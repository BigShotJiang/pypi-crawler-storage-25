"""Tests for atomic state persistence module."""

import json
import time
from pathlib import Path

import pytest

from code_generator.state import (
    CycleState,
    EffortHint,
    IssueState,
    State,
    StateCorruptedError,
    append_new_cycles,
    clear_pause,
    compute_requirements_hash,
    get_issues,
    is_paused,
    load_state,
    mark_paused,
    save_state,
)


def _make_issue(number: int = 1, status: str = "open", agent: str = "python-pro") -> IssueState:
    return IssueState(number=number, status=status, agent=agent)  # type: ignore[arg-type]


def _make_cycle(cycle_id: int = 1) -> CycleState:
    return CycleState(
        id=cycle_id,
        name="Cycle 1",
        milestone_number=1,
        milestone_title="Cycle 1 — Foundation",
        status="in_progress",
        phase=3,
        issues=[_make_issue()],
        commit_sha=None,
    )


class TestLoadState:
    def test_missing_file_returns_fresh_default(self, tmp_path: Path) -> None:
        """load_state returns a default State when the file does not exist."""
        path = tmp_path / "state.json"
        state = load_state(path)

        assert state.mode == "unknown"
        assert state.cycles == []
        assert state.issues == []
        assert state.phase is None
        assert state.session_id is None
        assert state.paused_until is None
        assert state.started_at != ""
        assert state.updated_at != ""

    def test_timestamps_are_iso8601z(self, tmp_path: Path) -> None:
        """Fresh default state has ISO 8601 UTC timestamps."""
        state = load_state(tmp_path / "state.json")

        assert state.started_at.endswith("Z")
        assert state.updated_at.endswith("Z")


class TestSaveAndLoadRoundTrip:
    def test_single_mode_round_trip(self, tmp_path: Path) -> None:
        """save_state then load_state preserves all single-mode fields."""
        path = tmp_path / ".code-generator" / "state.json"
        state = load_state(path)
        state.mode = "single"
        state.phase = 3
        state.issues = [_make_issue(1, "open", "python-pro"), _make_issue(2, "closed", "frontend")]
        state.session_id = "ses-abc"
        state.last_error = "something went wrong"

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.mode == "single"
        assert loaded.phase == 3
        assert loaded.session_id == "ses-abc"
        assert loaded.last_error == "something went wrong"
        assert len(loaded.issues) == 2
        assert loaded.issues[0].number == 1
        assert loaded.issues[1].status == "closed"

    def test_multi_cycle_round_trip(self, tmp_path: Path) -> None:
        """save_state then load_state preserves multi-cycle nested structure."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "multi-cycle"
        state.current_cycle = 2
        state.cycles = [_make_cycle(1), _make_cycle(2)]
        state.cycles[1].commit_sha = "abc123"
        state.cycles[1].depends_on = [1]

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.mode == "multi-cycle"
        assert loaded.current_cycle == 2
        assert len(loaded.cycles) == 2
        assert loaded.cycles[1].commit_sha == "abc123"
        assert loaded.cycles[1].depends_on == [1]

    def test_save_creates_parent_dirs(self, tmp_path: Path) -> None:
        """save_state creates the parent directory if it does not exist."""
        path = tmp_path / "deep" / "nested" / "state.json"
        state = load_state(path)

        save_state(path, state)

        assert path.exists()

    def test_save_updates_updated_at(self, tmp_path: Path) -> None:
        """save_state always refreshes updated_at on every write."""
        path = tmp_path / "state.json"
        state = load_state(path)
        original_ts = state.updated_at

        time.sleep(0.01)
        save_state(path, state)
        loaded = load_state(path)

        assert loaded.updated_at >= original_ts

    def test_json_has_two_space_indent(self, tmp_path: Path) -> None:
        """Saved JSON is pretty-printed with 2-space indentation."""
        path = tmp_path / "state.json"
        state = load_state(path)
        save_state(path, state)

        raw = path.read_text()
        parsed = json.loads(raw)
        assert json.dumps(parsed, indent=2) == raw.rstrip()

    def test_no_tmp_file_left_after_save(self, tmp_path: Path) -> None:
        """save_state must not leave a .tmp file after a successful write."""
        path = tmp_path / "state.json"
        state = load_state(path)

        save_state(path, state)
        save_state(path, state)

        tmp = Path(str(path) + ".tmp")
        assert not tmp.exists()

    def test_cycle_state_issues_round_trip(self, tmp_path: Path) -> None:
        """IssueState objects nested inside CycleState survive serialization."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "multi-cycle"
        cycle = _make_cycle()
        cycle.issues = [_make_issue(10, "closed", "nestjs-expert")]
        state.cycles = [cycle]

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.cycles[0].issues[0].number == 10
        assert loaded.cycles[0].issues[0].status == "closed"
        assert loaded.cycles[0].issues[0].agent == "nestjs-expert"


class TestPauseHelpers:
    def test_mark_paused_sets_fields(self, tmp_path: Path) -> None:
        """mark_paused populates paused_until, rate_limit_type, and session_id."""
        state = load_state(tmp_path / "state.json")
        future = int(time.time()) + 300

        mark_paused(state, resets_at=future, rate_limit_type="subscription", session_id="ses-xyz")

        assert state.paused_until == future
        assert state.rate_limit_type == "subscription"
        assert state.session_id == "ses-xyz"

    def test_clear_pause_removes_pause_fields(self, tmp_path: Path) -> None:
        """clear_pause resets paused_until and rate_limit_type to None."""
        state = load_state(tmp_path / "state.json")
        mark_paused(state, resets_at=int(time.time()) + 300, rate_limit_type="sub", session_id=None)

        clear_pause(state)

        assert state.paused_until is None
        assert state.rate_limit_type is None

    def test_is_paused_returns_true_when_in_future(self) -> None:
        """is_paused returns True when paused_until is in the future."""
        state = State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            paused_until=int(time.time()) + 3600,
        )

        assert is_paused(state) is True

    def test_is_paused_returns_false_when_in_past(self) -> None:
        """is_paused returns False when paused_until is in the past."""
        state = State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            paused_until=int(time.time()) - 1,
        )

        assert is_paused(state) is False

    def test_is_paused_returns_false_when_none(self) -> None:
        """is_paused returns False when paused_until is None."""
        state = State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )

        assert is_paused(state) is False

    def test_is_paused_accepts_custom_now(self) -> None:
        """is_paused uses the supplied now parameter instead of time.time()."""
        paused_until = 1000
        state = State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            paused_until=paused_until,
        )

        assert is_paused(state, now=500.0) is True
        assert is_paused(state, now=1001.0) is False


class TestGetIssues:
    def test_returns_state_issues_when_cycle_is_none(self) -> None:
        """When cycle is None, get_issues returns state.issues content."""
        issue = _make_issue(number=1)
        state = State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            issues=[issue],
        )
        result = get_issues(state, None)
        assert result == state.issues

    def test_returns_cycle_issues_when_cycle_provided(self) -> None:
        """When cycle is given, get_issues returns cycle.issues content."""
        cycle = _make_cycle()
        state = State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            issues=[_make_issue(number=99)],
        )
        result = get_issues(state, cycle)
        assert result == cycle.issues

    def test_returns_empty_list_when_cycle_has_no_issues(self) -> None:
        """get_issues returns an empty list when the cycle has no issues."""
        cycle = _make_cycle()
        cycle.issues = []
        state = State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        result = get_issues(state, cycle)
        assert result == []

    def test_returns_issues_sorted_ascending_single_mode(self) -> None:
        """get_issues must return state.issues sorted ascending by number even
        when the underlying list is stored out of order (Phase 5 fix-issue
        append can land in gh's default descending order)."""
        state = State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            issues=[_make_issue(number=91), _make_issue(number=90), _make_issue(number=89)],
        )
        result = get_issues(state, None)
        assert [i.number for i in result] == [89, 90, 91]

    def test_returns_issues_sorted_ascending_multi_cycle_mode(self) -> None:
        """Same invariant holds for multi-cycle mode via cycle.issues."""
        cycle = _make_cycle()
        cycle.issues = [
            _make_issue(number=91),
            _make_issue(number=90),
            _make_issue(number=89),
        ]
        state = State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        result = get_issues(state, cycle)
        assert [i.number for i in result] == [89, 90, 91]

    def test_phase5_fix_issue_append_still_yields_ascending_order(self) -> None:
        """Regression for Section 8 of requirements.md: when Phase 5 appends
        a lower-numbered fix-issue mid-cycle (e.g. #5 after #10 and #20 are
        already in the list), subsequent phases must still see ascending order."""
        cycle = _make_cycle()
        cycle.issues = [_make_issue(number=10), _make_issue(number=20)]
        state = State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        # Simulate Phase 5 extending with a new (lower-numbered) fix issue.
        cycle.issues.append(_make_issue(number=5))
        result = get_issues(state, cycle)
        assert [i.number for i in result] == [5, 10, 20]

    def test_does_not_mutate_underlying_list(self) -> None:
        """get_issues must return a new sorted list, leaving state.issues /
        cycle.issues in their original (possibly unsorted) order so that
        Phase 5's extend() semantics and state.json round-trips are unchanged."""
        original = [_make_issue(number=3), _make_issue(number=1), _make_issue(number=2)]
        state = State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            issues=list(original),
        )
        _ = get_issues(state, None)
        assert [i.number for i in state.issues] == [3, 1, 2]


class TestFullRoundTripAllFields:
    def test_two_cycles_three_issues_all_optional_fields(self, tmp_path: Path) -> None:
        """Full round-trip: 2 cycles × 3 issues each, all optional fields populated."""
        path = tmp_path / "state.json"

        cycle1 = CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=10,
            milestone_title="Cycle 1 — Foundation",
            status="completed",
            phase=7,
            issues=[
                IssueState(number=1, status="closed", agent="python-pro"),
                IssueState(number=2, status="closed", agent="frontend-developer"),
                IssueState(number=3, status="closed", agent="nestjs-expert"),
            ],
            commit_sha="abc123def456",
            depends_on=[],
            scope="backend",
        )
        cycle2 = CycleState(
            id=2,
            name="Cycle 2",
            milestone_number=11,
            milestone_title="Cycle 2 — Features",
            status="in_progress",
            phase=3,
            issues=[
                IssueState(number=4, status="open", agent="python-pro"),
                IssueState(number=5, status="open", agent="frontend-developer"),
                IssueState(number=6, status="closed", agent="baml-expert-agent"),
            ],
            commit_sha=None,
            depends_on=[1],
            scope="frontend",
        )
        state = State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            current_cycle=2,
            cycles=[cycle1, cycle2],
            phase=3,
            issues=[],
            session_id="ses-fulltest",
            paused_until=None,
            rate_limit_type=None,
            last_error="previous transient error",
        )

        save_state(path, state)
        loaded = load_state(path)

        # Root fields
        assert loaded.mode == "multi-cycle"
        assert loaded.current_cycle == 2
        assert loaded.phase == 3
        assert loaded.session_id == "ses-fulltest"
        assert loaded.last_error == "previous transient error"
        assert loaded.paused_until is None
        assert loaded.rate_limit_type is None

        # Cycle 1 — all fields survive serialization
        c1 = loaded.cycles[0]
        assert c1.id == 1
        assert c1.commit_sha == "abc123def456"
        assert c1.depends_on == []
        assert c1.scope == "backend"
        assert c1.status == "completed"
        assert c1.milestone_number == 10
        assert len(c1.issues) == 3
        assert c1.issues[0].number == 1
        assert c1.issues[0].status == "closed"
        assert c1.issues[1].agent == "frontend-developer"
        assert c1.issues[2].agent == "nestjs-expert"

        # Cycle 2 — optional commit_sha None and depends_on non-empty
        c2 = loaded.cycles[1]
        assert c2.id == 2
        assert c2.commit_sha is None
        assert c2.depends_on == [1]
        assert c2.scope == "frontend"
        assert len(c2.issues) == 3
        assert c2.issues[0].number == 4
        assert c2.issues[0].status == "open"
        assert c2.issues[2].status == "closed"
        assert c2.issues[2].agent == "baml-expert-agent"


class TestIsPausedBoundary:
    def test_paused_until_equals_now_returns_false(self) -> None:
        """is_paused returns False when paused_until exactly equals now (strict > used)."""
        now = int(time.time())
        state = State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            paused_until=now,
        )

        # paused_until == now → not paused (code does paused_until > now)
        assert is_paused(state, now=float(now)) is False


class TestLoadStateCorrupted:
    def test_corrupted_json_raises_json_decode_error(self, tmp_path: Path) -> None:
        """load_state raises JSONDecodeError when the file contains invalid JSON."""
        path = tmp_path / "state.json"
        path.write_text("{not valid json!!!", encoding="utf-8")

        with pytest.raises(json.JSONDecodeError):
            load_state(path)


class TestSaveStateStaleTemp:
    def test_save_overwrites_stale_tmp_file_from_previous_crash(self, tmp_path: Path) -> None:
        """save_state overwrites a stale .tmp file left behind by a previous crash."""
        path = tmp_path / "state.json"
        tmp = Path(str(path) + ".tmp")

        # Simulate a crash: a leftover .tmp with stale/partial content
        tmp.write_text('{"stale": true, "incomplete":', encoding="utf-8")
        assert tmp.exists()

        state = load_state(path)
        save_state(path, state)

        # The .tmp must be gone after a successful atomic write
        assert not tmp.exists()
        # The real state file must be valid and loadable
        loaded = load_state(path)
        assert loaded.mode == "unknown"


class TestEffortHintRoundTrip:
    def test_effort_hints_in_cycle_state_round_trip(self, tmp_path: Path) -> None:
        """effort_hints inside CycleState survive save/load serialization."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "multi-cycle"
        cycle = _make_cycle()
        cycle.effort_hints = [
            EffortHint(scope_keyword="database migration", effort="high"),
            EffortHint(scope_keyword="simple CRUD", effort="low"),
        ]
        state.cycles = [cycle]

        save_state(path, state)
        loaded = load_state(path)

        hints = loaded.cycles[0].effort_hints
        assert len(hints) == 2
        assert hints[0].scope_keyword == "database migration"
        assert hints[0].effort == "high"
        assert hints[1].scope_keyword == "simple CRUD"
        assert hints[1].effort == "low"

    def test_effort_hints_in_state_single_mode_round_trip(self, tmp_path: Path) -> None:
        """effort_hints on State root survive save/load in single mode."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "single"
        state.effort_hints = [
            EffortHint(scope_keyword="complex auth flow", effort="high"),
        ]

        save_state(path, state)
        loaded = load_state(path)

        assert len(loaded.effort_hints) == 1
        assert loaded.effort_hints[0].scope_keyword == "complex auth flow"
        assert loaded.effort_hints[0].effort == "high"

    def test_missing_effort_hints_defaults_to_empty_list_in_cycle(self, tmp_path: Path) -> None:
        """Old state JSON without effort_hints in cycle loads with empty list (backward compat)."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "multi-cycle",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "cycles": [
                {
                    "id": 1,
                    "name": "Cycle 1",
                    "milestone_number": None,
                    "milestone_title": "Cycle 1 — DB",
                    "status": "open",
                    "phase": 0,
                    "issues": [],
                    "commit_sha": None,
                    "depends_on": [],
                    "scope": "db",
                    # no "effort_hints" key — backward compat
                }
            ],
        }
        path.write_text(__import__("json").dumps(raw), encoding="utf-8")

        loaded = load_state(path)

        assert loaded.cycles[0].effort_hints == []

    def test_missing_effort_hints_defaults_to_empty_list_in_state(self, tmp_path: Path) -> None:
        """Old state JSON without top-level effort_hints loads with empty list."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "single",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            # no "effort_hints" key
        }
        path.write_text(__import__("json").dumps(raw), encoding="utf-8")

        loaded = load_state(path)

        assert loaded.effort_hints == []


class TestIssueStateLabels:
    def test_issue_from_dict_with_labels_preserves_them(self) -> None:
        """_issue_from_dict() reads the labels list when present."""
        from code_generator.state import _issue_from_dict  # type: ignore[attr-defined]

        issue = _issue_from_dict(
            {
                "number": 5,
                "status": "open",
                "agent": "python-pro",
                "labels": ["complexity:high", "area:api"],
            }
        )

        assert issue.labels == ["complexity:high", "area:api"]

    def test_issue_from_dict_without_labels_defaults_to_empty(self) -> None:
        """_issue_from_dict() returns empty labels list when key is absent (backward compat)."""
        from code_generator.state import _issue_from_dict  # type: ignore[attr-defined]

        issue = _issue_from_dict({"number": 3, "status": "closed", "agent": "frontend-developer"})

        assert issue.labels == []

    def test_issue_state_labels_round_trip(self, tmp_path: Path) -> None:
        """IssueState.labels survives save_state / load_state serialization."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "single"
        state.issues = [
            IssueState(
                number=1,
                status="open",
                agent="python-pro",
                labels=["complexity:high", "priority:high"],
            ),
            IssueState(number=2, status="closed", agent="frontend-developer", labels=[]),
        ]

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.issues[0].labels == ["complexity:high", "priority:high"]
        assert loaded.issues[1].labels == []

    def test_issue_state_labels_default_factory_is_independent(self) -> None:
        """Each IssueState gets its own labels list (no shared mutable default)."""
        a = IssueState(number=1, status="open", agent="python-pro")
        b = IssueState(number=2, status="open", agent="python-pro")
        a.labels.append("area:api")

        assert b.labels == []

    def test_old_state_json_without_labels_key_loads_cleanly(self, tmp_path: Path) -> None:
        """Existing state.json files without labels key on IssueState load without error."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "single",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "issues": [
                {
                    "number": 10,
                    "status": "open",
                    "agent": "python-pro",
                    # intentionally no "labels" key — old format
                }
            ],
        }
        path.write_text(__import__("json").dumps(raw), encoding="utf-8")

        loaded = load_state(path)

        assert loaded.issues[0].number == 10
        assert loaded.issues[0].labels == []


class TestIssueStateComments:
    """Tests for IssueState.comments caching field (§9 comment dedup)."""

    def test_comments_defaults_to_none(self) -> None:
        """IssueState.comments is None when not explicitly set."""
        issue = IssueState(number=1, status="open", agent="python-pro")

        assert issue.comments is None

    def test_comments_round_trips_through_save_load(self, tmp_path: Path) -> None:
        """IssueState.comments value survives save_state / load_state serialization."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "single"
        cached = "## Pre-fetched Issue Comments\n\n**alice** (2026-01-01): Nice comment"
        state.issues = [IssueState(number=1, status="open", agent="python-pro", comments=cached)]

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.issues[0].comments == cached

    def test_comments_none_round_trips(self, tmp_path: Path) -> None:
        """IssueState.comments=None is preserved through save_state / load_state."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "single"
        state.issues = [IssueState(number=1, status="open", agent="python-pro", comments=None)]

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.issues[0].comments is None

    def test_legacy_state_without_comments_key_loads_as_none(self, tmp_path: Path) -> None:
        """Existing state.json without comments key on IssueState loads as None (backward compat)."""
        import json as _json

        path = tmp_path / "state.json"
        raw = {
            "mode": "single",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "issues": [
                {
                    "number": 7,
                    "status": "open",
                    "agent": "python-pro",
                    # intentionally no "comments" key — legacy 0.2.x format
                }
            ],
        }
        path.write_text(_json.dumps(raw), encoding="utf-8")

        loaded = load_state(path)

        assert loaded.issues[0].number == 7
        assert loaded.issues[0].comments is None

    def test_comments_persisted_in_cycle_issues(self, tmp_path: Path) -> None:
        """IssueState.comments inside CycleState.issues survives round-trip."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "multi-cycle"
        cached = "## Pre-fetched Issue Comments\n\n**bob** (2026-02-01): Looks good"
        cycle = CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=1,
            milestone_title="M",
            status="open",
            phase=2,
            issues=[IssueState(number=42, status="open", agent="python-pro", comments=cached)],
            commit_sha=None,
        )
        state.cycles = [cycle]

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.cycles[0].issues[0].comments == cached


class TestRequirementsHash:
    def test_consistent_hash_for_same_content(self, tmp_path: Path) -> None:
        """compute_requirements_hash returns the same hash for the same file content."""
        req = tmp_path / "requirements.md"
        req.write_text("# My requirements\nBuild something.", encoding="utf-8")

        hash1 = compute_requirements_hash(req)
        hash2 = compute_requirements_hash(req)

        assert hash1 == hash2

    def test_different_hash_for_different_content(self, tmp_path: Path) -> None:
        """compute_requirements_hash returns different hashes for different content."""
        req_a = tmp_path / "requirements_a.md"
        req_b = tmp_path / "requirements_b.md"
        req_a.write_text("# Requirements A", encoding="utf-8")
        req_b.write_text("# Requirements B", encoding="utf-8")

        assert compute_requirements_hash(req_a) != compute_requirements_hash(req_b)

    def test_returns_hex_string(self, tmp_path: Path) -> None:
        """compute_requirements_hash returns a lowercase hex string (SHA-256 = 64 chars)."""
        req = tmp_path / "requirements.md"
        req.write_text("content", encoding="utf-8")

        result = compute_requirements_hash(req)

        assert len(result) == 64
        assert all(c in "0123456789abcdef" for c in result)

    def test_hash_is_utf8_based(self, tmp_path: Path) -> None:
        """Hash is computed on UTF-8 bytes, ensuring determinism across platforms."""
        import hashlib

        content = "Héllo wörld — unicode content"
        req = tmp_path / "requirements.md"
        req.write_text(content, encoding="utf-8")

        expected = hashlib.sha256(content.encode("utf-8")).hexdigest()

        assert compute_requirements_hash(req) == expected

    def test_state_has_requirements_hash_field_default_none(self) -> None:
        """State dataclass has requirements_hash field defaulting to None."""
        state = State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )

        assert state.requirements_hash is None

    def test_load_state_without_requirements_hash_returns_none(self, tmp_path: Path) -> None:
        """load_state from a state.json without requirements_hash field yields None, no error."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "single",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            # intentionally no "requirements_hash" key — pre-0.2.0 format
        }
        path.write_text(__import__("json").dumps(raw), encoding="utf-8")

        loaded = load_state(path)

        assert loaded.requirements_hash is None

    def test_round_trip_save_load_preserves_hash(self, tmp_path: Path) -> None:
        """save_state then load_state preserves the requirements_hash value."""
        state_path = tmp_path / "state.json"
        req_path = tmp_path / "requirements.md"
        req_path.write_text("# Build a great product", encoding="utf-8")

        state = load_state(state_path)
        state.requirements_hash = compute_requirements_hash(req_path)

        save_state(state_path, state)
        loaded = load_state(state_path)

        assert loaded.requirements_hash == state.requirements_hash

    def test_round_trip_preserves_none_hash(self, tmp_path: Path) -> None:
        """save_state then load_state preserves requirements_hash=None."""
        state_path = tmp_path / "state.json"
        state = load_state(state_path)
        state.requirements_hash = None

        save_state(state_path, state)
        loaded = load_state(state_path)

        assert loaded.requirements_hash is None


# ---------------------------------------------------------------------------
# append_new_cycles helper
# ---------------------------------------------------------------------------


class TestAppendNewCycles:
    """Unit tests for the append_new_cycles pure helper in state.py."""

    def _completed(self, cycle_id: int, scope: str) -> CycleState:
        return CycleState(
            id=cycle_id,
            name=f"Cycle {cycle_id}",
            milestone_number=cycle_id,
            milestone_title=f"Cycle {cycle_id} — {scope}",
            status="completed",
            phase=7,
            issues=[],
            commit_sha=None,
            scope=scope,
        )

    def _multi_state(self, cycles: list) -> State:
        return State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            cycles=cycles,
        )

    def _raw(self, raw_id: int, scope: str, depends_on=None):
        return {
            "id": raw_id,
            "name": f"Cycle {raw_id}",
            "milestone_title": f"Cycle {raw_id} — {scope}",
            "scope": scope,
            "depends_on": depends_on or [],
        }

    def test_3_completed_plus_2_new_returns_2_new_cycles(self) -> None:
        """3 completed cycles + Phase 0 returning 5 scopes → 2 new CycleState objects."""
        state = self._multi_state(
            [
                self._completed(1, "auth"),
                self._completed(2, "api"),
                self._completed(3, "database"),
            ]
        )
        raw = [
            self._raw(1, "auth"),
            self._raw(2, "api"),
            self._raw(3, "database"),
            self._raw(4, "frontend", depends_on=[1]),
            self._raw(5, "notifications", depends_on=[4]),
        ]

        result = append_new_cycles(state, raw)

        assert len(result) == 2
        assert result[0].scope == "frontend"
        assert result[0].id == 4
        assert result[0].status == "open"
        assert result[1].scope == "notifications"
        assert result[1].id == 5
        assert result[1].status == "open"

    def test_after_extending_state_has_5_cycles_correct_statuses(self) -> None:
        """After extending state.cycles: 5 total, first 3 completed, last 2 open."""
        state = self._multi_state(
            [
                self._completed(1, "auth"),
                self._completed(2, "api"),
                self._completed(3, "database"),
            ]
        )
        raw = [
            self._raw(1, "auth"),
            self._raw(2, "api"),
            self._raw(3, "database"),
            self._raw(4, "frontend"),
            self._raw(5, "notifications"),
        ]

        state.cycles.extend(append_new_cycles(state, raw))

        assert len(state.cycles) == 5
        assert [c.id for c in state.cycles] == [1, 2, 3, 4, 5]
        assert all(c.status == "completed" for c in state.cycles[:3])
        assert all(c.status == "open" for c in state.cycles[3:])

    def test_depends_on_remapped_from_raw_ids_to_state_ids(self) -> None:
        """New cycles get depends_on remapped from Phase 0 raw IDs to actual state IDs."""
        state = self._multi_state(
            [
                self._completed(1, "auth"),
                self._completed(2, "api"),
                self._completed(3, "database"),
            ]
        )
        raw = [
            self._raw(1, "auth"),
            self._raw(2, "api"),
            self._raw(3, "database"),
            self._raw(4, "frontend", depends_on=[1, 3]),
            self._raw(5, "notifications", depends_on=[4]),
        ]

        result = append_new_cycles(state, raw)

        assert result[0].depends_on == [1, 3]
        assert result[1].depends_on == [4]

    def test_identical_scopes_returns_empty_list(self) -> None:
        """When all raw scopes already exist in state, result is empty."""
        state = self._multi_state(
            [
                self._completed(1, "auth"),
                self._completed(2, "api"),
            ]
        )
        raw = [self._raw(1, "auth"), self._raw(2, "api")]

        assert append_new_cycles(state, raw) == []

    def test_idempotent_second_call_appends_nothing(self) -> None:
        """Calling append_new_cycles twice with same new scopes is idempotent."""
        state = self._multi_state([self._completed(1, "auth")])
        raw = [self._raw(1, "auth"), self._raw(2, "frontend")]

        state.cycles.extend(append_new_cycles(state, raw))
        second_batch = append_new_cycles(state, raw)

        assert second_batch == []
        assert len(state.cycles) == 2

    def test_empty_state_all_raw_cycles_become_new(self) -> None:
        """When state has no cycles, all raw cycles are returned as new."""
        state = self._multi_state([])
        raw = [self._raw(1, "auth"), self._raw(2, "api", depends_on=[1])]

        result = append_new_cycles(state, raw)

        assert len(result) == 2
        assert result[0].id == 1
        assert result[1].id == 2
        assert result[1].depends_on == [1]

    def test_new_cycle_ids_start_from_max_existing_plus_1(self) -> None:
        """New cycle IDs are assigned from max(existing_ids) + 1."""
        state = self._multi_state(
            [
                self._completed(10, "auth"),
                self._completed(20, "api"),
            ]
        )
        raw = [
            self._raw(1, "auth"),
            self._raw(2, "api"),
            self._raw(3, "new-feature"),
        ]

        result = append_new_cycles(state, raw)

        assert len(result) == 1
        assert result[0].scope == "new-feature"
        assert result[0].id == 21

    def test_does_not_mutate_state_cycles(self) -> None:
        """append_new_cycles must not modify state.cycles in place."""
        state = self._multi_state([self._completed(1, "auth")])
        raw = [self._raw(1, "auth"), self._raw(2, "frontend")]

        append_new_cycles(state, raw)

        assert len(state.cycles) == 1


# ---------------------------------------------------------------------------
# base_commit field — State, CycleState, backward compatibility
# ---------------------------------------------------------------------------


class TestBaseCommitField:
    def test_state_base_commit_defaults_to_none(self) -> None:
        """State dataclass has base_commit field defaulting to None."""
        state = State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )

        assert state.base_commit is None

    def test_cycle_state_base_commit_defaults_to_none(self) -> None:
        """CycleState dataclass has base_commit field defaulting to None."""
        cycle = _make_cycle()

        assert cycle.base_commit is None

    def test_load_state_v010_without_base_commit_yields_none(self, tmp_path: Path) -> None:
        """load_state() on a v0.1.0 state.json (no base_commit key) deserializes
        cleanly with base_commit=None — no KeyError, no TypeError."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "single",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            # intentionally no "base_commit" key — pre-feature-8 format
        }
        path.write_text(__import__("json").dumps(raw), encoding="utf-8")

        loaded = load_state(path)

        assert loaded.base_commit is None

    def test_load_state_with_base_commit_round_trips(self, tmp_path: Path) -> None:
        """load_state() on a state.json with base_commit='abc123' preserves the value."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "single"
        state.base_commit = "abc123def456789012345678901234567890abcd"

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.base_commit == "abc123def456789012345678901234567890abcd"

    def test_cycle_from_dict_without_base_commit_yields_none(self) -> None:
        """_cycle_from_dict() with no base_commit key produces CycleState(base_commit=None)."""
        from code_generator.state import _cycle_from_dict  # type: ignore[attr-defined]

        d = {
            "id": 1,
            "name": "Cycle 1",
            "milestone_number": None,
            "milestone_title": "Cycle 1 — Foundation",
            "status": "open",
            "phase": 0,
            "issues": [],
            "commit_sha": None,
            # intentionally no "base_commit" key
        }

        cycle = _cycle_from_dict(d)

        assert cycle.base_commit is None

    def test_cycle_from_dict_with_base_commit_preserves_value(self) -> None:
        """_cycle_from_dict() reads base_commit when present in the dict."""
        from code_generator.state import _cycle_from_dict  # type: ignore[attr-defined]

        sha = "deadbeef" * 5  # 40 chars
        d = {
            "id": 1,
            "name": "Cycle 1",
            "milestone_number": None,
            "milestone_title": "Cycle 1 — Foundation",
            "status": "open",
            "phase": 0,
            "issues": [],
            "commit_sha": None,
            "base_commit": sha,
        }

        cycle = _cycle_from_dict(d)

        assert cycle.base_commit == sha


# ---------------------------------------------------------------------------
# token_usage and cycle timing fields — CycleState, State
# ---------------------------------------------------------------------------


class TestStateCorruptedErrorClass:
    def test_is_exception_subclass(self) -> None:
        """StateCorruptedError is a subclass of Exception."""
        assert issubclass(StateCorruptedError, Exception)

    def test_has_path_location_reason_attributes(self) -> None:
        """StateCorruptedError exposes path, location, and reason attributes."""
        err = StateCorruptedError(
            path=Path("/foo/state.json"),
            location="cycles[0].issues[1]",
            reason="expected dict, got int",
        )

        assert err.path == Path("/foo/state.json")
        assert err.location == "cycles[0].issues[1]"
        assert err.reason == "expected dict, got int"

    def test_str_includes_location_and_reason(self) -> None:
        """str(StateCorruptedError) contains location and reason."""
        err = StateCorruptedError(
            path=Path("/tmp/state.json"),
            location="cycles[2].issues[0]",
            reason="expected dict, got str",
        )

        msg = str(err)
        assert "cycles[2].issues[0]" in msg
        assert "expected dict, got str" in msg

    def test_can_be_raised_and_caught(self) -> None:
        """StateCorruptedError can be raised and caught as Exception."""
        with pytest.raises(StateCorruptedError):
            raise StateCorruptedError(
                path=Path("/x"), location="issues[0]", reason="expected dict, got int"
            )


class TestSchemaValidationOnLoad:
    """Tests for StateCorruptedError raised during load_state schema validation."""

    def test_incident_2026_04_15_int_in_cycle_issues_raises_state_corrupted_error(
        self,
    ) -> None:
        """Fixture reproducing the 2026-04-15 incident: integers written into cycles[0].issues.

        A subsequent load_state() must crash immediately with a useful location
        (cycles[0].issues[0]) instead of deep in the orchestrator with
        'int object is not subscriptable'.
        """
        fixture = Path(__file__).parent / "fixtures" / "state-corrupted-int-issues.json"

        with pytest.raises(StateCorruptedError) as exc_info:
            load_state(fixture)

        err = exc_info.value
        assert err.location == "cycles[0].issues[0]"
        assert "int" in err.reason
        assert err.path == fixture

    def test_top_level_non_dict_json_raises_state_corrupted_error(self, tmp_path: Path) -> None:
        """load_state raises StateCorruptedError when the root JSON value is not a dict."""
        path = tmp_path / "state.json"
        path.write_text("42", encoding="utf-8")

        with pytest.raises(StateCorruptedError) as exc_info:
            load_state(path)

        assert exc_info.value.path == path

    def test_non_list_issues_in_cycle_raises_state_corrupted_error(self, tmp_path: Path) -> None:
        """load_state raises StateCorruptedError when cycles[N].issues is not a list."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "multi-cycle",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "cycles": [
                {
                    "id": 1,
                    "name": "C1",
                    "milestone_title": "C1",
                    "status": "open",
                    "phase": 0,
                    "issues": "not-a-list",
                    "commit_sha": None,
                }
            ],
        }
        path.write_text(json.dumps(raw), encoding="utf-8")

        with pytest.raises(StateCorruptedError) as exc_info:
            load_state(path)

        err = exc_info.value
        assert "cycles[0].issues" in err.location
        assert err.path == path

    def test_missing_required_key_in_cycle_raises_state_corrupted_error(
        self, tmp_path: Path
    ) -> None:
        """load_state raises StateCorruptedError when a required cycle key is missing."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "multi-cycle",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "cycles": [
                {
                    # missing required "id" key
                    "name": "C1",
                    "milestone_title": "C1",
                    "status": "open",
                    "phase": 0,
                    "issues": [],
                    "commit_sha": None,
                }
            ],
        }
        path.write_text(json.dumps(raw), encoding="utf-8")

        with pytest.raises(StateCorruptedError) as exc_info:
            load_state(path)

        assert exc_info.value.path == path

    def test_non_dict_cycle_raises_state_corrupted_error(self, tmp_path: Path) -> None:
        """load_state raises StateCorruptedError when a cycle entry is not a dict."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "multi-cycle",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "cycles": [42],
        }
        path.write_text(json.dumps(raw), encoding="utf-8")

        with pytest.raises(StateCorruptedError) as exc_info:
            load_state(path)

        err = exc_info.value
        assert "cycles[0]" in err.location
        assert err.path == path

    def test_top_level_issues_non_dict_raises_state_corrupted_error(self, tmp_path: Path) -> None:
        """load_state raises StateCorruptedError when top-level issues contain a non-dict."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "single",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "issues": [99],
        }
        path.write_text(json.dumps(raw), encoding="utf-8")

        with pytest.raises(StateCorruptedError) as exc_info:
            load_state(path)

        err = exc_info.value
        assert "issues[0]" in err.location
        assert err.path == path

    def test_error_location_identifies_nested_cycle_and_issue_index(self, tmp_path: Path) -> None:
        """Error location string is exact: cycles[C].issues[I] with correct indices."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "multi-cycle",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "cycles": [
                {
                    "id": 1,
                    "name": "C1",
                    "milestone_title": "C1",
                    "status": "open",
                    "phase": 0,
                    "issues": [{"number": 1, "status": "open", "agent": "python-pro"}, 42],
                    "commit_sha": None,
                }
            ],
        }
        path.write_text(json.dumps(raw), encoding="utf-8")

        with pytest.raises(StateCorruptedError) as exc_info:
            load_state(path)

        err = exc_info.value
        assert err.location == "cycles[0].issues[1]"
        assert "int" in err.reason

    def test_valid_state_still_loads_unchanged_after_schema_validation(
        self, tmp_path: Path
    ) -> None:
        """Backward compat: valid 0.2.x state.json files load without raising."""
        path = tmp_path / "state.json"
        state = State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        state.cycles = [_make_cycle()]
        save_state(path, state)

        loaded = load_state(path)

        assert loaded.mode == "multi-cycle"
        assert len(loaded.cycles) == 1

    def test_valid_fixture_state_2026_04_14_loads_unchanged(self) -> None:
        """Real state.json from 2026-04-14 loads cleanly (backward-compat regression)."""
        fixture = Path(__file__).parent / "fixtures" / "state_2026_04_14.json"

        loaded = load_state(fixture)

        assert loaded.mode == "multi-cycle"
        assert len(loaded.cycles) == 5


class TestTokenUsageAndCycleTiming:
    """Tests for token_usage / started_at / finished_at fields (issue #122)."""

    def _minimal_cycle_dict(self) -> dict:
        return {
            "id": 1,
            "name": "Cycle 1",
            "milestone_number": None,
            "milestone_title": "Cycle 1 — Foundation",
            "status": "open",
            "phase": 0,
            "issues": [],
            "commit_sha": None,
        }

    def test_cycle_state_has_token_usage_defaulting_to_empty_dict(self) -> None:
        """CycleState.token_usage defaults to an empty dict (YAGNI-safe)."""
        cycle = _make_cycle()
        assert cycle.token_usage == {}

    def test_state_has_token_usage_defaulting_to_empty_dict(self) -> None:
        """State.token_usage defaults to an empty dict (single-cycle mode)."""
        state = State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        assert state.token_usage == {}

    def test_cycle_state_started_at_defaults_to_none(self) -> None:
        """CycleState.started_at defaults to None."""
        cycle = _make_cycle()
        assert cycle.started_at is None

    def test_cycle_state_finished_at_defaults_to_none(self) -> None:
        """CycleState.finished_at defaults to None."""
        cycle = _make_cycle()
        assert cycle.finished_at is None

    def test_old_state_json_without_token_usage_loads_with_empty_dict(self, tmp_path: Path) -> None:
        """load_state() on a v0.1.0 state.json (no token_usage key) → empty dict, no error."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "single",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            # intentionally no "token_usage" key — old format
        }
        path.write_text(__import__("json").dumps(raw), encoding="utf-8")

        loaded = load_state(path)

        assert loaded.token_usage == {}

    def test_old_cycle_dict_without_token_usage_loads_with_empty_dict(self) -> None:
        """_cycle_from_dict() on a dict without token_usage → empty dict, no error."""
        from code_generator.state import _cycle_from_dict  # type: ignore[attr-defined]

        cycle = _cycle_from_dict(self._minimal_cycle_dict())

        assert cycle.token_usage == {}

    def test_old_cycle_dict_without_timing_fields_loads_with_none(self) -> None:
        """_cycle_from_dict() on a dict without started_at/finished_at → None, no error."""
        from code_generator.state import _cycle_from_dict  # type: ignore[attr-defined]

        cycle = _cycle_from_dict(self._minimal_cycle_dict())

        assert cycle.started_at is None
        assert cycle.finished_at is None

    def test_round_trip_cycle_with_populated_token_usage(self, tmp_path: Path) -> None:
        """save/load round-trip preserves populated token_usage in CycleState."""
        from code_generator.runner.types import TokenUsage

        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "multi-cycle"
        cycle = _make_cycle()
        cycle.token_usage = {
            "phase0": TokenUsage(input=1000, output=200, cache_read=50, cache_write=30),
            "phase3_4": TokenUsage(input=8000, output=3000, cache_read=100, cache_write=0),
        }
        state.cycles = [cycle]

        save_state(path, state)
        loaded = load_state(path)

        phase0 = loaded.cycles[0].token_usage["phase0"]
        phase3_4 = loaded.cycles[0].token_usage["phase3_4"]
        assert phase0.input == 1000
        assert phase0.output == 200
        assert phase0.cache_read == 50
        assert phase0.cache_write == 30
        assert phase3_4.input == 8000
        assert phase3_4.output == 3000

    def test_partial_phase_coverage_missing_phases_absent_not_zero_filled(
        self, tmp_path: Path
    ) -> None:
        """Only phases with recorded usage appear in the dict; others are absent."""
        from code_generator.runner.types import TokenUsage

        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "multi-cycle"
        cycle = _make_cycle()
        cycle.token_usage = {"phase1": TokenUsage(input=500, output=100)}
        state.cycles = [cycle]

        save_state(path, state)
        loaded = load_state(path)

        usage = loaded.cycles[0].token_usage
        assert "phase1" in usage
        assert "phase0" not in usage
        assert "phase3_4" not in usage
        assert len(usage) == 1

    def test_cycle_timing_fields_round_trip(self, tmp_path: Path) -> None:
        """started_at and finished_at in CycleState survive save/load."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "multi-cycle"
        cycle = _make_cycle()
        cycle.started_at = "2026-04-14T10:00:00Z"
        cycle.finished_at = "2026-04-14T10:45:00Z"
        state.cycles = [cycle]

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.cycles[0].started_at == "2026-04-14T10:00:00Z"
        assert loaded.cycles[0].finished_at == "2026-04-14T10:45:00Z"

    def test_asdict_serializes_token_usage_to_nested_dicts(self) -> None:
        """dataclasses.asdict() converts TokenUsage instances to plain dicts."""
        import dataclasses

        from code_generator.runner.types import TokenUsage

        state = State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        state.token_usage = {"phase1": TokenUsage(input=100, output=50)}

        raw = dataclasses.asdict(state)

        assert isinstance(raw["token_usage"]["phase1"], dict)
        assert raw["token_usage"]["phase1"]["input"] == 100
        assert raw["token_usage"]["phase1"]["output"] == 50

    def test_token_usage_default_factory_is_independent_per_instance(self) -> None:
        """Each CycleState gets its own token_usage dict (no shared mutable default)."""
        from code_generator.runner.types import TokenUsage

        cycle_a = _make_cycle(1)
        cycle_b = _make_cycle(2)
        cycle_a.token_usage["phase0"] = TokenUsage(input=999)

        assert cycle_b.token_usage == {}

    def test_token_usage_from_dict_missing_num_turns_defaults_to_zero(self) -> None:
        """Old state.json dict without num_turns deserializes with num_turns=0 (issue #204)."""
        from code_generator.state import _token_usage_from_dict  # type: ignore[attr-defined]

        raw = {
            "phase0": {
                "input": 100,
                "output": 50,
                "cache_read": 10,
                "cache_write": 5,
                # intentionally no "num_turns" — pre-0.3.1 state.json format
            }
        }

        result = _token_usage_from_dict(raw)

        assert result["phase0"].num_turns == 0
        # Other fields are still populated correctly.
        assert result["phase0"].input == 100
        assert result["phase0"].output == 50
        assert result["phase0"].cache_read == 10
        assert result["phase0"].cache_write == 5

    def test_token_usage_from_dict_preserves_num_turns_when_present(self) -> None:
        """When num_turns is present in the dict, _token_usage_from_dict reads it."""
        from code_generator.state import _token_usage_from_dict  # type: ignore[attr-defined]

        raw = {"phase3_4": {"input": 0, "output": 0, "num_turns": 42}}

        result = _token_usage_from_dict(raw)

        assert result["phase3_4"].num_turns == 42

    def test_token_usage_num_turns_round_trip(self, tmp_path: Path) -> None:
        """TokenUsage(num_turns=7) → dict → _token_usage_from_dict → .num_turns == 7."""
        import dataclasses

        from code_generator.runner.types import TokenUsage
        from code_generator.state import _token_usage_from_dict  # type: ignore[attr-defined]

        original = {"phase3_4": TokenUsage(input=8000, output=3000, num_turns=7)}
        raw = {phase: dataclasses.asdict(usage) for phase, usage in original.items()}

        restored = _token_usage_from_dict(raw)

        assert restored["phase3_4"].num_turns == 7
        assert restored["phase3_4"].input == 8000
        assert restored["phase3_4"].output == 3000

    def test_save_load_round_trip_preserves_num_turns(self, tmp_path: Path) -> None:
        """save_state → load_state round-trip preserves num_turns in CycleState.token_usage."""
        from code_generator.runner.types import TokenUsage

        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "multi-cycle"
        cycle = _make_cycle()
        cycle.token_usage = {"phase3_4": TokenUsage(input=8000, output=3000, num_turns=12)}
        state.cycles = [cycle]

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.cycles[0].token_usage["phase3_4"].num_turns == 12


# ---------------------------------------------------------------------------
# Issue #149 — State.session_mode, client_alive_at, repo fields
# ---------------------------------------------------------------------------


class TestSessionModeField:
    """Tests for State.session_mode: Literal['shared','fresh'] = 'shared'."""

    def test_session_mode_defaults_to_shared(self) -> None:
        """State.session_mode defaults to 'shared'."""
        state = State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )

        assert state.session_mode == "shared"

    def test_session_mode_can_be_set_to_fresh(self) -> None:
        """State.session_mode can be explicitly set to 'fresh'."""
        state = State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            session_mode="fresh",
        )

        assert state.session_mode == "fresh"

    def test_session_mode_round_trip_shared(self, tmp_path: Path) -> None:
        """session_mode='shared' survives save_state / load_state round-trip."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.session_mode = "shared"

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.session_mode == "shared"

    def test_session_mode_round_trip_fresh(self, tmp_path: Path) -> None:
        """session_mode='fresh' survives save_state / load_state round-trip."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.session_mode = "fresh"

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.session_mode == "fresh"

    def test_invalid_session_mode_raises_state_corrupted_error(self, tmp_path: Path) -> None:
        """load_state raises StateCorruptedError for unknown session_mode values."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "single",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "session_mode": "invalid-mode",
        }
        path.write_text(__import__("json").dumps(raw), encoding="utf-8")

        with pytest.raises(StateCorruptedError) as exc_info:
            load_state(path)

        err = exc_info.value
        assert "session_mode" in err.location
        assert "invalid-mode" in err.reason
        assert err.path == path

    def test_missing_session_mode_in_legacy_json_defaults_to_shared(self, tmp_path: Path) -> None:
        """Old 0.2.x state.json without session_mode loads cleanly with default 'shared'."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "single",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            # no "session_mode" key — 0.2.x format
        }
        path.write_text(__import__("json").dumps(raw), encoding="utf-8")

        loaded = load_state(path)

        assert loaded.session_mode == "shared"


class TestClientAliveAtField:
    """Tests for State.client_alive_at: str | None = None."""

    def test_client_alive_at_defaults_to_none(self) -> None:
        """State.client_alive_at defaults to None."""
        state = State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )

        assert state.client_alive_at is None

    def test_client_alive_at_round_trip_with_value(self, tmp_path: Path) -> None:
        """client_alive_at ISO timestamp survives save_state / load_state round-trip."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.client_alive_at = "2026-04-17T10:00:00Z"

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.client_alive_at == "2026-04-17T10:00:00Z"

    def test_client_alive_at_round_trip_none(self, tmp_path: Path) -> None:
        """client_alive_at=None survives save_state / load_state round-trip."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.client_alive_at = None

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.client_alive_at is None

    def test_missing_client_alive_at_in_legacy_json_defaults_to_none(self, tmp_path: Path) -> None:
        """Old 0.2.x state.json without client_alive_at loads cleanly with default None."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "single",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            # no "client_alive_at" key — 0.2.x format
        }
        path.write_text(__import__("json").dumps(raw), encoding="utf-8")

        loaded = load_state(path)

        assert loaded.client_alive_at is None


class TestRepoField:
    """Tests for State.repo: RepoInfo | None = None."""

    def test_repo_defaults_to_none(self) -> None:
        """State.repo defaults to None."""
        state = State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )

        assert state.repo is None

    def test_repo_round_trip_with_repo_info(self, tmp_path: Path) -> None:
        """State.repo with a RepoInfo survives save_state / load_state round-trip."""
        from code_generator.repo_info import RepoInfo

        path = tmp_path / "state.json"
        state = load_state(path)
        state.repo = RepoInfo(host="github.com", owner="acme", name="my-project")

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.repo is not None
        assert loaded.repo.host == "github.com"
        assert loaded.repo.owner == "acme"
        assert loaded.repo.name == "my-project"
        assert loaded.repo.full == "acme/my-project"

    def test_repo_round_trip_none(self, tmp_path: Path) -> None:
        """State.repo=None survives save_state / load_state round-trip."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.repo = None

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.repo is None

    def test_missing_repo_in_legacy_json_defaults_to_none(self, tmp_path: Path) -> None:
        """Old 0.2.x state.json without repo loads cleanly with default None."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "single",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            # no "repo" key — 0.2.x format
        }
        path.write_text(__import__("json").dumps(raw), encoding="utf-8")

        loaded = load_state(path)

        assert loaded.repo is None

    def test_repo_serialized_as_nested_dict_in_json(self, tmp_path: Path) -> None:
        """save_state emits repo as a nested dict (not a RepoInfo object string)."""
        from code_generator.repo_info import RepoInfo

        path = tmp_path / "state.json"
        state = load_state(path)
        state.repo = RepoInfo(host="github.com", owner="acme", name="my-project")

        save_state(path, state)
        raw = json.loads(path.read_text(encoding="utf-8"))

        assert isinstance(raw["repo"], dict)
        assert raw["repo"]["host"] == "github.com"
        assert raw["repo"]["owner"] == "acme"
        assert raw["repo"]["name"] == "my-project"


class TestRepoInfoHelpers:
    """Tests for _repo_info_from_dict and _repo_info_to_dict helpers."""

    def test_repo_info_from_dict_reconstructs_repo_info(self) -> None:
        """_repo_info_from_dict builds a RepoInfo from a plain dict."""
        from code_generator.state import _repo_info_from_dict  # type: ignore[attr-defined]

        d = {"host": "github.com", "owner": "acme", "name": "my-project"}
        repo = _repo_info_from_dict(d)

        assert repo.host == "github.com"
        assert repo.owner == "acme"
        assert repo.name == "my-project"
        assert repo.full == "acme/my-project"

    def test_repo_info_from_dict_ignores_extra_keys(self) -> None:
        """_repo_info_from_dict ignores extra keys like 'full' (derived field)."""
        from code_generator.state import _repo_info_from_dict  # type: ignore[attr-defined]

        d = {"host": "github.com", "owner": "acme", "name": "my-project", "full": "acme/my-project"}
        repo = _repo_info_from_dict(d)

        assert repo.host == "github.com"
        assert repo.full == "acme/my-project"

    def test_repo_info_to_dict_serializes_core_fields(self) -> None:
        """_repo_info_to_dict returns a dict with host, owner, name."""
        from code_generator.repo_info import RepoInfo
        from code_generator.state import _repo_info_to_dict  # type: ignore[attr-defined]

        repo = RepoInfo(host="github.com", owner="acme", name="my-project")
        d = _repo_info_to_dict(repo)

        assert d["host"] == "github.com"
        assert d["owner"] == "acme"
        assert d["name"] == "my-project"


class TestLegacyFixtureLoad:
    """Test backward-compat loading of a checked-in 0.2.x state.json fixture."""

    def test_legacy_02x_fixture_loads_with_new_field_defaults(self) -> None:
        """A checked-in 0.2.x state.json (no new fields) loads cleanly with defaults."""
        fixture = Path(__file__).parent / "fixtures" / "state_legacy_02x.json"

        loaded = load_state(fixture)

        assert loaded.session_mode == "shared"
        assert loaded.client_alive_at is None
        assert loaded.repo is None

    def test_legacy_02x_fixture_preserves_existing_data(self) -> None:
        """Existing data in a 0.2.x fixture (mode, cycles, issues) is preserved."""
        fixture = Path(__file__).parent / "fixtures" / "state_legacy_02x.json"

        loaded = load_state(fixture)

        assert loaded.mode == "multi-cycle"
        assert len(loaded.cycles) >= 1


# ---------------------------------------------------------------------------
# Issue #150 — telemetry fields: prompt_hashes, sdk_version,
#              cache_telemetry, issue.comments
# ---------------------------------------------------------------------------

_DEFAULT_CACHE_TELEMETRY: dict[str, int | float] = {
    "input": 0,
    "output": 0,
    "cache_read": 0,
    "cache_write": 0,
    "cache_hit_pct": 0.0,
    "wall_seconds": 0,
}


class TestPromptHashesField:
    """Tests for State.prompt_hashes: dict[str, str] = {}."""

    def test_prompt_hashes_defaults_to_empty_dict(self) -> None:
        """State.prompt_hashes defaults to an empty dict."""
        state = State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )

        assert state.prompt_hashes == {}

    def test_prompt_hashes_default_factory_is_independent(self) -> None:
        """Each State instance gets its own prompt_hashes dict (no shared mutable default)."""
        a = State(
            mode="single", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
        )
        b = State(
            mode="single", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
        )
        a.prompt_hashes["phase1"] = "deadbeef"

        assert b.prompt_hashes == {}

    def test_prompt_hashes_round_trip(self, tmp_path: Path) -> None:
        """prompt_hashes dict survives save_state / load_state round-trip."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.prompt_hashes = {"phase1": "abc123", "phase2": "def456"}

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.prompt_hashes == {"phase1": "abc123", "phase2": "def456"}

    def test_prompt_hashes_round_trip_empty(self, tmp_path: Path) -> None:
        """prompt_hashes={} survives save_state / load_state round-trip."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.prompt_hashes = {}

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.prompt_hashes == {}

    def test_missing_prompt_hashes_in_legacy_json_defaults_to_empty(self, tmp_path: Path) -> None:
        """Old 0.2.x state.json without prompt_hashes loads cleanly with default {}."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "single",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            # no "prompt_hashes" key — 0.2.x format
        }
        path.write_text(__import__("json").dumps(raw), encoding="utf-8")

        loaded = load_state(path)

        assert loaded.prompt_hashes == {}

    def test_legacy_02x_fixture_prompt_hashes_defaults_to_empty(self) -> None:
        """The shared 0.2.x fixture loads with prompt_hashes defaulting to {}."""
        fixture = Path(__file__).parent / "fixtures" / "state_legacy_02x.json"

        loaded = load_state(fixture)

        assert loaded.prompt_hashes == {}


class TestSdkVersionField:
    """Tests for State.sdk_version: str | None = None."""

    def test_sdk_version_defaults_to_none(self) -> None:
        """State.sdk_version defaults to None."""
        state = State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )

        assert state.sdk_version is None

    def test_sdk_version_round_trip_with_value(self, tmp_path: Path) -> None:
        """sdk_version string survives save_state / load_state round-trip."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.sdk_version = "0.5.3"

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.sdk_version == "0.5.3"

    def test_sdk_version_round_trip_none(self, tmp_path: Path) -> None:
        """sdk_version=None survives save_state / load_state round-trip."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.sdk_version = None

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.sdk_version is None

    def test_missing_sdk_version_in_legacy_json_defaults_to_none(self, tmp_path: Path) -> None:
        """Old 0.2.x state.json without sdk_version loads cleanly with default None."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "single",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            # no "sdk_version" key — 0.2.x format
        }
        path.write_text(__import__("json").dumps(raw), encoding="utf-8")

        loaded = load_state(path)

        assert loaded.sdk_version is None

    def test_legacy_02x_fixture_sdk_version_defaults_to_none(self) -> None:
        """The shared 0.2.x fixture loads with sdk_version defaulting to None."""
        fixture = Path(__file__).parent / "fixtures" / "state_legacy_02x.json"

        loaded = load_state(fixture)

        assert loaded.sdk_version is None


class TestCacheTelemetryField:
    """Tests for CycleState.cache_telemetry: dict[str, int | float]."""

    def test_cache_telemetry_defaults_to_canonical_dict(self) -> None:
        """CycleState.cache_telemetry defaults to the canonical telemetry dict."""
        cycle = _make_cycle()

        assert cycle.cache_telemetry == _DEFAULT_CACHE_TELEMETRY

    def test_cache_telemetry_has_correct_default_values(self) -> None:
        """Each key in the default cache_telemetry has the correct zero value."""
        cycle = _make_cycle()

        assert cycle.cache_telemetry["input"] == 0
        assert cycle.cache_telemetry["output"] == 0
        assert cycle.cache_telemetry["cache_read"] == 0
        assert cycle.cache_telemetry["cache_write"] == 0
        assert cycle.cache_telemetry["cache_hit_pct"] == 0.0
        assert cycle.cache_telemetry["wall_seconds"] == 0

    def test_cache_telemetry_default_factory_is_independent(self) -> None:
        """Each CycleState gets its own cache_telemetry dict (no shared mutable default)."""
        cycle_a = _make_cycle(1)
        cycle_b = _make_cycle(2)
        cycle_a.cache_telemetry["input"] = 999

        assert cycle_b.cache_telemetry["input"] == 0

    def test_cache_telemetry_round_trip(self, tmp_path: Path) -> None:
        """cache_telemetry dict survives save_state / load_state round-trip."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "multi-cycle"
        cycle = _make_cycle()
        cycle.cache_telemetry = {
            "input": 1500,
            "output": 300,
            "cache_read": 200,
            "cache_write": 50,
            "cache_hit_pct": 12.5,
            "wall_seconds": 42,
        }
        state.cycles = [cycle]

        save_state(path, state)
        loaded = load_state(path)

        ct = loaded.cycles[0].cache_telemetry
        assert ct["input"] == 1500
        assert ct["output"] == 300
        assert ct["cache_read"] == 200
        assert ct["cache_write"] == 50
        assert ct["cache_hit_pct"] == 12.5
        assert ct["wall_seconds"] == 42

    def test_missing_cache_telemetry_in_legacy_json_defaults_to_canonical(
        self, tmp_path: Path
    ) -> None:
        """Old state.json cycle dict without cache_telemetry loads with canonical defaults."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "multi-cycle",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "cycles": [
                {
                    "id": 1,
                    "name": "Cycle 1",
                    "milestone_number": None,
                    "milestone_title": "Cycle 1 — Foundation",
                    "status": "open",
                    "phase": 0,
                    "issues": [],
                    "commit_sha": None,
                    # no "cache_telemetry" — 0.2.x format
                }
            ],
        }
        path.write_text(__import__("json").dumps(raw), encoding="utf-8")

        loaded = load_state(path)

        assert loaded.cycles[0].cache_telemetry == _DEFAULT_CACHE_TELEMETRY

    def test_legacy_02x_fixture_cycle_cache_telemetry_defaults_to_canonical(self) -> None:
        """The shared 0.2.x fixture's cycles load with cache_telemetry defaulting to canonical."""
        fixture = Path(__file__).parent / "fixtures" / "state_legacy_02x.json"

        loaded = load_state(fixture)

        assert loaded.cycles[0].cache_telemetry == _DEFAULT_CACHE_TELEMETRY

    def test_cache_telemetry_rejects_string_value_raises_state_corrupted_error(
        self, tmp_path: Path
    ) -> None:
        """load_state raises StateCorruptedError when cache_telemetry contains a string value."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "multi-cycle",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "cycles": [
                {
                    "id": 1,
                    "name": "Cycle 1",
                    "milestone_number": None,
                    "milestone_title": "Cycle 1 — Foundation",
                    "status": "open",
                    "phase": 0,
                    "issues": [],
                    "commit_sha": None,
                    "cache_telemetry": {
                        "input": "not-a-number",
                        "output": 0,
                        "cache_read": 0,
                        "cache_write": 0,
                        "cache_hit_pct": 0.0,
                        "wall_seconds": 0,
                    },
                }
            ],
        }
        path.write_text(__import__("json").dumps(raw), encoding="utf-8")

        with pytest.raises(StateCorruptedError) as exc_info:
            load_state(path)

        err = exc_info.value
        assert "cache_telemetry" in err.location
        assert err.path == path

    def test_cache_telemetry_rejects_bool_value_raises_state_corrupted_error(
        self, tmp_path: Path
    ) -> None:
        """load_state raises StateCorruptedError when cache_telemetry contains a bool value.

        Python's isinstance(True, int) is True, so bool must be rejected explicitly.
        """
        path = tmp_path / "state.json"
        raw = {
            "mode": "multi-cycle",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "cycles": [
                {
                    "id": 1,
                    "name": "Cycle 1",
                    "milestone_number": None,
                    "milestone_title": "Cycle 1 — Foundation",
                    "status": "open",
                    "phase": 0,
                    "issues": [],
                    "commit_sha": None,
                    "cache_telemetry": {
                        "input": True,
                        "output": 0,
                        "cache_read": 0,
                        "cache_write": 0,
                        "cache_hit_pct": 0.0,
                        "wall_seconds": 0,
                    },
                }
            ],
        }
        path.write_text(__import__("json").dumps(raw), encoding="utf-8")

        with pytest.raises(StateCorruptedError) as exc_info:
            load_state(path)

        err = exc_info.value
        assert "cache_telemetry" in err.location
        assert err.path == path

    def test_cache_telemetry_rejects_non_dict_raises_state_corrupted_error(
        self, tmp_path: Path
    ) -> None:
        """load_state raises StateCorruptedError when cache_telemetry is not a dict."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "multi-cycle",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "cycles": [
                {
                    "id": 1,
                    "name": "Cycle 1",
                    "milestone_number": None,
                    "milestone_title": "Cycle 1 — Foundation",
                    "status": "open",
                    "phase": 0,
                    "issues": [],
                    "commit_sha": None,
                    "cache_telemetry": [1, 2, 3],
                }
            ],
        }
        path.write_text(__import__("json").dumps(raw), encoding="utf-8")

        with pytest.raises(StateCorruptedError) as exc_info:
            load_state(path)

        err = exc_info.value
        assert "cache_telemetry" in err.location
        assert err.path == path

    def test_cache_telemetry_accepts_int_and_float_values(self, tmp_path: Path) -> None:
        """load_state accepts cache_telemetry dicts with int and float values."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "multi-cycle",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "cycles": [
                {
                    "id": 1,
                    "name": "Cycle 1",
                    "milestone_number": None,
                    "milestone_title": "Cycle 1 — Foundation",
                    "status": "open",
                    "phase": 0,
                    "issues": [],
                    "commit_sha": None,
                    "cache_telemetry": {
                        "input": 100,
                        "output": 50,
                        "cache_read": 20,
                        "cache_write": 10,
                        "cache_hit_pct": 3.14,
                        "wall_seconds": 7,
                    },
                }
            ],
        }
        path.write_text(__import__("json").dumps(raw), encoding="utf-8")

        loaded = load_state(path)

        ct = loaded.cycles[0].cache_telemetry
        assert ct["input"] == 100
        assert ct["cache_hit_pct"] == 3.14


class TestIssueCommentsField:
    """Tests for IssueState.comments: str | None = None."""

    def test_issue_comments_defaults_to_none(self) -> None:
        """IssueState.comments defaults to None."""
        issue = _make_issue()

        assert issue.comments is None

    def test_issue_comments_round_trip_with_value(self, tmp_path: Path) -> None:
        """IssueState.comments string survives save_state / load_state round-trip."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "single"
        state.issues = [
            IssueState(number=1, status="open", agent="python-pro", comments="Phase 2 review OK"),
        ]

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.issues[0].comments == "Phase 2 review OK"

    def test_issue_comments_round_trip_none(self, tmp_path: Path) -> None:
        """IssueState.comments=None survives save_state / load_state round-trip."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "single"
        state.issues = [IssueState(number=1, status="open", agent="python-pro", comments=None)]

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.issues[0].comments is None

    def test_missing_comments_in_legacy_json_defaults_to_none(self, tmp_path: Path) -> None:
        """Old state.json issues without comments key load cleanly with default None."""
        path = tmp_path / "state.json"
        raw = {
            "mode": "single",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "issues": [
                {
                    "number": 5,
                    "status": "open",
                    "agent": "python-pro",
                    # no "comments" key — 0.2.x format
                }
            ],
        }
        path.write_text(__import__("json").dumps(raw), encoding="utf-8")

        loaded = load_state(path)

        assert loaded.issues[0].comments is None

    def test_legacy_02x_fixture_issue_comments_defaults_to_none(self) -> None:
        """The shared 0.2.x fixture's issues load with comments defaulting to None."""
        fixture = Path(__file__).parent / "fixtures" / "state_legacy_02x.json"

        loaded = load_state(fixture)

        assert loaded.cycles[0].issues[0].comments is None

    def test_comments_in_cycle_issues_round_trip(self, tmp_path: Path) -> None:
        """IssueState.comments inside CycleState survives save_state / load_state."""
        path = tmp_path / "state.json"
        state = load_state(path)
        state.mode = "multi-cycle"
        cycle = _make_cycle()
        cycle.issues = [
            IssueState(number=10, status="closed", agent="python-pro", comments="LGTM"),
        ]
        state.cycles = [cycle]

        save_state(path, state)
        loaded = load_state(path)

        assert loaded.cycles[0].issues[0].comments == "LGTM"


# ---------------------------------------------------------------------------
# Issue #155 — crash-recovery FSM hooks: client_alive_at write points
# ---------------------------------------------------------------------------


class TestUtcNowIsoformat:
    """Tests for utc_now_isoformat() deterministic formatting helper."""

    def test_returns_string(self) -> None:
        """utc_now_isoformat() returns a string."""
        from code_generator.state import utc_now_isoformat

        result = utc_now_isoformat()

        assert isinstance(result, str)

    def test_format_is_iso_with_seconds_precision(self) -> None:
        """utc_now_isoformat() produces ISO 8601 parseable string with seconds precision."""
        from datetime import datetime

        from code_generator.state import utc_now_isoformat

        result = utc_now_isoformat()
        parsed = datetime.fromisoformat(result)

        assert parsed.tzinfo is not None
        assert parsed.microsecond == 0

    def test_is_utc(self) -> None:
        """utc_now_isoformat() returns a UTC-aware timestamp."""
        from datetime import UTC, datetime

        from code_generator.state import utc_now_isoformat

        result = utc_now_isoformat()
        parsed = datetime.fromisoformat(result)
        now = datetime.now(tz=UTC)

        assert abs((now - parsed).total_seconds()) < 2


class TestMarkClientAlive:
    """Tests for mark_client_alive(state, state_path) helper."""

    def test_mark_sets_client_alive_at_field(self, tmp_path: Path) -> None:
        """mark_client_alive sets state.client_alive_at to a non-None ISO string."""
        from code_generator.state import mark_client_alive

        path = tmp_path / "state.json"
        state = load_state(path)

        mark_client_alive(state, path)

        assert state.client_alive_at is not None
        assert isinstance(state.client_alive_at, str)

    def test_mark_persists_to_disk(self, tmp_path: Path) -> None:
        """mark_client_alive atomically saves state so client_alive_at survives reload."""
        from code_generator.state import mark_client_alive

        path = tmp_path / "state.json"
        state = load_state(path)

        mark_client_alive(state, path)
        reloaded = load_state(path)

        assert reloaded.client_alive_at == state.client_alive_at

    def test_mark_written_timestamp_is_parseable_iso(self, tmp_path: Path) -> None:
        """mark_client_alive writes a parseable ISO timestamp to client_alive_at."""
        from datetime import datetime

        from code_generator.state import mark_client_alive

        path = tmp_path / "state.json"
        state = load_state(path)

        mark_client_alive(state, path)
        parsed = datetime.fromisoformat(state.client_alive_at)  # type: ignore[arg-type]

        assert parsed.tzinfo is not None


class TestClearClientAlive:
    """Tests for clear_client_alive(state, state_path) helper."""

    def test_clear_resets_client_alive_at_to_none(self, tmp_path: Path) -> None:
        """clear_client_alive sets state.client_alive_at back to None."""
        from code_generator.state import clear_client_alive, mark_client_alive

        path = tmp_path / "state.json"
        state = load_state(path)
        mark_client_alive(state, path)
        assert state.client_alive_at is not None

        clear_client_alive(state, path)

        assert state.client_alive_at is None

    def test_clear_persists_none_to_disk(self, tmp_path: Path) -> None:
        """clear_client_alive atomically saves state so client_alive_at=None survives reload."""
        from code_generator.state import clear_client_alive, mark_client_alive

        path = tmp_path / "state.json"
        state = load_state(path)
        mark_client_alive(state, path)

        clear_client_alive(state, path)
        reloaded = load_state(path)

        assert reloaded.client_alive_at is None


class TestIsClientPresumedAlive:
    """Tests for is_client_presumed_alive(state, now_utc=None, *, ttl_minutes=60) -> bool."""

    def _state_with_alive_at(self, iso_ts: str | None) -> State:
        state = State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        state.client_alive_at = iso_ts
        return state

    def test_returns_true_when_client_alive_at_is_59_minutes_ago(self) -> None:
        """is_client_presumed_alive returns True when client_alive_at is 59 min ago (< TTL)."""
        from datetime import UTC, datetime, timedelta

        from code_generator.state import is_client_presumed_alive

        now = datetime.now(tz=UTC)
        alive_at = (now - timedelta(minutes=59)).isoformat(timespec="seconds")
        state = self._state_with_alive_at(alive_at)

        assert is_client_presumed_alive(state, now_utc=now) is True

    def test_returns_false_when_client_alive_at_is_61_minutes_ago(self) -> None:
        """is_client_presumed_alive returns False when client_alive_at is 61 min ago (> TTL)."""
        from datetime import UTC, datetime, timedelta

        from code_generator.state import is_client_presumed_alive

        now = datetime.now(tz=UTC)
        alive_at = (now - timedelta(minutes=61)).isoformat(timespec="seconds")
        state = self._state_with_alive_at(alive_at)

        assert is_client_presumed_alive(state, now_utc=now) is False

    def test_returns_false_when_client_alive_at_is_none(self) -> None:
        """is_client_presumed_alive returns False when client_alive_at is None."""
        from code_generator.state import is_client_presumed_alive

        state = self._state_with_alive_at(None)

        assert is_client_presumed_alive(state) is False

    def test_raises_state_corrupted_error_for_invalid_iso_string(self) -> None:
        """is_client_presumed_alive raises StateCorruptedError when client_alive_at is not valid ISO."""
        from code_generator.state import is_client_presumed_alive

        state = self._state_with_alive_at("not-an-iso-timestamp")

        with pytest.raises(StateCorruptedError) as exc_info:
            is_client_presumed_alive(state)

        assert "client_alive_at" in exc_info.value.location

    def test_uses_real_utc_now_when_now_utc_is_not_provided(self) -> None:
        """is_client_presumed_alive uses current UTC when now_utc is omitted."""
        from datetime import UTC, datetime, timedelta

        from code_generator.state import is_client_presumed_alive

        # 30 minutes ago should always be within TTL
        alive_at = (datetime.now(tz=UTC) - timedelta(minutes=30)).isoformat(timespec="seconds")
        state = self._state_with_alive_at(alive_at)

        assert is_client_presumed_alive(state) is True

    def test_ttl_boundary_at_exactly_60_minutes_returns_false(self) -> None:
        """is_client_presumed_alive returns False when delta equals TTL (strict < used)."""
        from datetime import UTC, datetime, timedelta

        from code_generator.state import is_client_presumed_alive

        now = datetime.now(tz=UTC)
        alive_at = (now - timedelta(minutes=60)).isoformat(timespec="seconds")
        state = self._state_with_alive_at(alive_at)

        assert is_client_presumed_alive(state, now_utc=now) is False


class TestAssertSessionModeCompatible:
    """Tests for assert_session_mode_compatible(state, requested) guard."""

    def _state_with_mode(self, session_mode: str | None) -> State:
        state = State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        if session_mode is not None:
            state.session_mode = session_mode  # type: ignore[assignment]
        return state

    def test_raises_value_error_when_state_is_fresh_but_shared_requested(self) -> None:
        """assert_session_mode_compatible raises ValueError when state=fresh, requested=shared."""
        from code_generator.state import assert_session_mode_compatible

        state = self._state_with_mode("fresh")

        with pytest.raises(ValueError) as exc_info:
            assert_session_mode_compatible(state, "shared")

        assert str(exc_info.value) == (
            "State mode mismatch: state.json was written with --session-mode=fresh; "
            "re-run with that flag or clear state."
        )

    def test_returns_cleanly_when_both_shared(self) -> None:
        """assert_session_mode_compatible returns None when state=shared, requested=shared."""
        from code_generator.state import assert_session_mode_compatible

        state = self._state_with_mode("shared")

        result = assert_session_mode_compatible(state, "shared")

        assert result is None

    def test_returns_cleanly_when_both_fresh(self) -> None:
        """assert_session_mode_compatible returns None when state=fresh, requested=fresh."""
        from code_generator.state import assert_session_mode_compatible

        state = self._state_with_mode("fresh")

        result = assert_session_mode_compatible(state, "fresh")

        assert result is None

    def test_returns_cleanly_when_session_mode_is_none(self) -> None:
        """assert_session_mode_compatible returns None when state.session_mode is None (first run)."""
        from code_generator.state import assert_session_mode_compatible

        state = State(
            mode="unknown",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        state.session_mode = None  # type: ignore[assignment]

        result = assert_session_mode_compatible(state, "shared")

        assert result is None

    def test_error_message_matches_spec_byte_for_byte(self) -> None:
        """ValueError message from assert_session_mode_compatible must match §1 spec exactly."""
        from code_generator.state import assert_session_mode_compatible

        state = self._state_with_mode("fresh")
        expected = (
            "State mode mismatch: state.json was written with --session-mode=fresh; "
            "re-run with that flag or clear state."
        )

        with pytest.raises(ValueError) as exc_info:
            assert_session_mode_compatible(state, "shared")

        assert str(exc_info.value) == expected


# ---------------------------------------------------------------------------
# Tests for clear_comment_cache (issue #180)
# ---------------------------------------------------------------------------


class TestClearCommentCache:
    """clear_comment_cache must reset IssueState.comments to None on all issues."""

    def _make_state_with_comments(self):  # type: ignore[return]
        from code_generator import state as s

        st = s.State(
            mode="single",
            started_at="2026-01-01T00:00:00+00:00",
            updated_at="2026-01-01T00:00:00+00:00",
        )
        st.issues = [
            s.IssueState(number=1, status="open", agent="python-pro", comments="c1"),
            s.IssueState(number=2, status="closed", agent="python-pro", comments="c2"),
        ]
        cycle = s.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=1,
            milestone_title="Cycle 1",
            status="open",
            phase=2,
            issues=[
                s.IssueState(number=10, status="open", agent="python-pro", comments="c10"),
                s.IssueState(number=11, status="open", agent="python-pro", comments=None),
            ],
            commit_sha=None,
        )
        st.cycles = [cycle]
        return st

    def test_resets_all_single_mode_issues(self) -> None:
        from code_generator.state import clear_comment_cache

        state = self._make_state_with_comments()
        clear_comment_cache(state)

        for issue in state.issues:
            assert issue.comments is None, f"issue #{issue.number} comments not reset"

    def test_resets_all_cycle_issues(self) -> None:
        from code_generator.state import clear_comment_cache

        state = self._make_state_with_comments()
        clear_comment_cache(state)

        for cycle in state.cycles:
            for issue in cycle.issues:
                assert issue.comments is None, f"cycle issue #{issue.number} comments not reset"

    def test_already_none_stays_none(self) -> None:
        from code_generator.state import clear_comment_cache

        state = self._make_state_with_comments()
        state.issues.append(
            state.issues[0].__class__(number=99, status="open", agent="python-pro", comments=None)
        )
        clear_comment_cache(state)

        issue_99 = next(i for i in state.issues if i.number == 99)
        assert issue_99.comments is None

    def test_empty_state_does_not_raise(self) -> None:
        from code_generator import state as _state
        from code_generator.state import clear_comment_cache

        empty = _state.State(
            mode="single",
            started_at="2026-01-01T00:00:00+00:00",
            updated_at="2026-01-01T00:00:00+00:00",
        )
        clear_comment_cache(empty)  # Should not raise
