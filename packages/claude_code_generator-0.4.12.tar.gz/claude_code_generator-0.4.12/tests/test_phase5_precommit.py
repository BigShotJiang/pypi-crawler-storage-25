"""Tests for code_generator.orchestrator._phase5_precommit.

Tests follow TDD / Red-Green-Refactor and cover all acceptance criteria from
GitHub issue #186.
"""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_completed(
    returncode: int, stdout: str = "", stderr: str = ""
) -> subprocess.CompletedProcess:  # type: ignore[type-arg]
    cp = MagicMock(spec=subprocess.CompletedProcess)
    cp.returncode = returncode
    cp.stdout = stdout
    cp.stderr = stderr
    return cp


# ---------------------------------------------------------------------------
# Unit tests: run_ruff_check
# ---------------------------------------------------------------------------


class TestRunRuffCheck:
    """run_ruff_check returns (output, exit_code) from ruff check."""

    def test_returns_output_and_zero_on_clean(self) -> None:
        from code_generator.orchestrator._phase5_precommit import run_ruff_check

        with patch("subprocess.run", return_value=_make_completed(0, stdout="")) as mock_run:
            output, code = run_ruff_check(Path("/proj"))

        assert code == 0
        assert output == ""
        args = mock_run.call_args[0][0]
        assert "ruff" in args[0]
        assert "check" in args

    def test_returns_errors_and_nonzero_on_violations(self) -> None:
        from code_generator.orchestrator._phase5_precommit import run_ruff_check

        with patch("subprocess.run", return_value=_make_completed(1, stdout="src/foo.py:1:1 E501")):
            output, code = run_ruff_check(Path("/proj"))

        assert code == 1
        assert "E501" in output

    def test_missing_ruff_binary_returns_none(self) -> None:
        from code_generator.orchestrator._phase5_precommit import run_ruff_check

        with patch("subprocess.run", side_effect=FileNotFoundError):
            result = run_ruff_check(Path("/proj"))

        assert result is None


# ---------------------------------------------------------------------------
# Unit tests: run_ruff_format_check
# ---------------------------------------------------------------------------


class TestRunRuffFormatCheck:
    """run_ruff_format_check returns (output, exit_code) from ruff format --check."""

    def test_returns_empty_and_zero_when_formatted(self) -> None:
        from code_generator.orchestrator._phase5_precommit import run_ruff_format_check

        with patch("subprocess.run", return_value=_make_completed(0, stdout="")) as mock_run:
            output, code = run_ruff_format_check(Path("/proj"))

        assert code == 0
        assert output == ""
        args = mock_run.call_args[0][0]
        assert "--check" in args

    def test_returns_diff_and_nonzero_when_unformatted(self) -> None:
        from code_generator.orchestrator._phase5_precommit import run_ruff_format_check

        with patch("subprocess.run", return_value=_make_completed(1, stdout="Would reformat")):
            output, code = run_ruff_format_check(Path("/proj"))

        assert code == 1
        assert "reformat" in output

    def test_missing_ruff_binary_returns_none(self) -> None:
        from code_generator.orchestrator._phase5_precommit import run_ruff_format_check

        with patch("subprocess.run", side_effect=FileNotFoundError):
            result = run_ruff_format_check(Path("/proj"))

        assert result is None


# ---------------------------------------------------------------------------
# Unit tests: run_mypy_if_configured
# ---------------------------------------------------------------------------


class TestRunMypyIfConfigured:
    """run_mypy_if_configured runs mypy only when [tool.mypy] exists."""

    def test_skips_mypy_when_no_pyproject(self, tmp_path: Path) -> None:
        from code_generator.orchestrator._phase5_precommit import run_mypy_if_configured

        with patch("subprocess.run") as mock_run:
            result = run_mypy_if_configured(tmp_path)

        mock_run.assert_not_called()
        assert result is None

    def test_skips_mypy_when_pyproject_has_no_mypy_section(self, tmp_path: Path) -> None:
        from code_generator.orchestrator._phase5_precommit import run_mypy_if_configured

        (tmp_path / "pyproject.toml").write_text("[tool.ruff]\n", encoding="utf-8")

        with patch("subprocess.run") as mock_run:
            result = run_mypy_if_configured(tmp_path)

        mock_run.assert_not_called()
        assert result is None

    def test_runs_mypy_when_pyproject_has_mypy_section(self, tmp_path: Path) -> None:
        from code_generator.orchestrator._phase5_precommit import run_mypy_if_configured

        (tmp_path / "pyproject.toml").write_text("[tool.mypy]\nstrict = true\n", encoding="utf-8")

        with patch("subprocess.run", return_value=_make_completed(0, stdout="Success")):
            output, code = run_mypy_if_configured(tmp_path)

        assert code == 0

    def test_missing_mypy_binary_returns_none(self, tmp_path: Path) -> None:
        from code_generator.orchestrator._phase5_precommit import run_mypy_if_configured

        (tmp_path / "pyproject.toml").write_text("[tool.mypy]\n", encoding="utf-8")

        with patch("subprocess.run", side_effect=FileNotFoundError):
            result = run_mypy_if_configured(tmp_path)

        assert result is None


# ---------------------------------------------------------------------------
# Unit tests: collect_lint_errors (aggregator)
# ---------------------------------------------------------------------------


class TestCollectLintErrors:
    """collect_lint_errors aggregates all linter results."""

    def test_returns_empty_string_and_true_when_all_clean(self, tmp_path: Path) -> None:
        from code_generator.orchestrator._phase5_precommit import collect_lint_errors

        with (
            patch(
                "code_generator.orchestrator._phase5_precommit.run_ruff_check",
                return_value=("", 0),
            ),
            patch(
                "code_generator.orchestrator._phase5_precommit.run_ruff_format_check",
                return_value=("", 0),
            ),
            patch(
                "code_generator.orchestrator._phase5_precommit.run_mypy_if_configured",
                return_value=None,
            ),
        ):
            errors, is_clean = collect_lint_errors(tmp_path, logging.getLogger())

        assert is_clean is True
        assert errors == ""

    def test_returns_errors_and_false_when_ruff_fails(self, tmp_path: Path) -> None:
        from code_generator.orchestrator._phase5_precommit import collect_lint_errors

        with (
            patch(
                "code_generator.orchestrator._phase5_precommit.run_ruff_check",
                return_value=("E501 line too long", 1),
            ),
            patch(
                "code_generator.orchestrator._phase5_precommit.run_ruff_format_check",
                return_value=("", 0),
            ),
            patch(
                "code_generator.orchestrator._phase5_precommit.run_mypy_if_configured",
                return_value=None,
            ),
        ):
            errors, is_clean = collect_lint_errors(tmp_path, logging.getLogger())

        assert is_clean is False
        assert "E501" in errors

    def test_warns_and_continues_when_ruff_missing(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        from code_generator.orchestrator._phase5_precommit import collect_lint_errors

        with (
            patch(
                "code_generator.orchestrator._phase5_precommit.run_ruff_check",
                return_value=None,
            ),
            patch(
                "code_generator.orchestrator._phase5_precommit.run_ruff_format_check",
                return_value=None,
            ),
            patch(
                "code_generator.orchestrator._phase5_precommit.run_mypy_if_configured",
                return_value=("", 0),
            ),
        ):
            with caplog.at_level(logging.WARNING):
                errors, is_clean = collect_lint_errors(tmp_path, logging.getLogger("test"))

        assert any("ruff" in r.message.lower() for r in caplog.records)
        # mypy passed with exit 0 and no ruff ran — that's still clean
        assert is_clean is True

    def test_warns_and_continues_when_mypy_missing(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        from code_generator.orchestrator._phase5_precommit import collect_lint_errors

        with (
            patch(
                "code_generator.orchestrator._phase5_precommit.run_ruff_check",
                return_value=("", 0),
            ),
            patch(
                "code_generator.orchestrator._phase5_precommit.run_ruff_format_check",
                return_value=("", 0),
            ),
            patch(
                "code_generator.orchestrator._phase5_precommit.run_mypy_if_configured",
                return_value=None,
            ),
        ):
            # run_mypy_if_configured returning None when pyproject has [tool.mypy]
            # would trigger warning in run_mypy_if_configured, not collect_lint_errors.
            # Here: None means "not configured or binary missing", both are fine.
            with caplog.at_level(logging.WARNING):
                errors, is_clean = collect_lint_errors(tmp_path, logging.getLogger("test"))

        # No errors from ruff; mypy not configured → clean
        assert is_clean is True

    def test_truncates_large_output(self, tmp_path: Path) -> None:
        from code_generator.orchestrator._phase5_precommit import collect_lint_errors

        large_output = "E" * (50 * 1024)  # 50 KB

        with (
            patch(
                "code_generator.orchestrator._phase5_precommit.run_ruff_check",
                return_value=(large_output, 1),
            ),
            patch(
                "code_generator.orchestrator._phase5_precommit.run_ruff_format_check",
                return_value=("", 0),
            ),
            patch(
                "code_generator.orchestrator._phase5_precommit.run_mypy_if_configured",
                return_value=None,
            ),
        ):
            errors, is_clean = collect_lint_errors(tmp_path, logging.getLogger())

        assert is_clean is False
        # 5000 tokens * 4 chars = 20_000 chars max
        assert len(errors) <= 20_000 + 200  # allow marker overhead
        assert "truncated" in errors


# ---------------------------------------------------------------------------
# Unit tests: phase5_closure integration — skip-on-clean
# ---------------------------------------------------------------------------


class TestPhase5CleanSkip:
    """When all linters pass, Phase 5 must skip the SDK call entirely."""

    @pytest.mark.asyncio
    async def test_sdk_not_called_on_clean_run(self, tmp_path: Path) -> None:
        from unittest.mock import AsyncMock, patch

        from code_generator import state as _state
        from code_generator.orchestrator import phase5_closure
        from code_generator.repo_info import RepoInfo

        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True)
        st = _state.load_state(state_dir / "missing.json")
        st.repo = RepoInfo(host="github.com", owner="a", name="b")
        _state.save_state(state_dir / "state.json", st)

        mock_loop = AsyncMock()

        with (
            patch.object(phase5_closure.rate_limit, "main_loop", new=mock_loop),
            patch.object(phase5_closure.gh, "list_issues", return_value=[]),
            patch(
                "code_generator.orchestrator.phase5_closure.collect_lint_errors",
                return_value=("", True),
            ),
        ):
            result = await phase5_closure.run(
                st,
                None,
                tmp_path,
                runner_module=MagicMock(),
            )

        mock_loop.assert_not_called()
        assert isinstance(result, phase5_closure.FixResult)

    @pytest.mark.asyncio
    async def test_sdk_called_when_lint_errors_present(self, tmp_path: Path) -> None:
        from unittest.mock import AsyncMock, patch

        from code_generator import state as _state
        from code_generator.orchestrator import phase5_closure
        from code_generator.repo_info import RepoInfo
        from code_generator.runner.sdk_runner import RunResult

        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True)
        st = _state.load_state(state_dir / "missing.json")
        st.repo = RepoInfo(host="github.com", owner="a", name="b")
        _state.save_state(state_dir / "state.json", st)

        mock_result = RunResult(text="ok", session_id=None, tokens_in=0, tokens_out=0)
        mock_loop = AsyncMock(return_value=mock_result)

        with (
            patch.object(phase5_closure.rate_limit, "main_loop", new=mock_loop),
            patch.object(phase5_closure.gh, "list_issues", return_value=[]),
            patch(
                "code_generator.orchestrator.phase5_closure.collect_lint_errors",
                return_value=("E501 line too long in foo.py", False),
            ),
        ):
            result = await phase5_closure.run(
                st,
                None,
                tmp_path,
                runner_module=MagicMock(),
            )

        mock_loop.assert_called_once()
        # Verify LINT_ERRORS was injected in the prompt
        prompt_arg = mock_loop.call_args[0][1]
        assert "E501" in prompt_arg
        assert "Pre-Found Lint Errors" in prompt_arg
        assert isinstance(result, phase5_closure.FixResult)

    @pytest.mark.asyncio
    async def test_clean_run_logs_skip_message(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        from unittest.mock import AsyncMock, patch

        from code_generator import state as _state
        from code_generator.orchestrator import phase5_closure
        from code_generator.repo_info import RepoInfo

        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True)
        st = _state.load_state(state_dir / "missing.json")
        st.repo = RepoInfo(host="github.com", owner="a", name="b")
        _state.save_state(state_dir / "state.json", st)

        with (
            patch.object(phase5_closure.rate_limit, "main_loop", new=AsyncMock()),
            patch.object(phase5_closure.gh, "list_issues", return_value=[]),
            patch(
                "code_generator.orchestrator.phase5_closure.collect_lint_errors",
                return_value=("", True),
            ),
        ):
            import logging as _logging

            logger = _logging.getLogger("test_skip")
            with caplog.at_level(_logging.INFO, logger="test_skip"):
                await phase5_closure.run(
                    st,
                    None,
                    tmp_path,
                    runner_module=MagicMock(),
                    logger=logger,
                )

        skip_logged = any(
            "clean" in r.message.lower() and "skip" in r.message.lower() for r in caplog.records
        )
        assert skip_logged, f"Expected skip log, got: {[r.message for r in caplog.records]}"
