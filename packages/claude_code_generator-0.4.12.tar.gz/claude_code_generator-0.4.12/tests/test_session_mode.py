"""Tests for --session-mode {shared,fresh,batch} Typer flag on the generate command.

Acceptance criteria (issue #181 + issue #198):
- --help lists --session-mode with choices shared|fresh|batch and default shared.
- generate (no flag) sets State.session_mode = "shared" on fresh cycle start.
- generate --session-mode fresh sets State.session_mode = "fresh".
- generate --session-mode batch sets State.session_mode = "batch".
- --continue with mismatch → exit 2 with the exact message from state.py.
- --session-mode batch is now a valid choice (not an error).
- --continue without explicit flag inherits the stored session_mode silently.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

import pytest
from typer.testing import CliRunner

from code_generator import state as state_module
from code_generator.cli import app
from code_generator.env import DANGEROUS_VARS

if TYPE_CHECKING:
    from pathlib import Path

runner = CliRunner()

_MISMATCH_MESSAGE = (
    "State mode mismatch: state.json was written with --session-mode=fresh; "
    "re-run with that flag or clear state."
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _clear_env(monkeypatch: pytest.MonkeyPatch) -> None:
    for var in DANGEROUS_VARS:
        monkeypatch.delenv(var, raising=False)


@pytest.fixture(autouse=True)
def _mock_preflight(monkeypatch: pytest.MonkeyPatch) -> None:
    import code_generator.commands.generate as gen_mod
    from code_generator.repo_info import RepoInfo

    monkeypatch.setattr(
        gen_mod.preflight_module,
        "run_preflight",
        lambda _: RepoInfo(host="github.com", owner="test-owner", name="test-repo"),
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_cg_dir(tmp_path: Path, *, session_mode: str = "shared", mode: str = "single") -> Path:
    cg = tmp_path / ".code-generator"
    cg.mkdir(parents=True, exist_ok=True)
    st = state_module.State(
        mode=mode,  # type: ignore[arg-type]
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
        session_mode=session_mode,  # type: ignore[arg-type]
    )
    state_module.save_state(cg / "state.json", st)
    return cg


def _patch_all_phases(monkeypatch: pytest.MonkeyPatch) -> None:
    from code_generator.orchestrator import cycle_loop, phase0_complexity, phase1_plan

    async def _noop_phase0(state, project_dir, *, runner_module, logger=None, **kw):
        state.mode = "single"
        return state

    async def _noop_single(
        state,
        project_dir,
        *,
        runner_module,
        logger=None,
        start_phase=1,
        session_mode="shared",
        **kw,
    ):
        return state

    async def _noop_multi(
        state,
        project_dir,
        *,
        runner_module,
        logger=None,
        start_cycle=None,
        start_phase=1,
        session_mode="shared",
        **kw,
    ):
        return state

    async def _noop_phase1(*args, **kwargs):
        pass

    monkeypatch.setattr(phase0_complexity, "run", _noop_phase0)
    monkeypatch.setattr(cycle_loop, "run_single_mode", _noop_single)
    monkeypatch.setattr(cycle_loop, "run_multi_cycle", _noop_multi)
    monkeypatch.setattr(phase1_plan, "run", _noop_phase1)


# ---------------------------------------------------------------------------
# Flag visibility (--help)
# ---------------------------------------------------------------------------


class TestSessionModeFlagHelp:
    def test_help_lists_session_mode_flag(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--help output contains --session-mode so operators can discover it."""
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["generate", "--help"])
        assert result.exit_code == 0
        assert "--session-mode" in result.output

    def test_help_shows_shared_fresh_and_batch_choices(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--help enumerates the three valid choices: shared, fresh, and batch."""
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["generate", "--help"])
        assert result.exit_code == 0
        assert "shared" in result.output
        assert "fresh" in result.output
        assert "batch" in result.output


# ---------------------------------------------------------------------------
# State persistence on fresh run
# ---------------------------------------------------------------------------


class TestSessionModeStatePersistence:
    def test_default_persists_shared_to_state(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """generate (no --session-mode) writes session_mode='shared' to state.json."""
        monkeypatch.chdir(tmp_path)
        cg = _make_cg_dir(tmp_path)
        _patch_all_phases(monkeypatch)

        result = runner.invoke(app, ["generate"])

        assert result.exit_code == 0
        raw = json.loads((cg / "state.json").read_text())
        assert raw["session_mode"] == "shared"

    def test_fresh_flag_persists_fresh_to_state(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """generate --session-mode fresh writes session_mode='fresh' to state.json."""
        monkeypatch.chdir(tmp_path)
        cg = _make_cg_dir(tmp_path)
        _patch_all_phases(monkeypatch)

        result = runner.invoke(app, ["generate", "--session-mode", "fresh"])

        assert result.exit_code == 0
        raw = json.loads((cg / "state.json").read_text())
        assert raw["session_mode"] == "fresh"

    def test_shared_flag_persists_shared_to_state(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """generate --session-mode shared explicitly writes session_mode='shared'."""
        monkeypatch.chdir(tmp_path)
        cg = _make_cg_dir(tmp_path)
        _patch_all_phases(monkeypatch)

        result = runner.invoke(app, ["generate", "--session-mode", "shared"])

        assert result.exit_code == 0
        raw = json.loads((cg / "state.json").read_text())
        assert raw["session_mode"] == "shared"

    def test_batch_flag_persists_batch_to_state(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """generate --session-mode batch writes session_mode='batch' to state.json."""
        monkeypatch.chdir(tmp_path)
        cg = _make_cg_dir(tmp_path)
        _patch_all_phases(monkeypatch)

        result = runner.invoke(app, ["generate", "--session-mode", "batch"])

        assert result.exit_code == 0
        raw = json.loads((cg / "state.json").read_text())
        assert raw["session_mode"] == "batch"


# ---------------------------------------------------------------------------
# Typer choice validation
# ---------------------------------------------------------------------------


class TestSessionModeChoiceValidation:
    def test_invalid_choice_unknown_exits_2(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Any unknown --session-mode value triggers Typer validation error (exit 2)."""
        monkeypatch.chdir(tmp_path)
        _make_cg_dir(tmp_path)

        result = runner.invoke(app, ["generate", "--session-mode", "unknown-mode"])

        assert result.exit_code == 2


# ---------------------------------------------------------------------------
# --continue with session-mode mismatch
# ---------------------------------------------------------------------------


class TestSessionModeContinueMismatch:
    def test_continue_with_explicit_shared_when_state_has_fresh_exits_2(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--continue --session-mode shared when state has fresh exits 2 with mismatch message."""
        monkeypatch.chdir(tmp_path)
        _make_cg_dir(tmp_path, session_mode="fresh", mode="single")
        _patch_all_phases(monkeypatch)

        result = runner.invoke(app, ["generate", "--continue", "--session-mode", "shared"])

        assert result.exit_code == 2
        combined = (result.output or "") + (result.stderr or "")
        assert "State mode mismatch" in combined
        assert "--session-mode=fresh" in combined

    def test_continue_with_exact_mismatch_message_from_state_py(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """The error message matches the exact text defined in state.assert_session_mode_compatible."""
        monkeypatch.chdir(tmp_path)
        _make_cg_dir(tmp_path, session_mode="fresh", mode="single")
        _patch_all_phases(monkeypatch)

        result = runner.invoke(app, ["generate", "--continue", "--session-mode", "shared"])

        combined = (result.output or "") + (result.stderr or "")
        assert _MISMATCH_MESSAGE in combined

    def test_continue_without_explicit_flag_inherits_fresh_silently(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--continue without --session-mode inherits stored fresh mode without error."""
        monkeypatch.chdir(tmp_path)
        _make_cg_dir(tmp_path, session_mode="fresh", mode="single")
        _patch_all_phases(monkeypatch)

        result = runner.invoke(app, ["generate", "--continue"])

        assert result.exit_code == 0

    def test_continue_with_matching_fresh_flag_succeeds(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--continue --session-mode fresh when state has fresh is compatible → exit 0."""
        monkeypatch.chdir(tmp_path)
        _make_cg_dir(tmp_path, session_mode="fresh", mode="single")
        _patch_all_phases(monkeypatch)

        result = runner.invoke(app, ["generate", "--continue", "--session-mode", "fresh"])

        assert result.exit_code == 0

    def test_continue_with_fresh_when_state_has_shared_succeeds(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--continue --session-mode fresh when state has shared does not raise (one-way guard)."""
        monkeypatch.chdir(tmp_path)
        _make_cg_dir(tmp_path, session_mode="shared", mode="single")
        _patch_all_phases(monkeypatch)

        result = runner.invoke(app, ["generate", "--continue", "--session-mode", "fresh"])

        assert result.exit_code == 0
