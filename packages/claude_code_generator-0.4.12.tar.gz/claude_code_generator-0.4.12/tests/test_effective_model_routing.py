"""Tests for single-model Ollama routing through all 8 phases (issue #219).

TDD: Red → Green.

When a cycle is tagged with ``ollama_model``, every phase (0-7) must pass
that string as the ``model`` kwarg to ``make_agent_options``. The default
Anthropic Max per-phase assignments (Opus / Sonnet) must be preserved when
``ollama_model`` is ``None``.

The AC invariant "no Anthropic model string ever leaks on the Ollama
codepath" is enforced by a dedicated regression test that inspects every
captured call.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.runner.types import RunResult, TokenUsage

if TYPE_CHECKING:
    from pathlib import Path


# Anthropic model IDs that must never appear on the Ollama codepath.
_ANTHROPIC_MODEL_STRINGS = frozenset(
    {
        "claude-opus-4-7",
        "claude-sonnet-4-6",
        "claude-haiku-4-5-20251001",
    }
)

_OLLAMA_TAG = "qwen3-coder:480b:cloud"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _Capture:
    """Records every call to make_agent_options across the phases under test."""

    def __init__(self) -> None:
        self.calls: list[dict[str, Any]] = []

    def __call__(self, *args: Any, **kwargs: Any) -> MagicMock:
        self.calls.append(kwargs)
        opts = MagicMock()
        opts.model = kwargs.get("model")
        return opts

    @property
    def models(self) -> list[str]:
        return [c.get("model", "<missing>") for c in self.calls]


def _make_runner() -> MagicMock:
    """Fake runner returning an empty RunResult."""
    runner = MagicMock()
    runner.run = AsyncMock(
        return_value=RunResult(
            text='{"mode":"single","cycles":[]}', session_id=None, usage=TokenUsage()
        ),
    )
    return runner


def _make_state(tmp_path: Path) -> _state.State:
    st = _state.load_state(tmp_path / "missing.json")
    cg = tmp_path / ".code-generator"
    cg.mkdir(parents=True, exist_ok=True)
    (cg / "memories").mkdir(exist_ok=True)
    _state.save_state(cg / "state.json", st)
    return st


def _make_cycle_with_model(model: str | None) -> _state.CycleState:
    return _state.CycleState(
        id=1,
        name="c1",
        milestone_number=1,
        milestone_title="c1",
        status="open",
        phase=None,
        issues=[],
        commit_sha=None,
        ollama_model=model,
    )


# ---------------------------------------------------------------------------
# Per-phase table: (module_path, default_model)
# ---------------------------------------------------------------------------


_PHASE_MODULES: list[tuple[str, str]] = [
    ("code_generator.orchestrator.phase0_complexity", "claude-opus-4-7"),
    ("code_generator.orchestrator.phase1_plan", "claude-opus-4-7"),
    ("code_generator.orchestrator.phase2_review", "claude-opus-4-7"),
    ("code_generator.orchestrator.phase3_4_implement", "claude-sonnet-4-6"),
    ("code_generator.orchestrator.phase5_closure", "claude-opus-4-7"),
    ("code_generator.orchestrator.phase6_test", "claude-sonnet-4-6"),
    ("code_generator.orchestrator.phase7_commit", "claude-opus-4-7"),
]


# ---------------------------------------------------------------------------
# Each phase accepts ``effective_model`` kwarg
# ---------------------------------------------------------------------------


class TestPhaseSignatureAcceptsEffectiveModel:
    @pytest.mark.parametrize(("module_path", "_default"), _PHASE_MODULES)
    def test_phase_run_signature_has_effective_model_kwarg(
        self, module_path: str, _default: str
    ) -> None:
        """Every phase's ``run()`` accepts the ``effective_model`` keyword."""
        import importlib
        import inspect

        mod = importlib.import_module(module_path)
        sig = inspect.signature(mod.run)
        assert "effective_model" in sig.parameters, (
            f"{module_path}.run must accept an effective_model kwarg"
        )


# ---------------------------------------------------------------------------
# Cycle-loop threads effective_model to each phase
# ---------------------------------------------------------------------------


class TestCycleLoopResolvesEffectiveModel:
    @pytest.mark.asyncio
    async def test_cycle_loop_passes_cycle_ollama_model_to_each_phase(self, tmp_path: Path) -> None:
        """_run_phases reads cycle.ollama_model and forwards to each phase.run()."""
        from code_generator.orchestrator import cycle_loop

        captured: dict[str, Any] = {}

        async def _record(phase_name: str) -> Any:
            async def _fake(*args: Any, **kwargs: Any) -> Any:
                captured.setdefault(phase_name, []).append(kwargs.get("effective_model"))
                return MagicMock(new_issues=[]) if phase_name == "phase5" else None

            return _fake

        state = _make_state(tmp_path)
        cycle = _make_cycle_with_model(_OLLAMA_TAG)
        state.cycles = [cycle]

        with (
            patch.object(cycle_loop.phase1_plan, "run", new=await _record("phase1")),
            patch.object(cycle_loop.phase2_review, "run", new=await _record("phase2")),
            patch.object(cycle_loop.phase3_4_implement, "run", new=await _record("phase3_4")),
            patch.object(cycle_loop.phase5_closure, "run", new=await _record("phase5")),
            patch.object(cycle_loop.phase6_test, "run", new=await _record("phase6")),
            patch.object(cycle_loop.phase7_commit, "run", new=await _record("phase7")),
            patch.object(cycle_loop, "_compute_and_persist_repomap", lambda *a, **k: None),
            patch.object(cycle_loop, "reset_cycle_summary", lambda *a, **k: None),
            patch.object(cycle_loop, "write_project_plan", lambda *a, **k: None),
            patch.object(cycle_loop, "append_cycle_summaries", lambda *a, **k: None),
            patch.object(cycle_loop, "populate_cycle_start_fields", lambda *a, **k: None),
            patch.object(_state, "get_issues", lambda *a, **k: []),
            patch.object(cycle_loop, "_capture_base_commit", lambda *a, **k: None),
        ):
            await cycle_loop._run_phases(
                state=state,
                cycle=cycle,
                project_dir=tmp_path,
                runner_module=_make_runner(),
                log_prefix="",
                start_phase=1,
            )

        for phase_name in ("phase1", "phase2", "phase3_4", "phase5", "phase6", "phase7"):
            assert phase_name in captured, f"{phase_name} not invoked"
            assert captured[phase_name][0] == _OLLAMA_TAG, (
                f"{phase_name}: expected effective_model={_OLLAMA_TAG}, "
                f"got {captured[phase_name][0]}"
            )

    @pytest.mark.asyncio
    async def test_cycle_loop_passes_none_when_no_ollama_model(self, tmp_path: Path) -> None:
        """When cycle.ollama_model is None, effective_model=None is forwarded."""
        from code_generator.orchestrator import cycle_loop

        seen: list[str | None] = []

        async def _record(*args: Any, **kwargs: Any) -> Any:
            seen.append(kwargs.get("effective_model"))
            return MagicMock(new_issues=[])

        state = _make_state(tmp_path)
        cycle = _make_cycle_with_model(None)
        state.cycles = [cycle]

        with (
            patch.object(cycle_loop.phase1_plan, "run", new=_record),
            patch.object(cycle_loop.phase2_review, "run", new=_record),
            patch.object(cycle_loop.phase3_4_implement, "run", new=_record),
            patch.object(cycle_loop.phase5_closure, "run", new=_record),
            patch.object(cycle_loop.phase6_test, "run", new=_record),
            patch.object(cycle_loop.phase7_commit, "run", new=_record),
            patch.object(cycle_loop, "_compute_and_persist_repomap", lambda *a, **k: None),
            patch.object(cycle_loop, "reset_cycle_summary", lambda *a, **k: None),
            patch.object(cycle_loop, "write_project_plan", lambda *a, **k: None),
            patch.object(cycle_loop, "append_cycle_summaries", lambda *a, **k: None),
            patch.object(cycle_loop, "populate_cycle_start_fields", lambda *a, **k: None),
            patch.object(_state, "get_issues", lambda *a, **k: []),
            patch.object(cycle_loop, "_capture_base_commit", lambda *a, **k: None),
        ):
            await cycle_loop._run_phases(
                state=state,
                cycle=cycle,
                project_dir=tmp_path,
                runner_module=_make_runner(),
                log_prefix="",
                start_phase=1,
            )

        assert seen, "expected at least one phase to run"
        assert all(v is None for v in seen), f"expected all None, got {seen}"


# ---------------------------------------------------------------------------
# Regression: Anthropic Max path keeps per-phase defaults when effective_model=None
# ---------------------------------------------------------------------------


class TestAnthropicMaxRegression:
    @pytest.mark.parametrize(("module_path", "default_model"), _PHASE_MODULES)
    def test_phase_default_model_constant_still_exported(
        self, module_path: str, default_model: str
    ) -> None:
        """Each phase still hard-codes the Anthropic Max default as a source-level string.

        Grepping the source file is a robust check that works regardless of
        whether the constant was extracted to a module-level variable.
        """
        import importlib

        mod = importlib.import_module(module_path)
        from pathlib import Path as _P

        source = _P(mod.__file__).read_text(encoding="utf-8")
        assert default_model in source, (
            f"{module_path} no longer references the default model {default_model!r} — "
            "the Anthropic Max path regression would break."
        )


# ---------------------------------------------------------------------------
# No Anthropic-model-string leak on Ollama codepath (whole-orchestrator test)
# ---------------------------------------------------------------------------


class TestNoAnthropicLeakOnOllamaPath:
    @pytest.mark.parametrize(("module_path", "_default"), _PHASE_MODULES)
    def test_make_agent_options_receives_ollama_tag(self, module_path: str, _default: str) -> None:
        """When a phase is called with effective_model=<tag>, model=<tag> is forwarded.

        Detects any phase that forgets to wire its ``effective_model`` param
        into the ``make_agent_options(model=...)`` call.
        """
        import importlib

        mod = importlib.import_module(module_path)
        from pathlib import Path as _P

        source = _P(mod.__file__).read_text(encoding="utf-8")
        # Every phase that hard-codes a model now wraps it with the effective_model
        # fall-through expression. A plain literal like ``model="claude-opus-4-7"``
        # without the fall-through pattern would be a regression.
        for anthropic_model in _ANTHROPIC_MODEL_STRINGS:
            if anthropic_model in source:
                # The file must reference effective_model at least as many times
                # as it references any Anthropic literal (otherwise the literal
                # is used unconditionally and would leak on the Ollama path).
                assert "effective_model" in source, (
                    f"{module_path} references {anthropic_model!r} but does not "
                    "read effective_model — this leaks the Anthropic model on "
                    "the Ollama codepath."
                )
