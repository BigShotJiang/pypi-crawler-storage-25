"""Tests for runner/_telemetry.py — Issue #190.

Validates cache_telemetry accumulation, cache_hit_pct computation,
state round-trip, and legacy-state backward compatibility.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from code_generator.runner._telemetry import accumulate_telemetry
from code_generator.runner.types import TokenUsage
from code_generator.state import (
    CycleState,
    _default_cache_telemetry,
    load_state,
    save_state,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_cycle(cycle_id: int = 1) -> CycleState:
    return CycleState(
        id=cycle_id,
        name="Test Cycle",
        milestone_number=1,
        milestone_title="Test",
        status="in_progress",
        phase=4,
        issues=[],
        commit_sha=None,
    )


# ---------------------------------------------------------------------------
# accumulate_telemetry — pure function tests
# ---------------------------------------------------------------------------


class TestAccumulateTelemetry:
    def test_three_usage_blocks_sum_exactly(self) -> None:
        """Fake runner emits 3 usage blocks in one cycle — sums match exactly, cache_hit_pct correct."""
        telemetry = _default_cache_telemetry()

        accumulate_telemetry(
            telemetry,
            TokenUsage(input=100, output=50, cache_read=200, cache_write=80),
            1.0,
        )
        accumulate_telemetry(
            telemetry,
            TokenUsage(input=150, output=70, cache_read=300, cache_write=60),
            2.0,
        )
        accumulate_telemetry(
            telemetry,
            TokenUsage(input=200, output=90, cache_read=100, cache_write=40),
            0.5,
        )

        assert telemetry["input"] == 450
        assert telemetry["output"] == 210
        assert telemetry["cache_read"] == 600
        assert telemetry["cache_write"] == 180
        assert telemetry["wall_seconds"] == pytest.approx(3.5)
        # cache_hit_pct = 600 / (600 + 180 + 450) * 100 = 600/1230 * 100 ≈ 48.780... → 48.8
        assert telemetry["cache_hit_pct"] == 48.8

    def test_zero_sdk_activity_leaves_defaults_without_division_by_zero(self) -> None:
        """A cycle with zero SDK activity keeps cache_telemetry at defaults; no division-by-zero."""
        telemetry = _default_cache_telemetry()

        # No accumulate_telemetry calls — telemetry stays at factory defaults.
        assert telemetry["input"] == 0
        assert telemetry["output"] == 0
        assert telemetry["cache_read"] == 0
        assert telemetry["cache_write"] == 0
        assert telemetry["cache_hit_pct"] == 0.0
        assert telemetry["wall_seconds"] == 0

    def test_zero_denominator_guard_on_explicit_empty_usage(self) -> None:
        """When a run reports all-zero token counts, accumulate_telemetry does not divide by zero."""
        telemetry = _default_cache_telemetry()
        accumulate_telemetry(
            telemetry,
            TokenUsage(input=0, output=0, cache_read=0, cache_write=0),
            1.0,
        )
        assert telemetry["cache_hit_pct"] == 0.0
        assert telemetry["wall_seconds"] == pytest.approx(1.0)

    def test_cache_hit_pct_stored_as_percentage_not_ratio(self) -> None:
        """cache_hit_pct stores a percent value (0–100), not a raw ratio (0–1)."""
        telemetry = _default_cache_telemetry()
        # With 100% cache hits: cache_read=100, input=0, cache_write=0
        accumulate_telemetry(
            telemetry,
            TokenUsage(input=0, output=0, cache_read=100, cache_write=0),
            0.5,
        )
        assert telemetry["cache_hit_pct"] == 100.0

    def test_cache_hit_pct_rounds_to_one_decimal(self) -> None:
        """cache_hit_pct is rounded to exactly one decimal place."""
        telemetry = _default_cache_telemetry()
        # cache_read=1, cache_write=1, input=1 → 1/(1+1+1)*100 = 33.333… → 33.3
        accumulate_telemetry(
            telemetry,
            TokenUsage(input=1, output=0, cache_read=1, cache_write=1),
            0.0,
        )
        assert telemetry["cache_hit_pct"] == 33.3

    def test_wall_seconds_accumulates_across_calls(self) -> None:
        """wall_seconds adds up correctly across multiple calls."""
        telemetry = _default_cache_telemetry()
        accumulate_telemetry(telemetry, TokenUsage(input=10), 1.25)
        accumulate_telemetry(telemetry, TokenUsage(input=10), 2.75)
        assert telemetry["wall_seconds"] == pytest.approx(4.0)


# ---------------------------------------------------------------------------
# State round-trip
# ---------------------------------------------------------------------------


class TestCacheTelemetryRoundTrip:
    def test_round_trip_preserves_all_six_keys_including_float(self, tmp_path: Path) -> None:
        """Round-trip through save/load preserves all 6 keys, including float cache_hit_pct."""
        state = load_state(tmp_path / "state.json")
        state.mode = "multi-cycle"
        cycle = _make_cycle()
        cycle.cache_telemetry = {
            "input": 450,
            "output": 210,
            "cache_read": 600,
            "cache_write": 180,
            "cache_hit_pct": 48.8,
            "wall_seconds": 3.5,
        }
        state.cycles = [cycle]

        save_state(tmp_path / "state.json", state)
        loaded = load_state(tmp_path / "state.json")

        ct = loaded.cycles[0].cache_telemetry
        assert ct["input"] == 450
        assert ct["output"] == 210
        assert ct["cache_read"] == 600
        assert ct["cache_write"] == 180
        assert ct["cache_hit_pct"] == 48.8
        assert ct["wall_seconds"] == pytest.approx(3.5)

    def test_legacy_state_without_cache_telemetry_loads_with_defaults(self, tmp_path: Path) -> None:
        """0.2.x state.json without cache_telemetry loads cleanly, all 6 keys default to zero."""
        legacy = {
            "mode": "multi-cycle",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "cycles": [
                {
                    "id": 1,
                    "name": "Legacy Cycle",
                    "milestone_number": 1,
                    "milestone_title": "Legacy",
                    "status": "in_progress",
                    "phase": 3,
                    "issues": [],
                    "commit_sha": None,
                    # Intentionally no "cache_telemetry" key — simulates 0.2.x state.
                }
            ],
        }
        path = tmp_path / "state.json"
        path.write_text(json.dumps(legacy), encoding="utf-8")

        state = load_state(path)

        ct = state.cycles[0].cache_telemetry
        assert ct == {
            "input": 0,
            "output": 0,
            "cache_read": 0,
            "cache_write": 0,
            "cache_hit_pct": 0.0,
            "wall_seconds": 0,
        }
