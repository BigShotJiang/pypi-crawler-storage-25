"""Tests for the opt-in ``--max-turns`` CLI flag (issue #210).

The flag is an operator-only escape hatch: when omitted no SDK call site sets
``max_turns`` (per the no-default-turn-budget invariant from requirements §1);
when set, the value is threaded through dispatch → cycle-loop → every phase
module and forwarded to ``make_agent_options()``.  Invalid values (0 or
negative) fail fast at the Typer layer before any SDK call.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from typer.testing import CliRunner

from code_generator.cli import app
from code_generator.env import DANGEROUS_VARS
from code_generator.runner.types import RunResult, TokenUsage

if TYPE_CHECKING:
    from pathlib import Path

_runner = CliRunner()


# ---------------------------------------------------------------------------
# Shared fixtures — mirror the sibling test_optimize / test_review setup
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _clear_dangerous_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Strip API-key env vars so the safety check does not fire."""
    for var in DANGEROUS_VARS:
        monkeypatch.delenv(var, raising=False)


def _make_result(text: str = "done") -> RunResult:
    return RunResult(
        text=text,
        session_id="sess-max-turns",
        usage=TokenUsage(input=10, output=20),
    )


def _fake_runner_module() -> MagicMock:
    module = MagicMock()
    module.run = AsyncMock(return_value=_make_result())
    return module


_NONCANONICAL_REQUIREMENTS = """\
# My Project

## Description
Build something cool.

## Tech Stack
Python.

## Goals
- Ship.

## Scope

### 1. Auth
Allow users to log in.

## Non-goals
- Mobile apps.

## Global acceptance criteria
- [ ] All tests pass.
"""


def _setup_optimize_tmp(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    cg = tmp_path / ".code-generator"
    cg.mkdir(parents=True, exist_ok=True)
    (cg / "requirements.md").write_text(_NONCANONICAL_REQUIREMENTS, encoding="utf-8")


# ---------------------------------------------------------------------------
# optimize — CliRunner threading tests
# ---------------------------------------------------------------------------


class TestOptimizeMaxTurnsFlag:
    def test_no_flag_omits_max_turns_kwarg(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``optimize`` (no flag) → make_agent_options() not called with max_turns."""
        _setup_optimize_tmp(tmp_path, monkeypatch)
        fake_runner = _fake_runner_module()

        with (
            patch("code_generator.commands.optimize.get_runner", return_value=fake_runner),
            patch("code_generator.commands.optimize.make_agent_options") as mock_opts,
        ):
            mock_opts.return_value = MagicMock()
            result = _runner.invoke(app, ["optimize"])

        assert result.exit_code == 0, result.output
        assert mock_opts.called
        assert "max_turns" not in mock_opts.call_args.kwargs

    def test_with_flag_forwards_max_turns_to_make_agent_options(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``optimize --max-turns 50`` → make_agent_options called with max_turns=50."""
        _setup_optimize_tmp(tmp_path, monkeypatch)
        fake_runner = _fake_runner_module()

        with (
            patch("code_generator.commands.optimize.get_runner", return_value=fake_runner),
            patch("code_generator.commands.optimize.make_agent_options") as mock_opts,
        ):
            mock_opts.return_value = MagicMock()
            result = _runner.invoke(app, ["optimize", "--max-turns", "50"])

        assert result.exit_code == 0, result.output
        assert mock_opts.call_args.kwargs.get("max_turns") == 50

    def test_zero_is_rejected_by_typer_validator(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``optimize --max-turns 0`` → non-zero exit via typer.BadParameter."""
        _setup_optimize_tmp(tmp_path, monkeypatch)

        with patch("code_generator.commands.optimize.make_agent_options") as mock_opts:
            result = _runner.invoke(app, ["optimize", "--max-turns", "0"])

        assert result.exit_code != 0
        assert not mock_opts.called, "validator must run before any SDK call"

    def test_negative_is_rejected_by_typer_validator(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``optimize --max-turns -5`` → non-zero exit via typer.BadParameter."""
        _setup_optimize_tmp(tmp_path, monkeypatch)

        with patch("code_generator.commands.optimize.make_agent_options") as mock_opts:
            result = _runner.invoke(app, ["optimize", "--max-turns", "-5"])

        assert result.exit_code != 0
        assert not mock_opts.called


# ---------------------------------------------------------------------------
# review — CliRunner threading tests
# ---------------------------------------------------------------------------


class TestReviewMaxTurnsFlag:
    def test_no_flag_omits_max_turns_kwarg(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``review`` (no flag) → make_agent_options() not called with max_turns."""
        monkeypatch.chdir(tmp_path)
        fake_runner = _fake_runner_module()

        with (
            patch("code_generator.commands.review.get_runner", return_value=fake_runner),
            patch("code_generator.commands.review.make_agent_options") as mock_opts,
        ):
            mock_opts.return_value = MagicMock()
            result = _runner.invoke(app, ["review"])

        assert result.exit_code == 0, result.output
        assert mock_opts.called
        assert "max_turns" not in mock_opts.call_args.kwargs

    def test_with_flag_forwards_max_turns_to_make_agent_options(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``review --max-turns 100`` → make_agent_options called with max_turns=100."""
        monkeypatch.chdir(tmp_path)
        fake_runner = _fake_runner_module()

        with (
            patch("code_generator.commands.review.get_runner", return_value=fake_runner),
            patch("code_generator.commands.review.make_agent_options") as mock_opts,
        ):
            mock_opts.return_value = MagicMock()
            result = _runner.invoke(app, ["review", "--max-turns", "100"])

        assert result.exit_code == 0, result.output
        assert mock_opts.call_args.kwargs.get("max_turns") == 100

    def test_zero_is_rejected(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        """``review --max-turns 0`` → non-zero exit via typer.BadParameter."""
        monkeypatch.chdir(tmp_path)
        with patch("code_generator.commands.review.make_agent_options") as mock_opts:
            result = _runner.invoke(app, ["review", "--max-turns", "0"])
        assert result.exit_code != 0
        assert not mock_opts.called

    def test_negative_is_rejected(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        """``review --max-turns -2`` → non-zero exit via typer.BadParameter."""
        monkeypatch.chdir(tmp_path)
        with patch("code_generator.commands.review.make_agent_options") as mock_opts:
            result = _runner.invoke(app, ["review", "--max-turns", "-2"])
        assert result.exit_code != 0
        assert not mock_opts.called


# ---------------------------------------------------------------------------
# generate — validation + fail-fast (full threading is covered by the
# dispatch-layer and per-phase-module tests below)
# ---------------------------------------------------------------------------


def _setup_generate_tmp(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Create a minimal .code-generator directory for the generate command."""
    monkeypatch.chdir(tmp_path)
    cg = tmp_path / ".code-generator"
    cg.mkdir(parents=True, exist_ok=True)


class TestGenerateMaxTurnsFlag:
    def test_zero_is_rejected_before_sdk_call(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``generate --max-turns 0`` exits non-zero *before* the dispatch layer runs."""
        _setup_generate_tmp(tmp_path, monkeypatch)

        with patch("code_generator.commands.generate.dispatch_orchestrator") as mock_dispatch:
            result = _runner.invoke(app, ["generate", "--max-turns", "0"])

        assert result.exit_code != 0
        assert not mock_dispatch.called, "validator must fire before dispatch"

    def test_negative_is_rejected_before_sdk_call(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``generate --max-turns -1`` exits non-zero *before* the dispatch layer runs."""
        _setup_generate_tmp(tmp_path, monkeypatch)

        with patch("code_generator.commands.generate.dispatch_orchestrator") as mock_dispatch:
            result = _runner.invoke(app, ["generate", "--max-turns", "-1"])

        assert result.exit_code != 0
        assert not mock_dispatch.called


# ---------------------------------------------------------------------------
# Threading tests — dispatch / cycle-loop → phase modules
# ---------------------------------------------------------------------------


class TestDispatchThreading:
    """``dispatch_orchestrator`` must thread ``max_turns`` all the way through."""

    def test_dispatch_orchestrator_forwards_max_turns_to_dispatch_async(
        self, tmp_path: Path
    ) -> None:
        """The sync entry point threads max_turns into the asyncio.run target."""
        from code_generator import state as _state_module
        from code_generator.commands import _dispatch

        state_path = tmp_path / "state.json"
        st = _state_module.State(
            mode="single",
            started_at=_state_module.utc_now(),
            updated_at=_state_module.utc_now(),
        )
        _state_module.save_state(state_path, st)

        captured_kwargs: list[dict[str, Any]] = []

        async def fake_async(st: Any, project_dir: Any, **kwargs: Any) -> None:
            captured_kwargs.append(kwargs)

        with patch.object(_dispatch, "dispatch_async", side_effect=fake_async):
            _dispatch.dispatch_orchestrator(
                st,
                tmp_path,
                dry_run=False,
                phase=None,
                continue_=False,
                mode="single",
                cycle=None,
                state_path=state_path,
                requirements_hash=None,
                session_mode="fresh",
                session_mode_explicit=False,
                max_turns=200,
            )

        assert captured_kwargs, "dispatch_async was not called"
        assert captured_kwargs[0].get("max_turns") == 200

    @pytest.mark.asyncio
    async def test_dispatch_async_forwards_max_turns_to_run_single_mode(
        self, tmp_path: Path
    ) -> None:
        """max_turns reaches ``cycle_loop.run_single_mode`` intact."""
        from code_generator import state as _state_module
        from code_generator.commands import _dispatch
        from code_generator.orchestrator import cycle_loop

        st = _state_module.State(
            mode="single",
            started_at=_state_module.utc_now(),
            updated_at=_state_module.utc_now(),
        )

        captured: list[dict[str, Any]] = []

        async def fake_run_single_mode(state: Any, project_dir: Any, **kwargs: Any) -> Any:
            captured.append(kwargs)
            return state

        with (
            patch.object(cycle_loop, "run_single_mode", side_effect=fake_run_single_mode),
            patch("code_generator.runner.get_runner", return_value=MagicMock()),
        ):
            await _dispatch.dispatch_async(
                st,
                tmp_path,
                dry_run=False,
                start_phase=1,
                start_cycle=None,
                mode="single",
                session_mode="fresh",
                max_turns=200,
            )

        assert captured, "run_single_mode was not invoked"
        assert captured[0].get("max_turns") == 200


# ---------------------------------------------------------------------------
# Per-phase helpers — every phase that calls make_agent_options must forward
# ``max_turns`` when set and omit the kwarg when None.
# ---------------------------------------------------------------------------


class TestPhaseModuleThreading:
    """Each phase's run(max_turns=N) must propagate N into make_agent_options."""

    @pytest.mark.asyncio
    async def test_phase0_threads_max_turns_when_set(self, tmp_path: Path) -> None:
        import logging

        from code_generator import state as _state_module
        from code_generator.orchestrator import phase0_complexity

        st = _state_module.State(
            mode="unknown",
            started_at=_state_module.utc_now(),
            updated_at=_state_module.utc_now(),
        )
        captured: list[dict[str, Any]] = []

        def capture_opts(**kwargs: Any) -> Any:
            captured.append(kwargs)
            return MagicMock()

        async def fake_main_loop(*args: Any, **kwargs: Any) -> Any:
            return RunResult(
                text='{"mode": "single", "cycles": []}',
                session_id=None,
                usage=TokenUsage(),
            )

        with (
            patch.object(phase0_complexity, "make_agent_options", side_effect=capture_opts),
            patch.object(phase0_complexity.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase0_complexity.run(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test.p0"),
                max_turns=200,
            )

        assert captured and captured[0].get("max_turns") == 200

    @pytest.mark.asyncio
    async def test_phase0_omits_max_turns_when_none(self, tmp_path: Path) -> None:
        import logging

        from code_generator import state as _state_module
        from code_generator.orchestrator import phase0_complexity

        st = _state_module.State(
            mode="unknown",
            started_at=_state_module.utc_now(),
            updated_at=_state_module.utc_now(),
        )
        captured: list[dict[str, Any]] = []

        def capture_opts(**kwargs: Any) -> Any:
            captured.append(kwargs)
            return MagicMock()

        async def fake_main_loop(*args: Any, **kwargs: Any) -> Any:
            return RunResult(
                text='{"mode": "single", "cycles": []}',
                session_id=None,
                usage=TokenUsage(),
            )

        with (
            patch.object(phase0_complexity, "make_agent_options", side_effect=capture_opts),
            patch.object(phase0_complexity.rate_limit, "main_loop", side_effect=fake_main_loop),
        ):
            await phase0_complexity.run(
                st,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test.p0.none"),
            )

        assert captured and "max_turns" not in captured[0]
