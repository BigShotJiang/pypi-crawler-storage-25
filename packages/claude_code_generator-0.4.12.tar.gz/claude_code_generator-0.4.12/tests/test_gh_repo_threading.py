"""Argv-capture tests verifying RepoInfo threading through every gh wrapper.

Each wrapper must:
- For non-api subcommands (gh issue/label): include ``--repo owner/name`` in
  argv AND set ``GH_HOST=host`` in the subprocess environment.
- For api subcommands (gh api): include ``--hostname host`` in argv.

Reference: issue #152 acceptance criteria + reviewer clarification comment.
"""

from __future__ import annotations

import json

from code_generator.gh.core import reset_runner, set_runner
from code_generator.repo_info import RepoInfo

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

_REPO = RepoInfo(host="github.example.com", owner="acme", name="myrepo")


class CapturingRunner:
    """Captures (argv, env) for every call so tests can assert exact flags."""

    def __init__(self, return_value: str = "") -> None:
        self.calls: list[tuple[list[str], dict[str, str] | None]] = []
        self._return_value = return_value

    def run(
        self,
        argv: list[str],
        *,
        input: str | None = None,  # noqa: A002
        env: dict[str, str] | None = None,
    ) -> str:
        self.calls.append((argv, env))
        return self._return_value


# ---------------------------------------------------------------------------
# view_issue
# ---------------------------------------------------------------------------


class TestViewIssueRepoFlags:
    def setup_method(self) -> None:
        payload = json.dumps(
            {
                "number": 1,
                "title": "T",
                "state": "open",
                "labels": [],
                "comments": [],
                "body": "",
                "milestone": None,
            }
        )
        self.runner: CapturingRunner = CapturingRunner(return_value=payload)
        set_runner(self.runner)

    def teardown_method(self) -> None:
        reset_runner()

    def test_repo_flag_present_in_argv(self) -> None:
        """view_issue passes --repo owner/name in argv."""
        from code_generator.gh.issues import view_issue  # noqa: PLC0415

        view_issue(_REPO, 1)
        argv, _ = self.runner.calls[0]
        assert "--repo" in argv
        assert "acme/myrepo" in argv

    def test_gh_host_set_in_env(self) -> None:
        """view_issue sets GH_HOST=host in the subprocess env."""
        from code_generator.gh.issues import view_issue  # noqa: PLC0415

        view_issue(_REPO, 1)
        _, env = self.runner.calls[0]
        assert env is not None
        assert env.get("GH_HOST") == "github.example.com"

    def test_no_hostname_flag_in_argv(self) -> None:
        """view_issue does NOT put --hostname in argv (that's api-only)."""
        from code_generator.gh.issues import view_issue  # noqa: PLC0415

        view_issue(_REPO, 1)
        argv, _ = self.runner.calls[0]
        assert "--hostname" not in argv


# ---------------------------------------------------------------------------
# list_issues
# ---------------------------------------------------------------------------


class TestListIssuesRepoFlags:
    def setup_method(self) -> None:
        self.runner: CapturingRunner = CapturingRunner(return_value=json.dumps([]))
        set_runner(self.runner)

    def teardown_method(self) -> None:
        reset_runner()

    def test_repo_flag_present_in_argv(self) -> None:
        """list_issues passes --repo owner/name in argv."""
        from code_generator.gh.issues import list_issues  # noqa: PLC0415

        list_issues(_REPO)
        argv, _ = self.runner.calls[0]
        assert "--repo" in argv
        assert "acme/myrepo" in argv

    def test_gh_host_set_in_env(self) -> None:
        """list_issues sets GH_HOST=host in the subprocess env."""
        from code_generator.gh.issues import list_issues  # noqa: PLC0415

        list_issues(_REPO)
        _, env = self.runner.calls[0]
        assert env is not None
        assert env.get("GH_HOST") == "github.example.com"

    def test_no_hostname_flag_in_argv(self) -> None:
        """list_issues does NOT put --hostname in argv."""
        from code_generator.gh.issues import list_issues  # noqa: PLC0415

        list_issues(_REPO)
        argv, _ = self.runner.calls[0]
        assert "--hostname" not in argv


# ---------------------------------------------------------------------------
# issue_state
# ---------------------------------------------------------------------------


class TestIssueStateRepoFlags:
    def setup_method(self) -> None:
        self.runner: CapturingRunner = CapturingRunner(return_value="open")
        set_runner(self.runner)

    def teardown_method(self) -> None:
        reset_runner()

    def test_repo_flag_present_in_argv(self) -> None:
        """issue_state passes --repo owner/name in argv."""
        from code_generator.gh.issues import issue_state  # noqa: PLC0415

        issue_state(_REPO, 1)
        argv, _ = self.runner.calls[0]
        assert "--repo" in argv
        assert "acme/myrepo" in argv

    def test_gh_host_set_in_env(self) -> None:
        """issue_state sets GH_HOST=host in the subprocess env."""
        from code_generator.gh.issues import issue_state  # noqa: PLC0415

        issue_state(_REPO, 1)
        _, env = self.runner.calls[0]
        assert env is not None
        assert env.get("GH_HOST") == "github.example.com"

    def test_no_hostname_flag_in_argv(self) -> None:
        """issue_state does NOT put --hostname in argv."""
        from code_generator.gh.issues import issue_state  # noqa: PLC0415

        issue_state(_REPO, 1)
        argv, _ = self.runner.calls[0]
        assert "--hostname" not in argv


# ---------------------------------------------------------------------------
# ensure_label
# ---------------------------------------------------------------------------


class TestEnsureLabelRepoFlags:
    def setup_method(self) -> None:
        self.runner: CapturingRunner = CapturingRunner(return_value="")
        set_runner(self.runner)

    def teardown_method(self) -> None:
        reset_runner()

    def test_repo_flag_present_in_argv(self) -> None:
        """ensure_label passes --repo owner/name in argv."""
        from code_generator.gh.labels import ensure_label  # noqa: PLC0415

        ensure_label(_REPO, "priority:high", "FF0000", "High priority")
        argv, _ = self.runner.calls[0]
        assert "--repo" in argv
        assert "acme/myrepo" in argv

    def test_gh_host_set_in_env(self) -> None:
        """ensure_label sets GH_HOST=host in the subprocess env."""
        from code_generator.gh.labels import ensure_label  # noqa: PLC0415

        ensure_label(_REPO, "priority:high", "FF0000", "High priority")
        _, env = self.runner.calls[0]
        assert env is not None
        assert env.get("GH_HOST") == "github.example.com"

    def test_no_hostname_flag_in_argv(self) -> None:
        """ensure_label does NOT put --hostname in argv."""
        from code_generator.gh.labels import ensure_label  # noqa: PLC0415

        ensure_label(_REPO, "priority:high", "FF0000", "High priority")
        argv, _ = self.runner.calls[0]
        assert "--hostname" not in argv


# ---------------------------------------------------------------------------
# add_label
# ---------------------------------------------------------------------------


class TestAddLabelRepoFlags:
    def setup_method(self) -> None:
        self.runner: CapturingRunner = CapturingRunner(return_value="")
        set_runner(self.runner)

    def teardown_method(self) -> None:
        reset_runner()

    def test_repo_flag_present_in_argv(self) -> None:
        """add_label passes --repo owner/name in argv."""
        from code_generator.gh.labels import add_label  # noqa: PLC0415

        add_label(_REPO, 5, "needs-manual-review")
        argv, _ = self.runner.calls[0]
        assert "--repo" in argv
        assert "acme/myrepo" in argv

    def test_gh_host_set_in_env(self) -> None:
        """add_label sets GH_HOST=host in the subprocess env."""
        from code_generator.gh.labels import add_label  # noqa: PLC0415

        add_label(_REPO, 5, "needs-manual-review")
        _, env = self.runner.calls[0]
        assert env is not None
        assert env.get("GH_HOST") == "github.example.com"

    def test_no_hostname_flag_in_argv(self) -> None:
        """add_label does NOT put --hostname in argv."""
        from code_generator.gh.labels import add_label  # noqa: PLC0415

        add_label(_REPO, 5, "needs-manual-review")
        argv, _ = self.runner.calls[0]
        assert "--hostname" not in argv


# ---------------------------------------------------------------------------
# create_milestone  (gh api → uses --hostname, NOT GH_HOST env)
# ---------------------------------------------------------------------------


class TestCreateMilestoneRepoFlags:
    def setup_method(self) -> None:
        self.runner: CapturingRunner = CapturingRunner(
            return_value=json.dumps({"number": 3, "title": "M"})
        )
        set_runner(self.runner)

    def teardown_method(self) -> None:
        reset_runner()

    def test_hostname_flag_in_argv(self) -> None:
        """create_milestone passes --hostname host in argv (gh api style)."""
        from code_generator.gh.milestones import create_milestone  # noqa: PLC0415

        create_milestone(_REPO, "Cycle 1")
        argv, _ = self.runner.calls[0]
        assert "--hostname" in argv
        assert "github.example.com" in argv

    def test_repo_full_in_api_path(self) -> None:
        """create_milestone embeds owner/name in the API path."""
        from code_generator.gh.milestones import create_milestone  # noqa: PLC0415

        create_milestone(_REPO, "Cycle 1")
        argv, _ = self.runner.calls[0]
        assert any("acme/myrepo" in part for part in argv)

    def test_no_gh_host_env_set(self) -> None:
        """create_milestone does NOT set GH_HOST env (uses --hostname instead)."""
        from code_generator.gh.milestones import create_milestone  # noqa: PLC0415

        create_milestone(_REPO, "Cycle 1")
        _, env = self.runner.calls[0]
        assert env is None or "GH_HOST" not in (env or {})


# ---------------------------------------------------------------------------
# delete_milestone  (gh api → --hostname)
# ---------------------------------------------------------------------------


class TestDeleteMilestoneRepoFlags:
    def setup_method(self) -> None:
        self.runner: CapturingRunner = CapturingRunner(return_value="")
        set_runner(self.runner)

    def teardown_method(self) -> None:
        reset_runner()

    def test_hostname_flag_in_argv(self) -> None:
        """delete_milestone passes --hostname host in argv."""
        from code_generator.gh.milestones import delete_milestone  # noqa: PLC0415

        delete_milestone(_REPO, 5)
        argv, _ = self.runner.calls[0]
        assert "--hostname" in argv
        assert "github.example.com" in argv

    def test_repo_full_in_api_path(self) -> None:
        """delete_milestone embeds owner/name in the API path."""
        from code_generator.gh.milestones import delete_milestone  # noqa: PLC0415

        delete_milestone(_REPO, 5)
        argv, _ = self.runner.calls[0]
        assert any("acme/myrepo" in part for part in argv)


# ---------------------------------------------------------------------------
# close_milestone  (gh api → --hostname)
# ---------------------------------------------------------------------------


class TestCloseMilestoneRepoFlags:
    def setup_method(self) -> None:
        self.runner: CapturingRunner = CapturingRunner(return_value="")
        set_runner(self.runner)

    def teardown_method(self) -> None:
        reset_runner()

    def test_hostname_flag_in_argv(self) -> None:
        """close_milestone passes --hostname host in argv."""
        from code_generator.gh.milestones import close_milestone  # noqa: PLC0415

        close_milestone(_REPO, 2)
        argv, _ = self.runner.calls[0]
        assert "--hostname" in argv
        assert "github.example.com" in argv

    def test_repo_full_in_api_path(self) -> None:
        """close_milestone embeds owner/name in the API path."""
        from code_generator.gh.milestones import close_milestone  # noqa: PLC0415

        close_milestone(_REPO, 2)
        argv, _ = self.runner.calls[0]
        assert any("acme/myrepo" in part for part in argv)


# ---------------------------------------------------------------------------
# Integration fixture: github.com project (mocked subprocess)
# ---------------------------------------------------------------------------


class TestGithubComIntegrationFixture:
    """Simulates a github.com project with mocked subprocess — no runtime regression."""

    def setup_method(self) -> None:
        self.repo = RepoInfo(host="github.com", owner="SilvioBaratto", name="code-generator")
        payload = json.dumps(
            [{"number": 1, "title": "T", "state": "open", "labels": [], "comments": []}]
        )
        self.runner: CapturingRunner = CapturingRunner(return_value=payload)
        set_runner(self.runner)

    def teardown_method(self) -> None:
        reset_runner()

    def test_list_issues_github_com_produces_correct_repo_flag(self) -> None:
        """On github.com the --repo flag is SilvioBaratto/code-generator."""
        from code_generator.gh.issues import list_issues  # noqa: PLC0415

        list_issues(self.repo)
        argv, env = self.runner.calls[0]
        repo_idx = argv.index("--repo")
        assert argv[repo_idx + 1] == "SilvioBaratto/code-generator"
        assert env is not None
        assert env["GH_HOST"] == "github.com"
