"""CI grep guard: assert none of the 10 Non-goals techniques appear in shipped code.

Each Non-goal has a named fingerprint in FINGERPRINTS so failures report which one
was hit. Co-occurrence patterns (session-resume-cache, skill-file-cache) require a
secondary pattern to also appear within a 5-line window before flagging a violation.

ALLOWLIST entries suppress known false-positives. Every entry must have a matching
justification comment at the flagged source location.

Ref: GitHub issue #203 — §Non-goals of the 0.3.0 release spec.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import NamedTuple

# ---------------------------------------------------------------------------
# Fingerprints
# ---------------------------------------------------------------------------

FINGERPRINTS: dict[str, re.Pattern] = {
    "haiku-prefilter": re.compile(r"claude-haiku-[34]-\d+\s+pre-?filter", re.IGNORECASE),
    "caveman": re.compile(r"caveman|caveman-speak", re.IGNORECASE),
    # session-resume-cache: primary pattern; co-occurrence with "cache" checked below.
    "session-resume-cache": re.compile(r"resume\s*=\s*session_id", re.IGNORECASE),
    "hardcoded-thinking-budget": re.compile(r"thinking_budget\s*=\s*\d+", re.IGNORECASE),
    # skill-file-cache: primary pattern; co-occurrence with cache/prefix checked below.
    "skill-file-cache": re.compile(r"\.skill\b", re.IGNORECASE),
    "managed-agents-api": re.compile(r"/v1/agents|/v1/sessions", re.IGNORECASE),
    "prompt-minify": re.compile(
        r"prompt_minify|minify_prompt|strip_prompt_whitespace", re.IGNORECASE
    ),
    "haiku-router": re.compile(r"haiku.*routing|router.*haiku", re.IGNORECASE),
    "semantic-redis": re.compile(r"redis.*embedding|embedding.*cache.*redis", re.IGNORECASE),
    "cross-workspace-cache": re.compile(
        r"cross_workspace_cache|multi_workspace_cache", re.IGNORECASE
    ),
}

# Co-occurrence: (secondary_pattern, window_lines).
# Primary match is only flagged when secondary also appears within ±window lines.
_CO_OCCURRENCE: dict[str, tuple[re.Pattern, int]] = {
    "session-resume-cache": (re.compile(r"cache", re.IGNORECASE), 5),
    "skill-file-cache": (re.compile(r"cache|prefix", re.IGNORECASE), 5),
}


# ---------------------------------------------------------------------------
# Allowlist
# ---------------------------------------------------------------------------


class AllowlistEntry(NamedTuple):
    """A suppressed false-positive.

    *file_path*: path relative to the repository root (forward slashes).
    *line*: 1-based line number of the flagged occurrence.
    *justification*: human-readable explanation; a matching comment must exist at
    that location in the source file.
    """

    fingerprint: str
    file_path: str
    line: int
    justification: str


# Add entries here when a legitimate occurrence exists in src/.
# Format: AllowlistEntry(fingerprint, "src/code_generator/...", line, "reason")
ALLOWLIST: set[AllowlistEntry] = set()


# ---------------------------------------------------------------------------
# Internal types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Violation:
    name: str
    file: Path
    line: int
    text: str

    def __str__(self) -> str:
        return f"Non-goal '{self.name}' detected at {self.file}:{self.line}: {self.text}"


# ---------------------------------------------------------------------------
# Scanner helpers
# ---------------------------------------------------------------------------


def _repo_root() -> Path:
    return Path(__file__).parent.parent


def _src_root() -> Path:
    return _repo_root() / "src" / "code_generator"


def _collect_files(root: Path) -> list[Path]:
    files: list[Path] = []
    for glob in ("**/*.py", "**/*.md"):
        files.extend(root.glob(glob))
    return sorted(files)


def _secondary_present(lines: list[str], idx: int, secondary: re.Pattern, window: int) -> bool:
    """Return True if *secondary* matches any line within *window* lines of *idx*."""
    start = max(0, idx - window)
    end = min(len(lines), idx + window + 1)
    return any(secondary.search(line) for line in lines[start:end])


def _scan_file_lines(path: Path, lines: list[str]) -> list[Violation]:
    """Return all violations found in *lines* for file *path*."""
    violations: list[Violation] = []
    for name, pattern in FINGERPRINTS.items():
        co = _CO_OCCURRENCE.get(name)
        for i, line in enumerate(lines):
            if not pattern.search(line):
                continue
            if co is not None:
                secondary, window = co
                if not _secondary_present(lines, i, secondary, window):
                    continue
            violations.append(Violation(name=name, file=path, line=i + 1, text=line.rstrip()))
    return violations


def _is_allowlisted(v: Violation, repo_root: Path) -> bool:
    """Return True if *v* has a matching ALLOWLIST entry."""
    try:
        rel = v.file.relative_to(repo_root).as_posix()
    except ValueError:
        rel = v.file.as_posix()
    return any(
        entry.fingerprint == v.name and entry.file_path == rel and entry.line == v.line
        for entry in ALLOWLIST
    )


def _scan_directory(root: Path) -> list[Violation]:
    """Scan *root* recursively; return violations not suppressed by ALLOWLIST."""
    repo_root = _repo_root()
    violations: list[Violation] = []
    for path in _collect_files(root):
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        for v in _scan_file_lines(path, lines):
            if not _is_allowlisted(v, repo_root):
                violations.append(v)
    return violations


# ---------------------------------------------------------------------------
# Main guard test
# ---------------------------------------------------------------------------


class TestNonGoalsGrepGuard:
    def test_no_non_goals_in_src(self) -> None:
        """None of the 10 Non-goals fingerprints must appear in src/code_generator/."""
        violations = _scan_directory(_src_root())

        if violations:
            header = "Forbidden Non-goal techniques detected in shipped code:"
            body = "\n".join(f"  {v}" for v in violations)
            raise AssertionError(f"{header}\n{body}")


# ---------------------------------------------------------------------------
# Meta-tests: verify the scanner itself works correctly
# ---------------------------------------------------------------------------


class TestGrepGuardMeta:
    """Meta-tests ensure the scanner catches violations and the allowlist silences them."""

    def test_seeded_fingerprint_is_detected(self, tmp_path: Path) -> None:
        """Scanner catches a deliberately seeded 'caveman' fingerprint."""
        seed = tmp_path / "seed.py"
        seed.write_text("x = 1\ncaveman = True\nx = 3\n", encoding="utf-8")

        violations = _scan_file_lines(seed, seed.read_text().splitlines())

        assert any(v.name == "caveman" for v in violations), (
            f"Expected 'caveman' violation; got: {[v.name for v in violations]}"
        )

    def test_seeded_fingerprint_correct_line_number(self, tmp_path: Path) -> None:
        """Scanner reports the correct 1-based line number for a match."""
        seed = tmp_path / "seed_line.py"
        seed.write_text("# line 1\n# line 2\ncaveman = True\n", encoding="utf-8")

        violations = _scan_file_lines(seed, seed.read_text().splitlines())

        caveman = next((v for v in violations if v.name == "caveman"), None)
        assert caveman is not None, "Expected caveman violation"
        assert caveman.line == 3, f"Expected line 3, got {caveman.line}"

    def test_violation_message_includes_name_file_line_text(self, tmp_path: Path) -> None:
        """Violation __str__ includes fingerprint name, file path, line, and matched text."""
        seed = tmp_path / "seed_msg.py"
        seed.write_text("caveman_speak = 'old'\n", encoding="utf-8")

        violations = _scan_file_lines(seed, seed.read_text().splitlines())

        assert violations, "Expected at least one violation"
        msg = str(violations[0])
        assert "caveman" in msg
        assert str(seed) in msg
        assert ":1:" in msg

    def test_allowlist_silences_seeded_fingerprint(self, tmp_path: Path) -> None:
        """ALLOWLIST entry suppresses the matching violation."""
        seed = tmp_path / "allowlist_seed.py"
        seed.write_text("caveman_speak = 'explicitly rejected'\n", encoding="utf-8")

        lines = seed.read_text().splitlines()
        raw = _scan_file_lines(seed, lines)
        assert any(v.name == "caveman" for v in raw), "Pre-condition: violation must exist"

        entry = AllowlistEntry(
            fingerprint="caveman",
            file_path=str(seed.relative_to(tmp_path).as_posix()),
            line=1,
            justification="test: meta-test for allowlist silencing",
            # Matching comment required in source: see test body above.
        )
        original = ALLOWLIST.copy()
        try:
            ALLOWLIST.add(entry)
            remaining = [v for v in raw if not _is_allowlisted(v, tmp_path)]
            assert not any(v.name == "caveman" for v in remaining), (
                "ALLOWLIST did not silence the caveman violation"
            )
        finally:
            ALLOWLIST.clear()
            ALLOWLIST.update(original)

    def test_co_occurrence_not_triggered_without_secondary(self, tmp_path: Path) -> None:
        """session-resume-cache is NOT flagged when 'cache' is absent from the window."""
        seed = tmp_path / "no_co.py"
        seed.write_text("options.resume = session_id\n", encoding="utf-8")

        violations = _scan_file_lines(seed, seed.read_text().splitlines())

        assert not any(v.name == "session-resume-cache" for v in violations), (
            "session-resume-cache must not trigger without 'cache' within 5 lines"
        )

    def test_co_occurrence_triggered_when_secondary_in_window(self, tmp_path: Path) -> None:
        """session-resume-cache IS flagged when 'cache' appears within 5 lines."""
        code = "options.resume = session_id\n# comment\nwarm_cache = True\n"
        seed = tmp_path / "co_match.py"
        seed.write_text(code, encoding="utf-8")

        violations = _scan_file_lines(seed, seed.read_text().splitlines())

        assert any(v.name == "session-resume-cache" for v in violations), (
            "session-resume-cache must trigger when 'cache' is within 5 lines"
        )

    def test_all_ten_fingerprints_defined(self) -> None:
        """FINGERPRINTS contains exactly the 10 required Non-goal entries."""
        expected = {
            "haiku-prefilter",
            "caveman",
            "session-resume-cache",
            "hardcoded-thinking-budget",
            "skill-file-cache",
            "managed-agents-api",
            "prompt-minify",
            "haiku-router",
            "semantic-redis",
            "cross-workspace-cache",
        }
        assert set(FINGERPRINTS.keys()) == expected

    def test_all_fingerprints_are_compiled_patterns(self) -> None:
        """Every value in FINGERPRINTS is a compiled re.Pattern."""
        for name, pattern in FINGERPRINTS.items():
            assert isinstance(pattern, re.Pattern), (
                f"'{name}': expected re.Pattern, got {type(pattern)}"
            )

    def test_collect_files_returns_py_and_md(self, tmp_path: Path) -> None:
        """_collect_files returns both .py and .md files, ignoring others."""
        (tmp_path / "a.py").write_text("# py", encoding="utf-8")
        (tmp_path / "b.md").write_text("# md", encoding="utf-8")
        (tmp_path / "c.txt").write_text("# txt", encoding="utf-8")

        files = _collect_files(tmp_path)
        names = {f.name for f in files}

        assert "a.py" in names
        assert "b.md" in names
        assert "c.txt" not in names
