"""Tests for crash-recovery FSM on --continue (issue #188).

Acceptance criteria:
- client_alive_at within TTL → INFO log "previous client vanished; reopening with fresh KV cache..."
- client_alive_at outside TTL → no INFO, silent resume path.
- client_alive_at = None → no INFO, silent resume path.
- --continue --session-mode shared, stored "fresh" → exit 2, exact mismatch message in stderr.
- --continue without --session-mode flag → inherits stored mode silently (exit 0).
- client_alive_at cleared on clean cycle completion (delegated to managed_shared_client tests).
- Integration: crash simulation via CancelledError leaves client_alive_at set; --continue
  detects it and logs crash recovery.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from code_generator import state as state_module
from code_generator.env import DANGEROUS_VARS

if TYPE_CHECKING:
    from pathlib import Path

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _clear_env(monkeypatch: pytest.MonkeyPatch) -> None:
    for var in DANGEROUS_VARS:
        monkeypatch.delenv(var, raising=False)


def _state_with_client_alive_at(
    *,
    minutes_ago: float | None,
    mode: str = "single",
    session_mode: str = "shared",
) -> state_module.State:
    """Build a State with client_alive_at set to minutes_ago minutes in the past."""
    if minutes_ago is not None:
        ts = (datetime.now(tz=UTC) - timedelta(minutes=minutes_ago)).isoformat(timespec="seconds")
    else:
        ts = None
    return state_module.State(
        mode=mode,  # type: ignore[arg-type]
        started_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
        session_mode=session_mode,  # type: ignore[arg-type]
        client_alive_at=ts,
    )


# ---------------------------------------------------------------------------
# Unit tests: check_and_log_crash_recovery
# ---------------------------------------------------------------------------


class TestCheckAndLogCrashRecovery:
    """Unit tests for commands._crash_recovery.check_and_log_crash_recovery."""

    def test_client_alive_5min_ago_logs_info(self, caplog: pytest.LogCaptureFixture) -> None:
        """client_alive_at set to 5 min ago → INFO logged with exact crash-recovery message."""
        from code_generator.commands._crash_recovery import (
            CRASH_RECOVERY_LOG_MSG,
            check_and_log_crash_recovery,
        )

        st = _state_with_client_alive_at(minutes_ago=5)

        with caplog.at_level(logging.INFO):
            check_and_log_crash_recovery(st)

        messages = [r.message for r in caplog.records if r.levelno == logging.INFO]
        assert any(CRASH_RECOVERY_LOG_MSG in m for m in messages), (
            f"Expected crash-recovery INFO not found. Records: {messages}"
        )

    def test_client_alive_90min_ago_does_not_log(self, caplog: pytest.LogCaptureFixture) -> None:
        """client_alive_at set to 90 min ago → no INFO crash-recovery log (outside TTL)."""
        from code_generator.commands._crash_recovery import (
            CRASH_RECOVERY_LOG_MSG,
            check_and_log_crash_recovery,
        )

        st = _state_with_client_alive_at(minutes_ago=90)

        with caplog.at_level(logging.INFO):
            check_and_log_crash_recovery(st)

        messages = [r.message for r in caplog.records if r.levelno == logging.INFO]
        assert not any(CRASH_RECOVERY_LOG_MSG in m for m in messages), (
            f"Unexpected crash-recovery INFO for stale client. Records: {messages}"
        )

    def test_client_alive_at_none_does_not_log(self, caplog: pytest.LogCaptureFixture) -> None:
        """client_alive_at = None → no INFO crash-recovery log."""
        from code_generator.commands._crash_recovery import (
            CRASH_RECOVERY_LOG_MSG,
            check_and_log_crash_recovery,
        )

        st = _state_with_client_alive_at(minutes_ago=None)

        with caplog.at_level(logging.INFO):
            check_and_log_crash_recovery(st)

        messages = [r.message for r in caplog.records if r.levelno == logging.INFO]
        assert not any(CRASH_RECOVERY_LOG_MSG in m for m in messages), (
            f"Unexpected crash-recovery INFO when client_alive_at is None. Records: {messages}"
        )

    def test_custom_logger_receives_info(self) -> None:
        """When a custom logger is passed, the INFO is emitted on that logger."""
        from code_generator.commands._crash_recovery import (
            CRASH_RECOVERY_LOG_MSG,
            check_and_log_crash_recovery,
        )

        st = _state_with_client_alive_at(minutes_ago=5)
        mock_logger = MagicMock(spec=logging.Logger)

        check_and_log_crash_recovery(st, logger=mock_logger)

        mock_logger.info.assert_called_once_with(CRASH_RECOVERY_LOG_MSG)

    def test_custom_logger_not_called_when_outside_ttl(self) -> None:
        """Custom logger is NOT called when client_alive_at is outside TTL."""
        from code_generator.commands._crash_recovery import check_and_log_crash_recovery

        st = _state_with_client_alive_at(minutes_ago=90)
        mock_logger = MagicMock(spec=logging.Logger)

        check_and_log_crash_recovery(st, logger=mock_logger)

        mock_logger.info.assert_not_called()

    def test_exact_log_message_matches_verbatim(self) -> None:
        """CRASH_RECOVERY_LOG_MSG must match byte-for-byte what the issue specifies."""
        from code_generator.commands._crash_recovery import CRASH_RECOVERY_LOG_MSG

        expected = (
            "previous client vanished; reopening with fresh KV cache (expected on crash recovery)"
        )
        assert expected == CRASH_RECOVERY_LOG_MSG, (
            f"Log message mismatch. Downstream tooling greps for the exact string.\n"
            f"  expected: {expected!r}\n"
            f"  got:      {CRASH_RECOVERY_LOG_MSG!r}"
        )

    def test_custom_ttl_respected(self) -> None:
        """ttl_minutes parameter limits the window — 45-min-old client is outside a 30-min TTL."""
        from code_generator.commands._crash_recovery import check_and_log_crash_recovery

        st = _state_with_client_alive_at(minutes_ago=45)
        mock_logger = MagicMock(spec=logging.Logger)

        check_and_log_crash_recovery(st, ttl_minutes=30, logger=mock_logger)

        mock_logger.info.assert_not_called()


# ---------------------------------------------------------------------------
# Integration: dispatch_orchestrator calls check_and_log_crash_recovery
# ---------------------------------------------------------------------------


class TestDispatchCrashRecoveryIntegration:
    """Verify dispatch_orchestrator invokes check_and_log_crash_recovery on --continue."""

    def _write_state(
        self,
        tmp_path: Path,
        *,
        minutes_ago: float | None,
        mode: str = "single",
        session_mode: str = "shared",
    ) -> Path:
        cg = tmp_path / ".code-generator"
        cg.mkdir(parents=True, exist_ok=True)
        st = _state_with_client_alive_at(
            minutes_ago=minutes_ago,
            mode=mode,
            session_mode=session_mode,
        )
        state_module.save_state(cg / "state.json", st)
        return cg

    def test_continue_with_client_alive_calls_crash_recovery(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """dispatch_orchestrator calls check_and_log_crash_recovery on --continue."""
        monkeypatch.chdir(tmp_path)
        self._write_state(tmp_path, minutes_ago=5)

        crash_recovery_calls: list[state_module.State] = []

        from code_generator.commands import _dispatch

        def fake_crash_recovery(st, **kwargs):  # type: ignore[no-untyped-def]
            crash_recovery_calls.append(st)

        monkeypatch.setattr(
            _dispatch,
            "check_and_log_crash_recovery",
            fake_crash_recovery,
        )

        async def mock_single(state, *_args, **_kwargs):
            return state

        from code_generator.orchestrator import cycle_loop

        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)

        st = state_module.load_state(tmp_path / ".code-generator" / "state.json")

        _dispatch.dispatch_orchestrator(
            st,
            tmp_path,
            dry_run=False,
            phase=None,
            continue_=True,
            mode="auto",
            cycle=None,
            state_path=tmp_path / ".code-generator" / "state.json",
        )

        assert len(crash_recovery_calls) == 1, (
            "check_and_log_crash_recovery must be called exactly once on --continue"
        )

    def test_no_continue_does_not_call_crash_recovery(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Without --continue, check_and_log_crash_recovery is NOT called."""
        monkeypatch.chdir(tmp_path)
        self._write_state(tmp_path, minutes_ago=5)

        crash_recovery_calls: list[state_module.State] = []

        from code_generator.commands import _dispatch

        def fake_crash_recovery(st, **kwargs):  # type: ignore[no-untyped-def]
            crash_recovery_calls.append(st)

        monkeypatch.setattr(
            _dispatch,
            "check_and_log_crash_recovery",
            fake_crash_recovery,
        )

        async def mock_single(state, *_args, **_kwargs):
            return state

        from code_generator.orchestrator import cycle_loop, phase0_complexity

        async def mock_phase0(state, *_args, **_kwargs):
            state.mode = "single"
            return state

        monkeypatch.setattr(phase0_complexity, "run", mock_phase0)
        monkeypatch.setattr(cycle_loop, "run_single_mode", mock_single)

        st = state_module.load_state(tmp_path / ".code-generator" / "state.json")
        # Need to set mode so phase0 isn't needed
        st.mode = "single"  # type: ignore[assignment]
        state_module.save_state(tmp_path / ".code-generator" / "state.json", st)
        st = state_module.load_state(tmp_path / ".code-generator" / "state.json")

        _dispatch.dispatch_orchestrator(
            st,
            tmp_path,
            dry_run=False,
            phase=None,
            continue_=False,
            mode="single",
            cycle=None,
            state_path=tmp_path / ".code-generator" / "state.json",
        )

        assert crash_recovery_calls == [], (
            "check_and_log_crash_recovery must NOT be called on a fresh run"
        )


# ---------------------------------------------------------------------------
# Integration: session-mode mismatch on --continue (AC coverage)
# ---------------------------------------------------------------------------


class TestSessionModeMismatchOnContinue:
    """Verify exit 2 + exact mismatch message when --session-mode conflicts with stored value."""

    def test_continue_session_mode_shared_stored_fresh_exits_2(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--continue --session-mode shared, stored 'fresh' → exit 2, exact mismatch in output."""
        from typer.testing import CliRunner

        from code_generator import state as sm
        from code_generator.cli import app

        monkeypatch.chdir(tmp_path)
        cg = tmp_path / ".code-generator"
        cg.mkdir()
        st = sm.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            session_mode="fresh",  # type: ignore[arg-type]
        )
        sm.save_state(cg / "state.json", st)

        import code_generator.commands.generate as gen_mod
        from code_generator.repo_info import RepoInfo

        monkeypatch.setattr(
            gen_mod.preflight_module,
            "run_preflight",
            lambda _: RepoInfo(host="github.com", owner="test-owner", name="test-repo"),
        )

        cli_runner = CliRunner()
        result = cli_runner.invoke(app, ["generate", "--continue", "--session-mode", "shared"])

        assert result.exit_code == 2
        combined = (result.output or "") + (result.stderr or "")
        assert "State mode mismatch" in combined
        assert "--session-mode=fresh" in combined

    def test_continue_without_session_mode_flag_inherits_silently(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """--continue without --session-mode inherits stored mode silently (exit 0)."""
        from typer.testing import CliRunner

        from code_generator import state as sm
        from code_generator.cli import app
        from code_generator.orchestrator import cycle_loop

        monkeypatch.chdir(tmp_path)
        cg = tmp_path / ".code-generator"
        cg.mkdir()
        st = sm.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            session_mode="fresh",  # type: ignore[arg-type]
        )
        sm.save_state(cg / "state.json", st)

        import code_generator.commands.generate as gen_mod
        from code_generator.repo_info import RepoInfo

        monkeypatch.setattr(
            gen_mod.preflight_module,
            "run_preflight",
            lambda _: RepoInfo(host="github.com", owner="test-owner", name="test-repo"),
        )

        async def _noop_single(state, *_args, **_kwargs):
            return state

        monkeypatch.setattr(cycle_loop, "run_single_mode", _noop_single)

        cli_runner = CliRunner()
        result = cli_runner.invoke(app, ["generate", "--continue"])

        assert result.exit_code == 0, (
            f"Expected exit 0 when inheriting stored mode; got {result.exit_code}.\n{result.output}"
        )


# ---------------------------------------------------------------------------
# Integration: crash simulation — CancelledError leaves client_alive_at set
# ---------------------------------------------------------------------------


class TestCrashSimulation:
    """Simulate a process crash mid-Phase-3/4 and verify client_alive_at is preserved."""

    @pytest.mark.asyncio
    async def test_cancelled_error_leaves_client_alive_at_set(self, tmp_path: Path) -> None:
        """CancelledError in managed_shared_client body leaves client_alive_at set."""
        from code_generator.orchestrator._client_lifecycle import managed_shared_client

        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir()
        state_path = state_dir / "state.json"

        st = state_module.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
        )
        state_module.save_state(state_path, st)

        mock_client = MagicMock()
        mock_cm = MagicMock()
        mock_cm.__aenter__ = AsyncMock(return_value=mock_client)
        mock_cm.__aexit__ = AsyncMock(return_value=False)

        with (
            patch("code_generator.orchestrator._client_lifecycle._env.strip_dangerous_env"),
            patch(
                "code_generator.orchestrator._client_lifecycle._build_cycle_options",
                return_value=MagicMock(),
            ),
            patch(
                "code_generator.orchestrator._client_lifecycle._open_cycle_client",
                return_value=mock_cm,
            ),
        ):
            with pytest.raises(asyncio.CancelledError):
                async with managed_shared_client(st, state_path):
                    state_module.mark_client_alive(st, state_path)
                    raise asyncio.CancelledError()

        # Reload state from disk and verify client_alive_at is NOT cleared.
        st_after = state_module.load_state(state_path)
        assert st_after.client_alive_at is not None, (
            "client_alive_at must remain set after CancelledError — crash recovery depends on it"
        )

    @pytest.mark.asyncio
    async def test_continue_after_crash_logs_recovery_and_opens_new_client(
        self, tmp_path: Path
    ) -> None:
        """--continue with client_alive_at within TTL logs crash recovery and opens a new client."""
        from code_generator.orchestrator._client_lifecycle import managed_shared_client

        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir()
        state_path = state_dir / "state.json"

        # Simulate crash: state has client_alive_at set 5 minutes ago.
        recent = (datetime.now(tz=UTC) - timedelta(minutes=5)).isoformat(timespec="seconds")
        st = state_module.State(
            mode="single",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            client_alive_at=recent,
        )
        state_module.save_state(state_path, st)

        # Verify crash_recovery check fires for this state.
        from code_generator.commands._crash_recovery import (
            CRASH_RECOVERY_LOG_MSG,
            check_and_log_crash_recovery,
        )

        mock_logger = MagicMock(spec=logging.Logger)
        check_and_log_crash_recovery(st, logger=mock_logger)

        mock_logger.info.assert_called_once_with(CRASH_RECOVERY_LOG_MSG)

        # Verify managed_shared_client can open a fresh client after the crash.
        mock_client = MagicMock()
        mock_cm = MagicMock()
        mock_cm.__aenter__ = AsyncMock(return_value=mock_client)
        mock_cm.__aexit__ = AsyncMock(return_value=False)

        clients_opened: list[object] = []

        with (
            patch("code_generator.orchestrator._client_lifecycle._env.strip_dangerous_env"),
            patch(
                "code_generator.orchestrator._client_lifecycle._build_cycle_options",
                return_value=MagicMock(),
            ),
            patch(
                "code_generator.orchestrator._client_lifecycle._open_cycle_client",
                return_value=mock_cm,
            ),
            patch("code_generator.orchestrator._client_lifecycle._state.mark_client_alive"),
            patch("code_generator.orchestrator._client_lifecycle._state.clear_client_alive"),
        ):
            async with managed_shared_client(st, state_path) as client:
                clients_opened.append(client)

        assert len(clients_opened) == 1, "A fresh client must be opened on resume after crash"
        assert clients_opened[0] is mock_client
