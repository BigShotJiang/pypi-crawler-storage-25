"""Tests for ``CycleState.ollama_model`` persistence (issue #217).

TDD: Red → Green.

The field mirrors the ``phase2_batch_id`` pattern added in #198 — optional
string with a ``None`` default so pre-existing state.json files deserialize
without migration. ``save_state`` relies on ``dataclasses.asdict`` so the key
is always present in the JSON payload (even when ``None``); old files simply
lack the key and fall back to the default via ``.get()``.
"""

from __future__ import annotations

import dataclasses
import json
from pathlib import Path

from code_generator import state as _state


def _make_cycle(**overrides: object) -> _state.CycleState:
    """Build a minimal CycleState with sensible defaults."""
    defaults: dict[str, object] = {
        "id": 1,
        "name": "Test",
        "milestone_number": 1,
        "milestone_title": "Test",
        "status": "open",
        "phase": 0,
        "issues": [],
        "commit_sha": None,
    }
    defaults.update(overrides)
    return _state.CycleState(**defaults)  # type: ignore[arg-type]


class TestOllamaModelDefaultValue:
    def test_cycle_state_has_ollama_model_field_defaulting_to_none(self) -> None:
        """Constructing CycleState without ollama_model sets it to None."""
        cycle = _make_cycle()
        assert cycle.ollama_model is None

    def test_cycle_state_accepts_explicit_ollama_model(self) -> None:
        """Passing ollama_model="..." to CycleState stores the string."""
        cycle = _make_cycle(ollama_model="qwen3-coder:480b:cloud")
        assert cycle.ollama_model == "qwen3-coder:480b:cloud"


class TestOllamaModelSerialization:
    def test_asdict_includes_ollama_model_key(self) -> None:
        """``dataclasses.asdict`` emits the ``ollama_model`` key."""
        cycle = _make_cycle(ollama_model="gpt-oss:120b-cloud")
        d = dataclasses.asdict(cycle)
        assert d["ollama_model"] == "gpt-oss:120b-cloud"

    def test_asdict_emits_null_for_unset_ollama_model(self) -> None:
        """When ollama_model is None, the JSON payload contains a null value."""
        cycle = _make_cycle()
        d = dataclasses.asdict(cycle)
        assert "ollama_model" in d
        assert d["ollama_model"] is None


class TestOllamaModelRoundTrip:
    def test_save_load_round_trip_preserves_model_tag(self, tmp_path: Path) -> None:
        """CycleState.ollama_model round-trips through save_state / load_state."""
        state_path = tmp_path / ".code-generator" / "state.json"
        tag = "qwen3-coder:480b:cloud"
        cycle = _make_cycle(ollama_model=tag)
        state = _state.State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            cycles=[cycle],
        )

        _state.save_state(state_path, state)
        loaded = _state.load_state(state_path)

        assert isinstance(loaded.cycles[0], _state.CycleState)
        assert loaded.cycles[0].ollama_model == tag

    def test_round_trip_preserves_colons_in_model_tag(self, tmp_path: Path) -> None:
        """Colon-heavy Ollama model tags survive JSON encode / decode."""
        state_path = tmp_path / ".code-generator" / "state.json"
        cycle = _make_cycle(ollama_model="devstral-small-2:24b:cloud")
        state = _state.State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            cycles=[cycle],
        )

        _state.save_state(state_path, state)
        loaded = _state.load_state(state_path)

        assert isinstance(loaded.cycles[0], _state.CycleState)
        assert loaded.cycles[0].ollama_model == "devstral-small-2:24b:cloud"

    def test_round_trip_preserves_unicode_in_model_tag(self, tmp_path: Path) -> None:
        """Non-ASCII characters in the model tag round-trip losslessly."""
        state_path = tmp_path / ".code-generator" / "state.json"
        tag = "café-model:v1"  # contains U+00E9
        cycle = _make_cycle(ollama_model=tag)
        state = _state.State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            cycles=[cycle],
        )

        _state.save_state(state_path, state)
        loaded = _state.load_state(state_path)

        assert isinstance(loaded.cycles[0], _state.CycleState)
        assert loaded.cycles[0].ollama_model == tag

    def test_none_round_trips_as_none(self, tmp_path: Path) -> None:
        """An unset ollama_model round-trips as None."""
        state_path = tmp_path / ".code-generator" / "state.json"
        cycle = _make_cycle()
        state = _state.State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            cycles=[cycle],
        )

        _state.save_state(state_path, state)
        loaded = _state.load_state(state_path)

        assert isinstance(loaded.cycles[0], _state.CycleState)
        assert loaded.cycles[0].ollama_model is None


class TestOllamaModelLegacyStateFile:
    def test_legacy_cycle_dict_without_ollama_model_loads_cleanly(self, tmp_path: Path) -> None:
        """A legacy state.json written before #217 deserializes without error."""
        state_path = tmp_path / ".code-generator" / "state.json"
        state_path.parent.mkdir(parents=True, exist_ok=True)

        # Simulate a pre-#217 state.json: all current keys except ollama_model.
        legacy_cycle: dict[str, object] = {
            "id": 1,
            "name": "Legacy",
            "milestone_number": 1,
            "milestone_title": "Legacy milestone",
            "status": "open",
            "phase": 0,
            "issues": [],
            "commit_sha": None,
            "depends_on": [],
            "scope": "",
            "effort_hints": [],
            "base_commit": None,
            "token_usage": {},
            "started_at": None,
            "finished_at": None,
            "cache_telemetry": {
                "cache_creation_tokens": 0,
                "cache_read_tokens": 0,
                "input_tokens": 0,
                "output_tokens": 0,
                "cache_hit_pct": 0.0,
            },
            "phase2_batch_id": None,
            # NOTE: no "ollama_model" key — this is the pre-#217 shape.
        }
        legacy_state: dict[str, object] = {
            "mode": "multi-cycle",
            "started_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-01T00:00:00Z",
            "current_cycle": 1,
            "cycles": [legacy_cycle],
            "phase": None,
            "issues": [],
            "session_id": None,
            "paused_until": None,
            "rate_limit_type": None,
            "last_error": None,
            "effort_hints": [],
            "requirements_hash": None,
            "base_commit": None,
            "token_usage": {},
            "session_mode": "shared",
            "client_alive_at": None,
            "phase2_batch_id": None,
            "prompt_hashes": {},
            "sdk_version": None,
        }
        state_path.write_text(json.dumps(legacy_state, indent=2), encoding="utf-8")

        loaded = _state.load_state(state_path)

        assert isinstance(loaded.cycles[0], _state.CycleState)
        assert loaded.cycles[0].ollama_model is None  # default for absent key


class TestAtomicWriteUnchanged:
    def test_save_state_writes_via_tmp_and_replace(self, tmp_path: Path) -> None:
        """Save path still goes through tmp → os.replace (non-negotiable #7).

        We verify the atomic-write contract is preserved by checking that the
        final file is a valid JSON payload after save_state returns (no partial
        file) and that adding ollama_model did not introduce any new writes.
        """
        state_path = tmp_path / ".code-generator" / "state.json"
        cycle = _make_cycle(ollama_model="gpt-oss:120b-cloud")
        state = _state.State(
            mode="multi-cycle",
            started_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            cycles=[cycle],
        )

        _state.save_state(state_path, state)

        content = json.loads(state_path.read_text(encoding="utf-8"))
        assert content["cycles"][0]["ollama_model"] == "gpt-oss:120b-cloud"
