"""Tests for src/code_generator/repomap.py — tree-sitter + PageRank repo map.

Test strategy: Red → Green → Refactor (TDD).
Each acceptance criterion from issue #174 has at least one dedicated test.
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

FIXTURE_DIR = Path(__file__).parent / "fixtures" / "repomap-fixture"


@pytest.fixture()
def malformed_fixture(tmp_path: Path) -> Path:
    """Fixture with one valid and one intentionally malformed Python file."""
    (tmp_path / "good.py").write_text(
        "def greet():\n    pass\n\ndef farewell():\n    greet()\n",
        encoding="utf-8",
    )
    # File with a Python syntax error — tree-sitter marks root as has_error
    (tmp_path / "bad.py").write_text("def ():\n    pass\n", encoding="utf-8")
    return tmp_path


# ---------------------------------------------------------------------------
# Test 1: Deterministic output across two compute calls
# ---------------------------------------------------------------------------


def test_deterministic_output_across_runs() -> None:
    """compute_repomap returns the same string on successive calls."""
    from code_generator.repomap import compute_repomap

    result1 = compute_repomap(FIXTURE_DIR)
    result2 = compute_repomap(FIXTURE_DIR)

    assert result1 == result2
    assert result1.strip(), "expected non-empty repomap"


# ---------------------------------------------------------------------------
# Test 2: ImportError fallback — WARNING emitted, fallback string returned
# ---------------------------------------------------------------------------


def test_fallback_when_tree_sitter_import_error(
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When neither tree-sitter package is importable, the fallback string is returned."""
    monkeypatch.setitem(sys.modules, "tree_sitter_language_pack", None)
    monkeypatch.setitem(sys.modules, "tree_sitter_languages", None)

    # Import after patching so the lazy import sees the None entry.
    import importlib

    import code_generator.repomap as mod

    importlib.reload(mod)

    with caplog.at_level(logging.WARNING, logger="code_generator.repomap"):
        result = mod.compute_repomap(tmp_path)

    assert result == "(repomap unavailable — rely on MCP or Read tools)"
    assert "tree-sitter not installed; using fallback" in caplog.text


# ---------------------------------------------------------------------------
# Test 3: Malformed file — WARNING logged, rest of the repo still processed
# ---------------------------------------------------------------------------


def test_malformed_file_skipped_with_warning(
    malformed_fixture: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """A file with syntax errors is skipped; other files still contribute."""
    from code_generator.repomap import compute_repomap

    with caplog.at_level(logging.WARNING, logger="code_generator.repomap"):
        result = compute_repomap(malformed_fixture)

    # Warning must name the bad file
    assert "bad.py" in caplog.text
    # Result is non-empty (good.py still processed)
    assert result.strip(), "expected symbols from good.py"
    # Only bad.py warned, good.py must appear in output
    assert "good.py" in result


# ---------------------------------------------------------------------------
# Test 4: Token budget — len(result) // 4 <= max_tokens
# ---------------------------------------------------------------------------


def test_token_budget_respected() -> None:
    """compute_repomap never exceeds the requested token budget."""
    from code_generator.repomap import compute_repomap

    result = compute_repomap(FIXTURE_DIR, max_tokens=5000)
    assert len(result) // 4 <= 5000
