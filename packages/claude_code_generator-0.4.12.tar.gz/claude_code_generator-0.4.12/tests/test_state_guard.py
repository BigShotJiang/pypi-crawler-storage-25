"""Tests for runner/state_guard.py — Issue #153.

TDD: Red → Green → Refactor
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

from code_generator.runner.state_guard import protect_state_file

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

IS_WINDOWS = sys.platform == "win32"


# ---------------------------------------------------------------------------
# Test: PermissionError raised when writing inside the context (POSIX only)
# ---------------------------------------------------------------------------


@pytest.mark.skipif(IS_WINDOWS, reason="chmod write-protection is a no-op on Windows")
def test_write_inside_context_raises_permission_error(tmp_path: Path) -> None:
    """On POSIX, writing to state_path inside protect_state_file raises PermissionError."""
    state_path = tmp_path / "state.json"
    state_path.write_text('{"version": 1}')

    with pytest.raises(PermissionError):
        with protect_state_file(state_path):
            state_path.write_text("x")


# ---------------------------------------------------------------------------
# Test: mode is restored after an exception raised inside the with block
# ---------------------------------------------------------------------------


@pytest.mark.skipif(IS_WINDOWS, reason="chmod write-protection is a no-op on Windows")
def test_mode_restored_after_exception_inside_context(tmp_path: Path) -> None:
    """Original file mode is restored even when an exception is raised inside the with block."""
    state_path = tmp_path / "state.json"
    state_path.write_text('{"version": 1}')
    original_mode = state_path.stat().st_mode & 0o777

    with pytest.raises(RuntimeError):
        with protect_state_file(state_path):
            raise RuntimeError("something went wrong")

    restored_mode = state_path.stat().st_mode & 0o777
    assert restored_mode == original_mode


@pytest.mark.skipif(IS_WINDOWS, reason="chmod write-protection is a no-op on Windows")
def test_file_is_writable_after_normal_exit(tmp_path: Path) -> None:
    """File is writable again after the context exits normally."""
    state_path = tmp_path / "state.json"
    state_path.write_text('{"version": 1}')
    original_mode = state_path.stat().st_mode & 0o777

    with protect_state_file(state_path):
        pass  # no exception

    restored_mode = state_path.stat().st_mode & 0o777
    assert restored_mode == original_mode
    # Confirm it's actually writable now.
    state_path.write_text("after context")
    assert state_path.read_text() == "after context"


# ---------------------------------------------------------------------------
# Test: no-op when file does not exist
# ---------------------------------------------------------------------------


def test_noop_when_file_does_not_exist(tmp_path: Path) -> None:
    """protect_state_file is a no-op when state_path does not exist."""
    state_path = tmp_path / "nonexistent_state.json"
    assert not state_path.exists()

    # Should not raise; body executes normally.
    body_executed = False
    with protect_state_file(state_path):
        body_executed = True

    assert body_executed
    assert not state_path.exists()


def test_noop_when_file_does_not_exist_preserves_exception(tmp_path: Path) -> None:
    """No-op mode still propagates exceptions from within the block."""
    state_path = tmp_path / "nonexistent_state.json"

    with pytest.raises(ValueError, match="propagated"):
        with protect_state_file(state_path):
            raise ValueError("propagated")
