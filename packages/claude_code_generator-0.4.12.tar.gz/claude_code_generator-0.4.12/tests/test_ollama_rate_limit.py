"""Tests for Ollama 429 / Retry-After rate-limit handling (issue #221).

TDD: Red → Green.

The existing ``rate_limit.main_loop`` already handles ``RateLimitHit`` via
wait-and-resume (non-negotiable #5). This issue adds a second signal source
for Ollama 429 responses: a public ``handle_ollama_429`` helper that mirrors
the Anthropic ``_handle_rejected_rate_limit`` semantics (persist
``paused_until``, raise ``RateLimitHit``) but reads the wait interval from
the HTTP ``Retry-After`` header instead of ``RateLimitEvent.resets_at``.

The Anthropic codepath is explicitly untouched — its tests remain valid.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import pytest

from code_generator import state as _state
from code_generator.runner.rate_limit import (
    OLLAMA_DEFAULT_RETRY_AFTER_SECONDS,
    OLLAMA_MAX_RETRY_AFTER_SECONDS,
    OLLAMA_RATE_LIMIT_TYPE,
    handle_ollama_429,
)
from code_generator.runner.types import RateLimitHit

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------


class TestOllamaRateLimitConstants:
    def test_default_retry_after_is_60_seconds(self) -> None:
        """When Retry-After is missing, the handler waits a documented default."""
        assert OLLAMA_DEFAULT_RETRY_AFTER_SECONDS == 60

    def test_max_retry_after_caps_at_4_hours(self) -> None:
        """An absurd Retry-After value is clamped to a sane ceiling (4h)."""
        assert OLLAMA_MAX_RETRY_AFTER_SECONDS == 14400

    def test_rate_limit_type_label_is_stable(self) -> None:
        """The rate-limit-type label is a stable identifier for analytics."""
        assert OLLAMA_RATE_LIMIT_TYPE == "ollama_429"


# ---------------------------------------------------------------------------
# handle_ollama_429 — basic behaviour
# ---------------------------------------------------------------------------


class TestHandleOllama429WithRetryAfter:
    def test_persists_paused_until_with_60s_buffer(self, tmp_path: Path) -> None:
        """paused_until = now + retry_after + 60s safety buffer (non-negotiable #5)."""
        state_path = tmp_path / ".code-generator" / "state.json"
        state_path.parent.mkdir(parents=True, exist_ok=True)
        _state.save_state(state_path, _state.load_state(state_path))

        retry_after = 120
        now = 1_000_000.0

        with pytest.raises(RateLimitHit):
            handle_ollama_429(
                retry_after_seconds=retry_after,
                session_id="sess-ollama",
                state_path=state_path,
                logger=logging.getLogger("test.o429"),
                now_fn=lambda: now,
            )

        st = _state.load_state(state_path)
        assert st.paused_until == int(now + retry_after + 60)
        assert st.session_id == "sess-ollama"
        assert st.rate_limit_type == OLLAMA_RATE_LIMIT_TYPE

    def test_raises_rate_limit_hit_with_rate_limit_type(self, tmp_path: Path) -> None:
        """The raised RateLimitHit carries the ollama_429 type identifier."""
        state_path = tmp_path / ".code-generator" / "state.json"
        state_path.parent.mkdir(parents=True, exist_ok=True)
        _state.save_state(state_path, _state.load_state(state_path))

        with pytest.raises(RateLimitHit) as excinfo:
            handle_ollama_429(
                retry_after_seconds=90,
                session_id=None,
                state_path=state_path,
                logger=logging.getLogger("test.o429"),
                now_fn=lambda: 2000.0,
            )

        assert excinfo.value.rate_limit_type == OLLAMA_RATE_LIMIT_TYPE
        assert excinfo.value.resets_at == int(2000.0 + 90 + 60)


# ---------------------------------------------------------------------------
# Missing Retry-After header → documented default + warning
# ---------------------------------------------------------------------------


class TestMissingRetryAfterHeader:
    def test_missing_retry_after_falls_back_to_default(self, tmp_path: Path) -> None:
        """Retry-After=None → use OLLAMA_DEFAULT_RETRY_AFTER_SECONDS."""
        state_path = tmp_path / ".code-generator" / "state.json"
        state_path.parent.mkdir(parents=True, exist_ok=True)
        _state.save_state(state_path, _state.load_state(state_path))

        now = 50_000.0
        with pytest.raises(RateLimitHit):
            handle_ollama_429(
                retry_after_seconds=None,
                session_id=None,
                state_path=state_path,
                logger=logging.getLogger("test.o429.none"),
                now_fn=lambda: now,
            )

        st = _state.load_state(state_path)
        expected = int(now + OLLAMA_DEFAULT_RETRY_AFTER_SECONDS + 60)
        assert st.paused_until == expected

    def test_missing_retry_after_logs_warning(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """A warning naming the default wait is emitted when the header is missing."""
        state_path = tmp_path / ".code-generator" / "state.json"
        state_path.parent.mkdir(parents=True, exist_ok=True)
        _state.save_state(state_path, _state.load_state(state_path))

        with caplog.at_level(logging.WARNING), pytest.raises(RateLimitHit):
            handle_ollama_429(
                retry_after_seconds=None,
                session_id=None,
                state_path=state_path,
                logger=logging.getLogger("test.o429.warn"),
                now_fn=lambda: 0.0,
            )

        warnings = [r for r in caplog.records if r.levelno == logging.WARNING]
        assert any("Retry-After" in r.message for r in warnings)
        assert any(str(OLLAMA_DEFAULT_RETRY_AFTER_SECONDS) in r.message for r in warnings)


# ---------------------------------------------------------------------------
# Cap on absurd Retry-After values
# ---------------------------------------------------------------------------


class TestAbsurdRetryAfterCap:
    def test_retry_after_above_max_is_clamped(self, tmp_path: Path) -> None:
        """An absurd Retry-After (e.g. 1 week) is clamped to the max constant."""
        state_path = tmp_path / ".code-generator" / "state.json"
        state_path.parent.mkdir(parents=True, exist_ok=True)
        _state.save_state(state_path, _state.load_state(state_path))

        absurd = 7 * 24 * 3600  # 1 week
        now = 100.0

        with pytest.raises(RateLimitHit):
            handle_ollama_429(
                retry_after_seconds=absurd,
                session_id=None,
                state_path=state_path,
                logger=logging.getLogger("test.o429.cap"),
                now_fn=lambda: now,
            )

        st = _state.load_state(state_path)
        expected = int(now + OLLAMA_MAX_RETRY_AFTER_SECONDS + 60)
        assert st.paused_until == expected

    def test_cap_logs_warning_naming_max(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """A warning naming the cap is emitted when the wait is clamped."""
        state_path = tmp_path / ".code-generator" / "state.json"
        state_path.parent.mkdir(parents=True, exist_ok=True)
        _state.save_state(state_path, _state.load_state(state_path))

        with caplog.at_level(logging.WARNING), pytest.raises(RateLimitHit):
            handle_ollama_429(
                retry_after_seconds=1_000_000,
                session_id=None,
                state_path=state_path,
                logger=logging.getLogger("test.o429.cap"),
                now_fn=lambda: 0.0,
            )

        warnings = [r for r in caplog.records if r.levelno == logging.WARNING]
        assert any(str(OLLAMA_MAX_RETRY_AFTER_SECONDS) in r.message for r in warnings)

    def test_negative_retry_after_clamps_to_default(self, tmp_path: Path) -> None:
        """A negative Retry-After (malformed server) falls back to the default."""
        state_path = tmp_path / ".code-generator" / "state.json"
        state_path.parent.mkdir(parents=True, exist_ok=True)
        _state.save_state(state_path, _state.load_state(state_path))

        with pytest.raises(RateLimitHit):
            handle_ollama_429(
                retry_after_seconds=-5,
                session_id=None,
                state_path=state_path,
                logger=logging.getLogger("test.o429.neg"),
                now_fn=lambda: 0.0,
            )

        st = _state.load_state(state_path)
        expected = int(0.0 + OLLAMA_DEFAULT_RETRY_AFTER_SECONDS + 60)
        assert st.paused_until == expected


# ---------------------------------------------------------------------------
# Session-id preservation for resume
# ---------------------------------------------------------------------------


class TestSessionIdPreserved:
    def test_session_id_persisted_for_resume(self, tmp_path: Path) -> None:
        """The session_id is stored so main_loop can set options.resume on retry."""
        state_path = tmp_path / ".code-generator" / "state.json"
        state_path.parent.mkdir(parents=True, exist_ok=True)
        _state.save_state(state_path, _state.load_state(state_path))

        with pytest.raises(RateLimitHit):
            handle_ollama_429(
                retry_after_seconds=30,
                session_id="sess-ollama-resume",
                state_path=state_path,
                logger=logging.getLogger("test.o429.sid"),
                now_fn=lambda: 0.0,
            )

        st = _state.load_state(state_path)
        assert st.session_id == "sess-ollama-resume"

    def test_missing_session_id_stays_none(self, tmp_path: Path) -> None:
        """A None session_id is persisted as None (unchanged)."""
        state_path = tmp_path / ".code-generator" / "state.json"
        state_path.parent.mkdir(parents=True, exist_ok=True)
        _state.save_state(state_path, _state.load_state(state_path))

        with pytest.raises(RateLimitHit):
            handle_ollama_429(
                retry_after_seconds=30,
                session_id=None,
                state_path=state_path,
                logger=logging.getLogger("test.o429.nosid"),
                now_fn=lambda: 0.0,
            )

        st = _state.load_state(state_path)
        assert st.session_id is None


# ---------------------------------------------------------------------------
# Anthropic path untouched (non-429 transient still backs off, not waits)
# ---------------------------------------------------------------------------


class TestAnthropicPathUntouched:
    def test_rate_limit_module_still_exports_main_loop(self) -> None:
        """``main_loop`` is still the primary wait-and-resume entry point."""
        from code_generator.runner import rate_limit

        assert hasattr(rate_limit, "main_loop")

    def test_existing_handle_rate_limit_event_still_present(self) -> None:
        """The Anthropic RateLimitEvent handler is not modified or removed."""
        from code_generator.runner import message_parsing

        assert hasattr(message_parsing, "handle_rate_limit_event")
        assert hasattr(message_parsing, "_handle_rejected_rate_limit")

    @pytest.mark.asyncio
    async def test_api_upstream_error_still_uses_backoff_not_wait_and_resume(
        self, tmp_path: Path
    ) -> None:
        """Non-429 transient ApiUpstreamError still goes through the upstream
        backoff (10/20/40/80/120-ish) path, not the wait-and-resume branch.

        Guards against regression where the new 429 handler accidentally
        captures upstream 5xx errors too.
        """
        from unittest.mock import AsyncMock

        from code_generator.runner.rate_limit import main_loop
        from code_generator.runner.types import ApiUpstreamError, RunResult

        state_path = tmp_path / ".code-generator" / "state.json"
        state_path.parent.mkdir(parents=True, exist_ok=True)
        _state.save_state(state_path, _state.load_state(state_path))

        # First call raises ApiUpstreamError; second call succeeds.
        runner = AsyncMock()
        runner.run = AsyncMock(
            side_effect=[
                ApiUpstreamError("fake upstream 5xx"),
                RunResult(text="ok", session_id="sess-ok", tokens_in=1, tokens_out=2),
            ]
        )

        sleep_calls: list[float] = []

        async def fake_sleep(secs: float) -> None:
            sleep_calls.append(secs)

        class FakeOptions:
            def __init__(self) -> None:
                self.resume: str | None = None

        result = await main_loop(
            runner,
            "prompt",
            FakeOptions(),
            state_path=state_path,
            logger=logging.getLogger("test.upstream"),
            now_fn=lambda: 0.0,
            sleep_fn=fake_sleep,
        )

        assert result.text == "ok"
        # The upstream-backoff first delay is 60s; the 429 path would be
        # longer (at least default 60 + 60s buffer = 120s). Asserting the
        # first sleep is ≤60 distinguishes the backoff path from the
        # wait-and-resume path.
        assert sleep_calls, "Expected at least one sleep call (backoff)"
        assert sleep_calls[0] <= 60, (
            f"First sleep {sleep_calls[0]}s indicates wait-and-resume leaked "
            "into the ApiUpstreamError path — expected backoff (≤60s)"
        )
