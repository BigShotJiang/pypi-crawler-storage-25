"""Docs guards for the Ollama Pro subcommand (issue #223).

Three artefacts must carry the Ollama codepath end-to-end so operators
and future maintainers both see it:

- **README.md** — a ``Running against Ollama Pro`` section covering the
  one-time ``ollama signin``, the reuse of ``OLLAMA_API_KEY`` (no new
  secret), and at least two worked subcommand examples.
- **CLAUDE.md** non-negotiables #1, #4, and #8 — each annotated with a
  scoped exception pointing to the ``provider == "ollama"`` gate and the
  ``code-generator generate ollama`` subcommand.
- **CLAUDE.md** ``## Architecture`` — a short subsection summarizing the
  single-model Ollama path: what is overridden, what is preserved.

Mirrors the pattern in ``tests/test_docs_no_default_max_turns.py``.
"""

from __future__ import annotations

import re
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
_README = _REPO_ROOT / "README.md"
_CLAUDE_MD = _REPO_ROOT / "CLAUDE.md"


def _non_negotiables_section() -> str:
    """Return the ``## Non-negotiable constraints`` block from CLAUDE.md."""
    text = _CLAUDE_MD.read_text(encoding="utf-8")
    match = re.search(
        r"^## Non-negotiable constraints(.*?)(?=^## |\Z)",
        text,
        re.DOTALL | re.MULTILINE,
    )
    assert match, "Missing '## Non-negotiable constraints' section in CLAUDE.md"
    return match.group(1)


def _architecture_section() -> str:
    """Return the ``## Architecture`` block from CLAUDE.md."""
    text = _CLAUDE_MD.read_text(encoding="utf-8")
    match = re.search(
        r"^## Architecture(.*?)(?=^## |\Z)",
        text,
        re.DOTALL | re.MULTILINE,
    )
    assert match, "Missing '## Architecture' section in CLAUDE.md"
    return match.group(1)


# ---------------------------------------------------------------------------
# README — "Running against Ollama Pro" section (AC #1)
# ---------------------------------------------------------------------------


def test_readme_running_against_ollama_pro_section_exists() -> None:
    """README must expose a section titled 'Running against Ollama Pro'."""
    text = _README.read_text(encoding="utf-8")
    assert re.search(r"^#{2,4} Running against Ollama Pro", text, re.MULTILINE), (
        "README must expose a 'Running against Ollama Pro' heading"
    )


def test_readme_ollama_section_documents_signin_and_reuses_api_key() -> None:
    """The section must cover one-time ``ollama signin`` and ``OLLAMA_API_KEY`` reuse."""
    text = _README.read_text(encoding="utf-8")
    section = _extract_readme_ollama_section(text)
    assert "ollama signin" in section, (
        "Ollama Pro section must mention the one-time 'ollama signin' setup"
    )
    assert "OLLAMA_API_KEY" in section, (
        "Ollama Pro section must name OLLAMA_API_KEY as the reused secret"
    )


def test_readme_ollama_section_has_two_worked_examples() -> None:
    """At least two executable ``code-generator generate ollama --model <tag>`` examples."""
    text = _README.read_text(encoding="utf-8")
    section = _extract_readme_ollama_section(text)
    examples = re.findall(
        r"code-generator generate ollama --model \S+",
        section,
    )
    assert len(examples) >= 2, (
        f"Ollama Pro section must carry at least 2 worked examples; found {len(examples)}"
    )


def _extract_readme_ollama_section(text: str) -> str:
    """Slice the Ollama Pro heading up to the next heading of the same or shallower rank."""
    heading_match = re.search(r"^(#{2,4}) Running against Ollama Pro$", text, re.MULTILINE)
    assert heading_match, "README 'Running against Ollama Pro' section not found"
    rank = len(heading_match.group(1))
    start = heading_match.end()
    # Stop only at the *same* rank ("## " for a rank-2 heading) so that nested
    # subsections ("### ...") and shell comments inside fenced code blocks
    # ("# Plan ...") are not misread as a section boundary.
    stop_pattern = rf"^#{{{rank}}}(?!#) "
    stop_match = re.search(stop_pattern, text[start:], re.MULTILINE)
    end = start + stop_match.start() if stop_match else len(text)
    return text[start:end]


# ---------------------------------------------------------------------------
# CLAUDE.md non-negotiables #1, #4, #8 — scoped-exception annotations (AC #2)
# ---------------------------------------------------------------------------


def test_non_negotiable_1_carries_ollama_scoped_exception() -> None:
    """Non-negotiable #1 (Max subscription only) must note the Ollama bypass + gate."""
    section = _non_negotiables_section()
    nn1 = _extract_numbered_item(section, 1)
    assert 'provider == "ollama"' in nn1, (
        'Non-negotiable #1 must reference the provider == "ollama" gate'
    )
    assert "generate ollama" in nn1, (
        "Non-negotiable #1 must reference the `code-generator generate ollama` subcommand"
    )


def test_non_negotiable_4_carries_ollama_scoped_exception() -> None:
    """Non-negotiable #4 (overage protection) must note the Ollama bypass + gate."""
    section = _non_negotiables_section()
    nn4 = _extract_numbered_item(section, 4)
    assert 'provider == "ollama"' in nn4, (
        'Non-negotiable #4 must reference the provider == "ollama" gate'
    )
    assert "generate ollama" in nn4, (
        "Non-negotiable #4 must reference the `code-generator generate ollama` subcommand"
    )


def test_non_negotiable_8_carries_ollama_scoped_exception() -> None:
    """Non-negotiable #8 (fixed model per phase) must note the Ollama bypass + gate."""
    section = _non_negotiables_section()
    nn8 = _extract_numbered_item(section, 8)
    assert 'provider == "ollama"' in nn8, (
        'Non-negotiable #8 must reference the provider == "ollama" gate'
    )
    assert "generate ollama" in nn8, (
        "Non-negotiable #8 must reference the `code-generator generate ollama` subcommand"
    )


def _extract_numbered_item(section: str, number: int) -> str:
    """Extract item N from a numbered list, up to the next top-level number or blank line."""
    pattern = rf"^{number}\. (.*?)(?=^\d+\. |^## |\Z)"
    match = re.search(pattern, section, re.DOTALL | re.MULTILINE)
    assert match, f"Non-negotiable #{number} not found"
    return match.group(1)


# ---------------------------------------------------------------------------
# CLAUDE.md Architecture — single-model Ollama subsection (AC #3)
# ---------------------------------------------------------------------------


def test_architecture_has_single_model_ollama_subsection() -> None:
    """Architecture section must summarize the single-model Ollama path."""
    section = _architecture_section()
    assert "single-model" in section.lower(), (
        "Architecture section must mention single-model routing for the Ollama path"
    )
    assert "ollama" in section.lower(), "Architecture section must name the Ollama path"


def test_architecture_subsection_lists_overridden_and_preserved_invariants() -> None:
    """The subsection must explicitly call out what is overridden vs. preserved."""
    section = _architecture_section().lower()
    assert "overridden" in section or "override" in section, (
        "Architecture Ollama subsection must state which invariants are overridden"
    )
    assert "preserved" in section or "still enforced" in section or "still apply" in section, (
        "Architecture Ollama subsection must state which invariants are preserved"
    )
