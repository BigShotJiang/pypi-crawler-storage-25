"""Tests asserting pinned dependency constraints in pyproject.toml."""

import tomllib
from pathlib import Path

_PYPROJECT_PATH = Path(__file__).resolve().parents[1] / "pyproject.toml"


def _load_dependencies() -> list[str]:
    with _PYPROJECT_PATH.open("rb") as f:
        data = tomllib.load(f)
    return data["project"]["dependencies"]


def test_claude_agent_sdk_pin_exists() -> None:
    """pyproject.toml must pin claude-agent-sdk to the 0.3.x minor line.

    The exact string 'claude-agent-sdk>=0.3.0,<0.4.0' must appear in
    [project].dependencies so that major-version bumps are blocked at
    install time (Requirements §18).
    """
    deps = _load_dependencies()
    assert "claude-agent-sdk>=0.3.0,<0.4.0" in deps
