"""Tests for the `code-generator status` command."""

import time
from pathlib import Path

import pytest
from typer.testing import CliRunner

from code_generator import state as state_module
from code_generator.cli import app

runner = CliRunner()


def _write_state(path: Path, st: state_module.State) -> None:
    state_module.save_state(path, st)


def test_no_state_file_prints_friendly_message(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "init" in result.output


def test_single_mode_state_shows_mode_and_phase(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.load_state(cg_dir / "missing.json")
    st.mode = "single"
    st.phase = 3
    st.issues = [
        state_module.IssueState(number=1, status="open", agent="python-pro"),
        state_module.IssueState(number=2, status="closed", agent="python-pro"),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "single" in result.output
    assert "3" in result.output
    # open count = 1, closed = 1
    assert "1" in result.output


def test_multi_cycle_state_renders_cycle_rows(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.load_state(cg_dir / "missing.json")
    st.mode = "multi-cycle"
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=1,
            milestone_title="Milestone 1",
            status="completed",
            phase=7,
            issues=[state_module.IssueState(number=1, status="closed", agent="python-pro")],
            commit_sha="abc123",
        ),
        state_module.CycleState(
            id=2,
            name="Cycle 2",
            milestone_number=2,
            milestone_title="Milestone 2",
            status="in-progress",
            phase=3,
            issues=[
                state_module.IssueState(number=2, status="open", agent="python-pro"),
                state_module.IssueState(number=3, status="closed", agent="python-pro"),
            ],
            commit_sha=None,
        ),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "Cycle 1" in result.output
    assert "Cycle 2" in result.output
    assert "completed" in result.output
    assert "in-progress" in result.output


def _make_multi_cycle_state() -> state_module.State:
    """Helper: build a multi-cycle state with rich CycleState data."""
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=10,
            milestone_title="Milestone 10",
            status="completed",
            phase=7,
            issues=[state_module.IssueState(number=1, status="closed", agent="python-pro")],
            commit_sha="abc123",
            scope="Set up core database models and migrations",
            depends_on=[],
        ),
        state_module.CycleState(
            id=2,
            name="Cycle 2",
            milestone_number=11,
            milestone_title="Milestone 11",
            status="in-progress",
            phase=3,
            issues=[
                state_module.IssueState(number=2, status="open", agent="python-pro"),
                state_module.IssueState(number=3, status="closed", agent="python-pro"),
            ],
            commit_sha=None,
            scope="Implement REST API endpoints for user management",
            depends_on=[1],
        ),
    ]
    return st


def test_cycles_table_renders_scope_column(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = _make_multi_cycle_state()
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "scope" in result.output
    assert "Set up core database" in result.output
    assert "Implement REST API" in result.output


def test_cycles_table_renders_depends_on_column(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = _make_multi_cycle_state()
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "depends on" in result.output
    # cycle 1 has no deps → "—"; cycle 2 depends on [1] → "1"
    assert "1" in result.output


def test_cycles_table_renders_milestone_column(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = _make_multi_cycle_state()
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "milestone" in result.output
    assert "#10" in result.output
    assert "#11" in result.output


def test_cycles_table_shows_checkmark_for_completed_status(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = _make_multi_cycle_state()
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "✓" in result.output


def test_cycles_table_renders_dash_for_missing_scope_and_deps(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=None,
            milestone_title="",
            status="in-progress",
            phase=1,
            issues=[],
            commit_sha=None,
            scope="",
            depends_on=[],
        ),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    # "None" should never appear
    assert "None" not in result.output
    # em dash for empty scope, deps, and milestone
    assert "—" in result.output


def test_summary_table_shows_requirements_hash_when_present(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.load_state(cg_dir / "missing.json")
    st.mode = "single"
    # Simulate the requirements_hash field added by issue #109 — may not exist yet
    object.__setattr__(st, "requirements_hash", "abcdef1234567890") if not hasattr(
        st, "requirements_hash"
    ) else setattr(st, "requirements_hash", "abcdef1234567890")
    _write_state(cg_dir / "state.json", st)

    # Reload to simulate normal flow (hash may not survive save/load yet)
    # so we test the rendering function directly via monkeypatching load_state
    import unittest.mock as mock

    st_with_hash = state_module.load_state(cg_dir / "state.json")
    st_with_hash.__dict__["requirements_hash"] = "abcdef1234567890"

    with mock.patch(
        "code_generator.commands.status.state_module.load_state", return_value=st_with_hash
    ):
        result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "requirements hash" in result.output
    assert "abcdef12" in result.output  # truncated to 8 chars


def test_paused_state_shows_minutes_remaining(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.load_state(cg_dir / "missing.json")
    st.paused_until = int(time.time()) + 120
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "2" in result.output
    assert "minute" in result.output


# ---------------------------------------------------------------------------
# New tests for issue #125: token columns, wall-clock, last_error rendering
# ---------------------------------------------------------------------------


def _make_token_usage(
    input: int = 0,
    output: int = 0,
    cache_read: int = 0,
    cache_write: int = 0,
    num_turns: int = 0,
) -> state_module.TokenUsage:
    from code_generator.runner.types import TokenUsage

    return TokenUsage(
        input=input,
        output=output,
        cache_read=cache_read,
        cache_write=cache_write,
        num_turns=num_turns,
    )


def test_multi_cycle_token_columns_show_correct_values(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """When cycles have populated token_usage, correct summed values appear in columns."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=1,
            milestone_title="M1",
            status="completed",
            phase=7,
            issues=[],
            commit_sha=None,
            token_usage={
                "phase3": _make_token_usage(input=100, output=50, cache_read=200, cache_write=30),
                "phase4": _make_token_usage(input=10, output=5, cache_read=20, cache_write=3),
            },
        ),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    # summed: input=110, output=55, cache_read=220, cache_write=33
    assert "110" in result.output
    assert "55" in result.output
    assert "220" in result.output
    assert "33" in result.output


def test_multi_cycle_turns_column_shows_accumulated_num_turns(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Issue #211: Turns column renders the summed ``num_turns`` across phases."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=1,
            milestone_title="M1",
            status="completed",
            phase=7,
            issues=[],
            commit_sha=None,
            token_usage={
                "phase3_4": _make_token_usage(input=100, num_turns=42),
            },
        ),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    # The cycles table gains a "Turns" header and the row shows 42.
    assert "Turns" in result.output
    assert "42" in result.output


def test_multi_cycle_turns_column_shows_zero_for_pre_upgrade_state(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Issue #211: legacy token_usage without ``num_turns`` renders ``0`` (no crash)."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    # Old state: TokenUsage is constructed without num_turns so the field
    # defaults to 0 via the dataclass default (same as reading pre-0.3.1 JSON).
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=1,
            milestone_title="M1",
            status="completed",
            phase=7,
            issues=[],
            commit_sha=None,
            token_usage={
                "phase3_4": _make_token_usage(input=100),
            },
        ),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "Turns" in result.output
    # The row for cycle 1 must carry a literal "0" in the Turns column and
    # must not crash with KeyError.
    assert "0" in result.output


def test_pre_upgrade_cycle_shows_dash_in_token_columns(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Pre-upgrade cycles with empty token_usage render — in all four token columns."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=1,
            milestone_title="M1",
            status="completed",
            phase=7,
            issues=[],
            commit_sha=None,
            token_usage={},  # pre-upgrade: empty
        ),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "—" in result.output
    assert result.exit_code == 0  # no crash


def test_wall_clock_column_shows_formatted_duration(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Cycles with started_at and finished_at render formatted duration in wall-clock column."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=1,
            milestone_title="M1",
            status="completed",
            phase=7,
            issues=[],
            commit_sha=None,
            started_at="2026-01-01T10:00:00Z",
            finished_at="2026-01-01T11:23:00Z",  # 1h 23m
        ),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "1h 23m" in result.output


def test_wall_clock_column_shows_minutes_seconds_for_short_duration(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Cycles shorter than 1h render as Xm Ys in wall-clock column."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=1,
            milestone_title="M1",
            status="completed",
            phase=7,
            issues=[],
            commit_sha=None,
            started_at="2026-01-01T10:00:00Z",
            finished_at="2026-01-01T10:45:30Z",  # 45m 30s
        ),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "45m 30s" in result.output


def test_wall_clock_column_shows_dash_when_timestamps_missing(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Cycles with missing started_at or finished_at render — in wall-clock column."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=1,
            milestone_title="M1",
            status="in-progress",
            phase=3,
            issues=[],
            commit_sha=None,
            started_at=None,
            finished_at=None,
        ),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "—" in result.output


def test_pct_5h_column_shows_correct_percentage(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """% of 5h column shows sum(cache_read)/50_000_000*100 for each cycle."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    # 5_000_000 cache_read = 10.0% of 50_000_000 budget
    st.cycles = [
        state_module.CycleState(
            id=1,
            name="Cycle 1",
            milestone_number=1,
            milestone_title="M1",
            status="completed",
            phase=7,
            issues=[],
            commit_sha=None,
            token_usage={
                "phase3": _make_token_usage(cache_read=3_000_000),
                "phase4": _make_token_usage(cache_read=2_000_000),
            },
        ),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "10.0%" in result.output


def test_last_error_renders_in_red_at_top(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """When last_error is set, red error banner appears and no plain-text row in summary."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.load_state(cg_dir / "missing.json")
    st.mode = "single"
    st.last_error = "phase 3 failed: timeout"
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    # red banner text is present
    assert "phase 3 failed: timeout" in result.output
    # the plain-text "last error" row in the summary table must NOT appear
    assert "last error" not in result.output


def test_no_red_banner_when_last_error_is_none(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """When last_error is None, no red error banner in output."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.load_state(cg_dir / "missing.json")
    st.mode = "single"
    st.last_error = None
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "Last error" not in result.output
    assert "⚠" not in result.output


def test_single_cycle_mode_shows_token_totals_in_summary(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Single-cycle mode: summary table shows token totals summed across phases."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="single", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.token_usage = {
        "phase3": _make_token_usage(input=500, output=100, cache_read=1000, cache_write=50),
        "phase5": _make_token_usage(input=200, output=40, cache_read=400, cache_write=20),
    }
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    # "Tokens" row group header should appear
    assert "Tokens" in result.output
    # summed: input=700, output=140, cache_read=1400, cache_write=70
    assert "700" in result.output
    assert "140" in result.output
    assert "1400" in result.output
    assert "70" in result.output


# ---------------------------------------------------------------------------
# Issue #191: Cache hit % column and CycleTelemetrySummary rendering
# ---------------------------------------------------------------------------


def _make_cycle_with_telemetry(
    cycle_id: int,
    cache_hit_pct: float = 0.0,
    wall_seconds: float = 0.0,
) -> state_module.CycleState:
    return state_module.CycleState(
        id=cycle_id,
        name=f"Cycle {cycle_id}",
        milestone_number=cycle_id,
        milestone_title=f"Milestone {cycle_id}",
        status="completed",
        phase=7,
        issues=[],
        commit_sha=None,
        cache_telemetry={
            "input": 100,
            "output": 50,
            "cache_read": 200,
            "cache_write": 30,
            "cache_hit_pct": cache_hit_pct,
            "wall_seconds": wall_seconds,
        },
    )


def test_cache_hit_pct_column_renders_when_populated(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Cache hit % column shows XX.X% format when cache_hit_pct is non-zero."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [_make_cycle_with_telemetry(1, cache_hit_pct=67.3)]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "67.3%" in result.output
    assert "Cache hit %" in result.output


def test_cache_hit_pct_column_renders_dash_when_all_zero(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Cache hit % column renders '-' (not '0.0%') when all telemetry values are zero."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [_make_cycle_with_telemetry(1, cache_hit_pct=0.0)]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "0.0%" not in result.output
    assert "-" in result.output


def test_cache_hit_pct_column_renders_dash_for_legacy_state(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Legacy state without cache_telemetry renders '-' in Cache hit % column without error."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()

    import json

    raw = {
        "mode": "multi-cycle",
        "started_at": "2026-01-01T00:00:00Z",
        "updated_at": "2026-01-01T00:00:00Z",
        "cycles": [
            {
                "id": 1,
                "name": "Legacy Cycle",
                "milestone_number": 1,
                "milestone_title": "Milestone 1",
                "status": "completed",
                "phase": 7,
                "issues": [],
                "commit_sha": None,
                # No cache_telemetry — legacy format
            }
        ],
    }
    (cg_dir / "state.json").write_text(json.dumps(raw))

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "0.0%" not in result.output
    assert "Cache hit %" in result.output


def test_status_12_cycles_shows_2_summary_rows_and_10_detail_rows(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """status on a 12-cycle state shows 10 full detail rows + 2 summary rows."""
    from code_generator.runner.types import TokenUsage

    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        state_module.CycleState(
            id=i,
            name=f"Cycle {i}",
            milestone_number=i,
            milestone_title=f"Milestone {i}",
            status="completed",
            phase=7,
            issues=[state_module.IssueState(number=i, status="closed", agent="python-pro")],
            commit_sha=f"sha{i}",
            token_usage={
                "phase3": TokenUsage(input=100, output=50, cache_read=200, cache_write=30)
            },
            cache_telemetry={
                "input": 100,
                "output": 50,
                "cache_read": 200,
                "cache_write": 30,
                "cache_hit_pct": 45.5,
                "wall_seconds": 120.0,
            },
        )
        for i in range(1, 13)
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0

    # 12 cycle names should appear: Cycle 1 through Cycle 12
    for i in range(1, 13):
        assert f"Cycle {i}" in result.output

    # Summary indicator: "(summary)" or similar text should appear for old cycles
    assert "summary" in result.output.lower()


def test_summary_cycle_row_shows_retained_fields(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Summary cycle rows (from retention) show cycle name, total_tokens, cache_hit_pct, wall_seconds."""
    from code_generator.runner.types import TokenUsage

    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        state_module.CycleState(
            id=i,
            name=f"Cycle {i}",
            milestone_number=i,
            milestone_title=f"Milestone {i}",
            status="completed",
            phase=7,
            issues=[],
            commit_sha=None,
            token_usage={
                "phase3": TokenUsage(input=100, output=50, cache_read=200, cache_write=30)
            },
            cache_telemetry={
                "input": 100,
                "output": 50,
                "cache_read": 200,
                "cache_write": 30,
                "cache_hit_pct": 33.3,
                "wall_seconds": 90.0,
            },
        )
        for i in range(1, 13)
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    # Cache hit pct for detail rows should appear (last 10 cycles)
    assert "33.3%" in result.output


# ---------------------------------------------------------------------------
# Issue #222: "Model" column rendering (Ollama tag / Anthropic Max default)
# ---------------------------------------------------------------------------


def _make_cycle_with_model(cid: int, ollama_model: str | None) -> state_module.CycleState:
    """Build a minimal CycleState with an optional ollama_model tag."""
    return state_module.CycleState(
        id=cid,
        name=f"Cycle {cid}",
        milestone_number=cid,
        milestone_title=f"M{cid}",
        status="completed",
        phase=7,
        issues=[],
        commit_sha=None,
        ollama_model=ollama_model,
    )


def test_model_column_header_present_in_cycles_table(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """The cycles table advertises a ``Model`` column header."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [_make_cycle_with_model(1, ollama_model=None)]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])

    assert result.exit_code == 0
    assert "Model" in result.output


def test_ollama_cycle_row_shows_ollama_prefixed_tag(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A cycle with ollama_model set renders ``ollama:<tag>`` in the Model column."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [_make_cycle_with_model(1, ollama_model="qwen3-coder:480b:cloud")]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])

    assert result.exit_code == 0
    assert "ollama:qwen3-coder:480b:cloud" in result.output


def test_anthropic_max_cycle_row_shows_anthropic_max_label(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A cycle without ollama_model renders a non-empty ``anthropic-max`` label."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [_make_cycle_with_model(1, ollama_model=None)]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])

    assert result.exit_code == 0
    # Default: the Anthropic Max path is labelled, not left blank.
    assert "anthropic-max" in result.output


def test_mixed_cycles_render_distinct_model_labels(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Snapshot-style check: two cycles with different providers surface
    distinguishable Model values in the same table render."""
    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        _make_cycle_with_model(1, ollama_model=None),
        _make_cycle_with_model(2, ollama_model="gpt-oss:120b-cloud"),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])

    assert result.exit_code == 0
    assert "anthropic-max" in result.output
    assert "ollama:gpt-oss:120b-cloud" in result.output


def test_format_model_unit_helper_returns_anthropic_max_by_default() -> None:
    """Unit-test the _format_model helper directly for the no-Ollama case."""
    from code_generator.commands.status import _format_model

    cycle = _make_cycle_with_model(1, ollama_model=None)
    assert _format_model(cycle) == "anthropic-max"


def test_format_model_unit_helper_returns_prefixed_ollama_tag() -> None:
    """Unit-test the _format_model helper directly for the Ollama case."""
    from code_generator.commands.status import _format_model

    cycle = _make_cycle_with_model(1, ollama_model="my-model:7b")
    assert _format_model(cycle) == "ollama:my-model:7b"


def test_summary_row_renders_without_crash_when_model_column_added(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Regression guard: adding the Model column must not break summary rows.

    CycleTelemetrySummary rows don't carry a model — they must render a
    sentinel (``—``) in the new column without raising.
    """
    from code_generator.state_retention import CycleTelemetrySummary

    monkeypatch.chdir(tmp_path)
    cg_dir = tmp_path / ".code-generator"
    cg_dir.mkdir()
    st = state_module.State(
        mode="multi-cycle", started_at="2026-01-01T00:00:00Z", updated_at="2026-01-01T00:00:00Z"
    )
    st.cycles = [
        CycleTelemetrySummary(
            cycle_name="Old",
            total_tokens=1000,
            cache_hit_pct=50.0,
            wall_seconds=120.0,
        ),
        _make_cycle_with_model(2, ollama_model="qwen:latest"),
    ]
    _write_state(cg_dir / "state.json", st)

    result = runner.invoke(app, ["status"])

    assert result.exit_code == 0
    # Summary row renders (column count matches), and the Ollama cycle still
    # displays its tag beside it.
    assert "ollama:qwen:latest" in result.output
    assert "Old" in result.output  # summary row's cycle_name
