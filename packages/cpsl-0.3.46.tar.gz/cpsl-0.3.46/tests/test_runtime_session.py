import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from cpsl.db import reset_active_identity, set_active_identity
from cpsl.session import RequestContext, Session, SessionChannel, UserInfo, current_session
from cpsl.task_types import TaskDescriptor


class RuntimeSessionTests(unittest.TestCase):
    def test_current_session_returns_active_session(self):
        session = Session(
            id="",
            user=UserInfo(id="owner-123", org_id="org_123"),
            channel=SessionChannel(type="chat"),
            history=[],
            data={},
        )
        token = set_active_identity(session)
        try:
            self.assertIs(current_session(), session)
        finally:
            reset_active_identity(token)

    def test_current_session_ignores_non_session_identity(self):
        ctx = RequestContext(user=UserInfo(id="user-123"), integrations={})
        token = set_active_identity(ctx)
        try:
            self.assertIsNone(current_session())
        finally:
            reset_active_identity(token)

    def test_task_descriptor_detects_session_parameter_anywhere(self):
        async def with_session(session, value):
            return value

        async def with_trailing_session(value, session=None):
            return value

        async def without_session(value):
            return value

        class Example:
            async def method_with_session(self, session, value):
                return value

            async def method_with_trailing_session(self, value, session=None):
                return value

            async def method_without_session(self, value):
                return value

        self.assertTrue(TaskDescriptor(with_session)._wants_session)
        self.assertTrue(TaskDescriptor(with_trailing_session)._wants_session)
        self.assertFalse(TaskDescriptor(without_session)._wants_session)
        self.assertTrue(TaskDescriptor(Example.method_with_session)._wants_session)
        self.assertTrue(TaskDescriptor(Example.method_with_trailing_session)._wants_session)
        self.assertFalse(TaskDescriptor(Example.method_without_session)._wants_session)


if __name__ == "__main__":
    unittest.main()
