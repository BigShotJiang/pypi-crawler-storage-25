# Copyright 2024 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Package of Pathways-on-Cloud utilities."""
from collections.abc import Callable
from pathwaysutils import _initialize

initialize: Callable[[], None] = _initialize.initialize
is_pathways_backend_used: Callable[[], bool] = _initialize.is_pathways_backend_used

del _initialize

# When changing this, also update the CHANGELOG.md.
__version__ = "v0.1.8"
