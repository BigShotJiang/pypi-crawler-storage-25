# src/uncoded/__init__.py

from importlib.metadata import version

__version__ = version('uncoded')
