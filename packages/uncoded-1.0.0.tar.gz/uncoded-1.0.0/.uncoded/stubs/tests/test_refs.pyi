# tests/test_refs.py

import io
import json
import subprocess
import textwrap
from pathlib import Path
from unittest import mock
import pytest
from uncoded.refs import TY_VERSION, Reference, _find_root, _LSPLocation, _query_references, _read_message, _read_response, _run_exchange, _terminate, _to_rel_path, find_refs
from uncoded.resolver import NamePath

def _lsp_stream(*msgs: dict) -> io.BytesIO:
    ...

def _init_response() -> dict:
    ...

def _shutdown_response() -> dict:
    ...

class TestFindRefs:
    def test_returns_empty_for_dead_symbol(self, tmp_path):
        ...

    def test_finds_multiple_references_across_files(self, tmp_path):
        ...

    def test_class_method_shape(self, tmp_path):
        ...

    def test_results_are_sorted(self, tmp_path):
        ...

    def test_line_and_col_are_one_indexed(self, tmp_path):
        ...

    def test_path_with_spaces_is_not_percent_encoded(self, tmp_path):
        ...

class TestToRelPath:
    def test_returns_relative_path_when_under_cwd(self, tmp_path, monkeypatch):
        ...

    def test_returns_absolute_path_when_outside_cwd(self, tmp_path, monkeypatch):
        ...

class TestQueryReferences:
    def test_finds_call_sites(self, tmp_path):
        ...

    def test_uvx_not_found_raises_runtime_error(self, tmp_path):
        ...

    def test_returns_empty_list_when_no_references(self, tmp_path):
        ...

    def test_returns_lsp_locations_when_popen_succeeds(self, tmp_path):
        ...

class TestRunExchange:
    def test_lsp_error_raises(self, tmp_path):
        ...

    def test_empty_result_list_returns_empty(self, tmp_path):
        ...

class TestFindRoot:
    def test_returns_pyproject_parent_when_found(self, tmp_path):
        ...

    def test_returns_in_path_parent_when_not_found(self, tmp_path):
        ...

class TestTerminate:
    def test_kills_on_timeout(self):
        ...

class TestReadMessage:
    def test_raises_on_closed_stream(self):
        ...

    def test_parses_framed_message(self):
        ...

class TestReadResponse:
    def test_skips_notifications_until_matching_id(self):
        ...
