import subprocess
import sys
import json
import os

# ألوان الترمينال
class Colors:
    RED = '\033[91m'
    ORANGE = '\033[93m'  # مش موجود في ANSI قديم، فهنستخدم Yellow
    YELLOW = '\033[93m'
    GREEN = '\033[92m'
    CYAN = '\033[96m'
    BOLD = '\033[1m'
    END = '\033[0m'

def print_colored(text, color):
    print(f"{color}{text}{Colors.END}")

def calculate_score(vulns):
    score = 100
    for v in vulns:
        sev = v.get("severity", "").upper()
        if sev == "CRITICAL":
            score -= 10
        elif sev == "HIGH":
            score -= 5
        elif sev == "MEDIUM":
            score -= 2
        elif sev == "LOW":
            score -= 1
    return max(0, min(100, score))

def scan_image(image_name):
    print_colored(f"\n[+] DockerIQ: Scanning image '{image_name}'...", Colors.CYAN)

    # تأكد إن Trivy مثبت
    result = subprocess.run(["which", "trivy"], capture_output=True, text=True)
    if result.returncode != 0:
        print_colored("❌ DockerIQ Error: Required scanner not found.", Colors.RED)
        print("👉 Install it: curl -sfL https://raw.githubusercontent.com/aquasecurity/trivy/main/contrib/install.sh | sh -s -- -b /usr/local/bin")
        sys.exit(1)

    # شغّل Trivy بصمت، واحصل على JSON
    try:
        result = subprocess.run([
            "trivy", "image",
            "--quiet",
            "--skip-db-update",
            "--format", "json",
            image_name
        ], capture_output=True, text=True, check=True)
    except subprocess.CalledProcessError as e:
        if e.returncode == 1:
            # Trivy بيطلع exit code 1 لو لقى ثغرات — ده طبيعي
            result = e
        else:
            print_colored(f"❌ Scan failed: {e}", Colors.RED)
            sys.exit(1)

    try:
        data = json.loads(result.stdout)
    except json.JSONDecodeError:
        print_colored("❌ Invalid scan output.", Colors.RED)
        sys.exit(1)

    # استخرج الثغرات
    vulns = []
    for res in data.get("Results", []):
        for v in res.get("Vulnerabilities", []):
            vulns.append({
                "pkg": v.get("PkgName", "unknown"),
                "id": v.get("VulnerabilityID", "N/A"),
                "severity": v.get("Severity", "UNKNOWN").upper(),
                "title": v.get("Title", "No title available")
            })

    # احسب الدرجات
    critical = [v for v in vulns if v["severity"] == "CRITICAL"]
    high = [v for v in vulns if v["severity"] == "HIGH"]
    medium = [v for v in vulns if v["severity"] == "MEDIUM"]
    low = [v for v in vulns if v["severity"] == "LOW"]

    total = len(vulns)
    score = calculate_score(vulns)

    # عرض النتيجة
    if total == 0:
        print_colored("\n✅ DockerIQ: No vulnerabilities found!", Colors.GREEN)
        print_colored(f"🛡️  Security Score: {score}/100", Colors.BOLD)
    else:
        print_colored(f"\n🚨 DockerIQ: Found {total} vulnerabilities", Colors.RED)
        print_colored(f"🛡️  Security Score: {score}/100", Colors.BOLD)

        # عرض الأعداد
        print(f"\n📊 Summary:")
        if critical:
            print_colored(f"   🔴 Critical: {len(critical)}", Colors.RED)
        if high:
            print_colored(f"   🟠 High: {len(high)}", Colors.ORANGE)
        if medium:
            print_colored(f"   🟡 Medium: {len(medium)}", Colors.YELLOW)
        if low:
            print_colored(f"   🟢 Low: {len(low)}", Colors.GREEN)

        # عرض الثغرات
        print(f"\n🔍 Details:")
        for v in vulns:
            sev = v["severity"]
            icon = "🔴" if sev == "CRITICAL" else "🟠" if sev == "HIGH" else "🟡" if sev == "MEDIUM" else "🟢"
            color = Colors.RED if sev == "CRITICAL" else Colors.ORANGE if sev == "HIGH" else Colors.YELLOW if sev == "MEDIUM" else Colors.GREEN
            pkg = v["pkg"]
            vid = v["id"]
            title = v["title"][:80] + "..." if len(v["title"]) > 80 else v["title"]
            print_colored(f"   {icon} [{sev}] {vid} in `{pkg}`", color)
            print(f"      → {title}\n")

def main():
    if len(sys.argv) != 3 or sys.argv[1] != "scan":
        print("Usage: dockeriq scan <image-name>")
        print("Example: dockeriq scan nginx:latest")
        sys.exit(1)

    image = sys.argv[2]
    scan_image(image)

if __name__ == "__main__":
    main()

