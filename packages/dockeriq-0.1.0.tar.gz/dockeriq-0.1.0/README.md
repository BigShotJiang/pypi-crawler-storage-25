# DockerIQ CLI

Scan Docker images for security vulnerabilities directly from your terminal.

## Requirements
- Docker
- Trivy (install from: https://github.com/aquasecurity/trivy)

## Install
```bash
pip install dockeriq

