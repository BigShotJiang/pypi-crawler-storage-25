from __future__ import annotations

__all__ = ["search"]
