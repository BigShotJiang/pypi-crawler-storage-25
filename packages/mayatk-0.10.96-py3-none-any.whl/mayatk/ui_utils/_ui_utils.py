# !/usr/bin/python
# coding=utf-8
import maya.cmds as cmds
from typing import Optional



class UiUtils:
    @staticmethod
    def get_main_window():
        """Get the main Maya window as a QMainWindow instance.

        Robust implementation supporting PySide2 (Maya < 2024) and PySide6 (Maya >= 2024).
        """
        from qtpy import QtWidgets
        import maya.OpenMayaUI as omui

        ptr = omui.MQtUtil.mainWindow()
        if not ptr:
            return None

        # Try shiboken6 first (newer Maya)
        try:
            from shiboken6 import wrapInstance

            return wrapInstance(int(ptr), QtWidgets.QMainWindow)
        except ImportError:
            pass

        # Try shiboken2 next (older Maya)
        try:
            from shiboken2 import wrapInstance

            return wrapInstance(int(ptr), QtWidgets.QMainWindow)
        except ImportError:
            return None

    @staticmethod
    def get_menu_name(qt_object_name: str) -> Optional[str]:
        """Retrieve the internal Maya name of a menu given its Qt object name."""
        import maya.OpenMayaUI as omui

        # Find the control associated with the given Qt object name
        ptr = omui.MQtUtil.findControl(qt_object_name)
        if ptr is not None:
            # Convert the pointer to an integer and get the full Maya menu name
            maya_menu_name = omui.MQtUtil.fullName(int(ptr))
            if maya_menu_name:
                print(f"Derived Maya menu name: {maya_menu_name}")
                return maya_menu_name
            else:
                print(
                    f"Failed to derive the Maya menu name from Qt object '{qt_object_name}'."
                )
                return None
        else:
            print(f"Failed to find the pointer for the Qt object '{qt_object_name}'.")
            return None

    @staticmethod
    def get_panel(*args, **kwargs):
        """Returns panel and panel configuration information.
        Returns Maya panel info via the cmds.getPanel command.

        Parameters:
            [allConfigs=boolean], [allPanels=boolean], [allScriptedTypes=boolean], [allTypes=boolean], [configWithLabel=string], [containing=string], [invisiblePanels=boolean], [scriptType=string], [type=string], [typeOf=string], [underPointer=boolean], [visiblePanels=boolean], [withFocus=boolean], [withLabel=string])

        Returns:
            (str) An array of panel names.
        """
        from maya.cmds import getPanel

        result = getPanel(*args, **kwargs)

        return result

    @staticmethod
    def main_progress_bar(size, name="progressBar#", step_amount=1):
        """# add esc key pressed return False

        Parameters:
            size (int): total amount
            name (str): name of progress bar created
            step_amount(int): increment amount

        Example:
            main_progress_bar (len(edges), progressCount)
            cmds.progressBar ("progressBar_", edit=1, step=1)
            if cmds.progressBar ("progressBar_", q=True, isCancelled=1):
                break
            cmds.progressBar ("progressBar_", edit=1, endProgress=1)

            to use main progressBar: name=string $gMainProgressBar
        """
        status = "processing: {} items ..".format(size)

        edit = False
        if cmds.progressBar(name, exists=1):
            edit = True

        cmds.progressBar(
            name,
            edit=edit,
            beginProgress=1,
            isInterruptable=True,
            status=status,
            maxValue=size,
            step=step_amount,
        )

    @staticmethod
    def list_ui_objects():
        """List all UI objects."""
        ui_objects = {
            "windows": cmds.lsUI(windows=True),
            "panels": cmds.lsUI(panels=True),
            "editors": cmds.lsUI(editors=True),
            "menus": cmds.lsUI(menus=True),
            "menuItems": cmds.lsUI(menuItems=True),
            "controls": cmds.lsUI(controls=True),
            "controlLayouts": cmds.lsUI(controlLayouts=True),
            "contexts": cmds.lsUI(contexts=True),
        }
        for category, objects in ui_objects.items():
            print(f"{category}:\n{objects}\n")

    @staticmethod
    def clear_scrollfield_reporters():
        """Clears the contents of all cmdScrollFieldReporter UI objects in the current Maya session.

        This function is useful for cleaning up the script output display in Maya's UI,
        particularly before executing scripts or operations that generate a lot of output.
        It iterates over all cmdScrollFieldReporter objects and clears them, ensuring a clean
        slate for viewing new script or command output.
        """
        # Get a list of all UI objects of type "cmdScrollFieldReporter"
        reporters = cmds.lsUI(type="cmdScrollFieldReporter")

        # If any reporters are found, clear them
        for reporter in reporters:
            cmds.cmdScrollFieldReporter(reporter, edit=True, clear=True)

    @staticmethod
    def reveal_in_outliner(objects):
        """Reveal and select objects in the Outliner panel."""
        if not objects:
            return
        outliner_editor = cmds.outlinerPanel(
            "outlinerPanel1", query=True, outlinerEditor=True
        )
        cmds.select(objects, replace=True)
        cmds.outlinerEditor(outliner_editor, edit=True, showSelected=True)

    @staticmethod
    def dispatch_log_link(url, logger=None) -> bool:
        """Handle ``action://`` links emitted by ``log_link()`` in a QTextBrowser.

        Supported actions:
            ``select`` — select *node* in the Maya viewport.
            ``reveal`` — select *node* and reveal it in the Outliner.

        Parameters:
            url:    A ``QUrl`` from ``QTextBrowser.anchorClicked``.
            logger: Optional logger for debug/warning messages.

        Returns:
            True if the link was handled, False otherwise.
        """
        import os
        from urllib.parse import parse_qs
        from maya import cmds

        if url.scheme() != "action":
            return False

        action = url.host()
        params = parse_qs(url.query())

        # Non-node actions -------------------------------------------------
        if action == "open":
            filepath = params.get("filepath", [""])[0]
            if not filepath:
                return False
            try:
                os.startfile(filepath)
            except OSError as e:
                if logger:
                    logger.warning(f"Could not open file: {e}")
                return False
            return True

        # Node-based actions -----------------------------------------------
        node = params.get("node", [""])[0]

        if not node:
            return False

        if not cmds.objExists(node):
            if logger:
                logger.warning(f"Object not found: {node}")
            return False

        if action == "select":
            cmds.select(node, replace=True)
        elif action == "reveal":
            cmds.select(node, replace=True)
            panels = cmds.getPanel(type="outlinerPanel") or []
            if panels:
                editor = cmds.outlinerPanel(panels[0], query=True, outlinerEditor=True)
                cmds.outlinerEditor(editor, edit=True, showSelected=True)
        else:
            if logger:
                logger.debug(f"Unknown log link action: {action}")
            return False

        return True


# --------------------------------------------------------------------------------------------

if __name__ == "__main__":
    ...

# --------------------------------------------------------------------------------------------
# Notes
# --------------------------------------------------------------------------------------------
