# !/usr/bin/python
# coding=utf-8
import pythontk as ptk

# from this package:
from mayatk.core_utils.preview import Preview
from mayatk.edit_utils._edit_utils import EditUtils


class MirrorSlots(ptk.LoggingMixin):
    def __init__(self, switchboard, log_level="INFO"):
        self.sb = switchboard
        self.ui = self.sb.loaded_ui.mirror

        self.logger.setLevel(log_level)
        self.logger.set_log_prefix("[Mirror] ")

        self.preview = Preview(
            self, self.ui.chk000, self.ui.b000, message_func=self.sb.message_box
        )

        # Connect sliders and checkboxes to preview refresh function
        self.sb.connect_multi(
            self.ui, "cmb000-1", "currentIndexChanged", self.preview.refresh
        )
        self.sb.connect_multi(self.ui, "chk001-6", "clicked", self.preview.refresh)

    def header_init(self, widget):
        """Configure header menu with tool instructions."""
        widget.menu.add("Separator", setTitle="About")
        widget.menu.add(
            "QPushButton",
            setText="Instructions",
            setObjectName="btn_instructions",
            setToolTip=(
                "Mirror — Mirror selected geometry across an axis.\n\n"
                "• Choose axis (X, Y, Z) and pivot reference.\n"
                "• Merge border vertices option.\n"
                "• Enable Preview for non-destructive iteration."
            ),
        )

    def perform_operation(self, objects):
        # Read values from UI
        axis = self.sb.get_axis_from_checkboxes(
            "chk001-4", self.ui
        )  # Get axis from checkboxes
        pivot_index = (
            self.ui.cmb000.currentIndex()
        )  # Get UI selection for pivot dropdown
        pivot = self._resolve_pivot(
            pivot_index, axis
        )  # Dynamically resolve correct pivot

        mergeMode = (
            self.ui.cmb001.currentIndex() - 1
        )  # Adjust mergeMode to match Method signature (-1 for correct mapping)

        kwargs = {
            "axis": axis,
            "pivot": pivot,
            "mergeMode": mergeMode,
            "uninstance": self.ui.chk005.isChecked(),  # Uninstance objects before mirroring
            "delete_original": self.ui.chk006.isChecked(),  # Delete original half
        }

        EditUtils.mirror(objects, **kwargs)

    @staticmethod
    def _resolve_pivot(pivot_index: int, axis: str) -> str:
        axis_mapping = {
            "x": "xmax",
            "-x": "xmax",
            "y": "ymax",
            "-y": "ymax",
            "z": "zmax",
            "-z": "zmax",
        }

        pivot_mapping = {
            0: "manip",
            1: "object",
            2: "world",
            3: "center",
            4: axis_mapping.get(axis, "xmax"),
        }

        return pivot_mapping.get(pivot_index, "manip")


# -----------------------------------------------------------------------------

if __name__ == "__main__":
    from mayatk.ui_utils.maya_ui_handler import MayaUiHandler

    ui = MayaUiHandler.instance().get("mirror", reload=True)
    ui.show(pos="screen", app_exec=True)

# -----------------------------------------------------------------------------
# Notes
# -----------------------------------------------------------------------------
