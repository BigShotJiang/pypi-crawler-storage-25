"""
Tickerr Reporter — LiteLLM callback that reports LLM API failures to Tickerr.

Usage:
    from tickerr_reporter import TickerrReporter
    import litellm

    litellm.callbacks = [TickerrReporter()]

Or via env var (zero-code integration):
    TICKERR_AUTO=1 python your_agent.py
"""

from .callback import TickerrReporter

__all__ = ["TickerrReporter"]
__version__ = "0.1.0"
