"""
TickerrReporter — LiteLLM CustomLogger that fire-and-forgets
failure signals to https://tickerr.ai/api/v1/report.

Zero overhead on success paths: only fires on 5xx / timeout failures.
All network calls are async and non-blocking — your agent is never slowed down.
"""

from __future__ import annotations

import asyncio
import re
import threading
import time
from typing import Any

REPORT_URL = "https://tickerr.ai/api/v1/report"
UA = "tickerr-reporter-python/0.1.0"

# Map LiteLLM provider names → Tickerr provider names
_PROVIDER_MAP: dict[str, str] = {
    "openai":         "openai",
    "anthropic":      "anthropic",
    "google":         "google",
    "cohere":         "cohere",
    "mistral":        "mistral",
    "groq":           "groq",
    "together_ai":    "together",
    "together":       "together",
    "huggingface":    "huggingface",
    "replicate":      "replicate",
    "deepinfra":      "deepinfra",
    "perplexity":     "perplexity",
    "fireworks_ai":   "fireworks",
    "fireworks":      "fireworks",
    "openrouter":     "openrouter",
    "azure":          "azure",
    "vertex_ai":      "google",
    "bedrock":        "aws",
    "ai21":           "ai21",
    "nlp_cloud":      "nlp_cloud",
    "ollama":         "ollama",
    "cerebras":       "cerebras",
    "xai":            "xai",
}

# Map status codes → Tickerr error_type strings
_ERROR_TYPE_MAP: dict[int, str] = {
    429: "rate_limit",
    529: "overloaded",
    503: "overloaded",
    500: "overloaded",
    408: "timeout",
    524: "timeout",
    401: "auth",
    403: "auth",
}


def _normalize_provider(model: str, kwargs: dict[str, Any]) -> str:
    """Best-effort provider extraction from LiteLLM kwargs or model string."""
    # LiteLLM sets litellm_params.custom_llm_provider
    custom = (
        kwargs.get("litellm_params", {}).get("custom_llm_provider")
        or kwargs.get("custom_llm_provider")
        or ""
    )
    if custom:
        return _PROVIDER_MAP.get(custom.lower(), custom.lower())

    # Fall back to model prefix: "anthropic/claude-..." → "anthropic"
    if "/" in model:
        prefix = model.split("/")[0].lower()
        return _PROVIDER_MAP.get(prefix, prefix)

    # Known model name patterns
    if re.match(r"^claude", model, re.I):
        return "anthropic"
    if re.match(r"^gpt|^o[1-9]", model, re.I):
        return "openai"
    if re.match(r"^gemini", model, re.I):
        return "google"
    if re.match(r"^mistral|^mixtral", model, re.I):
        return "mistral"
    if re.match(r"^llama", model, re.I):
        return "meta"
    if re.match(r"^command", model, re.I):
        return "cohere"
    if re.match(r"^grok", model, re.I):
        return "xai"
    if re.match(r"^deepseek", model, re.I):
        return "deepseek"

    return "unknown"


def _extract_status_code(exception: BaseException | None) -> int | None:
    """Pull HTTP status code from LiteLLM exception, if any."""
    if exception is None:
        return None
    # LiteLLM exceptions carry .status_code
    code = getattr(exception, "status_code", None)
    if isinstance(code, int):
        return code
    # Some exceptions carry it as a string
    if isinstance(code, str) and code.isdigit():
        return int(code)
    return None


def _fire_and_forget(payload: dict[str, Any]) -> None:
    """Send report in a background daemon thread — no await, no blocking."""

    def _send() -> None:
        try:
            import urllib.request, json as _json
            data = _json.dumps(payload).encode()
            req = urllib.request.Request(
                REPORT_URL,
                data=data,
                headers={"Content-Type": "application/json", "User-Agent": UA},
                method="POST",
            )
            # 5s timeout — silently drop if Tickerr is unreachable
            with urllib.request.urlopen(req, timeout=5):
                pass
        except Exception:
            pass  # never crash the caller

    t = threading.Thread(target=_send, daemon=True)
    t.start()


class TickerrReporter:
    """
    LiteLLM CustomLogger — drop-in callback that reports LLM failures to Tickerr.

    Install:
        litellm.callbacks = [TickerrReporter()]

    Optional env vars:
        TICKERR_CLIENT_TIER  — "free" | "pro" | "team" | "enterprise" | "api_pay_as_you_go"
        TICKERR_REGION       — e.g. "us-east-1"
    """

    def __init__(
        self,
        client_tier: str | None = None,
        region: str | None = None,
        report_successes: bool = False,
    ) -> None:
        import os
        self.client_tier = client_tier or os.environ.get("TICKERR_CLIENT_TIER")
        self.region = region or os.environ.get("TICKERR_REGION")
        self.report_successes = report_successes

    # ── LiteLLM CustomLogger interface ────────────────────────────────────────

    def log_failure_event(
        self,
        kwargs: dict[str, Any],
        response_obj: Any,
        start_time: float,
        end_time: float,
    ) -> None:
        """Called by LiteLLM on any failed API call."""
        self._report(kwargs, response_obj, start_time, end_time, is_resolution=False)

    def log_success_event(
        self,
        kwargs: dict[str, Any],
        response_obj: Any,
        start_time: float,
        end_time: float,
    ) -> None:
        """Called by LiteLLM on successful API calls (only reports if report_successes=True)."""
        if self.report_successes:
            self._report(kwargs, response_obj, start_time, end_time, is_resolution=True)

    # Async variants (LiteLLM calls these if defined)
    async def async_log_failure_event(
        self,
        kwargs: dict[str, Any],
        response_obj: Any,
        start_time: float,
        end_time: float,
    ) -> None:
        self.log_failure_event(kwargs, response_obj, start_time, end_time)

    async def async_log_success_event(
        self,
        kwargs: dict[str, Any],
        response_obj: Any,
        start_time: float,
        end_time: float,
    ) -> None:
        self.log_success_event(kwargs, response_obj, start_time, end_time)

    # ── Internal ──────────────────────────────────────────────────────────────

    def _report(
        self,
        kwargs: dict[str, Any],
        response_obj: Any,
        start_time: float,
        end_time: float,
        is_resolution: bool,
    ) -> None:
        model: str = kwargs.get("model", "") or ""
        exception: BaseException | None = kwargs.get("exception")
        latency_ms = round((end_time - start_time) * 1000)

        provider = _normalize_provider(model, kwargs)
        status_code = _extract_status_code(exception)
        error_type = _ERROR_TYPE_MAP.get(status_code, "overloaded") if status_code else None

        # Strip provider prefix from model name if present (e.g. "anthropic/claude-3-5-haiku")
        model_clean = model.split("/", 1)[-1] if "/" in model else model

        payload: dict[str, Any] = {
            "provider": provider,
            "model": model_clean or None,
            "is_resolution": is_resolution,
            "latency_ms": latency_ms,
        }
        if status_code is not None:
            payload["error_code"] = status_code
        if error_type:
            payload["error_type"] = error_type
        if self.client_tier:
            payload["client_tier"] = self.client_tier
        if self.region:
            payload["region"] = self.region

        _fire_and_forget(payload)
