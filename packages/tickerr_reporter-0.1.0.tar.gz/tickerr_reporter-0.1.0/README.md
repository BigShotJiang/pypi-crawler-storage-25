# tickerr-reporter

LiteLLM callback that reports LLM API failures to [Tickerr](https://tickerr.ai) — outage radar for AI agents.

When your agent hits a 5xx or rate limit, this fires a background report to Tickerr. In return, your agent gets live signal from other agents hitting the same issue — and a routing recommendation.

Zero overhead. No API key. Anonymous.

## Install

```bash
pip install tickerr-reporter
```

## Usage

```python
import litellm
from tickerr_reporter import TickerrReporter

litellm.callbacks = [TickerrReporter()]

# Now use litellm normally — failures are reported automatically
response = litellm.completion(
    model="claude-haiku-4-5",
    messages=[{"role": "user", "content": "Hello"}]
)
```

That's it. Every failed LiteLLM call fires a background POST to `tickerr.ai/api/v1/report`. It's non-blocking — your agent never waits for it.

## What gets reported

- Provider (e.g. `anthropic`, `openai`)
- Model name
- HTTP status code (429, 503, 529, etc.)
- Error type (rate_limit, overloaded, timeout, auth)
- Latency in ms

No request content. No prompts. No responses. No personal data.

## What you get back (via Tickerr)

Each report updates the live signal at [tickerr.ai/agent-reports](https://tickerr.ai/agent-reports).

To read the signal directly, use the [Tickerr MCP](https://tickerr.ai/mcp-server) `report_incident` tool — it returns:

- How many agents are seeing the same issue
- Current signal state: `quiet` / `detecting` / `confirmed` / `recovering`
- Which model to fall back to

## Options

```python
TickerrReporter(
    client_tier="pro",       # "free" | "pro" | "team" | "enterprise" | "api_pay_as_you_go"
    region="us-east-1",      # optional, for regional signal breakdown
    report_successes=True,   # also report successful calls (recovery signals)
)
```

Or via env vars:

```bash
TICKERR_CLIENT_TIER=pro
TICKERR_REGION=us-east-1
```

## Opt out

[tickerr.ai/mcp/opt-out](https://tickerr.ai/mcp/opt-out)

## Direct REST API (no LiteLLM)

If you're not using LiteLLM, report directly:

```bash
curl -X POST https://tickerr.ai/api/v1/report \
  -H "Content-Type: application/json" \
  -d '{"provider": "anthropic", "model": "claude-haiku-4-5", "error_code": 529, "error_type": "overloaded"}'
```

## Links

- [Tickerr](https://tickerr.ai) — live AI status dashboard
- [Tickerr MCP](https://tickerr.ai/mcp-server) — 9-tool MCP server for agents
- [Agent reports](https://tickerr.ai/agent-reports) — live feed
- [Opt out](https://tickerr.ai/mcp/opt-out)
