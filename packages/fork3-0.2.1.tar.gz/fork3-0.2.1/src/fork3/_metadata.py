"""Lineage metadata I/O for fork3."""

import tomllib
from pathlib import Path

import tomli_w

from ._output import FORK3_DIR, LINEAGES_DIR


def ensure_fork3_dir(workspace_root: Path) -> Path:
    """Create .fork3/lineages/ under *workspace_root* if missing; return .fork3/ path."""
    fork3 = workspace_root / FORK3_DIR
    lineages = fork3 / LINEAGES_DIR
    lineages.mkdir(parents=True, exist_ok=True)
    return fork3


def derive_lineage_id(relative_path: str) -> str:
    """Derive a lineage ID from a relative path by replacing '/' with '-'."""
    return relative_path.replace("/", "-").replace("\\", "-")


def read_lineage_toml(path: Path) -> dict:
    """Read and parse a lineage TOML file at *path*."""
    with open(path, "rb") as f:
        return tomllib.load(f)


def write_lineage_toml(path: Path, data: dict) -> None:
    """Serialize *data* to TOML and write to *path* atomically."""
    tmp = path.with_suffix(".toml.tmp")
    with open(tmp, "wb") as f:
        tomli_w.dump(data, f)
    tmp.rename(path)


def list_lineages(workspace_root: Path) -> list[str]:
    """Return sorted lineage IDs from .fork3/lineages/*.toml filenames."""
    lineages_dir = workspace_root / FORK3_DIR / LINEAGES_DIR
    if not lineages_dir.is_dir():
        return []
    return sorted(p.stem for p in lineages_dir.glob("*.toml"))


def lineage_exists(workspace_root: Path, lineage_id: str) -> bool:
    """Return True if a lineage TOML for *lineage_id* already exists."""
    path = workspace_root / FORK3_DIR / LINEAGES_DIR / f"{lineage_id}.toml"
    return path.is_file()
