"""Create and init commands for fork3."""

import argparse
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

from ._output import (
    FORK3_DIR,
    LINEAGES_DIR,
    info,
    ok,
    warn,
    error_exit,
)
from ._models import CopyInfo, WorkspaceContext
from ._git import (
    git_clone,
    git_checkout_new_branch,
    git_push,
    git_fetch_all,
    git_set_remote_url,
    git_remote_names,
    git_remote_url,
    git_current_branch,
    git_ls_remote,
)
from ._metadata import (
    ensure_fork3_dir,
    read_lineage_toml,
    write_lineage_toml,
    lineage_exists,
    derive_lineage_id,
)
from ._workspace import (
    build_workspace_context_for_create,
    resolve_workspace_root_for_setup,
    select_remote,
    classify_slots,
    replicate_uv_env,
)


def create_command(args: argparse.Namespace) -> None:
    """Create or expand a fork3 lineage (full 13-step flow)."""
    ctx = build_workspace_context_for_create(args)
    n = args.copies
    uv_flag = args.uv

    if lineage_exists(ctx.workspace_root, ctx.lineage_id):
        existing_toml = (
            ctx.workspace_root / FORK3_DIR / LINEAGES_DIR / f"{ctx.lineage_id}.toml"
        )
        existing_data = read_lineage_toml(existing_toml)
        try:
            existing_meta = existing_data["lineage"]
        except KeyError:
            error_exit(
                f"Malformed lineage file: {existing_toml} — missing [lineage] section"
            )
        try:
            existing_target = existing_meta["target_repo"]
        except KeyError:
            error_exit(
                f"Malformed lineage file: {existing_toml} — missing required field 'target_repo'"
            )
        if str(ctx.target_repo.relative_to(ctx.workspace_root)) != existing_target:
            error_exit(
                f"Lineage ID '{ctx.lineage_id}' already exists for a different repo."
            )

    for rname in git_remote_names(ctx.target_repo):
        rurl = git_remote_url(ctx.target_repo, rname)
        if not git_ls_remote(rurl):
            error_exit(f"Remote '{rname}' ({rurl}) is unreachable.")

    if uv_flag and not (ctx.target_repo / ".venv").is_dir():
        error_exit(
            f"--uv requested but {ctx.target_repo} has no .venv directory."
        )

    slots = classify_slots(ctx.workspace_root, ctx.repo_name, n, ctx.remote_url, ctx.remote_name)
    invalid = [(i, l, p) for i, l, p, s in slots if s == "invalid"]
    if invalid:
        paths = ", ".join(str(p) for _, _, p in invalid)
        error_exit(f"Invalid data in existing slot(s): {paths}")

    existing = [(i, l, p) for i, l, p, s in slots if s == "existing"]
    missing = [(i, l, p) for i, l, p, s in slots if s == "missing"]

    info(f"lineage: {ctx.lineage_id}")
    info(f"repo:    {ctx.repo_name}")
    info(f"remote:  {ctx.remote_name} -> {ctx.remote_url}")
    info(f"copies:  {n} total ({len(existing) + 1} existing, {len(missing)} to create)")
    print()

    for _, label, _ in existing:
        ok(f"{label} — exists, skipping")

    if not missing:
        print()
        info("all copies already exist — nothing to do")
        return

    for seq, (i, label, slot_path) in enumerate(missing, 1):
        branch_name = f"feat{i}"
        print(f"[{seq}/{len(missing)}] creating {label}/{ctx.repo_name}")
        slot_path.parent.mkdir(parents=True, exist_ok=True)
        git_clone(ctx.target_repo, slot_path)
        git_set_remote_url(slot_path, ctx.remote_name, ctx.remote_url)
        git_checkout_new_branch(slot_path, branch_name)
        git_push(slot_path, ctx.remote_name, branch_name, set_upstream=True)
        if uv_flag:
            replicate_uv_env(ctx.target_repo, slot_path)
            ok(f"{label}/{ctx.repo_name} -> branch: {branch_name} (pushed, uv env replicated)")
        else:
            ok(f"{label}/{ctx.repo_name} -> branch: {branch_name} (pushed)")

    print()
    info("syncing all copies …")
    all_copy_paths = [ctx.target_repo] + [
        ctx.workspace_root / f"branch{i}" / ctx.repo_name
        for i in range(1, n)
    ]
    all_labels = ["original"] + [f"branch{i}" for i in range(1, n)]
    with ThreadPoolExecutor(max_workers=min(len(all_copy_paths), 8)) as pool:
        futures = {
            pool.submit(git_fetch_all, p): lbl
            for p, lbl in zip(all_copy_paths, all_labels)
        }
        for fut in as_completed(futures):
            lbl = futures[fut]
            try:
                fut.result()
                ok(f"{lbl} fetched")
            except subprocess.CalledProcessError:
                warn(f"fetch failed for {lbl}")

    _update_lineage_toml(ctx, n)

    print()
    info(f"done — {n} copies ready ({len(missing)} newly created)")


def _update_lineage_toml(ctx: WorkspaceContext, copy_count: int) -> None:
    """Create or update the lineage TOML under .fork3/lineages/.

    On updates, copy_count is never decreased — this prevents silently
    orphaning existing offspring directories.
    """
    ensure_fork3_dir(ctx.workspace_root)
    toml_path = (
        ctx.workspace_root / FORK3_DIR / LINEAGES_DIR / f"{ctx.lineage_id}.toml"
    )
    if toml_path.is_file():
        data = read_lineage_toml(toml_path)
        try:
            existing_count = int(data["lineage"]["copy_count"])
        except KeyError as e:
            error_exit(f"Malformed lineage file: {toml_path} — missing required field {e}")
        except (TypeError, ValueError):
            error_exit(f"Malformed lineage file: {toml_path} — 'copy_count' must be an integer")
        data["lineage"]["copy_count"] = max(copy_count, existing_count)
    else:
        data = {
            "lineage": {
                "id": ctx.lineage_id,
                "repo_name": ctx.repo_name,
                "target_repo": str(ctx.target_repo.relative_to(ctx.workspace_root)),
                "remote_name": ctx.remote_name,
                "remote_url": ctx.remote_url,
                "copy_count": copy_count,
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
        }
    write_lineage_toml(toml_path, data)


def _scan_offspring(
    workspace_root: Path, repo_name: str, remote_url: str, remote_name: str = "origin",
) -> list[tuple[int, str, Path, str]]:
    """Scan workspace root for branchN/<repo_name>/ directories.

    Returns a list of (index, label, path, status) tuples where status is
    'valid', 'not_git', or 'remote_mismatch'.
    """
    results: list[tuple[int, str, Path, str]] = []
    branch_dirs = [
        e for e in workspace_root.iterdir()
        if e.is_dir() and e.name.startswith("branch") and e.name[len("branch"):].isdigit()
    ]
    branch_dirs.sort(key=lambda p: int(p.name[len("branch"):]))
    for entry in branch_dirs:
        suffix = entry.name[len("branch"):]
        idx = int(suffix)
        slot_path = entry / repo_name
        if not slot_path.is_dir():
            continue
        label = f"branch{idx}"
        if not (slot_path / ".git").exists():
            results.append((idx, label, slot_path, "not_git"))
            continue
        try:
            actual_url = git_remote_url(slot_path, remote_name)
            if actual_url == remote_url:
                results.append((idx, label, slot_path, "valid"))
            else:
                results.append((idx, label, slot_path, "remote_mismatch"))
        except subprocess.CalledProcessError:
            results.append((idx, label, slot_path, "remote_error"))
    return results


def init_command(args: argparse.Namespace) -> None:
    """Adopt an existing layout as a fork3 lineage."""
    ref_repo = Path(args.reference_repo).resolve()

    if not ref_repo.is_dir():
        error_exit(f"Reference repo path does not exist: {ref_repo}")
    if not (ref_repo / ".git").exists():
        error_exit(f"Not a git repository: {ref_repo}")

    remote_name, remote_url = select_remote(ref_repo)
    workspace_root = resolve_workspace_root_for_setup(ref_repo)
    repo_name = str(ref_repo.relative_to(workspace_root))
    lineage_id = args.lineage or derive_lineage_id(repo_name)

    if lineage_exists(workspace_root, lineage_id):
        error_exit(
            f"Lineage '{lineage_id}' is already registered. "
            "Cannot adopt again."
        )

    info(f"lineage: {lineage_id}")
    info(f"repo:    {repo_name}")
    info(f"remote:  {remote_name} -> {remote_url}")
    info("adopting existing layout …")
    print()

    adopted: list[CopyInfo] = [
        CopyInfo(index=0, label="original", path=ref_repo)
    ]
    branch = git_current_branch(ref_repo)
    branch_display = branch or "(detached)"
    ok(f"original  — {ref_repo} ({branch_display})")

    scanned = _scan_offspring(workspace_root, repo_name, remote_url, remote_name)
    for idx, label, slot_path, status in scanned:
        if status == "valid":
            slot_branch = git_current_branch(slot_path)
            slot_branch_display = slot_branch or "(detached)"
            ok(f"{label:<9} — {slot_path} ({slot_branch_display})")
            adopted.append(
                CopyInfo(index=idx, label=label, path=slot_path)
            )
        elif status == "not_git":
            warn(f"{label}/{repo_name} is not a valid git repository — skipped")
        elif status == "remote_mismatch":
            warn(f"{label}/{repo_name} remote URL does not match — skipped")
        elif status == "remote_error":
            warn(f"{label}/{repo_name} remote query failed — skipped")

    copy_count = max(c.index for c in adopted) + 1 if adopted else 1

    ensure_fork3_dir(workspace_root)
    toml_path = (
        workspace_root / FORK3_DIR / LINEAGES_DIR / f"{lineage_id}.toml"
    )
    data = {
        "lineage": {
            "id": lineage_id,
            "repo_name": repo_name,
            "target_repo": str(ref_repo.relative_to(workspace_root)),
            "remote_name": remote_name,
            "remote_url": remote_url,
            "copy_count": copy_count,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
    }
    write_lineage_toml(toml_path, data)

    print()
    info(f'lineage "{lineage_id}" registered — {len(adopted)} copies adopted')
