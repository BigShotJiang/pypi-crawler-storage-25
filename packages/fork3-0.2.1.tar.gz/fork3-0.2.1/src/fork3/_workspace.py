"""Workspace discovery, context resolution, slot classification, and UV replication."""

import argparse
import shutil
import subprocess
import tomllib
from pathlib import Path

from ._output import (
    FORK3_DIR,
    LINEAGES_DIR,
    MAX_PARENT_WALK,
    error_exit,
    prompt_choice,
)
from ._models import CopyInfo, WorkspaceContext
from ._git import git_remote_names, git_remote_url, git_tracking_remote
from ._metadata import (
    read_lineage_toml,
    list_lineages,
    lineage_exists,
    derive_lineage_id,
)


def find_workspace_root(start: Path) -> Path | None:
    """Walk up to MAX_PARENT_WALK parents from *start* looking for .fork3/."""
    current = start.resolve()
    for _ in range(MAX_PARENT_WALK + 1):
        if (current / FORK3_DIR).is_dir():
            return current
        parent = current.parent
        if parent == current:
            break
        current = parent
    return None


def resolve_workspace_root_for_setup(ref_repo: Path) -> Path:
    """Resolve the workspace root for create/init commands.

    Priority order:
      1. Walk up from ref_repo.parent looking for an existing .fork3/ directory.
      2. Use CWD if it is an ancestor of ref_repo.
      3. Fall back to ref_repo.parent.
    """
    existing = find_workspace_root(ref_repo.parent)
    if existing is not None:
        return existing

    cwd = Path.cwd().resolve()
    if ref_repo.is_relative_to(cwd):
        return cwd
    return ref_repo.parent


def auto_detect_lineage(workspace_root: Path, cwd: Path) -> str:
    """Detect the lineage ID from *cwd* relative to *workspace_root*.

    Matches CWD against known lineage target repos and offspring paths.
    Fails if zero or multiple lineages match.
    """
    cwd = cwd.resolve()
    workspace_root = workspace_root.resolve()

    if cwd == workspace_root:
        available = list_lineages(workspace_root)
        msg = "Cannot auto-detect lineage from workspace root. Use `-l <id>` to specify."
        if available:
            msg += f" Available: {', '.join(available)}"
        error_exit(msg)

    if not cwd.is_relative_to(workspace_root):
        error_exit(
            "Current directory is not inside the workspace. "
            "Use `-l <id>` to specify a lineage."
        )
    rel = cwd.relative_to(workspace_root)

    rel_parts = rel.parts
    lineage_ids = list_lineages(workspace_root)
    matches: list[str] = []

    for lid in lineage_ids:
        toml_path = (
            workspace_root / FORK3_DIR / LINEAGES_DIR / f"{lid}.toml"
        )
        try:
            data = read_lineage_toml(toml_path)
        except (FileNotFoundError, tomllib.TOMLDecodeError):
            continue

        try:
            lineage_meta = data["lineage"]
            repo_name = lineage_meta["repo_name"]
            target_repo_rel = lineage_meta["target_repo"]
        except KeyError:
            continue

        target_parts = Path(target_repo_rel).parts
        if _path_starts_with(rel_parts, target_parts):
            matches.append(lid)
            continue

        if rel_parts and rel_parts[0].startswith("branch"):
            offspring_parts = rel_parts[0:1] + target_parts
            if _path_starts_with(rel_parts, offspring_parts):
                matches.append(lid)
                continue

    if len(matches) == 1:
        return matches[0]
    elif len(matches) == 0:
        available = list_lineages(workspace_root)
        msg = "Cannot auto-detect lineage from current directory."
        if available:
            msg += f" Available: {', '.join(available)}"
        error_exit(msg)
    else:
        error_exit(
            f"Ambiguous lineage. Use `-l <id>` to specify. "
            f"Matches: {', '.join(matches)}"
        )


def _path_starts_with(full: tuple[str, ...], prefix: tuple[str, ...]) -> bool:
    """Return True if *full* path parts start with *prefix* parts."""
    if len(full) < len(prefix):
        return False
    return full[: len(prefix)] == prefix


def resolve_lineage(args: argparse.Namespace, cwd: Path) -> WorkspaceContext:
    """Resolve a lineage from CLI args and CWD into a full WorkspaceContext.

    Uses explicit `-l` if provided, otherwise auto-detects from CWD.
    """
    workspace_root = find_workspace_root(cwd)
    if workspace_root is None:
        error_exit(
            "No fork3 workspace found. "
            "Run `fork3 create` or `fork3 init` first."
        )

    lineage_id = args.lineage
    if lineage_id:
        if not lineage_exists(workspace_root, lineage_id):
            available = list_lineages(workspace_root)
            msg = f"Lineage '{lineage_id}' not found."
            if available:
                msg += f" Available: {', '.join(available)}"
            error_exit(msg)
    else:
        lineage_id = auto_detect_lineage(workspace_root, cwd)

    toml_path = workspace_root / FORK3_DIR / LINEAGES_DIR / f"{lineage_id}.toml"
    data = read_lineage_toml(toml_path)

    try:
        lineage_meta = data["lineage"]
    except KeyError:
        error_exit(f"Malformed lineage file: {toml_path} — missing [lineage] section")

    try:
        repo_name = lineage_meta["repo_name"]
        target_repo = (workspace_root / lineage_meta["target_repo"]).resolve()
        remote_name = lineage_meta["remote_name"]
        remote_url = lineage_meta["remote_url"]
        copy_count = int(lineage_meta["copy_count"])
    except KeyError as e:
        error_exit(f"Malformed lineage file: {toml_path} — missing required field {e}")
    except (TypeError, ValueError):
        error_exit(f"Malformed lineage file: {toml_path} — 'copy_count' must be an integer")

    copies: list[CopyInfo] = []
    copies.append(
        CopyInfo(index=0, label="original", path=target_repo)
    )
    for i in range(1, copy_count):
        slot_path = workspace_root / f"branch{i}" / repo_name
        copies.append(
            CopyInfo(index=i, label=f"branch{i}", path=slot_path)
        )

    return WorkspaceContext(
        workspace_root=workspace_root,
        lineage_id=lineage_id,
        target_repo=target_repo,
        repo_name=repo_name,
        remote_name=remote_name,
        remote_url=remote_url,
        copies=copies,
    )


def select_remote(repo: Path) -> tuple[str, str]:
    """Choose the best remote for *repo* and return ``(name, url)``.

    When only one remote is configured it is returned immediately.
    When multiple remotes exist the user is shown an interactive numbered
    menu with the branch-tracking remote pre-selected as the default.

    Falls back to the default automatically in non-interactive (piped) mode.
    """
    remotes = git_remote_names(repo)
    if not remotes:
        error_exit(f"No remotes found in {repo}")

    if len(remotes) == 1:
        return remotes[0], git_remote_url(repo, remotes[0])

    tracked = git_tracking_remote(repo)

    items: list[tuple[str, str]] = []
    for name in remotes:
        items.append((name, git_remote_url(repo, name)))

    default = 0
    tag_index: int | None = None
    if tracked and tracked in remotes:
        default = remotes.index(tracked)
        tag_index = default

    choice = prompt_choice(
        "Multiple remotes detected — select one:",
        items,
        default=default,
        tag_index=tag_index,
    )

    selected_name = remotes[choice]
    return selected_name, git_remote_url(repo, selected_name)


def build_workspace_context_for_create(args: argparse.Namespace) -> WorkspaceContext:
    """Build a WorkspaceContext for the create command (no .fork3/ required yet).

    Derives workspace root from the reference repo's parent directory.
    """
    ref_repo = Path(args.reference_repo).resolve()

    if not ref_repo.is_dir():
        error_exit(f"Reference repo path does not exist: {ref_repo}")
    if not (ref_repo / ".git").exists():
        error_exit(f"Not a git repository: {ref_repo}")

    remote_name, remote_url = select_remote(ref_repo)

    workspace_root = resolve_workspace_root_for_setup(ref_repo)
    repo_name = str(ref_repo.relative_to(workspace_root))

    lineage_id = args.lineage or derive_lineage_id(repo_name)

    n = args.copies

    copies: list[CopyInfo] = []
    copies.append(
        CopyInfo(index=0, label="original", path=ref_repo)
    )
    for i in range(1, n):
        slot_path = workspace_root / f"branch{i}" / repo_name
        copies.append(
            CopyInfo(index=i, label=f"branch{i}", path=slot_path)
        )

    return WorkspaceContext(
        workspace_root=workspace_root,
        lineage_id=lineage_id,
        target_repo=ref_repo,
        repo_name=repo_name,
        remote_name=remote_name,
        remote_url=remote_url,
        copies=copies,
    )


def classify_slots(
    workspace_root: Path,
    repo_name: str,
    n: int,
    remote_url: str,
    remote_name: str = "origin",
) -> list[tuple[int, str, Path, str]]:
    """Classify each offspring slot as 'existing', 'invalid', or 'missing'.

    Returns a list of (index, label, path, status) tuples for slots 1..n-1.
    """
    results: list[tuple[int, str, Path, str]] = []
    for i in range(1, n):
        label = f"branch{i}"
        slot_path = workspace_root / label / repo_name
        if slot_path.exists():
            if (slot_path / ".git").exists():
                try:
                    actual_url = git_remote_url(slot_path, remote_name)
                    if actual_url == remote_url:
                        results.append((i, label, slot_path, "existing"))
                    else:
                        results.append((i, label, slot_path, "invalid"))
                except subprocess.CalledProcessError:
                    results.append((i, label, slot_path, "invalid"))
            else:
                results.append((i, label, slot_path, "invalid"))
        else:
            results.append((i, label, slot_path, "missing"))
    return results


def replicate_uv_env(source: Path, dest: Path) -> bool:
    """Copy the .venv and optional .envrc from *source* into *dest*.

    Returns True on success, False if source has no .venv.
    """
    src_venv = source / ".venv"
    if not src_venv.is_dir():
        return False
    shutil.copytree(src_venv, dest / ".venv", symlinks=True)
    src_envrc = source / ".envrc"
    if src_envrc.is_file():
        shutil.copy2(src_envrc, dest / ".envrc")
    return True
