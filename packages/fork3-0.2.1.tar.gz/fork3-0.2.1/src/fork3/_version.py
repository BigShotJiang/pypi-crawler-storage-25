"""Version resolution for fork3.

VERSION contract:
  - Single source of truth: the VERSION file at the project root.
  - Build time: hatchling reads VERSION to embed in wheel metadata.
  - Runtime: this module reads VERSION from package resources (installed)
    or from the project root (editable install).
"""

from importlib.resources import files
from pathlib import Path


def read_version() -> str:
    """Read the package version from the bundled VERSION file.

    In a wheel install the VERSION file is bundled as package data.
    In an editable install it is resolved from the project root via __file__.
    """
    try:
        version_text = files("fork3").joinpath("VERSION").read_text(encoding="utf-8")
        return version_text.strip()
    except FileNotFoundError:
        root = Path(__file__).resolve().parent.parent.parent / "VERSION"
        return root.read_text(encoding="utf-8").strip()
