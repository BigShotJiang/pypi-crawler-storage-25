"""Git operation wrappers for fork3."""

import subprocess
from pathlib import Path

from ._output import GIT_TIMEOUT_SECS, GIT_LOCAL_TIMEOUT_SECS


def _run_network_git(cmd: list[str], label: str) -> subprocess.CompletedProcess[str]:
    """Run a git command that involves network I/O with a timeout guard.

    On timeout, raises ``SystemExit`` with a user-friendly message rather than
    letting ``subprocess.TimeoutExpired`` propagate raw.
    """
    try:
        return subprocess.run(
            cmd, check=True, capture_output=True, text=True,
            timeout=GIT_TIMEOUT_SECS,
        )
    except subprocess.TimeoutExpired:
        raise SystemExit(
            f"error: git operation timed out after {GIT_TIMEOUT_SECS}s for {label}"
        )


def git_clone(source: Path, dest: Path) -> None:
    """Clone a git repository from *source* to *dest*."""
    cmd = ["git", "clone", str(source), str(dest)]
    _run_network_git(cmd, label=str(dest))


def git_checkout_new_branch(repo: Path, branch: str) -> None:
    """Create and switch to a new branch in *repo*."""
    subprocess.run(
        ["git", "-C", str(repo), "checkout", "-b", branch],
        check=True,
        capture_output=True,
        text=True,
        timeout=GIT_LOCAL_TIMEOUT_SECS,
    )


def git_push(
    repo: Path, remote: str, branch: str, set_upstream: bool = False
) -> None:
    """Push *branch* to *remote* in *repo*."""
    cmd = ["git", "-C", str(repo), "push"]
    if set_upstream:
        cmd.append("-u")
    cmd += [remote, branch]
    _run_network_git(cmd, label=f"{repo.name}:{branch}")


def git_push_force_with_lease(repo: Path, remote: str, branch: str) -> None:
    """Force-push *branch* to *remote* using --force-with-lease."""
    _run_network_git(
        ["git", "-C", str(repo), "push", "--force-with-lease", remote, branch],
        label=f"{repo.name}:{branch}",
    )


def git_fetch_all(repo: Path) -> None:
    """Fetch all remotes in *repo*."""
    _run_network_git(
        ["git", "-C", str(repo), "fetch", "--all"],
        label=str(repo.name),
    )


def git_current_branch(repo: Path) -> str | None:
    """Return the current branch name, or None if HEAD is detached."""
    try:
        result = subprocess.run(
            ["git", "-C", str(repo), "symbolic-ref", "--short", "HEAD"],
            check=True,
            capture_output=True,
            text=True,
            timeout=GIT_LOCAL_TIMEOUT_SECS,
        )
        return result.stdout.strip()
    except subprocess.CalledProcessError:
        return None


def git_dirty_count(repo: Path) -> int:
    """Return the number of dirty files in the working tree."""
    result = subprocess.run(
        ["git", "-C", str(repo), "status", "--porcelain"],
        check=True,
        capture_output=True,
        text=True,
        timeout=GIT_LOCAL_TIMEOUT_SECS,
    )
    lines = [l for l in result.stdout.splitlines() if l.strip()]
    return len(lines)


def git_ahead_behind(repo: Path) -> tuple[int, int]:
    """Return (ahead, behind) counts relative to the upstream tracking branch."""
    try:
        result = subprocess.run(
            [
                "git",
                "-C",
                str(repo),
                "rev-list",
                "--left-right",
                "--count",
                "HEAD...@{u}",
            ],
            check=True,
            capture_output=True,
            text=True,
            timeout=GIT_LOCAL_TIMEOUT_SECS,
        )
        parts = result.stdout.strip().split()
        return int(parts[0]), int(parts[1])
    except subprocess.CalledProcessError:
        return 0, 0


def git_remote_url(repo: Path, remote: str = "origin") -> str:
    """Return the URL of *remote* in *repo*."""
    result = subprocess.run(
        ["git", "-C", str(repo), "remote", "get-url", remote],
        check=True,
        capture_output=True,
        text=True,
        timeout=GIT_LOCAL_TIMEOUT_SECS,
    )
    return result.stdout.strip()


def git_remote_names(repo: Path) -> list[str]:
    """Return a list of remote names configured in *repo*."""
    result = subprocess.run(
        ["git", "-C", str(repo), "remote"],
        check=True,
        capture_output=True,
        text=True,
        timeout=GIT_LOCAL_TIMEOUT_SECS,
    )
    return [l.strip() for l in result.stdout.splitlines() if l.strip()]


def git_ls_remote(url: str) -> bool:
    """Return True if the remote at *url* is reachable and has refs."""
    try:
        result = subprocess.run(
            ["git", "ls-remote", "--exit-code", url],
            capture_output=True,
            text=True,
            timeout=GIT_TIMEOUT_SECS,
        )
        return result.returncode == 0
    except subprocess.TimeoutExpired:
        return False


def git_set_remote_url(repo: Path, remote: str, url: str) -> None:
    """Ensure *remote* exists in *repo* and points to *url*.

    Uses ``git remote add`` when the remote is absent, and
    ``git remote set-url`` when it already exists.
    """
    existing = git_remote_names(repo)
    verb = "set-url" if remote in existing else "add"
    subprocess.run(
        ["git", "-C", str(repo), "remote", verb, remote, url],
        check=True,
        capture_output=True,
        text=True,
        timeout=GIT_LOCAL_TIMEOUT_SECS,
    )


def git_reset_hard(repo: Path, ref: str) -> None:
    """Hard-reset *repo* to *ref*."""
    subprocess.run(
        ["git", "-C", str(repo), "reset", "--hard", ref],
        check=True,
        capture_output=True,
        text=True,
        timeout=GIT_LOCAL_TIMEOUT_SECS,
    )


def git_tracking_branch(repo: Path) -> str | None:
    """Return the upstream tracking ref, or None if unset."""
    try:
        result = subprocess.run(
            ["git", "-C", str(repo), "rev-parse", "--abbrev-ref", "@{u}"],
            check=True,
            capture_output=True,
            text=True,
            timeout=GIT_LOCAL_TIMEOUT_SECS,
        )
        return result.stdout.strip()
    except subprocess.CalledProcessError:
        return None


def git_tracking_remote(repo: Path) -> str | None:
    """Return the remote name that the current branch tracks, or None.

    Queries ``git config branch.<branch>.remote`` which is set by
    ``git push -u <remote> <branch>`` or ``git branch --set-upstream-to``.
    """
    branch = git_current_branch(repo)
    if branch is None:
        return None
    try:
        result = subprocess.run(
            ["git", "-C", str(repo), "config", f"branch.{branch}.remote"],
            check=True,
            capture_output=True,
            text=True,
            timeout=GIT_LOCAL_TIMEOUT_SECS,
        )
        name = result.stdout.strip()
        return name if name else None
    except subprocess.CalledProcessError:
        return None
