"""Argument parsing and main entry point for fork3."""

import argparse
import sys

from . import __version__
from ._output import DEFAULT_COPY_COUNT, MIN_COPY_COUNT
from ._cmd_create import create_command, init_command
from ._cmd_ops import fetch_command, push_command, sync_command, status_command


def _looks_like_path(arg: str) -> bool:
    """Return True if *arg* looks like a filesystem path (syntactic check only).

    Matches arguments containing ``/`` or starting with ``.``.
    No filesystem I/O is performed.
    """
    return "/" in arg or arg.startswith(".")


def _build_parser() -> tuple[argparse.ArgumentParser, argparse._SubParsersAction]:
    """Construct the full CLI parser tree and return (parser, subparsers)."""
    parser = argparse.ArgumentParser(
        prog="fork3",
        description=(
            "fork3 — Manage parallel branch workspaces around git repositories.\n"
            "\n"
            "Create, inspect, push, and sync multiple local clones of a git repo,\n"
            "each on its own feature branch, all tracked under a single .fork3/\n"
            "workspace.\n"
            "\n"
            "Usage examples:\n"
            "  fork3 ./my-project -n 3          Create 3 copies of my-project\n"
            "  fork3 create ./repo -n 4 --uv    Create 4 copies with uv env replication\n"
            "  fork3 fetch -l my-project        Fetch all copies in the lineage\n"
            "  fork3 push -l my-project         Push all copies in the lineage\n"
            "  fork3 sync feat2 -l my-project   Sync all copies to the feat2 winner\n"
            "  fork3 st                         Show status (auto-detect lineage)\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "examples:\n"
            "  fork3 ./my-project -n 3          Create 3 copies\n"
            "  fork3 fetch -l my-project         Fetch all copies\n"
            "  fork3 push -l my-project          Push all copies\n"
            "  fork3 sync feat2 -l my-project    Sync to feat2 winner\n"
            "  fork3 st                          Show status (auto-detect)\n"
        ),
    )
    parser.add_argument(
        "--version", action="version", version=f"%(prog)s {__version__}"
    )

    subparsers = parser.add_subparsers(dest="command", title="commands")
    subparsers.required = True

    # --- create ---
    create_parser = subparsers.add_parser(
        "create",
        help="Create or expand a fork3 lineage",
        epilog=(
            "examples:\n"
            "  fork3 create ./my-project -n 3\n"
            "  fork3 create ./libs/auth -n 2 -l auth\n"
            "  fork3 create ./repo --uv\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    create_parser.add_argument(
        "reference_repo",
        type=str,
        metavar="REFERENCE_REPO",
        help="path to the original git repository",
    )
    create_parser.add_argument(
        "-n", "--copies",
        type=int,
        default=DEFAULT_COPY_COUNT,
        metavar="N",
        help=(
            f"total number of copies including the original "
            f"(default: {DEFAULT_COPY_COUNT}, minimum: {MIN_COPY_COUNT})"
        ),
    )
    create_parser.add_argument(
        "--uv",
        action="store_true",
        default=False,
        help="replicate uv-based virtual environment into new copies",
    )
    create_parser.add_argument(
        "-l",
        "--lineage",
        type=str,
        default=None,
        metavar="ID",
        help="custom lineage ID (default: derived from repo path)",
    )

    # --- init ---
    init_parser = subparsers.add_parser(
        "init",
        help="Adopt an existing layout as a fork3 lineage",
        epilog=(
            "examples:\n"
            "  fork3 init ./my-project\n"
            "  fork3 init ./libs/auth -l auth\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    init_parser.add_argument(
        "reference_repo",
        type=str,
        metavar="REFERENCE_REPO",
        help="path to the reference repository within the existing layout",
    )
    init_parser.add_argument(
        "-l",
        "--lineage",
        type=str,
        default=None,
        metavar="ID",
        help="custom lineage ID (default: derived from repo path)",
    )

    # --- push ---
    push_parser = subparsers.add_parser(
        "push",
        help="Push all copies in a lineage",
        epilog=(
            "examples:\n"
            "  fork3 push -l my-project\n"
            "  fork3 push --dry-run\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    push_parser.add_argument(
        "-l",
        "--lineage",
        type=str,
        default=None,
        metavar="ID",
        help="lineage ID (auto-detected if omitted)",
    )
    push_parser.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="print the push plan without executing",
    )

    # --- sync ---
    sync_parser = subparsers.add_parser(
        "sync",
        help="Sync all copies to a winner",
        epilog=(
            "examples:\n"
            "  fork3 sync feat2 -l my-project\n"
            "  fork3 sync branch2 --dry-run\n"
            "  fork3 sync 2 --force\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sync_parser.add_argument(
        "copy",
        type=str,
        metavar="COPY",
        help="winner copy (branch name, copy label, or numeric index)",
    )
    sync_parser.add_argument(
        "-l",
        "--lineage",
        type=str,
        default=None,
        metavar="ID",
        help="lineage ID (auto-detected if omitted)",
    )
    sync_parser.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="print the sync plan without executing",
    )
    sync_parser.add_argument(
        "--no-push",
        action="store_true",
        default=False,
        help="reset locally without force-pushing",
    )
    sync_parser.add_argument(
        "--force",
        action="store_true",
        default=False,
        help="override dirty-copy safety check",
    )

    # --- fetch ---
    fetch_parser = subparsers.add_parser(
        "fetch",
        help="Fetch all copies in a lineage",
        epilog=(
            "examples:\n"
            "  fork3 fetch -l my-project\n"
            "  fork3 fetch\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    fetch_parser.add_argument(
        "-l",
        "--lineage",
        type=str,
        default=None,
        metavar="ID",
        help="lineage ID (auto-detected if omitted)",
    )

    # --- status ---
    status_parser = subparsers.add_parser(
        "status",
        aliases=["st"],
        help="Show status of all copies in a lineage",
        epilog=(
            "examples:\n"
            "  fork3 st -l my-project\n"
            "  fork3 st\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    status_parser.add_argument(
        "-l",
        "--lineage",
        type=str,
        default=None,
        metavar="ID",
        help="lineage ID (auto-detected if omitted)",
    )

    return parser, subparsers


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Build the argparse parser and return parsed arguments.

    Phases:
      1. Build the full parser tree (all subparsers registered).
      2. Derive known_subcommands from subparsers.choices (single source of truth).
      3. Apply create shorthand: if argv[0] looks like a path, inject 'create'.
      4. Parse via argparse (handles unknown commands, missing required args).
      5. Post-parse validation (e.g. --copies minimum).
    """
    if argv is None:
        argv = sys.argv[1:]

    parser, subparsers = _build_parser()

    if not argv:
        parser.print_help()
        sys.exit(2)

    known_subcommands = set(subparsers.choices.keys())

    if not any(a in known_subcommands for a in argv) and any(
        _looks_like_path(a) for a in argv if not a.startswith("-")
    ):
        argv = ["create"] + argv

    args = parser.parse_args(argv)

    if args.command == "create" and args.copies < MIN_COPY_COUNT:
        subparsers.choices["create"].error(
            f"-n/--copies must be at least {MIN_COPY_COUNT}"
        )

    return args


def main() -> None:
    """Parse arguments and dispatch to the appropriate command handler."""
    try:
        args = parse_args()
        dispatch = {
            "create": create_command,
            "init": init_command,
            "fetch": fetch_command,
            "push": push_command,
            "sync": sync_command,
            "status": status_command,
            "st": status_command,
        }
        handler = dispatch[args.command]
        handler(args)
    except KeyboardInterrupt:
        print()
        sys.exit(130)
