"""fork3 — Manage parallel branch workspaces around git repositories."""

from ._version import read_version

__version__ = read_version()
__all__ = ["__version__"]
