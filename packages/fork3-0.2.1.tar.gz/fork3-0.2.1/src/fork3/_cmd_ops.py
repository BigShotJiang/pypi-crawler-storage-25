"""Push, sync, and status commands for fork3."""

import argparse
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from ._output import info, ok, warn, error_exit
from ._models import CopyInfo, WorkspaceContext
from ._git import (
    git_current_branch,
    git_dirty_count,
    git_ahead_behind,
    git_tracking_branch,
    git_fetch_all,
    git_push,
    git_push_force_with_lease,
    git_reset_hard,
)
from ._workspace import resolve_lineage


def _gather_copy_state(copy: CopyInfo) -> CopyInfo:
    """Populate runtime git state fields on a CopyInfo in-place and return it."""
    if not copy.path.is_dir() or not (copy.path / ".git").exists():
        copy.missing = True
        copy.detached = True
        return copy
    copy.branch = git_current_branch(copy.path)
    copy.detached = copy.branch is None
    copy.dirty_count = git_dirty_count(copy.path)
    copy.dirty = copy.dirty_count > 0
    if not copy.detached:
        copy.tracking_branch = git_tracking_branch(copy.path)
        copy.ahead, copy.behind = git_ahead_behind(copy.path)
    return copy


def _short_path(p: Path) -> str:
    """Return a truncated display path like '…/<parent>/<name>'."""
    parts = p.resolve().parts
    if len(parts) >= 2:
        return f"…/{parts[-2]}/{parts[-1]}"
    return str(p)


def _detect_current_copy(copies: list[CopyInfo]) -> int | None:
    """Return the index of the copy whose path contains the CWD, or None."""
    cwd = Path.cwd().resolve()
    for c in copies:
        if cwd.is_relative_to(c.path.resolve()):
            return c.index
    return None


def _print_status_table(copies: list[CopyInfo]) -> None:
    """Print a compact tabular status summary for the given copies."""
    current_idx = _detect_current_copy(copies)
    headers = ("Copy", "Path", "Branch", "Dirty", "A/B")

    rows: list[tuple[str, ...]] = []
    is_current: list[bool] = []
    for c in copies:
        is_current.append(c.index == current_idx)
        branch_display = c.branch if c.branch else ("(missing)" if c.missing else "(detached)")
        if c.dirty:
            dirty_display = f"{c.dirty_count} file{'s' if c.dirty_count != 1 else ''}"
        else:
            dirty_display = "clean"
        ab_display = f"{c.ahead}/{c.behind}"
        rows.append((
            c.label,
            _short_path(c.path),
            branch_display,
            dirty_display,
            ab_display,
        ))

    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(cell))

    def fmt_row(cells: tuple[str, ...]) -> str:
        """Format a row with fixed column widths."""
        parts = []
        for i, cell in enumerate(cells):
            parts.append(cell.ljust(col_widths[i]))
        return "  ".join(parts)

    print(f"  {fmt_row(headers)}")
    sep = tuple("-" * w for w in col_widths)
    print(f"  {fmt_row(sep)}")
    for row, current in zip(rows, is_current):
        marker = "▸ " if current else "  "
        print(f"{marker}{fmt_row(row)}")


def fetch_command(args: argparse.Namespace) -> None:
    """Fetch all copies in a lineage."""
    ctx = resolve_lineage(args, Path.cwd())

    info(f'fetching lineage "{ctx.lineage_id}"')
    print()

    errors: list[str] = []
    with ThreadPoolExecutor(max_workers=min(len(ctx.copies), 8)) as pool:
        futures = {pool.submit(git_fetch_all, c.path): c for c in ctx.copies}
        for fut in as_completed(futures):
            c = futures[fut]
            try:
                fut.result()
                ok(f"{c.label} fetched")
            except subprocess.CalledProcessError:
                errors.append(c.label)
                warn(f"fetch failed for {c.label}")

    print()
    fetched_count = len(ctx.copies) - len(errors)
    info(f"done — {fetched_count} fetched, {len(errors)} failed")


def push_command(args: argparse.Namespace) -> None:
    """Push all eligible copies in a lineage, then fetch all copies."""
    ctx = resolve_lineage(args, Path.cwd())

    for copy in ctx.copies:
        _gather_copy_state(copy)

    plan: list[tuple[CopyInfo, str]] = []
    for copy in ctx.copies:
        if copy.detached:
            plan.append((copy, "skip_detached"))
        elif copy.tracking_branch is None:
            plan.append((copy, "push_set_upstream"))
        else:
            plan.append((copy, "push"))

    if args.dry_run:
        _push_dry_run(ctx, plan)
        return

    info(f'pushing lineage "{ctx.lineage_id}"')
    print()

    eligible = [(c, a) for c, a in plan if a != "skip_detached"]
    skipped = [(c, a) for c, a in plan if a == "skip_detached"]

    for copy, _ in skipped:
        reason = "directory missing or not a git repo" if copy.missing else "detached HEAD"
        warn(f"{copy.label} — {reason}, skipping push")

    if not eligible:
        info("no eligible copies to push")
        return

    errors: list[tuple[str, str]] = []
    with ThreadPoolExecutor(max_workers=min(len(eligible), 8)) as pool:
        futures = {}
        for copy, action in eligible:
            assert copy.branch is not None
            set_upstream = action == "push_set_upstream"
            fut = pool.submit(
                git_push, copy.path, ctx.remote_name, copy.branch, set_upstream
            )
            futures[fut] = (copy, action)
        for fut in as_completed(futures):
            copy, action = futures[fut]
            try:
                fut.result()
                suffix = " (set upstream)" if action == "push_set_upstream" else ""
                ok(f"{copy.label} pushed{suffix}")
            except subprocess.CalledProcessError as exc:
                errors.append((copy.label, str(exc)))
                warn(f"{copy.label} push failed")

    print()
    info("fetching all copies …")
    with ThreadPoolExecutor(max_workers=min(len(ctx.copies), 8)) as pool:
        fetch_futures = {
            pool.submit(git_fetch_all, c.path): c for c in ctx.copies
        }
        for fut in as_completed(fetch_futures):
            c = fetch_futures[fut]
            try:
                fut.result()
                ok(f"{c.label} fetched")
            except subprocess.CalledProcessError:
                warn(f"fetch failed for {c.label}")

    print()
    pushed_count = len(eligible) - len(errors)
    info(f"done — {pushed_count} pushed, {len(skipped)} skipped, {len(errors)} failed")


def _push_dry_run(
    ctx: WorkspaceContext, plan: list[tuple[CopyInfo, str]]
) -> None:
    """Print the push plan without executing any mutations."""
    info(f'dry run — push plan for lineage "{ctx.lineage_id}"')
    print()
    print("  Phase 1: push")
    for copy, action in plan:
        if action == "skip_detached":
            print(f"    {copy.label:<10} skip — detached HEAD")
        elif action == "push_set_upstream":
            print(
                f"    {copy.label:<10} git push -u {ctx.remote_name} {copy.branch}  (set upstream)"
            )
        else:
            print(f"    {copy.label:<10} git push {ctx.remote_name} {copy.branch}")
    print()
    print("  Phase 2: fetch")
    print("    all copies  git fetch --all")


def sync_command(args: argparse.Namespace) -> None:
    """Sync all copies to a winner's branch within the resolved lineage."""
    ctx = resolve_lineage(args, Path.cwd())

    for copy in ctx.copies:
        _gather_copy_state(copy)

    winner = _resolve_winner(ctx, args.copy)

    if winner.detached:
        error_exit(
            f"Winner '{args.copy}' is in detached HEAD state. "
            "Cannot sync from a detached copy."
        )

    dry_run = args.dry_run
    no_push = args.no_push
    force = args.force

    non_winner = [c for c in ctx.copies if c.index != winner.index]
    eligible = [c for c in non_winner if not c.detached]
    skipped_detached = [c for c in non_winner if c.detached]

    if not non_winner:
        info("single-copy lineage — nothing to sync")
        return

    if not force:
        dirty_copies = [c for c in eligible if c.dirty]
        if dirty_copies:
            labels = ", ".join(c.label for c in dirty_copies)
            error_exit(
                f"Dirty copies block sync: {labels}. "
                "Commit or stash changes, or use --force to override."
            )

    if dry_run:
        _sync_dry_run(ctx, winner, eligible, skipped_detached, no_push)
        return

    winner_branch = winner.branch
    info(f'syncing lineage "{ctx.lineage_id}" to winner: {winner.label} ({winner_branch})')
    print()

    for copy in skipped_detached:
        reason = "directory missing or not a git repo" if copy.missing else "detached HEAD"
        warn(f"{copy.label} — {reason}, skipping")

    if not eligible:
        info("no eligible copies to sync")
        return

    with ThreadPoolExecutor(max_workers=min(len(eligible), 8)) as pool:
        fetch_futures = {pool.submit(git_fetch_all, c.path): c for c in eligible}
        for fut in as_completed(fetch_futures):
            c = fetch_futures[fut]
            try:
                fut.result()
            except subprocess.CalledProcessError:
                warn(f"fetch failed for {c.label}")

    reset_ref = f"{ctx.remote_name}/{winner_branch}"
    with ThreadPoolExecutor(max_workers=min(len(eligible), 8)) as pool:
        reset_futures = {
            pool.submit(git_reset_hard, c.path, reset_ref): c for c in eligible
        }
        for fut in as_completed(reset_futures):
            c = reset_futures[fut]
            try:
                fut.result()
                ok(f"{c.label} reset to {reset_ref}")
            except subprocess.CalledProcessError:
                warn(f"{c.label} reset failed")

    push_errors: list[str] = []
    if not no_push:
        print()
        info("force-pushing synced copies …")
        with ThreadPoolExecutor(max_workers=min(len(eligible), 8)) as pool:
            push_futures = {}
            for copy in eligible:
                copy_branch = git_current_branch(copy.path)
                if copy_branch is None:
                    continue
                fut = pool.submit(
                    git_push_force_with_lease, copy.path, ctx.remote_name, copy_branch
                )
                push_futures[fut] = copy
            for fut in as_completed(push_futures):
                c = push_futures[fut]
                try:
                    fut.result()
                    ok(f"{c.label} force-pushed")
                except subprocess.CalledProcessError:
                    push_errors.append(c.label)
                    warn(f"{c.label} force-push failed")

    print()
    info("fetching all copies …")
    with ThreadPoolExecutor(max_workers=min(len(ctx.copies), 8)) as pool:
        fetch_futures = {pool.submit(git_fetch_all, c.path): c for c in ctx.copies}
        for fut in as_completed(fetch_futures):
            c = fetch_futures[fut]
            try:
                fut.result()
                ok(f"{c.label} fetched")
            except subprocess.CalledProcessError:
                warn(f"fetch failed for {c.label}")

    synced_count = len(eligible) - len(push_errors)
    print()
    info(
        f"done — {synced_count} synced, "
        f"{len(skipped_detached)} skipped, "
        f"{len(push_errors)} failed"
    )

    for copy in ctx.copies:
        _gather_copy_state(copy)
    print()
    _print_status_table(ctx.copies)


def _resolve_winner(ctx: WorkspaceContext, copy_arg: str) -> CopyInfo:
    """Resolve the winner copy from a branch name, copy label, or numeric index."""
    for c in ctx.copies:
        if c.branch == copy_arg:
            return c

    for c in ctx.copies:
        if c.label == copy_arg:
            return c

    try:
        idx = int(copy_arg)
        for c in ctx.copies:
            if c.index == idx:
                return c
    except ValueError:
        pass

    labels = ", ".join(
        f"{c.label} ({c.branch or 'detached'})" for c in ctx.copies
    )
    error_exit(
        f"Cannot resolve winner '{copy_arg}'. Available copies: {labels}"
    )


def _sync_dry_run(
    ctx: WorkspaceContext,
    winner: CopyInfo,
    eligible: list[CopyInfo],
    skipped: list[CopyInfo],
    no_push: bool,
) -> None:
    """Print the sync plan without executing any mutations."""
    info(f'dry run — sync plan for lineage "{ctx.lineage_id}"')
    info(f"winner: {winner.label} ({winner.branch})")
    print()

    for copy in eligible:
        reset_cmd = f"git reset --hard {ctx.remote_name}/{winner.branch}"
        if no_push:
            print(f"    {copy.label:<10} {reset_cmd}")
        else:
            push_cmd = f"git push --force-with-lease {ctx.remote_name} {copy.branch or copy.label}"
            print(f"    {copy.label:<10} {reset_cmd}; {push_cmd}")

    for copy in skipped:
        print(f"    {copy.label:<10} skip — detached HEAD")


def status_command(args: argparse.Namespace) -> None:
    """Print a status summary for a lineage."""
    ctx = resolve_lineage(args, Path.cwd())

    for copy in ctx.copies:
        _gather_copy_state(copy)

    current_idx = _detect_current_copy(ctx.copies)

    info(f"lineage:   {ctx.lineage_id}")
    info(f"repo:      {ctx.repo_name}")
    info(f"remote:    {ctx.remote_name}")
    info(f"copies:    {len(ctx.copies)}")
    if current_idx is not None:
        current_copy = next(c for c in ctx.copies if c.index == current_idx)
        role = "ancestor" if current_idx == 0 else "offspring"
        info(f"cwd:       {current_copy.label} ({role})")
    print()

    _print_status_table(ctx.copies)
