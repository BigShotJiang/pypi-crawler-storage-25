"""Allow running fork3 as ``python -m fork3``."""

from ._cli import main

main()
