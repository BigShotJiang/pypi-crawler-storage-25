"""Constants and output helpers for fork3."""

import sys
from typing import NoReturn

FORK3_DIR = ".fork3"
LINEAGES_DIR = "lineages"
MAX_PARENT_WALK = 5
DEFAULT_COPY_COUNT = 3
MIN_COPY_COUNT = 2

GIT_TIMEOUT_SECS = 120
GIT_LOCAL_TIMEOUT_SECS = 30


def colorize(text: str, color: str = "info") -> str:
    """Wrap *text* with ANSI color escape sequences."""
    color_codes = {
        "info": "\033[1;34m",
        "success": "\033[1;32m",
        "warning": "\033[1;33m",
        "error": "\033[1;31m",
    }
    reset = "\033[0m"
    return f"{color_codes.get(color, '')}{text}{reset}"


def info(msg: str) -> None:
    """Print an informational header line in blue."""
    print(f"{colorize('==>', 'info')} {msg}")


def ok(msg: str) -> None:
    """Print a success line in green."""
    print(f"{colorize(' ✓', 'success')}  {msg}")


def warn(msg: str) -> None:
    """Print a warning line in yellow to stderr."""
    print(f"{colorize('warn:', 'warning')} {msg}", file=sys.stderr)


def error_exit(msg: str, code: int = 1) -> NoReturn:
    """Print an error message to stderr and exit with *code*."""
    print(f"{colorize('error:', 'error')} {msg}", file=sys.stderr)
    sys.exit(code)


def prompt_choice(
    header: str,
    items: list[tuple[str, str]],
    *,
    default: int = 0,
    tag_index: int | None = None,
    tag_label: str = "tracking",
) -> int:
    """Display a numbered selection menu and return the 0-based chosen index.

    *items* is a list of ``(label, detail)`` pairs.  The *default* index is
    pre-selected when the user presses Enter.  If *tag_index* is given, that
    row is annotated with *tag_label* to signal the recommended choice.

    Falls back to *default* silently when stdin is not a TTY.
    """
    info(header)
    print()

    idx_width = len(str(len(items)))
    label_width = max(len(label) for label, _ in items)

    for i, (label, detail) in enumerate(items):
        num = str(i + 1).rjust(idx_width)
        marker = colorize("▸", "success") if i == default else " "
        bracket = colorize(f"[{num}]", "info")
        tag = ""
        if tag_index is not None and i == tag_index:
            tag = f"  {colorize(f'({tag_label})', 'success')}"
        print(f"    {marker} {bracket}  {label.ljust(label_width)}  {detail}{tag}")

    print()

    if not sys.stdin.isatty():
        return default

    prompt_text = f"  Select ({1}-{len(items)}) [{default + 1}]: "
    while True:
        try:
            raw = input(prompt_text).strip()
        except (EOFError, KeyboardInterrupt):
            print()
            raise SystemExit(1)

        if not raw:
            return default

        try:
            choice = int(raw)
            if 1 <= choice <= len(items):
                return choice - 1
        except ValueError:
            pass

        warn(f"Please enter a number between 1 and {len(items)}")
