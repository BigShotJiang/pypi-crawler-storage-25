"""Data classes for fork3 workspace state."""

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class CopyInfo:
    """Per-copy state within a lineage."""

    index: int
    label: str
    path: Path
    branch: str | None = None
    dirty: bool = False
    dirty_count: int = 0
    ahead: int = 0
    behind: int = 0
    detached: bool = False
    missing: bool = False
    tracking_branch: str | None = None


@dataclass
class WorkspaceContext:
    """Resolved workspace state for any command."""

    workspace_root: Path
    lineage_id: str
    target_repo: Path
    repo_name: str
    remote_name: str
    remote_url: str
    copies: list[CopyInfo] = field(default_factory=list)
