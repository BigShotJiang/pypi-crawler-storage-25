#!/usr/bin/env bash
# publish.sh - Build and publish fork3 to PyPI.
#
# Usage:
#   publish.sh [options]
#
# Builds the sdist and wheel, then uploads to PyPI (or TestPyPI).
# Requires a PyPI API token configured via TWINE_USERNAME / TWINE_PASSWORD
# environment variables or a ~/.pypirc file.
#
# Options:
#   --test      Upload to TestPyPI instead of production PyPI
#   --dry-run   Build only, skip upload
#   -h          Show help and exit
#   -V          Show version and exit

set -euo pipefail

# ─── Metadata ────────────────────────────────────────────────────────────────

SCRIPT_NAME="publish.sh"
VERSION="1.0.0"

# ─── Defaults ────────────────────────────────────────────────────────────────

USE_TEST_PYPI=false
DRY_RUN=false
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"

# ─── Helpers ─────────────────────────────────────────────────────────────────

die()  { printf "\033[1;31merror:\033[0m %s\n" "$*" >&2; exit 1; }
info() { printf "\033[1;34m==>\033[0m %s\n" "$*"; }
warn() { printf "\033[1;33mwarn:\033[0m %s\n" "$*" >&2; }
ok()   { printf "\033[1;32m ✓\033[0m  %s\n" "$*"; }

# Prints the header comment block as help text
usage() {
    sed -n '2,/^$/s/^# \{0,1\}//p' "$0"
    exit 0
}

# ─── Argument parsing ────────────────────────────────────────────────────────

while [[ "$#" -gt 0 ]]; do
    case "$1" in
        --test)     USE_TEST_PYPI=true; shift ;;
        --dry-run)  DRY_RUN=true; shift ;;
        -h|--help)  usage ;;
        -V|--version) echo "$SCRIPT_NAME $VERSION"; exit 0 ;;
        -*)         die "unknown option: $1" ;;
        *)          die "unexpected argument: $1" ;;
    esac
done

# ─── Pre-flight checks ──────────────────────────────────────────────────────

info "running pre-flight checks …"

command -v uv &>/dev/null || die "uv is not installed — https://docs.astral.sh/uv/"

PKG_VERSION="$(cat "$PROJECT_ROOT/VERSION")"
[[ -n "$PKG_VERSION" ]] || die "VERSION file is empty"

ok "version: $PKG_VERSION"

if [[ "$DRY_RUN" == false ]]; then
    uv run twine --version &>/dev/null 2>&1 || {
        info "installing twine via uv …"
        uv pip install twine
    }
fi

ok "all pre-flight checks passed"

# ─── Clean previous builds ──────────────────────────────────────────────────

info "cleaning previous build artifacts …"
rm -rf "$PROJECT_ROOT/dist"
ok "dist/ cleaned"

# ─── Build ───────────────────────────────────────────────────────────────────

info "building sdist and wheel …"
uv build --directory "$PROJECT_ROOT"
ok "build complete — artifacts in dist/"

ls -lh "$PROJECT_ROOT/dist/"

# ─── Upload ──────────────────────────────────────────────────────────────────

if [[ "$DRY_RUN" == true ]]; then
    info "dry-run mode — skipping upload"
    ok "done (dry-run)"
    exit 0
fi

if [[ "$USE_TEST_PYPI" == true ]]; then
    info "uploading to TestPyPI …"
    uv run twine upload --repository testpypi "$PROJECT_ROOT/dist/"*
    ok "published fork3 $PKG_VERSION to TestPyPI"
    echo
    info "install from TestPyPI with:"
    echo "  uv pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ fork3==$PKG_VERSION"
else
    info "uploading to PyPI …"
    uv run twine upload "$PROJECT_ROOT/dist/"*
    ok "published fork3 $PKG_VERSION to PyPI"
fi
