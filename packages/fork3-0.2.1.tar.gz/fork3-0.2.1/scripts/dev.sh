#!/usr/bin/env bash
# dev.sh - Install or uninstall fork3-dev for local development.
#
# Usage:
#   dev.sh install      Install fork3-dev globally (editable, -dev version)
#   dev.sh uninstall    Remove fork3-dev from PATH
#   dev.sh -h           Show help and exit
#
# Installs a thin wrapper at ~/.local/bin/fork3-dev that delegates to the
# editable fork3 package with a "-dev" version suffix.

set -euo pipefail

# ─── Metadata ────────────────────────────────────────────────────────────────

SCRIPT_NAME="dev.sh"
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
INSTALL_DIR="${HOME}/.local/bin"
WRAPPER="${INSTALL_DIR}/fork3-dev"

# ─── Helpers ─────────────────────────────────────────────────────────────────

die()  { printf "\033[1;31merror:\033[0m %s\n" "$*" >&2; exit 1; }
info() { printf "\033[1;34m==>\033[0m %s\n" "$*"; }
ok()   { printf "\033[1;32m ✓\033[0m  %s\n" "$*"; }

usage() {
    sed -n '2,/^$/s/^# \{0,1\}//p' "$0"
    exit 0
}

# ─── Install ─────────────────────────────────────────────────────────────────

do_install() {
    info "checking prerequisites …"
    command -v uv &>/dev/null || die "uv is not installed — https://docs.astral.sh/uv/"

    info "installing fork3 in editable mode …"
    uv pip install -e "$PROJECT_ROOT"

    PYTHON="$(uv run python3 -c "import sys; print(sys.executable)")"
    [[ -x "$PYTHON" ]] || die "cannot locate python3 executable"
    ok "using python: $PYTHON"

    info "writing wrapper → $WRAPPER"
    mkdir -p "$INSTALL_DIR"

    cat > "$WRAPPER" <<PYEOF
#!${PYTHON}
"""fork3-dev — thin dev wrapper that adds '-dev' to the version string."""
import fork3

fork3.__version__ += "-dev"

from fork3._cli import main

main()
PYEOF

    chmod +x "$WRAPPER"
    ok "fork3-dev installed"

    if [[ ":${PATH}:" != *":${INSTALL_DIR}:"* ]]; then
        echo
        info "⚠  ${INSTALL_DIR} is not on your PATH"
        info "   add to your shell profile:"
        echo "     export PATH=\"${INSTALL_DIR}:\${PATH}\""
        echo
    fi

    "$WRAPPER" --version
}

# ─── Uninstall ───────────────────────────────────────────────────────────────

do_uninstall() {
    if [[ -f "$WRAPPER" ]]; then
        rm "$WRAPPER"
        ok "fork3-dev removed from $INSTALL_DIR"
    else
        info "fork3-dev is not installed at $WRAPPER"
    fi
}

# ─── Argument parsing ────────────────────────────────────────────────────────

[[ "$#" -gt 0 ]] || { usage; }

case "$1" in
    install)    do_install ;;
    uninstall)  do_uninstall ;;
    -h|--help)  usage ;;
    *)          die "unknown command: $1 (use install or uninstall)" ;;
esac
