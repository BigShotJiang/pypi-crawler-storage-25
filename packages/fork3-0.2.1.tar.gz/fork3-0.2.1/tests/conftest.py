import subprocess
from pathlib import Path

import pytest
import tomli_w


@pytest.fixture
def git_repo(tmp_path: Path) -> Path:
    """Create a real git repository with an initial commit and a remote 'origin' pointing to a bare clone.

    Sets up a bare repo at tmp_path/"remote.git", clones it to tmp_path/"repo",
    creates an initial commit with a README file, and pushes to origin main.
    Returns the Path to tmp_path/"repo".
    """
    bare_repo = tmp_path / "remote.git"
    subprocess.run(
        ["git", "init", "--bare", str(bare_repo)],
        check=True, capture_output=True, text=True,
    )

    repo = tmp_path / "repo"
    subprocess.run(
        ["git", "clone", str(bare_repo), str(repo)],
        check=True, capture_output=True, text=True,
    )

    subprocess.run(
        ["git", "config", "user.name", "Test"],
        cwd=str(repo), check=True, capture_output=True, text=True,
    )
    subprocess.run(
        ["git", "config", "user.email", "test@test.com"],
        cwd=str(repo), check=True, capture_output=True, text=True,
    )

    readme = repo / "README"
    readme.write_text("initial")

    subprocess.run(
        ["git", "add", "README"],
        cwd=str(repo), check=True, capture_output=True, text=True,
    )
    subprocess.run(
        ["git", "commit", "-m", "Initial commit"],
        cwd=str(repo), check=True, capture_output=True, text=True,
    )
    subprocess.run(
        ["git", "push", "origin", "HEAD:main"],
        cwd=str(repo), check=True, capture_output=True, text=True,
    )

    return repo


@pytest.fixture
def workspace_with_lineage(git_repo: Path) -> tuple[Path, str, Path]:
    """Create a workspace with a fork3 lineage TOML file inside the git repo's parent.

    Creates .fork3/lineages/ directory structure, writes a lineage TOML file
    using tomli_w, and returns a tuple of (workspace_root, lineage_id, git_repo).
    """
    workspace_root = git_repo.parent
    lineage_id = "my-project"

    lineages_dir = workspace_root / ".fork3" / "lineages"
    lineages_dir.mkdir(parents=True, exist_ok=True)

    result = subprocess.run(
        ["git", "remote", "get-url", "origin"],
        cwd=str(git_repo), check=True, capture_output=True, text=True,
    )
    remote_url = result.stdout.strip()

    data = {
        "lineage": {
            "id": lineage_id,
            "repo_name": git_repo.name,
            "target_repo": str(git_repo.relative_to(workspace_root)),
            "remote_name": "origin",
            "remote_url": remote_url,
            "copy_count": 3,
            "created_at": "2026-01-01T00:00:00+00:00",
        },
    }

    lineage_file = lineages_dir / f"{lineage_id}.toml"
    lineage_file.write_bytes(tomli_w.dumps(data).encode())

    return workspace_root, lineage_id, git_repo
