"""Tests for fork3._metadata module."""

from pathlib import Path

from fork3._metadata import (
    ensure_fork3_dir,
    derive_lineage_id,
    read_lineage_toml,
    write_lineage_toml,
    list_lineages,
    lineage_exists,
)
from fork3._output import FORK3_DIR, LINEAGES_DIR


def test_ensure_fork3_dir(tmp_path: Path) -> None:
    """Verify ensure_fork3_dir creates .fork3/lineages/ and returns the .fork3 path."""
    result = ensure_fork3_dir(tmp_path)

    assert result == tmp_path / FORK3_DIR
    assert (tmp_path / FORK3_DIR).is_dir()
    assert (tmp_path / FORK3_DIR / LINEAGES_DIR).is_dir()


def test_ensure_fork3_dir_idempotent(tmp_path: Path) -> None:
    """Call ensure_fork3_dir twice; no error and structure still correct."""
    ensure_fork3_dir(tmp_path)
    result = ensure_fork3_dir(tmp_path)

    assert result == tmp_path / FORK3_DIR
    assert (tmp_path / FORK3_DIR / LINEAGES_DIR).is_dir()


def test_derive_lineage_id_simple() -> None:
    """Simple name without separators passes through unchanged."""
    assert derive_lineage_id("my-project") == "my-project"


def test_derive_lineage_id_with_slashes() -> None:
    """Forward slashes are replaced with hyphens."""
    assert derive_lineage_id("libs/auth/core") == "libs-auth-core"


def test_derive_lineage_id_with_backslashes() -> None:
    """Backslashes are replaced with hyphens."""
    assert derive_lineage_id("libs\\auth") == "libs-auth"


def test_write_and_read_lineage_toml(tmp_path: Path) -> None:
    """Round-trip: write a dict then read it back and verify equality."""
    toml_path = tmp_path / "test.toml"
    data = {
        "lineage": {
            "id": "my-project",
            "repo_name": "my-project",
            "copy_count": 3,
            "created_at": "2025-01-01T00:00:00+00:00",
        }
    }

    write_lineage_toml(toml_path, data)
    result = read_lineage_toml(toml_path)

    assert result == data


def test_list_lineages_empty(tmp_path: Path) -> None:
    """No lineages directory returns an empty list."""
    assert list_lineages(tmp_path) == []


def test_list_lineages(tmp_path: Path) -> None:
    """Existing .toml files are returned as sorted lineage IDs."""
    lineages_dir = tmp_path / FORK3_DIR / LINEAGES_DIR
    lineages_dir.mkdir(parents=True)
    (lineages_dir / "a.toml").touch()
    (lineages_dir / "b.toml").touch()

    assert list_lineages(tmp_path) == ["a", "b"]


def test_lineage_exists_true(tmp_path: Path) -> None:
    """Returns True when the lineage TOML file exists."""
    lineages_dir = tmp_path / FORK3_DIR / LINEAGES_DIR
    lineages_dir.mkdir(parents=True)
    (lineages_dir / "foo.toml").touch()

    assert lineage_exists(tmp_path, "foo") is True


def test_lineage_exists_false(tmp_path: Path) -> None:
    """Returns False when the lineage TOML file does not exist."""
    assert lineage_exists(tmp_path, "nonexistent") is False
