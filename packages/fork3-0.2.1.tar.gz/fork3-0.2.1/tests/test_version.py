"""Tests for the VERSION file contract.

The VERSION file at the project root is the single source of truth.
These tests enforce that the runtime version matches the VERSION file.
"""

from __future__ import annotations

import re
from pathlib import Path

import fork3
from fork3._version import read_version

PROJECT_ROOT = Path(__file__).resolve().parent.parent
VERSION_FILE = PROJECT_ROOT / "VERSION"


def test_version_file_exists():
    """VERSION file must exist at project root."""
    assert VERSION_FILE.is_file(), f"VERSION file not found at {VERSION_FILE}"


def test_version_file_is_valid_semver():
    """VERSION file must contain a valid semver string."""
    content = VERSION_FILE.read_text(encoding="utf-8").strip()
    pattern = r"^\d+\.\d+\.\d+([a-zA-Z0-9.+-]*)$"
    assert re.match(pattern, content), f"VERSION content '{content}' is not valid semver"


def test_read_version_matches_file():
    """read_version() must return the same value as the VERSION file."""
    file_version = VERSION_FILE.read_text(encoding="utf-8").strip()
    runtime_version = read_version()
    assert runtime_version == file_version


def test_package_version_matches_file():
    """fork3.__version__ must match the VERSION file."""
    file_version = VERSION_FILE.read_text(encoding="utf-8").strip()
    assert fork3.__version__ == file_version
