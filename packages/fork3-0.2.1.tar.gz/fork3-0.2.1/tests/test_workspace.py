"""Tests for fork3._workspace module."""

import subprocess
from pathlib import Path

import pytest

from fork3._workspace import (
    find_workspace_root,
    resolve_workspace_root_for_setup,
    auto_detect_lineage,
    _path_starts_with,
    classify_slots,
    replicate_uv_env,
)
from fork3._output import FORK3_DIR


def test_find_workspace_root_found(tmp_path: Path) -> None:
    """Return the workspace root when .fork3/ exists at start."""
    (tmp_path / FORK3_DIR).mkdir()
    assert find_workspace_root(tmp_path) == tmp_path


def test_find_workspace_root_parent(tmp_path: Path) -> None:
    """Walk up to parent when .fork3/ is one level above start."""
    (tmp_path / FORK3_DIR).mkdir()
    child = tmp_path / "sub" / "deep"
    child.mkdir(parents=True)
    assert find_workspace_root(child) == tmp_path


def test_find_workspace_root_not_found(tmp_path: Path) -> None:
    """Return None when no .fork3/ exists within MAX_PARENT_WALK."""
    child = tmp_path / "a" / "b" / "c" / "d" / "e" / "f" / "g"
    child.mkdir(parents=True)
    assert find_workspace_root(child) is None


def test_resolve_workspace_root_existing_fork3(tmp_path: Path) -> None:
    """Use existing .fork3/ workspace root when found."""
    (tmp_path / FORK3_DIR).mkdir()
    ref_repo = tmp_path / "repo"
    ref_repo.mkdir()
    result = resolve_workspace_root_for_setup(ref_repo)
    assert result == tmp_path


def test_resolve_workspace_root_fallback_parent(tmp_path: Path) -> None:
    """Fall back to ref_repo.parent when no .fork3/ and CWD is not an ancestor."""
    ref_repo = tmp_path / "some" / "repo"
    ref_repo.mkdir(parents=True)
    result = resolve_workspace_root_for_setup(ref_repo)
    assert result.is_dir()


def test_path_starts_with_true() -> None:
    """Return True when full starts with prefix."""
    assert _path_starts_with(("a", "b", "c"), ("a", "b")) is True


def test_path_starts_with_exact() -> None:
    """Return True when full exactly equals prefix."""
    assert _path_starts_with(("a", "b"), ("a", "b")) is True


def test_path_starts_with_false() -> None:
    """Return False when full does not start with prefix."""
    assert _path_starts_with(("a", "b"), ("x", "y")) is False


def test_path_starts_with_prefix_longer() -> None:
    """Return False when prefix is longer than full."""
    assert _path_starts_with(("a",), ("a", "b")) is False


def test_classify_slots_all_missing(tmp_path: Path) -> None:
    """All slots are 'missing' when no branch directories exist."""
    results = classify_slots(tmp_path, "repo", 3, "https://example.com/repo.git")
    assert len(results) == 2
    assert all(status == "missing" for _, _, _, status in results)


def test_classify_slots_existing(git_repo: Path) -> None:
    """Slot is 'existing' when a valid clone with matching remote exists."""
    workspace_root = git_repo.parent
    repo_name = git_repo.name

    result = subprocess.run(
        ["git", "remote", "get-url", "origin"],
        cwd=str(git_repo), check=True, capture_output=True, text=True,
    )
    remote_url = result.stdout.strip()

    branch1 = workspace_root / "branch1" / repo_name
    subprocess.run(
        ["git", "clone", str(git_repo), str(branch1)],
        check=True, capture_output=True, text=True,
    )
    subprocess.run(
        ["git", "remote", "set-url", "origin", remote_url],
        cwd=str(branch1), check=True, capture_output=True, text=True,
    )

    results = classify_slots(workspace_root, repo_name, 3, remote_url)
    statuses = {label: status for _, label, _, status in results}
    assert statuses["branch1"] == "existing"
    assert statuses["branch2"] == "missing"


def test_classify_slots_invalid_no_git(tmp_path: Path) -> None:
    """Slot is 'invalid' when directory exists but is not a git repo."""
    repo_name = "repo"
    slot = tmp_path / "branch1" / repo_name
    slot.mkdir(parents=True)

    results = classify_slots(tmp_path, repo_name, 2, "https://example.com/repo.git")
    assert len(results) == 1
    assert results[0][3] == "invalid"


def test_replicate_uv_env_success(tmp_path: Path) -> None:
    """Copy .venv and .envrc from source to dest."""
    source = tmp_path / "source"
    source.mkdir()
    (source / ".venv").mkdir()
    (source / ".venv" / "bin").mkdir()
    (source / ".venv" / "bin" / "python").write_text("fake")
    (source / ".envrc").write_text("layout python")

    dest = tmp_path / "dest"
    dest.mkdir()

    assert replicate_uv_env(source, dest) is True
    assert (dest / ".venv" / "bin" / "python").read_text() == "fake"
    assert (dest / ".envrc").read_text() == "layout python"


def test_replicate_uv_env_no_venv(tmp_path: Path) -> None:
    """Return False when source has no .venv directory."""
    source = tmp_path / "source"
    source.mkdir()
    dest = tmp_path / "dest"
    dest.mkdir()

    assert replicate_uv_env(source, dest) is False


def test_auto_detect_lineage(workspace_with_lineage: tuple[Path, str, Path]) -> None:
    """Detect lineage when CWD is inside the target repo directory."""
    workspace_root, lineage_id, git_repo = workspace_with_lineage
    result = auto_detect_lineage(workspace_root, git_repo)
    assert result == lineage_id


def test_auto_detect_lineage_from_workspace_root_exits(
    workspace_with_lineage: tuple[Path, str, Path],
) -> None:
    """Exit with error when CWD is exactly the workspace root."""
    workspace_root, _, _ = workspace_with_lineage
    with pytest.raises(SystemExit):
        auto_detect_lineage(workspace_root, workspace_root)
