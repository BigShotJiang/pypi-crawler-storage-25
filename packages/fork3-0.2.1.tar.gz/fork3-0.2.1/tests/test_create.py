"""Tests for fork3 CLI argument parsing."""

import pytest

from fork3._cli import _looks_like_path, parse_args


def test_looks_like_path_with_slash() -> None:
    """Return True when the argument contains a forward slash."""
    assert _looks_like_path("./my-project") is True


def test_looks_like_path_with_nested_slash() -> None:
    """Return True when the argument contains a nested path separator."""
    assert _looks_like_path("libs/auth") is True


def test_looks_like_path_with_dot_prefix() -> None:
    """Return True when the argument starts with a dot."""
    assert _looks_like_path(".hidden") is True


def test_looks_like_path_plain_word() -> None:
    """Return False for a plain word without path indicators."""
    assert _looks_like_path("my-project") is False


def test_looks_like_path_flag() -> None:
    """Return False for a CLI flag."""
    assert _looks_like_path("--copies") is False


def test_parse_args_create_explicit() -> None:
    """Parse an explicit 'create' subcommand with repo path."""
    args = parse_args(["create", "./my-repo", "-n", "3"])
    assert args.command == "create"
    assert args.reference_repo == "./my-repo"
    assert args.copies == 3


def test_parse_args_create_shorthand() -> None:
    """Inject 'create' when the first positional arg looks like a path."""
    args = parse_args(["./my-repo", "-n", "4"])
    assert args.command == "create"
    assert args.reference_repo == "./my-repo"
    assert args.copies == 4


def test_parse_args_create_default_copies() -> None:
    """Default copy count is DEFAULT_COPY_COUNT when -n is omitted."""
    from fork3._output import DEFAULT_COPY_COUNT
    args = parse_args(["create", "./my-repo"])
    assert args.copies == DEFAULT_COPY_COUNT


def test_parse_args_push() -> None:
    """Parse a push subcommand with lineage option."""
    args = parse_args(["push", "-l", "my-project"])
    assert args.command == "push"
    assert args.lineage == "my-project"


def test_parse_args_sync() -> None:
    """Parse a sync subcommand with winner and lineage."""
    args = parse_args(["sync", "feat2", "-l", "my-project"])
    assert args.command == "sync"
    assert args.copy == "feat2"
    assert args.lineage == "my-project"


def test_parse_args_status() -> None:
    """Parse a status subcommand."""
    args = parse_args(["status", "-l", "my-project"])
    assert args.command == "status"
    assert args.lineage == "my-project"


def test_parse_args_status_alias() -> None:
    """Parse 'st' alias for status."""
    args = parse_args(["st"])
    assert args.command == "st"


def test_parse_args_init() -> None:
    """Parse an init subcommand with repo path and lineage."""
    args = parse_args(["init", "./my-repo", "-l", "custom-id"])
    assert args.command == "init"
    assert args.reference_repo == "./my-repo"
    assert args.lineage == "custom-id"


def test_parse_args_create_min_copies_error() -> None:
    """Exit with error when -n is below MIN_COPY_COUNT."""
    with pytest.raises(SystemExit):
        parse_args(["create", "./my-repo", "-n", "1"])


def test_parse_args_empty_exits() -> None:
    """Exit when no arguments provided."""
    with pytest.raises(SystemExit):
        parse_args([])


def test_parse_args_create_uv_flag() -> None:
    """Parse --uv flag in create subcommand."""
    args = parse_args(["create", "./my-repo", "--uv"])
    assert args.uv is True


def test_parse_args_push_dry_run() -> None:
    """Parse --dry-run flag in push subcommand."""
    args = parse_args(["push", "--dry-run"])
    assert args.dry_run is True


def test_parse_args_sync_force() -> None:
    """Parse --force flag in sync subcommand."""
    args = parse_args(["sync", "feat1", "--force"])
    assert args.force is True


def test_parse_args_sync_no_push() -> None:
    """Parse --no-push flag in sync subcommand."""
    args = parse_args(["sync", "feat1", "--no-push"])
    assert args.no_push is True
