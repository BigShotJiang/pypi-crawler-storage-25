---
id: tech-260418-fork3-testing-strategy
title: "fork3 — Testing Strategy"
status: draft
created: 2026-04-18
updated: 2026-04-19
source: "./docs/prd/prd-260418-fork3/index.md"
parent: "tech-260418-fork3"
superseded-by: ""
---

# fork3 — Testing Strategy

> **Standalone Migration (2026-04-19):** This document was originally written
> for the monorepo at `script_py/generic/git/fork3/`. The standalone package
> now lives at `src/fork3/` with tests at `tests/`. No `sys.path` manipulation
> is needed — install with `uv pip install -e .` and import directly.

## Framework

`pytest` — the de-facto standard for Python testing. Not currently in
`pyproject.toml` dependencies (it is a dev dependency, not a runtime
dependency).

Install for development:

```bash
uv pip install --python .venv/bin/python pytest
```

---

## Test Layout

All tests live under `tests/` and test the functions defined in
the `src/fork3/` package. Each test file targets a logical
module within the package.

```text
tests/
    ├── conftest.py              # shared fixtures
    ├── test_create.py           # create / expand integration tests
    ├── test_metadata.py         # lineage TOML round-trip tests
    ├── test_version.py          # version tests
    └── test_workspace.py        # workspace discovery + integration tests
```

Because fork3 is a multi-module package, tests import its functions
using package-relative imports:

```python
from fork3._git import git_current_branch, git_clone
from fork3._metadata import read_lineage_toml, write_lineage_toml
from fork3._workspace import find_workspace_root, classify_slots
```

---

## Fixture Design

All tests that touch the filesystem operate in `/tmp/` via pytest's
`tmp_path` fixture and clean up automatically after each test.

### `conftest.py` — Shared Fixtures

```python
@pytest.fixture
def tmp_workspace(tmp_path):
    """Provide a clean workspace directory under /tmp."""
    ws = tmp_path / "workspace"
    ws.mkdir()
    return ws

@pytest.fixture
def bare_remote(tmp_path):
    """Create a bare git repo to act as a remote origin."""
    remote = tmp_path / "remote.git"
    subprocess.run(["git", "init", "--bare", str(remote)], check=True)
    return remote

@pytest.fixture
def sample_repo(tmp_workspace, bare_remote):
    """Create a git repo cloned from bare_remote inside tmp_workspace."""
    repo = tmp_workspace / "my-project"
    subprocess.run(["git", "clone", str(bare_remote), str(repo)], check=True)
    readme = repo / "README.md"
    readme.write_text("init\n")
    subprocess.run(["git", "-C", str(repo), "add", "."], check=True)
    subprocess.run(["git", "-C", str(repo), "commit", "-m", "init"], check=True)
    subprocess.run(["git", "-C", str(repo), "push", "-u", "origin", "main"], check=True)
    return repo

@pytest.fixture
def workspace_with_lineage(sample_repo):
    """Run create to produce a workspace with .fork3/ and 3 copies."""
    from fork3._cmd_create import create_command
    # Invoke create programmatically or via subprocess
    ...
    return sample_repo.parent
```

### Git Sandbox Pattern

Every test that needs a git repo follows this pattern:

1. Create a bare repo in `/tmp` (`git init --bare`).
2. Clone it into the workspace directory.
3. Add a file, commit, push.
4. Now the test has a repo with a working remote.

This avoids network access — all git operations are local.

---

## Test Categories

### Unit Tests — Infrastructure Functions

| Logical Section | Test File | Key Test Cases |
|-----------------|-----------|---------------|
| Git wrappers | `test_git.py` | `git_current_branch` returns branch name. `git_current_branch` returns `None` on detached HEAD. `git_is_dirty` detects uncommitted changes. `git_dirty_count` returns correct file count. `git_ahead_behind` counts divergence. `git_clone` creates a working copy. `git_remote_url` returns the correct URL. `git_ls_remote` returns `True` for reachable, `False` for unreachable. |
| Metadata I/O | `test_metadata.py` | `write_lineage_toml` → `read_lineage_toml` round-trip produces identical dict. `list_lineages` returns sorted IDs. `lineage_exists` returns `True`/`False` correctly. `ensure_fork3_dir` creates `.fork3/lineages/` if missing. Corrupt TOML raises an error. |
| Discovery | `test_discovery.py` | `find_workspace_root` from target repo dir (1 hop). From offspring dir (2 hops). From nested dir (5 hops). Fail at 6 hops. `derive_lineage_id`: `libs/auth` → `libs-auth`. `auto_detect_lineage` matches correct lineage. Auto-detect fails at workspace root. Auto-detect fails with ambiguous match. `resolve_lineage` with explicit `-l` vs auto-detect. |
| Slots | `test_slots.py` | `classify_slots` with all-missing → all `"missing"`. With some existing → mix of `"existing"` and `"missing"`. With invalid path → `"invalid"`. Numeric sorting of `branchN/` dirs (not lexicographic). |

### Integration Tests — Commands

| Command | Test File | Key Test Cases |
|---------|-----------|---------------|
| `create` | `test_cmd_create.py` | Green-field: create workspace + 3 copies. Re-run (no-op): no new clones, no fetch, no push. Expansion: `-n 2` then `-n 4` adds 2 slots. Subset: `-n 4` then `-n 2` is a no-op. Multi-lineage: second create reuses `.fork3/`. Lineage ID collision: fail. Invalid repo path: fail. No remotes: fail. Remote unreachable: fail before mutation. `--uv` creates `.venv` in new slots. |
| `init` | `test_cmd_init.py` | Adopt pre-existing layout. Init with only target repo (no offspring). Init with lineage ID collision: fail. Init with invalid offspring: warn and skip. |
| `push` | `test_cmd_push.py` | Push all copies. Detached copy: skip + warn. `--dry-run`: no mutation. Single-copy lineage: no-op message. No upstream: push with `-u`. |
| `sync` | `test_cmd_sync.py` | Sync to winner by branch name. By copy label. By numeric index. Dirty copy blocks sync. `--force` overrides dirty check. `--no-push` resets locally only. `--dry-run`: print plan, no mutation. Detached winner: fail. Ambiguous winner: fail with guidance. |
| `status` | `test_cmd_status.py` | Output contains all columns. Dirty copy shows dirty state. Ahead/behind shows correct counts. Detached HEAD shows `(detached)`. Single-copy lineage: prints table with one row. |

### CLI Surface Tests

These can live in any test file (e.g., `test_cmd_create.py`) or a
dedicated `test_cli.py`:

| Scenario | Expectation |
|----------|-------------|
| `fork3 --help` | Exit 0, prints all subcommands |
| `fork3 --version` | Exit 0, prints version string |
| `fork3 ./repo -n 3` | Routes to create |
| `fork3 create ./repo -n 3` | Routes to create |
| `fork3 badcommand` | Exit 2, usage error |
| `fork3 create` (no repo) | Exit 2, missing argument |
| `fork3 create ./repo -n 1` | Exit 2, invalid `-n` (minimum 2) |

---

## Test Execution

```bash
# Run all fork3 tests
pytest tests/ -v

# Run a specific test file
pytest tests/test_create.py -v

# Run with output capture disabled (see git subprocess output)
pytest tests/ -v -s
```

---

## Test Timing Per Phase

Tests are written alongside implementation in each phase, not deferred.

| Phase | Test Activity |
|-------|---------------|
| Phase 1 | Write `conftest.py` fixtures. Write `test_git.py`, `test_metadata.py`, `test_discovery.py`, `test_slots.py`. All infrastructure functions have automated unit tests before Phase 2 begins. |
| Phase 2 | Write `test_cmd_create.py`. Cover green-field, no-op, expansion, subset, multi-lineage, collision, `--uv`. |
| Phase 3 | Write `test_cmd_init.py` and `test_cmd_status.py`. |
| Phase 4 | Write `test_cmd_push.py` and `test_cmd_sync.py`. Cover safety rules, dry-run, `--force`, `--no-push`. |
| Phase 5 | Add CLI surface tests. Run full suite as regression gate before installation integration. |

---

## What Is Not Tested

| Area | Reason |
|------|--------|
| Network-dependent git operations | Tests use local bare remotes only |
| `install.sh` / `uninstall.sh` integration | Tested manually (Phase 5) |
| `--uv` environment replication | Tested manually — venv internals are fragile to mock |
| Actual terminal color rendering | Output content is tested, ANSI codes are not |

---

## Coverage Targets

Coverage is measured per module in the `fork3/` package, mapped to the
test file that exercises it.

| Logical Section | Test File | Target |
|-----------------|-----------|--------|
| Data classes (`CopyInfo`, `WorkspaceContext`) | (exercised by all tests) | 100% |
| Output helpers (`colorize`, `info`, `ok`, `warn`, `error_exit`) | `test_git.py` / integration tests | 90% |
| Git wrappers (`git_*`) | `test_git.py` | 90% |
| Metadata I/O (`read_lineage_toml`, `write_lineage_toml`, etc.) | `test_metadata.py` | 95% |
| Discovery (`find_workspace_root`, `resolve_lineage`, etc.) | `test_discovery.py` | 95% |
| Slot classification (`classify_slots`) | `test_slots.py` | 95% |
| Create / Expand flow | `test_cmd_create.py` | 85% |
| Init flow | `test_cmd_init.py` | 85% |
| Push flow | `test_cmd_push.py` | 80% |
| Sync flow | `test_cmd_sync.py` | 80% |
| Status flow | `test_cmd_status.py` | 80% |
| **Overall** | **all** | **≥ 85%** |

---

## CI Considerations

No CI is configured for this repo currently. Tests are run locally.
If CI is added later, the test suite requires only:

- Python ≥ 3.11
- `git` available on PATH
- `pytest` installed
- Write access to `/tmp`
