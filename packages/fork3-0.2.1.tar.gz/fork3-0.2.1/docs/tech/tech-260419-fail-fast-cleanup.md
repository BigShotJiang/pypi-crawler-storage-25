---
id: "tech-260419-fail-fast-cleanup"
title: "fork3 — Pre-Production Fail-Fast Cleanup"
status: draft
created: 2026-04-19
updated: 2026-04-19
source: "technical-brief"
author: ""
tags:
  - tech-debt
  - fail-fast
  - cleanup
parent: "tech-260419-fork3-standalone"
superseded-by: ""
---

# fork3 — Pre-Production Fail-Fast Cleanup

## Context & Goals

### Engineering Motivation

fork3 is a pre-production (v0.1.0) CLI tool with zero users on any shipped artifact. The codebase contains defensive patterns that tolerate malformed state and historical formats that were never published. These patterns:

- **Mask bugs** — corrupted TOML files or packaging errors are silently recovered from rather than surfaced.
- **Carry dead code** — unused functions and speculative parameters add cognitive load and maintenance surface.
- **Violate fail-fast** — a pre-production tool should crash loudly on unexpected state so defects are caught during development, not papered over.

### Current State

| Pattern | Location | Problem |
|---------|----------|---------|
| Flat TOML fallback | `_workspace.py:96,158`, `_cmd_create.py:56` | `data.get("lineage", data)` tolerates a flat format never written by any code path |
| Defensive `.get()` on required fields | `_workspace.py:160-164` | Falls back to placeholder values for fields that `create`/`init` always write |
| Belt-and-suspenders version fallback | `_version.py:22-28` | Catches bare `Exception` and falls back to `importlib.metadata` |
| Dead code | `_git.py:88-97` | `git_is_dirty()` defined but never called |
| YAGNI parameter | `_git.py:26` | `bare=False` on `git_clone()` never exercised |
| Bare `except Exception` | `_version.py:25`, `_workspace.py:93` | Swallows all errors silently |

### Success Criteria

1. **No silent fallbacks for required data** — missing or malformed `.toml` fields raise immediately with a clear error message.
2. **No dead code** — every defined function and parameter is exercised by at least one call site.
3. **Specific exception handling** — `except` clauses catch only the expected error types.
4. **All existing tests pass** — no behavioral regression for valid inputs.

### Constraints

- No behavioral change for valid `.fork3/lineages/*.toml` files (the happy path is unaffected).
- Error messages must remain user-friendly (use `error_exit()` for user-facing failures).
- No new dependencies.

### Trigger

Code review during pre-release stabilization identified tolerance patterns appropriate for production migrations but unnecessary (and harmful) in a greenfield tool.

---

## Non-Goals

- Introducing a TOML schema validation library (overkill for 6 fields).
- Refactoring module boundaries or public API surface.
- Performance optimization.
- Adding new features or commands.

---

## System Context

This refactoring is internal to the fork3 CLI. No external actors are affected. The impacted components are:

```
┌─────────────────────────────────────────────────────┐
│  fork3 CLI                                          │
│                                                     │
│  ┌──────────┐   ┌──────────────┐   ┌───────────┐   │
│  │ _version │   │ _workspace   │   │ _git      │   │
│  └──────────┘   └──────────────┘   └───────────┘   │
│                          │                          │
│                 ┌────────▼────────┐                 │
│                 │ _cmd_create     │                 │
│                 └─────────────────┘                 │
└─────────────────────────────────────────────────────┘
                          │
                 ┌────────▼────────┐
                 │ .fork3/lineages │  (TOML on disk)
                 └─────────────────┘
```

Upstream: User invokes CLI commands.
Downstream: TOML files on disk (format is self-owned, no external consumers).

---

## Component Architecture

### Affected Components

| Component | File | Ownership | Change Type |
|-----------|------|-----------|-------------|
| Version loader | `_version.py` | fork3 core | Remove fallback, narrow exception |
| Workspace resolver | `_workspace.py` | fork3 core | Require `[lineage]` key, require fields |
| Create command | `_cmd_create.py` | fork3 commands | Remove flat-format fallback |
| Git wrapper | `_git.py` | fork3 core | Remove dead code, remove unused param |

---

## Data Flow

### TOML Read Path (Current — Tolerant)

```
read_lineage_toml(path)
  → raw dict
    → data.get("lineage", data)     ← fallback to raw dict
      → meta.get("repo_name", lid)  ← fallback to lid
      → meta.get("remote_url", "") ← fallback to empty string
```

### TOML Read Path (Target — Strict)

```
read_lineage_toml(path)
  → raw dict
    → data["lineage"]               ← KeyError → error_exit()
      → meta["repo_name"]           ← KeyError → error_exit()
      → meta["remote_url"]          ← KeyError → error_exit()
```

---

## Data Model

No changes to the logical data model. The TOML schema remains:

```toml
[lineage]
id = "..."
repo_name = "..."
target_repo = "..."
remote_name = "..."
remote_url = "..."
copy_count = 3
created_at = "..."
```

All fields under `[lineage]` are now treated as **required** (no fallback defaults).

---

## API & Contract Surface

No external API. Internal contract change:

| Function | Before | After |
|----------|--------|-------|
| `read_lineage_toml()` | Returns `dict` (caller must handle missing keys) | Returns `dict` (unchanged) |
| New: validation at call sites | `.get(key, default)` | `dict[key]` with `error_exit()` on `KeyError` |
| `git_clone()` | `(source, dest, bare=False)` | `(source, dest)` |
| `git_is_dirty()` | Defined | Removed |
| `read_version()` | Falls back to `importlib.metadata` | Direct read only, `FileNotFoundError` propagates |

---

## NFR & SLO Targets

Not applicable — this is an internal refactoring of a CLI tool with no SLA.

| Metric | Requirement |
|--------|-------------|
| Correctness | All existing tests pass; no behavioral change on valid inputs |
| Error clarity | Invalid TOML triggers a single-line error message via `error_exit()` |

---

## Cross-Cutting Concerns

- **Error handling**: Shift from silent-fallback to fail-fast with `error_exit()`. User sees a clear message; developer gets a traceable failure.
- **Logging/Observability**: No change (CLI uses stderr for errors).
- **Testing**: Existing tests cover the happy path. No new test fixtures needed unless a test was relying on fallback behavior (unlikely given the format was never written).

---

## Trade-Off Analysis

### Option A: Introduce a schema validator (e.g. pydantic, cattrs)

- **Pro**: Declarative schema, auto-generated error messages.
- **Con**: New dependency for 6 fields; violates minimal-dependency goal.
- **Decision**: Rejected.

### Option B: Manual key access with `error_exit()` on `KeyError`

- **Pro**: Zero new dependencies; explicit; easy to read; matches existing error pattern.
- **Con**: Slightly more boilerplate than a schema library.
- **Decision**: **Accepted**. Aligns with project constraints and existing patterns.

### Option C: Keep defensive `.get()` fallbacks

- **Pro**: Zero effort.
- **Con**: Masks bugs in a pre-production tool where they should be caught early.
- **Decision**: Rejected. This is the status quo and the reason for this refactoring.

---

## Execution Plan

### Phase 1: Dead Code Removal (no behavioral change)

| Track | Task | Dependency |
|-------|------|------------|
| 1A | Remove `git_is_dirty()` from `_git.py` | None |
| 1B | Remove `bare` parameter from `git_clone()` | None |

**Gate**: All tests pass.

### Phase 2: Strict TOML Parsing

| Track | Task | Dependency |
|-------|------|------------|
| 2A | Replace `data.get("lineage", data)` with `data["lineage"]` + `error_exit()` in `_workspace.py` and `_cmd_create.py` | Phase 1 gate |
| 2B | Replace `.get(field, default)` with direct key access + `error_exit()` for required fields in `_workspace.py:resolve_lineage` | Phase 1 gate |

**Gate**: All tests pass.

### Phase 3: Version & Exception Narrowing

| Track | Task | Dependency |
|-------|------|------------|
| 3A | Remove `importlib.metadata` fallback in `_version.py`; narrow to `FileNotFoundError` or remove try/except entirely | Phase 2 gate |
| 3B | Narrow `except Exception` to `except (FileNotFoundError, tomllib.TOMLDecodeError)` in `_workspace.py:auto_detect_lineage` | Phase 2 gate |

**Gate**: All tests pass; `pytest` green; manual smoke test of `fork3 create` and `fork3 st`.

### Dependency Graph

```
Phase 1A ─┐
           ├── Gate 1 ── Phase 2A ─┐
Phase 1B ─┘              Phase 2B ─┼── Gate 2 ── Phase 3A ─┐
                                   │              Phase 3B ─┼── Gate 3 (Done)
                                   └───────────────────────┘
```

---

## Risks & Mitigations

| Risk | Severity | Mitigation |
|------|----------|------------|
| A test fixture relies on fallback behavior | Low | Audit test fixtures before Phase 2; fix any that omit required fields |
| `read_version()` removal breaks editable installs (`pip install -e .`) | Medium | Verify with `uv pip install -e .` in dev; if `files()` fails in editable mode, keep a narrow fallback for `FileNotFoundError` only |
| Future TOML schema additions require updating validation | Low | Acceptable — adding a field means adding one `[]` access and one `error_exit()` line |

---

## Open Questions

1. Should `_workspace.py:auto_detect_lineage` log which `.toml` files failed parsing (with specific error) rather than silently skipping, even in the strict mode? This could help debug workspace corruption.
2. Should `read_version()` in editable-install mode still have a fallback? Needs verification that `importlib.resources.files()` works with `pip install -e .` under hatchling.
