---
id: "tech-260420-pre-release-code-debt-cleanup"
title: "Pre-Release Code Debt Cleanup"
status: draft
created: 2026-04-20
updated: 2026-04-20
source: "technical-brief"
author: "Cheng Yanru"
tags: [code-debt, refactor, pre-release]
parent: ""
superseded-by: ""
---

# Pre-Release Code Debt Cleanup

## 1 Context & Goals

### Technical Brief

| Element | Detail |
|---|---|
| **Engineering Motivation** | fork3 is pre-release (v0.1.0). The codebase contains patterns inherited from older Python idioms, silent-forgiveness strategies, and backward-compatibility shims that would be appropriate in a shipped product but represent unwarranted tolerance in a greenfield project. These patterns obscure bugs, confuse future contributors, and set a precedent that tolerance-of-bad-state is acceptable design. |
| **Current State** | Five concrete debt traces identified across `_workspace.py`, `_cmd_create.py`, `_cmd_ops.py`, `_git.py`, `_version.py`. All are behavioral — they change how the system responds to invalid or ambiguous state. |
| **Success Criteria** | (1) Zero silent-skip of malformed data — every tolerance path either errors or warns. (2) Zero pre-3.11 compatibility idioms. (3) `git_ahead_behind` failure is distinguishable from "in sync." (4) `copy_count` decrease is explicitly handled. (5) All existing tests pass. |
| **Constraints** | No public API changes (CLI flags, TOML schema, exit codes). Internal function signatures may change where callers are all within this repo. |
| **Trigger** | Audit of codebase for production-readiness. |

### Goal

Eliminate all traces of backward-compatibility tolerance and silent-error-masking so the codebase reflects its actual status: a pre-production system that should fail fast on unexpected state.

### Non-Goals

- Changing the TOML lineage schema.
- Adding new CLI commands or flags.
- Refactoring module boundaries or file layout.
- Performance optimization.

---

## 2 System Context

No change to external actors or system boundaries. fork3 remains a single-process CLI tool that shells out to `git`. This refactor is entirely internal to the fork3 package.

```
User ──▶ fork3 CLI ──▶ git (subprocess)
              │
              ▼
         .fork3/lineages/*.toml (local filesystem)
```

---

## 3 Component Architecture

Affected components (all within `src/fork3/`):

| Component | Role | Debt Items |
|---|---|---|
| `_workspace.py` | Workspace discovery, lineage resolution | D1 (path containment idiom), D2 (silent skip of malformed lineage) |
| `_cmd_create.py` | `create` command implementation | D3 (silent copy_count clamp) |
| `_cmd_ops.py` | `push` / `sync` / `status` commands | D1 (path containment idiom), D4 (ahead/behind masking) |
| `_git.py` | Git subprocess wrappers | D4 (ahead/behind error masking) |
| `_version.py` | Version resolution | D5 (`__future__` annotations leftover) |

No ownership boundary changes. No new components introduced.

---

## 4 Debt Items

### D1 — `try/except ValueError` for Path Containment

**Current:** Uses pre-3.9 `Path.relative_to()` + catch `ValueError` idiom to test path containment.

**Locations:**
- `_workspace.py` → `resolve_workspace_root_for_setup()` (L52–56)
- `_workspace.py` → `auto_detect_lineage()` (L75–81)
- `_cmd_ops.py` → `_detect_current_copy()` (L51–55)

**Target:** Replace with `Path.is_relative_to()` (available since Python 3.9, repo requires ≥3.11).

**Contract change:** None. Return values and error behavior identical.

**Risk:** Minimal — `is_relative_to()` is the standard-library replacement for this exact pattern.

---

### D2 — Silent Skip of Malformed Lineage Files

**Current:** `auto_detect_lineage()` catches `FileNotFoundError`, `TOMLDecodeError`, and `KeyError` on lineage files and silently `continue`s, producing no diagnostic output.

**Location:** `_workspace.py` → `auto_detect_lineage()` (L91–101)

**Problem:** In a pre-production system, a malformed `.toml` under `.fork3/lineages/` is a bug, not a recoverable condition. Silent skip hides corruption.

**Target:** Emit a `warn()` for each skipped file, stating the filename and reason (parse error or missing key). Continue iteration (non-fatal) but make the problem visible.

**Contract change:** New stderr output on malformed files. No change to return value or control flow.

**Risk:** Low — adds diagnostic output only. Existing tests don't assert on stderr content for this path.

---

### D3 — Silent `copy_count` Clamp via `max()`

**Current:** `_update_lineage_toml()` silently uses `max(copy_count, existing_count)`, ignoring the user's explicit `-n` when it's lower than the stored count.

**Location:** `_cmd_create.py` → `_update_lineage_toml()` (L164)

**Problem:** The user runs `fork3 create ./repo -n 2` expecting 2 copies, but the tool silently keeps the old higher count. This is a backward-compat guard (don't orphan old copies) disguised as a feature.

**Target:** When the requested count is lower than the stored count, emit a `warn()` informing the user that the count was not decreased and why (existing offspring directories). Keep the `max()` behavior — but make it explicit, not silent.

**Contract change:** New stderr warning when count is clamped. No change to the TOML write behavior.

**Risk:** Low — behavioral change is limited to a new warning message.

---

### D4 — `git_ahead_behind` Masks Failure as `(0, 0)`

**Current:** When `git rev-list --left-right --count HEAD...@{u}` fails (e.g., no upstream configured), the function returns `(0, 0)`.

**Location:** `_git.py` → `git_ahead_behind()` (L118–119)

**Problem:** `(0, 0)` is indistinguishable from "perfectly in sync." The status table shows `0/0` for copies that have no upstream — misleading.

**Target:**
1. Change `git_ahead_behind()` return type to `tuple[int, int] | None`. Return `None` on failure.
2. Update `_gather_copy_state()` in `_cmd_ops.py` to handle `None` — store as `ahead=0, behind=0` but set a new `no_upstream: bool` flag on `CopyInfo`.
3. Update `_print_status_table()` to display `—` instead of `0/0` when `no_upstream` is true.

**Contract change:**
- `git_ahead_behind()` return type changes: `tuple[int, int]` → `tuple[int, int] | None`.
- `CopyInfo` gains a `no_upstream: bool = False` field.
- Status table display changes for copies without upstream.

**Risk:** Medium — touches the data model and display layer. Requires updating `_gather_copy_state` and `_print_status_table`. All callers are internal.

---

### D5 — Stale `from __future__ import annotations`

**Current:** `_version.py` imports `from __future__ import annotations`. No other module does. The project requires Python ≥3.11 where native `X | Y` union syntax works at runtime.

**Location:** `_version.py` (L10)

**Problem:** Signals "this module was written for older Python" — misleading in a 3.11+ project.

**Target:** Remove the import.

**Contract change:** None. The module uses no annotations that require deferred evaluation.

**Risk:** Negligible.

---

## 5 Data Model Changes

Single addition to `CopyInfo`:

```
CopyInfo
  + no_upstream: bool = False    # True when git has no tracking branch configured
```

No TOML schema changes. No new files.

---

## 6 Trade-Off Analysis

### D3: Warn vs Error on Count Decrease

| Option | Behavior | Pros | Cons |
|---|---|---|---|
| **A. Warn + keep max** | Emit warning, apply `max()` | Non-breaking; user sees explanation | User's `-n` is still silently overridden |
| **B. Error + abort** | Reject the command | Forces explicit intent | Disrupts workflow; user must delete orphans manually |
| **C. Allow decrease + cleanup** | Delete orphan directories | Respects `-n` literally | Destructive; data loss risk; out of scope |

**Decision:** Option A. Rationale: The `max()` guard is actually correct behavior for preventing orphans. The debt is not the logic — it's the silence. A warning closes the information gap without introducing destructive behavior. Option C would require a new `prune` command (out of scope).

### D4: `None` Return vs Sentinel Tuple

| Option | Signature | Pros | Cons |
|---|---|---|---|
| **A. Return `None`** | `tuple[int, int] | None` | Clear semantic: "no data" ≠ "zero" | Callers must handle `None` |
| **B. Return `(-1, -1)`** | `tuple[int, int]` | No type change | Magic numbers; negative counts are confusing |

**Decision:** Option A. Rationale: The `None` return is idiomatic Python for "data unavailable." Only one caller (`_gather_copy_state`) needs updating.

---

## 7 Execution Plan

### Phase 1 — Isolated, Zero-Risk Changes (Parallel)

| Track | Item | Files | Dependency |
|---|---|---|---|
| 1A | D5: Remove `__future__` import | `_version.py` | None |
| 1B | D1: Replace `try/except ValueError` with `is_relative_to()` | `_workspace.py`, `_cmd_ops.py` | None |

**Gate:** All existing tests pass.

### Phase 2 — Diagnostic Improvements (Parallel)

| Track | Item | Files | Dependency |
|---|---|---|---|
| 2A | D2: Add `warn()` on malformed lineage files | `_workspace.py` | Phase 1 |
| 2B | D3: Add `warn()` on copy_count clamp | `_cmd_create.py` | Phase 1 |

**Gate:** All existing tests pass. Manual verification: trigger each warning by crafting a malformed `.toml` and a lower `-n` value.

### Phase 3 — Model + Display Change (Sequential)

| Step | Item | Files | Dependency |
|---|---|---|---|
| 3A | D4: Change `git_ahead_behind()` return type | `_git.py` | Phase 1 |
| 3B | D4: Add `no_upstream` to `CopyInfo` | `_models.py` | 3A |
| 3C | D4: Update `_gather_copy_state()` | `_cmd_ops.py` | 3A, 3B |
| 3D | D4: Update `_print_status_table()` display | `_cmd_ops.py` | 3C |

**Gate:** All existing tests pass. Manual verification: `fork3 st` on a lineage with a detached/no-upstream copy shows `—` instead of `0/0`.

### Dependency Graph

```
Phase 1:  1A ──┐
          1B ──┤
               ▼
Phase 2:  2A ──┐
          2B ──┤
               ▼
Phase 3:  3A → 3B → 3C → 3D
```

---

## 8 Risks & Mitigations

| Risk | Severity | Mitigation |
|---|---|---|
| `is_relative_to()` has subtle behavioral difference from `relative_to()` + catch | Low | Both methods use `PurePath._from_parsed_parts` internally. Behavior is identical for containment checks. Covered by existing tests. |
| New warnings break scripts that parse stderr | Low | No known downstream consumers. fork3 is pre-release with no published API contract for stderr. |
| `no_upstream` flag not populated on all code paths | Medium | Audit all `_gather_copy_state()` call sites (only 3: `push_command`, `sync_command`, `status_command`). Add test for no-upstream scenario. |

---

## 9 Open Questions

| # | Question | Impact | Status |
|---|---|---|---|
| 1 | Should D2 warnings be gated behind a `--verbose` flag to keep default output clean? | UX | Open — current decision: always warn (pre-production tool, fail-loud philosophy) |
| 2 | Should D4 add a dedicated test for the no-upstream display case? | Test coverage | Open — recommended yes, but out of scope for this refactor doc |
