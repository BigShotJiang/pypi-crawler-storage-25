---
id: tech-260418-fork3-execution-plan
title: "fork3 — Execution Plan"
status: draft
created: 2026-04-18
updated: 2026-04-19
source: "./docs/prd/prd-260418-fork3/index.md"
parent: "tech-260418-fork3"
superseded-by: ""
---

# fork3 — Execution Plan

> **Standalone Migration (2026-04-19):** This document was originally written
> for the monorepo at `script_py/generic/git/fork3/`. The standalone package
> now lives at `src/fork3/`. All `generic/git/fork3/` references below map to
> `src/fork3/` in the current repo layout.

## Phase Strategy

The implementation is split into 5 phases. Each phase produces a working, testable increment. Phase boundaries are chosen so that:

1. Each phase can be verified independently before moving on.
2. Earlier phases lay the foundation that later phases depend on.
3. The most critical and complex functionality (create) ships first.

---

## Dependency Graph

```
Phase 1: Scaffold + Infrastructure
    │
    ├──▸ Phase 2: Create / Expand (core command)
    │        │
    │        ├──▸ Phase 3: Init + Status (read-heavy commands)
    │        │
    │        └──▸ Phase 4: Push + Sync (write-heavy commands)
    │
    └──▸ Phase 5: Installation + Polish
```

Phases 3 and 4 are independent of each other and can be developed in either order (or in parallel). Phase 5 is a final integration pass.

---

## Phase 1 — Scaffold + Infrastructure

### Goal

Establish the file, the CLI skeleton, data classes, output helpers, workspace discovery, lineage metadata I/O, and git operation wrappers. No command logic yet — just the building blocks.

### Deliverables

| Deliverable | Description |
|-------------|-------------|
| `src/fork3/` (package) | Multi-module package with `__init__.py`, `__main__.py`, `_cli.py`, `_output.py`, `_models.py`, `_git.py`, `_metadata.py`, `_workspace.py`, `_cmd_create.py`, `_cmd_ops.py` |
| `colorize()` + output helpers | `info()`, `ok()`, `warn()`, `error_exit()` |
| `WorkspaceContext` dataclass | All fields from index.md |
| `CopyInfo` dataclass | All fields from index.md |
| `find_workspace_root(start: Path)` | Walk up to 5 parents looking for `.fork3/` |
| `resolve_lineage(args, cwd)` | Explicit `-l` or auto-detect, return `WorkspaceContext` |
| `auto_detect_lineage(workspace_root, cwd)` | CWD-relative matching against known lineages |
| `read_lineage_toml(path)` | Parse a `.fork3/lineages/<id>.toml` file |
| `write_lineage_toml(path, data)` | Serialize lineage metadata to TOML |
| `list_lineages(workspace_root)` | Enumerate all `.toml` files under `lineages/` |
| `classify_slots(workspace_root, lineage_id, repo_name, n, remote_url)` | Return per-slot classification |
| Git wrappers | `git_clone()`, `git_push()`, `git_fetch_all()`, `git_current_branch()`, `git_is_dirty()`, `git_ahead_behind()`, `git_remote_url()`, `git_ls_remote()` |
| `parse_args()` | argparse with subcommands (create, init, push, sync, status) + root-level create shorthand |
| `main()` | Dispatch stub that prints "not implemented" per subcommand |
| `tests/fork3/conftest.py` | Shared pytest fixtures: `tmp_workspace`, `bare_remote`, `sample_repo` |
| `tests/fork3/test_git.py` | Unit tests for all `git_*()` wrappers |
| `tests/fork3/test_metadata.py` | Round-trip and error tests for TOML I/O functions |
| `tests/fork3/test_discovery.py` | Workspace discovery and lineage resolution tests |
| `tests/fork3/test_slots.py` | Slot classification tests |

### Exit Criteria

- `fork3 --help` prints well-formatted help with all subcommands listed.
- `fork3 --version` prints the version.
- `fork3 create --help` prints create-specific help.
- Running any subcommand prints a "not yet implemented" message and exits cleanly.
- `pytest tests/fork3/ -v` runs all infrastructure unit tests and they pass.

---

## Phase 2 — Create / Expand

### Goal

Implement the full create / expand flow — the most complex command and the foundation of the entire tool.

### Deliverables

| Deliverable | Description |
|-------------|-------------|
| `create_command(args)` | Complete 13-step create flow from PRD §1 |
| Slot creation | Clone, branch checkout (`featN`), push with upstream |
| Idempotency | Exact re-run = no-op, subset re-run = no-op, expansion = create only new |
| `.fork3/` bootstrap | Create `.fork3/` and `lineages/` on first run |
| Lineage registration | Write `.fork3/lineages/<id>.toml` with metadata |
| Multi-lineage | Second `create` for a different repo adds to existing `.fork3/` |
| Remote pre-flight | Verify remotes are reachable before mutation |
| Post-create fetch | Parallel fetch-all so new branches are visible everywhere |
| `--uv` support | `replicate_uv_env()` for newly created slots |
| Output | Matches PRD output examples (expansion case, no-op case) |
| `tests/fork3/test_cmd_create.py` | Integration tests: green-field, no-op, expansion, subset, multi-lineage, collision, error cases |

### Exit Criteria

- `fork3 ./repo -n 3` creates a 3-copy lineage with correct directory layout.
- Re-running `fork3 ./repo -n 3` is a no-op (no I/O, no fetch).
- `fork3 ./repo -n 5` after `-n 3` creates only slots 3 and 4.
- `fork3 ./other-repo -n 2` in the same workspace adds a second lineage.
- Lineage ID collision is rejected with a clear error.
- `.fork3/lineages/<id>.toml` contains correct metadata.
- `--uv` replicates the venv into new copies.
- `pytest tests/fork3/test_cmd_create.py -v` — all tests pass.

---

## Phase 3 — Init + Status

### Goal

Implement the two read-heavy commands that round out workspace management without mutation.

### Deliverables

| Deliverable | Description |
|-------------|-------------|
| `init_command(args)` | Adopt existing layout per PRD §2 |
| Directory scanning | Discover `branchN/<repo>/` dirs matching the lineage |
| Validation | Verify each discovered copy has matching remote URL |
| `status_command(args)` | Print status table per PRD §5 |
| Table formatting | Copy, Dir, Branch, Remote, Dirty, Ahead/Behind columns |
| Auto-detection | Both commands work with `-l` and CWD-based auto-detect |
| `tests/fork3/test_cmd_init.py` | Integration tests: adopt layout, no-offspring, collision, invalid offspring |
| `tests/fork3/test_cmd_status.py` | Integration tests: all columns, dirty, ahead/behind, detached, auto-detect |

### Exit Criteria

- `fork3 init ./repo` adopts an existing layout and writes `.fork3/lineages/<id>.toml`.
- `fork3 init ./repo` on an already-registered lineage fails with a collision error.
- `fork3 status -l <id>` prints a correct status table.
- `fork3 status` inside a copy auto-detects the lineage.
- Detached HEAD copies show detached state in the status table.
- Dirty copies show file count in the Dirty column.
- `pytest tests/fork3/test_cmd_init.py tests/fork3/test_cmd_status.py -v` — all pass.

---

## Phase 4 — Push + Sync

### Goal

Implement the two mutating operational commands with full safety semantics.

### Deliverables

| Deliverable | Description |
|-------------|-------------|
| `push_command(args)` | Push all eligible copies per PRD §3 |
| Push eligibility | Normal branch → push; no upstream → push with `-u`; detached → skip + warn |
| Parallel push | `ThreadPoolExecutor` for push, then parallel fetch-all |
| `--dry-run` for push | Print logical operations without mutation |
| `sync_command(args)` | Sync to winner per PRD §4 |
| Winner resolution | By branch name → copy label → numeric index |
| Safety checks | Dirty copies block unless `--force`; detached winner = fail |
| Reset + force-push-with-lease | Per non-winner eligible copy |
| `--no-push` for sync | Skip the force-push step |
| `--dry-run` for sync | Print winner and per-copy plan |
| Post-sync fetch | Parallel fetch-all |
| `tests/fork3/test_cmd_push.py` | Integration tests: push all, detached skip, dry-run, single-copy no-op, no-upstream |
| `tests/fork3/test_cmd_sync.py` | Integration tests: winner resolution, dirty block, --force, --no-push, --dry-run, detached winner |

### Exit Criteria

- `fork3 push -l <id>` pushes all copies and fetches.
- Detached HEAD copies are skipped with a warning during push.
- `fork3 push --dry-run` shows the plan without mutation.
- `fork3 sync branch2 -l <id>` resets all non-winner copies to branch2's branch.
- Dirty copies block sync; `--force` overrides.
- `fork3 sync --dry-run` shows the plan.
- `fork3 sync --no-push` resets locally without pushing.
- Force-with-lease is used (not blind force push).
- `pytest tests/fork3/test_cmd_push.py tests/fork3/test_cmd_sync.py -v` — all pass.

---

## Phase 5 — Installation + Polish

### Goal

Integrate fork3 into the repo's installation system, add the `--version` flag, final output polish, and edge-case hardening.

### Deliverables

| Deliverable | Description |
|-------------|-------------|
| `install.sh` update | Add `"generic/git/*"` to the INCLUDE array |
| `pyproject.toml` update | Add `tomli_w` if the TOML-write approach requires it |
| Pre-commit checklist | Verify all items from the python-script skill checklist |
| Edge-case audit | Verify all error cases from PRD output-and-errors.md |
| Output consistency pass | Match all PRD output examples exactly |
| `--help` polish | Epilog examples, metavar tuning, help text completeness |
| CLI surface tests | `tests/fork3/test_cli.py` — `--help`, `--version`, root create routing, usage errors |
| Full regression run | `pytest tests/fork3/ -v` as gate before release |

### Exit Criteria

- `./install.sh` installs `fork3` as a wrapper in `~/.local/bin/fork3`.
- `fork3 --help` and `fork3 --version` work from any directory.
- All PRD error cases produce the specified error messages and exit codes.
- The python-script skill pre-commit checklist passes.
- `pytest tests/fork3/ -v` — full suite passes with no regressions.

---

## Phase Summary

| Phase | Name | Depends On | Key Risk |
|-------|------|------------|----------|
| 1 | Scaffold + Infrastructure | — | argparse subcommand + root-level fallback is tricky |
| 2 | Create / Expand | Phase 1 | Idempotency edge cases, multi-lineage `.fork3/` management |
| 3 | Init + Status | Phase 1 | Directory scanning heuristics for init |
| 4 | Push + Sync | Phase 1 | Force-with-lease semantics, dirty-copy detection |
| 5 | Installation + Polish | Phases 1–4 | install.sh glob compatibility |
