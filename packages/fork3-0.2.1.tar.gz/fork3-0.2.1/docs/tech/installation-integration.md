---
id: tech-260418-fork3-installation-integration
title: "fork3 — Installation Integration"
status: superseded
created: 2026-04-18
updated: 2026-04-19
source: "./docs/prd/prd-260418-fork3/index.md"
parent: "tech-260418-fork3"
superseded-by: "tech-260419-fork3-standalone"
---

# fork3 — Installation Integration

> **Superseded (2026-04-19):** This document described the monorepo
> `install.sh` wrapper-based integration. fork3 is now a standalone package
> installed via `pip install fork3` or `uv pip install -e .`. The entry point
> is defined in `pyproject.toml` under `[project.scripts]`.
>
> See [tech-260419-fork3-standalone.md](./tech-260419-fork3-standalone.md) for
> the current installation design.
>
> The original content is preserved in git history (`git log --all -p -- docs/tech/installation-integration.md`).
