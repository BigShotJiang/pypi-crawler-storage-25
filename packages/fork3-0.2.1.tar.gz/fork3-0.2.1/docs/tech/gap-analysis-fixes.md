---
id: tech-260418-fork3-gap-analysis-fixes
title: "fork3 — Gap Analysis & Required Fixes"
status: draft
created: 2026-04-19
updated: 2026-04-19
source: "./docs/prd/prd-260418-fork3/index.md"
parent: "tech-260418-fork3"
superseded-by: ""
---

# fork3 — Gap Analysis & Required Fixes

> **Standalone Migration (2026-04-19):** This document was originally written
> for the monorepo at `script_py/generic/git/fork3/`. The standalone package
> now lives at `src/fork3/`. All `generic/git/fork3/` path references below
> correspond to `src/fork3/` in the current repo layout.

## Context & Goals

The initial tech design (`tech-260418-fork3`) was written against a single-file `generic/git/fork3.py` architecture. During implementation the codebase was refactored into a multi-module package at `generic/git/fork3/`. This was the correct engineering decision — 10 focused modules are far more maintainable than a single 1000+ line file — but it introduced drift between the tech design and the implementation.

This supplemental document:

1. Catalogues every concrete gap between the PRD, the original tech design, and the shipped implementation.
2. Specifies the exact fix for each gap at the component-contract level.
3. Provides a phased execution plan for applying the fixes.

This document does **not** re-specify anything that already works correctly. It is purely additive to the existing tech design.

---

## Non-Goals

- Rewriting the existing tech design documents; they remain the canonical reference for the overall phase strategy.
- Changing the module decomposition; the current 10-module package is the correct architecture.
- Adding new user-facing features beyond what the PRD already specifies.

---

## Gap Inventory

| # | Gap | Severity | PRD Section | Code Location |
|---|-----|----------|-------------|---------------|
| G1 | Workspace root resolution for nested repos | **Critical** | lineage-model.md §`.fork3/ Location`, walkthrough.md §Step 2 | `_workspace.py:185`, `_cmd_create.py:214` |
| G2 | Lineage ID derivation ignores nested relative path | **Critical** | lineage-model.md §Default Lineage ID Derivation | `_workspace.py:188`, `_cmd_create.py:216` |
| G3 | `classify_slots` hardcodes `"origin"` remote | **High** | idempotency.md §Slot Classification Rules | `_workspace.py:230` |
| G4 | `_looks_like_path` heuristic misses bare directory names | **Medium** | cli-commands.md §Root-Level Create Shorthand | `_cli.py:12-13` |
| G5 | No subprocess timeouts on git operations | **Medium** | (defensive engineering) | `_git.py` (all functions) |
| G6 | No graceful signal handling for `KeyboardInterrupt` | **Low** | output-and-errors.md §General Output Rules | `_cli.py:249-263` |
| G7 | Tech design references single-file architecture | **Medium** | (documentation drift) | All 4 existing tech design docs |
| G8 | `tomli_w` used despite tech design recommending manual writer | **Low** | installation-integration.md §Recommendation | `_metadata.py:6, 34` |

---

## G1 — Workspace Root Resolution for Nested Repos

### Problem

The PRD walkthrough shows:

```
cd /home/dev/work
fork3 ./libs/auth-service -n 2
```

The expected workspace root is `/home/dev/work/` — the directory the user ran the command from, which is the common parent of both `my-project/` and `libs/auth-service/`.

The current code at `_workspace.py:185` and `_cmd_create.py:214` does:

```python
workspace_root = ref_repo.parent
```

For `./libs/auth-service`, `ref_repo.resolve()` = `/home/dev/work/libs/auth-service`, so `ref_repo.parent` = `/home/dev/work/libs/` — **not** the intended workspace root. This breaks:

- `.fork3/` gets created at `libs/.fork3/` instead of `work/.fork3/`
- Multi-lineage registration fails because `my-project` and `libs/auth-service` end up in different workspaces
- Offspring paths resolve to `libs/branch1/auth-service/` instead of `branch1/libs/auth-service/`

### Required Behavior

Workspace root resolution for `create` and `init` must follow these rules (in priority order):

1. **Existing workspace.** Walk up from `ref_repo.parent` looking for `.fork3/`. If found, use that directory as workspace root. This handles the second-lineage case (`fork3 ./libs/auth-service` when `.fork3/` already exists at `work/`).
2. **CWD heuristic.** If no existing `.fork3/` is found, use the **current working directory** as the workspace root. The PRD walkthrough assumes `cd /home/dev/work && fork3 ./libs/auth-service` produces the workspace at `work/`. CWD is the only consistent reference point that works for both flat (`./my-project`) and nested (`./libs/auth-service`) paths.
3. **Fallback.** If the resolved CWD is not an ancestor of `ref_repo`, fall back to `ref_repo.parent` (the original behavior). This handles edge cases like `fork3 /absolute/path/to/repo`.

### Contract Change

**`build_workspace_context_for_create`** in `_workspace.py`:

- Input: `args.reference_repo` (str), implicit `Path.cwd()`
- Output: `WorkspaceContext` with `workspace_root` resolved per rules above
- `target_repo` stored as the relative path from workspace root (e.g., `libs/auth-service`)

**`init_command`** in `_cmd_create.py`:

- Same resolution logic. Extract into a shared helper `resolve_workspace_root_for_setup(ref_repo: Path) -> Path`.

### Offspring Path Impact

With workspace root correctly at `work/`, offspring for `libs/auth-service` are at:

```
work/branch1/libs/auth-service/    # preserves full relative path
work/branch2/libs/auth-service/
```

The `classify_slots` function and the slot creation loop already use `workspace_root / f"branch{i}" / repo_name`. The fix is that `repo_name` must become the **relative path** from workspace root to the target repo (`libs/auth-service`), not just the basename (`auth-service`).

### Affected Components

| Component | Change |
|-----------|--------|
| `_workspace.py` → `build_workspace_context_for_create` | New workspace root resolution logic |
| `_workspace.py` → new `resolve_workspace_root_for_setup` | Shared helper for create + init |
| `_cmd_create.py` → `init_command` | Use shared helper instead of `ref_repo.parent` |
| `_workspace.py` → `classify_slots` | No change — already uses `repo_name` from context |
| `_workspace.py` → `resolve_lineage` | No change — reads `target_repo` from TOML |

---

## G2 — Lineage ID Derivation for Nested Paths

### Problem

The PRD specifies (lineage-model.md §Default Lineage ID Derivation):

| Target repo relative path | Default lineage ID |
|---|---|
| `libs/auth-service` | `libs-auth-service` |

The current code at `_workspace.py:188` and `_cmd_create.py:216`:

```python
repo_name = ref_repo.name          # "auth-service"
lineage_id = derive_lineage_id(repo_name)  # "auth-service"
```

`ref_repo.name` gives only the final component. The lineage ID should be derived from the **relative path** from workspace root, not the basename.

### Required Behavior

After workspace root is correctly resolved (G1), compute:

```python
relative_path = str(ref_repo.relative_to(workspace_root))  # "libs/auth-service"
lineage_id = derive_lineage_id(relative_path)               # "libs-auth-service"
```

`derive_lineage_id` itself is correct — it replaces `/` with `-`. The bug is in what gets passed to it.

### Affected Components

| Component | Change |
|-----------|--------|
| `_workspace.py` → `build_workspace_context_for_create` | Pass `relative_path` to `derive_lineage_id`, not `repo_name` |
| `_cmd_create.py` → `init_command` | Same fix |
| `_workspace.py` → `WorkspaceContext.repo_name` | Clarify semantics: this is the relative path from workspace root (e.g., `libs/auth-service`), not the basename |

### Data Model Clarification

The `repo_name` field on `WorkspaceContext` is used in two roles:

1. **Directory construction:** `workspace_root / f"branch{i}" / repo_name` — must be the relative path to produce `branch1/libs/auth-service/`.
2. **Display:** "repo: auth-service" — human-readable name.

Split into two fields:

| Field | Value for `libs/auth-service` | Usage |
|-------|-------------------------------|-------|
| `repo_rel_path` | `libs/auth-service` | Path construction, lineage ID derivation, TOML `target_repo` |
| `repo_display_name` | `auth-service` | Human-readable output |

Or — keep a single `repo_name` field that holds the relative path, and derive the display name with `Path(repo_name).name` where needed. The simpler option; avoids a model change.

### Recommended Approach

Keep `repo_name` as the relative path. Update the two sites that populate it:

- `build_workspace_context_for_create`: `repo_name = str(ref_repo.relative_to(workspace_root))`
- `init_command`: same

Update display sites to use `Path(ctx.repo_name).name` for short labels.

---

## G3 — `classify_slots` Remote Name Hardcoding

### Problem

`classify_slots` at `_workspace.py:230`:

```python
actual_url = git_remote_url(slot_path)  # defaults to "origin"
```

The lineage may use a remote named something other than `"origin"` (e.g., `"upstream"`). The `remote_url` parameter is correctly passed into `classify_slots`, but the comparison checks against `origin`'s URL specifically.

### Required Behavior

Pass `remote_name` into `classify_slots` and use it:

```python
def classify_slots(
    workspace_root: Path,
    repo_name: str,
    n: int,
    remote_url: str,
    remote_name: str = "origin",    # new parameter
) -> list[tuple[int, str, Path, str]]:
```

At the comparison site:

```python
actual_url = git_remote_url(slot_path, remote_name)
```

### Affected Components

| Component | Change |
|-----------|--------|
| `_workspace.py` → `classify_slots` | Add `remote_name` parameter, pass to `git_remote_url` |
| `_cmd_create.py` → `create_command` (call site) | Pass `ctx.remote_name` |
| `_cmd_create.py` → `_scan_offspring` | Same fix — also hardcodes `"origin"` at line 189 |

---

## G4 — `_looks_like_path` Heuristic

### Problem

`_cli.py:12-13`:

```python
def _looks_like_path(arg: str) -> bool:
    return "/" in arg or arg.startswith(".")
```

`fork3 my-project -n 3` treats `my-project` as an unknown subcommand because `my-project` has no `/` and doesn't start with `.`. The user gets a confusing error.

### Required Behavior

Expand the heuristic to also match bare names that are **not** known subcommands and **could be** a directory:

```python
def _looks_like_path(arg: str) -> bool:
    if "/" in arg or arg.startswith("."):
        return True
    return Path(arg).exists() and Path(arg).is_dir()
```

The filesystem check is intentional here: it distinguishes `fork3 my-project` (directory exists → create shorthand) from `fork3 badcommand` (directory doesn't exist → unknown command error). This matches the PRD's expectation that "the first positional argument looks like a path."

### Edge Case

If a directory happens to be named the same as a subcommand (e.g., a directory called `push`), the subcommand takes precedence because `_looks_like_path` is only called when the first arg is **not** a known subcommand. No conflict.

### Affected Components

| Component | Change |
|-----------|--------|
| `_cli.py` → `_looks_like_path` | Add `Path.exists()` filesystem probe |

---

## G5 — Subprocess Timeouts

### Problem

Every `subprocess.run()` in `_git.py` has no `timeout` parameter. A slow or hung remote blocks forever. Combined with `ThreadPoolExecutor`, one hung connection silently freezes a worker thread.

### Required Behavior

Add a default timeout constant and apply it to all `subprocess.run()` calls:

```python
GIT_TIMEOUT_SECS = 120       # 2 minutes for network operations
GIT_LOCAL_TIMEOUT_SECS = 30  # 30 seconds for local-only operations
```

Classification:

| Operation | Timeout | Rationale |
|-----------|---------|-----------|
| `git_clone`, `git_push`, `git_push_force_with_lease`, `git_fetch_all`, `git_ls_remote` | `GIT_TIMEOUT_SECS` (120s) | Network I/O |
| `git_checkout_new_branch`, `git_current_branch`, `git_is_dirty`, `git_dirty_count`, `git_ahead_behind`, `git_remote_url`, `git_remote_names`, `git_set_remote_url`, `git_reset_hard`, `git_tracking_branch` | `GIT_LOCAL_TIMEOUT_SECS` (30s) | Local-only |

On `subprocess.TimeoutExpired`:

- Network operations: catch, wrap as a user-friendly error (`"git push timed out after 120s for <label>"`).
- Local operations: let the exception propagate — a 30-second local operation indicates a real problem.

### Affected Components

| Component | Change |
|-----------|--------|
| `_output.py` | Add `GIT_TIMEOUT_SECS` and `GIT_LOCAL_TIMEOUT_SECS` constants |
| `_git.py` → all functions | Add `timeout=` parameter to every `subprocess.run()` call |

---

## G6 — Graceful Signal Handling

### Problem

`Ctrl+C` during a parallel push/sync produces ugly `KeyboardInterrupt` tracebacks from `ThreadPoolExecutor` worker threads and futures.

### Required Behavior

Wrap the top-level `main()` function:

```python
def main() -> None:
    try:
        args = parse_args()
        dispatch = { ... }
        handler = dispatch.get(args.command)
        if handler:
            handler(args)
        else:
            error_exit(f"unknown command: {args.command}", code=2)
    except KeyboardInterrupt:
        print()  # clear the ^C line
        sys.exit(130)  # standard SIGINT exit code
```

Exit code 130 is the Unix convention for SIGINT (128 + signal number 2).

### Affected Components

| Component | Change |
|-----------|--------|
| `_cli.py` → `main` | Wrap in `try/except KeyboardInterrupt` |

---

## G7 — Tech Design Documentation Drift

### Problem

All 4 existing tech design documents reference a single-file `generic/git/fork3.py` architecture. The actual implementation is a package at `generic/git/fork3/` with 8 modules. Specific drift points:

| Document | Drift |
|----------|-------|
| `execution-plan.md` | Phase 1 deliverables list `generic/git/fork3.py` as a single file |
| `task-breakdown.md` | Task 1.1 "Create `generic/git/fork3.py`", all subsequent tasks reference functions in a single file |
| `installation-integration.md` | Wrapper generation expects `fork3.py`, not `fork3/__main__.py`; wrapper command line incorrect |
| `testing-strategy.md` | Import strategy uses `sys.path.insert` + `from fork3 import ...` which won't work with package layout |

### Required Changes

Add a note at the top of each existing document:

```markdown
> **Architecture Update (2026-04-19):** The implementation uses a multi-module
> package at `generic/git/fork3/` instead of the single file originally planned.
> See [gap-analysis-fixes.md](./gap-analysis-fixes.md) §G7 for the module map
> and updated import strategy.
```

### Module Map (Current Implementation)

| Module | Responsibility |
|--------|---------------|
| `__init__.py` | Package marker (empty) |
| `__main__.py` | `python -m fork3` entry point |
| `_cli.py` | Argument parsing, `main()` dispatch |
| `_output.py` | Constants, ANSI helpers, `error_exit` |
| `_models.py` | `CopyInfo`, `WorkspaceContext` dataclasses |
| `_git.py` | Git subprocess wrappers |
| `_metadata.py` | TOML read/write, lineage enumeration |
| `_workspace.py` | Discovery, context resolution, slot classification, UV replication |
| `_cmd_create.py` | `create_command`, `init_command` |
| `_cmd_ops.py` | `push_command`, `sync_command`, `status_command` |

### Installation Integration Update

The `install.sh` wrapper script needs to target the package entry point. Two options:

| Option | Wrapper Command | Pros | Cons |
|--------|----------------|------|------|
| A. Use `__main__.py` | `exec python -m generic.git.fork3 "$@"` | Standard Python package invocation | Requires PYTHONPATH or install-time path manipulation |
| B. Use `__main__.py` directly | `exec python generic/git/fork3/__main__.py "$@"` | Simple, matches existing wrapper pattern | Direct file execution |

Option B matches the existing `install.sh` pattern for other scripts. The `__main__.py` file imports `from ._cli import main` and calls it, so direct execution works.

### Testing Import Update

Replace the single-file import with package-relative imports:

```python
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "generic" / "git"))
from fork3._git import git_current_branch, git_clone
from fork3._metadata import read_lineage_toml, write_lineage_toml
from fork3._workspace import find_workspace_root, classify_slots
```

---

## G8 — `tomli_w` vs Manual Writer

### Problem

The installation-integration tech design recommends a manual TOML writer (~20 lines) to avoid a third-party dependency. The implementation uses `tomli_w`.

### Assessment

This is a **low-severity** gap. `tomli_w` is a well-maintained, minimal package (single file, no transitive deps). The TOML data is simple, but `tomli_w` handles edge cases (quoting, escaping) that a manual writer would need to replicate. The current choice is defensible.

### Required Action

Update `installation-integration.md` §Recommendation to reflect the actual decision:

```markdown
**Decision:** Use `tomli_w` for TOML serialization. While a manual writer would
avoid the dependency, `tomli_w` is a single-file package with no transitive
dependencies and handles edge cases in TOML serialization correctly. The
`pyproject.toml` includes `tomli_w` in the dependencies list.
```

No code change needed.

---

## Execution Plan

### Phase A — Critical Path Fixes (G1, G2, G3)

These three gaps are interrelated: G1 (workspace root) must be fixed first, then G2 (lineage ID derivation) follows naturally, and G3 (remote name) is a simple parameter threading fix.

**Dependency graph:**

```
G1 (workspace root)
  └──▸ G2 (lineage ID derivation)

G3 (remote name) — independent
```

**Sequence:**

1. Implement `resolve_workspace_root_for_setup` in `_workspace.py`
2. Update `build_workspace_context_for_create` to use it and set `repo_name` to relative path
3. Update `init_command` to use the shared helper
4. Update `classify_slots` to accept and use `remote_name`
5. Update `_scan_offspring` to accept and use `remote_name`
6. Update all call sites

**Verification:**

- `fork3 create ./libs/auth-service -n 2` from `work/` produces `.fork3/` at `work/`, offspring at `work/branch1/libs/auth-service/`
- `fork3 create ./my-project -n 3` in the same workspace reuses `work/.fork3/`
- Lineage IDs: `libs-auth-service` and `my-project` respectively
- Re-run of either create command is a no-op

### Phase B — Usability & Robustness (G4, G5, G6)

Independent of each other and of Phase A.

**Sequence:**

1. Update `_looks_like_path` in `_cli.py` (G4)
2. Add timeout constants to `_output.py` and apply to all `_git.py` functions (G5)
3. Add `KeyboardInterrupt` handler in `_cli.py` → `main()` (G6)

**Verification:**

- `fork3 my-project -n 3` (where `my-project/` exists as a directory) routes to create
- `fork3 badcommand` still fails with unknown command error
- A simulated hung git operation times out after 120s (can test with a non-routable IP)
- `Ctrl+C` during push produces a clean exit with code 130

### Phase C — Documentation Alignment (G7, G8)

No code changes. Update existing tech design documents.

**Sequence:**

1. Add architecture-update note to all 4 existing tech design docs
2. Update the testing-strategy import examples
3. Update the installation-integration recommendation section
4. Update the execution-plan Phase 1 deliverables table

**Verification:**

- Read each updated doc and verify no stale single-file references remain without the update note

---

## Risks & Mitigations

| Risk | Severity | Mitigation |
|------|----------|------------|
| G1 fix changes workspace root for existing users who ran `create` with the old code | High | Since fork3 is pre-release (v0.1.0), no backward-compatibility concern. Document in changelog. |
| `Path.exists()` check in G4 adds a filesystem syscall to argument parsing | Low | Single `stat()` call; negligible cost. Only invoked when the arg is not a known subcommand. |
| Timeout values may be too aggressive for slow networks | Medium | 120s is generous for most git operations. Can be made configurable later via `.fork3/config`. |
| CWD-based workspace root (G1 rule 2) may surprise users who run `fork3 create /absolute/path` from an unrelated directory | Medium | Fallback rule 3 handles absolute paths. Document the CWD heuristic in `--help` text. |

---

## Open Questions

1. **Should `repo_name` on `WorkspaceContext` be renamed to `repo_rel_path`?** This would make the semantics explicit but touches many call sites. The alternative (keep `repo_name`, document that it holds a relative path) is lower-churn.

2. **Should the timeout constants be user-configurable via `.fork3/config`?** Deferred to a future version. The hardcoded defaults are sufficient for v0.1.0.

3. **Should `_looks_like_path` also check for `.git` inside the candidate directory?** This would add precision but also adds another syscall and couples CLI parsing to filesystem state more deeply. The simple `exists() + is_dir()` check is sufficient.
