---
id: "tech-260419-fork3-standalone"
title: "fork3 — Standalone Package Isolation"
status: draft
created: 2026-04-19
updated: 2026-04-19
source: "./docs/prd/prd-260418-fork3/index.md"
author: ""
tags:
  - packaging
  - isolation
  - python
parent: ""
superseded-by: ""
---

# fork3 — Standalone Package Isolation

## Context & Goals

### Engineering Motivation

fork3 is a Python CLI tool for managing parallel branch workspaces around git repositories. It originated inside a private monorepo where it shared a venv and dependency list with dozens of unrelated scripts. That coupling prevented independent versioning, distribution, and installation.

This repo extracts fork3 into a standalone, publicly distributable open-source package. The goals:

1. **Independent distribution** — fork3 is published on PyPI so anyone can install it with `pip install fork3` or `pipx install fork3`.
2. **Minimal dependency footprint** — fork3 declares only its own runtime dependency (`tomli_w`), not the full monorepo dependency tree.
3. **Standard packaging** — uses PEP 621 metadata, `src/` layout, and standard entry points. Works with pip, pipx, uv, and any PEP 517-compliant installer.
4. **Independent versioning** — fork3 follows its own release cadence, unaffected by unrelated projects.

### Prior State (monorepo)

```
script_py/
├── pyproject.toml              # shared deps: Pillow, pypdf, PyMuPDF, tqdm, requests, tomli_w
├── install.sh                  # wrapper generator → ~/.local/bin/fork3
├── generic/git/fork3/
│   ├── __init__.py
│   ├── __main__.py             # sys.path hack for direct invocation
│   ├── _cli.py
│   ├── _cmd_create.py
│   ├── _cmd_ops.py
│   ├── _git.py
│   ├── _metadata.py
│   ├── _models.py
│   ├── _output.py
│   ├── _workspace.py
│   └── tests/
│       ├── conftest.py
│       ├── test_create.py
│       ├── test_metadata.py
│       └── test_workspace.py
```

### Success Criteria

1. `fork3` is installable via `pip install fork3` from PyPI.
2. `fork3` is installable via `pipx install fork3` for CLI isolation.
3. `fork3` CLI entry point is exposed via standard `[project.scripts]`.
4. `fork3` declares only its own runtime dependency (`tomli_w`).
5. All existing tests pass in the standalone repo.
6. Package metadata (description, license, URLs) meets PyPI quality standards.

### Constraints

- Python ≥ 3.11.
- Must use `uv` as the development/build toolchain.
- Package name `fork3` must be available on PyPI (or an acceptable alternative chosen).

---

## Non-Goals

| Non-Goal | Rationale |
|----------|-----------|
| Rewriting fork3 internals | This is a packaging/isolation effort, not a feature change |
| Changing fork3 CLI behavior | Zero user-facing behavior changes |
| Managing downstream consumers | Repos that depend on fork3 handle their own integration |
| CI/CD pipeline setup | Separate concern; can be added later |

---

## System Context

```
┌─────────────────────────────────────────────┐
│              Public Distribution             │
│                                             │
│  ┌──────────┐      ┌───────────────────┐   │
│  │  PyPI    │◀─────│  fork3 (package)  │   │
│  └──────────┘      │  this repo        │   │
│       │            └───────────────────┘   │
│       ▼                                     │
│  ┌──────────────────────────┐              │
│  │  Any developer machine   │              │
│  │                          │              │
│  │  pip install fork3       │              │
│  │  pipx install fork3      │              │
│  │  uv pip install fork3    │              │
│  │                          │              │
│  │  ┌────────────────┐      │              │
│  │  │  git repos     │◀── fork3 operates  │
│  │  │  (.fork3/)     │    on these        │
│  │  └────────────────┘      │              │
│  └──────────────────────────┘              │
└─────────────────────────────────────────────┘
```

**External actors:**

| Actor | Interaction |
|-------|-------------|
| Any developer | Installs from PyPI; invokes `fork3` CLI from any directory |
| git repositories | Target of fork3 operations (clone, push, fetch, status) |
| PyPI | Distribution registry |
| `uv` / `pip` / `pipx` | Install toolchains |

---

## Component Architecture

### Standalone Package (this repo)

```
fork3/                              # repo root
├── pyproject.toml                  # PEP 621 metadata, entry point, deps
├── src/
│   └── fork3/                      # package root (src layout)
│       ├── __init__.py
│       ├── __main__.py
│       ├── _cli.py
│       ├── _cmd_create.py
│       ├── _cmd_ops.py
│       ├── _git.py
│       ├── _metadata.py
│       ├── _models.py
│       ├── _output.py
│       └── _workspace.py
└── tests/
    ├── conftest.py
    ├── test_create.py
    ├── test_metadata.py
    └── test_workspace.py
```

**Design decision: `src/` layout** — The `src/` layout prevents accidental import of the local package directory during testing and is the recommended layout for installable packages. See Trade-Off Analysis §1.

---

## Data Flow

### Installation Flow (from PyPI)

```
Developer
  │
  ▼
pip install fork3    (or pipx install fork3, uv pip install fork3)
  │
  ▼
PyPI → download wheel
  │
  ├── resolve deps: tomli_w
  └── install entry point: fork3 → fork3._cli:main
  │
  ▼
~/.local/bin/fork3    (or venv bin/fork3)
```

### Installation Flow (from source)

```
Developer
  │
  ▼
pip install .    (or uv pip install -e .)
  │
  ▼
pyproject.toml [build-system]
  │
  ├── resolve deps: tomli_w
  ├── build wheel from src/fork3/
  └── install entry point: fork3 → fork3._cli:main
  │
  ▼
~/.local/bin/fork3    (or venv bin/fork3)
```

### Runtime Flow (unchanged)

```
fork3 <args>
  │
  ▼
fork3._cli:main()
  │
  ├── parse_args()
  └── dispatch → create | init | push | sync | status
        │
        ├── _workspace.py  (workspace discovery)
        ├── _metadata.py   (TOML lineage I/O)
        ├── _git.py        (subprocess git ops)
        └── _models.py     (data structures)
```

---

## Data Model

No change. The `.fork3/` workspace metadata structure, lineage TOML files, and in-memory dataclasses (`CopyInfo`, `WorkspaceContext`) remain identical.

---

## API & Contract Surface

### Package Entry Point

```toml
[project.scripts]
fork3 = "fork3._cli:main"
```

This is the only public contract. All internal modules (`_cli`, `_git`, etc.) are private.

### PyPI Package Metadata

```toml
[project]
name = "fork3"
version = "..."
description = "Manage parallel branch workspaces around git repositories"
requires-python = ">=3.11"
license = "CC-BY-NC-ND-4.0"
dependencies = ["tomli_w"]

[project.urls]
Homepage = "https://github.com/chengyanru/fork3"
Repository = "https://github.com/chengyanru/fork3"
Issues = "https://github.com/chengyanru/fork3/issues"
```

---

## NFR & SLO Targets

| NFR | Target | Rationale |
|-----|--------|-----------|
| Install time | < 10s from PyPI | Single dependency, small pure-Python package |
| Zero runtime regression | All existing tests pass | Migration must not alter behavior |
| Dependency footprint | 1 runtime dep (`tomli_w`) | Isolation goal |
| Python version | ≥ 3.11 | Matches existing requirement |
| Package size | < 50 KB wheel | Pure Python, no assets |

---

## Cross-Cutting Concerns

### Error Handling

No change. fork3's error model (exit codes, colored stderr output) is self-contained and unaffected by repackaging.

### Logging / Observability

No change. fork3 uses direct print/stderr output. No structured logging to reconfigure.

### Testing

- Tests move from `generic/git/fork3/tests/` to top-level `tests/`.
- Test runner: `pytest` (already used).
- Imports change from relative package paths (if any test imports differ).
- `conftest.py` fixtures are self-contained (create temp git repos) — no repo-specific fixtures.

---

## Trade-Off Analysis

### 1. Package Layout: `src/` layout vs flat layout

| Option | Pros | Cons |
|--------|------|------|
| **`src/fork3/` (chosen)** | Prevents accidental local imports during testing; standard for installable packages; clear separation of source and project root | Slightly deeper directory nesting |
| `fork3/` at root (flat) | Simpler structure | Editable installs can mask import bugs; `import fork3` resolves to local dir not installed package |

**Decision:** `src/` layout. This is a proper installable package, not a script. The `src/` convention eliminates a class of packaging bugs.

### 2. Build Backend: hatchling vs setuptools

| Option | Pros | Cons |
|--------|------|------|
| **hatchling (chosen)** | Modern, fast, minimal config, default for `hatch init`, first-class `src/` layout support | Less familiar than setuptools |
| setuptools | Ubiquitous, well-known | Requires more boilerplate for `src/` layout; legacy baggage |

**Decision:** hatchling. It's the modern standard for pure-Python packages, aligns with `uv` ecosystem conventions, and requires minimal configuration.

### 3. Version Management: VERSION file vs hatch-vcs (git tags) vs manual version

| Option | Pros | Cons |
|--------|------|------|
| **VERSION file (chosen)** | Single source of truth in a plain file; works identically in dev, CI, and Docker; no git-specific tooling required; easy to read from shell/Python/build | Requires discipline to bump before release |
| hatch-vcs (git tags) | Version derived from git tags automatically; no manual bumping | Requires git tags for releases; dirty-tree versions are confusing; doesn't work in Docker builds without `.git` |
| Manual `version = "x.y.z"` in pyproject.toml | Simple, explicit | Easy to forget to bump; version can drift from git state |

**Decision:** VERSION file at project root. The version flows through three layers: file → hatchling build metadata → Python runtime (`_version.py:read_version()`). This approach is inspired by containerized Python workflows and provides the cleanest isolation.

---

## Execution Plan

### Phase 1 — Scaffold Standalone Repo

| Track | Task | Depends On |
|-------|------|------------|
| 1A | Create `pyproject.toml` with PEP 621 metadata, hatchling backend, `[project.scripts]` entry point, `tomli_w` dependency | — |
| 1B | Create `src/fork3/` directory structure | — |
| 1C | Create `.gitignore` (Python standard) | — |

**Gate:** `pyproject.toml` is valid and parseable.

### Phase 2 — Migrate Source Code

| Track | Task | Depends On |
|-------|------|------------|
| 2A | Copy all fork3 modules (`__init__.py`, `__main__.py`, `_cli.py`, `_cmd_create.py`, `_cmd_ops.py`, `_git.py`, `_metadata.py`, `_models.py`, `_output.py`, `_workspace.py`) from `script_py/generic/git/fork3/` to `src/fork3/` | 1B |
| 2B | Clean up `__main__.py` — remove the `sys.path` hack that was needed for the monorepo's direct-invocation pattern; proper packaging makes it unnecessary | 2A |
| 2C | Verify all internal relative imports resolve correctly within the new `src/fork3/` location | 2A |

**Gate:** `uv pip install -e .` succeeds; `fork3 --version` prints version.

### Phase 3 — Migrate Tests

| Track | Task | Depends On |
|-------|------|------------|
| 3A | Copy test files (`conftest.py`, `test_create.py`, `test_metadata.py`, `test_workspace.py`) from `script_py/generic/git/fork3/tests/` to `tests/` | 2A |
| 3B | Add `pytest` as a dev dependency in `pyproject.toml` (`[dependency-groups]`) | 1A |
| 3C | Verify all tests pass: `uv run pytest tests/` | 3A, 3B |

**Gate:** All tests pass with zero failures.

### Phase 4 — PyPI Publishing Readiness

| Track | Task | Depends On |
|-------|------|------------|
| 4A | Add complete PyPI metadata to `pyproject.toml`: description, license (CC BY-NC-ND 4.0), classifiers, URLs, readme | 1A |
| 4B | Configure VERSION file-based versioning (single source of truth) | 1A |
| 4C | Verify `uv build` produces a valid wheel and sdist | 4B |
| 4D | Test publish to TestPyPI; verify `pip install --index-url https://test.pypi.org/simple/ fork3` works | 4C |
| 4E | Publish to PyPI; verify `pip install fork3` works | 4D |

**Gate:** `pip install fork3` from PyPI produces a working `fork3` CLI.

### Phase 5 — Migrate Documentation

| Track | Task | Depends On |
|-------|------|------------|
| 5A | Copy PRD docs from `script_py/docs/prd/prd-260418-fork3/` to `fork3/docs/prd/` | — |
| 5B | Copy tech design docs from `script_py/docs/tech/tech-260418-fork3/` to `fork3/docs/tech/` | — |
| 5C | Update internal doc cross-references (relative paths) | 5A, 5B |

**Gate:** All doc links resolve correctly.

### Dependency Graph

```
Phase 1 (scaffold) ─────┐
                         ▼
Phase 2 (source) ────────┤
                         ▼
Phase 3 (tests) ─────────┤
                         ▼
Phase 4 (PyPI) ──────────┘

Phase 5 (docs) ──── parallel, no dependency on 2-4
```

---

## Risks & Mitigations

| Risk | Severity | Mitigation |
|------|----------|------------|
| import path changes break tests | Medium | Phase 3 explicitly verifies all tests. Relative imports within `fork3/` are unchanged. |
| Package name `fork3` taken on PyPI | Medium | Check availability early (Phase 4A). Fallback: `git-fork3` or `fork3-cli`. |
| `__main__.py` sys.path hack causes issues in packaged context | Low | Phase 2B explicitly removes the hack. Standard `python -m fork3` works via packaging. |
| Version tag discipline forgotten | Low | hatch-vcs fails loudly if no tag exists; CI can enforce tag-before-publish. |

---

## Open Questions

1. **PyPI name availability** — Is `fork3` available on PyPI? If not, what alternative name is acceptable (`git-fork3`, `fork3-cli`)?
2. **License choice** — CC BY-NC-ND 4.0 chosen. Non-commercial, no derivatives, attribution required.
3. **Minimum Python version** — 3.11 is chosen for current consistency. Could lower to 3.10 or 3.9 to expand user base if no 3.11-specific features are used.
4. **Doc migration scope** — Should the PRD and tech design docs be *moved* (deleted from the monorepo) or *copied* (kept in both repos)? Recommendation: move, since fork3 owns its own documentation.
