---
id: tech-260418-fork3-task-breakdown
title: "fork3 — Task Breakdown"
status: draft
created: 2026-04-18
updated: 2026-04-19
source: "./docs/prd/prd-260418-fork3/index.md"
parent: "tech-260418-fork3"
superseded-by: ""
---

# fork3 — Task Breakdown

> **Standalone Migration (2026-04-19):** This document was originally written
> for the monorepo at `script_py/generic/git/fork3/`. The standalone package
> now lives at `src/fork3/`. All `generic/git/fork3/` references below map to
> `src/fork3/` in the current repo layout.

Each task is atomic and verifiable. Tasks are ordered within each phase so that dependencies flow top-to-bottom.

---

## Phase 1 — Scaffold + Infrastructure

### 1.1 File skeleton

Create `src/fork3/` package with the following modules: `__init__.py`, `__main__.py`, `_cli.py`, `_output.py`, `_models.py`, `_git.py`, `_metadata.py`, `_workspace.py`, `_cmd_create.py`, `_cmd_ops.py`.

`__main__.py` serves as the `python -m fork3` entry point with:

**Verify:** Package runs without error: `python -m fork3`

### 1.2 Output helpers

Implement:

- `colorize(text: str, color: str = "info") -> str` — ANSI color wrapper (reuse repo pattern from `web_vid.py`)
- `info(msg: str) -> None` — prints `==> msg` in blue
- `ok(msg: str) -> None` — prints ` ✓  msg` in green
- `warn(msg: str) -> None` — prints `warn: msg` in yellow
- `error_exit(msg: str, code: int = 1) -> NoReturn` — prints `error: msg` in red to stderr, calls `sys.exit(code)`

**Verify:** Quick smoke test calling each function from `main()`.

### 1.3 Data classes

Define using `@dataclass`:

```python
@dataclass
class CopyInfo:
    index: int
    label: str           # "original", "branch1", "branch2", ...
    path: Path
    branch: str | None = None
    dirty: bool = False
    ahead: int = 0
    behind: int = 0
    detached: bool = False

@dataclass
class WorkspaceContext:
    workspace_root: Path
    lineage_id: str
    target_repo: Path
    repo_name: str
    remote_name: str
    remote_url: str
    copies: list[CopyInfo]
```

**Verify:** Instantiate both classes in a throwaway test.

### 1.4 Git operation wrappers

Each function wraps a single `subprocess.run()` call with `check=True`, `capture_output=True`, `text=True`. On `CalledProcessError`, print colored error and re-raise or return a sentinel.

| Function | Git Command | Returns |
|----------|-------------|---------|
| `git_clone(source: Path, dest: Path, bare: bool = False) -> None` | `git clone` | — |
| `git_checkout_new_branch(repo: Path, branch: str) -> None` | `git checkout -b <branch>` | — |
| `git_push(repo: Path, remote: str, branch: str, set_upstream: bool = False) -> None` | `git push [-u] <remote> <branch>` | — |
| `git_push_force_with_lease(repo: Path, remote: str, branch: str) -> None` | `git push --force-with-lease <remote> <branch>` | — |
| `git_fetch_all(repo: Path) -> None` | `git fetch --all` | — |
| `git_current_branch(repo: Path) -> str \| None` | `git symbolic-ref --short HEAD` | branch name or `None` if detached |
| `git_is_dirty(repo: Path) -> bool` | `git status --porcelain` | `True` if output is non-empty |
| `git_dirty_count(repo: Path) -> int` | `git status --porcelain` | line count |
| `git_ahead_behind(repo: Path) -> tuple[int, int]` | `git rev-list --left-right --count HEAD...@{u}` | `(ahead, behind)` |
| `git_remote_url(repo: Path, remote: str = "origin") -> str` | `git remote get-url <remote>` | URL string |
| `git_remote_names(repo: Path) -> list[str]` | `git remote` | list of remote names |
| `git_ls_remote(url: str) -> bool` | `git ls-remote --exit-code <url>` | `True` if reachable |
| `git_reset_hard(repo: Path, ref: str) -> None` | `git reset --hard <ref>` | — |
| `git_tracking_branch(repo: Path) -> str \| None` | `git rev-parse --abbrev-ref @{u}` | upstream ref or `None` |

**Verify:** Call `git_current_branch()` on a known git repo in `/tmp`.

### 1.5 Lineage metadata I/O

TOML format for `.fork3/lineages/<id>.toml`:

```toml
[lineage]
id = "my-project"
repo_name = "my-project"
target_repo = "my-project"
remote_name = "origin"
remote_url = "git@github.com:user/my-project.git"
copy_count = 3
created_at = "2025-07-01T12:00:00"
```

Functions:

| Function | Signature | Behavior |
|----------|-----------|----------|
| `read_lineage_toml` | `(path: Path) -> dict` | Read and parse TOML; raise on missing/corrupt |
| `write_lineage_toml` | `(path: Path, data: dict) -> None` | Serialize dict to TOML and write atomically |
| `list_lineages` | `(workspace_root: Path) -> list[str]` | Return sorted lineage IDs from `lineages/*.toml` filenames |
| `lineage_exists` | `(workspace_root: Path, lineage_id: str) -> bool` | Check if `lineages/<id>.toml` exists |
| `derive_lineage_id` | `(relative_path: str) -> str` | Replace `/` with `-` per PRD |
| `ensure_fork3_dir` | `(workspace_root: Path) -> Path` | Create `.fork3/lineages/` if missing, return `.fork3/` path |

**Verify:** Round-trip write → read a test TOML in `/tmp`.

### 1.6 Workspace discovery

| Function | Behavior |
|----------|----------|
| `find_workspace_root(start: Path) -> Path \| None` | Walk up to `MAX_PARENT_WALK` parents from `start`, return parent of `.fork3/` or `None` |
| `auto_detect_lineage(workspace_root: Path, cwd: Path) -> str` | Compute CWD relative to workspace root, match against lineage target repos and offspring paths. Fail if zero or multiple matches. |
| `resolve_lineage(args: Namespace, cwd: Path) -> WorkspaceContext` | If `-l` provided, look up by ID. If omitted, auto-detect. Populate full `WorkspaceContext`. |
| `build_workspace_context_for_create(args: Namespace) -> WorkspaceContext` | Special path for create: derive workspace root from reference repo parent, no `.fork3/` required yet. |

**Verify:** Create a mock `.fork3/` in `/tmp`, call `find_workspace_root()` from a nested child.

### 1.7 Slot classification

```python
def classify_slots(
    workspace_root: Path,
    repo_name: str,
    n: int,
    remote_url: str,
) -> list[tuple[int, str, Path, str]]:
    """Classify each slot as 'existing', 'invalid', or 'missing'.

    Return list of (index, label, path, status) tuples.
    """
```

Classification rules (from PRD idempotency.md):

| Condition | Status |
|-----------|--------|
| `branchI/<repo>/.git` exists and primary remote URL matches | `"existing"` |
| Path exists but is not a valid clone | `"invalid"` |
| Path does not exist | `"missing"` |

Slot 0 (original / target repo) is always classified separately — it must already exist.

**Verify:** Set up a mock workspace in `/tmp` with a mix of valid, invalid, and missing slots.

### 1.8 argparse setup

Build the argument parser with subcommands:

```
fork3 [<reference-repo>] [-n N] [--uv] [-l <lineage-id>]     # root = create shorthand
fork3 create <reference-repo> [-n N] [--uv] [-l <lineage-id>]
fork3 init <reference-repo> [-l <lineage-id>]
fork3 push [-l <lineage-id>] [--dry-run]
fork3 sync <copy> [-l <lineage-id>] [--dry-run] [--no-push] [--force]
fork3 status [-l <lineage-id>]
fork3 --help
fork3 --version
```

Implementation approach for root-level create shorthand:
- Use `argparse` subparsers with `dest="command"`
- Override `parse_args()` to detect when `sys.argv[1]` is not a known subcommand and the first positional argument looks like a path → inject `"create"` as argv[1]

Every argument has:
- `help=` text
- Short + long forms for optional flags
- `metavar=` where it improves readability
- `type=` for validation (`int`, `Path`)
- `default=` with value documented in help text
- Epilog with usage examples per subcommand

**Verify:** `fork3 --help`, `fork3 create --help`, `fork3 sync --help` all produce correct output.

### 1.9 Main dispatch stub

```python
def main() -> None:
    args = parse_args()
    dispatch = {
        "create": create_command,
        "init": init_command,
        "push": push_command,
        "sync": sync_command,
        "status": status_command,
    }
    handler = dispatch.get(args.command)
    if handler:
        handler(args)
    else:
        error_exit(f"unknown command: {args.command}", code=2)
```

Each command function is a stub that prints `"not yet implemented: <command>"` and exits 0.

**Verify:** `fork3 create ./foo` prints the stub message. `fork3 push` prints the stub message.

### 1.10 Test scaffold + infrastructure unit tests

Set up the pytest test directory and write unit tests for all Phase 1
infrastructure functions.

| Sub-task | Detail |
|----------|--------|
| Install pytest | `uv pip install --python .venv/bin/python pytest` |
| Create `tests/fork3/conftest.py` | Shared fixtures: `tmp_workspace`, `bare_remote`, `sample_repo` (see testing-strategy.md) |
| Create `tests/fork3/test_git.py` | Tests for every `git_*()` wrapper against real `git init` sandboxes in `/tmp` |
| Create `tests/fork3/test_metadata.py` | Round-trip write → read. `list_lineages`. `lineage_exists`. Corrupt TOML error. |
| Create `tests/fork3/test_discovery.py` | `find_workspace_root` at 1, 2, 5 hops (pass) and 6 hops (fail). `derive_lineage_id` table. Auto-detect from target repo, offspring, workspace root (fail). |
| Create `tests/fork3/test_slots.py` | `classify_slots` with all-missing, mixed, and invalid states. Numeric sort of `branchN/` dirs. |

**Verify:** `pytest tests/fork3/ -v` runs all unit tests and they pass. Each infrastructure function has at least one test.

---

## Phase 2 — Create / Expand

### 2.1 Reference repo resolution

Resolve `<reference-repo>` argument to an absolute path. Validate:

- Path exists
- Path is a directory
- Path contains `.git/` (is a git repo)
- Has at least one remote

Derive workspace root as `reference_repo.parent` (or the appropriate ancestor for nested paths like `libs/auth-service`).

**Verify:** Pass a non-git directory → get a clear error. Pass a valid repo → get the resolved path.

### 2.2 Lineage ID derivation + collision check

- If `-l` is provided, use it directly
- If omitted, compute relative path of reference repo from workspace root, replace `/` with `-`
- Check `lineage_exists()`. If collision, `error_exit()`

**Verify:** `fork3 create ./my-project` derives `"my-project"`. `fork3 create ./libs/auth` derives `"libs-auth"`. Collision on second run with different repo → error.

### 2.3 Remote pre-flight

- Read all remote names and URLs from the reference repo
- For each remote, call `git_ls_remote(url)` to verify reachability
- If any remote is unreachable, fail before mutation

**Verify:** Use a non-existent remote URL → get a failure before any directory is created.

### 2.4 Slot classification + creation plan

- Call `classify_slots()` for slots 1 through `n-1`
- If any slot is `"invalid"`, `error_exit()` immediately
- If all slots are `"existing"`, print no-op summary and return (no I/O)
- Otherwise, build a creation plan: list of `(index, label, path)` for `"missing"` slots

**Verify:** Pre-existing workspace with 2 slots, request 4 → plan shows 2 new slots.

### 2.5 Slot creation loop

For each missing slot:

1. Print `[M/N] creating branchI/<repo>`
2. Create parent directory `branchI/` if needed
3. `git_clone(target_repo, slot_path)`
4. `git_checkout_new_branch(slot_path, f"feat{i}")`
5. `git_push(slot_path, remote_name, f"feat{i}", set_upstream=True)`
6. Print `✓ branchI/<repo> -> branch: featI (pushed)`

**Verify:** `fork3 create ./repo -n 3` creates `branch1/repo/` and `branch2/repo/` with correct branches.

### 2.6 Post-create fetch

If any new slots were created:

- Parallel `git_fetch_all()` for every copy (including original and pre-existing)
- Print `✓ <label> fetched` per copy

If no new slots were created (no-op case): skip this step entirely.

**Verify:** After creation, `git branch -r` in the original repo shows the new `feat1`, `feat2` branches.

### 2.7 `.fork3/` bootstrap + lineage registration

- Call `ensure_fork3_dir(workspace_root)` — creates `.fork3/lineages/` if missing
- Build lineage metadata dict: `id`, `repo_name`, `target_repo`, `remote_name`, `remote_url`, `copy_count`, `created_at`
- Call `write_lineage_toml()` to persist
- On expansion (lineage already registered): update `copy_count` in the existing TOML

**Verify:** Inspect `.fork3/lineages/my-project.toml` after creation. Inspect after expansion — `copy_count` updated.

### 2.8 `--uv` environment replication

Implement `replicate_uv_env(source: Path, dest: Path) -> bool`:

1. Check `source / ".venv"` exists. If not, `error_exit()` when `--uv` was requested.
2. `shutil.copytree(source / ".venv", dest / ".venv")`
3. If `source / ".envrc"` exists, copy it to `dest / ".envrc"` (direnv integration)
4. Return `True` on success

Call this for each newly created slot when `--uv` is set. Print `✓ uv env replicated` or skip message.

**Verify:** Create with `--uv` → `.venv/` exists in new copy. Create without `--uv` → no `.venv/`.

### 2.9 Create output formatting

Match PRD output examples exactly:

- Header: `==> lineage: <id>`, `==> repo: <name>`, `==> remote: <name> -> <url>`, `==> copies: N total (M existing, K to create)`
- Body: skip messages + creation progress
- Fetch phase: `==> syncing all copies …` + per-copy `✓ <label> fetched`
- Footer: `==> done — N copies ready (K newly created)`
- No-op: `==> all copies already exist — nothing to do`

**Verify:** Visual comparison of actual output against PRD examples.

### 2.10 Create command integration tests

Write `tests/fork3/test_cmd_create.py` covering:

| Test Case | Assertion |
|-----------|-----------|
| Green-field create (`-n 3`) | 2 offspring dirs exist, correct branches, `.fork3/lineages/<id>.toml` written |
| Re-run (no-op) | No new dirs, no fetch, no push (check mtime or spy on git calls) |
| Expansion (`-n 2` → `-n 4`) | Only 2 new slots created, originals untouched |
| Subset (`-n 4` → `-n 2`) | No-op — existing count satisfies request |
| Multi-lineage | Second create reuses existing `.fork3/`, both TOML files exist |
| Lineage ID collision | `sys.exit(1)` or equivalent error |
| Invalid repo path | Error before any mutation |
| Remote unreachable | Error before any directory is created |

**Verify:** `pytest tests/fork3/test_cmd_create.py -v` — all pass.

---

## Phase 3 — Init + Status

### 3.1 Init: directory scanning

Scan workspace root for `branchN/<repo_name>/` directories:

1. List all `branch*` directories at workspace root
2. Filter to those matching `branch<N>` where N is a positive integer
3. Sort numerically
4. For each, check `branchN/<repo_name>/.git` exists
5. Validate remote URL matches the reference repo

Return list of discovered copies.

**Verify:** Pre-existing layout with `branch1/repo/`, `branch2/repo/`, `branch3/not-repo/` → discovers 2 valid copies, warns about 1.

### 3.2 Init: lineage registration

- Resolve reference repo, derive lineage ID, check collision
- Scan directories (task 3.1)
- Write `.fork3/lineages/<id>.toml` with discovered copy count
- Print adoption summary matching PRD output

**Verify:** `fork3 init ./repo` creates `.fork3/lineages/repo.toml`. Re-running fails with collision error.

### 3.3 Init: edge cases

| Case | Expected Behavior |
|------|-------------------|
| No `branchN/` directories found | Succeed — register lineage with only copy 0 |
| `branchN/<repo>` exists but is not a git repo | Warn and skip that slot |
| `branchN/<repo>` exists but remote URL doesn't match | Warn and skip that slot |
| Lineage ID already registered | Fail with collision error |

**Verify:** Each edge case produces correct behavior.

### 3.4 Status: gather per-copy state

For each copy in the resolved lineage:

1. `git_current_branch(copy.path)` → branch or detached
2. `git_is_dirty(copy.path)` → dirty bool
3. `git_dirty_count(copy.path)` → file count for display
4. `git_tracking_branch(copy.path)` → upstream ref
5. `git_ahead_behind(copy.path)` → (ahead, behind) tuple

Build `CopyInfo` for each copy.

**Verify:** A copy with uncommitted changes shows dirty. A copy ahead of upstream shows correct ahead count.

### 3.5 Status: table output

Print a formatted table matching the PRD:

```
==> workspace: /path/to/parent
==> lineage:   my-project
==> repo:      my-project
==> remote:    origin
==> copies:    3

  Copy       Dir                              Branch   Remote          Dirty   Ahead/Behind
  ---------  -------------------------------  -------  --------------  -----   ------------
  original   /path/to/my-project              main     origin/main     clean   0/0
  branch1    /path/to/branch1/my-project      feat1    origin/feat1    clean   2/0
  branch2    /path/to/branch2/my-project      feat2    origin/feat2    1 file  0/3
```

Use simple string formatting with fixed column widths. Handle long paths with truncation if needed.

**Verify:** Output matches PRD format. Detached HEAD shows `(detached)` in Branch column. Dirty shows `N file(s)`.

### 3.6 Init + Status integration tests

Write `tests/fork3/test_cmd_init.py` and `tests/fork3/test_cmd_status.py`.

**Init tests:**

| Test Case | Assertion |
|-----------|-----------|
| Adopt pre-existing layout | `.fork3/lineages/<id>.toml` written, copy count correct |
| Init with only target repo | Succeeds with copy count = 1 |
| Lineage ID collision | Fails with error |
| Invalid offspring (not a git repo) | Warned and skipped |
| Offspring with mismatched remote | Warned and skipped |

**Status tests:**

| Test Case | Assertion |
|-----------|-----------|
| Table output contains all columns | Copy, Dir, Branch, Remote, Dirty, Ahead/Behind present |
| Dirty copy | Shows dirty state with file count |
| Ahead/behind | Shows correct divergence counts |
| Detached HEAD copy | Shows `(detached)` in Branch column |
| Auto-detect from inside a copy | Resolves correct lineage |

**Verify:** `pytest tests/fork3/test_cmd_init.py tests/fork3/test_cmd_status.py -v` — all pass.

---

## Phase 4 — Push + Sync

### 4.1 Push: eligibility classification

For each copy in the lineage:

| Condition | Action |
|-----------|--------|
| Normal branch with upstream | Push |
| Normal branch without upstream | Push with `-u` |
| Detached HEAD | Skip + warn |

Build an ordered list of `(copy, action)` tuples.

**Verify:** Mix of normal, no-upstream, detached → correct classification.

### 4.2 Push: parallel execution

1. `ThreadPoolExecutor(max_workers=min(len(copies), 8))`
2. Submit push tasks per eligible copy
3. Collect results; if any fail, print errors but continue with remaining
4. Submit fetch-all tasks per copy (all copies, not just pushed)
5. Print status summary

**Verify:** `fork3 push -l <id>` pushes all copies. Verify remote branches updated.

### 4.3 Push: `--dry-run`

Print the plan without mutation:

```
==> dry run — push plan for lineage "my-project"

  Phase 1: push
    original   git push origin main
    branch1    git push origin feat1
    branch2    git push -u origin feat2  (set upstream)
    branch3    skip — detached HEAD

  Phase 2: fetch
    all copies  git fetch --all
```

**Verify:** `fork3 push --dry-run` produces output, no git state changes.

### 4.4 Sync: winner resolution

Resolve `<copy>` argument using priority:

1. Branch name match: find the copy currently on that branch
2. Copy label match: `branch2` → slot 2
3. Numeric index match: `2` → slot 2

If ambiguous or not found, `error_exit()` with available choices.

**Verify:** `fork3 sync feat2` resolves to copy on `feat2`. `fork3 sync branch2` resolves to slot 2. `fork3 sync 2` resolves to slot 2. `fork3 sync nonexistent` fails with guidance.

### 4.5 Sync: safety validation

Before any mutation:

1. Resolve winner. If winner is detached → `error_exit()`
2. Check all non-winner copies for dirty state
3. If any dirty and `--force` not set → `error_exit()` listing dirty copies
4. If `--force`, proceed with warning

**Verify:** Dirty copy without `--force` → blocked. With `--force` → proceeds. Detached winner → always blocked.

### 4.6 Sync: reset + force-push

For each non-winner, non-detached copy:

1. `git_fetch_all(copy.path)`
2. `git_reset_hard(copy.path, f"{remote_name}/{winner_branch}")`
3. Unless `--no-push`: `git_push_force_with_lease(copy.path, remote_name, copy_branch)`

Use `ThreadPoolExecutor` for parallelism.

**Verify:** After sync, all non-winner copies are on the same commit as the winner. Remote branches reflect the reset.

### 4.7 Sync: post-sync fetch + status

1. Parallel `git_fetch_all()` for all copies
2. Print refreshed status summary (reuse `status_command` output logic)

**Verify:** Status output after sync shows all copies aligned.

### 4.8 Sync: `--dry-run` and `--no-push`

`--dry-run`:
```
==> dry run — sync plan for lineage "my-project"
==> winner: branch2 (feat2)

  branch1    git reset --hard origin/feat2; git push --force-with-lease origin feat1
  branch3    skip — detached HEAD
```

`--no-push`: execute resets but skip the force-push step.

**Verify:** `--dry-run` produces plan output, no state changes. `--no-push` resets locally, remote branches unchanged.

### 4.9 Push + Sync integration tests

Write `tests/fork3/test_cmd_push.py` and `tests/fork3/test_cmd_sync.py`.

**Push tests:**

| Test Case | Assertion |
|-----------|-----------|
| Push all copies | Remote branches updated for every copy |
| Detached copy | Skipped with warning, other copies still pushed |
| `--dry-run` | No git state changes, output lists planned operations |
| Single-copy lineage | No-op message, clean exit |
| No upstream | Push with `-u` establishes upstream |

**Sync tests:**

| Test Case | Assertion |
|-----------|-----------|
| Sync by branch name (`feat2`) | Non-winner copies reset to winner's commit |
| Sync by copy label (`branch2`) | Same as above |
| Sync by numeric index (`2`) | Same as above |
| Dirty copy blocks sync | Exits with error listing dirty copies |
| `--force` overrides dirty | Proceeds, dirty changes are lost |
| `--no-push` | Local reset happens, remote branches unchanged |
| `--dry-run` | Plan printed, no state changes |
| Detached winner | Fails with error |
| Ambiguous winner | Fails with guidance showing available choices |
| Single-copy lineage | No-op message |

**Verify:** `pytest tests/fork3/test_cmd_push.py tests/fork3/test_cmd_sync.py -v` — all pass.

---

## Phase 5 — Installation + Polish

### 5.1 install.sh INCLUDE update

Add `"generic/git/*"` to the INCLUDE array:

```bash
INCLUDE=(
    "generic/media/*"
    "generic/pdf/*"
    "generic/download/*"
    "generic/git/*"
)
```

**Verify:** `./install.sh --dry-run` lists `fork3` as a script to install.

### 5.2 pyproject.toml update

If using `tomli_w` for TOML writing, add it to dependencies:

```toml
dependencies = [
    "Pillow",
    "pypdf",
    "PyMuPDF",
    "tqdm",
    "requests",
    "tomli_w",
]
```

If using a manual TOML writer, no change needed.

**Verify:** `uv pip install -r pyproject.toml` succeeds. `import tomli_w` works in the venv.

### 5.3 Python-script skill pre-commit checklist

Verify every item:

- [ ] `#!/usr/bin/env python3` shebang on line 1
- [ ] Module-level docstring present
- [ ] `__version__` defined and meaningful
- [ ] `--version` flag works
- [ ] `--help` output is clear with examples in epilog
- [ ] Every argument has `help=` text
- [ ] All functions have type hints and docstrings
- [ ] Imports are one-per-line and properly grouped
- [ ] No raw `sys.argv` parsing — `argparse` only
- [ ] Errors print colored messages and exit with non-zero code
- [ ] Temp files use `/tmp/` and are cleaned up
- [ ] `if __name__ == "__main__"` guard calls `main()`
- [ ] Script runs successfully with `--help` flag
- [ ] Script runs successfully with `--version` flag

**Verify:** Walk through each checkbox manually.

### 5.4 PRD error case audit

Walk through every row in the PRD's "Required Error Cases" table (output-and-errors.md) and verify:

| Condition | Exit Code | Message Quality |
|-----------|-----------|-----------------|
| Not inside a git repo, no `<reference-repo>` | 2 | Guidance provided |
| `<reference-repo>` not a git repo | 1 | Clear message |
| No remotes found | 1 | — |
| Remote unreachable | 1 | Pre-mutation fail |
| Foreign data in existing slot | 1 | No overwrite |
| `.fork3/` missing for push/sync/status | 1 | Guidance to run create/init |
| `-l <id>` not found | 1 | Lists available |
| Auto-detect failure | 1 | Guidance + available IDs |
| Lineage ID collision | 1 | Clear message |
| Unknown subcommand | 2 | — |
| Invalid `-n` | 2 | — |
| Sync winner unresolvable | 1 | Lists choices |
| Dirty blocks sync | 1 | Lists dirty copies |
| Detached winner | 1 | — |

**Verify:** Each case tested and producing correct exit code + message.

### 5.5 Output polish

- Review all command outputs against PRD examples
- Ensure consistent use of `==>`, `✓`, `warn:`, `error:` prefixes
- Verify skip vs create vs mutate distinction is always clear
- Check `[M/N]` progress counters in creation loop

**Verify:** Side-by-side comparison with PRD output examples.

### 5.6 End-to-end walkthrough

Execute the full walkthrough from `walkthrough.md`:

1. Create first lineage (`my-project` with 3 copies)
2. Create second lineage (`libs/auth-service` with 2 copies)
3. Push with explicit `-l`
4. Status with auto-detect from inside a copy
5. Sync with auto-detect
6. Verify auto-detect failure from workspace root
7. Verify lineage ID collision

**Verify:** Every step produces the expected output and state.

### 5.7 CLI surface tests + full regression run

Add CLI surface tests (can be in a dedicated `tests/fork3/test_cli.py`
or distributed across existing test files):

| Scenario | Expectation |
|----------|-------------|
| `fork3 --help` | Exit 0, prints all subcommands |
| `fork3 --version` | Exit 0, prints version string |
| `fork3 ./repo -n 3` | Routes to create |
| `fork3 create ./repo -n 3` | Routes to create |
| `fork3 badcommand` | Exit 2, usage error |
| `fork3 create` (no repo) | Exit 2, missing argument |
| `fork3 create ./repo -n 1` | Exit 2, invalid `-n` (minimum 2) |

Then run the full test suite as a regression gate:

```bash
pytest tests/fork3/ -v
```

**Verify:** All tests pass. No regressions from polish changes.

---

## Task Count Summary

| Phase | Tasks | Cumulative |
|-------|-------|------------|
| Phase 1 | 10 | 10 |
| Phase 2 | 10 | 20 |
| Phase 3 | 6 | 26 |
| Phase 4 | 9 | 35 |
| Phase 5 | 7 | 42 |
