---
title: "CLI Commands"
parent: "prd-260418-fork3"
status: Active
created: 2026-04-18
updated: 2026-04-18
---

# CLI Commands

## Primary UX Model

`fork3` is one CLI with a mixed command model:

- Root invocation performs **create / expand** (equivalent to `fork3 create`)
- Subcommands perform **workspace operations**

This keeps the most common action short:

```bash
# --- Creating lineages (lineage ID derived or explicit) ---
fork3 ./my-project -n 2                     # create lineage "my-project" with 2 copies
fork3 create ./my-project -n 3              # explicit create, lineage ID = "my-project"
fork3 create ./my-project -n 3 -l mp        # explicit create with custom lineage ID "mp"
fork3 create ./libs/auth -n 2               # lineage ID = "libs-auth"

# --- Operating on lineages (lineage ID required or auto-detected) ---
fork3 push -l my-project                    # push all copies in the "my-project" lineage
fork3 sync branch2 -l my-project            # sync within the "my-project" lineage
fork3 status -l my-project                  # status of the "my-project" lineage

# --- Auto-detection: omit -l when inside a lineage's repo tree ---
cd /workspace/my-project                    # inside the target repo of "my-project"
fork3 status                                # auto-detects lineage "my-project"
fork3 push                                  # auto-detects lineage "my-project"

cd /workspace/branch1/my-project            # inside an offspring of "my-project"
fork3 status                                # auto-detects lineage "my-project"

cd /workspace                               # at workspace root, not inside any repo
fork3 status                                # FAILS — must specify -l
fork3 status -l my-project                  # explicit — works
```

When no subcommand is given and a `<reference-repo>` positional argument is present, the CLI defaults to the `create` command. The reference repo is always required for creation so the workspace origin is explicit.

---

## CLI Surface

### Root Command (Create / Expand)

```bash
fork3 <reference-repo> [-n N] [--uv] [-l <lineage-id>]
fork3 create <reference-repo> [-n N] [--uv] [-l <lineage-id>]
```

### Subcommands

```bash
fork3 init <reference-repo> [-l <lineage-id>]
fork3 push [-l <lineage-id>] [--dry-run]
fork3 sync <copy> [-l <lineage-id>] [--dry-run] [--no-push] [--force]
fork3 status [-l <lineage-id>]
```

### Global Options

```bash
fork3 --help
fork3 --version
```

### Global Principles

- One binary name: `fork3`
- No second companion command such as `fork3-sync`
- Every command resolves to exactly one lineage via explicit `-l <id>` or CWD-based auto-detection
- All non-read-only operations must have deterministic, explicit behavior
- All commands must produce human-readable output suitable for terminal use
- Error messages must be actionable and specific

---

## 1. Create / Expand Lineage

```bash
fork3 <reference-repo> [-n N] [--uv] [-l <lineage-id>]
fork3 create <reference-repo> [-n N] [--uv] [-l <lineage-id>]
```

Create or expand a fork3 lineage to the requested total copy count. If `.fork3/` does not yet exist at the workspace root, create it. If it already exists, register the new lineage in the existing `.fork3/`.

### Arguments and Options

| Argument / Flag | Required | Default | Meaning |
|-----------------|----------|---------|---------|
| `<reference-repo>` | Yes | — | Path to the original repository that serves as the lineage source |
| `-n N` | No | `3` | Total number of copies including the original (minimum: 2) |
| `--uv` | No | off | Replicate the uv-based virtual environment into newly created copies |
| `-l <lineage-id>` | No | derived from path | Custom lineage ID. If omitted, derived from the relative path of the reference repo (see [Lineage Model](lineage-model.md)). |

### Accepted Invocation Modes

| Mode | Example | Behavior |
|------|---------|----------|
| Explicit repo path | `fork3 /path/to/repo -n 4` | Uses the given repo as the reference, creates workspace in its parent |
| Relative repo path | `fork3 ./my-repo -n 4` | Uses the relative path resolved to an absolute repo path |

### Required Behavior

| Step | Behavior |
|------|----------|
| 1 | Resolve the reference repo path and determine the workspace root (parent directory) |
| 2 | Validate the reference repo is a git repository |
| 3 | Derive or validate the lineage ID |
| 4 | If `.fork3/` exists, check for lineage ID collision. If collision, fail. |
| 5 | Read remote configuration from the reference repo |
| 6 | Pre-flight: verify all remotes are reachable |
| 7 | Classify each requested slot as existing-valid, existing-invalid, or missing |
| 8 | If all slots exist, print summary and exit (true no-op) |
| 9 | Create only missing slots |
| 10 | Leave all valid existing slots untouched |
| 11 | Fetch all remotes in every copy so new branches are visible everywhere |
| 12 | Create or update `.fork3/` metadata at the workspace root (register this lineage) |
| 13 | Print a concise creation / skip summary |

### Slot Model

If `-n 4` is requested for lineage `my-project`, the workspace is defined as:

- Copy 0: `my-project/` (original, target repo)
- Copy 1: `branch1/my-project/`
- Copy 2: `branch2/my-project/`
- Copy 3: `branch3/my-project/`

The CLI treats each copy index as a durable slot in the lineage. Slot identity is stable across re-runs.

### Default Branch Naming

For a newly created slot `I`, the local working branch is:

```text
featI
```

Examples:

- slot 1 -> `feat1`
- slot 2 -> `feat2`
- slot 3 -> `feat3`

This naming rule applies only when a slot is first created. Existing slots are not renamed.

### Output Example (Expansion Case)

```
==> lineage: my-project
==> repo:    my-project
==> remote:  origin -> git@github.com:user/my-project.git
==> copies:  4 total (1 existing, 2 to create)

 ✓  branch1 — exists, skipping
[1/2] creating branch2/my-project
 ✓  branch2/my-project -> branch: feat2 (pushed)
[2/2] creating branch3/my-project
 ✓  branch3/my-project -> branch: feat3 (pushed)

==> syncing all copies …
 ✓  original fetched
 ✓  branch1 fetched
 ✓  branch2 fetched
 ✓  branch3 fetched

==> done — 4 copies ready (2 newly created)
```

### Output Example (No-op Case)

```
==> lineage: my-project
==> repo:    my-project
==> remote:  origin -> git@github.com:user/my-project.git
==> copies:  2 total (1 existing, 0 to create)

 ✓  branch1 — exists, skipping

==> all copies already exist — nothing to do
```

---

## 2. Init (Adopt Existing Layout)

```bash
fork3 init <reference-repo> [-l <lineage-id>]
```

Adopt an existing collection of repositories that already follow the fork3 naming convention by registering them as a lineage in `.fork3/` metadata at the workspace root.

Both `create` and `init` are additive — if `.fork3/` already exists, they add a new lineage entry rather than failing.

### Arguments

| Argument | Required | Meaning |
|----------|----------|---------|
| `<reference-repo>` | Yes | Path to the reference repository within the existing directory layout |
| `-l <lineage-id>` | No | Custom lineage ID. If omitted, derived from relative path. |

### Required Behavior

| Step | Behavior |
|------|----------|
| 1 | Resolve the reference repo path and determine the workspace root (parent directory) |
| 2 | Validate the reference repo is a git repository |
| 3 | Derive or validate the lineage ID |
| 4 | If `.fork3/` exists, check for lineage ID collision. If collision, fail. |
| 5 | Scan the workspace root for existing `branchN/<repo>/` directories matching this lineage |
| 6 | Validate each discovered copy is a git repository with a matching primary remote URL |
| 7 | Write or update `.fork3/lineages/<lineage-id>.toml` with this lineage's metadata |
| 8 | Print a summary of the adopted lineage |

### Output Example

```
==> lineage: my-project
==> repo:    my-project
==> remote:  origin -> git@github.com:user/my-project.git
==> adopting existing layout …

 ✓  original  — /path/to/my-project
 ✓  branch1   — /path/to/branch1/my-project (feat1)
 ✓  branch2   — /path/to/branch2/my-project (feat2)

==> lineage "my-project" registered — 3 copies adopted
```

### Error Cases

| Condition | Behavior |
|-----------|----------|
| Lineage ID already exists in `.fork3/` | Fail — lineage already registered |
| Reference repo is not a git repository | Fail |
| No `branchN/` directories found | Succeed — initialize with only the reference repo as copy 0 |
| A `branchN/<repo>` path exists but is not a valid clone | Warn and skip that slot |

---

## 3. Push

```bash
fork3 push [-l <lineage-id>] [--dry-run]
```

Push every copy in the resolved lineage, then fetch every copy so branches are visible everywhere.

### Behavior

| Step | Action | Parallelism |
|------|--------|-------------|
| 1 | Discover workspace and resolve lineage | — |
| 2 | For each eligible copy in the lineage, run push | Parallel |
| 3 | Wait for all push operations to finish | — |
| 4 | Run fetch-all for every copy in the lineage | Parallel |
| 5 | Print a status summary | — |

### Eligibility Rules

| Condition | Required Behavior |
|-----------|-------------------|
| Copy on normal branch with upstream | Push |
| Copy on normal branch without upstream | Push with upstream establishment |
| Copy in detached HEAD | Skip and warn |
| Lineage has only original copy | No-op with clear message |

### Dry Run

`--dry-run` must print the exact logical operations that would run, grouped by phase, without mutating the workspace.

---

## 4. Sync

```bash
fork3 sync <copy> [-l <lineage-id>] [--dry-run] [--no-push] [--force]
```

Use one copy as the winner and align all other eligible copies to that winner's branch within the resolved lineage.

### Winner Resolution

`<copy>` must resolve using the following priority:

| Priority | Input Form | Example | Resolution |
|----------|------------|---------|------------|
| 1 | Branch name | `feat2` | Copy currently checked out on `feat2` |
| 2 | Copy label | `branch2` | Slot 2 |
| 3 | Numeric index | `2` | Slot 2 |

If resolution is ambiguous or invalid, the CLI must fail and print the available choices.

### Behavior

| Step | Action |
|------|--------|
| 1 | Discover workspace and resolve lineage |
| 2 | Resolve winner within the lineage |
| 3 | Refuse operation if winner is detached |
| 4 | Check for dirty copies and abort unless `--force` |
| 5 | For each non-winner eligible copy: fetch |
| 6 | Reset each non-winner eligible copy to winner remote branch |
| 7 | Unless `--no-push`, force-push with lease |
| 8 | Fetch all copies in the lineage |
| 9 | Print refreshed status summary |

### Safety Rules

- Default behavior must protect local uncommitted work
- Dirty copies must block sync unless `--force` is explicitly supplied
- Sync must use force-with-lease semantics, not blind force push
- A detached winner is invalid

### Skip Rules

| Condition | Required Behavior |
|-----------|-------------------|
| Winner copy | Never reset |
| Non-winner in detached HEAD | Skip and warn |
| Single-copy lineage | No-op with clear message |

### Dry Run

`--dry-run` must print the winner and the per-copy plan without making changes.

---

## 5. Status

```bash
fork3 status [-l <lineage-id>]
```

Print a readable summary of all discovered copies in the resolved lineage.

### Required Summary Fields

| Field | Meaning |
|-------|---------|
| Copy | `original`, `branch1`, `branch2`, ... |
| Directory | Filesystem path to the copy |
| Branch | Current checked-out branch or detached state |
| Remote | Upstream tracking branch if present |
| Dirty | Whether uncommitted changes exist |
| Ahead/Behind | Divergence relative to upstream |

### Output Example

```
==> workspace: /path/to/parent
==> lineage:   my-project
==> repo:      my-project
==> remote:    origin
==> copies:    3

  Copy       Dir                              Branch   Remote          Dirty   Ahead/Behind
  ---------  -------------------------------  -------  --------------  -----   ------------
  original   /path/to/my-project              main     origin/main     clean   0/0
  branch1    /path/to/branch1/my-project      feat1    origin/feat1    clean   2/0
  branch2    /path/to/branch2/my-project      feat2    origin/feat2    1 file  0/3
```

### Output Goal

The output must help a user answer these questions quickly:

- Which copies exist?
- Which branch is each copy on?
- Which copy is dirty?
- Which copies have not been pushed?
- Which copy should be chosen as sync winner?

---

## `--uv` Behavior

`--uv` only applies to root create / expand behavior.

### Product Meaning

When enabled, new copies should receive the same uv-managed environment setup as the original repository, including the minimal shell integration needed for local activation behavior.

### Constraints

- `--uv` applies only to newly created slots
- Existing valid slots must not be rebuilt or rewritten during idempotent re-runs
- Missing or invalid original environment state must produce a clear error if `--uv` is requested

### UX Rule

The CLI must clearly indicate whether each new slot received environment setup, and whether existing slots were skipped.
