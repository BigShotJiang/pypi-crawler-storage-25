---
title: "Design Decisions & Future Extensions"
parent: "prd-260418-fork3"
status: Active
created: 2026-04-18
updated: 2026-04-18
---

# Design Decisions & Future Extensions

## Design Decisions

| Decision | Rationale |
|----------|-----------|
| One CLI named `fork3` | Simplifies the mental model and removes the shell split between create and sync workflows |
| Root invocation performs create / expand | Matches the requested examples (`fork3 ./repo -n 2`) and keeps the most common action short |
| `create` also available as explicit subcommand | Allows discoverability via `--help` while keeping the shorthand ergonomic |
| `<reference-repo>` is always required for create | Makes the workspace origin explicit; avoids ambiguity when CWD is inside an unrelated git repo |
| `.fork3/` at workspace root, tracking all lineages | Single metadata directory enables multi-lineage management without per-repo metadata |
| Per-lineage `.toml` files under `lineages/` | Isolates lineage metadata — adding/removing a lineage doesn't mutate shared state; corruption is contained |
| Two ways to create `.fork3/`: `create` and `init` | `create` handles the green-field case; `init` adopts an existing directory layout without re-cloning |
| Lineage ID required for every command | Multi-lineage workspace needs unambiguous targeting; auto-detection provides ergonomic shortcut |
| Lineage ID defaults to relative path with `/` → `-` | Deterministic, readable, and requires no user input in common cases |
| Auto-detection walks up to 5 parent dirs | Fast failure outside workspaces; sufficient depth for nested repo structures |
| Auto-detection only from inside a lineage's repo tree | Prevents accidental operations when at workspace root with multiple lineages |
| Requested `-n` means minimum desired size | Enables idempotent re-runs and natural expansion semantics |
| Slot-based workspace identity | Makes repeated operations predictable and easy to explain |
| `.fork3/`-based discovery instead of directory heuristics | Walking upward for `.fork3/` is reliable and unambiguous, avoids false positives from similarly named directories |
| Existing valid slots are never touched | Protects user work and makes repeated invocation safe |
| No-op means zero I/O | A true no-op must not run fetch, push, or any git command |
| Read-only status plus explicit mutating commands | Keeps behavior legible and reduces surprise |
| Safety before convenience in sync | Necessary because reset and force-push are destructive operations |
| Force-with-lease over blind force | Prevents overwriting work pushed from another machine |
| Parallel push and fetch | Copies are independent; parallelism reduces wall-clock time proportional to N |

---

## Future Extensions

These may be added later, but are not part of this PRD:

- `fork3 diff <A> <B>`
- `fork3 run <cmd>`
- `fork3 clean`
- `fork3 doctor`
- `fork3 list` — list all lineages in the workspace
- subset-targeted sync or push operations
- `fork3 create --shrink`
- cross-lineage operations
