---
title: "Output & Error Model"
parent: "prd-260418-fork3"
status: Active
created: 2026-04-18
updated: 2026-04-18
---

# Output & Error Model

## Output Style

The CLI should feel like a professional developer utility:

- concise by default
- readable at a glance
- explicit about skip vs create vs mutate actions
- safe for repeated use

---

## Message Categories

| Category | Style | Meaning |
|----------|-------|---------|
| Info | Blue `==>` | High-level phase progress |
| Success | Green `✓` | Completed action |
| Warning | Yellow `warn:` | Skipped or degraded behavior |
| Error | Red `error:` | Action aborted |

---

## Create / Expand Output Expectations

The CLI must distinguish clearly between:

- already exists, skipped
- newly created (with `[M/N]` progress counters)
- invalid existing slot, abort
- nothing to do

This distinction is essential to making idempotent behavior understandable and trustworthy.

---

## Exit Code Conventions

| Exit Code | Meaning |
|-----------|---------|
| `0` | Success |
| `1` | Runtime / environment / repository state error |
| `2` | CLI usage error |

---

## Required Error Cases

| Condition | Expected Outcome |
|-----------|------------------|
| Not inside a git repo and no `<reference-repo>` provided | Usage / runtime error with guidance |
| `<reference-repo>` is not a git repo | Fail |
| No remotes found in original repo | Fail |
| Remote unreachable during creation pre-flight | Fail before mutation |
| Existing slot path contains foreign or invalid data | Fail, do not overwrite |
| `.fork3/` missing when running `push`, `sync`, or `status` | Fail with guidance to run `create` or `init` |
| `-l <id>` specified but lineage ID not found | Fail with available lineage IDs |
| `-l` omitted and lineage cannot be auto-detected | Fail with guidance and available lineage IDs |
| Lineage ID collision during `create` or `init` | Fail |
| `fork3 init` with lineage ID that already exists | Fail — lineage already registered |
| Unknown subcommand | Usage error |
| Invalid `-n` value (< 2 or non-integer) | Usage error |
| Sync winner cannot be resolved | Fail with available choices |
| Dirty copies block sync without `--force` | Fail |
| Winner in detached HEAD | Fail |

---

## Error Principle

If the CLI cannot prove an operation is safe, it must stop instead of guessing.
