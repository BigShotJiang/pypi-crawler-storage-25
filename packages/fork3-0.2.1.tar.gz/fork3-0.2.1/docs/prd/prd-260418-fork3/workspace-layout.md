---
title: "Workspace Layout & .fork3 Metadata"
parent: "prd-260418-fork3"
status: Active
created: 2026-04-18
updated: 2026-04-18
---

# Workspace Layout & `.fork3` Metadata

## Layout Contract

The tool depends on a convention-based workspace layout with an explicit metadata directory:

```text
<workspace-root>/
├── .fork3/                        # workspace metadata — tracks ALL lineages
│   ├── config                     # global config
│   └── lineages/
│       ├── my-project.toml        # per-lineage metadata
│       └── libs-auth-service.toml # per-lineage metadata
│
│   # --- lineage "my-project" ---
├── my-project/                    # target repo (copy 0)
├── branch1/my-project/            # slot 1, on feat1
├── branch2/my-project/            # slot 2, on feat2
├── branch3/my-project/            # slot 3, on feat3
│
│   # --- lineage "libs-auth-service" ---
├── libs/auth-service/             # target repo (copy 0)
├── branch1/libs/auth-service/     # slot 1, on feat1
└── branch2/libs/auth-service/     # slot 2, on feat2
```

### Rules

- The `.fork3/` directory lives at the **workspace root**, as a sibling of the target repos
- Each target (ancestor) repository lives directly under the workspace root (possibly in a nested subdirectory)
- Additional copies (offspring) live under `branchN/`, mirroring the target repo's relative path
- `N` is a 1-based integer
- Discovery must sort branch directories numerically, not lexicographically
- A single `.fork3/` directory is the source of truth for **all** lineages in the workspace
- The `.fork3/` directory is the single source of truth for workspace identity and configuration

This layout is part of the product contract and not configurable in v1.

---

## `.fork3` Metadata

The `.fork3/` directory is analogous to `.git/` — it marks a directory tree as a fork3 workspace and persists the configuration needed for all workspace operations across all lineages.

### Location

Always at `<workspace-root>/.fork3/`.

### Contents

| Path | Purpose |
|------|---------|
| `config` | Global configuration (root-level settings) |
| `lineages/<lineage-id>.toml` | Per-lineage metadata: ancestor repo path, primary remote, copy count, creation timestamp |

Each lineage gets its own file under `lineages/`. This design means:

- Adding or removing a lineage does not mutate shared state
- Corruption in one lineage file does not affect others
- Listing lineages = listing files in the `lineages/` directory
- Each file is independently inspectable and debuggable

### Creation

`.fork3/` is created on the first `create` or `init` command. Subsequent `create` or `init` commands that target additional repos register new lineages into the existing `.fork3/`.

| Method | Command | When |
|--------|---------|------|
| Automatic | `fork3 create <reference-repo>` | Created (or updated) as part of normal lineage creation |
| Adopt existing | `fork3 init <reference-repo>` | Created (or updated) on top of an existing directory layout |

Both `create` and `init` are additive — if `.fork3/` already exists, they add a new lineage entry rather than failing.

### Constraints

- The `.fork3/` directory must exist before any operational command (`push`, `sync`, `status`) can proceed
- If `.fork3/` is missing, operational commands must fail with a clear message directing the user to run `fork3 create` or `fork3 init`
- `.fork3/` must not be committed into any git repository — it is a workspace-level artifact
