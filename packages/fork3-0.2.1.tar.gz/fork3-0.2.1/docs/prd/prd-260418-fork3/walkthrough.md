---
title: "End-to-End Walkthrough"
parent: "prd-260418-fork3"
status: Active
created: 2026-04-18
updated: 2026-04-18
---

# End-to-End Walkthrough

This walkthrough demonstrates how `.fork3`, lineages, and lineage IDs work together in a realistic multi-repo scenario.

---

## Setup

```
/home/dev/work/                            # this will become the workspace root
├── my-project/                            # a git repo
└── libs/auth-service/                     # another git repo, nested path
```

---

## Step 1 — Create first lineage

```bash
cd /home/dev/work
fork3 ./my-project -n 3
```

- `.fork3/` is created at `/home/dev/work/.fork3/`
- Lineage ID: `my-project` (derived from relative path `my-project`, no `/` to replace)
- Lineage metadata written to `.fork3/lineages/my-project.toml`
- Result:

```
/home/dev/work/
├── .fork3/
│   └── lineages/
│       └── my-project.toml
├── my-project/                  # copy 0 (ancestor)
├── branch1/my-project/          # copy 1, on feat1
└── branch2/my-project/          # copy 2, on feat2
```

---

## Step 2 — Create second lineage in the same workspace

```bash
fork3 ./libs/auth-service -n 2
```

- Reuses the existing `.fork3/` at `/home/dev/work/.fork3/`
- Lineage ID: `libs-auth-service` (derived from `libs/auth-service`, `/` → `-`)
- Result:

```
/home/dev/work/
├── .fork3/
│   └── lineages/
│       ├── my-project.toml              # first lineage
│       └── libs-auth-service.toml       # second lineage
├── my-project/
├── libs/auth-service/                   # copy 0 (ancestor) of second lineage
├── branch1/my-project/
├── branch1/libs/auth-service/           # copy 1 of second lineage, on feat1
└── branch2/my-project/
```

---

## Step 3 — Operate with explicit lineage ID

```bash
# from anywhere:
fork3 push -l my-project                # pushes all 3 copies of my-project
fork3 status -l libs-auth-service       # shows status of auth-service lineage
fork3 sync branch1 -l my-project        # syncs within my-project lineage
```

---

## Step 4 — Operate with auto-detected lineage ID

```bash
cd /home/dev/work/my-project
fork3 status
# walks up: /home/dev/work/my-project → /home/dev/work (finds .fork3/)
# CWD is inside target repo "my-project" → lineage auto-resolved to "my-project"
# output: status of "my-project" lineage

cd /home/dev/work/branch1/libs/auth-service
fork3 push
# walks up: .../branch1/libs/auth-service → .../branch1 → /home/dev/work (finds .fork3/)
# CWD is inside offspring of "libs-auth-service" → lineage auto-resolved
# output: pushes all copies of "libs-auth-service" lineage

cd /home/dev/work/branch1/libs/auth-service/src/handlers
fork3 status
# walks up: .../src/handlers → .../src → .../auth-service → .../libs → .../branch1 → /home/dev/work
# that's 5 hops — just within limit — finds .fork3/
# CWD is inside offspring of "libs-auth-service" → auto-resolved
```

---

## Step 5 — Auto-detection fails

```bash
cd /home/dev/work
fork3 status
# .fork3/ is in CWD — workspace found
# but CWD is the workspace root, not inside any lineage repo
# FAILS: "Cannot auto-detect lineage from workspace root. Use -l <id>."
# Available lineages: my-project, libs-auth-service

cd /tmp/unrelated-project
fork3 push
# walks up 5 dirs, no .fork3/ found
# FAILS: "No fork3 workspace found."
```

---

## Step 6 — Custom lineage ID

```bash
fork3 create ./my-project -n 3 -l mp
# lineage ID explicitly set to "mp" instead of default "my-project"
# metadata written to .fork3/lineages/mp.toml
# all subsequent commands use -l mp:
fork3 push -l mp
fork3 status -l mp
```

---

## Step 7 — Lineage ID collision

```bash
# "my-project" lineage already exists
fork3 create ./other/my-project -n 2
# default lineage ID would be "other-my-project" — no collision, succeeds

fork3 create ./new-repo -n 2 -l my-project
# FAILS: lineage ID "my-project" already exists in this workspace
```
