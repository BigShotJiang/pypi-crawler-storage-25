---
id: prd-260418-fork3
title: "fork3 — CLI Product Requirements Document"
status: Active
created: 2026-04-18
updated: 2026-04-18
tags:
  - cli
  - git
  - developer-tools
---

# fork3 — CLI Product Requirements Document

## Context / Problem

The current workflow is split across two shell commands:

- `fork3.sh` creates parallel local clones of a git repository.
- `fork3-sync.sh` handles repeated multi-copy operations such as push-all, sync-to-winner, and workspace status.

That split is functionally useful, but the shell implementation has crossed the complexity threshold where Bash is no longer the right design medium. Workspace discovery, idempotent creation, multi-copy state inspection, and coordinated git operations are all better expressed as a single Python CLI with one coherent command surface.

This document defines the product requirements for a Python CLI named `fork3`.

The document is intentionally limited to CLI product behavior. It does not describe code structure, module layout, or implementation planning.

---

## Product Goal

`fork3` is a local developer CLI for managing "parallel branch workspaces" around git repositories.

The tool must let a user:

1. Create or expand a lineage with `N` total copies from a reference repository.
2. Manage multiple independent lineages under one workspace root.
3. Re-run the same command safely without duplicating work.
4. Push all copies of a lineage in one operation.
5. Pick one copy as the winner and sync the others to it.
6. Inspect the current lineage state from any copy.

The tool is optimized for solo developer workflows on a local machine, where multiple working copies are used to explore competing implementations in parallel.

---

## Non-Goals

The following are explicitly out of scope for this PRD:

- GUI or TUI workflows
- Merge or rebase orchestration
- Branch deletion or workspace teardown
- Remote creation or remote topology editing
- Non-git repositories
- Background daemons or persistent services
- CI/CD integration behavior
- Implementation details such as package structure, classes, or concurrency model

---

## Scope

| In Scope | Out of Scope |
|----------|--------------|
| Idempotent workspace creation | Shrinking an existing workspace |
| Workspace expansion from smaller N to larger N | Auto-deleting extra copies |
| Auto-discovery of an existing workspace | Arbitrary custom directory layouts |
| Push all copies | Merge conflict resolution workflows |
| Sync all non-winner copies to a winner | Partial sync of a selected subset |
| Status summary | Cross-machine coordination |
| Multiple lineages per workspace | Cross-lineage operations |
| Optional `--uv` environment replication for newly created copies | Managing non-uv Python environments |

---

## PRD Modules

| Module | Contents |
|--------|----------|
| [Lineage Model](lineage-model.md) | Terminology, lineage ID rules, multi-lineage concept |
| [Lineage Resolution](lineage-resolution.md) | Explicit and auto-detected lineage routing, workspace discovery |
| [CLI Commands](cli-commands.md) | Primary UX model, CLI surface, all command semantics, `--uv` behavior |
| [Workspace Layout](workspace-layout.md) | Directory layout contract, `.fork3/` metadata structure |
| [Idempotency](idempotency.md) | Idempotency guarantees, slot classification rules |
| [Output & Errors](output-and-errors.md) | Output style, error model, exit codes |
| [Design Decisions](design-decisions.md) | Design rationale table, future extensions |
| [Walkthrough](walkthrough.md) | End-to-end multi-lineage worked example |
