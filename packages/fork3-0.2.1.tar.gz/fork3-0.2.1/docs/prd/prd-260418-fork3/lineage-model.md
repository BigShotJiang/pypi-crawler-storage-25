---
title: "Lineage Model"
parent: "prd-260418-fork3"
status: Active
created: 2026-04-18
updated: 2026-04-18
---

# Lineage Model

A **lineage** is the fundamental unit of fork3. It represents one reference repository (the **ancestor**, also called the **target repo**) together with all of its derived copies (the **offspring**).

---

## Terminology

| Term | Meaning |
|------|---------|
| **Workspace root** | A directory containing a `.fork3/` metadata directory. A workspace root can host multiple lineages. |
| **Lineage** | One target repo (ancestor) plus its `branchN/<repo>` copies. Each lineage is identified by a lineage ID. |
| **Lineage ID** | A unique string that identifies a lineage within a workspace. Every operational command must resolve to exactly one lineage. |
| **Target repo** (ancestor) | The original git repository that serves as copy 0 of a lineage. |
| **Copy** (offspring) | A `branchN/<repo>` clone derived from the target repo. |

---

## `.fork3/` Location

The `.fork3/` directory always lives at the **workspace root** — the common parent directory that contains the target repo(s) and their offspring. It is **not** inside any individual git repository. A single `.fork3/` directory tracks **all** lineages within that workspace root.

```text
<workspace-root>/
├── .fork3/                       # single metadata dir — tracks ALL lineages
├── my-project/                   # target repo for lineage "my-project"
├── branch1/my-project/           # offspring of "my-project" lineage
├── branch2/my-project/           # offspring of "my-project" lineage
├── libs/auth-service/            # target repo for lineage "libs-auth-service"
├── branch1/libs/auth-service/    # offspring of "libs-auth-service" lineage
└── branch2/libs/auth-service/    # offspring of "libs-auth-service" lineage
```

---

## Lineage ID Rules

| Rule | Detail |
|------|--------|
| Explicit | A lineage ID can be specified with `--lineage <id>` (or `-l <id>`) at `create` or `init` time. |
| Default | If not specified, the ID is the **relative path** of the target repo from the workspace root, with every `/` replaced by `-`. |
| Uniqueness | A lineage ID must be unique within a workspace. Creation or init must fail if the ID collides with an existing lineage. |
| Immutable | Once assigned, a lineage ID cannot be changed. |

---

## Default Lineage ID Derivation

| Target repo relative path | Default lineage ID |
|------------------------------|-------------------|
| `my-project` | `my-project` |
| `repos/my-project` | `repos-my-project` |
| `libs/auth-service` | `libs-auth-service` |
| `work/deep/service` | `work-deep-service` |

---

## One Workspace, Multiple Lineages

A single `.fork3/` directory at the workspace root can track many lineages. Each lineage is fully independent — its copies, branches, remotes, and sync state are tracked separately. This allows a developer to manage parallel-branch workflows for several related or unrelated repos from one workspace root.
