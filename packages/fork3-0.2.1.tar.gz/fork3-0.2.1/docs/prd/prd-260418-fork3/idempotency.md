---
title: "Idempotency Requirements"
parent: "prd-260418-fork3"
status: Active
created: 2026-04-18
updated: 2026-04-18
---

# Idempotency Requirements

Idempotency is a core product guarantee.

---

## Definition

For root `fork3` create / expand behavior:

- Re-running with the same requested size must not create duplicate clones
- Re-running with a smaller requested size must not remove or modify existing higher-numbered slots
- Re-running with a larger requested size must create only the missing new slots
- Existing valid slots must remain untouched
- A no-op re-run must perform no mutating git or filesystem operations

---

## Canonical Cases

| Case | First Run | Second Run | Required Result |
|------|-----------|------------|-----------------|
| Exact re-run | `fork3 ./repo -n 2` | `fork3 ./repo -n 2` | No-op |
| Subset re-run | `fork3 ./repo -n 4` | `fork3 ./repo -n 2` | No-op |
| Expansion | `fork3 ./repo -n 2` | `fork3 ./repo -n 4` | Create only additional slots |

---

## Product Rule

The requested `-n` value defines the **minimum desired workspace size**, not the exact final size.

Implications:

- If actual size already satisfies requested size, no creation occurs
- If no creation occurs, the command is a true no-op (no I/O, no fetch, no output beyond summary)
- If actual size is smaller than requested size, only the missing slots are created
- The CLI must not treat a smaller later request as a shrink operation

---

## Slot Classification Rules

For each requested slot `I`:

| Slot State | Detection | Required Behavior |
|------------|-----------|-------------------|
| Existing valid | `branchI/<repo>/.git` exists and primary remote URL matches | Skip |
| Existing invalid | Path exists but is not a valid clone of the target workspace | Fail with clear error |
| Missing | Path does not exist | Create |

---

## Untouched Means Untouched

For an existing valid slot, the create / expand command must not:

- re-clone it
- reset its branch
- overwrite local changes
- recreate its branch
- modify its remote configuration
- recreate its environment

The only allowed read-write action after successful slot classification is the workspace-wide fetch stage that updates remote visibility. That fetch runs only when new slots were created, so that new branches become visible in all copies.

If no new slots are created, even that follow-up fetch must be skipped so the command remains fully idempotent in the user's sense of "nothing should happen."
