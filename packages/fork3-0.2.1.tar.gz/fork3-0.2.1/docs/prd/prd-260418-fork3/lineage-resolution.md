---
title: "Lineage ID Resolution"
parent: "prd-260418-fork3"
status: Active
created: 2026-04-18
updated: 2026-04-18
---

# Lineage ID Resolution

Every fork3 command must resolve to exactly one lineage. There are two mechanisms.

---

## 1. Explicit: `--lineage <id>` / `-l <id>`

The caller passes the lineage ID directly. This always works, from any working directory.

---

## 2. Implicit: Auto-Detection from CWD

When `-l` is omitted, the CLI attempts to infer the lineage:

| Step | Action |
|------|--------|
| 1 | Walk upward from CWD, examining up to **5 parent directories**, looking for a `.fork3/` directory. |
| 2 | If `.fork3/` is found, read its configuration to determine the workspace root. |
| 3 | Compute the relative path of CWD from the workspace root. |
| 4 | Match the CWD against known lineage target repos and their offspring directories. |
| 5 | If exactly one lineage matches, use it. If zero or more than one match, fail with guidance. |

---

## Auto-Detection Constraint

- The upward walk stops after checking **5 parent directories**. If no `.fork3/` is found within that limit, the command fails.
- Auto-detection only succeeds when CWD is inside a target repo or one of its offspring directories. Being at the workspace root itself (but not inside any repo) does **not** auto-resolve a lineage — `-l` is required.

---

## Depth Limit Examples

| CWD | Hops to workspace root | Within limit? |
|-----|----------------------|---------------|
| `/work/my-project` | 1 | ✓ |
| `/work/branch1/my-project` | 2 | ✓ |
| `/work/branch1/libs/auth-service` | 3 | ✓ |
| `/work/branch1/libs/auth-service/src` | 4 | ✓ |
| `/work/branch1/libs/auth-service/src/handlers` | 5 | ✓ |
| `/work/branch1/libs/auth-service/src/handlers/v2` | 6 | ✗ — too deep |

---

## Failure Cases

| Condition | Behavior |
|-----------|----------|
| No `.fork3/` found within 5 parent dirs | Fail: "No fork3 workspace found. Run `fork3 create` or `fork3 init` first." |
| CWD is at workspace root, not inside any lineage | Fail: "Cannot auto-detect lineage from workspace root. Use `-l <id>` to specify." |
| CWD matches multiple lineages | Fail: "Ambiguous lineage. Use `-l <id>` to specify." (list available IDs) |
| `-l <id>` specified but ID not found | Fail: "Lineage '<id>' not found. Available: ..." |

---

## Workspace Discovery Algorithm

Commands that operate on an existing workspace must auto-discover the workspace from the current working directory using the `.fork3/` metadata directory, then resolve which lineage to operate on.

### Discovery Inputs

The user may invoke `fork3` from:

- the workspace root
- a target repository (ancestor) belonging to a lineage
- any `branchN/<repo>` clone (offspring)
- a nested directory inside any of those repositories

### Full Discovery Sequence

| Step | Action |
|------|--------|
| 1 | Walk upward from CWD, checking up to **5 parent directories** for a `.fork3/` directory. |
| 2 | If found, the parent of `.fork3/` is the workspace root. |
| 3 | Read `.fork3/lineages/` to enumerate all registered lineages. |
| 4 | If `-l <id>` was provided, look up the lineage by ID. Fail if not found. |
| 5 | If `-l` was not provided, compute the CWD's relative path from the workspace root and match it against known lineage target repo paths and offspring paths. |
| 6 | If exactly one lineage matches, use it. |
| 7 | If zero or more than one match, fail with guidance. |

### Discovery Outputs

The CLI must determine:

- workspace root (directory containing `.fork3/`)
- the resolved lineage ID
- target repo path for the resolved lineage
- repo name
- list of all valid copies within the resolved lineage
- copy labels (`original`, `branch1`, `branch2`, ...)
- current branch per copy
- primary remote name from the target repo

### Discovery Failure

| Condition | Behavior |
|-----------|----------|
| No `.fork3/` found within 5 parent directories | Fail with a message directing the user to run `fork3 create` or `fork3 init` |
| `.fork3/` found but `lineages/` is empty or corrupt | Fail with actionable error |
| `.fork3/` found but target repo directory for resolved lineage is missing | Fail with clear explanation |
| `-l <id>` specified but ID not found in `.fork3/lineages/` | Fail: "Lineage '<id>' not found. Available: ..." |
| `-l` omitted and CWD is at workspace root | Fail: "Cannot auto-detect lineage from workspace root. Use `-l <id>`." |
| `-l` omitted and CWD matches multiple lineages | Fail: "Ambiguous lineage. Use `-l <id>`." |
