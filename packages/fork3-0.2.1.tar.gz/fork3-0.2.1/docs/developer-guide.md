# Developer Guide — Publishing to PyPI

## Prerequisites

| Tool | Install |
|------|---------|
| [uv](https://docs.astral.sh/uv/) | `curl -LsSf https://astral.sh/uv/install.sh \| sh` |
| [twine](https://twine.readthedocs.io/) | `uv pip install twine` |

You also need a [PyPI account](https://pypi.org/account/register/) and an
[API token](https://pypi.org/manage/account/token/) (scoped to the `fork3` project).

## Version Management

The single source of truth for the package version is the `VERSION` file at
the project root. To bump the version, edit that file:

```bash
echo "0.2.0" > VERSION
```

Hatchling reads `VERSION` at build time and embeds it in the wheel metadata.
At runtime, `fork3._version.read_version()` resolves it from the installed
package data.

## Local Development

Install in editable mode so the `fork3` command runs your local source:

```bash
uv pip install -e .
```

Changes to `src/fork3/` take effect immediately — no rebuild needed.

Alternatively, use `uv run` without installing:

```bash
uv run fork3 <args>
```

### Global `fork3-dev` Command

For day-to-day development you can install a `fork3-dev` wrapper that is
available globally (i.e. from any directory) and reports a `-dev` version
suffix:

```bash
# Install
./scripts/dev.sh install

# Verify
fork3-dev --version   # → fork3 0.2.1-dev

# Uninstall
./scripts/dev.sh uninstall
```

The wrapper lives at `~/.local/bin/fork3-dev` and delegates to the
editable install, so source changes take effect immediately. Make sure
`~/.local/bin` is on your `PATH`.

## Building Locally

```bash
uv build
```

This produces `dist/fork3-<version>.tar.gz` (sdist) and
`dist/fork3-<version>-py3-none-any.whl` (wheel).

## Publishing

### Quick Reference

```bash
# Dry-run (build only, no upload)
./scripts/publish.sh --dry-run

# Publish to TestPyPI
./scripts/publish.sh --test

# Publish to production PyPI
./scripts/publish.sh
```

### Step-by-Step

1. **Bump the version** in `VERSION`.
2. **Run tests** to make sure everything passes:
   ```bash
   uv run pytest
   ```
3. **Dry-run build** to verify the artifacts:
   ```bash
   ./scripts/publish.sh --dry-run
   ```
4. **Publish to TestPyPI** first to verify the upload:
   ```bash
   ./scripts/publish.sh --test
   ```
5. **Install from TestPyPI** and smoke-test:
   ```bash
   uv pip install \
     --index-url https://test.pypi.org/simple/ \
     --extra-index-url https://pypi.org/simple/ \
     fork3==<version>
   fork3 --version
   ```
6. **Publish to production PyPI**:
   ```bash
   ./scripts/publish.sh
   ```

### Authentication

Twine reads credentials from environment variables or `~/.pypirc`.

**Option A — Environment variables (recommended for CI):**

```bash
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-AgEIcH...      # your API token
```

**Option B — `~/.pypirc` file (local development):**

```ini
[pypi]
username = __token__
password = pypi-AgEIcH...

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-AgEIcH...
```

> **Security:** Never commit `.pypirc` or tokens to the repository. The
> `.gitignore` already excludes `.pypirc`.

## Release Checklist

- [ ] Version bumped in `VERSION`
- [ ] `uv run pytest` passes
- [ ] `./scripts/publish.sh --dry-run` builds cleanly
- [ ] `./scripts/publish.sh --test` uploads to TestPyPI successfully
- [ ] Smoke-test install from TestPyPI works
- [ ] `./scripts/publish.sh` uploads to production PyPI
- [ ] Git tag created: `git tag v<version> && git push --tags`
