# fork3

Manage parallel branch workspaces around git repositories.

## Installation

```bash
pip install fork3
```

Or with [pipx](https://pipx.pypa.io/) for isolated CLI installs:

```bash
pipx install fork3
```

Or with [uv](https://docs.astral.sh/uv/):

```bash
uv pip install fork3
```

## Usage

```bash
fork3 create   # Create parallel branch workspaces
fork3 status   # Show workspace status
fork3 sync     # Sync workspaces with remote
fork3 push     # Push workspace branches
```

Run `fork3 --help` for full usage details.

## Documentation

- [`docs/prd/`](docs/prd/prd-260418-fork3/index.md) — Product requirements (CLI behavior, workspace model, idempotency rules)
- [`docs/tech/`](docs/tech/execution-plan.md) — Technical design (execution plan, testing strategy, gap analysis)
- [`docs/tech/tech-260419-fork3-standalone.md`](docs/tech/tech-260419-fork3-standalone.md) — Standalone extraction design

> `installation-integration.md` is superseded — fork3 is now distributed via PyPI, not the monorepo `install.sh` system.

## Requirements

- Python >= 3.11
- Git

## License

[CC BY-NC-ND 4.0](https://creativecommons.org/licenses/by-nc-nd/4.0/)
