"""
Test ActionLoader functionality

Verifies that all actions can be discovered and loaded correctly
using the ActionLoader instead of hardcoded imports.
"""

import logging

from statemachine_engine.core.action_loader import ActionLoader, get_action_loader


class TestActionLoader:
    """Tests for ActionLoader discovery and loading"""

    def test_action_discovery(self):
        """Test that ActionLoader can discover all actions"""
        loader = ActionLoader()
        available_actions = loader.get_available_actions()

        # Should discover multiple actions
        assert len(available_actions) > 0, "ActionLoader should discover at least some actions"

        # Check for critical engine actions
        critical_actions = ['bash', 'log', 'check_database_queue']
        for action in critical_actions:
            assert action in available_actions, f"Critical action '{action}' should be discoverable"

    def test_load_bash_action(self):
        """Test loading bash action class"""
        loader = ActionLoader()
        action_class = loader.load_action_class('bash')

        assert action_class is not None, "Bash action should be loadable"
        assert action_class.__name__ == 'BashAction', "Should load correct class"

    def test_load_log_action(self):
        """Test loading log action class"""
        loader = ActionLoader()
        action_class = loader.load_action_class('log')

        assert action_class is not None, "Log action should be loadable"
        assert action_class.__name__ == 'LogAction', "Should load correct class"

    def test_load_nonexistent_action(self):
        """Test that loading nonexistent action returns None"""
        loader = ActionLoader()
        action_class = loader.load_action_class('nonexistent_action_xyz')

        assert action_class is None, "Nonexistent action should return None"

    def test_bash_action_instantiation(self):
        """Test that loaded bash action can be instantiated"""
        loader = ActionLoader()
        action_class = loader.load_action_class('bash')

        config = {'command': 'echo test', 'description': 'test command'}
        action_instance = action_class(config)

        assert action_instance is not None, "Action should instantiate successfully"
        assert hasattr(action_instance, 'execute'), "Action should have execute method"

    def test_log_action_instantiation(self):
        """Test that log action can be instantiated"""
        loader = ActionLoader()
        action_class = loader.load_action_class('log')

        config = {'message': 'test message'}
        action_instance = action_class(config)

        assert action_instance is not None, "Log action should instantiate"
        assert hasattr(action_instance, 'execute'), "Action should have execute method"

    def test_critical_actions_loadable(self):
        """Test that all critical actions can be loaded"""
        loader = ActionLoader()

        critical_actions = [
            'bash',
            'log',
            'check_database_queue',
            'send_event'
        ]

        for action_type in critical_actions:
            action_class = loader.load_action_class(action_type)
            assert action_class is not None, f"Critical action '{action_type}' should be loadable"


class TestActionLoaderDomain:
    """Tests for domain-specific actions (may fail if domain actions not available)"""

    def test_load_domain_actions_if_available(self):
        """Test loading domain-specific actions if they exist"""
        loader = ActionLoader()
        available_actions = loader.get_available_actions()

        domain_actions = ['generate_concepts', 'rank_concepts', 'generate_prompts', 'enhance_prompt']

        for action_type in domain_actions:
            if action_type in available_actions:
                action_class = loader.load_action_class(action_type)
                # If it's discovered, it should be loadable
                if action_class is not None:
                    # Verify it has execute method
                    assert hasattr(action_class, '__init__'), f"{action_type} should have __init__ method"


class TestGetActionLoader:
    """Tests for get_action_loader caching (FR-FSM-012)"""

    def setup_method(self):
        """Clear module-level cache before each test."""
        import statemachine_engine.core.action_loader as _al
        _al._loader_cache.clear()

    def test_same_key_returns_same_instance(self):
        """get_action_loader called twice with same key must return identical object."""
        loader1 = get_action_loader()
        loader2 = get_action_loader()
        assert loader1 is loader2, "Same actions_root should return the same ActionLoader instance"

    def test_different_keys_return_different_instances(self, tmp_path):
        """get_action_loader returns distinct instances for different actions_root values."""
        loader_default = get_action_loader()
        loader_custom = get_action_loader(actions_root=str(tmp_path))
        assert loader_default is not loader_custom

    def test_init_called_once_for_repeated_calls(self):
        """ActionLoader.__init__ must be invoked exactly once for N get_action_loader calls."""
        import statemachine_engine.core.action_loader as _al
        for _ in range(5):
            get_action_loader()
        assert len(_al._loader_cache) == 1, "Cache should contain exactly one entry for repeated calls with the same key"
        # Calling again should not grow the cache
        loader_a = get_action_loader()
        loader_b = get_action_loader()
        assert loader_a is loader_b
        assert len(_al._loader_cache) == 1

    def test_action_loader_initialized_log_is_debug(self, caplog):
        """'Action loader initialized' must be emitted at DEBUG, not INFO."""
        with caplog.at_level(logging.DEBUG, logger="statemachine_engine.core.action_loader"):
            ActionLoader()
        info_records = [
            r for r in caplog.records
            if r.levelno == logging.INFO and "Action loader initialized" in r.message
        ]
        assert info_records == [], (
            "'Action loader initialized' must not appear at INFO level; downgrade to DEBUG"
        )

    def test_load_failure_logs_full_traceback(self, caplog):
        """AC-06: ImportError during action load must use logger.exception (includes traceback)."""
        import importlib.util
        from unittest.mock import patch

        loader = ActionLoader()
        # Force a discovered action to fail on import by patching spec_from_file_location
        # to raise ImportError, then calling load_action_class on a custom-path action.
        # Simpler: inject a fake file path directly into _action_map.
        loader._action_map["_test_fail"] = "/nonexistent/path/to/_test_fail_action.py"

        with caplog.at_level(logging.ERROR, logger="statemachine_engine.core.action_loader"):
            result = loader.load_action_class("_test_fail")

        assert result is None
        error_records = [r for r in caplog.records if r.levelno == logging.ERROR]
        assert error_records, "An ERROR record must be emitted on import failure"
        # logger.exception attaches exc_info; verify traceback is present
        assert error_records[0].exc_info is not None, (
            "AC-06: logger.exception must be used so exc_info (traceback) is attached"
        )
