#-*-coding: utf-8-*-
#------------------------------import-------------------------------------------------
import os
import webbrowser as web
import platform
import subprocess
import requests
import socket
from requests.exceptions import Timeout
import cv2
import qrcode
from PIL import Image
from pyzbar.pyzbar import decode
from cryptography.fernet import Fernet
import sys
#----------------------------------------------------------------------------------
def found_abs(rel_path):
    return os.path.normcase(os.path.normpath(os.path.abspath(rel_path)))

def webopen(URL):
    web.open(URL) 

def play(path):
    abs_p = found_abs(path)
    if os.path.exists(abs_p):
        web.open(abs_p)
    else:
        return "file_not_found"

def sysdetect():
    return f"System:{platform.system()},Version:{platform.release()}"

def ofw(file_path,software_path):
    abs_fp = found_abs(file_path)
    if not os.path.isfile(abs_fp):
        return "not_exist"
    try:
        subprocess.Popen([software_path, abs_fp])
    except Exception as e:
        return "Failed"

def public_ip():
    headers = {"User-Agent":"Chrome"}
    APIs = ["https://api.ipify.org",
    "https://icanhazip.com",
    "https://api.ip.sb/ip"]
    for API in APIs:
        try:  
            return requests.get(API,headers=headers,timeout=10).text.strip().replace('\n','')
        except Timeout:  
            continue
        except:
            return "Failed"
    return "Failed"

def lan_ip():
    DNS_servers = ["114.114.114.114","1.1.1.1","8.8.8.8"]
    Port = 53
    for DNS in DNS_servers:
            try:
                with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:
                    s.settimeout(5)
                    s.connect((DNS,Port))
                    return s.getsockname()[0]
            except:
                continue
    return "Failed"

def take_photo(save_path="photo.png"):
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        return "Cannot_open_cam"
    ret,frame = cap.read()
    if not ret:
        cap.release()
        return "Failed"
    abs_sp = found_abs(save_path)
    cv2.imwrite(abs_sp,frame)
    cap.release()
    return f"Saved"

def get_lat_lon():
    api = "https://ipinfo.io/json"
    try:
        data = requests.get(api,timeout=5).json()
        loc = data.get("loc")
        if loc:
            lat,lon = loc.split(',')
            return float(lat),float(lon)
        return "format_change"
    except:
        return "network_Error"

def close_task_pid(pid):
    result = os.system(f'taskkill /f /pid {pid}')
    if result != 0:
        return "Failed"

def gen_qrcode(content,save_path="qrcode.png",size=8,ver=3):
    if not isinstance(content,(str,int,float,bool)):
        try:
            content = str(content)
        except:
            return "Unknown_type"
    qr = qrcode.QRCode(version=ver,box_size=size,border=4)
    qr.add_data(str(content))
    qr.make(fit=True)
    img = qr.make_image(fill_color="black",back_color="white")
    abs_sp = found_abs(save_path)
    img.save(abs_sp)
    return "Done"

def de_qrcode(img_path):
    abs_ip = found_abs(img_path)
    if not os.path.exists(abs_ip):
        return "file_not_found"
    try:
        img = Image.open(abs_ip)
        data = decode(img)[0].data.decode("utf-8")
        return f"{data}"
    except:
        return "Cannot_parse"

def gen_key(save_path="secret.key"):
    abs_sp = found_abs(save_path)
    key = Fernet.generate_key()
    with open(abs_sp,"wb") as f:
        f.write(key)
        return "Done"

def enc_file(file_path,key_path="secret.key",encrypted_path=None):
    abs_fp = found_abs(file_path)
    abs_kp = found_abs(key_path)
    if not os.path.exists(abs_fp):
        return "file_not_found"
    if not os.path.exists(abs_kp):
        return "key_file_not_found"   
    with open(abs_kp,"rb") as kf:
        key = kf.read()
        cipher = Fernet(key)
    with open(abs_fp,"rb") as f:
        data = f.read()
    if encrypted_path is None:
        save_path = abs_fp + ".encrypted"
    else:
        save_path = found_abs(encrypted_path)
    with open(save_path,"wb")as ef:
        ef.write(cipher.encrypt(data))
    return "Saved"

def dec_file(encrypted_path,key_path="secret.key",decrypted_path=None):
    abs_ep = found_abs(encrypted_path)
    abs_kp = found_abs(key_path)
    if not os.path.exists(abs_ep):
        return "encrypted_file_not_found"
    if not os.path.exists(abs_kp):
        return "key_path_not_found"
    with open(abs_kp,"rb") as kf:
        key = kf.read()
        cipher = Fernet(key)
    with open(abs_ep,"rb") as ef:
        encrypted_data = ef.read()
    decrypted_data = cipher.decrypt(encrypted_data)
    if decrypted_path is None:
        save_path = abs_ep.replace(".encrypted","")
    else:
        save_path = found_abs(decrypted_path)
    with open(save_path,"wb") as df:
        df.write(decrypted_data)
    return "Done"

__dir__ = lambda: [k for k, v in globals().items() if (callable(v) and v.__module__ == __name__)]