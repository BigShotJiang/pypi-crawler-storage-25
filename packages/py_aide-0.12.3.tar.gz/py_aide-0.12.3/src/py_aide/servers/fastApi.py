"""
FastAPIServicePortal - FastAPI counterpart to ServicePortal (flask.py)

Faithfully ports every feature of the Flask ServicePortal to FastAPI:

- @endpoint decorator with full GatePipeline security (auth, CSRF, rate-limit,
  validation, idempotency, security-headers, user-tier, request-size)
- @on_event decorator for WebSocket events (holding-pen pattern, registered at
  startup — FastAPI native WebSockets, no Socket.IO / eventlet dependency)
- Auto-discovery of route modules from a configurable directory
- Shared TokenManager and MemoryStorage (imported from flask.py)
- on_crash / on_audit developer hooks
- Response tokenization via default_tokenized_fields
- endpoint_map.json generation
- /docs  — password-protected HTML portal (HTTP Basic Auth)
- /health — public JSON health-check
- /ws     — WebSocket upgrade endpoint (all events multiplexed through it)
- Standardised { status, log, data } response envelope

FastAPI differences from the Flask version (by design):
- async-native: handlers may be sync or async functions
- WebSocket uses FastAPI's own WebSocket class, not Socket.IO
- Dependency injection via FastAPI's Depends() is supported alongside @endpoint
- OpenAPI schema available at /openapi.json (FastAPI built-in)

Install requirements:
    pip install fastapi uvicorn[standard] python-multipart
"""

import os
import sys
import uuid
import inspect
import traceback
import json
import importlib.util
import logging
import asyncio
from dataclasses import dataclass, field as dc_field
from typing import Any, Callable, Dict, List, Optional, Union, get_args, get_origin, Annotated
import types
import time

# FastAPI deps
from fastapi import FastAPI, Request, Response, WebSocket, WebSocketDisconnect, HTTPException, Depends
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBasic, HTTPBasicCredentials
import secrets

from .gate import GatePipeline, GateConfig, RequestContext, AuthType
from ..tokens import TokenManager, TokenRegistry
from ..dates import DateUtils
from ..customTypes import Options
from ..enforcer import enforce_requirements

# Re-use MemoryStorage, CrashReport and AuditReport from the Flask module so nothing is duplicated
from .flask import MemoryStorage, CrashReport, AuditReport
from ..codes import generate_code, CodeType

logger = logging.getLogger(__name__)


# ============================================================================
# FASTAPI REQUEST SHIM
# A thin wrapper that makes a FastAPI Request look like a Flask request to
# GatePipeline, which was written against Flask's request API.
#
# Every attribute/method listed here was found by grepping gate.py for
# context.request.* — nothing is guessed.
# ============================================================================

class _CaseInsensitiveDict(dict):
    """
    A dict whose .get() and [] access are case-insensitive.
    Mirrors how Flask/Werkzeug's Headers object works.
    Gates call headers.get("Authorization"), headers.get("authorization"),
    headers.get("X-CSRF-Token"), etc. — all must resolve correctly.
    """
    def __init__(self, data: dict):
        # Store with lower-cased keys internally; preserve original for iteration
        super().__init__({k.lower(): v for k, v in data.items()})
        self._original = dict(data)

    def get(self, key: str, default: Any = None) -> Any:
        return super().get(key.lower(), default)

    def __getitem__(self, key: str) -> Any:
        return super().__getitem__(key.lower())

    def __contains__(self, key: object) -> bool:
        return super().__contains__(str(key).lower())


class _MultiDict(dict):
    """
    A dict that also supports .to_dict() and .items() — the two methods
    gates call on request.args and request.form.
    Flask's MultiDict has more features but these are the only two used.
    """
    def to_dict(self, flat: bool = True) -> dict:
        return dict(self)

    # .items() is already provided by dict — no override needed


class _FlaskLikeRequest:
    """
    Adapts a FastAPI Request to the subset of Flask's request API that
    GatePipeline and its gates actually use.

    Every attribute here was verified against gate.py grep results:
        context.request.headers.get(...)   → _CaseInsensitiveDict
        context.request.method             → str
        context.request.path               → str
        context.request.remote_addr        → str
        context.request.authorization      → object with .username / .password
        context.request.is_json            → bool
        context.request.get_json(silent)   → Any
        context.request.args               → _MultiDict (with .to_dict(), .items())
        context.request.form               → _MultiDict (with .to_dict(), .items())
        context.request.cookies            → dict
        context.request.content_length     → int  (used by RequestContext.__init__)
        context.request.user_agent         → str
        context.request.referrer           → str
        context.request.data               → bytes
    """

    def __init__(self, request: Request, body: bytes, json_body: Any, form_data: Optional[Dict] = None):
        self._request = request
        self._body = body
        self._json_body = json_body

        self.method = request.method.upper()
        self.path = request.url.path
        self.remote_addr = request.client.host if request.client else "unknown"

        # Case-insensitive headers (mirrors Flask/Werkzeug)
        self.headers = _CaseInsensitiveDict(dict(request.headers))

        # Query parameters and form — both support .to_dict() and .items()
        self.args = _MultiDict(dict(request.query_params))
        # Form data (populated by _process_request)
        self.form = _MultiDict(form_data or {})

        self.cookies = dict(request.cookies)
        self.content_length = int(request.headers.get("content-length", 0) or 0)
        self.user_agent = request.headers.get("user-agent", "")
        self.referrer = request.headers.get("referer", "")

        # JSON detection
        ct = request.headers.get("content-type", "")
        self.is_json = "application/json" in ct

        # HTTP Basic Auth shim — produces object with .username / .password
        self.authorization = self._parse_authorization()

    def _parse_authorization(self):
        """Parse HTTP Basic Auth header into a Flask-compatible auth object."""
        import base64
        auth_header = self.headers.get("authorization", "")
        if auth_header.lower().startswith("basic "):
            try:
                decoded = base64.b64decode(auth_header[6:]).decode()
                username, _, password = decoded.partition(":")
                return type("_BasicAuth", (), {"username": username, "password": password})()
            except Exception:
                pass
        return None

    def get_json(self, silent: bool = True) -> Any:
        """Return the pre-parsed JSON body (read once, cached on construction)."""
        return self._json_body

    @property
    def data(self) -> bytes:
        """Raw request body."""
        return self._body



# ============================================================================
# WEBSOCKET CONNECTION MANAGER
# A simple in-process connection tracker for the holding-pen event model.
# ============================================================================

class _WSConnectionManager:
    """Tracks active WebSocket connections."""

    def __init__(self):
        self._connections: Dict[str, WebSocket] = {}
        self._lock = asyncio.Lock()

    async def connect(self, sid: str, ws: WebSocket) -> None:
        await ws.accept()
        async with self._lock:
            self._connections[sid] = ws
        logger.debug("WebSocket connected: %s (total: %d)", sid, len(self._connections))

    async def disconnect(self, sid: str) -> None:
        async with self._lock:
            self._connections.pop(sid, None)
        logger.debug("WebSocket disconnected: %s (remaining: %d)", sid, len(self._connections))

    async def send(self, sid: str, event: str, data: Any) -> None:
        ws = self._connections.get(sid)
        if ws:
            try:
                await ws.send_json({"event": event, "data": data})
            except Exception as e:
                logger.error("Failed to send to %s: %s", sid, e)

    async def broadcast(self, event: str, data: Any) -> None:
        payload = {"event": event, "data": data}
        for sid, ws in list(self._connections.items()):
            try:
                await ws.send_json(payload)
            except Exception as e:
                logger.warning("Broadcast failed for %s: %s", sid, e)

    @property
    def active_count(self) -> int:
        return len(self._connections)


# ============================================================================
# FASTAPI SERVICE PORTAL
# ============================================================================

class FastAPIServicePortal:
    """
    FastAPIServicePortal — Unified framework for HTTP APIs and WebSocket
    real-time events, built on FastAPI.

    Mirrors every feature of the Flask ServicePortal:

        portal = FastAPIServicePortal()

        @portal.endpoint("/api/users", gate=GateConfig.public())
        def get_users():
            return {"status": True, "log": "ok", "data": [...]}

        portal.run(port=8000)

    WebSocket mode:

        portal = FastAPIServicePortal(enable_websocket=True)

        @portal.on_event("chat.message", auth_required=True)
        async def handle_chat(data, sid):
            return {"received": True}

        portal.run(port=8000, use_websockets=True)
    """

    def __init__(
        self,
        *,
        debug: bool = False,
        admin_creds: tuple[str, str] = ("admin", "change_me"),
        token_type: Options[str, ["bearer", "api_key", "token_payload"]] = "bearer",
        cors_origins: List[str] | None = None,
        storage_max_size: int = 10_000,
        default_tokenized_fields: List[str] | None = None,
        default_cookies: Dict[str, Dict] | None = None,
        enable_websocket: bool = False,
    ):
        """
        Args:
            debug: Enable debug mode (verbose errors in responses).
            admin_creds: (username, password) for /docs and metrics endpoints.
            token_type: Default token type for TokenManager.
            cors_origins: Allowed CORS origins. None → allow all (dev only).
            storage_max_size: Upper bound for MemoryStorage.
            default_tokenized_fields: Fields tokenized in every response.
            default_cookies: Cookies added to every response by default.
            enable_websocket: Whether to enable the @on_event WebSocket API.
        """
        self.debug = debug
        self.admin_creds = admin_creds
        self.default_cookies = default_cookies or {}
        self.default_tokenized_fields = default_tokenized_fields or []
        self._websocket_enabled = enable_websocket
        self._running = False

        # Endpoint registry: path → config dict (same shape as Flask version)
        self.registry: Dict[str, Dict] = {}

        # WebSocket event holding-pen (same pattern as Flask version)
        self._socket_events: List[Dict[str, Any]] = []

        # Connection manager (used at runtime by /ws endpoint)
        self._ws_manager = _WSConnectionManager()

        # Core service managers
        self._gate_storage = MemoryStorage(
            cleanup_interval=60,
            max_size=storage_max_size,
            enable_background_cleanup=True,
        )
        self.token_manager = TokenManager(default_type=token_type)
        self.gate_pipeline = GatePipeline(self.token_manager, self._gate_storage)

        # Developer extension hooks
        self._crash_handler: Optional[Callable] = None
        self._audit_logger: Optional[Callable] = None

        # Track caller file for route discovery
        self._is_main = self._check_is_main()

        # Build the FastAPI app
        self.app = FastAPI(
            title="FastAPIServicePortal",
            debug=debug,
            docs_url=None,   # We serve our own /docs
            redoc_url=None,
        )

        # Apply CORS
        self._apply_cors(cors_origins)
        
        logger.info(
            "FastAPIServicePortal initialized (debug=%s, websocket=%s)",
            debug, enable_websocket,
        )

    # ============================================================================
    # INTERNAL SETUP
    # ============================================================================

    def _check_is_main(self) -> bool:
        main_mod = sys.modules.get("__main__")
        if not main_mod or not hasattr(main_mod, "__file__"):
            return False
        self._caller_file = os.path.abspath(main_mod.__file__)
        return True

    def _apply_cors(self, cors_origins: List[str] | None) -> None:
        if cors_origins:
            self.app.add_middleware(
                CORSMiddleware,
                allow_origins=cors_origins,
                allow_credentials=True,
                allow_methods=["*"],
                allow_headers=["*"],
            )
        else:
            # Permissive dev CORS
            self.app.add_middleware(
                CORSMiddleware,
                allow_origins=["*"],
                allow_credentials=True,
                allow_methods=["*"],
                allow_headers=["*"],
            )
            if not self.debug:
                logger.warning(
                    "Using permissive CORS (allow all origins). "
                    "Pass cors_origins= for production."
                )

    def normalize_path(self, path: str) -> str:
        parts = [p for p in path.split("/") if p]
        return "/" + "/".join(parts)

    # ============================================================================
    # DEVELOPER HOOKS  (same API as Flask ServicePortal)
    # ============================================================================

    def on_crash(self, func: Callable[[Dict], None]) -> Callable:
        """Register a crash handler called on every uncaught exception."""
        self._crash_handler = func
        return func

    def on_audit(self, func: Callable[[dict], None]) -> Callable[[dict], None]:
        """
        Register a function to audit all API activity.
        
        The registered function will receive a single dictionary containing:
        - user_id: ID of the user (or "anonymous")
        - request_id: Unique identifier for the request
        - path: Request endpoint path
        - method: HTTP method (GET, POST. etc.)
        - ip: Client IP address
        - success: Boolean indicating if the request succeeded
        - timestamp: Date and time of the audit event
        - log: Developer-facing log message
        - error_code: Optional machine-readable error code
        - user_agent: Client's User-Agent string
        """
        self._audit_logger = func
        return func

    # ============================================================================
    # RESPONSE HELPERS
    # ============================================================================

    def _apply_tokenization(self, data: Any, fields: List[str]) -> Any:
        """Recursively tokenize the specified fields in response data."""
        if not fields or data is None:
            return data
        if isinstance(data, list):
            return [self._apply_tokenization(item, fields) for item in data]
        if isinstance(data, dict):
            result = {}
            for key, value in data.items():
                if key in fields:
                    result[key] = self.token_manager.mask_data(value)
                else:
                    result[key] = self._apply_tokenization(value, fields)
            return result
        return data

    def _build_response(
        self,
        handler_output: Dict,
        http_code: int = 200,
        gate: Optional[GateConfig] = None,
        ctx: Optional[RequestContext] = None,
        endpoint_cookies: Optional[Dict] = None,
    ) -> JSONResponse:
        """
        Build a standardised { status, log, data } JSON response —
        identical envelope to the Flask ServicePortal.
        """
        status = handler_output.get("status", False)
        log = handler_output.get("log", "")
        raw_data = handler_output.get("data")

        # 1. Symmetrical Auth Proxy: Handover session tokens automatically
        if status and isinstance(raw_data, dict) and gate:
            auth_key = gate.payload_auth_token_key
            if auth_key and auth_key in raw_data:
                val = raw_data[auth_key]
                if gate.auth_type == AuthType.TOKEN_PAYLOAD:
                    # REPLACE raw ID with the masked session token
                    raw_data[auth_key] = self.token_manager.create_session_token(val, token_type="token_payload")
                elif gate.auth_type == AuthType.BEARER:
                    # INJECT a sibling key for the Authorization Header
                    raw_data["bearer"] = self.token_manager.create_session_token(val, token_type="bearer")
                elif gate.auth_type == AuthType.API_KEY:
                    # INJECT a sibling key for the API Key header
                    raw_data["api_key"] = self.token_manager.create_session_token(val, token_type="api_key")

        # 2. Field-Level Data Tokenization
        if status and raw_data is not None:
            tokenize_fields = self.default_tokenized_fields
            if gate and gate.tokenized_fields is not None:
                tokenize_fields = gate.tokenized_fields
            processed_data = self._apply_tokenization(raw_data, tokenize_fields)
        else:
            processed_data = raw_data

        payload = {"status": status, "log": log, "data": processed_data}

        headers: Dict[str, str] = {}

        # Security headers from gate context
        if ctx and ctx.security_headers:
            headers.update(ctx.security_headers)

        # Cookies: global then endpoint-level (endpoint takes precedence)
        all_cookies = {**self.default_cookies}
        if endpoint_cookies:
            all_cookies.update(endpoint_cookies)

        response = JSONResponse(content=payload, status_code=http_code, headers=headers)

        for name, props in all_cookies.items():
            cookie_props = dict(props)
            value = cookie_props.pop("value", "")
            response.set_cookie(name, value, **cookie_props)

        return response

    def _trigger_audit(
        self,
        ctx: Optional[RequestContext],
        request: Request,
        success: bool,
        log_msg: str = "",
        error_code: Optional[str] = None,
    ) -> None:
        """
        Trigger the developer's audit logging function if registered.
        
        The logger receives a single dictionary containing full audit details.
        """
        if not self._audit_logger:
            return
        try:
            report = AuditReport(
                user_id=ctx.user.get("user_id") if ctx and ctx.user else "anonymous",
                request_id=ctx.request_id if ctx else "unknown",
                path=request.url.path,
                success=success,
                log=log_msg,
                error_code=error_code,
                ip=request.client.host if request.client else "unknown",
                method=request.method,
                user_agent=request.headers.get("user-agent", "")
            )
            self._audit_logger(report.as_dict())
        except Exception as e:
            logger.error("Audit logger failed: %s", e)

    # ============================================================================
    # WEBSOCKET EVENT DECORATOR  (holding-pen pattern, same as Flask)
    # ============================================================================

    def on_event(self, event_name: str, *, auth_required: Optional[bool] = None, auth_type: Optional[AuthType] = None, auth_token_key: Optional[str] = None):
        """
        Decorator to register a WebSocket event handler.

        Works identically to Flask ServicePortal.on_event().  Handlers are
        stored in a holding pen and bound to the /ws endpoint at startup.

        Args:
            event_name:   Name of the event clients will emit (e.g. 'chat.msg').
            auth_required: True / False / None (use security default).
            auth_type:     Specific token type for this event (e.g. "bearer", "token_payload").
            auth_token_key: Custom key name for the token in the message payload (defaults to "token").

        Handler signature:
            def handler(data: Any, sid: str) -> Any:
                ...
            # or async:
            async def handler(data: Any, sid: str) -> Any:
                ...
        """
        if not self._websocket_enabled:
            raise RuntimeError(
                "Cannot use @on_event when WebSocket is disabled. "
                "Set enable_websocket=True in FastAPIServicePortal constructor."
            )

        if auth_required is True and (auth_type is None or auth_token_key is None):
            raise ValueError(f"WebSocket event '{event_name}' requires authentication but either 'auth_type' or 'auth_token_key' is missing. Both must be explicitly provided.")

        if auth_type and auth_type not in AuthType.__members__.values():
            raise ValueError(f"Invalid auth_type '{auth_type}' for event '{event_name}'. Must be one of: {', '.join(AuthType.__members__.values())}")

        def decorator(func: Callable) -> Callable:
            self._socket_events.append({
                "event": event_name,
                "handler": func,
                "auth_required": auth_required,
                "auth_type": auth_type,
                "auth_token_key": auth_token_key,
                "doc": func.__doc__.strip() if func.__doc__ else "No description provided.",
            })
            if self.debug:
                logger.debug("WebSocket event stored: %s", event_name)
            return func

        return decorator

    def _get_type_display_name(self, annotation: Any) -> Any:
        """
        Recursively extract a human-readable display structure for a type annotation.
        Returns a string for simple types, and a dict/list for complex ones.
        """
        if annotation is inspect.Parameter.empty:
            return "Any"
            
        origin = get_origin(annotation)
        args = get_args(annotation)
        
        # 1. Annotated Types (usually for Defenition/Schema or Options)
        if origin is Annotated:
            base_type = args[0]
            metadata = args[1]
            
            # Check for nested schema (py_aide.structures.Definition)
            if hasattr(metadata, "schema") and isinstance(getattr(metadata, "schema"), dict):
                schema_dict = getattr(metadata, "schema")
                # RECURSIVE: Convert the schema keys/values to display names (as a plain dict)
                return {
                    k: self._get_type_display_name(v) 
                    for k, v in schema_dict.items()
                }
            
            # Check for Options
            if isinstance(metadata, str) and metadata.startswith("Options:"):
                return f"{self._get_type_display_name(base_type)} ({metadata})"
                
            return self._get_type_display_name(base_type)
            
        # 2. Union types (e.g. str | None)
        if origin is Union or (hasattr(types, "UnionType") and origin is types.UnionType):
            return "|".join(
                str(self._get_type_display_name(a)) if a is not type(None) else "None"
                for a in args
            )
            
        # 3. Lists and Dicts (Generic Aliases)
        if origin in (list, List):
            inner = self._get_type_display_name(args[0]) if args else "Any"
            return [inner] # Represent as a list
            
        if origin in (dict, Dict):
            if len(args) == 2:
                k = self._get_type_display_name(args[0])
                v = self._get_type_display_name(args[1])
                return {str(k): v}
            return "dict"
            
        # 4. Standard types or nested dicts discovered in schemas
        if isinstance(annotation, dict):
            # If the annotation ITSELF is a dict (nested schema), unwrap recursively
            return {k: self._get_type_display_name(v) for k, v in annotation.items()}
            
        return getattr(annotation, "__name__", str(annotation))

    # ============================================================================
    # HTTP ENDPOINT DECORATOR
    # ============================================================================

    def endpoint(
        self,
        path: str,
        /,
        *,
        gate: Optional[GateConfig] = None,
        group: str = "General",
        methods: Optional[List[str]] = None,
        cookies: Optional[Dict[str, Dict]] = None,
    ) -> Callable:
        """
        Decorator to register an HTTP API endpoint.

        Mirrors Flask ServicePortal.endpoint() exactly.

        Example:
            @portal.endpoint("/api/users", gate=GateConfig.public(), methods=["GET"])
            def get_users():
                return {"status": True, "log": "ok", "data": [...]}
        """
        clean_path = self.normalize_path(path)

        def decorator(func: Callable) -> Callable:
            try:
                enforced_func = enforce_requirements(func)
            except (AttributeError, ValueError, TypeError, SyntaxError) as e:
                logger.error("Endpoint '%s' failed enforcement: %s", clean_path, e)
                raise

            source_file = inspect.getfile(func)

            # Extract parameter metadata (same logic as Flask version)
            sig = inspect.signature(func)
            params_meta: Dict[str, Dict] = {}

            for name, param in sig.parameters.items():
                if name in ("self", "cls"):
                    continue

                type_obj = self._get_type_display_name(param.annotation)
                # Only perform the final stringification at the top level to avoid double-escaping
                if isinstance(type_obj, (dict, list)):
                    type_display = json.dumps(type_obj, indent=2)
                    if isinstance(type_obj, dict):
                        type_display = f"dict (schema):\n{type_display}"
                else:
                    type_display = str(type_obj)

                params_meta[name] = {
                    "required": param.default == inspect.Parameter.empty,
                    "default": (
                        param.default if param.default != inspect.Parameter.empty else "REQUIRED"
                    ),
                    "type": type_display,
                    "kind": param.kind,
                }

            gate_config = gate or GateConfig()
            gate_config.required_params = [
                n for n, m in params_meta.items() if m["required"]
            ]

            self.registry[clean_path] = {
                "handler": enforced_func,
                "source_file": source_file,
                "gate_config": gate_config,
                "group": group,
                "params": params_meta,
                "methods": methods or ["POST"],
                "doc": func.__doc__.strip() if func.__doc__ else "No description available.",
                "cookies": cookies or {},
            }

            return enforced_func

        return decorator

    # ============================================================================
    # REQUEST PROCESSING  (mirrors _add_flask_rule)
    # ============================================================================

    async def _process_request(
        self,
        request: Request,
        config: Dict,
    ) -> Response:
        """
        Full request processing pipeline for one registered endpoint:
        gate → handler → response.
        """
        # 1. PARSE FORM (Multipart or URL-encoded)
        form_data = {}
        ct = request.headers.get("content-type", "")
        if "application/x-www-form-urlencoded" in ct or "multipart/form-data" in ct:
            try:
                # FastAPI's request.form() is an async call
                form_res = await request.form()
                form_data = dict(form_res)
            except Exception:
                pass

        # 2. READ BODY (FastAPI doesn't cache it like Flask does)
        try:
            body = await request.body()
        except Exception:
            body = b""
        
        # 3. PARSE JSON
        try:
            json_body = json.loads(body) if body else None
        except Exception:
            json_body = None

        # 4. PATH PARAMETERS (Replacement for **url_vars signature trap)
        url_vars = dict(request.path_params)

        flask_req = _FlaskLikeRequest(request, body, json_body, form_data)
        ctx: Optional[RequestContext] = None

        try:
            # 1. GATE: security & validation
            gate_result = self.gate_pipeline.process(flask_req, config["gate_config"])
            ctx = gate_result.context

            if not gate_result.success:
                err = gate_result.error
                self._trigger_audit(ctx, request, success=False,
                                    error_code=err.get("code"),
                                    log_msg=err.get("message"))
                return self._build_response(
                    {"status": False, "log": err.get("message"), "data": err},
                    http_code=400, ctx=ctx,
                    endpoint_cookies=config.get("cookies"),
                )

            # 2. HANDLER: build kwargs from validated data + URL vars
            incoming = ctx.validated_data.copy() if ctx.validated_data else {}
            incoming.update(url_vars)

            # Replace masked tokens with raw identities inside the handler's parameters
            raw_identity = ctx.get("session_identity_raw")
            if raw_identity is not None and config["gate_config"].payload_auth_token_key:
                incoming[config["gate_config"].payload_auth_token_key] = raw_identity

            # Inject fields unmasked by DataUnmaskingGate
            for key, val in ctx.gate_data.items():
                if key.startswith("unmasked_"):
                    field_name = key.replace("unmasked_", "")
                    incoming[field_name] = val

            # Build arguments based on function signature (respecting /, * and variadics)
            pos_args = []
            kw_args = {}
            for p_name, p_meta in config["params"].items():
                val = None
                if p_name in incoming:
                    val = incoming[p_name]
                elif p_meta["default"] != "REQUIRED":
                    val = p_meta["default"]
                else:
                    raise ValueError(f"Missing required parameter: {p_name}")
                
                p_kind = p_meta.get("kind")
                if p_kind == inspect.Parameter.POSITIONAL_ONLY:
                    pos_args.append(val)
                elif p_kind == inspect.Parameter.VAR_POSITIONAL:
                    if isinstance(val, (list, tuple)):
                        pos_args.extend(val)
                elif p_kind == inspect.Parameter.VAR_KEYWORD:
                    if isinstance(val, dict):
                        kw_args.update(val)
                else:
                    # Default: treat as a keyword-accessible argument (POSITIONAL_OR_KEYWORD or KEYWORD_ONLY)
                    kw_args[p_name] = val

            handler = config["handler"]
            if asyncio.iscoroutinefunction(handler):
                result = await handler(*pos_args, **kw_args)
            else:
                result = handler(*pos_args, **kw_args)

            # 3. RESPONSE: standardise
            if hasattr(result, "to_dict") and hasattr(result, "status"):
                result = result.to_dict()

            if isinstance(result, dict) and "status" in result:
                self._trigger_audit(ctx, request, success=result.get("status", False),
                                    log_msg=result.get("log", ""))
                return self._build_response(
                    result,
                    http_code=200 if result.get("status", False) else 400,
                    gate=config["gate_config"], ctx=ctx,
                    endpoint_cookies=config.get("cookies"),
                )

            self._trigger_audit(ctx, request, success=True)
            return self._build_response(
                {"status": True, "log": "Success", "data": result},
                http_code=200,
                gate=config["gate_config"], ctx=ctx,
                endpoint_cookies=config.get("cookies"),
            )

        except Exception as e:
            # 4. CRASH HANDLER
            error_id = f"ERR-{uuid.uuid4().hex[:8].upper()}"
            report = CrashReport(
                error_id=error_id,
                exception=e,
                traceback_str=traceback.format_exc(),
                request_path=request.url.path,
                user_id=ctx.user.get("user_id") if ctx and ctx.user else None,
                request_data=ctx.validated_data if ctx else None,
            )

            if self._crash_handler:
                try:
                    self._crash_handler(report.as_dict())
                except Exception as hook_error:
                    logger.error("Crash handler failed: %s", hook_error)

            self._trigger_audit(ctx, request, success=False,
                                error_code=f"CRASH:{error_id}", log_msg=str(e))

            error_msg = f"Internal server error: {error_id}"
            if self.debug:
                error_msg = f"(Error ID: {error_id}):: please contact system admin!"

            return self._build_response(
                {"status": False, "log": error_msg, "data": {}},
                http_code=500, ctx=ctx,
                endpoint_cookies=config.get("cookies"),
            )

    # ============================================================================
    # ROUTE BINDING
    # ============================================================================

    def _bind_routes(self) -> None:
        """
        Register all endpoints in self.registry with FastAPI, plus
        the built-in /docs, /health, and (optionally) /ws routes.
        """
        # /docs — Basic-Auth protected HTML portal
        @self.app.get("/docs", response_class=HTMLResponse, include_in_schema=False)
        async def docs_page(request: Request):
            auth_header = request.headers.get("authorization", "")
            if not auth_header.lower().startswith("basic "):
                return Response(
                    "Unauthorized", status_code=401,
                    headers={"WWW-Authenticate": 'Basic realm="Login Required"'},
                )
            import base64
            try:
                decoded = base64.b64decode(auth_header[6:]).decode()
                username, _, password = decoded.partition(":")
            except Exception:
                username, password = "", ""

            if not (
                secrets.compare_digest(username, self.admin_creds[0])
                and secrets.compare_digest(password, self.admin_creds[1])
            ):
                return Response(
                    "Unauthorized", status_code=401,
                    headers={"WWW-Authenticate": 'Basic realm="Login Required"'},
                )
            return HTMLResponse(content=self._build_docs_html())

        # /health — public JSON health-check
        @self.app.get("/health", include_in_schema=False)
        async def health():
            storage_info = self._gate_storage.info()
            return {
                "status": "healthy",
                "service": "FastAPIServicePortal",
                "timestamp": DateUtils.current_timestamp(),
                "endpoints_registered": len(self.registry),
                "websocket_events": len(self._socket_events) if self._websocket_enabled else 0,
                "storage": storage_info,
            }

        # Dynamic HTTP endpoints from self.registry
        for path, config in self.registry.items():
            self.gate_pipeline.verify_integrity(config["gate_config"])
            self._add_fastapi_route(path, config)

        # WebSocket upgrade endpoint
        if self._websocket_enabled:
            self._register_websocket_endpoint()

    def _add_fastapi_route(self, path: str, config: Dict) -> None:
        """Register one endpoint with FastAPI's router."""
        http_methods = [m.upper() for m in config["methods"]] + ["OPTIONS"]
        portal_ref = self   # capture for closure

        async def view_func(request: Request):
            # CORS preflight
            if request.method.upper() == "OPTIONS":
                return Response(status_code=204)
            return await portal_ref._process_request(request, config)

        # FastAPI needs a unique function name per route
        view_func.__name__ = f"route_{path.replace('/', '_').strip('_')}"

        self.app.add_api_route(
            path=path,
            endpoint=view_func,
            methods=http_methods,
        )

    def _register_websocket_endpoint(self) -> None:
        """
        Register the /ws WebSocket endpoint.

        Protocol:
            Client sends: { "event": "<name>", "data": <payload> }
            Server replies: { "event": "<name>_response", "data": <result> }
                         or { "event": "error", "data": { "error": "...", "event": "..." } }

        Auth: if an event has auth_required=True, the client MUST provide
        the active session token inside the JSON payload under the key "token"
        or "bearer" for that specific event.
        """
        event_map: Dict[str, Dict] = {
            ev["event"]: ev for ev in self._socket_events
        }
        portal_ref = self

        @self.app.websocket("/ws")
        async def ws_endpoint(websocket: WebSocket):
            sid = generate_code(32, xterSet=CodeType.ALPHANUMERIC)
            await portal_ref._ws_manager.connect(sid, websocket)

            try:
                while True:
                    raw = await websocket.receive_text()
                    try:
                        msg = json.loads(raw)
                    except json.JSONDecodeError:
                        await websocket.send_json(
                            {"event": "error", "data": {"error": "Invalid JSON"}}
                        )
                        continue

                    event_name = msg.get("event", "")
                    data = msg.get("data", {})
                    msg_id = msg.get("id") # Grab the unique ID if the client wants an acknowledgement
                    event_config = event_map.get(event_name)

                    if event_config is None:
                        await websocket.send_json({
                            "event": "error",
                            "data": {"error": f"Unknown event: {event_name}", "event": event_name},
                        })
                        continue

                    # -- INLINE MINI-GATE FOR AUTHENTICATION --
                    if event_config.get("auth_required"):
                        # Extract token using ONLY the explicitly specified key
                        target_key = event_config.get("auth_token_key")
                        token = data.pop(target_key, None) if target_key else None
                        
                        if not token:
                            await websocket.send_json({
                                "event": "error",
                                "data": {"error": "Unauthorized: Missing session token in payload", "event": event_name},
                            })
                            continue
                            
                        # Unlock the token using the global TokenManager
                        target_auth_type = event_config.get("auth_type")
                        auth_res = portal_ref.token_manager.unlock_session_token(token, token_type=target_auth_type)
                        
                        if not auth_res or not auth_res.is_active:
                            logger.warning("Rejected WebSocket event '%s' due to invalid/expired token.", event_name)
                            await websocket.send_json({
                                "event": "error",
                                "data": {"error": "Unauthorized: Invalid or expired session", "event": event_name},
                            })
                            continue
                            
                        # Assure Context: Inject the clean, true identity back into the payload
                        data["_user_id"] = auth_res.initial_value
                    # ----------------------------------------

                    try:
                        handler = event_config["handler"]
                        if asyncio.iscoroutinefunction(handler):
                            result = await handler(data, sid)
                        else:
                            result = handler(data, sid)

                        if hasattr(result, "to_dict") and hasattr(result, "status"):
                            result = result.to_dict()

                        if result is not None:
                            # Build the standard response
                            response = {
                                "event": f"{event_name}_response",
                                "data": result,
                            }
                            
                            # If an ID exists, we MUST echo it back for the client's 'ack' tracking
                            if msg_id:
                                response["id"] = msg_id
                                response["event"] = "ack"
                                response["success"] = True
                                
                            await websocket.send_json(response)

                    except Exception as e:
                        error_id = f"WS-ERR-{uuid.uuid4().hex[:8].upper()}"
                        logger.error("WebSocket handler error [%s] on '%s': %s",
                                     error_id, event_name, e)
                        await websocket.send_json({
                            "event": "error",
                            "data": {
                                "error": f"Handler error: {error_id}",
                                "event": event_name,
                            },
                        })

            except WebSocketDisconnect:
                pass
            finally:
                await portal_ref._ws_manager.disconnect(sid)

    # ============================================================================
    # AUTO-DISCOVERY  (same algorithm as Flask version)
    # ============================================================================

    def _auto_discover(self, abs_path: str) -> None:
        """
        Walk abs_path and import every .py file that doesn't start with '__'.
        During import, @endpoint and @on_event decorators register themselves.
        """
        if not os.path.exists(abs_path):
            logger.warning("Routes directory not found: %s", abs_path)
            return

        for root, _, files in os.walk(abs_path):
            for file in files:
                if not file.endswith(".py") or file.startswith("__"):
                    continue
                module_path = os.path.join(root, file)
                module_name = file[:-3]
                try:
                    spec = importlib.util.spec_from_file_location(module_name, module_path)
                    if spec and spec.loader:
                        module = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(module)
                        logger.debug("Loaded route module: %s", module_name)
                except SyntaxError as e:
                    logger.error("Syntax error in %s: %s", file, e)
                    raise
                except ImportError as e:
                    logger.error("Import error in %s: %s", file, e)
                    raise
                except Exception as e:
                    logger.error("Failed to load %s: %s", file, e)
                    raise

    # ============================================================================
    # ENDPOINT MAP GENERATION  (same as Flask version)
    # ============================================================================

    def _generate_endpoint_map(self, caller_dir: str) -> None:
        endpoint_map: Dict[str, Any] = {}
        for path, config in self.registry.items():
            try:
                relative_source = os.path.relpath(config["source_file"], caller_dir)
            except ValueError:
                relative_source = config["source_file"]
            endpoint_map[path] = {
                "file_location": relative_source,
                "group": config["group"],
                "methods": config["methods"],
            }

        map_path = os.path.join(caller_dir, "endpoint_map.json")
        try:
            with open(map_path, "w", encoding="utf-8") as f:
                json.dump(endpoint_map, f, indent=4, ensure_ascii=False)
            logger.info("Endpoint map generated at: %s", map_path)
        except IOError as e:
            logger.error("Failed to write endpoint map: %s", e)

    # ============================================================================
    # COMPONENT REGISTRATION
    # ============================================================================

    # ============================================================================
    # DOCUMENTATION (HTML)  — mirrors _build_docs_html / _build_http_docs_section
    # ============================================================================

    def _build_docs_html(self) -> str:
        http_section = self._build_http_docs_section()
        ws_section = self._build_websocket_docs_section() if self._websocket_enabled else ""

        return f"""
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>FastAPIServicePortal | Developer Docs</title>
            <style>
                :root {{
                    --header-bg: #37474f;
                    --group-bg: #455a64;
                    --accent: #066088;
                    --accent-light: #135f7e;
                    --text-main: #263238;
                    --code-bg: #263238;
                    --code-key: #9cdcfe;
                    --code-type: #4ec9b0;
                    --code-comment: #90a4ae;
                    --bg-canvas: #eceff1;
                    --ws-accent: #4a148c;
                }}

                body {{ font-family: 'Segoe UI', sans-serif; margin: 0; background: var(--bg-canvas); color: var(--text-main); height: 100vh; display: flex; flex-direction: column; }}

                .top-nav {{ background: var(--header-bg); color: white; padding: 12px 30px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 8px rgba(0,0,0,0.15); z-index: 10; }}
                #apiSearch {{ background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.3); border-radius: 20px; padding: 8px 20px; color: white; width: 250px; outline: none; transition: 0.3s; }}
                #apiSearch:focus {{ background: white; color: var(--text-main); width: 350px; }}

                .main-content {{ flex: 1; overflow-y: auto; padding: 30px; }}
                .container {{ width: 96%; max-width: 1400px; margin: 0 auto; }}

                .section-header {{ font-size: 1.5rem; margin: 30px 0 20px 0; padding-bottom: 10px; border-bottom: 2px solid var(--accent); }}
                .ws-header {{ border-bottom-color: var(--ws-accent); }}

                .method-tag {{ background: var(--accent); color: white; padding: 3px 10px; border-radius: 4px; font-size: 0.7rem; letter-spacing: 0.5px; }}
                .ws-tag {{ background: var(--ws-accent); }}

                .path-text {{ font-family: 'Consolas', monospace; font-size: 1.1rem; color: var(--accent-light); }}

                .gate-badge {{ background: #f1f5f9; border: 1px solid #e2e8f0; padding: 5px 12px; border-radius: 6px; font-size: 0.75rem; color: var(--group-bg); font-weight: 600; margin-right: 8px; margin-bottom: 8px; display: inline-block; }}
                .auth-badge {{ background: #fff3e0; border-color: #ff9800; color: #e65100; }}
                .public-badge {{ background: #e8f5e8; border-color: #4caf50; color: #1b5e20; }}

                .code-block {{ background: var(--code-bg); border-radius: 8px; padding: 20px; font-family: 'Consolas', 'Courier New', monospace; font-size: 0.95rem; overflow-x: auto; line-height: 1.7; box-shadow: inset 0 2px 4px rgba(0,0,0,0.1); color: #e0e0e0; }}
                .code-label {{ color: var(--group-bg); font-size: 0.8rem; margin-bottom: 10px; font-weight: bold; text-transform: uppercase; }}

                .indent {{ padding-left: 28px; display: block; border-left: 1px solid rgba(255,255,255,0.05); }}
                .key {{ color: var(--code-key); }}
                .type {{ color: var(--code-type); white-space: pre-wrap; vertical-align: top; }}
                .comment {{ color: var(--code-comment); font-style: italic; margin-left: 15px; }}

                details {{ background: white; margin-bottom: 12px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); overflow: hidden; }}
                summary {{ list-style: none; padding: 18px 25px; cursor: pointer; font-weight: 600; display: flex; align-items: center; justify-content: space-between; background: #fff; transition: background 0.2s; }}
                summary:hover {{ background: #f8f9fa; }}
                summary::-webkit-details-marker {{ display: none; }}

                .summary-left {{ display: flex; align-items: center; gap: 15px; flex-wrap: wrap; }}
                .card-content {{ padding: 0 25px 25px 25px; border-top: 1px solid #f1f1f1; }}
                .doc-text {{ color: #546e7a; line-height: 1.6; margin: 20px 0; }}

                .hidden {{ display: none !important; }}
            </style>
        </head>
        <body>
            <div class="top-nav">
                <div style="font-size: 1.2rem; font-weight: bold;">API <span>DOCUMENTATION</span></div>
                <input type="text" id="apiSearch" placeholder="Filter endpoints..." oninput="filterList()">
            </div>
            <div class="main-content">
                <div class="container">
                    {http_section}
                    {ws_section}
                </div>
            </div>
            <script>
                function filterList() {{
                    const query = document.getElementById('apiSearch').value.toLowerCase();
                    document.querySelectorAll('.api-item').forEach(item => {{
                        const text = item.getAttribute('data-search').toLowerCase();
                        item.classList.toggle('hidden', !text.includes(query));
                    }});
                    document.querySelectorAll('h2.section-header').forEach(header => {{
                        const section = header.closest('div');
                        if (section) {{
                            const visible = Array.from(section.querySelectorAll('.api-item')).some(i => !i.classList.contains('hidden'));
                            header.classList.toggle('hidden', !visible);
                        }}
                    }});
                }}
            </script>
        </body>
        </html>
        """

    def _build_http_docs_section(self) -> str:
        if not self.registry:
            return ""

        auth_descriptions = {
            AuthType.BEARER: "Bearer token required",
            AuthType.API_KEY: "API key required",
            AuthType.BASIC: "Basic authentication",
            AuthType.TOKEN_PAYLOAD: "Token payload",
            AuthType.NONE: "Public (no auth)",
        }

        items_html = ""
        for path, data in self.registry.items():
            gate = data["gate_config"]
            params = data.get("params", {})

            param_lines = ""
            for name, meta in params.items():
                req = (
                    '<span class="comment">required</span>'
                    if meta.get("required")
                    else '<span class="comment">optional</span>'
                )
                param_lines += f"""
                    <span class="indent">
                        <span class="key">{name}</span>: <span class="type">{meta.get('type')}</span> {req}
                        <span class="comment"># Default: {meta.get('default')}</span>
                    </span>"""

            body_display = (
                param_lines
                if param_lines
                else '<span class="indent"><span class="comment"># No parameters</span></span>'
            )

            items_html += f"""
            <details class="api-item" data-search="{path} {data.get('group')}">
                <summary>
                    <div class="summary-left">
                        <span class="method-tag">{" / ".join(data.get('methods', ['POST']))}</span>
                        <span class="path-text">{path}</span>
                    </div>
                    <div style="font-size: 0.75rem; color: #90a4ae;">{data.get('group')}</div>
                </summary>
                <div class="card-content">
                    <div class="doc-text">{data.get('doc', 'No description provided.')}</div>
                    <div>
                        <span class="gate-badge">AUTH: {auth_descriptions.get(gate.auth_type, 'Unknown')}</span>
                        <span class="gate-badge">RATE: {gate.rate_limit or 'OFF'}</span>
                        <span class="gate-badge">IDEMPOTENT: {gate.idempotent}</span>
                    </div>
                    <div class="code-label">Request Payload Structure</div>
                    <div class="code-block">
                        <span class="key">{{</span>
                        {body_display}
                        <span class="key">}}</span>
                    </div>
                </div>
            </details>
            """

        return f"""
            <h2 class="section-header">📡 HTTP REST API</h2>
            <p>{len(self.registry)} endpoints available</p>
            {items_html}
        """

    def _build_websocket_docs_section(self) -> str:
        if not self._socket_events:
            return ""

        items_html = ""
        for event_config in self._socket_events:
            event_name = event_config["event"]
            auth_required = event_config.get("auth_required")
            doc = event_config.get("doc", "No description provided.")

            if auth_required is True:
                auth_badge = '<span class="gate-badge auth-badge">🔒 REQUIRES AUTH</span>'
            elif auth_required is False:
                auth_badge = '<span class="gate-badge public-badge">🌍 PUBLIC</span>'
            else:
                auth_badge = '<span class="gate-badge">🔒 AUTH: DEFAULT</span>'

            items_html += f"""
            <details class="api-item" data-search="{event_name} websocket realtime">
                <summary>
                    <div class="summary-left">
                        <span class="method-tag ws-tag">EVENT</span>
                        <span class="path-text">{event_name}</span>
                    </div>
                    <div style="font-size: 0.75rem; color: #90a4ae;">WebSocket</div>
                </summary>
                <div class="card-content">
                    <div class="doc-text">{doc}</div>
                    <div>
                        {auth_badge}
                        <span class="gate-badge">📨 Request / Response</span>
                    </div>
                    <div class="code-label">Client Message Format</div>
                    <div class="code-block">
                        <span class="key">{{</span>
                        <span class="indent"><span class="key">"event"</span>: <span class="type">"{event_name}"</span>,</span>
                        <span class="indent"><span class="key">"data"</span>: <span class="type">{{ ...payload... }}</span></span>
                        <span class="key">}}</span>
                    </div>
                    <div class="code-label" style="margin-top: 15px;">JavaScript Example</div>
                    <div class="code-block">
                        <span class="comment">// Use a plain WebSocket or socket.io-client</span>
                        <span class="key">const</span> ws = <span class="key">new</span> <span class="type">WebSocket</span>(<span class="type">'ws://localhost:8000/ws'</span>);
                        <span class="indent">ws.send(<span class="type">JSON.stringify</span>({{ event: <span class="type">'{event_name}'</span>, data: {{ message: <span class="type">"Hello"</span> }} }}));</span>
                    </div>
                </div>
            </details>
            """

        return f"""
            <h2 class="section-header ws-header">⚡ WebSocket Real-Time Events</h2>
            <p>{len(self._socket_events)} events available</p>
            <p><small>WebSocket endpoint: <code>ws://localhost:8000/ws</code></small></p>
            {items_html}
        """

    # ============================================================================
    # SERVER STARTUP  (mirrors ServicePortal.run())
    # ============================================================================

    def run(
        self,
        port: int = 8000,
        routes_path: str = "./routes",
        host: str = "0.0.0.0",
    ) -> None:
        """
        Start the FastAPIServicePortal server.

        Unlike the Flask ServicePortal, there is NO separate use_websockets
        flag here.  FastAPI runs on uvicorn, which speaks both HTTP/1.1 and
        WebSocket natively over the same port in the same process.

        If enable_websocket=True was passed to __init__, the /ws endpoint is
        registered automatically and becomes available the moment the server
        starts — no extra flag, no mode switch, no monkey-patching.

        Args:
            port:        Port to listen on (default 8000).
            routes_path: Path (relative to the caller) for route auto-discovery.
            host:        Bind address (default 0.0.0.0).

        Raises:
            RuntimeError: If not called from the main module of the process.
            RuntimeError: If uvicorn is not installed.
        """
        if not self._is_main:
            raise RuntimeError(
                "FastAPIServicePortal must be started from the main module. "
                "Ensure your script is run directly, not imported."
            )

        try:
            import uvicorn
        except ImportError:
            raise RuntimeError(
                "uvicorn is required to run FastAPIServicePortal. "
                "Install it with: pip install uvicorn[standard]"
            )

        caller_dir = os.path.dirname(self._caller_file)
        abs_routes = os.path.abspath(os.path.join(caller_dir, routes_path))

        logger.info("FastAPIServicePortal starting | host=%s port=%d", host, port)

        # 1. Discover and import route modules (decorators register themselves)
        self._auto_discover(abs_routes)

        # 2. Write endpoint_map.json beside the caller
        self._generate_endpoint_map(caller_dir)

        # 3. Register all routes with FastAPI (HTTP + /docs + /health + /ws)
        #    /ws is only added if enable_websocket=True — but uvicorn doesn't
        #    need a flag; it handles whichever protocols the ASGI app declares.
        self._bind_routes()

        # 4. Start the MemoryStorage background janitor
        self._gate_storage.start()

        ws_info = f"ws://{host}:{port}/ws" if self._websocket_enabled else "disabled"
        logger.info(
            "Server ready | http=%s:%d | ws=%s | endpoints=%d | ws_events=%d | "
            "docs=http://%s:%d/docs | health=http://%s:%d/health",
            host, port, ws_info,
            len(self.registry), len(self._socket_events),
            host, port, host, port,
        )

        # 5. Run — uvicorn handles HTTP and WebSocket in the same event loop
        try:
            self._running = True
            uvicorn.run(self.app, host=host, port=port, log_level="info")
        except KeyboardInterrupt:
            logger.info("Shutting down (KeyboardInterrupt)...")
        finally:
            self._running = False
            self._gate_storage.stop()
            logger.info("FastAPIServicePortal stopped")
