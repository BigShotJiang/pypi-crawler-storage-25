# References

Official documentation referenced during project design.

## Azure Functions

- Azure Functions developer guide  
  https://learn.microsoft.com/en-us/azure/azure-functions/functions-reference

- Triggers and bindings concepts  
  https://learn.microsoft.com/en-us/azure/azure-functions/functions-triggers-bindings

- Register binding extensions  
  https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-register

- Extension bundles  
  https://learn.microsoft.com/en-us/azure/azure-functions/extension-bundles

- Timer trigger  
  https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-timer

- Error handling and retries  
  https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-error-pages

- Python developer guide  
  https://learn.microsoft.com/en-us/azure/azure-functions/functions-reference-python

- Python `FunctionApp` API  
  https://learn.microsoft.com/en-us/python/api/azure-functions/azure.functions.decorators.functionapp?view=azure-python

- Azure SQL bindings  
  https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-azure-sql

- Azure SQL trigger  
  https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-azure-sql-trigger

- Cosmos DB change feed with Azure Functions  
  https://learn.microsoft.com/en-us/azure/cosmos-db/change-feed-functions

- Service Bus bindings  
  https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-service-bus

## SQLAlchemy

- SQLAlchemy overview  
  https://docs.sqlalchemy.org/intro.html

- Dialects  
  https://docs.sqlalchemy.org/en/20/dialects/

- PostgreSQL dialect  
  https://docs.sqlalchemy.org/en/latest/dialects/postgresql.html

- MySQL / MariaDB dialect  
  https://docs.sqlalchemy.org/en/latest/dialects/mysql.html

- SQL Server dialect  
  https://docs.sqlalchemy.org/en/latest/dialects/mssql.html
