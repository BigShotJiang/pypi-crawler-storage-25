# Support Policy

## Supported Environment

* Python: 3.11 and above
* Runtime: Azure Functions (Python)

## Support Scope

This project is maintained by a single developer and support is provided on a
best-effort basis for the `azure-functions-db` package.

Supported requests:

* Bug reports with clear reproduction steps
* Feature requests aligned with the project scope
* Usage questions related to the package itself

Out of scope:

* Custom feature development
* Environment-specific debugging
* General Azure infrastructure consulting

## Support Channels

Preferred channels:

* GitHub Issues for bugs and feature requests
* GitHub Discussions for usage questions
* GitHub Security Advisories for security reports

Response targets:

* Initial response: within 3 business days on a best-effort basis
* Follow-up updates: weekly for active issues when applicable

## Deprecation Policy

* Deprecated behavior will be documented before removal
* Deprecations are announced at least one minor release in advance
* Removals happen in a later release when practical

## Security Issues

Report security issues privately when possible. See `SECURITY.md` for details.
