"""
Local host implementation.

Executes agent tasks in the current process using the agent's task loop.
"""

import os
from collections.abc import MutableMapping
from typing import TYPE_CHECKING, Any, Callable

from kvgit import Staged, VersionedKV

from agex.state.live import Live

from .base import Host

if TYPE_CHECKING:
    from agex.agent.base import BaseAgent
    from agex.state.config import StateConfig
    from agex.state.kv import KVStore


class Local(Host):
    """
    Local execution host.

    Runs agent tasks in the current process. This is the default host
    and provides the same behavior as calling tasks without any host configuration.

    For memory storage, each agent has isolated state. For shared state
    across agents, use disk storage with a shared path.
    """

    def __init__(self):
        # Per-agent session cache for memory-backed states
        # Key format: "{type}:{session}"
        self._session_cache: dict[str, MutableMapping[str, Any]] = {}

    def dump_config(self) -> dict[str, Any]:
        """Serialize local host configuration."""
        return {"provider": "local"}

    def validate_state(self, config: "StateConfig | None") -> None:
        """Validate that the state config is compatible with local execution."""
        if config is None:
            return  # Ephemeral is always valid

        if config.storage not in (None, "memory", "disk", "indexeddb"):
            raise ValueError(
                f"Local host does not support storage '{config.storage}'. "
                f"Supported: memory, disk, indexeddb"
            )

        if config.storage == "disk" and not config.path:
            raise ValueError("Disk storage requires 'path' parameter")

    def resolve_state(
        self, config: "StateConfig | None", session: str, fingerprint: str = ""
    ) -> MutableMapping[str, Any]:
        """Create or retrieve a State instance for this session."""
        from agex.state.kv import Disk, Memory

        # Ephemeral: fresh Live instance per call
        if config is None:
            return Live()

        # For memory storage, use session cache
        if config.storage == "memory":
            cache_key = f"{config.type}:{session}"
            if cache_key not in self._session_cache:
                self._session_cache[cache_key] = self._create_state(config, Memory())
            return self._session_cache[cache_key]

        # For disk storage, create with session-namespaced path
        if config.storage == "disk":
            # Cache disk-backed states to ensure singleton instance per session
            # This is critical for split-brain avoidance where multiple components
            # (e.g., task loop and agent.fs()) resolve the same state.
            cache_key = f"{config.type}:{session}:{config.path}"

            if cache_key not in self._session_cache:
                path = os.path.expanduser(config.path or "")
                session_path = os.path.join(path, "sessions", session)
                kv = Disk(session_path)
                self._session_cache[cache_key] = self._create_state(config, kv)

            return self._session_cache[cache_key]

        # For IndexedDB storage (Pyodide/browser)
        if config.storage == "indexeddb":
            db_name = (config.options or {}).get("db_name", "kvgit")
            cache_key = f"{config.type}:{session}:{db_name}"

            if cache_key not in self._session_cache:
                from kvgit.kv.indexeddb import IndexedDB

                kv = IndexedDB(db_name=db_name)
                self._session_cache[cache_key] = self._create_state(config, kv)

            return self._session_cache[cache_key]

        # Fallback for unspecified storage (treat as memory)
        cache_key = f"{config.type}:{session}"
        if cache_key not in self._session_cache:
            self._session_cache[cache_key] = self._create_state(config, Memory())
        return self._session_cache[cache_key]

    def _create_state(
        self, config: "StateConfig", kv: "KVStore"
    ) -> MutableMapping[str, Any]:
        """Create a state instance from config and KV store."""
        from agex.state import _agex_decoder, _agex_encoder

        from .base import apply_init_if_fresh

        if config.type == "versioned":
            versioned = VersionedKV(kv)
            state = Staged(versioned, encoder=_agex_encoder, decoder=_agex_decoder)
        elif config.type == "live":
            state = Live()
        else:  # ephemeral
            state = Live()

        # Apply init if provided and state is fresh
        apply_init_if_fresh(state, kv, config.init)

        return state

    def execute(
        self,
        agent: "BaseAgent",
        task_name: str,
        args: tuple,
        kwargs: dict,
        session: str,
        on_event: Callable[[Any], None] | None,
        on_token: Callable[[Any], None] | None,
    ) -> Any:
        """Execute the task locally using the agent's task loop."""
        # Resolve state from agent's config
        state = self.resolve_state(agent._state_config, session)

        # Get the registered task
        task_fn = agent._tasks.get(task_name)
        if task_fn is None:
            raise ValueError(f"Task '{task_name}' not found on agent '{agent.name}'")

        # Call the task directly - it handles the loop internally
        call_kwargs = dict(kwargs)
        call_kwargs["state"] = state
        if on_event is not None:
            call_kwargs["on_event"] = on_event
        if on_token is not None:
            call_kwargs["on_token"] = on_token

        return task_fn(*args, **call_kwargs)

    async def aexecute(
        self,
        agent: "BaseAgent",
        task_name: str,
        args: tuple,
        kwargs: dict,
        session: str,
        on_event: Callable[[Any], None] | None,
        on_token: Callable[[Any], None] | None,
    ) -> Any:
        """Execute the task locally using the agent's async task loop."""
        # Resolve state from agent's config
        state = self.resolve_state(agent._state_config, session)

        # Get the registered task
        task_fn = agent._tasks.get(task_name)
        if task_fn is None:
            raise ValueError(f"Task '{task_name}' not found on agent '{agent.name}'")

        # Call the task directly - it handles the loop internally
        call_kwargs = dict(kwargs)
        call_kwargs["state"] = state
        if on_event is not None:
            call_kwargs["on_event"] = on_event
        if on_token is not None:
            call_kwargs["on_token"] = on_token

        return await task_fn(*args, **call_kwargs)

    def state(
        self,
        config: "StateConfig | None",
        session: str,
        fingerprint: str = "",
    ) -> MutableMapping[str, Any]:
        """Get state for client-side access.

        For Local host, this is the same as resolve_state since we have
        direct access to the state.
        """
        return self.resolve_state(config, session, fingerprint)
