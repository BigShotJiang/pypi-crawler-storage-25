﻿"""
This project is made by Cloudberry Pi Foundations, any copyright violation can lead to severe acts and consequences.
Xperiential© Team
Owner: Cloudberry Pi Foundations
Type: Python Package
Version: v1.2.1
Output: GUI and TUI
For installation, enter:
```bash
pip install xperiential
```
"""
import os
import subprocess
import sys
import time
import turtle
from tkinter import *
import pyfiglet
from ascii_magic import AsciiArt

# Global Variables
window = None
root = None
menubox = Menu(window)
scrollbar = Scrollbar(window)
scrollarea = Text(window)

def typewriter(text="No Text To Print", duration=0.01):
    """Animate a typewriter effect on your screen for animated letters appearing one by one after each other."""
    for i in text:
        sys.stdout.flush()
        sys.stdout.write(i)
        time.sleep(duration)


def background_music(path=FileNotFoundError("The music file entered is not found")):
    """Play music in the background without opening music player."""
    subprocess.run(f'open {path}.mp3 -g', shell=True)


def square():
    """Draw the shape of a square using turtle graphics"""
    turtle.pendown()
    for i in range(4):
        turtle.forward(100)
        turtle.left(90)
    turtle.penup()
    time.sleep(5)


def triangle():
    """Draw the shape of a triangle using turtle graphics"""
    turtle.pendown()
    for i in range(3):
        turtle.forward(100)
        turtle.left(120)
    turtle.penup()
    time.sleep(5)


def circle(radius=10):
    """Draw the shape of a circle using the radius with the help of turtle graphics"""
    turtle.pendown()
    turtle.circle(radius)
    time.sleep(5)


def square_triangle():
    """Draw the collage of a square and a triangle merged together with black and white color effects."""
    turtle.pendown()
    turtle.begin_fill()
    for i in range(4):
        turtle.forward(100)
        turtle.left(90)
    turtle.goto(0, 0)
    for i in range(4):
        turtle.forward(100)
        turtle.left(120)
    turtle.end_fill()
    turtle.penup()
    time.sleep(5)


def triangle_circle(radius=100):
    """Draw the collage of a triangle and a circle merged together with black and white color effects."""
    turtle.goto(-100, 0)
    turtle.pendown()
    turtle.begin_fill()
    for i in range(4):
        turtle.forward(100)
        turtle.left(120)
    turtle.goto(0, 0)
    turtle.circle(radius)
    turtle.end_fill()
    turtle.penup()
    time.sleep(5)


def square_triangle_circle(radius=100):
    """Draw a collage of a triangle, circle and a square merged together with black and white color effects."""
    screen = turtle.Screen()
    t = turtle.Turtle()
    t.speed('fast')
    t.goto(-100, 0)
    t.pendown()
    t.begin_fill()
    for i in range(4):
        t.forward(100)
        t.left(120)
    t.goto(0, 0)
    t.circle(radius)
    t.goto(-50, 0)
    for i in range(4):
        t.forward(100)
        t.left(90)
    t.end_fill()
    t.penup()
    time.sleep(5)


def save_file(filename, content, silent=False, encoding="utf-8"):
    """Save a specific content such as text to a file."""
    with open(filename, 'w', encoding=encoding) as f:
        f.write(content)
        f.close()
    if not silent:
        print("Written content to file successfully!")
    else:
        pass


def read_file(filename, silent=False, encoding="utf-8"):
    """Read a specific content such as text inside a specific file."""
    with open(filename, 'r', encoding=encoding) as f:
        content = f.read()
        return content
    if silent:
        pass
    else:
        print("Read content to file successfully!")


def ascii_animate(text="Xperiential", duration=0.01):
    """Animate an ascii image by drawing text"""
    message = pyfiglet.figlet_format(text)
    for i in message:
        sys.stdout.flush()
        sys.stdout.write(i)
        time.sleep(duration)


def ascii_print(text="Xperiential"):
    """Print ascii image from text."""
    pyfiglet.figlet_format(text)


def asciimage(imagepath):
    """Print an ascii image from an image path."""
    my_art = AsciiArt.from_image(imagepath)
    my_art.to_terminal()


def animateasciiimage(imagepath="img.png", delay=0.03):
    """Animate an ascii image by drawing text with characters."""
    try:
        art = AsciiArt.from_image(imagepath)
    except Exception as e:
        print(f"Error loading image '{imagepath}': {e}")
        return

    # Generate ANSI-colored ASCII text
    ascii_colored = art.to_ascii()

    # Animate line-by-line (color-safe)
    for line in ascii_colored.splitlines():
        print(line)
        time.sleep(delay)


def window_button(window, text, command, pck=()):
    """Add a button to the window for executing a specific command."""
    Button(window, text=text, command=command).pack(pck)


def window_textinputbox(window, pck=(), font=("helvetica", 12)):
    """Add a Text Input Widget allowing multiple lines with indexing and input return function"""
    t_widget = (Text(window, font=font))
    t_widget.pack(pck)
    return t_widget.get("1.0", "end")


def window_inputbox(window, pck=(), font=("helvetica", 12)):
    """Add a Text Input Widget allowing only a single line with indexing and input return function"""
    tinput = (Entry(window, font=font))
    tinput.pack(pck)
    return tinput

def window_checkbox(window=None, command=None, text=None, pck=()):
    """Add a Checkbox widget for Tick marks or checklists which are helpful for `ToDo Planners` and similar applications."""
    Checkbutton(window, command=command, text=text).pack(pck)

def git_clone(url, download_path="~/Downloads"):
    """Clone a git repository and download it to a specified download path, the default download path is ~/Downloads"""
    os.system(f"cd {download_path}; git clone {url}")

def echo(text):
    """Print the given text to the console."""
    print(text)

def cat(file):
    """Print the contents of a file. Use the cat mechanism on the system to print and access the contents of a file."""
    os.system(f"cat {file}")

def http_localhost(url, source_path="~/Downloads"):
    """Run a localhost on a specified output url only on a local system"""
    os.system(f"cd {source_path}; python3 -m http.server {url}")

def window_label(window=None, text="Xperiential", pck=(), font=("helvetica", 12)):
    """Add a label to the window for a certain message or info to be displayed."""
    Label(window, text=text).pack(pck)

def window_scrollbar_default_area(window):
    """Initiate a default scrolling area for a scrollbar."""
    global scrollarea
    window.geometry("600x1000")
    scrollarea = Text(window)
    scrollarea.pack()

def window_scrollbar(window):
    scrollbar = Scrollbar(window, command=scrollarea.yview)
    scrollbar.pack(anchor='ne', side="right", fill="y")


def cli_handler():
    """Handles terminal commands with arguments"""
    args = sys.argv[1:]

    if not args:
        print("Usage: xperiential <command> [arguments]")
        return

    cmd = args[0]

    # Command Logic
    if cmd == "typewriter" and len(args) > 1:
        typewriter(args[1])
    elif cmd == "circle" and len(args) > 1:
        circle(int(args[1]))
    elif cmd == "square":
        square()
    elif cmd == "triangle":
        triangle()
    elif cmd == "ascii" and len(args) > 1:
        ascii_animate(args[1])
    elif cmd == "echo" and len(args) > 1:
        echo(args[1])
    elif cmd == "git-clone" and len(args) > 1:
        git_clone(args[1])
    else:
        print(f"Unknown command or missing arguments for: {cmd}")
