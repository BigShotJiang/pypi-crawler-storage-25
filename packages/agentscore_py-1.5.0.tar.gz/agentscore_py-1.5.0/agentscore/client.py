from __future__ import annotations

from importlib.metadata import version as _pkg_version
from typing import TYPE_CHECKING, Any

import httpx

from agentscore.errors import AgentScoreError

if TYPE_CHECKING:
    from agentscore.types import (
        AssessResponse,
        CredentialCreateResponse,
        CredentialListResponse,
        DecisionPolicy,
        ReputationResponse,
        SessionCreateResponse,
        SessionPollResponse,
    )


class AgentScore:
    """Client for the AgentScore trust and reputation API."""

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.agentscore.sh",
        timeout: float = 10.0,
    ):
        if not api_key:
            raise ValueError("AgentScore API key is required. Get one at https://agentscore.sh/sign-up")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._sync_client: httpx.Client | None = None
        self._async_client: httpx.AsyncClient | None = None

    def _headers(self) -> dict:
        return {
            "Accept": "application/json",
            "X-API-Key": self.api_key,
            "User-Agent": f"agentscore-py/{_pkg_version('agentscore-py')}",
        }

    def _get_sync_client(self) -> httpx.Client:
        if self._sync_client is None:
            self._sync_client = httpx.Client(
                base_url=self.base_url,
                headers=self._headers(),
                timeout=self.timeout,
            )
        return self._sync_client

    def _get_async_client(self) -> httpx.AsyncClient:
        if self._async_client is None:
            self._async_client = httpx.AsyncClient(
                base_url=self.base_url,
                headers=self._headers(),
                timeout=self.timeout,
            )
        return self._async_client

    def _handle_response(self, response: httpx.Response) -> dict:
        if response.status_code == 429:
            retry_after = response.headers.get("retry-after", "1")
            raise AgentScoreError(
                code="rate_limited",
                message=f"Rate limit exceeded. Retry after {retry_after}s",
                status_code=429,
            )
        if response.status_code >= 400:
            try:
                body = response.json()
                error = body.get("error", {})
                raise AgentScoreError(
                    code=error.get("code", "unknown_error"),
                    message=error.get("message", response.text),
                    status_code=response.status_code,
                )
            except ValueError as err:
                raise AgentScoreError(
                    code="unknown_error",
                    message=response.text,
                    status_code=response.status_code,
                ) from err
        try:
            return response.json()
        except ValueError as err:
            raise AgentScoreError(
                code="invalid_response",
                message="Server returned invalid JSON on success response",
                status_code=response.status_code,
            ) from err

    # --- Sync methods ---

    def get_reputation(self, address: str, chain: str | None = None) -> ReputationResponse:
        """Get cached reputation for an address (free, read-only). Optionally filter by chain."""
        params: dict[str, str] = {}
        if chain:
            params["chain"] = chain
        client = self._get_sync_client()
        response = client.get(f"/v1/reputation/{address}", params=params)
        return self._handle_response(response)

    def assess(
        self,
        address: str | None = None,
        chain: str | None = None,
        refresh: bool = False,
        policy: DecisionPolicy | None = None,
        operator_token: str | None = None,
    ) -> AssessResponse:
        """Assess a wallet or operator (paid, writes score on-the-fly)."""
        body: dict[str, Any] = {}
        if address:
            body["address"] = address
        if operator_token:
            body["operator_token"] = operator_token
        if chain:
            body["chain"] = chain
        if refresh:
            body["refresh"] = True
        if policy is not None:
            body["policy"] = dict(policy)
        client = self._get_sync_client()
        response = client.post("/v1/assess", json=body)
        return self._handle_response(response)

    def create_session(
        self,
        context: str | None = None,
        product_name: str | None = None,
    ) -> SessionCreateResponse:
        """Create an assessment session for deferred scoring."""
        body: dict[str, Any] = {}
        if context is not None:
            body["context"] = context
        if product_name is not None:
            body["product_name"] = product_name
        client = self._get_sync_client()
        response = client.post("/v1/sessions", json=body)
        return self._handle_response(response)

    def poll_session(self, session_id: str, poll_secret: str) -> SessionPollResponse:
        """Poll a session for its current status and result."""
        client = self._get_sync_client()
        response = client.get(
            f"/v1/sessions/{session_id}",
            headers={"X-Poll-Secret": poll_secret},
        )
        return self._handle_response(response)

    def create_credential(
        self,
        label: str | None = None,
        ttl_days: int | None = None,
    ) -> CredentialCreateResponse:
        """Create a new API credential."""
        body: dict[str, Any] = {}
        if label is not None:
            body["label"] = label
        if ttl_days is not None:
            body["ttl_days"] = ttl_days
        client = self._get_sync_client()
        response = client.post("/v1/credentials", json=body)
        return self._handle_response(response)

    def list_credentials(self) -> CredentialListResponse:
        """List all API credentials."""
        client = self._get_sync_client()
        response = client.get("/v1/credentials")
        return self._handle_response(response)

    def revoke_credential(self, id: str) -> dict:
        """Revoke an API credential by ID."""
        client = self._get_sync_client()
        response = client.delete(f"/v1/credentials/{id}")
        return self._handle_response(response)

    # --- Async methods ---

    async def aget_reputation(self, address: str, chain: str | None = None) -> ReputationResponse:
        """Get cached reputation for an address (free, read-only). Optionally filter by chain."""
        params: dict[str, str] = {}
        if chain:
            params["chain"] = chain
        client = self._get_async_client()
        response = await client.get(f"/v1/reputation/{address}", params=params)
        return self._handle_response(response)

    async def aassess(
        self,
        address: str | None = None,
        chain: str | None = None,
        refresh: bool = False,
        policy: DecisionPolicy | None = None,
        operator_token: str | None = None,
    ) -> AssessResponse:
        """Assess a wallet or operator (paid, writes score on-the-fly)."""
        body: dict[str, Any] = {}
        if address:
            body["address"] = address
        if operator_token:
            body["operator_token"] = operator_token
        if chain:
            body["chain"] = chain
        if refresh:
            body["refresh"] = True
        if policy is not None:
            body["policy"] = dict(policy)
        client = self._get_async_client()
        response = await client.post("/v1/assess", json=body)
        return self._handle_response(response)

    async def acreate_session(
        self,
        context: str | None = None,
        product_name: str | None = None,
    ) -> SessionCreateResponse:
        """Create an assessment session for deferred scoring."""
        body: dict[str, Any] = {}
        if context is not None:
            body["context"] = context
        if product_name is not None:
            body["product_name"] = product_name
        client = self._get_async_client()
        response = await client.post("/v1/sessions", json=body)
        return self._handle_response(response)

    async def apoll_session(self, session_id: str, poll_secret: str) -> SessionPollResponse:
        """Poll a session for its current status and result."""
        client = self._get_async_client()
        response = await client.get(
            f"/v1/sessions/{session_id}",
            headers={"X-Poll-Secret": poll_secret},
        )
        return self._handle_response(response)

    async def acreate_credential(
        self,
        label: str | None = None,
        ttl_days: int | None = None,
    ) -> CredentialCreateResponse:
        """Create a new API credential."""
        body: dict[str, Any] = {}
        if label is not None:
            body["label"] = label
        if ttl_days is not None:
            body["ttl_days"] = ttl_days
        client = self._get_async_client()
        response = await client.post("/v1/credentials", json=body)
        return self._handle_response(response)

    async def alist_credentials(self) -> CredentialListResponse:
        """List all API credentials."""
        client = self._get_async_client()
        response = await client.get("/v1/credentials")
        return self._handle_response(response)

    async def arevoke_credential(self, id: str) -> dict:
        """Revoke an API credential by ID."""
        client = self._get_async_client()
        response = await client.delete(f"/v1/credentials/{id}")
        return self._handle_response(response)

    def close(self):
        if self._sync_client:
            self._sync_client.close()
            self._sync_client = None

    async def aclose(self):
        if self._async_client:
            await self._async_client.aclose()
            self._async_client = None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.aclose()
