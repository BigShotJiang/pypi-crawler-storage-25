from __future__ import annotations

from bisect import bisect_left, bisect_right
from datetime import date, datetime, time, timedelta
from functools import lru_cache
from importlib.resources import files

MIN_DATE = date(2000, 1, 1)
MAX_DATE = date(2099, 12, 31)
SERIAL_BASE_DATE = date(1900, 1, 1)


def _today_date() -> date:
    return datetime.now().date()


def _to_datetime(value: date) -> datetime:
    return datetime.combine(value, time.min)


def _require_supported_date(value: date) -> date:
    if not (MIN_DATE <= value <= MAX_DATE):
        raise ValueError(
            f"Data fora do intervalo suportado pelo calendario ANBIMA: {value.isoformat()}"
        )
    return value


def _parse_date(value: str | date | datetime) -> date:
    if isinstance(value, datetime):
        return _require_supported_date(value.date())
    if isinstance(value, date):
        return _require_supported_date(value)
    if isinstance(value, str):
        return _require_supported_date(datetime.strptime(value, "%Y-%m-%d").date())
    raise TypeError("Use uma data em 'AAAA-MM-DD', datetime.date ou datetime.datetime.")


def _parse_year_month(value: str | date | datetime) -> tuple[int, int]:
    if isinstance(value, str):
        if len(value) == 7:
            parsed = datetime.strptime(value, "%Y-%m")
        else:
            parsed = datetime.strptime(value, "%Y-%m-%d")
        month_date = date(parsed.year, parsed.month, 1)
    elif isinstance(value, datetime):
        month_date = date(value.year, value.month, 1)
    elif isinstance(value, date):
        month_date = date(value.year, value.month, 1)
    else:
        raise TypeError("Use um valor em 'AAAA-MM', 'AAAA-MM-DD', datetime.date ou datetime.datetime.")

    _require_supported_date(month_date)
    return month_date.year, month_date.month


@lru_cache(maxsize=1)
def _blocked_dates() -> frozenset[date]:
    data_path = files("dubacen").joinpath("feriados_anbima.txt")
    blocked = {
        datetime.strptime(line.strip(), "%Y-%m-%d").date()
        for line in data_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    }
    return frozenset(blocked)


@lru_cache(maxsize=1)
def _business_days() -> tuple[date, ...]:
    blocked = _blocked_dates()
    days: list[date] = []
    current = MIN_DATE
    while current <= MAX_DATE:
        if current not in blocked:
            days.append(current)
        current += timedelta(days=1)
    return tuple(days)


def hoje(offset: int = 0) -> datetime:
    """Retorna D0 ou o deslocamento util a partir de D0.

    D0 e a data util mais recente em relacao ao dia atual. Se hoje cair em um
    feriado ou fim de semana, D0 sera o ultimo dia util anterior.
    """

    if not isinstance(offset, int):
        raise TypeError("O deslocamento deve ser um numero inteiro.")

    business_days = _business_days()
    reference = _today_date()
    index = bisect_right(business_days, reference) - 1
    if index < 0:
        raise ValueError("Nao ha D0 disponivel antes da data atual dentro do calendario suportado.")

    target = index + offset
    if target < 0 or target >= len(business_days):
        raise ValueError("Nao ha data util suficiente dentro do intervalo de 2000 a 2099.")
    return _to_datetime(business_days[target])


def hojenum(offset: int = 0) -> int:
    """Retorna o serial numerico da data de hoje(), onde 1900-01-01 = 1."""

    current = hoje(offset).date()
    return (current - SERIAL_BASE_DATE).days + 1


def qdu(ordem: int, ano_mes: str | date | datetime) -> datetime:
    """Retorna a data do n-esimo dia util do mes informado."""

    if not isinstance(ordem, int):
        raise TypeError("A ordem do dia util deve ser um numero inteiro.")
    if ordem <= 0:
        raise ValueError("A ordem do dia util deve ser maior que zero.")

    year, month = _parse_year_month(ano_mes)
    start = date(year, month, 1)
    end = date(year + (month == 12), 1 if month == 12 else month + 1, 1) - timedelta(days=1)

    business_days = _business_days()
    start_index = bisect_left(business_days, start)
    end_index = bisect_right(business_days, end)
    monthly_business_days = business_days[start_index:end_index]

    if ordem > len(monthly_business_days):
        raise ValueError(
            f"O mes {year:04d}-{month:02d} possui apenas {len(monthly_business_days)} dias uteis."
        )

    return _to_datetime(monthly_business_days[ordem - 1])


def qdtu(inicio: str | date | datetime, fim: str | date | datetime) -> int:
    """Retorna a quantidade de dias uteis entre duas datas, incluindo as pontas."""

    start = _parse_date(inicio)
    end = _parse_date(fim)
    business_days = _business_days()

    if start <= end:
        return bisect_right(business_days, end) - bisect_left(business_days, start)

    return -qdtu(end, start)


def qtdu(inicio: str | date | datetime, fim: str | date | datetime) -> int:
    """Alias para qdtu, para compatibilidade com a grafia usada na descricao."""

    return qdtu(inicio, fim)
