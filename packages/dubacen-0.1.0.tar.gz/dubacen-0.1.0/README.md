# dubacen

Biblioteca Python para calculos de dias uteis usando o calendario ANBIMA.

## O que a biblioteca faz

O pacote expõe funcoes simples para trabalhar com datas uteis:

- `hoje(offset=0)`: retorna o D0 util atual. Se hoje cair em fim de semana ou feriado, usa o ultimo dia util anterior.
- `hojenum(offset=0)`: retorna o serial numerico da data de `hoje()`, onde `1900-01-01 = 1`.
- `qdu(ordem, ano_mes)`: retorna o n-esimo dia util de um mes.
- `qdtu(inicio, fim)`: conta os dias uteis entre duas datas, incluindo as pontas.
- `qtdu(inicio, fim)`: alias de `qdtu`.

O calendario suportado cobre o intervalo de `2000-01-01` ate `2099-12-31`.

## Instalacao

No terminal, entre na pasta do projeto e rode:

```bash
python -m pip install .
```

Para instalar em modo editavel durante desenvolvimento:

```bash
python -m pip install -e .
```

## Uso rapido

```python
from dubacen import hoje, hojenum, qdu, qdtu, qtdu

print(hoje())               # datetime do D0 util
print(hojenum())            # serial numerico do D0 util
print(hoje(-1))             # dia util anterior ao D0
print(qdu(5, "2026-04"))    # 5o dia util de abril de 2026
print(qdtu("2026-04-01", "2026-04-30"))
print(qtdu("2026-04-01", "2026-04-30"))
```

## Entradas aceitas

As funcoes aceitam datas em um destes formatos:

- string no formato `AAAA-MM-DD`
- string no formato `AAAA-MM` para `qdu`
- `datetime.date`
- `datetime.datetime`

## Regras importantes

- `hoje()` retorna um `datetime` em vez de `date`.
- `qdtu()` conta datas inicial e final quando elas forem dias uteis.
- Se `inicio > fim`, `qdtu()` retorna o valor negativo equivalente.
- `qdu()` gera erro quando a ordem pedida for maior que a quantidade de dias uteis do mes.
- Datas fora do intervalo suportado geram `ValueError`.

## Exemplo mais completo

```python
from dubacen import qdu, qdtu

vencimento = qdu(10, "2026-06")
janela = qdtu("2026-06-01", "2026-06-15")

print("10o dia util:", vencimento)
print("Dias uteis na janela:", janela)
```

## Estrutura do pacote

- `core.py`: implementacao principal.
- `feriados_anbima.txt`: base de feriados embutida no pacote.
- `__init__.py`: API publica.
