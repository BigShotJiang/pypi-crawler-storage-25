from __future__ import annotations

import io
import re
import tokenize
from pathlib import Path

from .pack import load_pack


def _apply_postfix_syntax(source: str, mapping: dict) -> str:
    if "@@" not in source:
        return source

    kw_pattern = "|".join(re.escape(k) for k in sorted(mapping, key=len, reverse=True))
    postfix_re = re.compile(rf"(.+?)@@({kw_pattern})")

    lines = source.splitlines(keepends=True)
    result = []

    for line in lines:
        if "@@" not in line:
            result.append(line)
            continue

        stripped = line.lstrip()
        indent = line[: len(line) - len(stripped)]
        ending = "\n" if stripped.endswith("\n") else ""
        content = stripped.rstrip("\n")

        def _replace(m: re.Match) -> str:
            return f"{m.group(2)} {m.group(1).strip()}"

        result.append(indent + postfix_re.sub(_replace, content) + ending)

    return "".join(result)


def _apply_postfix_output(source: str, en_to_foreign: dict, postfix_english: set) -> str:
    postfix_foreign = {en_to_foreign[k] for k in postfix_english if k in en_to_foreign}

    lines = source.splitlines(keepends=True)
    result = []

    for line in lines:
        stripped = line.lstrip()
        indent = line[: len(line) - len(stripped)]
        ending = "\n" if line.endswith("\n") else ""
        content = stripped.rstrip("\n")
        matched = False

        for fkw in postfix_foreign:
            if content.startswith(fkw + " ") and content.endswith(":"):
                expr = content[len(fkw): -1].strip()
                result.append(f"{indent}{expr} @@{fkw}:{ending}")
                matched = True
                break

        if not matched:
            result.append(line)

    return "".join(result)


def _get_slice(source_lines: list[str], sr: int, sc: int, er: int, ec: int) -> str:
    """Extract text from source between two (row, col) positions (1-indexed rows)."""
    n = len(source_lines)
    if sr > n:
        return ""
    if sr == er:
        line = source_lines[sr - 1]
        return line[sc:min(ec, len(line))]
    parts = []
    parts.append(source_lines[sr - 1][sc:])
    for r in range(sr, er - 1):
        if r < n:
            parts.append(source_lines[r])
    if er <= n:
        parts.append(source_lines[er - 1][:ec])
    return "".join(parts)


def _swap_tokens(source: str, mapping: dict) -> str:
    """
    Swap NAME tokens while copying all inter-token text verbatim from source.
    This preserves original spacing exactly — no double newlines, no extra spaces.
    """
    source_lines = source.splitlines(keepends=True)
    tokens = list(tokenize.generate_tokens(io.StringIO(source).readline))

    result = []
    prev_end = (1, 0)

    for tok_type, tok_string, tok_start, tok_end, _ in tokens:
        if tok_type in (tokenize.ENDMARKER, tokenize.ENCODING):
            break

        s_row, s_col = tok_start

        # Copy original whitespace/newlines between tokens verbatim
        gap = _get_slice(source_lines, prev_end[0], prev_end[1], s_row, s_col)
        result.append(gap)

        # Swap or keep token
        if tok_type == tokenize.NAME and tok_string in mapping:
            result.append(mapping[tok_string])
        else:
            result.append(tok_string)

        prev_end = tok_end

    return "".join(result)


def transpile(source: str, lang_code: str) -> str:
    pack = load_pack(lang_code)

    mapping: dict[str, str] = {}
    mapping.update(pack["keywords"])
    mapping.update(pack["builtins"])
    mapping.update(pack["exceptions"])
    mapping.update(pack["stdlib"])

    source = _apply_postfix_syntax(source, mapping)
    return _swap_tokens(source, mapping)


def detranspile(source: str, lang_code: str, postfix: bool = False) -> str:
    pack = load_pack(lang_code)

    en_to_foreign: dict[str, str] = {}
    for section in ("keywords", "builtins", "exceptions", "stdlib"):
        for foreign, english in pack[section].items():
            en_to_foreign[english] = foreign

    output = _swap_tokens(source, en_to_foreign)

    if postfix:
        postfix_english = set(pack.get("postfix_keywords", ["if", "elif", "while"]))
        output = _apply_postfix_output(output, en_to_foreign, postfix_english)

    return output


def transpile_file(path: Path) -> str:
    lang_code = _detect_lang(path)
    source = path.read_text(encoding="utf-8")
    lang_code = _check_shebang(source, lang_code)
    return transpile(source, lang_code)


def detranspile_file(path: Path, lang_code: str, postfix: bool = False) -> str:
    source = path.read_text(encoding="utf-8")
    return detranspile(source, lang_code, postfix=postfix)


def run_transpiled(original_path: Path, transpiled: str) -> None:
    import linecache

    filename = str(original_path.resolve())
    original_lines = original_path.read_text(encoding="utf-8").splitlines(keepends=True)
    linecache.cache[filename] = (len(original_lines), None, original_lines, filename)

    code = compile(transpiled, filename, "exec")
    glob = {"__file__": filename, "__name__": "__main__"}
    exec(code, glob)


def _detect_lang(path: Path) -> str:
    suffixes = path.suffixes
    if len(suffixes) >= 2 and suffixes[-1] == ".py":
        return suffixes[-2].lstrip(".")
    raise ValueError(
        f"Cannot detect language from filename '{path.name}'. "
        "Expected format: script.<lang>.py (e.g. script.es.py)"
    )


def _check_shebang(source: str, default: str) -> str:
    first_line = source.splitlines()[0] if source else ""
    if first_line.startswith("# foreignthon:"):
        return first_line.split(":", 1)[1].strip()
    return default
