from __future__ import annotations

import sys
from pathlib import Path

import click

from . import __version__
from .errors import activate
from .transpiler import run_transpiled, transpile_file

CONTEXT_SETTINGS = dict(help_option_names=["-h", "--help"])


@click.group(context_settings=CONTEXT_SETTINGS)
@click.version_option(__version__, prog_name="fpy")
def main():
    """ForeignThon — write Python in any language."""
    pass


@main.command(context_settings=CONTEXT_SETTINGS)
@click.argument("file", type=click.Path(exists=True, path_type=Path))
@click.option("--lang", "-l", default=None, help="Override language code (e.g. es, ta)")
@click.option("--keep", is_flag=True, help="Keep the compiled .py alongside the source")
def run(file: Path, lang: str | None, keep: bool):
    """Transpile and run a foreign-language Python file."""
    if lang:
        source = file.read_text(encoding="utf-8")
        if not source.startswith("# foreignthon:"):
            source = f"# foreignthon: {lang}\n" + source
            file.write_text(source, encoding="utf-8")

    detected_lang = lang or _lang_from_file(file)
    activate(detected_lang)

    transpiled = transpile_file(file)

    if keep:
        out_path = file.with_suffix("").with_suffix(".compiled.py")
        out_path.write_text(transpiled, encoding="utf-8")
        click.echo(f"Compiled: {out_path}")

    run_transpiled(file, transpiled)


@main.command(context_settings=CONTEXT_SETTINGS)
@click.argument("file", type=click.Path(exists=True, path_type=Path))
@click.option(
    "--output", "-o", default=None,
    help="Output file or directory. Defaults to same directory as source."
)
def compile(file: Path, output: str | None):
    """
    Transpile a foreign-language file to standard Python.

    Output can be a file path or a directory:

    \b
    fpy compile script.es.py              # → script.compiled.py
    fpy compile script.es.py -o out/      # → out/script.compiled.py
    fpy compile script.es.py -o out.py    # → out.py
    """
    transpiled = transpile_file(file)

    if output is None:
        out_path = file.with_suffix("").with_suffix(".compiled.py")
    else:
        out = Path(output)
        if out.is_dir() or str(output).endswith("/"):
            out.mkdir(parents=True, exist_ok=True)
            out_path = out / file.with_suffix("").with_suffix(".compiled.py").name
        else:
            out_path = out

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(transpiled, encoding="utf-8")
    click.echo(f"Compiled: {out_path}")


@main.command(context_settings=CONTEXT_SETTINGS)
@click.argument("file", type=click.Path(exists=True, path_type=Path))
def check(file: Path):
    """Validate a foreign-language file without running it."""
    import ast

    try:
        transpiled = transpile_file(file)
        ast.parse(transpiled)
        click.echo(f"✓ {file.name} looks good.")
    except SyntaxError as e:
        click.echo(f"✗ Syntax error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"✗ {e}", err=True)
        sys.exit(1)


@main.command("pack", context_settings=CONTEXT_SETTINGS)
@click.argument("json_file", type=click.Path(exists=True, path_type=Path))
def validate_pack(json_file: Path):
    """Validate a language pack JSON file."""
    import json

    from .pack import REQUIRED_SECTIONS

    with open(json_file, encoding="utf-8") as f:
        data = json.load(f)

    missing = REQUIRED_SECTIONS - data.keys()
    if missing:
        click.echo(f"✗ Missing sections: {missing}", err=True)
        sys.exit(1)

    click.echo(f"✓ Pack '{data['meta']['name']}' is valid.")



@main.command(context_settings=CONTEXT_SETTINGS)
@click.argument("file", type=click.Path(exists=True, path_type=Path))
@click.option("--lang", "-l", required=True, help="Target language code (e.g. es, ta)")
@click.option("--postfix", is_flag=True, help="Use @@ postfix style for if/elif/while")
@click.option("--output", "-o", default=None, help="Output file or directory")
def decompile(file: Path, lang: str, postfix: bool, output: str | None):
    """
    Convert standard Python back to a foreign language.

    Keywords and builtins are translated. Variable names are untouched.

    \b
    fpy decompile script.py --lang es
    fpy decompile script.py --lang ta --postfix
    fpy decompile script.py --lang es -o out/
    """
    from .transpiler import detranspile_file

    result = detranspile_file(file, lang, postfix=postfix)

    ext = f".{lang}.py"

    if output is None:
        stem = file.stem if not file.stem.endswith(f".{lang}") else file.stem
        out_path = file.with_name(stem + ext)
    else:
        out = Path(output)
        if out.is_dir() or str(output).endswith("/"):
            out.mkdir(parents=True, exist_ok=True)
            out_path = out / (file.stem + ext)
        else:
            out_path = out

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(result, encoding="utf-8")
    click.echo(f"Decompiled: {out_path}")


def _lang_from_file(path: Path) -> str:
    suffixes = path.suffixes
    if len(suffixes) >= 2 and suffixes[-1] == ".py":
        return suffixes[-2].lstrip(".")
    return "en"

