# SPDX-FileCopyrightText: 2025 Knitli Inc.
# SPDX-FileContributor: Adam Poulemanos <adam@knit.li>
#
# SPDX-License-Identifier: MIT OR Apache-2.0

"""Cohere reranking model capabilities."""

from __future__ import annotations

from codeweaver.core import dependency_provider
from codeweaver.providers.reranking.capabilities.base import RerankingModelCapabilities


class AmazonRerankingCapabilities(RerankingModelCapabilities):
    """Capabilities for Amazon reranking models."""


@dependency_provider(AmazonRerankingCapabilities, scope="singleton", collection=True)
def get_amazon_reranking_capabilities() -> tuple[AmazonRerankingCapabilities, ...]:
    """Get the capabilities of the Amazon reranking model."""
    from codeweaver.core import Provider

    return (
        AmazonRerankingCapabilities.model_validate({
            "name": "amazon.rerank-v1:0",
            "provider": Provider.BEDROCK,
            "max_input": 4096,  # we actually have no idea, Amazon doesn't provide any info on model capabilities and limits
            "supports_custom_prompt": False,
            # we'll default to tiktoken/o200k_base because Amazon doesn't provide any info on tokenizer
            "tokenizer": "tiktoken",
            "tokenizer_model": "o200k_base",
        }),
    )


__all__ = ("AmazonRerankingCapabilities", "get_amazon_reranking_capabilities")
