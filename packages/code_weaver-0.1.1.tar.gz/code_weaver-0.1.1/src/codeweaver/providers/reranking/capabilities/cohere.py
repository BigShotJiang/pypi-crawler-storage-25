# SPDX-FileCopyrightText: 2025 Knitli Inc.
# SPDX-FileContributor: Adam Poulemanos <adam@knit.li>
#
# SPDX-License-Identifier: MIT OR Apache-2.0

"""Cohere reranking model capabilities."""

from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING, cast

from codeweaver_tokenizers import get_tokenizer
from pydantic import NonNegativeInt

from codeweaver.core import dependency_provider
from codeweaver.providers.reranking.capabilities.base import RerankingModelCapabilities


if TYPE_CHECKING:
    from codeweaver.core import CodeChunk
    from codeweaver.providers.reranking.capabilities.types import PartialRerankingCapabilitiesDict


class CohereRerankingCapabilities(RerankingModelCapabilities):
    """Capabilities for Cohere reranking models."""


def cohere_max_input(chunks: Sequence[CodeChunk], query: str) -> tuple[bool, NonNegativeInt]:
    """Determine the maximum input length for the Cohere model."""
    tokenizer = get_tokenizer("tokenizers", "Cohere/rerank-v3.5")
    sizes = [
        tokenizer.estimate(cast(str, chunk.serialize_for_embedding())) + tokenizer.estimate(query)
        for chunk in chunks
    ]
    if all(size <= 4096 for size in sizes):
        return True, 4096
    return False, next(i - 1 for i, size in enumerate(sizes) if size > 4096)


def _get_common_capabilities() -> PartialRerankingCapabilitiesDict:
    """
    Get the common capabilities for Cohere models.
    """
    return {
        "max_input": None,  # Cohere uses dynamic limit checking via cohere_max_input function
        "context_window": 4096,
        "supports_custom_prompt": False,
        "tokenizer": "tokenizers",
    }


def _get_v4_capabilities() -> PartialRerankingCapabilitiesDict:
    """
    Get the capabilities for Cohere v4 models.
    """
    base_caps = _get_common_capabilities()
    return {**base_caps, "context_window": 32_764}


@dependency_provider(CohereRerankingCapabilities, scope="singleton", collection=True)
def get_cohere_reranking_capabilities() -> tuple[CohereRerankingCapabilities, ...]:
    """Get the capabilities of the Cohere reranking model."""
    from codeweaver.core import Provider

    base_capabilities = _get_common_capabilities()
    capabilities: list[CohereRerankingCapabilities] = [
        CohereRerankingCapabilities.model_validate({
            **base_capabilities,
            "name": model,
            "provider": Provider.COHERE,
            "tokenizer_model": f"Cohere/{model}",
        })
        for model in (
            "rerank-v3.5",
            "rerank-english-v3.0",
            "rerank-multilingual-v3.0",
            "rerank-v4.0-pro",
            "rerank-v4.0-fast",
        )
    ]
    return (
        *capabilities,
        CohereRerankingCapabilities.model_validate({
            **base_capabilities,
            "name": "rerank-v3-5:0",
            "provider": Provider.BEDROCK,
            "tokenizer_model": "Cohere/rerank-v3.5",
        }),
    )


__all__ = ("CohereRerankingCapabilities", "cohere_max_input", "get_cohere_reranking_capabilities")
