# SPDX-FileCopyrightText: 2025 Knitli Inc.
# SPDX-FileContributor: Adam Poulemanos <adam@knit.li>
#
# SPDX-License-Identifier: MIT OR Apache-2.0
"""Abstract provider interfaces for embeddings and vector storage."""

from __future__ import annotations

import logging
import threading
import time

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, ClassVar, Literal, cast

import httpx

from pydantic import UUID7, ConfigDict, PrivateAttr
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from codeweaver.core import BasedModel, CodeChunk, Provider, StrategizedQuery
from codeweaver.core.constants import (
    BASE_RETRYABLE_EXCEPTIONS,
    DEFAULT_OPEN_BREAKER_DURATION,
    MAX_RETRY_ATTEMPTS,
    ZERO,
)
from codeweaver.core.types import ModelNameT, SearchResult
from codeweaver.providers import EmbeddingModelCapabilities
from codeweaver.providers.config import VectorStoreProviderSettings
from codeweaver.providers.exceptions import CircuitBreakerOpenError
from codeweaver.providers.types import CircuitBreakerState, EmbeddingCapabilityGroup
from codeweaver.providers.vector_stores.search import Filter


# Common retryable exceptions for vector store operations
# Include httpcore and qdrant-specific exceptions that indicate transient network issues
try:
    import httpcore
    import qdrant_client.http.exceptions

    RETRYABLE_EXCEPTIONS = (
        *BASE_RETRYABLE_EXCEPTIONS,
        httpx.TimeoutException,
        httpcore.ReadError,
        httpcore.WriteError,
        httpcore.ConnectError,
        httpcore.PoolTimeout,
        qdrant_client.http.exceptions.ResponseHandlingException,
    )
except ImportError:
    # Fallback if httpcore or qdrant_client not available
    RETRYABLE_EXCEPTIONS = (*BASE_RETRYABLE_EXCEPTIONS, httpx.TimeoutException)


logger = logging.getLogger(__name__)

type MixedQueryInput = (
    list[float] | list[int] | dict[Literal["dense", "sparse"], list[float] | list[int] | Any]
)


# Lock for thread-safe initialization of class-level embedding capabilities
_embedding_caps_lock = threading.Lock()


class VectorStoreProvider[VectorStoreClient](BasedModel, ABC):
    """Abstract interface for vector storage providers."""

    model_config = BasedModel.model_config | ConfigDict(extra="allow")

    config: VectorStoreProviderSettings
    caps: EmbeddingCapabilityGroup
    client: VectorStoreClient

    _known_collections: set[str] = PrivateAttr(default_factory=set)

    _provider: ClassVar[Provider] = Provider.NOT_SET

    # Circuit breaker state tracking
    _circuit_state: CircuitBreakerState = CircuitBreakerState.CLOSED
    _failure_count: int = ZERO
    _last_failure_time: float | None = None
    _circuit_open_duration: float = DEFAULT_OPEN_BREAKER_DURATION

    def __init__(
        self,
        client: VectorStoreClient,
        config: VectorStoreProviderSettings,
        caps: EmbeddingCapabilityGroup,
        **kwargs: Any,
    ) -> None:
        """Initialize the vector store provider with embedding capabilities."""
        # Pass parameters to Pydantic's __init__
        init_data: dict[str, Any] = {**kwargs}
        if config is not None:
            init_data["config"] = config
        if client is not None:
            init_data["client"] = client
        if caps is not None:
            init_data["caps"] = caps

        object.__setattr__(self, "caps", caps)
        object.__setattr__(self, "client", client)
        object.__setattr__(self, "config", config)

        super().__init__(**init_data)

        # Initialize circuit breaker state
        self._circuit_state = CircuitBreakerState.CLOSED
        self._failure_count = ZERO
        self._last_failure_time = None

    async def _initialize(self) -> None:
        """Initialize the vector store provider.

        This method should be called after creating an instance to perform
        any async initialization. Override in subclasses for custom initialization.
        """

    @property
    def client(self) -> VectorStoreClient:
        """Returns the vector store client instance."""
        return cast(VectorStoreClient, self.client)

    @property
    def name(self) -> Provider:
        """
        The enum member representing the provider.
        """
        return type(self)._provider

    @property
    @abstractmethod
    def base_url(self) -> str | None:
        """The base URL for the provider's API, if applicable.

        Returns:
            Valid HTTP/HTTPS URL or None.
        """
        return None

    @property
    def collection(self) -> str | None:
        """Name of the currently configured collection.

        Returns:
            Collection name (alphanumeric, underscores, hyphens; max 255 chars)
            or None if no collection configured.
        """
        return None

    @property
    def embedding_capabilities(self) -> EmbeddingCapabilityGroup:
        """Get the embedding capabilities for this vector store provider.

        Returns:
            Embedding capabilities dictionary with 'dense' and 'sparse' keys.
        """
        return self.caps

    async def dense_dimension(self) -> int | None:
        """Get the dimension of dense embeddings for this vector store provider.

        Returns:
            Dimension of dense embeddings, or None if dense embeddings not supported.
        """
        dense_caps = self.embedding_capabilities.dense
        return await dense_caps.dimension() if dense_caps else None

    async def dense_dtype(self) -> Literal["float32", "float16", "int8", "binary"]:
        """Get the data type of dense embeddings for this vector store provider.

        Returns:
            Data type of dense embeddings.
        """
        dense_caps = self.embedding_capabilities.dense
        return await dense_caps.datatype() if dense_caps else "float16"  # ty:ignore[invalid-return-type]

    @property
    def distance_metric(self) -> Literal["cosine", "dot", "euclidean", "manhattan"]:
        """Get the distance metric used for similarity search.

        Returns:
            Distance metric as a string.
        """
        dense_caps = self.embedding_capabilities.dense
        if dense_caps and cast(EmbeddingModelCapabilities, dense_caps.capability).preferred_metrics:
            return next(
                cast(Literal["cosine", "dot", "euclidean", "manhattan"], measure.lower())
                for measure in cast(
                    EmbeddingModelCapabilities, dense_caps.capability
                ).preferred_metrics
                if measure.lower() in {"cosine", "dot", "euclidean", "manhattan"}
            )
        return "cosine"

    @property
    def dense_model(self) -> ModelNameT | None:
        """Get the name of the dense embedding model.

        Returns:
            Dense model name, or None if not configured.
        """
        return (
            self.embedding_capabilities.dense.config.model_name
            if self.embedding_capabilities.dense
            else None
        )

    @property
    def sparse_model(self) -> ModelNameT | None:
        """Get the name of the sparse embedding model.

        Returns:
            Sparse model name, or None if not configured.
        """
        return (
            self.embedding_capabilities.sparse.config.model_name
            if self.embedding_capabilities.sparse
            else self.embedding_capabilities.idf.config.model_name
            if self.embedding_capabilities.idf
            else None
        )

    @property
    def _check_circuit_breaker(self) -> None:
        """Check circuit breaker state before making API calls.

        Raises:
            CircuitBreakerOpenError: If circuit breaker is open.
        """
        current_time = time.time()

        if self._circuit_state == CircuitBreakerState.OPEN:
            if (
                self._last_failure_time
                and (current_time - self._last_failure_time) > self._circuit_open_duration
            ):
                # Transition to half-open to test recovery
                import logging

                logger = logging.getLogger(__name__)
                logger.info(
                    "Circuit breaker transitioning to half-open state for %s", type(self)._provider
                )
                self._circuit_state = CircuitBreakerState.HALF_OPEN
            else:
                raise CircuitBreakerOpenError(
                    f"Circuit breaker is open for {type(self)._provider}. Failing fast."
                )

    def _record_success(self) -> None:
        """Record successful API call and reset circuit breaker if needed."""
        if self._circuit_state in (CircuitBreakerState.HALF_OPEN, CircuitBreakerState.OPEN):
            import logging

            logger = logging.getLogger(__name__)
            logger.info(
                "Circuit breaker closing for %s after successful operation", type(self)._provider
            )
        self._circuit_state = CircuitBreakerState.CLOSED
        self._failure_count = ZERO
        self._last_failure_time = None

    def _record_failure(self) -> None:
        """Record failed API call and update circuit breaker state."""
        self._failure_count += 1
        self._last_failure_time = time.time()

        if self._failure_count >= MAX_RETRY_ATTEMPTS:
            import logging

            logger = logging.getLogger(__name__)
            logger.warning(
                "Circuit breaker opening for %s after %d consecutive failures",
                type(self)._provider,
                self._failure_count,
            )
            self._circuit_state = CircuitBreakerState.OPEN

    @property
    def circuit_breaker_state(self) -> str:
        """Get current circuit breaker state for health monitoring."""
        return self._circuit_state.variable

    @abstractmethod
    async def list_collections(self) -> list[str] | None:
        """List all collections in the vector store.

        Returns:
            List of collection names, or None if operation not supported.
            Returns empty list when no collections exist.

        Raises:
            ConnectionError: Failed to connect to vector store.
            ProviderError: Provider-specific operation failure.
        """

    @retry(
        stop=stop_after_attempt(MAX_RETRY_ATTEMPTS),
        wait=wait_exponential(multiplier=1, min=1, max=16),  # 1s, 2s, 4s, 8s, 16s
        retry=retry_if_exception_type(RETRYABLE_EXCEPTIONS),
        reraise=True,
    )
    async def _search_with_retry(
        self,
        vector: StrategizedQuery | MixedQueryInput,
        query_filter: Filter | None = None,
        context: Any = None,
    ) -> list[SearchResult]:
        """Wrapper around search with retry logic and circuit breaker."""
        from codeweaver.core import log_to_client_or_fallback

        _ = self._check_circuit_breaker

        try:
            result = await self.search(vector, query_filter)
            self._record_success()

            await log_to_client_or_fallback(
                context,
                "debug",
                {
                    "msg": "Vector store search successful",
                    "extra": {
                        "provider": type(self)._provider.variable,
                        "results_count": len(result),
                    },
                },
            )
        except RETRYABLE_EXCEPTIONS as e:
            self._record_failure()

            await log_to_client_or_fallback(
                context,
                "warning",
                {
                    "msg": "Vector store search failed",
                    "extra": {
                        "provider": type(self)._provider.variable,
                        "error": str(e),
                        "error_type": type(e).__name__,
                        "attempt": self._failure_count,
                        "max_attempts": MAX_RETRY_ATTEMPTS,
                    },
                },
            )
            raise
        except Exception as e:
            await log_to_client_or_fallback(
                context,
                "error",
                {
                    "msg": "Non-retryable error in vector store search",
                    "extra": {
                        "provider": type(self)._provider.variable,
                        "error": str(e),
                        "error_type": type(e).__name__,
                    },
                },
            )
            raise
        else:
            return result

    @abstractmethod
    async def search(
        self, vector: StrategizedQuery | MixedQueryInput, query_filter: Filter | None = None
    ) -> list[SearchResult]:
        """Search for similar vectors using query vector(s).

        Supports both dense-only and hybrid search.

        Args:
            vector: Preferred input is a StrategizedQuery object containing:
                - query: Original query string (for logging/metadata/tracking)
                - dense: Dense embedding vector (list of floats or ints) or None
                - sparse: Sparse embedding vector (list of floats/ints) or None
                - strategy: Search strategy to use (DENSE_ONLY, SPARSE_ONLY, HYBRID_SEARCH)

                Alternatively, a MixedQueryInput can be provided (will be deprecated), which is any of:
                - For dense-only: list of floats or ints
                - For sparse-only: list of floats or ints
                - For hybrid: dict with keys "dense" and "sparse" mapping to respective vectors

            query_filter: Optional filter to apply to search results.

        Returns:
            List of search results sorted by relevance score (descending).
            Maximum 100 results returned per query.
            Each result includes score between 0.0 and 1.0.
            Returns empty list when no results match query/filter.

        Raises:
            CollectionNotFoundError: Collection doesn't exist.
            DimensionMismatchError: Query vector dimension doesn't match collection.
            InvalidFilterError: Filter contains invalid fields or values.
            SearchError: Search operation failed.
        """

    @retry(
        stop=stop_after_attempt(MAX_RETRY_ATTEMPTS),
        wait=wait_exponential(multiplier=1, min=1, max=16),
        retry=retry_if_exception_type(RETRYABLE_EXCEPTIONS),
        reraise=True,
    )
    async def _upsert_with_retry(self, chunks: list[CodeChunk], context: Any = None) -> None:
        """Wrapper around upsert with retry logic and circuit breaker."""
        from codeweaver.core import log_to_client_or_fallback

        _ = self._check_circuit_breaker

        await log_to_client_or_fallback(
            context,
            "debug",
            {
                "msg": "Starting vector store upsert",
                "extra": {"provider": type(self)._provider.variable, "chunks_count": len(chunks)},
            },
        )

        try:
            await self.upsert(chunks)
            self._record_success()

            await log_to_client_or_fallback(
                context,
                "debug",
                {
                    "msg": "Vector store upsert successful",
                    "extra": {
                        "provider": type(self)._provider.variable,
                        "chunks_count": len(chunks),
                    },
                },
            )
        except RETRYABLE_EXCEPTIONS as e:
            self._record_failure()

            await log_to_client_or_fallback(
                context,
                "warning",
                {
                    "msg": "Vector store upsert failed",
                    "extra": {
                        "provider": type(self)._provider.variable,
                        "chunks_count": len(chunks),
                        "error": str(e),
                        "error_type": type(e).__name__,
                        "attempt": self._failure_count,
                        "max_attempts": MAX_RETRY_ATTEMPTS,
                    },
                },
            )
            raise
        except Exception as e:
            await log_to_client_or_fallback(
                context,
                "error",
                {
                    "msg": "Non-retryable error in vector store upsert",
                    "extra": {
                        "provider": type(self)._provider.variable,
                        "chunks_count": len(chunks),
                        "error": str(e),
                        "error_type": type(e).__name__,
                    },
                },
            )
            raise

    @abstractmethod
    async def upsert(self, chunks: list[CodeChunk]) -> None:
        """Insert or update code chunks with their embeddings.

        Args:
            chunks: List of code chunks to insert/update.
                - Each chunk must have unique chunk_id.
                - Each chunk must have at least one embedding (sparse or dense).
                - Embedding dimensions must match collection configuration.
                - Maximum 1000 chunks per batch.

        Raises:
            CollectionNotFoundError: Collection doesn't exist.
            DimensionMismatchError: Embedding dimension doesn't match collection.
            ValidationError: Chunk data validation failed.
            UpsertError: Upsert operation failed.

        Notes:
            - Existing chunks with same ID are replaced.
            - Payload indexes updated for new/modified chunks.
            - Operation is atomic (all-or-nothing for batch).
        """

    @abstractmethod
    async def delete_by_file(self, file_path: Path) -> None:
        """Delete all chunks for a specific file.

        Args:
            file_path: Path of file to remove from index.
                Must be relative path from project root.
                Use forward slashes for cross-platform compatibility.

        Raises:
            CollectionNotFoundError: Collection doesn't exist.
            DeleteError: Delete operation failed.

        Notes:
            - Idempotent: No error if file has no chunks.
            - Payload indexes updated to remove deleted chunks.
        """

    @abstractmethod
    async def delete_by_files(self, file_paths: list[Path]) -> None:
        """Delete all chunks for multiple files in a single operation.

        Args:
            file_paths: List of file paths to remove from index.
                Paths should be relative to project root.

        Raises:
            CollectionNotFoundError: Collection doesn't exist.
            DeleteError: Delete operation failed.

        Notes:
            - Idempotent: No error if files have no chunks.
            - More efficient than multiple calls to delete_by_file.
        """

    @abstractmethod
    async def delete_by_id(self, ids: list[UUID7]) -> None:
        """Delete specific code chunks by their unique identifiers.

        Args:
            ids: List of chunk IDs to delete.
                - Each ID must be valid UUID7.
                - Maximum 1000 IDs per batch.

        Raises:
            CollectionNotFoundError: Collection doesn't exist.
            DeleteError: Delete operation failed.

        Notes:
            - Idempotent: No error if some IDs don't exist.
            - Operation is atomic (all-or-nothing for batch).
        """

    @abstractmethod
    async def delete_by_name(self, names: list[str]) -> None:
        """Delete specific code chunks by their unique names.

        Args:
            names: List of chunk names to delete.
                - Each name must be non-empty string.
                - Maximum 1000 names per batch.

        Raises:
            CollectionNotFoundError: Collection doesn't exist.
            DeleteError: Delete operation failed.

        Notes:
            - Idempotent: No error if some names don't exist.
            - Operation is atomic (all-or-nothing for batch).
        """

    def _telemetry_keys(self) -> None:
        return None


__all__ = ("MixedQueryInput", "VectorStoreProvider")
