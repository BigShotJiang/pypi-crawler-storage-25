# sourcery skip: avoid-single-character-names-variables, lambdas-should-be-short, no-complex-if-expressions
"""Bedrock embedding provider."""

# SPDX-FileCopyrightText: 2025 (c) 2025 Knitli Inc.
# SPDX-License-Identifier: MIT OR Apache-2.0
# SPDX-FileContributor: Adam Poulemanos <adam@knit.li>
from __future__ import annotations

import asyncio
import logging

from collections.abc import Callable, Sequence
from io import BytesIO
from typing import (
    Annotated,
    Any,
    ClassVar,
    Literal,
    NotRequired,
    Required,
    TypedDict,
    TypeGuard,
    cast,
)

from boto3_types import BedrockInvokeModelResponseDict, BedrockRuntimeClient
from pydantic import (
    AliasGenerator,
    ConfigDict,
    Field,
    Json,
    PositiveInt,
    PrivateAttr,
    ValidationInfo,
    model_serializer,
    model_validator,
)
from pydantic.alias_generators import to_camel, to_snake

from codeweaver.core import BasedModel, CodeChunk, Provider, ProviderError
from codeweaver.core import ValidationError as CodeWeaverValidationError
from codeweaver.providers.config import (
    BedrockCohereConfigDict,
    BedrockEmbeddingProviderSettings,
    BedrockTitanV2ConfigDict,
)
from codeweaver.providers.embedding.providers.base import (
    EmbeddingCustomDeps,
    EmbeddingImplementationDeps,
    EmbeddingProvider,
)


logger = logging.getLogger(__name__)


class BaseBedrockModel(BasedModel):
    """Base model for Bedrock-related Pydantic models."""

    model_config = BasedModel.model_config | ConfigDict(
        alias_generator=AliasGenerator(validation_alias=to_snake, serialization_alias=to_camel),
        str_strip_whitespace=True,
        # spellchecker:off
        ser_json_inf_nan="null",
        # spellchecker:on
        serialize_by_alias=True,
    )


def is_cohere_request(data: dict[Any, Any] | str | bytes | bytearray) -> bool:
    """Determine if the given data is a Cohere embedding request."""
    if isinstance(data, dict):
        return (
            ("texts" in data and data["texts"] is not None)
            or ("images" in data and data["images"] is not None)
        ) and "input_type" in data
    if isinstance(data, str):
        return ("'texts':" in data or '"texts":' in data) and (
            "'input_type':" in data or '"input_type":' in data
        )
    return (b"'texts':" in data or b'"texts":' in data) and (
        b"'input_type':" in data or b'"input_type":' in data
    )


def is_cohere_response(data: dict[Any, Any] | str | bytes | bytearray) -> bool:
    """Determine if the given data is a Cohere embedding response."""
    if isinstance(data, dict):
        return ("embeddings" in data and "id" in data) or ("response_type" in data)
    if isinstance(data, str):
        return ("'embeddings':" in data or '"embeddings":' in data) and (
            "'response_type':" in data or '"response_type":' in data
        )
    return (b"'embeddings':" in data or b'"embeddings":' in data) and (
        b"'response_type':" in data or b'"response_type":' in data
    )


def is_titan_response(data: dict[Any, Any] | str | bytes | bytearray) -> bool:
    """Determine if the given data is a Titan Embedding V2 response."""
    if isinstance(data, dict):
        return ("embedding" in data and "input_text_token_count" in data) or (
            "embeddings_by_type" in data
        )
    if isinstance(data, str):
        return ("'embedding':" in data or '"embedding":' in data) and (
            "'input_text_token_count':" in data or '"input_text_token_count":' in data
        )
    return (b"'embedding':" in data or b'"embedding":' in data) and (
        b"'input_text_token_count':" in data or b'"input_text_token_count":' in data
    )


def is_one_of_valid_types(
    data: Any,
) -> TypeGuard[dict[str, Any] | str | bytes | bytearray | BytesIO]:
    """Check if the data is one of the valid types."""
    if isinstance(data, dict):
        return all(isinstance(key, str) for key in data if key)
    return isinstance(data, str | bytes | bytearray | BytesIO)


class CohereRequestHandler:
    """Handler for Cohere embedding requests."""

    def __init__(
        self,
        inputs: Sequence[CodeChunk] | Sequence[str],
        kind: Literal["documents", "query"],
        **kwargs: Any,
    ) -> None:
        """Initialize the CohereRequestHandler."""
        self.inputs = inputs
        self.kind = kind
        self.kwargs = kwargs


class CohereEmbeddingRequestBody(BaseBedrockModel):
    """Request body for Cohere embedding model."""

    input_type: Annotated[
        Literal["search_document", "search_query", "classification", "clustering", "image"],
        Field(description="""The type of input to generate embeddings for."""),
    ]
    texts: Annotated[
        list[Annotated[str, Field(max_length=2048)]],
        Field(description="""The input texts to generate embeddings for.""", max_length=96),
    ]
    images: Annotated[
        list[str] | None,
        Field(
            description="""The input image (as base64-encoded strings) to generate embeddings for.""",
            max_length=1,  # your read that right, only one image at a time... even if you give it as a list...
        ),
    ] = None
    truncate: Annotated[
        Literal["NONE", "START", "END"] | None, Field(description="""Truncation strategy.""")
    ] = None
    embedding_types: Annotated[
        list[Literal["float", "int8", "uint8", "binary", "ubinary"]] | None,
        Field(
            description="""The type of embeddings to generate. You can specify one or more types. Default is float."""
        ),
    ] = None

    @model_serializer
    def serialize(self) -> BytesIO:
        """Serialize the model to a UTF-8 encoded JSON byte stream.

        Bedrock expects the body to be a byte stream (e.g. `BytesIO`).
        """
        return shared_serializer(self)

    @model_validator(mode="before")
    @classmethod
    def _validate_input(cls, data: Any, info: ValidationInfo) -> Any:
        """Ensure that only one of `input_text` or `input_texts` is provided."""
        return shared_validator(cls, data, info, "request")


class TitanEmbeddingV2RequestBody(BaseBedrockModel):
    """Request body for Titan Embedding V2. Note that it's one document per request.

    This model serializes to the JSON body that Bedrock expects, **even when serialized to Python dicts**.
    """

    input_text: Annotated[
        str, Field(description="""The input text to generate embeddings for.""", max_length=50_000)
    ]
    dimensions: Annotated[
        Literal[1024, 512, 256],
        Field(description="""The number of dimensions for the generated embeddings."""),
    ] = 1024
    normalize: Annotated[
        bool,
        Field(
            description="""Whether to normalize the embeddings. Amazon defaults to False, but we default to True for our purposes."""
        ),
    ] = True
    embedding_types: Annotated[
        list[Literal["float", "binary"]] | None,
        Field(
            description="""The type of embeddings to generate. You can specify one or both types. In this context, 'binary' means 'integer' -- likely 'uint8'. Default is ['float']."""
        ),
    ] = None

    @model_serializer
    def serialize(self) -> BytesIO:
        """Serialize the model to a UTF-8 encoded JSON byte stream.

        Bedrock expects the body to be a byte stream (e.g. `BytesIO`).
        """
        return shared_serializer(self)

    @model_validator(mode="before")
    @classmethod
    def _validate_input(cls, data: Any, info: ValidationInfo) -> Any:
        """Ensure that only one of `input_text` or `input_texts` is provided."""
        return shared_validator(cls, data, info, "request")


def shared_serializer(
    instance: CohereEmbeddingRequestBody
    | TitanEmbeddingV2RequestBody
    | CohereEmbeddingResponse
    | TitanEmbeddingV2Response,
) -> BytesIO:
    """Shared serializer to serialize the model to a UTF-8 encoded JSON byte stream."""
    return BytesIO(instance.model_dump_json().encode("utf-8"))


def shared_validator(
    _cls: type[
        CohereEmbeddingRequestBody
        | TitanEmbeddingV2RequestBody
        | CohereEmbeddingResponse
        | TitanEmbeddingV2Response
    ],
    data: Any,
    info: ValidationInfo,
    kind: Literal["request", "response"] = "request",
) -> Any:
    """Shared validator to route JSON/text/bytes to the appropriate Bedrock model."""
    mode = info.mode

    if isinstance(data, BytesIO):
        data = data.getvalue()

    if not is_one_of_valid_types(data):
        raise CodeWeaverValidationError(
            f"Invalid data type. Expected one of: dict, str, bytes, bytearray, BytesIO. Full validation info:\n{info}"
        )
    data = cast(dict[str, Any] | str | bytes | bytearray, data)
    if kind == "request":
        return _handle_data_type_validation(
            mode,
            data,
            CohereEmbeddingRequestBody if is_cohere_request(data) else TitanEmbeddingV2RequestBody,
        )
    return _handle_data_type_validation(
        mode,
        cast(dict[str, Any] | bytes | bytearray, data),
        CohereEmbeddingResponse if is_cohere_response(data) else TitanEmbeddingV2Response,
    )


def _handle_data_type_validation(
    mode: Literal["python", "json"],
    data: dict[str, Any] | str | bytes | bytearray,
    cls: type[
        CohereEmbeddingRequestBody
        | TitanEmbeddingV2RequestBody
        | CohereEmbeddingResponse
        | TitanEmbeddingV2Response
    ],
) -> (
    dict[str, Any]
    | CohereEmbeddingRequestBody
    | TitanEmbeddingV2RequestBody
    | CohereEmbeddingResponse
    | TitanEmbeddingV2Response
):
    """Handle data type validation for Bedrock request/response models.

    - If Pydantic is running in python mode and a dict is provided, return the dict so
      Pydantic will validate it normally into the provided cls.
    - Otherwise, parse the provided JSON (bytes/str) into the target cls.
    """
    if mode == "python" and isinstance(data, dict):
        return data

    # Otherwise parse JSON text/bytes into the requested model.
    # model_validate_json accepts str or bytes
    return cls.model_validate_json(cast(str | bytes | bytearray, data))


class BedrockInvokeEmbeddingRequest(BaseBedrockModel):
    """Request for Bedrock embedding."""

    body: Annotated[
        Json[TitanEmbeddingV2RequestBody] | Json[CohereEmbeddingRequestBody],
        Field(
            description=(
                "The request body for the embedding. This must be either a TitanEmbeddingV2RequestBody or a CohereEmbeddingRequestBody. When serialized to Python or JSON, this will be a UTF-8 encoded JSON string. Amazon requires the body to be a byte stream (e.g. `BinaryIO`)"
            )
        ),
    ]
    content_type: Annotated[
        Literal["application/json"],
        Field(description="""The content type of the body. This must be 'application/json'."""),
    ] = "application/json"
    accept: Annotated[
        Literal["application/json"],
        Field(description="""The accept header. This must be 'application/json'."""),
    ] = "application/json"
    model_id: Annotated[
        str,
        Field(
            description="""The model ID to use for generating embeddings. The value for this depends on the model, your account, and other factors. [See the Bedrock docs](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/bedrock-runtime/client/invoke_model.html) for more information. tl;dr use the model ARN if you aren't sure."""
        ),
    ]
    trace: Annotated[
        Literal["ENABLED", "DISABLED", "ENABLED_FULL"],
        Field(
            description="""The trace level to use for the request. This controls the amount of tracing information returned in the response."""
        ),
    ] = "DISABLED"
    guardrail_identifier: Annotated[
        str | None,
        Field(
            description="""The guardrail identifier to use for the request. This is used to enforce safety and compliance policies. We'll default to null/None. If you need this, you'll know."""
        ),
    ] = None
    guardrail_version: Annotated[
        str | None, Field(description="""The guardrail version to use, if using guardrail.""")
    ] = None
    performance_config_latency: Annotated[
        Literal["standard", "optimized"],
        Field(
            description="""The performance configuration to use for the request. This controls the latency and throughput of the request."""
        ),
    ] = "standard"


class TitanEmbeddingV2Response(BaseBedrockModel):
    """Response from Titan Embedding V2."""

    embedding: Annotated[
        list[float], Field(description="""The generated embedding as a list of floats.""")
    ]
    input_text_token_count: Annotated[
        int, Field(description="""The number of tokens in the input text.""")
    ]
    embeddings_by_type: Annotated[
        dict[Literal["float", "binary"], list[float] | list[int]],
        Field(description="""The generated embeddings by type."""),
    ]

    @model_serializer
    def serialize(self) -> BytesIO:
        """Serialize the model to a UTF-8 encoded JSON byte stream."""
        return shared_serializer(self)

    @model_validator(mode="before")
    @classmethod
    def _validate_input(cls, data: Any, info: ValidationInfo) -> Any:
        return shared_validator(cls, data, info, "response")


class ImageDescription(BaseBedrockModel):
    """Description of an image in the request."""

    width: PositiveInt
    height: PositiveInt
    fmt: Annotated[str, Field(serialization_alias="format", validation_alias="format")]
    bit_depth: PositiveInt


class CohereEmbeddingResponse(BaseBedrockModel):
    """Response from Cohere embedding."""

    embeddings: Annotated[
        Sequence[Sequence[float] | Sequence[Sequence[int]]],
        Field(
            description="""The generated embeddings as a list of lists. Floats or ints depending on type."""
        ),
    ]
    id: Annotated[str, Field(description="""The ID of the request.""")]
    response_type: Annotated[
        Literal["embedding_floats"], Field(description="""The type of response.""")
    ] = "embedding_floats"
    texts: Annotated[
        list[str] | None, Field(description="""The input texts for the embedding request.""")
    ]
    images: Annotated[
        list[ImageDescription] | None,
        Field(description="""A description of the image in the request."""),
    ] = None

    @model_serializer
    def serialize(self) -> BytesIO:
        """Serialize the model to a UTF-8 encoded JSON byte stream."""
        return shared_serializer(self)

    @model_validator(mode="before")
    @classmethod
    def _validate_input(cls, data: Any, info: ValidationInfo) -> Any:
        return shared_validator(cls, data, info, "response")


class InvokeRequestDict(TypedDict, total=False):
    """Request dict for invoking the model."""

    body: Required[BytesIO]
    content_type: Required[Literal["application/json"]]
    accept: Required[Literal["application/json"]]
    model_id: Required[str]
    trace: NotRequired[Literal["ENABLED", "DISABLED", "ENABLED_FULL"]]
    guardrail_identifier: NotRequired[str | None]
    guardrail_version: NotRequired[str | None]
    performance_config_latency: NotRequired[Literal["standard", "optimized"]]


class BedrockInvokeEmbeddingResponse(BaseBedrockModel):
    """Response from Bedrock embedding."""

    body: Annotated[
        TitanEmbeddingV2Response | CohereEmbeddingResponse,
        Field(
            description="""The body of the response. This is what AWS calls a `StreamingBody` response -- a bytestream. It will contain a UTF-8 encoded JSON string that will be either be the JSON-serialized form of TitanEmbeddingV2Response or CohereEmbeddingResponse, depending on which model you used."""
        ),
    ]
    content_type: Annotated[
        str,
        Field(
            description="""The mimetype of the response body. Most likely 'application/json', but AWS isn't clear on this."""
        ),
    ] = "application/json"

    @classmethod
    def from_boto3_response(cls, response: Any) -> BedrockInvokeEmbeddingResponse:
        """Create a BedrockInvokeEmbeddingResponse from a boto3 response."""
        return cls.model_validate_json(response, by_alias=True)


class BedrockEmbeddingProvider(EmbeddingProvider[BedrockRuntimeClient]):
    """Bedrock embedding provider."""

    _provider: ClassVar[Provider] = Provider.BEDROCK

    client: BedrockRuntimeClient
    config: BedrockEmbeddingProviderSettings

    # Private instance variables to store extracted config values
    _model_arn: str | None = PrivateAttr(default=None)
    _model_config: BedrockTitanV2ConfigDict | BedrockCohereConfigDict | dict[str, Any] = (
        PrivateAttr(default_factory=dict)
    )

    def _initialize(
        self,
        impl_deps: EmbeddingImplementationDeps = None,
        custom_deps: EmbeddingCustomDeps = None,
        **kwargs: Any,
    ) -> None:

        self._output_transformer: Callable[
            [BedrockInvokeEmbeddingResponse, CodeChunk | None, asyncio.AbstractEventLoop | None],
            list[float] | list[int] | list[list[float]] | list[list[int]],
        ] = self._handle_response

        # Store model ARN and model config for easy access
        object.__setattr__(self, "_model_arn", self.config.embedding_config.model_arn)
        model_config = self.config.embedding_config.model
        if not model_config:
            if str(self.config.model_name).startswith("titan"):
                model_config = BedrockTitanV2ConfigDict()
            elif str(self.config.model_name).startswith("cohere"):
                model_config = BedrockCohereConfigDict()
            else:
                model_config = {}
        model_config = (
            cast(BedrockTitanV2ConfigDict, model_config)
            if any(k for k in ("dimensions", "embedding_types") if k in model_config)
            else cast(BedrockCohereConfigDict, model_config)
            if any(k for k in ("truncate", "embedding_types", "images") if k in model_config)
            else cast(dict[str, Any], model_config)
        )
        object.__setattr__(self, "_model_config", model_config)

    @property
    def base_url(self) -> str | None:
        """Get the base URL for the Bedrock client."""
        return self.client.meta.endpoint_url

    @property
    def dimension(self) -> int:
        """Get the dimension of the embeddings."""
        return self._model_config.get("dimensions") or self.caps.default_dimension

    def _handle_response(
        self,
        response: dict[str, Any],
        doc: CodeChunk | None = None,
        loop: asyncio.AbstractEventLoop | None = None,
    ) -> list[float] | list[int] | list[list[float]] | list[list[int]]:
        """Handle the response from Bedrock for embedding requests."""
        if "cohere" in self.model_name.lower():
            return self._handle_cohere_response(
                BedrockInvokeEmbeddingResponse.from_boto3_response(response), doc, loop=loop
            )
        return self._handle_titan_response(
            BedrockInvokeEmbeddingResponse.from_boto3_response(response), doc, loop=loop
        )

    def _handle_titan_response(
        self,
        response: BedrockInvokeEmbeddingResponse,
        doc: CodeChunk | None = None,
        loop: asyncio.AbstractEventLoop | None = None,
    ) -> list[float] | list[int]:
        """Handle the response from Titan for embedding requests."""
        from codeweaver.core import CodeChunk

        loop = loop or asyncio.get_running_loop()
        if (
            isinstance(response.body, TitanEmbeddingV2Response)
            and hasattr(response.body, "input_text_token_count")
            and (count := response.body.input_text_token_count)
        ):
            self._fire_and_forget(lambda: self._update_token_stats(token_count=count), loop=loop)
        else:
            self._fire_and_forget(
                lambda: self._update_token_stats(
                    from_docs=cast(
                        Sequence[str], CodeChunk.dechunkify(cast(Sequence[CodeChunk], [doc]))
                    )
                ),
                loop=loop,
            )
        return (
            response.body.embedding if isinstance(response.body, TitanEmbeddingV2Response) else []
        )

    def _handle_cohere_response(
        self,
        response: BedrockInvokeEmbeddingResponse,
        doc: CodeChunk | None = None,
        loop: asyncio.AbstractEventLoop | None = None,
    ) -> list[list[float]] | list[list[int]]:
        """Handle the response from Bedrock for embedding requests and normalize to Sequence[float]."""
        deserialized = BedrockInvokeEmbeddingResponse.from_boto3_response(response)
        if not isinstance(deserialized.body, CohereEmbeddingResponse):
            raise ProviderError(
                "AWS Bedrock returned invalid response format for Cohere embedding",
                details={
                    "provider": "bedrock",
                    "model": self.caps.name,
                    "expected_type": "CohereEmbeddingResponse",
                    "received_type": type(deserialized.body).__name__,
                },
                suggestions=[
                    "Verify the Bedrock model ID is correct for Cohere embeddings",
                    "Check that the Bedrock API response format has not changed",
                    "Ensure the model supports the requested embedding operation",
                ],
            )
        loop = loop or asyncio.get_running_loop()
        self._fire_and_forget(
            lambda: self._update_token_stats(
                from_docs=cast(
                    Sequence[str], self.chunks_to_strings(cast(Sequence[CodeChunk], [doc]))
                )
            ),
            loop=loop,
        )
        return cast(
            list[list[float]] | list[list[int]],
            deserialized.body.embeddings
            if deserialized.body and deserialized.body.embeddings
            else [],
        )

    async def _create_cohere_request(
        self,
        inputs: Sequence[CodeChunk] | Sequence[str],
        kind: Literal["documents", "query"],
        **kwargs: Any,
    ) -> InvokeRequestDict:
        """Create the Cohere embedding request."""
        body_kwargs = (
            {k: v for k, v in kwargs.items() if k in {"truncate", "embedding_types", "images"}}
            if kwargs
            else {}
        ) | (cast(dict[str, Any], kwargs).get("body", {}) if kwargs else {})
        if kind == "documents":
            texts = [(await self._process_input(doc))[0] for doc in inputs]
            texts = self.chunks_to_strings([subitem for item in texts for subitem in item])
        else:
            texts = inputs
        body = {
            "input_type": "search_document" if kind == "documents" else "search_query",
            "texts": texts,
            "truncate": self._model_config.get("truncate", "NONE"),
            "embedding_types": self._model_config.get("embedding_types", ["float"]),
            **body_kwargs,
        }
        request: BedrockInvokeEmbeddingRequest = BedrockInvokeEmbeddingRequest.model_validate({
            "body": body,
            "model_id": self._model_arn,
        })
        return InvokeRequestDict(**dict(request.model_dump(by_alias=True)))  # ty: ignore[missing-typed-dict-key]

    async def _create_titan_request(
        self,
        inputs: Sequence[CodeChunk] | Sequence[str],
        kind: Literal["documents", "query"],
        **kwargs: Any,
    ) -> list[InvokeRequestDict]:
        """Create the Titan embedding request."""
        from codeweaver.core import CodeChunk

        body_kwargs = (
            {
                k: v
                for k, v in cast(dict[str, Any], kwargs).items()
                if k in {"dimensions", "normalize", "embedding_types"}
            }
            if kwargs
            else {}
        ) | (cast(dict[str, Any], kwargs).get("body", {}) if kwargs else {})
        if kind == "documents":
            text = await self._process_input(inputs)
            processed = CodeChunk.dechunkify(text[0])
        else:
            processed = cast(Sequence[str], inputs)
        requests: list[BedrockInvokeEmbeddingRequest] = []
        for doc in processed:
            if len(doc) > 50_000:
                raise CodeWeaverValidationError(
                    "Input text exceeds Titan Embedding V2 maximum length",
                    details={
                        "provider": "bedrock",
                        "model": f"{self.config.model_name}",
                        "max_length": 50_000,
                        "actual_length": len(doc),
                        "excess_chars": len(doc) - 50_000,
                    },
                    suggestions=[
                        "Split the text into smaller chunks (< 50,000 characters)",
                        "Use a different embedding model with larger context window",
                        "Consider summarizing the text before embedding",
                    ],
                )
            body = TitanEmbeddingV2RequestBody.model_validate({
                "input_text": doc,
                "dimensions": self.dimension,
                "normalize": self._model_config.get("normalize", True),
                "embedding_types": self._model_config.get("embedding_types", ["float"]),
                **body_kwargs,
            })
            requests.append(
                BedrockInvokeEmbeddingRequest.model_validate({
                    "body": body,
                    "model_id": self._model_arn,
                })
            )
        return [InvokeRequestDict(**dict(req.model_dump(by_alias=True))) for req in requests]  # ty: ignore[missing-typed-dict-key]

    async def _create_request(
        self,
        inputs: Sequence[CodeChunk] | Sequence[str],
        kind: Literal["documents", "query"],
        **kwargs: Any,
    ) -> list[InvokeRequestDict] | InvokeRequestDict:
        """Create the Bedrock embedding request."""
        if "cohere" in self.config.model_name.lower():
            return await self._create_cohere_request(inputs, kind, **kwargs)
        return await self._create_titan_request(inputs, kind, **kwargs)

    async def _get_vectors(
        self, requests: list[InvokeRequestDict]
    ) -> list[BedrockInvokeModelResponseDict]:
        """Get vectors for a sequence of texts using the Bedrock API."""
        return [await asyncio.to_thread(self.client.invoke_model, **req) for req in requests]

    async def _embed_documents(
        self, documents: Sequence[CodeChunk], **kwargs: Any
    ) -> list[list[float]] | list[list[int]]:
        """Embed a batch of documents using the Bedrock API."""
        kwargs = kwargs or {}
        requests = await self._create_request(documents, kind="documents", **kwargs)
        responses = await self._get_vectors(requests if isinstance(requests, list) else [requests])
        loop = await self._get_loop()
        if "cohere" in self.config.model_name.lower():
            return self._output_transformer(responses[0], documents, loop)  # type: ignore
        return [
            self._output_transformer(response, doc, loop)  # type: ignore
            for (response, doc) in zip(responses, documents, strict=True)
        ]  # ty: ignore[invalid-return-type]

    async def _embed_query(
        self, query: Sequence[str], **kwargs: Any
    ) -> list[list[float]] | list[list[int]]:
        """Embed a batch of queries using the Bedrock API."""
        kwargs = kwargs or {}
        requests = await self._create_request(query, kind="query", **kwargs)
        responses: list[BedrockInvokeModelResponseDict] = await self._get_vectors(
            requests if isinstance(requests, list) else [requests]
        )
        loop = await self._get_loop()
        return [
            self._output_transformer(response, doc, loop)  # ty:ignore[too-many-positional-arguments]
            for (response, doc) in zip(responses, query, strict=True)
        ]  # ty: ignore[invalid-return-type]


__all__ = (
    "BaseBedrockModel",
    "BedrockEmbeddingProvider",
    "BedrockInvokeEmbeddingRequest",
    "BedrockInvokeEmbeddingResponse",
    "CohereEmbeddingRequestBody",
    "CohereEmbeddingResponse",
    "CohereRequestHandler",
    "ImageDescription",
    "InvokeRequestDict",
    "TitanEmbeddingV2RequestBody",
    "TitanEmbeddingV2Response",
    "is_cohere_request",
    "is_cohere_response",
    "is_one_of_valid_types",
    "is_titan_response",
    "shared_serializer",
    "shared_validator",
)
