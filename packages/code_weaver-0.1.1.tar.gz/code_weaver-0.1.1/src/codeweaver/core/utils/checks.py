# SPDX-FileCopyrightText: 2025 Knitli Inc.
# SPDX-FileContributor: Adam Poulemanos <adam@knit.li>
#
# SPDX-License-Identifier: MIT OR Apache-2.0

"""Utility functions for type checking and validation."""

from __future__ import annotations

import inspect
import logging
import os
import platform
import sys
import urllib.parse as urllib_parse

from functools import cache
from importlib import metadata, util
from pathlib import Path
from typing import Any

import httpx

from pydantic import AnyUrl, BaseModel, TypeAdapter


logger = logging.getLogger(__name__)

python_version = sys.version_info

if sys.version_info >= (3, 13):
    from typing import TypeIs as _TypeIs
else:
    from typing_extensions import TypeIs as _TypeIs

TypeIs = _TypeIs

LOCALHOST_INDICATORS = {
    "localhost",
    "127.0.0.1",
    "0.0.0.0",  # noqa: S104
    "::1",
    "0:0:0:0:0:0:0:1",
    "::",  # I guess ruff is ok if we bind to all interfaces in ipv6
    # save the more expensive check for second
    # this checks if the ip range is in private ranges
}


def is_local_host(host: str | AnyUrl | httpx.URL | urllib_parse.ParseResult) -> bool:
    """Check if a host is a localhost address."""
    if isinstance(host, (AnyUrl, httpx.URL)):
        filtered_host = host.host
    elif isinstance(host, urllib_parse.ParseResult):
        filtered_host = host.hostname or ""
    else:
        filtered_host = str(host)
        if any(c in filtered_host for c in ("/", ":", "\\")):
            # likely a url, parse it
            parsed = urllib_parse.urlparse(filtered_host)
            filtered_host = parsed.hostname or ""
    return filtered_host in LOCALHOST_INDICATORS if filtered_host else False


def is_pydantic_basemodel(model: Any) -> TypeIs[type[BaseModel] | BaseModel]:
    """Check if a model is a Pydantic BaseModel."""
    return isinstance(model, type) and (
        issubclass(model, BaseModel) or isinstance(model, BaseModel)
    )


def is_class(obj: Any) -> TypeIs[type[Any]]:
    """Check if an object is a class."""
    return inspect.isclass(obj)


def is_typeadapter(adapter: Any) -> TypeIs[TypeAdapter[Any] | type[TypeAdapter[Any]]]:
    """Check if an object is a Pydantic TypeAdapter."""
    return hasattr(adapter, "pydantic_complete") and hasattr(adapter, "validate_python")


@cache
def has_package(package_name: str) -> bool:
    """Check if a package is installed.

    First checks via importlib.metadata to catch cases like `fastembed-gpu` which don't import under that name.
    Then falls back to importlib.util.find_spec to catch packages that may not be registered in metadata.
    """

    def check_spec(name: str) -> bool:
        return util.find_spec(name) is not None

    try:
        metadata.distribution(package_name.replace("_", "-").replace("codeweaver", "code-weaver"))
    except metadata.PackageNotFoundError:
        if check_spec(package_name):
            return True
        if "-" in package_name and check_spec(
            package_name.replace("-", "_").replace("code-weaver", "codeweaver")
        ):
            return True
    else:
        return True
    return False


def is_debug() -> bool:
    """Check if the application is running in debug mode."""
    from codeweaver.core import in_codeweaver_clone

    env = os.getenv("CODEWEAVER_DEBUG")

    explicit_true = (env in ("1", "true", "True", "TRUE")) if env is not None else False
    explicit_false = os.getenv("CODEWEAVER_DEBUG", "1") in ("false", "0", "", "False", "FALSE")

    has_debugger = (
        hasattr(sys, "gettrace") and callable(sys.gettrace) and (sys.gettrace() is not None)
    )
    repo_heuristic = in_codeweaver_clone(Path.cwd()) and not explicit_false

    return explicit_true or has_debugger or repo_heuristic


def is_ci() -> bool:
    """Check if the code is running in a Continuous Integration environment."""
    ci_indicators = [
        "APPVEYOR",
        "BUILDKITE",
        "BUILD_NUMBER",
        "CI",
        "CIRCLECI",
        "CONTINUOUS_INTEGRATION",
        "GITHUB_ACTIONS",
        "GITLAB_CI",
        "JENKINS_URL",
        "RUN_ID",
        "TF_BUILD",
        "TRAVIS",
    ]
    return any(os.getenv(var) for var in ci_indicators)


def file_is_binary(file_path: Path) -> bool:
    """Check if a file is binary by reading its initial bytes."""
    try:
        with file_path.open("rb") as f:
            initial_bytes = f.read(1024)
            if b"\0" in initial_bytes:
                return True
            text_characters = bytearray({7, 8, 9, 10, 12, 13, 27} | set(range(0x20, 0x100)))
            non_text = initial_bytes.translate(None, text_characters)
            if len(non_text) / len(initial_bytes) > 0.30:
                return True
    except Exception as e:
        logger.warning("Could not read file %s to determine if binary: %s", file_path, e)
        return False
    return False


def is_test_environment() -> bool:
    """Check if the code is running in a test environment."""
    # Check if CODEWEAVER_TEST_MODE is explicitly enabled
    test_mode_enabled = os.environ.get("CODEWEAVER_TEST_MODE", "0") in {"1", "true", "True", "TRUE"}
    if test_mode_enabled:
        return True

    # Fallback: detect pytest environment
    pytest_loaded = "pytest" in sys.modules
    pytest_flagged = any(arg.startswith("-m") and "pytest" in arg for arg in sys.argv)
    pytest_current_test = bool(os.environ.get("PYTEST_CURRENT_TEST"))
    # We don't want to force a testing profile if someone is debugging something else!
    from codeweaver.core.utils.filesystem import in_codeweaver_clone

    return in_codeweaver_clone() and (pytest_loaded or (pytest_flagged and pytest_current_test))


def is_wsl() -> bool:
    """Check if the code is running inside Windows Subsystem for Linux (WSL)."""
    if sys.platform != "linux":
        return False
    return (
        "microsoft" in platform.uname().release.lower()
        or "WSL" in platform.uname().version
        or any(
            v
            for v in ("WSL_INTEROP", "WSL_DISTRO_NAME", "WSLENV", "WSL2_GUI_APPS_ENABLED")
            if v in os.environ
        )
    )


def is_wsl_vscode() -> bool:
    """Check if the code is running inside WSL with VSCode integration."""
    from codeweaver.core.utils.environment import we_are_in_vscode

    return is_wsl() and we_are_in_vscode()


__all__ = (
    "LOCALHOST_INDICATORS",
    "TypeIs",
    "file_is_binary",
    "has_package",
    "is_ci",
    "is_class",
    "is_debug",
    "is_local_host",
    "is_pydantic_basemodel",
    "is_test_environment",
    "is_typeadapter",
    "is_wsl",
    "is_wsl_vscode",
)
