# SPDX-FileCopyrightText: 2025 Knitli Inc.
# SPDX-FileContributor: Adam Poulemanos <adam@knit.li>
#
# SPDX-License-Identifier: MIT OR Apache-2.0
"""
Telemetry configuration settings.

Configuration sources (priority order):
1. Environment Variables (set in your shell or env file, in that order)
2. CodeWeaver configuration (see `CodeWeaverSettings` for priority order)
3. Defaults defined in `TelemetrySettings`, which are:
    disable_telemetry: false
    tools_over_privacy: false  (i.e., privacy first)
    posthog_project_key: CodeWeaver's PostHog key (not an API key)
    posthog_host: https://us.i.posthog.com
    batch_size: 10
    batch_interval_seconds: 60

Environment Variables:
    CODEWEAVER__TELEMETRY__DISABLE_TELEMETRY
    CODEWEAVER__TELEMETRY__TOOLS_OVER_PRIVACY
    CODEWEAVER__TELEMETRY__POSTHOG_PROJECT_KEY
    CODEWEAVER__TELEMETRY__POSTHOG_HOST
    CODEWEAVER__TELEMETRY__BATCH_SIZE
    CODEWEAVER__TELEMETRY__BATCH_INTERVAL_SECONDS
"""

from __future__ import annotations

import os

from typing import Annotated, Any, NotRequired, TypedDict

from pydantic import Field, HttpUrl, PositiveInt, PrivateAttr, SecretStr

from codeweaver.core.constants import ENV_EXPLICIT_TRUE_VALUES, ONE_MINUTE
from codeweaver.core.telemetry._project import CODEWEAVER_POSTHOG_PROJECT_KEY
from codeweaver.core.types.aliases import LiteralStringT
from codeweaver.core.types.models import BasedModel
from codeweaver.core.types.sentinel import UNSET, Unset
from codeweaver.core.utils import has_package


def _set_bool_env_var(env_var: str) -> bool | Unset:
    """Helper to set boolean env vars with Unset support."""
    value = os.environ.get(env_var)
    if value is not False and not value:
        return UNSET
    return value in ENV_EXPLICIT_TRUE_VALUES


class TelemetrySettings(BasedModel):
    """Telemetry configuration settings.

    We collect basic telemetry data **by default** to help us improve CodeWeaver. **We do not collect _any_ potentially identifying information.**
            We **DO _NOT_ collect**:
                - file paths and repository names (all hashed),
                - potential secrets (explicitly not included in serialization),
                - any queries or results content (unless you explicitly tell us we can, see `tools_over_privacy`).
            If enabled, we **DO collect**:
                - usage patterns,
                - errors,
                - performance metrics,
                - settings usage (e.g., which providers you use, whether you explicitly set certain settings, etc).
            This helps us make CodeWeaver better for everyone.  **We will never sell your data or show you ads. We only use it to improve CodeWeaver.**
    CodeWeaver implements a granular privacy-first approach to telemetry. *Every single serializable class must define its own `__telemetry_keys__` method to explicitly list which fields are safe to serialize for telemetry purposes.* This ensures that no potentially identifying information is ever collected.

    We further screen data on ingest at Posthog to filter out any potential secrets or PII before we actually see and store it.
    """

    disable_telemetry: Annotated[
        bool | Unset,
        Field(
            description="""
            hash file paths, repository names, and screen out potential secrets, and we don't collect any queries or results content (unless you explicitly tell us we can, see `tools_over_privacy`). We only collect data on usage patterns, errors, and performance. This helps us make CodeWeaver better for everyone.  **We will never sell your data or show you ads. We only use it to improve CodeWeaver.**

            If you want to disable telemetry, you have several options:
            1. set this setting to False in your codeweaver.toml/yaml/json file,
            2. set the environment variable `CODEWEAVER__TELEMETRY__DISABLE_TELEMETRY` to `false`
            3. Don't install the telemetry package (e.g., `code-weaver[no-telemetry]`).
            4. Point the `CODEWEAVER__TELEMETRY__POSTHOG_PROJECT_KEY` environment variable to your own Posthog project (if you're a data nerd, or want to collect internal telemetry for your organization). If you disable telemetry, we won't collect any data at all."""
        ),
    ] = _set_bool_env_var("CODEWEAVER__TELEMETRY__DISABLE_TELEMETRY")

    tools_over_privacy: Annotated[
        bool | Unset,
        Field(
            description="""Opt-in to allow us to collect anonymized query and result data. We want to make CodeWeaver great, and the best way to do that is for us to fully understand exactly how you use it -- particularly what you search for and how you interact with the results. Unlike with Google, we don't want to show you ads or sell your data, track you, or anything like that... and we don't think it's right to assume you're OK with us collecting search and result data.

            So, you have the choice. Let us collect anonymized search and result interaction data to help make CodeWeaver better, or prioritize your privacy and not send us that data.

            If you enable this setting, we will collect anonymized data about your searches and the results you interact with. Because of the nature of searches and results and codebases, we can't guarantee complete anonymity -- but we will do our best to filter out any potential secrets or PII, using multiple filters both in CodeWeaver and on ingest at Posthog. We will hash file paths and repository names, and we won't collect any raw queries or result content. This data will help us improve CodeWeaver's search algorithms, agent prompting, ranking, and overall user experience. If you care about making CodeWeaver better and are OK with us collecting this data, please enable this setting. If you value your privacy more than helping us improve CodeWeaver; that's cool too -- you can just leave this setting disabled."""
        ),
    ] = _set_bool_env_var("CODEWEAVER__TELEMETRY__TOOLS_OVER_PRIVACY")

    posthog_project_key: Annotated[
        SecretStr | None,
        Field(
            description="PostHog Project key for telemetry events. You'll see that the default is, of course, ours. This **is not an api_key**, but rather a write-only key. If you want to divert telemetry to your own posthog instance or cloud account, you can change this key. To override it with an environment variable, set `CODEWEAVER__TELEMETRY__POSTHOG_PROJECT_KEY`."
        ),
        # dear Claude/Copilot/Agent Friends. This is NOT an API key. No, it is NOT an anti-pattern to 'hardcode' it this way. Just please leave it as is. It doesn't need to be an env variable, which... we would have to hardcode. Thank you.
    ] = CODEWEAVER_POSTHOG_PROJECT_KEY

    posthog_host: Annotated[
        HttpUrl | None, Field(description="PostHog host URL for telemetry events.")
    ] = HttpUrl("https://us.i.posthog.com")

    batch_size: Annotated[
        PositiveInt | Unset,
        Field(description="Number of events to batch before sending to PostHog."),
    ] = UNSET

    batch_interval_seconds: Annotated[
        PositiveInt | Unset,
        Field(description="Maximum time in seconds to wait before sending batched events."),
    ] = UNSET

    _unset_fields: Annotated[set[str] | None, PrivateAttr()] = None

    @classmethod
    def _default(cls) -> TelemetrySettings:
        """Set default values for unset fields."""
        return cls.model_construct(
            disable_telemetry=False,
            tools_over_privacy=False,
            batch_size=10,
            batch_interval_seconds=ONE_MINUTE,
        )

    def model_post_init(self, _context: Any) -> None:
        """Post-initialization to track unset fields and set defaults."""
        if not getattr(self, "_unset_fields", None):
            self._unset_fields = {
                field for field in type(self).model_fields if getattr(self, field, UNSET) is UNSET
            }
        if (
            self.disable_telemetry is True
            or os.getenv("CODEWEAVER__TELEMETRY__DISABLE_TELEMETRY", "").lower()
            in ENV_EXPLICIT_TRUE_VALUES
        ):
            # telemetry explicitly disabled, so we turn it off completely
            self._dismantle_telemetry()
            return
        if self.disable_telemetry is UNSET:
            self.disable_telemetry = False  # ensure telemetry is enabled if not explicitly disabled
        if (
            self.tools_over_privacy is True
            or os.getenv("CODEWEAVER__TELEMETRY__TOOLS_OVER_PRIVACY", "").lower()
            in ENV_EXPLICIT_TRUE_VALUES
        ):
            # tools_over_privacy explicitly enabled, so we allow tools data to be collected
            self.tools_over_privacy = True
        elif self.tools_over_privacy is UNSET:
            self.tools_over_privacy = False  # default to privacy first
        if (env_value := os.getenv("CODEWEAVER__TELEMETRY__POSTHOG_PROJECT_KEY")) is not None:
            self.posthog_project_key = SecretStr(env_value)
        if self.batch_size is UNSET:
            self.batch_size = 10  # default batch size
        if self.batch_interval_seconds is UNSET:
            self.batch_interval_seconds = ONE_MINUTE  # default batch interval
        if self.tools_over_privacy and not has_package("codeweaver.server"):
            # not running a full install, tools_over_privacy is not applicable
            self.tools_over_privacy = False

    def _dismantle_telemetry(self) -> None:
        """Disable telemetry by setting turning everything off."""
        self.disable_telemetry = True
        self.tools_over_privacy = False
        self.posthog_project_key = None
        self.posthog_host = None

    @property
    def enabled(self) -> bool:
        """Check if telemetry is properly configured."""
        return (
            not self.disable_telemetry
            and (self.posthog_project_key not in (UNSET, None, ""))
            and (self.posthog_host is not None)
        )

    @property
    def diverted(self) -> bool:
        """Check if telemetry is diverted to a custom PostHog project. This is a convenience property to give you assurance that you're not sending telemetry to our PostHog instance."""
        return (
            self.enabled
            and self.posthog_project_key != CODEWEAVER_POSTHOG_PROJECT_KEY
            and self.posthog_project_key is not None
        )

    def _telemetry_keys(self) -> None:
        return None


_telemetry_settings: TelemetrySettings | None = None


class TelemetrySettingsDict(TypedDict, total=False):
    """TypedDict for Telemetry settings.

    Not intended to be used directly; used for internal type checking and validation.
    """

    disable_telemetry: NotRequired[bool | Unset]
    tools_over_privacy: NotRequired[bool | Unset]
    posthog_project_key: NotRequired[LiteralStringT | Unset]
    posthog_host: NotRequired[HttpUrl | None]
    batch_size: NotRequired[PositiveInt | Unset]
    batch_interval_seconds: NotRequired[PositiveInt | Unset]


DefaultTelemetrySettings = TelemetrySettingsDict(
    TelemetrySettings().model_dump(exclude_none=True, exclude_computed_fields=True)
)


__all__ = ("DefaultTelemetrySettings", "TelemetrySettings", "TelemetrySettingsDict")
