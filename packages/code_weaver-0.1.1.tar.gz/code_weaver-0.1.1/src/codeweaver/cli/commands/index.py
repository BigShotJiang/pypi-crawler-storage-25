# SPDX-FileCopyrightText: 2025 Knitli Inc.
# SPDX-FileContributor: Adam Poulemanos <adam@knit.li>
#
# SPDX-License-Identifier: MIT OR Apache-2.0

"""CodeWeaver indexing command-line interface."""

from __future__ import annotations

import sys

from pathlib import Path
from typing import TYPE_CHECKING, Annotated, Any

import cyclopts

from cyclopts import App
from pydantic import FilePath

from codeweaver.cli.dependencies import setup_cli_di
from codeweaver.cli.ui import (
    CLIErrorHandler,
    IndexingProgress,
    StatusDisplay,
    get_display,
    handle_keyboard_interrupt_gracefully,
)
from codeweaver.core import CodeWeaverError, SettingsMapDep
from codeweaver.core.config.types import CodeWeaverSettingsDict
from codeweaver.core.constants import ONE_MINUTE
from codeweaver.core.di.dependency import INJECTED
from codeweaver.core.types import UNSET, DictView
from codeweaver.engine import CheckpointManager, FileManifestManager
from codeweaver.engine.services.indexing_service import IndexingService
from codeweaver.providers import VectorStoreProvider


if TYPE_CHECKING:
    from codeweaver.engine.config.root_settings import CodeWeaverEngineSettings

_display: StatusDisplay = get_display()

app = App("index", help="Index codebase for semantic search.", console=_display.console)


def _settings_map(settings: SettingsMapDep = INJECTED) -> DictView[CodeWeaverSettingsDict]:
    """Get the settings map."""
    return settings


async def _check_server_health() -> bool:
    """Check if CodeWeaver server is running.

    Returns:
        True if server is running and healthy
    """
    import httpx

    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(f"{_get_url()}/health", timeout=2.0)
    except (httpx.ConnectError, httpx.TimeoutException):
        return False
    else:
        return response.status_code == 200


async def _derive_collection_name(
    settings: CodeWeaverEngineSettings, project_path: Path, checkpoint_mgr: CheckpointManager
) -> str:
    """Derive collection name from settings or checkpoint.

    Args:
        settings: Settings object containing configuration
        project_path: Path to project root
        checkpoint_mgr: Checkpoint manager instance

    Returns:
        Derived collection name string
    """
    from codeweaver.core import generate_collection_name
    from codeweaver.providers import ProviderSettings

    # Default collection name
    collection_name = generate_collection_name()

    # Check checkpoint file
    if checkpoint_file := checkpoint_mgr.checkpoint_file:
        return checkpoint_file.stem.replace("checkpoint_", "")

    # Check provider settings
    if (
        (provider_settings := settings.provider)
        and isinstance(provider_settings, ProviderSettings)
        and (vector_settings := provider_settings.vector_store)
        and vector_settings is not UNSET
    ):
        return (
            vector_settings[0].collection.collection_name
            if isinstance(vector_settings, tuple) and len(vector_settings) > 0
            else vector_settings.collection.collection_name  # ty:ignore[unresolved-attribute, invalid-return-type]
        )
    return collection_name


async def _perform_clear_operation(
    settings: CodeWeaverEngineSettings, project_path: Path, *, yes: bool, display: StatusDisplay
) -> None:
    """Clear vector store and checkpoints.

    Args:
        settings: Settings object containing configuration
        project_path: Path to project root
        yes: If True, skip confirmation prompt
        display: StatusDisplay for output

    Raises:
        CodeWeaverError: If operation fails
    """
    from codeweaver.core import get_container

    if not yes:
        display.print_warning("⚠ Warning: Destructive Operation")
        display.console.print()
        display.console.print("This will [red]permanently delete[/red]:")
        display.console.print("  • Vector store collection and all indexed data")
        display.console.print("  • All indexing checkpoints")
        display.console.print("  • File manifest state")
        display.console.print()

        response = display.console.input(
            "[yellow]Are you sure you want to continue? (yes/no):[/yellow] "
        )
        if response.lower() not in {"yes", "y"}:
            display.print_info("Operation cancelled")
            sys.exit(0)

    display.print_info("Clearing vector store and checkpoints...")

    container = get_container()

    # Resolve managers
    checkpoint_mgr = await container.resolve(CheckpointManager)
    manifest = await container.resolve(FileManifestManager)

    # Resolve vector store
    store = await container.resolve(VectorStoreProvider)

    # Derive collection name
    collection_name = await _derive_collection_name(settings, project_path, checkpoint_mgr)

    await store._initialize()
    await_result = await store.delete_collection(collection_name)

    if await_result:
        display.print_success(f"Vector store collection '{collection_name}' deleted")
    else:
        display.print_info(f"Vector store collection '{collection_name}' did not exist")

    # Clear checkpoints and manifests
    await checkpoint_mgr.delete()
    display.print_success("Checkpoints cleared")
    await manifest.delete()
    display.print_success("File manifest cleared")

    display.print_success("Clear operation complete")
    display.console.print()


async def _handle_server_status(*, standalone: bool, display: StatusDisplay) -> bool:
    """Check server status and inform user.

    Args:
        standalone: If True, skip server check
        display: StatusDisplay for output

    Returns:
        True if should proceed with standalone indexing, False to exit
    """
    if standalone:
        return True

    if await _check_server_health():
        return _check_and_print_server_status(display)
    display.print_warning("Server not running")
    display.print_info("Running standalone indexing")
    display.console.print("[dim]Tip: Start server with 'cw server' for automatic indexing[/dim]")
    display.console.print()
    return True


def _get_url():
    settings_map = _settings_map()
    host = settings_map.get("management_host", "localhost")
    port = settings_map.get("management_port", 9329)
    return f"http://{host}:{port}"


def _check_and_print_server_status(display: StatusDisplay):
    display.console.print()
    display.print_success(
        "Good news: Server is running. Your **codebase is indexed automatically**!"
    )
    display.console.print()
    display.print_info("The CodeWeaver server automatically indexes your codebase")
    display.console.print(
        "  • Initial indexing runs on server startup if the index is missing or incomplete."
    )
    display.console.print(
        "  • CodeWeaver indexes most codebases in under a minute (meaning discovering, parsing, and chunking files), but the biggest factor is your choice of embedding provider. If you're generating embeddings locally and want indexing to finish quickly, consider getting lunch while you wait. 🍔"
    )
    display.console.print(
        "  • While CodeWeaver runs, it continuously monitors your codebase for changes, and updates the index in real-time. It also picks up changes when the server restarts."
    )
    display.console.print()
    display.console.print("[cyan]To check indexing status while the server is running:[/cyan]")
    display.console.print()
    display.console.print("   run: 'cw status'")
    display.console.print(f"  curl {_get_url()}/health | jq '.indexer'")
    display.console.print()
    display.console.print(
        "[dim]Tip: Use --standalone to run indexing without running the server.[/dim]"
    )
    return False


async def _run_standalone_indexing(
    settings: CodeWeaverEngineSettings, *, force_reindex: bool, display: StatusDisplay
) -> None:
    """Run standalone indexing operation.

    Args:
        settings: Settings object containing configuration
        force_reindex: If True, force full reindex
        display: StatusDisplay for output

    Raises:
        CodeWeaverError: If indexing fails
    """
    from codeweaver.core import get_container

    display.print_info("Initializing indexer...")

    container = get_container()
    indexing_service = await container.resolve(IndexingService)

    # Check if sparse embeddings are configured
    # We can check the service's private attribute if accessible or check settings
    # For now, let's assume if the service was created, it has what it needs.
    # The progress tracker needs to know if sparse is enabled.
    # We can inspect the service or check config.
    # Accessing private attribute _sparse_provider for UI hint logic is acceptable here.
    has_sparse = getattr(indexing_service, "_sparse_provider", None) is not None

    # Create progress tracker with batch support
    progress_tracker = IndexingProgress(console=display.console, has_sparse=has_sparse)

    # Track files in current batch for complete_batch
    current_batch_files = [0]  # Use list to allow mutation in closure

    # Create callback that maps to the new IndexingProgress methods
    def progress_callback(
        phase: str, current: int, total: int, *, extra: dict[str, Any] | None = None
    ) -> None:
        if phase == "batch_start":
            if current == 0:
                # Initial setup - start with total batches
                total_files = extra.get("total_files", 0) if extra else 0
                progress_tracker.start(total_batches=total, total_files=total_files)
            else:
                # Start of a specific batch
                files_in_batch = extra.get("files_in_batch", 0) if extra else 0
                current_batch_files[0] = files_in_batch
                progress_tracker.start_batch(current, files_in_batch)
        elif phase == "batch_complete":
            progress_tracker.complete_batch(current_batch_files[0])
            current_batch_files[0] = 0
        elif phase == "discovery":
            # Legacy discovery callback - maps to checking
            progress_tracker.update_discovery(current, total)
        elif phase == "checking":
            progress_tracker.update_checking(current, total)
        elif phase == "chunking":
            chunks_created = extra.get("chunks_created", 0) if extra else 0
            progress_tracker.update_chunking(current, total, chunks_created)
        elif phase == "dense_embedding":
            progress_tracker.update_dense_embedding(current, total)
        elif phase == "sparse_embedding":
            progress_tracker.update_sparse_embedding(current, total)
        elif phase == "embedding":
            # Legacy embedding callback - maps to dense
            progress_tracker.update_embedding(current, total)
        elif phase == "indexing":
            progress_tracker.update_indexing(current, total)

    display.print_success("Starting indexing process...")

    with progress_tracker:
        _ = await indexing_service.index_project(
            force_reindex=force_reindex, progress_callback=progress_callback
        )
        progress_tracker.complete()

    # Display final summary
    stats = indexing_service.stats
    display.console.print()
    display.print_success("Indexing Complete!")
    display.console.print()
    display.console.print(f"  Files processed: [cyan]{stats.files_processed}[/cyan]")
    display.console.print(f"  Chunks created: [cyan]{stats.chunks_created}[/cyan]")
    display.console.print(f"  Chunks indexed: [cyan]{stats.chunks_indexed}[/cyan]")
    display.console.print(
        f"  Processing rate: [cyan]{stats.processing_rate():.2f}[/cyan] files/sec"
    )

    # Format elapsed time in human-readable format
    elapsed = stats.elapsed_time()
    if elapsed >= 3600:
        hours = int(elapsed // 3600)
        minutes = int((elapsed % 3600) // ONE_MINUTE)
        seconds = int(elapsed % ONE_MINUTE)
        human_time = f"{hours}h {minutes}m {seconds}s"
    elif elapsed >= ONE_MINUTE:
        minutes = int(elapsed // ONE_MINUTE)
        seconds = int(elapsed % ONE_MINUTE)
        human_time = f"{minutes}m {seconds}s"
    else:
        human_time = f"{elapsed:.1f}s"
    display.console.print(f"  Time elapsed: [cyan]{human_time}[/cyan]")

    if stats.total_errors() > 0:
        display.console.print(f"  [yellow]Files with errors: {stats.total_errors()}[/yellow]")

    sys.exit(0)


@app.default
async def index(
    *,
    config_file: Annotated[FilePath | None, cyclopts.Parameter(name=["--config", "-c"])] = None,
    project_path: Annotated[Path | None, cyclopts.Parameter(name=["--project", "-p"])] = None,
    force_reindex: Annotated[
        bool, cyclopts.Parameter(name=["--force", "-f"], help="Force full reindex")
    ] = False,
    standalone: Annotated[
        bool, cyclopts.Parameter(name=["--standalone", "-s"], help="Run indexing without server")
    ] = False,
    clear: Annotated[
        bool,
        cyclopts.Parameter(
            name=["--clear"],
            help="Clear vector store and checkpoints before indexing (requires confirmation)",
        ),
    ] = False,
    yes: Annotated[
        bool,
        cyclopts.Parameter(
            name=["--yes", "-y"], help="Skip confirmation prompts (use with --clear)"
        ),
    ] = False,
    verbose: Annotated[
        bool,
        cyclopts.Parameter(name=["--verbose", "-v"], help="Enable verbose logging with timestamps"),
    ] = False,
    debug: Annotated[
        bool, cyclopts.Parameter(name=["--debug", "-d"], help="Enable debug logging")
    ] = False,
) -> None:
    """Index or re-index a codebase.

    By default, checks if server is running and informs user about auto-indexing.
    Use --standalone to run indexing without server.

    Examples:
        cw index                  # Check server status
        cw index --force          # Force full re-index in standalone mode
        cw index --standalone     # Standalone indexing
        cw index --clear          # Clear vector store and re-index (with confirmation)
        cw index --clear --yes    # Clear and re-index without confirmation

    Args:
        config_file: Optional path to CodeWeaver configuration file
        project_path: Optional path to project root directory
        force_reindex: If True, skip persistence checks and reindex everything
        standalone: If True, run indexing without checking for server
        clear: If True, clear vector store and checkpoints before indexing
        yes: If True, skip confirmation prompts
    """
    display = _display or get_display()
    error_handler = CLIErrorHandler(display, verbose=verbose, debug=debug)
    from codeweaver.core import is_wsl_vscode

    if is_wsl_vscode():
        display.print_warning(
            "It looks like you're running CodeWeaver inside WSL in a VSCode terminal. In our testing, we found indexing in that environment would cause the vscode server to crash. Until we can resolve this, we recommend running CodeWeaver either directly in a WSL terminal (outside vscode), in a native Linux or Windows environment, for a better experience. **You can use Codeweaver with vscode** -- just run it outside a vscode terminal.  See issue [#135](https://github.com/knitli/codeweaver/issues/135)."
        )
        display.print_info("If you have already indexed your codebase, you'll probably be OK.")

    try:
        # Setup DI Container
        container = setup_cli_di(config_file, project_path, verbose=verbose)

        # We need to retrieve settings from the container now
        from codeweaver.core.config.settings_type import CodeWeaverSettingsType

        settings = await container.resolve(CodeWeaverSettingsType)

        # Handle --clear flag
        if clear:
            await _perform_clear_operation(
                settings, Path(str(settings.project_path)), yes=yes, display=display
            )
            force_reindex = True  # Continue to reindex after clearing

        # Check server status and decide whether to proceed
        if not await _handle_server_status(standalone=standalone, display=display):
            return  # Server is running, exit early

        # Standalone indexing
        await _run_standalone_indexing(settings, force_reindex=force_reindex, display=display)

    except CodeWeaverError as e:
        error_handler.handle_error(e, "Indexing", exit_code=1)

    except KeyboardInterrupt:
        display.console.print()
        display.print_warning("Indexing cancelled by user")
        sys.exit(130)

    except Exception as e:
        error_handler.handle_error(e, "Indexing", exit_code=1)


def main() -> None:
    """Entry point for the CodeWeaver index CLI."""
    display = StatusDisplay()
    error_handler = CLIErrorHandler(display, verbose=True, debug=True)

    with handle_keyboard_interrupt_gracefully():
        try:
            app()
        except Exception as e:
            error_handler.handle_error(e, "Index Command", exit_code=1)


if __name__ == "__main__":
    main()

__all__ = ()
