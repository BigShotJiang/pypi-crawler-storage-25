# SPDX-FileCopyrightText: 2025 Knitli Inc.
# SPDX-FileContributor: Adam Poulemanos <adam@knit.li>
#
# SPDX-License-Identifier: MIT OR Apache-2.0

"""FastMCP Server Creation and Lifespan Management for CodeWeaver.

This module handles the setup, configuration, and instantiation of FastMCP servers. **It does not *start* the servers;** instead, it provides factory functions to create server instances configured for either HTTP or stdio transport.
"""

from __future__ import annotations

import logging

from collections.abc import AsyncIterator, Container
from typing import TYPE_CHECKING, Any, Literal, cast, overload

from fastmcp import FastMCP
from fastmcp.client.transports import StreamableHttpTransport
from fastmcp.server import create_proxy
from fastmcp.server.providers.proxy import FastMCPProxy, ProxyClient
from fastmcp.tools import Tool
from lateimport import lateimport

from codeweaver.core import UNSET, DictView, SettingsMapDep, StatisticsDep
from codeweaver.core.constants import DEFAULT_MCP_PORT, LOCALHOST, MCP_ENDPOINT
from codeweaver.core.di.dependency import INJECTED
from codeweaver.server.config import (
    FastMcpHttpRunArgs,
    FastMcpHttpServerSettings,
    FastMcpServerSettingsDict,
    FastMcpStdioServerSettings,
    MiddlewareOptions,
    default_for_transport,
)
from codeweaver.server.mcp import McpMiddleware
from codeweaver.server.mcp.middleware import StatisticsMiddleware


if TYPE_CHECKING:
    from codeweaver.core.config.types import CodeWeaverSettingsDict
    from codeweaver.core.statistics import SessionStatistics
    from codeweaver.server.config import FastMcpServerSettingsDict
    from codeweaver.server.mcp.state import CwMcpHttpState


TOOLS_TO_REGISTER = ("find_code",)

type StdioClientLifespan = AsyncIterator[Any]


def _get_statistics(stats: StatisticsDep = INJECTED) -> SessionStatistics:
    return stats


def _get_fastmcp_settings_map(
    *, http: bool = False, settings_map: SettingsMapDep = INJECTED
) -> DictView[FastMcpServerSettingsDict]:
    """Get the current settings."""
    if http:
        return (
            settings_map.get_subview("mcp_server")
            if settings_map.get("mcp_server") is not UNSET
            else DictView(FastMcpServerSettingsDict(**FastMcpHttpServerSettings().as_settings()))
        )
    return (
        settings_map.get_subview("stdio_server")
        if settings_map.get("stdio_server") is not UNSET
        else DictView(FastMcpServerSettingsDict(**FastMcpStdioServerSettings().as_settings()))
    )


def _get_middleware_settings(
    settings_map: SettingsMapDep = INJECTED,
) -> DictView[MiddlewareOptions] | None:
    """Get the current middleware settings."""
    return (
        settings_map.get_subview("middleware")
        if settings_map.get("middleware") is not UNSET
        else None
    )


def _get_default_middleware() -> Container[type[McpMiddleware]]:
    """Get the default middleware for the application."""
    from codeweaver.server.mcp.middleware import default_middleware_for_transport

    fastmcp_settings = _get_fastmcp_settings_map()
    transport = fastmcp_settings.get("transport", "streamable-http")
    return default_middleware_for_transport(transport)


def get_statistics_middleware(
    settings: MiddlewareOptions | DictView[MiddlewareOptions] | None = None,
    statistics: SessionStatistics | None = None,
) -> StatisticsMiddleware:
    """Get the statistics middleware instance."""
    from codeweaver.server.mcp.middleware.statistics import StatisticsMiddleware

    settings = settings or _get_middleware_settings()
    statistics = statistics or _get_statistics()

    return StatisticsMiddleware(
        statistics=statistics,
        logger=logging.getLogger("codeweaver.server.mcpmiddleware.statistics"),
        log_level=(settings or {}).get("logging", {}).get("log_level", 30),  # ty:ignore[unresolved-attribute]
    )


def configure_uvicorn_logging(
    run_args: FastMcpHttpRunArgs,
    host: str | None = None,
    port: int | None = None,
    *,
    verbose: bool = False,
    debug: bool = False,
) -> FastMcpHttpRunArgs:
    """Configure uvicorn logging based on verbosity settings."""
    # Make a mutable copy to avoid modifying the input
    mutable_run_args = dict(run_args)
    uvicorn_config = dict(mutable_run_args.get("uvicorn_config", {}))

    # host, port, and name go in run_args top-level only (FastMCP extracts them)
    # Also filter out invalid uvicorn.Config parameters
    invalid_params = {"host", "port", "name", "data_header"}  # data_header should be date_header
    uvicorn_config = {k: v for k, v in uvicorn_config.items() if k not in invalid_params}

    # Update mutable_run_args with the cleaned uvicorn_config
    mutable_run_args["uvicorn_config"] = uvicorn_config

    if port:
        mutable_run_args["port"] = port
    if host:
        mutable_run_args["host"] = host

    if verbose or debug:
        # Verbose/debug mode: Enable uvicorn access logs
        mutable_run_args["uvicorn_config"] = {
            **uvicorn_config,
            "access_log": True,  # Enable access logging in verbose mode
            "log_level": "debug" if debug else "info",  # Match verbosity level
        }
        return FastMcpHttpRunArgs(**mutable_run_args)
    # Non-verbose mode: Suppress all uvicorn logging
    # Just set log_level to critical and disable access_log
    # Don't pass custom log_config as it's complex to get right with Pydantic validation
    mutable_run_args["uvicorn_config"] = {
        **uvicorn_config,
        "access_log": False,  # Disable access logging
        "log_level": "critical",  # Only critical errors (minimal logging)
    }
    return FastMcpHttpRunArgs(**mutable_run_args)


def setup_runargs(
    run_args: FastMcpHttpRunArgs | DictView[FastMcpHttpRunArgs],
    host: str | None,
    port: int | None,
    *,
    verbose: bool = False,
    debug: bool = False,
) -> FastMcpHttpRunArgs:
    """Setup run arguments for the server."""
    mutable_run_args = dict(run_args) if isinstance(run_args, DictView) else run_args
    # Configure uvicorn logging and clean up host/port from uvicorn_config
    return configure_uvicorn_logging(
        FastMcpHttpRunArgs(**mutable_run_args), host=host, port=port, verbose=verbose, debug=debug
    )


def _attempt_import(mw: str) -> type[McpMiddleware] | None:
    """Attempt to import a middleware class from a string."""
    from importlib import import_module

    try:
        imported = import_module(mw.rsplit(".", 1)[0])
        imported = getattr(imported, mw.rsplit(".", 1)[1])
        if isinstance(imported, type) and issubclass(imported, McpMiddleware):
            return imported
    except (ImportError, AttributeError):
        logging.getLogger("codeweaver.server.mcp.server").warning(
            "Failed to import middleware class '%s'", mw
        )
    return None


def setup_middleware(
    middleware: Container[type[McpMiddleware]],
    middleware_settings: MiddlewareOptions | DictView[MiddlewareOptions],
) -> set[McpMiddleware]:
    """Setup middleware for the application."""
    # Convert container to set for modification
    result: set[McpMiddleware] = set()

    def _get_mw_name(mw: Any) -> str:
        return str(getattr(mw, "__name__", type(mw).__name__))

    # Apply middleware settings
    # ty gets very confused here, so we ignore most issues

    for mw in middleware:  # type: ignore
        mw_name = _get_mw_name(mw)
        match mw_name:
            case "ErrorHandlingMiddleware":
                instance = mw(
                    **(
                        middleware_settings.get("error_handling", {})
                        | {"logger": logging.getLogger("codeweaver.middleware.error_handling")}  # type: ignore[reportCallIssue]
                    )
                )
            case "RetryMiddleware":
                instance = mw(
                    **(middleware_settings.get("retry", {}))
                    | {"logger": logging.getLogger("codeweaver.middleware.retry")}  # type: ignore[reportCallIssue]
                )
            case "RateLimitingMiddleware":
                instance = mw(**middleware_settings.get("rate_limiting", {}))  # type: ignore[reportCallIssue]
            case "LoggingMiddleware" | "StructuredLoggingMiddleware":
                instance = mw(
                    **(middleware_settings.get("logging", {}))
                    | {"logger": logging.getLogger("codeweaver.middleware._logging")}  # type: ignore[reportCallIssue]
                )
            case "ResponseCachingMiddleware":
                instance = mw(**middleware_settings.get("caching", {}))  # type: ignore
            case _:
                if any_settings := middleware_settings.get(mw_name.lower()):
                    instance = mw(**any_settings)
                else:
                    instance = mw()
        result.add(instance)
    result.add(get_statistics_middleware(middleware_settings))
    return result


def register_middleware(
    app: FastMCP[StdioClientLifespan] | FastMCP[CwMcpHttpState],
    middleware: Container[type[McpMiddleware]],
    middleware_settings: MiddlewareOptions | DictView[MiddlewareOptions],
) -> FastMCP[StdioClientLifespan] | FastMCP[CwMcpHttpState]:
    """Register middleware with the application."""
    for mw in setup_middleware(middleware, middleware_settings):
        _ = app.add_middleware(mw)
    return app


def register_tools(
    app: FastMCP[StdioClientLifespan] | FastMCP[CwMcpHttpState],
) -> FastMCP[StdioClientLifespan] | FastMCP[CwMcpHttpState]:
    """Register tools with the application."""
    from codeweaver.server.mcp.tools import TOOL_DEFINITIONS, register_tool

    for tool_name in TOOLS_TO_REGISTER:
        if tool_name not in TOOL_DEFINITIONS:
            continue
        app = register_tool(
            app,
            tool if (tool := TOOL_DEFINITIONS[tool_name]) and isinstance(tool, Tool) else tool(app),
        )
    return app


@overload
def _setup_server(
    args: DictView[FastMcpServerSettingsDict],
    transport: Literal["stdio"],
    host: None = None,
    port: None = None,
    *,
    verbose: Literal[False] = False,
    debug: Literal[False] = False,
) -> FastMCP[StdioClientLifespan]: ...
@overload
def _setup_server(
    args: DictView[FastMcpServerSettingsDict],
    transport: Literal["streamable-http"],
    host: str | None = None,
    port: int | None = None,
    *,
    verbose: bool,
    debug: bool,
) -> CwMcpHttpState: ...
def _setup_server[TransportT: Literal["stdio", "streamable-http"]](
    args: DictView[FastMcpServerSettingsDict],
    transport: TransportT,
    host: str | None = None,
    port: int | None = None,
    *,
    verbose: bool = False,
    debug: bool = False,
) -> FastMCP[StdioClientLifespan] | CwMcpHttpState:
    """Set class args for FastMCP server settings."""
    is_http = transport == "streamable-http"
    # Use transport parameter as the primary indicator for HTTP transport
    middleware_opts = _get_middleware_settings() or default_for_transport(
        "streamable-http" if is_http else "stdio"
    )
    mutable_args = dict(args)
    # Middleware in settings is just configuration names/options, not classes
    # Remove it from args and always use default middleware classes for the transport
    mutable_args.pop("middleware", None)
    run_args = mutable_args.pop("run_args", {})
    # Remove transport from args - it's not a FastMCP constructor parameter
    mutable_args.pop("transport", None)
    # FastMCP v3: include_tags/exclude_tags are no longer constructor parameters.
    # Extract them here and apply via app.enable()/app.disable() after construction.
    include_tags: set[str] | None = mutable_args.pop("include_tags", None)
    exclude_tags: set[str] | None = mutable_args.pop("exclude_tags", None)

    # Always use default middleware classes for this transport
    from codeweaver.server.mcp.middleware import default_middleware_for_transport

    middleware = default_middleware_for_transport(transport)

    if is_http:
        run_args = setup_runargs(run_args, host, port, verbose=verbose, debug=debug)
    app = FastMCP(
        "CodeWeaver",
        **(mutable_args | {"icons": [lateimport("codeweaver.server", "CODEWEAVER_SVG_ICON")]}),
    )
    app = register_tools(app)
    app = register_middleware(app, cast(list[type[McpMiddleware]], middleware), middleware_opts)
    # FastMCP v3: Apply tag-based visibility filtering using the new enable()/disable() API
    if exclude_tags:
        app.disable(tags=exclude_tags)
    if include_tags:
        app.enable(tags=include_tags, only=True)
    if is_http:
        from codeweaver.server.mcp.state import CwMcpHttpState

        # Pass the instantiated middleware from app.middleware, not the classes
        return CwMcpHttpState.from_app(
            app, **(mutable_args | {"run_args": run_args, "middleware": app.middleware})
        )
    return cast(FastMCP[StdioClientLifespan], app)


# Note: FastMCP's parameterized type is the server's lifespan. For stdio servers, the client manages lifespan, so we use AsyncIterator[Any] aliased as StdioClientLifespan.
async def create_stdio_server(
    *,
    settings: CodeWeaverSettingsDict | None = None,
    host: str | None = None,
    port: int | None = None,
    verbose: bool = False,
    debug: bool = False,
) -> FastMCPProxy:
    """Get a FastMCP server configured for stdio transport.

    Args:
        settings: Optional FastMCP server settings dictionary, constructed when a custom config file is passed to the main CLI.
        host: Optional host for the server (this is the host/port for the *codeweaver http mcp server* that the stdio client will be proxied to -- only needed if not default or not what's in your config).
        port: Optional port for the server (this is the host/port for the *codeweaver http mcp server* that the stdio client will be proxied to -- only needed if not default or not what's in your config).
        verbose: Enable verbose logging.
        debug: Enable debug logging.

    Returns:
        Configured FastMCP stdio server instance.
    """
    if settings and (stdio_settings := settings.get("stdio_server")) is not UNSET:
        stdio_settings = DictView(FastMcpServerSettingsDict(**cast(dict, stdio_settings)))
    else:
        stdio_settings = _get_fastmcp_settings_map(http=False)
    # Derive the stdio server name directly from settings instead of constructing
    # a full FastMCP app instance just to access `app.name`.
    stdio_name = cast(str | None, stdio_settings.get("name"))
    if settings and (http_settings := settings.get("mcp_server")) is not UNSET:
        http_settings = DictView(FastMcpServerSettingsDict(**cast(dict, http_settings)))
    else:
        http_settings = _get_fastmcp_settings_map(http=True)
    run_args = http_settings.get("run_args", {})
    resolved_host = host or run_args.get("host", LOCALHOST)
    resolved_port = port or run_args.get("port", DEFAULT_MCP_PORT)
    url = f"http://{resolved_host}:{resolved_port}{http_settings.get('path', MCP_ENDPOINT)}"
    # FastMCP v3: Replace app.as_proxy() with create_proxy()
    # create_proxy() takes a target (URL, transport, client, etc.) and settings
    return create_proxy(
        target=ProxyClient(transport=StreamableHttpTransport(url=url)),
        name=stdio_name or cast(str, http_settings.get("name", "codeweaver-mcp")),
    )


async def create_http_server(
    *, host: str | None = None, port: int | None = None, verbose: bool = False, debug: bool = False
) -> CwMcpHttpState:
    """Get a FastMCP server configured for HTTP transport."""
    http_settings = _get_fastmcp_settings_map(http=True)
    return _setup_server(
        http_settings,
        transport="streamable-http",
        host=host,
        port=port,
        verbose=verbose,
        debug=debug,
    )


__all__ = (
    "TOOLS_TO_REGISTER",
    "StdioClientLifespan",
    "configure_uvicorn_logging",
    "create_http_server",
    "create_stdio_server",
    "get_statistics_middleware",
    "register_middleware",
    "register_tools",
    "setup_middleware",
    "setup_runargs",
)
