# SPDX-FileCopyrightText: 2026 Knitli Inc.
#
# SPDX-License-Identifier: MIT OR Apache-2.0

"""The engine package contains core functionality for indexing, chunking, and searching code and documentation data, but also for other data providers 🚋."""

from __future__ import annotations


parent = __spec__.parent or "codeweaver.engine"

# === MANAGED EXPORTS ===

# Exportify manages this section. It contains lazy-loading infrastructure
# for the package: imports and runtime declarations (__all__, __getattr__,
# __dir__). Manual edits will be overwritten by `exportify fix`.

from types import MappingProxyType
from typing import TYPE_CHECKING

from lateimport import create_late_getattr


if TYPE_CHECKING:
    from codeweaver.engine.chunker.base import AdaptiveChunkBehavior, BaseChunker, ChunkGovernor
    from codeweaver.engine.chunker.delimiter import DelimiterChunker, StringParseState
    from codeweaver.engine.chunker.delimiter_model import Boundary, Delimiter, DelimiterMatch
    from codeweaver.engine.chunker.delimiters.families import (
        PatternKey,
        detect_family_characteristics,
        detect_language_family,
        get_family_patterns,
    )
    from codeweaver.engine.chunker.delimiters.patterns import expand_pattern
    from codeweaver.engine.chunker.exceptions import (
        ASTDepthExceededError,
        BinaryFileError,
        ChunkingError,
        ChunkingTimeoutError,
        ChunkLimitExceededError,
        OversizedChunkError,
        ParseError,
    )
    from codeweaver.engine.chunker.governance import ResourceGovernor
    from codeweaver.engine.chunker.parallel import chunk_files_parallel
    from codeweaver.engine.chunker.registry import SourceIdRegistry
    from codeweaver.engine.chunker.selector import ChunkerSelector, GracefulChunker
    from codeweaver.engine.chunker.semantic import SemanticChunker
    from codeweaver.engine.config.chunker import (
        ChunkerSettings,
        ChunkerSettingsDict,
        ConcurrencySettings,
        ConcurrencySettingsDict,
        CustomDelimiter,
        CustomLanguage,
        DefaultChunkerSettings,
        PerformanceSettings,
        PerformanceSettingsDict,
    )
    from codeweaver.engine.config.failover import (
        DefaultFailoverSettings,
        FailoverSettings,
        FailoverSettingsDict,
    )
    from codeweaver.engine.config.failover_detector import FailoverDetector, LocalEmbeddingDetector
    from codeweaver.engine.config.indexer import (
        DefaultIndexerSettings,
        FilteredPaths,
        IndexerSettings,
        IndexerSettingsDict,
        RignoreSettings,
    )
    from codeweaver.engine.config.root_settings import CodeWeaverEngineSettings
    from codeweaver.engine.dependencies import (
        CheckpointManagerDep,
        ChunkerSettingsDep,
        ChunkGovernorDep,
        ChunkingServiceDep,
        ConfigChangeAnalyzerDep,
        ExtensionFilterDep,
        FailoverServiceDep,
        FailoverSettingsDep,
        FileWatchingServiceDep,
        IgnoreFilterDep,
        IndexerSettingsDep,
        IndexingServiceDep,
        IndexingStatsDep,
        ManifestManagerDep,
        MigrationServiceDep,
        ProgressTrackerDep,
        SourceIdRegistryDep,
    )
    from codeweaver.engine.managers.checkpoint_manager import (
        ChangeImpact,
        CheckpointManager,
        CheckpointSettingsFingerprint,
        CheckpointSettingsMap,
        IndexingCheckpoint,
    )
    from codeweaver.engine.managers.manifest_manager import (
        FileManifestEntry,
        FileManifestManager,
        FileManifestStats,
        IndexFileManifest,
    )
    from codeweaver.engine.managers.progress_tracker import (
        IndexingErrorDict,
        IndexingPhase,
        IndexingProgressTracker,
        IndexingStats,
    )
    from codeweaver.engine.services.chunking_service import ChunkingService
    from codeweaver.engine.services.config_analyzer import (
        ConfigChangeAnalysis,
        ConfigChangeAnalyzer,
        TransformationDetails,
    )
    from codeweaver.engine.services.failover_service import FailoverService
    from codeweaver.engine.services.indexing_service import IndexingService, ProgressCallback
    from codeweaver.engine.services.migration_service import (
        ChunkResult,
        InvalidStateTransitionError,
        MigrationCheckpoint,
        MigrationError,
        MigrationResult,
        MigrationService,
        MigrationState,
        ValidationError,
        WorkItem,
    )
    from codeweaver.engine.services.reconciliation_service import (
        ReconciliationResult,
        RepairStats,
        VectorReconciliationService,
    )
    from codeweaver.engine.services.snapshot_service import QdrantSnapshotBackupService
    from codeweaver.engine.services.watching_service import FileWatchingService
    from codeweaver.engine.watcher._logging import WatchfilesLogManager
    from codeweaver.engine.watcher.progress import IndexingProgressUI
    from codeweaver.engine.watcher.types import FileChange, WatchfilesArgs
    from codeweaver.engine.watcher.watch_filters import (
        CodeFilter,
        ConfigFilter,
        DefaultExtensionFilter,
        DefaultFilter,
        DocsFilter,
        ExtensionFilter,
        IgnoreFilter,
    )

_dynamic_imports: MappingProxyType[str, tuple[str, str]] = MappingProxyType({
    "AdaptiveChunkBehavior": (__spec__.parent, "chunker.base"),
    "BaseChunker": (__spec__.parent, "chunker.base"),
    "BinaryFileError": (__spec__.parent, "chunker.exceptions"),
    "Boundary": (__spec__.parent, "chunker.delimiter_model"),
    "ChangeImpact": (__spec__.parent, "managers.checkpoint_manager"),
    "CheckpointManager": (__spec__.parent, "managers.checkpoint_manager"),
    "CheckpointManagerDep": (__spec__.parent, "dependencies"),
    "CheckpointSettingsFingerprint": (__spec__.parent, "managers.checkpoint_manager"),
    "CheckpointSettingsMap": (__spec__.parent, "managers.checkpoint_manager"),
    "ChunkerSelector": (__spec__.parent, "chunker.selector"),
    "ChunkerSettings": (__spec__.parent, "config.chunker"),
    "ChunkerSettingsDep": (__spec__.parent, "dependencies"),
    "ChunkerSettingsDict": (__spec__.parent, "config.chunker"),
    "ChunkGovernor": (__spec__.parent, "chunker.base"),
    "ChunkGovernorDep": (__spec__.parent, "dependencies"),
    "ChunkingError": (__spec__.parent, "chunker.exceptions"),
    "ChunkingService": (__spec__.parent, "services.chunking_service"),
    "ChunkingServiceDep": (__spec__.parent, "dependencies"),
    "ChunkingTimeoutError": (__spec__.parent, "chunker.exceptions"),
    "ChunkLimitExceededError": (__spec__.parent, "chunker.exceptions"),
    "ChunkResult": (__spec__.parent, "services.migration_service"),
    "CodeFilter": (__spec__.parent, "watcher.watch_filters"),
    "CodeWeaverEngineSettings": (__spec__.parent, "config.root_settings"),
    "ConcurrencySettings": (__spec__.parent, "config.chunker"),
    "ConcurrencySettingsDict": (__spec__.parent, "config.chunker"),
    "ConfigChangeAnalysis": (__spec__.parent, "services.config_analyzer"),
    "ConfigChangeAnalyzer": (__spec__.parent, "services.config_analyzer"),
    "ConfigChangeAnalyzerDep": (__spec__.parent, "dependencies"),
    "ConfigFilter": (__spec__.parent, "watcher.watch_filters"),
    "CustomDelimiter": (__spec__.parent, "config.chunker"),
    "CustomLanguage": (__spec__.parent, "config.chunker"),
    "DefaultChunkerSettings": (__spec__.parent, "config.chunker"),
    "DefaultExtensionFilter": (__spec__.parent, "watcher.watch_filters"),
    "DefaultFailoverSettings": (__spec__.parent, "config.failover"),
    "DefaultFilter": (__spec__.parent, "watcher.watch_filters"),
    "DefaultIndexerSettings": (__spec__.parent, "config.indexer"),
    "Delimiter": (__spec__.parent, "chunker.delimiter_model"),
    "DelimiterChunker": (__spec__.parent, "chunker.delimiter"),
    "DelimiterMatch": (__spec__.parent, "chunker.delimiter_model"),
    "DocsFilter": (__spec__.parent, "watcher.watch_filters"),
    "ExtensionFilter": (__spec__.parent, "watcher.watch_filters"),
    "ExtensionFilterDep": (__spec__.parent, "dependencies"),
    "FailoverDetector": (__spec__.parent, "config.failover_detector"),
    "FailoverService": (__spec__.parent, "services.failover_service"),
    "FailoverServiceDep": (__spec__.parent, "dependencies"),
    "FailoverSettings": (__spec__.parent, "config.failover"),
    "FailoverSettingsDep": (__spec__.parent, "dependencies"),
    "FailoverSettingsDict": (__spec__.parent, "config.failover"),
    "FileChange": (__spec__.parent, "watcher.types"),
    "FileManifestEntry": (__spec__.parent, "managers.manifest_manager"),
    "FileManifestManager": (__spec__.parent, "managers.manifest_manager"),
    "FileManifestStats": (__spec__.parent, "managers.manifest_manager"),
    "FileWatchingService": (__spec__.parent, "services.watching_service"),
    "FileWatchingServiceDep": (__spec__.parent, "dependencies"),
    "FilteredPaths": (__spec__.parent, "config.indexer"),
    "GracefulChunker": (__spec__.parent, "chunker.selector"),
    "IgnoreFilter": (__spec__.parent, "watcher.watch_filters"),
    "IgnoreFilterDep": (__spec__.parent, "dependencies"),
    "IndexerSettings": (__spec__.parent, "config.indexer"),
    "IndexerSettingsDep": (__spec__.parent, "dependencies"),
    "IndexerSettingsDict": (__spec__.parent, "config.indexer"),
    "IndexFileManifest": (__spec__.parent, "managers.manifest_manager"),
    "IndexingCheckpoint": (__spec__.parent, "managers.checkpoint_manager"),
    "IndexingErrorDict": (__spec__.parent, "managers.progress_tracker"),
    "IndexingPhase": (__spec__.parent, "managers.progress_tracker"),
    "IndexingProgressTracker": (__spec__.parent, "managers.progress_tracker"),
    "IndexingService": (__spec__.parent, "services.indexing_service"),
    "IndexingServiceDep": (__spec__.parent, "dependencies"),
    "IndexingStats": (__spec__.parent, "managers.progress_tracker"),
    "IndexingStatsDep": (__spec__.parent, "dependencies"),
    "InvalidStateTransitionError": (__spec__.parent, "services.migration_service"),
    "LocalEmbeddingDetector": (__spec__.parent, "config.failover_detector"),
    "ManifestManagerDep": (__spec__.parent, "dependencies"),
    "MigrationCheckpoint": (__spec__.parent, "services.migration_service"),
    "MigrationError": (__spec__.parent, "services.migration_service"),
    "MigrationResult": (__spec__.parent, "services.migration_service"),
    "MigrationService": (__spec__.parent, "services.migration_service"),
    "MigrationServiceDep": (__spec__.parent, "dependencies"),
    "MigrationState": (__spec__.parent, "services.migration_service"),
    "OversizedChunkError": (__spec__.parent, "chunker.exceptions"),
    "ParseError": (__spec__.parent, "chunker.exceptions"),
    "PatternKey": (__spec__.parent, "chunker.delimiters.families"),
    "PerformanceSettings": (__spec__.parent, "config.chunker"),
    "PerformanceSettingsDict": (__spec__.parent, "config.chunker"),
    "ProgressCallback": (__spec__.parent, "services.indexing_service"),
    "ProgressTrackerDep": (__spec__.parent, "dependencies"),
    "QdrantSnapshotBackupService": (__spec__.parent, "services.snapshot_service"),
    "ReconciliationResult": (__spec__.parent, "services.reconciliation_service"),
    "RepairStats": (__spec__.parent, "services.reconciliation_service"),
    "ResourceGovernor": (__spec__.parent, "chunker.governance"),
    "RignoreSettings": (__spec__.parent, "config.indexer"),
    "SemanticChunker": (__spec__.parent, "chunker.semantic"),
    "SourceIdRegistry": (__spec__.parent, "chunker.registry"),
    "SourceIdRegistryDep": (__spec__.parent, "dependencies"),
    "StringParseState": (__spec__.parent, "chunker.delimiter"),
    "TransformationDetails": (__spec__.parent, "services.config_analyzer"),
    "ValidationError": (__spec__.parent, "services.migration_service"),
    "VectorReconciliationService": (__spec__.parent, "services.reconciliation_service"),
    "WatchfilesArgs": (__spec__.parent, "watcher.types"),
    "WatchfilesLogManager": (__spec__.parent, "watcher._logging"),
    "WorkItem": (__spec__.parent, "services.migration_service"),
    "ASTDepthExceededError": (__spec__.parent, "chunker.exceptions"),
    "chunk_files_parallel": (__spec__.parent, "chunker.parallel"),
    "chunk_files_parallel_dict": (__spec__.parent, "chunker.parallel"),
    "detect_family_characteristics": (__spec__.parent, "chunker.delimiters.families"),
    "detect_language_family": (__spec__.parent, "chunker.delimiters.families"),
    "expand_pattern": (__spec__.parent, "chunker.delimiters.patterns"),
    "get_family_patterns": (__spec__.parent, "chunker.delimiters.families"),
    "IndexingProgressUI": (__spec__.parent, "watcher.progress"),
})

__getattr__ = create_late_getattr(_dynamic_imports, globals(), __name__)

__all__ = (
    "ASTDepthExceededError",
    "AdaptiveChunkBehavior",
    "BaseChunker",
    "BinaryFileError",
    "Boundary",
    "ChangeImpact",
    "CheckpointManager",
    "CheckpointManagerDep",
    "CheckpointSettingsFingerprint",
    "CheckpointSettingsMap",
    "ChunkGovernor",
    "ChunkGovernorDep",
    "ChunkLimitExceededError",
    "ChunkResult",
    "ChunkerSelector",
    "ChunkerSettings",
    "ChunkerSettingsDep",
    "ChunkerSettingsDict",
    "ChunkingError",
    "ChunkingService",
    "ChunkingServiceDep",
    "ChunkingTimeoutError",
    "CodeFilter",
    "CodeWeaverEngineSettings",
    "ConcurrencySettings",
    "ConcurrencySettingsDict",
    "ConfigChangeAnalysis",
    "ConfigChangeAnalyzer",
    "ConfigChangeAnalyzerDep",
    "ConfigFilter",
    "CustomDelimiter",
    "CustomLanguage",
    "DefaultChunkerSettings",
    "DefaultExtensionFilter",
    "DefaultFailoverSettings",
    "DefaultFilter",
    "DefaultIndexerSettings",
    "Delimiter",
    "DelimiterChunker",
    "DelimiterMatch",
    "DocsFilter",
    "ExtensionFilter",
    "ExtensionFilterDep",
    "FailoverDetector",
    "FailoverService",
    "FailoverServiceDep",
    "FailoverSettings",
    "FailoverSettingsDep",
    "FailoverSettingsDict",
    "FileChange",
    "FileManifestEntry",
    "FileManifestManager",
    "FileManifestStats",
    "FileWatchingService",
    "FileWatchingServiceDep",
    "FilteredPaths",
    "GracefulChunker",
    "IgnoreFilter",
    "IgnoreFilterDep",
    "IndexFileManifest",
    "IndexerSettings",
    "IndexerSettingsDep",
    "IndexerSettingsDict",
    "IndexingCheckpoint",
    "IndexingErrorDict",
    "IndexingPhase",
    "IndexingProgressTracker",
    "IndexingProgressUI",
    "IndexingService",
    "IndexingServiceDep",
    "IndexingStats",
    "IndexingStatsDep",
    "InvalidStateTransitionError",
    "LocalEmbeddingDetector",
    "ManifestManagerDep",
    "MigrationCheckpoint",
    "MigrationError",
    "MigrationResult",
    "MigrationService",
    "MigrationServiceDep",
    "MigrationState",
    "OversizedChunkError",
    "ParseError",
    "PatternKey",
    "PerformanceSettings",
    "PerformanceSettingsDict",
    "ProgressCallback",
    "ProgressTrackerDep",
    "QdrantSnapshotBackupService",
    "ReconciliationResult",
    "RepairStats",
    "ResourceGovernor",
    "RignoreSettings",
    "SemanticChunker",
    "SourceIdRegistry",
    "SourceIdRegistryDep",
    "StringParseState",
    "TransformationDetails",
    "ValidationError",
    "VectorReconciliationService",
    "WatchfilesArgs",
    "WatchfilesLogManager",
    "WorkItem",
    "chunk_files_parallel",
    "chunk_files_parallel_dict",
    "detect_family_characteristics",
    "detect_language_family",
    "expand_pattern",
    "get_family_patterns",
)


def __dir__() -> list[str]:
    """List available attributes for the package."""
    return list(__all__)
