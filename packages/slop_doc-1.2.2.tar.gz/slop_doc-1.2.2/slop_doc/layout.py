"""Stage 7: Layout Generator & HTML Output - generates the 3-column layout."""

from __future__ import annotations

import json
import os
import posixpath
from dataclasses import dataclass

from slop_doc.tree_builder import Node


def _assets_prefix(output_path: str) -> str:
    """Return the relative prefix needed to reach the output root from output_path."""
    depth = output_path.count('/')
    return '../' * depth


def _relative_url(from_path: str, to_path: str) -> str:
    """Compute a relative URL from from_path to to_path (both relative to output root)."""
    # Strip #anchor from both paths before computing relative path
    from_base = from_path.split('#')[0]
    anchor = ''
    if '#' in to_path:
        to_base, anchor = to_path.split('#', 1)
        anchor = '#' + anchor
    else:
        to_base = to_path
    from_dir = posixpath.dirname(from_base)
    rel = posixpath.relpath(to_base, from_dir) if from_dir else to_base
    return rel.replace('\\', '/') + anchor


class LayoutError(Exception):
    """Raised when layout generation fails."""
    pass


@dataclass
class BreadcrumbItem:
    """Represents a breadcrumb item."""
    title: str
    url: str


def generate_nav_tree(tree: list[Node], current: Node | None = None, expand_parents: bool = True) -> str:
    """Generate navigation tree HTML.

    Args:
        tree: The navigation tree.
        current: The current node (to highlight).
        expand_parents: Whether to expand parent nodes of current.

    Returns:
        HTML string for the navigation tree.
    """
    current_path = current.output_path if current else None
    html = '<ul class="nav-tree">\n'
    for node in tree:
        html += _generate_nav_node(node, current_path, current_path, expand_parents)
    html += '</ul>\n'
    return html


def _generate_nav_node(node: Node, current_path: str | None, page_path: str | None, expand_parents: bool) -> str:
    """Generate a single nav node and its children.

    Args:
        node: The node to render.
        current_path: output_path of the currently displayed page (for highlight).
        page_path: output_path of the page being assembled (for computing relative hrefs).
        expand_parents: Whether to expand parent nodes of current.

    Returns:
        HTML string for the node.
    """
    is_current = current_path is not None and node.output_path == current_path
    has_children = len(node.children) > 0
    is_container = not node.output_path and not node.content  # No output = container/group node

    if current_path is None:
        should_expand = True
    else:
        should_expand = expand_parents and _is_ancestor(node, current_path)

    classes = ['nav-item', 'no-select']
    if is_current:
        classes.append('active')
    if is_container:
        classes.append('nav-group')

    children_expanded = should_expand or is_current or is_container if has_children else False
    if has_children:
        classes.append('has-children')
        classes.append('expanded' if children_expanded else 'collapsed')

    classes_str = ' '.join(classes)
    # Stable ID for localStorage nav state persistence
    nav_id = (node.output_path or node.title or '').split('#')[0]
    nav_attr = f' data-nav-id="{nav_id}"' if has_children else ''
    html = f'<li class="{classes_str}"{nav_attr}>\n'

    if is_container or not node.output_path:
        # Container node — render as link that toggles children (no navigation)
        html += f'<a href="javascript:void(0)" class="nav-container">{node.title}</a>\n'
    else:
        href = _relative_url(page_path, node.output_path) if page_path else node.output_path
        extra = ' class="active"' if is_current else ''
        html += f'<a href="{href}"{extra}>{node.title}</a>\n'

    if has_children:
        # Always render children but control visibility via CSS class
        ul_class = 'expanded' if children_expanded else 'collapsed'
        html += f'<ul class="nav-children {ul_class}">\n'
        for child in node.children:
            html += _generate_nav_node(child, current_path, page_path, expand_parents)
        html += '</ul>\n'
        # Toggle arrow button (aligned right)
        html += '<span class="nav-toggle" aria-hidden="true"></span>\n'

    html += '</li>\n'
    return html


def _is_ancestor(ancestor: Node, descendant_path: str) -> bool:
    """Check if ancestor contains a node with descendant_path anywhere in its subtree."""
    # Strip #anchor for comparison (function nodes have page.html#func anchors)
    desc_base = descendant_path.split('#')[0]
    for child in ancestor.children:
        child_base = child.output_path.split('#')[0] if child.output_path else ''
        if child_base == desc_base or child.output_path == descendant_path:
            return True
        if _is_ancestor(child, descendant_path):
            return True
    return False


def generate_breadcrumb(node: Node, tree: list[Node]) -> list[BreadcrumbItem]:
    """Generate breadcrumb items for a node.

    Args:
        node: The current node.
        tree: The full navigation tree.

    Returns:
        List of BreadcrumbItems from root to current.
    """
    breadcrumb: list[BreadcrumbItem] = []

    # Find the path to this node
    path = _find_node_path(tree, node)

    for n in path:
        breadcrumb.append(BreadcrumbItem(title=n.title, url=n.output_path))

    return breadcrumb


def _find_node_path(tree: list[Node], target: Node, path: list[Node] | None = None) -> list[Node]:
    """Find the path from root to target node.

    Args:
        tree: The navigation tree.
        target: The target node.
        path: Current path (for recursion).

    Returns:
        List of nodes from root to target.
    """
    if path is None:
        path = []

    for node in tree:
        current_path = path + [node]
        if node.output_path == target.output_path:
            return current_path
        if node.children:
            result = _find_node_path(node.children, target, current_path)
            if result:
                return result

    return []


def generate_contents_sidebar(html_content: str) -> str:
    """Extract h2/h3 headings from HTML and generate contents sidebar.

    Args:
        html_content: The rendered HTML content.

    Returns:
        HTML string for the contents sidebar.
    """
    import re

    # Find all h2 and h3 with their ids - capture inner text properly
    pattern = r'<h([23])[^>]*id="([^"]+)"[^>]*>(.*?)</h[23]>'
    matches = re.findall(pattern, html_content, re.DOTALL)

    if not matches:
        return ""

    html = '<div class="contents-sidebar">\n'
    html += '<h4>Contents</h4>\n'
    html += '<ul>\n'

    for level, anchor_id, inner in matches:
        # Strip all HTML tags to get plain text
        text = re.sub(r'<[^>]+>', '', inner).strip()
        level_class = 'h2' if level == '2' else 'h3'
        html += f'<li class="{level_class}"><a href="#{anchor_id}">{text}</a></li>\n'

    html += '</ul>\n'
    html += '</div>\n'

    return html


def generate_search_index(
    tree: list[Node],
    source_data_by_folder: dict,
) -> str:
    """Generate search index JSON.

    Args:
        tree: The navigation tree.
        source_data_by_folder: Dict of source data by folder.

    Returns:
        JSON string for the search index.
    """
    index = []
    processed_sources = set()

    # Build a mapping from class name -> detail page URL
    class_page_urls = {}

    def scan_for_class_pages(node: Node):
        auto_class = getattr(node, 'auto_class', None)
        if auto_class and node.output_path:
            class_page_urls[auto_class] = node.output_path
        for child in node.children:
            scan_for_class_pages(child)

    for node in tree:
        scan_for_class_pages(node)

    # Build function URL map from function-link nav nodes in the tree
    import os as _os
    func_page_urls: dict[str, str] = {}  # func_name → "page.html#func_name"

    def scan_for_func_pages(node: Node):
        auto_fn = getattr(node, 'auto_function', None)
        if auto_fn and node.output_path:
            # output_path is already "parent/file.html#func_name"
            func_page_urls.setdefault(auto_fn, node.output_path)
        for child in node.children:
            scan_for_func_pages(child)

    for node in tree:
        scan_for_func_pages(node)

    def process_node(node: Node):
        # Skip function-link nav nodes (nav-only, no page entry)
        if getattr(node, 'auto_function', None):
            for child in node.children:
                process_node(child)
            return

        entry = {
            'title': node.title,
            'url': node.output_path,
            'type': 'page'
        }
        index.append(entry)

        # Add class and function names from source data (only once per source)
        if node.source and node.source not in processed_sources:
            processed_sources.add(node.source)
            if node.source in source_data_by_folder:
                source_data = source_data_by_folder[node.source]

                # Add classes with their detail page URL if found, else folder URL
                for cls in source_data.classes:
                    class_url = class_page_urls.get(cls.name, node.output_path)
                    index.append({
                        'title': cls.name,
                        'url': class_url,
                        'type': 'class'
                    })
                    # Add all methods (public, private, dunder) for search
                    for method in cls.methods:
                        index.append({
                            'title': f"{cls.name}.{method.name}",
                            'url': f"{class_url}#{method.name}",
                            'type': 'method'
                        })

                # Add module-level functions
                for func in source_data.functions:
                    func_url = func_page_urls.get(func.name, node.output_path)
                    index.append({
                        'title': func.name,
                        'url': func_url,
                        'type': 'function'
                    })

                # Add constants
                for const in source_data.constants:
                    index.append({
                        'title': const.name,
                        'url': node.output_path,
                        'type': 'constant'
                    })

        for child in node.children:
            process_node(child)

    for node in tree:
        process_node(node)

    return json.dumps(index, indent=2)


def assemble_page(
    content: str,
    node: Node,
    tree: list[Node],
    project_name: str,
    version: str,
    search_index: str = '',
    settings: dict | None = None,
) -> str:
    """Assemble a complete HTML page with 3-column layout.

    Args:
        content: The rendered page content (center column).
        node: The current node.
        tree: The navigation tree.
        project_name: Project name for header.
        version: Version string.
        search_index: JSON string for search index (embedded inline).
        settings: Optional project settings dict (editor, max_search_results, etc.).

    Returns:
        Complete HTML page.
    """
    prefix = _assets_prefix(node.output_path)

    # Generate navigation (with relative hrefs from this page)
    # Rebuild nav with relative hrefs specific to this page's location
    current_path = node.output_path
    nav_html = '<ul class="nav-tree">\n'
    for n in tree:
        nav_html += _generate_nav_node(n, current_path, current_path, True)
    nav_html += '</ul>\n'

    # Generate breadcrumb
    breadcrumb_items = generate_breadcrumb(node, tree)
    breadcrumb_html = _render_breadcrumb(breadcrumb_items, project_name, node.output_path)

    # Generate contents sidebar
    contents_html = generate_contents_sidebar(content)

    # Assemble full page
    html = f'''<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>{node.title} — {project_name}</title>
  <link rel="stylesheet" href="{prefix}assets/style.css">
</head>
<body>
  <header>
    <span class="project-name">{project_name}</span>
    <div class="breadcrumb">{breadcrumb_html}</div>
    <div class="search">
      <input type="text" placeholder="Search..." id="search-input" autocomplete="off">
    </div>
  </header>
  <div class="layout">
    <nav class="sidebar-left">
      {nav_html}
    </nav>
    <main class="content"{f' data-source-path="{node.md_source_path}"' if node.md_source_path else ''}>
      {content}
    </main>
    <aside class="sidebar-right">
      {contents_html}
    </aside>
  </div>
  <script src="{prefix}assets/app.js"></script>
  <script>
  window.__SLOP_SETTINGS__ = {json.dumps(settings or {{}})};
  window.__SEARCH_INDEX__ = {search_index};
  window.__SEARCH_PREFIX__ = '{prefix}';
  </script>
</body>
</html>'''

    return html


def _render_breadcrumb(items: list[BreadcrumbItem], project_name: str, page_path: str = '') -> str:
    """Render breadcrumb HTML.

    Args:
        items: Breadcrumb items.
        project_name: Project name.
        page_path: Current page's output path (for relative URLs).

    Returns:
        HTML string for breadcrumb.
    """
    prefix = _assets_prefix(page_path)
    root_href = f'{prefix}index.html' if prefix else 'index.html'
    html = f'<a href="{root_href}">Home</a>'
    for item in items:
        if not item.url:
            # Container node (no page) — render as plain text in breadcrumb
            html += f' &gt; <span>{item.title}</span>'
        else:
            href = _relative_url(page_path, item.url) if page_path else item.url
            html += f' &gt; <a href="{href}">{item.title}</a>'
    return html


