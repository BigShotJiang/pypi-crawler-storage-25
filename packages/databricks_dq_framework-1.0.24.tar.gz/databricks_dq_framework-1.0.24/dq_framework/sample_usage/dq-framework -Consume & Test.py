# Databricks notebook source
# MAGIC %md
# MAGIC # Creating a Catalog & Schema for sample usage
# MAGIC Before  downloading sample CSV data & installing the DQ Non-Functional Assessment Framework, need to create the Catalog & Schema.

# COMMAND ----------

# DBTITLE 1,Initialize Catalog and Schema
# Cell — Load sample CSVs as Delta tables (reads from Repos path on disk)

MY_CATALOG      = "sampledatacatalog"   # ← change to your catalog
CURATED_SCHEMA  = "silver"              # ← schema that holds your curated tables
DQ_SCHEMA       = "dq"                  # ← schema where DQ framework tables will live
REPO_USER       = spark.sql("SELECT current_user()").first()[0]  # ← your Databricks Repos username

REPO_BASE = f"/Workspace/Repos/{REPO_USER}/FinBricks/DQ-NonFunctional-Assessment-DBXFramework/sample_usage"

# COMMAND ----------

# DBTITLE 1,Resolve Managed Storage Root URL for Workspace
workspace_id = spark.conf.get("spark.databricks.clusterUsageTags.orgId")
query = f"""
    SELECT url 
    FROM system.information_schema.external_locations
    WHERE external_location_owner LIKE '%{workspace_id}%' AND url LIKE '%{workspace_id}%'
"""
results = spark.sql(query).collect()

if not results:
    raise Exception(
        f"Could not resolve managed storage root for workspace '{workspace_id}'. "
        "Ensure Unity Catalog is enabled and the workspace default external location exists in system.information_schema.external_locations."
    )

managed_root = results[0]["url"]
base_url = managed_root.rsplit("/", 1)[0]

MANAGED_LOCATION = f"{managed_root}/{MY_CATALOG}" # NOTE: Databricks only permits catalog managed locations under that registered path.
print(MANAGED_LOCATION)

# COMMAND ----------

# DBTITLE 1,Create Managed Catalog and Schemas
queries = [
    f"CREATE CATALOG IF NOT EXISTS {MY_CATALOG} MANAGED LOCATION '{MANAGED_LOCATION}'",
    f"CREATE SCHEMA IF NOT EXISTS {MY_CATALOG}.{CURATED_SCHEMA}",
    f"CREATE SCHEMA IF NOT EXISTS {MY_CATALOG}.{DQ_SCHEMA}",
]

for query in queries:
    spark.sql(query)

print(f"✓ Catalog  : {MY_CATALOG}")
print(f"✓ Schema   : {MY_CATALOG}.{CURATED_SCHEMA}")
print(f"✓ Schema   : {MY_CATALOG}.{DQ_SCHEMA}")


# COMMAND ----------

# MAGIC %md
# MAGIC # Create Volume & get sample data
# MAGIC Download sample CSV data into a Databricks Volume to explore and understand the DQ Framework.

# COMMAND ----------

# DBTITLE 1,Create Storage Volume to upload sample data
query = f"CREATE VOLUME IF NOT EXISTS {MY_CATALOG}.{CURATED_SCHEMA}.sample_data"
spark.sql(query)

print("\nUpload your 3 CSV files here (all in the same volume):")
print("  • mock_curated_vendors.csv")
print("  • mock_curated_contacts.csv")
print("  • mock_curated_locations.csv")
print("\nHow to upload:")
print("  1. In the left sidebar → Catalog → Schema → Volumes → sample_data")
print("  2. Click 'Upload to this volume' and drag-drop all 3 files")


# COMMAND ----------

# DBTITLE 1,Load Sample Data from CSV Files
VOLUME_PATH = f"/Volumes/{MY_CATALOG}/{CURATED_SCHEMA}/sample_data"

csv_files = [
    "mock_curated_vendors",
    "mock_curated_contacts",
    "mock_curated_locations",
]

for table_name in csv_files:
    csv_path = f"{VOLUME_PATH}/{table_name}.csv"

    df = spark.read \
        .option("header", "true") \
        .option("inferSchema", "true") \
        .csv(csv_path)

    # display(df)
    df.write \
        .format("delta") \
        .mode("overwrite") \
        .option("overwriteSchema", "true") \
        .saveAsTable(f"{MY_CATALOG}.{CURATED_SCHEMA}.{table_name}")

    print(f"✓ {table_name} — {df.count()} rows loaded")

# COMMAND ----------

# DBTITLE 1,Introduction
# MAGIC %md
# MAGIC # DQ Framework — Consume & Test
# MAGIC Install and run the DQ Non-Functional Assessment Framework from the local repo.
# MAGIC Point it at your **existing catalog and schema** — change the variables in Cell 3.

# COMMAND ----------

# DBTITLE 1,Install Databricks Data Quality Framework
# %pip install databricks-dq-framework
# dbutils.library.restartPython() # <-- Upon restart run cell 1

%pip install databricks-dq-framework --upgrade --no-deps
dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,Check Installed Version of Databricks DQ Framework
# MAGIC %pip show databricks-dq-framework

# COMMAND ----------

# DBTITLE 1,Import Data Quality Framework & Configuration Summary
from dq_framework import DQFramework

dq = DQFramework(spark, catalog=MY_CATALOG, schema=DQ_SCHEMA)
dq.config.show_config_summary()

# COMMAND ----------

# DBTITLE 1,Initialize DQ Framework -Setup
dq.setup()

# COMMAND ----------

# DBTITLE 1,Upsert MasterField data -PySpark
(dq.config
    .register_field(field_id=1, full_field_name='postal_code_all_country', data_category_type_id=10, is_active=True, created_by=None, last_updated_by=None)
    .register_field(field_id=2, full_field_name='province', data_category_type_id=3, is_active=True, created_by=None, last_updated_by=None)
    .register_field(field_id=3, full_field_name='state', data_category_type_id=3, is_active=True, created_by=None, last_updated_by=None)
    .register_field(field_id=4, full_field_name='city', data_category_type_id=3, is_active=True, created_by=None, last_updated_by=None)
    .register_field(field_id=5, full_field_name='address_line_1', data_category_type_id=2, is_active=True, created_by=None, last_updated_by=None)
    .register_field(field_id=6, full_field_name='address_line_2', data_category_type_id=2, is_active=True, created_by=None, last_updated_by=None)
    .register_field(field_id=7, full_field_name='address_general', data_category_type_id=2, is_active=True, created_by=None, last_updated_by=None)
    .register_field(field_id=8, full_field_name='address_short', data_category_type_id=3, is_active=True, created_by=None, last_updated_by=None)
    .register_field(field_id=9, full_field_name='country', data_category_type_id=3, is_active=True, created_by=None, last_updated_by=None)
    .register_field(field_id=10, full_field_name='county', data_category_type_id=10, is_active=True, created_by=None, last_updated_by=None)
    .register_field(field_id=11, full_field_name='email_address', data_category_type_id=4, is_active=True, created_by=None, last_updated_by=None)
    .register_field(field_id=12, full_field_name='phone_number', data_category_type_id=12, is_active=True, created_by=None, last_updated_by=None)
    .register_field(field_id=13, full_field_name='mobile_number_without_country', data_category_type_id=14, is_active=True, created_by=None, last_updated_by=None)
    .register_field(field_id=14, full_field_name='vendor_name', data_category_type_id=2, is_active=True, created_by=None, last_updated_by=None)
    .register_field(field_id=15, full_field_name='first_name', data_category_type_id=2, is_active=True, created_by=None, last_updated_by=None)
    .register_field(field_id=16, full_field_name='name_general', data_category_type_id=2, is_active=True, created_by='sys', last_updated_by=None)
    .register_field(field_id=17, full_field_name='trade_type', data_category_type_id=1, is_active=True, created_by='sys', last_updated_by=None)
    .register_field(field_id=18, full_field_name='check_vendor_license_number', data_category_type_id=11, is_active=True, created_by='sys', last_updated_by=None)
)


# COMMAND ----------

# DBTITLE 1,Upsert MasterField data -SQL
query = f"""
MERGE INTO `{MY_CATALOG}`.`{DQ_SCHEMA}`.`masterField` AS t
USING (
    SELECT * FROM (
        SELECT NULL AS _ID, NULL AS FullFieldName, NULL AS DataCategoryTypeID, NULL AS IsActive, NULL AS CreatedBy, NULL AS CreatedOn, NULL AS LastUpdatedBy, NULL AS LastUpdatedOn UNION ALL 
        SELECT 1, 'postal_code_all_country', 10, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
        SELECT 2, 'province', 3, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
        SELECT 3, 'state', 3, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
        SELECT 4, 'city', 3, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
        SELECT 5, 'address_line_1', 2, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
        SELECT 6, 'address_line_2', 2, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
        SELECT 7, 'address_general', 2, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
        SELECT 8, 'address_short', 3, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
        SELECT 9, 'country', 3, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
        SELECT 10, 'county', 10, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
        SELECT 11, 'email_address', 4, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
        SELECT 12, 'phone_number', 12, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
        SELECT 13, 'mobile_number_without_country', 14, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
        SELECT 14, 'vendor_name', 2, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
        SELECT 15, 'first_name', 2, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
        SELECT 16, 'name_general', 2, true, 'sys', current_timestamp(), NULL, NULL UNION ALL 
        SELECT 17, 'trade_type', 1, true, 'sys', current_timestamp(), NULL, NULL UNION ALL 
        SELECT 18, 'check_vendor_license_number', 11, true, 'sys', current_timestamp(), NULL, NULL 
    ) WHERE _ID IS NOT NULL
) AS s ON t._ID = s._ID
WHEN MATCHED AND (
    t.FullFieldName      <> s.FullFieldName OR
    t.DataCategoryTypeID <> s.DataCategoryTypeID OR
    t.IsActive           <> s.IsActive
) THEN UPDATE SET
    t.FullFieldName      = s.FullFieldName,
    t.DataCategoryTypeID = s.DataCategoryTypeID,
    t.IsActive           = s.IsActive,
    t.LastUpdatedBy      = current_user(),
    t.LastUpdatedOn      = current_timestamp()
WHEN NOT MATCHED THEN INSERT (
    _ID, FullFieldName, DataCategoryTypeID, IsActive,
    CreatedBy, CreatedOn, LastUpdatedBy, LastUpdatedOn
) VALUES (
    s._ID, s.FullFieldName, s.DataCategoryTypeID, s.IsActive,
    s.CreatedBy, s.CreatedOn, s.LastUpdatedBy, s.LastUpdatedOn
)
"""

spark.sql(query)

# COMMAND ----------

# DBTITLE 1,MasterField -Data
check_query = f"SELECT * FROM {MY_CATALOG}.{DQ_SCHEMA}.masterField"
display(spark.sql(check_query))

# COMMAND ----------

# DBTITLE 1,Upsert configFieldValues data -PySpark
(dq.config
.set_field_values(config_id=1, full_field_name='postal_code_all_country', field_id=1, min_data_length=5, max_data_length=10, min_data_value='00001', max_data_value='ZZZ 9ZZ', is_active=True, created_by=None, last_updated_by=None)
.set_field_values(config_id=2, full_field_name='province', field_id=2, min_data_length=4, max_data_length=20, min_data_value='aaaa', max_data_value='ZZZZZZZZZZZZZZZZZZZZ', is_active=True, created_by=None, last_updated_by=None)
.set_field_values(config_id=3, full_field_name='state', field_id=3, min_data_length=3, max_data_length=20, min_data_value='aaaa', max_data_value='ZZZZZZZZZZZZZZZZZZZZ', is_active=True, created_by=None, last_updated_by=None)
.set_field_values(config_id=4, full_field_name='city', field_id=4, min_data_length=3, max_data_length=20, min_data_value=None, max_data_value=None, is_active=True, created_by=None, last_updated_by=None)
.set_field_values(config_id=5, full_field_name='address_line_1', field_id=5, min_data_length=5, max_data_length=100, min_data_value=None, max_data_value=None, is_active=True, created_by=None, last_updated_by=None)
.set_field_values(config_id=6, full_field_name='address_line_2', field_id=6, min_data_length=5, max_data_length=100, min_data_value=None, max_data_value=None, is_active=True, created_by=None, last_updated_by=None)
.set_field_values(config_id=7, full_field_name='address_general', field_id=7, min_data_length=5, max_data_length=100, min_data_value=None, max_data_value=None, is_active=True, created_by=None, last_updated_by=None)
.set_field_values(config_id=8, full_field_name='address_short', field_id=8, min_data_length=5, max_data_length=15, min_data_value=None, max_data_value=None, is_active=True, created_by=None, last_updated_by=None)
.set_field_values(config_id=9, full_field_name='country', field_id=9, min_data_length=2, max_data_length=2, min_data_value=None, max_data_value=None, is_active=True, created_by=None, last_updated_by=None)
.set_field_values(config_id=10, full_field_name='county', field_id=10, min_data_length=3, max_data_length=20, min_data_value=None, max_data_value=None, is_active=True, created_by=None, last_updated_by=None)
.set_field_values(config_id=11, full_field_name='email_address', field_id=11, min_data_length=6, max_data_length=255, min_data_value=None, max_data_value=None, is_active=True, created_by=None, last_updated_by=None)
.set_field_values(config_id=12, full_field_name='phone_number', field_id=12, min_data_length=6, max_data_length=16, min_data_value='100000', max_data_value='999999999999999', is_active=True, created_by=None, last_updated_by=None)
.set_field_values(config_id=13, full_field_name='mobile_number_without_country', field_id=13, min_data_length=6, max_data_length=16, min_data_value='60000000000', max_data_value='9999999999', is_active=True, created_by=None, last_updated_by=None)
.set_field_values(config_id=14, full_field_name='vendor_name', field_id=14, min_data_length=5, max_data_length=50, min_data_value=None, max_data_value=None, is_active=True, created_by=None, last_updated_by=None)
.set_field_values(config_id=15, full_field_name='first_name', field_id=15, min_data_length=2, max_data_length=20, min_data_value=None, max_data_value=None, is_active=True, created_by=None, last_updated_by=None)
.set_field_values(config_id=16, full_field_name='name_general', field_id=16, min_data_length=2, max_data_length=20, min_data_value=None, max_data_value=None, is_active=True, created_by=None, last_updated_by=None)
.set_field_values(config_id=17, full_field_name='trade_type', field_id=17, min_data_length=5, max_data_length=10, min_data_value=None, max_data_value=None, is_active=True, created_by=None, last_updated_by=None)
)

# COMMAND ----------

# DBTITLE 1,Upsert configFieldValues -data
query = f"""
MERGE INTO `{MY_CATALOG}`.`{DQ_SCHEMA}`.`configFieldValues` AS t
USING (
    SELECT * FROM (
        SELECT NULL AS _ID, NULL AS FieldID, NULL AS FullFieldName, NULL AS MinDataLength, NULL AS MaxDataLength, NULL AS MinDataValue, NULL AS MaxDataValue, NULL AS IsActive, NULL AS CreatedBy, NULL AS CreatedOn, NULL AS LastUpdatedBy, NULL AS LastUpdatedOn UNION ALL
        SELECT 1,  1,  'postal_code_all_country',       5,  10,  '00001',         'ZZZ 9ZZ',                true, 'sys', current_timestamp(), NULL, NULL UNION ALL
        SELECT 2,  2,  'province',                       4,  20,  'aaaa',           'ZZZZZZZZZZZZZZZZZZZZ', true, 'sys', current_timestamp(), NULL, NULL UNION ALL
        SELECT 3,  3,  'state',                          3,  20,  'aaaa',           'ZZZZZZZZZZZZZZZZZZZZ', true, 'sys', current_timestamp(), NULL, NULL UNION ALL
        SELECT 4,  4,  'city',                           3,  20,  NULL,             NULL,                   true, 'sys', current_timestamp(), NULL, NULL UNION ALL
        SELECT 5,  5,  'address_line_1',                 5,  100, NULL,             NULL,                   true, 'sys', current_timestamp(), NULL, NULL UNION ALL
        SELECT 6,  6,  'address_line_2',                 5,  100, NULL,             NULL,                   true, 'sys', current_timestamp(), NULL, NULL UNION ALL
        SELECT 7,  7,  'address_general',                5,  100, NULL,             NULL,                   true, 'sys', current_timestamp(), NULL, NULL UNION ALL
        SELECT 8,  8,  'address_short',                  5,  15,  NULL,             NULL,                   true, 'sys', current_timestamp(), NULL, NULL UNION ALL
        SELECT 9,  9,  'country',                        2,  2,   NULL,             NULL,                   true, 'sys', current_timestamp(), NULL, NULL UNION ALL
        SELECT 10, 10, 'county',                         3,  20,  NULL,             NULL,                   true, 'sys', current_timestamp(), NULL, NULL UNION ALL
        SELECT 11, 11, 'email_address',                  6,  255, NULL,             NULL,                   true, 'sys', current_timestamp(), NULL, NULL UNION ALL
        SELECT 12, 12, 'phone_number',                   6,  16,  '100000',         '999999999999999',       true, 'sys', current_timestamp(), NULL, NULL UNION ALL
        SELECT 13, 13, 'mobile_number_without_country',  6,  16,  '60000000000',    '9999999999',            true, 'sys', current_timestamp(), NULL, NULL UNION ALL
        SELECT 14, 14, 'vendor_name',                    5,  50,  NULL,             NULL,                   true, 'sys', current_timestamp(), NULL, NULL UNION ALL
        SELECT 15, 15, 'first_name',                     2,  20,  NULL,             NULL,                   true, 'sys', current_timestamp(), NULL, NULL UNION ALL
        SELECT 16, 16, 'name_general',                   2,  20,  NULL,             NULL,                   true, 'sys', current_timestamp(), NULL, NULL UNION ALL
        SELECT 17, 17, 'trade_type',                     5,  10,  NULL,             NULL,                   true, 'sys', current_timestamp(), NULL, NULL
    ) WHERE _ID IS NOT NULL
) AS s ON t._ID = s._ID
WHEN MATCHED AND (
    t.MinDataLength <> s.MinDataLength OR t.MaxDataLength <> s.MaxDataLength OR
    t.MinDataValue  <> s.MinDataValue  OR t.MaxDataValue  <> s.MaxDataValue  OR
    t.IsActive      <> s.IsActive
) THEN UPDATE SET
    t.MinDataLength = s.MinDataLength,
    t.MaxDataLength = s.MaxDataLength,
    t.MinDataValue  = s.MinDataValue,
    t.MaxDataValue  = s.MaxDataValue,
    t.IsActive      = s.IsActive,
    t.LastUpdatedBy = current_user(),
    t.LastUpdatedOn = current_timestamp()
WHEN NOT MATCHED THEN INSERT (
    _ID, FieldID, FullFieldName, MinDataLength, MaxDataLength,
    MinDataValue, MaxDataValue, IsActive,
    CreatedBy, CreatedOn, LastUpdatedBy, LastUpdatedOn
) VALUES (
    s._ID, s.FieldID, s.FullFieldName, s.MinDataLength, s.MaxDataLength,
    s.MinDataValue, s.MaxDataValue, s.IsActive,
    s.CreatedBy, s.CreatedOn, s.LastUpdatedBy, s.LastUpdatedOn
)
"""
spark.sql(query)


# COMMAND ----------

# DBTITLE 1,configFieldValues -Data
check_query = f"SELECT * FROM {MY_CATALOG}.{DQ_SCHEMA}.configFieldValues"
display(spark.sql(check_query))

# COMMAND ----------

# DBTITLE 1,Upsert configFieldAllowedPattern data -PySpark
(dq.config
.add_pattern_rule(rule_id=1, full_field_name='email_address', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Is Fully Numeric', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=2, full_field_name='email_address', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Is Fully Decimal', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=3, full_field_name='email_address', is_pattern_allowed=False, pattern_category='DataType3', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=4, full_field_name='email_address', is_pattern_allowed=False, pattern_category='SpecialCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=5, full_field_name='email_address', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Has Full Stop', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=6, full_field_name='email_address', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Has Hyphen', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=7, full_field_name='email_address', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Has Underscore', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=8, full_field_name='email_address', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Has At Sign', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=9, full_field_name='email_address', is_pattern_allowed=False, pattern_category=None, pattern_subcategory='Emptiness', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=10, full_field_name='email_address', is_pattern_allowed=False, pattern_category='InvalidKeyword', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=11, full_field_name='email_address', is_pattern_allowed=False, pattern_category='FullyDuplicatedCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=12, full_field_name='email_address', is_pattern_allowed=False, pattern_category='UnicodeCharacters', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=13, full_field_name='email_address', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Is Empty or NULL', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=14, full_field_name='email_address', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Has Space', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=15, full_field_name='postal_code_all_country', is_pattern_allowed=False, pattern_category='DataType3', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=16, full_field_name='postal_code_all_country', is_pattern_allowed=False, pattern_category='InvalidKeyword', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=17, full_field_name='postal_code_all_country', is_pattern_allowed=False, pattern_category='FullyDuplicatedCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=18, full_field_name='postal_code_all_country', is_pattern_allowed=False, pattern_category='UnicodeCharacters', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=19, full_field_name='postal_code_all_country', is_pattern_allowed=False, pattern_category='SpecialCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=20, full_field_name='postal_code_all_country', is_pattern_allowed=False, pattern_category=None, pattern_subcategory='Emptiness', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=21, full_field_name='postal_code_all_country', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Has Space', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=22, full_field_name='postal_code_all_country', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Is Fully Decimal', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=23, full_field_name='postal_code_all_country', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Has Lowercase Character', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=24, full_field_name='state', is_pattern_allowed=False, pattern_category='DataType1', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=25, full_field_name='state', is_pattern_allowed=False, pattern_category='DataType2', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=26, full_field_name='state', is_pattern_allowed=False, pattern_category='DataType3', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=27, full_field_name='state', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Is Fully Text', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=28, full_field_name='state', is_pattern_allowed=False, pattern_category='InvalidKeyword', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=29, full_field_name='state', is_pattern_allowed=False, pattern_category='FullyDuplicatedCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=30, full_field_name='state', is_pattern_allowed=False, pattern_category='UnicodeCharacters', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=31, full_field_name='state', is_pattern_allowed=False, pattern_category='SpecialCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=32, full_field_name='state', is_pattern_allowed=False, pattern_category=None, pattern_subcategory='Emptiness', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=33, full_field_name='state', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Has Space', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=34, full_field_name='city', is_pattern_allowed=False, pattern_category='DataType1', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=35, full_field_name='city', is_pattern_allowed=False, pattern_category='DataType2', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=36, full_field_name='city', is_pattern_allowed=False, pattern_category='DataType3', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=37, full_field_name='city', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Is Fully Text', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=38, full_field_name='city', is_pattern_allowed=False, pattern_category='InvalidKeyword', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=39, full_field_name='city', is_pattern_allowed=False, pattern_category='FullyDuplicatedCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=40, full_field_name='city', is_pattern_allowed=False, pattern_category='UnicodeCharacters', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=41, full_field_name='city', is_pattern_allowed=False, pattern_category='SpecialCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=42, full_field_name='city', is_pattern_allowed=False, pattern_category=None, pattern_subcategory='Emptiness', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=43, full_field_name='city', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Has Space', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=44, full_field_name='address_line_1', is_pattern_allowed=False, pattern_category='DataType3', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=45, full_field_name='address_line_1', is_pattern_allowed=False, pattern_category='InvalidKeyword', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=46, full_field_name='address_line_1', is_pattern_allowed=False, pattern_category='FullyDuplicatedCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=47, full_field_name='address_line_1', is_pattern_allowed=False, pattern_category='UnicodeCharacters', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=48, full_field_name='address_line_1', is_pattern_allowed=False, pattern_category='SpecialCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=49, full_field_name='address_line_1', is_pattern_allowed=False, pattern_category=None, pattern_subcategory='Emptiness', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=50, full_field_name='address_line_1', is_pattern_allowed=True, pattern_category=None, pattern_subcategory='SpecialCharacter-L1', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=51, full_field_name='address_line_1', is_pattern_allowed=True, pattern_category=None, pattern_subcategory='SpecialCharacter-L2', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=52, full_field_name='address_line_1', is_pattern_allowed=True, pattern_category=None, pattern_subcategory='SpecialCharacter-L3', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=53, full_field_name='address_line_1', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Has Exclamation Mark', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=54, full_field_name='address_line_1', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Has Question Mark', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=55, full_field_name='address_line_1', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Has Space', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=56, full_field_name='address_line_1', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Is Fully Decimal', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=57, full_field_name='address_line_1', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Is Fully Numeric', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=58, full_field_name='country', is_pattern_allowed=False, pattern_category='DataType1', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=59, full_field_name='country', is_pattern_allowed=False, pattern_category='DataType2', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=60, full_field_name='country', is_pattern_allowed=False, pattern_category='DataType3', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=61, full_field_name='country', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Is Fully Text', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=62, full_field_name='country', is_pattern_allowed=False, pattern_category='InvalidKeyword', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=63, full_field_name='country', is_pattern_allowed=False, pattern_category='FullyDuplicatedCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=64, full_field_name='country', is_pattern_allowed=False, pattern_category='UnicodeCharacters', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=65, full_field_name='country', is_pattern_allowed=False, pattern_category='SpecialCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=66, full_field_name='country', is_pattern_allowed=False, pattern_category=None, pattern_subcategory='Emptiness', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=67, full_field_name='country', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Has Space', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=68, full_field_name='country', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Has Lowercase Character', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=69, full_field_name='vendor_name', is_pattern_allowed=False, pattern_category='DataType3', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=70, full_field_name='vendor_name', is_pattern_allowed=False, pattern_category='InvalidKeyword', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=71, full_field_name='vendor_name', is_pattern_allowed=False, pattern_category='FullyDuplicatedCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=72, full_field_name='vendor_name', is_pattern_allowed=False, pattern_category='UnicodeCharacters', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=73, full_field_name='vendor_name', is_pattern_allowed=False, pattern_category='SpecialCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=74, full_field_name='vendor_name', is_pattern_allowed=False, pattern_category=None, pattern_subcategory='Emptiness', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=75, full_field_name='vendor_name', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Has Space', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=76, full_field_name='vendor_name', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Is Fully Decimal', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=77, full_field_name='vendor_name', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Is Fully Numeric', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=78, full_field_name='vendor_name', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Has Lowercase Character', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=79, full_field_name='name_general', is_pattern_allowed=False, pattern_category='DataType2', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=80, full_field_name='name_general', is_pattern_allowed=False, pattern_category='DataType3', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=81, full_field_name='name_general', is_pattern_allowed=False, pattern_category='InvalidKeyword', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=82, full_field_name='name_general', is_pattern_allowed=False, pattern_category='FullyDuplicatedCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=83, full_field_name='name_general', is_pattern_allowed=False, pattern_category='UnicodeCharacters', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=84, full_field_name='name_general', is_pattern_allowed=False, pattern_category='SpecialCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=85, full_field_name='name_general', is_pattern_allowed=False, pattern_category=None, pattern_subcategory='Emptiness', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=86, full_field_name='name_general', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Has Space', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=87, full_field_name='name_general', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Is Fully Decimal', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=88, full_field_name='name_general', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Is Fully Numeric', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=89, full_field_name='first_name', is_pattern_allowed=False, pattern_category='DataType1', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=90, full_field_name='name_general', is_pattern_allowed=False, pattern_category='DataType2', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=91, full_field_name='name_general', is_pattern_allowed=False, pattern_category='DataType3', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=92, full_field_name='name_general', is_pattern_allowed=False, pattern_category='InvalidKeyword', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=93, full_field_name='name_general', is_pattern_allowed=False, pattern_category='FullyDuplicatedCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=94, full_field_name='name_general', is_pattern_allowed=True, pattern_category='UnicodeCharacters', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=95, full_field_name='name_general', is_pattern_allowed=False, pattern_category='SpecialCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=96, full_field_name='name_general', is_pattern_allowed=False, pattern_category=None, pattern_subcategory='Emptiness', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=97, full_field_name='name_general', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Has Space', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=98, full_field_name='name_general', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Is Fully Text', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=99, full_field_name='name_general', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Has Lowercase Character', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=100, full_field_name='name_general', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Has Hyphen', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=101, full_field_name='name_general', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Has Full Stop', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=102, full_field_name='name_general', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Has Single Quote', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=103, full_field_name='name_general', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name=None, is_active=False, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=104, full_field_name='mobile_number_without_country', is_pattern_allowed=False, pattern_category='DataType1', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=105, full_field_name='mobile_number_without_country', is_pattern_allowed=False, pattern_category='DataType2', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=106, full_field_name='mobile_number_without_country', is_pattern_allowed=False, pattern_category='DataType3', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=107, full_field_name='mobile_number_without_country', is_pattern_allowed=False, pattern_category='SpecialCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=108, full_field_name='mobile_number_without_country', is_pattern_allowed=False, pattern_category='InvalidKeyword', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=109, full_field_name='mobile_number_without_country', is_pattern_allowed=False, pattern_category='FullyDuplicatedCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=110, full_field_name='mobile_number_without_country', is_pattern_allowed=False, pattern_category='UnicodeCharacters', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=111, full_field_name='mobile_number_without_country', is_pattern_allowed=False, pattern_category=None, pattern_subcategory='Emptiness', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=112, full_field_name='mobile_number_without_country', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Has Space', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=113, full_field_name='mobile_number_without_country', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Is Fully Numeric', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=114, full_field_name='mobile_number_without_country', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Is Empty or NULL', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=115, full_field_name='trade_type', is_pattern_allowed=False, pattern_category='InvalidKeyword', pattern_subcategory=None, pattern_name=None, is_active=False, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=116, full_field_name='trade_type', is_pattern_allowed=False, pattern_category='FullyDuplicatedCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=117, full_field_name='trade_type', is_pattern_allowed=False, pattern_category='UnicodeCharacters', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=118, full_field_name='trade_type', is_pattern_allowed=False, pattern_category=None, pattern_subcategory='Emptiness', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=119, full_field_name='trade_type', is_pattern_allowed=False, pattern_category=None, pattern_subcategory='100% Numeric', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=120, full_field_name='trade_type', is_pattern_allowed=True, pattern_category=None, pattern_subcategory='SpecialCharacter-L1', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=121, full_field_name='trade_type', is_pattern_allowed=True, pattern_category=None, pattern_subcategory='SpecialCharacter-L2', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=122, full_field_name='trade_type', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Has Semicolon', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=123, full_field_name='trade_type', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Has Space', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=124, full_field_name='address_general', is_pattern_allowed=False, pattern_category='DataType3', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=125, full_field_name='address_general', is_pattern_allowed=False, pattern_category='InvalidKeyword', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=126, full_field_name='address_general', is_pattern_allowed=False, pattern_category='FullyDuplicatedCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=127, full_field_name='address_general', is_pattern_allowed=False, pattern_category='UnicodeCharacters', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=128, full_field_name='address_general', is_pattern_allowed=False, pattern_category='SpecialCharacter', pattern_subcategory=None, pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=129, full_field_name='address_general', is_pattern_allowed=False, pattern_category=None, pattern_subcategory='Emptiness', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=130, full_field_name='address_general', is_pattern_allowed=True, pattern_category=None, pattern_subcategory='SpecialCharacter-L1', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=131, full_field_name='address_general', is_pattern_allowed=True, pattern_category=None, pattern_subcategory='SpecialCharacter-L2', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=132, full_field_name='address_general', is_pattern_allowed=True, pattern_category=None, pattern_subcategory='SpecialCharacter-L3', pattern_name=None, is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=133, full_field_name='address_general', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Has Exclamation Mark', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=134, full_field_name='address_general', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Has Question Mark', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=135, full_field_name='address_general', is_pattern_allowed=True, pattern_category=None, pattern_subcategory=None, pattern_name='Has Space', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=136, full_field_name='address_general', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Is Fully Decimal', is_active=True, created_by=None, last_updated_by=None)
.add_pattern_rule(rule_id=137, full_field_name='address_general', is_pattern_allowed=False, pattern_category=None, pattern_subcategory=None, pattern_name='Is Fully Numeric', is_active=True, created_by=None, last_updated_by=None)
)

# COMMAND ----------

# DBTITLE 1,Upsert configFieldAllowedPattern data -SQL
query = f"""
MERGE INTO `{MY_CATALOG}`.`{DQ_SCHEMA}`.`configFieldAllowedPattern` AS t
USING (
    SELECT * FROM (
        SELECT NULL AS _ID, NULL AS FullFieldName, NULL AS PatternCategory, NULL AS PatternSubCategory, NULL AS PatternName, NULL AS IsPatternAllowed, NULL AS IsActive, NULL AS CreatedBy, NULL AS CreatedOn, NULL AS LastUpdatedBy, NULL AS LastUpdatedOn UNION ALL 
    SELECT 1, 'email_address', NULL, NULL, 'Is Fully Numeric', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 2, 'email_address', NULL, NULL, 'Is Fully Decimal', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 3, 'email_address', 'DataType3', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 4, 'email_address', 'SpecialCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 5, 'email_address', NULL, NULL, 'Has Full Stop', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 6, 'email_address', NULL, NULL, 'Has Hyphen', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 7, 'email_address', NULL, NULL, 'Has Underscore', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 8, 'email_address', NULL, NULL, 'Has At Sign', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 9, 'email_address', NULL, 'Emptiness', NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 10, 'email_address', 'InvalidKeyword', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 11, 'email_address', 'FullyDuplicatedCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 12, 'email_address', 'UnicodeCharacters', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 13, 'email_address', NULL, NULL, 'Is Empty or NULL', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 14, 'email_address', NULL, NULL, 'Has Space', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 15, 'postal_code_all_country', 'DataType3', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 16, 'postal_code_all_country', 'InvalidKeyword', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 17, 'postal_code_all_country', 'FullyDuplicatedCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 18, 'postal_code_all_country', 'UnicodeCharacters', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 19, 'postal_code_all_country', 'SpecialCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 20, 'postal_code_all_country', NULL, 'Emptiness', NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 21, 'postal_code_all_country', NULL, NULL, 'Has Space', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 22, 'postal_code_all_country', NULL, NULL, 'Is Fully Decimal', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 23, 'postal_code_all_country', NULL, NULL, 'Has Lowercase Character', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 24, 'state', 'DataType1', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 25, 'state', 'DataType2', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 26, 'state', 'DataType3', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 27, 'state', NULL, NULL, 'Is Fully Text', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 28, 'state', 'InvalidKeyword', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 29, 'state', 'FullyDuplicatedCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 30, 'state', 'UnicodeCharacters', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 31, 'state', 'SpecialCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 32, 'state', NULL, 'Emptiness', NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 33, 'state', NULL, NULL, 'Has Space', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 34, 'city', 'DataType1', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 35, 'city', 'DataType2', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 36, 'city', 'DataType3', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 37, 'city', NULL, NULL, 'Is Fully Text', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 38, 'city', 'InvalidKeyword', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 39, 'city', 'FullyDuplicatedCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 40, 'city', 'UnicodeCharacters', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 41, 'city', 'SpecialCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 42, 'city', NULL, 'Emptiness', NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 43, 'city', NULL, NULL, 'Has Space', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 44, 'address_line_1', 'DataType3', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 45, 'address_line_1', 'InvalidKeyword', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 46, 'address_line_1', 'FullyDuplicatedCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 47, 'address_line_1', 'UnicodeCharacters', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 48, 'address_line_1', 'SpecialCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 49, 'address_line_1', NULL, 'Emptiness', NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 50, 'address_line_1', NULL, 'SpecialCharacter-L1', NULL, true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 51, 'address_line_1', NULL, 'SpecialCharacter-L2', NULL, true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 52, 'address_line_1', NULL, 'SpecialCharacter-L3', NULL, true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 53, 'address_line_1', NULL, NULL, 'Has Exclamation Mark', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 54, 'address_line_1', NULL, NULL, 'Has Question Mark', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 55, 'address_line_1', NULL, NULL, 'Has Space', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 56, 'address_line_1', NULL, NULL, 'Is Fully Decimal', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 57, 'address_line_1', NULL, NULL, 'Is Fully Numeric', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 58, 'country', 'DataType1', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 59, 'country', 'DataType2', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 60, 'country', 'DataType3', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 61, 'country', NULL, NULL, 'Is Fully Text', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 62, 'country', 'InvalidKeyword', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 63, 'country', 'FullyDuplicatedCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 64, 'country', 'UnicodeCharacters', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 65, 'country', 'SpecialCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 66, 'country', NULL, 'Emptiness', NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 67, 'country', NULL, NULL, 'Has Space', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 68, 'country', NULL, NULL, 'Has Lowercase Character', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 69, 'vendor_name', 'DataType3', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 70, 'vendor_name', 'InvalidKeyword', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 71, 'vendor_name', 'FullyDuplicatedCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 72, 'vendor_name', 'UnicodeCharacters', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 73, 'vendor_name', 'SpecialCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 74, 'vendor_name', NULL, 'Emptiness', NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 75, 'vendor_name', NULL, NULL, 'Has Space', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 76, 'vendor_name', NULL, NULL, 'Is Fully Decimal', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 77, 'vendor_name', NULL, NULL, 'Is Fully Numeric', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 78, 'vendor_name', NULL, NULL, 'Has Lowercase Character', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 79, 'name_general', 'DataType2', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 80, 'name_general', 'DataType3', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 81, 'name_general', 'InvalidKeyword', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 82, 'name_general', 'FullyDuplicatedCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 83, 'name_general', 'UnicodeCharacters', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 84, 'name_general', 'SpecialCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 85, 'name_general', NULL, 'Emptiness', NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 86, 'name_general', NULL, NULL, 'Has Space', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 87, 'name_general', NULL, NULL, 'Is Fully Decimal', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 88, 'name_general', NULL, NULL, 'Is Fully Numeric', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 89, 'first_name', 'DataType1', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 90, 'name_general', 'DataType2', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 91, 'name_general', 'DataType3', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 92, 'name_general', 'InvalidKeyword', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 93, 'name_general', 'FullyDuplicatedCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 94, 'name_general', 'UnicodeCharacters', NULL, NULL, true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 95, 'name_general', 'SpecialCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 96, 'name_general', NULL, 'Emptiness', NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 97, 'name_general', NULL, NULL, 'Has Space', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 98, 'name_general', NULL, NULL, 'Is Fully Text', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 99, 'name_general', NULL, NULL, 'Has Lowercase Character', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 100, 'name_general', NULL, NULL, 'Has Hyphen', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 101, 'name_general', NULL, NULL, 'Has Full Stop', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 102, 'name_general', NULL, NULL, 'Has Single Quote', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 103, 'name_general', NULL, NULL, NULL, false, false, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 104, 'mobile_number_without_country', 'DataType1', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 105, 'mobile_number_without_country', 'DataType2', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 106, 'mobile_number_without_country', 'DataType3', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 107, 'mobile_number_without_country', 'SpecialCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 108, 'mobile_number_without_country', 'InvalidKeyword', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 109, 'mobile_number_without_country', 'FullyDuplicatedCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 110, 'mobile_number_without_country', 'UnicodeCharacters', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 111, 'mobile_number_without_country', NULL, 'Emptiness', NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 112, 'mobile_number_without_country', NULL, NULL, 'Has Space', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 113, 'mobile_number_without_country', NULL, NULL, 'Is Fully Numeric', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 114, 'mobile_number_without_country', NULL, NULL, 'Is Empty or NULL', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 115, 'trade_type', 'InvalidKeyword', NULL, NULL, false, false, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 116, 'trade_type', 'FullyDuplicatedCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 117, 'trade_type', 'UnicodeCharacters', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 118, 'trade_type', NULL, 'Emptiness', NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 119, 'trade_type', NULL, '100% Numeric', NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 120, 'trade_type', NULL, 'SpecialCharacter-L1', NULL, true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 121, 'trade_type', NULL, 'SpecialCharacter-L2', NULL, true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 122, 'trade_type', NULL, NULL, 'Has Semicolon', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 123, 'trade_type', NULL, NULL, 'Has Space', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 124, 'address_general', 'DataType3', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 125, 'address_general', 'InvalidKeyword', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 126, 'address_general', 'FullyDuplicatedCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 127, 'address_general', 'UnicodeCharacters', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 128, 'address_general', 'SpecialCharacter', NULL, NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 129, 'address_general', NULL, 'Emptiness', NULL, false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 130, 'address_general', NULL, 'SpecialCharacter-L1', NULL, true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 131, 'address_general', NULL, 'SpecialCharacter-L2', NULL, true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 132, 'address_general', NULL, 'SpecialCharacter-L3', NULL, true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 133, 'address_general', NULL, NULL, 'Has Exclamation Mark', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 134, 'address_general', NULL, NULL, 'Has Question Mark', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 135, 'address_general', NULL, NULL, 'Has Space', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 136, 'address_general', NULL, NULL, 'Is Fully Decimal', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
    SELECT 137, 'address_general', NULL, NULL, 'Is Fully Numeric', false, true, current_user(), current_timestamp(), NULL, NULL
    ) WHERE _ID IS NOT NULL
) AS s ON t._ID = s._ID
WHEN MATCHED AND (
    t.IsPatternAllowed <> s.IsPatternAllowed OR
    t.IsActive         <> s.IsActive
) THEN UPDATE SET
    t.IsPatternAllowed = s.IsPatternAllowed,
    t.IsActive         = s.IsActive,
    t.LastUpdatedBy    = current_user(),
    t.LastUpdatedOn    = current_timestamp()
WHEN NOT MATCHED THEN INSERT (
    _ID, FullFieldName, PatternCategory, PatternSubCategory, PatternName,
    IsPatternAllowed, IsActive,
    CreatedBy, CreatedOn, LastUpdatedBy, LastUpdatedOn
) VALUES (
    s._ID, s.FullFieldName, s.PatternCategory, s.PatternSubCategory, s.PatternName,
    s.IsPatternAllowed, s.IsActive,
    s.CreatedBy, s.CreatedOn, s.LastUpdatedBy, s.LastUpdatedOn
)
"""
spark.sql(query)


# COMMAND ----------

# DBTITLE 1,configFieldAllowedPattern -Data
check_query = f"SELECT * FROM {MY_CATALOG}.{DQ_SCHEMA}.configFieldAllowedPattern"
display(spark.sql(check_query))

# COMMAND ----------

# DBTITLE 1,Upsert configCustomQuery data -PySpark
(dq.config
    .add_custom_query(full_field_name='email_address', expression='(  (@InputValue LIKE \'%_@_%.__%\' AND LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) - LENGTH(REPLACE(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), \'.\', \'\')) = 1)  OR (@InputValue LIKE \'%_@_%.__%.__%\' AND LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) - LENGTH(REPLACE(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), \'.\', \'\')) = 2)  OR (@InputValue LIKE \'%_@_%.__%._%._%\' AND LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) - LENGTH(REPLACE(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), \'.\', \'\')) > 2) )', is_condition_allowed=True, query_id=1, custom_query_type='SQL', description='Basic validations to ensure Pattern of valid email address.', is_active=True, created_by=None, last_updated_by=None)
    .add_custom_query(full_field_name='email_address', expression='( LOCATE(\'@\', @InputValue) > 1 AND LOCATE(\'@\', @InputValue) < LENGTH(@InputValue) AND LOCATE(\'@\', REVERSE(@InputValue)) > LOCATE(\'.\', REVERSE(@InputValue)) AND (LENGTH(@InputValue) - LENGTH(REPLACE(@InputValue, \'@\', \'\'))) = 1 )', is_condition_allowed=True, query_id=2, custom_query_type='SQL', description='Additional validations to ensure Pattern of valid email address- 1. Ensure \'@\' is not the first character 2. Ensure \'@\' is not the last character 3. Ensure at least one dot after \'@\' 4. Ensure only one \'@\' symbol', is_active=True, created_by=None, last_updated_by=None)
    .add_custom_query(full_field_name='email_address', expression='LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) > 0 AND (LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)))  - LENGTH(REPLACE(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), \'.\', \'\'))  BETWEEN 1 AND 3 ) AND @InputValue NOT LIKE \'%.\' AND (LOCATE(\'..\', SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) = 0   AND LENGTH(SUBSTRING(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), LOCATE(\'.\', SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) + 1, LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))))) >= 2   AND (LOCATE(\'.\', SUBSTRING(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), LOCATE(\'.\', SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) + 1, LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))))) = 0    OR LENGTH(SUBSTRING(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), LOCATE(\'.\', SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), LOCATE(\'.\', SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) + 1) + 1, LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))))) >= 2) )', is_condition_allowed=True, query_id=3, custom_query_type='SQL', description='1. Extract the domain part after \'@\' and ensure  \'.\' (periods) atleast 1 & atmost 3 2. Validate that domain labels are not empty and ensure there are no consecutive periods and each part is at least one character long', is_active=True, created_by=None, last_updated_by=None)
    .add_custom_query(full_field_name='email_address', expression='LENGTH(SUBSTRING(@InputValue, 1, LOCATE(\'@\', @InputValue) - 1)) - LENGTH(REPLACE(SUBSTRING(@InputValue, 1, LOCATE(\'@\', @InputValue) - 1), \'.\', \'\')) < 3', is_condition_allowed=True, query_id=4, custom_query_type='SQL', description='Ensure that main part does not contain more than 2 \'.\' (periods)', is_active=True, created_by=None, last_updated_by=None)
    .add_custom_query(full_field_name='email_address', expression='@InputValue LIKE \'%noemaildress%\'', is_condition_allowed=False, query_id=5, custom_query_type='SQL', description='Ensure that email does not contain a keyword like \'noemaildress\'', is_active=True, created_by=None, last_updated_by=None)
    .add_custom_query(full_field_name='email_address', expression='@InputValue RLIKE \'.*[-._]$\'', is_condition_allowed=False, query_id=6, custom_query_type='SQL', description='Ensure that email does not end with allowed special characters', is_active=True, created_by=None, last_updated_by=None)
    .add_custom_query(full_field_name='email_address', expression='^[a-zA-Z0-9._%+\\-]+@[a-zA-Z0-9]([a-zA-Z0-9\\-]{0,61}[a-zA-Z0-9])?(\\.[a-zA-Z0-9]([a-zA-Z0-9\\-]{0,61}[a-zA-Z0-9])?)*\\.[a-zA-Z]{2,}$', is_condition_allowed=True, query_id=7, custom_query_type='REGEX', description='Validates email address format: RFC-compliant structure with alphanumeric/special-char local part, domain labels max 63 chars with no leading/trailing hyphens, no consecutive dots, and TLD minimum 2 alpha characters.', is_active=True, created_by=None, last_updated_by=None)
    .add_custom_query(full_field_name='check_vendor_license_number', expression='^[A-Z]{2,4}/[A-Z]{2}[0-9]{3}-[0-9]{3}$', is_condition_allowed=True, query_id=8, custom_query_type='REGEX', description='Validates vendor code format: 2-4 uppercase org prefix, forward-slash separator, 2 uppercase type code letters, 3-digit sequence, hyphen, 3-digit version (e.g. ACME/WH001-003).', is_active=True, created_by=None, last_updated_by=None)
)

# COMMAND ----------

# DBTITLE 1,Upsert configCustomQuery data -SQL
query = f"""
MERGE INTO `{MY_CATALOG}`.`{DQ_SCHEMA}`.`configCustomQuery` AS t
USING (
    SELECT * FROM (
        SELECT NULL AS _ID, NULL AS FullFieldName, NULL AS CustomQueryType, NULL AS CustomQuery, NULL AS CustomQueryDescription, NULL AS IsConditionAllowed, NULL AS IsActive, NULL AS CreatedBy, NULL AS CreatedOn, NULL AS LastUpdatedBy, NULL AS LastUpdatedOn UNION ALL 
        SELECT 1, 'email_address', 'SQL', '(  (@InputValue LIKE \'%_@_%.__%\' AND LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) - LENGTH(REPLACE(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), \'.\', \'\')) = 1)  OR (@InputValue LIKE \'%_@_%.__%.__%\' AND LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) - LENGTH(REPLACE(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), \'.\', \'\')) = 2)  OR (@InputValue LIKE \'%_@_%.__%._%._%\' AND LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) - LENGTH(REPLACE(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), \'.\', \'\')) > 2) )', 'Basic validations to ensure Pattern of valid email address.', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 2, 'email_address', 'SQL', '( LOCATE(\'@\', @InputValue) > 1 AND LOCATE(\'@\', @InputValue) < LENGTH(@InputValue) AND LOCATE(\'@\', REVERSE(@InputValue)) > LOCATE(\'.\', REVERSE(@InputValue)) AND (LENGTH(@InputValue) - LENGTH(REPLACE(@InputValue, \'@\', \'\'))) = 1 )', 'Additional validations to ensure Pattern of valid email address- 1. Ensure ''@'' is not the first character 2. Ensure ''@'' is not the last character 3. Ensure at least one dot after ''@'' 4. Ensure only one ''@'' symbol', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 3, 'email_address', 'SQL', 'LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) > 0 AND (LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)))  - LENGTH(REPLACE(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), \'.\', \'\'))  BETWEEN 1 AND 3 ) AND @InputValue NOT LIKE \'%.\' AND (LOCATE(\'..\', SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) = 0   AND LENGTH(SUBSTRING(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), LOCATE(\'.\', SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) + 1, LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))))) >= 2   AND (LOCATE(\'.\', SUBSTRING(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), LOCATE(\'.\', SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) + 1, LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))))) = 0    OR LENGTH(SUBSTRING(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), LOCATE(\'.\', SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), LOCATE(\'.\', SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) + 1) + 1, LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))))) >= 2) )', '1. Extract the domain part after ''@'' and ensure  ''.'' (periods) atleast 1 & atmost 3 2. Validate that domain labels are not empty and ensure there are no consecutive periods and each part is at least one character long', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 4, 'email_address', 'SQL', 'LENGTH(SUBSTRING(@InputValue, 1, LOCATE(\'@\', @InputValue) - 1)) - LENGTH(REPLACE(SUBSTRING(@InputValue, 1, LOCATE(\'@\', @InputValue) - 1), \'.\', \'\')) < 3', 'Ensure that main part does not contain more than 2 ''.'' (periods)', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 5, 'email_address', 'SQL', '@InputValue LIKE \'%noemaildress%\'', 'Ensure that email does not contain a keyword like ''noemaildress''', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 6, 'email_address', 'SQL', '@InputValue RLIKE \'.*[-._]$\'', 'Ensure that email does not end with allowed special characters', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 7, 'email_address', 'REGEX', '^[a-zA-Z0-9._%+\\-]+@[a-zA-Z0-9]([a-zA-Z0-9\\-]{0,61}[a-zA-Z0-9])?(\\.[a-zA-Z0-9]([a-zA-Z0-9\\-]{0,61}[a-zA-Z0-9])?)*\\.[a-zA-Z]{2,}$', 'Validates email address format: RFC-compliant structure with alphanumeric/special-char local part, domain labels max 63 chars with no leading/trailing hyphens, no consecutive dots, and TLD minimum 2 alpha characters.', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 8, 'check_vendor_license_number', 'REGEX', '^[A-Z]{2,4}/[A-Z]{2}[0-9]{3}-[0-9]{3}$', 'Validates vendor code format: 2-4 uppercase org prefix, forward-slash separator, 2 uppercase type code letters, 3-digit sequence, hyphen, 3-digit version (e.g. ACME/WH001-003).', true, true, current_user(), current_timestamp(), NULL, NULL 
    ) WHERE _ID IS NOT NULL
) AS s ON t._ID = s._ID
WHEN MATCHED AND (
    t.CustomQuery        <> s.CustomQuery OR
    t.IsConditionAllowed <> s.IsConditionAllowed OR
    t.IsActive           <> s.IsActive
) THEN UPDATE SET
    t.CustomQuery        = s.CustomQuery,
    t.CustomQueryType    = s.CustomQueryType,
    t.IsConditionAllowed = s.IsConditionAllowed,
    t.IsActive           = s.IsActive,
    t.LastUpdatedBy      = current_user(),
    t.LastUpdatedOn      = current_timestamp()
WHEN NOT MATCHED THEN INSERT (
    _ID, FullFieldName, CustomQueryType, CustomQuery, CustomQueryDescription,
    IsConditionAllowed, IsActive,
    CreatedBy, CreatedOn, LastUpdatedBy, LastUpdatedOn
) VALUES (
    s._ID, s.FullFieldName, s.CustomQueryType, s.CustomQuery, s.CustomQueryDescription,
    s.IsConditionAllowed, s.IsActive,
    s.CreatedBy, s.CreatedOn, s.LastUpdatedBy, s.LastUpdatedOn
)
"""
spark.sql(query)

# COMMAND ----------

# DBTITLE 1,Upsert configCustomQuery data -SQL v2
# Paste Excel N-column rows into r"""...""" (raw string, no f-prefix)
_rows = r"""
SELECT NULL AS _ID, NULL AS FullFieldName, NULL AS CustomQueryType, NULL AS CustomQuery, NULL AS CustomQueryDescription, NULL AS IsConditionAllowed, NULL AS IsActive, NULL AS CreatedBy, NULL AS CreatedOn, NULL AS LastUpdatedBy, NULL AS LastUpdatedOn UNION ALL 
SELECT 1, 'email_address', 'SQL', '(  (@InputValue LIKE \'%_@_%.__%\' AND LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) - LENGTH(REPLACE(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), \'.\', \'\')) = 1)  OR (@InputValue LIKE \'%_@_%.__%.__%\' AND LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) - LENGTH(REPLACE(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), \'.\', \'\')) = 2)  OR (@InputValue LIKE \'%_@_%.__%._%._%\' AND LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) - LENGTH(REPLACE(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), \'.\', \'\')) > 2) )', 'Basic validations to ensure Pattern of valid email address.', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL
SELECT 2, 'email_address', 'SQL', '( LOCATE(\'@\', @InputValue) > 1 AND LOCATE(\'@\', @InputValue) < LENGTH(@InputValue) AND LOCATE(\'@\', REVERSE(@InputValue)) > LOCATE(\'.\', REVERSE(@InputValue)) AND (LENGTH(@InputValue) - LENGTH(REPLACE(@InputValue, \'@\', \'\'))) = 1 )', 'Additional validations to ensure Pattern of valid email address- 1. Ensure ''@'' is not the first character 2. Ensure ''@'' is not the last character 3. Ensure at least one dot after ''@'' 4. Ensure only one ''@'' symbol', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL
SELECT 3, 'email_address', 'SQL', 'LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) > 0 AND (LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)))  - LENGTH(REPLACE(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), \'.\', \'\'))  BETWEEN 1 AND 3 ) AND @InputValue NOT LIKE \'%.\' AND (LOCATE(\'..\', SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) = 0   AND LENGTH(SUBSTRING(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), LOCATE(\'.\', SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) + 1, LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))))) >= 2   AND (LOCATE(\'.\', SUBSTRING(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), LOCATE(\'.\', SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) + 1, LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))))) = 0    OR LENGTH(SUBSTRING(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), LOCATE(\'.\', SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue)), LOCATE(\'.\', SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))) + 1) + 1, LENGTH(SUBSTRING(@InputValue, LOCATE(\'@\', @InputValue) + 1, LENGTH(@InputValue))))) >= 2) )', '1. Extract the domain part after ''@'' and ensure  ''.'' (periods) atleast 1 & atmost 3 2. Validate that domain labels are not empty and ensure there are no consecutive periods and each part is at least one character long', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL
SELECT 4, 'email_address', 'SQL', 'LENGTH(SUBSTRING(@InputValue, 1, LOCATE(\'@\', @InputValue) - 1)) - LENGTH(REPLACE(SUBSTRING(@InputValue, 1, LOCATE(\'@\', @InputValue) - 1), \'.\', \'\')) < 3', 'Ensure that main part does not contain more than 2 ''.'' (periods)', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL
SELECT 5, 'email_address', 'SQL', '@InputValue LIKE \'%noemaildress%\'', 'Ensure that email does not contain a keyword like ''noemaildress''', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL
SELECT 6, 'email_address', 'SQL', '@InputValue RLIKE \'.*[-._]$\'', 'Ensure that email does not end with allowed special characters', false, true, current_user(), current_timestamp(), NULL, NULL UNION ALL
SELECT 7, 'email_address', 'REGEX', '^[a-zA-Z0-9._%+\\-]+@[a-zA-Z0-9]([a-zA-Z0-9\\-]{0,61}[a-zA-Z0-9])?(\\.[a-zA-Z0-9]([a-zA-Z0-9\\-]{0,61}[a-zA-Z0-9])?)*\\.[a-zA-Z]{2,}$', 'Validates email address format: RFC-compliant structure with alphanumeric/special-char local part, domain labels max 63 chars with no leading/trailing hyphens, no consecutive dots, and TLD minimum 2 alpha characters.', true, true, current_user(), current_timestamp(), NULL, NULL UNION ALL
SELECT 8, 'check_vendor_license_number', 'REGEX', '^[A-Z]{2,4}/[A-Z]{2}[0-9]{3}-[0-9]{3}$', 'Validates vendor code format: 2-4 uppercase org prefix, forward-slash separator, 2 uppercase type code letters, 3-digit sequence, hyphen, 3-digit version (e.g. ACME/WH001-003).', true, true, current_user(), current_timestamp(), NULL, NULL 
"""

# print(_rows)

spark.sql(f"""
MERGE INTO `{MY_CATALOG}`.`{DQ_SCHEMA}`.`configCustomQuery` AS t
USING (
    SELECT * FROM (
""" + _rows + f"""
    ) WHERE _ID IS NOT NULL
) AS s ON t._ID = s._ID
WHEN MATCHED AND (
    t.CustomQuery        <> s.CustomQuery OR
    t.IsConditionAllowed <> s.IsConditionAllowed OR
    t.IsActive           <> s.IsActive
) THEN UPDATE SET
    t.CustomQuery        = s.CustomQuery,
    t.CustomQueryType    = s.CustomQueryType,
    t.IsConditionAllowed = s.IsConditionAllowed,
    t.IsActive           = s.IsActive,
    t.LastUpdatedBy      = current_user(),
    t.LastUpdatedOn      = current_timestamp()
WHEN NOT MATCHED THEN INSERT (
    _ID, FullFieldName, CustomQueryType, CustomQuery, CustomQueryDescription,
    IsConditionAllowed, IsActive,
    CreatedBy, CreatedOn, LastUpdatedBy, LastUpdatedOn
) VALUES (
    s._ID, s.FullFieldName, s.CustomQueryType, s.CustomQuery, s.CustomQueryDescription,
    s.IsConditionAllowed, s.IsActive,
    s.CreatedBy, s.CreatedOn, s.LastUpdatedBy, s.LastUpdatedOn
)
""")

# COMMAND ----------

# DBTITLE 1,configCustomQuery -Data
check_query = f"SELECT * FROM {MY_CATALOG}.{DQ_SCHEMA}.configCustomQuery"
display(spark.sql(check_query))

# COMMAND ----------

# DBTITLE 1,Upsert mapDQChecks data -PySpark
(dq.config
    .add_mapping(full_field_name='email_address', target_schema_name='silver', target_table_name='mock_curated_contacts', target_field_name='email_address', mapping_id=1, dq_function_schema_name='dq', dq_function_name='fn_DQ_email_address', is_active=True, created_by=None, last_updated_by=None)
    .add_mapping(full_field_name='postal_code_all_country', target_schema_name='silver', target_table_name='mock_curated_locations', target_field_name='postal_code', mapping_id=2, dq_function_schema_name='dq', dq_function_name='fn_DQ_postal_code_all_country', is_active=True, created_by=None, last_updated_by=None)
    .add_mapping(full_field_name='trade_type', target_schema_name='silver', target_table_name='mock_curated_vendors', target_field_name='trade_type', mapping_id=3, dq_function_schema_name='dq', dq_function_name='fn_DQ_trade_type', is_active=True, created_by=None, last_updated_by=None)
    .add_mapping(full_field_name='state', target_schema_name='silver', target_table_name='mock_curated_locations', target_field_name='state', mapping_id=4, dq_function_schema_name='dq', dq_function_name='fn_DQ_state', is_active=True, created_by=None, last_updated_by=None)
    .add_mapping(full_field_name='city', target_schema_name='silver', target_table_name='mock_curated_locations', target_field_name='city', mapping_id=5, dq_function_schema_name='dq', dq_function_name='fn_DQ_city', is_active=True, created_by=None, last_updated_by=None)
    .add_mapping(full_field_name='address_line_1', target_schema_name='silver', target_table_name='mock_curated_locations', target_field_name='address1', mapping_id=6, dq_function_schema_name='dq', dq_function_name='fn_DQ_address_line_1', is_active=True, created_by=None, last_updated_by=None)
    .add_mapping(full_field_name='address_line_1', target_schema_name='silver', target_table_name='mock_curated_locations', target_field_name='address2', mapping_id=7, dq_function_schema_name='dq', dq_function_name='fn_DQ_address_line_1', is_active=True, created_by=None, last_updated_by=None)
    .add_mapping(full_field_name='address_general', target_schema_name='silver', target_table_name='mock_curated_locations', target_field_name='address4', mapping_id=8, dq_function_schema_name='dq', dq_function_name='fn_DQ_address_general', is_active=True, created_by=None, last_updated_by=None)
    .add_mapping(full_field_name='country', target_schema_name='silver', target_table_name='mock_curated_locations', target_field_name='country', mapping_id=9, dq_function_schema_name='dq', dq_function_name='fn_DQ_country', is_active=True, created_by=None, last_updated_by=None)
    .add_mapping(full_field_name='address_line_2', target_schema_name='silver', target_table_name='mock_curated_locations', target_field_name='address3', mapping_id=10, dq_function_schema_name='dq', dq_function_name='fn_DQ_address_line_2', is_active=True, created_by=None, last_updated_by=None)
    .add_mapping(full_field_name='mobile_number_without_country', target_schema_name='silver', target_table_name='mock_curated_contacts', target_field_name='raw_phone_number', mapping_id=11, dq_function_schema_name='dq', dq_function_name='fn_DQ_mobile_number_without_country', is_active=True, created_by=None, last_updated_by=None)
    .add_mapping(full_field_name='name_general', target_schema_name='silver', target_table_name='mock_curated_vendors', target_field_name='last_name', mapping_id=12, dq_function_schema_name='dq', dq_function_name='fn_DQ_name_general', is_active=True, created_by=None, last_updated_by=None)
    .add_mapping(full_field_name='vendor_name', target_schema_name='silver', target_table_name='mock_curated_vendors', target_field_name='vendor_name', mapping_id=13, dq_function_schema_name='dq', dq_function_name='fn_DQ_vendor_name', is_active=True, created_by=None, last_updated_by=None)
    .add_mapping(full_field_name='first_name', target_schema_name='silver', target_table_name='mock_curated_vendors', target_field_name='first_name', mapping_id=14, dq_function_schema_name='dq', dq_function_name='fn_DQ_first_name', is_active=True, created_by=None, last_updated_by=None)
    .add_mapping(full_field_name='phone_number', target_schema_name='silver', target_table_name='mock_curated_contacts', target_field_name='phone_number', mapping_id=15, dq_function_schema_name='dq', dq_function_name='fn_DQ_phone_number', is_active=True, created_by=None, last_updated_by=None)
    .add_mapping(full_field_name='check_vendor_license_number', target_schema_name='silver', target_table_name='mock_curated_vendors', target_field_name='vendor_code', mapping_id=16, dq_function_schema_name='dq', dq_function_name='fn_DQ_check_vendor_license_number', is_active=True, created_by=None, last_updated_by=None)
)


# COMMAND ----------

# DBTITLE 1,Upsert mapDQChecks data -SQL
query = f"""
MERGE INTO `{MY_CATALOG}`.`{DQ_SCHEMA}`.`mapDQChecks` AS t
USING (
    SELECT * FROM (
        SELECT NULL AS _ID, NULL AS FullFieldName, NULL AS TargetCatalogName, NULL AS TargetSchemaName, NULL AS TargetTableName, NULL AS TargetFieldName, NULL AS DQFunctionSchemaName, NULL AS DQFunctionName, NULL AS IsActive, NULL AS CreatedBy, NULL AS CreatedOn, NULL AS LastUpdatedBy, NULL AS LastUpdatedOn UNION ALL 
        SELECT 1, 'email_address', NULL, 'silver', 'mock_curated_contacts', 'email_address', 'dq', 'fn_DQ_email_address', true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 2, 'postal_code_all_country', NULL, 'silver', 'mock_curated_locations', 'postal_code', 'dq', 'fn_DQ_postal_code_all_country', true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 3, 'trade_type', NULL, 'silver', 'mock_curated_vendors', 'trade_type', 'dq', 'fn_DQ_trade_type', true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 4, 'state', NULL, 'silver', 'mock_curated_locations', 'state', 'dq', 'fn_DQ_state', true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 5, 'city', NULL, 'silver', 'mock_curated_locations', 'city', 'dq', 'fn_DQ_city', true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 6, 'address_line_1', NULL, 'silver', 'mock_curated_locations', 'address1', 'dq', 'fn_DQ_address_line_1', true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 7, 'address_line_1', NULL, 'silver', 'mock_curated_locations', 'address2', 'dq', 'fn_DQ_address_line_1', true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 8, 'address_general', NULL, 'silver', 'mock_curated_locations', 'address4', 'dq', 'fn_DQ_address_general', true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 9, 'country', NULL, 'silver', 'mock_curated_locations', 'country', 'dq', 'fn_DQ_country', true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 10, 'address_line_2', NULL, 'silver', 'mock_curated_locations', 'address3', 'dq', 'fn_DQ_address_line_2', true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 11, 'mobile_number_without_country', NULL, 'silver', 'mock_curated_contacts', 'raw_phone_number', 'dq', 'fn_DQ_mobile_number_without_country', true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 12, 'name_general', NULL, 'silver', 'mock_curated_vendors', 'last_name', 'dq', 'fn_DQ_name_general', true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 13, 'vendor_name', NULL, 'silver', 'mock_curated_vendors', 'vendor_name', 'dq', 'fn_DQ_vendor_name', true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 14, 'first_name', NULL, 'silver', 'mock_curated_vendors', 'first_name', 'dq', 'fn_DQ_first_name', true, current_user(), current_timestamp(), NULL, NULL UNION ALL
        SELECT 15, 'phone_number', NULL, 'silver', 'mock_curated_contacts', 'phone_number', 'dq', 'fn_DQ_phone_number', true, current_user(), current_timestamp(), NULL, NULL UNION ALL 
        SELECT 16, 'check_vendor_license_number', NULL, 'silver', 'mock_curated_vendors', 'vendor_code', 'dq', 'fn_DQ_check_vendor_license_number', true, current_user(), current_timestamp(), NULL, NULL 
    ) WHERE _ID IS NOT NULL
) AS s ON t._ID = s._ID
WHEN MATCHED AND (
    t.TargetSchemaName    <> s.TargetSchemaName  OR
    t.TargetTableName     <> s.TargetTableName   OR
    t.TargetFieldName     <> s.TargetFieldName   OR
    t.IsActive            <> s.IsActive
) THEN UPDATE SET
    t.TargetCatalogName    = s.TargetCatalogName,
    t.TargetSchemaName     = s.TargetSchemaName,
    t.TargetTableName      = s.TargetTableName,
    t.TargetFieldName      = s.TargetFieldName,
    t.DQFunctionSchemaName = s.DQFunctionSchemaName,
    t.DQFunctionName       = s.DQFunctionName,
    t.IsActive             = s.IsActive,
    t.LastUpdatedBy        = current_user(),
    t.LastUpdatedOn        = current_timestamp()
WHEN NOT MATCHED THEN INSERT (
    _ID, FullFieldName, TargetCatalogName, TargetSchemaName, TargetTableName,
    TargetFieldName, DQFunctionSchemaName, DQFunctionName,
    IsActive, CreatedBy, CreatedOn, LastUpdatedBy, LastUpdatedOn
) VALUES (
    s._ID, s.FullFieldName, s.TargetCatalogName, s.TargetSchemaName, s.TargetTableName,
    s.TargetFieldName, s.DQFunctionSchemaName, s.DQFunctionName,
    s.IsActive, s.CreatedBy, s.CreatedOn, s.LastUpdatedBy, s.LastUpdatedOn
)
"""
spark.sql(query)

# COMMAND ----------

# DBTITLE 1,mapDQChecks -Data
check_query = f"SELECT * FROM `{MY_CATALOG}`.`{DQ_SCHEMA}`.`mapDQChecks`"
display(spark.sql(check_query))

# COMMAND ----------

# DBTITLE 1,Display Data Quality Framework Configuration Summary
dq.config.show_config_summary()

# COMMAND ----------

# DBTITLE 1,Display Data Quality Framework Guide and Usage Help
dq.guide()

# COMMAND ----------

# DBTITLE 1,Generate Data Quality Rule Functions
dq.generate_rule_functions()

# COMMAND ----------

# DBTITLE 1,Run Data Quality Assessment and Write Results to Table
# 2. Run the assessment (writes DQEligible/DQViolations/DQFields back to the curated table)

ok = dq.validate_custom_queries_sql()
if ok:
    exec_id = dq.run_assessment(schema_name=CURATED_SCHEMA)

# COMMAND ----------

# DBTITLE 1,TEMP
# MAGIC %sql
# MAGIC select * from sampledatacatalog.silver.mock_curated_vendors where DQEligible = true
# MAGIC

# COMMAND ----------

# DBTITLE 1,Inspect Generated DQ Rules for a
dq.inspect_checker('fn_DQ_email_address', show_all_patterns=True)

# COMMAND ----------

# DBTITLE 1,Add Data Quality Columns to All Curated Tables
# 1. Add the 3 DQ columns to all your curated tables (one-time, idempotent)
dq.prepare_curated_tables()

# COMMAND ----------

# DBTITLE 1,TEMP
# MAGIC %sql
# MAGIC select * from sampledatacatalog.dq.v_auditdqchecks where ExecutionID = '7aed2ab3-d56a-4f90-a968-44d94f8731b6' and FullFieldName IN ('check_vendor_license_number','xvendor_name', 'xemail_address','xtrade_type')

# COMMAND ----------

# DBTITLE 1,TEMP
# MAGIC %sql
# MAGIC select * from sampledatacatalog.dq.auditdqchecks order by ExecutionID, _id

# COMMAND ----------

# DBTITLE 1,Run Assessment header
# MAGIC %md
# MAGIC ## Run Assessment & View Results

# COMMAND ----------

# DBTITLE 1,Display Data Quality Violations
# View violations for this run
dq.violations(exec_id).display()

# COMMAND ----------

# DBTITLE 1,Display Data Quality Scores per Field
# Quality scores per field
dq.quality_scores(exec_id).display()

# COMMAND ----------

# DBTITLE 1,Summary by table
# Summary by table
dq.summary_by_table(exec_id).display()

# COMMAND ----------

# DBTITLE 1,Display Data Quality Violations with Quality Scores below Threshold
# Fields below a quality threshold (e.g. 80%)
dq.fields_below_threshold(threshold=80).display()

# COMMAND ----------

# DBTITLE 1,DELETE Sample & DQ -Tables and Views
preScriptTable = "DROP TABLE IF EXISTS {MY_CATALOG}.{DQ_SCHEMA}."
preScriptView = "DROP VIEW IF EXISTS {MY_CATALOG}.{DQ_SCHEMA}."
list_tables = [
    "mock_curated_contacts",
    "mock_curated_locations",
    "mock_curated_vendors",
    "masterDataCategory",
    "masterPattern",
    "masterField",
    "configFieldValues",
    "configFieldAllowedPattern",
    "configCustomQuery",
    "mapDQChecks",
    "auditDQChecks",
    "statDQChecks"
]
list_views = [
    "v_auditDQChecks",
    "v_statDQChecks"
]

for table in list_tables:
    spark.sql(preScriptTable.format(table=table))
for view in list_views:
    spark.sql(preScriptView.format(view=view))

