# OpenConstructionERP — DataDrivenConstruction (DDC)
# CWICR Cost Database Engine · CAD2DATA Pipeline
# Copyright (c) 2026 Artem Boiko / DataDrivenConstruction
# AGPL-3.0 License · DDC-CWICR-OE-2026
"""‌⁠‍OpenEstimate​‌‍⁠​‌‍⁠​‌‍⁠​‌‍⁠ — FastAPI application factory.

Usage:
    uvicorn app.main:create_app --factory --reload --port 8000
    openestimate serve  (CLI mode — also serves frontend)
"""

# ── Runtime compatibility shims ─────────────────────────────────────────────
# MUST run BEFORE any import that can pull in numpy / torch / lancedb.
# On Windows + Anaconda Python, both Intel MKL (bundled with Anaconda numpy)
# and the torch wheels ship their own copy of ``libiomp5md.dll``. When the
# second copy is loaded, the OpenMP runtime aborts with:
#
#   OMP: Error #15: Initializing libiomp5md.dll, but found libiomp5md.dll
#                   already initialized.
#
# On Linux/macOS this is a warning; on Windows it is a fatal native abort
# that kills the process silently — no Python traceback, the shell just
# returns to the prompt. ``KMP_DUPLICATE_LIB_OK=TRUE`` tells the OpenMP
# runtime to accept the duplicate library instead of terminating, which
# is safe for inference workloads where we do not rely on deterministic
# thread pool ownership.
import os as _os

_os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
_os.environ.setdefault("OMP_NUM_THREADS", "1")
_os.environ.setdefault("MKL_NUM_THREADS", "1")

import hashlib as _hashlib
import logging
import os
import secrets
import time
import uuid
import uuid as _instance_uuid
from typing import Any

# Unique instance fingerprint — proves this specific deployment origin
_INSTANCE_ID = str(_instance_uuid.uuid4())
# Build-pepper. Looks like opaque crypto material; the bytes XOR-decode to
# the project authorship marker so removing it changes the published health
# build hash (deterministic across rebuilds with the same INSTANCE_ID).
_BUILD_PEPPER = bytes(b ^ 0x55 for b in (
    b"\x11\x11\x16\x78\x16\x02\x1c\x16\x07\x78\x1a\x10\x78\x67\x65\x67\x63"
))
_BUILD_HASH = _hashlib.sha256(
    _BUILD_PEPPER + f"DDC-CWICR-OE-{_INSTANCE_ID}".encode()
).hexdigest()[:16]

from datetime import UTC
from pathlib import Path

import structlog
from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware

from app.config import Settings, get_settings
from app.core.module_loader import module_loader
from app.dependencies import RequireRole, get_current_user_id

logger = logging.getLogger(__name__)


def configure_logging(settings: Settings) -> None:
    """‌⁠‍Configure structured logging."""
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.dev.ConsoleRenderer() if settings.app_debug else structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.stdlib.BoundLogger,
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )
    logging.basicConfig(level=getattr(logging, settings.log_level), format="%(message)s")


def _init_vector_db() -> None:
    """‌⁠‍Initialize vector database on startup (non-blocking, never fatal).

    Vector search is an important feature of OpenConstructionERP —
    it powers semantic cost-item matching, BOQ auto-classification,
    and assembly suggestions. We support two backends:

    * **Qdrant** (recommended for production) — dedicated server, scales
      to millions of vectors, supports snapshots. Run it locally with:
      ``docker run -p 6333:6333 qdrant/qdrant``
    * **LanceDB** (embedded, default) — zero-config, stores vectors on
      the local filesystem. Good enough for single-node deployments.

    Neither is a hard dependency: if both are unavailable, the platform
    still runs and serves all modules — only semantic search is disabled.
    This function is deliberately wrapped in a broad try/except so that
    no vector-related failure can ever block the rest of startup.
    """
    try:
        from app.core.vector import vector_status

        status = vector_status()
        engine = status.get("engine", "lancedb")
        if status.get("connected"):
            vectors = status.get("cost_collection", {})
            count = vectors.get("vectors_count", 0) if vectors else 0
            logger.info("Vector DB ready: %s (%d vectors indexed)", engine, count)
            return

        # Not connected — log a clear, actionable hint so users know how
        # to enable semantic search if they need it.
        error = status.get("error", "unknown")
        if engine == "qdrant":
            logger.warning(
                "Qdrant not reachable (%s). Semantic search is disabled. "
                "Start a local Qdrant with: docker run -p 6333:6333 qdrant/qdrant",
                error,
            )
        else:
            logger.warning(
                "LanceDB init failed (%s). Semantic search is disabled. "
                "Install the embedded vector backend with: pip install openconstructionerp[vector]",
                error,
            )
    except Exception as exc:  # noqa: BLE001 — intentional: never fatal
        # Includes ImportError (missing optional extras), native crashes
        # surfaced as OSError, etc. Semantic search is optional; the rest
        # of the application must continue to boot.
        logger.warning("Vector DB init skipped: %s", exc)


async def _auto_backfill_vector_collections() -> None:
    """Backfill the multi-collection vector store from existing rows.

    The event-driven indexing layer (added in v1.4.0) only fires for
    rows that are created or updated AFTER the upgrade.  On a fresh
    install with no data this is a no-op; on an existing v1.3.x install
    it would leave thousands of BOQ positions / documents / tasks /
    risks / BIM elements / validation reports / chat messages
    unsearchable until the user manually called every per-module
    `/vector/reindex/` endpoint.

    This helper closes that gap automatically.  For each registered
    collection it:

    1. Reads the live row count from Postgres / SQLite
    2. Reads the indexed row count from the vector store
    3. If the vector store is short, runs ``reindex_collection`` for the
       missing rows (capped by ``vector_backfill_max_rows`` per pass)

    Designed to be **non-blocking** — it runs in a detached background
    task so startup completes immediately even if the model loader has
    to download a fresh embedding checkpoint.

    All failures are logged and swallowed.  Disable entirely with
    ``vector_auto_backfill=False`` in settings.
    """
    try:
        from sqlalchemy import select

        from app.config import get_settings
        from app.core.vector import vector_count_collection
        from app.core.vector_index import (
            COLLECTION_BIM_ELEMENTS,
            COLLECTION_BOQ,
            COLLECTION_CHAT,
            COLLECTION_COSTS,
            COLLECTION_DOCUMENTS,
            COLLECTION_REQUIREMENTS,
            COLLECTION_RISKS,
            COLLECTION_TASKS,
            COLLECTION_VALIDATION,
            reindex_collection,
        )
        from app.database import async_session_factory

        settings = get_settings()
        if not settings.vector_auto_backfill:
            logger.info("Vector auto-backfill disabled by settings; skipping")
            return

        cap = max(0, int(settings.vector_backfill_max_rows or 0))

        from sqlalchemy import func
        from sqlalchemy.orm import selectinload

        async def _maybe_backfill(
            label: str,
            collection: str,
            model,
            adapter,
            *,
            options: list | None = None,
        ) -> None:
            """Backfill ``collection`` from ``model`` rows in a memory-safe way.

            Steps:
                1. Read the indexed-row count from the vector store (cheap).
                2. Issue a ``SELECT COUNT(*)`` against the model — also cheap.
                3. Skip if the index already has at least as many rows.
                4. Otherwise pull rows with ``LIMIT cap`` applied at the SQL
                   level so we never materialise the full table in memory.

            The previous implementation called ``loader(session)`` which
            executed an unbounded ``SELECT *`` and then sliced ``rows[:cap]``
            in Python — fine on a 100-row dev DB, catastrophic on a 2M-row
            production deployment because it allocates the entire result set
            before applying the cap.  Now the cap is enforced before the
            scan reaches the network.
            """
            try:
                indexed = vector_count_collection(collection) or 0
            except Exception:
                indexed = 0

            try:
                async with async_session_factory() as session:
                    # Step 1: cheap COUNT(*) — never materialises rows.
                    live_total = (
                        await session.execute(select(func.count()).select_from(model))
                    ).scalar_one() or 0

                    if not live_total:
                        return
                    if indexed >= live_total:
                        logger.debug(
                            "Backfill %s: %d/%d already indexed; skipping",
                            label,
                            indexed,
                            live_total,
                        )
                        return

                    # Step 2: decide how many rows to actually pull.
                    if cap > 0 and live_total > cap:
                        limit_to = cap
                        logger.info(
                            "Backfill %s: %d live rows exceeds cap (%d); "
                            "indexing first %d",
                            label,
                            live_total,
                            cap,
                            cap,
                        )
                    else:
                        limit_to = live_total

                    # Step 3: pull only what we need, with relationship
                    # eager-loads if the adapter needs them.
                    stmt = select(model)
                    if options:
                        stmt = stmt.options(*options)
                    stmt = stmt.limit(limit_to)
                    rows = list((await session.execute(stmt)).scalars().all())
            except Exception as exc:
                logger.debug("Backfill %s loader failed: %s", label, exc)
                return

            if not rows:
                return

            try:
                result = await reindex_collection(adapter, rows)
                logger.info(
                    "Backfill %s: indexed=%d, skipped=%d (live=%d, was=%d)",
                    label,
                    result.get("indexed", 0),
                    result.get("skipped", 0),
                    live_total,
                    indexed,
                )
            except Exception as exc:
                logger.debug("Backfill %s reindex failed: %s", label, exc)

        # ── Declarative collection registry ──────────────────────────────
        # Each tuple is (label, collection_constant, model_loader, adapter_loader,
        # options_factory).  The loaders are deferred to keep import cost low
        # and to avoid pulling every module's models into memory if the
        # auto-backfill is disabled.
        from app.modules.bim_hub.models import BIMElement
        from app.modules.bim_hub.vector_adapter import bim_element_vector_adapter
        from app.modules.boq.models import Position
        from app.modules.boq.vector_adapter import boq_position_adapter
        from app.modules.documents.models import Document
        from app.modules.documents.vector_adapter import document_vector_adapter
        from app.modules.erp_chat.models import ChatMessage
        from app.modules.erp_chat.vector_adapter import chat_message_adapter
        from app.modules.requirements.models import Requirement
        from app.modules.requirements.vector_adapter import (
            requirement_vector_adapter,
        )
        from app.modules.risk.models import RiskItem
        from app.modules.risk.vector_adapter import risk_vector_adapter
        from app.modules.tasks.models import Task
        from app.modules.tasks.vector_adapter import task_vector_adapter
        from app.modules.validation.models import ValidationReport
        from app.modules.validation.vector_adapter import validation_report_adapter

        backfill_targets = [
            (
                "BOQ positions",
                COLLECTION_BOQ,
                Position,
                boq_position_adapter,
                [selectinload(Position.boq)],
            ),
            ("Documents", COLLECTION_DOCUMENTS, Document, document_vector_adapter, None),
            ("Tasks", COLLECTION_TASKS, Task, task_vector_adapter, None),
            ("Risks", COLLECTION_RISKS, RiskItem, risk_vector_adapter, None),
            (
                "BIM elements",
                COLLECTION_BIM_ELEMENTS,
                BIMElement,
                bim_element_vector_adapter,
                [selectinload(BIMElement.model)],
            ),
            (
                "Validation reports",
                COLLECTION_VALIDATION,
                ValidationReport,
                validation_report_adapter,
                None,
            ),
            (
                "Requirements",
                COLLECTION_REQUIREMENTS,
                Requirement,
                requirement_vector_adapter,
                [selectinload(Requirement.requirement_set)],
            ),
            (
                "Chat messages",
                COLLECTION_CHAT,
                ChatMessage,
                chat_message_adapter,
                [selectinload(ChatMessage.session)],
            ),
        ]

        for label, collection_id, model, adapter, options in backfill_targets:
            await _maybe_backfill(
                label,
                collection_id,
                model,
                adapter,
                options=options,
            )

        # ── Cost catalog (oe_cost_items) ─────────────────────────────────
        # The cost adapter needs the E5 ``passage:`` prefix at encode time
        # so it can't go through ``reindex_collection`` (which uses the
        # adapter's plain ``to_text``).  Run a dedicated delta pass that
        # uses the cost-specific helper instead.
        try:
            import os as _os

            from app.modules.costs import vector_adapter as _cost_vec
            from app.modules.costs.events import (
                _delta_reindex_all_active as _cost_reindex_active,
            )
            from app.modules.costs.models import CostItem as _CostItem

            force_backfill = _os.environ.get(
                "OE_COST_VECTOR_FORCE_BACKFILL", ""
            ).strip() in ("1", "true", "True", "yes")

            indexed_count = await _cost_vec.collection_count()
            async with async_session_factory() as _sess:
                live_total = (
                    await _sess.execute(
                        select(func.count())
                        .select_from(_CostItem)
                        .where(_CostItem.is_active.is_(True))
                    )
                ).scalar_one() or 0

            if not live_total:
                logger.debug("Backfill Cost catalog: 0 live rows; skipping")
            elif not force_backfill and indexed_count >= live_total:
                logger.debug(
                    "Backfill Cost catalog: %d/%d already indexed; skipping",
                    indexed_count,
                    live_total,
                )
            else:
                # Cap by the same setting as every other collection so
                # we don't saturate the embedder on first boot.
                if cap > 0 and live_total > cap:
                    logger.info(
                        "Backfill Cost catalog: %d live rows exceeds cap "
                        "(%d); will index in chunks via the existing "
                        "delta pass",
                        live_total,
                        cap,
                    )
                indexed = await _cost_reindex_active()
                logger.info(
                    "Backfill Cost catalog: indexed=%d (live=%d, was=%d, "
                    "force=%s)",
                    indexed,
                    live_total,
                    indexed_count,
                    force_backfill,
                )
        except Exception as exc:
            logger.debug("Backfill Cost catalog skipped: %s", exc)

        # Sentinel — keeps imports above flagged as used by ruff F401 even
        # if a future refactor drops one of the targeted collections.
        _ = COLLECTION_COSTS

        logger.info("Vector auto-backfill pass complete")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Vector auto-backfill skipped: %s", exc)


def _resolve_demo_password(env_var: str) -> tuple[str, bool]:
    """Resolve the password for one demo account.

    Returns ``(password, was_generated)``. If the operator set the matching
    env var to a non-empty string we honour it as-is. Otherwise we generate
    a fresh ``secrets.token_urlsafe(16)`` (22 url-safe chars). Generated
    passwords are persisted by ``_persist_demo_credentials`` so the CLI
    banner can read them back after the seeder runs — see BUG-D01 for why
    no hardcoded fallback is acceptable here.
    """
    env_value = os.environ.get(env_var)
    if env_value:
        return env_value, False
    return secrets.token_urlsafe(16), True


def _persist_demo_credentials(creds: dict[str, str]) -> Path | None:
    """Write generated demo credentials to a 0600 file.

    Falls back to ``~/.openestimator/.demo_credentials.json`` when the CLI
    didn't expose a data directory. Returns the path written, or ``None``
    if the write failed (best-effort — never let credential persistence
    block startup).
    """
    import json as _json
    import stat as _stat

    target_dir = os.environ.get("OE_CLI_DATA_DIR")
    if target_dir:
        base = Path(target_dir)
    else:
        base = Path.home() / ".openestimator"
    try:
        base.mkdir(parents=True, exist_ok=True)
        path = base / ".demo_credentials.json"
        # Merge with existing values so we don't overwrite earlier entries
        # if the seeder runs multiple times (idempotent boot).
        existing: dict[str, str] = {}
        if path.exists():
            try:
                existing = _json.loads(path.read_text(encoding="utf-8")) or {}
            except (OSError, ValueError):
                existing = {}
        existing.update(creds)
        path.write_text(
            _json.dumps(existing, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        try:
            path.chmod(_stat.S_IRUSR | _stat.S_IWUSR)
        except OSError:
            # Best-effort on Windows — chmod is a no-op there
            pass
        return path
    except OSError as exc:
        logger.warning("Could not persist demo credentials: %s", exc)
        return None


async def _seed_demo_account() -> None:
    """Create demo user + 5 demo projects if they don't exist yet.

    Idempotent — safe to call on every startup. Creates:

    * demo@openestimator.io        (role=admin — full walkthrough)
    * estimator@openestimator.io   (role=estimator)
    * manager@openestimator.io     (role=manager)

    Each password is read from the environment if set
    (``DEMO_USER_PASSWORD``, ``DEMO_ESTIMATOR_PASSWORD``,
    ``DEMO_MANAGER_PASSWORD``), otherwise generated per-installation via
    ``secrets.token_urlsafe(16)``. Generated values are written to
    ``~/.openestimator/.demo_credentials.json`` (chmod 600) and printed
    once to the startup log. Operators who want a stable password for
    their team can set the env vars; everyone else gets a unique secret
    they can recover from the credentials file.

    Disable demo creation entirely with ``SEED_DEMO=false`` in production.
    """
    if os.environ.get("SEED_DEMO", "true").lower() in ("false", "0", "no"):
        return

    from sqlalchemy import func, select

    from app.database import async_session_factory
    from app.modules.projects.models import Project
    from app.modules.users.models import User
    from app.modules.users.service import hash_password

    # Email → env-var-name mapping. Order matters for stable banner output.
    demo_account_specs: list[dict[str, str]] = [
        {
            "email": "demo@openestimator.io",
            "env_var": "DEMO_USER_PASSWORD",
            "full_name": "Demo User",
            "role": "admin",
        },
        {
            "email": "estimator@openestimator.io",
            "env_var": "DEMO_ESTIMATOR_PASSWORD",
            "full_name": "Sarah Chen",
            "role": "editor",
        },
        {
            "email": "manager@openestimator.io",
            "env_var": "DEMO_MANAGER_PASSWORD",
            "full_name": "Thomas Müller",
            "role": "manager",
        },
    ]

    # Track generated credentials so we can persist + print them once.
    generated_creds: dict[str, str] = {}

    try:
        from app.modules.users.service import verify_password

        async with async_session_factory() as session:
            demo: User | None = None
            for acct in demo_account_specs:
                exists = (
                    await session.execute(select(User).where(User.email == acct["email"]))
                ).scalar_one_or_none()
                if exists is not None:
                    if acct["email"] == "demo@openestimator.io":
                        demo = exists
                    # If operator set the env-var explicitly and the stored
                    # hash no longer matches that password, sync the hash so
                    # the documented credential always works after a restart.
                    env_value = os.environ.get(acct["env_var"])
                    if env_value and not verify_password(env_value, exists.hashed_password):
                        exists.hashed_password = hash_password(env_value)
                        logger.info("Demo user password synced from env: %s", acct["email"])
                    continue

                password, was_generated = _resolve_demo_password(acct["env_var"])
                if was_generated:
                    generated_creds[acct["email"]] = password

                user = User(
                    id=uuid.uuid4(),
                    email=acct["email"],
                    hashed_password=hash_password(password),
                    full_name=acct["full_name"],
                    role=acct["role"],
                    locale="en",
                    is_active=True,
                    metadata_={},
                )
                session.add(user)
                await session.flush()
                if acct["email"] == "demo@openestimator.io":
                    demo = user
                logger.info(
                    "Demo user created: %s (password source: %s)",
                    acct["email"],
                    "env" if not was_generated else "generated",
                )

            # Persist generated passwords + print once. Operators who set
            # env vars never see this banner; new installs get a one-time
            # log line with the location.
            if generated_creds:
                creds_path = _persist_demo_credentials(generated_creds)
                logger.warning(
                    "Demo credentials generated for %d account(s). "
                    "Saved to %s — recover the passwords from there or "
                    "set DEMO_USER_PASSWORD / DEMO_ESTIMATOR_PASSWORD / "
                    "DEMO_MANAGER_PASSWORD before next boot to override.",
                    len(generated_creds),
                    creds_path or "(persistence failed — check logs)",
                )
                # Log each generated password ONCE so a fresh log capture
                # can reconstruct them. Subsequent boots find the user
                # row already present and skip this branch entirely.
                for email, pw in generated_creds.items():
                    logger.warning("  %s: %s", email, pw)

            # 2. Install 5 demo projects if user has none
            count = (
                await session.execute(select(func.count()).select_from(Project).where(Project.owner_id == demo.id))
            ).scalar() or 0

            if count == 0:
                # Fresh-install seed: cap strictly at 5 (DEFAULT_DEMO_IDS).
                # Drift-prevention: if the constant ever exceeds five, we abort
                # so a future PR can't silently re-introduce demo bloat.
                from app.core.demo_projects import DEFAULT_DEMO_IDS, install_demo_project

                if len(DEFAULT_DEMO_IDS) > 5:
                    logger.error(
                        "DEFAULT_DEMO_IDS has %d entries — fresh-install seed is capped at 5. Aborting auto-seed.",
                        len(DEFAULT_DEMO_IDS),
                    )
                    return

                for demo_id in DEFAULT_DEMO_IDS:
                    try:
                        result = await install_demo_project(session, demo_id)
                        logger.info(
                            "Demo project installed: %s (%s positions, %s %s)",
                            demo_id,
                            result.get("positions"),
                            result.get("currency"),
                            result.get("grand_total"),
                        )
                    except Exception:
                        logger.warning("Failed to install demo %s (skipping)", demo_id)

            await session.commit()
    except Exception:
        logger.exception("Failed to seed demo account (non-fatal)")


def create_app() -> FastAPI:
    """Application factory.

    Creates and configures the FastAPI application:
    1. Load settings
    2. Configure logging
    3. Create FastAPI instance
    4. Add middleware
    5. Mount system routes
    6. Discover & load modules (on startup)
    """
    settings = get_settings()
    configure_logging(settings)

    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        description="Open-source modular platform for construction cost estimation",
        docs_url="/api/docs" if not settings.is_production else None,
        redoc_url="/api/redoc" if not settings.is_production else None,
        # BUG-394: don't expose the full OpenAPI schema in production — it
        # hands attackers a route/parameter enumeration map of every endpoint,
        # including rarely-exercised admin surfaces. Dev still gets it for
        # the Swagger/ReDoc UI and for openapi-typescript client generation.
        openapi_url="/api/openapi.json" if not settings.is_production else None,
        swagger_ui_oauth2_redirect_url=("/api/docs/oauth2-redirect" if not settings.is_production else None),
        redirect_slashes=False,
        # NOTE: do NOT set default_response_class=ORJSONResponse here.
        # FastAPI's own deprecation warning explains why: "FastAPI now
        # serializes data directly to JSON bytes via Pydantic when a
        # return type or response model is set, which is faster and
        # doesn't need a custom response class." More importantly,
        # orjson rejects NaN/Infinity floats by default — DDC cad2data
        # BIM elements occasionally emit NaN bbox coordinates for
        # degenerate geometry, which would 500 the response. Stick with
        # FastAPI's default Pydantic-direct path; orjson is still used
        # by handlers that explicitly opt in.
    )

    # ── Middleware ───────────────────────────────────────────────────────
    cors_origins = settings.cors_origins
    # Security: block wildcard origins in production
    if settings.is_production and "*" in cors_origins:
        logger.warning(
            "CORS: wildcard '*' origin is not allowed in production. Set ALLOWED_ORIGINS to your actual domain(s)."
        )
        cors_origins = [o for o in cors_origins if o != "*"]
        if not cors_origins:
            cors_origins = ["https://openconstructionerp.com"]

    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "HEAD", "POST", "PATCH", "PUT", "DELETE", "OPTIONS"],
        allow_headers=["Content-Type", "Authorization", "Accept", "Accept-Language"],
    )

    # ── API Version header ──────────────────────────────────────────────
    from starlette.middleware.base import BaseHTTPMiddleware
    from starlette.requests import Request as StarletteRequest
    from starlette.responses import Response as StarletteResponse

    class APIVersionMiddleware(BaseHTTPMiddleware):
        """Add X-API-Version response header to every API response."""

        async def dispatch(self, request: StarletteRequest, call_next):  # noqa: ANN001, ANN201
            response: StarletteResponse = await call_next(request)
            response.headers["X-API-Version"] = settings.app_version
            return response

    app.add_middleware(APIVersionMiddleware)

    # ── Reject non-finite floats in JSON request bodies ─────────────────
    # Python's ``json`` decoder accepts the non-standard ``NaN`` / ``Infinity``
    # literals by default. Several handlers use those values in Decimal
    # arithmetic downstream and raise ``decimal.InvalidOperation`` → 500.
    # We refuse them up-front with 422 so clients get a deterministic error
    # and Pydantic validators still see finite numbers.
    import re as _re

    import orjson as _orjson
    from starlette.types import ASGIApp, Message, Receive, Scope, Send

    _NONFINITE_TOKEN_RE = _re.compile(rb"\b(NaN|-?Infinity)\b")

    class _RejectNonFiniteJSONMiddleware:
        """Pure-ASGI middleware so we can rewrite the receive() stream."""

        def __init__(self, app: ASGIApp) -> None:
            self.inner = app

        async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
            if scope.get("type") != "http":
                await self.inner(scope, receive, send)
                return
            method = scope.get("method", "").upper()
            if method not in ("POST", "PUT", "PATCH"):
                await self.inner(scope, receive, send)
                return
            headers = dict(scope.get("headers") or [])
            content_type = headers.get(b"content-type", b"").decode("latin-1", "ignore")
            if "application/json" not in content_type.lower():
                await self.inner(scope, receive, send)
                return

            # Drain body up-front so we can scan it AND replay it to the app.
            body = bytearray()
            more = True
            while more:
                message = await receive()
                if message["type"] != "http.request":
                    await self.inner(scope, receive, send)
                    return
                body.extend(message.get("body") or b"")
                more = message.get("more_body", False)

            if _NONFINITE_TOKEN_RE.search(bytes(body)):
                # Extra safety: confirm the tokens occur outside a string literal
                # before rejecting. ``orjson`` rejects non-finite floats by
                # default, so parsing failure with the token present = real
                # non-finite number.
                try:
                    _orjson.loads(bytes(body))
                except _orjson.JSONDecodeError:
                    from starlette.responses import JSONResponse

                    resp = JSONResponse(
                        status_code=422,
                        content={
                            "detail": (
                                "NaN and Infinity are not accepted in numeric fields"
                            )
                        },
                    )
                    await resp(scope, receive, send)
                    return

            sent = False

            async def replay() -> Message:
                nonlocal sent
                if not sent:
                    sent = True
                    return {"type": "http.request", "body": bytes(body), "more_body": False}
                return {"type": "http.disconnect"}

            await self.inner(scope, replay, send)

    app.add_middleware(_RejectNonFiniteJSONMiddleware)

    # ── DDC Fingerprint ──────────────────────────────────────────────────
    from app.middleware.fingerprint import DDCFingerprintMiddleware

    app.add_middleware(DDCFingerprintMiddleware)

    # ── Security headers (X-Frame-Options, CSP, HSTS, etc.) ──────────────
    from app.middleware.security_headers import SecurityHeadersMiddleware

    app.add_middleware(SecurityHeadersMiddleware)

    # ── Slow request logger (warns on > 500ms responses) ──────────────────
    from app.middleware.slow_request_logger import SlowRequestLoggerMiddleware

    app.add_middleware(SlowRequestLoggerMiddleware)

    # ── SQLite lock retry (transient "database is locked" → retry) ─────────
    # Only retries on sqlite-specific lock errors — PostgreSQL paths pass
    # through untouched. Smooths over Part 5 BUG-118/119 on single-file
    # SQLite deployments without masking real write failures.
    if "sqlite" in settings.database_url.lower():
        from app.middleware.sqlite_retry import SQLiteLockRetryMiddleware

        app.add_middleware(SQLiteLockRetryMiddleware)

    # ── Accept-Language (sets i18n context locale per request) ────────────
    from app.middleware.accept_language import AcceptLanguageMiddleware

    app.add_middleware(AcceptLanguageMiddleware)

    # ── Global exception handler — return JSON for unhandled errors ────
    from fastapi import Request
    from fastapi.exceptions import RequestValidationError
    from fastapi.responses import JSONResponse

    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception) -> JSONResponse:
        logger.exception("Unhandled exception on %s %s", request.method, request.url.path)
        return JSONResponse(
            status_code=500,
            content={"detail": "Internal server error"},
        )

    # BUG-API02: sanitise FastAPI's default RequestValidationError response.
    #
    # Out of the box FastAPI returns 422 with a body that exposes the path
    # parameter name and its expected Pydantic type, e.g.
    #   {"detail":[{"type":"uuid_parsing","loc":["path","user_id"],"input":"abc"}]}
    # An unauthenticated probe can read those bodies to enumerate the route
    # surface (param names + types). For path-param validation failures —
    # which mostly mean "the URL was malformed" — we collapse the response
    # to a generic 400 with no schema details.
    #
    # Body / query-param validation errors keep the legacy 422 + detail
    # behaviour because those are real client-error feedback (e.g. POST
    # /users/ with role="god" must surface "role: invalid value" so the
    # admin UI can show a useful message).  When ``app_debug`` is on, the
    # full Pydantic detail is preserved everywhere so developers can still
    # see what they broke.
    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        errors = exc.errors()
        path_only = bool(errors) and all(
            (err.get("loc") or [None])[0] == "path" for err in errors
        )

        if path_only and not settings.app_debug:
            # No detail leak — just acknowledge the URL is malformed.
            return JSONResponse(
                status_code=400,
                content={"error": "Invalid request"},
            )

        # Body / query / header validation: keep informative detail so
        # client UIs can render per-field errors.  In production we still
        # strip the raw input echo (Pydantic includes the offending value
        # in ``input`` which can echo PII / tokens).
        # ``ctx.error`` is a raw ``ValueError`` instance for ``value_error``
        # entries — not JSON-serialisable — so always coerce to ``str``
        # before emitting (regression seen with custom ``field_validator``
        # raises in BUG-MATH03 unit-catalogue checks).
        def _scrub(err: dict) -> dict:
            out = dict(err)
            ctx = out.get("ctx")
            if isinstance(ctx, dict) and "error" in ctx and not isinstance(
                ctx["error"], (str, int, float, bool, type(None))
            ):
                ctx = dict(ctx)
                ctx["error"] = str(ctx["error"])
                out["ctx"] = ctx
            return out

        if settings.app_debug:
            safe_errors = [_scrub(e) for e in errors]
        else:
            safe_errors = [
                {k: v for k, v in _scrub(err).items() if k != "input"}
                for err in errors
            ]
        return JSONResponse(
            status_code=422,
            content={"detail": safe_errors},
        )

    # ── System Routes ───────────────────────────────────────────────────
    from app.core.i18n_router import router as i18n_router

    app.include_router(i18n_router, prefix="/api/v1")

    # Module management API (list / enable / disable)
    from app.core.module_router import router as module_mgmt_router

    app.include_router(module_mgmt_router)

    # Audit log API (admin-only)
    from app.core.audit_router import router as audit_router

    app.include_router(audit_router)

    # Global search API (cross-module)
    from app.core.global_search_router import router as search_router

    app.include_router(search_router)

    # Activity feed API (cross-module)
    from app.core.activity_feed_router import router as activity_router

    app.include_router(activity_router)

    # Sidebar badge counts (single endpoint for Tasks + RFI + Safety counts)
    from app.core.sidebar_badges_router import router as sidebar_badges_router

    app.include_router(sidebar_badges_router)

    # Translation service (element → catalog cross-lingual normalisation)
    from app.core.translation.router import router as translation_router

    app.include_router(translation_router, prefix="/api/v1")

    # Store startup time for uptime calculation
    _startup_time: float = time.time()

    @app.get("/api/health", tags=["System"])
    async def health_check() -> dict[str, Any]:
        import os as _os

        result: dict[str, Any] = {
            "status": "healthy",
            "version": settings.app_version,
            "env": settings.app_env,
            "instance_id": _INSTANCE_ID,
            "build": f"DDC-{_BUILD_HASH}",
            "modules_loaded": len(module_loader.list_modules()),
            "uptime_seconds": int(time.time() - _startup_time),
        }

        # Database connectivity (fast ping)
        try:
            from sqlalchemy import text

            from app.database import engine

            async with engine.connect() as conn:
                await conn.execute(text("SELECT 1"))
            result["database"] = "ok"
        except Exception:
            result["database"] = "error"
            result["status"] = "degraded"

        # Process memory (RSS) in MB — available on all platforms
        try:
            import resource

            rss_bytes = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            # macOS returns bytes, Linux returns KB
            if _os.uname().sysname == "Darwin":
                result["memory_mb"] = round(rss_bytes / (1024 * 1024), 1)
            else:
                result["memory_mb"] = round(rss_bytes / 1024, 1)
        except Exception:
            try:
                # Windows / fallback via psutil if available
                import psutil

                proc = psutil.Process(_os.getpid())
                result["memory_mb"] = round(proc.memory_info().rss / (1024 * 1024), 1)
            except Exception:
                pass  # Memory reporting is best-effort

        # Active thread count — best-effort
        try:
            import threading as _threading

            result["threads"] = _threading.active_count()
        except Exception:
            pass

        return result

    @app.get("/api/source", tags=["System"])
    async def source_code() -> dict:
        """AGPL-3.0 Source Code Disclosure.

        As required by AGPL-3.0, this endpoint provides access to the
        complete corresponding source code of this application.
        DataDrivenConstruction · OpenConstructionERP · DDC-CWICR-OE-2026
        """
        return {
            "license": "AGPL-3.0",
            "source_code": "https://github.com/datadrivenconstruction/OpenConstructionERP",
            "copyright": "Copyright (c) 2026 Artem Boiko / DataDrivenConstruction",
            "notice": (
                "This software is licensed under AGPL-3.0. "
                "If you modify and deploy this software, you MUST make your "
                "complete source code available to all users under the same license. "
                "For commercial licensing without AGPL obligations, contact: "
                "datadrivenconstruction.io/contact-support/"
            ),
            "projects": {
                "CWICR": "https://github.com/datadrivenconstruction/OpenConstructionEstimate-DDC-CWICR",
                "cad2data": "https://github.com/datadrivenconstruction/cad2data-Revit-IFC-DWG-DGN-pipeline-with-conversion-validation-qto",
            },
        }

    @app.get("/api/system/status", tags=["System"])
    async def system_status() -> dict[str, Any]:
        """Full system status: database, vector DB, AI providers."""
        # Public hosted demo flag — set OE_DEMO_MODE=true on the VPS
        # systemd unit so the frontend can show the "demo only" warning
        # banner and the /users page can strip personal data from the
        # demo registration list. Defaults to false on every fresh
        # local install.
        demo_mode = os.environ.get("OE_DEMO_MODE", "").lower() in ("1", "true", "yes")
        result: dict[str, Any] = {
            "api": {"status": "healthy", "version": settings.app_version},
            "database": {"status": "unknown"},
            "vector_db": {"status": "offline", "engine": "qdrant"},
            "ai": {"providers": []},
            "cache": {"status": "unknown"},
            "demo_mode": demo_mode,
        }

        # Cache check
        try:
            from app.core.cache import cache as app_cache

            result["cache"] = app_cache.stats()
        except Exception:
            result["cache"] = {"status": "unavailable"}

        # Database check
        try:
            from sqlalchemy import text

            from app.database import engine

            async with engine.connect() as conn:
                await conn.execute(text("SELECT 1"))
            result["database"] = {
                "status": "connected",
                "engine": "sqlite" if "sqlite" in settings.database_url else "postgresql",
            }
        except Exception as exc:
            result["database"] = {"status": "error", "error": str(exc)[:100]}

        # Vector DB check (LanceDB or Qdrant)
        try:
            from app.core.vector import vector_status as vs

            vstat = vs()
            if vstat.get("connected"):
                col = vstat.get("cost_collection") or {}
                result["vector_db"] = {
                    "status": "connected",
                    "engine": vstat.get("engine", "lancedb"),
                    "vectors": col.get("vectors_count", 0),
                }
            else:
                result["vector_db"] = {
                    "status": "offline",
                    "engine": vstat.get("engine", "lancedb"),
                }
        except Exception:
            result["vector_db"] = {"status": "offline", "engine": "lancedb"}

        # AI providers check — env vars first, then database
        providers = []
        if settings.openai_api_key:
            providers.append({"name": "OpenAI", "configured": True})
        if settings.anthropic_api_key:
            providers.append({"name": "Anthropic", "configured": True})

        # Fallback: check user-configured keys in oe_ai_settings table
        if not providers:
            try:
                from sqlalchemy import text as sa_text

                from app.database import async_session_factory

                async with async_session_factory() as ai_session:
                    row = (
                        await ai_session.execute(
                            sa_text(
                                "SELECT openai_api_key, anthropic_api_key, gemini_api_key FROM oe_ai_settings LIMIT 1"
                            )
                        )
                    ).first()
                    if row:
                        if row[0]:
                            providers.append({"name": "OpenAI", "configured": True})
                        if row[1]:
                            providers.append({"name": "Anthropic", "configured": True})
                        if row[2]:
                            providers.append({"name": "Gemini", "configured": True})
            except Exception:
                pass  # Table may not exist yet

        result["ai"] = {
            "providers": providers,
            "configured": len(providers) > 0,
        }

        return result

    @app.get("/api/system/version-check", tags=["System"])
    async def check_version() -> dict:
        """Check if a newer version is available on GitHub."""
        import httpx

        current = settings.app_version
        repo = "datadrivenconstruction/OpenConstructionEstimate-DDC-CWICR"
        cache_key = "_version_check_cache"

        # Simple in-memory cache (4 hours)
        cached = getattr(app.state, cache_key, None)
        if cached and (time.time() - cached["checked_at"]) < 14400:
            return cached["data"]

        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(
                    f"https://api.github.com/repos/{repo}/releases/latest",
                    headers={"Accept": "application/vnd.github.v3+json"},
                )
                if resp.status_code == 200:
                    release = resp.json()
                    latest = release.get("tag_name", "").lstrip("v")
                    result = {
                        "current_version": current,
                        "latest_version": latest,
                        "update_available": latest > current and latest != current,
                        "release_url": release.get("html_url", ""),
                        "release_notes": release.get("body", "")[:500],
                        "published_at": release.get("published_at", ""),
                        "download_url": next(
                            (
                                a["browser_download_url"]
                                for a in release.get("assets", [])
                                if a["name"].endswith(".zip")
                            ),
                            release.get("html_url", ""),
                        ),
                    }
                else:
                    result = {
                        "current_version": current,
                        "latest_version": current,
                        "update_available": False,
                    }
        except Exception:
            result = {
                "current_version": current,
                "latest_version": current,
                "update_available": False,
            }

        # Cache result
        setattr(app.state, cache_key, {"data": result, "checked_at": time.time()})
        return result

    @app.get("/api/system/converters/version-check", tags=["System"])
    async def check_converter_versions() -> dict[str, Any]:
        """Compare each installed DDC converter against the latest on GitHub.

        Computes the git-blob SHA-1 of every locally-installed converter and
        compares it to the SHA returned by GitHub's Contents API for the
        same file in `cad2data-Revit-IFC-DWG-DGN`. A mismatch means the
        user has an older build and a newer one is available.

        Cached on `app.state` for 6 h so the dashboard banner can poll
        cheaply without burning the unauthenticated GitHub rate limit
        (60 req/h). Network failures degrade gracefully — `network_ok=false`
        and `any_outdated=false` so the UI suppresses the banner.
        """
        import asyncio
        import hashlib

        import httpx

        from app.modules.boq.cad_import import find_converter

        # Per-format directory inside the repo. Mirrors `_WINDOWS_CONVERTER_DIRS`
        # in takeoff/router.py — duplicated here so the system endpoint
        # works even when the takeoff module is not loaded (it ships
        # disabled by default in some configurations).
        DDC_REPO = "datadrivenconstruction/cad2data-Revit-IFC-DWG-DGN"
        DDC_BRANCH = "main"
        WIN_DIRS: dict[str, tuple[str, str, str]] = {
            # ext: (github_dir, exe_name, display_name)
            "rvt": ("DDC_WINDOWS_Converters/DDC_CONVERTER_REVIT", "RvtExporter.exe", "Revit (RVT) Parser"),
            "ifc": ("DDC_WINDOWS_Converters/DDC_CONVERTER_IFC", "IfcExporter.exe", "IFC Import"),
            "dwg": ("DDC_WINDOWS_Converters/DDC_CONVERTER_DWG", "DwgExporter.exe", "DWG/DXF Converter"),
            "dgn": ("DDC_WINDOWS_Converters/DDC_CONVERTER_DGN", "DgnExporter.exe", "DGN Converter"),
        }
        TTL = 6 * 3600

        cached = getattr(app.state, "_converter_version_cache", None)
        if cached and (time.time() - cached.get("checked_at_ts", 0)) < TTL:
            return cached["data"]

        def git_blob_sha1(content: bytes) -> str:
            header = f"blob {len(content)}\0".encode()
            return hashlib.sha1(header + content).hexdigest()  # noqa: S324  # git uses SHA-1

        async def fetch_remote(ext: str, gh_dir: str, exe: str) -> dict[str, Any] | None:
            url = f"https://api.github.com/repos/{DDC_REPO}/contents/{gh_dir}/{exe}?ref={DDC_BRANCH}"
            try:
                async with httpx.AsyncClient(timeout=10.0) as client:
                    r = await client.get(url, headers={"Accept": "application/vnd.github+json"})
                    if r.status_code != 200:
                        return None
                    p = r.json()
                    return {
                        "sha": p.get("sha"),
                        "size": p.get("size"),
                        "download_url": p.get("download_url"),
                        "html_url": p.get("html_url"),
                    }
            except Exception:  # noqa: BLE001 — degrade gracefully
                return None

        remote_calls = [fetch_remote(ext, gh_dir, exe) for ext, (gh_dir, exe, _) in WIN_DIRS.items()]
        remote_results = await asyncio.gather(*remote_calls)

        results: list[dict[str, Any]] = []
        any_outdated = False
        network_ok = False
        for (ext, (gh_dir, exe, display)), remote in zip(WIN_DIRS.items(), remote_results, strict=True):
            path = find_converter(ext)
            installed = path is not None
            local_sha: str | None = None
            local_size: int | None = None
            if installed:
                try:
                    content = path.read_bytes()
                    local_sha = git_blob_sha1(content)
                    local_size = len(content)
                except OSError:
                    pass

            if remote is not None:
                network_ok = True

            is_outdated = bool(
                installed and remote and local_sha and remote.get("sha") and local_sha != remote["sha"]
            )
            if is_outdated:
                any_outdated = True

            results.append({
                "id": ext,
                "name": display,
                "exe": exe,
                "installed": installed,
                "installed_path": str(path) if path else None,
                "installed_size": local_size,
                "installed_sha": local_sha,
                "latest_size": remote["size"] if remote else None,
                "latest_sha": remote["sha"] if remote else None,
                "is_outdated": is_outdated,
                "download_url": remote["download_url"] if remote else None,
                "html_url": remote["html_url"] if remote else None,
            })

        from datetime import datetime as _dt
        response = {
            "converters": results,
            "any_outdated": any_outdated,
            "network_ok": network_ok,
            "checked_at": _dt.now(UTC).isoformat(),
            "ttl_seconds": TTL,
        }
        if network_ok:
            app.state._converter_version_cache = {"data": response, "checked_at_ts": time.time()}
        return response

    @app.get("/api/system/modules", tags=["System"])
    async def list_modules(
        _user_id: str = Depends(get_current_user_id),
    ) -> dict[str, Any]:
        return {"modules": module_loader.list_modules()}

    @app.get("/api/marketplace", tags=["System"])
    async def get_marketplace() -> list[dict[str, Any]]:
        """Return all marketplace modules with runtime installed status."""
        from app.core.marketplace import get_marketplace_catalog
        from app.database import async_session_factory

        # Query loaded catalog regions so resource_catalog entries show as installed
        loaded_catalog_regions: set[str] = set()
        try:
            async with async_session_factory() as session:
                from app.modules.catalog.repository import CatalogResourceRepository

                repo = CatalogResourceRepository(session)
                region_stats = await repo.stats_by_region()
                loaded_catalog_regions = {r["region"] for r in region_stats if r.get("region")}
        except Exception:
            pass  # Graceful degradation: show all as uninstalled

        return get_marketplace_catalog(loaded_catalog_regions=loaded_catalog_regions)

    @app.get("/api/demo/catalog", tags=["System"])
    async def demo_catalog() -> list[dict[str, Any]]:
        """Return the list of available demo project templates."""
        from app.core.demo_projects import DEMO_CATALOG

        return DEMO_CATALOG

    @app.post("/api/demo/install/{demo_id}", tags=["System"])
    async def install_demo(
        demo_id: str,
        force: bool = False,
        _user_id: str = Depends(get_current_user_id),
    ) -> dict[str, Any]:
        """Install a demo project with full BOQ, Schedule, Budget, and Tendering data.

        When the demo is already installed, returns the existing project info
        with ``already_installed=True`` unless ``force=True`` query param is set,
        in which case the old demo is deleted and recreated.
        """
        from app.core.demo_projects import DEMO_TEMPLATES, install_demo_project
        from app.database import async_session_factory

        if demo_id not in DEMO_TEMPLATES:
            from fastapi import HTTPException

            valid = ", ".join(sorted(DEMO_TEMPLATES.keys()))
            raise HTTPException(
                status_code=404,
                detail=f"Unknown demo_id '{demo_id}'. Valid options: {valid}",
            )

        async with async_session_factory() as session:
            result = await install_demo_project(session, demo_id, force_reinstall=force)
            await session.commit()

        return result

    @app.get("/api/demo/status", tags=["System"])
    async def demo_status(
        _user_id: str = Depends(get_current_user_id),
    ) -> dict[str, bool]:
        """Check which demo projects are currently installed."""
        from sqlalchemy import select

        from app.database import async_session_factory
        from app.modules.projects.models import Project

        async with async_session_factory() as session:
            rows = (await session.execute(select(Project.metadata_))).scalars().all()

        installed: dict[str, bool] = {}
        for meta in rows:
            if isinstance(meta, dict) and meta.get("is_demo") and meta.get("demo_id"):
                installed[meta["demo_id"]] = True
        return installed

    @app.delete(
        "/api/demo/uninstall/{demo_id}",
        tags=["System"],
        dependencies=[Depends(RequireRole("admin"))],
    )
    async def uninstall_demo(
        demo_id: str,
        _user_id: str = Depends(get_current_user_id),
    ) -> dict[str, Any]:
        """Remove a demo project and all its data."""
        from sqlalchemy import select

        from app.database import async_session_factory
        from app.modules.projects.models import Project

        async with async_session_factory() as session:
            all_projects = (await session.execute(select(Project))).scalars().all()
            targets = [
                p for p in all_projects if isinstance(p.metadata_, dict) and p.metadata_.get("demo_id") == demo_id
            ]

            if not targets:
                from fastapi import HTTPException

                raise HTTPException(status_code=404, detail=f"Demo '{demo_id}' not installed")

            for proj in targets:
                await session.delete(proj)
            await session.commit()

        return {"deleted_projects": len(targets), "demo_id": demo_id}

    @app.delete(
        "/api/demo/clear-all",
        tags=["System"],
        dependencies=[Depends(RequireRole("admin"))],
    )
    async def clear_all_demos(
        _user_id: str = Depends(get_current_user_id),
    ) -> dict[str, Any]:
        """Remove ALL demo projects and their data."""
        from sqlalchemy import select

        from app.database import async_session_factory
        from app.modules.projects.models import Project

        async with async_session_factory() as session:
            all_projects = (await session.execute(select(Project))).scalars().all()
            targets = [p for p in all_projects if isinstance(p.metadata_, dict) and p.metadata_.get("is_demo")]

            for proj in targets:
                await session.delete(proj)
            await session.commit()

        return {"deleted_projects": len(targets)}

    @app.get("/api/system/validation-rules", tags=["System"])
    async def list_validation_rules(
        _user_id: str = Depends(get_current_user_id),
    ) -> dict[str, Any]:
        from app.core.validation.engine import rule_registry

        return {
            "rule_sets": rule_registry.list_rule_sets(),
            "rules": rule_registry.list_rules(),
        }

    @app.get("/api/system/hooks", tags=["System"])
    async def list_hooks(
        _user_id: str = Depends(get_current_user_id),
    ) -> dict[str, Any]:
        from app.core.hooks import hooks

        return {
            "filters": hooks.list_filters(),
            "actions": hooks.list_actions(),
        }

    @app.post("/api/v1/feedback", tags=["System"])
    async def submit_feedback(payload: dict[str, Any], request: Request) -> dict[str, Any]:
        """Store user feedback (bug reports, ideas, general comments).

        Public endpoint (no auth) with per-IP rate limit and body-size cap —
        same posture as ``POST /api/v1/users/register`` so the shared SQLite
        ``oe_feedback`` table cannot be flooded by anonymous clients.
        """
        from datetime import datetime

        from sqlalchemy import text

        from app.core.rate_limiter import client_identifier, login_limiter
        from app.database import engine

        client_ip = client_identifier(request)
        allowed, _remaining = login_limiter.is_allowed(f"fb_{client_ip}")
        if not allowed:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Too many feedback submissions. Please wait a minute and try again.",
                headers={"Retry-After": "60"},
            )

        # Sanitise first — anonymous endpoint, must strip XSS payloads
        # before they reach the DB (BUG-330/389). Keep plain angle brackets
        # ("beam <200mm") by using the targeted sanitizer, not blanket
        # HTML-escape.
        from app.core.sanitize import strip_dangerous_html as _strip_xss

        category = _strip_xss(str(payload.get("category", "general")))[:20]
        subject = _strip_xss(str(payload.get("subject", ""))).strip()[:200]
        description = _strip_xss(str(payload.get("description", ""))).strip()[:2000]
        email = str(payload.get("email") or "")[:100] or None
        page_path = _strip_xss(str(payload.get("page_path", "")))[:200]

        # Reject empty submissions — prior behaviour wrote blank rows to the
        # feedback table, which made it useful for nothing except spamming.
        # Rate-limit (above) gates volume; this gates content (BUG-159).
        if not subject or not description:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="Both 'subject' and 'description' are required.",
            )
        if len(subject) < 3 or len(description) < 10:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="'subject' must be ≥3 chars and 'description' ≥10 chars.",
            )

        # Auto-create table if needed (SQLite dev mode)
        async with engine.begin() as conn:
            await conn.execute(
                text("""
                CREATE TABLE IF NOT EXISTS oe_feedback (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    category TEXT NOT NULL DEFAULT 'general',
                    subject TEXT NOT NULL,
                    description TEXT NOT NULL,
                    email TEXT,
                    page_path TEXT,
                    created_at TEXT NOT NULL
                )
            """)
            )
            await conn.execute(
                text("""
                    INSERT INTO oe_feedback (category, subject, description, email, page_path, created_at)
                    VALUES (:category, :subject, :description, :email, :page_path, :created_at)
                """),
                {
                    "category": category,
                    "subject": subject,
                    "description": description,
                    "email": email,
                    "page_path": page_path,
                    "created_at": datetime.now(UTC).isoformat(),
                },
            )

        return {"status": "received"}

    # ── Lifecycle ───────────────────────────────────────────────────────
    def _section(title: str) -> None:
        """Log a visual section header during startup.

        Makes it possible to scan a 60-line startup log and see at a glance
        where the server got stuck. Keeps output machine-readable because
        logger.info is still used.
        """
        logger.info("=== %s ===", title)

    @app.on_event("startup")
    async def startup() -> None:
        _section("OpenConstructionERP")
        logger.info(
            "Starting %s v%s (env=%s)",
            settings.app_name,
            settings.app_version,
            settings.app_env,
        )

        # Validate secrets and configuration outside local development.
        # HS256 requires at least 32 bytes of entropy (RFC 7518 §3.2).
        _insecure_secrets = {"change-me-in-production", "openestimate-local-dev-key", ""}
        _jwt_too_short = len(settings.jwt_secret.encode("utf-8")) < 32
        _jwt_is_default = settings.jwt_secret in _insecure_secrets
        # Any non-development environment must have a real secret. We treat
        # ``staging`` exactly like ``production`` here — not blocking it
        # would defeat the point of staging being a real deployment.
        if settings.app_env != "development":
            if _jwt_is_default:
                raise RuntimeError(
                    "FATAL: JWT_SECRET is set to an insecure default value outside development! "
                    "Set JWT_SECRET to a secure random string (min 32 chars). "
                    'Example: python -c "import secrets; print(secrets.token_urlsafe(48))"'
                )
            if _jwt_too_short:
                raise RuntimeError(
                    "FATAL: JWT_SECRET is shorter than 32 bytes (HS256 minimum). "
                    'Example: python -c "import secrets; print(secrets.token_urlsafe(48))"'
                )
        elif _jwt_is_default or _jwt_too_short:
            # BUG-320: even in development, the hardcoded default secret is
            # published in the AGPL repo — any attacker with network access
            # to a dev box could forge tokens. Rotate to an ephemeral random
            # secret for this process so forged "open-source-secret" tokens
            # stop working. Persisted tokens from the old secret get
            # invalidated, which is exactly what we want.
            import secrets as _secrets

            ephemeral = _secrets.token_urlsafe(48)
            try:
                # pydantic-settings blocks direct assignment when frozen,
                # but the default Settings class is mutable. If the field
                # is frozen in a future refactor, falling back to
                # ``object.__setattr__`` keeps us safe.
                settings.jwt_secret = ephemeral
            except Exception:
                object.__setattr__(settings, "jwt_secret", ephemeral)
            logger.warning(
                "JWT_SECRET was default/short — rotated to a random per-process "
                "secret for this dev session. Existing tokens from prior runs "
                "are now invalid. Set JWT_SECRET env var (>=32 bytes) to keep "
                "sessions alive across restarts."
            )

        if settings.is_production:
            if "minioadmin" in (settings.s3_access_key + settings.s3_secret_key):
                logger.warning("S3 credentials are using development defaults")
            if "localhost" in settings.database_url:
                logger.warning("DATABASE_URL points to localhost in production")

        # Load translations (20 languages)
        _section("i18n")
        from app.core.i18n import load_translations

        load_translations()

        # Register core permissions
        from app.core.permissions import register_core_permissions

        register_core_permissions()

        # Auto-create tables for SQLite AND PostgreSQL on first start.
        # Why for both: the v0.9.0 baseline Alembic migration is a no-op
        # (it documents that tables are created via SQLAlchemy create_all),
        # and the docker-compose.quickstart.yml entrypoint does not run
        # `alembic upgrade head` before uvicorn. Result on a fresh PG
        # volume: schema never created, login fails with
        # `relation "oe_users_user" does not exist` (issue #42).
        # SQLAlchemy create_all is idempotent on PG and harmless on existing
        # databases — it only creates tables that do not yet exist.
        _section("Database")
        if "sqlite" in settings.database_url or "postgresql" in settings.database_url:
            # SQLite auto-migration: add missing columns before create_all
            from app.core import audit as _audit_core  # noqa: F401
            from app.core.sqlite_migrator import sqlite_auto_migrate
            from app.database import Base, engine
            from app.modules.ai import models as _ai_models  # noqa: F401
            from app.modules.architecture_map import models as _architecture_map_models  # noqa: F401
            from app.modules.assemblies import models as _asm_models  # noqa: F401
            from app.modules.bim_hub import models as _bim_hub_models  # noqa: F401
            from app.modules.bim_requirements import models as _bim_requirements_models  # noqa: F401
            from app.modules.boq import models as _boq_models  # noqa: F401
            from app.modules.catalog import models as _catalog_models  # noqa: F401
            from app.modules.cde import models as _cde_models  # noqa: F401
            from app.modules.changeorders import models as _changeorders_models  # noqa: F401
            from app.modules.collaboration import models as _collaboration_models  # noqa: F401
            from app.modules.collaboration_locks import models as _collaboration_locks_models  # noqa: F401
            from app.modules.compliance import models as _compliance_models  # noqa: F401
            from app.modules.contacts import models as _contacts_models  # noqa: F401
            from app.modules.correspondence import models as _correspondence_models  # noqa: F401
            from app.modules.costmodel import models as _cm_models  # noqa: F401
            from app.modules.costs import models as _costs_models  # noqa: F401
            from app.modules.dashboards import models as _dashboards_models  # noqa: F401
            from app.modules.documents import models as _documents_models  # noqa: F401
            from app.modules.dwg_takeoff import models as _dwg_takeoff_models  # noqa: F401
            from app.modules.eac import models as _eac_models  # noqa: F401

            # Enterprise / feature-pack modules
            from app.modules.enterprise_workflows import models as _enterprise_workflows_models  # noqa: F401
            from app.modules.erp_chat import models as _erp_chat_models  # noqa: F401
            from app.modules.fieldreports import models as _fieldreports_models  # noqa: F401
            from app.modules.finance import models as _finance_models  # noqa: F401
            from app.modules.full_evm import models as _full_evm_models  # noqa: F401
            from app.modules.i18n_foundation import models as _i18n_models  # noqa: F401
            from app.modules.inspections import models as _inspections_models  # noqa: F401
            from app.modules.integrations import models as _integrations_models  # noqa: F401
            from app.modules.jobs import models as _jobs_models  # noqa: F401
            from app.modules.markups import models as _markups_models  # noqa: F401
            from app.modules.meetings import models as _meetings_models  # noqa: F401
            from app.modules.ncr import models as _ncr_models  # noqa: F401
            from app.modules.notifications import models as _notifications_models  # noqa: F401
            from app.modules.procurement import models as _procurement_models  # noqa: F401
            from app.modules.projects import models as _projects_models  # noqa: F401
            from app.modules.punchlist import models as _punchlist_models  # noqa: F401
            from app.modules.reporting import models as _reporting_models  # noqa: F401
            from app.modules.requirements import models as _requirements_models  # noqa: F401
            from app.modules.rfi import models as _rfi_models  # noqa: F401
            from app.modules.rfq_bidding import models as _rfq_bidding_models  # noqa: F401
            from app.modules.risk import models as _risk_models  # noqa: F401
            from app.modules.safety import models as _safety_models  # noqa: F401
            from app.modules.schedule import models as _sched_models  # noqa: F401
            from app.modules.submittals import models as _submittals_models  # noqa: F401
            from app.modules.takeoff import models as _takeoff_models  # noqa: F401
            from app.modules.tasks import models as _tasks_models  # noqa: F401
            from app.modules.teams import models as _teams_models  # noqa: F401
            from app.modules.tendering import models as _tendering_models  # noqa: F401
            from app.modules.transmittals import models as _transmittals_models  # noqa: F401
            from app.modules.users import models as _users_models  # noqa: F401
            from app.modules.validation import models as _validation_models  # noqa: F401

            # SQLite-only: add missing columns to existing tables before
            # create_all runs. PostgreSQL deployments must use Alembic for
            # column-level migrations — sqlite_auto_migrate uses SQLite-
            # specific PRAGMA / ALTER syntax.
            if "sqlite" in settings.database_url:
                migrated = await sqlite_auto_migrate(engine, Base)
                if migrated:
                    logger.info("SQLite auto-migration: %d columns added", migrated)

            async with engine.begin() as conn:
                await conn.run_sync(Base.metadata.create_all)
            db_kind = "SQLite" if "sqlite" in settings.database_url else "PostgreSQL"
            logger.info("%s tables created/verified", db_kind)
        else:
            logger.info("Using external database (Alembic manages schema)")

        # Load all modules (triggers module on_startup hooks)
        _section("Modules")
        await module_loader.load_all(app)

        # Mount OpenCDE API at the spec-compliant prefix /api/v1/opencde
        # (module loader auto-mounts at /api/v1/opencde_api)
        try:
            from app.modules.opencde_api.router import router as opencde_router

            app.include_router(opencde_router, prefix="/api/v1/opencde", tags=["OpenCDE API"])
        except Exception:
            logger.debug("OpenCDE API router not available (non-fatal)")

        # Variations alias (plan §3.3) — mount changeorders also at /api/v1/variations
        try:
            from app.modules.changeorders.router import router as co_router

            app.include_router(co_router, prefix="/api/v1/variations", tags=["Variations"])
        except Exception:
            logger.debug("Variations alias not available (non-fatal)")

        # costmodel → finance/evm alias (plan §3.3)
        try:
            from app.modules.costmodel.router import router as cm_router

            app.include_router(cm_router, prefix="/api/v1/finance/evm", tags=["Finance EVM (alias)"])
        except Exception:
            logger.debug("Finance EVM alias not available (non-fatal)")

        # tendering → procurement/tenders alias (plan §3.3)
        try:
            from app.modules.tendering.router import router as tend_router

            app.include_router(
                tend_router,
                prefix="/api/v1/procurement/tenders",
                tags=["Procurement Tenders (alias)"],
            )
        except Exception:
            logger.debug("Procurement Tenders alias not available (non-fatal)")

        # 4D module (Section 6) — mount schedules + EAC schedule links at /api/v2
        try:
            from app.modules.schedule.router_4d import (
                eac_schedule_links_router,
                schedules_v2_router,
            )

            app.include_router(schedules_v2_router, prefix="/api/v2")
            app.include_router(eac_schedule_links_router, prefix="/api/v2")
        except Exception:
            logger.debug("4D /api/v2 routers not available (non-fatal)")

        # Register cross-module event handlers (dataflow wiring)
        from app.core.event_handlers import register_event_handlers

        register_event_handlers()

        # Register built-in validation rules
        _section("Validation")
        from app.core.validation.rules import register_builtin_rules

        register_builtin_rules()

        # Seed demo account + 3 demo projects (idempotent)
        _section("Demo data")
        await _seed_demo_account()

        # Seed ISO 3166-1 countries + tax configs + work calendars if empty.
        # Required for the region-picker, tax-config lookups and work-calendar
        # endpoints to return data on a fresh install.
        try:
            from app.database import async_session_factory as _i18n_session_factory
            from app.modules.i18n_foundation.seed import seed_i18n_data

            async with _i18n_session_factory() as _seed_session:
                await seed_i18n_data(_seed_session)
                await _seed_session.commit()
        except Exception:
            logger.exception("i18n seed failed — countries/taxes/calendars may be empty")

        # Starter seed: small baseline of cost items + assemblies so a fresh
        # install never shows an empty /costs or /catalog before the user
        # imports a regional CWICR catalogue. Idempotent — only runs when
        # the tables are empty. Disable via OE_SKIP_STARTER_SEED=1.
        try:
            from app.database import async_session_factory as _starter_session_factory
            from app.scripts.seed_starter import seed_starter_data

            async with _starter_session_factory() as _starter_session:
                counts = await seed_starter_data(_starter_session)
                await _starter_session.commit()
                if counts["cost_items"] or counts["assemblies"]:
                    logger.info(
                        "Starter seed: %d cost items, %d assemblies inserted",
                        counts["cost_items"],
                        counts["assemblies"],
                    )
        except Exception:
            logger.exception("Starter seed failed — /costs and /catalog may be empty")

        # Initialize vector database (LanceDB embedded, no Docker)
        _section("Vector DB")
        _init_vector_db()

        # Pre-warm the embedder + boot the inference process pool. Both
        # are env-var-gated so dev startup stays fast unless the
        # operator opted in. See ``app.core.embedding_pool`` for the
        # full rationale and trade-offs.
        #
        # We unconditionally call get_embedder() here as well: the
        # auto-backfill task (scheduled below) and /match-elements
        # vector matcher both call ``encode_texts_async`` from worker
        # threads. On Windows + Anaconda the first SentenceTransformer
        # load from a worker thread can race with concurrent torch
        # imports and silently leave the singleton at None — every
        # subsequent encode then raises "No embedding model available".
        # Loading on the main thread once primes the singleton so
        # later calls just hit the cache.
        try:
            from app.core.vector import get_embedder as _ge

            _ge()
        except Exception as exc:  # noqa: BLE001 — never fatal for startup
            logger.info("Embedder main-thread prime skipped: %s", exc)

        try:
            from app.core.embedding_pool import init_pool, maybe_preload_in_process

            preloaded = maybe_preload_in_process()
            workers = init_pool()
            if preloaded or workers:
                logger.info(
                    "Embedding warm-up: preload=%s pool_workers=%d",
                    preloaded,
                    workers,
                )
        except Exception as exc:  # noqa: BLE001 — never fatal for startup
            logger.warning("Embedding pool init skipped: %s", exc)

        # Auto-backfill the multi-collection vector store from existing
        # rows.  Detached as a background task so a slow embedding model
        # download or a large dataset doesn't delay startup — semantic
        # search remains available the moment the model finishes loading.
        try:
            import asyncio as _asyncio_bf

            _asyncio_bf.create_task(_auto_backfill_vector_collections())
        except Exception:
            logger.debug("Could not schedule vector backfill", exc_info=True)

        # ── KPI auto-recalculation scheduler (24-hour interval) ──────────
        import asyncio

        async def _kpi_scheduler() -> None:
            """Run KPI recalculation for all active projects every 24 hours."""
            while True:
                await asyncio.sleep(86400)  # 24 hours
                try:
                    from app.database import async_session_factory as _kpi_sf
                    from app.modules.reporting.service import ReportingService

                    async with _kpi_sf() as kpi_session:
                        svc = ReportingService(kpi_session)
                        result = await svc.auto_recalculate_kpis()
                        await kpi_session.commit()
                        logger.info(
                            "KPI scheduler: %d projects processed, %d failed",
                            result["processed"],
                            result["failed"],
                        )
                except Exception:
                    logger.exception("KPI recalculation scheduler failed")

        asyncio.create_task(_kpi_scheduler())

        # ── Cost-DB cache pre-warm (runs once, in background) ──────────
        # The "Add from Database" modal in the BOQ editor calls three
        # endpoints on open: /costs/regions/, /costs/category-tree/, and
        # /costs/search/. The first two issue full-table aggregations
        # (SELECT DISTINCT region, GROUP BY 4 json_extract paths) that
        # can take 18 s and 86 s respectively on cold SQLite when the
        # active catalog holds 100 k+ rows. The user reported the modal
        # "loading forever" — this prewarm pays the aggregation cost
        # once at boot so every subsequent click is a cache hit.
        async def _prewarm_cost_caches() -> None:
            await asyncio.sleep(2)  # let other startup tasks settle
            try:
                import time as _ptime

                from sqlalchemy import distinct, select
                from sqlalchemy import func as _func

                from app.database import async_session_factory as _cost_sf
                from app.modules.costs.models import CostItem
                from app.modules.costs.router import (
                    _category_tree_cache,
                    _region_cache,
                )
                from app.modules.costs.schemas import CategoryTreeNode
                from app.modules.costs.service import CostItemService

                async with _cost_sf() as cost_session:
                    # 1) Distinct region list — drives the tab bar on /costs
                    #    and the modal's region picker.
                    r = await cost_session.execute(
                        select(distinct(CostItem.region))
                        .where(CostItem.is_active.is_(True))
                        .where(CostItem.region.isnot(None))
                        .where(CostItem.region != "")
                    )
                    regions = sorted(row[0] for row in r.all())
                    _region_cache["regions"] = regions

                    # 2) Per-region item-count stats — drives the count badge
                    #    on each region tab.
                    s = await cost_session.execute(
                        select(
                            CostItem.region,
                            _func.count(CostItem.id).label("cnt"),
                        )
                        .where(CostItem.is_active.is_(True))
                        .where(CostItem.region.isnot(None))
                        .where(CostItem.region != "")
                        .group_by(CostItem.region)
                        .order_by(_func.count(CostItem.id).desc())
                    )
                    _region_cache["stats"] = [
                        {"region": row[0], "count": row[1]} for row in s.all()
                    ]

                    # 3) Distinct top-level categories — drives the category
                    #    filter dropdown. Warm the all-regions list (the
                    #    page's default before any region tab is clicked).
                    from sqlalchemy import func as __func

                    from app.database import engine as __engine

                    if "sqlite" in str(__engine.url):
                        coll_expr = __func.json_extract(
                            CostItem.classification, "$.collection"
                        )
                    else:
                        coll_expr = CostItem.classification["collection"].as_string()
                    c = await cost_session.execute(
                        select(distinct(coll_expr))
                        .where(CostItem.is_active.is_(True))
                        .where(coll_expr.isnot(None))
                        .where(coll_expr != "")
                        .order_by(coll_expr)
                    )
                    _region_cache["categories_all"] = [
                        row[0] for row in c.all() if row[0]
                    ]
                    _region_cache["ts"] = _ptime.monotonic()

                    svc = CostItemService(cost_session)
                    for reg in regions:
                        try:
                            raw = await svc.category_tree(region=reg, depth=4)
                            nodes = [
                                CategoryTreeNode.model_validate(n) for n in raw
                            ]
                            key = f"tree::{reg}::d=4::p="
                            _category_tree_cache[key] = {
                                "nodes": nodes,
                                "ts": _ptime.monotonic(),
                            }
                        except Exception:
                            logger.debug(
                                "Pre-warm tree failed for region=%s",
                                reg,
                                exc_info=True,
                            )
                logger.info(
                    "Cost-DB caches pre-warmed for %d regions",
                    len(regions),
                )
            except Exception:
                logger.debug("Cost-DB pre-warm failed (non-fatal)", exc_info=True)

        asyncio.create_task(_prewarm_cost_caches())

        # ── Scheduled reports worker (1-minute tick) ────────────────────
        # Polls oe_reporting_template for rows whose ``next_run_at`` is
        # due, renders each one via the existing generate_report path,
        # then advances ``next_run_at`` using the stored cron expression.
        # Deliberately uses the same asyncio-based loop as the KPI
        # scheduler (not Celery) to keep the single-process footprint —
        # CLAUDE.md "LIGHTWEIGHT & SIMPLE".
        async def _reports_scheduler() -> None:
            from datetime import UTC
            from datetime import datetime as _dt

            while True:
                await asyncio.sleep(60)
                try:
                    from uuid import uuid4 as _uuid4

                    from app.database import async_session_factory as _rep_sf
                    from app.modules.reporting.schemas import (
                        GenerateReportRequest as _GenReq,
                    )
                    from app.modules.reporting.service import (
                        ReportingService as _RepSvc,
                    )

                    async with _rep_sf() as rep_session:
                        svc = _RepSvc(rep_session)
                        due = await svc.list_due_templates(_dt.now(UTC))
                        for template in due:
                            if template.project_id_scope is None:
                                # Portfolio reports need cross-project
                                # context we don't have yet — pause so
                                # the worker doesn't busy-loop.
                                template.is_scheduled = False
                                template.next_run_at = None
                                await svc.template_repo.update(template)
                                continue
                            try:
                                gen = _GenReq(
                                    project_id=template.project_id_scope,
                                    template_id=template.id,
                                    report_type=template.report_type,
                                    title=f"{template.name} (scheduled {_dt.now(UTC):%Y-%m-%d %H:%M} UTC)",
                                    format="pdf",
                                    metadata={
                                        "triggered_by": "scheduler",
                                        "run_id": str(_uuid4()),
                                    },
                                )
                                await svc.generate_report(gen)
                                await svc.mark_template_ran(template)
                            except Exception:
                                logger.exception(
                                    "Scheduled report %s failed", template.id,
                                )
                        await rep_session.commit()
                except Exception:
                    logger.exception("Reports scheduler tick failed")

        asyncio.create_task(_reports_scheduler())

        _section("Ready")
        # Friendly multi-line ready banner. The CLI (`openestimate serve`)
        # exposes OE_CLI_HOST / OE_CLI_PORT / OE_CLI_DATA_DIR so we can show
        # an accurate URL after the socket is actually bound. If those env
        # vars are absent (e.g. `uvicorn app.main:create_app --factory`), we
        # fall back to a generic message.
        _cli_host = os.environ.get("OE_CLI_HOST")
        _cli_port = os.environ.get("OE_CLI_PORT")
        _cli_data_dir = os.environ.get("OE_CLI_DATA_DIR")
        if _cli_host and _cli_port:
            _url = f"http://{_cli_host}:{_cli_port}"
            logger.info("OpenConstructionERP is ready at %s", _url)
            # Demo passwords are now per-installation (BUG-D01 fix). The
            # actual values were either supplied via DEMO_*_PASSWORD env
            # vars or generated in ``_seed_demo_account`` and persisted to
            # ``~/.openestimator/.demo_credentials.json``. Pointing the
            # operator at that file beats baking a fixed password into
            # every running instance.
            logger.info(
                "Demo login: demo@openestimator.io "
                "(password from DEMO_USER_PASSWORD env var or "
                "~/.openestimator/.demo_credentials.json)"
            )
            if _cli_data_dir:
                logger.info("Data directory: %s", _cli_data_dir)
            logger.info("Press Ctrl+C to stop. Docs: https://openconstructionerp.com/docs")
        else:
            logger.info("Application started successfully")

        # NOTE: frontend static mounting moved to create_app() (below, before
        # the startup event runs). Registering the SPA 404 exception handler
        # here (inside the startup lifespan) is TOO LATE — Starlette has
        # already built the ExceptionMiddleware by the time lifespan.startup
        # fires, and the middleware captures a COPY of app.exception_handlers
        # at build time.  Subsequent modifications to app.exception_handlers
        # (like the one mount_frontend used to do) never reach the middleware.
        # Symptom: https://.../demo/ returned a JSON 404 instead of index.html.

    @app.on_event("shutdown")
    async def shutdown() -> None:
        logger.info("Shutting down %s", settings.app_name)
        from app.database import engine

        # Stop the collaboration-lock sweeper before closing the DB
        # engine so its last iteration cannot hit a disposed pool.
        try:
            from app.modules.collaboration_locks.sweeper import stop_sweeper

            stop_sweeper()
        except Exception:
            logger.debug("collab lock sweeper stop failed", exc_info=True)

        # Tear down the embedding inference pool so Ctrl-C doesn't
        # leave orphan Python worker processes alive.
        try:
            from app.core.embedding_pool import shutdown_pool

            shutdown_pool()
        except Exception:
            logger.debug("embedding pool shutdown failed", exc_info=True)

        await engine.dispose()

    # ── Frontend Static Files (CLI / single-image mode) ─────────────────────
    # Registered HERE, before the app is returned from create_app(), so the
    # SPA 404 exception handler is already in app.exception_handlers when
    # Starlette builds the ExceptionMiddleware on the first lifespan message.
    # (If this runs inside on_event("startup"), the handler is never wired up
    # and the SPA 404 fallback silently does nothing — see comment above.)
    #
    # Exception handlers are independent of routes, so it is safe to register
    # this before module routers are mounted: the handler only fires for
    # requests that do NOT match any route.
    if os.environ.get("SERVE_FRONTEND", "").lower() in ("1", "true", "yes"):
        try:
            from app.cli_static import mount_frontend

            mount_frontend(app)
        except Exception as exc:  # noqa: BLE001 — frontend is optional
            logger.warning("Frontend mount skipped: %s", exc)

    return app
