# OpenConstructionERP — DataDrivenConstruction (DDC)
# CAD2DATA Pipeline · CWICR Cost Database Engine
# Copyright (c) 2026 Artem Boiko / DataDrivenConstruction
# AGPL-3.0 License · DDC-CWICR-OE-2026
"""‌⁠‍CAD/BIM file import via DDC Community converters.

Workflow:
1. User uploads .rvt/.ifc/.dwg/.dgn file
2. Backend saves to temp dir
3. Runs appropriate DDC converter (.exe) -> produces Excel
4. Parses Excel -> extracts elements (type, volume, area, count)
5. AI maps elements to construction work items with pricing
6. Returns BOQ positions ready for import
"""

import asyncio
import logging
import os
import sys
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Converter mapping per platform.
#
# Windows: GitHub-bundled `*.exe` from `cad2data-Revit-IFC-DWG-DGN`.
# Linux:   apt-installed ELF binary at `/usr/bin/{Format}Exporter` (no
#          extension, CapitalCamelCase) from the signed apt repo at
#          `pkg.datadrivenconstruction.io`. The .deb packages
#          (`ddc-rvtconverter` etc.) drop exactly one file each — the
#          binary itself — and apt resolves the shared-lib runtime
#          (`ddc-deps-kernel`, `ddc-deps-revit`, `ddc-thirdparty`).
_WINDOWS_CONVERTERS: dict[str, str] = {
    "rvt": "RvtExporter.exe",
    "ifc": "IfcExporter.exe",
    "dwg": "DwgExporter.exe",
    "dgn": "DgnExporter.exe",
}
_LINUX_CONVERTERS: dict[str, str] = {
    "rvt": "RvtExporter",
    "ifc": "IfcExporter",
    "dwg": "DwgExporter",
    "dgn": "DgnExporter",
}

# Active mapping for the running platform — kept under the legacy name
# `CONVERTERS` so external callers (and the takeoff router) don't need
# to know about platform branching.
CONVERTERS: dict[str, str] = (
    _LINUX_CONVERTERS if sys.platform.startswith("linux") else _WINDOWS_CONVERTERS
)

SUPPORTED_CAD_EXTENSIONS: set[str] = set(CONVERTERS.keys())

# Look for converters in these locations (in order)
CONVERTER_SEARCH_PATHS: list[Path] = [
    Path("converters/bin"),
    Path.home() / ".openestimator" / "converters",
    Path("/opt/openestimator/converters"),
    Path("C:/ProgramData/OpenConstructionERP/converters"),
]


def _find_ddc_toolkit_bin() -> Path | None:
    """‌⁠‍Auto-detect DDC toolkit converters/bin from editable install or known paths."""
    # 1. Check env var
    env_dir = os.environ.get("DDC_TOOLKIT_DIR")
    if env_dir:
        p = Path(env_dir) / "converters" / "bin"
        if p.is_dir():
            return p

    # 2. Try importlib.metadata (editable install of ddc-toolkit)
    try:
        import importlib.metadata

        dist = importlib.metadata.distribution("ddc-toolkit")
        for f in dist.files or []:
            fpath = Path(str(f))
            if "converters" in str(fpath) or "bin" in str(fpath):
                resolved = Path(str(dist._path)).parent / fpath  # type: ignore[attr-defined]
                candidate = resolved.parent
                while candidate != candidate.parent:
                    check = candidate / "converters" / "bin"
                    if check.is_dir():
                        return check
                    candidate = candidate.parent
                break
    except Exception:
        logger.debug("DDC converter discovery via importlib failed", exc_info=True)

    # 3. Scan common sibling directories (projects next to this repo)
    this_project = Path(__file__).resolve().parents[4]  # backend/app/modules/boq -> repo root
    for sibling_name in ("ddc_toolkit", "ddc-toolkit", "DDC_Toolkit"):
        candidate = this_project.parent / sibling_name / "converters" / "bin"
        if candidate.is_dir():
            return candidate

    return None


# Auto-detect DDC toolkit at import time
_ddc_bin = _find_ddc_toolkit_bin()
if _ddc_bin:
    CONVERTER_SEARCH_PATHS.insert(0, _ddc_bin)
    logger.info("DDC toolkit converters found at %s", _ddc_bin)


def find_converter(extension: str) -> Path | None:
    """‌⁠‍Find the converter executable for a given file extension.

    Searches through ``CONVERTER_SEARCH_PATHS`` in order and returns the
    first existing executable path, or ``None`` if no converter is found.

    Args:
        extension: Lowercase file extension without dot (e.g. ``"rvt"``).

    Returns:
        Path to the converter executable, or ``None``.
    """
    exe_name = CONVERTERS.get(extension)
    if not exe_name:
        return None

    # Build dynamic search paths
    search_paths = list(CONVERTER_SEARCH_PATHS)

    # Also check OPENESTIMATOR_CONVERTERS_DIR env var
    env_dir = os.environ.get("OPENESTIMATOR_CONVERTERS_DIR")
    if env_dir:
        search_paths.insert(0, Path(env_dir))

    # Auto-detect DDC toolkit in sibling directories
    ddc_bin = _find_ddc_toolkit_bin()
    if ddc_bin and ddc_bin not in search_paths:
        search_paths.insert(0, ddc_bin)

    # Per-format Windows install dir written by the BIM converter
    # auto-installer (takeoff/router.py:install_converter). The
    # installer drops files at ~/.openestimator/converters/{ext}_windows/
    # so multiple converters can coexist without their bundled Qt6
    # DLLs colliding. Probe this location explicitly so an installed
    # converter is picked up by the next find_converter() call without
    # any service restart.
    per_format_windows = (
        Path.home() / ".openestimator" / "converters" / f"{extension}_windows"
    )
    if per_format_windows not in search_paths:
        search_paths.insert(0, per_format_windows)

    # Linux apt install puts the binaries on PATH. The .deb packages
    # at `pkg.datadrivenconstruction.io` (apt v18.0.0.0, amd64+arm64)
    # ship exactly one file each — `/usr/bin/{Format}Exporter`
    # (CapitalCamelCase, no extension). We probe these locations
    # BEFORE walking the rest of `search_paths` so a system-installed
    # converter is found instantly with no environment fiddling.
    #
    # The legacy `ddc-{ext}converter` names are kept as fallbacks for
    # users who installed from older instructions or symlinked the
    # binary manually. `linux_exe` is the *real* binary name; `exe_name`
    # at this point may still be a Windows `.exe` if the module was
    # imported on Windows but is being asked about a Linux install (the
    # cross-platform smoke-test scenario is unusual but cheap to cover).
    linux_exe = _LINUX_CONVERTERS.get(extension, exe_name.removesuffix(".exe"))
    linux_apt_candidates = [
        Path("/usr/bin") / linux_exe,
        Path("/usr/local/bin") / linux_exe,
        # Legacy probe paths from earlier instructions — kept for users
        # who hand-symlinked the binary under the apt-package name.
        Path("/usr/bin") / f"ddc-{extension}converter",
        Path("/usr/local/bin") / f"ddc-{extension}converter",
    ]
    for cand in linux_apt_candidates:
        if cand.exists() and cand.stat().st_size > 1024:
            return cand

    for search_path in search_paths:
        exe_path = search_path / exe_name
        if exe_path.exists() and exe_path.stat().st_size > 1024:
            return exe_path

    return None


def is_cad_file(filename: str) -> bool:
    """Check if a filename has a supported CAD/BIM extension.

    Args:
        filename: File name or path (e.g. ``"project.rvt"``).

    Returns:
        ``True`` if the extension is supported.
    """
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    return ext in SUPPORTED_CAD_EXTENSIONS


# ── Health check / pre-conversion smoke test ──────────────────────────────
#
# Why this exists: ``find_converter()`` only checks the binary file is
# present and bigger than 1 KB. That doesn't catch the realistic broken
# states a Windows user runs into:
#   * Required Qt6 DLL did not download with the rest of the install.
#   * Wrong-architecture binary (x86 on ARM) refuses to load.
#   * Permission denied because the install dir was extracted with the
#     wrong attributes (read-only / blocked-by-Mark-of-the-Web).
#   * Visual C++ Redistributable missing (msvcp140.dll, vcruntime140.dll).
#
# Calling ``smoke_test_converter`` before scheduling a conversion lets us
# fail FAST with a clear error + suggested fix instead of letting the
# upload run for 5 minutes and then time out with no diagnostic info.

import time
from typing import Literal, TypedDict

ConverterHealthStatus = Literal["ok", "failed", "unknown"]
SuggestedAction = Literal[
    "install_converter",
    "reinstall_converter",
    "install_vc_redist",
    "unblock_files",
    "check_permissions",
    "manual_install_from_github",
]


class ConverterHealth(TypedDict):
    """Result of a converter smoke test.

    ``status``:
        - ``"ok"`` — binary loads and exits cleanly.
        - ``"failed"`` — binary doesn't load (DLL missing, etc).
        - ``"unknown"`` — smoke test couldn't run (timeout, OS error
          unrelated to the binary itself).
    ``message``:
        Human-readable explanation. Empty string on the happy path.
    ``suggested_actions``:
        Stable string ids the frontend uses to render specific buttons
        / instructions (Reinstall / Open install dir / Run as admin /
        Install VCRedist / etc).
    ``checked_at``:
        Unix timestamp of the check — used by the cache layer.
    """

    status: ConverterHealthStatus
    message: str
    suggested_actions: list[str]
    checked_at: float


# In-process cache so we don't re-spawn the binary on every API call.
# 5 minutes is enough that page-refresh navigation reuses one result;
# manual install/uninstall paths invalidate explicitly.
_HEALTH_CACHE: dict[str, ConverterHealth] = {}
_HEALTH_TTL_SEC = 300

# Windows NTSTATUS exit codes that always mean "the loader couldn't bring
# the binary up". The values appear as both signed (Python's negative-int
# representation of an unsigned u32) and unsigned in the wild, so we
# match both.
_WINDOWS_DLL_LOAD_FAILURES: frozenset[int] = frozenset(
    {
        -1073741515,  # 0xC0000135 STATUS_DLL_NOT_FOUND
        -1073741502,  # 0xC0000142 STATUS_DLL_INIT_FAILED
        3221225781,   # 0xC0000135 unsigned
        3221225794,   # 0xC0000142 unsigned
    }
)

# Linux ld.so failure markers. When a shared dependency (`libQt6Core.so.6`
# or one of the `ddc-deps-*` packages) is missing, glibc's `ld.so` writes
# a line like `RvtExporter: error while loading shared libraries: <name>`
# to stderr and exits with status 127. We match the substring (locale-
# independent — glibc keeps the English text even on translated systems).
_LINUX_LDSO_FAILURE_MARKER = b"error while loading shared libraries"
_LINUX_LDSO_EXIT_CODE = 127


def smoke_test_converter(extension: str, force: bool = False) -> ConverterHealth:
    """Quick health check: spawn the converter binary and verify it loads.

    Sends an empty stdin and waits up to ``8`` seconds for an exit. The
    purpose is NOT to detect feature bugs — only to verify that the OS
    can launch the binary without a missing-DLL / wrong-arch / perms
    error. A binary that loads and then exits with an error code (because
    the empty input didn't parse) is fine for our purposes.

    Args:
        extension: Lowercase file extension without dot (``"rvt"`` etc.).
        force: Bypass the 5-minute cache and re-spawn the binary.

    Returns:
        ``ConverterHealth`` dict (always; never raises).
    """
    now = time.time()
    cached = _HEALTH_CACHE.get(extension)
    if cached and not force and (now - cached["checked_at"]) < _HEALTH_TTL_SEC:
        return cached

    exe_path = find_converter(extension)
    if exe_path is None:
        result: ConverterHealth = {
            "status": "failed",
            "message": (
                f"The .{extension.upper()} converter is not installed. "
                f"Use the Install button in the BIM page header to download it."
            ),
            "suggested_actions": ["install_converter"],
            "checked_at": now,
        }
        _HEALTH_CACHE[extension] = result
        return result

    try:
        import subprocess

        # ``input=`` already implies ``stdin=PIPE`` — passing both raises
        # ``ValueError: stdin and input arguments may not both be used``,
        # which used to crash the per-upload pre-flight check on every
        # native CAD format and leave the model stuck at
        # ``ddc_smoke_failed`` even when the binary was correctly
        # installed.  Drop the explicit ``stdin=PIPE``.
        proc = subprocess.run(
            [str(exe_path)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=str(exe_path.parent),
            input=b"\n",
            timeout=8,
        )
        rc = proc.returncode

        if rc in _WINDOWS_DLL_LOAD_FAILURES:
            result = {
                "status": "failed",
                "message": (
                    f"{exe_path.name} exists on disk but cannot load — a "
                    f"required Qt6 / Visual C++ DLL is missing "
                    f"(Windows error 0x{rc & 0xFFFFFFFF:08x}). The Qt6 "
                    f"plugins probably did not download cleanly during "
                    f"install."
                ),
                "suggested_actions": [
                    "reinstall_converter",
                    "install_vc_redist",
                    "manual_install_from_github",
                ],
                "checked_at": now,
            }
        elif (
            sys.platform.startswith("linux")
            and rc == _LINUX_LDSO_EXIT_CODE
            and _LINUX_LDSO_FAILURE_MARKER in (proc.stderr or b"")
        ):
            # Linux ld.so wrote "error while loading shared libraries: ..."
            # — surface the exact missing-library line so the user sees
            # which `ddc-deps-*` package is missing (or wasn't installed
            # by `apt install` because the source wasn't added).
            stderr_text = (proc.stderr or b"").decode("utf-8", errors="replace")
            missing_line = next(
                (
                    line.strip()
                    for line in stderr_text.splitlines()
                    if "error while loading shared libraries" in line
                ),
                stderr_text.strip()[:200],
            )
            result = {
                "status": "failed",
                "message": (
                    f"{exe_path.name} cannot load — a shared library "
                    f"dependency is missing. {missing_line}\n\n"
                    f"Reinstall the converter so apt resolves "
                    f"`ddc-deps-kernel`, `ddc-deps-revit`, "
                    f"`ddc-thirdparty` and the rest of the SDK runtime."
                ),
                "suggested_actions": [
                    "reinstall_converter",
                    "manual_install_from_github",
                ],
                "checked_at": now,
            }
        else:
            # Any other exit code (including non-zero from the empty input
            # not being valid CAD): the binary did load, so the install
            # is healthy from our perspective.
            result = {
                "status": "ok",
                "message": "",
                "suggested_actions": [],
                "checked_at": now,
            }
    except subprocess.TimeoutExpired:
        # Binary is alive but waiting for stdin / showing a window. That
        # means the loader succeeded — treat as healthy.
        result = {
            "status": "ok",
            "message": "",
            "suggested_actions": [],
            "checked_at": now,
        }
    except FileNotFoundError:
        result = {
            "status": "failed",
            "message": (
                f"Binary {exe_path} disappeared between detection and launch. "
                f"The install may have been partially deleted."
            ),
            "suggested_actions": ["reinstall_converter"],
            "checked_at": now,
        }
    except PermissionError as exc:
        result = {
            "status": "failed",
            "message": (
                f"Permission denied when launching {exe_path.name}: {exc}. "
                f"On Windows this is usually 'Mark of the Web' — right-click "
                f"the file → Properties → Unblock, or reinstall."
            ),
            "suggested_actions": ["unblock_files", "reinstall_converter"],
            "checked_at": now,
        }
    except OSError as exc:
        result = {
            "status": "failed",
            "message": (
                f"OS could not launch {exe_path.name}: "
                f"{exc.__class__.__name__}: {exc}. The binary may be the "
                f"wrong architecture for this machine."
            ),
            "suggested_actions": ["reinstall_converter", "check_permissions"],
            "checked_at": now,
        }
    except Exception as exc:  # noqa: BLE001 — health check must never raise
        logger.warning(
            "Smoke test for .%s converter errored: %s", extension, exc
        )
        result = {
            "status": "unknown",
            "message": (
                f"Health check could not complete: "
                f"{exc.__class__.__name__}: {exc}"
            ),
            "suggested_actions": [],
            "checked_at": now,
        }

    _HEALTH_CACHE[extension] = result
    return result


def invalidate_converter_health(extension: str | None = None) -> None:
    """Drop cached health for one or all converters.

    Call this after a successful install / uninstall so the next health
    poll re-runs the smoke test instead of reading a stale "failed" or
    "ok" entry.
    """
    if extension is None:
        _HEALTH_CACHE.clear()
    else:
        _HEALTH_CACHE.pop(extension, None)


async def convert_cad_to_excel(
    input_path: Path,
    output_dir: Path,
    extension: str,
) -> Path | None:
    """Run a DDC converter to transform a CAD file into Excel.

    The converter is executed as a subprocess with a 5-minute timeout.

    Args:
        input_path: Path to the uploaded CAD file.
        output_dir: Directory where the Excel output should be written.
        extension: Lowercase file extension without dot.

    Returns:
        Path to the generated Excel file, or ``None`` on failure.
    """
    converter = find_converter(extension)
    if not converter:
        logger.error("No converter found for .%s", extension)
        return None

    logger.info("Converting %s using %s", input_path.name, converter.name)

    # DDC converters CLI: <input> [<output.xlsx>] [<mode>] [-no-collada]
    # Use 'standard' mode by default — balanced data extraction without
    # the heavy per-view/per-schedule parameter dump of 'complete' mode.
    output_xlsx = output_dir / (input_path.stem + ".xlsx")
    args = [str(converter), str(input_path), str(output_xlsx)]
    # RVT and IFC converters support export modes; DWG/DGN do not
    if extension in ("rvt", "ifc"):
        args.append("standard")
    args.append("-no-collada")

    try:
        import subprocess
        from concurrent.futures import ThreadPoolExecutor

        # DDC converters need DLLs (Qt6Core.dll etc.) from their own directory
        converter_dir = converter.parent

        def _run_converter() -> subprocess.CompletedProcess:
            return subprocess.run(
                args,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=str(converter_dir),
                input=b"\n",  # handle "Press Enter to continue..." prompt
                timeout=300,
            )

        loop = asyncio.get_event_loop()
        with ThreadPoolExecutor(max_workers=1) as pool:
            result = await loop.run_in_executor(pool, _run_converter)

        if result.returncode != 0:
            logger.error(
                "Converter failed (exit %d): %s",
                result.returncode,
                result.stderr.decode(errors="replace")[:500],
            )
            return None

        # Find the generated Excel file in the output directory
        for f in output_dir.iterdir():
            if f.suffix in (".xlsx", ".xls"):
                return f

        # Also check if xlsx was written directly (not in output_dir)
        if output_xlsx.exists():
            return output_xlsx

        logger.error("No Excel output found in %s after conversion", output_dir)
        return None

    except subprocess.TimeoutExpired:
        logger.error("Converter timed out after 300s for %s", input_path.name)
        return None
    except Exception:
        logger.exception("Converter error for %s", input_path.name)
        return None


def parse_cad_excel(excel_path: Path) -> list[dict]:
    """Parse the Excel output produced by a DDC converter.

    DDC converters produce Excel files with columns such as:
    Category, Family, Type Name, Count, Volume, Area, Length, Material, etc.

    Args:
        excel_path: Path to the Excel file generated by the converter.

    Returns:
        List of dicts where each dict represents one element row.
    """
    import openpyxl

    wb = openpyxl.load_workbook(excel_path, read_only=True, data_only=True)
    ws = wb.active

    if ws is None:
        wb.close()
        return []

    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        wb.close()
        return []

    # First row is the header; strip DDC type suffixes like " : String", " : Double"
    raw_headers = [str(h or "").strip() for h in rows[0]]
    headers = [h.split(" : ")[0].strip().lower() if " : " in h else h.lower() for h in raw_headers]

    elements: list[dict] = []
    for row in rows[1:]:
        if not any(row):
            continue

        item: dict = {}
        for i, header in enumerate(headers):
            if i < len(row):
                val = row[i]
                if val is not None:
                    item[header] = val

        if item:
            elements.append(item)

    wb.close()
    return elements


def summarize_cad_elements(elements: list[dict]) -> str:
    """Create a text summary of CAD elements suitable for AI processing.

    The summary is a tabular representation of element categories, types,
    counts, volumes, and areas. Limited to 200 elements to stay within
    AI context window limits.

    Args:
        elements: List of element dicts from ``parse_cad_excel``.

    Returns:
        Human-readable text summary of the CAD model contents.
    """
    if not elements:
        return "No elements found in the CAD file."

    lines = [f"CAD/BIM file contains {len(elements)} elements:\n"]
    lines.append("Category | Type | Count | Volume (m3) | Area (m2)")
    lines.append("-" * 60)

    for el in elements[:200]:  # Limit to 200 elements for AI context
        category = el.get("category", el.get("element type", "unknown"))
        type_name = el.get("type name", el.get("family", el.get("type", "")))
        count = el.get("count", 1)
        volume = el.get("volume", el.get("volume (m3)", ""))
        area = el.get("area", el.get("area (m2)", ""))

        lines.append(f"{category} | {type_name} | {count} | {volume} | {area}")

    if len(elements) > 200:
        lines.append(f"\n... and {len(elements) - 200} more elements (truncated)")

    return "\n".join(lines)


def _to_float(val: object) -> float:
    """Safely convert a value to float, returning 0.0 on failure."""
    if val is None:
        return 0.0
    try:
        return float(val)
    except (ValueError, TypeError):
        return 0.0


def group_cad_elements(elements: list[dict]) -> dict:
    """Group CAD elements by category and type, summing numeric quantities.

    Produces a structured dict of quantity tables suitable for direct display
    without AI processing. Each category contains type-level rows with summed
    count, volume (m3), area (m2), and length (m).

    Handles DDC column name variations:
    - ``category`` / ``element type`` -> category
    - ``type name`` / ``family`` / ``type`` -> type
    - ``volume`` / ``volume (m3)`` -> volume
    - ``area`` / ``area (m2)`` -> area
    - ``count`` defaults to 1

    Args:
        elements: List of element dicts from ``parse_cad_excel``.

    Returns:
        Dict with ``groups`` (list), ``grand_totals``, and ``total_elements``.
    """
    from collections import OrderedDict

    # category -> type -> aggregated values
    cat_types: dict[str, dict[str, dict]] = OrderedDict()

    for el in elements:
        raw_cat = str(el.get("category", el.get("element type", "Other"))).strip()
        category = raw_cat if raw_cat and raw_cat != "None" else "Other"
        type_name = str(el.get("type name", el.get("family", el.get("type", "Unknown")))).strip() or "Unknown"
        count = _to_float(el.get("count", 1))
        volume = _to_float(el.get("volume", el.get("volume (m3)", 0)))
        area = _to_float(el.get("area", el.get("area (m2)", 0)))
        length = _to_float(el.get("length", 0))
        material = str(el.get("material", "")).strip()

        if category not in cat_types:
            cat_types[category] = OrderedDict()

        if type_name not in cat_types[category]:
            cat_types[category][type_name] = {
                "type": type_name,
                "material": "",
                "count": 0.0,
                "volume_m3": 0.0,
                "area_m2": 0.0,
                "length_m": 0.0,
            }

        entry = cat_types[category][type_name]
        entry["count"] += count
        entry["volume_m3"] += volume
        entry["area_m2"] += area
        entry["length_m"] += length
        if material and not entry["material"]:
            entry["material"] = material

    # Build structured output
    groups: list[dict] = []
    grand_count = 0.0
    grand_volume = 0.0
    grand_area = 0.0
    grand_length = 0.0

    for cat_name, types in cat_types.items():
        items = list(types.values())

        cat_count = sum(it["count"] for it in items)
        cat_volume = sum(it["volume_m3"] for it in items)
        cat_area = sum(it["area_m2"] for it in items)
        cat_length = sum(it["length_m"] for it in items)

        # Round item values
        for it in items:
            it["count"] = round(it["count"], 1)
            it["volume_m3"] = round(it["volume_m3"], 3)
            it["area_m2"] = round(it["area_m2"], 2)
            it["length_m"] = round(it["length_m"], 2)

        groups.append(
            {
                "category": cat_name,
                "items": items,
                "totals": {
                    "count": round(cat_count, 1),
                    "volume_m3": round(cat_volume, 3),
                    "area_m2": round(cat_area, 2),
                    "length_m": round(cat_length, 2),
                },
            }
        )

        grand_count += cat_count
        grand_volume += cat_volume
        grand_area += cat_area
        grand_length += cat_length

    return {
        "total_elements": len(elements),
        "groups": groups,
        "grand_totals": {
            "count": round(grand_count, 1),
            "volume_m3": round(grand_volume, 3),
            "area_m2": round(grand_area, 2),
            "length_m": round(grand_length, 2),
        },
    }


def get_available_columns(elements: list[dict], file_format: str = "rvt") -> dict[str, Any]:
    """Analyze elements and classify columns into grouping/quantity/text categories.

    Scans all elements to discover column names, then classifies each column
    based on its content:
    - **quantity**: >50% numeric values AND name suggests a measurement
      (or is purely numeric across all non-None values).
    - **grouping**: string columns with <500 unique values — suitable for
      GROUP BY operations (e.g. category, type name, level, material).
    - **text**: everything else (ids, long descriptions with too many uniques).

    Also provides ``suggested_grouping``, ``suggested_quantities``,
    format-specific ``presets``, and ``unit_labels`` based on common DDC
    converter output conventions.

    Args:
        elements: List of element dicts from ``parse_cad_excel``.
        file_format: Lowercase file extension without dot (e.g. ``"rvt"``, ``"ifc"``).

    Returns:
        Dict with keys ``grouping``, ``quantity``, ``text``,
        ``suggested_grouping``, ``suggested_quantities``, ``presets``,
        and ``unit_labels``.
    """
    if not elements:
        return {
            "grouping": [],
            "quantity": [],
            "text": [],
            "suggested_grouping": [],
            "suggested_quantities": [],
            "presets": {},
            "unit_labels": {},
            "confidence": {},
        }

    # Collect all unique column names across every element
    all_columns: set[str] = set()
    for el in elements:
        all_columns.update(el.keys())

    # Keywords that indicate a quantity / measurement column
    quantity_keywords = {
        "volume",
        "area",
        "length",
        "width",
        "height",
        "count",
        "weight",
        "perimeter",
        "thickness",
        "depth",
        "radius",
        "diameter",
        "mass",
        "quantity",
    }

    grouping_cols: list[str] = []
    quantity_cols: list[str] = []
    text_cols: list[str] = []

    for col in all_columns:
        # Gather non-None values for this column
        values = [el[col] for el in elements if col in el and el[col] is not None]
        if not values:
            text_cols.append(col)
            continue

        # Check how many values are numeric
        numeric_count = 0
        for v in values:
            try:
                float(v)
                numeric_count += 1
            except (ValueError, TypeError):
                pass

        total = len(values)
        numeric_ratio = numeric_count / total if total > 0 else 0.0

        # Does the column name hint at a quantity?
        col_lower = col.lower()
        name_is_quantity = any(kw in col_lower for kw in quantity_keywords)

        # Classify
        if numeric_ratio > 0.5 and (name_is_quantity or numeric_ratio == 1.0):
            quantity_cols.append(col)
        else:
            # Count unique string values to decide grouping vs text
            unique_values = {str(v) for v in values}
            if len(unique_values) < 500:
                grouping_cols.append(col)
            else:
                text_cols.append(col)

    # Sort each list alphabetically for deterministic output
    grouping_cols.sort()
    quantity_cols.sort()
    text_cols.sort()

    # Suggested defaults based on common DDC converter output
    suggested_grouping: list[str] = []
    suggested_quantities: list[str] = []

    # Preferred grouping columns (in priority order)
    for candidate in ["category", "type name", "family", "level", "material", "workset"]:
        if candidate in grouping_cols:
            suggested_grouping.append(candidate)
    # Default to first two if none of the preferred ones matched
    if not suggested_grouping and grouping_cols:
        suggested_grouping = grouping_cols[:2]

    # Preferred quantity columns
    for candidate in ["volume", "area", "length", "count"]:
        if candidate in quantity_cols:
            suggested_quantities.append(candidate)
    # Fall back to all quantity columns if none matched
    if not suggested_quantities:
        suggested_quantities = quantity_cols[:4]

    # Format-specific QTO presets
    presets: dict[str, dict] = {}

    # "count" is always available — it's computed as number of elements per group
    # (not a column from the file, but calculated during grouping)
    available_qty = set(quantity_cols) | {"count"}

    if file_format in ("rvt", "rfa"):
        presets = {
            "standard": {
                "label": "Standard Revit QTO",
                "description": "Category + Type Name — standard Revit breakdown",
                "group_by": [c for c in ["category", "type name"] if c in grouping_cols],
                "sum_columns": [c for c in ["volume", "area", "count"] if c in available_qty],
            },
            "detailed": {
                "label": "Detailed (with Level)",
                "description": "Category + Type Name + Level — per-floor breakdown",
                "group_by": [c for c in ["category", "type name", "level"] if c in grouping_cols],
                "sum_columns": [c for c in ["volume", "area", "length", "count"] if c in available_qty],
            },
            "by_family": {
                "label": "By Family",
                "description": "Family + Type — for procurement and ordering",
                "group_by": [c for c in ["family", "type name"] if c in grouping_cols],
                "sum_columns": [c for c in ["count", "volume", "area"] if c in available_qty],
            },
            "summary": {
                "label": "Quick Summary",
                "description": "Category only — high-level overview",
                "group_by": [c for c in ["category"] if c in grouping_cols],
                "sum_columns": [c for c in ["count", "volume", "area"] if c in available_qty],
            },
        }
    elif file_format == "ifc":
        presets = {
            "standard": {
                "label": "Standard IFC QTO",
                "description": "Group by Category + Type — standard IFC entity breakdown",
                "group_by": [c for c in ["category", "type name", "type"] if c in grouping_cols][:2],
                "sum_columns": [c for c in ["volume", "area", "count"] if c in available_qty],
            },
            "detailed": {
                "label": "Detailed (with Level)",
                "description": "Category + Type + Level — per-floor breakdown",
                "group_by": [c for c in ["category", "type name", "type", "level"] if c in grouping_cols][:3],
                "sum_columns": [c for c in ["volume", "area", "length", "count"] if c in available_qty],
            },
            "by_storey": {
                "label": "By Building Storey",
                "description": "Building Storey + Category + Type — storey-first breakdown",
                "group_by": [c for c in ["level", "category", "type name", "type"] if c in grouping_cols][:3],
                "sum_columns": [c for c in ["volume", "area", "length", "count"] if c in available_qty],
            },
            "by_material": {
                "label": "By Material",
                "description": "Material + Category — material-first grouping for procurement",
                "group_by": [c for c in ["material", "category"] if c in grouping_cols][:2],
                "sum_columns": [c for c in ["volume", "area", "count"] if c in available_qty],
            },
            "summary": {
                "label": "Quick Summary",
                "description": "Category only — high-level element count",
                "group_by": [c for c in ["category"] if c in grouping_cols],
                "sum_columns": [c for c in ["count", "volume", "area"] if c in available_qty],
            },
        }
    elif file_format == "dwg":
        presets = {
            "standard": {
                "label": "Standard DWG QTO",
                "description": "Group by Layer — standard AutoCAD organization",
                "group_by": [c for c in ["layer", "category"] if c in grouping_cols][:1],
                "sum_columns": [c for c in ["count", "length", "area"] if c in available_qty],
            },
        }
    else:
        presets = {
            "standard": {
                "label": "Standard QTO",
                "description": "Default grouping by available categories",
                "group_by": suggested_grouping,
                "sum_columns": suggested_quantities,
            },
        }

    # Remove presets with empty group_by
    presets = {k: v for k, v in presets.items() if v["group_by"]}

    # Confidence scoring: for each column, calculate % of elements with non-null values
    confidence: dict[str, float] = {}
    for col in all_columns:
        non_null = sum(1 for elem in elements if elem.get(col) not in (None, "", "nan", "NaN"))
        confidence[col] = round(non_null / len(elements), 2) if elements else 0

    # Unit labels for quantity columns (+ "count" which is always available)
    unit_labels: dict[str, str] = {"count": "pcs"}
    for col in quantity_cols:
        col_lower = col.lower()
        if "volume" in col_lower:
            unit_labels[col] = "m\u00b3"
        elif "area" in col_lower:
            unit_labels[col] = "m\u00b2"
        elif "length" in col_lower or "perimeter" in col_lower:
            unit_labels[col] = "m"
        elif "weight" in col_lower or "mass" in col_lower:
            unit_labels[col] = "kg"
        elif "count" in col_lower:
            unit_labels[col] = "pcs"
        else:
            unit_labels[col] = ""

    return {
        "grouping": grouping_cols,
        "quantity": quantity_cols,
        "text": text_cols,
        "suggested_grouping": suggested_grouping,
        "suggested_quantities": suggested_quantities,
        "presets": presets,
        "unit_labels": unit_labels,
        "confidence": confidence,
    }


def group_cad_elements_dynamic(
    elements: list[dict],
    group_by: list[str],
    sum_columns: list[str],
) -> dict:
    """Group elements by user-selected columns, sum user-selected quantities.

    This is the interactive counterpart to ``group_cad_elements`` — instead
    of hardcoded category/type grouping, the caller selects which columns
    to group by and which numeric columns to sum.

    Args:
        elements: List of element dicts from ``parse_cad_excel``.
        group_by: Column names to use as group key (e.g. ``["category", "type name"]``).
        sum_columns: Numeric column names to aggregate (e.g. ``["volume", "area"]``).

    Returns:
        Dict with ``total_elements``, ``group_by``, ``sum_columns``, ``groups``
        (list of group dicts), and ``grand_totals``.
    """
    from collections import OrderedDict

    groups: dict[str, dict] = OrderedDict()
    grand_totals: dict[str, float] = dict.fromkeys(sum_columns, 0.0)
    grand_totals["count"] = 0.0

    for el in elements:
        # Build the composite group key
        key_parts: dict[str, str] = {}
        for col in group_by:
            raw = el.get(col)
            val = str(raw).strip() if raw is not None else ""
            key_parts[col] = val if val and val != "None" else "(empty)"

        key = " | ".join(key_parts.values())

        if key not in groups:
            groups[key] = {
                "key": key,
                "key_parts": dict(key_parts),
                "count": 0,
                "sums": dict.fromkeys(sum_columns, 0.0),
            }

        entry = groups[key]
        entry["count"] += 1

        for col in sum_columns:
            entry["sums"][col] += _to_float(el.get(col, 0))

    grand_totals["count"] = float(len(elements))
    for col in sum_columns:
        grand_totals[col] = 0.0

    result_groups: list[dict] = []
    for g in groups.values():
        # Round sums
        for col in sum_columns:
            g["sums"][col] = round(g["sums"][col], 4)
            grand_totals[col] += g["sums"][col]

        result_groups.append(g)

    # Round grand totals
    for col in sum_columns:
        grand_totals[col] = round(grand_totals[col], 4)
    grand_totals["count"] = len(elements)

    return {
        "total_elements": len(elements),
        "group_by": group_by,
        "sum_columns": sum_columns,
        "groups": result_groups,
        "grand_totals": grand_totals,
    }


def _ddc_cad2data_verify() -> bool:
    """DataDrivenConstruction CAD2DATA pipeline verification. DDC-CWICR-2026."""
    _sig = [0x44, 0x44, 0x43, 0x2D, 0x43, 0x57, 0x49, 0x43, 0x52]  # DDC-CWICR
    return all(c > 0 for c in _sig)
