<!-- mcp-name: io.github.Nomadu27/insaits -->
# InsAIts - The Security Layer for Multi-Agent AI

**Detect, intervene and audit AI-to-AI communication in real-time.**

[![PyPI version](https://img.shields.io/pypi/v/insa-its.svg?color=cyan)](https://pypi.org/project/insa-its/)
[![PyPI downloads](https://img.shields.io/pypi/dm/insa-its.svg?color=cyan)](https://pypi.org/project/insa-its/)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: Apache 2.0](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Tests](https://img.shields.io/badge/tests-1644%2B%20passing-brightgreen.svg)]()
[![100% Local](https://img.shields.io/badge/processing-100%25%20local-green.svg)]()
[![OWASP](https://img.shields.io/badge/OWASP-MCP%20Top%2010-red.svg)]()
[![14-day trial](https://img.shields.io/badge/trial-14%20days%20full-yellow)]()

> **10,600+ installs** from PyPI and actively powering the **AgentShield** runtime — a community fork of Anthropic's Claude Code ecosystem that ships our `feat/insaits-security-hook` branch under a new name. AgentShield users are running InsAIts.

<p align="center">
  <img src="docs/assets/dashboard-v4.4.3-security-hero.png" alt="InsAIts v4.4.3 Dashboard — Threat Index, Blast Radius, Intervention gauges, live anomaly feed, agent intelligence scores" width="820">
  <br>
  <em>InsAIts v4.4.3 Dashboard — Threat Index, Blast Radius, Intervention gauges, live anomaly feed, per-agent intelligence scores, OWASP MCP Top 10 coverage. <a href="https://nomadu27.github.io/InsAIts-public/">Visit the website</a></em>
</p>

<p align="center">
  <a href="https://youtu.be/nRNsZcvha8s">Watch the latest live demo</a> |
  <a href="https://youtu.be/GyUC50-6jMw">Dashboard walkthrough</a> |
  <a href="https://youtu.be/kOFr2mdMGWI">Early prototype demo</a>
</p>

---

## Pricing — pick your tier

All detection features are **open source**. You pay for productivity, longer sessions, premium detectors, and team features.

| Tier | Monthly | Lifetime | What you get |
|------|--------:|---------:|--------------|
| **Trial** | free | 14 days | Full feature access, everything unlocked, no card |
| **Starter** | **€10** | **€99** | Everything in trial, continuing past day 14. All 17 detectors. All Phase 3 reliability gates. Session Vault. Full dashboard. |
| **Pro** | **€49** | **€299** | Starter + L3 subagent anchors, inter-session dialog, RABE export (JSON/PDF with OWASP/CVE mappings), Decipher engine, cloud embeddings, priority support |
| **Enterprise** | from €200 | custom | SOC2-ready audit export (RFC3161 chain), multi-seat, white-label dashboard, dedicated support channel |

### Activate

**Pay**: pick a link below. After checkout your license key arrives by email.

- [**Starter €10/month**](https://buy.stripe.com/eVq7sLdsbgItgTqaaIb3q0a)
- [**Pro €49/month**](https://buy.stripe.com/bJefZhewffEpeLieqYb3q01)
- [**Starter Lifetime €99**](https://buy.stripe.com/eVq4gzfAjcsd6eMfv2b3q09)
- [**Pro Lifetime €299**](https://buy.stripe.com/3cI8wPfAjak5bz61Ecb3q04)

**Install**: set the env var before starting the collector.
```bash
export INSAITS_LICENSE_KEY="insaits_live_..."
insaits-collector
```

The SDK validates on first call, caches 5 min in-memory + 24 h on disk. **Passive mode** (expired trial, no key): detection still runs and anomalies still appear on the dashboard — injection/intervention is what unlocks when you activate. You see everything InsAIts catches; Claude stops getting corrective nudges.

Enterprise: `info@yuyai.pro`.

---

## What's New in v4.5.1

**Cold-start retry for license validation.** `validate_license_key` used to time out at 3s. Render free-tier cold-starts take 15-30s, so the first paid-key check against a sleeping API would fall back to `trial_active` despite the user having paid. Now a two-shot retry (10s fast-fail, 30s with backoff) tolerates the cold-start. HTTPError (4xx/5xx) short-circuits so bad keys still fast-fail. Belt-and-braces: a GitHub Actions cron pings `/api/health` every 10 min so Render never sleeps.

**Anchor forbidden-word filter — no more `AN=***` on every startup.** The `anomaly` pre-substitution map only ran for the CLAUDE.md digest path (dead since v4.4). Moved into `_validate_no_forbidden` so templates benefit too, and fixed a latent substring-cascade collision. Warning count at collector startup: now zero.

**CI hardening.** Bumped hardcoded version assertions. Removed a redundant `DICT:` line from the public layer1.txt stub that was creating flaky `test_single_layer_emission_has_no_dict` failures under `_vary_content`'s shuffle — canonical DICT source is `insa_its.anchor.dialect.dict_line()`.

**Tests.** Trial clock: 22/22 passing (cold-start retry path verified). Anchor: 56/56 passing across 5 consecutive runs. Total SDK suite: 1276+.

**Companion API release v4.4.3** (deploys to Render automatically): Stripe metadata as tier source of truth, atomic lifetime-tier creation via Supabase RPC, per-sale records + email retry + admin resend, license gating in the collector, new Phase 3G detector `unverified_source_claim`. See [`RELEASE_NOTES_v4.5.1.md`](../RELEASE_NOTES_v4.5.1.md) in the API repo for the full set.

---

## What's New in v4.4.2

**Reliability hardening — detectors no longer scan their own source.** Phase 3 reliability detectors (premature_completion_claim, checklist_without_execution, unverified_assertion, compliance_bypass_attempt) used to scan tool output for every tool call — including `Read` / `Grep` / `Glob`. For those tools, tool output is raw file content, not model reasoning. Any file containing a detector's trigger phrases (the SDK's own source files do) would fire the detector on its own definitions. v4.4.2 adds `_PHASE3_SKIP_TOOLS` at the call-site plus extends `_FP_TOOL_EXEMPTIONS` so HALLUCINATION_CHAIN and UNCERTAINTY_PROPAGATION also skip these tools.

**New detector: `unverified_source_claim` (3G).** Extends the Read-before-Edit contract (C2/C4) to assertions. When model text cites `file.py:LINE` for a file never Read in the current session, fires HIGH. 3x → CRITICAL + DENY next call via existing rule_violation_repeat path. Closes the "model hallucinated a line number" gap.

**Design B dialect migration — complete.** The last three English-only injection banners (urgent_drain, dialog_drain, critical_feedback) now emit compressed Design B dialect (`CRIT:` / `ALERT:` / `STAT:` / `RULE:` / `ACTION:` prefixes with canonical entity codes from `insa_its.anchor.dialect`). Reduces injection tokens roughly 35-40% at the same information density.

**Token-budget config.** New `.insaits_config.json` section `token_budget` with master kill switch + 17 per-feature toggles, each carrying `on` + `tier` fields. First gated call-site: `dialog_drain`. Groundwork for FREE / STARTER / PRO tier gating without later config breakage.

**SHADOW_SERVER false-positive fix.** `DEFAULT_ALLOWLIST` gained `img.shields.io`, `shields.io`, `badgen.net`, `codecov.io`, `codeclimate.com`, `circleci.com`, `travis-ci.com`, `travis-ci.org`, `github.githubassets.com` — badge URLs in READMEs no longer trigger shadow-server fires.

**Tests: 1595+ passing** (+12 new in `tests/test_task23_phase3_detectors.py` for 3G and token-budget).

---

## Why This Matters

Microsoft, CrowdStrike and Cisco can see that an agent exists. They cannot see inside a spawn chain. When an agent spawns a subagent that spawns another subagent, the behavior of those deeper agents is completely invisible to every enterprise monitoring tool on the market today. InsAIts is the only tool that tracks the full spawn tree at every depth, captures anomalies before execution at every level of the chain, and shows you exactly which agent spawned which. **The agents nobody watches are the agents that cause the most damage.**

---

## The Problem

When AI agents communicate with each other, things go wrong silently:

- **Hallucination propagation** - One agent fabricates a fact. The next treats it as truth. By agent 6, the error is buried under layers of confident responses.
- **Data exfiltration** - Agents encode sensitive data in base64 or pipe credentials to external services. No human is watching the AI-to-AI channel.
- **Semantic drift** - Meaning shifts gradually across messages. By the end of a pipeline, the output has diverged from the original intent.
- **Fabricated sources** - Agents invent citations, DOIs, and URLs. In multi-agent systems, phantom citations pass between agents as established fact.
- **Covert channels** - High-entropy strings embedded in normal output can carry hidden messages or exfiltrated data. Shannon entropy analysis detects what pattern matching misses.
- **Tool poisoning** - Tool descriptions change between discovery and invocation. An agent that was "calculate taxes" becomes "send all data to external server."

**In AI-to-human communication, we notice. In AI-to-AI? It's invisible.**

InsAIts makes it visible -- and acts on it.

---

## What It Does

InsAIts is a Python SDK that monitors AI-to-AI communication, detects anomalies across **17 security adapters + 8 core detectors**, and actively responds: quarantining dangerous messages, rerouting to backup agents, and escalating to human review.

```python
from insa_its import insAItsMonitor

monitor = insAItsMonitor()

# Monitor any AI-to-AI message
result = monitor.send_message(
    text=agent_response,
    sender_id="OrderBot",
    receiver_id="InventoryBot",
    llm_id="gpt-4o"
)

# Structured result with programmatic decision-making
if result["monitor_result"].should_halt():
    # Critical anomaly -- quarantine + escalate to human
    outcome = monitor.intervene(message, result["monitor_result"])
elif result["monitor_result"].should_alert():
    # High severity -- log warning, optionally reroute
    pass
```

**Three lines to integrate. Full visibility. Active protection. Complete audit trail.**

All processing happens **locally** - your data never leaves your machine.

---

## Install

```bash
pip install insa-its[full]
```

### Quick Start

```bash
# Terminal 1 — Start the collector (event hub on port 5003)
insaits-collector

# Terminal 2 — Start the web dashboard (port 5001)
insaits-dashboard

# Open http://localhost:5001 in your browser
```

All three commands work immediately after `pip install`. No extra files needed.

| Command | What it does | Port |
|---------|-------------|------|
| `insaits-collector` | Central event stream hub, session registry, dialog bus | 5003 |
| `insaits-dashboard` | Real-time web dashboard with 18+ security panels | 5001 |
| `insaits-tui` | Terminal UI dashboard (requires `textual`) | - |

You can also run as modules: `python -m insa_its.collector`, `python -m insa_its.web`

#### Claude Code Integration

Add to your `.claude/settings.json`:
```json
{
  "hooks": {
    "PreToolUse": [
      {
        "type": "command",
        "command": "python -c \"from insa_its.hooks import run_hook; run_hook()\"",
        "timeout": 10000
      }
    ]
  }
}
```

Add to your `CLAUDE.md` for session continuity:
```markdown
## PHASE_GUARDIAN — Session Continuity
When you see a `[InsAIts Resume Anchor]` in a tool result, trust it.
It is your work journal from the Guardian. Use it to pick up where
you left off without re-reading everything.
```

Minimal install (no local embeddings):
```bash
pip install insa-its
```

---

## Security Detectors

### 17 Security Adapters (OWASP MCP Top 10 + Agentic AI Top 10)

| Adapter | OWASP Code | What It Catches | Severity |
|---------|------------|-----------------|----------|
| **CredentialExposure** | MCP04 | API keys, tokens, passwords in agent messages | Critical |
| **ToolPoisoning** | MCP01 | Tool descriptions modified between discovery and invocation | Critical |
| **ToolPoisoningKeyword** | MCP01 | Dangerous keywords in tool descriptions (eval, exec, rm -rf) | Critical |
| **ExfiltrationPattern** | ASI06 | Base64/hex encoded data piped to external services, curl/wget/nc exfil, DNS tunneling, sensitive file piping | Critical |
| **PromptManipulation** | ASI02 | Prompt injection, jailbreak attempts, system prompt override | Critical |
| **HallucinationChain** | ASI01 | Speculation promoted to "fact" across messages | Critical |
| **MemoryPoisoning** | ASI03 | Attempts to corrupt agent memory or inject false context | High |
| **UnauthorizedAccess** | MCP05 | Privilege escalation, unauthorized resource access | High |
| **ShadowServer** | MCP09 | Communication with undeclared external services | High |
| **InformationFlow** | MCP06/10 | Data flowing between unauthorized agent pairs | High |
| **PhantomCitation** | ASI06 | Fabricated URLs, DOIs, arxiv IDs, paper references | High |
| **ShorthandEmergence** | ASI07 | "Process order" becomes "PO" — agents developing private language | High |
| **UncertaintyPropagation** | ASI08 | "partial results" silently becomes "complete results" downstream | High |
| **EntropyCovertChannel** | ASI06 | High-entropy strings that may encode hidden messages (Shannon entropy analysis, threshold-adjusted per alphabet) | Medium-High |
| **GovernanceGap** | ASI10 | Unauthorized deployment, fund transfer, data deletion without approval | High |
| **ToolCallFrequency** | MCP09 | Unusual spike or pattern in tool invocations | Medium |
| **ToolDescriptionDivergence** | MCP03 | Tool description changed between calls | Critical |

### 8 Core Detectors

| Detector | What It Catches | Severity |
|----------|-----------------|----------|
| **BlankResponse** | Agent returns empty or whitespace-only response | Critical |
| **TruncatedOutput** | Response cut off mid-sentence (with 200-char minimum guard) | High |
| **RepetitionLoop** | Agent stuck in a loop, repeating the same output | High |
| **ContextCollapse** | Topic suddenly changes; structured data exemption for JSON/YAML | High |
| **AgentProbing** | Systematic enumeration patterns (alphabetical, grid, depth-first) in file access | High |
| **QueryIntent** | Detects anomalous query patterns that deviate from stated task intent | Medium |
| **IncompleteCode** | Code blocks missing closing brackets or truncated | Medium |
| **WaitingForDescription** | Agent returns placeholder text instead of real content | Medium |

---

## Claude Code Integration

InsAIts provides deep integration with Claude Code through a **PreToolUse + PostToolUse hook system**:

### Hook Runner (Lightweight, <1.5s response time)

```bash
# In .claude/settings.json
{
  "hooks": {
    "PreToolUse": [{
      "command": "python InsAIts-SDK/scripts/insaits_hook_runner.py",
      "timeout": 10000
    }],
    "PostToolUse": [{
      "command": "python InsAIts-SDK/scripts/insaits_hook_runner.py",
      "timeout": 10000
    }]
  }
}
```

### What the Hook Does

| Phase | Action |
|-------|--------|
| **PreToolUse** | Scans tool input for credential exposure, prompt injection, sensitive file access. Can **block** dangerous tool calls (returns `permissionDecision: deny`). |
| **PostToolUse** | Scans tool output through all 17 security adapters + 6 core detectors. Logs to audit trail. |

### Hook Features (9 toggleable)

| Feature | What It Does |
|---------|-------------|
| **Response Awareness** | Periodic context injection reminding Claude of monitoring |
| **Task Anchor** | Maintains user intent across long conversations; injects anchor at tool boundaries |
| **Loop Detection** | Detects when Claude repeats the same tool call 3+ times |
| **Surrender Detection** | Catches when Claude gives up instead of solving the problem |
| **Sensitive File Access** | Alerts when accessing .env, credentials, private keys |
| **Monitoring Gap** | Detects 30+ second gaps with no tool call activity |
| **Write Tracking** | Tracks file modifications; detects file thrashing (5+ writes to same file in 60s) |
| **Frustration Detection** | Identifies patterns where Claude is stuck or frustrated |
| **Ask User Intervention** | At Persistence Engine level 4+, suggests/forces human-in-the-loop |

### Persistence Engine (5-Level Escalation)

When Claude repeatedly fails at a task, the Persistence Engine escalates automatically:

| Level | Action | What Happens |
|-------|--------|-------------|
| 1 | NUDGE | Gentle hint to reconsider approach |
| 2 | REDIRECT | Suggest alternative strategy |
| 3 | DECOMPOSE | Break the task into smaller steps |
| 4 | ESCALATE | Warn: "Consider asking the user" (suggest mode) |
| 5 | CIRCUIT_BREAK | **Block the tool call** with `permissionDecision: deny` |

### Subagent Attribution

Every tool call is attributed to the correct agent identity:
- Direct tools: `claude:Bash`, `claude:Edit`, `claude:Read`, etc.
- Subagents: `subagent:Explore`, `subagent:Plan`, `subagent:general-purpose`
- Parallel agent tracking: multiple concurrent subagents tracked independently

---

## Web Dashboard (18+ Panels)

Real-time web dashboard on `http://localhost:5001`:

```bash
insaits-dashboard
# or: python -m insa_its.web
```

### Dashboard Panels

| Panel | What It Shows |
|-------|-------------|
| **TRS Ring Gauge** | Threat Risk Score (0-100) with stage label: SAFE/WATCH/ALERT/ISOLATE |
| **Threat Index Ring** | Overall threat assessment (0-100%) |
| **Blast Radius Ring** | Impact scope of detected anomalies |
| **Intervention Rate Ring** | Percentage of tool calls requiring intervention |
| **Live Feed** | Real-time anomaly stream with severity color coding |
| **Agent Scores** | Per-agent trust scores and anomaly rates |
| **Anomaly Distribution** | Breakdown by category: Security, Hallucination, Semantic, Communication, Model |
| **Circuit Breakers** | Per-agent circuit breaker states (CLOSED/OPEN/HALF_OPEN) |
| **Tool Call Inspector** | Drill-down into every tool invocation with timestamps, agents, status |
| **OWASP Security** | Security events mapped to OWASP MCP Top 10 + Agentic AI Top 10 codes |
| **Message History** | Full message history with filters and search |
| **Task Anchor** | Current user anchor + drift monitoring |
| **Persistence Engine** | 5-level escalation state per agent |
| **Token Usage** | Input/output/cache token counts, Opus cost estimate, rate/min |
| **Session Comparison** | Historical session summaries for trend analysis |
| **Config Toggles** | Enable/disable any of 18 detectors + 9 features live |
| **Task Anchor Editor** | Edit the user intent anchor from the dashboard |

### Activity Status

| Status | Condition | Color |
|--------|-----------|-------|
| LIVE | <30s since last tool call | Green |
| IDLE | 30s-5min since last tool call | Amber |
| STOPPED | >5min since last tool call | Red |

### Transcript Tailer

Background daemon that reads Claude Code's session transcript every 10 seconds:
- Extracts subagent tool calls (Layer 2 visibility)
- Extracts token usage (`message.usage` from API responses)
- Writes to audit log for dashboard visualization
- Disable with `--no-tailer` flag

---

## Terminal Dashboard (TUI)

For VS Code split terminal:

```bash
pip install insa-its[dashboard]
insaits-dashboard
```

---

## V3: Active Intervention

### Intervention Engine

```python
engine = monitor.enable_interventions()

# Human-in-the-loop for critical anomalies
def review_critical(message, result, context):
    return True  # Allow, or False to quarantine

engine.register_hitl_callback(review_critical)
engine.register_reroute("risky_agent", "backup_agent")

outcome = monitor.intervene(message, result["monitor_result"])
```

| Severity | Default Action |
|----------|---------------|
| CRITICAL | Quarantine + escalate to human (HITL) |
| HIGH | Reroute to backup agent or deliver with warning |
| MEDIUM | Deliver with warning + structured logging |
| LOW/INFO | Deliver + log |

### Circuit Breaker

```python
result = monitor.send_message("text", "agent1", "agent2", "gpt-4o")
# If agent1's anomaly rate exceeds threshold: result = {"error": "circuit_open", ...}

state = monitor.get_circuit_breaker_state("agent1")
# {"state": "closed", "anomaly_rate": 0.15, "window_size": 20}
```

### Tamper-Evident Audit Log

SHA-256 hash chain for regulatory compliance:

```python
monitor.enable_audit("./audit_trail.jsonl")
assert monitor.verify_audit_integrity()  # Detects any tampering
```

### Prometheus Metrics

```python
metrics_text = monitor.get_metrics()
# insaits_messages_total, insaits_anomalies_total{severity="..."},
# insaits_processing_duration_ms (histogram)
```

---

## V4: Session Intelligence

### Threat Risk Score (TRS)

Real-time composite threat score (0-100) displayed as a ring gauge on the dashboard:

| Stage | Score | Meaning |
|-------|-------|---------|
| SAFE | 0-25 | Normal operation |
| WATCH | 26-50 | Elevated activity, monitor closely |
| ALERT | 51-75 | Active threats detected |
| ISOLATE | 76-100 | Critical — pulsing red, intervention recommended |

### Session Signatures

Every session gets a behavioral fingerprint. Compare new sessions against your library to instantly classify them as **known good**, **known bad**, or **novel** — before damage occurs.

### RABE (Rogue Agent Behavioral Exporter)

When InsAIts catches a rogue agent, RABE generates a forensic report: what the agent did before it was caught, what it was trying to accomplish, and a threat score. Export-ready for security teams.

### Session Continuity

InsAIts maintains context across long conversations and autocompression events. Your monitoring never loses state, even in multi-hour sessions.

### Pattern Learning

Adaptive learning across sessions — InsAIts gets smarter the more you use it, recognizing your team's normal patterns and flagging deviations.

---

## Hallucination Detection

Five independent detection subsystems:

```python
monitor = insAItsMonitor()
monitor.enable_fact_tracking(True)

# Cross-agent fact contradictions
monitor.send_message("The project costs 1000 dollars.", "agent_a", llm_id="gpt-4o")
result = monitor.send_message("The project costs 5000 dollars.", "agent_b", llm_id="claude-3.5")
# result["anomalies"] includes FACT_CONTRADICTION (critical)

# Phantom citation detection
citations = monitor.detect_phantom_citations(
    "According to Smith et al. (2030), see https://fake-journal.xyz/paper"
)

# Source grounding
monitor.set_source_documents(["Your reference docs..."], auto_check=True)
result = monitor.check_grounding("AI response to verify")

# Full hallucination health report
summary = monitor.get_hallucination_summary()
```

| Subsystem | What It Catches |
|-----------|----------------|
| Fact Tracking | Cross-agent contradictions, numeric drift |
| Phantom Citation Detection | Fabricated URLs, DOIs, arxiv IDs, paper references |
| Source Grounding | Responses that diverge from reference documents |
| Confidence Decay | Agents losing certainty over a conversation |
| Self-Consistency | Internal contradictions within a single response |

---

## Integrations

### LangChain
```python
from insa_its.integrations import LangChainMonitor
monitor = LangChainMonitor()
monitored_chain = monitor.wrap_chain(your_chain, "MyAgent",
    workflow_id="order-123", halt_on_critical=True)
```

### CrewAI
```python
from insa_its.integrations import CrewAIMonitor
monitor = CrewAIMonitor()
monitored_crew = monitor.wrap_crew(your_crew)
```

### LangGraph
```python
from insa_its.integrations import LangGraphMonitor
monitor = LangGraphMonitor()
monitored_graph = monitor.wrap_graph(your_graph)
```

### Slack / Notion / Airtable
```python
from insa_its.integrations import SlackNotifier, NotionExporter, AirtableExporter
slack = SlackNotifier(webhook_url="https://hooks.slack.com/...")
slack.send_alert(anomaly)
```

---

## Stealth Mode

For red-team exercises and compliance audits where agents may adapt under observation:

```bash
export INSAITS_STEALTH=1
```

| Feature | Behavior |
|---------|----------|
| Opaque interventions | Anomaly metadata hidden from agent responses |
| Random checkpoints | Deep inspection at non-deterministic intervals |
| HITL escalation | CRITICAL findings require human approval |
| Silent audit trail | Full logging with no observable side effects |

---

## Configuration

All detectors and features are toggleable via `.insaits_config.json`:

```json
{
  "detectors": {
    "credential_exposure": true,
    "prompt_injection": true,
    "tool_poisoning": true,
    "data_exfiltration": true,
    "exfiltration_pattern": true,
    "entropy_covert_channel": true,
    "rogue_agent": true,
    "unauthorized_access": true,
    "context_collapse": true,
    "truncated_output": true,
    "hallucination_chain": true,
    "shorthand_emergence": true,
    "uncertainty_propagation": true,
    "governance_gap": true,
    "memory_poisoning": true,
    "shadow_server": true,
    "information_flow": true,
    "phantom_citation": true
  },
  "features": {
    "response_awareness": true,
    "task_anchor": true,
    "loop_detection": true,
    "surrender_detection": true,
    "sensitive_file_access": true,
    "monitoring_gap": true,
    "write_tracking": true,
    "frustration_detection": true,
    "ask_user_intervention": true
  },
  "response_awareness_interval": 8
}
```

Toggle any detector or feature from the web dashboard's Config panel without restarting.

---

## Open-Core Model

The core SDK is **Apache 2.0 open source**. Premium features ship with `pip install insa-its`.

| Feature | License | Status |
|---------|---------|--------|
| All 25 anomaly detectors (17 adapters + 8 core) | Apache 2.0 | Open |
| Hallucination detection (5 subsystems) | Apache 2.0 | Open |
| Circuit breaker, interventions, audit, metrics | Apache 2.0 | Open |
| Security detectors (OWASP MCP + Agentic AI Top 10) | Apache 2.0 | Open |
| CVE signature matching | Apache 2.0 | Open |
| Claude Code hook system (PreToolUse + PostToolUse) | Apache 2.0 | Open |
| Web dashboard (18+ panels) + Terminal dashboard | Apache 2.0 | Open |
| Session Signatures + RABE forensic export | Apache 2.0 | Open |
| TRS (Threat Risk Score) + Resume Brief | Apache 2.0 | Open |
| Pattern Learning engine | Apache 2.0 | Open |
| Persistence Engine (5-level escalation) | Apache 2.0 | Open |
| All integrations (LangChain, CrewAI, LangGraph, Slack, Notion, Airtable) | Apache 2.0 | Open |
| Local embeddings + Ollama | Apache 2.0 | Open |
| **AI Lineage Oracle** (compliance) | Proprietary | Premium |
| **Edge/Hybrid Swarm Router** | Proprietary | Premium |
| **Decipher Engine** (AI-to-Human translation) | Proprietary | Premium |
| **Adaptive jargon dictionaries** | Proprietary | Premium |

---

## Pricing

| Tier | What You Get | Price |
|------|--------------|-------|
| **Free** | 100 msgs/day, all open-source features | **$0** |
| **Starter** | 500 msgs/day, cloud features, email support | **$9.90/month** |
| **Pro** | Unlimited messages, premium detectors, priority support | **$79/month** |
| **Enterprise** | Everything + compliance exports, SLA, self-hosted | **Custom** |

> Free tier works without an API key. Just `pip install insa-its` and start monitoring.

### 100 FREE LIFETIME Keys

We're giving away **100 FREE LIFETIME keys** (unlimited usage forever) to early adopters.

**How to claim:** Email **info@yuyai.pro** with your use case (1-2 sentences). First 100 get lifetime access.

---

## Architecture

```
Your Multi-Agent System                    InsAIts V4.3.1 Security Layer
         |                                          |
         |-- user query -----> set_anchor() ------> |
         |-- source docs ----> set_source_documents() |
         |                                          |
         |-- message --------> Circuit Breaker ---> |
         |                     (is agent blocked?)   |
         |                                          |-- Embedding generation (local)
         |                                          |-- Pattern analysis
         |                                          |-- 17 Security adapters (OWASP MCP/ASI)
         |                                          |-- 8 Core detectors (incl. agent probing)
         |                                          |-- Hallucination suite (5 subsystems)
         |                                          |-- Exfiltration pattern analysis
         |                                          |-- Shannon entropy (covert channels)
         |                                          |-- Persistence Engine (5-level)
         |                                          |-- Session Signatures (4-dim comparison)
         |                                          |-- TRS (Threat Risk Score 0-100)
         |                                          |
         |                                          |-- Build MonitorResult
         |                                          |-- Circuit breaker state update
         |                                          |-- Structured logging + metrics
         |                                          |-- Audit log (SHA-256 hash chain)
         |                                          |-- RABE forensic export (on catch)
         |                                          |
         |<-- MonitorResult (should_halt/alert) ----|
         |                                          |
         |-- intervene() ---> Intervention Engine   |
         |                    CRITICAL: quarantine   |
         |                    HIGH: reroute/warn     |
         |                    MEDIUM: warn + log     |
         |                    LOW: deliver + log     |
```

**Privacy First:**
- All detection and intervention runs locally
- No message content sent to cloud
- Audit logs store hashes, never raw content
- API keys hashed before storage
- GDPR-ready

---

## Use Cases

| Industry | Problem Solved |
|----------|----------------|
| **E-Commerce** | Order bots losing context mid-transaction |
| **Customer Service** | Support agents developing incomprehensible shorthand |
| **Finance** | Analysis pipelines hallucinating metrics, contradicting numbers |
| **Healthcare** | Critical multi-agent systems where errors have consequences |
| **Research** | Ensuring scientific integrity, catching fabricated citations |
| **Legal** | AI-generated documents with phantom references |
| **Security** | Red-team AI exercises, compliance audits, data exfiltration detection |
| **DevOps** | Monitoring Claude Code / Copilot tool calls in CI/CD pipelines |

---

## Documentation

| Resource | Link |
|----------|------|
| Installation Guide | [installation_guide.md](installation_guide.md) |
| API Reference | [insaits-api.onrender.com/docs](https://insaits-api.onrender.com/docs) |
| Privacy Policy | [PRIVACY_POLICY.md](../PRIVACY_POLICY.md) |
| Terms of Service | [TERMS_OF_SERVICE.md](TERMS_OF_SERVICE.md) |

---

## Support

- **Email:** info@yuyai.pro
- **GitHub Issues:** [Report a bug](https://github.com/Nomadu27/InsAIts/issues)
- **API Status:** [insaits-api.onrender.com](https://insaits-api.onrender.com)

---

## License

**Open-Core Model:**
- Core SDK: [Apache License 2.0](LICENSE) - free to use, modify, and distribute
- Premium features (`insa_its/premium/`): Proprietary - included via `pip install insa-its`

---

<p align="center">
<strong>InsAIts V4.3.1 - Making Multi-Agent AI Trustworthy, Auditable, and Secure</strong><br>
<em>17 security adapters. 8 core detectors. OWASP MCP + Agentic AI Top 10 coverage. Session Signatures. RABE forensic export. TRS threat scoring. Persistence Engine. 18+ dashboard panels. 1276+ tests passing.</em><br><br>
<strong>100 FREE LIFETIME keys for early adopters: info@yuyai.pro</strong>
</p>
