"""InsAIts Collector — Central event stream hub.

Usage:
    python -m insa_its.collector          # start on default port 5003
    python -m insa_its.collector --port 5010
    insaits-collector                     # console script entry point

The canonical collector lives at the API repo root (insaits_collector.py).
This module resolves to it dynamically.
"""

import os


def _find_collector():
    """Locate the canonical insaits_collector.py."""
    sdk_root = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    api_root = os.path.dirname(sdk_root)
    candidates = [
        os.path.join(api_root, "insaits_collector.py"),
        os.path.join(sdk_root, "..", "insaits_collector.py"),
        os.path.join(os.path.dirname(__file__), "server.py"),  # legacy fallback
    ]
    for path in candidates:
        real = os.path.realpath(path)
        if os.path.isfile(real):
            return real
    return None


def main():
    """Entry point — imports collector directly, bypasses heavy SDK init."""
    import importlib.util
    path = _find_collector()
    if path is None:
        raise FileNotFoundError(
            "Cannot find insaits_collector.py. "
            "Run from the InsAIts API repo or install the full package."
        )
    spec = importlib.util.spec_from_file_location("insa_its.collector.server", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.main()


__all__ = ["main"]
