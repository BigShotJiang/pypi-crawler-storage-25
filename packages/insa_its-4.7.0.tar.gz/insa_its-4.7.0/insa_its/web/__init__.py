"""InsAIts Web Dashboard — Real-time security monitoring UI.

Usage:
    python -m insa_its.web               # start on default port 5001
    python -m insa_its.web --port 8080
    insaits-dashboard                    # console script entry point

The canonical dashboard lives at the API repo root (insaits_web_dashboard.py).
This module resolves to it dynamically, searching:
  1. API repo root (development: editable install)
  2. Same directory as this file (legacy fallback)
"""

import os


def _find_dashboard():
    """Locate the canonical insaits_web_dashboard.py."""
    # Development: API repo root (2 levels up from insa_its/web/)
    sdk_root = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    api_root = os.path.dirname(sdk_root)
    candidates = [
        os.path.join(api_root, "insaits_web_dashboard.py"),
        os.path.join(sdk_root, "..", "insaits_web_dashboard.py"),
        os.path.join(os.path.dirname(__file__), "server.py"),  # legacy fallback
    ]
    for path in candidates:
        real = os.path.realpath(path)
        if os.path.isfile(real):
            return real
    return None


def main():
    """Entry point — imports dashboard directly, bypasses heavy SDK init."""
    import importlib.util
    path = _find_dashboard()
    if path is None:
        raise FileNotFoundError(
            "Cannot find insaits_web_dashboard.py. "
            "Run from the InsAIts API repo or install the full package."
        )
    spec = importlib.util.spec_from_file_location("insa_its.web.server", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.main()


__all__ = ["main"]
