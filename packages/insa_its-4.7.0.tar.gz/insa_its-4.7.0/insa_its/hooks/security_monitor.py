"""
InsAIts ECC plugin entrypoint — license-gated wrapper around the hook runner.

Invoked by the ECC fork's JS shim:
    python -m insa_its.hooks.security_monitor

PLAN_ECC_LICENSE_GATE.md §3 Lock #3 contract:
  * exit 0 → license valid, hook runner delegated successfully
  * exit 3 → LicenseMissingError   (no key + no cache)
  * exit 4 → LicenseExpiredError   (cache expired, remote unreachable)
  * exit 5 → LicenseFeatureMissingError (tier missing required feature)

Exit codes are consumed by Claude Code: non-zero is treated as a hook
error and surfaced to the user.
"""

from __future__ import annotations

import logging
import sys
from typing import Callable, Optional

from ..exceptions import (
    LicenseExpiredError,
    LicenseFeatureMissingError,
    LicenseMissingError,
)
from ..license import require_valid_license

logger = logging.getLogger(__name__)

_FEATURE_FLAG = "hook.security_monitor.ecc"
_CONTEXT = "ECC plugin entrypoint"

_INSTALL_HINT = (
    "[InsAIts ECC plugin] No valid InsAIts license found.\n"
    "  1. Install:  pip install insa-its\n"
    "  2. Activate: python -m insa_its.cli license activate <KEY>\n"
    "     (or set environment variable INSAITS_LICENSE_KEY=<KEY>)\n"
    "  See: https://pypi.org/project/insa-its/\n"
)

_EXPIRED_HINT = (
    "[InsAIts ECC plugin] License cache expired and remote is unreachable.\n"
    "  Reconnect to the internet, or re-activate your license key.\n"
)

_FEATURE_HINT_TMPL = (
    "[InsAIts ECC plugin] Your InsAIts license does not include the "
    "required feature: {feature}\n"
    "  Upgrade at https://insaits.onrender.com/pricing\n"
)


def _default_runner() -> int:
    """Delegate to the in-package hook runner. Returns 0 on success."""
    from . import run_hook
    run_hook()
    return 0


def main(runner: Optional[Callable[[], int]] = None) -> int:
    """Main entrypoint.

    ``runner`` is injectable so tests can verify delegation occurs on
    license success without requiring a real Claude Code hook payload
    on stdin.
    """
    try:
        require_valid_license(features=(_FEATURE_FLAG,), context=_CONTEXT)
    except LicenseMissingError as exc:
        sys.stderr.write(_INSTALL_HINT)
        sys.stderr.write(f"  Detail: {exc}\n")
        return 3
    except LicenseExpiredError as exc:
        sys.stderr.write(_EXPIRED_HINT)
        sys.stderr.write(f"  Detail: {exc}\n")
        return 4
    except LicenseFeatureMissingError as exc:
        sys.stderr.write(_FEATURE_HINT_TMPL.format(feature=exc.feature))
        return 5

    try:
        return (runner or _default_runner)() or 0
    except Exception as exc:  # noqa: BLE001 — propagate runner failures as exit 1
        logger.error("Hook runner failed: %s", exc)
        sys.stderr.write(f"[InsAIts ECC plugin] Hook runner error: {exc}\n")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
