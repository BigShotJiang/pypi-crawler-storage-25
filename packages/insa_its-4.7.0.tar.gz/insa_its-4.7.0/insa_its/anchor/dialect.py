"""
InsAIts Compressed Anchor Dialect (C1 — Design B)
==================================================
Canonical definition + parser for the anchor dialect emitted as a
``DICT:`` key-line on multi-layer anchors.

The dialect has three layers:

1. **Entity codes** — single/double-letter handles for tool/anomaly
   identifiers. Used when emitting structured facts (e.g. ``R/E=3.2`` for
   the live Read:Edit ratio).

2. **State prefixes** — line-leading tags that classify an assertion
   (``THINK:``, ``RULE:``, ``STAT:``, ``ALERT:``, ``OK:``, ``WARN:``,
   ``CRIT:``, ``ACTION:``).

3. **Phrase substitutions** — long CLAUDE.md maxims compressed to a short
   symbolic form (``plan->code``, ``verify->done``, etc).

The ``DICT:`` line that leads a multi-layer emission publishes the entity
codes so a downstream reader can faithfully expand them. This is a
published contract, not obfuscation — InsAIts' own collector uses the
parser below to SEE and UNDERSTAND the dialect when it appears in
injected text.
"""

from __future__ import annotations

import re
from typing import Dict, Iterable, List, Tuple

# ---------------------------------------------------------------------------
# Canonical dialect (PLAN1.md C1 Design B, lines 599-621 + 651-661)
# ---------------------------------------------------------------------------

#: Entity codes — short handles for tools, anomalies, session objects.
#: These are the pairs advertised on the ``DICT:`` line.
ENTITY_CODES: Dict[str, str] = {
    "R": "Read/Grep",
    "E": "Edit/Write",
    "B": "Bash",
    "AG": "AgentSpawn",
    "SA": "Subagent",
    "TC": "ToolCall#",
    "AN": "Anomaly",
    "SID": "SessionID",
}

#: Additional short aliases used inside compressed anchors. These are
#: NOT published on the DICT line (they would bloat it) but ARE recognised
#: by the parser so InsAIts can understand its own emissions.
EXTENDED_CODES: Dict[str, str] = {
    "R/E": "ReadEditRatio",
    "TDC": "ThinkingDepthCorrection",
    "BR": "BlastRadius",
    "TRS": "ThreatReadinessScore",
    "RABE": "RequiredAnchorByEvent",
}

#: State prefixes — line-leading tags. Always terminated with a colon.
STATE_PREFIXES: Tuple[str, ...] = (
    "THINK", "RULE", "STAT", "ALERT",
    "OK", "WARN", "CRIT", "ACTION",
)

#: Symbols used in structured assertions. Meaning → human-readable gloss.
SYMBOLS: Dict[str, str] = {
    "→": "leads-to",
    "≥": "at-least",
    "≤": "at-most",
    "≠": "must-not",
    "|": "or",
    "!": "action-required",
    "?": "uncertain",
    "★": "importance",
}

#: Phrase substitutions — (original, compressed). Order matters: longest
#: first so short prefixes don't eat long ones.
PHRASE_SUBSTITUTIONS: Tuple[Tuple[str, str], ...] = (
    ("Update WORK_LOG.md at session end.", "ACTION:WORK_LOG→session-end"),
    ("Go deep. Never superficial.", "deep≠superficial"),
    ("Do NOT re-read large files", "RULE:no-reread(large-files)"),
    ("Context compression detected", "STAT:compact"),
    ("This is your own product.", "own-product"),
    ("Continue from last action.", "ACTION:continue"),
    ("Plan before code.", "plan→code"),
    ("Verify before done.", "verify→done"),
    ("Root cause only.", "root-cause-only"),
    ("status: nominal", "STAT:nominal"),
    # Legacy Design A tokens kept as phrase subs (backward compat with
    # already-deployed anchors that used §-form shorthand).
    ("plan-first", "§P"),
    ("verify-before-done", "§V"),
    ("read-before-edit", "§R"),
    ("blast-radius-minimise", "§B"),
    ("scope-discipline", "§S"),
    ("honesty-on-verification", "§H"),
)

#: Reverse map of the phrase subs — used by the expander.
_PHRASE_REVERSE: Tuple[Tuple[str, str], ...] = tuple(
    (compressed, original) for original, compressed in PHRASE_SUBSTITUTIONS
)

#: Hard floor on post-compression length (chars). Below this we revert to
#: the original content — very short anchors do not benefit from compression
#: and lose clarity.
MIN_COMPRESSED_CHARS: int = 60

#: Substrings that mark a message as un-compressible (clarity > brevity).
CRITICAL_MARKERS: Tuple[str, ...] = (
    "INSAITS SECURITY WARNING",
    "BLOCK EXECUTION",
)


# ---------------------------------------------------------------------------
# Emission helpers
# ---------------------------------------------------------------------------

def dict_line() -> str:
    """Return the canonical ``DICT:`` header line for the entity codes.

    The line format is:
        ``DICT:R=Read/Grep|E=Edit/Write|B=Bash|AG=AgentSpawn|...``

    Pipe separators match PLAN1.md line 619.
    """
    pairs = "|".join(f"{k}={v}" for k, v in ENTITY_CODES.items())
    return f"DICT:{pairs}"


def compress(text: str) -> str:
    """Compress a plain-English anchor into the dialect.

    Returns the text unchanged if any CRITICAL marker is present, or if
    the compressed form would fall below :data:`MIN_COMPRESSED_CHARS`.
    Preserves all numbers and identifiers exactly.
    """
    if not text:
        return text
    # Critical guards — never touch intervention messaging.
    upper = text.upper()
    for marker in CRITICAL_MARKERS:
        if marker in upper:
            return text

    out = text
    for original, compressed in PHRASE_SUBSTITUTIONS:
        # Case-insensitive literal replacement. We use re.escape because
        # phrase strings may contain regex metacharacters (".", "(", etc).
        # If the phrase is identifier-like (starts AND ends with a word
        # char, e.g. "plan-first"), anchor with \b so it can't collide
        # inside user identifiers like "my_plan-first_flag".
        pattern = re.escape(original)
        if original[:1].isalnum() and original[-1:].isalnum():
            pattern = rf"\b{pattern}\b"
        out = re.sub(pattern, compressed, out, flags=re.IGNORECASE)

    # Safety: never compress below the MIN_COMPRESSED_CHARS floor when the
    # original was meaningfully longer. Preserves clarity on tiny messages.
    if len(out) < MIN_COMPRESSED_CHARS < len(text):
        return text
    return out


# ---------------------------------------------------------------------------
# Parser / expander — so InsAIts can UNDERSTAND its own emissions
# ---------------------------------------------------------------------------

# Matches "DICT:" plus everything up to the first newline or end-of-string.
_DICT_LINE_RE = re.compile(r"^DICT:(?P<pairs>[^\r\n]+)", re.MULTILINE)

# Accept either pipe or comma separators (older Design A used commas).
_PAIR_SEP_RE = re.compile(r"[|,]")


def parse_dict_line(text: str) -> Dict[str, str]:
    """Extract the ``DICT:`` key map from an anchor body.

    Returns an empty dict if no ``DICT:`` line is present or if the line
    is malformed. Tolerates both pipe and comma separators so this parser
    works against historical Design A emissions as well.

    Example::

        >>> parse_dict_line("DICT:R=Read/Grep|E=Edit/Write\\n...body...")
        {'R': 'Read/Grep', 'E': 'Edit/Write'}
    """
    if not text:
        return {}
    match = _DICT_LINE_RE.search(text)
    if not match:
        return {}
    pairs = _PAIR_SEP_RE.split(match.group("pairs"))
    result: Dict[str, str] = {}
    for pair in pairs:
        if "=" not in pair:
            continue
        key, _, value = pair.partition("=")
        key, value = key.strip(), value.strip()
        if key and value:
            result[key] = value
    return result


def _token_pattern(tokens: Iterable[str]) -> re.Pattern:
    """Build a single regex that alternates all tokens, longest first.

    Longest-first prevents ``R`` from eating a preceding ``R/E``.
    Word-boundary-safe for alphanumeric tokens; for tokens containing
    non-word characters (``R/E``, ``§P``) we require a non-word LHS/RHS
    context via lookaround instead.
    """
    ordered = sorted(set(tokens), key=len, reverse=True)
    alts: List[str] = []
    for tok in ordered:
        if not tok:
            continue
        if re.fullmatch(r"\w+", tok):
            alts.append(rf"\b{re.escape(tok)}\b")
        else:
            # Non-word chars: no \b anchor. Use lookaround for clean edges.
            alts.append(rf"(?<!\w){re.escape(tok)}(?!\w)")
    if not alts:
        # Regex that never matches — keeps the caller's logic simple.
        return re.compile(r"(?!x)x")
    return re.compile("|".join(alts))


def expand_tokens(
    text: str,
    dict_map: Dict[str, str] | None = None,
    *,
    include_extended: bool = True,
    include_phrases: bool = True,
) -> str:
    """Expand compressed tokens back to their human-readable form.

    ``dict_map`` — when provided (e.g. the result of :func:`parse_dict_line`
    on the same anchor body) — takes precedence over the built-in
    :data:`ENTITY_CODES`. This honours per-session dialect overrides if
    a future anchor emits a custom DICT line.

    ``include_extended`` also expands :data:`EXTENDED_CODES` (``R/E``,
    ``TDC``, etc) which do not appear on the DICT line.

    ``include_phrases`` also reverses :data:`PHRASE_SUBSTITUTIONS` so
    ``plan→code`` becomes ``Plan before code.`` again.
    """
    if not text:
        return text

    combined: Dict[str, str] = {}
    if include_extended:
        combined.update(EXTENDED_CODES)
    # Built-in entity codes baseline...
    combined.update(ENTITY_CODES)
    # ...then override with the parsed DICT line (session-specific wins).
    if dict_map:
        combined.update(dict_map)

    out = text
    if combined:
        pat = _token_pattern(combined.keys())
        out = pat.sub(lambda m: combined.get(m.group(0), m.group(0)), out)

    if include_phrases:
        # Apply in declaration order so the longest compressed forms go
        # first (they appear first in the tuple by construction).
        for compressed, original in _PHRASE_REVERSE:
            out = re.sub(re.escape(compressed), original, out)

    return out


def extract_and_expand(text: str) -> str:
    """One-shot convenience: parse the embedded DICT line and expand.

    Useful for the collector's audit trail — logs the HUMAN-READABLE form
    of an anchor so the dashboard stream is legible without a separate
    decode step.
    """
    dict_map = parse_dict_line(text)
    # Strip the DICT line itself from the expanded output — it was metadata,
    # not content. We only strip a single leading DICT line so later
    # body-text containing the literal string "DICT:" (e.g. documentation
    # snippets) survives.
    stripped = _DICT_LINE_RE.sub("", text, count=1).lstrip("\n")
    return expand_tokens(stripped, dict_map)


__all__ = [
    "ENTITY_CODES",
    "EXTENDED_CODES",
    "STATE_PREFIXES",
    "SYMBOLS",
    "PHRASE_SUBSTITUTIONS",
    "MIN_COMPRESSED_CHARS",
    "CRITICAL_MARKERS",
    "dict_line",
    "compress",
    "parse_dict_line",
    "expand_tokens",
    "extract_and_expand",
]
