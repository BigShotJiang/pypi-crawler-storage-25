"""
License gate for entry-point scripts (ECC plugin, future integrations).

Contract — PLAN_ECC_LICENSE_GATE.md §3 Lock #3 / Lock #4:

    require_valid_license(features=(...), context="...") -> dict

Resolution order:
  1. ``INSAITS_LICENSE_KEY`` env var present → call
     ``validate_license_key`` (network POST + 24h cache write on success,
     fall back to disk cache on network failure).
  2. No env var → read raw 24h disk cache directly.
  3. Cache expired (``valid_until`` past) → LicenseExpiredError.
  4. Cache missing → LicenseMissingError.
  5. Tier grants all requested features → return license doc.
     Otherwise → LicenseFeatureMissingError.

The cache file (``~/.insaits/license/validated.json``) is written by
``trial_clock.validate_license_key`` on successful server validation.
That existing path is reused verbatim — no new on-disk surface.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, Optional, Set

from ..exceptions import (
    LicenseExpiredError,
    LicenseFeatureMissingError,
    LicenseMissingError,
)
from . import trial_clock as _tc

logger = logging.getLogger(__name__)


TIER_FEATURES: Dict[str, Set[str]] = {
    "starter":    {"hook.security_monitor.ecc"},
    "pro":        {"hook.security_monitor.ecc"},
    "enterprise": {"hook.security_monitor.ecc"},
}


def _read_cache_raw() -> Optional[Dict[str, Any]]:
    """Return the cache dict without TTL gating, or None if unreadable.

    Distinct from ``trial_clock._read_license_cache`` which silently drops
    expired caches — we need to distinguish *expired* from *missing* to
    surface the right exception.
    """
    path = _tc._LICENSE_CACHE_PATH
    if not path.exists():
        return None
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (IOError, OSError, json.JSONDecodeError):
        return None


def _validate_via_env_key() -> Optional[Dict[str, Any]]:
    """If INSAITS_LICENSE_KEY is set, do a full network→cache validation.

    Returns normalised license doc or None (env var absent / validation
    failed AND no cache fallback fired).
    """
    key = os.environ.get("INSAITS_LICENSE_KEY", "").strip()
    if not key:
        return None
    result = _tc.validate_license_key(key)
    if not result.get("valid"):
        return None
    return {
        "tier":   result.get("tier", "starter"),
        "email":  result.get("email", ""),
        "key_id": result.get("id", ""),
        "source": result.get("source", "api"),
    }


def require_valid_license(
    features: Iterable[str] = (),
    context: str = "",
) -> Dict[str, Any]:
    """Enforce valid license + feature coverage.

    Returns the resolved license doc (tier/email/key_id/source). Raises:
      * LicenseMissingError        — no env key AND no disk cache.
      * LicenseExpiredError        — cache present but ``valid_until`` past.
      * LicenseFeatureMissingError — valid license, missing feature flag.
    """
    features_tuple = tuple(features)
    license_doc = _validate_via_env_key()

    # Fallback: no env key OR env key failed → try raw cache.
    if license_doc is None:
        raw = _read_cache_raw()
        if raw is None:
            raise LicenseMissingError(
                "No valid InsAIts license. "
                f"Context: {context or '(none)'}. "
                "Install: pip install insa-its  |  "
                "Activate: python -m insa_its.cli license activate <KEY>  "
                "(or set INSAITS_LICENSE_KEY)."
            )
        valid_until = _tc._parse_iso(raw.get("valid_until", ""))
        if valid_until is None or valid_until < datetime.now(timezone.utc):
            raise LicenseExpiredError(
                f"License cache expired (valid_until="
                f"{raw.get('valid_until', 'unknown')}). "
                "Reconnect to re-validate."
            )
        license_doc = {
            "tier":   raw.get("tier", ""),
            "email":  raw.get("email", ""),
            "key_id": raw.get("key_id", ""),
            "source": "cache",
        }

    tier = license_doc.get("tier", "")
    granted = TIER_FEATURES.get(tier, set())
    for feat in features_tuple:
        if feat not in granted:
            raise LicenseFeatureMissingError(feat)

    logger.info(
        "License validated: tier=%s source=%s context=%s",
        tier, license_doc.get("source"), context or "(none)",
    )
    return license_doc


__all__ = ["require_valid_license", "TIER_FEATURES"]
