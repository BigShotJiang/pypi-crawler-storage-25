"""
InsAIts trial clock — v4.5.0 monetization core.

14-day full trial, then passive mode (detection keeps running, injection
stops). Three tamper-resistant layers anchor the install date:

    Layer 1: ~/.insaits/license/trial_anchor.json
    Layer 2: %APPDATA%/insaits/.trial_marker   (Windows)
             ~/.config/insaits/.trial_marker   (Unix)
    Layer 3: `trial_activated` event in ~/.insaits/audit/session.jsonl

All three carry an HMAC-SHA256 of (installed_at + machine_id) against a
baked-in salt. The salt is OPEN-SOURCE — anyone who reads the code can
read it. Goal: deter casual JSON edits, not defeat a motivated attacker.
The €10 price point makes the economics work even with trivial bypass.

stdlib-only. No cryptography, no torch, nothing heavy. Callers (collector
+ dashboard) import this directly; it must stay fast and dependency-free.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import platform
import socket
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, Optional
from urllib import request as _urlreq, error as _urlerr

logger = logging.getLogger("insa_its.license.trial_clock")

TRIAL_DAYS: int = 14
_VERSION: str = "4.5.0"

# Baked-in HMAC salt. 32 random bytes. Regenerate only if you're breaking
# backward compatibility with pre-v4.5.0 trial anchors (there are none).
_TRIAL_SALT: bytes = bytes.fromhex(
    "a3f29d874e6b1ce5b78d4c0f6a215d3e9b847c20f5d1a9e83b4c6f2710d8e9a5"
)

# --- Layer paths -----------------------------------------------------------
TRIAL_ANCHOR_DIR: Path = Path.home() / ".insaits" / "license"
TRIAL_ANCHOR_FILE: Path = TRIAL_ANCHOR_DIR / "trial_anchor.json"

if platform.system() == "Windows":
    _APPDATA = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
    TRIAL_BREADCRUMB_DIR: Path = Path(_APPDATA) / "insaits"
else:
    TRIAL_BREADCRUMB_DIR: Path = Path.home() / ".config" / "insaits"
TRIAL_BREADCRUMB_FILE: Path = TRIAL_BREADCRUMB_DIR / ".trial_marker"

AUDIT_LOG_FILE: Path = Path.home() / ".insaits" / "audit" / "session.jsonl"

# --- License validation paths / config -------------------------------------
_LICENSE_CACHE_PATH: Path = TRIAL_ANCHOR_DIR / "validated.json"
_LICENSE_CACHE_TTL_HOURS: int = 24
_DEFAULT_API_URL: str = "https://insaits-api.onrender.com"
# First attempt timeout — fast-fail when the API is deterministically down.
_VALIDATE_TIMEOUT: float = 10.0
# Retry timeout — tolerates Render free-tier cold-start (15-30s from sleep).
# Without this, a first-ever paid-key validate on a cold API times out and
# the user falls through to trial_active mode despite having paid.
_VALIDATE_RETRY_TIMEOUT: float = 30.0
_VALIDATE_RETRY_DELAY: float = 2.0

# --- Cached state ----------------------------------------------------------
# Module-level cache: get_license_state() is called on collector startup
# and every 5 minutes thereafter. Subsequent calls within the same process
# return the cached dict unless force_refresh=True.
_STATE_CACHE: Dict[str, Any] = {}
_STATE_CACHE_TS: float = 0.0
_STATE_CACHE_TTL: float = 300.0  # 5 min

# Layer 3 (audit log) scan is the slow path — cache its result separately
# so a cache miss on the main state doesn't re-scan the audit log.
_LAYER3_CACHE: Optional[str] = None
_LAYER3_CACHE_FOUND: bool = False


# ===========================================================================
# Fingerprint + checksum helpers
# ===========================================================================
def _compute_machine_id() -> str:
    """Stable soft-fingerprint: sha256(hostname + username + home_dir).

    Stable across reinstalls on the same machine. Non-invasive (no MAC /
    CPU / disk serial). Changes when the user moves to a new machine —
    which is fine: a new trial starts, which the spec explicitly accepts.
    """
    try:
        hostname = socket.gethostname() or "unknown"
    except OSError:
        hostname = "unknown"
    try:
        user = os.getlogin()
    except OSError:
        user = os.environ.get("USER") or os.environ.get("USERNAME") or "unknown"
    home = str(Path.home())
    payload = f"{hostname}|{user}|{home}".encode("utf-8", errors="replace")
    return hashlib.sha256(payload).hexdigest()


def _compute_checksum(installed_at: str, machine_id: str) -> str:
    """HMAC-SHA256 over (installed_at + '|' + machine_id)."""
    msg = (installed_at + "|" + machine_id).encode("utf-8")
    return hmac.new(_TRIAL_SALT, msg, hashlib.sha256).hexdigest()


def _verify_checksum(anchor: Dict[str, Any]) -> bool:
    """Constant-time compare of stored checksum vs recomputed."""
    stored = anchor.get("checksum", "")
    installed_at = anchor.get("installed_at", "")
    machine_id = anchor.get("machine_id", "")
    if not (stored and installed_at and machine_id):
        return False
    try:
        expected = _compute_checksum(installed_at, machine_id)
    except Exception:
        return False
    return hmac.compare_digest(stored, expected)


# ===========================================================================
# Layer 1 — trial_anchor.json
# ===========================================================================
def _write_layer1(installed_at: str, machine_id: str) -> bool:
    """Write ~/.insaits/license/trial_anchor.json atomically. Never raises."""
    try:
        TRIAL_ANCHOR_DIR.mkdir(parents=True, exist_ok=True)
        doc = {
            "installed_at": installed_at,
            "trial_days":   TRIAL_DAYS,
            "machine_id":   machine_id,
            "checksum":     _compute_checksum(installed_at, machine_id),
            "version":      _VERSION,
        }
        tmp = TRIAL_ANCHOR_FILE.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(doc, fh, indent=2)
        tmp.replace(TRIAL_ANCHOR_FILE)
        return True
    except (IOError, OSError) as exc:
        logger.debug("trial_anchor write failed: %s", exc)
        return False


def _read_layer1() -> Optional[Dict[str, Any]]:
    """Read + verify trial_anchor.json. Returns None on any failure."""
    if not TRIAL_ANCHOR_FILE.exists():
        return None
    try:
        with open(TRIAL_ANCHOR_FILE, "r", encoding="utf-8") as fh:
            doc = json.load(fh)
    except (IOError, OSError, json.JSONDecodeError):
        return None
    if not isinstance(doc, dict):
        return None
    if not _verify_checksum(doc):
        logger.warning("Trial anchor tampered or checksum mismatch — treating as expired")
        return None
    return doc


# ===========================================================================
# Layer 2 — .trial_marker breadcrumb (separate directory)
# ===========================================================================
def _write_layer2(installed_at: str, machine_id: str) -> bool:
    """Write the OS-level breadcrumb. Survives deletion of ~/.insaits/."""
    try:
        TRIAL_BREADCRUMB_DIR.mkdir(parents=True, exist_ok=True)
        checksum = _compute_checksum(installed_at, machine_id)
        # Minimal 2-line format so it's hard to corrupt partially.
        with open(TRIAL_BREADCRUMB_FILE, "w", encoding="utf-8") as fh:
            fh.write(installed_at + "\n")
            fh.write(checksum + "\n")
        return True
    except (IOError, OSError) as exc:
        logger.debug("trial_marker write failed: %s", exc)
        return False


def _read_layer2() -> Optional[str]:
    """Read + verify breadcrumb. Returns installed_at ISO string or None."""
    if not TRIAL_BREADCRUMB_FILE.exists():
        return None
    try:
        with open(TRIAL_BREADCRUMB_FILE, "r", encoding="utf-8") as fh:
            lines = fh.read().splitlines()
    except (IOError, OSError):
        return None
    if len(lines) < 2:
        return None
    installed_at, stored_checksum = lines[0].strip(), lines[1].strip()
    if not (installed_at and stored_checksum):
        return None
    machine_id = _compute_machine_id()
    try:
        expected = _compute_checksum(installed_at, machine_id)
    except Exception:
        return None
    if not hmac.compare_digest(stored_checksum, expected):
        logger.warning("Trial breadcrumb HMAC mismatch — ignoring layer 2")
        return None
    return installed_at


# ===========================================================================
# Layer 3 — trial_activated audit log entry
# ===========================================================================
def _write_layer3_audit(installed_at: str) -> bool:
    """Append trial_activated event to session.jsonl. Never raises."""
    try:
        AUDIT_LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        event = {
            "type":    "trial_activated",
            "ts":      installed_at,
            "version": _VERSION,
        }
        with open(AUDIT_LOG_FILE, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(event) + "\n")
        return True
    except (IOError, OSError) as exc:
        logger.debug("trial_activated audit write failed: %s", exc)
        return False


def _read_layer3_audit() -> Optional[str]:
    """Scan session.jsonl for a trial_activated event. Cached after first hit.

    Performance guard: on a huge audit log (>10K lines), we stop scanning
    after 200 lines if we haven't found it — the entry is always written
    early in the log. Module-level cache means we never scan twice.
    """
    global _LAYER3_CACHE, _LAYER3_CACHE_FOUND
    if _LAYER3_CACHE_FOUND:
        return _LAYER3_CACHE
    if not AUDIT_LOG_FILE.exists():
        return None
    try:
        line_count = 0
        with open(AUDIT_LOG_FILE, "r", encoding="utf-8") as fh:
            for line in fh:
                line_count += 1
                if line_count > 200:
                    # Guard: if it's not near the top, it's probably not there.
                    break
                s = line.strip()
                if not s or '"trial_activated"' not in s:
                    continue
                try:
                    evt = json.loads(s)
                except json.JSONDecodeError:
                    continue
                if evt.get("type") == "trial_activated" and evt.get("ts"):
                    _LAYER3_CACHE = str(evt["ts"])
                    _LAYER3_CACHE_FOUND = True
                    return _LAYER3_CACHE
    except (IOError, OSError):
        return None
    _LAYER3_CACHE_FOUND = True  # remember we scanned and found nothing
    _LAYER3_CACHE = None
    return None


# ===========================================================================
# Main state machine
# ===========================================================================
def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _parse_iso(ts: str) -> Optional[datetime]:
    if not ts:
        return None
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None


def _compute_days_remaining(installed_at: str) -> int:
    """Days left in the trial. Negative = expired by N days."""
    start = _parse_iso(installed_at)
    if start is None:
        return -9999
    elapsed = datetime.now(timezone.utc) - start
    remaining = TRIAL_DAYS - int(elapsed.total_seconds() // 86400)
    return remaining


def get_license_state(force_refresh: bool = False) -> Dict[str, Any]:
    """Determine current license state.

    Returns a dict with keys:
        state:            "trial_active" | "trial_expired" | "licensed" | "trial_tampered"
        tier:             "trial" | "expired" | "starter" | "pro" | "enterprise"
        days_remaining:   int (-1 if licensed; negative if expired)
        installed_at:     ISO timestamp (empty string if licensed)
        machine_id:       sha256 fingerprint
        trial_tampered:   bool (True if anchor checksum failed AND no valid fallback)
        version:          the trial_clock module version

    Cached for _STATE_CACHE_TTL seconds. Pass force_refresh=True to bypass.
    """
    global _STATE_CACHE, _STATE_CACHE_TS
    now = time.time()
    if (not force_refresh) and _STATE_CACHE and (now - _STATE_CACHE_TS) < _STATE_CACHE_TTL:
        return dict(_STATE_CACHE)  # return a copy so callers can't mutate the cache

    state = _compute_state()
    _STATE_CACHE = state
    _STATE_CACHE_TS = now
    return dict(state)


def _compute_state() -> Dict[str, Any]:
    """Uncached state computation. Called by get_license_state()."""
    machine_id = _compute_machine_id()

    # Step 1 — license key bypasses trial
    license_key = os.environ.get("INSAITS_LICENSE_KEY", "").strip()
    if license_key:
        result = validate_license_key(license_key)
        if result.get("valid"):
            return {
                "state":           "licensed",
                "tier":            result.get("tier", "starter"),
                "days_remaining":  -1,
                "installed_at":    "",
                "machine_id":      machine_id,
                "trial_tampered":  False,
                "version":         _VERSION,
            }
        # Invalid / network fail: log and fall through to trial check.
        logger.warning("INSAITS_LICENSE_KEY present but validation failed: %s",
                       result.get("error", "unknown"))

    # Step 2-5 — read the 3 layers, repair missing ones
    anchor = _read_layer1()
    installed_at: Optional[str] = None
    tampered = False
    layer1_source = False

    if anchor:
        installed_at = str(anchor.get("installed_at") or "")
        layer1_source = bool(installed_at)
    if not layer1_source and TRIAL_ANCHOR_FILE.exists():
        # Layer 1 exists but checksum failed → mark tampered.
        tampered = True

    if not installed_at:
        layer2_ts = _read_layer2()
        if layer2_ts:
            installed_at = layer2_ts
            # Repair Layer 1
            _write_layer1(installed_at, machine_id)

    if not installed_at:
        layer3_ts = _read_layer3_audit()
        if layer3_ts:
            installed_at = layer3_ts
            # Repair Layers 1 + 2
            _write_layer1(installed_at, machine_id)
            _write_layer2(installed_at, machine_id)

    # Step 5 — all three missing: fresh install
    if not installed_at:
        if tampered:
            # Anchor existed but was corrupted AND no fallback — treat as expired
            return {
                "state":          "trial_tampered",
                "tier":           "expired",
                "days_remaining": 0,
                "installed_at":   "",
                "machine_id":     machine_id,
                "trial_tampered": True,
                "version":        _VERSION,
            }
        installed_at = _now_iso()
        _write_layer1(installed_at, machine_id)
        _write_layer2(installed_at, machine_id)
        _write_layer3_audit(installed_at)

    # Step 6 — compute days remaining
    days_remaining = _compute_days_remaining(installed_at)
    if days_remaining >= 0:
        return {
            "state":          "trial_active",
            "tier":           "trial",
            "days_remaining": days_remaining,
            "installed_at":   installed_at,
            "machine_id":     machine_id,
            "trial_tampered": False,
            "version":        _VERSION,
        }
    return {
        "state":          "trial_expired",
        "tier":           "expired",
        "days_remaining": days_remaining,  # negative = how many days past expiration
        "installed_at":   installed_at,
        "machine_id":     machine_id,
        "trial_tampered": False,
        "version":        _VERSION,
    }


# ===========================================================================
# License key validation (Phase C)
# ===========================================================================
def _api_base_url() -> str:
    return (os.environ.get("INSAITS_API_URL") or _DEFAULT_API_URL).rstrip("/")


def _read_license_cache() -> Optional[Dict[str, Any]]:
    if not _LICENSE_CACHE_PATH.exists():
        return None
    try:
        with open(_LICENSE_CACHE_PATH, "r", encoding="utf-8") as fh:
            doc = json.load(fh)
    except (IOError, OSError, json.JSONDecodeError):
        return None
    vu = _parse_iso(doc.get("valid_until", ""))
    if not vu or vu < datetime.now(timezone.utc):
        return None
    return doc


def _write_license_cache(tier: str, email: str, key_id: str) -> None:
    """Only called on SUCCESSFUL validation. Never caches failures."""
    try:
        TRIAL_ANCHOR_DIR.mkdir(parents=True, exist_ok=True)
        now = datetime.now(timezone.utc)
        doc = {
            "tier":         tier,
            "email":        email,
            "key_id":       key_id,
            "validated_at": now.isoformat(),
            "valid_until":  (now + timedelta(hours=_LICENSE_CACHE_TTL_HOURS)).isoformat(),
        }
        with open(_LICENSE_CACHE_PATH, "w", encoding="utf-8") as fh:
            json.dump(doc, fh, indent=2)
    except (IOError, OSError):
        pass


def validate_license_key(key: str) -> Dict[str, Any]:
    """Validate a license key. Fallback chain: network → cache → invalid.

    Returns:
        {"valid": True,  "tier": "starter"|"pro"|"enterprise", "email": str, "id": str, "source": "api"|"cache"}
        {"valid": False, "error": str}
    """
    key = (key or "").strip()
    if not key:
        return {"valid": False, "error": "empty_key"}

    # Wire format matches /api/keys/validate (routers/auth.py::KeyValidateRequest).
    # Raw key is sent over TLS; the API hashes server-side with SHA-256 and
    # looks up the resulting hash in Supabase. Changing this field name silently
    # breaks paid-user validation — see test_validate_license_key_wire_contract.
    url = f"{_api_base_url()}/api/keys/validate"
    body = json.dumps({"api_key": key}).encode("utf-8")
    # key_hash kept for logging on the error path so we never write the raw key.
    key_hash = hashlib.sha256(key.encode("utf-8")).hexdigest()
    req = _urlreq.Request(
        url, data=body, method="POST",
        headers={"Content-Type": "application/json", "User-Agent": f"insa-its/{_VERSION}"},
    )
    # Two-shot retry so a Render cold-start (15-30s from sleep) doesn't lock
    # a first-time paid user into trial mode. Fast-fail on shot 1; shot 2
    # gives the server time to wake. HTTPError (a real 4xx/5xx response) is
    # not retried — the server answered, the answer just wasn't 200.
    attempts = (
        (_VALIDATE_TIMEOUT,       0.0),
        (_VALIDATE_RETRY_TIMEOUT, _VALIDATE_RETRY_DELAY),
    )
    last_exc: Optional[BaseException] = None
    for idx, (timeout, delay) in enumerate(attempts):
        if delay:
            time.sleep(delay)
        try:
            with _urlreq.urlopen(req, timeout=timeout) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
                payload = json.loads(raw)
            if payload.get("valid"):
                tier = payload.get("tier", "starter")
                email = payload.get("email", "")
                key_id = payload.get("id", "")
                _write_license_cache(tier, email, key_id)
                return {
                    "valid":  True,
                    "tier":   tier,
                    "email":  email,
                    "id":     key_id,
                    "source": "api",
                }
            return {"valid": False, "error": payload.get("message", "invalid")}
        except _urlerr.HTTPError as exc:
            # Real HTTP response (4xx/5xx) — server answered, don't retry.
            last_exc = exc
            break
        except (_urlerr.URLError, OSError, socket.timeout, json.JSONDecodeError) as exc:
            last_exc = exc
            if idx == 0:
                logger.info(
                    "License validate shot 1 failed (%s); retrying with longer timeout "
                    "— this is expected on a Render cold-start.", type(exc).__name__,
                )
            continue

    # Both shots exhausted — try disk cache.
    cached = _read_license_cache()
    if cached:
        return {
            "valid":  True,
            "tier":   cached.get("tier", "starter"),
            "email":  cached.get("email", ""),
            "id":     cached.get("key_id", ""),
            "source": "cache",
        }
    if last_exc is not None:
        logger.warning("License validation unreachable + no cache: %s (key_hash=%s...)",
                       last_exc, key_hash[:8])
        return {"valid": False, "error": f"unreachable: {type(last_exc).__name__}"}
    return {"valid": False, "error": "unreachable: unknown"}
