"""
insa_its.license — v4.5.0 trial clock + license validation.

Public API:
    get_license_state() -> dict
        Current state machine: trial_active / trial_expired / licensed / trial_tampered.

    validate_license_key(key) -> dict
        Validates a license key against the API. Used when INSAITS_LICENSE_KEY is set.

    TRIAL_DAYS:  int  — the trial duration (14).

Design notes:
    * stdlib-only. No torch / cryptography / sentence-transformers imports.
    * 3-layer anti-reset: trial_anchor.json + .trial_marker + audit event.
    * Fail-open on broken install (defaults to licensed/enterprise so
      dev-from-source is not blocked).
    * Cached state, <10ms on cache hit.
"""

from .trial_clock import (
    TRIAL_DAYS,
    get_license_state,
    validate_license_key,
)
from .validator import require_valid_license, TIER_FEATURES

# Bridge legacy LicenseManager API. The old single-file module
# `insa_its/license.py` was renamed to `_license_manager.py` so this package
# directory could exist without shadowing it. Both APIs coexist:
#   * trial_clock — v4.5.0 collector trial gate (stdlib-only)
#   * LicenseManager — SDK monitor tier gating (PBKDF2 + encrypted cache)
from .._license_manager import LicenseManager, get_license_manager

__all__ = [
    "TRIAL_DAYS",
    "get_license_state",
    "validate_license_key",
    "require_valid_license",
    "TIER_FEATURES",
    "LicenseManager",
    "get_license_manager",
]
