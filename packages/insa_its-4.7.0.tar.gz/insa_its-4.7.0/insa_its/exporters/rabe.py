"""Rogue Agent Behavioral Exporter (RABE) — Feature 3.

Exports confirmed anomalous sessions as structured behavioral signatures.
Captures the pre-catch window: what the agent looked like BEFORE the first
anomaly fired. This is the most analytically valuable data InsAIts produces.

Runs entirely on-demand via GET endpoint. Zero hook impact.
"""

from __future__ import annotations

import json
import math
import pathlib
from collections import Counter
from datetime import datetime, timezone
from typing import Any, Dict, List


EXCLUDED_TYPES = frozenset({
    "replay_detected", "anchor_injection", "anchor_injected",
    "task_anchor_injected", "session_resumed", "context_restored",
    "context_compression", "context_compression_detected", "milestone",
    "subagent_tool_call", "subagent_spawned", "subagent_complete",
    "acm_compression_cycle", "snapshot_saved", "response_awareness",
    "retry_budget_warning", "retry_budget_exceeded",
    "replay_rate_high", "loop_detected", "monitoring_gap_check",
    "retry_storm", "circuit_breaker", "storm_block",
    "emergency_save", "emergency_shutdown", "storm_block_released",
    "session_continued",
})


def export_rabe(
    session_id: str,
    audit_jsonl_path: str,
    output_path: str,
) -> Dict[str, Any]:
    """Extract behavioral signature from a confirmed rogue session.

    The pre_catch_window field contains everything InsAIts observed before
    the first real anomaly fired. This is the early warning signature.
    """
    # 1. Load all audit entries for this session
    entries: List[Dict[str, Any]] = []

    def _scan_jsonl(path: str) -> None:
        try:
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        e = json.loads(line)
                        sid = e.get("session_id") or e.get("claude_session_id", "")
                        if sid == session_id:
                            entries.append(e)
                    except json.JSONDecodeError:
                        continue
        except FileNotFoundError:
            pass

    # Try current audit log first
    _scan_jsonl(audit_jsonl_path)

    # If not found, scan archived session JSONLs
    if not entries:
        audit_dir = pathlib.Path(audit_jsonl_path).parent
        sessions_dir = audit_dir / ".insaits_sessions"
        if sessions_dir.is_dir():
            for archived in sorted(sessions_dir.glob("*.jsonl"), reverse=True):
                _scan_jsonl(str(archived))
                if entries:
                    break

    if not entries:
        return {"error": "session_not_found", "session_id": session_id}

    # 2. Find first real anomaly (exclude guardian meta-events)
    first_anomaly_idx = None
    first_anomaly_type = None
    for i, entry in enumerate(entries):
        for a in entry.get("anomalies", []):
            if a.get("type") not in EXCLUDED_TYPES:
                first_anomaly_idx = i
                first_anomaly_type = a.get("type")
                break
        if first_anomaly_idx is not None:
            break

    if first_anomaly_idx is None:
        return {
            "error": "no_real_anomalies_found",
            "session_id": session_id,
            "total_entries": len(entries),
        }

    # 3. Pre-catch window — entries BEFORE first anomaly
    pre_catch = entries[:first_anomaly_idx]
    tool_calls = [
        e for e in pre_catch
        if e.get("tool") not in EXCLUDED_TYPES
        and e.get("tool") is not None
    ]

    # Timing deltas between consecutive tool calls
    timestamps = [e.get("ts", e.get("timestamp", "")) for e in tool_calls if e.get("ts") or e.get("timestamp")]
    timing_deltas: List[float] = []
    for i in range(1, len(timestamps)):
        try:
            a = datetime.fromisoformat(timestamps[i - 1].replace("Z", "+00:00"))
            b = datetime.fromisoformat(timestamps[i].replace("Z", "+00:00"))
            timing_deltas.append(round((b - a).total_seconds(), 3))
        except Exception:
            pass

    # Path entropy
    paths: List[str] = []
    for e in tool_calls:
        inp = e.get("tool_input") or {}
        if isinstance(inp, str):
            try:
                inp = json.loads(inp)
            except (json.JSONDecodeError, TypeError):
                inp = {}
        p = (
            inp.get("file_path")
            or inp.get("path")
            or str(inp.get("command", ""))[:80]
        )
        paths.append(p or "")

    tokens = [p.replace("\\", "/").split("/")[-1] for p in paths if p]
    entropy = 0.0
    if tokens:
        counts = Counter(tokens)
        total = sum(counts.values())
        entropy = -sum(
            (c / total) * math.log2(c / total)
            for c in counts.values() if c > 0
        )

    # Semantic coherence
    coherence_values: List[float] = []
    for i in range(1, len(paths)):
        a_set, b_set = set(paths[i - 1]), set(paths[i])
        if a_set and b_set:
            union = len(a_set | b_set)
            if union > 0:
                coherence_values.append(len(a_set & b_set) / union)
    coherence = (
        sum(coherence_values) / len(coherence_values)
        if coherence_values else 1.0
    )

    # 4. Anomaly progression after first catch
    anomaly_progression: List[Dict[str, Any]] = []
    for i, entry in enumerate(entries[first_anomaly_idx:], start=first_anomaly_idx):
        for a in entry.get("anomalies", []):
            if a.get("type") not in EXCLUDED_TYPES:
                anomaly_progression.append({
                    "type": a["type"],
                    "severity": a.get("severity", "UNKNOWN"),
                    "message_idx": i,
                    "timestamp": entry.get("ts", entry.get("timestamp", "")),
                })

    # 5. Infer attacker objective from probe sequence
    credential_signals = sum(
        1 for p in paths
        if any(s in p.lower() for s in [
            ".env", "secret", "credential", "token",
            "api_key", ".key", "password", ".pem",
        ])
    )
    exfil_signals = sum(
        1 for e in entries
        if "shadow_server" in str(e.get("anomalies", []))
    )
    lateral_signals = sum(
        1 for e in entries
        if "agent_probing_pattern" in str(e.get("anomalies", []))
    )
    objectives = {
        "credential_harvest": credential_signals,
        "code_exfiltration": exfil_signals,
        "lateral_movement": lateral_signals,
    }
    top_objective = max(objectives, key=objectives.get)
    estimated_objective = (
        top_objective if max(objectives.values()) > 0 else "unknown"
    )

    # 6. Threat score
    threat_score = round(
        min(entropy * (1.0 - coherence) / 4.0, 1.0), 3
    )

    # 7. Assemble export
    export: Dict[str, Any] = {
        "rabe_version": "1.0",
        "session_id": session_id,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "catch_confirmed": True,
        "pre_catch_window": {
            "message_count": len(pre_catch),
            "tool_call_count": len(tool_calls),
            "timing_deltas": timing_deltas,
            "timing_mean_seconds": round(
                sum(timing_deltas) / len(timing_deltas), 3
            ) if timing_deltas else 0.0,
            "path_entropy": round(entropy, 4),
            "semantic_coherence": round(coherence, 4),
            "first_anomaly_fired": first_anomaly_type,
            "messages_before_first_anomaly": first_anomaly_idx,
        },
        "anomaly_progression": anomaly_progression,
        "anomaly_count_total": len(anomaly_progression),
        "estimated_objective": estimated_objective,
        "objective_signals": objectives,
        "threat_score": threat_score,
    }

    pathlib.Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(output_path).write_text(
        json.dumps(export, indent=2, default=str),
        encoding="utf-8",
    )
    return export
