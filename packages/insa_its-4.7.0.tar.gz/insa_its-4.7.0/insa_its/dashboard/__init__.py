"""
InsAIts Dashboard Package
=========================
Live TUI dashboard for InsAIts runtime monitoring.

Usage:
    python3 -m insa_its.dashboard.tui          # Watch audit log
    python3 -m insa_its.dashboard.tui --demo   # Demo mode with synthetic data

The canonical TUI lives at the API repo root (insaits_tui.py).
This package resolves to it dynamically.
"""

DASHBOARD_AVAILABLE = False
InsAItsDashboard = None

try:
    from .tui import InsAItsDashboard
    DASHBOARD_AVAILABLE = True
except ImportError:
    # tui.py may have been moved to API root — try loading from there
    try:
        import importlib.util
        import os
        sdk_root = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
        api_root = os.path.dirname(sdk_root)
        for candidate in [
            os.path.join(api_root, "insaits_tui.py"),
            os.path.join(sdk_root, "..", "insaits_tui.py"),
        ]:
            if os.path.isfile(candidate):
                spec = importlib.util.spec_from_file_location(
                    "insa_its.dashboard.tui", candidate
                )
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                InsAItsDashboard = getattr(mod, "InsAItsDashboard", None)
                if InsAItsDashboard:
                    DASHBOARD_AVAILABLE = True
                break
    except Exception:
        pass

__all__ = ["InsAItsDashboard", "DASHBOARD_AVAILABLE"]
