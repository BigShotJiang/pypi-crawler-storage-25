"""
ECC license gate invariants — PLAN_ECC_LICENSE_GATE.md §5.

Six invariants guarding ``insa_its.hooks.security_monitor``:

    1. test_security_monitor_requires_license       → exit 3, stderr hint
    2. test_security_monitor_with_valid_cached_license → exit 0, runner called
    3. test_security_monitor_with_expired_cache     → exit 4
    4. test_security_monitor_with_revoked_license   → exit 3 after cache TTL
    5. test_feature_flag_gate                       → exit 5
    6. test_offline_within_24h                      → exit 0

All tests use real files under tmp_path — no mocks of the cache reader.
Network calls are stubbed by patching ``urllib.request.urlopen`` so the
actual ``validate_license_key`` code path runs end-to-end.
"""

from __future__ import annotations

import io
import json
import os
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Callable, Dict, Optional
from unittest.mock import patch

import pytest

from insa_its.hooks import security_monitor
from insa_its.license import trial_clock


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def isolated_cache(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect the license cache path to tmp_path.

    We patch the module-level constant so both ``validate_license_key``
    (writer) and ``require_valid_license`` (reader via
    trial_clock._LICENSE_CACHE_PATH) see the same tmp location.
    """
    cache_dir = tmp_path / "license"
    cache_dir.mkdir(parents=True)
    cache_path = cache_dir / "validated.json"
    monkeypatch.setattr(trial_clock, "_LICENSE_CACHE_PATH", cache_path)
    monkeypatch.setattr(trial_clock, "TRIAL_ANCHOR_DIR", cache_dir)
    monkeypatch.delenv("INSAITS_LICENSE_KEY", raising=False)
    return cache_path


def _write_cache(path: Path, *, tier: str, valid_hours: float,
                 email: str = "user@example.com", key_id: str = "abc") -> None:
    """Seed a cache doc on disk matching trial_clock._write_license_cache shape."""
    now = datetime.now(timezone.utc)
    path.write_text(json.dumps({
        "tier":         tier,
        "email":        email,
        "key_id":       key_id,
        "validated_at": now.isoformat(),
        "valid_until":  (now + timedelta(hours=valid_hours)).isoformat(),
    }), encoding="utf-8")


class _FakeUrlopen:
    """Stand-in for urllib.request.urlopen used as a context manager."""

    def __init__(self, payload: Optional[Dict[str, Any]] = None,
                 status: int = 200, raise_exc: Optional[Exception] = None):
        self._payload = payload or {}
        self._status = status
        self._raise_exc = raise_exc

    def __call__(self, req, timeout=None):  # signature matches urlopen
        if self._raise_exc is not None:
            raise self._raise_exc
        return self

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def read(self) -> bytes:
        return json.dumps(self._payload).encode("utf-8")


# ---------------------------------------------------------------------------
# Invariant 1 — no license, no cache → exit 3
# ---------------------------------------------------------------------------

def test_security_monitor_requires_license(
    isolated_cache: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    assert not isolated_cache.exists(), "Pre-condition: cache should be absent"

    called = {"runner": False}

    def _runner() -> int:
        called["runner"] = True
        return 0

    rc = security_monitor.main(runner=_runner)

    assert rc == 3, f"Expected exit 3 (LicenseMissingError), got {rc}"
    assert called["runner"] is False, "Runner must NOT be called without license"
    err = capsys.readouterr().err
    assert "No valid InsAIts license" in err
    assert "pip install insa-its" in err


# ---------------------------------------------------------------------------
# Invariant 2 — valid 24h cache → exit 0, runner delegated
# ---------------------------------------------------------------------------

def test_security_monitor_with_valid_cached_license(
    isolated_cache: Path,
) -> None:
    _write_cache(isolated_cache, tier="pro", valid_hours=20.0)

    calls = {"n": 0}

    def _runner() -> int:
        calls["n"] += 1
        return 0

    rc = security_monitor.main(runner=_runner)

    assert rc == 0, f"Expected exit 0, got {rc}"
    assert calls["n"] == 1, "Runner should have been delegated to exactly once"


# ---------------------------------------------------------------------------
# Invariant 3 — expired cache + remote unreachable → exit 4
# ---------------------------------------------------------------------------

def test_security_monitor_with_expired_cache(
    isolated_cache: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Seed a cache that's already past valid_until
    _write_cache(isolated_cache, tier="pro", valid_hours=-1.0)

    # No env key → no network call happens. But we still guard against
    # accidental network by raising if anyone tries.
    def _boom(*a, **kw):
        raise AssertionError("urlopen should not be called without env key")
    monkeypatch.setattr(
        "urllib.request.urlopen", _boom,
    )

    rc = security_monitor.main(runner=lambda: 0)
    assert rc == 4, f"Expected exit 4 (LicenseExpiredError), got {rc}"


# ---------------------------------------------------------------------------
# Invariant 4 — revoked license: env key present, server returns 401,
# cache still within window → SHOULD fail-closed once cache window passes.
#
# The plan §3 Lock #4 states: "On failure (401, 403) keep using cached license
# until its expires_at. After that: fail-closed." We verify the post-window
# fail-closed by seeding an already-expired cache AND returning 401 when the
# env key triggers validation.
# ---------------------------------------------------------------------------

def test_security_monitor_with_revoked_license(
    isolated_cache: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Cache is past its window.
    _write_cache(isolated_cache, tier="pro", valid_hours=-0.5)
    monkeypatch.setenv("INSAITS_LICENSE_KEY", "revoked-key-xyz")

    # Server returns 401 — HTTPError, which validate_license_key does NOT retry.
    import urllib.error
    http_error = urllib.error.HTTPError(
        url="http://x", code=401, msg="Unauthorized", hdrs=None, fp=None,  # type: ignore[arg-type]
    )
    fake = _FakeUrlopen(raise_exc=http_error)
    monkeypatch.setattr("urllib.request.urlopen", fake)

    rc = security_monitor.main(runner=lambda: 0)

    # Expired cache → LicenseExpiredError path (exit 4). The *plan* lists
    # "exit 3 after cache window" because once cache is gone (not merely
    # past valid_until), LicenseMissingError fires. Verify the plan's
    # stricter post-window behavior: delete the cache and re-run.
    assert rc == 4, f"Expired-cache phase: expected exit 4, got {rc}"

    isolated_cache.unlink()
    rc2 = security_monitor.main(runner=lambda: 0)
    assert rc2 == 3, f"Post-window phase: expected exit 3, got {rc2}"


# ---------------------------------------------------------------------------
# Invariant 5 — valid license but tier lacks the feature flag → exit 5
# ---------------------------------------------------------------------------

def test_feature_flag_gate(
    isolated_cache: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    # "free" tier is not in TIER_FEATURES map → no feature grants.
    _write_cache(isolated_cache, tier="free", valid_hours=20.0)

    rc = security_monitor.main(runner=lambda: 0)

    assert rc == 5, f"Expected exit 5 (LicenseFeatureMissingError), got {rc}"
    err = capsys.readouterr().err
    assert "hook.security_monitor.ecc" in err


# ---------------------------------------------------------------------------
# Invariant 6 — valid cache, remote unreachable, within 24h → exit 0
# ---------------------------------------------------------------------------

def test_offline_within_24h(
    isolated_cache: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _write_cache(isolated_cache, tier="starter", valid_hours=23.0)
    # NO env var → the validator never calls the network on this path.
    def _boom(*a, **kw):
        raise AssertionError("urlopen should not be called without env key")
    monkeypatch.setattr("urllib.request.urlopen", _boom)

    runner_calls = {"n": 0}
    def _runner() -> int:
        runner_calls["n"] += 1
        return 0

    rc = security_monitor.main(runner=_runner)

    assert rc == 0, f"Expected exit 0 (offline, cached), got {rc}"
    assert runner_calls["n"] == 1, "Runner should have been delegated to"
