"""Tests for the Compressed Anchor Dialect (C1 Design B).

Covers:
- Canonical entity codes + DICT line format (PLAN1.md lines 618-621).
- Phrase substitutions round-trip (compress -> expand).
- Parser handles both pipe (Design B) and comma (legacy Design A) separators.
- CRITICAL markers bypass compression.
- Numbers and identifiers preserved through compress.
- Word-boundary / non-word token safety in the expander.
- Session-specific DICT overrides built-in ENTITY_CODES.
- extract_and_expand strips the leading DICT line but preserves body text.
"""

from __future__ import annotations

from insa_its.anchor import dialect


# ---------------------------------------------------------------------------
# Canonical definition
# ---------------------------------------------------------------------------

class TestCanonicalDefinition:
    def test_entity_codes_match_plan1_spec(self):
        # PLAN1.md line 604-606:
        #   R=Read/Grep  E=Edit/Write  B=Bash  AG=AgentSpawn
        #   SA=Subagent  TC=ToolCall#  AN=Anomaly  SID=SessionID
        assert dialect.ENTITY_CODES["R"] == "Read/Grep"
        assert dialect.ENTITY_CODES["E"] == "Edit/Write"
        assert dialect.ENTITY_CODES["B"] == "Bash"
        assert dialect.ENTITY_CODES["AG"] == "AgentSpawn"
        assert dialect.ENTITY_CODES["SA"] == "Subagent"
        assert dialect.ENTITY_CODES["TC"] == "ToolCall#"
        assert dialect.ENTITY_CODES["AN"] == "Anomaly"
        assert dialect.ENTITY_CODES["SID"] == "SessionID"

    def test_state_prefixes_complete(self):
        # PLAN1.md line 601
        expected = {
            "THINK", "RULE", "STAT", "ALERT",
            "OK", "WARN", "CRIT", "ACTION",
        }
        assert set(dialect.STATE_PREFIXES) == expected

    def test_symbols_include_arrow_and_ne(self):
        # PLAN1.md line 602
        for sym in ("→", "≥", "≠", "|", "!", "?"):
            assert sym in dialect.SYMBOLS

    def test_phrase_substitutions_from_plan1(self):
        # A representative subset from PLAN1.md lines 651-661
        pairs = dict(dialect.PHRASE_SUBSTITUTIONS)
        assert pairs["Plan before code."] == "plan→code"
        assert pairs["Verify before done."] == "verify→done"
        assert pairs["Root cause only."] == "root-cause-only"
        assert pairs["Go deep. Never superficial."] == "deep≠superficial"


# ---------------------------------------------------------------------------
# DICT: line emission
# ---------------------------------------------------------------------------

class TestDictLine:
    def test_starts_with_dict_prefix(self):
        assert dialect.dict_line().startswith("DICT:")

    def test_pipe_separated(self):
        # Design B uses pipe separators (PLAN1.md line 619)
        line = dialect.dict_line()
        # First pair
        assert "R=Read/Grep" in line
        # Pipe, not comma
        assert "|" in line
        assert "R=Read/Grep|E=Edit/Write" in line

    def test_contains_all_entity_codes(self):
        line = dialect.dict_line()
        for key, value in dialect.ENTITY_CODES.items():
            assert f"{key}={value}" in line


# ---------------------------------------------------------------------------
# Compress
# ---------------------------------------------------------------------------

class TestCompress:
    def test_compress_replaces_known_phrases(self):
        text = "Plan before code. Verify before done."
        out = dialect.compress(text)
        assert "plan→code" in out
        assert "verify→done" in out
        # originals gone
        assert "Plan before code." not in out

    def test_compress_case_insensitive(self):
        text = "plan before code. VERIFY BEFORE DONE."
        out = dialect.compress(text)
        assert "plan→code" in out
        assert "verify→done" in out

    def test_compress_preserves_numbers(self):
        text = "Plan before code. ratio=3.14 calls=42 anomalies=7"
        out = dialect.compress(text)
        assert "3.14" in out and "42" in out and "7" in out

    def test_compress_empty_string(self):
        assert dialect.compress("") == ""

    def test_compress_critical_marker_untouched(self):
        msg = "INSAITS SECURITY WARNING — Plan before code. Verify before done."
        assert dialect.compress(msg) == msg

    def test_compress_block_execution_marker_untouched(self):
        msg = "BLOCK EXECUTION — Plan before code."
        assert dialect.compress(msg) == msg

    def test_compress_short_source_compresses_freely(self):
        # Per PLAN1.md spec: the 60-char floor only triggers when the
        # SOURCE was long. Short sources compress freely because there's
        # nothing long to protect.
        short = "Plan before code."
        out = dialect.compress(short)
        assert "plan→code" in out

    def test_compress_long_source_below_floor_reverts(self):
        # Densely-compressible long source whose compressed form would
        # fall below MIN_COMPRESSED_CHARS reverts to the original.
        long_dense = (
            "Plan before code. Verify before done. "
            "Root cause only. status: nominal"
        )
        assert len(long_dense) > dialect.MIN_COMPRESSED_CHARS
        out = dialect.compress(long_dense)
        # If compressed form dropped below the floor, we keep the original
        if len(out) < dialect.MIN_COMPRESSED_CHARS:
            assert out == long_dense


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

class TestParseDictLine:
    def test_parses_pipe_separated(self):
        text = "DICT:R=Read/Grep|E=Edit/Write|B=Bash\n\nbody here"
        parsed = dialect.parse_dict_line(text)
        assert parsed == {"R": "Read/Grep", "E": "Edit/Write", "B": "Bash"}

    def test_parses_comma_separated_legacy(self):
        # Design A used commas.
        text = "DICT:§P=plan-first,§V=verify-before-done\nbody"
        parsed = dialect.parse_dict_line(text)
        assert parsed == {"§P": "plan-first", "§V": "verify-before-done"}

    def test_no_dict_line_returns_empty(self):
        assert dialect.parse_dict_line("no dict here") == {}

    def test_empty_text_returns_empty(self):
        assert dialect.parse_dict_line("") == {}

    def test_malformed_pairs_skipped(self):
        text = "DICT:R=Read/Grep|malformed|E=Edit/Write"
        parsed = dialect.parse_dict_line(text)
        assert parsed == {"R": "Read/Grep", "E": "Edit/Write"}

    def test_dict_line_not_at_start(self):
        text = "preamble line\nDICT:R=Read/Grep\nbody"
        parsed = dialect.parse_dict_line(text)
        assert parsed == {"R": "Read/Grep"}


# ---------------------------------------------------------------------------
# Expander
# ---------------------------------------------------------------------------

class TestExpandTokens:
    def test_expands_builtin_entity_codes(self):
        body = "Latest TC=17, AN=edit_without_read on SID=abc123"
        out = dialect.expand_tokens(body)
        assert "ToolCall#" in out
        assert "Anomaly" in out
        assert "SessionID" in out

    def test_respects_word_boundaries(self):
        # "R" inside "Read" should NOT expand
        body = "Read this file"
        out = dialect.expand_tokens(body)
        assert out == "Read this file"

    def test_respects_non_word_boundaries(self):
        # "R/E" should expand but "R/Edit" should not
        body = "R/E=3.2 — keep reading"
        out = dialect.expand_tokens(body)
        assert "ReadEditRatio" in out

    def test_session_dict_overrides_builtin(self):
        # If a session DICT rebinds R, expander honours it
        body = "R=CustomReader"
        out = dialect.expand_tokens(body, dict_map={"R": "CustomReader"})
        assert "CustomReader" in out

    def test_expand_phrases_reverses_compression(self):
        original = "Plan before code. Verify before done. Root cause only."
        compressed = dialect.compress(original)
        expanded = dialect.expand_tokens(
            compressed, include_extended=False,
        )
        assert "Plan before code." in expanded
        assert "Verify before done." in expanded
        assert "Root cause only." in expanded

    def test_include_phrases_flag_disables_phrase_reversal(self):
        compressed = "plan→code done"
        # With phrases off, the → symbol stays
        out = dialect.expand_tokens(compressed, include_phrases=False)
        assert "plan→code" in out

    def test_empty_string(self):
        assert dialect.expand_tokens("") == ""


# ---------------------------------------------------------------------------
# Round-trip — InsAIts SEES and UNDERSTANDS its own emission
# ---------------------------------------------------------------------------

class TestExtractAndExpand:
    def test_strips_dict_line_and_expands_body(self):
        emission = (
            dialect.dict_line()
            + "\n\n"
            + "TC=17 AN=edit_without_read SID=abc123"
        )
        expanded = dialect.extract_and_expand(emission)
        # DICT: leader is gone
        assert not expanded.startswith("DICT:")
        # Codes are expanded
        assert "ToolCall#" in expanded
        assert "Anomaly" in expanded
        assert "SessionID" in expanded

    def test_body_containing_literal_dict_survives(self):
        # Only the FIRST DICT line is stripped (the header). A later
        # reference to the literal string "DICT:" in the body must survive
        # so docs / examples round-trip cleanly.
        emission = (
            dialect.dict_line()
            + "\n\n"
            + "Example emission: DICT:R=Read/Grep is the header key line."
        )
        expanded = dialect.extract_and_expand(emission)
        assert "DICT:" in expanded  # the body reference survives

    def test_full_roundtrip_compress_then_expand(self):
        # Use a long source with enough surrounding prose that compression
        # stays above MIN_COMPRESSED_CHARS and the floor-guard doesn't
        # trigger a full revert.
        original = (
            "[CONTEXT BLOCK] session=abc123 tool_calls=42 "
            "rules: Plan before code. Verify before done. "
            "Signal status: nominal — ready for next tool call."
        )
        compressed = dialect.compress(original)
        assert compressed != original  # something substituted
        emission = dialect.dict_line() + "\n\n" + compressed
        expanded = dialect.extract_and_expand(emission)
        assert "Plan before code." in expanded
        assert "Verify before done." in expanded


# ---------------------------------------------------------------------------
# Integration with AnchorMessageBuilder — builder emits Design B DICT
# ---------------------------------------------------------------------------

class TestBuilderEmitsDesignB:
    def test_builder_dict_line_matches_canonical(self):
        from insa_its.anchor.message_builder import AnchorMessageBuilder
        assert AnchorMessageBuilder._dict_line() == dialect.dict_line()

    def test_builder_dialect_is_entity_codes(self):
        from insa_its.anchor.message_builder import AnchorMessageBuilder
        assert AnchorMessageBuilder._DIALECT == dict(dialect.ENTITY_CODES)

    def test_builder_compress_delegates_to_dialect(self):
        from insa_its.anchor.message_builder import AnchorMessageBuilder
        text = "Plan before code. Verify before done."
        assert AnchorMessageBuilder._compress_anchor(text) == dialect.compress(text)
