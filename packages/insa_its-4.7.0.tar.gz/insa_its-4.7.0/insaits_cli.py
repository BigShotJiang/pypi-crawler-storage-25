"""InsAIts CLI entry points — fast startup, no heavy SDK imports.

Delegates to ``insa_its.collector.main`` / ``insa_its.web.main``, which use
their own ``_find_*`` helpers to locate the canonical ``insaits_collector.py``
and ``insaits_web_dashboard.py`` at the API repo root.

The previous version of this file referenced ``collector/server.py`` and
``web/server.py`` inside the ``insa_its`` package, but those files never
existed — the console scripts were dead on arrival. This rewrite delegates
to the actual entry points already shipped in ``insa_its.collector.__init__``
and ``insa_its.web.__init__``.
"""


def collector():
    """Entry point for ``insaits-collector`` command."""
    from insa_its.collector import main as _main
    _main()


def dashboard():
    """Entry point for ``insaits-dashboard`` command."""
    from insa_its.web import main as _main
    _main()
