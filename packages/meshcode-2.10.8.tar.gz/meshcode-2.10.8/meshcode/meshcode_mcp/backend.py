"""Thin Supabase REST backend used by both the MCP server and tests.

Reuses the helpers from comms_v4.py without going through subprocess.
Zero deps beyond stdlib (urllib).
"""
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

# Bake in production defaults — RLS-protected publishable key, safe to ship.
_DEFAULT_SUPABASE_URL = "https://gjinagyyjttyxnaoavnz.supabase.co"
_DEFAULT_SUPABASE_KEY = "sb_publishable_qwN9PO1L7jUXhhbhhVk2CQ_z1FXG2Qf"

def _load_env_file() -> Dict[str, str]:
    env_path = Path.home() / ".meshcode" / "env"
    if not env_path.exists():
        return {}
    out: Dict[str, str] = {}
    try:
        for line in env_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line.startswith("export "):
                line = line[7:]
            if "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip().strip('"').strip("'")
    except Exception:
        pass
    return out

_env_file = _load_env_file()
SUPABASE_URL = os.environ.get("SUPABASE_URL") or _env_file.get("SUPABASE_URL") or _DEFAULT_SUPABASE_URL
SUPABASE_KEY = os.environ.get("SUPABASE_KEY") or _env_file.get("SUPABASE_KEY") or _DEFAULT_SUPABASE_KEY
SUPABASE_SERVICE_ROLE_KEY = (
    os.environ.get("SUPABASE_SERVICE_ROLE_KEY")
    or os.environ.get("SUPABASE_SECRET_KEY")
    or _env_file.get("SUPABASE_SERVICE_ROLE_KEY")
    or _env_file.get("SUPABASE_SECRET_KEY")
    or _env_file.get("NEW_SUPABASE_SECRET")
    or ""
)
SCHEMA = "meshcode"


def _now_iso() -> str:
    return datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S+00:00")


def _headers(*, prefer: Optional[str] = None, content_profile: bool = True) -> Dict[str, str]:
    h = {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Content-Type": "application/json",
    }
    if content_profile:
        h["Accept-Profile"] = SCHEMA
        h["Content-Profile"] = SCHEMA
    if prefer:
        h["Prefer"] = prefer
    return h


def _request(method: str, path: str, *, data: Any = None, prefer: Optional[str] = None) -> Any:
    url = f"{SUPABASE_URL}/rest/v1/{path}"
    body = json.dumps(data).encode("utf-8") if data else None
    req = Request(url, data=body, method=method, headers=_headers(prefer=prefer))
    try:
        with urlopen(req, timeout=10) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw) if raw.strip() else None
    except HTTPError as e:
        err = e.read().decode("utf-8", errors="replace")
        try:
            err_obj = json.loads(err)
            return {"_error": err_obj.get("message", err[:200]), "_code": e.code}
        except Exception:
            return {"_error": err[:200], "_code": e.code}
    except URLError as e:
        return {"_error": str(e.reason), "_code": 0}


def sb_select(table: str, filters: str = "", order: Optional[str] = None, limit: Optional[int] = None) -> List[Dict]:
    params = []
    if filters:
        params.append(filters)
    if order:
        params.append(f"order={order}")
    if limit:
        params.append(f"limit={limit}")
    path = f"{table}?{'&'.join(params)}" if params else table
    result = _request("GET", path)
    if isinstance(result, dict) and result.get("_error"):
        return []
    return result or []


def sb_insert(table: str, row: Dict, *, upsert: bool = False, on_conflict: Optional[str] = None) -> Any:
    prefer = "return=representation"
    if upsert:
        prefer += ",resolution=merge-duplicates"
    path = table
    if on_conflict:
        path += f"?on_conflict={on_conflict}"
    return _request("POST", path, data=row, prefer=prefer)


def sb_update(table: str, filters: str, updates: Dict) -> Any:
    return _request("PATCH", f"{table}?{filters}", data=updates, prefer="return=representation")


# Session recording config — set by MCP server at boot
_recording_enabled = False
_recording_api_key = ""
_recording_project_id = ""
_recording_agent_name = ""
_recording_session_id = ""

# RPCs that should NOT be recorded (internal/heartbeat/recording itself)
_SKIP_RECORDING = {"mc_heartbeat", "mc_record_event", "mc_agent_set_status_by_api_key",
                    "mc_acquire_agent_lease", "mc_release_agent_lease"}


def enable_recording(api_key: str, project_id: str, agent_name: str, session_id: str):
    """Called by MCP server at boot to enable session recording."""
    global _recording_enabled, _recording_api_key, _recording_project_id
    global _recording_agent_name, _recording_session_id
    _recording_enabled = True
    _recording_api_key = api_key
    _recording_project_id = project_id
    _recording_agent_name = agent_name
    _recording_session_id = session_id


def sb_rpc(fn_name: str, params: Dict) -> Any:
    url = f"{SUPABASE_URL}/rest/v1/rpc/{fn_name}"
    body = json.dumps(params).encode("utf-8")
    req = Request(url, data=body, method="POST", headers=_headers(content_profile=False))
    try:
        with urlopen(req, timeout=10) as resp:
            raw = resp.read().decode("utf-8")
            result = json.loads(raw) if raw.strip() else None
    except HTTPError as e:
        err = e.read().decode("utf-8", errors="replace")
        try:
            result = {"_error": json.loads(err).get("message", err[:200])}
        except Exception:
            result = {"_error": err[:200]}
        # Record errors too
        if _recording_enabled and fn_name not in _SKIP_RECORDING:
            _bg_record("error", {"rpc": fn_name, "error": str(err)[:200]})
        return result
    except URLError as e:
        return {"_error": str(e.reason)}

    # Auto-record tool calls to session events (hot-reloadable)
    if _recording_enabled and fn_name not in _SKIP_RECORDING:
        _bg_record("tool_call", {"rpc": fn_name})

    return result


def _bg_record(event_type: str, payload: dict):
    """Background-thread recording — never blocks the caller."""
    import threading
    def _do():
        try:
            sb_rpc_raw("mc_record_event", {
                "p_api_key": _recording_api_key,
                "p_project_id": _recording_project_id,
                "p_agent_name": _recording_agent_name,
                "p_session_id": _recording_session_id,
                "p_event_type": event_type,
                "p_payload": payload,
            })
        except Exception:
            pass
    threading.Thread(target=_do, daemon=True).start()


def sb_rpc_raw(fn_name: str, params: Dict) -> Any:
    """Raw RPC call without recording (to avoid infinite recursion)."""
    url = f"{SUPABASE_URL}/rest/v1/rpc/{fn_name}"
    body = json.dumps(params).encode("utf-8")
    req = Request(url, data=body, method="POST", headers=_headers(content_profile=False))
    try:
        with urlopen(req, timeout=10) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw) if raw.strip() else None
    except Exception:
        return None


# ============================================================
# Project + agent helpers
# ============================================================

def get_project_id(project_name: str) -> Optional[str]:
    rows = sb_select("mc_projects", f"name=eq.{quote(project_name)}")
    if rows:
        return rows[0]["id"]
    result = sb_insert("mc_projects", {"name": project_name})
    if isinstance(result, list) and result:
        return result[0]["id"]
    return None


def register_agent(project: str, name: str, role: str = "", api_key: Optional[str] = None) -> Dict:
    project_id = get_project_id(project)
    if not project_id:
        # Fallback: many spawn paths (setup_clients.py) bake the project
        # uuid into the env so we can register even when the name lookup
        # fails (RLS, schema cache, network blip, anon-key visibility).
        env_pid = os.environ.get("MESHCODE_PROJECT_ID", "").strip()
        if env_pid:
            project_id = env_pid
    if not project_id:
        return {"error": f"Project '{project}' not found"}

    params = {
        "p_project_id": project_id,
        "p_name": name,
        "p_role": role,
        "p_status": "online",
    }
    if api_key:
        params["p_api_key"] = api_key
    result = sb_rpc("mc_register_agent", params)

    if not result or (isinstance(result, dict) and result.get("error")):
        return result or {"error": "Failed to register agent"}

    sb_update("mc_agents",
              f"project_id=eq.{project_id}&name=eq.{quote(name)}",
              {"task": role, "last_heartbeat": _now_iso()})

    return {
        "registered": True,
        "project_id": project_id,
        "agent_name": name,
        "agent_id": result.get("agent_id") if isinstance(result, dict) else None,
    }


def send_message(project_id: str, from_agent: str, to_agent: str, payload: Any, msg_type: str = "msg", parent_msg_id: Optional[str] = None, sensitive: bool = False, api_key: Optional[str] = None, encrypted: bool = False) -> Dict:
    if not isinstance(payload, dict):
        payload = {"text": str(payload)}

    # Encrypt payload if requested
    actual_encrypted = False
    if encrypted and api_key:
        mesh_key = get_mesh_key(api_key, project_id)
        if mesh_key:
            encrypted_data = encrypt_payload(payload, mesh_key, aad=project_id)
            payload = {"_encrypted": encrypted_data, "_aad": project_id}
            actual_encrypted = True

    # Use validated SECURITY DEFINER RPC when api_key is provided
    if api_key:
        params = {
            "p_api_key": api_key,
            "p_project_id": project_id,
            "p_from_agent": from_agent,
            "p_to_agent": to_agent,
            "p_payload": payload,
            "p_type": msg_type,
        }
        if parent_msg_id:
            params["p_parent_msg_id"] = parent_msg_id
        if sensitive or actual_encrypted:
            params["p_sensitive"] = True
        result = sb_rpc("mc_send_message", params)
        # If RPC succeeded, return
        if isinstance(result, dict) and result.get("ok"):
            out = {"sent": True, "msg_id": result.get("msg_id")}
            if actual_encrypted:
                out["encrypted"] = True
            return out
        # If RPC returned an error, propagate it — do NOT fall through to
        # direct insert (RLS blocks anon INSERT since migration 089).
        if isinstance(result, dict) and result.get("error"):
            return {"error": result["error"]}
        # RPC returned unexpected shape but didn't error — treat as success
        if result is not None:
            return {"sent": True}

    # Fallback: direct insert — ONLY for tests or legacy (no api_key)
    if api_key:
        # api_key was provided but RPC path didn't return — should not happen
        return {"error": "mc_send_message RPC unavailable and direct insert blocked by RLS"}
    msg = {
        "project_id": project_id,
        "from_agent": from_agent,
        "to_agent": to_agent,
        "type": msg_type,
        "payload": payload,
        "read": False,
    }
    if parent_msg_id:
        msg["parent_msg_id"] = parent_msg_id
    if sensitive:
        msg["is_sensitive"] = True
    result = sb_insert("mc_messages", msg)
    if isinstance(result, dict) and result.get("_error"):
        return {"error": result["_error"]}
    if isinstance(result, list) and result:
        return {"sent": True, "msg_id": result[0].get("id")}
    return {"sent": True}


def read_inbox(project_id: str, agent: str, mark_read: bool = True, api_key: Optional[str] = None) -> List[Dict]:
    # Use SECURITY DEFINER RPC when api_key is available (bypasses RLS safely)
    if api_key:
        rpc_result = sb_rpc("mc_read_inbox", {
            "p_api_key": api_key,
            "p_project_id": project_id,
            "p_agent_name": agent,
            "p_mark_read": mark_read,
        })
        if isinstance(rpc_result, dict) and rpc_result.get("ok"):
            messages = rpc_result.get("messages", [])
            if isinstance(messages, list):
                # Auto-decrypt and ACK (mark_read already handled by RPC)
                mesh_key = None
                for m in messages:
                    p = m.get("payload")
                    if isinstance(p, dict) and "_encrypted" in p:
                        if mesh_key is None:
                            mesh_key = get_mesh_key(api_key, project_id)
                        if mesh_key:
                            msg_aad = p.get("_aad", project_id)
                            decrypted = decrypt_payload(p["_encrypted"], mesh_key, aad=msg_aad)
                            if decrypted is not None:
                                m["payload"] = decrypted
                                m["_was_encrypted"] = True
                if mark_read and messages:
                    import datetime as _dt
                    now = _dt.datetime.now(_dt.timezone.utc)
                    def _is_stale_rpc(m):
                        ts = m.get("created_at")
                        if not ts:
                            return True
                        try:
                            dt = _dt.datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
                            return (now - dt).total_seconds() > 60
                        except Exception:
                            return True
                    ack_targets = {
                        m.get("from_agent", "")
                        for m in messages
                        if m.get("type") not in ("ack", "broadcast") and _is_stale_rpc(m)
                    }
                    for sender in ack_targets:
                        if sender:
                            send_message(project_id, agent, sender,
                                         {"text": f"{agent} read your message"},
                                         msg_type="ack", api_key=api_key)
                return messages
        # If RPC doesn't exist yet, fall through to direct query

    # Fallback: direct SELECT (tests/legacy — requires anon RLS bypass)
    messages = sb_select(
        "mc_messages",
        f"project_id=eq.{project_id}&to_agent=eq.{quote(agent)}&read=eq.false",
        order="created_at.asc",
    )
    # Auto-decrypt encrypted messages
    if api_key and messages:
        mesh_key = None  # lazy-load
        for m in messages:
            p = m.get("payload")
            if isinstance(p, dict) and "_encrypted" in p:
                if mesh_key is None:
                    mesh_key = get_mesh_key(api_key, project_id)
                if mesh_key:
                    msg_aad = p.get("_aad", project_id)
                    decrypted = decrypt_payload(p["_encrypted"], mesh_key, aad=msg_aad)
                    if decrypted is not None:
                        m["payload"] = decrypted
                        m["_was_encrypted"] = True
    if mark_read and messages:
        for m in messages:
            marked = False
            if api_key:
                result = sb_rpc("mc_mark_message_read", {
                    "p_api_key": api_key,
                    "p_project_id": project_id,
                    "p_message_id": m["id"],
                })
                # If RPC succeeded, skip direct update
                if isinstance(result, dict) and result.get("ok"):
                    marked = True
            if not marked and not api_key:
                # Only attempt direct update when no api_key (tests/legacy).
                # With api_key, RLS blocks anon UPDATE since migration 089.
                sb_update("mc_messages", f"id=eq.{m['id']}", {"read": True})

        # Auto-ACK senders — but ONLY for messages older than 60s. If the
        # message was sent recently, the sender is very likely still inside
        # a meshcode_wait call that already returned the message via the
        # realtime path; an extra "you got it" ack row is pure noise that
        # spams the dashboard and the sender's inbox.
        import datetime as _dt
        now = _dt.datetime.now(_dt.timezone.utc)
        def _is_stale(m):
            ts = m.get("created_at")
            if not ts:
                return True
            try:
                dt = _dt.datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
                return (now - dt).total_seconds() > 60
            except Exception:
                return True
        ack_targets = {
            m["from_agent"]
            for m in messages
            if m.get("type") not in ("ack", "broadcast") and _is_stale(m)
        }
        for sender in ack_targets:
            send_message(project_id, agent, sender,
                         {"text": f"{agent} read your message"},
                         msg_type="ack", api_key=api_key)
    return messages


def count_pending(project_id: str, agent: str, api_key: Optional[str] = None) -> int:
    # Use SECURITY DEFINER RPC when api_key is available
    if api_key:
        result = sb_rpc("mc_count_pending", {
            "p_api_key": api_key,
            "p_project_id": project_id,
            "p_agent_name": agent,
        })
        if isinstance(result, dict) and result.get("ok"):
            return result.get("count", 0)
        # Fall through to direct query if RPC doesn't exist yet

    # Fallback: direct SELECT (tests/legacy)
    pending = sb_select(
        "mc_messages",
        f"project_id=eq.{project_id}&to_agent=eq.{quote(agent)}&read=eq.false&type=neq.ack",
        limit=1000,
    )
    return len(pending)


# ============================================================
# Encryption helpers for sensitive mesh messages
# ============================================================

_mesh_key_cache: Dict[str, str] = {}  # project_id -> hex key


def get_mesh_key(api_key: str, project_id: str) -> Optional[str]:
    """Retrieve the per-meshwork encryption key (hex-encoded AES-256 key)."""
    if project_id in _mesh_key_cache:
        return _mesh_key_cache[project_id]
    result = sb_rpc("mc_get_mesh_key", {
        "p_api_key": api_key,
        "p_project_id": project_id,
    })
    if isinstance(result, dict) and result.get("ok"):
        key = result["key"]
        _mesh_key_cache[project_id] = key
        return key
    return None


def encrypt_payload(payload: Dict, hex_key: str, aad: Optional[str] = None) -> str:
    """Encrypt a JSON payload using AES-256-GCM with optional AAD.

    Args:
        payload: JSON-serializable dict to encrypt.
        hex_key: Hex-encoded AES-256 key.
        aad: Additional Authenticated Data (e.g. project_id) to bind
             ciphertext to context and prevent replay/swap attacks.
    """
    import base64
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError:
        raise RuntimeError("cryptography package required for encrypted messages: pip install cryptography")
    key = bytes.fromhex(hex_key)
    nonce = os.urandom(12)  # 96-bit nonce for GCM
    plaintext = json.dumps(payload).encode("utf-8")
    aad_bytes = aad.encode("utf-8") if aad else None
    aesgcm = AESGCM(key)
    ciphertext = aesgcm.encrypt(nonce, plaintext, aad_bytes)
    # Format: base64(nonce + ciphertext)
    return base64.b64encode(nonce + ciphertext).decode("ascii")


def decrypt_payload(encrypted_b64: str, hex_key: str, aad: Optional[str] = None) -> Optional[Dict]:
    """Decrypt an AES-256-GCM encrypted payload. Returns None on failure.

    Tries with AAD first, falls back to no-AAD for backward compat
    with messages encrypted before AAD was added.
    """
    import base64
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError:
        return None
    try:
        key = bytes.fromhex(hex_key)
        raw = base64.b64decode(encrypted_b64)
        nonce = raw[:12]
        ciphertext = raw[12:]
        aesgcm = AESGCM(key)
        aad_bytes = aad.encode("utf-8") if aad else None
        # Try with AAD first
        if aad_bytes:
            try:
                plaintext = aesgcm.decrypt(nonce, ciphertext, aad_bytes)
                return json.loads(plaintext.decode("utf-8"))
            except Exception:
                pass  # Fall through to no-AAD for backward compat
        # Try without AAD (legacy messages)
        plaintext = aesgcm.decrypt(nonce, ciphertext, None)
        return json.loads(plaintext.decode("utf-8"))
    except Exception:
        return None


def get_board(project_id: str) -> List[Dict]:
    return sb_select("mc_agents", f"project_id=eq.{project_id}", order="registered_at.asc")


def heartbeat(project_id: str, agent: str) -> Dict:
    result = sb_rpc("mc_heartbeat", {"p_project_id": project_id, "p_agent_name": agent})
    return result or {}


def set_status(project_id: str, agent: str, status: str, task: str = "", api_key: Optional[str] = None) -> Dict:
    # Use SECURITY DEFINER RPC when api_key is available (anon PATCH silently fails)
    if api_key:
        rpc_result = sb_rpc("mc_agent_set_status_by_api_key", {
            "p_api_key": api_key,
            "p_project_id": project_id,
            "p_agent_name": agent,
            "p_status": status,
            "p_task": task,
        })
        if isinstance(rpc_result, dict) and rpc_result.get("ok"):
            return {"ok": True, "status": status}
        # Fall through to direct PATCH if RPC doesn't exist yet

    # Fallback: direct PATCH (may silently fail with anon key if RLS blocks)
    updates = {"status": status, "last_heartbeat": _now_iso()}
    if task:
        updates["task"] = task
    result = sb_update("mc_agents", f"project_id=eq.{project_id}&name=eq.{quote(agent)}", updates)
    if isinstance(result, dict) and result.get("_error"):
        return {"error": result["_error"]}
    return {"ok": True, "status": status}


def task_create(api_key, project_id, creator_agent, title, description="", assignee="*", priority="normal", parent_task_id=None):
    return sb_rpc("mc_task_create", {
        "p_api_key": api_key,
        "p_project_id": project_id,
        "p_creator_agent": creator_agent,
        "p_title": title,
        "p_description": description,
        "p_assignee": assignee,
        "p_priority": priority,
        "p_parent_task_id": parent_task_id,
    })


def task_list(api_key, project_id, agent, status_filter=None, include_done=False):
    return sb_rpc("mc_task_list", {
        "p_api_key": api_key,
        "p_project_id": project_id,
        "p_agent": agent,
        "p_status_filter": status_filter,
        "p_include_done": include_done,
    })


def task_claim(api_key, project_id, task_id, claiming_agent):
    return sb_rpc("mc_task_claim", {
        "p_api_key": api_key,
        "p_project_id": project_id,
        "p_task_id": task_id,
        "p_claiming_agent": claiming_agent,
    })


def task_complete(api_key, project_id, task_id, completing_agent, summary=""):
    return sb_rpc("mc_task_complete", {
        "p_api_key": api_key,
        "p_project_id": project_id,
        "p_task_id": task_id,
        "p_completing_agent": completing_agent,
        "p_summary": summary,
    })


def record_event(api_key, project_id, agent_name, session_id, event_type, payload=None):
    """Fire-and-forget event recording for session replay."""
    return sb_rpc("mc_record_event", {
        "p_api_key": api_key,
        "p_project_id": project_id,
        "p_agent_name": agent_name,
        "p_session_id": session_id,
        "p_event_type": event_type,
        "p_payload": payload or {},
    })


def get_history(project_id: str, limit: int = 20, agent_filter: str = "", api_key: Optional[str] = None) -> List[Dict]:
    # Use SECURITY DEFINER RPC when api_key is available (bypasses RLS safely)
    if api_key:
        rpc_result = sb_rpc("mc_get_history", {
            "p_api_key": api_key,
            "p_project_id": project_id,
            "p_limit": limit,
            "p_agent_filter": agent_filter or None,
        })
        if isinstance(rpc_result, dict) and rpc_result.get("ok"):
            return rpc_result.get("messages", [])
        # Fall through to direct query if RPC doesn't exist yet

    # Fallback: direct SELECT (tests/legacy)
    filters = f"project_id=eq.{project_id}&type=neq.ack"
    if agent_filter:
        filters += f"&or=(from_agent.eq.{quote(agent_filter)},to_agent.eq.{quote(agent_filter)})"
    return sb_select(
        "mc_messages",
        filters,
        order="created_at.desc",
        limit=limit,
    )


def get_message_by_id(project_id: str, msg_id: str, api_key: Optional[str] = None) -> Optional[Dict]:
    # Use SECURITY DEFINER RPC when api_key is available (bypasses RLS safely)
    if api_key:
        rpc_result = sb_rpc("mc_get_message_by_id", {
            "p_api_key": api_key,
            "p_project_id": project_id,
            "p_msg_id": msg_id,
        })
        if isinstance(rpc_result, dict) and rpc_result.get("ok"):
            return rpc_result.get("message")
        if isinstance(rpc_result, dict) and rpc_result.get("error"):
            return None
        # Fall through to direct query if RPC doesn't exist yet

    # Fallback: direct SELECT (tests/legacy)
    results = sb_select(
        "mc_messages",
        f"project_id=eq.{project_id}&id=eq.{msg_id}",
        limit=1,
    )
    return results[0] if results else None
