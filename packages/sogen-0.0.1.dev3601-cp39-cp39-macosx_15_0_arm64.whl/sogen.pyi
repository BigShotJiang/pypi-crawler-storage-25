"""Sogen Python bindings"""

import enum
import pathlib
from typing import Optional

from . import windows as windows
from .windows import (
    ApiHooks as ApiHooks,
    Callbacks as Callbacks,
    Emulator as Emulator,
    Emulator as WindowsEmulator,
    Hook as Hook,
    Hooks as Hooks,
    MemoryManager as MemoryManager,
    ProcessContext as ProcessContext,
    Thread as Thread,
    create_application as create_application,
    create_empty as create_empty
)


class Backend(enum.Enum):
    unicorn = 0

    icicle = 1

    whp = 2

unicorn: Backend = Backend.unicorn

icicle: Backend = Backend.icicle

whp: Backend = Backend.whp

class MemoryPermission(enum.Enum):
    none = 0

    read = 1

    write = 2

    exec = 4

    read_write = 3

    all = 7

none: MemoryPermission = MemoryPermission.none

read: MemoryPermission = MemoryPermission.read

write: MemoryPermission = MemoryPermission.write

exec: MemoryPermission = MemoryPermission.exec

read_write: MemoryPermission = MemoryPermission.read_write

all: MemoryPermission = MemoryPermission.all

class MemoryRegionKind(enum.Enum):
    free = 0

    private_allocation = 1

    file_section_view = 2

    pagefile_section_view = 3

    section_image = 4

    mmio = 5

free: MemoryRegionKind = MemoryRegionKind.free

private_allocation: MemoryRegionKind = MemoryRegionKind.private_allocation

file_section_view: MemoryRegionKind = MemoryRegionKind.file_section_view

pagefile_section_view: MemoryRegionKind = MemoryRegionKind.pagefile_section_view

section_image: MemoryRegionKind = MemoryRegionKind.section_image

mmio: MemoryRegionKind = MemoryRegionKind.mmio

class MemoryViolationType(enum.Enum):
    unmapped = 0

    protection = 1

unmapped: MemoryViolationType = MemoryViolationType.unmapped

protection: MemoryViolationType = MemoryViolationType.protection

class Register(enum.Enum):
    invalid = 0

    rax = 35

    rbx = 37

    rcx = 38

    rdx = 40

    rsi = 43

    rdi = 39

    rbp = 36

    rsp = 44

    rip = 41

    r8 = 106

    r9 = 107

    r10 = 108

    r11 = 109

    r12 = 110

    r13 = 111

    r14 = 112

    r15 = 113

    eax = 19

    ebx = 21

    ecx = 22

    edx = 24

    esi = 29

    edi = 23

    ebp = 20

    esp = 30

    eip = 26

    eflags = 25

    rflags = 253

    cs = 11

    ss = 49

    ds = 17

    es = 28

    fs = 32

    gs = 33

    xmm0 = 122

    xmm1 = 123

    xmm2 = 124

    xmm3 = 125

    xmm4 = 126

    xmm5 = 127

    xmm6 = 128

    xmm7 = 129

    xmm8 = 130

    xmm9 = 131

    xmm10 = 132

    xmm11 = 133

    xmm12 = 134

    xmm13 = 135

    xmm14 = 136

    xmm15 = 137

invalid: Instruction = Instruction.invalid

rax: Register = Register.rax

rbx: Register = Register.rbx

rcx: Register = Register.rcx

rdx: Register = Register.rdx

rsi: Register = Register.rsi

rdi: Register = Register.rdi

rbp: Register = Register.rbp

rsp: Register = Register.rsp

rip: Register = Register.rip

r8: Register = Register.r8

r9: Register = Register.r9

r10: Register = Register.r10

r11: Register = Register.r11

r12: Register = Register.r12

r13: Register = Register.r13

r14: Register = Register.r14

r15: Register = Register.r15

eax: Register = Register.eax

ebx: Register = Register.ebx

ecx: Register = Register.ecx

edx: Register = Register.edx

esi: Register = Register.esi

edi: Register = Register.edi

ebp: Register = Register.ebp

esp: Register = Register.esp

eip: Register = Register.eip

eflags: Register = Register.eflags

rflags: Register = Register.rflags

cs: Register = Register.cs

ss: Register = Register.ss

ds: Register = Register.ds

es: Register = Register.es

fs: Register = Register.fs

gs: Register = Register.gs

xmm0: Register = Register.xmm0

xmm1: Register = Register.xmm1

xmm2: Register = Register.xmm2

xmm3: Register = Register.xmm3

xmm4: Register = Register.xmm4

xmm5: Register = Register.xmm5

xmm6: Register = Register.xmm6

xmm7: Register = Register.xmm7

xmm8: Register = Register.xmm8

xmm9: Register = Register.xmm9

xmm10: Register = Register.xmm10

xmm11: Register = Register.xmm11

xmm12: Register = Register.xmm12

xmm13: Register = Register.xmm13

xmm14: Register = Register.xmm14

xmm15: Register = Register.xmm15

class MemoryStats:
    @property
    def reserved_memory(self) -> int: ...

    @property
    def committed_memory(self) -> int: ...

class Handle:
    def __init__(self) -> None: ...

    @property
    def bits(self) -> int: ...

    @bits.setter
    def bits(self, arg: int, /) -> None: ...

    @property
    def id(self) -> int: ...

    @property
    def type(self) -> int: ...

    @property
    def is_system(self) -> bool: ...

    @property
    def is_pseudo(self) -> bool: ...

    @property
    def high_bits(self) -> int: ...

class MemoryRegionInfo:
    @property
    def start(self) -> int: ...

    @property
    def length(self) -> int: ...

    @property
    def permissions(self) -> "nt_memory_permission": ...

    @property
    def allocation_base(self) -> int: ...

    @property
    def allocation_length(self) -> int: ...

    @property
    def is_reserved(self) -> bool: ...

    @property
    def is_committed(self) -> bool: ...

    @property
    def initial_permissions(self) -> "nt_memory_permission": ...

    @property
    def kind(self) -> MemoryRegionKind: ...

class HookContinuation(enum.Enum):
    run = 0

    skip = 1

run: HookContinuation = HookContinuation.run

skip: HookContinuation = HookContinuation.skip

class MemoryViolationContinuation(enum.Enum):
    stop = 0

    resume = 1

    restart = 2

stop: MemoryViolationContinuation = MemoryViolationContinuation.stop

resume: MemoryViolationContinuation = MemoryViolationContinuation.resume

restart: MemoryViolationContinuation = MemoryViolationContinuation.restart

class Instruction(enum.Enum):
    invalid = 0

    syscall = 1

    cpuid = 2

    rdtsc = 3

    rdtscp = 4

syscall: CallingConvention = CallingConvention.syscall

cpuid: Instruction = Instruction.cpuid

rdtsc: Instruction = Instruction.rdtsc

rdtscp: Instruction = Instruction.rdtscp

class CallingConvention(enum.Enum):
    cdecl = 0

    stdcall = 1

    fastcall = 2

    syscall = 3

cdecl: CallingConvention = CallingConvention.cdecl

stdcall: CallingConvention = CallingConvention.stdcall

fastcall: CallingConvention = CallingConvention.fastcall

class ApiContinuation(enum.Enum):
    run_original = 0

    intercept = 1

    skip = 1

run_original: ApiContinuation = ApiContinuation.run_original

intercept: ApiContinuation = ApiContinuation.intercept

class ApiCall:
    @property
    def module(self) -> str: ...

    @property
    def name(self) -> str: ...

    @property
    def address(self) -> int: ...

    @property
    def return_address(self) -> int: ...

    @property
    def return_value(self) -> int: ...

    @return_value.setter
    def return_value(self, arg: int, /) -> None: ...

class BasicBlock:
    @property
    def address(self) -> int: ...

    @property
    def instruction_count(self) -> int: ...

    @property
    def size(self) -> int: ...

class ExportedSymbol:
    @property
    def name(self) -> str: ...

    @property
    def ordinal(self) -> int: ...

    @property
    def rva(self) -> int: ...

    @property
    def address(self) -> int: ...

class MappedModule:
    @property
    def name(self) -> str: ...

    @property
    def path(self) -> pathlib.Path: ...

    @property
    def module_path(self) -> str: ...

    @property
    def image_base(self) -> int: ...

    @property
    def image_base_file(self) -> int: ...

    @property
    def size_of_image(self) -> int: ...

    @property
    def entry_point(self) -> int: ...

    @property
    def exports(self) -> list[ExportedSymbol]: ...

    @property
    def is_static(self) -> bool: ...

def api_call(cc: CallingConvention, params: Optional[object] = None, restype: Optional[object] = None) -> object: ...
