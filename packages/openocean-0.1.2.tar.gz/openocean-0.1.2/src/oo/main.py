def main():
    print("Hello from openocean!")


if __name__ == "__main__":
    main()
