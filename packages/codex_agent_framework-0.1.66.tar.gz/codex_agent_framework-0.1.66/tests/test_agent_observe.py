import json

import pytest

from codex_agent import Agent
from codex_agent.image import ImageMessage
from codex_agent.message import AssistantMessage


def test_agent_add_image_rejects_invalid_image_without_polluting_session():
    agent = Agent(session="new")
    initial_count = len(agent.session.messages)
    with pytest.raises(ValueError, match="Invalid or inaccessible image source"):
        agent.add_image("/tmp/definitely-missing-image.png")
    assert len(agent.session.messages) == initial_count


def test_builtin_observe_tool_accepts_multiple_sources(tmp_path):
    from PIL import Image

    image_one = tmp_path / "one.png"
    image_two = tmp_path / "two.png"
    Image.new("RGB", (1, 1), color="red").save(image_one)
    Image.new("RGB", (1, 1), color="green").save(image_two)

    agent = Agent(session="new", auto_proceed=False, builtin_plugins=["content"])
    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_observe",
        "name": "observe",
        "arguments": json.dumps({"sources": [
            {"target": "path", "path": str(image_one)},
            {"target": "path", "path": str(image_two)},
        ]}),
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert agent.session.messages[-1].call_id == "call_observe"
    assert "2 outputs in pending messages ids=" in agent.session.messages[-1].content
    observed = agent.mainloop_manager.pending[-2:]
    assert all(isinstance(image, ImageMessage) for image in observed)
    assert [image.content for image in observed] == [str(image_one), str(image_two)]
    assert [image.turns_left for image in observed] == [3, 3]


def test_builtin_observe_url_falls_back_to_page_screenshot(tmp_path, monkeypatch):
    from PIL import Image
    import codex_agent.builtin_plugins.content.vision as vision_tools

    screenshot_path = tmp_path / "page.png"
    Image.new("RGB", (1, 1), color="purple").save(screenshot_path)
    calls = []

    def fail_image_download(url):
        raise ValueError("URL did not resolve to an image")

    class FakeBrowserController:
        def capture_page_screenshot(self, url, path, **kwargs):
            calls.append((url, path, kwargs))
            return str(screenshot_path)

    monkeypatch.setattr(vision_tools, "persist_image_url", fail_image_download)
    monkeypatch.setattr(vision_tools, "get_browser_controller", lambda: FakeBrowserController(), raising=False)

    image = vision_tools.observe_source({"target": "url", "url": "https://example.com/page"})

    assert isinstance(image, ImageMessage)
    assert image.content == str(screenshot_path)
    assert image.image_name == "Screenshot of https://example.com/page"
    assert image.turns_left == 3
    assert image.is_valid()
    assert calls
    assert calls[0][0] == "https://example.com/page"
    assert calls[0][2]["full_page"] is True


def test_builtin_observe_accepts_screen_and_window_targets(tmp_path, monkeypatch):
    from PIL import Image
    import codex_agent.builtin_plugins.content.vision as vision_tools

    screen_path = tmp_path / "screen.png"
    window_path = tmp_path / "window.png"
    Image.new("RGB", (1, 1), color="black").save(screen_path)
    Image.new("RGB", (1, 1), color="white").save(window_path)

    screen_calls = []
    window_calls = []

    class FakeDesktopController:
        def capture_screen(self, output_path=None):
            screen_calls.append(output_path)
            return str(screen_path)

        def capture_window(self, window_id, output_path=None):
            window_calls.append((window_id, output_path))
            return str(window_path)

    monkeypatch.setattr(vision_tools, "get_desktop_controller", lambda: FakeDesktopController(), raising=False)

    observed = vision_tools.observe([
        {"target": "screen", "image_name": "desktop"},
        {"target": "window", "window_id": "0x123", "image_name": "app"},
    ])

    assert all(isinstance(image, ImageMessage) for image in observed)
    assert [image.content for image in observed] == [str(screen_path), str(window_path)]
    assert [image.image_name for image in observed] == ["desktop", "app"]
    assert [image.turns_left for image in observed] == [3, 3]
    assert screen_calls == [None]
    assert window_calls == [("0x123", None)]


def test_provider_image_message_keeps_image_message_type_and_wraps_description(tmp_path):
    from PIL import Image

    image_path = tmp_path / "provider.png"
    Image.new("RGB", (1, 1), color="red").save(image_path)
    original = ImageMessage(content=str(image_path), description="active tab screenshot")
    agent = Agent(session="new")

    @agent.add_provider(name="browser_state")
    def image_provider():
        return original

    messages = agent.context_manager.get_providers_messages()
    image_messages = [message for message in messages if isinstance(message, ImageMessage)]

    assert len(image_messages) == 1
    provided = image_messages[0]
    assert provided is not original
    assert provided.content == str(image_path)
    assert provided.description == '<context_provider name="browser_state">\nactive tab screenshot\n</context_provider>'
    assert provided.is_valid()
