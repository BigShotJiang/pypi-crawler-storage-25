import json
from types import SimpleNamespace

import codex_agent.utils as utils
from codex_agent import Agent, ResponseContentDeltaEvent
from codex_agent.message import AssistantMessage, MessageChunk, ServerToolResponseMessage


class FakeAI:
    def __init__(self, agent):
        self.agent = agent
        self.params = None

    def run(self, **params):
        self.params = params
        message = AssistantMessage(name="assistant")
        chunk = MessageChunk(content="hi")
        message.add_chunk(chunk)
        self.agent.emit(
            ResponseContentDeltaEvent,
            delta="hi",
            content="hi",
            chunk=chunk,
            message=message,
        )
        return message


class FakeCodexClient:
    def __init__(self, events):
        self.events = events
        self.kwargs = None
        self.responses = self
        self.codex = self

    def create(self, **kwargs):
        self.kwargs = kwargs
        return iter(self.events)

    def usage(self):
        return {
            "rate_limit": {
                "primary_window": {"used_percent": 11},
                "secondary_window": {"used_percent": 22},
            }
        }


def response_event(event_type, **payload):
    return SimpleNamespace(type=event_type, **payload)


def output_item_event(item):
    return response_event("response.output_item.done", item=item)


class FakeImageAI:
    def __init__(self, agent, item=None):
        self.agent = agent
        self.params = None
        self.item = item or {
            "type": "image_generation_call",
            "id": "ig_123",
            "result": "Zm9v",
        }

    def run(self, **params):
        self.params = params
        message = AssistantMessage(name="assistant")
        message.add_chunk(MessageChunk(output_items=[self.item]))
        return message


def test_agent_applies_image_generation_tool_config():
    agent = Agent(
        session="new",
        builtin_plugins=["image_generation"],
        image_generation_size="1024x1024",
        image_generation_quality="low",
        image_generation_background="opaque",
        image_generation_moderation="low",
    )
    agent.ai = FakeAI(agent)

    agent.get_response()

    assert {
        "type": "image_generation",
        "output_format": "png",
        "size": "1024x1024",
        "quality": "low",
        "background": "opaque",
        "moderation": "low",
    } in agent.ai.params["tools"]


def test_agent_create_image_generates_without_touching_session(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", builtin_plugins=["image_generation"])
    agent.ai = FakeImageAI(agent)
    before = len(agent.session.messages)

    assert not hasattr(agent, "create_image")
    path = agent.plugins.image_generation.create_image("draw a red square", size="1024x1024")

    assert path.startswith(str(tmp_path / "images"))
    assert len(agent.session.messages) == before
    assert agent.ai.params["messages"][0].type == "system_message"
    assert "specialized image creation assistant" in agent.ai.params["messages"][0].content
    assert agent.ai.params["messages"][-1].content == [{"type": "text", "text": "draw a red square"}]
    assert agent.ai.params["model"] == "gpt-5.4"
    assert agent.ai.params["reasoning"] == {"effort": "medium", "summary": "auto"}
    assert agent.ai.params["text"] == {"verbosity": "medium"}
    assert agent.ai.params["tools"] == [{
        "type": "image_generation",
        "output_format": "png",
        "size": "1024x1024",
    }]


def test_agent_create_image_accepts_input_images(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", builtin_plugins=["image_generation"])
    agent.ai = FakeImageAI(agent)
    source = b"source image bytes"

    path = agent.plugins.image_generation.create_image("make a variation", input_images=[source])
    content = agent.ai.params["messages"][-1].content

    assert path.startswith(str(tmp_path / "images"))
    assert content[0] == {"type": "text", "text": "make a variation"}
    assert any(part.get("type") == "input_image" for part in content)


def test_agent_create_image_allows_llm_parameter_overrides(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", builtin_plugins=["image_generation"])
    agent.ai = FakeImageAI(agent)

    agent.plugins.image_generation.create_image(
        "draw a red square",
        model="gpt-test",
        reasoning={"effort": "low", "summary": "auto"},
        text={"verbosity": "high"},
    )

    assert agent.ai.params["model"] == "gpt-test"
    assert agent.ai.params["reasoning"] == {"effort": "low", "summary": "auto"}
    assert agent.ai.params["text"] == {"verbosity": "high"}


def test_agent_create_image_uses_explicit_generation_parameters(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(
        session="new",
        builtin_plugins=["image_generation"],
        image_generation_size="should-not-leak",
        image_generation_quality="should-not-leak",
    )
    agent.ai = FakeImageAI(agent)

    agent.plugins.image_generation.create_image(
        "draw a red square",
        output_format="png",
        size="1024x1024",
        quality="low",
        background="opaque",
        moderation="low",
    )

    assert agent.ai.params["tools"] == [{
        "type": "image_generation",
        "output_format": "png",
        "size": "1024x1024",
        "quality": "low",
        "background": "opaque",
        "moderation": "low",
    }]


def test_agent_persists_generated_images_as_observable_files(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new", builtin_plugins=["image_generation"])
    item = {
        "type": "image_generation_call",
        "id": "ig_123",
        "result": "Zm9v",
    }
    agent.ai._codex_client = FakeCodexClient([output_item_event(item)])

    message = agent.get_response()
    server_message = agent.session.messages[-1]
    assistant_payload = json.loads(json.dumps(message))
    payload = json.loads(json.dumps(server_message))

    assert "output_items" not in assistant_payload
    assert "Zm9v" not in json.dumps(assistant_payload)
    assert isinstance(server_message, ServerToolResponseMessage)
    assert server_message.item == {"type": "image_generation_call", "id": "ig_123"}
    assert server_message.content.startswith(str(tmp_path / "images"))
    assert "Zm9v" not in json.dumps(payload)
    assert server_message.as_image_message().content == server_message.content
