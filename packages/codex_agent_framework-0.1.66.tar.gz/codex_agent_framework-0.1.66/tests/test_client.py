import json
import threading
import time

import requests

from codex_agent.client import AgentClient
from codex_agent.event import AssistantTurnStartEvent


def test_agent_client_parses_sse_events():
    client = AgentClient()
    lines = [
        "id: evt_1",
        "event: assistant_turn_start_event",
        'data: {"type": "assistant_turn_start_event", "value": 1}',
        "",
    ]

    events = list(client.iter_sse(lines))

    assert events[0].id == "evt_1"
    assert events[0].type == "assistant_turn_start_event"
    assert events[0].value == 1


def test_agent_client_dispatches_event_classes_as_snake_case():
    client = AgentClient()
    seen = []

    client.on(AssistantTurnStartEvent, lambda event: seen.append(event.type))
    client.emit_local({"type": "assistant_turn_start_event"})

    assert seen == ["assistant_turn_start_event"]


def test_agent_client_keeps_dispatching_when_handler_fails():
    client = AgentClient()
    seen = []

    def broken(_event):
        raise RuntimeError("boom")

    client.on("assistant_turn_start_event", broken)
    client.on("client_event_error", lambda event: seen.append(event.error))

    client.emit_local({"type": "assistant_turn_start_event"})

    assert seen == ["boom"]


def test_agent_client_local_dispatch_queue_decouples_sse_from_slow_handler(monkeypatch):
    client = AgentClient(timeout=0.01)
    started = threading.Event()
    release = threading.Event()
    handled = []
    request_count = {"count": 0}

    def slow_handler(event):
        handled.append(("start", event.type))
        started.set()
        release.wait(timeout=1.0)
        handled.append(("done", event.type))

    client.on("assistant_turn_start_event", slow_handler)
    client.on("tool_call_start_event", lambda event: (handled.append(("fast", event.type)), client._event_stop.set()))

    class Response:
        content = b""

        def __init__(self, lines):
            self.lines = lines

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def raise_for_status(self):
            pass

        def iter_lines(self, chunk_size=None, decode_unicode=True):
            for line in self.lines:
                yield line

    def fake_get(*args, **kwargs):
        request_count["count"] += 1
        if request_count["count"] == 1:
            return Response([
                'event: assistant_turn_start_event',
                'data: {"type": "assistant_turn_start_event", "sequence": 1}',
                '',
                'event: tool_call_start_event',
                'data: {"type": "tool_call_start_event", "sequence": 2}',
                '',
            ])
        return Response([])

    monkeypatch.setattr("codex_agent.client.requests.get", fake_get)
    monkeypatch.setattr(client._event_stop, "wait", lambda delay: None)

    thread = threading.Thread(target=client._event_loop, daemon=True)
    thread.start()

    assert started.wait(timeout=1.0) is True
    assert client._last_event_sequence == 2

    release.set()
    thread.join(timeout=1.0)
    client.stop_events(timeout=0.2)

    assert ("start", "assistant_turn_start_event") in handled
    assert ("done", "assistant_turn_start_event") in handled
    assert ("fast", "tool_call_start_event") in handled


def test_agent_client_parses_bad_sse_json_as_client_error():
    client = AgentClient()
    lines = [
        "id: evt_1",
        "event: assistant_turn_start_event",
        "data: {bad json",
        "",
    ]

    events = list(client.iter_sse(lines))

    assert events[0].type == "client_event_error"
    assert events[0].id == "evt_1"


def test_agent_client_http_error_payload_includes_status_and_detail():
    client = AgentClient()

    class Response:
        status_code = 409
        text = '{"detail": "an event client is already connected"}'

        def json(self):
            return json.loads(self.text)

    error = requests.HTTPError("409 Client Error")
    error.response = Response()

    payload = client.event_error_payload(error)

    assert payload.type == "client_event_error"
    assert payload.status_code == 409
    assert payload.detail == "an event client is already connected"
    assert payload.error == "an event client is already connected"


def test_agent_client_http_error_payload_falls_back_to_text_for_non_json_body():
    client = AgentClient()

    class Response:
        status_code = 502
        text = "gateway unavailable"

        def json(self):
            raise ValueError("not json")

    error = requests.HTTPError("502 Bad Gateway")
    error.response = Response()

    payload = client.event_error_payload(error)

    assert payload.status_code == 502
    assert payload.detail == "gateway unavailable"
    assert payload.error == "gateway unavailable"


def test_agent_client_context_status_delegates_to_get_status(monkeypatch):
    client = AgentClient(base_url="http://agent.local")
    calls = []

    def fake_get(path):
        calls.append(path)
        return {"ok": True}

    monkeypatch.setattr(client, "get", fake_get)

    assert client.context_status() == {"ok": True}
    assert calls == ["/status"]


def test_agent_client_submit_prompt_posts_prompt(monkeypatch):
    client = AgentClient(base_url="http://agent.local")
    calls = []

    class Response:
        content = b'{"accepted": true, "turn_id": "turn_1"}'

        def raise_for_status(self):
            pass

        def json(self):
            return json.loads(self.content)

    def fake_request(method, url, **kwargs):
        calls.append((method, url, kwargs))
        return Response()

    monkeypatch.setattr("codex_agent.client.requests.request", fake_request)

    result = client.submit_prompt("hello")

    assert result.turn_id == "turn_1"
    assert calls[0][0] == "POST"
    assert calls[0][1] == "http://agent.local/turns"
    assert calls[0][2]["json"] == {"prompt": "hello"}


def test_agent_client_interrupt_is_best_effort_on_http_error(monkeypatch):
    client = AgentClient(base_url="http://agent.local")
    seen = []
    received = threading.Event()
    client.on("client_event_error", lambda event: (seen.append(event), received.set()))

    def fake_request(method, url, **kwargs):
        raise requests.ConnectionError("server disappeared")

    monkeypatch.setattr("codex_agent.client.requests.request", fake_request)

    result = client.interrupt("keyboard_interrupt")

    assert result.interrupted is False
    assert result.interrupt_requested is False
    assert "server disappeared" in result.error
    assert received.wait(timeout=1.0) is True
    assert seen[-1].source == "interrupt"
    client.stop_events(timeout=0.2)


def test_agent_client_fetches_replay_events_with_cursor_and_session(monkeypatch):
    client = AgentClient(base_url="http://agent.local")
    calls = []

    class Response:
        content = b'{"events": []}'

        def raise_for_status(self):
            pass

        def json(self):
            return json.loads(self.content)

    def fake_request(method, url, **kwargs):
        calls.append((method, url, kwargs))
        return Response()

    monkeypatch.setattr("codex_agent.client.requests.request", fake_request)

    result = client.replay_events(before_sequence=42, session_id="session_1")

    assert result.events == []
    assert calls[0][0] == "GET"
    assert calls[0][1] == "http://agent.local/events/replay?before_sequence=42&session_id=session_1"


def test_agent_client_emits_offline_then_connected_on_reconnect(monkeypatch):
    client = AgentClient(timeout=0.01)
    events = []
    client.on("server_connected", lambda event: events.append(event.type))
    client.on("server_offline", lambda event: events.append(event.type))
    ping_count = {"count": 0}
    def on_ping(event):
        events.append(event.type)
        ping_count["count"] += 1
        if ping_count["count"] >= 2:
            client._event_stop.set()
    client.on("server_ping", on_ping)

    class Response:
        content = b""
        def __init__(self, lines):
            self.lines = lines
        def __enter__(self):
            return self
        def __exit__(self, *args):
            return False
        def raise_for_status(self):
            pass
        def iter_lines(self, chunk_size=None, decode_unicode=True):
            for line in self.lines:
                yield line

    calls = {"count": 0}

    def fake_get(*args, **kwargs):
        calls["count"] += 1
        if calls["count"] == 1:
            return Response(["event: server_ping", 'data: {"type": "server_ping"}', ""])
        if calls["count"] == 2:
            raise requests.ConnectionError("server down")
        return Response(["event: server_ping", 'data: {"type": "server_ping"}', ""])

    monkeypatch.setattr("codex_agent.client.requests.get", fake_get)
    monkeypatch.setattr(client._event_stop, "wait", lambda delay: None)

    client._event_loop()
    client.stop_events(timeout=0.2)

    assert events[:5] == ["server_connected", "server_ping", "server_offline", "server_connected", "server_ping"]


def test_agent_client_does_not_emit_server_connected_for_failed_connection(monkeypatch):
    client = AgentClient(timeout=0.01)
    events = []
    client.on("server_connected", lambda event: events.append(event.type))
    client.on("client_event_error", lambda event: (events.append(event.type), client._event_stop.set()))

    monkeypatch.setattr("codex_agent.client.requests.get", lambda *args, **kwargs: (_ for _ in ()).throw(requests.ConnectionError("server down")))

    client._event_loop()

    assert events == ["client_event_error"]


def test_agent_client_emits_offline_when_event_stream_closes_cleanly(monkeypatch):
    client = AgentClient(timeout=0.01)
    events = []
    client.on("server_connected", lambda event: events.append(event.type))
    client.on("server_offline", lambda event: (events.append(event.type), client._event_stop.set()))

    class Response:
        content = b""
        def __enter__(self):
            return self
        def __exit__(self, *args):
            return False
        def raise_for_status(self):
            pass
        def iter_lines(self, chunk_size=None, decode_unicode=True):
            return iter([])

    monkeypatch.setattr("codex_agent.client.requests.get", lambda *args, **kwargs: Response())

    client._event_loop()

    assert events == ["server_connected", "server_offline"]
    assert client._server_connected is False


def test_agent_client_uses_bounded_sse_read_timeout_by_default(monkeypatch):
    client = AgentClient(timeout=10)
    client.client_pid = 1234
    seen = []

    class Response:
        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def raise_for_status(self):
            pass

        def iter_lines(self, chunk_size=None, decode_unicode=True):
            client._event_stop.set()
            return iter([])

    def fake_get(*args, **kwargs):
        seen.append(kwargs["timeout"])
        return Response()

    monkeypatch.setattr("codex_agent.client.requests.get", fake_get)

    client._event_loop()

    assert seen == [(10, 15.0)]


def test_agent_client_accepts_explicit_sse_read_timeout(monkeypatch):
    client = AgentClient(timeout=10, event_read_timeout=30)
    seen = []

    class Response:
        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def raise_for_status(self):
            pass

        def iter_lines(self, chunk_size=None, decode_unicode=True):
            client._event_stop.set()
            return iter([])

    def fake_get(*args, **kwargs):
        seen.append(kwargs["timeout"])
        return Response()

    monkeypatch.setattr("codex_agent.client.requests.get", fake_get)

    client._event_loop()

    assert seen == [(10, 30)]


def test_agent_client_reconnects_after_idle_read_timeout_without_offline_event(monkeypatch):
    client = AgentClient(base_url="http://agent.local", timeout=10, event_read_timeout=0.01)
    client.client_pid = 1234
    urls = []
    events = []
    client.on("server_connected", lambda event: events.append(event.type))
    client.on("server_offline", lambda event: events.append(event.type))
    client.on("client_event_error", lambda event: events.append(event.type))
    client.on("tool_call_start_event", lambda event: events.append(event.type))
    client.on("tool_call_done_event", lambda event: (events.append(event.type), client._event_stop.set()))

    class Response:
        def __init__(self, lines=None, error=None):
            self.lines = lines or []
            self.error = error

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def raise_for_status(self):
            pass

        def iter_lines(self, chunk_size=None, decode_unicode=True):
            for line in self.lines:
                yield line
            if self.error is not None:
                raise self.error

    def event_lines(event_type, sequence):
        return [
            f"event: {event_type}",
            f'data: {{"type": "{event_type}", "sequence": {sequence}, "tool_call": {{"name": "bash", "call_id": "call_1"}}}}',
            "",
        ]

    def fake_get(url, **kwargs):
        urls.append(url)
        if len(urls) == 1:
            return Response(
                event_lines("tool_call_start_event", 2),
                requests.exceptions.ReadTimeout("Read timed out."),
            )
        return Response(event_lines("tool_call_done_event", 3))

    monkeypatch.setattr("codex_agent.client.requests.get", fake_get)
    monkeypatch.setattr(client._event_stop, "wait", lambda delay: False)

    client._event_loop()
    client.stop_events(timeout=0.2)

    assert urls[:2] == [
        "http://agent.local/events?client_pid=1234",
        "http://agent.local/events?client_pid=1234&after_sequence=2",
    ]
    assert events[:3] == ["server_connected", "tool_call_start_event", "tool_call_done_event"]


def test_agent_client_health_loop_reconnects_stale_event_stream_without_offline(monkeypatch):
    client = AgentClient(timeout=10, event_stale_after=2.0)
    client._server_connected = True
    client._event_stream_connected = True
    client._last_event_stream_activity = 10.0
    events = []
    closed = []
    checks = {"count": 0}

    class StreamResponse:
        def close(self):
            closed.append(True)

    class HealthResponse:
        def raise_for_status(self):
            pass

    client._event_stream_response = StreamResponse()
    client.on("server_offline", lambda event: events.append(event.type))
    monkeypatch.setattr("codex_agent.client.time.monotonic", lambda: 13.0)

    def fake_get(*args, **kwargs):
        checks["count"] += 1
        return HealthResponse()

    def wait(delay):
        client._event_stop.set()
        return False

    monkeypatch.setattr("codex_agent.client.requests.get", fake_get)
    monkeypatch.setattr(client._event_stop, "wait", wait)

    client._health_loop()

    assert closed == [True]
    assert client._event_reconnect_requested is True
    assert events == []


def test_agent_client_submit_prompt_reconnects_stale_event_stream(monkeypatch):
    client = AgentClient(base_url="http://agent.local", timeout=10, event_stale_after=2.0)
    client._server_connected = True
    client._event_stream_connected = True
    client._last_event_stream_activity = 10.0
    closed = []
    calls = []

    class StreamResponse:
        def close(self):
            closed.append(True)

    class Response:
        content = b'{"turn_id": "turn_1"}'

        def raise_for_status(self):
            pass

        def json(self):
            return {"turn_id": "turn_1"}

    client._event_stream_response = StreamResponse()
    monkeypatch.setattr("codex_agent.client.time.monotonic", lambda: 13.0)

    def fake_request(method, url, **kwargs):
        calls.append((method, url, kwargs["json"]))
        return Response()

    monkeypatch.setattr("codex_agent.client.requests.request", fake_request)

    result = client.submit_prompt("hello")

    assert result.turn_id == "turn_1"
    assert closed == [True]
    assert client._event_reconnect_requested is True
    assert calls == [("POST", "http://agent.local/turns", {"prompt": "hello"})]


def test_agent_client_health_loop_emits_offline_without_waiting_for_sse(monkeypatch):
    client = AgentClient(timeout=10)
    client._server_connected = True
    client.health_failure_threshold = 2
    events = []
    client.on("server_offline", lambda event: (events.append(event.error), client._event_stop.set()))

    monkeypatch.setattr(
        "codex_agent.client.requests.get",
        lambda *args, **kwargs: (_ for _ in ()).throw(requests.ConnectionError("server down")),
    )
    monkeypatch.setattr(client._event_stop, "wait", lambda delay: None)

    client._health_loop()

    assert events == ["server down"]
    assert client._server_connected is False


def test_agent_client_health_loop_does_not_emit_offline_while_sse_is_connected(monkeypatch):
    client = AgentClient(timeout=10)
    client._server_connected = True
    client._event_stream_connected = True
    client.health_failure_threshold = 2
    events = []
    calls = {"count": 0}
    client.on("server_offline", lambda event: events.append(event.error))

    def fake_get(*args, **kwargs):
        calls["count"] += 1
        raise requests.ConnectionError("server busy")

    def wait(delay):
        if calls["count"] >= 2:
            client._event_stop.set()
        return False

    monkeypatch.setattr("codex_agent.client.requests.get", fake_get)
    monkeypatch.setattr(client._event_stop, "wait", wait)

    client._health_loop()

    assert events == []
    assert client._server_connected is True


def test_agent_client_health_loop_does_not_emit_connected_while_sse_is_connected(monkeypatch):
    client = AgentClient(timeout=10)
    client._server_connected = False
    client._event_stream_connected = True
    events = []
    calls = {"count": 0}
    client.on("server_connected", lambda event: events.append(event.type))

    class Response:
        def raise_for_status(self):
            pass

    def fake_get(*args, **kwargs):
        calls["count"] += 1
        return Response()

    def wait(delay):
        client._event_stop.set()
        return False

    monkeypatch.setattr("codex_agent.client.requests.get", fake_get)
    monkeypatch.setattr(client._event_stop, "wait", wait)

    client._health_loop()

    assert events == []
    assert client._server_connected is False


def test_agent_client_health_loop_ignores_transient_failures(monkeypatch):
    client = AgentClient(timeout=10)
    client._server_connected = True
    client.health_failure_threshold = 2
    events = []
    calls = {"count": 0}
    client.on("server_offline", lambda event: events.append(event.error))
    client.on("server_connected", lambda event: events.append(event.type))

    class Response:
        def raise_for_status(self):
            pass

    def fake_get(*args, **kwargs):
        calls["count"] += 1
        if calls["count"] == 1:
            raise requests.ConnectionError("brief stall")
        return Response()

    monkeypatch.setattr("codex_agent.client.requests.get", fake_get)
    def wait(delay):
        if calls["count"] >= 2:
            client._event_stop.set()
        return False

    monkeypatch.setattr(client._event_stop, "wait", wait)

    client._health_loop()

    assert events == []
    assert client._server_connected is True
    assert client._health_failures == 0


def test_agent_client_health_loop_does_not_emit_connected_when_health_recovers(monkeypatch):
    client = AgentClient(timeout=10)
    events = []
    calls = {"count": 0}
    client.on("server_connected", lambda event: events.append(event.type))

    class Response:
        def raise_for_status(self):
            pass

    def fake_get(*args, **kwargs):
        calls["count"] += 1
        return Response()

    def wait(delay):
        client._event_stop.set()
        return False

    monkeypatch.setattr("codex_agent.client.requests.get", fake_get)
    monkeypatch.setattr(client._event_stop, "wait", wait)

    client._health_loop()

    assert events == []
    assert client._server_connected is False


def test_agent_client_reconnects_with_last_seen_sequence(monkeypatch):
    client = AgentClient(base_url="http://agent.local", timeout=0.01)
    client.client_pid = 1234
    urls = []
    class Response:
        content = b""
        def __init__(self, lines):
            self.lines = lines
        def __enter__(self):
            return self
        def __exit__(self, *args):
            return False
        def raise_for_status(self):
            pass
        def iter_lines(self, chunk_size=None, decode_unicode=True):
            return iter(self.lines)
    def fake_get(url, **kwargs):
        urls.append(url)
        if len(urls) == 1:
            return Response([
                "id: one",
                "event: assistant_message_delta_event",
                'data: {"type": "assistant_message_delta_event", "sequence": 12}',
                "",
            ])
        client._event_stop.set()
        return Response([])
    monkeypatch.setattr("codex_agent.client.requests.get", fake_get)
    monkeypatch.setattr(client._event_stop, "wait", lambda delay: None)
    client._event_loop()
    assert urls[:2] == [
        "http://agent.local/events?client_pid=1234",
        "http://agent.local/events?client_pid=1234&after_sequence=12",
    ]

def test_agent_client_ignores_non_monotonic_event_sequence():
    client = AgentClient()
    client.remember_event_sequence({"sequence": 5})
    client.remember_event_sequence({"sequence": 3})
    client.remember_event_sequence({"sequence": "bad"})
    assert client._last_event_sequence == 5


def test_agent_client_does_not_treat_replay_cursor_as_seen_event_sequence():
    client = AgentClient()

    client.remember_event_sequence({"type": "server_subscribed", "replay_before_sequence": 42})

    assert client._last_event_sequence is None


def test_agent_client_event_error_payload_marks_event_stream_source():
    client = AgentClient()

    payload = client.event_error_payload(requests.ConnectionError("server down"))

    assert payload.source == "event_stream"
