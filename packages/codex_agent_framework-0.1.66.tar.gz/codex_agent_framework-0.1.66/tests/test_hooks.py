from modict import modict

from codex_agent import Agent
from codex_agent.hooks import HookManager
from codex_agent.builtin_plugins.files.tools import apply_file_write, apply_text_edit
from codex_agent.message import AssistantMessage, UserMessage


def test_hook_manager_runs_handlers_in_order_and_allows_payload_mutation():
    manager = HookManager()
    calls = []

    @manager.add("sample.before")
    def first(context):
        calls.append(("first", context.payload.value))
        context.payload.value = "changed"

    @manager.add("sample.before")
    def second(context):
        calls.append(("second", context.payload.value))
        return {"extra": True}

    context = manager.run("sample.before", value="original")

    assert calls == [("first", "original"), ("second", "changed")]
    assert context.payload.value == "changed"
    assert context.extra is True
    assert len(context.results) == 2


def test_agent_hook_api_keeps_legacy_hooks_compatible():
    agent = Agent(session="new")
    calls = []

    @agent.add_hook("audio_playback_hook")
    def playback(audio):
        calls.append(audio)
        return "played"

    assert agent.has_hook("audio_playback_hook") is True
    assert agent.run_hooks("audio_playback_hook", b"audio") == ["played"]
    assert calls == [b"audio"]


def test_submit_message_hooks_can_transform_message():
    agent = Agent(session="new")
    seen = []

    @agent.add_hook("message.submit.before")
    def before(context):
        seen.append(("before", context.payload.message.content))
        context.payload.message = UserMessage(content="changed")

    @agent.add_hook("message.submit.after")
    def after(context):
        seen.append(("after", context.payload.message.content, bool(context.payload.turn_id)))

    result = agent.submit_message(UserMessage(content="original"))

    assert result.message.content == "changed"
    assert seen == [("before", "original"), ("after", "changed", True)]
    agent.stop(timeout=1.0)


def test_context_build_after_hook_can_transform_context():
    agent = Agent(session="new")

    @agent.add_hook("context.build.after")
    def after(context):
        context.payload.messages = [modict(type="input_text", text="hooked")]

    assert agent.context_manager.get_context() == [modict(type="input_text", text="hooked")]


def test_tool_call_hooks_can_transform_arguments_and_output():
    agent = Agent(session="new")
    calls = []

    @agent.add_tool
    def echo(value: str):
        """
        description: Echo value.
        parameters:
          value:
            type: string
        required:
          - value
        """
        calls.append(("tool", value))
        return value

    @agent.add_hook("tool.call.before")
    def before(context):
        calls.append(("before", context.payload.kwargs["value"]))
        context.payload.kwargs["value"] = "changed"

    @agent.add_hook("tool.call.after")
    def after(context):
        calls.append(("after", context.payload.output))
        context.payload.output = "wrapped"

    message = AssistantMessage(tool_calls=[modict(
        type="function_call",
        name="echo",
        call_id="call_1",
        arguments='{"value": "original"}',
    )])

    assert agent.mainloop_manager.call_tools(message) is True
    assert calls == [("before", "original"), ("tool", "changed"), ("after", "changed")]
    wrapper = [msg for msg in agent.mainloop_manager.pending if msg.get("name") == "tool_result_wrapper"][-1]
    assert wrapper.content == "wrapped"


def test_runtime_module_load_hooks_are_called(tmp_path):
    agent = Agent(session="new")
    path = tmp_path / "custom_tool.py"
    path.write_text("VALUE = 42\n", encoding="utf-8")
    calls = []

    @agent.add_hook("runtime_module.load.before")
    def before(context):
        calls.append(("before", context.payload.kind, context.payload.path))

    @agent.add_hook("runtime_module.load.after")
    def after(context):
        calls.append(("after", context.payload.kind, context.payload.module.VALUE))

    module = agent.plugins_manager.load_runtime_module(str(path))

    assert module.VALUE == 42
    assert calls == [("before", "plugin", str(path)), ("after", "plugin", 42)]


def test_file_write_and_edit_hooks_can_transform_operation(tmp_path):
    agent = Agent(session="new")
    target = tmp_path / "hooked.txt"
    events = []

    @agent.add_hook("file.write.before")
    def before_write(context):
        events.append(("write.before", context.payload.file_path))
        context.payload.content = "hello hook"

    @agent.add_hook("file.edit.before")
    def before_edit(context):
        events.append(("edit.before", context.payload.old_string))
        context.payload.new_string = "hello edited"

    @agent.add_hook("file.edit.after")
    def after_edit(context):
        events.append(("edit.after", context.payload.replaced))

    with_agent = __import__("codex_agent.tool", fromlist=["set_current_agent", "reset_current_agent"])
    token = with_agent.set_current_agent(agent)
    try:
        assert "success" in apply_file_write(1, {"file_path": str(target), "content": "original"})
        assert target.read_text(encoding="utf-8") == "hello hook"
        assert "success" in apply_text_edit(1, {"file_path": str(target), "old_string": "hello hook", "new_string": "ignored"})
        assert target.read_text(encoding="utf-8") == "hello edited"
    finally:
        with_agent.reset_current_agent(token)

    assert events == [
        ("write.before", str(target)),
        ("edit.before", "hello hook"),
        ("edit.after", 1),
    ]


def test_bash_hooks_can_transform_command_and_output():
    agent = Agent(session="new", builtin_plugins=["bash"])

    @agent.add_hook("shell.bash.before")
    def before(context):
        context.payload.content = "printf hooked"

    @agent.add_hook("shell.bash.after")
    def after(context):
        context.payload.output = f"wrapped: {context.payload.stdout}"

    assert agent.tools.bash("printf original") == "wrapped: hooked"
