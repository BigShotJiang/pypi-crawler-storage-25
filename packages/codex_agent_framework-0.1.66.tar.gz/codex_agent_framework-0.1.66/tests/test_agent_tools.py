import json
import sys
from typing import Literal

from codex_agent import Agent, get_agent, get_current_call_id
from codex_agent.image import ImageMessage
from codex_agent.message import AssistantMessage, ToolResultWrapper
from codex_agent.tool import Tool


def test_builtin_read_tool_survives_get_text_submodule_shadowing():

    agent = Agent(session="new")
    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "read",
        "arguments": '{"reads": {"source": "codex_agent/builtin_plugins/files/tools.py"}}',
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert "success: call_id=call_1" in agent.session.messages[-1].content
    assert isinstance(agent.mainloop_manager.pending[-1], ToolResultWrapper)
    assert "'module' object is not callable" not in agent.mainloop_manager.pending[-1].content
    assert "def read(" in agent.mainloop_manager.pending[-1].content


def test_builtin_read_tool_accepts_line_range(tmp_path):
    file = tmp_path / "sample.txt"
    file.write_text("alpha\nbeta\ngamma\ndelta", encoding="utf-8")

    agent = Agent(session="new")
    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "read",
        "arguments": json.dumps({"reads": {"source": str(file), "start_at_line": 2, "end_at_line": 3}}),
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert isinstance(agent.mainloop_manager.pending[-1], ToolResultWrapper)
    assert agent.mainloop_manager.pending[-1].content == "2|beta\n3|gamma"


def test_builtin_read_tool_accepts_pattern_and_includes_context(tmp_path):
    file = tmp_path / "sample.txt"
    lines = [f"line {index}" for index in range(1, 31)]
    lines[20] = "line 21 needle"
    file.write_text("\n".join(lines), encoding="utf-8")

    agent = Agent(session="new")
    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "read",
        "arguments": f'{{"reads": {{"source": "{file}", "pattern": "needle"}}}}',
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert isinstance(agent.mainloop_manager.pending[-1], ToolResultWrapper)
    assert "11|line 11" in agent.mainloop_manager.pending[-1].content
    assert "21|line 21 needle" in agent.mainloop_manager.pending[-1].content
    assert "10|line 10" not in agent.mainloop_manager.pending[-1].content


def test_builtin_read_tool_accepts_regex_pattern(tmp_path):
    file = tmp_path / "sample.txt"
    lines = ["alpha", "ticket ABC-123", *[f"line {index}" for index in range(3, 25)], "ticket XYZ-123"]
    file.write_text("\n".join(lines), encoding="utf-8")

    agent = Agent(session="new")
    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "read",
        "arguments": f'{{"reads": {{"source": "{file}", "pattern": "ABC-\\\\d+", "regex": true}}}}',
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert isinstance(agent.mainloop_manager.pending[-1], ToolResultWrapper)
    assert "2|ticket ABC-123" in agent.mainloop_manager.pending[-1].content
    assert "3|ticket XYZ-123" not in agent.mainloop_manager.pending[-1].content


def test_builtin_read_tool_accepts_multiple_reads(tmp_path):
    file_one = tmp_path / "one.txt"
    file_two = tmp_path / "two.txt"
    file_one.write_text("alpha\nbeta", encoding="utf-8")
    file_two.write_text("gamma\ndelta", encoding="utf-8")

    agent = Agent(session="new")
    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_batch",
        "name": "read",
        "arguments": json.dumps({
            "reads": [
                {"source": str(file_one)},
                {"source": str(file_two), "start_at_line": 2},
            ]
        }),
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert agent.session.messages[-1].call_id == "call_batch"
    assert "2 outputs in ToolResultWrapper ids=" in agent.session.messages[-1].content
    assert [wrapper.call_id for wrapper in agent.mainloop_manager.pending[-2:]] == ["call_batch", "call_batch"]
    assert "1|alpha" in agent.mainloop_manager.pending[-2].content
    assert "2|beta" in agent.mainloop_manager.pending[-2].content
    assert "1|gamma" not in agent.mainloop_manager.pending[-1].content
    assert "2|delta" in agent.mainloop_manager.pending[-1].content


def test_builtin_edit_tool_applies_single_exact_replacement(tmp_path):
    agent = Agent(session="new")
    path = tmp_path / "note.txt"
    path.write_text("hello world\n", encoding="utf-8")

    result = agent.tools.edit({
        "file_path": str(path),
        "old_string": "hello",
        "new_string": "bonjour",
    })

    assert "1. success: replaced 1 match" in result
    assert path.read_text(encoding="utf-8") == "bonjour world\n"


def test_builtin_python_tool_runs_in_persistent_shell():
    agent = Agent(session="new", builtin_plugins=["python"])
    message = AssistantMessage()
    message.tool_calls = [{
        "type": "custom_tool_call",
        "call_id": "call_1",
        "name": "python",
        "input": "x = 40\nx + 2",
    }]

    assert agent.mainloop_manager.call_tools(message) is True

    assert "success: call_id=call_1" in agent.session.messages[-1].content
    assert "result:\n42" in agent.mainloop_manager.pending[-1].content


def test_builtin_bash_tool_runs_shell_commands():
    agent = Agent(session="new", builtin_plugins=["bash"])

    result = agent.tools.bash("printf hello")

    assert result == "stdout:\nhello"


def test_builtin_bash_tool_uses_agent_cwd(tmp_path):
    root = tmp_path / "project"
    root.mkdir()
    (root / "marker.txt").write_text("ok", encoding="utf-8")
    agent = Agent(session="new", root_dir=str(root), builtin_plugins=["bash"])

    result = agent.tools.bash("pwd; cat marker.txt")

    assert str(root) in result
    assert "ok" in result


def test_builtin_python_tool_uses_and_updates_agent_cwd(tmp_path):
    root = tmp_path / "project"
    other = tmp_path / "other"
    root.mkdir()
    other.mkdir()
    agent = Agent(session="new", root_dir=str(root), builtin_plugins=["python"])

    result = agent.tools.python(f"import os\nprint(os.getcwd())\nos.chdir({str(other)!r})\nprint(os.getcwd())")

    assert str(root) in result
    assert str(other) in result
    assert agent.config.cwd == str(other)
    assert agent.session.cwd == str(other)


def test_builtin_bash_tool_reports_stderr_and_exit_code():
    agent = Agent(session="new", builtin_plugins=["bash"])

    result = agent.tools.bash("echo problem >&2; exit 7")

    assert "stderr:\nproblem\n" in result
    assert "exit_code: 7" in result


def test_builtin_bash_tool_prefers_agent_python_environment(monkeypatch):
    monkeypatch.setenv("PATH", "/usr/bin:/bin")
    agent = Agent(session="new", builtin_plugins=["bash"])

    result = agent.tools.bash("command -v python && python -c 'import sys; print(sys.executable)'")

    expected_dir = str(__import__("pathlib").Path(sys.executable).parent)
    assert expected_dir in result
    assert "/python" in result


def test_builtin_write_tool_writes_complete_file(tmp_path):
    agent = Agent(session="new")
    path = tmp_path / "notes" / "note.txt"

    result = agent.tools.write({"file_path": str(path), "content": "hello\nworld\n"})

    assert "1. success: wrote 12 characters" in result
    assert path.read_text(encoding="utf-8") == "hello\nworld\n"


def test_builtin_file_tools_resolve_relative_paths_from_agent_cwd(tmp_path):
    root = tmp_path / "project"
    root.mkdir()
    agent = Agent(session="new", root_dir=str(root))

    write_result = agent.tools.write({"file_path": "notes/note.txt", "content": "hello\n"})
    read_result = agent.tools.read({"source": "notes/note.txt"})

    assert "success: wrote 6 characters" in write_result
    assert (root / "notes" / "note.txt").read_text(encoding="utf-8") == "hello\n"
    assert "hello" in read_result[0]


def test_builtin_write_tool_overwrites_existing_file(tmp_path):
    agent = Agent(session="new")
    path = tmp_path / "note.txt"
    path.write_text("old\ncontent\n", encoding="utf-8")

    result = agent.tools.write({"file_path": str(path), "content": "new\n"})

    assert "1. success: wrote 4 characters" in result
    assert path.read_text(encoding="utf-8") == "new\n"


def test_builtin_write_tool_writes_multiple_files(tmp_path):
    agent = Agent(session="new")
    first = tmp_path / "one.txt"
    second = tmp_path / "nested" / "two.txt"

    result = agent.tools.write(writes=[
        {"file_path": str(first), "content": "one\n"},
        {"file_path": str(second), "content": "two\n"},
    ])

    assert "1. success: wrote 4 characters" in result
    assert "2. success: wrote 4 characters" in result
    assert first.read_text(encoding="utf-8") == "one\n"
    assert second.read_text(encoding="utf-8") == "two\n"


def test_builtin_write_tool_schema_is_structured_function_tool():
    agent = Agent(session="new")

    assert agent.tools.write.to_response_tool() == {
        "type": "function",
        "name": "write",
        "description": "Write or overwrite one or more complete UTF-8 text files.\nUse this when creating new text files or replacing entire files is clearer than targeted edits.\nParent directories are created automatically.\nPass either a single write object or a list of write objects.\n",
        "parameters": {
            "type": "object",
            "properties": {
                "writes": {
                    "description": "A single write object or a list of write objects.\nEach object must contain file_path and content.\n",
                    "anyOf": [
                        {
                            "type": "object",
                            "properties": {
                                "file_path": {"type": "string"},
                                "content": {"type": "string"},
                            },
                            "required": ["file_path", "content"],
                        },
                        {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "file_path": {"type": "string"},
                                    "content": {"type": "string"},
                                },
                                "required": ["file_path", "content"],
                            },
                        },
                    ],
                },
            },
            "required": ["writes"],
        },
    }


def test_builtin_edit_tool_requires_single_match_unless_replace_all(tmp_path):
    agent = Agent(session="new")
    path = tmp_path / "note.txt"
    path.write_text("x x x", encoding="utf-8")

    failed = agent.tools.edit({
        "file_path": str(path),
        "old_string": "x",
        "new_string": "y",
    })
    assert "failed: old_string matched 3 times" in failed
    assert path.read_text(encoding="utf-8") == "x x x"

    succeeded = agent.tools.edit({
        "file_path": str(path),
        "old_string": "x",
        "new_string": "y",
        "replace_all": True,
    })
    assert "success: replaced 3 matches" in succeeded
    assert path.read_text(encoding="utf-8") == "y y y"


def test_builtin_edit_tool_applies_multiple_edits_in_sequence(tmp_path):
    agent = Agent(session="new")
    path = tmp_path / "note.txt"
    path.write_text("alpha beta gamma", encoding="utf-8")

    result = agent.tools.edit([
        {
            "file_path": str(path),
            "old_string": "alpha",
            "new_string": "one",
        },
        {
            "file_path": str(path),
            "old_string": "one beta",
            "new_string": "two",
        },
        {
            "file_path": str(path),
            "old_string": "missing",
            "new_string": "nope",
        },
    ])

    assert "1. success" in result
    assert "2. success" in result
    assert "3. failed: old_string not found" in result
    assert path.read_text(encoding="utf-8") == "two gamma"


def test_tool_can_describe_freeform_custom_tool():
    def code_exec(source):
        """Executes Python source code."""
        return source

    tool = Tool.from_callable(code_exec, tool_type="custom")

    assert tool.to_response_tool() == {
        "type": "custom",
        "name": "code_exec",
        "description": "Executes Python source code.",
    }


def test_tool_is_modict_payload_with_runtime_callable_attr():
    def echo(text: str):
        return text

    tool = Tool.from_callable(echo)

    assert isinstance(tool, dict)
    assert tool["name"] == "echo"
    assert tool["type"] == "tool"
    assert tool["tool_type"] == "function"
    assert tool["description"] == ""
    assert tool["parameters"] == {"text": {"type": "string"}}
    assert tool["required"] == ["text"]
    assert "schema" not in tool
    assert "mode" not in tool
    assert "format" not in tool
    assert "obj" not in tool
    assert "callable" not in tool
    assert tool("hi") == "hi"


def test_tool_parses_yaml_docstring():
    def lookup(query):
        """
        description: Finds a value.
        parameters:
          query:
            type: string
            description: Search query.
        required:
          - query
        """
        return query

    assert Tool.from_callable(lookup).to_response_tool() == {
        "type": "function",
        "name": "lookup",
        "description": "Finds a value.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query.",
                },
            },
            "required": ["query"],
        },
    }


def test_tool_infers_parameters_from_signature_annotations():
    def search(query: str, limit: int = 5, exact: bool = False):
        """Searches things."""
        return query

    assert Tool.from_callable(search).to_response_tool() == {
        "type": "function",
        "name": "search",
        "description": "Searches things.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "limit": {"type": "integer", "default": 5},
                "exact": {"type": "boolean", "default": False},
            },
            "required": ["query"],
        },
    }


def test_tool_infers_literal_and_array_annotations():
    def filter_items(tags: list[str], mode: Literal["all", "any"] = "all"):
        return tags

    assert Tool.from_callable(filter_items).to_response_tool()["parameters"] == {
        "type": "object",
        "properties": {
            "tags": {
                "type": "array",
                "items": {"type": "string"},
            },
            "mode": {
                "enum": ["all", "any"],
                "type": "string",
                "default": "all",
            },
        },
        "required": ["tags"],
    }


def test_tool_docstring_parameter_schema_overrides_inference():
    def lookup(query: str):
        """
        description: Finds a value.
        parameters:
          query:
            type: string
            description: Search query.
        """
        return query

    assert Tool.from_callable(lookup).to_response_tool()["parameters"]["properties"]["query"] == {
        "type": "string",
        "description": "Search query.",
    }


def test_tool_can_describe_grammar_constrained_custom_tool():
    def math_exp(source):
        return source

    tool = Tool.from_callable(
        math_exp,
        tool_type="custom",
        description="Creates a math expression.",
        format={
            "type": "grammar",
            "syntax": "lark",
            "definition": "start: /[0-9]+/",
        },
    )

    assert tool.to_response_tool() == {
        "type": "custom",
        "name": "math_exp",
        "description": "Creates a math expression.",
        "format": {
            "type": "grammar",
            "syntax": "lark",
            "definition": "start: /[0-9]+/",
        },
    }


def test_agent_calls_custom_tool_with_raw_input():
    agent = Agent(session="new", auto_proceed=False)
    seen = []

    @agent.add_tool(tool_type="custom", description="Echoes raw text.")
    def echo_raw(text):
        seen.append(text)
        return text.upper()

    message = AssistantMessage()
    message.tool_calls = [{
        "type": "custom_tool_call",
        "call_id": "call_1",
        "name": "echo_raw",
        "input": "hello",
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert seen == ["hello"]
    assert agent.session.messages[-1].to_response_format() == {
        "type": "custom_tool_call_output",
        "call_id": "call_1",
        "output": f"success: call_id=call_1; full output in ToolResultWrapper id={agent.mainloop_manager.pending[-1].id}.",
    }
    assert agent.mainloop_manager.pending[-1].content == "HELLO"


def test_tool_can_access_current_agent_context():
    agent = Agent(session="new", auto_proceed=False)

    @agent.add_tool
    def agent_name():
        """Gets the current agent name."""
        return get_agent().config.name

    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "agent_name",
        "arguments": "{}",
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert "success: call_id=call_1" in agent.session.messages[-1].content
    assert agent.mainloop_manager.pending[-1].content == agent.config.name


def test_tool_can_access_current_call_id_context():
    agent = Agent(session="new", auto_proceed=False)

    @agent.add_tool
    def current_call_id():
        """Gets the active tool call id."""
        return get_current_call_id()

    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_abc",
        "name": "current_call_id",
        "arguments": "{}",
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert agent.mainloop_manager.pending[-1].content == "call_abc"


def test_tool_can_return_multiple_output_wrappers():
    agent = Agent(session="new", auto_proceed=False)

    @agent.add_tool
    def many_outputs():
        """Returns multiple pending output messages."""
        return [
            "first",
            ToolResultWrapper(call_id=get_current_call_id(), tool_name="many_outputs", content="second"),
        ]

    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_multi",
        "name": "many_outputs",
        "arguments": "{}",
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert agent.session.messages[-1].call_id == "call_multi"
    assert "2 outputs in ToolResultWrapper ids=" in agent.session.messages[-1].content
    assert [wrapper.call_id for wrapper in agent.mainloop_manager.pending[-2:]] == ["call_multi", "call_multi"]
    assert [wrapper.content for wrapper in agent.mainloop_manager.pending[-2:]] == ["first", "second"]


def test_tool_can_return_image_message_output(tmp_path):
    from PIL import Image

    image_path = tmp_path / "tool-image.png"
    Image.new("RGB", (1, 1), color="blue").save(image_path)
    agent = Agent(session="new", auto_proceed=False)

    @agent.add_tool
    def image_output():
        """Returns an image as a pending output message."""
        return ImageMessage(content=str(image_path), turns_left=3)

    message = AssistantMessage()
    message.tool_calls = [{
        "type": "function_call",
        "call_id": "call_image",
        "name": "image_output",
        "arguments": "{}",
    }]

    assert agent.mainloop_manager.call_tools(message) is True
    assert agent.session.messages[-1].call_id == "call_image"
    assert "full output in ImageMessage id=" in agent.session.messages[-1].content
    assert isinstance(agent.mainloop_manager.pending[-1], ImageMessage)
    assert agent.mainloop_manager.pending[-1].content == str(image_path)
    assert agent.mainloop_manager.pending[-1].turns_left == 3
