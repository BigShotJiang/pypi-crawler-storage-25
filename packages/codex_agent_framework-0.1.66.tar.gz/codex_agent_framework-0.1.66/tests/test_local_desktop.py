from __future__ import annotations

import pytest

from codex_agent.desktop import DesktopControlError, DesktopController, WindowInfo, get_desktop_controller


def test_desktop_controller_wmctrl_parser(monkeypatch):
    controller = DesktopController()

    monkeypatch.setattr(controller, "_list_windows_pywinctl", lambda: [])
    monkeypatch.setattr("codex_agent.desktop.shutil.which", lambda name: name == "wmctrl")

    class Result:
        stdout = "0x01200007  0 1234 10 20 800 600 app.Class host Example window\n"

    monkeypatch.setattr(controller, "_run", lambda command: Result())

    windows = controller.list_windows()

    assert windows == [
        WindowInfo(
            id="0x01200007",
            desktop="0",
            pid="1234",
            x=10,
            y=20,
            width=800,
            height=600,
            wm_class="app.Class",
            title="Example window",
            backend="wmctrl",
        )
    ]


def test_desktop_controller_wmctrl_parser_keeps_invalid_geometry_as_none(monkeypatch):
    controller = DesktopController()

    monkeypatch.setattr(controller, "_list_windows_pywinctl", lambda: [])
    monkeypatch.setattr("codex_agent.desktop.shutil.which", lambda name: name == "wmctrl")

    class Result:
        stdout = "0x01200007  0 1234 ? nope 800 bad app.Class host Example window\n"

    monkeypatch.setattr(controller, "_run", lambda command: Result())

    [window] = controller.list_windows()
    assert window.x is None
    assert window.y is None
    assert window.width == 800
    assert window.height is None


def test_desktop_controller_capture_screen_uses_mss_only(monkeypatch, tmp_path):
    controller = DesktopController()
    output = tmp_path / "screen.png"
    calls = []

    def fake_capture(path, **region):
        calls.append((path, region))
        output.write_bytes(b"png")
        return path

    monkeypatch.setattr(controller, "_capture_mss", fake_capture)
    monkeypatch.setattr(controller, "_run", lambda command: pytest.fail(f"unexpected external screenshot command: {command}"))

    assert controller.capture_screen(str(output)) == str(output)
    assert calls == [(str(output), {})]


def test_desktop_controller_wmctrl_geometry_uses_valid_gravity(monkeypatch):
    controller = DesktopController()
    calls = []

    monkeypatch.setattr("codex_agent.desktop.shutil.which", lambda name: name == "wmctrl")
    monkeypatch.setattr(controller, "_run", lambda command: calls.append(command))

    controller.move_resize_window("0x01200007", 10, 20, 800, 600)

    assert calls == [["wmctrl", "-ir", "0x01200007", "-e", "0,10,20,800,600"]]


def test_desktop_controller_live_session_flag_toggles():
    controller = DesktopController()

    assert controller.live_session is False
    controller.start_live_session()
    assert controller.live_session is True
    controller.stop_live_session()
    assert controller.live_session is False


def test_desktop_controller_copy_text_uses_xclip(monkeypatch):
    controller = DesktopController()
    calls = []

    monkeypatch.setattr("codex_agent.desktop.shutil.which", lambda name: name == "xclip")
    monkeypatch.setattr(controller, "_run_stdin", lambda command, text: calls.append((command, text)))

    controller.copy("hello")

    assert calls == [(["xclip", "-selection", "clipboard"], "hello")]


def test_desktop_controller_copy_selection_presses_ctrl_c(monkeypatch):
    controller = DesktopController()
    calls = []

    monkeypatch.setattr("codex_agent.desktop.shutil.which", lambda name: name == "xdotool")
    monkeypatch.setattr(controller, "_run", lambda command: calls.append(command))

    controller.copy()

    assert calls == [["xdotool", "key", "--clearmodifiers", "ctrl+c"]]


def test_desktop_controller_paste_presses_ctrl_v(monkeypatch):
    controller = DesktopController()
    calls = []

    monkeypatch.setattr("codex_agent.desktop.shutil.which", lambda name: name == "xdotool")
    monkeypatch.setattr(controller, "_run", lambda command: calls.append(command))

    controller.paste()

    assert calls == [["xdotool", "key", "--clearmodifiers", "ctrl+v"]]


def test_desktop_controller_click_drag_release_uses_xdotool_sequence(monkeypatch):
    controller = DesktopController()
    calls = []

    monkeypatch.setattr("codex_agent.desktop.shutil.which", lambda name: name == "xdotool")
    monkeypatch.setattr(controller, "_run", lambda command: calls.append(command))

    controller.click_drag_release(x=10, y=20, to_x=30, to_y=40, button=1)

    assert calls == [
        ["xdotool", "mousemove", "--sync", "10", "20"],
        ["xdotool", "mousedown", "1"],
        ["xdotool", "mousemove", "--sync", "30", "40"],
        ["xdotool", "mouseup", "1"],
    ]


def test_desktop_controller_copy_text_requires_xclip(monkeypatch):
    controller = DesktopController()

    monkeypatch.setattr("codex_agent.desktop.shutil.which", lambda name: name == "xsel")

    with pytest.raises(DesktopControlError, match="Install xclip"):
        controller.copy("hello")


def test_desktop_controller_singleton_is_desktop_controller():
    assert isinstance(get_desktop_controller(), DesktopController)
