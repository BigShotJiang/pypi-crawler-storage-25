import importlib
import json

cli_main = importlib.import_module("codex_agent.cli.main")
headless = importlib.import_module("codex_agent.cli.headless")
runner = importlib.import_module("codex_agent.cli.runner")


class FakeClient:
    instances = []

    def __init__(self, base_url):
        self.base_url = base_url
        self.handlers = []
        FakeClient.instances.append(self)

    def get_status(self):
        return {"ok": True, "busy": False}

    def tools(self):
        return {"bash": {}, "read": {}}

    def get_config(self):
        return {"model": "test-model"}

    def update_config(self, values=None, save=True, namespace="agent", **kwargs):
        payload = dict(values or {})
        payload.update(kwargs)
        payload["save"] = save
        payload["namespace"] = namespace
        return payload

    def sessions(self):
        return {"current": "s1", "sessions": [{"id": "s1", "title": "Current"}]}

    def new_session(self):
        return {"id": "new"}

    def load_session(self, session_id):
        return {"id": session_id, "loaded": True}

    def delete_session(self, session_id):
        return {"session_id": session_id}

    def interrupt(self, reason="cli"):
        return {"interrupted": True, "reason": reason}

    def on(self, event_type, handler):
        self.handlers.append(handler)
        return handler

    def start_events(self):
        return self

    def stop_events(self, timeout=None):
        return self

    def submit_prompt(self, prompt):
        for handler in list(self.handlers):
            handler({"type": "response_content_delta_event", "delta": "hello"})
            handler({"type": "assistant_turn_end_event"})
        return {"accepted": True, "turn_id": "t1"}


def patch_client(monkeypatch):
    FakeClient.instances.clear()
    monkeypatch.setattr(runner, "AgentClient", FakeClient)


def test_status_headless_json(monkeypatch, capsys):
    patch_client(monkeypatch)

    cli_main.main(["status", "--json", "--url", "http://agent.local"])

    out = capsys.readouterr().out
    assert '"ok": true' in out
    assert FakeClient.instances[-1].base_url == "http://agent.local"


def test_tools_headless_text(monkeypatch, capsys):
    patch_client(monkeypatch)

    cli_main.main(["tools"])

    assert capsys.readouterr().out.splitlines() == ["bash", "read"]


def test_sessions_load_forwards_session_id(monkeypatch, capsys):
    patch_client(monkeypatch)

    cli_main.main(["sessions", "load", "session-123", "--json"])

    assert '"loaded": true' in capsys.readouterr().out


def test_config_get_key(monkeypatch, capsys):
    patch_client(monkeypatch)

    cli_main.main(["config", "get", "model"])

    assert capsys.readouterr().out.strip() == "test-model"


def test_config_set_key_value_parses_central_config_scalars(monkeypatch, capsys):
    patch_client(monkeypatch)

    cli_main.main([
        "config",
        "set",
        "enabled",
        "yes",
        "limit",
        "128000",
        "disabled",
        "off",
        "plugins",
        '["memory"]',
        "--json",
    ])

    payload = json.loads(capsys.readouterr().out)
    assert payload["enabled"] is True
    assert payload["limit"] == 128000
    assert payload["disabled"] is False
    assert payload["plugins"] == ["memory"]


def test_config_set_key_value(monkeypatch, capsys):
    patch_client(monkeypatch)

    cli_main.main(["config", "set", "input_token_limit", "128000", "--json"])

    out = capsys.readouterr().out
    assert '"input_token_limit": 128000' in out
    assert '"save": true' in out


def test_config_set_key_equals_value_no_save(monkeypatch, capsys):
    patch_client(monkeypatch)

    cli_main.main(["config", "set", "model=gpt-test", "--no-save", "--json"])

    out = capsys.readouterr().out
    assert '"model": "gpt-test"' in out
    assert '"save": false' in out


def test_run_streams_text(monkeypatch, capsys):
    patch_client(monkeypatch)

    cli_main.main(["run", "say", "hello"])

    assert capsys.readouterr().out == "hello\n"


def test_run_json_outputs_result(monkeypatch, capsys):
    patch_client(monkeypatch)

    cli_main.main(["run", "--json", "say", "hello"])

    out = capsys.readouterr().out
    assert '"ok": true' in out
    assert '"text": ""' in out
