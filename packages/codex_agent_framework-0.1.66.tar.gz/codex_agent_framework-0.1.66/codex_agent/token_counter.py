class TokenCounter:
    """Count tokens for a single object using minimal Responses input_tokens requests.

    The counter is object-oriented: each supported object provides a
    ``token_count_request(model=...)`` projection and stores its own cached
    result locally in ``token_count``.
    """

    def __init__(self, ai, default_model="gpt-5", baseline_text="PING"):
        self.ai = ai
        self.default_model = default_model
        self.baseline_text = baseline_text
        self._baseline_counts = {}

    def count_object(self, obj, model=None):
        model = str(model or self.default_model or "gpt-5")

        cached = self._cached_count(obj, model=model)
        if cached is not None:
            return cached

        observed = self._observed_count(obj)
        if observed is not None:
            return self._store_count(obj, observed, model=model)

        request = getattr(obj, "token_count_request", lambda model=None: None)(model=model)
        if request is None:
            if hasattr(obj, "count_tokens"):
                return int(obj.count_tokens(model=model))
            raise TypeError(f"{type(obj).__name__} does not support token counting")

        if self._needs_baseline(request):
            baseline = self._baseline_request(model=model)
            baseline_count = self._baseline_count(model=model)
            payload = dict(request)
            payload["input"] = baseline["input"]
            count = int(self.ai.count_input_tokens(**payload)) - baseline_count
        else:
            count = int(self.ai.count_input_tokens(**request))
        return self._store_count(obj, count, model=model)

    def hydrate(self, objects, model=None):
        return [self.count_object(obj, model=model) for obj in objects]

    def _baseline_request(self, model=None):
        return {
            "model": str(model or self.default_model or "gpt-5"),
            "input": [{
                "type": "message",
                "role": "user",
                "content": [{"type": "input_text", "text": self.baseline_text}],
            }],
        }

    def _baseline_count(self, model=None):
        model_key = str(model or self.default_model or "gpt-5")
        cached = self._baseline_counts.get(model_key)
        if cached is not None:
            return int(cached)
        count = int(self.ai.count_input_tokens(**self._baseline_request(model=model_key)))
        self._baseline_counts[model_key] = count
        return count

    def _needs_baseline(self, request):
        if not isinstance(request, dict):
            return False
        payload_input = request.get("input")
        if payload_input:
            return False
        return True

    def _observed_count(self, obj):
        observed = getattr(obj, "observed_token_count", None)
        if callable(observed):
            value = observed()
            if value is not None:
                return int(value)
        return None

    def _fingerprint(self, obj):
        if hasattr(obj, "api_token_fingerprint"):
            return obj.api_token_fingerprint()
        if hasattr(obj, "response_tool_fingerprint"):
            return obj.response_tool_fingerprint()
        return None

    def _cache_map(self, obj):
        token_count_cache = getattr(obj, "token_count_cache", None)
        if callable(token_count_cache):
            return token_count_cache()
        getter = getattr(obj, "get", None)
        if callable(getter):
            cache = getter("token_count") or {}
            return cache if isinstance(cache, dict) else {}
        return {}

    def _cached_count(self, obj, model=None):
        model_key = str(model or self.default_model or "gpt-5")
        fingerprint = self._fingerprint(obj)
        cache = self._cache_map(obj)
        cached = cache.get(model_key)
        if not isinstance(cached, dict):
            return None
        if fingerprint is not None and cached.get("fingerprint") != fingerprint:
            return None
        if "count" not in cached:
            return None
        return int(cached.get("count") or 0)

    def _store_count(self, obj, count, model=None):
        count = int(count or 0)
        cache_method = getattr(obj, "cache_token_count", None)
        if callable(cache_method):
            return int(cache_method(count, model=model))
        return count
