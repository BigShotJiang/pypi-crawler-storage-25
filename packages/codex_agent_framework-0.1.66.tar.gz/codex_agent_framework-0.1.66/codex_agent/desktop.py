"""Cross-platform-ish local desktop/window control helpers.

The public entry point is :class:`DesktopController`. It prefers PyWinCtl
when available because it provides the most portable Python window API, then
falls back to small native command backends for common Linux/X11 operations.

Wayland note: many compositors intentionally restrict global window listing,
activation, geometry control, and per-window screenshots. These helpers report
clear DesktopControlError failures instead of trying to bypass compositor
security. For reliable Linux desktop automation, an X11 session is currently
recommended.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import uuid
from dataclasses import dataclass
from typing import Any

from .utils import runtime_join


class DesktopControlError(RuntimeError):
    """Raised when no desktop/window backend can satisfy the request."""


@dataclass
class WindowInfo:
    id: str
    desktop: str | None = None
    pid: str | None = None
    x: int | None = None
    y: int | None = None
    width: int | None = None
    height: int | None = None
    wm_class: str | None = None
    title: str | None = None
    backend: str | None = None
    active: bool | None = None
    visible: bool | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "desktop": self.desktop,
            "pid": self.pid,
            "x": self.x,
            "y": self.y,
            "width": self.width,
            "height": self.height,
            "wm_class": self.wm_class,
            "title": self.title,
            "backend": self.backend,
            "active": self.active,
            "visible": self.visible,
        }


class DesktopController:
    """Utility facade for local desktop/window automation.

    The implementation is intentionally best-effort and backend-driven:
    - PyWinCtl, when installed, is used first for portable window listing and
      geometry/actions.
    - Linux/X11 command backends (wmctrl/xdotool) are kept for window and input control.
    - Screenshots use the Python mss backend only, to avoid desktop UI sounds/animations.
    """

    def __init__(self):
        self.live_session = False

    def start_live_session(self) -> None:
        """Enable live desktop context screenshots."""
        self.live_session = True

    def stop_live_session(self) -> None:
        """Disable live desktop context screenshots."""
        self.live_session = False

    def list_windows(self) -> list[WindowInfo]:
        """List visible local windows."""
        errors = []
        try:
            windows = self._list_windows_pywinctl()
            if windows:
                return windows
        except Exception as exc:  # pragma: no cover - backend dependent
            errors.append(f"PyWinCtl: {exc}")

        if shutil.which("wmctrl"):
            return self._list_windows_wmctrl()
        if shutil.which("xdotool"):
            return self._list_windows_xdotool()

        detail = "; ".join(errors)
        suffix = f" Tried: {detail}." if detail else ""
        raise DesktopControlError(
            "No window listing backend found. Install pywinctl or, on Linux/X11, wmctrl/xdotool."
            + suffix
        )

    def capture_screen(self, path: str | None = None) -> str:
        """Capture the full local desktop screen with mss and return the saved PNG path."""
        path = self._ensure_parent(path or self.screenshot_path("screen"))
        return self._capture_mss(path)

    def capture_window(self, window_id: str, path: str | None = None) -> str:
        """Capture a local window by id using mss screen cropping and return the saved PNG path."""
        if not window_id:
            raise DesktopControlError("window_id is required for window screenshots.")
        geometry = self._window_geometry(window_id)
        if geometry.x is None or geometry.y is None or geometry.width is None or geometry.height is None:
            raise DesktopControlError(f"Window geometry is unavailable for screenshot: {window_id}")
        path = self._ensure_parent(path or self.screenshot_path("window"))
        return self._capture_mss(
            path,
            left=geometry.x,
            top=geometry.y,
            width=geometry.width,
            height=geometry.height,
        )

    def activate_window(self, window_id: str) -> None:
        """Activate/focus a window by id when the current backend permits it."""
        if not window_id:
            raise DesktopControlError("window_id is required to activate a window.")
        if shutil.which("wmctrl"):
            self._run(["wmctrl", "-ia", str(window_id)])
            return
        if shutil.which("xdotool"):
            self._run(["xdotool", "windowactivate", str(window_id)])
            return
        raise DesktopControlError("No activate-window backend found. Install wmctrl or xdotool on Linux/X11.")

    def move_window(self, window_id: str, x: int, y: int) -> None:
        """Move a window to an absolute desktop position."""
        geometry = self._window_geometry(window_id)
        self._set_window_geometry(window_id, x=x, y=y, width=geometry.width, height=geometry.height)

    def resize_window(self, window_id: str, width: int, height: int) -> None:
        """Resize a window while keeping its current position when known."""
        geometry = self._window_geometry(window_id)
        self._set_window_geometry(window_id, x=geometry.x, y=geometry.y, width=width, height=height)

    def move_resize_window(self, window_id: str, x: int, y: int, width: int, height: int) -> None:
        """Move and resize a window in one operation."""
        self._set_window_geometry(window_id, x=x, y=y, width=width, height=height)

    def minimize_window(self, window_id: str) -> None:
        if shutil.which("xdotool"):
            self._run(["xdotool", "windowminimize", str(window_id)])
            return
        raise DesktopControlError("No minimize-window backend found. Install xdotool on Linux/X11.")

    def close_window(self, window_id: str) -> None:
        if shutil.which("wmctrl"):
            self._run(["wmctrl", "-ic", str(window_id)])
            return
        if shutil.which("xdotool"):
            self._run(["xdotool", "windowclose", str(window_id)])
            return
        raise DesktopControlError("No close-window backend found. Install wmctrl or xdotool on Linux/X11.")

    def mouse_location(self) -> dict[str, int | str]:
        """Return the current pointer location using xdotool."""
        if not shutil.which("xdotool"):
            raise DesktopControlError("No mouse-location backend found. Install xdotool on Linux/X11.")
        output = self._run(["xdotool", "getmouselocation", "--shell"]).stdout
        location: dict[str, int | str] = {}
        for line in output.splitlines():
            if "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.lower()
            location[key] = _safe_int(value) if key in {"x", "y", "screen", "window"} else value
        return location

    def move_mouse(self, x: int, y: int) -> None:
        """Move the pointer to an absolute screen position."""
        if not shutil.which("xdotool"):
            raise DesktopControlError("No mouse-move backend found. Install xdotool on Linux/X11.")
        self._run(["xdotool", "mousemove", "--sync", str(int(x)), str(int(y))])

    def click_mouse(self, button: int = 1, *, x: int | None = None, y: int | None = None, clicks: int = 1) -> None:
        """Click the mouse, optionally moving to an absolute screen position first."""
        if not shutil.which("xdotool"):
            raise DesktopControlError("No mouse-click backend found. Install xdotool on Linux/X11.")
        if clicks <= 0:
            raise DesktopControlError("clicks must be positive.")
        if button <= 0:
            raise DesktopControlError("mouse button must be positive.")
        if (x is None) != (y is None):
            raise DesktopControlError("x and y must be provided together for mouse clicks.")
        if x is not None and y is not None:
            self.move_mouse(x, y)
        command = ["xdotool", "click"]
        if clicks != 1:
            command.extend(["--repeat", str(int(clicks))])
        command.append(str(int(button)))
        self._run(command)

    def click_drag_release(self, x: int, y: int, to_x: int, to_y: int, button: int = 1) -> None:
        """Drag from one absolute screen coordinate to another, then release."""
        if not shutil.which("xdotool"):
            raise DesktopControlError("No mouse-drag backend found. Install xdotool on Linux/X11.")
        if button <= 0:
            raise DesktopControlError("mouse button must be positive.")
        self._run(["xdotool", "mousemove", "--sync", str(int(x)), str(int(y))])
        self._run(["xdotool", "mousedown", str(int(button))])
        self._run(["xdotool", "mousemove", "--sync", str(int(to_x)), str(int(to_y))])
        self._run(["xdotool", "mouseup", str(int(button))])

    def press(self, keys: str) -> None:
        """Press a key or key chord using xdotool syntax, e.g. Return or ctrl+l."""
        if not keys:
            raise DesktopControlError("keys is required.")
        if not shutil.which("xdotool"):
            raise DesktopControlError("No key-press backend found. Install xdotool on Linux/X11.")
        self._run(["xdotool", "key", "--clearmodifiers", str(keys)])

    def copy(self, text: str | None = None) -> None:
        """Copy explicit text to clipboard, or copy the current mouse/text selection."""
        if text is None:
            self.press("ctrl+c")
            return
        self.write_clipboard(text)

    def paste(self) -> None:
        """Paste the current clipboard at the focused cursor location."""
        self.press("ctrl+v")

    def write_clipboard(self, text: str) -> None:
        """Load text into the desktop clipboard using xclip."""
        if text is None:
            raise DesktopControlError("text is required.")
        if not shutil.which("xclip"):
            raise DesktopControlError("No clipboard backend found. Install xclip on Linux/X11.")
        self._run_stdin(["xclip", "-selection", "clipboard"], str(text))

    def screenshot_path(self, prefix: str) -> str:
        folder = runtime_join("images", "screenshots")
        os.makedirs(folder, exist_ok=True)
        return os.path.join(folder, f"{prefix}_{uuid.uuid4().hex[:12]}.png")

    def _list_windows_pywinctl(self) -> list[WindowInfo]:
        import pywinctl as pwc  # type: ignore[import-not-found]

        try:
            pywinctl_windows = pwc.getAllWindows()
        except KeyError as exc:
            if os.environ.get("XDG_SESSION_TYPE", "").lower() == "wayland":
                raise DesktopControlError(
                    "PyWinCtl failed while listing Wayland windows. "
                    "Wayland support is limited and may require compositor-specific unsafe/window APIs; "
                    "use an X11 session for reliable window control."
                ) from exc
            raise

        windows = []
        for index, window in enumerate(pywinctl_windows):
            title = getattr(window, "title", "") or ""
            if not title:
                continue
            windows.append(WindowInfo(
                id=self._pywinctl_window_id(window, index),
                x=_safe_int(getattr(window, "left", None)),
                y=_safe_int(getattr(window, "top", None)),
                width=_safe_int(getattr(window, "width", None)),
                height=_safe_int(getattr(window, "height", None)),
                title=title,
                backend="pywinctl",
                active=_safe_bool(getattr(window, "isActive", None)),
                visible=_safe_bool(getattr(window, "isVisible", None)),
            ))
        return windows

    def _pywinctl_window_id(self, window: Any, index: int) -> str:
        for attr in ("_hWnd", "_handle", "handle", "id"):
            value = getattr(window, attr, None)
            if value is not None:
                return str(value)
        return f"pywinctl:{index}:{getattr(window, 'title', '')}"

    def _list_windows_wmctrl(self) -> list[WindowInfo]:
        # wmctrl -lGpx: id desktop pid x y w h wm_class host title...
        output = self._run(["wmctrl", "-lGpx"]).stdout
        windows = []
        for line in output.splitlines():
            parts = line.split(maxsplit=9)
            if len(parts) < 9:
                continue
            title = parts[9] if len(parts) > 9 else ""
            windows.append(WindowInfo(
                id=parts[0],
                desktop=parts[1],
                pid=parts[2],
                x=_safe_int(parts[3]),
                y=_safe_int(parts[4]),
                width=_safe_int(parts[5]),
                height=_safe_int(parts[6]),
                wm_class=parts[7],
                title=title,
                backend="wmctrl",
            ))
        return windows

    def _list_windows_xdotool(self) -> list[WindowInfo]:
        output = self._run(["xdotool", "search", "--onlyvisible", "--name", "."]).stdout
        windows = []
        for window_id in output.splitlines():
            title = ""
            try:
                title = self._run(["xdotool", "getwindowname", window_id]).stdout.strip()
            except Exception:  # pragma: no cover - backend dependent
                pass
            windows.append(WindowInfo(id=window_id, title=title, backend="xdotool"))
        return windows

    def _window_geometry(self, window_id: str) -> WindowInfo:
        for window in self.list_windows():
            if window.id == str(window_id):
                return window
        raise DesktopControlError(f"Window not found: {window_id}")

    def _set_window_geometry(
        self,
        window_id: str,
        *,
        x: int | None,
        y: int | None,
        width: int | None,
        height: int | None,
    ) -> None:
        if not window_id:
            raise DesktopControlError("window_id is required to change window geometry.")
        if width is not None and width <= 0:
            raise DesktopControlError("window width must be positive.")
        if height is not None and height <= 0:
            raise DesktopControlError("window height must be positive.")

        if shutil.which("wmctrl"):
            # Gravity,x,y,width,height. wmctrl expects a valid gravity value;
            # use 0 (NorthWestGravity), while -1 keeps optional fields unchanged.
            geometry = ",".join(str(value if value is not None else -1) for value in (0, x, y, width, height))
            self._run(["wmctrl", "-ir", str(window_id), "-e", geometry])
            return
        if shutil.which("xdotool"):
            if x is not None and y is not None:
                self._run(["xdotool", "windowmove", str(window_id), str(x), str(y)])
            if width is not None and height is not None:
                self._run(["xdotool", "windowsize", str(window_id), str(width), str(height)])
            return
        raise DesktopControlError("No window geometry backend found. Install wmctrl or xdotool on Linux/X11.")

    def _capture_mss(
        self,
        path: str,
        *,
        left: int | None = None,
        top: int | None = None,
        width: int | None = None,
        height: int | None = None,
    ) -> str:
        """Capture the desktop using mss only, with no native screenshot UI fallback."""
        try:
            import mss  # type: ignore[import-not-found]
        except ImportError as exc:
            raise DesktopControlError("Screenshot capture requires the Python dependency 'mss'.") from exc

        try:
            import mss.tools  # type: ignore[import-not-found]

            with mss.mss() as sct:
                if left is None and top is None and width is None and height is None:
                    monitor = sct.monitors[0]
                else:
                    if None in (left, top, width, height):
                        raise DesktopControlError("left, top, width and height are required together for region capture.")
                    monitor = {
                        "left": int(left),
                        "top": int(top),
                        "width": int(width),
                        "height": int(height),
                    }
                screenshot = sct.grab(monitor)
                mss.tools.to_png(screenshot.rgb, screenshot.size, output=path)
        except DesktopControlError:
            raise
        except Exception as exc:  # pragma: no cover - backend/display dependent
            raise DesktopControlError(f"mss screenshot capture failed: {exc}") from exc

        if not os.path.isfile(path) or os.path.getsize(path) <= 0:
            raise DesktopControlError("mss screenshot capture failed: output file was not created.")
        return path

    def _run(self, command: list[str]) -> subprocess.CompletedProcess:
        return subprocess.run(command, check=True, capture_output=True, text=True)

    def _run_stdin(self, command: list[str], text: str) -> subprocess.CompletedProcess:
        return subprocess.run(command, input=text, check=True, capture_output=True, text=True)

    def _ensure_parent(self, path: str) -> str:
        path = os.path.abspath(os.path.expanduser(path))
        os.makedirs(os.path.dirname(path), exist_ok=True)
        return path


_desktop_controller = DesktopController()


def get_desktop_controller() -> DesktopController:
    """Return the process-wide DesktopController singleton shared by tools/providers."""
    return _desktop_controller


def _safe_int(value: Any) -> int | None:
    try:
        return None if value is None else int(value)
    except (TypeError, ValueError):
        return None


def _safe_bool(value: Any) -> bool | None:
    return None if value is None else bool(value)
