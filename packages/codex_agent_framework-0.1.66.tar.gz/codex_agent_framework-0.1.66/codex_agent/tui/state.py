import time


class LiveDeltaBuffer:
    """Coalesce live text deltas before touching the Textual render loop.

    Live text should feel immediate, but repainting on every micro-delta can
    still overwhelm Textual during bursty model output. We therefore flush as
    soon as possible while capping render frequency to a TUI-friendly maximum.
    """

    def __init__(self, interval=1 / 30):
        self.interval = interval
        self.text = ""
        self.flush_requested = False
        self.last_flush_at = None

    def push(self, delta):
        if not delta:
            return False
        self.text += str(delta)
        return True

    def ready_to_flush(self, now=None):
        if not self.text:
            return False
        now = time.monotonic() if now is None else float(now)
        if self.last_flush_at is None:
            return True
        return (now - self.last_flush_at) >= self.interval

    def delay_until_flush(self, now=None):
        if not self.text:
            return 0.0
        now = time.monotonic() if now is None else float(now)
        if self.last_flush_at is None:
            return 0.0
        return max(0.0, self.interval - (now - self.last_flush_at))

    def pop(self, now=None):
        text = self.text
        self.text = ""
        self.flush_requested = False
        if text:
            self.last_flush_at = time.monotonic() if now is None else float(now)
        return text

    def mark_flush_requested(self):
        if self.flush_requested:
            return False
        self.flush_requested = True
        return True


class ReplayDeltaBuffer:
    def __init__(self):
        self.text = ""

    def clear(self):
        self.text = ""

    def push(self, delta):
        if delta:
            self.text += str(delta)
        return self.text

    def pop(self):
        text = self.text
        self.text = ""
        return text

    def __bool__(self):
        return bool(self.text)


class TuiAppBridge:
    """Thread-aware typed bridge from chat event handlers to the Textual app."""

    def __init__(self, chat):
        self.chat = chat

    @property
    def app(self):
        return self.chat.app

    def call(self, method, *args, skip_during_replay=False):
        if skip_during_replay and self.chat.replaying_events:
            return None
        if self.app is None:
            return None
        perf = getattr(self.app, "perf", None)
        if perf is not None:
            perf.count("bridge_call_from_thread")
            perf.count(f"bridge_call_from_thread.{method}")
        stream_debug = getattr(self.app, "stream_debug", None)
        if stream_debug is not None:
            stream_debug.record("bridge_schedule", method=method, args_count=len(args))
        callback = getattr(self.app, method)

        def traced_callback(*callback_args):
            if stream_debug is not None:
                stream_debug.record("ui_callback_begin", method=method, args_count=len(callback_args))
            try:
                result = callback(*callback_args)
                if stream_debug is not None:
                    stream_debug.record("ui_callback_done", method=method, args_count=len(callback_args))
                return result
            except Exception as exc:
                if stream_debug is not None:
                    stream_debug.record("ui_callback_error", method=method, error=str(exc), args_count=len(callback_args))
                raise

        return self.app.call_from_thread(traced_callback, *args)

    def refresh_status(self):
        return self.call("refresh_status", skip_during_replay=True)

    def begin_transcript_batch(self):
        return self.call("begin_transcript_batch")

    def end_transcript_batch(self):
        return self.call("end_transcript_batch")

    def exit(self):
        return self.call("exit")

    def start_agent_step(self):
        return self.call("start_agent_step")

    def end_agent_step(self):
        return self.call("end_agent_step")

    def schedule_agent_delta_flush(self, delay=None):
        if delay is None:
            return self.call("schedule_agent_delta_flush")
        return self.call("schedule_agent_delta_flush", delay)

    def flush_agent_delta(self):
        return self.call("flush_agent_delta")

    def write_user(self, prompt):
        return self.call("write_user", prompt)

    def write_agent_start(self, name):
        return self.call("write_agent_start", name)

    def write_agent_delta(self, delta):
        return self.call("write_agent_delta", delta)

    def write_agent_message(self, content):
        return self.call("write_agent_message", content)

    def write_tool(self, name, call_id=None, status=None):
        return self.call("write_tool", name, call_id, status)

    def write_slash_command(self, name, args="", status=None):
        return self.call("write_slash_command", name, args, status)

    def write_info(self, text):
        return self.call("write_info", text)

    def write_error(self, text):
        return self.call("write_error", text)


class DisplayDeduper:
    """Track already-rendered transient TUI items.

    Event ids are global for the client lifetime; tool/slash items are scoped to the
    current assistant turn and should be reset when a new turn starts.
    """

    def __init__(self):
        self.event_ids = set()
        self.turn_tool_items = set()
        self.turn_slash_items = set()

    def remember_event(self, event):
        event_id = event.get("id") if event else None
        if not event_id:
            return True
        if event_id in self.event_ids:
            return False
        self.event_ids.add(event_id)
        return True

    def reset_turn_scope(self):
        self.turn_tool_items.clear()
        self.turn_slash_items.clear()

    def remember_tool(self, call_id, status=None):
        key = (call_id, status or "running")
        if key in self.turn_tool_items:
            return False
        self.turn_tool_items.add(key)
        return True

    def remember_slash_command(self, name, args="", status=None):
        key = (name, args, status or "running")
        if key in self.turn_slash_items:
            return False
        self.turn_slash_items.add(key)
        return True
