CHAT_CSS = """
Screen {
    background: #000000;
    color: #aeb0aa;
}
Screen > .screen--selection {
    background: #6f98bd;
    color: #000000;
}
#main {
    height: 100%;
    padding: 0 1;
    background: #000000;
}
#conversation {
    height: 1fr;
    padding: 1 1;
    background: #000000;
    scrollbar-background: #000000;
    scrollbar-background-hover: #000000;
    scrollbar-background-active: #000000;
    scrollbar-color: #202020;
    scrollbar-color-hover: #2a2a2a;
    scrollbar-color-active: #343434;
}
.role-header {
    width: 100%;
    height: 1;
    padding: 0;
    margin: 0 0 1 0;
    content-align: center middle;
}
.message {
    width: 100%;
    padding: 0 0 1 0;
    margin: 0;
    color: #aeb0aa;
}
.message.user {
    color: #d6e4c9;
}
.message.assistant {
    color: #aeb0aa;
}
.message.assistant.live {
    color: #c6c8c2;
}
.message.tool,
.message.slash-command {
    height: 1;
    padding: 0;
    margin: 0;
    color: #7d8590;
}
.message.info,
.message.error {
    height: 1;
    padding: 0;
    margin: 0;
}
.message.info {
    color: #8b949e;
}
.message.error {
    color: #ff7b72;
}
.step-marker {
    width: 100%;
    height: 1;
    padding: 0;
    margin: 0 0 1 0;
    content-align: right middle;
    color: #6f98bd;
}
#status {
    height: 1;
    color: #8b949e;
    background: #161b22;
    padding: 0 1;
}
#input {
    height: 3;
    margin-top: 0;
    padding: 0 1;
    background: #000000;
    color: #aeb0aa;
    border: blank #000000;
    scrollbar-size-vertical: 1;
    scrollbar-size-horizontal: 0;
    scrollbar-background: #000000;
    scrollbar-background-hover: #000000;
    scrollbar-background-active: #000000;
    scrollbar-color: #202020;
    scrollbar-color-hover: #2a2a2a;
    scrollbar-color-active: #343434;
}
TextArea > .text-area--cursor {
    background: #6f98bd;
    color: #0d1117;
}
Footer {
    background: #000000;
    color: #7d8590;
}
"""
