import json
import os
import time
from contextlib import contextmanager
from pathlib import Path


class TuiPerfMonitor:
    """Tiny in-process profiler for diagnosing TUI stream stalls.

    The monitor keeps only counters and cumulative timings in memory, then writes
    an atomic JSON snapshot. It is intentionally small enough to leave enabled
    during local debugging without needing ptrace/py-spy access.
    """

    def __init__(self, path=None):
        self.path = Path(path or os.path.expanduser("~/.codex-agent/tui-perf.json"))
        self.started_at = time.monotonic()
        self.reset_window()

    def reset_window(self):
        self.window_started_at = time.monotonic()
        self.counts = {}
        self.timings = {}
        self.last = {}

    def count(self, name, value=1):
        self.counts[name] = self.counts.get(name, 0) + value

    def set_last(self, name, value):
        self.last[name] = value

    @contextmanager
    def timed(self, name):
        start = time.perf_counter()
        try:
            yield
        finally:
            elapsed = time.perf_counter() - start
            total, count, max_elapsed = self.timings.get(name, (0.0, 0, 0.0))
            self.timings[name] = (total + elapsed, count + 1, max(max_elapsed, elapsed))

    def snapshot(self, extra=None):
        now = time.monotonic()
        window_seconds = max(1e-9, now - self.window_started_at)
        timings = {}
        for name, (total, count, max_elapsed) in self.timings.items():
            timings[name] = {
                "count": count,
                "total_ms": round(total * 1000, 3),
                "avg_ms": round((total / count) * 1000, 3) if count else 0.0,
                "max_ms": round(max_elapsed * 1000, 3),
            }
        return {
            "pid": os.getpid(),
            "uptime_seconds": round(now - self.started_at, 3),
            "window_seconds": round(window_seconds, 3),
            "rates_per_second": {key: round(value / window_seconds, 3) for key, value in self.counts.items()},
            "counts": dict(self.counts),
            "timings": timings,
            "last": dict(self.last),
            "extra": dict(extra or {}),
        }

    def write_snapshot(self, extra=None, *, reset=True):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = self.snapshot(extra=extra)
        tmp_path = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
        tmp_path.replace(self.path)
        if reset:
            self.reset_window()
        return payload
