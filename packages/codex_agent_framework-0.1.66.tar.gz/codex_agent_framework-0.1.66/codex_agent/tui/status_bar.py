from rich.text import Text


class StatusBar:
    @classmethod
    def render(cls, status):
        percent = float(status.get("context_percent") or 0)
        used = cls._format_ktok(status.get("context_current_tokens") or 0)
        limit = cls._format_ktok(status.get("context_limit_tokens") or 0)
        return Text.assemble(
            (" ctx ", "bold #c9d1d9 on #161b22"),
            *cls._context_token_segments(status, used, limit),
            (" ", "#8b949e on #161b22"),
            (f"{percent:.1f}%", f"{cls._percent_style(percent)} on #161b22"),
            ("  msg ", "#6e7681 on #161b22"),
            *cls._message_segments(status),
            ("  cmp ", "#6e7681 on #161b22"),
            (str(int(status.get("compactable_turns") or 0)), "#c9d1d9 on #161b22"),
            ("  5h ", "#6e7681 on #161b22"),
            (cls._format_percent(status.get("quota_5h_percent")), f"{cls._percent_style(status.get('quota_5h_percent'))} on #161b22"),
            ("  7d ", "#6e7681 on #161b22"),
            (cls._format_percent(status.get("quota_7d_percent")), f"{cls._percent_style(status.get('quota_7d_percent'))} on #161b22"),
            ("  model ", "#6e7681 on #161b22"),
            (str(status.get("model") or "-"), "#c9d1d9 on #161b22"),
        )

    @classmethod
    def _context_token_segments(cls, status, used, limit):
        if (
            "base_context_tokens" not in status
            and "provider_context_tokens" not in status
            and "active_wrapper_tokens" not in status
            and "vanished_wrapper_tokens" not in status
        ):
            return ((f"{used}/{limit} ktok", "#8b949e on #161b22"),)
        base_tokens = status.get("base_context_tokens") or 0
        provider_tokens = status.get("provider_context_tokens") or 0
        active_wrapper_tokens = status.get("active_wrapper_tokens") or 0
        vanished_wrapper_tokens = status.get("vanished_wrapper_tokens") or 0
        active_total = cls._format_ktok(base_tokens + provider_tokens + active_wrapper_tokens)
        segments = [
            (cls._format_ktok(base_tokens), "#c9d1d9 on #161b22"),
        ]
        segments.extend([
            (f"(+{cls._format_ktok(vanished_wrapper_tokens)})", "italic #6e7681 on #161b22"),
            (f"+{cls._format_ktok(active_wrapper_tokens)}", "italic #f0883e on #161b22"),
        ])
        if provider_tokens:
            segments.append((f"+{cls._format_ktok(provider_tokens)}", "italic #58a6ff on #161b22"))
        segments.extend([
            ("=", "#8b949e on #161b22"),
            (active_total, "#c9d1d9 on #161b22"),
            (f"/{limit} ktok", "#8b949e on #161b22"),
        ])
        return tuple(segments)

    @classmethod
    def _message_segments(cls, status):
        sent = int(status.get("sent_session_messages") or 0)
        total = int(status.get("total_session_messages") or 0)
        if "active_wrapper_messages" in status or "vanished_wrapper_messages" in status:
            persistent = int(status.get("persistent_session_messages") or 0)
            active_wrappers = int(status.get("active_wrapper_messages") or 0)
            vanished_wrappers = int(status.get("vanished_wrapper_messages") or 0)
            active_total = persistent + active_wrappers
            return (
                (str(persistent), "#c9d1d9 on #161b22"),
                (f"(+{vanished_wrappers})", "italic #6e7681 on #161b22"),
                (f"+{active_wrappers}", "italic #f0883e on #161b22"),
                ("=", "#8b949e on #161b22"),
                (str(active_total), "#c9d1d9 on #161b22"),
                (f"/{total}", "#8b949e on #161b22"),
            )
        if "persistent_session_messages" in status or "temporary_session_messages" in status:
            return (
                (f"{sent}/{total}", "#c9d1d9 on #161b22"),
                ("  ctxmsg ", "#6e7681 on #161b22"),
                (str(int(status.get("persistent_session_messages") or 0)), "#c9d1d9 on #161b22"),
                (f"+{int(status.get('temporary_session_messages') or 0)}", "italic #f0883e on #161b22"),
            )
        return ((f"{sent}/{total}", "#c9d1d9 on #161b22"),)

    @staticmethod
    def _format_ktok(value):
        try:
            return f"{float(value) / 1000:.1f}"
        except Exception:
            return str(value)

    @staticmethod
    def _format_percent(value):
        if value is None:
            return "-"
        try:
            return f"{float(value):.0f}%"
        except Exception:
            return str(value)

    @staticmethod
    def _percent_style(value):
        try:
            percent = float(value)
        except Exception:
            return "#6e7681"
        if percent >= 90:
            return "bold #ff7b72"
        if percent >= 75:
            return "#f0883e"
        if percent >= 50:
            return "#d29922"
        return "#3fb950"
