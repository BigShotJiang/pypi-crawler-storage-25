import os

from textual.app import App, ComposeResult
from textual.containers import Vertical
from textual.events import Resize
from textual.widgets import Footer, Static, TextArea

from .lifecycle import clear_tui, install_tui_cleanup_handlers
from .perf import TuiPerfMonitor
from .stream_debug import TuiStreamDebugLog
from .style import CHAT_CSS
from .widgets import ConversationTimeline


def composer_height(text):
    useful_lines = max(1, min(10, str(text or "").count("\n") + 1))
    return useful_lines + 2


class AgentTextualApp(App):
    CSS = CHAT_CSS
    TITLE = "Codex Agent"
    BINDINGS = [
        ("ctrl+c", "interrupt", "Interrupt"),
        ("ctrl+l", "clear", "Clear"),
        ("ctrl+q", "quit", "Quit"),
        ("ctrl+s", "submit", "Submit"),
        ("alt+enter", "submit", "Submit"),
        ("ctrl+enter", "submit", "Submit"),
        ("f2", "submit", "Submit"),
    ]

    def __init__(self, chat, mouse_mode_hint, **kwargs):
        super().__init__(**kwargs)
        self.chat = chat
        self.mouse_mode_hint = mouse_mode_hint
        self._live_delta_flush_scheduled = False
        self.perf = TuiPerfMonitor()
        self.stream_debug = TuiStreamDebugLog()

    def compose(self) -> ComposeResult:
        with Vertical(id="main"):
            yield ConversationTimeline(id="conversation")
            yield Static("", id="status")
            yield TextArea(
                "",
                placeholder=f"> message  -  Enter = newline  -  Ctrl+S/F2 = send  -  {self.mouse_mode_hint}",
                id="input",
                show_line_numbers=False,
                soft_wrap=True,
            )
        yield Footer()

    def on_mount(self):
        self.chat.app = self
        self.chat.client.stream_debug = self.stream_debug
        self.stream_debug.record("tui_mount")
        install_tui_cleanup_handlers()
        self.chat.attach()
        self.chat.client.start_events()
        self.refresh_status()
        self.resize_input()
        self.query_one("#input", TextArea).focus()
        self.set_interval(1.0, self.write_perf_snapshot)
        self.write_info(f"Codex Agent client ready - {self.mouse_mode_hint}")

    def on_resize(self, event: Resize):
        self.handle_terminal_resize()

    def handle_terminal_resize(self, *, log_resized=False):
        self.resize_input()
        self.refresh_status()

    def on_unmount(self):
        self.stream_debug.record("tui_unmount")
        clear_tui(pid=os.getpid())

    def action_quit(self):
        clear_tui(pid=os.getpid())
        self.chat.client.stop(timeout=0.2)
        self.exit()

    def action_submit(self):
        input_widget = self.query_one("#input", TextArea)
        prompt = input_widget.text
        command = prompt.strip().lower()
        if not command:
            return
        if command in ["exit", "quit", "/exit", "/quit"]:
            self.exit()
            return
        if command == "/clear":
            input_widget.load_text("")
            self.action_clear()
            return
        if command in ("/new_session", "/new"):
            input_widget.load_text("")
            self.refresh_status()
            self.run_worker(self._new_session_from_client_cwd, thread=True)
            return
        input_widget.load_text("")
        self.refresh_status()
        self.run_worker(lambda: self._submit_prompt(prompt), thread=True)

    def action_clear(self):
        self.chat.transcript.clear()
        self.conversation.clear_messages()
        self.write_info("screen cleared - session history preserved")
        self.refresh_status()

    def action_interrupt(self):
        if self.screen.get_selected_text():
            self.screen.action_copy_text()
            return
        result = self.chat.client.interrupt("keyboard_interrupt")
        self.write_error(f"interrupt requested - {result.error}" if result.get("error") else "interrupt requested")

    def on_text_area_changed(self, event: TextArea.Changed):
        if event.text_area.id == "input":
            self.resize_input()

    def resize_input(self):
        input_widget = self.query_one("#input", TextArea)
        input_widget.styles.height = composer_height(input_widget.text)

    def _new_session_from_client_cwd(self):
        try:
            session = self.chat.client.new_session(root_dir=os.getcwd(), cwd=os.getcwd())
            self.call_from_thread(self.write_info, f"Created session: {session.get('session_id')}")
        except Exception as exc:
            self.call_from_thread(self.write_error, str(exc))
        finally:
            self.call_from_thread(self.refresh_status)

    def _submit_prompt(self, prompt):
        try:
            self.chat.client.submit_prompt(prompt)
            self.chat.resync_from_status()
        except Exception as exc:
            self.call_from_thread(self.write_error, str(exc))
        finally:
            self.call_from_thread(self.refresh_status)

    @property
    def conversation(self):
        return self.query_one("#conversation", ConversationTimeline)

    def render_transcript(self, *, keep_scroll=False):
        # The widget timeline is updated incrementally. This method remains as a
        # compatibility shim for older call sites during the migration.
        return None

    def begin_transcript_batch(self):
        self.conversation.begin_batch()

    def end_transcript_batch(self):
        self.conversation.end_batch()

    def load_older_transcript(self):
        return None

    def write_user(self, prompt):
        self.chat.transcript.append_user(prompt, self.chat.username())
        self.conversation.add_user(prompt, title=self.chat.username())

    def ensure_agent_role(self, name=None):
        self.chat.transcript.ensure_agent(name or self.chat.agent_name())
        return self.conversation.ensure_active_assistant(title=name or self.chat.agent_name())

    def write_agent_start(self, name):
        self.chat.begin_turn_rendering()

    def start_agent_step(self):
        self.chat.transcript.begin_step()

    def write_agent_delta(self, delta):
        self.stream_debug.record("ui_render_delta_begin", delta_len=len(str(delta or "")))
        self.perf.count("write_agent_delta")
        self.perf.count("write_agent_delta_chars", len(str(delta or "")))
        with self.perf.timed("write_agent_delta"):
            self.ensure_agent_role()
            self.chat.transcript.apply_agent_delta(delta)
            self.chat.transcript.step_had_content = True
            self.conversation.append_assistant_delta(delta, title=self.chat.agent_name())
        self.stream_debug.record("ui_render_delta_done", delta_len=len(str(delta or "")), live_chars=len(self.conversation._active_assistant_text))

    def write_agent_message(self, content):
        self.ensure_agent_role()
        self.chat.transcript.agent_buffer = str(content or "")
        if self.chat.transcript.entries and self.chat.transcript.entries[-1].kind == "agent":
            self.chat.transcript.entries[-1].text = self.chat.transcript.agent_buffer
        self.conversation.add_assistant_message(content, title=self.chat.agent_name())

    def schedule_agent_delta_flush(self, delay=None):
        self.perf.count("schedule_agent_delta_flush")
        if self._live_delta_flush_scheduled:
            return
        self._live_delta_flush_scheduled = True
        delay = self.chat.live_delta.interval if delay is None else max(0.0, float(delay))
        self.set_timer(delay, self.flush_agent_delta)

    def flush_agent_delta(self):
        self.perf.count("flush_agent_delta")
        with self.perf.timed("flush_agent_delta"):
            self._live_delta_flush_scheduled = False
            delta = self.chat.live_delta.pop()
            if delta:
                self.write_agent_delta(delta)

    def write_tool(self, name, call_id=None, status=None):
        self.flush_agent_delta()
        self.conversation.commit_active_assistant_preview()
        self.chat.transcript.append_tool(name, call_id=call_id, status=status)
        self.conversation.add_tool(name, call_id=call_id, status=status)

    def write_slash_command(self, name, args="", status=None):
        self.flush_agent_delta()
        self.conversation.commit_active_assistant_preview()
        self.chat.transcript.append_slash_command(name, args=args, status=status)
        self.conversation.add_slash_command(name, args=args, status=status)

    def end_agent_step(self):
        self.flush_agent_delta()
        self.conversation.commit_active_assistant_preview()
        self.chat.transcript.end_step()
        self.conversation.add_step_separator()

    def write_info(self, text):
        self.chat.transcript.append_info(text)
        self.conversation.add_info(text)

    def write_error(self, text):
        self.chat.transcript.append_error(text)
        self.conversation.add_error(text)

    def refresh_status(self):
        self.perf.count("refresh_status")
        with self.perf.timed("refresh_status"):
            self.query_one("#status", Static).update(self.chat.status_renderable())

    def write_perf_snapshot(self):
        client = self.chat.client
        queue_obj = getattr(client, "_local_event_queue", None)
        extra = {
            "entries": len(self.chat.transcript.entries),
            "live_buffer_chars": len(self.conversation._active_assistant_text),
            "pending_live_delta_chars": len(self.chat.live_delta.text),
            "last_event_sequence": getattr(client, "_last_event_sequence", None),
            "event_queue_size": queue_obj.qsize() if queue_obj is not None else None,
            "event_stream_connected": getattr(client, "_event_stream_connected", None),
            "live_delta_flush_scheduled": self._live_delta_flush_scheduled,
        }
        self.perf.write_snapshot(extra=extra)
        self.stream_debug.record("tui_heartbeat", **extra)
