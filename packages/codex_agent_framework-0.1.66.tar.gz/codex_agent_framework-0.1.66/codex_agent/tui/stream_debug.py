from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path


class TuiStreamDebugLog:
    """Append-only black-box log for intermittent TUI stream stalls.

    The file is intentionally outside the Textual render path and is flushed on
    every record. When the UI stops updating but the process stays alive, the
    last records should reveal whether events stopped at SSE receive, queue,
    dispatch, bridge scheduling, or actual widget rendering.
    """

    def __init__(self, path=None, *, max_bytes=5_000_000):
        self.path = Path(path or os.path.expanduser("~/.codex-agent/tui-stream-debug.jsonl"))
        self.max_bytes = int(max_bytes or 0)
        self._lock = threading.Lock()
        self._started_at = time.monotonic()

    def record(self, stage, event=None, **fields):
        payload = {
            "ts": round(time.time(), 6),
            "monotonic": round(time.monotonic(), 6),
            "uptime": round(time.monotonic() - self._started_at, 6),
            "pid": os.getpid(),
            "thread": threading.current_thread().name,
            "stage": str(stage),
        }
        payload.update(self.event_fields(event))
        payload.update(fields)
        line = json.dumps(payload, ensure_ascii=False, default=str, sort_keys=True)
        with self._lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self._trim_if_needed()
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(line + "\n")
                handle.flush()
        return payload

    def event_fields(self, event):
        if not isinstance(event, dict):
            return {}
        payload = {
            "event_type": event.get("type"),
            "event_id": event.get("id"),
            "sequence": event.get("sequence"),
        }
        if "delta" in event:
            payload["delta_len"] = len(str(event.get("delta") or ""))
        if "content" in event:
            payload["content_len"] = len(str(event.get("content") or ""))
            payload["content_truncated"] = bool(event.get("content_truncated"))
            payload["content_full_length"] = event.get("content_full_length")
        message = event.get("message")
        if isinstance(message, dict):
            payload["message_type"] = message.get("type")
            payload["message_content_len"] = len(str(message.get("content") or ""))
        tool_call = event.get("tool_call")
        if isinstance(tool_call, dict):
            payload["tool_name"] = tool_call.get("name")
            payload["tool_call_id"] = tool_call.get("call_id")
        if "error" in event:
            payload["error"] = str(event.get("error") or "")[:500]
        return payload

    def _trim_if_needed(self):
        if self.max_bytes <= 0 or not self.path.exists():
            return
        try:
            if self.path.stat().st_size <= self.max_bytes:
                return
            data = self.path.read_bytes()[-self.max_bytes // 2:]
            first_newline = data.find(b"\n")
            if first_newline >= 0:
                data = data[first_newline + 1:]
            self.path.write_bytes(data)
        except Exception:
            # Debug logging must never break the TUI.
            return
