import inspect

from .event import RuntimeStateChangedEvent

from modict import modict


PROVIDER_MARKER = "__codex_agent_provider__"


def provider(func=None, **options):
    """Mark a function as an agent context provider for automatic discovery."""
    if func is None:
        def decorator(f):
            return provider(f, **options)
        return decorator

    setattr(func, PROVIDER_MARKER, modict(options))
    return func


def provider_options(func):
    """Return provider decorator metadata from a function or bound method."""
    options = getattr(func, PROVIDER_MARKER, None)
    if options is not None:
        return options
    return getattr(getattr(func, "__func__", None), PROVIDER_MARKER, None)


class ProvidersManager:
    """Registry for context providers contributed by the agent and plugins."""

    def __init__(self, agent):
        self.agent = agent
        self.providers = modict()
        self.owners = modict()

    def add_from_module(self, module, filter=None, owner=None):
        for name, obj in module.__dict__.items():
            if filter is not None and not filter(name, obj):
                continue
            self.add_object(obj, owner=owner)

    def add_from_object(self, obj, owner=None):
        for _, member in inspect.getmembers(obj):
            self.add_object(member, owner=owner)

    def add_object(self, obj, owner=None):
        options = provider_options(obj)
        if options is not None:
            self.add(obj, owner=owner, **options)

    def add(self, func=None, name=None, owner=None):
        if func is None:
            def decorator(f):
                return self.add(f, name=name, owner=owner)
            return decorator

        if self.agent.mainloop_manager.should_queue_state_command():
            return self.agent.submit("add_provider", func=func, name=name, owner=owner).wait().result

        provider_name = name or getattr(func, "__name__", None) or f"provider_{len(self.providers)}"
        self.providers[provider_name] = func
        if owner is not None:
            self.owners[provider_name] = owner
        else:
            self.owners.pop(provider_name, None)
        self.agent.emit(RuntimeStateChangedEvent, reason="provider_added", namespace="providers", name=provider_name, owner=owner or "", details=func)
        return func

    def remove_by_owner(self, owner):
        removed = modict()
        for name, registered_owner in list(self.owners.items()):
            if registered_owner == owner:
                removed[name] = self.providers.pop(name, None)
                self.owners.pop(name, None)
        if removed:
            self.agent.emit(RuntimeStateChangedEvent, reason="providers_removed", namespace="providers", owner=owner or "", details=removed)
        return removed
