from modict import modict
from .utils import short_id, snake_case_type, timestamp, format, type_hierarchy
import base64
import hashlib
import json
from textwrap import dedent
from xml.sax.saxutils import escape, quoteattr


OUTPUT_ITEMS_ATTR = "_output_items"


class MessageChunk(modict):
    """Streaming chunk emitted by the model."""

    content = ''
    reasoning = ''
    tool_calls = None
    output_items = None


class Message(modict):
    """Base persisted message.

    Concrete subclasses own API formatting. The ``types`` field mirrors the
    inheritance hierarchy from generic to concrete. ``type`` is computed from
    the last entry for compatibility with existing consumers.
    """

    content = ''
    name = ''
    types = modict.factory(list)
    reasoning = ''
    id = modict.factory(lambda: short_id())
    session_id = None
    timestamp = modict.factory(lambda: timestamp())
    turns_left = -1
    embedding = None
    token_count = modict.factory(dict)
    estimated_token_count = modict.factory(dict)

    def __init__(self, *args, **kwargs):
        args, kwargs, legacy_type = self.prepare_init_types(args, kwargs)
        super().__init__(*args, **kwargs)
        if not self.get('types'):
            self.types = self.default_types(legacy_type=legacy_type)

    @classmethod
    def prepare_init_types(cls, args, kwargs):
        kwargs = dict(kwargs)
        legacy_type = kwargs.pop('type', None)
        if args and isinstance(args[0], dict):
            data = dict(args[0])
            legacy_type = data.pop('type', legacy_type)
            args = (data, *args[1:])
        return args, kwargs, legacy_type

    @classmethod
    def default_types(cls, legacy_type=None):
        types = type_hierarchy(cls, Message)
        if legacy_type and legacy_type not in types:
            types.append(legacy_type)
        return types

    @modict.computed(deps=["types"])
    def type(self):
        return (self.get('types') or self.default_types())[-1]

    def format(self, context=None):
        return type(self)(self)

    def text_part(self, output=False):
        text_type = "output_text" if output else "input_text"
        return {"type": text_type, "text": str(self.get('content') or "")}

    def content_to_response_parts(self, output=False):
        content = self.get("content", "")
        if not isinstance(content, list):
            return [self.text_part(output=output)]

        text_type = "output_text" if output else "input_text"
        parts = []
        for part in content:
            if isinstance(part, str):
                parts.append({"type": text_type, "text": part})
            elif isinstance(part, dict) and part.get("type") == "text":
                parts.append({"type": text_type, "text": part.get("text", "")})
            else:
                parts.append(dict(part))
        return parts

    def to_response_format(self):
        raise NotImplementedError(f"{type(self).__name__} must implement to_response_format()")

    def token_count_cache(self):
        cache = self.get("token_count")
        if isinstance(cache, dict) and cache:
            return cache
        legacy = self.get("estimated_token_count")
        if isinstance(legacy, dict) and legacy:
            self.token_count = dict(legacy)
            return self.token_count
        self.token_count = {}
        return self.token_count

    def cache_token_count(self, count, model=None):
        model_key = str(model or "gpt-5")
        cache = self.token_count_cache()
        cache[model_key] = {
            "fingerprint": self.api_token_fingerprint(),
            "count": int(count or 0),
        }
        self.token_count = cache
        self.estimated_token_count = dict(cache)
        return int(count or 0)

    def count_tokens(self, model=None):
        model_key = str(model or "gpt-5")
        fingerprint = self.api_token_fingerprint()
        cache = self.token_count_cache()
        cached = cache.get(model_key)
        if isinstance(cached, dict) and cached.get("fingerprint") == fingerprint:
            return int(cached.get("count") or 0)

        count = int(self.compute_api_token_count(model=model) or 0)
        return self.cache_token_count(count, model=model)

    def api_token_count(self, model=None):
        return self.count_tokens(model=model)

    @modict.computed()
    def effective_token_count(self):
        if self.get("turns_left", -1) == 0:
            return 0
        return self.count_tokens()

    @modict.computed()
    def effective_api_token_count(self):
        return self.effective_token_count

    def api_token_fingerprint(self):
        payload = {
            "class": type(self).__name__,
            "response": self.to_response_format(),
            "content": self.get("content"),
            "tool_calls": self.get("tool_calls"),
        }
        text = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(text.encode("utf-8")).hexdigest()

    def token_count_request(self, model=None):
        item = self.to_response_format()
        if item is None:
            return None
        if isinstance(item, list):
            return {"model": str(model or "gpt-5"), "input": item}
        return {"model": str(model or "gpt-5"), "input": [item]}

    def token_count_payload(self):
        return self.to_response_format()

    def compute_api_token_count(self, model=None):
        from .utils import token_count, token_count_payload

        item = self.token_count_payload()
        if item is None:
            return token_count(str(self.get("content") or ""), model=model)
        return token_count_payload(item, model=model)

    def as_string(self):
        tag = type(self).__name__
        params = self.as_string_attrs()
        content = self.as_string_body()
        return dedent(
            f"""<{tag} {params}>
            {content}
            </{tag}>"""
        )

    def as_string_attrs(self):
        return self.format_as_string_attrs(self.extract('name', 'type', 'timestamp'))

    def format_as_string_attrs(self, attrs):
        return ' '.join(f"{k}={v!r}" for k, v in attrs.items() if v is not None)

    def as_string_body(self):
        return str(self.get('content') or '')


class TextMessage(Message):
    role = "user"

    def to_response_format(self):
        role = self.role
        return {
            "type": "message",
            "role": role,
            "content": self.content_to_response_parts(output=(role == "assistant")),
        }


class UserMessage(TextMessage):
    role = "user"


class SystemMessage(TextMessage):
    role = "system"

    def format(self, context=None):
        msg = type(self)(self)
        if isinstance(msg.get('content'), str):
            msg.content = format(msg.content, context=context)
        return msg

    def to_response_format(self):
        return None

    def instruction_text(self):
        content = self.get("content") or ""
        if isinstance(content, str):
            return content
        parts = []
        for part in content if isinstance(content, list) else [content]:
            if isinstance(part, str):
                parts.append(part)
            elif isinstance(part, dict):
                parts.append(str(part.get("text") or ""))
            else:
                parts.append(str(part))
        return "\n".join(part for part in parts if part)

    def token_count_request(self, model=None):
        return {"model": str(model or "gpt-5"), "instructions": self.instruction_text()}

    def compute_api_token_count(self, model=None):
        from .utils import token_count

        return token_count(self.instruction_text(), model=model)


class DeveloperMessage(TextMessage):
    role = "developer"


class InterruptMessage(DeveloperMessage):
    name = "interrupt"
    content = "User interrupted the current turn."


class ProviderMessage(DeveloperMessage):
    def content_to_response_parts(self, output=False):
        content = str(self.get("content") or "")
        name = self.get("name") or "provider"
        wrapped = f'<context_provider name="{name}">\n{content}\n</context_provider>'
        return [{"type": "input_text", "text": wrapped}]


class CompactionMessage(DeveloperMessage):
    name = "compaction"
    content = "Previous conversation context was compacted by the backend."
    response_id = ""
    output = modict.factory(list)
    usage = modict.factory(modict)
    compacted_message_count = 0

    def __init__(self, *args, **kwargs):
        output_items = kwargs.pop("output_items", None)
        super().__init__(*args, **kwargs)
        if output_items is None:
            output_items = self.pop("output_items", None)
        legacy_summaries = self.pop("summaries", None)
        if not self.get("output"):
            if output_items is not None:
                self.output = list(output_items or [])
            elif legacy_summaries is not None:
                self.output = list(legacy_summaries or [])

    @staticmethod
    def summary_items(items):
        return [
            item for item in items or []
            if item.get("type") == "compaction_summary"
        ]

    @property
    def summaries(self):
        return self.summary_items(self.get("output") or [])

    def to_response_format(self):
        return list(self.get("output") or [])

    def observed_token_count(self):
        usage = self.get("usage") or {}
        if not isinstance(usage, dict):
            return None
        value = usage.get("output_tokens")
        if isinstance(value, int) and value >= 0:
            return value
        return None

    def count_tokens(self, model=None):
        observed = self.observed_token_count()
        if observed is not None:
            return int(observed)
        return super().count_tokens(model=model)

    def token_count_request(self, model=None):
        if self.observed_token_count() is not None:
            return None
        payload = self.token_count_payload()
        if not payload:
            return {"model": str(model or "gpt-5"), "input": []}
        return {"model": str(model or "gpt-5"), "input": payload}

    def token_count_payload(self):
        sanitized = []
        for item in self.get("output") or []:
            entry = dict(item)
            if entry.get("type") == "compaction_summary" and entry.get("encrypted_content"):
                entry["encrypted_content"] = "<encrypted_compaction_summary>"
            sanitized.append(entry)
        return sanitized

    def as_string_attrs(self):
        attrs = self.extract('name', 'type', 'timestamp')
        attrs["response_id"] = self.get("response_id")
        attrs["compacted_message_count"] = self.get("compacted_message_count")
        return self.format_as_string_attrs(attrs)

    def as_string_body(self):
        summaries = self.summary_items(self.get("output") or [])
        if not summaries:
            return self.content
        summary_lines = "\n".join(
            f"<compaction_summary id={summary.get('id', '')!r}>opaque backend summary</compaction_summary>"
            for summary in summaries
        )
        output_count = len(self.get("output") or [])
        return dedent(
            f"""{self.content}
            <compaction_output items={output_count}>
            {summary_lines}
            </compaction_output>"""
        )


class AssistantMessage(TextMessage):
    role = "assistant"

    def to_response_format(self):
        items = []
        if self.get("content"):
            items.append({
                "type": "message",
                "role": "assistant",
                "content": self.content_to_response_parts(output=True),
            })
        for tool_call in self.get("tool_calls") or []:
            if tool_call.get("type") == "custom_tool_call":
                items.append({
                    "type": "custom_tool_call",
                    "call_id": tool_call.get("call_id", ""),
                    "name": tool_call.get("name", ""),
                    "input": tool_call.get("input", ""),
                })
            else:
                items.append({
                    "type": "function_call",
                    "call_id": tool_call.get("call_id", ""),
                    "name": tool_call.get("name", ""),
                    "arguments": tool_call.get("arguments", "{}"),
                })
        return items

    def get_tool_call_by_index(self, index):
        for tool_call in self.get('tool_calls', []):
            if tool_call.get('index') == index:
                return tool_call
        return None

    def add_chunk(self, msg_chunk: MessageChunk):
        self.content += msg_chunk.get('content') or ''
        self.reasoning += msg_chunk.get('reasoning') or ''
        for tool_call in msg_chunk.get('tool_calls') or []:
            existing_tool_call = self.get_tool_call_by_index(tool_call.index)
            if existing_tool_call is None:
                self.setdefault('tool_calls', []).append(tool_call)
            else:
                existing_tool_call.arguments += tool_call.get('arguments', '')
        for item in msg_chunk.get('output_items') or []:
            self.output_items.append(item)

    @property
    def output_items(self):
        items = self.get_attr(OUTPUT_ITEMS_ATTR, None)
        if items is None:
            items = []
            self.set_attr(OUTPUT_ITEMS_ATTR, items)
        return items

    def as_string_body(self):
        body = super().as_string_body()
        tool_calls = [self.tool_call_as_string(tool_call) for tool_call in self.get("tool_calls") or []]
        return "\n".join(part for part in [body, *tool_calls] if part)

    def tool_call_as_string(self, tool_call):
        params = {
            "type": tool_call.get("type") or "function_call",
            "name": tool_call.get("name", ""),
            "call_id": tool_call.get("call_id", ""),
        }
        attrs = " ".join(f"{key}={value!r}" for key, value in params.items() if value)
        content = tool_call.get("input") if tool_call.get("type") == "custom_tool_call" else tool_call.get("arguments", "")
        if not isinstance(content, str):
            content = json.dumps(content, ensure_ascii=False, default=str)
        return dedent(
            f"""<tool_call {attrs}>
            {content}
            </tool_call>"""
        )


class ToolResultMessage(Message):
    role = "tool"
    call_id = ''
    tool_call_type = "function_call"

    def as_string_attrs(self):
        attrs = self.extract('name', 'type', 'timestamp')
        attrs["call_id"] = self.get("call_id", "")
        attrs["tool_call_type"] = self.get("tool_call_type", "")
        return self.format_as_string_attrs(attrs)

    def to_response_format(self):
        if self.get("tool_call_type") == "custom_tool_call":
            return {
                "type": "custom_tool_call_output",
                "call_id": self.get("call_id", ""),
                "output": self.get("content", ""),
            }
        return {
            "type": "function_call_output",
            "call_id": self.get("call_id", ""),
            "output": self.get("content", ""),
        }


class ToolResultWrapper(DeveloperMessage):
    name = "tool_result_wrapper"
    call_id = ""
    tool_name = ""
    status = "success"
    turns_left = 3

    def content_to_response_parts(self, output=False):
        attrs = {
            "call_id": self.get("call_id", ""),
            "tool_name": self.get("tool_name", ""),
            "status": self.get("status", ""),
            "wrapper_id": self.get("id", ""),
        }
        attr_text = " ".join(
            f"{key}={quoteattr(str(value))}"
            for key, value in attrs.items()
            if value
        )
        wrapped = (
            f"<tool_result_wrapper {attr_text}>\n"
            f"{escape(str(self.get('content') or ''))}\n"
            f"</tool_result_wrapper>"
        )
        return [{"type": "input_text", "text": wrapped}]

    def as_string_attrs(self):
        attrs = self.extract('name', 'type', 'timestamp')
        attrs["call_id"] = self.get("call_id", "")
        attrs["tool_name"] = self.get("tool_name", "")
        attrs["status"] = self.get("status", "")
        return self.format_as_string_attrs(attrs)


class ServerToolResponseMessage(Message):
    item = None

    def __init__(self, *args, **kwargs):
        args, kwargs = self._prepare_init_payload(args, kwargs)
        super().__init__(*args, **kwargs)

    @classmethod
    def _prepare_init_payload(cls, args, kwargs):
        kwargs = dict(kwargs)
        data = dict(args[0]) if args and isinstance(args[0], dict) else None

        item = kwargs.get("item")
        if data and "item" in data and "item" not in kwargs:
            item = data["item"]

        item = dict(item or {})
        if item.get("type") != "image_generation_call" or not item.get("result"):
            return args, kwargs

        from .image import persist_image_bytes

        image_bytes = base64.b64decode(item["result"])
        image_path = persist_image_bytes(image_bytes, name=f"{item.get('id') or 'image_generation'}.png")
        item.pop("result", None)

        if data is not None:
            data["item"] = item
            data.setdefault("content", image_path)
            args = (data, *args[1:])
        else:
            kwargs["item"] = item
            kwargs.setdefault("content", image_path)
        return args, kwargs

    def to_response_format(self):
        item = dict(self.item or {})
        if item.get("type") == "image_generation_call" and "result" not in item and self.get("content"):
            from .image import data_url_from_file

            return [
                {
                    "type": "message",
                    "role": "user",
                    "content": [
                        {
                            "type": "input_image",
                            "image_url": data_url_from_file(self.content),
                            "detail": "auto",
                        },
                        {
                            "type": "input_text",
                            "text": (
                                "This is an image previously generated by the image_generation tool. "
                                "Use it as the base image for any requested follow-up image edits."
                            ),
                        },
                    ],
                },
                {
                    "type": "message",
                    "role": "developer",
                    "content": [{
                        "type": "input_text",
                        "text": (
                            "The generated image has also been saved locally at: "
                            f"{self.content}\n"
                            "Use the show tool to open it for the user, or observe it if visual analysis is needed."
                        ),
                    }],
                },
            ]
        return item

    def as_string_attrs(self):
        attrs = self.extract('name', 'type', 'timestamp')
        item = self.get("item") or {}
        attrs["item_type"] = item.get("type")
        attrs["item_id"] = item.get("id")
        attrs["status"] = item.get("status")
        return self.format_as_string_attrs(attrs)

    def as_string_body(self):
        parts = []
        if self.get("content"):
            parts.append(str(self.content))
        if self.get("item"):
            parts.append(dedent(
                f"""<server_tool_item>
                {json.dumps(self.item, ensure_ascii=False, default=str)}
                </server_tool_item>"""
            ))
        return "\n".join(parts)

    def as_image_message(self):
        from .image import ImageMessage

        if self.get("content") and self.get("item", {}).get("type") == "image_generation_call":
            return ImageMessage(content=self.content, image_name=self.get("name") or self.get("item", {}).get("id"))
        return None


MESSAGE_TYPES = {
    snake_case_type(cls): cls
    for cls in (
        UserMessage,
        SystemMessage,
        DeveloperMessage,
        InterruptMessage,
        ProviderMessage,
        CompactionMessage,
        AssistantMessage,
        ToolResultMessage,
        ToolResultWrapper,
        ServerToolResponseMessage,
    )
}

def message_from_data(data=None, **kwargs):
    data = dict(data or {})
    data.update(kwargs)

    message_type = data.get('type') or next(reversed(data.get('types') or []), None)
    cls = MESSAGE_TYPES.get(message_type)
    if cls is None:
        raise ValueError(f"Unknown or missing message type: {message_type!r}")
    data.pop('type', None)
    data.pop('role', None)
    if not data.get('types'):
        data['types'] = cls.default_types(legacy_type=message_type)
    return cls(data)


def register_message_type(cls):
    MESSAGE_TYPES[snake_case_type(cls)] = cls
    return cls
