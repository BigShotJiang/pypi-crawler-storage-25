from ...plugin import Plugin
from ...tool import WebSearchTool


class WebSearchPlugin(Plugin):
    name = "web_search"
    description = "OpenAI Responses API web search server tool."

    def __init__(self, agent):
        super().__init__(agent)
        self.agent.tools_manager.add_server_tool(WebSearchTool())
