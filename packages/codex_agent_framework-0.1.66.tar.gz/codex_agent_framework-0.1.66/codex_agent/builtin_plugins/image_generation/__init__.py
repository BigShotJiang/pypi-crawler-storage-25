import os

from ...image import ImageMessage
from ...message import ServerToolResponseMessage, SystemMessage, UserMessage
from ...plugin import Plugin
from ...tool import ServerTool
from ...utils import text_content


class ImageGenerationTool(ServerTool):
    type = "image_generation"
    baked_token_count = 342
    output_format = "png"
    size = None
    quality = None
    background = None
    moderation = None


class ImageGenerationPlugin(Plugin):
    name = "image_generation"
    description = "OpenAI Responses API image generation server tool and direct image helper."

    def __init__(self, agent):
        super().__init__(agent)
        self.agent.tools_manager.add_server_tool(self.image_generation_tool())

    def image_generation_tool(self, **kwargs):
        params = dict(
            output_format=self.agent.config.get("image_generation_output_format"),
            size=self.agent.config.get("image_generation_size"),
            quality=self.agent.config.get("image_generation_quality"),
            background=self.agent.config.get("image_generation_background"),
            moderation=self.agent.config.get("image_generation_moderation"),
        )
        params.update({key: value for key, value in kwargs.items() if value is not None})
        return ImageGenerationTool(**params)

    def create_image(
        self,
        prompt,
        input_images=None,
        model="gpt-5.4",
        reasoning=None,
        text=None,
        reasoning_effort=None,
        verbosity=None,
        output_format="png",
        size=None,
        quality=None,
        background=None,
        moderation=None,
    ):
        """Generate an image directly and return the saved image path."""
        content = [{"type": "text", "text": prompt}]
        for source in input_images or []:
            content.extend(ImageMessage(content=source).content_to_response_parts())

        system_prompt = text_content(
            os.path.join(os.path.dirname(__file__), "image_generation_system_prompt.txt")
        )
        if reasoning is None and reasoning_effort:
            reasoning = {"effort": reasoning_effort, "summary": "auto"}
        if text is None and verbosity:
            text = {"verbosity": verbosity}
        message = self.agent.ai.run(
            messages=[SystemMessage(content=system_prompt), UserMessage(content=content)],
            tools=[self.image_generation_tool(
                output_format=output_format,
                size=size,
                quality=quality,
                background=background,
                moderation=moderation,
            ).to_response_tool()],
            model=model,
            reasoning=reasoning or {"effort": "medium", "summary": "auto"},
            text=text or {"verbosity": "medium"},
        )
        for item in message.output_items:
            if item.get("type") == "image_generation_call":
                return ServerToolResponseMessage(item=item).content
        raise RuntimeError("The image_generation tool did not return an image.")
