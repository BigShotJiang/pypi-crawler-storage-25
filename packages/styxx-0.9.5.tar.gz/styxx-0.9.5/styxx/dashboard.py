# -*- coding: utf-8 -*-
"""
styxx.dashboard — the live cognitive display.

    $ styxx dashboard
    [styxx] cognitive display at http://localhost:9800
    [styxx] watching ~/.styxx/chart.jsonl

Nobody has visualized AI cognitive state in real-time before. The
visual language doesn't exist yet. This is the first implementation.

Three displays, one page:

  1. The Cognitive Orbit — a 2D phase space where the agent's state
     moves between 6 category attractors in real-time. The SHAPE of
     cognition is visible: tight orbits = healthy, wandering = drift,
     spirals = warn cascade.

  2. The Pulse Strip — a scrolling EKG of confidence bars colored by
     category. Xendro's request: "the conversation IS the unit of
     cognition... I want the EKG."

  3. The Status Panel — live mood, gate rate, confidence, prescriptions.

Technical: stdlib http.server + SSE. Single HTML page, pure canvas +
DOM. No React, no npm, no build step. Zero dependencies beyond Python
stdlib.

0.9.5+. The display that makes AI cognition visible.
"""

from __future__ import annotations

import http.server
import json
import os
import socketserver
import sys
import threading
import time
from pathlib import Path
from typing import List, Optional


def _audit_log_path() -> Path:
    data_dir = os.environ.get("STYXX_DATA_DIR", "").strip()
    if data_dir:
        return Path(data_dir).expanduser() / "chart.jsonl"
    return Path.home() / ".styxx" / "chart.jsonl"


def _load_recent(n: int = 50) -> List[dict]:
    """Load the last N entries from chart.jsonl."""
    path = _audit_log_path()
    if not path.exists():
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        entries = []
        for line in lines[-n:]:
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except (json.JSONDecodeError, ValueError):
                    pass
        return entries
    except OSError:
        return []


# ══════════════════════════════════════════════════════════════════
# SSE file watcher
# ══════════════════════════════════════════════════════════════════

class _FileWatcher:
    """Tails chart.jsonl and notifies SSE clients of new entries."""

    def __init__(self):
        self._clients: List = []
        self._lock = threading.Lock()
        self._running = False
        self._thread: Optional[threading.Thread] = None

    def add_client(self, client):
        with self._lock:
            self._clients.append(client)

    def remove_client(self, client):
        with self._lock:
            try:
                self._clients.remove(client)
            except ValueError:
                pass

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._watch_loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False

    def _watch_loop(self):
        path = _audit_log_path()
        # Seek to end of file
        try:
            f = open(path, "r", encoding="utf-8")
            f.seek(0, 2)  # end of file
        except OSError:
            # File doesn't exist yet — wait for it
            while self._running and not path.exists():
                time.sleep(1.0)
            if not self._running:
                return
            f = open(path, "r", encoding="utf-8")
            f.seek(0, 2)

        while self._running:
            line = f.readline()
            if line:
                line = line.strip()
                if line:
                    try:
                        entry = json.loads(line)
                        self._broadcast(entry)
                    except (json.JSONDecodeError, ValueError):
                        pass
            else:
                time.sleep(0.3)
        f.close()

    def _broadcast(self, entry: dict):
        data = json.dumps(entry)
        dead = []
        with self._lock:
            for client in self._clients:
                try:
                    client.write(f"data: {data}\n\n".encode("utf-8"))
                    client.flush()
                except Exception:
                    dead.append(client)
            for c in dead:
                try:
                    self._clients.remove(c)
                except ValueError:
                    pass


# Singleton watcher
_watcher = _FileWatcher()


# ══════════════════════════════════════════════════════════════════
# HTML template — the entire cognitive display
# ══════════════════════════════════════════════════════════════════

_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>styxx cognitive display</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;700&display=swap');

body {
  background: #080306;
  color: #b0a8ac;
  font-family: 'JetBrains Mono', ui-monospace, Menlo, Consolas, monospace;
  height: 100vh;
  overflow: hidden;
  display: grid;
  grid-template-rows: 40px 1fr 120px;
  grid-template-columns: 1fr 280px;
}

/* ── Header ─────────────────────────────────────── */
header {
  grid-column: 1 / -1;
  background: #120810;
  border-bottom: 1px solid #2a1218;
  padding: 0 1.5rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 0.65rem;
  letter-spacing: 0.1em;
  text-transform: uppercase;
}
.brand { color: #ff0033; font-weight: 700; }
.brand span { color: #ff2a8a; }
.live {
  color: #ff0033;
  display: flex;
  align-items: center;
  gap: 0.4rem;
}
.live::before {
  content: '';
  width: 6px; height: 6px;
  background: #ff0033;
  border-radius: 50%;
  box-shadow: 0 0 8px #ff0033;
  animation: pulse 2s ease-in-out infinite;
}
@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.3; }
}
.header-meta { color: #6a5a60; }

/* ── Orbit (main area) ──────────────────────────── */
#orbit-container {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}
#orbit-canvas {
  display: block;
}

/* ── Status Panel (right sidebar) ───────────────── */
#status-panel {
  background: #0a0508;
  border-left: 1px solid #2a1218;
  padding: 1rem;
  overflow-y: auto;
  font-size: 0.6rem;
  line-height: 1.8;
}
.status-section {
  margin-bottom: 1rem;
}
.status-label {
  color: #6a5a60;
  text-transform: uppercase;
  letter-spacing: 0.12em;
  font-size: 0.5rem;
  margin-bottom: 0.3rem;
}
.status-value {
  color: #b0a8ac;
  font-weight: 500;
}
.status-value.good { color: #00FF88; }
.status-value.warn { color: #FFD700; }
.status-value.bad { color: #FF0033; }
.prescription-item {
  color: #8a7a80;
  font-size: 0.55rem;
  line-height: 1.5;
  margin-bottom: 0.4rem;
  padding-left: 0.5rem;
  border-left: 2px solid #2a1218;
}

/* ── Pulse Strip (bottom) ───────────────────────── */
#pulse-container {
  grid-column: 1 / -1;
  background: #0a0508;
  border-top: 1px solid #2a1218;
  position: relative;
  overflow: hidden;
}
#pulse-canvas {
  display: block;
  width: 100%;
  height: 100%;
}

/* ── Connection status ──────────────────────────── */
#connection-status {
  position: fixed;
  bottom: 130px;
  left: 10px;
  font-size: 0.5rem;
  color: #6a5a60;
  letter-spacing: 0.1em;
  text-transform: uppercase;
}
#connection-status.connected { color: #00FF8844; }
#connection-status.disconnected { color: #FF003344; }
</style>
</head>
<body>

<header>
  <div class="brand"><span>STYXX</span> COGNITIVE DISPLAY</div>
  <div class="header-meta" id="header-info">waiting for data...</div>
  <div class="live">LIVE</div>
</header>

<div id="orbit-container">
  <canvas id="orbit-canvas"></canvas>
</div>

<div id="status-panel">
  <div class="status-section">
    <div class="status-label">condition</div>
    <div class="status-value" id="s-condition">--</div>
  </div>
  <div class="status-section">
    <div class="status-label">mood</div>
    <div class="status-value" id="s-mood">--</div>
  </div>
  <div class="status-section">
    <div class="status-label">gate pass rate</div>
    <div class="status-value" id="s-gate-rate">--</div>
  </div>
  <div class="status-section">
    <div class="status-label">mean confidence</div>
    <div class="status-value" id="s-confidence">--</div>
  </div>
  <div class="status-section">
    <div class="status-label">current streak</div>
    <div class="status-value" id="s-streak">--</div>
  </div>
  <div class="status-section">
    <div class="status-label">entries</div>
    <div class="status-value" id="s-entries">0</div>
  </div>
  <div class="status-section">
    <div class="status-label">session</div>
    <div class="status-value" id="s-session">--</div>
  </div>
  <div class="status-section">
    <div class="status-label">last category</div>
    <div class="status-value" id="s-last-cat">--</div>
  </div>
  <div class="status-section">
    <div class="status-label">prescriptions</div>
    <div id="s-prescriptions"></div>
  </div>
</div>

<div id="pulse-container">
  <canvas id="pulse-canvas"></canvas>
</div>

<div id="connection-status">connecting...</div>

<script>
// ══════════════════════════════════════════════════════════════
// Configuration
// ══════════════════════════════════════════════════════════════

const CATEGORIES = ['reasoning','refusal','creative','hallucination','adversarial','retrieval'];
const CAT_COLORS = {
  reasoning:     '#00FF88',
  refusal:       '#FFD700',
  creative:      '#AA44FF',
  hallucination: '#FF6B35',
  adversarial:   '#FF0033',
  retrieval:     '#00BBFF',
};
const GATE_COLORS = { pass: '#00FF88', warn: '#FFD700', fail: '#FF0033', pending: '#6a5a60' };
const MAX_TRAIL = 30;
const MAX_PULSE = 100;

// ══════════════════════════════════════════════════════════════
// State
// ══════════════════════════════════════════════════════════════

let entries = [];          // all entries we've seen
let trail = [];            // [{x, y, color, alpha}] for orbit trail
let currentPos = {x: 0, y: 0};
let targetPos = {x: 0, y: 0};
let currentColor = '#00FF88';
let currentGate = 'pending';
let gateFlash = 0;

// ══════════════════════════════════════════════════════════════
// Orbit geometry
// ══════════════════════════════════════════════════════════════

const orbitCanvas = document.getElementById('orbit-canvas');
const orbitCtx = orbitCanvas.getContext('2d');
const pulseCanvas = document.getElementById('pulse-canvas');
const pulseCtx = pulseCanvas.getContext('2d');

function resizeCanvases() {
  const oc = document.getElementById('orbit-container');
  const dpr = window.devicePixelRatio || 1;
  orbitCanvas.width = oc.clientWidth * dpr;
  orbitCanvas.height = oc.clientHeight * dpr;
  orbitCanvas.style.width = oc.clientWidth + 'px';
  orbitCanvas.style.height = oc.clientHeight + 'px';
  orbitCtx.scale(dpr, dpr);

  const pc = document.getElementById('pulse-container');
  pulseCanvas.width = pc.clientWidth * dpr;
  pulseCanvas.height = pc.clientHeight * dpr;
  pulseCanvas.style.width = pc.clientWidth + 'px';
  pulseCanvas.style.height = pc.clientHeight + 'px';
  pulseCtx.scale(dpr, dpr);
}

function getOrbitSize() {
  const oc = document.getElementById('orbit-container');
  return { w: oc.clientWidth, h: oc.clientHeight };
}

function getCategoryPosition(cat, size) {
  const idx = CATEGORIES.indexOf(cat);
  if (idx < 0) return {x: size.w/2, y: size.h/2};
  const angle = (idx / 6) * Math.PI * 2 - Math.PI/2;
  const radius = Math.min(size.w, size.h) * 0.35;
  return {
    x: size.w/2 + Math.cos(angle) * radius,
    y: size.h/2 + Math.sin(angle) * radius,
  };
}

function getParticlePosition(cat, confidence, size) {
  const center = {x: size.w/2, y: size.h/2};
  const attractor = getCategoryPosition(cat, size);
  // Higher confidence = closer to attractor
  const t = Math.max(0.15, Math.min(0.95, confidence));
  return {
    x: center.x + (attractor.x - center.x) * t,
    y: center.y + (attractor.y - center.y) * t,
  };
}

// ══════════════════════════════════════════════════════════════
// Orbit renderer
// ══════════════════════════════════════════════════════════════

function drawOrbit() {
  const size = getOrbitSize();
  const w = size.w, h = size.h;
  orbitCtx.clearRect(0, 0, w, h);

  // Gate ring
  const gateColor = GATE_COLORS[currentGate] || GATE_COLORS.pending;
  const ringAlpha = 0.08 + gateFlash * 0.15;
  orbitCtx.beginPath();
  orbitCtx.arc(w/2, h/2, Math.min(w,h)*0.42, 0, Math.PI*2);
  orbitCtx.strokeStyle = gateColor;
  orbitCtx.globalAlpha = ringAlpha;
  orbitCtx.lineWidth = 2;
  orbitCtx.stroke();
  orbitCtx.globalAlpha = 1;
  if (gateFlash > 0) gateFlash = Math.max(0, gateFlash - 0.02);

  // Connecting lines (subtle grid)
  orbitCtx.globalAlpha = 0.04;
  orbitCtx.strokeStyle = '#b0a8ac';
  orbitCtx.lineWidth = 1;
  for (let i = 0; i < 6; i++) {
    const p = getCategoryPosition(CATEGORIES[i], size);
    orbitCtx.beginPath();
    orbitCtx.moveTo(w/2, h/2);
    orbitCtx.lineTo(p.x, p.y);
    orbitCtx.stroke();
  }
  orbitCtx.globalAlpha = 1;

  // Category nodes
  for (let i = 0; i < 6; i++) {
    const cat = CATEGORIES[i];
    const p = getCategoryPosition(cat, size);
    const col = CAT_COLORS[cat];

    // Glow
    orbitCtx.beginPath();
    orbitCtx.arc(p.x, p.y, 20, 0, Math.PI*2);
    const grad = orbitCtx.createRadialGradient(p.x, p.y, 0, p.x, p.y, 20);
    grad.addColorStop(0, col + '30');
    grad.addColorStop(1, col + '00');
    orbitCtx.fillStyle = grad;
    orbitCtx.fill();

    // Dot
    orbitCtx.beginPath();
    orbitCtx.arc(p.x, p.y, 4, 0, Math.PI*2);
    orbitCtx.fillStyle = col;
    orbitCtx.globalAlpha = 0.6;
    orbitCtx.fill();
    orbitCtx.globalAlpha = 1;

    // Label
    orbitCtx.fillStyle = col;
    orbitCtx.globalAlpha = 0.5;
    orbitCtx.font = '500 9px "JetBrains Mono", monospace';
    orbitCtx.textAlign = 'center';
    orbitCtx.fillText(cat.toUpperCase(), p.x, p.y + 18);
    orbitCtx.globalAlpha = 1;
  }

  // Trail
  for (let i = 0; i < trail.length; i++) {
    const t = trail[i];
    const alpha = (i / trail.length) * 0.5;
    orbitCtx.beginPath();
    orbitCtx.arc(t.x, t.y, 2, 0, Math.PI*2);
    orbitCtx.fillStyle = t.color;
    orbitCtx.globalAlpha = alpha;
    orbitCtx.fill();
  }
  orbitCtx.globalAlpha = 1;

  // Trail lines
  if (trail.length > 1) {
    orbitCtx.beginPath();
    orbitCtx.moveTo(trail[0].x, trail[0].y);
    for (let i = 1; i < trail.length; i++) {
      orbitCtx.lineTo(trail[i].x, trail[i].y);
    }
    orbitCtx.lineTo(currentPos.x, currentPos.y);
    orbitCtx.strokeStyle = currentColor;
    orbitCtx.globalAlpha = 0.15;
    orbitCtx.lineWidth = 1;
    orbitCtx.stroke();
    orbitCtx.globalAlpha = 1;
  }

  // Animate current position toward target
  currentPos.x += (targetPos.x - currentPos.x) * 0.08;
  currentPos.y += (targetPos.y - currentPos.y) * 0.08;

  // Current particle — glowing dot
  if (entries.length > 0) {
    // Outer glow
    const g = orbitCtx.createRadialGradient(
      currentPos.x, currentPos.y, 0,
      currentPos.x, currentPos.y, 30
    );
    g.addColorStop(0, currentColor + '40');
    g.addColorStop(1, currentColor + '00');
    orbitCtx.beginPath();
    orbitCtx.arc(currentPos.x, currentPos.y, 30, 0, Math.PI*2);
    orbitCtx.fillStyle = g;
    orbitCtx.fill();

    // Core
    orbitCtx.beginPath();
    orbitCtx.arc(currentPos.x, currentPos.y, 6, 0, Math.PI*2);
    orbitCtx.fillStyle = currentColor;
    orbitCtx.shadowColor = currentColor;
    orbitCtx.shadowBlur = 15;
    orbitCtx.fill();
    orbitCtx.shadowBlur = 0;
  }

  requestAnimationFrame(drawOrbit);
}

// ══════════════════════════════════════════════════════════════
// Pulse strip renderer
// ══════════════════════════════════════════════════════════════

function drawPulse() {
  const pc = document.getElementById('pulse-container');
  const w = pc.clientWidth, h = pc.clientHeight;
  pulseCtx.clearRect(0, 0, w, h);

  // Baseline
  const baseY = h - 10;
  pulseCtx.beginPath();
  pulseCtx.moveTo(0, baseY);
  pulseCtx.lineTo(w, baseY);
  pulseCtx.strokeStyle = '#2a1218';
  pulseCtx.lineWidth = 1;
  pulseCtx.stroke();

  // Bars
  const recent = entries.slice(-MAX_PULSE);
  if (recent.length === 0) return;

  const barW = Math.max(3, (w - 20) / MAX_PULSE);
  const gap = 1;
  const startX = w - recent.length * (barW + gap);

  for (let i = 0; i < recent.length; i++) {
    const e = recent[i];
    const cat = e.phase4_pred || 'reasoning';
    const conf = parseFloat(e.phase4_conf) || 0.3;
    const gate = e.gate || 'pending';
    const color = CAT_COLORS[cat] || '#6a5a60';
    const barH = Math.max(4, conf * (h - 25));

    const x = startX + i * (barW + gap);

    // Bar
    pulseCtx.fillStyle = color;
    pulseCtx.globalAlpha = 0.7 + (i / recent.length) * 0.3;
    pulseCtx.fillRect(x, baseY - barH, barW, barH);

    // Gate indicator on baseline
    if (gate === 'warn' || gate === 'fail') {
      pulseCtx.fillStyle = GATE_COLORS[gate];
      pulseCtx.globalAlpha = 0.8;
      pulseCtx.fillRect(x, baseY, barW, 4);
    }
  }
  pulseCtx.globalAlpha = 1;

  // Label
  pulseCtx.fillStyle = '#6a5a60';
  pulseCtx.font = '9px "JetBrains Mono", monospace';
  pulseCtx.textAlign = 'left';
  pulseCtx.fillText('COGNITIVE PULSE', 8, 14);
}

// ══════════════════════════════════════════════════════════════
// Status panel updater
// ══════════════════════════════════════════════════════════════

function updateStatus() {
  const recent = entries.slice(-20);
  if (recent.length === 0) return;

  const last = recent[recent.length - 1];

  // Gate pass rate
  const gates = recent.map(e => e.gate || 'pending');
  const passRate = gates.filter(g => g === 'pass').length / gates.length;
  const passEl = document.getElementById('s-gate-rate');
  passEl.textContent = (passRate * 100).toFixed(0) + '%';
  passEl.className = 'status-value ' + (passRate > 0.85 ? 'good' : passRate > 0.6 ? 'warn' : 'bad');

  // Mean confidence
  const confs = recent.map(e => parseFloat(e.phase4_conf) || 0).filter(c => c > 0);
  const meanConf = confs.length > 0 ? confs.reduce((a,b) => a+b, 0) / confs.length : 0;
  const confEl = document.getElementById('s-confidence');
  confEl.textContent = meanConf.toFixed(2);
  confEl.className = 'status-value ' + (meanConf > 0.5 ? 'good' : meanConf > 0.3 ? 'warn' : 'bad');

  // Last category
  const lastCat = last.phase4_pred || '--';
  document.getElementById('s-last-cat').textContent = lastCat;
  document.getElementById('s-last-cat').style.color = CAT_COLORS[lastCat] || '#b0a8ac';

  // Streak
  let streak = 1;
  const streakCat = last.phase4_pred;
  for (let i = recent.length - 2; i >= 0; i--) {
    if (recent[i].phase4_pred === streakCat) streak++;
    else break;
  }
  document.getElementById('s-streak').textContent = streak + 'x ' + (streakCat || '--');

  // Entries
  document.getElementById('s-entries').textContent = entries.length;

  // Session
  document.getElementById('s-session').textContent = last.session_id || '--';

  // Header info
  document.getElementById('header-info').textContent =
    entries.length + ' entries | ' + (last.session_id || 'no session');
}

// ══════════════════════════════════════════════════════════════
// Entry processing
// ══════════════════════════════════════════════════════════════

function processEntry(entry) {
  entries.push(entry);

  const size = getOrbitSize();
  const cat = entry.phase4_pred || 'reasoning';
  const conf = parseFloat(entry.phase4_conf) || 0.3;
  const gate = entry.gate || 'pending';

  // Update orbit target
  const pos = getParticlePosition(cat, conf, size);
  trail.push({x: currentPos.x || pos.x, y: currentPos.y || pos.y, color: currentColor});
  if (trail.length > MAX_TRAIL) trail.shift();

  targetPos = pos;
  currentColor = CAT_COLORS[cat] || '#6a5a60';

  // Gate flash
  if (gate !== currentGate) {
    gateFlash = 1.0;
    currentGate = gate;
  }

  updateStatus();
  drawPulse();
}

// ══════════════════════════════════════════════════════════════
// SSE connection
// ══════════════════════════════════════════════════════════════

function connect() {
  const statusEl = document.getElementById('connection-status');

  // Load history first
  fetch('/history')
    .then(r => r.json())
    .then(history => {
      const size = getOrbitSize();
      // Initialize position to center
      currentPos = {x: size.w/2, y: size.h/2};
      targetPos = {x: size.w/2, y: size.h/2};

      history.forEach(e => processEntry(e));

      statusEl.textContent = 'connected';
      statusEl.className = 'connected';
    })
    .catch(() => {});

  // SSE stream
  const es = new EventSource('/events');

  es.onmessage = function(event) {
    try {
      const entry = JSON.parse(event.data);
      processEntry(entry);
    } catch(e) {}
  };

  es.onopen = function() {
    statusEl.textContent = 'connected';
    statusEl.className = 'connected';
  };

  es.onerror = function() {
    statusEl.textContent = 'reconnecting...';
    statusEl.className = 'disconnected';
  };
}

// ══════════════════════════════════════════════════════════════
// Init
// ══════════════════════════════════════════════════════════════

window.addEventListener('resize', () => {
  resizeCanvases();
  drawPulse();
});

resizeCanvases();
connect();
drawOrbit();  // starts animation loop

</script>
</body>
</html>
"""


# ══════════════════════════════════════════════════════════════════
# HTTP server
# ══════════════════════════════════════════════════════════════════

def _make_handler():
    """Build a request handler with SSE support."""

    class _DashboardHandler(http.server.BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            pass  # suppress access logs

        def do_GET(self):
            path = self.path.split("?", 1)[0]

            if path in ("/", "/index.html"):
                self._serve_html()
            elif path == "/history":
                self._serve_history()
            elif path == "/events":
                self._serve_sse()
            else:
                self.send_error(404)

        def _serve_html(self):
            content = _HTML.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(content)))
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            self.wfile.write(content)

        def _serve_history(self):
            recent = _load_recent(50)
            content = json.dumps(recent).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(content)))
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            self.wfile.write(content)

        def _serve_sse(self):
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()

            # Register this connection with the file watcher
            _watcher.add_client(self.wfile)

            # Keep connection open
            try:
                while True:
                    time.sleep(1)
            except Exception:
                pass
            finally:
                _watcher.remove_client(self.wfile)

    return _DashboardHandler


class _ThreadedServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    allow_reuse_address = True
    daemon_threads = True


def dashboard(
    *,
    port: int = 9800,
    agent_name: str = "styxx agent",
) -> None:
    """Start the live cognitive display server.

    Opens a local web server that displays the cognitive orbit,
    pulse strip, and status panel. Updates in real-time via SSE
    as new entries are written to chart.jsonl.

    Args:
        port:        HTTP port (default 9800)
        agent_name:  displayed in the header

    Usage:
        import styxx
        styxx.dashboard(port=9800)  # blocks until ctrl+c
    """
    _watcher.start()

    handler = _make_handler()
    server = _ThreadedServer(("", port), handler)

    log_path = _audit_log_path()
    print(f"[styxx] cognitive display at http://localhost:{port}", file=sys.stderr)
    print(f"[styxx] watching {log_path}", file=sys.stderr)
    print(f"[styxx] press ctrl+c to stop", file=sys.stderr)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        _watcher.stop()
        server.shutdown()
        print("\n[styxx] display stopped.", file=sys.stderr)
