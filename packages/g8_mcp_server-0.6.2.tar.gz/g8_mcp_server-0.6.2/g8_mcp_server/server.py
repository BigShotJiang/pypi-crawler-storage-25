"""MCP server bootstrap - registers all tools, resources, and prompts."""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import sys
import time

import httpx
from mcp.server import FastMCP, NotificationOptions
from mcp.server.fastmcp.server import StreamableHTTPASGIApp
from mcp.server.streamable_http_manager import StreamableHTTPSessionManager
from starlette.requests import Request
from starlette.responses import JSONResponse

from g8_mcp_server.auth import get_api_key, set_api_key
from g8_mcp_server.client import G8Client, G8ClientError
from g8_mcp_server.tools import dev, discovery, forms, gtm, inbox, intent, pipelines, platform, snippet, sync, voice, workflows
from g8_mcp_server.tools import skills as skills_tools
from g8_mcp_server.tools import skills_authoring
from g8_mcp_server import resources, prompts, tool_catalog
from g8_mcp_server.session_tools import get_activated, session_id_for_key

# Tool registration mode: "all" (default), "dev", or "gtm"
# - all:  registers dev tools plus GTM tools namespaced as g8_gtm_*
# - dev:  repo-scoped tools for developers in Cursor/Windsurf/Claude Code
# - gtm:  org-scoped tools for campaign managers in Claude Desktop
MCP_MODE = os.getenv("G8_MCP_MODE", "all").lower()

logger = logging.getLogger(__name__)

# PropelAuth MCP token validation config
_PA_AUTH_URL = os.getenv("PROPELAUTH_AUTH_URL", "")
_PA_API_KEY = os.getenv("PROPELAUTH_API_KEY", "")
# SDK sends just the hostname (no scheme) in X-Propelauth-url header
_PA_HOSTNAME = _PA_AUTH_URL.replace("https://", "").replace("http://", "").rstrip("/")
_INTROSPECT_URL = f"{_PA_AUTH_URL}/oauth/2.1/introspect"
_INTROSPECT_CLIENT_ID = os.getenv("MCP_INTROSPECTION_CLIENT_ID", "")
_INTROSPECT_CLIENT_SECRET = os.getenv("MCP_INTROSPECTION_CLIENT_SECRET", "")

# Redis cache prefixes and TTL for JWT → API key mappings
_JWT_CACHE_PREFIX = "mcp:jwt_key:"
_USER_CACHE_PREFIX = "mcp:user_key:"  # keyed by sha256(f"{user_id}:{org_id}")
_USER_PREFS_PREFIX = "mcp:user_prefs:"
_KEY_REVERSE_PREFIX = "mcp:key_reverse:"  # api_key sha → JSON list of cache keys to invalidate
_JWT_CACHE_TTL = 14 * 86400  # 14 days (matches PropelAuth MCP session duration)
_PREFS_CACHE_TTL = 3600  # 1 hour - user can change tool group in profile

# MCP rate limits (lower than Developer API - MCP tools are heavier operations)
_MCP_REQUESTS_PER_MINUTE = int(os.getenv("MCP_RATE_LIMIT_PER_MINUTE", "100"))
_MCP_REQUESTS_PER_SECOND = int(os.getenv("MCP_RATE_LIMIT_PER_SECOND", "10"))
_MCP_RATE_LIMIT_PREFIX = "ratelimit:mcp"
_mcp_rate_limiter = None


def _register_tools(server: FastMCP, client: G8Client, mode: str = "all") -> None:
    """Register tools based on mode: 'all', 'dev', or 'gtm'."""
    # Shared tools - available in every mode
    platform.register(server, client)
    inbox.register(server, client)
    sync.register(server, client)
    intent.register(server, client)
    skills_tools.register(server)

    if mode == "dev":
        dev.register(server, client)
        snippet.register(server, client)
        forms.register(server, client)
    elif mode == "gtm":
        gtm.register(server, client)
        # Pipeline tools (g8_list_pipelines, g8_create_pipeline, g8_suggest_pipeline_from_context, ...)
        # are GTM-mode operations. See mcp_server/g8_mcp_server/tools/pipelines.py.
        pipelines.register(server, client)
    else:
        # "all" - register developer tools plus GTM tools with a prefix to avoid collisions
        dev.register(server, client)
        snippet.register(server, client)
        forms.register(server, client)
        gtm.register(server, client, name_prefix="gtm")
        # Pipeline tools also get the gtm prefix in "all" mode (g8_gtm_list_pipelines, ...)
        pipelines.register(server, client, name_prefix="gtm")
        # Voice / dialer tools (g8_voice_*) live in "all" mode only.
        # They proxy the voice microservice. The surface includes:
        #   read   - sessions, stats, numbers, missed callbacks, grading,
        #            agents picker
        #   write  - create/pause/resume/stop dialer sessions
        # Per-call SDR-frontend ops (start_session with contacts,
        # manual-dial, redial, hangup, drop voicemail, update disposition)
        # intentionally stay frontend-only - they need a Twilio browser
        # conference and are not chat-friendly.
        voice.register(server, client)
        # Workflow builder tools (g8_workflow_*) - also "all" mode only.
        # They proxy developer_api's /workflows/* surface (which itself
        # proxies voice's /api/v1/actions/* with runtime_type='workflow').
        # The 19 tools cover read/discover, build/edit (incl. granular
        # add_node / update_node / remove_node / connect_nodes helpers)
        # and execution lifecycle (execute, pause/resume/stop, status,
        # trigger reset). Workflow building is a deep niche, so NONE of
        # these tools are in _ALWAYS_ON_TOOLS - they reach the model only
        # via g8_tool_search progressive discovery, keeping steady-state
        # context tax at zero.
        workflows.register(server, client)
        # Skill authoring tools - also "all" mode only.
        # Registered under TWO name surfaces:
        #   - g8_skill_*           (canonical / legacy - keeps existing
        #                           callers, tests, and cached schemas working)
        #   - g8_workflow_skill_*  (alias - puts skill authoring under the
        #                           workflow namespace so the agent treats
        #                           it as part of the workflow toolbelt)
        # Both names point at the same handler functions. They proxy
        # developer_api's /skills/* surface (which itself proxies voice's
        # /api/v1/actions/* with runtime_type IN ('llm','api')). The 14
        # base tools cover read/discover, create (llm/api/from-template/
        # from-node), update, delete, validate, and execute. Skills are the
        # reusable LLM/API building blocks that workflows compose into runs;
        # the lift tool (`from-node`) produces byte-identical skills to
        # authored ones by routing through the same /actions/create endpoint.
        # Like workflows, none of these are in _ALWAYS_ON_TOOLS - they reach
        # the model via g8_tool_search progressive discovery.
        skills_authoring.register(server, client)

    # Progressive tool discovery (upgrade 1 from the Anthropic talk). Must be
    # registered AFTER the other tools so the initial catalog snapshot covers
    # the full surface - the catalog itself is built lazily on first request.
    discovery.register(server, always_on=_ALWAYS_ON_TOOLS)

    resources.register(server, client)
    # Prompts are mode-aware - dev prompts reference repo-scoped dev tools,
    # gtm prompts reference org-scoped gtm tools. Registering all prompts in
    # every mode would surface workflows that reference tools the current
    # server didn't load (dev prompts pointing at `g8_connect_repo` in a
    # `gtm` server, etc.). Pass the mode so prompts.py can gate correctly.
    prompts.register(server, mode=mode)


_SERVER_INSTRUCTIONS = """\
graph8 is a B2B sales and marketing platform with CRM, prospecting, enrichment, sequences, and campaigns.

## Prospecting workflow (finding new leads)
1. g8_find_contacts - preview results with filters (free to browse, no credits)
2. g8_create_list - save matches to a CRM list. Pass one of:
   - filters=[..] - search-and-save against open data (credits per contact)
   - rows=[..]    - import explicit records you already have (free, no enrichment)
   - contact_ids=[..] - attach existing CRM contacts (free)
   Always call with dry_run=True first for filters/rows modes - returns a
   ConfirmationPreview the user must confirm before credits are charged.
3. g8_add_to_list - append more contacts to an existing list (contact_ids or rows)
4. g8_enrich_contacts - fill missing emails/phones on saved contacts (credits per contact - confirm with user)
5. g8_list_sequences - find available outreach sequences
6. g8_add_to_sequence - enroll contacts in automated outreach (sends real messages - always confirm)

## Single person lookup workflow
1. g8_lookup_person - find by email, LinkedIn URL, or name + company (1 credit)
2. g8_create_contact - save to CRM
3. g8_add_to_list or g8_enrich_contacts or g8_add_to_sequence as needed

## Campaign workflow
1. g8_gtm_list_campaigns or g8_gtm_create_campaign
2. g8_gtm_create_campaign_step (repeat for each step)
3. g8_gtm_launch_campaign (sends real outreach - always confirm)

## Dialer session workflow
1. g8_get_lists - find the contact list to dial (list_id)
2. g8_voice_list_numbers - pick a from-phone the org owns
3. g8_voice_list_agents - pick the voice agent (agent_id)
4. g8_gtm_list_campaigns - optional Studio campaign linkage (studio_campaign_id)
5. g8_voice_create_dialer_session - creates the session in PAUSED state
6. SDR opens the dialer UI to actually start dialing
7. g8_voice_pause_session / g8_voice_resume_session / g8_voice_stop_session - lifecycle control

## Rules
- NEVER call g8_create_list (filters mode), g8_enrich_contacts, g8_add_to_sequence, or g8_gtm_launch_campaign without user confirmation. These cost credits or send real messages. Always run dry_run=True first when the tool supports it.
- NEVER call g8_voice_create_dialer_session or g8_voice_stop_session without user confirmation. They mutate real dialer state. Pause and resume are reversible and may be called without explicit confirmation if the user already asked.
- Always preview with g8_find_contacts before g8_create_list(filters=...).
- IDs (contact_id, list_id, sequence_id, campaign_id, agent_id, session_id) come from other tool responses. Never guess them.
- When a tool returns an error, explain it clearly and suggest the fix.

## Skills - load before starting a multi-step workflow
Call g8_list_skills at the start of any non-trivial task to see available
prescriptive workflow guides. When a skill's when_to_use matches the user's
request, call g8_load_skill(slug) and follow it. Skills cover sequencing,
confirmations, and gotchas that aren't obvious from individual tool docs.
Available skills cover prospecting, campaigns, tracking install, and inbox replies.

## Workflow building - Action+LLM-skill, NOT Agent node
When building or editing a workflow (g8_workflow_*), any sub-step that does
content generation, summarization, classification, extraction, or parsing
MUST be implemented as an Action node (llm_completion) bound to an LLM skill
you author with g8_workflow_skill_create_llm (or its alias g8_skill_create_llm).
The Agent node is reserved for autonomous multi-turn tool use only.

Pattern:
  1. g8_workflow_skill_create_llm with a prompt template containing
     {variable} placeholders for each upstream input. For deterministic
     downstream wiring (e.g. a Delay node that needs an integer), say so
     in the prompt: "Reply with ONLY an integer number of days."
  2. g8_workflow_add_node type=llm_completion, action_id=<new skill id>.
     input_mappings stubs auto-populate; fill each one with
     {{trigger.*}} or {{<upstream_node_id>.*}}.
  3. Downstream nodes read the skill's output as {{<node_id>.result}}.

Examples that are ALWAYS Action+skill (never Agent):
  - "summarize this thread" -> LLM skill, Action node
  - "draft a follow-up email" -> LLM skill, Action node
  - "extract the time delay from the customer's reply" -> LLM skill with
     "Reply with ONLY a number followed by a unit" constraint, Action node,
     then Delay node that reads {{<extract_node>.result}}
  - "classify the objection type" -> LLM skill, Action node, then Branch

The g8_workflow_skill_* tools are not always-on; reach them via
g8_tool_search("workflow skill create") whenever a workflow step needs
generation/summarization/extraction/classification.
"""


def _enable_tool_list_changed_capability(server: FastMCP) -> None:
    """Declare `tools.listChanged=true` in the MCP capabilities.

    Without this, clients have no reason to listen for
    `notifications/tools/list_changed` emitted by `g8_tool_search` when it
    activates new tools mid-session. With it, conformant clients re-fetch
    tools/list on the notification and the newly-activated schemas become
    callable in the same session.

    Implementation: FastMCP's transports (stdio, SSE, streamable-HTTP) all
    call `_mcp_server.create_initialization_options()` with no arguments,
    which constructs an empty `NotificationOptions(tools_changed=False)`.
    We wrap the method to inject `tools_changed=True` when the caller
    didn't specify - preserving any future explicit overrides.

    Backward compatibility:
    - Clients that don't understand `tools.listChanged` ignore the capability
      field (MCP spec requires forward-compat on capabilities).
    - Clients that do understand it can now refresh tools/list on notification
      instead of waiting for a reconnect.
    - The notification itself is best-effort inside `g8_tool_search`; a
      transport-level failure never breaks the tool call.
    """
    low_level = server._mcp_server
    original = low_level.create_initialization_options

    def patched(notification_options=None, experimental_capabilities=None):
        if notification_options is None:
            notification_options = NotificationOptions(tools_changed=True)
        return original(notification_options, experimental_capabilities)

    low_level.create_initialization_options = patched


def create_server() -> FastMCP:
    """Create MCP server for local stdio mode. Requires G8_API_KEY env var."""
    server = FastMCP("graph8", instructions=_SERVER_INSTRUCTIONS)
    client = G8Client(require_key=True)
    _register_tools(server, client, mode=MCP_MODE)
    _enable_tool_list_changed_capability(server)
    return server


# ---------------------------------------------------------------------------
# JWT → API key resolution (for PropelAuth MCP OAuth 2.1 tokens)
# ---------------------------------------------------------------------------

async def _introspect_token(token: str) -> dict | None:
    """Validate a token via PropelAuth's introspection endpoint."""
    logger.info("MCP introspect: calling %s (client_id=%s...)", _INTROSPECT_URL, _INTROSPECT_CLIENT_ID[:8] if _INTROSPECT_CLIENT_ID else "EMPTY")
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.post(
            _INTROSPECT_URL,
            data={"token": token},
            auth=(_INTROSPECT_CLIENT_ID, _INTROSPECT_CLIENT_SECRET),
        )
        if resp.status_code != 200:
            logger.warning("MCP introspection failed: status=%s body=%s", resp.status_code, resp.text[:200])
            return None
        data = resp.json()
        if not data.get("active"):
            logger.warning("MCP introspection: token is not active (sub=%s)", data.get("sub", "?"))
            return None
        logger.info("MCP introspection: token valid for user %s", data.get("sub", "?"))
        return data


async def _fetch_user_org(user_id: str) -> str | None:
    """Fetch user's active org ID (PropelAuth UUID) from backend API.

    Uses propelauth-api.com (the real backend API host) with
    X-Propelauth-url header, matching the official SDK's approach.
    auth.graph8.com is a frontend proxy that may strip query params.
    """
    logger.info("MCP: fetching org for user %s via propelauth-api.com", user_id)
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.get(
            f"https://propelauth-api.com/api/backend/v1/user/{user_id}",
            headers={
                "Authorization": f"Bearer {_PA_API_KEY}",
                "X-Propelauth-url": _PA_HOSTNAME,
            },
            params={"include_orgs": "true"},
        )
        if resp.status_code != 200:
            logger.warning("MCP user fetch failed: status=%s body=%s", resp.status_code, resp.text[:200])
            return None
        user_data = resp.json()

    # Pick active org → first org fallback
    props = user_data.get("properties") or {}
    active_org_id = props.get("active_org_id")
    # PropelAuth API returns "org_id_to_org_info" (not "org_id_to_org_member_info")
    org_map = user_data.get("org_id_to_org_info") or user_data.get("org_id_to_org_member_info") or {}

    logger.info(
        "MCP: user %s email=%s active_org=%s org_count=%d org_ids=%s",
        user_id, user_data.get("email", "?"), active_org_id, len(org_map), list(org_map.keys())[:3],
    )

    if active_org_id:
        for pa_uuid, info in org_map.items():
            if info.get("legacy_org_id") == active_org_id:
                return pa_uuid
        if active_org_id in org_map:
            return active_org_id

    if org_map:
        return next(iter(org_map))
    return None


# TTL used when we couldn't validate the freshly-created key against the backend
# (e.g. transient network error). Short enough that the next request retries
# validation, long enough to absorb a brief outage without hammering PropelAuth.
_UNVALIDATED_CACHE_TTL = 300  # 5 minutes


async def _validate_api_key(api_key: str) -> tuple[bool, bool]:
    """Verify a PropelAuth end-user API key by asking PropelAuth directly.

    Returns (is_valid, validation_ran):
    - (True, True)   - PropelAuth confirmed the key is active
    - (False, True)  - PropelAuth rejected the key (do NOT cache)
    - (True, False)  - could not reach PropelAuth; let caller decide how to proceed

    This is NOT called on the OAuth mint path anymore (see notes in
    `_resolve_jwt_to_api_key`). It's retained for tests and any future explicit
    caller that wants to check liveness against PropelAuth without going through
    a graph8 backend route (graph8 routes use JWT-only middleware and cannot
    accept PropelAuth end-user API keys).
    """
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(
                "https://propelauth-api.com/api/backend/v1/end_user_api_keys/validate",
                headers={
                    "Authorization": f"Bearer {_PA_API_KEY}",
                    "X-Propelauth-url": _PA_HOSTNAME,
                    "Content-Type": "application/json",
                },
                json={"api_key_token": api_key},
            )
        if 200 <= resp.status_code < 300:
            return True, True
        if resp.status_code in (400, 404):
            # 404 = key not found (revoked); 400 = malformed request
            return False, True
        # 401 on /validate = OUR integration key is bad (config issue, don't
        # punish users). Anything else = unexpected; fail open.
        return True, False
    except Exception as e:
        logger.warning("MCP: validate_api_key network error (%s)", e)
        return True, False


async def _create_api_key(org_id: str, user_id: str) -> str | None:
    """Create a temporary org API key via PropelAuth backend API."""
    expires_at = int(time.time()) + _JWT_CACHE_TTL
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.post(
            "https://propelauth-api.com/api/backend/v1/end_user_api_keys",
            headers={
                "Authorization": f"Bearer {_PA_API_KEY}",
                "X-Propelauth-url": _PA_HOSTNAME,
                "Content-Type": "application/json",
            },
            json={
                "org_id": org_id,
                "user_id": user_id,
                "expires_at_seconds": expires_at,
                "metadata": {"source": "mcp_oauth"},
            },
        )
        if resp.status_code not in (200, 201):
            logger.warning("MCP API key creation failed: %s %s", resp.status_code, resp.text)
            return None
        return resp.json().get("api_key_token")


def _redis():
    """Get Redis client (lazy import to avoid circular deps at module level)."""
    from shared import apps
    return apps.infra().redis()


def _get_mcp_rate_limiter():
    """Get or create the MCP rate limiter (Redis-backed with in-memory fallback)."""
    global _mcp_rate_limiter
    if _mcp_rate_limiter is not None:
        return _mcp_rate_limiter

    try:
        from enrichment.interfaces.fastapi.api_key_auth import RedisRateLimiter

        redis_client = _redis()
        _mcp_rate_limiter = RedisRateLimiter(
            redis_client=redis_client,
            requests_per_minute=_MCP_REQUESTS_PER_MINUTE,
            requests_per_second=_MCP_REQUESTS_PER_SECOND,
            key_prefix=_MCP_RATE_LIMIT_PREFIX,
        )
        logger.info("MCP using Redis-based rate limiter (%d/min, %d/sec)", _MCP_REQUESTS_PER_MINUTE, _MCP_REQUESTS_PER_SECOND)
    except Exception as e:
        logger.warning("MCP rate limiter: Redis unavailable, using in-memory fallback: %s", e)
        from enrichment.interfaces.fastapi.api_key_auth import SlidingWindowRateLimiter

        _mcp_rate_limiter = SlidingWindowRateLimiter(
            requests_per_minute=_MCP_REQUESTS_PER_MINUTE,
            requests_per_second=_MCP_REQUESTS_PER_SECOND,
        )

    return _mcp_rate_limiter


async def _check_mcp_rate_limit(token: str) -> tuple[bool, int]:
    """Check rate limit for an MCP request. Returns (is_allowed, retry_after)."""
    rate_limit_key = token[:16] if len(token) >= 16 else token
    limiter = _get_mcp_rate_limiter()

    try:
        from enrichment.interfaces.fastapi.api_key_auth import RedisRateLimiter

        if isinstance(limiter, RedisRateLimiter):
            return await limiter.is_allowed(rate_limit_key)
        return limiter.is_allowed(rate_limit_key)
    except Exception:
        # If rate limiter fails, allow the request (fail open)
        return True, 0


# ---------------------------------------------------------------------------
# Per-user tool filtering (based on mcp_tool_group preference)
# ---------------------------------------------------------------------------

# Tools that are exclusively dev-oriented (repo scanning, code generation).
# These are excluded when the user selects "crm" or "campaigns" mode.
_DEV_ONLY_TOOLS = frozenset({
    "g8_connect_repo", "g8_scan_repo", "g8_get_scan_results",
    "g8_status", "g8_doctor", "g8_install_spine", "g8_apply_install",
    "g8_get_tracking_snippet", "g8_get_form_template",
})

# CRM/prospecting tools that are irrelevant in dev mode.
# Developers want repo scanning and GTM install - not list building or enrichment.
_CRM_ONLY_TOOLS = frozenset({
    "g8_find_contacts", "g8_find_companies",
    "g8_create_contact", "g8_create_list", "g8_add_to_list",
    "g8_enrich_contacts", "g8_get_deals", "g8_get_deal",
    "g8_get_pipeline", "g8_get_tasks", "g8_create_task",
    "g8_create_note", "g8_get_activities",
    # Custom column management - only useful when working with CRM lists.
    "g8_list_fields", "g8_create_field", "g8_delete_field", "g8_set_field_value",
})

# ---------------------------------------------------------------------------
# Progressive tool discovery (upgrade 1 from Anthropic's Nov 2026 talk)
# ---------------------------------------------------------------------------
#
# With ~105 registered tools in `all` mode (incl. 19 g8_workflow_*), shipping every schema in tools/list
# at connect time wastes context - most sessions only touch a handful. We
# default-filter tools/list down to this small always-on set. Everything else
# is discoverable via `g8_tool_search`, which writes activations to a
# per-session Redis set that the filter reads on subsequent list calls.
#
# Invariants:
# - Must contain g8_tool_search (the escape hatch to the rest).
# - Keep small - if this grows past ~15 the deferred-discovery win vanishes.
# - Entries must be tool names that exist when registration completes (the
#   startup catalog build verifies this; missing entries are logged as WARN).
_ALWAYS_ON_TOOLS: frozenset[str] = frozenset({
    # The discovery tool itself - without this the model can never reach the rest.
    "g8_tool_search",
    # Skill catalog - the server instructions explicitly direct the agent to
    # "Call g8_list_skills at the start of any non-trivial task". If it weren't
    # in the always-on set, the agent would need a `g8_tool_search` detour
    # before it could even orient itself - which defeats the purpose of the
    # skills surface. `g8_load_skill` is not always-on: once the catalog lists
    # its slugs the agent can widen visibility via `g8_tool_search("load skill")`.
    "g8_list_skills",
    # Universal read entry points - every graph8 workflow starts with one of these.
    "g8_search_contacts",
    "g8_search_companies",
    # Single-entity lookups - cheap, credit-metered, common first step.
    "g8_lookup_person",
    "g8_lookup_company",
    # Prospecting - primary value action for sales-oriented sessions.
    "g8_find_contacts",
    "g8_find_companies",
    # List hub - needed to browse existing saved audiences.
    "g8_get_lists",
    "g8_enrich_contacts",
    # Campaign + sequence entry points (one each).
    "g8_gtm_list_campaigns",
    "g8_list_sequences",
    "g8_list_inbox",
    # List building + custom-field management - common follow-ups after browsing lists.
    "g8_create_list",
    "g8_add_to_list",
    "g8_create_field",
    "g8_set_field_value",
    # Deals pipeline read - common CRM entry point.
    "g8_get_deals",
    # Voice / dialer surface - read + lifecycle controls callable inline.
    "g8_voice_list_dialer_sessions",
    "g8_voice_get_dialer_stats",
    "g8_voice_list_agents",
    "g8_voice_create_dialer_session",
    "g8_voice_pause_session",
    "g8_voice_resume_session",
    "g8_voice_stop_session",
    # Compete-tracking entry points. Third-party agents (e.g. CIENCE) need
    # the keyword surface visible without a `g8_tool_search` detour - the
    # competitor-intent workflow is a primary value action, not a niche
    # advanced surface. The other 9 g8_intent_* tools (pages layer + filter
    # mutation) stay behind progressive discovery.
    "g8_intent_list_keywords",
    "g8_intent_create_from_domain",
    "g8_intent_keyword_contacts",
    "g8_intent_keyword_companies",
})

# Safety net: ensure the discovery tool is in the allowlist at import time so
# a misedit above can't lock users out of the rest of the surface.
assert "g8_tool_search" in _ALWAYS_ON_TOOLS, (
    "g8_tool_search must remain in _ALWAYS_ON_TOOLS or progressive discovery breaks"
)


def _filter_tools_list(tools: list[dict], group: str) -> list[dict]:
    """Filter MCP tools based on user's preferred tool group.

    In remote "all" mode, both dev and GTM tools are registered.
    GTM tools are prefixed with g8_gtm_* to avoid name collisions.

    This is the GROUP filter (user's saved preference). Progressive discovery
    is a separate filter applied on top - see `_filter_tools_progressive`.
    """
    if group == "all" or not group:
        return tools
    if group in ("crm", "campaigns"):
        # Keep platform + GTM + prospecting tools, remove dev-only tools
        return [t for t in tools if t.get("name") not in _DEV_ONLY_TOOLS]
    if group == "dev":
        # Keep platform + dev tools, remove GTM-prefixed duplicates and CRM-only tools
        return [t for t in tools if not t.get("name", "").startswith("g8_gtm_") and t.get("name") not in _CRM_ONLY_TOOLS]
    return tools


# Progressive discovery can be disabled per-deployment or per-client. Stdio
# clients (Cursor, Claude Code, local uvx) tend to assume tools/list is the
# full surface - they don't call discovery tools, so default-filtering hides
# capability from them. Remote HTTP mode keeps discovery on by default because
# Claude.ai and Claude Desktop handle the meta-tool cleanly.
_PROGRESSIVE_DISCOVERY_ENABLED = (
    os.getenv("G8_MCP_PROGRESSIVE_DISCOVERY", "true").lower() == "true"
)


def _filter_tools_progressive(tools: list[dict], activated: frozenset[str]) -> list[dict]:
    """Trim tools/list to the always-on allowlist plus session-activated set.

    This is what produces the context win from upgrade 1 of the Anthropic
    talk. The model sees ~11 tools at connect time instead of 83; `g8_tool_search`
    widens the set on demand.
    """
    if not _PROGRESSIVE_DISCOVERY_ENABLED:
        return tools
    visible = _ALWAYS_ON_TOOLS | activated
    return [t for t in tools if t.get("name") in visible]


def _apply_tools_list_filter(
    resp_data: dict,
    tool_group: str,
    activated: frozenset[str],
) -> dict:
    """Apply group + progressive filters to a parsed JSON-RPC tools/list result.

    Returns the original dict if it is not a tools/list response; otherwise
    mutates `resp_data["result"]["tools"]` in place and returns it.
    """
    if "result" not in resp_data or "tools" not in resp_data.get("result", {}):
        return resp_data
    original_count = len(resp_data["result"]["tools"])
    filtered = resp_data["result"]["tools"]
    if tool_group != "all":
        filtered = _filter_tools_list(filtered, tool_group)
    group_count = len(filtered)
    if _PROGRESSIVE_DISCOVERY_ENABLED:
        filtered = _filter_tools_progressive(filtered, activated)
    resp_data["result"]["tools"] = filtered
    logger.info(
        "MCP tools/list filter: group=%s %d->%d (group)->%d (progressive, activated=%d)",
        tool_group, original_count, group_count, len(filtered),
        len(activated),
    )
    return resp_data


def _rewrite_tools_list_body(
    body: bytes,
    tool_group: str,
    activated: frozenset[str],
) -> bytes:
    """Rewrite a tools/list HTTP response body with tool filters applied.

    Handles both response modes:
    - JSON: the body is a single JSON object. Parse, filter, re-serialize.
    - SSE (text/event-stream): the body is a stream of `event: message / data:
      <json> / blank-line` frames. Walk frames, find the one whose data is the
      tools/list JSONRPCResponse, filter the tools array in place, re-serialize
      the frame. All other frames (priming events, server->client notifications
      that may arrive before the response) pass through unchanged.

    Falls back to returning the body unmodified on any parse error, so a
    malformed response (which the upstream handler would have errored on
    anyway) is never worse after this filter than before it.
    """
    text = body.decode("utf-8", errors="replace")
    stripped = text.lstrip()
    # SSE frames always begin with one of these event fields per the spec.
    is_sse = stripped.startswith(("event:", "data:", "id:", "retry:", ":"))

    if not is_sse:
        try:
            resp_data = json.loads(body)
        except (json.JSONDecodeError, ValueError):
            return body
        _apply_tools_list_filter(resp_data, tool_group, activated)
        return json.dumps(resp_data).encode()

    # Split on blank-line frame separators (spec allows \n\n or \r\n\r\n).
    # Normalise CRLF first so the split is uniform, then reconstruct with \n.
    normalised = text.replace("\r\n", "\n")
    frames = normalised.split("\n\n")
    out_frames: list[str] = []
    for frame in frames:
        if not frame.strip():
            out_frames.append(frame)
            continue
        lines = frame.split("\n")
        rewrote = False
        for i, line in enumerate(lines):
            # SSE "data:" lines may be "data:foo" or "data: foo" per the spec.
            if line.startswith("data:"):
                payload = line[5:].lstrip(" ")
                if not payload:
                    continue
                try:
                    resp_data = json.loads(payload)
                except (json.JSONDecodeError, ValueError):
                    continue
                if isinstance(resp_data, dict) and "tools" in resp_data.get("result", {}):
                    _apply_tools_list_filter(resp_data, tool_group, activated)
                    lines[i] = f"data: {json.dumps(resp_data)}"
                    rewrote = True
                    break
        out_frames.append("\n".join(lines))
        if rewrote:
            # Continue emitting the remaining frames (notifications, tail
            # events) verbatim. We only needed to rewrite the response frame.
            pass
    return "\n\n".join(out_frames).encode()


def _api_key_fingerprint(api_key: str | None) -> str:
    """Short, stable, non-reversible tag for correlating a caller in logs.

    Never logs the raw key; emits the first 10 hex chars of its sha256.
    """
    if not api_key:
        return "anon"
    return hashlib.sha256(api_key.encode()).hexdigest()[:10]


def _log_mcp_request(method: str | None, rpc: dict, api_key: str | None) -> None:
    """Log a one-liner per inbound MCP JSON-RPC request.

    Structured per method so log greps stay useful:

      * ``tools/call``     -> tool name at INFO, args keys + sizes at DEBUG
      * ``resources/read`` -> URI at INFO
      * everything else    -> method name at INFO

    We deliberately avoid logging full argument payloads at INFO because
    tool args routinely contain customer data (emails, phone numbers,
    search queries, etc.). DEBUG-level arg keys + short value previews are
    enough to correlate with a widget round-trip without being a PII leak.
    """
    caller = _api_key_fingerprint(api_key)
    if method == "tools/call":
        params = rpc.get("params")
        params = params if isinstance(params, dict) else {}
        name = params.get("name", "<missing>")
        args = params.get("arguments")
        args = args if isinstance(args, dict) else {}
        logger.info("MCP tools/call name=%s caller=%s", name, caller)
        if logger.isEnabledFor(logging.DEBUG) and args:
            # Only keys + coarse shape, never full values.
            shape = {
                k: f"{type(v).__name__}[{len(v)}]" if hasattr(v, "__len__") else type(v).__name__
                for k, v in args.items()
            }
            logger.debug("MCP tools/call args name=%s shape=%s caller=%s", name, shape, caller)
        return
    if method == "resources/read":
        params = rpc.get("params")
        params = params if isinstance(params, dict) else {}
        uri = params.get("uri", "<missing>")
        logger.info("MCP resources/read uri=%s caller=%s", uri, caller)
        return
    if method == "resources/list":
        logger.info("MCP resources/list caller=%s", caller)
        return
    if method == "tools/list":
        logger.info("MCP tools/list caller=%s", caller)
        return
    if method:
        logger.info("MCP request method=%s caller=%s", method, caller)


async def _fetch_user_tool_group(api_key: str) -> str:
    """Fetch user's MCP tool group preference via backend API.

    Returns the tool group string ("crm", "campaigns", "dev", "all").
    Cached in Redis for 1 hour to avoid repeated backend calls.
    Falls back to "all" on any error.
    """
    cache_key = f"{_USER_PREFS_PREFIX}{hashlib.sha256(api_key.encode()).hexdigest()[:32]}"

    # Check cache first
    try:
        redis = _redis()
        cached = await redis.get(cache_key)
        if cached:
            return cached.decode() if isinstance(cached, bytes) else cached
    except Exception:
        pass

    # Fetch from backend
    base_url = os.getenv("BACKEND_URL", os.getenv("NEXT_PUBLIC_API_URL_GROWTH", "http://localhost:8000"))
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(
                f"{base_url}/campaign-builder/profile/preferences",
                headers={"Authorization": f"Bearer {api_key}"},
            )
            if resp.status_code == 200:
                data = resp.json()
                tool_group = data.get("mcp_tool_group", "all")
                # Cache for 1 hour
                try:
                    redis = _redis()
                    await redis.setex(cache_key, _PREFS_CACHE_TTL, tool_group)
                except Exception:
                    pass
                return tool_group
    except Exception as e:
        logger.debug("MCP: failed to fetch user tool group preference: %s", e)

    return "all"


def _user_cache_key_for(user_id: str, org_id: str) -> str:
    """Build the user-level cache key. Includes org_id so org switches invalidate."""
    return f"{_USER_CACHE_PREFIX}{hashlib.sha256(f'{user_id}:{org_id}'.encode()).hexdigest()[:32]}"


def _key_reverse_key_for(api_key: str) -> str:
    """Reverse-mapping key: api_key sha → JSON list of cache keys to invalidate."""
    return f"{_KEY_REVERSE_PREFIX}{hashlib.sha256(api_key.encode()).hexdigest()[:32]}"


async def _store_key_reverse_mapping(api_key: str, cache_keys: list[str]) -> None:
    """Store reverse mapping so we can invalidate cache entries by api_key on 401."""
    if not cache_keys:
        return
    try:
        redis = _redis()
        await redis.setex(_key_reverse_key_for(api_key), _JWT_CACHE_TTL, json.dumps(cache_keys))
    except Exception:
        # Non-fatal - just means we can't bust cache by api_key later
        pass


async def invalidate_cached_key(api_key: str) -> int:
    """Invalidate every Redis cache entry that maps to this api_key.

    Called by client.safe_call when a tool gets a 401 from the backend, so the
    next request bypasses the stale cache and provisions a fresh key.

    Returns the number of cache entries deleted (0 if none found / Redis down).
    """
    if not api_key:
        return 0
    reverse_key = _key_reverse_key_for(api_key)
    try:
        redis = _redis()
        raw = await redis.get(reverse_key)
        if not raw:
            return 0
        cache_keys = json.loads(raw.decode() if isinstance(raw, bytes) else raw)
        if not cache_keys:
            return 0
        deleted = 0
        for ck in cache_keys:
            try:
                deleted += int(bool(await redis.delete(ck)))
            except Exception:
                continue
        try:
            await redis.delete(reverse_key)
        except Exception:
            pass
        logger.info("MCP: invalidated %d cache entries for stale key ...%s", deleted, api_key[-4:])
        return deleted
    except Exception as e:
        logger.warning("MCP: invalidate_cached_key failed: %s", e)
        return 0


async def _resolve_jwt_to_api_key(token: str) -> str | None:
    """Convert a PropelAuth MCP OAuth JWT to a cached API key.

    Two-level cache to avoid repeated PropelAuth calls on token refresh:
    - Level 1 (token hash): full cache hit - zero network calls
    - Level 2 ((user_id, org_id) hash): introspect + user fetch needed - skips key creation

    Full flow (first request per user, or after org switch / cache invalidation):
    1. Introspect token → validate + get user_id
    2. Fetch user details → resolve active org
    3. Check user-cache keyed by (user_id, org_id) - hits skip key creation
    4. On miss: create a new org API key, validate it against the backend, then cache

    Important: the user-cache key includes org_id so switching active org in
    PropelAuth automatically invalidates the cache. Also, `invalidate_cached_key`
    can bust both cache levels by api_key when a tool call gets a 401 from the
    backend (e.g. PropelAuth revoked the key). This prevents the "stuck in stale
    cache for 14 days" failure mode.
    """
    token_cache_key = f"{_JWT_CACHE_PREFIX}{hashlib.sha256(token.encode()).hexdigest()[:32]}"

    # Level 1: Check token-level cache (fastest path - zero network calls).
    # On hit we still need to know the user_cache_key so the reverse mapping
    # can be refreshed; otherwise long-lived sessions that only ever hit
    # Level 1 lose their reverse mapping and 401-driven invalidation no-ops.
    try:
        redis = _redis()
        cached = await redis.get(token_cache_key)
        if cached:
            api_key = cached.decode() if isinstance(cached, bytes) else cached
            # Best-effort: re-arm the reverse mapping for this key. We don't have
            # user_id/org_id on this fast path, so we can only re-link the token
            # cache entry. The user-cache entry (if still alive) will be re-linked
            # the next time a Level 2 hit occurs.
            await _store_key_reverse_mapping(api_key, [token_cache_key])
            return api_key
    except Exception:
        pass

    # Introspect to validate token and extract user_id
    intro = await _introspect_token(token)
    if not intro:
        return None

    user_id = intro.get("sub")
    if not user_id:
        return None

    # Resolve org BEFORE checking user-cache so the cache key includes org_id.
    # This means an org switch in PropelAuth produces a different cache key
    # and naturally bypasses any previously-cached (now wrong-org) key.
    org_id = await _fetch_user_org(user_id)
    if not org_id:
        logger.warning("MCP OAuth user %s has no organization", user_id)
        return None

    user_cache_key = _user_cache_key_for(user_id, org_id)

    # Level 2: Check user+org-level cache (avoids API key creation on token refresh)
    try:
        redis = _redis()
        cached = await redis.get(user_cache_key)
        if cached:
            api_key = cached.decode() if isinstance(cached, bytes) else cached
            # Backfill token cache so the next request with the same token skips introspection
            try:
                await redis.setex(token_cache_key, _JWT_CACHE_TTL, api_key)
            except Exception:
                pass
            # Refresh reverse mapping so 401-driven invalidation reaches both keys
            await _store_key_reverse_mapping(api_key, [token_cache_key, user_cache_key])
            return api_key
    except Exception:
        pass

    # Create API key
    api_key = await _create_api_key(org_id, user_id)
    if not api_key:
        return None

    # NOTE: we intentionally do NOT post-mint validate the key here.
    #
    # History: commit a7c8e49d2 (2026-04-19) added a `_validate_api_key()` call
    # after mint to avoid caching a stale/bad key for 14 days. It hit
    # `/api/v1/profile` (which doesn't exist -> 404 -> always rejected).
    # A follow-up fix pointed it at `/campaign-builder/profile/mcp/status`, but
    # THAT route uses graph8's JWT-only auth middleware (`require_user`) which
    # rejects PropelAuth end-user API keys as malformed tokens. Either way,
    # every freshly-minted key was being rejected -> OAuth broken for everyone.
    #
    # The stale-cache safety net from that same commit is sufficient on its own:
    #   1. cache key now includes org_id  -> org switch misses cache
    #   2. reverse-mapping + invalidate_cached_key() on 401 in safe_call() ->
    #      any stale key self-heals on the next tool call
    # So we trust PropelAuth's response to the mint call and cache with the
    # full TTL. `_validate_api_key()` is kept in the module for explicit callers
    # and tests but is no longer wired into the OAuth resolution path.
    cache_ttl = _JWT_CACHE_TTL

    # Cache by both token and user_id+org_id
    try:
        redis = _redis()
        await redis.setex(token_cache_key, cache_ttl, api_key)
        await redis.setex(user_cache_key, cache_ttl, api_key)
    except Exception:
        pass

    # Record reverse mapping so invalidate_cached_key() can bust both entries on 401
    await _store_key_reverse_mapping(api_key, [token_cache_key, user_cache_key])

    logger.info(
        "MCP OAuth: provisioned API key for user=%s org=%s (key=...%s, ttl=%ds)",
        intro.get("username", user_id), org_id,
        api_key[-4:] if len(api_key) >= 4 else "?",
        cache_ttl,
    )
    return api_key


# ---------------------------------------------------------------------------
# ASGI auth middleware
# ---------------------------------------------------------------------------

class _RemoteMCPApp:
    """ASGI app that serves MCP over HTTP with bearer auth.

    Combines authentication (API key + JWT/OAuth) with lazy lifecycle
    management for the MCP session manager.  The session manager is started
    as a background task on the first request - this works around FastAPI's
    ``app.mount()`` not forwarding lifespan events to sub-applications.
    """

    def __init__(self, handler: StreamableHTTPASGIApp, session_manager: StreamableHTTPSessionManager):
        self._handler = handler
        self._sm = session_manager
        self._started = False
        self._lock = asyncio.Lock()

    async def _ensure_started(self) -> None:
        """Start the session manager's task group once (lazy, thread-safe)."""
        if self._started:
            return
        async with self._lock:
            if self._started:
                return

            ready = asyncio.Event()

            async def _lifecycle() -> None:
                async with self._sm.run():
                    ready.set()
                    await asyncio.Event().wait()  # block until cancelled

            asyncio.create_task(_lifecycle())
            await ready.wait()
            self._started = True
            logger.info("MCP session manager started (lazy init)")

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            # Non-HTTP scopes (e.g. lifespan) - must still send a valid response
            # to avoid Starlette's "No response returned" error.
            return

        request = Request(scope)

        # --- Allowed MCP Streamable HTTP methods ---
        # POST: JSON-RPC requests/responses (initialize, tools/list, tools/call, ...)
        # DELETE: explicit session termination
        # OPTIONS: CORS preflight (handled below without auth)
        # GET: Server-Sent Events (SSE) notification stream per MCP spec 2025-03-26.
        #   Required by ChatGPT custom MCP connectors - they open a GET right after
        #   `initialize` and treat 405 as a fatal "Connection error". claude.ai
        #   doesn't open this stream, which is why it survived without GET support.
        #   The MCP SDK's StreamableHTTPServerTransport handles GET natively
        #   (see _handle_get_request in mcp/server/streamable_http.py).
        if request.method not in ("GET", "POST", "DELETE", "OPTIONS"):
            response = JSONResponse(
                {"error": f"Method {request.method} not allowed."},
                status_code=405,
                headers={"Allow": "GET, POST, DELETE, OPTIONS"},
            )
            await response(scope, receive, send)
            return

        # --- CORS preflight: let OPTIONS through without auth ---
        if request.method == "OPTIONS":
            response = JSONResponse(
                content=None,
                status_code=204,
                headers={
                    "Access-Control-Allow-Origin": request.headers.get("origin", "*"),
                    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
                    "Access-Control-Allow-Headers": "Authorization, Content-Type, Accept, Mcp-Session-Id",
                    "Access-Control-Max-Age": "86400",
                },
            )
            await response(scope, receive, send)
            return

        auth_header = request.headers.get("authorization", "")

        # --- Auth: require Bearer token ---
        if not auth_header.lower().startswith("bearer "):
            scheme = request.headers.get("x-forwarded-proto", request.url.scheme)
            backend_url = os.getenv("BACKEND_URL", f"{scheme}://{request.url.netloc}")
            resource_metadata_url = f"{backend_url}/.well-known/oauth-protected-resource"
            response = JSONResponse(
                {"error": "Missing or invalid Authorization header"},
                status_code=401,
                headers={
                    "WWW-Authenticate": f'Bearer resource_metadata="{resource_metadata_url}"',
                },
            )
            await response(scope, receive, send)
            return

        token = auth_header[7:]

        # --- Detect token type ---
        # PropelAuth OAuth 2.1 issues opaque tokens (not JWTs), so we can't
        # rely on dot-counting. Instead: if OAuth introspection is configured,
        # try it for any token that doesn't look like a Developer API key.
        is_oauth_token = _INTROSPECT_CLIENT_ID and len(token) > 40
        logger.info(
            "MCP auth: token len=%d, dots=%d, oauth_introspect=%s",
            len(token), token.count("."), "yes" if is_oauth_token else "no",
        )

        # --- OAuth token → API key resolution ---
        if is_oauth_token:
            try:
                api_key = await _resolve_jwt_to_api_key(token)
            except Exception:
                logger.exception("MCP OAuth: token resolution failed")
                response = JSONResponse(
                    {"error": "Internal error during OAuth token resolution"},
                    status_code=500,
                )
                await response(scope, receive, send)
                return
            if not api_key:
                logger.warning("MCP OAuth: token resolution returned None - token invalid or user has no org")
                response = JSONResponse(
                    {"error": "Invalid or expired MCP OAuth token"},
                    status_code=401,
                )
                await response(scope, receive, send)
                return
            logger.info("MCP OAuth: token resolved to API key successfully")
            set_api_key(api_key)
        else:
            logger.info("MCP auth: using token as API key directly")
            set_api_key(token)

        # --- Rate limiting (per API key) ---
        try:
            is_allowed, retry_after = await _check_mcp_rate_limit(token)
        except Exception:
            logger.exception("MCP rate limiter error - allowing request")
            is_allowed, retry_after = True, 0
        if not is_allowed:
            logger.warning("MCP rate limit exceeded for key %s...", token[:8])
            response = JSONResponse(
                {"error": "Rate limit exceeded. Please slow down."},
                status_code=429,
                headers={
                    "Retry-After": str(retry_after),
                    "X-RateLimit-Limit-Minute": str(_MCP_REQUESTS_PER_MINUTE),
                    "X-RateLimit-Limit-Second": str(_MCP_REQUESTS_PER_SECOND),
                },
            )
            await response(scope, receive, send)
            return

        # --- Start session manager (once) and forward to MCP handler ---
        try:
            await self._ensure_started()
        except Exception:
            logger.exception("MCP session manager startup failed")
            response = JSONResponse(
                {"error": "MCP server startup error"},
                status_code=500,
            )
            await response(scope, receive, send)
            return

        # --- GET fast-path: SSE notification stream ---
        # GET /mcp/ opens a Server-Sent Events stream for server→client
        # notifications (per MCP Streamable HTTP spec 2025-03-26). It carries
        # no JSON-RPC body, so there is nothing to buffer or filter; reading
        # `receive()` here would also block waiting for a body that never
        # arrives. Forward directly to the SDK handler with the original
        # `receive` so it can observe genuine TCP disconnects on the long-
        # lived stream. ChatGPT's custom MCP connector requires this path;
        # claude.ai never opens it (which is why the previous 405 went
        # unnoticed).
        if request.method == "GET":
            resolved_key = get_api_key() or token
            logger.info("MCP SSE stream opened: key=%s...", resolved_key[:8])
            try:
                await self._handler(scope, receive, send)
            except Exception:
                logger.exception("MCP SSE handler error")
                response = JSONResponse(
                    {"error": "Internal MCP server error"},
                    status_code=500,
                )
                await response(scope, receive, send)
            return

        # --- Per-user tool filtering for tools/list requests ---
        # Read request body to check if this is a tools/list call.
        # If so, fetch user preference and filter the response.
        body_chunks = []
        try:
            while True:
                msg = await receive()
                body_chunks.append(msg.get("body", b""))
                if not msg.get("more_body", False):
                    break
        except Exception:
            logger.exception("MCP: error reading request body")
            response = JSONResponse(
                {"error": "Error reading request body"},
                status_code=400,
            )
            await response(scope, receive, send)
            return
        raw_body = b"".join(body_chunks)

        is_tools_list = False
        tool_group = "all"
        activated_session_tools: frozenset[str] = frozenset()
        resolved_key = get_api_key() or token
        try:
            rpc = json.loads(raw_body)
            method = rpc.get("method")
            if method == "tools/list":
                is_tools_list = True
                tool_group = await _fetch_user_tool_group(resolved_key)
                if _PROGRESSIVE_DISCOVERY_ENABLED:
                    try:
                        activated_session_tools = await get_activated(
                            session_id_for_key(resolved_key)
                        )
                    except Exception:
                        logger.exception("MCP: failed to read activated session tools")
                        activated_session_tools = frozenset()

            # --- Lightweight request logging (info level) ----------------
            # Logs just enough to diagnose routing / client-side issues
            # without leaking full arg payloads. Tool args + resource URIs
            # are surfaced at DEBUG only. Swallows any shape error so this
            # never blocks a request.
            try:
                _log_mcp_request(method, rpc, resolved_key)
            except Exception:
                logger.debug("MCP: request logging failed", exc_info=True)
        except (json.JSONDecodeError, KeyError):
            pass

        # Replay the buffered body for the downstream handler.
        #
        # IMPORTANT for SSE responses: after replaying the request body we
        # must NOT synthesise an immediate `http.disconnect` - sse-starlette
        # polls `receive()` in the background while streaming, and the first
        # http.disconnect it sees terminates the SSE stream. In JSON mode
        # the handler only calls receive() once (to read the body), so the
        # old shortcut worked by accident; in SSE mode it cuts the stream
        # off before the tool-call response and any `tools/list_changed`
        # notification can be written.
        #
        # Correct behaviour: deliver the body once, then proxy real receive
        # events from the upstream ASGI runtime (the actual TCP disconnect).
        body_sent = False

        async def replay_receive():
            nonlocal body_sent
            if not body_sent:
                body_sent = True
                return {"type": "http.request", "body": raw_body, "more_body": False}
            # Forward to the real receive to surface genuine disconnects
            # when the TCP connection closes; never synthesise one early.
            return await receive()

        # Do we actually need to intercept the response?  Only tools/list calls
        # need filtering, and only when at least one filter will actually change
        # something (group != all OR progressive discovery is enabled).
        needs_filtering = is_tools_list and (
            tool_group != "all" or _PROGRESSIVE_DISCOVERY_ENABLED
        )

        try:
            if not needs_filtering:
                # No filtering needed - forward directly
                await self._handler(scope, replay_receive, send)
                return

            # Intercept response to filter tools. Buffers the entire response
            # body - fine for tools/list which closes the stream as soon as
            # the JSONRPCResponse arrives (no server-initiated events ride
            # along with it). If future methods ever get filtered here and
            # emit long-lived notifications before responding, this buffering
            # would serialise them; that is intentionally out of scope.
            response_headers: list[tuple[bytes, bytes]] = []
            response_status = 200
            body_chunks: list[bytes] = []

            async def capture_send(message):
                nonlocal response_headers, response_status
                if message["type"] == "http.response.start":
                    response_status = message.get("status", 200)
                    response_headers = list(message.get("headers", []))
                elif message["type"] == "http.response.body":
                    body_chunks.append(message.get("body", b""))

            await self._handler(scope, replay_receive, capture_send)
            response_body = b"".join(body_chunks)

            # Rewrite the response body (JSON or SSE) with our tool filters.
            try:
                filtered_body = _rewrite_tools_list_body(
                    response_body, tool_group, activated_session_tools
                )
            except Exception:
                logger.exception("MCP tools/list filter: rewrite failed, forwarding unfiltered body")
                filtered_body = response_body

            # Preserve original headers (Content-Type stays text/event-stream
            # for SSE, application/json for JSON mode); only rewrite
            # Content-Length because the body length may have changed.
            filtered_headers = [
                (k, v) for k, v in response_headers if k.lower() != b"content-length"
            ]
            filtered_headers.append((b"content-length", str(len(filtered_body)).encode()))
            await send({"type": "http.response.start", "status": response_status, "headers": filtered_headers})
            await send({"type": "http.response.body", "body": filtered_body})
        except Exception:
            logger.exception("MCP handler error")
            response = JSONResponse(
                {"error": "Internal MCP server error"},
                status_code=500,
            )
            await response(scope, receive, send)


def create_remote_app():
    """Create MCP ASGI app with bearer auth for remote HTTP access.

    Accepts both API keys (direct) and PropelAuth MCP OAuth 2.1 tokens.

    Builds the MCP handler directly (bypassing Starlette's lifespan wrapper)
    because FastAPI's ``app.mount()`` does not forward lifespan events to
    mounted sub-applications. The session manager is started lazily on the
    first HTTP request via a background task.
    """
    # SSE response mode (json_response=False) is required for
    # notifications/tools/list_changed to reach the client mid-session.
    # In JSON mode the SDK discards notifications that arrive on the request
    # stream (only a JSONRPCResponse/JSONRPCError closes the loop); in SSE mode
    # every event_message on the stream is forwarded to the client before the
    # response closes it. The official MCP client SDK sends
    # "Accept: application/json, text/event-stream" on every POST, so SSE
    # responses are backward compatible.
    server = FastMCP("graph8", json_response=False, instructions=_SERVER_INSTRUCTIONS)
    client = G8Client(require_key=False)
    _register_tools(server, client, mode=MCP_MODE)
    _enable_tool_list_changed_capability(server)

    session_manager = StreamableHTTPSessionManager(
        app=server._mcp_server,
        event_store=server._event_store,
        json_response=server.settings.json_response,
        stateless=True,
    )
    handler = StreamableHTTPASGIApp(session_manager)

    return _RemoteMCPApp(handler, session_manager)


def main() -> None:
    """Entry point for `uvx g8-mcp-server` (local stdio mode)."""
    try:
        server = create_server()
    except G8ClientError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    server.run(transport="stdio")
