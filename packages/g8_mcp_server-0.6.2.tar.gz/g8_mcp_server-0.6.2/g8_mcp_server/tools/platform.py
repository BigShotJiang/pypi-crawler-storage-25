"""Platform tools - contacts, companies, enrichment, lists, and sequences."""

from __future__ import annotations

from typing import Any

from mcp.server import FastMCP
from mcp.types import ToolAnnotations

from g8_mcp_server.client import G8Client, safe_call_typed
from g8_mcp_server.ui_apps import ui_tool_meta
from g8_mcp_server.models import (
    ActionResult,
    ActivitiesResult,
    CompaniesResult,
    ConfirmationDetail,
    ConfirmationPreview,
    ContactsResult,
    DealsResult,
    FieldsResult,
    ListsResult,
    PipelinesResult,
    ResourceDetail,
    SequenceAnalytics,
    SequencePreview,
    SequencesResult,
    TasksResult,
)

def _extract_waterfall_configs(envelope: Any) -> list[dict]:
    """Pull the waterfall config list from the list-configs API envelope.

    The developer API returns `ApiResponse[WaterfallConfigsResponse]`:
    `{"data": {"configs": [...], "list_id": ..., "count": ...}}`. We also
    tolerate the raw shape `{"configs": [...]}` for robustness across
    minor response-shape drift.
    """
    if not isinstance(envelope, dict):
        return []
    data = envelope.get("data", envelope)
    if isinstance(data, dict):
        configs = data.get("configs")
        if isinstance(configs, list):
            return [c for c in configs if isinstance(c, dict)]
    if isinstance(data, list):
        return [c for c in data if isinstance(c, dict)]
    return []


# Common seniority-level abbreviations → canonical strings in the open-data
# index. The index stores full strings like "Vice President", but LLMs and
# legacy callers frequently pass abbreviations ("VP", "SVP", etc.) because
# that's how the original skill examples and many vendor APIs phrased them.
#
# Expansion is ADDITIVE: every value the caller passed survives in the
# outbound filter, and we just append the canonical form alongside. So a
# request for ["VP"] becomes ["VP", "Vice President"]; a request that
# already used ["Vice President"] stays identical. This keeps the change
# fully backward compatible with any existing filter that already uses the
# canonical form, and matches `any_of` semantics (more values = more hits,
# never fewer).
_SENIORITY_SYNONYMS: dict[str, list[str]] = {
    "VP": ["Vice President"],
    "V.P.": ["Vice President"],
    "V.P": ["Vice President"],
    "SVP": ["Senior Vice President"],
    "S.V.P.": ["Senior Vice President"],
    "EVP": ["Executive Vice President"],
    "E.V.P.": ["Executive Vice President"],
    "AVP": ["Associate Vice President"],
    "A.V.P.": ["Associate Vice President"],
    "C-Level": [
        "CEO", "CFO", "COO", "CTO", "CMO", "CIO", "CRO", "CHRO", "CSO",
        "Chief", "President", "Founder",
    ],
    "C-Suite": [
        "CEO", "CFO", "COO", "CTO", "CMO", "CIO", "CRO", "CHRO", "CSO",
        "Chief", "President", "Founder",
    ],
}


def _expand_seniority_synonyms(filters: list[dict] | None) -> list[dict] | None:
    """Expand seniority_level abbreviations to canonical index strings.

    Walks ``filters`` and, for any clause with ``field == "seniority_level"``
    whose ``value`` is a list, appends the canonical form of each known
    abbreviation while preserving every value the caller supplied. Returns
    a new list/dict tree - never mutates the caller's argument.

    Non-seniority filters, non-list values, and non-dict entries pass
    through untouched, so misformed input never crashes the call.

    The expansion is intentionally case-sensitive on the well-formed forms
    (e.g. ``"VP"``) AND case-insensitive on the upper-cased version, so a
    lowercase ``"vp"`` also expands.
    """
    if not filters:
        return filters
    expanded: list[dict] = []
    for clause in filters:
        if not isinstance(clause, dict):
            expanded.append(clause)
            continue
        if clause.get("field") != "seniority_level":
            expanded.append(clause)
            continue
        value = clause.get("value")
        if not isinstance(value, list):
            expanded.append(clause)
            continue
        seen: set[str] = set()
        out: list[Any] = []
        for v in value:
            if isinstance(v, str):
                if v not in seen:
                    seen.add(v)
                    out.append(v)
                synonyms = _SENIORITY_SYNONYMS.get(v) or _SENIORITY_SYNONYMS.get(v.upper())
                if synonyms:
                    for s in synonyms:
                        if s not in seen:
                            seen.add(s)
                            out.append(s)
            else:
                # Non-string values are preserved verbatim - the index
                # endpoint will validate them. Don't try to dedupe non-hashable.
                out.append(v)
        new_clause = dict(clause)
        new_clause["value"] = out
        expanded.append(new_clause)
    return expanded


# Reusable annotation presets - the three behavioral categories MCP clients
# use to decide whether to prompt, cache, or auto-run a tool call:
#
# - _READ_ONLY: safe to call anytime, idempotent (repeat calls = same result).
# - _WRITE: mutates org data but not destructive (create/add/update). Clients
#   should confirm with the user but don't need to flag this as dangerous.
# - _DESTRUCTIVE: costs credits, sends real outreach, or is irreversible.
#   Per the MCP spec, `destructiveHint=True` is the "ask forgiveness later"
#   warning that should trigger extra confirmation UX.
#
# Key subtlety: when readOnlyHint=False, the MCP spec defaults destructiveHint
# to True. So to express "mutates but not destructive" we MUST set both
# readOnlyHint=False AND destructiveHint=False explicitly.
_READ_ONLY = ToolAnnotations(readOnlyHint=True, idempotentHint=True)
_WRITE = ToolAnnotations(
    readOnlyHint=False, destructiveHint=False, idempotentHint=False, openWorldHint=True
)
_DESTRUCTIVE = ToolAnnotations(destructiveHint=True, openWorldHint=True)


def register(server: FastMCP, client: G8Client) -> None:
    """Register platform tools on the MCP server."""

    # ------------------------------------------------------------------
    # CRM tools - query YOUR database (PostgreSQL)
    # ------------------------------------------------------------------

    @server.tool(
        annotations=_READ_ONLY,
        # Drives ui://contacts/list - shared with g8_find_contacts.
        meta=ui_tool_meta("ui://contacts/list"),
    )
    async def g8_search_contacts(
        email: str | None = None,
        list_id: str | None = None,
        name: str | None = None,
        job_title: str | None = None,
        seniority_level: str | None = None,
        company_name: str | None = None,
        country: str | None = None,
        page: int = 1,
        limit: int = 50,
    ) -> ContactsResult | str:
        """Search contacts already in your CRM database.

        Returns contacts that your organization has imported or created.
        Use this to find people you already know about - NOT for prospecting.
        For finding new leads, use g8_find_contacts instead.

        Args:
            email: Filter by email address (exact match)
            list_id: Filter by contact list ID
            name: Filter by first or last name (partial match)
            job_title: Filter by job title (partial match)
            seniority_level: Filter by seniority (exact: C-Suite, VP, Director, Manager, etc.)
            company_name: Filter by company name (partial match)
            country: Filter by country (exact match)
            page: Page number (default 1)
            limit: Items per page (default 50, max 200)
        """
        params = {
            "email": email, "list_id": list_id, "name": name,
            "job_title": job_title, "seniority_level": seniority_level,
            "company_name": company_name, "country": country,
            "page": page, "limit": limit,
        }
        return await safe_call_typed(
            client.get("/contacts", params),
            ContactsResult.from_envelope,
            context="Contact search",
        )

    @server.tool(
        annotations=_READ_ONLY,
        # Drives ui://companies/list - shared with g8_find_companies.
        meta=ui_tool_meta("ui://companies/list"),
    )
    async def g8_search_companies(
        domain: str | None = None,
        industry: str | None = None,
        name: str | None = None,
        page: int = 1,
        limit: int = 50,
    ) -> CompaniesResult | str:
        """Search companies already in your CRM database.

        Returns companies that your organization has imported or created.
        Use this to find companies you already track - NOT for prospecting.
        For finding new companies, use g8_find_companies instead.

        Args:
            domain: Filter by company domain (e.g. acme.com)
            industry: Filter by industry
            name: Filter by company name (partial match)
            page: Page number (default 1)
            limit: Items per page (default 50, max 200)
        """
        return await safe_call_typed(
            client.get("/companies", {"domain": domain, "industry": industry, "name": name, "page": page, "limit": limit}),
            CompaniesResult.from_envelope,
            context="Company search",
        )

    # ------------------------------------------------------------------
    # Prospecting tools - search OPEN DATA index (OpenSearch, 300M+ records)
    # ------------------------------------------------------------------

    @server.tool(annotations=_READ_ONLY)
    async def g8_lookup_person(
        email: str | None = None,
        linkedin_url: str | None = None,
        first_name: str | None = None,
        last_name: str | None = None,
        company_domain: str | None = None,
    ) -> ResourceDetail | str:
        """Instantly look up a single person in graph8's data index.

        Provide at least one of: email, linkedin_url, or (first_name + last_name + company_domain).
        Returns enriched data including verified email, phone, job title, company info,
        and a confidence score. Costs 1 credit.

        This searches external data - the person does NOT need to be in your CRM.
        To save them to your CRM afterward, use g8_create_contact.

        Args:
            email: Person's email address
            linkedin_url: Person's LinkedIn profile URL
            first_name: Person's first name (combine with last_name + company_domain)
            last_name: Person's last name
            company_domain: Person's company domain (e.g. acme.com)
        """
        body = {k: v for k, v in {"email": email, "linkedin_url": linkedin_url, "first_name": first_name, "last_name": last_name, "company_domain": company_domain}.items() if v is not None}
        return await safe_call_typed(
            client.post("/enrichment/lookup/person", body),
            ResourceDetail.from_envelope,
            context="Person lookup",
        )

    @server.tool(
        annotations=_READ_ONLY,
        meta=ui_tool_meta("ui://companies/detail"),
    )
    async def g8_lookup_company(
        domain: str | None = None,
        name: str | None = None,
    ) -> ResourceDetail | str:
        """Instantly look up a single company in graph8's data index.

        Provide at least one of: domain or name. Returns enriched data including
        revenue, headcount, industry, tech stack, funding, and a confidence score.
        Costs 1 credit.

        This searches external data - the company does NOT need to be in your CRM.

        Args:
            domain: Company domain (e.g. acme.com)
            name: Company name
        """
        body = {k: v for k, v in {"domain": domain, "name": name}.items() if v is not None}
        return await safe_call_typed(
            client.post("/enrichment/lookup/company", body),
            ResourceDetail.from_envelope,
            context="Company lookup",
        )

    @server.tool(
        annotations=_READ_ONLY,
        # Drives ui://contacts/list - shared with g8_search_contacts.
        meta=ui_tool_meta("ui://contacts/list"),
    )
    async def g8_find_contacts(
        filters: list[dict],
        page: int = 1,
        limit: int = 25,
    ) -> ContactsResult | str:
        """Search graph8's 300M+ contact database to find new prospects.

        Unlike g8_search_contacts (which searches YOUR CRM), this searches
        the open data index for leads you don't have yet.
        Credits charged per record returned.

        Each filter is a dict with: field, operator, value.

        Fields: first_name, last_name, work_email, job_title, seniority_level,
                job_department, role, linkedin_url, city, state, country,
                company_name, company_domain, company_industry,
                company_employee_count, company_revenue, company_founded_year

        Operators: any_of, contains, all_of, none_of, is_empty, is_not_empty, between, exists

        Example filters:
            [
                {"field": "seniority_level", "operator": "any_of", "value": ["Vice President", "Director"]},
                {"field": "company_industry", "operator": "contains", "value": ["SaaS", "Software"]},
                {"field": "company_employee_count", "operator": "between", "value": [50, 500]}
            ]

        Note: the open-data index stores seniority as full strings
        ("Vice President", not "VP"). Common abbreviations (VP, SVP, EVP,
        AVP, C-Level, C-Suite) are auto-expanded server-side, so existing
        filters that use them keep working, but new code should prefer the
        canonical form.

        Args:
            filters: List of filter objects (field, operator, value)
            page: Page number (default 1)
            limit: Results per page (default 25, max 200)
        """
        # Seniority abbreviations (VP, SVP, EVP, ...) are auto-expanded to
        # the canonical strings the open-data index actually stores
        # ("Vice President", "Senior Vice President", ...). Expansion is
        # additive - original values are preserved alongside the canonical
        # form, so callers that already use canonical strings are
        # untouched.
        body = {
            "filters": _expand_seniority_synonyms(filters),
            "page": page,
            "limit": limit,
        }
        return await safe_call_typed(
            client.post("/search/contacts", body),
            ContactsResult.from_envelope,
            context="Contact prospecting search",
        )

    @server.tool(
        annotations=_READ_ONLY,
        # Drives ui://companies/list - shared with g8_search_companies.
        meta=ui_tool_meta("ui://companies/list"),
    )
    async def g8_find_companies(
        filters: list[dict],
        page: int = 1,
        limit: int = 25,
    ) -> CompaniesResult | str:
        """Search graph8's company database for new prospects.

        Unlike g8_search_companies (which searches YOUR CRM), this searches
        the open data index for companies you don't track yet.
        Credits charged per record returned.

        Each filter is a dict with: field, operator, value.

        Fields: name, domain, industry, industry_group, employee_count, revenue,
                founded_year, country, state, city, linkedin_followers

        Operators: any_of, contains, all_of, none_of, is_empty, is_not_empty, between, exists

        Args:
            filters: List of filter objects (field, operator, value)
            page: Page number (default 1)
            limit: Results per page (default 25, max 200)
        """
        body = {"filters": filters, "page": page, "limit": limit}
        return await safe_call_typed(
            client.post("/search/companies", body),
            CompaniesResult.from_envelope,
            context="Company prospecting search",
        )

    # ------------------------------------------------------------------
    # Contact & list management - bridge between prospecting and CRM
    # ------------------------------------------------------------------

    @server.tool(annotations=_WRITE)
    async def g8_create_contact(
        work_email: str,
        first_name: str | None = None,
        last_name: str | None = None,
        job_title: str | None = None,
        company_domain: str | None = None,
        linkedin_url: str | None = None,
        direct_phone: str | None = None,
        mobile_phone: str | None = None,
        seniority_level: str | None = None,
        city: str | None = None,
        state: str | None = None,
        country: str | None = None,
        list_id: int | None = None,
    ) -> ActionResult | str:
        """Create a contact in your CRM database.

        Use this after g8_lookup_person to save a prospect you want to track,
        or to manually add a contact you know about.
        Optionally add them directly to a list by providing list_id.
        Returns the new contact_id (needed for g8_add_to_sequence and g8_add_to_list).

        Args:
            work_email: Contact's work email (required)
            first_name: First name
            last_name: Last name
            job_title: Job title
            company_domain: Company domain (e.g. acme.com)
            linkedin_url: LinkedIn profile URL
            direct_phone: Direct phone number
            mobile_phone: Mobile phone number
            seniority_level: Seniority level (C-Suite, VP, Director, Manager, etc.)
            city: City
            state: State/province
            country: Country
            list_id: Optionally add to this list immediately (from g8_create_list)
        """
        body = {k: v for k, v in {
            "work_email": work_email, "first_name": first_name, "last_name": last_name,
            "job_title": job_title, "company_domain": company_domain, "linkedin_url": linkedin_url,
            "direct_phone": direct_phone, "mobile_phone": mobile_phone,
            "seniority_level": seniority_level, "city": city, "state": state, "country": country,
            "list_id": list_id,
        }.items() if v is not None}
        return await safe_call_typed(
            client.post("/contacts", body),
            ActionResult.from_envelope,
            context="Contact creation",
        )

    # ------------------------------------------------------------------
    # Unified list tools - g8_create_list / g8_add_to_list
    # ------------------------------------------------------------------
    #
    # Both tools accept one of four mutually-exclusive source modes:
    #   - (no source)      -> empty list (create_list only; free)
    #   - contact_ids=[..] -> CRM contacts that already have IDs (free)
    #   - rows=[{..}]      -> explicit records to import (free, no enrichment)
    #   - filters=[{..}]   -> search + save against open data (credits)
    #
    # The original `g8_create_list(title=, type=)` empty-list call and
    # `g8_add_to_list(list_id=, contact_ids=)` id-add call still work
    # unchanged - the new source modes are additive.
    #
    # Cost prompt: any source that creates real CRM contacts (rows, filters)
    # supports dry_run=True returning a ConfirmationPreview - the wave-3
    # destructive-tool pattern, applied per-source-mode.

    # Subset of ContactCreateRequest fields accepted by POST /api/v1/contacts.
    # Rows passed by the model are filtered against this allowlist so unknown
    # fields (e.g. company_name, confidence_score from SearchContactItem) are
    # silently dropped rather than rejected by the backend.
    _CONTACT_ROW_FIELDS = (
        "first_name", "last_name", "work_email", "personal_emails",
        "direct_phone", "mobile_phone", "job_title", "job_department",
        "seniority_level", "linkedin_url", "city", "state", "country",
        "company_domain",
    )

    def _row_for_create(row: dict, list_id: int) -> dict:
        """Project a free-form row onto the POST /contacts request shape.

        Unknown keys are dropped. `list_id` is always injected since
        ContactCreateRequest requires it on the backend.
        """
        body: dict[str, Any] = {"list_id": list_id}
        for key in _CONTACT_ROW_FIELDS:
            value = row.get(key)
            if value is not None and value != "":
                body[key] = value
        return body

    def _count_sources(
        contact_ids: list[int] | None,
        rows: list[dict] | None,
        filters: list[dict] | None,
    ) -> int:
        """Count how many source modes were provided. Used to enforce
        at-most-one (create_list) or exactly-one (add_to_list) semantics."""
        present = 0
        if contact_ids:
            present += 1
        if rows:
            present += 1
        if filters:
            present += 1
        return present

    async def _import_rows_to_list(list_id: int, rows: list[dict]) -> ActionResult:
        """POST /contacts in sequence for each row, attaching to list_id.

        Aggregates successes and failures into a single ActionResult so the
        caller sees one structured response. Per-row errors are non-fatal:
        we keep going and surface counts at the end.
        """
        imported = 0
        failed = 0
        errors: list[dict[str, Any]] = []
        for idx, row in enumerate(rows):
            body = _row_for_create(row, list_id)
            try:
                await client.post("/contacts", body)
                imported += 1
            except Exception as exc:  # noqa: BLE001 - aggregate any per-row failure
                failed += 1
                errors.append({"index": idx, "error": str(exc)})
        return ActionResult.model_validate({
            "status": "ok" if failed == 0 else "partial",
            "id": list_id,
            "message": f"Imported {imported} of {len(rows)} rows",
            "imported": imported,
            "failed": failed,
            "list_id": list_id,
            **({"errors": errors} if errors else {}),
        })

    @server.tool(
        annotations=_WRITE,
        # Drives ui://confirmations/create-list when dry_run=True. The widget
        # renders all four source modes off the ConfirmationPreview fields.
        meta=ui_tool_meta("ui://confirmations/create-list"),
    )
    async def g8_create_list(
        title: str,
        type: str = "contacts",
        contact_ids: list[int] | None = None,
        rows: list[dict] | None = None,
        filters: list[dict] | None = None,
        max_results: int = 100,
        dry_run: bool = False,
    ) -> ConfirmationPreview | ActionResult | str:
        """Create a contact or company list, optionally pre-populated.

        Source modes (pass at most one; default = empty list):
          - contact_ids: list[int]  - add existing CRM contacts to the new list (free)
          - rows: list[dict]        - import explicit records (free; no enrichment).
                                      Each row may contain any of: first_name,
                                      last_name, work_email, job_title, company_domain,
                                      seniority_level, linkedin_url, city, state,
                                      country, personal_emails, direct_phone,
                                      mobile_phone, job_department.
          - filters: list[dict]     - search + save from open data (CHARGES CREDITS).
                                      Same shape as g8_find_contacts; max_results
                                      caps the spend.

        When `filters` or `rows` is supplied, call with `dry_run=True` first to
        get a ConfirmationPreview. Re-call with `dry_run=False` to execute.
        For `contact_ids` and the empty-list mode the cost is zero, but
        `dry_run=True` is still honored if the caller wants a preview.

        Returns the new list's id on success. Backward compatible: with no
        source params this is identical to the original empty-list creator.

        Args:
            title: List name (e.g. "Enterprise Q2 Targets")
            type: List type - "contacts" or "companies" (default: contacts)
            contact_ids: Optional CRM contact ids to attach to the new list.
            rows: Optional list of record dicts to import into the list.
            filters: Optional g8_find_contacts-style filters to search and save.
            max_results: Cap on records saved when `filters` is used (default 100).
            dry_run: When True, return a ConfirmationPreview instead of executing.
        """
        # Validate mutual exclusion. Multiple sources is almost always a model
        # mistake (e.g. trying to merge curated rows with a filter expression)
        # and would be ambiguous without a documented merge order. Reject loudly.
        sources_present = _count_sources(contact_ids, rows, filters)
        if sources_present > 1:
            return (
                "Error: g8_create_list accepts at most one of "
                "`contact_ids`, `rows`, `filters` per call. Got "
                f"{sources_present}. Split into multiple calls or pick one."
            )

        # ----- filters mode: search + save against open data (charges credits)
        if filters:
            if dry_run:
                return ConfirmationPreview(
                    action_label="Save contacts to new list",
                    summary=(
                        f"Search open data and save up to {max_results} matching "
                        f"contacts to a new list \"{title}\"."
                    ),
                    details=[
                        ConfirmationDetail(label="List name", value=title),
                        ConfirmationDetail(label="Source", value="open data search"),
                        ConfirmationDetail(label="Filter count", value=str(len(filters))),
                        ConfirmationDetail(label="Max contacts", value=str(max_results)),
                    ],
                    warning=(
                        f"This will consume up to {max_results} credits and create "
                        "real contacts in your CRM."
                    ),
                    cost_label=f"Up to {max_results} credits",
                    confirm_tool="g8_create_list",
                    confirm_args={
                        "title": title,
                        "type": type,
                        "filters": filters,
                        "max_results": max_results,
                        "dry_run": False,
                    },
                    confirm_label=f"Save up to {max_results} contacts",
                    cancel_label="Cancel",
                )
            # Seniority abbreviations are auto-expanded to canonical
            # strings (see _expand_seniority_synonyms). The dry-run preview
            # above keeps the user's original filters so the confirmation
            # widget shows exactly what they typed; expansion happens here
            # right before the network call.
            body = {
                "filters": _expand_seniority_synonyms(filters),
                "list_title": title,
                "max_results": max_results,
            }
            return await safe_call_typed(
                client.post("/search/contacts/save", body),
                ActionResult.from_envelope,
                context="List building (filters)",
            )

        # ----- rows mode: explicit records, imported one-per-call (no enrichment credits)
        if rows:
            if dry_run:
                return ConfirmationPreview(
                    action_label="Import rows into new list",
                    summary=(
                        f"Create list \"{title}\" and import {len(rows)} explicit "
                        "record(s) into it. Each row becomes a CRM contact."
                    ),
                    details=[
                        ConfirmationDetail(label="List name", value=title),
                        ConfirmationDetail(label="Source", value="explicit rows"),
                        ConfirmationDetail(label="Row count", value=str(len(rows))),
                    ],
                    warning=(
                        "This creates real contacts in your CRM. No enrichment "
                        "credits are charged when rows already carry their data."
                    ),
                    cost_label="No enrichment credits",
                    confirm_tool="g8_create_list",
                    confirm_args={
                        "title": title,
                        "type": type,
                        "rows": rows,
                        "dry_run": False,
                    },
                    confirm_label=f"Import {len(rows)} row(s)",
                    cancel_label="Cancel",
                )
            # 1) create the list, 2) import rows attached to it.
            create_resp = await safe_call_typed(
                client.post("/lists", {"title": title, "type": type}),
                ActionResult.from_envelope,
                context="List creation (rows mode)",
            )
            if isinstance(create_resp, str):
                return create_resp  # error from list creation; abort before importing.
            list_id_val = create_resp.id
            if not isinstance(list_id_val, int):
                # Defensive: backend should always return an int id, but if it
                # ever returns a string or None we cannot import.
                return (
                    "Error: list creation succeeded but no integer list_id was "
                    f"returned (got {list_id_val!r}). Cannot import rows."
                )
            return await _import_rows_to_list(list_id_val, rows)

        # ----- contact_ids mode: free CRM-only add
        if contact_ids:
            if dry_run:
                return ConfirmationPreview(
                    action_label="Create list with existing contacts",
                    summary=(
                        f"Create list \"{title}\" and attach {len(contact_ids)} "
                        "existing CRM contact(s) to it."
                    ),
                    details=[
                        ConfirmationDetail(label="List name", value=title),
                        ConfirmationDetail(label="Source", value="CRM contact ids"),
                        ConfirmationDetail(label="Contact count", value=str(len(contact_ids))),
                    ],
                    warning=None,
                    cost_label="Free",
                    confirm_tool="g8_create_list",
                    confirm_args={
                        "title": title,
                        "type": type,
                        "contact_ids": contact_ids,
                        "dry_run": False,
                    },
                    confirm_label=f"Add {len(contact_ids)} contact(s)",
                    cancel_label="Cancel",
                )
            # 1) create list, 2) attach contact ids in one batch call.
            create_resp = await safe_call_typed(
                client.post("/lists", {"title": title, "type": type}),
                ActionResult.from_envelope,
                context="List creation (contact_ids mode)",
            )
            if isinstance(create_resp, str):
                return create_resp
            list_id_val = create_resp.id
            if not isinstance(list_id_val, int):
                return (
                    "Error: list creation succeeded but no integer list_id was "
                    f"returned (got {list_id_val!r}). Cannot attach contacts."
                )
            add_resp = await safe_call_typed(
                client.post(
                    f"/lists/{list_id_val}/contacts", {"contact_ids": contact_ids}
                ),
                ActionResult.from_envelope,
                context="List add (contact_ids mode)",
            )
            # Surface the list id even though the attach response doesn't echo it.
            if isinstance(add_resp, ActionResult):
                return ActionResult.model_validate({
                    "status": add_resp.status or "ok",
                    "id": list_id_val,
                    "message": f"Created list {list_id_val} and attached {len(contact_ids)} contact(s)",
                    "list_id": list_id_val,
                    "attached": len(contact_ids),
                })
            return add_resp

        # ----- default (no source): empty list
        if dry_run:
            return ConfirmationPreview(
                action_label="Create empty list",
                summary=f"Create empty list \"{title}\" (no contacts attached).",
                details=[
                    ConfirmationDetail(label="List name", value=title),
                    ConfirmationDetail(label="Source", value="(empty)"),
                ],
                warning=None,
                cost_label="Free",
                confirm_tool="g8_create_list",
                confirm_args={
                    "title": title,
                    "type": type,
                    "dry_run": False,
                },
                confirm_label="Create list",
                cancel_label="Cancel",
            )
        # Normalize the empty-mode ack into the same envelope shape the other
        # three source modes return: {status, id, list_id, total, message}.
        # Bug 2 fix: previously this branch passed the raw backend response
        # through (which carried `status: "completed"` and only `id`, no
        # `list_id`), so callers saw a different shape than they got from
        # the contact_ids / rows / filters modes. Backward compatible
        # because the new envelope is a SUPERSET - `id` is still present;
        # we just add `list_id`, `total`, and standardize `status` to "ok".
        create_resp = await safe_call_typed(
            client.post("/lists", {"title": title, "type": type}),
            ActionResult.from_envelope,
            context="List creation",
        )
        if isinstance(create_resp, str):
            return create_resp
        list_id_val = create_resp.id
        extras = create_resp.model_dump(exclude_none=True)
        extras.pop("status", None)
        extras.pop("id", None)
        extras.pop("message", None)
        return ActionResult.model_validate({
            "status": "ok",
            "id": list_id_val,
            "list_id": list_id_val,
            "total": 0,
            "message": f"Created empty list {list_id_val}.",
            **extras,
        })

    @server.tool(
        annotations=_WRITE,
        # Drives ui://confirmations/add-to-list when dry_run=True.
        meta=ui_tool_meta("ui://confirmations/add-to-list"),
    )
    async def g8_add_to_list(
        list_id: int,
        contact_ids: list[int] | None = None,
        rows: list[dict] | None = None,
        dry_run: bool = False,
    ) -> ConfirmationPreview | ActionResult | str:
        """Add contacts to an existing list, by id or by explicit records.

        Source modes (exactly one required):
          - contact_ids: list[int]  - attach existing CRM contacts (free).
          - rows: list[dict]        - import explicit records into the list
                                      (free; no enrichment credits). Accepted
                                      fields per row: first_name, last_name,
                                      work_email, job_title, company_domain,
                                      seniority_level, linkedin_url, city, state,
                                      country, personal_emails, direct_phone,
                                      mobile_phone, job_department.

        Searching by filters and merging into an existing list is not supported
        here in v1 - use g8_create_list(filters=...) to create a new list
        instead, or call g8_find_contacts and forward the result as `rows`.

        When `rows` is supplied, call with `dry_run=True` first to get a
        ConfirmationPreview, then re-call with `dry_run=False` to execute.

        Args:
            list_id: Target list id (from g8_create_list or g8_get_lists).
            contact_ids: Optional CRM contact ids to attach to the list.
            rows: Optional list of record dicts to import into the list.
            dry_run: When True, return a ConfirmationPreview instead of executing.
        """
        sources_present = _count_sources(contact_ids, rows, None)
        if sources_present == 0:
            return (
                "Error: g8_add_to_list requires one of `contact_ids` or `rows`. "
                "To search-and-add from open data, use g8_create_list(filters=..., "
                "title=...) to create a new list instead."
            )
        if sources_present > 1:
            return (
                "Error: g8_add_to_list accepts at most one of `contact_ids` or "
                "`rows` per call. Split into multiple calls or pick one."
            )

        # ----- rows mode
        if rows:
            if dry_run:
                return ConfirmationPreview(
                    action_label="Import rows into list",
                    summary=(
                        f"Import {len(rows)} explicit record(s) into list "
                        f"{list_id}. Each row becomes a CRM contact."
                    ),
                    details=[
                        ConfirmationDetail(label="List id", value=str(list_id)),
                        ConfirmationDetail(label="Source", value="explicit rows"),
                        ConfirmationDetail(label="Row count", value=str(len(rows))),
                    ],
                    warning=(
                        "This creates real contacts in your CRM. No enrichment "
                        "credits are charged when rows already carry their data."
                    ),
                    cost_label="No enrichment credits",
                    confirm_tool="g8_add_to_list",
                    confirm_args={
                        "list_id": list_id,
                        "rows": rows,
                        "dry_run": False,
                    },
                    confirm_label=f"Import {len(rows)} row(s)",
                    cancel_label="Cancel",
                )
            return await _import_rows_to_list(list_id, rows)

        # ----- contact_ids mode (original behavior preserved)
        if dry_run:
            return ConfirmationPreview(
                action_label="Add contacts to list",
                summary=(
                    f"Attach {len(contact_ids)} existing CRM contact(s) to "
                    f"list {list_id}."
                ),
                details=[
                    ConfirmationDetail(label="List id", value=str(list_id)),
                    ConfirmationDetail(label="Source", value="CRM contact ids"),
                    ConfirmationDetail(label="Contact count", value=str(len(contact_ids))),
                ],
                warning=None,
                cost_label="Free",
                confirm_tool="g8_add_to_list",
                confirm_args={
                    "list_id": list_id,
                    "contact_ids": contact_ids,
                    "dry_run": False,
                },
                confirm_label=f"Add {len(contact_ids)} contact(s)",
                cancel_label="Cancel",
            )
        return await safe_call_typed(
            client.post(f"/lists/{list_id}/contacts", {"contact_ids": contact_ids}),
            ActionResult.from_envelope,
            context="List",
        )

    @server.tool(
        annotations=_READ_ONLY,
        # Drives ui://lists/list - card grid grouped by list type.
        meta=ui_tool_meta("ui://lists/list"),
    )
    async def g8_get_lists(
        page: int = 1,
        limit: int = 50,
    ) -> ListsResult | str:
        """List contact and company lists in your CRM.

        Args:
            page: Page number (default 1)
            limit: Items per page (default 50)
        """
        return await safe_call_typed(
            client.get("/lists", {"page": page, "limit": limit}),
            ListsResult.from_envelope,
            context="List catalog",
        )

    # ------------------------------------------------------------------
    # Custom fields / columns - read + create + delete on contacts/companies
    # ------------------------------------------------------------------
    #
    # Backed by /fields (contacts) and /fields/companies (companies). When
    # `list_id` is set, the field is scoped to that list; otherwise it is a
    # global column visible across every list of that entity in the org.
    # The backend stores both base columns (no row in `dynamic_columns`) and
    # custom columns (one row per definition); the response surfaces both
    # under a unified shape.

    @server.tool(annotations=_READ_ONLY)
    async def g8_list_fields(
        entity: str = "contacts",
        list_id: int | None = None,
    ) -> FieldsResult | str:
        """List the field definitions (base + custom columns) for contacts or companies.

        Use this to see which custom columns already exist before calling
        `g8_create_field`, or to discover the column `name` to reference in
        downstream APIs.

        Args:
            entity: Target entity - "contacts" or "companies" (default: contacts)
            list_id: Optional list ID. When provided, includes custom columns
                scoped to that list in addition to global columns.
        """
        path = "/fields/companies" if entity == "companies" else "/fields"
        params = {"list_id": list_id} if list_id is not None else None
        envelope = await safe_call_typed(
            client.get(path, params),
            FieldsResult.from_envelope,
            context="Field catalog",
        )
        # On error safe_call_typed returns the error string - propagate as-is.
        if isinstance(envelope, FieldsResult):
            envelope.entity = entity if entity in ("contacts", "companies") else "contacts"
            envelope.list_id = list_id
        return envelope

    @server.tool(annotations=_WRITE)
    async def g8_create_field(
        title: str,
        entity: str = "contacts",
        list_id: int | None = None,
        data_type: str = "text",
    ) -> ActionResult | str:
        """Create a custom column on contacts or companies.

        When `list_id` is set, the column is list-scoped (only visible on that
        list). When omitted, the column is global across every list of that
        entity in the org.

        Currently the only supported `data_type` is "text". Additional types
        (numeric, date, boolean, select) may be added in the future - the
        backend rejects unknown values with a 400.

        Args:
            title: Column title shown in the UI (e.g. "Job Level")
            entity: Target entity - "contacts" or "companies" (default: contacts)
            list_id: Optional list ID to scope the column to a single list
            data_type: Column data type (default: "text")
        """
        body: dict[str, Any] = {
            "title": title,
            "data_type": data_type,
            "entity": entity,
        }
        if list_id is not None:
            body["list_id"] = list_id
        return await safe_call_typed(
            client.post("/fields", body),
            ActionResult.from_envelope,
            context="Field creation",
        )

    @server.tool(annotations=_WRITE)
    async def g8_set_field_value(
        column_id: int,
        record_id: int,
        value: str | None = None,
        entity: str = "contacts",
    ) -> ActionResult | str:
        """Set a custom column value on a single contact or company row.

        Use `g8_list_fields` first to find the `column_id` for the column you
        want to write into. The `record_id` is the contact_id (when
        entity="contacts") or company_id (when entity="companies") of the row
        to update.

        Pass `value=None` (or omit it) to clear the column for that row.

        This is a write, not a destructive op: setting the same value twice
        is idempotent and reversible by simply writing the previous value back.

        Args:
            column_id: Column ID from `g8_list_fields` or `g8_create_field`
            record_id: Contact ID or company ID to update
            value: Value to write into the custom column. Omit/None to clear.
            entity: Target entity - "contacts" or "companies" (default: contacts)
        """
        body: dict[str, Any] = {"record_id": record_id, "entity": entity}
        # Mirror the `list_id`-omission pattern used in g8_create_field:
        # only include `value` in the body when explicitly set, so a missing
        # key cleanly maps to "clear" semantics on the backend.
        if value is not None:
            body["value"] = value
        return await safe_call_typed(
            client.patch(f"/fields/{column_id}/values", body),
            ActionResult.from_envelope,
            context="Field value set",
        )

    @server.tool(annotations=_DESTRUCTIVE)
    async def g8_delete_field(
        column_id: int,
        entity: str = "contacts",
        list_id: int | None = None,
    ) -> ActionResult | str:
        """Soft-delete a custom column from contacts or companies.

        Always org-scoped. Pass `list_id` to additionally require that the
        column belong to a specific list - that is the safer default for
        list-scoped agents because the org may have many custom columns
        across different lists with similar names.

        Args:
            column_id: Column ID to delete (from g8_list_fields or g8_create_field)
            entity: Target entity - "contacts" or "companies" (default: contacts)
            list_id: Optional list scope guard. If set, returns 404 unless the
                column belongs to this list - prevents cross-list deletion.
        """
        params: dict[str, Any] = {"entity": entity}
        if list_id is not None:
            params["list_id"] = list_id
        return await safe_call_typed(
            client.delete(f"/fields/{column_id}", params),
            ActionResult.from_envelope,
            context="Field deletion",
        )

    @server.tool(
        annotations=_READ_ONLY,
        meta=ui_tool_meta("ui://deals/list"),
    )
    async def g8_get_deals(
        page: int = 1,
        limit: int = 50,
        stage_id: str | None = None,
        pipeline_id: str | None = None,
        search: str | None = None,
    ) -> DealsResult | str:
        """List deals in your CRM with optional stage, pipeline, or text filters."""
        return await safe_call_typed(
            client.get(
                "/deals",
                {
                    "page": page,
                    "limit": limit,
                    "stage_id": stage_id,
                    "pipeline_id": pipeline_id,
                    "search": search,
                },
            ),
            DealsResult.from_envelope,
            context="Deal list",
        )

    @server.tool(
        annotations=_READ_ONLY,
        meta=ui_tool_meta("ui://deals/detail"),
    )
    async def g8_get_deal(deal_id: str) -> ResourceDetail | str:
        """Get details for a single CRM deal."""
        return await safe_call_typed(
            client.get(f"/deals/{deal_id}"),
            ResourceDetail.from_envelope,
            context="Deal",
        )

    @server.tool(annotations=_READ_ONLY)
    async def g8_get_pipeline() -> PipelinesResult | str:
        """List deal pipelines and stages."""
        return await safe_call_typed(
            client.get("/deals/pipelines"),
            PipelinesResult.from_envelope,
            context="Deal pipeline",
        )

    @server.tool(
        annotations=_READ_ONLY,
        meta=ui_tool_meta("ui://tasks/list"),
    )
    async def g8_get_tasks(
        status: str | None = None,
        priority: int | None = None,
        assignee_id: str | None = None,
        search: str | None = None,
    ) -> TasksResult | str:
        """List tasks for the current organization with optional filters."""
        return await safe_call_typed(
            client.get(
                "/tasks",
                {
                    "status": status,
                    "priority": priority,
                    "assignee_id": assignee_id,
                    "search": search,
                },
            ),
            TasksResult.from_envelope,
            context="Task list",
        )

    @server.tool(annotations=_WRITE)
    async def g8_create_task(
        contact_id: int,
        title: str,
        description: str | None = None,
        due_date: str | None = None,
        assignee_id: str | None = None,
        priority: int | None = None,
    ) -> ActionResult | str:
        """Create a task linked to a CRM contact."""
        body = {
            key: value
            for key, value in {
                "title": title,
                "description": description,
                "due_date": due_date,
                "assignee_id": assignee_id,
                "priority": priority,
            }.items()
            if value is not None
        }
        return await safe_call_typed(
            client.post(f"/contacts/{contact_id}/tasks", body),
            ActionResult.from_envelope,
            context="Task creation",
        )

    @server.tool(annotations=_WRITE)
    async def g8_create_note(contact_id: int, content: str) -> ActionResult | str:
        """Add a note to a CRM contact."""
        return await safe_call_typed(
            client.post(f"/contacts/{contact_id}/notes", {"content": content}),
            ActionResult.from_envelope,
            context="Note creation",
        )

    @server.tool(
        annotations=_READ_ONLY,
        meta=ui_tool_meta("ui://activities/list"),
    )
    async def g8_get_activities(
        limit: int = 50,
        activity_type: str | None = None,
        contact_id: str | None = None,
        company_id: str | None = None,
        deal_id: str | None = None,
    ) -> ActivitiesResult | str:
        """List recent CRM activities for the current organization."""
        return await safe_call_typed(
            client.get(
                "/activities",
                {
                    "limit": limit,
                    "activity_type": activity_type,
                    "contact_id": contact_id,
                    "company_id": company_id,
                    "deal_id": deal_id,
                },
            ),
            ActivitiesResult.from_envelope,
            context="Activity list",
        )

    @server.tool(annotations=_READ_ONLY)
    async def g8_get_activity_summary(
        days: int = 7,
        activity_type: str | None = None,
        contact_id: str | None = None,
        company_id: str | None = None,
        deal_id: str | None = None,
    ) -> dict:
        """Summarize recent CRM activity for the current organization.

        Aggregates the most recent activities into a rollup: total count, counts by
        activity_type, counts by outcome, daily counts for the window, top owners by
        activity count, and total call/meeting duration. Useful for "how was this
        week" or "which reps are most active" questions without paging through the
        raw feed.

        Scope: reads the current org's activities (org is resolved from the API key).

        Limitations: pulls up to 200 most recent activities from the activities
        endpoint (the list endpoint's max page size), then filters client-side by
        the day window. For orgs with more than 200 activities in the window, the
        summary covers only the newest 200 - the `truncated` flag in the response
        will be true, and you should call `g8_get_activities` directly for a full
        feed with narrower filters.

        Args:
            days: Size of the rollup window in days ending now (default 7).
            activity_type: Optional activity type filter (e.g. "call", "email",
                "meeting"). Passed to the server-side filter.
            contact_id: Optional contact filter.
            company_id: Optional company filter.
            deal_id: Optional deal filter.
        """
        from datetime import datetime, timedelta, timezone

        envelope = await client.get(
            "/activities",
            {
                "limit": 200,
                "activity_type": activity_type,
                "contact_id": contact_id,
                "company_id": company_id,
                "deal_id": deal_id,
            },
        )
        raw = envelope.get("data", []) if isinstance(envelope, dict) else []
        if not isinstance(raw, list):
            raw = []

        window_start = datetime.now(timezone.utc) - timedelta(days=max(days, 1))

        def _parse_ts(value: Any) -> datetime | None:
            if not value:
                return None
            text = str(value).strip()
            # Postgres renders timestamps as "2026-04-22 13:45:00+00:00" - normalise
            # to something fromisoformat can parse across Python 3.10+.
            text = text.replace(" ", "T", 1)
            if text.endswith("Z"):
                text = text[:-1] + "+00:00"
            try:
                dt = datetime.fromisoformat(text)
            except ValueError:
                return None
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt

        in_window: list[dict[str, Any]] = []
        for row in raw:
            if not isinstance(row, dict):
                continue
            ts = _parse_ts(row.get("activity_date") or row.get("occurred_at"))
            if ts is None or ts < window_start:
                continue
            in_window.append(row)

        by_type: dict[str, int] = {}
        by_outcome: dict[str, int] = {}
        by_day: dict[str, int] = {}
        by_owner: dict[str, dict[str, Any]] = {}
        total_duration = 0

        for row in in_window:
            activity_type_val = row.get("activity_type") or "unknown"
            outcome_val = row.get("outcome") or "unknown"
            by_type[activity_type_val] = by_type.get(activity_type_val, 0) + 1
            by_outcome[outcome_val] = by_outcome.get(outcome_val, 0) + 1

            ts = _parse_ts(row.get("activity_date") or row.get("occurred_at"))
            if ts is not None:
                day_key = ts.date().isoformat()
                by_day[day_key] = by_day.get(day_key, 0) + 1

            duration = row.get("duration_minutes")
            if isinstance(duration, (int, float)):
                total_duration += int(duration)

            owner_id = row.get("owner_id") or row.get("user_id")
            if owner_id:
                entry = by_owner.setdefault(
                    str(owner_id),
                    {"user_id": str(owner_id), "name": row.get("owner_name"), "count": 0},
                )
                entry["count"] += 1
                if not entry.get("name") and row.get("owner_name"):
                    entry["name"] = row.get("owner_name")

        # Buckets: `days` contiguous calendar days ending today (inclusive), so a
        # days=7 query returns today plus the previous 6 days. Anchoring to
        # `today` rather than `window_start.date()` avoids an off-by-one where
        # today's activities had no bucket to land in.
        today = datetime.now(timezone.utc).date()
        activities_by_day = [
            {
                "date": (today - timedelta(days=max(days, 1) - 1 - i)).isoformat(),
                "count": 0,
            }
            for i in range(max(days, 1))
        ]
        for entry in activities_by_day:
            if entry["date"] in by_day:
                entry["count"] = by_day[entry["date"]]

        top_owners = sorted(by_owner.values(), key=lambda x: x["count"], reverse=True)[:10]

        return {
            "period_days": max(days, 1),
            "window_start": window_start.isoformat(),
            "total_activities": len(in_window),
            "by_type": by_type,
            "by_outcome": by_outcome,
            "total_duration_minutes": total_duration,
            "activities_by_day": activities_by_day,
            "top_owners": top_owners,
            "truncated": len(raw) >= 200,
            "note": (
                "Summary covers the 200 most recent activities fetched from the "
                "list endpoint. Use g8_get_activities with filters for the full feed "
                "if 'truncated' is true."
            ),
        }

    # ------------------------------------------------------------------
    # Contact deep-reads - focused lookups for a single contact or
    # the company a contact belongs to. All thin wrappers around
    # existing /api/v1 routes; safer + more discoverable for agents
    # than asking them to compose g8_search_contacts + g8_get_deals.
    # ------------------------------------------------------------------

    @server.tool(
        annotations=_READ_ONLY,
        meta=ui_tool_meta("ui://contacts/detail"),
    )
    async def g8_get_contact_detail(contact_id: int) -> ResourceDetail | str:
        """Get the full detail record for a single CRM contact.

        Returns every backend field the org has on this contact (emails, phones,
        job title, company linkage, social URLs, location, custom attributes).
        Use after g8_search_contacts has narrowed down a contact_id to read
        the full record.

        Args:
            contact_id: Integer contact ID (from g8_search_contacts or CRM).
        """
        return await safe_call_typed(
            client.get(f"/contacts/{contact_id}"),
            ResourceDetail.from_envelope,
            context="Contact detail",
        )

    @server.tool(annotations=_READ_ONLY)
    async def g8_get_contact_activity(
        contact_id: int,
        limit: int = 50,
        activity_type: str | None = None,
    ) -> dict:
        """List recent activities for a single contact.

        Returns the activity timeline (calls, emails, meetings, notes)
        attributed to this contact, newest first. Useful for "what have we
        done with this person" questions.

        Implementation note: the backend `/activities?contact_id=X` server-side
        filter is currently broken (returns 500), so this tool pulls up to 200
        most recent org-wide activities and filters client-side. For low-to-
        medium-activity orgs this returns everything; for very active orgs the
        contact's older activities may fall outside the 200-row scan window.
        The response sets `scan_truncated: true` when the upstream hit its cap.

        Args:
            contact_id: Integer contact ID.
            limit: Max activities to return after filtering (default 50, max 200).
            activity_type: Optional type filter (e.g. "call", "email", "meeting").
        """
        # Pull the org-wide recent feed (no server-side contact filter).
        envelope = await client.get("/activities", {"limit": 200})
        raw = envelope.get("data", []) if isinstance(envelope, dict) else []
        if not isinstance(raw, list):
            raw = []

        target = str(contact_id)
        filtered: list[dict[str, Any]] = []
        for row in raw:
            if not isinstance(row, dict):
                continue
            # Match on whatever the backend emits for the contact linkage;
            # some endpoints use contact_id (flat), others nest inside contact.
            row_cid = row.get("contact_id")
            if row_cid is None and isinstance(row.get("contact"), dict):
                row_cid = row["contact"].get("id")
            if row_cid is None or str(row_cid) != target:
                continue
            if activity_type and row.get("activity_type") != activity_type:
                continue
            filtered.append(row)
            if len(filtered) >= min(max(limit, 1), 200):
                break

        return {
            "activities": filtered,
            "total": len(filtered),
            "scan_truncated": len(raw) >= 200,
            "note": (
                "Client-side filter over the 200 most recent org activities. "
                "If scan_truncated is true and you didn't find what you expected, "
                "the contact's older activities are out of window."
            ),
        }

    @server.tool(annotations=_READ_ONLY)
    async def g8_get_contact_deals(contact_id: int) -> dict:
        """List all deals associated with a contact.

        Returns every deal where this contact is the primary or associated
        contact, with stage, value, currency, pipeline, and role. Useful for
        "what's this person working on with us" questions.

        Args:
            contact_id: Integer contact ID.
        """
        envelope = await client.get(f"/contacts/{contact_id}/deals")
        # The /contacts/{id}/deals endpoint returns ContactDealResponse
        # (deal_id / name / stage / value / currency / role / pipeline_id /
        # close_date / owner_id / created_at) - shape differs from DealItem so
        # we surface the raw list unchanged and let the agent read the field
        # names directly.
        data = envelope.get("data", []) if isinstance(envelope, dict) else []
        if not isinstance(data, list):
            data = []
        return {"deals": data, "total": len(data)}

    @server.tool(annotations=_READ_ONLY)
    async def g8_get_contact_company(contact_id: int) -> ResourceDetail | str:
        """Get the company record attached to a contact.

        Single-call wrapper: `/contacts/{id}` already embeds the contact's
        company as a nested object (id, name, domain, industry, location,
        linkedin_url, logo_url), so we extract and return that directly.
        Returns an empty ResourceDetail if the contact has no company linkage.

        Args:
            contact_id: Integer contact ID.
        """
        contact_env = await client.get(f"/contacts/{contact_id}")
        inner = (
            contact_env.get("data", contact_env)
            if isinstance(contact_env, dict)
            else {}
        )
        company = (
            inner.get("company") if isinstance(inner, dict) else None
        )
        if not isinstance(company, dict) or not company.get("id"):
            return ResourceDetail()
        return ResourceDetail.model_validate(company)

    @server.tool(
        annotations=_READ_ONLY,
        # Drill-in target from ui://companies/list - reuses the contacts
        # table layout via the sibling "company-contacts" view.
        meta=ui_tool_meta("ui://companies/list"),
    )
    async def g8_get_company_contacts(
        company_id: int,
        limit: int = 100,
        offset: int = 0,
    ) -> ContactsResult | str:
        """List the contacts attached to a company.

        Returns the people your org has recorded at a given company. Useful
        for multi-threading prep ("who else do we know at Acme?") or for
        building account-based outreach lists.

        Args:
            company_id: Integer company ID.
            limit: Items per page (default 100, max 200).
            offset: Pagination offset (default 0).
        """
        return await safe_call_typed(
            client.get(
                f"/companies/{company_id}/contacts",
                {"limit": limit, "offset": offset},
            ),
            ContactsResult.from_envelope,
            context="Company contacts",
        )

    # ------------------------------------------------------------------
    # Enrichment - enhance existing CRM contacts with external data
    # ------------------------------------------------------------------

    @server.tool(
        annotations=_DESTRUCTIVE,
        # Drives ui://confirmations/enrich-contacts when dry_run=True.
        meta=ui_tool_meta("ui://confirmations/enrich-contacts"),
    )
    async def g8_enrich_contacts(
        contact_ids: list[int],
        list_id: int,
        dry_run: bool = False,
    ) -> ConfirmationPreview | ActionResult | str:
        """Enrich existing CRM contacts with third-party data.

        Fills in missing fields (verified email, phone, job title, company info)
        using the list's saved waterfall pipeline. Credits charged per contact
        based on the pipeline's provider steps. Returns a job_id - enrichment
        runs asynchronously. Poll with g8_get_enrichment_job.

        How it picks a pipeline:
        1. Looks up saved pipelines on the list (GET /enrichment/waterfall/configs).
        2. If at least one exists, uses the most recent active one.
        3. If none exist, auto-creates a minimal graph8 lookup pipeline
           (fills name/email/company in one 0-credit internal call) and uses
           that. The auto-created pipeline stays on the list for reuse.

        Contacts must already exist in your CRM (use g8_search_contacts to find IDs).
        The list_id comes from g8_create_list, g8_get_lists, or
        g8_search_contacts (with list_id filter).

        IMPORTANT: This charges credits per contact. Confirm with user first.
        Recommended flow: call with `dry_run=True` to render a confirmation
        widget, then call again with `dry_run=False` after the user confirms.

        Args:
            contact_ids: List of CRM contact IDs to enrich
            list_id: ID of the list the contacts belong to (required for job tracking)
            dry_run: When True, return a confirmation preview instead of executing.
        """
        if dry_run:
            count = len(contact_ids or [])
            return ConfirmationPreview(
                action_label="Enrich contacts",
                summary=f"Enrich {count} contact(s) on list #{list_id} via the saved waterfall pipeline.",
                details=[
                    ConfirmationDetail(label="Contact count", value=str(count)),
                    ConfirmationDetail(label="List ID", value=str(list_id)),
                ],
                warning="Credits are charged per contact based on the list's enrichment pipeline.",
                cost_label=f"Up to {count} × pipeline cost",
                confirm_tool="g8_enrich_contacts",
                confirm_args={
                    "contact_ids": contact_ids,
                    "list_id": list_id,
                    "dry_run": False,
                },
                confirm_label=f"Enrich {count} contact(s)",
                cancel_label="Cancel",
            )
        # Step 1: discover existing pipelines for this list.
        try:
            configs_raw = await client.get(
                "/enrichment/waterfall/configs", {"list_id": list_id}
            )
        except Exception as e:
            from g8_mcp_server.client import G8ClientError, _format_error

            if isinstance(e, G8ClientError):
                return _format_error(e, context="Enrichment pipeline lookup")
            raise

        configs = _extract_waterfall_configs(configs_raw)
        column_id: str | None = None
        for cfg in configs:
            if cfg.get("is_active", True) and cfg.get("column_id"):
                column_id = cfg["column_id"]
                break

        # Step 2: no pipeline -> auto-create a minimal default one.
        if column_id is None:
            create_resp = await safe_call_typed(
                client.post(
                    "/enrichment/waterfall/configs",
                    {"list_id": list_id},
                ),
                ActionResult.from_envelope,
                context="Enrichment pipeline create",
            )
            if isinstance(create_resp, str):
                # Error string from safe_call_typed - surface directly.
                return create_resp
            extras = create_resp.model_dump()
            column_id = extras.get("column_id")
            if not column_id:
                return "Error: pipeline created but no column_id returned."

        # Step 3: run the pipeline.
        return await safe_call_typed(
            client.post(
                "/enrichment/waterfall/enrich",
                {
                    "column_id": column_id,
                    "list_id": list_id,
                    "record_ids": contact_ids,
                },
            ),
            ActionResult.from_envelope,
            context="Enrichment",
        )

    @server.tool(annotations=_READ_ONLY)
    async def g8_get_enrichment_job(job_id: str) -> ActionResult | str:
        """Poll the status of a waterfall enrichment job.

        Call this with the `job_id` returned by g8_enrich_contacts to check
        progress. The job typically completes within a minute for a handful
        of contacts; for larger batches expect several minutes.

        Note: if the job is still queued the response may only include the
        status field. Once the worker picks it up, progress counts populate.

        Args:
            job_id: job_id from the g8_enrich_contacts response
        """
        return await safe_call_typed(
            client.get(f"/enrichment/jobs/{job_id}"),
            ActionResult.from_envelope,
            context="Enrichment job status",
        )

    # ------------------------------------------------------------------
    # Sequence operations - outbound outreach
    # ------------------------------------------------------------------

    @server.tool(
        annotations=_READ_ONLY,
        # Drives ui://sequences/list.
        meta=ui_tool_meta("ui://sequences/list"),
    )
    async def g8_list_sequences(
        page: int = 1,
        limit: int = 50,
    ) -> SequencesResult | str:
        """List available outbound sequences in your organization.

        Returns sequence IDs, names, status, and step counts.
        Use this to find a sequence_id before calling g8_add_to_sequence.

        Args:
            page: Page number (default 1)
            limit: Items per page (default 50)
        """
        return await safe_call_typed(
            client.get("/sequences", {"page": page, "limit": limit}),
            SequencesResult.from_envelope,
            context="Sequence list",
        )

    @server.tool(
        annotations=_DESTRUCTIVE,
        # Drives ui://confirmations/add-to-sequence when dry_run=True.
        meta=ui_tool_meta("ui://confirmations/add-to-sequence"),
    )
    async def g8_add_to_sequence(
        sequence_id: str,
        contact_ids: list[int],
        list_id: int,
        dry_run: bool = False,
    ) -> ConfirmationPreview | ActionResult | str:
        """Add contacts to an outbound sequence for automated outreach.

        IMPORTANT: This enrolls real contacts into an active sequence that will
        send emails/messages. Always confirm with the user before calling this
        tool. Recommended flow: call with `dry_run=True` first to render a
        confirmation widget, then again with `dry_run=False` after the user
        confirms.

        Use g8_list_sequences to find available sequence IDs.
        Contacts must exist in your CRM with a contact_id. If they came from
        prospecting (g8_lookup_person / g8_find_contacts), create them first
        with g8_create_contact.

        Args:
            sequence_id: Sequence ID (from g8_list_sequences)
            contact_ids: List of contact IDs to enroll
            list_id: Contact list ID the contacts belong to
            dry_run: When True, return a confirmation preview instead of executing.
        """
        if dry_run:
            count = len(contact_ids or [])
            return ConfirmationPreview(
                action_label="Enroll contacts in sequence",
                summary=f"Enroll {count} contact(s) into sequence {sequence_id}.",
                details=[
                    ConfirmationDetail(label="Sequence ID", value=sequence_id),
                    ConfirmationDetail(label="Contact count", value=str(count)),
                    ConfirmationDetail(label="List ID", value=str(list_id)),
                ],
                warning="This sends real outbound messages (emails/SMS/etc.) on your behalf.",
                cost_label=None,
                confirm_tool="g8_add_to_sequence",
                confirm_args={
                    "sequence_id": sequence_id,
                    "contact_ids": contact_ids,
                    "list_id": list_id,
                    "dry_run": False,
                },
                confirm_label=f"Enroll {count} contact(s)",
                cancel_label="Cancel",
            )
        return await safe_call_typed(
            client.post(f"/sequences/{sequence_id}/contacts", {"contact_ids": contact_ids, "list_id": list_id}),
            ActionResult.from_envelope,
            context="Sequence",
        )

    # ------------------------------------------------------------------
    # Sequence Lifecycle tools
    # ------------------------------------------------------------------

    @server.tool(annotations=_DESTRUCTIVE)
    async def g8_create_sequence(
        name: str,
        user_email: str,
        description: str | None = None,
        finish_on_reply: bool = True,
        send_in_same_thread: bool = False,
        wait_for_new_contacts: bool = False,
        associated_list_id: int | None = None,
        steps: list[dict] | None = None,
        channels: list[dict] | None = None,
        campaign_id: str | None = None,
    ) -> ActionResult | str:
        """Create a new outbound sequence (drafted state).

        Confirm with the user before calling - this creates a real sequence.

        Args:
            name: Sequence name
            user_email: Owner email
            description: Optional description
            finish_on_reply: Stop contacting on reply (default true)
            send_in_same_thread: Send follow-ups in same email thread
            wait_for_new_contacts: Keep sequence open for late-arriving contacts
            associated_list_id: Contact list ID to attach to the sequence (use g8_get_lists to find)
            steps: Sequence steps. Each item is a dict with:
                - step_order (int, 1-based)
                - step_type (str): one of EMAIL, PHONE, SMS, WHATSAPP, HEYREACH, MANUAL_DIALER.
                  Note: LinkedIn outreach uses HEYREACH, not LINKEDIN. Case-insensitive.
                - input_type (str, default ON_DEMAND): one of ON_DEMAND, MANUAL_TEMPLATE, AI_GENERATED_TEMPLATE.
                  Case-insensitive (e.g. 'template' -> MANUAL_TEMPLATE).
                - time_interval (int, seconds delay after previous step)
                - step_data (dict): EMAIL needs {subject, body}; SMS/WHATSAPP need {message_body};
                  HEYREACH needs {linkedin_action_type, ...}; ON_DEMAND can use {instructions}.
            channels: Channels to attach. Each item is a dict with:
                - channel_id (int): mailbox/phone resource ID
                - channel_value (str): email address, phone number, etc.
                - channel_type (str): one of SMTP, GMAIL, INBOXKIT, PHONE, LINKEDIN, SMS, WHATSAPP.
            campaign_id: AI Studio campaign ID to link (optional)

        Example minimal email sequence:
            steps=[
                {"step_order": 1, "step_type": "EMAIL", "input_type": "MANUAL_TEMPLATE",
                 "time_interval": 0,
                 "step_data": {"subject": "Hi {{first_name}}", "body": "Quick intro..."}},
                {"step_order": 2, "step_type": "EMAIL", "input_type": "MANUAL_TEMPLATE",
                 "time_interval": 259200,
                 "step_data": {"subject": "Re: Hi {{first_name}}", "body": "Bumping this..."}},
            ]
        """
        body: dict = {
            "name": name,
            "user_email": user_email,
            "finish_on_reply": finish_on_reply,
            "send_in_same_thread": send_in_same_thread,
            "wait_for_new_contacts": wait_for_new_contacts,
        }
        if description:
            body["description"] = description
        if associated_list_id is not None:
            body["associated_list_id"] = associated_list_id
        if steps:
            body["steps"] = steps
        if channels:
            body["channels"] = channels
        if campaign_id:
            body["campaign_id"] = campaign_id
        return await safe_call_typed(
            client.post("/sequences", body),
            ActionResult.from_envelope,
            context="Create sequence",
        )

    @server.tool(
        annotations=_READ_ONLY,
        meta=ui_tool_meta("ui://sequences/detail"),
    )
    async def g8_get_sequence_preview(sequence_id: str) -> SequencePreview | str:
        """Preview a sequence with its steps and channels (read-only, no enrollment).

        Args:
            sequence_id: Sequence ID to preview
        """
        return await safe_call_typed(
            client.get(f"/sequences/{sequence_id}/preview"),
            SequencePreview.from_envelope,
            context="Sequence preview",
        )

    @server.tool(annotations=_DESTRUCTIVE)
    async def g8_update_sequence(
        sequence_id: str,
        name: str | None = None,
        description: str | None = None,
        is_shared: bool | None = None,
        finish_on_reply: bool | None = None,
        send_in_same_thread: bool | None = None,
        wait_for_new_contacts: bool | None = None,
    ) -> ActionResult | str:
        """Update sequence metadata. Cannot modify while in a transitional state.

        Args:
            sequence_id: Sequence ID to update
            name: New name
            description: New description
            is_shared: Whether sequence is shared
            finish_on_reply: Finish on reply
            send_in_same_thread: Send in same thread
            wait_for_new_contacts: Wait for new contacts
        """
        body = {k: v for k, v in {
            "name": name, "description": description, "is_shared": is_shared,
            "finish_on_reply": finish_on_reply, "send_in_same_thread": send_in_same_thread,
            "wait_for_new_contacts": wait_for_new_contacts,
        }.items() if v is not None}
        return await safe_call_typed(
            client.patch(f"/sequences/{sequence_id}", body),
            ActionResult.from_envelope,
            context="Update sequence",
        )

    @server.tool(annotations=_DESTRUCTIVE)
    async def g8_update_sequence_step(
        sequence_id: str,
        step_id: str,
        step_data: dict | None = None,
        time_interval: int | None = None,
        step_type: str | None = None,
        input_type: str | None = None,
    ) -> ActionResult | str:
        """Update a single step within a sequence.

        Args:
            sequence_id: Sequence ID containing the step
            step_id: Step ID to update
            step_data: Step template/content data
            time_interval: Delay in seconds after previous step
            step_type: Step type. One of: EMAIL, PHONE, SMS, WHATSAPP, HEYREACH, MANUAL_DIALER. Case-insensitive.
            input_type: Input type. One of: ON_DEMAND, MANUAL_TEMPLATE, AI_GENERATED_TEMPLATE. Case-insensitive.
        """
        body = {k: v for k, v in {
            "step_data": step_data, "time_interval": time_interval,
            "step_type": step_type, "input_type": input_type,
        }.items() if v is not None}
        return await safe_call_typed(
            client.patch(f"/sequences/{sequence_id}/steps/{step_id}", body),
            ActionResult.from_envelope,
            context="Update step",
        )

    @server.tool(annotations=_DESTRUCTIVE)
    async def g8_pause_sequence(sequence_id: str) -> ActionResult | str:
        """Pause a live sequence. Contacts in progress will be wound down.

        IMPORTANT: This pauses real outreach. Confirm with the user first.

        Args:
            sequence_id: Sequence ID to pause
        """
        return await safe_call_typed(
            client.post(f"/sequences/{sequence_id}/pause"),
            ActionResult.from_envelope,
            context="Pause sequence",
        )

    @server.tool(annotations=_DESTRUCTIVE)
    async def g8_resume_sequence(sequence_id: str) -> ActionResult | str:
        """Resume a paused sequence. Contacts will resume receiving messages.

        IMPORTANT: This resumes real outreach. Confirm with the user first.

        Args:
            sequence_id: Sequence ID to resume
        """
        return await safe_call_typed(
            client.post(f"/sequences/{sequence_id}/resume"),
            ActionResult.from_envelope,
            context="Resume sequence",
        )

    @server.tool(annotations=_READ_ONLY)
    async def g8_get_sequence_analytics(sequence_id: str) -> SequenceAnalytics | str:
        """Get comprehensive analytics for a sequence.

        Returns overview, performance, engagement, timeline, and contact distribution.

        Args:
            sequence_id: Sequence ID to get analytics for
        """
        return await safe_call_typed(
            client.get(f"/sequences/{sequence_id}/analytics"),
            SequenceAnalytics.from_envelope,
            context="Sequence analytics",
        )

    @server.tool(annotations=_DESTRUCTIVE)
    async def g8_delete_sequence(sequence_id: str) -> ActionResult | str:
        """Soft-delete (archive) a sequence. Sets is_archived=True.

        IMPORTANT: This archives a real sequence. Confirm with the user first.
        Archived sequences are hidden from the UI and excluded from worker processing.

        Args:
            sequence_id: Sequence ID to archive
        """
        return await safe_call_typed(
            client.delete(f"/sequences/{sequence_id}"),
            ActionResult.from_envelope,
            context="Delete sequence",
        )
