"""MCP-specific response models for structured tool output.

FastMCP auto-detects Pydantic return types and emits an `outputSchema` in the
tool definition, so clients know the response shape before they call. These
models intentionally subset the fields from the backend DTOs - only what the
agent actually needs to reason about. `extra="ignore"` means the backend can
add fields without breaking MCP clients.

Every result model exposes a `from_envelope(dict)` classmethod that maps the
standard ApiResponse envelope (`{"data": ..., "pagination": ...}`) into the
MCP-friendly flat shape, so pagination is visible to the model.

Philosophy:
- Prefer flat, agent-friendly shapes over mirroring backend DTOs.
- `extra="ignore"` on success models; `extra="allow"` on generic ack models
  so the model can still reason about backend-specific ack fields (job_id,
  inserted_count, etc.) that we don't want to hard-code.
- Pagination is always flat at the top level (page/limit/total/has_next)
  so the agent can paginate without reading nested structures.
"""

from __future__ import annotations

from typing import Any

from pydantic import AliasChoices, BaseModel, ConfigDict, Field


class _StrictIgnore(BaseModel):
    """Base that ignores unknown fields so backend additions don't break us."""

    model_config = ConfigDict(extra="ignore")


class _AllowExtra(BaseModel):
    """Base that ALLOWS unknown fields - useful for generic ack responses where
    the agent benefits from seeing backend-specific fields like job_id or
    inserted_count without us hard-coding every one."""

    model_config = ConfigDict(extra="allow")


# ---------------------------------------------------------------------------
# Generic action ack (for mutations where the shape is minimal / dynamic)
# ---------------------------------------------------------------------------


class ActionResult(_AllowExtra):
    """Generic result for mutations - create, update, delete, launch, etc.

    The success branch typically has `status` + an entity id or count, plus
    whatever extras the backend returned. `extra="allow"` surfaces those to
    the agent for free.
    """

    status: str | None = None
    id: str | int | None = None
    message: str | None = None

    @classmethod
    def from_envelope(cls, envelope: Any) -> "ActionResult":
        # ApiResponse envelope: {"data": {...}}. Bare dict or scalars also OK.
        if isinstance(envelope, dict):
            inner = envelope.get("data")
            if isinstance(inner, dict):
                return cls.model_validate(inner)
            if isinstance(inner, list):
                # Some endpoints return {"data": [ids...]} on bulk ops
                return cls.model_validate({"status": "ok", "message": f"{len(inner)} records"})
            # No data field - treat whole dict as the ack body
            return cls.model_validate(envelope)
        if isinstance(envelope, list):
            return cls.model_validate({"status": "ok", "message": f"{len(envelope)} records"})
        return cls(status="ok", message=str(envelope) if envelope is not None else None)


# ---------------------------------------------------------------------------
# Confirmation preview - dry-run shape for credit-spending / send mutations
# ---------------------------------------------------------------------------
#
# The wave-3 mutation tools (g8_create_list, g8_add_to_list, g8_enrich_contacts,
# g8_add_to_sequence, g8_gtm_launch_campaign, g8_voice_create_dialer_session,
# g8_voice_stop_session) accept an optional ``dry_run`` flag. When True they
# return a ConfirmationPreview instead of executing the real call. The
# confirmation widget (``ui://confirmations/...``) renders the preview and
# fires the same tool again with ``dry_run=False`` once the user clicks
# Confirm.
#
# ConfirmationPreview SUBCLASSES ActionResult so existing tool return type
# annotations of ``ActionResult | str`` stay valid -- this is the
# backwards-compat hinge. Any existing caller that introspects
# ``ActionResult`` fields (status / id / message / extras) keeps working,
# and the widget can detect the preview shape via ``preview is True``.


class ConfirmationDetail(_StrictIgnore):
    """One label/value row inside a ConfirmationPreview."""

    label: str
    value: str | None = None


class ConfirmationPreview(ActionResult):
    """Preview payload returned by wave-3 mutation tools when dry_run=True.

    Field semantics (read by the ``confirmation`` view in shell.html):
      - ``preview``   -- always True; lets the widget distinguish a preview
        from a real ack on the same tool surface.
      - ``action_label`` -- short bold header (e.g. "Save 12 contacts").
      - ``summary``   -- one-paragraph descriptor of what will happen.
      - ``details``   -- ordered list/value rows shown as a definition list.
      - ``warning``   -- amber callout (e.g. credit cost, irreversibility).
      - ``cost_label`` -- small pill above the summary for spend.
      - ``confirm_tool`` -- the tool name the widget calls on Confirm.
      - ``confirm_args`` -- args dict passed to ``confirm_tool``. MUST
        include ``dry_run=False`` so the second call actually executes.
      - ``confirm_label`` / ``cancel_label`` -- button captions.

    Inherits ``status`` / ``id`` / ``message`` / ``extra=allow`` from
    ``ActionResult``. ``status`` is left unset so a preview never looks
    like a finished ack.
    """

    preview: bool = True
    action_label: str | None = None
    summary: str | None = None
    details: list[ConfirmationDetail] = Field(default_factory=list)
    warning: str | None = None
    cost_label: str | None = None
    confirm_tool: str | None = None
    confirm_args: dict[str, Any] = Field(default_factory=dict)
    confirm_label: str | None = None
    cancel_label: str | None = None


# ---------------------------------------------------------------------------
# Skill authoring (LLM + API runtime actions, NOT workflows)
#
# Used by the g8_skill_* / g8_workflow_skill_* MCP tool family
# (tools/skills_authoring.py). Both name surfaces share these models.
# Variable extraction and template validation deliberately return structured
# results so the agent can pipe them into a follow-up create/update without
# parsing free-text. Shapes mirror what the developer_api /skills/* surface
# returns - extra=ignore so backend additions don't break clients.
# ---------------------------------------------------------------------------


class SkillVariableExtractResult(_StrictIgnore):
    """Result of extracting {variable} placeholders from a skill's templates.

    `variables` is the deduplicated, first-seen-order list of names matched
    by the single-brace regex `\\{(\\w+)\\}`. `runtime_type` is included so
    the agent can build a downstream input mapping that matches the skill's
    expected substitution surface (e.g. body_template vs query_params).
    """

    action_id: str | None = None
    runtime_type: str | None = None
    variables: list[str] = Field(default_factory=list)
    total: int = 0


class SkillValidateResult(_StrictIgnore):
    """Result of dry-running a skill template through the validator.

    Per the PRD lock (warn-only): `valid` is always True for syntactically
    parseable templates; `warnings` carries the soft issues (double-brace
    usage, unmatched braces, etc.) so the agent can repair before saving.
    """

    valid: bool = True
    variables: list[str] = Field(default_factory=list)
    variable_count: int = 0
    warnings: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Generic resource detail (single-entity GET where we don't have a bespoke model)
# ---------------------------------------------------------------------------


class ResourceDetail(_AllowExtra):
    """Generic wrapper for single-resource GETs.

    We surface `id` explicitly and let everything else flow through via
    extra="allow". The agent sees real backend fields without us having to
    model every resource shape.
    """

    id: str | int | None = None

    @classmethod
    def from_envelope(cls, envelope: Any) -> "ResourceDetail":
        if isinstance(envelope, dict):
            inner = envelope.get("data", envelope)
            if isinstance(inner, dict):
                return cls.model_validate(inner)
        return cls()


# ---------------------------------------------------------------------------
# Contacts (covers both CRM search and open-data find)
# ---------------------------------------------------------------------------


class ContactItem(_StrictIgnore):
    """Single contact summary - works for both CRM contacts and open-data prospects."""

    id: int | None = None
    first_name: str | None = None
    last_name: str | None = None
    work_email: str | None = None
    direct_phone: str | None = None
    mobile_phone: str | None = None
    job_title: str | None = None
    job_department: str | None = None
    seniority_level: str | None = None
    linkedin_url: str | None = None
    city: str | None = None
    state: str | None = None
    country: str | None = None
    # Open-data search surfaces company fields denormalized onto the contact
    company_id: int | None = None
    company_name: str | None = None
    company_domain: str | None = None
    company_industry: str | None = None
    company_employee_count: str | None = None
    confidence_score: float | None = None


class ContactsResult(_StrictIgnore):
    """Paginated contact list - flat shape with pagination at the top level."""

    contacts: list[ContactItem] = Field(default_factory=list)
    page: int = 1
    limit: int = 0
    total: int | None = None
    has_next: bool = False

    @classmethod
    def from_envelope(cls, envelope: Any) -> "ContactsResult":
        data = _extract_list(envelope)
        pag = _extract_pagination(envelope)
        items = [ContactItem.model_validate(c) for c in data if isinstance(c, dict)]
        return cls(
            contacts=items,
            page=pag.get("page", 1),
            limit=pag.get("limit", len(items)),
            total=pag.get("total"),
            has_next=pag.get("has_next", False),
        )


# ---------------------------------------------------------------------------
# Companies
# ---------------------------------------------------------------------------


class CompanyItem(_StrictIgnore):
    id: int | None = None
    name: str | None = None
    domain: str | None = None
    industry: str | None = None
    industry_group: str | None = None
    employee_count: str | None = None
    revenue: str | None = None
    founded_year: int | None = None
    country: str | None = None
    state: str | None = None
    city: str | None = None
    linkedin_url: str | None = None
    description: str | None = None
    confidence_score: float | None = None


class CompaniesResult(_StrictIgnore):
    companies: list[CompanyItem] = Field(default_factory=list)
    page: int = 1
    limit: int = 0
    total: int | None = None
    has_next: bool = False

    @classmethod
    def from_envelope(cls, envelope: Any) -> "CompaniesResult":
        data = _extract_list(envelope)
        pag = _extract_pagination(envelope)
        items = [CompanyItem.model_validate(c) for c in data if isinstance(c, dict)]
        return cls(
            companies=items,
            page=pag.get("page", 1),
            limit=pag.get("limit", len(items)),
            total=pag.get("total"),
            has_next=pag.get("has_next", False),
        )


# ---------------------------------------------------------------------------
# Campaigns (GTM list)
# ---------------------------------------------------------------------------


class CampaignItem(_StrictIgnore):
    """Single campaign summary - the shape list_campaigns returns per row."""

    id: str | None = None
    name: str | None = None
    slug: str | None = None
    status: str | None = None
    category: str | None = None
    goal: str | None = None
    target_persona: str | None = None
    created_at: str | None = None


class CampaignsResult(_StrictIgnore):
    """Paginated campaign list."""

    campaigns: list[CampaignItem] = Field(default_factory=list)
    page: int = 1
    limit: int = 0
    total: int | None = None
    has_next: bool = False

    @classmethod
    def from_envelope(cls, envelope: Any) -> "CampaignsResult":
        data = _extract_list(envelope)
        pag = _extract_pagination(envelope)
        items = [CampaignItem.model_validate(c) for c in data if isinstance(c, dict)]
        return cls(
            campaigns=items,
            page=pag.get("page", 1),
            limit=pag.get("limit", len(items)),
            total=pag.get("total"),
            has_next=pag.get("has_next", False),
        )


# ---------------------------------------------------------------------------
# Campaign documents, sequences, personas, ICPs, ideas, global context
# ---------------------------------------------------------------------------


class CampaignDocumentItem(_StrictIgnore):
    id: str | None = None
    campaign_id: str | None = None
    file_type: str | None = None
    display_name: str | None = None
    folder_path: str | None = None
    status: str | None = None
    updated_at: str | None = None
    # Content is optional - list_campaign_documents returns metadata only
    content: str | None = None


class CampaignDocumentsResult(_StrictIgnore):
    documents: list[CampaignDocumentItem] = Field(default_factory=list)

    @classmethod
    def from_envelope(cls, envelope: Any) -> "CampaignDocumentsResult":
        data = _extract_list(envelope)
        return cls(documents=[CampaignDocumentItem.model_validate(d) for d in data if isinstance(d, dict)])


# ---------------------------------------------------------------------------
# Ad images  -  result envelopes consumed by the ui://campaigns/ad-images app.
#
# The MCP App iframe (shell.html + the ad-images view_config registered in
# `resources.py`) reads `structuredContent` from the tool result via
# `ontoolresult`. Field names on the outer objects MUST match exactly what
# the view_config declares: `campaign_id`, `campaign_name`, `images[]`,
# `hidden_image_id`. Renames here are breaking changes for the widget.
# ---------------------------------------------------------------------------


class AdImageItem(_StrictIgnore):
    """Single ad creative in the per-campaign grid."""

    image_id: str | None = None
    image_url: str | None = None
    alt_text: str | None = None
    platform: str | None = None
    width: int | None = None
    height: int | None = None
    aspect_ratio: str | None = None
    style: str | None = None
    validation_score: float | None = None
    created_at: str | None = None


class AdImagesResult(_StrictIgnore):
    """Return envelope for `g8_get_ad_images`.

    Shape mirrors the `GET /api/v1/campaigns/{id}/ad-images` response. The
    app bundle reads `campaign_id`, `campaign_name`, and `images`.
    """

    campaign_id: str | None = None
    campaign_name: str | None = None
    images: list[AdImageItem] = Field(default_factory=list)
    count: int = 0

    @classmethod
    def from_envelope(cls, envelope: Any) -> "AdImagesResult":
        data = envelope.get("data") if isinstance(envelope, dict) else None
        if not isinstance(data, dict):
            return cls()
        raw_images = data.get("images") or []
        images = [
            AdImageItem.model_validate(i)
            for i in raw_images
            if isinstance(i, dict)
        ]
        return cls(
            campaign_id=data.get("campaign_id"),
            campaign_name=data.get("campaign_name"),
            images=images,
            count=data.get("count", len(images)),
        )


class AdImageHideResult(_StrictIgnore):
    """Return envelope for `g8_hide_ad_image`.

    The iframe reads `hidden_image_id` and removes the matching card from
    its local grid state. `message` is human-readable; content text
    channel renders it to model + non-app clients.
    """

    campaign_id: str | None = None
    hidden_image_id: str | None = None
    message: str | None = None

    @classmethod
    def from_envelope(cls, envelope: Any) -> "AdImageHideResult":
        data = envelope.get("data") if isinstance(envelope, dict) else None
        if not isinstance(data, dict):
            return cls()
        return cls(
            campaign_id=data.get("campaign_id"),
            hidden_image_id=data.get("hidden_image_id"),
            message=data.get("message"),
        )


class SequenceStepItem(_StrictIgnore):
    id: str | None = None
    name: str | None = None
    channel: str | None = None
    mode: str | None = None
    day: int | None = None
    angle_id: str | None = None
    cta_type: str | None = None
    personalization_level: str | None = None
    condition: str | None = None


class CampaignSequenceResult(_StrictIgnore):
    """Response for gtm_get_campaign_sequence - returns step catalog."""

    steps: list[SequenceStepItem] = Field(default_factory=list)

    @classmethod
    def from_envelope(cls, envelope: Any) -> "CampaignSequenceResult":
        data = envelope.get("data") if isinstance(envelope, dict) else None
        if isinstance(data, dict):
            steps = data.get("steps") or []
        elif isinstance(data, list):
            steps = data
        else:
            steps = []
        return cls(steps=[SequenceStepItem.model_validate(s) for s in steps if isinstance(s, dict)])


class PersonaItem(_StrictIgnore):
    id: str | None = None
    name: str | None = None
    role: str | None = None
    status: str | None = None
    description: str | None = None
    pain_points: list[str] | None = None
    updated_at: str | None = None


class PersonasResult(_StrictIgnore):
    personas: list[PersonaItem] = Field(default_factory=list)

    @classmethod
    def from_envelope(cls, envelope: Any) -> "PersonasResult":
        data = _extract_list(envelope)
        return cls(personas=[PersonaItem.model_validate(p) for p in data if isinstance(p, dict)])


class IcpItem(_StrictIgnore):
    id: str | None = None
    name: str | None = None
    status: str | None = None
    industry: str | None = None
    company_size: str | None = None
    updated_at: str | None = None


class IcpsResult(_StrictIgnore):
    icps: list[IcpItem] = Field(default_factory=list)

    @classmethod
    def from_envelope(cls, envelope: Any) -> "IcpsResult":
        data = _extract_list(envelope)
        return cls(icps=[IcpItem.model_validate(i) for i in data if isinstance(i, dict)])


class CampaignIdeaItem(_StrictIgnore):
    id: str | None = None
    title: str | None = None
    description: str | None = None
    favorited: bool | None = None
    created_at: str | None = None


class CampaignIdeasResult(_StrictIgnore):
    ideas: list[CampaignIdeaItem] = Field(default_factory=list)

    @classmethod
    def from_envelope(cls, envelope: Any) -> "CampaignIdeasResult":
        data = _extract_list(envelope)
        return cls(ideas=[CampaignIdeaItem.model_validate(i) for i in data if isinstance(i, dict)])


class GlobalContextItem(_StrictIgnore):
    id: str | None = None
    category: str | None = None
    doc_type: str | None = None
    title: str | None = None
    status: str | None = None
    updated_at: str | None = None


class GlobalContextsResult(_StrictIgnore):
    documents: list[GlobalContextItem] = Field(default_factory=list)

    @classmethod
    def from_envelope(cls, envelope: Any) -> "GlobalContextsResult":
        data = _extract_list(envelope)
        return cls(documents=[GlobalContextItem.model_validate(d) for d in data if isinstance(d, dict)])


# ---------------------------------------------------------------------------
# Lists, deals, tasks, notes, activities
# ---------------------------------------------------------------------------


class ListItem(_StrictIgnore):
    id: int | None = None
    title: str | None = None
    # Backend `Audience` entity uses `type_` as the python attribute with
    # `alias="type"` (FastAPI may serialize either). Accept both spellings
    # so the canonical `type` key is always populated downstream.
    type: str | None = Field(
        default=None,
        validation_alias=AliasChoices("type", "type_"),
    )
    # Backend `Audience.total` is the single canonical record count (regardless
    # of whether it's a contact list or company list). The legacy split fields
    # below are retained for backwards compatibility - some perf endpoints may
    # still return them - but the widget should read `total`.
    total: int | None = None
    total_contacts: int | None = None
    total_companies: int | None = None
    created_at: str | None = None
    updated_at: str | None = None


class ListsResult(_StrictIgnore):
    lists: list[ListItem] = Field(default_factory=list)
    page: int = 1
    limit: int = 0
    total: int | None = None
    has_next: bool = False

    @classmethod
    def from_envelope(cls, envelope: Any) -> "ListsResult":
        data = _extract_list(envelope)
        pag = _extract_pagination(envelope)
        items = [ListItem.model_validate(l) for l in data if isinstance(l, dict)]
        return cls(
            lists=items,
            page=pag.get("page", 1),
            limit=pag.get("limit", len(items)),
            total=pag.get("total"),
            has_next=pag.get("has_next", False),
        )


# ---------------------------------------------------------------------------
# Custom fields / columns (contact + company schemas)
# ---------------------------------------------------------------------------


class FieldItem(_StrictIgnore):
    """A single field definition - base column or user-defined custom column.

    Mirrors the developer API `FieldResponse` shape (see
    `developer_api/interfaces/dtos/fields.py`). `id` is None for base columns
    that aren't backed by a `dynamic_columns` row; populated for custom columns.
    `is_global` is True when the column applies org-wide, False when scoped
    to a specific list.
    """

    id: int | None = None
    title: str
    name: str | None = None
    data_type: str = "text"
    is_global: bool = True


class FieldsResult(_StrictIgnore):
    """Envelope-aware result for the `/fields` and `/fields/companies` endpoints."""

    fields: list[FieldItem] = Field(default_factory=list)
    entity: str = "contacts"
    list_id: int | None = None

    @classmethod
    def from_envelope(cls, envelope: Any) -> "FieldsResult":
        data = _extract_list(envelope)
        items = [FieldItem.model_validate(f) for f in data if isinstance(f, dict)]
        return cls(fields=items)


class DealItem(_StrictIgnore):
    id: str | None = None
    name: str | None = None
    amount: float | None = None
    currency: str | None = None
    stage_id: str | None = None
    stage_name: str | None = None
    pipeline_id: str | None = None
    contact_id: int | None = None
    company_id: int | None = None
    owner_id: str | None = None
    status: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
    close_date: str | None = None


class DealsResult(_StrictIgnore):
    deals: list[DealItem] = Field(default_factory=list)
    page: int = 1
    limit: int = 0
    total: int | None = None
    has_next: bool = False

    @classmethod
    def from_envelope(cls, envelope: Any) -> "DealsResult":
        data = _extract_list(envelope)
        pag = _extract_pagination(envelope)
        items = [DealItem.model_validate(d) for d in data if isinstance(d, dict)]
        return cls(
            deals=items,
            page=pag.get("page", 1),
            limit=pag.get("limit", len(items)),
            total=pag.get("total"),
            has_next=pag.get("has_next", False),
        )


class PipelineStage(_StrictIgnore):
    id: str | None = None
    name: str | None = None
    order: int | None = None


class PipelineItem(_StrictIgnore):
    id: str | None = None
    name: str | None = None
    stages: list[PipelineStage] = Field(default_factory=list)


class PipelinesResult(_StrictIgnore):
    pipelines: list[PipelineItem] = Field(default_factory=list)

    @classmethod
    def from_envelope(cls, envelope: Any) -> "PipelinesResult":
        data = _extract_list(envelope)
        return cls(pipelines=[PipelineItem.model_validate(p) for p in data if isinstance(p, dict)])


class TaskItem(_StrictIgnore):
    id: str | None = None
    title: str | None = None
    description: str | None = None
    status: str | None = None
    priority: int | None = None
    due_date: str | None = None
    assignee_id: str | None = None
    contact_id: int | None = None
    company_id: int | None = None
    created_at: str | None = None
    updated_at: str | None = None


class TasksResult(_StrictIgnore):
    tasks: list[TaskItem] = Field(default_factory=list)

    @classmethod
    def from_envelope(cls, envelope: Any) -> "TasksResult":
        data = _extract_list(envelope)
        return cls(tasks=[TaskItem.model_validate(t) for t in data if isinstance(t, dict)])


class ActivityItem(_StrictIgnore):
    id: str | None = None
    activity_type: str | None = None
    summary: str | None = None
    contact_id: int | None = None
    company_id: int | None = None
    deal_id: str | None = None
    user_id: str | None = None
    occurred_at: str | None = None
    metadata: dict | None = None


class ActivitiesResult(_StrictIgnore):
    activities: list[ActivityItem] = Field(default_factory=list)

    @classmethod
    def from_envelope(cls, envelope: Any) -> "ActivitiesResult":
        data = _extract_list(envelope)
        return cls(activities=[ActivityItem.model_validate(a) for a in data if isinstance(a, dict)])


# ---------------------------------------------------------------------------
# Sequences
# ---------------------------------------------------------------------------


class SequenceItem(_StrictIgnore):
    id: str | None = None
    name: str | None = None
    description: str | None = None
    status: str | None = None
    is_shared: bool | None = None
    is_archived: bool | None = None
    # Backend `/sequences` (sequencer.interfaces.sequences.sequences.ListSequence)
    # serializes these as `step_counts` / `contact_counts` (plural). Older callers
    # and the widget read singular names, so accept both via AliasChoices and keep
    # the singular Python attribute as the canonical serialization key. Backwards
    # compatible: existing inputs using `step_count` / `contact_count` still work.
    step_count: int | None = Field(
        default=None,
        validation_alias=AliasChoices("step_count", "step_counts"),
    )
    contact_count: int | None = Field(
        default=None,
        validation_alias=AliasChoices("contact_count", "contact_counts"),
    )
    # Channel count is also returned by the backend (`channel_counts`, plural).
    # New optional field - older callers never read this so adding it is safe.
    channel_count: int | None = Field(
        default=None,
        validation_alias=AliasChoices("channel_count", "channel_counts"),
    )
    finish_on_reply: bool | None = None
    send_in_same_thread: bool | None = None
    # Backend list endpoint also returns these; capture them so the widget can
    # surface useful metadata. Optional - old envelopes without them stay valid.
    user_email: str | None = None
    sequence_kind: str | None = None
    associated_list_id: int | None = None
    created_at: str | None = None
    updated_at: str | None = None


class SequencesResult(_StrictIgnore):
    sequences: list[SequenceItem] = Field(default_factory=list)
    page: int = 1
    limit: int = 0
    total: int | None = None
    has_next: bool = False

    @classmethod
    def from_envelope(cls, envelope: Any) -> "SequencesResult":
        data = _extract_list(envelope)
        pag = _extract_pagination(envelope)
        items = [SequenceItem.model_validate(s) for s in data if isinstance(s, dict)]
        return cls(
            sequences=items,
            page=pag.get("page", 1),
            limit=pag.get("limit", len(items)),
            total=pag.get("total"),
            has_next=pag.get("has_next", False),
        )


class SequenceStepDetail(_StrictIgnore):
    id: str | None = None
    step_order: int | None = None
    step_type: str | None = None
    input_type: str | None = None
    time_interval: int | None = None
    step_data: dict | None = None


class SequenceChannel(_StrictIgnore):
    id: str | None = None
    # Backend (developer_api/interfaces/dtos/sequences.py:108) returns int
    # because the underlying SeqSequenceChannel.channel_id column is Integer.
    # Accept str too for drift tolerance - same pattern as SequenceItem.
    channel_id: int | str | None = None
    channel_value: str | None = None
    channel_type: str | None = None


class SequencePreview(_StrictIgnore):
    id: str | None = None
    name: str | None = None
    description: str | None = None
    status: str | None = None
    steps: list[SequenceStepDetail] = Field(default_factory=list)
    channels: list[SequenceChannel] = Field(default_factory=list)

    @classmethod
    def from_envelope(cls, envelope: Any) -> "SequencePreview":
        data = envelope.get("data") if isinstance(envelope, dict) else envelope
        if not isinstance(data, dict):
            return cls()
        return cls.model_validate(data)


class SequenceAnalytics(_AllowExtra):
    """Opaque analytics payload - shape varies. Agent reads fields as they appear."""

    overview: dict | None = None
    performance: dict | None = None
    engagement: dict | None = None
    timeline: dict | None = None

    @classmethod
    def from_envelope(cls, envelope: Any) -> "SequenceAnalytics":
        data = envelope.get("data") if isinstance(envelope, dict) else envelope
        if isinstance(data, dict):
            return cls.model_validate(data)
        return cls()


# ---------------------------------------------------------------------------
# Inbox detail (single thread)
# ---------------------------------------------------------------------------


class InboxThreadSummary(_StrictIgnore):
    """Thread-level summary - full message history comes from g8_get_reply."""

    id: str | None = None
    channel: str | None = None
    subject: str | None = None
    status: str | None = None
    contact: dict | None = None
    tags: list[dict] = Field(default_factory=list)
    assignees: list[dict] = Field(default_factory=list)
    created_at: str | None = None
    updated_at: str | None = None
    # Convenience: most-recent message preview if the backend populates one
    preview: str | None = None


class InboxListResult(_StrictIgnore):
    """Paginated multi-channel inbox listing."""

    threads: list[InboxThreadSummary] = Field(default_factory=list)
    page: int = 1
    limit: int = 0
    total: int | None = None
    has_next: bool = False

    @classmethod
    def from_envelope(cls, envelope: Any) -> "InboxListResult":
        data = _extract_list(envelope)
        pag = _extract_pagination(envelope)
        items = [InboxThreadSummary.model_validate(t) for t in data if isinstance(t, dict)]
        return cls(
            threads=items,
            page=pag.get("page", 1),
            limit=pag.get("limit", len(items)),
            total=pag.get("total"),
            has_next=pag.get("has_next", False),
        )


class InboxMessage(_StrictIgnore):
    # Canonical fields returned by developer_api InboxMessageItem.
    # See developer_api/interfaces/dtos/inbox.py and the
    # _to_message_item mapper in developer_api/interfaces/v1/inbox_router.py.
    message_id: str | None = None
    from_address: str | None = None
    to_addresses: list[str] = Field(default_factory=list)
    content: str | None = None
    responder: str | None = None  # USER, AI, OTHER
    date: str | None = None
    is_draft: bool = False

    # Legacy fields kept for backwards compatibility. These are never
    # populated by the current backend, but consumers (templates,
    # downstream tools) that referenced them by name will still find
    # them as None rather than raising AttributeError. Safe to remove
    # in a future major version once we confirm no callers depend on
    # them.
    id: str | None = None
    channel: str | None = None
    direction: str | None = None  # inbound / outbound
    sender: str | None = None
    recipient: str | None = None
    subject: str | None = None
    body: str | None = None
    sent_at: str | None = None
    received_at: str | None = None


class InboxThreadDetail(_StrictIgnore):
    """Full inbox thread with message history - returned by g8_get_reply."""

    id: str | None = None
    channel: str | None = None
    subject: str | None = None
    status: str | None = None
    contact: dict | None = None
    tags: list[dict] = Field(default_factory=list)
    assignees: list[dict] = Field(default_factory=list)
    messages: list[InboxMessage] = Field(default_factory=list)
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def from_envelope(cls, envelope: Any) -> "InboxThreadDetail":
        data = envelope.get("data") if isinstance(envelope, dict) else envelope
        if not isinstance(data, dict):
            return cls()
        return cls.model_validate(data)


class InboxDraft(_AllowExtra):
    """AI-generated draft reply. Shape may vary - `extra="allow"` surfaces any
    backend-added fields (subject, references, confidence, etc.)."""

    reply_id: str | None = None
    body: str | None = None
    subject: str | None = None

    @classmethod
    def from_envelope(cls, envelope: Any) -> "InboxDraft":
        data = envelope.get("data") if isinstance(envelope, dict) else envelope
        if not isinstance(data, dict):
            return cls()
        return cls.model_validate(data)


# ---------------------------------------------------------------------------
# Knowledge base search
# ---------------------------------------------------------------------------


class KBHit(_StrictIgnore):
    """Single KB search hit."""

    doc_path: str | None = None
    section: str | None = None
    title: str | None = None
    content: str | None = None
    score: float | None = None


class KBResult(_StrictIgnore):
    """Knowledge base search result list. No pagination - the endpoint returns a flat list."""

    hits: list[KBHit] = Field(default_factory=list)

    @classmethod
    def from_envelope(cls, envelope: Any) -> "KBResult":
        data = _extract_list(envelope)
        return cls(hits=[KBHit.model_validate(h) for h in data if isinstance(h, dict)])


class KBDocument(_StrictIgnore):
    doc_path: str | None = None
    title: str | None = None
    section_count: int | None = None
    updated_at: str | None = None


class KBDocumentsResult(_StrictIgnore):
    documents: list[KBDocument] = Field(default_factory=list)

    @classmethod
    def from_envelope(cls, envelope: Any) -> "KBDocumentsResult":
        data = _extract_list(envelope)
        return cls(documents=[KBDocument.model_validate(d) for d in data if isinstance(d, dict)])


# ---------------------------------------------------------------------------
# Dev-mode repos
# ---------------------------------------------------------------------------


class RepoSummary(_StrictIgnore):
    id: str | None = None
    repo_name: str | None = None
    repo_url: str | None = None
    provider: str | None = None
    default_branch: str | None = None
    status: str | None = None
    created_at: str | None = None


class RepoDetail(_AllowExtra):
    """Detail + status for a single repo - `extra="allow"` surfaces scan_status,
    install_status, last_verified_at, and other workflow fields without us
    hard-coding them."""

    id: str | None = None
    repo_name: str | None = None
    repo_url: str | None = None
    provider: str | None = None
    default_branch: str | None = None
    status: str | None = None

    @classmethod
    def from_envelope(cls, envelope: Any) -> "RepoDetail":
        data = envelope.get("data") if isinstance(envelope, dict) else envelope
        if not isinstance(data, dict):
            return cls()
        return cls.model_validate(data)


class ScanResult(_AllowExtra):
    """Repo scan result - tech_stack / api_routes / gtm_readiness fields vary.
    `extra="allow"` so we expose everything the backend returns."""

    repo_id: str | None = None
    scanned_at: str | None = None
    tech_stack: list[str] | None = None
    api_routes: list[dict] | None = None
    readme_summary: str | None = None

    @classmethod
    def from_envelope(cls, envelope: Any) -> "ScanResult":
        data = envelope.get("data") if isinstance(envelope, dict) else envelope
        if not isinstance(data, dict):
            return cls()
        return cls.model_validate(data)


# ---------------------------------------------------------------------------
# Audience + CRM sync
# ---------------------------------------------------------------------------


class AudienceSyncItem(_StrictIgnore):
    id: int | None = None
    audience_id: int | None = None
    platform: str | None = None
    mode: str | None = None
    refresh_cadence_hours: int | None = None
    is_active: bool | None = None
    platform_audience_name: str | None = None
    last_sync_at: str | None = None
    status: str | None = None


class AudienceSyncsResult(_StrictIgnore):
    syncs: list[AudienceSyncItem] = Field(default_factory=list)

    @classmethod
    def from_envelope(cls, envelope: Any) -> "AudienceSyncsResult":
        data = _extract_list(envelope)
        return cls(syncs=[AudienceSyncItem.model_validate(s) for s in data if isinstance(s, dict)])


class SyncRunItem(_StrictIgnore):
    id: int | None = None
    started_at: str | None = None
    finished_at: str | None = None
    status: str | None = None
    member_count: int | None = None
    added_count: int | None = None
    removed_count: int | None = None
    error_message: str | None = None


class SyncRunsResult(_StrictIgnore):
    runs: list[SyncRunItem] = Field(default_factory=list)

    @classmethod
    def from_envelope(cls, envelope: Any) -> "SyncRunsResult":
        data = _extract_list(envelope)
        return cls(runs=[SyncRunItem.model_validate(r) for r in data if isinstance(r, dict)])


class CrmSyncItem(_StrictIgnore):
    provider: str | None = None
    is_connected: bool | None = None
    status: str | None = None
    last_sync_at: str | None = None
    account_name: str | None = None


class CrmSyncsResult(_StrictIgnore):
    integrations: list[CrmSyncItem] = Field(default_factory=list)

    @classmethod
    def from_envelope(cls, envelope: Any) -> "CrmSyncsResult":
        data = _extract_list(envelope)
        return cls(integrations=[CrmSyncItem.model_validate(i) for i in data if isinstance(i, dict)])


class CrmFieldItem(_StrictIgnore):
    name: str | None = None
    label: str | None = None
    type: str | None = None
    is_required: bool | None = None
    is_custom: bool | None = None


class CrmFieldsResult(_StrictIgnore):
    fields: list[CrmFieldItem] = Field(default_factory=list)
    entity_type: str | None = None
    provider: str | None = None

    @classmethod
    def from_envelope(cls, envelope: Any) -> "CrmFieldsResult":
        if isinstance(envelope, dict):
            data = envelope.get("data", envelope)
            if isinstance(data, list):
                return cls(fields=[CrmFieldItem.model_validate(f) for f in data if isinstance(f, dict)])
            if isinstance(data, dict):
                fields_data = data.get("fields") or data.get("data") or []
                return cls(
                    fields=[CrmFieldItem.model_validate(f) for f in fields_data if isinstance(f, dict)],
                    entity_type=data.get("entity_type"),
                    provider=data.get("provider"),
                )
        return cls()


# ---------------------------------------------------------------------------
# Tool search (upgrade 1 - progressive tool discovery)
# ---------------------------------------------------------------------------


class ToolSearchMatch(_StrictIgnore):
    """A single tool returned from g8_tool_search ranking."""

    name: str
    description: str = ""
    score: float = 0.0
    activated: bool = False


class ToolSearchResult(_StrictIgnore):
    """Result of a g8_tool_search call.

    `matches` is the ranked list of tools for the query (or the requested tools
    when `tool_names` was passed). `activated_session_tools` is the post-call
    set of tool names this session can now see in subsequent tools/list results.
    """

    query: str | None = None
    matches: list[ToolSearchMatch] = Field(default_factory=list)
    activated_session_tools: list[str] = Field(default_factory=list)
    always_on_tools: list[str] = Field(default_factory=list)
    total_registered_tools: int = 0
    note: str | None = None


# ---------------------------------------------------------------------------
# Code artifacts - snippet and form template tools (upgrade 2 - last 2 tools)
# ---------------------------------------------------------------------------


class TrackingMethods(_StrictIgnore):
    """Example identify/track calls returned alongside a tracking snippet."""

    identify: str | None = None
    track: str | None = None


class TrackingSnippetResult(_StrictIgnore):
    """Structured result for g8_get_tracking_snippet.

    The agent gets the code block plus enough metadata to execute the
    install: where to paste it, how to verify it loaded, and how to call
    identify/track once it's on the page.
    """

    write_key: str = ""
    tracking_host: str = ""
    framework: str = ""
    snippet_code: str = ""
    setup_steps: list[str] = Field(default_factory=list)
    tracking_methods: TrackingMethods = Field(default_factory=TrackingMethods)
    privacy_options: str = ""
    verification: list[str] = Field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "TrackingSnippetResult":
        return cls.model_validate(data)


class FormFieldDefinition(_StrictIgnore):
    """One field inside a progressive form stage."""

    name: str | None = None
    type: str | None = None
    label: str | None = None
    required: bool | None = None
    options: list[str] | None = None


class FormStageDefinition(_StrictIgnore):
    """One stage of a progressive form - collects a subset of fields."""

    stage: int | None = None
    fields: list[FormFieldDefinition] = Field(default_factory=list)


class FormTemplateResult(_StrictIgnore):
    """Structured result for g8_get_form_template.

    `template_code` is the generated component; `field_stages` is the
    machine-readable progressive-profiling plan so the agent can reason
    about what each stage collects without parsing the code.
    """

    write_key: str = ""
    tracking_host: str = ""
    framework: str = ""
    variant: str = ""
    template_code: str = ""
    field_stages: list[FormStageDefinition] = Field(default_factory=list)
    data_flow: str = ""
    customization_guide: str = ""
    prerequisite: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FormTemplateResult":
        return cls.model_validate(data)


# ---------------------------------------------------------------------------
# Skills catalog - g8_list_skills / g8_load_skill (structured output)
# ---------------------------------------------------------------------------
#
# Prior state: both skills tools returned plain `str` (JSON-as-string for
# `g8_list_skills`, raw markdown for `g8_load_skill`). That forced the agent
# to re-parse the list response every call, and made the error branch of
# `g8_load_skill` ambiguous (was it markdown, or a serialized error dict?).
#
# Current state: `SkillsCatalogResult` gives the agent typed `slug / title /
# summary / when_to_use` for every skill without parsing. `SkillContentResult`
# wraps the markdown in a `slug / title / content` envelope so the model can
# render a title and track which skill is currently loaded without scanning
# the body. Errors fall through the `Model | str` union as plain strings, so
# there's no more "JSON-encoded error dict pretending to be markdown" case.


class SkillMetadata(_StrictIgnore):
    """One skill entry - mirrors `SkillEntry` TypedDict from skills/__init__.py,
    minus the internal `path` field."""

    slug: str = ""
    title: str = ""
    summary: str = ""
    when_to_use: str = ""


class SkillsCatalogResult(_StrictIgnore):
    """Structured result for g8_list_skills.

    `skills` is ordered the same as `SKILLS_CATALOG` so the first entry is the
    curated "most likely match" for an ambiguous request. `total` is redundant
    with `len(skills)` but matches the pagination idiom used elsewhere so
    clients can write consistent handlers.
    """

    skills: list[SkillMetadata] = Field(default_factory=list)
    total: int = 0

    @classmethod
    def from_entries(cls, entries: list[dict[str, Any]]) -> "SkillsCatalogResult":
        """Build from the `SKILLS_CATALOG` list directly. `entries` items are
        expected to have at least `slug / title / summary / when_to_use` keys;
        extra keys (e.g. `path`) are ignored via `_StrictIgnore`."""
        skills = [SkillMetadata.model_validate(entry) for entry in entries if isinstance(entry, dict)]
        return cls(skills=skills, total=len(skills))


class SkillContentResult(_StrictIgnore):
    """Structured result for g8_load_skill.

    `content` is the raw markdown body; `slug` + `title` let the agent surface
    a human-readable label without splitting the markdown on its first `# `.
    """

    slug: str = ""
    title: str = ""
    content: str = ""

    @classmethod
    def from_entry(cls, entry: dict[str, Any], content: str) -> "SkillContentResult":
        """Build from a `SKILLS_CATALOG` entry + the already-loaded markdown body.

        Defensive: if `entry` lacks `title` (unexpected), falls back to `slug`
        so the agent still gets a non-empty label. `entry` is accepted as a
        plain dict (not a TypedDict) so the signature stays runtime-friendly.
        """
        slug = str(entry.get("slug", "")) if isinstance(entry, dict) else ""
        title = str(entry.get("title") or entry.get("slug") or "") if isinstance(entry, dict) else ""
        return cls(slug=slug, title=title, content=content or "")


# ---------------------------------------------------------------------------
# Envelope helpers
# ---------------------------------------------------------------------------


def _extract_list(envelope: Any) -> list:
    """Pull the list of items from a backend response, handling both envelope
    shapes (`{"data": [...]}`) and bare lists."""
    if isinstance(envelope, list):
        return envelope
    if isinstance(envelope, dict):
        data = envelope.get("data")
        if isinstance(data, list):
            return data
    return []


def _extract_pagination(envelope: Any) -> dict:
    """Pull pagination block from a standard ApiResponse envelope, if present."""
    if isinstance(envelope, dict):
        pag = envelope.get("pagination")
        if isinstance(pag, dict):
            return pag
    return {}
