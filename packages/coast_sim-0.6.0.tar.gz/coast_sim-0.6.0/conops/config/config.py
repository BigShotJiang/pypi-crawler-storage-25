from __future__ import annotations

from typing import Any

import yaml
from pydantic import Field, model_validator
from rust_ephem.constraints import ConstraintConfig

from ._base import ConfigModel
from .battery import Battery
from .constraint import Constraint, DefaultConstraint
from .fault_management import FaultManagement
from .groundstation import GroundStationRegistry
from .instrument import Payload
from .observation_categories import ObservationCategories
from .recorder import OnboardRecorder
from .solar_panel import SolarPanelSet
from .spacecraft_bus import SpacecraftBus
from .targets import TargetConfig
from .visualization import VisualizationConfig


class MissionConfig(ConfigModel):
    """
    Configuration class for the spacecraft and its subsystems.
    """

    name: str = Field(default="Default Config", description="Mission name/identifier")
    spacecraft_bus: SpacecraftBus = Field(
        default_factory=SpacecraftBus,
        description="Spacecraft Bus Configuration. Defines the main spacecraft platform including power, attitude control, and communications",
    )
    solar_panel: SolarPanelSet = Field(
        default_factory=SolarPanelSet,
        description="Solar Panel Configuration. Defines solar array characteristics and power generation capability",
    )
    payload: Payload = Field(
        default_factory=Payload,
        description="Payload/Instrument Configuration. Defines science instruments with power draw and data generation rates",
    )
    battery: Battery = Field(
        default_factory=Battery,
        description="Battery Configuration. Defines battery capacity, voltage, and charging parameters",
    )
    constraint: Constraint = Field(
        default_factory=DefaultConstraint,
        description="Pointing Constraints. Defines geometric constraints for spacecraft pointing",
    )
    ground_stations: GroundStationRegistry = Field(
        default_factory=GroundStationRegistry,
        description="Ground Station Network. Defines ground station locations and communication capabilities",
    )
    recorder: OnboardRecorder = Field(
        default_factory=OnboardRecorder,
        description="Onboard Data Recorder. Defines storage capacity and fill thresholds",
    )
    fault_management: FaultManagement = Field(
        default_factory=FaultManagement,
        description="Fault Management System. Defines thresholds and responses for system health monitoring",
    )
    observation_categories: ObservationCategories = Field(
        default_factory=ObservationCategories.default_categories,
        description="Observation Categories. Defines categories for different observation types with ID ranges",
    )
    visualization: VisualizationConfig = Field(
        default_factory=VisualizationConfig,
        exclude=True,
        description="Visualization Configuration",
    )
    targets: TargetConfig = Field(
        default_factory=TargetConfig,
        description="Target Configuration. Defines observational targets and scheduling parameters",
    )

    @model_validator(mode="after")
    def init_fault_management_defaults(self) -> MissionConfig:
        """Initialize default fault thresholds if none provided.

        Currently sets up a battery_level threshold using the battery
        max_depth_of_discharge as the minimum allowed charge level for YELLOW
        and (max_depth_of_discharge + 0.1) as RED for demonstration.
        Also sets up recorder_fill_fraction threshold using the recorder's
        yellow and red thresholds.
        Users can override via config serialization.
        """
        if self.fault_management is None:
            return self
        # Only add battery threshold if not already present
        if not any(t.name == "battery_level" for t in self.fault_management.thresholds):
            # Yellow alert at minimum allowed charge level (1.0 - max_depth_of_discharge)
            yellow = 1.0 - self.battery.max_depth_of_discharge
            # Red alert at 10% below the minimum allowed charge level
            red = max(yellow - 0.1, 0.0)  # Ensure non-negative
            self.fault_management.add_threshold(
                name="battery_level", yellow=yellow, red=red, direction="below"
            )
        # Add recorder threshold if not already present
        if not any(
            t.name == "recorder_fill_fraction" for t in self.fault_management.thresholds
        ):
            # Use recorder's built-in thresholds
            self.fault_management.add_threshold(
                name="recorder_fill_fraction",
                yellow=self.recorder.yellow_threshold,
                red=self.recorder.red_threshold,
                direction="above",
            )
        # Add star tracker threshold if not already present and star trackers are configured
        star_trackers = None
        try:
            star_trackers = self.spacecraft_bus.star_trackers
            has_star_trackers = (
                hasattr(star_trackers, "num_trackers")
                and star_trackers.num_trackers() > 0
            )
        except AttributeError:
            has_star_trackers = False

        existing_st_threshold = next(
            (
                t
                for t in self.fault_management.thresholds
                if t.name == "star_tracker_functional_count"
            ),
            None,
        )
        if existing_st_threshold is not None:
            # Config-file-loaded thresholds default triggers_safe_mode=True; force
            # it False — a tracker hard-constraint violation should alert but not
            # safehold (the scheduler already avoids the zone; if we slewed into one
            # it's a scheduling bug, not a spacecraft emergency).
            existing_st_threshold.triggers_safe_mode = False
        elif has_star_trackers and star_trackers is not None:
            # Any hard constraint violation is RED — star tracker hard constraints
            # are health-and-safety keep-outs, so any violation is immediately critical.
            # With direction="below", thresholds fire when value <= threshold, so
            # num_trackers - 1 fires the moment any tracker enters a hard constraint
            # (functional_count drops from num_trackers to num_trackers - 1).
            num_trackers = star_trackers.num_trackers()
            yellow = num_trackers - 1  # any hard violation → YELLOW and RED
            red = num_trackers - 1  # any hard violation → RED
            self.fault_management.add_threshold(
                name="star_tracker_functional_count",
                yellow=yellow,
                red=red,
                direction="below",
                triggers_safe_mode=False,
            )

        # Add ppt_unavailable threshold if not already present.
        # bool True (=1.0) > 0.5 → YELLOW; False (=0.0) is nominal; red set
        # above 1.0 so only YELLOW fires (no RED for this alert).
        if not any(
            t.name == "ppt_unavailable" for t in self.fault_management.thresholds
        ):
            self.fault_management.add_threshold(
                name="ppt_unavailable",
                yellow=0.5,
                red=1.5,  # unreachable by bool — YELLOW-only alert
                direction="above",
            )

        # Propagate star tracker hard exclusions into mission-level planning constraint.
        if star_trackers is not None and has_star_trackers:
            self.constraint.star_tracker_hard_constraint = (
                star_trackers.startracker_hard_constraint
            )
            self.constraint.star_tracker_soft_constraint = (
                star_trackers.startracker_constraint
            )
            self.constraint.star_tracker_enforce_modes = (
                star_trackers.modes_require_lock
            )
        else:
            self.constraint.star_tracker_hard_constraint = None
            self.constraint.star_tracker_soft_constraint = None
            self.constraint.star_tracker_enforce_modes = None

        radiators = None
        try:
            radiators = self.spacecraft_bus.radiators
            num_radiators = radiators.num_radiators()
            has_radiators = isinstance(num_radiators, int) and num_radiators > 0
        except (AttributeError, TypeError):
            has_radiators = False

        if radiators is not None and has_radiators:
            self.constraint.radiator_hard_constraint = (
                radiators.radiator_hard_constraint
            )
        else:
            self.constraint.radiator_hard_constraint = None

        telescope_constraint = self.payload.combined_telescope_spacecraft_constraint()
        self.constraint.telescope_hard_constraint = (
            telescope_constraint
            if isinstance(telescope_constraint, ConstraintConfig)
            else None
        )

        self.constraint.invalidate_combined_constraint_cache()
        return self

    def data_generated(self, duration_seconds: float) -> float:
        """Calculate total data generated by spacecraft bus and payload over a duration.

        Args:
            duration_seconds: Duration of data generation in seconds.

        Returns:
            float: Total amount of data generated in Gigabits.
        """
        bus_data = self.spacecraft_bus.data_generated(duration_seconds)
        payload_data = self.payload.data_generated(duration_seconds)
        return bus_data + payload_data

    @classmethod
    def from_json_file(cls, filepath: str) -> MissionConfig:
        """Load configuration from a JSON file."""
        with open(filepath) as f:
            return cls.model_validate_json(f.read())

    def to_json_file(self, filepath: str) -> None:
        """Save configuration to a JSON file."""
        with open(filepath, "w") as f:
            f.write(self.model_dump_json(indent=4))

    @classmethod
    def from_yaml_file(cls, filepath: str) -> MissionConfig:
        """Load configuration from a YAML file.

        Args:
            filepath: Path to the YAML configuration file.

        Returns:
            MissionConfig: Validated configuration object.
        """
        with open(filepath) as f:
            config_dict = yaml.safe_load(f)
            return cls.model_validate(config_dict)

    def to_yaml_file(self, filepath: str) -> None:
        """Save configuration to a YAML file with annotations.

        The YAML output includes helpful comments explaining:
        - Default units for physical quantities (e.g., power in Watts, time in seconds)
        - Purpose and meaning of configuration settings
        - Valid ranges or constraints where applicable

        Args:
            filepath: Path where the YAML file will be written.
        """
        config_dict = self.model_dump(mode="json", exclude_none=True)

        # Build annotated YAML with comments
        yaml_lines = []
        yaml_lines.append("# COAST-Sim Mission Configuration File")
        yaml_lines.append("# Generated YAML configuration with annotations")
        yaml_lines.append("#")
        yaml_lines.append(
            "# This file defines the complete spacecraft configuration including:"
        )
        yaml_lines.append("#   - Spacecraft bus and subsystems")
        yaml_lines.append("#   - Power generation and storage")
        yaml_lines.append("#   - Payload instruments")
        yaml_lines.append("#   - Ground stations")
        yaml_lines.append("#   - Operational constraints")
        yaml_lines.append("#")
        yaml_lines.append("# Units Legend:")
        yaml_lines.append("#   Power: Watts (W)")
        yaml_lines.append("#   Energy: Watt-hours (Wh)")
        yaml_lines.append("#   Time: seconds (s) unless otherwise specified")
        yaml_lines.append("#   Angles: degrees (deg)")
        yaml_lines.append(
            "#   Data rates: Gigabits per second (Gbps) or Megabits per second (Mbps)"
        )
        yaml_lines.append("#   Data volume: Gigabits (Gb) or Gigabytes (GB)")
        yaml_lines.append("#   Slew rates: degrees per second (deg/s)")
        yaml_lines.append("#   Acceleration: degrees per second squared (deg/s²)")
        yaml_lines.append("")

        # Dynamically iterate through all top-level fields
        for field_name, field_info in self.__class__.model_fields.items():
            # Skip visualization as it's excluded
            if field_info.exclude:
                continue

            if field_name not in config_dict:
                continue

            # Add section header comment
            if field_info.description:
                yaml_lines.append(f"# {field_info.description}")

            field_value = config_dict[field_name]
            field_model = field_info.annotation

            # For scalar top-level fields, just output directly
            if not isinstance(field_value, (dict, list)):
                yaml_str = yaml.safe_dump(
                    {field_name: field_value}, default_flow_style=False, sort_keys=False
                )
                yaml_lines.append(yaml_str.rstrip())
            else:
                # For dict/list fields, use the key and then indent content
                yaml_lines.append(f"{field_name}:")
                self._add_annotated_yaml_content(
                    yaml_lines, field_value, field_model, indent=1
                )
            yaml_lines.append("")

        # Write to file
        with open(filepath, "w") as f:
            f.write("\n".join(yaml_lines))

    def _add_annotated_yaml_content(
        self,
        lines: list[str],
        content: dict[str, Any] | list[Any] | Any,
        model_class: Any,
        indent: int = 1,
    ) -> None:
        """Add YAML content with annotations from Pydantic model field descriptions.

        Args:
            lines: List of YAML lines to append to
            content: The data content to serialize (dict, list, or scalar)
            model_class: The Pydantic model class for field descriptions (can be generic type)
            indent: Indentation level for nested content
        """
        ind = "  " * indent

        # Handle dict with potential nested model
        if isinstance(content, dict):
            if hasattr(model_class, "model_fields"):
                # Iterate through fields in the model
                for field_name, field_info in model_class.model_fields.items():
                    if field_name not in content:
                        continue

                    field_value = content[field_name]
                    field_annotation = self._resolve_annotation(field_info.annotation)

                    # Add field description as a comment
                    if field_info.description:
                        lines.append(f"{ind}# {field_name}: {field_info.description}")

                    # Handle lists
                    if isinstance(field_value, list):
                        lines.append(f"{ind}{field_name}:")
                        # Get the item type from list annotation
                        item_model = self._get_list_item_type(field_info.annotation)
                        if (
                            field_value
                            and isinstance(field_value[0], dict)
                            and item_model
                            and hasattr(item_model, "model_fields")
                        ):
                            # For lists of dicts with a model, add annotated items
                            for item in field_value:
                                lines.append(f"{ind}  - name: {item.get('name', '')}")
                                for (
                                    item_field_name,
                                    item_field_info,
                                ) in item_model.model_fields.items():
                                    if (
                                        item_field_name in ("name",)
                                        or item_field_name not in item
                                    ):
                                        continue
                                    item_val = item[item_field_name]
                                    if item_field_info.description:
                                        lines.append(
                                            f"{ind}    # {item_field_name}: {item_field_info.description}"
                                        )
                                    yaml_str = yaml.safe_dump(
                                        {item_field_name: item_val},
                                        default_flow_style=False,
                                        sort_keys=False,
                                    )
                                    for line in yaml_str.rstrip().split("\n"):
                                        if line:
                                            lines.append(ind + "    " + line)
                        else:
                            # Default list handling
                            self._add_annotated_yaml_content(
                                lines,
                                field_value,
                                item_model if item_model else Any,
                                indent + 1,
                            )
                    # Handle nested models
                    elif isinstance(field_value, dict) and hasattr(
                        field_annotation, "model_fields"
                    ):
                        expected_keys = set(field_annotation.model_fields.keys())
                        if set(field_value.keys()).issubset(expected_keys):
                            lines.append(f"{ind}{field_name}:")
                            self._add_annotated_yaml_content(
                                lines,
                                field_value,
                                field_annotation,
                                indent=indent + 1,
                            )
                        else:
                            yaml_str = yaml.safe_dump(
                                {field_name: field_value},
                                default_flow_style=False,
                                sort_keys=False,
                            )
                            for line in yaml_str.rstrip().split("\n"):
                                if line:
                                    lines.append(ind + line)
                    else:
                        # Scalar or non-pydantic value
                        yaml_str = yaml.safe_dump(
                            {field_name: field_value},
                            default_flow_style=False,
                            sort_keys=False,
                        )
                        for line in yaml_str.rstrip().split("\n"):
                            if line:
                                lines.append(ind + line)
            else:
                # No model class, just dump as-is
                yaml_str = yaml.safe_dump(
                    content, default_flow_style=False, sort_keys=False
                )
                for line in yaml_str.rstrip().split("\n"):
                    if line:
                        lines.append(ind + line)
                    else:
                        lines.append("")
        # Handle list
        elif isinstance(content, list):
            yaml_str = yaml.safe_dump(
                content, default_flow_style=False, sort_keys=False
            )
            for line in yaml_str.rstrip().split("\n"):
                if line:
                    lines.append(ind + line)
        else:
            # Scalar value
            yaml_str = yaml.safe_dump(
                content, default_flow_style=False, sort_keys=False
            )
            lines.append(ind + yaml_str.rstrip())

    def _resolve_annotation(self, annotation: Any) -> Any:
        """Unwrap Annotated and Union annotations to the underlying type."""
        import types
        import typing

        if hasattr(typing, "get_origin") and hasattr(typing, "get_args"):
            origin = typing.get_origin(annotation)
            args = typing.get_args(annotation)

            if origin is typing.Annotated and args:
                return self._resolve_annotation(args[0])

            if origin in (typing.Union, types.UnionType) and args:
                # Prefer a pydantic model if one exists in the union.
                for arg in args:
                    resolved = self._resolve_annotation(arg)
                    if hasattr(resolved, "model_fields"):
                        return resolved
                return self._resolve_annotation(args[0])

        return annotation

    def _get_list_item_type(self, model_class: Any) -> Any:
        """Extract the item type from a list annotation.

        Args:
            model_class: A type annotation like list[SomeModel]

        Returns:
            The item type, or None if not determinable
        """
        import typing

        if hasattr(typing, "get_origin") and hasattr(typing, "get_args"):
            origin = typing.get_origin(model_class)
            args = typing.get_args(model_class)

            if origin is list and args:
                return self._resolve_annotation(args[0])

        return None
