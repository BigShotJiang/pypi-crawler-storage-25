from typing import Any, cast

import numpy as np
import rust_ephem

from ..common import unixtime2date
from ..config import AttitudeControlSystem, Constraint, MissionConfig
from ..ditl.ditl_log import DITLLog
from . import Pointing


class TargetQueue:
    """TargetQueue class, contains a list of targets for Spacecraft to observe."""

    targets: list[Pointing]
    ephem: rust_ephem.Ephemeris | None
    utime: float
    gs: Any
    log: DITLLog | None
    constraint: Constraint | None
    acs_config: AttitudeControlSystem | None
    config: MissionConfig | None

    def __init__(
        self,
        config: MissionConfig | None = None,
        ephem: rust_ephem.Ephemeris | None = None,
        log: DITLLog | None = None,
    ):
        # Extract config parameters from Config object
        if config is None:
            raise ValueError("Config must be provided to TargetQueue")
        self.config = config
        self.constraint = config.constraint
        self.acs_config = config.spacecraft_bus.attitude_control

        self.targets = []
        self.ephem = ephem
        self.utime = 0.0
        self.gs = None
        self.log = log
        # Optional weight to penalize long slews when selecting next target
        self.slew_distance_weight = config.targets.slew_distance_weight
        self.radiator_sun_exposure_weight = config.targets.radiator_sun_exposure_weight
        self.radiator_earth_exposure_weight = (
            config.targets.radiator_earth_exposure_weight
        )

    def __getitem__(self, number: int) -> Pointing:
        return self.targets[number]

    def __len__(self) -> int:
        return len(self.targets)

    def append(self, target: Pointing) -> None:
        self.targets.append(target)

    def add(
        self,
        ra: float = 0.0,
        dec: float = 0.0,
        obsid: int = 0,
        name: str = "FakeTarget",
        merit: float = 100.0,
        exptime: int = 1000,
        ss_min: int = 300,
        ss_max: int = 86400,
    ) -> None:
        """Add a pointing target to the queue.

        Creates a new Pointing object with the specified parameters and adds it to the queue.

        Args:
            ra: Right ascension in degrees
            dec: Declination in degrees
            obsid: Observation ID
            name: Target name
            merit: Merit value for scheduling priority
            exptime: Exposure time in seconds
            ss_min: Minimum snapshot size in seconds
            ss_max: Maximum snapshot size in seconds
        """

        pointing = Pointing(
            config=self.config,
            ra=ra,
            dec=dec,
            obsid=obsid,
            name=name,
            merit=merit,
            exptime=exptime,
            ss_min=ss_min,
            ss_max=ss_max,
        )
        pointing.visibility()
        self.targets.append(pointing)

    def meritsort(self) -> None:
        """Sort target queue by merit based on visibility, type, and trigger recency."""

        for target in self.targets:
            # Initialize merit using any pre-configured merit on the target.
            # Previously this used a `fom` attribute; prefer setting `merit`
            # directly on targets now.
            if getattr(target, "fom", None) is None:
                target.merit = 100
            else:
                target.merit = target.fom

            # Penalize constrained targets
            if target.visible(self.utime, self.utime) is False:
                target.merit = -900
                continue

        # Add randomness to break ties
        for target in self.targets:
            target.merit += np.random.random()

        # Sort by merit (highest first)
        self.targets.sort(key=lambda x: x.merit, reverse=True)

    def get(
        self,
        ra: float,
        dec: float,
        utime: float,
    ) -> Pointing | None:
        """Get the next best target to observe from the queue.

        Given current position (ra, dec), roll, and time, returns the next
        highest-merit target that is visible for the minimum exposure time.

        Args:
            ra: Current right ascension in degrees.
            dec: Current declination in degrees.
            utime: Current time in Unix seconds.
            current_roll: Current spacecraft roll angle in degrees, used to
                apply roll-aware star tracker filtering when checking target
                visibility and attitude constraints.

        Returns:
            Next target to observe, or None if no suitable target found.
        """
        assert self.ephem is not None, (
            "Ephemeris must be set in TargetQueue before get()"
        )
        self.utime = utime
        self.meritsort()

        # Select targets from queue
        targets = [t for t in self.targets if t.merit > 0 and not t.done]

        msg = (
            f"{unixtime2date(self.utime)} Searching {len(targets)} targets in queue..."
        )
        if self.log is not None:
            self.log.log_event(
                utime=utime,
                event_type="QUEUE",
                description=msg,
                obsid=None,
                acs_mode=None,
            )
        else:
            print(msg)
        best_target = None
        best_score = -np.inf

        # Check each candidate target
        for target in targets:
            # Skip targets with remaining exposure less than minimum snapshot
            if target.exptime is not None and target.exptime < target.ss_min:
                continue

            target.slewtime = target.calc_slewtime(ra, dec)

            # Calculate observation window
            endtime = utime + target.slewtime + target.ss_min

            # Use timestamp for the end-of-ephemeris bound
            last_unix = self.ephem.timestamp[-1].timestamp()

            # If the end time exceeds ephemeris, clamp it
            if endtime > last_unix:
                endtime = last_unix

            # Check if target is visible for full observation
            if target.visible(utime, endtime):
                target.begin = int(utime)
                target.end = int(utime + target.slewtime + target.ss_max)
                # If no slew weighting, return first visible target (fast path)
                if self.slew_distance_weight == 0.0:
                    if (
                        self.radiator_sun_exposure_weight == 0.0
                        and self.radiator_earth_exposure_weight == 0.0
                    ):
                        return target
                # Otherwise, score all visible targets and pick best
                slewdist = getattr(target, "slewdist", 0.0)
                score = target.merit - self.slew_distance_weight * slewdist

                if (
                    self.radiator_sun_exposure_weight > 0.0
                    or self.radiator_earth_exposure_weight > 0.0
                ):
                    assert self.config is not None
                    radiators = self.config.spacecraft_bus.radiators
                    if radiators.num_radiators() > 0 and self.ephem is not None:
                        metrics = radiators.exposure_metrics(
                            ra_deg=target.ra,
                            dec_deg=target.dec,
                            utime=utime,
                            ephem=self.ephem,
                            roll_deg=getattr(target, "roll", 0.0),
                        )
                        sun_exposure = cast(float, metrics.get("sun_exposure", 0.0))
                        earth_exposure = cast(float, metrics.get("earth_exposure", 0.0))
                        score -= (
                            self.radiator_sun_exposure_weight * sun_exposure
                            + self.radiator_earth_exposure_weight * earth_exposure
                        )

                if score > best_score:
                    best_score = score
                    best_target = target

        return best_target

    def reset(self) -> None:
        """Reset queue by resetting target status.

        Resets done flags on remaining targets for reuse in subsequent
        scheduling cycles.
        """
        for target in self.targets:
            target.reset()


Queue = TargetQueue
