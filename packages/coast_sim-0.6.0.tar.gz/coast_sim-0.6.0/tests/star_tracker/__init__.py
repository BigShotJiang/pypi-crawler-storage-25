"""Star tracker tests."""
