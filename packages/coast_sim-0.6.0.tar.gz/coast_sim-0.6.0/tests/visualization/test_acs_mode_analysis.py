"""Unit tests for conops.visualization.acs_mode_analysis module."""

from datetime import datetime, timezone
from unittest.mock import Mock

import matplotlib.pyplot as plt
import plotly.graph_objects as go

from conops.common import ACSMode
from conops.config.visualization import VisualizationConfig
from conops.ditl.telemetry import Housekeeping, HousekeepingList, Telemetry
from conops.visualization.mpl.acs_mode_analysis import plot_acs_mode_distribution
from conops.visualization.plotly.acs_mode_analysis import (
    plot_acs_mode_distribution_plotly,
)


class TestPlotAcsModeDistribution:
    """Test plot_acs_mode_distribution function."""

    def test_plot_acs_mode_distribution_returns_figure_and_axes(self, mock_ditl):
        """Test that plot_acs_mode_distribution returns a figure and axes."""
        fig, ax = plot_acs_mode_distribution(mock_ditl)

        assert fig is not None
        assert ax is not None

        # Clean up
        plt.close(fig)

    def test_plot_acs_mode_distribution_custom_figsize(self, mock_ditl):
        """Test plot_acs_mode_distribution with custom figsize."""
        figsize = (8, 6)
        fig, ax = plot_acs_mode_distribution(mock_ditl, figsize=figsize)

        assert fig.get_size_inches()[0] == figsize[0]
        assert fig.get_size_inches()[1] == figsize[1]

        # Clean up
        plt.close(fig)

    def test_plot_acs_mode_distribution_with_known_modes(self, mock_ditl):
        """Test plot_acs_mode_distribution with known ACS modes."""
        fig, ax = plot_acs_mode_distribution(mock_ditl)

        # Check that the pie chart was created
        wedges = ax.patches
        assert len(wedges) > 0  # Should have pie wedges

        # Check that labels contain expected mode names
        labels = [t.get_text() for t in ax.texts if t.get_text()]
        assert any("SCIENCE" in label for label in labels)
        assert any("SLEWING" in label for label in labels)

        # Clean up
        plt.close(fig)

    def test_plot_acs_mode_distribution_with_unknown_mode(self):
        """Test plot_acs_mode_distribution handles unknown modes."""

        # Create mock with unknown mode
        mock_ditl = Mock()
        # Create telemetry with unknown mode
        hk1 = Housekeeping(
            timestamp=datetime.fromtimestamp(1000.0, tz=timezone.utc),
            acs_mode=ACSMode.SCIENCE.value,
        )
        hk2 = Housekeeping(
            timestamp=datetime.fromtimestamp(1001.0, tz=timezone.utc), acs_mode=999
        )  # 999 is unknown
        telemetry = Telemetry(housekeeping=HousekeepingList([hk1, hk2]))
        mock_ditl.telemetry = telemetry

        fig, ax = plot_acs_mode_distribution(mock_ditl)

        # Check that unknown mode is labeled appropriately
        labels = [t.get_text() for t in ax.texts if t.get_text()]
        assert any("UNKNOWN(999)" in label for label in labels)

        # Clean up
        plt.close(fig)

    def test_plot_acs_mode_distribution_title(self, mock_ditl):
        """Test that the plot has an appropriate title."""
        fig, ax = plot_acs_mode_distribution(mock_ditl)

        title = ax.get_title()
        assert "Percentage of Time Spent in Each ACS Mode" in title

        # Clean up
        plt.close(fig)

    def test_plot_acs_mode_distribution_title_font_from_config(self, mock_ditl):
        """Test that the plot title uses the font family from VisualizationConfig."""

        viz_config = VisualizationConfig(font_family="Courier")
        fig, ax = plot_acs_mode_distribution(mock_ditl, config=viz_config)
        # Get the font family applied to title font properties
        family = ax.title.get_fontproperties().get_family()
        assert isinstance(family, (list, tuple))
        assert "Courier" in family or family == ["Courier"]
        plt.close(fig)


class TestPlotAcsModeDistributionPlotly:
    """Test plot_acs_mode_distribution_plotly function."""

    def test_plot_acs_mode_distribution_plotly_populates_pie_trace(self, mock_ditl):
        """Test Plotly ACS mode distribution returns a figure with populated pie data."""
        fig = plot_acs_mode_distribution_plotly(mock_ditl)

        assert isinstance(fig, go.Figure)
        assert len(fig.data) == 1

        trace = fig.data[0]
        assert trace.type == "pie"
        assert trace.labels is not None
        assert trace.values is not None
        assert len(trace.labels) > 0
        assert len(trace.values) > 0
        assert sum(trace.values) == len(mock_ditl.telemetry.housekeeping)
