"""Tests for conops.targets.plan_schema (PlanSchema / PlanEntrySchema)."""

import json
import pathlib
from unittest.mock import Mock

import pytest

from conops.targets import PlanEntrySchema, PlanSchema

# ── Helpers ───────────────────────────────────────────────────────────────────

_ENTRY_DICT = {
    "name": "TEST",
    "ra": 123.45,
    "dec": -45.0,
    "roll": 0.0,
    "begin": 1_000_000.0,
    "end": 1_001_000.0,
    "merit": 50.0,
    "slewtime": 120,
    "insaa": 0,
    "obsid": 99,
    "obstype": "AT",
    "slewdist": 10.0,
    "ss_min": 300.0,
    "ss_max": 1_000_000.0,
    "exptime": 880,
    "exporig": 1000,
    "isat": False,
    "done": True,
    "exposure": 880,
}


def _make_schema(n: int = 2) -> PlanSchema:
    """Build a PlanSchema from raw dicts (no Plan object required)."""
    entries = [
        dict(
            _ENTRY_DICT,
            obsid=i,
            begin=float(1_000_000 + i * 2000),
            end=float(1_001_000 + i * 2000),
        )
        for i in range(n)
    ]
    return PlanSchema(
        version="test-1.0",
        created_at="2025-01-01T00:00:00+00:00",
        start=entries[0]["begin"],
        end=entries[-1]["end"],
        num_entries=n,
        entries=[PlanEntrySchema(**e) for e in entries],
    )


# ── PlanEntrySchema ────────────────────────────────────────────────────────────


class TestPlanEntrySchema:
    def test_from_dict_roundtrip(self):
        entry = PlanEntrySchema(**_ENTRY_DICT)
        assert entry.name == "TEST"
        assert entry.ra == pytest.approx(123.45)
        assert entry.dec == pytest.approx(-45.0)
        assert entry.obsid == 99
        assert entry.done is True
        assert entry.isat is False
        assert entry.exptime == 880
        assert entry.exporig == 1000

    def test_defaults_for_missing_optional_fields(self):
        entry = PlanEntrySchema(
            **{k: v for k, v in _ENTRY_DICT.items() if k not in ("isat", "done")}
        )
        assert entry.isat is False
        assert entry.done is False

    def test_model_dump_contains_all_keys(self):
        entry = PlanEntrySchema(**_ENTRY_DICT)
        dumped = entry.model_dump()
        for key in (
            "name",
            "ra",
            "dec",
            "roll",
            "begin",
            "end",
            "merit",
            "slewtime",
            "insaa",
            "obsid",
            "obstype",
            "slewdist",
            "ss_min",
            "ss_max",
            "exptime",
            "exporig",
            "isat",
            "done",
            "exposure",
        ):
            assert key in dumped, f"Missing key: {key}"

    def test_gsp_contact_metadata_roundtrips(self):
        entry = PlanEntrySchema(
            **dict(
                _ENTRY_DICT,
                obstype="GSP",
                station="TRO",
                contact_begin=1_000_120.0,
                contact_end=1_000_720.0,
            )
        )

        dumped = entry.model_dump(mode="json")
        assert dumped["station"] == "TRO"
        assert dumped["contact_begin"] == "1970-01-12T13:48:40+00:00"
        assert dumped["contact_end"] == "1970-01-12T13:58:40+00:00"

        reloaded = PlanEntrySchema(**dumped)
        assert reloaded.station == "TRO"
        assert reloaded.contact_begin == pytest.approx(1_000_120.0)
        assert reloaded.contact_end == pytest.approx(1_000_720.0)


# ── PlanSchema ─────────────────────────────────────────────────────────────────


class TestPlanSchema:
    def test_construction_and_basic_fields(self):
        schema = _make_schema(3)
        assert schema.num_entries == 3
        assert len(schema.entries) == 3
        assert schema.version == 0  # coerced from "test-1.0"
        assert schema.start == pytest.approx(1_000_000.0)

    def test_save_to_directory_autogenerates_filename(self, tmp_path):
        schema = _make_schema(1)
        returned_path = schema.save(str(tmp_path) + "/")
        assert returned_path.parent == tmp_path.resolve()
        assert returned_path.suffix == ".json"
        assert returned_path.name.startswith("plan_")
        assert returned_path.exists()

    def test_save_to_existing_directory_autogenerates_filename(self, tmp_path):
        schema = _make_schema(1)
        returned_path = schema.save(tmp_path)  # tmp_path already exists as dir
        assert returned_path.parent == tmp_path.resolve()
        assert returned_path.name.startswith("plan_")

    def test_default_filename_format(self):
        schema = _make_schema(1)
        name = schema._default_filename()
        # e.g. plan_19700101T277H46M40Z_..._vtest-1.0.json
        assert name.startswith("plan_")
        assert name.endswith(".json")
        parts = name[len("plan_") : name.rfind("_v")]
        assert "T" in parts  # ISO date component present

    def test_save_and_load_roundtrip(self, tmp_path):
        original = _make_schema(2)
        dest = tmp_path / "plan.json"
        returned_path = original.save(dest)
        assert returned_path == dest.resolve()

        loaded = PlanSchema.load(dest)
        assert loaded.version == original.version
        assert loaded.created_at == original.created_at
        assert loaded.num_entries == original.num_entries
        assert len(loaded.entries) == len(original.entries)
        assert loaded.entries[0].obsid == original.entries[0].obsid
        assert loaded.entries[0].ra == pytest.approx(original.entries[0].ra)
        assert loaded.entries[0].begin == pytest.approx(original.entries[0].begin)
        assert loaded.entries[0].end == pytest.approx(original.entries[0].end)
        assert loaded.start == pytest.approx(original.start)
        assert loaded.end == pytest.approx(original.end)

    def test_save_produces_valid_json(self, tmp_path):
        schema = _make_schema(1)
        dest = tmp_path / "plan.json"
        schema.save(dest)
        raw = json.loads(dest.read_text())
        assert "version" in raw
        assert "created_at" in raw
        assert "start" in raw
        assert "end" in raw
        assert "num_entries" in raw
        assert isinstance(raw["start"], str), "start should be an ISO-8601 string"
        assert isinstance(raw["end"], str), "end should be an ISO-8601 string"
        assert "T" in raw["start"]  # sanity-check ISO format
        assert isinstance(raw["entries"], list)
        assert len(raw["entries"]) == 1

    def test_entry_fields_in_json(self, tmp_path):
        schema = _make_schema(1)
        dest = tmp_path / "plan.json"
        schema.save(dest)
        raw = json.loads(dest.read_text())
        entry = raw["entries"][0]
        for key in (
            "name",
            "ra",
            "dec",
            "roll",
            "begin",
            "end",
            "merit",
            "slewtime",
            "insaa",
            "obsid",
            "obstype",
            "slewdist",
            "ss_min",
            "ss_max",
            "exptime",
            "exporig",
            "isat",
            "done",
            "exposure",
        ):
            assert key in entry, f"JSON entry missing key: {key}"
        assert isinstance(entry["begin"], str), "begin should be an ISO-8601 string"
        assert isinstance(entry["end"], str), "end should be an ISO-8601 string"
        assert "T" in entry["begin"]
        assert "station" not in entry
        assert "contact_begin" not in entry
        assert "contact_end" not in entry

    def test_load_existing_example_json(self):
        """Load a plan JSON file produced by a previous version (backward compat)."""
        example = (
            pathlib.Path(__file__).parent.parent.parent
            / "examples"
            / "plan_20251201T000000Z_20251201T235900Z_v0.json"
        )
        if not example.exists():
            pytest.skip("Example JSON file not found")
        schema = PlanSchema.load(example)
        assert schema.num_entries >= 0
        assert isinstance(schema.entries, list)
        assert isinstance(schema.version, int)

    def test_load_legacy_json_without_metadata(self, tmp_path):
        """Files produced before PlanSchema existed may lack created_at / num_entries."""
        legacy = {
            "version": "0.1.0",
            "start": 1_000_000,
            "end": 1_002_000,
            "entries": [_ENTRY_DICT],
        }
        dest = tmp_path / "legacy.json"
        dest.write_text(json.dumps(legacy))
        schema = PlanSchema.load(dest)
        assert schema.version == 0  # legacy semver coerced to 0
        assert len(schema.entries) == 1
        assert schema.num_entries == len(schema.entries)
        # num_entries and created_at will have schema defaults
        assert isinstance(schema.created_at, str)

    def test_reconcile_num_entries_when_missing(self, tmp_path):
        """num_entries is recomputed from entries when absent in JSON."""
        raw = {
            "version": 0,
            "start": 1_000_000,
            "end": 1_002_000,
            "entries": [_ENTRY_DICT, _ENTRY_DICT],
            # no num_entries key
        }
        dest = tmp_path / "plan.json"
        dest.write_text(json.dumps(raw))
        schema = PlanSchema.load(dest)
        assert schema.num_entries == 2

    def test_reconcile_num_entries_when_stale(self, tmp_path):
        """num_entries is corrected when it disagrees with the actual entries list."""
        raw = {
            "version": 0,
            "start": 1_000_000,
            "end": 1_002_000,
            "num_entries": 99,  # intentionally wrong
            "entries": [_ENTRY_DICT],
        }
        dest = tmp_path / "plan.json"
        dest.write_text(json.dumps(raw))
        schema = PlanSchema.load(dest)
        assert schema.num_entries == 1

    def test_reconcile_start_when_missing(self, tmp_path):
        """start is inferred from the first entry's begin time when absent."""
        raw = {
            "version": 0,
            "end": 1_001_000,
            "entries": [_ENTRY_DICT],
            # no start key
        }
        dest = tmp_path / "plan.json"
        dest.write_text(json.dumps(raw))
        schema = PlanSchema.load(dest)
        assert schema.start == pytest.approx(_ENTRY_DICT["begin"])

    def test_reconcile_end_when_missing(self, tmp_path):
        """end is inferred from the last entry's end time when absent."""
        raw = {
            "version": 0,
            "start": 1_000_000,
            "entries": [_ENTRY_DICT],
            # no end key
        }
        dest = tmp_path / "plan.json"
        dest.write_text(json.dumps(raw))
        schema = PlanSchema.load(dest)
        assert schema.end == pytest.approx(_ENTRY_DICT["end"])

    def test_from_plan_classmethod_empty_plan(self):
        """from_plan on an empty Plan should produce zero entries and start/end=0."""
        from conops.targets.plan import Plan

        plan = Plan()
        schema = PlanSchema.from_plan(plan)
        assert schema.num_entries == 0
        assert schema.entries == []
        assert schema.start == 0.0
        assert schema.end == 0.0

    def test_from_plan_clamps_negative_exposure(self, tmp_path):
        """Generated JSON should not contain negative exposure for truncated entries."""
        from conops.targets.plan import Plan
        from conops.targets.plan_entry import PlanEntry

        config = Mock()
        config.constraint = Mock()
        config.constraint.ephem = Mock()
        config.spacecraft_bus = Mock()
        config.spacecraft_bus.attitude_control = Mock()

        entry = PlanEntry(config=config)
        entry.obstype = "AT"
        entry.begin = 1000.0
        entry.end = 1060.0
        entry.slewtime = 224
        entry.insaa = 0

        plan = Plan()
        plan.append(entry)

        schema = PlanSchema.from_plan(plan)
        assert schema.entries[0].exposure == 0

        dest = tmp_path / "plan.json"
        schema.save(dest)
        raw = json.loads(dest.read_text())
        assert raw["entries"][0]["exposure"] == 0
