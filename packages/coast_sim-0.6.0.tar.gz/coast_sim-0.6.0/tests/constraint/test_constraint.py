"""Tests for conops.constraint module."""

from unittest.mock import patch

import numpy as np
import pytest

from conops import Constraint, DefaultConstraint


class TestConstraintInit:
    """Test Constraint initialization."""

    def test_constraint_init_defaults_bestroll(self, constraint) -> None:
        """Test Constraint initialization with default bestroll."""
        assert constraint.bestroll == 0.0

    def test_constraint_init_defaults_bestpointing(self, constraint) -> None:
        """Test Constraint initialization with default bestpointing."""
        assert np.array_equal(constraint.bestpointing, np.array([-1, -1, -1]))

    def test_constraint_init_defaults_ephem(self, constraint) -> None:
        """Test Constraint initialization with default ephem."""
        assert constraint.ephem is None

    def test_constraint_init_sun_constraint_defaults_to_none(self) -> None:
        """Test bare Constraint defaults to no sun constraint."""
        assert Constraint().sun_constraint is None

    def test_constraint_init_anti_sun_constraint_defaults_to_none(self) -> None:
        """Test bare Constraint defaults to no anti-sun constraint."""
        assert Constraint().anti_sun_constraint is None

    def test_constraint_init_moon_constraint_defaults_to_none(self) -> None:
        """Test bare Constraint defaults to no moon constraint."""
        assert Constraint().moon_constraint is None

    def test_constraint_init_earth_constraint_defaults_to_none(self) -> None:
        """Test bare Constraint defaults to no earth constraint."""
        assert Constraint().earth_constraint is None

    def test_constraint_init_orbit_constraint_defaults_to_none(self) -> None:
        """Test bare Constraint defaults to no orbit constraint."""
        assert Constraint().orbit_constraint is None

    def test_constraint_init_panel_constraint_defaults_to_none(self) -> None:
        """Test bare Constraint defaults to no panel constraint."""
        assert Constraint().panel_constraint is None

    def test_constraint_init_star_tracker_soft_constraint_defaults_to_none(
        self,
    ) -> None:
        """Test bare Constraint defaults to no star-tracker soft constraint."""
        assert Constraint().star_tracker_soft_constraint is None

    def test_default_constraint_has_legacy_constraints(self) -> None:
        """Test DefaultConstraint preserves legacy non-None defaults."""
        default_constraint = DefaultConstraint()
        assert default_constraint.sun_constraint is not None
        assert default_constraint.anti_sun_constraint is not None
        assert default_constraint.moon_constraint is not None
        assert default_constraint.earth_constraint is not None
        assert default_constraint.panel_constraint is not None

    def test_constraint_in_sun_noop_when_constraint_is_none(self) -> None:
        """Test in_sun returns False when sun constraint is disabled."""
        constraint = Constraint(ephem=None)
        assert not constraint.in_sun(45.0, 30.0, 1700000000.0)

    def test_constraint_in_panel_noop_when_constraint_is_none(self) -> None:
        """Test in_panel returns False when panel constraint is disabled."""
        constraint = Constraint(ephem=None)
        assert not constraint.in_panel(45.0, 30.0, 1700000000.0)

    def test_constraint_in_anti_sun_noop_when_constraint_is_none(self) -> None:
        """Test in_anti_sun returns False when anti-sun constraint is disabled."""
        constraint = Constraint(ephem=None)
        assert not constraint.in_anti_sun(45.0, 30.0, 1700000000.0)

    def test_constraint_in_earth_noop_when_constraint_is_none(self) -> None:
        """Test in_earth returns False when earth constraint is disabled."""
        constraint = Constraint(ephem=None)
        assert not constraint.in_earth(45.0, 30.0, 1700000000.0)

    def test_constraint_in_moon_noop_when_constraint_is_none(self) -> None:
        """Test in_moon returns False when moon constraint is disabled."""
        constraint = Constraint(ephem=None)
        assert not constraint.in_moon(45.0, 30.0, 1700000000.0)

    def test_constraint_in_orbit_noop_when_constraint_is_none(self) -> None:
        """Test in_orbit returns False when orbit constraint is disabled."""
        constraint = Constraint(ephem=None)
        assert not constraint.in_orbit(45.0, 30.0, 1700000000.0)


class TestConstraintProperties:
    """Test Constraint model properties."""

    def test_constraint_bestpointing_default(self, constraint) -> None:
        """Test bestpointing default value."""
        expected = np.array([-1, -1, -1])
        assert np.array_equal(constraint.bestpointing, expected)

    def test_constraint_bestroll_default(self, constraint) -> None:
        """Test bestroll default value."""
        assert constraint.bestroll == 0.0

    def test_constraint_exclusion_from_serialization(self, constraint) -> None:
        """Test that ephem is excluded from model serialization."""
        # ephem is marked with exclude=True in Field definition
        # so it should not appear in model_dump
        dumped = constraint.model_dump(exclude_unset=False)
        assert "ephem" not in dumped


class TestInSunMethod:
    """Test in_sun method - requires actual Ephemeris, skip detailed tests."""

    def test_in_sun_requires_ephemeris(self) -> None:
        """Test in_sun raises assertion without ephemeris."""
        constraint = DefaultConstraint(ephem=None)

        with pytest.raises(AssertionError, match="Ephemeris must be set"):
            constraint.in_sun(45.0, 30.0, 1700000000.0)


class TestInPanelMethod:
    """Test in_panel method - requires actual Ephemeris."""

    def test_in_panel_requires_ephemeris(self) -> None:
        """Test in_panel raises assertion without ephemeris."""
        constraint = DefaultConstraint(ephem=None)

        with pytest.raises(AssertionError, match="Ephemeris must be set"):
            constraint.in_panel(45.0, 30.0, 1700000000.0)


class TestInAntiSunMethod:
    """Test in_anti_sun method - requires actual Ephemeris."""

    def test_in_anti_sun_requires_ephemeris(self) -> None:
        """Test in_anti_sun raises assertion without ephemeris."""
        constraint = DefaultConstraint(ephem=None)

        with pytest.raises(AssertionError, match="Ephemeris must be set"):
            constraint.in_anti_sun(45.0, 30.0, 1700000000.0)


class TestInEarthMethod:
    """Test in_earth method - requires actual Ephemeris."""

    def test_in_earth_requires_ephemeris(self) -> None:
        """Test in_earth raises assertion without ephemeris."""
        constraint = DefaultConstraint(ephem=None)

        with pytest.raises(AssertionError, match="Ephemeris must be set"):
            constraint.in_earth(45.0, 30.0, 1700000000.0)


class TestInMoonMethod:
    """Test in_moon method - requires actual Ephemeris."""

    def test_in_moon_requires_ephemeris(self) -> None:
        """Test in_moon raises assertion without ephemeris."""
        constraint = DefaultConstraint(ephem=None)

        with pytest.raises(AssertionError, match="Ephemeris must be set"):
            constraint.in_moon(45.0, 30.0, 1700000000.0)


class TestInOccultMethod:
    """Test in_constraint method logic."""

    @patch("conops.Constraint.in_panel")
    @patch("conops.Constraint.in_moon")
    @patch("conops.Constraint.in_earth")
    @patch("conops.Constraint.in_anti_sun")
    @patch("conops.Constraint.in_sun")
    def test_in_constraint_no_violations(
        self, mock_sun, mock_antisun, mock_earth, mock_moon, mock_panel, constraint
    ):
        """Test in_constraint with no violations."""
        mock_sun.return_value = False
        mock_antisun.return_value = False
        mock_earth.return_value = False
        mock_moon.return_value = False
        mock_panel.return_value = False

        result = constraint.in_constraint(45.0, 30.0, 1700000000.0, 2)

        assert result is False

    @patch("conops.Constraint.in_panel")
    @patch("conops.Constraint.in_moon")
    @patch("conops.Constraint.in_earth")
    @patch("conops.Constraint.in_anti_sun")
    @patch("conops.Constraint.in_sun")
    def test_in_constraint_sun_violation(
        self, mock_sun, mock_antisun, mock_earth, mock_moon, mock_panel, constraint
    ):
        """Test in_constraint with sun constraint violation."""
        mock_sun.return_value = True
        mock_antisun.return_value = False
        mock_earth.return_value = False
        mock_moon.return_value = False
        mock_panel.return_value = False

        result = constraint.in_constraint(45.0, 30.0, 1700000000.0, 2)

        assert result is True

    @patch("conops.Constraint.in_star_tracker_soft")
    @patch("conops.Constraint.in_star_tracker_hard")
    @patch("conops.Constraint.in_panel")
    @patch("conops.Constraint.in_moon")
    @patch("conops.Constraint.in_earth")
    @patch("conops.Constraint.in_anti_sun")
    @patch("conops.Constraint.in_sun")
    def test_in_constraint_star_tracker_soft_violation(
        self,
        mock_sun,
        mock_antisun,
        mock_earth,
        mock_moon,
        mock_panel,
        mock_star_tracker_hard,
        mock_star_tracker_soft,
        constraint,
    ):
        """Test in_constraint returns True when soft star-tracker constraint is violated."""
        mock_sun.return_value = False
        mock_antisun.return_value = False
        mock_earth.return_value = False
        mock_moon.return_value = False
        mock_panel.return_value = False
        mock_star_tracker_hard.return_value = False
        mock_star_tracker_soft.return_value = True

        result = constraint.in_constraint(45.0, 30.0, 1700000000.0, 2)

        assert result is True

    @patch("conops.Constraint.in_panel")
    @patch("conops.Constraint.in_moon")
    @patch("conops.Constraint.in_earth")
    @patch("conops.Constraint.in_anti_sun")
    @patch("conops.Constraint.in_sun")
    def test_in_constraint_multiple_violations(
        self, mock_sun, mock_antisun, mock_earth, mock_moon, mock_panel, constraint
    ):
        """Test in_constraint with multiple violations."""
        mock_sun.return_value = True
        mock_antisun.return_value = False
        mock_earth.return_value = True
        mock_moon.return_value = False
        mock_panel.return_value = False

        result = constraint.in_constraint(45.0, 30.0, 1700000000.0, 2)

        assert result is True


class TestInOccultCountMethod:
    """Test in_constraint_count method logic."""

    @patch("conops.Constraint.in_panel")
    @patch("conops.Constraint.in_earth")
    @patch("conops.Constraint.in_anti_sun")
    @patch("conops.Constraint.in_moon")
    @patch("conops.Constraint.in_sun")
    def test_in_constraint_count_no_violations(
        self, mock_sun, mock_moon, mock_antisun, mock_earth, mock_panel, constraint
    ):
        """Test in_constraint_count with no violations."""
        mock_sun.return_value = False
        mock_moon.return_value = False
        mock_antisun.return_value = False
        mock_earth.return_value = False
        mock_panel.return_value = False

        count = constraint.in_constraint_count(45.0, 30.0, 1700000000.0, 12)

        assert count == 0

    @patch("conops.Constraint.in_panel")
    @patch("conops.Constraint.in_earth")
    @patch("conops.Constraint.in_anti_sun")
    @patch("conops.Constraint.in_moon")
    @patch("conops.Constraint.in_sun")
    def test_in_constraint_count_sun_only(
        self, mock_sun, mock_moon, mock_antisun, mock_earth, mock_panel, constraint
    ):
        """Test in_constraint_count with only sun violation."""
        mock_sun.return_value = True
        mock_moon.return_value = False
        mock_antisun.return_value = False
        mock_earth.return_value = False
        mock_panel.return_value = False

        count = constraint.in_constraint_count(45.0, 30.0, 1700000000.0, 21)

        assert count == 2


class TestInGalConsMethod:
    """Test ingalcons method - which appears to be missing from implementation."""

    def test_ingalcons_not_implemented(self, constraint) -> None:
        """Test that ingalcons method doesn't exist (likely legacy code reference)."""
        # The method is called in in_constraint_count with hardonly=False, but doesn't exist
        assert not hasattr(constraint, "ingalcons")


class TestConstraintFloatTimeReturnsScalar:
    """Test that float time returns scalar value, not array."""

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_in_sun_with_float_returns_scalar(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test in_sun with float time returns scalar."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_sun(45.0, 30.0, 1700000000.0)

        # Should be scalar, not array
        assert isinstance(result, bool)

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_in_sun_with_float_returns_true(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test in_sun with float time returns True."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_sun(45.0, 30.0, 1700000000.0)

        assert result

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_in_sun_with_float_called(
        self, mock_in_constraint, constraint_with_ephem
    ) -> None:
        """Test in_sun with float time calls constraint."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        _ = constraint_with_ephem.in_sun(45.0, 30.0, 1700000000.0)

        # Verify the constraint was called
        assert mock_in_constraint.called


class TestConstraintRollPassthrough:
    """Test roll passthrough to rust-ephem constraint APIs."""

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_in_sun_forwards_target_roll(
        self, mock_in_constraint, constraint_with_ephem
    ) -> None:
        mock_in_constraint.return_value = False

        _ = constraint_with_ephem.in_sun(
            45.0,
            30.0,
            1700000000.0,
            target_roll=12.5,
        )

        assert mock_in_constraint.call_args.kwargs["target_roll"] == 12.5

    def test_in_constraint_batch_forwards_target_rolls(
        self, constraint_with_ephem
    ) -> None:
        class NewBatchConstraint:
            def __init__(self) -> None:
                self.target_rolls = None

            def in_constraint_batch(
                self,
                ephemeris,
                target_ras,
                target_decs,
                times,
                indices=None,
                target_rolls=None,
                n_roll_samples=360,
            ):
                self.target_rolls = target_rolls
                return np.zeros((len(target_ras), 1), dtype=bool)

        mock_constraint = NewBatchConstraint()
        constraint_with_ephem.sun_constraint = mock_constraint
        constraint_with_ephem.earth_constraint = None
        constraint_with_ephem.panel_constraint = None
        constraint_with_ephem.moon_constraint = None
        constraint_with_ephem.anti_sun_constraint = None
        constraint_with_ephem.orbit_constraint = None
        constraint_with_ephem.star_tracker_hard_constraint = None
        constraint_with_ephem.star_tracker_soft_constraint = None

        _ = constraint_with_ephem.in_constraint_batch(
            ras=[10.0, 20.0],
            decs=[-5.0, 15.0],
            utime=1700000000.0,
            target_rolls=[22.0, 33.0],
        )

        assert mock_constraint.target_rolls == [22.0, 33.0]

    def test_in_constraint_batch_rejects_mismatched_target_rolls(
        self, constraint_with_ephem
    ) -> None:
        class NewBatchConstraint:
            def in_constraint_batch(
                self,
                ephemeris,
                target_ras,
                target_decs,
                times,
                indices=None,
                target_rolls=None,
                n_roll_samples=360,
            ):
                return np.zeros((len(target_ras), 1), dtype=bool)

        mock_constraint = NewBatchConstraint()
        constraint_with_ephem.sun_constraint = mock_constraint
        constraint_with_ephem.earth_constraint = None
        constraint_with_ephem.panel_constraint = None
        constraint_with_ephem.moon_constraint = None
        constraint_with_ephem.anti_sun_constraint = None
        constraint_with_ephem.orbit_constraint = None
        constraint_with_ephem.star_tracker_hard_constraint = None
        constraint_with_ephem.star_tracker_soft_constraint = None

        with pytest.raises(
            ValueError,
            match="target_rolls must be None or have the same length",
        ):
            constraint_with_ephem.in_constraint_batch(
                ras=[10.0, 20.0],
                decs=[-5.0, 15.0],
                utime=1700000000.0,
                target_rolls=[22.0],
            )

    @patch("rust_ephem.AndConstraint.in_constraint")
    def test_in_panel_with_float_returns_scalar(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test in_panel with float time returns scalar."""
        # Mock the in_constraint method to return False
        mock_in_constraint.return_value = False

        result = constraint_with_ephem.in_panel(45.0, 30.0, 1700000000.0)

        # Should be scalar, not array
        assert isinstance(result, bool)

    @patch("rust_ephem.AndConstraint.in_constraint")
    def test_in_panel_with_float_returns_false(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test in_panel with float time returns False."""
        # Mock the in_constraint method to return False
        mock_in_constraint.return_value = False

        result = constraint_with_ephem.in_panel(45.0, 30.0, 1700000000.0)

        assert not result

    @patch("rust_ephem.AndConstraint.in_constraint")
    def test_in_panel_with_float_called(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test in_panel with float time calls constraint."""
        # Mock the in_constraint method to return False
        mock_in_constraint.return_value = False

        _ = constraint_with_ephem.in_panel(45.0, 30.0, 1700000000.0)

        # Verify the constraint was called
        assert mock_in_constraint.called

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_in_anti_sun_with_float_returns_scalar(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test in_anti_sun with float time returns scalar."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_anti_sun(45.0, 30.0, 1700000000.0)

        # Should be scalar, not array
        assert isinstance(result, bool)

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_in_anti_sun_with_float_returns_true(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test in_anti_sun with float time returns True."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_anti_sun(45.0, 30.0, 1700000000.0)

        assert result

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_in_anti_sun_with_float_called(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test in_anti_sun with float time calls constraint."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        _ = constraint_with_ephem.in_anti_sun(45.0, 30.0, 1700000000.0)

        # Verify the constraint was called
        assert mock_in_constraint.called

    @patch("rust_ephem.EarthLimbConstraint.in_constraint")
    def test_in_earth_with_float_returns_scalar(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test in_earth with float time returns scalar."""
        # Mock the in_constraint method to return False
        mock_in_constraint.return_value = False

        result = constraint_with_ephem.in_earth(45.0, 30.0, 1700000000.0)

        # Should be scalar, not array
        assert isinstance(result, bool)

    @patch("rust_ephem.EarthLimbConstraint.in_constraint")
    def test_in_earth_with_float_returns_false(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test in_earth with float time returns False."""
        # Mock the in_constraint method to return False
        mock_in_constraint.return_value = False

        result = constraint_with_ephem.in_earth(45.0, 30.0, 1700000000.0)

        assert not result

    @patch("rust_ephem.EarthLimbConstraint.in_constraint")
    def test_in_earth_with_float_called(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test in_earth with float time calls constraint."""
        # Mock the in_constraint method to return False
        mock_in_constraint.return_value = False

        _ = constraint_with_ephem.in_earth(45.0, 30.0, 1700000000.0)

        # Verify the constraint was called
        assert mock_in_constraint.called

    @patch("rust_ephem.MoonConstraint.in_constraint")
    def test_in_moon_with_float_returns_scalar(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test in_moon with float time returns scalar."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_moon(45.0, 30.0, 1700000000.0)

        # Should be scalar, not array
        assert isinstance(result, bool)

    @patch("rust_ephem.MoonConstraint.in_constraint")
    def test_in_moon_with_float_returns_true(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test in_moon with float time returns True."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_moon(45.0, 30.0, 1700000000.0)

        assert result

    @patch("rust_ephem.MoonConstraint.in_constraint")
    def test_in_moon_with_float_called(
        self, mock_in_constraint, constraint_with_ephem
    ) -> None:
        """Test in_moon with float time calls constraint."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        _ = constraint_with_ephem.in_moon(45.0, 30.0, 1700000000.0)

        # Verify the constraint was called
        assert mock_in_constraint.called

    @patch("conops.Constraint.in_panel")
    @patch("conops.Constraint.in_earth")
    @patch("conops.Constraint.in_anti_sun")
    @patch("conops.Constraint.in_moon")
    @patch("conops.Constraint.in_sun")
    def test_in_constraint_count_all_violations(
        self, mock_sun, mock_moon, mock_antisun, mock_earth, mock_panel, constraint
    ):
        """Test in_constraint_count with all base constraints violated."""
        mock_sun.return_value = True
        mock_moon.return_value = True
        mock_antisun.return_value = True
        mock_earth.return_value = True
        mock_panel.return_value = True

        count = constraint.in_constraint_count(45.0, 30.0, 1700000000.0, 20)

        assert count == 10

    @patch("conops.Constraint.in_panel")
    @patch("conops.Constraint.in_earth")
    @patch("conops.Constraint.in_anti_sun")
    @patch("conops.Constraint.in_moon")
    @patch("conops.Constraint.in_sun")
    def test_in_constraint_count_panel_not_counted_when_not_violated(
        self, mock_sun, mock_moon, mock_antisun, mock_earth, mock_panel, constraint
    ):
        """Test in_constraint_count: panel not violated → count is 8 for 4 other violations."""
        mock_sun.return_value = True
        mock_moon.return_value = True
        mock_antisun.return_value = True
        mock_earth.return_value = True
        mock_panel.return_value = False

        count = constraint.in_constraint_count(45.0, 30.0, 1700000000.0, 20)

        # panel_constraint defaults to None in base Constraint, so in_panel returns False
        assert count == 8


class TestConstraintWithTimeObjects:
    """Test constraint methods with Time objects instead of floats."""

    @patch("rust_ephem.AndConstraint.in_constraint")
    def test_in_panel_with_time_object_returns_array(
        self, mock_in_constraint, constraint_with_ephem, time_list
    ):
        """Test in_panel with Time object returns array."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_panel(45.0, 30.0, time_list[0].timestamp())

        assert isinstance(result, bool)

    @patch("rust_ephem.AndConstraint.in_constraint")
    def test_in_panel_with_time_object_returns_length_2(
        self, mock_in_constraint, constraint_with_ephem, time_list
    ):
        """Test in_panel with Time object returns array of length 2."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_panel(45.0, 30.0, time_list[0].timestamp())

        assert isinstance(result, bool)

    @patch("rust_ephem.AndConstraint.in_constraint")
    def test_in_panel_with_time_object_called(
        self, mock_in_constraint, constraint_with_ephem, time_list
    ):
        """Test in_panel with Time object calls evaluate."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        _ = constraint_with_ephem.in_panel(45.0, 30.0, time_list[0].timestamp())

        assert mock_in_constraint.called

    @patch("rust_ephem.AndConstraint.in_constraint")
    def test_in_panel_with_time_object_second_call_returns_array(
        self, mock_in_constraint, constraint_with_ephem, time_list
    ):
        """Test in_panel with Time object second call returns array."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_panel(45.0, 30.0, time_list[0].timestamp())

        assert isinstance(result, bool)

    @patch("rust_ephem.AndConstraint.in_constraint")
    def test_in_panel_with_time_object_second_call_returns_length_2(
        self, mock_in_constraint, constraint_with_ephem, time_list
    ):
        """Test in_panel with Time object second call returns array of length 2."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_panel(45.0, 30.0, time_list[0].timestamp())

        assert isinstance(result, bool)

    @patch("conops.Constraint.in_panel")
    @patch("conops.Constraint.in_moon")
    @patch("conops.Constraint.in_earth")
    @patch("conops.Constraint.in_anti_sun")
    @patch("conops.Constraint.in_sun")
    def test_in_constraint_with_time_object_returns_array(
        self,
        mock_sun,
        mock_antisun,
        mock_earth,
        mock_moon,
        mock_panel,
        constraint,
        time_list,
    ):
        """Test in_constraint with Time object returns array."""
        mock_sun.return_value = True
        mock_antisun.return_value = False
        mock_earth.return_value = False
        mock_moon.return_value = False
        mock_panel.return_value = False

        result = constraint.in_constraint(45.0, 30.0, time_list[0].timestamp(), 10)

        assert isinstance(result, bool)

    @patch("conops.Constraint.in_panel")
    @patch("conops.Constraint.in_moon")
    @patch("conops.Constraint.in_earth")
    @patch("conops.Constraint.in_anti_sun")
    @patch("conops.Constraint.in_sun")
    def test_in_constraint_with_time_object_first_element_true(
        self,
        mock_sun,
        mock_antisun,
        mock_earth,
        mock_moon,
        mock_panel,
        constraint,
        time_list,
    ):
        """Test in_constraint with Time object first element is True."""
        mock_sun.return_value = True
        mock_antisun.return_value = False
        mock_earth.return_value = False
        mock_moon.return_value = False
        mock_panel.return_value = False

        result = constraint.in_constraint(45.0, 30.0, time_list[0].timestamp(), 10)

        assert result  # sun violation

    @patch("conops.Constraint.in_panel")
    @patch("conops.Constraint.in_moon")
    @patch("conops.Constraint.in_earth")
    @patch("conops.Constraint.in_anti_sun")
    @patch("conops.Constraint.in_sun")
    def test_in_constraint_with_time_object_second_element_true(
        self,
        mock_sun,
        mock_antisun,
        mock_earth,
        mock_moon,
        mock_panel,
        constraint,
        time_list,
    ):
        """Test in_constraint with Time object second element is True."""
        mock_sun.return_value = False
        mock_antisun.return_value = False
        mock_earth.return_value = False
        mock_moon.return_value = True
        mock_panel.return_value = False

        result = constraint.in_constraint(45.0, 30.0, time_list[1].timestamp(), 10)

        assert result  # moon violation

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_in_sun_with_time_object_returns_array(
        self, mock_in_constraint, constraint_with_ephem, time_list
    ):
        """Test in_sun with datetime list returns array."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_sun(45.0, 30.0, time_list[0].timestamp())

        assert isinstance(result, bool)

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_in_sun_with_time_object_returns_length_2(
        self, mock_in_constraint, constraint_with_ephem, time_list
    ):
        """Test in_sun with datetime list returns array of length 2."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_sun(45.0, 30.0, time_list[0].timestamp())

        assert isinstance(result, bool)

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_in_anti_sun_with_time_object_returns_array(
        self, mock_in_constraint, constraint_with_ephem, time_list
    ):
        """Test in_anti_sun with datetime list returns array."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_anti_sun(45.0, 30.0, time_list[0].timestamp())

        assert isinstance(result, bool)

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_in_anti_sun_with_time_object_returns_length_2(
        self, mock_in_constraint, constraint_with_ephem, time_list
    ):
        """Test in_anti_sun with datetime list returns array of length 2."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_anti_sun(45.0, 30.0, time_list[0].timestamp())

        assert isinstance(result, bool)

    @patch("rust_ephem.EarthLimbConstraint.in_constraint")
    def test_in_earth_with_time_object_returns_array(
        self, mock_in_constraint, constraint_with_ephem, time_list
    ):
        """Test in_earth with datetime list returns array."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_earth(45.0, 30.0, time_list[0].timestamp())

        assert isinstance(result, bool)

    @patch("rust_ephem.EarthLimbConstraint.in_constraint")
    def test_in_earth_with_time_object_returns_length_2(
        self, mock_in_constraint, constraint_with_ephem, time_list
    ):
        """Test in_earth with datetime list returns array of length 2."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_earth(45.0, 30.0, time_list[0].timestamp())

        assert isinstance(result, bool)

    @patch("rust_ephem.MoonConstraint.in_constraint")
    def test_in_moon_with_time_object_returns_array(
        self, mock_in_constraint, constraint_with_ephem, time_list
    ):
        """Test in_moon with datetime list returns array."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_moon(45.0, 30.0, time_list[0].timestamp())

        assert isinstance(result, bool)

    @patch("rust_ephem.MoonConstraint.in_constraint")
    def test_in_moon_with_time_object_returns_length_2(
        self, mock_in_constraint, constraint_with_ephem, time_list
    ):
        """Test in_moon with datetime list returns array of length 2."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_moon(45.0, 30.0, time_list[0].timestamp())

        assert isinstance(result, bool)

    @patch("rust_ephem.EclipseConstraint.in_constraint")
    def test_in_eclipse_with_time_object_returns_array(
        self, mock_in_constraint, constraint_with_ephem, time_list
    ):
        """Test in_eclipse with datetime list returns array."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_eclipse(45.0, 30.0, time_list[0].timestamp())

        assert isinstance(result, bool)

    @patch("rust_ephem.EclipseConstraint.in_constraint")
    def test_in_eclipse_with_time_object_returns_length_2(
        self, mock_in_constraint, constraint_with_ephem, time_list
    ):
        """Test in_eclipse with datetime list returns array of length 2."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_eclipse(45.0, 30.0, time_list[0].timestamp())

        assert isinstance(result, bool)


class TestConstraintEdgeCases:
    """Test edge cases and additional paths."""

    @patch("conops.Constraint.in_panel")
    @patch("conops.Constraint.in_moon")
    @patch("conops.Constraint.in_earth")
    @patch("conops.Constraint.in_anti_sun")
    @patch("conops.Constraint.in_sun")
    def test_in_constraint_panel_violation(
        self, mock_sun, mock_antisun, mock_earth, mock_moon, mock_panel, constraint
    ):
        """Test in_constraint with panel constraint violation."""
        mock_sun.return_value = False
        mock_antisun.return_value = False
        mock_earth.return_value = False
        mock_moon.return_value = False
        mock_panel.return_value = True

        result = constraint.in_constraint(45.0, 30.0, 1700000000.0, 2)

        assert result is True

    @patch("conops.Constraint.in_panel")
    @patch("conops.Constraint.in_moon")
    @patch("conops.Constraint.in_earth")
    @patch("conops.Constraint.in_anti_sun")
    @patch("conops.Constraint.in_sun")
    def test_in_constraint_antisun_violation(
        self, mock_sun, mock_antisun, mock_earth, mock_moon, mock_panel, constraint
    ):
        """Test in_constraint with antisun constraint violation."""
        mock_sun.return_value = False
        mock_antisun.return_value = True
        mock_earth.return_value = False
        mock_moon.return_value = False
        mock_panel.return_value = False

        result = constraint.in_constraint(45.0, 30.0, 1700000000.0, 2)

        assert result is True

    @patch("conops.Constraint.in_panel")
    @patch("conops.Constraint.in_moon")
    @patch("conops.Constraint.in_earth")
    @patch("conops.Constraint.in_anti_sun")
    @patch("conops.Constraint.in_sun")
    def test_in_constraint_moon_violation(
        self, mock_sun, mock_antisun, mock_earth, mock_moon, mock_panel, constraint
    ):
        """Test in_constraint with moon constraint violation."""
        mock_sun.return_value = False
        mock_antisun.return_value = False
        mock_earth.return_value = False
        mock_moon.return_value = True
        mock_panel.return_value = False

        result = constraint.in_constraint(45.0, 30.0, 1700000000.0, 2)

        assert result is True

    @patch("conops.Constraint.in_panel")
    @patch("conops.Constraint.in_moon")
    @patch("conops.Constraint.in_earth")
    @patch("conops.Constraint.in_anti_sun")
    @patch("conops.Constraint.in_sun")
    def test_in_constraint_earth_violation(
        self, mock_sun, mock_antisun, mock_earth, mock_moon, mock_panel, constraint
    ):
        """Test in_constraint with earth constraint violation."""
        mock_sun.return_value = False
        mock_antisun.return_value = False
        mock_earth.return_value = True
        mock_moon.return_value = False
        mock_panel.return_value = False

        result = constraint.in_constraint(45.0, 30.0, 1700000000.0, 2)

        assert result is True

    @patch("conops.Constraint.in_panel")
    @patch("conops.Constraint.in_earth")
    @patch("conops.Constraint.in_anti_sun")
    @patch("conops.Constraint.in_moon")
    @patch("conops.Constraint.in_sun")
    def test_in_constraint_count_moon_only(
        self, mock_sun, mock_moon, mock_antisun, mock_earth, mock_panel, constraint
    ):
        """Test in_constraint_count with only moon violation."""
        mock_sun.return_value = False
        mock_moon.return_value = True
        mock_antisun.return_value = False
        mock_earth.return_value = False
        mock_panel.return_value = False

        count = constraint.in_constraint_count(45.0, 30.0, 1700000000.0, 2)

        assert count == 2

    @patch("conops.Constraint.in_panel")
    @patch("conops.Constraint.in_earth")
    @patch("conops.Constraint.in_anti_sun")
    @patch("conops.Constraint.in_moon")
    @patch("conops.Constraint.in_sun")
    def test_in_constraint_count_antisun_only(
        self, mock_sun, mock_moon, mock_antisun, mock_earth, mock_panel, constraint
    ):
        """Test in_constraint_count with only antisun violation."""
        mock_sun.return_value = False
        mock_moon.return_value = False
        mock_antisun.return_value = True
        mock_earth.return_value = False
        mock_panel.return_value = False

        count = constraint.in_constraint_count(45.0, 30.0, 1700000000.0, 2)

        assert count == 2

    @patch("conops.Constraint.in_panel")
    @patch("conops.Constraint.in_earth")
    @patch("conops.Constraint.in_anti_sun")
    @patch("conops.Constraint.in_moon")
    @patch("conops.Constraint.in_sun")
    def test_in_constraint_count_earth_only(
        self, mock_sun, mock_moon, mock_antisun, mock_earth, mock_panel, constraint
    ):
        """Test in_constraint_count with only earth violation."""
        mock_sun.return_value = False
        mock_moon.return_value = False
        mock_antisun.return_value = False
        mock_earth.return_value = True
        mock_panel.return_value = False

        count = constraint.in_constraint_count(45.0, 30.0, 1700000000.0, 2)

        assert count == 2


class TestInEclipseMethod:
    """Test in_eclipse method - requires actual Ephemeris."""

    def test_in_eclipse_requires_ephemeris(self) -> None:
        """Test in_eclipse raises assertion without ephemeris."""
        constraint = Constraint(ephem=None)

        with pytest.raises(AssertionError, match="Ephemeris must be set"):
            constraint.in_eclipse(45.0, 30.0, 1700000000.0)

    @patch("rust_ephem.EclipseConstraint.in_constraint")
    def test_in_eclipse_with_float_returns_scalar(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test in_eclipse with float time returns scalar."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_eclipse(45.0, 30.0, 1700000000.0)

        # Should be scalar, not array
        assert isinstance(result, bool)

    @patch("rust_ephem.EclipseConstraint.in_constraint")
    def test_in_eclipse_with_float_returns_true(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test in_eclipse with float time returns True."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_eclipse(45.0, 30.0, 1700000000.0)

        assert result

    @patch("rust_ephem.EclipseConstraint.in_constraint")
    def test_in_eclipse_with_float_called(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test in_eclipse with float time calls constraint."""
        # Mock the in_constraint method to return True
        mock_in_constraint.return_value = True

        _ = constraint_with_ephem.in_eclipse(45.0, 30.0, 1700000000.0)

        assert mock_in_constraint.called


class TestConstraintInSun:
    """Test Constraint in_sun method behavior."""

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_in_sun_calls_underlying_constraint(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test that in_sun calls the underlying SunConstraint."""
        mock_in_constraint.return_value = True

        result = constraint_with_ephem.in_sun(
            45.0, 30.0, 1700000000.0, target_roll=15.0
        )

        assert result is True
        mock_in_constraint.assert_called_once()


class TestConstraintCaching:
    """Test constraint result caching functionality."""

    def test_cache_stats_initial_zeros(self, constraint) -> None:
        """Test that cache stats start at zero."""
        hits, misses = constraint.cache_stats()
        assert hits == 0
        assert misses == 0

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_cache_miss_increments_counter(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test that cache miss increments the miss counter."""
        mock_in_constraint.return_value = True

        constraint_with_ephem.in_sun(45.0, 30.0, 1700000000.0, target_roll=15.0)

        hits, misses = constraint_with_ephem.cache_stats()
        assert hits == 0
        assert misses == 1

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_cache_hit_increments_counter(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test that cache hit increments the hit counter."""
        mock_in_constraint.return_value = True

        # First call - cache miss
        constraint_with_ephem.in_sun(45.0, 30.0, 1700000000.0, target_roll=15.0)
        # Second call - cache hit
        constraint_with_ephem.in_sun(45.0, 30.0, 1700000000.0, target_roll=15.0)

        hits, misses = constraint_with_ephem.cache_stats()
        assert hits == 1
        assert misses == 1

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_cache_returns_same_result(
        self, mock_in_constraint, constraint_with_ephem
    ) -> None:
        """Test that cached result matches original result."""
        mock_in_constraint.return_value = True

        result1 = constraint_with_ephem.in_sun(
            45.0, 30.0, 1700000000.0, target_roll=15.0
        )
        result2 = constraint_with_ephem.in_sun(
            45.0, 30.0, 1700000000.0, target_roll=15.0
        )

        assert result1 is True
        assert result2 is True
        # Should only call underlying constraint once
        mock_in_constraint.assert_called_once()

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_clear_cache_resets(
        self, mock_in_constraint, constraint_with_ephem
    ) -> None:
        """Test that clear_cache clears the cache."""
        mock_in_constraint.return_value = True

        constraint_with_ephem.in_sun(45.0, 30.0, 1700000000.0, target_roll=15.0)
        assert len(constraint_with_ephem._cache) == 1

        constraint_with_ephem.clear_cache()
        assert len(constraint_with_ephem._cache) == 0

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_different_times_different_cache_entries(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test that different times create different cache entries."""
        mock_in_constraint.return_value = True

        constraint_with_ephem.in_sun(45.0, 30.0, 1700000000.0, target_roll=15.0)
        constraint_with_ephem.in_sun(45.0, 30.0, 1700000100.0, target_roll=15.0)

        hits, misses = constraint_with_ephem.cache_stats()
        assert hits == 0
        assert misses == 2

    @patch("rust_ephem.SunConstraint.in_constraint")
    @patch("rust_ephem.EarthLimbConstraint.in_constraint")
    def test_different_constraint_types_cached_separately(
        self, mock_earth, mock_sun, constraint_with_ephem
    ):
        """Test that different constraint types have separate cache entries."""
        mock_sun.return_value = True
        mock_earth.return_value = False

        # Check sun and earth at same position/time
        sun_result = constraint_with_ephem.in_sun(
            45.0, 30.0, 1700000000.0, target_roll=15.0
        )
        earth_result = constraint_with_ephem.in_earth(
            45.0, 30.0, 1700000000.0, target_roll=15.0
        )

        assert sun_result is True
        assert earth_result is False
        # Both should be cache misses
        hits, misses = constraint_with_ephem.cache_stats()
        assert hits == 0
        assert misses == 2

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_cache_key_rounding_prevents_float_misses(
        self, mock_in_constraint, constraint_with_ephem
    ):
        """Test that small floating point differences hit the cache."""
        mock_in_constraint.return_value = True

        # Very slightly different RA values that should round to same key
        # Both round to 45.00 (2 decimal places)
        constraint_with_ephem.in_sun(45.001, 30.0, 1700000000.0, target_roll=15.0)
        constraint_with_ephem.in_sun(45.004, 30.0, 1700000000.0, target_roll=15.0)

        hits, misses = constraint_with_ephem.cache_stats()
        assert hits == 1  # Second call should hit cache
        assert misses == 1


class TestIgnoreRoll:
    """Tests for Constraint.ignore_roll — forces target_roll=None on all checks."""

    def test_ignore_roll_default_is_false(self, constraint_with_ephem) -> None:
        """ignore_roll defaults to False."""
        assert constraint_with_ephem.ignore_roll is False

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_ignore_roll_false_passes_roll_to_backend(
        self, mock_in_constraint, constraint_with_ephem
    ) -> None:
        """When ignore_roll=False the supplied roll is forwarded."""
        mock_in_constraint.return_value = False
        constraint_with_ephem.ignore_roll = False

        constraint_with_ephem.in_sun(45.0, 30.0, 1700000000.0, target_roll=42.0)

        _, kwargs = mock_in_constraint.call_args
        assert kwargs["target_roll"] == 42.0

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_ignore_roll_true_passes_actual_roll_to_backend(
        self, mock_in_constraint, constraint_with_ephem
    ) -> None:
        """When ignore_roll=True the actual roll is still forwarded to the backend.

        ignore_roll controls which roll is *chosen* (best solar within valid
        constraint range), not whether the roll is supplied to constraint checks.
        """
        mock_in_constraint.return_value = False
        constraint_with_ephem.ignore_roll = True

        constraint_with_ephem.in_sun(45.0, 30.0, 1700000000.0, target_roll=42.0)

        _, kwargs = mock_in_constraint.call_args
        assert kwargs["target_roll"] == 42.0

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_ignore_roll_true_different_rolls_are_separate_cache_entries(
        self, mock_in_constraint, constraint_with_ephem
    ) -> None:
        """With ignore_roll=True, different rolls produce different cache entries.

        The actual roll value is always used in the cache key so that each
        distinct roll is evaluated independently against the backend.
        """
        mock_in_constraint.return_value = True
        constraint_with_ephem.ignore_roll = True

        r1 = constraint_with_ephem.in_sun(45.0, 30.0, 1700000000.0, target_roll=0.0)
        r2 = constraint_with_ephem.in_sun(45.0, 30.0, 1700000000.0, target_roll=90.0)
        r3 = constraint_with_ephem.in_sun(45.0, 30.0, 1700000000.0, target_roll=180.0)

        assert r1 is True
        assert r2 is True
        assert r3 is True
        # Each distinct roll is a separate cache entry — 3 misses, 0 hits
        hits, misses = constraint_with_ephem.cache_stats()
        assert misses == 3
        assert hits == 0

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_ignore_roll_false_different_rolls_are_separate_cache_entries(
        self, mock_in_constraint, constraint_with_ephem
    ) -> None:
        """With ignore_roll=False, different rolls produce different cache entries."""
        mock_in_constraint.return_value = False
        constraint_with_ephem.ignore_roll = False

        constraint_with_ephem.in_sun(45.0, 30.0, 1700000000.0, target_roll=0.0)
        constraint_with_ephem.in_sun(45.0, 30.0, 1700000000.0, target_roll=90.0)

        hits, misses = constraint_with_ephem.cache_stats()
        assert misses == 2
        assert hits == 0

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_ignore_roll_propagates_through_in_constraint(
        self,
        mock_sun_backend,
        constraint_with_ephem,
    ) -> None:
        """ignore_roll=True does not suppress the roll forwarded to the backend."""
        mock_sun_backend.return_value = True
        constraint_with_ephem.ignore_roll = True

        constraint_with_ephem.in_constraint(45.0, 30.0, 1700000000.0, target_roll=42.0)

        _, kwargs = mock_sun_backend.call_args
        assert kwargs["target_roll"] == 42.0

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_ignore_roll_false_does_not_strip_roll_in_in_constraint(
        self,
        mock_sun_backend,
        constraint_with_ephem,
    ) -> None:
        """ignore_roll=False passes the supplied roll down to the backend."""
        mock_sun_backend.return_value = True
        constraint_with_ephem.ignore_roll = False

        constraint_with_ephem.in_constraint(45.0, 30.0, 1700000000.0, target_roll=42.0)

        _, kwargs = mock_sun_backend.call_args
        assert kwargs["target_roll"] == 42.0


class TestInTelescopeHard:
    """Test in_telescope_hard method."""

    def test_no_constraint_returns_false(self) -> None:
        c = Constraint()
        assert c.in_telescope_hard(45.0, 30.0, 1700000000.0) is False

    def test_requires_ephemeris_when_constraint_set(self) -> None:
        import rust_ephem

        c = Constraint(
            telescope_hard_constraint=rust_ephem.SunConstraint(min_angle=45.0),
            ephem=None,
        )
        with pytest.raises(AssertionError, match="Ephemeris must be set"):
            c.in_telescope_hard(45.0, 30.0, 1700000000.0)

    @patch("rust_ephem.SunConstraint.in_constraint")
    def test_delegates_to_cached_check(self, mock_backend) -> None:
        from unittest.mock import Mock

        import rust_ephem

        mock_backend.return_value = True
        c = Constraint(
            telescope_hard_constraint=rust_ephem.SunConstraint(min_angle=45.0),
        )
        c.ephem = Mock()  # assign post-construction (validate_assignment=False)
        result = c.in_telescope_hard(45.0, 30.0, 1700000000.0)
        assert result is True
        assert mock_backend.called
