"""Unit tests for QueueDITL class."""

from typing import cast
from unittest.mock import Mock, patch

import pytest

from conops import ACSCommandType, ACSMode, Pass, QueueDITL
from conops.common.enums import ObsType
from conops.config.config import MissionConfig
from conops.ditl.telemetry import Housekeeping
from conops.targets import PlanEntry, PlanSchema


class TestQueueDITLInitialization:
    """Test QueueDITL initialization."""

    def test_initialization_ppts_defaults(self, mock_config: MissionConfig) -> None:
        with (
            patch("conops.Queue"),
            patch("conops.PassTimes"),
            patch("conops.ACS"),
        ):
            ditl = QueueDITL(config=mock_config)
            assert ditl.ppt is None
            assert ditl.charging_ppt is None

    def test_initialization_pointing_lists_empty(
        self, mock_config: MissionConfig
    ) -> None:
        with (
            patch("conops.Queue"),
            patch("conops.PassTimes"),
            patch("conops.ACS"),
        ):
            ditl = QueueDITL(config=mock_config)
            assert ditl.ra == []
            assert ditl.dec == []
            assert ditl.roll == []
            assert ditl.mode == []
            assert ditl.obsid == []

    def test_initialization_power_lists_empty_and_plan(
        self, mock_config: MissionConfig
    ) -> None:
        with (
            patch("conops.Queue"),
            patch("conops.PassTimes"),
            patch("conops.ACS"),
        ):
            ditl = QueueDITL(config=mock_config)
            assert ditl.panel == []
            assert ditl.batterylevel == []
            assert ditl.power == []
            assert ditl.panel_power == []
            assert ditl.plan is not None and len(ditl.plan) == 0

    def test_initialization_stores_config_subsystems(
        self, mock_config: MissionConfig
    ) -> None:
        with (
            patch("conops.Queue"),
            patch("conops.PassTimes"),
            patch("conops.ACS"),
        ):
            ditl = QueueDITL(config=mock_config)
            assert ditl.constraint is mock_config.constraint
            assert ditl.battery is mock_config.battery
            assert ditl.spacecraft_bus is mock_config.spacecraft_bus
            assert ditl.payload is mock_config.payload


class TestSetupSimulationTiming:
    """Test _setup_simulation_timing helper method."""

    def test_setup_timing_success_returns_true(self, queue_ditl: QueueDITL) -> None:
        queue_ditl.step_size = 60
        assert queue_ditl._setup_simulation_timing() is True

    def test_setup_timing_sets_ustart(self, queue_ditl: QueueDITL) -> None:
        queue_ditl.step_size = 60
        queue_ditl._setup_simulation_timing()
        assert queue_ditl.ustart > 0

    def test_setup_timing_sets_uend_greater(self, queue_ditl: QueueDITL) -> None:
        queue_ditl.step_size = 60
        queue_ditl._setup_simulation_timing()
        assert queue_ditl.uend > queue_ditl.ustart

    def test_setup_timing_uend_length_and_utime(self, queue_ditl: QueueDITL) -> None:
        queue_ditl.step_size = 60
        queue_ditl._setup_simulation_timing()
        assert queue_ditl.uend == queue_ditl.ustart + 86400
        assert len(queue_ditl.utime) == 86400 // 60


class TestScheduleGroundstationPasses:
    """Test _schedule_groundstation_passes helper method."""

    def test_schedule_passes_empty_schedule_called(self, queue_ditl: QueueDITL) -> None:
        queue_ditl.acs.passrequests.passes = []
        queue_ditl._schedule_groundstation_passes()
        cast(Mock, queue_ditl.acs.passrequests.get).assert_called_once_with(
            2018, 331, 1
        )

    def test_schedule_passes_empty_prints_message(
        self, queue_ditl: QueueDITL, capsys: pytest.CaptureFixture[str]
    ) -> None:
        queue_ditl.acs.passrequests.passes = []
        queue_ditl._schedule_groundstation_passes()
        # Check the log instead of print output
        assert len(queue_ditl.log.events) > 0
        assert any(
            "Scheduling groundstation passes" in event.description
            for event in queue_ditl.log.events
        )

    def test_schedule_passes_already_scheduled_no_get(
        self, queue_ditl: QueueDITL
    ) -> None:
        mock_pass = Mock()
        queue_ditl.acs.passrequests.passes = [mock_pass]
        queue_ditl._schedule_groundstation_passes()
        cast(Mock, queue_ditl.acs.passrequests.get).assert_not_called()

    def test_schedule_passes_returns_passes_print(
        self, queue_ditl: QueueDITL, capsys: pytest.CaptureFixture[str]
    ) -> None:
        queue_ditl.acs.passrequests.passes = []

        # Create mock passes
        mock_pass1 = Mock()
        mock_pass1.__str__ = Mock(return_value="Pass 1")
        mock_pass2 = Mock()
        mock_pass2.__str__ = Mock(return_value="Pass 2")

        # After calling get, passes should be populated
        def populate_passes(year: int, day: int, length: int) -> None:
            queue_ditl.acs.passrequests.passes = [mock_pass1, mock_pass2]

        cast(Mock, queue_ditl.acs.passrequests.get).side_effect = populate_passes
        queue_ditl._schedule_groundstation_passes()
        # Check the log instead of print output
        assert len(queue_ditl.log.events) > 0
        log_text = "\n".join(event.description for event in queue_ditl.log.events)
        assert "Scheduling groundstation passes" in log_text
        assert "Pass 1" in log_text
        assert "Pass 2" in log_text

    def test_schedule_passes_logs_skipped_overlapping_passes(
        self, queue_ditl: QueueDITL
    ) -> None:
        queue_ditl.acs.passrequests.passes = []

        selected = Mock()
        selected.__str__ = Mock(return_value="Selected pass")
        dropped = Mock()
        dropped.__str__ = Mock(return_value="Dropped pass")

        def populate_passes(year: int, day: int, length: int) -> None:
            queue_ditl.acs.passrequests.passes = [selected]
            queue_ditl.acs.passrequests.dropped_overlapping_passes = [
                (dropped, selected)
            ]

        cast(Mock, queue_ditl.acs.passrequests.get).side_effect = populate_passes
        queue_ditl._schedule_groundstation_passes()

        log_text = "\n".join(event.description for event in queue_ditl.log.events)
        assert "Skipped overlapping pass opportunity: Dropped pass" in log_text
        assert "overlaps selected pass Selected pass" in log_text


class TestDetermineMode:
    """Test mode determination now handled by ACS.get_mode() - these tests use real ACS instance."""

    def test_determine_mode_slewing(
        self, mock_config: MissionConfig, mock_ephem: Mock
    ) -> None:
        from conops import ACS, Constraint

        constraint = Constraint(ephem=None)
        constraint.ephem = mock_ephem
        mock_config.constraint = constraint
        acs = ACS(config=mock_config)

        mock_slew = Mock()
        mock_slew.is_slewing = Mock(return_value=True)
        mock_slew.obstype = "PPT"
        acs.current_slew = mock_slew

        mode = acs.get_mode(1000.0)
        assert mode == ACSMode.SLEWING

    def test_determine_mode_pass(
        self, mock_config: MissionConfig, mock_ephem: Mock
    ) -> None:
        from conops import ACS, Constraint, Pass

        constraint = Constraint(ephem=None)
        constraint.ephem = mock_ephem
        mock_config.constraint = constraint
        acs = ACS(config=mock_config)

        mock_pass = Mock(spec=Pass)
        mock_pass.in_pass = Mock(return_value=True)
        acs.current_pass = mock_pass

        mode = acs.get_mode(1000.0)
        assert mode == ACSMode.PASS

    def test_determine_mode_saa(
        self, mock_config: MissionConfig, mock_ephem: Mock
    ) -> None:
        from conops import ACS, Constraint

        constraint = Constraint(ephem=None)
        constraint.ephem = mock_ephem
        mock_config.constraint = constraint
        acs = ACS(config=mock_config)

        acs.current_slew = None
        object.__setattr__(acs, "saa", Mock())
        cast(Mock, acs.saa).insaa = Mock(return_value=True)

        mode = acs.get_mode(1000.0)
        assert mode == ACSMode.SAA

    def test_determine_mode_charging(
        self,
        mock_config: MissionConfig,
        mock_ephem: Mock,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        from conops import ACS, Constraint

        constraint = Mock(spec=Constraint)
        constraint.ephem = mock_ephem
        constraint.constraint = None  # no combined rust-ephem constraint in tests
        constraint.roll_dependent_constraint = None
        mock_config.constraint = constraint
        acs = ACS(config=mock_config)
        monkeypatch.setattr(acs.constraint, "in_eclipse", lambda ra, dec, time: False)

        charging_slew = Mock()
        charging_slew.obstype = "CHARGE"
        charging_slew.is_slewing = Mock(return_value=False)

        acs.current_slew = None
        acs.last_slew = charging_slew
        acs.saa = None

        mode = acs.get_mode(1000.0)
        assert mode == ACSMode.CHARGING

    def test_determine_mode_science(
        self, mock_config: MissionConfig, mock_ephem: Mock
    ) -> None:
        from conops import ACS, Constraint

        constraint = Constraint(ephem=None)
        constraint.ephem = mock_ephem
        mock_config.constraint = constraint
        acs = ACS(config=mock_config)

        acs.current_slew = None
        acs.saa = None

        mode = acs.get_mode(1000.0)
        assert mode == ACSMode.SCIENCE


class TestHandlePassMode:
    """Test _handle_pass_mode helper method."""

    def test_handle_pass_terminates_ppt_end_time_set(
        self, queue_ditl: QueueDITL
    ) -> None:
        mock_ppt = Mock()
        mock_ppt.end = 0
        mock_ppt.done = False
        queue_ditl.ppt = mock_ppt
        queue_ditl._handle_pass_mode(1000.0)
        assert mock_ppt.end == 1000.0

    def test_handle_pass_terminates_ppt_done_flag_set(
        self, queue_ditl: QueueDITL
    ) -> None:
        mock_ppt = Mock()
        mock_ppt.end = 0
        mock_ppt.done = False
        queue_ditl.ppt = mock_ppt
        queue_ditl._handle_pass_mode(1000.0)
        assert mock_ppt.done is True

    def test_handle_pass_terminates_ppt_cleared(self, queue_ditl: QueueDITL) -> None:
        mock_ppt = Mock()
        mock_ppt.end = 0
        mock_ppt.done = False
        queue_ditl.ppt = mock_ppt
        queue_ditl._handle_pass_mode(1000.0)
        assert queue_ditl.ppt is None

    def test_handle_pass_terminates_charging_ppt_end_time_set(
        self, queue_ditl: QueueDITL
    ) -> None:
        mock_charging = Mock()
        mock_charging.end = 0
        mock_charging.done = False
        queue_ditl.charging_ppt = mock_charging
        queue_ditl._handle_pass_mode(1000.0)
        assert mock_charging.end == 1000.0

    def test_handle_pass_terminates_charging_ppt_done_set(
        self, queue_ditl: QueueDITL
    ) -> None:
        mock_charging = Mock()
        mock_charging.end = 0
        mock_charging.done = False
        queue_ditl.charging_ppt = mock_charging
        queue_ditl._handle_pass_mode(1000.0)
        assert mock_charging.done is True

    def test_handle_pass_terminates_charging_ppt_cleared(
        self, queue_ditl: QueueDITL
    ) -> None:
        mock_charging = Mock()
        mock_charging.end = 0
        mock_charging.done = False
        queue_ditl.charging_ppt = mock_charging
        queue_ditl._handle_pass_mode(1000.0)
        assert queue_ditl.charging_ppt is None

    def test_handle_pass_no_ppt(self, queue_ditl: QueueDITL) -> None:
        queue_ditl.ppt = None
        queue_ditl.charging_ppt = None
        queue_ditl._handle_pass_mode(1000.0)


class TestHandleChargingMode:
    """Test _handle_charging_mode helper method."""

    def test_charging_ends_when_battery_recharged_end_set(
        self, queue_ditl: QueueDITL, capsys: pytest.CaptureFixture[str]
    ) -> None:
        cast(Mock, queue_ditl.battery).battery_alert = False
        cast(Mock, queue_ditl.battery).battery_level = 0.85
        mock_charging = Mock()
        mock_charging.end = 0
        mock_charging.done = False
        mock_charging.obsid = 999001  # Add obsid attribute
        queue_ditl.charging_ppt = mock_charging
        queue_ditl._handle_charging_mode(1000.0)
        assert mock_charging.end == 1000.0

    def test_charging_ends_when_battery_recharged_done_flag(
        self, queue_ditl: QueueDITL, capsys: pytest.CaptureFixture[str]
    ) -> None:
        cast(Mock, queue_ditl.battery).battery_alert = False
        cast(Mock, queue_ditl.battery).battery_level = 0.85
        mock_charging = Mock()
        mock_charging.end = 0
        mock_charging.done = False
        mock_charging.obsid = 999001  # Add obsid attribute
        queue_ditl.charging_ppt = mock_charging
        queue_ditl._handle_charging_mode(1000.0)
        assert mock_charging.done is True

    def test_charging_ends_when_battery_recharged_clears_charging_ppt(
        self, queue_ditl: QueueDITL, capsys: pytest.CaptureFixture[str]
    ) -> None:
        cast(Mock, queue_ditl.battery).battery_alert = False
        cast(Mock, queue_ditl.battery).battery_level = 0.85
        mock_charging = Mock()
        mock_charging.end = 0
        mock_charging.done = False
        mock_charging.obsid = 999001  # Add obsid attribute
        queue_ditl.charging_ppt = mock_charging
        queue_ditl._handle_charging_mode(1000.0)
        assert queue_ditl.charging_ppt is None
        # Check the log instead of print output
        log_text = "\n".join(event.description for event in queue_ditl.log.events)
        assert "Battery recharged" in log_text

    def test_charging_ends_when_constrained_end_and_done_set(
        self, queue_ditl: QueueDITL, capsys: pytest.CaptureFixture[str]
    ) -> None:
        cast(Mock, queue_ditl.battery).battery_alert = True
        mock_charging = Mock()
        mock_charging.ra = 10.0
        mock_charging.dec = 20.0
        mock_charging.end = 0
        mock_charging.done = False
        mock_charging.obsid = 999001  # Add obsid attribute
        queue_ditl.charging_ppt = mock_charging
        cast(Mock, queue_ditl.constraint).in_constraint = Mock(return_value=True)
        queue_ditl._handle_charging_mode(1000.0)
        assert mock_charging.end == 1000.0
        assert mock_charging.done is True
        assert queue_ditl.charging_ppt is None
        # Check the log instead of print output
        log_text = "\n".join(event.description for event in queue_ditl.log.events)
        assert "Charging pointing constrained" in log_text

    def test_charging_ends_in_eclipse_clears_charging(
        self, queue_ditl: QueueDITL, capsys: pytest.CaptureFixture[str]
    ) -> None:
        cast(Mock, queue_ditl.battery).battery_alert = True
        mock_charging = Mock()
        mock_charging.ra = 10.0
        mock_charging.dec = 20.0
        mock_charging.obsid = 999001  # Add obsid attribute
        queue_ditl.charging_ppt = mock_charging
        cast(Mock, queue_ditl.emergency_charging)._is_in_sunlight = Mock(
            return_value=False
        )
        queue_ditl._handle_charging_mode(1000.0)
        assert queue_ditl.charging_ppt is None
        # Check the log instead of print output
        log_text = "\n".join(event.description for event in queue_ditl.log.events)
        assert "Entered eclipse" in log_text

    def test_charging_continues(self, queue_ditl: QueueDITL) -> None:
        cast(Mock, queue_ditl.battery).battery_alert = True
        mock_charging = Mock()
        mock_charging.ra = 10.0
        mock_charging.dec = 20.0
        queue_ditl.charging_ppt = mock_charging
        cast(Mock, queue_ditl.emergency_charging)._is_in_sunlight = Mock(
            return_value=True
        )
        queue_ditl._handle_charging_mode(1000.0)
        assert queue_ditl.charging_ppt is mock_charging


class TestManagePPTLifecycle:
    """Test _manage_ppt_lifecycle helper method."""

    def test_manage_ppt_science_mode_exposure_decrements(
        self, queue_ditl: QueueDITL
    ) -> None:
        mock_ppt = Mock()
        mock_ppt.exptime = 300.0
        mock_ppt.ra = 10.0
        mock_ppt.dec = 20.0
        mock_ppt.end = 2000.0
        queue_ditl.ppt = mock_ppt
        queue_ditl.charging_ppt = None
        queue_ditl.step_size = 60
        queue_ditl._manage_ppt_lifecycle(1000.0, ACSMode.SCIENCE)
        assert mock_ppt.exptime == 240.0
        assert queue_ditl.ppt is mock_ppt

    def test_manage_ppt_slewing_no_exptime_decrement(
        self, queue_ditl: QueueDITL
    ) -> None:
        mock_ppt = Mock()
        mock_ppt.exptime = 300.0
        mock_ppt.ra = 10.0
        mock_ppt.dec = 20.0
        mock_ppt.end = 2000.0
        mock_ppt.obsid = 1001
        queue_ditl.ppt = mock_ppt
        queue_ditl.charging_ppt = None
        cast(Mock, queue_ditl.constraint).in_constraint = Mock(return_value=True)
        queue_ditl._manage_ppt_lifecycle(1000.0, ACSMode.SLEWING)
        assert mock_ppt.exptime == 300.0
        assert queue_ditl.ppt is mock_ppt
        cast(Mock, queue_ditl.constraint).in_constraint.assert_not_called()

    def test_manage_ppt_becomes_constrained_terminates(
        self, queue_ditl: QueueDITL
    ) -> None:
        mock_ppt = Mock()
        mock_ppt.exptime = 300.0
        mock_ppt.ra = 10.0
        mock_ppt.dec = 20.0
        mock_ppt.end = 2000.0
        mock_ppt.obsid = 1001  # Add obsid attribute
        queue_ditl.ppt = mock_ppt
        queue_ditl.charging_ppt = None
        cast(Mock, queue_ditl.constraint).in_constraint = Mock(return_value=True)
        queue_ditl._manage_ppt_lifecycle(1000.0, ACSMode.SCIENCE)
        assert queue_ditl.ppt is None

    def test_manage_ppt_exposure_complete_terminates(
        self, queue_ditl: QueueDITL
    ) -> None:
        mock_ppt = Mock()
        mock_ppt.exptime = 30.0
        mock_ppt.ra = 10.0
        mock_ppt.dec = 20.0
        mock_ppt.end = 2000.0
        mock_ppt.done = False
        mock_ppt.obsid = 1001  # Add obsid attribute
        queue_ditl.ppt = mock_ppt
        queue_ditl.charging_ppt = None
        queue_ditl.step_size = 60
        queue_ditl._manage_ppt_lifecycle(1000.0, ACSMode.SCIENCE)
        assert queue_ditl.ppt is None
        assert mock_ppt.done is True

    def test_manage_ppt_time_window_elapsed_terminate(
        self, queue_ditl: QueueDITL
    ) -> None:
        mock_ppt = Mock()
        mock_ppt.exptime = 300.0
        mock_ppt.ra = 10.0
        mock_ppt.dec = 20.0
        mock_ppt.end = 500.0
        mock_ppt.obsid = 1001  # Add obsid attribute
        queue_ditl.ppt = mock_ppt
        queue_ditl.charging_ppt = None
        queue_ditl._manage_ppt_lifecycle(1000.0, ACSMode.SCIENCE)
        assert queue_ditl.ppt is None

    def test_manage_ppt_charging_ppt_ignored(self, queue_ditl: QueueDITL) -> None:
        mock_charging = Mock()
        mock_charging.exptime = 300.0
        queue_ditl.ppt = mock_charging
        queue_ditl.charging_ppt = mock_charging
        queue_ditl._manage_ppt_lifecycle(1000.0, ACSMode.SCIENCE)
        assert mock_charging.exptime == 300.0


class TestFetchNewPPT:
    """Test _fetch_new_ppt helper method."""

    def test_fetch_ppt_sets_ppt_and_returns_last_positions(
        self, queue_ditl: QueueDITL, capsys: pytest.CaptureFixture[str]
    ) -> None:
        mock_ppt = Mock()
        mock_ppt.ra = 45.0
        mock_ppt.dec = 30.0
        mock_ppt.obsid = 1001
        mock_ppt.next_vis = Mock(return_value=1000.0)
        mock_ppt.ss_max = 3600.0
        mock_ppt.ss_min = 300.0
        mock_ppt.windows = [[0.0, 1e12]]
        cast(Mock, queue_ditl.queue).get = Mock(return_value=mock_ppt)
        queue_ditl._fetch_new_ppt(1000.0, 10.0, 20.0)
        assert queue_ditl.ppt is mock_ppt
        cast(Mock, queue_ditl.queue).get.assert_called_once_with(
            10.0,
            20.0,
            1000.0,
        )

    def test_fetch_ppt_enqueues_slew_command(
        self, queue_ditl: QueueDITL, capsys: pytest.CaptureFixture[str]
    ) -> None:
        mock_ppt = Mock()
        mock_ppt.ra = 45.0
        mock_ppt.dec = 30.0
        mock_ppt.obsid = 1001
        mock_ppt.next_vis = Mock(return_value=1000.0)
        mock_ppt.ss_max = 3600.0
        mock_ppt.ss_min = 300.0
        mock_ppt.windows = [[0.0, 1e12]]
        cast(Mock, queue_ditl.queue).get = Mock(return_value=mock_ppt)
        queue_ditl._fetch_new_ppt(1000.0, 10.0, 20.0)
        cast(Mock, queue_ditl.acs.enqueue_command).assert_called_once()
        call_args = cast(Mock, queue_ditl.acs.enqueue_command).call_args
        command = call_args[0][0]
        assert command.command_type == ACSCommandType.SLEW_TO_TARGET
        assert command.slew.endra == 45.0
        assert command.slew.enddec == 30.0
        assert command.slew.obsid == 1001

    def test_fetch_ppt_prints_messages(
        self, queue_ditl: QueueDITL, capsys: pytest.CaptureFixture[str]
    ) -> None:
        mock_ppt = Mock()
        mock_ppt.ra = 45.0
        mock_ppt.dec = 30.0
        mock_ppt.obsid = 1001
        mock_ppt.next_vis = Mock(return_value=1000.0)
        mock_ppt.ss_max = 3600.0
        mock_ppt.ss_min = 300.0
        mock_ppt.windows = [[0.0, 1e12]]
        cast(Mock, queue_ditl.queue).get = Mock(return_value=mock_ppt)
        queue_ditl._fetch_new_ppt(1000.0, 10.0, 20.0)
        # Check the log instead of print output
        log_text = "\n".join(event.description for event in queue_ditl.log.events)
        assert "Fetching new PPT from Queue" in log_text

    def test_fetch_ppt_none_available(
        self, queue_ditl: QueueDITL, capsys: pytest.CaptureFixture[str]
    ) -> None:
        cast(Mock, queue_ditl.queue).get = Mock(return_value=None)
        queue_ditl._fetch_new_ppt(1000.0, 10.0, 20.0)
        assert queue_ditl.ppt is None
        # Check the log instead of print output
        log_text = "\n".join(event.description for event in queue_ditl.log.events)
        assert "No targets available from Queue" in log_text

    def test_fetch_ppt_defers_during_active_pass(self, queue_ditl: QueueDITL) -> None:
        """Test that _fetch_new_ppt returns early when a pass is in progress."""
        mock_pass = Mock()
        cast(Mock, queue_ditl.acs.passrequests).current_pass = Mock(
            return_value=mock_pass
        )
        queue_ditl._fetch_new_ppt(1000.0, 10.0, 20.0)

        # PPT should not be set
        assert queue_ditl.ppt is None
        # Queue should not be queried
        cast(Mock, queue_ditl.queue.get).assert_not_called()
        # No slew command should be enqueued
        cast(Mock, queue_ditl.acs.enqueue_command).assert_not_called()
        # Log should indicate deferral
        log_text = "\n".join(event.description for event in queue_ditl.log.events)
        assert "Deferring PPT fetch - pass in progress" in log_text

    def test_fetch_ppt_rejects_slew_execution_during_pass(
        self, queue_ditl: QueueDITL
    ) -> None:
        """Test slew rejection when execution time falls during a pass."""
        # Setup mock PPT
        mock_ppt = Mock()
        mock_ppt.ra = 45.0
        mock_ppt.dec = 30.0
        mock_ppt.obsid = 1001
        mock_ppt.next_vis = Mock(return_value=1000.0)
        mock_ppt.ss_max = 3600.0
        mock_ppt.ss_min = 100.0
        cast(Mock, queue_ditl.queue).get = Mock(return_value=mock_ppt)

        # Mock that execution time falls during a pass
        # First call returns None (initial check), second call returns a pass (execution time check)
        cast(Mock, queue_ditl.acs.passrequests).current_pass = Mock(
            side_effect=[None, Mock()]
        )

        queue_ditl._fetch_new_ppt(1000.0, 10.0, 20.0)

        # PPT should be cleared
        assert queue_ditl.ppt is None
        # No command should be enqueued
        cast(Mock, queue_ditl.acs.enqueue_command).assert_not_called()
        # Log should indicate rejection
        log_text = "\n".join(event.description for event in queue_ditl.log.events)
        assert "Slew rejected - execution time falls during a pass" in log_text

    def test_fetch_ppt_rejects_slew_completion_during_pass(
        self, queue_ditl: QueueDITL
    ) -> None:
        """Test slew rejection when slew would complete during a pass."""
        # Setup mock PPT
        mock_ppt = Mock()
        mock_ppt.ra = 45.0
        mock_ppt.dec = 30.0
        mock_ppt.obsid = 1001
        mock_ppt.next_vis = Mock(return_value=1000.0)
        mock_ppt.ss_max = 3600.0
        mock_ppt.ss_min = 100.0
        cast(Mock, queue_ditl.queue).get = Mock(return_value=mock_ppt)

        # No pass at current time or execution time, but pass during slew completion
        def current_pass_check(time: float) -> Mock | None:
            if time < 1050.0:  # Before slew completes
                return None
            else:  # Slew completion time
                return Mock()  # Pass is active when slew would complete

        cast(Mock, queue_ditl.acs.passrequests).current_pass = Mock(
            side_effect=current_pass_check
        )

        queue_ditl._fetch_new_ppt(1000.0, 10.0, 20.0)

        # PPT should be cleared
        assert queue_ditl.ppt is None
        # No command should be enqueued
        cast(Mock, queue_ditl.acs.enqueue_command).assert_not_called()
        # Log should indicate rejection
        log_text = "\n".join(event.description for event in queue_ditl.log.events)
        assert "Slew rejected - would complete during a pass" in log_text

    def test_fetch_ppt_rejects_insufficient_observation_time(
        self, queue_ditl: QueueDITL
    ) -> None:
        """Test target rejection when there's not enough time before next pass."""
        queue_ditl.ephem.step_size = 60
        # Setup mock PPT with minimum observation time requirement
        mock_ppt = Mock()
        mock_ppt.ra = 45.0
        mock_ppt.dec = 30.0
        mock_ppt.obsid = 1001
        mock_ppt.next_vis = Mock(return_value=1000.0)
        mock_ppt.ss_max = 3600.0
        mock_ppt.ss_min = 500.0  # Requires 500 seconds
        mock_ppt.windows = [[0.0, 1e12]]
        cast(Mock, queue_ditl.queue).get = Mock(return_value=mock_ppt)
        queue_ditl.queue.targets = [mock_ppt]

        # No current pass
        cast(Mock, queue_ditl.acs.passrequests).current_pass = Mock(return_value=None)

        # Mock a pass that starts too soon
        mock_next_pass = Mock()
        mock_next_pass.begin = 1200.0  # Pass begins in 200 seconds
        mock_next_pass.gsstartra = 100.0
        mock_next_pass.gsstartdec = 50.0
        cast(Mock, queue_ditl.acs.passrequests).next_pass = Mock(
            return_value=mock_next_pass
        )

        queue_ditl._fetch_new_ppt(1000.0, 10.0, 20.0)

        # PPT should be cleared
        assert queue_ditl.ppt is None
        # No command should be enqueued
        cast(Mock, queue_ditl.acs.enqueue_command).assert_not_called()
        # Log should indicate rejection with available time
        log_text = "\n".join(event.description for event in queue_ditl.log.events)
        assert "rejected - only" in log_text
        assert "available before pass" in log_text
        assert str(mock_ppt.obsid) in log_text

    def test_fetch_ppt_rejects_when_pass_slew_buffer_consumes_minimum_collect(
        self, queue_ditl: QueueDITL
    ) -> None:
        """Pass admission should include the early trigger used by pass slews."""
        queue_ditl.ephem.step_size = 60

        mock_ppt = Mock()
        mock_ppt.ra = 45.0
        mock_ppt.dec = 30.0
        mock_ppt.obsid = 1001
        mock_ppt.next_vis = Mock(return_value=1000.0)
        mock_ppt.ss_max = 3600.0
        mock_ppt.ss_min = 200.0
        mock_ppt.windows = [[0.0, 1e12]]
        cast(Mock, queue_ditl.queue).get = Mock(return_value=mock_ppt)
        queue_ditl.queue.targets = [mock_ppt]

        cast(Mock, queue_ditl.acs.passrequests).current_pass = Mock(return_value=None)

        mock_next_pass = Mock()
        mock_next_pass.begin = 1450.0
        mock_next_pass.gsstartra = 100.0
        mock_next_pass.gsstartdec = 50.0
        cast(Mock, queue_ditl.acs.passrequests).next_pass = Mock(
            return_value=mock_next_pass
        )

        queue_ditl._fetch_new_ppt(1000.0, 10.0, 20.0)

        assert queue_ditl.ppt is None
        cast(Mock, queue_ditl.acs.enqueue_command).assert_not_called()
        log_text = "\n".join(event.description for event in queue_ditl.log.events)
        assert "rejected - only 130s available before pass" in log_text

    def test_fetch_ppt_accepts_with_sufficient_observation_time(
        self, queue_ditl
    ) -> None:
        """Test target acceptance when there's enough time before next pass."""
        queue_ditl.ephem.step_size = 60
        # Setup mock PPT
        mock_ppt = Mock()
        mock_ppt.ra = 45.0
        mock_ppt.dec = 30.0
        mock_ppt.obsid = 1001
        mock_ppt.next_vis = Mock(return_value=1000.0)
        mock_ppt.ss_max = 3600.0
        mock_ppt.ss_min = 100.0  # Requires 100 seconds
        mock_ppt.windows = [[0.0, 1e12]]
        cast(Mock, queue_ditl.queue).get = Mock(return_value=mock_ppt)

        # No current pass
        cast(Mock, queue_ditl.acs.passrequests).current_pass = Mock(return_value=None)

        # Mock a pass with plenty of time
        mock_next_pass = Mock()
        mock_next_pass.begin = 2000.0  # Pass begins in 1000 seconds
        mock_next_pass.gsstartra = 100.0
        mock_next_pass.gsstartdec = 50.0
        cast(Mock, queue_ditl.acs.passrequests).next_pass = Mock(
            return_value=mock_next_pass
        )

        queue_ditl._fetch_new_ppt(1000.0, 10.0, 20.0)

        # PPT should be set
        assert queue_ditl.ppt is mock_ppt
        # Command should be enqueued
        cast(Mock, queue_ditl.acs.enqueue_command).assert_called_once()

    def test_fetch_ppt_retries_when_top_target_cannot_collect(
        self, queue_ditl: QueueDITL
    ) -> None:
        """Reject an infeasible top target and commit the next feasible target."""
        queue_ditl.ephem.step_size = 60
        bad_ppt = Mock()
        bad_ppt.ra = 45.0
        bad_ppt.dec = 30.0
        bad_ppt.obsid = 1001
        bad_ppt.done = False
        bad_ppt.windows = []
        bad_ppt.visible = Mock(return_value=[1000.0, 5000.0])
        bad_ppt.next_vis = Mock(return_value=1000.0)
        bad_ppt.ss_max = 3600.0
        bad_ppt.ss_min = 300.0

        good_ppt = Mock()
        good_ppt.ra = 46.0
        good_ppt.dec = 31.0
        good_ppt.obsid = 1002
        good_ppt.done = False
        good_ppt.windows = []
        good_ppt.visible = Mock(return_value=[1000.0, 5000.0])
        good_ppt.next_vis = Mock(return_value=1000.0)
        good_ppt.ss_max = 3600.0
        good_ppt.ss_min = 30.0

        targets = [bad_ppt, good_ppt]
        queue_ditl.queue.targets = targets

        def get_next_not_done(ra: float, dec: float, utime: float) -> Mock | None:
            return next((target for target in targets if not target.done), None)

        cast(Mock, queue_ditl.queue).get = Mock(side_effect=get_next_not_done)
        cast(Mock, queue_ditl.acs.passrequests).current_pass = Mock(return_value=None)

        mock_next_pass = Mock()
        mock_next_pass.begin = 1400.0
        mock_next_pass.gsstartra = 100.0
        mock_next_pass.gsstartdec = 50.0
        cast(Mock, queue_ditl.acs.passrequests).next_pass = Mock(
            return_value=mock_next_pass
        )

        queue_ditl._fetch_new_ppt(1000.0, 10.0, 20.0)

        assert queue_ditl.ppt is good_ppt
        assert bad_ppt.done is False
        cast(Mock, queue_ditl.acs.enqueue_command).assert_called_once()
        command = cast(Mock, queue_ditl.acs.enqueue_command).call_args[0][0]
        assert command.slew.obsid == good_ppt.obsid

        log_text = "\n".join(event.description for event in queue_ditl.log.events)
        assert "Target 1001 rejected" in log_text
        assert "available before pass" in log_text

    def test_fetch_ppt_rejects_when_locked_roll_violates_constraint_in_window(
        self, queue_ditl
    ) -> None:
        """Locked roll that violates a constraint inside the ss_min window skips target.

        Expected outcome:
        - No slew command enqueued
        - ppt cleared (None)
        - _ppt_unavailable set to True
        - log event describing the locked-roll violation emitted
        """
        mock_ppt = Mock()
        mock_ppt.ra = 45.0
        mock_ppt.dec = 30.0
        mock_ppt.obsid = 1001
        mock_ppt.next_vis = Mock(return_value=1000.0)
        mock_ppt.ss_max = 3600.0
        mock_ppt.ss_min = 300.0
        mock_ppt.windows = [[0.0, 1e12]]
        cast(Mock, queue_ditl.queue).get = Mock(return_value=mock_ppt)

        # No blocking pass
        cast(Mock, queue_ditl.acs.passrequests).current_pass = Mock(return_value=None)
        cast(Mock, queue_ditl.acs.passrequests).next_pass = Mock(return_value=None)

        # Constraint reports a violation for every timestamp in the window
        queue_ditl.constraint.in_constraint = Mock(return_value=True)

        queue_ditl._fetch_new_ppt(1000.0, 10.0, 20.0)

        # No slew should be enqueued
        cast(Mock, queue_ditl.acs.enqueue_command).assert_not_called()
        # PPT should be cleared
        assert queue_ditl.ppt is None
        # Unavailable flag should be set so the caller does not retry immediately
        assert queue_ditl._ppt_unavailable is True
        # A log event describing the locked-roll rejection should have been emitted
        log_text = "\n".join(event.description for event in queue_ditl.log.events)
        assert "locked roll" in log_text
        assert str(mock_ppt.obsid) in log_text

    def test_fetch_ppt_accepts_when_locked_roll_satisfies_constraint_in_window(
        self, queue_ditl
    ) -> None:
        """Target is accepted when locked roll clears all constraints across ss_min window."""
        mock_ppt = Mock()
        mock_ppt.ra = 45.0
        mock_ppt.dec = 30.0
        mock_ppt.obsid = 1002
        mock_ppt.next_vis = Mock(return_value=1000.0)
        mock_ppt.ss_max = 3600.0
        mock_ppt.ss_min = 300.0
        mock_ppt.windows = [[0.0, 1e12]]
        cast(Mock, queue_ditl.queue).get = Mock(return_value=mock_ppt)

        # No blocking pass
        cast(Mock, queue_ditl.acs.passrequests).current_pass = Mock(return_value=None)
        cast(Mock, queue_ditl.acs.passrequests).next_pass = Mock(return_value=None)

        # Constraint reports no violation (default for the fixture, but explicit here)
        queue_ditl.constraint.in_constraint = Mock(return_value=False)

        queue_ditl._fetch_new_ppt(1000.0, 10.0, 20.0)

        assert queue_ditl.ppt is mock_ppt
        cast(Mock, queue_ditl.acs.enqueue_command).assert_called_once()


class TestRecordSpacecraftState:
    """Test _record_spacecraft_state helper method."""

    def test_record_state_mode(self, queue_ditl) -> None:
        queue_ditl.utime = [1000.0, 1060.0, 1120.0]
        queue_ditl._record_pointing_data(
            ra=45.0,
            dec=30.0,
            roll=15.0,
            obsid=1001,
            mode=ACSMode.SCIENCE,
        )
        assert queue_ditl.mode == [ACSMode.SCIENCE]

    def test_record_state_ra(self, queue_ditl) -> None:
        queue_ditl.utime = [1000.0, 1060.0, 1120.0]
        queue_ditl._record_pointing_data(
            ra=45.0,
            dec=30.0,
            roll=15.0,
            obsid=1001,
            mode=ACSMode.SCIENCE,
        )
        assert queue_ditl.ra == [45.0]

    def test_record_state_dec(self, queue_ditl) -> None:
        queue_ditl.utime = [1000.0, 1060.0, 1120.0]
        queue_ditl._record_pointing_data(
            ra=45.0,
            dec=30.0,
            roll=15.0,
            obsid=1001,
            mode=ACSMode.SCIENCE,
        )
        assert queue_ditl.dec == [30.0]

    def test_record_state_roll(self, queue_ditl) -> None:
        queue_ditl.utime = [1000.0, 1060.0, 1120.0]
        queue_ditl._record_pointing_data(
            ra=45.0,
            dec=30.0,
            roll=15.0,
            obsid=1001,
            mode=ACSMode.SCIENCE,
        )
        assert queue_ditl.roll == [15.0]

    def test_record_state_obsid(self, queue_ditl) -> None:
        queue_ditl.utime = [1000.0, 1060.0, 1120.0]
        queue_ditl._record_pointing_data(
            ra=45.0,
            dec=30.0,
            roll=15.0,
            obsid=1001,
            mode=ACSMode.SCIENCE,
        )
        assert queue_ditl.obsid == [1001]

    def test_record_state_panel_length(self, queue_ditl) -> None:
        queue_ditl.utime = [1000.0, 1060.0, 1120.0]
        queue_ditl._record_power_data(
            i=0,
            utime=1000.0,
            ra=45.0,
            dec=30.0,
            roll=0,
            mode=ACSMode.SCIENCE,
            in_eclipse=False,
        )
        assert len(queue_ditl.panel) == 1

    def test_record_state_power_length(self, queue_ditl) -> None:
        queue_ditl.utime = [1000.0, 1060.0, 1120.0]
        queue_ditl._record_power_data(
            i=0,
            utime=1000.0,
            ra=45.0,
            dec=30.0,
            roll=0,
            mode=ACSMode.SCIENCE,
            in_eclipse=False,
        )
        assert len(queue_ditl.power) == 1

    def test_record_state_panel_power_length(self, queue_ditl) -> None:
        queue_ditl.utime = [1000.0, 1060.0, 1120.0]
        queue_ditl._record_power_data(
            i=0,
            utime=1000.0,
            ra=45.0,
            dec=30.0,
            roll=0,
            mode=ACSMode.SCIENCE,
            in_eclipse=False,
        )
        assert len(queue_ditl.panel_power) == 1

    def test_record_state_batterylevel_length(self, queue_ditl) -> None:
        queue_ditl.utime = [1000.0, 1060.0, 1120.0]
        queue_ditl._record_power_data(
            i=0,
            utime=1000.0,
            ra=45.0,
            dec=30.0,
            roll=0,
            mode=ACSMode.SCIENCE,
            in_eclipse=False,
        )
        assert len(queue_ditl.batterylevel) == 1

    def test_record_state_spacecraft_power_call(self, queue_ditl) -> None:
        queue_ditl.utime = [1000.0]
        queue_ditl.spacecraft_bus.power = Mock(return_value=50.0)
        queue_ditl.payload.power = Mock(return_value=30.0)
        queue_ditl.acs.solar_panel.power = Mock(return_value=100.0)
        queue_ditl.battery.battery_level = 0.75
        queue_ditl.step_size = 60
        queue_ditl._record_power_data(
            i=0,
            utime=1000.0,
            ra=0.0,
            dec=0.0,
            roll=0.0,
            mode=ACSMode.SCIENCE,
            in_eclipse=False,
        )
        queue_ditl.spacecraft_bus.power.assert_called_once_with(
            mode=ACSMode.SCIENCE, in_eclipse=False
        )

    def test_record_state_payload_power_call(self, queue_ditl) -> None:
        queue_ditl.utime = [1000.0]
        queue_ditl.spacecraft_bus.power = Mock(return_value=50.0)
        queue_ditl.payload.power = Mock(return_value=30.0)
        queue_ditl.acs.solar_panel.power = Mock(return_value=100.0)
        queue_ditl.battery.battery_level = 0.75
        queue_ditl.step_size = 60
        queue_ditl._record_power_data(
            i=0,
            utime=1000.0,
            ra=0.0,
            dec=0.0,
            roll=0.0,
            mode=ACSMode.SCIENCE,
            in_eclipse=False,
        )
        queue_ditl.payload.power.assert_called_once_with(
            mode=ACSMode.SCIENCE, in_eclipse=False
        )

    def test_record_state_power_sum(self, queue_ditl) -> None:
        queue_ditl.utime = [1000.0]
        queue_ditl.spacecraft_bus.power = Mock(return_value=50.0)
        queue_ditl.payload.power = Mock(return_value=30.0)
        queue_ditl.acs.solar_panel.power = Mock(return_value=100.0)
        queue_ditl.battery.battery_level = 0.75
        queue_ditl.step_size = 60
        queue_ditl._record_power_data(
            i=0,
            utime=1000.0,
            ra=0.0,
            dec=0.0,
            roll=0.0,
            mode=ACSMode.SCIENCE,
            in_eclipse=False,
        )
        assert queue_ditl.power == [80.0]  # 50 + 30

    def test_record_state_battery_drain_called(self, queue_ditl) -> None:
        queue_ditl.utime = [1000.0]
        queue_ditl.spacecraft_bus.power = Mock(return_value=50.0)
        queue_ditl.payload.power = Mock(return_value=30.0)
        queue_ditl.acs.solar_panel.power = Mock(return_value=100.0)
        queue_ditl.battery.battery_level = 0.75
        queue_ditl.step_size = 60
        queue_ditl._record_power_data(
            i=0,
            utime=1000.0,
            ra=0.0,
            dec=0.0,
            roll=0.0,
            mode=ACSMode.SCIENCE,
            in_eclipse=False,
        )
        queue_ditl.battery.drain.assert_called_once_with(80.0, 60)

    def test_record_state_battery_charge_called(self, queue_ditl) -> None:
        queue_ditl.utime = [1000.0]
        queue_ditl.spacecraft_bus.power = Mock(return_value=50.0)
        queue_ditl.payload.power = Mock(return_value=30.0)
        queue_ditl.acs.solar_panel.power = Mock(return_value=100.0)
        queue_ditl.battery.battery_level = 0.75
        queue_ditl.step_size = 60
        queue_ditl._record_power_data(
            i=0,
            utime=1000.0,
            ra=0.0,
            dec=0.0,
            roll=0.0,
            mode=ACSMode.SCIENCE,
            in_eclipse=False,
        )
        queue_ditl.battery.charge.assert_called_once_with(100.0, 60)


class TestCalcMethod:
    """Test main calc method integration."""

    def test_calc_requires_ephemeris(self, queue_ditl) -> None:
        queue_ditl.ephem = None
        with pytest.raises(AssertionError, match="Ephemeris must be set"):
            queue_ditl.calc()

    def test_calc_basic_success_return(self, queue_ditl) -> None:
        queue_ditl.year = 2018
        queue_ditl.day = 331
        queue_ditl.length = 1
        queue_ditl.step_size = 3600
        result = queue_ditl.calc()
        assert result is True

    def test_calc_basic_success_mode_and_pointing_length(self, queue_ditl) -> None:
        queue_ditl.year = 2018
        queue_ditl.day = 331
        queue_ditl.length = 1
        queue_ditl.step_size = 3600  # 1 hour steps for faster test
        queue_ditl.calc()
        assert len(queue_ditl.mode) == 24
        assert len(queue_ditl.ra) == 24
        assert len(queue_ditl.dec) == 24

    def test_calc_sets_acs_ephemeris(self, queue_ditl) -> None:
        queue_ditl.acs.ephem = None
        queue_ditl.year = 2018
        queue_ditl.day = 331
        queue_ditl.length = 1
        queue_ditl.step_size = 3600
        queue_ditl.calc()
        assert queue_ditl.acs.ephem is queue_ditl.ephem

    def test_calc_tracks_ppt_in_plan(self, queue_ditl) -> None:
        queue_ditl.year = 2018
        queue_ditl.day = 331
        queue_ditl.length = 1
        queue_ditl.step_size = 3600

        mock_ppt = Mock()
        mock_ppt.ra = 45.0
        mock_ppt.dec = 30.0
        mock_ppt.obsid = 1001
        mock_ppt.exptime = 7200.0
        mock_ppt.begin = 1543622400
        mock_ppt.end = 1543629600
        mock_ppt.done = False
        mock_ppt.next_vis = Mock(return_value=1543276800.0)
        mock_ppt.ss_max = 3600.0
        mock_ppt.ss_min = 300.0
        mock_ppt.windows = [[0.0, 1e12]]
        mock_ppt.copy = Mock(return_value=Mock())
        mock_ppt.copy.return_value.begin = 1543622400
        mock_ppt.copy.return_value.end = 1543629600
        mock_ppt.copy.return_value.obstype = "PPT"

        queue_ditl.queue.get = Mock(side_effect=[mock_ppt] + [None] * 1500)
        queue_ditl.calc()

        assert len(queue_ditl.plan) > 0

    def test_calc_handles_pass_mode_result_true(self, queue_ditl) -> None:
        queue_ditl.year = 2018
        queue_ditl.day = 331
        queue_ditl.length = 1
        queue_ditl.step_size = 3600
        queue_ditl.acs.get_mode = Mock(return_value=ACSMode.PASS)
        result = queue_ditl.calc()
        assert result is True

    def test_calc_handles_pass_mode_contains_pass(self, queue_ditl) -> None:
        queue_ditl.year = 2018
        queue_ditl.day = 331
        queue_ditl.length = 1
        queue_ditl.step_size = 3600
        queue_ditl.acs.get_mode = Mock(return_value=ACSMode.PASS)
        queue_ditl.calc()
        assert ACSMode.PASS in queue_ditl.mode

    def test_calc_handles_emergency_charging_initiates(self, queue_ditl) -> None:
        queue_ditl.year = 2018
        queue_ditl.day = 331
        queue_ditl.length = 1
        queue_ditl.step_size = 3600
        queue_ditl.battery.battery_alert = True
        mock_charging = Mock()
        mock_charging.ra = 100.0
        mock_charging.dec = 50.0
        mock_charging.obsid = 999001
        mock_charging.roll = 0.0
        mock_charging.begin = 1543622400
        mock_charging.end = 1543622400 + 86400
        mock_charging.copy = Mock(return_value=Mock())
        mock_charging.copy.return_value.begin = 1543622400
        mock_charging.copy.return_value.end = 1543622400 + 86400
        queue_ditl.emergency_charging.should_initiate_charging = Mock(return_value=True)
        queue_ditl.emergency_charging.initiate_emergency_charging = Mock(
            return_value=mock_charging
        )
        queue_ditl.acs.enqueue_command = Mock()
        result = queue_ditl.calc()
        assert result is True
        assert queue_ditl.emergency_charging.initiate_emergency_charging.called

    def test_calc_handles_emergency_charging_enqueue_command_and_type(
        self, queue_ditl
    ) -> None:
        queue_ditl.year = 2018
        queue_ditl.day = 331
        queue_ditl.length = 1
        queue_ditl.step_size = 3600
        queue_ditl.battery.battery_alert = True
        mock_charging = Mock()
        mock_charging.ra = 100.0
        mock_charging.dec = 50.0
        mock_charging.obsid = 999001
        mock_charging.roll = 0.0
        mock_charging.begin = 1543622400
        mock_charging.end = 1543622400 + 86400
        mock_charging.copy = Mock(return_value=Mock())
        mock_charging.copy.return_value.begin = 1543622400
        mock_charging.copy.return_value.end = 1543622400 + 86400
        queue_ditl.emergency_charging.should_initiate_charging = Mock(return_value=True)
        queue_ditl.emergency_charging.initiate_emergency_charging = Mock(
            return_value=mock_charging
        )
        queue_ditl.acs.enqueue_command = Mock()
        queue_ditl.calc()
        assert queue_ditl.acs.enqueue_command.called
        command_types = [
            call[0][0].command_type.name
            for call in queue_ditl.acs.enqueue_command.call_args_list
        ]
        assert "START_BATTERY_CHARGE" in command_types

    def test_initiate_charging_leaves_short_science_target_retryable(
        self, queue_ditl
    ) -> None:
        science_ppt = Mock()
        science_ppt.obstype = "AT"
        science_ppt.begin = 1000.0
        science_ppt.end = 1000.0 + 86400
        science_ppt.slewtime = 200.0
        science_ppt.insaa = 0.0
        science_ppt.ss_min = 300.0
        science_ppt.done = False
        science_ppt.ra = 10.0
        science_ppt.dec = 20.0
        science_ppt.obsid = 1001

        charging_ppt = Mock()
        charging_ppt.ra = 100.0
        charging_ppt.dec = 50.0
        charging_ppt.obsid = 999001
        charging_ppt.roll = 0.0

        def interrupt_for_charging(utime, ephem, ra, dec, current_ppt):
            current_ppt.end = utime
            current_ppt.done = True
            return charging_ppt

        queue_ditl.ppt = science_ppt
        queue_ditl.emergency_charging.initiate_emergency_charging = Mock(
            side_effect=interrupt_for_charging
        )

        queue_ditl._initiate_charging(1250.0, 10.0, 20.0)

        assert science_ppt.done is False
        assert queue_ditl.ppt is charging_ppt
        queue_ditl.acs.enqueue_command.assert_called_once()

    def test_calc_drops_short_science_entry_when_charging_interrupts(
        self, queue_ditl
    ) -> None:
        from datetime import timedelta

        begin = queue_ditl.ephem.timestamp[0]
        queue_ditl.begin = begin
        queue_ditl.end = begin + timedelta(seconds=180)
        queue_ditl.ephem.step_size = 60
        queue_ditl.ephem.timestamp = [
            begin + timedelta(seconds=i * 60) for i in range(4)
        ]
        queue_ditl.step_size = 60
        queue_ditl.battery.battery_alert = True
        queue_ditl.acs.get_mode = Mock(return_value=ACSMode.SCIENCE)
        queue_ditl.acs.pointing = Mock(return_value=(10.0, 20.0, 0.0, 1001))

        science_entry = Mock()
        science_entry.obstype = "AT"
        science_entry.begin = begin.timestamp()
        science_entry.end = begin.timestamp() + 86400
        science_entry.slewtime = 120.0
        science_entry.insaa = 0.0
        science_entry.ss_min = 300.0
        science_entry.done = False
        science_entry.ra = 10.0
        science_entry.dec = 20.0
        science_entry.obsid = 1001
        science_entry.exptime = 1000
        science_copy = Mock()
        science_copy.obstype = science_entry.obstype
        science_copy.begin = science_entry.begin
        science_copy.end = science_entry.end
        science_copy.slewtime = science_entry.slewtime
        science_copy.insaa = science_entry.insaa
        science_copy.ss_min = science_entry.ss_min
        science_copy.obsid = science_entry.obsid
        science_entry.copy = Mock(return_value=science_copy)

        charging_entry = Mock()
        charging_entry.obstype = "CHARGE"
        charging_entry.begin = begin.timestamp()
        charging_entry.end = begin.timestamp() + 86400
        charging_entry.slewtime = 0.0
        charging_entry.ra = 100.0
        charging_entry.dec = 50.0
        charging_entry.obsid = 999001
        charging_entry.roll = 0.0
        charging_entry.copy = Mock(return_value=charging_entry)

        def interrupt_for_charging(utime, ephem, ra, dec, current_ppt):
            current_ppt.end = utime
            current_ppt.done = True
            return charging_entry

        queue_ditl.ppt = science_entry
        queue_ditl.emergency_charging.should_initiate_charging = Mock(return_value=True)
        queue_ditl.emergency_charging.initiate_emergency_charging = Mock(
            side_effect=interrupt_for_charging
        )

        assert queue_ditl.calc() is True

        science_entries = [
            entry
            for entry in queue_ditl.plan
            if getattr(entry, "obstype", None) == "AT"
        ]
        assert science_entries == []
        assert science_entry.done is False

    def test_calc_closes_final_ppt_end_set(self, queue_ditl) -> None:
        queue_ditl.year = 2018
        queue_ditl.day = 331
        queue_ditl.length = 1
        queue_ditl.step_size = 3600
        mock_ppt = Mock()
        mock_ppt.ra = 45.0
        mock_ppt.dec = 30.0
        mock_ppt.obsid = 1001
        mock_ppt.exptime = 86400.0
        mock_ppt.begin = 1543622400
        mock_ppt.end = 1543708800
        mock_ppt.done = False
        mock_ppt.next_vis = Mock(return_value=1543276800.0)
        mock_ppt.ss_max = 3600.0
        mock_ppt.ss_min = 300.0
        mock_ppt.windows = [[0.0, 1e12]]
        mock_ppt.copy = Mock(return_value=Mock())
        mock_ppt.copy.return_value.begin = 1543622400
        mock_ppt.copy.return_value.end = 1543708800
        mock_ppt.copy.return_value.obstype = "PPT"
        queue_ditl.queue.get = Mock(return_value=mock_ppt)
        queue_ditl.calc()
        if queue_ditl.plan:
            assert queue_ditl.plan[-1].end > 0

    def test_calc_handles_naive_datetimes(self, queue_ditl) -> None:
        """Test calc method handles naive datetimes by making them UTC."""
        from datetime import datetime

        # Set naive datetimes
        queue_ditl.begin = datetime(2018, 11, 27, 0, 0, 0)  # naive
        queue_ditl.end = datetime(2018, 11, 27, 1, 0, 0)  # naive

        queue_ditl.year = 2018
        queue_ditl.day = 331
        queue_ditl.length = 1
        queue_ditl.step_size = 3600

        # Should not raise an exception and should make datetimes timezone-aware
        result = queue_ditl.calc()
        assert result is True
        assert queue_ditl.begin.tzinfo is not None
        assert queue_ditl.end.tzinfo is not None

    def test_calc_handles_safe_mode_request(self, queue_ditl) -> None:
        """Test calc method handles safe mode requests."""
        # Set up safe mode request
        queue_ditl.config.fault_management.safe_mode_requested = True
        queue_ditl.acs.in_safe_mode = False

        queue_ditl.year = 2018
        queue_ditl.day = 331
        queue_ditl.length = 1
        queue_ditl.step_size = 3600

        result = queue_ditl.calc()
        assert result is True

        # Check that safe mode command was enqueued
        queue_ditl.acs.enqueue_command.assert_called()
        call_args = queue_ditl.acs.enqueue_command.call_args
        command = call_args[0][0]
        assert command.command_type == ACSCommandType.ENTER_SAFE_MODE

    def test_create_housekeeping_record_uses_current_state(self, queue_ditl) -> None:
        """Housekeeping helper should capture post-update recorder values."""
        queue_ditl.calculate_field_of_regard = True

        queue_ditl.panel = [0.75]
        queue_ditl.power = [80.0]
        queue_ditl.power_bus = [50.0]
        queue_ditl.power_payload = [30.0]
        queue_ditl.obsid = [1001]
        queue_ditl.battery.battery_level = 0.82
        queue_ditl.battery.charge_state = 1
        queue_ditl.battery.battery_alert = 0

        queue_ditl.recorder.current_volume_gb = 12.5
        queue_ditl.recorder.get_fill_fraction = Mock(return_value=0.92)
        queue_ditl.recorder.get_alert_level = Mock(return_value=2)

        with patch.object(
            queue_ditl.constraint, "instantaneous_field_of_regard", return_value=1.234
        ):
            hk = queue_ditl._create_housekeeping_record(
                utime=1000.0,
                ra=45.0,
                dec=30.0,
                roll=10.0,
                mode=ACSMode.SCIENCE,
            )

        assert isinstance(hk, Housekeeping)
        assert hk.panel_illumination == 0.75
        assert hk.power_usage == 80.0
        assert hk.recorder_volume_gb == 12.5
        assert hk.recorder_fill_fraction == 0.92
        assert hk.recorder_alert == 2
        assert hk.for_solid_angle_sr == 1.234

    def test_create_housekeeping_record_skips_for_when_disabled(
        self, queue_ditl
    ) -> None:
        """Housekeeping helper should omit FOR when calculation is disabled."""
        queue_ditl.calculate_field_of_regard = False

        with patch.object(
            queue_ditl.constraint, "instantaneous_field_of_regard"
        ) as mock_for:
            hk = queue_ditl._create_housekeeping_record(
                utime=1000.0,
                ra=45.0,
                dec=30.0,
                roll=10.0,
                mode=ACSMode.SCIENCE,
            )

        assert hk.for_solid_angle_sr is None
        mock_for.assert_not_called()

    def test_create_housekeeping_record_populates_quaternion(self, queue_ditl) -> None:
        """Housekeeping helper should populate quaternion fields from attitude."""
        import numpy as np

        from conops.common.vector import attitude_to_quat

        ra, dec, roll = 45.0, 30.0, 10.0

        hk = queue_ditl._create_housekeeping_record(
            utime=1000.0,
            ra=ra,
            dec=dec,
            roll=roll,
            mode=ACSMode.SCIENCE,
        )

        # Compute expected quaternion
        expected_quat = attitude_to_quat(ra, dec, roll)

        # Verify quaternion fields are populated
        assert hk.quat_w is not None
        assert hk.quat_x is not None
        assert hk.quat_y is not None
        assert hk.quat_z is not None

        # Verify quaternion values match expected
        assert abs(hk.quat_w - float(expected_quat[0])) < 1e-10
        assert abs(hk.quat_x - float(expected_quat[1])) < 1e-10
        assert abs(hk.quat_y - float(expected_quat[2])) < 1e-10
        assert abs(hk.quat_z - float(expected_quat[3])) < 1e-10

        # Verify quaternion is normalized
        quat_norm = np.sqrt(hk.quat_w**2 + hk.quat_x**2 + hk.quat_y**2 + hk.quat_z**2)
        assert abs(quat_norm - 1.0) < 1e-10

    def test_track_ppt_in_timeline_closes_placeholder_end_times(
        self, queue_ditl
    ) -> None:
        """Test _track_ppt_in_timeline closes PPTs with placeholder end times."""
        from conops.targets import PlanEntry

        # Create a mock PPT with placeholder end time
        mock_previous_ppt = Mock(spec=PlanEntry)
        mock_previous_ppt.begin = 1000.0
        mock_previous_ppt.end = 1000.0 + 86400 + 100  # Placeholder end time
        mock_previous_ppt.obstype = "PPT"
        mock_previous_ppt.copy = Mock(return_value=mock_previous_ppt)

        # Create current PPT
        mock_current_ppt = Mock(spec=PlanEntry)
        mock_current_ppt.begin = 2000.0
        mock_current_ppt.end = 3000.0
        mock_current_ppt.copy = Mock(return_value=mock_current_ppt)

        # Set up plan with previous PPT
        queue_ditl.plan = [mock_previous_ppt]
        queue_ditl.ppt = mock_current_ppt

        # Call the method
        queue_ditl._track_ppt_in_timeline()

        # Check that the previous PPT's end time was updated
        assert (
            mock_previous_ppt.end == 2000.0
        )  # Should be set to current PPT begin time
        assert len(queue_ditl.plan) == 2  # Should have both PPTs now

    def test_track_ppt_drops_science_entry_closed_before_collect(
        self, queue_ditl
    ) -> None:
        """A science entry truncated before slew completion is not kept as AT."""
        previous_ppt = Mock()
        previous_ppt.obstype = "AT"
        previous_ppt.begin = 1000.0
        previous_ppt.end = 1000.0 + 86400 + 100
        previous_ppt.slewtime = 224.0
        previous_ppt.insaa = 0.0
        previous_ppt.ss_min = 300
        previous_ppt.obsid = 1001

        current_ppt = Mock()
        current_ppt.begin = 1060.0
        current_ppt.end = 3000.0
        current_ppt.copy = Mock(return_value=current_ppt)

        queue_ditl.plan = [previous_ppt]
        queue_ditl.ppt = current_ppt

        queue_ditl._track_ppt_in_timeline()

        assert previous_ppt not in queue_ditl.plan
        assert queue_ditl.plan == [current_ppt]
        log_text = "\n".join(event.description for event in queue_ditl.log.events)
        assert "Dropping under-collected science entry 1001" in log_text
        assert "collected 0s" in log_text

    def test_track_ppt_drops_science_entry_below_ss_min(self, queue_ditl) -> None:
        """A science entry with less than ss_min collection is not kept as AT."""
        previous_ppt = Mock()
        previous_ppt.obstype = "AT"
        previous_ppt.begin = 1000.0
        previous_ppt.end = 1000.0 + 86400 + 100
        previous_ppt.slewtime = 100.0
        previous_ppt.insaa = 0.0
        previous_ppt.ss_min = 300.0
        previous_ppt.obsid = 1002

        current_ppt = Mock()
        current_ppt.begin = 1350.0
        current_ppt.end = 3000.0
        current_ppt.copy = Mock(return_value=current_ppt)

        queue_ditl.plan = [previous_ppt]
        queue_ditl.ppt = current_ppt

        queue_ditl._track_ppt_in_timeline()

        assert previous_ppt not in queue_ditl.plan
        assert queue_ditl.plan == [current_ppt]
        log_text = "\n".join(event.description for event in queue_ditl.log.events)
        assert "Dropping under-collected science entry 1002" in log_text
        assert "collected 250s of required 300s" in log_text

    def test_close_ppt_timeline_if_needed_closes_when_ppt_none(
        self, queue_ditl
    ) -> None:
        """Test _close_ppt_timeline_if_needed closes PPT when ppt is None."""
        from conops.targets import PlanEntry

        # Create a mock PPT with placeholder end time
        mock_ppt = Mock(spec=PlanEntry)
        mock_ppt.begin = 1000.0
        mock_ppt.end = 1000.0 + 86400 + 100  # Placeholder end time
        mock_ppt.obstype = "PPT"

        # Set up plan with the PPT and set current ppt to None
        queue_ditl.plan = [mock_ppt]
        queue_ditl.ppt = None

        # Call the method
        queue_ditl._close_ppt_timeline_if_needed(2000.0)

        # Check that the PPT's end time was updated
        assert mock_ppt.end == 2000.0

    def test_terminate_ppt_marks_done_when_requested(self, queue_ditl) -> None:
        """Test _terminate_ppt sets done flag when mark_done=True."""
        from conops.targets import PlanEntry

        # Create a mock PPT
        mock_ppt = Mock(spec=PlanEntry)
        mock_ppt.begin = 1000.0
        mock_ppt.end = 2000.0
        mock_ppt.obsid = 1001  # Add obsid attribute
        mock_ppt.obstype = "PPT"

        # Set up the PPT
        queue_ditl.plan = [mock_ppt]
        queue_ditl.ppt = mock_ppt

        # Call terminate with mark_done=True
        queue_ditl._terminate_ppt(1500.0, reason="Test termination", mark_done=True)

        # Check that done was set to True
        assert mock_ppt.done is True
        assert mock_ppt.end == 1500.0
        assert queue_ditl.ppt is None

    def test_fetch_ppt_delays_for_current_slew(self, queue_ditl, capsys) -> None:
        """Test _fetch_new_ppt delays slew when current slew is in progress."""
        from conops.simulation.slew import Slew

        # Create mock PPT
        mock_ppt = Mock()
        mock_ppt.ra = 45.0
        mock_ppt.dec = 30.0
        mock_ppt.obsid = 1001
        mock_ppt.next_vis = Mock(return_value=1000.0)
        mock_ppt.ss_max = 3600.0
        mock_ppt.ss_min = 300.0
        mock_ppt.windows = [[0.0, 1e12]]
        queue_ditl.queue.get = Mock(return_value=mock_ppt)

        # Create a mock current slew that's still slewing
        mock_current_slew = Mock(spec=Slew)
        mock_current_slew.is_slewing = Mock(return_value=True)
        mock_current_slew.slewstart = 900.0
        mock_current_slew.slewtime = 200.0
        queue_ditl.acs.last_slew = mock_current_slew
        queue_ditl._fetch_new_ppt(1000.0, 10.0, 20.0)

        # Check that the command was enqueued with delayed execution time
        queue_ditl.acs.enqueue_command.assert_called_once()
        call_args = queue_ditl.acs.enqueue_command.call_args
        command = call_args[0][0]
        # Execution time should be delayed to current_slew.slewstart + slewtime = 1100.0
        assert command.execution_time == 1100.0

        # Check that the delay message was logged
        log_text = "\n".join(event.description for event in queue_ditl.log.events)
        assert "delaying next slew until" in log_text

    def test_fetch_ppt_delays_for_visibility(self, queue_ditl, capsys) -> None:
        """Test _fetch_new_ppt delays slew when target visibility requires it."""
        # Create mock PPT
        mock_ppt = Mock()
        mock_ppt.ra = 45.0
        mock_ppt.dec = 30.0
        mock_ppt.obsid = 1001
        # Set next_vis to a time after the current time (1000.0)
        mock_ppt.next_vis = Mock(return_value=1200.0)
        mock_ppt.ss_max = 3600.0
        mock_ppt.ss_min = 300.0
        mock_ppt.windows = [[0.0, 1e12]]
        queue_ditl.queue.get = Mock(return_value=mock_ppt)
        queue_ditl._fetch_new_ppt(1000.0, 10.0, 20.0)

        # Check that the command was enqueued with delayed execution time
        queue_ditl.acs.enqueue_command.assert_called_once()
        call_args = queue_ditl.acs.enqueue_command.call_args
        command = call_args[0][0]
        # Execution time should be delayed to visibility time (1200.0)
        assert command.execution_time == 1200.0

        # Check that the visibility delay message was logged
        log_text = "\n".join(event.description for event in queue_ditl.log.events)
        assert "Slew delayed by" in log_text

    def test_terminate_science_ppt_for_pass_sets_done_flag(self, queue_ditl) -> None:
        """Test _terminate_science_ppt_for_pass sets done flag."""
        from conops.targets import PlanEntry

        # Create a mock PPT
        mock_ppt = Mock(spec=PlanEntry)
        mock_ppt.begin = 1000.0
        mock_ppt.end = 2000.0
        mock_ppt.obstype = "PPT"

        # Set up the PPT
        queue_ditl.plan = [mock_ppt]
        queue_ditl.ppt = mock_ppt

        # Call the method
        queue_ditl._terminate_science_ppt_for_pass(1500.0)

        # Check that done was set to True and other updates happened
        assert mock_ppt.done is True
        assert mock_ppt.end == 1500.0
        assert queue_ditl.ppt is None

    def test_terminate_charging_ppt_sets_done_flag(self, queue_ditl) -> None:
        """Test _terminate_charging_ppt sets done flag."""
        from conops.targets import PlanEntry

        # Create a mock charging PPT
        mock_charging_ppt = Mock(spec=PlanEntry)
        mock_charging_ppt.begin = 1000.0
        mock_charging_ppt.end = 2000.0
        mock_charging_ppt.obstype = "PPT"

        # Set up the charging PPT
        queue_ditl.plan = [mock_charging_ppt]
        queue_ditl.charging_ppt = mock_charging_ppt

        # Call the method
        queue_ditl._terminate_charging_ppt(1500.0)

        # Check that done was set to True and other updates happened
        assert mock_charging_ppt.done is True
        assert mock_charging_ppt.end == 1500.0
        assert queue_ditl.charging_ppt is None

    def test_setup_simulation_timing_fails_with_invalid_ephemeris_range(
        self, queue_ditl, capsys
    ):
        """Test _setup_simulation_timing fails when ephemeris doesn't cover date range."""
        from datetime import datetime, timezone

        import pytest

        # Set begin/end times that are not in the ephemeris
        queue_ditl.begin = datetime(2025, 1, 1, tzinfo=timezone.utc)  # Far future date
        queue_ditl.end = datetime(2025, 1, 2, tzinfo=timezone.utc)

        with pytest.raises(
            ValueError, match="ERROR: Ephemeris does not cover simulation date range"
        ):
            queue_ditl._setup_simulation_timing()


class TestGetConstraintName:
    """Tests for _get_constraint_name method."""

    def test_get_constraint_name_earth_name(self, queue_ditl) -> None:
        ra, dec, utime = 10.0, 20.0, 1000.0
        queue_ditl.constraint.in_earth = Mock(return_value=True)
        queue_ditl.constraint.in_moon = Mock(return_value=False)
        queue_ditl.constraint.in_sun = Mock(return_value=False)
        queue_ditl.constraint.in_panel = Mock(return_value=False)
        name = queue_ditl._get_constraint_name(ra, dec, utime)
        assert name == "Earth Limb"

    def test_get_constraint_name_earth_call(self, queue_ditl) -> None:
        ra, dec, utime = 10.0, 20.0, 1000.0
        queue_ditl.constraint.in_earth = Mock(return_value=True)
        queue_ditl.constraint.in_moon = Mock(return_value=False)
        queue_ditl.constraint.in_sun = Mock(return_value=False)
        queue_ditl.constraint.in_panel = Mock(return_value=False)
        queue_ditl.constraint.in_anti_sun = Mock(return_value=False)
        queue_ditl.constraint.in_star_tracker_hard = Mock(return_value=False)
        queue_ditl.constraint.in_star_tracker_soft = Mock(return_value=False)
        _ = queue_ditl._get_constraint_name(ra, dec, utime)
        queue_ditl.constraint.in_earth.assert_called_once_with(
            ra, dec, utime, target_roll=None
        )

    def test_get_constraint_name_moon_name(self, queue_ditl) -> None:
        ra, dec, utime = 11.0, 21.0, 2000.0
        queue_ditl.constraint.in_earth = Mock(return_value=False)
        queue_ditl.constraint.in_moon = Mock(return_value=True)
        queue_ditl.constraint.in_sun = Mock(return_value=False)
        queue_ditl.constraint.in_panel = Mock(return_value=False)
        name = queue_ditl._get_constraint_name(ra, dec, utime)
        assert name == "Moon"

    def test_get_constraint_name_moon_calls(self, queue_ditl) -> None:
        ra, dec, utime = 11.0, 21.0, 2000.0
        queue_ditl.constraint.in_earth = Mock(return_value=False)
        queue_ditl.constraint.in_moon = Mock(return_value=True)
        queue_ditl.constraint.in_sun = Mock(return_value=False)
        queue_ditl.constraint.in_panel = Mock(return_value=False)
        queue_ditl.constraint.in_anti_sun = Mock(return_value=False)
        queue_ditl.constraint.in_star_tracker_hard = Mock(return_value=False)
        queue_ditl.constraint.in_star_tracker_soft = Mock(return_value=False)
        _ = queue_ditl._get_constraint_name(ra, dec, utime)
        queue_ditl.constraint.in_earth.assert_called_once_with(
            ra, dec, utime, target_roll=None
        )
        queue_ditl.constraint.in_moon.assert_called_once_with(
            ra, dec, utime, target_roll=None
        )

    def test_get_constraint_name_sun_name(self, queue_ditl) -> None:
        ra, dec, utime = 12.0, 22.0, 3000.0
        queue_ditl.constraint.in_earth = Mock(return_value=False)
        queue_ditl.constraint.in_moon = Mock(return_value=False)
        queue_ditl.constraint.in_sun = Mock(return_value=True)
        queue_ditl.constraint.in_panel = Mock(return_value=False)
        name = queue_ditl._get_constraint_name(ra, dec, utime)
        assert name == "Sun"

    def test_get_constraint_name_sun_calls(self, queue_ditl) -> None:
        ra, dec, utime = 12.0, 22.0, 3000.0
        queue_ditl.constraint.in_earth = Mock(return_value=False)
        queue_ditl.constraint.in_moon = Mock(return_value=False)
        queue_ditl.constraint.in_sun = Mock(return_value=True)
        queue_ditl.constraint.in_panel = Mock(return_value=False)
        queue_ditl.constraint.in_anti_sun = Mock(return_value=False)
        queue_ditl.constraint.in_star_tracker_hard = Mock(return_value=False)
        queue_ditl.constraint.in_star_tracker_soft = Mock(return_value=False)
        _ = queue_ditl._get_constraint_name(ra, dec, utime)
        # Sun is checked first; Earth and Moon are never reached
        queue_ditl.constraint.in_sun.assert_called_once_with(
            ra, dec, utime, target_roll=None
        )
        queue_ditl.constraint.in_earth.assert_not_called()
        queue_ditl.constraint.in_moon.assert_not_called()

    def test_get_constraint_name_panel_name(self, queue_ditl) -> None:
        ra, dec, utime = 13.0, 23.0, 4000.0
        queue_ditl.constraint.in_earth = Mock(return_value=False)
        queue_ditl.constraint.in_moon = Mock(return_value=False)
        queue_ditl.constraint.in_sun = Mock(return_value=False)
        queue_ditl.constraint.in_panel = Mock(return_value=True)
        name = queue_ditl._get_constraint_name(ra, dec, utime)
        assert name == "Panel"

    def test_get_constraint_name_panel_calls(self, queue_ditl) -> None:
        ra, dec, utime = 13.0, 23.0, 4000.0
        queue_ditl.constraint.in_earth = Mock(return_value=False)
        queue_ditl.constraint.in_moon = Mock(return_value=False)
        queue_ditl.constraint.in_sun = Mock(return_value=False)
        queue_ditl.constraint.in_panel = Mock(return_value=True)
        queue_ditl.constraint.in_anti_sun = Mock(return_value=False)
        queue_ditl.constraint.in_star_tracker_hard = Mock(return_value=False)
        queue_ditl.constraint.in_star_tracker_soft = Mock(return_value=False)
        _ = queue_ditl._get_constraint_name(ra, dec, utime)
        # Order: Sun, Earth, Panel — Moon is never reached
        queue_ditl.constraint.in_sun.assert_called_once_with(
            ra, dec, utime, target_roll=None
        )
        queue_ditl.constraint.in_earth.assert_called_once_with(
            ra, dec, utime, target_roll=None
        )
        queue_ditl.constraint.in_panel.assert_called_once_with(
            ra, dec, utime, target_roll=None
        )
        queue_ditl.constraint.in_moon.assert_not_called()

    def test_get_constraint_name_unknown_name(self, queue_ditl) -> None:
        ra, dec, utime = 14.0, 24.0, 5000.0
        queue_ditl.constraint.in_earth = Mock(return_value=False)
        queue_ditl.constraint.in_moon = Mock(return_value=False)
        queue_ditl.constraint.in_sun = Mock(return_value=False)
        queue_ditl.constraint.in_panel = Mock(return_value=False)
        queue_ditl.constraint.in_anti_sun = Mock(return_value=False)
        queue_ditl.constraint.in_orbit = Mock(return_value=False)
        queue_ditl.constraint.in_star_tracker_hard = Mock(return_value=False)
        queue_ditl.constraint.in_star_tracker_soft = Mock(return_value=False)
        name = queue_ditl._get_constraint_name(ra, dec, utime)
        assert name == "Unknown"

    def test_get_constraint_name_unknown_calls(self, queue_ditl) -> None:
        ra, dec, utime = 14.0, 24.0, 5000.0
        queue_ditl.constraint.in_earth = Mock(return_value=False)
        queue_ditl.constraint.in_moon = Mock(return_value=False)
        queue_ditl.constraint.in_sun = Mock(return_value=False)
        queue_ditl.constraint.in_panel = Mock(return_value=False)
        queue_ditl.constraint.in_anti_sun = Mock(return_value=False)
        queue_ditl.constraint.in_orbit = Mock(return_value=False)
        queue_ditl.constraint.in_star_tracker_hard = Mock(return_value=False)
        queue_ditl.constraint.in_star_tracker_soft = Mock(return_value=False)
        _ = queue_ditl._get_constraint_name(ra, dec, utime)
        queue_ditl.constraint.in_earth.assert_called_once_with(
            ra, dec, utime, target_roll=None
        )
        queue_ditl.constraint.in_moon.assert_called_once_with(
            ra, dec, utime, target_roll=None
        )
        queue_ditl.constraint.in_sun.assert_called_once_with(
            ra, dec, utime, target_roll=None
        )
        queue_ditl.constraint.in_panel.assert_called_once_with(
            ra, dec, utime, target_roll=None
        )

    def test_get_constraint_name_orbit_name(self, queue_ditl) -> None:
        ra, dec, utime = 14.0, 24.0, 5000.0
        queue_ditl.constraint.in_earth = Mock(return_value=False)
        queue_ditl.constraint.in_moon = Mock(return_value=False)
        queue_ditl.constraint.in_sun = Mock(return_value=False)
        queue_ditl.constraint.in_panel = Mock(return_value=False)
        queue_ditl.constraint.in_anti_sun = Mock(return_value=False)
        queue_ditl.constraint.in_orbit = Mock(return_value=True)
        name = queue_ditl._get_constraint_name(ra, dec, utime)
        assert name == "Orbit"

    def test_get_constraint_name_precedence_sun(self, queue_ditl) -> None:
        """Sun has highest precedence when multiple constraints are simultaneously active."""
        ra, dec, utime = 15.0, 25.0, 6000.0
        queue_ditl.constraint.in_earth = Mock(return_value=True)
        queue_ditl.constraint.in_moon = Mock(return_value=True)
        queue_ditl.constraint.in_sun = Mock(return_value=True)
        queue_ditl.constraint.in_panel = Mock(return_value=True)
        queue_ditl.constraint.in_anti_sun = Mock(return_value=False)
        queue_ditl.constraint.in_star_tracker_hard = Mock(return_value=False)
        queue_ditl.constraint.in_star_tracker_soft = Mock(return_value=False)
        name = queue_ditl._get_constraint_name(ra, dec, utime)
        assert name == "Sun"
        queue_ditl.constraint.in_sun.assert_called_once_with(
            ra, dec, utime, target_roll=None
        )
        queue_ditl.constraint.in_earth.assert_not_called()


class TestCheckAndManagePasses:
    """Tests for _check_and_manage_passes helper method."""

    def test_check_and_manage_passes_end_pass_calls_check_pass_timing(
        self, queue_ditl
    ) -> None:
        """Test that END_PASS is enqueued when we detect a pass ended."""
        utime = 1000.0
        ra, dec = 10.0, 20.0
        # Mock passrequests to indicate pass has ended
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=None)
        # Previous timestep had a pass
        queue_ditl.acs.passrequests.next_pass = Mock(return_value=None)
        queue_ditl._check_and_manage_passes(utime, ra, dec)
        # The method should work without errors even when pass ends
        assert True

    def test_check_and_manage_passes_end_pass_enqueues_command(
        self, queue_ditl
    ) -> None:
        """Test that END_PASS command is enqueued when pass ends."""
        utime = 1000.0
        ra, dec = 10.0, 20.0
        # Setup: currently not in a pass
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=None)
        queue_ditl.acs.passrequests.next_pass = Mock(return_value=None)
        queue_ditl.acs.acsmode = ACSMode.SCIENCE
        # No pass, no next pass - method should not enqueue anything
        queue_ditl._check_and_manage_passes(utime, ra, dec)
        # verify method runs without error

    def test_check_and_manage_passes_end_pass_command_type(self, queue_ditl) -> None:
        """Test that END_PASS command has correct type."""
        utime = 1000.0
        ra, dec = 10.0, 20.0
        # Simulate just exited a pass
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=None)
        queue_ditl.acs.passrequests.next_pass = Mock(return_value=None)
        queue_ditl.acs.acsmode = ACSMode.SCIENCE
        queue_ditl._check_and_manage_passes(utime, ra, dec)
        # Test documents that when no pass, no command is sent

    def test_check_and_manage_passes_end_pass_command_execution_time(
        self, queue_ditl
    ) -> None:
        """Test that END_PASS command has correct execution time."""
        utime = 1000.0
        ra, dec = 10.0, 20.0
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=None)
        queue_ditl.acs.passrequests.next_pass = Mock(return_value=None)
        queue_ditl.acs.acsmode = ACSMode.SCIENCE
        queue_ditl._check_and_manage_passes(utime, ra, dec)
        # Verify method completes without error

    def test_check_and_manage_passes_start_pass_calls_check_pass_timing(
        self, queue_ditl
    ):
        """Test that START_PASS is issued when entering a pass."""
        utime = 1000.0
        ra, dec = 10.0, 20.0
        pass_obj = Pass(station="GS_TEST", begin=950.0, length=600.0)
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=pass_obj)
        queue_ditl.acs.acsmode = ACSMode.SCIENCE  # Not in pass yet
        queue_ditl._check_and_manage_passes(utime, ra, dec)
        queue_ditl.acs.enqueue_command.assert_called_once()

    def test_check_and_manage_passes_start_pass_enqueues_command(
        self, queue_ditl
    ) -> None:
        """Test that START_PASS command is enqueued when entering pass."""
        utime = 1000.0
        ra, dec = 10.0, 20.0
        pass_obj = Pass(station="GS_TEST", begin=950.0, length=600.0)
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=pass_obj)
        queue_ditl.acs.acsmode = ACSMode.SCIENCE  # Not in pass yet
        queue_ditl._check_and_manage_passes(utime, ra, dec)
        queue_ditl.acs.enqueue_command.assert_called_once()

    def test_check_and_manage_passes_start_pass_command_type_and_exec_time(
        self, queue_ditl
    ):
        """Test START_PASS command has correct type and execution time."""
        utime = 1000.0
        ra, dec = 10.0, 20.0
        pass_obj = Pass(station="GS_TEST", begin=950.0, length=600.0)
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=pass_obj)
        queue_ditl.acs.acsmode = ACSMode.SCIENCE  # Not in pass yet
        queue_ditl._check_and_manage_passes(utime, ra, dec)
        cmd = queue_ditl.acs.enqueue_command.call_args[0][0]
        assert cmd.command_type == ACSCommandType.START_PASS
        assert cmd.execution_time == utime

    def test_check_and_manage_passes_start_pass_sets_obsid(self, queue_ditl) -> None:
        """Test that pass gets assigned obsid when starting."""
        utime = 1000.0
        ra, dec = 10.0, 20.0
        pass_obj = Pass(
            station="GS_STATION", begin=950.0, slewrequired=900.0, length=600.0
        )
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=pass_obj)
        queue_ditl.acs.acsmode = ACSMode.SCIENCE
        queue_ditl.acs.last_ppt = Mock(obsid=1234)
        queue_ditl._check_and_manage_passes(utime, ra, dec)
        # In the current code, obsid is not set during START_PASS
        # This test documents that behavior

    def test_check_and_manage_passes_start_pass_command_slew_station(
        self, queue_ditl
    ) -> None:
        """Test START_PASS behavior in SAA mode (should not be enqueued)."""
        utime = 1000.0
        ra, dec = 10.0, 20.0
        pass_obj = Pass(
            station="GS_STATION", begin=950.0, slewrequired=900.0, length=600.0
        )
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=pass_obj)
        queue_ditl.acs.acsmode = ACSMode.SCIENCE
        queue_ditl.acs.last_ppt = Mock(obsid=1234)
        queue_ditl._check_and_manage_passes(utime, ra, dec)
        # Verify method ran without error

    def test_check_and_manage_passes_start_pass_not_enqueued_when_not_science_calls_check(
        self, queue_ditl
    ):
        """Test that START_PASS is not issued when in SAA mode."""
        utime = 2000.0
        ra, dec = 30.0, 40.0
        pass_obj = Pass(station="GS2", begin=1850.0, slewrequired=1800.0, length=600.0)
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=pass_obj)
        queue_ditl.acs.acsmode = ACSMode.SAA
        queue_ditl._check_and_manage_passes(utime, ra, dec)
        # In SAA mode, commands should not be enqueued

    def test_check_and_manage_passes_both_end_and_start_calls_check_pass_timing(
        self, queue_ditl
    ):
        """Test pass management with both end and start scenarios."""
        utime = 3000.0
        ra, dec = 0.0, 0.0
        pass_obj = Pass(
            station="GS_ORDER", begin=2950.0, slewrequired=2900.0, length=600.0
        )
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=pass_obj)
        queue_ditl.acs.acsmode = ACSMode.SCIENCE
        queue_ditl.acs.last_ppt = Mock(obsid=0xBEEF)
        queue_ditl._check_and_manage_passes(utime, ra, dec)
        # Verify method runs without error

    def test_check_and_manage_passes_both_end_and_start_enqueues_two_commands(
        self, queue_ditl
    ):
        """Test multiple commands during pass transitions."""
        utime = 3000.0
        ra, dec = 0.0, 0.0
        pass_obj = Pass(
            station="GS_ORDER", begin=2950.0, slewrequired=2900.0, length=600.0
        )
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=pass_obj)
        queue_ditl.acs.acsmode = ACSMode.SCIENCE
        queue_ditl.acs.last_ppt = Mock(obsid=0xBEEF)
        queue_ditl._check_and_manage_passes(utime, ra, dec)
        # Verify behavior documented

    def test_check_and_manage_passes_both_end_and_start_command_order(
        self, queue_ditl
    ) -> None:
        """Test command ordering during pass transitions."""
        utime = 3000.0
        ra, dec = 0.0, 0.0
        pass_obj = Pass(
            station="GS_ORDER", begin=2950.0, slewrequired=2900.0, length=600.0
        )
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=pass_obj)
        queue_ditl.acs.acsmode = ACSMode.SCIENCE
        queue_ditl.acs.last_ppt = Mock(obsid=0xBEEF)
        queue_ditl._check_and_manage_passes(utime, ra, dec)
        # Method should run without error

    def test_check_and_manage_passes_both_end_and_start_start_command_exec_time_and_slew(
        self, queue_ditl
    ):
        """Test START_PASS command structure and timing."""
        utime = 3000.0
        ra, dec = 0.0, 0.0
        pass_obj = Pass(
            station="GS_ORDER", begin=2950.0, slewrequired=2900.0, length=600.0
        )
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=pass_obj)
        queue_ditl.acs.acsmode = ACSMode.SCIENCE
        queue_ditl.acs.last_ppt = Mock(obsid=0xBEEF)
        queue_ditl._check_and_manage_passes(utime, ra, dec)
        # Verify method runs correctly

    def test_check_and_manage_passes_both_end_and_start_sets_obsid_from_last_ppt(
        self, queue_ditl
    ):
        """Test obsid handling during pass transitions."""
        utime = 3000.0
        ra, dec = 0.0, 0.0
        pass_obj = Pass(
            station="GS_ORDER", begin=2950.0, slewrequired=2900.0, length=600.0
        )
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=pass_obj)
        queue_ditl.acs.acsmode = ACSMode.SCIENCE
        queue_ditl.acs.last_ppt = Mock(obsid=0xBEEF)
        queue_ditl._check_and_manage_passes(utime, ra, dec)
        # Verify method completes successfully

    def test_check_and_manage_passes_slew_to_pass_has_gsp_obstype(
        self, queue_ditl
    ) -> None:
        """Test that slew to ground station pass is marked with GSP obstype."""
        utime = 1000.0
        ra, dec = 10.0, 20.0

        pass_obj = Pass(
            station="GS_TEST",
            begin=1100.0,
            length=600.0,
            gsstartra=100.0,
            gsstartdec=50.0,
        )

        # Mock the pass request methods
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=None)
        queue_ditl.acs.passrequests.next_pass = Mock(return_value=pass_obj)
        queue_ditl.acs.acsmode = ACSMode.SCIENCE

        # Call the method
        with patch.object(Pass, "time_to_slew", return_value=True):
            queue_ditl._check_and_manage_passes(utime, ra, dec)

        # Verify a slew command was enqueued
        queue_ditl.acs.enqueue_command.assert_called_once()

        # Get the enqueued command
        call_args = queue_ditl.acs.enqueue_command.call_args
        command = call_args[0][0]

        # Verify it's a SLEW_TO_TARGET command
        assert command.command_type == ACSCommandType.SLEW_TO_TARGET

        # Verify the slew has GSP obstype marker
        assert command.slew.obstype == "GSP"

        # Verify slew points to the pass start position
        assert command.slew.endra == pass_obj.gsstartra
        assert command.slew.enddec == pass_obj.gsstartdec

    def test_check_and_manage_passes_exports_gsp_plan_entry_for_pass_slew(
        self, queue_ditl, tmp_path
    ) -> None:
        """Pass slew reservation should create an exported GSP plan entry."""
        utime = 1000.0
        ra, dec = 10.0, 20.0

        pass_obj = Pass(
            station="GS_TEST",
            begin=1100.0,
            length=600.0,
            gsstartra=100.0,
            gsstartdec=50.0,
            obsid=4242,
        )

        queue_ditl.acs.passrequests.current_pass = Mock(return_value=None)
        queue_ditl.acs.passrequests.next_pass = Mock(return_value=pass_obj)
        queue_ditl.acs.acsmode = ACSMode.SCIENCE

        with patch.object(Pass, "time_to_slew", return_value=True):
            queue_ditl._check_and_manage_passes(utime, ra, dec)
            queue_ditl._check_and_manage_passes(utime, ra, dec)

        gsp_entries = [
            entry for entry in queue_ditl.plan if entry.obstype == ObsType.GSP
        ]
        assert len(gsp_entries) == 1
        entry = gsp_entries[0]
        assert entry.name == "GS_TEST_PASS"
        assert entry.begin == utime
        assert entry.slewtime == 100
        assert entry.end == pass_obj.end
        assert entry.exposure == 600
        assert entry.exptime == 600
        assert entry.station == "GS_TEST"
        assert entry.contact_begin == pass_obj.begin
        assert entry.contact_end == pass_obj.end

        schema = PlanSchema.from_plan(queue_ditl.plan)
        assert schema.entries[0].obstype == ObsType.GSP
        assert schema.entries[0].station == "GS_TEST"
        assert schema.entries[0].contact_begin == pass_obj.begin
        saved_path = schema.save(tmp_path / "plan.json")
        assert '"obstype": "GSP"' in saved_path.read_text()
        assert '"station": "GS_TEST"' in saved_path.read_text()

    def test_check_and_manage_passes_records_gsp_after_pass_slew_command_enqueue(
        self, queue_ditl
    ) -> None:
        """A GSP plan entry should only be recorded after the pass command path."""
        utime = 1000.0
        pass_obj = Pass(
            station="GS_TEST",
            begin=1100.0,
            length=600.0,
            gsstartra=100.0,
            gsstartdec=50.0,
        )
        enqueued_commands = []

        def enqueue_command(command) -> None:
            assert not any(entry.obstype == ObsType.GSP for entry in queue_ditl.plan)
            enqueued_commands.append(command)

        queue_ditl.acs.enqueue_command.side_effect = enqueue_command
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=None)
        queue_ditl.acs.passrequests.next_pass = Mock(return_value=pass_obj)
        queue_ditl.acs.acsmode = ACSMode.SCIENCE
        queue_ditl.acs.in_safe_mode = False

        with patch.object(Pass, "time_to_slew", return_value=True):
            queue_ditl._check_and_manage_passes(utime, 10.0, 20.0)

        assert enqueued_commands[0].command_type == ACSCommandType.SLEW_TO_TARGET
        gsp_entries = [
            entry for entry in queue_ditl.plan if entry.obstype == ObsType.GSP
        ]
        assert len(gsp_entries) == 1

    def test_check_and_manage_passes_safe_mode_does_not_export_gsp(
        self, queue_ditl
    ) -> None:
        """SAFE mode should not create a plan entry for a pass ACS will not command."""
        pass_obj = Pass(
            station="GS_TEST",
            begin=1100.0,
            length=600.0,
            gsstartra=100.0,
            gsstartdec=50.0,
        )
        queue_ditl.acs.acsmode = ACSMode.SAFE
        queue_ditl.acs.in_safe_mode = True
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=pass_obj)
        queue_ditl.acs.passrequests.next_pass = Mock(return_value=pass_obj)

        with patch.object(Pass, "time_to_slew", return_value=True):
            queue_ditl._check_and_manage_passes(1000.0, 10.0, 20.0)

        queue_ditl.acs.enqueue_command.assert_not_called()
        queue_ditl.acs.passrequests.current_pass.assert_not_called()
        queue_ditl.acs.passrequests.next_pass.assert_not_called()
        assert list(queue_ditl.plan) == []

    def test_check_and_manage_passes_gsp_terminates_active_ppt_once(
        self, queue_ditl
    ) -> None:
        """Reserving a pass should end active science and not re-add it later."""
        utime = 1000.0
        ra, dec = 10.0, 20.0
        ppt = PlanEntry(config=queue_ditl.config)
        ppt.name = "SCIENCE"
        ppt.obstype = ObsType.AT
        ppt.begin = 900.0
        ppt.end = 5000.0
        ppt.slewtime = 0
        ppt.ss_min = 10
        queue_ditl.ppt = ppt
        queue_ditl.plan.append(ppt)

        pass_obj = Pass(
            station="GS_TEST",
            begin=1100.0,
            length=600.0,
            gsstartra=100.0,
            gsstartdec=50.0,
        )
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=None)
        queue_ditl.acs.passrequests.next_pass = Mock(return_value=pass_obj)
        queue_ditl.acs.acsmode = ACSMode.SCIENCE

        with patch.object(Pass, "time_to_slew", return_value=True):
            queue_ditl._check_and_manage_passes(utime, ra, dec)

        assert queue_ditl.ppt is None
        assert [entry.obstype for entry in queue_ditl.plan] == [ObsType.AT, ObsType.GSP]
        assert queue_ditl.plan[0].end == utime

        queue_ditl._track_ppt_in_timeline()
        assert [entry.obstype for entry in queue_ditl.plan] == [ObsType.AT, ObsType.GSP]

        queue_ditl.queue.get.reset_mock()
        queue_ditl._handle_science_mode(utime, ra, dec, ACSMode.SCIENCE)
        queue_ditl.queue.get.assert_not_called()

    def test_check_and_manage_passes_skips_overlapping_unselected_pass(
        self, queue_ditl
    ) -> None:
        """Overlapping pass opportunities should not become accidental tail contacts."""
        selected_pass = Pass(
            station="SGS",
            begin=1000.0,
            length=600.0,
            gsstartra=100.0,
            gsstartdec=50.0,
        )
        overlapping_pass = Pass(
            station="TRO",
            begin=1050.0,
            length=600.0,
            gsstartra=120.0,
            gsstartdec=60.0,
        )
        assert queue_ditl._record_gsp_plan_entry(selected_pass, reserved_begin=900.0)

        queue_ditl.acs.enqueue_command.reset_mock()
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=overlapping_pass)
        queue_ditl.acs.acsmode = ACSMode.SCIENCE

        queue_ditl._check_and_manage_passes(1600.0, 10.0, 20.0)

        gsp_entries = [
            entry for entry in queue_ditl.plan if entry.obstype == ObsType.GSP
        ]
        assert len(gsp_entries) == 1
        assert gsp_entries[0].station == "SGS"
        queue_ditl.acs.enqueue_command.assert_not_called()
        log_text = "\n".join(event.description for event in queue_ditl.log.events)
        assert "Skipping overlapping pass opportunity for TRO" in log_text

    def test_check_and_manage_passes_ends_commanded_pass_before_overlap(
        self, queue_ditl
    ) -> None:
        """An overlapping opportunity should not keep the commanded pass open."""
        selected_pass = Pass(
            station="SGS",
            begin=1000.0,
            length=600.0,
            gsstartra=100.0,
            gsstartdec=50.0,
        )
        overlapping_pass = Pass(
            station="TRO",
            begin=1050.0,
            length=600.0,
            gsstartra=120.0,
            gsstartdec=60.0,
        )
        assert queue_ditl._record_gsp_plan_entry(selected_pass, reserved_begin=900.0)

        queue_ditl.acs.acsmode = ACSMode.PASS
        queue_ditl.acs.current_pass = selected_pass
        queue_ditl.acs.passrequests.current_pass = Mock(return_value=overlapping_pass)

        queue_ditl._check_and_manage_passes(1601.0, 10.0, 20.0)

        cmd = queue_ditl.acs.enqueue_command.call_args[0][0]
        assert cmd.command_type == ACSCommandType.END_PASS
        gsp_entries = [
            entry for entry in queue_ditl.plan if entry.obstype == ObsType.GSP
        ]
        assert len(gsp_entries) == 1
        assert gsp_entries[0].station == "SGS"

    def test_check_and_manage_passes_exports_gsp_plan_entry_when_pass_starts(
        self, queue_ditl
    ) -> None:
        """Entering an active pass should export GSP even if no prep slew was reserved."""
        utime = 1000.0
        ra, dec = 10.0, 20.0
        pass_obj = Pass(
            station="GS_ACTIVE",
            begin=950.0,
            length=600.0,
            gsstartra=80.0,
            gsstartdec=30.0,
            obsid=3131,
        )

        queue_ditl.acs.passrequests.current_pass = Mock(return_value=pass_obj)
        queue_ditl.acs.acsmode = ACSMode.SCIENCE

        queue_ditl._check_and_manage_passes(utime, ra, dec)

        entry = queue_ditl.plan[0]
        assert entry.obstype == ObsType.GSP
        assert entry.name == "GS_ACTIVE_PASS"
        assert entry.begin == utime
        assert entry.slewtime == 0
        assert entry.end == pass_obj.end
        assert entry.exposure == 550
        assert entry.exptime == 550
        assert entry.contact_begin == pass_obj.begin

    def test_check_and_manage_passes_skip_slew_when_already_slewing(
        self, queue_ditl
    ) -> None:
        """Test that we don't initiate a slew to a pass if already slewing."""
        utime = 1000.0
        ra, dec = 10.0, 20.0

        # Set mode to SLEWING
        queue_ditl.acs.acsmode = ACSMode.SLEWING

        # Create a mock pass that would otherwise need slewing
        pass_obj = Mock()
        pass_obj.time_to_slew = Mock(return_value=True)
        queue_ditl.acs.passrequests.next_pass = Mock(return_value=pass_obj)

        # Call the method
        queue_ditl._check_and_manage_passes(utime, ra, dec)

        # No command should be enqueued because we're already slewing
        queue_ditl.acs.enqueue_command.assert_not_called()

    def test_check_and_manage_passes_skip_slew_when_in_pass(self, queue_ditl) -> None:
        """Test that we don't initiate a slew to next pass if currently in a pass."""
        utime = 1000.0
        ra, dec = 10.0, 20.0

        # Set mode to PASS
        queue_ditl.acs.acsmode = ACSMode.PASS

        # Create a mock pass that would otherwise need slewing
        pass_obj = Mock()
        pass_obj.time_to_slew = Mock(return_value=True)
        queue_ditl.acs.passrequests.next_pass = Mock(return_value=pass_obj)

        # Call the method
        queue_ditl._check_and_manage_passes(utime, ra, dec)

        # No command should be enqueued because we're already in a pass
        queue_ditl.acs.enqueue_command.assert_not_called()


class TestGetACSQueueStatus:
    """Test get_acs_queue_status method."""

    def test_get_acs_queue_status_empty_queue(self, queue_ditl) -> None:
        queue_ditl.acs.command_queue = []
        queue_ditl.acs.current_slew = None
        queue_ditl.acs.acsmode = ACSMode.SCIENCE
        status = queue_ditl.get_acs_queue_status()
        expected = {
            "queue_size": 0,
            "pending_commands": [],
            "current_slew": None,
            "acs_mode": "SCIENCE",
        }
        assert status == expected

    def test_get_acs_queue_status_with_pending_commands(self, queue_ditl) -> None:
        mock_cmd1 = Mock()
        mock_cmd1.command_type.name = "SLEW_TO_TARGET"
        mock_cmd1.execution_time = 1000.0
        mock_cmd2 = Mock()
        mock_cmd2.command_type.name = "START_PASS"
        mock_cmd2.execution_time = 2000.0
        queue_ditl.acs.command_queue = [mock_cmd1, mock_cmd2]
        queue_ditl.acs.current_slew = None
        queue_ditl.acs.acsmode = ACSMode.PASS
        with patch("conops.ditl.queue_ditl.unixtime2date") as mock_unixtime2date:
            mock_unixtime2date.side_effect = [
                "2023-01-01 00:00:00",
                "2023-01-01 00:33:20",
            ]
            status = queue_ditl.get_acs_queue_status()
        expected = {
            "queue_size": 2,
            "pending_commands": [
                {
                    "type": "SLEW_TO_TARGET",
                    "execution_time": 1000.0,
                    "time_formatted": "2023-01-01 00:00:00",
                },
                {
                    "type": "START_PASS",
                    "execution_time": 2000.0,
                    "time_formatted": "2023-01-01 00:33:20",
                },
            ],
            "current_slew": None,
            "acs_mode": "PASS",
        }
        assert status == expected

    def test_get_acs_queue_status_with_current_slew(self, queue_ditl) -> None:
        queue_ditl.acs.command_queue = []
        mock_slew = Mock()
        mock_slew.__class__.__name__ = "Slew"
        queue_ditl.acs.current_slew = mock_slew
        queue_ditl.acs.acsmode = ACSMode.SLEWING
        status = queue_ditl.get_acs_queue_status()
        expected = {
            "queue_size": 0,
            "pending_commands": [],
            "current_slew": "Slew",
            "acs_mode": "SLEWING",
        }
        assert status == expected

    def test_get_acs_queue_status_different_modes(self, queue_ditl) -> None:
        queue_ditl.acs.command_queue = []
        queue_ditl.acs.current_slew = None
        for mode in [ACSMode.SCIENCE, ACSMode.CHARGING, ACSMode.SAA]:
            queue_ditl.acs.acsmode = mode
            status = queue_ditl.get_acs_queue_status()
            assert status["acs_mode"] == mode.name

    def test_get_acs_queue_status_mixed_state(self, queue_ditl) -> None:
        mock_cmd = Mock()
        mock_cmd.command_type.name = "END_PASS"
        mock_cmd.execution_time = 1500.0
        queue_ditl.acs.command_queue = [mock_cmd]
        mock_slew = Mock()
        mock_slew.__class__.__name__ = "Pass"
        queue_ditl.acs.current_slew = mock_slew
        queue_ditl.acs.acsmode = ACSMode.PASS
        with patch(
            "conops.ditl.queue_ditl.unixtime2date", return_value="2023-01-01 00:25:00"
        ):
            status = queue_ditl.get_acs_queue_status()
        expected = {
            "queue_size": 1,
            "pending_commands": [
                {
                    "type": "END_PASS",
                    "execution_time": 1500.0,
                    "time_formatted": "2023-01-01 00:25:00",
                }
            ],
            "current_slew": "Pass",
            "acs_mode": "PASS",
        }
        assert status == expected


class TestTOOFunctionality:
    """Test Target of Opportunity (TOO) functionality in QueueDITL."""

    def test_too_request_model_creation_obsid(self, basic_too_request) -> None:
        """Test TOORequest model creation - obsid field."""
        assert basic_too_request.obsid == 1000001

    def test_too_request_model_creation_ra(self, basic_too_request) -> None:
        """Test TOORequest model creation - ra field."""
        assert basic_too_request.ra == 180.0

    def test_too_request_model_creation_dec(self, basic_too_request) -> None:
        """Test TOORequest model creation - dec field."""
        assert basic_too_request.dec == 45.0

    def test_too_request_model_creation_merit(self, basic_too_request) -> None:
        """Test TOORequest model creation - merit field."""
        assert basic_too_request.merit == 10000.0

    def test_too_request_model_creation_exptime(self, basic_too_request) -> None:
        """Test TOORequest model creation - exptime field."""
        assert basic_too_request.exptime == 3600

    def test_too_request_model_creation_name(self, basic_too_request) -> None:
        """Test TOORequest model creation - name field."""
        assert basic_too_request.name == "GRB 250101A"

    def test_too_request_model_creation_submit_time_default(
        self, basic_too_request
    ) -> None:
        """Test TOORequest model creation - submit_time default value."""
        assert basic_too_request.submit_time == 0.0  # default

    def test_too_request_model_creation_executed_default(
        self, basic_too_request
    ) -> None:
        """Test TOORequest model creation - executed default value."""
        assert basic_too_request.executed is False

    def test_too_request_with_custom_submit_time_value(
        self, custom_too_request
    ) -> None:
        """Test TOORequest with custom submit_time - check value."""
        assert custom_too_request.submit_time == 1234567890.0

    def test_too_request_with_custom_submit_time_executed(
        self, custom_too_request
    ) -> None:
        """Test TOORequest with custom submit_time - check executed flag."""
        assert custom_too_request.executed is True

    def test_submit_too_immediate_activation_register_length(
        self, queue_ditl, submitted_too
    ):
        """Test submit_too with immediate activation - check register length."""
        assert len(queue_ditl.too_register) == 1

    def test_submit_too_immediate_activation_register_content(
        self, queue_ditl, submitted_too
    ):
        """Test submit_too with immediate activation - check register content."""
        assert queue_ditl.too_register[0] == submitted_too

    def test_submit_too_immediate_activation_obsid(self, submitted_too) -> None:
        """Test submit_too with immediate activation - check obsid."""
        assert submitted_too.obsid == 1000001

    def test_submit_too_immediate_activation_submit_time(self, submitted_too) -> None:
        """Test submit_too with immediate activation - check submit_time."""
        assert submitted_too.submit_time == 0.0

    def test_submit_too_immediate_activation_executed(self, submitted_too) -> None:
        """Test submit_too with immediate activation - check executed flag."""
        assert submitted_too.executed is False

    def test_submit_too_with_unix_timestamp_submit_time(
        self, unix_timestamp_too
    ) -> None:
        """Test submit_too with Unix timestamp submit_time - check submit_time."""
        submit_time = 1640995200.0  # 2022-01-01 00:00:00 UTC
        assert unix_timestamp_too.submit_time == submit_time

    def test_submit_too_with_unix_timestamp_register_length(
        self, queue_ditl, unix_timestamp_too
    ):
        """Test submit_too with Unix timestamp submit_time - check register length."""
        assert len(queue_ditl.too_register) == 1

    def test_submit_too_with_datetime(self, queue_ditl) -> None:
        """Test submit_too with datetime submit_time."""
        from datetime import datetime, timezone

        submit_dt = datetime(2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        expected_timestamp = submit_dt.timestamp()

        too = queue_ditl.submit_too(
            obsid=1000003,
            ra=270.0,
            dec=60.0,
            merit=8000.0,
            exptime=2400,
            name="Datetime TOO",
            submit_time=submit_dt,
        )

        assert too.submit_time == expected_timestamp

    def test_submit_too_with_naive_datetime(self, queue_ditl) -> None:
        """Test submit_too with naive datetime (should be converted to UTC)."""
        from datetime import datetime, timezone

        submit_dt = datetime(2025, 1, 1, 12, 0, 0)  # naive datetime
        expected_timestamp = submit_dt.replace(tzinfo=timezone.utc).timestamp()

        too = queue_ditl.submit_too(
            obsid=1000004,
            ra=0.0,
            dec=0.0,
            merit=3000.0,
            exptime=1200,
            name="Naive datetime TOO",
            submit_time=submit_dt,
        )

        assert too.submit_time == expected_timestamp

    def test_submit_too_multiple_requests_length(
        self, queue_ditl, standard_too_params
    ) -> None:
        """Test submitting multiple TOO requests - check register length."""
        # Submit first TOO
        queue_ditl.submit_too(**standard_too_params)

        # Submit second TOO with different parameters
        queue_ditl.submit_too(
            obsid=1000002,
            ra=90.0,
            dec=-30.0,
            merit=5000.0,
            exptime=1800,
            name="TOO 2",
            submit_time=1000.0,
        )

        assert len(queue_ditl.too_register) == 2

    def test_submit_too_multiple_requests_first_too(
        self, queue_ditl, standard_too_params
    ):
        """Test submitting multiple TOO requests - check first TOO."""
        # Submit first TOO
        too1 = queue_ditl.submit_too(**standard_too_params)

        # Submit second TOO
        queue_ditl.submit_too(
            obsid=1000002,
            ra=90.0,
            dec=-30.0,
            merit=5000.0,
            exptime=1800,
            name="TOO 2",
            submit_time=1000.0,
        )

        assert queue_ditl.too_register[0] == too1

    def test_submit_too_multiple_requests_second_too(
        self, queue_ditl, standard_too_params
    ):
        """Test submitting multiple TOO requests - check second TOO."""
        # Submit first TOO
        queue_ditl.submit_too(**standard_too_params)

        # Submit second TOO
        too2 = queue_ditl.submit_too(
            obsid=1000002,
            ra=90.0,
            dec=-30.0,
            merit=5000.0,
            exptime=1800,
            name="TOO 2",
            submit_time=1000.0,
        )

        assert queue_ditl.too_register[1] == too2

    def test_submit_too_multiple_requests_first_submit_time(
        self, queue_ditl, standard_too_params
    ):
        """Test submitting multiple TOO requests - check first TOO submit time."""
        # Submit first TOO
        too1 = queue_ditl.submit_too(**standard_too_params)

        # Submit second TOO
        queue_ditl.submit_too(
            obsid=1000002,
            ra=90.0,
            dec=-30.0,
            merit=5000.0,
            exptime=1800,
            name="TOO 2",
            submit_time=1000.0,
        )

        assert too1.submit_time == 0.0

    def test_submit_too_multiple_requests_second_submit_time(
        self, queue_ditl, standard_too_params
    ):
        """Test submitting multiple TOO requests - check second TOO submit time."""
        # Submit first TOO
        queue_ditl.submit_too(**standard_too_params)

        # Submit second TOO
        too2 = queue_ditl.submit_too(
            obsid=1000002,
            ra=90.0,
            dec=-30.0,
            merit=5000.0,
            exptime=1800,
            name="TOO 2",
            submit_time=1000.0,
        )

        assert too2.submit_time == 1000.0

    def test_check_too_interrupt_no_pending_toos(self, queue_ditl) -> None:
        """Test _check_too_interrupt when no TOOs are pending."""
        result = queue_ditl._check_too_interrupt(utime=1000.0, ra=180.0, dec=45.0)
        assert result is False

    def test_check_too_interrupt_too_not_yet_active(self, queue_ditl) -> None:
        """Test _check_too_interrupt when TOO submit_time is in the future."""
        # Submit TOO with future submit_time
        queue_ditl.submit_too(
            obsid=1000001,
            ra=180.0,
            dec=45.0,
            merit=10000.0,
            exptime=3600,
            name="Future TOO",
            submit_time=2000.0,  # Future time
        )

        # Check at earlier time
        result = queue_ditl._check_too_interrupt(utime=1000.0, ra=180.0, dec=45.0)
        assert result is False

    def test_check_too_interrupt_too_already_executed(self, queue_ditl) -> None:
        """Test _check_too_interrupt when TOO has already been executed."""
        too = queue_ditl.submit_too(
            obsid=1000001,
            ra=180.0,
            dec=45.0,
            merit=10000.0,
            exptime=3600,
            name="Executed TOO",
        )
        too.executed = True  # Mark as executed

        result = queue_ditl._check_too_interrupt(utime=1000.0, ra=180.0, dec=45.0)
        assert result is False

    def test_check_too_interrupt_merit_too_low(self, queue_ditl) -> None:
        """Test _check_too_interrupt when TOO merit is lower than current observation."""
        # Submit TOO with low merit
        queue_ditl.submit_too(
            obsid=1000001,
            ra=180.0,
            dec=45.0,
            merit=100.0,  # Low merit
            exptime=3600,
            name="Low merit TOO",
        )

        # Set current PPT with higher merit
        from conops import Pointing

        queue_ditl.ppt = Pointing(
            config=queue_ditl.config,
            ra=0.0,
            dec=0.0,
            obsid=1,
            name="Current obs",
            merit=1000.0,  # Higher merit
            exptime=1800,
        )

        result = queue_ditl._check_too_interrupt(utime=1000.0, ra=180.0, dec=45.0)
        assert result is False

    @patch("conops.targets.pointing.Pointing.visibility")
    def test_check_too_interrupt_target_not_visible(
        self, mock_pointing_visible, mock_pointing_visibility, queue_ditl, submitted_too
    ):
        """Test _check_too_interrupt when TOO target is not visible."""
        mock_pointing_visible.return_value = False  # Target not visible

        result = queue_ditl._check_too_interrupt(utime=1000.0, ra=180.0, dec=45.0)
        assert result is False  # No interrupt should occur
        mock_pointing_visible.assert_called_once()

    def test_check_too_interrupt_successful_interrupt_result(
        self,
        mock_too_interrupt_success,
        queue_ditl,
        submitted_too,
        low_merit_current_ppt,
    ):
        """Test _check_too_interrupt when TOO successfully interrupts - check result."""
        # Mock queue.add to avoid actual queue operations
        with patch.object(queue_ditl.queue, "add"):
            result = queue_ditl._check_too_interrupt(utime=1000.0, ra=180.0, dec=45.0)

            assert result is True  # Should return True for successful interrupt

    def test_check_too_interrupt_successful_interrupt_executed(
        self, mock_too_interrupt_success, queue_ditl, low_merit_current_ppt
    ):
        """Test _check_too_interrupt when TOO successfully interrupts - check executed flag."""
        # Submit TOO with high merit
        too = queue_ditl.submit_too(
            obsid=1000001,
            ra=180.0,
            dec=45.0,
            merit=10000.0,
            exptime=3600,
            name="Successful TOO",
        )

        # Mock queue.add to avoid actual queue operations
        with patch.object(queue_ditl.queue, "add"):
            queue_ditl._check_too_interrupt(utime=1000.0, ra=180.0, dec=45.0)

            assert too.executed is True

    def test_check_too_interrupt_successful_interrupt_terminate_called(
        self, mock_too_interrupt_success, queue_ditl, low_merit_current_ppt
    ):
        """Test _check_too_interrupt when TOO successfully interrupts - check terminate called."""
        # Submit TOO with high merit
        queue_ditl.submit_too(
            obsid=1000001,
            ra=180.0,
            dec=45.0,
            merit=10000.0,
            exptime=3600,
            name="Successful TOO",
        )

        # Mock queue.add to avoid actual queue operations
        with patch.object(queue_ditl.queue, "add"):
            queue_ditl._check_too_interrupt(utime=1000.0, ra=180.0, dec=45.0)

            mock_too_interrupt_success["terminate"].assert_called_once_with(
                1000.0,
                reason="Preempted by TOO Successful TOO (obsid=1000001)",
                mark_done=False,
            )

    def test_check_too_interrupt_successful_interrupt_queue_add_called(
        self, mock_too_interrupt_success, queue_ditl, low_merit_current_ppt
    ):
        """Test _check_too_interrupt when TOO successfully interrupts - check queue.add called."""
        # Submit TOO with high merit
        queue_ditl.submit_too(
            obsid=1000001,
            ra=180.0,
            dec=45.0,
            merit=10000.0,
            exptime=3600,
            name="Successful TOO",
        )

        # Mock queue.add to avoid actual queue operations
        with patch.object(queue_ditl.queue, "add") as mock_queue_add:
            queue_ditl._check_too_interrupt(utime=1000.0, ra=180.0, dec=45.0)

            mock_queue_add.assert_called_once_with(
                ra=180.0,
                dec=45.0,
                obsid=1000001,
                name="Successful TOO",
                merit=110000.0,  # Original merit + 100000 boost
                exptime=3600,
            )

    def test_check_too_interrupt_successful_interrupt_fetch_called(
        self, mock_too_interrupt_success, queue_ditl, low_merit_current_ppt
    ):
        """Test _check_too_interrupt when TOO successfully interrupts - check fetch called."""
        # Submit TOO with high merit
        queue_ditl.submit_too(
            obsid=1000001,
            ra=180.0,
            dec=45.0,
            merit=10000.0,
            exptime=3600,
            name="Successful TOO",
        )

        # Mock queue.add to avoid actual queue operations
        with patch.object(queue_ditl.queue, "add"):
            queue_ditl._check_too_interrupt(utime=1000.0, ra=180.0, dec=45.0)

            mock_too_interrupt_success["fetch"].assert_called_once_with(
                1000.0, 180.0, 45.0
            )

    def test_check_too_interrupt_no_current_observation_result(
        self, mock_too_interrupt_no_current_obs, queue_ditl
    ):
        """Test _check_too_interrupt when there is no current observation - check result."""
        # Submit TOO
        queue_ditl.submit_too(
            obsid=1000001,
            ra=180.0,
            dec=45.0,
            merit=10000.0,
            exptime=3600,
            name="TOO without current obs",
        )

        # No current PPT (queue_ditl.ppt is None)

        with patch.object(queue_ditl.queue, "add"):
            result = queue_ditl._check_too_interrupt(utime=1000.0, ra=180.0, dec=45.0)

            assert result is True  # Should return True for successful interrupt

    def test_check_too_interrupt_no_current_observation_executed(
        self, mock_too_interrupt_no_current_obs, queue_ditl
    ):
        """Test _check_too_interrupt when there is no current observation - check executed flag."""
        # Submit TOO
        too = queue_ditl.submit_too(
            obsid=1000001,
            ra=180.0,
            dec=45.0,
            merit=10000.0,
            exptime=3600,
            name="TOO without current obs",
        )

        # No current PPT (queue_ditl.ppt is None)

        with patch.object(queue_ditl.queue, "add"):
            queue_ditl._check_too_interrupt(utime=1000.0, ra=180.0, dec=45.0)

            assert too.executed is True

    def test_check_too_interrupt_no_current_observation_queue_add_called(
        self, mock_too_interrupt_no_current_obs, queue_ditl
    ):
        """Test _check_too_interrupt when there is no current observation - check queue.add called."""
        # Submit TOO
        queue_ditl.submit_too(
            obsid=1000001,
            ra=180.0,
            dec=45.0,
            merit=10000.0,
            exptime=3600,
            name="TOO without current obs",
        )

        # No current PPT (queue_ditl.ppt is None)

        with patch.object(queue_ditl.queue, "add") as mock_queue_add:
            queue_ditl._check_too_interrupt(utime=1000.0, ra=180.0, dec=45.0)

            mock_queue_add.assert_called_once()

    def test_check_too_interrupt_no_current_observation_fetch_called(
        self, mock_too_interrupt_no_current_obs, queue_ditl
    ):
        """Test _check_too_interrupt when there is no current observation - check fetch called."""
        # Submit TOO
        queue_ditl.submit_too(
            obsid=1000001,
            ra=180.0,
            dec=45.0,
            merit=10000.0,
            exptime=3600,
            name="TOO without current obs",
        )

        # No current PPT (queue_ditl.ppt is None)

        with patch.object(queue_ditl.queue, "add"):
            queue_ditl._check_too_interrupt(utime=1000.0, ra=180.0, dec=45.0)

            mock_too_interrupt_no_current_obs["fetch"].assert_called_once_with(
                1000.0, 180.0, 45.0
            )

    def test_too_request_pydantic_validation_valid(self) -> None:
        """Test TOORequest Pydantic validation - valid creation."""
        from conops.ditl import TOORequest

        # Valid TOO
        too = TOORequest(
            obsid=1000001,
            ra=180.0,
            dec=45.0,
            merit=10000.0,
            exptime=3600,
            name="Valid TOO",
        )
        assert too.obsid == 1000001

    def test_too_request_pydantic_validation_invalid_obsid(self) -> None:
        """Test TOORequest Pydantic validation - invalid obsid type."""
        from pydantic import ValidationError

        from conops.ditl import TOORequest

        # Test validation errors
        with pytest.raises(ValidationError):
            TOORequest(
                obsid="invalid",  # type: ignore[arg-type]  # Should be int
                ra=180.0,
                dec=45.0,
                merit=10000.0,
                exptime=3600,
                name="Invalid TOO",
            )

    def test_too_request_model_dump(self) -> None:
        """Test TOORequest model_dump method."""
        from conops.ditl import TOORequest

        too = TOORequest(
            obsid=1000001,
            ra=180.0,
            dec=45.0,
            merit=10000.0,
            exptime=3600,
            name="Test TOO",
            submit_time=1234567890.0,
            executed=True,
        )

        data = too.model_dump()
        expected = {
            "obsid": 1000001,
            "ra": 180.0,
            "dec": 45.0,
            "merit": 10000.0,
            "exptime": 3600,
            "name": "Test TOO",
            "submit_time": 1234567890.0,
            "executed": True,
        }
        assert data == expected


class TestQueueDITLCoverage:
    """Test cases to achieve 100% coverage for QueueDITL."""

    def test_queue_log_assignment_when_none(self, queue_ditl_no_queue_log) -> None:
        """Test that queue.log is assigned when provided queue has no log (line 112)."""
        # The fixture already tests this by creating a QueueDITL with queue.log = None
        # and verifying it gets assigned during initialization
        assert queue_ditl_no_queue_log.queue.log is not None

    def test_acs_ephem_assignment_when_none(self, queue_ditl_acs_no_ephem) -> None:
        """Test that acs.ephem is assigned when ACS has no ephem (line 377)."""
        # Manually trigger the ephem assignment that happens in run()
        queue_ditl_acs_no_ephem.acs.ephem = queue_ditl_acs_no_ephem.ephem
        assert queue_ditl_acs_no_ephem.acs.ephem is not None

    def test_handle_science_mode_called(self, mock_config, mock_ephem) -> None:
        """Test that _handle_science_mode is called for SCIENCE mode (line 506)."""
        with (
            patch("conops.Queue") as mock_queue_class,
            patch("conops.PassTimes") as mock_passtimes,
            patch("conops.ACS") as mock_acs_class,
            patch.object(QueueDITL, "_handle_science_mode") as mock_handle_science,
        ):
            # Mock PassTimes
            mock_pt = Mock()
            mock_pt.passes = []
            mock_pt.get = Mock()
            mock_pt.check_pass_timing = Mock(
                return_value={
                    "start_pass": None,
                    "end_pass": False,
                    "updated_pass": None,
                }
            )
            mock_passtimes.return_value = mock_pt

            # Mock ACS
            mock_acs = Mock()
            mock_acs.ephem = mock_ephem
            mock_acs.slewing = False
            mock_acs.inpass = False
            mock_acs.saa = None
            mock_acs.pointing = Mock(return_value=(0.0, 0.0, 0.0, 0))
            mock_acs.enqueue_command = Mock()
            mock_acs.passrequests = mock_pt
            mock_acs.slew_dists = []
            mock_acs.last_slew = None
            from conops import ACSMode

            mock_acs.acsmode = ACSMode.SCIENCE
            mock_acs.in_safe_mode = False
            mock_acs_class.return_value = mock_acs

            # Mock solar panel
            mock_config.solar_panel.illumination_and_power = Mock(
                return_value=(0.5, 100.0)
            )

            # Mock Queue
            mock_queue = Mock()
            mock_queue.get = Mock(return_value=None)
            mock_queue_class.return_value = mock_queue

            ditl = QueueDITL(config=mock_config, ephem=mock_ephem, queue=mock_queue)
            ditl.acs = mock_acs

            # Call _handle_mode_operations with SCIENCE mode
            ditl._handle_mode_operations(ACSMode.SCIENCE, 1000.0, 0.0, 0.0)

            # Verify _handle_science_mode was called
            mock_handle_science.assert_called_once_with(
                1000.0, 0.0, 0.0, ACSMode.SCIENCE
            )

    def test_too_interrupt_return_early(
        self, mock_config, mock_ephem, mock_too_interrupt_success
    ):
        """Test that _handle_science_mode returns early when TOO interrupt occurs (line 522)."""
        with (
            patch("conops.Queue") as mock_queue_class,
            patch("conops.PassTimes") as mock_passtimes,
            patch("conops.ACS") as mock_acs_class,
            patch.object(QueueDITL, "_manage_ppt_lifecycle") as mock_manage_ppt,
            patch.object(QueueDITL, "_fetch_new_ppt") as mock_fetch_ppt,
        ):
            # Mock PassTimes
            mock_pt = Mock()
            mock_pt.passes = []
            mock_pt.get = Mock()
            mock_pt.check_pass_timing = Mock(
                return_value={
                    "start_pass": None,
                    "end_pass": False,
                    "updated_pass": None,
                }
            )
            mock_passtimes.return_value = mock_pt

            # Mock ACS
            mock_acs = Mock()
            mock_acs.ephem = mock_ephem
            mock_acs.slewing = False
            mock_acs.inpass = False
            mock_acs.saa = None
            mock_acs.pointing = Mock(return_value=(0.0, 0.0, 0.0, 0))
            mock_acs.enqueue_command = Mock()
            mock_acs.passrequests = mock_pt
            mock_acs.slew_dists = []
            mock_acs.last_slew = None
            from conops import ACSMode

            mock_acs.acsmode = ACSMode.SCIENCE
            mock_acs.in_safe_mode = False
            mock_acs_class.return_value = mock_acs

            # Mock solar panel
            mock_config.solar_panel.illumination_and_power = Mock(
                return_value=(0.5, 100.0)
            )

            # Mock Queue
            mock_queue = Mock()
            mock_queue.get = Mock(return_value=None)
            mock_queue_class.return_value = mock_queue

            ditl = QueueDITL(config=mock_config, ephem=mock_ephem, queue=mock_queue)
            ditl.acs = mock_acs

            # Mock _check_too_interrupt to return True (interrupt occurred)
            with patch.object(ditl, "_check_too_interrupt", return_value=True):
                # Call _handle_science_mode
                ditl._handle_science_mode(1000.0, 0.0, 0.0, ACSMode.SCIENCE)

                # Verify that PPT lifecycle management and fetching were NOT called
                mock_manage_ppt.assert_not_called()
                mock_fetch_ppt.assert_not_called()

    def test_pass_ending_logic_triggered(self, mock_config, mock_ephem) -> None:
        """Test pass ending logic when previous pass existed but current doesn't (lines 631-642)."""
        with (
            patch("conops.Queue") as mock_queue_class,
            patch("conops.PassTimes") as mock_passtimes,
            patch("conops.ACS") as mock_acs_class,
            patch("conops.ACSCommand"),
            patch("conops.ACSCommandType"),
        ):
            # Mock PassTimes with current_pass logic
            mock_pt = Mock()
            mock_pt.passes = []
            mock_pt.get = Mock()
            # Simulate: previous step had a pass, current step doesn't
            mock_pt.current_pass = Mock(
                side_effect=lambda t: Mock() if t < 1000.0 else None
            )
            mock_pt.check_pass_timing = Mock(
                return_value={
                    "start_pass": None,
                    "end_pass": False,
                    "updated_pass": None,
                }
            )
            mock_passtimes.return_value = mock_pt

            # Mock ACS
            mock_acs = Mock()
            mock_acs.ephem = mock_ephem
            mock_acs.slewing = False
            mock_acs.inpass = False
            mock_acs.saa = None
            mock_acs.pointing = Mock(return_value=(0.0, 0.0, 0.0, 0))
            mock_acs.enqueue_command = Mock()
            mock_acs.passrequests = mock_pt
            mock_acs.slew_dists = []
            mock_acs.last_slew = None
            from conops import ACSMode

            mock_acs.acsmode = ACSMode.SCIENCE
            mock_acs.in_safe_mode = False
            mock_acs_class.return_value = mock_acs

            # Mock solar panel
            mock_config.solar_panel.illumination_and_power = Mock(
                return_value=(0.5, 100.0)
            )

            # Mock Queue
            mock_queue = Mock()
            mock_queue.get = Mock(return_value=None)
            mock_queue_class.return_value = mock_queue

            ditl = QueueDITL(config=mock_config, ephem=mock_ephem, queue=mock_queue)
            ditl.acs = mock_acs

            # Call _check_and_manage_passes with utime where pass just ended
            ditl._check_and_manage_passes(1000.0, 0.0, 0.0)

            # Verify END_PASS command was enqueued
            mock_acs.enqueue_command.assert_called_once()
            call_args = mock_acs.enqueue_command.call_args[0][0]
            assert call_args.command_type == ACSCommandType.END_PASS
            assert call_args.execution_time == 1000.0

    # def test_pass_slewing_logic_triggered(self, mock_config, mock_ephem) -> None:
    #     """Test pass slewing logic when it's time to slew to next pass (lines 655-679)."""
    #     # NOTE: This test was removed due to patching issues with relative imports
    #     # The pass slewing logic is tested indirectly through integration tests

    def test_charging_ppt_constraint_check(self, mock_config, mock_ephem) -> None:
        """Test charging PPT constraint checking (lines 717-727)."""
        with (
            patch("conops.Queue") as mock_queue_class,
            patch("conops.PassTimes") as mock_passtimes,
            patch("conops.ACS") as mock_acs_class,
            patch.object(QueueDITL, "_get_constraint_name") as mock_get_constraint,
            patch.object(QueueDITL, "_terminate_emergency_charging") as mock_terminate,
        ):
            # Mock PassTimes
            mock_pt = Mock()
            mock_pt.passes = []
            mock_pt.get = Mock()
            mock_pt.check_pass_timing = Mock(
                return_value={
                    "start_pass": None,
                    "end_pass": False,
                    "updated_pass": None,
                }
            )
            mock_passtimes.return_value = mock_pt

            # Mock ACS
            mock_acs = Mock()
            mock_acs.ephem = mock_ephem
            mock_acs.slewing = False
            mock_acs.inpass = False
            mock_acs.saa = None
            mock_acs.pointing = Mock(return_value=(0.0, 0.0, 0.0, 0))
            mock_acs.enqueue_command = Mock()
            mock_acs.passrequests = mock_pt
            mock_acs.slew_dists = []
            mock_acs.last_slew = None
            from conops import ACSMode

            mock_acs.acsmode = ACSMode.SCIENCE
            mock_acs_class.return_value = mock_acs

            # Mock solar panel
            mock_config.solar_panel.illumination_and_power = Mock(
                return_value=(0.5, 100.0)
            )

            # Mock Queue
            mock_queue = Mock()
            mock_queue.get = Mock(return_value=None)
            mock_queue_class.return_value = mock_queue

            # Mock constraint
            mock_config.constraint.in_constraint = Mock(return_value=True)
            mock_get_constraint.return_value = "SAA"

            ditl = QueueDITL(config=mock_config, ephem=mock_ephem, queue=mock_queue)
            ditl.acs = mock_acs

            # Set up charging PPT
            mock_charging_ppt = Mock()
            mock_charging_ppt.ra = 10.0
            mock_charging_ppt.dec = 20.0
            mock_charging_ppt.obsid = 12345  # Fix: use int instead of Mock
            ditl.charging_ppt = mock_charging_ppt
            ditl.ppt = mock_charging_ppt  # Currently charging

            # Call _manage_ppt_lifecycle
            ditl._manage_ppt_lifecycle(1000.0, ACSMode.SCIENCE)

            # Verify constraint check and termination
            mock_config.constraint.in_constraint.assert_called_once_with(
                10.0, 20.0, 1000.0, target_roll=mock_acs.roll, acs_mode=ACSMode.CHARGING
            )
            mock_get_constraint.assert_called_once_with(
                10.0, 20.0, 1000.0, roll=mock_acs.roll, mode=ACSMode.CHARGING
            )
            mock_terminate.assert_called_once_with("constraint", 1000.0)

    def test_slew_visibility_check_rejection(self, mock_config, mock_ephem) -> None:
        """Test slew visibility check that rejects slew when target not visible (lines 844-851)."""
        with (
            patch("conops.Queue") as mock_queue_class,
            patch("conops.PassTimes") as mock_passtimes,
            patch("conops.ACS") as mock_acs_class,
            patch("conops.Slew"),
        ):
            # Mock PassTimes
            mock_pt = Mock()
            mock_pt.passes = []
            mock_pt.get = Mock()
            mock_pt.check_pass_timing = Mock(
                return_value={
                    "start_pass": None,
                    "end_pass": False,
                    "updated_pass": None,
                }
            )
            mock_passtimes.return_value = mock_pt

            # Mock ACS
            mock_acs = Mock()
            mock_acs.ephem = mock_ephem
            mock_acs.slewing = False
            mock_acs.inpass = False
            mock_acs.saa = None
            mock_acs.pointing = Mock(return_value=(0.0, 0.0, 0.0, 0))
            mock_acs.enqueue_command = Mock()
            mock_acs.passrequests = mock_pt
            mock_acs.slew_dists = []
            mock_acs.last_slew = None
            mock_acs.ra = 0.0
            mock_acs.dec = 0.0
            from conops import ACSMode

            mock_acs.acsmode = ACSMode.SCIENCE
            mock_acs_class.return_value = mock_acs

            # Mock solar panel
            mock_config.solar_panel.illumination_and_power = Mock(
                return_value=(0.5, 100.0)
            )

            # Mock Queue
            mock_queue = Mock()
            mock_queue.get = Mock(return_value=None)
            mock_queue_class.return_value = mock_queue

            # Mock PPT with visibility check failing
            mock_ppt = Mock()
            mock_ppt.next_vis = Mock(return_value=None)  # Not visible
            mock_ppt.obsid = 12345

            ditl = QueueDITL(config=mock_config, ephem=mock_ephem, queue=mock_queue)
            ditl.acs = mock_acs
            ditl.ppt = mock_ppt

            # Call _fetch_new_ppt which should trigger the visibility check
            ditl._fetch_new_ppt(1000.0, 0.0, 0.0)

            # Verify that enqueue_command was NOT called (slew rejected)
            mock_acs.enqueue_command.assert_not_called()
