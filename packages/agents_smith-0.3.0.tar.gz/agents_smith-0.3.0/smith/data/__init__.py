"""Bundled template data package."""
