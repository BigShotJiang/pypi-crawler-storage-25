# CLAUDE.md — Efterlev

This file is your persistent context for working on Efterlev. Read it at the start of every session.

---

## What we're building

**Efterlev** is a repo-native, agent-first compliance scanner for FedRAMP 20x. It runs locally in the developer's codebase and CI pipeline — not in a SaaS dashboard — and produces code-level evidence, FRMR-compatible attestation drafts, and code-level remediation diffs. The internal abstraction is the **Key Security Indicator (KSI)** — the outcome-based unit FedRAMP 20x is built around. Detectors evidence KSIs; KSIs reference 800-53 controls; the user-facing surface speaks KSIs.

The name is a shortening of the Swedish *efterlevnad* (compliance). Pronounce it "EF-ter-lev."

**Primary user (the ICP lens for every product decision):** a SaaS company (50–200 engineers) pursuing its first FedRAMP Moderate authorization, with a committed federal deal on the line. Full ICP at `docs/icp.md` — read it before proposing features, because the ICP is how we decide what Efterlev does and doesn't do.

License: Apache 2.0. No commercial tier, no managed SaaS, no paid layer. Pure OSS, throughout.

---

## Current state

**v0.1.105 is current** (shipped 2026-05-14). Public on GitHub at `efterlev/efterlev`, on PyPI as `efterlev`, on `ghcr.io/efterlev/efterlev` (multi-arch, cosign-signed + cosign-verifiable SLSA build provenance from v0.1.13; wheel + sdist CycloneDX SBOMs attached to every GitHub Release from v0.1.57; ALL third-party Actions SHA-pinned with no exceptions from v0.1.62; pip-audit + bandit lockfile-pinned in [dev] extra from v0.1.61; eval-harness Phase 2 lite scaffolding shipped from v0.1.63 + 67 draft labels across 3 real-shape fixtures from v0.1.64-v0.1.66 + second-pass label review with 6 revisions from v0.1.67 + documentation audit sweep from v0.1.68 + maintainer-validation pass from v0.1.69 + CFN/CDK synth-mode DECISIONS entry from v0.1.70 + README tagline rephrase from v0.1.71 + Tier 5 #1 PR beta: CFN parser + adapter + scan integration + first vendored CFN fixture from v0.1.72 + Tier 5 #1 PR gamma: CFN→TF property-mapping table covering 3 resource types with parity-tested Evidence emission from v0.1.73 + Tier 5 #1 PR gamma.2 batches 1-4 expanding the property-mapping table to 18 CFN types across 13 AWS namespaces from v0.1.74-v0.1.77 + CFN eval-harness Phase 2 lite scaffolding with the first labeled CFN fixture `csp-starter-cfn` from v0.1.78 + doc-quality sweep lifting the value-prop above the install commands + improving the keyless-quickstart footer + adding README troubleshooting from v0.1.79 + README/LIMITATIONS CFN-support honesty pass making the lede + Scans bullet + comparison table + LIMITATIONS section honest about TF-validated/CFN-experimental dual support from v0.1.80 + CFN maintainer-validation harness + first dispatch run scoring 23/23 = 100/100 (matching the v0.1.69 TF baseline) + second-pass label review removing 2 typo KSIs + closing the strategic gate from v0.1.81 + README visual content lifting a real Gap Report screenshot + POA&M markdown snippet inline from v0.1.82 + README/docs accuracy patch correcting 22/22 → 23/23 (CI authoritative) and patch-count off-by-one from v0.1.83 + UX-polish bundle (cost rollup at end of report run + quickstart, doctor CFN-template detection check, doctor wrong-shape API key escalation to fail when backend=anthropic, init next-steps section) from v0.1.84 + Documentation Agent narrative quality polish (per-KSI-family procedural-evidence hints in deterministic inapplicable template — AFR/CED/INR/PIY each get specific 3PAO-actionable guidance) from v0.1.85 + Streaming-tokens-as-progress for Gap Agent — closes the silent-for-60-90s UX gap by regex-extracting KSI IDs from the streaming JSON and printing per-KSI lines as the model emits classifications, from v0.1.86 + GitHub Actions minute-budget reduction 3-fix bundle: release-smoke matrix slim 7→4 cells, dropped ci.yml `push:` trigger that double-fired the lint/type-check/test job on every PR, e2e-smoke version-bump-only filter to skip the harness when `__init__.py` is the only changed file under `src/`, from v0.1.87 + release-smoke signature-verify cosign-installer pin to v3.0.6 — default cosign v2.5.2 can't verify SLSA v1 attestations from `actions/attest-build-provenance`; v0.1.87 release exposed this latent bug because pre-v0.1.87 release-smoke runs were stuck queued on the macos-13 cell that v0.1.87 dropped, from v0.1.88 + cosign-installer action bump v3 → v4.1.2 — v0.1.88's `cosign-release: 'v3.0.6'` pin failed because v3-action's installer 404s on `cosign-linux-amd64.sig` (cosign v3 dropped .sig files; uses .sigstore.json bundles); v4.0+ added cosign v3 install support, v4.1.2 defaults to cosign v3.0.6, from v0.1.89 + CFN PR gamma.2 batch 5 covering the WAF family (5 CFN types — WAFv2::WebACL with deep Rules→rule[N] and Statement→statement[0] translation for GeoMatchStatement/RateBasedStatement/ManagedRuleGroupStatement/IPSetReferenceStatement/RuleGroupReferenceStatement, plus WAFv2::WebACLAssociation/RuleGroup, legacy WAF::WebACL v1, Shield::Protection — unlocks 8 detectors, highest-impact batch in the gamma.2 series, from v0.1.90 + CFN PR gamma.2 batch 6 covering RDS Cluster + EC2 NetworkAcl pair + EC2 Instance — AWS::RDS::DBCluster (sibling to DBInstance, flat renames), AWS::EC2::NetworkAcl + AWS::EC2::NetworkAclEntry (CFN splits NACL across two resource types; Entry maps to standalone aws_network_acl_rule), AWS::EC2::Instance (with MetadataOptions list-wrapped block + BlockDeviceMappings → ebs_block_device list; all EBS mappings go to ebs_block_device — root-vs-non-root heuristic deferred — detectors flag unencrypted volumes either way), 4 mappings unlock 7 detectors, from v0.1.91 + CFN PR gamma.2 batch 7 covering IAM Group (1→(1+N+M) synthesis pattern same as IAM Role/User from batch 2) + API Gateway v1 Stage (singular AccessLogSetting → access_log_settings; tf_type override since cfn_type_to_tf_type yields aws_apigateway_stage) + v2 Stage (plural AccessLogSettings; default tf_type already correct) + v1 Method (AuthorizationType → authorization since TF v1 schema flattens the suffix; tf_type override) + v2 Route (AuthorizationType → authorization_type since v2 keeps the suffix), 5 mappings unlock 7 detectors, from v0.1.92 + CFN PR gamma.2 batch 8 (finishing batch) covering all 30 remaining detector-referenced CFN types in one PR — API Gateway DomainName v1/v2, AccessAnalyzer, GuardDuty, Config Recorder + DeliveryChannel, CloudWatch Alarm, Events Rule (1→1+N synthesis for Targets), DocDB / Neptune / ElastiCache×2 / EFS, EC2 LaunchTemplate (LaunchTemplateData unwrap) / VPC / Subnet / SecurityGroupIngress, ELBv2 + ELB Classic with LoadBalancerAttributes-key/value-list → access_logs[0]-block translation, IAM SAML + OIDC providers, Backup family (Plan with rule-list translation, Vault, Selection, RestoreTesting Plan + Selection), Logs::ResourcePolicy, SecretsManager::RotationSchedule, AutoScaling::AutoScalingGroup, ECS::Service. **CFN type-coverage CLOSED — every detector reachable from CFN.** 43 new parity tests; pytest 1689 → 1732. AWS::IAM::AccountPasswordPolicy documented as unmappable (account-level setting, not a CFN resource), from v0.1.93 + repo-content cleanup removing COMPETITIVE_LANDSCAPE.md + docs/comparisons/* + docs/dual_horizon_plan.md and scrubbing all "hackathon" references (file never shipped a public hackathon; the framing was inappropriate), from v0.1.94 + CFN graduation arc step 1: detector parity audit (docs/cfn-detector-parity.csv + .md, generated by scripts/build_cfn_parity_table.py — 92% effective coverage, with honest correction that v0.1.93 "CFN coverage CLOSED" claim was off by 8 types — 5 detectors have real gaps, mostly centralized_log_aggregation reading 7 unmapped CFN types and 2 IAM detectors needing AWS::IAM::AccessKey), from v0.1.95 + CFN graduation arc step 1.5: closed all 8 missing CFN mappings — AWS::IAM::AccessKey, AWS::Logs::Destination, AWS::Logs::SubscriptionFilter, AWS::OpenSearchService::Domain, AWS::Elasticsearch::Domain, AWS::KinesisFirehose::DeliveryStream, AWS::SecurityHub::Hub (TF name-asymmetry: aws_securityhub_account), AWS::SecurityHub::FindingAggregator. CFN coverage now genuinely 100% (47 full + 11 partial-by-design + 2 TF-only-by-design = 60/60), from v0.1.96 + CFN graduation arc step 2: 2nd labeled CFN fixture aws-vpc-cfn (vendored AWS Quick Start VPC) with maintainer-draft labels mirroring aws-vpc-tfm — closes the validation-breadth gap from 23 labels (1 fixture) toward ~50 (matches TF baseline shape; final number TBD when aws-vpc-cfn dispatch lands), from v0.1.97 + CFN graduation arc step 2 (validation): aws-vpc-cfn maintainer-validation dispatch on Anthropic API + Haiku 4.5 hit **21/21 = 100% precision + 100% recall** against revision-1 labels — combined with v0.1.81's 23/23 the CFN side now stands at **44/44 = 100% across 2 fixtures**, matching TF baseline shape; CFN graduation arc step 2 COMPLETE, from v0.1.98 + CFN graduation arc step 3: **CFN scanning is now default-on**. `--allow-cfn` flag deprecated (Optional[bool] sentinel detects explicit pass; emits warning to stderr; will be removed in v0.2.0). `--no-allow-cfn` accepted for explicit opt-out (same posture as pre-v0.1.99 default). Removed "experimental" framing from README + LIMITATIONS + doctor's CFN-template-detection check (now reports "will be scanned by default" instead of warn-with-flag-hint), from v0.1.99 + post-graduation doc cleanup: fixed 5 stale CFN claims surfaced by post-v0.1.99 audit — docs/faq.md said "Terraform/OpenTofu only... CFN is roadmap"; docs/architecture.md said "CloudFormation/K8s/runtime in v1.5+"; README Status para narrated arc up to v0.1.81 only (no mention of v0.1.95-99 graduation); PHASE_2_LITE_CFN_VALIDATION.md called doc graduation "next arc release"; evals/harness.py still appended --allow-cfn (would emit deprecation warning every run). Removed _fixture_has_cfn_templates as dead code, from v0.1.100 + verify-release.sh retry-and-wait fix (5min retry on the cosign sig + SLSA attestation checks at scripts/verify-release.sh; closes the recurring release-smoke `signature-verify` timing race that hit v0.1.87 and v0.1.99 — `cosign verify` would race the release-container.yml workflow's ghcr push), from v0.1.101 + CFN graduation arc step 4: removed the `--allow-cfn` flag entirely. CFN now scans unconditionally. Shipped as v0.1.102 (not v0.2.0) per DECISIONS commitments reserving v0.2.0 for the eval-harness-as-user-feature substantive arc, from v0.1.102 + QA-surfaced bundle: scanned aws-quickstart/quickstart-aws-aurora-postgresql for internal QA, surfaced 3 real bugs and fixed all — Rules-section intrinsics (!ValueOf, !RefAll, !EachMemberEquals, !EachMemberIn, !Contains, !ValueOfAll) registered in _CfnSafeLoader (parser used to crash on !ValueOf and silently drop the 1091-line template); parse failures now surfaced in scan summary; AWS::CloudFormation::Stack nested-stack count surfaced (TemplateURL not followed — limitation made visible). Same-fixture re-scan: 1→2 templates, 3→24 resources, 1→19 evidence records, from v0.1.103 + SAM transparency note: AWS::Serverless::* types (Transform: AWS::Serverless-2016-10-31 dialect) fall through the unmapped-fallback path; documented in LIMITATIONS.md as a deferred-pending-customer-driver gap rather than ship speculative SAM property mappings, from v0.1.104 + OSCAL output arc step 1: shipped `efterlev oscal export --kind poam` emitting OSCAL 1.0.4 POA&M JSON conforming to FedRAMP-current schema. New CLI subcommand (oscal_app) under `efterlev oscal`; new primitive `generate_poam_oscal` in src/efterlev/primitives/generate/. Deterministic UUIDs via uuid5 from a fixed namespace + KSI/control identifiers (re-runs of same scan produce stable diffs — important for downstream consumers like RegScale OSCAL Hub that may detect "changes" via UUID comparison). 10 new tests; pytest 1749 → 1759. component-definition + partial-SSP planned for v0.1.107+; reserves v0.1.106 for GSA fedramp-automation Schematron validation in CI, from v0.1.105). One hundred and six patch releases since v0.1.0 (2026-04-29).

The v0.1.x patch arc closed real-CI bugs surfaced by deep-dive shakedowns against the canonical dogfood target (govnotes-demo) and external real-Terraform shakedowns (terraform-aws-vpc, fully-private-cluster). Each release fixed cross-component bugs unit tests had missed: max_tokens truncation, doc-agent dual-emit on multi-gap-run workspaces, boundary-state propagation on stale evidence, IAM `aws_iam_policy_document` data-source resolution, and many more. The release-blocker rate converged to 0 by v0.1.7 and stayed there. **v0.1.11 was the first release driven by an external 3PAO blinded review** rather than dogfood shakedown — five rendering / display / persistence findings, all closed at the artifact layer with no scanner-output behavior change. **v0.1.12 closed four findings from a deterministic, zero-LLM post-release validation of v0.1.11** — verify-release.sh wired to PEP 740 (PyPI side), subdir-scan ancestor warning, unparseable-evidence plan-JSON hint, doc drift in ai-quickstart-prompt.md. **v0.1.13 fixed a missing `attestations: write` permission on `release-container.yml`** that prevented v0.1.12's new SLSA-attestation step from firing — verify-release.sh check 3 starts passing on v0.1.13 container artifacts. **v0.1.16 codified the post-release-triage methodology** as `scripts/triage.sh` + `.github/workflows/post-release-triage.yml` — auto-runs on every tag push, posts a verifiable-quality report to the GitHub Release notes body. See `CHANGELOG.md` for per-release detail.

**v0.1.18–v0.1.21: Tier 1 #1–#3 delivery.** Shipped the activation/audit/manifest half of the Tier 1 sequence locked in DECISIONS 2026-05-06: `efterlev quickstart` (one-command activation demo, v0.1.18); end-of-run cost summary on agent commands (v0.1.19); `--dry-run` / `--dump-prompt` on agent commands (v0.1.20); 24-template Evidence Manifest starter pack with `efterlev manifests init --starter-pack` (v0.1.21).

**v0.1.22–v0.1.27: matrix-visibility cascade.** A single discovery — that `release-smoke` had been silently red across every cell on v0.1.20 + v0.1.21 because the workflow_run row in `gh run list` collapses matrix state to one column — turned into a six-release cascade. Each fix surfaced the next layer of platform-specific bug that the silent matrix had been masking: assertion script (v0.1.22) → workflow env + trigger gate + Windows fcntl + docker-ghcr ?mode=ro (v0.1.23) → WAL-mode &immutable=1 (v0.1.24) → Windows charmap on read (v0.1.25) → Windows msvcrt.locking O_APPEND (v0.1.26) → Windows charmap on write (v0.1.27). v0.1.27's matrix lands green across pipx + docker-ghcr × mac/win/linux/arm. Auto-triage T7 surfaces matrix conclusion on the GH Release page so silent regressions cannot recur. See six DECISIONS 2026-05-07 entries for the full cascade.

**v0.1.28–v0.1.34: Tier 1 #4 detector backlog.** Per DECISIONS 2026-05-07 "Tier 1 #4 design: detector gap analysis", classified all 30 currently-uncovered KSIs as `evidenceable-via-iac` / `partial` / `procedural-only`, then shipped 6 detectors closing the IaC-evidenceable gaps: `aws.cna_optimizing_for_availability` (KSI-CNA-OFA, v0.1.28); `aws.mla_log_access_least_privilege` (KSI-MLA-ALA, v0.1.30); `aws.cna_dos_protection` (KSI-CNA-RVP, v0.1.31); `aws.svc_at_rest_encryption_coverage` (KSI-SVC-PRR, v0.1.32); `aws.rpl_backup_configured` (KSI-RPL-ARP, v0.1.33); `github.piy_sdlc_security_gates` (KSI-PIY-RSD, v0.1.34). Coverage moved from 30/60 to 36/60 KSIs — exactly matching the design entry's projected outcome. v0.1.29 was a CI hotfix that introduced `tests/test_triage_constant_alignment.py` — a source-level pin against `EXPECTED_DETECTORS` drift in `scripts/triage.sh`; the lock then caught drift at PR time on every detector PR (5/5). All four originally-planned Tier 1 items now shipped (#1 quickstart, #2a/2b cost+dry-run, #3 starter pack, #4 detector gap analysis).

**v0.1.10 added the CI E2E smoke required check.** Every PR runs the full Efterlev pipeline (init → scan → agent gap → agent document → poam) against a synthetic fixture using a real Anthropic API call. ~$0.05–0.10/PR on Haiku 4.5 (the v0.1.43+ default; switched from Sonnet 4.6 after observing ~50% PR-flake rate); ~5 min wall. This is what closed the manual-shakedown-per-patch loop.

**v0.1.43: agent-quality maturity sprint.** Gap/doc/remediation prompts rewritten against the 2026 Anthropic prompting best-practices guide (XML structure, few-shot examples, manifest-quoting + resource-naming codified, anti-overengineering for remediation diffs). v0.2 eval-harness Phase 1 shipped (5 metrics: M1 status_precision through M5 poam_scope_discipline; 4 fixtures; `--runs N` aggregator for noise-floor calibration). M1 status_precision lifted 0.818 → 1.000 on the most-exercised eval-harness fixture. Gap-stage retry helper (DECISIONS 2026-05-09) handles the ~21% Haiku stochastic-rejection rate transparently in both the eval harness and the CI smoke entry point.

**v0.1.44 + v0.1.45: Tier 2 serverless detector batches.** Three DECISIONS-then-implementation cycles (#1 + #2 + #3) shipped 7 detectors closing the original 5-detector Lambda + API Gateway deferred backlog from PR #196 — `aws.lambda_logging_configured`, `aws.api_gateway_tls_min_version`, `aws.lambda_env_kms_encryption`, `aws.api_gateway_access_logging`, `aws.lambda_vpc_isolation`, `aws.api_gateway_auth_required`, `aws.api_gateway_waf_attached`. Plus a new `serverless-mixed` eval-harness fixture (5th in the corpus). KSI count unchanged at 37 — the new detectors widen the resource-type evidence base for already-covered KSIs (CNA family especially) rather than adding first-time coverage. KSI-mapped detector count rose 47 → 54.

**v0.1.46: Tier 3 #1 `aws.waf_*` detector family v0.** Three new detectors closing the WAF-posture-quality dimension that the Tier 2 #3 `aws.api_gateway_waf_attached` left unaddressed — `aws.waf_rule_count`, `aws.waf_managed_rule_groups`, `aws.waf_rate_limiting`. Per-Web-ACL emission, binary states (no `unverifiable`), all map to KSI-CNA-RVP (already covered) — these widen KSI-CNA-RVP detector cross-coverage 2 → 5 spans without adding first-time KSI coverage. `serverless-mixed` fixture extends to rev 4 to exercise both posture extremes (api_protection with managed group + rate cap; legacy_unprotected_waf bare). KSI-mapped detector count rose 54 → 57.

**v0.1.47: Tier 3 #2 streaming refactor + cap lift.** AnthropicClient._one_call switched from non-streaming `messages.create()` to `messages.stream()` (unconditional, not max_tokens-conditional); Gap Agent default_anthropic max_tokens lifted 20480 → 32768 (matches Bedrock). Removed the deterministic Anthropic-direct ceiling that was about to bite as fixtures grew. Public agent-layer API unchanged; retry helper, telemetry, and Bedrock client all untouched. PR #217 stochastic flake on rev-4 fixture was the immediate motivating evidence; the v0.1.x post-release-validation methodology working as designed.

**v0.1.48: Tier 3 #3 `aws.waf_*` family v1.** Two new detectors closing the action-type + IP-set-blocking dimensions deferred from Tier 3 #1 Decision #7: `aws.waf_action_types` (3-state: enforcing / observing_only / mixed; catches the canonical "managed group set to count" gap) and `aws.waf_ip_set_blocking` (first WAF-family detector to evidence AC-3 Access Enforcement at the IaC layer). `serverless-mixed` extends to rev 5 to exercise both new dimensions on `api_protection` (count-action managed-group rule + IP-set blocking rule) plus a new top-level `aws_wafv2_ip_set` resource. Detector count rises 61 → 63; KSI-mapped 57 → 59. KSI-CNA-RVP cross-coverage rises 5 → 7 (most cross-resource-type-evidenced KSI in the library by a wide margin).

**v0.1.49: Tier 3 #4 `aws.waf_geo_blocking`.** Single detector closing the geo-blocking dimension deferred from Tier 3 #1 Decision #7. **First WAF-family detector to evidence SC-7 (Boundary Protection) at the IaC layer** -- geo-blocking IS the canonical perimeter-side boundary control at the country level; the existing SC-7 evidence base is heavily VPC-internal, this widens it to the public-internet perimeter. Two-state binary detector with intentional-absence handling in the gap message ("may be intentional for global-customer workloads"). `serverless-mixed` extends to rev 6 to exercise the new dimension on `api_protection` (canonical embargoed-country block: KP, IR, CU, SY). Detector count rises 63 → 64; KSI-mapped 59 → 60. KSI-CNA-RVP cross-coverage rises 7 → 8. WAF family now at 6 of 7 v0/v1 dimensions shipped (only `custom_rule_groups` remains deferred for Tier 3 #5).

**v0.1.50: Tier 3 #5 closes the WAF family at 7/7.** `aws.waf_custom_rule_groups` -- cross-resource detector that walks both aws_wafv2_web_acl AND aws_wafv2_rule_group resources; emits per Web ACL whether any rule references a customer-defined rule group via statement.rule_group_reference_statement. The defined_rule_groups inventory in the evidence content lets the Gap Agent flag the canonical "defined but unreferenced" anti-pattern. `serverless-mixed` extends to rev 7. Detector count rises 64 → 65; KSI-mapped 60 → 61. KSI-CNA-RVP cross-coverage rises 8 → 9. **The aws.waf_* family v0/v1 arc spanning 5 batches across 5 releases (v0.1.46–v0.1.50) is now complete** — 7 detectors covering rule_count, managed_rule_groups, rate_limiting, action_types, ip_set_blocking, geo_blocking, custom_rule_groups; KSI-CNA-RVP went from 2 detectors at v0.1.45 to 9 at v0.1.50. The 3-dimension SC-7 evidence base + 2-dimension AC-3 evidence base + bulk SI-3 coverage make WAF the most cross-control-evidenced detector family.

**v0.1.51: Tier 4 #1 ships ConMon Lite v0.** First non-detector strategic batch since the Tier 3 WAF arc closure. PR-delta scan comparison: every PR now gets a sticky comment listing newly-introduced gaps relative to the base branch. New `efterlev scan-diff <prior> <current>` CLI command + `.efterlev/reports/scan-<ts>.json` sidecar emission on `efterlev scan` + extended pr-compliance-scan.yml workflow that scans the base branch via `git worktree add`, runs the diff, and posts a sticky comment with the `<!-- efterlev-conmon-lite -->` marker (distinct from the existing posture-comment marker so the two coexist). Per-detector gap-emission abstraction at v0 — deterministic + free; KSI-verdict diffs deferred to ConMon Lite v1 once a verdict-stability mechanism is in place.

**v0.1.52: Tier 4 #2 ships ConMon Lite v1.** Closes the verdict-stability deferral from Tier 4 #1 with 2-of-3 majority voting. New `--runs N` flag on `efterlev agent gap` + new `multi_run.py` aggregator (per-KSI majority via `Counter` + `ceil(N/2)` threshold, tie-break to most-conservative verdict, KSIs whose top vote count is below threshold marked `flickering`) + new gap-report JSON sidecar fields (`runs_aggregated`, `per_run_verdicts`, `flickering_ksis`) + `--print-markdown` + `--base-branch` flags on `efterlev report diff` + `render_gap_diff_markdown` function + extended pr-compliance-scan.yml workflow gated on `EFTERLEV_CONMON_LITE_V1` repo variable. v0 + v1 sticky comments coexist on the same PR with distinct markers (`<!-- efterlev-conmon-lite -->` vs `<!-- efterlev-conmon-lite-v1 -->`); different audiences (code reviewers vs compliance reviewers). Default OFF; per-PR cost ~$0.90 on Sonnet 4.6.

**v0.1.53: contributor scaffolder.** New `efterlev detectors new <detector_id>` CLI command. Generates the canonical 5-file detector folder skeleton (`__init__.py` + `detector.py` + `mapping.yaml` + `evidence.yaml` + `README.md`) plus `fixtures/should_match/` and `fixtures/should_not_match/` directories. Stub `detector.py` is registration-ready (decorator + empty `detect`); `mapping.yaml` / `evidence.yaml` / `README.md` carry TODO placeholders keyed off the requested KSIs + controls. OSS-friction reducer held in `LIMITATIONS.md` "Future ideas" since v0.1.18+; small focused single-PR feature after the multi-batch ConMon Lite arc closed.

**v0.1.54: boundary --interactive helper.** New `--interactive` / `-i` flag on `efterlev boundary set`. Walks the user through include + exclude glob entry instead of requiring them to remember the `--include`/`--exclude` flag syntax. Bail-fast if no globs entered; mutually exclusive with `--include`/`--exclude`. Second small focused single-PR feature in the post-Tier-4 cadence; closes the second of the v0.1.18+ "Future ideas" deferrals.

**v0.1.55: github.branch_protection detector.** New per-`github_branch_protection`-resource Terraform-source detector under `detectors/github/` — inaugural Terraform reader in that namespace, which previously read only `.github/workflows/*.yml`. Joins `github.piy_sdlc_security_gates` on KSI-PIY-RSD: workflow gates run on PRs; branch protection enforces that PRs require those gates to pass before merge. Two binary states (`protections_present` / `protections_absent`); the absent state catches the canonical "branch protection rule declared but enforces nothing" gap. Bonus: friendly_errors now surfaces the Anthropic 400 body (was hidden behind a canned "code-level bug" hint) and pattern-matches the account-spend-cap 400 body (`"API usage limit"` / `"regain access"`) to a quota classification — caught the v0.1.55-cut-day spend-cap incident inside CI logs in <30 min.

**v0.1.56: efterlev detectors show <id>.** New CLI command — read/inspect counterpart that completes the detectors-CLI symmetry: `list` (registry summary, existing) + `new` (write/scaffold, v0.1.53) + `show` (read/inspect, v0.1.56). Surfaces what `detectors list` elides: mapping.yaml KSI/control coverage notes, evidence.yaml shape (per-record `content` keys), README lead paragraph, and fixture file counts. Each section degrades gracefully when a detector folder is missing the corresponding file. Unknown id exits 1 with substring-overlap + cloud-prefix-fallback suggestions.

**v0.1.57: wheel + sdist SBOMs attached to GitHub Releases.** Closes the parallel gap to the container's already-embedded SBOM (`buildx sbom: true` from v0.1.10+). `release-pypi.yml` runs `anchore/sbom-action@v0` after `publish-pypi` to generate CycloneDX SBOMs for both PyPI artifacts and attaches them as `efterlev-<VERSION>-wheel-sbom.cdx.json` + `efterlev-<VERSION>-sdist-sbom.cdx.json`. Race-tolerant against `post-release-triage.yml` (creates the Release if triage hasn't yet; triage's `gh release edit --notes-file` correctly handles the Release-exists-replace-notes case). Final tags only — rc tags don't get a public Release page. Held in `docs/followups.md` v0.1.x bucket since the v0.1.0 launch security review.

**v0.1.58: efterlev manifests validate <path>.** New CLI command — offline schema-validation gate for Evidence Manifests. Pre-commit / pre-PR friction reducer that catches the high-leverage authoring mistakes a contributor makes: typo'd field names (`extra="forbid"` rejects them — the canonical `attester:` vs `attested_by:` swallowed-typo), malformed dates, missing required fields, top-level not-a-mapping. Pure schema check; no FRMR / baseline load required. Path argument accepts a single file OR a directory (walked via the same glob as scan-time discovery). Fourth single-PR friction-reducer in the post-Tier-4 cadence (after detectors-new, boundary-interactive, detectors-show).

**v0.1.59: first-run UX hard-error for `--target <subdir>` + workflows-ancestor.** Bridge release before the next strategic arc (CFN/CDK gated on eval-harness Phase 2 lite per DECISIONS 2026-05-11 strategic-arc entry). Closes a documented funnel-killer: a first-run user pointing `--target` at `infra/terraform/` (the dominant real-customer layout) used to get a `20 evidence records` success line and conclude the tool covered their repo, when github-source detectors had silently contributed zero. The pre-v0.1.59 post-scan warning was easy to miss in CI logs. v0.1.59 promotes that to a pre-scan hard-error (exit 2) with two clear remediations: re-run from the detected repo root, OR pass the new `--allow-subdir-target` flag to acknowledge the trade-off (legitimate monorepo-with-multiple-Terraform-roots case). The post-scan warning still fires when `--allow-subdir-target` is passed.

**v0.1.105: OSCAL output arc step 1 — POA&M emit (`efterlev oscal export --kind poam`).** First step in the OSCAL output arc per 2026-05-14 strategic plan. New `oscal` CLI subcommand (under `efterlev oscal export ...`) with `--kind poam` emitting OSCAL 1.0.4 plan-of-action-and-milestones JSON conforming to the FedRAMP-current schema (and the GSA fedramp-automation rule set, validation wiring planned for v0.1.106). New `generate_poam_oscal` primitive in `src/efterlev/primitives/generate/`. Deterministic — same Gap Agent classifications + same FRMR + pinned `last-modified` timestamp produce byte-identical OSCAL JSON; UUIDs derived via `uuid5` from a fixed namespace (`uuid.NAMESPACE_DNS / "efterlev.com/oscal"`) + KSI/control identifiers, so re-runs of the same scan produce stable UUIDs (important for downstream consumers like RegScale OSCAL Hub that may detect "changes" via UUID comparison). Output structure: per `not_implemented`/`partial` KSI → 1 poam-item, per (KSI × cited control) pair → 1 finding, per cited evidence_id → 1 deduplicated observation. Severity heuristic mirrors the markdown POA&M (`not_implemented` → high, `partial` → medium; flagged in OSCAL `props.remarks` as "reviewer must confirm against internal risk framework"). Why a dedicated subcommand (not a flag on `report run`): OSCAL has multiple output kinds (POA&M today; component-definition + partial-SSP planned), each is a distinct schema; subcommand namespace lets us add `oscal validate` etc. without overloading the top-level CLI; `report run` users who don't care about OSCAL shouldn't pay the OSCAL emit cost. Honest scope at v0.1.105: minimal-conformant POA&M with metadata, system-id, observations, findings, poam-items. No `import-ssp` reference (system-id-only mode; `--system-name` and `--system-id` CLI options are placeholders the maintainer overrides before submitting to a 3PAO). No risks block. No local-definitions.components (LLM-narrative implementation statements scoped for the component-definition export at v0.1.107). 10 new tests covering UUID determinism, severity heuristic, dedup, JSON serializability; pytest 1749 → 1759.

**v0.1.104: SAM transparency note (LIMITATIONS only).** Tiny patch documenting that AWS SAM templates (`Transform: AWS::Serverless-2016-10-31` directive) parse without crashing but the SAM-specific resource types (`AWS::Serverless::Function`, `AWS::Serverless::Api`, `AWS::Serverless::SimpleTable`, `AWS::Serverless::GraphQLApi`, etc.) fall through the unmapped-fallback path — they translate to `aws_serverless_function` / `aws_serverless_api` / etc. via default `cfn_type_to_tf_type`, which **no detector reads**. Surfaced by an internal QA scan against three aws-samples/serverless-patterns templates (apigw-translate, lambda-s3, dynamodb-appsync). Honest user-facing scope: scan post-`sam build` CFN output to reach concrete CFN; real SAM property mappings (`AWS::Serverless::Function` → `aws_lambda_function` etc.) deferred until first customer hits the gap so we can use their template as the validation fixture rather than guessing SAM-app shape. Closes the v0.1.103-style QA-driven release loop after one productive cycle (which paid off with the 3 universal CFN bugs in v0.1.103); SAM is a niche dialect (~10-20% of FedRAMP-pursuing SaaS architecturally; pure-serverless apps only) and not worth speculative mapping work without a concrete driver.

**v0.1.103: QA-surfaced CFN parser + scan-summary bundle.** Internal QA scan against aws-quickstart/quickstart-aws-aurora-postgresql (1758 lines of real-world Quick Start CFN; 71 AWS::* references) surfaced 3 real bugs that 2 maintainer-validated fixtures had missed. (1) Parser crashed on `!ValueOf` (a Rules-section intrinsic for parameter validation) and silently dropped the entire 1091-line template — registered Rules-section intrinsics `Contains`, `EachMemberEquals`, `EachMemberIn`, `RefAll`, `ValueOf`, `ValueOfAll` in `_CfnSafeLoader._CFN_INTRINSICS`. (2) Parse failures were tracked in `ScanCloudFormationOutput.parse_failures` but never surfaced in the scan summary — added `cfn parse failures: N — see scan-<ts>.json sidecar` line to the CLI summary. (3) Nested-stack references (`AWS::CloudFormation::Stack` with `TemplateURL: !Sub 'https://${S3Bucket}/...'`) weren't followed and weren't visible — added `nested_stack_refs` field to the primitive output + `cfn nested stacks: N (TemplateURL not followed; scan child templates directly to reach nested resources)` line to the CLI summary. Honest documentation of the limitation rather than implementing nested-stack expansion (that's a v0.x followup needing S3 fetch + recursive parse). Also dropped the stale "v0.1.72 plumbing — property-mapping in PR gamma" text from the summary (10 minor versions out of date as of v0.1.102). Same-fixture re-scan validation: 1→2 templates parsed, 3→24 resources adapted, 1→19 evidence records (8x and 19x improvements). 6 new tests (2 in test_cloudformation_parser.py + 4 in new test_scan_cloudformation_summary.py); pytest 1743 → 1749. Internal-QA-driven release pattern is the right cadence for finding real bugs the synthetic fixture surface can't reach.

**v0.1.102: CFN graduation arc step 4 — remove `--allow-cfn` flag.** Closes the CFN graduation arc completely. Removed the `allow_cfn: bool | None = typer.Option(...)` parameter from cli/main.py's scan command + the deprecation-warning sentinel logic. CFN now scans unconditionally; the `scan_cloudformation` primitive is invoked on every scan. Pre-v0.1.102 callers of `efterlev scan --allow-cfn` will get a CLI parse error ("No such option: --allow-cfn"); pre-v0.1.102 callers of `efterlev scan --no-allow-cfn` lose their explicit opt-out (CFN scanning is now unconditional). Shipped as v0.1.102 rather than v0.2.0 per DECISIONS commitments (×3 entries) reserving v0.2.0 for the eval-harness-as-user-feature substantive arc — "Bumping major version on a change that gives users nothing is a form of marketing inflation." Removing a deprecated flag is a cleanup, not a capability shift. Updated LIMITATIONS.md + PHASE_2_LITE_CFN_VALIDATION.md to reflect "removed at v0.1.102" instead of the prior "removed in v0.2.0" promise. **CFN graduation arc COMPLETE: type-coverage 100% (60/60), maintainer-validation 44/44 = 100/100 across 2 fixtures, doc graduation, deprecation, removal — all 4 steps shipped.**

**v0.1.101: verify-release.sh ghcr-propagation retry-and-wait.** Closes the recurring release-smoke `signature-verify` timing race that hit v0.1.87 and v0.1.99 (~1 in 5 release tags). Root cause: `cosign verify` for the container sig and `cosign verify-attestation` for the SLSA provenance both race the release-container.yml workflow's ghcr push. The release artifacts are valid; only the CI status reads false-red. Fix: wrap both cosign calls in retry-and-wait loops matching the smoke matrix's `docker pull` shape — 10 attempts × 30s = 5min. Self-contained in `scripts/verify-release.sh`; benefits both CI signature-verify and end users running the script immediately after a release. Sanity-checked against v0.1.100 (passed 4/4). bash -n syntax-clean.

**v0.1.100: post-CFN-graduation doc cleanup.** Audit after v0.1.99 surfaced 5 stale CFN claims missed during the graduation work — fixed in this release. (1) `docs/faq.md` "What if my code is in something other than Terraform?" answer said "v0.1.0 supports Terraform and OpenTofu only... CloudFormation, AWS CDK, Pulumi, and Kubernetes manifests are roadmap items" — wrong; CFN ships. Updated to reflect default-on status + 60/60 + 44/44 numbers. (2) `docs/architecture.md` "Two Evidence sources" section said "Terraform today; CloudFormation / K8s / runtime in v1.5+" — wrong; CFN ships now. Updated to reflect property-mapping-table-translates-CFN-to-TF-shape architecture. (3) `README.md` Status para narrated CFN arc through v0.1.81 only — extended through v0.1.95-99 graduation steps with the combined 44/44 number. (4) `evals/PHASE_2_LITE_CFN_VALIDATION.md` closing line called doc graduation "next arc release" — updated to reflect that v0.1.99 shipped it. (5) `evals/harness.py` still appended `--allow-cfn` to scan_args, which would emit the deprecation warning every harness run — dropped the append. Also removed `_fixture_has_cfn_templates` as dead code (only callsite was the now-removed flag dispatch). pytest still 1743 passing.

**v0.1.99: CFN graduation arc step 3 — doc graduation + `--allow-cfn` deprecation.** CFN scanning is now default-on. The `--allow-cfn` flag is kept for backward compatibility but emits a deprecation warning when explicitly passed (will be removed in v0.2.0). Implementation: `allow_cfn` parameter changed from `bool = False` to `bool | None = None`; sentinel logic — `None` (default) and `True` (explicit) both run CFN, `False` (explicit `--no-allow-cfn`) opts out. Deprecation warning fires only when `allow_cfn is True` (explicit pass). Removed "experimental" framing from README (lede + Status para + Coverage table) + LIMITATIONS.md (replaced "experimental status with 18 resource types... maintainer-validation deferred" with the actual graduation numbers: 60/60 type coverage + 44/44 = 100/100 across 2 fixtures). Updated `cli/doctor.py`'s `check_cloudformation_templates` to report `pass` with "will be scanned by default" instead of `warn` with the now-defunct flag hint. v0.2.0 will remove the flag entirely (breaking change requiring users to drop `--allow-cfn` from scripts; `--no-allow-cfn` will also go away — CFN becomes unconditionally on). One-minor-release deprecation window per standard CLI deprecation pattern.

**v0.1.98: CFN graduation arc step 2 (validation) — aws-vpc-cfn maintainer-validation dispatch.** Triggered the existing `eval-harness-cfn.yml` workflow_dispatch with `fixture=evals/fixtures/aws-vpc-cfn` + `llm_model=claude-haiku-4-5` (same backend as the v0.1.81 csp-starter-cfn run). Result: **21/21 = 100% precision + 100% recall** against revision-1 labels. The 4 detector-evidence KSIs (CNA-MAT, CNA-RNT, CNA-ULN, PIY-GIV) all matched expectation including the alternation-honored case (CNA-ULN classified `not_implemented`, alternation accepted). The 17 procedural-only KSIs all classified `evidence_layer_inapplicable`. Combined with v0.1.81's 23/23 csp-starter-cfn result: **44/44 = 100% across 2 CFN fixtures.** This proves the v0.1.97 thesis: detector verdicts are invariant under IaC syntax once the property-mapping table translates CFN bodies to TF shape — the same VPC architecture in CFN classifies identically to the same architecture in TF (`aws-vpc-tfm` v0.1.69 baseline). Bumped `aws-vpc-cfn/GROUND_TRUTH.yaml` revision 1 → 2 to mark validated; appended Results section to `evals/PHASE_2_LITE_CFN_VALIDATION.md`. **CFN graduation arc step 2 is COMPLETE.** Step 3 (doc graduation, remove "experimental" framing, deprecate `--allow-cfn`) is the next arc release.

**v0.1.97: CFN graduation arc step 2 — label aws-vpc-cfn (2nd CFN fixture).** Lifts CFN-side validation breadth from 23 labels (csp-starter-cfn alone) toward ~50 (matching TF baseline of 67 across 3 fixtures). The aws-vpc-cfn fixture has been in the repo since v0.1.72 (vendored AWS Quick Start VPC, real-shape, parameter-driven, condition-conditional template) but had empty labels per the v0.1.72 plumbing-only note. Property mapping shipped via PR γ + γ.2 batches 1-9 (v0.1.73-v0.1.96), so detectors now read CFN-translated bodies equivalently to TF and labels can land. Maintainer-draft labels mirror aws-vpc-tfm's GROUND_TRUTH.yaml structure (the TF companion is the authoritative shape for "what an honest maintainer expects from a real-shape VPC fixture"): 4 detector-evidence KSIs (KSI-CNA-MAT/CNA-RNT as `partial|not_implemented` per nacl_restrictiveness no-explicit-deny gap; KSI-CNA-ULN as `partial|not_implemented` per vpc_logical_segmentation; KSI-PIY-GIV as `partial` per terraform_inventory which fires on any aws_* including CFN-translated) + 16 procedural-only labels (9 AFR + 4 CED + 3 INR all `evidence_layer_inapplicable|not_applicable`) + KSI-PIY-RSD as `not_implemented|evidence_layer_inapplicable`. Total: 21 labels for aws-vpc-cfn. CFN-side validation breadth: 23 (csp-starter-cfn) + 21 (aws-vpc-cfn) = 44 labels across 2 fixtures, vs TF baseline 67 across 3 fixtures. The maintainer-validation LLM-call dispatch (the v0.1.81-equivalent step where we run gap agent with a real LLM backend and compare verdicts to labels) is the next graduation arc step (v0.1.98 candidate). The expectation: verdicts equivalent to aws-vpc-tfm's at the KSI level — that's the regression instrument the dispatch will test. If verdicts diverge, it's a CFN-side bug, not a fixture-quality issue.

**v0.1.96: CFN graduation arc step 1.5 — close 8 missing mappings (true 100% coverage).** Closes the 8 CFN-type mappings the v0.1.95 parity audit surfaced as real gaps. Mappings added: `AWS::IAM::AccessKey` → `aws_iam_access_key` (closes `iam_user_access_keys` + `iam_service_account_keys_age`); `AWS::Logs::Destination` → `aws_cloudwatch_log_destination` (TF prefixes `cloudwatch_`); `AWS::Logs::SubscriptionFilter` → `aws_cloudwatch_log_subscription_filter` (same prefix); `AWS::OpenSearchService::Domain` → `aws_opensearch_domain` (TF drops the `service` namespace segment); `AWS::Elasticsearch::Domain` → `aws_elasticsearch_domain` (legacy AWS service; default tf_type correct); `AWS::KinesisFirehose::DeliveryStream` → `aws_kinesis_firehose_delivery_stream` (override since CamelCase segments collapse); `AWS::SecurityHub::Hub` → `aws_securityhub_account` (NAME asymmetry: TF models enable-on-account semantics rather than hub-as-resource); `AWS::SecurityHub::FindingAggregator` → `aws_securityhub_finding_aggregator`. Also fixed parity-script classification of `aws_iam_user_login_profile` from "missing mapping" to "no CFN equivalent" (AWS exposes login-profile creation only via the IAM API). 11 new parity tests; pytest 1732 → 1743. **Parity matrix at v0.1.96: 47 full + 11 partial-by-design + 2 TF-only-by-design = 60/60. Effective CFN coverage: 100% with zero real gaps.** The only remaining TF-only-by-design entries are `aws.iam_password_policy` (account-level setting, no CFN type) and `aws.iam_managed_via_terraform` (meta-detector by definition).

**v0.1.95: CFN graduation arc step 1 — detector parity audit.** First step in the CFN graduation plan per 2026-05-14: produce a defensible matrix of detector→CFN status so the marketing claim "Efterlev reads CloudFormation" matches what the code actually does. Generated by `scripts/build_cfn_parity_table.py` which inspects `_MAPPINGS` + each mapping function's `tf_type` overrides + each detector's `r.type ==` filters. Adds manual-review classification for TF aliases (`aws_alb` ↔ `aws_lb`), TF data sources (no CFN concept), TF-only-by-design types (account-level settings), and TF sub-resources CFN bundles inline (S3 versioning/acl/SSE/lifecycle inside `AWS::S3::Bucket`'s body). Outputs `docs/cfn-detector-parity.csv` (authoritative) + `docs/cfn-detector-parity.md` (wrapper page explaining the matrix). **Coverage at v0.1.95: 92% effective (45 full + 10 partial-by-design out of 60 detectors).** **Honest correction:** the v0.1.93 "CFN type-coverage CLOSED" claim was off by 8 types — `centralized_log_aggregation` reads 7 real-but-unmapped CFN types (`AWS::Logs::Destination`/`SubscriptionFilter`, `AWS::OpenSearchService::Domain`, `AWS::Elasticsearch::Domain`, `AWS::KinesisFirehose::DeliveryStream`, `AWS::SecurityHub::Hub`/`FindingAggregator`), and 2 IAM detectors (`iam_user_access_keys`, `iam_service_account_keys_age`) need `AWS::IAM::AccessKey`. Closing this gap is a small follow-up patch (v0.1.96 candidate). The v0.1.93 inventory script missed `centralized_log_aggregation`'s 7-type read because the detector reads many TF types in one filter — a reminder that auto-inventory needs better spot-checks. TF-only-by-design (intentional, no fix planned): `aws.iam_password_policy` (account-level setting; CFN has no resource type for it) and `aws.iam_managed_via_terraform` (meta-detector confirming any IAM is in TF — TF-only by definition).

**v0.1.94: repo-content cleanup — competitive positioning + hackathon framing removed.** User directive 2026-05-14: "remove the COMPETITIVE_LANDSCAPE.md file. that is not appropriate" + "some documents still mention a hackathon. that never happened. remove all references to it." Two scrubs in one PR. **(1) Competitive content:** deleted `COMPETITIVE_LANDSCAPE.md` (top-level, 18KB) + `docs/comparisons/{paramify, compliance-tf, comp-ai, vanta-drata, consultant}.md` (5 derivative pages) + `mkdocs.yml` Comparisons nav section + Competitive landscape link in Project links. Scrubbed inline file references from CLAUDE.md (3 places), CODE_OF_CONDUCT.md, CONTRIBUTING.md, GOVERNANCE.md, docs/architecture.md, scripts/launch-grep-scrub.allowlist (preserved policy intent in policy docs while removing file mentions). Fixed broken `comparisons/` links in docs/faq.md + docs/index.md. **(2) Hackathon framing:** the project was originally framed as a 4-day hackathon build; the hackathon never happened, so the framing was inaccurate. Deleted `docs/dual_horizon_plan.md` (entire structure was hackathon-based: "Layer 1 Hackathon MVP / Layer 2 Post-hackathon"; doc was also stale at v0.1.93). Bulk-replaced 29 hackathon references in DECISIONS.md ("hackathon MVP" → "v0 MVP", "pre-hackathon" → "pre-v0", etc.) preserving dates and decisions but updating the framing language. Cleaned narrative refs in README.md, CONTRIBUTING.md, THREAT_MODEL.md, docs/icp.md, scripts/{README, catalogs_crossref, trestle_smoke, mcp_smoke_server}.py, tests/{test_agents, test_oscal_loader}.py. Final grep confirms zero "hackathon" matches and zero `COMPETITIVE_LANDSCAPE`/`comparisons/` matches outside dated SPEC/DECISIONS historical entries (intentionally preserved as accurate records of past work). 8 files deleted, 14 files edited; pytest still 1732 (no test-count regression).

**v0.1.93: CFN PR gamma.2 batch 8 — finishing batch.** Closes out CFN type-coverage in one PR per user directive ("finish cloudformation, I want it done"). 30 mappings unlock the remaining detector-referenced CFN types: API Gateway DomainName (v1 + v2 — note v1's flat `SecurityPolicy` vs v2's nested `DomainNameConfigurations[0].SecurityPolicy`), AccessAnalyzer::Analyzer, GuardDuty::Detector, Config (ConfigurationRecorder + DeliveryChannel), CloudWatch::Alarm (override → `aws_cloudwatch_metric_alarm`), Events::Rule (1→1+N synthesis: rule + one `aws_cloudwatch_event_target` per CFN `Targets` entry; EventPattern dict → JSON-stringified per TF schema), DocDB::DBCluster, Neptune::DBCluster (note: Neptune uses `kms_key_arn` while RDS uses `kms_key_id` — AWS API asymmetry), ElastiCache (ReplicationGroup + CacheCluster — CFN's `CacheCluster` becomes TF's bare `cluster`), EFS::FileSystem, EC2 LaunchTemplate (unwraps `LaunchTemplateData` envelope to lift MetadataOptions to top level) / VPC / Subnet / SecurityGroupIngress (CFN's `CidrIp` single string → TF's `cidr_blocks` single-element list), ELBv2 LoadBalancer (CFN's generic `LoadBalancerAttributes: [{Key, Value}, ...]` → TF's `access_logs[0].{enabled, bucket, prefix}` block, parsing `access_logs.s3.enabled`/`access_logs.s3.bucket`/`access_logs.s3.prefix` keys) + ELB Classic (CFN's `AccessLoggingPolicy.{Enabled, S3BucketName, S3BucketPrefix, EmitInterval}` → TF's `access_logs[0].{enabled, bucket, bucket_prefix, interval}`), IAM SAMLProvider (with embedded SAML metadata XML), IAM OIDCProvider (note tf_type asymmetry: CFN's compact `OIDCProvider` becomes TF's spelled-out `aws_iam_openid_connect_provider`), Backup family (BackupPlan unwraps the `BackupPlan.BackupPlanRule` nested-list with `Lifecycle.{DeleteAfterDays, MoveToColdStorageAfterDays}` → `lifecycle[0].{delete_after, cold_storage_after}`; Vault, Selection, RestoreTestingPlan, RestoreTestingSelection), Logs::ResourcePolicy (PolicyDocument dict JSON-stringified; tf_type asymmetry: CFN's `Logs::ResourcePolicy` → TF's `aws_cloudwatch_log_resource_policy` with the `cloudwatch_` prefix), SecretsManager::RotationSchedule, AutoScaling::AutoScalingGroup, ECS::Service, CloudFront::Distribution (DistributionConfig unwrap; DefaultCacheBehavior → default_cache_behavior[0]; CacheBehaviors → ordered_cache_behavior[N]; ViewerCertificate → viewer_certificate[0]). Updated 3 pre-existing tests in test_cloudformation_adapter.py + test_cfn_property_mapping.py to use `AWS::Athena::WorkGroup` (no detector reads it; reliably unmapped) instead of `AWS::CloudFront::Distribution` for the unmapped-fallback path. **CFN type-coverage CLOSED — every detector now reachable from CloudFormation.** 43 new parity tests covering basic translation + adapter routing + detector-fires-on-CFN end-to-end for each type; pytest 1689 → 1732. AWS::IAM::AccountPasswordPolicy explicitly documented as unmappable (it's an account-level setting in AWS, deployable only via IAM API or AWS Console — not a CFN resource type; the `aws.iam_password_policy` detector still works on TF since `aws_iam_account_password_policy` abstracts the API call).

**v0.1.92: CFN PR gamma.2 batch 7 — IAM Group + API Gateway pair.** 5 CFN type mappings unlock 7 detectors. `AWS::IAM::Group` reuses the 1→(1+N+M) synthesis pattern from PR gamma.2 batch 2 (IAM::Role/User): each `ManagedPolicyArns` entry → synthesized `aws_iam_group_policy_attachment`; each inline `Policies` entry → synthesized `aws_iam_group_policy` with PolicyDocument JSON-stringified. Unlocks iam_admin_policy_usage, iam_inline_policies_audit, mfa_required_on_iam_policies, mla_log_access_least_privilege. API Gateway pair documents two AWS-side naming inconsistencies the mapping handles cleanly: (1) v1 Stage uses singular `AccessLogSetting` while v2 Stage uses plural `AccessLogSettings` — both translate to TF's plural `access_log_settings`; (2) v1 Method's `AuthorizationType` maps to TF's bare `authorization` (TF v1 schema flattened the suffix) while v2 Route's `AuthorizationType` maps to TF's `authorization_type` (v2 keeps the suffix). tf_type overrides needed for v1 types (`AWS::ApiGateway::Stage` → `aws_api_gateway_stage`, `AWS::ApiGateway::Method` → `aws_api_gateway_method`); v2 types use default `cfn_type_to_tf_type` correctly (`aws_apigatewayv2_stage`, `aws_apigatewayv2_route`). 13 new parity tests; pytest 1676 → 1689. Pre-v0.1.92 type-coverage was 27 of 54 detector-referenced types; batch 7 → 32 (59%).

**v0.1.91: CFN PR gamma.2 batch 6 — RDS Cluster + NACL pair + EC2 Instance.** Mid-tier batch in the gamma.2 series: 4 CFN type mappings unlock 7 detectors. `AWS::RDS::DBCluster` → `aws_rds_cluster` (sibling to DBInstance from batch 3; same flat-rename pattern; reads: `backup_retention_period`, `storage_encrypted`, `kms_key_id`, `availability_zones`). `AWS::EC2::NetworkAcl` → `aws_network_acl` (bare; CFN splits NACL rules into separate Entry resources unlike SecurityGroup which inlines them; tf_type override needed because `cfn_type_to_tf_type` yields `aws_ec2_networkacl`). `AWS::EC2::NetworkAclEntry` → `aws_network_acl_rule` (with `PortRange.{From, To}` flatten to `from_port`/`to_port`; `Icmp.{Type, Code}` flatten to `icmp_type`/`icmp_code`). `AWS::EC2::Instance` → `aws_instance` (tf_type override; `MetadataOptions` → `metadata_options[0]` list-wrapped block; `BlockDeviceMappings: [{DeviceName, Ebs: {Encrypted, KmsKeyId, ...}}]` → `ebs_block_device[N]`; v0.1.91 puts ALL Ebs mappings under `ebs_block_device` — no root-vs-non-root heuristic. CFN doesn't carry the AMI's root device name so without one we can't reliably tell. The `aws.encryption_ebs` detector emits Evidence per block in either list, so unencrypted volumes are flagged either way; only the label differs. Future enhancement: heuristic on `/dev/sda1`, `/dev/xvda`, `/dev/nvme0n1`). Detectors unlocked on CFN: rds_public_accessibility, backup_retention_configured, svc_at_rest_encryption_coverage, cna_optimizing_for_availability (RDS), nacl_open_egress, nacl_restrictiveness (NACL), ec2_imdsv2_required, encryption_ebs (EC2). 17 new parity tests; pytest 1659 → 1676.

**v0.1.90: CFN PR gamma.2 batch 5 — WAF family.** Highest-impact batch in the gamma.2 series: 5 CFN type mappings unlock 8 detectors (the whole WAF family + cna_dos_protection's WAFv2 path). Mappings added to `src/efterlev/cloudformation/property_mapping.py`: `AWS::WAFv2::WebACL` → `aws_wafv2_web_acl` (with deep `Rules → rule[N]` and `Statement → statement[0]` translation for `GeoMatchStatement.CountryCodes`, `RateBasedStatement.{Limit, AggregateKeyType}`, `ManagedRuleGroupStatement.{VendorName, Name, Version}`, `IPSetReferenceStatement.Arn`, `RuleGroupReferenceStatement.Arn`; `Action.{Block, Allow, Count, Captcha, Challenge}` and `OverrideAction.{None, Count}` each become list-wrapped empty blocks per python-hcl2 convention). `AWS::WAFv2::WebACLAssociation` → `aws_wafv2_web_acl_association`. `AWS::WAFv2::RuleGroup` → `aws_wafv2_rule_group`. `AWS::WAF::WebACL` → `aws_waf_web_acl` (legacy v1, minimal mapping — only `cna_dos_protection` reads it and only for existence/name). `AWS::Shield::Protection` → `aws_shield_protection`. tf_type overrides required for the 4 WAF types because `cfn_type_to_tf_type` produces `aws_wafv2_webacl`/`aws_waf_webacl` (no internal underscoring of the `WebACL` segment). 21 new parity tests in `tests/test_cfn_property_mapping_batch5.py`: each Statement kind translation isolated, each Action/OverrideAction kind, end-to-end fixture exercising 6 of the 8 detector read paths. Test count 1638 → 1659.

**v0.1.89: cosign-installer v3 → v4.1.2 (real fix for SLSA verify in CI).** v0.1.88's `cosign-release: 'v3.0.6'` pin under `cosign-installer@v3` failed in CI: the v3-line action's installer 404s on `cosign-linux-amd64.sig` because **cosign v3.x dropped `.sig` files** in favor of `.sigstore.json` bundles — only v2.x ships `.sig`. v4.0+ added cosign v3 install support; v4.1.2 (2026-05-07, sha `6f9f1778…`) defaults to cosign v3.0.6 per its release notes ("Bump cosign to 3.0.6 in #232"). v0.1.89 bumps the action and drops the now-redundant explicit `cosign-release` input. Action stays SHA-pinned per v0.1.62 SLSA-L3 hardening. Only `release-smoke.yml` changed; `release-container.yml`'s `cosign-installer@v3` keeps working for sign + verify (signature path) — only attestation verify breaks on v2.5.2. v0.1.87 + v0.1.88 published artifacts remain cryptographically valid (verified locally with cosign v3.0.6, 4/4) — pure CI-tooling lag.

**v0.1.88: release-smoke signature-verify cosign pin.** Surgical CI-tooling fix to the `signature-verify` job in `.github/workflows/release-smoke.yml`. Pinned `cosign-release: 'v3.0.6'` on the `Install cosign` step. Root cause: `sigstore/cosign-installer@v3`'s default `cosign-release` is **cosign v2.5.2**, which cannot verify the **SLSA v1** attestations (`predicateType: https://slsa.dev/provenance/v1`) that `actions/attest-build-provenance` writes. cosign v3.x reads them correctly. v0.1.87 release was fully cryptographically valid (verified locally with cosign v3.0.6: 4/4 — Sigstore wheel + sdist + container cosign sig + SLSA provenance) but CI's `signature-verify` showed false-red. Pre-v0.1.87 releases hid this regression because the `macos-13` release-smoke cell got stuck queued indefinitely (the same cell v0.1.87 dropped as part of the matrix slim) — `signature-verify` (`needs: [smoke]`) never actually ran on v0.1.80–v0.1.86. release-container.yml's cosign-installer also pulls v2.5.2 default, but its `cosign sign` and `cosign verify` (signature, not attestation) succeed fine on v2.5.2 — only the SLSA-attestation verify breaks. Keeping that workflow unchanged at v0.1.88; will pin if/when its surface area widens. Product unaffected.

**v0.1.87: GitHub Actions minute-budget reduction — 3-fix workflow bundle.** Repo-wide CI-cost audit on 2026-05-13 surfaced three structural waste sources; this release fixes all three. (1) `.github/workflows/release-smoke.yml` matrix slimmed from 7 cells to 4 — dropped `ubuntu-24.04-arm pipx` + `ubuntu-24.04-arm docker-ghcr` (architecture-specific bugs are rare for pure-Python projects with no native deps; container is still built for both archs in `release-container.yml`) and `macos-13 pipx` (one macOS version is enough for first-impression catch). Coverage retained: pipx on linux/mac/windows, docker on linux. Saves ~15 min per release tag. (2) `.github/workflows/ci.yml` dropped `push: branches: ['**']` trigger; kept only `pull_request:`. The concurrency group's key `${{ github.workflow }}-${{ github.ref }}` doesn't dedup push vs PR (different `github.ref`: `refs/heads/<branch>` vs `refs/pull/<N>/merge`), so every PR was running CI twice. Push-to-main still gets covered (all merges land via PR under this repo's protected-branch posture). Saves ~3 min per PR. (3) `.github/workflows/e2e-smoke.yml` added a version-bump-only filter to the `Detect source/test changes vs PR base` step — if `src/efterlev/__init__.py` is the only changed file under `src/` and no other matched files changed, the harness graceful-no-ops. Pre-v0.1.87 doc-only releases triggered e2e_smoke (~5 min wasted) because the `paths:` regex matched `^src/`. Saves ~5 min per doc-only release PR. None of the cuts are coverage-blind: each removal documents what was dropped and why it's low-yield. Even on Enterprise (50,000 min/mo cap, upgraded 2026-05-13), removing waste lowers run bill regardless of cap.

**v0.1.86: Streaming-tokens-as-progress for the Gap Agent.** Closes the silent-for-~60-90s UX gap during `efterlev agent gap`. The agent is a single batched LLM call by design (cross-KSI reasoning), but until v0.1.86 the user had no signal it wasn't hung. Now: regex-extracts `"ksi_id": "KSI-XXX-YYY"` patterns from cumulative streaming text, prints `[gap] classifying KSI X/N: KSI-AAA-BBB` per new ID. Heartbeat `[gap] thinking... (Ns elapsed, ~K tokens)` every 2s during the model's reasoning-summary preamble. Final `[gap] done in T.Ts — N/total` summary. TTY-only (silent in CI). New `src/efterlev/agents/gap_progress.py` module + 8 tests. Plumbed via `LLMClient.complete(on_chunk=…)` Protocol extension; Anthropic streams real chunks (uses the existing `client.messages.stream()` per DECISIONS 2026-05-10 — just exposes them); Bedrock fires on_chunk once at end (Converse non-streaming; uniform contract, per-backend granularity differs). Three prospects asked mid-run today if the tool was hung — this is the cheapest possible fix. Zero LLM-cost change, zero risk to validated 23/23 = 100/100 baseline.

**v0.1.85: Documentation Agent narrative quality — honest finding + targeted template improvement.** Surveyed the v0.1.81 dispatch artifacts. **Honest finding: the LLM-drafted narratives are already in strong shape** — 32/32 have explicit reviewer-action framing, specific resource names, exact config quotes, multi-layer scope, explicit gap callouts. The system prompt at agents/documentation_prompt.md is mature (3 worked examples, scope discipline, hedge/marketing-language forbidden). No LLM system-prompt changes — touching it would risk the v0.1.81 23/23 = 100/100 baseline without a clear gain. Defer prompt-engineering polish until concrete user feedback identifies a specific weakness. **Change: per-KSI-family procedural-evidence hints in the deterministic inapplicable template** (the cost-optimized template that fires for the 25-45 procedural KSIs per fixture). AFR-* → "FedRAMP authorization-data-sharing agreements"; CED-* → "security-awareness training completion records"; INR-* → "incident-response playbooks, post-incident review records"; PIY-* → "policy publication evidence with effective dates"; unknown → pre-v0.1.86 generic fallback. Makes 3PAO ask sharper without burning an LLM call. No eval-harness re-dispatch needed — pure-string change to procedural narrative; the harness's status_precision/recall metrics measure KSI verdicts, not narrative text.

**v0.1.84: UX-polish bundle — first-time-user onboarding moments.** Four small additions to user-facing prompts/output: (1) `efterlev report run` end-of-pipeline cost rollup ("Pipeline total: $X.XX over N tokens" sums Gap + Documentation + Remediation spend in one line). (2) `efterlev quickstart` end-of-quickstart cost rollup, same shape. (3) `efterlev doctor` new CFN-template detection check: walks the target tree for `Resources:`/`AWSTemplateFormatVersion`-shaped YAML/JSON, surfaces `warn` with hint pointing at `--allow-cfn` (citing v0.1.81 23/23 = 100/100 validation). (4) `efterlev init` next-steps section pointing at doctor + report run + scan. Plus: doctor's wrong-shape API key check escalates from warn to fail when workspace backend is anthropic (the `sk-proj-*` confusable that bit me at v0.1.81 dispatch time would now error at doctor time, not LLM-call time). No agent system prompt changes — those are v0.1.86 risk-bearing work gated on re-validating 22/22 = 100/100.

**v0.1.83: README/docs accuracy patch.** Three corrections: (1) 22/22 → 23/23 across README + validation doc + CHANGELOG/CLAUDE/DECISIONS — the CI workflow_dispatch artifact (run 25814274941, 2026-05-13) is authoritative at 23/23 against revision 2 labels; the prior 22/22 claim came from a manual recompute against the local Bedrock run's gap-*.json (against revision 1 before the second-pass review), not from an actual rev2 harness run. Both numbers are 100% precision + 100% recall — qualitative claim unchanged. (2) Patch-release count: README/LIMITATIONS/CLAUDE/docs/index.md said "eighty-four patch releases" while only 83 tags existed at v0.1.82 ship time; v0.1.83 release fixed this by making the count correct (84 tags including v0.1.83). (3) docs/index.md status para said "the maintainer-validation LLM-call run for CFN remains the deferred bet-pays-off measurement" — stale post-v0.1.81 close. Updated to current state.

**v0.1.82: README visual content — first-impression credibility.** Adds a real Gap Report HTML screenshot (1280×800, ~100 KB) + a fenced POA&M markdown snippet inline in the README, sourced from the v0.1.81 maintainer-validation run artifacts. First-screen readers see what the output actually looks like before scrolling to install commands. New `scripts/capture-screenshots.sh` regenerates the screenshot from the latest eval-harness run via headless Google Chrome (override `CHROME_BIN` for non-macOS); future validation dispatches can refresh the README hero shot in one command. Pairs with v0.1.79's elevator-pitch lift and v0.1.81's 23/23 = 100/100 numbers to give a complete pitch shape: value-prop → artifact → install. Real artifacts — outputs of the maintainer-validation pass, not doctored examples.

**v0.1.81: CFN maintainer-validation harness + first dispatch run + second-pass label review — strategic gate CLOSED at 23/23 = 100/100.** Bedrock Haiku 4.5 dispatch against csp-starter-cfn produced 60 KSI verdicts; first-pass scored 20/22 = 90.9% precision + 90.9% recall against revision 1 labels; second-pass review (mirroring v0.1.67 TF discipline) alternation-expanded 4 too-tight labels + removed 2 typo KSI IDs (KSI-MLA-LRP, KSI-SVC-EAR — neither exists in FRMR 0.9.43-beta); revision 2 hits 23/23 = 100/100, matching the TF-side v0.1.69 baseline. **Zero property-mapping or detector bugs surfaced** — every first-pass disagreement was labeling-judgment. Tier 5 #1 strategic bet validated; PR gamma.2 batches 5+ (ELBv2 LB/TG, CloudFront, API Gateway, WAFv2) are the natural next coverage-expansion work. Also ships `evals/harness.py` auto-detection of CFN fixtures (adds `--allow-cfn` to scan when sniffing detects `Resources:` in `infra/*.yaml`), `.github/workflows/eval-harness-cfn.yml` workflow_dispatch for future runs, and `evals/PHASE_2_LITE_CFN_VALIDATION.md` with per-KSI analysis. Local run path: `AWS_PROFILE=bedrock-test uv run python -m evals run --fixture evals/fixtures/csp-starter-cfn` (the local `ANTHROPIC_API_KEY` is the wrong-shape OpenAI-style key; Bedrock is the working backend per memory `project_efterlev_test_llm_default.md`).

**v0.1.80: README + LIMITATIONS CFN-support honesty pass.** The README lede + "Why this exists" + "What it does"/Scans bullet + comparison-table "Reads" row all framed Efterlev as Terraform-only — stale post-v0.1.72 when CFN support shipped behind `--allow-cfn`. LIMITATIONS.md was actively wrong, claiming "CloudFormation... deferred to v1.5+" when CloudFormation YAML/JSON has shipped through 4 batches of mapping work + a labeled eval fixture. Honest framing now: TF is the validated primary path; CFN is experimental opt-in with 18 mapped resource types and ~12 detectors firing identically to TF; the empirical maintainer-validation pass remains deferred. Customer-pitch-day release: surgical edits, no functional changes.

**v0.1.79: doc-quality sweep — first-impression polish.** Lifts the strongest two sentences of the README's "Why this exists" section above the install commands as a blockquote so first-screen readers see the value-prop before the code blocks. Adds a real Troubleshooting subsection to the README "How to run it" that lifts the recovery patterns from `docs/ai-quickstart-prompt.md` Step 4 (`terraform init -backend=false` / throwaway-tfvars / HCL-fallback). Improves the keyless `efterlev quickstart` footer to name the three concrete artifacts the user is missing without `ANTHROPIC_API_KEY` (Gap classifications, FRMR attestation drafts, POA&M markdown) instead of the vague pre-v0.1.79 wording. Fixes two stale `0.1.11` version-floor refs in the AI prompt that the v0.1.68 doc-audit sweep missed (now self-evergreening with `pip index versions efterlev` check). Verified-but-not-changed: the `gap-<ts>.json` (flat) vs `poam/poam-<ts>.md` (subdir) path asymmetry in the AI prompt is intentional per cli/main.py:1388-1390; both paths are correct.

**v0.1.78: CFN eval-harness Phase 2 lite scaffolding + first labeled fixture.** Strategic pivot from mapping work to the validation-gate scaffolding the original DECISIONS 2026-05-12 entry framed as the bet-pays-off measurement. New `evals/fixtures/csp-starter-cfn/` fixture covering KMS + S3 + CloudTrail + IAM + RDS + Lambda + Logs in canonical day-one CSP shape (synthetic, NOT vendored — see SOURCE.md for synthesis rationale; no public single-publisher canonical CFN library equivalent of `terraform-aws-modules/*` exists). 9 logical CFN resources expanding to 14 TF-shape via sub-resource synthesis. `GROUND_TRUTH.yaml` revision 1 with conservative labels for ~25 KSIs (Phase 2 lite discipline: conservative-by-default, leave-unlabeled-when-unsure). 11 of 12 detectors fire as expected. **Deferred (memory-tracked)**: the maintainer-validation LLM-call run (gap agent → precision/recall vs labels) — Anthropic spend cap and GitHub Actions minute cap argued for ship-labels-first. The deferred run is the bet-pays-off measurement; memory entry `project_efterlev_cfn_eval_validation_deferred.md` ensures future sessions surface this as unfinished business. Compresses what TF Phase 2 lite spread across v0.1.63→v0.1.67 (4 releases) into one release.

**v0.1.77: Tier 5 #1 PR gamma.2 batch 4 — long-tail services.** Adds 5 mappings: `AWS::CloudTrail::Trail` + `AWS::SNS::Topic` + `AWS::SQS::Queue` + `AWS::DynamoDB::Table` (with SSESpecification/PointInTimeRecoverySpecification list-wrapped-block transforms) + `AWS::SecretsManager::Secret`. Per-detector parity tests for `aws.cloudtrail_audit_logging`, `aws.cloudtrail_log_file_validation`, `aws.sns_topic_encryption`, `aws.sqs_queue_encryption`, `aws.secrets_manager_rotation`. Coverage milestone: **18 CFN types across 13 AWS namespaces** — crosses the loosely-set threshold for the eval-harness CFN-fixture maintainer-validation pass that the original DECISIONS 2026-05-12 entry framed as the "did the strategic bet pay off" measurement.

**v0.1.76: Tier 5 #1 PR gamma.2 batch 3 — KMS + RDS + Lambda mappings.** Adds `AWS::KMS::Key` (with `KeySpec` → `customer_master_key_spec` legacy-attribute rename + KeyPolicy JSON-stringification), `AWS::RDS::DBInstance` (storage_encrypted/kms_key_id/publicly_accessible all renamed), `AWS::Lambda::Function` (introducing the flat-dict-to-list-wrapped-block translation pattern: CFN's flat `Environment.Variables` and `VpcConfig.{SubnetIds, SecurityGroupIds}` become TF's `environment[0].variables` and `vpc_config[0].{subnet_ids, security_group_ids}` matching python-hcl2's nested-block convention). 11 new tests including per-detector parity for `kms_key_rotation`, `rds_encryption_at_rest`, `rds_public_accessibility`, `lambda_env_kms_encryption`, `lambda_vpc_isolation`. With batch 3 the table now demonstrates four orthogonal structural-translation patterns (per-key rename + structural wrap + sub-resource synthesis + flat-dict-to-list-wrapped-block); remaining batches are mostly per-key-rename mechanics. Coverage now 13 CFN types.

**v0.1.75: Tier 5 #1 PR gamma.2 batch 2 — IAM family mappings.** Adds `AWS::IAM::Role`, `AWS::IAM::ManagedPolicy`, `AWS::IAM::User` mappings. Introduces the 1→(1+N+M) sub-resource synthesis pattern: CFN bundles managed-policy attachments and inline policies into the Role/User's own properties; the mapping synthesizes the per-attachment (`aws_iam_role_policy_attachment`, suffix `_attach_<idx>`) and per-policy (`aws_iam_role_policy`, suffix `_inline_<PolicyName>`) resources TF detectors expect. `aws.iam_admin_policy_usage` and `aws.iam_inline_policies_audit` now fire on CFN inputs identically to TF — validated by parity tests including the negative cases (read-only policy doesn't fire admin detector). 11 new tests. Bug caught + fixed during the batch: PyYAML parses YAML date-shaped scalars (e.g. policy version "2012-10-17") as `datetime.date` objects which `json.dumps` rejects; fix is `default=str` on all 5 json.dumps calls. Coverage now 10 CFN types.

**v0.1.74: Tier 5 #1 PR gamma.2 batch 1 — EC2 + Logs property mappings.** Extends v0.1.73's mapping table with `AWS::EC2::FlowLog` (with `(ResourceType, ResourceId)` discriminator dispatch into `vpc_id`/`subnet_id`/`eni_id`), `AWS::EC2::SecurityGroup` (with `SecurityGroupIngress`/`Egress` list translation into TF inline-block shape, including CFN scalar `CidrIp` → TF list `cidr_blocks`), `AWS::EC2::Volume`, and `AWS::Logs::LogGroup` (explicit `tf_type` override). The first batch where parsing+adapting+detecting on the existing vendored `aws-vpc-cfn` template (from `aws-quickstart/quickstart-aws-vpc`) emits real Evidence end-to-end — `test_aws_vpc_cfn_fixture_emits_flow_log_evidence` validates this. 13 new tests (per-mapping + per-detector parity + integration). Coverage now 7 CFN types.

**v0.1.73: Tier 5 #1 PR gamma — CFN→TF property-mapping table.** Centralized per-resource-type table mapping CFN property paths to TF body keys, with structural transforms for the cases where CFN and TF disagree on nesting. Coverage at v0.1.73: 3 CFN types (`AWS::S3::Bucket` with both `BucketEncryption` structural transform + sub-resource synthesis of `aws_s3_bucket_public_access_block` from `PublicAccessBlockConfiguration`; `AWS::S3::BucketPolicy` with JSON-stringify of policy doc; `AWS::ElasticLoadBalancingV2::Listener` with explicit `tf_type` override + first-cert extraction). The architectural call delegated by the user ("you decide" 2026-05-12): option (D) per-resource-type table chosen over (A) IR refactor / (B) N-detectors / (C) per-detector dual-mode — rationale documented in DECISIONS 2026-05-12 amendment. Parity test suite (`tests/test_cfn_property_mapping.py`) asserts CFN inputs emit identical Evidence to equivalent TF for each of the 3 sample detectors from the original DECISIONS entry. The `adapt_cfn_to_terraform` signature widened from 1→1 to 1→N (a single CFN resource may yield multiple TF resources). Bulk sweep over remaining ~50 detectors' resource types is PR gamma.2.

**v0.1.72: Tier 5 #1 PR beta — CFN parser + adapter + scan integration + first vendored CFN fixture.** First code shipment of the CloudFormation/CDK synth-mode arc. Plumbing-only — per-detector property mapping is PR gamma with honest scope acknowledgment in the new modules' docstrings. New `src/efterlev/cloudformation/` package: `parser.py` handles all 19 CFN intrinsic-function YAML tags via a `_CfnSafeLoader` subclass that doesn't pollute the global SafeLoader; `adapter.py` does CFN-type translation (`AWS::S3::Bucket` → `aws_s3_bucket`, clean for ~80% of common AWS resource types) + shallow snake_case body mirror. New primitive `scan_cloudformation` runs the SAME `source="terraform"` detectors over CFN-adapter-shaped resources. CLI flag `--allow-cfn` (off by default; default-on after PR gamma + design-partner validation). First vendored CFN fixture `evals/fixtures/aws-vpc-cfn/` from `aws-quickstart/quickstart-aws-vpc` commit `e7ab8614` (Apache 2.0; ~75 raw `AWS::EC2::*` resources). Honest finding while implementing: the DECISIONS entry's "most existing detectors work unchanged" framing was too optimistic — CFN and TF property structures diverge enough per-resource that uniform translation isn't tractable at the adapter layer; PR gamma must make the IR-vs-N-detectors call with full information. v0.1.72 plumbing is honest + verifiable + leaves the architectural call open.

**v0.1.71: README tagline rephrase.** Per maintainer feedback, the lead tagline reframes from "Compliance scanning for SaaS teams pursuing FedRAMP 20x — that lives in your repo, not a SaaS dashboard." to "Open source. Runs locally. Compliance evidence lives in your repo alongside the code it describes." The new tagline leads with the open-source + local positioning that distinguishes Efterlev from the SaaS GRC competitive landscape; FedRAMP 20x framework specificity moved to the body sentence.

**v0.1.70: CFN/CDK synth-mode design DECISIONS entry (Tier 5 #1) + docs/index.md feature-list refresh.** Locks the architectural shape of the CFN/CDK support work (v1 = scan CFN JSON whether hand-authored or `cdk synth`-generated; thin adapter shim over IaC-agnostic IR refactor; auto-detect by extension + `Resources` content sniff; behind `--allow-cfn` flag at v0; design-partner recruitment WITH the work) + 3-PR α/β/γ rollout sequence (α this release; β = parser + adapter + 3 sample detector adaptations + 1 CFN fixture; γ = bulk detector sweep + scan integration + design-partner outreach). Code lands across v0.1.71+. The strategic-arc gate that opened with v0.1.69's Phase 2 lite validation is now being walked through.

**v0.1.69: Phase 2 lite maintainer validation — 67/67 labels at 100/100, 0 overrides.** Ran the harness against each Phase 2 lite fixture with a real `ANTHROPIC_API_KEY` (the maintainer-review-pass step that v0.1.67's `PHASE_2_LITE_LABEL_REVIEW.md` documented as the API-key-required follow-on). All 67 claude-drafted labels validated: aws-vpc-tfm 21/21, aws-s3-bucket-tfm 25/25, aws-lambda-tfm 21/21 — 100% precision + 100% recall on each. Side-by-side reasoning in `evals/PHASE_2_LITE_MAINTAINER_VALIDATION.md`. **The strategic-arc gate to start CFN synth-mode design is now genuinely open** — Phase 2 lite is operational as the regression instrument the CFN/CDK expansion was structurally gated on. v0.1.67's tightenings on the Lambda fixture (CNA-MAT `not_implemented|partial` → `not_implemented`; MLA-LET `not_implemented|partial` → `partial`) nailed the agent's exact verdict, validating the second-pass review discipline.

**v0.1.68: documentation audit sweep.** Stale count refs and capability claims accumulated across the v0.1.55-v0.1.67 release marathon (13 releases on 2026-05-11 alone) brought back into sync. LIMITATIONS "It does not cover the full FedRAMP 20x Moderate KSI set via detectors alone" section: v0.1.17/45 detectors → v0.1.67/66 detectors; 31 of 60 → 37 of 60. docs/aws-coexistence: detector-breakdown counts updated (38→62 KSI-mapped); KSI coverage 31→37; threshold math redone (~33/63 ~52% → ~40/60 ~67%, now roughly at the 70% Phase 2 line). docs/ai-quickstart-prompt: workflow-detector count 4→5. docs/quickstart: troubleshooting-block "we ship 45 detectors" → 66. docs/v0.2-eval-harness-plan: Phase 1/Phase 2/Phase 3 lines annotated with "shipped at vX.Y" status (Phase 2 shipped as "Phase 2 lite" v0.1.63-v0.1.67).

**v0.1.67: Phase 2 lite second-pass label review.** Walked the 67 conservative claude-drafted labels from v0.1.64-v0.1.66 against the canonical FRMR statements + the available scan evidence. 6 revised (3 tightenings: aws-s3 AFR-UCM, aws-lambda CNA-MAT + MLA-LET; 3 loosenings: aws-vpc CNA-MAT + CNA-RNT, aws-s3 SVC-RUD), 61 confirmed unchanged. Consolidated reasoning + per-KSI confidence + maintainer-review-pass workflow under `evals/PHASE_2_LITE_LABEL_REVIEW.md`. The 6 revisions skew toward tightening evidence-supported labels (drop alternations that were "reading-into-the-future") and loosening alternation-eligible cases for symmetry across fixtures.

**v0.1.66: Phase 2 lite expansion — third real-shape fixture (Lambda).** `aws-lambda-tfm` vendored verbatim from `terraform-aws-modules/terraform-aws-lambda` v8.8.0 (commit `b8423741`). Rounds out the initial three-fixture corpus covering the most-common AWS workload patterns (network/segmentation, storage/encryption, serverless compute). 21 conservative draft labels — 4 KSIs WITH detector evidence (KSI-CNA-MAT Lambda internet-facing, KSI-MLA-LET logging unverifiable, KSI-MLA-OSM producers-only, KSI-PIY-GIV) + 17 procedural-only. Phase 2 lite labeled-KSI count: 46 → 67.

**v0.1.65: Phase 2 lite expansion — second real-shape fixture.** `aws-s3-bucket-tfm` vendored verbatim from `terraform-aws-modules/terraform-aws-s3-bucket` v5.13.0 (commit `af0286ff`). Companion to v0.1.63's VPC fixture: where VPC exercises network/segmentation detector dimensions, this exercises storage + encryption (S3 SSE, public-access-block, ACL, lifecycle, replication, versioning, ownership, logging). 25 conservative draft labels — 8 KSIs WITH detector evidence (KSI-AFR-UCM split-resource encryption pattern, KSI-CNA-MAT/RNT unparseable from jsonencode, KSI-CNA-OFA replication, KSI-IAM-AAM, KSI-PIY-GIV, KSI-RPL-ABO unresolvable versioning, KSI-SVC-RUD placeholder lifecycle), 17 procedural-only — same labeling discipline as v0.1.64 (claude-drafted from scan output, no LLM agent verdict consulted, awaits maintainer review). Phase 2 lite labeled-KSI count: 21 → 46.

**v0.1.64: Phase 2 lite first labels (claude-drafted) + harness scan-fix.** Bug fix: `evals/harness.py` now passes `--allow-subdir-target` on its internal scan invocation (v0.1.59 hard-error broke the harness end-to-end; v0.1.59's CI-compat sweep got e2e_smoke + release-smoke but missed evals). Plus 21 conservative evidence-based draft labels for the v0.1.63 fixture, authored by reading the deterministic scan output (NO LLM agent verdict consulted — avoids confirmation-bias). Marked "claude-drafted, awaits maintainer review" for spot-check during evening grading sessions.

**v0.1.63: eval-harness Phase 2 lite scaffolding — first real-shape fixture vendored.** Strategic-arc kickoff per the 2026-05-11 conversation (memory: `project_efterlev_strategic_arc_2026-05.md`): Phase 2 lite is the gating prerequisite before CFN/CDK market expansion. The 5 in-repo Phase 1 fixtures all hit 1.000/0.000 — overfit because the prompts were tuned against them. v0.1.63 vendors `terraform-aws-modules/terraform-aws-vpc` v6.6.1 verbatim (Apache 2.0; provenance under `evals/fixtures/aws-vpc-tfm/SOURCE.md`) as the first real-shape fixture, with empty-labels `GROUND_TRUTH.yaml` ready for evening labeling sessions. New `tests/test_eval_fixtures_parse.py` parametrizes over every fixture and confirms `infra/` parses + `GROUND_TRUTH.yaml` carries required fields — guards at PR time against an upstream re-vendor breaking the format. User's chosen fixture-sourcing path: public open-source corpora (vs design-partner real-customer boundaries).

**v0.1.62: pypa/gh-action-pypi-publish SHA-pinned to v1.14.0.** Closes the v0.1.60 SHA-pinning gap — that release left `pypa/gh-action-pypi-publish@release/v1` (a moving branch ref documented as canonical install) on a tag-pin, deferred for a follow-on. v0.1.62 lands the follow-on: pin to v1.14.0's commit SHA so all third-party Action references across all workflows are now SHA-pinned with no exceptions. Dependabot's wildcard github-actions group (v0.1.60) picks up future v1.x releases automatically.

**v0.1.61: pip-audit + bandit baked into [dev] extra.** CI was using `uv run --with pip-audit` (pip-audit) and `pip install --upgrade 'bandit[toml]>=1.7,<2'` (bandit), both fetching whatever PyPI happens to have on every CI run — defeats reproducibility AND means a Bandit release with a regression could turn green PRs red overnight without any code change here. v0.1.61 adds both to `[project.optional-dependencies].dev` (pinned via uv.lock + grouped via Dependabot's existing Python group) and switches CI to `uv run pip-audit ...` / `uv run bandit ...` against the lockfile. Local-dev parity with CI as the bonus. Closes `docs/security-review-2026-04.md` §7.

**v0.1.60: third-party GitHub Actions SHA-pinned + Dependabot grouping wildcarded.** OpenSSF Scorecard / SLSA L3 expectation closed. Every third-party `uses: <org>/<repo>@<tag>` across all workflows rewritten to `uses: <org>/<repo>@<full-sha> # <tag>` (tag preserved as comment for human readability + Dependabot version-bump detection). Pinned: astral-sh, sigstore, anchore, returntocorp, docker. Skipped: pypa/gh-action-pypi-publish@release/v1 (moving branch ref documented as canonical install — different pinning strategy needed). First-party `actions/*` and `github/*` left tag-pinned per common GitHub convention. Dependabot's github-actions group rewritten from `update-types: [minor, patch]` to `patterns: ["*"]` so the SHA-pin update churn lands as one grouped PR per cycle rather than ~10 separate PRs.

**Coverage at v0.1.105:**
- 66 detectors total (62 KSI-mapped + 4 supplementary 800-53-only)
- 37 of 60 thematic KSIs covered, across 10 of 11 themes (CMT, CNA, IAM, MLA, PIY, RPL, SCR, SVC, plus partial PIY via the v0.1.34 github workflow detector now widened by v0.1.55's branch-protection detector to the merge-enforcement layer, plus partial AFR-UCM via the v0.1.42 cryptographic-module mapping audit). The remaining KSIs (most of CED, INR, AFR) are covered by Evidence Manifests, not detectors. KSI-CNA-RVP is the most cross-resource-type-evidenced KSI in the library by a wide margin (9 detectors after v0.1.50). KSI-PIY-RSD now has 2-detector cross-coverage (workflow + branch-protection layers).
- 26 hand-authored Evidence Manifest templates for the procedural KSIs (`efterlev manifests init --starter-pack`, v0.1.21+; expanded from 24 in v0.1.36 with KSI-MLA-RVL + KSI-SVC-EIS to close the Tier 1 #4 design entry's projected manifest follow-ups)
- 3 agents: Gap (Opus 4.7), Documentation (Sonnet 4.6), Remediation (Opus 4.7) — all with system prompts rewritten v0.1.43 against the current Anthropic best-practices guide
- Two LLM backends: direct Anthropic (default) + AWS Bedrock (`[bedrock]` extra, GovCloud)
- 1554 tests passing; mypy strict + ruff check + ruff format clean across 226 source files; 31 CLI commands; full E2E pipeline smoke runs on every PR; ConMon Lite v0 (scanner-only) sticky comments on every PR (Tier 4 #1, v0.1.51); ConMon Lite v1 (KSI-verdict regressions, opt-in via EFTERLEV_CONMON_LITE_V1) (Tier 4 #2, v0.1.52); `efterlev detectors new <id>` contributor scaffolder (v0.1.53); `efterlev boundary set --interactive` helper (v0.1.54); `github.branch_protection` detector (v0.1.55); `efterlev detectors show <id>` read/inspect command (v0.1.56); wheel + sdist CycloneDX SBOMs on every GitHub Release (v0.1.57); `efterlev manifests validate <path>` offline schema-validation gate (v0.1.58); `efterlev scan` hard-errors on subdir-below-workflows-ancestor with `--allow-subdir-target` opt-in (v0.1.59); third-party GitHub Actions SHA-pinned across all workflows + dependabot group wildcarded (v0.1.60); pip-audit + bandit baked into [dev] extra and run lockfile-pinned in CI (v0.1.61); pypa/gh-action-pypi-publish SHA-pinned to v1.14.0 closing the v0.1.60 SHA-pinning gap (v0.1.62); eval-harness Phase 2 lite scaffolding with first real-shape fixture vendored (v0.1.63)
- 5 eval-harness fixtures (govnotes-v1, encryption-mixed, iam-dynamic-policy, runtime-monitoring, serverless-mixed at rev 7) — each at 1.000 mean / 0.000 stddev across 5-run aggregates on the post-v0.1.43 prompts
- Cross-platform install matrix green across mac (13 + 14) / Windows (2022) / Linux (Ubuntu 22.04 + 24.04 ARM) × pipx + docker-ghcr methods, validated on every tag via `release-smoke.yml` and surfaced on the GH Release page via T7 in `scripts/triage.sh` (v0.1.22+)
- Token usage telemetry on Claim records + `receipts.log` (per-run cost auditing without CloudWatch); end-of-run cost summary on every agent command (v0.1.19+); `--dry-run` / `--dump-prompt` for prompt audit (v0.1.20+)
- Documentation report JSON sidecar schema v1.1 (`controls_mapped` + aggregate `boundary_state` per attestation; v0.1.11)
- Cosign-verifiable SLSA build provenance attached to every container release via `actions/attest-build-provenance` (v0.1.13+)
- `PLW1514` (unspecified-encoding) enforced at lint time + `EXPECTED_DETECTORS` source-level pin in `tests/test_triage_constant_alignment.py` (v0.1.29) — both caught real drift at PR time across the v0.1.28–v0.1.34 detector backlog

**Authoritative sources for "what's in":**
- `CHANGELOG.md` — release-by-release record. Don't restate it here.
- `git log` — commit-level history
- `DECISIONS.md` — append-only architectural decision log; every non-trivial choice is here
- `docs/followups.md` — tracker for v0.1.x and v0.2.0+ deferred work

**Canonical dogfood target:** `lhassa8/govnotes-demo`. 24 documented "deliberate gaps" spanning 16 KSIs across 8 themes, plus 3 Evidence Manifests for procedural AFR/CED/INR theme KSIs. Synthetic FedRAMP boundary built specifically for compliance-scanning evaluation. Re-running the full pipeline against it costs ~$2.60 in Anthropic API and is the reference test for any non-trivial Efterlev change. The repo's own `efterlev-scan.yml` workflow runs the full pipeline on every push touching infra/workflows/manifests.

**What's deferred** (not in v0.1.x): OSCAL-shaped SSP/AR/POA&M JSON generators (v1.5+, gated on customer pull); non-Terraform input sources (CloudFormation, CDK, Pulumi, Kubernetes — v1.5+); CMMC 2.0 overlay (v1.5+); runtime cloud API scanning (different threat model — v1.5+). The streaming refactor of the Anthropic client previously listed here as v0.2.0 work shipped in v0.1.47 (DECISIONS PR #219, implementation PRs #220 + #221).

---

## Path forward (v0.1.105+)

The v0.1.12–v0.1.16 arc closed the post-release-validation feedback loop:
findings F1–H1 + the v0.1.16 first-of-kind auto-triage findings all landed
through the same shape — ship → triage → fix in next release. The
methodology is now codified as `scripts/triage.sh` + `.github/workflows/post-release-triage.yml`,
which auto-runs on every tag push and posts the report as the GitHub
Release notes body, with T7 surfacing matrix conclusion (v0.1.22+).

**Tier 1 fully complete.** All four originally-planned Tier 1 items
shipped: #1 quickstart (v0.1.18), #2a cost summary (v0.1.19), #2b
`--dry-run`/`--dump-prompt` (v0.1.20), #3 manifest starter pack (v0.1.21),
#4 detector gap analysis + 6-detector backlog (v0.1.28–v0.1.34). KSI
coverage moved from 30/60 to 36/60 across the #4 sequence — exactly
matching the DECISIONS 2026-05-07 design entry's projected outcome.

### Tier 1 — shipped (per DECISIONS 2026-05-06 sequencing)

- ~~#1 `efterlev quickstart`~~ **shipped at v0.1.18.** One-command
  activation demo for ICP A's day-one experience. Bundled FIXTURE +
  `python -m efterlev` entry point.
- ~~#2a end-of-run cost summary~~ **shipped at v0.1.19.** Token usage
  surfaced at agent-command stdout (model, tokens in/out, $ estimate).
- ~~#2b `--dry-run` / `--dump-prompt`~~ **shipped at v0.1.20.** Prints
  the assembled, scrubbed prompt and exits without calling Claude.
  3PAO-grade audit primitive.
- ~~#3 Manifest starter pack~~ **shipped at v0.1.21 (24 templates); expanded
  to 26 at v0.1.36** with KSI-MLA-RVL + KSI-SVC-EIS, closing the
  Tier 1 #4 design entry's projected manifest follow-ups. Hand-authored
  Evidence Manifest templates (10 AFR + 4 CED + 3 INR + 4 PIY + 1 each
  CMT-RVP / RPL-RRO / SVC-PRR / MLA-RVL / SVC-EIS).
  `efterlev manifests init --starter-pack` copies them into
  `.efterlev/manifests/starter-pack/` (subdir, outside the loader's
  pickup glob — safe by default; `--force` to overwrite).
- ~~#4 Detector gap analysis + prioritized adds~~ **shipped at v0.1.28–v0.1.34
  (6/6 detectors per DECISIONS 2026-05-07 backlog).** `aws.cna_optimizing_for_availability`
  (v0.1.28); `aws.mla_log_access_least_privilege` (v0.1.30);
  `aws.cna_dos_protection` (v0.1.31); `aws.svc_at_rest_encryption_coverage`
  (v0.1.32); `aws.rpl_backup_configured` (v0.1.33);
  `github.piy_sdlc_security_gates` (v0.1.34). All six classified
  `evidenceable-via-iac` or `partial` per the design; the 24
  `procedural-only` KSIs identified in the same analysis are covered
  by the v0.1.21 starter pack (with two follow-up templates pending —
  KSI-MLA-RVL + KSI-SVC-EIS).

### Small follow-ups (when convenient)

- **2 Evidence Manifest templates** for the procedural-only KSIs the
  v0.1.21 starter pack didn't cover: `KSI-MLA-RVL` (log review) and
  `KSI-SVC-EIS` (security improvement review). Single small PR.

### Tier 2 — serverless detector batches (shipped)

- **Tier 2 #1** — `aws.lambda_logging_configured`,
  `aws.api_gateway_tls_min_version` + `serverless-mixed` fixture
  (DECISIONS 2026-05-09 PR #196; v0.1.44).
- **Tier 2 #2** — `aws.lambda_env_kms_encryption`,
  `aws.api_gateway_access_logging` + serverless-mixed rev 2
  (DECISIONS 2026-05-10 PR #200; v0.1.44).
- **Tier 2 #3** — `aws.lambda_vpc_isolation`,
  `aws.api_gateway_auth_required`, `aws.api_gateway_waf_attached` +
  serverless-mixed rev 3 (DECISIONS 2026-05-10 PR #205; v0.1.45).
  Closes the original 5-detector deferred backlog from PR #196.
- **Tier 3 #1** — `aws.waf_rule_count`, `aws.waf_managed_rule_groups`,
  `aws.waf_rate_limiting` + serverless-mixed rev 4 (DECISIONS 2026-05-10
  PR #213; v0.1.46). Closes the WAF posture-quality dimension that
  the Tier 2 #3 attachment-only detector left unaddressed.
- **Tier 3 #2** — Anthropic-client streaming refactor + Gap Agent
  max_tokens cap lift 20480 → 32768 (DECISIONS 2026-05-10 PR #219;
  implementation PRs #220 + #221; v0.1.47). Removes the deterministic
  Anthropic-direct ceiling that PR #217 surfaced as a recurring flake;
  unblocks fixture growth and customer-codebase scans previously
  gated by the cap.
- **Tier 3 #3** — `aws.waf_action_types` + `aws.waf_ip_set_blocking`
  + serverless-mixed rev 5 (DECISIONS 2026-05-10 PR #223;
  implementation PRs #224 + #225 + #226; v0.1.48). Closes the
  action-type + IP-set-blocking dimensions deferred from Tier 3 #1
  Decision #7. `waf_ip_set_blocking` is the first WAF detector to
  evidence AC-3 (Access Enforcement) at the IaC layer.
- **Tier 3 #4** — `aws.waf_geo_blocking` + serverless-mixed rev 6
  (DECISIONS 2026-05-10 PR #229; implementation PRs #230 + #231;
  v0.1.49). Closes the geo-blocking dimension deferred from Tier 3
  #1 Decision #7. First WAF-family detector to evidence SC-7
  (Boundary Protection) at the IaC layer.
- **Tier 3 #5** — `aws.waf_custom_rule_groups` + serverless-mixed
  rev 7 (DECISIONS 2026-05-10 PR #233; implementation PRs #234 +
  #235; v0.1.50). Cross-resource detector closing the WAF family
  at 7/7 v0/v1 dimensions. The `defined_rule_groups` inventory
  surfaces the "defined but unreferenced" anti-pattern for the
  Gap Agent. The 5-batch WAF arc spanning v0.1.46–v0.1.50 is now
  complete.
- **Tier 4 #1** — ConMon Lite v0 (DECISIONS 2026-05-11 PR #237;
  implementation PRs #238 + #239; v0.1.51). PR-delta scan
  comparison with sticky comments. Scanner-only (deterministic +
  free).
- **Tier 4 #2** — ConMon Lite v1 (DECISIONS 2026-05-11 PR #241;
  implementation PRs #242 + #243; v0.1.52). Gap-Agent KSI-verdict
  regression diff with 2-of-3 majority voting. Closes the
  verdict-stability deferral from Tier 4 #1. Opt-in via
  `EFTERLEV_CONMON_LITE_V1` repo variable (default OFF; per-PR
  cost ~$0.90 on Sonnet 4.6).

### Tier 2 — held; each gets its own DECISIONS entry when promoted

- **ConMon Lite v2 candidates** — configurable severity thresholds,
  gating policy (block-on-regress with skip label), drift detection
  over time (not just PR-delta), suppression annotations
  (`# efterlev-ignore: KSI-X`).
- **`aws.waf_*` further extensions** beyond v0/v1 (version pinning,
  scope-down breadth, custom-aggregation keys, action-type
  appropriateness per managed-group). Tier 4 candidates; each
  warrants its own scoping pass when there's customer pull or
  specific findings.
- **Cross-platform CI gate on every PR** (Tier 2 candidate from
  DECISIONS 2026-05-07 v0.1.25 entry — would catch Windows-cascade-style
  bugs at PR time, not only at tag time). Tradeoff: doubles CI minutes
  per PR; held until Actions minutes negotiation.
- CloudFormation/CDK source support (ICP doc names this v1 month 1–2).
- Boundary-scoping interactive helper.
- Detector scaffolder for OSS-contribution friction reduction.
- Branch-protection-rule detection (Tier 1 #4 design called this out
  as a follow-up to `github.piy_sdlc_security_gates` — needs the
  GitHub Terraform provider + `github_branch_protection` reader).

### Out of scope this cycle (decline if proposed)

No web UI. No SaaS / multi-tenancy. No runtime cloud API scanning. No CMMC
overlay. No additional frameworks (SOC 2, ISO 27001, HIPAA, etc.). No
Pulumi or Kubernetes support yet. If you find yourself proposing any of
these, stop and ask before continuing.

### Working agreement (carries forward unchanged)

- Each Tier 1 item lands as its own PR with its own DECISIONS entry surfaced
  for review *before* implementation starts.
- LIMITATIONS.md and the relevant docs update in the *same PR* as the
  feature — never deferred to a follow-up. The check-docs path-shape +
  current-version-claim rules (v0.1.12 + v0.1.14) and the auto-triage T6
  phase enforce this on every release.
- Per-fix regression test discipline (CLAUDE.md "Per-fix regression test
  discipline (v0.1.10+)") applies to every patch in this sequence.
- **Source-level pin tests** for platform-specific fixes (the v0.1.23–v0.1.27
  pattern). When a fix is platform-gated, add a test that reads the source
  and asserts the platform check + fix shape are present. A/B-verify before
  commit (revert fix → test fails with prod's exact error). This catches
  regressions on every dev platform without needing the failing platform's
  CI runner.

---

## Known gotchas (v0.1.x lessons)

These have all surfaced in real CI, so they're not theoretical:

- **Anthropic non-streaming threshold.** `client.messages.create()` rejects requests whose `max_tokens` could plausibly take >10 minutes ("Streaming is required for operations that may take longer than 10 minutes"). Empirically, `max_tokens > ~24000` for Opus 4.7 trips this on real workloads. v0.1.2 holds the Gap Agent at 20480 — enough headroom over the v0.1.0 truncation site (~16384 was too small for a full-baseline classification with substantive rationales). Pushing the cap past ~24K means switching to `client.messages.stream()`. Don't bump the cap blindly.

- **`.efterlev/manifests/` committed; everything else gitignored.** This is the canonical Evidence-Manifest pattern. A fresh clone has the workspace dir present (because manifests are checked in) but the FRMR cache, provenance store, etc. missing. `report run` and `init` both check for the FRMR cache file (`.efterlev/cache/frmr_document.json`), not just the dir, to distinguish "fully initialized" from "half-initialized." If you change the init-detection logic, preserve this distinction.

- **`__version__` lives in `src/efterlev/__init__.py` only.** `pyproject.toml` reads it via `[tool.hatch.version] path = "src/efterlev/__init__.py"`. There's a CI-time regression test (`test_in_source_version_matches_package_metadata`) that asserts `efterlev.__version__ == importlib.metadata.version("efterlev")`. Bumping the version means editing `__init__.py` only and rebuilding (uv sync handles this on dev; hatch handles it on the wheel build).

- **`# nosemgrep:` annotations need the full registry-resolved rule_id, not the short name.** Bare `# nosemgrep` (suppress all on the line) works; `# nosemgrep: dangerous-subprocess-use-audit` does NOT, because semgrep matches against `python.lang.security.audit.dangerous-subprocess-use-audit.dangerous-subprocess-use-audit` (the full path from the registry pack). Caused every push-event ci-security run on main to fail silently from v0.1.0 launch through v0.1.1.

- **`python-hcl2` doesn't resolve `${...}` interpolations.** Detectors matching string literals (e.g., `policy_arn == "arn:aws:iam::aws:policy/AdministratorAccess"`) miss when the source uses `arn:${local.partition}:iam::aws:...`. For test targets, hardcode `arn:aws:`. For real-world detection robustness, use plan-JSON mode (`efterlev scan --plan plan.json`) which gives Terraform-resolved values.

- **GitHub-source detectors fire only when the scan target sees `.github/workflows/`.** `efterlev scan --target infra/terraform/` skips them. For mixed-content repos, scan from repo root (`--target .`) — `.tf` files are still found via rglob.

- **Bedrock client needs `read_timeout=600` + boto retries disabled, AND a tight OUR-retry loop on top (v0.1.42).** boto3 defaults to `read_timeout=60` + 3 retries. Gap Agent prompts (60 KSIs × evidence) routinely exceed 60s; the 3 retries triple wasted cost before our retry loop fires. v0.1.3's `bedrock_client._client()` sets `Config(read_timeout=600, connect_timeout=10, retries={"max_attempts": 1})`. Don't remove that config — it's load-bearing for any first-run on Opus 4.7. **v0.1.42 added the OUR-side retry-loop tightening:** ReadTimeoutError caps at `_MAX_READ_TIMEOUT_RETRIES=1` (each ReadTimeout burns 600s — 3 retries = 30 min of silent wedge), `_MAX_TOTAL_WALL_SECONDS=1200` hard ceiling on the entire `complete()` call, and `_emit_progress()` writes `[bedrock] …` lines to stderr (with flush) so the user sees retry attempts even with logging unconfigured. Surfaced by the v0.1.35 deep-test session where `report run` wedged for 24 minutes at 0% CPU on a single agent call. Don't loosen the ReadTimeout cap or the wall-clock ceiling without re-thinking the silent-wedge failure mode.

- **LLMs occasionally wrap structured output in ` ```json ` fences** despite explicit system-prompt instructions to return raw JSON (Opus 4.6 on Bedrock especially). v0.1.3's `agents.base._strip_code_fences` strips them defensively before `json.loads`. Raw JSON passes through unchanged. Test coverage in `tests/test_agents.py::test_strip_code_fences_*`.

- **Bedrock model defaults go stale across model releases.** `init --llm-backend=bedrock` probes `bedrock.list_inference_profiles(typeEquals="SYSTEM_DEFINED")` and picks the latest available Anthropic Opus when `--llm-model` is unset. The hardcoded `DEFAULT_BEDROCK_MODEL` is the fallback when probing fails. **Probe semantics (v0.1.36+):** filters to `us.*` cross-region inference profiles ONLY (excludes `eu.*`/`apac.*`/`global.*` — `global.*` forfeits the US-region geographic guarantee some FedRAMP boundary documentation depends on). Sorts by parsed `(major, minor, date_int, rev)` tuple — NOT lexically. v0.1.0–v0.1.36 used a lexical sort that picked Opus 4.0 over Opus 4.1 (`4-2…date` outranked `4-1…` lexically because `2`>`1` at position 14). The parser handles both modern (`claude-opus-4-7-v1:0`, `claude-opus-4-1-20250805-v1:0`) and legacy (`claude-3-opus-…`, `claude-3-5-sonnet-…`, `claude-3-7-sonnet-…`) ID shapes. The helper supports `opus`/`sonnet`/`haiku` families; today only Opus is wired to the init probe — per-agent Sonnet/Haiku Bedrock defaults are a Tier 2 candidate. Tests in `tests/test_bedrock_probe.py` lock the contract.

- **`gh run list` collapses workflow_run state to one column.** A matrix workflow can have every cell failing while the row shows "queued" or "in_progress" — the workflow_run row only flips to "failure" once ALL cells have a definite outcome, and matrix cells that never get scheduled keep the workflow in queued state indefinitely. v0.1.20–v0.1.21 shipped with `release-smoke` red across every cell because nobody noticed via the collapsed view. v0.1.22 added T7 to `scripts/triage.sh` to surface matrix conclusion on the GH Release page so this can't recur. Always check `gh run view <id>` per-cell when a matrix workflow looks "still running" for an unusually long time.

- **Windows / `efterlev` cross-platform pitfalls (v0.1.23–v0.1.27 cascade).** Five distinct categories the silent matrix masked, all now fixed + locked with source-level pin tests. Avoid re-introducing:
  - **`fcntl` is POSIX-only.** Use the platform-gated `_flock_exclusive` / `_flock_release` helpers in `efterlev.provenance.receipts` (fcntl on POSIX, msvcrt on Windows). `tests/test_receipts_locking.py::test_no_unconditional_fcntl_import_in_receipts` fails the suite if a top-level `import fcntl` reappears.
  - **`Path.open()` defaults to OS-default encoding** (cp1252 on Windows). For any file containing non-ASCII (FRMR catalog, manifests, source files), pass `encoding="utf-8"` explicitly. **Enforced at lint time by ruff `PLW1514`** since v0.1.27+ — every new `Path.open()` / `read_text()` / `write_text()` / text-mode `tempfile.NamedTemporaryFile` call must pass `encoding=`. `tests/test_frmr_loader.py::test_loader_source_explicitly_passes_utf8_to_open` adds a targeted source-level pin on the FRMR loader.
  - **`sqlite3.connect()` defaults to read-write.** When the SQLite store may be on read-only media or root-owned (docker-ghcr scenario), use URI mode: `sqlite3.connect(f"file:{path}?mode=ro&immutable=1", uri=True)`. The `immutable=1` flag is required if the store uses `PRAGMA journal_mode=WAL` (ours does) — `mode=ro` alone fails because WAL still needs a writable journal-file open in the dir.
  - **`msvcrt.locking()` is byte-range based** (unlike POSIX `fcntl.flock` which locks the whole file). With `O_APPEND`, file position advances after each write, so unlock targets a different byte range than lock. Always `os.lseek(fd, 0, os.SEEK_SET)` before both lock and unlock so they target the same byte range. `tests/test_receipts_locking.py::test_windows_lock_helpers_lseek_to_byte_zero_before_lock_and_unlock` pins this.
  - **Windows console default encoding is cp1252.** `cli/main.py` reconfigures `sys.stdout` and `sys.stderr` to UTF-8 at import time on Windows so non-Latin-1 chars in CLI output (⚠ etc.) don't crash with `UnicodeEncodeError`. `tests/test_cli_windows_stdio.py` pins this.

---

## Non-negotiable principles

These override local convenience. If you feel tempted to violate one, stop and ask.

1. **Evidence before claims.** Deterministic scanner output is primary, high-trust, citable. LLM-generated content (narratives, classifications, mappings, remediation proposals) is secondary, carries confidence levels, and is explicitly marked "DRAFT — requires human review" in output. The two classes are visible in the data model, the FRMR output, and every rendered report.
2. **Provenance or it didn't happen.** Every generated claim — finding, narrative, classification, remediation — emits a provenance record linking it to its upstream sources (detector output, evidence records, LLM calls). No exceptions, not for speed, not for demo polish.
3. **FRMR primary, OSCAL secondary.** The user-facing layer is KSIs and Themes; 800-53 Controls remain first-class because KSIs reference them, but they're the underlying layer. FRMR-compatible JSON is what the Documentation Agent produces. OSCAL-shaped output generators are v1.5+ for users transitioning Rev5 submissions. The internal data model is our own Pydantic types; FRMR and OSCAL are produced at the output boundary, not used as internal representations.
4. **Detectors are the moat; primitives are the interface.** The detection library is a community-contributable asset. Each detector is a self-contained folder a contributor can add without touching the rest of the codebase. Primitives are the stable, MCP-exposed surface over which agents reason.
5. **Agent-first, pragmatically.** Every primitive is exposed via the MCP server. External agents (other Claude Code sessions, third-party tools) can discover and call every primitive. Our own agents prefer the MCP interface because it proves the architecture, but direct Python imports are acceptable when they materially improve performance or reliability.
6. **Drafts, not authorizations.** Efterlev never claims to produce an ATO, a pass, or a guarantee of compliance. It produces drafts that accelerate the human/3PAO process. This is not hedging; it's the truth, and it's the only claim that survives serious scrutiny.
7. **Honesty over polish.** If a detector can't prove a KSI, say so in the docstring's "does NOT prove" section. If a feature exists in docs but not in code, fix the docs, not the code (unless the code should exist). Overclaiming is the failure mode 3PAOs reject tools for.

---

## Tech stack

- **Language:** Python 3.12
- **Dependency management:** `uv`
- **Typing:** Pydantic v2 for all primitive I/O. No untyped dicts crossing a primitive boundary.
- **FRMR:** `FRMR.documentation.json` vendored from `FedRAMP/docs` into `catalogs/frmr/`. Single authoritative JSON file (`info`, `FRD`, `FRR`, `KSI`). On load, validated against `FedRAMP.schema.json` (JSON Schema draft 2020-12). On output, attestation artifacts use Pydantic structural validation (`extra="forbid"` + strict literals) — FedRAMP has not published an attestation-output schema, so the catalog schema doesn't apply to our output.
- **OSCAL (input only at v0.1.0):** `compliance-trestle` 4.x for loading the vendored NIST SP 800-53 Rev 5 catalog. OSCAL *output* generation is v1.5+.
- **MCP:** Official Anthropic Python SDK. Stdio transport.
- **LLM backends:** `LLMClient` protocol with `AnthropicClient` (direct API) and `AnthropicBedrockClient` (Converse API). Default model `claude-opus-4-7` for Gap and Remediation; `claude-sonnet-4-6` for Documentation. Centralize client instantiation in `src/efterlev/llm/__init__.py` — do not scatter `anthropic.Anthropic()` calls across agent files.
- **Storage:** SQLite for the provenance index. Content-addressed blob store on disk under `.efterlev/store/` (SHA-256 filenames). Append-only.
- **CLI:** Typer. Single entry point: `efterlev`.
- **IaC parsing:** `python-hcl2` for `.tf` files. `terraform show -json` plan output normalizes through `efterlev.terraform.parse_plan_json` into the same `TerraformResource` shape detectors consume.
- **Testing:** `pytest`. Every primitive and detector has ≥1 happy-path and ≥1 error-path test. No coverage targets — we optimize for confidence, not numbers.
- **Formatting:** `ruff` for lint + format (`PLW1514` opt-in via `preview = true` + `explicit-preview-rules = true` enforces explicit `encoding=` on every text-mode file open). `mypy --strict` on `src/efterlev/{primitives,detectors,oscal,manifests}.*`.
- **Docs:** MkDocs Material at `efterlev.com`.

---

## Repository layout

```
efterlev/
├── CLAUDE.md                          # this file
├── README.md                          # user-facing
├── CHANGELOG.md                       # release history (Keep a Changelog)
├── CONTRIBUTING.md, CODE_OF_CONDUCT.md, GOVERNANCE.md
├── DECISIONS.md                       # running log of non-trivial choices — APPEND-ONLY
├── LIMITATIONS.md                     # honest scope: what the tool does and doesn't do
├── THREAT_MODEL.md                    # security posture
├── SECURITY.md                        # coordinated disclosure
├── LICENSE                            # Apache 2.0
├── docs/
│   ├── architecture.md, faq.md, quickstart.md, deployment-modes.md
│   ├── ai-quickstart-prompt.md        # canonical AI-assistant-driven runbook
│   ├── aws-coexistence.md             # how Efterlev fits next to AWS Config / Security Hub
│   ├── csx-mapping.md                 # how Efterlev's outputs map to CSX-SUM/MAS/ORD
│   ├── ci-integration.md              # GitHub Action setup
│   ├── deploy-govcloud-ec2.md         # GovCloud EC2 + Bedrock walkthrough
│   ├── detector-mapping-audit.md      # KSI-mapping audit trail
│   ├── followups.md                   # v0.1.x and v0.2.0+ deferred work; Done section
│   ├── icp.md                         # Ideal Customer Profile
│   ├── manual-verification-runbook.md
│   ├── RELEASE.md                     # release process + verify-release.sh contract
│   ├── security-review-2026-04.md     # pre-launch security review (signed)
│   ├── v0.2-eval-harness-plan.md      # design sketch for v0.2 agent-quality harness
│   ├── concepts/, tutorials/, reference/   # public docs site
│   └── specs/                          # internal SPEC documents
├── src/efterlev/
│   ├── models/                        # Pydantic types (Indicator, Control, Evidence, Claim, ...)
│   ├── frmr/                          # FRMR loader + validator + generator
│   ├── oscal/                          # 800-53 catalog loader; OSCAL output generator (v1.5+)
│   ├── detectors/
│   │   ├── aws/<capability>/          # one folder per detector
│   │   └── github/<capability>/       # github-workflows detectors
│   ├── primitives/{scan,map,evidence,generate,validate}/
│   ├── manifests/                     # Evidence Manifest loader + types
│   ├── terraform/                     # HCL + plan-JSON parsing
│   ├── github_workflows/              # workflow YAML parsing
│   ├── llm/                           # LLMClient protocol + scrubber + retry/fallback
│   ├── mcp_server/
│   ├── agents/                        # gap.py + gap_prompt.md, etc.
│   ├── provenance/                    # store + walker
│   ├── reports/                       # HTML renderers
│   └── cli/
├── catalogs/{frmr,nist}/              # vendored reference data
├── demo/govnotes/                     # sample target app
├── scripts/                           # e2e_smoke.py, ci_pr_summary.py, verify-release.sh, ...
└── tests/
```

When adding new detectors, match the source/capability folder. When adding primitives, match the capability verb (`scan`, `map`, `evidence`, `generate`, `validate`). If it doesn't fit, propose a new subfolder before creating it.

---

## The detector contract

A detector is a self-contained artifact. One folder per detector. A contributor can add a new detector without reading the rest of the codebase. This is the #1 design commitment for long-term project health.

Each detector folder contains:

- **`detector.py`** — pure function, typed input/output. Reads source material (Terraform resources, GitHub workflow YAML), emits `Evidence` records.
- **`mapping.yaml`** — which KSI(s) this detector evidences, plus the underlying 800-53 control(s). Multi-target mappings are fine.
- **`evidence.yaml`** — template describing the shape and semantics of evidence this detector produces. Internal schema, not FRMR or OSCAL.
- **`fixtures/`** — `should_match/` and `should_not_match/` samples the test harness runs against.
- **`README.md`** — what this detector checks, what it proves, what it does NOT prove, known limitations. The "does NOT prove" section is required.

Detector IDs are capability-shaped (what the detector checks), not control-shaped. KSIs think in capabilities; IDs like `encryption_s3_at_rest` age better than `sc_28_s3_encryption` as the KSI ↔ control mapping evolves.

**Two mapping disciplines applied across the catalog:**

1. **`ksis=[]` is honest when no KSI maps the control.** SC-28 (encryption at rest) is the largest example: 5 of the 7 supplementary 800-53-only detectors carry `ksis=[]` because FRMR 0.9.43-beta does not list SC-28 in any KSI's `controls` array. Their evidence surfaces in the gap report's "Unmapped findings" section. Tracked as an upstream FRMR issue, not an Efterlev mapping mistake.
2. **Control membership in a KSI's `controls` array is necessary but not sufficient for claiming the KSI.** The detector must also evidence what the KSI's *statement* commits to. Example: IA-5 appears in KSI-IAM-MFA's controls, but `aws.iam_password_policy` does NOT claim KSI-IAM-MFA — password policy doesn't evidence phishing-resistant MFA.

See `docs/detector-mapping-audit.md` for the full per-detector audit.

---

## The primitive contract

Primitives are the MCP-exposed agent interface. Small and stable.

**Two classes of primitives, different contracts:**

**Deterministic primitives** — scan, map, validate, parse, hash, serialize. Pure where possible. Side-effecting primitives (write files, open PRs) are flagged.

```python
@primitive(capability="scan", side_effects=False, version="0.1.0", deterministic=True)
def scan_terraform(input: ScanTerraformInput) -> ScanTerraformOutput:
    """Run all applicable detectors against a Terraform source tree."""
```

**Generative primitives** — narrative synthesis, classification, remediation. LLM-backed. Output carries confidence levels and a `requires_review: Literal[True]` flag.

**Shared rules:**
- Verb-noun snake_case name
- One Pydantic input model, one Pydantic output model
- Docstring states intent, side effects, deterministic/generative, external dependencies
- Emits a provenance record via decorator machinery — you do not write provenance code inside the function body
- Auto-registered with the MCP server by the decorator
- No `print`; use the standard logger
- Raises typed exceptions from `efterlev.errors`, never bare `Exception`

---

## The agent contract

Every agent:

- Subclasses `efterlev.agents.base.Agent`
- Has its system prompt in a sibling `.md` file (`gap.py` → `gap_prompt.md`). **Prompts are product code — do not inline them as Python strings.**
- Consumes primitives via the MCP tool interface by default. Direct imports from `efterlev.primitives.*` are allowed when MCP round-tripping adds no value; flag the choice in the agent's docstring.
- Produces a typed output artifact on our internal model (e.g. `GapReport`, `AttestationDraft`, `RemediationProposal`). FRMR and OSCAL serialization are separate generator steps, not the agent's job.
- Logs every tool call, model response, and final artifact to the provenance store
- Is invokable standalone from the CLI: `efterlev agent <name> [options]`

**When you write or revise an agent's system prompt, surface the full diff in chat for review before committing.** Agent prompts are the product's brain; they deserve human sign-off even when code doesn't.

**Hallucination defenses are structural, not advisory:**
- Every agent prompt wraps evidence in `<evidence_NONCE id="sha256:...">...</evidence_NONCE>` XML fences, with a per-run nonce (`secrets.token_hex(4)`) that prevents content-injected forged fences.
- A post-generation validator rejects any output that cites evidence IDs not present as fences in the prompt the model actually saw.
- `ProvenanceStore.write_record` validates every Claim's `derived_from` at write time — unresolvable IDs raise `ProvenanceError` before insertion.
- Every Claim carries `requires_review: Literal[True]` at the type level — not a string, not a flag.

**Secret redaction is unconditional:** every LLM prompt is scrubbed for 7 secret families (AWS, GCP, GitHub, Slack, Stripe, PEM, JWT) before egress. The scrubber lives in `src/efterlev/llm/scrubber.py`; it's called by `format_evidence_for_prompt` and `format_source_files_for_prompt` in `agents/base.py` with no opt-out path. Each redaction writes to `.efterlev/redactions/<scan_id>.jsonl` (mode `0o600`); `efterlev redaction review` renders the log.

**LLM calls degrade predictably:** transient Anthropic errors retry with exponential backoff + full jitter (3 attempts on primary). Primary-model exhaustion falls back once to a configured secondary (Opus 4.7 → Sonnet 4.6 by default) before surfacing.

---

## Evidence vs. claims: the data model

Two distinct types, treated differently throughout the system. See `src/efterlev/models/evidence.py` and `claim.py` for the canonical definitions.

- **`Evidence`** — deterministic, scanner-derived, content-addressed by SHA-256. Fields: `evidence_id`, `detector_id`, `ksis_evidenced`, `controls_evidenced`, `source_ref` (file + line + commit), `content`, `timestamp`.
- **`Claim`** — LLM-reasoned, content-addressed. Fields: `claim_id`, `claim_type` (narrative / classification / remediation / mapping), `content`, `confidence`, `requires_review: Literal[True]`, `derived_from`, `model`, `prompt_hash`, `timestamp`.

Every rendered output — HTML report, FRMR artifact, terminal summary — visually distinguishes Evidence (green left border) from Claims (amber, with the DRAFT banner). Manifest-sourced citations carry an additional "attestation" pill to distinguish human-signed from scanner-derived evidence.

---

## Provenance model

Every claim is a node in a directed graph. Edges point from derived claims to upstream sources.

```python
class ProvenanceRecord(BaseModel):
    record_id: str                      # sha256 of canonical content
    record_type: Literal["evidence", "claim", "finding", "mapping", "remediation"]
    content_ref: str                    # path in blob store
    derived_from: list[str]             # upstream record_ids (evidence or claim)
    primitive: str | None               # "scan_terraform@0.1.0"
    agent: str | None                   # "gap_agent" if agent-mediated
    model: str | None                   # "claude-opus-4-7" if LLM-involved
    prompt_hash: str | None             # hash of system prompt if LLM-involved
    timestamp: datetime
    metadata: dict
```

Rules:
- A record with `derived_from=[]` is raw evidence or a primitive input. Any reasoning step must carry its inputs forward.
- Records are immutable and append-only. New evidence for a KSI creates a new record; it does not overwrite the old one.
- `efterlev provenance show <record_id>` walks the chain to source-file line ranges.

When you implement a primitive or agent that generates records, **write the provenance walk test first**. If the chain doesn't resolve end-to-end, the feature isn't done.

---

## Quality bar

- **Every detector:** typed I/O, docstring with "proves / does NOT prove," fixtures for should-match and should-not-match, passing tests, plan-JSON equivalence test.
- **Every primitive:** typed I/O, docstring, ≥1 happy test, ≥1 error test, FRMR validation on output where applicable, provenance record emitted.
- **Every agent:** system prompt in its own file, provenance-emitting, CLI-invokable, end-to-end test against the demo repo.
- **Every commit:** `ruff check` clean (incl. `PLW1514` unspecified-encoding), `ruff format --check` clean, `mypy --strict` clean on core paths, tests passing.
- **Every non-trivial decision:** appended to `DECISIONS.md` with date, decision, rationale, alternatives considered.

## Per-fix regression test discipline (v0.1.10+)

**Every bug-fix patch ships with a test that would have caught the bug.** No exceptions for "obviously correct" fixes — those are the patches that historically introduced new bugs (the v0.1.7 doc dual-emit was an "obviously correct" v0.1.4 deterministic-template path). Pick the right test layer for the bug class:

| Bug class | Test layer | Examples from v0.1.5–0.1.9 |
|---|---|---|
| Single function / pure logic | unit (`tests/test_*.py` near the function) | prefix-resolve scope, KSI dedup logic, manifest-in-boundary special case |
| Cross-component (model→store→render) | integration in `tests/test_<feature>_*.py` | doc dual-emit dedup, boundary state propagation |
| Real environment / install / CLI | E2E smoke (`scripts/e2e_smoke.py`) | uv-vs-pipx hint, max_tokens default, terraform-init backend block |
| Doc drift | check-docs CI job | README test count, KSI naming in DELIBERATE_GAPS |
| Detector registry | detector fixture under `src/efterlev/detectors/<name>/fixtures/` | sbom-action recognition, govulncheck CVE scanner |

The test should fail without the fix and pass with it — verify both directions during the patch cycle. The PR body should reference the regression test by name.

### A/B verification for hard-to-reproduce fixes (v0.1.24+)

For platform-specific fixes (Windows, docker-ghcr, AWS Bedrock, anything where the failure mode is gated on environment), the regression test must be **A/B-verified before commit**: revert the fix, run the test, confirm it FAILS with the same error message that prod produced. Then restore the fix.

This isn't paranoia — it's the lesson from the v0.1.23 → v0.1.24 cycle. v0.1.23 shipped with a test (`test_assert_passes_against_readonly_db`) that PASSED locally because the fixture (chmod-on-file, non-WAL) didn't match the prod failure mode (chmod-on-directory + WAL). The fix didn't actually work in prod, but the test couldn't tell. v0.1.24 strengthened the test to reproduce prod exactly (chmod on directory + WAL fixture) and A/B-verified it before commit. The cost was ~10 minutes; the benefit was avoiding one more round of "ship → fail in matrix → debug → repatch."

A/B-verification is especially valuable for:
- **Platform-gated bugs** (POSIX-only / Windows-only / docker-only) where the dev laptop can't reproduce by default. Source-level pin tests (read the source, assert the fix shape is present) plus an A/B-verified behavioral fixture is the v0.1.23–v0.1.27 pattern.
- **Filesystem-state bugs** (read-only files, root-owned dirs, exotic permissions) where the failure mode is `[Errno N]` and the test fixture must match exactly.
- **Encoding bugs** where the dev-laptop default (utf-8 on macOS / Linux) differs from CI (cp1252 on Windows). Without A/B verification, the test passes on POSIX even if the fix doesn't actually work.

The `tests/test_smoke_assert.py::test_assert_passes_against_wal_mode_readonly_dir` and `tests/test_receipts_locking.py::test_windows_lock_helpers_lseek_to_byte_zero_before_lock_and_unlock` tests are reference examples — both A/B-verified, both catch their specific prod failure mode on every platform.

### Encoding hygiene as a lint-time gate (v0.1.27+)

`PLW1514` ("unspecified-encoding") is enabled in `pyproject.toml`'s ruff config. It catches `Path.open()`, `read_text()`, `write_text()`, and `tempfile.NamedTemporaryFile(mode="w")` calls without an explicit `encoding=`. Enforced at lint time on every PR — don't rely on the OS-default encoding even on POSIX (where it happens to be utf-8 today). Pass `encoding="utf-8"` explicitly or, for binary blobs, use binary mode (`"rb"` / `"wb"` / `read_bytes()` / `write_bytes()`).

**Why this matters:** v0.1.25 + v0.1.27 in the cascade were both Windows-only encoding bugs that would have been caught by PLW1514 at PR review instead of after-tag matrix run. The enforcement closes that category of bug at lint time.

**Why this matters (the original case):** v0.1.5–0.1.9 each surfaced 3 new bugs in manual shakedowns. ~75% would have been caught by tests we could have written before shipping. The E2E smoke CI gate (v0.1.10) closes the cross-component gap automatically; this discipline closes the unit/integration gap.

### Testing tiers — pick by cost (post-v0.1.42)

Three opt-in tiers above the always-on unit suite. Pick by what the bug class needs and by what's worth burning at this point in the cycle:

| Tier | Marker | Cost | Wall | When to run |
|---|---|---|---|---|
| Unit | (default) | $0 | ~20s | Every save. Default `pytest -m "not e2e"` cycle. |
| Deep-smoke | `pytest -m deep` (`scripts/deep-test.sh`) | $0 | ~25s | Before tagging. Catches user-flow regressions that span CLI primitives — friendly-error paths, init/scan/manifest sequences, broken-HCL handling, etc. Replaces the deterministic-tier portion of the old human deep-test prompt. |
| Eval harness | `python -m evals run --fixture <path>` (`evals/`) | ~$0.04/fixture/run on Haiku-Bedrock; ~$0.12 corpus pass | ~3-5min/fixture | Before merging prompt-touching PRs. Catches the agent-quality regressions deep-smoke can't (status-classification drift, narrative quality, POAM scope discipline). 5 metrics, 3 synthetic fixtures, delta-vs-prior reporter. v0.2 Phase 1 (DECISIONS 2026-05-08); see `evals/README.md` for the operator walkthrough. |
| E2E smoke | `pytest -m e2e` | ~$0.30/run | ~7min | Required CI check on every PR (real Anthropic API call against synthetic fixture). Locks the Anthropic-backend pipeline shape. |
| Bedrock E2E | `pytest -m e2e tests/test_e2e_smoke_bedrock.py` | ~$0.30/run | ~7min | Manual; opt-in for Bedrock-specific shake-downs. |

**Why deep-smoke exists:** before v0.1.42 the way to catch user-flow bugs was to hand a fresh Claude Code session a 150-line markdown deep-test prompt and have it walk through install + init + quickstart + agent + manifests + edge cases. That session cost ~$3 and ~30 min. About 80% of the prompt was deterministic shell sequences — running them through an LLM tester was the wrong abstraction. `tests/test_deep_smoke.py` captures the deterministic 80% as 14 pytest-driven scenarios that run in ~25s with $0 cost. The remaining 20% (judgment-requiring agent-output assessments) is the eval-harness tier above.

**Why the eval harness exists:** unit tests + deep-smoke + E2E together still don't catch agent-quality regressions — the verdict-vs-ground-truth and rationale-vs-reviewability dimensions. v0.1.5–0.1.9's KSI-SVC-PRR drift, KSI-SCR-MIT "mixed" reasoning bug, and F5 manifest cross-wiring were all this class. The eval harness measures both dimensions on every prompt-touching PR via 5 metrics (M1 status precision, M2 status recall, M3 resource-naming, M4 manifest-quoting, M5 POAM scope) against ground-truth-labeled fixtures. Yellow-flag (PR comment) on > 5% regression at Phase 1; hard-blocking is Phase 3 work after noise-floor calibration. See DECISIONS 2026-05-08 "v0.2 agent-quality eval harness" for the design.

**The discipline:** when a finding from a real shakedown surfaces a bug that a unit test wouldn't have caught (because it spans CLI primitives, or the bug is in the friendly-error wrapper, or it's about subprocess behavior), the regression test goes into `test_deep_smoke.py`, not into a new unit test. Deep-smoke scenarios accumulate one user-flow lock per finding. v0.1.37 (Bedrock silent-wedge), v0.1.38 (friendly handler chain-walk + --version shadow), and v0.1.42 (init manifests-only + lifecycle-aware probe) all have unit tests AND deep-smoke scenarios — the unit tests pin the function-level behavior, the deep-smoke scenarios pin the user-flow shape.

---

## How we work together

- **Surface architectural questions immediately.** If you see a fork in the road, stop and ask. Do not silently pick and refactor later.
- **Prefer small PRs.** If a change touches more than three files outside of pure additions, flag it.
- **GitHub Actions minutes are constrained** (~90% of monthly cap as of 2026-04-28). Batch related changes into one PR; run gates locally before pushing; avoid fixup-push churn.
- **Maintain `DECISIONS.md`.** Every non-obvious choice belongs there. Append-only — historical entries stay even when the decision is later reversed; add the reversal as a new dated entry.
- **Prompts are product.** Surface system-prompt diffs in chat before committing.
- **Use the repo-scoped slash commands when they fit.** `.claude/commands/` ships six commands that compress recurring multi-file workflows. Each is a recipe template — every step is still a real human decision, but the agent doesn't have to re-derive the ritual. See `.claude/commands/README.md` for the full table; the canonical chains are:
  - **Cut a release (no detector):** `/release-housekeeping <version>` → review the PR diff → `/release-finalize <pr-number>`. The split lets you inspect the bump+drift-sweep+CHANGELOG diff before kicking off the merge+tag+verify cycle. Together they encode the v0.1.37/38/39 ritual we ran three times on 2026-05-07/08.
  - **Cut a release (new detector):** `/ship-detector <slug> <KSI-ID>` does the full release including detector folder scaffold + EXPECTED_DETECTORS bump. Don't chain this with `/release-housekeeping`; ship-detector covers the same ground.
  - **Validate a shipped release in the wild:** `/validation-prompt <version>` reads the CHANGELOG block, maps each Fixed/Added entry to a PASS/FAIL scenario, emits paste-ready markdown for the tester. Mandatory S0 baseline check catches install-shadow confusion (the v0.1.38 footgun).
  - **Surface a design decision before implementing:** `/decisions-entry <title>` drafts the DECISIONS.md entry as its own PR, per the working agreement (design lands BEFORE implementation).
  - **Snapshot the repo state at session start:** `/check-state` is the orientation read.

---

## Never do

- Never commit real secrets, API keys, or production data. The demo repo is synthetic.
- Never return FRMR (or, in v1.5+, OSCAL) output that hasn't passed Pydantic structural validation.
- Never generate a Claim without citing the Evidence records it derives from.
- Never claim the tool produces an ATO, a pass, or a guarantee of compliance. Drafts and findings only.
- Never add a dependency without a line in `DECISIONS.md` explaining why.
- Never mix Evidence and Claims in a way that loses their distinction — in the data model, in the UI, or in FRMR/OSCAL output.
- Never claim a detector proves more than it actually does. The "does NOT prove" section of the detector README is as important as the "does prove" section.
- Never invent a KSI ID that does not appear in the vendored FRMR. If coverage is genuinely missing, surface the gap and file an upstream issue; do not paper over it.
- Never bypass the secret scrubber or the fence-citation validator. Both are unconditional by design.

---

## References

- `CHANGELOG.md` — release-by-release record
- `DECISIONS.md` — append-only architectural decision log
- `LIMITATIONS.md` — honest scope of what the tool does and doesn't do
- `THREAT_MODEL.md` — security posture for the tool itself
- `docs/architecture.md` — deeper architectural detail
- `docs/icp.md` — the Ideal Customer Profile; lens for every product decision
- `docs/followups.md` — v0.1.x and v0.2.0+ deferred work

When any of those conflict with this file on a current-state question, this file wins and we update the others. Where this file conflicts with the actual code, the code wins and we update this file.
