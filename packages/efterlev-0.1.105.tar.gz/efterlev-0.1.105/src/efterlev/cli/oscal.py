"""`efterlev oscal` subcommand — emit OSCAL 1.0.4 artifacts.

OSCAL output arc step 1 (v0.1.105): POA&M emit only. Future kinds
(component-definition v0.1.107, partial-SSP v0.1.108+) ship behind
the same `--kind` flag.

Why a dedicated subcommand (not a flag on `report run`):

  - OSCAL has multiple output kinds (POA&M, component-definition,
    partial-SSP). Each is a distinct schema with its own input
    requirements. Subcommand namespace lets us add `oscal validate`,
    `oscal export --kind component-definition`, etc. without
    overloading the top-level CLI.
  - `efterlev report run` users who don't care about OSCAL shouldn't
    pay the OSCAL emit cost (deterministic but still work).
  - Trestle (IBM) and RegScale CLI both use the subcommand pattern;
    this keeps the OSCAL-tool surface familiar to compliance users.

OSCAL version: 1.0.4 (FedRAMP-current). When FedRAMP publishes
1.1.0 guidance, add a `--oscal-version` flag.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path

import typer

oscal_app = typer.Typer(
    name="oscal",
    help="Emit OSCAL 1.0.4 artifacts (POA&M today; component-definition + SSP planned).",
    no_args_is_help=True,
)


@oscal_app.command("export")
def oscal_export(
    kind: str = typer.Option(
        ...,
        "--kind",
        help=(
            "OSCAL artifact to emit. v0.1.105 supports `poam` (Plan of Action "
            "and Milestones). `component-definition` and `partial-ssp` planned "
            "for later releases."
        ),
    ),
    target: Path = typer.Option(
        Path("."),
        "--target",
        help="Path to the workspace whose `.efterlev/` store will be read.",
    ),
    output: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help=(
            "Write the OSCAL JSON to this file. Defaults to "
            "`.efterlev/reports/oscal/<kind>-<timestamp>.json`."
        ),
    ),
    system_name: str = typer.Option(
        "Unnamed System (efterlev placeholder)",
        "--system-name",
        help=(
            "Human-readable system name for the OSCAL `metadata.title`. "
            "Override before submitting to a 3PAO; the default is a "
            "placeholder that flags the gap."
        ),
    ),
    system_id: str = typer.Option(
        "efterlev-system-default",
        "--system-id",
        help=(
            "OSCAL `system-id` value. Override with the system's authoritative "
            "identifier (FedRAMP-issued ID for FedRAMP submissions, internal "
            "system inventory ID otherwise)."
        ),
    ),
) -> None:
    """Emit an OSCAL artifact (currently `poam` only).

    Reads the latest Gap Agent classifications from the workspace's
    provenance store, resolves each KSI against the loaded FRMR catalog,
    and writes an OSCAL 1.0.4 JSON document.

    Deterministic: same Gap Agent classifications + same FRMR + same
    `last-modified` timestamp produce byte-identical OSCAL JSON. UUIDs
    are derived via `uuid5` from a fixed namespace + the underlying
    KSI/control identifiers, so re-runs of the same scan produce
    stable diffs (important for tracking deltas across release cycles).
    """
    if kind != "poam":
        typer.echo(
            f"error: --kind={kind!r} is not yet supported. v0.1.105 supports "
            "`poam` only. `component-definition` and `partial-ssp` are tracked "
            "for later releases (see CHANGELOG).",
            err=True,
        )
        raise typer.Exit(code=2)

    # Lazy imports keep the CLI startup fast for unrelated subcommands.
    from efterlev.agents import (
        count_duplicate_classification_runs,
        reconstruct_classifications_from_store,
    )
    from efterlev.frmr.loader import FrmrDocument
    from efterlev.primitives.generate import (
        GeneratePoamOscalInput,
        PoamClassificationInput,
        generate_poam_oscal,
    )
    from efterlev.provenance import ProvenanceStore, active_store

    root = target.resolve()
    if not (root / ".efterlev").is_dir():
        typer.echo(
            f"error: no `.efterlev/` directory under {root}. Run `efterlev init` first.",
            err=True,
        )
        raise typer.Exit(code=1)

    frmr_cache = root / ".efterlev" / "cache" / "frmr_document.json"
    if not frmr_cache.is_file():
        typer.echo(
            f"error: FRMR cache missing at {frmr_cache}. Re-run `efterlev init`.",
            err=True,
        )
        raise typer.Exit(code=1)

    frmr_doc = FrmrDocument.model_validate_json(frmr_cache.read_text(encoding="utf-8"))

    with ProvenanceStore(root) as store, active_store(store):
        rows = store.iter_claims_by_metadata_kind("ksi_classification")
        duplicate_count = count_duplicate_classification_runs(rows)
        classifications = reconstruct_classifications_from_store(rows)
        if duplicate_count > 0:
            typer.echo(
                f"note: deduped {duplicate_count} duplicate classification(s) "
                f"from prior `agent gap` runs (latest-wins).",
                err=True,
            )
        if not classifications:
            typer.echo(
                "error: 0 Gap Agent classifications in the store. The Gap Agent "
                "either hasn't run yet, or ran with no evidence to classify "
                "(check `efterlev scan` first if you skipped that stage).",
                err=True,
            )
            raise typer.Exit(code=1)

        poam_inputs = [
            PoamClassificationInput(
                ksi_id=c.ksi_id,
                status=c.status,
                rationale=c.rationale,
                evidence_ids=list(c.evidence_ids),
                claim_record_id=None,
            )
            for c in classifications
        ]

        result = generate_poam_oscal(
            GeneratePoamOscalInput(
                classifications=poam_inputs,
                indicators=frmr_doc.indicators,
                baseline_id="fedramp-20x-moderate",
                frmr_version=frmr_doc.version,
                system_name=system_name,
                system_id=system_id,
                last_modified=datetime.now(UTC),
            )
        )

    timestamp = datetime.now().astimezone().strftime("%Y%m%d-%H%M%S")
    output_path = output or (root / ".efterlev" / "reports" / "oscal" / f"poam-{timestamp}.json")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(result.oscal_document, indent=2, sort_keys=False) + "\n",
        encoding="utf-8",
    )

    typer.echo(f"OSCAL POA&M: {output_path.resolve()}")
    typer.echo("  oscal-version:    1.0.4")
    typer.echo(f"  poam-items:       {result.item_count}")
    if result.skipped_unknown_ksi:
        typer.echo(
            f"  skipped (unknown KSI in indicator dict): "
            f"{', '.join(sorted(result.skipped_unknown_ksi))}",
            err=True,
        )
    typer.echo(
        "  reviewer:         override --system-name and --system-id with the "
        "authoritative values before submitting to a 3PAO",
        err=True,
    )
