from __future__ import annotations

import pytest

from showholdings_agentmon import Monitor
from showholdings_agentmon.exceptions import AgentMonUsageError


def test_monitor_init() -> None:
    monitor = Monitor(
        api_key="test-key",
        base_url="https://agentops.showholdings.com",
        project_name="my-agent",
    )
    assert monitor.project_name == "my-agent"


def test_run_context_success(monkeypatch: pytest.MonkeyPatch) -> None:
    monitor = Monitor(
        api_key="test-key",
        base_url="https://agentops.showholdings.com",
        project_name="my-agent",
    )

    calls: list[tuple[str, dict]] = []

    def fake_safe_post(path: str, payload: dict):
        calls.append((path, payload.copy()))
        if path == "/api/sdk/runs/start":
            return {"run_id": 123}
        return {"ok": True}

    monkeypatch.setattr(monitor, "_safe_post", fake_safe_post)

    with monitor.run(agent_name="general-agent", session_id="session-123"):
        pass

    assert len(calls) == 2
    assert calls[0][0] == "/api/sdk/runs/start"
    assert calls[1][0] == "/api/sdk/runs/end"
    assert calls[1][1]["status"] == "success"
    assert calls[1][1]["run_id"] == 123
    assert isinstance(calls[1][1]["duration_ms"], int)


def test_run_context_failure_reraises(monkeypatch: pytest.MonkeyPatch) -> None:
    monitor = Monitor(
        api_key="test-key",
        base_url="https://agentops.showholdings.com",
        project_name="my-agent",
    )

    calls: list[tuple[str, dict]] = []

    def fake_safe_post(path: str, payload: dict):
        calls.append((path, payload.copy()))
        return {"ok": True}

    monkeypatch.setattr(monitor, "_safe_post", fake_safe_post)

    with pytest.raises(RuntimeError):
        with monitor.run(agent_name="general-agent"):
            raise RuntimeError("boom")

    assert len(calls) == 2
    assert calls[1][0] == "/api/sdk/runs/end"
    assert calls[1][1]["status"] == "failed"
    assert calls[1][1]["failure_reason_type"] == "RuntimeError"
    assert calls[1][1]["error_count"] == 1


def test_best_effort_does_not_break_user_flow(monkeypatch: pytest.MonkeyPatch) -> None:
    monitor = Monitor(
        api_key="test-key",
        base_url="https://agentops.showholdings.com",
        project_name="my-agent",
    )

    def always_fail(_path: str, _payload: dict):
        raise RuntimeError("network down")

    monkeypatch.setattr(monitor._client, "post", always_fail)

    with monitor.run(agent_name="general-agent"):
        value = 1 + 1

    assert value == 2


def test_step_context_success(monkeypatch: pytest.MonkeyPatch) -> None:
    monitor = Monitor(
        api_key="test-key",
        base_url="https://agentops.showholdings.com",
        project_name="my-agent",
    )

    calls: list[tuple[str, dict]] = []

    def fake_safe_post(path: str, payload: dict):
        calls.append((path, payload.copy()))
        if path == "/api/sdk/runs/start":
            return {"run_id": 101}
        if path == "/api/sdk/steps/start":
            return {"step_id": 301}
        return {"ok": True}

    monkeypatch.setattr(monitor, "_safe_post", fake_safe_post)

    with monitor.run(agent_name="general-agent", session_id="session-123"):
        with monitor.step("準備資料", step_type="資料處理"):
            pass

    assert [path for path, _ in calls] == [
        "/api/sdk/runs/start",
        "/api/sdk/steps/start",
        "/api/sdk/steps/end",
        "/api/sdk/runs/end",
    ]
    step_start_payload = calls[1][1]
    assert step_start_payload["run_id"] == 101
    assert step_start_payload["seq_no"] == 1
    assert step_start_payload["step_name"] == "準備資料"
    assert step_start_payload["step_type"] == "資料處理"

    step_end_payload = calls[2][1]
    assert step_end_payload["run_id"] == 101
    assert step_end_payload["step_id"] == 301
    assert step_end_payload["status"] == "success"
    assert isinstance(step_end_payload["duration_ms"], int)


def test_step_outside_run_raises_usage_error() -> None:
    monitor = Monitor(
        api_key="test-key",
        base_url="https://agentops.showholdings.com",
        project_name="my-agent",
    )

    with pytest.raises(AgentMonUsageError):
        with monitor.step("準備資料"):
            pass


def test_step_failure_reraises_and_reports_failed(monkeypatch: pytest.MonkeyPatch) -> None:
    monitor = Monitor(
        api_key="test-key",
        base_url="https://agentops.showholdings.com",
        project_name="my-agent",
    )

    calls: list[tuple[str, dict]] = []

    def fake_safe_post(path: str, payload: dict):
        calls.append((path, payload.copy()))
        if path == "/api/sdk/runs/start":
            return {"run_id": 7}
        if path == "/api/sdk/steps/start":
            return {"step_id": 88}
        return {"ok": True}

    monkeypatch.setattr(monitor, "_safe_post", fake_safe_post)

    with pytest.raises(ValueError, match="bad-step"):
        with monitor.run(agent_name="general-agent"):
            with monitor.step("產生結果", step_type="模型呼叫"):
                raise ValueError("bad-step")

    step_end_payload = next(payload for path, payload in calls if path == "/api/sdk/steps/end")
    assert step_end_payload["status"] == "failed"
    assert step_end_payload["error_message"] == "bad-step"


def test_step_sequence_resets_for_new_run(monkeypatch: pytest.MonkeyPatch) -> None:
    monitor = Monitor(
        api_key="test-key",
        base_url="https://agentops.showholdings.com",
        project_name="my-agent",
    )

    step_start_payloads: list[dict] = []
    run_counter = {"value": 0}

    def fake_safe_post(path: str, payload: dict):
        if path == "/api/sdk/runs/start":
            run_counter["value"] += 1
            return {"run_id": run_counter["value"]}
        if path == "/api/sdk/steps/start":
            step_start_payloads.append(payload.copy())
            return {"step_id": len(step_start_payloads)}
        return {"ok": True}

    monkeypatch.setattr(monitor, "_safe_post", fake_safe_post)

    with monitor.run(agent_name="general-agent"):
        with monitor.step("step-1"):
            pass
        with monitor.step("step-2"):
            pass

    with monitor.run(agent_name="general-agent"):
        with monitor.step("step-3"):
            pass

    assert [payload["seq_no"] for payload in step_start_payloads] == [1, 2, 1]
