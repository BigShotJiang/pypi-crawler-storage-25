"""Noise and error modeling."""
