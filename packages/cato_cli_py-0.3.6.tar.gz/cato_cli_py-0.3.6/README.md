# cato-cli

Universal AI agent safety layer. Protect your files and commands from AI coding agents with configurable rules.

## Install

```bash
pip install cato-cli
```

## Quick start

```bash
cato init              # create .cato.toml in your project
cato adapt claude-code # set up Claude Code hooks
cato check .env        # test: denied
```

## Documentation

See [github.com/Harikrishnareddyl/cato](https://github.com/Harikrishnareddyl/cato)
