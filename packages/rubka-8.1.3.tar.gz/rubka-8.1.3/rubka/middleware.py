from typing import Callable, Any, Dict, List, Optional
from enum import IntEnum
import asyncio

class MiddlewarePriority(IntEnum):
    HIGHEST = 0
    HIGH = 1
    NORMAL = 2
    LOW = 3
    LOWEST = 4

class Middleware:
    def __init__(
        self, 
        func: Callable, 
        priority: MiddlewarePriority = MiddlewarePriority.NORMAL,
        name: Optional[str] = None
    ):
        self.func = func
        self.priority = priority
        self.name = name or func.__name__
        
    def __lt__(self, other):
        return self.priority < other.priority

class MiddlewareManager:
    def __init__(self):
        self._middlewares: List[Middleware] = []
        self._before_middlewares: List[Middleware] = []
        self._after_middlewares: List[Middleware] = []
        self._error_middlewares: List[Middleware] = []
        
    def add_middleware(
        self, 
        func: Callable, 
        priority: MiddlewarePriority = MiddlewarePriority.NORMAL,
        name: Optional[str] = None
    ):
        middleware = Middleware(func, priority, name)
        self._middlewares.append(middleware)
        self._middlewares.sort()
        
    def add_before_middleware(
        self, 
        func: Callable, 
        priority: MiddlewarePriority = MiddlewarePriority.NORMAL
    ):
        middleware = Middleware(func, priority)
        self._before_middlewares.append(middleware)
        self._before_middlewares.sort()
        
    def add_after_middleware(
        self, 
        func: Callable, 
        priority: MiddlewarePriority = MiddlewarePriority.NORMAL
    ):
        middleware = Middleware(func, priority)
        self._after_middlewares.append(middleware)
        self._after_middlewares.sort()
        
    def add_error_middleware(
        self, 
        func: Callable, 
        priority: MiddlewarePriority = MiddlewarePriority.NORMAL
    ):
        middleware = Middleware(func, priority)
        self._error_middlewares.append(middleware)
        self._error_middlewares.sort()
    async def run_middlewares(
        self, 
        bot, 
        message, 
        handler: Callable,
        context: Optional[Dict] = None
    ):
        context = context or {}
        for middleware in self._before_middlewares:
            try:
                result = await middleware.func(bot, message, context)
                if result is False:
                    return None
            except Exception as e:
                await self._handle_error(bot, message, e, context)
                return None
        async def run_middleware_chain(index=0):
            if index >= len(self._middlewares):
                return await handler(bot, message)
            
            mw = self._middlewares[index]
            
            async def next_mw(b, m):
                return await run_middleware_chain(index + 1)
            
            return await mw.func(bot, message, next_mw, context)
        try:
            result = await run_middleware_chain(0)
        except Exception as e:
            await self._handle_error(bot, message, e, context)
            raise 
        for middleware in self._after_middlewares:
            try:
                result = await middleware.func(bot, message, result, context)
            except Exception as e:
                await self._handle_error(bot, message, e, context)
        
        return result
        
    async def _handle_error(self, bot, message, error, context):
        for middleware in self._error_middlewares:
            try:
                result = await middleware.func(bot, message, error, context)
                if result:
                    return result
            except Exception:
                continue
        raise error