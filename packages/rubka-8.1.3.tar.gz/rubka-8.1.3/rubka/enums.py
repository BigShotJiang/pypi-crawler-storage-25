from enum import Enum


class BaseEnum(str, Enum):
    def __str__(self):
        return self.value


class ChatTypeEnum(BaseEnum):
    User = "User"
    Bot = "Bot"
    Group = "Group"
    Channel = "Channel"

class FileTypeEnum(BaseEnum):
    File = "File"
    Image = "Image"
    Voice = "Voice"
    Video = "Video"
    Music = "Music"
    Gif = "Gif"


class ForwardedFromEnum(BaseEnum):
    User = "User"
    Channel = "Channel"
    Bot = "Bot"


class PollStatusEnum(BaseEnum):
    Open = "Open"
    Closed = "Closed"


class ButtonSelectionTypeEnum(BaseEnum):
    TextOnly = "TextOnly"
    TextImgThu = "TextImgThu"
    TextImgBig = "TextImgBig"


class ButtonSelectionSearchEnum(BaseEnum):
    None_ = "None"
    Local = "Local"
    Api = "Api"


class ButtonSelectionGetEnum(BaseEnum):
    Local = "Local"
    Api = "Api"


class ButtonCalendarTypeEnum(BaseEnum):
    DatePersian = "DatePersian"
    DateGregorian = "DateGregorian"


class ButtonTextboxTypeKeypadEnum(BaseEnum):
    String = "String"
    Number = "Number"


class ButtonTextboxTypeLineEnum(BaseEnum):
    SingleLine = "SingleLine"
    MultiLine = "MultiLine"


class ButtonLocationTypeEnum(BaseEnum):
    Picker = "Picker"
    View = "View"


class MessageSenderEnum(BaseEnum):
    User = "User"
    Bot = "Bot"


class UpdateTypeEnum(BaseEnum):
    UpdatedMessage = "UpdatedMessage"
    NewMessage = "NewMessage"
    RemovedMessage = "RemovedMessage"
    StartedBot = "StartedBot"
    StoppedBot = "StoppedBot"


class ChatKeypadTypeEnum(BaseEnum):
    None_ = "None"
    New = "New"
    Remove = "Remove"

class outher(BaseEnum):
    Null = None

class UpdateEndpointTypeEnum(BaseEnum):
    ReceiveUpdate = "ReceiveUpdate"
    ReceiveInlineMessage = "ReceiveInlineMessage"
    ReceiveQuery = "ReceiveQuery"
    GetSelectionItem = "GetSelectionItem"
    SearchSelectionItems = "SearchSelectionItems"


class MetadataTypeEnum(BaseEnum):
    Bold = "Bold"
    Italic = "Italic"
    Mono = "Mono"
    Underline = "Underline"
    Strike = "Strike"
    Spoiler = "Spoiler"
    Link = "Link"
    MentionText = "MentionText"
    Pre = "Pre"
    Quote = "Quote"
