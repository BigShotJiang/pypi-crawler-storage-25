from setuptools import setup, find_packages

try:
    with open('README.md', encoding='utf-8') as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = ''

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name='Rubka',
    version='8.1.3',
    description=(
    "rubka: The official Python SDK for the Rubika Bot API, provided by Rubika. "
    "This library offers a robust and feature-rich interface for developers to build "
    "advanced bots on the Rubika platform. Features include comprehensive support for "
    "messaging, media, inline keyboards, group/channel management, user authentication, "
    "subscription systems, and real-time event handling. Built for scalability and ease of use."
),

    long_description=long_description,
    long_description_content_type='text/markdown',
    author='Mahdi Ahmadi',
    author_email='mahdiahmadi.1208@gmail.com',
    maintainer='Mahdi Ahmadi',
    maintainer_email='mahdiahmadi.1208@gmail.com',
    url='https://github.com/Mahdy-Ahmadi/Rubka',
    download_url='https://github.com/Mahdy-Ahmadi/rubka/',
    packages=find_packages(),
    include_package_data=True,
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Topic :: Communications :: Chat',
        'Topic :: Software Development :: Libraries',
        'Natural Language :: Persian',
    ],
    python_requires='>=3.6',
    install_requires=[
        "requests",
        "websocket-client",
        'pycryptodome',
        'aiohttp',
        'httpx',
        'tqdm',
        'mutagen',
        'markdownify',
        'filetype',
        'aiofiles',
        'deep-translator'
    ],
    entry_points={
        "console_scripts": [
            "rubka=rubka.__main__:main",
        ],
        "rubka.plugins": [],
    },
    keywords="rubika bot api library chat messaging rubpy pyrubi rubigram rubika_bot rubika_api fast_rub",
    project_urls={
        "Bug Tracker": "https://t.me/Dev_servers",
        "Documentation": "https://github.com/Mahdy-Ahmadi/rubka/blob/main/README.md",
        "Source Code": "https://github.com/Mahdy-Ahmadi/Rubka",
        "Web Site":"http://rubka.ir",
        "Discord/Telegram": "https://rubika.ir/rubka_info"
    },
    license="MIT",
    zip_safe=False
)