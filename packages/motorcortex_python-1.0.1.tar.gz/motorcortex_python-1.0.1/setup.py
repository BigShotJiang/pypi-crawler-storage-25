#!/usr/bin/python3

#
#   Developer: Alexey Zakharov (alexey.zakharov@vectioneer.com)
#   All rights reserved. Copyright (c) 2020 VECTIONEER.
#


from setuptools import setup
import os

with open("README.md", "r") as fh:
    long_description = fh.read()


def read_version():
    version_file = os.path.join(os.path.dirname(__file__), "motorcortex", "version.py")
    with open(version_file) as f:
        for line in f:
            if line.startswith("__version__"):
                delim = '"' if '"' in line else "'"
                return line.split(delim)[1]
    raise RuntimeError("Unable to find version string.")


setup(name='motorcortex-python',
      version=read_version(),
      description='Python bindings for Motorcortex Engine',
      long_description=long_description,
      long_description_content_type="text/markdown",
      author='Alexey Zakharov',
      author_email='alexey.zakharov@vectioneer.com',
      url='https://www.motorcortex.io',
      license='MIT',
      packages=['motorcortex'],
      package_data={'motorcortex': ['py.typed', '*.pyi']},
      python_requires='>=3.10',
      install_requires=[
          # pynng is pre-1.0, so its API contract may flip at 1.0
          # — keep an upper bound to head off a silent install-time
          # break. protobuf has been runtime-backcompat across its
          # 3.x / 4.x / 5.x / 6.x majors, so we deliberately don't
          # cap it.
          'pynng>=0.9.0,<2',
          'protobuf>=3.20'],
      classifiers=[
          'Development Status :: 5 - Production/Stable',
          'Intended Audience :: Developers',
          'License :: OSI Approved :: MIT License',
          'Operating System :: OS Independent',
          'Programming Language :: Python :: 3',
          'Programming Language :: Python :: 3.10',
          'Programming Language :: Python :: 3.11',
          'Programming Language :: Python :: 3.12',
          'Programming Language :: Python :: 3.13',
          'Topic :: Software Development :: Libraries :: Python Modules',
          'Topic :: System :: Distributed Computing',
      ],
      include_package_data=True,
      )
