#!/usr/bin/python3

#
#   Developer: Alexey Zakharov (alexey.zakharov@vectioneer.com)
#   All rights reserved. Copyright (c) 2016-2026 VECTIONEER.
#


from concurrent.futures import Future, TimeoutError as _FutureTimeout
from typing import Any, Callable, Generic, Optional, TypeVar

from motorcortex.exceptions import McxTimeout


T = TypeVar("T")


class Reply(Generic[T]):
    """Reply handle is a JavaScript-like Promise, generic over the
    message type returned by the underlying RPC.

    ``Reply[T].get()`` returns ``T`` — the decoded protobuf message
    class for the specific RPC. For example,
    ``Request.getParameter`` returns ``Reply[ParameterMsg]``, so
    ``req.getParameter(path).get()`` is a ``ParameterMsg`` at the
    type-check level, not ``Any``.

    Runtime behavior is unchanged — ``Reply[X]`` is a typing-time
    construct; at runtime it is just ``Reply``. Pre-generic annotations
    like ``reply: Reply`` still work (equivalent to ``Reply[Any]``).
    """

    def __init__(self, future: "Future[Any]") -> None:
        self._future = future

    def __repr__(self) -> str:
        return f"Reply(done={self._future.done()})"

    def get(self, timeout_ms: Optional[int] = None) -> T:
        """A blocking call to wait for the reply and returns a value.

            Args:
                timeout_ms(integer): timeout for reply in milliseconds

            Returns:
                A protobuf message with a parameter description and value.

            Raises:
                McxTimeout: ``timeout_ms`` elapsed before the reply
                    arrived. ``McxTimeout`` inherits ``TimeoutError``
                    so ``except TimeoutError`` still catches it.

            Examples:
                  >>> param_tree_reply = req.getParameterTree()
                  >>> value = param_tree_reply.get()

        """
        try:
            return self._future.result(timeout_ms / 1000.0 if timeout_ms else None)
        except _FutureTimeout as e:
            # Keep the typed-exception contract from ARCHITECTURE.md §2b:
            # reply-level timeouts raise McxTimeout, not the stdlib
            # TimeoutError that concurrent.futures would leak.
            raise McxTimeout(
                f"Reply.get timed out after {timeout_ms}ms"
            ) from e

    def done(self) -> bool:
        """
            Returns:
                bool: True if the call was successfully canceled or finished running.
        """
        return self._future.done()

    def then(self, received_clb: Callable[..., Any], *args: Any, **kwargs: Any) -> "Reply[T]":
        """JavaScript-like promise, which is resolved when a reply is received.

                Args:
                    received_clb: callback which is resolved when the reply is received.

                Returns:
                    self pointer to add 'catch' callback

                Examples:
                    >>> param_tree_reply.then(lambda reply: print("got reply: %s"%reply))
                    >>>                 .catch(lambda g: print("failed"))
        """
        self._future.add_done_callback(
            lambda msg: received_clb(msg.result(), *args, **kwargs) if msg.result() else None
        )
        return self

    def catch(self, failed_clb: Callable[..., Any], *args: Any, **kwargs: Any) -> "Reply[T]":
        """JavaScript-like promise, which is resolved when receive has failed.

            Args:
                failed_clb: callback which is resolved when receive has failed

            Returns:
                self pointer to add 'then' callback

            Examples:
                >>> param_tree_reply.catch(lambda g: print("failed")).then(lambda reply: print("got reply: %s"%reply))
        """
        self._future.add_done_callback(
            lambda msg: failed_clb(*args, **kwargs) if not msg.result() else None
        )
        return self
