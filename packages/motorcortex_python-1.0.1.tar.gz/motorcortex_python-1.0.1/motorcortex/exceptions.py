#
#   Developer: Alexey Zakharov (alexey.zakharov@vectioneer.com)
#   All rights reserved. Copyright (c) 2026 VECTIONEER.
#

"""Typed exceptions raised by the motorcortex library.

The library follows a deliberate split between **transport** errors
(which raise) and **protocol-level** status (which lives on the reply
message and is checked by the caller):

- **Transport errors raise** an :class:`McxError` subclass. Use when
  the socket is closed, the server never answers, or the dial itself
  fails. Caller can't do anything with the reply — there isn't one.
- **Protocol-level status stays on the reply.** ``reply.get().status``
  carries codes like ``WRONG_PASSWORD``, ``WRONG_PARAMETER_PATH``,
  ``READ_ONLY_MODE``. Caller inspects if they care; nothing raises.

Every exception here inherits from ``RuntimeError`` so existing
``try: ... except RuntimeError: ...`` code keeps catching
motorcortex failures without modification.
"""

from __future__ import annotations

from typing import Optional


class McxError(RuntimeError):
    """Base class for all motorcortex library errors.

    Inherits from ``RuntimeError`` so code that was written against the
    pre-typed-exception era (``except RuntimeError``) keeps working
    when the library swaps in more specific types.
    """


class McxConnectionError(McxError):
    """Transport failure: socket is closed, server is unreachable,
    dial was rejected, or a request was made on a connection that
    never came up.
    """


class McxLoginError(McxError):
    """Login RPC returned a non-OK status during
    :func:`motorcortex.connect` or
    :meth:`motorcortex.Session.connect`.

    The engine's numeric status code is available as :attr:`status`
    so callers can distinguish ``WRONG_PASSWORD`` from
    ``READ_ONLY_MODE`` without parsing the message text.
    """

    def __init__(self, message: str, status: Optional[int] = None) -> None:
        super().__init__(message)
        self.status: Optional[int] = status


class McxTimeout(McxError, TimeoutError):
    """A reply didn't arrive within the requested timeout.

    Dual-bases ``McxError`` and the stdlib ``TimeoutError`` so either
    ``except McxError`` or ``except TimeoutError`` catches it.
    """
