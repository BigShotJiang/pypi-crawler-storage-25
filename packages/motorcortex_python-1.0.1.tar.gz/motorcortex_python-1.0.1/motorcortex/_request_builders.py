#
#   Developer: Alexey Zakharov (alexey.zakharov@vectioneer.com)
#   All rights reserved. Copyright (c) 2026 VECTIONEER.
#

"""Pure protobuf message builders used by :class:`motorcortex.Request`.

These used to be private static methods on ``Request``. Moving them to
a free-function module so they can be unit-tested without spinning up a
socket or stubbing the class.

Everything here is side-effect-free w.r.t. the wire — the builders just
produce protobuf messages that the caller later hands to
``Request.send()``. They may log an error when no encoder resolves, but
they do not touch sockets, files, or global state.
"""

from __future__ import annotations

from typing import Any, Optional, TYPE_CHECKING

from motorcortex.setup_logger import logger

if TYPE_CHECKING:  # pragma: no cover
    from motorcortex.message_types import MessageTypes
    from motorcortex.parameter_tree import ParameterTree


def _resolve_encoder(
        path: str,
        type_name: Optional[str],
        protobuf_types: "MessageTypes",
        parameter_tree: "ParameterTree",
) -> Any:
    """Find the encoder for ``path`` — by explicit ``type_name`` first,
    otherwise by hash looked up in the parameter tree.

    Returns ``None`` when neither resolution succeeds. Callers (see
    ``build_set_parameter_msg`` / ``build_overwrite_parameter_msg``)
    log and fall back to sending an empty-value message, which the
    server rejects with a clean status code — beats raising
    ``AttributeError`` at the client on ``.encode()``.
    """
    if type_name:
        return protobuf_types.createType(type_name)
    try:
        type_id = parameter_tree.getDataType(path)
    except KeyError:
        return None
    return protobuf_types.getTypeByHash(type_id)


def build_set_parameter_msg(
        path: str,
        value: Any,
        type_name: Optional[str],
        protobuf_types: "MessageTypes",
        parameter_tree: "ParameterTree",
) -> Any:
    """``SetParameterMsg`` for a single parameter (whole-value write).

    When the encoder cannot be resolved (unknown path, no ``type_name``),
    the message is built with an empty ``value`` byte string and sent as-is
    — the server rejects it with a proper error status, which beats
    raising ``AttributeError`` at the client.
    """
    param_value = _resolve_encoder(path, type_name, protobuf_types, parameter_tree)
    msg = protobuf_types.createType("motorcortex.SetParameterMsg")
    msg.path = path
    if param_value is None:
        logger.error("No encoder for path %s (type=%s) — sending empty value", path, type_name)
        msg.value = b""
    else:
        msg.value = param_value.encode(value)
    return msg


def build_set_parameter_with_offset_msg(
        offset: int,
        length: int,
        path: str,
        value: Any,
        type_name: Optional[str],
        protobuf_types: "MessageTypes",
        parameter_tree: "ParameterTree",
) -> Any:
    """``SetParameterMsg`` with an ``offset`` + ``length`` slice window.

    Negative offsets are clamped to zero. ``length == 0`` means "write
    all of ``value``" and is inferred from ``len(value)`` (or 1 for
    scalars). Unknown encoder → empty ``value``, see
    :func:`build_set_parameter_msg`.
    """
    param_value = _resolve_encoder(path, type_name, protobuf_types, parameter_tree)

    if offset < 0:
        offset = 0
    if length < 0:
        length = 0
    if length == 0:
        length = len(value) if hasattr(value, "__len__") else 1

    msg = protobuf_types.createType("motorcortex.SetParameterMsg")
    msg.offset.type = 1
    msg.offset.offset = offset
    msg.offset.length = length
    msg.path = path
    if param_value is None:
        logger.error("No encoder for path %s (type=%s) — sending empty value", path, type_name)
        msg.value = b""
    else:
        msg.value = param_value.encode(value)
    return msg


def build_get_parameter_msg(
        path: str,
        protobuf_types: "MessageTypes",
) -> Any:
    """``GetParameterMsg`` — trivial, just carries the path."""
    msg = protobuf_types.createType("motorcortex.GetParameterMsg")
    msg.path = path
    return msg


def build_overwrite_parameter_msg(
        path: str,
        value: Any,
        activate: bool,
        type_name: Optional[str],
        protobuf_types: "MessageTypes",
        parameter_tree: "ParameterTree",
) -> Any:
    """``OverwriteParameterMsg`` — pins a value until release or deactivate.

    Unknown encoder → empty ``value``, see :func:`build_set_parameter_msg`.
    """
    param_value = _resolve_encoder(path, type_name, protobuf_types, parameter_tree)
    msg = protobuf_types.createType("motorcortex.OverwriteParameterMsg")
    msg.path = path
    msg.activate = activate
    if param_value is None:
        logger.error("No encoder for path %s (type=%s) — sending empty value", path, type_name)
        msg.value = b""
    else:
        msg.value = param_value.encode(value)
    return msg


def build_release_parameter_msg(
        path: str,
        protobuf_types: "MessageTypes",
) -> Any:
    """``ReleaseParameterMsg`` — drop any active overwrite on ``path``."""
    msg = protobuf_types.createType("motorcortex.ReleaseParameterMsg")
    msg.path = path
    return msg
