#
#   Developer: Alexey Zakharov (alexey.zakharov@vectioneer.com)
#   All rights reserved. Copyright (c) 2026 VECTIONEER.
#

"""Pure frame-parsing and dispatch helpers for :mod:`motorcortex.subscribe`.

These used to be inlined in ``Subscribe.__run``. Moving them out lets us
unit-test the wire format parser and the protocol-version dispatch
without standing up a real subscribe socket — in particular the
"unknown protocol version" branch that real servers never produce.

Wire frame layout:
    bytes [0..2]  little-endian 24-bit subscription id
    byte   3      protocol version (0 = MULTI_TIMESTAMP, 1 = SINGLE_TIMESTAMP)
    bytes [4..]   payload passed to ``Subscription._updateProtocol{0,1}``
"""

from __future__ import annotations

from typing import Any, Mapping, Tuple

from motorcortex.setup_logger import logger


_HEADER_SIZE = 4


def parse_frame_header(buffer: bytes) -> Tuple[int, int]:
    """Decode the leading 4-byte frame header.

    Args:
        buffer: Raw bytes received on the subscribe socket. Must be at
            least ``_HEADER_SIZE`` long; shorter inputs raise IndexError.

    Returns:
        ``(sub_id, protocol_version)``.
    """
    sub_id = buffer[0] + (buffer[1] << 8) + (buffer[2] << 16)
    protocol_version = buffer[3]
    return sub_id, protocol_version


def dispatch_frame(buffer: bytes, subscriptions: Mapping[int, Any]) -> None:
    """Route a received wire frame to the matching ``Subscription``.

    Drops frames that fail any of:
    - empty / shorter than the 4-byte header,
    - sub_id not present in ``subscriptions``,
    - protocol version ≠ 0 and ≠ 1.

    Dropped frames are logged at ``error`` (unknown protocol / short frame)
    or ``debug`` (unknown sub_id — can happen briefly after unsubscribe).
    """
    if not buffer:
        return
    if len(buffer) < _HEADER_SIZE:
        logger.error(
            '[SUBSCRIBE-DISPATCH] Frame shorter than header (%d bytes)',
            len(buffer),
        )
        return

    sub_id, protocol_version = parse_frame_header(buffer)
    sub = subscriptions.get(sub_id)

    if sub is None:
        logger.debug(
            '[SUBSCRIBE-DISPATCH] Received data for unknown subscription id: %s',
            sub_id,
        )
        return

    payload = buffer[_HEADER_SIZE:]
    payload_length = len(buffer) - _HEADER_SIZE

    if protocol_version == 1:
        sub._updateProtocol1(payload, payload_length)
    elif protocol_version == 0:
        sub._updateProtocol0(payload, payload_length)
    else:
        logger.error(
            '[SUBSCRIBE-DISPATCH] Unknown protocol version: %s for sub_id: %s',
            protocol_version, sub_id,
        )
        # Bump the subscription's dropped-frame count so callers can
        # observe the silent discard via ``Subscription.droppedFrameCount()``.
        recorder = getattr(sub, '_recordDroppedFrame', None)
        if recorder is not None:
            recorder()
