#
#   Developer: Alexey Zakharov (alexey.zakharov@vectioneer.com)
#   All rights reserved. Copyright (c) 2026 VECTIONEER.
#

"""High-level context-manager wrapper around ``(Request, Subscribe)``.

``motorcortex.Session`` owns both channels, constructs sensible defaults
for ``MessageTypes`` and ``ParameterTree``, and guarantees ``close()``
on the way out — including on exceptions inside the ``with`` block.
Nothing about the underlying API changes: ``session.req`` and
``session.sub`` are the same ``Request`` / ``Subscribe`` instances the
user would get from :func:`motorcortex.connect`, so every existing
method call keeps working unchanged.

The class is intentionally thin. It does not replicate the RPC surface
of ``Request`` / ``Subscribe`` — pass-through getters would drift from
the real objects over time. A couple of convenience properties
(``connectionState``, ``token``) are provided because they're the two
things users poll most often.

Example::

    with motorcortex.Session(
        "wss://robot.local:5568:5567",
        login="administrator",
        password="administrator",
        certificate="/etc/ssl/certs/motorcortex.pem",
    ) as s:
        reply = s.req.getParameter("root/Control/x").get()
        s.sub.subscribe(["root/Control/x"], "grp", frq_divider=10)

The existing :func:`motorcortex.connect` entrypoint is unchanged; code
that manages ``(req, sub)`` explicitly keeps working.
"""

from __future__ import annotations

from types import TracebackType
from typing import Any, Optional, Type, TYPE_CHECKING

from motorcortex.exceptions import McxConnectionError

if TYPE_CHECKING:  # pragma: no cover
    from motorcortex.request import Request, ConnectionState
    from motorcortex.subscribe import Subscribe
    from motorcortex.message_types import MessageTypes
    from motorcortex.parameter_tree import ParameterTree


class Session:
    """Context-manager owning a ``(Request, Subscribe)`` pair.

    Args:
        url: Connection URL (``scheme://host:req_port:sub_port``).
        motorcortex_types: Optional pre-built ``MessageTypes``. A fresh
            one is constructed when omitted.
        param_tree: Optional pre-built ``ParameterTree``. A fresh one
            is constructed when omitted. After :meth:`connect` /
            entering the ``with`` block, the tree is populated from
            the server.
        **kwargs: Forwarded verbatim to :func:`motorcortex.connect` —
            ``login``, ``password``, ``certificate``, ``timeout_ms``,
            ``reconnect``, ``token_update_interval_ms``,
            ``req_number_of_threads``, ``sub_number_of_threads``,
            ``state_update``.

    The session is lazy — it does not dial until :meth:`connect` is
    called or the ``with`` block is entered. That way constructing a
    Session on its own is cheap and can't raise ``RuntimeError``.
    """

    def __init__(
            self,
            url: str,
            motorcortex_types: Optional["MessageTypes"] = None,
            param_tree: Optional["ParameterTree"] = None,
            **kwargs: Any,
    ) -> None:
        # Imported lazily so the `motorcortex` package can be imported
        # without pulling in pynng during static analysis.
        from motorcortex.message_types import MessageTypes
        from motorcortex.parameter_tree import ParameterTree

        self._url = url
        self._kwargs = kwargs
        self._types: "MessageTypes" = motorcortex_types or MessageTypes()
        self._tree: "ParameterTree" = param_tree or ParameterTree()
        self._req: Optional["Request"] = None
        self._sub: Optional["Subscribe"] = None

    # -- lifecycle -----------------------------------------------------

    def connect(self) -> "Session":
        """Open the underlying ``Request`` / ``Subscribe`` pair.

        Idempotent — a second call while already connected is a no-op.
        Returns ``self`` so ``with Session(...).connect() as s:`` works
        (though entering the ``with`` block alone is enough).
        """
        if self._req is not None:
            return self
        from motorcortex import connect as _connect
        self._req, self._sub = _connect(
            self._url, self._types, self._tree, **self._kwargs,
        )
        return self

    def close(self) -> None:
        """Close subscribe then request. Idempotent; safe on failure."""
        if self._sub is not None:
            try:
                self._sub.close()
            except Exception:
                pass
            self._sub = None
        if self._req is not None:
            try:
                self._req.close()
            except Exception:
                pass
            self._req = None

    def __enter__(self) -> "Session":
        return self.connect()

    def __exit__(
            self,
            exc_type: Optional[Type[BaseException]],
            exc: Optional[BaseException],
            tb: Optional[TracebackType],
    ) -> None:
        self.close()

    def __repr__(self) -> str:
        if self._req is None:
            state = "not-connected"
        else:
            state = self._req.connectionState().name
        return f"Session(url={self._url!r}, state={state})"

    # -- accessors -----------------------------------------------------

    @property
    def req(self) -> "Request":
        """The underlying ``Request``. Raises if :meth:`connect` hasn't run."""
        if self._req is None:
            raise McxConnectionError(
                "Session is not connected. Use 'with Session(...) as s:' "
                "or call session.connect() first."
            )
        return self._req

    @property
    def sub(self) -> "Subscribe":
        """The underlying ``Subscribe``."""
        if self._sub is None:
            raise McxConnectionError(
                "Session is not connected. Use 'with Session(...) as s:' "
                "or call session.connect() first."
            )
        return self._sub

    @property
    def types(self) -> "MessageTypes":
        """The ``MessageTypes`` instance this session uses."""
        return self._types

    @property
    def tree(self) -> "ParameterTree":
        """The populated ``ParameterTree`` after connect; empty before."""
        return self._tree

    @property
    def url(self) -> str:
        return self._url

    def connectionState(self) -> "ConnectionState":
        """Convenience shortcut for ``session.req.connectionState()``.

        Returns ``DISCONNECTED`` before :meth:`connect` has run so
        callers don't need to guard against ``None``.
        """
        from motorcortex._connection_state import ConnectionState
        if self._req is None:
            return ConnectionState.DISCONNECTED
        return self._req.connectionState()

    @property
    def token(self) -> Optional[str]:
        """Convenience shortcut for ``session.req.token`` — the session
        token issued by the engine at login, or ``None`` before connect.
        """
        return None if self._req is None else self._req.token
