#!/usr/bin/python3

#
#   Developer: Alexey Zakharov (alexey.zakharov@vectioneer.com)
#   All rights reserved. Copyright (c) 2016-2026 VECTIONEER.
#

"""NNG thread-count initialization.

``init_nng_threads`` is called automatically once from
``motorcortex/__init__.py`` — it **must** run before any pynng socket
is created, because NNG latches these values on its first internal
init and ignores subsequent ``nng_init_set_parameter`` calls. The
import-time auto-call is what guarantees that ordering for users who
only touch NNG through motorcortex.

Values are process-wide, so anything else using pynng in the same
process inherits them. The hardcoded defaults (task=2, expire=1,
poller=1, resolver=1) are tuned for the request/subscribe workload;
most callers never need to tune them.

Ops-side tuning is via env vars, read at import time — no code
change needed:

    MCX_NNG_TASK_THREADS       default 2
    MCX_NNG_EXPIRE_THREADS     default 1
    MCX_NNG_POLLER_THREADS     default 1
    MCX_NNG_RESOLVER_THREADS   default 1

Any explicit keyword argument to ``init_nng_threads(...)`` takes
precedence over the env value. Env bad-values (non-int, negative)
fall back to the default with a warning.
"""

import os

from pynng._nng import lib  # type: ignore[import-untyped]
from motorcortex.setup_logger import logger


_DEFAULTS = {
    "task": 2,
    "expire": 1,
    "poller": 1,
    "resolver": 1,
}

_ENV_NAMES = {
    "task": "MCX_NNG_TASK_THREADS",
    "expire": "MCX_NNG_EXPIRE_THREADS",
    "poller": "MCX_NNG_POLLER_THREADS",
    "resolver": "MCX_NNG_RESOLVER_THREADS",
}


def _resolve(name: str, override: int | None) -> int:
    """Pick the value for one knob: explicit arg > env var > default."""
    if override is not None:
        return override
    raw = os.environ.get(_ENV_NAMES[name])
    if raw is None:
        return _DEFAULTS[name]
    try:
        value = int(raw)
        if value < 1:
            raise ValueError("must be >= 1")
        return value
    except ValueError as e:
        logger.warning(
            "[INIT-THREADS] %s=%r invalid (%s); using default %d",
            _ENV_NAMES[name], raw, e, _DEFAULTS[name],
        )
        return _DEFAULTS[name]


def init_nng_threads(
    task: int | None = None,
    expire: int | None = None,
    poller: int | None = None,
    resolver: int | None = None,
) -> None:
    """Set NNG thread-pool sizes. Must run before any pynng socket.

    Any argument left as ``None`` is resolved from the matching
    ``MCX_NNG_*_THREADS`` env var, falling back to the hardcoded
    default.
    """
    task_n = _resolve("task", task)
    expire_n = _resolve("expire", expire)
    poller_n = _resolve("poller", poller)
    resolver_n = _resolve("resolver", resolver)

    try:
        lib.nng_init_set_parameter(lib.NNG_INIT_NUM_TASK_THREADS, task_n)
        lib.nng_init_set_parameter(lib.NNG_INIT_NUM_EXPIRE_THREADS, expire_n)
        lib.nng_init_set_parameter(lib.NNG_INIT_NUM_POLLER_THREADS, poller_n)
        lib.nng_init_set_parameter(lib.NNG_INIT_NUM_RESOLVER_THREADS, resolver_n)
        logger.debug(
            "[INIT-THREADS] task=%d expire=%d poller=%d resolver=%d",
            task_n, expire_n, poller_n, resolver_n,
        )
    except AttributeError:
        logger.error("[INIT-THREADS] Cannot adjust thread count: interface unavailable")
