#
#   Developer: Alexey Zakharov (alexey.zakharov@vectioneer.com)
#   All rights reserved. Copyright (c) 2026 VECTIONEER.
#

"""Connection-state enum + pure state-transition helpers.

``ConnectionState`` was historically defined in ``motorcortex.request`` and
is still re-exported from there (and from ``motorcortex``) for backward
compatibility. It lives here so pure helpers can depend on it without
dragging the whole ``request`` module — which would cause a circular
import.
"""

from __future__ import annotations

from enum import Enum


class ConnectionState(Enum):
    """Enumeration of connection states.

        - CONNECTING:           Connection is being established.
        - CONNECTION_OK:        Connection is successfully established.
        - CONNECTION_LOST:      Connection was lost.
        - CONNECTION_FAILED:    Connection attempt failed.
        - DISCONNECTING:        Connection is being closed.
        - DISCONNECTED:         Connection is closed.
    """
    CONNECTING = 0
    CONNECTION_OK = 1
    CONNECTION_LOST = 2
    CONNECTION_FAILED = 3
    DISCONNECTING = 4
    DISCONNECTED = 5


def next_state_after_pipe_remove(current: ConnectionState) -> ConnectionState:
    """Map the current state to the one we enter when the remote pipe goes away.

    nng fires its post-remove callback when a peer socket is torn down, but
    the callback itself can't tell *why*: we might have called
    ``close()`` (clean shutdown) or the remote might have died (lost /
    failed). The only disambiguator is the state we were already in.

    Transitions:
        DISCONNECTING    → DISCONNECTED        (clean close we initiated)
        CONNECTING       → CONNECTION_FAILED   (never finished handshake)
        CONNECTION_OK    → CONNECTION_LOST     (remote went away mid-session)
        anything else    → unchanged           (idempotent / re-entry safe)
    """
    if current == ConnectionState.DISCONNECTING:
        return ConnectionState.DISCONNECTED
    if current == ConnectionState.CONNECTING:
        return ConnectionState.CONNECTION_FAILED
    if current == ConnectionState.CONNECTION_OK:
        return ConnectionState.CONNECTION_LOST
    return current
