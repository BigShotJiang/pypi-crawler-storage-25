"""
LogForge Python SDK
Official client for LogForge — self-hosted log management
https://github.com/loickadjiwanou/logforge-py-sdk
"""

from .client import LogForge

__all__ = ["LogForge"]
__version__ = "2.0.0"
