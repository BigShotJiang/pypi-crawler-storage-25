"""
LogForge Python SDK — main client
"""

from __future__ import annotations

import logging
import platform
import queue
import threading
import traceback
import uuid
from typing import Any, Dict, List, Literal, Optional

try:
    import requests as _requests
    _REQUESTS_AVAILABLE = True
except ImportError:
    _REQUESTS_AVAILABLE = False

try:
    import httpx as _httpx
    _HTTPX_AVAILABLE = True
except ImportError:
    _HTTPX_AVAILABLE = False

LogLevel = Literal["info", "warning", "error", "debug", "critical"]

_logger = logging.getLogger("logforge")


def _get_device_info() -> Dict[str, Any]:
    return {
        "runtime": "python",
        "python_version": platform.python_version(),
        "platform": platform.system(),
        "platform_release": platform.release(),
        "machine": platform.machine(),
        "processor": platform.processor(),
    }


def _generate_uuid() -> str:
    return str(uuid.uuid4())


class LogForge:
    """
    LogForge Python SDK client.

    Parameters
    ----------
    api_key : str
        Project API key from the LogForge dashboard.
    endpoint : str
        Base URL of your LogForge backend (e.g. ``https://logs.myapp.com``).
    environment : str
        Environment tag attached to every log. Default: ``"production"``.
    channel : str
        Default log channel. Default: ``"default"``.
    batch_size : int
        Max number of logs per flush. Default: ``10``.
    flush_interval : float
        Seconds between auto-flushes. Default: ``5.0``.
    retry_attempts : int
        Number of HTTP retry attempts on failure. Default: ``3``.
    debug : bool
        Log SDK-internal errors via the Python ``logging`` module. Default: ``False``.
    timeout : float
        HTTP request timeout in seconds. Default: ``10.0``.

    Examples
    --------
    >>> from logforge import LogForge
    >>> logger = LogForge(api_key="YOUR_KEY", endpoint="https://logs.myapp.com")
    >>> logger.info("App started")
    >>> logger.shutdown()
    """

    def __init__(
        self,
        *,
        api_key: str,
        endpoint: str,
        environment: str = "production",
        channel: str = "default",
        batch_size: int = 10,
        flush_interval: float = 5.0,
        retry_attempts: int = 3,
        debug: bool = False,
        timeout: float = 10.0,
    ) -> None:
        if not api_key:
            raise ValueError("[LogForge] api_key is required")
        if not endpoint:
            raise ValueError("[LogForge] endpoint is required")
        if not _REQUESTS_AVAILABLE and not _HTTPX_AVAILABLE:
            raise ImportError(
                "[LogForge] Install either 'requests' or 'httpx': "
                "pip install logforge-py[requests] OR pip install logforge-py[httpx]"
            )

        self.api_key = api_key
        self.endpoint = endpoint.rstrip("/")
        self.environment = environment
        self.channel = channel
        self.batch_size = batch_size
        self.flush_interval = flush_interval
        self.retry_attempts = retry_attempts
        self._debug_mode = debug
        self.timeout = timeout

        self._user_info: Optional[Dict[str, Any]] = None
        self._queue: queue.Queue = queue.Queue()
        self._shutdown_event = threading.Event()
        self._lock = threading.Lock()

        self._flush_thread = threading.Thread(
            target=self._flush_loop,
            daemon=True,
            name="logforge-flush",
        )
        self._flush_thread.start()

    # ---------------------------------------------------------------------------
    # Public API
    # ---------------------------------------------------------------------------

    def log(
        self,
        level: LogLevel,
        message: str,
        *,
        channel: Optional[str] = None,
        environment: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        stack_trace: Optional[str] = None,
        user: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
    ) -> str:
        """
        Send a log entry. Returns the generated log ID (UUID).

        Parameters
        ----------
        level : LogLevel
            One of ``'info'``, ``'warning'``, ``'error'``, ``'debug'``, ``'critical'``.
        message : str
            Human-readable log message.
        channel : str, optional
            Override the default channel for this entry.
        environment : str, optional
            Override the default environment for this entry.
        metadata : dict, optional
            Arbitrary key/value pairs to attach.
        stack_trace : str, optional
            Stack trace string.
        user : dict, optional
            User context override (overrides ``set_user``).
        tags : list[str], optional
            List of tag strings.
        """
        log_id = _generate_uuid()
        entry = {
            "id": log_id,
            "level": level,
            "message": str(message),
            "channel": channel or self.channel,
            "environment": environment or self.environment,
            "metadata": metadata or {},
            "stack_trace": stack_trace,
            "user_info": user or self._user_info,
            "device_info": _get_device_info(),
            "tags": tags or [],
        }
        self._queue.put(entry)
        return log_id

    def info(self, message: str, **kwargs) -> str:
        """Send an info-level log."""
        return self.log("info", message, **kwargs)

    def warning(self, message: str, **kwargs) -> str:
        """Send a warning-level log."""
        return self.log("warning", message, **kwargs)

    # Alias
    warn = warning

    def error(self, message: str, **kwargs) -> str:
        """Send an error-level log."""
        return self.log("error", message, **kwargs)

    def debug(self, message: str, **kwargs) -> str:
        """Send a debug-level log."""
        return self.log("debug", message, **kwargs)

    def critical(self, message: str, **kwargs) -> str:
        """Send a critical-level log."""
        return self.log("critical", message, **kwargs)

    def capture_exception(
        self,
        exc: Optional[BaseException] = None,
        **kwargs,
    ) -> str:
        """
        Capture a Python exception with its full stack trace.

        If ``exc`` is ``None``, the current exception (from ``sys.exc_info()``) is used.

        Parameters
        ----------
        exc : BaseException, optional
            Exception to capture. Defaults to the active exception.
        **kwargs
            Additional options passed to :meth:`log`.

        Examples
        --------
        >>> try:
        ...     1 / 0
        ... except ZeroDivisionError as e:
        ...     logger.capture_exception(e)
        """
        import sys

        if exc is None:
            exc_info = sys.exc_info()
            if exc_info[1] is None:
                raise RuntimeError(
                    "[LogForge] capture_exception() called with no active exception"
                )
            exc = exc_info[1]

        tb = "".join(
            traceback.format_exception(type(exc), exc, exc.__traceback__)
        )
        metadata = dict(kwargs.pop("metadata", {}) or {})
        metadata["error_type"] = type(exc).__name__

        return self.error(
            str(exc),
            stack_trace=tb,
            metadata=metadata,
            **kwargs,
        )

    def set_user(self, user_id: str, email: str, name: Optional[str] = None, **extra) -> None:
        """
        Set the persistent user context attached to all subsequent logs.

        Parameters
        ----------
        user_id : str
        email : str
        name : str, optional
        **extra
            Any additional user fields.
        """
        self._user_info = {"id": user_id, "email": email, "name": name, **extra}

    def clear_user(self) -> None:
        """Remove the current user context."""
        self._user_info = None

    def set_channel(self, channel: str) -> None:
        """Update the default channel."""
        self.channel = channel

    def set_environment(self, environment: str) -> None:
        """Update the default environment."""
        self.environment = environment

    def flush(self) -> None:
        """
        Synchronously flush all pending logs in the queue.

        Blocks until the queue is empty and all batches have been sent.
        """
        while not self._queue.empty():
            self._flush_batch()

    def shutdown(self) -> None:
        """
        Flush remaining logs and stop the background thread.

        Call this before process exit to ensure no logs are lost.

        Examples
        --------
        >>> import atexit
        >>> atexit.register(logger.shutdown)
        """
        self._shutdown_event.set()
        self.flush()
        self._flush_thread.join(timeout=10)

    # ---------------------------------------------------------------------------
    # Private helpers
    # ---------------------------------------------------------------------------

    def _flush_loop(self) -> None:
        while not self._shutdown_event.is_set():
            self._shutdown_event.wait(timeout=self.flush_interval)
            self._flush_batch()

    def _flush_batch(self) -> None:
        batch: List[Dict[str, Any]] = []
        try:
            while len(batch) < self.batch_size:
                batch.append(self._queue.get_nowait())
        except queue.Empty:
            pass

        if not batch:
            return

        url = f"{self.endpoint}/api/logs/ingest/batch"
        headers = {"X-API-Key": self.api_key, "Content-Type": "application/json"}
        payload = {"logs": batch}

        for attempt in range(self.retry_attempts):
            try:
                self._post(url, headers, payload)
                # Mark tasks as done
                for _ in batch:
                    self._queue.task_done()
                return
            except Exception as exc:  # noqa: BLE001
                if self._debug_mode:
                    _logger.error(
                        "[LogForge] Flush attempt %d/%d failed: %s",
                        attempt + 1,
                        self.retry_attempts,
                        exc,
                    )
                if attempt < self.retry_attempts - 1:
                    import time
                    time.sleep(2 ** attempt)

        # All retries failed — re-queue the batch
        if self._debug_mode:
            _logger.error("[LogForge] All retry attempts failed. Re-queuing %d logs.", len(batch))
        for entry in reversed(batch):
            # Put back at front by draining and refilling is expensive;
            # just put them back (ordering may differ slightly).
            self._queue.put(entry)

    def _post(self, url: str, headers: Dict[str, str], payload: Dict[str, Any]) -> None:
        import json

        body = json.dumps(payload, default=str)

        if _REQUESTS_AVAILABLE:
            resp = _requests.post(
                url,
                data=body,
                headers=headers,
                timeout=self.timeout,
            )
            resp.raise_for_status()
        else:
            with _httpx.Client(timeout=self.timeout) as client:
                resp = client.post(url, content=body, headers=headers)
            resp.raise_for_status()
