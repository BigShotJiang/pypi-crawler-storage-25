"""
LogForge Python SDK — unit tests (no external HTTP calls)
"""

import json
import re
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest

from logforge import LogForge


def _noop_post(self, url, headers, payload):
    """Replacement for LogForge._post that does nothing (no network call)."""
    pass


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _MockHandler(BaseHTTPRequestHandler):
    """Minimal HTTP server that records received request bodies."""

    received: list = []

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        _MockHandler.received.append(json.loads(body))
        self.send_response(200)
        self.end_headers()

    def log_message(self, *args):  # silence stdout
        pass


def _start_mock_server():
    server = HTTPServer(("127.0.0.1", 0), _MockHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    _MockHandler.received.clear()
    return server, thread


# ---------------------------------------------------------------------------
# Constructor validation
# ---------------------------------------------------------------------------


def test_raises_without_api_key():
    with pytest.raises(ValueError, match="api_key"):
        LogForge(api_key="", endpoint="http://x")


def test_raises_without_endpoint():
    with pytest.raises(ValueError, match="endpoint"):
        LogForge(api_key="key", endpoint="")


def test_strips_trailing_slash(monkeypatch):
    monkeypatch.setattr(LogForge, "_post", _noop_post)
    sdk = LogForge(api_key="k", endpoint="http://x/")
    sdk.shutdown()
    assert sdk.endpoint == "http://x"


# ---------------------------------------------------------------------------
# Log queue
# ---------------------------------------------------------------------------


def test_log_adds_to_queue(monkeypatch):
    monkeypatch.setattr(LogForge, "_post", _noop_post)
    sdk = LogForge(api_key="k", endpoint="http://x", flush_interval=9999)
    sdk.info("hello")
    assert sdk._queue.qsize() == 1
    sdk.shutdown()


def test_log_returns_uuid(monkeypatch):
    monkeypatch.setattr(LogForge, "_post", _noop_post)
    sdk = LogForge(api_key="k", endpoint="http://x", flush_interval=9999)
    log_id = sdk.info("test")
    assert re.match(r"^[0-9a-f-]{36}$", log_id)
    sdk.shutdown()


def test_set_user_attaches_to_log(monkeypatch):
    monkeypatch.setattr(LogForge, "_post", _noop_post)
    sdk = LogForge(api_key="k", endpoint="http://x", flush_interval=9999)
    sdk.set_user("42", "a@b.com", name="Alice")
    sdk.info("msg")
    entry = sdk._queue.get_nowait()
    assert entry["user_info"]["id"] == "42"
    assert entry["user_info"]["email"] == "a@b.com"
    sdk.shutdown()


def test_clear_user_removes_context(monkeypatch):
    monkeypatch.setattr(LogForge, "_post", _noop_post)
    sdk = LogForge(api_key="k", endpoint="http://x", flush_interval=9999)
    sdk.set_user("1", "x@y.com")
    sdk.clear_user()
    sdk.info("msg")
    entry = sdk._queue.get_nowait()
    assert entry["user_info"] is None
    sdk.shutdown()


def test_set_channel_updates_default(monkeypatch):
    monkeypatch.setattr(LogForge, "_post", _noop_post)
    sdk = LogForge(api_key="k", endpoint="http://x", flush_interval=9999)
    sdk.set_channel("payments")
    sdk.info("msg")
    entry = sdk._queue.get_nowait()
    assert entry["channel"] == "payments"
    sdk.shutdown()


def test_log_kwargs_override_defaults(monkeypatch):
    monkeypatch.setattr(LogForge, "_post", _noop_post)
    sdk = LogForge(api_key="k", endpoint="http://x", flush_interval=9999)
    sdk.info("msg", channel="auth", environment="staging")
    entry = sdk._queue.get_nowait()
    assert entry["channel"] == "auth"
    assert entry["environment"] == "staging"
    sdk.shutdown()


# ---------------------------------------------------------------------------
# capture_exception
# ---------------------------------------------------------------------------


def test_capture_exception_attaches_traceback(monkeypatch):
    monkeypatch.setattr(LogForge, "_post", _noop_post)
    sdk = LogForge(api_key="k", endpoint="http://x", flush_interval=9999)
    try:
        raise ValueError("bad input")
    except ValueError as exc:
        sdk.capture_exception(exc)

    entry = sdk._queue.get_nowait()
    assert entry["level"] == "error"
    assert entry["message"] == "bad input"
    assert "ValueError" in entry["stack_trace"]
    assert entry["metadata"]["error_type"] == "ValueError"
    sdk.shutdown()


def test_capture_exception_with_active_exception(monkeypatch):
    monkeypatch.setattr(LogForge, "_post", _noop_post)
    sdk = LogForge(api_key="k", endpoint="http://x", flush_interval=9999)
    try:
        raise TypeError("type error")
    except TypeError:
        sdk.capture_exception()  # no argument — uses sys.exc_info()

    entry = sdk._queue.get_nowait()
    assert entry["metadata"]["error_type"] == "TypeError"
    sdk.shutdown()


# ---------------------------------------------------------------------------
# HTTP flush (real local server)
# ---------------------------------------------------------------------------


def test_flush_sends_to_batch_endpoint():
    server, _ = _start_mock_server()
    port = server.server_address[1]
    endpoint = f"http://127.0.0.1:{port}"

    sdk = LogForge(api_key="test-key", endpoint=endpoint, flush_interval=9999)
    sdk.info("flush test", channel="ci")
    sdk.flush()

    assert len(_MockHandler.received) == 1
    body = _MockHandler.received[0]
    assert "logs" in body
    assert body["logs"][0]["message"] == "flush test"
    assert body["logs"][0]["channel"] == "ci"

    sdk.shutdown()
    server.shutdown()


def test_shutdown_flushes_remaining_logs():
    server, _ = _start_mock_server()
    port = server.server_address[1]
    endpoint = f"http://127.0.0.1:{port}"

    sdk = LogForge(api_key="test-key", endpoint=endpoint, flush_interval=9999)
    for i in range(5):
        sdk.info(f"log {i}")

    sdk.shutdown()
    server.shutdown()

    total_logs = sum(len(b["logs"]) for b in _MockHandler.received)
    assert total_logs == 5
