"""
Import shim for `syside.conf`
"""

from ..core.conf import *  # pyright: ignore
