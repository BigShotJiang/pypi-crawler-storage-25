"""
Import shim for `syside.cli`
"""

from ..core.cli import *  # pyright: ignore
