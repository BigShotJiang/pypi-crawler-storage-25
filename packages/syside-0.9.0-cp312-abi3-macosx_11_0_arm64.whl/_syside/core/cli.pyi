"""Internal CLI exposed to Python."""

from collections.abc import Callable, Sequence
import os
import pathlib
from typing import AnyStr


class Interactive:
    """Options for the ``interactive`` command."""

    @property
    def paths(self) -> list[pathlib.Path]:
        """Paths to model files or directories."""

    @paths.setter
    def paths(self, arg: list[str | os.PathLike[AnyStr]], /) -> None: ...

    @property
    def werror(self) -> bool:
        """Whether to treat warnings as errors."""

    @werror.setter
    def werror(self, arg: bool, /) -> None: ...

class ExtContext:
    """External command context"""

    @property
    def path(self) -> Sequence[str]:
        """Path of commands taken to the current command"""

    @path.setter
    def path(self, arg: Sequence[str], /) -> None: ...

    @property
    def term_width(self) -> int:
        """
        The ``stdout`` terminal width if it is one, or a large number.

        This can be used to fit output content instead of relying on terminal wrapping.
        """

    @term_width.setter
    def term_width(self, arg: int, /) -> None: ...

class ExternalCommand:
    """
    An external CLI command that may be invoked by the command line argument parser.

    Implementations must override both ``help`` and ``execute`` as they are otherwise abstract!
    """

    def __init__(self, name: str, description: str, aliases: Sequence[str] = ()) -> None:
        """Construct new ``ExternalCommand`` with the given metadata."""

    @property
    def name(self) -> str:
        """
        The name of this command that will also be displayed in ``help``.

        Note that duplicate names are hard errors, and will terminate the program.
        """

    @property
    def aliases(self) -> Sequence[str]:
        """
        Additional aliases to parse as this command.

        Note that duplicate aliases are hard errors, and will terminate the program.
        """

    @property
    def description(self) -> str:
        """
        Brief description of this command that will be displayed in ``help`` of its parent.

        By default, only the first paragraph will be displayed. As this command must print
        verbose ``help`` on its own, anything after will never be displayed.
        """

    def help(self, arguments: list[str], ctx: ExtContext) -> str:
        """
        Print help for this command or its subcommand.

        The argument list contains all arguments after reaching this subcommand. For example,
        ``syside help rule list`` will contain ``"list"`` as the only argument if ``rule`` was
        an external command.

        To match the behaviour of ``help`` command, all arguments should be further subcommands
        only. Implementations may assume that verbose help was requested.

        ``ctx`` contains additional details of this argument parse. Note that the ``help`` segment
        will not appear in ``ctx.path``.
        """

    def execute(self, arguments: list[str], ctx: ExtContext) -> int:
        """
        Execute this command.

        The argument list contains all arguments after reaching this subcommand. For example,
        ``syside rule --all`` will contain ``"--all"`` as the only argument if ``rule`` was
        an external command.

        Implementations must return an exit code, otherwise the exact behaviour is up to them.

        ``ctx`` contains additional details of this argument parse.
        """

def main(args: Sequence[str], interactive: Callable[[Interactive], int] | None = None, external: Sequence[ExternalCommand] = ()) -> int:
    """
    Entry point to internal Syside CLI. Returns exit code on completion.

    ``args`` must either be ``<syside> args...`` or ``<python> -m <syside> args...``, i.e.
    they must be the same as called from the command line, e.g. ``sys.argv``.

    The ``interactive`` argument is used to provide Python implementation for the
    ``interactive`` command.

    Raises anything ``interactive`` or ``external`` may raise if executed.

    The ``server`` command will use underlying native ``stdin`` and ``stdout`` streams
    directly, any modifications to ``sys.stdout`` and ``sys.stdin`` will not be propagated.

    .. warning::

        Multiple threads running ``server`` command simultaneously are not supported as
        it overrides global exit and error hooks. If multiple servers are needed, run
        them in separate processes.
    """
