from collections.abc import Sequence
import enum
import os
from typing import AnyStr


class AlwaysNever(enum.Enum):
    """An option to ``always`` print some token, or ``never``."""

    Always = 0

    Never = 1

class OptionalKw(enum.Enum):
    """An option to ``always`` print some token, or ``as-needed``."""

    Always = 0

    AsNeeded = 1

class OptionalToken(enum.Enum):
    """
    An option to ``always`` print some token, ``never`` print, or print ``on-break`` due to line width limits.
    """

    Never = 0

    Always = 1

    OnBreak = 2

class MultiOrder(enum.Enum):
    """
    Whether to place ``ordered``, or ``nonunique``, first when printing multiplicity ranges.
    """

    Ordered = 0

    Nonunique = 1

class OptionalKwToken(enum.Enum):
    """
    An option to print a non-word ``token``, word ``keyword``, or ``none``.
    """

    Token = 0

    Keyword = 1

    none = 2

class KwToken(enum.Enum):
    """An option to print a non-word ``token``, or word ``keyword``."""

    Token = 0

    Keyword = 1

class MultiPlacement(enum.Enum):
    """
    An option to control multiplicity range placement relative to declaration specializations.
    """

    First = 0

    FirstSpecialization = 1

    Last = 2

class OperatorBreak(enum.Enum):
    """Whether to place operators ``before`` line break, or ``after``."""

    Before = 0

    After = 1

class FloatFormat(enum.Enum):
    """Synthetic float format"""

    none = 0

    Exp = 1

    Prec = 2

class NullFormat(enum.Enum):
    """Whether to print null expressions as ``null``, or ``()``."""

    Null = 0

    Brackets = 1

class FormatPreserved[T]:
    """
    Formatting option that can either be preserved from source, or overridden.
    """

    @property
    def preserve(self) -> bool:
        """
        Controls formatting in majority of cases. Set to ``true`` to preserve
        tokens and keywords as they appear in the source code.
        """

    @preserve.setter
    def preserve(self, arg: bool, /) -> None: ...

    @property
    def fallback(self) -> T:
        """
        Controls ``preserve`` formatting for cases when there is no associated
        source text or ``preserve`` is false.
        """

    @fallback.setter
    def fallback(self, arg: T, /) -> None: ...

    __cpp_name__: str = 'syside::py::PyFormatPreserved'

class SynthOptions:
    """Options for printing synthetic elements."""

    def __init__(self) -> None: ...

    @property
    def literal_real(self) -> FloatFormat:
        """
        How to print synthetic ``LiteralReal`` values:

        - ``none`` - implementation defined, typically fixed format, e.g.
          ``0.024``
        - ``exp`` - printed in exponential notation, e.g. ``2.4e-2``
        - ``prec`` - general format, switching between fixed and exponential
          format depending on the magnitude
        """

    @literal_real.setter
    def literal_real(self, arg: FloatFormat, /) -> None: ...

class BreakOptions:
    """Options for inserting line breaks."""

    def __init__(self) -> None: ...

    @property
    def language(self) -> OptionalKw:
        """
        When to insert line break preceding ``language`` in textual
        representations:

        - ``always``: language is always printed on a new line
        - ``as-needed``: printer tries to fit language on the current line
        """

    @language.setter
    def language(self, arg: OptionalKw, /) -> None: ...

    @property
    def about(self) -> OptionalKw:
        """
        When to insert line break preceding ``about`` in comments:

        - ``always``: about list is always printed on a new line
        - ``as-needed``: printer tries to fit about list on the current line
        """

    @about.setter
    def about(self, arg: OptionalKw, /) -> None: ...

    @property
    def operator(self) -> OperatorBreak:
        """
        Whether to insert line breaks in binary operators:

        - ``after``: operators are placed on the same line as the LHS expression
        - ``before``: operators are placed on the same line as the RHS
          expression
        """

    @operator.setter
    def operator(self, arg: OperatorBreak, /) -> None: ...

    @property
    def force_bodies(self) -> bool:
        """
        Whether to print all children on a new line, even if they otherwise fit
        on the same line.
        """

    @force_bodies.setter
    def force_bodies(self, arg: bool, /) -> None: ...

class WhileLoopParentheses:
    """Options for parenthesizing expressions in while loops."""

    def __init__(self) -> None: ...

    @property
    def condition(self) -> OptionalToken:
        """When to parenthesize condition expression ``while (...)``."""

    @condition.setter
    def condition(self, arg: OptionalToken, /) -> None: ...

    @property
    def until(self) -> OptionalToken:
        """When to parenthesize until expression ``until (...)``."""

    @until.setter
    def until(self, arg: OptionalToken, /) -> None: ...

class MergeOptions:
    """Options for merging consecutive declaration relationships."""

    def __init__(self) -> None: ...

    @property
    def disjoining(self) -> bool:
        """Whether to merge consecutive disjoinings (KerML)."""

    @disjoining.setter
    def disjoining(self, arg: bool, /) -> None: ...

    @property
    def unioning(self) -> bool:
        """Whether to merge consecutive unionings (KerML)."""

    @unioning.setter
    def unioning(self, arg: bool, /) -> None: ...

    @property
    def intersecting(self) -> bool:
        """Whether to merge consecutive intersectings (KerML)."""

    @intersecting.setter
    def intersecting(self, arg: bool, /) -> None: ...

    @property
    def differencing(self) -> bool:
        """Whether to merge consecutive differencings (KerML)."""

    @differencing.setter
    def differencing(self, arg: bool, /) -> None: ...

    @property
    def feature_chaining(self) -> bool:
        """Whether to merge consecutive feature chainings (KerML)."""

    @feature_chaining.setter
    def feature_chaining(self, arg: bool, /) -> None: ...

    @property
    def type_featuring(self) -> bool:
        """Whether to merge consecutive type featurings (KerML)."""

    @type_featuring.setter
    def type_featuring(self, arg: bool, /) -> None: ...

class BinaryEndsFormat:
    """
    Options for binary ends formatting:

    - ``always``: binary ends are printed as binary declaration
    - ``never``: binary ends are printed as nary declaration
    """

    def __init__(self) -> None: ...

    @property
    def allocation(self) -> FormatPreserved[AlwaysNever]:
        """How binary allocation usage ends are formatted."""

    @allocation.setter
    def allocation(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def connector(self) -> FormatPreserved[AlwaysNever]:
        """How binary connector ends are formatted."""

    @connector.setter
    def connector(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def succession(self) -> FormatPreserved[AlwaysNever]:
        """How binary succession ends are formatted."""

    @succession.setter
    def succession(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def connection(self) -> FormatPreserved[AlwaysNever]:
        """How binary connection usage ends are formatted."""

    @connection.setter
    def connection(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def interface(self) -> FormatPreserved[AlwaysNever]:
        """How binary interface usage ends are formatted."""

    @interface.setter
    def interface(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

class RedefinesKeyword:
    """Options for ``redefines`` keyword formatting."""

    def __init__(self) -> None: ...

    @property
    def feature(self) -> FormatPreserved[KwToken]:
        """
        Choose between ``redefines`` and ``:>>`` in feature declarations:

        - ``keyword``: ``redefines`` is printed
        - ``token``: ``:>>`` is printed
        """

    @feature.setter
    def feature(self, arg: FormatPreserved[KwToken], /) -> None: ...

    @property
    def metadata_body(self) -> FormatPreserved[OptionalKwToken]:
        """
        Choose between ``redefines``, ``:>>``, or no token inside metadata
        feature bodies:

        - ``keyword``: ``redefines`` is printed
        - ``token``: ``:>>`` is printed
        - ``none``: nothing is printed
        """

    @metadata_body.setter
    def metadata_body(self, arg: FormatPreserved[OptionalKwToken], /) -> None: ...

class ActionKeyword:
    """
    Options for ``action`` keyword formatting:

    - ``always``: ``action`` is always printed
    - ``as-needed``: ``action`` is only printed when required by the grammar
    """

    def __init__(self) -> None: ...

    @property
    def perform_action(self) -> FormatPreserved[OptionalKw]:
        """When ``action`` keyword is printed in perform action usages."""

    @perform_action.setter
    def perform_action(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def action_node(self) -> FormatPreserved[OptionalKw]:
        """When ``action`` keyword is printed in action nodes."""

    @action_node.setter
    def action_node(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

class OccurrenceKeyword:
    """
    Options for ``occurrence`` keyword formatting:

    - ``always``: ``occurrence`` is always printed
    - ``as-needed``: ``occurrence`` is only printed when required by the
      grammar
    """

    def __init__(self) -> None: ...

    @property
    def occurrence(self) -> FormatPreserved[OptionalKw]:
        """
        When ``occurrence`` keyword is printed in occurrence usages and
        definitions.
        """

    @occurrence.setter
    def occurrence(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def event_occurrence(self) -> FormatPreserved[OptionalKw]:
        """When ``occurrence`` keyword is printed in event occurrence usages."""

    @event_occurrence.setter
    def event_occurrence(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

class FirstKeyword:
    """
    Options for ``first`` keyword formatting:

    - ``always``: ``first`` is always printed if permitted by the grammar
    - ``as-needed``: ``first`` is only printed if required by the grammar
    """

    def __init__(self) -> None: ...

    @property
    def succession(self) -> FormatPreserved[OptionalKw]:
        """When ``first`` keyword is printed in binary successions."""

    @succession.setter
    def succession(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def transition(self) -> FormatPreserved[OptionalKw]:
        """When ``first`` keyword is printed in transition usages."""

    @transition.setter
    def transition(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

class OfKeyword:
    """
    Options for ``of`` keyword formatting:

    - ``always``: ``of`` is always printed
    - ``as-needed``: ``of`` is only printed when required by the grammar
    """

    def __init__(self) -> None: ...

    @property
    def binding_connector(self) -> FormatPreserved[OptionalKw]:
        """When ``of`` keyword is printed in binary binding connectors."""

    @binding_connector.setter
    def binding_connector(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def type_featuring(self) -> FormatPreserved[OptionalKw]:
        """When ``of`` keyword is printed in type featuring members."""

    @type_featuring.setter
    def type_featuring(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

class RefKeyword:
    """
    Options for ``ref`` keyword formatting:

    - ``always``: ``ref`` keyword is always printed
    - ``never``: ``ref`` keyword is never printed
    """

    def __init__(self) -> None: ...

    @property
    def metadata(self) -> FormatPreserved[AlwaysNever]:
        """When ``ref`` keyword is printed in metadata usages."""

    @metadata.setter
    def metadata(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def reference(self) -> FormatPreserved[OptionalKw]:
        """
        When ``ref`` keyword is printed in reference usages:

        - ``always``: ``ref`` keyword is always printed
        - ``as-needed``: ``ref`` keyword is only printed if required by the
          grammar
        """

    @reference.setter
    def reference(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def attribute(self) -> FormatPreserved[AlwaysNever]:
        """When ``ref`` keyword is printed in attribute usages."""

    @attribute.setter
    def attribute(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def event_occurrence(self) -> FormatPreserved[AlwaysNever]:
        """When ``ref`` keyword is printed in event occurrence usages."""

    @event_occurrence.setter
    def event_occurrence(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def port(self) -> FormatPreserved[AlwaysNever]:
        """When ``ref`` keyword is printed in port usages."""

    @port.setter
    def port(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def connection(self) -> FormatPreserved[AlwaysNever]:
        """When ``ref`` keyword is printed in connection usages."""

    @connection.setter
    def connection(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def connector(self) -> FormatPreserved[AlwaysNever]:
        """When ``ref`` keyword is printed in connector as usages."""

    @connector.setter
    def connector(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def exhibit_state(self) -> FormatPreserved[AlwaysNever]:
        """When ``ref`` keyword is printed in exhibit state usages."""

    @exhibit_state.setter
    def exhibit_state(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def include_use_case(self) -> FormatPreserved[AlwaysNever]:
        """When ``ref`` keyword is printed in include use case usages."""

    @include_use_case.setter
    def include_use_case(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def perform_action(self) -> FormatPreserved[AlwaysNever]:
        """When ``ref`` keyword is printed in perform action usages."""

    @perform_action.setter
    def perform_action(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

class FromKeyword:
    """Options for ``from`` keyword formatting."""

    def __init__(self) -> None: ...

    @property
    def dependency(self) -> FormatPreserved[OptionalKw]:
        """When ``from`` keyword is printed in dependencies."""

    @dependency.setter
    def dependency(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def flow(self) -> FormatPreserved[OptionalKw]:
        """When ``from`` keyword is printed in flows (KerML)."""

    @flow.setter
    def flow(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def succession_flow(self) -> FormatPreserved[OptionalKw]:
        """When ``from`` keyword is printed in succession flows (KerML)."""

    @succession_flow.setter
    def succession_flow(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def flow_usage(self) -> FormatPreserved[OptionalKw]:
        """When ``from`` keyword is printed in flow usages."""

    @flow_usage.setter
    def flow_usage(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def succession_flow_usage(self) -> FormatPreserved[OptionalKw]:
        """When ``from`` keyword is printed in succession flow usages."""

    @succession_flow_usage.setter
    def succession_flow_usage(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def connector(self) -> FormatPreserved[OptionalKw]:
        """When ``from`` keyword is printed in binary connectors (KerML)."""

    @connector.setter
    def connector(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

class FeatureKeyword:
    """Options for ``feature`` keyword formatting (KerML)."""

    def __init__(self) -> None: ...

    @property
    def feature(self) -> FormatPreserved[OptionalKw]:
        """
        When ``feature`` keyword is printed in features:

        - ``always``: ``feature`` is always printed
        - ``as-needed``: ``feature`` is printed only when required by the
          grammar
        """

    @feature.setter
    def feature(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def metadata(self) -> FormatPreserved[AlwaysNever]:
        """
        When ``feature`` keyword is printed in metadata features:

        - ``always``: ``feature`` keyword is always printed
        - ``never``: ``feature`` keyword is never printed
        """

    @metadata.setter
    def metadata(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

class SpecializationKeyword:
    """
    Options for ``specialization`` keyword formatting in member
    relationships (KerML).
    """

    def __init__(self) -> None: ...

    @property
    def specialization(self) -> FormatPreserved[OptionalKw]:
        """When ``specialization`` keyword is printed in specialization members."""

    @specialization.setter
    def specialization(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def subclassification(self) -> FormatPreserved[OptionalKw]:
        """
        When ``specialization`` keyword is printed in subclassification members.
        """

    @subclassification.setter
    def subclassification(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def feature_typing(self) -> FormatPreserved[OptionalKw]:
        """When ``specialization`` keyword is printed in feature typing members."""

    @feature_typing.setter
    def feature_typing(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def subsetting(self) -> FormatPreserved[OptionalKw]:
        """When ``specialization`` keyword is printed in subsetting members."""

    @subsetting.setter
    def subsetting(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def redefinition(self) -> FormatPreserved[OptionalKw]:
        """When ``specialization`` keyword is printed in redefinition members."""

    @redefinition.setter
    def redefinition(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

class CommaOptions:
    """Options for trailing comma placement."""

    def __init__(self) -> None: ...

    @property
    def sequence_expression(self) -> OptionalToken:
        """
        When to insert a trailing comma in sequence expressions,
        e.g. ``= (a, b, c);``:

        - ``always``: trailing comma is always inserted
        - ``never``: trailing comma is never inserted
        - ``on-break``: trailing comma is inserted if the expression breaks
        """

    @sequence_expression.setter
    def sequence_expression(self, arg: OptionalToken, /) -> None: ...

class ParenthesesFormat:
    """
    Options for expression parentheses formatting:

    - ``always``: expression is printed with parentheses
    - ``never``: expression is printed without parentheses
    - ``on-break``: expression is printed with parentheses only if it breaks
    """

    def __init__(self) -> None: ...

    @property
    def while_loop(self) -> WhileLoopParentheses:
        """Options for parentheses inside while loops."""

    @while_loop.setter
    def while_loop(self, arg: WhileLoopParentheses, /) -> None: ...

    @property
    def if_(self) -> OptionalToken:
        """
        When to parenthesize condition expression ``if (...)``:

        - ``always``: expression is printed with parentheses
        - ``never``: expression is printed without parentheses
        - ``on-break``: expression is printed with parentheses only if it breaks
        """

    @if_.setter
    def if_(self, arg: OptionalToken, /) -> None: ...

    @property
    def transition_guard(self) -> OptionalToken:
        """
        When to parenthesize condition expression ``if (...)`` in transition
        usages:

        - ``always``: expression is printed with parentheses
        - ``never``: expression is printed without parentheses
        - ``on-break``: expression is printed with parentheses only if it breaks
        """

    @transition_guard.setter
    def transition_guard(self, arg: OptionalToken, /) -> None: ...

    @property
    def filter(self) -> OptionalToken:
        """
        When to parenthesize filter expression ``filter (...)``:

        - ``always``: expression is printed with parentheses
        - ``never``: expression is printed without parentheses
        - ``on-break``: expression is printed with parentheses only if it breaks
        """

    @filter.setter
    def filter(self, arg: OptionalToken, /) -> None: ...

class DeclFormat:
    """Format options for declarations"""

    def __init__(self) -> None: ...

    @property
    def multiplicity_placement(self) -> MultiPlacement:
        """
        Where multiplicity is placed in type declarations:

        - ``first``: multiplicity is printed before any other specializations
        - ``first-specialization``: multiplicity is printed after the first
          specialization
        - ``last``: multiplicity is printed after all specializations
        """

    @multiplicity_placement.setter
    def multiplicity_placement(self, arg: MultiPlacement, /) -> None: ...

    @property
    def merge(self) -> MergeOptions:
        """Options for merging consecutive declaration relationships."""

    @merge.setter
    def merge(self, arg: MergeOptions, /) -> None: ...

    @property
    def ordered_nonunique(self) -> FormatPreserved[MultiOrder]:
        """
        How ``ordered`` and ``nonunique`` are ordered:

        - ``ordered``: ``ordered`` is printed first
        - ``nonunique``: ``nonunique`` is printed first
        """

    @ordered_nonunique.setter
    def ordered_nonunique(self, arg: FormatPreserved[MultiOrder], /) -> None: ...

class KeywordOptions:
    """Options for keyword formatting"""

    def __init__(self) -> None: ...

    @property
    def comment(self) -> FormatPreserved[OptionalKw]:
        """
        When ``comment`` keyword is printed:

        - ``always``: ``comment`` will always be printed
        - ``as-needed``: ``comment`` will only be printed as needed
        """

    @comment.setter
    def comment(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def ref(self) -> RefKeyword:
        """When ``ref`` keyword is printed"""

    @ref.setter
    def ref(self, arg: RefKeyword, /) -> None: ...

    @property
    def specialization(self) -> SpecializationKeyword:
        """
        Options for ``specialization`` keyword formatting member relationships
        (KerML).

        When ``specialization`` keyword is printed:

        - ``always``: ``specialization`` will always be printed.
        - ``as-needed``: ``specialization`` will be printed only if required by
          the grammar
        """

    @specialization.setter
    def specialization(self, arg: SpecializationKeyword, /) -> None: ...

    @property
    def feature(self) -> FeatureKeyword:
        """Options for ``feature`` keyword formatting (KerML)."""

    @feature.setter
    def feature(self, arg: FeatureKeyword, /) -> None: ...

    @property
    def public(self) -> FormatPreserved[AlwaysNever]:
        """
        When ``public`` keyword is printed:

        - ``always``: ``public`` will always be printed
        - ``never``: ``public`` will never be printed
        """

    @public.setter
    def public(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def conjugation(self) -> FormatPreserved[OptionalKw]:
        """
        When ``conjugation`` keyword is printed in conjugation members (KerML):

        - ``always``: ``conjugation`` will always be printed.
        - ``as-needed``: ``conjugation`` will be printed only if required by the
          grammar
        """

    @conjugation.setter
    def conjugation(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def disjoining(self) -> FormatPreserved[OptionalKw]:
        """
        When ``disjoining`` keyword is printed in disjoining members (KerML):

        - ``always``: ``disjoining`` will always be printed.
        - ``as-needed``: ``disjoining`` will be printed only if required by the
          grammar
        """

    @disjoining.setter
    def disjoining(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def inverting(self) -> FormatPreserved[OptionalKw]:
        """
        When ``inverting`` keyword is printed in inverting members (KerML):

        - ``always``: ``inverting`` will always be printed.
        - ``as-needed``: ``inverting`` will be printed only if required by the
          grammar
        """

    @inverting.setter
    def inverting(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def from_(self) -> FromKeyword:
        """
        When ``from`` keyword is printed:

        - ``always``: ``from`` is always printed
        - ``as-needed``: ``from`` is only printed when required by the grammar
        """

    @from_.setter
    def from_(self, arg: FromKeyword, /) -> None: ...

    @property
    def true(self) -> FormatPreserved[AlwaysNever]:
        """
        When ``true`` keyword is printed in invariants:

        - ``never``: ``true`` is never printed
        - ``always``: ``true`` is always printed if invariant is not negated
        """

    @true.setter
    def true(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def metadata(self) -> FormatPreserved[KwToken]:
        """
        Choose between ``metadata`` and ``@`` tokens for metadata features and
        usages:

        - ``keyword``: ``metadata`` is printed
        - ``token``: ``@`` is printed
        """

    @metadata.setter
    def metadata(self, arg: FormatPreserved[KwToken], /) -> None: ...

    @property
    def of(self) -> OfKeyword:
        """
        When ``of`` keyword is printed:

        - ``always``: ``of`` is always printed
        - ``as-needed``: ``of`` is only printed when required by the grammar
        """

    @of.setter
    def of(self, arg: OfKeyword, /) -> None: ...

    @property
    def first(self) -> FirstKeyword:
        """
        When ``first`` keyword is printed:

        - ``always``: ``first`` is always printed if permitted by the grammar
        - ``as-needed``: ``first`` is only printed if required by the grammar
        """

    @first.setter
    def first(self, arg: FirstKeyword, /) -> None: ...

    @property
    def enum(self) -> FormatPreserved[AlwaysNever]:
        """
        When ``enum`` keyword is printed inside enum definitions:

        - ``always``: ``enum`` is always printed
        - ``never``: ``enum`` is never printed
        """

    @enum.setter
    def enum(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def occurrence(self) -> OccurrenceKeyword:
        """
        When ``occurrence`` keyword is printed:

        - ``always``: ``occurrence`` is always printed
        - ``as-needed``: ``occurrence`` is only printed when required by the
          grammar
        """

    @occurrence.setter
    def occurrence(self, arg: OccurrenceKeyword, /) -> None: ...

    @property
    def binding(self) -> FormatPreserved[OptionalKw]:
        """
        When ``binding`` keyword is printed in binding connectors as usages:

        - ``always``: ``binding`` is always printed
        - ``as-needed``: ``binding`` is only printed when required by the
          grammar
        """

    @binding.setter
    def binding(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def succession(self) -> FormatPreserved[OptionalKw]:
        """
        When ``succession`` keyword formatting in successions as usages:

        - ``always``: ``succession`` is always printed
        - ``as-needed``: ``succession`` is only printed when required by the
          grammar
        """

    @succession.setter
    def succession(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def constraint(self) -> FormatPreserved[OptionalKw]:
        """
        When ``constraint`` keyword is printed in assert constraint usages:

        - ``always``: ``constraint`` is always printed
        - ``as-needed``: ``constraint`` is only printed when required by the
          grammar
        """

    @constraint.setter
    def constraint(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def state(self) -> FormatPreserved[OptionalKw]:
        """
        When ``state`` keyword is printed in exhibit state usages:

        - ``always``: ``state`` is always printed
        - ``as-needed``: ``state`` is only printed when required by the grammar
        """

    @state.setter
    def state(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def use_case(self) -> FormatPreserved[OptionalKw]:
        """
        When ``use case`` keyword is printed in include use case usages:

        - ``always``: ``use case`` is always printed
        - ``as-needed``: ``use case`` is only printed when required by the
          grammar
        """

    @use_case.setter
    def use_case(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def action(self) -> ActionKeyword:
        """
        When ``action`` keyword is printed:

        - ``always``: ``action`` is always printed
        - ``as-needed``: ``action`` is only printed when required by the grammar
        """

    @action.setter
    def action(self, arg: ActionKeyword, /) -> None: ...

    @property
    def requirement(self) -> FormatPreserved[OptionalKw]:
        """
        When ``requirement`` keyword is printed in satisfy requirement usages:

        - ``always``: ``requirement`` is always printed
        - ``as-needed``: ``requirement`` is only printed when required by the
          grammar
        """

    @requirement.setter
    def requirement(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def assert_(self) -> FormatPreserved[AlwaysNever]:
        """
        When ``assert`` keyword is printed in satisfy requirement usages:

        - ``always``: ``assert`` is always printed
        - ``never``: ``assert`` is never printed
        """

    @assert_.setter
    def assert_(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def allocation(self) -> FormatPreserved[OptionalKw]:
        """
        When ``allocation`` keyword is printed in allocation usages:

        - ``always``: ``allocation`` is always printed
        - ``as-needed``: ``allocation`` is only printed when required by the
          grammar
        """

    @allocation.setter
    def allocation(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def connection(self) -> FormatPreserved[OptionalKw]:
        """
        When ``connection`` keyword is printed in connection usages:

        - ``always``: ``connection`` is always printed
        - ``as-needed``: ``connection`` is only printed when required by the
          grammar
        """

    @connection.setter
    def connection(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def connect(self) -> FormatPreserved[OptionalKw]:
        """
        When ``connect`` keyword is printed in interface usages:

        - ``always``: ``connect`` is always printed
        - ``as-needed``: ``connect`` is only printed when required by the
          grammar
        """

    @connect.setter
    def connect(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def transition(self) -> FormatPreserved[OptionalKw]:
        """
        When ``transition`` keyword is printed in transition usages:

        - ``always``: ``transition`` is always printed if permitted by the
          grammar
        - ``as-needed``: ``transition`` is only printed if required by the
          grammar
        """

    @transition.setter
    def transition(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def concern(self) -> FormatPreserved[OptionalKw]:
        """
        When ``concern`` keyword is printed in framed concern usages:

        - ``always``: ``concern`` is always printed
        - ``as-needed``: ``concern`` is only printed if required by the grammar
        """

    @concern.setter
    def concern(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def port(self) -> FormatPreserved[AlwaysNever]:
        """
        When ``port`` keyword is printed of default interface ends:

        - ``always``: ``port`` is always printed
        - ``never``: ``port`` is never printed
        """

    @port.setter
    def port(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def null(self) -> FormatPreserved[NullFormat]:
        """
        Option for ``NullExpression`` formatting:

        - ``null``: always formatted as ``null``
        - ``brackets``: always formatted as ``()``
        """

    @null.setter
    def null(self, arg: FormatPreserved[NullFormat], /) -> None: ...

    @property
    def specializes(self) -> FormatPreserved[KwToken]:
        """
        Choose between ``specializes`` and ``:>`` when formatting
        specializations and subclassifications:

        - ``keyword``: ``specializes`` is printed
        - ``token``: ``:>`` is printed
        """

    @specializes.setter
    def specializes(self, arg: FormatPreserved[KwToken], /) -> None: ...

    @property
    def conjugates(self) -> FormatPreserved[KwToken]:
        """
        Choose between ``conjugates`` and ``~`` when formatting conjugations
        (KerML):

        - ``keyword``: ``conjugates`` is printed
        - ``token``: ``~`` is printed
        """

    @conjugates.setter
    def conjugates(self, arg: FormatPreserved[KwToken], /) -> None: ...

    @property
    def subsets(self) -> FormatPreserved[KwToken]:
        """
        Choose between ``subsets`` and ``:>`` when formatting subsettings:

        - ``keyword``: ``subsets`` is printed
        - ``token``: ``:>`` is printed
        """

    @subsets.setter
    def subsets(self, arg: FormatPreserved[KwToken], /) -> None: ...

    @property
    def redefines(self) -> RedefinesKeyword:
        """Options for ``redefines`` keyword formatting."""

    @redefines.setter
    def redefines(self, arg: RedefinesKeyword, /) -> None: ...

    @property
    def references(self) -> FormatPreserved[KwToken]:
        """
        Choose between ``references`` and ``::>`` when formatting reference
        subsettings:

        - ``keyword``: ``references`` is printed
        - ``token``: ``::>`` is printed
        """

    @references.setter
    def references(self, arg: FormatPreserved[KwToken], /) -> None: ...

    @property
    def crosses(self) -> FormatPreserved[KwToken]:
        """
        Choose between ``crosses`` and ``=>`` when formatting cross subsettings:

        - ``keyword``: ``crosses`` is printed
        - ``token``: ``=>`` is printed
        """

    @crosses.setter
    def crosses(self, arg: FormatPreserved[KwToken], /) -> None: ...

    @property
    def typed_by(self) -> FormatPreserved[KwToken]:
        """
        Choose between ``typed by`` and ``:`` when formatting feature typings
        (KerML):

        - ``keyword``: ``typed by`` is printed
        - ``token``: ``:`` is printed
        """

    @typed_by.setter
    def typed_by(self, arg: FormatPreserved[KwToken], /) -> None: ...

    @property
    def defined_by(self) -> FormatPreserved[KwToken]:
        """
        Choose between ``defined by`` and ``:`` when formatting feature typings
        (SysML, use ``typed-by`` for KerML):

        - ``keyword``: ``defined by`` is printed
        - ``token``: ``:`` is printed
        """

    @defined_by.setter
    def defined_by(self, arg: FormatPreserved[KwToken], /) -> None: ...

    @property
    def equals(self) -> FormatPreserved[OptionalKw]:
        """
        When to print ``=`` in feature values:

        - ``as-needed``: ``=`` will only be printed if it is required by the
          grammar
        - ``always``: ``=`` will be always printed when it is acceptable by the
          grammar
        """

    @equals.setter
    def equals(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

class FormatOptions:
    """Formatter options for Syside"""

    def __init__(self) -> None: ...

    @property
    def strip_unnecessary_quotes(self) -> bool:
        """
        Whether to strip quotes from quoted identifiers where possible.

        If true, quotes will be stripped from identifiers that have no
        restricted characters and do not clash with language keywords.
        """

    @strip_unnecessary_quotes.setter
    def strip_unnecessary_quotes(self, arg: bool, /) -> None: ...

    @property
    def trailing_comma(self) -> CommaOptions:
        """Options for trailing comma placement."""

    @trailing_comma.setter
    def trailing_comma(self, arg: CommaOptions, /) -> None: ...

    @property
    def keywords(self) -> KeywordOptions:
        """
        Options for keyword formatting, switching between keywords and tokens,
        or omitting keywords where possible.
        """

    @keywords.setter
    def keywords(self, arg: KeywordOptions, /) -> None: ...

    @property
    def binary(self) -> BinaryEndsFormat:
        """
        Options for binary ends formatting:

        - ``always``: binary ends are printed as binary declaration
        - ``never``: binary ends are printed as nary declaration
        """

    @binary.setter
    def binary(self, arg: BinaryEndsFormat, /) -> None: ...

    @property
    def decl(self) -> DeclFormat:
        """Options for declaration formatting."""

    @decl.setter
    def decl(self, arg: DeclFormat, /) -> None: ...

    @property
    def parentheses(self) -> ParenthesesFormat:
        """
        Options for expression parentheses formatting:

        - ``always``: expression is printed with parentheses
        - ``never``: expression is printed without parentheses
        - ``on-break``: expression is printed with parentheses only if it breaks
        """

    @parentheses.setter
    def parentheses(self, arg: ParenthesesFormat, /) -> None: ...

    @property
    def breaks(self) -> BreakOptions:
        """Options for declarations."""

    @breaks.setter
    def breaks(self, arg: BreakOptions, /) -> None: ...

    @property
    def synth(self) -> SynthOptions:
        """Options for printing synthetic elements."""

    @synth.setter
    def synth(self, arg: SynthOptions, /) -> None: ...

    @property
    def markdown(self) -> bool:
        """
        Whether to treat ``Comment`` and ``Documentation`` bodies as Markdown.

        Markdown will preserve whitespace at the end of the lines since it is
        significant, otherwise it will be trimmed. This does not reformat
        paragraphs.
        """

    @markdown.setter
    def markdown(self, arg: bool, /) -> None: ...

    @property
    def empty_brackets(self) -> FormatPreserved[AlwaysNever]:
        """
        Choose between ``{}`` and ``;`` when formatting empty children blocks:

        - ``always``: empty blocks are always formatted as ``{}``
        - ``never``: empty blocks are always formatted as a trailing ``;``
        """

    @empty_brackets.setter
    def empty_brackets(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    __cpp_name__: str = 'syside::sysml::conf::FormatOptions'

class MultiplicityBoundType(enum.Enum):
    """Type to check multiplicity range bounds expression result against."""

    Integer = 0

    Natural = 1

class DiagnosticSeverity(enum.Enum):
    """Severity of a lint rule."""

    Error = 0

    Warning = 1

    Information = 2

    Hint = 3

    Off = 4

class Lint:
    """Configuration for validations and lints."""

    def __init__(self) -> None: ...

    @property
    def standard_library_package(self) -> DiagnosticSeverity | None:
        """
        Severity to diagnose ``standard-library-package`` with. Disable with
        ``off``.
        """

    @standard_library_package.setter
    def standard_library_package(self, arg: DiagnosticSeverity | None) -> None: ...

    @property
    def multiplicity_range_bound_result_types(self) -> MultiplicityBoundType | None:
        """
        The expected type of multiplicity range bounds expression.

        This defaults to ``integer`` which matches the specification.
        ``natural`` is stricter, aligns more closely with the requirement that
        bounds are never negative, and can be used instead to find places where
        the bound could be negative even if the expression cannot be evaluated
        eagerly.
        """

    @multiplicity_range_bound_result_types.setter
    def multiplicity_range_bound_result_types(self, arg: MultiplicityBoundType | None) -> None: ...

class NameHintPreference(enum.Enum):
    """Hinted name preference"""

    Both = 0

    PreferRegular = 1

    PreferShort = 2

    Shortest = 3

    Longest = 4

    Off = 5

class Toggle(enum.Enum):
    """Toggle option"""

    On = 0

    Off = 1

    Explicit = 2

class ImpliedRedefinitionHints:
    """
    Options for implicit redefinitions.

    .. code:: sysml

       part def A { end ref a; }
       part def B :> A {
           end ref //* :>> a */;
       }
    """

    def __init__(self) -> None: ...

    @property
    def toggle(self) -> Toggle:
        """
        Toggle for all nested options.

        - ``on`` enables the default behaviour
        - ``off`` disables the default behaviour and all nested options
        - ``explicit`` disables the default behaviour. Same as ``on`` if there
          is no default behaviour not covered by nested options.
        """

    @toggle.setter
    def toggle(self, arg: Toggle, /) -> None: ...

    @property
    def end(self) -> bool:
        """
        Whether to show implicit ``end`` redefinitions.

        .. code:: sysml

           part def A { end ref a; }
           part def B :> A {
               end ref //* :>> a */;
           }
        """

    @end.setter
    def end(self, arg: bool, /) -> None: ...

    @property
    def argument(self) -> bool:
        """
        Whether to show implicit directed feature redefinitions.

        .. code:: sysml

           calc def A { in ref a; }
           calc def B :> A {
               in ref //* :>> a */;
           }
        """

    @argument.setter
    def argument(self, arg: bool, /) -> None: ...

class ConstantHint:
    """
    Whether to show the ``constant`` keyword on implicitly constant features
    in SysML.

    .. code:: sysml

       part def P {
           //* constant */ end e;
       }
    """

    def __init__(self) -> None: ...

    @property
    def toggle(self) -> Toggle:
        """
        Toggle for all nested options.

        - ``on`` enables the default behaviour
        - ``off`` disables the default behaviour and all nested options
        - ``explicit`` disables the default behaviour. Same as ``on`` if there
          is no default behaviour not covered by nested options.
        """

    @toggle.setter
    def toggle(self, arg: Toggle, /) -> None: ...

class RefHint:
    """
    Whether to show the ``ref`` keyword on non-composite features in SysML.

    .. code:: sysml

       part def P {
           //* ref */ attribute a;
       }
    """

    def __init__(self) -> None: ...

    @property
    def toggle(self) -> Toggle:
        """
        Toggle for all nested options.

        - ``on`` enables the default behaviour
        - ``off`` disables the default behaviour and all nested options
        - ``explicit`` disables the default behaviour. Same as ``on`` if there
          is no default behaviour not covered by nested options.
        """

    @toggle.setter
    def toggle(self, arg: Toggle, /) -> None: ...

class EffectiveNameHints:
    """Inlay hint options for effective names."""

    def __init__(self) -> None: ...

    @property
    def toggle(self) -> Toggle:
        """
        Toggle for all nested options.

        - ``on`` enables the default behaviour
        - ``off`` disables the default behaviour and all nested options
        - ``explicit`` disables the default behaviour. Same as ``on`` if there
          is no default behaviour not covered by nested options.
        """

    @toggle.setter
    def toggle(self, arg: Toggle, /) -> None: ...

    @property
    def features(self) -> NameHintPreference:
        """
        Name hints on non instantiation expression arguments.

        .. code:: sysml

           attribute def A { attribute <a> b; }
           attribute a : A {
               //* <a> b */ :>> b;
           }
        """

    @features.setter
    def features(self, arg: NameHintPreference, /) -> None: ...

    @property
    def parameters(self) -> NameHintPreference:
        """
        Name hints on positional instantiation expression arguments.

        .. code:: sysml

           attribute def A { attribute <a> b; }
           attribute a = new A(//* <a> b = */ 4);
        """

    @parameters.setter
    def parameters(self, arg: NameHintPreference, /) -> None: ...

class ImpliedHeritageHints:
    """
    Options for implicit specialization hints.

    .. code:: sysml

       attribute x //* :> dataValues */;
    """

    def __init__(self) -> None: ...

    @property
    def toggle(self) -> Toggle:
        """
        Toggle for all nested options.

        - ``on`` enables the default behaviour
        - ``off`` disables the default behaviour and all nested options
        - ``explicit`` disables the default behaviour. Same as ``on`` if there
          is no default behaviour not covered by nested options.
        """

    @toggle.setter
    def toggle(self, arg: Toggle, /) -> None: ...

    @property
    def standard_library(self) -> bool:
        """
        Whether to show implicit subsettings and subclassifications to standard
        library elements.

        .. code:: sysml

           attribute x //* :> dataValues */;
        """

    @standard_library.setter
    def standard_library(self, arg: bool, /) -> None: ...

    @property
    def cross_subsettings(self) -> bool:
        """
        Whether to show implicit cross subsettings. Often, they can contain
        anonymous elements which are controlled by ``anonymous`` option.

        .. code:: sysml

           part def P {
               end x_cross [1] ref <x> //* => y.x_cross */;
               end ref y;
           }
        """

    @cross_subsettings.setter
    def cross_subsettings(self, arg: bool, /) -> None: ...

    @property
    def anonymous(self) -> bool:
        """
        Whether to show implicit specializations to anonymous elements. Note
        that hovers will still show the tooltip for the actual target element.

        .. code:: sysml

           part def A { end ref; }
           part def B :> A {
               end ref //* :>> (anonymous) */;
           }
        """

    @anonymous.setter
    def anonymous(self, arg: bool, /) -> None: ...

    @property
    def redefinitions(self) -> ImpliedRedefinitionHints:
        """
        Options for implicit redefinitions.

        .. code:: sysml

           part def A { end ref a; }
           part def B :> A {
               end ref //* :>> a */;
           }
        """

    @redefinitions.setter
    def redefinitions(self, arg: ImpliedRedefinitionHints, /) -> None: ...

class InlayHints:
    """
    Options for inlay hints.

    SysML models contain extensive implicit state which is hard to track
    manually. Inlay hints display some of this state as a virtual text
    inserted into the code.

    While the hints may be useful, there can be a lot of them. Unlike
    regular text, inlay hints cannot be navigated to via keyboard hence they
    may make source editing harder and more frustrating. To counter this,
    this table contains fine-grained editor-agnostic control over which
    hints are shown, cascading ``toggle`` properties can be used to control
    groups of inlay hints.

    Because inlay hints are a user preference, user-specific configuration
    is the recommended place for configuring them, either globally or
    per-project. See config file discovery for more details.

    Further, Visual Studio Code contains and ``editor.inlayHints.enabled``
    configuration option. It is recommended to set it to ``onUnlessPressed``
    or ``offUnlessPressed`` to have them globally on or off at the press of
    a button. See `Inlay
    Hints <https://code.visualstudio.com/docs/editing/editingevolved#_inlay-hints>`__
    for more details. While not explicitly stated, the default keyboard
    shortcuts for inlay hints are ``Ctrl + Alt`` on Windows and Linux, and
    ``Control + Option`` on macOS.
    """

    def __init__(self) -> None: ...

    @property
    def toggle(self) -> Toggle:
        """
        Toggle for all nested options.

        - ``on`` enables the default behaviour
        - ``off`` disables the default behaviour and all nested options
        - ``explicit`` disables the default behaviour. Same as ``on`` if there
          is no default behaviour not covered by nested options.
        """

    @toggle.setter
    def toggle(self, arg: Toggle, /) -> None: ...

    @property
    def expose_visibility(self) -> bool:
        """
        Whether to show implicit expose visibility (``protected``).

        .. code:: sysml

           view V {
               //* protected */ expose V;
           }
        """

    @expose_visibility.setter
    def expose_visibility(self, arg: bool, /) -> None: ...

    @property
    def membership_import_names(self) -> bool:
        """
        Whether to show the other imported name on membership imports.

        .. code:: sysml

           package <short> long;

           private import //* <short> */ long;
           private import //* < */ short //* > long */;
        """

    @membership_import_names.setter
    def membership_import_names(self, arg: bool, /) -> None: ...

    @property
    def effective_names(self) -> EffectiveNameHints:
        """Inlay hint options for effective names."""

    @effective_names.setter
    def effective_names(self, arg: EffectiveNameHints, /) -> None: ...

    @property
    def ref(self) -> RefHint:
        """
        Whether to show the ``ref`` keyword on non-composite features in SysML.

        .. code:: sysml

           part def P {
               //* ref */ attribute a;
           }
        """

    @ref.setter
    def ref(self, arg: RefHint, /) -> None: ...

    @property
    def constant(self) -> ConstantHint:
        """
        Whether to show the ``constant`` keyword on implicitly constant features
        in SysML.

        .. code:: sysml

           part def P {
               //* constant */ end e;
           }
        """

    @constant.setter
    def constant(self, arg: ConstantHint, /) -> None: ...

    @property
    def implicit_specializations(self) -> ImpliedHeritageHints:
        """
        Options for implicit specialization hints.

        .. code:: sysml

           attribute x //* :> dataValues */;
        """

    @implicit_specializations.setter
    def implicit_specializations(self, arg: ImpliedHeritageHints, /) -> None: ...

class CrashTelemAction(enum.Enum):
    """Action to take on crash in regard to crash reports."""

    Ignore = 0

    Upload = 1

class Edit(enum.Enum):
    """LSP editing scope."""

    All = 0

    External = 1

    Project = 2

class Telemetry:
    """Telemetry options."""

    def __init__(self) -> None: ...

    @property
    def crash_reports(self) -> CrashTelemAction | None:
        """
        Whether Syside should automatically send crash reports back to Sensmetry
        or not.

        When declared in a configuration file, this only takes effect after the
        configuration file is parsed. If you want to ensure consistent
        behaviour, consider passing this through CLI.

        Automatic sending can be disabled by setting this to ``"ignore"``. For
        more information refer to
        `Telemetry <https://docs.sensmetry.com/about/telemetry.html#telemetry>`__.
        """

    @crash_reports.setter
    def crash_reports(self, arg: CrashTelemAction | None) -> None: ...

class Lsp:
    """Syside LSP options."""

    def __init__(self) -> None: ...

    @property
    def completion_limit(self) -> int:
        """
        The maximum number of completions shown in the autocomplete dropdown.

        Setting this to ``0`` will disable any limits. Lower values reduce
        completion latency.
        """

    @completion_limit.setter
    def completion_limit(self, arg: int, /) -> None: ...

    @property
    def edit(self) -> Edit:
        """
        Document tiers treated as editable, affecting the renaming feature, and
        diagnostics:

        - ``project`` - allows editing only project files.
        - ``external`` - allows editing project files and external libraries
          except the standard library.
        - ``all`` - allows editing all files, including standard library.
        """

    @edit.setter
    def edit(self, arg: Edit, /) -> None: ...

    @property
    def inlay_hints(self) -> InlayHints:
        """
        Options for inlay hints.

        SysML models contain extensive implicit state which is hard to track
        manually. Inlay hints display some of this state as a virtual text
        inserted into the code.

        While the hints may be useful, there can be a lot of them. Unlike
        regular text, inlay hints cannot be navigated to via keyboard hence they
        may make source editing harder and more frustrating. To counter this,
        this table contains fine-grained editor-agnostic control over which
        hints are shown, cascading ``toggle`` properties can be used to control
        groups of inlay hints.

        Because inlay hints are a user preference, user-specific configuration
        is the recommended place for configuring them, either globally or
        per-project. See config file discovery for more details.

        Further, Visual Studio Code contains and ``editor.inlayHints.enabled``
        configuration option. It is recommended to set it to ``onUnlessPressed``
        or ``offUnlessPressed`` to have them globally on or off at the press of
        a button. See `Inlay
        Hints <https://code.visualstudio.com/docs/editing/editingevolved#_inlay-hints>`__
        for more details. While not explicitly stated, the default keyboard
        shortcuts for inlay hints are ``Ctrl + Alt`` on Windows and Linux, and
        ``Control + Option`` on macOS.
        """

    @inlay_hints.setter
    def inlay_hints(self, arg: InlayHints, /) -> None: ...

class Format(FormatOptions):
    """Formatter options for Syside"""

    def __init__(self) -> None: ...

    @property
    def line_width(self) -> int:
        """
        Formatter visual line-width limit.

        Formatter will attempt to fit formatted lines into this number of visual
        columns.
        """

    @line_width.setter
    def line_width(self, arg: int, /) -> None: ...

    @property
    def tab_width(self) -> int | None:
        """
        Number of spaces for tabs if using space indentation.

        Takes priority over editor settings if set. Defaults to ``4`` otherwise.
        """

    @tab_width.setter
    def tab_width(self, arg: int | None) -> None: ...

    @property
    def tabs(self) -> bool | None:
        """
        Indent using tabs instead of spaces.

        Takes priority over editor settings if set. Defaults to ``false``
        otherwise.
        """

    @tabs.setter
    def tabs(self, arg: bool | None) -> None: ...

class Config:
    r"""
    Syside configuration using TOML 1.0. See `TOML
    page <https://toml.io/en/>`__ for more details.

    Example:

    .. code:: toml

       #:schema https://docs.sensmetry.com/schemas/latest/syside.schema.json

       std = "path/to/sysml.library"
       include = []
       exclude = ["lib", "out", "dist"]

       [lsp]
       completion-limit = 256
       edit = "all"

       [telemetry]
       crash-reports = "ignore"

       [format]
       line-width = 100
       tab-width = 4
       tabs = false

       [format.keywords.null]
       fallback = "null"
       preserve = false

       [lint]
       standard-library-package = "warning"

    Glob Patterns
    -------------

    Some configuration options support the following
    `glob <https://en.wikipedia.org/wiki/Glob_(programming)>`__ patterns.

    - ``*`` - Matches zero or more characters in a path segment. E.g.
      ``*.sysml`` matches all files that end with ``.sysml``.
    - ``?`` - Matches one character in a path segment. E.g. ``?at`` will
      match ``cat`` and ``bat``, but not ``chat``.
    - ``**`` - Matches any number of path segments, including none. E.g.
      ``/x/**/y`` could match ``/x/y``, ``/x/a/y``, ``/x/a/b/y``.
    - ``{...}`` - Groups conditions. E.g. ``*.{ker,sys}ml`` to match both
      KerML and SysML files (the default behaviour).
    - ``[...]`` - Declares a set or range of characters to match in a path
      segment. E.g. ``example[0-9]`` matches files ``example0``,
      ``example1``.
    - ``[!...]`` - Declares a negation set or range of characters. E.g.
      ``example[!0-9]`` will not match ``example1``, but will match
      ``exampleA``.
    - ``[^...]`` - Same as ``[!...]`` to match Unix ``bash`` behaviour.

    .. container:: {attention}

       Glob patterns use ``\`` to escape characters thus it cannot be used
       as a directory separator on Windows. Please use ``/`` to separate
       directories which works on all platforms. Additionally, patterns
       starting with ``/`` are treated as absolute on all platforms.
    """

    def __init__(self) -> None: ...

    @property
    def std(self) -> str | None:
        """
        Path to the standard SysML library, e.g. ``sysml.library``.

        If this is not set, Syside uses a bundled compatible standard library.
        This setting can be used to experiment with different SysML
        specification versions or to use a customised SysML library. Keep in
        mind that using standard libraries other than the bundled one can result
        in spurious and false-positive diagnostics.
        """

    @std.setter
    def std(self, arg: str | None) -> None: ...

    @property
    def include(self) -> list[str] | None:
        """
        Additional files and/or directories to include in the workspace.

        This is useful for including external libraries in a project. Note that
        validation is **not** performed for files included this way, and that by
        default Syside ignores hidden files and directories (denoted by the
        leading ``.`` character), and thus this setting would need to be used to
        include them. This setting supports glob patterns. Relative paths and
        patterns are resolved relative to the directory where they were
        declared:

        - Current working directory when provided as a CLI argument;
        - Directory of the configuration file if declared in one.
        """

    @include.setter
    def include(self, arg: Sequence[str] | None) -> None: ...

    @property
    def exclude(self) -> list[str] | None:
        """
        Files and/or directories to be omitted from automatic discovery,
        parsing, and analysis.

        Unlike other options, ``exclude`` values are merged from inherited
        configs instead of being overwritten.

        This can be used to exclude folders containing automatically generated
        files, e.g. ``build`` folder, from the current workspace. It can also be
        used in large workspaces to improve startup times by disabling large
        directories. Note that exclusions are applied before deciding whether a
        file should be parsed or a directory recursed into but after resolving
        the root directories from ``include`` items, so directory in both
        ``include`` and ``exclude`` will be searched non-recursively. This
        setting supports glob patterns. Relative paths and patterns are resolved
        relative to the directory that is being searched, matching
        ``.gitignore`` behaviour.
        """

    @exclude.setter
    def exclude(self, arg: Sequence[str] | None) -> None: ...

    @property
    def lint(self) -> Lint:
        """Configuration for validations and lints."""

    @lint.setter
    def lint(self, arg: Lint, /) -> None: ...

    @property
    def lsp(self) -> Lsp:
        """LSP configuration."""

    @lsp.setter
    def lsp(self, arg: Lsp, /) -> None: ...

    @property
    def telemetry(self) -> Telemetry:
        """Telemetry configuration."""

    @telemetry.setter
    def telemetry(self, arg: Telemetry, /) -> None: ...

    @property
    def format(self) -> Format:
        """Formatter configuration."""

    @format.setter
    def format(self, arg: Format, /) -> None: ...

def load_config(arg: str | os.PathLike[AnyStr], /) -> Config:
    """
    Load ``Config`` from the given ``path``.

    Raises ``FileNotFoundError`` if there is no such file.
    Raises ``RuntimeError`` if parsing fails otherwise.
    """
