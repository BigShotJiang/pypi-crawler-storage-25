"""Structured access to Syside version"""

import datetime


major: int = 0
"""Major version of Syside"""

minor: int = 9
"""Minor version of Syside"""

patch: int = 0
"""Patch version of Syside"""

sha: str = 'e6870fdbbc49c83025cf45516ebea6e27cfc3117'
"""Commit hash Syside was built from"""

timestamp: str = '2026-05-08T14:37:53Z'
"""Timestamp of when Syside was built"""

def date() -> datetime.datetime:
    """Datetime of when Syside was built"""
