"""
Submodule for generating SysML visualizations.

Note that this any features in this module are still in very
early stages and subject to change. Features will be extended
and more implemented in future versions.

Currently implemented:

- hierarchical nodes and edges
- binary edges
- n-ary edges
- metadata prefixes
- annotating elements
- DOT nested and interconnection diagrams
- edges from ``Types``, e.g. ``Connections``, ``Flows``
- rendering common ``Type`` declarations, including heritage, and feature values

To be implemented:

- rendering type-specific declarations, e.g. connectors
- inserting cross-referenced elements
- inserting and modifying nodes and edges manually
- more rendered graph types
- more render targets
- embedded hyperlinks
- semantically highlighted SysML text
- styling
- layouting
"""

from collections.abc import Callable, Iterable, Iterator
import enum
from typing import overload

from . import dot as dot
from .... import core


class NodeID(enum.IntFlag):
    """Typed node identifier within a graph."""

    def __str__(self) -> str: ...

    def __repr__(self) -> str: ...

    Max = 4294967295
    """Maximum representable ID value. Not intended for direct use."""

    @property
    def entity(self) -> int:
        """Entity index component of this ID (without version bits)."""

    @property
    def version(self) -> int:
        """Version component of this ID."""

class EdgeID(enum.IntFlag):
    """Typed edge identifier within a graph."""

    def __str__(self) -> str: ...

    def __repr__(self) -> str: ...

    Max = 4294967295
    """Maximum representable ID value. Not intended for direct use."""

    @property
    def entity(self) -> int:
        """Entity index component of this ID (without version bits)."""

    @property
    def version(self) -> int:
        """Version component of this ID."""

class NodeShape(enum.Enum):
    """
    Shape used when rendering a node.

    Shapes correspond to graphviz `node shapes <https://graphviz.org/doc/info/shapes.html>`__
    where applicable.
    """

    Package = 0
    """Package tab shape."""

    Note = 1
    """Note shape."""

    Box = 2
    """Rectangular box."""

    RoundedBox = 3
    """Rounded rectangle."""

    Circle = 4
    """Filled circle (start node)."""

    DCircle = 5
    """Double circle (end node)."""

    XOCircle = 6
    """Circle with X (terminate node)."""

    ODiamond = 7
    """Open diamond (decision/merge node)."""

    Bar = 8
    """Filled bar (fork/join node)."""

class ArrowStyle(enum.Enum):
    """
    Arrow head/tail style for edges.

    Styles are partly based on graphviz
    `arrow shapes <https://graphviz.org/docs/attr-types/arrowType/>`__.
    """

    none = 0
    """No arrow."""

    Normal = 1
    """Filled triangular arrow."""

    ONormal = 2
    """Open triangular arrow."""

    ONormalDots = 3
    """Open triangular arrow followed by dots."""

    ONormalDDots = 4
    """Open triangular arrow followed by two rows of dots."""

    ONormalTee = 5
    """Open triangular arrow followed by tee."""

    Diamond = 6
    """Filled diamond."""

    ODiamond = 7
    """Open diamond."""

    Vee = 8
    """Unclosed triangular arrow."""

    OVee = 9
    """Open unclosed triangular arrow."""

    ODot = 10
    """Open dot."""

    PlusODot = 11
    """Open dot with overlaid plus."""

    Pacman = 12
    """Filled arc."""

    InvNormal = 13
    """Inverted filled triangular arrow."""

    InvOVee = 14
    """Inverted open unclosed triangular arrow."""

class LineStyle(enum.Enum):
    """
    Line style for edges and node borders.

    Styles are partly based on graphviz
    `style attributes <https://graphviz.org/docs/attr-types/style/>`__.
    """

    Solid = 0
    """Solid line."""

    Dashed = 1
    """Long dashes."""

    DDashed = 2
    """Short dashes."""

    Dotted = 3
    """Dotted line."""

class NodePlacement(enum.Enum):
    """Abstract node placement relative to the enclosing node."""

    Default = 0
    """
    Default placement.

    The actual placement will depend on visualization implementation, and whether
    children are nested or interconnected.
    """

    AdjacentOutside = 1
    """
    Node should be placed outside and adjacent to the parent.

    This is the placement for parameters.
    """

    OnEdge = 2
    """
    Node should be placed on the perimeter of parent node.

    This is the placement for ports.
    """

class NodeStyle:
    """Style attributes for a node."""

    @property
    def shape(self) -> NodeShape:
        """Visual shape for this node."""

    @property
    def lines(self) -> LineStyle:
        """Line style for this node's border."""

    @property
    def placement(self) -> NodePlacement:
        """Placement of this node relative to its parent."""

class EdgeStyle:
    """Style attributes for an edge."""

    @property
    def tail(self) -> ArrowStyle:
        """Head arrow style."""

    @property
    def head(self) -> ArrowStyle:
        """Tail arrow style."""

    @property
    def line(self) -> LineStyle:
        """Line style for this edge."""

class TextAnnotation:
    """Comment or documentation annotation."""

    @property
    def locale(self) -> str:
        """Locale of the annotation or an empty string."""

    @property
    def body(self) -> str:
        """Body text of the annotation."""

    def __eq__(self, arg: object, /) -> bool:
        pass

class Code:
    """Code snippet annotation (textual representation)."""

    @property
    def language(self) -> str:
        """Language of the code snippet."""

    @property
    def body(self) -> str:
        """Body text of the code snippet."""

    def __eq__(self, arg: object, /) -> bool:
        pass

class MetadataAttribute:
    """A metadata annotation attribute"""

    @property
    def short_name(self) -> str | None:
        """Short name of this attribute"""

    @property
    def name(self) -> str | None:
        """Name of this attribute"""

    def format(self, config: core.PrinterConfig = ...) -> str:
        """
        Formatted metadata attribute string including feature value.

        Examples:

        - ``a = 4``

        ``config`` will be used to pretty-print the formatted string.
        """

    def __eq__(self, arg: object, /) -> bool:
        pass

class Metadata(Iterable[MetadataAttribute]):
    """Metadata annotation containing attributes."""

    def __len__(self) -> int: ...

    def __getitem__(self, arg: int, /) -> MetadataAttribute: ...

    def __iter__(self) -> Iterator[MetadataAttribute]: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

class Label:
    """Label for the heading and declaration parts of this node or edge."""

    def heading(self, config: core.PrinterConfig = ...) -> str | None:
        """
        Heading part of this label.

        This part includes relevant keywords, modifiers, and metadata prefixes, all wrapped
        with guillemets.

        Examples:

        - ``«part def»``
        - ``«abstract part def»``
        - ``«#Prefix part def»``

        ``config`` may be used to pretty-print the heading.
        """

    def decl(self, config: core.PrinterConfig = ...) -> str | None:
        """
        Declaration part of this label.

        This part includes anything not otherwise included by the ``heading`` up to the body.

        Examples:

        - ``<p> myPart :> Part``

        ``config`` will be used to pretty-print the heading. Note that not all declaration parts
        are currently implemented.
        """

class Node:
    """
    Proxy to a node in the graph.

    Provides access to the node's attributes and components.
    """

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __str__(self) -> str: ...

    @property
    def id(self) -> NodeID:
        """Typed node ID of this node."""

    @property
    def element(self) -> core.Element | None:
        """
        Source element this node was constructed from.

        This is only provided for convenience as the graph contains all the data needed
        for visualization.
        """

    @property
    def label(self) -> Label:
        """Label parts for this node."""

    def style(self) -> NodeStyle:
        """Structural style of this node."""

    def parent_edge_style(self) -> EdgeStyle | None:
        """
        Structural style of the edge from ``parent`` to this node if any.

        Such edges are always unnamed, implied through the hierarchy, and not required
        in some visualizations. For these reasons, explicit edges are not created,
        and style options are stored together with node options. If no edge from the
        ``parent`` is required, this returns ``None``.
        """

    @property
    def direction(self) -> core.FeatureDirectionKind | None:
        """Feature direction, or ``None`` if not a ``Feature`` or undirected."""

    @property
    def parent(self) -> Node | None:
        """Parent node, or ``None`` for root nodes."""

    def children(self) -> list[Node]:
        """Child nodes."""

    @property
    def annotation(self) -> TextAnnotation | Code | Metadata | None:
        """Annotation contents for note-shaped nodes."""

class Edge:
    """
    Proxy to an edge in the graph.

    Provides access to the edge attributes and components.
    """

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __str__(self) -> str: ...

    @property
    def id(self) -> EdgeID:
        """Typed edge ID for this edge."""

    @property
    def element(self) -> core.Element | None:
        """
        Source SysML element that this edge was created from.

        This is only provided for convenience as the graph contains all the data needed
        for visualization.
        """

    def sources(self) -> list[Node]:
        """Source nodes. Binary edges have exactly one source."""

    def targets(self) -> list[Node]:
        """Target nodes. Binary edges have exactly one target."""

    @property
    def elaboration(self) -> Node | None:
        """
        Node that elaborates this edge if any.

        Additional optional link to an elaboration node, i.e. the node that created this
        edge. This will typically be rendered as a dotted edge connecting the nary edge
        dot and the elaboration node. In this case, no labels are required for the dot
        as they will be contained in the elaboration node.
        """

    @property
    def label(self) -> Label:
        """Label parts for this edge."""

    def style(self) -> EdgeStyle:
        """Structural style of this edge."""

class Nodes:
    """View of all nodes in the graph."""

    def __iter__(self) -> Iterator[Node]:
        """
        Iterate over live entities.

        .. warning::

            Modifying the underlying graph during iteration is undefined behaviour!
        """

    def __getitem__(self, arg: NodeID, /) -> Node: ...

    def __len__(self) -> int: ...

    def __contains__(self, arg: NodeID, /) -> bool: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

class Edges:
    """View of all edges in the graph."""

    def __iter__(self) -> Iterator[Edge]:
        """
        Iterate over live entities.

        .. warning::

            Modifying the underlying graph during iteration is undefined behaviour!
        """

    def __getitem__(self, arg: EdgeID, /) -> Edge: ...

    def __len__(self) -> int: ...

    def __contains__(self, arg: EdgeID, /) -> bool: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

class Graph:
    """
    Data structure for SysML graphs.

    Attributes and methods will be added as internal API stabilizes.
    """

    def __init__(self) -> None: ...

    def clear(self) -> None:
        """
        Clear all nodes and edges.

        Note that node and edge ids will be reused in an unspecified order.
        """

    @property
    def nodes(self) -> Nodes:
        """Nodes in this graph."""

    @property
    def edges(self) -> Edges:
        """Edges in this graph."""

    def roots(self) -> list[Node]:
        """Root nodes (nodes without a parent)."""

    @overload
    def __getitem__(self, arg: NodeID, /) -> Node: ...

    @overload
    def __getitem__(self, arg: EdgeID, /) -> Edge: ...

class TransformationContext:
    """Reusable context for transforming SysML models into graphs."""

    def __init__(self) -> None: ...

def transform_to(graph: Graph, root: core.Namespace, *, context: TransformationContext | None = None) -> None:
    """
    Insert model rooted at ``root`` to ``graph``.

    Note that edges between different root subtrees may not be created.

    If calling this repeatedly, prefer passing in a ``context`` to improve performance.
    """

DEFAULT_PRINTER_CONFIG: core.PrinterConfig = ...

@overload
def traverse_hierarchical(graph: Graph, on_enter: Callable[[Node], bool], on_exit: Callable[[Node], None], on_edge: Callable[[Edge], None]) -> None:
    """
    Depth-first traversal of the graph's node hierarchy.

    Visits all root nodes via DFS, calling ``on_enter`` and ``on_exit`` for each
    node, then emits all edges via ``on_edge``.

    ``on_enter(node)`` returns a bool: ``True`` to descend into the node's
    children, ``False`` to prune the subtree. On ``False``, the pruned node does not
    invoke ``on_exit``.
    """

@overload
def traverse_hierarchical(graph: Graph, on_enter: Callable[[Node], bool], on_exit: Callable[[Node], None], root: NodeID) -> None:
    """
    Depth-first traversal of the graph's node hierarchy from a given root.

    Node traversal follows the same rules as full graph hierarchical traversal, except
    edges are not visited.
    """

def traverse_unordered(graph: Graph, on_node: Callable[[Node], None], on_edge: Callable[[Edge], None]) -> None:
    """Visit all nodes, then all edges in an unspecified order."""
