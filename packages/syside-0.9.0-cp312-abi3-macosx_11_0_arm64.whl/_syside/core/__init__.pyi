"""
Syside
======

**Native Syside module for Python.**

Internally, Syside uses ``snake_case`` for all non-type symbols, e.g. attributes and
functions, whereas the specification and the Pilot implementation both use ``camelCase``
instead. ``snake_case`` was chosen because it integrates far better into Python - 
the programming language that Syside uses.

Additionally, Syside does not use multiple inheritance to implement the standard model
and instead uses sum-types where appropriate (``typing.Union`` in Python). This improves
performance as methods and attributes can be inlined and are not required to be accessed 
through interfaces (no pointer chasing), reduces memory usage as unused members need not 
be stored (e.g. ``Relationship`` interface for ``Associations``), and improves usability 
by allowing more flexible constraints on element types.

Usability is further improved by storing child elements in separate members based on
their position in the textual syntax. This is in comparison to the Pilot implementation,
which only uses two such members, ``ownedRelationship`` and ``ownedRelatedElement``.
Syside implementation allows direct access to most special members without resorting to
filtering every time, improving performance. Moreover, modifying and inserting such
members does not require potentially expensive reshuffling of children arrays.

Lastly, because textual source files may contain syntax errors, all model elements may
return optional elements, even if the corresponding attribute in the specification
expects a non-null element. This also allows elements to be default constructible.

Additional Notes
----------------

-  For performance reasons, elements and their groups are stored as
   specific members in AST nodes based on their position in textual
   syntax which also makes mutation easier. Notably:

   -  ``prefixes`` - group for metadata prefixes, prefixed with ``#`` in
      textual notation
   -  ``heritage`` - type specializations and conjugations
   -  ``type_relationships`` - non-specialization type relationships
      appearing after specialization part, including feature chaining
   -  ``children`` - elements in the children block (in-between brackets
      ``{`` and ``}``) in textual notation, and expression arguments
   -  ``declared_ends``, ``declared_messages`` - end features and messages
      before the children block. In the textual syntax they appear in the same
      position, hence in contrast to similar groups there are additional
      ``try_append`` and ``try_insert`` methods that return ``None`` without
      throwing if modification failed because the slot is already occupied by
      either ends or messages.

-  Due to parser limitations, argument member references are parsed as
   argument members instead. This has little effect on analysis as
   intermediate ``FeatureReferenceExpression`` and ``OwningMembership``
   are excluded from the expression tree.
-  Elements can only be owned nodes in the same document to satisfy tree
   constraints, elements can be referenced by any appropriate element.
   Violating this constraint raises ``ValueError``. Similarly, trying to
   steal ownership also raises ``ValueError``.
-  Relationship ends cannot generally be modified unless they are member
   elements, and only a few allow this dependent on the textual syntax
   (KerML only but there are currently no checks that models constructed
   are actually representable in chosen textual syntax beyond some
   simple checks during printing).

Model Modifications
~~~~~~~~~~~~~~~~~~~

Adding new owned or referenced ``Elements`` to a model can raise:

-  ``TypeError``:

   -  if the relationship type is not allowed by the container/setter as
      this violates internal invariants.
   -  if the element type is not allowed by the container/setter as this
      violates internal invariants.
   -  if the element type is not allowed by the relationship as this
      violates internal invariants.
   -  if the element is owned but the relationship instead only
      references related element to prevent orphan elements.

-  ``ValueError``:

   -  if taking ownership of an element from another document as this
      violates internal invariants.
   -  if stealing ownership of the element as there is no good default
      behaviour on what should happen, remove the element from the model
      first before trying to re-parent it.

-  ``RuntimeError``:

   -  if the parent ``Element`` has been removed from the model. This
      can be fixed by adding the ``Element`` back into the model as an
      owned element.
"""

from collections.abc import Callable, Iterable, Iterator, Sequence
import datetime
import enum
import os
import types
from typing import (
    AnyStr,
    Generic,
    Self,
    TYPE_CHECKING,
    Tuple,
    TypeGuard as _TypeGuard,
    TypeVar,
    Union,
    overload
)
import uuid

from . import (
    cli as cli,
    conf as conf,
    debug as debug,
    experimental as experimental,
    gc as gc,
    ide as ide,
    version as version
)


# pyright reports false positive class var overrides because they are
# mutable and there are no read-only type hints
# pyright: reportIncompatibleVariableOverride=false
# mypy: disable-error-code="assignment"

if TYPE_CHECKING:
    from fractions import Fraction

    type Scalar = int | float | bool | Infinity | str | Element | BoundMetaclass | complex | Fraction
    type Value = Scalar | range | list[Scalar] | None

T = TypeVar("T")
"""Generic type variable"""

U = TypeVar("U", covariant=True)
"""Generic covariant type variable"""

class WriteLocked(Generic[U]):
    """
    A context manager for managing lock acquiry and release.

    This will typically be used as ``with mutex.lock() as data: ...`` to ensure
    that the lock is released at the end of the scope.
    """

    def __enter__(self) -> U: ...

    def __exit__(self, exc_type: type[BaseException] | None, exc: BaseException | None, traceback: types.TracebackType | None) -> None: ...

class SharedMutex(Generic[U]):
    """A mutex-protected data"""

    def lock(self) -> WriteLocked[U]:
        """
        Acquire access to the protected data.

        This returns a context manager that ensures the lock is released at the end
        of the scope:

        .. code-block:: python

            with mutex.lock() as data:
                ...
        """

class Scheme(enum.Enum):
    """A known URL scheme."""

    none = 0
    """Indicates that no scheme is present"""

    Unknown = 1
    """Indicates the scheme is not a well-known scheme"""

    Ftp = 2
    """
    File Transfer Protocol (FTP) 

    FTP is a standard communication protocol used for the transfer of computer files
    from a server to a client on a computer network.
    """

    File = 3
    """
    File URI Scheme

    The File URI Scheme is typically used to retrieve files from within one's own
    computer.
    """

    Http = 4
    """
    The Hypertext Transfer Protocol URI Scheme

    URLs of this type indicate a resource which is interacted with using the HTTP
    protocol.
    """

    Https = 5
    """
    The Secure Hypertext Transfer Protocol URI Scheme

    URLs of this type indicate a resource which is interacted with using the Secure
    HTTP protocol.
    """

    Ws = 6
    """
    The WebSocket URI Scheme

    URLs of this type indicate a resource which is interacted with using the
    WebSocket protocol.
    """

    Wss = 7
    """
    The Secure WebSocket URI Scheme

    URLs of this type indicate a resource which is interacted with using the Secure
    WebSocket protocol.
    """

class HostType(enum.Enum):
    """The type of host in a URL."""

    none = 0
    """No host is specified."""

    Name = 1
    """A host is specified by reg-name."""

    IPv4 = 2
    """A host is specified by ipv4_address."""

    IPv6 = 3
    """A host is specified by ipv6_address."""

    IPvFuture = 4
    """A host is specified by IPvFuture."""

class IPv4Address:
    """An IP version 4 style address."""

    @overload
    def __init__(self) -> None: ...

    @overload
    def __init__(self, arg: int, /) -> None: ...

    @overload
    def __init__(self, arg: Sequence[int], /) -> None: ...

    def to_bytes(self) -> list[int]:
        """Returns the address as bytes, in network byte order."""

    def to_uint(self) -> int:
        """Returns the address as an unsigned integer."""

    def __int__(self) -> int:
        """Returns the address as an unsigned integer."""

    def __deepcopy__(self) -> IPv4Address: ...

    def __copy__(self) -> IPv4Address: ...

    def __str__(self) -> str: ...

    def __repr__(self) -> str: ...

    @property
    def is_loopback(self) -> bool:
        """Returns true if the address is a loopback address"""

    @property
    def is_unspecified(self) -> bool:
        """Returns true if the address is unspecified"""

    @property
    def is_multicast(self) -> bool:
        """Returns true if the address is a multicast address"""

    @staticmethod
    def any() -> IPv4Address:
        """Returns an address object that represents any address"""

    @staticmethod
    def loopback() -> IPv4Address:
        """Returns an address object that represents the loopback address"""

    @staticmethod
    def broadcast() -> IPv4Address:
        """Returns an address object that represents the broadcast address"""

class IPv6Address:
    """An IP version 6 style address."""

    @overload
    def __init__(self) -> None: ...

    @overload
    def __init__(self, arg: Sequence[int], /) -> None: ...

    @overload
    def __init__(self, arg: str, /) -> None: ...

    def to_bytes(self) -> list[int]:
        """Returns the address as bytes, in network byte order"""

    def __deepcopy__(self) -> IPv6Address: ...

    def __copy__(self) -> IPv6Address: ...

    def __str__(self) -> str: ...

    def __repr__(self) -> str: ...

    @property
    def is_loopback(self) -> bool:
        """Returns true if the address is a loopback address"""

    @property
    def is_unspecified(self) -> bool:
        """Returns true if the address is unspecified"""

    @property
    def is_v4_mapped(self) -> bool:
        """Returns true if the address is a mapped IPv4 address"""

    @staticmethod
    def loopback() -> IPv6Address:
        """Returns an address object that represents the loopback address"""

class EncodingOpts:
    """
    Percent-encoding options

    These options are used to customize the behavior of algorithms which use percent
    escapes, such as encoding or decoding.
    """

    def __init__(self, space_as_plus: bool = False, lower_case: bool = False, disallow_null: bool = False) -> None: ...

    @property
    def space_as_plus(self) -> bool:
        """
        True if spaces encode to and from plus signs

        This option controls whether or not the PLUS character ("+") is used to
        represent the SP character (" ") when encoding or decoding. Although not
        prescribed by the RFC, plus signs are commonly treated as spaces upon decoding
        when used in the query of URLs using well known schemes such as HTTP.
        """

    @space_as_plus.setter
    def space_as_plus(self, arg: bool, /) -> None: ...

    @property
    def lower_case(self) -> bool:
        """
        True if hexadecimal digits are emitted as lower case

        By default, percent-encoding algorithms emit hexadecimal digits A through F as
        uppercase letters. When this option is ``true``, lowercase letters are used.
        """

    @lower_case.setter
    def lower_case(self, arg: bool, /) -> None: ...

    @property
    def disallow_null(self) -> bool:
        """
        True if nulls are not allowed

        Normally all possible character values (from 0 to 255) are allowed, with
        reserved characters being replaced with escapes upon encoding. When this option
        is true, attempting to decode a null will result in an error.
        """

    @disallow_null.setter
    def disallow_null(self, arg: bool, /) -> None: ...

class Url:
    """
    ``URL`` as described using the `Uniform Resource Identifier (URI) <https://datatracker.ietf.org/doc/html/rfc3986>`__ specification (RFC3986).

    Raises ``RuntimeError`` on invalid URLs, including those with unicode characters.
    Unicode characters must be percent escaped by encoding them as hex with ``%``
    escape. Url components are accessible both as encoded and decoded strings.

    Encoded strings use ``.encoded`` properties and returns strings exactly as they
    appear in the URL. Setting components to escaped strings via ``.set_encoded`` methods
    preserve the escapes while still percent-escaping reserved characters in the result.

    Otherwise properties and methods operate on decoded strings. Retrieving a decoded
    string unescapes percent-encoded octects with the corresponding characters. Setting
    component values to unescaped strings will percent-escape any reserved characters
    in the result.

    Note that an empty component is distinct from no component, however getters will
    return empty strings for missing components.

    Documentation is based on
    `Boost.URL <https://www.boost.org/doc/libs/latest/doc/antora/url/index.html>`__.

    Normalization
    -------------

    URL can be normalized using any of the ``.normalize`` methods:

    * ``scheme`` is normalized to lowercase
    * other components have percent-encoding triplets normalized to uppercase.
      Percent-encoded octects that correspond to unreserved characters are decoded.

    See `Specification <https://datatracker.ietf.org/doc/html/rfc3986#section-6.2.2>`__ for
    more details.
    """

    @overload
    def __init__(self) -> None: ...

    @overload
    def __init__(self, arg: str, /) -> None: ...

    def __deepcopy__(self) -> Url: ...

    def __copy__(self) -> Url: ...

    def __str__(self) -> str: ...

    def __repr__(self) -> str: ...

    def clear(self) -> None:
        """Clear the contents while preserving the capacity"""

    def reserve(self, arg: int, /) -> None:
        """Adjust the capacity without changing the size"""

    def __len__(self) -> int:
        """Returns the number of characters in the url"""

    def __bool__(self) -> bool:
        """Returns true if the url is not empty"""

    @property
    def has_scheme(self) -> bool:
        """Returns true if a scheme is present"""

    @property
    def scheme(self) -> str:
        """Returns the scheme"""

    @property
    def scheme_id(self) -> Scheme:
        """
        Return the scheme

        This returns a value which depends on the scheme in the url:

        * If the scheme is a well-known scheme, corresponding value from the enumeration ``Scheme`` is returned.
        * If a scheme is present but is not a well-known scheme, the value returned is ``Scheme.Unknown``.
        * Otherwise, the value returned is ``Scheme.none``.
        """

    @property
    def has_authority(self) -> bool:
        """
        Return true if an authority is present

        This returns true if the url contains an authority.
        The presence of an authority is denoted by a double slash ("//") at the beginning or after the scheme.
        """

    @property
    def authority(self) -> str:
        """Return the authority"""

    @property
    def encoded_authority(self) -> str:
        """Return the authority."""

    @property
    def has_userinfo(self) -> bool:
        """Return true if a userinfo is present"""

    @property
    def has_password(self) -> bool:
        """
        Return true if a password is present

        This returns true if the userinfo is present and contains a password.
        """

    @property
    def userinfo(self) -> str:
        """Return the userinfo"""

    @property
    def encoded_userinfo(self) -> str:
        """Return the userinfo"""

    @property
    def user(self) -> str:
        """Return the user"""

    @property
    def encoded_user(self) -> str:
        """Return the user"""

    @property
    def password(self) -> str:
        """Return the password"""

    @property
    def encoded_password(self) -> str:
        """
        Return the password

        This returns the password portion of the userinfo as a percent-encoded string.
        """

    @property
    def host_type(self) -> HostType:
        """
        Return the host type

        This returns one of the following constants representing the type of host present.

        * ``HostType.IPv4``
        * ``HostType.IPv6``
        * ``HostType.IPvFuture``
        * ``HostType.Name``
        * ``HostType.none``

        When ``has_authority`` is false, the host type is ``HostType.none``.
        """

    @property
    def host(self) -> str:
        """Return the host"""

    @property
    def encoded_host(self) -> str:
        """Return the host"""

    @property
    def host_address(self) -> str:
        """Return the host"""

    @property
    def encoded_host_address(self) -> str:
        """Return the host"""

    @property
    def host_ipv4_address(self) -> IPv4Address:
        """
        Return the host IPv4 address

        If the host type is ``IPv4``, this returns the address.
        Otherwise, returns a default-constructed value which is equal to the unspecified address "0.0.0.0".
        """

    @property
    def host_ipv6_address(self) -> IPv6Address:
        """
        Return the host IPv6 address

        If the host type is ``IPv6``, this returns the address.
        Otherwise, returns a default-constructed value which is equal to the unspecified address "0:0:0:0:0:0:0:0".
        """

    @property
    def host_ipvfuture(self) -> str:
        """
        Return the host IPvFuture address

        If the host type is ``IPvFuture``, this returns the address as a string.
        Otherwise, returns an empty string.
        """

    @property
    def host_name(self) -> str:
        """
        Return the host name

        If the host type is ``Name``, this returns the name as a string.
        Otherwise, returns an empty string.
        """

    @property
    def encoded_host_name(self) -> str:
        """
        Return the host name

        If the host type is ``Name``, this  returns the name as a string.
        Otherwise, returns an empty string.
        """

    @property
    def zone_id(self) -> str:
        """
        Return the IPv6 Zone ID

        If the host type is ``IPv6``, this returns the Zone ID as a string.
        Otherwise an empty string is returned.
        """

    @property
    def encoded_zone_id(self) -> str:
        """
        Return the IPv6 Zone ID

        If the host type is ``IPv6``, this returns the Zone ID as a string.
        Otherwise an empty string is returned.
        """

    @property
    def has_port(self) -> bool:
        """
        Return true if a port is present

        This returns true if an authority is present and contains a port.
        """

    @property
    def port(self) -> str:
        """Return the port"""

    @property
    def port_number(self) -> int:
        """
        Return the port

        If a port is present and the numerical value is representable, it is returned
        as an unsigned integer. Otherwise, the number zero is returned.
        """

    @property
    def is_path_absolute(self) -> bool:
        """
        Return true if the path is absolute

        This returns true if the path begins with a forward slash ('/')
        """

    @property
    def path(self) -> str:
        """Return the path"""

    @property
    def encoded_path(self) -> str:
        """Return the path"""

    @property
    def has_query(self) -> bool:
        """
        Return true if a query is present

        This returns true if this contains a query.
        """

    @property
    def query(self) -> str:
        """
        Return the query

        When plus signs appear in the query portion of the url, they are converted to spaces automatically upon decoding.
        """

    @property
    def encoded_query(self) -> str:
        """Return the query"""

    def params(self, options: EncodingOpts = ...) -> list[tuple[str, str | None]]:
        """
        Return the query as a sequence of parameters

        This function returns a bidirectional sequence of key/value pairs over the query.
        Any percent-escapes in strings returned when iterating the view are decoded first.
        Changes to the container are not reflected in the underlying URL.
        """

    @property
    def encoded_params(self) -> list[tuple[str, str | None]]:
        """
        Return the query as a sequence of parameters

        This returns a bidirectional sequence of key/value pairs over the query.
        Strings returned when iterating the range may contain percent escapes.
        Changes to the container are not reflected in the underlying URL.
        """

    @property
    def has_fragment(self) -> bool:
        """Return true if a fragment is present"""

    @property
    def fragment(self) -> str:
        """
        Return the fragment

        This calculates the fragment of the url, with percent escapes decoded and
        without the leading pound sign ('#') whose presence indicates that the url contains a fragment.
        """

    @property
    def encoded_fragment(self) -> str:
        """Return the fragment"""

    @property
    def encoded_host_and_port(self) -> str:
        """
        Return the host and port

        If an authority is present, this returns the host and optional port as a string, which may be empty.
        Otherwise it returns an empty string.
        """

    @property
    def encoded_origin(self) -> str:
        """
        Return the origin

        If an authority is present, this returns the scheme and authority portion of the url.
        Otherwise, an empty string is returned.
        """

    @property
    def encoded_resource(self) -> str:
        """
        Return the resource

        This returns the resource, which is the portion of the url that includes only the path, query, and fragment.
        """

    @property
    def encoded_target(self) -> str:
        """
        Return the target

        This returns the target, which is the portion of the url that includes only the path and query.
        """

    def set_scheme(self, arg: str, /) -> Url:
        """
        Set the scheme

        The scheme is set to the specified string, which must contain a valid scheme without any trailing colon (':').
        Note that schemes are case-insensitive,
        and the canonical form is lowercased.
        """

    def set_scheme_id(self, arg: Scheme, /) -> Url:
        """
        Set the scheme

        This function sets the scheme to the specified known scheme id, which may not be
        ``Unknown`` or else an error is raide. If the id is ``none``, this function behaves as if ``remove_scheme`` were called.
        """

    def remove_scheme(self) -> Url:
        """Remove the scheme"""

    def set_encoded_authority(self, arg: str, /) -> Url:
        """Set the authority"""

    def remove_authority(self) -> Url:
        """
        Remove the authority

        This function removes the authority, which includes the userinfo, host, and a port if present.
        """

    def set_userinfo(self, arg: str, /) -> Url:
        """
        Set the userinfo

        The effects on the user and password depend on the presence of a colon (':') in the string:

        * If an unescaped colon exists, the characters up to the colon become the user and the rest of the characters after the colon become the password.
          In this case ``has_password`` returns true. Otherwise,
        * If there is no colon, the user is set to the string. ``has_password`` returns false.

        .. note::

            The interpretation of the userinfo as individual user and password components is scheme-dependent.
            Transmitting passwords in URLs is deprecated.
        """

    def set_encoded_userinfo(self, arg: str, /) -> Url:
        """
        Set the userinfo.

        The effects on the user and password depend on the presence of a colon (':') in the string:

        * If an unescaped colon exists, the characters up to the colon become the user and the rest of the characters after the colon become the password.
          In this case ``has_password`` returns true. Otherwise,
        * If there is no colon, the user is set to the string. ``has_password`` returns false.

        .. note::

            The interpretation of the userinfo as individual user and password components is scheme-dependent.
            Transmitting passwords in URLs is deprecated.
        """

    def remove_userinfo(self) -> Url:
        """Remove the userinfo if present, without removing any authority."""

    def set_user(self, arg: str, /) -> Url:
        """Set the user"""

    def set_encoded_user(self, arg: str, /) -> Url:
        """Set the user"""

    def set_password(self, arg: str, /) -> Url:
        """
        Set the password.

        .. note::

            The interpretation of the userinfo as individual user and password components is scheme-dependent.
            Transmitting passwords in URLs is deprecated.
        """

    def set_encoded_password(self, arg: str, /) -> Url:
        """
        Set the password.

        .. note::

            The interpretation of the userinfo as individual user and password components is scheme-dependent.
            Transmitting passwords in URLs is deprecated.
        """

    def remove_password(self) -> Url:
        """
        Remove the password

        This function removes the password from the userinfo if a password exists. If there is no userinfo or no authority,
        the call has no effect.

        .. note::

            The interpretation of the userinfo as individual user and password components is scheme-dependent.
            Transmitting passwords in URLs is deprecated.
        """

    def set_host(self, arg: str, /) -> Url:
        """
        Set the host

        Depending on the contents of the passed string, this function sets the host:

        * If the string is a valid IPv4 address, then the host is set to the address.
        * If the string is a valid IPv6 address enclosed in square brackets, then the host is set to that address.
        * If the string is a valid IPvFuture address enclosed in square brackets, then the host is set to that address.
        * Otherwise, the host name is set to the string, which may be empty.

        In all cases, when this function returns, the URL contains an authority.
        """

    def set_encoded_host(self, arg: str, /) -> Url:
        """
        Set the host

        Depending on the contents of the passed string, this function sets the host:

        * If the string is a valid IPv4 address, then the host is set to the address.
        * If the string is a valid IPv6 address enclosed in square brackets, then the host is set to that address.
        * If the string is a valid IPvFuture address enclosed in square brackets, then the host is set to that address.
        * Otherwise, the host name is set to the string.

        In all cases, when this function returns, the URL contains an authority.
        """

    def set_host_address(self, arg: str, /) -> Url:
        """
        Set the host to an address

        Depending on the contents of the passed string, this function sets the host:

        * If the string is a valid IPv4 address, then the host is set to the address.
        * If the string is a valid IPv6 address, then the host is set to that address.
        * If the string is a valid IPvFuture, then the host is set to that address.
        * Otherwise, the host name is set to the string.

        In all cases, when this function returns, the URL contains an authority.
        """

    def set_encoded_host_address(self, arg: str, /) -> Url:
        """
        Set the host to an address

        Depending on the contents of the passed string, this function sets the host:

        * If the string is a valid IPv4 address, then the host is set to the address.
        * If the string is a valid IPv6 address, then the host is set to that address.
        * If the string is a valid IPvFuture, then the host is set to that address.
        * Otherwise, the host name is set to the string.

        In all cases, when this function returns, the URL contains an authority.
        """

    def set_host_ipv4(self, arg: IPv4Address, /) -> Url:
        """
        Set the host to an address

        The host is set to the specified IPv4 address.
        """

    def set_host_ipv6(self, arg: IPv6Address, /) -> Url:
        """
        Set the host to an address

        The host is set to the specified IPv6 address.
        """

    def set_host_ipvfuture(self, arg: str, /) -> Url:
        """
        Set the host to an address

        The host is set to the specified IPvFuture string.
        """

    def set_host_name(self, arg: str, /) -> Url:
        """Set the host to a name"""

    def set_encoded_host_name(self, arg: str, /) -> Url:
        """Set the host to a name"""

    def set_port_number(self, arg: int, /) -> Url:
        """
        Set the port

        The port is set to the specified integer.
        """

    def set_port(self, arg: str, /) -> Url:
        """
        Set the port

        This port is set to the string, which must contain only digits or be empty.
        """

    def remove_port(self) -> Url:
        """Remove the port without affecting the rest of the authority"""

    def set_path(self, arg: str, /) -> Url:
        """
        Set the path.

        .. note::

            The library may adjust the final result to ensure that no other parts of
            the url are semantically affected.

        .. note::

            This function does not encode '/' chars, which are unreserved for paths
            but reserved for path segments. If a path segment should include encoded
            '/'s to differentiate it from path separators, the function
            ``set_encoded_path`` should be used instead.
        """

    def set_encoded_path(self, arg: str, /) -> Url:
        """Set the path."""

    def set_query(self, arg: str, /) -> Url:
        """Set the query"""

    def set_encoded_query(self, arg: str, /) -> Url:
        """Set the query"""

    def remove_query(self) -> Url:
        """Remove the query"""

    def remove_fragment(self) -> Url:
        """Remove the fragment"""

    def set_fragment(self, arg: str, /) -> Url:
        """Set the fragment."""

    def set_encoded_fragment(self, arg: str, /) -> Url:
        """Set the fragment."""

    def remove_origin(self) -> Url:
        """Removes the origin (scheme and authority)"""

    def normalize(self) -> Url:
        """Normalize all URL components"""

    def normalize_scheme(self) -> Url:
        """Normalize the URL scheme to lowercase"""

    def normalize_authority(self) -> Url:
        """Normalize the URL authority"""

    def normalize_path(self) -> Url:
        """Normalize the URL path"""

    def normalize_query(self) -> Url:
        """Normalize the URL query"""

    def normalize_fragment(self) -> Url:
        """Normalize the URL fragment"""

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __hash__(self) -> int: ...

    __cpp_name__: str = 'boost::urls::url'

@overload
def make_file_url(arg0: str, options: EncodingOpts = ...) -> Url:
    """
    Construct a ``Url`` for a filesystem path with the ``file:`` scheme. 

    This correctly handles Windows and Posix paths, normalizes Windows drive letters
    to uppercase, and percent escapes Unicode characters.
    """

@overload
def make_file_url(arg0: str | os.PathLike[AnyStr], options: EncodingOpts = ...) -> Url: ...

def decode_path(arg0: Url, options: EncodingOpts = ...) -> str:
    """
    Decode a filesystem path from a ``Url``.

    This correctly handles Windows and Posix paths using ``file://`` scheme and
    returns other ``Urls`` as is.
    """

class BuildState(enum.IntEnum):
    """Document build state"""

    none = 0
    """Document has only been created"""

    Changed = 1
    """Document content has changed"""

    Parsed = 2
    """Document content was parsed"""

    Indexed = 3
    """Document global and local exports have been indexed"""

    Built = 4
    """Model has been built and linked"""

    Validated = 5
    """Model has been validated"""

class DocumentState(enum.IntEnum):
    """The state of a document inside of a pipeline."""

    Created = 0
    """Document has been created"""

    Building = 1
    """Document is being built"""

    Completed = 2
    """Document was built successfully"""

    Cancelled = 3
    """Document building was cancelled"""

    Error = 4
    """Document building errored"""

class DocumentTier(enum.Enum):
    """
    A document tier.

    This is used internally to apply specific optimizations, mainly to standard library
    sources.
    """

    StandardLibrary = 0
    """
    Document is a part of standard library. Assume that such documents change very rarely, or only change with new tool versions.
    """

    External = 1
    """
    Document is imported from a third-party library. Assume that they do not change unless the third-party library is updated.
    """

    Project = 2
    """
    Document is a part of the current project and may be edited at any time.
    """

class Symbol:
    """Strongly typed CST symbol id"""

    def __init__(self, arg: int, /) -> None: ...

    def __int__(self) -> int: ...

    def __index__(self) -> int: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __hash__(self) -> int: ...

    def __le__(self, arg: object, /) -> bool:
        pass

    def __ge__(self, arg: object, /) -> bool:
        pass

    def __lt__(self, arg: object, /) -> bool:
        pass

    def __gt__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'tree_sitter::Symbol'

class FieldId:
    """Strongly typed CST field id"""

    def __init__(self, arg: int, /) -> None: ...

    def __int__(self) -> int: ...

    def __index__(self) -> int: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __hash__(self) -> int: ...

    def __le__(self, arg: object, /) -> bool:
        pass

    def __ge__(self, arg: object, /) -> bool:
        pass

    def __lt__(self, arg: object, /) -> bool:
        pass

    def __gt__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'tree_sitter::FieldId'

class StateId:
    """Strongly typed CST state id"""

    def __init__(self, arg: int, /) -> None: ...

    def __int__(self) -> int: ...

    def __index__(self) -> int: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __hash__(self) -> int: ...

    def __le__(self, arg: object, /) -> bool:
        pass

    def __ge__(self, arg: object, /) -> bool:
        pass

    def __lt__(self, arg: object, /) -> bool:
        pass

    def __gt__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'tree_sitter::StateId'

class CstNode:
    """A `CST <https://en.wikipedia.org/wiki/Parse_tree>`__ node"""

    @property
    def id(self) -> int:
        """
        Get a numeric id for this node that is unique.

        Within a given syntax tree, no two nodes have the same id. However:

        - If a new tree is created based on an older tree, and a node from the old tree
          is reused in the process, then that node will have the same id in both trees.
        - A node not marked as having changes does not guarantee it was reused.
        - If a node is marked as having changed in the old tree, it will not be reused.
        """

    @property
    def type(self) -> str:
        """Get the node's type as a string."""

    @property
    def symbol(self) -> Symbol:
        """Get the node's type as a numerical id."""

    @property
    def grammar_type(self) -> str:
        """
        Get the node's type as it appears in the grammar ignoring aliases as a null-terminated string.
        """

    @property
    def grammar_symbol(self) -> Symbol:
        """
        Get the node's type as a numerical id as it appears in the grammar ignoring aliases.
        """

    @property
    def start_byte(self) -> int:
        """Get the node's start byte."""

    @property
    def start_point(self) -> PositionUtf8:
        """
        Get the node's start position in terms of rows and columns (Utf-8 based).
        """

    @property
    def end_byte(self) -> int:
        """Get the node's end byte."""

    @property
    def end_point(self) -> PositionUtf8:
        """
        Get the node's end position in terms of rows and columns (Utf-8 based).
        """

    @property
    def string(self) -> str:
        """Get an S-expression representing the node as a string."""

    @property
    def is_named(self) -> bool:
        """
        Check if the node is *named*.

        Named nodes correspond to named rules in the grammar, whereas *anonymous* nodes
        correspond to string literals in the grammar.
        """

    @property
    def is_missing(self) -> bool:
        """
        Check if the node is *missing*.

        Missing nodes are inserted by the parser in order to recover from certain
        kinds of syntax errors.
        """

    @property
    def is_extra(self) -> bool:
        """
        Check if the node is *extra*.

        Extra nodes represent things like comments, which are not required by the
        grammar, but can appear anywhere.
        """

    @property
    def has_changes(self) -> bool:
        """Check if a syntax node has been edited."""

    @property
    def has_error(self) -> bool:
        """Check if the node is a syntax error or contains any syntax errors."""

    @property
    def is_error(self) -> bool:
        """Check if the node is a syntax error."""

    @property
    def parse_state(self) -> StateId:
        """Get this node's parse state."""

    @property
    def next_parse_state(self) -> StateId:
        """Get the parse state after this node."""

    def field_name_for_child(self, arg: int, /) -> str | None:
        """
        Get the field name for node's child at the given index, where zero represents the first child.

        Returns ``None``, if no field is found
        """

    @property
    def child_count(self) -> int:
        """Get the node's number of children."""

    @property
    def named_child_count(self) -> int:
        """Get the node's number of *named* children."""

    @property
    def descendant_count(self) -> int:
        """
        Get the node's number of descendants, including one for the node itself.
        """

    def text(self, arg: str, /) -> str:
        """
        Get the node's source text.

        This requires an explicit source text as it is not stored in the tree otherwise.
        """

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __le__(self, arg: object, /) -> bool:
        pass

    def __ge__(self, arg: object, /) -> bool:
        pass

    def __lt__(self, arg: object, /) -> bool:
        pass

    def __gt__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'tree_sitter::Node'

class PositionUtf8:
    """Utf-8 based text position"""

    def __init__(self, line: int = 0, character: int = 0) -> None: ...

    @property
    def line(self) -> int:
        """Line number"""

    @line.setter
    def line(self, arg: int, /) -> None: ...

    @property
    def character(self) -> int:
        """Character number"""

    @character.setter
    def character(self, arg: int, /) -> None: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __le__(self, arg: object, /) -> bool:
        pass

    def __ge__(self, arg: object, /) -> bool:
        pass

    def __lt__(self, arg: object, /) -> bool:
        pass

    def __gt__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::Position<Utf8Tag>'

class PositionUtf16:
    """Utf-16 based text position"""

    def __init__(self, line: int = 0, character: int = 0) -> None: ...

    @property
    def line(self) -> int:
        """Line number"""

    @line.setter
    def line(self, arg: int, /) -> None: ...

    @property
    def character(self) -> int:
        """Character number"""

    @character.setter
    def character(self, arg: int, /) -> None: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __le__(self, arg: object, /) -> bool:
        pass

    def __ge__(self, arg: object, /) -> bool:
        pass

    def __lt__(self, arg: object, /) -> bool:
        pass

    def __gt__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::Position<Utf16Tag>'

class PositionUtf32:
    """Utf-32 based text position"""

    def __init__(self, line: int = 0, character: int = 0) -> None: ...

    @property
    def line(self) -> int:
        """Line number"""

    @line.setter
    def line(self, arg: int, /) -> None: ...

    @property
    def character(self) -> int:
        """Character number"""

    @character.setter
    def character(self, arg: int, /) -> None: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __le__(self, arg: object, /) -> bool:
        pass

    def __ge__(self, arg: object, /) -> bool:
        pass

    def __lt__(self, arg: object, /) -> bool:
        pass

    def __gt__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::Position<Utf32Tag>'

class RangeUtf8:
    """Utf-8 based text range"""

    def __init__(self, start: PositionUtf8, end: PositionUtf8) -> None: ...

    @property
    def start(self) -> PositionUtf8:
        """Start position of this range"""

    @start.setter
    def start(self, arg: PositionUtf8, /) -> None: ...

    @property
    def end(self) -> PositionUtf8:
        """End position of this range"""

    @end.setter
    def end(self, arg: PositionUtf8, /) -> None: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::Range<Utf8Tag>'

class RangeUtf16:
    """Utf-16 based text range"""

    def __init__(self, start: PositionUtf16, end: PositionUtf16) -> None: ...

    @property
    def start(self) -> PositionUtf16:
        """Start position of this range"""

    @start.setter
    def start(self, arg: PositionUtf16, /) -> None: ...

    @property
    def end(self) -> PositionUtf16:
        """End position of this range"""

    @end.setter
    def end(self, arg: PositionUtf16, /) -> None: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::Range<Utf16Tag>'

class RangeUtf32:
    """Utf-32 based text range"""

    def __init__(self, start: PositionUtf32, end: PositionUtf32) -> None: ...

    @property
    def start(self) -> PositionUtf32:
        """Start position of this range"""

    @start.setter
    def start(self, arg: PositionUtf32, /) -> None: ...

    @property
    def end(self) -> PositionUtf32:
        """End position of this range"""

    @end.setter
    def end(self, arg: PositionUtf32, /) -> None: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::Range<Utf32Tag>'

class TextDocumentEditUtf8:
    """Utf-8 based text edit"""

    def __init__(self, text: str, range: RangeUtf8 | None = None) -> None: ...

    @property
    def text(self) -> str:
        """
        The string to be inserted.

        For delete operations use an empty string.
        """

    @text.setter
    def text(self, arg: str, /) -> None: ...

    @property
    def range(self) -> RangeUtf8 | None:
        """
        The range of the text document to be manipulated.

        To insert text into a document create a range where ``start == end``.
        To apply the edit to the whole document, use ``None``.
        """

    @range.setter
    def range(self, arg: RangeUtf8 | None) -> None: ...

    __cpp_name__: str = 'syside::py::PyTextDocumentEdit<syside::Utf8Tag>'

class TextDocumentEditUtf16:
    """Utf-16 based text edit"""

    def __init__(self, text: str, range: RangeUtf16 | None = None) -> None: ...

    @property
    def text(self) -> str:
        """
        The string to be inserted.

        For delete operations use an empty string.
        """

    @text.setter
    def text(self, arg: str, /) -> None: ...

    @property
    def range(self) -> RangeUtf16 | None:
        """
        The range of the text document to be manipulated.

        To insert text into a document create a range where ``start == end``.
        To apply the edit to the whole document, use ``None``.
        """

    @range.setter
    def range(self, arg: RangeUtf16 | None) -> None: ...

    __cpp_name__: str = ...

class TextDocumentEditUtf32:
    """Utf-32 based text edit"""

    def __init__(self, text: str, range: RangeUtf32 | None = None) -> None: ...

    @property
    def text(self) -> str:
        """
        The string to be inserted.

        For delete operations use an empty string.
        """

    @text.setter
    def text(self, arg: str, /) -> None: ...

    @property
    def range(self) -> RangeUtf32 | None:
        """
        The range of the text document to be manipulated.

        To insert text into a document create a range where ``start == end``.
        To apply the edit to the whole document, use ``None``.
        """

    @range.setter
    def range(self, arg: RangeUtf32 | None) -> None: ...

    __cpp_name__: str = ...

class TextDocumentData:
    """Data used to initialize new text documents with."""

    def __init__(self, url: Url, language: str, content: str, version: int = 0) -> None: ...

    @property
    def url(self) -> Url:
        """
        Location of the text document.

        Once set, it cannot be changed.
        """

    @url.setter
    def url(self, arg: Url, /) -> None: ...

    @property
    def language(self) -> str:
        """
        Language identifier of the text document, e.g. ``"sysml"``.

        Once set, it cannot be changed.
        """

    @language.setter
    def language(self, arg: str, /) -> None: ...

    @property
    def content(self) -> str:
        """
        The actual contents of the text document, e.g. file contents.

        Once set, can only be modified by edits.
        """

    @content.setter
    def content(self, arg: str, /) -> None: ...

    @property
    def version(self) -> int:
        """
        Initial version of the text document.

        Version is used to cheaply track the edits done to the text document.
        """

    @version.setter
    def version(self, arg: int, /) -> None: ...

class PartialTextDocumentData:
    """
    A subset of ``TextDocumentData`` for opening a new text document when one was not found
    """

    def __init__(self, content: str, version: int = 0) -> None: ...

    @property
    def content(self) -> str:
        """Source text contents"""

    @content.setter
    def content(self, arg: str, /) -> None: ...

    @property
    def version(self) -> int:
        """Initial version number"""

    @version.setter
    def version(self, arg: int, /) -> None: ...

class TextDocument:
    """
    A basic text document that holds source text and allows conversions between
    encoded text positions and byte offsets.

    Note that the only way to update contents is through ``.update`` method.
    """

    @overload
    @staticmethod
    def create_st() -> SharedMutex[TextDocument]:
        """Create an empty ``TextDocument`` for single-threaded applications"""

    @overload
    @staticmethod
    def create_st(url: Url, language: str, content: str, version: int = 0) -> SharedMutex[TextDocument]: ...

    @overload
    @staticmethod
    def create_mt() -> SharedMutex[TextDocument]:
        """Create an empty ``TextDocument`` for multi-threaded applications"""

    @overload
    @staticmethod
    def create_mt(url: Url, language: str, content: str, version: int = 0) -> SharedMutex[TextDocument]: ...

    @property
    def url(self) -> Url:
        """Location this text corresponds to."""

    @property
    def language_id(self) -> str:
        """Language identifier of this text document."""

    @property
    def version(self) -> int:
        """Current version of this text document."""

    @property
    def text(self) -> str:
        """Full source of this text document."""

    @overload
    def get_text(self, range: RangeUtf8) -> str:
        """Get text corresponding to the given Utf-8 range."""

    @overload
    def get_text(self, range: RangeUtf16) -> str:
        """Get text corresponding to the given Utf-16 range."""

    @overload
    def get_text(self, range: RangeUtf32) -> str:
        """Get text corresponding to the given Utf-32 range."""

    @overload
    def offset_at(self, position: PositionUtf8) -> int:
        """Get byte offset at Utf-8 position."""

    @overload
    def offset_at(self, position: PositionUtf16) -> int:
        """Get byte offset at Utf-16 position."""

    @overload
    def offset_at(self, position: PositionUtf32) -> int:
        """Get byte offset at Utf-32 position."""

    def utf8_position_at(self, offset: int) -> PositionUtf8:
        """Get Utf-8 position at the given byte offset."""

    def utf16_position_at(self, offset: int) -> PositionUtf16:
        """Get Utf-16 position at the given byte offset."""

    def utf32_position_at(self, offset: int) -> PositionUtf32:
        """Get Utf-32 position at the given byte offset."""

    @property
    def line_count(self) -> int:
        """Number of lines in this text document."""

    def update(self, changes: Sequence[TextDocumentEditUtf8], version: int | None = None) -> None:
        """
        Apply edits to the ``contents`` of this text documents.

        Updates the version to the given value, or increments an existing version.
        """

class TextDocumentSaveReason(enum.Enum):
    """Represents reasons why a text document is saved."""

    Manual = 1

    AfterDelay = 2

    FocusOut = 3

class TextEdit:
    """A textual edit applicable to a text document."""

    @property
    def range(self) -> RangeUtf8:
        """
        The range of the text document to be manipulated.

        To insert text into a document create a range where ``start == end``.
        """

    @range.setter
    def range(self, arg: RangeUtf8, /) -> None: ...

    @property
    def new_text(self) -> str:
        """
        The string to be inserted.

        For delete operations use an empty string.
        """

    @new_text.setter
    def new_text(self, arg: str, /) -> None: ...

class TextDocuments:
    """A thread-safe registry for ``TextDocuments``."""

    @staticmethod
    def create_st() -> TextDocuments:
        """Create ``TextDocuments`` for single-threaded applications"""

    @staticmethod
    def create_mt() -> TextDocuments:
        """Create ``TextDocuments`` for multi-threaded applications"""

    def __getitem__(self, url: Url) -> SharedMutex[TextDocument]: ...

    def visit_documents(self, visitor: Callable[[SharedMutex[TextDocument]], None]) -> None:
        """Visit all text documents in the registry."""

    def visit_urls(self, visitor: Callable[[Url], None]) -> None:
        """Visit all reachable urls in the registry."""

    def visit(self, visitor: Callable[[Url, SharedMutex[TextDocument]], None]) -> None:
        """Visit all text documents in the registry."""

    @overload
    def open(self, url: Url, language: str, content: str, version: int = 0) -> SharedMutex[TextDocument]:
        """
        Open a new text document.

        This overwrites any text document already at ``url``.
        """

    @overload
    def open(self, arg: TextDocumentData, /) -> SharedMutex[TextDocument]: ...

    def find_or_open(self, url: Url, language: str, data: Callable[[], PartialTextDocumentData]) -> tuple[SharedMutex[TextDocument], bool]:
        """
        Find an existing document, or open a new one if either `url` does not exist, or an existing document
        has a different language.

        The second return value is only ``True`` if a new document was opened,
        and ``False`` if an existing document was found.
        """

    def close(self, url: Url) -> SharedMutex[TextDocument] | None:
        """Remove a document at ``url`` from this registry."""

    def move(self, src: Url, dst: Url) -> SharedMutex[TextDocument] | None:
        """
        Move document from ``src`` to ``dst``.

        If ``src`` exists, steals its contents and creates a new document at ``dst`` and
        returns the new document. Note that any references to the old document at ``src``
        will not be updated to ``dst``.

        This overwrites existing document at ``dst`` if ``src`` exits.
        """

    def will_save(self, url: Url, reason: TextDocumentSaveReason) -> None:
        """Signal that document at ``url`` will be saved."""

    def save(self, url: Url) -> None:
        """Signal that document at ``url`` has been saved."""

    def will_save_wait_until(self, url: Url, reason: TextDocumentSaveReason) -> list[TextEdit]:
        """
        Signal that document at ``url`` has been saved and wait until corresponding
        handler completes.
        """

    def change_content(self, url: Url, changes: Sequence[TextDocumentEditUtf8], version: int | None = None) -> None:
        """Update contents of the text document at ``url``."""

class DocumentID:
    """Strongly typed numerical document id"""

    def __init__(self, arg: int, /) -> None: ...

    def __int__(self) -> int: ...

    def __index__(self) -> int: ...

    def __hash__(self) -> int: ...

    @staticmethod
    def reserve_new() -> DocumentID:
        """
        Reserve a new globally unique id.

        This is only guaranteed to be unique for ids constructed this way.
        """

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __le__(self, arg: object, /) -> bool:
        pass

    def __ge__(self, arg: object, /) -> bool:
        pass

    def __lt__(self, arg: object, /) -> bool:
        pass

    def __gt__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::DocumentID'

class LibraryID:
    """Strongly typed numerical library id"""

    def __init__(self, arg: int, /) -> None: ...

    def __int__(self) -> int: ...

    def __index__(self) -> int: ...

    def __hash__(self) -> int: ...

    @staticmethod
    def reserve_new() -> LibraryID:
        """
        Reserve a new globally unique id.

        This is only guaranteed to be unique for ids constructed this way.
        """

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __le__(self, arg: object, /) -> bool:
        pass

    def __ge__(self, arg: object, /) -> bool:
        pass

    def __lt__(self, arg: object, /) -> bool:
        pass

    def __gt__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::LibraryID'

class DiagnosticSeverity(enum.IntEnum):
    """The severity of the diagnostic"""

    Error = 1

    Warning = 2

    Information = 3

    Hint = 4

class DocumentSegment:
    """Utf-8 based segment into a source text document."""

    def __init__(self, range: RangeUtf8 = ..., offset: int = 0, end: int = 0) -> None: ...

    @property
    def range(self) -> RangeUtf8:
        """Text range of this segment"""

    @range.setter
    def range(self, arg: RangeUtf8, /) -> None: ...

    @property
    def offset(self) -> int:
        """Start byte of this segment"""

    @offset.setter
    def offset(self, arg: int, /) -> None: ...

    @property
    def end(self) -> int:
        """End byte of this segment"""

    @end.setter
    def end(self, arg: int, /) -> None: ...

    @staticmethod
    def from_cst(arg: CstNode, /) -> DocumentSegment:
        """Construct a segment corresponding to the given CST node."""

    @staticmethod
    def from_cst_start(arg: CstNode, /) -> DocumentSegment:
        """
        Construct a segment corresponding to the start position of the given CST node.
        """

    @staticmethod
    def from_cst_end(arg: CstNode, /) -> DocumentSegment:
        """
        Construct a segment corresponding to the end position of the given CST node.
        """

    @staticmethod
    def from_node(arg: AstNode, /) -> DocumentSegment:
        """
        Construct ``DocumentSegment`` from the nearest CST node that contains ``node``.
        """

    @staticmethod
    def from_node_field(node: AstNode, field: str, index: int = 0) -> DocumentSegment:
        """
        Construct ``DocumentSegment`` from a ``tree-sitter`` field named ``field`` at ``index``.

        If ``node`` does not contain a CST node with a matching ``field``, the nearest
        CST segment is returned instead.
        """

    @staticmethod
    def from_node_symbol(node: AstNode, symbol: str, index: int = 0) -> DocumentSegment:
        """
        Construct ``DocumentSegment`` from a ``tree-sitter`` symbol named ``symbol`` at ``index``.

        If ``node`` does not contain a CST node with a matching ``symbol``, the nearest
        CST segment is returned instead.
        """

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::DocumentSegment'

class DiagnosticRelatedInformation:
    """
    Represents a related message and source code location for a diagnostic.

    This should be used to point to code locations that cause or related to a diagnostics,
    e.g when duplicating a symbol in a scope.
    """

    def __init__(self, uri: Url, segment: DocumentSegment, message: str, depth: int = 0) -> None: ...

    @property
    def uri(self) -> Url:
        """URI of the document this information applies to"""

    @uri.setter
    def uri(self, arg: Url, /) -> None: ...

    @property
    def segment(self) -> DocumentSegment:
        """
        The segment at which the message applies, offsets are in UTF-8 characters
        """

    @segment.setter
    def segment(self, arg: DocumentSegment, /) -> None: ...

    @property
    def message(self) -> str:
        """The diagnostic's message."""

    @message.setter
    def message(self, arg: str, /) -> None: ...

    @property
    def depth(self) -> int:
        """
        Nesting level of the related information, may be used to indent the printed message
        """

    @depth.setter
    def depth(self, arg: int, /) -> None: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::DiagnosticRelatedInformation'

class DiagnosticContext:
    """Additional diagnostics context information for formatting."""

    def __init__(self, source: str = '', filename: str = '', related_sources: Callable[[Url], str | SharedMutex[TextDocument]] | TextDocuments | None = None) -> None: ...

    @property
    def source(self) -> str:
        """The source text of the document diagnostics apply to."""

    @source.setter
    def source(self, arg: str, /) -> None: ...

    @property
    def filename(self) -> str:
        """The filename of the document diagnostics apply to."""

    @filename.setter
    def filename(self, arg: str, /) -> None: ...

    @property
    def related_sources(self) -> Callable[[Url], str | SharedMutex[TextDocument]] | TextDocuments:
        """
        Additional sources for printing related information snippets from external documents
        """

    @related_sources.setter
    def related_sources(self, arg: Callable[[Url], str | SharedMutex[TextDocument]] | TextDocuments, /) -> None: ...

    __cpp_name__: str = 'syside::py::PyDiagnosticContext'

class TreeDrawing(enum.Enum):
    """Kind of glyphs to insert when formatting related information tree"""

    No = 0
    """No tree is drawn"""

    Ascii = 1
    """Use ASCII symbols for drawing"""

    Unicode = 2
    """Use unicode symbols for drawing"""

class DiagnosticFormatOptions:
    """Diagnostic formatting style options"""

    def __init__(self, indent: int = 0, tab_size: int = 4, underline: str = '^', colours: bool = False, draw_tree: TreeDrawing = TreeDrawing.No) -> None: ...

    @property
    def indent(self) -> int:
        """Number of indentations to apply to the message (``indent * tab_size``)"""

    @indent.setter
    def indent(self, arg: int, /) -> None: ...

    @property
    def tab_size(self) -> int:
        """Tab size in spaces"""

    @tab_size.setter
    def tab_size(self, arg: int, /) -> None: ...

    @property
    def underline(self) -> str:
        """Underline character used to highlight snippets diagnostics apply to"""

    @underline.setter
    def underline(self, arg: str, /) -> None: ...

    @property
    def colours(self) -> bool:
        """Wether to format diagnostics with coloured output"""

    @colours.setter
    def colours(self, arg: bool, /) -> None: ...

    @property
    def draw_tree(self) -> TreeDrawing:
        """Wether to insert tree branch glyphs to related information"""

    @draw_tree.setter
    def draw_tree(self, arg: TreeDrawing, /) -> None: ...

    __cpp_name__: str = 'syside::DiagnosticFormatOptions'

class CodeDescription:
    """Structure to capture a description for an error code."""

    def __init__(self, href: str) -> None: ...

    @property
    def href(self) -> str:
        """An URI to open with more information about the diagnostic error."""

    @href.setter
    def href(self, arg: str, /) -> None: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::CodeDescription'

class Diagnostic:
    """
    LSP compatible diagnostic structure.

    Note that this does not capture the source document the diagnostic applies to,
    it is expected that this information is contextual and readily available without
    additional duplication.
    """

    def __init__(self, segment: DocumentSegment, code: str | str, message: str, severity: DiagnosticSeverity = DiagnosticSeverity.Error) -> None: ...

    @property
    def segment(self) -> DocumentSegment:
        """
        The segment at which the message applies, offsets are in UTF-8 characters
        """

    @segment.setter
    def segment(self, arg: DocumentSegment, /) -> None: ...

    @property
    def code(self) -> str | str:
        """The diagnostic's code, which usually appear in the user interface."""

    @code.setter
    def code(self, arg: str | str, /) -> None: ...

    @property
    def message(self) -> str:
        """The diagnostic's message. It usually appears in the user interface"""

    @message.setter
    def message(self, arg: str, /) -> None: ...

    @property
    def severity(self) -> DiagnosticSeverity:
        """The diagnostic's severity."""

    @severity.setter
    def severity(self, arg: DiagnosticSeverity, /) -> None: ...

    @property
    def is_unnecessary(self) -> bool:
        """Unused or unnecessary code."""

    @is_unnecessary.setter
    def is_unnecessary(self, arg: bool, /) -> None: ...

    @property
    def is_deprecated(self) -> bool:
        """Deprecated or obsolete code."""

    @is_deprecated.setter
    def is_deprecated(self, arg: bool, /) -> None: ...

    @property
    def code_description(self) -> CodeDescription | None:
        """
        An optional property to describe the error code.

        Requires the code field (above) to be present/not null.
        """

    @code_description.setter
    def code_description(self, arg: CodeDescription | None) -> None: ...

    @property
    def source(self) -> str | None:
        """
        A human-readable string describing the source of this diagnostic, e.g. 'typescript' or 'super lint'.

        It usually appears in the user interface.
        """

    @source.setter
    def source(self, arg: str | None) -> None: ...

    @property
    def related_information(self) -> ContainerView[DiagnosticRelatedInformation]:
        """
        An array of related diagnostic information.

        E.g. when symbol-names within a scope collide all definitions can be marked via
        this property.
        """

    def append_related_information(self, arg: DiagnosticRelatedInformation, /) -> None:
        """Append new related diagnostic information."""

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::Diagnostic'

def format_diagnostics(errors: Sequence[Diagnostic], context: DiagnosticContext = ..., options: DiagnosticFormatOptions = ...) -> str:
    """
    Format diagnostics to string.

    ``context`` will be used to add additional contextual information, like source snippets,
    to the formatted output. ``options`` control how the diagnostics are formatted.

    Note that this is subject to change in future releases.
    """

class ScheduleError:
    """Signifies an error when attempting to schedule documents for analysis"""

    @property
    def message(self) -> str:
        """Reason for error"""

    @property
    def input(self) -> Schedule | None:
        """Schedule that was passed in to be reused"""

    __cpp_name__: str = 'syside::ScheduleError'

class Schedule:
    """
    A schedule for parsing and analysis of documents.

    Schedules are executable on an ``Executor``, and doing so consumes them.
    """

    @staticmethod
    def make_empty_schedule() -> Schedule:
        """Create an empty schedule"""

    __cpp_name__: str = 'syside::Schedule'

class ValidationTiming(enum.Enum):
    """Cost threshold of validation rules to execute."""

    OnType = 0
    """Validation rules will be executed on every key stroke."""

    OnSave = 1
    """Validation rules will be executed on document save."""

    Manual = 2
    """Validation rules will be executed manually."""

    Never = 3
    """No validation rules will be executed"""

class ScheduleOptions:
    """Options for a particular ``Schedule``."""

    def __init__(self, validation_timing: ValidationTiming, cutoff: BuildState = BuildState.Validated, force_revalidation: bool = False, attach_comments: bool = False, validation_tier: DocumentTier = DocumentTier.Project) -> None: ...

    @property
    def validation_timing(self) -> ValidationTiming:
        """Which validations to run."""

    @validation_timing.setter
    def validation_timing(self, arg: ValidationTiming, /) -> None: ...

    @property
    def validation_tier(self) -> DocumentTier:
        """
        Lowest tier of documents to validate.

        For example, ``Projects`` will validate only project documents, while
        ``StandardLibrary`` - everything.
        """

    @validation_tier.setter
    def validation_tier(self, arg: DocumentTier, /) -> None: ...

    @property
    def cutoff(self) -> BuildState:
        """
        The last stage in the pipeline that will be executed.

        Any stages higher than ``cutoff`` will be ignored.
        """

    @cutoff.setter
    def cutoff(self, arg: BuildState, /) -> None: ...

    @property
    def force_revalidation(self) -> bool:
        """If true, validated documents will be validated again."""

    @force_revalidation.setter
    def force_revalidation(self, arg: bool, /) -> None: ...

    @property
    def attach_comments(self) -> bool:
        """If true, comments will be attached. Mainly useful for formatters."""

    @attach_comments.setter
    def attach_comments(self, arg: bool, /) -> None: ...

    __cpp_name__: str = 'syside::ScheduleOptions'

class IOSchedule:
    """An IO schedule that can be executed concurrently on an ``Executor``."""

    @staticmethod
    def make_empty_schedule(multithreaded: bool = False) -> IOSchedule:
        """Create a new schedule"""

    @property
    def text_documents(self) -> TextDocuments | None:
        """``TextDocuments`` that new text files will be opened in"""

    @text_documents.setter
    def text_documents(self, arg: TextDocuments | None) -> None: ...

    @property
    def is_multithreaded(self) -> bool:
        """
        If true, new text documents will be constructed for multithreaded application, otherwise - single threaded. Only has effect if no ``TextDocuments`` is set.
        """

    @is_multithreaded.setter
    def is_multithreaded(self, arg: bool, /) -> None: ...

    def set_multithreaded(self, arg: bool, /) -> IOSchedule:
        """Builder pattern setter for ``is_multithreaded``."""

    def assign_text_documents(self, arg: TextDocuments, /) -> IOSchedule:
        """Set ``TextDocuments`` that new text files will be opened in"""

    def add_file(self, path: str | os.PathLike[AnyStr], language: str, tier: DocumentTier = DocumentTier.Project) -> IOSchedule:
        """Schedule a new file to read at ``path``"""

    def add_source(self, url: Url, contents: str, language: str, tier: DocumentTier = DocumentTier.Project) -> IOSchedule:
        """Schedule a new in-memory source at ``url``"""

    @property
    def size(self) -> int:
        """Returns the number of currently scheduled documents"""

    def set_completion_callback(self, arg: Callable[[SharedMutex[TextDocument], IOSchedule.CallbackData], None], /) -> IOSchedule:
        """
        Set completion callback that will be invoked when a text document is
        ready.

        The second callback argument contains the index of the document,
        and order between `add_*` is preserved. Note that this may be called from
        multiple other threads so this should be thread-safe, e.g. by sizing a
        result buffer to `size()` before executing this schedule and only
        modifying the element at the callback `index`.

        On a single-thread executor, only the first enqueued unique source will
        invoke this callback. On multithreaded executors, any one of duplicated
        sources may invoke this callback, however it is unspecified which.
        Deduplication is performed based on resolved absolute URLs.
        """

    __cpp_name__: str = 'syside::IOSchedule'

    class CallbackData:
        @property
        def index(self) -> int:
            """
            The index of the associated text document. Matches the order it was added to the schedule.
            """

        @index.setter
        def index(self, arg: int, /) -> None: ...

        @property
        def tier(self) -> DocumentTier:
            """Tier the text document was added with."""

        @tier.setter
        def tier(self, arg: DocumentTier, /) -> None: ...

class Pipeline:
    """A language agnostic multithreaded parsing and analysis pipeline."""

    def schedule(self, documents: Sequence[SharedMutex[BasicDocument]], options: ScheduleOptions = ..., invalidated: Sequence[SharedMutex[BasicDocument]] = []) -> Schedule:
        """
        Schedule ``documents`` for building with this ``Pipeline``.

        ``documents`` with ``build_state`` equal or greater to the state at the end of particular
        pipeline stage will not be scheduled for that stage. For example, a
        document with ``build_state >= BuildState.Parsed`` will not be scheduled
        for parsing.

        Pipeline also accepts additional ``invalidated`` documents that will have
        their semantic states reset. These documents will then pass through sema
        and validation stages as normal. This should typically be used for
        documents that have had their dependencies modified. Any documents for
        which ``build_state < BuildState.Built`` will not be invalidated as there
        should be nothing to invalidate.

        The returned schedule should be executed on an ``Executor``:

        .. code-block:: python

            executor = syside.Executor(...)
            schedule = pipeline.schedule(...)
            ...
            result = executor.run(schedule)

        Note that pipeline will skip indexing certain URLs that are used by IDEs to display
        virtual documents:

        * ``git*://*``, e.g. used by VS Code to display ``git`` diffs
        * ``vscode*://*``, e.g. used by VS Code to display editor previews
        * ``<scheme>[:|://]`` (URL with scheme only), e.g. used by Neovim for new unnamed buffers

        The first two patterns additionally skip validation since those virtual documents are
        never a part of the workspace. Indexing is skipped only for known URL patterns to
        avoid unexpected behaviour. However, prefer using common schemes such as ``file`` or
        ``http[s]`` to ensure that the documents are handled correctly as more URL patterns may
        be added as more IDEs are tested.
        """

    __cpp_name__: str = 'syside::Pipeline'

class DiagnosticResults:
    """The collection of all diagnostics for a single document."""

    @property
    def parser(self) -> ContainerView[Diagnostic]:
        """Diagnostics emitted during parsing of the source files"""

    @property
    def sema(self) -> ContainerView[Diagnostic]:
        """Diagnostics emitted during semantic resolution"""

    @property
    def validation(self) -> ContainerView[Diagnostic]:
        """Diagnostics emitted during validation"""

    def passed(self, warnings_as_errors: bool = False) -> bool:
        """
        Whether this result can be treated as passing

        Using ``warnings_as_errors`` treats any warnings as fatal, in addition to errors.
        """

    @property
    def empty(self) -> bool:
        """Returns ``True`` if all diagnostic categories are empty"""

    def __bool__(self) -> bool:
        """Returns ``True`` if there are no ``Error`` diagnostics"""

    __cpp_name__: str = 'syside::DiagnosticResults'

class DocumentTimes:
    """
    Stage times for a single document.

    Note that Windows has ~15 ms resolution timers only so this may be
    wildly inaccurate.
    """

    @property
    def parse(self) -> datetime.timedelta:
        """The time it took to parse the document"""

    @parse.setter
    def parse(self, arg: datetime.timedelta | float, /) -> None: ...

    @property
    def ast(self) -> datetime.timedelta:
        """The time it took to construct the AST"""

    @ast.setter
    def ast(self, arg: datetime.timedelta | float, /) -> None: ...

    @property
    def index(self) -> datetime.timedelta:
        """The time it took to index the document"""

    @index.setter
    def index(self, arg: datetime.timedelta | float, /) -> None: ...

    @property
    def sema(self) -> datetime.timedelta:
        """
        The time it took to semantically resolve the document.

        Note that semantic resolution is done in batches to work with cyclical dependencies,
        therefore this time is a batch (``sema_group``) time.
        """

    @sema.setter
    def sema(self, arg: datetime.timedelta | float, /) -> None: ...

    @property
    def validate(self) -> datetime.timedelta:
        """The time it took to validate the document"""

    @validate.setter
    def validate(self, arg: datetime.timedelta | float, /) -> None: ...

    @property
    def sema_group(self) -> int | None:
        """The batch number the document was semantically resolved in"""

    @sema_group.setter
    def sema_group(self, arg: int | None) -> None: ...

    __cpp_name__: str = 'syside::DocumentTimes'

class StageTimes:
    """
    Total times for each pipeline stage.

    Note that Windows has ~15 ms resolution timers only so this may be
    wildly inaccurate.
    """

    @property
    def ast(self) -> datetime.timedelta:
        """
        The time it took to parse all scheduled documents, including ast and index
        """

    @ast.setter
    def ast(self, arg: datetime.timedelta | float, /) -> None: ...

    @property
    def sema(self) -> datetime.timedelta:
        """The time it took to semantically resolve all scheduled documents"""

    @sema.setter
    def sema(self, arg: datetime.timedelta | float, /) -> None: ...

    @property
    def validate(self) -> datetime.timedelta:
        """The time it took to validate all scheduled documents"""

    @validate.setter
    def validate(self, arg: datetime.timedelta | float, /) -> None: ...

    @property
    def total(self) -> datetime.timedelta:
        """The total time of this execution"""

    @total.setter
    def total(self, arg: datetime.timedelta | float, /) -> None: ...

    __cpp_name__: str = 'syside::StageTimes'

class ExecutionResult:
    """Schedule execution result"""

    @property
    def schedule(self) -> Schedule:
        """Schedule that was executed."""

    @property
    def documents(self) -> ContainerView[SharedMutex[BasicDocument]]:
        """
        Documents that were scheduled.

        Note that duplicates have been removed.
        """

    @property
    def diagnostics(self) -> ContainerView[DiagnosticResults]:
        """Diagnostics corresponding to each document in ``documents``."""

    @property
    def times(self) -> ContainerView[DocumentTimes]:
        """Execution times corresponding to each document in ``documents``."""

    @property
    def total_times(self) -> StageTimes:
        """Stage times corresponding to each document in ``documents``."""

    @total_times.setter
    def total_times(self, arg: StageTimes, /) -> None: ...

    def rethrow_exception(self) -> None:
        """
        Rethrow the exception that was caught during execution. Noop otherwise.

        Because schedules are executed on multiple threads, and even partial results
        may be useful, exceptions are not thrown automatically.
        """

    def __bool__(self) -> bool:
        """
        Whether the execution suceeded

        Note that this is different to whether the analysis is passing or not.
        """

    __cpp_name__: str = 'syside::ExecutionResult'

class Executor:
    """
    Thread-pool executor used to run various multi-threaded tasks internally.
    """

    @overload
    def __init__(self) -> None:
        """Default constructor using as many workers as possible"""

    @overload
    def __init__(self, num_workers: int) -> None: ...

    @overload
    def run(self, schedule: Schedule) -> ExecutionResult:
        """
        Execute a schedule. Note that schedules are consumed and trying to access them again will result in an error
        """

    @overload
    def run(self, schedule: IOSchedule) -> tuple[IOSchedule, list[SharedMutex[TextDocument]]]: ...

    @property
    def num_workers(self) -> int:
        """Returns the number of worker threads associated with this executor."""

class BasicDocument:
    """The base type of all documents corresponding to a single source file."""

    @property
    def text_document(self) -> SharedMutex[TextDocument] | None:
        """The source text document associated with this document."""

    @text_document.setter
    def text_document(self, text: SharedMutex[TextDocument] | None) -> None: ...

    @property
    def url(self) -> Url:
        """
        Location of this document.

        Url is used for compatibility with LSP. Typically, local files will have absolute
        ``file:///path/to/source.ext`` urls.
        """

    @url.setter
    def url(self, arg: Url, /) -> None: ...

    @property
    def build_state(self) -> BuildState:
        """
        The current build state of this document.

        This is typically used by the pipeline to select and execute appropriate phases.
        """

    @build_state.setter
    def build_state(self, arg: BuildState, /) -> None: ...

    @property
    def document_state(self) -> DocumentState:
        """
        The current state of this document inside a pipeline.

        This is automatically updated by the pipeline and allows monitoring its state from
        worker threads.
        """

    @property
    def document_tier(self) -> DocumentTier:
        """
        The tier of this document.

        This is used internally to optimize certain operations, especially on standard
        library documents.
        """

    def change_document_tier(self, arg: DocumentTier, /) -> None:
        """
        Set ``document_tier`` to another value.

        This is a method rather than a function because
        tier should not change throughout document lifetime. Nevertheless, this is still useful
        in cases where a document has just been constructed and its attributes need to be changed.
        """

    @property
    def language(self) -> str:
        """Language identifier of this document"""

    @property
    def version(self) -> DocumentVersion:
        """
        The version of the last build.

        This corresponds to the version of ``TextDocument`` this was built from.
        """

    def increment_version(self) -> None:
        """
        Increment sema version.

        Source version is automatically handled by source parser.
        """

    def __hash__(self) -> int:
        """
        Identity based hash of this document.

        This is guaranteed to be unique or nearly unique globally (due to bit mixing). However,
        it is not stable across Python invocations.
        """

    @property
    def mutex(self) -> SharedMutex[Self]:
        """Retrieve the mutex associated with this document"""

    __cpp_name__: str = 'syside::BasicDocument'

class DocumentVersion:
    """Document version ``(source, sema)`` pair."""

    def __init__(self, source: int = 0, sema: int = 0) -> None: ...

    @property
    def source(self) -> int:
        """
        The version of the source ``TextDocument`` the document was built from.
        Always 0 if there is no actual source associated. Takes priority over
        ``sema``.
        """

    @source.setter
    def source(self, arg: int, /) -> None: ...

    @property
    def sema(self) -> int:
        """
        The sema version of the ``document``. This is separate from ``source`` since
        ``sema`` may be recomputed after one of the dependencies has changed. May also
        be reset to 0 on source changes. Most similar to patch version in
        semantic versioning scheme.
        """

    @sema.setter
    def sema(self, arg: int, /) -> None: ...

    def __int__(self) -> int: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __le__(self, arg: object, /) -> bool:
        pass

    def __ge__(self, arg: object, /) -> bool:
        pass

    def __lt__(self, arg: object, /) -> bool:
        pass

    def __gt__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::DocumentVersion'

class DocumentOptions:
    """Options to construct new document with"""

    def __init__(self, url: Url, language: str = 'plaintext', tier: DocumentTier = DocumentTier.Project, document_id: DocumentID = ..., owning_library: LibraryID | None = None) -> None: ...

    @property
    def url(self) -> Url:
        """Url of the new document"""

    @url.setter
    def url(self, arg: Url, /) -> None: ...

    @property
    def language(self) -> str:
        """Language identifier of the new document, e.g. ``"sysml"``"""

    @language.setter
    def language(self, arg: str, /) -> None: ...

    @property
    def tier(self) -> DocumentTier:
        """
        Document tier of the new document.

        This will typically be ``Project``.
        """

    @tier.setter
    def tier(self, arg: DocumentTier, /) -> None: ...

    @property
    def document_id(self) -> DocumentID:
        """
        Id of the new document.

        Note: this currently has no effect.
        """

    @document_id.setter
    def document_id(self, arg: DocumentID, /) -> None: ...

    @property
    def owning_library(self) -> LibraryID | None:
        """
        Id of the library this document is a part of.

        Note: this currently has no effect.
        """

    @owning_library.setter
    def owning_library(self, arg: LibraryID | None) -> None: ...

    __cpp_name__: str = 'syside::DocumentOptions'

class Document(BasicDocument):
    """KerML and SysML specific document type"""

    @property
    def root_node(self) -> Namespace:
        """The root namespace of this document"""

    def nodes(self, kind: type[TElement]) -> Iterable[TElement]:
        """
        Returns the iterator to nodes in this documents that are exact instances of
        ``kind``, excluding any subtypes.
        """

    def all_nodes(self, kind: type[TElement]) -> Iterable[TElement]:
        """
        Returns the iterator to all nodes in this document that are instances of
        ``kind``, including all subtypes.
        """

    @staticmethod
    def parse_string_st(source: str, language: ModelLanguage) -> tuple[SharedMutex[Document], list[Diagnostic]]:
        """
        Parse a document from string for single-threaded applications without resolving references.

        Note that this disables GIL optimization during ``Executor.run`` using this document.
        """

    @staticmethod
    def parse_string_mt(source: str, language: ModelLanguage) -> tuple[SharedMutex[Document], list[Diagnostic]]:
        """
        Parse a document from string for multi-threaded applications without resolving references.

        This allows the ``Executor`` to release GIL during execution allowing other Python
        threads to execute in the meantime but only if all the other documents were also
        created with ``create_mt``.
        """

    @overload
    @staticmethod
    def create_st() -> SharedMutex[Document]:
        """
        Create a document for single-threaded applications.

        Note that this disables GIL optimization during ``Executor.run`` using this document.
        """

    @overload
    @staticmethod
    def create_st(arg: DocumentOptions, /) -> SharedMutex[Document]: ...

    @overload
    @staticmethod
    def create_st(url: Url, language: ModelLanguage, tier: DocumentTier = DocumentTier.Project, document_id: DocumentID | None = None, owning_library: LibraryID | None = None) -> SharedMutex[Document]: ...

    @overload
    @staticmethod
    def create_mt() -> SharedMutex[Document]:
        """
        Create a document for multi-threaded applications.

        This allows the ``Executor`` to release GIL during execution allowing other Python
        threads to execute in the meantime but only if all the other documents were also created
        with ``create_mt``.
        """

    @overload
    @staticmethod
    def create_mt(arg: DocumentOptions, /) -> SharedMutex[Document]: ...

    @overload
    @staticmethod
    def create_mt(url: Url, language: ModelLanguage, tier: DocumentTier = DocumentTier.Project, document_id: DocumentID | None = None, owning_library: LibraryID | None = None) -> SharedMutex[Document]: ...

    __cpp_name__: str = 'syside::Document<syside::sysml::SysMLTraits>'

class Infinity:
    """A cheap-to-construct marker for infinity (``*`` in KerML/SysML)"""

    def __init__(self, positive: bool = True) -> None: ...

    @property
    def positive(self) -> bool:
        """Whether this is positive or negative infinity"""

    @positive.setter
    def positive(self, arg: bool, /) -> None: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::sysml::vm::Infinity'

class BoundMetaclass:
    """A cheap-to-constructor surrogate for metadata features"""

    @property
    def element(self) -> Element:
        """
        The element this metadata applies to.

        This is equivalent to ``.annotated_element``.
        """

    @property
    def metaclass(self) -> Type | None:
        """
        The metaclass this metadata is typed by.

        This is equivalent to ``.metaclass`` of metadata features. Presence of ``metaclass``
        depends on the standard library cache used to construct this ``BoundMetaclass``. It
        is optional, because reflection is implemented based on the ``element`` type alone.
        """

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::sysml::vm::BoundMetaclass'

class ImplicitSpecializationKind(enum.Enum):
    """
    An implicit specialization kind that also depends on the type of the element.

    Note that not all ``(type, kind)`` combinations are valid.
    """

    AccessedFeature = 0

    ActionTransition = 1

    After = 2

    AnnotatedElement = 3

    Assumption = 4

    At = 5

    Base = 6

    BaseType = 7

    Binary = 8

    BinaryObject = 9

    CaseActor = 10

    CheckedConstraint = 11

    Classifier = 12

    Concern = 13

    DataValue = 14

    Decision = 15

    Do = 16

    Effect = 17

    EnclosedPerformance = 18

    Entry = 19

    ExclusiveState = 20

    Exit = 21

    Feature = 22

    FeatureWrite = 23

    Flow = 24

    Guard = 25

    IfThenElse = 26

    IncomingTransfer = 27

    Life = 28

    LoopVariable = 29

    Merge = 30

    Message = 31

    Negated = 32

    Object = 33

    Occurrence = 34

    OwnedAction = 35

    OwnedPerformance = 36

    OwnedPort = 37

    Participant = 38

    Payload = 39

    PerformedAction = 40

    Portion = 41

    Requirement = 42

    RequirementActor = 43

    RequirementStakeholder = 44

    Satisfied = 45

    Snapshot = 46

    SourceOutput = 47

    StartingAt = 48

    StateTransition = 49

    SubAnalysisCase = 50

    SubUseCase = 51

    SubVerificationCase = 52

    Subaction = 53

    Subcalculation = 54

    Subcase = 55

    Subitem = 56

    Subobject = 57

    Suboccurrence = 58

    Subpart = 59

    Subperformance = 60

    Subport = 61

    Subrendering = 62

    Subrequirement = 63

    Substate = 64

    Subview = 65

    Target = 66

    TargetInput = 67

    Timeslice = 68

    TransitionLink = 69

    Trigger = 70

    Verification = 71

    ViewRendering = 72

    When = 73

class Stdlib:
    """Cache of standard library elements used by sema."""

    @overload
    def __init__(self) -> None:
        """
        Initialize an empty cache.

        Empty cache will be populated during pipeline execution, after documents
        have been indexed.
        """

    @overload
    def __init__(self, arg: StaticIndex, /) -> None:
        """
        Initialize cache from a given index.

        Cache will try to find elements only in the given index.
        """

    def update(self, arg: StaticIndex, /) -> bool:
        """
        Update missing elements from the given index.

        Returns true if all elements have been found. If all elements have already
        been found, this does nothing.
        """

    @property
    def all_complete(self) -> bool:
        """Returns ``True`` if all cacheable elements have been found and cached."""

    @property
    def anything(self) -> Type | None:
        """Cached ``Base::Anything``."""

    @property
    def ordered_collection(self) -> Type | None:
        """Cached ``Collections::OrderedCollection``."""

    @property
    def array(self) -> Type | None:
        """Cached ``Collections::Aray``."""

    @property
    def self_reference(self) -> Feature | None:
        """Cached ``Base::Anything::self``."""

    @property
    def that(self) -> Feature | None:
        """Cached ``Base::things::that``."""

    @property
    def this(self) -> Feature | None:
        """Cached ``Occurrences::Occurrence::this``."""

    @property
    def collection_elements(self) -> Feature | None:
        """Cached ``Collections::Collection::elements``."""

    @property
    def array_dimensions(self) -> Feature | None:
        """Cached ``Collections::Array::dimensions``."""

    @property
    def scalar_value(self) -> Type | None:
        """Cached ``ScalarValues::ScalarValue``."""

    @property
    def boolean(self) -> Type | None:
        """Cached ``ScalarValues::Boolean``."""

    @property
    def string(self) -> Type | None:
        """Cached ``ScalarValues::String``."""

    @property
    def numerical_value(self) -> Type | None:
        """Cached ``ScalarValues::NumericalValue``."""

    @property
    def number(self) -> Type | None:
        """Cached ``ScalarValues::Number``."""

    @property
    def complex(self) -> Type | None:
        """Cached ``ScalarValues::Complex``."""

    @property
    def real(self) -> Type | None:
        """Cached ``ScalarValues::Real``."""

    @property
    def rational(self) -> Type | None:
        """Cached ``ScalarValues::Rational``."""

    @property
    def integer(self) -> Type | None:
        """Cached ``ScalarValues::Integer``."""

    @property
    def natural(self) -> Type | None:
        """Cached ``ScalarValues::Natural``."""

    @property
    def positive(self) -> Type | None:
        """Cached ``ScalarValues::Positive``."""

    @property
    def metadata_annotated_element(self) -> Feature | None:
        """Cached ``Metaobjects::Metaobject::annotatedElement``."""

    @property
    def metaobject(self) -> Type | None:
        """Cached ``Metaobjects::Metaobject``."""

    @property
    def tensor_quantity_value(self) -> Type | None:
        """Cached ``Quantities::TensorQuantityValue``."""

    @property
    def tensor_measurement_reference(self) -> Type | None:
        """Cached ``MeasurementReferences::TensorMeasurementReference``."""

    @property
    def measurement_unit_conversion(self) -> Feature | None:
        """Cached ``MeasurementReferences::MeasurementUnit::unitConversion``."""

    @property
    def unit_conversion(self) -> Type | None:
        """Cached ``MeasurementReferences::UnitConversion``."""

    @property
    def unit_conversion_factor(self) -> Feature | None:
        """Cached ``MeasurementReferences::UnitConversion::conversionFactor``."""

    @property
    def unit_conversion_reference(self) -> Feature | None:
        """Cached ``MeasurementReferences::UnitConversion::referenceUnit``."""

    @property
    def unit_prefix(self) -> Type | None:
        """Cached ``MeasurementReferences::UnitPrefix``."""

    @property
    def unit_prefix_factor(self) -> Feature | None:
        """Cached ``MeasurementReferences::UnitPrefix::conversionFactor``."""

    @property
    def semantic_metadata(self) -> Type | None:
        """Cached ``Metaobjects::SemanticMetadata``."""

    @property
    def semantic_metadata_base_type(self) -> Feature | None:
        """Cached ``Metaobjects::SemanticMetadata::baseType``."""

    @property
    def metaclasses(self) -> ContainerView[Metaclass | MetadataDefinition | None]:
        """
        All cached metaclasses of metamodel from standard library packages ``KerML`` and ``SysML``.
        """

    def metaclass_for(self, arg: type[Element], /) -> Metaclass | MetadataDefinition | None:
        """Get a corresponding metaclass for model type."""

    @property
    def implicit_supertypes(self) -> ContainerView[Type | None]:
        """All cached types that are used as implicit supertypes by sema."""

    def implicit_supertype_for(self, type: type[Element], kind: ImplicitSpecializationKind) -> Type | None:
        """
        Get a corresponding implicit supertype for ``type`` and ``kind`` tuple.

        **Note:** not all combinations make sense and ``None`` will be returned in those cases.
        """

    @property
    def operator_functions(self) -> ContainerView[Function | None]:
        """
        Cached standard operator functions in the order of ``Operator`` values.
        """

    def operator_function_for(self, operator: Operator) -> Function | None:
        """
        Get a corresponding standard library operator function for ``operator``.
        """

    @property
    def visibility_kinds(self) -> ContainerView[Feature | None]:
        """Cached standard ``KerML::Root::VisibilityKind`` features."""

    def visibility_kind(self, arg: VisibilityKind, /) -> Feature | None:
        """
        Get a corresponding standard library ``KerML::Root::VisibilityKind`` feature.
        """

    @property
    def feature_direction_kinds(self) -> ContainerView[Feature | None]:
        """Cached standard ``KerML::Core::FeatureDirectionKind`` features."""

    def feature_direction_kind(self, arg: FeatureDirectionKind, /) -> Feature | None:
        """
        Get a corresponding standard library ``KerML::Core::FeatureDirectionKind`` feature.
        """

    @property
    def portion_kinds(self) -> ContainerView[EnumerationUsage | None]:
        """Cached standard ``SysML::Systems::PortionKind`` features."""

    def portion_kind(self, arg: PortionKind, /) -> EnumerationUsage | None:
        """
        Get a corresponding standard library ``SysML::Systems::PortionKind`` feature.
        """

    @property
    def requirement_constraint_kinds(self) -> ContainerView[EnumerationUsage | None]:
        """
        Cached standard ``SysML::Systems::RequirementConstraintKind`` features.
        """

    def requirement_constraint_kind(self, arg: RequirementConstraintKind, /) -> EnumerationUsage | None:
        """
        Get a corresponding standard library ``SysML::Systems::RequirementConstraintKind`` feature.
        """

    @property
    def state_subaction_kinds(self) -> ContainerView[EnumerationUsage | None]:
        """Cached standard ``SysML::Systems::StateSubactionKind`` features."""

    def state_subaction_kind(self, arg: StateSubactionKind, /) -> EnumerationUsage | None:
        """
        Get a corresponding standard library ``SysML::Systems::StateSubactionKind`` feature.
        """

    @property
    def transition_feature_kinds(self) -> ContainerView[EnumerationUsage | None]:
        """Cached standard ``SysML::Systems::TransitionFeatureKind`` features."""

    def transition_feature_kind(self, arg: TransitionFeatureKind, /) -> EnumerationUsage | None:
        """
        Get a corresponding standard library ``SysML::Systems::TransitionFeatureKind`` feature.
        """

    @property
    def trigger_kinds(self) -> ContainerView[EnumerationUsage | None]:
        """Cached standard ``SysML::Systems::TriggerKind`` features."""

    def trigger_kind(self, operator: TriggerKind) -> EnumerationUsage | None:
        """
        Get a corresponding standard library ``SysML::Systems::TriggerKind`` feature.
        """

    @property
    def literal_boolean(self) -> Type | None:
        """Cached ``ScalarValues::Boolean``."""

    @property
    def literal_string(self) -> Type | None:
        """Cached ``ScalarValues::String``."""

    @property
    def literal_rational(self) -> Type | None:
        """Cached ``ScalarValues::Rational``."""

    @property
    def literal_integer(self) -> Type | None:
        """Cached ``ScalarValues::Integer``."""

    @property
    def literal_natural(self) -> Type | None:
        """Cached ``ScalarValues::Natural``."""

    @property
    def literal_positive(self) -> Type | None:
        """Cached ``ScalarValues::Positive``."""

    __cpp_name__: str = 'syside::sysml::stdlib::Cached'

class CompilationReport:
    """Messages emitted during compilation or evaluation."""

    @property
    def fatal(self) -> bool:
        """Whether the compilation or evaluation completed with a fatal error."""

    @fatal.setter
    def fatal(self, arg: bool, /) -> None: ...

    @property
    def diagnostics(self) -> ContainerView[Diagnostic]:
        """Diagnostics emitted"""

    def __bool__(self) -> bool: ...

    __cpp_name__: str = 'syside::sysml::vm::CompilationReport'

class Compiler:
    """
    A non-recursive compiler/virtual machine for KerML and SysML expressions.

    Note that some patterns require cache of standard library elements to compute.
    See methods for more details.
    """

    def __init__(self, max_steps: int = 100000) -> None: ...

    @property
    def max_steps(self) -> int:
        """
        Maximum number of steps an expression evaluation may take.

        When this is reached, evaluation stops with an error. Actual steps are an
        implementation detail.
        """

    @max_steps.setter
    def max_steps(self, arg: int, /) -> None: ...

    def evaluate(self, expr: Expression | CalculationUsage | ConstraintUsage, stdlib: Stdlib | None = None, scope: Type | None | None = None, experimental_quantities: bool = False) -> tuple[Value | None, CompilationReport]:
        """
        Evaluate an expression ``expr``. Note that complex custom functions and
        expressions, and most except a few standard library functions are not
        evaluatable. Constructor expressions evaluate as their return parameters
        because they conform to the constructed object implicitly. This primarily
        evaluates operator, metadata access, and feature reference expressions.
        If provided, ``stdlib`` is used to accelerate some common evaluations,
        e.g. checking for ``self`` expressions.

        Quantity Evaluation
        -------------------

        .. versionadded:: 0.8.2

        If ``experimental_quantities`` is enabled, compiler will additionally
        attempt to evaluate scalar quantity expressions in SI units, other
        systems of quantities are not supported. The results will be returned in
        scalar ``float`` and no type-checking will be performed. In the future,
        when typed quantities are implemented, this may be changed.

        Note that quantity evaluation requires ``Stdlib`` to have found elements
        from ``MeasurementReferences`` library. Additionally, evaluation is
        tested to work with standard library quantities and prefixes. Custom
        package-level prefixes and quantities are also expected to work, however
        any nested feature chaining may or may not work.

        Reflection
        ----------

        .. versionadded:: 0.8.5

        Note that reflection (metadata access) is evaluated immediately on
        whatever symbol is referenced on the left. This means that inheritance
        and redefinitions have no effect - symbols will not be substituted based
        on scope during evaluation.

        User-defined Function Evaluation
        --------------------------------

        .. versionadded:: 0.8.5

        ``InvocationExpressions`` of simple user-defined function are supported
        as long they have either a ``ResultExpressionMembership``, declared as
        the last expression inside the body without a trailing ``;``, or a
        ``return`` feature. The former is preferred for performance reasons. As
        long the result or return expression is evaluatable by Syside and all
        input arguments have values, the invocation will be evaluated. Note that
        this does not add support for evaluating body expressions, like those
        used in ``collect`` and ``select`` expressions.
        """

    def evaluate_feature(self, feature: Feature, scope: Type, stdlib: Stdlib | None = None, experimental_quantities: bool = False) -> tuple[Value | None, CompilationReport]:
        """
        Evaluate ``feature`` in ``scope``, taking into account redefinitions.

        If ``feature`` is an ``Expression``, this effectively performs ``evaluate``.
        """

    def evaluate_filter(self, target: Element, filter: Expression, stdlib: Stdlib | None = None, functions: bool = True) -> tuple[Value | None, CompilationReport]:
        """
        Evaluate ``filter`` expression on the metadata of ``target``.

        .. versionadded:: 0.8.5

        Be aware that absolute feature references are resolved at the package level,
        thus if the filter expressions depends on a value of metadata attribute, use ``as``
        cast:

        .. code-block:: sysml

            metadata def Safety { attribute isMandatory; }
            filter (as Safety).isMandatory;

        The cast automatically doubles as a classification test ``@`` which can
        be omitted.

        Note that this does not support quantities because they are not model-level
        evaluable according to the specification, while filter expressions must be.

        While all non-operator functions are also not model-level evaluable, this allows evaluating
        function invocations if ``functions`` is set to give users more control
        over programmatic filtering. If specification conformant evaluation is required, use
        ``functions=False``.
        """

    __cpp_name__: str = 'syside::sysml::vm::Compiler'

class IndexedSymbol:
    """A statically indexed symbol"""

    @property
    def node(self) -> Element:
        """The indexed node"""

    @property
    def document(self) -> DocumentID:
        """The id of the document the node belongs to"""

    @property
    def library(self) -> LibraryID:
        """The id of the library the node belongs to"""

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = ...

class StaticIndex:
    """
    A static thread-safe index that allows multiple entries using the same name
    """

    def __init__(self) -> None: ...

    @overload
    def visit(self, arg0: str, arg1: Callable[[IndexedSymbol], None], /) -> None:
        """
        Visit all symbols with the provided name.

        .. code-block:: python

            symbol: IndexedSymbol | None = None

            def visitor(value: IndexedSymbol) -> None:
                nonlocal symbol
                symbol = value
                ...

            index.visit("mySymbol", visitor)
        """

    @overload
    def visit(self, arg0: Sequence[str], arg1: Callable[[str, IndexedSymbol], None], /) -> None:
        """
        Bulk visit all symbols with the provided names.

        .. code-block:: python

            symbol: IndexedSymbol | None = None

            def visitor(value: IndexedSymbol) -> None:
                nonlocal symbol
                symbol = value
                ...

            index.visit(("mySymbol0", "mySymbol1"), visitor)
        """

    @overload
    def visit_while(self, arg0: str, arg1: Callable[[IndexedSymbol], bool], /) -> None:
        """
        Visit all symbols with the provided name until visitor returns ``False``.

        .. code-block:: python

            symbol: IndexedSymbol | None = None

            def visitor(value: IndexedSymbol) -> bool:
                nonlocal symbol
                symbol = value
                ...

                return False

            index.visit_while("mySymbol", visitor)
        """

    @overload
    def visit_while(self, arg0: Sequence[str], arg1: Callable[[str, IndexedSymbol], bool], /) -> None:
        """
        Bulk visit all symbols with the provided names until visitor returns ``False``.

        .. code-block:: python

            symbol: IndexedSymbol | None = None

            def visitor(value: IndexedSymbol) -> bool:
                nonlocal symbol
                symbol = value
                ...

                return False

            index.visit_while(("mySymbol0", "mySymbol1"), visitor)
        """

    def insert(self, document: Document) -> int:
        """
        Add all symbols exported by ``document`` from this index. Returns the number of symbols added.

        **NOTE**: exported symbols must first be collected into the ``document``.
        """

    def erase(self, document: Document) -> int:
        """
        Remove all symbols exported by ``document`` from this index. Returns the number of symbols erased.

        **NOTE**: exported symbols must first be collected into the ``document``, and only symbols currently exported by ``document`` will be erased.
        """

    def reserve(self, arg: int, /) -> None:
        """
        Reserve memory for this index. This can reduce the number of allocations performed when adding new symbols to this index.
        """

    def clear(self) -> None:
        """Clear this index."""

    def clone(self) -> StaticIndex:
        """
        Clone this index. Modifications to one or the other index does not affect the other.
        """

    def __len__(self) -> int:
        """The number of different symbols name in this index."""

    def __bool__(self) -> bool:
        """Returns ``True`` if this index is not empty."""

    @property
    def empty(self) -> bool:
        """Returns ``True`` if this index contains no indexed symbols."""

    __cpp_name__: str = 'syside::StaticIndex<syside::sysml::SysMLTraits>'

class PipelineOptions:
    """Options for ``Pipeline`` construction."""

    def __init__(self, static_index: StaticIndex | None = None, lib: Stdlib | None = None) -> None:
        """
        Constructor for pipeline options.

        ``static_index`` and ``lib`` are optional, and empty containers will be constructed
        if not provided. On each run, the pipeline will update the bound ``static_index``
        and ``lib`` on every execution.
        """

    @property
    def static_index(self) -> StaticIndex:
        """
        Index used to resolve globally accessible names.

        Names in the index will only be used if the name resolution fails to resolve
        a name in any ancestor scopes, including inherited and imported names.
        """

    @static_index.setter
    def static_index(self, arg: StaticIndex, /) -> None: ...

    @property
    def lib(self) -> Stdlib:
        """
        Standard library cache used to resolve elements for semantic constraints.

        Note that the accessible elements must either be in the set of documents that are
        scheduled, or be accessible through the ``static_index``. Missing elements will
        result in incomplete semantic constraints and a lot of errors being reported.
        """

    @lib.setter
    def lib(self, arg: Stdlib, /) -> None: ...

    __cpp_name__: str = 'syside::sysml::PipelineOptions'

def make_pipeline(arg: PipelineOptions, /) -> Pipeline:
    """
    Creates a combined pipeline for parsing and analysing both KerML and SysML documents.
    """

class VisitAction(enum.Enum):
    """A strongly typed explicit visitation operation"""

    Continue = 0
    """Continue visitation"""

    Stop = 1
    """Stop visitation"""

class LazyIterator(Generic[T]):
    """
    A base type for all internally-iterated objects.

    Such objects are only iterable through ``.for_each`` method, rather than Python standard
    ``.__iter__``:

    .. code-block:: python

        def visitor(value: T) -> None | bool | VisitAction:
            ...

        iterator.for_each(visitor)

    This allows generating internally iterated sequences on-the-fly while keeping performance
    overhead low, e.g. combining multiple sequences while traversing a graph. In most cases,
    this is not as easy to implement with external iteration otherwise.
    """

    def at(self, arg0: int, /) -> T | None:
        """
        Get value at index. This is computed lazily. Returns ``None`` for out of bounds index.

        Notes:

        * Has complexity O(n) so should be used sparingly.
        * Only positive indices are allowed since size is unknown.
        """

    def __getitem__(self, arg0: int, /) -> T:
        """
        Get value at index, This is computed lazily. Throws ``IndexError`` on out of bounds.

        Notes:

        * Has complexity O(n) so should be used sparingly.
        * Only positive indices are allowed since size is unknown.
        """

    def empty(self) -> bool:
        """Check if this range is empty."""

    def __bool__(self) -> bool:
        """Returns ``True`` if this range is not empty."""

    def count(self) -> int:
        """Count the number of items in this range. This is computed lazily."""

    def collect(self) -> list[T]:
        """Collect all items into a ``list``."""

    def for_each(self, arg0: Callable[[T], None | bool | VisitAction], /) -> None:
        """
        Lazily visit each item in this range. Visitation is stopped on returning ``False`` or ``VisitAction.Stop``;
        """

class Stream(LazyIterator[T]):
    """A type-erased iterable"""

    def __iter__(self) -> Iterator[T]: ...

class ContainerView(Sequence[T]):
    """
    An immutable view into a native random-access container. Implements Sequence protocol.
    """

    def __contains__(self, value: object) -> bool: ...

    @overload
    def __getitem__(self, index: int) -> T: ...

    @overload
    def __getitem__(self, index: slice) -> list[T]: ...

    @overload
    def at(self, arg: int, /) -> T | None:
        """
        Get the value at ``index``.

        Returns ``None`` if ``index`` is out-of-bounds.
        """

    @overload
    def at(self, arg0: int, arg1: T, /) -> T:
        """
        Get the value at ``index``.

        Returns ``arg1`` if ``index`` is out-of-bounds.
        """

    def __iter__(self) -> Iterator[T]: ...

    def __reversed__(self) -> Iterator[T]: ...

    def __len__(self) -> int: ...

    def __bool__(self) -> bool:
        """Whether this container is not empty"""

    def empty(self) -> bool:
        """Whether this container is empty"""

    def count(self, value: T) -> int:
        """Returns the number of ``value`` occurrences in this container"""

    def index(self, value: T, start: int = 0, stop: int | None = None) -> int:
        """
        Returns the index of ``value`` in this container.

        Raises ``ValueError`` if ``value`` is not found.
        """

    def __str__(self) -> str: ...

class FeatureDirectionKind(enum.Enum):
    """
    Implementation of ``FeatureDirectionKind`` defined in the KerML
    specification.

    **Specification**:

       ``FeatureDirectionKind`` enumerates the possible kinds of
       ``direction`` that a ``Feature`` may be given as a member of a
       ``Type``.

    For language description, see section
    `7.3.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=58>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.1.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=165>`__
    of the KerML specification.
    """

    In = 0

    Inout = 1

    Out = 2

class PortionKind(enum.Enum):
    """
    Implementation of ``PortionKind`` defined in the SysML specification.

    **Specification**:

       ``PortionKind`` is an enumeration of the specific kinds of
       ``Occurrence`` portions that can be represented by an
       ``OccurrenceUsage``.

    For language description, see section
    `7.9.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=86>`__
    of the SysML specification. For more details on the model, see section
    `8.3.9.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=318>`__
    of the SysML specification.
    """

    Timeslice = 0

    Snapshot = 1

class RequirementConstraintKind(enum.Enum):
    """
    Implementation of ``RequirementConstraintKind`` defined in the SysML
    specification.

    **Specification**:

       A ``RequirementConstraintKind`` indicates whether a
       ``ConstraintUsage`` is an assumption or a requirement in a
       ``RequirementDefinition`` or ``RequirementUsage``.

    For language description, see section
    `7.21.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=165>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=387>`__
    of the SysML specification.
    """

    Assumption = 0

    Requirement = 1

class StateSubactionKind(enum.Enum):
    """
    Implementation of ``StateSubactionKind`` defined in the SysML
    specification.

    **Specification**:

       A ``StateSubactionKind`` indicates whether the ``action`` of a
       StateSubactionMembership is an entry, do or exit action.

    For language description, see section
    `7.18.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=149>`__
    of the SysML specification. For more details on the model, see section
    `8.3.18.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=365>`__
    of the SysML specification.
    """

    Entry = 0

    Do = 1

    Exit = 2

class TransitionFeatureKind(enum.Enum):
    """
    Implementation of ``TransitionFeatureKind`` defined in the SysML
    specification.

    **Specification**:

       A ``TransitionActionKind`` indicates whether the
       ``transition_feature`` of a ``TransitionFeatureMembership`` is a
       trigger, guard or effect.

    For language description, see section
    `7.18.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=151>`__
    of the SysML specification. For more details on the model, see section
    `8.3.18.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=371>`__
    of the SysML specification.
    """

    Trigger = 0

    Guard = 1

    Effect = 2

class TriggerKind(enum.Enum):
    """
    Implementation of ``TriggerKind`` defined in the SysML specification.

    **Specification**:

       ``TriggerKind`` enumerates the kinds of triggers that can be
       represented by a ``TriggerInvocationExpression``.

    For language description, see section
    `7.18.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=151>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.18 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=360>`__
    of the SysML specification.
    """

    When = 0

    At = 1

    After = 2

class VisibilityKind(enum.Enum):
    """
    Implementation of ``VisibilityKind`` defined in the KerML specification.

    **Specification**:

       ``VisibilityKind`` is an enumeration whose literals specify the
       visibility of a ``Membership`` of an ``Element`` in a ``Namespace``
       outside of that ``Namespace``. Note that “visibility” specifically
       restricts whether an ``Element`` in a ``Namespace`` may be referenced
       by name from outside the ``Namespace`` and only otherwise restricts
       access to an ``Element`` as provided by specific constraints in the
       abstract syntax (e.g., preventing the import or inheritance of
       private ``Elements``).

    For language description, see section
    `7.2.5.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=47>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.4.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=157>`__
    of the KerML specification.
    """

    Private = 0

    Protected = 1

    Public = 2

class ExplicitOperator(enum.Enum):
    """Operator that can be declared explicitly, e.g. excluding ``select``."""

    def __str__(self) -> str: ...

    If = 0

    NullCoalescing = 1

    Implies = 2

    LogicalOr = 3

    Or = 4

    Xor = 5

    LogicalAnd = 6

    And = 7

    Equals = 8

    Same = 9

    NotEquals = 10

    NotSame = 11

    IsType = 12

    HasType = 13

    At = 14

    AtAt = 15

    As = 16

    Meta = 17

    Less = 18

    LessEqual = 19

    Greater = 20

    GreaterEqual = 21

    Range = 22

    Plus = 23

    Minus = 24

    Multiply = 25

    Divide = 26

    Modulo = 27

    ExponentStar = 28

    ExponentCaret = 29

    Conjugation = 30

    Not = 31

    All = 32

    Quantity = 33

    Comma = 34

    def from_string(self) -> ExplicitOperator:
        """
        Convert an operator string to a corresponding enum value.

        Raises ``ValueError`` if conversion fails.
        """

class Operator(enum.Enum):
    """Any operator, including implicit operators"""

    def __str__(self) -> str: ...

    If = 0

    NullCoalescing = 1

    Implies = 2

    LogicalOr = 3

    Or = 4

    Xor = 5

    LogicalAnd = 6

    And = 7

    Equals = 8

    Same = 9

    NotEquals = 10

    NotSame = 11

    IsType = 12

    HasType = 13

    At = 14

    AtAt = 15

    As = 16

    Meta = 17

    Less = 18

    LessEqual = 19

    Greater = 20

    GreaterEqual = 21

    Range = 22

    Plus = 23

    Minus = 24

    Multiply = 25

    Divide = 26

    Modulo = 27

    ExponentStar = 28

    ExponentCaret = 29

    Conjugation = 30

    Not = 31

    All = 32

    Quantity = 33

    Comma = 34

    def from_string(self) -> Operator:
        """
        Convert an operator string to a corresponding enum value.

        Raises ``ValueError`` if conversion fails.
        """

    Dot = 36

    Collect = 37

    Index = 35

    Select = 38

class ModelLanguage(enum.Enum):
    """Language used to parse/build the model"""

    KerML = 1

    SysML = 0

class SemaState(enum.Enum):
    """
    Semantic resolution state of ``Elements``.

    Sema will use this information to discard duplicate work, e.g. when resolving
    elements in a group of related documents.
    """

    none = 0

    Active = 1

    Resolved = 2

    Cached = 3

class QualifiedName(Sequence[str]):
    """
    A sequence of qualified name segments that stringifies with unrestricted names as needed.

    Unlike string, this allows querying segments in a qualified name without having to parse it again,
    and is cheaper to construct as string conversion is performed only when needed.
    """

    @overload
    def __init__(self) -> None:
        """Default constructor"""

    @overload
    def __init__(self, arg: QualifiedName) -> None:
        """Copy constructor"""

    @overload
    def __init__(self, arg: Iterable[str], /) -> None:
        """Construct from an iterable object"""

    def __len__(self) -> int: ...

    def __bool__(self) -> bool:
        """Check whether the vector is nonempty"""

    def __repr__(self) -> str: ...

    @overload
    def __getitem__(self, arg: int, /) -> str: ...

    @overload
    def __getitem__(self, arg: slice, /) -> QualifiedName: ...

    def clear(self) -> None:
        """Remove all items from list."""

    def append(self, arg: str, /) -> None:
        """Append `arg` to the end of the list."""

    def insert(self, arg0: int, arg1: str, /) -> None:
        """Insert object `arg1` before index `arg0`."""

    def pop(self, index: int = -1) -> str:
        """Remove and return item at `index` (default last)."""

    def extend(self, arg: QualifiedName, /) -> None:
        """Extend `self` by appending elements from `arg`."""

    @overload
    def __setitem__(self, arg0: int, arg1: str, /) -> None: ...

    @overload
    def __setitem__(self, arg0: slice, arg1: QualifiedName, /) -> None: ...

    @overload
    def __delitem__(self, arg: int, /) -> None: ...

    @overload
    def __delitem__(self, arg: slice, /) -> None: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    @overload
    def __contains__(self, arg: str, /) -> bool: ...

    @overload
    def __contains__(self, arg: object, /) -> bool: ...

    def count(self, arg: str, /) -> int:
        """Return number of occurrences of `arg`."""

    def remove(self, arg: str, /) -> None:
        """Remove first occurrence of `arg`."""

    def __iter__(self) -> Iterator[str]: ...

    def __str__(self) -> str: ...

class Path(Sequence[str | int]):
    """
    A sequence of path segments that stringifies with unrestricted names as needed.

    Similar to ``QualifiedName`` but may contain indices to unnamed elements, that are
    printed literally with ``/`` separator instead.

    Note that indices are expected to use 1-based indexing according to the specification.
    """

    @overload
    def __init__(self) -> None:
        """Default constructor"""

    @overload
    def __init__(self, arg: Path) -> None:
        """Copy constructor"""

    @overload
    def __init__(self, arg: Iterable[str | int], /) -> None:
        """Construct from an iterable object"""

    def __len__(self) -> int: ...

    def __bool__(self) -> bool:
        """Check whether the vector is nonempty"""

    def __repr__(self) -> str: ...

    @overload
    def __getitem__(self, arg: int, /) -> str | int: ...

    @overload
    def __getitem__(self, arg: slice, /) -> Path: ...

    def clear(self) -> None:
        """Remove all items from list."""

    def append(self, arg: str | int, /) -> None:
        """Append `arg` to the end of the list."""

    def insert(self, arg0: int, arg1: str | int, /) -> None:
        """Insert object `arg1` before index `arg0`."""

    def pop(self, index: int = -1) -> str | int:
        """Remove and return item at `index` (default last)."""

    def extend(self, arg: Path, /) -> None:
        """Extend `self` by appending elements from `arg`."""

    @overload
    def __setitem__(self, arg0: int, arg1: str | int, /) -> None: ...

    @overload
    def __setitem__(self, arg0: slice, arg1: Path, /) -> None: ...

    @overload
    def __delitem__(self, arg: int, /) -> None: ...

    @overload
    def __delitem__(self, arg: slice, /) -> None: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    @overload
    def __contains__(self, arg: str | int, /) -> bool: ...

    @overload
    def __contains__(self, arg: object, /) -> bool: ...

    def count(self, arg: str | int, /) -> int:
        """Return number of occurrences of `arg`."""

    def remove(self, arg: str | int, /) -> None:
        """Remove first occurrence of `arg`."""

    def __iter__(self) -> Iterator[str | int]: ...

    def __str__(self) -> str: ...

    @property
    def to_owning_membership(self) -> bool:
        """
        If this is true, this path is to the owning membership of the element the
        segments would resolve to.

        This is a flag rather than a segment since owning memberships can effectively
        only ever be the last segment. When formatted, this will add ``/owningMembership``
        suffix.

        This flag should only be set if all the segments are names as owning memberships
        to elements without ``qualified_names`` are encoded purely with indices.
        """

    @to_owning_membership.setter
    def to_owning_membership(self, arg: bool, /) -> None: ...

class AstNode:
    """The basic type of all AST nodes."""

    def __str__(self) -> str: ...

    def __hash__(self) -> int:
        """
        Identity based hash of this node.

        This is guaranteed to be unique or nearly unique globally (due to bit mixing). However,
        it is not stable across Python invocations, and erased elements may be reused internally
        with the same hash.
        """

    @overload
    def isinstance(self, type: type[TNode]) -> _TypeGuard[TNode]:
        """Chainable equivalent to ``isintance(self, type)``"""

    @overload
    def isinstance(self, type: tuple[type[TNode], ...]) -> _TypeGuard[TNode]: ...

    @overload
    def try_cast(self, type: tuple[type[TNode], ...]) -> TNode | None:
        """
        Checked cast to ``type``.

        Similar to ``typing.cast(type, self)`` except this returns ``None`` if the cast fails.
        """

    @overload
    def try_cast(self, *type: type[TNode]) -> TNode | None: ...

    @overload
    def cast(self, type: tuple[type[TNode], ...]) -> TNode: ...

    @overload
    def cast(self, *type: type[TNode]) -> TNode:
        """
        Checked cast to ``type``.

        Similar to ``typing.cast(type, self)`` except this raises ``TypeError`` if the cast fails.
        """

    @property
    def parent(self) -> Element | None:
        """The parent node of ``self``."""

    @property
    def document(self) -> Document:
        """
        The ``document`` that owns this node.

        In Syside, all AST nodes are attached to their owning documents, this improves performance
        and ergonomics in certain places at the cost of not being able to move nodes between
        documents.

        Note that this assumes that the returned ``document`` and all of its transitive dependencies
        will not be accessed from other threads, e.g. by acquiring locks to all dependent
        (downstream) documents.
        """

    @property
    def cst_node(self) -> CstNode | None:
        """
        The source `CST <https://en.wikipedia.org/wiki/Parse_tree>`__ node of ``self`` if one exists.

        This is only available on nodes parsed from text sources, and only on nodes that have
        not been created implicitly to satisfy some constraints.
        """

    @property
    def owned_elements(self) -> LazyIterator[Element]:
        """Returns a view into all elements directly owned by this ``Element``."""

TNode = TypeVar("TNode", bound=AstNode)
"""Generic ``AstNode`` type variable"""

class Element(AstNode):
    """
    Implementation of ``Element`` defined in the KerML specification.

    **Specification**:

       An ``Element`` is a constituent of a model that is uniquely
       identified relative to all other ``Elements``. It can have
       ``Relationships`` with other ``Elements``. Some of these
       ``Relationships`` might imply ownership of other ``Elements``, which
       means that if an ``Element`` is deleted from a model, then so are all
       the ``Elements`` that it owns.

    For language description, see section
    `7.2.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=41>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=135>`__
    of the KerML specification.
    """

    def __str__(self) -> str: ...

    __cpp_name__: str = 'syside::sysml::Element'

    STD: tuple[type[Element], ...] = ...
    """
    All subtypes of ``Element`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Element.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Element.STD):
            ...

    For type hints, instead use ``Element.Std``:

    .. code-block:: python

        def function(element: Element) -> Element.Std:
            ...

    Note that ``Element.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Element.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Element
        """Type hint for all subtypes of ``Element`` according to the specification"""

    @property
    def element_id(self) -> uuid.UUID:
        """
        Implementation of ``element_id`` defined in the KerML specification.

        **Specification**:

           The globally unique identifier for this Element. This is intended to
           be set by tooling, and it must not change during the lifetime of the
           Element.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=136>`__
        of the KerML specification for more details.

        Note that ``element_id`` may be deprecated in a future release to improve
        performance as it has no use outside of serialization. In such cases, we may
        instead create and store ``element_ids`` only during serialization. Otherwise
        ``__hash__`` is guaranteed to remain stable while the ``Element`` is alive,
        however it may be reused on ``Document`` rebuilds.

        See :py:attr:`Element.path <syside.Element.path>` for more details as ``element_id``
        is generated based on it.

        We reserve the option to change non-standard element id generation in future
        versions.
        """

    @element_id.setter
    def element_id(self, arg: uuid.UUID, /) -> None: ...

    @property
    def sema_state(self) -> SemaState:
        """
        The state of semantic resolution for this ``Element``. Based on this, sema may skip elements to avoid duplicate work, e.g. when resolving elements in a group of related documents.
        """

    @sema_state.setter
    def sema_state(self, arg: SemaState, /) -> None: ...

    @property
    def declared_name(self) -> str | None:
        """
        Implementation of ``declared_name`` defined in the KerML specification.

        **Specification**:

           The declared name of this ``Element``.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=136>`__
        of the KerML specification for more details.
        """

    @declared_name.setter
    def declared_name(self, arg: str | None) -> None: ...

    @property
    def declared_short_name(self) -> str | None:
        """
        Implementation of ``declared_short_name`` defined in the KerML
        specification.

        **Specification**:

           An optional alternative name for the ``Element`` that is intended to
           be shorter or in some way more succinct than its primary ``name``. It
           may act as a modeler-specified identifier for the ``Element``, though
           it is then the responsibility of the modeler to maintain the
           uniqueness of this identifier within a model or relative to some
           other context.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=136>`__
        of the KerML specification for more details.
        """

    @declared_short_name.setter
    def declared_short_name(self, arg: str | None) -> None: ...

    @property
    def name(self) -> str | None:
        """
        Implementation of ``name`` defined in the KerML specification.

        **Specification**:

           The name to be used for this ``Element`` during name resolution
           within its ``owning_namespace``. This is derived using the
           ``effective_name()`` operation. By default, it is the same as the
           ``declared_name``, but this is overridden for certain kinds of
           ``Elements`` to compute a ``name`` even when the ``declared_name`` is
           null.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=136>`__
        of the KerML specification for more details.
        """

    @property
    def short_name(self) -> str | None:
        """
        Implementation of ``short_name`` defined in the KerML specification.

        **Specification**:

           The short name to be used for this ``Element`` during name resolution
           within its ``owning_namespace``. This is derived using the
           ``effective_short_name()`` operation. By default, it is the same as
           the ``declared_short_name``, but this is overridden for certain kinds
           of ``Elements`` to compute a ``short_name`` even when the
           ``declared_name`` is null.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=137>`__
        of the KerML specification for more details.
        """

    @property
    def qualified_name(self) -> QualifiedName | None:
        """
        Implementation of ``qualified_name`` defined in the KerML specification.

        **Specification**:

           The full ownership-qualified name of this ``Element``, represented in
           a form that is valid according to the KerML textual concrete syntax
           for qualified names (including use of unrestricted name notation and
           escaped characters, as necessary). The ``qualified_name`` is null if
           this ``Element`` has no ``owning_namespace`` or if there is not a
           complete ownership chain of named ``Namespaces`` from a root
           ``Namespace`` to this ``Element``. If the ``owning_namespace`` has
           other ``Elements`` with the same name as this one, then the
           ``qualified_name`` is null for all such ``Elements`` other than the
           first.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=137>`__
        of the KerML specification for more details.
        """

    @property
    def path(self) -> Path:
        """
        Return a unique description of the location of this ``Element`` in the
        containment structure rooted in a root ``Namespace``. In most cases the
        segments will be identical to ``QualifiedName``.

        For example, an ``OwningMembership`` will return its ``owned_member_element``
        path with ``to_owning_membership == True``.

        While ``paths`` will be unique per document, any ``paths`` with indices may
        not be stable across parses. This is because implicit elements are added
        incrementally and they themselves affect element indices, however whether and
        the order in which they are added are dependent on the order the documents
        are parsed in. Unclear interdependencies between documents and officially
        supported cyclical dependencies do not make this any easier.

        *NOTE* that position indices are 1-based according to the specification.

        *NOTE* that this has ``O(d)`` complexity at best and ``O(dn)`` at worst where
        ``d`` is the tree depth, and ``n`` - number of owned elements. The best case
        is achieved when ``path`` is equivalent to ``qualified_name`` and only
        ancestor names need to be looked up. Otherwise, an additional linear search
        for the position index is required for every ancestor that has no
        ``qualified_name``.
        """

    def matches_qualified_name(self, arg: Sequence[str], /) -> bool:
        """
        Check if the qualified name of this ``Element`` matches the provided segments of a qualified name.
        """

    @property
    def is_implied_included(self) -> bool:
        """
        Implementation of ``is_implied_included`` defined in the KerML
        specification.

        **Specification**:

           Whether all necessary implied Relationships have been included in the
           ``owned_relationships`` of this Element. This property may be true,
           even if there are not actually any ``owned_relationships`` with
           ``is_implied = true``, meaning that no such Relationships are
           actually implied for this Element. However, if it is false, then
           ``owned_relationships`` may *not* contain any implied Relationships.
           That is, either *all* required implied Relationships must be
           included, or none of them.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=136>`__
        of the KerML specification for more details.
        """

    @property
    def is_library_element(self) -> bool:
        """
        Implementation of ``is_library_element`` defined in the KerML
        specification.

        **Specification**:

           Whether this Element is contained in the ownership tree of a library
           model.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=136>`__
        of the KerML specification for more details.
        """

    @property
    def owning_membership(self) -> OwningMembership | None:
        """
        Implementation of ``owning_membership`` defined in the KerML
        specification.

        **Specification**:

           The ``owning_relationship`` of this ``Element``, if that
           ``Relationship`` is a ``Membership``.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=137>`__
        of the KerML specification for more details.
        """

    @property
    def owned_relationships(self) -> LazyIterator[Relationship]:
        """
        Implementation of ``owned_relationship`` defined in the KerML
        specification.

        **Specification**:

           The Relationships for which this Element is the
           owning_related_element.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=136>`__
        of the KerML specification for more details.
        """

    @property
    def owning_relationship(self) -> Relationship | None:
        """
        Implementation of ``owning_relationship`` defined in the KerML
        specification.

        **Specification**:

           The Relationship for which this Element is an owned_related_element,
           if any.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=137>`__
        of the KerML specification for more details.
        """

    @property
    def owning_namespace(self) -> Namespace | None:
        """
        Implementation of ``owning_namespace`` defined in the KerML
        specification.

        **Specification**:

           The ``Namespace`` that owns this ``Element``, which is the
           ``membership_owning_namespace`` of the ``owning_membership`` of this
           ``Element``, if any.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=137>`__
        of the KerML specification for more details.
        """

    @property
    def owner(self) -> Element | None:
        """
        Implementation of ``owner`` defined in the KerML specification.

        **Specification**:

           The owner of this Element, derived as the ``owning_related_element``
           of the ``owning_relationship`` of this Element, if any.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=137>`__
        of the KerML specification for more details.
        """

    @property
    def scoped_owner(self) -> Element | None:
        """
        The owner of this ``Element`` as the parent of ``owning_membership`` or ``owning_relationship`` otherwise.
        """

    @property
    def owned_elements(self) -> LazyIterator[Element]:
        """
        Implementation of ``owned_element`` defined in the KerML specification.

        **Specification**:

           The Elements owned by this Element, derived as the
           owned_related_elements of the owned_relationships of this Element.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=136>`__
        of the KerML specification for more details.
        """

    @property
    def documentation(self) -> LazyIterator[Documentation]:
        """
        Implementation of ``documentation`` defined in the KerML specification.

        **Specification**:

           The Documentation owned by this Element.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=136>`__
        of the KerML specification for more details.
        """

    @property
    def owned_annotations(self) -> LazyIterator[Annotation]:
        """
        Implementation of ``owned_annotation`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``Element`` that are
           ``Annotations``, for which this ``Element`` is the
           ``annotated_element``.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=136>`__
        of the KerML specification for more details.
        """

    @property
    def comments(self) -> LazyIterator[Comment]:
        """The owned ``Comments`` related by ``owned_relationships``."""

    @property
    def textual_representations(self) -> LazyIterator[TextualRepresentation]:
        """
        Implementation of ``textual_representation`` defined in the KerML
        specification.

        **Specification**:

           The ``TextualRepresentations`` that annotate this ``Element``.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=137>`__
        of the KerML specification for more details.
        """

    @property
    def metadata(self) -> LazyIterator[MetadataFeature | MetadataUsage]:
        """The owned metadata related by ``owned_relationships``."""

    @property
    def alias_ids(self) -> list[str]:
        """
        Implementation of ``alias_ids`` defined in the KerML specification.

        **Specification**:

           Various alternative identifiers for this Element. Generally, these
           will be set by tools.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=136>`__
        of the KerML specification for more details.
        """

TElement = TypeVar("TElement", bound=Element)
"""Generic type variable"""

class Namespace(Element):
    """
    Implementation of ``Namespace`` defined in the KerML specification.

    **Specification**:

       A ``Namespace`` is an ``Element`` that contains other ``Elements``,
       known as its ``members``, via ``Membership`` ``Relationships`` with
       those ``Elements``. The ``members`` of a ``Namespace`` may be owned
       by the ``Namespace``, aliased in the ``Namespace``, or imported into
       the ``Namespace`` via ``Import`` ``Relationships``.

       A ``Namespace`` can provide names for its ``members`` via the
       ``member_names`` and ``member_short_names`` specified by the
       ``Memberships`` in the ``Namespace``. If a ``Membership`` specifies a
       ``member_name`` and/or ``member_short_name``, then those are names of
       the corresponding ``member_element`` relative to the ``Namespace``.
       For an ``OwningMembership``, the ``owned_member_name`` and
       ``owned_member_short_name`` are given by the ``Element`` ``name`` and
       ``short_name``. Note that the same ``Element`` may be the
       ``member_element`` of multiple ``Memberships`` in a ``Namespace``
       (though it may be owned at most once), each of which may define a
       separate alias for the ``Element`` relative to the ``Namespace``.

    For language description, see section
    `7.2.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=47>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.4.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=153>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Namespace'

    STD: tuple[type[Namespace], ...] = ...
    """
    All subtypes of ``Namespace`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Namespace.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Namespace.STD):
            ...

    For type hints, instead use ``Namespace.Std``:

    .. code-block:: python

        def function(element: Element) -> Namespace.Std:
            ...

    Note that ``Namespace.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Namespace.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Namespace
        """Type hint for all subtypes of ``Namespace`` according to the specification"""

    @property
    def prefixes(self) -> NamespacePrefixes:
        """Metadata prefixes, prefixed with ``#`` in textual syntax."""

    @property
    def children(self) -> NamespaceBody:
        """The elements enclosed by curly brackets in textual syntax."""

    @property
    def owned_memberships(self) -> LazyIterator[Membership]:
        """
        Implementation of ``owned_membership`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``Namespace`` that are
           ``Memberships``, for which the ``Namespace`` is the
           ``membership_owning_namespace``.

        See section
        `8.3.2.4.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=154>`__
        of the KerML specification for more details.
        """

    @property
    def imported_memberships(self) -> LazyImportsIterator[Membership]:
        """
        Implementation of ``imported_membership`` defined in the KerML
        specification.

        **Specification**:

           The ``Memberships`` in this ``Namespace`` that result from the
           ``owned_imports`` of this ``Namespace``.

        See section
        `8.3.2.4.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=153>`__
        of the KerML specification for more details.
        """

    @property
    def owned_members(self) -> LazyIterator[Element]:
        """
        Implementation of ``owned_member`` defined in the KerML specification.

        **Specification**:

           The owned ``members`` of this ``Namespace``, which are the
           ``owned_member_elements`` of the ``owned_memberships`` of the
           ``Namespace``.

        See section
        `8.3.2.4.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=153>`__
        of the KerML specification for more details.
        """

    @property
    def memberships(self) -> LazyImportsIterator[Membership]:
        """
        Implementation of ``membership`` defined in the KerML specification.

        **Specification**:

           All ``Memberships`` in this ``Namespace``, including (at least) the
           union of ``owned_memberships`` and ``imported_memberships``.

        See section
        `8.3.2.4.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=153>`__
        of the KerML specification for more details.
        """

    @property
    def members(self) -> LazyImportsIterator[Element]:
        """
        Implementation of ``member`` defined in the KerML specification.

        **Specification**:

           The set of all member ``Elements`` of this ``Namespace``, which are
           the ``member_elements`` of all ``memberships`` of the ``Namespace``.

        See section
        `8.3.2.4.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=153>`__
        of the KerML specification for more details.
        """

    @property
    def owned_imports(self) -> LazyIterator[Import]:
        """
        Implementation of ``owned_import`` defined in the KerML specification.

        **Specification**:

           The ``owned_relationships`` of this ``Namespace`` that are
           ``Imports``, for which the ``Namespace`` is the
           ``import_owning_namespace``.

        See section
        `8.3.2.4.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=153>`__
        of the KerML specification for more details.
        """

    def __getitem__(self, arg: str, /) -> Element:
        """
        Access owned named members by name. Throws ``KeyError`` if a member with such name does not exist.
        """

    @overload
    def get_membership(self, arg: str, /) -> Membership | None:
        """
        Access owned memberships by name. Returns None if an owned member or membership with such name does not exist.
        """

    @overload
    def get_membership(self, arg0: str, arg1: Membership, /) -> Membership:
        """
        Overload for ``get_membership`` that returns the last argument if a member was not found.
        """

    @overload
    def get_member(self, arg: str, /) -> Element | None:
        """
        Non-throwing variant of ``__getitem__``. Returns None if a named member was not found.
        """

    @overload
    def get_member(self, arg0: str, arg1: Element, /) -> Element:
        """
        Overload for ``get_member`` that returns the last argument if a member was not found.
        """

class Relationship(Element):
    """
    Implementation of ``Relationship`` defined in the KerML specification.

    **Specification**:

       A ``Relationship`` is an ``Element`` that relates other ``Element``.
       Some of its ``related_elements`` may be owned, in which case those
       ``owned_related_elements`` will be deleted from a model if their
       ``owning_relationship`` is. A ``Relationship`` may also be owned by
       another ``Element``, in which case the ``owned_related_elements`` of
       the ``Relationship`` are also considered to be transitively owned by
       the ``owning_related_element`` of the ``Relationship``.

       The ``related_elements`` of a ``Relationship`` are divided into
       ``source`` and ``target`` ``Elements``. The ``Relationship`` is
       considered to be directed from the ``source`` to the ``target``
       ``Elements``. An undirected ``Relationship`` may have either all
       ``source`` or all ``target`` ``Elements``.

       A “relationship ``Element``” in the abstract syntax is generically
       any ``Element`` that is an instance of either ``Relationship`` or a
       direct or indirect specialization of ``Relationship``. Any other kind
       of ``Element`` is a “non-relationship ``Element``”. It is a
       convention of that non-relationship ``Elements`` are *only* related
       via reified relationship ``Elements``. Any meta-associations directly
       between non-relationship ``Elements`` must be derived from underlying
       reified ``Relationship``.

    For language description, see section
    `7.2.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=41>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Relationship'

    STD: tuple[Union[type[Relationship], type[Association], type[ConnectionDefinition], type[Connector], type[ConnectorAsUsage], type[FlowDefinition]], ...] = ...
    """
    All subtypes of ``Relationship`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Relationship.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Relationship.STD):
            ...

    For type hints, instead use ``Relationship.Std``:

    .. code-block:: python

        def function(element: Element) -> Relationship.Std:
            ...

    Note that ``Relationship.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Relationship.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[Relationship, Association, ConnectionDefinition, Connector, ConnectorAsUsage, FlowDefinition]
        """Type hint for all subtypes of ``Relationship`` according to the specification"""

    @property
    def is_implied(self) -> bool:
        """
        Implementation of ``is_implied`` defined in the KerML specification.

        **Specification**:

           Whether this Relationship was generated by tooling to meet semantic
           rules, rather than being directly created by a modeler.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @is_implied.setter
    def is_implied(self, arg: bool, /) -> None: ...

    @property
    def visibility(self) -> VisibilityKind:
        """
        The visibility level of the related elements from this ``Relationship`` relative to the ``owning_related_element``.

        Raises ``TypeError`` if visibility is immutable, e.g. on ``Expose`` elements.
        """

    @visibility.setter
    def visibility(self, arg: VisibilityKind | None) -> None: ...

    def try_set_visibility(self, arg: VisibilityKind | None) -> bool:
        """Non-throwing alternative to ``visibility`` setter."""

    def reset_visibility(self) -> None:
        """Reset visibility to its implicit value."""

    @property
    def is_visibility_implied(self) -> bool:
        """
        Returns ``True`` if this ``Relationship`` is using implicit visibility.
        """

    @property
    def owning_related_element(self) -> Element | None:
        """
        Implementation of ``owning_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_element of this Relationship that owns the Relationship,
           if any.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def sources(self) -> ContainerView[Element]:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def targets(self) -> ContainerView[Element]:
        """
        Implementation of ``target`` defined in the KerML specification.

        **Specification**:

           The ``related_elements`` to which this Relationship is considered to
           be directed.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def related_elements(self) -> LazyIterator[Element]:
        """
        Implementation of ``related_element`` defined in the KerML
        specification.

        **Specification**:

           The Elements that are related by this Relationship, derived as the
           union of the ``source`` and ``target`` Elements of the Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def first_source(self) -> Element | None:
        """Convenience method for sources[0]."""

    @property
    def first_target(self) -> Element | None:
        """Convenience method for targets[0]."""

    @property
    def owned_related_elements(self) -> LazyIterator[Element]:
        """
        Implementation of ``owned_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_elements of this Relationship that are owned by the
           Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

class Membership(Relationship):
    """
    Implementation of ``Membership`` defined in the KerML specification.

    **Specification**:

       A ``Membership`` is a ``Relationship`` between a ``Namespace`` and an
       ``Element`` that indicates the ``Element`` is a ``member`` of (i.e.,
       is contained in) the Namespace. Any ``member_names`` specify how the
       ``member_element`` is identified in the ``Namespace`` and the
       ``visibility`` specifies whether or not the ``member_element`` is
       publicly visible from outside the ``Namespace``.

       If a ``Membership`` is an ``OwningMembership``, then it owns its
       ``member_element``, which becomes an ``owned_member`` of the
       ``membership_owning_namespace``. Otherwise, the ``member_names`` of a
       ``Membership`` are effectively aliases within the
       ``membership_owning_namespace`` for an ``Element`` with a separate
       ``OwningMembership`` in the same or a different ``Namespace``.

    For language description, see section
    `7.2.5.1 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=47>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.4.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=151>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Membership'

    STD: tuple[type[Membership], ...] = ...
    """
    All subtypes of ``Membership`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Membership.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Membership.STD):
            ...

    For type hints, instead use ``Membership.Std``:

    .. code-block:: python

        def function(element: Element) -> Membership.Std:
            ...

    Note that ``Membership.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Membership.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Membership
        """Type hint for all subtypes of ``Membership`` according to the specification"""

    @property
    def is_initial_node(self) -> bool:
        """
        Returns ``True`` if this ``Membership`` was parsed from ``InitialNode`` syntax rule.
        """

    @is_initial_node.setter
    def is_initial_node(self, arg: bool, /) -> None: ...

    @property
    def owning_related_element(self) -> Element | None:
        """
        Implementation of ``owning_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_element of this Relationship that owns the Relationship,
           if any.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def sources(self) -> ContainerView[Element]:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def targets(self) -> ContainerView[Element]:
        """
        Implementation of ``target`` defined in the KerML specification.

        **Specification**:

           The ``related_elements`` to which this Relationship is considered to
           be directed.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def member_element_id(self) -> uuid.UUID:
        """
        Implementation of ``member_element_id`` defined in the KerML
        specification.

        **Specification**:

           The ``element_id`` of the ``member_element``.

        See section
        `8.3.2.4.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=151>`__
        of the KerML specification for more details.
        """

    @property
    def member_short_name(self) -> str | None:
        """
        Implementation of ``member_short_name`` defined in the KerML
        specification.

        **Specification**:

           The short name of the ``member_element`` relative to the
           ``membership_owning_namespace``.

        See section
        `8.3.2.4.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=151>`__
        of the KerML specification for more details.
        """

    @property
    def member_name(self) -> str | None:
        """
        Implementation of ``member_name`` defined in the KerML specification.

        **Specification**:

           The name of the ``member_element`` relative to the
           ``membership_owning_namespace``.

        See section
        `8.3.2.4.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=151>`__
        of the KerML specification for more details.
        """

    @property
    def membership_owning_namespace(self) -> Namespace | None:
        """
        Implementation of ``membership_owning_namespace`` defined in the KerML
        specification.

        **Specification**:

           The ``Namespace`` of which the ``member_element`` becomes a
           ``member`` due to this ``Membership``.

        See section
        `8.3.2.4.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=151>`__
        of the KerML specification for more details.
        """

    @property
    def member_element(self) -> Element | None:
        """
        Implementation of ``member_element`` defined in the KerML specification.

        **Specification**:

           The ``Element`` that becomes a ``member`` of the
           ``membership_owning_namespace`` due to this ``Membership``.

        See section
        `8.3.2.4.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=151>`__
        of the KerML specification for more details.
        """

    @property
    def children(self) -> RelationshipBody:
        """The elements enclosed by curly brackets in textual syntax."""

class OwningMembership(Membership):
    """
    Implementation of ``OwningMembership`` defined in the KerML
    specification.

    **Specification**:

       An ``OwningMembership`` is a ``Membership`` that owns its
       ``member_element`` as a ``owned_related_element``. The
       ``owned_member_element`` becomes an ``owned_member`` of the
       ``membership_owning_namespace``.

    For language description, see section
    `7.2.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=47>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.4.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=158>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::OwningMembership'

    STD: tuple[type[OwningMembership], ...] = ...
    """
    All subtypes of ``OwningMembership`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``OwningMembership.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, OwningMembership.STD):
            ...

    For type hints, instead use ``OwningMembership.Std``:

    .. code-block:: python

        def function(element: Element) -> OwningMembership.Std:
            ...

    Note that ``OwningMembership.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "OwningMembership.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = OwningMembership
        """Type hint for all subtypes of ``OwningMembership`` according to the specification"""

    @property
    def owned_member_element_id(self) -> uuid.UUID:
        """
        Implementation of ``owned_member_element_id`` defined in the KerML
        specification.

        **Specification**:

           The ``element_id`` of the ``owned_member_element``.

        See section
        `8.3.2.4.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=158>`__
        of the KerML specification for more details.
        """

    @property
    def owned_member_short_name(self) -> str | None:
        """
        Implementation of ``owned_member_short_name`` defined in the KerML
        specification.

        **Specification**:

           The ``short_name`` of the ``owned_member_element``.

        See section
        `8.3.2.4.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=158>`__
        of the KerML specification for more details.
        """

    @property
    def owned_member_name(self) -> str | None:
        """
        Implementation of ``owned_member_name`` defined in the KerML
        specification.

        **Specification**:

           The ``name`` of the ``owned_member_element``.

        See section
        `8.3.2.4.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=158>`__
        of the KerML specification for more details.
        """

    @property
    def owned_member_element(self) -> Element | None:
        """
        Implementation of ``owned_member_element`` defined in the KerML
        specification.

        **Specification**:

           The ``Element`` that becomes an ``owned_member`` of the
           ``membership_owning_namespace`` due to this ``OwningMembership``.

        See section
        `8.3.2.4.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=158>`__
        of the KerML specification for more details.
        """

class Dependency(Relationship):
    """
    Implementation of ``Dependency`` defined in the KerML specification.

    **Specification**:

       A ``Dependency`` is a ``Relationship`` that indicates that one or
       more ``client`` ``Elements`` require one more ``supplier``
       ``Elements`` for their complete specification. In general, this means
       that a change to one of the ``supplier`` ``Elements`` may necessitate
       a change to, or re-specification of, the ``client`` ``Elements``.

       Note that a ``Dependency`` is entirely a model-level
       ``Relationship``, without instance-level semantics.

    For language description, see section
    `7.2.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=43>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.2.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=142>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Dependency'

    STD: tuple[type[Dependency], ...] = ...
    """
    All subtypes of ``Dependency`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Dependency.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Dependency.STD):
            ...

    For type hints, instead use ``Dependency.Std``:

    .. code-block:: python

        def function(element: Element) -> Dependency.Std:
            ...

    Note that ``Dependency.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Dependency.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Dependency
        """Type hint for all subtypes of ``Dependency`` according to the specification"""

    @property
    def prefixes(self) -> DependencyPrefixes:
        """Metadata prefixes, prefixed with ``#`` in textual syntax."""

    @property
    def clients(self) -> DependencyEnds:
        """
        Implementation of ``client`` defined in the KerML specification.

        **Specification**:

           The ``Element`` or ``Elements`` dependent on the ``supplier``
           ``Elements``.

        See section
        `8.3.2.2.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=142>`__
        of the KerML specification for more details.
        """

    @property
    def suppliers(self) -> DependencyEnds:
        """
        Implementation of ``supplier`` defined in the KerML specification.

        **Specification**:

           The ``Element`` or ``Elements`` on which the ``client`` ``Elements``
           depend in some respect.

        See section
        `8.3.2.2.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=142>`__
        of the KerML specification for more details.
        """

    @property
    def children(self) -> RelationshipBody:
        """The elements enclosed by curly brackets in textual syntax."""

    @property
    def owning_related_element(self) -> Element | None:
        """
        Implementation of ``owning_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_element of this Relationship that owns the Relationship,
           if any.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def sources(self) -> ContainerView[Element]:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def targets(self) -> ContainerView[Element]:
        """
        Implementation of ``target`` defined in the KerML specification.

        **Specification**:

           The ``related_elements`` to which this Relationship is considered to
           be directed.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

class Import(Relationship):
    """
    Implementation of ``Import`` defined in the KerML specification.

    **Specification**:

       An ``Import`` is an ``Relationship`` between its
       ``import_owning_namespace`` and either a ``Membership`` (for a
       ``MembershipImport``) or another ``Namespace`` (for a
       ``NamespaceImport``), which determines a set of ``Memberships`` that
       become ``imported_memberships`` of the ``import_owning_namespace``.
       If ``is_import_all = false`` (the default), then only public
       ``Memberships`` are considered “visible”. If
       ``is_import_all = true``, then all ``Memberships`` are considered
       “visible”, regardless of their declared ``visibility``. If
       ``is_recursive = true``, then visible ``Memberships`` are also
       recursively imported from owned sub-``Namespaces``.

    For language description, see section
    `7.2.5.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=49>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=150>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Import'

    STD: tuple[type[Import], ...] = ...
    """
    All subtypes of ``Import`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Import.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Import.STD):
            ...

    For type hints, instead use ``Import.Std``:

    .. code-block:: python

        def function(element: Element) -> Import.Std:
            ...

    Note that ``Import.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Import.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Import
        """Type hint for all subtypes of ``Import`` according to the specification"""

    @property
    def is_recursive(self) -> bool:
        """
        Implementation of ``is_recursive`` defined in the KerML specification.

        **Specification**:

           Whether to recursively import Memberships from visible, owned
           sub-Namespaces.

        See section
        `8.3.2.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=150>`__
        of the KerML specification for more details.
        """

    @is_recursive.setter
    def is_recursive(self, arg: bool, /) -> None: ...

    @property
    def is_import_all(self) -> bool:
        """
        Implementation of ``is_import_all`` defined in the KerML specification.

        **Specification**:

           Whether to import memberships without regard to declared visibility.

        See section
        `8.3.2.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=150>`__
        of the KerML specification for more details.


        The setter will throw ``TypeError`` on ``Expose`` elements which are always ``is_import_all``.
        Use ``try_set_is_import_all`` instead for a non-throwing behaviour.
        """

    @is_import_all.setter
    def is_import_all(self, arg: bool, /) -> None: ...

    def try_set_is_import_all(self, arg: bool, /) -> bool:
        """
        Try setting ``is_import_all``. For ``Expose`` elements, this will return ``False`` instead of throwing ``TypeError`` when using ``is_import_all`` setter.
        """

    @property
    def import_target(self) -> Membership | Namespace | None:
        """The target element of this ``Import``."""

    @property
    def imported_element(self) -> Element | None:
        """
        Implementation of ``imported_element`` defined in the KerML
        specification.

        **Specification**:

           The effectively imported ``Element`` for this Import. For a
           ``MembershipImport``, this is the ``member_element`` of the
           ``imported_membership``. For a ``NamespaceImport``, it is the
           ``imported_namespace``.

        See section
        `8.3.2.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=150>`__
        of the KerML specification for more details.
        """

    @property
    def import_owning_namespace(self) -> Namespace | None:
        """
        Implementation of ``import_owning_namespace`` defined in the KerML
        specification.

        **Specification**:

           The Namespace into which Memberships are imported by this Import,
           which must be the ``owning_related_element`` of the Import.

        See section
        `8.3.2.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=150>`__
        of the KerML specification for more details.
        """

    @property
    def children(self) -> RelationshipBody:
        """The elements enclosed by curly brackets in textual syntax."""

    @property
    def owning_related_element(self) -> Element | None:
        """
        Implementation of ``owning_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_element of this Relationship that owns the Relationship,
           if any.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def sources(self) -> ContainerView[Element]:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def targets(self) -> ContainerView[Element]:
        """
        Implementation of ``target`` defined in the KerML specification.

        **Specification**:

           The ``related_elements`` to which this Relationship is considered to
           be directed.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

class AnnotatingElement(Element):
    """
    Implementation of ``AnnotatingElement`` defined in the KerML
    specification.

    **Specification**:

       An ``AnnotatingElement`` is an ``Element`` that provides additional
       description of or metadata on some other ``Element``. An
       ``AnnotatingElement`` is either attached to its
       ``annotated_elements`` by ``Annotation`` ``Relationships``, or it
       implicitly annotates its ``owning_namespace``.

    For language description, see section
    `7.2.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=44>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::AnnotatingElement'

    STD: tuple[Union[type[AnnotatingElement], type[MetadataFeature], type[MetadataUsage]], ...] = ...
    """
    All subtypes of ``AnnotatingElement`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``AnnotatingElement.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, AnnotatingElement.STD):
            ...

    For type hints, instead use ``AnnotatingElement.Std``:

    .. code-block:: python

        def function(element: Element) -> AnnotatingElement.Std:
            ...

    Note that ``AnnotatingElement.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "AnnotatingElement.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[AnnotatingElement, MetadataFeature, MetadataUsage]
        """Type hint for all subtypes of ``AnnotatingElement`` according to the specification"""

    @property
    def annotations(self) -> ContainerView[Annotation]:
        """
        Implementation of ``annotation`` defined in the KerML specification.

        **Specification**:

           The ``Annotations`` that relate this ``AnnotatingElement`` to its
           ``annotated_elements``. This includes the
           ``owning_annotating_relationship`` (if any) followed by all the
           ``owned_annotating_relationships``.

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def annotated_elements(self) -> ContainerView[Element]:
        """
        Implementation of ``annotated_element`` defined in the KerML
        specification.

        **Specification**:

           The ``Elements`` that are annotated by this ``AnnotatingElement``. If
           ``annotation`` is not empty, these are the ``annotated_elements`` of
           the ``annotations``. If ``annotation`` is empty, then it is the
           ``owning_namespace`` of the ``AnnotatingElement``.

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def owned_annotating_relationships(self) -> ContainerView[Annotation]:
        """
        Implementation of ``owned_annotating_relationship`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``AnnotatingElement`` that are
           ``Annotations``, for which this ``AnnotatingElement`` is the
           ``annotating_element``.

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=144>`__
        of the KerML specification for more details.
        """

    @property
    def owning_annotating_relationship(self) -> Annotation | None:
        """
        Implementation of ``owning_annotating_relationship`` defined in the
        KerML specification.

        **Specification**:

           The ``owning_relationship`` of this ``AnnotatingRelationship``, if it
           is an ``Annotation``

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=144>`__
        of the KerML specification for more details.
        """

    @property
    def about(self) -> Annotations:
        """Container for owned annotations."""

class Comment(AnnotatingElement):
    """
    Implementation of ``Comment`` defined in the KerML specification.

    **Specification**:

       A ``Comment`` is an ``AnnotatingElement`` whose ``body`` in some way
       describes its ``annotated_elements``.

    For language description, see section
    `7.2.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=45>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=146>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Comment'

    STD: tuple[type[Comment], ...] = ...
    """
    All subtypes of ``Comment`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Comment.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Comment.STD):
            ...

    For type hints, instead use ``Comment.Std``:

    .. code-block:: python

        def function(element: Element) -> Comment.Std:
            ...

    Note that ``Comment.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Comment.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Comment
        """Type hint for all subtypes of ``Comment`` according to the specification"""

    @property
    def locale(self) -> str | None:
        """
        Implementation of ``locale`` defined in the KerML specification.

        **Specification**:

           Identification of the language of the ``body`` text and, optionally,
           the region and/or encoding. The format shall be a POSIX locale
           conformant to ISO/IEC 15897, with the format
           ``[language[_territory][.codeset][@modifier]]``.

        See section
        `8.3.2.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=146>`__
        of the KerML specification for more details.
        """

    @locale.setter
    def locale(self, arg: str | None) -> None: ...

    @property
    def body(self) -> str:
        """
        Implementation of ``body`` defined in the KerML specification.

        **Specification**:

           The annotation text for the ``Comment``.

        See section
        `8.3.2.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=146>`__
        of the KerML specification for more details.
        """

    @body.setter
    def body(self, arg: str, /) -> None: ...

class Documentation(Comment):
    """
    Implementation of ``Documentation`` defined in the KerML specification.

    **Specification**:

       ``Documentation`` is a ``Comment`` that specifically documents a
       ``documented_element``, which must be its ``owner``.

    For language description, see section
    `7.2.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=45>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.3.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=146>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Documentation'

    STD: tuple[type[Documentation], ...] = ...
    """
    All subtypes of ``Documentation`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Documentation.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Documentation.STD):
            ...

    For type hints, instead use ``Documentation.Std``:

    .. code-block:: python

        def function(element: Element) -> Documentation.Std:
            ...

    Note that ``Documentation.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Documentation.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Documentation
        """Type hint for all subtypes of ``Documentation`` according to the specification"""

    @property
    def documented_element(self) -> Element | None:
        """
        Implementation of ``documented_element`` defined in the KerML
        specification.

        **Specification**:

           The ``Element`` that is documented by this ``Documentation``.

        See section
        `8.3.2.3.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=146>`__
        of the KerML specification for more details.
        """

class Annotation(Relationship):
    """
    Implementation of ``Annotation`` defined in the KerML specification.

    **Specification**:

       An ``Annotation`` is a Relationship between an ``AnnotatingElement``
       and the ``Element`` that is annotated by that ``AnnotatingElement``.

    For language description, see section
    `7.2.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=44>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.3.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=144>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Annotation'

    STD: tuple[type[Annotation], ...] = ...
    """
    All subtypes of ``Annotation`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Annotation.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Annotation.STD):
            ...

    For type hints, instead use ``Annotation.Std``:

    .. code-block:: python

        def function(element: Element) -> Annotation.Std:
            ...

    Note that ``Annotation.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Annotation.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Annotation
        """Type hint for all subtypes of ``Annotation`` according to the specification"""

    @property
    def annotated_element(self) -> Element | None:
        """
        Implementation of ``annotated_element`` defined in the KerML
        specification.

        **Specification**:

           The ``Element`` that is annotated by the ``annotating_element`` of
           this Annotation.

        See section
        `8.3.2.3.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=145>`__
        of the KerML specification for more details.
        """

    @property
    def owning_annotated_element(self) -> Element | None:
        """
        Implementation of ``owning_annotated_element`` defined in the KerML
        specification.

        **Specification**:

           The ``annotated_element`` of this ``Annotation``, when it is also the
           ``owning_related_element``.

        See section
        `8.3.2.3.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=145>`__
        of the KerML specification for more details.
        """

    @property
    def owned_annotating_element(self) -> AnnotatingElement | MetadataFeature | MetadataUsage | None:
        """
        Implementation of ``owned_annotating_element`` defined in the KerML
        specification.

        **Specification**:

           The ``annotating_element`` of this ``Annotation``, when it is an
           ``owned_related_element``.

        See section
        `8.3.2.3.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=145>`__
        of the KerML specification for more details.
        """

    @property
    def annotating_element(self) -> AnnotatingElement | MetadataFeature | MetadataUsage | None:
        """
        Implementation of ``annotating_element`` defined in the KerML
        specification.

        **Specification**:

           The ``AnnotatingElement`` that annotates the ``annotated_element`` of
           this ``Annotation``. This is always either the
           ``owned_annotating_element`` or the ``owning_annotating_element``.

        See section
        `8.3.2.3.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=145>`__
        of the KerML specification for more details.
        """

    @property
    def owning_annotating_element(self) -> AnnotatingElement | MetadataFeature | MetadataUsage | None:
        """
        Implementation of ``owning_annotating_element`` defined in the KerML
        specification.

        **Specification**:

           The ``annotating_element`` of this ``Annotation``, when it is the
           ``owning_related_element``.

        See section
        `8.3.2.3.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=145>`__
        of the KerML specification for more details.
        """

    @property
    def owning_related_element(self) -> Element | None:
        """
        Implementation of ``owning_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_element of this Relationship that owns the Relationship,
           if any.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def sources(self) -> ContainerView[Element]:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def targets(self) -> ContainerView[Element]:
        """
        Implementation of ``target`` defined in the KerML specification.

        **Specification**:

           The ``related_elements`` to which this Relationship is considered to
           be directed.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

class TextualRepresentation(AnnotatingElement):
    """
    Implementation of ``TextualRepresentation`` defined in the KerML
    specification.

    **Specification**:

       A ``TextualRepresentation`` is an ``AnnotatingElement`` whose
       ``body`` represents the ``represented_element`` in a given
       ``language``. The ``represented_element`` must be the ``owner`` of
       the ``TextualRepresentation``. The named ``language`` can be a
       natural language, in which case the ``body`` is an informal
       representation, or an artificial language, in which case the ``body``
       is expected to be a formal, machine-parsable representation.

       If the named ``language`` of a ``TextualRepresentation`` is
       machine-parsable, then the ``body`` text should be legal input text
       as defined for that ``language``. The interpretation of the named
       language string shall be case insensitive. The following ``language``
       names are defined to correspond to the given standard languages:

       ========= ===========================
       ``kerml`` Kernel Modeling Language
       ``ocl``   Object Constraint Language
       ``alf``   Action Language for f_u_m_l
       ========= ===========================

       Other specifications may define specific ``language`` strings, other
       than those shown above, to be used to indicate the use of languages
       from those specifications in KerML ``TextualRepresentation``.

       If the ``language`` of a ``TextualRepresentation`` is “``kerml``”,
       then the ``body`` text shall be a legal representation of the
       ``represented_element`` in the KerML textual concrete syntax. A
       conforming tool can use such a ``TextualRepresentation``
       ``Annotation`` to record the original KerML concrete syntax text from
       which an ``Element`` was parsed. In this case, it is a tool
       responsibility to ensure that the ``body`` of the
       ``TextualRepresentation`` remains correct (or the Annotation is
       removed) if the annotated ``Element`` changes other than by
       re-parsing the ``body`` text.

       An ``Element`` with a ``TextualRepresentation`` in a language other
       than KerML is essentially a semantically “opaque” ``Element``
       specified in the other language. However, a conforming KerML tool may
       interpret such an element consistently with the specification of the
       named language.

    For language description, see section
    `7.2.4.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=46>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.3.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=147>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::TextualRepresentation'

    STD: tuple[type[TextualRepresentation], ...] = ...
    """
    All subtypes of ``TextualRepresentation`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``TextualRepresentation.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, TextualRepresentation.STD):
            ...

    For type hints, instead use ``TextualRepresentation.Std``:

    .. code-block:: python

        def function(element: Element) -> TextualRepresentation.Std:
            ...

    Note that ``TextualRepresentation.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "TextualRepresentation.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = TextualRepresentation
        """Type hint for all subtypes of ``TextualRepresentation`` according to the specification"""

    @property
    def language(self) -> str:
        """
        Implementation of ``language`` defined in the KerML specification.

        **Specification**:

           The natural or artificial language in which the ``body`` text is
           written.

        See section
        `8.3.2.3.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=147>`__
        of the KerML specification for more details.
        """

    @language.setter
    def language(self, arg: str, /) -> None: ...

    @property
    def body(self) -> str:
        """
        Implementation of ``body`` defined in the KerML specification.

        **Specification**:

           The textual representation of the ``represented_element`` in the
           given ``language``.

        See section
        `8.3.2.3.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=147>`__
        of the KerML specification for more details.
        """

    @body.setter
    def body(self, arg: str, /) -> None: ...

    @property
    def represented_element(self) -> Element | None:
        """
        Implementation of ``represented_element`` defined in the KerML
        specification.

        **Specification**:

           The ``Element`` that is represented by this
           ``TextualRepresentation``.

        See section
        `8.3.2.3.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=147>`__
        of the KerML specification for more details.
        """

class NamespaceImport(Import):
    """
    Implementation of ``NamespaceImport`` defined in the KerML
    specification.

    **Specification**:

       A ``NamespaceImport`` is an Import that imports ``Memberships`` from
       its ``imported_namespace`` into the ``import_owning_namespace``. If
       ``is_recursive = false``, then only the visible ``Memberships`` of
       the ``imported_namespace`` are imported. If ``is_recursive = true``,
       then, in addition, ``Memberships`` are recursively imported from any
       ``owned_members`` of the ``imported_namespace`` that are
       ``Namespaces``.

    For language description, see section
    `7.2.5.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=49>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.4.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=157>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::NamespaceImport'

    STD: tuple[type[NamespaceImport], ...] = ...
    """
    All subtypes of ``NamespaceImport`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``NamespaceImport.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, NamespaceImport.STD):
            ...

    For type hints, instead use ``NamespaceImport.Std``:

    .. code-block:: python

        def function(element: Element) -> NamespaceImport.Std:
            ...

    Note that ``NamespaceImport.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "NamespaceImport.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = NamespaceImport
        """Type hint for all subtypes of ``NamespaceImport`` according to the specification"""

    @property
    def imported_namespace(self) -> Namespace | None:
        """
        Implementation of ``imported_namespace`` defined in the KerML
        specification.

        **Specification**:

           The ``Namespace`` whose visible ``Memberships`` are imported by this
           ``NamespaceImport``.

        See section
        `8.3.2.4.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=157>`__
        of the KerML specification for more details.
        """

class MembershipImport(Import):
    """
    Implementation of ``MembershipImport`` defined in the KerML
    specification.

    **Specification**:

       A ``MembershipImport`` is an ``Import`` that imports its
       ``imported_membership`` into the ``import_owning_namespace``. If
       ``is_recursive = true`` and the ``member_element`` of the
       ``imported_membership`` is a ``Namespace``, then the equivalent of a
       recursive ``NamespaceImport`` is also performed on that
       ``Namespace``.

    For language description, see section
    `7.2.5.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=49>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.4.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=152>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::MembershipImport'

    STD: tuple[type[MembershipImport], ...] = ...
    """
    All subtypes of ``MembershipImport`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``MembershipImport.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, MembershipImport.STD):
            ...

    For type hints, instead use ``MembershipImport.Std``:

    .. code-block:: python

        def function(element: Element) -> MembershipImport.Std:
            ...

    Note that ``MembershipImport.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "MembershipImport.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = MembershipImport
        """Type hint for all subtypes of ``MembershipImport`` according to the specification"""

    @property
    def imported_membership(self) -> Membership | None:
        """
        Implementation of ``imported_membership`` defined in the KerML
        specification.

        **Specification**:

           The ``Membership`` to be imported.

        See section
        `8.3.2.4.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=152>`__
        of the KerML specification for more details.
        """

class Specialization(Relationship):
    """
    Implementation of ``Specialization`` defined in the KerML specification.

    **Specification**:

       ``Specialization`` is a ``Relationship`` between two ``Types`` that
       requires all instances of the ``specific`` type to also be instances
       of the ``general`` Type (i.e., the set of instances of the
       ``specific`` Type is a *subset* of those of the ``general`` Type,
       which might be the same set).

    For language description, see section
    `7.3.2.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=53>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.1.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=166>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Specialization'

    STD: tuple[type[Specialization], ...] = ...
    """
    All subtypes of ``Specialization`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Specialization.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Specialization.STD):
            ...

    For type hints, instead use ``Specialization.Std``:

    .. code-block:: python

        def function(element: Element) -> Specialization.Std:
            ...

    Note that ``Specialization.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Specialization.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Specialization
        """Type hint for all subtypes of ``Specialization`` according to the specification"""

    CHAINABLE: bool = True
    """
    Whether this relationship can be used with chained features.

    Using this in, e.g. ``append_chain``, will not raise ``TypeError``.
    """

    @property
    def general(self) -> Type | None:
        """
        Implementation of ``general`` defined in the KerML specification.

        **Specification**:

           A ``Type`` with a superset of all instances of the ``specific``
           ``Type``, which might be the same set.

        See section
        `8.3.3.1.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=166>`__
        of the KerML specification for more details.
        """

    @property
    def specific(self) -> Type | None:
        """
        Implementation of ``specific`` defined in the KerML specification.

        **Specification**:

           A ``Type`` with a subset of all instances of the ``general``
           ``Type``, which might be the same set.

        See section
        `8.3.3.1.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=167>`__
        of the KerML specification for more details.
        """

    @property
    def owning_type(self) -> Type | None:
        """
        Implementation of ``owning_type`` defined in the KerML specification.

        **Specification**:

           The ``Type`` that is the ``specific`` ``Type`` of this
           ``Specialization`` and owns it as its ``owning_related_element``.

        See section
        `8.3.3.1.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=167>`__
        of the KerML specification for more details.
        """

    @property
    def children(self) -> RelationshipBody:
        """The elements enclosed by curly brackets in textual syntax."""

    @property
    def specific_target(self) -> ChainedTypeReference:
        """Syside specific accessor for manipulating the target of ``specific``."""

    @property
    def general_target(self) -> ChainedTypeReference:
        """Syside specific accessor for manipulating the target of ``general``."""

class Subclassification(Specialization):
    """
    Implementation of ``Subclassification`` defined in the KerML
    specification.

    **Specification**:

       ``Subclassification`` is ``Specialization`` in which both the
       ``specific`` and ``general`` ``Types`` are ``Classifier``. This means
       all instances of the specific ``Classifier`` are also instances of
       the general ``Classifier``.

    For language description, see section
    `7.3.3.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=57>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.2.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=179>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Subclassification'

    STD: tuple[type[Subclassification], ...] = ...
    """
    All subtypes of ``Subclassification`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Subclassification.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Subclassification.STD):
            ...

    For type hints, instead use ``Subclassification.Std``:

    .. code-block:: python

        def function(element: Element) -> Subclassification.Std:
            ...

    Note that ``Subclassification.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Subclassification.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Subclassification
        """Type hint for all subtypes of ``Subclassification`` according to the specification"""

    CHAINABLE: bool = False
    """
    Whether this relationship can be used with chained features.

    Using this in, e.g. ``append_chain``, will raise ``TypeError``.
    """

    @property
    def superclassifier(self) -> Classifier | None:
        """
        Implementation of ``superclassifier`` defined in the KerML
        specification.

        **Specification**:

           The more ``general`` Classifier in this ``Subclassification``.

        See section
        `8.3.3.2.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=179>`__
        of the KerML specification for more details.
        """

    @property
    def subclassifier(self) -> Classifier | None:
        """
        Implementation of ``subclassifier`` defined in the KerML specification.

        **Specification**:

           The more specific ``Classifier`` in this ``Subclassification``.

        See section
        `8.3.3.2.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=179>`__
        of the KerML specification for more details.
        """

    @property
    def owning_classifier(self) -> Classifier | None:
        """
        Implementation of ``owning_classifier`` defined in the KerML
        specification.

        **Specification**:

           The ``Classifier`` that owns this ``Subclassification`` relationship,
           which must also be its ``subclassifier``.

        See section
        `8.3.3.2.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=179>`__
        of the KerML specification for more details.
        """

    @property
    def superclassifier_target(self) -> ClassifierReference:
        """
        Syside specific accessor for manipulating the target of ``superclassifier``.
        """

    @property
    def subclassifier_target(self) -> ClassifierReference:
        """
        Syside specific accessor for manipulating the target of ``subclassifier``.
        """

class Type(Namespace):
    """
    Implementation of ``Type`` defined in the KerML specification.

    **Specification**:

       A ``Type`` is a ``Namespace`` that is the most general kind of
       ``Element`` supporting the semantics of classification. A ``Type``
       may be a ``Classifier`` or a ``Feature``, defining conditions on what
       is classified by the ``Type`` (see also the description of
       ``is_sufficient``).

    For language description, see section
    `7.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=52>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=168>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Type'

    STD: tuple[type[Type], ...] = ...
    """
    All subtypes of ``Type`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Type.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Type.STD):
            ...

    For type hints, instead use ``Type.Std``:

    .. code-block:: python

        def function(element: Element) -> Type.Std:
            ...

    Note that ``Type.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Type.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Type
        """Type hint for all subtypes of ``Type`` according to the specification"""

    @property
    def is_abstract(self) -> bool:
        """
        Implementation of ``is_abstract`` defined in the KerML specification.

        **Specification**:

           Indicates whether instances of this ``Type`` must also be instances
           of at least one of its specialized ``Types``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=169>`__
        of the KerML specification for more details.
        """

    @is_abstract.setter
    def is_abstract(self, arg: bool, /) -> None: ...

    @property
    def is_abstract_explicitly(self) -> bool:
        """
        Returns ``True`` if this ``Type`` was declared as ``abstract`` in the textual syntax.
        """

    @property
    def is_sufficient(self) -> bool:
        """
        Implementation of ``is_sufficient`` defined in the KerML specification.

        **Specification**:

           Whether all things that meet the classification conditions of this
           ``Type`` must be classified by the ``Type``.

           (A ``Type`` gives conditions that must be met by whatever it
           classifies, but when ``is_sufficient`` is false, things may meet
           those conditions but still not be classified by the ``Type``. For
           example, a Type ``Car`` that is not sufficient could require
           everything it classifies to have four wheels, but not all four
           wheeled things would classify as cars. However, if the ``Type``
           ``Car`` were sufficient, it would classify all four-wheeled things.)

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=169>`__
        of the KerML specification for more details.
        """

    @is_sufficient.setter
    def is_sufficient(self, arg: bool, /) -> None: ...

    @property
    def is_sufficient_explicitly(self) -> bool:
        """
        Returns ``True`` if this ``Type`` was declared as ``sufficient`` in the textual syntax.
        """

    @property
    def is_conjugated(self) -> bool:
        """
        Implementation of ``is_conjugated`` defined in the KerML specification.

        **Specification**:

           Indicates whether this ``Type`` has an ``owned_conjugator``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=169>`__
        of the KerML specification for more details.
        """

    @property
    def owned_specializations(self) -> LazyIterator[Specialization]:
        """
        Implementation of ``owned_specialization`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``Type`` that are
           ``Specializations``, for which the ``Type`` is the ``specific``
           ``Type``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=170>`__
        of the KerML specification for more details.
        """

    @property
    def owned_feature_memberships(self) -> LazyIterator[FeatureMembership]:
        """
        Implementation of ``owned_feature_membership`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_memberships`` of this ``Type`` that are
           ``FeatureMemberships``, for which the ``Type`` is the
           ``owning_type``. Each such ``FeatureMembership`` identifies an
           ``owned_feature`` of the ``Type``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=170>`__
        of the KerML specification for more details.
        """

    @property
    def owned_features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``owned_feature`` defined in the KerML specification.

        **Specification**:

           The ``owned_member_features`` of the ``owned_feature_memberships`` of
           this ``Type``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=170>`__
        of the KerML specification for more details.
        """

    @property
    def feature_memberships(self) -> LazyIterator[FeatureMembership]:
        """
        Implementation of ``feature_membership`` defined in the KerML
        specification.

        **Specification**:

           The ``FeatureMemberships`` for ``features`` of this ``Type``, which
           include all ``owned_feature_memberships`` and those
           ``inherited_memberships`` that are ``FeatureMemberships`` (but does
           *not* include any ``imported_memberships``).

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=168>`__
        of the KerML specification for more details.
        """

    @property
    def features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``feature`` defined in the KerML specification.

        **Specification**:

           The ``owned_member_features`` of the ``feature_memberships`` of this
           ``Type``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=168>`__
        of the KerML specification for more details.
        """

    @property
    def owned_inputs(self) -> LazyIterator[Feature]:
        """The ``inputs`` that are owned by this ``Type``."""

    @property
    def inputs(self) -> LazyIterator[Feature]:
        """
        Implementation of ``input`` defined in the KerML specification.

        **Specification**:

           All ``features`` related to this ``Type`` by ``FeatureMemberships``
           that have ``direction`` ``in`` or ``inout``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=169>`__
        of the KerML specification for more details.
        """

    @property
    def owned_outputs(self) -> LazyIterator[Feature]:
        """The ``outputs`` that are owned by this ``Type``."""

    @property
    def outputs(self) -> LazyIterator[Feature]:
        """
        Implementation of ``output`` defined in the KerML specification.

        **Specification**:

           All ``features`` related to this ``Type`` by ``FeatureMemberships``
           that have ``direction`` ``out`` or ``inout``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=169>`__
        of the KerML specification for more details.
        """

    @property
    def inherited_memberships(self) -> LazyIterator[Membership]:
        """
        Implementation of ``inherited_membership`` defined in the KerML
        specification.

        **Specification**:

           All ``Memberships`` inherited by this ``Type`` via ``Specialization``
           or ``Conjugation``. These are included in the derived union for the
           ``memberships`` of the ``Type``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=169>`__
        of the KerML specification for more details.
        """

    @property
    def owned_end_features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``owned_end_feature`` defined in the KerML
        specification.

        **Specification**:

           All ``end_features`` of this ``Type`` that are ``owned_features``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=170>`__
        of the KerML specification for more details.
        """

    @property
    def end_features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``end_feature`` defined in the KerML specification.

        **Specification**:

           All ``features`` of this ``Type`` with ``is_end = true``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=168>`__
        of the KerML specification for more details.
        """

    @property
    def owned_conjugator(self) -> Conjugation | None:
        """
        Implementation of ``owned_conjugator`` defined in the KerML
        specification.

        **Specification**:

           A ``Conjugation`` owned by this ``Type`` for which the ``Type`` is
           the ``original_type``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=169>`__
        of the KerML specification for more details.
        """

    @property
    def inherited_features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``inherited_feature`` defined in the KerML
        specification.

        **Specification**:

           All the ``member_features`` of the ``inherited_memberships`` of this
           ``Type`` that are ``FeatureMemberships``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=169>`__
        of the KerML specification for more details.
        """

    @property
    def multiplicity(self) -> Multiplicity | None:
        """
        Implementation of ``multiplicity`` defined in the KerML specification.

        **Specification**:

           An ``owned_member`` of this ``Type`` that is a ``Multiplicity``,
           which constraints the cardinality of the ``Type``. If there is no
           such ``owned_member``, then the cardinality of this ``Type`` is
           constrained by all the ``Multiplicity`` constraints applicable to any
           direct supertypes.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=169>`__
        of the KerML specification for more details.
        """

    @property
    def declared_multiplicity(self) -> MultiplicityRange | None:
        """
        The owned multiplicity that is declared before the children block in the textual syntax.
        """

    @property
    def declared_multiplicity_member(self) -> OwnedMultiplicityAccessor:
        """Syside specific accessor for manipulating ``declared_multiplicity``."""

    @property
    def owned_unionings(self) -> LazyIterator[Unioning]:
        """
        Implementation of ``owned_unioning`` defined in the KerML specification.

        **Specification**:

           The ``owned_relationships`` of this ``Type`` that are ``Unionings``,
           having the ``Type`` as their ``type_unioned``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=170>`__
        of the KerML specification for more details.
        """

    @property
    def unioning_types(self) -> LazyIterator[Type]:
        """
        Implementation of ``unioning_type`` defined in the KerML specification.

        **Specification**:

           The interpretations of a ``Type`` with ``unioning_types`` are
           asserted to be the same as those of all the ``unioning_types``
           together, which are the ``Types`` derived from the ``unioning_type``
           of the ``owned_unionings`` of this ``Type``. For example, a
           ``Classifier`` for people might be the union of ``Classifiers`` for
           all the sexes. Similarly, a feature for people’s children might be
           the union of features dividing them in the same ways as people in
           general.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=170>`__
        of the KerML specification for more details.
        """

    @property
    def owned_intersectings(self) -> LazyIterator[Intersecting]:
        """
        Implementation of ``owned_intersecting`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``Type`` that are
           ``Intersectings``, have the ``Type`` as their ``type_intersected``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=170>`__
        of the KerML specification for more details.
        """

    @property
    def intersecting_types(self) -> LazyIterator[Type]:
        """
        Implementation of ``intersecting_type`` defined in the KerML
        specification.

        **Specification**:

           The interpretations of a ``Type`` with ``intersecting_types`` are
           asserted to be those in common among the ``intersecting_types``,
           which are the ``Types`` derived from the ``intersecting_type`` of the
           ``owned_intersectings`` of this ``Type``. For example, a
           ``Classifier`` might be an intersection of ``Classifiers`` for people
           of a particular sex and of a particular nationality. Similarly, a
           feature for people’s children of a particular sex might be the
           intersection of a ``Feature`` for their children and a ``Classifier``
           for people of that sex (because the interpretations of the children
           ``Feature`` that identify those of that sex are also interpretations
           of the Classifier for that sex).

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=169>`__
        of the KerML specification for more details.
        """

    @property
    def owned_disjoinings(self) -> LazyIterator[Disjoining]:
        """
        Implementation of ``owned_disjoining`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``Type`` that are
           ``Disjoinings``, for which the ``Type`` is the ``type_disjoined``
           ``Type``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=170>`__
        of the KerML specification for more details.
        """

    @property
    def disjoining_types(self) -> LazyIterator[Type]:
        """The types that related to this ``Type`` through ``owned_disjoinings``."""

    @property
    def owned_differencings(self) -> LazyIterator[Differencing]:
        """
        Implementation of ``owned_differencing`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``Type`` that are
           ``Differencings``, having this ``Type`` as their
           ``type_differenced``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=170>`__
        of the KerML specification for more details.
        """

    @property
    def differencing_types(self) -> LazyIterator[Type]:
        """
        Implementation of ``differencing_type`` defined in the KerML
        specification.

        **Specification**:

           The interpretations of a ``Type`` with ``differencing_types`` are
           asserted to be those of the first of those ``Types``, but not
           including those of the remaining ``Types``. For example, a
           ``Classifier`` might be the difference of a ``Classifier`` for people
           and another for people of a particular nationality, leaving people
           who are not of that nationality. Similarly, a feature of people might
           be the difference between a feature for their children and a
           ``Classifier`` for people of a particular sex, identifying their
           children not of that sex (because the interpretations of the children
           ``Feature`` that identify those of that sex are also interpretations
           of the ``Classifier`` for that sex).

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=168>`__
        of the KerML specification for more details.
        """

    @property
    def owned_directed_features(self) -> LazyIterator[Feature]:
        """The ``directed_features`` that are owned by this ``Type``."""

    @property
    def directed_features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``directed_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``features`` of this ``Type`` that have a non-null ``direction``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=168>`__
        of the KerML specification for more details.
        """

    @property
    def heritage(self) -> Heritage:
        """The specializations and conjugations owned by this ``Type``."""

    @property
    def type_relationships(self) -> TypeRelationships:
        """
        The other type, feature relationships and ``FeatureChainings`` owned by this ``Type``.
        """

    @overload
    def conforms(self, arg: Sequence[str], /) -> bool:
        """
        Returns ``True`` if this ``Type`` directly or indirectly specializes another ``Type`` while following ``FeatureChainings``.
        """

    @overload
    def conforms(self, arg: Type, /) -> bool: ...

    @overload
    def specializes(self, arg: Sequence[str], /) -> bool:
        """
        Returns ``True`` if this ``Type`` directly or indirectly specializes another ``Type`` while ignoring ``FeatureChainings``.
        """

    @overload
    def specializes(self, arg: Type, /) -> bool: ...

    def direction_of(self, arg: Feature, /) -> FeatureDirectionKind | None:
        """Returns the direction of a ``Feature`` in this ``Type``."""

class FeatureMembership(OwningMembership):
    """
    Implementation of ``FeatureMembership`` defined in the KerML
    specification.

    **Specification**:

       A ``FeatureMembership`` is an ``OwningMembership`` between an
       ``owned_member_feature`` and an ``owning_type``. If the
       ``owned_member_feature`` has ``is_variable = false``, then the
       ``FeatureMembership`` implies that the ``owning_type`` is also a
       ``featuring_type`` of the ``owned_member_feature``. If the
       ``owned_member_feature`` has ``is_variable = true``, then the
       ``FeatureMembership`` implies that the ``owned_member_feature`` is
       featured by the ``snapshots`` of the ``owning_type``, which must
       specialize the Kernel Semantic Library base class ``Occurrence``.

    For language description, see section
    `7.3.2.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=56>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.1.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=165>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::FeatureMembership'

    STD: tuple[type[FeatureMembership], ...] = ...
    """
    All subtypes of ``FeatureMembership`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``FeatureMembership.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, FeatureMembership.STD):
            ...

    For type hints, instead use ``FeatureMembership.Std``:

    .. code-block:: python

        def function(element: Element) -> FeatureMembership.Std:
            ...

    Note that ``FeatureMembership.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "FeatureMembership.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = FeatureMembership
        """Type hint for all subtypes of ``FeatureMembership`` according to the specification"""

    @property
    def owning_type(self) -> Type | None:
        """
        Implementation of ``owning_type`` defined in the KerML specification.

        **Specification**:

           The ``Type`` that owns this ``FeatureMembership``.

        See section
        `8.3.3.1.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=165>`__
        of the KerML specification for more details.
        """

    @property
    def owned_member_feature(self) -> Feature | None:
        """
        Implementation of ``owned_member_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that this ``FeatureMembership`` relates to its
           ``owning_type``, making it an ``owned_feature`` of the
           ``owning_type``.

        See section
        `8.3.3.1.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=165>`__
        of the KerML specification for more details.
        """

class Feature(Type):
    """
    Implementation of ``Feature`` defined in the KerML specification.

    **Specification**:

       A ``Feature`` is a ``Type`` that classifies relations between
       multiple things (in the universe). The domain of the relation is the
       intersection of the ``featuring_types`` of the ``Feature``. (The
       domain of a ``Feature`` with no ``featuring_types`` is implicitly the
       most general ``Type`` ``Base::Anything`` from the Kernel Semantic
       Library.) The co-domain of the relation is the intersection of the
       ``types`` of the ``Feature``.

       In the simplest cases, the ``featuring_types`` and ``types`` are
       ``Classifiers`` and the ``Feature`` relates two things, one from the
       domain and one from the range. Examples include cars paired with
       wheels, people paired with other people, and cars paired with numbers
       representing the car length.

       Since ``Features`` are ``Types``, their ``featuring_types`` and
       ``types`` can be ``Features``. In this case, the ``Feature``
       effectively classifies relations between relations, which can be
       interpreted as the sequence of things related by the domain
       ``Feature`` concatenated with the sequence of things related by the
       co-domain ``Feature``.

       The *values* of a ``Feature`` for a given instance of its domain are
       all the instances of its co-domain that are related to that domain
       instance by the ``Feature``. The values of a ``Feature`` with
       ``chaining_features`` are the same as values of the last ``Feature``
       in the chain, which can be found by starting with values of the first
       ``Feature``, then using those values as domain instances to obtain
       values of the second ``Feature``, and so on, to values of the last
       ``Feature``.

    For language description, see section
    `7.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=58>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=184>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Feature'

    STD: tuple[type[Feature], ...] = ...
    """
    All subtypes of ``Feature`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Feature.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Feature.STD):
            ...

    For type hints, instead use ``Feature.Std``:

    .. code-block:: python

        def function(element: Element) -> Feature.Std:
            ...

    Note that ``Feature.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Feature.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Feature
        """Type hint for all subtypes of ``Feature`` according to the specification"""

    @property
    def is_unique(self) -> bool:
        """
        Implementation of ``is_unique`` defined in the KerML specification.

        **Specification**:

           Whether or not values for this ``Feature`` must have no duplicates or
           not.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=186>`__
        of the KerML specification for more details.
        """

    @is_unique.setter
    def is_unique(self, arg: bool, /) -> None: ...

    @property
    def is_nonunique(self) -> bool:
        """Inverse of ``is_unique``."""

    @is_nonunique.setter
    def is_nonunique(self, arg: bool, /) -> None: ...

    @property
    def is_ordered(self) -> bool:
        """
        Implementation of ``is_ordered`` defined in the KerML specification.

        **Specification**:

           Whether an order exists for the values of this ``Feature`` or not.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=186>`__
        of the KerML specification for more details.
        """

    @is_ordered.setter
    def is_ordered(self, arg: bool, /) -> None: ...

    @property
    def is_composite(self) -> bool:
        """
        Implementation of ``is_composite`` defined in the KerML specification.

        **Specification**:

           Whether the ``Feature`` is a composite ``feature`` of its
           ``featuring_type``. If so, the values of the ``Feature`` cannot exist
           after its featuring instance no longer does and cannot be values of
           another composite feature that is not on the same featuring instance.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=185>`__
        of the KerML specification for more details.
        """

    @is_composite.setter
    def is_composite(self, arg: bool, /) -> None: ...

    @property
    def is_composite_explicitly(self) -> bool:
        """
        Returns ``True`` if this ``Feature`` has been declared ``composite`` in the textual syntax.
        """

    @property
    def is_end(self) -> bool:
        """
        Implementation of ``is_end`` defined in the KerML specification.

        **Specification**:

           Whether or not this ``Feature`` is an end ``Feature``. An end
           ``Feature`` always has multiplicity 1, mapping each of its domain
           instances to a single co-domain instance. However, it may have a
           ``cross_feature``, in which case values of the ``cross_feature`` must
           be the same as those found by navigation across instances of the
           ``owning_type`` from values of other end ``Features`` to values of
           this Feature. If the ``owning_type`` has *n* end ``Features``, then
           the multiplicity, ordering, and uniqueness declared for the
           ``cross_feature`` of any one of these end ``Features`` constrains the
           cardinality, ordering, and uniqueness of the collection of values of
           that ``Feature`` reached by navigation when the values of the other
           *n-1* end ``Features`` are held fixed.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=185>`__
        of the KerML specification for more details.
        """

    @is_end.setter
    def is_end(self, arg: bool, /) -> None: ...

    @property
    def is_end_explicitly(self) -> bool:
        """
        Returns ``True`` if this ``Feature`` has been declared ``end`` in the textual syntax.
        """

    @property
    def is_derived(self) -> bool:
        """
        Implementation of ``is_derived`` defined in the KerML specification.

        **Specification**:

           Whether the values of this ``Feature`` can always be computed from
           the values of other ``Features``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=185>`__
        of the KerML specification for more details.
        """

    @is_derived.setter
    def is_derived(self, arg: bool, /) -> None: ...

    @property
    def is_constant(self) -> bool:
        """
        Implementation of ``is_constant`` defined in the KerML specification.

        **Specification**:

           If ``is_variable`` is true, then whether the value of this
           ``Feature`` nevertheless does not change over all ``snapshots`` of
           its ``owning_type``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=185>`__
        of the KerML specification for more details.
        """

    @is_constant.setter
    def is_constant(self, arg: bool, /) -> None: ...

    @property
    def is_constant_explicitly(self) -> bool:
        """
        Returns ``True`` if this ``Feature`` has been declared ``constant`` in the textual syntax.
        """

    @property
    def is_variable(self) -> bool:
        """
        Implementation of ``is_variable`` defined in the KerML specification.

        **Specification**:

           Whether the value of this ``Feature`` might vary over time. That is,
           whether the ``Feature`` may have a different value for each
           ``snapshot`` of an ``owning_type`` that is an ``Occurrence``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=186>`__
        of the KerML specification for more details.

        Note that this will raise ``TypeError`` if attempting to set ``is_variable`` on ``Usages`` because it
        is computed by sema, see ``Usage.may_time_vary``. Prefer using ``try_set_is_variable`` for non-raising
        behaviour.
        """

    @is_variable.setter
    def is_variable(self, arg: bool, /) -> None: ...

    @property
    def is_variable_explicitly(self) -> bool:
        """
        Returns ``True`` if this ``Feature`` has been declared ``variable`` in the textual syntax.
        """

    def try_set_is_variable(self, arg: bool, /) -> bool:
        """
        Non-raising variant of ``is_variable`` setter that returns ``False`` on ``Usages``
        without modifying ``is_variable``.
        """

    @property
    def is_read_only(self) -> bool:
        """
        Alias for `is_constant`.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @is_read_only.setter
    def is_read_only(self, arg: bool, /) -> None: ...

    @property
    def is_portion(self) -> bool:
        """
        Implementation of ``is_portion`` defined in the KerML specification.

        **Specification**:

           Whether the values of this ``Feature`` are contained in the space and
           time of instances of the domain of the ``Feature`` and represent the
           same thing as those instances.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=186>`__
        of the KerML specification for more details.
        """

    @is_portion.setter
    def is_portion(self, arg: bool, /) -> None: ...

    @property
    def direction(self) -> FeatureDirectionKind | None:
        """
        Implementation of ``direction`` defined in the KerML specification.

        **Specification**:

           Indicates how values of this ``Feature`` are determined or used (as
           specified for the ``FeatureDirectionKind``).

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=185>`__
        of the KerML specification for more details.
        """

    @direction.setter
    def direction(self, arg: FeatureDirectionKind | None) -> None: ...

    @property
    def explicit_direction(self) -> FeatureDirectionKind | None:
        """
        Returns the direction this ``Feature`` has been declared with in the textual syntax.
        """

    @property
    def owning_feature_membership(self) -> FeatureMembership | None:
        """
        Implementation of ``owning_feature_membership`` defined in the KerML
        specification.

        **Specification**:

           The ``FeatureMembership`` that owns this ``Feature`` as an
           ``owned_member_feature``, determining its ``owning_type``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=187>`__
        of the KerML specification for more details.
        """

    @property
    def owning_type(self) -> Type | None:
        """
        Implementation of ``owning_type`` defined in the KerML specification.

        **Specification**:

           The ``Type`` that is the ``owning_type`` of the
           ``owning_feature_membership`` of this ``Feature``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=187>`__
        of the KerML specification for more details.
        """

    @property
    def end_owning_type(self) -> Type | None:
        """
        Implementation of ``end_owning_type`` defined in the KerML
        specification.

        **Specification**:

           The ``Type`` that is related to this ``Feature`` by an
           ``EndFeatureMembership`` in which the ``Feature`` is an
           ``owned_member_feature``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=185>`__
        of the KerML specification for more details.
        """

    @property
    def types(self) -> LazyIterator[Type]:
        """
        Implementation of ``type`` defined in the KerML specification.

        **Specification**:

           ``Types`` that restrict the values of this ``Feature``, such that the
           values must be instances of all the ``types``. The types of a
           ``Feature`` are derived from its ``typings`` and the ``types`` of its
           ``subsettings``. If the ``Feature`` is chained, then the ``types`` of
           the last ``Feature`` in the chain are also ``types`` of the chained
           ``Feature``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=187>`__
        of the KerML specification for more details.
        """

    @property
    def owned_redefinitions(self) -> LazyIterator[Redefinition]:
        """
        Implementation of ``owned_redefinition`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_subsettings`` of this ``Feature`` that are
           ``Redefinitions``, for which the ``Feature`` is the
           ``redefining_feature``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=186>`__
        of the KerML specification for more details.
        """

    @property
    def owned_subsettings(self) -> LazyIterator[Subsetting]:
        """
        Implementation of ``owned_subsetting`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_specializations`` of this ``Feature`` that are
           ``Subsettings``, for which the ``Feature`` is the
           ``subsetting_feature``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=186>`__
        of the KerML specification for more details.
        """

    @property
    def owned_typings(self) -> LazyIterator[FeatureTyping]:
        """
        Implementation of ``owned_typing`` defined in the KerML specification.

        **Specification**:

           The ``owned_specializations`` of this ``Feature`` that are
           ``FeatureTypings``, for which the ``Feature`` is the
           ``typed_feature``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=187>`__
        of the KerML specification for more details.
        """

    @property
    def featuring_types(self) -> LazyIterator[Type]:
        """
        Implementation of ``featuring_type`` defined in the KerML specification.

        **Specification**:

           ``Types`` that feature this ``Feature``, such that any instance in
           the domain of the ``Feature`` must be classified by all of these
           ``Types``, including at least all the ``featuring_types`` of its
           ``type_featurings``. If the ``Feature`` is chained, then the
           ``featuring_types`` of the first ``Feature`` in the chain are also
           ``featuring_types`` of the chained ``Feature``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=185>`__
        of the KerML specification for more details.
        """

    @property
    def owned_type_featurings(self) -> LazyIterator[TypeFeaturing]:
        """
        Implementation of ``owned_type_featuring`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``Feature`` that are
           ``TypeFeaturings`` and for which the ``Feature`` is the
           ``feature_of_type``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=187>`__
        of the KerML specification for more details.
        """

    @property
    def owned_feature_invertings(self) -> LazyIterator[FeatureInverting]:
        """
        Implementation of ``owned_feature_inverting`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``Feature`` that are
           ``FeatureInvertings`` and for which the ``Feature`` is the
           ``feature_inverted``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=186>`__
        of the KerML specification for more details.
        """

    @property
    def owned_feature_chainings(self) -> LazyIterator[FeatureChaining]:
        """
        Implementation of ``owned_feature_chaining`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``Feature`` that are
           ``FeatureChainings``, for which the ``Feature`` will be the
           ``feature_chained``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=186>`__
        of the KerML specification for more details.
        """

    @property
    def owned_reference_subsetting(self) -> ReferenceSubsetting | None:
        """
        Implementation of ``owned_reference_subsetting`` defined in the KerML
        specification.

        **Specification**:

           The one ``owned_subsetting`` of this ``Feature``, if any, that is a
           ``ReferenceSubsetting``, for which the ``Feature`` is the
           ``referencing_feature``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=186>`__
        of the KerML specification for more details.
        """

    @property
    def referenced_feature(self) -> Feature | None:
        """
        Returns the ``Feature`` this ``Feature`` references through ``ReferenceSubsetting`` if any.
        """

    @property
    def referenced_feature_target(self) -> Feature | None:
        """
        Returns the ``feature_target`` of ``referenced_feature``, i.e. ``referenced_feature.feature_target``.
        """

    @property
    def owned_cross_subsetting(self) -> CrossSubsetting | None:
        """
        Implementation of ``owned_cross_subsetting`` defined in the KerML
        specification.

        **Specification**:

           The one ``owned_subsetting`` of this ``Feature``, if any, that is a
           ``CrossSubsetting}, for which the Feature is the crossing_feature.``

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=186>`__
        of the KerML specification for more details.
        """

    @property
    def cross_feature(self) -> Feature | None:
        """
        Implementation of ``cross_feature`` defined in the KerML specification.

        **Specification**:

           The second ``chaining_feature`` of the ``crossed_feature`` of the
           ``owned_cross_subsetting`` of this ``Feature``, if it has one.
           Semantically, the values of the ``cross_feature`` of an end
           ``Feature`` must include all values of the end ``Feature`` obtained
           when navigating from values of the other end ``Features`` of the same
           ``owning_type``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=185>`__
        of the KerML specification for more details.
        """

    @property
    def owned_cross_feature_member(self) -> OwnedFeatureAccessor:
        """
        Syside specific accessor for either owned `crossing_feature` or `crossing_multiplicity`. This is the
        member ``Feature`` that is declared before any prefixes in the textual syntax.
        """

    @property
    def owned_cross_feature(self) -> Feature | None:
        """
        The member ``Feature`` that is declared before any prefixes in the textual syntax.
        """

    def find_owned_cross_feature(self) -> Feature | None:
        """
        Find the owned cross feature by potentially checking children. This is
        needed for spec that defined owned cross feature as the first member feature
        that is not a MetadataFeature or Multiplicity of an end feature. Since SysML
        does not allow member features (member keyword in KerML), this is equivalent
        to owned_cross_feature in SysML.
        """

    @property
    def feature_value(self) -> FeatureValue | None:
        """The ``FeatureValue`` owned by this ``Feature`` if any."""

    @property
    def feature_value_expression(self) -> Expression | None:
        """The feature value ``Expression`` of this ``Feature`` if any."""

    @property
    def feature_value_member(self) -> FeatureValueAccessor:
        """Syside specific accessor for manipulating ``feature_value``."""

    @property
    def first_chaining_feature(self) -> Feature | None:
        """
        The related ``Feature`` related by the first ``owned_feature_chaining`` if any.
        """

    @property
    def last_chaining_feature(self) -> Feature | None:
        """
        The related ``Feature`` related by the last ``owned_feature_chaining`` if any.
        """

    @property
    def basic_feature(self) -> Feature:
        """
        The ``last_chaining_feature`` if one exists, otherwise this ``Feature``.
        """

    @property
    def feature_target(self) -> Feature:
        """
        Implementation of ``feature_target`` defined in the KerML specification.

        **Specification**:

           The last of the ``chaining_features`` of this ``Feature``, if it has
           any. Otherwise, this ``Feature`` itself.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=185>`__
        of the KerML specification for more details.
        """

    @property
    def chaining_features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``chaining_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that are chained together to determine the values of
           this ``Feature``, derived from the ``chaining_features`` of the
           ``owned_feature_chainings`` of this ``Feature``, in the same order.
           The values of a ``Feature`` with ``chaining_features`` are the same
           as values of the last ``Feature`` in the chain, which can be found by
           starting with the values of the first ``Feature`` (for each instance
           of the domain of the original ``Feature``), then using each of those
           as domain instances to find the values of the second ``Feature`` in
           chaining_features, and so on, to values of the last ``Feature``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=185>`__
        of the KerML specification for more details.
        """

class Subsetting(Specialization):
    """
    Implementation of ``Subsetting`` defined in the KerML specification.

    **Specification**:

       ``Subsetting`` is ``Specialization`` in which the ``specific`` and
       ``general`` ``Types`` are ``Features``. This means all values of the
       ``subsetting_feature`` (on instances of its domain, i.e., the
       intersection of its ``featuring_types``) are values of the
       ``subsetted_feature`` on instances of its domain. To support this the
       domain of the ``subsetting_feature`` must be the same or specialize
       (at least indirectly) the domain of the ``subsetted_feature`` (via
       ``Specialization``), and the co-domain (intersection of the
       ``types``) of the ``subsetting_feature`` must specialize the
       co-domain of the ``subsetted_feature``.

    For language description, see section
    `7.3.4.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=61>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.3.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=202>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Subsetting'

    STD: tuple[type[Subsetting], ...] = ...
    """
    All subtypes of ``Subsetting`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Subsetting.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Subsetting.STD):
            ...

    For type hints, instead use ``Subsetting.Std``:

    .. code-block:: python

        def function(element: Element) -> Subsetting.Std:
            ...

    Note that ``Subsetting.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Subsetting.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Subsetting
        """Type hint for all subtypes of ``Subsetting`` according to the specification"""

    CHAINABLE: bool = True
    """
    Whether this relationship can be used with chained features.

    Using this in, e.g. ``append_chain``, will not raise ``TypeError``.
    """

    @property
    def subsetted_feature(self) -> Feature | None:
        """
        Implementation of ``subsetted_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that is subsetted by the ``subsetting_feature`` of
           this ``Subsetting``.

        See section
        `8.3.3.3.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=203>`__
        of the KerML specification for more details.
        """

    @property
    def subsetting_feature(self) -> Feature | None:
        """
        Implementation of ``subsetting_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that is a subset of the ``subsetted_feature`` of this
           ``Subsetting``.

        See section
        `8.3.3.3.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=203>`__
        of the KerML specification for more details.
        """

    @property
    def owning_feature(self) -> Feature | None:
        """
        Implementation of ``owning_feature`` defined in the KerML specification.

        **Specification**:

           A ``subsetting_feature`` that is also the ``owning_related_element``
           of this ``Subsetting``.

        See section
        `8.3.3.3.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=203>`__
        of the KerML specification for more details.
        """

    @property
    def subsetted_feature_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``subsetted_feature``.
        """

    @property
    def subsetting_feature_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``subsetting_feature``.
        """

class Redefinition(Subsetting):
    """
    Implementation of ``Redefinition`` defined in the KerML specification.

    **Specification**:

       ``Redefinition`` is a kind of ``Subsetting`` that requires the
       ``redefined_feature`` and the ``redefining_feature`` to have the same
       values (on each instance of the domain of the
       ``redefining_feature``). This means any restrictions on the
       ``redefining_feature``, such as ``type`` or ``multiplicity``, also
       apply to the ``redefined_feature`` (on each instance of the domain of
       the ``redefining_feature``), and vice versa. The
       ``redefined_feature`` might have values for instances of the domain
       of the ``redefining_feature``, but only as instances of the domain of
       the ``redefined_feature`` that happen to also be instances of the
       domain of the ``redefining_feature``. This is supported by the
       constraints inherited from ``Subsetting`` on the domains of the
       ``redefining_feature`` and ``redefined_feature``. However, these
       constraints are narrowed for ``Redefinition`` to require the
       ``owning_types`` of the ``redefining_feature`` and
       ``redefined_feature`` to be different and the ``redefined_feature``
       to not be inherited into the ``owning_namespace`` of the
       ``redefining_feature``.This enables the ``redefining_feature`` to
       have the same name as the ``redefined_feature``, if desired.

    For language description, see section
    `7.3.4.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=62>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.3.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=200>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Redefinition'

    STD: tuple[type[Redefinition], ...] = ...
    """
    All subtypes of ``Redefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Redefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Redefinition.STD):
            ...

    For type hints, instead use ``Redefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> Redefinition.Std:
            ...

    Note that ``Redefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Redefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Redefinition
        """Type hint for all subtypes of ``Redefinition`` according to the specification"""

    CHAINABLE: bool = True
    """
    Whether this relationship can be used with chained features.

    Using this in, e.g. ``append_chain``, will not raise ``TypeError``.
    """

    @property
    def redefining_feature(self) -> Feature | None:
        """
        Implementation of ``redefining_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that is redefining the ``redefined_feature`` of this
           ``Redefinition``.

        See section
        `8.3.3.3.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=201>`__
        of the KerML specification for more details.
        """

    @property
    def redefined_feature(self) -> Feature | None:
        """
        Implementation of ``redefined_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that is redefined by the ``redefining_feature`` of
           this ``Redefinition``.

        See section
        `8.3.3.3.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=201>`__
        of the KerML specification for more details.
        """

    @property
    def redefining_feature_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``redefining_feature``.
        """

    @property
    def redefined_feature_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``redefined_feature``.
        """

class FeatureTyping(Specialization):
    """
    Implementation of ``FeatureTyping`` defined in the KerML specification.

    **Specification**:

       ``FeatureTyping`` is ``Specialization`` in which the ``specific``
       ``Type`` is a ``Feature``. This means the set of instances of the
       (specific) ``typed_feature`` is a subset of the set of instances of
       the (general) ``type``. In the simplest case, the ``type`` is a
       ``Classifier``, whereupon the ``typed_feature`` has values that are
       instances of the ``Classifier``.

    For language description, see section
    `7.3.4.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=60>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.3.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=200>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::FeatureTyping'

    STD: tuple[type[FeatureTyping], ...] = ...
    """
    All subtypes of ``FeatureTyping`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``FeatureTyping.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, FeatureTyping.STD):
            ...

    For type hints, instead use ``FeatureTyping.Std``:

    .. code-block:: python

        def function(element: Element) -> FeatureTyping.Std:
            ...

    Note that ``FeatureTyping.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "FeatureTyping.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = FeatureTyping
        """Type hint for all subtypes of ``FeatureTyping`` according to the specification"""

    CHAINABLE: bool = False
    """
    Whether this relationship can be used with chained features.

    Using this in, e.g. ``append_chain``, will raise ``TypeError``.
    """

    @property
    def typed_feature(self) -> Feature | None:
        """
        Implementation of ``typed_feature`` defined in the KerML specification.

        **Specification**:

           The ``Feature`` that has a ``type`` determined by this
           ``FeatureTyping``.

        See section
        `8.3.3.3.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=200>`__
        of the KerML specification for more details.
        """

    @property
    def type(self) -> Type | None:
        """
        Implementation of ``type`` defined in the KerML specification.

        **Specification**:

           The ``Type`` that is being applied by this ``FeatureTyping``.

        See section
        `8.3.3.3.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=200>`__
        of the KerML specification for more details.
        """

    @property
    def owning_feature(self) -> Feature | None:
        """
        Implementation of ``owning_feature`` defined in the KerML specification.

        **Specification**:

           A ``typed_feature`` that is also the ``owning_related_element`` of
           this ``FeatureTyping``.

        See section
        `8.3.3.3.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=200>`__
        of the KerML specification for more details.
        """

    @property
    def typed_feature_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``typed_feature``.
        """

    @property
    def type_target(self) -> ChainedTypeReference:
        """Syside specific accessor for manipulating the target of ``type``."""

class TypeFeaturing(Relationship):
    """
    Implementation of ``TypeFeaturing`` defined in the KerML specification.

    **Specification**:

       A ``TypeFeaturing`` is a ``Featuring`` ``Relationship`` in which the
       ``feature_of_type`` is the ``source`` and the ``featuring_type`` is
       the ``target``.

    For language description, see section
    `7.3.4.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=65>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.3.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=203>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::TypeFeaturing'

    STD: tuple[type[TypeFeaturing], ...] = ...
    """
    All subtypes of ``TypeFeaturing`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``TypeFeaturing.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, TypeFeaturing.STD):
            ...

    For type hints, instead use ``TypeFeaturing.Std``:

    .. code-block:: python

        def function(element: Element) -> TypeFeaturing.Std:
            ...

    Note that ``TypeFeaturing.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "TypeFeaturing.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = TypeFeaturing
        """Type hint for all subtypes of ``TypeFeaturing`` according to the specification"""

    CHAINABLE: bool = False
    """
    Whether this relationship can be used with chained features.

    Using this in, e.g. ``append_chain``, will raise ``TypeError``.
    """

    @property
    def feature_of_type(self) -> Feature | None:
        """
        Implementation of ``feature_of_type`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that is featured by the ``featuring_type``. It is the
           ``source`` of the ``TypeFeaturing``.

        See section
        `8.3.3.3.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=204>`__
        of the KerML specification for more details.
        """

    @property
    def featuring_type(self) -> Type | None:
        """
        Implementation of ``featuring_type`` defined in the KerML specification.

        **Specification**:

           The ``Type`` that features the ``feature_of_type``. It is the
           ``target`` of the ``TypeFeaturing``.

        See section
        `8.3.3.3.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=204>`__
        of the KerML specification for more details.
        """

    @property
    def owning_feature_of_type(self) -> Feature | None:
        """
        Implementation of ``owning_feature_of_type`` defined in the KerML
        specification.

        **Specification**:

           A ``feature_of_type`` that is also the ``owning_related_element`` of
           this ``TypeFeaturing``.

        See section
        `8.3.3.3.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=204>`__
        of the KerML specification for more details.
        """

    @property
    def feature_of_type_target(self) -> FeatureReference:
        """
        Syside specific accessor for manipulating the target of ``feature_of_type``.
        """

    @property
    def featuring_type_target(self) -> TypeReference:
        """
        Syside specific accessor for manipulating the target of ``featuring_type``.
        """

class FeatureInverting(Relationship):
    """
    Implementation of ``FeatureInverting`` defined in the KerML
    specification.

    **Specification**:

       A ``FeatureInverting`` is a ``Relationship`` between ``Features``
       asserting that their interpretations (sequences) are the reverse of
       each other, identified as ``feature_inverted`` and
       ``inverting_feature``. For example, a ``Feature`` identifying each
       person’s parents is the inverse of a ``Feature`` identifying each
       person’s children. A person identified as a parent of another will
       identify that other as one of their children.

    For language description, see section
    `7.3.4.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=64>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.3.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=199>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::FeatureInverting'

    STD: tuple[type[FeatureInverting], ...] = ...
    """
    All subtypes of ``FeatureInverting`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``FeatureInverting.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, FeatureInverting.STD):
            ...

    For type hints, instead use ``FeatureInverting.Std``:

    .. code-block:: python

        def function(element: Element) -> FeatureInverting.Std:
            ...

    Note that ``FeatureInverting.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "FeatureInverting.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = FeatureInverting
        """Type hint for all subtypes of ``FeatureInverting`` according to the specification"""

    CHAINABLE: bool = True
    """
    Whether this relationship can be used with chained features.

    Using this in, e.g. ``append_chain``, will not raise ``TypeError``.
    """

    @property
    def inverting_feature(self) -> Feature | None:
        """
        Implementation of ``inverting_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that is an inverse of the ``inverted_feature``.

        See section
        `8.3.3.3.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=199>`__
        of the KerML specification for more details.
        """

    @property
    def feature_inverted(self) -> Feature | None:
        """
        Implementation of ``feature_inverted`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that is an inverse of the ``inverting_feature``.

        See section
        `8.3.3.3.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=199>`__
        of the KerML specification for more details.
        """

    @property
    def owning_feature(self) -> Feature | None:
        """
        Implementation of ``owning_feature`` defined in the KerML specification.

        **Specification**:

           A ``feature_inverted`` that is also the ``owning_related_element`` of
           this ``FeatureInverting``.

        See section
        `8.3.3.3.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=200>`__
        of the KerML specification for more details.
        """

    @property
    def children(self) -> RelationshipBody:
        """The elements enclosed by curly brackets in textual syntax."""

    @property
    def inverting_feature_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``inverting_feature``.
        """

    @property
    def feature_inverted_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``feature_inverted``.
        """

class FeatureChaining(Relationship):
    """
    Implementation of ``FeatureChaining`` defined in the KerML
    specification.

    **Specification**:

       ``FeatureChaining`` is a ``Relationship`` that makes its target
       ``Feature`` one of the ``chaining_features`` of its owning
       ``Feature``.

    For language description, see section
    `7.3.4.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=63>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.3.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=199>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::FeatureChaining'

    STD: tuple[type[FeatureChaining], ...] = ...
    """
    All subtypes of ``FeatureChaining`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``FeatureChaining.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, FeatureChaining.STD):
            ...

    For type hints, instead use ``FeatureChaining.Std``:

    .. code-block:: python

        def function(element: Element) -> FeatureChaining.Std:
            ...

    Note that ``FeatureChaining.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "FeatureChaining.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = FeatureChaining
        """Type hint for all subtypes of ``FeatureChaining`` according to the specification"""

    CHAINABLE: bool = False
    """
    Whether this relationship can be used with chained features.

    Using this in, e.g. ``append_chain``, will raise ``TypeError``.
    """

    @property
    def chaining_feature(self) -> Feature | None:
        """
        Implementation of ``chaining_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` whose values partly determine values of
           ``feature_chained``, as described in ``Feature::chaining_feature``.

        See section
        `8.3.3.3.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=199>`__
        of the KerML specification for more details.
        """

    @property
    def feature_chained(self) -> Feature | None:
        """
        Implementation of ``feature_chained`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` whose values are partly determined by values of the
           ``chaining_feature``, as described in ``Feature::chaining_feature``.

        See section
        `8.3.3.3.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=199>`__
        of the KerML specification for more details.
        """

class ReferenceSubsetting(Subsetting):
    """
    Implementation of ``ReferenceSubsetting`` defined in the KerML
    specification.

    **Specification**:

       ``ReferenceSubsetting`` is a kind of ``Subsetting`` in which the
       ``referenced_feature`` is syntactically distinguished from other
       ``Features`` subsetted by the ``referencing_feature``.
       ``ReferenceSubsetting`` has the same semantics as ``Subsetting``, but
       the ``referenced_feature`` may have a special purpose relative to the
       ``referencing_feature``. For instance, ``ReferenceSubsetting`` is
       used to identify the ``related_features`` of a ``Connector``.

       ``ReferenceSubsetting`` is always an ``owned_relationship`` of its
       ``referencing_feature``. A ``Feature`` can have at most one
       ``owned_reference_subsetting``.

    For language description, see section
    `7.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=73>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.3.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=202>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::ReferenceSubsetting'

    STD: tuple[type[ReferenceSubsetting], ...] = ...
    """
    All subtypes of ``ReferenceSubsetting`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ReferenceSubsetting.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ReferenceSubsetting.STD):
            ...

    For type hints, instead use ``ReferenceSubsetting.Std``:

    .. code-block:: python

        def function(element: Element) -> ReferenceSubsetting.Std:
            ...

    Note that ``ReferenceSubsetting.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ReferenceSubsetting.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ReferenceSubsetting
        """Type hint for all subtypes of ``ReferenceSubsetting`` according to the specification"""

    CHAINABLE: bool = True
    """
    Whether this relationship can be used with chained features.

    Using this in, e.g. ``append_chain``, will not raise ``TypeError``.
    """

    @property
    def referenced_feature(self) -> Feature | None:
        """
        Implementation of ``referenced_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that is referenced by the ``referencing_feature`` of
           this ``ReferenceSubsetting``.

        See section
        `8.3.3.3.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=202>`__
        of the KerML specification for more details.
        """

    @property
    def referencing_feature(self) -> Feature | None:
        """
        Implementation of ``referencing_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that owns this ``ReferenceSubsetting`` relationship,
           which is also its ``subsetting_feature``.

        See section
        `8.3.3.3.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=202>`__
        of the KerML specification for more details.
        """

    @property
    def referenced_feature_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``referenced_feature``.
        """

    @property
    def referencing_feature_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``referencing_feature``.
        """

class Conjugation(Relationship):
    """
    Implementation of ``Conjugation`` defined in the KerML specification.

    **Specification**:

       ``Conjugation`` is a ``Relationship`` between two types in which the
       ``conjugated_type`` inherits all the ``Features`` of the
       ``original_type``, but with all ``input`` and ``output`` ``Features``
       reversed. That is, any ``Features`` with a ``direction`` *in*
       relative to the ``original_type`` are considered to have an effective
       ``direction`` of *out* relative to the ``conjugated_type`` and,
       similarly, ``Features`` with ``direction`` *out* in the
       ``original_type`` are considered to have an effective ``direction``
       of *in* in the ``conjugated_type``. ``Features`` with ``direction``
       *inout*, or with no ``direction``, in the ``original_type``, are
       inherited without change.

       A ``Type`` may participate as a ``conjugated_type`` in at most one
       ``Conjugation`` relationship, and such a ``Type`` may not also be the
       ``specific`` ``Type`` in any ``Specialization`` relationship.

    For language description, see section
    `7.3.2.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=54>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=163>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Conjugation'

    STD: tuple[type[Conjugation], ...] = ...
    """
    All subtypes of ``Conjugation`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Conjugation.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Conjugation.STD):
            ...

    For type hints, instead use ``Conjugation.Std``:

    .. code-block:: python

        def function(element: Element) -> Conjugation.Std:
            ...

    Note that ``Conjugation.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Conjugation.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Conjugation
        """Type hint for all subtypes of ``Conjugation`` according to the specification"""

    CHAINABLE: bool = True
    """
    Whether this relationship can be used with chained features.

    Using this in, e.g. ``append_chain``, will not raise ``TypeError``.
    """

    @property
    def original_type(self) -> Type | None:
        """
        Implementation of ``original_type`` defined in the KerML specification.

        **Specification**:

           The ``Type`` to be conjugated.

        See section
        `8.3.3.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=163>`__
        of the KerML specification for more details.
        """

    @property
    def conjugated_type(self) -> Type | None:
        """
        Implementation of ``conjugated_type`` defined in the KerML
        specification.

        **Specification**:

           The ``Type`` that is the result of applying ``Conjugation`` to the
           ``original_type``.

        See section
        `8.3.3.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=163>`__
        of the KerML specification for more details.
        """

    @property
    def owning_type(self) -> Type | None:
        """
        Implementation of ``owning_type`` defined in the KerML specification.

        **Specification**:

           The ``conjugated_type`` of this ``Conjugation`` that is also its
           ``owning_related_element``.

        See section
        `8.3.3.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=163>`__
        of the KerML specification for more details.
        """

    @property
    def children(self) -> RelationshipBody:
        """The elements enclosed by curly brackets in textual syntax."""

    @property
    def original_type_target(self) -> ChainedTypeReference:
        """
        Syside specific accessor for manipulating the target of ``original_type``.
        """

    @property
    def conjugated_type_target(self) -> ChainedTypeReference:
        """
        Syside specific accessor for manipulating the target of ``conjugated_type``.
        """

class Multiplicity(Feature):
    r"""
    Implementation of ``Multiplicity`` defined in the KerML specification.

    **Specification**:

       A ``Multiplicity`` is a ``Feature`` whose co-domain is a set of
       natural numbers giving the allowed cardinalities of each
       ``type_with_multiplicity``. The *cardinality* of a ``Type`` is
       defined as follows, depending on whether the ``Type`` is a
       ``Classifier`` or ``Feature``.

       - ``Classifier`` – The number of basic instances of the
         ``Classifier``, that is, those instances representing things, which
         are not instances of any subtypes of the ``Classifier`` that are
         ``Features``.\* ``Features`` – The number of instances with the
         same featuring instances. In the case of a ``Feature`` with a
         ``Classifier`` as its ``featuring_type``, this is the number of
         values of ``Feature`` for each basic instance of the
         ``Classifier``. Note that, for non-unique ``Features``, all
         duplicate values are included in this count.

       ``Multiplicity`` co-domains (in models) can be specified by
       ``Expression`` that might vary in their results. If the
       ``type_with_multiplicity`` is a ``Classifier``, the domain of the
       ``Multiplicity`` shall be ``Base::Anything``. If the
       ``type_with_multiplicity`` is a ``Feature``, the ``Multiplicity``
       shall have the same domain as the ``type_with_multiplicity``.

    For language description, see section
    `7.4.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=93>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.1.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=167>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Multiplicity'

    STD: tuple[type[Multiplicity], ...] = ...
    """
    All subtypes of ``Multiplicity`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Multiplicity.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Multiplicity.STD):
            ...

    For type hints, instead use ``Multiplicity.Std``:

    .. code-block:: python

        def function(element: Element) -> Multiplicity.Std:
            ...

    Note that ``Multiplicity.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Multiplicity.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Multiplicity
        """Type hint for all subtypes of ``Multiplicity`` according to the specification"""

class Intersecting(Relationship):
    """
    Implementation of ``Intersecting`` defined in the KerML specification.

    **Specification**:

       ``Intersecting`` is a ``Relationship`` that makes its
       ``intersecting_type`` one of the ``intersecting_types`` of its
       ``type_intersected``.

    For language description, see section
    `7.3.2.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=56>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.1.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=166>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Intersecting'

    STD: tuple[type[Intersecting], ...] = ...
    """
    All subtypes of ``Intersecting`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Intersecting.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Intersecting.STD):
            ...

    For type hints, instead use ``Intersecting.Std``:

    .. code-block:: python

        def function(element: Element) -> Intersecting.Std:
            ...

    Note that ``Intersecting.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Intersecting.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Intersecting
        """Type hint for all subtypes of ``Intersecting`` according to the specification"""

    CHAINABLE: bool = True
    """
    Whether this relationship can be used with chained features.

    Using this in, e.g. ``append_chain``, will not raise ``TypeError``.
    """

    @property
    def intersecting_type(self) -> Type | None:
        """
        Implementation of ``intersecting_type`` defined in the KerML
        specification.

        **Specification**:

           ``Type`` that partly determines interpretations of
           ``type_intersected``, as described in ``Type::intersecting_type``.

        See section
        `8.3.3.1.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=166>`__
        of the KerML specification for more details.
        """

    @property
    def type_intersected(self) -> Type | None:
        """
        Implementation of ``type_intersected`` defined in the KerML
        specification.

        **Specification**:

           ``Type`` with interpretations partly determined by
           ``intersecting_type``, as described in ``Type::intersecting_type``.

        See section
        `8.3.3.1.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=166>`__
        of the KerML specification for more details.
        """

class Unioning(Relationship):
    """
    Implementation of ``Unioning`` defined in the KerML specification.

    **Specification**:

       ``Unioning`` is a ``Relationship`` that makes its ``unioning_type``
       one of the ``unioning_types`` of its ``type_unioned``.

    For language description, see section
    `7.3.2.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=56>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.1.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=177>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Unioning'

    STD: tuple[type[Unioning], ...] = ...
    """
    All subtypes of ``Unioning`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Unioning.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Unioning.STD):
            ...

    For type hints, instead use ``Unioning.Std``:

    .. code-block:: python

        def function(element: Element) -> Unioning.Std:
            ...

    Note that ``Unioning.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Unioning.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Unioning
        """Type hint for all subtypes of ``Unioning`` according to the specification"""

    CHAINABLE: bool = True
    """
    Whether this relationship can be used with chained features.

    Using this in, e.g. ``append_chain``, will not raise ``TypeError``.
    """

    @property
    def type_unioned(self) -> Type | None:
        """
        Implementation of ``type_unioned`` defined in the KerML specification.

        **Specification**:

           ``Type`` with interpretations partly determined by ``unioning_type``,
           as described in ``Type::unioning_type``.

        See section
        `8.3.3.1.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=177>`__
        of the KerML specification for more details.
        """

    @property
    def unioning_type(self) -> Type | None:
        """
        Implementation of ``unioning_type`` defined in the KerML specification.

        **Specification**:

           ``Type`` that partly determines interpretations of ``type_unioned``,
           as described in ``Type::unioning_type``.

        See section
        `8.3.3.1.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=177>`__
        of the KerML specification for more details.
        """

class Disjoining(Relationship):
    """
    Implementation of ``Disjoining`` defined in the KerML specification.

    **Specification**:

       A ``Disjoining`` is a ``Relationship`` between ``Types`` asserted to
       have interpretations that are not shared (disjoint) between them,
       identified as ``type_disjoined`` and ``disjoining_type``. For
       example, a ``Classifier`` for mammals is disjoint from a
       ``Classifier`` for minerals, and a ``Feature`` for people’s parents
       is disjoint from a ``Feature`` for their children.

    For language description, see section
    `7.3.2.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=55>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.1.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=164>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Disjoining'

    STD: tuple[type[Disjoining], ...] = ...
    """
    All subtypes of ``Disjoining`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Disjoining.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Disjoining.STD):
            ...

    For type hints, instead use ``Disjoining.Std``:

    .. code-block:: python

        def function(element: Element) -> Disjoining.Std:
            ...

    Note that ``Disjoining.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Disjoining.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Disjoining
        """Type hint for all subtypes of ``Disjoining`` according to the specification"""

    CHAINABLE: bool = True
    """
    Whether this relationship can be used with chained features.

    Using this in, e.g. ``append_chain``, will not raise ``TypeError``.
    """

    @property
    def disjoining_type(self) -> Type | None:
        """
        Implementation of ``disjoining_type`` defined in the KerML
        specification.

        **Specification**:

           ``Type`` asserted to be disjoint with the ``type_disjoined``.

        See section
        `8.3.3.1.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=164>`__
        of the KerML specification for more details.
        """

    @property
    def type_disjoined(self) -> Type | None:
        """
        Implementation of ``type_disjoined`` defined in the KerML specification.

        **Specification**:

           ``Type`` asserted to be disjoint with the ``disjoining_type``.

        See section
        `8.3.3.1.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=164>`__
        of the KerML specification for more details.
        """

    @property
    def owning_type(self) -> Type | None:
        """
        Implementation of ``owning_type`` defined in the KerML specification.

        **Specification**:

           A ``type_disjoined`` that is also an ``owning_related_element``.

        See section
        `8.3.3.1.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=164>`__
        of the KerML specification for more details.
        """

    @property
    def children(self) -> RelationshipBody:
        """The elements enclosed by curly brackets in textual syntax."""

    @property
    def disjoining_type_target(self) -> ChainedTypeReference:
        """
        Syside specific accessor for manipulating the target of ``disjoining_type``.
        """

    @property
    def type_disjoined_target(self) -> ChainedTypeReference:
        """
        Syside specific accessor for manipulating the target of ``type_disjoined``.
        """

class Differencing(Relationship):
    """
    Implementation of ``Differencing`` defined in the KerML specification.

    **Specification**:

       ``Differencing`` is a ``Relationship`` that makes its
       ``differencing_type`` one of the ``differencing_types`` of its
       ``type_differenced``.

    For language description, see section
    `7.3.2.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=56>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=164>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Differencing'

    STD: tuple[type[Differencing], ...] = ...
    """
    All subtypes of ``Differencing`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Differencing.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Differencing.STD):
            ...

    For type hints, instead use ``Differencing.Std``:

    .. code-block:: python

        def function(element: Element) -> Differencing.Std:
            ...

    Note that ``Differencing.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Differencing.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Differencing
        """Type hint for all subtypes of ``Differencing`` according to the specification"""

    CHAINABLE: bool = True
    """
    Whether this relationship can be used with chained features.

    Using this in, e.g. ``append_chain``, will not raise ``TypeError``.
    """

    @property
    def differencing_type(self) -> Type | None:
        """
        Implementation of ``differencing_type`` defined in the KerML
        specification.

        **Specification**:

           ``Type`` that partly determines interpretations of
           ``type_differenced``, as described in ``Type::differencing_type``.

        See section
        `8.3.3.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=164>`__
        of the KerML specification for more details.
        """

    @property
    def type_differenced(self) -> Type | None:
        """
        Implementation of ``type_differenced`` defined in the KerML
        specification.

        **Specification**:

           ``Type`` with interpretations partly determined by
           ``differencing_type``, as described in ``Type::differencing_type``.

        See section
        `8.3.3.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=164>`__
        of the KerML specification for more details.
        """

class Classifier(Type):
    """
    Implementation of ``Classifier`` defined in the KerML specification.

    **Specification**:

       A ``Classifier`` is a ``Type`` that classifies:

       - Things (in the universe) regardless of how ``Features`` relate
         them. (These are interpreted semantically as sequences of exactly
         one thing.)
       - How the above things are related by ``Features.`` (These are
         interpreted semantically as sequences of multiple things, such that
         the last thing in the sequence is also classified by the
         ``Classifier``. Note that this means that a ``Classifier`` modeled
         as specializing a ``Feature`` cannot classify anything.)

    For language description, see section
    `7.3.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=57>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.2.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=178>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Classifier'

    STD: tuple[type[Classifier], ...] = ...
    """
    All subtypes of ``Classifier`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Classifier.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Classifier.STD):
            ...

    For type hints, instead use ``Classifier.Std``:

    .. code-block:: python

        def function(element: Element) -> Classifier.Std:
            ...

    Note that ``Classifier.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Classifier.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Classifier
        """Type hint for all subtypes of ``Classifier`` according to the specification"""

    @property
    def owned_subclassifications(self) -> LazyIterator[Subclassification]:
        """
        Implementation of ``owned_subclassification`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_specializations`` of this ``Classifier`` that are
           ``Subclassifications``, for which this ``Classifier`` is the
           ``subclassifier``.

        See section
        `8.3.3.2.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=178>`__
        of the KerML specification for more details.
        """

    @property
    def owned_subclassification_types(self) -> LazyIterator[Classifier]:
        """
        The ``Classifiers`` related to this ``Classifier`` by ``owned_subclassifications``.
        """

class EndFeatureMembership(FeatureMembership):
    """
    Implementation of ``EndFeatureMembership`` defined in the KerML
    specification.

    **Specification**:

       ``EndFeatureMembership`` is a ``FeatureMembership`` that requires its
       ``member_feature`` be owned and have ``is_end = true``.

    For language description, see section
    `7.4.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=68>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.3.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=184>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::EndFeatureMembership'

    STD: tuple[type[EndFeatureMembership], ...] = ...
    """
    All subtypes of ``EndFeatureMembership`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``EndFeatureMembership.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, EndFeatureMembership.STD):
            ...

    For type hints, instead use ``EndFeatureMembership.Std``:

    .. code-block:: python

        def function(element: Element) -> EndFeatureMembership.Std:
            ...

    Note that ``EndFeatureMembership.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "EndFeatureMembership.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = EndFeatureMembership
        """Type hint for all subtypes of ``EndFeatureMembership`` according to the specification"""

class Class(Classifier):
    """
    Implementation of ``Class`` defined in the KerML specification.

    **Specification**:

       A ``Class`` is a ``Classifier`` of things (in the universe) that can
       be distinguished without regard to how they are related to other
       things (via ``Features``). This means multiple things classified by
       the same ``Class`` can be distinguished, even when they are related
       other things in exactly the same way.

    For language description, see section
    `7.4.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=67>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.2.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=205>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Class'

    STD: tuple[Union[type[Class], type[AssociationStructure], type[Interaction], type[OccurrenceDefinition]], ...] = ...
    """
    All subtypes of ``Class`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Class.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Class.STD):
            ...

    For type hints, instead use ``Class.Std``:

    .. code-block:: python

        def function(element: Element) -> Class.Std:
            ...

    Note that ``Class.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Class.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[Class, AssociationStructure, Interaction, OccurrenceDefinition]
        """Type hint for all subtypes of ``Class`` according to the specification"""

class Structure(Class):
    """
    Implementation of ``Structure`` defined in the KerML specification.

    **Specification**:

       A ``Structure`` is a ``Class`` of objects in the modeled universe
       that are primarily structural in nature. While such an object is not
       itself behavioral, it may be involved in and acted on by
       ``Behaviors``, and it may be the performer of some of them.

    For language description, see section
    `7.4.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=68>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=206>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Structure'

    STD: tuple[Union[type[Structure], type[AssociationStructure], type[ItemDefinition], type[PortDefinition]], ...] = ...
    """
    All subtypes of ``Structure`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Structure.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Structure.STD):
            ...

    For type hints, instead use ``Structure.Std``:

    .. code-block:: python

        def function(element: Element) -> Structure.Std:
            ...

    Note that ``Structure.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Structure.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[Structure, AssociationStructure, ItemDefinition, PortDefinition]
        """Type hint for all subtypes of ``Structure`` according to the specification"""

class DataType(Classifier):
    """
    Implementation of ``DataType`` defined in the KerML specification.

    **Specification**:

       A ``DataType`` is a ``Classifier`` of things (in the universe) that
       can only be distinguished by how they are related to other things
       (via Features). This means multiple things classified by the same
       ``DataType``

       - Cannot be distinguished when they are related to other things in
         exactly the same way, even when they are intended to be about
         different things.
       - Can be distinguished when they are related to other things in
         different ways, even when they are intended to be about the same
         thing.

    For language description, see section
    `7.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=66>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=204>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::DataType'

    STD: tuple[Union[type[DataType], type[AttributeDefinition]], ...] = ...
    """
    All subtypes of ``DataType`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``DataType.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, DataType.STD):
            ...

    For type hints, instead use ``DataType.Std``:

    .. code-block:: python

        def function(element: Element) -> DataType.Std:
            ...

    Note that ``DataType.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "DataType.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[DataType, AttributeDefinition]
        """Type hint for all subtypes of ``DataType`` according to the specification"""

class Package(Namespace):
    """
    Implementation of ``Package`` defined in the KerML specification.

    **Specification**:

       A ``Package`` is a ``Namespace`` used to group ``Elements``, without
       any instance-level semantics. It may have one or more model-level
       evaluable ``filter_condition`` ``Expressions`` used to filter its
       ``imported_memberships``. Any imported ``member`` must meet all of
       the ``filter_conditions``.

    For language description, see section
    `7.4.14 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=97>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.13.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=261>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Package'

    STD: tuple[type[Package], ...] = ...
    """
    All subtypes of ``Package`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Package.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Package.STD):
            ...

    For type hints, instead use ``Package.Std``:

    .. code-block:: python

        def function(element: Element) -> Package.Std:
            ...

    Note that ``Package.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Package.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Package
        """Type hint for all subtypes of ``Package`` according to the specification"""

    @property
    def filter_conditions(self) -> LazyIterator[ElementFilterMembership]:
        """
        Implementation of ``filter_condition`` defined in the KerML
        specification.

        **Specification**:

           The model-level evaluable ``Boolean``-valued ``Expression`` used to
           filter the ``members`` of this ``Package``, which are owned by the
           ``Package`` are via ``ElementFilterMemberships``.

        See section
        `8.3.4.13.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=261>`__
        of the KerML specification for more details.
        """

class LibraryPackage(Package):
    """
    Implementation of ``LibraryPackage`` defined in the KerML specification.

    **Specification**:

       A ``LibraryPackage`` is a ``Package`` that is the container for a
       model library. A ``LibraryPackage`` is itself a library ``Element``
       as are all ``Elements`` that are directly or indirectly contained in
       it.

    For language description, see section
    `7.4.14 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=97>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.13.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=260>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::LibraryPackage'

    STD: tuple[type[LibraryPackage], ...] = ...
    """
    All subtypes of ``LibraryPackage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``LibraryPackage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, LibraryPackage.STD):
            ...

    For type hints, instead use ``LibraryPackage.Std``:

    .. code-block:: python

        def function(element: Element) -> LibraryPackage.Std:
            ...

    Note that ``LibraryPackage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "LibraryPackage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = LibraryPackage
        """Type hint for all subtypes of ``LibraryPackage`` according to the specification"""

    @property
    def is_standard(self) -> bool:
        """
        Implementation of ``is_standard`` defined in the KerML specification.

        **Specification**:

           Whether this ``LibraryPackage`` contains a standard library model.
           This should only be set to true for ``LibraryPackages`` in the
           standard Kernel Model Libraries or in normative model libraries for a
           language built on KerML.

        See section
        `8.3.4.13.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=260>`__
        of the KerML specification for more details.
        """

    @is_standard.setter
    def is_standard(self, arg: bool, /) -> None: ...

class Step(Feature):
    """
    Implementation of ``Step`` defined in the KerML specification.

    **Specification**:

       A ``Step`` is a ``Feature`` that is typed by one or more
       ``Behaviors``. ``Steps`` may be used by one ``Behavior`` to
       coordinate the performance of other ``Behaviors``, supporting a
       steady refinement of behavioral descriptions. ``Steps`` can be
       ordered in time and can be connected using ``Flows`` to specify
       things flowing between their ``parameters``.

    For language description, see section
    `7.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=79>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=217>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Step'

    STD: tuple[Union[type[Step], type[ActionUsage], type[ConstraintUsage], type[Flow], type[FlowUsage]], ...] = ...
    """
    All subtypes of ``Step`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Step.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Step.STD):
            ...

    For type hints, instead use ``Step.Std``:

    .. code-block:: python

        def function(element: Element) -> Step.Std:
            ...

    Note that ``Step.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Step.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[Step, ActionUsage, ConstraintUsage, Flow, FlowUsage]
        """Type hint for all subtypes of ``Step`` according to the specification"""

    @property
    def behaviors(self) -> LazyIterator[Behavior | ActionDefinition]:
        """
        Implementation of ``behavior`` defined in the KerML specification.

        **Specification**:

           The ``Behaviors`` that type this ``Step``.

        See section
        `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=218>`__
        of the KerML specification for more details.
        """

    @property
    def owned_parameters(self) -> LazyIterator[Feature]:
        """The ``parameters`` owned by this ``Step``."""

    @property
    def parameters(self) -> LazyIterator[Feature]:
        """
        Implementation of ``parameter`` defined in the KerML specification.

        **Specification**:

           The ``parameters`` of this ``Step``, which are defined as its
           ``directed_features``, whose values are passed into and/or out of a
           performance of the ``Step``.

        See section
        `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=218>`__
        of the KerML specification for more details.
        """

class Expression(Step):
    """
    Implementation of ``Expression`` defined in the KerML specification.

    **Specification**:

       An ``Expression`` is a ``Step`` that is typed by a ``Function``. An
       ``Expression`` that also has a ``Function`` as its ``featuring_type``
       is a computational step within that ``Function``. An ``Expression``
       always has a single ``result`` parameter, which redefines the
       ``result`` parameter of its defining ``function``. This allows
       ``Expressions`` to be interconnected in tree structures, in which
       inputs to each ``Expression`` in the tree are determined as the
       results of other ``Expression`` in the tree.

    For language description, see section
    `7.4.8.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=81>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=221>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Expression'

    STD: tuple[Union[type[Expression], type[CalculationUsage], type[ConstraintUsage]], ...] = ...
    """
    All subtypes of ``Expression`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Expression.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Expression.STD):
            ...

    For type hints, instead use ``Expression.Std``:

    .. code-block:: python

        def function(element: Element) -> Expression.Std:
            ...

    Note that ``Expression.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Expression.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[Expression, CalculationUsage, ConstraintUsage]
        """Type hint for all subtypes of ``Expression`` according to the specification"""

    @property
    def cached_result_type(self) -> None | Type | TypeGuard:
        """The result type of this ``Expression`` as inferred by sema"""

    @property
    def is_model_level_evaluable(self) -> bool:
        """
        Implementation of ``is_model_level_evaluable`` defined in the KerML
        specification.

        **Specification**:

           Whether this ``Expression`` meets the constraints necessary to be
           evaluated at *model level*, that is, using metadata within the model.

        See section
        `8.3.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=221>`__
        of the KerML specification for more details.
        """

    @property
    def function(self) -> Function | CalculationDefinition | ConstraintDefinition | None:
        """
        Implementation of ``function`` defined in the KerML specification.

        **Specification**:

           The ``Function`` that types this ``Expression``.

           This is the Function that types the Expression.

        See section
        `8.3.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=221>`__
        of the KerML specification for more details.
        """

    @property
    def result(self) -> Feature | None:
        """
        Implementation of ``result`` defined in the KerML specification.

        **Specification**:

           An ``output`` ``parameter`` of the ``Expression`` whose value is the
           result of the ``Expression``. The result of an ``Expression`` is
           either inherited from its ``function`` or it is related to the
           ``Expression`` via a ``ReturnParameterMembership``, in which case it
           redefines the ``result`` ``parameter`` of its ``function``.

        See section
        `8.3.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=222>`__
        of the KerML specification for more details.
        """

    @property
    def result_expression(self) -> Expression | None:
        """
        The result expression of this ``Expression`` owned by ``ResultExpressionMembership``.
        """

    @property
    def result_expression_member(self) -> ResultExpressionAccessor:
        """Syside specific accessor for manipulating ``result_expression``."""

class Behavior(Class):
    """
    Implementation of ``Behavior`` defined in the KerML specification.

    **Specification**:

       A ``Behavior`` coordinates occurrences of other ``Behaviors``, as
       well as changes in objects. ``Behaviors`` can be decomposed into
       ``Steps`` and be characterized by ``parameters``.

    For language description, see section
    `7.4.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=77>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=217>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Behavior'

    STD: tuple[Union[type[Behavior], type[ActionDefinition], type[ConstraintDefinition], type[Interaction]], ...] = ...
    """
    All subtypes of ``Behavior`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Behavior.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Behavior.STD):
            ...

    For type hints, instead use ``Behavior.Std``:

    .. code-block:: python

        def function(element: Element) -> Behavior.Std:
            ...

    Note that ``Behavior.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Behavior.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[Behavior, ActionDefinition, ConstraintDefinition, Interaction]
        """Type hint for all subtypes of ``Behavior`` according to the specification"""

    @property
    def steps(self) -> LazyIterator[Step | ActionUsage | FlowUsage]:
        """
        Implementation of ``step`` defined in the KerML specification.

        **Specification**:

           The ``Steps`` that make up this ``Behavior``.

        See section
        `8.3.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=217>`__
        of the KerML specification for more details.
        """

    @property
    def parameters(self) -> LazyIterator[Feature]:
        """
        Implementation of ``parameter`` defined in the KerML specification.

        **Specification**:

           The parameters of this ``Behavior``, which are defined as its
           ``directed_features``, whose values are passed into and/or out of a
           performance of the ``Behavior``.

        See section
        `8.3.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=217>`__
        of the KerML specification for more details.
        """

class Function(Behavior):
    """
    Implementation of ``Function`` defined in the KerML specification.

    **Specification**:

       A ``Function`` is a ``Behavior`` that has an ``out`` ``parameter``
       that is identified as its ``result``. A ``Function`` represents the
       performance of a calculation that produces the values of its
       ``result`` ``parameter``. This calculation may be decomposed into
       ``Expressions`` that are ``steps`` of the ``Function``.

    For language description, see section
    `7.4.8.1 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=79>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.7.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Function'

    STD: tuple[Union[type[Function], type[CalculationDefinition], type[ConstraintDefinition]], ...] = ...
    """
    All subtypes of ``Function`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Function.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Function.STD):
            ...

    For type hints, instead use ``Function.Std``:

    .. code-block:: python

        def function(element: Element) -> Function.Std:
            ...

    Note that ``Function.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Function.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[Function, CalculationDefinition, ConstraintDefinition]
        """Type hint for all subtypes of ``Function`` according to the specification"""

    @property
    def is_model_level_evaluable(self) -> bool:
        """
        Implementation of ``is_model_level_evaluable`` defined in the KerML
        specification.

        **Specification**:

           Whether this ``Function`` can be used as the ``function`` of a
           model-level evaluable ``InvocationExpression``. Certain ``Functions``
           from the Kernel Functions Library are considered to have
           ``is_model_level_evaluable = true``. For all other ``Functions`` it
           is ``false``.

           **Note:** See the specification of the KerML concrete syntax notation
           for ``Expressions`` for an identification of which library
           ``Functions`` are model-level evaluable.

        See section
        `8.3.4.7.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
        of the KerML specification for more details.
        """

    @property
    def expressions(self) -> LazyIterator[Expression | CalculationUsage | ConstraintUsage]:
        """
        Implementation of ``expression`` defined in the KerML specification.

        **Specification**:

           The ``Expressions`` that are ``steps`` in the calculation of the
           ``result`` of this ``Function``.

           The set of expressions that represent computational steps or parts of
           a system of equations within the Function.

        See section
        `8.3.4.7.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
        of the KerML specification for more details.
        """

    @property
    def result(self) -> Feature | None:
        """
        Implementation of ``result`` defined in the KerML specification.

        **Specification**:

           The object or value that is the result of evaluating the Function.

           The ``result`` ``parameter`` of the ``Function``, which is owned by
           the ``Function`` via a ``ReturnParameterMembership``.

        See section
        `8.3.4.7.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
        of the KerML specification for more details.
        """

    @property
    def any_result(self) -> Feature | None:
        """``result`` that also considers specialized ``Functions``."""

    @property
    def result_expression(self) -> Expression | None:
        """
        The result expression of this ``Function`` owned by ``ResultExpressionMembership``.
        """

    @property
    def result_expression_member(self) -> ResultExpressionAccessor:
        """Syside specific accessor for manipulating ``result_expression``."""

class ElementFilterMembership(OwningMembership):
    """
    Implementation of ``ElementFilterMembership`` defined in the KerML
    specification.

    **Specification**:

       ``ElementFilterMembership`` is a ``Membership`` between a
       ``Namespace`` and a model-level evaluable ``Boolean``-valued
       ``Expression``, asserting that imported ``members`` of the
       ``Namespace`` should be filtered using the ``condition``
       ``Expression``. A general ``Namespace`` does not define any specific
       filtering behavior, but such behavior may be defined for various
       specialized kinds of ``Namespaces``.

    For language description, see section
    `7.2.5.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=49>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.13.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=259>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::ElementFilterMembership'

    STD: tuple[type[ElementFilterMembership], ...] = ...
    """
    All subtypes of ``ElementFilterMembership`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ElementFilterMembership.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ElementFilterMembership.STD):
            ...

    For type hints, instead use ``ElementFilterMembership.Std``:

    .. code-block:: python

        def function(element: Element) -> ElementFilterMembership.Std:
            ...

    Note that ``ElementFilterMembership.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ElementFilterMembership.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ElementFilterMembership
        """Type hint for all subtypes of ``ElementFilterMembership`` according to the specification"""

    @property
    def condition(self) -> Expression | None:
        """
        Implementation of ``condition`` defined in the KerML specification.

        **Specification**:

           The model-level evaluable ``Boolean``-valued ``Expression`` used to
           filter the imported ``members`` of the
           ``membership_owning_namespace`` of this ``ElementFilterMembership``.

        See section
        `8.3.4.13.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=260>`__
        of the KerML specification for more details.
        """

class LiteralExpression(Expression):
    """
    Implementation of ``LiteralExpression`` defined in the KerML
    specification.

    **Specification**:

       A ``LiteralExpression`` is an ``Expression`` that provides a basic
       ``DataValue`` as a result.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=87>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=239>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::LiteralExpression'

    STD: tuple[type[LiteralExpression], ...] = ...
    """
    All subtypes of ``LiteralExpression`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``LiteralExpression.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, LiteralExpression.STD):
            ...

    For type hints, instead use ``LiteralExpression.Std``:

    .. code-block:: python

        def function(element: Element) -> LiteralExpression.Std:
            ...

    Note that ``LiteralExpression.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "LiteralExpression.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = LiteralExpression
        """Type hint for all subtypes of ``LiteralExpression`` according to the specification"""

class LiteralString(LiteralExpression):
    """
    Implementation of ``LiteralString`` defined in the KerML specification.

    **Specification**:

       A ``LiteralString`` is a ``LiteralExpression`` that provides a
       ``String`` value as a result. Its ``result`` ``parameter`` must have
       the type ``String``.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=87>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.14 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=241>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::LiteralString'

    STD: tuple[type[LiteralString], ...] = ...
    """
    All subtypes of ``LiteralString`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``LiteralString.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, LiteralString.STD):
            ...

    For type hints, instead use ``LiteralString.Std``:

    .. code-block:: python

        def function(element: Element) -> LiteralString.Std:
            ...

    Note that ``LiteralString.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "LiteralString.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = LiteralString
        """Type hint for all subtypes of ``LiteralString`` according to the specification"""

    @property
    def value(self) -> str:
        """
        Implementation of ``value`` defined in the KerML specification.

        **Specification**:

           The String value that is the result of evaluating this Expression.

           The ``String`` value that is the result of evaluating this
           ``LiteralString``.

        See section
        `8.3.4.8.14 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=241>`__
        of the KerML specification for more details.
        """

    @value.setter
    def value(self, arg: str, /) -> None: ...

class LiteralRational(LiteralExpression):
    """
    Implementation of ``LiteralRational`` defined in the KerML
    specification.

    **Specification**:

       A ``LiteralRational`` is a ``LiteralExpression`` that provides a
       ``Rational`` value as a result. Its ``result`` ``parameter`` must
       have the type ``Rational``.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=87>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.13 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=241>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::LiteralRational'

    STD: tuple[type[LiteralRational], ...] = ...
    """
    All subtypes of ``LiteralRational`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``LiteralRational.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, LiteralRational.STD):
            ...

    For type hints, instead use ``LiteralRational.Std``:

    .. code-block:: python

        def function(element: Element) -> LiteralRational.Std:
            ...

    Note that ``LiteralRational.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "LiteralRational.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = LiteralRational
        """Type hint for all subtypes of ``LiteralRational`` according to the specification"""

    @property
    def value(self) -> float:
        """
        Implementation of ``value`` defined in the KerML specification.

        **Specification**:

           The value whose rational approximation is the result of evaluating
           this ``LiteralRational``.

           The Real value that is the result of evaluating this Expression.

        See section
        `8.3.4.8.13 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=241>`__
        of the KerML specification for more details.
        """

    @value.setter
    def value(self, arg: float, /) -> None: ...

class FeatureReferenceExpression(Expression):
    """
    Implementation of ``FeatureReferenceExpression`` defined in the KerML
    specification.

    **Specification**:

       A ``FeatureReferenceExpression`` is an ``Expression`` whose
       ``result`` is bound to a ``referent`` ``Feature``.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=87>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=232>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::FeatureReferenceExpression'

    STD: tuple[type[FeatureReferenceExpression], ...] = ...
    """
    All subtypes of ``FeatureReferenceExpression`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``FeatureReferenceExpression.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, FeatureReferenceExpression.STD):
            ...

    For type hints, instead use ``FeatureReferenceExpression.Std``:

    .. code-block:: python

        def function(element: Element) -> FeatureReferenceExpression.Std:
            ...

    Note that ``FeatureReferenceExpression.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "FeatureReferenceExpression.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = FeatureReferenceExpression
        """Type hint for all subtypes of ``FeatureReferenceExpression`` according to the specification"""

    @property
    def referent(self) -> Feature | None:
        """
        Implementation of ``referent`` defined in the KerML specification.

        **Specification**:

           The ``Feature`` that is referenced by this
           ``FeatureReferenceExpression``, which is its first non-``parameter``
           ``member``.

        See section
        `8.3.4.8.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=232>`__
        of the KerML specification for more details.
        """

    @property
    def referent_member(self) -> ReferentAccessor:
        """Syside specific accessor for manipulating ``referent``."""

class LiteralInteger(LiteralExpression):
    """
    Implementation of ``LiteralInteger`` defined in the KerML specification.

    **Specification**:

       A ``LiteralInteger`` is a ``LiteralExpression`` that provides an
       ``Integer`` value as a result. Its ``result`` ``parameter`` must have
       the type ``Integer``.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=87>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=240>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::LiteralInteger'

    STD: tuple[type[LiteralInteger], ...] = ...
    """
    All subtypes of ``LiteralInteger`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``LiteralInteger.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, LiteralInteger.STD):
            ...

    For type hints, instead use ``LiteralInteger.Std``:

    .. code-block:: python

        def function(element: Element) -> LiteralInteger.Std:
            ...

    Note that ``LiteralInteger.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "LiteralInteger.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = LiteralInteger
        """Type hint for all subtypes of ``LiteralInteger`` according to the specification"""

    @property
    def value(self) -> int:
        """
        Implementation of ``value`` defined in the KerML specification.

        **Specification**:

           The ``Integer`` value that is the result of evaluating this
           ``LiteralInteger``.

           The Integer value that is the result of evaluating this Expression.

        See section
        `8.3.4.8.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=240>`__
        of the KerML specification for more details.
        """

    @value.setter
    def value(self, arg: int, /) -> None: ...

class InstantiationExpression(Expression):
    """
    Implementation of ``InstantiationExpression`` defined in the KerML
    specification.

    **Specification**:

       An ``InstantiationExpression`` is an ``Expression`` that instantiates
       its ``instantiated_type``, binding some or all of the ``features`` of
       that ``Type`` to the ``results`` of its ``arguments``.

       ``InstantiationExpression`` is abstract, with concrete subclasses
       ``InvocationExpression`` and ``ConstructorExpression``.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=87>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=235>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::InstantiationExpression'

    STD: tuple[type[InstantiationExpression], ...] = ...
    """
    All subtypes of ``InstantiationExpression`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``InstantiationExpression.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, InstantiationExpression.STD):
            ...

    For type hints, instead use ``InstantiationExpression.Std``:

    .. code-block:: python

        def function(element: Element) -> InstantiationExpression.Std:
            ...

    Note that ``InstantiationExpression.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "InstantiationExpression.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = InstantiationExpression
        """Type hint for all subtypes of ``InstantiationExpression`` according to the specification"""

    @property
    def arguments(self) -> ArgumentsAccessor:
        """
        Implementation of ``argument`` defined in the KerML specification.

        **Specification**:

           The ``Expressions`` whose ``results`` are bound to ``features`` of
           the ``instantiated_type``. The ``arguments`` are ordered consistent
           with the order of the ``features``, though they may not be one-to-one
           with all the ``features``.

           **Note.** The derivation of ``argument`` is given in the concrete
           subclasses of ``InstantiationExpression``.

        See section
        `8.3.4.8.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=235>`__
        of the KerML specification for more details.
        """

    @property
    def instantiated_type(self) -> Type | None:
        """
        Implementation of ``instantiated_type`` defined in the KerML
        specification.

        **Specification**:

           The ``Type`` that is being instantiated.

        See section
        `8.3.4.8.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=235>`__
        of the KerML specification for more details.
        """

    @property
    def instantiated_type_membership(self) -> Membership | None:
        """
        The ``Membership`` that relates this ``InstantiationExpression`` to the ``instantiated_type``.
        """

class InvocationExpression(InstantiationExpression):
    """
    Implementation of ``InvocationExpression`` defined in the KerML
    specification.

    **Specification**:

       An ``InvocationExpression`` is an ``InstantiationExpression`` whose
       ``instantiated_type`` must be a ``Behavior`` or a ``Feature`` typed
       by a single ``Behavior`` (such as a ``Step``). Each of the input
       ``parameters`` of the ``instantiated_type`` are bound to the
       ``result`` of an ``argument`` ``Expression``. If the
       ``instantiated_type`` is a ``Function`` or a ``Feature`` typed by a
       ``Function``, then the ``result`` of the ``InvocationExpression`` is
       the ``result`` of the invoked ``Function``. Otherwise, the ``result``
       is an instance of the ``instantiated_type`` (essentially like a
       behavioral ``ConstructorExpression``).

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=87>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=236>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::InvocationExpression'

    STD: tuple[type[InvocationExpression], ...] = ...
    """
    All subtypes of ``InvocationExpression`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``InvocationExpression.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, InvocationExpression.STD):
            ...

    For type hints, instead use ``InvocationExpression.Std``:

    .. code-block:: python

        def function(element: Element) -> InvocationExpression.Std:
            ...

    Note that ``InvocationExpression.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "InvocationExpression.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = InvocationExpression
        """Type hint for all subtypes of ``InvocationExpression`` according to the specification"""

    @property
    def operands(self) -> LazyIterator[Expression]:
        """
        Arguments that are parameter members.

        Typically, this will be equivalent to ``arguments``.
        """

class ConstructorExpression(InstantiationExpression):
    """
    Implementation of ``ConstructorExpression`` defined in the KerML
    specification.

    **Specification**:

       A ``ConstructorExpression`` is an ``InstantiationExpression`` whose
       ``result`` specializes its ``instantiated_type``, binding some or all
       of the ``features`` of the ``instantiated_type`` to the ``results``
       of its ``argument`` ``Expressions``.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=87>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=229>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::ConstructorExpression'

    STD: tuple[type[ConstructorExpression], ...] = ...
    """
    All subtypes of ``ConstructorExpression`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ConstructorExpression.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ConstructorExpression.STD):
            ...

    For type hints, instead use ``ConstructorExpression.Std``:

    .. code-block:: python

        def function(element: Element) -> ConstructorExpression.Std:
            ...

    Note that ``ConstructorExpression.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ConstructorExpression.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ConstructorExpression
        """Type hint for all subtypes of ``ConstructorExpression`` according to the specification"""

class OperatorExpression(InvocationExpression):
    """
    Implementation of ``OperatorExpression`` defined in the KerML
    specification.

    **Specification**:

       An ``OperatorExpression`` is an ``InvocationExpression`` whose
       ``function`` is determined by resolving its ``operator`` in the
       context of one of the standard packages from the Kernel Function
       Library.

    For language description, see section
    `7.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=83>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.17 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=244>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::OperatorExpression'

    STD: tuple[type[OperatorExpression], ...] = ...
    """
    All subtypes of ``OperatorExpression`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``OperatorExpression.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, OperatorExpression.STD):
            ...

    For type hints, instead use ``OperatorExpression.Std``:

    .. code-block:: python

        def function(element: Element) -> OperatorExpression.Std:
            ...

    Note that ``OperatorExpression.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "OperatorExpression.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = OperatorExpression
        """Type hint for all subtypes of ``OperatorExpression`` according to the specification"""

    @property
    def operator(self) -> Operator:
        """
        Implementation of ``operator`` defined in the KerML specification.

        **Specification**:

           An ``operator`` symbol that names a corresponding ``Function`` from
           one of the standard packages from the Kernel Function Library .

        See section
        `8.3.4.8.17 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=244>`__
        of the KerML specification for more details.
        """

    @operator.setter
    def operator(self, arg: ExplicitOperator, /) -> None: ...

    def try_set_operator(self, arg: ExplicitOperator, /) -> bool:
        """
        Alternative for ``operator`` that will return ``False`` if this expression does not allow modifying its ``operator`` rather than raising ``TypeError``.
        """

class SelectExpression(OperatorExpression):
    """
    Implementation of ``SelectExpression`` defined in the KerML
    specification.

    **Specification**:

       A ``SelectExpression`` is an ``OperatorExpression`` whose operator is
       ``"select"``, which resolves to the ``Function``
       ``ControlFunctions::select`` from the Kernel Functions Library.

    For language description, see section
    `7.4.9.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=85>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.18 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=244>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::SelectExpression'

    STD: tuple[type[SelectExpression], ...] = ...
    """
    All subtypes of ``SelectExpression`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``SelectExpression.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, SelectExpression.STD):
            ...

    For type hints, instead use ``SelectExpression.Std``:

    .. code-block:: python

        def function(element: Element) -> SelectExpression.Std:
            ...

    Note that ``SelectExpression.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "SelectExpression.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = SelectExpression
        """Type hint for all subtypes of ``SelectExpression`` according to the specification"""

class CollectExpression(OperatorExpression):
    """
    Implementation of ``CollectExpression`` defined in the KerML
    specification.

    **Specification**:

       A ``CollectExpression`` is an ``OperatorExpression`` whose
       ``operator`` is ``"collect"``, which resolves to the ``Function``
       ``ControlFunctions::collect`` from the Kernel Functions Library.

    For language description, see section
    `7.4.9.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=85>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=228>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::CollectExpression'

    STD: tuple[type[CollectExpression], ...] = ...
    """
    All subtypes of ``CollectExpression`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``CollectExpression.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, CollectExpression.STD):
            ...

    For type hints, instead use ``CollectExpression.Std``:

    .. code-block:: python

        def function(element: Element) -> CollectExpression.Std:
            ...

    Note that ``CollectExpression.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "CollectExpression.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = CollectExpression
        """Type hint for all subtypes of ``CollectExpression`` according to the specification"""

class LiteralBoolean(LiteralExpression):
    """
    Implementation of ``LiteralBoolean`` defined in the KerML specification.

    **Specification**:

       ``LiteralBoolean`` is a ``LiteralExpression`` that provides a
       ``Boolean`` value as a result. Its ``result`` ``parameter`` must have
       type ``Boolean``.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=87>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=238>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::LiteralBoolean'

    STD: tuple[type[LiteralBoolean], ...] = ...
    """
    All subtypes of ``LiteralBoolean`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``LiteralBoolean.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, LiteralBoolean.STD):
            ...

    For type hints, instead use ``LiteralBoolean.Std``:

    .. code-block:: python

        def function(element: Element) -> LiteralBoolean.Std:
            ...

    Note that ``LiteralBoolean.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "LiteralBoolean.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = LiteralBoolean
        """Type hint for all subtypes of ``LiteralBoolean`` according to the specification"""

    @property
    def value(self) -> bool:
        """
        Implementation of ``value`` defined in the KerML specification.

        **Specification**:

           The ``Boolean`` value that is the result of evaluating this
           ``LiteralBoolean``.

           The Boolean value that is the result of evaluating this Expression.

        See section
        `8.3.4.8.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=238>`__
        of the KerML specification for more details.
        """

    @value.setter
    def value(self, arg: bool, /) -> None: ...

class NullExpression(Expression):
    """
    Implementation of ``NullExpression`` defined in the KerML specification.

    **Specification**:

       A ``NullExpression`` is an ``Expression`` that results in a null
       value.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=87>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.16 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=243>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::NullExpression'

    STD: tuple[type[NullExpression], ...] = ...
    """
    All subtypes of ``NullExpression`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``NullExpression.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, NullExpression.STD):
            ...

    For type hints, instead use ``NullExpression.Std``:

    .. code-block:: python

        def function(element: Element) -> NullExpression.Std:
            ...

    Note that ``NullExpression.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "NullExpression.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = NullExpression
        """Type hint for all subtypes of ``NullExpression`` according to the specification"""

class LiteralInfinity(LiteralExpression):
    """
    Implementation of ``LiteralInfinity`` defined in the KerML
    specification.

    **Specification**:

       A ``LiteralInfinity`` is a ``LiteralExpression`` that provides the
       positive infinity value (``*``). It’s ``result`` must have the type
       ``Positive``.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=87>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=240>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::LiteralInfinity'

    STD: tuple[type[LiteralInfinity], ...] = ...
    """
    All subtypes of ``LiteralInfinity`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``LiteralInfinity.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, LiteralInfinity.STD):
            ...

    For type hints, instead use ``LiteralInfinity.Std``:

    .. code-block:: python

        def function(element: Element) -> LiteralInfinity.Std:
            ...

    Note that ``LiteralInfinity.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "LiteralInfinity.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = LiteralInfinity
        """Type hint for all subtypes of ``LiteralInfinity`` according to the specification"""

class FeatureChainExpression(OperatorExpression):
    """
    Implementation of ``FeatureChainExpression`` defined in the KerML
    specification.

    **Specification**:

       A ``FeatureChainExpression`` is an ``OperatorExpression`` whose
       operator is ``"."``, which resolves to the ``Function``
       ``ControlFunctions::'.'`` from the Kernel Functions Library. It
       evaluates to the result of chaining the ``result`` ``Feature`` of its
       single ``argument`` ``Expression`` with its ``target_feature``.

    For language description, see section
    `7.4.9.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=85>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=230>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::FeatureChainExpression'

    STD: tuple[type[FeatureChainExpression], ...] = ...
    """
    All subtypes of ``FeatureChainExpression`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``FeatureChainExpression.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, FeatureChainExpression.STD):
            ...

    For type hints, instead use ``FeatureChainExpression.Std``:

    .. code-block:: python

        def function(element: Element) -> FeatureChainExpression.Std:
            ...

    Note that ``FeatureChainExpression.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "FeatureChainExpression.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = FeatureChainExpression
        """Type hint for all subtypes of ``FeatureChainExpression`` according to the specification"""

    @property
    def target_feature(self) -> Feature | None:
        """
        Implementation of ``target_feature`` defined in the KerML specification.

        **Specification**:

           The ``Feature`` that is accessed by this ``FeatureChainExpression``,
           which is its first non-``parameter`` ``member``.

        See section
        `8.3.4.8.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=231>`__
        of the KerML specification for more details.
        """

    @property
    def target_feature_member(self) -> TargetFeatureAccessor:
        """Syside specific accessor for manipulating ``target_feature``."""

class MetadataAccessExpression(Expression):
    """
    Implementation of ``MetadataAccessExpression`` defined in the KerML
    specification.

    **Specification**:

       A ``MetadataAccessExpression`` is an ``Expression`` whose ``result``
       is a sequence of instances of ``Metaclasses`` representing all the
       ``MetadataFeature`` annotations of the ``referenced_element``. In
       addition, the sequence includes an instance of the reflective
       ``Metaclass`` corresponding to the MOF class of the
       ``referenced_element``, with values for all the abstract syntax
       properties of the ``referenced_element``.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=87>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.15 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=242>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::MetadataAccessExpression'

    STD: tuple[type[MetadataAccessExpression], ...] = ...
    """
    All subtypes of ``MetadataAccessExpression`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``MetadataAccessExpression.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, MetadataAccessExpression.STD):
            ...

    For type hints, instead use ``MetadataAccessExpression.Std``:

    .. code-block:: python

        def function(element: Element) -> MetadataAccessExpression.Std:
            ...

    Note that ``MetadataAccessExpression.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "MetadataAccessExpression.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = MetadataAccessExpression
        """Type hint for all subtypes of ``MetadataAccessExpression`` according to the specification"""

    @property
    def referenced_element(self) -> Element | None:
        """
        Implementation of ``referenced_element`` defined in the KerML
        specification.

        **Specification**:

           The ``Element`` whose metadata is being accessed.

        See section
        `8.3.4.8.15 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=242>`__
        of the KerML specification for more details.
        """

    def referenced_element_member(self) -> ElementAccessor:
        """Syside specific accessor for manipulating ``referenced_element``."""

class MetadataFeature(Feature):
    """
    Implementation of ``MetadataFeature`` defined in the KerML
    specification.

    **Specification**:

       A ``MetadataFeature`` is a ``Feature`` that is an
       ``AnnotatingElement`` used to annotate another ``Element`` with
       metadata. It is typed by a ``Metaclass``. All its ``owned_features``
       must redefine ``features`` of its ``metaclass`` and any feature
       bindings must be model-level evaluable.

    For language description, see section
    `7.4.13 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=94>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.12.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=256>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::MetadataFeature'

    STD: tuple[Union[type[MetadataFeature], type[MetadataUsage]], ...] = ...
    """
    All subtypes of ``MetadataFeature`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``MetadataFeature.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, MetadataFeature.STD):
            ...

    For type hints, instead use ``MetadataFeature.Std``:

    .. code-block:: python

        def function(element: Element) -> MetadataFeature.Std:
            ...

    Note that ``MetadataFeature.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "MetadataFeature.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[MetadataFeature, MetadataUsage]
        """Type hint for all subtypes of ``MetadataFeature`` according to the specification"""

    @property
    def annotations(self) -> ContainerView[Annotation]:
        """
        Implementation of ``annotation`` defined in the KerML specification.

        **Specification**:

           The ``Annotations`` that relate this ``AnnotatingElement`` to its
           ``annotated_elements``. This includes the
           ``owning_annotating_relationship`` (if any) followed by all the
           ``owned_annotating_relationships``.

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def annotated_elements(self) -> ContainerView[Element]:
        """
        Implementation of ``annotated_element`` defined in the KerML
        specification.

        **Specification**:

           The ``Elements`` that are annotated by this ``AnnotatingElement``. If
           ``annotation`` is not empty, these are the ``annotated_elements`` of
           the ``annotations``. If ``annotation`` is empty, then it is the
           ``owning_namespace`` of the ``AnnotatingElement``.

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def owned_annotating_relationships(self) -> ContainerView[Annotation]:
        """
        Implementation of ``owned_annotating_relationship`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``AnnotatingElement`` that are
           ``Annotations``, for which this ``AnnotatingElement`` is the
           ``annotating_element``.

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=144>`__
        of the KerML specification for more details.
        """

    @property
    def owning_annotating_relationship(self) -> Annotation | None:
        """
        Implementation of ``owning_annotating_relationship`` defined in the
        KerML specification.

        **Specification**:

           The ``owning_relationship`` of this ``AnnotatingRelationship``, if it
           is an ``Annotation``

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=144>`__
        of the KerML specification for more details.
        """

    @property
    def about(self) -> Annotations:
        """Container for owned annotations."""

    @property
    def metaclass(self) -> MetadataDefinition | Metaclass | None:
        """
        Implementation of ``metaclass`` defined in the KerML specification.

        **Specification**:

           The ``type`` of this ``MetadataFeature``, which must be a
           ``Metaclass``.

        See section
        `8.3.4.12.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=257>`__
        of the KerML specification for more details.
        """

class Metaclass(Structure):
    """
    Implementation of ``Metaclass`` defined in the KerML specification.

    **Specification**:

       A ``Metaclass`` is a ``Structure`` used to type ``MetadataFeatures``.

    For language description, see section
    `7.4.13 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=94>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.12.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=256>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Metaclass'

    STD: tuple[Union[type[Metaclass], type[MetadataDefinition]], ...] = ...
    """
    All subtypes of ``Metaclass`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Metaclass.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Metaclass.STD):
            ...

    For type hints, instead use ``Metaclass.Std``:

    .. code-block:: python

        def function(element: Element) -> Metaclass.Std:
            ...

    Note that ``Metaclass.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Metaclass.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[Metaclass, MetadataDefinition]
        """Type hint for all subtypes of ``Metaclass`` according to the specification"""

class ParameterMembership(FeatureMembership):
    """
    Implementation of ``ParameterMembership`` defined in the KerML
    specification.

    **Specification**:

       A ``ParameterMembership`` is a ``FeatureMembership`` that identifies
       its ``member_feature`` as a parameter, which is always owned, and
       must have a ``direction``. A ``ParameterMembership`` must be owned by
       a ``Behavior``, a ``Step``, or the ``result`` parameter of a
       ``ConstructorExpression``.

    For language description, see section
    `7.4.7.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=78>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=219>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::ParameterMembership'

    STD: tuple[type[ParameterMembership], ...] = ...
    """
    All subtypes of ``ParameterMembership`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ParameterMembership.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ParameterMembership.STD):
            ...

    For type hints, instead use ``ParameterMembership.Std``:

    .. code-block:: python

        def function(element: Element) -> ParameterMembership.Std:
            ...

    Note that ``ParameterMembership.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ParameterMembership.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ParameterMembership
        """Type hint for all subtypes of ``ParameterMembership`` according to the specification"""

    @property
    def owned_member_parameter(self) -> Feature | None:
        """
        Implementation of ``owned_member_parameter`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that is identified as a ``parameter`` by this
           ``ParameterMembership``.

        See section
        `8.3.4.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=219>`__
        of the KerML specification for more details.
        """

    def parameter_direction(self) -> FeatureDirectionKind:
        """
        Return the required value of the direction of the ``owned_member_parameter``. By default, this is ``in``.
        """

class FeatureValue(OwningMembership):
    """
    Implementation of ``FeatureValue`` defined in the KerML specification.

    **Specification**:

       A ``FeatureValue`` is a ``Membership`` that identifies a particular
       member ``Expression`` that provides the value of the ``Feature`` that
       owns the ``FeatureValue``. The value is specified as either a bound
       value or an initial value, and as either a concrete or default value.
       A ``Feature`` can have at most one ``FeatureValue``.

       The result of the ``value`` ``Expression`` is bound to the
       ``feature_with_value`` using a ``BindingConnector``. If
       ``is_initial = false``, then the ``featuring_type`` of the
       ``BindingConnector`` is the same as the ``featuring_type`` of the
       ``feature_with_value``. If ``is_initial = true``, then the
       ``featuring_type`` of the ``BindingConnector`` is restricted to its
       ``start_shot``.

       If ``is_default = false``, then the above semantics of the
       ``FeatureValue`` are realized for the given ``feature_with_value``.
       Otherwise, the semantics are realized for any individual of the
       ``featuring_type`` of the ``feature_with_value``, unless another
       value is explicitly given for the ``feature_with_value`` for that
       individual.

    For language description, see section
    `7.4.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=92>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.10.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=251>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::FeatureValue'

    STD: tuple[type[FeatureValue], ...] = ...
    """
    All subtypes of ``FeatureValue`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``FeatureValue.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, FeatureValue.STD):
            ...

    For type hints, instead use ``FeatureValue.Std``:

    .. code-block:: python

        def function(element: Element) -> FeatureValue.Std:
            ...

    Note that ``FeatureValue.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "FeatureValue.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = FeatureValue
        """Type hint for all subtypes of ``FeatureValue`` according to the specification"""

    @property
    def is_initial(self) -> bool:
        """
        Implementation of ``is_initial`` defined in the KerML specification.

        **Specification**:

           Whether this ``FeatureValue`` specifies a bound value or an initial
           value for the ``feature_with_value``.

        See section
        `8.3.4.10.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=251>`__
        of the KerML specification for more details.
        """

    @is_initial.setter
    def is_initial(self, arg: bool, /) -> None: ...

    @property
    def is_default(self) -> bool:
        """
        Implementation of ``is_default`` defined in the KerML specification.

        **Specification**:

           Whether this ``FeatureValue`` is a concrete specification of the
           bound or initial value of the ``feature_with_value``, or just a
           default value that may be overridden.

        See section
        `8.3.4.10.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=251>`__
        of the KerML specification for more details.
        """

    @is_default.setter
    def is_default(self, arg: bool, /) -> None: ...

    @property
    def feature_with_value(self) -> Feature | None:
        """
        Implementation of ``feature_with_value`` defined in the KerML
        specification.

        **Specification**:

           The Feature to be provided a value.

           The ``Feature`` to be provided a value.

        See section
        `8.3.4.10.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=251>`__
        of the KerML specification for more details.
        """

    @property
    def value(self) -> Expression | None:
        """
        Implementation of ``value`` defined in the KerML specification.

        **Specification**:

           The Expression that provides the value as a result.

           The ``Expression`` that provides the value of the
           ``feature_with_value`` as its ``result``.

        See section
        `8.3.4.10.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=251>`__
        of the KerML specification for more details.
        """

class Association(Classifier):
    """
    Implementation of ``Association`` defined in the KerML specification.

    **Specification**:

       An ``Association`` is a ``Relationship`` and a ``Classifier`` to
       enable classification of links between things (in the universe). The
       co-domains (``types``) of the ``association_end`` ``Features`` are
       the ``related_types``, as co-domain and participants (linked things)
       of an ``Association`` identify each other.

    For language description, see section
    `7.4.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=68>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=207>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Association'

    STD: tuple[Union[type[Association], type[ConnectionDefinition], type[FlowDefinition]], ...] = ...
    """
    All subtypes of ``Association`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Association.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Association.STD):
            ...

    For type hints, instead use ``Association.Std``:

    .. code-block:: python

        def function(element: Element) -> Association.Std:
            ...

    Note that ``Association.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Association.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[Association, ConnectionDefinition, FlowDefinition]
        """Type hint for all subtypes of ``Association`` according to the specification"""

    @property
    def source(self) -> Feature | None:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def sources(self) -> list[Feature]:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def owning_related_element(self) -> None:
        """
        Implementation of ``owning_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_element of this Relationship that owns the Relationship,
           if any.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def is_implied(self) -> bool:
        """
        Implementation of ``is_implied`` defined in the KerML specification.

        **Specification**:

           Whether this Relationship was generated by tooling to meet semantic
           rules, rather than being directly created by a modeler.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @is_implied.setter
    def is_implied(self, arg: bool, /) -> None: ...

    @property
    def related_elements(self) -> LazyIterator[Feature]:
        """
        Implementation of ``related_element`` defined in the KerML
        specification.

        **Specification**:

           The Elements that are related by this Relationship, derived as the
           union of the ``source`` and ``target`` Elements of the Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def targets(self) -> LazyIterator[Feature]:
        """
        Implementation of ``target`` defined in the KerML specification.

        **Specification**:

           The ``related_elements`` to which this Relationship is considered to
           be directed.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def owned_related_elements(self) -> LazyIterator[Feature]:
        """
        Implementation of ``owned_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_elements of this Relationship that are owned by the
           Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def source_type(self) -> Type | None:
        """
        Implementation of ``source_type`` defined in the KerML specification.

        **Specification**:

           The source ``related_type`` for this ``Association``. It is the first
           ``related_type`` of the ``Association``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=208>`__
        of the KerML specification for more details.
        """

    @property
    def related_types(self) -> LazyIterator[Type]:
        """
        Implementation of ``related_type`` defined in the KerML specification.

        **Specification**:

           The ``types`` of the ``association_ends`` of the ``Association``,
           which are the ``related_elements`` of the ``Association`` considered
           as a ``Relationship``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=208>`__
        of the KerML specification for more details.
        """

    @property
    def target_types(self) -> LazyIterator[Type]:
        """
        Implementation of ``target_type`` defined in the KerML specification.

        **Specification**:

           The target ``related_types`` for this ``Association``. This includes
           all the ``related_types`` other than the ``source_type``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=208>`__
        of the KerML specification for more details.
        """

    @property
    def association_ends(self) -> LazyIterator[Feature]:
        """
        Implementation of ``association_end`` defined in the KerML
        specification.

        **Specification**:

           The ``features`` of the ``Association`` that identify the things that
           can be related by it. A concrete ``Association`` must have at least
           two ``association_ends``. When it has exactly two, the
           ``Association`` is called a *binary* ``Association``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=208>`__
        of the KerML specification for more details.
        """

class AssociationStructure(Association):
    """
    Implementation of ``AssociationStructure`` defined in the KerML
    specification.

    **Specification**:

       An ``AssociationStructure`` is an ``Association`` that is also a
       ``Structure``, classifying link objects that are both links and
       objects. As objects, link objects can be created and destroyed, and
       their non-end ``Features`` can change over time. However, the values
       of the end ``Features`` of a link object are fixed and cannot change
       over its lifetime.

    For language description, see section
    `7.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=71>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.4.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=209>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::AssociationStructure'

    STD: tuple[Union[type[AssociationStructure], type[ConnectionDefinition]], ...] = ...
    """
    All subtypes of ``AssociationStructure`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``AssociationStructure.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, AssociationStructure.STD):
            ...

    For type hints, instead use ``AssociationStructure.Std``:

    .. code-block:: python

        def function(element: Element) -> AssociationStructure.Std:
            ...

    Note that ``AssociationStructure.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "AssociationStructure.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[AssociationStructure, ConnectionDefinition]
        """Type hint for all subtypes of ``AssociationStructure`` according to the specification"""

class BooleanExpression(Expression):
    """
    Implementation of ``BooleanExpression`` defined in the KerML
    specification.

    **Specification**:

       A ``BooleanExpression`` is a ``Boolean``-valued ``Expression`` whose
       type is a ``Predicate``. It represents a logical condition resulting
       from the evaluation of the ``Predicate``.

    For language description, see section
    `7.4.8.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=82>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.7.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=221>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::BooleanExpression'

    STD: tuple[Union[type[BooleanExpression], type[ConstraintUsage]], ...] = ...
    """
    All subtypes of ``BooleanExpression`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``BooleanExpression.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, BooleanExpression.STD):
            ...

    For type hints, instead use ``BooleanExpression.Std``:

    .. code-block:: python

        def function(element: Element) -> BooleanExpression.Std:
            ...

    Note that ``BooleanExpression.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "BooleanExpression.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[BooleanExpression, ConstraintUsage]
        """Type hint for all subtypes of ``BooleanExpression`` according to the specification"""

    @property
    def predicate(self) -> Predicate | ConstraintDefinition | None:
        """
        Implementation of ``predicate`` defined in the KerML specification.

        **Specification**:

           The Predicate that types the Expression.

           The ``Predicate`` that types this ``BooleanExpression``.

        See section
        `8.3.4.7.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=221>`__
        of the KerML specification for more details.
        """

class Predicate(Function):
    """
    Implementation of ``Predicate`` defined in the KerML specification.

    **Specification**:

       A ``Predicate`` is a ``Function`` whose ``result`` ``parameter`` has
       type ``Boolean`` and multiplicity ``1..1``.

    For language description, see section
    `7.4.8.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=82>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.7.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=226>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Predicate'

    STD: tuple[Union[type[Predicate], type[ConstraintDefinition]], ...] = ...
    """
    All subtypes of ``Predicate`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Predicate.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Predicate.STD):
            ...

    For type hints, instead use ``Predicate.Std``:

    .. code-block:: python

        def function(element: Element) -> Predicate.Std:
            ...

    Note that ``Predicate.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Predicate.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[Predicate, ConstraintDefinition]
        """Type hint for all subtypes of ``Predicate`` according to the specification"""

class ResultExpressionMembership(FeatureMembership):
    """
    Implementation of ``ResultExpressionMembership`` defined in the KerML
    specification.

    **Specification**:

       A ``ResultExpressionMembership`` is a ``FeatureMembership`` that
       indicates that the ``owned_result_expression`` provides the result
       values for the ``Function`` or ``Expression`` that owns it. The
       owning ``Function`` or ``Expression`` must contain a
       ``BindingConnector`` between the ``result`` ``parameter`` of the
       ``owned_result_expression`` and the ``result`` ``parameter`` of the
       owning ``Function`` or ``Expression``.

    For language description, see section
    `7.4.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=79>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.7.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=226>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::ResultExpressionMembership'

    STD: tuple[type[ResultExpressionMembership], ...] = ...
    """
    All subtypes of ``ResultExpressionMembership`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ResultExpressionMembership.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ResultExpressionMembership.STD):
            ...

    For type hints, instead use ``ResultExpressionMembership.Std``:

    .. code-block:: python

        def function(element: Element) -> ResultExpressionMembership.Std:
            ...

    Note that ``ResultExpressionMembership.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ResultExpressionMembership.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ResultExpressionMembership
        """Type hint for all subtypes of ``ResultExpressionMembership`` according to the specification"""

    @property
    def owned_result_expression(self) -> Expression | None:
        """
        Implementation of ``owned_result_expression`` defined in the KerML
        specification.

        **Specification**:

           The ``Expression`` that provides the result for the owner of the
           ``ResultExpressionMembership``.

        See section
        `8.3.4.7.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=227>`__
        of the KerML specification for more details.
        """

class Invariant(BooleanExpression):
    """
    Implementation of ``Invariant`` defined in the KerML specification.

    **Specification**:

       An ``Invariant`` is a ``BooleanExpression`` that is asserted to have
       a specific ``Boolean`` result value. If ``is_negated = false``, then
       the result is asserted to be true. If ``is_negated = true``, then the
       result is asserted to be false.

    For language description, see section
    `7.4.8.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=82>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.7.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=225>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Invariant'

    STD: tuple[Union[type[Invariant], type[AssertConstraintUsage], type[SatisfyRequirementUsage]], ...] = ...
    """
    All subtypes of ``Invariant`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Invariant.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Invariant.STD):
            ...

    For type hints, instead use ``Invariant.Std``:

    .. code-block:: python

        def function(element: Element) -> Invariant.Std:
            ...

    Note that ``Invariant.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Invariant.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[Invariant, AssertConstraintUsage, SatisfyRequirementUsage]
        """Type hint for all subtypes of ``Invariant`` according to the specification"""

    @property
    def is_negated(self) -> bool:
        """
        Implementation of ``is_negated`` defined in the KerML specification.

        **Specification**:

           Whether this ``Invariant`` is asserted to be false rather than true.

        See section
        `8.3.4.7.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=225>`__
        of the KerML specification for more details.
        """

    @is_negated.setter
    def is_negated(self, arg: bool, /) -> None: ...

class ReturnParameterMembership(ParameterMembership):
    """
    Implementation of ``ReturnParameterMembership`` defined in the KerML
    specification.

    **Specification**:

       A ``ReturnParameterMembership`` is a ``ParameterMembership`` that
       indicates that the ``owned_member_parameter`` is the ``result``
       ``parameter`` of a ``Function`` or ``Expression``. The ``direction``
       of the ``owned_member_parameter`` must be ``out``.

    For language description, see section
    `7.4.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=79>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.7.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=227>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::ReturnParameterMembership'

    STD: tuple[type[ReturnParameterMembership], ...] = ...
    """
    All subtypes of ``ReturnParameterMembership`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ReturnParameterMembership.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ReturnParameterMembership.STD):
            ...

    For type hints, instead use ``ReturnParameterMembership.Std``:

    .. code-block:: python

        def function(element: Element) -> ReturnParameterMembership.Std:
            ...

    Note that ``ReturnParameterMembership.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ReturnParameterMembership.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ReturnParameterMembership
        """Type hint for all subtypes of ``ReturnParameterMembership`` according to the specification"""

class Connector(Feature):
    """
    Implementation of ``Connector`` defined in the KerML specification.

    **Specification**:

       A ``Connector`` is a usage of ``Associations``, with links restricted
       according to instances of the ``Type`` in which they are used (domain
       of the ``Connector``). The ``associations`` of the ``Connector``
       restrict what kinds of things might be linked. The ``Connector``
       further restricts these links to be between values of ``Features`` on
       instances of its domain.

    For language description, see section
    `7.4.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=72>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=212>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Connector'

    STD: tuple[Union[type[Connector], type[ConnectorAsUsage]], ...] = ...
    """
    All subtypes of ``Connector`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Connector.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Connector.STD):
            ...

    For type hints, instead use ``Connector.Std``:

    .. code-block:: python

        def function(element: Element) -> Connector.Std:
            ...

    Note that ``Connector.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Connector.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[Connector, ConnectorAsUsage]
        """Type hint for all subtypes of ``Connector`` according to the specification"""

    @property
    def declared_ends(self) -> ConnectorEnds:
        """
        Ends that are explicitly declared using textual syntax shorthand before the children block.
        """

    @property
    def related_features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``related_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Features`` that are related by this ``Connector`` considered as
           a ``Relationship`` and that restrict the links it identifies, given
           by the referenced ``Features`` of the ``connector_ends`` of the
           ``Connector``.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=212>`__
        of the KerML specification for more details.
        """

    @property
    def associations(self) -> LazyIterator[ConnectionDefinition | Association]:
        """
        Implementation of ``association`` defined in the KerML specification.

        **Specification**:

           The ``Associations`` that type the ``Connector``.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=212>`__
        of the KerML specification for more details.
        """

    @property
    def connector_ends(self) -> LazyIterator[Feature]:
        """
        Implementation of ``connector_end`` defined in the KerML specification.

        **Specification**:

           The ``end_features`` of a ``Connector``, which redefine the
           ``end_features`` of the ``associations`` of the ``Connector``. The
           ``connector_ends`` determine via ``ReferenceSubsetting``
           ``Relationships`` which ``Features`` are related by the
           ``Connector``.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=212>`__
        of the KerML specification for more details.
        """

    @property
    def source_feature(self) -> Feature | None:
        """
        Implementation of ``source_feature`` defined in the KerML specification.

        **Specification**:

           The source ``related_feature`` for this ``Connector``. It is the
           first ``related_feature``.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=213>`__
        of the KerML specification for more details.
        """

    @property
    def target_features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``target_feature`` defined in the KerML specification.

        **Specification**:

           The target ``related_features`` for this ``Connector``. This includes
           all the ``related_features`` other than the ``source_feature``.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=213>`__
        of the KerML specification for more details.
        """

    @property
    def is_implied(self) -> bool:
        """
        Implementation of ``is_implied`` defined in the KerML specification.

        **Specification**:

           Whether this Relationship was generated by tooling to meet semantic
           rules, rather than being directly created by a modeler.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @is_implied.setter
    def is_implied(self, arg: bool, /) -> None: ...

    @property
    def related_elements(self) -> LazyIterator[Feature]:
        """
        Implementation of ``related_element`` defined in the KerML
        specification.

        **Specification**:

           The Elements that are related by this Relationship, derived as the
           union of the ``source`` and ``target`` Elements of the Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def targets(self) -> LazyIterator[Feature]:
        """
        Implementation of ``target`` defined in the KerML specification.

        **Specification**:

           The ``related_elements`` to which this Relationship is considered to
           be directed.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def source(self) -> Feature | None:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def sources(self) -> list[Feature]:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def owning_related_element(self) -> None:
        """
        Implementation of ``owning_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_element of this Relationship that owns the Relationship,
           if any.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def default_featuring_type(self) -> Type | None:
        """
        Implementation of ``default_featuring_type`` defined in the KerML
        specification.

        **Specification**:

           The innermost ``Type`` that is a common direct or indirect
           ``featuring_type`` of the ``related_features``, such that, if it
           exists and was the ``featuring_type`` of this ``Connector``, the
           ``Connector`` would satisfy the ``check_connector_type_featuring``
           constraint.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=212>`__
        of the KerML specification for more details.
        """

    @property
    def owned_related_elements(self) -> LazyIterator[Feature]:
        """
        Implementation of ``owned_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_elements of this Relationship that are owned by the
           Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

class Flow(Connector):
    """
    Implementation of ``Flow`` defined in the KerML specification.

    **Specification**:

       An ``Flow`` is a ``Step`` that represents the transfer of values from
       one ``Feature`` to another. ``Flows`` can take non-zero time to
       complete.

    For language description, see section
    `7.4.10.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=90>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=246>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Flow'

    STD: tuple[Union[type[Flow], type[FlowUsage]], ...] = ...
    """
    All subtypes of ``Flow`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Flow.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Flow.STD):
            ...

    For type hints, instead use ``Flow.Std``:

    .. code-block:: python

        def function(element: Element) -> Flow.Std:
            ...

    Note that ``Flow.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Flow.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[Flow, FlowUsage]
        """Type hint for all subtypes of ``Flow`` according to the specification"""

    @property
    def behaviors(self) -> LazyIterator[Behavior | ActionDefinition]:
        """
        Implementation of ``behavior`` defined in the KerML specification.

        **Specification**:

           The ``Behaviors`` that type this ``Step``.

        See section
        `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=218>`__
        of the KerML specification for more details.
        """

    @property
    def owned_parameters(self) -> LazyIterator[Feature]:
        """The ``parameters`` owned by this ``Step``."""

    @property
    def parameters(self) -> LazyIterator[Feature]:
        """
        Implementation of ``parameter`` defined in the KerML specification.

        **Specification**:

           The ``parameters`` of this ``Step``, which are defined as its
           ``directed_features``, whose values are passed into and/or out of a
           performance of the ``Step``.

        See section
        `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=218>`__
        of the KerML specification for more details.
        """

    @property
    def payload_types(self) -> LazyIterator[Classifier]:
        """
        Implementation of ``payload_type`` defined in the KerML specification.

        **Specification**:

           The type of values transferred, which is the ``type`` of the
           ``payload_feature`` of the ``Flow``.

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=247>`__
        of the KerML specification for more details.
        """

    @property
    def target_input_feature(self) -> Feature | None:
        """
        Implementation of ``target_input_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that receives the values carried by the ``Flow``. It
           must be a ``feature`` of the ``target`` of the ``Flow``.

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=247>`__
        of the KerML specification for more details.
        """

    @property
    def source_output_feature(self) -> Feature | None:
        """
        Implementation of ``source_output_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that provides the items carried by the ``Flow``. It
           must be a ``feature`` of the ``source`` of the ``Flow``.

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=247>`__
        of the KerML specification for more details.
        """

    @property
    def flow_ends(self) -> LazyIterator[FlowEnd]:
        """
        Implementation of ``flow_end`` defined in the KerML specification.

        **Specification**:

           The ``connector_ends`` of this ``Flow`` that are ``FlowEnds``.

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=246>`__
        of the KerML specification for more details.
        """

    @property
    def payload_feature(self) -> PayloadFeature | None:
        """
        Implementation of ``payload_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_feature`` of the ``Flow`` that is a ``PayloadFeature``
           (if any).

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=247>`__
        of the KerML specification for more details.
        """

    @property
    def payload_feature_member(self) -> PayloadFeatureAccessor:
        """Syside specific accessor for manipulating ``payload_feature``."""

    @property
    def interactions(self) -> LazyIterator[FlowDefinition | Interaction]:
        """
        Implementation of ``interaction`` defined in the KerML specification.

        **Specification**:

           The ``Interactions`` that type this ``Flow``. ``Interactions`` are
           both ``Associations`` and ``Behaviors``, which can type
           ``Connectors`` and ``Steps``, respectively.

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=246>`__
        of the KerML specification for more details.
        """

class FlowEnd(Feature):
    """
    Implementation of ``FlowEnd`` defined in the KerML specification.

    **Specification**:

       A ``FlowEnd`` is a ``Feature`` that is one of the ``connector_ends``
       giving the ``source`` or ``target`` of a ``Flow``. For ``Flows``
       typed by ``FlowTransfer`` or its specializations, ``FlowEnds`` must
       have exactly one ``owned_feature``, which redefines
       ``Transfer::source::source_output`` or
       ``Transfer::target::target_input`` and redefines the corresponding
       feature of the ``related_element`` for its end.

    For language description, see section
    `7.4.10.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=90>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.9.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=248>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::FlowEnd'

    STD: tuple[type[FlowEnd], ...] = ...
    """
    All subtypes of ``FlowEnd`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``FlowEnd.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, FlowEnd.STD):
            ...

    For type hints, instead use ``FlowEnd.Std``:

    .. code-block:: python

        def function(element: Element) -> FlowEnd.Std:
            ...

    Note that ``FlowEnd.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "FlowEnd.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = FlowEnd
        """Type hint for all subtypes of ``FlowEnd`` according to the specification"""

class PayloadFeature(Feature):
    """
    Implementation of ``PayloadFeature`` defined in the KerML specification.

    **Specification**:

       A ``PayloadFeature`` is the ``owned_feature`` of a ``Flow`` that
       identifies the things carried by the kinds of transfers that are
       instances of the ``Flow``.

    For language description, see section
    `7.4.10.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=90>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.9.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=249>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::PayloadFeature'

    STD: tuple[type[PayloadFeature], ...] = ...
    """
    All subtypes of ``PayloadFeature`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``PayloadFeature.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, PayloadFeature.STD):
            ...

    For type hints, instead use ``PayloadFeature.Std``:

    .. code-block:: python

        def function(element: Element) -> PayloadFeature.Std:
            ...

    Note that ``PayloadFeature.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "PayloadFeature.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = PayloadFeature
        """Type hint for all subtypes of ``PayloadFeature`` according to the specification"""

class Interaction(Association):
    """
    Implementation of ``Interaction`` defined in the KerML specification.

    **Specification**:

       An ``Interaction`` is a ``Behavior`` that is also an ``Association``,
       providing a context for multiple objects that have behaviors that
       impact one another.

    For language description, see section
    `7.4.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=90>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=249>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Interaction'

    STD: tuple[Union[type[Interaction], type[FlowDefinition]], ...] = ...
    """
    All subtypes of ``Interaction`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Interaction.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Interaction.STD):
            ...

    For type hints, instead use ``Interaction.Std``:

    .. code-block:: python

        def function(element: Element) -> Interaction.Std:
            ...

    Note that ``Interaction.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Interaction.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[Interaction, FlowDefinition]
        """Type hint for all subtypes of ``Interaction`` according to the specification"""

    @property
    def steps(self) -> LazyIterator[Step | ActionUsage | FlowUsage]:
        """
        Implementation of ``step`` defined in the KerML specification.

        **Specification**:

           The ``Steps`` that make up this ``Behavior``.

        See section
        `8.3.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=217>`__
        of the KerML specification for more details.
        """

    @property
    def parameters(self) -> LazyIterator[Feature]:
        """
        Implementation of ``parameter`` defined in the KerML specification.

        **Specification**:

           The parameters of this ``Behavior``, which are defined as its
           ``directed_features``, whose values are passed into and/or out of a
           performance of the ``Behavior``.

        See section
        `8.3.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=217>`__
        of the KerML specification for more details.
        """

class SuccessionFlow(Flow):
    """
    Implementation of ``SuccessionFlow`` defined in the KerML specification.

    **Specification**:

       A ``SuccessionFlow`` is a ``Flow`` that also provides temporal
       ordering. It classifies ``Transfers`` that cannot start until the
       source ``Occurrence`` has completed and that must complete before the
       target ``Occurrence`` can start.

    For language description, see section
    `7.4.10.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=90>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.9.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=250>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::SuccessionFlow'

    STD: tuple[Union[type[SuccessionFlow], type[SuccessionFlowUsage]], ...] = ...
    """
    All subtypes of ``SuccessionFlow`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``SuccessionFlow.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, SuccessionFlow.STD):
            ...

    For type hints, instead use ``SuccessionFlow.Std``:

    .. code-block:: python

        def function(element: Element) -> SuccessionFlow.Std:
            ...

    Note that ``SuccessionFlow.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "SuccessionFlow.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[SuccessionFlow, SuccessionFlowUsage]
        """Type hint for all subtypes of ``SuccessionFlow`` according to the specification"""

    @property
    def transition_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        A ``Step`` that is typed by the ``Behavior``
        ``TransitionPerformances::TransitionPerformance`` (from the Kernel
        Semantic Library) that has this ``Succession`` as its
        ``transition_link``.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def trigger_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        ``Steps`` that map incoming events to the timing of occurrences of the
        ``transition_step``. The values of ``trigger_step`` subset the list of
        acceptable events to be received by a ``Behavior`` or the object that
        performs it.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def trigger_steps(self) -> list[Step | ActionUsage | ConstraintUsage | Flow | FlowUsage]:
        """
        ``Steps`` that map incoming events to the timing of occurrences of the
        ``transition_step``. The values of ``trigger_step`` subset the list of
        acceptable events to be received by a ``Behavior`` or the object that
        performs it.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def effect_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        ``Steps`` that represent occurrences that are side effects of the
        ``transition_step`` occurring.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def effect_steps(self) -> list[Step | ActionUsage | ConstraintUsage | Flow | FlowUsage]:
        """
        ``Steps`` that represent occurrences that are side effects of the
        ``transition_step`` occurring.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def guard_expression(self) -> list[Expression]:
        """
        ``Expressions`` that must evaluate to true before the
        ``transition_step`` can occur.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

class Succession(Connector):
    """
    Implementation of ``Succession`` defined in the KerML specification.

    **Specification**:

       A ``Succession`` is a binary ``Connector`` that requires its
       ``related_features`` to happen separately in time.

    For language description, see section
    `7.4.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=77>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.5.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=215>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Succession'

    STD: tuple[Union[type[Succession], type[SuccessionAsUsage], type[SuccessionFlow], type[SuccessionFlowUsage]], ...] = ...
    """
    All subtypes of ``Succession`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Succession.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Succession.STD):
            ...

    For type hints, instead use ``Succession.Std``:

    .. code-block:: python

        def function(element: Element) -> Succession.Std:
            ...

    Note that ``Succession.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Succession.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[Succession, SuccessionAsUsage, SuccessionFlow, SuccessionFlowUsage]
        """Type hint for all subtypes of ``Succession`` according to the specification"""

    @property
    def transition_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        A ``Step`` that is typed by the ``Behavior``
        ``TransitionPerformances::TransitionPerformance`` (from the Kernel
        Semantic Library) that has this ``Succession`` as its
        ``transition_link``.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def trigger_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        ``Steps`` that map incoming events to the timing of occurrences of the
        ``transition_step``. The values of ``trigger_step`` subset the list of
        acceptable events to be received by a ``Behavior`` or the object that
        performs it.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def trigger_steps(self) -> list[Step | ActionUsage | ConstraintUsage | Flow | FlowUsage]:
        """
        ``Steps`` that map incoming events to the timing of occurrences of the
        ``transition_step``. The values of ``trigger_step`` subset the list of
        acceptable events to be received by a ``Behavior`` or the object that
        performs it.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def effect_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        ``Steps`` that represent occurrences that are side effects of the
        ``transition_step`` occurring.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def effect_steps(self) -> list[Step | ActionUsage | ConstraintUsage | Flow | FlowUsage]:
        """
        ``Steps`` that represent occurrences that are side effects of the
        ``transition_step`` occurring.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def guard_expression(self) -> list[Expression]:
        """
        ``Expressions`` that must evaluate to true before the
        ``transition_step`` can occur.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

class BindingConnector(Connector):
    """
    Implementation of ``BindingConnector`` defined in the KerML
    specification.

    **Specification**:

       A ``BindingConnector`` is a binary ``Connector`` that requires its
       ``related_features`` to identify the same things (have the same
       values).

    For language description, see section
    `7.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=76>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.5.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=211>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::BindingConnector'

    STD: tuple[Union[type[BindingConnector], type[BindingConnectorAsUsage]], ...] = ...
    """
    All subtypes of ``BindingConnector`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``BindingConnector.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, BindingConnector.STD):
            ...

    For type hints, instead use ``BindingConnector.Std``:

    .. code-block:: python

        def function(element: Element) -> BindingConnector.Std:
            ...

    Note that ``BindingConnector.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "BindingConnector.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[BindingConnector, BindingConnectorAsUsage]
        """Type hint for all subtypes of ``BindingConnector`` according to the specification"""

class MultiplicityRange(Multiplicity):
    """
    Implementation of ``MultiplicityRange`` defined in the KerML
    specification.

    **Specification**:

       A ``MultiplicityRange`` is a ``Multiplicity`` whose value is defined
       to be the (inclusive) range of natural numbers given by the result of
       a ``lower_bound`` ``Expression`` and the result of an ``upper_bound``
       ``Expression``. The result of these ``Expressions`` shall be of type
       ``Natural``. If the result of the ``upper_bound`` ``Expression`` is
       the unbounded value ``*``, then the specified range includes all
       natural numbers greater than or equal to the ``lower_bound`` value.
       If no ``lower_bound`` ``Expression``, then the default is that the
       lower bound has the same value as the upper bound, except if the
       ``upper_bound`` evaluates to ``*``, in which case the default for the
       lower bound is 0.

    For language description, see section
    `7.4.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=93>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.11.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=253>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::MultiplicityRange'

    STD: tuple[type[MultiplicityRange], ...] = ...
    """
    All subtypes of ``MultiplicityRange`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``MultiplicityRange.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, MultiplicityRange.STD):
            ...

    For type hints, instead use ``MultiplicityRange.Std``:

    .. code-block:: python

        def function(element: Element) -> MultiplicityRange.Std:
            ...

    Note that ``MultiplicityRange.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "MultiplicityRange.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = MultiplicityRange
        """Type hint for all subtypes of ``MultiplicityRange`` according to the specification"""

    @property
    def lower_bound(self) -> Expression | None:
        """
        Implementation of ``lower_bound`` defined in the KerML specification.

        **Specification**:

           The ``Expression`` whose result provides the lower bound of the
           ``MultiplicityRange``. If no ``lower_bound`` ``Expression`` is given,
           then the lower bound shall have the same value as the upper bound,
           unless the upper bound is unbounded (``*``), in which case the lower
           bound shall be 0.

        See section
        `8.3.4.11.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=253>`__
        of the KerML specification for more details.
        """

    @property
    def upper_bound(self) -> Expression | None:
        """
        Implementation of ``upper_bound`` defined in the KerML specification.

        **Specification**:

           The ``Expression`` whose result is the upper bound of the
           ``MultiplicityRange``.

        See section
        `8.3.4.11.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=253>`__
        of the KerML specification for more details.
        """

    @property
    def bounds(self) -> list[Expression | None]:
        """
        Implementation of ``bound`` defined in the KerML specification.

        **Specification**:

           The owned ``Expressions`` of the ``MultiplicityRange`` whose results
           provide its bounds. These must be the first ``owned_members`` of the
           ``MultiplicityRange``.

        See section
        `8.3.4.11.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=253>`__
        of the KerML specification for more details.
        """

    @property
    def bounds_expression(self) -> Expression | None:
        """The ``Expression`` of the bounds range."""

    @property
    def bounds_expression_member(self) -> OwnedExpressionAccessor:
        """Syside specific accessor for manipulating ``bounds_expression``."""

    @property
    def has_cached_bounds(self) -> bool:
        """Returns ``True`` if sema succeeded in computing bounds."""

    @property
    def cached_lower_bound(self) -> int:
        """The numerically evaluated lower bound if any."""

    @property
    def cached_upper_bound(self) -> int | None:
        """
        The numerically evaluated upper bound if any. Returns ``None`` if the upper bound is infinity.
        """

class Usage(Feature):
    """
    Implementation of ``Usage`` defined in the SysML specification.

    **Specification**:

       A ``Usage`` is a usage of a ``Definition``.

       A ``Usage`` may have ``nested_usages`` that model ``features`` that
       apply in the context of the ``owning_usage``. A ``Usage`` may also
       have ``Definitions`` nested in it, but this has no semantic
       significance, other than the nested scoping resulting from the
       ``Usage`` being considered as a ``Namespace`` for any nested
       ``Definitions``.

       However, if a ``Usage`` has ``is_variation = true``, then it
       represents a *variation point* ``Usage``. In this case, all of its
       ``members`` must be ``variant`` ``Usages``, related to the ``Usage``
       by ``VariantMembership`` ``Relationships``. Rather than being
       ``features`` of the ``Usage``, ``variant`` ``Usages`` model different
       concrete alternatives that can be chosen to fill in for the variation
       point ``Usage``.

    For language description, see section
    `7.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=63>`__
    of the SysML specification. For more details on the model, see section
    `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=301>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::Usage'

    STD: tuple[type[Usage], ...] = ...
    """
    All subtypes of ``Usage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Usage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Usage.STD):
            ...

    For type hints, instead use ``Usage.Std``:

    .. code-block:: python

        def function(element: Element) -> Usage.Std:
            ...

    Note that ``Usage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Usage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Usage
        """Type hint for all subtypes of ``Usage`` according to the specification"""

    @property
    def is_reference(self) -> bool:
        """
        Implementation of ``is_reference`` defined in the SysML specification.

        **Specification**:

           Whether this ``Usage`` is a referential ``Usage``, that is, it has
           ``is_composite = false``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=301>`__
        of the SysML specification for more details.
        """

    @is_reference.setter
    def is_reference(self, arg: bool, /) -> None: ...

    @property
    def is_reference_explicitly(self) -> bool:
        """
        Returns ``True`` if this ``Usage`` was explicitly declared as ``ref`` in the textual syntax.
        """

    @property
    def is_variation(self) -> bool:
        """
        Implementation of ``is_variation`` defined in the SysML specification.

        **Specification**:

           Whether this ``Usage`` is for a variation point or not. If true, then
           all the ``memberships`` of the ``Usage`` must be
           ``VariantMemberships``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=301>`__
        of the SysML specification for more details.
        """

    @is_variation.setter
    def is_variation(self, arg: bool, /) -> None: ...

    @property
    def may_time_vary(self) -> bool:
        """
        Implementation of ``may_time_vary`` defined in the SysML specification.

        **Specification**:

           Whether this ``Usage`` may be time varying (that is, whether it is
           featured by the snapshots of its ``owning_type``, rather than being
           featured by the ``owning_type`` itself). However, if ``is_constant``
           is also true, then the value of the ``Usage`` is nevertheless
           constant over the entire duration of an instance of its
           ``owning_type`` (that is, it has the same value on all snapshots).

           The property ``may_time_vary`` redefines the KerML property
           ``Feature::is_variable``, making it derived. The property
           ``is_constant`` is inherited from ``Feature``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=301>`__
        of the SysML specification for more details.
        """

    @property
    def variants(self) -> LazyIterator[Usage]:
        """
        Implementation of ``variant`` defined in the SysML specification.

        **Specification**:

           The ``Usages`` which represent the variants of this ``Usage`` as a
           variation point ``Usage``, if ``is_variation = true``. If
           ``is_variation = false``, then there must be no ``variants``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=304>`__
        of the SysML specification for more details.
        """

    @property
    def variant_memberships(self) -> LazyIterator[VariantMembership]:
        r"""
        Implementation of ``variant_membership`` defined in the SysML
        specification.

        **Specification**:

           The ``owned_memberships`` of this ``Usage`` that are
           ``VariantMemberships``. If ``is_variation = true``, then this must be
           all ``memberships`` of the ``Usage``. If ``is_variation = false``,
           then ``variant_membership``\ must be empty.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=304>`__
        of the SysML specification for more details.
        """

    @property
    def owning_definition(self) -> Definition | None:
        """
        Implementation of ``owning_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``Definition`` that owns this ``Usage`` (if any).

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
        of the SysML specification for more details.
        """

    @property
    def owning_usage(self) -> Usage | None:
        """
        Implementation of ``owning_usage`` defined in the SysML specification.

        **Specification**:

           The ``Usage`` in which this ``Usage`` is nested (if any).

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
        of the SysML specification for more details.
        """

    @property
    def nested_usages(self) -> LazyIterator[Usage]:
        """
        Implementation of ``nested_usage`` defined in the SysML specification.

        **Specification**:

           The ``Usages`` that are ``owned_features`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
        of the SysML specification for more details.
        """

    @property
    def definitions(self) -> LazyIterator[Classifier]:
        """
        Implementation of ``definition`` defined in the SysML specification.

        **Specification**:

           The ``Classifiers`` that are the types of this ``Usage``. Nominally,
           these are ``Definitions``, but other kinds of Kernel ``Classifiers``
           are also allowed, to permit use of ``Classifiers`` from the Kernel
           Model Libraries.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=301>`__
        of the SysML specification for more details.
        """

    @property
    def usages(self) -> LazyIterator[Usage]:
        """
        Implementation of ``usage`` defined in the SysML specification.

        **Specification**:

           The ``Usages`` that are ``features`` of this ``Usage`` (not
           necessarily owned).

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=304>`__
        of the SysML specification for more details.
        """

    @property
    def directed_usages(self) -> LazyIterator[Usage]:
        """
        Implementation of ``directed_usage`` defined in the SysML specification.

        **Specification**:

           The ``usages`` of this ``Usage`` that are ``directed_features``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=301>`__
        of the SysML specification for more details.
        """

    @property
    def nested_references(self) -> LazyIterator[ReferenceUsage]:
        """
        Implementation of ``nested_reference`` defined in the SysML
        specification.

        **Specification**:

           The ``ReferenceUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
        of the SysML specification for more details.
        """

    @property
    def nested_attributes(self) -> LazyIterator[AttributeUsage]:
        """
        Implementation of ``nested_attribute`` defined in the SysML
        specification.

        **Specification**:

           The code>AttributeUsages that are ``nested_usages`` of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=302>`__
        of the SysML specification for more details.
        """

    @property
    def nested_enumerations(self) -> LazyIterator[EnumerationUsage]:
        """
        Implementation of ``nested_enumeration`` defined in the SysML
        specification.

        **Specification**:

           The code>EnumerationUsages that are ``nested_usages`` of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=302>`__
        of the SysML specification for more details.
        """

    @property
    def nested_occurrences(self) -> LazyIterator[OccurrenceUsage]:
        """
        Implementation of ``nested_occurrence`` defined in the SysML
        specification.

        **Specification**:

           The ``OccurrenceUsages`` that are ``nested_usages`` of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=302>`__
        of the SysML specification for more details.
        """

    @property
    def nested_items(self) -> LazyIterator[ItemUsage]:
        """
        Implementation of ``nested_item`` defined in the SysML specification.

        **Specification**:

           The ``ItemUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=302>`__
        of the SysML specification for more details.
        """

    @property
    def nested_parts(self) -> LazyIterator[PartUsage | ConnectionUsage]:
        """
        Implementation of ``nested_part`` defined in the SysML specification.

        **Specification**:

           The ``PartUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
        of the SysML specification for more details.
        """

    @property
    def nested_ports(self) -> LazyIterator[PortUsage]:
        """
        Implementation of ``nested_port`` defined in the SysML specification.

        **Specification**:

           The ``PortUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
        of the SysML specification for more details.
        """

    @property
    def nested_connections(self) -> LazyIterator[ConnectorAsUsage]:
        """
        Implementation of ``nested_connection`` defined in the SysML
        specification.

        **Specification**:

           The ``ConnectorAsUsages`` that are ``nested_usages`` of this
           ``Usage``. Note that this list includes ``BindingConnectorAsUsages``,
           ``SuccessionAsUsages``, and ``FlowConnectionUsages`` because these
           are ``ConnectorAsUsages`` even though they are not
           ``ConnectionUsages``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=302>`__
        of the SysML specification for more details.
        """

    @property
    def nested_flows(self) -> LazyIterator[FlowUsage]:
        """
        Implementation of ``nested_flow`` defined in the SysML specification.

        **Specification**:

           The code>FlowUsages that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=302>`__
        of the SysML specification for more details.
        """

    @property
    def nested_interfaces(self) -> LazyIterator[InterfaceUsage]:
        """
        Implementation of ``nested_interface`` defined in the SysML
        specification.

        **Specification**:

           The ``InterfaceUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=302>`__
        of the SysML specification for more details.
        """

    @property
    def nested_allocations(self) -> LazyIterator[AllocationUsage]:
        """
        Implementation of ``nested_allocation`` defined in the SysML
        specification.

        **Specification**:

           The ``AllocationUsages`` that are ``nested_usages`` of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=301>`__
        of the SysML specification for more details.
        """

    @property
    def nested_actions(self) -> LazyIterator[ActionUsage | FlowUsage]:
        """
        Implementation of ``nested_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=301>`__
        of the SysML specification for more details.
        """

    @property
    def nested_states(self) -> LazyIterator[StateUsage]:
        """
        Implementation of ``nested_state`` defined in the SysML specification.

        **Specification**:

           The ``StateUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
        of the SysML specification for more details.
        """

    @property
    def nested_transitions(self) -> LazyIterator[TransitionUsage]:
        """
        Implementation of ``nested_transition`` defined in the SysML
        specification.

        **Specification**:

           The ``TransitionUsages`` that are ``nested_usages`` of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
        of the SysML specification for more details.
        """

    @property
    def nested_calculations(self) -> LazyIterator[CalculationUsage]:
        """
        Implementation of ``nested_calculation`` defined in the SysML
        specification.

        **Specification**:

           The ``CalculationUsage`` that are ``nested_usages`` of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=302>`__
        of the SysML specification for more details.
        """

    @property
    def nested_constraints(self) -> LazyIterator[ConstraintUsage]:
        """
        Implementation of ``nested_constraint`` defined in the SysML
        specification.

        **Specification**:

           The ``ConstraintUsages`` that are ``nested_usages`` of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=302>`__
        of the SysML specification for more details.
        """

    @property
    def nested_requirements(self) -> LazyIterator[RequirementUsage]:
        """
        Implementation of ``nested_requirement`` defined in the SysML
        specification.

        **Specification**:

           The ``RequirementUsages`` that are ``nested_usages`` of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
        of the SysML specification for more details.
        """

    @property
    def nested_concerns(self) -> LazyIterator[ConcernUsage]:
        """
        Implementation of ``nested_concern`` defined in the SysML specification.

        **Specification**:

           The ``ConcernUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=302>`__
        of the SysML specification for more details.
        """

    @property
    def nested_cases(self) -> LazyIterator[CaseUsage]:
        """
        Implementation of ``nested_case`` defined in the SysML specification.

        **Specification**:

           The ``CaseUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=302>`__
        of the SysML specification for more details.
        """

    @property
    def nested_analysis_cases(self) -> LazyIterator[AnalysisCaseUsage]:
        """
        Implementation of ``nested_analysis_case`` defined in the SysML
        specification.

        **Specification**:

           The ``AnalysisCaseUsages`` that are ``nested_usages`` of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=302>`__
        of the SysML specification for more details.
        """

    @property
    def nested_verification_cases(self) -> LazyIterator[VerificationCaseUsage]:
        """
        Implementation of ``nested_verification_case`` defined in the SysML
        specification.

        **Specification**:

           The ``VerificationCaseUsages`` that are ``nested_usages`` of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
        of the SysML specification for more details.
        """

    @property
    def nested_use_cases(self) -> LazyIterator[UseCaseUsage]:
        """
        Implementation of ``nested_use_case`` defined in the SysML
        specification.

        **Specification**:

           The ``UseCaseUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
        of the SysML specification for more details.
        """

    @property
    def nested_views(self) -> LazyIterator[ViewUsage]:
        """
        Implementation of ``nested_view`` defined in the SysML specification.

        **Specification**:

           The ``ViewUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
        of the SysML specification for more details.
        """

    @property
    def nested_viewpoints(self) -> LazyIterator[ViewpointUsage]:
        """
        Implementation of ``nested_viewpoint`` defined in the SysML
        specification.

        **Specification**:

           The ``ViewpointUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
        of the SysML specification for more details.
        """

    @property
    def nested_renderings(self) -> LazyIterator[RenderingUsage]:
        """
        Implementation of ``nested_rendering`` defined in the SysML
        specification.

        **Specification**:

           The ``RenderingUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
        of the SysML specification for more details.
        """

    @property
    def nested_metadata(self) -> LazyIterator[MetadataUsage]:
        """
        Implementation of ``nested_metadata`` defined in the SysML
        specification.

        **Specification**:

           The ``MetadataUsages`` that are ``nested_usages`` of this of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=302>`__
        of the SysML specification for more details.
        """

class ConnectorAsUsage(Usage):
    """
    Implementation of ``ConnectorAsUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``ConnectorAsUsage`` is both a ``Connector`` and a ``Usage``.
       ``ConnectorAsUsage`` cannot itself be instantiated in a SysML model,
       but it is a base class for the concrete classes
       ``BindingConnectorAsUsage``, ``SuccessionAsUsage``,
       ``ConnectionUsage`` and ``FlowConnectionUsage``.

    For language description, see section
    `7.13.1 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=95>`__
    of the SysML specification. For more details on the model, see section
    `8.3.13.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=331>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ConnectorAsUsage'

    STD: tuple[type[ConnectorAsUsage], ...] = ...
    """
    All subtypes of ``ConnectorAsUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ConnectorAsUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ConnectorAsUsage.STD):
            ...

    For type hints, instead use ``ConnectorAsUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> ConnectorAsUsage.Std:
            ...

    Note that ``ConnectorAsUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ConnectorAsUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ConnectorAsUsage
        """Type hint for all subtypes of ``ConnectorAsUsage`` according to the specification"""

    @property
    def is_message_connection(self) -> bool:
        """
        Ends that are explicitly declared using textual syntax shorthand before the children block.
        """

    @property
    def declared_ends(self) -> ConnectorAsUsageEnds:
        """
        Ends that are explicitly declared using textual syntax shorthand before the children block.
        """

    @property
    def related_features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``related_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Features`` that are related by this ``Connector`` considered as
           a ``Relationship`` and that restrict the links it identifies, given
           by the referenced ``Features`` of the ``connector_ends`` of the
           ``Connector``.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=212>`__
        of the KerML specification for more details.
        """

    @property
    def associations(self) -> LazyIterator[ConnectionDefinition | Association]:
        """
        Implementation of ``association`` defined in the KerML specification.

        **Specification**:

           The ``Associations`` that type the ``Connector``.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=212>`__
        of the KerML specification for more details.
        """

    @property
    def connector_ends(self) -> LazyIterator[Feature]:
        """
        Implementation of ``connector_end`` defined in the KerML specification.

        **Specification**:

           The ``end_features`` of a ``Connector``, which redefine the
           ``end_features`` of the ``associations`` of the ``Connector``. The
           ``connector_ends`` determine via ``ReferenceSubsetting``
           ``Relationships`` which ``Features`` are related by the
           ``Connector``.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=212>`__
        of the KerML specification for more details.
        """

    @property
    def source_feature(self) -> Feature | None:
        """
        Implementation of ``source_feature`` defined in the KerML specification.

        **Specification**:

           The source ``related_feature`` for this ``Connector``. It is the
           first ``related_feature``.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=213>`__
        of the KerML specification for more details.
        """

    @property
    def target_features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``target_feature`` defined in the KerML specification.

        **Specification**:

           The target ``related_features`` for this ``Connector``. This includes
           all the ``related_features`` other than the ``source_feature``.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=213>`__
        of the KerML specification for more details.
        """

    @property
    def is_implied(self) -> bool:
        """
        Implementation of ``is_implied`` defined in the KerML specification.

        **Specification**:

           Whether this Relationship was generated by tooling to meet semantic
           rules, rather than being directly created by a modeler.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @is_implied.setter
    def is_implied(self, arg: bool, /) -> None: ...

    @property
    def related_elements(self) -> LazyIterator[Feature]:
        """
        Implementation of ``related_element`` defined in the KerML
        specification.

        **Specification**:

           The Elements that are related by this Relationship, derived as the
           union of the ``source`` and ``target`` Elements of the Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def targets(self) -> LazyIterator[Feature]:
        """
        Implementation of ``target`` defined in the KerML specification.

        **Specification**:

           The ``related_elements`` to which this Relationship is considered to
           be directed.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def source(self) -> Feature | None:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def sources(self) -> list[Feature]:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def owning_related_element(self) -> None:
        """
        Implementation of ``owning_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_element of this Relationship that owns the Relationship,
           if any.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def default_featuring_type(self) -> Type | None:
        """
        Implementation of ``default_featuring_type`` defined in the KerML
        specification.

        **Specification**:

           The innermost ``Type`` that is a common direct or indirect
           ``featuring_type`` of the ``related_features``, such that, if it
           exists and was the ``featuring_type`` of this ``Connector``, the
           ``Connector`` would satisfy the ``check_connector_type_featuring``
           constraint.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=212>`__
        of the KerML specification for more details.
        """

    @property
    def owned_related_elements(self) -> LazyIterator[Feature]:
        """
        Implementation of ``owned_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_elements of this Relationship that are owned by the
           Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

class ConnectionUsage(ConnectorAsUsage):
    """
    Implementation of ``ConnectionUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``ConnectionUsage`` is a ``ConnectorAsUsage`` that is also a
       ``PartUsage``. Nominally, if its type is a ``ConnectionDefinition``,
       then a ``ConnectionUsage`` is a Usage of that
       ``ConnectionDefinition``, representing a connection between parts of
       a system. However, other kinds of kernel ``AssociationStructures``
       are also allowed, to permit use of ``AssociationStructures`` from the
       Kernel Model Libraries.

    For language description, see section
    `7.13.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=100>`__
    of the SysML specification. For more details on the model, see section
    `8.3.13.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=330>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ConnectionUsage'

    STD: tuple[type[ConnectionUsage], ...] = ...
    """
    All subtypes of ``ConnectionUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ConnectionUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ConnectionUsage.STD):
            ...

    For type hints, instead use ``ConnectionUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> ConnectionUsage.Std:
            ...

    Note that ``ConnectionUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ConnectionUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ConnectionUsage
        """Type hint for all subtypes of ``ConnectionUsage`` according to the specification"""

    @property
    def connection_definitions(self) -> LazyIterator[ConnectionDefinition | AssociationStructure]:
        """
        Implementation of ``connection_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``AssociationStructures`` that are the types of this
           ``ConnectionUsage``. Nominally, these are , but other kinds of Kernel
           ``AssociationStructures`` are also allowed, to permit use of
           ``AssociationStructures`` from the Kernel Model Libraries

        See section
        `8.3.13.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=330>`__
        of the SysML specification for more details.
        """

    @property
    def item_definitions(self) -> LazyIterator[Structure | AssociationStructure | ConnectionDefinition | ItemDefinition | PortDefinition]:
        """
        Implementation of ``item_definition`` defined in the SysML
        specification.

        **Specification**:

           The Structures that are the ``definitions`` of this ItemUsage.
           Nominally, these are ItemDefinitions, but other kinds of Kernel
           Structures are also allowed, to permit use of Structures from the
           Kernel Library.

        See section
        `8.3.10.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=320>`__
        of the SysML specification for more details.
        """

    @property
    def part_definitions(self) -> LazyIterator[PartDefinition]:
        """
        Implementation of ``part_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``item_definitions`` of this PartUsage that are PartDefinitions.

        See section
        `8.3.11.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=322>`__
        of the SysML specification for more details.
        """

    @property
    def is_individual(self) -> bool:
        """
        Implementation of ``is_individual`` defined in the SysML specification.

        **Specification**:

           Whether this ``OccurrenceUsage`` represents the usage of the specific
           individual represented by its ``individual_definition``.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=316>`__
        of the SysML specification for more details.
        """

    @is_individual.setter
    def is_individual(self, arg: bool, /) -> None: ...

    @property
    def portion_kind(self) -> PortionKind | None:
        """
        Implementation of ``portion_kind`` defined in the SysML specification.

        **Specification**:

           The kind of temporal portion (time slice or snapshot) is represented
           by this ``OccurrenceUsage``. If ``portion_kind`` is not null, then
           the ``owning_type`` of the ``OccurrenceUsage`` must be non-null, and
           the ``OccurrenceUsage`` represents portions of the featuring instance
           of the ``owning_type``.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=316>`__
        of the SysML specification for more details.
        """

    @portion_kind.setter
    def portion_kind(self, arg: PortionKind | None) -> None: ...

    @property
    def occurrence_definitions(self) -> LazyIterator[OccurrenceDefinition]:
        """
        Implementation of ``occurrence_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``Classes`` that are the types of this ``OccurrenceUsage``.
           Nominally, these are ``OccurrenceDefinitions``, but other kinds of
           kernel ``Classes`` are also allowed, to permit use of ``Classes``
           from the Kernel Model Libraries.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=316>`__
        of the SysML specification for more details.
        """

    @property
    def individual_definition(self) -> OccurrenceDefinition | None:
        """
        Implementation of ``individual_definition`` defined in the SysML
        specification.

        **Specification**:

           The at most one ``occurrence_definition`` that has
           ``is_individual = true``.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=316>`__
        of the SysML specification for more details.
        """

class InterfaceUsage(ConnectionUsage):
    """
    Implementation of ``InterfaceUsage`` defined in the SysML specification.

    **Specification**:

       An ``InterfaceUsage`` is a Usage of an ``InterfaceDefinition`` to
       represent an interface connecting parts of a system through specific
       ports.

    For language description, see section
    `7.14.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=109>`__
    of the SysML specification. For more details on the model, see section
    `8.3.14.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=333>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::InterfaceUsage'

    STD: tuple[type[InterfaceUsage], ...] = ...
    """
    All subtypes of ``InterfaceUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``InterfaceUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, InterfaceUsage.STD):
            ...

    For type hints, instead use ``InterfaceUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> InterfaceUsage.Std:
            ...

    Note that ``InterfaceUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "InterfaceUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = InterfaceUsage
        """Type hint for all subtypes of ``InterfaceUsage`` according to the specification"""

    @property
    def interface_definitions(self) -> LazyIterator[InterfaceDefinition]:
        """
        Implementation of ``interface_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``InterfaceDefinitions`` that type this ``InterfaceUsage``.

        See section
        `8.3.14.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=333>`__
        of the SysML specification for more details.
        """

class VariantMembership(OwningMembership):
    """
    Implementation of ``VariantMembership`` defined in the SysML
    specification.

    **Specification**:

       A ``VariantMembership`` is a ``Membership`` between a variation point
       ``Definition`` or ``Usage`` and a ``Usage`` that represents a variant
       in the context of that variation. The ``membership_owning_namespace``
       for the ``VariantMembership`` must be either a Definition or a
       ``Usage`` with ``is_variation = true``.

    For language description, see section
    `7.6.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=75>`__
    of the SysML specification. For more details on the model, see section
    `8.3.6.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=309>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::VariantMembership'

    STD: tuple[type[VariantMembership], ...] = ...
    """
    All subtypes of ``VariantMembership`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``VariantMembership.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, VariantMembership.STD):
            ...

    For type hints, instead use ``VariantMembership.Std``:

    .. code-block:: python

        def function(element: Element) -> VariantMembership.Std:
            ...

    Note that ``VariantMembership.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "VariantMembership.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = VariantMembership
        """Type hint for all subtypes of ``VariantMembership`` according to the specification"""

    @property
    def owned_variant_usage(self) -> Usage | None:
        """
        Implementation of ``owned_variant_usage`` defined in the SysML
        specification.

        **Specification**:

           The ``Usage`` that represents a variant in the context of the
           ``owning_variation_definition`` or ``owning_variation_usage``.

        See section
        `8.3.6.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=309>`__
        of the SysML specification for more details.
        """

class Definition(Classifier):
    """
    Implementation of ``Definition`` defined in the SysML specification.

    **Specification**:

       A ``Definition`` is a ``Classifier`` of ``Usages``. The actual kinds
       of ``Definition`` that may appear in a model are given by the
       subclasses of ``Definition`` (possibly as extended with user-defined
       ``SemanticMetadata``).

       Normally, a ``Definition`` has owned Usages that model ``features``
       of the thing being defined. A ``Definition`` may also have other
       ``Definitions`` nested in it, but this has no semantic significance,
       other than the nested scoping resulting from the ``Definition`` being
       considered as a ``Namespace`` for any nested ``Definitions``.

       However, if a ``Definition`` has ``is_variation`` = ``true``, then it
       represents a *variation point* ``Definition``. In this case, all of
       its ``members`` must be ``variant`` ``Usages``, related to the
       ``Definition`` by ``VariantMembership`` ``Relationships``. Rather
       than being ``features`` of the ``Definition``, ``variant`` ``Usages``
       model different concrete alternatives that can be chosen to fill in
       for an abstract ``Usage`` of the variation point ``Definition``.

    For language description, see section
    `7.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=63>`__
    of the SysML specification. For more details on the model, see section
    `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=293>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::Definition'

    STD: tuple[type[Definition], ...] = ...
    """
    All subtypes of ``Definition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Definition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Definition.STD):
            ...

    For type hints, instead use ``Definition.Std``:

    .. code-block:: python

        def function(element: Element) -> Definition.Std:
            ...

    Note that ``Definition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Definition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Definition
        """Type hint for all subtypes of ``Definition`` according to the specification"""

    @property
    def is_variation(self) -> bool:
        """
        Implementation of ``is_variation`` defined in the SysML specification.

        **Specification**:

           Whether this ``Definition`` is for a variation point or not. If true,
           then all the ``memberships`` of the ``Definition`` must be
           ``VariantMemberships``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=294>`__
        of the SysML specification for more details.


        The setter will throw ``TypeError`` on types that are implicitly variations already, e.g. ``EnumerationDefinition``.
        Use ``try_set_is_variation`` instead for a non-throwing behaviour.
        """

    @is_variation.setter
    def is_variation(self, arg: bool, /) -> None: ...

    def try_set_is_variation(self, arg: bool, /) -> bool:
        """
        Try setting ``is_variation``. For types that are implicitly variations, this will return ``False`` instead of throwing ``TypeError`` when using ``is_variation`` setter.
        """

    @property
    def variants(self) -> LazyIterator[Usage]:
        """
        Implementation of ``variant`` defined in the SysML specification.

        **Specification**:

           The ``Usages`` which represent the variants of this ``Definition`` as
           a variation point ``Definition``, if ``is_variation`` = true. If
           ``is_variation = false``, the there must be no ``variants``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=296>`__
        of the SysML specification for more details.
        """

    @property
    def variant_memberships(self) -> LazyIterator[VariantMembership]:
        r"""
        Implementation of ``variant_membership`` defined in the SysML
        specification.

        **Specification**:

           The ``owned_memberships`` of this ``Definition`` that are
           ``VariantMemberships``. If ``is_variation`` = true, then this must be
           all ``owned_memberships`` of the ``Definition``. If ``is_variation``
           = false, then ``variant_membership``\ must be empty.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=296>`__
        of the SysML specification for more details.
        """

    @property
    def usages(self) -> LazyIterator[Usage]:
        """
        Implementation of ``usage`` defined in the SysML specification.

        **Specification**:

           The ``Usages`` that are ``features`` of this ``Definition`` (not
           necessarily owned).

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=296>`__
        of the SysML specification for more details.
        """

    @property
    def directed_usages(self) -> LazyIterator[Usage]:
        """
        Implementation of ``directed_usage`` defined in the SysML specification.

        **Specification**:

           The ``usages`` of this ``Definition`` that are ``directed_features``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=294>`__
        of the SysML specification for more details.
        """

    @property
    def owned_usages(self) -> LazyIterator[Usage]:
        """
        Implementation of ``owned_usage`` defined in the SysML specification.

        **Specification**:

           The ``Usages`` that are ``owned_features`` of this ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=296>`__
        of the SysML specification for more details.
        """

    @property
    def owned_references(self) -> LazyIterator[ReferenceUsage]:
        """
        Implementation of ``owned_reference`` defined in the SysML
        specification.

        **Specification**:

           The ``ReferenceUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=295>`__
        of the SysML specification for more details.
        """

    @property
    def owned_attributes(self) -> LazyIterator[AttributeUsage]:
        """
        Implementation of ``owned_attribute`` defined in the SysML
        specification.

        **Specification**:

           The ``AttributeUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=294>`__
        of the SysML specification for more details.
        """

    @property
    def owned_enumerations(self) -> LazyIterator[EnumerationUsage]:
        """
        Implementation of ``owned_enumeration`` defined in the SysML
        specification.

        **Specification**:

           The ``EnumerationUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=295>`__
        of the SysML specification for more details.
        """

    @property
    def owned_occurrences(self) -> LazyIterator[OccurrenceUsage]:
        """
        Implementation of ``owned_occurrence`` defined in the SysML
        specification.

        **Specification**:

           The ``OccurrenceUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=295>`__
        of the SysML specification for more details.
        """

    @property
    def owned_items(self) -> LazyIterator[ItemUsage]:
        """
        Implementation of ``owned_item`` defined in the SysML specification.

        **Specification**:

           The ``ItemUsages`` that are ``owned_usages`` of this ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=295>`__
        of the SysML specification for more details.
        """

    @property
    def owned_parts(self) -> LazyIterator[PartUsage | ConnectionUsage]:
        """
        Implementation of ``owned_part`` defined in the SysML specification.

        **Specification**:

           The ``PartUsages`` that are ``owned_usages`` of this ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=295>`__
        of the SysML specification for more details.
        """

    @property
    def owned_ports(self) -> LazyIterator[PortUsage]:
        """
        Implementation of ``owned_port`` defined in the SysML specification.

        **Specification**:

           The ``PortUsages`` that are ``owned_usages`` of this ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=295>`__
        of the SysML specification for more details.
        """

    @property
    def owned_connections(self) -> LazyIterator[ConnectorAsUsage]:
        """
        Implementation of ``owned_connection`` defined in the SysML
        specification.

        **Specification**:

           The ``ConnectorAsUsages`` that are ``owned_usages`` of this
           ``Definition``. Note that this list includes
           ``BindingConnectorAsUsages``, ``SuccessionAsUsages``, and
           ``FlowUsages`` because these are ``ConnectorAsUsages`` even though
           they are not ``ConnectionUsages``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=294>`__
        of the SysML specification for more details.
        """

    @property
    def owned_flows(self) -> LazyIterator[FlowUsage]:
        """
        Implementation of ``owned_flow`` defined in the SysML specification.

        **Specification**:

           The ``FlowUsages`` that are ``owned_usages`` of this ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=295>`__
        of the SysML specification for more details.
        """

    @property
    def owned_interfaces(self) -> LazyIterator[InterfaceUsage]:
        """
        Implementation of ``owned_interface`` defined in the SysML
        specification.

        **Specification**:

           The ``InterfaceUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=295>`__
        of the SysML specification for more details.
        """

    @property
    def owned_allocations(self) -> LazyIterator[AllocationUsage]:
        """
        Implementation of ``owned_allocation`` defined in the SysML
        specification.

        **Specification**:

           The ``AllocationUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=294>`__
        of the SysML specification for more details.
        """

    @property
    def owned_actions(self) -> LazyIterator[ActionUsage | FlowUsage]:
        """
        Implementation of ``owned_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=294>`__
        of the SysML specification for more details.
        """

    @property
    def owned_states(self) -> LazyIterator[StateUsage]:
        """
        Implementation of ``owned_state`` defined in the SysML specification.

        **Specification**:

           The ``StateUsages`` that are ``owned_usages`` of this ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=295>`__
        of the SysML specification for more details.
        """

    @property
    def owned_transitions(self) -> LazyIterator[TransitionUsage]:
        """
        Implementation of ``owned_transition`` defined in the SysML
        specification.

        **Specification**:

           The ``TransitionUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=296>`__
        of the SysML specification for more details.
        """

    @property
    def owned_calculations(self) -> LazyIterator[CalculationUsage]:
        """
        Implementation of ``owned_calculation`` defined in the SysML
        specification.

        **Specification**:

           The ``CalculationUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=294>`__
        of the SysML specification for more details.
        """

    @property
    def owned_constraints(self) -> LazyIterator[ConstraintUsage]:
        """
        Implementation of ``owned_constraint`` defined in the SysML
        specification.

        **Specification**:

           The ``ConstraintUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=295>`__
        of the SysML specification for more details.
        """

    @property
    def owned_concerns(self) -> LazyIterator[ConcernUsage]:
        """
        Implementation of ``owned_concern`` defined in the SysML specification.

        **Specification**:

           The ``ConcernUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=294>`__
        of the SysML specification for more details.
        """

    @property
    def owned_cases(self) -> LazyIterator[CaseUsage]:
        """
        Implementation of ``owned_case`` defined in the SysML specification.

        **Specification**:

           The code>CaseUsages that are ``owned_usages`` of this ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=294>`__
        of the SysML specification for more details.
        """

    @property
    def owned_verification_cases(self) -> LazyIterator[VerificationCaseUsage]:
        """
        Implementation of ``owned_verification_case`` defined in the SysML
        specification.

        **Specification**:

           The ``VerificationCaseUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=296>`__
        of the SysML specification for more details.
        """

    @property
    def owned_use_cases(self) -> LazyIterator[UseCaseUsage]:
        """
        Implementation of ``owned_use_case`` defined in the SysML specification.

        **Specification**:

           The ``UseCaseUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=296>`__
        of the SysML specification for more details.
        """

    @property
    def owned_views(self) -> LazyIterator[ViewUsage]:
        """
        Implementation of ``owned_view`` defined in the SysML specification.

        **Specification**:

           The ``ViewUsages`` that are ``owned_usages`` of this ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=296>`__
        of the SysML specification for more details.
        """

    @property
    def owned_viewpoints(self) -> LazyIterator[ViewpointUsage]:
        """
        Implementation of ``owned_viewpoint`` defined in the SysML
        specification.

        **Specification**:

           The ``ViewpointUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=296>`__
        of the SysML specification for more details.
        """

    @property
    def owned_renderings(self) -> LazyIterator[RenderingUsage]:
        """
        Implementation of ``owned_rendering`` defined in the SysML
        specification.

        **Specification**:

           The ``RenderingUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=295>`__
        of the SysML specification for more details.
        """

    @property
    def owned_metadata(self) -> LazyIterator[MetadataUsage]:
        """
        Implementation of ``owned_metadata`` defined in the SysML specification.

        **Specification**:

           The ``MetadataUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=295>`__
        of the SysML specification for more details.
        """

    @property
    def owned_analysis_cases(self) -> LazyIterator[AnalysisCaseUsage]:
        """
        Implementation of ``owned_analysis_case`` defined in the SysML
        specification.

        **Specification**:

           The ``AnalysisCaseUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=294>`__
        of the SysML specification for more details.
        """

    @property
    def owned_requirements(self) -> LazyIterator[RequirementUsage]:
        """
        Implementation of ``owned_requirement`` defined in the SysML
        specification.

        **Specification**:

           The ``RequirementUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=295>`__
        of the SysML specification for more details.
        """

class ReferenceUsage(Usage):
    """
    Implementation of ``ReferenceUsage`` defined in the SysML specification.

    **Specification**:

       A ``ReferenceUsage`` is a ``Usage`` that specifies a
       non-compositional (``is_composite = false``) reference to something.
       The ``definition`` of a ``ReferenceUsage`` can be any kind of
       ``Classifier``, with the default being the top-level ``Classifier``
       ``Base::Anything`` from the Kernel Semantic Library. This allows the
       specification of a generic reference without distinguishing if the
       thing referenced is an attribute value, item, action, etc.

    For language description, see section
    `7.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=74>`__
    of the SysML specification. For more details on the model, see section
    `8.3.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=300>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ReferenceUsage'

    STD: tuple[type[ReferenceUsage], ...] = ...
    """
    All subtypes of ``ReferenceUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ReferenceUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ReferenceUsage.STD):
            ...

    For type hints, instead use ``ReferenceUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> ReferenceUsage.Std:
            ...

    Note that ``ReferenceUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ReferenceUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ReferenceUsage
        """Type hint for all subtypes of ``ReferenceUsage`` according to the specification"""

class AttributeUsage(Usage):
    """
    Implementation of ``AttributeUsage`` defined in the SysML specification.

    **Specification**:

       An ``AttributeUsage`` is a ``Usage`` whose type is a ``DataType``.
       Nominally, if the type is an ``AttributeDefinition``, an
       ``AttributeUsage`` is a usage of a ``AttributeDefinition`` to
       represent the value of some system quality or characteristic.
       However, other kinds of kernel ``DataTypes`` are also allowed, to
       permit use of ``DataTypes`` from the Kernel Model Libraries. An
       ``AttributeUsage`` itself as well as all its nested ``features`` must
       be referential (non-composite).

       An ``AttributeUsage`` must specialize, directly or indirectly, the
       base ``Feature`` ``Base::data_values`` from the Kernel Semantic
       Library.

    For language description, see section
    `7.7.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=78>`__
    of the SysML specification. For more details on the model, see section
    `8.3.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=311>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::AttributeUsage'

    STD: tuple[type[AttributeUsage], ...] = ...
    """
    All subtypes of ``AttributeUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``AttributeUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, AttributeUsage.STD):
            ...

    For type hints, instead use ``AttributeUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> AttributeUsage.Std:
            ...

    Note that ``AttributeUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "AttributeUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = AttributeUsage
        """Type hint for all subtypes of ``AttributeUsage`` according to the specification"""

    @property
    def attribute_definitions(self) -> LazyIterator[AttributeDefinition | DataType]:
        """
        Implementation of ``attribute_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``DataTypes`` that are the types of this ``AttributeUsage``.
           Nominally, these are ``AttributeDefinitions``, but other kinds of
           kernel ``DataTypes`` are also allowed, to permit use of ``DataTypes``
           from the Kernel Model Libraries.

        See section
        `8.3.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=311>`__
        of the SysML specification for more details.
        """

class EnumerationUsage(AttributeUsage):
    """
    Implementation of ``EnumerationUsage`` defined in the SysML
    specification.

    **Specification**:

       An ``EnumerationUsage`` is an ``AttributeUsage`` whose
       ``attribute_definition`` is an ``EnumerationDefinition``.

    For language description, see section
    `7.8.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=80>`__
    of the SysML specification. For more details on the model, see section
    `8.3.8.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=313>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::EnumerationUsage'

    STD: tuple[type[EnumerationUsage], ...] = ...
    """
    All subtypes of ``EnumerationUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``EnumerationUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, EnumerationUsage.STD):
            ...

    For type hints, instead use ``EnumerationUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> EnumerationUsage.Std:
            ...

    Note that ``EnumerationUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "EnumerationUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = EnumerationUsage
        """Type hint for all subtypes of ``EnumerationUsage`` according to the specification"""

    @property
    def enumeration_definition(self) -> EnumerationDefinition | None:
        """
        Implementation of ``enumeration_definition`` defined in the SysML
        specification.

        **Specification**:

           The single EnumerationDefinition that is the type of this
           EnumerationUsage.

        See section
        `8.3.8.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=313>`__
        of the SysML specification for more details.
        """

class AttributeDefinition(Definition):
    """
    Implementation of ``AttributeDefinition`` defined in the SysML
    specification.

    **Specification**:

       An ``AttributeDefinition`` is a ``Definition`` and a ``DataType`` of
       information about a quality or characteristic of a system or part of
       a system that has no independent identity other than its value. All
       ``features`` of an ``AttributeDefinition`` must be referential
       (non-composite).

       As a ``DataType``, an ``AttributeDefinition`` must specialize,
       directly or indirectly, the base ``DataType`` ``Base::DataValue``
       from the Kernel Semantic Library.

    For language description, see section
    `7.7.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=78>`__
    of the SysML specification. For more details on the model, see section
    `8.3.7.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=310>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::AttributeDefinition'

    STD: tuple[type[AttributeDefinition], ...] = ...
    """
    All subtypes of ``AttributeDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``AttributeDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, AttributeDefinition.STD):
            ...

    For type hints, instead use ``AttributeDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> AttributeDefinition.Std:
            ...

    Note that ``AttributeDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "AttributeDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = AttributeDefinition
        """Type hint for all subtypes of ``AttributeDefinition`` according to the specification"""

class EnumerationDefinition(AttributeDefinition):
    """
    Implementation of ``EnumerationDefinition`` defined in the SysML
    specification.

    **Specification**:

       An ``EnumerationDefinition`` is an ``AttributeDefinition`` all of
       whose instances are given by an explicit list of
       ``enumerated_values``. This is realized by requiring that the
       ``EnumerationDefinition`` have ``is_variation = true``, with the
       ``enumerated_values`` being its ``variants``.

    For language description, see section
    `7.8.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=80>`__
    of the SysML specification. For more details on the model, see section
    `8.3.8.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=312>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::EnumerationDefinition'

    STD: tuple[type[EnumerationDefinition], ...] = ...
    """
    All subtypes of ``EnumerationDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``EnumerationDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, EnumerationDefinition.STD):
            ...

    For type hints, instead use ``EnumerationDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> EnumerationDefinition.Std:
            ...

    Note that ``EnumerationDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "EnumerationDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = EnumerationDefinition
        """Type hint for all subtypes of ``EnumerationDefinition`` according to the specification"""

    @property
    def enumerated_values(self) -> LazyIterator[EnumerationUsage]:
        r"""
        Implementation of ``enumerated_value`` defined in the SysML
        specification.

        **Specification**:

           ``EnumerationUsages`` of this ``EnumerationDefinition``\ that have
           distinct, fixed values. Each ``enumerated_value`` specifies one of
           the allowed instances of the ``EnumerationDefinition``.

        See section
        `8.3.8.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=312>`__
        of the SysML specification for more details.
        """

class OccurrenceUsage(Usage):
    """
    Implementation of ``OccurrenceUsage`` defined in the SysML
    specification.

    **Specification**:

       An ``OccurrenceUsage`` is a ``Usage`` whose ``types`` are all
       ``Classes``. Nominally, if a ``type`` is an ``OccurrenceDefinition``,
       an ``OccurrenceUsage`` is a ``Usage`` of that
       ``OccurrenceDefinition`` within a system. However, other types of
       Kernel ``Classes`` are also allowed, to permit use of ``Classes``
       from the Kernel Model Libraries.

    For language description, see section
    `7.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=86>`__
    of the SysML specification. For more details on the model, see section
    `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=316>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::OccurrenceUsage'

    STD: tuple[Union[type[OccurrenceUsage], type[ConnectionUsage], type[FlowUsage]], ...] = ...
    """
    All subtypes of ``OccurrenceUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``OccurrenceUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, OccurrenceUsage.STD):
            ...

    For type hints, instead use ``OccurrenceUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> OccurrenceUsage.Std:
            ...

    Note that ``OccurrenceUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "OccurrenceUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[OccurrenceUsage, ConnectionUsage, FlowUsage]
        """Type hint for all subtypes of ``OccurrenceUsage`` according to the specification"""

    @property
    def is_individual(self) -> bool:
        """
        Implementation of ``is_individual`` defined in the SysML specification.

        **Specification**:

           Whether this ``OccurrenceUsage`` represents the usage of the specific
           individual represented by its ``individual_definition``.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=316>`__
        of the SysML specification for more details.
        """

    @is_individual.setter
    def is_individual(self, arg: bool, /) -> None: ...

    @property
    def portion_kind(self) -> PortionKind | None:
        """
        Implementation of ``portion_kind`` defined in the SysML specification.

        **Specification**:

           The kind of temporal portion (time slice or snapshot) is represented
           by this ``OccurrenceUsage``. If ``portion_kind`` is not null, then
           the ``owning_type`` of the ``OccurrenceUsage`` must be non-null, and
           the ``OccurrenceUsage`` represents portions of the featuring instance
           of the ``owning_type``.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=316>`__
        of the SysML specification for more details.
        """

    @portion_kind.setter
    def portion_kind(self, arg: PortionKind | None) -> None: ...

    @property
    def occurrence_definitions(self) -> LazyIterator[OccurrenceDefinition]:
        """
        Implementation of ``occurrence_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``Classes`` that are the types of this ``OccurrenceUsage``.
           Nominally, these are ``OccurrenceDefinitions``, but other kinds of
           kernel ``Classes`` are also allowed, to permit use of ``Classes``
           from the Kernel Model Libraries.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=316>`__
        of the SysML specification for more details.
        """

    @property
    def individual_definition(self) -> OccurrenceDefinition | None:
        """
        Implementation of ``individual_definition`` defined in the SysML
        specification.

        **Specification**:

           The at most one ``occurrence_definition`` that has
           ``is_individual = true``.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=316>`__
        of the SysML specification for more details.
        """

class OccurrenceDefinition(Definition):
    """
    Implementation of ``OccurrenceDefinition`` defined in the SysML
    specification.

    **Specification**:

       An ``OccurrenceDefinition`` is a ``Definition`` of a ``Class`` of
       individuals that have an independent life over time and potentially
       an extent over space. This includes both structural things and
       behaviors that act on such structures. If ``is_individual`` is true,
       then the ``OccurrenceDefinition`` is constrained to have (at most) a
       single instance that is the entire life of a single individual.

    For language description, see section
    `7.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=86>`__
    of the SysML specification. For more details on the model, see section
    `8.3.9.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=315>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::OccurrenceDefinition'

    STD: tuple[type[OccurrenceDefinition], ...] = ...
    """
    All subtypes of ``OccurrenceDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``OccurrenceDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, OccurrenceDefinition.STD):
            ...

    For type hints, instead use ``OccurrenceDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> OccurrenceDefinition.Std:
            ...

    Note that ``OccurrenceDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "OccurrenceDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = OccurrenceDefinition
        """Type hint for all subtypes of ``OccurrenceDefinition`` according to the specification"""

    @property
    def is_individual(self) -> bool:
        """
        Implementation of ``is_individual`` defined in the SysML specification.

        **Specification**:

           Whether this ``OccurrenceDefinition`` is constrained to represent at
           most one thing.

        See section
        `8.3.9.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=315>`__
        of the SysML specification for more details.
        """

    @is_individual.setter
    def is_individual(self, arg: bool, /) -> None: ...

class ItemUsage(OccurrenceUsage):
    """
    Implementation of ``ItemUsage`` defined in the SysML specification.

    **Specification**:

       An ``ItemUsage`` is a ``ItemUsage`` whose ``definition`` is a
       ``Structure``. Nominally, if the ``definition`` is an
       ``ItemDefinition``, an ``ItemUsage`` is a ``ItemUsage`` of that
       ``ItemDefinition`` within a system. However, other kinds of Kernel
       ``Structures`` are also allowed, to permit use of ``Structures`` from
       the Kernel Model Libraries.

    For language description, see section
    `7.10.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=89>`__
    of the SysML specification. For more details on the model, see section
    `8.3.10.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=320>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ItemUsage'

    STD: tuple[Union[type[ItemUsage], type[ConnectionUsage]], ...] = ...
    """
    All subtypes of ``ItemUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ItemUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ItemUsage.STD):
            ...

    For type hints, instead use ``ItemUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> ItemUsage.Std:
            ...

    Note that ``ItemUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ItemUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[ItemUsage, ConnectionUsage]
        """Type hint for all subtypes of ``ItemUsage`` according to the specification"""

    @property
    def item_definitions(self) -> LazyIterator[Structure | AssociationStructure | ConnectionDefinition | ItemDefinition | PortDefinition]:
        """
        Implementation of ``item_definition`` defined in the SysML
        specification.

        **Specification**:

           The Structures that are the ``definitions`` of this ItemUsage.
           Nominally, these are ItemDefinitions, but other kinds of Kernel
           Structures are also allowed, to permit use of Structures from the
           Kernel Library.

        See section
        `8.3.10.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=320>`__
        of the SysML specification for more details.
        """

class PartUsage(ItemUsage):
    """
    Implementation of ``PartUsage`` defined in the SysML specification.

    **Specification**:

       A ``PartUsage`` is a usage of a ``PartDefinition`` to represent a
       system or a part of a system. At least one of the
       ``item_definitions`` of the ``PartUsage`` must be a
       ``PartDefinition``.

       A ``PartUsage`` must subset, directly or indirectly, the base
       ``PartUsage`` ``parts`` from the Systems Model Library.

    For language description, see section
    `7.11.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=92>`__
    of the SysML specification. For more details on the model, see section
    `8.3.11.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=321>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::PartUsage'

    STD: tuple[Union[type[PartUsage], type[ConnectionUsage]], ...] = ...
    """
    All subtypes of ``PartUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``PartUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, PartUsage.STD):
            ...

    For type hints, instead use ``PartUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> PartUsage.Std:
            ...

    Note that ``PartUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "PartUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[PartUsage, ConnectionUsage]
        """Type hint for all subtypes of ``PartUsage`` according to the specification"""

    @property
    def part_definitions(self) -> LazyIterator[PartDefinition]:
        """
        Implementation of ``part_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``item_definitions`` of this PartUsage that are PartDefinitions.

        See section
        `8.3.11.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=322>`__
        of the SysML specification for more details.
        """

class ItemDefinition(OccurrenceDefinition):
    """
    Implementation of ``ItemDefinition`` defined in the SysML specification.

    **Specification**:

       An ``ItemDefinition`` is an ``OccurrenceDefinition`` of the
       ``Structure`` of things that may themselves be systems or parts of
       systems, but may also be things that are acted on by a system or
       parts of a system, but which do not necessarily perform actions
       themselves. This includes items that can be exchanged between parts
       of a system, such as water or electrical signals.

    For language description, see section
    `7.10.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=89>`__
    of the SysML specification. For more details on the model, see section
    `8.3.10.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=319>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ItemDefinition'

    STD: tuple[type[ItemDefinition], ...] = ...
    """
    All subtypes of ``ItemDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ItemDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ItemDefinition.STD):
            ...

    For type hints, instead use ``ItemDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> ItemDefinition.Std:
            ...

    Note that ``ItemDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ItemDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ItemDefinition
        """Type hint for all subtypes of ``ItemDefinition`` according to the specification"""

class PartDefinition(ItemDefinition):
    """
    Implementation of ``PartDefinition`` defined in the SysML specification.

    **Specification**:

       A ``PartDefinition`` is an ``ItemDefinition`` of a ``Class`` of
       systems or parts of systems. Note that all parts may be considered
       items for certain purposes, but not all items are parts that can
       perform actions within a system.

    For language description, see section
    `7.11.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=92>`__
    of the SysML specification. For more details on the model, see section
    `8.3.11.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=321>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::PartDefinition'

    STD: tuple[type[PartDefinition], ...] = ...
    """
    All subtypes of ``PartDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``PartDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, PartDefinition.STD):
            ...

    For type hints, instead use ``PartDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> PartDefinition.Std:
            ...

    Note that ``PartDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "PartDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = PartDefinition
        """Type hint for all subtypes of ``PartDefinition`` according to the specification"""

class PortUsage(OccurrenceUsage):
    """
    Implementation of ``PortUsage`` defined in the SysML specification.

    **Specification**:

       A ``PortUsage`` is a usage of a ``PortDefinition``. A ``PortUsage``
       itself as well as all its ``nested_usages`` must be referential
       (non-composite).

    For language description, see section
    `7.12.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=95>`__
    of the SysML specification. For more details on the model, see section
    `8.3.12.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=327>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::PortUsage'

    STD: tuple[type[PortUsage], ...] = ...
    """
    All subtypes of ``PortUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``PortUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, PortUsage.STD):
            ...

    For type hints, instead use ``PortUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> PortUsage.Std:
            ...

    Note that ``PortUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "PortUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = PortUsage
        """Type hint for all subtypes of ``PortUsage`` according to the specification"""

    @property
    def port_definitions(self) -> LazyIterator[PortDefinition]:
        """
        Implementation of ``port_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``occurrence_definitions`` of this ``PortUsage``, which must all
           be ``PortDefinitions``.

        See section
        `8.3.12.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=327>`__
        of the SysML specification for more details.
        """

class PortDefinition(OccurrenceDefinition):
    """
    Implementation of ``PortDefinition`` defined in the SysML specification.

    **Specification**:

       A ``PortDefinition`` defines a point at which external entities can
       connect to and interact with a system or part of a system. Any
       ``owned_usages`` of a ``PortDefinition``, other than ``PortUsages``,
       must not be composite.

    For language description, see section
    `7.12.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=95>`__
    of the SysML specification. For more details on the model, see section
    `8.3.12.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=326>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::PortDefinition'

    STD: tuple[type[PortDefinition], ...] = ...
    """
    All subtypes of ``PortDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``PortDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, PortDefinition.STD):
            ...

    For type hints, instead use ``PortDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> PortDefinition.Std:
            ...

    Note that ``PortDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "PortDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = PortDefinition
        """Type hint for all subtypes of ``PortDefinition`` according to the specification"""

    @property
    def conjugated_port_definition(self) -> ConjugatedPortDefinition | None:
        """
        Implementation of ``conjugated_port_definition`` defined in the SysML
        specification.

        **Specification**:

           The that is conjugate to this ``PortDefinition``.

        See section
        `8.3.12.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=326>`__
        of the SysML specification for more details.
        """

class ConjugatedPortDefinition(PortDefinition):
    """
    Implementation of ``ConjugatedPortDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``ConjugatedPortDefinition`` is a ``PortDefinition`` that is a
       ``PortDefinition`` of its original ``PortDefinition``. That is, a
       ``ConjugatedPortDefinition`` inherits all the ``features`` of the
       original ``PortDefinition``, but input ``flows`` of the original
       ``PortDefinition`` become outputs on the ``ConjugatedPortDefinition``
       and output ``flows`` of the original ``PortDefinition`` become inputs
       on the ``ConjugatedPortDefinition``. Every ``PortDefinition`` (that
       is not itself a ``ConjugatedPortDefinition``) has exactly one
       corresponding ``ConjugatedPortDefinition``, whose effective name is
       the name of the ``original_port_definition``, with the character
       ``~`` prepended.

    For language description, see section
    `7.12.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=95>`__
    of the SysML specification. For more details on the model, see section
    `8.3.12.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=324>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ConjugatedPortDefinition'

    STD: tuple[type[ConjugatedPortDefinition], ...] = ...
    """
    All subtypes of ``ConjugatedPortDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ConjugatedPortDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ConjugatedPortDefinition.STD):
            ...

    For type hints, instead use ``ConjugatedPortDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> ConjugatedPortDefinition.Std:
            ...

    Note that ``ConjugatedPortDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ConjugatedPortDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ConjugatedPortDefinition
        """Type hint for all subtypes of ``ConjugatedPortDefinition`` according to the specification"""

    @property
    def owned_port_conjugator(self) -> PortConjugation | None:
        """
        Implementation of ``owned_port_conjugator`` defined in the SysML
        specification.

        **Specification**:

           The ``PortConjugation`` that is the ``owned_conjugator`` of this
           ``ConjugatedPortDefinition``, linking it to its
           ``original_port_definition``.

        See section
        `8.3.12.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=324>`__
        of the SysML specification for more details.
        """

    @property
    def original_port_definition(self) -> PortDefinition | None:
        """
        Implementation of ``original_port_definition`` defined in the SysML
        specification.

        **Specification**:

           The original ``PortDefinition`` for this
           ``ConjugatedPortDefinition``, which is the ``owning_namespace`` of
           the ``ConjugatedPortDefinition``.

        See section
        `8.3.12.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=324>`__
        of the SysML specification for more details.
        """

class PortConjugation(Conjugation):
    """
    Implementation of ``PortConjugation`` defined in the SysML
    specification.

    **Specification**:

       A ``PortConjugation`` is a ``Conjugation`` ``Relationship`` between a
       ``PortDefinition`` and its corresponding
       ``ConjugatedPortDefinition``. As a result of this ``Relationship``,
       the ``ConjugatedPortDefinition`` inherits all the ``features`` of the
       original ``PortDefinition``, but input ``flows`` of the original
       ``PortDefinition`` become outputs on the ``ConjugatedPortDefinition``
       and output ``flows`` of the original ``PortDefinition`` become inputs
       on the ``ConjugatedPortDefinition``.

    For language description, see section
    `7.12.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=95>`__
    of the SysML specification. For more details on the model, see section
    `8.3.12.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=325>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::PortConjugation'

    STD: tuple[type[PortConjugation], ...] = ...
    """
    All subtypes of ``PortConjugation`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``PortConjugation.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, PortConjugation.STD):
            ...

    For type hints, instead use ``PortConjugation.Std``:

    .. code-block:: python

        def function(element: Element) -> PortConjugation.Std:
            ...

    Note that ``PortConjugation.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "PortConjugation.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = PortConjugation
        """Type hint for all subtypes of ``PortConjugation`` according to the specification"""

    CHAINABLE: bool = False
    """
    Whether this relationship can be used with chained features.

    Using this in, e.g. ``append_chain``, will raise ``TypeError``.
    """

    @property
    def original_port_definition(self) -> PortDefinition | None:
        """
        Implementation of ``original_port_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``PortDefinition`` being conjugated.

        See section
        `8.3.12.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=325>`__
        of the SysML specification for more details.
        """

    @property
    def conjugated_port_definition(self) -> Type | None:
        """
        Implementation of ``conjugated_port_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``ConjugatedPortDefinition`` that is conjugate to the
           ``original_port_definition``.

        See section
        `8.3.12.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=325>`__
        of the SysML specification for more details.
        """

class FlowUsage(ConnectorAsUsage):
    """
    Implementation of ``FlowUsage`` defined in the SysML specification.

    **Specification**:

       A ``FlowUsage`` is an ``ActionUsage`` that is also a
       ``ConnectorAsUsage`` and a KerML ``Flow``.

    For language description, see section
    `7.16.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=115>`__
    of the SysML specification. For more details on the model, see section
    `8.3.16.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=337>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::FlowUsage'

    STD: tuple[type[FlowUsage], ...] = ...
    """
    All subtypes of ``FlowUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``FlowUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, FlowUsage.STD):
            ...

    For type hints, instead use ``FlowUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> FlowUsage.Std:
            ...

    Note that ``FlowUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "FlowUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = FlowUsage
        """Type hint for all subtypes of ``FlowUsage`` according to the specification"""

    @property
    def flow_definitions(self) -> LazyIterator[FlowDefinition | Interaction]:
        """
        Implementation of ``flow_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``Interactions`` that are the ``types`` of this ``FlowUsage``.
           Nominally, these are ``FlowDefinitions``, but other kinds of Kernel
           ``Interactions`` are also allowed, to permit use of Interactions from
           the Kernel Model Libraries.

        See section
        `8.3.16.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=337>`__
        of the SysML specification for more details.
        """

    @property
    def declared_messages(self) -> Messages:
        """
        The messages of this ``FlowUsage`` as declared before the children block in the textual syntax.
        """

    @property
    def behaviors(self) -> LazyIterator[Behavior | ActionDefinition]:
        """
        Implementation of ``behavior`` defined in the KerML specification.

        **Specification**:

           The ``Behaviors`` that type this ``Step``.

        See section
        `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=218>`__
        of the KerML specification for more details.
        """

    @property
    def owned_parameters(self) -> LazyIterator[Feature]:
        """The ``parameters`` owned by this ``Step``."""

    @property
    def parameters(self) -> LazyIterator[Feature]:
        """
        Implementation of ``parameter`` defined in the KerML specification.

        **Specification**:

           The ``parameters`` of this ``Step``, which are defined as its
           ``directed_features``, whose values are passed into and/or out of a
           performance of the ``Step``.

        See section
        `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=218>`__
        of the KerML specification for more details.
        """

    @property
    def action_definitions(self) -> LazyIterator[Behavior | ActionDefinition]:
        """
        Implementation of ``action_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``Behaviors`` that are the ``types`` of this ``ActionUsage``.
           Nominally, these would be ``ActionDefinitions``, but other kinds of
           Kernel ``Behaviors`` are also allowed, to permit use of ``Behaviors``
           from the Kernel Model Libraries.

        See section
        `8.3.17.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=344>`__
        of the SysML specification for more details.
        """

    @property
    def is_individual(self) -> bool:
        """
        Implementation of ``is_individual`` defined in the SysML specification.

        **Specification**:

           Whether this ``OccurrenceUsage`` represents the usage of the specific
           individual represented by its ``individual_definition``.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=316>`__
        of the SysML specification for more details.
        """

    @is_individual.setter
    def is_individual(self, arg: bool, /) -> None: ...

    @property
    def portion_kind(self) -> PortionKind | None:
        """
        Implementation of ``portion_kind`` defined in the SysML specification.

        **Specification**:

           The kind of temporal portion (time slice or snapshot) is represented
           by this ``OccurrenceUsage``. If ``portion_kind`` is not null, then
           the ``owning_type`` of the ``OccurrenceUsage`` must be non-null, and
           the ``OccurrenceUsage`` represents portions of the featuring instance
           of the ``owning_type``.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=316>`__
        of the SysML specification for more details.
        """

    @portion_kind.setter
    def portion_kind(self, arg: PortionKind | None) -> None: ...

    @property
    def occurrence_definitions(self) -> LazyIterator[OccurrenceDefinition]:
        """
        Implementation of ``occurrence_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``Classes`` that are the types of this ``OccurrenceUsage``.
           Nominally, these are ``OccurrenceDefinitions``, but other kinds of
           kernel ``Classes`` are also allowed, to permit use of ``Classes``
           from the Kernel Model Libraries.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=316>`__
        of the SysML specification for more details.
        """

    @property
    def individual_definition(self) -> OccurrenceDefinition | None:
        """
        Implementation of ``individual_definition`` defined in the SysML
        specification.

        **Specification**:

           The at most one ``occurrence_definition`` that has
           ``is_individual = true``.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=316>`__
        of the SysML specification for more details.
        """

    @property
    def payload_types(self) -> LazyIterator[Classifier]:
        """
        Implementation of ``payload_type`` defined in the KerML specification.

        **Specification**:

           The type of values transferred, which is the ``type`` of the
           ``payload_feature`` of the ``Flow``.

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=247>`__
        of the KerML specification for more details.
        """

    @property
    def target_input_feature(self) -> Feature | None:
        """
        Implementation of ``target_input_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that receives the values carried by the ``Flow``. It
           must be a ``feature`` of the ``target`` of the ``Flow``.

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=247>`__
        of the KerML specification for more details.
        """

    @property
    def source_output_feature(self) -> Feature | None:
        """
        Implementation of ``source_output_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that provides the items carried by the ``Flow``. It
           must be a ``feature`` of the ``source`` of the ``Flow``.

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=247>`__
        of the KerML specification for more details.
        """

    @property
    def flow_ends(self) -> LazyIterator[FlowEnd]:
        """
        Implementation of ``flow_end`` defined in the KerML specification.

        **Specification**:

           The ``connector_ends`` of this ``Flow`` that are ``FlowEnds``.

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=246>`__
        of the KerML specification for more details.
        """

    @property
    def payload_feature(self) -> PayloadFeature | None:
        """
        Implementation of ``payload_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_feature`` of the ``Flow`` that is a ``PayloadFeature``
           (if any).

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=247>`__
        of the KerML specification for more details.
        """

    @property
    def payload_feature_member(self) -> PayloadFeatureAccessor:
        """Syside specific accessor for manipulating ``payload_feature``."""

    @property
    def interactions(self) -> LazyIterator[FlowDefinition | Interaction]:
        """
        Implementation of ``interaction`` defined in the KerML specification.

        **Specification**:

           The ``Interactions`` that type this ``Flow``. ``Interactions`` are
           both ``Associations`` and ``Behaviors``, which can type
           ``Connectors`` and ``Steps``, respectively.

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=246>`__
        of the KerML specification for more details.
        """

class ActionUsage(OccurrenceUsage):
    """
    Implementation of ``ActionUsage`` defined in the SysML specification.

    **Specification**:

       An ``ActionUsage`` is a ``Usage`` that is also a ``Step``, and, so,
       is typed by a ``Behavior``. Nominally, if the type is an
       ``ActionDefinition``, an ``ActionUsage`` is a ``Usage`` of that
       ``ActionDefinition`` within a system. However, other kinds of kernel
       ``Behaviors`` are also allowed, to permit use of ``Behaviors`` from
       the Kernel Model Libraries.

    For language description, see section
    `7.17.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=131>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=344>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ActionUsage'

    STD: tuple[Union[type[ActionUsage], type[FlowUsage]], ...] = ...
    """
    All subtypes of ``ActionUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ActionUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ActionUsage.STD):
            ...

    For type hints, instead use ``ActionUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> ActionUsage.Std:
            ...

    Note that ``ActionUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ActionUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[ActionUsage, FlowUsage]
        """Type hint for all subtypes of ``ActionUsage`` according to the specification"""

    @property
    def behaviors(self) -> LazyIterator[Behavior | ActionDefinition]:
        """
        Implementation of ``behavior`` defined in the KerML specification.

        **Specification**:

           The ``Behaviors`` that type this ``Step``.

        See section
        `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=218>`__
        of the KerML specification for more details.
        """

    @property
    def owned_parameters(self) -> LazyIterator[Feature]:
        """The ``parameters`` owned by this ``Step``."""

    @property
    def parameters(self) -> LazyIterator[Feature]:
        """
        Implementation of ``parameter`` defined in the KerML specification.

        **Specification**:

           The ``parameters`` of this ``Step``, which are defined as its
           ``directed_features``, whose values are passed into and/or out of a
           performance of the ``Step``.

        See section
        `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=218>`__
        of the KerML specification for more details.
        """

    @property
    def action_definitions(self) -> LazyIterator[Behavior | ActionDefinition]:
        """
        Implementation of ``action_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``Behaviors`` that are the ``types`` of this ``ActionUsage``.
           Nominally, these would be ``ActionDefinitions``, but other kinds of
           Kernel ``Behaviors`` are also allowed, to permit use of ``Behaviors``
           from the Kernel Model Libraries.

        See section
        `8.3.17.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=344>`__
        of the SysML specification for more details.
        """

class AllocationUsage(ConnectionUsage):
    """
    Implementation of ``AllocationUsage`` defined in the SysML
    specification.

    **Specification**:

       An ``AllocationUsage`` is a usage of an ``AllocationDefinition``
       asserting the allocation of the ``source`` feature to the ``target``
       feature.

    For language description, see section
    `7.15.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=112>`__
    of the SysML specification. For more details on the model, see section
    `8.3.15.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=335>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::AllocationUsage'

    STD: tuple[type[AllocationUsage], ...] = ...
    """
    All subtypes of ``AllocationUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``AllocationUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, AllocationUsage.STD):
            ...

    For type hints, instead use ``AllocationUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> AllocationUsage.Std:
            ...

    Note that ``AllocationUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "AllocationUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = AllocationUsage
        """Type hint for all subtypes of ``AllocationUsage`` according to the specification"""

    @property
    def allocation_definitions(self) -> LazyIterator[AllocationDefinition]:
        """
        Implementation of ``allocation_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``AllocationDefinitions`` that are the types of this
           ``AllocationUsage``.

        See section
        `8.3.15.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=335>`__
        of the SysML specification for more details.
        """

class ConnectionDefinition(PartDefinition):
    """
    Implementation of ``ConnectionDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``ConnectionDefinition`` is a ``PartDefinition`` that is also an
       ``AssociationStructure``. The end ``Features`` of a
       ``ConnectionDefinition`` must be ``Usages``.

    For language description, see section
    `7.13.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=100>`__
    of the SysML specification. For more details on the model, see section
    `8.3.13.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=329>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ConnectionDefinition'

    STD: tuple[type[ConnectionDefinition], ...] = ...
    """
    All subtypes of ``ConnectionDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ConnectionDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ConnectionDefinition.STD):
            ...

    For type hints, instead use ``ConnectionDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> ConnectionDefinition.Std:
            ...

    Note that ``ConnectionDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ConnectionDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ConnectionDefinition
        """Type hint for all subtypes of ``ConnectionDefinition`` according to the specification"""

    @property
    def connection_ends(self) -> LazyIterator[Usage]:
        """
        Implementation of ``connection_end`` defined in the SysML specification.

        **Specification**:

           The ``Usages`` that define the things related by the
           ``ConnectionDefinition``.

        See section
        `8.3.13.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=330>`__
        of the SysML specification for more details.
        """

    @property
    def source(self) -> Feature | None:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def sources(self) -> list[Feature]:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def owning_related_element(self) -> None:
        """
        Implementation of ``owning_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_element of this Relationship that owns the Relationship,
           if any.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def is_implied(self) -> bool:
        """
        Implementation of ``is_implied`` defined in the KerML specification.

        **Specification**:

           Whether this Relationship was generated by tooling to meet semantic
           rules, rather than being directly created by a modeler.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @is_implied.setter
    def is_implied(self, arg: bool, /) -> None: ...

    @property
    def related_elements(self) -> LazyIterator[Feature]:
        """
        Implementation of ``related_element`` defined in the KerML
        specification.

        **Specification**:

           The Elements that are related by this Relationship, derived as the
           union of the ``source`` and ``target`` Elements of the Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def targets(self) -> LazyIterator[Feature]:
        """
        Implementation of ``target`` defined in the KerML specification.

        **Specification**:

           The ``related_elements`` to which this Relationship is considered to
           be directed.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def owned_related_elements(self) -> LazyIterator[Feature]:
        """
        Implementation of ``owned_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_elements of this Relationship that are owned by the
           Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def source_type(self) -> Type | None:
        """
        Implementation of ``source_type`` defined in the KerML specification.

        **Specification**:

           The source ``related_type`` for this ``Association``. It is the first
           ``related_type`` of the ``Association``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=208>`__
        of the KerML specification for more details.
        """

    @property
    def related_types(self) -> LazyIterator[Type]:
        """
        Implementation of ``related_type`` defined in the KerML specification.

        **Specification**:

           The ``types`` of the ``association_ends`` of the ``Association``,
           which are the ``related_elements`` of the ``Association`` considered
           as a ``Relationship``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=208>`__
        of the KerML specification for more details.
        """

    @property
    def target_types(self) -> LazyIterator[Type]:
        """
        Implementation of ``target_type`` defined in the KerML specification.

        **Specification**:

           The target ``related_types`` for this ``Association``. This includes
           all the ``related_types`` other than the ``source_type``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=208>`__
        of the KerML specification for more details.
        """

    @property
    def association_ends(self) -> LazyIterator[Feature]:
        """
        Implementation of ``association_end`` defined in the KerML
        specification.

        **Specification**:

           The ``features`` of the ``Association`` that identify the things that
           can be related by it. A concrete ``Association`` must have at least
           two ``association_ends``. When it has exactly two, the
           ``Association`` is called a *binary* ``Association``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=208>`__
        of the KerML specification for more details.
        """

class AllocationDefinition(ConnectionDefinition):
    """
    Implementation of ``AllocationDefinition`` defined in the SysML
    specification.

    **Specification**:

       An ``AllocationDefinition`` is a ``ConnectionDefinition`` that
       specifies that some or all of the responsibility to realize the
       intent of the ``source`` is allocated to the ``target`` instances.
       Such allocations define mappings across the various structures and
       hierarchies of a system model, perhaps as a precursor to more
       rigorous specifications and implementations. An
       ``AllocationDefinition`` can itself be refined using nested
       ``allocations`` that give a finer-grained decomposition of the
       containing allocation mapping.

    For language description, see section
    `7.15.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=112>`__
    of the SysML specification. For more details on the model, see section
    `8.3.15.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=334>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::AllocationDefinition'

    STD: tuple[type[AllocationDefinition], ...] = ...
    """
    All subtypes of ``AllocationDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``AllocationDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, AllocationDefinition.STD):
            ...

    For type hints, instead use ``AllocationDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> AllocationDefinition.Std:
            ...

    Note that ``AllocationDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "AllocationDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = AllocationDefinition
        """Type hint for all subtypes of ``AllocationDefinition`` according to the specification"""

    @property
    def allocations(self) -> LazyIterator[AllocationUsage]:
        """
        Implementation of ``allocation`` defined in the SysML specification.

        **Specification**:

           The ``AllocationUsages`` that refine the allocation mapping defined
           by this ``AllocationDefinition``.

        See section
        `8.3.15.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=335>`__
        of the SysML specification for more details.
        """

class StateUsage(ActionUsage):
    """
    Implementation of ``StateUsage`` defined in the SysML specification.

    **Specification**:

       A ``StateUsage`` is an ``ActionUsage`` that is nominally the
       ``Usage`` of a ``StateDefinition``. However, other kinds of kernel
       ``Behaviors`` are also allowed as ``types``, to permit use of
       ``Behaviors``

       A ``StateUsage`` may be related to up to three of its
       ``owned_features`` by ``StateSubactionMembership`` ``Relationships``,
       all of different ``kinds``, corresponding to the entry, do and exit
       actions of the ``StateUsage``.

    For language description, see section
    `7.18.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=149>`__
    of the SysML specification. For more details on the model, see section
    `8.3.18.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=368>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::StateUsage'

    STD: tuple[type[StateUsage], ...] = ...
    """
    All subtypes of ``StateUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``StateUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, StateUsage.STD):
            ...

    For type hints, instead use ``StateUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> StateUsage.Std:
            ...

    Note that ``StateUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "StateUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = StateUsage
        """Type hint for all subtypes of ``StateUsage`` according to the specification"""

    @property
    def state_definitions(self) -> LazyIterator[StateDefinition | Behavior | ActionDefinition]:
        """
        Implementation of ``state_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``Behaviors`` that are the ``types`` of this ``StateUsage``.
           Nominally, these would be ``StateDefinitions``, but kernel
           ``Behaviors`` are also allowed, to permit use of ``Behaviors`` from
           the Kernel Model Libraries.

        See section
        `8.3.18.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=369>`__
        of the SysML specification for more details.
        """

    @property
    def is_parallel(self) -> bool:
        """
        Implementation of ``is_parallel`` defined in the SysML specification.

        **Specification**:

           Whether the ``nested_states`` of this ``StateUsage`` are to all be
           performed in parallel. If true, none of the ``nested_actions`` (which
           include ``nested_states``) may have any incoming or outgoing
           ``Transitions``. If false, only one ``nested_state`` may be performed
           at a time.

        See section
        `8.3.18.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=369>`__
        of the SysML specification for more details.
        """

    @is_parallel.setter
    def is_parallel(self, arg: bool, /) -> None: ...

    @property
    def entry_action(self) -> ActionUsage | None:
        """
        Implementation of ``entry_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsage`` of this ``StateUsage`` to be performed on entry
           to the state defined by the ``StateDefinition``. It is the owned
           ``ActionUsage`` related to the ``StateUsage`` by a
           ``StateSubactionMembership`` with ``kind = entry``.

        See section
        `8.3.18.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=369>`__
        of the SysML specification for more details.
        """

    @property
    def do_action(self) -> ActionUsage | None:
        """
        Implementation of ``do_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsage`` of this ``StateUsage`` to be performed while in
           the state defined by the ``StateDefinition``. It is the owned
           ``ActionUsage`` related to the ``StateUsage`` by a
           ``StateSubactionMembership`` with ``kind = do``.

        See section
        `8.3.18.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=369>`__
        of the SysML specification for more details.
        """

    @property
    def exit_action(self) -> ActionUsage | None:
        """
        Implementation of ``exit_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsage`` of this ``StateUsage`` to be performed on exit to
           the state defined by the ``StateDefinition``. It is the owned
           ``ActionUsage`` related to the ``StateUsage`` by a
           ``StateSubactionMembership`` with ``kind = exit``.

        See section
        `8.3.18.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=369>`__
        of the SysML specification for more details.
        """

class TransitionUsage(ActionUsage):
    """
    Implementation of ``TransitionUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``TransitionUsage`` is an ``ActionUsage`` representing a triggered
       transition between ``ActionUsages`` or ``StateUsages``. When
       triggered by a ``trigger_action``, when its ``guard_expression`` is
       true, the ``TransitionUsage`` asserts that its ``source`` is exited,
       then its ``effect_action`` (if any) is performed, and then its
       ``target`` is entered.

       A ``TransitionUsage`` can be related to some of its
       ``owned_features`` using ``TransitionFeatureMembership``
       ``Relationships``, corresponding to the ``trigger_action``,
       ``guard_expression`` and ``effect_action`` of the
       ``TransitionUsage``.

    For language description, see section
    `7.18.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=151>`__
    of the SysML specification. For more details on the model, see section
    `8.3.18.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=372>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::TransitionUsage'

    STD: tuple[type[TransitionUsage], ...] = ...
    """
    All subtypes of ``TransitionUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``TransitionUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, TransitionUsage.STD):
            ...

    For type hints, instead use ``TransitionUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> TransitionUsage.Std:
            ...

    Note that ``TransitionUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "TransitionUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = TransitionUsage
        """Type hint for all subtypes of ``TransitionUsage`` according to the specification"""

    @property
    def source(self) -> ActionUsage | None:
        """
        Implementation of ``source`` defined in the SysML specification.

        **Specification**:

           The source ``ActionUsage`` of this ``TransitionUsage``, which becomes
           the ``source`` of the ``succession`` for the ``TransitionUsage``.

        See section
        `8.3.18.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=373>`__
        of the SysML specification for more details.
        """

    @property
    def source_member(self) -> TransitionSourceAccessor:
        """Syside specific accessor for manipulating ``source``."""

    @property
    def target(self) -> ActionUsage | None:
        """
        Implementation of ``target`` defined in the SysML specification.

        **Specification**:

           The target ``ActionUsage`` of this ``TransitionUsage``, which is the
           ``target_feature`` of the ``succession`` for the ``TransitionUsage``.

        See section
        `8.3.18.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=373>`__
        of the SysML specification for more details.
        """

    @property
    def trigger_action(self) -> AcceptActionUsage | None:
        """
        Implementation of ``trigger_action`` defined in the SysML specification.

        **Specification**:

           The ``AcceptActionUsages`` that define the triggers of this
           ``TransitionUsage``, which are the ``owned_features`` of the
           ``TransitionUsage`` related to it by ``TransitionFeatureMemberships``
           with ``kind = trigger``, which must all be ``AcceptActionUsages``.

        See section
        `8.3.18.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=373>`__
        of the SysML specification for more details.
        """

    @property
    def trigger_actions(self) -> list[AcceptActionUsage]:
        """
        Implementation of ``trigger_action`` defined in the SysML specification.

        **Specification**:

           The ``AcceptActionUsages`` that define the triggers of this
           ``TransitionUsage``, which are the ``owned_features`` of the
           ``TransitionUsage`` related to it by ``TransitionFeatureMemberships``
           with ``kind = trigger``, which must all be ``AcceptActionUsages``.

        See section
        `8.3.18.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=373>`__
        of the SysML specification for more details.
        """

    @property
    def trigger_action_member(self) -> TriggerAccessor:
        """Syside specific accessor for manipulating ``trigger_action``."""

    @property
    def guard_expression(self) -> Expression | None:
        """
        Implementation of ``guard_expression`` defined in the SysML
        specification.

        **Specification**:

           The ``Expressions`` that define the guards of this
           ``TransitionUsage``, which are the ``owned_features`` of the
           ``TransitionUsage`` related to it by ``TransitionFeatureMemberships``
           with ``kind = guard``, which must all be ``Expressions``.

        See section
        `8.3.18.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=373>`__
        of the SysML specification for more details.
        """

    @property
    def guard_expressions(self) -> list[Expression]:
        """
        Implementation of ``guard_expression`` defined in the SysML
        specification.

        **Specification**:

           The ``Expressions`` that define the guards of this
           ``TransitionUsage``, which are the ``owned_features`` of the
           ``TransitionUsage`` related to it by ``TransitionFeatureMemberships``
           with ``kind = guard``, which must all be ``Expressions``.

        See section
        `8.3.18.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=373>`__
        of the SysML specification for more details.
        """

    @property
    def guard_expression_member(self) -> GuardAccessor:
        """Syside specific accessor for manipulating ``guard_expression``."""

    @property
    def effect_action(self) -> ActionUsage | None:
        """
        Implementation of ``effect_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsages`` that define the effects of this
           ``TransitionUsage``, which are the ``owned_features`` of the
           ``TransitionUsage`` related to it by ``TransitionFeatureMemberships``
           with ``kind = effect``, which must all be ``ActionUsages``.

        See section
        `8.3.18.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=373>`__
        of the SysML specification for more details.
        """

    @property
    def effect_actions(self) -> list[ActionUsage]:
        """
        Implementation of ``effect_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsages`` that define the effects of this
           ``TransitionUsage``, which are the ``owned_features`` of the
           ``TransitionUsage`` related to it by ``TransitionFeatureMemberships``
           with ``kind = effect``, which must all be ``ActionUsages``.

        See section
        `8.3.18.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=373>`__
        of the SysML specification for more details.
        """

    @property
    def effect_action_member(self) -> EffectAccessor:
        """Syside specific accessor for manipulating ``effect_action``."""

    @property
    def succession(self) -> SuccessionAsUsage | None:
        """
        Implementation of ``succession`` defined in the SysML specification.

        **Specification**:

           The ``Succession`` that is the ``owned_feature`` of this
           ``TransitionUsage``, which, if the ``TransitionUsage`` is triggered,
           asserts the temporal ordering of the ``source`` and ``target``.

        See section
        `8.3.18.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=373>`__
        of the SysML specification for more details.
        """

    @property
    def succession_member(self) -> OwnedSuccessionAccessor:
        """Syside specific accessor for manipulating ``succession``."""

    @property
    def transition_link_source(self) -> ReferenceUsage | None:
        """
        The first ``EmptyParameterMember`` in the concrete syntax after ``TransitionSourceMember``.
        """

    @property
    def transition_link_source_member(self) -> ReferenceParameterAccessor:
        """Syside specific accessor for manipulating ``transition_link_source``."""

    @property
    def transition_link(self) -> ReferenceUsage | None:
        """
        An implicitly created transition link element used to satisfy semantic constraints.
        """

    @property
    def transition_link_member(self) -> ReferenceUsageAccessor:
        """Syside specific accessor for manipulating ``transition_link``."""

    @property
    def payload(self) -> ReferenceUsage | None:
        """
        An implicitly created payload element used to satisfy semantic constraints.
        """

    @property
    def payload_member(self) -> ReferenceParameterAccessor:
        """Syside specific accessor for manipulating ``payload``."""

class AcceptActionUsage(ActionUsage):
    """
    Implementation of ``AcceptActionUsage`` defined in the SysML
    specification.

    **Specification**:

       An ``AcceptActionUsage`` is an ``ActionUsage`` that specifies the
       acceptance of an ``incoming_transfer`` from the ``Occurrence`` given
       by the result of its ``receiver_argument`` Expression. (If no
       ``receiver_argument`` is provided, the default is the ``this``
       context of the AcceptActionUsage.) The payload of the accepted
       ``Transfer`` is output on its ``payload_parameter``. Which
       ``Transfers`` may be accepted is determined by conformance to the
       typing and (potentially) binding of the ``payload_parameter``.

    For language description, see section
    `7.17.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=138>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=341>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::AcceptActionUsage'

    STD: tuple[type[AcceptActionUsage], ...] = ...
    """
    All subtypes of ``AcceptActionUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``AcceptActionUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, AcceptActionUsage.STD):
            ...

    For type hints, instead use ``AcceptActionUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> AcceptActionUsage.Std:
            ...

    Note that ``AcceptActionUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "AcceptActionUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = AcceptActionUsage
        """Type hint for all subtypes of ``AcceptActionUsage`` according to the specification"""

    @property
    def receiver_parameter(self) -> ReferenceUsage | None:
        """The parameter that owns the ``receiver_argument``."""

    @property
    def receiver_member(self) -> ParameterAccessor:
        """Syside specific accessor for manipulating ``receiver``."""

    @property
    def receiver_argument(self) -> Expression | None:
        """
        Implementation of ``receiver_argument`` defined in the SysML
        specification.

        **Specification**:

           An ``Expression`` whose ``result`` is bound to the ``receiver`` input
           ``parameter`` of this ``AcceptActionUsage``.

        See section
        `8.3.17.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=342>`__
        of the SysML specification for more details.
        """

    @property
    def payload_parameter(self) -> ReferenceUsage | None:
        """
        Implementation of ``payload_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``nested_reference`` of this ``AcceptActionUsage`` that redefines
           the ``payload`` output ``parameter`` of the base
           ``AcceptActionUsage`` ``AcceptAction`` from the Systems Model
           Library.

        See section
        `8.3.17.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=342>`__
        of the SysML specification for more details.
        """

    @property
    def payload_member(self) -> ParameterAccessor:
        """Syside specific accessor for manipulating ``payload``."""

    @property
    def payload_argument(self) -> Expression | None:
        """
        Implementation of ``payload_argument`` defined in the SysML
        specification.

        **Specification**:

           An ``Expression`` whose ``result`` is bound to the ``payload``
           ``parameter`` of this ``AcceptActionUsage``. If provided, the
           ``AcceptActionUsage`` will only accept a ``Transfer`` with exactly
           this ``payload``.

        See section
        `8.3.17.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=342>`__
        of the SysML specification for more details.
        """

class CalculationUsage(ActionUsage):
    """
    Implementation of ``CalculationUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``CalculationUsage`` is an ``ActionUsage`` that is also an
       ``Expression``, and, so, is typed by a ``Function``. Nominally, if
       the ``type`` is a ``CalculationDefinition``, a ``CalculationUsage``
       is a ``Usage`` of that ``CalculationDefinition`` within a system.
       However, other kinds of kernel ``Functions`` are also allowed, to
       permit use of ``Functions`` from the Kernel Model Libraries.

    For language description, see section
    `7.19.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=156>`__
    of the SysML specification. For more details on the model, see section
    `8.3.19.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=378>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::CalculationUsage'

    STD: tuple[type[CalculationUsage], ...] = ...
    """
    All subtypes of ``CalculationUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``CalculationUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, CalculationUsage.STD):
            ...

    For type hints, instead use ``CalculationUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> CalculationUsage.Std:
            ...

    Note that ``CalculationUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "CalculationUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = CalculationUsage
        """Type hint for all subtypes of ``CalculationUsage`` according to the specification"""

    @property
    def calculation_definition(self) -> Function | CalculationDefinition | ConstraintDefinition | None:
        """
        Implementation of ``calculation_definition`` defined in the SysML
        specification.

        **Specification**:

           The Function that is the ``type`` of this ``CalculationUsage``.
           Nominally, this would be a ``CalculationDefinition``, but a kernel
           ``Function`` is also allowed, to permit use of ``Functions`` from the
           Kernel Model Libraries.

        See section
        `8.3.19.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=378>`__
        of the SysML specification for more details.
        """

    @property
    def is_model_level_evaluable(self) -> bool:
        """
        Implementation of ``is_model_level_evaluable`` defined in the KerML
        specification.

        **Specification**:

           Whether this ``Expression`` meets the constraints necessary to be
           evaluated at *model level*, that is, using metadata within the model.

        See section
        `8.3.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=221>`__
        of the KerML specification for more details.
        """

    @property
    def function(self) -> Function | CalculationDefinition | ConstraintDefinition | None:
        """
        Implementation of ``function`` defined in the KerML specification.

        **Specification**:

           The ``Function`` that types this ``Expression``.

           This is the Function that types the Expression.

        See section
        `8.3.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=221>`__
        of the KerML specification for more details.
        """

    @property
    def result(self) -> Feature | None:
        """
        Implementation of ``result`` defined in the KerML specification.

        **Specification**:

           An ``output`` ``parameter`` of the ``Expression`` whose value is the
           result of the ``Expression``. The result of an ``Expression`` is
           either inherited from its ``function`` or it is related to the
           ``Expression`` via a ``ReturnParameterMembership``, in which case it
           redefines the ``result`` ``parameter`` of its ``function``.

        See section
        `8.3.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=222>`__
        of the KerML specification for more details.
        """

    @property
    def result_expression(self) -> Expression | None:
        """
        The result expression of this ``CalculationUsage`` owned by ``ResultExpressionMembership``.
        """

    @property
    def result_expression_member(self) -> ResultExpressionAccessor:
        """Syside specific accessor for manipulating ``result_expression``."""

class ConstraintUsage(OccurrenceUsage):
    """
    Implementation of ``ConstraintUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``ConstraintUsage`` is an ``OccurrenceUsage`` that is also a
       ``BooleanExpression``, and, so, is typed by a ``Predicate``.
       Nominally, if the type is a ``ConstraintDefinition``, a
       ``ConstraintUsage`` is a ``Usage`` of that ``ConstraintDefinition``.
       However, other kinds of kernel ``Predicates`` are also allowed, to
       permit use of ``Predicates`` from the Kernel Model Libraries.

    For language description, see section
    `7.20.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=159>`__
    of the SysML specification. For more details on the model, see section
    `8.3.20.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=381>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ConstraintUsage'

    STD: tuple[type[ConstraintUsage], ...] = ...
    """
    All subtypes of ``ConstraintUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ConstraintUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ConstraintUsage.STD):
            ...

    For type hints, instead use ``ConstraintUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> ConstraintUsage.Std:
            ...

    Note that ``ConstraintUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ConstraintUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ConstraintUsage
        """Type hint for all subtypes of ``ConstraintUsage`` according to the specification"""

    @property
    def constraint_definition(self) -> ConstraintDefinition | Predicate | None:
        """
        Implementation of ``constraint_definition`` defined in the SysML
        specification.

        **Specification**:

           The (single) ``Predicate`` that is the type of this
           ``ConstraintUsage``. Nominally, this will be a
           ``ConstraintDefinition``, but other kinds of ``Predicates`` are also
           allowed, to permit use of ``Predicates`` from the Kernel Model
           Libraries.

        See section
        `8.3.20.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=381>`__
        of the SysML specification for more details.
        """

    @property
    def behaviors(self) -> LazyIterator[Behavior | ActionDefinition]:
        """
        Implementation of ``behavior`` defined in the KerML specification.

        **Specification**:

           The ``Behaviors`` that type this ``Step``.

        See section
        `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=218>`__
        of the KerML specification for more details.
        """

    @property
    def owned_parameters(self) -> LazyIterator[Feature]:
        """The ``parameters`` owned by this ``Step``."""

    @property
    def parameters(self) -> LazyIterator[Feature]:
        """
        Implementation of ``parameter`` defined in the KerML specification.

        **Specification**:

           The ``parameters`` of this ``Step``, which are defined as its
           ``directed_features``, whose values are passed into and/or out of a
           performance of the ``Step``.

        See section
        `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=218>`__
        of the KerML specification for more details.
        """

    @property
    def is_model_level_evaluable(self) -> bool:
        """
        Implementation of ``is_model_level_evaluable`` defined in the KerML
        specification.

        **Specification**:

           Whether this ``Expression`` meets the constraints necessary to be
           evaluated at *model level*, that is, using metadata within the model.

        See section
        `8.3.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=221>`__
        of the KerML specification for more details.
        """

    @property
    def function(self) -> Function | CalculationDefinition | ConstraintDefinition | None:
        """
        Implementation of ``function`` defined in the KerML specification.

        **Specification**:

           The ``Function`` that types this ``Expression``.

           This is the Function that types the Expression.

        See section
        `8.3.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=221>`__
        of the KerML specification for more details.
        """

    @property
    def result(self) -> Feature | None:
        """
        Implementation of ``result`` defined in the KerML specification.

        **Specification**:

           An ``output`` ``parameter`` of the ``Expression`` whose value is the
           result of the ``Expression``. The result of an ``Expression`` is
           either inherited from its ``function`` or it is related to the
           ``Expression`` via a ``ReturnParameterMembership``, in which case it
           redefines the ``result`` ``parameter`` of its ``function``.

        See section
        `8.3.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=222>`__
        of the KerML specification for more details.
        """

    @property
    def predicate(self) -> Predicate | ConstraintDefinition | None:
        """
        Implementation of ``predicate`` defined in the KerML specification.

        **Specification**:

           The Predicate that types the Expression.

           The ``Predicate`` that types this ``BooleanExpression``.

        See section
        `8.3.4.7.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=221>`__
        of the KerML specification for more details.
        """

    @property
    def result_expression(self) -> Expression | None:
        """
        The result expression of this ``ConstraintUsage`` owned by ``ResultExpressionMembership``.
        """

    @property
    def result_expression_member(self) -> ResultExpressionAccessor:
        """Syside specific accessor for manipulating ``result_expression``."""

class RequirementUsage(ConstraintUsage):
    """
    Implementation of ``RequirementUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``RequirementUsage`` is a ``Usage`` of a ``RequirementDefinition``.

    For language description, see section
    `7.21.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=165>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=391>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::RequirementUsage'

    STD: tuple[type[RequirementUsage], ...] = ...
    """
    All subtypes of ``RequirementUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``RequirementUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, RequirementUsage.STD):
            ...

    For type hints, instead use ``RequirementUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> RequirementUsage.Std:
            ...

    Note that ``RequirementUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "RequirementUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = RequirementUsage
        """Type hint for all subtypes of ``RequirementUsage`` according to the specification"""

    @property
    def requirement_definition(self) -> RequirementDefinition | None:
        """
        Implementation of ``requirement_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``RequirementDefinition`` that is the single ``definition`` of
           this ``RequirementUsage``.

        See section
        `8.3.21.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=392>`__
        of the SysML specification for more details.
        """

    @property
    def subject_parameter(self) -> Usage | None:
        """
        Implementation of ``subject_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``parameter`` of this ``RequirementUsage`` that represents its
           subject.

        See section
        `8.3.21.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=392>`__
        of the SysML specification for more details.
        """

    @property
    def actor_parameters(self) -> LazyIterator[PartUsage]:
        """
        Implementation of ``actor_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``parameters`` of this ``RequirementUsage`` that represent actors
           involved in the requirement.

        See section
        `8.3.21.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=392>`__
        of the SysML specification for more details.
        """

    @property
    def req_id(self) -> str | None:
        """
        Implementation of ``req_id`` defined in the SysML specification.

        **Specification**:

           An optional modeler-specified identifier for this
           ``RequirementUsage`` (used, e.g., to link it to an original
           requirement text in some source document), which is the
           ``declared_short_name`` for the ``RequirementUsage``.

        See section
        `8.3.21.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=392>`__
        of the SysML specification for more details.
        """

    @req_id.setter
    def req_id(self, arg: str | None) -> None: ...

    @property
    def texts(self) -> LazyIterator[str]:
        """
        Implementation of ``text`` defined in the SysML specification.

        **Specification**:

           An optional textual statement of the requirement represented by this
           ``RequirementUsage``, derived from the ``bodies`` of the
           ``documentation`` of the ``RequirementUsage``.

        See section
        `8.3.21.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=392>`__
        of the SysML specification for more details.
        """

    @property
    def stakeholder_parameters(self) -> LazyIterator[PartUsage]:
        """
        Implementation of ``stakeholder_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``parameters`` of this ``RequirementUsage`` that represent
           stakeholders for the requirement.

        See section
        `8.3.21.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=392>`__
        of the SysML specification for more details.
        """

    @property
    def assumed_constraints(self) -> LazyIterator[ConstraintUsage]:
        """
        Implementation of ``assumed_constraint`` defined in the SysML
        specification.

        **Specification**:

           The owned ``ConstraintUsages`` that represent assumptions of this
           ``RequirementUsage``, derived as the ``owned_constraints`` of the
           ``RequirementConstraintMemberships`` of the ``RequirementUsage`` with
           ``kind`` = ``assumption``.

        See section
        `8.3.21.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=392>`__
        of the SysML specification for more details.
        """

    @property
    def required_constraints(self) -> LazyIterator[ConstraintUsage]:
        """
        Implementation of ``required_constraint`` defined in the SysML
        specification.

        **Specification**:

           The owned ``ConstraintUsages`` that represent requirements of this
           ``RequirementUsage``, which are the ``owned_constraints`` of the
           ``RequirementConstraintMemberships`` of the ``RequirementUsage`` with
           ``kind`` = ``requirement``.

        See section
        `8.3.21.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=392>`__
        of the SysML specification for more details.
        """

    @property
    def framed_concerns(self) -> LazyIterator[ConcernUsage]:
        """
        Implementation of ``framed_concern`` defined in the SysML specification.

        **Specification**:

           The ``ConcernUsages`` framed by this ``RequirementUsage``, which are
           the ``owned_concerns`` of all ``FramedConcernMemberships`` of the
           ``RequirementUsage``.

        See section
        `8.3.21.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=392>`__
        of the SysML specification for more details.
        """

class ConstraintDefinition(OccurrenceDefinition):
    """
    Implementation of ``ConstraintDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``ConstraintDefinition`` is an ``OccurrenceDefinition`` that is
       also a ``Predicate`` that defines a constraint that may be asserted
       to hold on a system or part of a system.

    For language description, see section
    `7.20.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=159>`__
    of the SysML specification. For more details on the model, see section
    `8.3.20.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=380>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ConstraintDefinition'

    STD: tuple[type[ConstraintDefinition], ...] = ...
    """
    All subtypes of ``ConstraintDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ConstraintDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ConstraintDefinition.STD):
            ...

    For type hints, instead use ``ConstraintDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> ConstraintDefinition.Std:
            ...

    Note that ``ConstraintDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ConstraintDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ConstraintDefinition
        """Type hint for all subtypes of ``ConstraintDefinition`` according to the specification"""

    @property
    def steps(self) -> LazyIterator[Step | ActionUsage | FlowUsage]:
        """
        Implementation of ``step`` defined in the KerML specification.

        **Specification**:

           The ``Steps`` that make up this ``Behavior``.

        See section
        `8.3.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=217>`__
        of the KerML specification for more details.
        """

    @property
    def parameters(self) -> LazyIterator[Feature]:
        """
        Implementation of ``parameter`` defined in the KerML specification.

        **Specification**:

           The parameters of this ``Behavior``, which are defined as its
           ``directed_features``, whose values are passed into and/or out of a
           performance of the ``Behavior``.

        See section
        `8.3.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=217>`__
        of the KerML specification for more details.
        """

    @property
    def is_model_level_evaluable(self) -> bool:
        """
        Implementation of ``is_model_level_evaluable`` defined in the KerML
        specification.

        **Specification**:

           Whether this ``Function`` can be used as the ``function`` of a
           model-level evaluable ``InvocationExpression``. Certain ``Functions``
           from the Kernel Functions Library are considered to have
           ``is_model_level_evaluable = true``. For all other ``Functions`` it
           is ``false``.

           **Note:** See the specification of the KerML concrete syntax notation
           for ``Expressions`` for an identification of which library
           ``Functions`` are model-level evaluable.

        See section
        `8.3.4.7.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
        of the KerML specification for more details.
        """

    @property
    def expressions(self) -> LazyIterator[Expression | CalculationUsage | ConstraintUsage]:
        """
        Implementation of ``expression`` defined in the KerML specification.

        **Specification**:

           The ``Expressions`` that are ``steps`` in the calculation of the
           ``result`` of this ``Function``.

           The set of expressions that represent computational steps or parts of
           a system of equations within the Function.

        See section
        `8.3.4.7.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
        of the KerML specification for more details.
        """

    @property
    def result(self) -> Feature | None:
        """
        Implementation of ``result`` defined in the KerML specification.

        **Specification**:

           The object or value that is the result of evaluating the Function.

           The ``result`` ``parameter`` of the ``Function``, which is owned by
           the ``Function`` via a ``ReturnParameterMembership``.

        See section
        `8.3.4.7.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
        of the KerML specification for more details.
        """

    @property
    def any_result(self) -> Feature | None:
        """``result`` that also considers specialized ``Functions``."""

    @property
    def result_expression(self) -> Expression | None:
        """
        The result expression of this ``Function`` owned by ``ResultExpressionMembership``.
        """

    @property
    def result_expression_member(self) -> ResultExpressionAccessor:
        """Syside specific accessor for manipulating ``result_expression``."""

class RequirementDefinition(ConstraintDefinition):
    """
    Implementation of ``RequirementDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``RequirementDefinition`` is a ``ConstraintDefinition`` that
       defines a requirement used in the context of a specification as a
       constraint that a valid solution must satisfy. The specification is
       relative to a specified subject, possibly in collaboration with one
       or more external actors.

    For language description, see section
    `7.21.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=165>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=389>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::RequirementDefinition'

    STD: tuple[type[RequirementDefinition], ...] = ...
    """
    All subtypes of ``RequirementDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``RequirementDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, RequirementDefinition.STD):
            ...

    For type hints, instead use ``RequirementDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> RequirementDefinition.Std:
            ...

    Note that ``RequirementDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "RequirementDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = RequirementDefinition
        """Type hint for all subtypes of ``RequirementDefinition`` according to the specification"""

    @property
    def subject_parameter(self) -> Usage | None:
        """
        Implementation of ``subject_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``parameter`` of this ``RequirementDefinition`` that represents
           its subject.

        See section
        `8.3.21.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=390>`__
        of the SysML specification for more details.
        """

    @property
    def actor_parameters(self) -> LazyIterator[PartUsage]:
        """
        Implementation of ``actor_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``parameters`` of this ``RequirementDefinition`` that represent
           actors involved in the requirement.

        See section
        `8.3.21.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=389>`__
        of the SysML specification for more details.
        """

    @property
    def req_id(self) -> str | None:
        """
        Implementation of ``req_id`` defined in the SysML specification.

        **Specification**:

           An optional modeler-specified identifier for this
           ``RequirementDefinition`` (used, e.g., to link it to an original
           requirement text in some source document), which is the
           ``declared_short_name`` for the ``RequirementDefinition``.

        See section
        `8.3.21.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=389>`__
        of the SysML specification for more details.
        """

    @req_id.setter
    def req_id(self, arg: str | None) -> None: ...

    @property
    def texts(self) -> LazyIterator[str]:
        """
        Implementation of ``text`` defined in the SysML specification.

        **Specification**:

           An optional textual statement of the requirement represented by this
           ``RequirementDefinition``, derived from the ``bodies`` of the
           ``documentation`` of the ``RequirementDefinition``.

        See section
        `8.3.21.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=390>`__
        of the SysML specification for more details.
        """

    @property
    def stakeholder_parameters(self) -> LazyIterator[PartUsage]:
        """
        Implementation of ``stakeholder_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``parameters`` of this ``RequirementDefinition`` that represent
           stakeholders for th requirement.

        See section
        `8.3.21.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=390>`__
        of the SysML specification for more details.
        """

    @property
    def assumed_constraints(self) -> LazyIterator[ConstraintUsage]:
        """
        Implementation of ``assumed_constraint`` defined in the SysML
        specification.

        **Specification**:

           The owned ``ConstraintUsages`` that represent assumptions of this
           ``RequirementDefinition``, which are the ``owned_constraints`` of the
           ``RequirementConstraintMemberships`` of the ``RequirementDefinition``
           with ``kind = assumption``.

        See section
        `8.3.21.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=389>`__
        of the SysML specification for more details.
        """

    @property
    def required_constraints(self) -> LazyIterator[ConstraintUsage]:
        """
        Implementation of ``required_constraint`` defined in the SysML
        specification.

        **Specification**:

           The owned ``ConstraintUsages`` that represent requirements of this
           ``RequirementDefinition``, derived as the ``owned_constraints`` of
           the ``RequirementConstraintMemberships`` of the
           ``RequirementDefinition`` with ``kind`` = ``requirement``.

        See section
        `8.3.21.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=390>`__
        of the SysML specification for more details.
        """

    @property
    def framed_concerns(self) -> LazyIterator[ConcernUsage]:
        """
        Implementation of ``framed_concern`` defined in the SysML specification.

        **Specification**:

           The ``ConcernUsages`` framed by this ``RequirementDefinition``, which
           are the ``owned_concerns`` of all ``FramedConcernMemberships`` of the
           ``RequirementDefinition``.

        See section
        `8.3.21.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=389>`__
        of the SysML specification for more details.
        """

class ConcernUsage(RequirementUsage):
    """
    Implementation of ``ConcernUsage`` defined in the SysML specification.

    **Specification**:

       A ``ConcernUsage`` is a ``Usage`` of a ``ConcernDefinition``.

       The ``owned_stakeholder`` features of the ConcernUsage shall all
       subset the ``ConcernCheck::concerned_stakeholders`` feature. If the
       ConcernUsage is an ``owned_feature`` of a StakeholderDefinition or
       StakeholderUsage, then the ConcernUsage shall have an
       ``owned_stakeholder`` feature that is bound to the ``self`` feature
       of its owner.

    For language description, see section
    `7.21.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=167>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=386>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ConcernUsage'

    STD: tuple[type[ConcernUsage], ...] = ...
    """
    All subtypes of ``ConcernUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ConcernUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ConcernUsage.STD):
            ...

    For type hints, instead use ``ConcernUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> ConcernUsage.Std:
            ...

    Note that ``ConcernUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ConcernUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ConcernUsage
        """Type hint for all subtypes of ``ConcernUsage`` according to the specification"""

    @property
    def concern_definition(self) -> ConcernDefinition | None:
        """
        Implementation of ``concern_definition`` defined in the SysML
        specification.

        **Specification**:

           The ConcernDefinition that is the single type of this ConcernUsage.

        See section
        `8.3.21.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=386>`__
        of the SysML specification for more details.
        """

class ConcernDefinition(RequirementDefinition):
    r"""
    Implementation of ``ConcernDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``ConcernDefinition`` is a ``RequirementDefinition`` that one or
       more stakeholders may be interested in having addressed. These
       stakeholders are identified by the ``owned_stakeholders``\ of the
       ``ConcernDefinition``.

    For language description, see section
    `7.21.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=167>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=385>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ConcernDefinition'

    STD: tuple[type[ConcernDefinition], ...] = ...
    """
    All subtypes of ``ConcernDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ConcernDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ConcernDefinition.STD):
            ...

    For type hints, instead use ``ConcernDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> ConcernDefinition.Std:
            ...

    Note that ``ConcernDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ConcernDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ConcernDefinition
        """Type hint for all subtypes of ``ConcernDefinition`` according to the specification"""

class CaseUsage(CalculationUsage):
    """
    Implementation of ``CaseUsage`` defined in the SysML specification.

    **Specification**:

       A ``CaseUsage`` is a ``Usage`` of a ``CaseDefinition``.

    For language description, see section
    `7.22.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=169>`__
    of the SysML specification. For more details on the model, see section
    `8.3.22.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=400>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::CaseUsage'

    STD: tuple[type[CaseUsage], ...] = ...
    """
    All subtypes of ``CaseUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``CaseUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, CaseUsage.STD):
            ...

    For type hints, instead use ``CaseUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> CaseUsage.Std:
            ...

    Note that ``CaseUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "CaseUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = CaseUsage
        """Type hint for all subtypes of ``CaseUsage`` according to the specification"""

    @property
    def subject_parameter(self) -> Usage | None:
        """
        Implementation of ``subject_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``parameter`` of this ``CaseUsage`` that represents its subject.

        See section
        `8.3.22.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=401>`__
        of the SysML specification for more details.
        """

    @property
    def actor_parameters(self) -> LazyIterator[PartUsage]:
        """
        Implementation of ``actor_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``parameters`` of this ``CaseUsage`` that represent actors
           involved in the case.

        See section
        `8.3.22.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=400>`__
        of the SysML specification for more details.
        """

    @property
    def objective_requirement(self) -> RequirementUsage | None:
        """
        Implementation of ``objective_requirement`` defined in the SysML
        specification.

        **Specification**:

           The ``RequirementUsage`` representing the objective of this
           ``CaseUsage``.

        See section
        `8.3.22.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=400>`__
        of the SysML specification for more details.
        """

    @property
    def case_definition(self) -> CaseDefinition | None:
        """
        Implementation of ``case_definition`` defined in the SysML
        specification.

        **Specification**:

           The CaseDefinition that is the type of this CaseUsage.

        See section
        `8.3.22.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=400>`__
        of the SysML specification for more details.
        """

class ActionDefinition(OccurrenceDefinition):
    """
    Implementation of ``ActionDefinition`` defined in the SysML
    specification.

    **Specification**:

       An ``ActionDefinition`` is a ``Definition`` that is also a
       ``Behavior`` that defines an ``Action`` performed by a system or part
       of a system.

    For language description, see section
    `7.17.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=131>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=343>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ActionDefinition'

    STD: tuple[type[ActionDefinition], ...] = ...
    """
    All subtypes of ``ActionDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ActionDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ActionDefinition.STD):
            ...

    For type hints, instead use ``ActionDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> ActionDefinition.Std:
            ...

    Note that ``ActionDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ActionDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ActionDefinition
        """Type hint for all subtypes of ``ActionDefinition`` according to the specification"""

    @property
    def steps(self) -> LazyIterator[Step | ActionUsage | FlowUsage]:
        """
        Implementation of ``step`` defined in the KerML specification.

        **Specification**:

           The ``Steps`` that make up this ``Behavior``.

        See section
        `8.3.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=217>`__
        of the KerML specification for more details.
        """

    @property
    def parameters(self) -> LazyIterator[Feature]:
        """
        Implementation of ``parameter`` defined in the KerML specification.

        **Specification**:

           The parameters of this ``Behavior``, which are defined as its
           ``directed_features``, whose values are passed into and/or out of a
           performance of the ``Behavior``.

        See section
        `8.3.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=217>`__
        of the KerML specification for more details.
        """

    @property
    def actions(self) -> LazyIterator[ActionUsage | FlowUsage]:
        """
        Implementation of ``action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsages`` that are ``steps`` in this ``ActionDefinition``,
           which define the actions that specify the behavior of the
           ``ActionDefinition``.

        See section
        `8.3.17.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=344>`__
        of the SysML specification for more details.
        """

class CalculationDefinition(ActionDefinition):
    """
    Implementation of ``CalculationDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``CalculationDefinition`` is an ActionDefinition that also defines
       a ``Function`` producing a ``result``.

    For language description, see section
    `7.19.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=156>`__
    of the SysML specification. For more details on the model, see section
    `8.3.19.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=377>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::CalculationDefinition'

    STD: tuple[type[CalculationDefinition], ...] = ...
    """
    All subtypes of ``CalculationDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``CalculationDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, CalculationDefinition.STD):
            ...

    For type hints, instead use ``CalculationDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> CalculationDefinition.Std:
            ...

    Note that ``CalculationDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "CalculationDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = CalculationDefinition
        """Type hint for all subtypes of ``CalculationDefinition`` according to the specification"""

    @property
    def calculations(self) -> LazyIterator[CalculationUsage]:
        """
        Implementation of ``calculation`` defined in the SysML specification.

        **Specification**:

           The ``actions`` of this ``CalculationDefinition`` that are
           ``CalculationUsages``.

        See section
        `8.3.19.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=377>`__
        of the SysML specification for more details.
        """

    @property
    def is_model_level_evaluable(self) -> bool:
        """
        Implementation of ``is_model_level_evaluable`` defined in the KerML
        specification.

        **Specification**:

           Whether this ``Function`` can be used as the ``function`` of a
           model-level evaluable ``InvocationExpression``. Certain ``Functions``
           from the Kernel Functions Library are considered to have
           ``is_model_level_evaluable = true``. For all other ``Functions`` it
           is ``false``.

           **Note:** See the specification of the KerML concrete syntax notation
           for ``Expressions`` for an identification of which library
           ``Functions`` are model-level evaluable.

        See section
        `8.3.4.7.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
        of the KerML specification for more details.
        """

    @property
    def expressions(self) -> LazyIterator[Expression | CalculationUsage | ConstraintUsage]:
        """
        Implementation of ``expression`` defined in the KerML specification.

        **Specification**:

           The ``Expressions`` that are ``steps`` in the calculation of the
           ``result`` of this ``Function``.

           The set of expressions that represent computational steps or parts of
           a system of equations within the Function.

        See section
        `8.3.4.7.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
        of the KerML specification for more details.
        """

    @property
    def result(self) -> Feature | None:
        """
        Implementation of ``result`` defined in the KerML specification.

        **Specification**:

           The object or value that is the result of evaluating the Function.

           The ``result`` ``parameter`` of the ``Function``, which is owned by
           the ``Function`` via a ``ReturnParameterMembership``.

        See section
        `8.3.4.7.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
        of the KerML specification for more details.
        """

    @property
    def any_result(self) -> Feature | None:
        """``result`` that also considers specialized ``Functions``."""

    @property
    def result_expression(self) -> Expression | None:
        """
        The result expression of this ``Function`` owned by ``ResultExpressionMembership``.
        """

    @property
    def result_expression_member(self) -> ResultExpressionAccessor:
        """Syside specific accessor for manipulating ``result_expression``."""

class CaseDefinition(CalculationDefinition):
    """
    Implementation of ``CaseDefinition`` defined in the SysML specification.

    **Specification**:

       A ``CaseDefinition`` is a ``CalculationDefinition`` for a process,
       often involving collecting evidence or data, relative to a subject,
       possibly involving the collaboration of one or more other actors,
       producing a result that meets an objective.

    For language description, see section
    `7.22.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=169>`__
    of the SysML specification. For more details on the model, see section
    `8.3.22.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=399>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::CaseDefinition'

    STD: tuple[type[CaseDefinition], ...] = ...
    """
    All subtypes of ``CaseDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``CaseDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, CaseDefinition.STD):
            ...

    For type hints, instead use ``CaseDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> CaseDefinition.Std:
            ...

    Note that ``CaseDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "CaseDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = CaseDefinition
        """Type hint for all subtypes of ``CaseDefinition`` according to the specification"""

    @property
    def subject_parameter(self) -> Usage | None:
        """
        Implementation of ``subject_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``parameter`` of this ``CaseDefinition`` that represents its
           subject.

        See section
        `8.3.22.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=399>`__
        of the SysML specification for more details.
        """

    @property
    def actor_parameters(self) -> LazyIterator[PartUsage]:
        """
        Implementation of ``actor_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``parameters`` of this ``CaseDefinition`` that represent actors
           involved in the case.

        See section
        `8.3.22.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=399>`__
        of the SysML specification for more details.
        """

    @property
    def objective_requirement(self) -> RequirementUsage | None:
        """
        Implementation of ``objective_requirement`` defined in the SysML
        specification.

        **Specification**:

           The ``RequirementUsage`` representing the objective of this
           ``CaseDefinition``.

        See section
        `8.3.22.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=399>`__
        of the SysML specification for more details.
        """

class AnalysisCaseUsage(CaseUsage):
    """
    Implementation of ``AnalysisCaseUsage`` defined in the SysML
    specification.

    **Specification**:

       An ``AnalysisCaseUsage`` is a ``Usage`` of an
       ``AnalysisCaseDefinition``.

    For language description, see section
    `7.23.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=172>`__
    of the SysML specification. For more details on the model, see section
    `8.3.23.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=404>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::AnalysisCaseUsage'

    STD: tuple[type[AnalysisCaseUsage], ...] = ...
    """
    All subtypes of ``AnalysisCaseUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``AnalysisCaseUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, AnalysisCaseUsage.STD):
            ...

    For type hints, instead use ``AnalysisCaseUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> AnalysisCaseUsage.Std:
            ...

    Note that ``AnalysisCaseUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "AnalysisCaseUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = AnalysisCaseUsage
        """Type hint for all subtypes of ``AnalysisCaseUsage`` according to the specification"""

    @property
    def analysis_case_definition(self) -> AnalysisCaseDefinition | None:
        """
        Implementation of ``analysis_case_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``AnalysisCaseDefinition`` that is the ``definition`` of this
           ``AnalysisCaseUsage``.

        See section
        `8.3.23.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=404>`__
        of the SysML specification for more details.
        """

class AnalysisCaseDefinition(CaseDefinition):
    """
    Implementation of ``AnalysisCaseDefinition`` defined in the SysML
    specification.

    **Specification**:

       An ``AnalysisCaseDefinition`` is a ``CaseDefinition`` for the case of
       carrying out an analysis.

    For language description, see section
    `7.23.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=172>`__
    of the SysML specification. For more details on the model, see section
    `8.3.23.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=403>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::AnalysisCaseDefinition'

    STD: tuple[type[AnalysisCaseDefinition], ...] = ...
    """
    All subtypes of ``AnalysisCaseDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``AnalysisCaseDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, AnalysisCaseDefinition.STD):
            ...

    For type hints, instead use ``AnalysisCaseDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> AnalysisCaseDefinition.Std:
            ...

    Note that ``AnalysisCaseDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "AnalysisCaseDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = AnalysisCaseDefinition
        """Type hint for all subtypes of ``AnalysisCaseDefinition`` according to the specification"""

class VerificationCaseUsage(CaseUsage):
    """
    Implementation of ``VerificationCaseUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``VerificationCaseUsage`` is a Usage of a
       ``VerificationCaseDefinition``.

    For language description, see section
    `7.24.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=176>`__
    of the SysML specification. For more details on the model, see section
    `8.3.24.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=408>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::VerificationCaseUsage'

    STD: tuple[type[VerificationCaseUsage], ...] = ...
    """
    All subtypes of ``VerificationCaseUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``VerificationCaseUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, VerificationCaseUsage.STD):
            ...

    For type hints, instead use ``VerificationCaseUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> VerificationCaseUsage.Std:
            ...

    Note that ``VerificationCaseUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "VerificationCaseUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = VerificationCaseUsage
        """Type hint for all subtypes of ``VerificationCaseUsage`` according to the specification"""

    @property
    def verification_case_definition(self) -> VerificationCaseDefinition | None:
        """
        Implementation of ``verification_case_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``VerificationCase`` that is the ``definition`` of this
           ``VerificationCaseUsage``.

        See section
        `8.3.24.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=408>`__
        of the SysML specification for more details.
        """

    @property
    def verified_requirements(self) -> LazyIterator[RequirementUsage]:
        """
        Implementation of ``verified_requirement`` defined in the SysML
        specification.

        **Specification**:

           The ``RequirementUsages`` verified by this ``VerificationCaseUsage``,
           which are the ``verified_requirements`` of all
           ``RequirementVerificationMemberships`` of the
           ``objective_requirement``.

        See section
        `8.3.24.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=408>`__
        of the SysML specification for more details.
        """

class VerificationCaseDefinition(CaseDefinition):
    """
    Implementation of ``VerificationCaseDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``VerificationCaseDefinition`` is a ``CaseDefinition`` for the
       purpose of verification of the subject of the case against its
       requirements.

    For language description, see section
    `7.24.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=176>`__
    of the SysML specification. For more details on the model, see section
    `8.3.24.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=407>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::VerificationCaseDefinition'

    STD: tuple[type[VerificationCaseDefinition], ...] = ...
    """
    All subtypes of ``VerificationCaseDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``VerificationCaseDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, VerificationCaseDefinition.STD):
            ...

    For type hints, instead use ``VerificationCaseDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> VerificationCaseDefinition.Std:
            ...

    Note that ``VerificationCaseDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "VerificationCaseDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = VerificationCaseDefinition
        """Type hint for all subtypes of ``VerificationCaseDefinition`` according to the specification"""

    @property
    def verified_requirements(self) -> LazyIterator[RequirementUsage]:
        """
        Implementation of ``verified_requirement`` defined in the SysML
        specification.

        **Specification**:

           The ``RequirementUsages`` verified by this
           ``VerificationCaseDefinition``, which are the
           ``verified_requirements`` of all
           ``RequirementVerificationMemberships`` of the
           ``objective_requirement``.

        See section
        `8.3.24.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=408>`__
        of the SysML specification for more details.
        """

class UseCaseUsage(CaseUsage):
    """
    Implementation of ``UseCaseUsage`` defined in the SysML specification.

    **Specification**:

       A ``UseCaseUsage`` is a ``Usage`` of a ``UseCaseDefinition``.

    For language description, see section
    `7.25.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=179>`__
    of the SysML specification. For more details on the model, see section
    `8.3.25.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=412>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::UseCaseUsage'

    STD: tuple[type[UseCaseUsage], ...] = ...
    """
    All subtypes of ``UseCaseUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``UseCaseUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, UseCaseUsage.STD):
            ...

    For type hints, instead use ``UseCaseUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> UseCaseUsage.Std:
            ...

    Note that ``UseCaseUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "UseCaseUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = UseCaseUsage
        """Type hint for all subtypes of ``UseCaseUsage`` according to the specification"""

    @property
    def use_case_definition(self) -> UseCaseDefinition | None:
        """
        Implementation of ``use_case_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``UseCaseDefinition`` that is the ``definition`` of this
           ``UseCaseUsage``.

        See section
        `8.3.25.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=412>`__
        of the SysML specification for more details.
        """

    @property
    def included_use_cases(self) -> LazyIterator[UseCaseUsage]:
        """
        Implementation of ``included_use_case`` defined in the SysML
        specification.

        **Specification**:

           The ``UseCaseUsages`` that are included by this ``UseCaseUse``, which
           are the ``use_case_includeds`` of the ``IncludeUseCaseUsages`` owned
           by this ``UseCaseUsage``.

        See section
        `8.3.25.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=412>`__
        of the SysML specification for more details.
        """

class UseCaseDefinition(CaseDefinition):
    """
    Implementation of ``UseCaseDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``UseCaseDefinition`` is a ``CaseDefinition`` that specifies a set
       of actions performed by its subject, in interaction with one or more
       actors external to the subject. The objective is to yield an
       observable result that is of value to one or more of the actors.

    For language description, see section
    `7.25.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=179>`__
    of the SysML specification. For more details on the model, see section
    `8.3.25.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=411>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::UseCaseDefinition'

    STD: tuple[type[UseCaseDefinition], ...] = ...
    """
    All subtypes of ``UseCaseDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``UseCaseDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, UseCaseDefinition.STD):
            ...

    For type hints, instead use ``UseCaseDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> UseCaseDefinition.Std:
            ...

    Note that ``UseCaseDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "UseCaseDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = UseCaseDefinition
        """Type hint for all subtypes of ``UseCaseDefinition`` according to the specification"""

    @property
    def included_use_cases(self) -> LazyIterator[UseCaseUsage]:
        """
        Implementation of ``included_use_case`` defined in the SysML
        specification.

        **Specification**:

           The ``UseCaseUsages`` that are included by this
           ``UseCaseDefinition``, which are the ``use_case_includeds`` of the
           ``IncludeUseCaseUsages`` owned by this ``UseCaseDefinition``.

        See section
        `8.3.25.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=411>`__
        of the SysML specification for more details.
        """

class ViewUsage(PartUsage):
    """
    Implementation of ``ViewUsage`` defined in the SysML specification.

    **Specification**:

       A ``ViewUsage`` is a usage of a ``ViewDefinition`` to specify the
       generation of a view of the ``members`` of a collection of
       ``exposed_namespaces``. The ``ViewUsage`` can satisfy more
       ``viewpoints`` than its definition, and it can specialize the
       ``view_rendering`` specified by its definition.

    For language description, see section
    `7.26.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=184>`__
    of the SysML specification. For more details on the model, see section
    `8.3.26.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=423>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ViewUsage'

    STD: tuple[type[ViewUsage], ...] = ...
    """
    All subtypes of ``ViewUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ViewUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ViewUsage.STD):
            ...

    For type hints, instead use ``ViewUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> ViewUsage.Std:
            ...

    Note that ``ViewUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ViewUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ViewUsage
        """Type hint for all subtypes of ``ViewUsage`` according to the specification"""

    @property
    def view_definition(self) -> ViewDefinition | None:
        """
        Implementation of ``view_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``ViewDefinition`` that is the ``definition`` of this
           ``ViewUsage``.

        See section
        `8.3.26.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=423>`__
        of the SysML specification for more details.
        """

    @property
    def exposed_elements(self) -> LazyImportsIterator[Element]:
        """
        Implementation of ``exposed_element`` defined in the SysML
        specification.

        **Specification**:

           The ``Elements`` that are exposed by this ``ViewUsage``, which are
           those ``member_elements`` of the imported ``Memberships`` from all
           the ``Expose`` ``Relationships`` that meet all the owned and
           inherited ``view_conditions``.

        See section
        `8.3.26.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=423>`__
        of the SysML specification for more details.
        """

    @property
    def satisfied_viewpoints(self) -> LazyIterator[ViewpointUsage]:
        """
        Implementation of ``satisfied_viewpoint`` defined in the SysML
        specification.

        **Specification**:

           The ``nested_requirements`` of this ``ViewUsage`` that are
           ``ViewpointUsages`` for (additional) viewpoints satisfied by the
           ``ViewUsage``.

        See section
        `8.3.26.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=423>`__
        of the SysML specification for more details.
        """

    @property
    def view_rendering(self) -> RenderingUsage | None:
        """
        Implementation of ``view_rendering`` defined in the SysML specification.

        **Specification**:

           The ``RenderingUsage`` to be used to render views defined by this
           ``ViewUsage``, which is the ``referenced_rendering`` of the
           ``ViewRenderingMembership`` of the ``ViewUsage``.

        See section
        `8.3.26.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=423>`__
        of the SysML specification for more details.
        """

    @property
    def owned_view_conditions(self) -> LazyIterator[ElementFilterMembership]:
        """The ``view_conditions`` owned by this ``ViewUsage``."""

    @property
    def view_conditions(self) -> LazyIterator[ElementFilterMembership]:
        """
        Implementation of ``view_condition`` defined in the SysML specification.

        **Specification**:

           The ``Expressions`` related to this ``ViewUsage`` by
           ``ElementFilterMemberships``, which specify conditions on
           ``Elements`` to be rendered in a view.

        See section
        `8.3.26.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=423>`__
        of the SysML specification for more details.
        """

class ViewDefinition(PartDefinition):
    """
    Implementation of ``ViewDefinition`` defined in the SysML specification.

    **Specification**:

       A ``ViewDefinition`` is a ``PartDefinition`` that specifies how a
       view artifact is constructed to satisfy a ``viewpoint``. It specifies
       a ``view_conditions`` to define the model content to be presented and
       a ``view_rendering`` to define how the model content is presented.

    For language description, see section
    `7.26.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=184>`__
    of the SysML specification. For more details on the model, see section
    `8.3.26.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=419>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ViewDefinition'

    STD: tuple[type[ViewDefinition], ...] = ...
    """
    All subtypes of ``ViewDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ViewDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ViewDefinition.STD):
            ...

    For type hints, instead use ``ViewDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> ViewDefinition.Std:
            ...

    Note that ``ViewDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ViewDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ViewDefinition
        """Type hint for all subtypes of ``ViewDefinition`` according to the specification"""

    @property
    def views(self) -> LazyIterator[ViewUsage]:
        """
        Implementation of ``view`` defined in the SysML specification.

        **Specification**:

           The ``usages`` of this ``ViewDefinition`` that are ``ViewUsages``.

        See section
        `8.3.26.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=419>`__
        of the SysML specification for more details.
        """

    @property
    def satisfied_viewpoints(self) -> LazyIterator[ViewpointUsage]:
        """
        Implementation of ``satisfied_viewpoint`` defined in the SysML
        specification.

        **Specification**:

           The composite ``owned_requirements`` of this ``ViewDefinition`` that
           are ``ViewpointUsages`` for viewpoints satisfied by the
           ``ViewDefinition``.

        See section
        `8.3.26.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=419>`__
        of the SysML specification for more details.
        """

    @property
    def view_rendering(self) -> RenderingUsage | None:
        """
        Implementation of ``view_rendering`` defined in the SysML specification.

        **Specification**:

           The ``RenderingUsage`` to be used to render views defined by this
           ``ViewDefinition``, which is the ``referenced_rendering`` of the
           ``ViewRenderingMembership`` of the ``ViewDefinition``.

        See section
        `8.3.26.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=419>`__
        of the SysML specification for more details.
        """

    @property
    def owned_view_conditions(self) -> LazyIterator[ElementFilterMembership]:
        """The ``view_conditions`` owned by this ``ViewDefinition``."""

    @property
    def view_conditions(self) -> LazyIterator[ElementFilterMembership]:
        """
        Implementation of ``view_condition`` defined in the SysML specification.

        **Specification**:

           The ``Expressions`` related to this ``ViewDefinition`` by
           ``ElementFilterMemberships``, which specify conditions on
           ``Elements`` to be rendered in a view.

        See section
        `8.3.26.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=419>`__
        of the SysML specification for more details.
        """

class ViewpointUsage(RequirementUsage):
    """
    Implementation of ``ViewpointUsage`` defined in the SysML specification.

    **Specification**:

       A ``ViewpointUsage`` is a ``Usage`` of a ``ViewpointDefinition``.

    For language description, see section
    `7.26.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=185>`__
    of the SysML specification. For more details on the model, see section
    `8.3.26.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=421>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ViewpointUsage'

    STD: tuple[type[ViewpointUsage], ...] = ...
    """
    All subtypes of ``ViewpointUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ViewpointUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ViewpointUsage.STD):
            ...

    For type hints, instead use ``ViewpointUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> ViewpointUsage.Std:
            ...

    Note that ``ViewpointUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ViewpointUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ViewpointUsage
        """Type hint for all subtypes of ``ViewpointUsage`` according to the specification"""

    @property
    def viewpoint_definition(self) -> ViewpointDefinition | None:
        """
        Implementation of ``viewpoint_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``ViewpointDefinition`` that is the ``definition`` of this
           ``ViewpointUsage``.

        See section
        `8.3.26.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=421>`__
        of the SysML specification for more details.
        """

    @property
    def viewpoint_stakeholders(self) -> LazyIterator[PartUsage]:
        """
        Implementation of ``viewpoint_stakeholder`` defined in the SysML
        specification.

        **Specification**:

           The ``PartUsages`` that identify the stakeholders with concerns
           framed by this ``ViewpointUsage``, which are the owned and inherited
           ``stakeholder_parameters`` of the ``framed_concerns`` of this
           ``ViewpointUsage``.

        See section
        `8.3.26.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=421>`__
        of the SysML specification for more details.
        """

class ViewpointDefinition(RequirementDefinition):
    """
    Implementation of ``ViewpointDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``ViewpointDefinition`` is a ``RequirementDefinition`` that
       specifies one or more stakeholder concerns that are to be satisfied
       by creating a view of a model.

    For language description, see section
    `7.26.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=185>`__
    of the SysML specification. For more details on the model, see section
    `8.3.26.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=420>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ViewpointDefinition'

    STD: tuple[type[ViewpointDefinition], ...] = ...
    """
    All subtypes of ``ViewpointDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ViewpointDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ViewpointDefinition.STD):
            ...

    For type hints, instead use ``ViewpointDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> ViewpointDefinition.Std:
            ...

    Note that ``ViewpointDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ViewpointDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ViewpointDefinition
        """Type hint for all subtypes of ``ViewpointDefinition`` according to the specification"""

    @property
    def viewpoint_stakeholders(self) -> LazyIterator[PartUsage]:
        """
        Implementation of ``viewpoint_stakeholder`` defined in the SysML
        specification.

        **Specification**:

           The ``PartUsages`` that identify the stakeholders with concerns
           framed by this ``ViewpointDefinition``, which are the owned and
           inherited ``stakeholder_parameters`` of the ``framed_concerns`` of
           this ``ViewpointDefinition``.

        See section
        `8.3.26.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=420>`__
        of the SysML specification for more details.
        """

class RenderingUsage(PartUsage):
    """
    Implementation of ``RenderingUsage`` defined in the SysML specification.

    **Specification**:

       A ``RenderingUsage`` is the usage of a ``RenderingDefinition`` to
       specify the rendering of a specific model view to produce a physical
       view artifact.

    For language description, see section
    `7.26.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=186>`__
    of the SysML specification. For more details on the model, see section
    `8.3.26.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=418>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::RenderingUsage'

    STD: tuple[type[RenderingUsage], ...] = ...
    """
    All subtypes of ``RenderingUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``RenderingUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, RenderingUsage.STD):
            ...

    For type hints, instead use ``RenderingUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> RenderingUsage.Std:
            ...

    Note that ``RenderingUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "RenderingUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = RenderingUsage
        """Type hint for all subtypes of ``RenderingUsage`` according to the specification"""

    @property
    def rendering_definition(self) -> RenderingDefinition | None:
        """
        Implementation of ``rendering_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``RenderingDefinition`` that is the ``definition`` of this
           ``RenderingUsage``.

        See section
        `8.3.26.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=418>`__
        of the SysML specification for more details.
        """

class RenderingDefinition(PartDefinition):
    """
    Implementation of ``RenderingDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``RenderingDefinition`` is a ``PartDefinition`` that defines a
       specific rendering of the content of a model view (e.g., symbols,
       style, layout, etc.).

    For language description, see section
    `7.26.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=186>`__
    of the SysML specification. For more details on the model, see section
    `8.3.26.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=417>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::RenderingDefinition'

    STD: tuple[type[RenderingDefinition], ...] = ...
    """
    All subtypes of ``RenderingDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``RenderingDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, RenderingDefinition.STD):
            ...

    For type hints, instead use ``RenderingDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> RenderingDefinition.Std:
            ...

    Note that ``RenderingDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "RenderingDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = RenderingDefinition
        """Type hint for all subtypes of ``RenderingDefinition`` according to the specification"""

    @property
    def renderings(self) -> LazyIterator[RenderingUsage]:
        """
        Implementation of ``rendering`` defined in the SysML specification.

        **Specification**:

           The ``usages`` of a ``RenderingDefinition`` that are
           ``RenderingUsages``.

        See section
        `8.3.26.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=417>`__
        of the SysML specification for more details.
        """

class MetadataUsage(ItemUsage):
    """
    Implementation of ``MetadataUsage`` defined in the SysML specification.

    **Specification**:

       A ``MetadataUsage`` is a ``Usage`` and a ``MetadataFeature``, used to
       annotate other ``Elements`` in a system model with metadata. As a
       ``MetadataFeature``, its type must be a ``Metaclass``, which will
       nominally be a ``MetadataDefinition``. However, any kernel
       ``Metaclass`` is also allowed, to permit use of ``Metaclasses`` from
       the Kernel Model Libraries.

    For language description, see section
    `7.27.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=191>`__
    of the SysML specification. For more details on the model, see section
    `8.3.27.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=426>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::MetadataUsage'

    STD: tuple[type[MetadataUsage], ...] = ...
    """
    All subtypes of ``MetadataUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``MetadataUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, MetadataUsage.STD):
            ...

    For type hints, instead use ``MetadataUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> MetadataUsage.Std:
            ...

    Note that ``MetadataUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "MetadataUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = MetadataUsage
        """Type hint for all subtypes of ``MetadataUsage`` according to the specification"""

    @property
    def metadata_definition(self) -> MetadataDefinition | None:
        """
        Implementation of ``metadata_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``MetadataDefinition`` that is the ``definition`` of this
           ``MetadataUsage``.

        See section
        `8.3.27.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=426>`__
        of the SysML specification for more details.
        """

    @property
    def annotations(self) -> ContainerView[Annotation]:
        """
        Implementation of ``annotation`` defined in the KerML specification.

        **Specification**:

           The ``Annotations`` that relate this ``AnnotatingElement`` to its
           ``annotated_elements``. This includes the
           ``owning_annotating_relationship`` (if any) followed by all the
           ``owned_annotating_relationships``.

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def annotated_elements(self) -> ContainerView[Element]:
        """
        Implementation of ``annotated_element`` defined in the KerML
        specification.

        **Specification**:

           The ``Elements`` that are annotated by this ``AnnotatingElement``. If
           ``annotation`` is not empty, these are the ``annotated_elements`` of
           the ``annotations``. If ``annotation`` is empty, then it is the
           ``owning_namespace`` of the ``AnnotatingElement``.

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def owned_annotating_relationships(self) -> ContainerView[Annotation]:
        """
        Implementation of ``owned_annotating_relationship`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``AnnotatingElement`` that are
           ``Annotations``, for which this ``AnnotatingElement`` is the
           ``annotating_element``.

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=144>`__
        of the KerML specification for more details.
        """

    @property
    def owning_annotating_relationship(self) -> Annotation | None:
        """
        Implementation of ``owning_annotating_relationship`` defined in the
        KerML specification.

        **Specification**:

           The ``owning_relationship`` of this ``AnnotatingRelationship``, if it
           is an ``Annotation``

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=144>`__
        of the KerML specification for more details.
        """

    @property
    def about(self) -> Annotations:
        """Container for owned annotations."""

    @property
    def metaclass(self) -> MetadataDefinition | Metaclass | None:
        """
        Implementation of ``metaclass`` defined in the KerML specification.

        **Specification**:

           The ``type`` of this ``MetadataFeature``, which must be a
           ``Metaclass``.

        See section
        `8.3.4.12.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=257>`__
        of the KerML specification for more details.
        """

class InterfaceDefinition(ConnectionDefinition):
    """
    Implementation of ``InterfaceDefinition`` defined in the SysML
    specification.

    **Specification**:

       An ``InterfaceDefinition`` is a ``ConnectionDefinition`` all of whose
       ends are ``PortUsages``, defining an interface between elements that
       interact through such ports.

    For language description, see section
    `7.14.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=109>`__
    of the SysML specification. For more details on the model, see section
    `8.3.14.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=332>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::InterfaceDefinition'

    STD: tuple[type[InterfaceDefinition], ...] = ...
    """
    All subtypes of ``InterfaceDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``InterfaceDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, InterfaceDefinition.STD):
            ...

    For type hints, instead use ``InterfaceDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> InterfaceDefinition.Std:
            ...

    Note that ``InterfaceDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "InterfaceDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = InterfaceDefinition
        """Type hint for all subtypes of ``InterfaceDefinition`` according to the specification"""

    @property
    def interface_ends(self) -> LazyIterator[PortUsage]:
        """
        Implementation of ``interface_end`` defined in the SysML specification.

        **Specification**:

           The ``PortUsages`` that are the ``connection_ends`` of this
           ``InterfaceDefinition``.

        See section
        `8.3.14.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=333>`__
        of the SysML specification for more details.
        """

class EventOccurrenceUsage(OccurrenceUsage):
    """
    Implementation of ``EventOccurrenceUsage`` defined in the SysML
    specification.

    **Specification**:

       An ``EventOccurrenceUsage`` is an ``OccurrenceUsage`` that represents
       another ``OccurrenceUsage`` occurring as a ``suboccurrence`` of the
       containing occurrence of the ``EventOccurrenceUsage``. Unless it is
       the ``EventOccurrenceUsage`` itself, the referenced
       ``OccurrenceUsage`` is related to the ``EventOccurrenceUsage`` by a
       ``ReferenceSubsetting`` ``Relationship``.

       If the ``EventOccurrenceUsage`` is owned by an
       ``OccurrenceDefinition`` or ``OccurrenceUsage``, then it also subsets
       the ``time_enclosed_occurrences`` property of the ``Class``
       ``Occurrence`` from the Kernel Semantic Library model
       ``Occurrences``.

    For language description, see section
    `7.9.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=87>`__
    of the SysML specification. For more details on the model, see section
    `8.3.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=314>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::EventOccurrenceUsage'

    STD: tuple[Union[type[EventOccurrenceUsage], type[ExhibitStateUsage], type[IncludeUseCaseUsage], type[PerformActionUsage]], ...] = ...
    """
    All subtypes of ``EventOccurrenceUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``EventOccurrenceUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, EventOccurrenceUsage.STD):
            ...

    For type hints, instead use ``EventOccurrenceUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> EventOccurrenceUsage.Std:
            ...

    Note that ``EventOccurrenceUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "EventOccurrenceUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[EventOccurrenceUsage, ExhibitStateUsage, IncludeUseCaseUsage, PerformActionUsage]
        """Type hint for all subtypes of ``EventOccurrenceUsage`` according to the specification"""

    @property
    def event_occurrence(self) -> OccurrenceUsage | ConnectionUsage | FlowUsage | None:
        """
        Implementation of ``event_occurrence`` defined in the SysML
        specification.

        **Specification**:

           The ``OccurrenceUsage`` referenced as an event by this
           ``EventOccurrenceUsage``. It is the ``reference_feature`` of the
           ``owned_reference_subsetting`` for the ``EventOccurrenceUsage``, if
           there is one, and, otherwise, the ``EventOccurrenceUsage`` itself.

        See section
        `8.3.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=314>`__
        of the SysML specification for more details.
        """

class MetadataDefinition(ItemDefinition):
    """
    Implementation of ``MetadataDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``MetadataDefinition`` is an ``ItemDefinition`` that is also a
       ``Metaclass``.

    For language description, see section
    `7.27.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=191>`__
    of the SysML specification. For more details on the model, see section
    `8.3.27.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=425>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::MetadataDefinition'

    STD: tuple[type[MetadataDefinition], ...] = ...
    """
    All subtypes of ``MetadataDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``MetadataDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, MetadataDefinition.STD):
            ...

    For type hints, instead use ``MetadataDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> MetadataDefinition.Std:
            ...

    Note that ``MetadataDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "MetadataDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = MetadataDefinition
        """Type hint for all subtypes of ``MetadataDefinition`` according to the specification"""

class BindingConnectorAsUsage(ConnectorAsUsage):
    """
    Implementation of ``BindingConnectorAsUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``BindingConnectorAsUsage`` is both a ``BindingConnector`` and a
       ``ConnectorAsUsage``.

    For language description, see section
    `7.13.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=104>`__
    of the SysML specification. For more details on the model, see section
    `8.3.13.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=329>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::BindingConnectorAsUsage'

    STD: tuple[type[BindingConnectorAsUsage], ...] = ...
    """
    All subtypes of ``BindingConnectorAsUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``BindingConnectorAsUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, BindingConnectorAsUsage.STD):
            ...

    For type hints, instead use ``BindingConnectorAsUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> BindingConnectorAsUsage.Std:
            ...

    Note that ``BindingConnectorAsUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "BindingConnectorAsUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = BindingConnectorAsUsage
        """Type hint for all subtypes of ``BindingConnectorAsUsage`` according to the specification"""

class SuccessionFlowUsage(FlowUsage):
    """
    Implementation of ``SuccessionFlowUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``SuccessionFlowUsage`` is a ``FlowUsage`` that is also a KerML
       ``SuccessionFlow``.

    For language description, see section
    `7.16.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=115>`__
    of the SysML specification. For more details on the model, see section
    `8.3.16.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=338>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::SuccessionFlowUsage'

    STD: tuple[type[SuccessionFlowUsage], ...] = ...
    """
    All subtypes of ``SuccessionFlowUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``SuccessionFlowUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, SuccessionFlowUsage.STD):
            ...

    For type hints, instead use ``SuccessionFlowUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> SuccessionFlowUsage.Std:
            ...

    Note that ``SuccessionFlowUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "SuccessionFlowUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = SuccessionFlowUsage
        """Type hint for all subtypes of ``SuccessionFlowUsage`` according to the specification"""

    @property
    def transition_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        A ``Step`` that is typed by the ``Behavior``
        ``TransitionPerformances::TransitionPerformance`` (from the Kernel
        Semantic Library) that has this ``Succession`` as its
        ``transition_link``.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def trigger_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        ``Steps`` that map incoming events to the timing of occurrences of the
        ``transition_step``. The values of ``trigger_step`` subset the list of
        acceptable events to be received by a ``Behavior`` or the object that
        performs it.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def trigger_steps(self) -> list[Step | ActionUsage | ConstraintUsage | Flow | FlowUsage]:
        """
        ``Steps`` that map incoming events to the timing of occurrences of the
        ``transition_step``. The values of ``trigger_step`` subset the list of
        acceptable events to be received by a ``Behavior`` or the object that
        performs it.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def effect_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        ``Steps`` that represent occurrences that are side effects of the
        ``transition_step`` occurring.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def effect_steps(self) -> list[Step | ActionUsage | ConstraintUsage | Flow | FlowUsage]:
        """
        ``Steps`` that represent occurrences that are side effects of the
        ``transition_step`` occurring.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def guard_expression(self) -> list[Expression]:
        """
        ``Expressions`` that must evaluate to true before the
        ``transition_step`` can occur.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

class SuccessionAsUsage(ConnectorAsUsage):
    """
    Implementation of ``SuccessionAsUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``SuccessionAsUsage`` is both a ``ConnectorAsUsage`` and a
       ``Succession``.

    For language description, see section
    `7.13.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=105>`__
    of the SysML specification. For more details on the model, see section
    `8.3.13.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=331>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::SuccessionAsUsage'

    STD: tuple[type[SuccessionAsUsage], ...] = ...
    """
    All subtypes of ``SuccessionAsUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``SuccessionAsUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, SuccessionAsUsage.STD):
            ...

    For type hints, instead use ``SuccessionAsUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> SuccessionAsUsage.Std:
            ...

    Note that ``SuccessionAsUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "SuccessionAsUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = SuccessionAsUsage
        """Type hint for all subtypes of ``SuccessionAsUsage`` according to the specification"""

    @property
    def transition_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        A ``Step`` that is typed by the ``Behavior``
        ``TransitionPerformances::TransitionPerformance`` (from the Kernel
        Semantic Library) that has this ``Succession`` as its
        ``transition_link``.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def trigger_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        ``Steps`` that map incoming events to the timing of occurrences of the
        ``transition_step``. The values of ``trigger_step`` subset the list of
        acceptable events to be received by a ``Behavior`` or the object that
        performs it.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def trigger_steps(self) -> list[Step | ActionUsage | ConstraintUsage | Flow | FlowUsage]:
        """
        ``Steps`` that map incoming events to the timing of occurrences of the
        ``transition_step``. The values of ``trigger_step`` subset the list of
        acceptable events to be received by a ``Behavior`` or the object that
        performs it.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def effect_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        ``Steps`` that represent occurrences that are side effects of the
        ``transition_step`` occurring.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def effect_steps(self) -> list[Step | ActionUsage | ConstraintUsage | Flow | FlowUsage]:
        """
        ``Steps`` that represent occurrences that are side effects of the
        ``transition_step`` occurring.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def guard_expression(self) -> list[Expression]:
        """
        ``Expressions`` that must evaluate to true before the
        ``transition_step`` can occur.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

class FlowDefinition(ActionDefinition):
    """
    Implementation of ``FlowDefinition`` defined in the SysML specification.

    **Specification**:

       A ``FlowDefinition`` is an ``ActionDefinition`` that is also an
       ``Interaction`` (which is both a KerML ``Behavior`` and
       ``Association``), representing flows between ``Usages``.

    For language description, see section
    `7.16.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=115>`__
    of the SysML specification. For more details on the model, see section
    `8.3.16.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=336>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::FlowDefinition'

    STD: tuple[type[FlowDefinition], ...] = ...
    """
    All subtypes of ``FlowDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``FlowDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, FlowDefinition.STD):
            ...

    For type hints, instead use ``FlowDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> FlowDefinition.Std:
            ...

    Note that ``FlowDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "FlowDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = FlowDefinition
        """Type hint for all subtypes of ``FlowDefinition`` according to the specification"""

    @property
    def flow_ends(self) -> LazyIterator[tuple[FeatureMembership, Usage]]:
        """
        Implementation of ``flow_end`` defined in the SysML specification.

        **Specification**:

           The ``Usages`` that define the things related by the
           ``FlowDefinition``.

        See section
        `8.3.16.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=336>`__
        of the SysML specification for more details.
        """

    @property
    def source(self) -> Feature | None:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def sources(self) -> list[Feature]:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def owning_related_element(self) -> None:
        """
        Implementation of ``owning_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_element of this Relationship that owns the Relationship,
           if any.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def is_implied(self) -> bool:
        """
        Implementation of ``is_implied`` defined in the KerML specification.

        **Specification**:

           Whether this Relationship was generated by tooling to meet semantic
           rules, rather than being directly created by a modeler.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @is_implied.setter
    def is_implied(self, arg: bool, /) -> None: ...

    @property
    def related_elements(self) -> LazyIterator[Feature]:
        """
        Implementation of ``related_element`` defined in the KerML
        specification.

        **Specification**:

           The Elements that are related by this Relationship, derived as the
           union of the ``source`` and ``target`` Elements of the Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def targets(self) -> LazyIterator[Feature]:
        """
        Implementation of ``target`` defined in the KerML specification.

        **Specification**:

           The ``related_elements`` to which this Relationship is considered to
           be directed.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def owned_related_elements(self) -> LazyIterator[Feature]:
        """
        Implementation of ``owned_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_elements of this Relationship that are owned by the
           Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def source_type(self) -> Type | None:
        """
        Implementation of ``source_type`` defined in the KerML specification.

        **Specification**:

           The source ``related_type`` for this ``Association``. It is the first
           ``related_type`` of the ``Association``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=208>`__
        of the KerML specification for more details.
        """

    @property
    def related_types(self) -> LazyIterator[Type]:
        """
        Implementation of ``related_type`` defined in the KerML specification.

        **Specification**:

           The ``types`` of the ``association_ends`` of the ``Association``,
           which are the ``related_elements`` of the ``Association`` considered
           as a ``Relationship``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=208>`__
        of the KerML specification for more details.
        """

    @property
    def target_types(self) -> LazyIterator[Type]:
        """
        Implementation of ``target_type`` defined in the KerML specification.

        **Specification**:

           The target ``related_types`` for this ``Association``. This includes
           all the ``related_types`` other than the ``source_type``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=208>`__
        of the KerML specification for more details.
        """

    @property
    def association_ends(self) -> LazyIterator[Feature]:
        """
        Implementation of ``association_end`` defined in the KerML
        specification.

        **Specification**:

           The ``features`` of the ``Association`` that identify the things that
           can be related by it. A concrete ``Association`` must have at least
           two ``association_ends``. When it has exactly two, the
           ``Association`` is called a *binary* ``Association``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=208>`__
        of the KerML specification for more details.
        """

class RequirementConstraintMembership(FeatureMembership):
    """
    Implementation of ``RequirementConstraintMembership`` defined in the
    SysML specification.

    **Specification**:

       A ``RequirementConstraintMembership`` is a ``FeatureMembership`` for
       an assumed or required ``ConstraintUsage`` of a
       ``RequirementDefinition`` or ``RequirementUsage``.

    For language description, see section
    `7.21.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=165>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=388>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::RequirementConstraintMembership'

    STD: tuple[type[RequirementConstraintMembership], ...] = ...
    """
    All subtypes of ``RequirementConstraintMembership`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``RequirementConstraintMembership.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, RequirementConstraintMembership.STD):
            ...

    For type hints, instead use ``RequirementConstraintMembership.Std``:

    .. code-block:: python

        def function(element: Element) -> RequirementConstraintMembership.Std:
            ...

    Note that ``RequirementConstraintMembership.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "RequirementConstraintMembership.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = RequirementConstraintMembership
        """Type hint for all subtypes of ``RequirementConstraintMembership`` according to the specification"""

    @property
    def kind(self) -> RequirementConstraintKind:
        """
        Implementation of ``kind`` defined in the SysML specification.

        **Specification**:

           Whether the ``RequirementConstraintMembership`` is for an assumed or
           required ``ConstraintUsage``.

        See section
        `8.3.21.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=388>`__
        of the SysML specification for more details.


        Note that setting ``kind`` on ``RequirementConstraintMembership`` subtypes will throw ``TypeError``.
        """

    @kind.setter
    def kind(self, arg: RequirementConstraintKind, /) -> None: ...

    def try_set_kind(self, arg: RequirementConstraintKind, /) -> bool:
        """
        An alternative to ``kind`` that will return ``False`` if this ``RequirementConstraintMembership`` does not allow modifying its ``kind`` rather than raising ``TypeError``.
        """

    @property
    def owned_constraint(self) -> ConstraintUsage | None:
        """
        Implementation of ``owned_constraint`` defined in the SysML
        specification.

        **Specification**:

           The ``ConstraintUsage`` that is the ``owned_member_feature`` of this
           ``RequirementConstraintMembership``.

        See section
        `8.3.21.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=388>`__
        of the SysML specification for more details.
        """

    @property
    def referenced_constraint(self) -> ConstraintUsage | None:
        """
        Implementation of ``referenced_constraint`` defined in the SysML
        specification.

        **Specification**:

           The ``ConstraintUsage`` that is referenced through this
           ``RequirementConstraintMembership``. It is the ``referenced_feature``
           of the ``owned_reference_subsetting`` of the ``owned_constraint``, if
           there is one, and, otherwise, the ``owned_constraint`` itself.

        See section
        `8.3.21.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=388>`__
        of the SysML specification for more details.
        """

class RequirementVerificationMembership(RequirementConstraintMembership):
    """
    Implementation of ``RequirementVerificationMembership`` defined in the
    SysML specification.

    **Specification**:

       A ``RequirementVerificationMembership`` is a
       ``RequirementConstraintMembership`` used in the objective of a
       ``VerificationCase`` to identify a ``RequirementUsage`` that is
       verified by the ``VerificationCase``.

    For language description, see section
    `7.24.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=176>`__
    of the SysML specification. For more details on the model, see section
    `8.3.24.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=407>`__
    of the SysML specification.
    """

    __cpp_name__: str = ...

    STD: tuple[type[RequirementVerificationMembership], ...] = ...
    """
    All subtypes of ``RequirementVerificationMembership`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``RequirementVerificationMembership.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, RequirementVerificationMembership.STD):
            ...

    For type hints, instead use ``RequirementVerificationMembership.Std``:

    .. code-block:: python

        def function(element: Element) -> RequirementVerificationMembership.Std:
            ...

    Note that ``RequirementVerificationMembership.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "RequirementVerificationMembership.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = RequirementVerificationMembership
        """Type hint for all subtypes of ``RequirementVerificationMembership`` according to the specification"""

    @property
    def owned_requirement(self) -> RequirementUsage | None:
        """
        Implementation of ``owned_requirement`` defined in the SysML
        specification.

        **Specification**:

           The owned ``RequirementUsage`` that acts as the ``owned_constraint``
           for this ``RequirementVerificationMembership``. This will either be
           the ``verified_requirement``, or it will subset the
           ``verified_requirement``.

        See section
        `8.3.24.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=407>`__
        of the SysML specification for more details.
        """

    @property
    def verified_requirement(self) -> RequirementUsage | None:
        """
        Implementation of ``verified_requirement`` defined in the SysML
        specification.

        **Specification**:

           The ``RequirementUsage`` that is identified as being verified. It is
           the ``referenced_constraint`` of the
           ``RequirementVerificationMembership`` considered as a
           ``RequirementConstraintMembership``, which must be a
           ``RequirementUsage``.

        See section
        `8.3.24.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=407>`__
        of the SysML specification for more details.
        """

class FramedConcernMembership(RequirementConstraintMembership):
    """
    Implementation of ``FramedConcernMembership`` defined in the SysML
    specification.

    **Specification**:

       A ``FramedConcernMembership`` is a
       ``RequirementConstraintMembership`` for a framed ``ConcernUsage`` of
       a ``RequirementDefinition`` or ``RequirementUsage``.

    For language description, see section
    `7.21.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=167>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=387>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::FramedConcernMembership'

    STD: tuple[type[FramedConcernMembership], ...] = ...
    """
    All subtypes of ``FramedConcernMembership`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``FramedConcernMembership.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, FramedConcernMembership.STD):
            ...

    For type hints, instead use ``FramedConcernMembership.Std``:

    .. code-block:: python

        def function(element: Element) -> FramedConcernMembership.Std:
            ...

    Note that ``FramedConcernMembership.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "FramedConcernMembership.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = FramedConcernMembership
        """Type hint for all subtypes of ``FramedConcernMembership`` according to the specification"""

    @property
    def owned_concern(self) -> ConcernUsage | None:
        """
        Implementation of ``owned_concern`` defined in the SysML specification.

        **Specification**:

           The ``ConcernUsage`` that is the ``owned_constraint`` of this
           ``FramedConcernMembership``.

        See section
        `8.3.21.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=387>`__
        of the SysML specification for more details.
        """

    @property
    def referenced_concern(self) -> ConcernUsage | None:
        """
        Implementation of ``referenced_concern`` defined in the SysML
        specification.

        **Specification**:

           The ``ConcernUsage`` that is referenced through this
           ``FramedConcernMembership``. It is the ``referenced_constraint`` of
           the ``FramedConcernMembership`` considered as a
           ``RequirementConstraintMembership``, which must be a
           ``ConcernUsage``.

        See section
        `8.3.21.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=387>`__
        of the SysML specification for more details.
        """

class SubjectMembership(ParameterMembership):
    """
    Implementation of ``SubjectMembership`` defined in the SysML
    specification.

    **Specification**:

       A ``SubjectMembership`` is a ``ParameterMembership`` that indicates
       that its ``owned_subject_parameter`` is the subject of its
       ``owning_type``. The ``owning_type`` of a ``SubjectMembership`` must
       be a ``RequirementDefinition``, ``RequirementUsage``,
       ``CaseDefinition``, or ``CaseUsage``.

    For language description, see section
    `7.21.1 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=161>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=396>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::SubjectMembership'

    STD: tuple[type[SubjectMembership], ...] = ...
    """
    All subtypes of ``SubjectMembership`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``SubjectMembership.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, SubjectMembership.STD):
            ...

    For type hints, instead use ``SubjectMembership.Std``:

    .. code-block:: python

        def function(element: Element) -> SubjectMembership.Std:
            ...

    Note that ``SubjectMembership.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "SubjectMembership.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = SubjectMembership
        """Type hint for all subtypes of ``SubjectMembership`` according to the specification"""

    @property
    def owned_subject_parameter(self) -> ReferenceUsage | None:
        """
        Implementation of ``owned_subject_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``UsageownedMemberParameter`` of this ``SubjectMembership``.

        See section
        `8.3.21.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=396>`__
        of the SysML specification for more details.
        """

class ActorMembership(ParameterMembership):
    """
    Implementation of ``ActorMembership`` defined in the SysML
    specification.

    **Specification**:

       An ``ActorMembership`` is a ``ParameterMembership`` that identifies a
       ``PartUsage`` as an *actor* ``parameter``, which specifies a role
       played by an external entity in interaction with the ``owning_type``
       of the ``ActorMembership``.

    For language description, see section
    `7.21.1 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=161>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=385>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ActorMembership'

    STD: tuple[type[ActorMembership], ...] = ...
    """
    All subtypes of ``ActorMembership`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ActorMembership.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ActorMembership.STD):
            ...

    For type hints, instead use ``ActorMembership.Std``:

    .. code-block:: python

        def function(element: Element) -> ActorMembership.Std:
            ...

    Note that ``ActorMembership.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ActorMembership.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ActorMembership
        """Type hint for all subtypes of ``ActorMembership`` according to the specification"""

    @property
    def owned_actor_parameter(self) -> PartUsage | None:
        """
        Implementation of ``owned_actor_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``PartUsage`` specifying the actor.

        See section
        `8.3.21.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=385>`__
        of the SysML specification for more details.
        """

class StakeholderMembership(ParameterMembership):
    """
    Implementation of ``StakeholderMembership`` defined in the SysML
    specification.

    **Specification**:

       A ``StakeholderMembership`` is a ``ParameterMembership`` that
       identifies a ``PartUsage`` as a ``stakeholder_parameter`` of a
       ``RequirementDefinition`` or ``RequirementUsage``, which specifies a
       role played by an entity with concerns framed by the ``owning_type``.

    For language description, see section
    `7.21.1 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=161>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=397>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::StakeholderMembership'

    STD: tuple[type[StakeholderMembership], ...] = ...
    """
    All subtypes of ``StakeholderMembership`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``StakeholderMembership.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, StakeholderMembership.STD):
            ...

    For type hints, instead use ``StakeholderMembership.Std``:

    .. code-block:: python

        def function(element: Element) -> StakeholderMembership.Std:
            ...

    Note that ``StakeholderMembership.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "StakeholderMembership.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = StakeholderMembership
        """Type hint for all subtypes of ``StakeholderMembership`` according to the specification"""

    @property
    def owned_stakeholder_parameter(self) -> PartUsage | None:
        """
        Implementation of ``owned_stakeholder_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``PartUsage`` specifying the stakeholder.

        See section
        `8.3.21.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=397>`__
        of the SysML specification for more details.
        """

class SatisfyRequirementUsage(RequirementUsage):
    """
    Implementation of ``SatisfyRequirementUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``SatisfyRequirementUsage`` is an ``AssertConstraintUsage`` that
       asserts, by default, that a satisfied ``RequirementUsage`` is true
       for a specific ``satisfying_feature``, or, if ``is_negated = true``,
       that the ``RequirementUsage`` is false. The satisfied
       ``RequirementUsage`` is related to the ``SatisfyRequirementUsage`` by
       a ``ReferenceSubsetting`` ``Relationship``.

    For language description, see section
    `7.21.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=168>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=395>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::SatisfyRequirementUsage'

    STD: tuple[type[SatisfyRequirementUsage], ...] = ...
    """
    All subtypes of ``SatisfyRequirementUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``SatisfyRequirementUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, SatisfyRequirementUsage.STD):
            ...

    For type hints, instead use ``SatisfyRequirementUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> SatisfyRequirementUsage.Std:
            ...

    Note that ``SatisfyRequirementUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "SatisfyRequirementUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = SatisfyRequirementUsage
        """Type hint for all subtypes of ``SatisfyRequirementUsage`` according to the specification"""

    @property
    def satisfied_requirement(self) -> RequirementUsage | None:
        """
        Implementation of ``satisfied_requirement`` defined in the SysML
        specification.

        **Specification**:

           The ``RequirementUsage`` that is satisfied by the
           ``satisfying_subject`` of this ``SatisfyRequirementUsage``. It is the
           ``asserted_constraint`` of the ``SatisfyRequirementUsage`` considered
           as an ``AssertConstraintUsage``, which must be a
           ``RequirementUsage``.

        See section
        `8.3.21.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=395>`__
        of the SysML specification for more details.
        """

    @property
    def satisfying_feature(self) -> Feature | None:
        """
        Implementation of ``satisfying_feature`` defined in the SysML
        specification.

        **Specification**:

           The ``Feature`` that represents the actual subject that is asserted
           to satisfy the ``satisfied_requirement``. The ``satisfying_feature``
           is bound to the ``subject_parameter`` of the
           ``SatisfyRequirementUsage``.

        See section
        `8.3.21.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=395>`__
        of the SysML specification for more details.
        """

    @property
    def satisfaction_subject_member(self) -> SatisfactionSubjectAccessor:
        """Syside specific accessor for manipulating ``satisfaction subject``."""

    @property
    def satisfaction_subject(self) -> ReferenceUsage | None:
        """The subject as explicitly declared via ``by`` in the textual syntax."""

    @property
    def is_negated(self) -> bool:
        """
        Implementation of ``is_negated`` defined in the KerML specification.

        **Specification**:

           Whether this ``Invariant`` is asserted to be false rather than true.

        See section
        `8.3.4.7.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=225>`__
        of the KerML specification for more details.
        """

    @is_negated.setter
    def is_negated(self, arg: bool, /) -> None: ...

    @property
    def asserted_constraint(self) -> ConstraintUsage | None:
        """
        Implementation of ``asserted_constraint`` defined in the SysML
        specification.

        **Specification**:

           The ``ConstraintUsage`` to be performed by the
           ``AssertConstraintUsage``. It is the ``reference_feature`` of the
           ``owned_reference_subsetting`` for the ``AssertConstraintUsage``, if
           there is one, and, otherwise, the ``AssertConstraintUsage`` itself.

        See section
        `8.3.20.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=379>`__
        of the SysML specification for more details.
        """

class AssertConstraintUsage(ConstraintUsage):
    """
    Implementation of ``AssertConstraintUsage`` defined in the SysML
    specification.

    **Specification**:

       An ``AssertConstraintUsage`` is a ``ConstraintUsage`` that is also an
       ``Invariant`` and, so, is asserted to be true (by default). Unless it
       is the ``AssertConstraintUsage`` itself, the asserted
       ``ConstraintUsage`` is related to the ``AssertConstraintUsage`` by a
       ReferenceSubsetting ``Relationship``.

    For language description, see section
    `7.20.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=160>`__
    of the SysML specification. For more details on the model, see section
    `8.3.20.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=379>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::AssertConstraintUsage'

    STD: tuple[Union[type[AssertConstraintUsage], type[SatisfyRequirementUsage]], ...] = ...
    """
    All subtypes of ``AssertConstraintUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``AssertConstraintUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, AssertConstraintUsage.STD):
            ...

    For type hints, instead use ``AssertConstraintUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> AssertConstraintUsage.Std:
            ...

    Note that ``AssertConstraintUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "AssertConstraintUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[AssertConstraintUsage, SatisfyRequirementUsage]
        """Type hint for all subtypes of ``AssertConstraintUsage`` according to the specification"""

    @property
    def is_negated(self) -> bool:
        """
        Implementation of ``is_negated`` defined in the KerML specification.

        **Specification**:

           Whether this ``Invariant`` is asserted to be false rather than true.

        See section
        `8.3.4.7.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=225>`__
        of the KerML specification for more details.
        """

    @is_negated.setter
    def is_negated(self, arg: bool, /) -> None: ...

    @property
    def asserted_constraint(self) -> ConstraintUsage | None:
        """
        Implementation of ``asserted_constraint`` defined in the SysML
        specification.

        **Specification**:

           The ``ConstraintUsage`` to be performed by the
           ``AssertConstraintUsage``. It is the ``reference_feature`` of the
           ``owned_reference_subsetting`` for the ``AssertConstraintUsage``, if
           there is one, and, otherwise, the ``AssertConstraintUsage`` itself.

        See section
        `8.3.20.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=379>`__
        of the SysML specification for more details.
        """

class ControlNode(ActionUsage):
    """
    Implementation of ``ControlNode`` defined in the SysML specification.

    **Specification**:

       A ``ControlNode`` is an ``ActionUsage`` that does not have any
       inherent behavior but provides constraints on incoming and outgoing
       ``Successions`` that are used to control other ``Actions``. A
       ``ControlNode`` must be a composite owned ``usage`` of an
       ``ActionDefinition`` or ``ActionUsage``.

    For language description, see section
    `7.17.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=133>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=348>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ControlNode'

    STD: tuple[type[ControlNode], ...] = ...
    """
    All subtypes of ``ControlNode`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ControlNode.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ControlNode.STD):
            ...

    For type hints, instead use ``ControlNode.Std``:

    .. code-block:: python

        def function(element: Element) -> ControlNode.Std:
            ...

    Note that ``ControlNode.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ControlNode.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ControlNode
        """Type hint for all subtypes of ``ControlNode`` according to the specification"""

class JoinNode(ControlNode):
    """
    Implementation of ``JoinNode`` defined in the SysML specification.

    **Specification**:

       A ``JoinNode`` is a ``ControlNode`` that waits for the completion of
       all the predecessor ``Actions`` given by incoming ``Successions``.

    For language description, see section
    `7.17.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=133>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=354>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::JoinNode'

    STD: tuple[type[JoinNode], ...] = ...
    """
    All subtypes of ``JoinNode`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``JoinNode.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, JoinNode.STD):
            ...

    For type hints, instead use ``JoinNode.Std``:

    .. code-block:: python

        def function(element: Element) -> JoinNode.Std:
            ...

    Note that ``JoinNode.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "JoinNode.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = JoinNode
        """Type hint for all subtypes of ``JoinNode`` according to the specification"""

class ForkNode(ControlNode):
    """
    Implementation of ``ForkNode`` defined in the SysML specification.

    **Specification**:

       A ``ForkNode`` is a ``ControlNode`` that must be followed by
       successor ``Actions`` as given by all its outgoing ``Successions``.

    For language description, see section
    `7.17.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=133>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=350>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ForkNode'

    STD: tuple[type[ForkNode], ...] = ...
    """
    All subtypes of ``ForkNode`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ForkNode.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ForkNode.STD):
            ...

    For type hints, instead use ``ForkNode.Std``:

    .. code-block:: python

        def function(element: Element) -> ForkNode.Std:
            ...

    Note that ``ForkNode.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ForkNode.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ForkNode
        """Type hint for all subtypes of ``ForkNode`` according to the specification"""

class MergeNode(ControlNode):
    """
    Implementation of ``MergeNode`` defined in the SysML specification.

    **Specification**:

       A ``MergeNode`` is a ``ControlNode`` that asserts the merging of its
       incoming ``Successions``. A ``MergeNode`` may have at most one
       outgoing ``Successions``.

    For language description, see section
    `7.17.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=133>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.13 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=355>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::MergeNode'

    STD: tuple[type[MergeNode], ...] = ...
    """
    All subtypes of ``MergeNode`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``MergeNode.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, MergeNode.STD):
            ...

    For type hints, instead use ``MergeNode.Std``:

    .. code-block:: python

        def function(element: Element) -> MergeNode.Std:
            ...

    Note that ``MergeNode.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "MergeNode.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = MergeNode
        """Type hint for all subtypes of ``MergeNode`` according to the specification"""

class LoopActionUsage(ActionUsage):
    """
    Implementation of ``LoopActionUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``LoopActionUsage`` is an ``ActionUsage`` that specifies that its
       ``body_action`` should be performed repeatedly. Its subclasses
       ``WhileLoopActionUsage`` and ``ForLoopActionUsage`` provide different
       ways to determine how many times the ``body_action`` should be
       performed.

    For language description, see section
    `7.17.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=143>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=354>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::LoopActionUsage'

    STD: tuple[type[LoopActionUsage], ...] = ...
    """
    All subtypes of ``LoopActionUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``LoopActionUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, LoopActionUsage.STD):
            ...

    For type hints, instead use ``LoopActionUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> LoopActionUsage.Std:
            ...

    Note that ``LoopActionUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "LoopActionUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = LoopActionUsage
        """Type hint for all subtypes of ``LoopActionUsage`` according to the specification"""

    @property
    def body_action(self) -> ActionUsage | None:
        """
        Implementation of ``body_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsage`` to be performed repeatedly by the
           ``LoopActionUsage``. It is the second ``parameter`` of the
           ``LoopActionUsage``.

        See section
        `8.3.17.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=355>`__
        of the SysML specification for more details.
        """

    @property
    def body_action_member(self) -> ActionParameterAccessor:
        """Syside specific accessor for manipulating ``body_action``."""

class ForLoopActionUsage(LoopActionUsage):
    """
    Implementation of ``ForLoopActionUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``ForLoopActionUsage`` is a ``LoopActionUsage`` that specifies that
       its ``body_action`` ``ActionUsage`` should be performed once for each
       value, in order, from the sequence of values obtained as the result
       of the ``seq_argument`` ``Expression``, with the ``loop_variable``
       set to the value for each iteration.

    For language description, see section
    `7.17.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=143>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=351>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ForLoopActionUsage'

    STD: tuple[type[ForLoopActionUsage], ...] = ...
    """
    All subtypes of ``ForLoopActionUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ForLoopActionUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ForLoopActionUsage.STD):
            ...

    For type hints, instead use ``ForLoopActionUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> ForLoopActionUsage.Std:
            ...

    Note that ``ForLoopActionUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ForLoopActionUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ForLoopActionUsage
        """Type hint for all subtypes of ``ForLoopActionUsage`` according to the specification"""

    @property
    def seq_argument(self) -> Expression | None:
        """
        Implementation of ``seq_argument`` defined in the SysML specification.

        **Specification**:

           The ``Expression`` whose result provides the sequence of values to
           which the ``loop_variable`` is set for each iterative performance of
           the ``body_action``. It is the ``Expression`` whose ``result`` is
           bound to the ``seq`` ``input`` ``parameter`` of this
           ``ForLoopActionUsage``.

        See section
        `8.3.17.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=351>`__
        of the SysML specification for more details.
        """

    @property
    def seq_parameter(self) -> ReferenceUsage | None:
        """The parameter owning ``seq_argument``."""

    @property
    def seq_member(self) -> ParameterAccessor:
        """Syside specific accessor for manipulating ``seq_parameter``."""

    @property
    def loop_variable(self) -> ReferenceUsage | None:
        """
        Implementation of ``loop_variable`` defined in the SysML specification.

        **Specification**:

           The ``owned_feature`` of this ForLoopActionUsage that acts as the
           loop variable, which is assigned the successive values of the input
           sequence on each iteration. It is the ``owned_feature`` that
           redefines ``ForLoopAction::var``.

        See section
        `8.3.17.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=351>`__
        of the SysML specification for more details.
        """

    @property
    def loop_variable_member(self) -> ReferenceUsageAccessor:
        """Syside specific accessor for manipulating ``loop_variable``."""

class TriggerInvocationExpression(InvocationExpression):
    """
    Implementation of ``TriggerInvocationExpression`` defined in the SysML
    specification.

    **Specification**:

       A ``TriggerInvocationExpression`` is an ``InvocationExpression`` that
       invokes one of the trigger ``Functions`` from the Kernel Semantic
       Library ``Triggers`` package, as indicated by its ``kind``.

    For language description, see section
    `7.18.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=151>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.17 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=359>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::TriggerInvocationExpression'

    STD: tuple[type[TriggerInvocationExpression], ...] = ...
    """
    All subtypes of ``TriggerInvocationExpression`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``TriggerInvocationExpression.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, TriggerInvocationExpression.STD):
            ...

    For type hints, instead use ``TriggerInvocationExpression.Std``:

    .. code-block:: python

        def function(element: Element) -> TriggerInvocationExpression.Std:
            ...

    Note that ``TriggerInvocationExpression.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "TriggerInvocationExpression.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = TriggerInvocationExpression
        """Type hint for all subtypes of ``TriggerInvocationExpression`` according to the specification"""

    @property
    def kind(self) -> TriggerKind:
        """
        Implementation of ``kind`` defined in the SysML specification.

        **Specification**:

           Indicates which of the ``Functions`` from the ``Triggers`` model in
           the Kernel Semantic Library is to be invoked by this
           ``TriggerInvocationExpression``.

        See section
        `8.3.17.17 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=359>`__
        of the SysML specification for more details.
        """

    @kind.setter
    def kind(self, arg: TriggerKind, /) -> None: ...

class AssignmentActionUsage(ActionUsage):
    """
    Implementation of ``AssignmentActionUsage`` defined in the SysML
    specification.

    **Specification**:

       An ``AssignmentActionUsage`` is an ``ActionUsage`` that is defined,
       directly or indirectly, by the ``ActionDefinition``
       ``AssignmentAction`` from the Systems Model Library. It specifies
       that the value of the ``referent`` ``Feature``, relative to the
       target given by the result of the ``target_argument`` ``Expression``,
       should be set to the result of the ``value_expression``.

    For language description, see section
    `7.17.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=141>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=346>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::AssignmentActionUsage'

    STD: tuple[type[AssignmentActionUsage], ...] = ...
    """
    All subtypes of ``AssignmentActionUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``AssignmentActionUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, AssignmentActionUsage.STD):
            ...

    For type hints, instead use ``AssignmentActionUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> AssignmentActionUsage.Std:
            ...

    Note that ``AssignmentActionUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "AssignmentActionUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = AssignmentActionUsage
        """Type hint for all subtypes of ``AssignmentActionUsage`` according to the specification"""

    @property
    def target_argument(self) -> Expression | None:
        """
        Implementation of ``target_argument`` defined in the SysML
        specification.

        **Specification**:

           The ``Expression`` whose value is an occurrence in the domain of the
           ``referent`` ``Feature``, for which the value of the ``referent``
           will be set to the result of the ``value_expression`` by this
           ``AssignmentActionUsage``.

        See section
        `8.3.17.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=346>`__
        of the SysML specification for more details.
        """

    @property
    def target_parameter(self) -> ReferenceUsage | None:
        """The parameter owning the ``target_argument``."""

    @property
    def target_member(self) -> ParameterAccessor:
        """Syside specific accessor for manipulating ``target_parameter``."""

    @property
    def value_expression(self) -> Expression | None:
        """
        Implementation of ``value_expression`` defined in the SysML
        specification.

        **Specification**:

           The ``Expression`` whose result is to be assigned to the ``referent``
           ``Feature``.

        See section
        `8.3.17.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=346>`__
        of the SysML specification for more details.
        """

    @property
    def value_parameter(self) -> ReferenceUsage | None:
        """The parameter owning the ``value_expression``."""

    @property
    def value_member(self) -> ParameterAccessor:
        """Syside specific accessor for manipulating ``value_parameter``."""

    @property
    def referent(self) -> Feature | None:
        """
        Implementation of ``referent`` defined in the SysML specification.

        **Specification**:

           The ``Feature`` whose value is to be set.

        See section
        `8.3.17.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=346>`__
        of the SysML specification for more details.
        """

    @property
    def referent_member(self) -> ChainedFeatureMemberAccessor:
        """Syside specific accessor for manipulating ``referent``."""

class IfActionUsage(ActionUsage):
    """
    Implementation of ``IfActionUsage`` defined in the SysML specification.

    **Specification**:

       An ``IfActionUsage`` is an ``ActionUsage`` that specifies that the
       ``then_action`` ``ActionUsage`` should be performed if the result of
       the ``if_argument`` ``Expression`` is true. It may also optionally
       specify an ``else_action`` ``ActionUsage`` that is performed if the
       result of the ``if_argument`` is false.

    For language description, see section
    `7.17.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=143>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=352>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::IfActionUsage'

    STD: tuple[type[IfActionUsage], ...] = ...
    """
    All subtypes of ``IfActionUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``IfActionUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, IfActionUsage.STD):
            ...

    For type hints, instead use ``IfActionUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> IfActionUsage.Std:
            ...

    Note that ``IfActionUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "IfActionUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = IfActionUsage
        """Type hint for all subtypes of ``IfActionUsage`` according to the specification"""

    @property
    def else_action(self) -> ActionUsage | None:
        """
        Implementation of ``else_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsage`` that is to be performed if the result of the
           ``if_argument`` is false. It is the (optional) third ``parameter`` of
           the ``IfActionUsage``.

        See section
        `8.3.17.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=352>`__
        of the SysML specification for more details.
        """

    @property
    def else_action_member(self) -> ActionParameterAccessor:
        """Syside specific accessor for manipulating ``else_action``."""

    @property
    def then_action(self) -> ActionUsage | None:
        """
        Implementation of ``then_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsage`` that is to be performed if the result of the
           ``if_argument`` is true. It is the second ``parameter`` of the
           ``IfActionUsage``.

        See section
        `8.3.17.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=353>`__
        of the SysML specification for more details.
        """

    @property
    def then_action_member(self) -> ActionParameterAccessor:
        """Syside specific accessor for manipulating ``then_action``."""

    @property
    def if_argument(self) -> Expression | None:
        """
        Implementation of ``if_argument`` defined in the SysML specification.

        **Specification**:

           The ``Expression`` whose result determines whether the
           ``then_action`` or (optionally) the ``else_action`` is performed. It
           is the first ``parameter`` of the ``IfActionUsage``.

        See section
        `8.3.17.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=352>`__
        of the SysML specification for more details.
        """

    @property
    def if_argument_member(self) -> ExpressionParameterAccessor:
        """Syside specific accessor for manipulating ``if_argument``."""

class SendActionUsage(ActionUsage):
    """
    Implementation of ``SendActionUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``SendActionUsage`` is an ``ActionUsage`` that specifies the
       sending of a payload given by the result of its ``payload_argument``
       ``Expression`` via a ``MessageTransfer`` whose ``source`` is given by
       the result of the ``sender_argument`` ``Expression`` and whose
       ``target`` is given by the result of the ``receiver_argument``
       ``Expression``. If no ``sender_argument`` is provided, the default is
       the ``this`` context for the action. If no ``receiver_argument`` is
       given, then the receiver is to be determined by, e.g., outgoing
       ``Connections`` from the sender.

    For language description, see section
    `7.17.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=137>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.15 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=357>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::SendActionUsage'

    STD: tuple[type[SendActionUsage], ...] = ...
    """
    All subtypes of ``SendActionUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``SendActionUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, SendActionUsage.STD):
            ...

    For type hints, instead use ``SendActionUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> SendActionUsage.Std:
            ...

    Note that ``SendActionUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "SendActionUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = SendActionUsage
        """Type hint for all subtypes of ``SendActionUsage`` according to the specification"""

    @property
    def receiver_argument(self) -> Expression | None:
        """
        Implementation of ``receiver_argument`` defined in the SysML
        specification.

        **Specification**:

           An ``Expression`` whose result is bound to the ``receiver`` input
           parameter of this ``SendActionUsage``.

        See section
        `8.3.17.15 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=357>`__
        of the SysML specification for more details.
        """

    @property
    def receiver_parameter(self) -> ReferenceUsage | None:
        """
        The parameter owning the ``receiver_argument`` if the argument is a part of the declaration before braces.
        """

    @property
    def receiver_member(self) -> ParameterAccessor:
        """Syside specific accessor for manipulating ``receiver_parameter``."""

    @property
    def payload_argument(self) -> Expression | None:
        """
        Implementation of ``payload_argument`` defined in the SysML
        specification.

        **Specification**:

           An ``Expression`` whose result is bound to the ``payload`` input
           parameter of this ``SendActionUsage``.

        See section
        `8.3.17.15 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=357>`__
        of the SysML specification for more details.
        """

    @property
    def payload_parameter(self) -> ReferenceUsage | None:
        """
        The parameter owning the ``payload_argument`` if the argument is a part of the declaration before braces.
        """

    @property
    def payload_member(self) -> ParameterAccessor:
        """Syside specific accessor for manipulating ``payload_parameter``."""

    @property
    def sender_argument(self) -> Expression | None:
        """
        Implementation of ``sender_argument`` defined in the SysML
        specification.

        **Specification**:

           An ``Expression`` whose result is bound to the ``sender`` input
           parameter of this ``SendActionUsage``.

        See section
        `8.3.17.15 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=357>`__
        of the SysML specification for more details.
        """

    @property
    def sender_parameter(self) -> ReferenceUsage | None:
        """
        The parameter owning the ``sender_argument`` if the argument is a part of the declaration before braces.
        """

    @property
    def sender_member(self) -> ParameterAccessor:
        """Syside specific accessor for manipulating ``sender_parameter``."""

class PerformActionUsage(ActionUsage):
    """
    Implementation of ``PerformActionUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``PerformActionUsage`` is an ``ActionUsage`` that represents the
       performance of an ``ActionUsage``. Unless it is the
       ``PerformActionUsage`` itself, the ``ActionUsage`` to be performed is
       related to the ``PerformActionUsage`` by a ``ReferenceSubsetting``
       relationship. A ``PerformActionUsage`` is also an
       ``EventOccurrenceUsage``, with its ``performed_action`` as the
       ``event_occurrence``.

    For language description, see section
    `7.17.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=136>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.14 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=356>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::PerformActionUsage'

    STD: tuple[Union[type[PerformActionUsage], type[ExhibitStateUsage], type[IncludeUseCaseUsage]], ...] = ...
    """
    All subtypes of ``PerformActionUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``PerformActionUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, PerformActionUsage.STD):
            ...

    For type hints, instead use ``PerformActionUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> PerformActionUsage.Std:
            ...

    Note that ``PerformActionUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "PerformActionUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[PerformActionUsage, ExhibitStateUsage, IncludeUseCaseUsage]
        """Type hint for all subtypes of ``PerformActionUsage`` according to the specification"""

    @property
    def event_occurrence(self) -> OccurrenceUsage | ConnectionUsage | FlowUsage | None:
        """
        Implementation of ``event_occurrence`` defined in the SysML
        specification.

        **Specification**:

           The ``OccurrenceUsage`` referenced as an event by this
           ``EventOccurrenceUsage``. It is the ``reference_feature`` of the
           ``owned_reference_subsetting`` for the ``EventOccurrenceUsage``, if
           there is one, and, otherwise, the ``EventOccurrenceUsage`` itself.

        See section
        `8.3.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=314>`__
        of the SysML specification for more details.
        """

    @property
    def performed_action(self) -> ActionUsage | FlowUsage | None:
        """
        Implementation of ``performed_action`` defined in the SysML
        specification.

        **Specification**:

           The ``ActionUsage`` to be performed by this ``PerformedActionUsage``.
           It is the ``event_occurrence`` of the ``PerformActionUsage``
           considered as an ``EventOccurrenceUsage``, which must be an
           ``ActionUsage``.

        See section
        `8.3.17.14 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=356>`__
        of the SysML specification for more details.
        """

class DecisionNode(ControlNode):
    """
    Implementation of ``DecisionNode`` defined in the SysML specification.

    **Specification**:

       A ``DecisionNode`` is a ``ControlNode`` that makes a selection from
       its outgoing ``Successions``.

    For language description, see section
    `7.17.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=133>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=349>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::DecisionNode'

    STD: tuple[type[DecisionNode], ...] = ...
    """
    All subtypes of ``DecisionNode`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``DecisionNode.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, DecisionNode.STD):
            ...

    For type hints, instead use ``DecisionNode.Std``:

    .. code-block:: python

        def function(element: Element) -> DecisionNode.Std:
            ...

    Note that ``DecisionNode.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "DecisionNode.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = DecisionNode
        """Type hint for all subtypes of ``DecisionNode`` according to the specification"""

class WhileLoopActionUsage(LoopActionUsage):
    """
    Implementation of ``WhileLoopActionUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``WhileLoopActionUsage`` is a ``LoopActionUsage`` that specifies
       that the ``body_action`` ``ActionUsage`` should be performed
       repeatedly while the result of the ``while_argument`` ``Expression``
       is true or until the result of the ``until_argument`` ``Expression``
       (if provided) is true. The ``while_argument`` ``Expression`` is
       evaluated before each (possible) performance of the ``body_action``,
       and the ``until_argument`` ``Expression`` is evaluated after each
       performance of the ``body_action``.

    For language description, see section
    `7.17.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=143>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.19 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=361>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::WhileLoopActionUsage'

    STD: tuple[type[WhileLoopActionUsage], ...] = ...
    """
    All subtypes of ``WhileLoopActionUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``WhileLoopActionUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, WhileLoopActionUsage.STD):
            ...

    For type hints, instead use ``WhileLoopActionUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> WhileLoopActionUsage.Std:
            ...

    Note that ``WhileLoopActionUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "WhileLoopActionUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = WhileLoopActionUsage
        """Type hint for all subtypes of ``WhileLoopActionUsage`` according to the specification"""

    @property
    def while_argument(self) -> Expression | None:
        """
        Implementation of ``while_argument`` defined in the SysML specification.

        **Specification**:

           The ``Expression`` whose result, if true, determines that the
           ``body_action`` should continue to be performed. It is the first
           owned ``parameter`` of the ``WhileLoopActionUsage``.

        See section
        `8.3.17.19 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=361>`__
        of the SysML specification for more details.
        """

    @property
    def while_argument_member(self) -> ExpressionParameterAccessor:
        """Syside specific accessor for manipulating ``while_argument``."""

    @property
    def until_argument(self) -> Expression | None:
        """
        Implementation of ``until_argument`` defined in the SysML specification.

        **Specification**:

           The ``Expression`` whose result, if false, determines that the
           ``body_action`` should continue to be performed. It is the (optional)
           third owned ``parameter`` of the ``WhileLoopActionUsage``.

        See section
        `8.3.17.19 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=361>`__
        of the SysML specification for more details.
        """

    @property
    def until_argument_member(self) -> ExpressionParameterAccessor:
        """Syside specific accessor for manipulating ``until_argument``."""

class Expose(Import):
    """
    Implementation of ``Expose`` defined in the SysML specification.

    **Specification**:

       An ``Expose`` is an ``Import`` of ``Memberships`` into a
       ``ViewUsage`` that provide the ``Elements`` to be included in a view.
       Visibility is always ignored for an ``Expose`` (i.e.,
       ``is_import_all = true``).

    For language description, see section
    `7.26.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=184>`__
    of the SysML specification. For more details on the model, see section
    `8.3.26.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=415>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::Expose'

    STD: tuple[Union[type[Expose], type[MembershipExpose], type[NamespaceExpose]], ...] = ...
    """
    All subtypes of ``Expose`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``Expose.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, Expose.STD):
            ...

    For type hints, instead use ``Expose.Std``:

    .. code-block:: python

        def function(element: Element) -> Expose.Std:
            ...

    Note that ``Expose.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "Expose.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = Union[Expose, MembershipExpose, NamespaceExpose]
        """Type hint for all subtypes of ``Expose`` according to the specification"""

class MembershipExpose(MembershipImport):
    """
    Implementation of ``MembershipExpose`` defined in the SysML
    specification.

    **Specification**:

       A ``MembershipExpose`` is an ``Expose`` that exposes a specific
       ``imported_membership`` and, if ``is_recursive = true``, additional
       ``Memberships`` recursively.

    For language description, see section
    `7.26.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=184>`__
    of the SysML specification. For more details on the model, see section
    `8.3.26.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=416>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::MembershipExpose'

    STD: tuple[type[MembershipExpose], ...] = ...
    """
    All subtypes of ``MembershipExpose`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``MembershipExpose.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, MembershipExpose.STD):
            ...

    For type hints, instead use ``MembershipExpose.Std``:

    .. code-block:: python

        def function(element: Element) -> MembershipExpose.Std:
            ...

    Note that ``MembershipExpose.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "MembershipExpose.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = MembershipExpose
        """Type hint for all subtypes of ``MembershipExpose`` according to the specification"""

class NamespaceExpose(NamespaceImport):
    """
    Implementation of ``NamespaceExpose`` defined in the SysML
    specification.

    **Specification**:

       A ``NamespaceExpose`` is an ``Expose`` ``Relationship`` that exposes
       the ``Memberships`` of a specific ``imported_namespace`` and, if
       ``is_recursive = true``, additional ``Memberships`` recursively.

    For language description, see section
    `7.26.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=184>`__
    of the SysML specification. For more details on the model, see section
    `8.3.26.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=417>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::NamespaceExpose'

    STD: tuple[type[NamespaceExpose], ...] = ...
    """
    All subtypes of ``NamespaceExpose`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``NamespaceExpose.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, NamespaceExpose.STD):
            ...

    For type hints, instead use ``NamespaceExpose.Std``:

    .. code-block:: python

        def function(element: Element) -> NamespaceExpose.Std:
            ...

    Note that ``NamespaceExpose.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "NamespaceExpose.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = NamespaceExpose
        """Type hint for all subtypes of ``NamespaceExpose`` according to the specification"""

class ViewRenderingMembership(FeatureMembership):
    """
    Implementation of ``ViewRenderingMembership`` defined in the SysML
    specification.

    **Specification**:

       A ``ViewRenderingMembership`` is a FeatureMembership that identifies
       the ``view_rendering`` of a ``ViewDefinition`` or ``ViewUsage``.

    For language description, see section
    `7.26.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=184>`__
    of the SysML specification. For more details on the model, see section
    `8.3.26.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=422>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ViewRenderingMembership'

    STD: tuple[type[ViewRenderingMembership], ...] = ...
    """
    All subtypes of ``ViewRenderingMembership`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ViewRenderingMembership.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ViewRenderingMembership.STD):
            ...

    For type hints, instead use ``ViewRenderingMembership.Std``:

    .. code-block:: python

        def function(element: Element) -> ViewRenderingMembership.Std:
            ...

    Note that ``ViewRenderingMembership.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ViewRenderingMembership.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ViewRenderingMembership
        """Type hint for all subtypes of ``ViewRenderingMembership`` according to the specification"""

    @property
    def owned_rendering(self) -> RenderingUsage | None:
        """
        Implementation of ``owned_rendering`` defined in the SysML
        specification.

        **Specification**:

           The owned ``RenderingUsage`` that is either itself the
           ``referenced_rendering`` or subsets the ``referenced_rendering``.

        See section
        `8.3.26.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=422>`__
        of the SysML specification for more details.
        """

    @property
    def referenced_rendering(self) -> RenderingUsage | None:
        """
        Implementation of ``referenced_rendering`` defined in the SysML
        specification.

        **Specification**:

           The ``RenderingUsage`` that is referenced through this
           ``ViewRenderingMembership``. It is the ``referenced_feature`` of the
           ``owned_reference_subsetting`` for the ``owned_rendering``, if there
           is one, and, otherwise, the ``owned_rendering`` itself.

        See section
        `8.3.26.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=422>`__
        of the SysML specification for more details.
        """

class ConjugatedPortTyping(FeatureTyping):
    """
    Implementation of ``ConjugatedPortTyping`` defined in the SysML
    specification.

    **Specification**:

       A ``ConjugatedPortTyping`` is a ``FeatureTyping`` whose ``type`` is a
       ``ConjugatedPortDefinition``. (This relationship is intended to be an
       abstract-syntax marker for a special surface notation for conjugated
       typing of ports.)

    For language description, see section
    `7.12.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=95>`__
    of the SysML specification. For more details on the model, see section
    `8.3.12.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=324>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ConjugatedPortTyping'

    STD: tuple[type[ConjugatedPortTyping], ...] = ...
    """
    All subtypes of ``ConjugatedPortTyping`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ConjugatedPortTyping.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ConjugatedPortTyping.STD):
            ...

    For type hints, instead use ``ConjugatedPortTyping.Std``:

    .. code-block:: python

        def function(element: Element) -> ConjugatedPortTyping.Std:
            ...

    Note that ``ConjugatedPortTyping.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ConjugatedPortTyping.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ConjugatedPortTyping
        """Type hint for all subtypes of ``ConjugatedPortTyping`` according to the specification"""

    CHAINABLE: bool = False
    """
    Whether this relationship can be used with chained features.

    Using this in, e.g. ``append_chain``, will raise ``TypeError``.
    """

    @property
    def port_definition(self) -> PortDefinition | None:
        """
        Implementation of ``port_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``original_port_definition`` of the
           ``conjugated_port_definition`` of this ``ConjugatedPortTyping``.

        See section
        `8.3.12.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=325>`__
        of the SysML specification for more details.
        """

    @property
    def conjugated_port_definition(self) -> ConjugatedPortDefinition | None:
        """
        Implementation of ``conjugated_port_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``type`` of this ``ConjugatedPortTyping`` considered as a
           ``FeatureTyping``, which must be a ``ConjugatedPortDefinition``.

        See section
        `8.3.12.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=325>`__
        of the SysML specification for more details.
        """

class ObjectiveMembership(FeatureMembership):
    """
    Implementation of ``ObjectiveMembership`` defined in the SysML
    specification.

    **Specification**:

       An ``ObjectiveMembership`` is a ``FeatureMembership`` that indicates
       that its ``owned_objective_requirement`` is the objective
       ``RequirementUsage`` for its ``owning_type``, which must be a
       ``CaseDefinition`` or ``CaseUsage``.

    For language description, see section
    `7.22.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=169>`__
    of the SysML specification. For more details on the model, see section
    `8.3.22.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=402>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ObjectiveMembership'

    STD: tuple[type[ObjectiveMembership], ...] = ...
    """
    All subtypes of ``ObjectiveMembership`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ObjectiveMembership.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ObjectiveMembership.STD):
            ...

    For type hints, instead use ``ObjectiveMembership.Std``:

    .. code-block:: python

        def function(element: Element) -> ObjectiveMembership.Std:
            ...

    Note that ``ObjectiveMembership.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ObjectiveMembership.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ObjectiveMembership
        """Type hint for all subtypes of ``ObjectiveMembership`` according to the specification"""

    @property
    def owned_objective_requirement(self) -> RequirementUsage | None:
        """
        Implementation of ``owned_objective_requirement`` defined in the SysML
        specification.

        **Specification**:

           The RequirementUsage that is the ``owned_member_feature`` of this
           RequirementUsage.

        See section
        `8.3.22.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=402>`__
        of the SysML specification for more details.
        """

class StateDefinition(ActionDefinition):
    """
    Implementation of ``StateDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``StateDefinition`` is the ``Definition`` of the Behavior of a
       system or part of a system in a certain state condition.

       A ``StateDefinition`` may be related to up to three of its
       ``owned_features`` by ``StateBehaviorMembership`` ``Relationships``,
       all of different ``kinds``, corresponding to the entry, do and exit
       actions of the ``StateDefinition``.

    For language description, see section
    `7.18.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=149>`__
    of the SysML specification. For more details on the model, see section
    `8.3.18.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=366>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::StateDefinition'

    STD: tuple[type[StateDefinition], ...] = ...
    """
    All subtypes of ``StateDefinition`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``StateDefinition.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, StateDefinition.STD):
            ...

    For type hints, instead use ``StateDefinition.Std``:

    .. code-block:: python

        def function(element: Element) -> StateDefinition.Std:
            ...

    Note that ``StateDefinition.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "StateDefinition.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = StateDefinition
        """Type hint for all subtypes of ``StateDefinition`` according to the specification"""

    @property
    def states(self) -> LazyIterator[StateUsage]:
        """
        Implementation of ``state`` defined in the SysML specification.

        **Specification**:

           The ``StateUsages``, which are ``actions`` in the
           ``StateDefinition``, that specify the discrete states in the behavior
           defined by the ``StateDefinition``.

        See section
        `8.3.18.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=367>`__
        of the SysML specification for more details.
        """

    @property
    def is_parallel(self) -> bool:
        """
        Implementation of ``is_parallel`` defined in the SysML specification.

        **Specification**:

           Whether the ``owned_states`` of this ``StateDefinition`` are to all
           be performed in parallel. If true, none of the ``owned_actions``
           (which includes ``owned_states``) may have any incoming or outgoing
           ``Transitions``. If false, only one ``owned_state`` may be performed
           at a time.

        See section
        `8.3.18.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=367>`__
        of the SysML specification for more details.
        """

    @is_parallel.setter
    def is_parallel(self, arg: bool, /) -> None: ...

    @property
    def entry_action(self) -> ActionUsage | None:
        """
        Implementation of ``entry_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsage`` of this ``StateDefinition`` to be performed on
           entry to the state defined by the ``StateDefinition``. It is the
           owned ``ActionUsage`` related to the ``StateDefinition`` by a
           ``StateSubactionMembership`` with ``kind = entry``.

        See section
        `8.3.18.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=367>`__
        of the SysML specification for more details.
        """

    @property
    def do_action(self) -> ActionUsage | None:
        """
        Implementation of ``do_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsage`` of this ``StateDefinition`` to be performed while
           in the state defined by the ``StateDefinition``. It is the owned
           ``ActionUsage`` related to the ``StateDefinition`` by a
           ``StateSubactionMembership`` with ``kind = do``.

        See section
        `8.3.18.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=366>`__
        of the SysML specification for more details.
        """

    @property
    def exit_action(self) -> ActionUsage | None:
        """
        Implementation of ``exit_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsage`` of this ``StateDefinition`` to be performed on
           exit to the state defined by the ``StateDefinition``. It is the owned
           ``ActionUsage`` related to the ``StateDefinition`` by a
           ``StateSubactionMembership`` with ``kind = exit``.

        See section
        `8.3.18.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=367>`__
        of the SysML specification for more details.
        """

class StateSubactionMembership(FeatureMembership):
    """
    Implementation of ``StateSubactionMembership`` defined in the SysML
    specification.

    **Specification**:

       A ``StateSubactionMembership`` is a ``FeatureMembership`` for an
       entry, do or exit ``ActionUsage`` of a ``StateDefinition`` or
       ``StateUsage``.

    For language description, see section
    `7.18.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=149>`__
    of the SysML specification. For more details on the model, see section
    `8.3.18.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=366>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::StateSubactionMembership'

    STD: tuple[type[StateSubactionMembership], ...] = ...
    """
    All subtypes of ``StateSubactionMembership`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``StateSubactionMembership.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, StateSubactionMembership.STD):
            ...

    For type hints, instead use ``StateSubactionMembership.Std``:

    .. code-block:: python

        def function(element: Element) -> StateSubactionMembership.Std:
            ...

    Note that ``StateSubactionMembership.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "StateSubactionMembership.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = StateSubactionMembership
        """Type hint for all subtypes of ``StateSubactionMembership`` according to the specification"""

    @property
    def kind(self) -> StateSubactionKind:
        """
        Implementation of ``kind`` defined in the SysML specification.

        **Specification**:

           Whether this ``StateSubactionMembership`` is for an ``entry``, ``do``
           or ``exit`` ``ActionUsage``.

        See section
        `8.3.18.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=366>`__
        of the SysML specification for more details.
        """

    @kind.setter
    def kind(self, arg: StateSubactionKind, /) -> None: ...

    @property
    def action(self) -> ActionUsage | None:
        """
        Implementation of ``action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsage`` that is the ``owned_member_feature`` of this
           ``StateSubactionMembership``.

        See section
        `8.3.18.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=366>`__
        of the SysML specification for more details.
        """

class ExhibitStateUsage(StateUsage):
    """
    Implementation of ``ExhibitStateUsage`` defined in the SysML
    specification.

    **Specification**:

       An ``ExhibitStateUsage`` is a ``StateUsage`` that represents the
       exhibiting of a ``StateUsage``. Unless it is the ``StateUsage``
       itself, the ``StateUsage`` to be exhibited is related to the
       ``ExhibitStateUsage`` by a ``ReferenceSubsetting`` ``Relationship``.
       An ``ExhibitStateUsage`` is also a ``PerformActionUsage``, with its
       ``exhibited_state`` as the ``performed_action``.

    For language description, see section
    `7.18.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=154>`__
    of the SysML specification. For more details on the model, see section
    `8.3.18.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=364>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ExhibitStateUsage'

    STD: tuple[type[ExhibitStateUsage], ...] = ...
    """
    All subtypes of ``ExhibitStateUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``ExhibitStateUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, ExhibitStateUsage.STD):
            ...

    For type hints, instead use ``ExhibitStateUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> ExhibitStateUsage.Std:
            ...

    Note that ``ExhibitStateUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "ExhibitStateUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = ExhibitStateUsage
        """Type hint for all subtypes of ``ExhibitStateUsage`` according to the specification"""

    @property
    def exhibited_state(self) -> StateUsage | None:
        """
        Implementation of ``exhibited_state`` defined in the SysML
        specification.

        **Specification**:

           The ``StateUsage`` to be exhibited by the ``ExhibitStateUsage``. It
           is the ``performed_action`` of the ``ExhibitStateUsage`` considered
           as a ``PerformActionUsage``, which must be a ``StateUsage``.

        See section
        `8.3.18.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=365>`__
        of the SysML specification for more details.
        """

    @property
    def event_occurrence(self) -> OccurrenceUsage | ConnectionUsage | FlowUsage | None:
        """
        Implementation of ``event_occurrence`` defined in the SysML
        specification.

        **Specification**:

           The ``OccurrenceUsage`` referenced as an event by this
           ``EventOccurrenceUsage``. It is the ``reference_feature`` of the
           ``owned_reference_subsetting`` for the ``EventOccurrenceUsage``, if
           there is one, and, otherwise, the ``EventOccurrenceUsage`` itself.

        See section
        `8.3.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=314>`__
        of the SysML specification for more details.
        """

    @property
    def performed_action(self) -> ActionUsage | FlowUsage | None:
        """
        Implementation of ``performed_action`` defined in the SysML
        specification.

        **Specification**:

           The ``ActionUsage`` to be performed by this ``PerformedActionUsage``.
           It is the ``event_occurrence`` of the ``PerformActionUsage``
           considered as an ``EventOccurrenceUsage``, which must be an
           ``ActionUsage``.

        See section
        `8.3.17.14 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=356>`__
        of the SysML specification for more details.
        """

class TransitionFeatureMembership(FeatureMembership):
    """
    Implementation of ``TransitionFeatureMembership`` defined in the SysML
    specification.

    **Specification**:

       A ``TransitionFeatureMembership`` is a ``FeatureMembership`` for a
       trigger, guard or effect of a ``TransitionUsage``, whose
       ``transition_feature`` is a ``AcceptActionUsage``, ``Boolean``-valued
       ``Expression`` or ``ActionUsage``, depending on its ``kind``.

    For language description, see section
    `7.18.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=151>`__
    of the SysML specification. For more details on the model, see section
    `8.3.18.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=371>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::TransitionFeatureMembership'

    STD: tuple[type[TransitionFeatureMembership], ...] = ...
    """
    All subtypes of ``TransitionFeatureMembership`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``TransitionFeatureMembership.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, TransitionFeatureMembership.STD):
            ...

    For type hints, instead use ``TransitionFeatureMembership.Std``:

    .. code-block:: python

        def function(element: Element) -> TransitionFeatureMembership.Std:
            ...

    Note that ``TransitionFeatureMembership.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "TransitionFeatureMembership.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = TransitionFeatureMembership
        """Type hint for all subtypes of ``TransitionFeatureMembership`` according to the specification"""

    @property
    def kind(self) -> TransitionFeatureKind:
        """
        Implementation of ``kind`` defined in the SysML specification.

        **Specification**:

           Whether this ``TransitionFeatureMembership`` is for a ``trigger``,
           ``guard`` or ``effect``.

        See section
        `8.3.18.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=372>`__
        of the SysML specification for more details.
        """

    @property
    def transition_feature(self) -> ActionUsage | Expression | None:
        """
        Implementation of ``transition_feature`` defined in the SysML
        specification.

        **Specification**:

           The ``Step`` that is the ``owned_member_feature`` of this
           ``TransitionFeatureMembership``.

        See section
        `8.3.18.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=372>`__
        of the SysML specification for more details.
        """

class IncludeUseCaseUsage(UseCaseUsage):
    """
    Implementation of ``IncludeUseCaseUsage`` defined in the SysML
    specification.

    **Specification**:

       An ``IncludeUseCaseUsage`` is a ``UseCaseUsage`` that represents the
       inclusion of a ``UseCaseUsage`` by a ``UseCaseDefinition`` or
       ``UseCaseUsage``. Unless it is the ``IncludeUseCaseUsage`` itself,
       the ``UseCaseUsage`` to be included is related to the
       ``included_use_case`` by a ``ReferenceSubsetting`` ``Relationship``.
       An ``IncludeUseCaseUsage`` is also a PerformActionUsage, with its
       ``use_case_included`` as the ``performed_action``.

    For language description, see section
    `7.25.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=180>`__
    of the SysML specification. For more details on the model, see section
    `8.3.25.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=410>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::IncludeUseCaseUsage'

    STD: tuple[type[IncludeUseCaseUsage], ...] = ...
    """
    All subtypes of ``IncludeUseCaseUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``IncludeUseCaseUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, IncludeUseCaseUsage.STD):
            ...

    For type hints, instead use ``IncludeUseCaseUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> IncludeUseCaseUsage.Std:
            ...

    Note that ``IncludeUseCaseUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "IncludeUseCaseUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = IncludeUseCaseUsage
        """Type hint for all subtypes of ``IncludeUseCaseUsage`` according to the specification"""

    @property
    def use_case_included(self) -> UseCaseUsage | None:
        """
        Implementation of ``use_case_included`` defined in the SysML
        specification.

        **Specification**:

           The ``UseCaseUsage`` to be included by this ``IncludeUseCaseUsage``.
           It is the ``performed_action`` of the ``IncludeUseCaseUsage``
           considered as a ``PerformActionUsage``, which must be a
           ``UseCaseUsage``.

        See section
        `8.3.25.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=411>`__
        of the SysML specification for more details.
        """

    @property
    def event_occurrence(self) -> OccurrenceUsage | ConnectionUsage | FlowUsage | None:
        """
        Implementation of ``event_occurrence`` defined in the SysML
        specification.

        **Specification**:

           The ``OccurrenceUsage`` referenced as an event by this
           ``EventOccurrenceUsage``. It is the ``reference_feature`` of the
           ``owned_reference_subsetting`` for the ``EventOccurrenceUsage``, if
           there is one, and, otherwise, the ``EventOccurrenceUsage`` itself.

        See section
        `8.3.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=314>`__
        of the SysML specification for more details.
        """

    @property
    def performed_action(self) -> ActionUsage | FlowUsage | None:
        """
        Implementation of ``performed_action`` defined in the SysML
        specification.

        **Specification**:

           The ``ActionUsage`` to be performed by this ``PerformedActionUsage``.
           It is the ``event_occurrence`` of the ``PerformActionUsage``
           considered as an ``EventOccurrenceUsage``, which must be an
           ``ActionUsage``.

        See section
        `8.3.17.14 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=356>`__
        of the SysML specification for more details.
        """

class TerminateActionUsage(ActionUsage):
    """
    Implementation of ``TerminateActionUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``TerminateActionUsage`` is an ``ActionUsage`` that directly or
       indirectly specializes the ``ActionDefinition`` ``TerminateAction``
       from the Systems Model Library, which causes a given
       ``terminated_occurrence`` to end during its performance. By default,
       the ``terminated_occurrence`` is the featuring instance (``that``) of
       the performance of the ``TerminateActionUsage``, generally the
       performance of its immediately containing ``ActionDefinition`` or
       ``ActionUsage``.

    For language description, see section
    `7.17.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=142>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.16 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=358>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::TerminateActionUsage'

    STD: tuple[type[TerminateActionUsage], ...] = ...
    """
    All subtypes of ``TerminateActionUsage`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``TerminateActionUsage.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, TerminateActionUsage.STD):
            ...

    For type hints, instead use ``TerminateActionUsage.Std``:

    .. code-block:: python

        def function(element: Element) -> TerminateActionUsage.Std:
            ...

    Note that ``TerminateActionUsage.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "TerminateActionUsage.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = TerminateActionUsage
        """Type hint for all subtypes of ``TerminateActionUsage`` according to the specification"""

    @property
    def terminated_occurrence_argument(self) -> Expression | None:
        """
        Implementation of ``terminated_occurrence_argument`` defined in the
        SysML specification.

        **Specification**:

           The ``Expression`` that is the ``feature_value`` of the
           ``terminate_occurrence`` ``parameter`` of this
           ``TerminateActionUsage``.

        See section
        `8.3.17.16 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/2a-OMG_Systems_Modeling_Language.pdf#page=359>`__
        of the SysML specification for more details.
        """

    @property
    def terminated_occurrence_parameter(self) -> ReferenceUsage | None:
        """The parameter owning the ``terminated_occurrence_argument``."""

    @property
    def terminated_occurrence_member(self) -> ParameterAccessor:
        """Syside specific accessor for manipulating ``terminated_occurrence``."""

class CrossSubsetting(Subsetting):
    r"""
    Implementation of ``CrossSubsetting`` defined in the KerML
    specification.

    **Specification**:

       ``CrossSubsetting`` is a kind of ``Subsetting`` for end ``Features``,
       as identified by ``crossing_feature``, to subset a chained
       ``Feature``, identified by ``crossed_feature.`` It navigates to
       instances of the end ``Feature``\ ’s type from instances of other end
       ``Feature`` types on the same ``owning_type`` (at least two end
       ``Features`` are required for any of them to have a
       ``CrossSubsetting``).

       The ``crossed_feature`` of a ``CrossSubsetting`` must have a feature
       chain of exactly two ``Features``. The second ``Feature`` in the
       chain is the ``cross_feature`` of the ``crossing_feature`` (end
       ``Feature``), which has the same type as the ``crossing_feature``.
       When the ``owning_type`` of the ``crossing_feature`` has exactly two
       end ``Features``, the first ``Feature`` in the chain of the
       ``crossed_feature`` is the other end ``Feature``. The
       ``cross_feature``\ ’s ``featuring_type`` in this case is the other
       end ``Feature``. When the ``owning_type`` has more than two end
       ``Features``, the first ``Feature`` in the chain is a ``Feature``
       that ``CrossMultiplies`` all the other end ``Features``, which is
       also the ``featuring_type`` of the ``cross_feature``.

       A ``cross_feature`` must be owned by its ``feature_crossing`` (end
       ``Feature``) when the ``feature_crossing`` ``owning_type`` has more
       than two end ``Features``. Otherwise, for exactly two end
       ``Features``, the ``cross_features`` of each the ends can instead
       optionally be inherited by the other end from one of its ``types`` or
       a subsetted ``Feature``.

    For language description, see section
    `7.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=73>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=183>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::CrossSubsetting'

    STD: tuple[type[CrossSubsetting], ...] = ...
    """
    All subtypes of ``CrossSubsetting`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``CrossSubsetting.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, CrossSubsetting.STD):
            ...

    For type hints, instead use ``CrossSubsetting.Std``:

    .. code-block:: python

        def function(element: Element) -> CrossSubsetting.Std:
            ...

    Note that ``CrossSubsetting.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "CrossSubsetting.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = CrossSubsetting
        """Type hint for all subtypes of ``CrossSubsetting`` according to the specification"""

    CHAINABLE: bool = True
    """
    Whether this relationship can be used with chained features.

    Using this in, e.g. ``append_chain``, will not raise ``TypeError``.
    """

    @property
    def crossed_feature(self) -> Feature | None:
        """
        Implementation of ``crossed_feature`` defined in the KerML
        specification.

        **Specification**:

           The chained ``Feature`` that is cross subset by the
           ``crossing_feature`` of this ``CrossSubsetting``.

        See section
        `8.3.3.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=183>`__
        of the KerML specification for more details.
        """

    @property
    def crossing_feature(self) -> Feature | None:
        """
        Implementation of ``crossing_feature`` defined in the KerML
        specification.

        **Specification**:

           The end ``Feature`` that owns this ``CrossSubsetting`` relationship
           and is also its subsetting_feature.

        See section
        `8.3.3.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=183>`__
        of the KerML specification for more details.
        """

    @property
    def crossed_feature_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``crossed_feature``.
        """

    @property
    def crossing_feature_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``crossing_feature``.
        """

class IndexExpression(OperatorExpression):
    """
    Implementation of ``IndexExpression`` defined in the KerML
    specification.

    **Specification**:

       An ``IndexExpression`` is an ``OperatorExpression`` whose operator is
       ``"#"``, which resolves to the ``Function`` ``BasicFunctions::'#'``
       from the Kernel Functions Library.

    For language description, see section
    `7.4.9.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=85>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2026-03/doc/1-Kernel_Modeling_Language.pdf#page=234>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::IndexExpression'

    STD: tuple[type[IndexExpression], ...] = ...
    """
    All subtypes of ``IndexExpression`` according to the specification.

    This is needed because the implementation does not use multiple inheritance
    like the standard metamodel. However, all would-be inherited attributes
    are implemented explicitly on classes in ``IndexExpression.Std``.

    When working with standard metamodel types, use:

    .. code-block:: python

        if isinstance(element, IndexExpression.STD):
            ...

    For type hints, instead use ``IndexExpression.Std``:

    .. code-block:: python

        def function(element: Element) -> IndexExpression.Std:
            ...

    Note that ``IndexExpression.Std`` is only defined during ``TYPE_CHECKING``, depending
    on the Python version used either ``from __future__ import annotations`` or
    ``def function(...) -> "IndexExpression.Std"`` may be required to ensure that annotations
    are resolved lazily without an actual object present.
    """

    if TYPE_CHECKING:
        type Std = IndexExpression
        """Type hint for all subtypes of ``IndexExpression`` according to the specification"""

R = TypeVar("R", bound=Relationship)
"""Generic ``Relationship`` type variable"""

M = TypeVar("M", bound=Element)
"""Generic ``Element`` type variable"""

class LazyImportsIterator[T: Element](LazyIterator[T]):
    """
    An internally iterated generator for ``Element`` attributes that may include
    imported members.

    .. code-block:: python

        for member in package.members.with_import_filter(...).collect():
            ...

    Evaluation of import filters requires an explicit evaluator function because
    the model is treated as a data structure. It has no knowledge of expression evaluation
    semantics. In addition, this allows reusing virtual machines between different
    methods for improved performance.
    """

    def with_import_filter(self, arg: CompilerFilter | Callable[[Element, list[Expression]], bool], /) -> LazyImportsIterator[T]:
        """
        Use the provided function to evaluate import filters.

        Note that this creates a copy of ``self`` with the new ``filter`` function.
        """

class CompilerFilter:
    """
    A ``LazyImportsIterator`` compatible import filter evaluator.

    This class allows the filter to skip expensive Python marshalling
    during filter evaluation to improve performance in the common case.

    Note that because the specification requires all filter expressions to be model-level
    evaluable, invocations of functions is an error.
    """

    def __init__(self, compiler: Compiler, lib: Stdlib, reporter: Callable[[Element, Diagnostic], None] = ...) -> None:
        """
        Construct a new filter evaluator with a given ``compiler`` and ``lib``.

        ``reporter`` is optional and is used to propagate any diagnostics from filter
        expression evaluation. By default, a ``RuntimeWarning`` is emitted on diagnostics.

        ``lib`` is used to provide the ``compiler`` with standard library context required
        for metadata and reflection evaluation.
        """

    @property
    def compiler(self) -> Compiler:
        """The compiler used to evaluate filter expressions."""

    @compiler.setter
    def compiler(self, arg: Compiler, /) -> None: ...

    @property
    def lib(self) -> Stdlib:
        """
        The standard library context used in filter expression evaluation.

        This is required for reflection to be evaluated.
        """

    @lib.setter
    def lib(self, arg: Stdlib, /) -> None: ...

    @property
    def reporter(self) -> Callable[[Element, Diagnostic], None]:
        """
        Callback used to propagate diagnostics from filter expression evaluation.

        The signature is ``(source: Element, diagnostic: Diagnostic) -> None``, where
        ``source`` is the element the ``diagnostic`` originates from.

        By default, this emits a ``RuntimeWarning`` for each diagnostic.
        """

    @reporter.setter
    def reporter(self, arg: Callable[[Element, Diagnostic], None], /) -> None: ...

    def __call__(self, arg0: Element, arg1: Sequence[Expression], /) -> bool:
        """Evaluate conjunction of filter ``conditions`` on an element target."""

class ChildrenNodesView(Generic[R, M]):
    """A view to a container of children nodes."""

    @property
    def relationships(self) -> ContainerView[R]:
        """The relationships in this container."""

    @property
    def elements(self) -> ContainerView[M]:
        """The related elements in this container."""

    def __len__(self) -> int: ...

    def __bool__(self) -> bool: ...

    def __getitem__(self, arg: int, /) -> Tuple[R, M]: ...

    def at(self, arg: int, /) -> Tuple[R, M] | None:
        """
        Get tuple of ``(relationship, element)`` at ``index``.

        Returns ``None`` if ``index`` is out-of-bounds.
        """

class NameID(enum.Enum):
    """
    The identifier used to reference the element in the textual syntax.

    This may be used to select the printed identifier for synthetic references
    when printing the model back to textual syntax.
    """

    Regular = 1
    """Reference element by its regular ID"""

    Short = 0
    """Reference element by its short ID"""

class ChildrenNodes(ChildrenNodesView[R, M]):
    """
    Container that stores a vector of children nodes.

    This is the primary object to modify the model through. In order to maintain type invariants,
    relationships can only be constructed internally by this container using the provided relationship type.
    The related element type is then checked against the types supported by the relationship and the container.
    However, due to limitations in the Python type system, this check can only be done at runtime. In addition,
    type system limitations do not allow generic ``TypeVar`` constraints which prevents fully resolved return types
    in this generic implementation.
    """

    def reserve(self, arg: int, /) -> None:
        """Increase the capacity of the container. Size is not changed."""

    def clear(self) -> None:
        """Clear all nodes from this container. Size is reset to 0 afterwards."""

    def append(self, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Append a new *owned* or *referenced* element, inferred from the relationship type and this container. Returns a
        pair of (relationship, element), only the relationship is newly constructed.
        """

    def replace(self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element may be *owned* or *referenced*
        depending on the relationship type and this container, see ``append`` for more details.
        """

    def insert(self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element may be *owned* or
        *referenced* depending on the relationship type and this container, see ``append`` for more details.
        """

    def pop(self, index: int = -1) -> tuple[R, M]:
        """
        Removes and returns a pair (relationship, element) from this container at the specified index. The relationship
        may be reused internally when constructing a new relationship of the same type, while the related element will
        only be reused if it was and owned related element. In this case, the related element may be assigned to a new
        owner in the same document. Note that removed owned related elements will have all the elements in the subtree
        removed as well.
        """

    def remove_relationship(self, arg: R, /) -> bool:
        """
        Removes a relationship and its related element from this container. Returns ``True`` if the relationship was
        removed, and ``False`` otherwise. Note that removed owned related elements will have all the elements in the
        subtree removed as well.
        """

    def remove_element(self, arg: M, /) -> bool:
        """
        Removes a related element from this container. Returns ``True`` if the related element was removed, and ``False``
        otherwise. Note that removed owned related elements will have all the elements in the subtree
        removed as well.
        """

    def extract(self, index: int = -1) -> M:
        """
        Extracts and returns the element from this container at the specified index without clearing its subtree. The
        relationship may be reused internally when constructing a new relationship of the same type, while the related
        element will not.

        Note that it is up to the user to ensure that the returned orphan element is not leaked.

        Raises ``IndexError`` if index is out of bounds.
        """

    def extract_with_relationship(self, arg: R, /) -> M:
        """
        Removes a relationship and extracts its related element from this container without clearing its subtree.

        Note that it is up to the user to ensure that the returned orphan element is not leaked.

        Raises ``ValueError`` if there is no such relationship.
        """

    def extract_element(self, arg: M, /) -> M:
        """
        Extracts a related element from this container without clearing its subtree.

        Note that it is up to the user to ensure that the returned orphan element is not leaked.

        Raises ``ValueError`` if there is no such related element.
        """

class OwnedChildrenNodes(ChildrenNodes[R, M]):
    """Container that stores a vector of potentially owned children nodes."""

    @overload
    def append(self, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Append a new *owned* or *referenced* element, inferred from the relationship type and this container. Returns a
        pair of (relationship, element), only the relationship is newly constructed.
        """

    @overload
    def append(self, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Append a new *owned* element. Relationship must be a subtype of ``OwningMembership`` or ``Annotation``. Returns a
        newly constructed pair of (relationship, element) with the types provided.
        """

    @overload
    def replace(self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element may be *owned* or *referenced*
        depending on the relationship type and this container, see ``append`` for more details.
        """

    @overload
    def replace(self, index: int, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element must be *owned* so the same owning
        ``append`` limitations apply.
        """

    @overload
    def insert(self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element may be *owned* or
        *referenced* depending on the relationship type and this container, see ``append`` for more details.
        """

    @overload
    def insert(self, index: int, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element must be *owned* so the
        same owning ``append`` limitations apply.
        """

class ChainedChildrenNodes(ChildrenNodes[R, M]):
    """
    Container that stores a vector of children nodes that may own feature chainings.
    """

    def append_chain(self, relationship: type[R], features: Sequence[Feature]) -> tuple[R, Feature]:
        """
        Append a relationship with an owned chaining. Raises ``TypeError`` if the relationship type cannot have owned
        chaining in the textual syntax.
        """

    def insert_chain(self, index: int, relationship: type[R], features: Sequence[Feature]) -> tuple[R, Feature]:
        """
        Insert a relationship with an owned chaining at the specified index. Raises ``TypeError`` if the relationship
        type cannot have owned chaining in the textual syntax.
        """

    def replace_chain_at(self, index: int, relationship: type[R], features: Sequence[Feature]) -> tuple[R, Feature]:
        """
        Replace the relationship and its related element at the specified index with an owned chaining. The relationship
        may be reused if its type matches the current relationship at that index. Raises ``TypeError`` if the
        relationship type cannot have owned chaining in the textual syntax.
        """

class RelationshipBody(ContainerView[Element]):
    """
    Container for relationship bodies. Works similarly to ``ChildrenNodes`` except
    relationships are not needed and all elements are taken ownership off.

    TODO: add insert and replace methods.
    """

    @overload
    def append(self, element: type[TElement]) -> TElement:
        """
        Append an owned related element. Returns newly constructed related element.
        """

    @overload
    def append(self, element: TElement) -> TElement:
        """
        Append an owned existing related element. Returns the same related element.
        """

    @overload
    def append_annotation[M: AnnotatingElement | MetadataUsage | MetadataFeature](self, element: type[M]) -> tuple[Annotation, M]:
        """
        Append an owned annotation to an annotating element. Returns a pair of newly constructed
        (annotation, annotating element).
        """

    @overload
    def append_annotation[M: AnnotatingElement | MetadataUsage | MetadataFeature](self, element: M) -> tuple[Annotation, M]:
        """
        Append an owned annotation to an existing annotating element. Returns a pair of
        (annotation, annotating element) where only the annotation is newly constructed.
        """

    def pop(self, index: int = -1) -> Element:
        """
        Removes a related element at the specified index from the model tree and returns it.
        """

    def remove_element(self, arg: Element, /) -> bool:
        """
        Removes a related element from the model tree. Returns ``True`` if the element was
        removed, otherwise ``False``.
        """

    def extract(self, index: int = -1) -> Element:
        """
        Extracts a related element at the specified index from the model tree and returns it.

        Note that it is up to the user to ensure that the returned orphan element is not leaked.

        Raises ``IndexError`` if index is out of bounds.
        """

    def extract_element[T: Element](self, arg: T, /) -> T:
        """
        Extracts a related element from the model tree.

        Note that it is up to the user to ensure that the returned orphan element is not leaked.

        Raises ``ValueError`` if there is no such element.
        """

    def clear(self) -> None:
        """
        Removes and releases all elements in this container. Afterwards, ``len`` is 0.
        """

class DependencyEnds(ContainerView[Element]):
    """An accessor for dependency ``client`` and ``supplier`` references."""

    def append(self, element: Element, name: NameID = NameID.Regular) -> None:
        """Append a new reference to this container."""

    def replace_at(self, index: int, element: Element, name: NameID = NameID.Regular) -> Element:
        """
        Replace reference element at ``index`` with ``element``. Returns the previously referenced element.

        Raises ``IndexError`` if ``index`` is out-of-bounds.
        """

    def pop(self, index: int = -1) -> Element:
        """
        Pop and return the reference element at ``index``. By default, the last reference is popped.

        Raises ``ValueError`` if the ``index`` is out of bounds.
        """

    def remove(self, arg: Element, /) -> bool:
        """
        Remove the referenced element. Returns ``True`` if the element was removed, and ``False`` otherwise.
        """

    def clear(self) -> None:
        """
        Clear all references from this container.

        Note that empty references cannot be represented in textual syntax, and is a semantic violation.
        """

class MemberAccessor(Generic[R, M]):
    """An accessor for specific member elements"""

    @property
    def membership(self) -> R:
        """The ``membership`` of this ``member`` if it is not empty."""

    @property
    def member_element(self) -> M:
        """The ``member_element`` of this ``member`` if it is not empty."""

    @overload
    def set_member_element(self, element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Set a new ``member_element``.

        ``element`` will only be referenced if the ``membership`` is ``Membership``, otherwise ownership
        constraints apply. Replaces the previous ``member_element``, which may be reused by
        the model if it was owned.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element(self, element: M | None, name: NameID = ...) -> tuple[R, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    def remove_member_element(self) -> None:
        """
        Remove the ``member_element`` leaving this ``member`` empty.

        Note that not all empty ``members`` are valid textual syntax.
        This does not check that the model is left in a valid state.
        """

    def extract_member_element(self) -> M:
        """
        Extract the ``member_element`` leaving this ``member`` empty.

        Note that not all empty ``members`` are valid textual syntax.
        This does not check that the model is left in a valid state.

        Note that it is up to the user to ensure that the returned orphan element is not leaked.

        Raises ``ValueError`` if member is empty.
        """

    def __bool__(self) -> bool: ...

class OwnedMemberAccessor[R: OwningMembership, M: Element](MemberAccessor[R, M]):
    """An accessor for specific owned member elements"""

    @overload
    def set_member_element(self, element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply.

        Replaces the previous ``member_element``, which may be reused by the model.
        ``name_id`` has no effect since the ``element`` is always taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element(self, element: M | None, name: NameID = ...) -> tuple[R, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element(self, arg: type[M], /) -> tuple[R, M]:
        """
        Constructs a new empty ``member_element`` with the provided type.

        Replaces the previous ``member_element``. Because a new element is always constructed,
        ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

    def add_member_element(self) -> tuple[R, M]:
        """
        Constructs a new ``member_element`` with the default type if this ``member`` is empty, otherwise does nothing.

        Returns a pair of (``membership``, ``member_element``)
        """

class ParameterAccessor(OwnedMemberAccessor[ParameterMembership, ReferenceUsage]):
    """A typed accessor for some parameter members"""

    @property
    def argument(self) -> Expression | None:
        """The ``argument`` accessible by this ``parameter``."""

    @overload
    def set_argument[M: Expression](self, expression: M) -> tuple[FeatureValue, M]:
        """
        Set the ``argument`` to an owned ``expression``. Ownership constraints apply. An empty
        parameter will be constructed if there is none.

        Returns a pair of (``feature_value``, ``argument``).
        """

    @overload
    def set_argument[M: Expression](self, expression: M | None) -> tuple[FeatureValue, M] | None:
        """
        ``set_argument`` overload that will instead remove the argument if ``expression is None`` and return ``None``.
        Otherwise behaviour is the same.
        """

    @overload
    def set_argument[M: Expression](self, expression: type[M]) -> tuple[FeatureValue, M]:
        """
        Set the ``argument`` to an empty ``Expression`` with the corresponding type. An empty
        parameter will be constructed if there is none.

        Returns a pair of (``feature_value``, ``argument``).
        """

    def remove_argument(self) -> None:
        """
        Remove the ``argument`` while leaving ``parameter`` intact. Does nothing if there is no ``argument``.
        """

    def extract_argument(self) -> Expression:
        """
        Extract the ``argument`` while leaving ``parameter`` intact. Raises ``ValueError`` if there is no ``argument``.

        Note that it is up to the user to ensure that the returned orphan element is not leaked.
        """

    @overload
    def set_member_element[M: ReferenceUsage](self, element: M, name: NameID = ...) -> tuple[ParameterMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply.

        Replaces the previous ``member_element``, which may be reused by the model.
        ``name_id`` has no effect since the ``element`` is always taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: ReferenceUsage](self, element: M | None, name: NameID = ...) -> tuple[ParameterMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: ReferenceUsage](self, element: type[M]) -> tuple[ParameterMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type.

        Replaces the previous ``member_element``. Because a new element is always constructed,
        ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class ChainedMemberAccessor[R: Membership, M: Feature](MemberAccessor[R, M]):
    """
    An accessor for potentially unowned member features that may be also chained
    """

    def set_member_element_chain(self, arg: Sequence[Feature], /) -> tuple[OwningMembership, Feature]:
        """
        Set the reference to a chain of ``Features``. Replaces the previous ``member_element``.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is the ``Feature``
        with owned ``FeatureChainings`` to the provided ``Features`` with order preserved.
        """

class ReferenceAccessor(Generic[M]):
    """A generic accessor for references in the model"""

    @property
    def element(self) -> Element | None:
        """
        Returns the referenced ``Element``.

        This may return ``None``, e.g. when reference resolution failed,
        although in most such cases a placeholder element will be returned instead.
        """

    @property
    def modifiable(self) -> bool:
        """
        Returns ``True`` if this reference can be modified, that is the owning ``Relationship`` is an owned member
        of a ``Namespace``.

        Calling ``set`` methods when ``modifiable == False`` will raise ``ValueError``.
        """

    def try_set(self, element: M, name: NameID = ...) -> M | None:
        """
        Try changing the referenced ``element``. Returns ``None`` if this reference cannot be modified, otherwise
        returns ``element`` argument.
        """

    def set(self, element: M, name: NameID = ...) -> M:
        """
        ``try_set`` but instead raises ``ValueError`` if this reference cannot be modified.
        """

class ChainedReferenceAccessor(ReferenceAccessor[M]):
    """An accessor for reference that may also be chained"""

    def try_set_chain(self, arg: Sequence[Feature], /) -> Feature | None:
        """
        Try changing the referenced ``element`` to a chain of ``Features``.

        Returns ``None`` if this reference cannot be modified, otherwise returns a
        new owned ``Feature`` that chains all ``Features`` in order.
        """

    def set_chain(self, arg: Sequence[Feature], /) -> Feature:
        """
        ``try_set_chain`` but instead raises ``ValueError`` if this reference cannot be modified.
        """

class ConnectorEndsAccessor[R: FeatureMembership, M: Feature](ChildrenNodesView[R, M]):
    """An accessor for ends in connector declarations"""

    @property
    def modifiable(self) -> bool:
        """
        Returns ``True`` if the contents of this accessor can be modified.

        In such a case, ``try_`` methods will return values, and corresponding modification
        methods will not raise ``ValueErrors``.

        ``False`` is returned when the corresponding textual syntax position is already occupied by other elements,
        e.g. ``FlowUsage`` ``declared_messages`` and ``declared_ends`` share the same position.
        """

    @overload
    def try_append(self, arg0: M, /) -> tuple[R, M] | None:
        """
        Try appending a new ``Feature``. Ownership constraints apply.

        Returns a pair of (``membership``, ``feature``) where ``feature`` is the argument passed in if the contents
        can be modified. Note that generally empty ``Features`` are not syntactically correct, and the correct
        syntax depends on the owner type.
        """

    @overload
    def try_append(self) -> tuple[R, M] | None:
        """
        Try appending a new default constructed ``Feature`` with type inferred from the corresponding member
        type in the textual syntax dependent on the owner of this accessor.

        Returns a pair of (``membership``, ``feature``) if the contents can be modified. Note that generally empty
        ``Features`` are not syntactically correct, and the correct syntax depends on the owner type.
        """

    @overload
    def try_insert(self, arg0: int, arg1: M, /) -> tuple[R, M] | None:
        """
        Try inserting a new ``Feature`` at the specified index. Ownership constraints apply.

        Returns a pair of (``membership``, ``feature``) where ``feature`` is the argument passed in if the contents
        can be modified. Note that generally empty ``Features`` are not syntactically correct, and the correct
        syntax depends on the owner type.
        """

    @overload
    def try_insert(self, arg0: int, /) -> tuple[R, M] | None:
        """
        Try inserting a new default constructed ``Feature`` at the index specified with type inferred from the corresponding member
        type in the textual syntax dependent on the owner of this accessor.

        Returns a pair of (``membership``, ``feature``) if the contents can be modified. Note that generally empty
        ``Features`` are not syntactically correct, and the correct syntax depends on the owner type.
        """

    @overload
    def append(self, arg0: M, /) -> tuple[R, M]:
        """
        Same as ``try_append`` but will raise ``ValueError`` if the contents cannot be modified.
        """

    @overload
    def append(self, /) -> tuple[R, M]: ...

    @overload
    def insert(self, arg0: int, arg1: M, /) -> tuple[R, M]:
        """
        Same as ``insert`` but will raise ``ValueError`` if the contents cannot be modified.
        """

    @overload
    def insert(self, arg0: int, /) -> tuple[R, M]: ...

    def clear(self) -> None:
        """
        Clear the contents accessed by this accessor. Does nothing if the contents cannot be modified.
        """

    def erase(self, arg: int, /) -> None:
        """
        Erase ``Feature`` at the specified index. Raises ``IndexError`` if the index is out of bounds.
        """

    def extract(self, arg0: int, /) -> M:
        """
        Extract ``Feature`` at the specified index. Raises ``IndexError`` if the index is out of bounds.
        """

class ReferentAccessor(MemberAccessor[Membership, Feature]):
    """An accessor for feature reference expression referent member"""

    @overload
    def set_member_element[M: Feature](self, element: M, name: NameID = ...) -> tuple[Membership, M]:
        """
        Set a new ``member_element``.

        ``element`` will only be referenced if the ``membership`` is ``Membership``, otherwise ownership
        constraints apply. Replaces the previous ``member_element``, which may be reused by
        the model if it was owned.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: Feature](self, element: M | None, name: NameID = ...) -> tuple[Membership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_owned_expression[M: Expression](self, arg: M, /) -> tuple[FeatureMembership, M]:
        """
        Set the referent to an owned ``Expression``. Ownership constraints apply.

        Returns a pair of (``feature_membership``, ``referent``).
        """

    @overload
    def set_owned_expression[M: Expression](self, arg: type[M], /) -> tuple[FeatureMembership, M]:
        """
        Set the referent to an empty ``Expression`` with the corresponding type.

        Returns a pair of (``feature_membership``, ``referent``). Note that empty
        ``Expressions`` may not be representable in textual syntax.
        """

class SatisfactionSubjectAccessor(OwnedMemberAccessor[SubjectMembership, ReferenceUsage]):
    """
    A typed accessor for satisfaction subject of ``SatisfyRequirementUsage``.
    """

    @overload
    def set_member_element[M: ReferenceUsage](self, element: M, name: NameID = ...) -> tuple[SubjectMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply.

        Replaces the previous ``member_element``, which may be reused by the model.
        ``name_id`` has no effect since the ``element`` is always taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: ReferenceUsage](self, element: M | None, name: NameID = ...) -> tuple[SubjectMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: ReferenceUsage](self, element: type[M]) -> tuple[SubjectMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type.

        Replaces the previous ``member_element``. Because a new element is always constructed,
        ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

    @property
    def target(self) -> Feature | None:
        """The target of this satisfaction subject."""

    @overload
    def set_target[T: Feature](self, element: T, name: NameID = ...) -> tuple[Membership, T]:
        """
        Set the target to a referenced ``Feature``.

        Returns a pair of (``membership``, ``target``).
        """

    @overload
    def set_target[T: Feature](self, element: T | None, name: NameID = ...) -> tuple[Membership, T] | None:
        """
        ``set_target`` overload that will remove the target element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    def set_target_chain(self, arg: Sequence[Feature], /) -> tuple[OwningMembership, Feature]:
        """
        Set the reference to a chain of ``Features``. Replaces the previous ``target``.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is the ``Feature``
        with owned ``FeatureChainings`` to the provided ``Features`` with order preserved.
        """

class ArgumentsAccessor(LazyIterator[Expression]):
    """
    A convencience accessor for instantiation arguments.

    This is a wrapper around ``LazyIterator`` that additionally allows appending new
    arguments without having to create intermediate features. Arguments are input feature
    value expressions from:

    - ``InvocationExpression.children``
    - ``ConstructorExpression.result.children``

    Arguments can be removed by removing elements from the corresponding ``children``
    containers.
    """

    @overload
    def append[M: Expression](self, arg: M, /) -> tuple[FeatureValue, M]:
        """
        Append a new invocation ``argument``.

        This takes care of constructing any intermediate elements.

        Returns a pair of (``feature_value``, ``argument``).
        """

    @overload
    def append[M: Expression](self, arg: type[M], /) -> tuple[FeatureValue, M]:
        """
        Append a new invocation ``argument`` with the corresponding type.

        This takes care of constructing any intermediate elements.

        Returns a pair of (``feature_value``, ``argument``).
        """

class ElementAccessor(MemberAccessor[Membership, Element]):
    """A typed accessor for unowned member elements"""

    @overload
    def set_member_element[M: Element](self, element: M, name: NameID = ...) -> tuple[Membership, M]:
        """
        Set a new ``member_element``.

        ``element`` will only be referenced if the ``membership`` is ``Membership``, otherwise ownership
        constraints apply. Replaces the previous ``member_element``, which may be reused by
        the model if it was owned.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: Element](self, element: M | None, name: NameID = ...) -> tuple[Membership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

class PayloadFeatureAccessor(OwnedMemberAccessor[FeatureMembership, PayloadFeature]):
    """A typed accessor for flow payload features"""

    @overload
    def set_member_element[M: PayloadFeature](self, element: M, name: NameID = ...) -> tuple[FeatureMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply.

        Replaces the previous ``member_element``, which may be reused by the model.
        ``name_id`` has no effect since the ``element`` is always taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: PayloadFeature](self, element: M | None, name: NameID = ...) -> tuple[FeatureMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: PayloadFeature](self, element: type[M]) -> tuple[FeatureMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type.

        Replaces the previous ``member_element``. Because a new element is always constructed,
        ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class ResultExpressionAccessor(OwnedMemberAccessor[ResultExpressionMembership, Expression]):
    """A typed accessor for function and expression result members"""

    @overload
    def set_member_element[M: Expression](self, element: M, name: NameID = ...) -> tuple[ResultExpressionMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply.

        Replaces the previous ``member_element``, which may be reused by the model.
        ``name_id`` has no effect since the ``element`` is always taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: Expression](self, element: M | None, name: NameID = ...) -> tuple[ResultExpressionMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: Expression](self, element: type[M]) -> tuple[ResultExpressionMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type.

        Replaces the previous ``member_element``. Because a new element is always constructed,
        ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class ReferenceParameterAccessor(OwnedMemberAccessor[ParameterMembership, ReferenceUsage]):
    """A typed accessor for various parameter members"""

    @overload
    def set_member_element[M: ReferenceUsage](self, element: M, name: NameID = ...) -> tuple[ParameterMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply.

        Replaces the previous ``member_element``, which may be reused by the model.
        ``name_id`` has no effect since the ``element`` is always taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: ReferenceUsage](self, element: M | None, name: NameID = ...) -> tuple[ParameterMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: ReferenceUsage](self, element: type[M]) -> tuple[ParameterMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type.

        Replaces the previous ``member_element``. Because a new element is always constructed,
        ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class ChainedFeatureMemberAccessor(ChainedMemberAccessor[Membership, Feature]):
    """
    A typed accessor for potentially unowned member features that may be also chained
    """

    @overload
    def set_member_element[M: Feature](self, element: M, name: NameID = ...) -> tuple[Membership, M]:
        """
        Set a new ``member_element``.

        ``element`` will only be referenced if the ``membership`` is ``Membership``, otherwise ownership
        constraints apply. Replaces the previous ``member_element``, which may be reused by
        the model if it was owned.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: Feature](self, element: M | None, name: NameID = ...) -> tuple[Membership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

class FeatureValueAccessor(OwnedMemberAccessor[FeatureValue, Expression]):
    """A typed accessor for feature value members"""

    @overload
    def set_member_element[M: Expression](self, element: M, name: NameID = ...) -> tuple[FeatureValue, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply.

        Replaces the previous ``member_element``, which may be reused by the model.
        ``name_id`` has no effect since the ``element`` is always taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: Expression](self, element: M | None, name: NameID = ...) -> tuple[FeatureValue, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: Expression](self, element: type[M]) -> tuple[FeatureValue, M]:
        """
        Constructs a new empty ``member_element`` with the provided type.

        Replaces the previous ``member_element``. Because a new element is always constructed,
        ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class ReferenceUsageAccessor(OwnedMemberAccessor[FeatureMembership, ReferenceUsage]):
    """A typed accessor for some reference usage members"""

    @overload
    def set_member_element[M: ReferenceUsage](self, element: M, name: NameID = ...) -> tuple[FeatureMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply.

        Replaces the previous ``member_element``, which may be reused by the model.
        ``name_id`` has no effect since the ``element`` is always taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: ReferenceUsage](self, element: M | None, name: NameID = ...) -> tuple[FeatureMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: ReferenceUsage](self, element: type[M]) -> tuple[FeatureMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type.

        Replaces the previous ``member_element``. Because a new element is always constructed,
        ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class ExpressionParameterAccessor(OwnedMemberAccessor[ParameterMembership, Expression]):
    """A typed accessor for parameter expression members"""

    @overload
    def set_member_element[M: Expression](self, element: M, name: NameID = ...) -> tuple[ParameterMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply.

        Replaces the previous ``member_element``, which may be reused by the model.
        ``name_id`` has no effect since the ``element`` is always taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: Expression](self, element: M | None, name: NameID = ...) -> tuple[ParameterMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: Expression](self, element: type[M]) -> tuple[ParameterMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type.

        Replaces the previous ``member_element``. Because a new element is always constructed,
        ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class ActionParameterAccessor(OwnedMemberAccessor[ParameterMembership, ActionUsage]):
    """A typed accessor for parameter action bodies"""

    @overload
    def set_member_element[M: ActionUsage](self, element: M, name: NameID = ...) -> tuple[ParameterMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply.

        Replaces the previous ``member_element``, which may be reused by the model.
        ``name_id`` has no effect since the ``element`` is always taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: ActionUsage](self, element: M | None, name: NameID = ...) -> tuple[ParameterMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: ActionUsage](self, element: type[M]) -> tuple[ParameterMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type.

        Replaces the previous ``member_element``. Because a new element is always constructed,
        ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class OwnedExpressionAccessor(OwnedMemberAccessor[OwningMembership, Expression]):
    """A typed accessor for multiplicity range bounds expression"""

    @overload
    def set_member_element[M: Expression](self, element: M, name: NameID = ...) -> tuple[OwningMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply.

        Replaces the previous ``member_element``, which may be reused by the model.
        ``name_id`` has no effect since the ``element`` is always taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: Expression](self, element: M | None, name: NameID = ...) -> tuple[OwningMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: Expression](self, element: type[M]) -> tuple[OwningMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type.

        Replaces the previous ``member_element``. Because a new element is always constructed,
        ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class TriggerAccessor(OwnedMemberAccessor[TransitionFeatureMembership, AcceptActionUsage]):
    """A typed accessor for transition triggers"""

    @overload
    def set_member_element[M: AcceptActionUsage](self, element: M, name: NameID = ...) -> tuple[TransitionFeatureMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply.

        Replaces the previous ``member_element``, which may be reused by the model.
        ``name_id`` has no effect since the ``element`` is always taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: AcceptActionUsage](self, element: M | None, name: NameID = ...) -> tuple[TransitionFeatureMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: AcceptActionUsage](self, element: type[M]) -> tuple[TransitionFeatureMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type.

        Replaces the previous ``member_element``. Because a new element is always constructed,
        ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class GuardAccessor(OwnedMemberAccessor[TransitionFeatureMembership, Expression]):
    """A typed accessor for transition guards"""

    @overload
    def set_member_element[M: Expression](self, element: M, name: NameID = ...) -> tuple[TransitionFeatureMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply.

        Replaces the previous ``member_element``, which may be reused by the model.
        ``name_id`` has no effect since the ``element`` is always taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: Expression](self, element: M | None, name: NameID = ...) -> tuple[TransitionFeatureMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: Expression](self, element: type[M]) -> tuple[TransitionFeatureMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type.

        Replaces the previous ``member_element``. Because a new element is always constructed,
        ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class EffectAccessor(OwnedMemberAccessor[TransitionFeatureMembership, ActionUsage]):
    """A typed accessor for transition effects"""

    @overload
    def set_member_element[M: ActionUsage](self, element: M, name: NameID = ...) -> tuple[TransitionFeatureMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply.

        Replaces the previous ``member_element``, which may be reused by the model.
        ``name_id`` has no effect since the ``element`` is always taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: ActionUsage](self, element: M | None, name: NameID = ...) -> tuple[TransitionFeatureMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: ActionUsage](self, element: type[M]) -> tuple[TransitionFeatureMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type.

        Replaces the previous ``member_element``. Because a new element is always constructed,
        ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class OwnedSuccessionAccessor(OwnedMemberAccessor[OwningMembership, SuccessionAsUsage]):
    """A typed accessor for transition succession"""

    @overload
    def set_member_element[M: SuccessionAsUsage](self, element: M, name: NameID = ...) -> tuple[OwningMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply.

        Replaces the previous ``member_element``, which may be reused by the model.
        ``name_id`` has no effect since the ``element`` is always taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: SuccessionAsUsage](self, element: M | None, name: NameID = ...) -> tuple[OwningMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: SuccessionAsUsage](self, element: type[M]) -> tuple[OwningMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type.

        Replaces the previous ``member_element``. Because a new element is always constructed,
        ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class OwnedMultiplicityAccessor(OwnedMemberAccessor[OwningMembership, MultiplicityRange]):
    """A typed accessor for multiplicity in ``Type``  declaration"""

    @overload
    def set_member_element[M: MultiplicityRange](self, element: M, name: NameID = ...) -> tuple[OwningMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply.

        Replaces the previous ``member_element``, which may be reused by the model.
        ``name_id`` has no effect since the ``element`` is always taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: MultiplicityRange](self, element: M | None, name: NameID = ...) -> tuple[OwningMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: MultiplicityRange](self, element: type[M]) -> tuple[OwningMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type.

        Replaces the previous ``member_element``. Because a new element is always constructed,
        ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class OwnedFeatureAccessor(OwnedMemberAccessor[OwningMembership, Feature]):
    """A typed accessor for some owned member features"""

    @overload
    def set_member_element[M: Feature](self, element: M, name: NameID = ...) -> tuple[OwningMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply.

        Replaces the previous ``member_element``, which may be reused by the model.
        ``name_id`` has no effect since the ``element`` is always taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: Feature](self, element: M | None, name: NameID = ...) -> tuple[OwningMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: Feature](self, element: type[M]) -> tuple[OwningMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type.

        Replaces the previous ``member_element``. Because a new element is always constructed,
        ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class TargetFeatureAccessor(ChainedMemberAccessor[Membership, Feature]):
    """
    A typed accessor for target feature member in feature chain expressions
    """

    @overload
    def set_member_element[M: Feature](self, element: M, name: NameID = ...) -> tuple[Membership, M]:
        """
        Set a new ``member_element``.

        ``element`` will only be referenced if the ``membership`` is ``Membership``, otherwise ownership
        constraints apply. Replaces the previous ``member_element``, which may be reused by
        the model if it was owned.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: Feature](self, element: M | None, name: NameID = ...) -> tuple[Membership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

class TransitionSourceAccessor(ChainedMemberAccessor[Membership, ActionUsage]):
    """A typed accessor for transition source"""

    @overload
    def set_member_element[M: ActionUsage](self, element: M, name: NameID = ...) -> tuple[Membership, M]:
        """
        Set a new ``member_element``.

        ``element`` will only be referenced if the ``membership`` is ``Membership``, otherwise ownership
        constraints apply. Replaces the previous ``member_element``, which may be reused by
        the model if it was owned.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: ActionUsage](self, element: M | None, name: NameID = ...) -> tuple[Membership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    def target(self) -> ActionUsage | None:
        """
        The feature target of this source member after following owned chaining if any.
        """

class TypeReference(ReferenceAccessor[Type]):
    """A typed accessor for type reference"""

    def try_set[M: Type](self, element: M, name: NameID = ...) -> M | None:
        """
        Try changing the referenced ``element``. Returns ``None`` if this reference cannot be modified, otherwise
        returns ``element`` argument.
        """

    def set[M: Type](self, element: M, name: NameID = ...) -> M:
        """
        ``try_set`` but instead raises ``ValueError`` if this reference cannot be modified.
        """

class FeatureReference(ReferenceAccessor[Feature]):
    """A typed accessor for feature reference"""

    def try_set[M: Feature](self, element: M, name: NameID = ...) -> M | None:
        """
        Try changing the referenced ``element``. Returns ``None`` if this reference cannot be modified, otherwise
        returns ``element`` argument.
        """

    def set[M: Feature](self, element: M, name: NameID = ...) -> M:
        """
        ``try_set`` but instead raises ``ValueError`` if this reference cannot be modified.
        """

class ClassifierReference(ReferenceAccessor[Classifier]):
    """A typed accessor for classifier reference"""

    def try_set[M: Classifier](self, element: M, name: NameID = ...) -> M | None:
        """
        Try changing the referenced ``element``. Returns ``None`` if this reference cannot be modified, otherwise
        returns ``element`` argument.
        """

    def set[M: Classifier](self, element: M, name: NameID = ...) -> M:
        """
        ``try_set`` but instead raises ``ValueError`` if this reference cannot be modified.
        """

class ConnectorEnds(ConnectorEndsAccessor[EndFeatureMembership, Feature]):
    """An accessor for ends in ``Connector`` declaration"""

class ConnectorAsUsageEnds(ConnectorEndsAccessor[EndFeatureMembership, Feature]):
    """An accessor for ends in ``ConnectorAsUsage`` declaration"""

class Messages(ConnectorEndsAccessor[ParameterMembership, EventOccurrenceUsage]):
    """An accessor for messages in ``FlowUsage`` declaration"""

class ChainedTypeReference(ChainedReferenceAccessor[Type]):
    """A typed accessor for type reference that may also be chained"""

    def try_set[M: Type](self, element: M, name: NameID = ...) -> M | None:
        """
        Try changing the referenced ``element``. Returns ``None`` if this reference cannot be modified, otherwise
        returns ``element`` argument.
        """

    def set[M: Type](self, element: M, name: NameID = ...) -> M:
        """
        ``try_set`` but instead raises ``ValueError`` if this reference cannot be modified.
        """

class ChainedFeatureReference(ChainedReferenceAccessor[Feature]):
    """A typed accessor for feature reference that may also be chained"""

    def try_set[M: Feature](self, element: M, name: NameID = ...) -> M | None:
        """
        Try changing the referenced ``element``. Returns ``None`` if this reference cannot be modified, otherwise
        returns ``element`` argument.
        """

    def set[M: Feature](self, element: M, name: NameID = ...) -> M:
        """
        ``try_set`` but instead raises ``ValueError`` if this reference cannot be modified.
        """

class DependencyPrefixes(OwnedChildrenNodes[Annotation, MetadataFeature | MetadataUsage]):
    """An accessor for dependency metadata prefixes"""

    @overload
    def append[R: Annotation, M: MetadataFeature | MetadataUsage](self, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Append a new *owned* or *referenced* element, inferred from the relationship type and this container. Returns a
        pair of (relationship, element), only the relationship is newly constructed.
        """

    @overload
    def append[R: Annotation, M: MetadataFeature | MetadataUsage](self, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Append a new *owned* element. Relationship must be a subtype of ``OwningMembership`` or ``Annotation``. Returns a
        newly constructed pair of (relationship, element) with the types provided.
        """

    @overload
    def replace[R: Annotation, M: MetadataFeature | MetadataUsage](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element may be *owned* or *referenced*
        depending on the relationship type and this container, see ``append`` for more details.
        """

    @overload
    def replace[R: Annotation, M: MetadataFeature | MetadataUsage](self, index: int, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element must be *owned* so the same owning
        ``append`` limitations apply.
        """

    @overload
    def insert[R: Annotation, M: MetadataFeature | MetadataUsage](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element may be *owned* or
        *referenced* depending on the relationship type and this container, see ``append`` for more details.
        """

    @overload
    def insert[R: Annotation, M: MetadataFeature | MetadataUsage](self, index: int, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element must be *owned* so the
        same owning ``append`` limitations apply.
        """

class NamespacePrefixes(OwnedChildrenNodes[OwningMembership, MetadataFeature | MetadataUsage]):
    """An accessor for namespace metadata prefixes"""

    @overload
    def append[R: OwningMembership, M: MetadataFeature | MetadataUsage](self, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Append a new *owned* or *referenced* element, inferred from the relationship type and this container. Returns a
        pair of (relationship, element), only the relationship is newly constructed.
        """

    @overload
    def append[R: OwningMembership, M: MetadataFeature | MetadataUsage](self, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Append a new *owned* element. Relationship must be a subtype of ``OwningMembership`` or ``Annotation``. Returns a
        newly constructed pair of (relationship, element) with the types provided.
        """

    @overload
    def replace[R: OwningMembership, M: MetadataFeature | MetadataUsage](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element may be *owned* or *referenced*
        depending on the relationship type and this container, see ``append`` for more details.
        """

    @overload
    def replace[R: OwningMembership, M: MetadataFeature | MetadataUsage](self, index: int, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element must be *owned* so the same owning
        ``append`` limitations apply.
        """

    @overload
    def insert[R: OwningMembership, M: MetadataFeature | MetadataUsage](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element may be *owned* or
        *referenced* depending on the relationship type and this container, see ``append`` for more details.
        """

    @overload
    def insert[R: OwningMembership, M: MetadataFeature | MetadataUsage](self, index: int, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element must be *owned* so the
        same owning ``append`` limitations apply.
        """

class NamespaceBody(OwnedChildrenNodes[MembershipImport | NamespaceImport | Membership, Element]):
    """An accessor for namespace body"""

    @overload
    def append[R: MembershipImport | NamespaceImport | Membership, M: Element](self, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Append a new *owned* or *referenced* element, inferred from the relationship type and this container. Returns a
        pair of (relationship, element), only the relationship is newly constructed.
        """

    @overload
    def append[R: MembershipImport | NamespaceImport | Membership, M: Element](self, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Append a new *owned* element. Relationship must be a subtype of ``OwningMembership`` or ``Annotation``. Returns a
        newly constructed pair of (relationship, element) with the types provided.
        """

    @overload
    def replace[R: MembershipImport | NamespaceImport | Membership, M: Element](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element may be *owned* or *referenced*
        depending on the relationship type and this container, see ``append`` for more details.
        """

    @overload
    def replace[R: MembershipImport | NamespaceImport | Membership, M: Element](self, index: int, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element must be *owned* so the same owning
        ``append`` limitations apply.
        """

    @overload
    def insert[R: MembershipImport | NamespaceImport | Membership, M: Element](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element may be *owned* or
        *referenced* depending on the relationship type and this container, see ``append`` for more details.
        """

    @overload
    def insert[R: MembershipImport | NamespaceImport | Membership, M: Element](self, index: int, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element must be *owned* so the
        same owning ``append`` limitations apply.
        """

class Annotations(ChildrenNodes[Annotation, Element]):
    """An accessor for annotating element annotations"""

    def append[R: Annotation, M: Element](self, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Append a new *owned* or *referenced* element, inferred from the relationship type and this container. Returns a
        pair of (relationship, element), only the relationship is newly constructed.
        """

    def replace[R: Annotation, M: Element](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element may be *owned* or *referenced*
        depending on the relationship type and this container, see ``append`` for more details.
        """

    def insert[R: Annotation, M: Element](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element may be *owned* or
        *referenced* depending on the relationship type and this container, see ``append`` for more details.
        """

class Heritage(ChainedChildrenNodes[Conjugation | Specialization, Type]):
    """An accessor for type specializations and conjugations"""

    def append[R: Conjugation | Specialization, M: Type](self, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Append a new *owned* or *referenced* element, inferred from the relationship type and this container. Returns a
        pair of (relationship, element), only the relationship is newly constructed.
        """

    def replace[R: Conjugation | Specialization, M: Type](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element may be *owned* or *referenced*
        depending on the relationship type and this container, see ``append`` for more details.
        """

    def insert[R: Conjugation | Specialization, M: Type](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element may be *owned* or
        *referenced* depending on the relationship type and this container, see ``append`` for more details.
        """

    def append_chain[R: Conjugation | Specialization](self, relationship: type[R], features: Sequence[Feature]) -> tuple[R, Feature]:
        """
        Append a relationship with an owned chaining. Raises ``TypeError`` if the relationship type cannot have owned
        chaining in the textual syntax.
        """

    def insert_chain[R: Conjugation | Specialization](self, index: int, relationship: type[R], features: Sequence[Feature]) -> tuple[R, Feature]:
        """
        Insert a relationship with an owned chaining at the specified index. Raises ``TypeError`` if the relationship
        type cannot have owned chaining in the textual syntax.
        """

    def replace_chain_at[R: Conjugation | Specialization](self, index: int, relationship: type[R], features: Sequence[Feature]) -> tuple[R, Feature]:
        """
        Replace the relationship and its related element at the specified index with an owned chaining. The relationship
        may be reused if its type matches the current relationship at that index. Raises ``TypeError`` if the
        relationship type cannot have owned chaining in the textual syntax.
        """

class TypeRelationships(ChainedChildrenNodes[Unioning | Intersecting | Differencing | Disjoining | FeatureChaining | FeatureInverting | TypeFeaturing, Type]):
    """
    An accessor for type and feature relationships that are part of the declaration
    """

    def append[R: Unioning | Intersecting | Differencing | Disjoining | FeatureChaining | FeatureInverting | TypeFeaturing, M: Type](self, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Append a new *owned* or *referenced* element, inferred from the relationship type and this container. Returns a
        pair of (relationship, element), only the relationship is newly constructed.
        """

    def replace[R: Unioning | Intersecting | Differencing | Disjoining | FeatureChaining | FeatureInverting | TypeFeaturing, M: Type](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element may be *owned* or *referenced*
        depending on the relationship type and this container, see ``append`` for more details.
        """

    def insert[R: Unioning | Intersecting | Differencing | Disjoining | FeatureChaining | FeatureInverting | TypeFeaturing, M: Type](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element may be *owned* or
        *referenced* depending on the relationship type and this container, see ``append`` for more details.
        """

    def append_chain[R: Unioning | Intersecting | Differencing | Disjoining | FeatureChaining | FeatureInverting | TypeFeaturing](self, relationship: type[R], features: Sequence[Feature]) -> tuple[R, Feature]:
        """
        Append a relationship with an owned chaining. Raises ``TypeError`` if the relationship type cannot have owned
        chaining in the textual syntax.
        """

    def insert_chain[R: Unioning | Intersecting | Differencing | Disjoining | FeatureChaining | FeatureInverting | TypeFeaturing](self, index: int, relationship: type[R], features: Sequence[Feature]) -> tuple[R, Feature]:
        """
        Insert a relationship with an owned chaining at the specified index. Raises ``TypeError`` if the relationship
        type cannot have owned chaining in the textual syntax.
        """

    def replace_chain_at[R: Unioning | Intersecting | Differencing | Disjoining | FeatureChaining | FeatureInverting | TypeFeaturing](self, index: int, relationship: type[R], features: Sequence[Feature]) -> tuple[R, Feature]:
        """
        Replace the relationship and its related element at the specified index with an owned chaining. The relationship
        may be reused if its type matches the current relationship at that index. Raises ``TypeError`` if the
        relationship type cannot have owned chaining in the textual syntax.
        """

class TypeGuard:
    """
    The type used in a type check expression, e.g. ``istype``, ``hastype``.

    The actual expression result type is ``ScalarValues::Boolean``.
    """

    @property
    def value(self) -> Type:
        """
        The type guarded by this expression result.

        This is the type that is to be used for inferring filter expression output types,
        rather than any of the input types.
        """

    @value.setter
    def value(self, arg: Type, /) -> None: ...

class SexpOptions:
    """Options for S-exp output"""

    def __init__(self, indent: int = 2, include_implicit: bool = True, print_references: bool = False) -> None: ...

    @property
    def indent(self) -> int:
        """Number of spaces to ident each level with"""

    @indent.setter
    def indent(self, arg: int, /) -> None: ...

    @property
    def include_implicit(self) -> bool:
        """
        Whether to include implicit relationships and their children in the output
        """

    @include_implicit.setter
    def include_implicit(self, arg: bool, /) -> None: ...

    @property
    def print_references(self) -> bool:
        """Whether to print references next to some non-owning relationships."""

    @print_references.setter
    def print_references(self, arg: bool, /) -> None: ...

    __cpp_name__: str = 'syside::sysml::SexpOptions'

@overload
def sexp(root: Element, options: SexpOptions = ...) -> str:
    """
    Generate a minimal S-expression of owned elements rooted at ``root``, useful for debugging.
    """

@overload
def sexp(root: Element, indent: int = 2, include_implicit: bool = True, print_references: bool = False) -> str: ...

class PrintMode(enum.Enum):
    """Syntax mode to print the model into."""

    KerML = 0
    """Print model back to KerML syntax."""

    SysML = 1
    """Print model back to SysML syntax."""

class NamePreference(enum.Enum):
    """
    Preference for selecting identifiers when printing synthetic references.
    """

    Automatic = 0
    """Implementation defined name preference"""

    Regular = 1
    """Prefer regular name, otherwise fall back to short name"""

    Short = 2
    """Prefer short name, otherwise fall back to regular name"""

    Shortest = 3
    """Prefer shortest name"""

    Longest = 4
    """Prefer longest name (for completeness)"""

class ReferencePrinter:
    """
    An opaque reference print function that will be called only for synthetic references.
    """

    @overload
    def __init__(self) -> None:
        """Construct a default reference printer"""

    @overload
    def __init__(self, preference: NamePreference) -> None:
        """
        Construct a reference printer that will select identifiers for printing using the given preference.
        """

    @overload
    def __init__(self, callback: Callable[[Element, Element], Sequence[str] | NamePreference]) -> None:
        """
        Construct a reference printer with a custom path callback. The signature is
        ``(target: Element, referent: Element) -> Sequence[str] | NamePreference``, where:

        - ``target`` is the element that is referenced. Callback should return the path to it.
        - ``referent`` is the referent element, e.g. ``Membership``.

        Callback may also choose to return a name preference which will be used to print the reference
        instead.
        """

class ModelPrinter:
    """
    Pretty-printer for KerML/SysML models back to textual syntax.

    Note that the printer primarily assumes that the model is representable in textual syntax,
    and does not check if some elements can be printed or not, or ignores some elements
    that are otherwise to represent in the textual syntax. However, elements that are
    required by the textual syntax, but are missing in the model, will raise ``RuntimeError``.
    """

    @staticmethod
    def kerml(format: conf.FormatOptions = ..., force_formatting: bool = False, reference_printer: ReferencePrinter = ...) -> ModelPrinter:
        """
        Create a printer for KerML.

        ``reference_printer`` is only used for synthetic references, otherwise the original
        reference segments will be printed.
        """

    @staticmethod
    def sysml(format: conf.FormatOptions = ..., force_formatting: bool = False, reference_printer: ReferencePrinter = ...) -> ModelPrinter:
        """
        Create a printer for SysML.

        ``reference_printer`` is only used for synthetic references, otherwise the original
        reference segments will be printed.
        """

    @property
    def mode(self) -> PrintMode:
        """Current language mode of this printer"""

    @mode.setter
    def mode(self, arg: PrintMode, /) -> None: ...

    @property
    def force_formatting(self) -> bool:
        """
        Whether to ignore ``syside-format ignore`` pragmas and format such elements regardless
        """

    @force_formatting.setter
    def force_formatting(self, arg: bool, /) -> None: ...

    @property
    def format(self) -> conf.FormatOptions:
        """Format options used by this printer"""

    @format.setter
    def format(self, arg: conf.FormatOptions, /) -> None: ...

    __cpp_name__: str = 'syside::sysml::ModelPrinter'

class LineEnd(enum.Enum):
    """Possible formatted line endings"""

    LF = 0
    r"""Use ``\n`` line ends (Posix)"""

    CRLF = 1
    r"""Use ``\r\n`` line ends (Windows)"""

class PrinterConfig:
    """Formatting options for pretty-printed models"""

    def __init__(self, line_width: int = 100, tab_width: int = 4, line_end: LineEnd = LineEnd.LF, use_spaces: bool = True, add_final_newline: bool = True) -> None: ...

    @property
    def line_width(self) -> int:
        """Number of visual columns to attempt to fit the formatted text into"""

    @line_width.setter
    def line_width(self, arg: int, /) -> None: ...

    @property
    def tab_width(self) -> int:
        """Number of spaces per indentation"""

    @tab_width.setter
    def tab_width(self, arg: int, /) -> None: ...

    @property
    def line_end(self) -> LineEnd:
        """Line endings"""

    @line_end.setter
    def line_end(self, arg: LineEnd, /) -> None: ...

    @property
    def use_spaces(self) -> bool:
        """Whether to indent using spaces rather than tabs"""

    @use_spaces.setter
    def use_spaces(self, arg: bool, /) -> None: ...

    @property
    def add_final_newline(self) -> bool:
        """Whether to insert a final new line"""

    @add_final_newline.setter
    def add_final_newline(self, arg: bool, /) -> None: ...

def pprint(arg0: Element, printer: ModelPrinter | None = None, config: PrinterConfig = ...) -> str:
    """
    Prints model subtree starting at ``root`` to textual syntax.

    **NOTE**
    This performs very little checking that the given model can be represented in textual syntax, besides checking for
    elements that are missing. This has no effect when used as a formatter on a model parsed without syntax errors but
    programmatic models are not guaranteed to be valid textual syntax. In addition, it does not check that references
    are reachable from their scopes so parsing the printed model can fail to find them again. Otherwise, clearly
    unreachable references, such as when one of their ancestors is anonymous, will raise errors.

    Only the first import from any parent namespaces that would shorten the printed reference is used. This does not
    apply to imports themselves to prevent reference resolution errors due to multiple or cyclical imports. Additionally,
    references relative to left-hand side expression result types, such as those from ``FeatureChainExpressions``, are
    assumed to be directly or indirectly accessible so only their short or regular name is printed.
    """

class Sema:
    """
    Semantic resolver for SysML. This is responsible for linking references and resolving semantic rules in the pipeline.
    """

    def __init__(self) -> None: ...

    @overload
    def resolve(self, documents: Sequence[SharedMutex[Document]], index: StaticIndex, stdlib: Stdlib, reporter: Callable[[Document, Diagnostic], None] = ...) -> None:
        """
        Link and resolve semantic rules for ``documents``. Any documents that have already been resolved will be skipped,
        inferred by ``build_state >= BuildState.Built``. For references to be resolved correctly, they either have to
        point to elements in unresolved ``documents``, or elements indexed in ``index``. Similarly, semantic rules depend on all the
        required elements cached by ``stdlib``.

        ``reporter`` can be used to override default behaviour of how diagnostics are emitted. By default, they are printed to
        stdout.
        """

    @overload
    def resolve(self, documents: Sequence[Document], index: StaticIndex, stdlib: Stdlib, reporter: Callable[[Document, Diagnostic], None] = ...) -> None: ...

class UnexpectedDifferentReference:
    """
    An error signifiying that a different reference was found while attempting to revert
    changes made by sema, and requiring manual intervention.
    """

    @property
    def reference(self) -> Element | None:
        """
        Referenced element that was found, ``None`` if no matching reference could be inferred
        """

    @reference.setter
    def reference(self, arg: Element | None, /) -> None: ...

    @property
    def expected(self) -> Element:
        """Element that was expected to be referenced"""

    @expected.setter
    def expected(self, arg: Element, /) -> None: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::sysml::UnexpectedDifferentReference'

def collect_exports(document: Document) -> int:
    """
    Collect and cache symbols exported by ``document``. This must be called before the ``document`` is indexed, otherwise wrong or no symbols may be indexed. Returns the number of symbols cached.
    """

def build_model(document: Document, language: ModelLanguage | None = None) -> list[Diagnostic]:
    """
    Build the AST for ``document`` from its ``text_document``.

    Any existing model will be cleared, and the built model will not have its references
    linked. Instead, most references will use placeholder references that will be
    replaced by actual targets in linking stage. Only ``sysml`` and ``kerml`` languages
    are supported.

    This is a CST -> AST stage in the pipeline.

    Raises ``ValueError`` if the ``document`` has unsupported language, or it has
    no associated ``text_document``.
    """

@overload
def sema_reset(element: Element) -> None:
    """
    Reset semantic state of ``element``.

    This will typically remove any implied relationships, and reverse a few other
    changes made by sema. After this completes, ``element.sema_state == SemaState.None``.
    """

@overload
def sema_reset(document: Document, reporter: Callable[[Element, UnexpectedDifferentReference], None] | None = None) -> None:
    """
    Reset semantic state of ``document``.

    This will call ``sema_reset`` on all owned elements, and additionally reset all
    resolved references back to unresolved state. While resetting references, if
    the resolved reference does not match the current reference, ``reporter`` will
    be called with the element the reference applies to and
    ``UnexpectedDifferentReference`` that was found. By default,
    ``reporter`` will print such errors to ``stderr``.

    After this completes, ``document.build_state == BuildState.Indexed``.
    """

class Writer(Generic[T]):
    """Abstract base class for serialization writer implementations."""

class SerdeMessage(Generic[T]):
    """Message emitted during (de)serialization"""

    @property
    def context(self) -> T:
        """The context that this message applies to."""

    @property
    def severity(self) -> DiagnosticSeverity:
        """The severity of the message."""

    @property
    def message(self) -> str:
        """Message contents."""

    def __str__(self) -> str: ...

class SerdeReport(Generic[T]):
    """(De)Serialization report containing emitted messages."""

    @property
    def messages(self) -> list[SerdeMessage[T]]:
        """The emitted messages."""

    def __bool__(self) -> bool:
        """Returns ``True`` if none of the messages are errors."""

    def passed(self, warnings_as_errors: bool = False) -> bool:
        """
        Check if the report has no errors. If ``warnings_as_errors`` is ``True``, also check if it contains
        no warnings.
        """

    def __str__(self) -> str: ...

class FailAction(enum.Enum):
    """Action taken when a serialization error is encountered."""

    Fail = 0
    """Stop serialization on the first error."""

    Diagnose = 1
    """Continue diagnosing errors but stop serialization."""

    Ignore = 2
    """Ignore errors and continue serialization."""

class SerializationOptions:
    """
    Options for SysML model serialization. Attribute options are ordered in descending precedence.
    """

    def __init__(self, use_standard_names: bool = True, include_derived: bool = False, include_redefined: bool = False, include_default: bool = False, include_optional: bool = False, include_implied: bool = False, fail_action: FailAction = FailAction.Diagnose, filter: CompilerFilter | Callable[[Element, list[Expression]], bool] | None = None) -> None: ...

    @property
    def use_standard_names(self) -> bool:
        """If true, fields will be serialized using standard names"""

    @use_standard_names.setter
    def use_standard_names(self, arg: bool, /) -> None: ...

    @property
    def include_derived(self) -> bool:
        """
        If true, serialize derived attributes. Corresponds to ``includesDerived`` flag in the specification (KerML 10.3, Table 13):

            Whether derived property values are included in the model interchange files.

        **Note:** Syside does not construct all derived properties yet. Therefore, setting
        ``options.include_derived`` to ``True`` may result in a JSON that does not satisfy the schema.
        """

    @include_derived.setter
    def include_derived(self, arg: bool, /) -> None: ...

    @property
    def include_redefined(self) -> bool:
        """
        If true, serialize attributes even if they are redefined in the metamodel.
        """

    @include_redefined.setter
    def include_redefined(self, arg: bool, /) -> None: ...

    @property
    def include_default(self) -> bool:
        """If true, serialize attributes even if they match their default values."""

    @include_default.setter
    def include_default(self, arg: bool, /) -> None: ...

    @property
    def include_optional(self) -> bool:
        """
        If true, non-required attributes will be serialized even if they are null or empty.
        """

    @include_optional.setter
    def include_optional(self, arg: bool, /) -> None: ...

    @property
    def include_implied(self) -> bool:
        """
        If true, serialize implicit elements. Only for attributes that are
        serialized. Corresponds to ``includesImplied`` flag in the
        specification (KerML 10.3, Table 13):

            Whether implied relationships are included in the model interchange files.
        """

    @include_implied.setter
    def include_implied(self, arg: bool, /) -> None: ...

    @property
    def fail_action(self) -> FailAction:
        """Action to take on serialization errors."""

    @fail_action.setter
    def fail_action(self, arg: FailAction, /) -> None: ...

    @property
    def filter(self) -> Callable[[Element, list[Expression]], bool] | None:
        """
        Filter expression evaluation function.

        If not set, filter expressions will not be evaluated. Do not note that filter expressions
        may be evaluated multiple times on each applicable element when serializing derived 
        properties as some overlap considerably.
        """

    @filter.setter
    def filter(self, arg: CompilerFilter | Callable[[Element, list[Expression]], bool] | None) -> None: ...

    @staticmethod
    def minimal() -> SerializationOptions:
        """
        Configuration that instructs the writer to produce a minimal JSON without any redundant elements.
        Examples of redundant information that is avoided using the minimal configuration are:

        +   including fields for null values;
        +   including fields whose values match the default values;
        +   including redefined fields that are duplicates of redefining fields;
        +   including derived fields that can be computed from minimal JSON (for
            example, the result value of evaluating an expression);
        +   including implied relationships.
        """

    def with_options(self, use_standard_names: bool | None = None, include_derived: bool | None = None, include_redefined: bool | None = None, include_default: bool | None = None, include_optional: bool | None = None, include_implied: bool | None = None, filter: CompilerFilter | Callable[[Element, list[Expression]], bool] | None = None, fail_action: FailAction | None = None) -> SerializationOptions:
        """Creates a copy with the specified options changed to the given values."""

class Serializer:
    """
    Serializer for SysML models. The actual serialization output depends on used ``Writer``.
    """

    def __init__(self) -> None: ...

    @overload
    def accept(self, root: Element, writer: Writer[T], options: SerializationOptions = ...) -> SerdeReport[Element]:
        """
        Perform serialization.

        The serialization result will be owned by the ``writer``, this only
        returns the collected diagnostics.
        """

    @overload
    def accept(self, root: Element, writer: Writer[T], use_standard_names: bool = True, include_derived: bool = False, include_redefined: bool = False, include_default: bool = False, include_optional: bool = False, include_implied: bool = False, fail_action: FailAction = FailAction.Diagnose, filter: CompilerFilter | Callable[[Element, list[Expression]], bool] | None = None) -> SerdeReport[Element]: ...

class JsonStringOptions:
    """Options for serialization writer to JSON strings"""

    def __init__(self, indent: int = 2, use_spaces: bool = True, final_new_line: bool = True, include_cross_ref_uris: bool = True) -> None: ...

    @property
    def indent(self) -> int:
        """Number of indents to indent nesting with"""

    @indent.setter
    def indent(self, arg: int, /) -> None: ...

    @property
    def use_spaces(self) -> bool:
        """Whether to use spaces for indenting"""

    @use_spaces.setter
    def use_spaces(self, arg: bool, /) -> None: ...

    @property
    def final_new_line(self) -> bool:
        """Whether to insert a final new line"""

    @final_new_line.setter
    def final_new_line(self, arg: bool, /) -> None: ...

    @property
    def include_cross_ref_uris(self) -> bool:
        """
        If true, include document URIs in references if elements are referenced from other documents
        """

    @include_cross_ref_uris.setter
    def include_cross_ref_uris(self, arg: bool, /) -> None: ...

class JsonStringWriter(Writer[str]):
    """Serialization writer that outputs JSON string"""

    @overload
    def __init__(self, arg: JsonStringOptions = ...) -> None: ...

    @overload
    def __init__(self, indent: int = 2, use_spaces: bool = True, final_new_line: bool = True, include_cross_ref_uris: bool = True) -> None: ...

    @property
    def partial_result(self) -> str:
        """Currently written text. May be incomplete JSON string."""

    @property
    def result(self) -> str:
        """Result of serialization. Guaranteed to be valid JSON string."""

    def clear(self) -> None:
        """Clear result. This is called automatically when serialization starts."""

    @property
    def options(self) -> JsonStringOptions:
        """Currently set options. Note that this returns a copy of the options."""

    @options.setter
    def options(self, arg: JsonStringOptions, /) -> None: ...

@overload
def serialize(root: Element, writer: Writer[T], options: SerializationOptions = ...) -> SerdeReport[Element]:
    """
    Convenience function for serialization. Prefer using ``Serializer`` to avoid
    allocations when doing repeated serializations.
    """

@overload
def serialize(root: Element, writer: Writer[T], use_standard_names: bool = True, include_derived: bool = False, include_redefined: bool = False, include_default: bool = False, include_optional: bool = False, include_implied: bool = False, fail_action: FailAction = FailAction.Diagnose, filter: CompilerFilter | Callable[[Element, list[Expression]], bool] | None = None) -> SerdeReport[Element]: ...

class AttributeMap:
    """Internal opaque type for deserialization attribute mapping"""

    def __eq__(self, arg: object, /) -> bool:
        pass

DESERIALIZE_INTERNAL: AttributeMap = ...
"""Marker to signal the deserializer that attributes are using internal names (snake_case)."""

DESERIALIZE_STANDARD: AttributeMap = ...
"""Marker to signal the deserializer that attributes are using standard names (camelCase)."""

class PendingReference:
    """Reference that has yet to be linked."""

    @property
    def uri(self) -> str:
        """Document URI this reference is resolved from"""

    @property
    def id(self) -> uuid.UUID:
        """Element ID of the reference element"""

    @property
    def referent(self) -> Element:
        """The element this reference is owned by"""

class Deserializer:
    """
    Deserializer for SysML models. The actual deserialization input depends on used ``Reader``.

    Note that unlike ``Serializer`` deserialization cannot be completed in a single pass in general
    because documents may form reference cycles with each other. The typical deserialization pattern will be

    .. code-block:: python

        des = Deserializer(document)
        model, report = des.accept(reader, DESERIALIZE_STANDARD)
        # ... collect all valid element ids for linking
        link_report, all_linked = model.link(my_reference_resolve)
    """

    def __init__(self, document: Document) -> None:
        """
        Construct a new deserializer that will deserialize models into the provided ``document``.
        """

    @overload
    def accept(self, reader: Reader, attributes: AttributeMap) -> tuple[DeserializedModel, SerdeReport[DocumentSegment | str | Element]]:
        """
        Accept a ``reader`` for deserialization into currently bound ``document``.
        Returns the deserialized model, or raises a ``RuntimeError``. ``document`` without a
        :py:class:`Url <syside.Url>` with scheme will emit a warning that relative URIs will not be
        resolvable.

        Note that cross-references may not be resolved, and instead replaced by
        placeholder element references due to potential reference cycles between
        documents. Call ``link`` on the returned model when dependent documents
        have been loaded.
        """

    @overload
    def accept(self, document: Document, reader: Reader, attributes: AttributeMap) -> tuple[DeserializedModel, SerdeReport[DocumentSegment | str | Element]]:
        """
        Accept ``reader`` for deserialization into ``document``. Equivalent to

        .. code-block:: python

            deserializer.reset(document)
            return deserializer.accept(reader, attributes)

        Returns the deserialized model, or raises ``RuntimeError``.
        """

    @property
    def document(self) -> Document:
        """The document bound to this deserializer"""

    def reset(self, document: Document) -> None:
        """
        Reset the deserializer. Rebinds to the ``document`` and resets this ``Deserializer`` for new deserialization.
        """

class IdMap:
    """
    ``DeserializedModel`` compatible mapping for elements. This will typically be used for linking pending references:

    .. code-block:: python

        map = IdMap()
        models_reports = [
            deserializer.accept(document, my_reader(input), DESERIALIZE_STANDARD)
            for document, input in zip(documents, inputs)
        ]
        for document in documents:
            map.insert_or_assign(document)
        reports_linked = [model.link(map) for model, _ in models_reports]
    """

    def __init__(self) -> None: ...

    def insert_or_assign(self, document: Document) -> tuple[int, bool]:
        """
        Insert all elements from ``document`` into this map.

        Returns the number of elements inserted, and ``True`` if insertion took place,
        ``False`` if ``document`` was already mapped.
        """

    def try_insert(self, document: Document) -> tuple[int, bool]:
        """
        Try insert all elements from ``document`` into this map.

        Returns the number of elements inserted, and ``True`` if insertion took place.
        This will not override already mapped document elements.
        """

    @overload
    def erase(self, document: Document) -> int:
        """
        Erase all elements assigned to ``document`` from this map.

        Returns the number of elements erased.
        """

    @overload
    def erase(self, uri: str) -> int:
        """
        Erase all elements assigned to document with ``uri`` from this map.

        Returns the number of elements erased.
        """

    def clear(self) -> None:
        """Clear all mapped elements."""

    def reserve(self, n: int) -> None:
        """Reserve space for ``n`` document mappings."""

    def find(self, uri: str, id: uuid.UUID) -> Element | None:
        """
        Find an element at document with ``uri`` that has ``id``.

        Returns the element found if any.
        """

    def search(self, id: uuid.UUID) -> Element | None:
        """
        Search across all registered documents for a matching id. This has complexity O(n)
        since it searches each document separately.

        Returns the element found if any.
        """

    def __call__(self, uri: str, id: uuid.UUID) -> Element | None:
        """
        Short-hand for ``find`` or ``search``. Will fall back to ``search`` if ``uri`` is empty.
        """

class DeserializedModel:
    """
    The model as it was deserialized, with references potentially unresolved.
    """

    @property
    def document(self) -> Document:
        """The document model was deserialized into"""

    @property
    def root(self) -> Element:
        """
        The root node of the deserialized model. Note that this may be an orphan node.
        """

    @property
    def pending_references(self) -> ContainerView[PendingReference]:
        """
        Currently unresolved pending references. These need to be resolved in a separate post-deserialization step
        to correctly resolve (potentially cyclical) dependencies between models.
        """

    def link(self, resolve: Callable[[str, uuid.UUID], Element | None]) -> tuple[SerdeReport[DocumentSegment | str | Element], bool]:
        """
        Attempt to resolve any pending references using custom ``resolve``. Signature is

        .. code-block:: python

            def resolve(uri: str, element_id: uuid.UUID) -> Element | None: ...

        Returns a pair of ``report`` and ``success``, whether all pending references have been resolved.
        Use ``pending_references`` again to get references that failed to resolve.
        """

class Reader:
    """Abstract base class for all deserialization readers."""

class JsonReader:
    """Unbound reader for JSON deserialization"""

    def __init__(self) -> None: ...

    def bind(self, s: str) -> JsonReader.StrReader:
        """
        Bind a serialized JSON string for reading.

        Note that only one reader can be bound at a time, binding again will raise ``ValueError``.
        Suggested usage is through a context manager:

        .. code-block:: python

            with reader.bind(json_str) as json:
                model, report = deserializer.accept(json, syside.DESERIALIZE_STANDARD)

        The reader will attempt to infer the root node as:

        1. The first ``Namespace`` (not subtype) without an owning relationship.
        2. The first ``Element`` that has no serialized owning related element or owning relationship,
           starting from the first element in the JSON array, and following owning elements up.
        3. The first element in the array otherwise.
        """

    @property
    def is_bound(self) -> bool:
        """Whether there currently is a reader bound to this resource."""

    class StrReader(Reader):
        """
        Bound reader for JSON deserialization that can be used together with ``Deserializer``.

        Resource usage can be controlled through context manager.
        """

        def unbind(self) -> None:
            """
            Unbind this reader explicitly, allowing resources to be reused for other reads.

            Attempting to use this for deserialization again will raise ``RuntimeError``.
            """

        def attribute_hint(self) -> AttributeMap | None:
            """Get a hint for deserialization attributes."""

        def __enter__(self) -> JsonReader.StrReader: ...

        def __exit__(self, exc_type: type[BaseException] | None, exc: BaseException | None, traceback: types.TracebackType | None) -> None: ...

def deserialize(document: Document, reader: Reader, attributes: AttributeMap) -> tuple[DeserializedModel, SerdeReport[DocumentSegment | str | Element]]:
    """
    Convenience function for deserialization. Prefer using ``Deserializer`` to avoid
    allocations when doing repeated deserializations.
    """

def precompute_element_ids(arg: Document | Element, /) -> None:
    """
    Precompute element IDs for a given ``Document`` or ``Element`` subtree.

    This has complexity ``O(n)`` for number of elements irrespective of tree
    depth and number of owned elements, and is far more efficient than
    generating element IDs lazily through ``Element.element_id``. Consider
    precomputing element IDs for documents that will be serialized to improve
    performance.

    A similar precomputation is performed on serialization, however its
    results are not persisted to the elements.
    """
