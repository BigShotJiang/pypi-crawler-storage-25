"""
Entrypoint of Syside Pro Python CLI
"""

from collections.abc import Generator, Iterable
from pathlib import Path
import sys
import textwrap

from .core import cli
from . import core as syside
from ._diagnostics import Diagnostics
from ._loading import collect_files_recursively, Model, try_load_model


def _all_file_paths(paths: Iterable[Path]) -> Generator[Path]:
    """
    Yields all non-directory paths in ``paths``, as well as all valid source file paths inside
    any directory path in ``paths``.
    """
    for path in paths:
        if path.is_dir():
            yield from collect_files_recursively(path)
        else:
            yield path


def _try_load_from_files(
    paths: list[Path], werror: bool = False
) -> tuple[Model, Diagnostics]:
    """
    Tries to load a model from a set of **file** ``paths``

    If ``werror`` is set, also exits in case of any (model) warnings.
    """

    (model, diagnostics) = try_load_model(paths=paths)

    for diag in diagnostics.all:
        match diag.severity:
            case syside.DiagnosticSeverity.Error | syside.DiagnosticSeverity.Warning:
                print(diag.full_message, file=sys.stderr)
            case syside.DiagnosticSeverity.Information | syside.DiagnosticSeverity.Hint:
                print(diag.full_message, file=sys.stdin)
            case other:
                raise NotImplementedError(f"Unknown diagnostic severity {other}")

    if diagnostics.contains_errors(werror):
        sys.exit(1)

    return model, diagnostics


def _embedded_session(model: Model, diagnostics: Diagnostics) -> None:
    """
    Runs an embedded ``IPython`` session in the current environment.
    """

    banner = textwrap.dedent(
        """\
        Welcome to isyside!

        This is an interactive Python shell with the loaded model accessible as model.
        Builtin modules:        syside
        Convenience variables:  model, diagnostics
        """
    )

    namespace = {"syside": syside, "model": model, "diagnostics": diagnostics}

    try:
        import IPython  # type: ignore[import-not-found]

        IPython.start_ipython(
            argv=[f'--InteractiveShell.banner2="{banner}"'],
            header=banner,
            user_ns=namespace,
        )
    except ModuleNotFoundError:
        import code

        code.interact(banner=banner, local=namespace)


def interactive(args: cli.Interactive) -> int:
    """Drop into an interactive shell with a loaded model"""

    file_paths = list(_all_file_paths(args.paths))

    (model, diagnostics) = _try_load_from_files(file_paths, werror=args.werror)

    _embedded_session(model, diagnostics)

    return 0


if __name__ == "__main__":
    sys.exit(cli.main(args=sys.argv, interactive=interactive))
