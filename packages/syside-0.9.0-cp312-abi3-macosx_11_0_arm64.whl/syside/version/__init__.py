"""
Import shim for `syside.version`
"""

from _syside.version import *
