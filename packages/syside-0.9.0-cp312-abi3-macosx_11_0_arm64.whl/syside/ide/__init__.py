"""
Import shim for `syside.ide`
"""

from _syside.ide import *
