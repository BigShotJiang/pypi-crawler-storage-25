import contextlib
import io
import sys

from _syside.__main__ import interactive
from .core import cli


_REQIF_PROG = "syside reqif"


class ReqIfCommand(cli.ExternalCommand):
    def __init__(self) -> None:
        super().__init__(
            "reqif",
            "Import/export ReqIF files for SysMLv2.",
        )

    def help(self, arguments: list[str], ctx: cli.ExtContext) -> str:
        from syside.reqif.__main__ import build_parser

        parser = build_parser(prog=_REQIF_PROG)
        # Let argparse resolve the (possibly nested) subcommand and render
        # its help via ``--help``. ``ExternalCommand.help`` returns a single
        # string the C++ side prints back to the user, so we redirect both
        # streams (argparse writes help to stdout and errors to stderr) and
        # suppress the ``SystemExit`` that ``--help`` / ``parser.error``
        # raise.
        buf = io.StringIO()
        with (
            contextlib.redirect_stdout(buf),
            contextlib.redirect_stderr(buf),
            contextlib.suppress(SystemExit),
        ):
            parser.parse_args([*arguments, "--help"])
        return buf.getvalue()

    def execute(self, arguments: list[str], ctx: cli.ExtContext) -> int:
        from syside.reqif.__main__ import main as _reqif_entry

        return _reqif_entry(list(arguments), prog=_REQIF_PROG)


def main() -> None:
    sys.exit(
        cli.main(
            args=sys.argv,
            interactive=interactive,
            external=[ReqIfCommand()],
        )
    )
