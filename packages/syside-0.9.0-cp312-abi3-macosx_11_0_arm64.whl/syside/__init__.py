"""
Syside Automator for Python.

A library for parsing, validating, and analysing SysMLv2 models, optimised for textual notation.
"""

from _syside import *

import _syside

__version__ = _syside.__version__

del _syside
