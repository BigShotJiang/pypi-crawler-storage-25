"""
Import shim for `syside.experimental.viz.dot`
"""

from _syside.experimental.viz.dot import *
