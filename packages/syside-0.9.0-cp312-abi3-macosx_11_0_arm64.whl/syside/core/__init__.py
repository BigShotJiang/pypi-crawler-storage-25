"""
Import shim for `syside.core`
"""

from _syside.core import *
