"""
Reusable CLI entrypoint for loading a SysMLv2 model from files/directories.

Intended to be called from a script's ``main`` function so that the script
author only needs to handle the loaded model, not argument parsing or file
collection.  Three calling conventions are supported:

**Simple** — returns only the ``Model``.  ``--errors-fatal`` is available
on the command line so end users can opt into hard failure when the model
contains errors::

    def main() -> None:
        m: Model = syside_cli.main()
        # work with m ...

    if __name__ == "__main__":
        main()

**With diagnostics** — returns ``(Model, Diagnostics)`` and omits
``--errors-fatal`` from the CLI, because the caller is taking responsibility
for inspecting diagnostics programmatically::

    def main() -> None:
        m, diags = syside_cli.main(return_diagnostics=True)
        for msg in diags.errors:
            ...

    if __name__ == "__main__":
        main()

**With extra arguments** — call :func:`main_with_args` to get back both the
model result and the unrecognized argv tokens, then parse the extra tokens
with a caller-owned parser::

    @dataclasses.dataclass
    class MyArgs:
        my_flag: bool

    def main() -> None:
        m, remaining = syside_cli.main_with_args(False)
        extra = argparse.ArgumentParser()
        extra.add_argument("--my-flag", action="store_true")
        my_args = MyArgs(**vars(extra.parse_args(remaining)))
        if my_args.my_flag:
            ...

    if __name__ == "__main__":
        main()
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import IO, Literal, overload

import syside
from syside import Diagnostics, Model


def _collect_paths(inputs: list[str | Path]) -> list[Path]:
    """
    Expand a mixed list of file paths and directory paths into a flat list of files.

    Directories are searched recursively for ``.sysml`` and ``.kerml`` files
    via :func:`syside.collect_files_recursively`.  Plain file paths are
    included as-is without extension filtering.

    ``.venv`` directories anywhere under a searched directory are excluded
    because the syside package bundles stdlib ``.sysml`` files inside it.
    """
    paths: list[Path] = []
    for raw in inputs:
        p = Path(raw)
        if p.is_dir():
            paths.extend(
                f for f in syside.collect_files_recursively(p) if ".venv" not in f.parts
            )
        else:
            paths.append(p)
    return paths


def _print_diagnostics(diagnostics: Diagnostics, *, color: bool, file: IO[str]) -> None:
    """
    Write all diagnostics to *file*.

    When *color* is ``True``, each message is rendered with ANSI colour codes
    and includes a source-snippet underline (via
    ``DiagnosticMessage.full_message``).  When ``False``, a plain single-line
    representation is used instead.
    """
    for msg in diagnostics.all:
        # full_message includes source snippet and ANSI colour codes;
        # str(msg) is the plain single-line version.
        text = msg.full_message if color else str(msg)
        print(text, file=file, end="" if text.endswith("\n") else "\n")


def default_args() -> argparse.ArgumentParser:
    """
    Return a :class:`argparse.ArgumentParser` pre-populated with the standard arguments.

    The following arguments are registered:

    ``PATH ...``
        Zero or more ``.sysml`` / ``.kerml`` files, or directories searched
        recursively.  Defaults to the current working directory when omitted.

    ``--attach-comments``
        Preserve source comments in the model so they survive a round-trip
        through the formatter.

    ``--color`` / ``--colour``
        ``always``, ``never``, or ``auto`` (default).  ``auto`` enables colour
        when stdout is a terminal.

    ``--diag-output``
        ``stdout`` (default) or ``stderr``.  Controls where diagnostic messages
        are written.
    """
    parser = argparse.ArgumentParser(
        description="Load a SysMLv2 model from files and/or directories."
    )
    parser.add_argument(
        "paths",
        nargs="*",
        metavar="PATH",
        help="Files (.sysml/.kerml) or directories to search recursively. Defaults to cwd.",
    )
    parser.add_argument(
        "--attach-comments",
        action="store_true",
        default=True,
        help="Attach source comments to the model.",
    )
    parser.add_argument(
        "--color",
        "--colour",
        dest="color",
        choices=["always", "never", "auto"],
        default="auto",
        help="Control ANSI colour in diagnostic output (default: auto).",
    )
    parser.add_argument(
        "--diag-output",
        choices=["stdout", "stderr"],
        default="stdout",
        help="Where to write diagnostic messages (default: stdout).",
    )
    return parser


@overload
def main_with_args(
    return_diagnostics: Literal[True],
) -> tuple[tuple[Model, Diagnostics], list[str]]: ...
@overload
def main_with_args(
    return_diagnostics: Literal[False],
) -> tuple[Model, list[str]]: ...


def main_with_args(
    return_diagnostics: bool,
) -> tuple[Model | tuple[Model, Diagnostics], list[str]]:
    """
    Parse the standard arguments from ``sys.argv``, load a SysMLv2 model, and return it
    along with any unrecognized argv tokens.

    Unrecognized tokens are returned as a ``list[str]`` so that callers can
    parse them with a caller-owned, statically-typed argument parser.  This
    keeps the type boundary explicit: this module owns the types for its own
    arguments; the caller owns the types for theirs.

    :param return_diagnostics:
        When ``True``, returns ``(Model, Diagnostics)`` and does **not** add
        ``--errors-fatal`` or ``--warnings-as-errors`` to the parser — the
        caller takes responsibility for inspecting and acting on diagnostics.
        When ``False``, returns only the ``Model`` and exposes both flags.
    :returns:
        ``(result, remaining)`` where *result* is ``Model`` or
        ``(Model, Diagnostics)`` depending on *return_diagnostics*, and
        *remaining* is the list of unrecognized argv tokens for the caller to
        parse.
    :raises SystemExit(1):
        If no ``.sysml`` or ``.kerml`` files are found, or if ``--errors-fatal``
        is set and the model contains errors.
    """
    parser = default_args()

    if not return_diagnostics:
        parser.add_argument(
            "--warnings-as-errors",
            "-Werror",
            action="store_true",
            default=False,
            help="Treat warnings as errors.",
        )
        parser.add_argument(
            "--errors-fatal",
            action="store_true",
            default=False,
            help="Exit with a non-zero status if the model has errors (or warnings, if --warnings-as-errors is set).",
        )

    args, remaining = parser.parse_known_args()

    inputs: list[str | Path] = args.paths if args.paths else [Path.cwd()]
    file_paths = _collect_paths(inputs)
    if not file_paths:
        print(
            "error: no .sysml or .kerml files found in the given paths", file=sys.stderr
        )
        sys.exit(1)

    model, diagnostics = syside.try_load_model(
        paths=file_paths,
        attach_comments=args.attach_comments,
    )

    match args.color:
        case "always":
            color = True
        case "never":
            color = False
        case "auto":
            color = sys.stdout.isatty()

    diag_file: IO[str] = sys.stdout if args.diag_output == "stdout" else sys.stderr

    if any(True for _ in diagnostics.all):
        _print_diagnostics(diagnostics, color=color, file=diag_file)

    if return_diagnostics:
        return (model, diagnostics), remaining

    if args.errors_fatal and diagnostics.contains_errors(
        warnings_as_errors=args.warnings_as_errors
    ):
        sys.exit(1)

    return model, remaining


@overload
def main(return_diagnostics: Literal[True]) -> tuple[Model, Diagnostics]: ...
@overload
def main(return_diagnostics: Literal[False] = ...) -> Model: ...


def main(return_diagnostics: bool = False) -> Model | tuple[Model, Diagnostics]:
    """
    Parse ``sys.argv``, load a SysMLv2 model, and return it.

    Convenience wrapper around :func:`main_with_args` for scripts that do not
    need to add extra CLI arguments.

    :param return_diagnostics:
        When ``True``, returns ``(Model, Diagnostics)`` and does **not** add
        ``--errors-fatal`` to the argument parser — the caller is expected to
        inspect diagnostics directly.  When ``False`` (the default), returns
        only the ``Model`` and exposes ``--errors-fatal`` on the CLI.

    :returns:
        ``Model`` when *return_diagnostics* is ``False``; ``(Model,
        Diagnostics)`` when it is ``True``.  Note that the model may be
        partial if parsing failed, but is always returned — even when errors
        are present — unless ``--errors-fatal`` causes an early exit.

    **CLI arguments** (see :func:`default_args` for the full list)

    ``PATH ...``
        Zero or more ``.sysml`` / ``.kerml`` files, or directories searched
        recursively.  Defaults to the current working directory when omitted.

    ``--attach-comments``
        Preserve source comments in the model.

    ``--color`` / ``--colour`` ``{always,never,auto}``
        Control ANSI colour in diagnostic output (default: ``auto``).

    ``--diag-output`` ``{stdout,stderr}``
        Where to write diagnostic messages (default: ``stdout``).

    ``--warnings-as-errors``, ``-Werror``
        Treat warnings as errors when evaluating ``--errors-fatal``.  Only
        present when *return_diagnostics* is ``False``.

    ``--errors-fatal``
        Exit with status 1 if the model contains errors after loading.
        Only present when *return_diagnostics* is ``False``.

    :raises SystemExit(1):
        If no ``.sysml`` or ``.kerml`` files are found, or if ``--errors-fatal``
        is set and the model contains errors.
    """
    if return_diagnostics:
        result_with_diags, _ = main_with_args(True)
        return result_with_diags
    else:
        result_model, _ = main_with_args(False)
        return result_model
