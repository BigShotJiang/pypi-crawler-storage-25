"""
`reload_model`
"""

from typing import Any

from .. import (
    Diagnostic,
    DiagnosticMessage,
    Document,
    Model,
    ModelLanguage,
    SerdeReport,
    SerializationOptions,
    make_pipeline,
    PipelineOptions,
    ScheduleOptions,
    ValidationTiming,
    get_default_executor,
    json,
)


def _msgs_from_serde_report(
    report: SerdeReport[Any],
) -> list[DiagnosticMessage]:
    return [
        DiagnosticMessage(
            filename=None,
            line=0,
            col=0,
            severity=msg.severity,
            code="serde",
            message=msg.message,
            full_message=str(msg),
        )
        for msg in report.messages
    ]


def _lang_from_str(s: str) -> ModelLanguage:
    if s == "sysml":
        return ModelLanguage.SysML
    elif s == "kerml":
        return ModelLanguage.KerML
    else:
        raise ValueError(f"Unknown model language: {s!r}")


def reload_model(m: Model) -> tuple[list[DiagnosticMessage], list[Diagnostic]]:
    """
    Reload a model, recomputing all derived elements.

    If deserialization fails, ``m`` is left unchanged.

    :param m: The model to reload.
    :return: A tuple of (serde messages, pipeline diagnostics). Serde messages
        are produced during JSON deserialization. Pipeline diagnostics are sema
        and validation diagnostics produced by re-running the pipeline.
    :raises syside.json.ProjectDeserializationError: If deserialization fails.
    """
    options = SerializationOptions.minimal()

    # Serialize first (no mutation), then deserialize into fresh document objects.
    # Using fresh documents rather than the originals means that if loads raises,
    # m is unchanged. Document.create_st with an explicit language avoids the URL
    # extension inference that JsonSourceNew (url_str, json_str) would require.
    sources: list[json.JsonSourceInto] = []
    for doc_mutex in m.documents:
        with doc_mutex.lock() as doc:
            json_str = json.dumps(doc.root_node, options)
            new_mutex = Document.create_st(doc.url, _lang_from_str(doc.language))
            with new_mutex.lock() as new_doc:
                sources.append((new_doc, json_str))

    new_model, reports = json.loads(sources, environment=m.environment)

    object.__setattr__(m, "documents", new_model.documents)
    object.__setattr__(m, "index", new_model.index)
    object.__setattr__(m, "lib", new_model.lib)
    object.__setattr__(m, "environment", new_model.environment)

    pipeline = make_pipeline(PipelineOptions(lib=m.lib, static_index=m.index))
    schedule = pipeline.schedule(
        m.documents,
        ScheduleOptions(validation_timing=ValidationTiming.Manual),
    )
    result = get_default_executor().run(schedule)
    if not result:
        result.rethrow_exception()

    serde_msgs = [
        msg for _, report in reports for msg in _msgs_from_serde_report(report)
    ]
    pipeline_diags = [
        diag
        for diags in result.diagnostics
        for diag in list(diags.sema) + list(diags.validation)
    ]
    return serde_msgs, pipeline_diags
