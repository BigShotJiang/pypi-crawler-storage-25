"""
Import shim for `syside.conf`
"""

from _syside.conf import *
