"""
Import shim for `syside.debug`
"""

from _syside.debug import *
