"""
Parsing of ReqIF datatypes, converting them to IR, and vice-versa.
"""

from typing import TypeAlias, assert_never
from reqif.models.reqif_req_if_content import ReqIFReqIFContent
from reqif.models.reqif_data_type import (
    ReqIFDataTypeDefinitionString,
    ReqIFDataTypeDefinitionInteger,
    ReqIFDataTypeDefinitionBoolean,
    ReqIFDataTypeDefinitionReal,
    ReqIFDataTypeDefinitionDateIdentifier,
    ReqIFDataTypeDefinitionEnumeration,
    ReqIFDataTypeDefinitionXHTML,
    ReqIFEnumValue,
)

from . import _ir_model as ir
from ._reqif_utils import (
    decode_reqif_string,
    encode_reqif_string,
    ensure_long_name,
)

_ReqIFDataType: TypeAlias = (
    ReqIFDataTypeDefinitionString
    | ReqIFDataTypeDefinitionInteger
    | ReqIFDataTypeDefinitionBoolean
    | ReqIFDataTypeDefinitionReal
    | ReqIFDataTypeDefinitionDateIdentifier
    | ReqIFDataTypeDefinitionXHTML
    | ReqIFDataTypeDefinitionEnumeration
)


def read_datatype_defs_to_ir(
    content: ReqIFReqIFContent,
) -> dict[str, ir.DatatypeDef[ir.DatatypeProps]]:
    """
    Read the supplied ReqIF content and extracts all DATATYPE-DEFINITION-* entries,
    converting them to IR datatypes.
    """
    result: dict[str, ir.DatatypeDef[ir.DatatypeProps]] = {}

    for datatype in content.data_types or []:
        if isinstance(datatype, ReqIFDataTypeDefinitionString):
            if datatype.max_length:
                props_string = ir.StrProps(max_length=int(datatype.max_length))
            else:
                props_string = ir.StrProps()

            dt_string = ir.DatatypeDef(
                id=datatype.identifier,
                props=props_string,
                name=decode_reqif_string(datatype.long_name) or "",
                description=decode_reqif_string(datatype.description),
                last_change=datatype.last_change or None,
            )
            result[dt_string.id] = dt_string

        elif isinstance(datatype, ReqIFDataTypeDefinitionInteger):
            props_integer = ir.IntProps()
            if datatype.min_value:
                props_integer.min = int(datatype.min_value)
            if datatype.max_value:
                props_integer.max = int(datatype.max_value)

            dt_integer = ir.DatatypeDef(
                id=datatype.identifier,
                props=props_integer,
                name=decode_reqif_string(datatype.long_name) or "",
                description=decode_reqif_string(datatype.description) or None,
                last_change=datatype.last_change or None,
            )
            result[dt_integer.id] = dt_integer

        elif isinstance(datatype, ReqIFDataTypeDefinitionBoolean):
            dt_boolean = ir.DatatypeDef(
                id=datatype.identifier,
                props=ir.BoolProps(),
                name=decode_reqif_string(datatype.long_name) or "",
                description=decode_reqif_string(datatype.description) or None,
                last_change=datatype.last_change or None,
            )
            result[dt_boolean.id] = dt_boolean

        elif isinstance(datatype, ReqIFDataTypeDefinitionReal):
            props_real = ir.RealProps()
            if datatype.min_value:
                props_real.min = float(datatype.min_value)
            if datatype.max_value:
                props_real.max = float(datatype.max_value)
            if datatype.accuracy:
                props_real.accuracy = int(datatype.accuracy)

            dt_real = ir.DatatypeDef(
                id=datatype.identifier,
                props=props_real,
                name=decode_reqif_string(datatype.long_name) or "",
                description=decode_reqif_string(datatype.description) or None,
                last_change=datatype.last_change or None,
            )
            result[dt_real.id] = dt_real

        elif isinstance(datatype, ReqIFDataTypeDefinitionDateIdentifier):
            dt_date = ir.DatatypeDef(
                id=datatype.identifier,
                props=ir.DateProps(),
                name=decode_reqif_string(datatype.long_name) or "",
                description=decode_reqif_string(datatype.description) or None,
                last_change=datatype.last_change or None,
            )
            result[dt_date.id] = dt_date

        elif isinstance(datatype, ReqIFDataTypeDefinitionXHTML):
            dt_xhtml = ir.DatatypeDef(
                id=datatype.identifier,
                props=ir.XhtmlProps(),
                name=decode_reqif_string(datatype.long_name) or "",
                description=decode_reqif_string(datatype.description) or None,
                last_change=datatype.last_change or None,
            )
            result[dt_xhtml.id] = dt_xhtml

        elif isinstance(datatype, ReqIFDataTypeDefinitionEnumeration):
            props_enum = ir.EnumProps(values=_read_enum_values(datatype))

            dt_enum = ir.DatatypeDef(
                id=datatype.identifier,
                props=props_enum,
                name=decode_reqif_string(datatype.long_name) or "",
                description=decode_reqif_string(datatype.description) or None,
                last_change=datatype.last_change or None,
            )
            result[dt_enum.id] = dt_enum

    return result


def _read_enum_values(
    dt_enum: ReqIFDataTypeDefinitionEnumeration,
) -> dict[str, ir.EnumValue]:
    """Read ENUM-VALUES of a DATATYPE-DEFINITION-ENUMERATION."""
    result: dict[str, ir.EnumValue] = {}

    for enum_value in dt_enum.values or []:
        ev = ir.EnumValue(
            id=enum_value.identifier,
            name=ensure_long_name(
                enum_value
            ),  # long_name cannot be empty according to ReqIF spec, but the reqif lib allows it for some reason
            key=int(enum_value.key),
            description=decode_reqif_string(enum_value.description) or None,
            last_change=enum_value.last_change or None,
            other_content=enum_value.other_content or "",
        )
        result[ev.id] = ev

    return result


def write_datatypes_from_ir(
    datatypes: dict[str, ir.DatatypeDef[ir.DatatypeProps]],
) -> list[_ReqIFDataType]:
    """Convert IR datatypes to ReqIF datatype objects."""
    result: list[_ReqIFDataType] = []

    for datatype in datatypes.values():
        if isinstance(datatype.props, ir.StrProps):
            reqif_string = ReqIFDataTypeDefinitionString(
                identifier=datatype.id,
                long_name=encode_reqif_string(datatype.name),
                description=encode_reqif_string(datatype.description),
                last_change=datatype.last_change,
                max_length=str(datatype.props.max_length),
            )
            result.append(reqif_string)

        elif isinstance(datatype.props, ir.IntProps):
            reqif_integer = ReqIFDataTypeDefinitionInteger(
                identifier=datatype.id,
                long_name=encode_reqif_string(datatype.name),
                description=encode_reqif_string(datatype.description),
                last_change=datatype.last_change,
                min_value=str(datatype.props.min),
                max_value=str(datatype.props.max),
            )
            result.append(reqif_integer)

        elif isinstance(datatype.props, ir.BoolProps):
            reqif_boolean = ReqIFDataTypeDefinitionBoolean(
                identifier=datatype.id,
                long_name=encode_reqif_string(datatype.name),
                description=encode_reqif_string(datatype.description),
                last_change=datatype.last_change,
            )
            result.append(reqif_boolean)

        elif isinstance(datatype.props, ir.RealProps):
            reqif_real = ReqIFDataTypeDefinitionReal(
                identifier=datatype.id,
                long_name=encode_reqif_string(datatype.name),
                description=encode_reqif_string(datatype.description),
                last_change=datatype.last_change,
                min_value=str(datatype.props.min),
                max_value=str(datatype.props.max),
                accuracy=datatype.props.accuracy,
            )
            result.append(reqif_real)

        elif isinstance(datatype.props, ir.DateProps):
            reqif_date = ReqIFDataTypeDefinitionDateIdentifier(
                identifier=datatype.id,
                long_name=encode_reqif_string(datatype.name),
                description=encode_reqif_string(datatype.description),
                last_change=datatype.last_change,
            )
            result.append(reqif_date)

        elif isinstance(datatype.props, ir.XhtmlProps):
            reqif_xhtml = ReqIFDataTypeDefinitionXHTML(
                identifier=datatype.id,
                long_name=encode_reqif_string(datatype.name),
                description=encode_reqif_string(datatype.description),
                last_change=datatype.last_change,
            )
            result.append(reqif_xhtml)

        elif isinstance(datatype.props, ir.EnumProps):
            enum_values = _write_enum_values(datatype.props)
            reqif_enum = ReqIFDataTypeDefinitionEnumeration(
                identifier=datatype.id,
                long_name=encode_reqif_string(datatype.name),
                description=encode_reqif_string(datatype.description),
                last_change=datatype.last_change,
                values=enum_values,
            )
            result.append(reqif_enum)

        else:
            assert_never(datatype.props)

    return result


def _write_enum_values(
    props: ir.EnumProps,
) -> list[ReqIFEnumValue]:
    """Convert IR enum values to ReqIF ENUM-VALUES."""
    result: list[ReqIFEnumValue] = []

    for value in props.values.values():
        reqif_enum_value = ReqIFEnumValue(
            identifier=value.id,
            # KEY is mandatory on EMBEDDED-VALUE per ReqIF spec — fall back
            # to "0" (matching the SysML library default) so we never emit
            # the invalid literal ``KEY="None"`` from ``str(None)``.
            key=str(value.key) if value.key is not None else "0",
            long_name=encode_reqif_string(value.name),
            description=encode_reqif_string(value.description),
            last_change=value.last_change,
            # OTHER-CONTENT is mandatory on EMBEDDED-VALUE per ReqIF spec —
            # default missing IR values to "" so the attribute is always
            # emitted (the SysML round-trip can't distinguish an explicit
            # empty string from defaulting and may surface it as None here).
            other_content=value.other_content
            if value.other_content is not None
            else "",
        )
        result.append(reqif_enum_value)

    return result
