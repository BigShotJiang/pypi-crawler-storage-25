import _syside

import syside.reqif._ir_model as ir
from syside.reqif._sysml_utils import (
    BuildContext,
    set_or_update_description,
)
from syside.reqif._sysml_metadata import (
    add_reqif_tag,
    obtain_metadata_tag,
    set_redefined_string,
)
from syside.reqif._attribute_values_sysml import (
    make_attribute_value_field_re,
    update_attribute_usage,
    write_attribute_usage,
)


_OWNER_KIND_LABEL = "SpecObject"
_ATTR_VAL_FIELD_RE = make_attribute_value_field_re("attribute_value")


def create_spec_objects(
    package: _syside.Package,
    spec_objects: dict[str, ir.SpecObject],
    ctx: BuildContext,
) -> None:
    """
    Write **new** SpecObject elements into the given package.

    This function adds ID -> SysMLv2 element references back to BuildContext's ``refs`` dict.
    """
    for obj in spec_objects.values():
        _, req_def = package.children.append(
            _syside.OwningMembership, _syside.RequirementDefinition
        )
        req_def.declared_name = obj.name

        obj_type_ref = ctx.spec_type_req(obj.type_ref.id)
        req_def.heritage.append(_syside.Subclassification, obj_type_ref)

        add_reqif_tag(
            req_def,
            ctx.meta_tags.reqif_tag,
            identifier=obj.id,
            last_change=obj.last_change,
        )

        if obj.description:
            set_or_update_description(req_def, obj.description)

        for ir_attr in obj.attributes.values():
            _ = write_attribute_usage(
                req_def, ir_attr, _OWNER_KIND_LABEL, obj.name, ctx
            )

        ctx.refs[obj.id] = req_def


def update_spec_object(
    existing: _syside.RequirementDefinition,
    element_delta: ir.ElementDelta,
    new_ir: ir.SpecObject,
    ctx: BuildContext,
) -> _syside.Url:
    """
    Apply IR-level changes to an existing SysMLv2 SpecObject.

    ``existing`` is the RequirementDefinition representing the SpecObject in
    the loaded workspace model. ``element_delta`` is its entry from
    :class:`DeltaReport.spec_objects` and tells us *which* fields changed.
    ``new_ir`` carries the post-delta IR — needed because some FieldChanges
    (e.g. an added AttributeValue) only encode the new primitive value, not
    the full ``AttributeValue`` with its ``attr_def_ref``. ``ctx`` resolves
    cross-references (the new SpecType for ``type_ref`` changes, AttrDef
    targets for redefinitions, etc.).

    Walks ``element_delta.changes`` and dispatches each :class:`FieldChange`
    to a small per-field handler. Raises :class:`ValueError` on a field
    pattern this writer doesn't yet handle.

    Returns the URL of the document containing ``existing`` so the caller
    can collect affected documents (e.g. for ``rewrite_document``) and
    re-serialize them after a batch of updates. Every edit performed here
    stays within ``existing``'s document — the heritage rebind in
    ``type_ref`` updates only ``existing``'s relationship, not the target
    SpecType's document.
    """
    for change in element_delta.changes:
        field = change.field
        if field == "name":
            existing.declared_name = new_ir.name
        elif field == "type_ref":
            _update_type_ref(existing, new_ir.type_ref, ctx)
        elif field == "description":
            set_or_update_description(existing, new_ir.description)
        elif field == "last_change":
            _update_last_change(existing, new_ir.last_change, ctx)
        elif _ATTR_VAL_FIELD_RE.match(field):
            update_attribute_usage(
                existing,
                change,
                new_ir.attributes,
                ctx,
                field_re=_ATTR_VAL_FIELD_RE,
                owner_kind_label=_OWNER_KIND_LABEL,
                owner_name=new_ir.name,
            )
        else:
            raise ValueError(
                f"{_OWNER_KIND_LABEL} {new_ir.name!r}: unhandled delta field {field!r}"
            )

    return existing.document.url


def _update_type_ref(
    existing: _syside.RequirementDefinition,
    new_type_ref: ir.SpecObjectType,
    ctx: BuildContext,
) -> None:
    new_target = ctx.spec_type_req(new_type_ref.id)
    for index, rel in enumerate(existing.heritage.relationships):
        if rel.try_cast(_syside.Subclassification) is not None:
            existing.heritage.replace(index, _syside.Subclassification, new_target)
            return
    raise ValueError(
        f"expected a Subclassification on RequirementDefinition "
        f"{existing.declared_name!r}, found none"
    )


def _update_last_change(
    existing: _syside.RequirementDefinition,
    new_last_change: str | None,
    ctx: BuildContext,
) -> None:
    if new_last_change is None:
        # IR allows None, but the SysML side has no "unset" representation
        # short of removing the redefinition. Skip — leaves the existing
        # value untouched, matching the create-side behavior.
        return
    meta = obtain_metadata_tag(existing, ctx.meta_tags.reqif_tag.metadata_elem)
    if meta is None:
        raise ValueError(
            f"missing @reqif tag on RequirementDefinition {existing.declared_name!r}"
        )
    set_redefined_string(
        meta, ctx.meta_tags.reqif_tag.last_change_field, new_last_change
    )
