import re
from typing import Literal, NamedTuple, cast

import _syside

import syside.reqif._ir_model as ir
from syside.reqif._sysml_utils import (
    BuildContext,
    iter_heritage_rels_of_type,
    set_literal_value,
    set_signed_integer_literal,
    set_or_update_description,
)


class ScalarTypeInfo(NamedTuple):
    expected_type: type
    # ``"signed_int"`` dispatches through ``set_signed_integer_literal`` instead
    # of a single literal class (SysMLv2 has no native negative integer literal).
    literal_cls: type[_syside.LiteralExpression] | Literal["signed_int"]
    tag_attr: str  # attribute name on ``meta_tags`` for the datatype reqif tag
    scalar_key: Literal["String", "Integer", "Real", "Boolean"]
    value_label: str  # noun used in the error message (``non-{value_label} value``)
    def_label: str  # full phrase including article (``a String``, ``an Integer``)


SCALAR_TYPE_INFO: dict[type, ScalarTypeInfo] = {
    ir.IntAttrDef: ScalarTypeInfo(
        int, "signed_int", "reqif_integer_tag", "Integer", "integer", "an Integer"
    ),
    ir.RealAttrDef: ScalarTypeInfo(
        float, _syside.LiteralRational, "reqif_real_tag", "Real", "float", "a Real"
    ),
    ir.StringAttrDef: ScalarTypeInfo(
        str, _syside.LiteralString, "reqif_string_tag", "String", "string", "a String"
    ),
    ir.XhtmlAttrDef: ScalarTypeInfo(
        str, _syside.LiteralString, "reqif_xhtml_tag", "String", "string", "a XHTML"
    ),
    ir.BoolAttrDef: ScalarTypeInfo(
        bool,
        _syside.LiteralBoolean,
        "reqif_boolean_tag",
        "Boolean",
        "boolean",
        "a Boolean",
    ),
    ir.DateAttrDef: ScalarTypeInfo(
        str, _syside.LiteralString, "reqif_date_tag", "String", "string", "a Date"
    ),
}


def write_attribute_usage(
    parent: _syside.Namespace,
    attribute: ir.AttributeValue,
    owner_kind_label: str,
    owner_name: str,
    ctx: BuildContext,
    *,
    index: int | None = None,
) -> str | None:
    """
    Append an ``AttributeUsage`` child to ``parent``.

    ``owner_kind_label`` (e.g. ``"SpecObject"``, ``"Specification"``,
    ``"SpecRelation"``, ``"RelationGroup"``) and ``owner_name`` are used solely
    to build error messages.

    When ``index`` is given, the new AttributeUsage is inserted at that
    position in ``parent.children`` instead of being appended at the end —
    used by delta-update flows that delete an existing AttributeUsage and
    want to drop its replacement at the same position rather than letting
    it migrate to the end of the parent.

    If the attribute is ``ReqIF.Prefix`` with a string value, its value is returned
    from this function. This is needed on creation time to overcome the fact that
    the full model semantics are not known yet and syside.Compiler cannot be used to
    evaluate features.

    A scalar attribute whose ``value`` is ``None`` (no THE-VALUE in the
    source, or an explicit empty THE-VALUE that the reader normalised to
    ``None``) emits no AttributeUsage. SysMLv2 has no representation for
    "explicit empty integer/real/boolean", and treating string-likes the
    same way keeps the rule uniform — the SpecObject simply doesn't claim
    a value for that slot, matching ReqIF's "missing SpecObjectAttribute"
    semantics.
    """
    if attribute.attr_def_ref.name == "ReqIF.Name":
        return None
    elif attribute.attr_def_ref.name == "ReqIF.Description":
        set_or_update_description(
            parent,
            str(attribute.value) if attribute.value is not None else None,
            name="Description",
        )
        return None
    elif attribute.attr_def_ref.name == "ReqIF.Text":
        set_or_update_description(
            parent,
            str(attribute.value) if attribute.value is not None else None,
            name="Text",
        )
        return None

    info = SCALAR_TYPE_INFO.get(type(attribute.attr_def_ref.props))
    if info is not None and attribute.value is None:
        # No SysMLv2 literal can stand in for "missing THE-VALUE", so we
        # emit no AttributeUsage at all — a fresh import that includes an
        # empty scalar value drops the slot rather than crashing on the
        # type check below or picking an arbitrary default.
        return None

    if index is None:
        _, attr = parent.children.append(
            _syside.OwningMembership, _syside.AttributeUsage
        )
    else:
        _, attr = parent.children.insert(
            index, _syside.OwningMembership, _syside.AttributeUsage
        )

    # Set redefinition
    attr_def_ref = ctx.attr_def_ref(attribute.attr_def_ref.id)
    attr.heritage.insert(0, _syside.Redefinition, attr_def_ref)

    # Handle values
    if info is not None:
        if not isinstance(attribute.value, info.expected_type):
            raise ValueError(
                f"{owner_kind_label} {owner_name} attribute {attribute.attr_def_ref.name} "
                f"has non-{info.value_label} value {attribute.value}, "
                f"even though it is defined by {info.def_label} Attribute Definition."
            )
        if info.literal_cls == "signed_int":
            _ = set_signed_integer_literal(
                attr.feature_value_member, cast(int, attribute.value)
            )
        else:
            _ = set_literal_value(
                attr.feature_value_member,
                info.literal_cls,
                cast(str | int | float | bool, attribute.value),
            )

    elif ir.kind_of(attribute.attr_def_ref, ir.EnumAttrDef):
        if not isinstance(attribute.value, list) or not all(
            isinstance(v, ir.EnumValue) for v in attribute.value
        ):
            raise ValueError(
                f"{owner_kind_label} {owner_name} attribute {attribute.attr_def_ref.name} "
                f"has non-enum value {attribute.value}, "
                f"even though it is defined by an Enum Attribute Definition."
            )
        # Check if enum is allowed to be multi-valued
        if attribute.attr_def_ref.props.multi_valued:
            # Create the list
            _, op_expr = attr.feature_value_member.set_member_element(
                _syside.OperatorExpression
            )
            op_expr.operator = _syside.ExplicitOperator.Comma
            # Add values to the list
            for value in attribute.value:
                enum_val_ref = ctx.enum_value(value.id)
                _, arg = op_expr.arguments.append(_syside.FeatureReferenceExpression)
                arg.referent_member.set_member_element(enum_val_ref)
        else:
            if len(attribute.value) != 1:
                raise ValueError(
                    f"{owner_kind_label} {owner_name} attribute {attribute.attr_def_ref.name} "
                    f"has multi-valued value {attribute.value}, "
                    f"even though it is defined by a non-multi-valued Enum Attribute Definition."
                )
            enum_val_ref = ctx.enum_value(attribute.value[0].id)
            _, enum_expr = attr.feature_value_member.set_member_element(
                _syside.FeatureReferenceExpression
            )
            enum_expr.referent_member.set_member_element(enum_val_ref)

    else:
        assert False, "unreachable"

    if attribute.attr_def_ref.name == "ReqIF.Prefix" and isinstance(
        attribute.value, str
    ):
        return attribute.value

    return None


def find_attribute_usage_index(
    parent: _syside.Namespace,
    target_attr_def: _syside.AttributeUsage,
) -> int | None:
    """
    Return the index in ``parent.children`` of the AttributeUsage child whose
    Redefinition heritage targets ``target_attr_def``, or ``None`` if absent.
    """
    for index, child in enumerate(parent.children.elements):
        attr = child.try_cast(_syside.AttributeUsage)
        if attr is None:
            continue
        for redef in iter_heritage_rels_of_type(attr, _syside.Redefinition):
            if redef.first_target is target_attr_def:
                return index
    return None


def make_attribute_value_field_re(field_prefix: str) -> re.Pattern[str]:
    """
    Build the regex matching ``<field_prefix>[<id>]`` and
    ``<field_prefix>[<id>].value`` for a given diff field prefix.

    The five element categories that carry attribute values use different
    field prefixes in their FieldChange records: ``"attribute_value"`` for
    SpecObject / SpecRelation / RelationGroup, ``"spec_attribute"`` for
    Specification. The regex shape is otherwise identical.
    """
    return re.compile(
        rf"^{re.escape(field_prefix)}\[(?P<id>[^\]]+)\](?P<dot>\.value)?$"
    )


def update_attribute_usage(
    existing: _syside.Namespace,
    change: ir.FieldChange,
    new_ir_attributes: dict[str, ir.AttributeValue],
    ctx: BuildContext,
    *,
    field_re: re.Pattern[str],
    owner_kind_label: str,
    owner_name: str,
) -> None:
    """
    Apply one ``<field_prefix>[X]`` / ``<field_prefix>[X].value`` change.

    Mirrors the routing in :func:`write_attribute_usage`:

    * ``ReqIF.Name`` is skipped — the SpecObject's ``name`` field handler
      already covers it (``write_attribute_usage`` doesn't materialize a
      child for this name on creation either).
    * ``ReqIF.Description`` / ``ReqIF.Text`` are routed to
      ``set_or_update_description`` with the corresponding doc-name; the
      value-or-None of the new IR attribute drives create / update / remove.
    * Everything else is generic AttributeUsage handling: value-changes
      delete + insert at the original index (so the field doesn't migrate
      to the end of the parent), additions append, removals extract.
    """
    m = field_re.match(change.field)
    assert m is not None  # caller already matched with the same regex
    attr_id = m.group("id")
    is_value_change = m.group("dot") is not None

    target_attr_def = ctx.attr_def_ref(attr_id)
    new_value = new_ir_attributes.get(attr_id)
    attr_name = (
        new_value.attr_def_ref.name
        if new_value is not None
        else target_attr_def.declared_name
    )

    if attr_name == "ReqIF.Name":
        return
    if attr_name in ("ReqIF.Description", "ReqIF.Text"):
        doc_name = "Description" if attr_name == "ReqIF.Description" else "Text"
        new_text = (
            str(new_value.value)
            if new_value is not None and new_value.value is not None
            else None
        )
        set_or_update_description(existing, new_text, name=doc_name)
        return

    found_index = find_attribute_usage_index(existing, target_attr_def)

    if is_value_change:
        if found_index is None:
            raise ValueError(
                f"{owner_kind_label} {owner_name!r}: AttributeUsage redefining "
                f"{attr_id!r} not found for value update"
            )
        existing.children.extract(found_index)
        assert new_value is not None
        _ = write_attribute_usage(
            existing,
            new_value,
            owner_kind_label,
            owner_name,
            ctx,
            index=found_index,
        )
    elif change.new is None:
        if found_index is None:
            return  # already gone; idempotent
        existing.children.extract(found_index)
    else:
        assert new_value is not None
        _ = write_attribute_usage(
            existing, new_value, owner_kind_label, owner_name, ctx
        )
