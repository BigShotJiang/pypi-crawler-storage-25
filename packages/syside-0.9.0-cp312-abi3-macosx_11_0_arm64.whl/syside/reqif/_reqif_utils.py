from __future__ import annotations

import html
import os
import tempfile
import zipfile
from pathlib import Path

from collections.abc import Iterable
from dataclasses import dataclass

from reqif.models.reqif_data_type import ReqIFEnumValue
from reqif.models.reqif_relation_group import ReqIFRelationGroup
from reqif.models.reqif_spec_object import ReqIFSpecObject, SpecObjectAttribute
from reqif.models.reqif_spec_object_type import SpecAttributeDefinition
from reqif.models.reqif_spec_relation import ReqIFSpecRelation
from reqif.models.reqif_specification import ReqIFSpecification
from reqif.models.reqif_types import SpecObjectAttributeType
from reqif.parser import ReqIFParser
from reqif.reqif_bundle import ReqIFBundle

from . import _ir_model as ir

from ._xhtml_markdown import xhtml_to_markdown, markdown_to_xhtml


# ---------------------------------------------------------------------------
# Convenience dataclasses
# ---------------------------------------------------------------------------
@dataclass(frozen=True, slots=True)
class ElementRef:
    """
    Identifies a ReqIF element for use in error messages.

    Combines the element ``kind`` (e.g. ``"SPEC-OBJECT"``) with its
    ``id`` so a single parameter can replace the ``element_kind`` /
    ``element_id`` pair across the reader helpers.
    """

    kind: str
    id: str

    def __str__(self) -> str:
        return f"{self.kind} {self.id}"


# ---------------------------------------------------------------------------
# File loading
# ---------------------------------------------------------------------------
def load_reqif(path: Path, attachments_dir: Path) -> ReqIFBundle:
    """
    Parse a ReqIF or ReqIFz file.

    For ReqIFz archives:
    - The contained ReqIF file is parsed.
    - All other members are extracted to `attachments_dir` (if provided).

    Returns a parsed ReqIF object.
    """
    suffix = path.suffix.lower()

    if suffix == ".reqifz":
        return _load_reqifz(path, attachments_dir)
    else:
        return ReqIFParser.parse(str(path))


def _load_reqifz(path: Path, attachments_dir: Path) -> ReqIFBundle:
    """Extract and parse a ReqIFz zip archive."""
    with zipfile.ZipFile(path, "r") as zf:
        members = zf.namelist()

        reqif_members = [m for m in members if m.lower().endswith(".reqif")]
        if not reqif_members:
            raise ValueError(f"No .reqif file found inside {path}")
        if len(reqif_members) > 1:
            # FIXME: multi-`.reqif` archives unsupported; reject for now to avoid
            # unresolved sysml-side tracking on export.
            raise ValueError(
                f"Expected exactly one .reqif entry inside {path}, "
                f"found {len(reqif_members)}: {reqif_members}"
            )

        reqif_member = reqif_members[0]

        attachments_dir.mkdir(parents=True, exist_ok=True)
        # Stage extraction in a private tempdir (POSIX mode 0700 / Windows
        # restricted ACL, courtesy of ``tempfile``) created inside
        # ``attachments_dir`` so the extract itself cannot be raced.
        # Writing directly to the final destination would leave a symlink
        # TOCTOU window between the ``resolve()`` safety check and
        # ``zf.extract`` — a co-resident attacker could plant a symlink
        # in that window to escape the directory. After extraction the
        # files are moved into ``attachments_dir`` with ``os.replace``,
        # which renames the literal target path rather than following a
        # symlink at the leaf, and any intermediate path component that
        # is itself a symlink is refused.
        with tempfile.TemporaryDirectory(
            prefix=".syside_reqifz_", dir=attachments_dir
        ) as tmp_str:
            tmp_extract_dir = Path(tmp_str)
            tmp_root = tmp_extract_dir.resolve()
            for member in members:
                if member.lower().endswith(".reqif"):
                    continue
                target_path = (tmp_root / member).resolve()
                if not target_path.is_relative_to(tmp_root):
                    raise ValueError(f"Unsafe path in archive: {member}")
                zf.extract(member, tmp_extract_dir)

            for src in list(tmp_extract_dir.rglob("*")):
                if src.is_dir() and not src.is_symlink():
                    continue
                rel = src.relative_to(tmp_extract_dir)
                cur = attachments_dir
                for part in rel.parts[:-1]:
                    cur = cur / part
                    if cur.is_symlink():
                        raise ValueError(
                            f"Refusing to extract {rel}: path component "
                            f"{cur} is a symlink"
                        )
                    cur.mkdir(exist_ok=True)
                dst = attachments_dir / rel
                if dst.is_symlink():
                    raise ValueError(f"Refusing to overwrite symlink at {dst}")
                os.replace(src, dst)

        reqif_bytes = zf.read(reqif_member)

    return ReqIFParser.parse_from_string(reqif_bytes.decode("utf-8"))


# ---------------------------------------------------------------------------
# Name utilities
# ---------------------------------------------------------------------------
def resolve_spec_element_name(
    element: ReqIFSpecObject
    | ReqIFSpecification
    | ReqIFSpecRelation
    | ReqIFRelationGroup,
    spec_types: dict[str, ir.SpecType[ir.SpecKind]],
) -> str:
    """
    Derive name using the three-step priority. This implementation will
    always give priority to the ReqIF.Name attribute, even if LONG-NAME is
    present and nonempty. On export, the name will always be written to the
    ReqIF.Name attribute if it is present (and into LONG-NAME too).

    1. ReqIF.Name attribute value (XHTML, converted to Markdown)
    2. LONG-NAME
    3. IDENTIFIER
    """
    # Reqif library uses different field names for the type ref and attribute
    # values on each element kind; normalise them here so callers just pass the
    # element.
    type_id: str | None
    reqif_attrs: Iterable[SpecObjectAttribute] | None
    if isinstance(element, ReqIFSpecObject):
        type_id = element.spec_object_type
        reqif_attrs = element.attributes
    elif isinstance(element, ReqIFSpecification):
        type_id = element.specification_type
        reqif_attrs = element.values
    else:
        # FIXME: ReqIFSpecRelation exposes `values_attribute` as a single value rather
        # than a list, and ReqIFRelationGroup has no attributes at all; for both
        # we skip the ReqIF.Name lookup and fall through to LONG-NAME/IDENTIFIER.
        # Do not want to code any workarounds of casting single value to the list now,
        # as then I will need to code in the writing code as well, and it will get messy.
        # Ignoring it until it is fixed is cleaner.
        type_id = (
            element.relation_type_ref
            if isinstance(element, ReqIFSpecRelation)
            else element.type_ref
        )
        reqif_attrs = None

    spec_type = spec_types.get(type_id or "")
    name_attr_id = (
        next(
            (
                ad.id
                for ad in spec_type.attribute_defs.values()
                if ad.name == "ReqIF.Name"
            ),
            None,
        )
        if spec_type is not None
        else None
    )

    if name_attr_id is not None:
        reqif_name_raw = next(
            (av.value for av in reqif_attrs or [] if av.definition_ref == name_attr_id),
            None,
        )
        if isinstance(reqif_name_raw, list):
            raise ValueError(
                f"Element {element.identifier} has ReqIF.Name attribute with list value"
            )

        if reqif_name_raw is not None:
            name = xhtml_to_markdown(reqif_name_raw).strip()
            if name:
                return name

    name = (decode_reqif_string(element.long_name) or "").strip()
    return name if name else element.identifier


def ensure_long_name(obj: SpecAttributeDefinition | ReqIFEnumValue) -> str:
    """
    Return obj.long_name, raising ValueError if it is missing or empty.

    Use this for ReqIF elements where LONG-NAME is mandatory per the spec:
    - ENUM-VALUE
    - ATTRIBUTE-DEFINITION-*
    """
    name = (decode_reqif_string(obj.long_name) or "").strip()
    if not name:
        raise ValueError(
            f"{type(obj).__name__} '{obj.identifier}' is missing required LONG-NAME"
        )
    return name


# ---------------------------------------------------------------------------
# String encoding/decoding utilities
# ---------------------------------------------------------------------------
def decode_reqif_string(value: str | None) -> str | None:
    """Decode XML/HTML character references in a ReqIF string attribute."""
    if not value:
        return value
    return html.unescape(value)


def encode_reqif_string(value: str | None) -> str | None:
    """
    Encode a Python string for safe embedding in a ReqIF XML attribute.

    Multi-line STRING attribute values are not supported: literal CR/LF/TAB
    in an XML attribute value are collapsed to a single space by XML 1.0
    §3.3.3 attribute-value normalization, so they would be lost on the
    reader side anyway.
    """
    if value is None:
        return None
    return html.escape(value, quote=True)


# ---------------------------------------------------------------------------
# Attribute utilities
# ---------------------------------------------------------------------------
def parse_xs_boolean(raw: str) -> bool:
    """Parse xs:boolean lexical space (true/false/1/0); raise on anything else."""
    if raw in ("true", "1"):
        return True
    if raw in ("false", "0"):
        return False
    raise ValueError(f"invalid xs:boolean value {raw!r}")


def _convert_attr_value(
    av: ir.AttributeValue, attachments_dir: str
) -> SpecObjectAttribute:
    """
    Convert an attribute value from IR into ReqIF.

    Since the `reqif` library only accepts strings as values, we stringify everything.
    """
    reqif_value: str | list[str]
    if isinstance(av, ir.EnumAttrValue):
        reqif_value = [ev.id for ev in av.value]
    elif av.value is None:
        reqif_value = ""
    elif isinstance(av, ir.BoolAttrValue):
        reqif_value = str(av.value).lower()
    elif isinstance(av, ir.XhtmlAttrValue):
        reqif_value = markdown_to_xhtml(av.value, attachments_dir)
    else:  # IntAttrValue, RealAttrValue, DateAttrValue, StringAttrValue
        reqif_value = str(av.value)

    return SpecObjectAttribute(
        attribute_type=SpecObjectAttributeType[av.TYPE],
        definition_ref=av.attr_def_ref.id,
        value=reqif_value,
    )


def _require_scalar(
    attr: SpecObjectAttribute,
    src: ElementRef,
    type_name: str,
) -> str:
    """
    Return ``attr.value`` narrowed to a scalar string.

    Every non-ENUM branch of the attribute-value reader needs to reject
    list-valued attrs with the same error shape. This centralises that
    guard so each branch body becomes a single expression.

    Raises ``ValueError`` if ``attr.value`` is a list.
    """
    if isinstance(attr.value, list):
        raise ValueError(f"{src} has {type_name} attribute with list value")
    return attr.value


def read_attrs(
    reqif_attrs: Iterable[SpecObjectAttribute],
    attr_defs_by_id: dict[str, ir.AttributeDef[ir.AttributeDefProps]],
    src: ElementRef,
    attachments_dir: str,
) -> dict[str, ir.AttributeValue]:
    """
    Read the attribute values for any SpecElementWithAttributes, such as:

    - SPEC-OBJECT
    - SPECIFICATION
    - SPEC-RELATION
    - RELATION-GROUP

    Returns a dict keyed by the referenced ``AttributeDef.id``.
    """
    attributes: dict[str, ir.AttributeValue] = {}

    for attr in reqif_attrs:
        attr_def_ref_id = attr.definition_ref
        attr_def = attr_defs_by_id.get(attr_def_ref_id)
        if attr_def is None:
            raise ValueError(
                f"{src} has attribute with unknown definition reference {attr_def_ref_id}"
            )

        av: ir.AttributeValue

        if ir.kind_of(attr_def, ir.EnumAttrDef):
            raw_ids = [attr.value] if isinstance(attr.value, str) else list(attr.value)
            av = ir.EnumAttrValue(
                attr_def_ref=attr_def,
                value=[
                    resolve_ref(
                        ev_id,
                        attr_def.props.datatype_def.props.values,
                        src=src,
                        ref_kind="enum value",
                    )
                    for ev_id in raw_ids
                ],
            )
        else:
            raw = _require_scalar(attr, src, attr_def.kind)
            if ir.kind_of(attr_def, ir.StringAttrDef):
                av = ir.StringAttrValue(attr_def_ref=attr_def, value=raw or None)
            elif ir.kind_of(attr_def, ir.IntAttrDef):
                av = ir.IntAttrValue(
                    attr_def_ref=attr_def, value=int(raw) if raw else None
                )
            elif ir.kind_of(attr_def, ir.BoolAttrDef):
                av = ir.BoolAttrValue(
                    attr_def_ref=attr_def,
                    value=parse_xs_boolean(raw) if raw else None,
                )
            elif ir.kind_of(attr_def, ir.RealAttrDef):
                av = ir.RealAttrValue(
                    attr_def_ref=attr_def, value=float(raw) if raw else None
                )
            elif ir.kind_of(attr_def, ir.DateAttrDef):
                av = ir.DateAttrValue(attr_def_ref=attr_def, value=raw or None)
            elif ir.kind_of(attr_def, ir.XhtmlAttrDef):
                # Empty XHTML body (`<reqif-xhtml:div></reqif-xhtml:div>`) and a
                # missing THE-VALUE both collapse to `None` so round-trips are
                # idempotent — `markdown_to_xhtml(None)` and `markdown_to_xhtml('')`
                # both emit nothing in THE-VALUE on write.
                md = xhtml_to_markdown(raw, attachments_dir) if raw else ""
                av = ir.XhtmlAttrValue(
                    attr_def_ref=attr_def,
                    value=md or None,
                )
            else:
                assert False, "unreachable"

        attributes[attr_def.id] = av

    return attributes


def build_reqif_attrs_with_name_injection(
    ir_attributes: dict[str, ir.AttributeValue],
    spec_type: ir.SpecType[ir.SpecKind],
    name: str,
    attachments_dir: str,
) -> list[SpecObjectAttribute]:
    """
    When writing IR -> ReqIF, this function will translate IR attribute values
    to ReqIF.

    Additionally, this function will inject the ReqIF.Name attribute if it is not
    already set as an attribute and its attribute definition exists on the SpecType.
    """
    attrs = [_convert_attr_value(av, attachments_dir) for av in ir_attributes.values()]

    name_attr_def = next(
        (ad for ad in spec_type.attribute_defs.values() if ad.name == "ReqIF.Name"),
        None,
    )
    if name_attr_def is not None and name_attr_def.id not in ir_attributes:
        attrs.insert(
            0,
            SpecObjectAttribute(
                attribute_type=SpecObjectAttributeType.XHTML,
                definition_ref=name_attr_def.id,
                value=markdown_to_xhtml(name, attachments_dir),
            ),
        )
    return attrs


# ---------------------------------------------------------------------------
# Reference resolution utilities
# ---------------------------------------------------------------------------
def resolve_ref[T](
    ref_id: str | None,
    lookup: dict[str, T],
    src: ElementRef,
    ref_kind: str,
) -> T:
    """Check if the reference exists when parsing ReqIF"""
    if ref_id is None:
        raise ValueError(f"{src} has no {ref_kind} set.")
    target = lookup.get(ref_id)
    if target is None:
        raise ValueError(f"{src} has unknown {ref_kind} reference {ref_id}")
    return target
