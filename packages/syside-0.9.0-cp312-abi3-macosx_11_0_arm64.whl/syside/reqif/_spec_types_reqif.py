from __future__ import annotations

from typing import Any, assert_never

from reqif.models.reqif_req_if_content import ReqIFReqIFContent

from reqif.models.reqif_relation_group_type import ReqIFRelationGroupType
from reqif.models.reqif_spec_object_type import (
    DefaultValueEmptySelfClosedTag,
    ReqIFSpecObjectType,
    SpecAttributeDefinition,
)
from reqif.models.reqif_spec_relation_type import ReqIFSpecRelationType
from reqif.models.reqif_specification_type import ReqIFSpecificationType
from reqif.models.reqif_types import SpecObjectAttributeType

from . import _ir_model as ir
from ._reqif_utils import (
    ElementRef,
    decode_reqif_string,
    encode_reqif_string,
    ensure_long_name,
    parse_xs_boolean,
    resolve_ref,
)

from ._xhtml_markdown import markdown_to_xhtml, xhtml_to_markdown


def _read_attribute_defs(
    attribute_definitions: list[SpecAttributeDefinition] | None,
    datatypes: dict[str, ir.DatatypeDef[ir.DatatypeProps]],
    attachments_dir: str,
) -> dict[str, ir.AttributeDef[ir.AttributeDefProps]]:
    """Convert a list of SPEC-ATTRIBUTES to a dict of IR AttributeDefs keyed by id."""
    result: dict[str, ir.AttributeDef[ir.AttributeDefProps]] = {}

    for attr_def in attribute_definitions or []:
        datatype_id = attr_def.datatype_definition
        datatype_def = datatypes.get(datatype_id)
        if datatype_def is None:
            raise ValueError(
                f"Attribute '{attr_def.identifier}' references unknown datatype '{datatype_id}'."
            )

        raw_default = attr_def.default_value
        if isinstance(raw_default, DefaultValueEmptySelfClosedTag):
            default_value = None
        else:
            default_value = raw_default

        props: ir.AttributeDefProps
        if ir.kind_of(datatype_def, ir.StrProps):
            props = ir.StringAttrDef(
                datatype_def=datatype_def,
                default_value=default_value,
            )
        elif ir.kind_of(datatype_def, ir.IntProps):
            props = ir.IntAttrDef(
                datatype_def=datatype_def,
                default_value=int(default_value) if default_value is not None else None,
            )
        elif ir.kind_of(datatype_def, ir.BoolProps):
            props = ir.BoolAttrDef(
                datatype_def=datatype_def,
                default_value=(
                    parse_xs_boolean(default_value)
                    if default_value is not None
                    else None
                ),
            )
        elif ir.kind_of(datatype_def, ir.RealProps):
            props = ir.RealAttrDef(
                datatype_def=datatype_def,
                default_value=(
                    float(default_value) if default_value is not None else None
                ),
            )
        elif ir.kind_of(datatype_def, ir.DateProps):
            props = ir.DateAttrDef(
                datatype_def=datatype_def,
                default_value=default_value,
            )
        elif ir.kind_of(datatype_def, ir.XhtmlProps):
            props = ir.XhtmlAttrDef(
                datatype_def=datatype_def,
                default_value=(
                    xhtml_to_markdown(default_value, attachments_dir)
                    if default_value is not None
                    else None
                ),
            )
        elif ir.kind_of(datatype_def, ir.EnumProps):
            found_value: ir.EnumValue | None = None
            if default_value is not None:
                found_value = resolve_ref(
                    ref_id=default_value,
                    lookup=datatype_def.props.values,
                    src=ElementRef(
                        "ATTRIBUTE-DEFINITION-ENUMERATION", attr_def.identifier
                    ),
                    ref_kind="ENUM-VALUE-REF default",
                )

            props = ir.EnumAttrDef(
                datatype_def=datatype_def,
                default_value=found_value,
                multi_valued=attr_def.multi_valued or False,
            )
        else:
            assert False, "unreachable"

        ir_attr_def = ir.AttributeDef(
            id=attr_def.identifier,
            name=ensure_long_name(attr_def),
            description=decode_reqif_string(attr_def.description),
            last_change=attr_def.last_change,
            props=props,
            is_editable=attr_def.editable or False,
        )
        result[ir_attr_def.id] = ir_attr_def

    return result


def read_spec_types_to_ir(
    content: ReqIFReqIFContent,
    datatype_defs: dict[str, ir.DatatypeDef[ir.DatatypeProps]],
    attachments_dir: str,
) -> dict[str, ir.SpecType[ir.SpecKind]]:
    """
    Extract all SPEC-TYPE and its subclasses (object, specification, relation, relation group) into IR.

    Returns a dict mapping ``SpecType.id`` to the ``SpecType``.
    """
    result: dict[str, ir.SpecType[ir.SpecKind]] = {}

    for spec_type in content.spec_types or []:
        if isinstance(spec_type, ReqIFSpecObjectType):
            object_attr_defs = _read_attribute_defs(
                attribute_definitions=spec_type.attribute_definitions,
                datatypes=datatype_defs,
                attachments_dir=attachments_dir,
            )

            st_object = ir.SpecType(
                id=spec_type.identifier,
                kind=ir.SpecKind.OBJECT,
                name=decode_reqif_string(spec_type.long_name) or "",
                attribute_defs=object_attr_defs,
                description=decode_reqif_string(spec_type.description),
                last_change=spec_type.last_change,
            )
            result[st_object.id] = st_object

        elif isinstance(spec_type, ReqIFSpecRelationType):
            relation_attr_defs = _read_attribute_defs(
                attribute_definitions=spec_type.attribute_definitions,
                datatypes=datatype_defs,
                attachments_dir=attachments_dir,
            )

            st_relation = ir.SpecType(
                id=spec_type.identifier,
                kind=ir.SpecKind.RELATION,
                name=decode_reqif_string(spec_type.long_name) or "",
                attribute_defs=relation_attr_defs,
                description=decode_reqif_string(spec_type.description),
                last_change=spec_type.last_change,
            )
            result[st_relation.id] = st_relation

        elif isinstance(spec_type, ReqIFSpecificationType):
            specification_attr_defs = _read_attribute_defs(
                attribute_definitions=spec_type.spec_attributes,
                datatypes=datatype_defs,
                attachments_dir=attachments_dir,
            )

            st_specification = ir.SpecType(
                id=spec_type.identifier,
                kind=ir.SpecKind.SPECIFICATION,
                name=decode_reqif_string(spec_type.long_name) or "",
                attribute_defs=specification_attr_defs,
                description=decode_reqif_string(spec_type.description),
                last_change=spec_type.last_change,
            )
            result[st_specification.id] = st_specification

        elif isinstance(spec_type, ReqIFRelationGroupType):
            relation_group_attr_defs = _read_attribute_defs(
                attribute_definitions=spec_type.attribute_definitions,
                datatypes=datatype_defs,
                attachments_dir=attachments_dir,
            )
            st_relation_group = ir.SpecType(
                id=spec_type.identifier,
                kind=ir.SpecKind.RELATION_GROUP,
                name=decode_reqif_string(spec_type.long_name) or "",
                attribute_defs=relation_group_attr_defs,
                description=decode_reqif_string(spec_type.description),
                last_change=spec_type.last_change,
            )
            result[st_relation_group.id] = st_relation_group

        else:
            assert_never(spec_type)

    return result


def _build_attr_defs(
    attribute_defs: dict[str, ir.AttributeDef[ir._AD]],
    attachments_dir: str,
) -> list[SpecAttributeDefinition]:
    """
    Convert a dict of IR AttributeDefs to a list of SPEC-ATTRIBUTES for ReqIF export.
    """
    result = []
    for attr_def in attribute_defs.values():
        attr_type = SpecObjectAttributeType[attr_def.kind]
        datatype_def_id = attr_def.props.datatype_def.id

        default_value = None
        default_value_definition_ref = None

        if attr_def.props.default_value is not None:
            default_value_definition_ref = attr_def.id
            if ir.kind_of(attr_def, ir.EnumAttrDef):
                default_value = attr_def.props.default_value.id
            elif ir.kind_of(attr_def, ir.StringAttrDef):
                # The reqif unparser drops the default value verbatim into
                # THE-VALUE="..." without escaping, so XML specials must be
                # encoded here for parity with the spec-attribute-value path.
                default_value = encode_reqif_string(attr_def.props.default_value)
            elif ir.kind_of(attr_def, ir.XhtmlAttrDef):
                # Re-wrap markdown back to ``<reqif-xhtml:div>...</…div>``,
                # mirroring what ``_convert_attr_value`` does for XHTML
                # AttributeValue payloads. Plain ``str()`` would leave the
                # IR's markdown form bare and produce invalid ReqIF.
                default_value = markdown_to_xhtml(
                    attr_def.props.default_value, attachments_dir
                )
            elif ir.kind_of(attr_def, ir.BoolAttrDef):
                # ReqIF's xs:boolean lexical form is "true"/"false"; ``str()``
                # of a Python bool produces "True"/"False". Mirror the
                # AttributeValue path's ``str(...).lower()``.
                default_value = str(attr_def.props.default_value).lower()
            else:
                default_value = str(attr_def.props.default_value)

        result.append(
            SpecAttributeDefinition(
                attribute_type=attr_type,
                identifier=attr_def.id,
                datatype_definition=datatype_def_id,
                long_name=attr_def.name,
                description=attr_def.description,
                last_change=attr_def.last_change,
                editable="true" if attr_def.is_editable else None,
                multi_valued=(
                    attr_def.props.multi_valued
                    if ir.kind_of(attr_def, ir.EnumAttrDef)
                    else None
                ),
                default_value=default_value,
                default_value_definition_ref=default_value_definition_ref,
            )
        )
    return result


def write_spec_types_from_ir(
    spec_types: dict[str, ir.SpecType[ir.SpecKind]],
    attachments_dir: str,
) -> list[
    ReqIFSpecObjectType
    | ReqIFSpecRelationType
    | ReqIFSpecificationType
    | ReqIFRelationGroupType
]:
    """
    Convert IR spec types to SPEC-OBJECT-TYPE, SPECIFICATION-TYPE,
    SPEC-RELATION-TYPE, and RELATION-GROUP-TYPE objects.
    """
    result: list[
        ReqIFSpecObjectType
        | ReqIFSpecRelationType
        | ReqIFSpecificationType
        | ReqIFRelationGroupType
    ] = []

    for spec_type in spec_types.values():
        common: dict[str, Any] = dict(
            identifier=spec_type.id,
            description=encode_reqif_string(spec_type.description),
            last_change=spec_type.last_change,
            long_name=encode_reqif_string(spec_type.name),
        )
        attr_defs = _build_attr_defs(spec_type.attribute_defs, attachments_dir)

        if spec_type.kind == ir.SpecKind.OBJECT:
            result.append(
                ReqIFSpecObjectType(**common, attribute_definitions=attr_defs)
            )
        elif spec_type.kind == ir.SpecKind.RELATION:
            result.append(
                ReqIFSpecRelationType(**common, attribute_definitions=attr_defs)
            )
        elif spec_type.kind == ir.SpecKind.SPECIFICATION:
            result.append(ReqIFSpecificationType(**common, spec_attributes=attr_defs))
        elif spec_type.kind == ir.SpecKind.RELATION_GROUP:
            result.append(
                ReqIFRelationGroupType(**common, attribute_definitions=attr_defs)
            )
        else:
            assert_never(spec_type.kind)

    return result
