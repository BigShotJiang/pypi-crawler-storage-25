"""
Intermediate representation (IR) for ReqIF import/export.

Makes it easier to convert between ReqIF XML and SysMLv2, and diff
between two versions of content regardless of the source (ReqIF or SysMLv2).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from collections.abc import Callable
from typing import (
    Any,
    ClassVar,
    Generic,
    Literal,
    Protocol,
    TypeVar,
    TypeGuard,
    cast,
    overload,
)


class _HasIdName(Protocol):
    id: str
    name: str


_T = TypeVar("_T", bound=_HasIdName)


# ---------------------------------------------------------------------------
# Datatypes
# ---------------------------------------------------------------------------


@dataclass
class EnumValue:
    """
    Combines ReqIF's EnumValue (10.8.31) and EmbeddedValue (10.8.30) into one dataclass.

    Maps to SysMLv2's ``enum`` with the ``@reqif_enum_value`` tag.
    """

    id: str
    name: str  # long_name mandatory for EnumValue according to ReqIF spec
    description: str | None = None
    last_change: str | None = None
    key: int | None = None  # EMBEDDED-VALUE KEY
    other_content: str = ""  # EMBEDDED-VALUE OTHER-CONTENT


class AttrType(StrEnum):
    """
    Possible types of datatypes/attributes according to ReqIF spec.
    """

    STRING = "STRING"
    INTEGER = "INTEGER"
    BOOLEAN = "BOOLEAN"
    REAL = "REAL"
    DATE = "DATE"
    ENUMERATION = "ENUMERATION"
    XHTML = "XHTML"


@dataclass
class StrProps:
    """
    Corresponds to ReqIF's DatatypeDefinitionString (10.8.28).
    """

    TYPE: ClassVar[AttrType] = AttrType.STRING
    max_length: int = 32767  # Our default in case some ReqIF exports don't specify this


@dataclass
class IntProps:
    """
    Corresponds to ReqIF's DatatypeDefinitionInteger (10.8.25).
    """

    TYPE: ClassVar[AttrType] = AttrType.INTEGER
    min: int = (
        -9223372036854775808
    )  # i64 min; our default in case some ReqIF exports don't specify this
    max: int = 9223372036854775807  # i64 max; our default in case some ReqIF exports don't specify this


@dataclass
class RealProps:
    """
    Corresponds to ReqIF's DatatypeDefinitionReal (10.8.26).
    """

    TYPE: ClassVar[AttrType] = AttrType.REAL
    min: float = (
        -1.79e308
    )  # -f64 min; our default in case some ReqIF exports don't specify this
    max: float = (
        1.79e308  # f64 max; our default in case some ReqIF exports don't specify this
    )
    accuracy: int = 15  # number of significant digits; our default in case some ReqIF exports don't specify this


@dataclass
class BoolProps:
    """
    Corresponds to ReqIF's DatatypeDefinitionBoolean (10.8.22).
    """

    TYPE: ClassVar[AttrType] = AttrType.BOOLEAN


@dataclass
class DateProps:
    """
    Corresponds to ReqIF's DatatypeDefinitionDate (10.8.23).
    """

    TYPE: ClassVar[AttrType] = AttrType.DATE


@dataclass
class XhtmlProps:
    """
    Corresponds to ReqIF's DatatypeDefinitionXhtml (10.8.29).
    """

    TYPE: ClassVar[AttrType] = AttrType.XHTML


@dataclass
class EnumProps:
    """
    Corresponds to ReqIF's DatatypeDefinitionEnumeration (10.8.24).

    Maps to SysMLv2's ``enum def`` with the ``@reqif`` tag.
    """

    TYPE: ClassVar[AttrType] = AttrType.ENUMERATION
    values: dict[str, EnumValue] = field(default_factory=dict)


DatatypeProps = (
    StrProps | IntProps | RealProps | BoolProps | DateProps | XhtmlProps | EnumProps
)

_P = TypeVar("_P", bound=DatatypeProps, covariant=True)


@dataclass
class DatatypeDef(Generic[_P]):
    """
    Corresponds to ReqIF's DatatypeDefinition (10.8.21). When combined with
    ``DatatypeProps``, it covers all its subtypes.
    """

    id: str
    props: _P
    name: str = ""  # long_name per spec; falls back to id if not provided
    description: str | None = None
    last_change: str | None = None

    def __post_init__(self) -> None:
        if not self.name:
            self.name = self.id

    @property
    def kind(self) -> AttrType:
        return self.props.TYPE


# ---------------------------------------------------------------------------
# Attribute definitions
# ---------------------------------------------------------------------------


@dataclass
class StringAttrDef:
    """
    Corresponds to ReqIF's AttributeDefinitionString (10.8.10).
    """

    datatype_def: DatatypeDef[StrProps]
    default_value: str | None = None


@dataclass
class IntAttrDef:
    """
    Corresponds to ReqIF's AttributeDefinitionInteger (10.8.7).
    """

    datatype_def: DatatypeDef[IntProps]
    default_value: int | None = None


@dataclass
class RealAttrDef:
    """
    Corresponds to ReqIF's AttributeDefinitionReal (10.8.8).
    """

    datatype_def: DatatypeDef[RealProps]
    default_value: float | None = None


@dataclass
class BoolAttrDef:
    """
    Corresponds to ReqIF's AttributeDefinitionBoolean (10.8.4).
    """

    datatype_def: DatatypeDef[BoolProps]
    default_value: bool | None = None


@dataclass
class DateAttrDef:
    """
    Corresponds to ReqIF's AttributeDefinitionDate (10.8.5).
    """

    datatype_def: DatatypeDef[DateProps]
    default_value: str | None = None  # ISO date string


@dataclass
class XhtmlAttrDef:
    """
    Corresponds to ReqIF's AttributeDefinitionXhtml (10.8.11).
    """

    datatype_def: DatatypeDef[XhtmlProps]
    default_value: str | None = None


@dataclass
class EnumAttrDef:
    """
    Corresponds to ReqIF's AttributeDefinitionEnumeration (10.8.6).
    """

    datatype_def: DatatypeDef[EnumProps]
    multi_valued: bool = False  # True maps to [0..*] in SysMLv2
    default_value: EnumValue | None = None


AttributeDefProps = (
    StringAttrDef
    | IntAttrDef
    | RealAttrDef
    | BoolAttrDef
    | DateAttrDef
    | XhtmlAttrDef
    | EnumAttrDef
)


_AD = TypeVar("_AD", bound=AttributeDefProps, covariant=True)


@dataclass
class AttributeDef(Generic[_AD]):
    """
    Corresponds to ReqIF's AttributeDefinition (10.8.3). When combined with
    ``AttributeDefProps``, it covers all its subtypes.

    This maps to ``attribute`` under the various SpecTypes in SysMLv2. Has the ``@reqif`` tag
    to preserve UUIDs for round-tripping.
    """

    id: str
    name: str  # long_name mandatory for all AttributeDefs according to ReqIF spec
    props: _AD
    description: str | None = None
    last_change: str | None = None
    is_editable: bool = True

    @property
    def kind(self) -> AttrType:
        return self.props.datatype_def.props.TYPE


# ---------------------------------------------------------------------------
# Attribute values
# ---------------------------------------------------------------------------
#
# One dataclass per ReqIF AttributeValue subtype (10.8.12). The ``TYPE``
# ClassVar mirrors the pattern used by *Props and *AttrDef and lets call sites
# dispatch with isinstance() instead of a discriminator field.
#
# Each subclass parameterises its ``attr_def_ref`` with the matching *AttrDef so
# type checkers catch mismatches like ``StringAttrValue(attr_def_ref=int_def)``.


@dataclass
class StringAttrValue:
    TYPE: ClassVar[AttrType] = AttrType.STRING
    attr_def_ref: AttributeDef[StringAttrDef]
    value: str | None = None


@dataclass
class IntAttrValue:
    TYPE: ClassVar[AttrType] = AttrType.INTEGER
    attr_def_ref: AttributeDef[IntAttrDef]
    value: int | None = None


@dataclass
class RealAttrValue:
    TYPE: ClassVar[AttrType] = AttrType.REAL
    attr_def_ref: AttributeDef[RealAttrDef]
    value: float | None = None


@dataclass
class BoolAttrValue:
    TYPE: ClassVar[AttrType] = AttrType.BOOLEAN
    attr_def_ref: AttributeDef[BoolAttrDef]
    value: bool | None = None


@dataclass
class DateAttrValue:
    TYPE: ClassVar[AttrType] = AttrType.DATE
    attr_def_ref: AttributeDef[DateAttrDef]
    value: str | None = None  # ISO date string


@dataclass
class XhtmlAttrValue:
    TYPE: ClassVar[AttrType] = AttrType.XHTML
    attr_def_ref: AttributeDef[XhtmlAttrDef]
    value: str | None = None  # markdown form


@dataclass
class EnumAttrValue:
    TYPE: ClassVar[AttrType] = AttrType.ENUMERATION
    attr_def_ref: AttributeDef[EnumAttrDef]
    value: list[EnumValue] = field(default_factory=list)


AttributeValue = (
    StringAttrValue
    | IntAttrValue
    | RealAttrValue
    | BoolAttrValue
    | DateAttrValue
    | XhtmlAttrValue
    | EnumAttrValue
)


# ---------------------------------------------------------------------------
# Spec types and objects
# ---------------------------------------------------------------------------


class SpecKind(StrEnum):
    """
    Discriminates the four ReqIF SpecType subtypes.
    """

    OBJECT = "object"
    SPECIFICATION = "specification"
    RELATION = "relation"
    RELATION_GROUP = "relation_group"


_SK = TypeVar("_SK", bound=SpecKind, covariant=True)


@dataclass
class SpecType(Generic[_SK]):
    """
    Corresponds to ReqIF's SpecType (10.8.44), which in turn is the common base for
    SpecObjectType (10.8.41), SpecificationType (10.8.39), SpecRelationType (10.8.43),
    and RelationGroupType (10.8.34).

    - SpecObjectType maps to SysMLv2's ``#reqif_spec_object_type abstract requirement def``.
    - SpecificationType maps to SysMLv2's ``#reqif_specification_type abstract requirement def``.
    - SpecRelationType maps to SysMLv2's ``#reqif_spec_relation_type connection def``.
    - RelationGroupType maps to SysMLv2's ``#reqif_relation_group_type occurrence def``.

    The ``_SK`` type parameter narrows ``kind`` to a specific ``SpecKind`` member
    so that references like ``SpecObject.type_ref: SpecObjectType`` are statically
    checked.
    """

    id: str
    kind: _SK
    name: str = ""  # long_name per spec; falls back to id if not provided
    attribute_defs: dict[str, AttributeDef[AttributeDefProps]] = field(
        default_factory=dict
    )
    description: str | None = None
    last_change: str | None = None

    def __post_init__(self) -> None:
        if not self.name:
            self.name = self.id


SpecObjectType = SpecType[Literal[SpecKind.OBJECT]]
SpecificationType = SpecType[Literal[SpecKind.SPECIFICATION]]
SpecRelationType = SpecType[Literal[SpecKind.RELATION]]
RelationGroupType = SpecType[Literal[SpecKind.RELATION_GROUP]]


@overload
def kind_of[T: AttributeDefProps](
    self: AttributeDef[Any], props_type: type[T]
) -> TypeGuard[AttributeDef[T]]: ...


@overload
def kind_of[T: DatatypeProps](
    self: DatatypeDef[Any], props_type: type[T]
) -> TypeGuard[DatatypeDef[T]]: ...


@overload
def kind_of(
    self: SpecType[Any], props_type: Literal[SpecKind.OBJECT]
) -> TypeGuard[SpecObjectType]: ...


@overload
def kind_of(
    self: SpecType[Any], props_type: Literal[SpecKind.SPECIFICATION]
) -> TypeGuard[SpecificationType]: ...


@overload
def kind_of(
    self: SpecType[Any], props_type: Literal[SpecKind.RELATION]
) -> TypeGuard[SpecRelationType]: ...


@overload
def kind_of(
    self: SpecType[Any], props_type: Literal[SpecKind.RELATION_GROUP]
) -> TypeGuard[RelationGroupType]: ...


def kind_of(
    self: AttributeDef[Any] | DatatypeDef[Any] | SpecType[Any], props_type: Any
) -> bool:
    if isinstance(self, SpecType):
        return cast(bool, self.kind == props_type)
    return isinstance(self.props, props_type)


@dataclass
class SpecObject:
    """
    Corresponds to ReqIF's SpecObject (10.8.40).

    Maps to SysMLv2's ``requirement def`` that specialises a ``#reqif_spec_object_type abstract requirement def``.
    Has a ``@reqif`` tag inside.
    """

    id: str
    name: str  # ReqIF.Name attribute >> long_name >> id
    type_ref: SpecObjectType
    attributes: dict[str, AttributeValue] = field(default_factory=dict)
    description: str | None = None
    last_change: str | None = None


@dataclass
class SpecRelation:
    """
    Corresponds to ReqIF's SpecRelation (10.8.42).

    Maps to SysMLv2's ``connection`` with ``@reqif`` tag inside.
    """

    id: str
    name: str  # ReqIF.Name attribute >> long_name >> id
    source_ref: SpecObject
    target_ref: SpecObject
    type_ref: SpecRelationType
    attributes: dict[str, AttributeValue] = field(default_factory=dict)
    description: str | None = None
    last_change: str | None = None


@dataclass
class RelationGroup:
    """
    Corresponds to ReqIF's RelationGroup (10.8.33)

    Maps to SysMLv2's ``occurrence def`` that specialises a ``#reqif_relation_group_type abstract occurrence def``.
    Has a ``@reqif`` tag inside.
    """

    id: str
    name: str  # ReqIF.Name attribute >> long_name >> id (long_name mandatory)
    source_ref: Specification
    target_ref: Specification
    type_ref: RelationGroupType
    relations: dict[str, SpecRelation] = field(default_factory=dict)
    attributes: dict[str, AttributeValue] = field(default_factory=dict)
    description: str | None = None
    last_change: str | None = None


@dataclass
class SpecHierarchyNode:
    """
    Corresponds to ReqIF's SpecHierarchy (10.8.37).
    ReqIF assigns UUIDs to hierarchy nodes as well.

    Maps to SysMLv2's ``requirement`` usages inside of ``requirement def``.
    """

    id: str
    spec_object_ref: SpecObject
    children: dict[str, SpecHierarchyNode] = field(default_factory=dict)
    name: str | None = None  # long_name
    description: str | None = None
    # TODO https://gitlab.com/sensmetry/internal2/tech/syside/syside-python/-/work_items/33: add editableAtts (list off attributes that can be edited). Not sure how to represent this in SysMLv2, list of references?
    # TODO https://gitlab.com/sensmetry/internal2/tech/syside/syside-python/-/work_items/33: figure out what `isTableInternal` means and how to handle it
    last_change: str | None = None
    is_editable: bool = False


@dataclass
class Specification:
    """
    Corresponds to ReqIF's Specification (10.8.38).

    Maps to SysMLv2's ``requirement def`` that specialises a ``#reqif_specification_type abstract requirement def``.
    Has ``@reqif`` tag inside.
    """

    id: str
    name: str  # ReqIF.Name attribute >> long_name >> id
    type_ref: SpecificationType
    children: dict[str, SpecHierarchyNode] = field(default_factory=dict)
    attributes: dict[str, AttributeValue] = field(default_factory=dict)
    description: str | None = None
    last_change: str | None = None


# ---------------------------------------------------------------------------
# Top-level model
# ---------------------------------------------------------------------------


@dataclass
class Model:
    datatype_defs: dict[str, DatatypeDef[DatatypeProps]] = field(default_factory=dict)
    spec_types: dict[str, SpecType[SpecKind]] = field(default_factory=dict)
    spec_objects: dict[str, SpecObject] = field(default_factory=dict)
    specifications: dict[str, Specification] = field(default_factory=dict)
    spec_relations: dict[str, SpecRelation] = field(default_factory=dict)
    relation_groups: dict[str, RelationGroup] = field(default_factory=dict)

    def is_empty(self) -> bool:
        return not any(
            (
                self.datatype_defs,
                self.spec_types,
                self.spec_objects,
                self.specifications,
                self.spec_relations,
                self.relation_groups,
            )
        )


# ---------------------------------------------------------------------------
# IR diff / delta report
# ---------------------------------------------------------------------------


@dataclass
class FieldChange:
    """
    A single field-level change between two versions of an element.

    For additions of sub-elements: ``old=None``, ``new`` holds the added value.
    For removals of sub-elements: ``new=None``, ``old`` holds the removed value.
    For field mutations: both ``old`` and ``new`` hold the before/after values.
    """

    field: str
    old: object | None
    new: object | None


@dataclass
class ElementDelta:
    id: str
    name: str
    status: Literal["added", "changed", "unchanged"]
    changes: list[FieldChange] = field(default_factory=list)


OrphanKind = Literal[
    "datatype_def",
    "spec_type",
    "spec_object",
    "specification",
    "spec_relation",
    "relation_group",
]


@dataclass
class OrphanedElement:
    id: str
    name: str
    kind: OrphanKind


def _format_field_change(c: FieldChange) -> str:
    if c.old is None:
        return f"added {c.field}"
    if c.new is None:
        return f"removed {c.field}"
    return f"{c.field}: {c.old!r} → {c.new!r}"


@dataclass
class DeltaReport:
    datatype_defs: dict[str, ElementDelta] = field(default_factory=dict)
    spec_types: dict[str, ElementDelta] = field(default_factory=dict)
    spec_objects: dict[str, ElementDelta] = field(default_factory=dict)
    specifications: dict[str, ElementDelta] = field(default_factory=dict)
    spec_relations: dict[str, ElementDelta] = field(default_factory=dict)
    relation_groups: dict[str, ElementDelta] = field(default_factory=dict)
    orphaned: list[OrphanedElement] = field(default_factory=list)

    @property
    def has_changes(self) -> bool:
        for deltas in (
            self.datatype_defs,
            self.spec_types,
            self.spec_objects,
            self.specifications,
            self.spec_relations,
            self.relation_groups,
        ):
            for d in deltas.values():
                if d.status != "unchanged":
                    return True
        if self.orphaned:
            return True
        return False

    def summary(self) -> str:
        lines: list[str] = []
        for section, deltas in [
            ("Datatype defs", self.datatype_defs),
            ("Spec types", self.spec_types),
            ("Spec objects", self.spec_objects),
            ("Specifications", self.specifications),
            ("Spec relations", self.spec_relations),
            ("Relation groups", self.relation_groups),
        ]:
            added = [d for d in deltas.values() if d.status == "added"]
            changed = [d for d in deltas.values() if d.status == "changed"]
            unchanged = [d for d in deltas.values() if d.status == "unchanged"]
            if added or changed:
                lines.append(
                    f"{section}: {len(added)} added, {len(changed)} changed, "
                    f"{len(unchanged)} unchanged"
                )
                for d in changed:
                    lines.append(f'  changed: "{d.name}" ({d.id})')
                    for c in d.changes:
                        lines.append(f"    - {_format_field_change(c)}")
        if self.orphaned:
            lines.append(f"Orphaned: {len(self.orphaned)} element(s)")
            for o in self.orphaned:
                lines.append(f'  - {o.kind} "{o.name}" ({o.id})')
        if not lines:
            lines.append("No changes detected.")
        return "\n".join(lines)


def diff_ir_models(existing: Model, incoming: Model) -> DeltaReport:
    """Compare two Models and produce a DeltaReport."""
    report = DeltaReport()

    _diff_collection(
        existing.datatype_defs,
        incoming.datatype_defs,
        "datatype_def",
        report.datatype_defs,
        report.orphaned,
        _diff_datatype_def_element,
    )
    _diff_collection(
        existing.spec_types,
        incoming.spec_types,
        "spec_type",
        report.spec_types,
        report.orphaned,
        _diff_spec_type,
    )
    _diff_collection(
        existing.spec_objects,
        incoming.spec_objects,
        "spec_object",
        report.spec_objects,
        report.orphaned,
        _diff_spec_object,
    )
    _diff_collection(
        existing.specifications,
        incoming.specifications,
        "specification",
        report.specifications,
        report.orphaned,
        _diff_specification,
    )
    _diff_collection(
        existing.spec_relations,
        incoming.spec_relations,
        "spec_relation",
        report.spec_relations,
        report.orphaned,
        _diff_spec_relation,
    )
    _diff_collection(
        existing.relation_groups,
        incoming.relation_groups,
        "relation_group",
        report.relation_groups,
        report.orphaned,
        _diff_relation_group,
    )

    return report


def _diff_collection(
    existing: dict[str, _T],
    incoming: dict[str, _T],
    kind: OrphanKind,
    deltas: dict[str, ElementDelta],
    orphaned: list[OrphanedElement],
    diff_fn: Callable[[_T, _T], ElementDelta],
) -> None:
    for elem_id, incoming_elem in incoming.items():
        existing_elem = existing.get(elem_id)
        if existing_elem is None:
            deltas[elem_id] = ElementDelta(
                id=elem_id, name=incoming_elem.name, status="added"
            )
        else:
            deltas[elem_id] = diff_fn(existing_elem, incoming_elem)

    for elem_id, existing_elem in existing.items():
        if elem_id not in incoming:
            orphaned.append(
                OrphanedElement(id=elem_id, name=existing_elem.name, kind=kind)
            )


def _make_delta(
    existing: _HasIdName, incoming: _HasIdName, changes: list[FieldChange]
) -> ElementDelta:
    status: Literal["added", "changed", "unchanged"] = (
        "changed" if changes else "unchanged"
    )
    return ElementDelta(
        id=existing.id, name=incoming.name, status=status, changes=changes
    )


def _check_fields(
    existing: object,
    incoming: object,
    fields: tuple[str, ...],
    changes: list[FieldChange],
    prefix: str = "",
) -> None:
    """Append a FieldChange for each field where existing != incoming."""
    for fname in fields:
        ev = getattr(existing, fname)
        iv = getattr(incoming, fname)
        if ev != iv:
            changes.append(
                FieldChange(
                    field=f"{prefix}.{fname}" if prefix else fname, old=ev, new=iv
                )
            )


def _check_ref(
    existing: _HasIdName,
    incoming: _HasIdName,
    field_name: str,
    changes: list[FieldChange],
    prefix: str = "",
) -> None:
    """
    Append a FieldChange when two cross-element references point to elements
    with different ids.

    Use this — not :func:`_check_fields` — for any field whose value is a
    reference to another top-level IR element (``type_ref``, ``source_ref``,
    ``target_ref``, ``spec_object_ref``, ``datatype_def``). Comparing those
    by ``==`` would recurse into the referenced subtree, so a single change
    deep in the graph (e.g. a ``DatatypeDef.name`` edit) would cascade into
    every element that transitively references it. The referenced element
    is independently diffed in its own collection, so it suffices to detect
    when *which* element is referenced changes.
    """
    if existing.id != incoming.id:
        full_field = f"{prefix}.{field_name}" if prefix else field_name
        changes.append(FieldChange(field=full_field, old=existing.id, new=incoming.id))


def _diff_datatype_def_element(
    existing: DatatypeDef[DatatypeProps], incoming: DatatypeDef[DatatypeProps]
) -> ElementDelta:
    changes: list[FieldChange] = []
    _check_fields(existing, incoming, ("name", "description", "last_change"), changes)
    if existing.kind != incoming.kind:
        changes.append(FieldChange(field="kind", old=existing.kind, new=incoming.kind))
    elif kind_of(existing, StrProps):
        assert kind_of(incoming, StrProps)
        _check_fields(existing.props, incoming.props, ("max_length",), changes)
    elif kind_of(existing, IntProps):
        assert kind_of(incoming, IntProps)
        _check_fields(existing.props, incoming.props, ("min", "max"), changes)
    elif kind_of(existing, RealProps):
        assert kind_of(incoming, RealProps)
        _check_fields(
            existing.props, incoming.props, ("min", "max", "accuracy"), changes
        )
    elif kind_of(existing, EnumProps):
        assert kind_of(incoming, EnumProps)
        _diff_enum_values(existing.props.values, incoming.props.values, changes)
    return _make_delta(existing, incoming, changes)


def _diff_enum_values(
    existing_vals: dict[str, EnumValue],
    incoming_vals: dict[str, EnumValue],
    changes: list[FieldChange],
    prefix: str = "",
) -> None:
    for value_id, incoming_val in incoming_vals.items():
        field = (
            f"{prefix}.enum_value[{value_id}]" if prefix else f"enum_value[{value_id}]"
        )
        existing_val = existing_vals.get(value_id)
        if existing_val is None:
            changes.append(FieldChange(field=field, old=None, new=incoming_val.name))
        elif existing_val != incoming_val:
            changes.extend(_diff_enum_value(existing_val, incoming_val, prefix))
    for value_id, existing_val in existing_vals.items():
        if value_id not in incoming_vals:
            field = (
                f"{prefix}.enum_value[{value_id}]"
                if prefix
                else f"enum_value[{value_id}]"
            )
            changes.append(FieldChange(field=field, old=existing_val.name, new=None))


def _diff_enum_value(
    existing: EnumValue, incoming: EnumValue, prefix: str = ""
) -> list[FieldChange]:
    changes: list[FieldChange] = []
    value_prefix = (
        f"{prefix}.enum_value[{existing.id}]"
        if prefix
        else f"enum_value[{existing.id}]"
    )
    _check_fields(
        existing,
        incoming,
        ("name", "key", "description", "other_content", "last_change"),
        changes,
        prefix=value_prefix,
    )
    return changes


def _diff_spec_type(
    existing: SpecType[SpecKind], incoming: SpecType[SpecKind]
) -> ElementDelta:
    changes: list[FieldChange] = []
    _check_fields(
        existing, incoming, ("name", "kind", "description", "last_change"), changes
    )
    _diff_attribute_defs(existing.attribute_defs, incoming.attribute_defs, changes)
    return _make_delta(existing, incoming, changes)


def _diff_attribute_defs(
    existing: dict[str, AttributeDef[AttributeDefProps]],
    incoming: dict[str, AttributeDef[AttributeDefProps]],
    changes: list[FieldChange],
) -> None:
    for attr_id, incoming_def in incoming.items():
        existing_def = existing.get(attr_id)
        if existing_def is None:
            changes.append(
                FieldChange(
                    field=f"attribute_def[{attr_id}]", old=None, new=incoming_def.name
                )
            )
            continue
        prefix = f"attribute_def[{attr_id}]"
        _check_fields(
            existing_def,
            incoming_def,
            ("name", "description", "last_change", "is_editable"),
            changes,
            prefix=prefix,
        )
        if existing_def.kind != incoming_def.kind:
            changes.append(
                FieldChange(
                    field=f"{prefix}.kind",
                    old=existing_def.kind,
                    new=incoming_def.kind,
                )
            )
        else:
            props_fields: tuple[str, ...] = ("default_value",)
            if kind_of(existing_def, EnumAttrDef):
                props_fields = ("multi_valued", "default_value")
            _check_fields(
                existing_def.props,
                incoming_def.props,
                props_fields,
                changes,
                prefix=prefix,
            )
            # Compare the datatype reference by id only. The datatype's own
            # contents are diffed in ``report.datatype_defs``; recursing here
            # would cascade a single ``DatatypeDef`` edit into every AttrDef
            # that references it.
            _check_ref(
                existing_def.props.datatype_def,
                incoming_def.props.datatype_def,
                "datatype_def",
                changes,
                prefix=prefix,
            )
    for attr_id, existing_def in existing.items():
        if attr_id not in incoming:
            changes.append(
                FieldChange(
                    field=f"attribute_def[{attr_id}]", old=existing_def.name, new=None
                )
            )


def _diff_attribute_values(
    existing_by_ref: dict[str, AttributeValue],
    incoming_by_ref: dict[str, AttributeValue],
    field_prefix: str,
    changes: list[FieldChange],
) -> None:
    for ref_id, incoming_val in incoming_by_ref.items():
        existing_val = existing_by_ref.get(ref_id)
        if existing_val is None:
            changes.append(
                FieldChange(
                    field=f"{field_prefix}[{ref_id}]", old=None, new=incoming_val.value
                )
            )
        # Compare ``.value`` directly rather than the whole AttributeValue:
        # the latter would recurse into ``attr_def_ref`` and report a
        # spurious value change whenever the AttrDef itself was edited
        # elsewhere.
        elif existing_val.value != incoming_val.value:
            changes.append(
                FieldChange(
                    field=f"{field_prefix}[{ref_id}].value",
                    old=existing_val.value,
                    new=incoming_val.value,
                )
            )
    for ref_id, existing_val in existing_by_ref.items():
        if ref_id not in incoming_by_ref:
            changes.append(
                FieldChange(
                    field=f"{field_prefix}[{ref_id}]", old=existing_val.value, new=None
                )
            )


def _diff_spec_object(existing: SpecObject, incoming: SpecObject) -> ElementDelta:
    changes: list[FieldChange] = []
    _check_fields(existing, incoming, ("name", "last_change", "description"), changes)
    _check_ref(existing.type_ref, incoming.type_ref, "type_ref", changes)
    _diff_attribute_values(
        existing.attributes, incoming.attributes, "attribute_value", changes
    )
    return _make_delta(existing, incoming, changes)


def _diff_specification(
    existing: Specification, incoming: Specification
) -> ElementDelta:
    changes: list[FieldChange] = []
    _check_fields(existing, incoming, ("name", "last_change", "description"), changes)
    _check_ref(existing.type_ref, incoming.type_ref, "type_ref", changes)
    _diff_attribute_values(
        existing.attributes, incoming.attributes, "spec_attribute", changes
    )
    _diff_hierarchy(existing.children, incoming.children, changes)
    return _make_delta(existing, incoming, changes)


def _diff_hierarchy(
    existing: dict[str, SpecHierarchyNode],
    incoming: dict[str, SpecHierarchyNode],
    changes: list[FieldChange],
) -> None:
    for node_id, incoming_node in incoming.items():
        existing_node = existing.get(node_id)
        if existing_node is None:
            changes.append(
                FieldChange(field=f"hierarchy_node[{node_id}]", old=None, new=node_id)
            )
        else:
            prefix = f"hierarchy_node[{node_id}]"
            _check_fields(
                existing_node,
                incoming_node,
                ("last_change", "is_editable", "name", "description"),
                changes,
                prefix=prefix,
            )
            _check_ref(
                existing_node.spec_object_ref,
                incoming_node.spec_object_ref,
                "spec_object_ref",
                changes,
                prefix=prefix,
            )
            _diff_hierarchy(existing_node.children, incoming_node.children, changes)
    for node_id in existing:
        if node_id not in incoming:
            changes.append(
                FieldChange(field=f"hierarchy_node[{node_id}]", old=node_id, new=None)
            )

    existing_order = list(existing.keys())
    incoming_order = list(incoming.keys())
    if existing_order != incoming_order and set(existing_order) == set(incoming_order):
        changes.append(
            FieldChange(
                field="hierarchy_node_ordering", old=existing_order, new=incoming_order
            )
        )


def _diff_spec_relation(existing: SpecRelation, incoming: SpecRelation) -> ElementDelta:
    changes: list[FieldChange] = []
    _check_fields(existing, incoming, ("name", "last_change", "description"), changes)
    _check_ref(existing.source_ref, incoming.source_ref, "source_ref", changes)
    _check_ref(existing.target_ref, incoming.target_ref, "target_ref", changes)
    _check_ref(existing.type_ref, incoming.type_ref, "type_ref", changes)
    return _make_delta(existing, incoming, changes)


def _diff_relation_group(
    existing: RelationGroup, incoming: RelationGroup
) -> ElementDelta:
    changes: list[FieldChange] = []
    _check_fields(existing, incoming, ("name", "last_change", "description"), changes)
    _check_ref(existing.source_ref, incoming.source_ref, "source_ref", changes)
    _check_ref(existing.target_ref, incoming.target_ref, "target_ref", changes)
    _check_ref(existing.type_ref, incoming.type_ref, "type_ref", changes)
    _diff_relation_membership(existing.relations, incoming.relations, changes)
    _diff_attribute_values(
        existing.attributes, incoming.attributes, "attribute_value", changes
    )
    return _make_delta(existing, incoming, changes)


def _diff_relation_membership(
    existing: dict[str, SpecRelation],
    incoming: dict[str, SpecRelation],
    changes: list[FieldChange],
) -> None:
    for rel_id, incoming_rel in incoming.items():
        if rel_id not in existing:
            changes.append(
                FieldChange(
                    field=f"relation[{rel_id}]", old=None, new=incoming_rel.name
                )
            )
    for rel_id, existing_rel in existing.items():
        if rel_id not in incoming:
            changes.append(
                FieldChange(
                    field=f"relation[{rel_id}]", old=existing_rel.name, new=None
                )
            )
