from collections.abc import Iterable, Generator
import itertools
import syside
import typing
from syside.reqif import _ir_model as ir
from syside.reqif._sysml_utils import indicate_problem_at
from syside.reqif._sysml_metadata import (
    load_sysml_metadata_defs,
    SysMLMetadataTagDefs,
    SysMLMetadataPrefixDefs,
    MetaReqIFTag,
    MetaReqIFDatatypeTag,
    MetaReqIFIntegerTag,
    MetaReqIFRealTag,
    MetaReqIFStringTag,
    MetaReqIFEnumValueTag,
)
from functools import cache


def _metadata_about(usage: syside.MetadataUsage) -> list[syside.Element]:
    if usage.about.elements.empty():
        if usage.owner is None:
            raise ValueError(indicate_problem_at(usage, "Orphaned metadata usage"))
        return [usage.owner]
    else:
        return list(usage.about.elements)


def _metadata_doc_description(
    usage: syside.MetadataUsage,
) -> syside.Documentation | None:
    result: syside.Documentation | None = None

    def visit(doc: syside.Documentation) -> bool:
        nonlocal result
        if doc.name is None:
            result = doc
            return False
        return True

    for elt in _metadata_about(usage):
        elt.documentation.for_each(visit)
        if result is not None:
            break

    return result


## NOTE: Best effort for now
def _feature_multivalued(
    usage: syside.Feature, c: syside.Compiler, stdlib: syside.Stdlib
) -> bool:
    if isinstance(usage.multiplicity, syside.MultiplicityRange):
        ub = usage.multiplicity.upper_bound
        if ub is not None:
            ub_val, _ = c.evaluate(ub, scope=usage, stdlib=stdlib)
            if isinstance(ub_val, int):
                return ub_val > 1
            elif isinstance(ub_val, syside.Infinity):
                return True
            else:
                raise ValueError(
                    indicate_problem_at(
                        usage, f"Unexpected multiplicity upper bound {ub_val}"
                    )
                )
        else:
            return False
    else:
        return False


def _metadata_usages(
    m: syside.Model, defs: Iterable[syside.MetadataDefinition]
) -> dict[syside.MetadataDefinition, list[syside.MetadataUsage]]:
    """
    Simultaneously find all (transitive) metadata typings of a collection of metadata usages.
    """

    @cache
    def _metadata_def_ancestors(
        def_: syside.MetadataDefinition,
    ) -> frozenset[syside.MetadataDefinition]:
        ## TODO: Compare by reference
        if tuple(def_.qualified_name or ()) == ("Metadata", "MetadataItem"):
            return frozenset()

        result: set[syside.MetadataDefinition] = set()

        for parent in def_.heritage.elements:
            if isinstance(parent, syside.MetadataDefinition.STD):
                result.update(_metadata_def_ancestors(parent))
            elif isinstance(parent, syside.Metaclass.STD):
                ## TODO: Double check that these are always safe to ignore
                continue
            else:
                if def_.qualified_name is not None:
                    opening = f"Metadata definition {def_.qualified_name}"
                else:
                    opening = "Anonymous metadata definition"

                if parent.qualified_name is not None:
                    closing = f"{parent.qualified_name} of type {type(parent).__name__}"
                else:
                    closing = f"of type {type(parent).__name__}"

                raise ValueError(
                    indicate_problem_at(
                        def_, f"{opening} has non-metadata parent {closing}"
                    )
                )

        return frozenset(result)

    @cache
    def _metadata_usage_defs(
        usage: syside.MetadataUsage,
    ) -> frozenset[syside.MetadataDefinition]:
        result: set[syside.MetadataDefinition] = set()

        for parent in usage.heritage.elements:
            if isinstance(parent, syside.MetadataUsage.STD):
                result.update(_metadata_usage_defs(parent))
            elif isinstance(parent, syside.MetadataDefinition.STD):
                result.add(parent)
                result.update(_metadata_def_ancestors(parent))
            ## TODO: Compare by reference
            elif tuple(parent.qualified_name or ()) == ("Metadata", "metadataItems"):
                continue
            else:
                if usage.qualified_name is not None:
                    opening = f"Metadata usage {usage.qualified_name}"
                else:
                    opening = "Anonymous metadata usage"

                if parent.qualified_name is not None:
                    closing = f"{parent.qualified_name} of type {type(parent).__name__}"
                else:
                    closing = f"of type {type(parent).__name__}"

                raise ValueError(
                    indicate_problem_at(
                        usage, f"{opening} has non-metadata parent {closing}"
                    )
                )

        return frozenset(result)

    def_usages: dict[syside.MetadataDefinition, list[syside.MetadataUsage]] = {
        def_: [] for def_ in defs
    }

    for usage in m.nodes(syside.MetadataUsage, True):
        for def_ in _metadata_usage_defs(usage):
            if def_ in def_usages:
                def_usages[def_].append(usage)

    return def_usages


def _reqif_metadata_usages(
    m: syside.Model,
    tag_defs: SysMLMetadataTagDefs,
    prefix_defs: SysMLMetadataPrefixDefs,
) -> dict[syside.MetadataDefinition, list[syside.MetadataUsage]]:
    return _metadata_usages(
        m,
        [
            tag_defs.reqif_tag.metadata_elem,
            tag_defs.reqif_integer_tag.metadata_elem,
            tag_defs.reqif_real_tag.metadata_elem,
            tag_defs.reqif_string_tag.metadata_elem,
            tag_defs.reqif_xhtml_tag.metadata_elem,
            tag_defs.reqif_boolean_tag.metadata_elem,
            tag_defs.reqif_date_tag.metadata_elem,
            tag_defs.reqif_enum_value_tag.metadata_elem,
            #
            prefix_defs.reqif_spec_object_type_prefix,
            prefix_defs.reqif_spec_relation_type_prefix,
            prefix_defs.reqif_specification_type_prefix,
            prefix_defs.reqif_relation_group_type_prefix,
        ],
    )


def _eval_optional_expected[T](
    t: type[T],
    feature: syside.Feature,
    scope: syside.Type,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> T | None:
    v, _ = c.evaluate_feature(feature, scope=scope, stdlib=stdlib)

    while isinstance(v, syside.Feature):
        w, _ = c.evaluate_feature(v, scope=scope, stdlib=stdlib)
        if w == v:
            return None
        else:
            v = w

    if v is None:
        return None

    if isinstance(v, t):
        return v

    if t is float and isinstance(v, int):
        return float(v)  # type: ignore

    raise ValueError(
        indicate_problem_at(
            feature,
            f"feature evaluates to unexpected type {type(v).__name__}, expected {t.__name__}",
        )
    )


def _ensure_is[T](t: type[T], v: typing.Any) -> T:
    if not isinstance(v, t):
        raise ValueError(f"expected get {t.__name__}, got {type(v).__name__}")
    return v


def _eval_optional_resolve_to[T](
    t: type[T],
    ops: Iterable[T],
    feature: syside.Feature,
    scope: syside.Type,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> list[T] | None:
    targets = frozenset(ops)

    v: syside.Value = feature

    while v not in targets:
        v = _ensure_is(syside.Feature, v)

        w, _ = c.evaluate_feature(v, scope=scope, stdlib=stdlib)
        if w == v:
            return None

        v = w

        if isinstance(v, list):
            return [
                result
                for v_alt in v
                for result in _eval_optional_resolve_to(
                    t,
                    ops,
                    _ensure_is(syside.Feature, v_alt),
                    scope,
                    c,
                    stdlib,
                )
                or []
                if result is not None
            ] or None

    if not isinstance(v, list):
        assert isinstance(v, syside.Element)
        v = [v]

    return [_ensure_is(t, x) for x in v]


def _extract_reqif_generic[T: ir.DatatypeProps](
    props: T,
    usage: syside.MetadataUsage,
    reqif_tag: MetaReqIFTag | MetaReqIFDatatypeTag,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> ir.DatatypeDef[T]:
    id_ = _eval_optional_expected(str, reqif_tag.identifier_field, usage, c, stdlib)

    if id_ is None:
        raise ValueError(
            indicate_problem_at(usage, "reqif metadata is missing identifier")
        )

    result = ir.DatatypeDef(
        id=id_,
        props=props,
    )

    if (
        last_change_val := _eval_optional_expected(
            t=str, feature=reqif_tag.last_change_field, scope=usage, c=c, stdlib=stdlib
        )
    ) is not None:
        result.last_change = last_change_val

    match reqif_tag:
        case MetaReqIFDatatypeTag():
            if (
                long_name_val := _eval_optional_expected(
                    t=str,
                    feature=reqif_tag.long_name_field,
                    scope=usage,
                    c=c,
                    stdlib=stdlib,
                )
            ) is not None:
                result.name = long_name_val

            if (
                description_val := _eval_optional_expected(
                    t=str,
                    feature=reqif_tag.desc_field,
                    scope=usage,
                    c=c,
                    stdlib=stdlib,
                )
            ) is not None:
                result.description = description_val

        case MetaReqIFTag():
            name = _metadata_name_from_element(usage)
            if name is None:
                raise ValueError(
                    indicate_problem_at(usage, "reqif annotated element is anonymous")
                )

            result.name = name

            if (description_doc := _metadata_doc_description(usage)) is not None:
                result.description = description_doc.body

    return result


def _extract_reqif_integer(
    usage: syside.MetadataUsage,
    reqif_integer_tag: MetaReqIFIntegerTag,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> ir.DatatypeDef[ir.IntProps]:
    props = ir.IntProps()

    if (
        min_val := _eval_optional_expected(
            t=int, feature=reqif_integer_tag.min_field, scope=usage, c=c, stdlib=stdlib
        )
    ) is not None:
        props.min = min_val

    if (
        max_val := _eval_optional_expected(
            t=int, feature=reqif_integer_tag.max_field, scope=usage, c=c, stdlib=stdlib
        )
    ) is not None:
        props.max = max_val

    return _extract_reqif_generic(props, usage, reqif_integer_tag, c, stdlib)


def _extract_reqif_real(
    usage: syside.MetadataUsage,
    reqif_real_tag: MetaReqIFRealTag,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> ir.DatatypeDef[ir.RealProps]:
    props = ir.RealProps()

    if (
        min_val := _eval_optional_expected(
            t=float, feature=reqif_real_tag.min_field, scope=usage, c=c, stdlib=stdlib
        )
    ) is not None:
        props.min = min_val

    if (
        max_val := _eval_optional_expected(
            t=float, feature=reqif_real_tag.max_field, scope=usage, c=c, stdlib=stdlib
        )
    ) is not None:
        props.max = max_val

    if (
        accuracy_val := _eval_optional_expected(
            t=int,
            feature=reqif_real_tag.accuracy_field,
            scope=usage,
            c=c,
            stdlib=stdlib,
        )
    ) is not None:
        props.accuracy = accuracy_val

    return _extract_reqif_generic(props, usage, reqif_real_tag, c, stdlib)


def _extract_reqif_string(
    usage: syside.MetadataUsage,
    reqif_string_tag: MetaReqIFStringTag,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> ir.DatatypeDef[ir.StrProps]:
    props = ir.StrProps()

    if (
        max_length_val := _eval_optional_expected(
            t=int,
            feature=reqif_string_tag.max_length_field,
            scope=usage,
            c=c,
            stdlib=stdlib,
        )
    ) is not None:
        props.max_length = max_length_val

    return _extract_reqif_generic(props, usage, reqif_string_tag, c, stdlib)


def _metadata_name_from_element(usage: syside.MetadataUsage) -> str | None:
    names = frozenset(
        {elt.name for elt in _metadata_about(usage) if elt.name is not None}
    )

    if not names:
        raise ValueError(
            indicate_problem_at(usage, "reqif annotated enum value is missing name")
        )
    elif len(names) > 1:
        raise ValueError(
            indicate_problem_at(usage, "reqif annotated enum value has ambiguous name")
        )

    return tuple(names)[0]


def _extract_reqif_enum_value(
    usage: syside.MetadataUsage,
    reqif_string_tag: MetaReqIFEnumValueTag,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> ir.EnumValue:
    id_ = _eval_optional_expected(
        str, reqif_string_tag.identifier_field, usage, c, stdlib
    )

    if id_ is None:
        raise ValueError(
            indicate_problem_at(usage, "reqif enum value is missing identifier")
        )

    name = _metadata_name_from_element(usage)

    if name is None:
        raise ValueError(indicate_problem_at(usage, "reqif enum value is anonymous"))

    result = ir.EnumValue(
        id=id_,
        name=name,
    )

    if (description_doc := _metadata_doc_description(usage)) is not None:
        result.description = description_doc.body

    if (
        last_change_val := _eval_optional_expected(
            t=str,
            feature=reqif_string_tag.last_change_field,
            scope=usage,
            c=c,
            stdlib=stdlib,
        )
    ) is not None:
        result.last_change = last_change_val

    if (
        key_val := _eval_optional_expected(
            t=int,
            feature=reqif_string_tag.key_field,
            scope=usage,
            c=c,
            stdlib=stdlib,
        )
    ) is not None:
        result.key = key_val

    if (
        other_content_val := _eval_optional_expected(
            t=str,
            feature=reqif_string_tag.other_content_field,
            scope=usage,
            c=c,
            stdlib=stdlib,
        )
    ) is not None:
        result.other_content = other_content_val

    return result


def _extract_reqif_xhtml(
    usage: syside.MetadataUsage,
    reqif_xhtml_tag: MetaReqIFTag,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> ir.DatatypeDef[ir.XhtmlProps]:
    props = ir.XhtmlProps()

    return _extract_reqif_generic(props, usage, reqif_xhtml_tag, c, stdlib)


def _extract_reqif_boolean(
    usage: syside.MetadataUsage,
    reqif_boolean_tag: MetaReqIFTag,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> ir.DatatypeDef[ir.BoolProps]:
    props = ir.BoolProps()

    return _extract_reqif_generic(props, usage, reqif_boolean_tag, c, stdlib)


def _extract_reqif_date(
    usage: syside.MetadataUsage,
    reqif_date_tag: MetaReqIFTag,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> ir.DatatypeDef[ir.DateProps]:
    props = ir.DateProps()

    return _extract_reqif_generic(props, usage, reqif_date_tag, c, stdlib)


def _extract_spec_type_generic(
    kind: ir.SpecKind,
    usage: syside.MetadataUsage,
    reqif_tag: MetaReqIFTag,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> ir.SpecType[typing.Any]:  # Cannot generalise type over literal
    id_ = _eval_optional_expected(str, reqif_tag.identifier_field, usage, c, stdlib)

    if id_ is None:
        raise ValueError(
            indicate_problem_at(usage, "reqif spec type metadata is missing identifier")
        )

    result = ir.SpecType(
        id=id_,
        kind=kind,
    )

    if (name := _metadata_name_from_element(usage)) is not None:
        result.name = name

    if (description := _metadata_doc_description(usage)) is not None:
        result.description = description.body

    if (
        last_change_val := _eval_optional_expected(
            t=str,
            feature=reqif_tag.last_change_field,
            scope=usage,
            c=c,
            stdlib=stdlib,
        )
    ) is not None:
        result.last_change = last_change_val

    return result


def _extract_spec_object_type(
    usage: syside.MetadataUsage,
    reqif_tag: MetaReqIFTag,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> ir.SpecObjectType:
    return _extract_spec_type_generic(
        kind=ir.SpecKind.OBJECT,
        usage=usage,
        reqif_tag=reqif_tag,
        c=c,
        stdlib=stdlib,
    )


def _extract_spec_type(
    usage: syside.MetadataUsage,
    reqif_tag: MetaReqIFTag,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> ir.SpecificationType:
    return _extract_spec_type_generic(
        kind=ir.SpecKind.SPECIFICATION,
        usage=usage,
        reqif_tag=reqif_tag,
        c=c,
        stdlib=stdlib,
    )


def _extract_relation_type(
    usage: syside.MetadataUsage,
    reqif_tag: MetaReqIFTag,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> ir.SpecRelationType:
    return _extract_spec_type_generic(
        kind=ir.SpecKind.RELATION,
        usage=usage,
        reqif_tag=reqif_tag,
        c=c,
        stdlib=stdlib,
    )


def _extract_relation_group_type(
    usage: syside.MetadataUsage,
    reqif_tag: MetaReqIFTag,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> ir.RelationGroupType:
    return _extract_spec_type_generic(
        kind=ir.SpecKind.RELATION_GROUP,
        usage=usage,
        reqif_tag=reqif_tag,
        c=c,
        stdlib=stdlib,
    )


def _extract_attribute(
    usage: syside.MetadataUsage,
    feature: syside.Feature,
    datatype_annotations: list[ir.DatatypeDef[ir.DatatypeProps]],
    enum_values: dict[syside.Element, list[ir.EnumValue]],
    reqif_tag: MetaReqIFTag,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> ir.AttributeDef[ir.AttributeDefProps]:
    id_ = _eval_optional_expected(str, reqif_tag.identifier_field, usage, c, stdlib)

    if id_ is None:
        raise ValueError(
            indicate_problem_at(usage, "reqif attribute metadata is missing identifier")
        )

    name = _metadata_name_from_element(usage)

    if name is None:
        raise ValueError(indicate_problem_at(usage, "anonymous reqif attribute"))

    if not datatype_annotations:
        raise ValueError(
            indicate_problem_at(feature, "reqif attribute without datatype annotation")
        )
    if len(datatype_annotations) > 1:
        raise ValueError(
            indicate_problem_at(
                feature, "reqif attribute with multiple datatype annotation"
            )
        )

    if (
        feature.feature_value is not None
        and feature.feature_value.is_default
        and feature.feature_value.value is not None
    ):
        default_value, _ = c.evaluate(
            feature.feature_value.value, stdlib=stdlib, scope=feature
        )
    else:
        default_value = None

    datatype_annotation = datatype_annotations[0]
    match datatype_annotation.props:
        case ir.StrProps():
            if default_value is not None and not isinstance(default_value, str):
                raise ValueError(
                    indicate_problem_at(feature, "expected string default value")
                )
            props = ir.StringAttrDef(
                datatype_def=datatype_annotation,  # type: ignore
                default_value=default_value,
            )
        case ir.IntProps():
            if default_value is not None and not isinstance(default_value, int):
                raise ValueError(
                    indicate_problem_at(feature, "expected integer default value")
                )
            props = ir.IntAttrDef(
                datatype_def=datatype_annotation,  # type: ignore
                default_value=default_value,
            )
        case ir.RealProps():
            if isinstance(default_value, int):
                default_value = float(default_value)

            if default_value is not None and not isinstance(default_value, float):
                raise ValueError(
                    indicate_problem_at(feature, "expected float default value")
                )

            props = ir.RealAttrDef(
                datatype_def=datatype_annotation,  # type: ignore
                default_value=default_value,
            )
        case ir.BoolProps():
            if default_value is not None and not isinstance(default_value, bool):
                raise ValueError(
                    indicate_problem_at(feature, "expected boolean default value")
                )

            props = ir.BoolAttrDef(
                datatype_def=datatype_annotation,  # type: ignore
                default_value=default_value,
            )
        case ir.DateProps():
            if default_value is not None and not isinstance(default_value, str):
                raise ValueError(
                    indicate_problem_at(feature, "expected date (string) default value")
                )

            props = ir.DateAttrDef(
                datatype_def=datatype_annotation,  # type: ignore
                default_value=default_value,
            )
        case ir.XhtmlProps():
            if default_value is not None and not isinstance(default_value, str):
                raise ValueError(
                    indicate_problem_at(
                        feature, "expected XHTML (string) default value"
                    )
                )

            props = ir.XhtmlAttrDef(
                datatype_def=datatype_annotation,  # type: ignore
                default_value=default_value,
            )
        case ir.EnumProps():
            if default_value is not None and not isinstance(
                default_value, syside.EnumerationUsage
            ):
                raise ValueError(
                    indicate_problem_at(feature, "expected enum usage default value")
                )

            if default_value is None:
                default_enum_value = None
            elif default_value in enum_values:
                if not enum_values[default_value]:
                    raise RuntimeError(
                        indicate_problem_at(feature, "invalid enum default")
                    )

                elif len(enum_values[default_value]) > 1:
                    raise ValueError(
                        indicate_problem_at(feature, "ambiguous enum default")
                    )

                default_enum_value = enum_values[default_value][0]
            else:
                raise ValueError(
                    indicate_problem_at(
                        feature, "enum default value is not a reqif enum value"
                    )
                )

            props = ir.EnumAttrDef(
                datatype_def=datatype_annotation,  # type: ignore
                default_value=default_enum_value,
                multi_valued=_feature_multivalued(feature, c=c, stdlib=stdlib),
            )
        case _:
            raise RuntimeError("invalid datatype prop type")

    result = ir.AttributeDef(
        id=id_,
        name=name,
        props=props,
    )

    if (description := _metadata_doc_description(usage)) is not None:
        result.description = description.body

    if (
        last_change_val := _eval_optional_expected(
            t=str,
            feature=reqif_tag.last_change_field,
            scope=usage,
            c=c,
            stdlib=stdlib,
        )
    ) is not None:
        result.last_change = last_change_val

    if (
        is_editable_val := _eval_optional_expected(
            t=bool,
            feature=reqif_tag.is_editable_field,
            scope=usage,
            c=c,
            stdlib=stdlib,
        )
    ) is not None:
        result.is_editable = is_editable_val

    return result


def _extract_spec_object(
    usage: syside.MetadataUsage,
    def_: syside.RequirementDefinition,
    typings: list[ir.SpecObjectType],
    reqif_tag: MetaReqIFTag,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> ir.SpecObject:
    id_ = _eval_optional_expected(str, reqif_tag.identifier_field, usage, c, stdlib)

    if id_ is None:
        raise ValueError(
            indicate_problem_at(usage, "spec object metadata is missing identifier")
        )

    if def_.name is None:
        raise ValueError(indicate_problem_at(usage, "anonymous spec object"))

    if not typings:
        raise RuntimeError("spec object without typings")
    elif len(typings) > 1:
        raise RuntimeError("spec object with multiple typings")

    typing = typings[0]

    result = ir.SpecObject(
        id=id_,
        name=def_.name,
        type_ref=typing,
    )

    if (description := _metadata_doc_description(usage)) is not None:
        result.description = description.body

    if (
        last_change_val := _eval_optional_expected(
            t=str,
            feature=reqif_tag.last_change_field,
            scope=usage,
            c=c,
            stdlib=stdlib,
        )
    ) is not None:
        result.last_change = last_change_val

    return result


def _extract_specification(
    usage: syside.MetadataUsage,
    def_: syside.RequirementDefinition,
    typings: list[ir.SpecificationType],
    reqif_tag: MetaReqIFTag,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> ir.Specification:
    id_ = _eval_optional_expected(str, reqif_tag.identifier_field, usage, c, stdlib)

    if id_ is None:
        raise ValueError(
            indicate_problem_at(usage, "specification metadata is missing identifier")
        )

    if def_.name is None:
        raise ValueError(indicate_problem_at(usage, "anonymous specification"))

    if not typings:
        raise RuntimeError("specification without typings")
    elif len(typings) > 1:
        raise RuntimeError("specification with multiple typings")

    typing = typings[0]

    result = ir.Specification(
        id=id_,
        name=def_.name,
        type_ref=typing,
    )

    if (description := _metadata_doc_description(usage)) is not None:
        result.description = description.body

    if (
        last_change_val := _eval_optional_expected(
            t=str,
            feature=reqif_tag.last_change_field,
            scope=usage,
            c=c,
            stdlib=stdlib,
        )
    ) is not None:
        result.last_change = last_change_val

    return result


def _connection_ultimate_features[T](
    t: type[T],
    connection: syside.ConnectionUsage,
    target_typings: Iterable[T],
) -> list[T]:
    target_set = frozenset(target_typings)

    connected = connection.related_elements.collect()

    def resolve_one(c: syside.Element) -> T:
        # `visited` makes termination obvious: each iteration adds id(c) and
        # the guard requires it to be absent, so the loop runs at most once
        # per distinct element. Cycle and chain-exhaustion both fall through
        # to the raise below.
        visited: set[int] = set()
        while id(c) not in visited:
            visited.add(id(c))

            ## Anything types itself
            if c in target_set:
                ## By virtue of set membership
                assert isinstance(c, t)
                return c

            if isinstance(c, syside.Type):
                for parent in c.heritage.elements:
                    if parent in target_set:
                        ## By virtue of set membership
                        assert isinstance(parent, t)
                        return parent

            if isinstance(c, syside.Feature) and c.feature_target is not None:
                c = c.feature_target
            else:
                break

        raise ValueError(
            indicate_problem_at(
                connection, "failed to resolve connection/relation ends"
            )
        )

    return [resolve_one(c) for c in connected]


def _extract_spec_relation(
    usage: syside.MetadataUsage,
    connection: syside.ConnectionUsage,
    typings: list[ir.SpecRelationType],
    spec_objects: dict[syside.RequirementDefinition, list[ir.SpecObject]],
    reqif_tag: MetaReqIFTag,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> ir.SpecRelation:
    id_ = _eval_optional_expected(str, reqif_tag.identifier_field, usage, c, stdlib)

    if id_ is None:
        raise ValueError(
            indicate_problem_at(usage, "relation metadata is missing identifier")
        )

    if connection.name is None:
        raise ValueError(indicate_problem_at(usage, "anonymous relation"))

    if not typings:
        raise RuntimeError("relation without typings")
    elif len(typings) > 1:
        raise RuntimeError("relation with multiple typings")

    typing = typings[0]

    connected_usages = _connection_ultimate_features(
        syside.RequirementDefinition, connection, spec_objects.keys()
    )

    if len(connected_usages) != 2:
        raise ValueError(
            indicate_problem_at(connection, "reqif relation/connection must be binary")
        )

    source_refs: list[ir.SpecObject] = spec_objects[connected_usages[0]]
    source_ref: ir.SpecObject = source_refs[0]
    target_refs: list[ir.SpecObject] = spec_objects[connected_usages[1]]
    target_ref: ir.SpecObject = target_refs[0]

    result = ir.SpecRelation(
        id=id_,
        name=connection.name,
        type_ref=typing,
        source_ref=source_ref,
        target_ref=target_ref,
    )

    if (description := _metadata_doc_description(usage)) is not None:
        result.description = description.body

    if (
        last_change_val := _eval_optional_expected(
            t=str,
            feature=reqif_tag.last_change_field,
            scope=usage,
            c=c,
            stdlib=stdlib,
        )
    ) is not None:
        result.last_change = last_change_val

    return result


def _extract_attribute_value(
    feature: syside.Feature,
    scope: syside.Type,
    attributes: list[ir.AttributeDef[ir.AttributeDefProps]],
    enum_values: dict[syside.Element, list[ir.EnumValue]],
    named_docs: dict[str, str | None],
    name: str | None,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> ir.AttributeValue | None:
    if not attributes:
        raise RuntimeError("attribute value for non-attribute")
    elif len(attributes) > 1:
        raise ValueError(
            indicate_problem_at(feature, "attribute value for ambiguous attribute")
        )

    attribute = attributes[0]

    if attribute.name == "ReqIF.Name" and name is not None:
        return ir.XhtmlAttrValue(attr_def_ref=attribute, value=name)  # type: ignore
    elif attribute.name == "ReqIF.Text" and "Text" in named_docs:
        return ir.XhtmlAttrValue(attr_def_ref=attribute, value=named_docs["Text"])  # type: ignore
    else:
        ## NOTE: Other than the above special cases, attribute values are only assigned if
        ## explicitly redefined
        if feature.owner != scope:
            return None

    match attribute.props:
        case ir.StringAttrDef():
            v_str = _eval_optional_expected(
                str, feature=feature, scope=scope, c=c, stdlib=stdlib
            )
            return ir.StringAttrValue(attr_def_ref=attribute, value=v_str)  # type: ignore
        case ir.IntAttrDef():
            v_int = _eval_optional_expected(
                int, feature=feature, scope=scope, c=c, stdlib=stdlib
            )
            return ir.IntAttrValue(attr_def_ref=attribute, value=v_int)  # type: ignore
        case ir.RealAttrDef():
            v_float = _eval_optional_expected(
                float, feature=feature, scope=scope, c=c, stdlib=stdlib
            )
            return ir.RealAttrValue(attr_def_ref=attribute, value=v_float)  # type: ignore
        case ir.BoolAttrDef():
            v_bool = _eval_optional_expected(
                bool, feature=feature, scope=scope, c=c, stdlib=stdlib
            )
            return ir.BoolAttrValue(attr_def_ref=attribute, value=v_bool)  # type: ignore
        case ir.DateAttrDef():
            v_str = _eval_optional_expected(
                str, feature=feature, scope=scope, c=c, stdlib=stdlib
            )
            return ir.DateAttrValue(attr_def_ref=attribute, value=v_str)  # type: ignore
        case ir.XhtmlAttrDef():
            v_str = _eval_optional_expected(
                str, feature=feature, scope=scope, c=c, stdlib=stdlib
            )
            return ir.XhtmlAttrValue(attr_def_ref=attribute, value=v_str)  # type: ignore
        case ir.EnumAttrDef():
            v_enum_elts = _eval_optional_resolve_to(
                t=syside.Element,
                ops=enum_values.keys(),
                feature=feature,
                scope=scope,
                c=c,
                stdlib=stdlib,
            )
            if v_enum_elts is None:
                raise ValueError(
                    indicate_problem_at(
                        feature,
                        "reqif enum attribute value does not resolve to reqif enum",
                    )
                )

            vs_enum = []
            for v_enum_elt in v_enum_elts:
                xs = enum_values[v_enum_elt]
                if not xs:
                    raise RuntimeError("empty reqif enum")
                elif len(xs) > 1:
                    raise ValueError(
                        indicate_problem_at(feature, "ambiguous reqif enum")
                    )
                vs_enum.append(xs[0])

            return ir.EnumAttrValue(attr_def_ref=attribute, value=vs_enum)  # type: ignore
        case _:
            raise RuntimeError("invalid attribute props")

    raise ValueError(indicate_problem_at(feature, "unable to extract attribute value"))


def _extract_attribute_values(
    elt: syside.Type,
    attributes: dict[syside.Feature, list[ir.AttributeDef[ir.AttributeDefProps]]],
    enum_values: dict[syside.Element, list[ir.EnumValue]],
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> list[ir.AttributeValue]:
    result: list[ir.AttributeValue] = []

    named_docs: dict[str, str | None] = {}

    def visit_annotation(comment: syside.Comment) -> None:
        if comment.name is not None:
            named_docs[comment.name] = comment.body

    elt.comments.for_each(visit_annotation)

    def visit_membership(rel: syside.FeatureMembership) -> None:
        if rel.member_element is None:
            raise ValueError(indicate_problem_at(rel, "orphaned feature membership"))

        if not isinstance(rel.member_element, syside.Feature.STD):
            raise ValueError(indicate_problem_at(rel, "non-feature feature membership"))

        ## Check if it's directly an attribute (typically inherited, with a default value)
        if rel.member_element in attributes:
            if (
                val := _extract_attribute_value(
                    rel.member_element,
                    elt,
                    attributes[rel.member_element],
                    enum_values,
                    named_docs,
                    elt.name,
                    c,
                    stdlib,
                )
            ) is not None:
                result.append(val)

        ## Otherwise it might be a (direct) redefinition of a reqif attribute
        for heritage_rel in rel.member_element.heritage.relationships:
            if (
                isinstance(heritage_rel, syside.Redefinition.STD)
                and heritage_rel.general in attributes
            ):
                ## By virtue of membership
                assert isinstance(heritage_rel.general, syside.Feature)
                ## Found a feature redefining a reqif attribute
                if (
                    val := _extract_attribute_value(
                        rel.member_element,
                        elt,
                        attributes[heritage_rel.general],
                        enum_values,
                        named_docs,
                        elt.name,
                        c,
                        stdlib,
                    )
                ) is not None:
                    result.append(val)

    elt.feature_memberships.for_each(visit_membership)

    return result


def _extract_spec_relation_group(
    usage: syside.MetadataUsage,
    def_: syside.OccurrenceDefinition,
    typings: list[ir.RelationGroupType],
    specification_types: dict[syside.RequirementDefinition, list[ir.Specification]],
    reqif_tag: MetaReqIFTag,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> ir.RelationGroup:
    id_ = _eval_optional_expected(str, reqif_tag.identifier_field, usage, c, stdlib)

    if id_ is None:
        raise ValueError(
            indicate_problem_at(usage, "relation group metadata is missing identifier")
        )

    if def_.name is None:
        raise ValueError(indicate_problem_at(usage, "anonymous relation group"))

    if not typings:
        raise RuntimeError("relation group without typings")
    elif len(typings) > 1:
        raise RuntimeError("relation group with multiple typings")

    typing = typings[0]

    source_feature = def_.get_member("source_specification")
    if source_feature is None or not isinstance(source_feature, syside.Feature):
        raise ValueError(
            indicate_problem_at(
                def_, "relation group must have explicit source_specification"
            )
        )
    source_typings: list[ir.Specification] = []
    for source_parent in source_feature.heritage.elements:
        if isinstance(source_parent, syside.RequirementDefinition):
            source_typings.extend(specification_types.get(source_parent) or [])
    if not source_typings:
        raise ValueError(
            indicate_problem_at(
                def_,
                "relation group source_specification must have an explicit reqif typing",
            )
        )
    elif len(source_typings) > 1:
        raise ValueError(
            indicate_problem_at(
                def_,
                "relation group source_specification cannot have multiple reqif typings",
            )
        )
    source_ref = source_typings[0]

    target_feature = def_.get_member("target_specification")
    if target_feature is None or not isinstance(target_feature, syside.Feature):
        raise ValueError(
            indicate_problem_at(
                def_, "relation group must have explicit target_specification"
            )
        )
    target_typings: list[ir.Specification] = []
    for target_parent in target_feature.heritage.elements:
        if isinstance(target_parent, syside.RequirementDefinition):
            target_typings.extend(specification_types.get(target_parent) or [])
    if not target_typings:
        raise ValueError(
            indicate_problem_at(
                def_,
                "relation group target_specification must have an explicit reqif typing",
            )
        )
    elif len(target_typings) > 1:
        raise ValueError(
            indicate_problem_at(
                usage,
                "relation group target_specification cannot have multiple reqif typings",
            )
        )
    target_ref = target_typings[0]

    result = ir.RelationGroup(
        id=id_,
        name=def_.name,
        type_ref=typing,
        source_ref=source_ref,
        target_ref=target_ref,
    )

    if (description := _metadata_doc_description(usage)) is not None:
        result.description = description.body

    if (
        last_change_val := _eval_optional_expected(
            t=str,
            feature=reqif_tag.last_change_field,
            scope=usage,
            c=c,
            stdlib=stdlib,
        )
    ) is not None:
        result.last_change = last_change_val

    return result


def _extract_spec_hierarchy_node(
    usage: syside.MetadataUsage,
    elt: syside.Element,
    spec_objects: list[ir.SpecObject],
    reqif_tag: MetaReqIFTag,
    c: syside.Compiler,
    stdlib: syside.Stdlib,
) -> ir.SpecHierarchyNode:
    id_ = _eval_optional_expected(str, reqif_tag.identifier_field, usage, c, stdlib)

    if id_ is None:
        raise ValueError(
            indicate_problem_at(elt, "hierarchy node metadata is missing identifier")
        )

    if not spec_objects:
        raise RuntimeError("empty reqif spec object")
    elif len(spec_objects) > 1:
        raise ValueError(indicate_problem_at(elt, "ambiguous reqif spec object"))
    spec_object = spec_objects[0]

    result = ir.SpecHierarchyNode(
        id=id_,
        name=None,  # elt.name ?
        spec_object_ref=spec_object,
    )

    if (
        last_change_val := _eval_optional_expected(
            t=str,
            feature=reqif_tag.last_change_field,
            scope=usage,
            c=c,
            stdlib=stdlib,
        )
    ) is not None:
        result.last_change = last_change_val

    if (
        is_editable_val := _eval_optional_expected(
            t=bool,
            feature=reqif_tag.is_editable_field,
            scope=usage,
            c=c,
            stdlib=stdlib,
        )
    ) is not None:
        result.is_editable = is_editable_val

    if (description := _metadata_doc_description(usage)) is not None:
        result.description = description.body

    return result


def parse_model_to_ir(
    m: syside.Model,
    *,
    sysml_tag_defs: SysMLMetadataTagDefs | None = None,
    sysml_prefix_defs: SysMLMetadataPrefixDefs | None = None,
) -> ir.Model:
    c = syside.Compiler()

    if sysml_tag_defs is None or sysml_prefix_defs is None:
        loaded_tag_defs, loaded_prefix_defs, _ = load_sysml_metadata_defs(m)
        tag_defs: SysMLMetadataTagDefs = sysml_tag_defs or loaded_tag_defs
        prefix_defs: SysMLMetadataPrefixDefs = sysml_prefix_defs or loaded_prefix_defs
    else:
        tag_defs = sysml_tag_defs
        prefix_defs = sysml_prefix_defs

    ## Do a single scan for all relevant metadata usages
    usages: dict[syside.MetadataDefinition, list[syside.MetadataUsage]] = (
        _reqif_metadata_usages(m, tag_defs, prefix_defs)
    )

    reqif_annotations: dict[syside.Element, list[syside.MetadataUsage]] = {}

    reqif_features: dict[syside.Type, list[syside.Feature]] = {}
    for usage in usages[tag_defs.reqif_tag.metadata_elem]:
        for elt in _metadata_about(usage):
            reqif_annotations.setdefault(elt, []).append(usage)

            if isinstance(elt, syside.Feature.STD):
                if not (
                    isinstance(elt.owning_relationship, syside.FeatureMembership)
                    and isinstance(elt.owner, syside.Type.STD)
                    and elt.owner in reqif_annotations
                ):
                    raise ValueError(
                        indicate_problem_at(
                            elt,
                            (
                                "reqif annotated attribute must be an owned feature "
                                "of a reqif annotated type"
                            ),
                        )
                    )
                reqif_features.setdefault(elt.owner, []).append(elt)

    ## Collect all data type annotations and the elements they annotate

    datatype_annotations: dict[
        syside.Element, list[ir.DatatypeDef[ir.DatatypeProps]]
    ] = {}

    ### Integers

    for usage in usages[tag_defs.reqif_integer_tag.metadata_elem]:
        int_ = _extract_reqif_integer(usage, tag_defs.reqif_integer_tag, c, m.lib)
        for elt in _metadata_about(usage):
            datatype_annotations.setdefault(elt, []).append(int_)

    ### Reals

    for usage in usages[tag_defs.reqif_real_tag.metadata_elem]:
        real = _extract_reqif_real(usage, tag_defs.reqif_real_tag, c, m.lib)
        for elt in _metadata_about(usage):
            datatype_annotations.setdefault(elt, []).append(real)

    ### Strings

    for usage in usages[tag_defs.reqif_string_tag.metadata_elem]:
        str_ = _extract_reqif_string(usage, tag_defs.reqif_string_tag, c, m.lib)
        for elt in _metadata_about(usage):
            datatype_annotations.setdefault(elt, []).append(str_)

    ### XHTMLs

    for usage in usages[tag_defs.reqif_xhtml_tag.metadata_elem]:
        xhtml = _extract_reqif_xhtml(usage, tag_defs.reqif_xhtml_tag, c, m.lib)
        for elt in _metadata_about(usage):
            datatype_annotations.setdefault(elt, []).append(xhtml)

    ### Booleans

    for usage in usages[tag_defs.reqif_boolean_tag.metadata_elem]:
        bool_ = _extract_reqif_boolean(usage, tag_defs.reqif_boolean_tag, c, m.lib)
        for elt in _metadata_about(usage):
            datatype_annotations.setdefault(elt, []).append(bool_)

    ### Dates

    for usage in usages[tag_defs.reqif_date_tag.metadata_elem]:
        date = _extract_reqif_date(usage, tag_defs.reqif_date_tag, c, m.lib)
        for elt in _metadata_about(usage):
            datatype_annotations.setdefault(elt, []).append(date)

    ### Enums

    #### Enum values by the (usage) they annotate
    enum_values: dict[syside.Element, list[ir.EnumValue]] = {}
    for usage in usages[tag_defs.reqif_enum_value_tag.metadata_elem]:
        enum_value = _extract_reqif_enum_value(
            usage, tag_defs.reqif_enum_value_tag, c, m.lib
        )
        for elt in _metadata_about(usage):
            enum_values.setdefault(elt, []).append(enum_value)

    #### Get all annotated enum defs (Q: should this be based on deriving from Std element?)
    enum_defs: dict[
        syside.EnumerationDefinition, list[ir.DatatypeDef[ir.EnumProps]]
    ] = {}
    for usage in usages[tag_defs.reqif_tag.metadata_elem]:
        for elt in _metadata_about(usage):
            if isinstance(elt, syside.EnumerationDefinition.STD):
                enum_defs.setdefault(elt, []).append(
                    _extract_reqif_generic(
                        ir.EnumProps(),
                        usage,
                        tag_defs.reqif_enum_value_tag,
                        c,
                        m.lib,
                    )
                )

    #### Attach all direct and inherited enum values

    owned_enum_usages: dict[
        syside.EnumerationDefinition, set[syside.EnumerationUsage]
    ] = {}
    for enum_usage in enum_values:
        if not isinstance(enum_usage, syside.EnumerationUsage.STD):
            raise ValueError(
                indicate_problem_at(
                    enum_usage, "non-enum usage annotated as a reqif enum usage"
                )
            )

        if enum_usage.owner in enum_defs:
            # by virtue of membership in enum_defs
            assert isinstance(enum_usage.owner, syside.EnumerationDefinition.STD)
            owned_enum_usages.setdefault(enum_usage.owner, set()).add(enum_usage)

    @cache
    def _enum_def_usages(
        def_: syside.EnumerationDefinition,
    ) -> frozenset[syside.EnumerationUsage]:
        result: set[syside.EnumerationUsage] = set()

        if def_ in owned_enum_usages:
            result.update(owned_enum_usages[def_])

        for parent in def_.heritage.elements:
            if isinstance(parent, syside.EnumerationDefinition.STD):
                result.update(_enum_def_usages(parent))

        return frozenset(result)

    for enum_def in enum_defs:
        vals: list[ir.EnumValue] = [
            val
            for enum_usage in _enum_def_usages(enum_def)
            for val in enum_values[enum_usage]
        ]

        for enum_dt in enum_defs[enum_def]:
            for val in vals:
                if val.id in enum_dt.props.values:
                    if enum_dt.props.values[val.id] != val:
                        raise ValueError(
                            indicate_problem_at(
                                enum_def, "Incompatible use of enum values"
                            )
                        )

                enum_dt.props.values[val.id] = val

    ### Generate the actual datatype definitions

    datatype_defs: dict[str, ir.DatatypeDef[ir.DatatypeProps]] = {}

    for dts in itertools.chain(datatype_annotations.values(), enum_defs.values()):
        assert isinstance(dts, list)
        for dt in dts:
            if dt.id in datatype_defs:
                if datatype_defs[dt.id] != dt:
                    raise ValueError(f"Incompatible definition of datateype {dt.id}")
                continue
            datatype_defs[dt.id] = dt

    ## Spec types

    ### Jump from an tagged element to its (set of) reqif-annotations
    def _reqif_annotations_for(
        metadata_def: syside.MetadataDefinition,
    ) -> Generator[tuple[syside.Type, syside.MetadataUsage], None, None]:
        for usage in usages[metadata_def]:
            for elt in _metadata_about(usage):
                if not isinstance(elt, syside.Type.STD):
                    raise ValueError(
                        indicate_problem_at(
                            elt, "#reqif_spec_object_type on non-Type element"
                        )
                    )

                annotation_usages = reqif_annotations.get(elt, [])
                if not annotation_usages:
                    raise ValueError(
                        indicate_problem_at(
                            elt, "#reqif_spec*_type without @reqif annotation"
                        )
                    )

                for annotation_usage in annotation_usages:
                    yield (elt, annotation_usage)

    ### Object types

    spec_object_types: dict[syside.Type, list[ir.SpecObjectType]] = {}
    for elt, annotation in _reqif_annotations_for(
        prefix_defs.reqif_spec_object_type_prefix
    ):
        spec_object_types.setdefault(elt, []).append(
            _extract_spec_object_type(annotation, tag_defs.reqif_tag, c, m.lib)
        )

    ### Specification types

    specification_types: dict[syside.Type, list[ir.SpecificationType]] = {}
    for elt, annotation in _reqif_annotations_for(
        prefix_defs.reqif_specification_type_prefix
    ):
        specification_types.setdefault(elt, []).append(
            _extract_spec_type(annotation, tag_defs.reqif_tag, c, m.lib)
        )

    ### Relation types

    spec_relation_types: dict[syside.Type, list[ir.SpecRelationType]] = {}
    for elt, annotation in _reqif_annotations_for(
        prefix_defs.reqif_spec_relation_type_prefix
    ):
        spec_relation_types.setdefault(elt, []).append(
            _extract_relation_type(annotation, tag_defs.reqif_tag, c, m.lib)
        )

    ### Relation group types

    relation_group_types: dict[syside.Type, list[ir.RelationGroupType]] = {}
    for elt, annotation in _reqif_annotations_for(
        prefix_defs.reqif_relation_group_type_prefix
    ):
        relation_group_types.setdefault(elt, []).append(
            _extract_relation_group_type(annotation, tag_defs.reqif_tag, c, m.lib)
        )

    ### Collect all spec* types and extract/assign attributes

    all_types: dict[syside.Type, list[ir.SpecType[ir.SpecKind]]] = {}
    for k, spec_object_type_list in spec_object_types.items():
        all_types.setdefault(k, []).extend(spec_object_type_list)
    for k, specitication_type_list in specification_types.items():
        all_types.setdefault(k, []).extend(specitication_type_list)
    for k, relation_type_list in spec_relation_types.items():
        all_types.setdefault(k, []).extend(relation_type_list)
    for k, relation_group_type_list in relation_group_types.items():
        all_types.setdefault(k, []).extend(relation_group_type_list)

    reqif_attributes: dict[
        syside.Feature, list[ir.AttributeDef[ir.AttributeDefProps]]
    ] = {}

    for featuring_type, features in reqif_features.items():
        if featuring_type in all_types:
            attributes: list[ir.AttributeDef[ir.AttributeDefProps]] = []
            for feature in features:
                data_types: list[ir.DatatypeDef[ir.DatatypeProps]] = []
                for rel in feature.heritage.relationships:
                    if isinstance(rel, syside.FeatureTyping.STD):
                        if rel.type in enum_defs:
                            ## By virtue of membership
                            assert isinstance(rel.type, syside.EnumerationDefinition)
                            data_types.extend(enum_defs[rel.type])

                if not data_types:
                    if feature in datatype_annotations:
                        data_types.extend(datatype_annotations[feature])
                    else:
                        raise ValueError(
                            indicate_problem_at(
                                feature,
                                (
                                    "reqif attribute is neither directly typed by a reqif enum "
                                    "nor annotated with a datatype"
                                ),
                            )
                        )

                for annotation in reqif_annotations[feature]:
                    attribute = _extract_attribute(
                        annotation,
                        feature,
                        data_types,
                        enum_values,
                        tag_defs.reqif_tag,
                        c,
                        m.lib,
                    )
                    attributes.append(attribute)

                    reqif_attributes.setdefault(feature, []).append(attribute)

            for spec_type in all_types[featuring_type]:
                for attribute in attributes:
                    if attribute.id in spec_type.attribute_defs:
                        if attribute != spec_type.attribute_defs[attribute.id]:
                            raise ValueError(
                                f"inconsistent use of attribute def {attribute.id}"
                            )

                    spec_type.attribute_defs[attribute.id] = attribute

    ### Collect all the above spec types

    spec_types: dict[str, ir.SpecType[ir.SpecKind]] = {}
    for spec_type_list in all_types.values():
        for spec_type in spec_type_list:
            if spec_type.id in spec_types:
                if spec_type != spec_types[spec_type.id]:
                    raise ValueError(
                        f"Inconsistent use of spec object type {spec_type.id}"
                    )
            spec_types[spec_type.id] = spec_type

    ## Spec objects/specs/relation/groups

    spec_object_elts: dict[syside.RequirementDefinition, list[ir.SpecObject]] = {}
    specification_elts: dict[syside.RequirementDefinition, list[ir.Specification]] = {}
    spec_relation_elts: dict[syside.ConnectionUsage, list[ir.SpecRelation]] = {}
    spec_relation_group_elts: dict[
        syside.OccurrenceDefinition, list[ir.RelationGroup]
    ] = {}

    ## NOTE: At the moment we assume that there is a direct owned specialisation

    ### First pass to find spec objects/specifications
    for usage in usages[tag_defs.reqif_tag.metadata_elem]:
        for elt in _metadata_about(usage):
            if not isinstance(elt, syside.Type):
                continue
            for parent in elt.heritage.elements:
                if parent in spec_object_types:
                    if not isinstance(elt, syside.RequirementDefinition):
                        raise ValueError(
                            indicate_problem_at(
                                elt,
                                "Only requirement defs may be typed by spec object types",
                            )
                        )

                    spec_object = _extract_spec_object(
                        usage,
                        elt,
                        spec_object_types[parent],
                        tag_defs.reqif_tag,
                        c,
                        m.lib,
                    )

                    for attribute_val in _extract_attribute_values(
                        elt,
                        reqif_attributes,
                        enum_values,
                        c,
                        m.lib,
                    ):
                        if attribute_val.attr_def_ref.id in spec_object.attributes:
                            if (
                                attribute_val
                                != spec_object.attributes[attribute_val.attr_def_ref.id]
                            ):
                                raise ValueError(
                                    f"inconsistent use of spec object attribute value {attribute_val.attr_def_ref.id}"
                                )
                        spec_object.attributes[attribute_val.attr_def_ref.id] = (
                            attribute_val
                        )

                    spec_object_elts.setdefault(elt, []).append(spec_object)

                if parent in specification_types:
                    if not isinstance(elt, syside.RequirementDefinition):
                        raise ValueError(
                            indicate_problem_at(
                                elt, "Only requirement defs may be typed by spec types"
                            )
                        )
                    # specification_typings.setdefault(elt, []).extend(
                    #     specification_types[parent]
                    # )

                    spec = _extract_specification(
                        usage,
                        elt,
                        specification_types[parent],
                        tag_defs.reqif_tag,
                        c,
                        m.lib,
                    )

                    for attribute_val in _extract_attribute_values(
                        elt,
                        reqif_attributes,
                        enum_values,
                        c,
                        m.lib,
                    ):
                        if attribute_val.attr_def_ref.id in spec.attributes:
                            if (
                                attribute_val
                                != spec.attributes[attribute_val.attr_def_ref.id]
                            ):
                                raise ValueError(
                                    f"inconsistent use of spec attribute value {attribute_val.attr_def_ref.id}"
                                )
                        spec.attributes[attribute_val.attr_def_ref.id] = attribute_val

                    specification_elts.setdefault(elt, []).append(spec)

    hierarchy_node_elts: dict[syside.Element, ir.SpecHierarchyNode] = {}

    ### Second pass to:
    ###   - generate spec hierarchy nodes
    ###   - find relation and relation groups, linking things from the first pass
    for usage in usages[tag_defs.reqif_tag.metadata_elem]:
        for elt in _metadata_about(usage):
            if not isinstance(elt, syside.Type):
                continue

            for parent in elt.heritage.elements:
                ## Hierarchy node
                if parent in spec_object_elts:
                    ## by virtue of membership
                    assert isinstance(parent, syside.RequirementDefinition)

                    hierarchy_node_elts[elt] = _extract_spec_hierarchy_node(
                        usage,
                        elt,
                        spec_object_elts[parent],
                        tag_defs.reqif_tag,
                        c,
                        m.lib,
                    )
                elif parent in specification_elts:
                    parent_qn = (
                        parent.qualified_name or f"anonymous {type(parent).__name__}"
                    )
                    raise ValueError(
                        indicate_problem_at(
                            elt,
                            f"hierarchy node is typed by Specification's "
                            f"requirement def {parent_qn!r}; hierarchy nodes "
                            f"must be typed by a SpecObject's requirement def",
                        )
                    )

                ## Spec relation
                if parent in spec_relation_types:
                    if not isinstance(elt, syside.ConnectionUsage):
                        raise ValueError(
                            indicate_problem_at(
                                elt,
                                "Only connection Usages may be typed by relation types",
                            )
                        )
                    # spec_relation_typings.setdefault(elt, []).extend(
                    #     spec_relation_types[parent]
                    # )

                    spec_relation = _extract_spec_relation(
                        usage,
                        elt,
                        spec_relation_types[parent],
                        spec_object_elts,
                        tag_defs.reqif_tag,
                        c,
                        m.lib,
                    )

                    for attribute_val in _extract_attribute_values(
                        elt,
                        reqif_attributes,
                        enum_values,
                        c,
                        m.lib,
                    ):
                        if attribute_val.attr_def_ref.id in spec_relation.attributes:
                            if (
                                attribute_val
                                != spec_relation.attributes[
                                    attribute_val.attr_def_ref.id
                                ]
                            ):
                                raise ValueError(
                                    f"inconsistent use of spec relation attribute value {attribute_val.attr_def_ref.id}"
                                )
                        spec_relation.attributes[attribute_val.attr_def_ref.id] = (
                            attribute_val
                        )

                    spec_relation_elts.setdefault(elt, []).append(spec_relation)

                ## Relation group
                if parent in relation_group_types:
                    if not isinstance(elt, syside.OccurrenceDefinition):
                        raise ValueError(
                            indicate_problem_at(
                                elt,
                                "Only occurrence definitions may be typed by relation group types",
                            )
                        )

                    spec_relation_group = _extract_spec_relation_group(
                        usage,
                        elt,
                        relation_group_types[parent],
                        specification_elts,
                        tag_defs.reqif_tag,
                        c,
                        m.lib,
                    )

                    for attribute_val in _extract_attribute_values(
                        elt,
                        reqif_attributes,
                        enum_values,
                        c,
                        m.lib,
                    ):
                        if (
                            attribute_val.attr_def_ref.id
                            in spec_relation_group.attributes
                        ):
                            if (
                                attribute_val
                                != spec_relation_group.attributes[
                                    attribute_val.attr_def_ref.id
                                ]
                            ):
                                raise ValueError(
                                    f"inconsistent use of spec relation group attribute value {attribute_val.attr_def_ref.id}"
                                )
                        spec_relation_group.attributes[
                            attribute_val.attr_def_ref.id
                        ] = attribute_val

                    spec_relation_group_elts.setdefault(elt, []).append(
                        spec_relation_group
                    )

    ### Link up hierarchy nodes

    #### Hierarchy nodes owned by spec objects need to be resolved later
    spec_object_hierarchy_nodes: dict[
        syside.RequirementDefinition, list[ir.SpecHierarchyNode]
    ] = {}

    for hierarchy_node_elt, hierarchy_node in hierarchy_node_elts.items():
        if hierarchy_node_elt.owner in specification_elts:
            ## by virtue of membership
            assert isinstance(hierarchy_node_elt.owner, syside.RequirementDefinition)
            for specification in specification_elts[hierarchy_node_elt.owner]:
                if hierarchy_node.id in specification.children:
                    if specification.children[hierarchy_node.id] != hierarchy_node:
                        raise ValueError(
                            f"inconsistent use of hierarchy node {hierarchy_node.id}"
                        )

                specification.children[hierarchy_node.id] = hierarchy_node
        elif hierarchy_node_elt.owner in spec_object_elts:
            ## by virtue of membership
            assert isinstance(hierarchy_node_elt.owner, syside.RequirementDefinition)
            spec_object_hierarchy_nodes.setdefault(hierarchy_node_elt.owner, []).append(
                hierarchy_node
            )
        elif hierarchy_node_elt.owner in hierarchy_node_elts:
            parent_hierarchy_node = hierarchy_node_elts[hierarchy_node_elt.owner]

            if hierarchy_node.id in parent_hierarchy_node.children:
                if parent_hierarchy_node.children[hierarchy_node.id] != hierarchy_node:
                    raise ValueError(
                        f"inconsistent use of hierarchy node {hierarchy_node.id}"
                    )

            parent_hierarchy_node.children[hierarchy_node.id] = hierarchy_node
        else:
            raise RuntimeError("dangling hierarchy node")

    #### Find uses of a spec object in specification and attach relevant hierarchy nodes
    for hierarchy_node_elt, hierarchy_node in hierarchy_node_elts.items():
        if not isinstance(hierarchy_node_elt, syside.Type):
            continue

        for parent in hierarchy_node_elt.heritage.elements:
            if parent in spec_object_hierarchy_nodes:
                if parent in spec_object_hierarchy_nodes:
                    ## By virtue of membership
                    assert isinstance(parent, syside.RequirementDefinition)
                    for remote_hierarchy_node in spec_object_hierarchy_nodes[parent]:
                        if (
                            remote_hierarchy_node.id in hierarchy_node.children
                            and hierarchy_node.children[remote_hierarchy_node.id]
                            != remote_hierarchy_node
                        ):
                            raise ValueError(
                                f"inconsistent use of hierarchy node {remote_hierarchy_node.id}"
                            )

                        hierarchy_node.children[remote_hierarchy_node.id] = (
                            remote_hierarchy_node
                        )
                if hierarchy_node_elt.owner in specification_elts:
                    ## by virtue of membership
                    assert isinstance(parent, syside.RequirementDefinition)
                    for inherited_hierarchy_node in spec_object_hierarchy_nodes[parent]:
                        if (
                            inherited_hierarchy_node.id in hierarchy_node.children
                            and hierarchy_node.children[inherited_hierarchy_node.id]
                            != inherited_hierarchy_node
                        ):
                            raise ValueError(
                                f"inconsistent use of hierarchy node {inherited_hierarchy_node.id}"
                            )
                        hierarchy_node.children[inherited_hierarchy_node.id] = (
                            inherited_hierarchy_node
                        )

    ### Collect relations into groups
    for relation_elt, relations in spec_relation_elts.items():
        for relation in relations:
            if relation_elt.owner not in spec_relation_group_elts:
                raise ValueError(
                    indicate_problem_at(
                        relation_elt, "relation must be in relation group"
                    )
                )
            ## By virtue of membership
            assert isinstance(relation_elt.owner, syside.OccurrenceDefinition)

            for relation_group in spec_relation_group_elts[relation_elt.owner]:
                if relation.id in relation_group.relations:
                    if relation_group.relations[relation.id] != relation:
                        raise ValueError(f"inconsistent use of relation {relation.id}")

                relation_group.relations[relation.id] = relation

    spec_objects: dict[str, ir.SpecObject] = {}
    specifications: dict[str, ir.Specification] = {}
    spec_relations: dict[str, ir.SpecRelation] = {}
    relation_groups: dict[str, ir.RelationGroup] = {}

    for def_, spec_object_list in spec_object_elts.items():
        for spec_object in spec_object_list:
            if spec_object.id in spec_objects:
                if spec_object != spec_objects[spec_object.id]:
                    raise ValueError(
                        f"inconsistent use of spec object {spec_object.id}"
                    )
            spec_objects[spec_object.id] = spec_object

    for specification_list in specification_elts.values():
        for specification in specification_list:
            if specification.id in specifications:
                if specification != specifications[specification.id]:
                    raise ValueError(
                        f"inconsistent use of specification {specification.id}"
                    )
            specifications[specification.id] = specification

    for spec_relation_list in spec_relation_elts.values():
        for spec_relation in spec_relation_list:
            if spec_relation.id in spec_relations:
                if spec_relation != spec_relations[spec_relation.id]:
                    raise ValueError(
                        f"inconsistent use of spec relation {spec_relation.id}"
                    )
            spec_relations[spec_relation.id] = spec_relation

    for relation_group_list in spec_relation_group_elts.values():
        for relation_group in relation_group_list:
            if relation_group.id in relation_groups:
                if relation_group != relation_groups[relation_group.id]:
                    raise ValueError(
                        f"inconsistent use of relation group {relation_group.id}"
                    )
            relation_groups[relation_group.id] = relation_group

    model = ir.Model(
        datatype_defs=datatype_defs,
        spec_types=spec_types,
        spec_objects=spec_objects,
        specifications=specifications,
        spec_relations=spec_relations,
        relation_groups=relation_groups,
    )

    return model
