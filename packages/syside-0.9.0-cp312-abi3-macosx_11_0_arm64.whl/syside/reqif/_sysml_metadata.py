import _syside
from syside.reqif._config import LIBRARY_PKG
from syside.reqif._sysml_utils import (
    iter_children_of_type,
    iter_heritage_rels_of_type,
    set_literal_value,
    set_signed_integer_literal,
)

from collections.abc import Iterable, Iterator
from dataclasses import dataclass, fields
from typing import TypeVar

T = TypeVar("T", bound=_syside.Element)


@dataclass(frozen=True)
class MetaReqIFTag:
    metadata_elem: _syside.MetadataDefinition
    identifier_field: _syside.AttributeUsage
    last_change_field: _syside.AttributeUsage
    is_editable_field: _syside.AttributeUsage


@dataclass(frozen=True)
class MetaReqIFDatatypeTag(MetaReqIFTag):
    long_name_field: _syside.AttributeUsage
    desc_field: _syside.AttributeUsage


@dataclass(frozen=True)
class MetaReqIFStringTag(MetaReqIFDatatypeTag):
    max_length_field: _syside.AttributeUsage


@dataclass(frozen=True)
class MetaReqIFIntegerTag(MetaReqIFDatatypeTag):
    min_field: _syside.AttributeUsage
    max_field: _syside.AttributeUsage


@dataclass(frozen=True)
class MetaReqIFRealTag(MetaReqIFDatatypeTag):
    min_field: _syside.AttributeUsage
    max_field: _syside.AttributeUsage
    accuracy_field: _syside.AttributeUsage


@dataclass(frozen=True)
class MetaReqIFEnumValueTag(MetaReqIFTag):
    key_field: _syside.AttributeUsage
    other_content_field: _syside.AttributeUsage


@dataclass(frozen=True)
class SysMLMetadataTagDefs:
    reqif_tag: MetaReqIFTag
    reqif_datatype_tag: MetaReqIFDatatypeTag
    reqif_integer_tag: MetaReqIFIntegerTag
    reqif_real_tag: MetaReqIFRealTag
    reqif_string_tag: MetaReqIFStringTag
    reqif_xhtml_tag: MetaReqIFDatatypeTag
    reqif_boolean_tag: MetaReqIFDatatypeTag
    reqif_date_tag: MetaReqIFDatatypeTag
    reqif_enum_value_tag: MetaReqIFEnumValueTag


@dataclass(frozen=True)
class SysMLMetadataPrefixDefs:
    reqif_spec_object_type_prefix: _syside.MetadataDefinition
    reqif_spec_relation_type_prefix: _syside.MetadataDefinition
    reqif_specification_type_prefix: _syside.MetadataDefinition
    reqif_relation_group_type_prefix: _syside.MetadataDefinition


def _by_name(elements: Iterable[_syside.Element], kind: type[T]) -> dict[str, T]:
    return {e.name: e for e in elements if isinstance(e, kind) and e.name is not None}


def _require(d: dict[str, T], *names: str, what: str) -> tuple[T, ...]:
    missing = [n for n in names if n not in d]
    if missing:
        raise ValueError(f"Missing {what}: {', '.join(missing)}")
    return tuple(d[n] for n in names)


# Names of the MetadataDefinition elements that must exist in the lib package.
_REQUIRED_MD_NAMES: tuple[str, ...] = (
    "reqif",
    "reqif_datatype",
    "reqif_integer",
    "reqif_real",
    "reqif_string",
    "reqif_xhtml",
    "reqif_boolean",
    "reqif_date",
    "reqif_enum_value",
    "reqif_spec_object_type",
    "reqif_spec_relation_type",
    "reqif_specification_type",
    "reqif_relation_group_type",
)

_BASE_ATTR_NAMES: tuple[str, ...] = (
    "identifier",
    "last_change",
    "is_editable",
)

_DATATYPE_ATTR_NAMES: tuple[str, ...] = (
    "long_name",
    "desc",
)

# Per-tag attribute fields beyond the shared `_BASE_ATTR_NAMES`. Used both to
# build the typed dataclasses in `load_sysml_metadata_defs` and to derive the
# reserved-name set below — keep this as the single source of truth.
_EXTRA_ATTR_NAMES_BY_TAG: dict[str, tuple[str, ...]] = {
    "reqif_integer": ("min", "max"),
    "reqif_real": ("min", "max", "accuracy"),
    "reqif_string": ("max_length",),
    "reqif_enum_value": ("key", "other_content"),
}

# Names reserved by the SysideReqIF library: every metadata def plus every
# attribute field on a reqif tag. ReqIF element names that collide with these
# would shadow library members in SysMLv2.
RESERVED_METADATA_NAMES: frozenset[str] = frozenset(
    {
        *_REQUIRED_MD_NAMES,
        *_BASE_ATTR_NAMES,
        *_DATATYPE_ATTR_NAMES,
        *(name for names in _EXTRA_ATTR_NAMES_BY_TAG.values() for name in names),
    }
)


def load_sysml_metadata_defs(
    model: _syside.Model,
) -> tuple[SysMLMetadataTagDefs, SysMLMetadataPrefixDefs, _syside.LibraryPackage]:
    """
    Load the references to needed SysideReqIF library elements for use in building
    metadata usages or when evaluating values through `_syside.Compiler`.

    Returns a tuple of:
        - ``SysMLMetadataTagDefs``: references to the metadata definitions
        - ``SysMLMetadataPrefixDefs``: references to the metadata prefix definitions
        - ``_syside.LibraryPackage``: the SysideReqIF library package itself
    """
    pkg = next(
        (p for p in model.nodes(_syside.LibraryPackage) if p.name == LIBRARY_PKG),
        None,
    )
    if pkg is None:
        raise ValueError(
            f"{LIBRARY_PKG} package not found\n"
            "In a fresh project, run `syside reqif init` first."
        )

    mds = _by_name(pkg.children.elements, _syside.MetadataDefinition)
    _require(mds, *_REQUIRED_MD_NAMES, what=f"{LIBRARY_PKG} metadata def")

    base_attrs = _by_name(mds["reqif"].children.elements, _syside.AttributeUsage)
    base_values = _require(base_attrs, *_BASE_ATTR_NAMES, what="reqif attribute")
    base_fields: dict[str, _syside.AttributeUsage] = {
        f"{n}_field": v for n, v in zip(_BASE_ATTR_NAMES, base_values)
    }

    datatype_attrs = _by_name(
        mds["reqif_datatype"].children.elements, _syside.AttributeUsage
    )
    datatype_values = _require(
        datatype_attrs, *_DATATYPE_ATTR_NAMES, what="reqif datatype attribute"
    )
    datatype_fields: dict[str, _syside.AttributeUsage] = {
        f"{n}_field": v for n, v in zip(_DATATYPE_ATTR_NAMES, datatype_values)
    }
    datatype_fields.update(base_fields)

    def _extra(md_name: str, *names: str) -> dict[str, _syside.AttributeUsage]:
        attrs = _by_name(mds[md_name].children.elements, _syside.AttributeUsage)
        values = _require(attrs, *names, what=f"{md_name} attribute")
        return {f"{n}_field": v for n, v in zip(names, values)}

    tag_defs = SysMLMetadataTagDefs(
        reqif_tag=MetaReqIFTag(metadata_elem=mds["reqif"], **base_fields),
        reqif_datatype_tag=MetaReqIFDatatypeTag(
            metadata_elem=mds["reqif_datatype"], **datatype_fields
        ),
        reqif_integer_tag=MetaReqIFIntegerTag(
            metadata_elem=mds["reqif_integer"],
            **datatype_fields,
            **_extra("reqif_integer", *_EXTRA_ATTR_NAMES_BY_TAG["reqif_integer"]),
        ),
        reqif_real_tag=MetaReqIFRealTag(
            metadata_elem=mds["reqif_real"],
            **datatype_fields,
            **_extra("reqif_real", *_EXTRA_ATTR_NAMES_BY_TAG["reqif_real"]),
        ),
        reqif_string_tag=MetaReqIFStringTag(
            metadata_elem=mds["reqif_string"],
            **datatype_fields,
            **_extra("reqif_string", *_EXTRA_ATTR_NAMES_BY_TAG["reqif_string"]),
        ),
        reqif_xhtml_tag=MetaReqIFDatatypeTag(
            metadata_elem=mds["reqif_xhtml"], **datatype_fields
        ),
        reqif_boolean_tag=MetaReqIFDatatypeTag(
            metadata_elem=mds["reqif_boolean"], **datatype_fields
        ),
        reqif_date_tag=MetaReqIFDatatypeTag(
            metadata_elem=mds["reqif_date"], **datatype_fields
        ),
        reqif_enum_value_tag=MetaReqIFEnumValueTag(
            metadata_elem=mds["reqif_enum_value"],
            **base_fields,
            **_extra("reqif_enum_value", *_EXTRA_ATTR_NAMES_BY_TAG["reqif_enum_value"]),
        ),
    )

    prefix_defs = SysMLMetadataPrefixDefs(
        reqif_spec_object_type_prefix=mds["reqif_spec_object_type"],
        reqif_spec_relation_type_prefix=mds["reqif_spec_relation_type"],
        reqif_specification_type_prefix=mds["reqif_specification_type"],
        reqif_relation_group_type_prefix=mds["reqif_relation_group_type"],
    )

    return tag_defs, prefix_defs, pkg


def reqif_tag_metadata_elems(
    tag_defs: SysMLMetadataTagDefs,
) -> frozenset[_syside.MetadataDefinition]:
    """Return the MetadataDefinition objects whose presence on an element marks it as @reqif*."""
    return frozenset(getattr(tag_defs, f.name).metadata_elem for f in fields(tag_defs))


def is_reqif_metadata_usage(
    meta: _syside.Type,
    tag_metadata_elems: frozenset[_syside.MetadataDefinition],
) -> bool:
    """Return True if ``meta`` is typed by one of the reqif tag MetadataDefinitions."""
    return any(
        typing.first_target in tag_metadata_elems
        for typing in iter_heritage_rels_of_type(meta, _syside.FeatureTyping)
    )


def iter_reqif_metadata_usages(
    model: _syside.Model,
    tag_defs: SysMLMetadataTagDefs,
) -> Iterator[_syside.MetadataUsage]:
    """
    Walk every MetadataUsage in ``model`` and yield only the reqif-typed ones.

    A MetadataUsage qualifies when at least one of its FeatureTyping heritage
    relations targets a MetadataDefinition listed in ``tag_defs`` (i.e. one of
    ``reqif``, ``reqif_string``, ``reqif_integer``, ``reqif_real``,
    ``reqif_boolean``, ``reqif_date``, ``reqif_xhtml``, ``reqif_enum_value``,
    or any of the spec-type prefix definitions).
    """
    tag_metadata_elems = reqif_tag_metadata_elems(tag_defs)
    for meta in model.nodes(_syside.MetadataUsage):
        if is_reqif_metadata_usage(meta, tag_metadata_elems):
            yield meta


_DATATYPE_MARKER_TAG_FIELDS: tuple[str, ...] = (
    "reqif_string_tag",
    "reqif_integer_tag",
    "reqif_real_tag",
    "reqif_boolean_tag",
    "reqif_date_tag",
    "reqif_xhtml_tag",
)


def _datatype_marker_metadata_elems(
    tag_defs: SysMLMetadataTagDefs,
) -> frozenset[_syside.MetadataDefinition]:
    """Return the MetadataDefinitions that mark a tag as a non-enum scalar datatype."""
    return frozenset(
        getattr(tag_defs, name).metadata_elem for name in _DATATYPE_MARKER_TAG_FIELDS
    )


def build_reqif_id_index(
    model: _syside.Model,
    tag_defs: SysMLMetadataTagDefs,
) -> dict[str, _syside.Element]:
    """
    Return a one-shot mapping from IR ``identifier`` to the SysMLv2 node that
    represents it.

    Walks the model once via :func:`iter_reqif_metadata_usages`, evaluates
    each tag's ``identifier`` field, and records the result. Used by the
    delta-import flow to populate ``BuildContext.refs`` without re-walking
    the model on every lookup.

    What a given id maps to depends on the tag's metadata definition:

    * ``@reqif_string``, ``@reqif_integer``, ``@reqif_real``,
      ``@reqif_boolean``, ``@reqif_date``, ``@reqif_xhtml`` — the scalar
      datatype-marker tags. These coexist with a sibling ``@reqif`` tag on
      the same host AttributeUsage (the AttributeDef carries one of each:
      ``@reqif`` identifying the AttrDef, the marker identifying the
      DatatypeDef). The id maps to the **MetadataUsage itself** so updates
      to datatype fields like ``long_name``, ``last_change``, ``max_length``
      can edit the right tag without re-discovering which one carries them.
    * Every other reqif tag (base ``@reqif``, ``@reqif_enum_value``, the
      spec-type ``#`` prefixes) — id maps to the **owner element** (the
      RequirementDefinition / EnumerationDefinition / EnumerationUsage /
      etc. hosting the tag), because that element is the IR element's
      complete representation in SysMLv2.

    Since the same scalar DatatypeDef can be referenced by multiple
    AttributeDefs, its id appears on multiple datatype-marker tags. The
    index records only one representative (last write wins); writers that
    need to update *every* tag carrying a given datatype id must re-walk
    the model. If the same identifier appears on tags hosted by entirely
    different elements (which would indicate a corrupt model) the last
    one scanned wins; callers should treat this as a precondition
    violation and fix their inputs.
    """
    compiler = _syside.Compiler()
    id_field = tag_defs.reqif_tag.identifier_field
    marker_elems = _datatype_marker_metadata_elems(tag_defs)

    result: dict[str, _syside.Element] = {}
    for meta in iter_reqif_metadata_usages(model, tag_defs):
        val, report = compiler.evaluate_feature(feature=id_field, scope=meta)
        if report.fatal:
            continue
        if not isinstance(val, str) or not val:
            continue

        if is_reqif_metadata_usage(meta, marker_elems):
            result[val] = meta
        else:
            owner = meta.owner
            if owner is None:
                continue
            result[val] = owner
    return result


def find_redefinition(
    meta: _syside.MetadataUsage,
    target: _syside.AttributeUsage,
) -> _syside.ReferenceUsage | None:
    """
    Return the ReferenceUsage child of ``meta`` whose Redefinition heritage
    targets ``target``, or ``None`` if no such child exists.
    """
    for ref in iter_children_of_type(meta, _syside.ReferenceUsage):
        for redef in iter_heritage_rels_of_type(ref, _syside.Redefinition):
            if redef.first_target is target:
                return ref
    return None


def set_redefined_string(
    meta: _syside.MetadataUsage,
    target: _syside.AttributeUsage,
    value: str,
) -> None:
    """
    Set ``target``'s redefined string value on ``meta``.

    Updates an existing redefinition's literal in place if one is present,
    otherwise appends a new ReferenceUsage child redefining ``target`` with
    a LiteralString of ``value``.
    """
    set_redefined_value(meta, target, value)


def set_redefined_value(
    meta: _syside.MetadataUsage,
    target: _syside.AttributeUsage,
    value: str | int | float | bool,
) -> None:
    """
    Set ``target``'s redefined value on ``meta``, picking the right
    ``LiteralExpression`` class based on Python type.

    Updates an existing redefinition in place if present, otherwise
    appends a new ``ReferenceUsage`` child redefining ``target``. The
    type-dispatch order matches :func:`create_metadata_tag` (``bool``
    before ``int`` because ``bool`` subclasses ``int``).
    """
    from syside.reqif._sysml_utils import (
        set_literal_value,
        set_signed_integer_literal,
    )

    existing = find_redefinition(meta, target)
    if existing is not None:
        member = existing.feature_value_member
    else:
        _, ref = meta.children.append(_syside.OwningMembership, _syside.ReferenceUsage)
        ref.heritage.insert(0, _syside.Redefinition, target)
        member = ref.feature_value_member

    if isinstance(value, str):
        _ = set_literal_value(member, _syside.LiteralString, value)
    elif isinstance(value, bool):
        _ = set_literal_value(member, _syside.LiteralBoolean, value)
    elif isinstance(value, float):
        _ = set_literal_value(member, _syside.LiteralRational, value)
    elif isinstance(value, int):
        _ = set_signed_integer_literal(member, value)
    else:
        raise TypeError(f"unsupported metadata value type {type(value).__name__}")


def find_datatype_marker_tags(
    model: _syside.Model,
    tag_defs: SysMLMetadataTagDefs,
    target_id: str,
) -> list[_syside.MetadataUsage]:
    """
    Return every datatype-marker MetadataUsage in ``model`` whose
    ``identifier`` field is ``target_id``.

    The same scalar DatatypeDef can be referenced by multiple
    AttributeDefs, each of which carries its own ``@reqif_string`` /
    ``@reqif_integer`` / ... tag. ``build_reqif_id_index`` records only
    one representative; updating a scalar DatatypeDef's fields needs to
    walk the model to update every tag.

    Reads the identifier via direct AST walk (no ``_syside.Compiler``)
    so the function works on programmatically mutated models.
    """
    marker_elems = _datatype_marker_metadata_elems(tag_defs)
    id_field = tag_defs.reqif_tag.identifier_field
    result: list[_syside.MetadataUsage] = []
    for meta in iter_reqif_metadata_usages(model, tag_defs):
        if not is_reqif_metadata_usage(meta, marker_elems):
            continue
        ref = find_redefinition(meta, id_field)
        if ref is None:
            continue
        expr = ref.feature_value_member.member_element
        if isinstance(expr, _syside.LiteralString) and expr.value == target_id:
            result.append(meta)
    return result


def create_metadata_tag(
    element: _syside.Namespace,
    tag_def: _syside.MetadataDefinition,
    values: dict[_syside.AttributeUsage, str | int | float | bool],
) -> None:
    """
    Create a @metadata tag.

    If the values are not empty, this function also creates a redefinition
    that sets the given values.
    """
    # Create the tag
    _, meta = element.children.append(_syside.OwningMembership, _syside.MetadataUsage)
    meta.heritage.append(_syside.FeatureTyping, tag_def)
    # Set values with redefinition, if any
    if values:
        for usage, value in values.items():
            _, attr = meta.children.append(
                _syside.OwningMembership, _syside.ReferenceUsage
            )
            attr.heritage.insert(0, _syside.Redefinition, usage)

            # bool must be checked before int (bool is an int subclass).
            if isinstance(value, str):
                _ = set_literal_value(
                    attr.feature_value_member, _syside.LiteralString, value
                )
            elif isinstance(value, bool):
                _ = set_literal_value(
                    attr.feature_value_member, _syside.LiteralBoolean, value
                )
            elif isinstance(value, float):
                _ = set_literal_value(
                    attr.feature_value_member, _syside.LiteralRational, value
                )
            elif isinstance(value, int):
                _ = set_signed_integer_literal(attr.feature_value_member, value)
            else:
                raise TypeError(
                    f"Unsupported metadata value type {type(value).__name__} "
                    f"for attribute {usage.name}"
                )


def add_reqif_tag(
    element: _syside.Namespace,
    tag: MetaReqIFTag,
    *,
    identifier: str,
    last_change: str | None = None,
    extra: dict[_syside.AttributeUsage, str | int | float | bool] | None = None,
) -> None:
    """
    Create a @reqif-style metadata tag setting the ``identifier`` field and,
    if provided, the ``last_change`` field.

    Pass ``extra`` to set additional fields beyond identifier/last_change
    (e.g. ``is_editable``, ``key``, ``other_content``).
    """
    values: dict[_syside.AttributeUsage, str | int | float | bool] = {
        tag.identifier_field: identifier,
    }
    if last_change is not None:
        values[tag.last_change_field] = last_change
    if extra:
        values.update(extra)
    create_metadata_tag(element, tag.metadata_elem, values=values)


def create_metadata_prefix(
    element: _syside.Namespace, tag_def: _syside.MetadataDefinition
) -> None:
    """
    Create a #metadata prefix.
    """
    # Lock the document of the element
    doc = element.document
    doc_mutex = doc.mutex
    with doc_mutex.lock():
        # Create the tag
        _, meta = element.prefixes.append(
            _syside.OwningMembership, _syside.MetadataUsage
        )
        meta.heritage.append(_syside.FeatureTyping, tag_def)


def obtain_metadata_tag(
    element: _syside.Type, tag_def: _syside.MetadataDefinition
) -> _syside.MetadataUsage | None:

    for meta in iter_children_of_type(element, _syside.MetadataUsage):
        for typing in iter_heritage_rels_of_type(meta, _syside.FeatureTyping):
            if typing.first_target == tag_def:
                return meta

    return None


def read_metadata_attribute_value(
    compiler: _syside.Compiler,
    meta_tag: _syside.Type,
    attr: _syside.AttributeUsage,
) -> str | int | float | bool | None:

    val, report = compiler.evaluate_feature(feature=attr, scope=meta_tag)

    if report.fatal:
        raise ValueError(report.diagnostics)

    if isinstance(val, (str | int | float | bool | None)):
        return val
    else:
        raise ValueError(f"Invalid value for {attr.name}: {val}")


def read_metadata_prefix(
    element: _syside.Namespace, tag_def: _syside.MetadataDefinition
) -> bool:
    """
    Check if a #metadata prefix is present and is of type `tag_def`.
    """
    for prefix in element.prefixes.elements:
        for typing in iter_heritage_rels_of_type(prefix, _syside.FeatureTyping):
            if typing.first_target == tag_def:
                return True
    return False
