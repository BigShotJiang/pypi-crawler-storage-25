from __future__ import annotations

from reqif.models.reqif_req_if_content import ReqIFReqIFContent
from reqif.models.reqif_spec_hierarchy import ReqIFSpecHierarchy
from reqif.models.reqif_specification import ReqIFSpecification
from reqif.parsers.spec_hierarchy_parser import ReqIFSpecHierarchyParser

from . import _ir_model as ir
from ._reqif_utils import (
    ElementRef,
    resolve_spec_element_name,
    decode_reqif_string,
    encode_reqif_string,
    read_attrs,
    resolve_ref,
    build_reqif_attrs_with_name_injection,
)


# FIXME
# The upstream `reqif` library (v0.0.49) parses neither emits
# the DESC attribute on SPEC-HIERARCHY. Side-channel it: the parser preserves
# the source `xml_node` on each ReqIFSpecHierarchy, so DESC is recoverable on
# read; on write, stash the description on the node as a dynamic attribute and
# patch the unparser to emit it.
_ORIG_SPEC_HIERARCHY_UNPARSE = ReqIFSpecHierarchyParser.unparse


def _unparse_with_desc(hierarchy: ReqIFSpecHierarchy) -> str:
    output = _ORIG_SPEC_HIERARCHY_UNPARSE(hierarchy)
    desc = getattr(hierarchy, "description", None)
    if desc:
        output = output.replace(
            f'<SPEC-HIERARCHY IDENTIFIER="{hierarchy.identifier}"',
            f'<SPEC-HIERARCHY DESC="{desc}" IDENTIFIER="{hierarchy.identifier}"',
            1,
        )
    return output


ReqIFSpecHierarchyParser.unparse = staticmethod(_unparse_with_desc)  # type: ignore[method-assign]


def _read_hierarchy_desc(node: ReqIFSpecHierarchy) -> str | None:
    xml_node = getattr(node, "xml_node", None)
    if xml_node is None:
        return None
    return decode_reqif_string(xml_node.attrib.get("DESC"))


def _read_hierarchy_children(
    children: list[ReqIFSpecHierarchy],
    spec_objects: dict[str, ir.SpecObject],
) -> dict[str, ir.SpecHierarchyNode]:
    """Recursively walk SPECIFICATION.children trees and build the trees IR."""
    result: dict[str, ir.SpecHierarchyNode] = {}
    for node in children:
        spec_object_ref = resolve_ref(
            ref_id=node.spec_object,
            lookup=spec_objects,
            src=ElementRef("SPEC-HIERARCHY", node.identifier),
            ref_kind="SPEC-OBJECT",
        )

        sub_children = _read_hierarchy_children(node.children or [], spec_objects)

        result[node.identifier] = ir.SpecHierarchyNode(
            id=node.identifier,
            spec_object_ref=spec_object_ref,
            children=sub_children,
            last_change=node.last_change,
            is_editable=bool(node.editable),
            name=decode_reqif_string(node.long_name),
            description=_read_hierarchy_desc(node),
        )

    return result


def read_specifications_to_ir(
    content: ReqIFReqIFContent,
    spec_types: dict[str, ir.SpecType[ir.SpecKind]],
    spec_objects: dict[str, ir.SpecObject],
    attachments_dir: str,
) -> dict[str, ir.Specification]:
    """
    Extract all SPECIFICATION entries and their SPEC-HIERARCHY trees into IR,
    keyed by ``Specification.id``.
    """
    result: dict[str, ir.Specification] = {}

    for spec in content.specifications or []:
        src = ElementRef("SPECIFICATION", spec.identifier)
        type_ref = resolve_ref(
            ref_id=spec.specification_type,
            lookup=spec_types,
            src=src,
            ref_kind="type",
        )
        if not ir.kind_of(type_ref, ir.SpecKind.SPECIFICATION):
            raise ValueError(
                f"SPECIFICATION {spec.identifier} is typed by some other type than SPECIFICATION-TYPE {type_ref.id}"
            )

        name = resolve_spec_element_name(spec, spec_types)

        attributes = read_attrs(
            reqif_attrs=spec.values or [],
            attr_defs_by_id=type_ref.attribute_defs,
            src=src,
            attachments_dir=attachments_dir,
        )

        children = _read_hierarchy_children(spec.children or [], spec_objects)

        result[spec.identifier] = ir.Specification(
            id=spec.identifier,
            name=name,
            type_ref=type_ref,
            children=children,
            attributes=attributes,
            last_change=spec.last_change,
            description=decode_reqif_string(spec.description),
        )

    return result


def _build_hierarchy(
    children: dict[str, ir.SpecHierarchyNode],
    level: int,
) -> list[ReqIFSpecHierarchy]:
    """Recursively walk the IR specification children trees and build the trees for ReqIF."""
    result: list[ReqIFSpecHierarchy] = []
    for node in children.values():
        sub = _build_hierarchy(node.children, level + 1) or None

        reqif_node = ReqIFSpecHierarchy(
            identifier=node.id,
            spec_object=node.spec_object_ref.id,
            level=level,
            children=sub,
            last_change=node.last_change,
            editable=node.is_editable or None,
            is_table_internal=None,
            long_name=encode_reqif_string(node.name),
        )
        # Side-channel: upstream `ReqIFSpecHierarchy` has no DESC field; the
        # patched unparser above reads this attribute to emit DESC.
        reqif_node.description = encode_reqif_string(node.description)  # type: ignore[attr-defined]
        result.append(reqif_node)
    return result


def write_specifications_from_ir(
    specifications: dict[str, ir.Specification],
    attachments_dir: str,
) -> list[ReqIFSpecification]:
    """Convert IR specifications to SPECIFICATION objects with SPEC-HIERARCHY."""
    result: list[ReqIFSpecification] = []
    for spec in specifications.values():
        children = _build_hierarchy(spec.children, level=1) or None

        attrs = build_reqif_attrs_with_name_injection(
            ir_attributes=spec.attributes,
            spec_type=spec.type_ref,
            name=spec.name,
            attachments_dir=attachments_dir,
        )

        result.append(
            ReqIFSpecification(
                identifier=spec.id,
                long_name=encode_reqif_string(spec.name),
                specification_type=spec.type_ref.id,
                children=children,
                values=attrs,
                last_change=spec.last_change,
                description=encode_reqif_string(spec.description),
            )
        )
    return result
