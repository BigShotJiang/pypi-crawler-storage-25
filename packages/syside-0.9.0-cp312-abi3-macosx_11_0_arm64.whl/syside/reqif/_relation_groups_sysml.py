import re

from . import _ir_model as ir

import _syside
from syside.reqif._sysml_utils import (
    BuildContext,
    extract_tracked_element,
    iter_children_of_type,
    iter_heritage_rels_of_type,
    set_or_update_description,
)
from syside.reqif._sysml_metadata import (
    add_reqif_tag,
    obtain_metadata_tag,
    set_redefined_string,
)
from syside.reqif._attribute_values_sysml import (
    make_attribute_value_field_re,
    update_attribute_usage,
    write_attribute_usage,
)
from syside.reqif._spec_relations_sysml import create_spec_relations


_OWNER_KIND_LABEL = "RelationGroup"
_ATTR_VAL_FIELD_RE = make_attribute_value_field_re("attribute_value")
_RELATION_FIELD_RE = re.compile(r"^relation\[(?P<id>[^\]]+)\]$")


def create_relation_groups(
    package: _syside.Package,
    relation_groups: dict[str, ir.RelationGroup],
    ctx: BuildContext,
) -> None:
    """
    Write **new** Relation Group elements into the given package. This function only covers
    the creation of the group, setting its attributes and referencing source and target
    specifications. For the creation of contained Spec Relation elements, this needs to be
    followed up by ``create_spec_relations`` function.

    This function adds ID -> SysMLv2 element references back to BuildContext's ``refs`` dict.
    """
    for group in relation_groups.values():
        _, group_element = package.children.append(
            _syside.OwningMembership, _syside.OccurrenceDefinition
        )
        group_element.declared_name = group.name

        add_reqif_tag(
            group_element,
            ctx.meta_tags.reqif_tag,
            identifier=group.id,
            last_change=group.last_change,
        )

        if group.description:
            set_or_update_description(group_element, group.description)

        spec_type_ref = ctx.spec_type_occ(group.type_ref.id)
        group_element.heritage.append(_syside.Subclassification, spec_type_ref)

        _, source = group_element.children.append(
            _syside.FeatureMembership, _syside.ReferenceUsage
        )
        source.declared_name = "source_specification"
        source_ref = ctx.specification(group.source_ref.id)
        source.heritage.append(_syside.FeatureTyping, source_ref)
        source.is_reference = True
        ## TODO https://gitlab.com/sensmetry/internal2/tech/syside/syside-python/-/work_items/59: Make this print as `ref`

        _, target = group_element.children.append(
            _syside.FeatureMembership, _syside.ReferenceUsage
        )
        target.declared_name = "target_specification"
        target_ref = ctx.specification(group.target_ref.id)
        target.heritage.append(_syside.FeatureTyping, target_ref)
        target.is_reference = True
        ## TODO https://gitlab.com/sensmetry/internal2/tech/syside/syside-python/-/work_items/59: Make this print as `ref`

        for relation in group.relations.values():
            create_spec_relations(
                group_element, relation, source, source_ref, target, target_ref, ctx
            )

        for ir_attr in group.attributes.values():
            _ = write_attribute_usage(
                group_element, ir_attr, "RelationGroup", group.name, ctx
            )

        ctx.refs[group.id] = group_element


def update_relation_group(
    existing: _syside.OccurrenceDefinition,
    element_delta: ir.ElementDelta,
    new_ir: ir.RelationGroup,
    ctx: BuildContext,
) -> _syside.Url:
    """
    Apply IR-level changes to an existing SysMLv2 RelationGroup
    (OccurrenceDefinition).

    Handles the SpecObject-shared fields (``name`` / ``description`` /
    ``last_change`` / ``type_ref``) plus RelationGroup specifics:

    * ``source_ref`` / ``target_ref`` rebind the FeatureTyping target on
      the ``source_specification`` / ``target_specification``
      ReferenceUsage children.
    * ``attribute_value[X]`` is dispatched to the shared
      ``update_attribute_usage`` helper.
    * ``relation[X]`` add invokes :func:`create_spec_relations` with the
      group's existing source/target ReferenceUsages and their typed
      RequirementDefinitions; removal extracts the matching
      ConnectionUsage child and clears the entry from ``ctx.refs``.
    """
    for change in element_delta.changes:
        field = change.field
        if field == "name":
            existing.declared_name = new_ir.name
        elif field == "type_ref":
            _update_type_ref(existing, new_ir.type_ref, ctx)
        elif field == "description":
            set_or_update_description(existing, new_ir.description)
        elif field == "last_change":
            _update_last_change(existing, new_ir.last_change, ctx)
        elif field == "source_ref":
            _update_end_specification(
                existing, "source_specification", new_ir.source_ref, ctx
            )
        elif field == "target_ref":
            _update_end_specification(
                existing, "target_specification", new_ir.target_ref, ctx
            )
        elif _ATTR_VAL_FIELD_RE.match(field):
            update_attribute_usage(
                existing,
                change,
                new_ir.attributes,
                ctx,
                field_re=_ATTR_VAL_FIELD_RE,
                owner_kind_label=_OWNER_KIND_LABEL,
                owner_name=new_ir.name,
            )
        elif (m := _RELATION_FIELD_RE.match(field)) is not None:
            rel_id = m.group("id")
            if change.old is None:
                new_rel_ir = new_ir.relations.get(rel_id)
                if new_rel_ir is None:
                    raise ValueError(
                        f"{_OWNER_KIND_LABEL} {new_ir.name!r}: relation "
                        f"{rel_id!r} marked as added but missing from new IR"
                    )
                add_relation_to_existing_group(existing, new_rel_ir, ctx)
            else:
                _remove_relation_from_group(rel_id, ctx)
        else:
            raise ValueError(
                f"{_OWNER_KIND_LABEL} {new_ir.name!r}: unhandled delta field {field!r}"
            )

    return existing.document.url


def add_relation_to_existing_group(
    group: _syside.OccurrenceDefinition,
    new_rel_ir: ir.SpecRelation,
    ctx: BuildContext,
) -> None:
    """
    Materialise a new SpecRelation under an already-existing RelationGroup.

    Re-derives the ``source_specification`` / ``target_specification``
    ReferenceUsages and the RequirementDefinitions they target from the
    group's children, then invokes :func:`create_spec_relations` with
    the same context a fresh import would have produced.
    """
    src_ref, src_def, tgt_ref, tgt_def = resolve_group_ends(group)
    create_spec_relations(group, new_rel_ir, src_ref, src_def, tgt_ref, tgt_def, ctx)


def _remove_relation_from_group(rel_id: str, ctx: BuildContext) -> None:
    """
    Idempotently extract the ``ConnectionUsage`` for ``rel_id`` from its
    SysML parent (the enclosing ``RelationGroup``). The ``group``
    parameter is no longer needed: ``extract_tracked_element`` reads the
    parent off the registered element's ``.owner``, which is exactly
    the group that ``create_spec_relations`` originally wrote it
    under.
    """
    extract_tracked_element(rel_id, ctx, _syside.ConnectionUsage)


def resolve_group_ends(
    group: _syside.OccurrenceDefinition,
) -> tuple[
    _syside.ReferenceUsage,
    _syside.RequirementDefinition,
    _syside.ReferenceUsage,
    _syside.RequirementDefinition,
]:
    """
    Resolve the ``source_specification`` / ``target_specification``
    ReferenceUsage children of ``group`` and the RequirementDefinition
    each is FeatureTyped against.

    Used by :func:`add_relation_to_existing_group` and by SpecRelation
    end-rebind in ``update_spec_relation`` — the same context a fresh
    import passes through to :func:`create_spec_relations`.
    """
    source_ref: _syside.ReferenceUsage | None = None
    target_ref: _syside.ReferenceUsage | None = None
    for ref in iter_children_of_type(group, _syside.ReferenceUsage):
        if ref.declared_name == "source_specification":
            source_ref = ref
        elif ref.declared_name == "target_specification":
            target_ref = ref
    if source_ref is None or target_ref is None:
        raise ValueError(
            f"RelationGroup {group.declared_name!r}: missing one or both of "
            f"'source_specification' / 'target_specification' ReferenceUsage children"
        )

    source_def = _first_feature_typing_target(source_ref, _syside.RequirementDefinition)
    target_def = _first_feature_typing_target(target_ref, _syside.RequirementDefinition)
    return source_ref, source_def, target_ref, target_def


def _first_feature_typing_target[_T: _syside.Element](
    ref: _syside.ReferenceUsage, expected: type[_T]
) -> _T:
    for typing in iter_heritage_rels_of_type(ref, _syside.FeatureTyping):
        target = typing.first_target
        if isinstance(target, expected):
            return target
    raise ValueError(
        f"ReferenceUsage {ref.declared_name!r}: no {expected.__name__} "
        f"FeatureTyping target on heritage"
    )


def _update_type_ref(
    existing: _syside.OccurrenceDefinition,
    new_type_ref: ir.RelationGroupType,
    ctx: BuildContext,
) -> None:
    new_target = ctx.spec_type_occ(new_type_ref.id)
    for index, rel in enumerate(existing.heritage.relationships):
        if rel.try_cast(_syside.Subclassification) is not None:
            existing.heritage.replace(index, _syside.Subclassification, new_target)
            return
    raise ValueError(
        f"expected a Subclassification on OccurrenceDefinition "
        f"{existing.declared_name!r}, found none"
    )


def _update_last_change(
    existing: _syside.OccurrenceDefinition,
    new_last_change: str | None,
    ctx: BuildContext,
) -> None:
    if new_last_change is None:
        return
    meta = obtain_metadata_tag(existing, ctx.meta_tags.reqif_tag.metadata_elem)
    if meta is None:
        raise ValueError(
            f"missing @reqif tag on OccurrenceDefinition {existing.declared_name!r}"
        )
    set_redefined_string(
        meta, ctx.meta_tags.reqif_tag.last_change_field, new_last_change
    )


def _update_end_specification(
    existing: _syside.OccurrenceDefinition,
    end_name: str,
    new_spec_ref: ir.Specification,
    ctx: BuildContext,
) -> None:
    """
    Rebind the FeatureTyping on the ``source_specification`` /
    ``target_specification`` ReferenceUsage child to point at a different
    Specification's RequirementDefinition.
    """
    new_target = ctx.specification(new_spec_ref.id)
    for ref in iter_children_of_type(existing, _syside.ReferenceUsage):
        if ref.declared_name != end_name:
            continue
        for index, rel in enumerate(ref.heritage.relationships):
            if rel.try_cast(_syside.FeatureTyping) is not None:
                ref.heritage.replace(index, _syside.FeatureTyping, new_target)
                return
        raise ValueError(
            f"expected a FeatureTyping on {end_name!r} ReferenceUsage of "
            f"{existing.declared_name!r}, found none"
        )
    raise ValueError(
        f"{end_name!r} ReferenceUsage not found on OccurrenceDefinition "
        f"{existing.declared_name!r}"
    )
