import _syside
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Iterator, Literal, TypeVar, cast
from urllib import parse
from pathlib import Path

if TYPE_CHECKING:
    from syside.reqif._sysml_metadata import (
        SysMLMetadataTagDefs,
        SysMLMetadataPrefixDefs,
    )

_T = TypeVar("_T", bound=_syside.AstNode)
_LiteralT = TypeVar("_LiteralT", bound=_syside.LiteralExpression)
_RefT = TypeVar("_RefT", bound=_syside.Element)


def indicate_problem_at(element: _syside.Element, msg: str | None) -> str:
    """Format ``msg`` with a ``url:start:end:`` location prefix and the element name."""
    cst_node = element.cst_node

    msg = " " + msg if msg is not None else ""

    if element.name is not None:
        name = element.name
    else:
        name = f"anonymous {type(element).__name__}"

    if cst_node is not None:
        location = (
            f"{element.document.url}:"
            f"{cst_node.start_point.line + 1}:{cst_node.start_point.character + 1}:"
            f"{cst_node.end_point.line + 1}:{cst_node.end_point.character + 1}"
        )
    else:
        location = "<in-memory>:0:0:0:0"

    return f"{location}: [{name}]{msg}"


@dataclass
class BuildContext:
    """
    Shared state passed between IR -> SysMLv2 writers.

    ``refs`` maps IR identifiers (globally unique per ReqIF) to the
    SysMLv2 elements created for them. Writers populate it as they run,
    so a downstream writer can resolve an IR cross-reference without
    re-walking the model.
    """

    meta_tags: "SysMLMetadataTagDefs"
    meta_prefixes: "SysMLMetadataPrefixDefs"
    scalar_map: dict[Literal["String", "Integer", "Real", "Boolean"], _syside.Type]
    refs: dict[str, _syside.Element] = field(default_factory=dict)
    definition_to_usage_map: dict[
        _syside.RequirementDefinition, _syside.RequirementUsage
    ] = field(default_factory=dict)  # For use when building SpecRelations
    prefix_default_map: dict[_syside.Namespace, str] = field(
        default_factory=dict
    )  # For use when building Specification top nodes

    def _ref(
        self,
        ir_id: str,
        cls: type[_RefT],
        *,
        must_be_abstract: bool = False,
    ) -> _RefT:
        elem = self.refs[ir_id]
        assert isinstance(elem, cls), (
            f"Expected {cls.__name__} for {ir_id!r}, got {type(elem).__name__}"
        )
        if must_be_abstract:
            assert getattr(elem, "is_abstract", False), (
                f"Expected abstract {cls.__name__} for {ir_id!r}, got non-abstract"
            )
        return elem

    def enum_value(self, ir_id: str) -> _syside.EnumerationUsage:
        """Resolve an IR ``EnumValue.id`` to the SysMLv2 EnumerationUsage."""
        return self._ref(ir_id, _syside.EnumerationUsage)

    def enum_def(self, ir_id: str) -> _syside.EnumerationDefinition:
        """Resolve an IR ``DatatypeDef[EnumProps].id`` to the SysMLv2 EnumerationDefinition."""
        return self._ref(ir_id, _syside.EnumerationDefinition)

    def spec_type_req(self, ir_id: str) -> _syside.RequirementDefinition:
        """
        Resolve an IR ``SpecType.id`` to the SysMLv2 abstract RequirementDefinition.

        Used for SpecObjects and Specifications typing.
        """
        return self._ref(ir_id, _syside.RequirementDefinition, must_be_abstract=True)

    def spec_type_occ(self, ir_id: str) -> _syside.OccurrenceDefinition:
        """
        Resolve an IR ``SpecType.id`` to the SysMLv2 abstract OccurrenceDefinition.

        Used for RelationGroups typing.
        """
        return self._ref(ir_id, _syside.OccurrenceDefinition, must_be_abstract=True)

    def spec_type_conn(self, ir_id: str) -> _syside.ConnectionDefinition:
        """
        Resolve an IR ``SpecType.id`` to the SysMLv2 ConnectionDefinition.

        Used for SpecRelations typing.
        """
        return self._ref(ir_id, _syside.ConnectionDefinition)

    def spec_object(self, ir_id: str) -> _syside.RequirementDefinition:
        """Resolve an IR ``SpecObject.id`` to the SysMLv2 RequirementDefinition."""
        return self._ref(ir_id, _syside.RequirementDefinition)

    def specification(self, ir_id: str) -> _syside.RequirementDefinition:
        """Resolve an IR ``Specification.id`` to the SysMLv2 RequirementDefinition."""
        return self._ref(ir_id, _syside.RequirementDefinition)

    def attr_def_ref(self, ir_id: str) -> _syside.AttributeUsage:
        """Resolve an IR ``AttributeValue.attr_def_ref.id`` to the SysMLv2 AttributeUsage."""
        return self._ref(ir_id, _syside.AttributeUsage)


def iter_children_of_type(
    parent: _syside.Namespace, node_type: type[_T]
) -> Iterator[_T]:
    """Yield direct children of parent that successfully cast to node_type."""
    for child in parent.children.elements:
        typed = child.try_cast(node_type)
        if typed is not None:
            yield typed


def iter_heritage_rels_of_type(node: _syside.Type, rel_type: type[_T]) -> Iterator[_T]:
    """
    Yield heritage relationship objects that successfully cast to rel_type.

    This is a convenience function for iterating over FeatureTypings, Redefinitions,
    Subclassifications.
    """
    for rel in node.heritage.relationships:
        typed = rel.try_cast(rel_type)
        if typed is not None:
            yield typed


def extract_tracked_element[T: _syside.Element](
    ir_id: str,
    ctx: "BuildContext",
    expected_type: type[T],
) -> T | None:
    """
    Idempotently extract the SysMLv2 element registered as
    ``ctx.refs[ir_id]`` from its parent's children, popping the entry
    from ``ctx.refs`` on success.

    Returns the extracted element on success; ``None`` when the id is
    not registered, the registered element is not of ``expected_type``,
    or the element's parent has no usable children container — leaving
    each ``update_*`` writer free to call this on every ``[X]`` removal
    without worrying about whether the child has already been pulled
    out by a prior pass.

    Used by both hierarchy-node and SpecRelation removal paths; the
    operation ("look up by id, extract from owner, clear refs") is the
    same regardless of which kind of usage the id maps to.
    """
    target = ctx.refs.get(ir_id)
    if not isinstance(target, expected_type):
        return None
    parent = target.owner
    if not isinstance(parent, _syside.Type):
        return None
    for index, child in enumerate(parent.children.elements):
        if child is target:
            parent.children.extract(index)
            ctx.refs.pop(ir_id, None)
            return target
    return None


def set_literal_value(
    member: _syside.FeatureValueAccessor,
    literal_cls: type[_LiteralT],
    value: str | int | float | bool,
) -> _syside.FeatureValue:
    """Set a literal-value expression on ``member`` and return the membership."""
    membership, expr = member.set_member_element(literal_cls)
    cast(Any, expr).value = value
    return membership


def set_signed_integer_literal(
    member: _syside.FeatureValueAccessor, value: int
) -> _syside.FeatureValue:
    """
    Set an integer literal on ``member``, expanding negative values into a
    ``Minus`` ``OperatorExpression`` over a positive ``LiteralInteger`` (SysMLv2
    has no native negative integer literal).

    Returns the ``FeatureValue`` membership so callers can set flags like
    ``is_default`` on it.
    """
    if value >= 0:
        membership, lit = member.set_member_element(_syside.LiteralInteger)
        lit.value = value
    else:
        membership, op = member.set_member_element(_syside.OperatorExpression)
        op.operator = _syside.ExplicitOperator.Minus
        _, lit = op.arguments.append(_syside.LiteralInteger)
        lit.value = -value
    return membership


def set_or_update_description(
    node: _syside.Namespace, new_desc: str | None, *, name: str | None = None
) -> None:
    """
    Set, update, or remove a Documentation child.

    With ``name=None`` targets the first unnamed Documentation; otherwise
    targets the Documentation whose ``declared_name`` matches ``name``.
    """
    matches = (
        (lambda d: d.declared_name == name)
        if name is not None
        else (lambda d: not d.declared_name)
    )
    existing_doc = next(
        (d for d in iter_children_of_type(node, _syside.Documentation) if matches(d)),
        None,
    )
    if new_desc:
        if existing_doc is not None:
            existing_doc.body = new_desc.strip()
        else:
            _, doc = node.children.append(
                _syside.OwningMembership, _syside.Documentation
            )
            doc.body = new_desc.strip()
            if name is not None:
                doc.declared_name = name
    elif existing_doc is not None:
        node.children.remove_element(existing_doc)


def build_scalar_type_map(
    model: _syside.Model,
) -> dict[Literal["String", "Integer", "Real", "Boolean"], _syside.Type]:
    """
    Return a dict of needed ScalarValues from SysMLv2 std lib.

    - ScalarValues::String,
    - ScalarValues::Integer,
    - ScalarValues::Real,
    - ScalarValues::Boolean
    """
    result: dict[Literal["String", "Integer", "Real", "Boolean"], _syside.Type] = {}

    for package in model.nodes(
        _syside.LibraryPackage, considered_document_kinds=_syside.DocumentKind.STDLIB
    ):
        if package.name == "ScalarValues":
            for child in package.children.elements:
                match child.name:
                    case "String":
                        result["String"] = child.cast(_syside.Type)
                    case "Integer":
                        result["Integer"] = child.cast(_syside.Type)
                    case "Real":
                        result["Real"] = child.cast(_syside.Type)
                    case "Boolean":
                        result["Boolean"] = child.cast(_syside.Type)
            break

    if len(result) != 4:
        raise ValueError(
            f"Expected ScalarValues to have 4 elements, found {len(result)}"
        )

    return result


def create_top_level_package(model: _syside.Model, name: str) -> _syside.Package:
    """
    Create a top-level package named ``name`` in ``model``.

    The package is created in the virtual document.
    """
    if name.strip() == "":
        raise ValueError("Package name must not be empty")

    doc_url = _syside.Url(f"memory://{parse.quote(name, safe='')}.sysml")
    doc = _syside.Document.create_st(
        _syside.DocumentOptions(url=doc_url, language="sysml")
    )
    with doc.lock() as locked:
        root = locked.root_node
        _, pkg = root.children.append(_syside.OwningMembership, _syside.Package)
        pkg.declared_name = name

    return pkg


def ensure_private_import(pkg: _syside.Package, target: _syside.Package) -> None:
    """
    Ensure pkg has a private import of target, creating it if absent.

    Uses .relationships (not .elements) because NamespaceImport is itself the
    relationship — it has no separate child element to cast.
    """
    for rel in pkg.children.relationships:
        imported = rel.try_cast(_syside.NamespaceImport)
        if imported is not None and imported.imported_namespace is target:
            return

    import_rel, _ = pkg.children.append(_syside.NamespaceImport, target)
    import_rel.visibility = _syside.VisibilityKind.Private


def check_for_reqif_metatag_presence(
    element: _syside.Namespace, reqif_tag_def: _syside.MetadataDefinition
) -> bool:

    for meta in element.metadata.collect():
        for typing in iter_heritage_rels_of_type(meta, _syside.FeatureTyping):
            if typing.first_target is reqif_tag_def:
                return True

    return False


def make_printer(root: Path) -> _syside.ModelPrinter:

    printer = _syside.ModelPrinter.sysml()

    config_file = root / "syside.toml"
    if config_file.is_file():
        syside_config = _syside.conf.load_config(config_file)
        # Overwrite one formatting setting -> We want `ref` to be printed on references (maybe)
        syside_config.format.keywords.ref.reference.fallback = (
            _syside.conf.OptionalKw.Always
        )
        printer.format = syside_config.format

    return printer


def rewrite_document(
    model: _syside.Model,
    url: _syside.Url,
    printer: _syside.ModelPrinter,
) -> None:
    """
    Rewrite a .sysml file by reprinting its document's root node.

    Pprints the document's root node rather than its top-level package so
    the output captures whatever the parser kept at document scope (file-
    level comments, leading imports, etc.) and matches the load -> pprint
    fixed point. Pprinting the package alone drops that surrounding
    context and produces a slightly different text on every cycle, which
    defeats the byte-equality short-circuit below.

    Skips the write when the new pprint output is byte-for-byte identical
    to what is already on disk, so files that didn't actually change keep
    their ``mtime`` (and aren't repeatedly bumped each time the workspace
    is rewritten end-to-end).
    """
    pkg = next(
        (p for p in model.nodes(node_kind=_syside.Package) if p.document.url == url),
        None,
    )
    if pkg is None:
        raise ValueError(f"expected to find package for url {url}")
    file_path = Path(_syside.decode_path(url))
    if not file_path.exists():
        return
    new_text = _syside.pprint(pkg.document.root_node, printer=printer)
    existing_text = file_path.read_text(encoding="utf-8")
    if existing_text == new_text:
        return
    file_path.write_text(new_text, encoding="utf-8")
