from . import _ir_model as ir

from typing import Literal

import _syside
from syside.reqif._sysml_utils import (
    BuildContext,
    iter_children_of_type,
    iter_heritage_rels_of_type,
    set_or_update_description,
)
from syside.reqif._sysml_metadata import (
    add_reqif_tag,
    obtain_metadata_tag,
    set_redefined_string,
)
from syside.reqif._attribute_values_sysml import (
    make_attribute_value_field_re,
    update_attribute_usage,
    write_attribute_usage,
)


_OWNER_KIND_LABEL = "SpecRelation"
_ATTR_VAL_FIELD_RE = make_attribute_value_field_re("attribute_value")


def create_spec_relations(
    relation_group: _syside.OccurrenceDefinition,
    relation: ir.SpecRelation,
    source_spec: _syside.ReferenceUsage,
    source_spec_def: _syside.RequirementDefinition,
    target_spec: _syside.ReferenceUsage,
    target_spec_def: _syside.RequirementDefinition,
    ctx: BuildContext,
) -> None:
    """
    Write **new** Spec Relation element into its Relation Groups. This
    function **has** to be ran after `create_relation_groups`, as the relations will
    be children of these groups.

    This function adds ID -> SysMLv2 element references back to BuildContext's ``refs`` dict.
    """
    _, relation_element = relation_group.children.append(
        _syside.OwningMembership, _syside.ConnectionUsage
    )
    relation_element.declared_name = relation.name

    add_reqif_tag(
        relation_element,
        ctx.meta_tags.reqif_tag,
        identifier=relation.id,
        last_change=relation.last_change,
    )

    if relation.description:
        set_or_update_description(relation_element, relation.description)

    spec_type_ref = ctx.spec_type_conn(relation.type_ref.id)
    relation_element.heritage.append(_syside.FeatureTyping, spec_type_ref)

    for end_to_def in spec_type_ref.children.elements:
        if end_to_def.declared_name == "source_requirement":
            _create_relation_end(
                relation_element,
                end_to_def,
                relation.source_ref.id,
                source_spec,
                source_spec_def,
                target_spec,
                target_spec_def,
                ctx,
            )
        elif end_to_def.declared_name == "target_requirement":
            _create_relation_end(
                relation_element,
                end_to_def,
                relation.target_ref.id,
                source_spec,
                source_spec_def,
                target_spec,
                target_spec_def,
                ctx,
            )

    for ir_attr in relation.attributes.values():
        _ = write_attribute_usage(
            relation_element, ir_attr, "SpecRelation", relation.name, ctx
        )

    ctx.refs[relation.id] = relation_element


def _create_relation_end(
    relation_element: _syside.ConnectionUsage,
    end_to_def: _syside.Element,
    spec_object_id: str,
    source_spec: _syside.ReferenceUsage,
    source_spec_def: _syside.RequirementDefinition,
    target_spec: _syside.ReferenceUsage,
    target_spec_def: _syside.RequirementDefinition,
    ctx: BuildContext,
) -> None:
    _, end = relation_element.children.append(
        _syside.FeatureMembership, _syside.ReferenceUsage
    )
    end.is_end = True
    end.heritage.insert(0, _syside.Redefinition, end_to_def.cast(_syside.Type))
    chain = _build_relation_end_chain(
        spec_object_id, source_spec, source_spec_def, target_spec, target_spec_def, ctx
    )
    _set_relation_end_chain(end, chain)


def _build_relation_end_chain(
    spec_object_id: str,
    source_spec: _syside.ReferenceUsage,
    source_spec_def: _syside.RequirementDefinition,
    target_spec: _syside.ReferenceUsage,
    target_spec_def: _syside.RequirementDefinition,
    ctx: BuildContext,
) -> list[_syside.Feature]:
    """
    Compute the ``ReferenceSubsetting`` feature chain for one end of a
    SpecRelation, rooted at the relation's parent group's
    ``source_specification`` / ``target_specification`` ReferenceUsage.

    ``validate_ir_model`` guarantees the SpecObject id resolves to a
    ``RequirementDefinition`` reachable in either side's hierarchy, so
    the lookup and ``_build_feature_chain`` walk must succeed and root
    at ``"source"`` or ``"target"``.
    """
    spec_object_ref = ctx.spec_object(spec_object_id)
    leaf_node = ctx.definition_to_usage_map[spec_object_ref]
    chain, start_node = _build_feature_chain(
        leaf_node, source_spec_def, target_spec_def, ctx
    )
    chain.insert(0, source_spec if start_node == "source" else target_spec)
    return chain


def _set_relation_end_chain(
    end: _syside.ReferenceUsage, chain: list[_syside.Feature]
) -> None:
    """
    Install ``chain`` as ``end``'s ``ReferenceSubsetting`` heritage.

    Replaces an existing ReferenceSubsetting in place when present (the
    update-time path) and appends a fresh one when absent (the
    create-time path). Either way callers see "this end now subsets the
    given chain" without having to care which they are.
    """
    for index, rel in enumerate(end.heritage.relationships):
        if rel.try_cast(_syside.ReferenceSubsetting) is not None:
            end.heritage.replace_chain_at(index, _syside.ReferenceSubsetting, chain)
            return
    end.heritage.append_chain(_syside.ReferenceSubsetting, chain)


def _build_feature_chain(
    initial_leaf: _syside.Feature,
    source_def: _syside.RequirementDefinition,
    target_def: _syside.RequirementDefinition,
    ctx: BuildContext,
) -> tuple[list[_syside.Feature], Literal["source", "target", "none"]]:
    """
    Walk backwards from the leaf feature up to the root feature.

    The root feature is considered to be one that is the ``source_specification`` or
    ``target_specification`` of the relation.

    Walks in from the leaf feature through the ``.owner`` to arrive at the definition.
    Then, the ``definition_to_usage_map`` is used to go to another feature in the chain.
    After inserting this feature to index 0 of the list, the algorithm is repeated until a
    definition is found that is the same as the definition of ``source_specification`` or
    ``target_specification``.
    """
    result: list[_syside.Feature] = [initial_leaf]

    inode_def = initial_leaf.owner
    while inode_def is not None:
        if inode_def is source_def:
            return result, "source"
        elif inode_def is target_def:
            return result, "target"
        else:
            if (
                isinstance(inode_def, _syside.RequirementDefinition)
                and inode_def in ctx.definition_to_usage_map
            ):
                result.insert(
                    0, ctx.definition_to_usage_map[inode_def].cast(_syside.Feature)
                )
                inode_def = result[0].owner
            else:
                inode_def = None

    return result, "none"


def update_spec_relation(
    existing: _syside.ConnectionUsage,
    element_delta: ir.ElementDelta,
    new_ir: ir.SpecRelation,
    ctx: BuildContext,
) -> _syside.Url:
    """
    Apply IR-level changes to an existing SysMLv2 SpecRelation
    (ConnectionUsage child of an OccurrenceDefinition relation group).

    Handles ``name`` / ``description`` / ``last_change`` directly. The
    ref-rebind cases (``source_ref``, ``target_ref``, ``type_ref``) are
    routed through :func:`_rebind_relation_ref`, which reuses the same
    ``definition_to_usage_map`` and ``_build_feature_chain`` logic as
    :func:`create_spec_relations`.

    ``source_ref`` / ``target_ref`` are processed *before* ``type_ref``
    in a single pass: a ``type_ref`` change re-redefines each end against
    the new type's ``source_requirement`` / ``target_requirement``, but
    leaves the ReferenceSubsetting chains intact; processing the
    end-rebinds first means each end's chain is already pointing at the
    final SpecObject before we swap the redefinition target.
    """
    ref_changes: dict[str, ir.FieldChange] = {}
    other_changes: list[ir.FieldChange] = []
    for change in element_delta.changes:
        if change.field in ("source_ref", "target_ref", "type_ref"):
            ref_changes[change.field] = change
        else:
            other_changes.append(change)

    for change in other_changes:
        field = change.field
        if field == "name":
            existing.declared_name = new_ir.name
        elif field == "description":
            set_or_update_description(existing, new_ir.description)
        elif field == "last_change":
            _update_last_change(existing, new_ir.last_change, ctx)
        elif _ATTR_VAL_FIELD_RE.match(field):
            update_attribute_usage(
                existing,
                change,
                new_ir.attributes,
                ctx,
                field_re=_ATTR_VAL_FIELD_RE,
                owner_kind_label=_OWNER_KIND_LABEL,
                owner_name=new_ir.name,
            )
        else:
            raise ValueError(
                f"{_OWNER_KIND_LABEL} {new_ir.name!r}: unhandled delta field {field!r}"
            )

    if "source_ref" in ref_changes:
        _rebind_relation_end(existing, "source_requirement", new_ir.source_ref.id, ctx)
    if "target_ref" in ref_changes:
        _rebind_relation_end(existing, "target_requirement", new_ir.target_ref.id, ctx)
    if "type_ref" in ref_changes:
        _rebind_relation_type(existing, new_ir.type_ref.id, ctx)

    return existing.document.url


def _find_relation_end(
    relation_element: _syside.ConnectionUsage,
    role: Literal["source_requirement", "target_requirement"],
) -> _syside.ReferenceUsage:
    """
    Return the ConnectionUsage end ReferenceUsage whose Redefinition
    heritage targets the type child named ``role``.

    Identifies ends by the role-name on the redefinition target, not by
    the type itself, so this remains correct mid-update when the
    enclosing ``type_ref`` change has not been applied yet.
    """
    for child in iter_children_of_type(relation_element, _syside.ReferenceUsage):
        if not child.is_end:
            continue
        for redef in iter_heritage_rels_of_type(child, _syside.Redefinition):
            target = redef.first_target
            if isinstance(target, _syside.Element) and target.declared_name == role:
                return child
    raise ValueError(
        f"{_OWNER_KIND_LABEL} {relation_element.declared_name!r}: end "
        f"redefining {role!r} not found"
    )


def _rebind_relation_end(
    relation_element: _syside.ConnectionUsage,
    role: Literal["source_requirement", "target_requirement"],
    new_spec_object_id: str,
    ctx: BuildContext,
) -> None:
    """
    Replace the ``ReferenceSubsetting`` chain on the end ReferenceUsage
    matching ``role`` so it points at ``new_spec_object_id``'s
    representative hierarchy usage. Delegates to the same
    :func:`_build_relation_end_chain` /
    :func:`_set_relation_end_chain` helpers
    :func:`_create_relation_end` uses; the only update-time additions
    are locating the end (``_find_relation_end``) and pulling the
    parent group's source/target context off the model rather than
    receiving them as parameters.
    """
    # Local import to avoid a circular dependency: ``_relation_groups_sysml``
    # imports ``create_spec_relations`` from this module.
    from syside.reqif._relation_groups_sysml import resolve_group_ends

    end = _find_relation_end(relation_element, role)
    parent_group = relation_element.owner
    if not isinstance(parent_group, _syside.OccurrenceDefinition):
        raise ValueError(
            f"{_OWNER_KIND_LABEL} {relation_element.declared_name!r}: parent "
            f"is not an OccurrenceDefinition"
        )
    src_ref, src_def, tgt_ref, tgt_def = resolve_group_ends(parent_group)
    chain = _build_relation_end_chain(
        new_spec_object_id, src_ref, src_def, tgt_ref, tgt_def, ctx
    )
    _set_relation_end_chain(end, chain)


def _rebind_relation_type(
    relation_element: _syside.ConnectionUsage,
    new_type_id: str,
    ctx: BuildContext,
) -> None:
    """
    Swap the ConnectionUsage's FeatureTyping target to the new
    ConnectionDefinition and re-redefine each end against the new type's
    ``source_requirement`` / ``target_requirement`` children.

    The ReferenceSubsetting chains on the ends are left untouched — they
    already point at the right SpecObject usages, regardless of which
    type the relation is.
    """
    new_type_def = ctx.spec_type_conn(new_type_id)

    typing_index: int | None = None
    for index, rel in enumerate(relation_element.heritage.relationships):
        if rel.try_cast(_syside.FeatureTyping) is not None:
            typing_index = index
            break
    if typing_index is None:
        raise ValueError(
            f"{_OWNER_KIND_LABEL} {relation_element.declared_name!r}: no "
            f"FeatureTyping on heritage to replace"
        )
    relation_element.heritage.replace(typing_index, _syside.FeatureTyping, new_type_def)

    new_role_targets: dict[str, _syside.Type] = {}
    for end_to_def in new_type_def.children.elements:
        name = end_to_def.declared_name
        if name in ("source_requirement", "target_requirement"):
            new_role_targets[name] = end_to_def.cast(_syside.Type)
    if (
        "source_requirement" not in new_role_targets
        or "target_requirement" not in new_role_targets
    ):
        raise ValueError(
            f"{_OWNER_KIND_LABEL} {relation_element.declared_name!r}: new "
            f"ConnectionDefinition is missing 'source_requirement' / "
            f"'target_requirement' children"
        )

    for child in iter_children_of_type(relation_element, _syside.ReferenceUsage):
        if not child.is_end:
            continue
        for redef_index, rel in enumerate(child.heritage.relationships):
            redef = rel.try_cast(_syside.Redefinition)
            if redef is None:
                continue
            current_target = redef.first_target
            current_name = (
                current_target.declared_name
                if isinstance(current_target, _syside.Element)
                else None
            )
            new_target = new_role_targets.get(current_name) if current_name else None
            if new_target is not None:
                child.heritage.replace(redef_index, _syside.Redefinition, new_target)
                break


def _update_last_change(
    existing: _syside.ConnectionUsage,
    new_last_change: str | None,
    ctx: BuildContext,
) -> None:
    if new_last_change is None:
        return
    meta = obtain_metadata_tag(existing, ctx.meta_tags.reqif_tag.metadata_elem)
    if meta is None:
        raise ValueError(
            f"missing @reqif tag on ConnectionUsage {existing.declared_name!r}"
        )
    set_redefined_string(
        meta, ctx.meta_tags.reqif_tag.last_change_field, new_last_change
    )
