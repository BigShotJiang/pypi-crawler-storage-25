"""
Syside Automator ReqIF import/export.

This module converts between ReqIF (Requirements Interchange Format) files
and SysMLv2 workspaces. It can be driven from the command line or from
Python scripts; both surfaces share the same underlying entry points.

Installation
------------

The public functions and CLI both require the ``[reqif]`` extra which pulls in
additional third-party dependencies. Install it with:

.. code-block:: shell

    pip install 'syside[reqif]'
    # or, for uv-managed projects:
    uv add 'syside[reqif]'

When the extra is missing, the captured ``ImportError`` is exposed as
``_missing_extra_error`` for callers building their own CLI.

Command-line usage
------------------

The CLI is reachable both through the top-level ``syside`` console script
and as a runnable module. The three are equivalent:

.. code-block:: shell

    syside reqif <subcommand> [options]
    python -m syside reqif <subcommand> [options]
    python -m syside.reqif <subcommand> [options]

All subcommands operate on the current working directory as the workspace
root. The available subcommands are:

- ``init`` — write the canonical ``SysideReqIF`` SysMLv2 library into the
  workspace so subsequent imports have something to reference. Use
  ``--lib-dir`` to override the default :data:`LIBRARY_DIR` location.
- ``import <file>`` — convert a ``.reqif`` or ``.reqifz`` file into
  SysMLv2 packages under the workspace, performing a fresh build or a
  delta update depending on existing content. Attachments are extracted
  into ``--attachments-dir`` (default: :data:`ATTACHMENTS_DIR`).
- ``lock`` — assign stable UUIDs and last-change timestamps to any
  ReqIF-tagged elements that don't yet have them, so subsequent
  round-trips preserve identity. Takes no options.
- ``export`` — convert the SysMLv2 models from the workspace into a
  ``.reqif`` or ``.reqifz`` file.
- ``check reqif <file>`` — validate that a ReqIF file satisfies the
  invariants required for round-trippable conversion (relation-group
  ownership, no hierarchy cycles, no name shadowing, etc.).
- ``check sysml`` — validate the workspace SysMLv2 model (currently
  enforces at most one top-level package per ``.sysml`` document, and
  that all ReqIF tags are locked).

Each subcommand exits ``0`` on success and raises on failure.

Library usage
-------------

Every CLI subcommand has a public Python counterpart: an options
dataclass plus a function named after the subcommand. The functions
return the CLI exit code and raise ``ValueError`` on validation
failures, and operate on the current working directory (use
``os.chdir`` to target a different workspace).

.. code-block:: python

    from pathlib import Path

    from syside.reqif import (
        ImportOptions,
        CheckReqifOptions,
        InitOptions,
        check_reqif,
        import_,
        init,
    )

    # Initialise the workspace once.
    init(InitOptions(lib_dir=None))

    # Validate a ReqIF file before importing it.
    reqif_file = Path("requirements.reqif")
    check_reqif(CheckReqifOptions(file=reqif_file))

    # Import the file; attachments land in ./attachments_reqif/.
    import_(ImportOptions(file=reqif_file, attachments_dir=None))

The default-path constants (:data:`LIBRARY_PKG`, :data:`LIBRARY_DIR`,
:data:`ATTACHMENTS_DIR`) are re-exported here so callers can reference
the same defaults the CLI uses without reaching into private modules.
"""

__unstable__ = True

_missing_extra_error: BaseException | None
try:
    # Import the chain that transitively loads the [reqif]-extra deps
    # (reqif, markdown-it-py, markdownify) first, so that a missing extra
    # bails before any partial bindings can land in this namespace.
    from syside.reqif._cmd_check import run_reqif as check_reqif
    from syside.reqif._cmd_check import run_sysml as check_sysml
    from syside.reqif._cmd_import import run as import_
    from syside.reqif._cmd_init import run as init
    from syside.reqif._cmd_lock import run as lock
    from syside.reqif._cmd_export import run as export
    from syside.reqif._cli import (
        CheckReqifOptions,
        CheckSysmlOptions,
        ImportOptions,
        InitOptions,
        ExportOptions,
        _OptionsBase as OptionsBase,
    )
    from syside.reqif._config import ATTACHMENTS_DIR, LIBRARY_DIR, LIBRARY_PKG
except ImportError as e:
    # Anything rooted in ``syside`` is an internal regression (typo, missing
    # submodule, etc.) and must surface untouched — the friendly install-hint
    # path is reserved for failures rooted in the third-party deps the
    # ``[reqif]`` extra pulls in (reqif, markdown-it-py, markdownify, and
    # their transitive dependencies). This avoids having to maintain a
    # hand-rolled list of extra deps in lockstep with pyproject.toml.
    if (e.name or "").split(".", 1)[0] == "syside":
        raise
    __all__: list[str] = []
    _missing_extra_error = e
else:
    __all__ = [
        "ATTACHMENTS_DIR",
        "CheckReqifOptions",
        "CheckSysmlOptions",
        "ImportOptions",
        "InitOptions",
        "ExportOptions",
        "OptionsBase",
        "LIBRARY_DIR",
        "LIBRARY_PKG",
        "check_reqif",
        "check_sysml",
        "import_",
        "init",
        "lock",
        "export",
    ]
    _missing_extra_error = None
