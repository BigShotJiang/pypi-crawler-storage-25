from __future__ import annotations

from reqif.models.reqif_req_if_content import ReqIFReqIFContent
from reqif.models.reqif_spec_relation import ReqIFSpecRelation

from . import _ir_model as ir
from ._reqif_utils import (
    ElementRef,
    decode_reqif_string,
    encode_reqif_string,
    resolve_spec_element_name,
    resolve_ref,
)


def read_spec_relations_to_ir(
    content: ReqIFReqIFContent,
    spec_types: dict[str, ir.SpecType[ir.SpecKind]],
    spec_objects: dict[str, ir.SpecObject],
) -> dict[str, ir.SpecRelation]:
    """
    Extract all SPEC-RELATION entries into IR, keyed by ``SpecRelation.id``.
    """
    result: dict[str, ir.SpecRelation] = {}

    for relation in content.spec_relations or []:
        src = ElementRef("SPEC-RELATION", relation.identifier)
        type_ref = resolve_ref(
            ref_id=relation.relation_type_ref,
            lookup=spec_types,
            src=src,
            ref_kind="type",
        )
        if not ir.kind_of(type_ref, ir.SpecKind.RELATION):
            raise ValueError(
                f"SPEC-RELATION {relation.identifier} is typed by some other type than SPEC-RELATION-TYPE {type_ref.id}"
            )

        name = resolve_spec_element_name(relation, spec_types)

        source_ref = resolve_ref(
            ref_id=relation.source,
            lookup=spec_objects,
            src=src,
            ref_kind="source",
        )

        target_ref = resolve_ref(
            ref_id=relation.target,
            lookup=spec_objects,
            src=src,
            ref_kind="target",
        )

        # FIXME: The `values_attribute` in reqif library is not a list for some reason...
        # Ignoring it completely for now not to make the writing part messy.
        # attributes = read_attrs(
        #     reqif_attrs=relation.values_attribute or [],
        #     attr_defs_by_id=type_ref.attribute_defs,
        #     element_kind="SPEC-RELATION",
        #     element_id=relation.identifier
        # )

        result[relation.identifier] = ir.SpecRelation(
            id=relation.identifier,
            name=name,
            source_ref=source_ref,
            target_ref=target_ref,
            type_ref=type_ref,
            description=decode_reqif_string(relation.description),
            last_change=relation.last_change,
            # attributes=attributes FIXME
        )

    return result


def write_spec_relations_from_ir(
    spec_relations: dict[str, ir.SpecRelation],
) -> list[ReqIFSpecRelation]:
    """Convert IR spec relations to SPEC-RELATION objects."""
    result: list[ReqIFSpecRelation] = []

    for sr in spec_relations.values():
        # FIXME: When reqif library supports lists for `values_attribute`, update this function
        # to also take into account set attributes, and inject ReqIF.Name
        # attrs = build_reqif_attrs_with_name_injection(
        #     ir_attributes=spec_obj.attributes,
        #     spec_type=spec_obj.type_ref,
        #     name=spec_obj.name,
        # )

        result.append(
            ReqIFSpecRelation(
                identifier=sr.id,
                source=sr.source_ref.id,
                target=sr.target_ref.id,
                relation_type_ref=sr.type_ref.id,
                last_change=sr.last_change,
                long_name=encode_reqif_string(sr.name),
                description=encode_reqif_string(sr.description),
                values_attribute=None,  # FIXME
            )
        )
    return result
