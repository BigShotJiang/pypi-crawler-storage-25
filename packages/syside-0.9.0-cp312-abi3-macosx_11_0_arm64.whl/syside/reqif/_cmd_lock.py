"""
'syside reqif lock' subcommand. Generates identifiers for unlocked elements.

An "unlocked" element is one that has any @reqif or @reqif_* annotation but with
no identifier or last_change value set. The lock command finds all such elements,
generates a UUID identifier and sets the current timestamp as last_change.
"""

import sys

import _syside

from pathlib import Path
from typing import Literal
import uuid
import datetime

from syside.reqif._sysml_file_loading import load_workspace_model
from syside.reqif._sysml_metadata import (
    is_reqif_metadata_usage,
    load_sysml_metadata_defs,
    reqif_tag_metadata_elems,
    set_redefined_string,
)
from syside.reqif._sysml_utils import (
    make_printer,
    rewrite_document,
)


def run() -> int:
    """
    Lock unlocked ReqIF-tagged elements in the workspace SysMLv2 model.

    Walks the model for elements carrying the ReqIF tag whose identifier or
    last-change fields have not yet been populated, generates fresh UUIDs and
    timestamps, and writes them back so subsequent ReqIF round-trips have
    stable identities.

    Unlike the other entry points this function takes no options
    — it always operates on the workspace under the current working directory.

    Returns ``0`` on success.
    """
    root = Path.cwd()
    model = load_workspace_model("locking")

    tag_defs, _, _ = load_sysml_metadata_defs(model)
    id_field = tag_defs.reqif_tag.identifier_field
    last_change_field = tag_defs.reqif_tag.last_change_field
    tag_metadata_elems = reqif_tag_metadata_elems(tag_defs)

    unlocked_elements = _find_unlocked_elements(
        model, id_field, last_change_field, tag_metadata_elems
    )

    affected_docs: set[_syside.Url] = set()
    for meta, (qn, missing) in unlocked_elements.items():
        print(f"Locking {qn}...", file=sys.stderr)

        _lock_element(meta, id_field, last_change_field, missing)

        affected_docs.add(meta.document.url)

    printer = make_printer(root)

    for url in affected_docs:
        rewrite_document(model, url, printer)

    return 0


def _find_unlocked_elements(
    model: _syside.Model,
    id_field: _syside.AttributeUsage,
    last_change_field: _syside.AttributeUsage,
    tag_metadata_elems: frozenset[_syside.MetadataDefinition],
) -> dict[_syside.MetadataUsage, tuple[str, frozenset[Literal["id", "last_change"]]]]:
    """
    Return a dict of unlocked metadata usages, qualified name of the owner element, and the set
    of fields (``id`` and/or ``last_change``) that are missing.
    """
    compiler = _syside.Compiler()
    unlocked_elements: dict[
        _syside.MetadataUsage, tuple[str, frozenset[Literal["id", "last_change"]]]
    ] = {}

    for element in model.nodes(_syside.MetadataUsage):
        if not is_reqif_metadata_usage(element, tag_metadata_elems):
            continue

        owner_element = element.owner
        if owner_element is None:
            continue
        owner_qn = str(owner_element.qualified_name)

        id_missing = False
        last_change_missing = False

        # ID
        val, report = compiler.evaluate_feature(feature=id_field, scope=element)
        if report.fatal:
            continue
        if val is None or str(val) == "":
            id_missing = True

        # last_change
        val, report = compiler.evaluate_feature(
            feature=last_change_field, scope=element
        )
        if report.fatal:
            continue
        if val is None or str(val) == "1970-01-01T00:00:00Z":
            last_change_missing = True

        fields: tuple[tuple[Literal["id", "last_change"], bool], ...] = (
            ("id", id_missing),
            ("last_change", last_change_missing),
        )
        missing: frozenset[Literal["id", "last_change"]] = frozenset(
            field for field, gone in fields if gone
        )
        if not missing:
            continue
        unlocked_elements[element] = (owner_qn, missing)

    return unlocked_elements


def _lock_element(
    meta: _syside.MetadataUsage,
    id_field: _syside.AttributeUsage,
    last_change_field: _syside.AttributeUsage,
    missing: frozenset[Literal["id", "last_change"]],
) -> None:

    if "id" in missing:
        set_redefined_string(meta, id_field, str(uuid.uuid4()))

    if "last_change" in missing:
        value = datetime.datetime.now().astimezone().isoformat(timespec="seconds")
        set_redefined_string(meta, last_change_field, value)
