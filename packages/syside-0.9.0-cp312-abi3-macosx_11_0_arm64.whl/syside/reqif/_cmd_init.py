"""``syside reqif init`` subcommand. Creates the Syside ReqIF library in the current workspace."""

import sys
from pathlib import Path

from syside.reqif._cli import InitOptions
from syside.reqif._sysml_file_loading import collect_files

from syside.reqif._config import LIBRARY_PKG, LIBRARY_DIR

SYSIDE_REQIF_LIB_CONTENT = """\
library package SysideReqIF {
    private import ScalarValues::*;

    // Used as tags (@)
    metadata def reqif {
        attribute identifier : String [1] default "";
        attribute last_change : String [1] default "1970-01-01T00:00:00Z";
        attribute is_editable : Boolean default true;
    }

    metadata def reqif_datatype :> reqif {
        attribute long_name : String [0..1];
        attribute desc : String [0..1];
    }

    metadata def reqif_integer :> reqif_datatype {
        attribute min : Integer default (-9223372036854775807) - 1; // Workaround to represent `-9223372036854775808`
        attribute max : Integer default 9223372036854775807;
    }

    metadata def reqif_real :> reqif_datatype {
        attribute min : Real default -1.79e+308;
        attribute max : Real default 1.79e+308;
        attribute accuracy : Integer default 15;
    }

    metadata def reqif_string :> reqif_datatype {
        attribute max_length : Integer default 32767;
    }

    metadata def reqif_xhtml :> reqif_datatype;

    metadata def reqif_boolean :> reqif_datatype;

    metadata def reqif_date :> reqif_datatype;

    metadata def reqif_enum_value :> reqif {
        attribute key : Integer [1] default 0;
        attribute other_content : String [1] default "";
    }

    // Used as prefixes (#)
    metadata def reqif_spec_object_type;
    metadata def reqif_spec_relation_type;
    metadata def reqif_specification_type;
    metadata def reqif_relation_group_type;
}
"""


def run(opts: InitOptions) -> int:
    """
    Initialise the current workspace for ReqIF <-> SysMLv2 conversion.

    Scans the current working directory for an existing ``<{LIBRARY_PKG}>.sysml``
    file (where ``LIBRARY_PKG`` is :data:`syside.reqif.LIBRARY_PKG`), normalising any
    BOM and CRLF/CR line endings before comparison so a Windows checkout is
    not mistaken for a stale copy. If the canonical library content is
    already present nothing happens; otherwise the canonical SysMLv2 ReqIF
    library is written under ``opts.lib_dir`` (or
    :data:`syside.reqif.LIBRARY_DIR` when unset).

    Raises ``ValueError`` if more than one ``<{LIBRARY_PKG}>.sysml`` is found
    in the workspace, since a "first hit wins" rewrite would silently leave
    the other copies stale.

    Returns ``0`` on success.
    """
    root = Path.cwd()
    found_files = collect_files(root)

    lib_files = [
        f for f in found_files if f.is_file() and f.name == f"{LIBRARY_PKG}.sysml"
    ]

    if len(lib_files) > 1:
        listing = "\n".join(f"  - {p.relative_to(root)}" for p in lib_files)
        raise ValueError(
            f"Multiple {LIBRARY_PKG}.sysml files found in the workspace; "
            f"please consolidate to a single copy before running `init`:\n"
            f"{listing}"
        )

    if lib_files:
        file = lib_files[0]
        # utf-8-sig strips a leading BOM; normalize CRLF/CR so a Windows
        # checkout doesn't look different from the canonical content.
        file_content = file.read_text(encoding="utf-8-sig")
        normalized = file_content.replace("\r\n", "\n").replace("\r", "\n")

        if normalized == SYSIDE_REQIF_LIB_CONTENT:
            print(
                f"Found existing {file.name} library. No action needed.",
                file=sys.stderr,
            )
            return 0

        file.write_text(SYSIDE_REQIF_LIB_CONTENT, encoding="utf-8")
        print(
            f"Updated {file.name} with latest SysideReqIF library content.",
            file=sys.stderr,
        )
        return 0

    lib_folder = opts.lib_dir or root / LIBRARY_DIR
    lib_folder.mkdir(parents=True, exist_ok=True)
    file = lib_folder / f"{LIBRARY_PKG}.sysml"
    file.write_text(SYSIDE_REQIF_LIB_CONTENT, encoding="utf-8")
    print(
        f"Created new {file} with latest SysideReqIF library content.",
        file=sys.stderr,
    )

    return 0
