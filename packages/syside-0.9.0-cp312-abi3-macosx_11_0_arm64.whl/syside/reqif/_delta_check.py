"""
Pre-flight triage for ``_delta_sysml`` unsupported operations.

Walks a :class:`DeltaReport` once and enumerates every ``FieldChange``
the writer layer would refuse to apply. Each issue is classified:

* ``"fatal"`` — abort the import before any mutation; surfacing one
  combined message keeps the workspace from being half-mutated when an
  unsupported delta is mixed with supported ones.
* ``"skip"`` — warn-and-drop; the writer pipeline cannot apply this
  particular field, but the rest of the import remains coherent. The
  caller strips these from the ElementDelta before the apply pass so
  partial-successes don't masquerade as full successes (and so the
  resulting ``DeltaReport`` summary already reflects what actually
  landed).

The triage list is the single source of truth for which fields are
gated. As writers grow support for currently-unsupported fields, the
matching entries here disappear and the dry-run gate stops flagging
them.
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass
from typing import Callable, Literal

from syside.reqif import _ir_model as ir


Severity = Literal["fatal", "skip"]


@dataclass(frozen=True)
class UnsupportedOp:
    """One unsupported FieldChange detected during pre-flight triage."""

    category: str
    element_id: str
    element_name: str
    field: str
    severity: Severity
    reason: str

    def format(self) -> str:
        return (
            f"  - {self.category} {self.element_name!r} ({self.element_id}): "
            f"{self.reason} (field {self.field!r})"
        )


# ``attribute_def[X].kind`` — the only unsupported sub-field on a
# SpecType change after b1/b2/b3-partial. Pulled out as a module-level
# regex so the classifier doesn't recompile it per change.
_ATTR_DEF_KIND_RE = re.compile(r"^attribute_def\[[^\]]+\]\.kind$")


_DATATYPE_KIND_REASON = (
    "datatype kind change requires rewriting every referencing AttributeUsage's "
    "FeatureTyping plus replacing the marker tag class — not yet supported"
)
_SPEC_TYPE_KIND_REASON = (
    "SpecType kind change replaces the SysMLv2 element class entirely — not "
    "yet supported"
)
_ATTR_DEF_KIND_REASON = (
    "AttributeDef kind change rewrites the FeatureTyping, marker tag class, "
    "and default value — not yet supported"
)


def _classify_datatype_def_change(field: str) -> tuple[Severity, str] | None:
    if field == "kind":
        return "fatal", _DATATYPE_KIND_REASON
    return None


def _classify_spec_type_change(field: str) -> tuple[Severity, str] | None:
    if field == "kind":
        return "fatal", _SPEC_TYPE_KIND_REASON
    if _ATTR_DEF_KIND_RE.match(field):
        # An AttrDef kind change is the most local of the four kind
        # changes: it touches one AttributeUsage and its marker tag,
        # so leaving the SysML side at the old kind doesn't cascade
        # through every dependent SpecObject the way a SpecType /
        # DatatypeDef kind change would. Skip-with-warning lets the
        # rest of the SpecType's edits land; the user (or a future
        # writer pass) can finish the kind change manually.
        return "skip", _ATTR_DEF_KIND_REASON
    return None


def _classify_default(field: str) -> tuple[Severity, str] | None:
    return None


_CLASSIFIERS: dict[str, Callable[[str], tuple[Severity, str] | None]] = {
    "DatatypeDef": _classify_datatype_def_change,
    "SpecType": _classify_spec_type_change,
    "SpecObject": _classify_default,
    "Specification": _classify_default,
    "SpecRelation": _classify_default,
    "RelationGroup": _classify_default,
}


def triage(delta: ir.DeltaReport) -> list[UnsupportedOp]:
    """
    Return every unsupported ``FieldChange`` the writer layer would
    refuse to apply, classified by severity.

    Side-effect-free: callers (:func:`apply_triage`) decide what to do
    with the result. Status ``"changed"`` is the only one that goes
    through ``update_*`` (and hence the only one with field-level
    classification); ``"added"`` elements run through ``create_*``,
    which has no unsupported-field axis to gate.
    """
    issues: list[UnsupportedOp] = []
    issues.extend(_walk(delta.datatype_defs, "DatatypeDef"))
    issues.extend(_walk(delta.spec_types, "SpecType"))
    issues.extend(_walk(delta.spec_objects, "SpecObject"))
    issues.extend(_walk(delta.specifications, "Specification"))
    issues.extend(_walk(delta.spec_relations, "SpecRelation"))
    issues.extend(_walk(delta.relation_groups, "RelationGroup"))
    return issues


def _walk(deltas: dict[str, ir.ElementDelta], category: str) -> list[UnsupportedOp]:
    classify = _CLASSIFIERS[category]
    out: list[UnsupportedOp] = []
    for element_delta in deltas.values():
        if element_delta.status != "changed":
            continue
        for change in element_delta.changes:
            verdict = classify(change.field)
            if verdict is None:
                continue
            severity, reason = verdict
            out.append(
                UnsupportedOp(
                    category=category,
                    element_id=element_delta.id,
                    element_name=element_delta.name,
                    field=change.field,
                    severity=severity,
                    reason=reason,
                )
            )
    return out


def apply_triage(delta: ir.DeltaReport) -> None:
    """
    Run :func:`triage` and act on the result.

    Raises :class:`ValueError` with all ``"fatal"`` issues bundled into
    one message when any are found — caller has not mutated the model
    yet, so this is the last chance to abort cleanly. ``"skip"`` issues
    are removed from the per-element ``changes`` lists in place and a
    one-line warning is emitted per skip on stderr; the ElementDelta
    is left as ``"changed"`` if any non-skipped fields remain, demoted
    to ``"unchanged"`` otherwise so the apply pass doesn't even iterate
    the empty list.
    """
    issues = triage(delta)
    if not issues:
        return

    fatal = [op for op in issues if op.severity == "fatal"]
    skips = [op for op in issues if op.severity == "skip"]

    if fatal:
        lines = ["delta requires unsupported operations:"]
        lines.extend(op.format() for op in fatal)
        raise ValueError("\n".join(lines))

    if skips:
        skip_keys = {(op.category, op.element_id, op.field) for op in skips}
        for op in skips:
            print(
                f"warning: skipping unsupported delta field — {op.format()}",
                file=sys.stderr,
            )
        _strip_skips(delta, skip_keys)


def _strip_skips(delta: ir.DeltaReport, skip_keys: set[tuple[str, str, str]]) -> None:
    """Remove every (category, element_id, field) entry in ``skip_keys`` from ``delta``."""
    for category, deltas in (
        ("DatatypeDef", delta.datatype_defs),
        ("SpecType", delta.spec_types),
        ("SpecObject", delta.spec_objects),
        ("Specification", delta.specifications),
        ("SpecRelation", delta.spec_relations),
        ("RelationGroup", delta.relation_groups),
    ):
        filter_changes_in_place(deltas, _make_skip_keep(category, skip_keys))


def filter_changes_in_place(
    deltas: dict[str, ir.ElementDelta],
    keep: Callable[[ir.ElementDelta, ir.FieldChange], bool],
) -> None:
    """
    Drop every ``FieldChange`` from each ``"changed"`` ElementDelta in
    ``deltas`` for which ``keep(delta, change)`` returns ``False``.

    Demotes the ElementDelta to ``"unchanged"`` when its kept-changes
    list ends up empty, so the apply pass skips it entirely. Used by
    both the unsupported-op skip filter (:func:`_strip_skips`) and the
    orchestrator's orphan-policy filter
    (``_cmd_import._strip_orphan_relation_removals``).
    """
    for delta in deltas.values():
        if delta.status != "changed":
            continue
        kept = [c for c in delta.changes if keep(delta, c)]
        if len(kept) == len(delta.changes):
            continue
        delta.changes = kept
        if not kept:
            delta.status = "unchanged"


def _make_skip_keep(
    category: str, skip_keys: set[tuple[str, str, str]]
) -> Callable[[ir.ElementDelta, ir.FieldChange], bool]:
    """Closure factory used by :func:`_strip_skips` — pulled out for mypy."""

    def _keep(delta: ir.ElementDelta, change: ir.FieldChange) -> bool:
        return (category, delta.id, change.field) not in skip_keys

    return _keep
