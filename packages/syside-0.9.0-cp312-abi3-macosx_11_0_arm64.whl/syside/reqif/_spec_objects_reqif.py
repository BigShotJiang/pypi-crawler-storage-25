from __future__ import annotations

from reqif.models.reqif_req_if_content import ReqIFReqIFContent
from reqif.models.reqif_spec_object import ReqIFSpecObject

from . import _ir_model as ir
from ._reqif_utils import (
    ElementRef,
    resolve_spec_element_name,
    decode_reqif_string,
    encode_reqif_string,
    read_attrs,
    resolve_ref,
    build_reqif_attrs_with_name_injection,
)


def read_spec_objects_to_ir(
    content: ReqIFReqIFContent,
    spec_types: dict[str, ir.SpecType[ir.SpecKind]],
    attachments_dir: str,
) -> dict[str, ir.SpecObject]:
    """
    Extract all SPEC-OBJECT entries into IR, keyed by ``SpecObject.id``.
    """
    result: dict[str, ir.SpecObject] = {}

    for spec_object in content.spec_objects or []:
        src = ElementRef("SPEC-OBJECT", spec_object.identifier)
        type_ref = resolve_ref(
            ref_id=spec_object.spec_object_type,
            lookup=spec_types,
            src=src,
            ref_kind="type",
        )
        if not ir.kind_of(type_ref, ir.SpecKind.OBJECT):
            raise ValueError(
                f"SPEC-OBJECT {spec_object.identifier} is typed by some other type than SPEC-OBJECT-TYPE {type_ref.id}"
            )

        name = resolve_spec_element_name(spec_object, spec_types)

        attributes = read_attrs(
            reqif_attrs=spec_object.attributes,
            attr_defs_by_id=type_ref.attribute_defs,
            src=src,
            attachments_dir=attachments_dir,
        )

        result[spec_object.identifier] = ir.SpecObject(
            id=spec_object.identifier,
            name=name,
            type_ref=type_ref,
            attributes=attributes,
            description=decode_reqif_string(spec_object.description),
            last_change=spec_object.last_change,
        )

    return result


def write_spec_objects_from_ir(
    spec_objects: dict[str, ir.SpecObject],
    attachments_dir: str,
) -> list[ReqIFSpecObject]:
    """Convert IR spec objects to SPEC-OBJECT objects."""
    result: list[ReqIFSpecObject] = []
    for spec_obj in spec_objects.values():
        attrs = build_reqif_attrs_with_name_injection(
            ir_attributes=spec_obj.attributes,
            spec_type=spec_obj.type_ref,
            name=spec_obj.name,
            attachments_dir=attachments_dir,
        )

        result.append(
            ReqIFSpecObject(
                identifier=spec_obj.id,
                attributes=attrs,
                spec_object_type=spec_obj.type_ref.id,
                long_name=encode_reqif_string(spec_obj.name),
                description=encode_reqif_string(spec_obj.description),
                last_change=spec_obj.last_change,
            )
        )

    return result
