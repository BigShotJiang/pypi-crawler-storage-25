"""``syside reqif import`` subcommand. Orchestrates the ReqIF -> SysMLv2 conversion."""

import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import _syside

from syside.reqif._sysml_file_loading import load_workspace_model
from syside.reqif._cli import ImportOptions
from syside.reqif import _ir_model as ir
from syside.reqif._ir_model import Model as ir_Model, diff_ir_models
from syside.reqif._config import (
    ATTACHMENTS_DIR,
    ENUMS_PKG,
    TYPES_PKG,
    OBJECTS_PKG,
    SPECS_PKG,
    RELATIONS_PKG,
)

from syside.reqif._reqif_loading import load_and_parse_reqif_to_ir
from syside.reqif._cmd_check import validate_ir_model, validate_sysml

from syside.reqif._sysml_utils import (
    build_scalar_type_map,
    BuildContext,
    create_top_level_package,
    ensure_private_import,
    iter_heritage_rels_of_type,
    make_printer,
    rewrite_document,
)
from syside.reqif._sysml_metadata import (
    build_reqif_id_index,
    load_sysml_metadata_defs,
)
from syside.reqif._datatypes_sysml import update_scalar_datatype_def
from syside.reqif._enum_defs_sysml import create_enum_defs, update_enum_def
from syside.reqif._spec_types_sysml import create_spec_types, update_spec_type
from syside.reqif._spec_objects_sysml import create_spec_objects, update_spec_object
from syside.reqif._specifications_sysml import (
    create_specifications,
    update_specification,
)
from syside.reqif._spec_relations_sysml import update_spec_relation
from syside.reqif._relation_groups_sysml import (
    create_relation_groups,
    update_relation_group,
)
from syside.reqif._model_to_ir import parse_model_to_ir
from syside.reqif._delta_check import apply_triage, filter_changes_in_place


@dataclass(frozen=True)
class _PkgSpec:
    """One ReqIF -> SysMLv2 output package: name, IR field, creator, and deps."""

    name: str
    ir_field: str
    creator: Callable[[_syside.Package, Any, BuildContext], None]
    deps: tuple[str, ...]  # other _PkgSpec names; the lib package is implicit


_PKG_SPECS: tuple[_PkgSpec, ...] = (
    _PkgSpec(ENUMS_PKG, "datatype_defs", create_enum_defs, ()),
    _PkgSpec(TYPES_PKG, "spec_types", create_spec_types, (ENUMS_PKG,)),
    _PkgSpec(OBJECTS_PKG, "spec_objects", create_spec_objects, (ENUMS_PKG, TYPES_PKG)),
    _PkgSpec(
        SPECS_PKG,
        "specifications",
        create_specifications,
        (ENUMS_PKG, TYPES_PKG, OBJECTS_PKG),
    ),
    _PkgSpec(
        RELATIONS_PKG,
        "relation_groups",
        create_relation_groups,
        (ENUMS_PKG, TYPES_PKG, SPECS_PKG),
    ),
)


def run(opts: ImportOptions) -> int:
    """
    Run the ReqIF -> SysMLv2 conversion.

    Loads the workspace SysMLv2 model under the current working directory
    and parses ``opts.file`` into the intermediate representation. If the
    workspace contains no existing ReqIF content, a fresh set of SysMLv2
    packages is built from the IR; otherwise a delta import is performed
    against the existing content.

    Attachments referenced by the ReqIF file are extracted into
    ``opts.attachments_dir`` (or ``<cwd>/`` joined with
    :data:`syside.reqif.ATTACHMENTS_DIR` when unset).

    Returns ``0`` on success.
    """
    root = Path.cwd()
    attachments_dir = opts.attachments_dir or root / ATTACHMENTS_DIR

    sysml_model = load_workspace_model("imports")
    validate_sysml(sysml_model)

    ir_model_from_reqif = load_and_parse_reqif_to_ir(opts.file, attachments_dir)

    # Parse existing SysML. ``parse_model_to_ir`` loads the metadata tag
    # and prefix defs itself when the kwargs are omitted.
    ir_model_from_sysml = parse_model_to_ir(sysml_model)

    if ir_model_from_sysml.is_empty():
        print(
            "The existing SysML model has no ReqIF content. Building new model from ReqIF...",
            file=sys.stderr,
        )
        _fresh_sysml(sysml_model, ir_model_from_reqif, root)
    else:
        print(
            "The existing SysML model has existing ReqIF content. Running delta import...",
            file=sys.stderr,
        )
        _delta_sysml(
            sysml_model, root, old_ir=ir_model_from_sysml, new_ir=ir_model_from_reqif
        )

    return 0


def _fresh_sysml(sysml_model: _syside.Model, ir_model: ir_Model, root: Path) -> None:
    # Gate every fresh-import conversion on the same checks ``check reqif``
    # runs: the converter never sees an IR the validator would reject. Tests
    # that drive ``_fresh_sysml`` directly also rely on this inline gate.
    validate_ir_model(ir_model)

    # Set up build context
    sysml_metadata_defs = load_sysml_metadata_defs(sysml_model)
    scalar_type_map = build_scalar_type_map(sysml_model)
    build_ctx = BuildContext(
        meta_tags=sysml_metadata_defs[0],
        meta_prefixes=sysml_metadata_defs[1],
        scalar_map=scalar_type_map,
    )

    # Create required packages
    pkgs: dict[str, _syside.Package] = {
        spec.name: create_top_level_package(sysml_model, name=spec.name)
        for spec in _PKG_SPECS
    }
    ## TODO https://gitlab.com/sensmetry/internal2/tech/syside/syside-python/-/work_items/57: Create a ReqIF_Views package with pre-defined table views

    # Create required imports for the fresh import (every pkg gets the lib)
    lib = sysml_metadata_defs[2]
    for spec in _PKG_SPECS:
        pkg = pkgs[spec.name]
        ensure_private_import(pkg, lib)
        for dep_name in spec.deps:
            ensure_private_import(pkg, pkgs[dep_name])

    # Create the required elements
    for spec in _PKG_SPECS:
        spec.creator(pkgs[spec.name], getattr(ir_model, spec.ir_field), build_ctx)

    # Write SysML
    printer = make_printer(root)

    for spec in _PKG_SPECS:
        out_path = Path.cwd() / f"{spec.name}.sysml"
        with out_path.open("w") as f:
            f.write(_syside.pprint(pkgs[spec.name], printer=printer))


def _delta_sysml(
    sysml_model: _syside.Model,
    root: Path,
    *,
    old_ir: ir_Model,
    new_ir: ir_Model,
) -> None:
    # Gate every delta-import conversion on the same checks ``check reqif``
    # runs against the incoming IR: the converter never sees an IR the
    # validator would reject. Tests that drive ``_delta_sysml`` directly
    # also rely on this inline gate.
    validate_ir_model(new_ir)

    delta = diff_ir_models(old_ir, new_ir)
    print(delta.summary())

    # Pre-flight: enumerate every FieldChange the writer pipeline would
    # refuse to apply. Fatal verdicts raise before we touch the model
    # (otherwise an unsupported field landing mid-batch leaves the
    # workspace half-mutated with no transactional rollback); skip
    # verdicts are stripped from the deltas in place with a warning.
    apply_triage(delta)

    # Honor the same "orphans are not auto-deleted" stance applied to
    # other top-level kinds (SpecObject, Specification, ...): when a
    # SpecRelation is dropped from the incoming ReqIF entirely, the diff
    # both lists it in ``delta.orphaned`` AND emits a ``relation[X]``
    # removal in its old RelationGroup's changes. Acting on the latter
    # would extract the ConnectionUsage and contradict the "not removed
    # automatically" notice surfaced alongside the orphan list.
    # SpecRelations that *moved* between groups stay in
    # ``Model.spec_relations`` of incoming IR and never appear in
    # ``orphaned``, so their ``relation[X]`` removal is left intact and
    # the apply pass extracts + reinserts under the new group.
    _strip_orphan_relation_removals(delta)

    # Build the BuildContext using the same setup as ``_fresh_sysml``, but
    # populate ``refs`` by scanning the workspace for reqif tags rather
    # than tracking them as we go — the delta-time equivalent of the
    # incremental ``ctx.refs[…] = …`` writes that happen during a fresh
    # import.
    sysml_metadata_defs = load_sysml_metadata_defs(sysml_model)
    build_ctx = BuildContext(
        meta_tags=sysml_metadata_defs[0],
        meta_prefixes=sysml_metadata_defs[1],
        scalar_map=build_scalar_type_map(sysml_model),
    )
    build_ctx.refs.update(build_reqif_id_index(sysml_model, sysml_metadata_defs[0]))
    # ``definition_to_usage_map`` is populated incrementally by
    # ``_write_hierarchy_node`` during fresh import. For delta we
    # rebuild it from the existing workspace so ``create_spec_relations``
    # (called by ``create_relation_groups`` for added groups) can walk
    # back from a SpecObject definition to a representative hierarchy
    # usage when assembling the connection-end feature chain.
    _populate_definition_to_usage_map(build_ctx)

    # Resolve the five top-level ReqIF packages so ``create_*`` writers
    # have somewhere to put added elements. Any that the user deleted
    # (a valid action when the package had emptied out) are recreated
    # in standalone documents and tracked in ``created_pkgs`` so we can
    # pprint them to disk after the rewrite pass — the rewrite loop
    # only sees packages already in the loaded model.
    pkgs, created_pkgs = _resolve_top_level_packages(
        sysml_model, sysml_metadata_defs[2]
    )

    # Each per-collection loop handles the ``added`` and ``changed``
    # statuses for its category. Order matches dependency order — enum
    # DatatypeDefs are referenced by SpecType AttrDefs, SpecTypes by
    # SpecObjects/Specifications/RelationGroups, SpecObjects by
    # Specifications and SpecRelations, Specifications by RelationGroups,
    # RelationGroups own newly-added SpecRelations. Scalar (non-enum)
    # DatatypeDef adds are no-ops at the top level: they have no
    # standalone SysMLv2 element and materialize as ``@reqif_*`` marker
    # tags only when an AttributeDef referencing them is created.

    for dt_id, element_delta in delta.datatype_defs.items():
        new_dt = new_ir.datatype_defs[dt_id]
        if element_delta.status == "added":
            if ir.kind_of(new_dt, ir.EnumProps):
                create_enum_defs(pkgs[ENUMS_PKG], {dt_id: new_dt}, build_ctx)
            continue
        if element_delta.status != "changed":
            continue
        if ir.kind_of(new_dt, ir.EnumProps):
            elem = build_ctx.refs.get(dt_id)
            if elem is None:
                raise ValueError(
                    f"DatatypeDef {dt_id!r} has changes in the IR but is not "
                    f"present in the SysML workspace"
                )
            assert isinstance(elem, _syside.EnumerationDefinition), (
                f"expected EnumerationDefinition for enum DatatypeDef "
                f"{dt_id!r}, got {type(elem).__name__}"
            )
            update_enum_def(elem, element_delta, new_dt, build_ctx)
        else:
            # Scalar datatypes have no top-level element; the writer
            # walks the model itself and updates every matching tag.
            update_scalar_datatype_def(sysml_model, element_delta, new_dt, build_ctx)

    for st_id, element_delta in delta.spec_types.items():
        if element_delta.status == "added":
            create_spec_types(
                pkgs[TYPES_PKG], {st_id: new_ir.spec_types[st_id]}, build_ctx
            )
            continue
        if element_delta.status != "changed":
            continue
        elem = build_ctx.refs.get(st_id)
        if elem is None:
            raise ValueError(
                f"SpecType {st_id!r} has changes in the IR but is not "
                f"present in the SysML workspace"
            )
        assert isinstance(elem, _syside.Definition), (
            f"expected Definition for SpecType {st_id!r}, got {type(elem).__name__}"
        )
        update_spec_type(elem, element_delta, new_ir.spec_types[st_id], build_ctx)

    for so_id, element_delta in delta.spec_objects.items():
        if element_delta.status == "added":
            create_spec_objects(
                pkgs[OBJECTS_PKG], {so_id: new_ir.spec_objects[so_id]}, build_ctx
            )
            continue
        if element_delta.status != "changed":
            continue
        elem = build_ctx.refs.get(so_id)
        if elem is None:
            raise ValueError(
                f"SpecObject {so_id!r} has changes in the IR but is not "
                f"present in the SysML workspace"
            )
        assert isinstance(elem, _syside.RequirementDefinition), (
            f"expected RequirementDefinition for SpecObject {so_id!r}, "
            f"got {type(elem).__name__}"
        )
        update_spec_object(elem, element_delta, new_ir.spec_objects[so_id], build_ctx)

    for spec_id, element_delta in delta.specifications.items():
        if element_delta.status == "added":
            create_specifications(
                pkgs[SPECS_PKG],
                {spec_id: new_ir.specifications[spec_id]},
                build_ctx,
            )
            continue
        if element_delta.status != "changed":
            continue
        elem = build_ctx.refs.get(spec_id)
        if elem is None:
            raise ValueError(
                f"Specification {spec_id!r} has changes in the IR but is not "
                f"present in the SysML workspace"
            )
        assert isinstance(elem, _syside.RequirementDefinition), (
            f"expected RequirementDefinition for Specification {spec_id!r}, "
            f"got {type(elem).__name__}"
        )
        update_specification(
            elem, element_delta, new_ir.specifications[spec_id], build_ctx
        )

    # RelationGroups before SpecRelations: ``create_relation_groups``
    # eagerly creates every contained ``SpecRelation`` (registering them
    # in ``ctx.refs``), so when we walk ``delta.spec_relations`` below
    # the entries that came in via a new group are already materialized.
    for group_id, element_delta in delta.relation_groups.items():
        if element_delta.status == "added":
            create_relation_groups(
                pkgs[RELATIONS_PKG],
                {group_id: new_ir.relation_groups[group_id]},
                build_ctx,
            )
            continue
        if element_delta.status != "changed":
            continue
        elem = build_ctx.refs.get(group_id)
        if elem is None:
            raise ValueError(
                f"RelationGroup {group_id!r} has changes in the IR but is not "
                f"present in the SysML workspace"
            )
        assert isinstance(elem, _syside.OccurrenceDefinition), (
            f"expected OccurrenceDefinition for RelationGroup {group_id!r}, "
            f"got {type(elem).__name__}"
        )
        update_relation_group(
            elem, element_delta, new_ir.relation_groups[group_id], build_ctx
        )

    for rel_id, element_delta in delta.spec_relations.items():
        if element_delta.status == "added":
            # New relations under either a brand-new group (written by
            # ``create_relation_groups``) or an existing one (written by
            # ``update_relation_group``'s ``relation[X]`` add handler)
            # are already registered by the time we get here. If we
            # still don't see it the IR breaks the invariant that every
            # SpecRelation is owned by exactly one RelationGroup.
            if rel_id in build_ctx.refs:
                continue
            raise ValueError(
                f"SpecRelation {rel_id!r} marked as added but is not "
                f"contained by any RelationGroup in the new IR"
            )
        if element_delta.status != "changed":
            continue
        elem = build_ctx.refs.get(rel_id)
        if elem is None:
            raise ValueError(
                f"SpecRelation {rel_id!r} has changes in the IR but is not "
                f"present in the SysML workspace"
            )
        assert isinstance(elem, _syside.ConnectionUsage), (
            f"expected ConnectionUsage for SpecRelation {rel_id!r}, "
            f"got {type(elem).__name__}"
        )
        update_spec_relation(
            elem, element_delta, new_ir.spec_relations[rel_id], build_ctx
        )

    # Orphans (in the workspace but no longer in the incoming ReqIF) are
    # deliberately left in place. ``DeltaReport.summary()`` already lists
    # them above; the explicit follow-up notice below makes the
    # "won't-be-deleted" stance unambiguous so the user can decide
    # whether to remove them by hand.
    if delta.orphaned:
        print(file=sys.stderr)
        print(
            "The above orphaned elements are NOT removed automatically. "
            "Review and delete manually if no longer needed.",
            file=sys.stderr,
        )

    # Renames and other element-level edits can ripple into other workspace
    # documents via cross-file textual references (e.g. ``:> Foo`` resolves
    # through the model graph and renders with the current declared name
    # at print time). Without a built-in reverse-index from element to
    # referrers we can't pinpoint which other files need rewriting, so
    # reprint every workspace document. Library packages (the user's
    # ``SysideReqIF.sysml`` and the SysMLv2 stdlib) are excluded — they're
    # canonical: ``SysideReqIF.sysml`` is created from a hardcoded string
    # in ``_cmd_init`` rather than via pprint, and would diverge if
    # reformatted, while the stdlib lives outside the user's workspace.
    # ``rewrite_document`` short-circuits on byte-for-byte equality so
    # files that didn't actually change keep their mtime.
    printer = make_printer(root)
    seen_urls: set[_syside.Url] = set()
    for pkg in sysml_model.nodes(_syside.Package):
        if isinstance(pkg, _syside.LibraryPackage):
            continue
        url = pkg.document.url
        if url in seen_urls:
            continue
        seen_urls.add(url)
        rewrite_document(sysml_model, url, printer)

    # Newly-recreated top-level packages live in standalone documents
    # not registered with ``sysml_model``, so the rewrite loop above
    # skipped them. Write each to disk under its conventional filename,
    # mirroring the final write step of ``_fresh_sysml``.
    for name, pkg in created_pkgs.items():
        out_path = root / f"{name}.sysml"
        with out_path.open("w") as f:
            f.write(_syside.pprint(pkg, printer=printer))


def _resolve_top_level_packages(
    sysml_model: _syside.Model,
    lib: _syside.LibraryPackage,
) -> tuple[dict[str, _syside.Package], dict[str, _syside.Package]]:
    """
    Resolve the workspace's five top-level ReqIF packages keyed by name.

    Looks up each ``_PKG_SPECS`` entry by ``Package.name``. Recreates any
    that are missing — deleting an empty package (e.g. after moving every
    SpecObject out of ``ReqIF_Import_Objects``) is a valid user action,
    so reconstructing them is preferable to demanding a fresh re-import.
    Recreated packages get the same lib + dependency private imports that
    :func:`_fresh_sysml` wires up.

    Returns ``(pkgs, created)``: ``pkgs`` is the full mapping, ``created``
    is the subset that didn't exist on entry. Caller uses ``created`` to
    pprint those packages directly to disk — the rewrite loop iterates
    ``sysml_model.nodes(Package)``, which doesn't see standalone
    documents produced by :func:`create_top_level_package`.
    """
    target_names = {spec.name for spec in _PKG_SPECS}
    by_name: dict[str, _syside.Package] = {}
    for pkg in sysml_model.nodes(_syside.Package):
        if isinstance(pkg, _syside.LibraryPackage):
            continue
        if pkg.name in target_names and pkg.name not in by_name:
            by_name[pkg.name] = pkg

    pkgs: dict[str, _syside.Package] = {}
    created: dict[str, _syside.Package] = {}
    for spec in _PKG_SPECS:
        existing = by_name.get(spec.name)
        if existing is not None:
            pkgs[spec.name] = existing
        else:
            new_pkg = create_top_level_package(sysml_model, name=spec.name)
            pkgs[spec.name] = new_pkg
            created[spec.name] = new_pkg

    for spec in _PKG_SPECS:
        if spec.name not in created:
            continue
        pkg = created[spec.name]
        ensure_private_import(pkg, lib)
        for dep_name in spec.deps:
            ensure_private_import(pkg, pkgs[dep_name])

    return pkgs, created


def _strip_orphan_relation_removals(delta: ir.DeltaReport) -> None:
    """
    Drop ``relation[X]`` removals from each ``RelationGroup`` ElementDelta
    when ``X`` is also listed as an orphan top-level SpecRelation.

    See the call site in :func:`_delta_sysml` for the policy rationale.
    Reuses :func:`filter_changes_in_place` for the kept-list rebuild
    and the demote-to-``"unchanged"`` rule shared with the
    unsupported-op skip filter.
    """
    orphan_rel_ids = {o.id for o in delta.orphaned if o.kind == "spec_relation"}
    if not orphan_rel_ids:
        return

    def _keep(_delta: ir.ElementDelta, change: ir.FieldChange) -> bool:
        if change.new is not None:
            return True
        field = change.field
        if not (field.startswith("relation[") and field.endswith("]")):
            return True
        return field[len("relation[") : -1] not in orphan_rel_ids

    filter_changes_in_place(delta.relation_groups, _keep)


def _populate_definition_to_usage_map(ctx: BuildContext) -> None:
    """
    Rebuild ``ctx.definition_to_usage_map`` from existing hierarchy
    ``RequirementUsage`` elements already indexed in ``ctx.refs``.

    During fresh import, :func:`_write_hierarchy_node` populates this
    map incrementally with the first usage written for each SpecObject
    Definition; the map is then consumed by ``create_spec_relations``
    when assembling connection-end feature chains. ``build_reqif_id_index``
    walks ``model.nodes`` in declaration order, so iterating its result
    here and applying ``setdefault`` preserves the same first-seen
    invariant for the delta path.
    """
    for elem in ctx.refs.values():
        if not isinstance(elem, _syside.RequirementUsage):
            continue
        for typing in iter_heritage_rels_of_type(elem, _syside.FeatureTyping):
            target = typing.first_target
            if isinstance(target, _syside.RequirementDefinition):
                ctx.definition_to_usage_map.setdefault(target, elem)
                break
