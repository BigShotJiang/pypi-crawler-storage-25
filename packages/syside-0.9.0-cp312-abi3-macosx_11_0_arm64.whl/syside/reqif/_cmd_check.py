"""``syside reqif check`` subcommand. Runs validation checks on ReqIF files or SysMLv2 models."""

import sys
import tempfile
from collections import Counter
from pathlib import Path

import _syside

import syside.reqif._ir_model as ir
from syside.reqif._cli import CheckReqifOptions, CheckSysmlOptions
from syside.reqif._reqif_loading import load_and_parse_reqif_to_ir
from syside.reqif._config import LIBRARY_PKG
from syside.reqif._cmd_lock import _find_unlocked_elements
from syside.reqif._sysml_file_loading import load_workspace_model
from syside.reqif._sysml_metadata import (
    RESERVED_METADATA_NAMES,
    load_sysml_metadata_defs,
    reqif_tag_metadata_elems,
)
from syside.reqif._sysml_utils import (
    indicate_problem_at,
    iter_heritage_rels_of_type,
)


def validate_ir_model(model: ir.Model) -> None:
    """
    Run every ReqIF-IR invariant required for a round-trippable
    ReqIF <-> SysMLv2 conversion against ``model``.

    Single source of truth for IR-level validation. Call sites:

    - ``_cmd_check.py::run_reqif`` (CLI ``syside reqif check reqif``)
    - ``_cmd_import.py::_fresh_sysml`` (fresh-import path of ``syside reqif import``)
    - ``_cmd_import.py::_delta_sysml`` (delta-import path of ``syside reqif import``)

    Asserted invariants:

    - Every cross-element reference (``type_ref``, ``source_ref``,
      ``target_ref``, ``spec_object_ref``, ``datatype_def``) resolves to an
      entry in the matching top-level model collection.
    - At least one Relation Group exists when any Spec Relation is present.
    - Every Spec Relation is owned by exactly one Relation Group, with no
      dangling references and no orphans.
    - Spec Relation endpoints live in the Specifications referenced by their
      enclosing Relation Group.
    - Each Spec Object belongs to at most one Specification.
    - The Spec Hierarchy contains no cycles (no Spec Object nested under
      itself).
    - No Spec Object is the parent of nested hierarchy nodes in more than
      one position (would collide with indexed-name siblings under one
      RequirementDefinition).
    - Enum values within a Datatype Def, and Attribute Defs within a Spec
      Type, have unique names.
    - No two Spec Relations within the same Relation Group share a name.
    - No element name shadows a reserved SysMLv2 metadata name.
    - No Spec Type carries a free-form Attribute Def whose name collides
      with the doc-element emitted by a sibling magic ``ReqIF.Text`` /
      ``ReqIF.Description`` Attribute Def.
    - Every Datatype Def is referenced by at least one Attribute Def.
      Warning only — unreferenced Datatype Defs do not survive the
      SysMLv2 round-trip (the SysML embedding has no carrier for them).
    - No enum Datatype Def shares its name with an Attribute Def it types.
    - No Spec Object shares its name with an enum Datatype Def
      (would shadow the enum import inside ``ReqIF_Import_Objects``).
    - No Specification shares its name with an enum Datatype Def
      (would resolve ambiguously inside ``ReqIF_Import_Relations``).
    - No Relation Group or Spec Relation shares its name with a Specification
      (would shadow the Specification import inside ``ReqIF_Import_Relations``).

    Raises ``ValueError`` on the first failed check.
    """
    _check_all_refs_resolve(model)
    _check_spec_relation_and_relation_group_existence(model)
    _check_spec_relation_ownership(model)
    _check_spec_relation_belong_to_referenced_specifications(model)
    _check_spec_object_belongs_to_only_one_specification(model)
    _check_no_circles_in_spec_hierarchy(model)
    _check_spec_object_appears_as_hierarchy_parent_at_most_once(model)
    _check_no_duplicate_enum_value_names(model)
    _check_no_duplicate_attribute_def_names(model)
    _check_no_duplicate_spec_relation_names_in_relation_group(model)
    _check_sysml_metadata_names_not_shadowed(model)
    _check_attribute_def_does_not_shadow_magic_doc_name(model)
    _check_that_all_datatypedefs_are_referenced(model)
    _check_enum_def_does_not_shadow_attribute_def(model)
    _check_spec_object_does_not_shadow_enum_def(model)
    _check_specification_does_not_shadow_enum_def(model)
    _check_relation_group_does_not_shadow_specification(model)
    _check_spec_relation_does_not_shadow_specification(model)


def run_reqif(opts: CheckReqifOptions) -> int:
    """
    Run the ReqIF-side validation suite against ``opts.file``.

    Loads the file into the intermediate representation runs the
    same validations as when doing ``run_import``.

    Returns ``0`` on success; raises ``ValueError`` on the first failed check.
    """
    # ReqIFz loading extracts non-`.reqif` archive members into the
    # ``attachments_dir`` argument. ``check`` discards the IR right after
    # validating, so route extraction through a tempdir to keep cwd clean
    # and let validation succeed in read-only directories.
    with tempfile.TemporaryDirectory(prefix="syside-check-reqif-") as tmp:
        ir_model_from_reqif = load_and_parse_reqif_to_ir(opts.file, Path(tmp))

    validate_ir_model(ir_model_from_reqif)

    return 0


def validate_sysml(model: _syside.Model) -> None:
    """
    Run every SysMLv2-side invariant required for a round-trippable
    ReqIF <-> SysMLv2 conversion against ``model``.

    Single source of truth for SysML-level validation. Call sites:

    - ``_cmd_check.py::run_sysml`` (CLI ``syside reqif check sysml``)
    - ``_cmd_import.py::run`` (CLI ``syside reqif import``)
    - ``_cmd_export.py::run`` (CLI ``syside reqif export``)

    Asserted invariants:

    - Each ``.sysml`` document has at most one top-level ``Package`` /
      ``LibraryPackage``. Incremental ReqIF import overwrites the document
      with one top-level package, so any extras would be silently dropped.
    - Every ReqIF tag is "locked" — carries a stable identifier and a
      ``last_change`` value. Unlocked tags lose their identity across
      ReqIF round-trips.
    - No ``@reqif`` element specialises another ``@reqif`` element via
      Subclassification, except a non-prefix instance specialising a
      ``#reqif_*_type`` prefix-tagged definition.

    Raises ``ValueError`` on the first failed check.
    """
    _check_all_files_have_one_top_level_package(model)
    _check_all_reqif_tags_are_locked(model)
    _check_no_reqif_def_specialises_reqif_def(model)


def run_sysml(opts: CheckSysmlOptions) -> int:
    """
    Run the SysMLv2-side validation suite against the current workspace.

    Loads every ``.sysml`` document under the current working directory and
    runs the same validations as when doing ``run_export``.

    Returns ``0`` on success; raises ``ValueError`` on the first failed check.
    """
    model = load_workspace_model("checking")

    validate_sysml(model)

    return 0


def _check_all_refs_resolve(model: ir.Model) -> None:
    """
    Check that every cross-element reference resolves to an entry in the
    matching top-level model collection.

    Validates the references handled by :func:`_check_ref` in the IR diff —
    ``type_ref``, ``source_ref``, ``target_ref``, ``spec_object_ref``, and
    ``datatype_def`` — against ``model.datatype_defs`` / ``spec_types`` /
    ``spec_objects`` / ``specifications``. The XML parser already rejects
    unresolved IDREFs at parse time, but IR built or merged in memory can
    still produce dangling references that would otherwise crash conversion
    later or, worse, surface as a misleading "type changed" entry in a delta
    report when one side renamed an id the other side never registered.
    """
    broken: list[str] = []

    for st in model.spec_types.values():
        for attr_def in st.attribute_defs.values():
            dt_id = attr_def.props.datatype_def.id
            if dt_id not in model.datatype_defs:
                broken.append(
                    f"SpecType {st.id!r} AttributeDef {attr_def.id!r} "
                    f"datatype_def -> DatatypeDef {dt_id!r}"
                )

    for so in model.spec_objects.values():
        if so.type_ref.id not in model.spec_types:
            broken.append(
                f"SpecObject {so.id!r} type_ref -> SpecType {so.type_ref.id!r}"
            )

    # Cycle protection by object identity: a malformed hierarchy could nest
    # itself, and ``_check_no_circles_in_spec_hierarchy`` runs later.
    visited: set[int] = set()

    def _walk_hierarchy(node: ir.SpecHierarchyNode) -> None:
        if id(node) in visited:
            return
        visited.add(id(node))
        if node.spec_object_ref.id not in model.spec_objects:
            broken.append(
                f"SpecHierarchyNode {node.id!r} spec_object_ref -> "
                f"SpecObject {node.spec_object_ref.id!r}"
            )
        for child in node.children.values():
            _walk_hierarchy(child)

    for spec in model.specifications.values():
        if spec.type_ref.id not in model.spec_types:
            broken.append(
                f"Specification {spec.id!r} type_ref -> SpecType {spec.type_ref.id!r}"
            )
        for node in spec.children.values():
            _walk_hierarchy(node)

    for rel in model.spec_relations.values():
        if rel.source_ref.id not in model.spec_objects:
            broken.append(
                f"SpecRelation {rel.id!r} source_ref -> "
                f"SpecObject {rel.source_ref.id!r}"
            )
        if rel.target_ref.id not in model.spec_objects:
            broken.append(
                f"SpecRelation {rel.id!r} target_ref -> "
                f"SpecObject {rel.target_ref.id!r}"
            )
        if rel.type_ref.id not in model.spec_types:
            broken.append(
                f"SpecRelation {rel.id!r} type_ref -> SpecType {rel.type_ref.id!r}"
            )

    for group in model.relation_groups.values():
        if group.source_ref.id not in model.specifications:
            broken.append(
                f"RelationGroup {group.id!r} source_ref -> "
                f"Specification {group.source_ref.id!r}"
            )
        if group.target_ref.id not in model.specifications:
            broken.append(
                f"RelationGroup {group.id!r} target_ref -> "
                f"Specification {group.target_ref.id!r}"
            )
        if group.type_ref.id not in model.spec_types:
            broken.append(
                f"RelationGroup {group.id!r} type_ref -> SpecType {group.type_ref.id!r}"
            )

    if broken:
        details = "; ".join(broken)
        raise ValueError(
            "All cross-element references must resolve to top-level model entries.\n"
            f"Broken references: {details}"
        )


def _check_spec_relation_and_relation_group_existence(model: ir.Model) -> None:
    """
    Check that ReqIF has RelationGroups if at least one SpecRelation is present.

    This is needed as in SysMLv2, SpecRelations are children of RelationGroups. Thus,
    if ReqIF has at least one SpecRelation, it must have at least one RelationGroup
    that could be the parent of the SpecRelation.
    """
    if len(model.spec_relations) > 0 and len(model.relation_groups) == 0:
        raise ValueError(
            "A model with Spec Relations must have at least one Relation Group.\n"
            f"This model has: {len(model.spec_relations)} Spec Relations, but no Relation Groups"
        )


def _check_spec_relation_ownership(model: ir.Model) -> None:
    """
    Check that each Spec Relation belongs to exactly one Relation Group.

    Checks three invariants:
    - Every Spec Relation referenced by a Relation Group is present in the model.
    - No Spec Relation is referenced by more than one Relation Group.
    - Every Spec Relation in the model is owned by some Relation Group
      (no "orphans" that would have no SysMLv2 namespace to live in).
    """
    unowned: set[str] = set(model.spec_relations.keys())
    seen_in_group: dict[str, str] = {}  # rel_id -> first group.id that owns it

    for group in model.relation_groups.values():
        for ref_id in group.relations.keys():
            if ref_id not in model.spec_relations:
                raise ValueError(
                    f"Relation Group {group.id} references Spec Relation "
                    f"{ref_id}, which is not in the model.",
                )
            if ref_id in seen_in_group:
                raise ValueError(
                    f"Spec Relation {ref_id} was found in multiple Relation "
                    f"Groups: {seen_in_group[ref_id]} and {group.id}.",
                )
            seen_in_group[ref_id] = group.id
            unowned.discard(ref_id)

    if unowned:
        raise ValueError(
            "Each Spec Relation must belong to a Relation Group.\n"
            f"These Spec Relations have no Relation Group: {sorted(unowned)}"
        )


def _check_spec_relation_belong_to_referenced_specifications(model: ir.Model) -> None:
    """
    Check that SpecObjects referenced by SpecRelations in a RelationGroup exist in
    the referenced Specifications.
    """
    specifications = _spec_to_object_ids(model)

    # For each RelationGroup, iterate over its SpecRelations,
    wrong_spec_relations: list[str] = []
    for group in model.relation_groups.values():
        for ref_id, role in (
            (group.source_ref.id, "source"),
            (group.target_ref.id, "target"),
        ):
            if ref_id not in specifications:
                raise ValueError(
                    f"Relation Group {group.id} references {role} Specification "
                    f"{ref_id}, which is not in the model."
                )
        # Build a fresh combined list per group; otherwise extending the cached
        # source list would leak target ids into later groups that share it.
        combined = [
            *specifications[group.source_ref.id],
            *specifications[group.target_ref.id],
        ]
        for relation in group.relations.values():
            # Check if referenced SpecObjects in SpecRelation belong to either
            # target or source Specification
            if (
                relation.source_ref.id not in combined
                or relation.target_ref.id not in combined
            ):
                wrong_spec_relations.append(relation.id)

    if wrong_spec_relations:
        raise ValueError(
            "All Spec Relations in a Relation Group must only reference those "
            f"Spec Objects, that belong to the Specifications referenced in the "
            f"Relation Group.\n"
            f"Spec Relations with wrong Spec Objects: {sorted(wrong_spec_relations)}"
        )


def _flatten_spec_hierarchy_children(
    node: ir.SpecHierarchyNode, list_to_append: list[str]
) -> None:
    list_to_append.append(node.spec_object_ref.id)
    for child in node.children.values():
        _flatten_spec_hierarchy_children(child, list_to_append)


def _spec_to_object_ids(model: ir.Model) -> dict[str, list[str]]:
    """Map each Specification id to the flat list of SpecObject ids in its hierarchy."""
    result: dict[str, list[str]] = {}
    for spec in model.specifications.values():
        object_list: list[str] = []
        for child in spec.children.values():
            _flatten_spec_hierarchy_children(child, object_list)
        result[spec.id] = object_list
    return result


def _check_spec_object_belongs_to_only_one_specification(model: ir.Model) -> None:
    """
    Check that each Spec Object belongs to one or zero Specifications.

    A Spec Object that appears under two different Specifications has two requirement
    usages typed by the same definition, which may break assumptions when resolving
    definitions to usages in ReqIF import/export and Syside table views.
    """
    specifications = _spec_to_object_ids(model)

    # Invert: for each Spec Object id, the set of Specifications it appears in.
    referenced_in: dict[str, set[str]] = {}
    for spec_id, obj_ids in specifications.items():
        for obj_id in obj_ids:
            referenced_in.setdefault(obj_id, set()).add(spec_id)

    duplicated: dict[str, list[str]] = {}
    for obj_id in model.spec_objects:
        owners = referenced_in.get(obj_id, set())
        if len(owners) > 1:
            duplicated[obj_id] = sorted(owners)

    if duplicated:
        details = "; ".join(
            f"{obj_id} in {spec_ids}" for obj_id, spec_ids in sorted(duplicated.items())
        )
        raise ValueError(
            "Each Spec Object must belong to at most one Specification.\n"
            f"Spec Objects appearing in multiple Specifications: {details}"
        )


def _check_no_circles_in_spec_hierarchy(model: ir.Model) -> None:
    """
    Check that no Spec Object is nested under itself within a Specification.

    SysMLv2 maps each Spec Object to a ``requirement def`` and each Spec
    Hierarchy node to a ``requirement`` usage inside its enclosing ``def``.
    A Spec Object that nests itself would translate to a definition that
    references itself in its own body — non-sensical and not round-trippable.
    """
    cycles: list[tuple[str, str]] = []  # (spec_id, offending_object_id)

    def _walk(node: ir.SpecHierarchyNode, ancestors: set[str], spec_id: str) -> None:
        obj_id = node.spec_object_ref.id
        if obj_id in ancestors:
            cycles.append((spec_id, obj_id))
            # Don't descend further; descendants would re-report the same cycle.
            return
        ancestors.add(obj_id)
        for child in node.children.values():
            _walk(child, ancestors, spec_id)
        ancestors.discard(obj_id)

    for spec in model.specifications.values():
        for node in spec.children.values():
            _walk(node, set(), spec.id)

    if cycles:
        details = "; ".join(
            f"Specification {sid!r} contains Spec Object {oid!r} as its own descendant"
            for sid, oid in cycles
        )
        raise ValueError(
            "Spec Hierarchy must not contain cycles "
            "(a Spec Object nested under itself).\n"
            f"Cycles: {details}"
        )


def _check_spec_object_appears_as_hierarchy_parent_at_most_once(
    model: ir.Model,
) -> None:
    """
    Check that no Spec Object is the parent of nested hierarchy nodes in
    more than one position across the whole model.

    The IR -> SysMLv2 converter emits a Spec Hierarchy node's children as
    members of the parent Spec Object's RequirementDefinition, with indexed
    names ``'1'``, ``'2'``, .... If the same Spec Object is used as a
    hierarchy parent in two different positions, both children-lists become
    siblings under the same RequirementDefinition with colliding indexed
    names — a SysMLv2 ``namespace-distinguishability`` error on reparse.
    Distinct from the cycle check: two siblings ``X -> [Y]`` and
    ``X -> [Z]`` are not a cycle (``X`` isn't its own descendant) but do
    trigger this collision.
    """
    parents_seen: dict[str, str] = {}  # obj_id -> first hierarchy-node id parenting it
    duplicates: list[tuple[str, str, str]] = []  # (obj_id, first_node, dup_node)

    def _walk(node: ir.SpecHierarchyNode) -> None:
        if node.children:
            obj_id = node.spec_object_ref.id
            existing = parents_seen.get(obj_id)
            if existing is not None:
                duplicates.append((obj_id, existing, node.id))
            else:
                parents_seen[obj_id] = node.id
        for child in node.children.values():
            _walk(child)

    for spec in model.specifications.values():
        for node in spec.children.values():
            _walk(node)

    if duplicates:
        details = "; ".join(
            f"Spec Object {oid!r} parents hierarchy nodes {first!r} and {dup!r}"
            for oid, first, dup in duplicates
        )
        raise ValueError(
            "Each Spec Object can be the parent of nested hierarchy nodes "
            "in at most one position (otherwise SysMLv2 emits colliding "
            "indexed-name siblings under one RequirementDefinition).\n"
            f"Offenders: {details}"
        )


def _check_no_duplicate_enum_value_names(model: ir.Model) -> None:
    """
    Check that EnumValues within an enum DatatypeDef do not have duplicate names.

    This would cause name shadowing errors in SysMLv2.
    """
    for dt in model.datatype_defs.values():
        if not ir.kind_of(dt, ir.EnumProps):
            continue
        counts = Counter(v.name for v in dt.props.values.values())
        duplicates = sorted(name for name, count in counts.items() if count > 1)
        if duplicates:
            raise ValueError(
                f"Enum {dt.id!r} has duplicate Enum Value names: {duplicates}"
            )


def _check_no_duplicate_attribute_def_names(model: ir.Model) -> None:
    """
    Check that AttributeDefs within a SpecType do not have duplicate names.

    This would cause name shadowing errors in SysMLv2.
    """
    for st in model.spec_types.values():
        counts = Counter(a.name for a in st.attribute_defs.values())
        duplicates = sorted(name for name, count in counts.items() if count > 1)
        if duplicates:
            raise ValueError(
                f"Spec Type {st.id!r} has duplicate Attribute Def names: {duplicates}"
            )


# Magic ReqIF attribute names that the IR -> SysMLv2 emitter short-circuits on
# the *value* path: instead of writing an AttributeUsage redefinition under the
# parent (SpecObject / SpecRelation / RelationGroup / Specification), the
# emitter writes a ``doc <stem>`` block with the unprefixed stem as its name.
# A free-form Attribute Def on the same Spec Type whose name equals that stem
# would shadow on reparse — the SpecObject's ``doc Text`` collides with the
# inherited ``Text`` attribute. Keep these in lockstep with the routing in
# ``_attribute_values_sysml.py::write_attribute_usage``.
_MAGIC_DOC_NAME_BY_ATTR_DEF_NAME: dict[str, str] = {
    "ReqIF.Text": "Text",
    "ReqIF.Description": "Description",
}


def _check_attribute_def_does_not_shadow_magic_doc_name(model: ir.Model) -> None:
    """
    Check that no Spec Type carries both a magic ``ReqIF.Text`` /
    ``ReqIF.Description`` Attribute Def and a free-form Attribute Def whose
    name is the unprefixed stem (``Text`` / ``Description``).

    The IR -> SysMLv2 emitter short-circuits ``ReqIF.Text`` /
    ``ReqIF.Description`` *values* on a SpecObject (or any other element that
    carries Attribute Values) into a ``doc Text`` / ``doc Description`` block
    on the parent. If the same Spec Type also defines a free-form
    ``Text`` / ``Description`` attribute, the SpecObject's emitted ``doc``
    shadows the inherited free-form attribute and reparse fails with a
    SysMLv2 ``namespace-distinguishability`` error.
    """
    clashes: list[tuple[str, str, str]] = []  # (spec_type_id, magic_name, plain_name)
    for st in model.spec_types.values():
        names_to_ids = {a.name: a.id for a in st.attribute_defs.values()}
        for magic_name, plain_name in _MAGIC_DOC_NAME_BY_ATTR_DEF_NAME.items():
            if magic_name in names_to_ids and plain_name in names_to_ids:
                clashes.append((st.id, magic_name, plain_name))

    if clashes:
        details = "; ".join(
            f"Spec Type {sid!r} has both {magic!r} and free-form {plain!r}"
            for sid, magic, plain in clashes
        )
        raise ValueError(
            "A Spec Type must not carry a free-form Attribute Def whose name "
            "collides with the doc-element emitted by a sibling magic "
            "ReqIF.Text / ReqIF.Description Attribute Def (the emitted "
            "`doc Text` / `doc Description` would shadow the inherited "
            "free-form attribute on reparse).\n"
            f"Clashes: {details}"
        )


def _check_sysml_metadata_names_not_shadowed(model: ir.Model) -> None:
    """
    Check that no element in the IR has a name that shadows a SysMLv2 metadata name.

    This would cause name shadowing errors in SysMLv2.
    """
    # Pair every name-bearing IR collection with a label so a single
    # comprehension can flatten them into (kind, id, name) tuples — one place
    # to add a new IR collection instead of a per-collection for-loop.
    sources = (
        ("DatatypeDef", model.datatype_defs.values()),
        (
            "EnumValue",
            (
                v
                for dt in model.datatype_defs.values()
                if ir.kind_of(dt, ir.EnumProps)
                for v in dt.props.values.values()
            ),
        ),
        ("SpecType", model.spec_types.values()),
        (
            "AttributeDef",
            (a for st in model.spec_types.values() for a in st.attribute_defs.values()),
        ),
        ("SpecObject", model.spec_objects.values()),
        ("Specification", model.specifications.values()),
        ("SpecRelation", model.spec_relations.values()),
        ("RelationGroup", model.relation_groups.values()),
    )

    violations = [
        (kind, e.id, e.name)
        for kind, items in sources
        for e in items
        if e.name in RESERVED_METADATA_NAMES
    ]
    if violations:
        details = "; ".join(f'{k} {i!r} named "{n}"' for k, i, n in violations)
        raise ValueError(
            "Element names must not shadow reserved SysideReqIF metadata names.\n"
            f"Shadowing names: {details}"
        )


def _check_spec_object_does_not_shadow_enum_def(model: ir.Model) -> None:
    """
    Check that no Spec Object shares a name with an enum Datatype Def.

    ``ReqIF_Import_Objects`` imports ``ReqIF_Import_Enums`` in the emitted
    SysMLv2, so a Spec Object named ``A`` shadows an imported ``A`` enum def
    inside the Objects package. Sibling Spec Objects with enum-attribute
    references like ``A::V`` then bind ``A`` to the local Spec Object (which
    has no ``V`` member) and reparse fails with
    ``reference-error: No Feature named 'V' found.``.
    """
    enum_names: dict[str, str] = {
        dt.name: dt.id
        for dt in model.datatype_defs.values()
        if ir.kind_of(dt, ir.EnumProps)
    }
    clashes: list[tuple[str, str, str]] = []  # (obj_id, name, enum_id)
    for obj in model.spec_objects.values():
        enum_id = enum_names.get(obj.name)
        if enum_id is not None:
            clashes.append((obj.id, obj.name, enum_id))

    if clashes:
        details = "; ".join(
            f"Spec Object {oid!r} named {name!r} clashes with enum Datatype Def {eid!r}"
            for oid, name, eid in clashes
        )
        raise ValueError(
            "Spec Object names must not shadow enum Datatype Def names "
            "(otherwise enum-value references like `A::V` resolve to the "
            "Spec Object instead of the enum def).\n"
            f"Clashes: {details}"
        )


def _check_specification_does_not_shadow_enum_def(model: ir.Model) -> None:
    """
    Check that no Specification shares a name with an enum Datatype Def.

    ``ReqIF_Import_Relations`` imports both ``ReqIF_Import_Enums`` and
    ``ReqIF_Import_Specifications``, so a name shared between an enum def and
    a Specification becomes ambiguous when used as a type inside the
    Relations package (e.g. ``source_specification : B`` could resolve to
    either). When the resolver picks the enum def, feature-chain references
    into the Specification's hierarchy (``source_specification.'1'``) fail
    to resolve.
    """
    enum_names: dict[str, str] = {
        dt.name: dt.id
        for dt in model.datatype_defs.values()
        if ir.kind_of(dt, ir.EnumProps)
    }
    clashes: list[tuple[str, str, str]] = []  # (spec_id, name, enum_id)
    for spec in model.specifications.values():
        enum_id = enum_names.get(spec.name)
        if enum_id is not None:
            clashes.append((spec.id, spec.name, enum_id))

    if clashes:
        details = "; ".join(
            f"Specification {sid!r} named {name!r} clashes with enum "
            f"Datatype Def {eid!r}"
            for sid, name, eid in clashes
        )
        raise ValueError(
            "Specification names must not shadow enum Datatype Def names "
            "(otherwise typings like `source_specification : <Name>` resolve "
            "ambiguously inside ReqIF_Import_Relations).\n"
            f"Clashes: {details}"
        )


def _check_relation_group_does_not_shadow_specification(model: ir.Model) -> None:
    """
    Check that no Relation Group shares a name with any Specification.

    ``ReqIF_Import_Relations`` imports ``ReqIF_Import_Specifications``; a
    Relation Group whose name matches a Specification shadows that import
    inside the Relations package, so ``source_specification : <Name>`` /
    ``target_specification : <Name>`` typings bind to the local
    ``occurrence def <Name>`` (no ``'1'`` / ``'2'`` members) and reparse
    fails with ``reference-error: No Feature named '1' found.``.
    """
    spec_names: dict[str, str] = {s.name: s.id for s in model.specifications.values()}
    clashes: list[tuple[str, str, str]] = []  # (group_id, name, spec_id)
    for group in model.relation_groups.values():
        spec_id = spec_names.get(group.name)
        if spec_id is not None:
            clashes.append((group.id, group.name, spec_id))

    if clashes:
        details = "; ".join(
            f"Relation Group {gid!r} named {name!r} clashes with Specification {sid!r}"
            for gid, name, sid in clashes
        )
        raise ValueError(
            "Relation Group names must not shadow Specification names "
            "(otherwise the local Relation Group shadows the imported "
            "Specification inside ReqIF_Import_Relations, breaking "
            "source_specification / target_specification typings).\n"
            f"Clashes: {details}"
        )


def _check_spec_relation_does_not_shadow_specification(model: ir.Model) -> None:
    """
    Check that no Spec Relation shares a name with any Specification.

    Same shadowing mechanism as
    ``_check_relation_group_does_not_shadow_specification``: the local
    Connection Definition emitted from the Spec Relation shadows the
    imported Specification inside ``ReqIF_Import_Relations`` and breaks
    ``source_specification`` / ``target_specification`` typings on reparse.
    """
    spec_names: dict[str, str] = {s.name: s.id for s in model.specifications.values()}
    clashes: list[tuple[str, str, str]] = []  # (rel_id, name, spec_id)
    for rel in model.spec_relations.values():
        spec_id = spec_names.get(rel.name)
        if spec_id is not None:
            clashes.append((rel.id, rel.name, spec_id))

    if clashes:
        details = "; ".join(
            f"Spec Relation {rid!r} named {name!r} clashes with Specification {sid!r}"
            for rid, name, sid in clashes
        )
        raise ValueError(
            "Spec Relation names must not shadow Specification names "
            "(otherwise the local Spec Relation shadows the imported "
            "Specification inside ReqIF_Import_Relations, breaking "
            "source_specification / target_specification typings).\n"
            f"Clashes: {details}"
        )


def _check_no_duplicate_spec_relation_names_in_relation_group(
    model: ir.Model,
) -> None:
    """
    Check that no two Spec Relations within the same Relation Group share a name.

    Two Spec Relations sharing a name inside one Relation Group emit two
    ``connection <name>`` members of the same OccurrenceDefinition; SysMLv2
    rejects this on reparse with a namespace-distinguishability error.
    """
    for group in model.relation_groups.values():
        counts = Counter(r.name for r in group.relations.values())
        duplicates = sorted(name for name, count in counts.items() if count > 1)
        if duplicates:
            raise ValueError(
                f"Relation Group {group.id!r} has duplicate Spec Relation "
                f"names: {duplicates}"
            )


def _check_that_all_datatypedefs_are_referenced(model: ir.Model) -> None:
    """
    Warn (do not raise) if any Datatype Def is not referenced by any Attribute Def.

    Unreferenced Datatype Defs do not survive a SysMLv2 round-trip: the SysML
    embedding only emits Datatype Defs reached via ``#reqif_*`` annotations on
    Attribute Defs, so a Datatype Def with no incoming reference has no
    carrier on the SysML side and is silently dropped on import.
    """
    referenced_ids = {
        attr.props.datatype_def.id
        for st in model.spec_types.values()
        for attr in st.attribute_defs.values()
    }
    unreferenced = [
        (dt.id, dt.name)
        for dt in model.datatype_defs.values()
        if dt.id not in referenced_ids
    ]
    if unreferenced:
        details = ", ".join(f"{name!r} ({id_})" for id_, name in unreferenced)
        print(
            "Warning: the following Datatype Defs are not referenced by any "
            "Attribute Def and will not be persisted after import/export "
            f"to/from SysMLv2: {details}",
            file=sys.stderr,
        )


def _check_enum_def_does_not_shadow_attribute_def(model: ir.Model) -> None:
    """
    Check that no enum DatatypeDef shares a name with an Attribute Def it types.

    Otherwise SysMLv2 emits ambiguous output like ``attribute Priority typed by
    Priority``, where the attribute and its type cannot be resolved unambiguously.
    Renaming the enum (e.g. ``Priority_enum``) restores unambiguous resolution.
    """
    clashes: list[tuple[str, str, str]] = []  # (spec_type_id, attr_id, shared_name)
    for st in model.spec_types.values():
        for attr in st.attribute_defs.values():
            if not ir.kind_of(attr, ir.EnumAttrDef):
                continue
            if attr.name == attr.props.datatype_def.name:
                clashes.append((st.id, attr.id, attr.name))

    if clashes:
        details = "; ".join(
            f"Spec Type {sid!r} Attribute Def {aid!r} shares its name {name!r} "
            f"with its enum DatatypeDef"
            for sid, aid, name in clashes
        )
        raise ValueError(
            "Enum DatatypeDef names must differ from the Attribute Def they type, "
            "to avoid ambiguous SysMLv2 emission like 'attribute X typed by X'.\n"
            f"Clashes: {details}"
        )


def _check_all_files_have_one_top_level_package(model: _syside.Model) -> None:
    """
    Check that every ``.sysml`` document has at most one top-level package.

    Incremental ReqIF import overwrites the document with one top-level
    package, so any extra top-level packages would be silently dropped.

    Both ``Package`` and ``LibraryPackage`` count toward the limit (the latter
    subclasses the former), so a file mixing one of each still fails.
    """
    violations: list[tuple[str, list[str]]] = []  # (doc_url, package_names)
    for doc in model.all_docs:
        with doc.lock() as locked:
            top_pkgs = [
                child.declared_name or "<unnamed>"
                for child in locked.root_node.children.elements
                if isinstance(child, _syside.Package)
            ]
            if len(top_pkgs) > 1:
                violations.append((str(locked.url), top_pkgs))

    if violations:
        details = "; ".join(f"{url} -> {names}" for url, names in violations)
        raise ValueError(
            "Each .sysml document must have at most one top-level package "
            "(otherwise ReqIF import would drop the extras).\n"
            f"Offenders: {details}"
        )


def _check_all_reqif_tags_are_locked(model: _syside.Model) -> None:
    """
    Check that every ReqIF tag in the workspace is "locked" — carries a
    stable identifier and ``last_change`` value.

    Unlocked tags (missing identifier and/or ``last_change``) lose their
    identity across ReqIF round-trips. Run ``syside reqif lock`` to populate
    fresh UUIDs and timestamps for any elements flagged here.
    """
    # No SysideReqIF library means there can be no reqif tags in the
    # workspace, so there is nothing for this check to validate. Bail
    # before ``load_sysml_metadata_defs`` raises on the missing package.
    if not any(p.name == LIBRARY_PKG for p in model.nodes(_syside.LibraryPackage)):
        return

    tag_defs, _, _ = load_sysml_metadata_defs(model)
    id_field = tag_defs.reqif_tag.identifier_field
    last_change_field = tag_defs.reqif_tag.last_change_field
    tag_metadata_elems = reqif_tag_metadata_elems(tag_defs)

    unlocked = _find_unlocked_elements(
        model, id_field, last_change_field, tag_metadata_elems
    )

    if unlocked:
        details = "; ".join(
            f"{qn} missing {sorted(missing)}" for qn, missing in unlocked.values()
        )
        raise ValueError(
            "All ReqIF tags must be locked (have stable UUIDs and "
            "last_change values). Run `syside reqif lock` to populate them.\n"
            f"Unlocked tags: {details}"
        )


def _check_no_reqif_def_specialises_reqif_def(model: _syside.Model) -> None:
    """
    Check that no ``@reqif`` Definition Subclassifies another ``@reqif``
    Definition unless the target carries a ``#reqif_*_type`` prefix tag and
    the source does not.

    SpecObjectType / SpecificationType / SpecRelationType / RelationGroupType
    each carry a ``#reqif_*_type`` prefix tag (the importer's ground-truth
    "this is a ReqIF type definition" marker), and SpecObject / Specification
    / RelationGroup are non-prefix ``@reqif`` instances that subclassify their
    type counterpart. Any other Subclassification chain between two ``@reqif``
    elements (type :> type, instance :> instance) has no ReqIF analogue and
    would be silently dropped on round-trip. Object-side AttributeUsage
    Redefining the type's AttributeDef is unaffected: that uses Redefinition,
    not Subclassification.
    """
    # No SysideReqIF library means there can be no reqif tags in the
    # workspace, so there is nothing for this check to validate. Bail
    # before ``load_sysml_metadata_defs`` raises on the missing package.
    if not any(p.name == LIBRARY_PKG for p in model.nodes(_syside.LibraryPackage)):
        return

    tag_defs, prefix_defs, _ = load_sysml_metadata_defs(model)
    reqif_tag_md = tag_defs.reqif_tag.metadata_elem
    prefix_mds = frozenset(
        (
            prefix_defs.reqif_spec_object_type_prefix,
            prefix_defs.reqif_specification_type_prefix,
            prefix_defs.reqif_spec_relation_type_prefix,
            prefix_defs.reqif_relation_group_type_prefix,
        )
    )

    reqif_annotated: set[_syside.Element] = set()
    prefix_tagged: set[_syside.Element] = set()
    for usage in model.nodes(_syside.MetadataUsage):
        if usage.about.elements.empty():
            owner = usage.owner
            if owner is None:
                continue
            elements: list[_syside.Element] = [owner]
        else:
            elements = list(usage.about.elements)
        for typing_rel in iter_heritage_rels_of_type(usage, _syside.FeatureTyping):
            target = typing_rel.first_target
            if target == reqif_tag_md:
                reqif_annotated.update(elements)
            elif target in prefix_mds:
                prefix_tagged.update(elements)

    for elt in reqif_annotated:
        if not isinstance(elt, _syside.Definition.STD):
            continue
        elt_is_type_def = elt in prefix_tagged
        for rel in elt.heritage.relationships:
            if not isinstance(rel, _syside.Subclassification.STD):
                continue
            target = rel.general
            if target not in reqif_annotated:
                continue
            target_is_type_def = target in prefix_tagged
            if elt_is_type_def or not target_is_type_def:
                raise ValueError(
                    indicate_problem_at(
                        elt,
                        (
                            "reqif element specialises another reqif element via "
                            "Subclassification; only a non-prefix `@reqif` instance "
                            "may specialise a `#reqif_*_type` prefix-tagged definition"
                        ),
                    )
                )
