from typing import cast

from . import _ir_model as ir

import _syside
from syside.reqif._sysml_utils import (
    BuildContext,
    set_literal_value,
    set_or_update_description,
    set_signed_integer_literal,
)
from syside.reqif._sysml_metadata import (
    MetaReqIFIntegerTag,
    MetaReqIFRealTag,
    MetaReqIFStringTag,
    MetaReqIFDatatypeTag,
    add_reqif_tag,
    find_datatype_marker_tags,
    set_redefined_string,
    set_redefined_value,
)
from syside.reqif._attribute_values_sysml import SCALAR_TYPE_INFO


_OWNER_KIND_LABEL_SCALAR = "ScalarDatatypeDef"

# IR kind enum -> ``ctx.meta_tags`` attribute name and the props field set
# we accept updates to. ``MetaReqIFTag`` (the base class) covers Boolean /
# Date / XHTML which carry no extra props beyond the inherited base
# fields.
_SCALAR_TAG_ATTR: dict[ir.AttrType, str] = {
    ir.AttrType.STRING: "reqif_string_tag",
    ir.AttrType.INTEGER: "reqif_integer_tag",
    ir.AttrType.REAL: "reqif_real_tag",
    ir.AttrType.BOOLEAN: "reqif_boolean_tag",
    ir.AttrType.DATE: "reqif_date_tag",
    ir.AttrType.XHTML: "reqif_xhtml_tag",
}


def _datatype_extra(
    tag: MetaReqIFDatatypeTag,
    dt: ir.DatatypeDef[ir.DatatypeProps],
) -> dict[_syside.AttributeUsage, str | int | float | bool]:
    """
    Build the ``extra`` mapping for a datatype's reqif tag, mirroring the
    datatype-specific fields (``max_length``, ``min``/``max``, ``accuracy``).

    Returns an empty dict for datatypes without extra fields (Boolean, Date, XHTML).
    """
    result: dict[_syside.AttributeUsage, str | int | float | bool] = {}

    # ``DatatypeDef.name`` is the source of truth for LONG-NAME — the parser
    # writes there, and ``__post_init__`` falls back to ``id`` when the
    # ReqIF DESC was missing. ``DatatypeProps.long_name`` /
    # ``DatatypeProps.description`` exist on the dataclass but are never
    # populated, so reading them was the regression.
    result[tag.long_name_field] = dt.name

    if dt.description is not None:
        result[tag.desc_field] = dt.description

    dt_props = dt.props
    if isinstance(dt_props, ir.StrProps):
        assert isinstance(tag, MetaReqIFStringTag)
        result[tag.max_length_field] = dt_props.max_length
    if isinstance(dt_props, ir.IntProps):
        assert isinstance(tag, MetaReqIFIntegerTag)
        result[tag.min_field] = dt_props.min
        result[tag.max_field] = dt_props.max
    if isinstance(dt_props, ir.RealProps):
        assert isinstance(tag, MetaReqIFRealTag)
        result[tag.min_field] = dt_props.min
        result[tag.max_field] = dt_props.max
        result[tag.accuracy_field] = dt_props.accuracy

    return result


def create_attribute_def(
    spectype: _syside.Namespace,
    attr_def: ir.AttributeDef[ir.AttributeDefProps],
    ctx: BuildContext,
) -> str | None:
    """
    Create **new** attributes under a given SysMLv2 SpecType element.

    This function adds ID -> SysMLv2 element references back to BuildContext's ``refs`` dict.

    If the attribute is ``ReqIF.Prefix`` with a string value, its value is returned
    from this function. This is needed on creation time to overcome the fact that
    the full model semantics are not known yet and syside.Compiler cannot be used to
    evaluate features.
    """
    _, attr = spectype.children.append(_syside.OwningMembership, _syside.AttributeUsage)
    attr.declared_name = attr_def.name

    # Add base reqif tag
    add_reqif_tag(
        attr,
        ctx.meta_tags.reqif_tag,
        identifier=attr_def.id,
        last_change=attr_def.last_change,
        extra={ctx.meta_tags.reqif_tag.is_editable_field: attr_def.is_editable},
    )

    # Add description
    if attr_def.description:
        set_or_update_description(attr, attr_def.description)

    # Handle typing and datatype def tags
    info = SCALAR_TYPE_INFO.get(type(attr_def.props))
    if info is not None:
        tag = getattr(ctx.meta_tags, info.tag_attr)
        add_reqif_tag(
            attr,
            tag,
            identifier=attr_def.props.datatype_def.id,
            last_change=attr_def.props.datatype_def.last_change,
            extra=_datatype_extra(tag, attr_def.props.datatype_def),
        )

        attr.heritage.append(_syside.FeatureTyping, ctx.scalar_map[info.scalar_key])

        if attr_def.props.default_value is not None:
            if info.literal_cls == "signed_int":
                value = set_signed_integer_literal(
                    attr.feature_value_member, cast(int, attr_def.props.default_value)
                )
            else:
                value = set_literal_value(
                    attr.feature_value_member,
                    info.literal_cls,
                    cast(str | int | float | bool, attr_def.props.default_value),
                )
            value.is_default = True

    elif ir.kind_of(attr_def, ir.EnumAttrDef):
        # Set multiplicity
        _, multiplicity = attr.declared_multiplicity_member.set_member_element(
            _syside.MultiplicityRange
        )
        _, range_expr = multiplicity.bounds_expression_member.set_member_element(
            _syside.OperatorExpression
        )
        range_expr.operator = _syside.ExplicitOperator.Range
        _, lower_val = range_expr.arguments.append(_syside.LiteralInteger)
        lower_val.value = 0

        if attr_def.props.multi_valued:
            range_expr.arguments.append(_syside.LiteralInfinity)
        else:
            _, higher_val = range_expr.arguments.append(_syside.LiteralInteger)
            higher_val.value = 1

        # Set type to the Enum Def
        enum_def_ref = ctx.enum_def(attr_def.props.datatype_def.id)
        attr.heritage.append(_syside.FeatureTyping, enum_def_ref)

        # Set default
        if attr_def.props.default_value is not None:
            enum_val_ref = ctx.enum_value(attr_def.props.default_value.id)
            enum_value, enum_expr = attr.feature_value_member.set_member_element(
                _syside.FeatureReferenceExpression
            )
            enum_expr.referent_member.set_member_element(enum_val_ref)
            enum_value.is_default = True

    else:
        assert False, "unreachable"

    ctx.refs[attr_def.id] = attr

    if attr_def.name == "ReqIF.Prefix" and isinstance(
        attr_def.props.default_value, str
    ):
        return attr_def.props.default_value

    return None


def update_scalar_datatype_def(
    sysml_model: _syside.Model,
    element_delta: ir.ElementDelta,
    new_ir: ir.DatatypeDef[ir.DatatypeProps],
    ctx: BuildContext,
) -> None:
    """
    Apply IR-level changes to a *scalar* (non-enum) DatatypeDef.

    Scalar datatypes have no top-level SysMLv2 element — they exist as
    ``@reqif_string`` / ``@reqif_integer`` / ... metadata tags on every
    ``AttributeUsage`` whose AttributeDef references them. A single
    DatatypeDef edit therefore has to update every matching tag in the
    workspace; ``find_datatype_marker_tags`` does the model-wide scan
    and returns them all.

    Handles ``name`` (long_name), ``description``, ``last_change``, and
    the per-kind constraint fields (``max_length`` / ``min`` / ``max`` /
    ``accuracy``). The DatatypeDef-level ``kind`` field still raises
    :class:`NotImplementedError`: a kind change rewrites every
    AttributeUsage's FeatureTyping plus the tag class itself, and
    cross-paradigm changes (scalar↔enum) need to add or remove a
    top-level ``EnumerationDefinition``. Out of scope for this writer.
    """
    all_tags = find_datatype_marker_tags(sysml_model, ctx.meta_tags, new_ir.id)
    if not all_tags:
        # Nothing to update — the DatatypeDef has no representation in
        # the SysML workspace. This is a precondition violation, not a
        # delta-apply error.
        raise ValueError(
            f"{_OWNER_KIND_LABEL_SCALAR} {new_ir.name!r}: no datatype-marker "
            f"tags found in the workspace for id {new_ir.id!r}"
        )

    datatype_tag = ctx.meta_tags.reqif_datatype_tag

    for change in element_delta.changes:
        field = change.field
        if field == "name":
            for meta in all_tags:
                set_redefined_string(meta, datatype_tag.long_name_field, new_ir.name)
        elif field == "description":
            if new_ir.description is not None:
                for meta in all_tags:
                    set_redefined_string(
                        meta, datatype_tag.desc_field, new_ir.description
                    )
        elif field == "last_change":
            if new_ir.last_change is not None:
                for meta in all_tags:
                    set_redefined_string(
                        meta, datatype_tag.last_change_field, new_ir.last_change
                    )
        elif field == "kind":
            raise NotImplementedError(
                f"{_OWNER_KIND_LABEL_SCALAR} {new_ir.name!r}: kind change "
                f"({change.old} -> {change.new}) requires rewriting every "
                f"referencing AttributeUsage's FeatureTyping plus replacing "
                f"the tag class, and is not yet supported"
            )
        elif field == "max_length":
            assert isinstance(new_ir.props, ir.StrProps)
            string_tag = ctx.meta_tags.reqif_string_tag
            for meta in all_tags:
                set_redefined_value(
                    meta, string_tag.max_length_field, new_ir.props.max_length
                )
        elif field == "min" or field == "max":
            _update_numeric_constraint(all_tags, field, new_ir.props, ctx)
        elif field == "accuracy":
            assert isinstance(new_ir.props, ir.RealProps)
            real_tag = ctx.meta_tags.reqif_real_tag
            for meta in all_tags:
                set_redefined_value(
                    meta, real_tag.accuracy_field, new_ir.props.accuracy
                )
        else:
            raise ValueError(
                f"{_OWNER_KIND_LABEL_SCALAR} {new_ir.name!r}: unhandled "
                f"delta field {field!r}"
            )


def _update_numeric_constraint(
    all_tags: list[_syside.MetadataUsage],
    field: str,  # ``"min"`` or ``"max"``
    props: ir.DatatypeProps,
    ctx: BuildContext,
) -> None:
    """Update ``min`` / ``max`` on every Int- or Real-tag in ``all_tags``."""
    new_value: int | float
    if isinstance(props, ir.IntProps):
        int_tag = ctx.meta_tags.reqif_integer_tag
        target = int_tag.min_field if field == "min" else int_tag.max_field
        new_value = props.min if field == "min" else props.max
        for meta in all_tags:
            set_redefined_value(meta, target, new_value)
    elif isinstance(props, ir.RealProps):
        real_tag = ctx.meta_tags.reqif_real_tag
        target = real_tag.min_field if field == "min" else real_tag.max_field
        new_value = props.min if field == "min" else props.max
        for meta in all_tags:
            set_redefined_value(meta, target, new_value)
    else:
        raise ValueError(
            f"unexpected min/max change on a {type(props).__name__} datatype"
        )
