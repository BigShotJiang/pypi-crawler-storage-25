import sys

import _syside

from pathlib import Path


# TODO https://gitlab.com/sensmetry/internal2/tech/syside/syside-python/-/work_items/58:
#       Take into account ``include`` and ``exclude`` from syside.toml or CLI,
#       but this should probably be a job for Automator itself, not just ReqIF
#       subcommands
def collect_files(root: Path) -> list[Path]:
    """
    Collect SysML files in the current directory recursively, discarding hidden folders
    except `.sysand`.
    """
    # Collect the files normally
    initial_files = _syside.collect_files_recursively(root)

    # Discard hidden files/folders EXCEPT `.sysand`
    files_without_hidden: list[Path] = []
    for file in initial_files:
        if any(
            part.startswith(".") and part != ".sysand"
            for part in file.relative_to(root).parts
        ):
            continue
        files_without_hidden.append(file)

    return files_without_hidden


def load_workspace_model(verb: str) -> _syside.Model:
    """
    Load the SysMLv2 workspace model rooted at the current working directory.

    Raises ``ValueError`` if no SysML files are found, with a hint to run
    ``syside reqif init`` for fresh projects. Prints a warning banner and the
    diagnostics if any errors or warnings are present, but still returns the
    (possibly partial) model. ``verb`` is interpolated into the warning message
    (e.g. ``"imports"``, ``"locking"``, ``"checking"``).
    """
    files_to_load = collect_files(Path.cwd())
    if not files_to_load:
        raise ValueError(
            "No SysML files found in the current directory.\n"
            "In a fresh project, run `syside reqif init` first."
        )

    model, diags = _syside.try_load_model(files_to_load, attach_comments=True)

    if diags.contains_errors(warnings_as_errors=True):
        print(
            "The loaded SysML files contain Errors and/or Warnings.",
            file=sys.stderr,
        )
        print(
            f"This may lead to incomplete {verb} or additional model errors.",
            file=sys.stderr,
        )
        for diag in diags.all:
            print(diag, file=sys.stderr)

    return model
