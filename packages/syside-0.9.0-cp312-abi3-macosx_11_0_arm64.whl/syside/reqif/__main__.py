"""Entry point for ``python -m syside.reqif``."""

import argparse
import sys
from collections.abc import Sequence
from datetime import date
from pathlib import Path
from typing import Any

REQIF_EXTRA_PACKAGE = "syside[reqif]"

_COPYRIGHT = f"Commercial Software (copyright) Sensmetry 2025-{date.today().year}"


class _SysideHelpFormatter(argparse.HelpFormatter):
    """HelpFormatter that title-cases the ``Usage:`` banner to match clap."""

    def add_usage(
        self,
        usage: str | None,
        actions: Any,
        groups: Any,
        prefix: str | None = None,
    ) -> None:
        # ``prefix is None`` rather than falsy: argparse calls add_usage with
        # ``prefix=''`` during subparser registration to cache the bare-usage
        # string, and substituting there bakes ``Usage:`` into the cached
        # text and produces a doubled banner on subparser ``--help``.
        if prefix is None:
            prefix = "Usage: "
        super().add_usage(usage, actions, groups, prefix)


class _SysideArgumentParser(argparse.ArgumentParser):
    """
    ArgumentParser pre-configured to match the ``syside`` help layout.

    - Section labels match clap's TitleCase headings (``Options``,
      ``Arguments`` for leaf parsers, ``Subcommands`` once subparsers are
      attached).
    - The auto-generated ``-h, --help`` flag is replaced by one whose help
      text reads ``Print help`` instead of argparse's default
      ``show this help message and exit``.
    - The Sensmetry copyright epilog is applied by default.
    - Subparsers inherit this class through argparse's ``_parser_class``,
      so the styling propagates without per-subparser plumbing.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        kwargs.setdefault("formatter_class", _SysideHelpFormatter)
        kwargs.setdefault("epilog", _COPYRIGHT)
        kwargs["add_help"] = False
        super().__init__(*args, **kwargs)
        self._optionals.title = "Options"
        self._positionals.title = "Arguments"
        self.add_argument(
            "-h",
            "--help",
            action="help",
            default=argparse.SUPPRESS,
            help="Print help",
        )

    def add_subparsers(self, **kwargs: Any) -> Any:
        kwargs.setdefault("metavar", "<COMMAND>")
        sub = super().add_subparsers(**kwargs)
        # The parser's positional group is now the subcommand list.
        self._positionals.title = "Subcommands"
        return sub


def _is_uv_managed_venv() -> bool:
    """
    Emit True when the active venv was created by uv.

    uv writes a ``uv = <version>`` line into ``pyvenv.cfg`` at venv creation,
    which is the cheapest reliable signal we can use without subprocess'ing.
    """
    venv_cfg = Path(sys.prefix) / "pyvenv.cfg"
    if not venv_cfg.is_file():
        return False
    try:
        content = venv_cfg.read_text(encoding="utf-8")
    except OSError:
        return False
    return any(line.split("=", 1)[0].strip() == "uv" for line in content.splitlines())


def _install_command() -> str:
    """Return the install command best matched to the user's environment."""
    if _is_uv_managed_venv():
        return f"uv add '{REQIF_EXTRA_PACKAGE}'"
    return f"pip install '{REQIF_EXTRA_PACKAGE}'"


def _missing_extra_message(import_error: BaseException) -> str:
    return (
        "The `reqif` subcommand requires the [reqif] extra, which is not installed.\n"
        "\n"
        "Install it with:\n"
        f"    {_install_command()}\n"
        "\n"
        f"Original import error: {import_error}"
    )


def build_parser(prog: str) -> argparse.ArgumentParser:
    """
    Construct the ``syside reqif`` argparse tree rooted at ``prog``.

    Kept extra-free (only imports the stdlib-only ``syside.reqif._cli``
    option dataclasses) so ``ExternalCommand.help`` can render the help
    tree even when the ``[reqif]`` extra is not installed.
    """
    from syside.reqif._cli import (
        CheckReqifOptions,
        CheckSysmlOptions,
        ImportOptions,
        InitOptions,
        ExportOptions,
    )

    parser = _SysideArgumentParser(prog=prog)
    subparsers = parser.add_subparsers(dest="command", required=True)

    import_parser = subparsers.add_parser(
        "import", help="Import a ReqIF file into SysMLv2"
    )
    ImportOptions.add_args(import_parser)

    init_parser = subparsers.add_parser(
        "init",
        help="Initialise a SysMLv2 workspace for ReqIF import and export",
    )
    InitOptions.add_args(init_parser)

    subparsers.add_parser(
        "lock",
        help="Generate UUIDs for ReqIF elements in SysMLv2",
    )

    check_parser = subparsers.add_parser(
        "check",
        help="Run validation checks on ReqIF files or SysMLv2 models",
    )
    check_subparsers = check_parser.add_subparsers(dest="check_target", required=True)

    check_reqif_parser = check_subparsers.add_parser(
        "reqif", help="Run checks against a ReqIF/ReqIFz file"
    )
    CheckReqifOptions.add_args(check_reqif_parser)

    check_sysml_parser = check_subparsers.add_parser(
        "sysml", help="Run checks against the SysMLv2 workspace"
    )
    CheckSysmlOptions.add_args(check_sysml_parser)

    export_parser = subparsers.add_parser(
        "export", help="Export a ReqIF file from SysMLv2 model"
    )
    ExportOptions.add_args(export_parser)

    return parser


def main(argv: Sequence[str] | None = None, prog: str = "syside reqif") -> int:
    """
    ReqIF import/export CLI entry point.
    """
    from syside import reqif as _reqif

    if _reqif._missing_extra_error is not None:
        sys.stderr.write(_missing_extra_message(_reqif._missing_extra_error) + "\n")
        return 1

    from syside.reqif._cli import (
        CheckReqifOptions,
        CheckSysmlOptions,
        ImportOptions,
        InitOptions,
        ExportOptions,
    )
    from syside.reqif import (
        check_reqif,
        check_sysml,
        import_,
        init,
        lock,
        export,
    )

    parser = build_parser(prog)
    args = parser.parse_args(argv)

    match args.command, getattr(args, "check_target", None):
        case ("import", _):
            return import_(ImportOptions.from_args(args))
        case ("init", _):
            return init(InitOptions.from_args(args))
        case ("lock", _):
            return lock()
        case ("check", "reqif"):
            return check_reqif(CheckReqifOptions.from_args(args))
        case ("check", "sysml"):
            return check_sysml(CheckSysmlOptions.from_args(args))
        case ("export", _):
            return export(ExportOptions.from_args(args))
        case _:
            raise AssertionError(
                f"unreachable: argparse should reject unknown command {args.command!r}"
            )


if __name__ == "__main__":
    sys.exit(main())
