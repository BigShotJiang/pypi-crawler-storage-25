"""``syside reqif export`` subcommand. Orchestrates the SysMLv2 -> ReqIF conversion."""

import sys
import zipfile
from pathlib import Path
from datetime import datetime, timezone
from uuid import uuid4

import _syside

from reqif.models.reqif_core_content import ReqIFCoreContent
from reqif.models.reqif_req_if_content import ReqIFReqIFContent
from reqif.models.reqif_namespace_info import ReqIFNamespaceInfo
from reqif.models.reqif_reqif_header import ReqIFReqIFHeader
from reqif.object_lookup import ReqIFObjectLookup
from reqif.reqif_bundle import ReqIFBundle
from reqif.unparser import ReqIFUnparser

from syside.reqif._sysml_file_loading import load_workspace_model
from syside.reqif._cli import ExportOptions
from syside.reqif._config import (
    ATTACHMENTS_DIR,
)

from syside.reqif._cmd_check import validate_sysml

from syside.reqif import _ir_model as ir
from syside.reqif._model_to_ir import parse_model_to_ir

from syside.reqif._datatypes_reqif import write_datatypes_from_ir
from syside.reqif._spec_types_reqif import write_spec_types_from_ir
from syside.reqif._spec_objects_reqif import write_spec_objects_from_ir
from syside.reqif._specifications_reqif import write_specifications_from_ir
from syside.reqif._spec_relations_reqif import write_spec_relations_from_ir
from syside.reqif._relation_groups_reqif import write_relation_groups_from_ir


def run(opts: ExportOptions) -> int:
    """
    Run the SysMLv2 -> ReqIF conversion.

    Loads the workspace SysMLv2 model under the current working directory
    and converts it into ReqIF saved into ``opts.file``. If the ``opts.reqifz``
    flag is set, the resulting ReqIF file is zipped into a ``.reqifz`` file,
    along with all files found in ``opts.attachments_dir`` (or ``<cwd>/``
    joined with :data:`syside.reqif.ATTACHMENTS_DIR` when unset) recursively.

    - ``opts.title`` is used as the title for the ReqIF file and is required.
    - ``opts.comment`` is used as the comment for the ReqIF file.
    - ``opts.repository_id`` is used as the repository ID for the ReqIF file.

    The latter two are optional.

    Returns ``0`` on success.
    """
    _validate_output_extension(opts.file, opts.reqifz)

    root = Path.cwd()
    attachments_dir = opts.attachments_dir or root / ATTACHMENTS_DIR
    attachments_rel = _resolve_attachments_rel(attachments_dir, root)

    sysml_model = load_workspace_model("exports")

    validate_sysml(sysml_model)

    # ``parse_model_to_ir`` loads the metadata tag and prefix defs itself
    # when the kwargs are omitted.
    ir_model = parse_model_to_ir(sysml_model)

    content = _ir_to_reqif_content(ir_model, attachments_rel)
    bundle = _build_bundle(content, opts)

    xml_output = ReqIFUnparser.unparse(bundle)
    xml_output = _fix_xhtml_namespace(xml_output)

    out_path = opts.file
    out_path.parent.mkdir(parents=True, exist_ok=True)

    if opts.reqifz:
        _write_reqifz(out_path, xml_output, attachments_dir)
    else:
        out_path.write_text(xml_output, encoding="utf-8")

    return 0


def _validate_output_extension(out_path: Path, reqifz: bool) -> None:
    """
    Reject mismatched output-extension/``--reqifz`` combinations.

    The flag controls the bytes written (zip vs plain XML); the path's
    extension controls how downstream tools interpret those bytes. Letting
    them disagree silently produces zip bytes wearing a ``.reqif`` extension
    or plain XML wearing a ``.reqifz`` extension — both are footguns for
    receivers that key off the extension. Refuse before any model work runs.
    """
    suffix = out_path.suffix.lower()
    if reqifz and suffix == ".reqifz":
        return
    if not reqifz and suffix == ".reqif":
        return

    if suffix == ".reqif" and reqifz:
        suggested = out_path.with_suffix(".reqifz").name
        raise ValueError(
            f"--reqifz produces a zipped archive, but {out_path} has a "
            f".reqif extension. Either rename the output to {suggested!r} "
            f"or drop --reqifz."
        )
    if suffix == ".reqifz" and not reqifz:
        suggested = out_path.with_suffix(".reqif").name
        raise ValueError(
            f"{out_path} has a .reqifz extension but --reqifz was not "
            f"passed, so the output would be plain XML. Either pass "
            f"--reqifz, or rename the output to {suggested!r}."
        )
    raise ValueError(
        f"{out_path} has an unsupported extension {suffix!r}; "
        f"the only valid extensions are .reqif and .reqifz."
    )


def _resolve_attachments_rel(attachments_dir: Path, root: Path) -> str:
    """
    Return ``attachments_dir`` relative to ``root`` as a string, or raise
    ``ValueError`` if it escapes the workspace.
    """
    resolved_attachments = attachments_dir.resolve()
    resolved_root = root.resolve()
    try:
        return str(resolved_attachments.relative_to(resolved_root))
    except ValueError:
        raise ValueError(
            f"--attachments-dir must be inside the workspace ({root}); "
            f"got {attachments_dir} (resolved to {resolved_attachments}, "
            f"workspace resolved to {resolved_root})"
        )


def _ir_to_reqif_content(ir_model: ir.Model, attachments_rel: str) -> ReqIFReqIFContent:
    """Fan ``ir_model`` out across the per-collection writers."""
    return ReqIFReqIFContent(
        data_types=write_datatypes_from_ir(ir_model.datatype_defs),
        spec_types=write_spec_types_from_ir(ir_model.spec_types, attachments_rel),
        spec_objects=write_spec_objects_from_ir(ir_model.spec_objects, attachments_rel),
        spec_relations=write_spec_relations_from_ir(ir_model.spec_relations),
        specifications=write_specifications_from_ir(
            ir_model.specifications, attachments_rel
        ),
        spec_relation_groups=write_relation_groups_from_ir(ir_model.relation_groups),
    )


def _build_bundle(content: ReqIFReqIFContent, opts: ExportOptions) -> ReqIFBundle:
    """Wrap ``content`` in a ``ReqIFBundle`` with a fresh header."""
    tool_id = _tool_id()
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    # The upstream ``reqif`` package ships no type stubs, so its
    # constructors are seen as untyped. Suppress the ``no-untyped-call``
    # errors at the boundary rather than scattering ignores or wrapping
    # every helper.
    return ReqIFBundle(
        namespace_info=ReqIFNamespaceInfo.create_default(),  # type: ignore[no-untyped-call]
        req_if_header=ReqIFReqIFHeader(
            identifier=str(uuid4()),
            comment=opts.comment,
            creation_time=now,
            req_if_tool_id=tool_id,
            req_if_version="1.0",
            source_tool_id=tool_id,
            title=opts.title,
            repository_id=opts.repository_id,
        ),
        core_content=ReqIFCoreContent(req_if_content=content),
        tool_extensions_tag_exists=False,
        lookup=ReqIFObjectLookup.empty(),  # type: ignore[no-untyped-call]
        exceptions=[],
    )


def _tool_id() -> str:
    """
    Return the tool ID, which is syside + version.
    """
    version = f"{_syside.version.major}.{_syside.version.minor}.{_syside.version.patch}"
    return f"Syside Automator v{version}"


def _fix_xhtml_namespace(xml: str) -> str:
    """
    Replace the ``xmlns:xhtml`` declaration (emitted by the upstream reqif
    library) with the correct ``xmlns:reqif-xhtml`` prefix required by ReqIF.
    """
    return xml.replace('xmlns:xhtml="', 'xmlns:reqif-xhtml="')


def _write_reqifz(out_path: Path, xml_output: str, attachments_dir: Path) -> None:
    reqif_name = out_path.with_suffix(".reqif").name

    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(reqif_name, xml_output)

        if attachments_dir.is_dir():
            attachments_root = attachments_dir.resolve()
            for file_path in sorted(attachments_dir.rglob("*")):
                # ZIP archives store paths with forward slashes per the
                # PKZIP/APPNOTE spec; ``Path.relative_to`` would emit
                # backslashes on Windows and break consumers that key off
                # the spec form (and the cross-platform assertions in our
                # own tests).
                rel = file_path.relative_to(attachments_dir).as_posix()
                # Refuse symlinks: a link under ``attachments_dir`` could
                # otherwise pull arbitrary file contents (secrets, hosts,
                # ssh keys, ...) into the .reqifz. Check ``is_symlink``
                # before ``is_file`` so symlinks to directories are also
                # surfaced, not silently dropped.
                if file_path.is_symlink():
                    print(
                        f"Skipping attachment {rel}: symlinks are not "
                        f"followed into .reqifz archives.",
                        file=sys.stderr,
                    )
                    continue
                if not file_path.is_file():
                    continue
                # Defence in depth for Python versions whose ``rglob``
                # descends into symlinked directories: any file whose
                # resolved path escapes ``attachments_dir`` is dropped.
                if not file_path.resolve().is_relative_to(attachments_root):
                    print(
                        f"Skipping attachment {rel}: resolves outside "
                        f"--attachments-dir (likely via a symlinked "
                        f"parent directory).",
                        file=sys.stderr,
                    )
                    continue
                zf.write(file_path, rel)
