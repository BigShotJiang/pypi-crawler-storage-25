import argparse
import pathlib
from dataclasses import dataclass, fields
from typing import Self

from syside.reqif._config import LIBRARY_DIR, ATTACHMENTS_DIR


class _OptionsBase:
    """
    Mixin for subcommand option dataclasses.

    Provides ``from_args`` so the CLI dispatcher can construct an options
    instance from a parsed ``argparse.Namespace`` without spelling each
    field name a third time. Field names on the subclass dataclass must
    match the attribute names argparse produces (``argparse`` already
    normalises ``--foo-bar`` into ``args.foo_bar``).
    """

    @classmethod
    def from_args(cls, args: argparse.Namespace) -> Self:
        """Build an options instance by pulling each dataclass field off ``args``."""
        return cls(**{f.name: getattr(args, f.name) for f in fields(cls)})  # type: ignore[arg-type]


@dataclass
class ImportOptions(_OptionsBase):
    """Parsed arguments for the ``syside reqif import`` subcommand."""

    file: pathlib.Path
    """Path to the ``.reqif`` or ``.reqifz`` file to import (positional)."""

    attachments_dir: pathlib.Path | None
    """
    Directory to extract ReqIF attachments into. When ``None``, defaults to
    ``<cwd>/`` joined with :data:`syside.reqif.ATTACHMENTS_DIR` at run time
    (``--attachments-dir``).
    """

    @staticmethod
    def add_args(parser: argparse.ArgumentParser) -> None:
        """Register this subcommand's flags onto ``parser``."""
        parser.add_argument(
            "file", type=pathlib.Path, help="Path to the ReqIF/ReqIFz file to import"
        )

        parser.add_argument(
            "--attachments-dir",
            type=pathlib.Path,
            help=f"Path to extract ReqIF attachments to. Default is `{ATTACHMENTS_DIR}/`",
            default=None,
        )


@dataclass
class InitOptions(_OptionsBase):
    """Parsed arguments for the ``syside reqif init`` subcommand."""

    lib_dir: pathlib.Path | None
    """
    Destination directory for the SysMLv2 ReqIF library. When ``None``,
    defaults to :data:`syside.reqif.LIBRARY_DIR` (``--lib-dir``).
    """

    @staticmethod
    def add_args(parser: argparse.ArgumentParser) -> None:
        """Register this subcommand's flags onto ``parser``."""
        parser.add_argument(
            "--lib-dir",
            type=pathlib.Path,
            help=f"Folder to extract SysMLv2 ReqIF library to. Default is `{LIBRARY_DIR}/`",
            default=None,
        )


@dataclass
class CheckReqifOptions(_OptionsBase):
    """Parsed arguments for the ``syside reqif check reqif`` subcommand."""

    file: pathlib.Path
    """Path to the ``.reqif`` or ``.reqifz`` file to validate (positional)."""

    @staticmethod
    def add_args(parser: argparse.ArgumentParser) -> None:
        """Register this subcommand's flags onto ``parser``."""
        parser.add_argument(
            "file",
            type=pathlib.Path,
            help="Path to the ReqIF/ReqIFz file to check",
        )


@dataclass
class CheckSysmlOptions(_OptionsBase):
    """
    Parsed arguments for the ``syside reqif check sysml`` subcommand.

    The SysML check operates on the current workspace, so this dataclass
    intentionally has no fields.
    """

    @staticmethod
    def add_args(parser: argparse.ArgumentParser) -> None:
        """Register this subcommand's flags onto ``parser``. No-op."""
        pass


@dataclass
class ExportOptions(_OptionsBase):
    """Parsed arguments for the ``syside reqif export`` subcommand."""

    file: pathlib.Path
    """Path to the exported ``.reqif`` or ``.reqifz`` file."""

    attachments_dir: pathlib.Path | None
    """
    Directory to collect ReqIF attachments into. When ``None``, defaults to
    ``<cwd>/`` joined with :data:`syside.reqif.ATTACHMENTS_DIR` at run time
    (``--attachments-dir``).

    **Note**: collection is dumb – it will collect all files in the directory
    regardless of whether they are mentioned in the SysMLv2 model or not.
    Avoid setting this path to the current working directory, as it will collect
    all SysMLv2 files as well.
    """

    reqifz: bool
    """
    Whether to export as ``.reqifz`` or ``.reqif``. Default: False.
    """

    title: str
    """
    Human-readable title for the ReqIF Exchange Document. Required.
    """

    comment: str | None
    """
    Human-readable free-form description of the ReqIF Exchange Document.
    Optional.
    """

    repository_id: str | None
    """
    Identifier of the repository from which this ReqIF Exchange Document
    was created. E.g. a UUID, URL. Optional.
    """

    @staticmethod
    def add_args(parser: argparse.ArgumentParser) -> None:
        """Register this subcommand's flags onto ``parser``."""
        parser.add_argument(
            "file", type=pathlib.Path, help="Path to the exported ReqIF or ReqIFz file."
        )

        parser.add_argument(
            "--title",
            type=str,
            help="Human-readable title for the ReqIF Exchange Document.",
            required=True,
        )

        parser.add_argument(
            "--comment",
            type=str,
            help="Human-readable free-form description of the ReqIF Exchange Document. Default: None.",
            default=None,
        )

        parser.add_argument(
            "--reqifz",
            action="store_true",
            help="Export as .reqifz (zipped) instead of plain .reqif. Default: False.",
        )

        parser.add_argument(
            "--repository-id",
            type=str,
            help="Identifier of the repository from which this ReqIF Exchange Document was created. E.g. a UUID, URL. Default: None.",
            default=None,
        )

        parser.add_argument(
            "--attachments-dir",
            type=pathlib.Path,
            help=f"Path to include ReqIF attachments from. Default is `{ATTACHMENTS_DIR}/`",
            default=None,
        )
