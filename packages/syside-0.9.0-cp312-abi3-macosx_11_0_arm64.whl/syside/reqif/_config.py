"""
Package name constants and metadata-type registries for ReqIF import/export.

``*_PKG`` constants name the SysMLv2 packages that receive each category of
imported ReqIF content.

``REQIF_METADATA_NAMES`` and ``REQIF_DATATYPE_NAMES`` list the stereotype
names used to identify ReqIF metadata blocks and scalar datatype markers on
attribute definitions.
"""

LIBRARY_PKG = "SysideReqIF"
"""
Name (without ``.sysml`` extension) of the canonical SysMLv2 library
package that ``syside reqif init`` writes into the workspace.
"""

LIBRARY_DIR = "lib"
"""
Default workspace-relative directory for the SysMLv2 ReqIF library, used
by ``syside reqif init`` when ``InitOptions.lib_dir`` is unset.
"""

ENUMS_PKG = "ReqIF_Import_Enums"
TYPES_PKG = "ReqIF_Import_Types"
OBJECTS_PKG = "ReqIF_Import_Objects"
SPECS_PKG = "ReqIF_Import_Specifications"
RELATIONS_PKG = "ReqIF_Import_Relations"
DEFAULT_OUTPUT_FILE = "export.reqif"

ATTACHMENTS_DIR = "attachments_reqif"
"""
Default workspace-relative directory that ``syside reqif import`` extracts
ReqIF attachments into when ``ImportOptions.attachments_dir`` is unset.
"""

# Metadata types that serve as datatype markers on attributes
REQIF_DATATYPE_NAMES = (
    "reqif_string",
    "reqif_xhtml",
    "reqif_integer",
    "reqif_real",
    "reqif_boolean",
    "reqif_date",
)

# All metadata types that inherit from reqif and carry identifier/last_change
REQIF_METADATA_NAMES = ("reqif", "reqif_enum_value") + REQIF_DATATYPE_NAMES
