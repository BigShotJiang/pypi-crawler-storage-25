import re

from . import _ir_model as ir

import _syside
from syside.reqif._sysml_utils import (
    BuildContext,
    extract_tracked_element,
    iter_children_of_type,
    set_or_update_description,
)
from syside.reqif._sysml_metadata import (
    add_reqif_tag,
    obtain_metadata_tag,
    set_redefined_string,
)
from syside.reqif._attribute_values_sysml import (
    make_attribute_value_field_re,
    update_attribute_usage,
    write_attribute_usage,
)


_OWNER_KIND_LABEL = "Specification"
_SPEC_ATTR_FIELD_RE = make_attribute_value_field_re("spec_attribute")

# Hierarchy-node FieldChange shapes (see ``_diff_hierarchy``):
#   ``hierarchy_node[<id>]``               — added (old=None) or removed (new=None)
#   ``hierarchy_node[<id>].<field>``       — field-level edit on an existing node
_HIERARCHY_NODE_FIELD_RE = re.compile(
    r"^hierarchy_node\[(?P<id>[^\]]+)\](?:\.(?P<sub>[a-z_]+))?$"
)
_HIERARCHY_ORDERING_FIELD = "hierarchy_node_ordering"


def _hierarchy_node_declared_name(prefix: str | None, ordinal: int) -> str:
    """
    Canonical rendering for a hierarchy-node ``declared_name``.

    SysML hierarchy nodes are displayed with 1-based ordinals
    (``prefix-1``, ``prefix-2``, ...), so ``ordinal`` is taken to
    already be 1-based — callers iterate with
    ``enumerate(..., start=1)`` or pass the ordinal returned by
    :func:`_locate_hierarchy_node`. Top-level children of a
    Specification carry the spec's ``ReqIF.Prefix``; nested nodes
    pass ``prefix=None`` and get a bare ordinal.

    Both the fresh and delta paths route through this helper so a
    delta-time rewrite can never drift away from what a fresh import
    would have produced for the same ``(prefix, ordinal)``.
    """
    return f"{prefix}-{ordinal}" if prefix else str(ordinal)


def create_specifications(
    package: _syside.Package,
    specifications: dict[str, ir.Specification],
    ctx: BuildContext,
) -> None:
    """
    Write **new** Specification elements into the given package. Additionally, this function
    writes SpecHierarchy elements (``requirement``) into SpecObjects (``requirement def``)
    found in the model.

    This function adds ID -> SysMLv2 element references back to BuildContext's ``refs`` dict.
    """
    for spec in specifications.values():
        _, spec_elem = package.children.append(
            _syside.OwningMembership, _syside.RequirementDefinition
        )
        spec_elem.declared_name = spec.name

        add_reqif_tag(
            spec_elem,
            ctx.meta_tags.reqif_tag,
            identifier=spec.id,
            last_change=spec.last_change,
        )

        if spec.description:
            set_or_update_description(spec_elem, spec.description)

        spec_type_ref = ctx.spec_type_req(spec.type_ref.id)
        spec_elem.heritage.append(_syside.Subclassification, spec_type_ref)

        prefix_redef: str | None = None
        for ir_attr in spec.attributes.values():
            prefix_redef = write_attribute_usage(
                spec_elem, ir_attr, "Specification", spec.name, ctx
            )

        prefix_default = ctx.prefix_default_map.get(spec_type_ref, None)
        prefix_actual = prefix_redef if prefix_redef is not None else prefix_default

        for ordinal, hierarchy_node in enumerate(spec.children.values(), start=1):
            _write_hierarchy_node(
                spec_elem, ordinal, hierarchy_node, ctx, name_prefix=prefix_actual
            )

        ctx.refs[spec.id] = spec_elem


def _write_hierarchy_node(
    parent: _syside.Namespace,
    ordinal: int,
    hierarchy_node: ir.SpecHierarchyNode,
    ctx: BuildContext,
    *,
    name_prefix: str | None = None,
) -> None:
    _, hierarchy_elem = parent.children.append(
        _syside.OwningMembership, _syside.RequirementUsage
    )
    hierarchy_elem.declared_name = _hierarchy_node_declared_name(name_prefix, ordinal)

    spec_obj_ref = ctx.spec_object(hierarchy_node.spec_object_ref.id)
    hierarchy_elem.heritage.append(_syside.FeatureTyping, spec_obj_ref)

    add_reqif_tag(
        hierarchy_elem,
        ctx.meta_tags.reqif_tag,
        identifier=hierarchy_node.id,
        last_change=hierarchy_node.last_change,
        extra={ctx.meta_tags.reqif_tag.is_editable_field: hierarchy_node.is_editable},
    )

    if hierarchy_node.description:
        set_or_update_description(hierarchy_elem, hierarchy_node.description)

    ctx.refs[hierarchy_node.id] = hierarchy_elem
    # Keep the first usage written for any given SpecObject definition: its
    # ancestry walks up through the enclosing Specification's definition,
    # which is what `_build_feature_chain` relies on. Overwriting on later
    # nested writes can leave the entry pointing at an inner usage whose
    # `.owner` is the SpecObject definition itself.
    ctx.definition_to_usage_map.setdefault(spec_obj_ref, hierarchy_elem)

    # `validate_ir_model` guarantees no SpecObject is the parent of nested
    # hierarchy nodes in two positions, so recursing once here can't collide
    # with a sibling recursion under the same RequirementDefinition.
    for child_ordinal, child_node in enumerate(
        hierarchy_node.children.values(), start=1
    ):
        _write_hierarchy_node(spec_obj_ref, child_ordinal, child_node, ctx)


def update_specification(
    existing: _syside.RequirementDefinition,
    element_delta: ir.ElementDelta,
    new_ir: ir.Specification,
    ctx: BuildContext,
) -> _syside.Url:
    """
    Apply IR-level changes to an existing SysMLv2 Specification.

    Mirrors :func:`update_spec_object` for the SpecObject-shared fields
    (``name``, ``type_ref``, ``description``, ``last_change``,
    ``spec_attribute[X]``) and adds Specification-only handlers for:

    * field edits on existing nodes (``hierarchy_node[X].name`` /
      ``last_change`` / ``is_editable`` / ``spec_object_ref``);
    * whole-node add / remove (``hierarchy_node[X]`` with ``old=None`` /
      ``new=None``); and
    * positional reordering (``hierarchy_node_ordering``).

    After every batch with structural hierarchy changes the writer
    runs a renumber pass over ``new_ir`` so each ``RequirementUsage``'s
    ``declared_name`` matches the ``ReqIF.Prefix`` + 1-based position
    that a fresh import would have produced — adds aren't required to
    insert at a specific SysML index, since :func:`parse_model_to_ir`
    reconstructs IR order from declared_name anyway.
    """
    structural_change = False
    for change in element_delta.changes:
        field = change.field
        if field == "name":
            existing.declared_name = new_ir.name
        elif field == "type_ref":
            _update_type_ref(existing, new_ir.type_ref, ctx)
        elif field == "description":
            set_or_update_description(existing, new_ir.description)
        elif field == "last_change":
            _update_last_change(existing, new_ir.last_change, ctx)
        elif _SPEC_ATTR_FIELD_RE.match(field):
            update_attribute_usage(
                existing,
                change,
                new_ir.attributes,
                ctx,
                field_re=_SPEC_ATTR_FIELD_RE,
                owner_kind_label=_OWNER_KIND_LABEL,
                owner_name=new_ir.name,
            )
        elif field == _HIERARCHY_ORDERING_FIELD:
            structural_change = True
        elif (m := _HIERARCHY_NODE_FIELD_RE.match(field)) is not None:
            if m.group("sub") is None:
                structural_change = True
            _update_hierarchy_node(existing, change, m, new_ir, ctx)
        else:
            raise ValueError(
                f"{_OWNER_KIND_LABEL} {new_ir.name!r}: unhandled delta field {field!r}"
            )

    if structural_change:
        _renumber_hierarchy(existing, new_ir, ctx)

    return existing.document.url


def _update_type_ref(
    existing: _syside.RequirementDefinition,
    new_type_ref: ir.SpecificationType,
    ctx: BuildContext,
) -> None:
    new_target = ctx.spec_type_req(new_type_ref.id)
    for index, rel in enumerate(existing.heritage.relationships):
        if rel.try_cast(_syside.Subclassification) is not None:
            existing.heritage.replace(index, _syside.Subclassification, new_target)
            return
    raise ValueError(
        f"expected a Subclassification on RequirementDefinition "
        f"{existing.declared_name!r}, found none"
    )


def _update_last_change(
    existing: _syside.RequirementDefinition,
    new_last_change: str | None,
    ctx: BuildContext,
) -> None:
    if new_last_change is None:
        return
    meta = obtain_metadata_tag(existing, ctx.meta_tags.reqif_tag.metadata_elem)
    if meta is None:
        raise ValueError(
            f"missing @reqif tag on RequirementDefinition {existing.declared_name!r}"
        )
    set_redefined_string(
        meta, ctx.meta_tags.reqif_tag.last_change_field, new_last_change
    )


def _find_hierarchy_node_ir(
    spec: ir.Specification, node_id: str
) -> ir.SpecHierarchyNode | None:
    """
    Return the IR ``SpecHierarchyNode`` whose id matches ``node_id``, or
    ``None`` if absent. Thin wrapper over :func:`_locate_hierarchy_node`
    for callers that only need the node — most field-edit paths look up
    by id without caring about position or parent.
    """
    located = _locate_hierarchy_node(spec, node_id)
    return located[1] if located is not None else None


def _locate_hierarchy_node(
    spec: ir.Specification, node_id: str
) -> tuple[ir.Specification | ir.SpecHierarchyNode, ir.SpecHierarchyNode, int] | None:
    """
    Locate ``node_id`` in ``spec``'s recursive hierarchy and return
    ``(parent, node, ordinal)`` — parent is the ``Specification`` for
    top-level nodes or the enclosing ``SpecHierarchyNode`` for nested
    ones, ``ordinal`` is the node's 1-based position in the parent's
    children (matching SysML's ``prefix-1`` / ``prefix-2`` rendering).
    Returns ``None`` when no node carries that id.

    The IR's hierarchy is recursive without back-pointers, so callers
    that need parent / ordinal (:func:`_add_hierarchy_node`) and
    callers that only need the node (:func:`_find_hierarchy_node_ir`)
    walk through one shared search instead of two near-identical ones.

    The diff emits flat ``hierarchy_node[X]`` field names regardless of
    nesting depth, so any handler dispatched on ``X`` resolves to the
    matching IR by id alone.
    """
    stack: list[
        tuple[ir.Specification | ir.SpecHierarchyNode, dict[str, ir.SpecHierarchyNode]]
    ] = [(spec, spec.children)]
    while stack:
        parent, children = stack.pop()
        for ordinal, node in enumerate(children.values(), start=1):
            if node.id == node_id:
                return parent, node, ordinal
            if node.children:
                stack.append((node, node.children))
    return None


def _update_hierarchy_node(
    spec_elem: _syside.RequirementDefinition,
    change: ir.FieldChange,
    match: re.Match[str],
    new_ir: ir.Specification,
    ctx: BuildContext,
) -> None:
    """Apply a hierarchy-node-level change captured by ``_HIERARCHY_NODE_FIELD_RE``."""
    node_id = match.group("id")
    sub_field = match.group("sub")  # None for adds/removes, str for field edits

    if sub_field is None:
        if change.old is None:
            _add_hierarchy_node(spec_elem, node_id, new_ir, ctx)
        else:
            _remove_hierarchy_node(node_id, ctx)
        return

    # Field-level edit on an existing node. ``ctx.refs`` was populated by
    # ``build_reqif_id_index`` so the RequirementUsage created by
    # ``_write_hierarchy_node`` is reachable directly by the IR id.
    node_elem = ctx.refs.get(node_id)
    if node_elem is None:
        raise ValueError(
            f"{_OWNER_KIND_LABEL} {new_ir.name!r}: hierarchy node {node_id!r} "
            f"has changes but is not present in the SysML workspace"
        )
    if not isinstance(node_elem, _syside.RequirementUsage):
        raise ValueError(
            f"{_OWNER_KIND_LABEL} {new_ir.name!r}: expected RequirementUsage for "
            f"hierarchy node {node_id!r}, got {type(node_elem).__name__}"
        )

    new_node_ir = _find_hierarchy_node_ir(new_ir, node_id)
    if new_node_ir is None:
        raise ValueError(
            f"{_OWNER_KIND_LABEL} {new_ir.name!r}: hierarchy node {node_id!r} "
            f"has changes but is missing from the new IR"
        )

    if sub_field == "name":
        # The model's ``declared_name`` for a hierarchy node is purely
        # ``_hierarchy_node_declared_name(prefix, ordinal)`` — sourced
        # at fresh-create time from ``ReqIF.Prefix`` and the 1-based
        # position in the parent's children. The IR's ``name`` field
        # maps to ReqIF ``LONG-NAME``, which other tools may have
        # synthesised from a different prefix; writing it through here
        # would drift the name away from what a fresh import on the
        # same IR would produce. ``(prefix, ordinal)`` cannot have
        # changed without a corresponding
        # ``spec_attribute[ReqIF.Prefix]`` / ``hierarchy_node_ordering``
        # field also being in this delta, so the existing
        # ``declared_name`` is already correct — no-op.
        pass
    elif sub_field == "spec_object_ref":
        new_target = ctx.spec_object(new_node_ir.spec_object_ref.id)
        for index, rel in enumerate(node_elem.heritage.relationships):
            if rel.try_cast(_syside.FeatureTyping) is not None:
                node_elem.heritage.replace(index, _syside.FeatureTyping, new_target)
                return
        raise ValueError(
            f"{_OWNER_KIND_LABEL} {new_ir.name!r}: hierarchy node {node_id!r} "
            f"has no FeatureTyping to replace"
        )
    elif sub_field == "last_change":
        if new_node_ir.last_change is None:
            return  # see _update_last_change
        meta = obtain_metadata_tag(node_elem, ctx.meta_tags.reqif_tag.metadata_elem)
        if meta is None:
            raise ValueError(f"missing @reqif tag on hierarchy node {node_id!r}")
        set_redefined_string(
            meta,
            ctx.meta_tags.reqif_tag.last_change_field,
            new_node_ir.last_change,
        )
    elif sub_field == "is_editable":
        # ``is_editable`` is a Boolean redefinition on the @reqif tag.
        meta = obtain_metadata_tag(node_elem, ctx.meta_tags.reqif_tag.metadata_elem)
        if meta is None:
            raise ValueError(f"missing @reqif tag on hierarchy node {node_id!r}")
        # Reuse the same redefinition-management pattern that
        # set_redefined_string uses for strings, but for a LiteralBoolean.
        from syside.reqif._sysml_metadata import find_redefinition
        from syside.reqif._sysml_utils import set_literal_value

        existing_ref = find_redefinition(
            meta, ctx.meta_tags.reqif_tag.is_editable_field
        )
        if existing_ref is not None:
            set_literal_value(
                existing_ref.feature_value_member,
                _syside.LiteralBoolean,
                new_node_ir.is_editable,
            )
        else:
            _, attr = meta.children.append(
                _syside.OwningMembership, _syside.ReferenceUsage
            )
            attr.heritage.insert(
                0,
                _syside.Redefinition,
                ctx.meta_tags.reqif_tag.is_editable_field,
            )
            set_literal_value(
                attr.feature_value_member,
                _syside.LiteralBoolean,
                new_node_ir.is_editable,
            )
    elif sub_field == "description":
        set_or_update_description(node_elem, new_node_ir.description)
    else:
        raise ValueError(
            f"{_OWNER_KIND_LABEL} {new_ir.name!r}: unhandled hierarchy node "
            f"sub-field {sub_field!r} on node {node_id!r}"
        )


def _add_hierarchy_node(
    spec_elem: _syside.RequirementDefinition,
    node_id: str,
    spec_ir: ir.Specification,
    ctx: BuildContext,
) -> None:
    """
    Materialise a new ``SpecHierarchyNode`` (and its descendants) under
    the SysML element corresponding to its IR-parent.

    Top-level nodes go into ``spec_elem`` directly with the
    Specification's ``ReqIF.Prefix`` (instance override or type
    default). Nested nodes go into the parent SpecHierarchyNode's
    SpecObject ``RequirementDefinition`` — same rule fresh import
    follows in :func:`_write_hierarchy_node` — and don't carry a
    name prefix.

    The new ``RequirementUsage`` is appended at the end of the SysML
    parent's children list. ``update_specification`` runs
    :func:`_renumber_hierarchy` after the batch to align every node's
    ``declared_name`` with its position in ``new_ir``.
    """
    located = _locate_hierarchy_node(spec_ir, node_id)
    if located is None:
        raise ValueError(
            f"{_OWNER_KIND_LABEL} {spec_ir.name!r}: hierarchy node {node_id!r} "
            f"marked as added but missing from new IR"
        )
    parent_ir, new_node_ir, placeholder_ordinal = located

    if parent_ir is spec_ir:
        sysml_parent: _syside.Namespace = spec_elem
        prefix = _resolve_specification_prefix(spec_elem, spec_ir, ctx)
    else:
        assert isinstance(parent_ir, ir.SpecHierarchyNode)
        sysml_parent = ctx.spec_object(parent_ir.spec_object_ref.id)
        prefix = None

    # ``placeholder_ordinal`` is purely a placeholder for ``declared_name``
    # — the renumber pass overwrites it from the final IR position once
    # all hierarchy edits in the batch have landed.
    _write_hierarchy_node(
        sysml_parent, placeholder_ordinal, new_node_ir, ctx, name_prefix=prefix
    )


def _remove_hierarchy_node(node_id: str, ctx: BuildContext) -> None:
    """
    Idempotently extract the ``RequirementUsage`` for ``node_id`` from
    its SysML parent. Descendants of the removed node live inside the
    SpecObject's ``RequirementDefinition`` (a sibling subtree, not
    under this usage), so they are deliberately left in place — the
    diff emits a separate ``hierarchy_node[X]`` remove for each
    descendant when the whole subtree is dropped.
    """
    extract_tracked_element(node_id, ctx, _syside.RequirementUsage)


def _renumber_hierarchy(
    spec_elem: _syside.RequirementDefinition,
    spec_ir: ir.Specification,
    ctx: BuildContext,
) -> None:
    """
    Walk ``spec_ir`` and rewrite each materialised hierarchy node's
    ``declared_name`` to ``_hierarchy_node_declared_name(prefix, ordinal)``.

    Top-level nodes get the Specification's ``ReqIF.Prefix``; nested
    nodes get ``None`` (matching :func:`_write_hierarchy_node`). The
    SysML children-list order is left as-is — :func:`parse_model_to_ir`
    uses identifiers to associate hierarchy children with IR nodes,
    not container position, and the diff fields are flat
    ``hierarchy_node[X]`` keys with no positional component.
    """
    prefix = _resolve_specification_prefix(spec_elem, spec_ir, ctx)
    for ordinal, node_ir in enumerate(spec_ir.children.values(), start=1):
        _renumber_subtree(ordinal, node_ir, prefix, ctx)


def _renumber_subtree(
    ordinal: int,
    node_ir: ir.SpecHierarchyNode,
    prefix: str | None,
    ctx: BuildContext,
) -> None:
    node_elem = ctx.refs.get(node_ir.id)
    if isinstance(node_elem, _syside.RequirementUsage):
        node_elem.declared_name = _hierarchy_node_declared_name(prefix, ordinal)
    for child_ordinal, child_ir in enumerate(node_ir.children.values(), start=1):
        _renumber_subtree(child_ordinal, child_ir, None, ctx)


def _resolve_specification_prefix(
    spec_elem: _syside.RequirementDefinition,
    spec_ir: ir.Specification,
    ctx: BuildContext,
) -> str | None:
    """
    Return the ``ReqIF.Prefix`` value applied to top-level hierarchy
    nodes of ``spec_elem``.

    Mirrors :func:`create_specifications`: an instance-level
    ``ReqIF.Prefix`` AttributeUsage on the Specification overrides the
    SpecificationType's default. The type-level default is captured
    incrementally on fresh import via
    :data:`BuildContext.prefix_default_map`; the delta path doesn't run
    that creation pass, so when the map is empty we fall back to
    reading the default literal off the type's ``ReqIF.Prefix``
    AttributeUsage directly.
    """
    for attr in spec_ir.attributes.values():
        if (
            attr.attr_def_ref.name == "ReqIF.Prefix"
            and isinstance(attr.value, str)
            and attr.value
        ):
            return attr.value
    spec_type_ref = ctx.spec_type_req(spec_ir.type_ref.id)
    cached = ctx.prefix_default_map.get(spec_type_ref)
    if cached is not None:
        return cached
    return _read_default_prefix_from_type(spec_type_ref)


def _read_default_prefix_from_type(
    spec_type_ref: _syside.RequirementDefinition,
) -> str | None:
    """
    Read the default literal value of ``spec_type_ref``'s direct
    ``ReqIF.Prefix`` AttributeUsage child, or ``None`` if none is set.
    """
    for attr in iter_children_of_type(spec_type_ref, _syside.AttributeUsage):
        if attr.declared_name != "ReqIF.Prefix":
            continue
        expr = attr.feature_value_member.member_element
        if isinstance(expr, _syside.LiteralString):
            return expr.value
    return None
