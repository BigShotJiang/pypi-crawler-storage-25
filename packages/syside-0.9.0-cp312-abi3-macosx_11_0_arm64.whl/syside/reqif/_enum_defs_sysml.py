import re

import _syside

import syside.reqif._ir_model as ir

from syside.reqif._sysml_metadata import (
    add_reqif_tag,
    obtain_metadata_tag,
    set_redefined_string,
    set_redefined_value,
)
from syside.reqif._sysml_utils import (
    BuildContext,
    set_or_update_description,
)


_OWNER_KIND_LABEL = "EnumDef"
_ENUM_VALUE_FIELD_RE = re.compile(
    r"^enum_value\[(?P<id>[^\]]+)\](?:\.(?P<sub>[a-z_]+))?$"
)


def create_enum_defs(
    package: _syside.Package,
    datatypes: dict[str, ir.DatatypeDef[ir.DatatypeProps]],
    ctx: BuildContext,
) -> None:
    """
    Write **new** Enum Defs into the given package.

    This function adds ID -> SysMLv2 element references back to BuildContext's ``refs`` dict.
    """
    for datatype in datatypes.values():
        if not ir.kind_of(datatype, ir.EnumProps):
            continue

        _, enum_def = package.children.append(
            _syside.OwningMembership, _syside.EnumerationDefinition
        )
        enum_def.declared_name = datatype.name

        # Add base reqif tag
        add_reqif_tag(
            enum_def,
            ctx.meta_tags.reqif_tag,
            identifier=datatype.id,
            last_change=datatype.last_change,
        )

        # Set description
        if datatype.description:
            set_or_update_description(enum_def, datatype.description)

        ctx.refs[datatype.id] = enum_def

        # Add enum values
        for value in datatype.props.values.values():
            _, enum_value = enum_def.children.append(
                _syside.OwningMembership, _syside.EnumerationUsage
            )
            enum_value.declared_name = value.name

            # Add reqif_enum_value tag
            extra: dict[_syside.AttributeUsage, str | int | float | bool] = {}
            if value.key is not None:
                extra[ctx.meta_tags.reqif_enum_value_tag.key_field] = value.key
            if value.other_content is not None:
                extra[ctx.meta_tags.reqif_enum_value_tag.other_content_field] = (
                    value.other_content
                )
            add_reqif_tag(
                enum_value,
                ctx.meta_tags.reqif_enum_value_tag,
                identifier=value.id,
                last_change=value.last_change,
                extra=extra,
            )

            # Set description
            if value.description:
                set_or_update_description(enum_value, value.description)

            ctx.refs[value.id] = enum_value


def update_enum_def(
    existing: _syside.EnumerationDefinition,
    element_delta: ir.ElementDelta,
    new_ir: ir.DatatypeDef[ir.EnumProps],
    ctx: BuildContext,
) -> _syside.Url:
    """
    Apply IR-level changes to an existing SysMLv2 EnumerationDefinition
    (the SysMLv2 representation of an enum DatatypeDef).

    Handles top-level fields (``name`` / ``description`` / ``last_change``)
    and ``enum_value[X]`` add / remove / sub-field edit
    (``name`` / ``description`` / ``key`` / ``other_content`` /
    ``last_change``). The DatatypeDef-level ``kind`` field raises
    :class:`NotImplementedError` because changing kind to a scalar drops
    the EnumerationDefinition entirely and re-emits ``@reqif_string`` /
    etc. tags on every AttributeUsage that referenced this enum, which
    is a cross-document operation deferred for now.
    """
    for change in element_delta.changes:
        field = change.field
        if field == "name":
            existing.declared_name = new_ir.name
        elif field == "description":
            set_or_update_description(existing, new_ir.description)
        elif field == "last_change":
            _update_enum_def_last_change(existing, new_ir.last_change, ctx)
        elif field == "kind":
            raise NotImplementedError(
                f"{_OWNER_KIND_LABEL} {new_ir.name!r}: kind change "
                f"({change.old} -> {change.new}) is a cross-paradigm "
                f"replacement and is not yet supported"
            )
        elif (m := _ENUM_VALUE_FIELD_RE.match(field)) is not None:
            _update_enum_value(existing, change, m, new_ir, ctx)
        else:
            raise ValueError(
                f"{_OWNER_KIND_LABEL} {new_ir.name!r}: unhandled delta field {field!r}"
            )

    return existing.document.url


def _update_enum_def_last_change(
    existing: _syside.EnumerationDefinition,
    new_last_change: str | None,
    ctx: BuildContext,
) -> None:
    if new_last_change is None:
        return
    meta = obtain_metadata_tag(existing, ctx.meta_tags.reqif_tag.metadata_elem)
    if meta is None:
        raise ValueError(
            f"missing @reqif tag on EnumerationDefinition {existing.declared_name!r}"
        )
    set_redefined_string(
        meta, ctx.meta_tags.reqif_tag.last_change_field, new_last_change
    )


def _update_enum_value(
    existing: _syside.EnumerationDefinition,
    change: ir.FieldChange,
    match: re.Match[str],
    new_ir: ir.DatatypeDef[ir.EnumProps],
    ctx: BuildContext,
) -> None:
    value_id = match.group("id")
    sub_field = match.group("sub")

    if sub_field is None:
        # Whole-value add or remove.
        if change.old is None:
            new_value = new_ir.props.values[value_id]
            _create_enum_value(existing, new_value, ctx)
            return
        # Removed
        value_elem = ctx.refs.get(value_id)
        if value_elem is None:
            return  # idempotent
        for index, child in enumerate(existing.children.elements):
            if child is value_elem:
                existing.children.extract(index)
                return
        # Element exists in ctx.refs but not as a child here — surfaced as
        # a workspace-state mismatch rather than silently ignored.
        raise ValueError(
            f"{_OWNER_KIND_LABEL} {new_ir.name!r}: enum value {value_id!r} "
            f"in ctx.refs but not a child of EnumerationDefinition "
            f"{existing.declared_name!r}"
        )

    # Sub-field edit on an existing enum value.
    value_elem = ctx.refs.get(value_id)
    if value_elem is None:
        raise ValueError(
            f"{_OWNER_KIND_LABEL} {new_ir.name!r}: enum value {value_id!r} "
            f"has changes but is not present in the SysML workspace"
        )
    if not isinstance(value_elem, _syside.EnumerationUsage):
        raise ValueError(
            f"{_OWNER_KIND_LABEL} {new_ir.name!r}: expected EnumerationUsage "
            f"for enum value {value_id!r}, got {type(value_elem).__name__}"
        )
    new_value = new_ir.props.values[value_id]

    if sub_field == "name":
        value_elem.declared_name = new_value.name
    elif sub_field == "description":
        set_or_update_description(value_elem, new_value.description)
    elif sub_field in ("key", "other_content", "last_change"):
        _update_enum_value_tag_field(value_elem, sub_field, new_value, ctx)
    else:
        raise ValueError(
            f"{_OWNER_KIND_LABEL} {new_ir.name!r}: unhandled enum-value "
            f"sub-field {sub_field!r} on {value_id!r}"
        )


def _update_enum_value_tag_field(
    value_elem: _syside.EnumerationUsage,
    sub_field: str,
    new_value: ir.EnumValue,
    ctx: BuildContext,
) -> None:
    """Update one redefined field on an enum value's @reqif_enum_value tag."""
    meta = obtain_metadata_tag(
        value_elem, ctx.meta_tags.reqif_enum_value_tag.metadata_elem
    )
    if meta is None:
        raise ValueError(
            f"missing @reqif_enum_value tag on EnumerationUsage "
            f"{value_elem.declared_name!r}"
        )
    if sub_field == "key":
        if new_value.key is None:
            return  # no clean "unset"
        set_redefined_value(
            meta, ctx.meta_tags.reqif_enum_value_tag.key_field, new_value.key
        )
    elif sub_field == "other_content":
        if new_value.other_content is None:
            return
        set_redefined_string(
            meta,
            ctx.meta_tags.reqif_enum_value_tag.other_content_field,
            new_value.other_content,
        )
    elif sub_field == "last_change":
        if new_value.last_change is None:
            return
        set_redefined_string(
            meta,
            ctx.meta_tags.reqif_tag.last_change_field,
            new_value.last_change,
        )


def _create_enum_value(
    existing: _syside.EnumerationDefinition,
    value: ir.EnumValue,
    ctx: BuildContext,
) -> None:
    """Append a new EnumerationUsage with @reqif_enum_value tag."""
    _, enum_value = existing.children.append(
        _syside.OwningMembership, _syside.EnumerationUsage
    )
    enum_value.declared_name = value.name

    extra: dict[_syside.AttributeUsage, str | int | float | bool] = {}
    if value.key is not None:
        extra[ctx.meta_tags.reqif_enum_value_tag.key_field] = value.key
    if value.other_content is not None:
        extra[ctx.meta_tags.reqif_enum_value_tag.other_content_field] = (
            value.other_content
        )

    add_reqif_tag(
        enum_value,
        ctx.meta_tags.reqif_enum_value_tag,
        identifier=value.id,
        last_change=value.last_change,
        extra=extra,
    )

    if value.description:
        set_or_update_description(enum_value, value.description)

    ctx.refs[value.id] = enum_value
