from pathlib import Path

from syside.reqif._ir_model import Model as ir_Model
from syside.reqif._reqif_utils import load_reqif
from syside.reqif._datatypes_reqif import read_datatype_defs_to_ir
from syside.reqif._spec_types_reqif import read_spec_types_to_ir
from syside.reqif._spec_objects_reqif import read_spec_objects_to_ir
from syside.reqif._specifications_reqif import read_specifications_to_ir
from syside.reqif._spec_relations_reqif import read_spec_relations_to_ir
from syside.reqif._relation_groups_reqif import read_relation_groups_to_ir


def load_and_parse_reqif_to_ir(file_path: Path, attachments_dir: Path) -> ir_Model:

    reqif_bundle = load_reqif(file_path, attachments_dir)

    core_content = reqif_bundle.core_content
    if core_content is None:
        raise ValueError("ReqIF has no content or is corrupted")

    reqif_content = core_content.req_if_content
    if reqif_content is None:
        raise ValueError("ReqIF has no content or is corrupted")

    attachments_dir_str = str(attachments_dir)
    datatype_defs = read_datatype_defs_to_ir(reqif_content)
    spec_types = read_spec_types_to_ir(
        reqif_content, datatype_defs, attachments_dir_str
    )
    spec_objects = read_spec_objects_to_ir(
        reqif_content, spec_types, attachments_dir_str
    )
    specifications = read_specifications_to_ir(
        reqif_content, spec_types, spec_objects, attachments_dir_str
    )
    spec_relations = read_spec_relations_to_ir(reqif_content, spec_types, spec_objects)
    relation_groups = read_relation_groups_to_ir(
        reqif_content, spec_types, spec_relations, specifications
    )

    # Local import: _cmd_check imports from this module, so a top-level
    # import would cycle.
    from syside.reqif._cmd_check import _check_that_all_datatypedefs_are_referenced

    unpruned = ir_Model(
        datatype_defs=datatype_defs,
        spec_types=spec_types,
        spec_objects=spec_objects,
        specifications=specifications,
        spec_relations=spec_relations,
        relation_groups=relation_groups,
    )
    _check_that_all_datatypedefs_are_referenced(unpruned)

    # FIXME #44: Figure out how to handle unreferenced Datatype Defs in SysMLv2 side
    # Prune unreferenced Datatype Defs: the SysMLv2 embedding has no carrier
    # for a Datatype Def that no Attribute Def points at, so keeping them in
    # the IR would break the ReqIF<->SysML equality oracle (#44).
    referenced_ids = {
        attr.props.datatype_def.id
        for st in spec_types.values()
        for attr in st.attribute_defs.values()
    }
    datatype_defs = {
        id_: dt for id_, dt in datatype_defs.items() if id_ in referenced_ids
    }

    model = ir_Model(
        datatype_defs=datatype_defs,
        spec_types=spec_types,
        spec_objects=spec_objects,
        specifications=specifications,
        spec_relations=spec_relations,
        relation_groups=relation_groups,
    )

    return model
