import re
from typing import cast

from . import _ir_model as ir

import _syside
from syside.reqif._sysml_utils import (
    BuildContext,
    iter_heritage_rels_of_type,
    set_literal_value,
    set_or_update_description,
    set_signed_integer_literal,
)
from syside.reqif._sysml_metadata import (
    add_reqif_tag,
    create_metadata_prefix,
    obtain_metadata_tag,
    set_redefined_string,
    set_redefined_value,
)
from syside.reqif._attribute_values_sysml import SCALAR_TYPE_INFO
from syside.reqif._datatypes_sysml import _datatype_extra, create_attribute_def


_OWNER_KIND_LABEL = "SpecType"
_ATTR_DEF_FIELD_RE = re.compile(
    r"^attribute_def\[(?P<id>[^\]]+)\](?:\.(?P<sub>[a-z_]+))?$"
)


_SPEC_TYPE_CONFIG: dict[ir.SpecKind, tuple[type[_syside.Definition], bool, str]] = {
    ir.SpecKind.OBJECT: (
        _syside.RequirementDefinition,
        True,
        "reqif_spec_object_type_prefix",
    ),
    ir.SpecKind.SPECIFICATION: (
        _syside.RequirementDefinition,
        True,
        "reqif_specification_type_prefix",
    ),
    ir.SpecKind.RELATION: (
        _syside.ConnectionDefinition,
        False,
        "reqif_spec_relation_type_prefix",
    ),
    ir.SpecKind.RELATION_GROUP: (
        _syside.OccurrenceDefinition,
        True,
        "reqif_relation_group_type_prefix",
    ),
}


def create_spec_types(
    package: _syside.Package,
    spectypes: dict[str, ir.SpecType[ir.SpecKind]],
    ctx: BuildContext,
) -> None:
    """
    Write **new** SpecType elements into the given package.

    This function adds ID -> SysMLv2 element references back to BuildContext's ``refs`` dict.
    """
    for spec_type in spectypes.values():
        sysml_cls, is_abstract, prefix_attr = _SPEC_TYPE_CONFIG[spec_type.kind]

        _, element = package.children.append(_syside.OwningMembership, sysml_cls)
        element.declared_name = spec_type.name
        if is_abstract:
            element.is_abstract = True

        create_metadata_prefix(element, getattr(ctx.meta_prefixes, prefix_attr))

        add_reqif_tag(
            element,
            ctx.meta_tags.reqif_tag,
            identifier=spec_type.id,
            last_change=spec_type.last_change,
        )

        if spec_type.description:
            set_or_update_description(element, spec_type.description)

        for attr_def in spec_type.attribute_defs.values():
            default_pref = create_attribute_def(element, attr_def, ctx)
            if default_pref:
                ctx.prefix_default_map[element] = default_pref

        if spec_type.kind == ir.SpecKind.RELATION:
            _, source_end = element.children.append(
                _syside.FeatureMembership, _syside.ReferenceUsage
            )
            source_end.declared_name = "source_requirement"
            source_end.is_end = True

            _, target_end = element.children.append(
                _syside.FeatureMembership, _syside.ReferenceUsage
            )
            target_end.declared_name = "target_requirement"
            target_end.is_end = True

        ctx.refs[spec_type.id] = element


def update_spec_type(
    existing: _syside.Definition,
    element_delta: ir.ElementDelta,
    new_ir: ir.SpecType[ir.SpecKind],
    ctx: BuildContext,
) -> _syside.Url:
    """
    Apply IR-level changes to an existing SysMLv2 SpecType element
    (the abstract ``RequirementDefinition`` /
    ``OccurrenceDefinition`` / ``ConnectionDefinition`` produced by
    :func:`create_spec_types`).

    Handles top-level fields and ``attribute_def[X]`` add / remove /
    sub-field edit. The ``kind`` field raises :class:`NotImplementedError`
    because changing kind would replace the SysMLv2 element class
    entirely (and ripple through every SpecObject / Specification /
    SpecRelation / RelationGroup that subclassifies it). Two AttrDef
    sub-fields are also deferred:

    * ``attribute_def[X].kind`` — flips the AttrDef from one scalar
      family to another (or to/from enum); rewrites the FeatureTyping,
      the datatype-marker tag class, and any default value. Deferred.
    * ``attribute_def[X].multi_valued`` — handled (just rebuilds the
      ``MultiplicityRange``).
    """
    for change in element_delta.changes:
        field = change.field
        if field == "name":
            existing.declared_name = new_ir.name
        elif field == "description":
            set_or_update_description(existing, new_ir.description)
        elif field == "last_change":
            _update_spec_type_last_change(existing, new_ir.last_change, ctx)
        elif field == "kind":
            raise NotImplementedError(
                f"{_OWNER_KIND_LABEL} {new_ir.name!r}: kind change "
                f"({change.old} -> {change.new}) replaces the SysMLv2 element "
                f"class and is not yet supported"
            )
        elif (m := _ATTR_DEF_FIELD_RE.match(field)) is not None:
            _update_attribute_def(existing, change, m, new_ir, ctx)
        else:
            raise ValueError(
                f"{_OWNER_KIND_LABEL} {new_ir.name!r}: unhandled delta field {field!r}"
            )

    return existing.document.url


def _update_spec_type_last_change(
    existing: _syside.Definition,
    new_last_change: str | None,
    ctx: BuildContext,
) -> None:
    if new_last_change is None:
        return
    meta = obtain_metadata_tag(existing, ctx.meta_tags.reqif_tag.metadata_elem)
    if meta is None:
        raise ValueError(
            f"missing @reqif tag on {type(existing).__name__} "
            f"{existing.declared_name!r}"
        )
    set_redefined_string(
        meta, ctx.meta_tags.reqif_tag.last_change_field, new_last_change
    )


def _find_attr_def_index(
    existing: _syside.Definition, attr_def: _syside.AttributeUsage
) -> int | None:
    """Return the child-index of the AttributeUsage ``attr_def`` on ``existing``."""
    for index, child in enumerate(existing.children.elements):
        if child is attr_def:
            return index
    return None


def _update_attribute_def(
    existing: _syside.Definition,
    change: ir.FieldChange,
    match: re.Match[str],
    new_ir: ir.SpecType[ir.SpecKind],
    ctx: BuildContext,
) -> None:
    attr_id = match.group("id")
    sub_field = match.group("sub")

    if sub_field is None:
        # Whole-AttrDef add or remove.
        if change.old is None:
            new_attr_def = new_ir.attribute_defs[attr_id]
            _ = create_attribute_def(existing, new_attr_def, ctx)
            return
        # Removed.
        attr_elem = ctx.refs.get(attr_id)
        if attr_elem is None:
            return  # already gone; idempotent
        if not isinstance(attr_elem, _syside.AttributeUsage):
            raise ValueError(
                f"{_OWNER_KIND_LABEL} {new_ir.name!r}: expected AttributeUsage "
                f"for AttributeDef {attr_id!r}, got {type(attr_elem).__name__}"
            )
        index = _find_attr_def_index(existing, attr_elem)
        if index is None:
            return  # belongs to a different SpecType in this workspace
        existing.children.extract(index)
        return

    # Sub-field edit on an existing AttrDef.
    attr_elem = ctx.refs.get(attr_id)
    if attr_elem is None:
        raise ValueError(
            f"{_OWNER_KIND_LABEL} {new_ir.name!r}: AttributeDef {attr_id!r} "
            f"has changes but is not present in the SysML workspace"
        )
    if not isinstance(attr_elem, _syside.AttributeUsage):
        raise ValueError(
            f"{_OWNER_KIND_LABEL} {new_ir.name!r}: expected AttributeUsage "
            f"for AttributeDef {attr_id!r}, got {type(attr_elem).__name__}"
        )
    new_attr_def = new_ir.attribute_defs[attr_id]

    if sub_field == "name":
        attr_elem.declared_name = new_attr_def.name
    elif sub_field == "description":
        # Per project convention, AttrDef descriptions go into an unnamed
        # Documentation child (not a field on the @reqif tag).
        set_or_update_description(attr_elem, new_attr_def.description)
    elif sub_field == "last_change":
        if new_attr_def.last_change is None:
            return
        meta = obtain_metadata_tag(attr_elem, ctx.meta_tags.reqif_tag.metadata_elem)
        if meta is None:
            raise ValueError(f"missing @reqif tag on AttributeUsage {attr_id!r}")
        set_redefined_string(
            meta,
            ctx.meta_tags.reqif_tag.last_change_field,
            new_attr_def.last_change,
        )
    elif sub_field == "is_editable":
        meta = obtain_metadata_tag(attr_elem, ctx.meta_tags.reqif_tag.metadata_elem)
        if meta is None:
            raise ValueError(f"missing @reqif tag on AttributeUsage {attr_id!r}")
        set_redefined_value(
            meta,
            ctx.meta_tags.reqif_tag.is_editable_field,
            new_attr_def.is_editable,
        )
    elif sub_field == "default_value":
        _update_attr_def_default_value(attr_elem, new_attr_def, ctx)
    elif sub_field == "multi_valued":
        _update_attr_def_multi_valued(attr_elem, new_attr_def)
    elif sub_field == "datatype_def":
        _rebuild_attr_def_datatype_tag(attr_elem, new_attr_def, ctx)
    elif sub_field == "kind":
        raise NotImplementedError(
            f"{_OWNER_KIND_LABEL} {new_ir.name!r}: AttributeDef {attr_id!r} "
            f"kind change is not yet supported"
        )
    else:
        raise ValueError(
            f"{_OWNER_KIND_LABEL} {new_ir.name!r}: unhandled AttrDef sub-field "
            f"{sub_field!r} on {attr_id!r}"
        )


def _update_attr_def_default_value(
    attr_elem: _syside.AttributeUsage,
    new_attr_def: ir.AttributeDef[ir.AttributeDefProps],
    ctx: BuildContext,
) -> None:
    """Rewrite the AttributeUsage's ``feature_value`` to match the new IR default."""
    new_default = new_attr_def.props.default_value
    if new_default is None:
        # Drop whatever was there. ``set_member_element`` doesn't have an
        # explicit "clear" — overwriting with a no-op-ish element would
        # be fragile. The ``feature_value_member`` accessor exposes
        # ``remove_member_element`` for this case.
        attr_elem.feature_value_member.remove_member_element()
        return

    info = SCALAR_TYPE_INFO.get(type(new_attr_def.props))
    if info is not None:
        if info.literal_cls == "signed_int":
            membership = set_signed_integer_literal(
                attr_elem.feature_value_member, cast(int, new_default)
            )
        else:
            membership = set_literal_value(
                attr_elem.feature_value_member,
                info.literal_cls,
                cast(str | int | float | bool, new_default),
            )
        membership.is_default = True
        return

    if ir.kind_of(new_attr_def, ir.EnumAttrDef):
        assert isinstance(new_default, ir.EnumValue)
        enum_val_ref = ctx.enum_value(new_default.id)
        membership, expr = attr_elem.feature_value_member.set_member_element(
            _syside.FeatureReferenceExpression
        )
        expr.referent_member.set_member_element(enum_val_ref)
        membership.is_default = True
        return

    raise ValueError(
        f"unexpected AttributeDef props type {type(new_attr_def.props).__name__}"
    )


def _update_attr_def_multi_valued(
    attr_elem: _syside.AttributeUsage,
    new_attr_def: ir.AttributeDef[ir.AttributeDefProps],
) -> None:
    """Rebuild the ``MultiplicityRange`` from scratch to reflect ``multi_valued``."""
    if not ir.kind_of(new_attr_def, ir.EnumAttrDef):
        # Only EnumAttrDef carries ``multi_valued`` — the diff shouldn't
        # produce this field for other kinds, but guard regardless.
        return
    multi_valued = new_attr_def.props.multi_valued

    _, multiplicity = attr_elem.declared_multiplicity_member.set_member_element(
        _syside.MultiplicityRange
    )
    _, range_expr = multiplicity.bounds_expression_member.set_member_element(
        _syside.OperatorExpression
    )
    range_expr.operator = _syside.ExplicitOperator.Range
    _, lower_val = range_expr.arguments.append(_syside.LiteralInteger)
    lower_val.value = 0
    if multi_valued:
        range_expr.arguments.append(_syside.LiteralInfinity)
    else:
        _, higher_val = range_expr.arguments.append(_syside.LiteralInteger)
        higher_val.value = 1


def _rebuild_attr_def_datatype_tag(
    attr_elem: _syside.AttributeUsage,
    new_attr_def: ir.AttributeDef[ir.AttributeDefProps],
    ctx: BuildContext,
) -> None:
    """
    Replace the AttrDef's datatype-marker MetadataUsage with a fresh one
    pointing at the new DatatypeDef.

    Only valid for scalar AttrDefs — enum AttrDefs don't carry a
    datatype-marker tag (the EnumerationDefinition is the typing
    target instead). The diff only emits ``datatype_def`` when the
    AttrDef kind is unchanged, so we won't see this for enum→scalar
    transitions.
    """
    info = SCALAR_TYPE_INFO.get(type(new_attr_def.props))
    if info is None:
        # Enum: no datatype tag to rebuild.
        return
    new_tag = getattr(ctx.meta_tags, info.tag_attr)

    # Find and drop the existing datatype-marker tag (any MetadataUsage
    # whose typing isn't the base @reqif).
    for index, child in enumerate(attr_elem.children.elements):
        meta = child.try_cast(_syside.MetadataUsage)
        if meta is None:
            continue
        # The base @reqif tag stays.
        is_base = any(
            t.first_target is ctx.meta_tags.reqif_tag.metadata_elem
            for t in iter_heritage_rels_of_type(meta, _syside.FeatureTyping)
        )
        if is_base:
            continue
        attr_elem.children.extract(index)
        break

    # Add the new tag.
    add_reqif_tag(
        attr_elem,
        new_tag,
        identifier=new_attr_def.props.datatype_def.id,
        last_change=new_attr_def.props.datatype_def.last_change,
        extra=_datatype_extra(new_tag, new_attr_def.props.datatype_def),
    )
