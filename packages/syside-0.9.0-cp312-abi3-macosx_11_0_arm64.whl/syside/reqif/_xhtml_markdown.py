from __future__ import annotations

import os
import re
from collections.abc import Callable, Collection

from bs4 import BeautifulSoup
from bs4.element import NavigableString, Tag
from markdown_it import MarkdownIt
from markdownify import MarkdownConverter


_IMAGE_MIMES: dict[str, str] = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".svg": "image/svg+xml",
    ".bmp": "image/bmp",
    ".webp": "image/webp",
}

_NS = "reqif-xhtml:"
_XHTML_WRAPPER = f"<{_NS}div>{{}}</{_NS}div>"

_INLINE_SYNONYMS: dict[str, str] = {"strong": "b", "em": "i", "s": "del", "code": "tt"}
_HEADING_TAGS = ["h1", "h2", "h3", "h4", "h5", "h6"]
_BLOCK_TAGS = frozenset(
    {"p", "div", "ul", "ol", "blockquote", "pre", "table", *_HEADING_TAGS}
)


_ConvertFn = Callable[[MarkdownConverter, Tag, str, Collection[str]], str]


def _inline_wrap(opener: str, closer: str | None = None) -> _ConvertFn:
    """
    Build a markdownify ``convert_*`` method that wraps inline text.

    Mirrors markdownify's internal ``abstract_inline_conversion`` (not exported
    in the type stubs): chomps surrounding whitespace onto the outside of the
    markers so output like ``** bold **`` never occurs.
    """
    close = closer if closer is not None else opener

    def convert(
        self: MarkdownConverter,
        el: Tag,
        text: str,
        parent_tags: Collection[str],
    ) -> str:
        if "_noformat" in parent_tags:
            return text
        prefix = " " if text.startswith(" ") else ""
        suffix = " " if text.endswith(" ") else ""
        text = text.strip()
        if not text:
            return ""
        return f"{prefix}{opener}{text}{close}{suffix}"

    return convert


class _ReqIFMarkdownConverter(MarkdownConverter):
    """
    Emit ``_italic_`` (not ``*italic*``) while keeping ``**bold**``.

    Also passes ``<sup>`` / ``<sub>`` through as raw HTML since they have no
    Markdown equivalent.
    """

    convert_em = _inline_wrap("_")
    convert_i = convert_em
    convert_sup = _inline_wrap("<sup>", "</sup>")
    convert_sub = _inline_wrap("<sub>", "</sub>")


def _image_mime(path: str) -> str:
    ext = os.path.splitext(path)[1].lower()
    return _IMAGE_MIMES.get(ext, "application/octet-stream")


# ---------------------------------------------------------------------------
# XHTML → Markdown (import)
# ---------------------------------------------------------------------------


def _rewrite_reqif_tags(soup: BeautifulSoup, attachments_dir: str) -> None:
    """
    Rewrite ReqIF-specific tags in-place into plain HTML understood by
    markdownify.
    """
    # Images in ReqIF are embedded in <object> tags.
    for obj in list(soup.find_all("object")):
        mime = str(obj.get("type", "") or "")
        data = str(obj.get("data", "") or "")
        if mime.startswith("image/") and data:
            img = soup.new_tag("img")
            img["src"] = f"{attachments_dir}/{data}"
            img["alt"] = os.path.basename(data)
            obj.replace_with(img)
        else:
            obj.decompose()

    for el in soup.find_all("cite"):
        el.name = "em"
    for el in soup.find_all("tt"):
        el.name = "code"


def xhtml_to_markdown(
    xhtml_input: str | BeautifulSoup | None,
    attachments_dir: str = "attachments",
) -> str:
    """
    Convert XHTML content to Markdown.

    Accepts either an XML string or a pre-parsed ``BeautifulSoup`` tree. When
    a string is given it is parsed with the ``lxml-xml`` parser so that
    namespace prefixes (``reqif-xhtml:``) are stripped from tag names.
    """
    if xhtml_input is None:
        return ""

    if isinstance(xhtml_input, BeautifulSoup):
        soup = xhtml_input
    else:
        text = xhtml_input.strip()
        if not text:
            return ""
        soup = BeautifulSoup(text, "lxml-xml")

    _rewrite_reqif_tags(soup, attachments_dir)

    md = (
        _ReqIFMarkdownConverter(
            heading_style="ATX",
            bullets="-",
            escape_asterisks=False,
            escape_underscores=False,
            escape_misc=False,
        )
        .convert_soup(soup)
        .strip()
    )

    # Break up SysML /* ... */ comment delimiters. CommonMark treats \/ and \*
    # as escaped punctuation and restores them verbatim on re-parse.
    md = md.replace("*/", "*\\/")
    # Backslash-escape apostrophes so they cannot mess with SysML unrestricted
    # names ('name'). CommonMark treats \' as escaped punctuation and restores
    # the literal on re-parse.
    md = md.replace("'", "\\'")
    return md


# ---------------------------------------------------------------------------
# Markdown → XHTML (export)
# ---------------------------------------------------------------------------

_NON_COLLAPSE_TAGS = ("b", "i", "em")


def _transform_html_to_xhtml_body(html: str, attachments_dir: str) -> str:
    """Transform markdown-it HTML output into ReqIF-compliant XHTML body."""
    soup = BeautifulSoup(html, "html.parser")

    # <pre><code>...</code></pre> → <pre>...</pre>
    for pre in soup.find_all("pre"):
        for code in list(pre.find_all("code")):
            code.unwrap()
        # markdown-it always appends a trailing newline inside fenced code;
        # strip it so the serialized <pre> matches the canonical form.
        for node in list(pre.contents):
            if isinstance(node, NavigableString):
                node.replace_with(node.rstrip("\n"))
                break

    # Inline synonyms → canonical ReqIF tags.
    for el in soup.find_all(list(_INLINE_SYNONYMS.keys())):
        el.name = _INLINE_SYNONYMS[el.name]

    # Headings → <p><b>…</b></p>. The implementation guide SHOULD NOT export <h*>.
    for h in soup.find_all(_HEADING_TAGS):
        h.name = "p"
        b = soup.new_tag("b")
        for child in list(h.contents):
            b.append(child.extract())
        h.append(b)

    # Tight-list <li>inline</li> → <li><p>inline</p></li> so the serialized
    # form matches the canonical ReqIF pattern. Skip items that already contain
    # a block-level child (nested list, paragraph from a heading, etc.).
    for li in soup.find_all("li"):
        has_block = any(
            isinstance(c, Tag) and c.name in _BLOCK_TAGS for c in li.children
        )
        if has_block:
            continue
        if not any(
            (isinstance(c, NavigableString) and c.strip()) or isinstance(c, Tag)
            for c in li.children
        ):
            continue
        p = soup.new_tag("p")
        for child in list(li.contents):
            p.append(child.extract())
        li.append(p)

    # <img> → <object>
    prefix = attachments_dir + "/"
    for img in list(soup.find_all("img")):
        src = str(img.get("src", "") or "")
        data = src.removeprefix(prefix)
        alt = str(img.get("alt") or "") or os.path.basename(data)
        mime = _image_mime(data)
        obj = soup.new_tag("object")
        obj["data"] = data
        obj["type"] = mime
        obj.string = alt
        img.replace_with(obj)

    # Unwrap a single top-level <p> so plaintext stays as inline content inside
    # the <div> wrapper, matching the canonical ReqIF pattern.
    top_tags = [c for c in soup.children if isinstance(c, Tag)]
    top_text = any(isinstance(c, NavigableString) and c.strip() for c in soup.children)
    if len(top_tags) == 1 and top_tags[0].name == "p" and not top_text:
        top_tags[0].unwrap()

    body = "".join(str(c) for c in soup.contents)

    # markdown-it emits "\n" between block elements for readability; collapse it
    # so the serialized form is tightly packed like the canonical ReqIF.
    # Avoid collapsing all whitespace between formating elements, as this breaks
    # conversion to markdown in cases such as <b>x</b><b>y</b> -> **x****y**.
    body = re.sub(r">\s+<", "><", body).strip()

    def conditional_space(m: re.Match[str]) -> str:
        tag = m.group(1)
        if tag in _NON_COLLAPSE_TAGS:
            return f"</{tag}> <{tag}>"
        else:
            return f"</{tag}><{tag}>"

    body = re.sub(r"</([^>]*)><\1>", conditional_space, body, flags=re.IGNORECASE)

    # Prefix every element name with the reqif-xhtml: namespace.
    body = re.sub(r"<(/?)([a-z][a-z0-9]*)", rf"<\1{_NS}\2", body, flags=re.IGNORECASE)

    return body


def markdown_to_xhtml(
    markdown_input: str | None,
    attachments_dir: str = "attachments",
) -> str:
    r"""
    Convert Markdown text to ReqIF-compatible simplified XHTML.

    Uses the recommended XHTML subset from the prostep ivip Implementation Guide Section 2.7
    (https://www.ps-ent-2023.de/fileadmin/prod-download/prostep-ivip_ImplementationGuide_ReqIF_V1-8.pdf):

    \<b>, \<i>, \<del>, \<tt> for inline; \<p>, \<ul>, \<ol>, \<blockquote>, \<pre>, \<table>, \<a>, \<object> for blocks.
    Headings are emitted as ``<p><b>text</b></p>``.

    Image paths have the *attachments_dir* prefix stripped so that the
    ``data`` attribute matches the original ReqIF value.
    """
    if not markdown_input:
        return ""

    md = MarkdownIt("commonmark", {"html": True, "xhtmlOut": True})
    md.enable("strikethrough")
    md.enable("table")
    html = md.render(markdown_input)

    if not html.strip():
        return ""

    body = _transform_html_to_xhtml_body(html, attachments_dir)
    if not body:
        return ""
    return _XHTML_WRAPPER.format(body)
