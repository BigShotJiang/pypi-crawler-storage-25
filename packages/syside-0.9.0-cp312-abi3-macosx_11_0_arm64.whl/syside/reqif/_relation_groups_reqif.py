from __future__ import annotations

from reqif.models.reqif_req_if_content import ReqIFReqIFContent
from reqif.models.reqif_relation_group import ReqIFRelationGroup

from . import _ir_model as ir
from ._reqif_utils import (
    ElementRef,
    decode_reqif_string,
    encode_reqif_string,
    resolve_spec_element_name,
    resolve_ref,
)


def read_relation_groups_to_ir(
    content: ReqIFReqIFContent,
    spec_types: dict[str, ir.SpecType[ir.SpecKind]],
    spec_relations: dict[str, ir.SpecRelation],
    specifications: dict[str, ir.Specification],
) -> dict[str, ir.RelationGroup]:
    """Extract all RELATION-GROUP entries into IR, keyed by ``RelationGroup.id``."""
    result: dict[str, ir.RelationGroup] = {}

    for group in content.spec_relation_groups or []:
        src = ElementRef("RELATION-GROUP", group.identifier)
        type_ref = resolve_ref(
            ref_id=group.type_ref,
            lookup=spec_types,
            src=src,
            ref_kind="type",
        )
        if not ir.kind_of(type_ref, ir.SpecKind.RELATION_GROUP):
            raise ValueError(
                f"RELATION-GROUP {group.identifier} is typed by some other type than RELATION-GROUP-TYPE {type_ref.id}"
            )

        name = resolve_spec_element_name(group, spec_types)

        source_ref = resolve_ref(
            ref_id=group.source_specification_ref,
            lookup=specifications,
            src=src,
            ref_kind="source",
        )

        target_ref = resolve_ref(
            ref_id=group.target_specification_ref,
            lookup=specifications,
            src=src,
            ref_kind="target",
        )

        # FIXME: Relation groups do not have attribute values in the
        # `redif` Python library, even though they are allowed in the spec
        # attributes = read_attrs(
        #     reqif_attrs=group.attributes or [],
        #     attr_defs_by_id=type_ref.attribute_defs,
        #     element_kind="RELATION-GROUP",
        #     element_id=group.identifier
        # )

        relations: dict[str, ir.SpecRelation] = {}
        for rel in group.spec_relations or []:
            relation_ref = resolve_ref(
                ref_id=rel,
                lookup=spec_relations,
                src=src,
                ref_kind="relation",
            )
            relations[relation_ref.id] = relation_ref

        result[group.identifier] = ir.RelationGroup(
            id=group.identifier,
            name=name,
            type_ref=type_ref,
            source_ref=source_ref,
            target_ref=target_ref,
            relations=relations,
            # attributes = attributes FIXME
            description=decode_reqif_string(group.description),
            last_change=group.last_change,
        )

    return result


def write_relation_groups_from_ir(
    relation_groups: dict[str, ir.RelationGroup],
) -> list[ReqIFRelationGroup]:
    """Convert IR relation groups to SPEC-RELATION objects."""
    result: list[ReqIFRelationGroup] = []

    for group in relation_groups.values():
        # FIXME: When reqif library supports attributes update this function to also take
        # into account set attributes, and inject ReqIF.Name
        # attrs = build_reqif_attrs_with_name_injection(
        #     ir_attributes=group.attributes,
        #     spec_type=group.type_ref,
        #     name=group.name,
        # )

        result.append(
            ReqIFRelationGroup(
                identifier=group.id,
                source_specification_ref=group.source_ref.id,
                target_specification_ref=group.target_ref.id,
                type_ref=group.type_ref.id,
                last_change=group.last_change,
                spec_relations=list(group.relations.keys()),
                long_name=encode_reqif_string(group.name),
                description=encode_reqif_string(group.description),
                # attributes=None,  # FIXME
            )
        )

    return result
