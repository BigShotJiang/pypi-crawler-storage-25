"""
Import shim for `syside.cli`
"""

from _syside.cli import *
