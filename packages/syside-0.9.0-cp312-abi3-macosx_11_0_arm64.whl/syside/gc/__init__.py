"""
Import shim for `syside.gc`
"""

from _syside.gc import *
