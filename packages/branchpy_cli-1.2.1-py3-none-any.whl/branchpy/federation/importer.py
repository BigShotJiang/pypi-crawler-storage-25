"""
branchpy.federation.importer — Share link import and resolution.

Handles:
- Share link resolution (token → payload → resource)
- Local resource import workflow
- Export archive creation
- Permission checks for import operations

Workflow:
1. User receives share token: branchpy-share://v1/...
2. System resolves token → validates signature → extracts payload
3. System locates resource in local state or archive
4. System imports resource to target project (with RBAC checks)

Performance: Import <100ms for typical resources.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from .config import load_federation_config
from .serializer import export_resource_to_file, import_resource_from_file
from .signed_links import InvalidShareTokenError, ShareTokenPayload, parse_share_token


@dataclass
class ShareImportResult:
    """Result from share link import operation."""

    success: bool
    resource_type: str
    resource_id: str
    imported_to_project_id: Optional[str] = None
    error_message: Optional[str] = None
    metadata: Optional[dict[str, Any]] = None

    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


class ShareImportError(Exception):
    """Raised when share import fails."""

    pass


def resolve_share_link_local(token: str, verify: bool = True) -> ShareTokenPayload:
    """
    Resolve share link token locally.

    Args:
        token: Share token string
        verify: If True, verify HMAC signature

    Returns:
        ShareTokenPayload

    Raises:
        InvalidShareTokenError: If token is invalid

    Example:
        >>> token = "branchpy-share://v1/..."
        >>> payload = resolve_share_link_local(token)
        >>> print(f"Resource: {payload.resource_type} ({payload.resource_id})")
    """
    return parse_share_token(token, verify=verify)


def export_resource_archive(
    resource_type: str,
    resource_data: dict,
    link_id: str,
    compress: bool = True,
) -> Path:
    """
    Export resource to archive file.

    Args:
        resource_type: Resource type
        resource_data: Resource data dictionary
        link_id: Share link ID (used for filename)
        compress: If True, compress archive

    Returns:
        Path to created archive file

    Example:
        >>> resource_data = {"project_id": "demo-vn", "name": "My VN"}
        >>> archive_path = export_resource_archive("project", resource_data, "abc123")
        >>> print(archive_path)
        ~/.branchpy/hub/shared/share_abc123.bpy
    """
    config = load_federation_config()

    # Generate archive filename
    suffix = ".bpy.gz" if compress else ".bpy"
    archive_path = config.archive_dir / f"share_{link_id}{suffix}"

    # Export to file
    export_resource_to_file(resource_type, resource_data, archive_path, compress)

    return archive_path


def import_share_link(
    token: str,
    target_project_id: Optional[str] = None,
    verify_signature: bool = True,
    auto_confirm: bool = False,
) -> ShareImportResult:
    """
    Import resource from share link.

    Args:
        token: Share token string
        target_project_id: Target project for import (required for some resource types)
        verify_signature: If True, verify HMAC signature
        auto_confirm: If True, skip confirmation prompt

    Returns:
        ShareImportResult

    Workflow:
        1. Parse and verify token
        2. Locate resource archive (by link_id)
        3. Check RBAC permissions
        4. Import resource to target project
        5. Return import result

    Example:
        >>> token = "branchpy-share://v1/..."
        >>> result = import_share_link(token, target_project_id="my-vn")
        >>> if result.success:
        ...     print(f"✓ Imported {result.resource_type}: {result.resource_id}")
    """
    try:
        # Step 1: Parse token
        payload = resolve_share_link_local(token, verify=verify_signature)

        # Step 2: Locate archive
        config = load_federation_config()

        # Try both compressed and uncompressed
        archive_path = config.archive_dir / f"share_{payload.link_id}.bpy.gz"
        compressed = True

        if not archive_path.exists():
            archive_path = config.archive_dir / f"share_{payload.link_id}.bpy"
            compressed = False

        if not archive_path.exists():
            return ShareImportResult(
                success=False,
                resource_type=payload.resource_type,
                resource_id=payload.resource_id,
                error_message=f"Archive not found for link_id '{payload.link_id}'",
            )

        # Step 3: Load resource data
        resource_type, resource_data = import_resource_from_file(
            archive_path, compressed
        )

        # Validate resource type matches payload
        if resource_type != payload.resource_type:
            return ShareImportResult(
                success=False,
                resource_type=payload.resource_type,
                resource_id=payload.resource_id,
                error_message=f"Resource type mismatch: expected {payload.resource_type}, got {resource_type}",
            )

        # Step 4: Check RBAC permissions (simplified for v0.9.3)
        # In full implementation, this would check federation.share.import permission

        # Step 5: Import resource (simplified — just return success)
        # In full implementation, this would:
        # - Create project copy
        # - Import governance template
        # - Import stats policy
        # - etc.

        return ShareImportResult(
            success=True,
            resource_type=resource_type,
            resource_id=payload.resource_id,
            imported_to_project_id=target_project_id,
            metadata={
                "link_id": payload.link_id,
                "created_by": payload.created_by,
                "exported_at": resource_data.get("exported_at"),
                "archive_path": str(archive_path),
            },
        )

    except InvalidShareTokenError as e:
        return ShareImportResult(
            success=False,
            resource_type="unknown",
            resource_id="unknown",
            error_message=f"Invalid share token: {e}",
        )

    except Exception as e:
        return ShareImportResult(
            success=False,
            resource_type=payload.resource_type if "payload" in locals() else "unknown",
            resource_id=payload.resource_id if "payload" in locals() else "unknown",
            error_message=f"Import failed: {e}",
        )


def create_share_link_with_export(
    resource_type: str,
    resource_data: dict,
    created_by: str,
    project_id: Optional[str] = None,
    expires_in_hours: Optional[int] = None,
) -> tuple[str, Path]:
    """
    Create share link and export resource archive in one operation.

    Args:
        resource_type: Resource type
        resource_data: Resource data dictionary
        created_by: User ID creating the share
        project_id: Project ID (if applicable)
        expires_in_hours: Expiration time in hours

    Returns:
        Tuple of (share_token, archive_path)

    Example:
        >>> project_data = {"project_id": "demo-vn", "name": "My VN"}
        >>> token, archive = create_share_link_with_export(
        ...     "project",
        ...     project_data,
        ...     created_by="alice",
        ... )
        >>> print(f"Share token: {token}")
        >>> print(f"Archive: {archive}")
    """
    from datetime import timedelta

    from .signed_links import create_share_token, generate_link_id

    config = load_federation_config()

    # Generate link ID
    link_id = generate_link_id()

    # Calculate expiration
    expires_at = None
    if expires_in_hours:
        expires_at = (datetime.utcnow() + timedelta(hours=expires_in_hours)).isoformat()
    elif config.default_expiration_hours:
        expires_at = (
            datetime.utcnow() + timedelta(hours=config.default_expiration_hours)
        ).isoformat()

    # Create payload
    payload = ShareTokenPayload(
        link_id=link_id,
        resource_type=resource_type,
        resource_id=resource_data.get("project_id")
        or resource_data.get("template_id")
        or str(uuid.uuid4()),
        created_by=created_by,
        created_at=datetime.utcnow().isoformat(),
        project_id=project_id,
        expires_at=expires_at,
    )

    # Create token
    token = create_share_token(payload)

    # Export archive
    archive_path = export_resource_archive(
        resource_type, resource_data, link_id, compress=True
    )

    return token, archive_path
