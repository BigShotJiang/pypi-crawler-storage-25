"""
BranchPy Configuration Loading

Handles loading and parsing of .branchpy.toml configuration files.
"""

import sys
from pathlib import Path
from typing import Any, Dict, List

try:
    import tomllib  # Python 3.11+
except ImportError:
    try:
        import tomli as tomllib  # Fallback for Python 3.10
    except ImportError:
        tomllib = None  # type: ignore


DEFAULT_CONFIG = {
    "localization": {
        "ignore": [],
        "base_locale": "english",
        "validate_language_tags": True,
        "min_coverage": 80.0,
    },
    "flowchart": {
        "pfi": {
            "enabled": True,  # Phase Flow Inference enabled by default
        },
        "sae": {
            "enabled": True,  # Semantic Action Extraction enabled by default (v1.0.0+)
        },
        "synthetic": {
            "enabled": False,  # Synthetic edges disabled by default
        },
    },
    "coverage": {
        "baseline_dir": ".branchpy/baselines/coverage",
        "metric": "lines",
        "min_tier": "medium",
        "tiers": {"high": 0.95, "medium": 0.85, "low": 0.0},
        "locales": {},
        "history": {
            "enabled": True,
            "max_snapshots": 10,
            "export_path": ".branchpy/reports/trends",
            "filename": "coverage_trend.json",
        },
        "policies": {
            "enabled": False,  # Feature flag (opt-in for v0.7.13)
            "global_min": 0.90,  # Min weighted average (0-1.0)
            "min_high_tier_count": 0,  # Require N high-tier locales
            "require_all_high_locales": False,  # All high-tier must pass threshold
            "enforcement_mode": "fail",  # "fail" | "warn"
        },
    },
    "discovery": {
        "force_engine": None,  # Override engine selection (renpy, godot, unity, unreal) or None
        "force_engine_always": False,  # If True, force_engine applies even on MATCHED
        "discovery_threshold": 0.5,  # Minimum confidence for MATCHED status (0.0-1.0)
        "cache_enabled": True,  # Enable discovery result caching
        "cache_ttl": 3600,  # Cache time-to-live in seconds (default: 1 hour)
    },
    "telemetry": {
        "mode": "manual",  # "off" | "manual" | "auto"
        "auto_upload_interval_hours": 24,  # Upload interval for auto mode
        "max_upload_size_mb": 5,  # Maximum upload size
        "auth_token": None,  # Optional authentication token for uploads
        "endpoint": "https://branchpy.com/api/telemetry/upload",  # Upload endpoint
    },
}


def _deep_merge(base: Dict, override: Dict) -> Dict:
    """
    Recursively merge override dict into base dict.

    Args:
        base: Base configuration dictionary
        override: User configuration to merge in

    Returns:
        Merged configuration
    """
    result = base.copy()

    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            # Recursively merge nested dicts
            result[key] = _deep_merge(result[key], value)
        else:
            # Override value
            result[key] = value

    return result


def load_config(project_root: Path) -> Dict[str, Any]:
    """
    Load .branchpy.toml configuration from project root.

    Args:
        project_root: Path to project root directory

    Returns:
        Configuration dictionary (merged with defaults)

    Example .branchpy/branchpy.toml:
        [localization]
        base_locale = "english"
        ignore = ["**/*_test.rpy", "game/tl/*/common.rpy"]
        validate_language_tags = true
        min_coverage = 90.0
    """
    # Try multiple config file locations - prefer canonical over legacy
    config_locations = [
        project_root / ".branchpy" / "branchpy.toml",  # Canonical: nested config
        project_root / ".branchpy" / "config.toml",  # Legacy nested (older versions)
        project_root / ".branchpy.toml",  # Legacy: root-level config
    ]

    config_file = None
    legacy_file = None

    for loc in config_locations:
        if loc.exists():
            if config_file is None:
                config_file = loc
            else:
                # Found multiple configs - canonical already set, this is legacy
                legacy_file = loc
                break

    # Log migration notice if legacy file exists alongside canonical
    # Only show in verbose mode to avoid output noise (stderr contamination in JSON mode)
    if config_file and legacy_file:
        # Check if verbose logging is requested via environment variable
        import os

        if os.environ.get("BRANCHPY_VERBOSE") == "1":
            print(
                f"Info: Multiple configs found. Using canonical {config_file.name}. "
                f"Legacy {legacy_file.name} ignored.",
                file=sys.stderr,
            )

    # Return defaults if no config file
    if not config_file:
        return DEFAULT_CONFIG.copy()

    # Check if TOML library available
    if tomllib is None:
        print(
            "Warning: TOML library not available. Install with: pip install tomli",
            file=sys.stderr,
        )
        return DEFAULT_CONFIG.copy()

    # Load and parse config
    try:
        with open(config_file, "rb") as f:
            content = f.read()
            # Strip UTF-8 BOM if present (Windows editors frequently add this)
            if content.startswith(b"\xef\xbb\xbf"):
                content = content[3:]
            user_config = tomllib.loads(content.decode("utf-8"))

        # Deep merge with defaults (for nested dicts like coverage.tiers)
        merged_config = _deep_merge(DEFAULT_CONFIG.copy(), user_config)

        return merged_config

    except Exception as e:
        print(f"Warning: Could not parse {config_file.name}: {e}", file=sys.stderr)
        return DEFAULT_CONFIG.copy()


def get_ignore_patterns(config: Dict[str, Any]) -> List[str]:
    """
    Extract localization ignore patterns from config.

    Args:
        config: Configuration dictionary from load_config()

    Returns:
        List of glob patterns to ignore

    Examples:
        >>> config = {"localization": {"ignore": ["**/*_test.rpy"]}}
        >>> get_ignore_patterns(config)
        ['**/*_test.rpy']
    """
    return config.get("localization", {}).get("ignore", [])


def load_ai_providers_config() -> Dict[str, Any]:
    """
    Loads AI provider configuration from ai_providers.toml.

    Searches for the file in the current project (.branchpy/ai_providers.toml)
    and in the user's home directory (~/.branchpy/ai_providers.toml).
    Project-level config is merged into the user-level config.
    """
    if tomllib is None:
        return {}

    user_config_path = Path.home() / ".branchpy" / "ai_providers.toml"
    project_config_path = Path.cwd() / ".branchpy" / "ai_providers.toml"

    user_config = {}
    if user_config_path.exists():
        try:
            with open(user_config_path, "rb") as f:
                user_config = tomllib.load(f)
        except Exception:
            # Ignore errors in user-level config
            pass

    project_config = {}
    if project_config_path.exists():
        try:
            with open(project_config_path, "rb") as f:
                project_config = tomllib.load(f)
        except Exception as e:
            print(
                f"Warning: Could not parse .branchpy/ai_providers.toml: {e}",
                file=sys.stderr,
            )

    # Merge project config into user config
    if user_config and project_config:
        return _deep_merge(user_config, project_config)

    return project_config or user_config
