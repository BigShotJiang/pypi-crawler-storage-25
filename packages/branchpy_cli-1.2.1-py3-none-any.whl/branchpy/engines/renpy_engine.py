from __future__ import annotations

import os
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from branchpy import logs
from branchpy.analysis.flow_graph_analysis import analyze_flow_graph
from branchpy.analysis.semantic_edges import (
    extract_pfi_edges,
    extract_sae_edges,
    resolve_semantic_edges,
)
from branchpy.core.engine_interface import EngineInterface
from branchpy.core.perf_profiler import PerfProfiler
from branchpy.core.snapshot import ProjectSnapshot
from branchpy.rules.registry import registry as rule_registry

from .renpy_cfg import build_cfg

# D16/D17a/D17b: EdgeType.value → webview edgeKind mapping.
# Defined at module level so it can be imported and regression-tested independently.
# NOTE: EdgeType.CONDITIONAL ("conditional") is NOT in this map — it is resolved
# inline using edge.condition_branch to emit "conditional_true" or "conditional_false".
EDGE_KIND_MAP: dict[str, str] = {
    "implicit": "fallthrough",
    "choice": "menu_choice",
    "jump": "jump",
    "call": "call",
    "return": "return",
    # D17b: dynamic dispatch
    "dynamic_call": "dynamic_call",
    "dynamic_jump": "dynamic_jump",
    # D18: while loop branch directions
    "while_true": "while_true",
    "while_false": "while_false",
    # D19: screen action families
    "screen_jump": "screen_jump",
    "screen_call": "screen_call",
    "screen_return": "screen_return",
    # D20: Python literal transfer families
    "python_jump": "python_jump",
    "python_call": "python_call",
    "python_return": "python_return",
    # D22: Engine lifecycle entry families
    "entry_point": "entry_point",
    # D23: Creator-defined custom transfer
    "custom_transfer": "custom_transfer",
}


class RenpyEngine(EngineInterface):
    """
    Minimal Ren'Py engine implementation.
    build_index: finds .rpy files and extracts naive 'label' occurrences.
    analyze: emits a trivial issue if no labels were found.
    """

    LABEL_RX = re.compile(r"^\s*label\s+([A-Za-z0-9_]+)\s*:\s*$")

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize RenpyEngine with optional configuration.

        Args:
            config: Resolved config dict from load_config() or equivalent
        """
        self.config = config or {}

        # Phase 3B.1-A: Store static graph for merging into collapsed_graph
        self._static_graph = None

        # Phase 2.4.3: Log config resolution for analysis source gating
        flowchart_config = self.config.get("flowchart", {})
        pfi_config = flowchart_config.get("pfi", {})
        sae_config = flowchart_config.get("sae", {})
        synthetic_config = flowchart_config.get("synthetic", {})

        logs.info(
            "config.analysis_sources_resolved",
            "Analysis source configuration loaded",
            flowchart_keys=list(flowchart_config.keys()),
            pfi_enabled=pfi_config.get("enabled", True),
            sae_enabled=sae_config.get("enabled", True),
            synthetic_enabled=synthetic_config.get("enabled", True),
        )

    def _extract_tier1_pfi_edges(self, index: Any) -> Dict[str, Any]:
        """
        Extract Tier-1 PFI edges (label-level jumps and calls).

        STABLE FEATURE - Do not expand this scope. This method extracts ONLY what is statically
        present in the Ren'Py index: jump and call statements. It does not infer, speculate,
        or handle dynamic targets.

        Design:
        - jump statements: unconditional label transitions
        - call statements: label calls that return
        - Returns the "known facts" layer that SAE will build on

        Supports two index formats:
        - ProjectIndex object (has .jumps, .calls, .labels attributes)
        - Dict format (has "jumps", "calls", "labels" keys)

        Returns:
            Dict with shape: {"jump_index": {src_label: [dst_labels...]}, "call_index": {...}}
        """
        jump_index = {}
        call_index = {}
        call_sites = []  # D11: per-site [{src, dst, file, line}] for call_bundle_id
        dynamic_call_sites = (
            []
        )  # D11: per-site [{src, file, line}] for DYNAMIC_CALL edges

        # Handle both object and dict formats
        def get_attr_or_key(obj: Any, attr: str, default=None):
            """Get attribute if object, otherwise get dict key"""
            if hasattr(obj, attr):
                return getattr(obj, attr)
            elif isinstance(obj, dict):
                return obj.get(attr, default)
            return default

        def get_entry_field(entry: Any, field: str):
            """Get field from IndexEntry object or dict"""
            if hasattr(entry, field):
                return getattr(entry, field)
            elif isinstance(entry, dict):
                return entry.get(field)
            return None

        # Extract from index
        jumps = get_attr_or_key(index, "jumps", []) or []
        calls = get_attr_or_key(index, "calls", []) or []
        dynamic_calls_raw = get_attr_or_key(index, "dynamic_calls", []) or []  # D11
        labels = get_attr_or_key(index, "labels", {}) or {}

        jumps_count = len(jumps) if jumps else 0
        calls_count = len(calls) if calls else 0
        labels_count = len(labels) if labels else 0

        logs.debug(
            "tier1.inspect",
            "Tier-1 PFI inspection",
            jumps_count=jumps_count,
            calls_count=calls_count,
            labels_count=labels_count,
        )

        # Track unknown targets for audit
        unknown_targets = set()

        # Extract jump edges from index
        if jumps:
            for jump_entry in jumps:
                src_file = get_entry_field(jump_entry, "file")
                src_line = get_entry_field(jump_entry, "line")
                dst_name = get_entry_field(jump_entry, "name")

                if src_file and src_line is not None and dst_name:
                    # Validate target exists in labels (Guardrail B: silent drop of unknown targets)
                    if dst_name not in labels:
                        unknown_targets.add(dst_name)
                        continue  # Skip this edge - target not in index

                    # Find source label containing this jump
                    src_label = self._find_containing_label(
                        index, src_file, src_line, labels
                    )
                    if src_label:
                        if src_label not in jump_index:
                            jump_index[src_label] = []
                        if dst_name not in jump_index[src_label]:
                            jump_index[src_label].append(dst_name)

        # Extract call edges from index
        if calls:
            for call_entry in calls:
                src_file = get_entry_field(call_entry, "file")
                src_line = get_entry_field(call_entry, "line")
                dst_name = get_entry_field(call_entry, "name")

                if src_file and src_line is not None and dst_name:
                    # Validate target exists in labels (Guardrail B: silent drop of unknown targets)
                    if dst_name not in labels:
                        unknown_targets.add(dst_name)
                        continue  # Skip this edge - target not in index

                    # Find source label containing this call
                    src_label = self._find_containing_label(
                        index, src_file, src_line, labels
                    )
                    if src_label:
                        if src_label not in call_index:
                            call_index[src_label] = []
                        if dst_name not in call_index[src_label]:
                            call_index[src_label].append(dst_name)
                        # D11: record per-site metadata for call_bundle_id computation
                        call_sites.append(
                            {
                                "src": src_label,
                                "dst": dst_name,
                                "file": src_file,
                                "line": src_line,
                            }
                        )

        # D11: Extract dynamic call sites (call expression <var>)
        if dynamic_calls_raw:
            for dyn_entry in dynamic_calls_raw:
                dyn_file = get_entry_field(dyn_entry, "file")
                dyn_line = get_entry_field(dyn_entry, "line")
                if dyn_file and dyn_line is not None:
                    src_label = self._find_containing_label(
                        index, dyn_file, dyn_line, labels
                    )
                    if src_label:
                        dynamic_call_sites.append(
                            {
                                "src": src_label,
                                "file": dyn_file,
                                "line": dyn_line,
                            }
                        )

        # Tier 1.5: Variable screen jump resolution
        # Handles: $ var = "label"; call screen X → Jump(var) in screen X
        try:
            project_path_str = (
                getattr(index, "project_path", None)
                or getattr(index, "project_root", None)
                or (index.get("project_path") if isinstance(index, dict) else None)
                or (index.get("project_root") if isinstance(index, dict) else None)
            )
            if project_path_str:
                import os

                screen_jump_result = self._extract_variable_screen_jumps(
                    index, labels, project_path_str
                )
                screen_jump_edges = screen_jump_result.get("edges", [])
                tier16_screen_call_labels = screen_jump_result.get(
                    "screen_call_labels", {}
                )
                tier16_screen_return_screens = screen_jump_result.get(
                    "screen_return_screens", []
                )
                for edge in screen_jump_edges:
                    src = edge["src_label"]
                    dst = edge["dst_label"]
                    if src and dst:
                        if src not in jump_index:
                            jump_index[src] = []
                        if dst not in jump_index[src]:
                            jump_index[src].append(dst)
                if screen_jump_edges:
                    logs.info(
                        "tier1.variable_screen_jumps",
                        "Variable screen jump edges resolved",
                        count=len(screen_jump_edges),
                    )
                if tier16_screen_call_labels:
                    logs.info(
                        "tier1.screen_call_labels",
                        "Screen-call terminal labels detected",
                        count=len(tier16_screen_call_labels),
                    )
        except Exception as e:
            logs.debug(
                "tier1.variable_screen_jumps_failed",
                f"Variable screen jump resolution failed: {e}",
            )
            tier16_screen_call_labels = {}
            tier16_screen_return_screens = []

        return {
            "jump_index": jump_index,
            "call_index": call_index,
            "call_sites": call_sites,  # D11: per-site call metadata
            "dynamic_call_sites": dynamic_call_sites,  # D11: dynamic call sites
            # Tier 1.6: Screen-call terminal data for ui_terminal node classification
            "screen_call_labels": locals().get("tier16_screen_call_labels", {}),
            "screen_return_screens": locals().get("tier16_screen_return_screens", []),
            "stats": {
                "total_jumps": jumps_count,
                "total_calls": calls_count,
                "jump_edges": sum(len(v) for v in jump_index.values()),
                "call_edges": sum(len(v) for v in call_index.values()),
                "unknown_targets_dropped": len(unknown_targets),  # Audit metric
            },
        }

    def _find_containing_label(
        self, index: Any, file: str, line: int, labels=None
    ) -> Optional[str]:
        """
        Find the label that contains the given line in the file.

        Supports both ProjectIndex object and dict formats.
        """
        # Use provided labels if given, otherwise try to extract from index
        if labels is None:
            if hasattr(index, "labels"):
                labels = index.labels
            elif isinstance(index, dict):
                labels = index.get("labels", {})
            else:
                return None

        if not labels:
            return None

        # Convert labels dict to tuples of (name, line_number)
        candidates = []

        for label_name, label_info in labels.items():
            # Handle both IndexEntry objects and dict format
            label_file = None
            label_line = None

            if hasattr(label_info, "file"):
                label_file = label_info.file
                label_line = label_info.line
            elif isinstance(label_info, dict):
                label_file = label_info.get("file")
                label_line = label_info.get("line")

            # Match file (handle both absolute and relative paths)
            if label_file:
                # Normalize paths for comparison (handle backslashes)
                file_normalized = file.replace("\\", "/").lower()
                label_file_normalized = label_file.replace("\\", "/").lower()

                # Match if equal or if label path ends with the jump file path (handles absolute vs relative)
                if (
                    file_normalized == label_file_normalized
                    or label_file_normalized.endswith(file_normalized)
                ):
                    if label_line is not None:
                        candidates.append((label_name, label_line))

        if not candidates:
            return None

        # Sort by line number and find the closest label before this line
        candidates.sort(key=lambda x: x[1])

        # Find the label whose line <= the target line
        result = None
        for label_name, label_line in candidates:
            if label_line <= line:
                result = label_name
            else:
                break

        return result

    def _extract_variable_screen_jumps(
        self, index: Any, labels: Any, project_path: str
    ) -> List[Dict[str, Any]]:
        """
        Resolve 'call screen X' + Jump(var) patterns into concrete jump edges.

        Ren'Py chapter-transition idiom:
            $ next_chapter = "intro_scene"
            call screen end_of_day_summary with dissolve

        Where end_of_day_summary contains a button:
            textbutton "Continue" action Jump(next_chapter)

        This method:
        1. Scans all .rpy files for screen blocks, collecting Jump(variable) actions
        2. Scans all .rpy files for `$ var = "literal"` + `call screen X` pairs
        3. Resolves the variable to its literal value and emits a jump edge

        Returns:
            List of edge dicts: [{src_label, dst_label, via_screen, resolved_var, kind}]
        """
        import os
        import re

        edges: List[Dict[str, Any]] = []

        # Patterns
        var_assign_re = re.compile(r'^\s*\$\s+(\w+)\s*=\s*["\']([A-Za-z_]\w*)["\']')
        call_screen_re = re.compile(r"^\s*call\s+screen\s+(\w+)")
        screen_def_re = re.compile(r"^\s*screen\s+(\w+)\s*[\(:]")
        jump_action_re = re.compile(r"\bJump\s*\(\s*(\w+)\s*\)")

        # Step 1: Find all rpy files (resolve to absolute paths so _find_containing_label
        # can match against the absolute paths stored in the index)
        rpy_files: List[str] = []
        game_dir = os.path.abspath(os.path.join(project_path, "game"))
        project_path_abs = os.path.abspath(project_path)
        scan_root = game_dir if os.path.isdir(game_dir) else project_path_abs
        for root, _, files in os.walk(scan_root):
            for fname in files:
                if fname.endswith(".rpy"):
                    rpy_files.append(os.path.join(root, fname))

        # Step 2: Build map of screen_name -> set of variable names used in Jump(var)
        screen_jump_vars: Dict[str, List[str]] = {}
        all_file_lines: Dict[str, List[str]] = {}

        for file_path in rpy_files:
            try:
                with open(file_path, encoding="utf-8", errors="replace") as fh:
                    content = fh.read()
                lines = content.split("\n")
                all_file_lines[file_path] = lines

                in_screen: Optional[str] = None
                screen_indent = 0

                for line in lines:
                    stripped = line.strip()
                    if not stripped or stripped.startswith("#"):
                        continue

                    indent = len(line) - len(line.lstrip())

                    # Detect screen block start
                    m = screen_def_re.match(line)
                    if m:
                        in_screen = m.group(1)
                        screen_indent = indent
                        continue

                    # Detect screen block end
                    if in_screen and indent <= screen_indent and stripped:
                        # Only end if we're at a new top-level statement
                        if not line[0].isspace() or indent < screen_indent:
                            in_screen = None

                    if in_screen:
                        for jm in jump_action_re.finditer(stripped):
                            var_name = jm.group(1)
                            if in_screen not in screen_jump_vars:
                                screen_jump_vars[in_screen] = []
                            if var_name not in screen_jump_vars[in_screen]:
                                screen_jump_vars[in_screen].append(var_name)

            except Exception:
                continue

        # Step 2b: Detect which screens exit via Return() (not just Jump)
        # These screens can be "called" and control returns to the caller label.
        screen_return_screens: set = set()
        return_action_re = re.compile(r"\bReturn\s*\(")
        for file_path, lines in all_file_lines.items():
            in_screen: Optional[str] = None
            si = 0
            for line in lines:
                stripped = line.strip()
                if not stripped or stripped.startswith("#"):
                    continue
                indent = len(line) - len(line.lstrip())
                m = screen_def_re.match(line)
                if m:
                    in_screen = m.group(1)
                    si = indent
                    continue
                if in_screen and indent <= si and stripped:
                    if not line[0].isspace() or indent < si:
                        in_screen = None
                if in_screen and return_action_re.search(stripped):
                    screen_return_screens.add(in_screen)

        # screen_call_labels: label_name -> screen_name, for ANY label that calls
        # a known screen via `call screen X`. Used for FLOW_SCREEN_TERMINAL classification.
        screen_call_labels: Dict[str, str] = {}

        # Step 3: Scan files for preceding var assignments + call screen X
        for file_path, lines in all_file_lines.items():
            # Track recent variable assignments (reset only at label boundaries)
            recent_assignments: Dict[str, str] = {}

            for line_idx, line in enumerate(lines):
                stripped = line.strip()
                if not stripped or stripped.startswith("#"):
                    continue

                # Variable assignment: $ var = "literal"
                m = var_assign_re.match(line)
                if m:
                    recent_assignments[m.group(1)] = m.group(2)
                    continue

                # call screen X
                m = call_screen_re.match(line)
                if m:
                    screen_name = m.group(1)

                    # Always track which label ends with a screen call (Tier 1.6:
                    # ui_terminal classification — even if target is unresolved).
                    src_label = self._find_containing_label(
                        index, file_path, line_idx + 1, labels
                    )
                    if src_label:
                        # Last one wins: if a label calls multiple screens, record
                        # the last call site (most likely the terminal one).
                        screen_call_labels[src_label] = screen_name

                    # Jump edge resolution (only if screen has known Jump(var) actions)
                    if screen_name in screen_jump_vars and src_label:
                        for var_name in screen_jump_vars[screen_name]:
                            if var_name in recent_assignments:
                                target_label = recent_assignments[var_name]
                                # Verify target is a known label
                                if hasattr(labels, "__contains__"):
                                    label_known = target_label in labels
                                else:
                                    label_known = False
                                if label_known:
                                    edges.append(
                                        {
                                            "src_label": src_label,
                                            "dst_label": target_label,
                                            "via_screen": screen_name,
                                            "resolved_var": var_name,
                                            "kind": "jump",
                                        }
                                    )
                    continue

                # Non-trivial lines (other than `$` or `call screen`) reset
                # recent_assignments if they leave the current label scope.
                # We keep assignments alive across non-assignment statements
                # because the pattern is always:
                #   $ next_chapter = "X"       ← assignment
                #   [optional show/with/etc.]
                #   call screen end_of_day_summary
                # Resetting on `label` boundaries is sufficient.
                if stripped.startswith("label ") and stripped.endswith(":"):
                    recent_assignments = {}

        return {
            "edges": edges,
            "screen_call_labels": screen_call_labels,
            "screen_return_screens": list(screen_return_screens),
        }

    def detect_trace_shim(self, project_path: str) -> Dict[str, Any]:
        """Detect if automatic trace generation shim is installed in project.

        Returns dict with:
            - installed: bool - True if shim file exists
            - version: str - Version from header comment, or None
            - path: str - Absolute path to shim file
        """
        from pathlib import Path

        shim_path = Path(project_path) / "game" / "branchpy_trace_autogen.rpy"
        result = {"installed": False, "version": None, "path": str(shim_path)}

        if shim_path.exists():
            result["installed"] = True
            # Parse version from header comment: # Version: 1.0.0 (line 2)
            try:
                with open(shim_path, "r", encoding="utf-8") as f:
                    lines = f.readlines()
                    if len(lines) >= 2:
                        version_line = lines[1].strip()  # # Version: 1.0.0
                        if "Version:" in version_line:
                            result["version"] = version_line.split("Version:")[
                                1
                            ].strip()
            except Exception as e:
                logs.warning(f"Failed to parse trace shim version: {e}")

        return result

    def install_trace_shim(self, project_path: str) -> Dict[str, Any]:
        """Install automatic trace generation shim into project game folder.

        Phase 3B.1: Installs autoplay + trace combined shim (renpy_autoplay_shim.rpy).
        Idempotent: Re-installing will overwrite with template version.

        Returns dict with:
            - success: bool
            - path: str - Path to installed shim
            - message: str - Human-readable result
        """
        import shutil
        from pathlib import Path

        # Locate autoplay shim template (Phase 3B combined)
        branchpy_root = Path(__file__).parent.parent
        template_path = branchpy_root / "templates" / "renpy_autoplay_shim.rpy"

        if not template_path.exists():
            return {
                "success": False,
                "path": None,
                "message": f"Autoplay shim template not found at {template_path}",
            }

        # Target location
        game_dir = Path(project_path) / "game"
        if not game_dir.exists():
            return {
                "success": False,
                "path": None,
                "message": f"game/ directory not found at {game_dir}",
            }

        shim_path = game_dir / "branchpy_trace_autogen.rpy"

        try:
            shutil.copy2(template_path, shim_path)
            return {
                "success": True,
                "path": str(shim_path),
                "message": f"Installed autoplay shim to {shim_path}",
            }
        except Exception as e:
            return {
                "success": False,
                "path": str(shim_path),
                "message": f"Failed to install autoplay shim: {e}",
            }

    def _persist_choice_points(self, index_obj, project_path: str) -> None:
        """
        Persist choice points to .branchpy/index/choice_points.json for runner consumption.

        Args:
            index_obj: ProjectIndex object with choice_points list
            project_path: Absolute path to project root
        """
        import json
        from pathlib import Path

        project_root = Path(project_path)
        artifact_dir = project_root / ".branchpy" / "index"
        artifact_dir.mkdir(parents=True, exist_ok=True)

        artifact_path = artifact_dir / "choice_points.json"

        # Build artifact
        artifact = {
            "version": 1,
            "project": {"root": str(project_root)},
            "choice_points": index_obj.choice_points,
        }

        # Write to disk
        with open(artifact_path, "w", encoding="utf-8") as f:
            json.dump(artifact, f, indent=2, ensure_ascii=False)

        logs.info(
            "indexer.choice_points_persisted",
            f"Persisted {len(index_obj.choice_points)} choice points to {artifact_path}",
            count=len(index_obj.choice_points),
            path=str(artifact_path),
        )

    def _build_static_graph(self, index_obj, project_path: str):
        """
        Build static flow graph and cache with incremental detection.

        Phase 3B.1-A: Static explorer becomes the default analysis path.

        Args:
            index_obj: ProjectIndex object with labels, jumps, calls, choice_points
            project_path: Absolute path to project root
        """
        try:
            from pathlib import Path

            from branchpy.explorers.cache_manager import CacheManager
            from branchpy.explorers.label_fingerprints import (
                LabelFingerprinter,
                compute_impact_set,
            )
            from branchpy.explorers.static_renpy_explorer import StaticRenpyExplorer

            project_root = Path(project_path)

            # Initialize cache and fingerprinter
            cache = CacheManager(project_root)
            fingerprinter = LabelFingerprinter(project_root)

            # Build static graph via BFS
            logs.info("static_explorer.start", "Building static flow graph via BFS")
            explorer = StaticRenpyExplorer(
                project_root=project_root,
                label_index=index_obj.labels,
                choice_points=index_obj.choice_points,
                jumps=index_obj.jumps,
                calls=index_obj.calls,
            )

            static_graph = explorer.explore(start_label="start")

            # Persist static graph
            cache.write_static_graph(static_graph.to_json_dict())

            # Compute fingerprints
            current_fingerprints = fingerprinter.compute_fingerprints(index_obj.labels)

            # Incremental: detect changes and compute impact set
            # (check BEFORE writing new fingerprints)
            if cache.has_previous_fingerprints():
                previous_fingerprints = cache.read_label_fingerprints()
                changed_labels = fingerprinter.detect_changed_labels(
                    current_fingerprints, previous_fingerprints
                )

                if changed_labels:
                    impact = compute_impact_set(changed_labels, static_graph, k=2)
                    cache.write_impact_set(changed_labels, impact, k_hops=2)

                    logs.info(
                        "static_explorer.incremental",
                        f"Incremental: {len(changed_labels)} changed → {len(impact)} impacted labels",
                    )
                else:
                    logs.info("static_explorer.no_changes", "No label changes detected")
            else:
                logs.info(
                    "static_explorer.first_run",
                    "First run: no previous fingerprints to compare",
                )

            # Write fingerprints AFTER checking for changes
            cache.write_label_fingerprints(current_fingerprints)

            logs.info(
                "static_explorer.complete",
                f"Static graph built: {len(static_graph.nodes)} nodes, "
                f"{len(static_graph.edges)} edges, {len(static_graph.uncertainties)} uncertainties",
            )
            return static_graph
        except Exception as e:
            import sys
            import traceback

            print(f"[STATIC EXPLORER ERROR] {e}", file=sys.stderr)
            print(traceback.format_exc(), file=sys.stderr)
            logs.error("static_explorer.error", f"Static explorer failed: {e}")
            logs.debug("static_explorer.traceback", traceback.format_exc())
            return None

    def build_index(self, project_path: str) -> Dict[str, Any]:
        """Build comprehensive project index with statement-level data"""
        # Use the proper SAE Indexer that extracts statements for containers
        from pathlib import Path as PathLib

        from branchpy.analysis.sae.indexer import Indexer

        indexer = Indexer(project_path)
        index_obj = indexer.build_index()

        # Phase 3B.1: Persist choice_points artifact for automated runner
        self._persist_choice_points(index_obj, project_path)

        # Phase 3B.1-A: Build static flow graph and cache incrementally
        static_graph = self._build_static_graph(index_obj, project_path)

        # Return as dict (with proper serialization of statements)
        index_dict = index_obj.to_dict()

        # Phase 3B.1-A: Store static_graph in index dict (architectural fix)
        # This ensures the graph survives across CLI/daemon/test lifecycles
        if static_graph:
            index_dict["static_graph"] = static_graph.to_json_dict()
            logs.info(
                "static_graph.persisted",
                f"Static graph stored in index: {len(static_graph.nodes)} nodes, "
                f"{len(static_graph.edges)} edges, {len(static_graph.uncertainties)} uncertainties",
            )

        # Convert relative file paths to absolute paths for story validation
        # This ensures build_story_graph() can find files regardless of working directory
        project_root = PathLib(project_path).resolve()

        # Convert files in main index
        if "files" in index_dict:
            converted_files = {}
            for rel_path in index_dict["files"]:
                abs_path = str(project_root / rel_path)
                converted_files[abs_path] = index_dict["files"][rel_path]
            index_dict["files"] = converted_files

        # Convert paths in statements
        if "statements" in index_dict and isinstance(index_dict["statements"], dict):
            converted_statements = {}
            for rel_path, stmts in index_dict["statements"].items():
                abs_path = str(project_root / rel_path)
                converted_statements[abs_path] = stmts
            index_dict["statements"] = converted_statements

        # Convert paths in labels
        if "labels" in index_dict:
            converted_labels = {}
            for label_name, label_info in index_dict["labels"].items():
                if isinstance(label_info, dict) and "file" in label_info:
                    label_info = label_info.copy()  # Don't modify original
                    label_info["file"] = str(project_root / label_info["file"])
                converted_labels[label_name] = label_info
            index_dict["labels"] = converted_labels

        # Ensure stats key exists for stable schema
        index_dict.setdefault(
            "stats",
            {
                "file_count": len(index_dict.get("files", {})),
                "label_count": len(index_dict.get("labels", {})),
            },
        )

        return index_dict

    @logs.traced("sae.analyze")
    def analyze(
        self, index: Dict[str, Any], options: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Analyze the project index with optional asset validation.

        Args:
            index: Project index from build_index()
            options: Optional dict with:
                - enable_assets (bool): Run asset validation
                - export_cfg (bool): Include CFG debug output
                - enable_story (bool): Run story structure validation
                - enable_perf (bool): Enable performance profiling (default True)

        Returns:
            Analysis results with CFG, issues, optional assets, story_structure, and performance
        """
        options = options or {}

        # Log analysis start
        files = list(index.get("files", {}).keys())
        logs.info(
            "sae.phase_start",
            "SAE analysis started",
            name="analyze",
            files=len(files),
            enable_assets=options.get("enable_assets", False),
            enable_story=options.get("enable_story", True),
            enable_perf=options.get("enable_perf", True),
        )

        # Phase 6: Performance profiling (enabled by default)
        perf_enabled = options.get("enable_perf", True)
        profiler = PerfProfiler(enable_memory=perf_enabled) if perf_enabled else None
        if profiler:
            profiler.start_session()
            profiler.mark("analysis")

        # Create snapshot for rules execution (without assets initially)
        files = list(index.get("files", {}).keys())
        labels = index.get("labels", {})
        snapshot = ProjectSnapshot(
            files=files, labels=labels, calls=None, menus=None, vars=None
        )

        # Run all registered rules
        rules_results = rule_registry.run_all(snapshot)

        if profiler:
            profiler.mark("rules")

        # Phase 2: Asset validation (optional)
        asset_index = None
        asset_results = None

        if options.get("enable_assets", False):
            logs.info(
                "sae.phase_start",
                "Asset validation started",
                name="assets",
                files=len(files),
            )
            try:
                from branchpy.analysis.sae.assets.asset_scanner import (
                    scan_project_assets,
                )
                from branchpy.analysis.sae.assets.definition_extractor import (
                    extract_definitions,
                )
                from branchpy.analysis.sae.assets.models import AssetIndex
                from branchpy.analysis.sae.assets.reference_extractor import (
                    extract_references,
                )
                from branchpy.analysis.sae.assets.validators.assets_fuzzy_typo_validator import (
                    validate_typo_audio_reference,
                    validate_typo_image_reference,
                )

                # Import all validators
                from branchpy.analysis.sae.assets.validators.assets_missing_validator import (
                    validate_missing_audio_file,
                    validate_missing_image_def,
                    validate_missing_image_file,
                    validate_missing_video_file,
                )
                from branchpy.analysis.sae.assets.validators.assets_unused_validator import (
                    validate_unused_audio_file,
                    validate_unused_image_file,
                    validate_unused_video_file,
                )

                # 1) Scan filesystem for assets
                project_path = Path(index.get("project_path", "."))
                asset_files_by_type = scan_project_assets(
                    project_path, compute_hash=False
                )

                # 2) Extract definitions from .rpy scripts
                script_files = [Path(f) for f in files]
                image_defs, font_defs = extract_definitions(script_files)

                # 3) Extract references from .rpy scripts
                asset_refs = extract_references(script_files)

                # 4) Build AssetIndex
                asset_index = AssetIndex(
                    images=asset_files_by_type.get("images", {}),
                    audio=asset_files_by_type.get("audio", {}),
                    video=asset_files_by_type.get("video", {}),
                    fonts=asset_files_by_type.get("fonts", {}),
                    image_defs=image_defs,
                    font_defs=font_defs,
                    references=asset_refs,
                )

                # 5) Run all 10 validators
                all_validators = [
                    validate_missing_image_def,
                    validate_missing_image_file,
                    validate_missing_audio_file,
                    validate_missing_video_file,
                    validate_unused_image_file,
                    validate_unused_audio_file,
                    validate_unused_video_file,
                    validate_typo_image_reference,
                    validate_typo_audio_reference,
                ]

                asset_issues = []
                for validator_fn in all_validators:
                    issues = validator_fn(asset_index)
                    asset_issues.extend(issues)

                # Build asset results
                asset_results = {
                    "summary": {
                        "total_files": asset_index.total_files(),
                        "images": len(asset_index.images),
                        "audio": len(asset_index.audio),
                        "video": len(asset_index.video),
                        "fonts": len(asset_index.fonts),
                        "image_definitions": len(asset_index.image_defs),
                        "references": asset_index.total_refs(),
                    },
                    "issues": [issue.to_dict() for issue in asset_issues],
                }

                logs.info(
                    "sae.phase_ok",
                    "Asset validation complete",
                    name="assets",
                    total_files=asset_index.total_files(),
                    issues_total=len(asset_issues),
                    warnings_total=sum(
                        1 for i in asset_issues if i.severity == "warning"
                    ),
                )

                # Update snapshot with asset_index
                snapshot = ProjectSnapshot(
                    files=files,
                    labels=labels,
                    calls=None,
                    menus=None,
                    vars=None,
                    assets=asset_index,
                )

            except Exception as e:
                # Graceful degradation - asset validation is optional
                print(
                    f"Warning: Asset validation failed: {e}",
                    file=__import__("sys").stderr,
                )
                logs.error(
                    "sae.phase_err",
                    "Asset validation failed",
                    name="assets",
                    error=str(e),
                )
                asset_results = None

        if profiler:
            profiler.mark("assets")

        # Phase 4.5: Media Intelligence Extraction (optional, v0.9.0+)
        media_results = None
        media_by_label: Dict[str, List[Dict[str, Any]]] = {}

        if options.get("enable_media", True):  # Enabled by default
            logs.info(
                "media.extract.start",
                "Media extraction started",
                name="media",
                files=len(files),
                media_intelligence_version="0.9.0.2",
                correlation_id=options.get("correlation_id"),
            )
            try:
                from branchpy.media_analyzer import MediaConfig, merge_media_refs
                from branchpy.media_renpy import RenpyMediaExtractor

                # Load media config from .branchpy.toml if available
                project_path = Path(index.get("project_path", "."))
                config_path = project_path / ".branchpy.toml"

                media_config = MediaConfig()
                if config_path.exists():
                    try:
                        # Try Python 3.11+ tomllib, fallback to tomli
                        try:
                            import tomllib
                        except ImportError:
                            try:
                                import tomli as tomllib  # type: ignore
                            except ImportError:
                                tomllib = None  # type: ignore

                        if tomllib:
                            with open(config_path, "rb") as f:
                                toml_data = tomllib.load(f)
                                if "media" in toml_data:
                                    media_config = MediaConfig.from_toml(
                                        toml_data["media"]
                                    )
                    except Exception as e:
                        logs.warning(
                            "media.config", f"Could not load media config: {e}"
                        )

                # Override with CLI options if provided
                if "max_media_per_node" in options:
                    media_config.max_media_per_node = options["max_media_per_node"]
                if "media_screens_enabled" in options:
                    media_config.screens_enabled = options["media_screens_enabled"]

                # Extract media references
                extractor = RenpyMediaExtractor(media_config)
                media_refs = extractor.extract(project_path)

                # Group media by label
                for ref in media_refs:
                    if ref.label:
                        if ref.label not in media_by_label:
                            media_by_label[ref.label] = []
                        media_by_label[ref.label].append(ref.to_dict())

                # Apply max_media_per_node limit and merge duplicates per label
                for label_name in media_by_label:
                    # Convert dicts back to MediaRef for merging
                    from branchpy.media_analyzer import MediaRef as MR

                    refs_objs = [MR.from_dict(d) for d in media_by_label[label_name]]
                    merged = merge_media_refs(
                        refs_objs, media_config.max_media_per_node
                    )
                    media_by_label[label_name] = [r.to_dict() for r in merged]

                # Build media summary
                summary = extractor.get_summary()
                media_results = {
                    "summary": summary.to_dict(),
                    "by_label": media_by_label,
                    "config": {
                        "enabled": media_config.enabled,
                        "screens_enabled": media_config.screens_enabled,
                        "max_media_per_node": media_config.max_media_per_node,
                    },
                }

                logs.info(
                    "media.extract.done",
                    "Media extraction complete",
                    name="media",
                    total_refs=summary.total,
                    labels_with_media=len(media_by_label),
                    images=summary.by_kind.get("image", 0),
                    audio=summary.by_kind.get("audio", 0),
                    video=summary.by_kind.get("video", 0),
                    media_intelligence_version="0.9.0.2",
                    correlation_id=options.get("correlation_id"),
                )

                # Phase 4.5: Media Validation (v0.9.0.2)
                from pathlib import Path as PathLib

                from branchpy.analyze.media_validate import (
                    ValidationConfig,
                    validate_media_refs,
                )

                # Get validation config (defaults if not in .branchpy.toml)
                try:
                    import tomllib
                except ImportError:
                    try:
                        import tomli as tomllib  # type: ignore
                    except ImportError:
                        tomllib = None  # type: ignore

                validation_cfg_dict = {}
                if tomllib and config_path.exists():
                    try:
                        with open(config_path, "rb") as f:
                            toml_data = tomllib.load(f)
                            validation_cfg_dict = toml_data.get("media", {}).get(
                                "validation", {}
                            )
                    except Exception:
                        pass

                val_cfg = ValidationConfig(
                    enabled=bool(validation_cfg_dict.get("enabled", True)),
                    check_existence=bool(
                        validation_cfg_dict.get("check_existence", True)
                    ),
                    base_paths=validation_cfg_dict.get("base_paths") or [],
                    smart_fallback=bool(
                        validation_cfg_dict.get("smart_fallback", True)
                    ),
                )

                if val_cfg.enabled:
                    logs.info(
                        "media.validate.start", "Validating media refs", name="media"
                    )
                    total_missing = 0
                    project_root = PathLib(index.get("project_root", ".")).resolve()

                    for label, refs in list(media_by_label.items()):
                        upd, val_summary = validate_media_refs(
                            refs, project_root, val_cfg
                        )
                        media_by_label[label] = upd
                        total_missing += val_summary["missing"]

                    # Update summary
                    summary_dict = media_results["summary"]
                    summary_dict["missing"] = total_missing

                    logs.info(
                        "media.validate.done",
                        "Media validation complete",
                        name="media",
                        missing=total_missing,
                        media_intelligence_version="0.9.0.2",
                        correlation_id=options.get("correlation_id"),
                    )

            except Exception as e:
                # Graceful degradation - media extraction is optional
                import sys
                import traceback

                print(f"Warning: Media extraction failed: {e}", file=sys.stderr)
                traceback.print_exc()
                logs.error(
                    "media.extract.error",
                    "Media extraction failed",
                    name="media",
                    error=str(e),
                    media_intelligence_version="0.9.0.2",
                    correlation_id=options.get("correlation_id"),
                )
                media_results = None

        if profiler:
            profiler.mark("media")

        # Phase 5: Story Structure & Completeness Validation (optional)
        story_structure = None
        graph = None  # Retain for performance metrics
        validation_result = None

        if options.get("enable_story", True):  # Enabled by default
            # DEBUG: Write to file IMMEDIATELY to confirm Phase 5 is running
            from pathlib import Path as PathLib

            debug_file = PathLib(__file__).parent / "phase5_debug.txt"
            with open(debug_file, "w") as f:
                f.write("Phase 5 STARTED\n")
                f.write(f"enable_story option: {options.get('enable_story', True)}\n")

            logs.info(
                "sae.phase_start",
                "Story structure validation started",
                name="story",
                files=len(files),
            )
            # Initialize before try block so it is always bound even if import fails
            sae_flow_edges = []
            sae_flow_status = {
                "enabled": bool(
                    self.config.get("flowchart", {}).get("sae", {}).get("enabled", True)
                ),
                "supported": True,
                "executed": False,
                "reason": "",
                "available_rules": [],
            }
            try:
                from pathlib import Path as PathLib

                from branchpy.internals.graph_builder import build_story_graph, graph_stats
                from branchpy.internals.story_validator import StoryValidator

                # Phase 1+2: Collapsed flowchart with utility chains
                # Mermaid code generation removed - using Cytoscape in webview instead
                # Build story graph from script files
                script_files = [PathLib(f) for f in files]
                graph = build_story_graph(script_files)

                if profiler:
                    profiler.mark("story_graph")

                # Phase 2: Compute PFI (Project Function Index) for inter-procedural edges
                pfi_result = None
                import sys

                try:
                    # Check if PFI is enabled in config
                    pfi_enabled = bool(
                        self.config.get("flowchart", {})
                        .get("pfi", {})
                        .get("enabled", True)
                    )
                    logs.info("pfi.flag", "PFI flag check", value=pfi_enabled)

                    if pfi_enabled:
                        # Tier-1: Extract label-level jumps and calls from index
                        tier1_pfi = self._extract_tier1_pfi_edges(index)
                        logs.info(
                            "pfi.tier1_extracted",
                            "Tier-1 PFI (label-level jumps/calls) extracted",
                            jump_edges=tier1_pfi["stats"]["jump_edges"],
                            call_edges=tier1_pfi["stats"]["call_edges"],
                        )

                        # Start with Tier-1 as base
                        pfi_result = {
                            "jump_index": tier1_pfi["jump_index"],
                            "call_index": tier1_pfi["call_index"],
                            "stats": tier1_pfi["stats"],
                            # Tier 1.6: pass screen-call terminal data through for node enrichment
                            "screen_call_labels": tier1_pfi.get(
                                "screen_call_labels", {}
                            ),
                            "screen_return_screens": tier1_pfi.get(
                                "screen_return_screens", []
                            ),
                        }

                        # Optionally add Tier-2: Python function calls from FunctionIndexer
                        try:
                            from branchpy.analysis.pfi.function_indexer import (
                                FunctionIndexer,
                            )

                            # Use project_path from index if available
                            project_path = index.get("project_path", ".")
                            pfi_indexer = FunctionIndexer(project_root=project_path)
                            tier2_result = pfi_indexer.index_project()

                            if tier2_result and "functions" in tier2_result:
                                pfi_result["functions"] = tier2_result.get("functions")
                                pfi_result["stats"]["tier2_functions"] = len(
                                    tier2_result.get("functions", [])
                                )
                                logs.info(
                                    "pfi.tier2_extracted",
                                    "Tier-2 PFI (Python function calls) extracted",
                                    functions=pfi_result["stats"].get(
                                        "tier2_functions", 0
                                    ),
                                )
                        except Exception as e:
                            logs.debug(
                                "pfi.tier2_skipped", f"Tier-2 PFI unavailable: {e}"
                            )

                        # Log final PFI result
                        logs.info(
                            "pfi.shape",
                            "PFI result structure",
                            keys=list(pfi_result.keys()),
                        )
                        logs.info(
                            "pfi.stats",
                            "PFI statistics",
                            stats=pfi_result.get("stats", {}),
                        )
                    else:
                        logs.info(
                            "pfi.disabled",
                            "PFI computation skipped",
                            enabled=pfi_enabled,
                        )
                except Exception as e:
                    logs.debug("pfi.failed", f"PFI extraction failed: {e}")
                    pfi_result = None

                # Phase 3: Compute SAE (Semantic Analysis Engine) for inferred flows
                # Note: SAE assignment extraction moved outside enable_story block (see line ~840)
                sae_result_from_pfi = None
                # Note: sae_flow_edges and sae_flow_status initialized before this try block

                # Run Phase 5 validation (R01-R03 rules)
                validator = StoryValidator()
                validation_result = validator.validate(graph)

                # Export to Phase 10 format
                story_structure = validator.export_for_phase10(validation_result)

                # DEBUG: Write to file

                debug_file = PathLib(__file__).parent / "phase5_debug.txt"
                with open(debug_file, "w") as f:
                    f.write(f"story_structure keys: {list(story_structure.keys())}\n")
                    f.write(f"story_structure length: {len(story_structure)}\n")
                    f.write(f"First 5 keys: {list(story_structure.keys())[:5]}\n")
                    f.write(f"story_structure type: {type(story_structure)}\n")

                logs.info(
                    "sae.export_phase10",
                    f"Exported story_structure: {len(story_structure)} keys, "
                    f"keys: {list(story_structure.keys())[:5]}",
                )

                # Only print progress if not in JSON-only mode
                json_mode = os.environ.get("BPY_JSON_MODE")
                if not json_mode:
                    print(
                        f"[Phase 5] Story Structure: {len(graph.nodes)} labels, "
                        + f"{len(graph.edges)} transitions, "
                        + f"{len(validation_result.diagnostics)} diagnostics"
                    )

                logs.info(
                    "sae.phase_ok",
                    "Story structure validation complete",
                    name="story",
                    labels=len(graph.nodes),
                    transitions=len(graph.edges),
                    issues_total=len(validation_result.diagnostics),
                    coverage_pct=validation_result.reachability.coverage_percentage,
                )

            except Exception as e:
                # Check if we should raise exceptions for debugging
                debug_cfg = (self.config or {}).get("debug", {})
                raise_engine_exceptions = bool(
                    debug_cfg.get("raise_engine_exceptions", False)
                )

                if raise_engine_exceptions:
                    raise

                # Graceful degradation - story validation is optional
                print(
                    f"Warning: Story validation failed: {e}",
                    file=__import__("sys").stderr,
                )
                import traceback

                traceback.print_exc()
                logs.error(
                    "sae.phase_err",
                    "Story structure validation failed",
                    name="story",
                    error=str(e),
                )
                story_structure = None
                # graph and validation_result are already None, will be handled below

        # Phase 3.5: SAE Assignment Extraction (independent of story validation)
        sae_result = None
        try:
            # Check if SAE is enabled in config
            sae_enabled = bool(
                self.config.get("flowchart", {}).get("sae", {}).get("enabled", True)
            )
            logs.info(
                "sae.assignment.flag",
                "SAE Assignment Extractor flag check",
                value=sae_enabled,
            )

            if sae_enabled:
                # Import SAE assignment extractor
                from branchpy.analysis.sae import extract_assignments_for_report
                from branchpy.semantics.ast.nodes import LabelNode
                from branchpy.semantics.ast.parser import RenpyASTParser

                logs.info(
                    "sae.assignment.start",
                    "SAE Assignment extraction started",
                    files=len(files),
                )

                # Parse AST from script files to get label nodes
                parser = RenpyASTParser()
                all_label_nodes = []
                for file_path in files:
                    try:
                        ast_nodes = parser.parse_file(file_path)
                        # Filter for LabelNode instances only
                        label_nodes = [
                            node for node in ast_nodes if isinstance(node, LabelNode)
                        ]
                        all_label_nodes.extend(label_nodes)
                    except Exception as e:
                        logs.debug(
                            "sae.assignment.parse_error",
                            f"Failed to parse {file_path}: {e}",
                        )

                # Extract statements from index for Tier 3 screen action integration
                statements = index.get("statements", {})

                # Extract assignments from parsed labels + screen actions (Tier 3)
                sae_result = extract_assignments_for_report(all_label_nodes, statements)

                logs.info(
                    "sae.assignment.extracted",
                    "SAE Assignment extraction complete",
                    assignments=len(sae_result.get("assignments", [])),
                    variables=len(sae_result.get("variables", {})),
                )
            else:
                logs.info(
                    "sae.assignment.disabled",
                    "SAE Assignment extraction skipped",
                    enabled=sae_enabled,
                )
        except Exception as e:
            import traceback

            logs.error(
                "sae.assignment.failed", f"SAE Assignment extraction failed: {e}"
            )
            traceback.print_exc()
            sae_result = None

        if profiler:
            profiler.mark("sae_assignment")

        # Phase 1: SAE Flow-Edge Inference (screen_return_property_dispatch)
        # Runs after sae_result is available from assignment extraction
        if sae_flow_status["enabled"]:
            try:
                from branchpy.analysis.sae.screen_return_resolver import (
                    infer_screen_return_property_dispatch_edges,
                )

                logs.info("sae.flow_edges.start", "Starting SAE flow-edge inference")

                # Get SAE assignments from earlier extraction
                assignments = sae_result.get("assignments", []) if sae_result else []

                # Run resolver on each file
                for file_path in files:
                    try:
                        with open(file_path, "r", encoding="utf-8") as f:
                            file_content = f.read()

                        edges = infer_screen_return_property_dispatch_edges(
                            file_path=file_path,
                            file_content=file_content,
                            assignments=assignments,
                        )
                        sae_flow_edges.extend(edges)
                    except Exception as e:
                        logs.debug(
                            "sae.flow_edges.file_error",
                            f"Error processing {file_path}: {e}",
                        )

                # Rule 2: call screen X + variable Jump resolution
                # Handles: $ var = "label" ... call screen X  (screen has Jump(var))
                try:
                    from branchpy.analysis.sae.screen_return_resolver import (
                        infer_call_screen_jump_variable_edges,
                    )

                    # Build known-label set from index
                    _idx_labels = (
                        index.get("labels", {})
                        if isinstance(index, dict)
                        else getattr(index, "labels", {})
                    )
                    known_labels_set = set(_idx_labels.keys()) if _idx_labels else set()

                    call_screen_edges = infer_call_screen_jump_variable_edges(
                        files=files,
                        known_labels=known_labels_set,
                    )
                    sae_flow_edges.extend(call_screen_edges)
                    if call_screen_edges:
                        logs.info(
                            "sae.flow_edges.call_screen_jump",
                            "SAE call_screen_jump_variable rule produced edges",
                            edges=len(call_screen_edges),
                        )
                except Exception as _e:
                    logs.debug(
                        "sae.flow_edges.call_screen_jump.error",
                        f"call_screen_jump_variable rule failed: {_e}",
                    )

                # Rule 3: PFI–SAE Callable Semantics Bridge
                # Resolves Function(foo) actions in screen blocks by looking up foo
                # in the PFI function index's calls_labels / returns_labels.
                if pfi_result and pfi_result.get("functions"):
                    try:
                        from branchpy.analysis.sae.screen_return_resolver import (
                            infer_pfi_callable_semantics_edges,
                        )

                        pfi_callable_edges = infer_pfi_callable_semantics_edges(
                            files=files,
                            pfi_functions=pfi_result["functions"],
                            known_labels=known_labels_set,
                        )
                        sae_flow_edges.extend(pfi_callable_edges)
                        if pfi_callable_edges:
                            logs.info(
                                "sae.flow_edges.pfi_callable",
                                "SAE pfi_callable_semantics rule produced edges",
                                edges=len(pfi_callable_edges),
                            )
                    except Exception as _e:
                        logs.debug(
                            "sae.flow_edges.pfi_callable.error",
                            f"pfi_callable_semantics rule failed: {_e}",
                        )

                # Update status
                sae_flow_status["executed"] = True
                sae_flow_status["available_rules"] = [
                    "screen_return_property_dispatch",
                    "call_screen_jump_variable",
                    "pfi_callable_semantics",
                ]

                if sae_flow_edges:
                    sae_flow_status["reason"] = (
                        f"Successfully inferred {len(sae_flow_edges)} edges using screen_return_property_dispatch, call_screen_jump_variable, pfi_callable_semantics"
                    )
                    logs.info(
                        "sae.flow_edges.success",
                        "SAE flow-edge inference completed",
                        edges=len(sae_flow_edges),
                        rules=sae_flow_status["available_rules"],
                    )
                else:
                    sae_flow_status["reason"] = (
                        "SAE rules executed but found no matching patterns"
                    )
                    logs.info(
                        "sae.flow_edges.no_matches",
                        "SAE flow-edge inference found no patterns",
                    )

            except ImportError as e:
                sae_flow_status["executed"] = False
                sae_flow_status["reason"] = f"SAE resolver module not available: {e}"
                logs.warning(
                    "sae.flow_edges.import_error", f"Could not import SAE resolver: {e}"
                )
            except Exception as e:
                sae_flow_status["executed"] = False
                sae_flow_status["reason"] = f"SAE flow-edge inference failed: {e}"
                logs.error(
                    "sae.flow_edges.error", f"SAE flow-edge inference error: {e}"
                )
        else:
            sae_flow_status["reason"] = "SAE not enabled in config"
            logs.info("sae.flow_edges.disabled", "SAE flow-edge inference disabled")

        # Phase 2: Observed Edge Ingestion (runtime traces)
        # Runs after SAE processing, provides ground-truth edges from gameplay
        obs_edges = []
        obs_status = {
            "enabled": bool(
                self.config.get("flowchart", {})
                .get("observed", {})
                .get("enabled", False)
            ),
            "supported": True,
            "executed": False,
            "reason": "",
            "trace_files_found": 0,
            "trace_files_used": [],
            "parse_errors": 0,
            "transitions_extracted": 0,
            "dedup_suppressed": 0,  # Observed edges suppressed by higher-priority edges (CFG/PFI)
            "labels_unmatched": 0,  # Transitions with labels not in node registry (diagnostic)
        }

        if obs_status["enabled"]:
            try:
                from branchpy.analysis.observed.trace_ingestor import (
                    ingest_observed_edges,
                )

                logs.info(
                    "observed.start", "Starting observed edge ingestion from traces"
                )

                # Get project root from index or use current directory
                project_root_str = index.get("project_path", ".")
                project_root = Path(project_root_str)
                obs_edges, obs_status = ingest_observed_edges(
                    project_root=project_root, enabled=True
                )

                if obs_edges:
                    logs.info(
                        "observed.success",
                        "Observed edge ingestion completed",
                        edges=len(obs_edges),
                        trace_files=len(obs_status["trace_files_used"]),
                    )
                else:
                    logs.info("observed.no_edges", obs_status["reason"])

            except ImportError as e:
                obs_status["executed"] = False
                obs_status["reason"] = f"Observed edge module not available: {e}"
                logs.warning(
                    "observed.import_error",
                    f"Could not import observed edge ingestor: {e}",
                )
            except Exception as e:
                obs_status["executed"] = False
                obs_status["reason"] = f"Observed edge ingestion failed: {e}"
                logs.error("observed.error", f"Observed edge ingestion error: {e}")
        else:
            obs_status["reason"] = "Observed edge ingestion not enabled in config"
            logs.info("observed.disabled", "Observed edge ingestion disabled")

        # Phase 3A: Automatic trace generation status
        # Reports on installed trace shim (generates observed traces during gameplay)
        trace_gen_status = {
            "supported": True,
            "installed": False,
            "enabled": False,
            "version": None,
            "reason": "",
            "shim_path": None,
        }

        # Check if trace shim is installed
        project_root_str = index.get("project_path", ".")
        detection = self.detect_trace_shim(project_root_str)
        trace_gen_status["installed"] = detection["installed"]
        trace_gen_status["version"] = detection["version"]
        trace_gen_status["shim_path"] = detection["path"]

        # Check if auto_trace is enabled in config
        auto_trace_config = (
            self.config.get("flowchart", {})
            .get("observed", {})
            .get("auto_trace", False)
        )
        trace_gen_status["enabled"] = auto_trace_config

        # Build reason string
        if not trace_gen_status["installed"]:
            trace_gen_status["reason"] = (
                "Trace generation shim not installed. Run: branchpy trace --install"
            )
        elif not trace_gen_status["enabled"]:
            trace_gen_status["reason"] = (
                "Trace generation disabled in config. Set flowchart.observed.auto_trace = true"
            )
        else:
            trace_gen_status["reason"] = (
                f"Trace generation active (shim v{trace_gen_status['version']} installed)"
            )

        logs.info("trace_gen.status", trace_gen_status["reason"])

        # rc.1.4: Build collapsed_graph with containers (ALWAYS, even if story validation failed)
        # This ensures execution containers are always promoted, and flowchart always has data
        collapsed_graph_nodes = []
        collapsed_graph_edges = []

        # Ensure we have story_structure to add collapsed_graph to
        if story_structure is None:
            story_structure = {}

        # Try to build collapsed_graph from graph if available
        if graph is not None and validation_result is not None:
            # Full graph available - build comprehensive collapsed_graph with containers and edges
            # Step 1: Extract execution containers from project index
            containers_by_file = {}  # file -> list of container statements
            internal_labels = set()  # Labels that are inside containers

            # Check if we have statement-level data in the index
            if (
                isinstance(index, dict)
                and "statements" in index
                and index["statements"]
            ):
                # Import statement type enum

                for file_path, statements in index["statements"].items():
                    containers_in_file = []
                    for stmt in statements:
                        # Handle both Statement objects and dicts (from serialization)
                        stmt_type = None
                        if isinstance(stmt, dict):
                            stmt_type = stmt.get("type")
                        elif hasattr(stmt, "type"):
                            stmt_type = (
                                stmt.type.value
                                if hasattr(stmt.type, "value")
                                else stmt.type
                            )

                        # Check if this is an execution container
                        if stmt_type == "execution_container":
                            containers_in_file.append(stmt)

                            # Mark all internal labels as not top-level
                            subgraph = (
                                stmt.get("subgraph", [])
                                if isinstance(stmt, dict)
                                else getattr(stmt, "subgraph", [])
                            )
                            for internal_stmt in subgraph:
                                internal_type = None
                                if isinstance(internal_stmt, dict):
                                    internal_type = internal_stmt.get("type")
                                elif hasattr(internal_stmt, "type"):
                                    internal_type = (
                                        internal_stmt.type.value
                                        if hasattr(internal_stmt.type, "value")
                                        else internal_stmt.type
                                    )

                                if internal_type == "label":
                                    label_name = (
                                        internal_stmt.get("label_name")
                                        if isinstance(internal_stmt, dict)
                                        else getattr(internal_stmt, "label_name", None)
                                    )
                                    if label_name:
                                        internal_labels.add(label_name)

                    if containers_in_file:
                        containers_by_file[file_path] = containers_in_file

            # Step 2: Build node list - containers with internal labels as children + non-internal labels
            # Add container nodes
            container_count = 0
            for file_path, containers in containers_by_file.items():
                for container in containers:
                    # Handle both Statement objects and dicts
                    container_line = (
                        container.get("line")
                        if isinstance(container, dict)
                        else container.line
                    )
                    container_name = (
                        container.get("container_name")
                        if isinstance(container, dict)
                        else container.container_name
                    )
                    container_id = (
                        f"container_{container_line}_{container_name.replace(' ', '_')}"
                    )

                    container_type = (
                        container.get("container_type")
                        if isinstance(container, dict)
                        else getattr(container, "container_type", None)
                    )
                    entry_points = (
                        container.get("entry_points", [])
                        if isinstance(container, dict)
                        else getattr(container, "entry_points", [])
                    )
                    exit_points = (
                        container.get("exit_points", [])
                        if isinstance(container, dict)
                        else getattr(container, "exit_points", [])
                    )

                    container_file = (
                        container.get("file")
                        if isinstance(container, dict)
                        else container.file
                    )

                    # Create container as parent node (Cytoscape compound node)
                    container_node = {
                        "id": container_id,  # For Cytoscape, use 'id' not 'label'
                        "label": container_name,
                        "type": "execution_container",
                        "container_type": container_type,
                        "container_name": container_name,
                        "entry_points": entry_points,
                        "exit_points": exit_points,
                        "file": container_file,
                        "line": container_line,
                        "isParent": True,  # Mark as parent for Cytoscape compound nodes
                    }
                    collapsed_graph_nodes.append(container_node)

                    # Add internal label nodes as children of container
                    subgraph_list = (
                        container.get("subgraph", [])
                        if isinstance(container, dict)
                        else getattr(container, "subgraph", [])
                    )
                    for internal_stmt in subgraph_list:
                        # Only add label statements as child nodes
                        stmt_type = None
                        if isinstance(internal_stmt, dict):
                            stmt_type = internal_stmt.get("type")
                        elif hasattr(internal_stmt, "type"):
                            stmt_type = (
                                internal_stmt.type.value
                                if hasattr(internal_stmt.type, "value")
                                else internal_stmt.type
                            )

                        if stmt_type == "label":
                            label_name = (
                                internal_stmt.get("label_name")
                                if isinstance(internal_stmt, dict)
                                else getattr(internal_stmt, "label_name", None)
                            )
                            if label_name and label_name in graph.nodes:
                                node = graph.nodes[label_name]
                                child_node = {
                                    "id": label_name,
                                    "label": label_name,  # Canonical label for mapping
                                    "type": (
                                        node.label_type.value
                                        if hasattr(node, "label_type")
                                        and node.label_type
                                        else "unknown"
                                    ),
                                    "file": node.location.file,
                                    "line": node.location.line,
                                    "line_start": node.location.line,  # Anchor for mapping
                                    "line_end": node.location.line,  # Anchor for mapping
                                    "parent": container_id,  # Make this a child of the container
                                }
                                collapsed_graph_nodes.append(child_node)

                    container_count += 1

            # Add regular label nodes (excluding internal labels)
            label_count = 0
            for label, node in graph.nodes.items():
                if label not in internal_labels:
                    node_data = {
                        "id": label,  # Use label as unique id
                        "label": label,  # Canonical label for mapping
                        "type": (
                            node.label_type.value
                            if hasattr(node, "label_type") and node.label_type
                            else "unknown"
                        ),
                        "file": node.location.file,
                        "line": node.location.line,
                        "line_start": node.location.line,  # Anchor for mapping
                        "line_end": node.location.line,  # Anchor for mapping
                    }
                    collapsed_graph_nodes.append(node_data)
                    label_count += 1

            # Build edges for collapsed_graph
            # Keep ALL edges where both endpoints exist in the node list
            # This includes:
            # - Internal edges (both children of same container)
            # - Boundary edges (one inside container, one outside)
            # - External edges (both outside containers)
            # Build set of all available node IDs for validation (match against id field)
            # D19: add "?" synthetic node early if any static edges have unresolved targets
            # (screen_return always resolves to "?" — must be a known node before edge loop)
            if any(e.to_label == "?" for e in graph.edges):
                if not any(n.get("id") == "?" for n in collapsed_graph_nodes):
                    collapsed_graph_nodes.append(
                        {
                            "id": "?",
                            "label": "?",
                            "type": "dynamic_target",
                            "synthetic": True,
                        }
                    )
            # D22: add "ENGINE" synthetic node if any entry_point edges are present
            if any(
                (e.edge_type.value if hasattr(e.edge_type, "value") else str(e.edge_type)) == "entry_point"
                for e in graph.edges
            ):
                if not any(n.get("id") == "ENGINE" for n in collapsed_graph_nodes):
                    collapsed_graph_nodes.insert(
                        0,
                        {
                            "id": "ENGINE",
                            "label": "ENGINE",
                            "type": "engine_root",
                            "synthetic": True,
                        },
                    )
            available_node_ids = {node["id"] for node in collapsed_graph_nodes}

            # Also build a mapping of label -> container_id for boundary edge detection
            label_to_container = {}
            for node in collapsed_graph_nodes:
                if "parent" in node:
                    label_to_container[node["id"]] = node["parent"]

            # Build reverse mapping: container_id -> set of child labels
            container_to_children = {}
            for label, container_id in label_to_container.items():
                if container_id not in container_to_children:
                    container_to_children[container_id] = set()
                container_to_children[container_id].add(label)

            # Track implicit return edges: for each container, track which external labels called it
            container_callers = {}  # container_id -> set of external caller labels
            container_has_return = {}  # container_id -> bool (has return path)

            for edge in graph.edges:
                # Only process edges where both endpoints exist in node list
                if (
                    edge.from_label in available_node_ids
                    and edge.to_label in available_node_ids
                ):

                    # Check if this is a boundary CALL edge (external caller -> internal child)
                    src_container = label_to_container.get(edge.from_label)
                    dst_container = label_to_container.get(edge.to_label)

                    if edge.edge_type.value == "call":
                        # If src is external (no container) and dst is internal, it's a call-in
                        if src_container is None and dst_container is not None:
                            if dst_container not in container_callers:
                                container_callers[dst_container] = set()
                            container_callers[dst_container].add(edge.from_label)

                    # Track if this container has a return edge (internal label returning)
                    if edge.edge_type.value == "return" and dst_container is not None:
                        # A child of the container has a return edge
                        container_has_return[dst_container] = True

            # Add all regular edges first
            for edge in graph.edges:
                # Only skip edges where either endpoint doesn't exist in node list
                if (
                    edge.from_label in available_node_ids
                    and edge.to_label in available_node_ids
                ):

                    # Determine if this is an internal edge (both endpoints in same container)
                    src_container = label_to_container.get(edge.from_label)
                    dst_container = label_to_container.get(edge.to_label)
                    is_internal_edge = src_container and src_container == dst_container

                    # D16/D17a/D17b: map EdgeType → edgeKind consumed by the VS Code webview.
                    # The webview reads edge.kind and stores it as Cytoscape data.edgeKind.
                    # EdgeType.IMPLICIT    → fallthrough
                    # EdgeType.CHOICE      → menu_choice
                    # EdgeType.JUMP        → jump
                    # EdgeType.CONDITIONAL → conditional_true or conditional_false (inline)
                    # EdgeType.DYNAMIC_CALL/JUMP → dynamic_call/dynamic_jump
                    # EdgeType.CALL/RETURN remain as-is.
                    # All others fall back to "direct".
                    _raw_type = (
                        edge.edge_type.value
                        if hasattr(edge.edge_type, "value")
                        else str(edge.edge_type)
                    )
                    # D17a: resolve conditional branch direction
                    if _raw_type == "conditional":
                        _branch = getattr(edge, "condition_branch", None)
                        _kind = "conditional_false" if _branch == "false" else "conditional_true"
                    else:
                        _kind = EDGE_KIND_MAP.get(_raw_type, "direct")

                    # Build the edge dict
                    _edge_dict: dict = {
                        "src": edge.from_label,
                        "dst": edge.to_label,
                        "kind": _kind,
                        "edge_type": _raw_type,
                        "isInternal": is_internal_edge,
                    }
                    _cond = getattr(edge, "condition", None)
                    if _cond:
                        _edge_dict["condition"] = _cond
                    # D17b: include the raw dynamic expression for hover tooltips
                    _dyn_expr = getattr(edge, "dynamic_expr", None)
                    if _dyn_expr:
                        _edge_dict["dynamic_expr"] = _dyn_expr

                    collapsed_graph_edges.append(_edge_dict)

            # Add implicit return edges for containers that can return
            for container_id, callers in container_callers.items():
                # If any child of this container has a return edge, assume all callers can receive returns
                if container_has_return.get(container_id, False):
                    for caller_label in callers:
                        collapsed_graph_edges.append(
                            {
                                "src": container_id,
                                "dst": caller_label,
                                "kind": "return",
                                "edge_type": "return",
                                "isInternal": False,
                                "isImplicitReturn": True,
                            }
                        )
        else:
            # Fallback: story validation failed, build simple graph from labels in index
            # This ensures flowchart always has data even without full validation
            if isinstance(index, dict) and "labels" in index:
                for label_name, label_info in index["labels"].items():
                    node_data = {
                        "label": label_name,
                        "type": (
                            label_info.get("type", "unknown")
                            if isinstance(label_info, dict)
                            else "unknown"
                        ),
                        "file": (
                            label_info.get("file", "")
                            if isinstance(label_info, dict)
                            else ""
                        ),
                        "line": (
                            label_info.get("line", 0)
                            if isinstance(label_info, dict)
                            else 0
                        ),
                    }
                    collapsed_graph_nodes.append(node_data)

            # Don't add edges in fallback mode (would require processing jumps without graph structure)

        # Phase 1+3: Edge Reconciliation Pipeline (ERP) - normalize CFG+PFI+SAE edges with provenance schema
        # All edges now include origin, confidence, meta fields

        # If upstream produced these results, consume them.
        # Otherwise remain empty (guarded, non-fatal).
        pfi_result = locals().get("pfi_result", None)
        sae_result = locals().get("sae_result", None)

        pfi_edges = []
        # Phase 2: PFI integration extracts inter-procedural edges
        # extract_pfi_edges supports both Shape 1 (jump_index/call_index) and Shape 2 (edge list)
        if (
            pfi_result
            and isinstance(pfi_result, dict)
            and (
                "edges" in pfi_result
                or "jump_index" in pfi_result
                or "call_index" in pfi_result
            )
        ):
            pfi_edges = extract_pfi_edges(pfi_result)

        # D11/D17b: if any DYNAMIC_CALL / DYNAMIC_JUMP edges with dst="?" are present
        # (from PFI or from graph_builder CFG edges), add the synthetic '?' node so the
        # ERP's keep_only_known_endpoints guard does not drop unresolved dynamic edges.
        _has_unresolved_dynamic = any(
            e.get("kind") in ("dynamic_call", "dynamic_jump")
            or e.get("edge_type") in ("dynamic_call", "dynamic_jump")
            for e in pfi_edges
        ) or any(
            e.get("dst") == "?"
            for e in collapsed_graph_edges
        )
        if _has_unresolved_dynamic:
            node_ids_present = {
                n.get("id") for n in collapsed_graph_nodes if n.get("id")
            }
            if "?" not in node_ids_present:
                collapsed_graph_nodes.append(
                    {
                        "id": "?",
                        "label": "?",
                        "type": "dynamic_target",
                        "synthetic": True,
                    }
                )

        sae_edges = []
        # Phase 3: SAE integration extracts semantic analysis edges
        if (
            sae_result
            and isinstance(sae_result, dict)
            and ("edges" in sae_result or "inferred_flows" in sae_result)
        ):
            sae_edges = extract_sae_edges(sae_result)

        # Phase 0: Add SAE flow edges (currently empty, will be populated in Phase 1)
        if "sae_flow_edges" in locals():
            sae_edges.extend(sae_flow_edges)

        # Phase 2: Add observed edges from runtime traces
        if "obs_edges" in locals() and obs_edges:
            # Observed edges are already in final format, no extraction needed
            pass  # Will be passed directly to ERP

        # Phase 2.4.3: Log extraction results with causality
        logs.info(
            "analysis_sources.extraction_summary",
            "Edge extraction completed - config gating result",
            pfi_enabled=bool(
                self.config.get("flowchart", {}).get("pfi", {}).get("enabled", True)
            ),
            pfi_result_available=pfi_result is not None,
            pfi_edges_extracted=len(pfi_edges),
            sae_enabled=bool(
                self.config.get("flowchart", {}).get("sae", {}).get("enabled", True)
            ),
            sae_result_available=sae_result is not None,
            sae_edges_extracted=len(sae_edges),
            observed_enabled=bool(
                self.config.get("flowchart", {})
                .get("observed", {})
                .get("enabled", False)
            ),
            observed_edges_extracted=len(obs_edges) if "obs_edges" in locals() else 0,
            cfg_edges_available=len(collapsed_graph_edges),
        )

        # Log edge extraction results before ERP
        logs.info(
            "pfi.edges_extracted",
            "PFI edge extraction completed",
            edges=len(pfi_edges),
            pfi_functions=(
                pfi_result.get("stats", {}).get("total_functions", 0)
                if pfi_result
                else 0
            ),
        )

        # Prepare observed edges for ERP (if available)
        observed_edges = obs_edges if "obs_edges" in locals() else []

        erp_edges, erp_stats = resolve_semantic_edges(
            nodes=collapsed_graph_nodes,
            cfg_edges=collapsed_graph_edges,
            pfi_edges=pfi_edges,
            sae_edges=sae_edges,
            observed_edges=observed_edges,
            keep_only_known_endpoints=True,
        )

        # Update obs_status with dedup suppression count from ERP
        if "obs_status" in locals() and erp_stats.get("observed_suppressed", 0) > 0:
            obs_status["dedup_suppressed"] = erp_stats["observed_suppressed"]

        # Count observed edges with missing endpoints (label mismatch diagnostic)
        if "obs_status" in locals() and "obs_edges" in locals():
            node_ids = {n.get("id") for n in collapsed_graph_nodes if n.get("id")}
            labels_unmatched = 0
            for edge in obs_edges:
                if edge.get("src") not in node_ids or edge.get("dst") not in node_ids:
                    labels_unmatched += 1
            if labels_unmatched > 0:
                obs_status["labels_unmatched"] = labels_unmatched
                logs.warning(
                    "observed.labels_unmatched",
                    f"{labels_unmatched} observed edges reference labels not in node registry",
                    unmatched_count=labels_unmatched,
                    total_observed=len(obs_edges),
                )

        # Log ERP edge loss analysis
        pfi_in = erp_stats.get("pfi_in", 0)
        pfi_dropped = (
            erp_stats.get("dropped_missing_endpoints", 0)
            if erp_stats.get("pfi_in", 0) > 0
            else 0
        )
        cfg_in = erp_stats.get("cfg_in", 0)
        cfg_out = len([e for e in erp_edges if e.get("origin") == "cfg"])
        pfi_out = len([e for e in erp_edges if e.get("origin") == "pfi"])
        sae_out = len([e for e in erp_edges if e.get("origin") == "sae"])

        # Phase 2.4.3: Add edge provenance breakdown to show why PFI/SAE contributed 0
        logs.info(
            "erp.edges_by_origin",
            "Edge Reconciliation Pipeline - provenance breakdown",
            cfg_in=cfg_in,
            cfg_out=cfg_out,
            pfi_in=pfi_in,
            pfi_out=pfi_out,
            pfi_dropped_no_endpoints=pfi_dropped,
            sae_in=erp_stats.get("sae_in", 0),
            sae_out=sae_out,
            total_merged_edges=len(erp_edges),
        )

        logs.info(
            "erp.pipeline_summary",
            "Edge reconciliation completed - data flow analysis",
            cfg_edges_in=cfg_in,
            cfg_edges_out=cfg_out,
            pfi_edges_in=pfi_in,
            pfi_edges_out=pfi_out,
            pfi_edges_dropped_unknown_endpoints=pfi_dropped,
            total_edges_out=len(erp_edges),
            unique_canonical_keys=erp_stats.get("normalized_total", 0),
            duplicate_groups=erp_stats.get("duplicate_groups", 0),
        )

        # Phase 4: Enforce container safety for synthetic nodes
        for node in collapsed_graph_nodes:
            if node.get("synthetic"):
                # Synthetic nodes must never be inside containers
                node.pop("parent", None)
                node["parent"] = None

        # Log ERP statistics
        logs.info(
            "semantic_edges.erp_stats",
            "Edge reconciliation pipeline processed CFG edges",
            extra={"stats": erp_stats},
        )

        # Always add collapsed_graph to story_structure (even if empty/no containers)

        # Build UI-friendly edge source summary
        edges_by_origin = {
            "cfg": int(
                erp_stats.get("confidence_by_origin", {}).get("cfg", {}).get("count", 0)
            ),
            "pfi": int(
                erp_stats.get("confidence_by_origin", {}).get("pfi", {}).get("count", 0)
            ),
            "sae": int(
                erp_stats.get("confidence_by_origin", {}).get("sae", {}).get("count", 0)
            ),
            "synthetic": int(
                erp_stats.get("confidence_by_origin", {})
                .get("synthetic", {})
                .get("count", 0)
            ),
        }

        # Fallback: count edges directly if confidence_by_origin unavailable
        if not any(edges_by_origin.values()):
            for e in erp_edges:
                o = (e.get("origin") or "cfg").lower()
                if o in edges_by_origin:
                    edges_by_origin[o] += 1

        # Generate analysis run_id and timestamp for artifact verification (Phase 2.4.3)
        analysis_run_id = str(uuid.uuid4())
        analysis_timestamp = datetime.now(timezone.utc).isoformat()

        # Capture analysis sources snapshot (Phase 2.4.3: config-truth verification)
        flowchart_config = self.config.get("flowchart", {})
        analysis_sources_snapshot = {
            "pfi_enabled": bool(flowchart_config.get("pfi", {}).get("enabled", True)),
            "sae_enabled": bool(flowchart_config.get("sae", {}).get("enabled", True)),
            "synthetic_enabled": bool(
                flowchart_config.get("synthetic", {}).get("enabled", True)
            ),
        }

        # Tier 1.6: Enrich nodes with ui_terminal flag for screen-call terminals.
        # Labels that end with `call screen X` should not be classified as dead-ends
        # even when their jump target is unresolved — the screen UI controls the exit.
        _scl = (
            pfi_result.get("screen_call_labels", {})
            if pfi_result and isinstance(pfi_result, dict)
            else {}
        )
        if _scl:
            for node in collapsed_graph_nodes:
                nid = str(node.get("id", ""))
                if nid in _scl:
                    node["ui_terminal"] = True
                    node["via_screen"] = _scl[nid]
            logs.info(
                "tier1.ui_terminal_enriched",
                "Nodes marked as ui_terminal (screen-call terminals)",
                count=sum(1 for n in collapsed_graph_nodes if n.get("ui_terminal")),
            )

        flow_analysis = analyze_flow_graph(collapsed_graph_nodes, erp_edges)
        node_analysis = flow_analysis.get("node_metadata", {})
        for node in collapsed_graph_nodes:
            node_id = str(node.get("id", ""))
            if node_id in node_analysis:
                node.update(node_analysis[node_id])

        # D11 Phase 3: Append synthetic RETURN edges (callee → caller) for visualization.
        # These are produced by analyze_flow_graph from call_return_pairs.
        # They are purely additive to erp_edges; reachability analysis already completed above.
        _d11_return_edges = flow_analysis.get("synthetic_return_edges", [])
        if _d11_return_edges:
            _existing_return_keys = {
                (e.get("src"), e.get("dst"))
                for e in erp_edges
                if e.get("kind") == "return" or e.get("edge_type") == "return"
            }
            _added = 0
            for _re in _d11_return_edges:
                _rk = (_re.get("src"), _re.get("dst"))
                if _rk not in _existing_return_keys:
                    erp_edges.append(_re)
                    _existing_return_keys.add(_rk)
                    _added += 1
            logs.info(
                "d11.synthetic_return_edges_appended",
                "D11 Phase 3: synthetic RETURN edges added to collapsed graph",
                requested=len(_d11_return_edges),
                added=_added,
            )

        story_structure["collapsed_graph"] = {
            "nodes": collapsed_graph_nodes,
            "edges": erp_edges,  # Use ERP-processed edges with provenance schema
            "stats": {
                **erp_stats,  # Include confidence distribution, per-origin counts
                "edges_by_origin": edges_by_origin,  # UI-friendly summary
                "entry_nodes": len(flow_analysis.get("entry_nodes", [])),
                "unreachable_nodes": len(flow_analysis.get("unreachable_nodes", [])),
                "terminal_end_nodes": len(flow_analysis.get("terminal_end_nodes", [])),
                "dead_end_nodes": len(flow_analysis.get("dead_end_nodes", [])),
                "screen_terminal_nodes": len(
                    flow_analysis.get("screen_terminal_nodes", [])
                ),
                "component_count": len(flow_analysis.get("components", [])),
                "cluster_count": int(
                    flow_analysis.get("semantic_summary", {})
                    .get("counts", {})
                    .get("cluster_count", len(flow_analysis.get("cluster_layout", [])))
                ),
                "backbone_length": int(
                    flow_analysis.get("semantic_summary", {})
                    .get("counts", {})
                    .get("backbone_length", 0)
                ),
                "branch_bundle_count": int(
                    flow_analysis.get("semantic_summary", {})
                    .get("counts", {})
                    .get("branch_bundle_count", 0)
                ),
                "terminal_bundle_count": int(
                    flow_analysis.get("semantic_summary", {})
                    .get("counts", {})
                    .get("terminal_bundle_count", 0)
                ),
                "merge_corridor_count": int(
                    flow_analysis.get("semantic_summary", {})
                    .get("counts", {})
                    .get("merge_corridor_count", 0)
                ),
                "branch_hub_nodes": len(flow_analysis.get("branch_hub_nodes", [])),
                "utility_nodes": len(flow_analysis.get("utility_nodes", [])),
                "narrative_nodes": len(flow_analysis.get("narrative_nodes", [])),
                "longest_reachable_depth": int(
                    flow_analysis.get("longest_reachable_depth", 0)
                ),
            },
            "analysis_run_id": analysis_run_id,  # Phase 2.4.3: Artifact verification
            "analysis_timestamp": analysis_timestamp,  # Phase 2.4.3: Artifact verification
            "analysis_sources_snapshot": analysis_sources_snapshot,  # Phase 2.4.3: Config-truth proof
            "analysis": {
                "entry_nodes": flow_analysis.get("entry_nodes", []),
                "reachable_nodes": flow_analysis.get("reachable_nodes", []),
                "unreachable_nodes": flow_analysis.get("unreachable_nodes", []),
                "terminal_end_nodes": flow_analysis.get("terminal_end_nodes", []),
                "dead_end_nodes": flow_analysis.get("dead_end_nodes", []),
                "components": flow_analysis.get("components", []),
                "cluster_layout": flow_analysis.get("cluster_layout", []),
                "branch_hub_nodes": flow_analysis.get("branch_hub_nodes", []),
                "utility_nodes": flow_analysis.get("utility_nodes", []),
                "narrative_nodes": flow_analysis.get("narrative_nodes", []),
                "semantic_summary": flow_analysis.get("semantic_summary", {}),
                "warnings": flow_analysis.get("warnings", []),
            },
        }

        # Phase 3B.1-A: Merge static graph certainty into collapsed_graph
        # Read from index dict (architectural fix: don't rely on instance state)
        static_graph_dict = index.get("static_graph")
        if static_graph_dict:
            # Build certainty map from static graph edges
            certainty_map = {}
            for edge in static_graph_dict.get("edges", []):
                from_label = edge.get("from", {}).get("label")
                to_label = edge.get("to", {}).get("label")
                if from_label and to_label:
                    key = (from_label, to_label)
                    certainty_map[key] = edge.get("certainty", "unknown")

            # Add certainty to collapsed_graph edges
            for edge in erp_edges:
                src = edge.get("src")
                dst = edge.get("dst")
                if src and dst:
                    key = (src, dst)
                    if key in certainty_map:
                        edge["certainty"] = certainty_map[key]

            # Add uncertainties list
            uncertainties_list = static_graph_dict.get("uncertainties", [])
            story_structure["collapsed_graph"]["uncertainties"] = [
                {
                    "location": u.get("location", ""),
                    "reason": u.get("reason", ""),
                    "detail": u.get("detail", ""),
                }
                for u in uncertainties_list
            ]

        # D21: Serialize hotspot diagnostics — parallel to collapsed_graph, not mixed into edges
        if graph is not None and hasattr(graph, "hotspot_diagnostics"):
            story_structure["diagnostics"] = [
                {
                    "category": d.category,
                    "from_label": d.from_label,
                    "location": {"file": d.location.file, "line": d.location.line},
                    "reason": d.reason,
                    "edge_emitted": d.edge_emitted,
                    "edge_kind": d.edge_kind,
                }
                for d in graph.hotspot_diagnostics
            ]

            logs.info(
                "static_graph.merged",
                f"Merged static graph certainty: {len(certainty_map)} edges, "
                f"{len(uncertainties_list)} uncertainties",
            )

        # rc.1.4 Debug logging
        container_nodes = [
            n for n in collapsed_graph_nodes if n.get("type") == "execution_container"
        ]
        child_nodes = [n for n in collapsed_graph_nodes if "parent" in n]
        logs.info(
            "rc14_container_structure",
            f"Collapsed graph has {len(container_nodes)} containers and {len(child_nodes)} child nodes",
            containers=len(container_nodes),
            children=len(child_nodes),
            total_nodes=len(collapsed_graph_nodes),
            sample_containers=[
                {"id": c.get("id"), "label": c.get("label"), "type": c.get("type")}
                for c in container_nodes[:2]
            ],
            sample_children=[
                {"id": c.get("id"), "label": c.get("label"), "parent": c.get("parent")}
                for c in child_nodes[:2]
            ],
        )

        # Semantic grouping — FLOWCHART-SEMANTIC-COMPRESSION-V1
        # Compute groups for ALL three presets at analysis time so the renderer
        # can switch between them instantly without a re-analysis round-trip.
        # groups_by_preset["conservative" | "balanced" | "aggressive"] → list[dict]
        # "groups" = legacy key, kept for backward-compat (used by html_report.py).
        try:
            from branchpy.analysis.group_types import group_to_dict
            from branchpy.analysis.semantic_grouping import detect_auto_groups

            _groups_by_preset: dict = {}
            for _preset_name in ("conservative", "balanced", "aggressive"):
                _pg = detect_auto_groups(
                    nodes=collapsed_graph_nodes,
                    edges=erp_edges,
                    preset=_preset_name,
                    existing_groups=[],
                    node_fingerprints={},
                )
                _groups_by_preset[_preset_name] = [group_to_dict(g) for g in _pg]

            story_structure["collapsed_graph"]["groups_by_preset"] = _groups_by_preset
            # Backward-compat: "groups" = configured preset (default off → [])
            _auto_group_preset = (
                (self.config or {}).get("flowchart", {}).get("auto_group_preset", "off")
            )
            story_structure["collapsed_graph"]["groups"] = _groups_by_preset.get(
                str(_auto_group_preset), []
            )
            _total = sum(len(v) for v in _groups_by_preset.values())
            logs.info(
                "semantic_grouping.complete",
                f"Semantic grouping precomputed for all presets: {_total} total group(s)",
                group_counts={k: len(v) for k, v in _groups_by_preset.items()},
            )
        except Exception as _sg_err:
            # Graceful degradation — grouping is optional and must not break analysis
            story_structure["collapsed_graph"].setdefault("groups", [])
            story_structure["collapsed_graph"].setdefault("groups_by_preset", {})
            logs.warning(
                "semantic_grouping.failed",
                f"Semantic grouping skipped: {_sg_err}",
            )

        # Phase 4.7: Image Validation (optional, runs even without labels)
        image_validation_results = None
        if options.get("enable_images", True):  # Enabled by default
            logs.info(
                "sae.phase_start",
                "Image validation started",
                name="images",
                files=len(files),
            )
            try:
                from branchpy.analysis.sae.image_validator import ImageValidator

                project_root = Path(index.get("project_path", "."))
                img_validator = ImageValidator(str(project_root))

                # Prepare label data for validation
                label_data = {}
                for label_name, label_info in labels.items():
                    file_path = label_info.get("file", "")
                    line_num = label_info.get("line", 0)

                    # Extract label content (simplified - reads entire file)
                    try:
                        label_file = Path(file_path)
                        if label_file.exists():
                            content = label_file.read_text(
                                encoding="utf-8", errors="ignore"
                            )
                            # Extract label body (from label definition to next label or EOF)
                            lines = content.split("\n")
                            start_idx = line_num - 1 if line_num > 0 else 0

                            # Find next label or end of file
                            end_idx = len(lines)
                            for i in range(start_idx + 1, len(lines)):
                                if lines[i].strip().startswith("label "):
                                    end_idx = i
                                    break

                            label_content = "\n".join(lines[start_idx:end_idx])

                            label_data[label_name] = {
                                "content": label_content,
                                "file": file_path,
                                "line": line_num,
                            }
                    except Exception as e:
                        logs.warn(
                            "sae.phase_err",
                            f"Failed to extract content for label {label_name}",
                            name="images",
                            error=str(e),
                        )
                        continue

                # Run validation
                image_validation_results = img_validator.validate_project(label_data)

                totals = image_validation_results.get("totals", {})
                logs.info(
                    "sae.phase_ok",
                    "Image validation complete",
                    name="images",
                    labels_with_images=totals.get("labels_with_images", 0),
                    unique_images=totals.get("unique_images", 0),
                    missing_images=totals.get("missing_images", 0),
                    placeholders=totals.get("placeholders", 0),
                )

            except ImportError:
                logs.warn(
                    "sae.phase_err", "ImageValidator not available", name="images"
                )
            except Exception as e:
                logs.error(
                    "sae.phase_err",
                    "Image validation failed",
                    name="images",
                    error=str(e),
                )
                import traceback

                traceback.print_exc()

        # Legacy analysis (kept for compatibility)
        issues = []
        if not labels:
            # v1.1.0: Discovery layer already caught "no .rpy files" case
            # This only fires when files exist but no labels found
            file_count = len(index.get("files", {}))

            issues.append(
                {
                    "severity": "warning",
                    "rule": "RENPY:NO_LABELS_FOUND",
                    "message": f"No Ren'Py labels detected in {file_count} .rpy file(s).",
                    "hint": "Add 'label start:' or other labels to your .rpy files.",
                }
            )
            logs.warn(
                "sae.phase_err",
                "No labels found in project",
                name="control_flow",
                file_count=file_count,
            )
            return {
                "engine": "renpy",
                "summary": {
                    "labels": 0,
                    "files": file_count,
                },
                "issues": issues,
                "media": media_results,  # Phase 4.5: Include media even when no labels
                "image_validation": image_validation_results,  # Include even when no labels
                "meta": {
                    "version": "0.9.0-dev1"
                },  # Bump version for media intelligence
            }

        # Phase 1: Control Flow Analysis
        logs.info(
            "sae.phase_start",
            "Control flow analysis started",
            name="control_flow",
            labels=len(labels),
        )
        cfg = build_cfg(index)
        # Convert CFG findings into normalized issues
        for tgt in cfg["undefined_targets"]:
            issues.append(
                {
                    "severity": "error",
                    "rule": "RENPY:UNDEFINED_JUMP_TARGET",
                    "message": f"Jump/Call target '{tgt}' is not defined.",
                    "hint": "Define a label with this name or fix the reference.",
                    "target": tgt,
                }
            )
        for lbl in cfg["unreachable"]:
            # Get file and line info from labels index
            label_info = labels.get(lbl, {})
            file_path = label_info.get("file", "")
            line_num = label_info.get("line", 0)

            issues.append(
                {
                    "severity": "warning",
                    "rule": "RENPY:UNREACHABLE_LABEL",
                    "message": f"Label '{lbl}' is not reachable from the entry point.",
                    "hint": "Ensure there is a path (jump/call) from 'start' or entry.",
                    "label": lbl,
                    "file": file_path,
                    "line": line_num,
                }
            )

        logs.info(
            "sae.phase_ok",
            "Control flow analysis complete",
            name="control_flow",
            nodes=len(cfg["graph"]["nodes"]),
            edges=len(cfg["graph"]["edges"]),
            undefined_targets=len(cfg["undefined_targets"]),
            unreachable=len(cfg["unreachable"]),
        )

        # Phase 6: Performance export
        performance = None
        if profiler:
            profiler.finish_session()

            # Derive graph stats if available
            derived = {}
            if graph is not None:
                try:
                    from branchpy.internals.graph_builder import graph_stats

                    derived = graph_stats(graph)
                except Exception:
                    pass

            performance = profiler.export(derived=derived)

        # Log analysis completion summary
        total_issues = len(issues)
        total_warnings = sum(1 for i in issues if i.get("severity") == "warning")
        logs.info(
            "sae.phase_ok",
            "SAE analysis complete",
            name="analyze",
            labels=len(labels),
            files=len(files),
            issues_total=total_issues,
            warnings_total=total_warnings,
            has_assets=asset_results is not None,
            has_media=media_results is not None,
            has_story=story_structure is not None,
            has_performance=performance is not None,
            has_images=image_validation_results is not None,
        )

        # Assemble flowchart from ERP results (Phase 1-3: CFG+PFI+SAE)
        # CONTRACT: Analysis vs Flowchart (docs/v1.0.0/flowchart/ANALYSIS_VS_FLOWCHART_CONTRACT.md)
        # - CFG edges always computed and included (facts)
        # - PFI edges included only if config.flowchart.pfi enabled (optional facts, factual)
        # - SAE edges included only if config.flowchart.sae enabled (inferred, opt-in)
        # - Synthetic edges are rendering-only, not included here
        # - Tier-1 PFI is factual: no inference, only literal jumps/calls from index

        # Note: analysis_run_id and analysis_sources_snapshot are already added to collapsed_graph above
        flowchart = {
            "cfg_edges": collapsed_graph_edges,
            "pfi_edges": pfi_edges,
            "sae_edges": sae_edges,
            "sae_status": locals().get(
                "sae_flow_status",
                {
                    "enabled": bool(
                        self.config.get("flowchart", {})
                        .get("sae", {})
                        .get("enabled", True)
                    ),
                    "supported": True,
                    "executed": False,
                    "reason": "SAE flow-edge analysis was not run (story validation failed or not enabled)",
                    "available_rules": [],
                },
            ),  # Phase 0: SAE status transparency
            "obs_status": locals().get(
                "obs_status",
                {
                    "enabled": bool(
                        self.config.get("flowchart", {})
                        .get("observed", {})
                        .get("enabled", False)
                    ),
                    "supported": True,
                    "executed": False,
                    "reason": "Observed edge ingestion was not run",
                    "trace_files_found": 0,
                    "trace_files_used": [],
                    "parse_errors": 0,
                    "transitions_extracted": 0,
                    "dedup_suppressed": 0,
                    "labels_unmatched": 0,
                },
            ),  # Phase 2: Observed edges status transparency
            "trace_gen_status": locals().get(
                "trace_gen_status",
                {
                    "supported": True,
                    "installed": False,
                    "enabled": False,
                    "version": None,
                    "reason": "Trace generation shim not detected",
                    "shim_path": None,
                },
            ),  # Phase 3A: Automatic trace generation status
            "erp_edges": erp_edges,
            "erp_stats": erp_stats,
            "edges_by_origin": edges_by_origin,
            "analysis_run_id": analysis_run_id,  # Phase 2.4.3: Artifact verification
            "analysis_timestamp": analysis_timestamp,  # Phase 2.4.3: Artifact verification
            "analysis_sources_snapshot": analysis_sources_snapshot,  # Phase 2.4.3: Config-truth proof
        }

        # Build result dict with conditional SAE inclusion
        result = {
            "engine": "renpy",
            "summary": {
                "labels": len(labels),
                "files": len(files),
            },
            "cfg": {
                "nodes": len(cfg["graph"]["nodes"]),
                "edges": len(cfg["graph"]["edges"]),
            },
            "issues": issues,
            "rules": rules_results,
            "assets": asset_results,  # Phase 2: Asset validation results (None if disabled)
            "media": media_results,  # Phase 4.5: Media intelligence results (v0.9.0+, None if disabled)
            "story_structure": story_structure,  # Phase 5: Story structure validation (None if disabled)
            "performance": performance,  # Phase 6: Performance metrics (None if disabled)
            "image_validation": image_validation_results,  # Phase 4.7: Image validation results
            "flowchart": flowchart,  # Phase 1-3: Flowchart with CFG+PFI+SAE edges
            "meta": {
                "version": "0.9.0-dev1",  # Bump version for media intelligence
                "analysis_run_id": analysis_run_id,  # Phase 2.4.3: Top-level run correlation
                "analysis_timestamp": analysis_timestamp,  # Phase 2.4.3: Top-level timestamp
                "has_static_explorer": bool(
                    index.get("static_graph")
                ),  # Phase 3B.1-A: Read from index dict
                "static_uncertainties": len(
                    index.get("static_graph", {}).get("uncertainties", [])
                ),  # Phase 3B.1-A
            },
            "debug": {
                "dot": cfg.get("dot", "")
            },  # Always include debug/dot for CFG export
        }

        # Contract A: Add SAE only if enabled and successfully extracted
        if sae_result is not None:
            result["sae"] = sae_result

        return result

    def _resolve_renpy_launcher(self) -> Path:
        """
        Resolve Ren'Py launcher executable using config or environment.

        Uses Ren'Py's official CLI contract:
        - Windows: renpy.exe
        - Linux: renpy.sh
        - macOS: renpy.app/Contents/MacOS/renpy

        Discovery order:
        1. config["renpy"]["sdk_path"]
        2. Environment variable RENPY_SDK_PATH
        3. Fail with remediation instructions

        Returns:
            Path to platform-specific launcher executable

        Raises:
            FileNotFoundError: If SDK not configured or launcher not found
        """
        import platform
        from pathlib import Path

        # Resolve SDK path from config or environment
        sdk_path_str = None

        # Try config first
        if self.config and "renpy" in self.config:
            sdk_path_str = self.config["renpy"].get("sdk_path")

        # Fallback to environment
        if not sdk_path_str:
            sdk_path_str = os.environ.get("RENPY_SDK_PATH")

        if not sdk_path_str:
            raise FileNotFoundError(
                "Ren'Py SDK path not configured.\n\n"
                "To fix, add one of:\n"
                "  1. In .branchpy.toml: [renpy]\n     sdk_path = '/path/to/renpy-sdk'\n"
                "  2. Environment: set RENPY_SDK_PATH=/path/to/renpy-sdk\n\n"
                "Example SDK structures:\n"
                "  - Windows: C:/renpy-8.3.0-sdk/\n"
                "  - Linux: ~/renpy-8.3.0-sdk/\n"
                "  - macOS: /Applications/renpy-8.3.0-sdk/"
            )

        sdk_path = Path(sdk_path_str)

        if not sdk_path.exists():
            raise FileNotFoundError(
                f"Configured Ren'Py SDK path does not exist: {sdk_path}\n"
                "Please verify the path is correct and accessible."
            )

        # Resolve platform-specific launcher
        system = platform.system()

        if system == "Windows":
            launcher = sdk_path / "renpy.exe"
        elif system == "Darwin":  # macOS
            # Try .app bundle first, fallback to renpy.sh
            app_launcher = sdk_path / "renpy.app" / "Contents" / "MacOS" / "renpy"
            if app_launcher.exists():
                launcher = app_launcher
            else:
                launcher = sdk_path / "renpy.sh"
        else:  # Linux and others
            launcher = sdk_path / "renpy.sh"

        if not launcher.exists():
            raise FileNotFoundError(
                f"Ren'Py launcher not found at: {launcher}\n"
                f"SDK path: {sdk_path}\n"
                f"Platform: {system}\n\n"
                "Expected launcher locations:\n"
                "  - Windows: renpy.exe\n"
                "  - Linux: renpy.sh\n"
                "  - macOS: renpy.app/Contents/MacOS/renpy or renpy.sh"
            )

        logs.info("engine.resolve_launcher", f"Resolved Ren'Py launcher: {launcher}")
        return launcher

    def _launch_renpy_for_runner(self, project_path: str, session_id: str) -> Any:
        """
        Launch Ren'Py subprocess for automated exploration.

        Uses Ren'Py's official CLI contract:
        - Command: <launcher> <project_path>
        - Working directory: project root (for config.basedir)
        - Output: redirected to .branchpy/runner/renpy_{session_id}.log

        Args:
            project_path: Absolute path to Ren'Py project
            session_id: Session ID for log file naming

        Returns:
            subprocess.Popen instance

        Raises:
            FileNotFoundError: If Ren'Py launcher not found
            RuntimeError: If launch fails
        """
        import subprocess
        from pathlib import Path

        project_path_obj = Path(project_path)

        # Resolve launcher executable
        try:
            launcher = self._resolve_renpy_launcher()
        except FileNotFoundError as e:
            raise FileNotFoundError(str(e))

        # Prepare log file
        log_dir = project_path_obj / ".branchpy" / "runner"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / f"renpy_{session_id}.log"

        # Build command: <launcher> <project_path>
        # Working directory: project root (critical for config.basedir)
        cmd = [str(launcher), str(project_path)]

        logs.info("engine.launch_renpy", f"Launching Ren'Py: {' '.join(cmd)}")
        logs.info("engine.launch_renpy.cwd", f"Working directory: {project_path}")
        logs.info("engine.launch_renpy.log", f"Output: {log_file}")

        # Launch process with project root as working directory
        try:
            with open(log_file, "w", encoding="utf-8") as log_handle:
                proc = subprocess.Popen(
                    cmd,
                    cwd=str(project_path),  # Critical: sets config.basedir
                    stdout=log_handle,
                    stderr=subprocess.STDOUT,
                    text=True,
                )

            logs.info(
                "engine.launch_renpy.started", f"Ren'Py process started: PID={proc.pid}"
            )
            return proc

        except Exception as e:
            raise RuntimeError(f"Failed to launch Ren'Py: {e}")

    def run_trace_exploration(
        self,
        project_path: str,
        session_id: str,
        mode: str,
        budget_sec: int,
        max_depth: int,
        trace_timeout: int,
    ) -> Dict[str, Any]:
        """
        Phase 3B.1: Run automated trace exploration via RenpyRunner.

        Architecture:
        - Engine launches Ren'Py subprocess and manages lifecycle
        - Runner consumes trace events and injects control decisions
        - Tailer detects process termination via TimeoutReason.PROCESS_TERMINATED

        Args:
            project_path: Absolute path to Ren'Py project
            session_id: Session identifier for this run
            mode: Exploration mode ("basic" for 3B.1 MVP)
            budget_sec: Time budget in seconds
            max_depth: Maximum exploration depth
            trace_timeout: Timeout for trace event polling (seconds)

        Returns:
            Run summary dict with counters and diagnostics
        """
        from datetime import datetime

        from branchpy.runners import RenpyRunner

        logs.info(
            "engine.trace_exploration",
            f"Starting automated exploration: session={session_id} budget={budget_sec}s",
        )

        # Launch Ren'Py process
        try:
            proc = self._launch_renpy_for_runner(project_path, session_id)
        except (FileNotFoundError, RuntimeError) as e:
            logs.error("engine.launch_failed", str(e))
            return {
                "session_id": session_id,
                "success": False,
                "error": str(e),
                "termination_reason": "launch_failed",
            }

        # Create runner and attach process
        runner = RenpyRunner(project_path)
        runner.session_id = session_id
        runner.attach_process(proc)

        # Set budget and depth limits (already set in __init__ via config, but override if specified)
        runner.budget_sec = budget_sec
        runner.max_depth = max_depth
        runner.mode = mode

        # Run exploration
        start_time = datetime.now()

        try:
            runner.run()

            end_time = datetime.now()
            duration_sec = (end_time - start_time).total_seconds()

            # Collect statistics
            summary = {
                "session_id": session_id,
                "mode": mode,
                "budget_sec": budget_sec,
                "max_depth": max_depth,
                "trace_timeout_sec": trace_timeout,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration_sec": duration_sec,
                "choices_seen": getattr(runner, "choices_seen", 0),
                "branches_enqueued": getattr(runner, "branches_enqueued", 0),
                "branches_executed": getattr(runner, "branches_executed", 0),
                "checkpoints_created": getattr(runner, "checkpoints_created", 0),
                "unresolved_count": len(getattr(runner, "unresolved_reasons", [])),
                "unresolved_reasons": getattr(runner, "unresolved_reasons", []),
                "session_mismatches": (
                    runner.event_router.get_session_mismatch_count()
                    if hasattr(runner, "event_router")
                    else 0
                ),
                "termination_reason": getattr(runner, "termination_reason", "unknown"),
                "success": True,
            }

            logs.info(
                "engine.trace_exploration.complete",
                f"Exploration complete: {summary['branches_executed']} branches executed",
            )

            return summary

        except Exception as e:
            end_time = datetime.now()
            duration_sec = (end_time - start_time).total_seconds()

            logs.error("engine.trace_exploration.failed", f"Exploration failed: {e}")

            return {
                "session_id": session_id,
                "mode": mode,
                "budget_sec": budget_sec,
                "max_depth": max_depth,
                "trace_timeout_sec": trace_timeout,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "duration_sec": duration_sec,
                "success": False,
                "error": str(e),
            }

        finally:
            # Ensure process termination (polite then force)
            if proc and proc.poll() is None:
                logs.info("engine.terminate_renpy", "Terminating Ren'Py process")
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                    logs.info(
                        "engine.terminate_renpy.clean", "Process terminated cleanly"
                    )
                except Exception:
                    logs.warning(
                        "engine.terminate_renpy.force",
                        "Process did not terminate, forcing kill",
                    )
                    proc.kill()
                    proc.wait()
