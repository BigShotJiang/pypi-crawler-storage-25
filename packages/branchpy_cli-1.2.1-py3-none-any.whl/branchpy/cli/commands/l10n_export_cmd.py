"""
BranchPy L10n Export CLI Command (BPY-L10n-RT Phase 1)

Exports all translation strings from a Ren'Py project to a single-sheet XLSX workbook.
The workbook can then be edited by translators and imported back with `bpy l10n import`.

Usage:
    bpy l10n export [OPTIONS]

Examples:
    # Export all locales to default path
    bpy l10n export

    # Export only missing strings for French
    bpy l10n export --locale fr --status missing

    # Specify output path
    bpy l10n export --output /tmp/translations.xlsx

Spec: docs/Current Version/Localization/L10N_ROUNDTRIP_V1_SPEC.md
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

from branchpy.contract import VERSION, Exit
from branchpy.emit import emit_event


def build_arg_parser(subparsers=None) -> argparse.ArgumentParser:
    """
    Build argument parser for `bpy l10n export`.

    If subparsers is provided (called by the l10n router), registers the
    subcommand there and returns it. Otherwise returns a standalone parser.
    """
    kwargs = dict(
        prog="bpy l10n export",
        description=(
            "Export translation strings to XLSX for external editing.\n\n"
            "Produces a workbook with one row per translation entry. "
            "Edit the 'translation' column and import the file back with "
            "'bpy l10n import'."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  bpy l10n export
  bpy l10n export --locale fr --status missing
  bpy l10n export --output translations.xlsx
        """,
    )
    if subparsers is not None:
        p = subparsers.add_parser("export", help="Export translations to XLSX", **kwargs)
    else:
        p = argparse.ArgumentParser(**kwargs)

    p.add_argument(
        "--project",
        default=".",
        help="Project root directory (default: current directory)",
    )

    p.add_argument(
        "--locale",
        default=None,
        metavar="TAG",
        help="Export only this BCP-47 locale (default: all locales)",
    )

    p.add_argument(
        "--status",
        choices=["missing", "translated", "orphaned", "all"],
        default="all",
        help="Filter rows by translation status (default: all)",
    )

    p.add_argument(
        "--output",
        "-o",
        default=None,
        metavar="FILE",
        help=(
            "Output .xlsx path "
            "(default: <project>/.branchpy/l10n/branchpy_l10n_export_<YYYYMMDD_HHMMSS>.xlsx)"
        ),
    )

    p.add_argument(
        "--json-summary",
        action="store_true",
        default=False,
        help="Print a JSON summary of the export to stdout after writing",
    )

    return p


def run_from_cli(args: argparse.Namespace) -> int:
    """
    Entry point for `bpy l10n export`.

    Returns an Exit code (0 = success, 10 = error).
    """
    # Late imports to keep startup fast
    from branchpy.l10n.round_trip import scan_project_for_rows
    from branchpy.l10n.xlsx_writer import export_to_xlsx, make_export_filename

    project_root = Path(args.project).resolve()

    if not project_root.exists():
        print(f"Error: project root not found: {project_root}", file=sys.stderr)
        return Exit.INTERNAL

    # Resolve output path
    if args.output:
        output_path = Path(args.output).resolve()
    else:
        ts = datetime.now()
        filename = make_export_filename(ts)
        output_path = project_root / ".branchpy" / "l10n" / filename

    # Scan project
    status_filter = None if args.status == "all" else args.status
    print(f"Scanning project: {project_root}", file=sys.stderr)

    try:
        rows = scan_project_for_rows(
            project_root=project_root,
            locale_filter=args.locale,
            status_filter=status_filter,
        )
    except Exception as exc:
        print(f"Error scanning project: {exc}", file=sys.stderr)
        return Exit.INTERNAL

    if not rows:
        print("No translation rows found. Check that the project has a tl/ directory.", file=sys.stderr)
        return Exit.ISSUES_FOUND

    # Gather per-locale counts for summary
    locale_counts: Dict[str, int] = {}
    for r in rows:
        locale_counts[r.locale] = locale_counts.get(r.locale, 0) + 1
    locale_count = len(locale_counts)

    print(
        f"Found {len(rows)} rows across {locale_count} locale(s): "
        + ", ".join(sorted(locale_counts.keys())),
        file=sys.stderr,
    )
    if locale_count > 1:
        print(
            "ℹ️  This workbook contains multiple locales. "
            "Filter the \u2018locale\u2019 column in Excel to work on one language at a time.",
            file=sys.stderr,
        )

    # Write XLSX
    try:
        export_to_xlsx(rows, output_path)
    except ImportError:
        # openpyxl missing — error already printed by xlsx_writer
        return Exit.INTERNAL
    except Exception as exc:
        print(f"Error writing XLSX: {exc}", file=sys.stderr)
        return Exit.INTERNAL

    print(f"\u2705 Export written to: {output_path}", file=sys.stderr)
    print(
        "\u2139\ufe0f  Notes are not saved between sessions \u2014 archive this file to keep them.",
        file=sys.stderr,
    )

    # Emit governance event
    try:
        emit_event(
            kind="l10n.export",
            payload={
                "module": "l10n",
                "event_type": "l10n.export",
                "locale_count": locale_count,
                "row_count": len(rows),
                "output_path": "<redacted>",
                "locale_filter": args.locale,
                "status_filter": args.status,
                "version": VERSION,
            },
            project=str(project_root),
        )
    except Exception:
        pass  # Governance failure must not abort a successful export

    if args.json_summary:
        summary: Dict[str, Any] = {
            "status": "ok",
            "output_path": str(output_path),
            "row_count": len(rows),
            "locale_count": locale_count,
            "locales": locale_counts,
        }
        print(json.dumps(summary, indent=2))

    return Exit.OK
