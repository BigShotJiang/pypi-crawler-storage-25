"""
BranchPy Semantics V2 CLI Commands — v0.9.4 Phase 2

Exposes Semantics V2 analysis engine via CLI:
- branchpy semantics2 analyze — Run semantic analysis
- branchpy semantics2 export-cfg — Export control flow graph
- branchpy semantics2 diff — Compare semantic snapshots

All commands support --json output for VS Code integration.

Governance Events:
- semantics.analyze.start
- semantics.analyze.complete
- semantics.export.start
- semantics.export.complete
- semantics.diff.start
- semantics.diff.complete
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict

# Import Semantics V2 modules
try:
    from branchpy.cfg import cfg_exporter  # type: ignore
    from branchpy.semantics.v2 import conditional_analyzer  # type: ignore
    from branchpy.semantics.v2 import effects_analyzer, parser, semantic_history

    _legacy_modules_available = True
except ImportError:
    # Graceful fallback if modules not yet fully integrated
    parser = effects_analyzer = conditional_analyzer = semantic_history = (
        cfg_exporter
    ) = None
    _legacy_modules_available = False

# Import new modules (M3 Phase 4+)
try:
    from branchpy.semantics.propagation.effects_analyzer import (  # type: ignore
        EffectAnalyzer,
    )
    from branchpy.semantics.propagation.effects_metrics import (  # type: ignore
        compute_effect_metrics,
    )

    _effects_modules_available = True
except ImportError:
    EffectAnalyzer = None
    compute_effect_metrics = None
    _effects_modules_available = False


def add_parser(subparsers: argparse._SubParsersAction) -> None:
    """Register semantics subcommand (aliased from existing command structure)."""
    # Note: This hooks into the existing semantics command structure
    # The actual sub-sub-commands will be added via register_semantics_parser
    pass


def register_semantics_parser(subparsers: argparse._SubParsersAction) -> None:
    """Register semantics2 subcommand and sub-subcommands."""
    parser_main = subparsers.add_parser(
        "semantics2", help="Semantics V2: Advanced semantic analysis and CFG export"
    )

    sem_subparsers = parser_main.add_subparsers(
        dest="semantics_command", required=False
    )

    # semantics-v2 analyze
    analyze_parser = sem_subparsers.add_parser(
        "analyze",
        help="Run semantic analysis on project",
        description="Run semantic analysis on Ren'Py project to detect variable flow, conditionals, and effects",
    )
    analyze_parser.add_argument(
        "--project", "-p", type=str, required=True, help="Project root directory"
    )
    analyze_parser.add_argument(
        "--json", action="store_true", help="Output JSON format"
    )
    analyze_parser.add_argument(
        "--save-history",
        action="store_true",
        default=True,
        help="Save analysis to semantic history",
    )
    analyze_parser.add_argument(
        "--full",
        action="store_true",
        # SOP §3.3 — When cmd_analyze produces real output, FULL payload is Class C.
        # Only SUMMARY output is Class B. Gate is ready; enforced when stub is replaced.
        help=argparse.SUPPRESS,
    )

    # semantics-v2 export-cfg — Class C, fully hidden from public help
    # Registered so argparse can parse its arguments if invoked; excluded from
    # the visible choices list so it does not appear in --help output.
    export_parser = sem_subparsers.add_parser(
        "export-cfg",
        # SOP §3.3 — Class C subcommand. Suppressed from public help.
        help=argparse.SUPPRESS,
        description=argparse.SUPPRESS,
    )
    # Remove from the displayed choices so `semantics2 --help` does not list it.
    # The parser remains registered in _name_parser_map and can still parse arguments.
    sem_subparsers._choices_actions = [  # type: ignore[attr-defined]
        a for a in sem_subparsers._choices_actions  # type: ignore[attr-defined]
        if a.dest != "export-cfg"
    ]
    export_parser.add_argument(
        "--project", "-p", type=str, required=True, help="Project root directory"
    )
    export_parser.add_argument(
        "--output",
        "-o",
        type=str,
        required=True,
        help="Output file path (.json or .dot)",
    )
    export_parser.add_argument(
        "--format",
        type=str,
        choices=["json", "dot", "graphviz"],
        default="json",
        help="Output format",
    )
    export_parser.add_argument(
        "--internal",
        action="store_true",
        # SOP §3.3 — Class C gate. Not in public help.
        help=argparse.SUPPRESS,
    )

    # semantics-v2 diff
    diff_parser = sem_subparsers.add_parser(
        "diff",
        help="Compare semantic snapshots",
        description="Compare semantic snapshots between two project states or commits",
    )
    diff_parser.add_argument(
        "--project", "-p", type=str, required=True, help="Project root directory"
    )
    diff_parser.add_argument(
        "--from", dest="from_rev", type=str, help="Source revision/snapshot ID"
    )
    diff_parser.add_argument(
        "--to", dest="to_rev", type=str, help="Target revision/snapshot ID"
    )
    diff_parser.add_argument("--json", action="store_true", help="Output JSON format")

    # semantics-v2 flow (M3 Phase 4)
    flow_parser = sem_subparsers.add_parser(
        "flow",
        help="Analyze control flow and compute flow metrics",
        description="Analyze control flow propagation and compute metrics (path count, complexity, etc.)",
    )
    flow_parser.add_argument(
        "--project", "-p", type=str, required=True, help="Project root directory"
    )
    flow_parser.add_argument("--label", type=str, help="Analyze specific label only")
    flow_parser.add_argument("--json", action="store_true", help="Output JSON format")
    flow_parser.add_argument(
        "--summary", action="store_true", help="Show summary only (human-readable)"
    )
    flow_parser.add_argument(
        "--timing",
        action="store_true",
        help="Enable timing telemetry for performance profiling",
    )

    # semantics-v2 warnings (M3 Phase 4)
    warnings_parser = sem_subparsers.add_parser(
        "warnings",
        help="Show flow-related semantic warnings",
        description="Show flow-related semantic warnings (unreachable code, undefined variables, etc.)",
    )
    warnings_parser.add_argument(
        "--project", "-p", type=str, required=True, help="Project root directory"
    )
    warnings_parser.add_argument(
        "--label", type=str, help="Show warnings for specific label only"
    )
    warnings_parser.add_argument(
        "--json", action="store_true", help="Output JSON format"
    )
    warnings_parser.add_argument(
        "--severity",
        type=str,
        choices=["info", "warning", "error", "all"],
        default="all",
        help="Filter by severity level",
    )
    warnings_parser.add_argument(
        "--timing",
        action="store_true",
        help="Enable timing telemetry for performance profiling",
    )

    # semantics-v2 effects (M3 Phase 4+)
    effects_parser = sem_subparsers.add_parser(
        "effects",
        help="Analyze semantic effects (variable assignments, media operations, etc.)",
        description="Analyze semantic effects: variable writes, media show/hide, audio play/stop, control flow",
    )
    effects_parser.add_argument(
        "--project", "-p", type=str, required=True, help="Project root directory"
    )
    effects_parser.add_argument(
        "--label", type=str, help="Show effects for specific label only"
    )
    effects_parser.add_argument(
        "--json", action="store_true", help="Output JSON format"
    )
    effects_parser.add_argument(
        "--summary", action="store_true", help="Show summary only (human-readable)"
    )
    effects_parser.add_argument(
        "--warnings", action="store_true", help="Show effect-related warnings"
    )

    # semantics-v2 lint (M3 Phase 5 Step 3)
    lint_parser = sem_subparsers.add_parser(
        "lint",
        help="Run regex-based linting rules on source code",
        description="Run regex-based linting rules: naming conventions, style checks, safety patterns",
    )
    lint_parser.add_argument(
        "--project", "-p", type=str, required=True, help="Project root directory"
    )
    lint_parser.add_argument(
        "--rules", type=str, help="Path to custom rules file (YAML or JSON)"
    )
    lint_parser.add_argument(
        "--severity",
        type=str,
        choices=["error", "warning", "info", "hint", "all"],
        default="all",
        help="Filter violations by severity",
    )
    lint_parser.add_argument(
        "--category",
        type=str,
        choices=[
            "naming",
            "style",
            "safety",
            "performance",
            "security",
            "maintainability",
            "custom",
            "all",
        ],
        default="all",
        help="Filter violations by category",
    )
    lint_parser.add_argument("--json", action="store_true", help="Output JSON format")
    lint_parser.add_argument(
        "--summary", action="store_true", help="Show summary only (human-readable)"
    )

    # semantics-v2 scan (M3 Phase 5 Step 10C)
    scan_parser = sem_subparsers.add_parser(
        "scan",
        help="Run semantic analysis with rule engines (regex/AI)",
        description="Scan Ren'Py scripts for semantic issues using regex and/or AI rule engines",
    )
    scan_parser.add_argument(
        "paths", nargs="+", help="One or more .rpy script files to scan"
    )
    scan_parser.add_argument(
        "--engine",
        type=str,
        choices=["regex", "ai", "both"],
        default="regex",
        help="Select rule engine: regex (pattern-based), ai (LLM-powered), or both",
    )
    scan_parser.add_argument(
        "--format",
        type=str,
        choices=["table", "json"],
        default="table",
        help="Output format: table (human-readable) or json (machine-readable)",
    )
    scan_parser.add_argument(
        "--output", "-o", type=str, help="Write results to file (default: stdout)"
    )
    scan_parser.add_argument(
        "--ruleset",
        type=str,
        help="Policy ID for BQF filtering (Step 10D - not yet implemented)",
    )


def cmd_semantics(args: argparse.Namespace) -> int:
    """Execute semantics command based on subcommand."""
    if not hasattr(args, "semantics_command") or args.semantics_command is None:
        print("ERROR: No semantics subcommand specified", file=sys.stderr)
        print(
            "Use: branchpy semantics2 {analyze|export-cfg|diff|flow|warnings|effects|lint|scan} --help",
            file=sys.stderr,
        )
        return 1

    # Note: analyze and export-cfg now have minimal implementations that don't require legacy modules
    # Other commands still check for their required modules

    # Check for effects modules
    if args.semantics_command == "effects":
        if not _effects_modules_available:
            print("ERROR: Effects analyzer modules not available", file=sys.stderr)
            return 1

    # Check for lint modules
    if args.semantics_command == "lint":
        try:
            from branchpy.semantics.propagation.regex_rule_engine import (  # type: ignore  # noqa: F401
                analyze_with_rules,
            )
        except ImportError:
            print("ERROR: Regex rule engine not available", file=sys.stderr)
            return 1

    # Check for scan modules (Step 10C)
    if args.semantics_command == "scan":
        try:
            from branchpy.semantics.propagation.cfg_builder import (  # type: ignore  # noqa: F401
                CFGBuilder,
            )
            from branchpy.semantics.propagation.cfg_regex_engine import (  # type: ignore  # noqa: F401
                run_cfg_regex_engine,
            )
        except ImportError as e:
            print(f"ERROR: CFG semantic engines not available: {e}", file=sys.stderr)
            return 1

    try:
        if args.semantics_command == "analyze":
            return cmd_analyze(args)
        elif args.semantics_command == "export-cfg":
            return cmd_export_cfg(args)
        elif args.semantics_command == "diff":
            if not _legacy_modules_available:
                print("ERROR: Semantic diff modules not available", file=sys.stderr)
                return 1
            return cmd_diff(args)
        elif args.semantics_command == "flow":
            return cmd_flow(args)
        elif args.semantics_command == "warnings":
            return cmd_warnings(args)
        elif args.semantics_command == "effects":
            return cmd_effects(args)
        elif args.semantics_command == "lint":
            return cmd_lint(args)
        elif args.semantics_command == "scan":
            return cmd_scan(args)
        else:
            print(
                f"ERROR: Unknown semantics command: {args.semantics_command}",
                file=sys.stderr,
            )
            return 1
    except Exception as e:
        if getattr(args, "json", False):
            print(json.dumps({"success": False, "error": str(e)}))
        else:
            print(f"ERROR: {e}", file=sys.stderr)
        return 1


def cmd_analyze(args: argparse.Namespace) -> int:
    """Run semantic analysis on project."""
    from branchpy import logs

    project_path = Path(args.project)
    if not project_path.exists():
        print(f"ERROR: Project not found: {project_path}", file=sys.stderr)
        return 1

    logs.info(
        "semantics.analyze.start",
        f"Starting semantic analysis: {project_path}",
        project=str(project_path),
    )

    # For now, create a simple analysis result
    # TODO: Integrate with actual parser and semantic analysis modules
    # NOTE (SOP §3.3): When this stub is replaced with a real implementation, the
    # output must respect the three-class model:
    #   - Default output (no --full) → Class B: summary counts only → stdout/JSON
    #   - --full provided             → Class C: full payload → .internal/ only
    #   Enforce with: if getattr(args, "full", False): ... else: thin_output(...)
    result = {
        "success": True,
        "project": str(project_path),
        "message": "Semantic analysis stub - full implementation coming soon",
        "summary": {"labels": 0, "effects": 0, "conditionals": 0},
    }

    logs.info(
        "semantics.analyze.complete",
        f"Semantic analysis complete: {project_path}",
        project=str(project_path),
    )

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(f"Analysis complete for: {project_path}", file=sys.stderr)
        print(
            "Note: Full semantic analysis integration is in progress.", file=sys.stderr
        )

    return 0


def cmd_export_cfg(args: argparse.Namespace) -> int:
    """Export control flow graph using full SAE analysis - same as analyze command."""
    # SOP §3.3 — Full CFG export is a Class C engine artifact.
    # Requires --internal to prevent accidental exposure in product context.
    if not getattr(args, "internal", False):
        print(
            "[bpy] ERROR: `semantics2 export-cfg` produces a Class C engine artifact (full CFG graph).\n"
            "  Add --internal to confirm this is an internal / development use.",
            file=sys.stderr,
        )
        return 1

    from branchpy import logs

    project_path = Path(args.project)
    output_path = Path(args.output)

    if not project_path.exists():
        print(f"ERROR: Project not found: {project_path}", file=sys.stderr)
        return 1

    logs.info(
        "semantics.export.start",
        f"Exporting CFG: {project_path} -> {output_path}",
        project=str(project_path),
        output=str(output_path),
        format=args.format,
    )

    try:
        # Use the exact same approach as analyze command
        from branchpy.analysis.catalog import BuiltinSemanticsCatalog, SemanticsCatalog
        from branchpy.analysis.sae.cfg_builder import StatementCFGBuilder
        from branchpy.analysis.sae.indexer import Indexer

        print("[CFG] Indexing project...", file=sys.stderr)
        indexer = Indexer(str(project_path))
        index = indexer.build_index()

        print("[CFG] Building semantics catalog...", file=sys.stderr)
        catalog = SemanticsCatalog()
        builtin_catalog = BuiltinSemanticsCatalog()
        for func_list in builtin_catalog.functions.values():
            for func in func_list:
                catalog.add(func)

        print("[CFG] Building control flow graph with SAE...", file=sys.stderr)
        builder = StatementCFGBuilder(
            index, project_root=str(project_path), semantics_catalog=catalog
        )
        cfg = builder.build()

        print(
            f"[CFG] Graph built: {len(cfg.nodes)} nodes, {len(cfg.edges)} edges",
            file=sys.stderr,
        )

        # Use CFG's built-in to_dict() method
        cfg_dict = cfg.to_dict() if hasattr(cfg, "to_dict") else {}

        # Convert to the format expected by VS Code extension
        nodes = []
        edges = []

        # Extract nodes
        if "nodes" in cfg_dict:
            for node_data in cfg_dict["nodes"]:
                nodes.append(
                    {
                        "id": node_data.get("id", "unknown"),
                        "type": node_data.get("type", "statement"),
                        "label": node_data.get("label"),
                        "file": node_data.get("file", "unknown"),
                        "line": node_data.get("line", 0),
                        "code_preview": node_data.get("code", node_data.get("id", ""))[
                            :80
                        ],
                        "semantic_rule_hits": node_data.get("semantic_rule_hits", []),
                    }
                )

        # Extract edges
        if "edges" in cfg_dict:
            for edge_data in cfg_dict["edges"]:
                edges.append(
                    {
                        "from": edge_data.get("from") or edge_data.get("source"),
                        "to": edge_data.get("to") or edge_data.get("target"),
                        "condition": edge_data.get("condition")
                        or edge_data.get("cond"),
                    }
                )

        # Build final CFG structure
        cfg_data = {
            "version": "1.0.0",
            "cfg_type": "project",
            "nodes": nodes,
            "edges": edges,
            "metadata": {
                "project": str(project_path),
                "generation_time": "2025-11-23T00:00:00Z",
                "parser": "StatementCFGBuilder",
                "analyzer": "SAE",
                "labels": len(index.labels),
                "files": len(index.files),
            },
        }

    except ImportError as e:
        logs.warning(
            "cfg.sae.unavailable",
            f"SAE not available, falling back to regex parser: {e}",
        )
        print(f"[CFG] ImportError: {e}", file=sys.stderr)
        import traceback

        traceback.print_exc(file=sys.stderr)
        return _export_cfg_regex(project_path, output_path, args.format)
    except Exception as e:
        logs.error("cfg.export.error", f"CFG export failed: {e}", exc_info=True)
        print(f"ERROR during SAE CFG build: {e}", file=sys.stderr)
        import traceback

        traceback.print_exc(file=sys.stderr)
        print("[CFG] Falling back to regex parser...", file=sys.stderr)
        return _export_cfg_regex(project_path, output_path, args.format)

    # Export based on format
    if args.format == "json":
        exported = json.dumps(cfg_data, indent=2)
    elif args.format in ("dot", "graphviz"):
        dot_lines = ["digraph CFG {", "  rankdir=TB;", "  node [shape=box];"]
        for node in nodes:
            node_id = node["id"]
            label = node.get("code_preview", node_id)
            dot_lines.append(f'  "{node_id}" [label="{label}"];')
        for edge in edges:
            src, tgt = edge["from"], edge["to"]
            condition = edge.get("condition")
            if condition:
                dot_lines.append(f'  "{src}" -> "{tgt}" [label="{condition}"];')
            else:
                dot_lines.append(f'  "{src}" -> "{tgt}";')
        dot_lines.append("}")
        exported = "\n".join(dot_lines)
    else:
        print(f"ERROR: Unknown format: {args.format}", file=sys.stderr)
        return 1

    # Write output
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(exported, encoding="utf-8")

    logs.info(
        "semantics.export.complete",
        f"CFG export complete: {output_path}",
        output=str(output_path),
        size=len(exported),
        nodes=len(nodes),
        edges=len(edges),
    )

    print(f"CFG exported to: {output_path}", file=sys.stderr)
    print(f"Format: {args.format}", file=sys.stderr)
    print(f"Nodes: {len(nodes)}", file=sys.stderr)
    print(f"Edges: {len(edges)}", file=sys.stderr)
    print("Parser: StatementCFGBuilder + SAE", file=sys.stderr)

    return 0


def _export_cfg_regex(project_path: Path, output_path: Path, export_format: str) -> int:
    """Fallback: Export CFG using regex parsing (original implementation)."""
    import re

    # Find all .rpy files in game/ directory
    game_dir = project_path / "game"
    if not game_dir.exists():
        game_dir = project_path

    rpy_files = list(game_dir.glob("*.rpy"))
    if not rpy_files:
        print(f"ERROR: No .rpy files found in {game_dir}", file=sys.stderr)
        return 1

    # Parse labels, menus, and jumps from source files
    nodes = []
    edges = []
    node_id_counter = 0
    label_map = {}

    # Regex patterns
    label_pattern = re.compile(r"^\s*label\s+(\w+)\s*:")
    menu_pattern = re.compile(r"^\s*menu\s*:")
    jump_pattern = re.compile(r"^\s*jump\s+(\w+)")
    call_pattern = re.compile(r"^\s*call\s+(\w+)")
    return_pattern = re.compile(r"^\s*return\b")
    choice_pattern = re.compile(r'^\s*"([^"]+)":\s*$')

    current_label = None
    current_label_node_id = None
    prev_node_id = None

    for rpy_file in rpy_files[:5]:
        try:
            lines = rpy_file.read_text(encoding="utf-8").splitlines()
        except Exception:
            continue

        for line_num, line in enumerate(lines[:200], 1):
            # Label definition
            label_match = label_pattern.match(line)
            if label_match:
                label_name = label_match.group(1)
                node_id = f"label_{label_name}"
                node_id_counter += 1

                nodes.append(
                    {
                        "id": node_id,
                        "type": "statement",
                        "label": label_name,
                        "file": str(rpy_file.relative_to(project_path)),
                        "line": line_num,
                        "code_preview": line.strip()[:60],
                        "semantic_rule_hits": [],
                    }
                )

                label_map[label_name] = node_id
                if prev_node_id and current_label_node_id:
                    edges.append(
                        {"from": prev_node_id, "to": node_id, "condition": None}
                    )

                current_label = label_name
                current_label_node_id = node_id
                prev_node_id = node_id
                continue

            # Menu, choices, jumps, calls, returns
            if menu_pattern.match(line) and current_label:
                node_id = f"menu_{node_id_counter}"
                node_id_counter += 1
                nodes.append(
                    {
                        "id": node_id,
                        "type": "menu",
                        "label": current_label,
                        "file": str(rpy_file.relative_to(project_path)),
                        "line": line_num,
                        "code_preview": "menu:",
                        "semantic_rule_hits": [],
                    }
                )
                if prev_node_id:
                    edges.append(
                        {"from": prev_node_id, "to": node_id, "condition": None}
                    )
                prev_node_id = node_id

    # Build CFG data
    cfg_data = {
        "version": "1.0.0",
        "cfg_type": "file",
        "nodes": (
            nodes
            if nodes
            else [
                {
                    "id": "start",
                    "type": "statement",
                    "label": "start",
                    "file": "script.rpy",
                    "line": 1,
                    "code_preview": "label start:",
                    "semantic_rule_hits": [],
                }
            ]
        ),
        "edges": edges,
        "metadata": {
            "project": str(project_path),
            "generation_time": "2025-11-23T00:00:00Z",
            "parser": "regex",
            "files_parsed": len(rpy_files[:5]),
        },
    }

    # Export
    if export_format == "json":
        exported = json.dumps(cfg_data, indent=2)
    else:
        dot_lines = ["digraph CFG {", "  rankdir=TB;", "  node [shape=box];"]
        for node in cfg_data["nodes"]:
            dot_lines.append(
                f'  "{node["id"]}" [label="{node.get("code_preview", node["id"])}"];'
            )
        for edge in cfg_data["edges"]:
            dot_lines.append(f'  "{edge["from"]}" -> "{edge["to"]}";')
        dot_lines.append("}")
        exported = "\n".join(dot_lines)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(exported, encoding="utf-8")

    print(f"CFG exported to: {output_path}", file=sys.stderr)
    print("Parser: regex (fallback)", file=sys.stderr)

    return 0


# Dead code removed - was unreachable after return statement
# Original block used undefined 'args' variable - removed entire code block
# TODO: Fix or remove this function if needed


def cmd_diff(args: argparse.Namespace) -> int:
    """Compare semantic snapshots."""
    from branchpy import logs

    project_path = Path(args.project)

    if not project_path.exists():
        print(f"ERROR: Project not found: {project_path}", file=sys.stderr)
        return 1

    logs.info(
        "semantics.diff.start",
        f"Computing semantic diff: {args.from_rev} -> {args.to_rev}",
        project=str(project_path),
        from_rev=args.from_rev,
        to_rev=args.to_rev,
    )

    # Get snapshots
    from_snapshot = semantic_history.load_snapshot(str(project_path), args.from_rev)  # type: ignore
    to_snapshot = semantic_history.load_snapshot(str(project_path), args.to_rev)  # type: ignore

    if not from_snapshot or not to_snapshot:
        print("ERROR: One or both snapshots not found", file=sys.stderr)
        return 1

    # Compute diff
    diff_result = semantic_history.compute_diff(from_snapshot, to_snapshot)  # type: ignore

    logs.info(
        "semantics.diff.complete",
        "Semantic diff complete",
        changes=diff_result.get("total_changes", 0),
    )

    if args.json:
        print(json.dumps(diff_result, indent=2))
    else:
        _print_diff_summary(diff_result)

    return 0


def _print_analysis_summary(result: Dict[str, Any]) -> None:
    """Pretty-print analysis summary to console."""
    print(f"\n{'=' * 60}")
    print("Semantic Analysis Results")
    print(f"{'=' * 60}\n")

    summary = result.get("summary", {})
    print(f"Labels:       {summary.get('labels', 0)}")
    print(f"Effects:      {summary.get('effects', 0)}")
    print(f"Conditionals: {summary.get('conditionals', 0)}")
    print()


def _print_diff_summary(diff_result: Dict[str, Any]) -> None:
    """Pretty-print diff summary to console."""
    print(f"\n{'=' * 60}")
    print("Semantic Diff Results")
    print(f"{'=' * 60}\n")

    print(f"Total changes: {diff_result.get('total_changes', 0)}")
    print(f"Added:         {diff_result.get('added', 0)}")
    print(f"Removed:       {diff_result.get('removed', 0)}")
    print(f"Modified:      {diff_result.get('modified', 0)}")
    print()


# ============================================================================
# M3 Phase 4: Flow Analysis Commands
# ============================================================================


def cmd_flow(args: argparse.Namespace) -> int:
    """Analyze control flow and compute flow metrics."""
    from branchpy import logs
    from branchpy.analyzer.script_graph import build_script_graph

    project_path = Path(args.project)
    if not project_path.exists():
        print(f"ERROR: Project not found: {project_path}", file=sys.stderr)
        return 1

    logs.info(
        "semantics.flow.start",
        f"Starting flow analysis: {project_path}",
        project=str(project_path),
    )

    try:
        # Build ScriptGraph from project
        graph = build_script_graph(project_path)

        # Run flow analysis using ScriptGraph.analyze_flow()
        bundle = graph.analyze_flow(use_cache=True, enable_timing=args.timing)

        if not bundle.success:
            print(f"ERROR: {bundle.error_message}", file=sys.stderr)
            return 1

        # Filter by label if requested
        if args.label:
            if args.label not in bundle.label_metrics:
                print(f"ERROR: Label '{args.label}' not found", file=sys.stderr)
                return 1

        logs.info(
            "semantics.flow.complete",
            "Flow analysis complete",
            labels=len(bundle.label_metrics),
            warnings=len(bundle.warnings),
        )

        # Output
        if args.json:
            _output_flow_json(bundle, args.label)
        elif args.summary:
            _output_flow_summary(bundle, args.label)
        else:
            _output_flow_detailed(bundle, args.label)

        return 0

    except Exception as e:
        logs.error("semantics.flow.error", f"Flow analysis failed: {e}", exc_info=True)
        print(f"ERROR: Flow analysis failed: {e}", file=sys.stderr)
        import traceback

        traceback.print_exc(file=sys.stderr)
        return 1


def cmd_warnings(args: argparse.Namespace) -> int:
    """Show flow-related semantic warnings."""
    from branchpy import logs
    from branchpy.analyzer.script_graph import build_script_graph

    project_path = Path(args.project)
    if not project_path.exists():
        print(f"ERROR: Project not found: {project_path}", file=sys.stderr)
        return 1

    logs.info(
        "semantics.warnings.start",
        f"Checking flow warnings: {project_path}",
        project=str(project_path),
    )

    try:
        # Build ScriptGraph from project
        graph = build_script_graph(project_path)

        # Run flow analysis
        bundle = graph.analyze_flow(use_cache=True, enable_timing=args.timing)

        if not bundle.success:
            print(f"ERROR: {bundle.error_message}", file=sys.stderr)
            return 1

        # Filter warnings
        warnings = bundle.warnings
        if args.label:
            warnings = bundle.get_label_warnings(args.label)

        if args.severity != "all":
            severity_map = {"info": "LOW", "warning": "MEDIUM", "error": "HIGH"}
            target_severity = severity_map.get(
                args.severity.lower(), args.severity.upper()
            )
            warnings = [w for w in warnings if w.severity == target_severity]

        logs.info(
            "semantics.warnings.complete",
            "Flow warnings analysis complete",
            warnings=len(warnings),
        )

        # Output
        if args.json:
            _output_warnings_json(warnings, bundle)
        else:
            _output_warnings_detailed(warnings)

        return 0

    except Exception as e:
        logs.error(
            "semantics.warnings.error", f"Warnings analysis failed: {e}", exc_info=True
        )
        print(f"ERROR: Warnings analysis failed: {e}", file=sys.stderr)
        import traceback

        traceback.print_exc(file=sys.stderr)
        return 1


def _output_flow_json(bundle, label_filter=None):
    """Output flow analysis as JSON."""
    data = bundle.to_dict()

    # Filter by label if requested
    if label_filter and label_filter in data["labels"]:
        data = {
            "version": data["version"],
            "label": label_filter,
            "metrics": data["labels"][label_filter],
        }

    print(json.dumps(data, indent=2))


def _output_flow_summary(bundle, label_filter=None):
    """Output flow analysis summary (human-readable)."""
    metrics = bundle.global_metrics

    print(f"\n{'=' * 60}")
    print("Flow Analysis Summary")
    print(f"{'=' * 60}\n")
    print(f"Path Count: {metrics.path_count}")
    print(f"Cyclomatic Complexity: {metrics.cyclomatic_complexity}")
    print(f"Max Nesting Depth: {metrics.max_nesting_depth}")
    print(f"Avg Branching Factor: {metrics.avg_branching_factor:.2f}")
    print(f"Total Branches: {metrics.total_branches}")
    print(f"\nLabels: {len(bundle.label_metrics)}")
    print(f"Unreachable Labels: {len(bundle.get_unreachable_labels())}")
    print(f"Variables: {len(bundle.variable_lifetimes)}")
    print(f"Warnings: {len(bundle.warnings)}")
    print()


def _output_flow_detailed(bundle, label_filter=None):
    """Output detailed flow analysis (human-readable)."""
    _output_flow_summary(bundle, label_filter)

    print("=== Per-Label Metrics ===\n")

    labels_to_show = bundle.label_metrics
    if label_filter:
        if label_filter in labels_to_show:
            labels_to_show = {label_filter: labels_to_show[label_filter]}
        else:
            labels_to_show = {}

    for label_name, label_metric in labels_to_show.items():
        status = "UNREACHABLE" if label_metric.is_unreachable else "reachable"
        print(f"Label '{label_name}' ({status}):")
        print(
            f"  Incoming: {label_metric.incoming_jumps} jumps, {label_metric.incoming_calls} calls"
        )
        print(
            f"  Outgoing: {label_metric.outgoing_jumps} jumps, {label_metric.outgoing_calls} calls"
        )
        print(f"  Local Complexity: {label_metric.local_complexity}")
        print()


def _output_warnings_json(warnings, bundle):
    """Output warnings as JSON."""
    data = {
        "version": "0.9.6-M3",
        "warnings": [
            {
                "id": f"FW-{i+1:04d}",
                "code": w.code,
                "severity": w.severity.lower(),
                "message": w.message,
                "category": w.category,
                "line": w.line,
                "context": w.context,
            }
            for i, w in enumerate(warnings)
        ],
    }
    print(json.dumps(data, indent=2))


def _output_warnings_detailed(warnings):
    """Output warnings in human-readable format."""
    if not warnings:
        print("No warnings found.")
        return

    print(f"\n{'=' * 60}")
    print(f"Flow Warnings ({len(warnings)})")
    print(f"{'=' * 60}\n")

    for i, warning in enumerate(warnings, 1):
        severity_symbol = {
            "LOW": "ℹ️",
            "MEDIUM": "⚠️",
            "HIGH": "❌",
        }.get(warning.severity, "•")

        print(f"[{i}] {severity_symbol} {warning.severity}")
        print(f"Code: {warning.code}")
        print(f"Category: {warning.category}")
        print(f"Message: {warning.message}")
        if warning.line:
            print(f"Line: {warning.line}")
        if warning.context:
            print(f"Context: {warning.context}")
        print()


# ============================================================================
# Effects Analysis Command (M3 Phase 4+)
# ============================================================================


def cmd_effects(args: argparse.Namespace) -> int:
    """Analyze semantic effects (variable assignments, media operations, etc.)."""
    from branchpy import logs
    from branchpy.semantics.ast.nodes import ImageNode, LabelNode, PythonNode
    from branchpy.semantics.propagation.effects_analyzer import analyze_effects
    from branchpy.semantics.propagation.effects_metrics import analyze_effect_metrics

    project_path = Path(args.project)
    if not project_path.exists():
        print(f"ERROR: Project not found: {project_path}", file=sys.stderr)
        return 1

    logs.info(
        "semantics.effects.start",
        f"Starting effects analysis: {project_path}",
        project=str(project_path),
    )

    # For now, create test nodes (TODO: integrate with parser/ScriptGraph)
    nodes = []

    label1 = LabelNode(name="start", line_number=1)
    py1 = PythonNode(code="$ score = 100", line_number=2, is_single_line=True)
    py2 = PythonNode(code="$ hp = 80", line_number=3, is_single_line=True)
    img1 = ImageNode(action="scene", image_name="bg_cafe", line_number=4)
    img2 = ImageNode(action="show", image_name="alice_happy", line_number=5)
    label1.add_child(py1)
    label1.add_child(py2)
    label1.add_child(img1)
    label1.add_child(img2)
    nodes.append(label1)

    # Analyze effects
    context = analyze_effects(nodes)
    metrics, warnings = analyze_effect_metrics(context)

    logs.info(
        "semantics.effects.complete",
        "Effects analysis complete",
        effects=len(context.effects),
        warnings=len(warnings),
    )

    # Filter by label if requested
    if args.label:
        if args.label not in context.effects_by_label:
            print(f"ERROR: Label '{args.label}' not found", file=sys.stderr)
            return 1

        # Filter context to specific label
        filtered_effects = context.effects_by_label[args.label]
    else:
        filtered_effects = context.effects

    # Output
    if args.json:
        _output_effects_json(context, metrics, warnings, args.label)
    elif args.summary:
        _output_effects_summary(metrics, warnings)
    elif args.warnings:
        _output_effect_warnings(warnings)
    else:
        _output_effects_detailed(context, metrics, warnings, args.label)

    return 0


def _output_effects_json(context, metrics, warnings, label_filter=None):
    """Output effects as JSON."""
    data = {
        "version": "0.9.6-M3",
        "context": context.to_dict(),
        "metrics": metrics.to_dict(),
        "warnings": [w.to_dict() for w in warnings],
    }

    if label_filter:
        data["label_filter"] = label_filter

    print(json.dumps(data, indent=2))


def _output_effects_summary(metrics, warnings):
    """Output effects summary (human-readable)."""
    print(f"\n{'=' * 60}")
    print("Effects Analysis Summary")
    print(f"{'=' * 60}\n")

    print(f"Total Effects: {metrics.total_effects}")
    print()

    # Variable effects
    if metrics.variables_written:
        print(f"Variables Written ({len(metrics.variables_written)}):")
        for var in sorted(metrics.variables_written):
            count = metrics.write_count_per_var.get(var, 0)
            print(f"  {var}: {count} writes")
        print()

    if metrics.variables_incremented:
        print(
            f"Variables Incremented: {', '.join(sorted(metrics.variables_incremented))}"
        )

    if metrics.variables_decremented:
        print(
            f"Variables Decremented: {', '.join(sorted(metrics.variables_decremented))}"
        )

    if metrics.variables_toggled:
        print(f"Variables Toggled: {', '.join(sorted(metrics.variables_toggled))}")

    print()

    # Media effects
    if metrics.media_shown:
        print(f"Media Shown: {', '.join(sorted(metrics.media_shown))}")

    if metrics.media_hidden:
        print(f"Media Hidden: {', '.join(sorted(metrics.media_hidden))}")

    if metrics.media_played:
        print(f"Audio Played: {', '.join(sorted(metrics.media_played))}")

    print()

    # Control flow
    if metrics.jump_targets:
        print(f"Jump Targets: {', '.join(sorted(metrics.jump_targets))}")

    if metrics.call_targets:
        print(f"Call Targets: {', '.join(sorted(metrics.call_targets))}")

    if metrics.return_count > 0:
        print(f"Returns: {metrics.return_count}")

    print()
    print(f"Warnings: {len(warnings)}")
    print()


def _output_effect_warnings(warnings):
    """Output effect warnings only."""
    if not warnings:
        print("No effect warnings found.")
        return

    print(f"\n{'=' * 60}")
    print(f"Effect Warnings ({len(warnings)})")
    print(f"{'=' * 60}\n")

    for i, warning in enumerate(warnings, 1):
        severity_symbol = {
            "error": "❌",
            "warning": "⚠️",
            "info": "ℹ️",
        }.get(warning.severity, "•")

        print(f"[{i}] {severity_symbol} {warning.severity.upper()}")
        print(f"Type: {warning.warning_type}")
        print(f"Message: {warning.message}")
        if warning.line:
            print(f"Line: {warning.line}")
        if warning.label:
            print(f"Label: {warning.label}")
        if warning.target:
            print(f"Target: {warning.target}")
        print()


def _output_effects_detailed(context, metrics, warnings, label_filter=None):
    """Output detailed effects analysis."""
    _output_effects_summary(metrics, warnings)

    print("=== Effects by Label ===\n")

    labels_to_show = context.effects_by_label
    if label_filter and label_filter in labels_to_show:
        labels_to_show = {label_filter: labels_to_show[label_filter]}

    for label_name, effects in labels_to_show.items():
        print(f"Label '{label_name}' ({len(effects)} effects):")

        for effect in effects:
            print(f"  Line {effect.line}: {effect.effect_type.value}", end="")
            if effect.target:
                print(f" → {effect.target}", end="")
            if effect.value:
                print(f" = {effect.value}", end="")
            print()

        print()

    if warnings:
        print()
        _output_effect_warnings(warnings)


# ============================================================================
# Scan Command (M3 Phase 5 Step 10C)
# ============================================================================


def cmd_scan(args: argparse.Namespace) -> int:
    """
    Run semantic analysis with rule engines (regex/AI).

    This is the unified front door for Semantics V2 rule-based analysis:
    - Builds CFG from source scripts
    - Runs selected engines (regex, AI, or both)
    - Outputs warnings in table or JSON format
    - Exit code: 1 if any error-level warnings, 0 otherwise
    """
    from branchpy import logs
    from branchpy.bqf.semantic_policy import apply_policies_to_warnings  # Step 10D
    from branchpy.semantics.propagation.cfg_builder import CFGBuilder
    from branchpy.semantics.propagation.cfg_regex_engine import (
        create_builtin_cfg_regex_rules,
        run_cfg_regex_engine,
    )
    from branchpy.semantics.propagation.rule_registry import (
        get_global_registry,
        register_builtin_rules,
    )

    # Optional AI engine import (only if --engine ai|both)
    run_cfg_ai_engine = None
    ai_client = None
    if args.engine in ("ai", "both"):
        try:
            from branchpy.ai_client import get_ai_client  # type: ignore
            from branchpy.semantics.propagation.cfg_ai_engine import (  # type: ignore
                run_cfg_ai_engine,
            )

            ai_client = get_ai_client()
        except ImportError:
            print(
                "ERROR: AI engine not available. Use --engine regex instead.",
                file=sys.stderr,
            )
            return 1

    # Validate paths
    paths = [Path(p) for p in args.paths]
    for path in paths:
        if not path.exists():
            print(f"ERROR: Path not found: {path}", file=sys.stderr)
            return 1

    logs.info(
        "semantics.scan.start",
        f"Starting semantic scan: {len(paths)} files",
        paths=[str(p) for p in paths],
        engine=args.engine,
        format=args.format,
    )

    # Load rule registry
    register_builtin_rules()
    registry = get_global_registry()

    # Get builtin CFG regex rules
    cfg_regex_rules = create_builtin_cfg_regex_rules()
    if not cfg_regex_rules:
        print("ERROR: No CFG regex rules available", file=sys.stderr)
        return 1

    # Process each path
    all_warnings = []
    builder = CFGBuilder()

    for path in paths:
        try:
            # For Step 10C, we build a simple CFG from the source file
            # TODO: Full AST integration in future step
            source_text = path.read_text(encoding="utf-8")

            # Simple heuristic: split by label definitions
            # This is a simplified approach until full parser integration
            lines = source_text.splitlines()
            statements = [
                line.strip()
                for line in lines
                if line.strip() and not line.strip().startswith("#")
            ]

            if not statements:
                logs.warning(
                    "semantics.scan.empty", f"No statements in {path}", path=str(path)
                )
                continue

            # Build a linear CFG for this file
            cfg = builder.build_linear_cfg(
                label=f"scan_{path.stem}",
                statements=statements[:50],  # Limit to first 50 statements for demo
                file=str(path),
            )

            # Run regex engine
            if args.engine in ("regex", "both"):
                regex_warnings = run_cfg_regex_engine(cfg, cfg_regex_rules, registry)
                _attach_source_info(regex_warnings, str(path), "regex", cfg)
                all_warnings.extend(regex_warnings)

            # Run AI engine
            if args.engine in ("ai", "both") and run_cfg_ai_engine and ai_client:
                # AI engine expects a TypedDict, but also accepts regular dict in practice
                ai_config = {
                    "model": "default-semantic-model",
                    "max_output_tokens": 512,
                    "temperature": 0.0,
                    "top_p": 1.0,
                    "ruleset_id": args.ruleset,  # For future BQF integration
                }

                ai_warnings = run_cfg_ai_engine(cfg, ai_client, registry, ai_config)  # type: ignore
                _attach_source_info(ai_warnings, str(path), "ai", cfg)
                all_warnings.extend(ai_warnings)

        except Exception as e:
            logs.error(
                "semantics.scan.error",
                f"Error processing {path}: {e}",
                path=str(path),
                error=str(e),
            )
            print(f"WARNING: Failed to process {path}: {e}", file=sys.stderr)
            continue

    # Step 10D: Apply BQF policy filtering
    final_warnings = apply_policies_to_warnings(all_warnings, args.ruleset, registry)

    # Format output (using final_warnings after policy filtering)
    if args.format == "json":
        output_text = _warnings_to_json(final_warnings)
    else:  # table
        output_text = _warnings_to_table(final_warnings)

    # Write output
    if args.output:
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(output_text, encoding="utf-8")
        print(f"Results written to: {output_path}")
    else:
        print(output_text)

    # Compute exit code (using final_warnings after BQF policy filtering)
    error_count = sum(1 for w in final_warnings if w.severity.upper() == "ERROR")

    logs.info(
        "semantics.scan.complete",
        f"Scan complete: {len(final_warnings)} warnings",
        total_warnings=len(final_warnings),
        errors=error_count,
    )

    return 1 if error_count > 0 else 0


def _attach_source_info(warnings, path, engine_name, cfg):
    """
    Attach source metadata to warnings.

    Args:
        warnings: List of SemanticWarning objects
        path: File path as string
        engine_name: 'regex' or 'ai'
        cfg: ControlFlowGraph instance
    """
    for w in warnings:
        # Add engine name (for multi-engine scans)
        w.engine = engine_name

        # Set file path if not already set
        if not hasattr(w, "file") or not w.file:
            w.file = path

        # Optionally add label context
        if hasattr(cfg, "label") and cfg.label:
            w.label = cfg.label


def _warnings_to_json(warnings):
    """
    Convert warnings to JSON format.

    Schema:
    {
        "version": "0.9.6-M3",
        "results": [
            {
                "rule_id": "SEM_FLOW_001",
                "engine": "regex",
                "severity": "warning",
                "message": "...",
                "file": "script.rpy",
                "line": 42,
                "column": 10,
                "label": "start",
                "node_id": "n1",
                "policy": "strict",
                "severity_original": "info"
            },
            ...
        ]
    }
    """
    results = []

    for w in warnings:
        result = {
            "rule_id": w.rule_id,
            "engine": getattr(w, "engine", "unknown"),
            "severity": (
                w.severity.lower()
                if isinstance(w.severity, str)
                else w.severity.name.lower()
            ),
            "message": w.message,
            "file": getattr(w, "file", None),
            "line": w.line,
            "column": w.column,
            "label": getattr(w, "label", None),
            "node_id": w.node_id,
        }

        # Step 10D: Include BQF policy metadata
        if hasattr(w, "policy") and w.policy:
            result["policy"] = w.policy
        if hasattr(w, "severity_original") and w.severity_original:
            result["severity_original"] = w.severity_original

        results.append(result)

    payload = {"version": "0.9.6-M3", "results": results}

    return json.dumps(payload, indent=2, ensure_ascii=False)


def _warnings_to_table(warnings):
    """
    Convert warnings to human-readable table format.

    Format:
    SEVERITY | ENGINE | RULE              | LOCATION      | MESSAGE
    ---------|--------|-------------------|---------------|------------------
    warning  | regex  | SEM_FLOW_001      | script.rpy:42 | Unreachable code
    error    | ai     | SEM_EXPR_003      | main.rpy:15   | Undefined variable
    ...
    """
    if not warnings:
        return "No semantic issues found."

    # Build table rows
    rows = []
    for w in warnings:
        severity = (
            w.severity.lower()
            if isinstance(w.severity, str)
            else w.severity.name.lower()
        )
        engine = getattr(w, "engine", "unknown")
        rule_id = w.rule_id
        location = f"{getattr(w, 'file', 'unknown')}:{w.line}" if w.line else "unknown"
        message = w.message[:60] + "..." if len(w.message) > 60 else w.message

        rows.append([severity, engine, rule_id, location, message])

    # Calculate column widths
    headers = ["SEVERITY", "ENGINE", "RULE", "LOCATION", "MESSAGE"]
    col_widths = [len(h) for h in headers]

    for row in rows:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(str(cell)))

    # Format table
    lines = []

    # Header
    header_line = " | ".join(h.ljust(col_widths[i]) for i, h in enumerate(headers))
    lines.append(header_line)

    # Separator
    separator = "-|-".join("-" * w for w in col_widths)
    lines.append(separator)

    # Rows
    for row in rows:
        row_line = " | ".join(
            str(cell).ljust(col_widths[i]) for i, cell in enumerate(row)
        )
        lines.append(row_line)

    return "\n".join(lines)


# ============================================================================
# Lint Command (M3 Phase 5 Step 3)
# ============================================================================


def cmd_lint(args: argparse.Namespace) -> int:
    """Run regex-based linting rules."""
    from branchpy.semantics.propagation.regex_rule_engine import (
        RuleCategory,
        RuleSeverity,
        analyze_with_rules,
    )

    # Load project source files
    project_path = Path(args.project)
    if not project_path.exists():
        print(f"ERROR: Project path not found: {args.project}", file=sys.stderr)
        return 1

    # Find .rpy files
    rpy_files = list(project_path.glob("**/*.rpy"))
    if not rpy_files:
        print(f"ERROR: No .rpy files found in {args.project}", file=sys.stderr)
        return 1

    # Combine all source text
    all_source = []
    for rpy_file in rpy_files:
        try:
            source = rpy_file.read_text(encoding="utf-8")
            all_source.append(f"# FILE: {rpy_file.relative_to(project_path)}\n{source}")
        except Exception as e:
            print(f"WARNING: Could not read {rpy_file}: {e}", file=sys.stderr)

    combined_source = "\n\n".join(all_source)

    # Load custom rules if provided
    custom_rules_path = None
    if args.rules:
        custom_rules_path = Path(args.rules)
        if not custom_rules_path.exists():
            print(f"ERROR: Custom rules file not found: {args.rules}", file=sys.stderr)
            return 1

    # Analyze
    context = analyze_with_rules(
        nodes=[],  # Using source_text only
        source_text=combined_source,
        custom_rules_path=custom_rules_path,
    )

    # Filter by severity
    if args.severity != "all":
        severity_filter = RuleSeverity(args.severity)
        filtered_matches = context.get_matches_by_severity(severity_filter)
    else:
        filtered_matches = context.matches

    # Filter by category
    if args.category != "all":
        category_filter = RuleCategory(args.category)
        filtered_matches = [
            m for m in filtered_matches if m.rule.category == category_filter
        ]

    # Output
    if args.json:
        _output_lint_json(context, filtered_matches)
    elif args.summary:
        _output_lint_summary(context, filtered_matches)
    else:
        _output_lint_detailed(context, filtered_matches)

    return 0


def _output_lint_json(context, filtered_matches):
    """Output lint results as JSON."""
    data = {
        "version": "0.9.6-M3-Phase5-Step3",
        "rules_checked": context.rules_checked,
        "total_violations": context.total_violations,
        "filtered_violations": len(filtered_matches),
        "violations_by_severity": context.violations_by_severity,
        "violations_by_category": context.violations_by_category,
        "violations_by_rule": context.violations_by_rule,
        "matches": [m.to_dict() for m in filtered_matches],
    }
    print(json.dumps(data, indent=2))


def _output_lint_summary(context, filtered_matches):
    """Output lint summary (human-readable)."""
    print(f"\n{'=' * 60}")
    print("Lint Analysis Summary")
    print(f"{'=' * 60}\n")

    print(f"Rules Checked: {context.rules_checked}")
    print(f"Total Violations: {context.total_violations}")
    print(f"Filtered Violations: {len(filtered_matches)}")
    print()

    # By severity
    if context.violations_by_severity:
        print("Violations by Severity:")
        for severity, count in sorted(context.violations_by_severity.items()):
            print(f"  {severity}: {count}")
        print()

    # By category
    if context.violations_by_category:
        print("Violations by Category:")
        for category, count in sorted(context.violations_by_category.items()):
            print(f"  {category}: {count}")
        print()

    # Top violated rules
    if context.violations_by_rule:
        print("Top Violated Rules:")
        top_rules = sorted(
            context.violations_by_rule.items(), key=lambda x: x[1], reverse=True
        )[:10]
        for rule_id, count in top_rules:
            print(f"  {rule_id}: {count}")


def _output_lint_detailed(context, filtered_matches):
    """Output detailed lint results."""
    _output_lint_summary(context, filtered_matches)

    if not filtered_matches:
        print("\n✅ No violations found!")
        return

    print(f"\n{'=' * 60}")
    print(f"Detailed Violations ({len(filtered_matches)})")
    print(f"{'=' * 60}\n")

    # Group by severity
    by_severity = {}
    for match in filtered_matches:
        sev = match.rule.severity.value
        by_severity.setdefault(sev, []).append(match)

    severity_order = ["error", "warning", "info", "hint"]

    for severity in severity_order:
        if severity not in by_severity:
            continue

        matches = by_severity[severity]
        severity_symbol = {
            "error": "❌",
            "warning": "⚠️",
            "info": "ℹ️",
            "hint": "💡",
        }.get(severity, "•")

        print(f"\n{severity_symbol} {severity.upper()} ({len(matches)})\n")

        for i, match in enumerate(matches, 1):
            print(f"[{i}] {match.rule.name} ({match.rule.id})")
            print(f"    {match.rule.message}")
            print(f"    Line {match.line}, Column {match.column}")
            if match.label_context:
                print(f"    Label: {match.label_context}")
            print(f"    Matched: '{match.matched_text}'")
            print()
