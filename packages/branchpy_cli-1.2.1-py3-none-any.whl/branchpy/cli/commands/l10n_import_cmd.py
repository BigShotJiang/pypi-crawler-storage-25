"""
BranchPy L10n Import CLI Command (BPY-L10n-RT Phase 2 / Phase 3)

Validates and optionally applies an XLSX workbook back to the Ren'Py project.

Phase 2 delivers: --validate-only
Phase 3 delivers: --apply, --dry-run, --accept-drift, --skip-drift

Usage:
    bpy l10n import <source.xlsx> [OPTIONS]

Examples:
    # Validate a workbook and show summary (no file writes)
    bpy l10n import translations.xlsx --validate-only

    # Validate and emit JSON summary
    bpy l10n import translations.xlsx --validate-only --json-summary

Spec: docs/Current Version/Localization/L10N_ROUNDTRIP_V1_SPEC.md §7
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, Optional


def build_arg_parser(subparsers=None) -> argparse.ArgumentParser:
    """
    Build argument parser for ``bpy l10n import``.

    Registers the subcommand on *subparsers* when called by the router;
    returns a standalone parser otherwise.
    """
    kwargs = dict(
        prog="bpy l10n import",
        description=(
            "Validate (and optionally apply) a translated XLSX workbook.\n\n"
            "Reads the workbook exported by 'bpy l10n export', checks all rows\n"
            "against the current project state, and reports the validation result.\n"
            "Use --validate-only to preview without writing anything."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  bpy l10n import translations.xlsx --validate-only
  bpy l10n import translations.xlsx --validate-only --json-summary
        """,
    )
    if subparsers is not None:
        p = subparsers.add_parser("import", help="Validate (and apply) a translated XLSX workbook", **kwargs)
    else:
        p = argparse.ArgumentParser(**kwargs)

    p.add_argument(
        "source",
        metavar="FILE",
        help="Path to the .xlsx workbook to import",
    )

    p.add_argument(
        "--project",
        default=".",
        help="Project root directory (default: current directory)",
    )

    mode = p.add_mutually_exclusive_group()
    mode.add_argument(
        "--validate-only",
        action="store_true",
        default=False,
        help="Validate the workbook and report results without writing any files (Phase 2)",
    )
    mode.add_argument(
        "--apply",
        action="store_true",
        default=False,
        help="Apply validated translations to the project tl/ files",
    )

    p.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Run the full apply logic but write nothing (implies --apply logic without file writes)",
    )

    drift = p.add_mutually_exclusive_group()
    drift.add_argument(
        "--accept-drift",
        action="store_true",
        default=False,
        help="Apply SOURCE_DRIFT rows without prompting",
    )
    drift.add_argument(
        "--skip-drift",
        action="store_true",
        default=False,
        help="Skip SOURCE_DRIFT rows silently (default in non-TTY environments)",
    )

    p.add_argument(
        "--json-summary",
        action="store_true",
        default=False,
        help="Print a JSON summary of the validation to stdout",
    )

    return p


def run_from_cli(args: argparse.Namespace) -> int:
    """
    Entry point for ``bpy l10n import``.

    Returns 0 on clean validation, 1 on rejections, 10 on errors.
    """
    from branchpy.contract import Exit
    from branchpy.l10n.xlsx_reader import StructuralError, read_xlsx
    from branchpy.l10n.import_validator import ValidationCode, validate_import

    source_path = Path(args.source).resolve()
    if not source_path.exists():
        print(f"Error: file not found: {source_path}", file=sys.stderr)
        return Exit.INTERNAL

    if not source_path.suffix.lower() == ".xlsx":
        print(
            f"Warning: '{source_path.name}' does not have a .xlsx extension; "
            "attempting to read anyway.",
            file=sys.stderr,
        )

    project_root = Path(args.project).resolve()
    if not project_root.exists():
        print(f"Error: project root not found: {project_root}", file=sys.stderr)
        return Exit.INTERNAL

    # Default to validate-only when no mode flag given
    dry_run: bool = getattr(args, "dry_run", False)
    do_apply: bool = getattr(args, "apply", False) or dry_run

    print(f"Reading workbook: {source_path}", file=sys.stderr)

    # ── Structural validation ────────────────────────────────────────────────
    try:
        rows, _column_names = read_xlsx(source_path)
    except ImportError:
        return Exit.INTERNAL
    except StructuralError as exc:
        print(
            f"\u274c Structural error [{exc.code}]: {exc.detail}",
            file=sys.stderr,
        )
        if args.json_summary:
            _print_json({
                "status": "structural_error",
                "error_code": exc.code,
                "detail": exc.detail,
                "row_count": 0,
            })
        return Exit.ISSUES_FOUND
    except Exception as exc:
        print(f"Error reading workbook: {exc}", file=sys.stderr)
        return Exit.INTERNAL

    print(
        f"Read {len(rows)} data row(s) from '{source_path.name}'.",
        file=sys.stderr,
    )

    # ── Row-level validation ─────────────────────────────────────────────────
    print(f"Validating against project: {project_root}", file=sys.stderr)

    try:
        report = validate_import(rows, project_root)
    except Exception as exc:
        print(f"Error during validation: {exc}", file=sys.stderr)
        return Exit.INTERNAL

    # ── Print human-readable summary ─────────────────────────────────────────
    print("", file=sys.stderr)
    print(report.format_summary(), file=sys.stderr)

    # Detailed issue list (rejections and skips)
    for vr in report.rejected + report.skipped:
        for issue in vr.issues:
            icon = "\u274c" if issue.severity.value == "rejection" else "\u26a0\ufe0f"
            print(f"  {icon} [{issue.code.value}] {issue.detail}", file=sys.stderr)

    # Warnings (less prominent)
    for vr in report.warned:
        for issue in vr.issues:
            if issue.severity.value == "warning":
                print(f"  \u2139\ufe0f [{issue.code.value}] {issue.detail}", file=sys.stderr)

    # ── JSON summary ─────────────────────────────────────────────────────────
    if args.json_summary:
        counts = report.issue_counts()
        # Per-row detail — consumed by VS Code preview panel (spec §10.2)
        row_detail = []
        for vr in report.validated_rows:
            row_detail.append({
                "index":       vr.row_index,
                "outcome":     vr.outcome.value,
                "locale":      vr.row.locale,
                "key":         vr.row.key,
                "source_text": vr.row.source_text,
                "translation": vr.row.translation,
                "source_file": vr.row.source_file,
                "issues": [
                    {
                        "code":     issue.code.value,
                        "severity": issue.severity.value,
                        "detail":   issue.detail,
                    }
                    for issue in vr.issues
                ],
            })
        _print_json({
            "status": "ok" if not report.has_rejections else "has_rejections",
            "total_rows": report.total_rows,
            "to_update": report.to_update_count,
            "to_create": report.to_create_count,
            "skipped": report.skip_count,
            "rejected": report.reject_count,
            "warning_count": report.warning_count(),
            "issue_counts": {k.value: v for k, v in counts.items()},
            "project_scanned": report.project_scanned,
            "rows": row_detail,
        })

    # ── Exit code ─────────────────────────────────────────────────────────────
    if report.has_rejections:
        print(
            "\n\u274c Validation completed with rejections. "
            "Fix the issues above before applying.",
            file=sys.stderr,
        )
        return Exit.ISSUES_FOUND

    print("\n\u2705 Validation passed.", file=sys.stderr)

    if not do_apply:
        if report.to_update_count + report.to_create_count > 0:
            print(
                "Run 'bpy l10n import <file> --apply' to write translations.",
                file=sys.stderr,
            )
        return 0

    # ── Phase 3: Apply ───────────────────────────────────────────────────────
    from branchpy.l10n.apply_backup import BackupError, create_backup
    from branchpy.l10n.apply_engine import (
        ApplyReport,
        DriftPolicy,
        apply_translations,
        collect_touched_files,
    )

    dry_run_prefix = "[DRY RUN] " if dry_run else ""

    # Determine drift policy
    accept_drift: bool = getattr(args, "accept_drift", False)
    skip_drift: bool   = getattr(args, "skip_drift", False)
    is_tty = sys.stdin.isatty() and sys.stdout.isatty()

    if accept_drift:
        drift_policy = DriftPolicy.ACCEPT
    elif skip_drift or not is_tty:
        drift_policy = DriftPolicy.SKIP
    else:
        # Interactive TTY: resolve drift interactively before calling apply
        drift_policy = DriftPolicy.INTERACTIVE

    appliable_rows = [vr.row for vr in report.appliable]

    if not appliable_rows:
        print(f"{dry_run_prefix}No appliable rows — nothing to write.", file=sys.stderr)
        _emit_governance_apply(
            project_root=project_root,
            files_touched=0,
            rows_written=0,
            rows_skipped=0,
            backup_path=None,
            dry_run=dry_run,
        )
        return 0

    # Resolve INTERACTIVE drift before calling apply_translations
    if drift_policy == DriftPolicy.INTERACTIVE:
        from branchpy.l10n.import_validator import ValidationCode
        resolved_rows = []
        for vr in report.appliable:
            has_drift = any(
                issue.code == ValidationCode.SOURCE_DRIFT
                for issue in vr.issues
            )
            if has_drift:
                print(
                    f"  ⚠  SOURCE_DRIFT — key: {vr.row.key}\n"
                    f"    Source text has changed since export.\n"
                    f"    Apply anyway? [y/N] ",
                    end="",
                    file=sys.stderr,
                )
                answer = sys.stdin.readline().strip().lower()
                if answer in ("y", "yes"):
                    resolved_rows.append(vr.row)
                # else skip silently
            else:
                resolved_rows.append(vr.row)
        appliable_rows = resolved_rows
        drift_policy = DriftPolicy.ACCEPT  # already resolved

    # ── Backup ───────────────────────────────────────────────────────────────
    backup_result = None
    backup_path_for_report = None
    if not dry_run:
        touched_files = collect_touched_files(appliable_rows, project_root)
        if touched_files:
            try:
                backup_result = create_backup(project_root, touched_files)
                backup_path_for_report = backup_result.backup_dir
                print(
                    f"Backup created: {backup_result.backup_dir} "
                    f"({backup_result.files_backed_up} file(s))",
                    file=sys.stderr,
                )
            except BackupError as exc:
                print(
                    f"\u274c Backup failed [{exc.code}]: {exc.detail}",
                    file=sys.stderr,
                )
                return Exit.INTERNAL

    # ── Write ────────────────────────────────────────────────────────────────
    print(
        f"{dry_run_prefix}Applying {len(appliable_rows)} row(s) to project…",
        file=sys.stderr,
    )

    try:
        apply_report = apply_translations(
            rows=appliable_rows,
            project_root=project_root,
            backup_path=backup_path_for_report,
            dry_run=dry_run,
            drift_policy=drift_policy,
        )
    except Exception as exc:
        print(f"Error during apply: {exc}", file=sys.stderr)
        return Exit.INTERNAL

    print("", file=sys.stderr)
    print(apply_report.format_summary(prefix=dry_run_prefix), file=sys.stderr)

    # ── Governance event ─────────────────────────────────────────────────────
    _emit_governance_apply(
        project_root=project_root,
        files_touched=apply_report.files_touched,
        rows_written=apply_report.rows_written,
        rows_skipped=apply_report.rows_skipped,
        backup_path=backup_path_for_report,
        dry_run=dry_run,
    )

    # ── JSON summary (apply result) ──────────────────────────────────────────
    if args.json_summary:
        _print_json({
            "status": "applied" if not dry_run else "dry_run",
            "dry_run": dry_run,
            "files_touched": apply_report.files_touched,
            "rows_written": apply_report.rows_written,
            "rows_skipped": apply_report.rows_skipped,
            "files_failed": apply_report.files_failed,
            "drift_accepted": apply_report.drift_accepted,
            "drift_skipped": apply_report.drift_skipped,
            "backup_path": str(backup_path_for_report) if backup_path_for_report else None,
            # Spec §10.3 coverage delta: {locale: [before_pct, after_pct]}
            "locale_coverage_delta": {
                locale: list(pair)
                for locale, pair in apply_report.locale_coverage_delta.items()
            },
        })

    return Exit.INTERNAL if apply_report.files_failed > 0 else 0


def _print_json(data: Dict[str, Any]) -> None:
    print(json.dumps(data, ensure_ascii=False, indent=2))


def _emit_governance_apply(
    project_root: Path,
    files_touched: int,
    rows_written: int,
    rows_skipped: int,
    backup_path: Optional[Path],
    dry_run: bool,
) -> None:
    """Emit the l10n.apply governance event (spec §8.6, best-effort)."""
    try:
        from branchpy.governance import emit_event  # type: ignore[import]

        emit_event(
            "l10n.apply",
            {
                "files_touched": files_touched,
                "rows_written": rows_written,
                "rows_skipped": rows_skipped,
                "backup_path": str(backup_path) if backup_path else None,
                "dry_run": dry_run,
            },
            project_root=project_root,
        )
    except Exception:
        # Governance is best-effort — never fail the main operation
        pass
