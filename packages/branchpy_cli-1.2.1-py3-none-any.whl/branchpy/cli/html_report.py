"""
branchpy/cli/html_report.py
Shared helper for --html / --open CLI flags.

Generates self-contained HTML reports for analyze, stats, and flowchart
commands and optionally opens them in the default browser.

Contract:
  --html  → write HTML artifact to disk, print path to stderr
  --open  → write HTML artifact AND open in browser (implies --html)
"""

from __future__ import annotations

import html
import json
import sys
import time
import webbrowser
from pathlib import Path
from typing import Any, Dict, Optional

# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------


def _default_html_path(project_root: Path, command: str) -> Path:
    """Return default HTML artifact path inside .branchpy/reports/."""
    reports_dir = project_root / ".branchpy" / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    ts = time.strftime("%Y%m%d-%H%M%S")
    return reports_dir / f"{command}-{ts}.html"


def resolve_html_output_path(
    project_root: Path,
    command: str,
    requested_out: Optional[str | Path] = None,
) -> Path:
    """
    Resolve the HTML destination.

    If requested_out points to an .html/.htm file, use it.
    Otherwise fall back to the default .branchpy/reports location.
    """
    if requested_out:
        out_path = Path(requested_out).expanduser()
        if out_path.suffix.lower() in {".html", ".htm"}:
            return out_path.resolve()
    return _default_html_path(project_root, command)


def announce_html_report(command: str, path: Path) -> None:
    """Print a consistent success message for generated HTML reports."""
    print(f"[bpy] {command.capitalize()} HTML report: {path}", file=sys.stderr)


# ---------------------------------------------------------------------------
# Shared HTML boilerplate
# ---------------------------------------------------------------------------

_CSS = """
  :root { --bg:#0f1117; --panel:#1a1d27; --border:#2a2d3a; --text:#e4e6f0;
          --muted:#7a7d8c; --ok:#4ade80; --warn:#facc15; --err:#f87171;
          --accent:#7ce7db; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: var(--bg); color: var(--text); font-family: ui-monospace,
         'Cascadia Code', 'Fira Code', monospace; font-size: 14px;
         line-height: 1.6; padding: 24px; }
  h1 { font-size: 1.4rem; color: var(--accent); margin-bottom: 4px; }
  h2 { font-size: 1.1rem; color: var(--text); margin: 20px 0 10px; }
  .meta { color: var(--muted); font-size: 0.85rem; margin-bottom: 20px; }
  .card { background: var(--panel); border: 1px solid var(--border);
          border-radius: 8px; padding: 16px; margin-bottom: 16px; }
  .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(140px,1fr));
          gap: 12px; }
  .stat { background: var(--bg); border: 1px solid var(--border); border-radius: 6px;
          padding: 12px; text-align: center; }
  .stat.summary { opacity:.74; border-color:#252834; }
  .stat .val { font-size: 1.6rem; font-weight: 700; margin-bottom: 4px; }
  .stat .lbl { color: var(--muted); font-size: 0.75rem; text-transform: uppercase;
               letter-spacing: .05em; }
  .ok  { color: var(--ok);   }
  .warn{ color: var(--warn); }
  .err { color: var(--err);  }
  table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
  th { text-align: left; color: var(--muted); font-weight: 600; padding: 6px 10px;
       border-bottom: 1px solid var(--border); }
  td { padding: 6px 10px; border-bottom: 1px solid var(--border); vertical-align: top; }
  tr:last-child td { border-bottom: none; }
  .tag { display: inline-block; padding: 2px 6px; border-radius: 4px;
         font-size: 0.7rem; font-weight: 700; letter-spacing: .05em; }
  .tag.err  { background: rgba(248,113,113,.15); color: var(--err); }
  .tag.warn { background: rgba(250,204,21,.12); color: var(--warn); }
  .tag.info { background: rgba(124,231,219,.1); color: var(--accent); }
  .tag.ok   { background: rgba(74,222,128,.1); color: var(--ok); }
    details.card { padding: 0; overflow: hidden; }
    details.card > summary { list-style: none; cursor: pointer; padding: 14px 16px;
                                                     font-weight: 700; user-select: none; }
    details.card > summary::-webkit-details-marker { display: none; }
    details.card > summary::after { content: '+'; float: right; color: var(--muted); }
    details.card[open] > summary::after { content: '-'; }
    .card-body { padding: 0 16px 16px; }
    .stat.filterable { cursor: pointer; transition: border-color .12s ease, transform .12s ease; }
    .stat.filterable:hover { border-color: var(--accent); transform: translateY(-1px); }
    .stat.filterable.active { border-color: var(--accent); box-shadow: 0 0 0 1px rgba(124,231,219,.25) inset; }
  .ext-chip { display:inline-block; padding:1px 5px; border-radius:3px; font-size:0.65rem;
              font-weight:700; letter-spacing:.04em; background:#2a2d3a; color:#7a7d8c;
              vertical-align:middle; margin-left:4px; }
  .refs-list { list-style:none; padding:0; margin:2px 0 0; max-height:90px; overflow-y:auto; }
  .refs-list li { font-size:0.72rem; color:var(--muted); word-break:break-all;
                  border-top:1px solid var(--border); padding:2px 0; }
  a.file-link { font-size:0.78rem; color:#7a7d8c; }
  a.file-link:hover { color:var(--accent); }
  /* Item Details three-zone panel */
  .detail-card { display:flex; flex-direction:column; max-height:calc(100vh - 48px); }
  .detail-card > summary { flex-shrink:0; }
  .detail-zone-head { flex-shrink:0; padding:0 14px 0; }
  .detail-zone-refs { flex:1 1 auto; min-height:0; overflow-y:auto;
                      margin:0 14px; border-top:1px solid var(--border); padding:6px 0; }
  .detail-zone-foot { flex-shrink:0; padding:10px 14px 12px;
                      border-top:1px solid var(--border); display:flex; gap:6px; flex-wrap:wrap; }
  .meta-grid { display:grid; grid-template-columns:auto 1fr; gap:2px 10px;
               font-size:0.78rem; padding:8px 0; }
  .meta-grid dt { color:var(--muted); white-space:nowrap; }
  .meta-grid dd { color:var(--text); word-break:break-all; margin:0; }
  .path-display { font-size:0.75rem; color:var(--text); word-break:break-all;
                  cursor:pointer; padding:4px 0; border-bottom:1px solid var(--border);
                  margin:4px 14px 0; }
  .path-display:hover { color:var(--accent); }
  .refs-label { font-size:0.68rem; color:var(--muted); text-transform:uppercase;
                letter-spacing:.05em; margin-bottom:3px; }
    .reason-summary { font-size:0.78rem; color:var(--text); line-height:1.3; }
    .action-btn { display:inline-flex; align-items:center; justify-content:center;
                                width:28px; height:26px; border-radius:5px; border:1px solid #2a2d3a;
                                                                background:#1d2230; color:#eef0fa; text-decoration:none;
                                font-size:1rem; cursor:pointer; transition:background .1s, color .1s;
                                vertical-align:middle; }
        .action-btn:hover { background:#243652; color:#9deee4; text-decoration:none; border-color:#345178; }
        .hint-mini { color:var(--muted); font-size:.72rem; cursor:help; opacity:.75; }
        .toolbar-utility { margin-left:auto; display:inline-flex; gap:10px; align-items:center; }
        .group-head td { background: rgba(124,231,219,.05); color: var(--accent); font-weight:700; }
        .path-compact { white-space:nowrap; overflow:hidden; text-overflow:ellipsis; display:inline-block; max-width:430px; vertical-align:bottom; }
    tr.media-row { cursor:pointer; }
    tr.media-row:hover td { background:rgba(124,231,219,.04); }
    tr.row-selected td { background:rgba(124,231,219,.22) !important; }
    tr.row-selected td:first-child { box-shadow: inset 3px 0 0 rgba(124,231,219,.9); }
  footer { margin-top: 32px; color: var(--muted); font-size: 0.75rem; }
  a { color: var(--accent); text-decoration: none; }
  a:hover { text-decoration: underline; }
"""


def _html_wrap(title: str, body: str, *, generated_at: str = "") -> str:
    """Wrap body HTML in a complete self-contained page."""
    ts = generated_at or time.strftime("%Y-%m-%d %H:%M:%S")
    return (
        "<!DOCTYPE html>\n"
        '<html lang="en">\n'
        "<head>\n"
        '  <meta charset="UTF-8">\n'
        '  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
        f"  <title>{html.escape(title)}</title>\n"
        f"  <style>{_CSS}</style>\n"
        "</head>\n"
        "<body>\n"
        f"{body}\n"
        f"<footer>Generated by BranchPy · {ts}</footer>\n"
        "</body>\n"
        "</html>\n"
    )


# ---------------------------------------------------------------------------
# open_in_browser
# ---------------------------------------------------------------------------


def open_in_browser(path: Path) -> None:
    """Open a local HTML file in the system default browser."""
    webbrowser.open(path.resolve().as_uri())


# ---------------------------------------------------------------------------
# Analyze HTML
# ---------------------------------------------------------------------------


def _sev_class(sev: str) -> str:
    s = str(sev).lower()
    if s in ("error", "err"):
        return "err"
    if s in ("warning", "warn"):
        return "warn"
    return "info"


def generate_analyze_html(
    payload: Dict[str, Any],
    project_root: Path,
    out_path: Optional[Path] = None,
) -> Path:
    """
    Generate a self-contained analyze HTML report.

    Parameters
    ----------
    payload : dict
        The full analyze payload (project, path, result, discovery).
    project_root : Path
        Project root directory (used for default output path).
    out_path : Path | None
        Override output path. Defaults to .branchpy/reports/analyze-<ts>.html.

    Returns
    -------
    Path
        Path where the HTML file was written.
    """
    result = payload.get("result", {})
    summary = result.get("summary", {})
    issues = result.get("issues", [])
    project_name = html.escape(str(payload.get("project", project_root.name)))
    project_path = html.escape(str(payload.get("path", str(project_root))))

    n_labels = summary.get("labels", 0)
    n_files = summary.get("files", 0)
    n_issues = len(issues) if isinstance(issues, list) else 0
    n_errors = sum(1 for i in issues if i.get("severity", "") in ("error", "err"))
    n_warnings = sum(1 for i in issues if i.get("severity", "") in ("warning", "warn"))

    sev_class = (
        "ok" if n_errors == 0 and n_warnings == 0 else ("err" if n_errors else "warn")
    )

    # Discovery metadata
    discovery = payload.get("discovery", {})
    engine = (
        discovery.get("matched_engine", "renpy")
        if isinstance(discovery, dict)
        else "renpy"
    )

    # Stats grid
    stats_grid = (
        '<div class="grid">'
        f'<div class="stat"><div class="val ok">{n_labels}</div><div class="lbl">Labels</div></div>'
        f'<div class="stat"><div class="val">{n_files}</div><div class="lbl">Files</div></div>'
        f'<div class="stat"><div class="val {sev_class}">{n_issues}</div><div class="lbl">Issues</div></div>'
        f'<div class="stat"><div class="val err">{n_errors}</div><div class="lbl">Errors</div></div>'
        f'<div class="stat"><div class="val warn">{n_warnings}</div><div class="lbl">Warnings</div></div>'
        f'<div class="stat"><div class="val">{html.escape(str(engine))}</div><div class="lbl">Engine</div></div>'
        "</div>"
    )

    # Issues table
    if issues:
        rows = []
        for iss in issues[:500]:  # cap to 500 for performance
            sev = str(iss.get("severity", iss.get("sev", "info")))
            rule = html.escape(str(iss.get("rule", iss.get("code", ""))))
            msg = html.escape(str(iss.get("message", iss.get("msg", ""))))
            loc_file = html.escape(str(iss.get("file", "")))
            loc_line = html.escape(str(iss.get("line", "")))
            loc = f"{loc_file}:{loc_line}" if loc_file else ""
            sc = _sev_class(sev)
            rows.append(
                f"<tr>"
                f'<td><span class="tag {sc}">{html.escape(sev)}</span></td>'
                f"<td><code>{rule}</code></td>"
                f"<td>{msg}</td>"
                f"<td>{loc}</td>"
                f"</tr>"
            )
        issues_section = (
            '<div class="card">'
            "<h2>Issues</h2>"
            "<table>"
            "<thead><tr><th>Severity</th><th>Rule</th><th>Message</th><th>Location</th></tr></thead>"
            "<tbody>" + "".join(rows) + "</tbody>"
            "</table>"
            "</div>"
        )
        if len(issues) > 500:
            issues_section += (
                f'<p class="meta">Showing first 500 of {len(issues)} issues.</p>'
            )
    else:
        issues_section = '<div class="card"><h2>Issues</h2><p class="ok">✓ No issues found.</p></div>'

    # D9 Narrative Structure card (research) — only when enabled.
    ns = (
        result.get("story_structure", {})
        .get("collapsed_graph", {})
        .get("analysis", {})
        .get("semantic_summary", {})
        .get("narrative_structure", {})
    )
    if ns.get("enabled"):
        raw_n = ns.get("raw_node_count", 0)
        scr_val = ns.get("structural_complexity_ratio_raw")
        scr_band = html.escape(str(ns.get("structural_complexity_band", "")))
        corridors = ns.get("corridor_count", 0)
        branch_hubs = ns.get("major_branch_hub_count", 0)
        merge_hubs = ns.get("major_merge_hub_count", 0)
        detachable = ns.get("detachable_scene_count", 0)
        lattice = ns.get("hub_return_lattice_count", 0)
        route_count = ns.get("route_candidate_count", 0)
        rbi = ns.get("route_balance_index")
        rbi_band = html.escape(str(ns.get("route_balance_band", "")))

        scr_str = f"{scr_band} ({scr_val:.2f})" if scr_val is not None else scr_band

        ns_rows = [
            f"<tr><td>Nodes</td><td>{raw_n}</td></tr>",
            f"<tr><td>SCR</td><td>{scr_str}</td></tr>",
            f"<tr><td>Corridors</td><td>{corridors}</td></tr>",
            f"<tr><td>Hubs</td><td>{branch_hubs} branch / {merge_hubs} merge</td></tr>",
        ]
        if detachable:
            ns_rows.append(f"<tr><td>Detachable scenes</td><td>{detachable}</td></tr>")
        if route_count:
            rbi_str = f"{rbi_band} (RBI {rbi:.2f})" if rbi is not None else ""
            rbi_cell = f" &middot; Balance: {rbi_str}" if rbi_str else ""
            ns_rows.append(
                f"<tr><td>Routes</td><td>{route_count} candidate(s){rbi_cell}</td></tr>"
            )
        if lattice:
            ns_rows.append(
                f"<tr><td>Hub-return lattice roots</td><td>{lattice}</td></tr>"
            )

        # Advisory rows — only for non-benign bands.
        from branchpy.analysis.flow_graph_analysis import RBI_BAND_NOTES, SCR_BAND_NOTES

        scr_note = SCR_BAND_NOTES.get(str(ns.get("structural_complexity_band", "")))
        rbi_note = (
            RBI_BAND_NOTES.get(str(ns.get("route_balance_band", "")))
            if ns.get("route_balance_band")
            else None
        )
        if scr_note:
            ns_rows.append(
                f'<tr><td colspan="2" style="color:var(--muted);font-size:0.85rem;">'
                f"SCR: {html.escape(scr_note)}</td></tr>"
            )
        if rbi_note:
            ns_rows.append(
                f'<tr><td colspan="2" style="color:var(--muted);font-size:0.85rem;">'
                f"RBI: {html.escape(rbi_note)}</td></tr>"
            )

        ns_card = (
            '<div class="card">'
            '<h2>Narrative Structure <span style="font-size:0.7rem;color:var(--muted);'
            'font-weight:400;">(research)</span></h2>'
            "<table>"
            "<tbody>" + "".join(ns_rows) + "</tbody>"
            "</table>"
            "</div>"
        )
    else:
        ns_card = ""

    body = (
        f"<h1>BranchPy Analyze — {project_name}</h1>\n"
        f'<p class="meta">{project_path}</p>\n'
        f'<div class="card">{stats_grid}</div>\n'
        f"{ns_card}\n"
        f"{issues_section}\n"
    )

    page = _html_wrap(f"Analyze — {project_name} · BranchPy", body)

    target = out_path or _default_html_path(project_root, "analyze")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(page, encoding="utf-8")
    return target


# ---------------------------------------------------------------------------
# Stats HTML
# ---------------------------------------------------------------------------


def generate_stats_html(
    stats_data: Dict[str, Any],
    project_root: Path,
    out_path: Optional[Path] = None,
) -> Path:
    """
    Generate a self-contained stats HTML report.

    Parameters
    ----------
    stats_data : dict
        The stats report data (variables, assignments, issues, all_variables).
    project_root : Path
        Project root directory.
    out_path : Path | None
        Override output path.

    Returns
    -------
    Path
        Path where HTML was written.
    """
    project_name = html.escape(project_root.name)
    variables_list = stats_data.get("all_variables", [])
    issues = stats_data.get("issues", [])
    n_vars = stats_data.get("variables", len(variables_list))
    n_assigns = stats_data.get("assignments", 0)
    n_issues = len(issues) if isinstance(issues, list) else 0

    sev_class = "ok" if n_issues == 0 else "warn"

    # Distribution
    dist = stats_data.get("type_distribution", {})
    dist_html = ""
    if dist:
        dist_html = '<div class="grid">'
        for dtype, count in dist.items():
            dist_html += (
                f'<div class="stat"><div class="val">{count}</div>'
                f'<div class="lbl">{html.escape(str(dtype))}</div></div>'
            )
        dist_html += "</div>"

    # Stats grid
    stats_grid = (
        '<div class="grid">'
        f'<div class="stat"><div class="val">{n_vars}</div><div class="lbl">Variables</div></div>'
        f'<div class="stat"><div class="val">{n_assigns}</div><div class="lbl">Assignments</div></div>'
        f'<div class="stat"><div class="val {sev_class}">{n_issues}</div><div class="lbl">Issues</div></div>'
        "</div>"
    )

    # Issues table
    if issues:
        rows = []
        for iss in issues[:500]:
            var = html.escape(str(iss.get("var", "")))
            issue_type = html.escape(str(iss.get("issue", "")))
            types = html.escape(", ".join(iss.get("types", [])))
            hint = html.escape(str(iss.get("hint", "")))
            rows.append(
                f"<tr>"
                f"<td><code>{var}</code></td>"
                f'<td><span class="tag warn">{issue_type}</span></td>'
                f"<td>{types}</td>"
                f"<td>{hint}</td>"
                f"</tr>"
            )
        issues_section = (
            '<div class="card">'
            "<h2>Issues</h2>"
            "<table>"
            "<thead><tr><th>Variable</th><th>Issue</th><th>Types</th><th>Hint</th></tr></thead>"
            "<tbody>" + "".join(rows) + "</tbody>"
            "</table>"
            "</div>"
        )
    else:
        issues_section = '<div class="card"><h2>Issues</h2><p class="ok">✓ No issues found.</p></div>'

    # Variables table (top 200, with status)
    var_section = ""
    if variables_list:
        show = variables_list[:200]
        rows = []
        for v in show:
            name = html.escape(str(v.get("name", "")))
            types = html.escape(", ".join(v.get("types", [])))
            status = str(v.get("status", "ok"))
            sc = _sev_class(status) if status != "ok" else "ok"
            issue_desc = html.escape(str(v.get("issue", "") or ""))
            rows.append(
                f"<tr>"
                f"<td><code>{name}</code></td>"
                f"<td>{types}</td>"
                f'<td><span class="tag {sc}">{html.escape(status)}</span> {issue_desc}</td>'
                f"<td>{v.get('usage_count', 0)}</td>"
                f"</tr>"
            )
        var_section = (
            '<div class="card">'
            f"<h2>Variables ({n_vars})</h2>"
            "<table>"
            "<thead><tr><th>Name</th><th>Types</th><th>Status</th><th>Uses</th></tr></thead>"
            "<tbody>" + "".join(rows) + "</tbody>"
            "</table>"
            "</div>"
        )
        if len(variables_list) > 200:
            var_section += f'<p class="meta">Showing first 200 of {len(variables_list)} variables.</p>'

    dist_section = (
        '<div class="card"><h2>Type Distribution</h2>' + dist_html + "</div>"
        if dist_html
        else ""
    )

    body = (
        f"<h1>BranchPy Stats — {project_name}</h1>\n"
        f'<p class="meta">{html.escape(str(project_root))}</p>\n'
        f'<div class="card">{stats_grid}</div>\n'
        f"{dist_section}\n"
        f"{issues_section}\n"
        f"{var_section}\n"
    )

    page = _html_wrap(f"Stats — {project_name} · BranchPy", body)

    target = out_path or _default_html_path(project_root, "stats")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(page, encoding="utf-8")
    return target


# ---------------------------------------------------------------------------
# PILOT (stats2) HTML
# ---------------------------------------------------------------------------


def generate_pilot_html(
    pilot_data: Dict[str, Any],
    project_root: Path,
    out_path: Optional[Path] = None,
) -> Path:
    """
    Generate a self-contained PILOT HTML report.

    Parameters
    ----------
    pilot_data : dict
        The full stats2/pilot JSON payload (schema_version 2.0).
    project_root : Path
        Project root directory.
    out_path : Path | None
        Override output path.
    """
    project_name = html.escape(pilot_data.get("project", project_root.name))
    generated_at = pilot_data.get("generated_at", "")
    summary = pilot_data.get("summary", {})
    aggregates = pilot_data.get("aggregates", {})
    warnings = pilot_data.get("warnings", {})

    n_paths = summary.get("paths_enumerated") or summary.get("total_paths", 0)
    n_vars = summary.get("total_variables", 0)
    n_stat = summary.get("stat_variables", 0)
    n_hv = len(warnings.get("highVariance", []))
    perf_ms = (pilot_data.get("performance") or {}).get("analysis_duration_ms")
    perf_str = f" · {perf_ms:,} ms" if perf_ms else ""

    # Narrative Paths metrics (spec §8 — narrative-first display order)
    np_est = summary.get("narrative_paths_estimate")
    np_conf = summary.get("narrative_confidence", "not_computed")
    np_computed = np_conf != "not_computed" and np_est is not None
    if np_computed:
        prefix = "~" if np_conf in ("medium", "low") else ""
        np_display = np_est if isinstance(np_est, str) else f"{prefix}{np_est}"
    else:
        np_display = "\u2014"
    np_conf_label = "" if np_conf == "not_computed" else np_conf.capitalize()
    np_conf_note = (
        f"<br><small style='color:#888;'>{html.escape(np_conf_label)} confidence</small>"
        if np_conf_label
        else ""
    )
    np_topo = summary.get("narrative_topology", "not_computed")
    np_out_count = summary.get("narrative_outcomes_estimate")
    np_context_note = ""
    if np_computed:
        if np_topo == "linear_variant":
            np_context_note = "<br><small style='color:#666;'>Linear story with branching scene variations</small>"
        elif np_topo == "hub_loop":
            _segs = (
                f" ({np_out_count} reachable segments)"
                if np_out_count is not None
                else ""
            )
            np_context_note = (
                f"<br><small style='color:#666;'>Loop-based structure{_segs}</small>"
            )
        elif np_topo == "branching":
            _routes = (
                f" ({np_out_count} distinct routes)" if np_out_count is not None else ""
            )
            np_context_note = (
                f"<br><small style='color:#666;'>Branching story{_routes}</small>"
            )
        # linear and not_computed: no context note

    hv_cls = "warn" if n_hv else "ok"
    capped = summary.get("paths_capped", False)
    exec_display = f"{n_paths}+" if capped else str(n_paths)
    stats_grid = (
        '<div class="grid">'
        # Narrative Paths — first
        f'<div class="stat"><div class="val" style="color:#4fc3f7;">{html.escape(str(np_display))}</div>'
        f'<div class="lbl">Narrative Paths{np_conf_note}{np_context_note}</div></div>'
        # Standard PILOT metrics
        f'<div class="stat"><div class="val">{n_vars}</div><div class="lbl">Variables Tracked</div></div>'
        f'<div class="stat"><div class="val">{n_stat}</div><div class="lbl">Stat Variables</div></div>'
        f'<div class="stat"><div class="val {hv_cls}">{n_hv}</div><div class="lbl">High Variance</div></div>'
        # Execution Paths — last, muted
        f'<div class="stat"><div class="val" style="color:#666;font-size:1.4em;">{html.escape(exec_display)}</div>'
        f'<div class="lbl" style="color:#555;">Execution Paths</div></div>'
        "</div>"
    )

    def _fmt(v, decimals=1):
        return "—" if v is None else f"{v:.{decimals}f}"

    def _rate_cls(r):
        if r is None:
            return ""
        return "err" if r < 0.25 else "warn" if r < 0.6 else "ok"

    # Variable Health table
    if aggregates:
        agg_rows = []
        high_var_set = set(warnings.get("highVariance", []))
        for var_name, agg in sorted(aggregates.items()):
            ns = agg.get("numeric_stats")
            ds = agg.get("delta_stats")
            cov = agg.get("coverage", {})
            flags = agg.get("flags", {})
            tc = agg.get("type_consistency", {})
            type_label = (
                "mixed"
                if tc.get("is_consistent") is False
                else ((tc.get("types") or ["?"])[0])
            )
            rate = cov.get("assignment_rate")
            rate_str = "—" if rate is None else f"{rate * 100:.0f}%"
            rate_cls = _rate_cls(rate)
            mean_str = _fmt(ns.get("mean") if ns else None)
            std_str = _fmt(ns.get("stddev") if ns else None)
            mn = ns.get("min") if ns else None
            mx = ns.get("max") if ns else None
            range_str = f"{_fmt(mn)} → {_fmt(mx)}" if ns else "—"
            dm = ds.get("mean") if ds else None
            delta_str = _fmt(dm)
            delta_cls = (
                "ok"
                if (dm is not None and dm > 0)
                else ("err" if (dm is not None and dm < 0) else "")
            )
            hv_marker = " ⚠" if var_name in high_var_set else ""
            chips = " ".join(
                filter(
                    None,
                    [
                        (
                            '<span class="tag info">STAT</span>'
                            if flags.get("is_stat")
                            else ""
                        ),
                        (
                            '<span class="tag ok">FLAG</span>'
                            if flags.get("is_flag")
                            else ""
                        ),
                    ],
                )
            )
            agg_rows.append(
                f"<tr>"
                f"<td><code>{html.escape(var_name)}{hv_marker}</code></td>"
                f"<td>{html.escape(type_label)}</td>"
                f"<td>{mean_str}</td>"
                f"<td>{std_str}</td>"
                f"<td>{range_str}</td>"
                f'<td class="{delta_cls}">{delta_str}</td>'
                f'<td class="{rate_cls}">{rate_str}</td>'
                f"<td>{chips}</td>"
                f"</tr>"
            )
        agg_section = (
            '<div class="card"><h2>Variable Health</h2>'
            "<table>"
            "<thead><tr><th>Variable</th><th>Type</th><th>Mean</th><th>StdDev</th>"
            "<th>Range</th><th>Avg Δ</th><th>Assign Rate</th><th>Flags</th></tr></thead>"
            "<tbody>" + "".join(agg_rows) + "</tbody>"
            "</table></div>"
        )
    else:
        agg_section = '<div class="card"><h2>Variable Health</h2><p>No aggregate data — run analysis with at least one path.</p></div>'

    def _warn_list(items: list, label: str) -> str:
        if not items:
            return f'<p class="ok">✓ No {html.escape(label)}.</p>'
        return (
            "<ul>"
            + "".join(f"<li><code>{html.escape(i)}</code></li>" for i in items)
            + "</ul>"
        )

    warn_section = (
        '<div class="card"><h2>Warnings</h2>'
        "<h3>High Variance</h3>"
        + _warn_list(warnings.get("highVariance", []), "high-variance variables")
        + "<h3>Type Inconsistencies</h3>"
        + _warn_list(warnings.get("typeInconsistencies", []), "type inconsistencies")
        + "</div>"
    )

    ts_display = (
        html.escape(generated_at.replace("T", " ").replace("Z", " UTC")[:19])
        if generated_at
        else ""
    )
    body = (
        f"<h1>BranchPy PILOT — {project_name}</h1>\n"
        f'<p class="meta">{html.escape(str(project_root))}'
        + (f" · {ts_display}" if ts_display else "")
        + f"{perf_str}</p>\n"
        f'<div class="card">{stats_grid}</div>\n'
        f"{agg_section}\n"
        f"{warn_section}\n"
    )

    page = _html_wrap(
        f"PILOT — {project_name} · BranchPy", body, generated_at=generated_at
    )
    target = out_path or _default_html_path(project_root, "pilot")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(page, encoding="utf-8")
    return target


# ---------------------------------------------------------------------------
# OMEGA HTML
# ---------------------------------------------------------------------------


def generate_omega_html(
    omega_data: Dict[str, Any],
    project_root: Path,
    out_path: Optional[Path] = None,
    omega2_data: Optional[Dict[str, Any]] = None,
) -> Path:
    """
    Generate a self-contained OMEGA HTML report.

    Parameters
    ----------
    omega_data : dict
        The legacy omega.json payload (omega_version 0.1.x).
    project_root : Path
        Project root directory.
    out_path : Path | None
        Override output path.
    omega2_data : dict | None
        Optional Ω-2 metrics payload (omega_metrics.json), enriches the report.
    """
    project_name = html.escape(project_root.name)
    omega_ver = html.escape(str(omega_data.get("omega_version", "0.1.0")))
    stats = omega_data.get("stats", {})
    variables = omega_data.get("variables", {})
    combos = omega_data.get("impossible_combo_candidates", [])
    limits = omega_data.get("limits", {})

    n_paths = stats.get("paths_seen", 0)
    n_events = stats.get("events_seen", 0)
    n_vars = stats.get("variables_seen", 0)

    stats_grid_parts = [
        f'<div class="stat"><div class="val">{n_paths}</div><div class="lbl">Paths Analyzed</div></div>',
        f'<div class="stat"><div class="val">{n_events}</div><div class="lbl">Events Processed</div></div>',
        f'<div class="stat"><div class="val">{n_vars}</div><div class="lbl">Variables Tracked</div></div>',
    ]
    if omega2_data:
        gs = omega2_data.get("graph_summary", {})
        cycles = gs.get("cycles_detected", False)
        cycles_str = "⚠ Yes" if cycles else "✓ None"
        cycles_cls = "warn" if cycles else "ok"
        stats_grid_parts += [
            f'<div class="stat"><div class="val">{gs.get("nodes", 0)}</div><div class="lbl">Nodes (Ω-2)</div></div>',
            f'<div class="stat"><div class="val">{gs.get("nodes_with_modifications", 0)}</div><div class="lbl">Nodes Modified</div></div>',
            f'<div class="stat"><div class="val {cycles_cls}">{cycles_str}</div><div class="lbl">Cycles</div></div>',
        ]
    stats_grid = '<div class="grid">' + "".join(stats_grid_parts) + "</div>"

    limits_banner = ""
    if limits.get("capped"):
        capped_vars = ", ".join(limits.get("capped_variables", []))
        limits_banner = (
            f'<p class="warn" style="margin-top:8px;">⚠ Limits reached — '
            f'value cap: {limits.get("value_cap", 50)}, '
            f'combo checks: {limits.get("combo_checks", 0)}/{limits.get("combo_cap", 2000)}'
            + (f", capped: {html.escape(capped_vars)}" if capped_vars else "")
            + "</p>"
        )

    if variables:
        var_rows = []
        for var_name, info in sorted(variables.items()):
            vtype = html.escape(info.get("type", "unknown"))
            if info.get("type") == "number":
                bounds = f'{info.get("min", "?")} → {info.get("max", "?")}'
            elif info.get("type") == "boolean":
                bounds = (
                    f'T: {info.get("seen_true", 0)}, F: {info.get("seen_false", 0)}'
                )
            else:
                vals = info.get("values", [])
                bounds = f'{len(vals)} distinct{"  (capped)" if info.get("truncated") else ""}'
            var_rows.append(
                f"<tr><td><code>{html.escape(var_name)}</code></td>"
                f"<td>{vtype}</td><td>{html.escape(bounds)}</td></tr>"
            )
        var_section = (
            '<div class="card"><h2>Variable Bounds</h2>'
            "<table><thead><tr><th>Variable</th><th>Type</th><th>Bounds / Values</th></tr></thead>"
            "<tbody>" + "".join(var_rows) + "</tbody></table></div>"
        )
    else:
        var_section = '<div class="card"><h2>Variable Bounds</h2><p>No variables analyzed.</p></div>'

    omega2_section = ""
    if omega2_data and omega2_data.get("nodes"):
        nodes = omega2_data["nodes"]
        sorted_nodes = sorted(
            nodes.items(), key=lambda kv: kv[1].get("state_width", 0), reverse=True
        )

        def _sw_cls(sw):
            return "err" if sw >= 1000 else "warn" if sw >= 100 else "ok"

        node_rows = []
        for label, nd in sorted_nodes:
            sw = nd.get("state_width", 0)
            sat = "⚠ Saturated" if nd.get("state_width_saturated") else "—"
            ec = nd.get("edit_cardinality", 0)
            node_rows.append(
                f"<tr><td><code>{html.escape(label)}</code></td>"
                f'<td class="{_sw_cls(sw)}">{sw:,}</td>'
                f"<td>{html.escape(sat)}</td>"
                f"<td>{ec}</td></tr>"
            )
        o2_ver = html.escape(str(omega2_data.get("omega_version", "1.1.0-omega-2")))
        omega2_section = (
            f'<div class="card"><h2>State Complexity by Label '
            f'<span style="font-size:0.72rem;opacity:0.6;">Ω-2 engine v{o2_ver}</span></h2>'
            "<p style='margin-bottom:8px;font-size:0.82rem;'>State width = distinct game states possible at that label. "
            "Green &lt;100 · yellow ≥100 · red ≥1000.</p>"
            "<table><thead><tr><th>Label</th><th>State Width</th><th>Saturated</th><th>Edit Cardinality</th></tr></thead>"
            "<tbody>" + "".join(node_rows) + "</tbody></table></div>"
        )

    if combos:
        combo_items = "".join(
            f"<li><code>{html.escape(str(c.get('vars', ['?', '?'])[0]))}="
            f"{html.escape(str(c.get('combo', ['?', '?'])[0]))}</code> + "
            f"<code>{html.escape(str(c.get('vars', ['?', '?'])[1]))}="
            f"{html.escape(str(c.get('combo', ['?', '?'])[1]))}</code></li>"
            for c in combos[:20]
        )
        extra = (
            f"<p style='margin-top:6px;font-size:0.8rem;'>… and {len(combos) - 20} more.</p>"
            if len(combos) > 20
            else ""
        )
        combo_section = (
            '<div class="card"><h2>Impossible Combination Candidates</h2>'
            "<p style='margin-bottom:8px;font-size:0.82rem;'>State pairs that never co-occurred in observed path endings (heuristic).</p>"
            f"<ul>{combo_items}</ul>{extra}</div>"
        )
    else:
        combo_section = '<div class="card"><h2>Impossible Combination Candidates</h2><p class="ok">✓ None detected.</p></div>'

    body = (
        f"<h1>BranchPy OMEGA — {project_name}</h1>\n"
        f'<p class="meta">State-Space Analysis · Version {omega_ver}</p>\n'
        f'<div class="card">{stats_grid}{limits_banner}</div>\n'
        f"{omega2_section}\n"
        f"{var_section}\n"
        f"{combo_section}\n"
    )

    page = _html_wrap(f"OMEGA — {project_name} · BranchPy", body)
    target = out_path or _default_html_path(project_root, "omega")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(page, encoding="utf-8")
    return target


# ---------------------------------------------------------------------------
# Media HTML
# ---------------------------------------------------------------------------


def generate_media_html(
    media_data: Dict[str, Any],
    project_root: Path,
    out_path: Optional[Path] = None,
) -> Path:
    """Generate a review-oriented media validation HTML report."""
    import re
    from urllib.parse import quote

    project_root = project_root.resolve()
    project_name = html.escape(project_root.name)
    summary = media_data.get("summary", {})
    tiers = media_data.get("tiers", {})
    rename_hints = media_data.get("rename_hints", [])

    used_items = tiers.get("used", [])
    cleanup_candidates = tiers.get("cleanup_candidates", [])
    needs_review = tiers.get("needs_review", [])
    dynamic_risk = tiers.get("dynamic_risk", [])
    protected_items = tiers.get("protected", [])

    n_protected = summary.get("protected", 0)
    n_safe_cleanup = summary.get("safe_cleanup", len(cleanup_candidates))
    n_review = len(needs_review)
    n_runtime_risk = len(dynamic_risk)
    cleanup_cls = "warn" if n_safe_cleanup > 0 else "ok"
    review_cls = "err" if n_review > 0 else "ok"
    review_card_cls = "" if n_review > 0 else " summary"

    banner = ""
    if n_protected:
        banner = (
            '<div class="card" style="border-left:4px solid var(--ok); background:rgba(74,222,128,.05);">'
            '<strong style="color:var(--ok);">&#9432; Ren\'Py GUI Protection Active</strong>'
            f'<p class="meta" style="margin-top:4px;"><strong>{n_protected}</strong> asset(s) '
            "are in Ren'Py-managed directories (gui/, fonts/, screens/). "
            "These are referenced dynamically by the Ren'Py framework and must not be deleted "
            "based on script scanning alone. They appear as "
            '<span class="tag ok">protected</span> in the table below.</p>'
            "</div>"
        )

    def _absolute_item_path(raw_path: str) -> str:
        if not raw_path:
            return ""
        p = Path(str(raw_path))
        if p.is_absolute():
            return str(p)
        candidates = [
            (project_root / p).resolve(),
            (project_root / "game" / p).resolve(),
            (project_root / "assets" / p).resolve(),
        ]
        for candidate in candidates:
            if candidate.exists():
                return str(candidate)
        return str((project_root / "game" / p).resolve())

    def _vscode_href(abs_path: str) -> str:
        if not abs_path:
            return ""
        return f"vscode://file/{quote(abs_path.replace(chr(92), '/'), safe='/:')}"

    def _reference_target(ref: str) -> tuple[str, Optional[int]]:
        if not ref:
            return "", None
        match = re.match(r"^(.*):(\d+)$", ref)
        if not match:
            return "", None
        ref_path = match.group(1)
        ref_line = int(match.group(2))
        return ref_path, ref_line

    def _compact_ref(ref: str) -> str:
        if not ref:
            return ""
        ref_path, ref_line = _reference_target(ref)
        if not ref_path:
            return html.escape(ref)
        short = (
            f"{Path(ref_path).name}:{ref_line}"
            if ref_line is not None
            else Path(ref_path).name
        )
        return (
            f'<span title="{html.escape(ref, quote=True)}">{html.escape(short)}</span>'
        )

    def _item_open_target(item: dict) -> tuple[str, Optional[int]]:
        item_path = _absolute_item_path(str(item.get("path", "")))
        if item_path and Path(item_path).exists():
            return item_path, None
        ref_path, ref_line = _reference_target(str(item.get("ref", "")))
        if ref_path and Path(ref_path).exists():
            return ref_path, ref_line
        return "", None

    def _ext_chip(path: str) -> str:
        dot = path.rfind(".")
        ext = path[dot + 1 :].lower() if dot >= 0 else "?"
        return f'<span class="ext-chip">{html.escape(ext)}</span>'

    def _compact_path(path: str, max_len: int = 58) -> str:
        p = str(path or "")
        if len(p) <= max_len:
            return p
        return "..." + p[-(max_len - 3) :]

    def _path_cell(path_raw: str) -> str:
        compact = html.escape(_compact_path(path_raw))
        full = html.escape(path_raw, quote=True)
        return (
            f'<span class="path-compact" title="{full}"><code>{compact}</code></span>'
        )

    def _display_reason(reason: str) -> str:
        raw = str(reason or "").strip().lower()
        mapping = {
            "direct file reference": "Matched by direct file reference",
            "resolved from ren'py image tag": "Matched by Ren'Py image tag",
            "ren'py gui system": "Protected by Ren'Py GUI framework",
            "font assets": "Protected by Ren'Py font framework",
            "ui screen assets": "Protected by Ren'Py screen framework",
        }
        return mapping.get(raw, str(reason or ""))

    def _open_button(
        abs_path: str, label: str = "VS Code", line: Optional[int] = None
    ) -> str:
        if not abs_path:
            return '<span style="white-space:nowrap; display:inline-flex; gap:4px; opacity:.3;">&#10697; &#128194;</span>'
        href = html.escape(_vscode_href(abs_path), quote=True)
        if line:
            href += f":{line}:1"
        file_href = html.escape("file:///" + abs_path.replace(chr(92), "/"), quote=True)
        return (
            '<span style="white-space:nowrap; display:inline-flex; gap:4px;">'
            f'<a href="{href}" target="_blank" rel="noopener noreferrer" '
            f'class="action-btn" title="Open in editor">&#10697;</a>'
            f'<a href="{file_href}" target="_blank" rel="noopener noreferrer" '
            f'class="action-btn" title="Open file directly">&#128194;</a>'
            "</span>"
        )

    def _render_path_table(
        items: list[dict],
        title: str,
        badge_class: str,
        *,
        open_by_default: bool = True,
        summary_note: str = "",
    ) -> str:
        if not items:
            empty_msg = "No items."
            if "Needs Review" in title:
                empty_msg = "No missing referenced assets detected."
            elif "Cleanup" in title:
                empty_msg = "No cleanup candidates found."
            elif "Dynamic Risk" in title:
                empty_msg = "No runtime-resolved risk paths detected."
            return f'<div class="card"><h2>{html.escape(title)}</h2><p class="meta">{html.escape(empty_msg)}</p></div>'

        rows = []
        for it in items[:600]:
            path_raw = str(it.get("path", ""))
            path_val = _path_cell(path_raw)
            category = html.escape(str(it.get("category", "other")))
            confidence = html.escape(str(it.get("confidence", "definite")))
            ref = _compact_ref(str(it.get("ref", "")))
            reason = html.escape(_display_reason(str(it.get("reason", ""))))
            open_path, open_line = _item_open_target(it)
            rows.append(
                "<tr>"
                f"<td>{path_val}{_ext_chip(path_raw)}</td>"
                f'<td><span class="tag {badge_class}">{category}</span></td>'
                f"<td style='color:var(--muted); font-size:0.8rem;'>{reason}</td>"
                f"<td style='font-size:0.78rem;'>{ref}</td>"
                f"<td>{_open_button(open_path, 'VS Code', open_line)}</td>"
                "</tr>"
            )

        details_open = " open" if open_by_default else ""
        summary_note_html = (
            f"<p class='meta' style='margin:8px 0 10px;'>{html.escape(summary_note)}</p>"
            if summary_note
            else ""
        )

        return (
            f'<details class="card"{details_open}>'
            f"<summary>{html.escape(title)} ({len(items)})</summary>"
            '<div class="card-body">'
            f"{summary_note_html}"
            "<table>"
            "<thead><tr><th>Path</th><th>Category</th><th>Reason</th><th>Reference</th><th>Action</th></tr></thead>"
            "<tbody>" + "".join(rows) + "</tbody>"
            "</table>"
            "</div>"
            "</details>"
        )

    def _render_protected_grouped(items: list[dict]) -> str:
        if not items:
            return _render_path_table(
                items, "Protected Assets", "ok", open_by_default=False
            )

        groups: dict[str, list[dict]] = {}
        for it in items:
            p = str(it.get("path", ""))
            parent = str(Path(p).parent).replace("\\", "/")
            if parent in ("", "."):
                parent = "(root)"
            groups.setdefault(parent, []).append(it)

        rows: list[str] = []
        for group in sorted(groups.keys()):
            rows.append(
                f"<tr class='group-head'><td colspan='5'>{html.escape(group)}/ ({len(groups[group])})</td></tr>"
            )
            for it in groups[group][:600]:
                path_raw = str(it.get("path", ""))
                category = html.escape(str(it.get("category", "other")))
                reason = html.escape(_display_reason(str(it.get("reason", ""))))
                ref = _compact_ref(str(it.get("ref", "")))
                open_path, open_line = _item_open_target(it)
                rows.append(
                    "<tr>"
                    f"<td>{_path_cell(path_raw)}{_ext_chip(path_raw)}</td>"
                    f'<td><span class="tag ok">{category}</span></td>'
                    f"<td style='color:var(--muted); font-size:0.8rem;'>{reason}</td>"
                    f"<td style='font-size:0.78rem;'>{ref}</td>"
                    f"<td>{_open_button(open_path, 'VS Code', open_line)}</td>"
                    "</tr>"
                )

        return (
            '<details class="card">'
            f"<summary>Protected Assets ({len(items)})</summary>"
            '<div class="card-body">'
            "<p class='meta' style='margin:8px 0 10px;'>Framework-managed assets detected in gui/, fonts/, or screens/; not candidates for deletion.</p>"
            "<table>"
            "<thead><tr><th>Path</th><th>Category</th><th>Reason</th><th>Reference</th><th>Action</th></tr></thead>"
            "<tbody>" + "".join(rows) + "</tbody>"
            "</table>"
            "</div>"
            "</details>"
        )

    hints_section = ""
    if rename_hints:
        hint_rows = []
        for h in rename_hints[:120]:
            miss = str(h.get("missing", ""))
            sugg = str(h.get("suggested", ""))
            score = h.get("score", 0.0)
            sugg_path = _absolute_item_path(sugg)
            hint_rows.append(
                "<tr>"
                f"<td><code>{html.escape(miss)}</code></td>"
                f"<td><code>{html.escape(sugg)}</code></td>"
                f"<td>{float(score):.2f}</td>"
                f"<td>{_open_button(sugg_path if Path(sugg_path).exists() else '', 'Open')}</td>"
                "</tr>"
            )
        hints_section = (
            '<details class="card">'
            "<summary>Rename-Pair Hints</summary>"
            '<div class="card-body">'
            "<table>"
            "<thead><tr><th>Missing</th><th>Likely Match</th><th>Similarity</th><th>Action</th></tr></thead>"
            "<tbody>" + "".join(hint_rows) + "</tbody>"
            "</table>"
            "</div>"
            "</details>"
        )

    all_items = []
    for tier_name, tier_items in (
        ("used", used_items),
        ("protected", protected_items),
        ("cleanup", cleanup_candidates),
        ("review", needs_review),
        ("risk", dynamic_risk),
    ):
        for it in tier_items:
            x = dict(it)
            x["tier"] = tier_name
            x["reason"] = _display_reason(str(it.get("reason", "")))
            open_path, open_line = _item_open_target(x)
            x["absolute_path"] = _absolute_item_path(str(it.get("path", "")))
            x["open_path"] = open_path
            x["open_line"] = open_line
            all_items.append(x)
    n_all = len(all_items)
    cards = (
        '<div class="grid">'
        f'<div class="stat filterable summary" data-tier="all"><div class="val info">{n_all}</div><div class="lbl">All</div></div>'
        f'<div class="stat filterable" data-tier="used"><div class="val ok">{summary.get("referenced", 0)}</div><div class="lbl">Used</div></div>'
        f'<div class="stat filterable" data-tier="protected"><div class="val ok">{n_protected}</div><div class="lbl">Protected</div></div>'
        f'<div class="stat filterable" data-tier="risk"><div class="val warn">{summary.get("dynamic_risk", 0)}</div><div class="lbl">Runtime Risk</div></div>'
        f'<div class="stat filterable" data-tier="cleanup"><div class="val {cleanup_cls}">{n_safe_cleanup}</div><div class="lbl">Cleanup Candidate</div></div>'
        f'<div class="stat filterable{review_card_cls}" data-tier="review"><div class="val {review_cls}">{n_review}</div><div class="lbl">Needs Review</div></div>'
        "</div>"
    )

    triage_hint = ""
    if n_review > 0:
        triage_hint = (
            '<div class="card" style="border-left:4px solid var(--accent); padding:10px 14px;">'
            '<strong style="color:var(--accent);">What to check first</strong>'
            '<div class="meta" style="margin-top:4px; margin-bottom:0;">'
            "1) Review missing items first. &nbsp; 2) Then inspect runtime risk. &nbsp; 3) Cleanup candidates last."
            "</div>"
            "</div>"
        )
    elif n_runtime_risk > 0 or n_safe_cleanup > 0:
        triage_hint = (
            '<div class="card" style="border-left:4px solid var(--accent); padding:10px 14px;">'
            '<strong style="color:var(--accent);">What to check first</strong>'
            '<div class="meta" style="margin-top:4px; margin-bottom:0;">'
            "No missing referenced assets detected. Start with runtime risk, then review cleanup candidates."
            "</div>"
            "</div>"
        )
    all_items_json = json.dumps(all_items, ensure_ascii=False)
    project_root_json = json.dumps(str(project_root), ensure_ascii=False)

    body = f"""
<h1>BranchPy Media Validation — {project_name}</h1>
<p class="meta">{html.escape(str(project_root))}</p>

{banner}
{triage_hint}
<div class="card">{cards}</div>

<div class="card" style="display:flex; gap:12px; align-items:center; flex-wrap:wrap;">
    <label>Tier:
        <select id="tier-filter">
            <option value="all">All</option>
            <option value="used">Used</option>
            <option value="protected">Protected</option>
            <option value="cleanup">Cleanup Candidate</option>
            <option value="review">Needs Review</option>
            <option value="risk">Runtime Risk</option>
        </select>
    </label>
    <label style="white-space:nowrap; cursor:pointer;">
        <input type="checkbox" id="safe-only-check"> Cleanup candidates only
    </label>
    <label>Search path:
        <input id="path-filter" type="text" placeholder="textures/bg_..." style="padding:6px 8px; min-width:260px; background:#0f1117; color:#e4e6f0; border:1px solid #2a2d3a; border-radius:4px;">
    </label>
    <label>Sort:
        <select id="sort-sel">
            <option value="tier">Tier</option>
            <option value="path">Path</option>
            <option value="category">Category</option>
            <option value="ext">Extension</option>
        </select>
    </label>
    <span class="meta"><span id="filter-count"></span></span>
    <span class="toolbar-utility">
        <button id="toggle-all-btn" style="padding:5px 10px; border-radius:5px; border:1px solid #2a2d3a; background:#1a1d27; color:#e4e6f0; cursor:pointer; font-size:0.8rem;">Collapse all</button>
        <span class="hint-mini" title="&#10697; Open in editor, &#128194; Open file directly. Click a row to inspect.">&#9432;</span>
    </span>
</div>

<div style="display:flex; gap:12px; align-items:flex-start; min-height:0; margin-bottom:16px;">
    <details class="card" open style="flex:1 1 0; min-width:0; margin-bottom:0;">
        <summary>Filtered Path List</summary>
        <div class="card-body">
        <table>
              <thead><tr><th>Tier</th><th>Path</th><th>Category</th><th>Reason</th><th>Action</th></tr></thead>
            <tbody id="filtered-body"></tbody>
        </table>
        </div>
    </details>
    <div style="flex:0 0 300px; display:flex; flex-direction:column; gap:10px; position:sticky; top:16px; max-height:calc(100vh - 32px); overflow-y:visible;">
        <details class="card detail-card" open style="margin-bottom:0; overflow:hidden;">
            <summary style="flex-shrink:0;">Item Details</summary>
            <div id="media-empty" class="meta" style="padding:10px 14px;">Select an item to view why it was classified this way, preview it, and open it.</div>
            <div id="media-detail-content" style="display:none; flex:1; overflow:hidden; flex-direction:column;">
                <div class="detail-zone-head">
                    <div style="display:flex; gap:8px; align-items:center; padding:8px 0 4px;">
                        <div id="media-tier"></div>
                        <div id="media-reason-summary" class="reason-summary"></div>
                    </div>
                    <div id="media-path-display" class="path-display" title="" onclick="navigator.clipboard&&navigator.clipboard.writeText(this.dataset.full||this.textContent)"></div>
                    <dl class="meta-grid">
                        <dt>Type</dt><dd id="media-category"></dd>
                        <dt>Confidence</dt><dd id="media-confidence"></dd>
                    </dl>
                    <div id="media-thumb-wrap" style="display:none; margin:6px 0;">
                        <img id="media-thumb" alt="preview" style="max-width:100%; max-height:96px; object-fit:contain; border-radius:4px; border:1px solid var(--border); cursor:zoom-in;" onclick="this.style.maxHeight=this.style.maxHeight==='96px'?'260px':'96px';">
                    </div>
                </div>
                <!-- Scrollable references zone -->
                <div class="detail-zone-refs" id="media-refs-zone" style="display:none;">
                    <div class="refs-label">Script references</div>
                    <ul id="media-refs-list" class="refs-list" style="max-height:none;"></ul>
                </div>
                <!-- Pinned action footer -->
                <div class="detail-zone-foot">
                    <a id="media-open-file" target="_blank" rel="noopener noreferrer" class="action-btn" title="Open in editor" style="opacity:.5; pointer-events:none;">&#10697;</a>
                    <a id="media-open-native" target="_blank" rel="noopener noreferrer" class="action-btn" title="Open file directly" style="opacity:.5; pointer-events:none;">&#128194;</a>
                </div>
            </div>
        </details>
        <details class="card" open style="margin-bottom:0; font-size:0.78rem; color:var(--muted);">
            <summary>Legend</summary>
            <div class="card-body">
            <div style="margin-bottom:6px;"><span class="tag ok">used</span> matched to an on-disk asset</div>
            <div style="margin-bottom:6px;"><span class="tag ok">protected</span> protected by Ren&apos;Py framework behavior</div>
            <div style="margin-bottom:6px;"><span class="tag warn">cleanup candidate</span> no static reference found — review before deleting</div>
            <div style="margin-bottom:6px;"><span class="tag err">needs review</span> referenced but missing from disk</div>
            <div><span class="tag info">runtime risk</span> template / variable path — resolves at runtime</div>
            </div>
        </details>
    </div>
</div>

{_render_path_table(used_items, "Used Assets", "ok")}
{_render_protected_grouped(protected_items)}
{_render_path_table(cleanup_candidates, "Cleanup Candidates", "warn")}
{_render_path_table(needs_review, "Needs Review (Missing from Disk)", "err")}
{_render_path_table(dynamic_risk, "Runtime Risk (Template / Variable Paths)", "info")}
{hints_section}

<script>
(function() {{
    var items = {all_items_json};
    var projectRoot = {project_root_json};
    var tierSel = document.getElementById('tier-filter');
    var pathInput = document.getElementById('path-filter');
    var body = document.getElementById('filtered-body');
    var count = document.getElementById('filter-count');
    var safeOnlyCheck = document.getElementById('safe-only-check');
    var sortSel = document.getElementById('sort-sel');
    var statCards = Array.prototype.slice.call(document.querySelectorAll('.stat.filterable'));
    var activeCardTier = null;
    var selectedIdx = null;

    function sortItems(arr, key) {{
        arr = arr.slice();
        if (key === 'path') return arr.sort(function(a,b) {{ return String(a.path||'').localeCompare(String(b.path||'')); }});
        if (key === 'category') return arr.sort(function(a,b) {{ return String(a.category||'').localeCompare(String(b.category||'')); }});
        if (key === 'ext') return arr.sort(function(a,b) {{
            var ea = String(a.path||'').split('.').pop();
            var eb = String(b.path||'').split('.').pop();
            return ea.localeCompare(eb);
        }});
        var tierOrder = {{used:0, protected:1, cleanup:2, review:3, risk:4}};
        return arr.sort(function(a,b) {{
            var ta = tierOrder[String(a.tier||'')] !== undefined ? tierOrder[String(a.tier||'')] : 9;
            var tb = tierOrder[String(b.tier||'')] !== undefined ? tierOrder[String(b.tier||'')] : 9;
            return ta !== tb ? ta - tb : String(a.path||'').localeCompare(String(b.path||''));
        }});
    }}

    function makeActionIcons(item) {{
        var path = String(item.open_path || item.absolute_path || item.path || '');
        var normalized = path ? normalizePath(path) : '';
        var vsUri = path ? toVscodeUri(path, item.open_line || null) : '';
        var editorBtn = vsUri
            ? '<a href="' + vsUri + '" target="_blank" rel="noopener noreferrer" class="action-btn" title="Open in editor" onclick="event.stopPropagation();">&#10697;</a>'
            : '<span class="action-btn" title="No editor path available" style="opacity:.3; pointer-events:none;">&#10697;</span>';
        var fileBtn = normalized
            ? '<a href="file:///' + normalized + '" target="_blank" rel="noopener noreferrer" class="action-btn" title="Open file directly" onclick="event.stopPropagation();">&#128194;</a>'
            : '<span class="action-btn" title="File path unavailable" style="opacity:.3; pointer-events:none;">&#128194;</span>';
        return '<span style="display:inline-flex; gap:4px;">' + editorBtn + fileBtn + '</span>';
    }}

    function slashify(value) {{
        return String(value || '').split(String.fromCharCode(92)).join('/');
    }}

    function trimLeadingSlashes(value) {{
        var out = String(value || '');
        while (out.charAt(0) === '/') out = out.slice(1);
        return out;
    }}

    function trimTrailingSlashes(value) {{
        var out = String(value || '');
        while (out.charAt(out.length - 1) === '/') out = out.slice(0, -1);
        return out;
    }}

    function normalizePath(path) {{
        var raw = String(path || '');
        if (!raw) return '';
        var slash = slashify(raw);
        var isWindowsAbs = slash.length > 2 && /^[A-Za-z]$/.test(slash.charAt(0)) && slash.charAt(1) === ':' && slash.charAt(2) === '/';
        if (isWindowsAbs || slash.indexOf('/') === 0) return slash;
        var base = trimTrailingSlashes(slashify(projectRoot || ''));
        var rel = trimLeadingSlashes(slash);
        return base + '/' + rel;
    }}

    function toVscodeUri(path, line) {{
        var normalized = normalizePath(path);
        if (!normalized) return '';
        var suffix = line ? ':' + String(line) + ':1' : '';
        return 'vscode://file/' + encodeURI(normalized) + suffix;
    }}

    function setOpenLink(path, line) {{
        var link = document.getElementById('media-open-file');
        var nat = document.getElementById('media-open-native');
        if (!link) return;
        var href = toVscodeUri(path, line);
        if (!href) {{
            link.removeAttribute('href');
            link.style.opacity = '.5';
            link.style.pointerEvents = 'none';
            link.title = 'No editor path available';
            if (nat) {{ nat.removeAttribute('href'); nat.style.opacity = '.5'; nat.style.pointerEvents = 'none'; nat.title = 'File path unavailable'; }}
            return;
        }}
        link.href = href;
        link.style.opacity = '1';
        link.style.pointerEvents = 'auto';
        link.title = 'Open in editor';
        if (nat) {{
            var normalized = normalizePath(path);
            nat.href = normalized ? 'file:///' + normalized : '#';
            nat.style.opacity = normalized ? '1' : '.5';
            nat.style.pointerEvents = normalized ? 'auto' : 'none';
            nat.title = normalized ? 'Open file directly' : 'File path unavailable';
        }}
    }}

    function syncCardHighlight() {{
        for (var i = 0; i < statCards.length; i++) {{
            var cardTier = statCards[i].getAttribute('data-tier');
            statCards[i].classList.toggle('active', cardTier === activeCardTier);
        }}
    }}

    function renderDetails(item) {{
        item = item || {{}};
        var empty = document.getElementById('media-empty');
        var content = document.getElementById('media-detail-content');
        var pathDisplay = document.getElementById('media-path-display');

        if (empty) empty.style.display = 'none';
        if (content) {{ content.style.display = 'flex'; content.style.flexDirection = 'column'; }}

        // Path header — truncated display, full path in title + data attr for clipboard
        var relPath = String(item.path || '');
        var displayPath = relPath;
        if (displayPath && displayPath.indexOf('/') !== 0 && displayPath.indexOf('game/') !== 0 && displayPath.indexOf('assets/') !== 0) {{
            displayPath = 'game/' + displayPath;
        }}
        var shortPath = displayPath.length > 58 ? '...' + displayPath.slice(-55) : displayPath;
        var fullPath = String(item.absolute_path || item.open_path || relPath || '');
        if (pathDisplay) {{
            pathDisplay.textContent = shortPath;
            pathDisplay.title = (fullPath || displayPath) + ' (click to copy full path)';
            pathDisplay.dataset.full = fullPath || displayPath;
        }}

        // Compact metadata
        var tierBadgeMap = {{used:'ok', protected:'ok', cleanup:'warn', review:'err', risk:'info'}};
        var tierEl = document.getElementById('media-tier');
        var tier = String(item.tier || '');
        if (tierEl) tierEl.innerHTML = '<span class="tag ' + (tierBadgeMap[tier]||'info') + '">' + tier + '</span>';
        document.getElementById('media-category').textContent = String(item.category || 'other');
        document.getElementById('media-confidence').textContent = String(item.confidence || '');
        var reason = String(item.reason || '');
        var reasonSummary = document.getElementById('media-reason-summary');
        if (reasonSummary) reasonSummary.textContent = reason || 'No reason provided';

        // Open link
        setOpenLink(item.open_path || item.absolute_path || item.path || '', item.open_line || null);

        // Script references evidence panel — show all (scrollable)
        var refsZone = document.getElementById('media-refs-zone');
        var refsList = document.getElementById('media-refs-list');
        var allRefs = Array.isArray(item.all_refs) ? item.all_refs : (item.ref ? [item.ref] : []);
        if (refsZone && refsList) {{
            if (allRefs.length > 0) {{
                refsList.innerHTML = allRefs.map(function(r) {{
                    return '<li>' + String(r || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;') + '</li>';
                }}).join('');
                refsZone.style.display = 'block';
            }} else {{
                refsList.innerHTML = '';
                refsZone.style.display = 'none';
            }}
        }}

        // Thumbnail (image assets only)
        var imgExts = ['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'svg', 'avif'];
        var pathLc = fullPath.toLowerCase();
        var dotIdx = pathLc.lastIndexOf('.');
        var ext = dotIdx >= 0 ? pathLc.slice(dotIdx + 1) : '';
        var thumbWrap = document.getElementById('media-thumb-wrap');
        var thumb = document.getElementById('media-thumb');
        var absPath = String(item.absolute_path || item.path || '');
        if (imgExts.indexOf(ext) >= 0 && absPath) {{
            thumb.src = 'file:///' + slashify(absPath);
            thumb.style.maxHeight = '96px';
            thumbWrap.style.display = 'block';
        }} else {{
            thumb.src = '';
            thumbWrap.style.display = 'none';
        }}
    }}

    function render() {{
        var tier = activeCardTier || ((safeOnlyCheck && safeOnlyCheck.checked) ? 'cleanup' : tierSel.value);
        var q = (pathInput.value || '').toLowerCase();
        var rows = [];
        var shown = 0;
        var selectedVisible = false;
        var tierBadge = {{used:'ok', protected:'ok', cleanup:'warn', review:'err', risk:'info'}};
        var sortKey = sortSel ? sortSel.value : 'tier';

        var filtered = [];
        for (var i = 0; i < items.length; i++) {{
            var it = items[i] || {{}};
            var path = String(it.path || '');
            var t = String(it.tier || '');
            if (tier !== 'all' && t !== tier) continue;
            if (q && path.toLowerCase().indexOf(q) === -1) continue;
            filtered.push({{item: it, idx: i}});
            if (filtered.length >= 1200) break;
        }}

        var sorted = sortItems(filtered.map(function(x) {{ return Object.assign({{_idx: x.idx}}, x.item); }}), sortKey);

        for (var j = 0; j < sorted.length; j++) {{
            var it = sorted[j];
            var i = it._idx;
            var path = String(it.path || '');
            var t = String(it.tier || '');
            shown += 1;
            var badgeCls = tierBadge[t] || 'info';
            var ext = path.split('.').pop().toLowerCase();
            var extHtml = ext ? '<span class="ext-chip">' + ext + '</span>' : '';
            var rowCls = 'media-row' + (i === selectedIdx ? ' row-selected' : '');
            if (i === selectedIdx) selectedVisible = true;
            rows.push('<tr class="' + rowCls + '" data-idx="' + i + '">' +
                '<td><span class="tag ' + badgeCls + '">' + t + '</span></td>' +
                '<td><code>' + path + '</code>' + extHtml + '</td>' +
                '<td>' + String(it.category || 'other') + '</td>' +
                '<td style="color:var(--muted); font-size:0.8rem;">' + String(it.reason || '') + '</td>' +
                '<td>' + makeActionIcons(it) + '</td>' +
            '</tr>');
        }}

        if (shown === 0) {{
            rows.push('<tr><td colspan="5" style="text-align:center; color:var(--muted); padding:14px;">No items match the current filters.</td></tr>');
        }}

        body.innerHTML = rows.join('');
        count.textContent = shown + ' item(s) shown';
        if (!selectedVisible) selectedIdx = null;
        syncCardHighlight();
    }}

    body.addEventListener('click', function(evt) {{
        if (evt.target.closest('.action-btn')) return;
        var row = evt.target.closest('tr[data-idx]');
        if (!row) return;
        var idx = Number(row.getAttribute('data-idx'));
        if (!Number.isNaN(idx) && items[idx]) {{
            selectedIdx = idx;
            var prev = body.querySelector('tr.row-selected');
            if (prev) prev.classList.remove('row-selected');
            row.classList.add('row-selected');
            renderDetails(items[idx]);
        }}
    }});

    for (var i = 0; i < statCards.length; i++) {{
        statCards[i].addEventListener('click', function() {{
            var tier = this.getAttribute('data-tier');
            if (activeCardTier === tier) {{
                activeCardTier = null;
            }} else {{
                activeCardTier = tier;
                if (safeOnlyCheck) safeOnlyCheck.checked = false;
                tierSel.value = tier || 'all';
            }}
            render();
        }});
    }}

    var toggleAllBtn = document.getElementById('toggle-all-btn');
    if (toggleAllBtn) {{
        var _allCollapsed = false;
        toggleAllBtn.addEventListener('click', function() {{
            _allCollapsed = !_allCollapsed;
            this.textContent = _allCollapsed ? 'Expand all' : 'Collapse all';
            var allD = document.querySelectorAll('details');
            for (var di = 0; di < allD.length; di++) {{
                if (_allCollapsed) allD[di].removeAttribute('open');
                else allD[di].setAttribute('open', '');
            }}
        }});
    }}

    tierSel.addEventListener('change', function() {{ activeCardTier = null; render(); }});
    pathInput.addEventListener('input', render);
    if (sortSel) sortSel.addEventListener('change', render);
    if (safeOnlyCheck) safeOnlyCheck.addEventListener('change', function() {{ activeCardTier = null; render(); }});
    render();
}})();
</script>
"""

    page = _html_wrap(f"Media Validation — {project_name} · BranchPy", body)

    target = out_path or _default_html_path(project_root, "media")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(page, encoding="utf-8")
    return target


# ---------------------------------------------------------------------------
# Flowchart HTML
# ---------------------------------------------------------------------------


def generate_flowchart_html(
    unified_data: Dict[str, Any],
    project_root: Path,
    out_path: Optional[Path] = None,
) -> Path:
    """
    Generate a self-contained flowchart HTML report with embedded Cytoscape.js.

    Parameters
    ----------
    unified_data : dict
        The unified report data containing collapsed_graph.nodes and .edges.
    project_root : Path
        Project root directory.
    out_path : Path | None
        Override output path.

    Returns
    -------
    Path
        Path where HTML was written.
    """
    project_name = html.escape(project_root.name)

    graph = unified_data.get("collapsed_graph", {})
    nodes_raw = graph.get("nodes", [])
    edges_raw = graph.get("edges", [])
    graph_analysis = graph.get("analysis", {}) if isinstance(graph, dict) else {}
    unreachable_count = len(graph_analysis.get("unreachable_nodes", []))
    terminal_end_count = len(graph_analysis.get("terminal_end_nodes", []))
    dead_end_count = len(graph_analysis.get("dead_end_nodes", []))
    entry_count = len(graph_analysis.get("entry_nodes", []))
    semantic_counts = (
        graph_analysis.get("semantic_summary", {}).get("counts", {})
        if isinstance(graph_analysis, dict)
        else {}
    )
    cluster_count = int(semantic_counts.get("cluster_count", 0))
    backbone_length = int(semantic_counts.get("backbone_length", 0))
    branch_bundle_count = int(semantic_counts.get("branch_bundle_count", 0))
    terminal_bundle_count = int(semantic_counts.get("terminal_bundle_count", 0))
    merge_corridor_count = int(semantic_counts.get("merge_corridor_count", 0))
    crossing_count_before_cleanup = int(
        semantic_counts.get("crossing_count_before_cleanup", 0)
    )
    crossing_count = int(semantic_counts.get("crossing_count", 0))
    normalized_crossings_before_cleanup = float(
        semantic_counts.get("normalized_crossings_before_cleanup", 0.0)
    )
    normalized_crossings = float(semantic_counts.get("normalized_crossings", 0.0))
    edge_overlap_count_before_cleanup = int(
        semantic_counts.get("edge_overlap_count_before_cleanup", 0)
    )
    edge_overlap_count = int(semantic_counts.get("edge_overlap_count", 0))
    local_nudge_count = int(semantic_counts.get("local_nudge_count", 0))
    reordered_branch_hub_count = int(
        semantic_counts.get("reordered_branch_hub_count", 0)
    )

    n_nodes = len(nodes_raw)

    component_ids = sorted(
        {
            str(node.get("component_id") or "c0000")
            for node in nodes_raw
            if node.get("id") is not None
        }
    )
    component_rank = {
        component_id: index for index, component_id in enumerate(component_ids)
    }
    n_components = len(component_ids)
    # Default view: for large graphs use a condensed abstraction level by default.
    # Priority: By Component if multiple components exist; By Filename otherwise.
    # Threshold: > 200 nodes triggers condensed default.
    if n_nodes > 200 and n_components > 1:
        default_view = "component"
    elif n_nodes > 200:
        default_view = "file"
    else:
        default_view = "full"

    lane_members: dict[tuple[str, str], list[str]] = {}
    for node in nodes_raw:
        node_id = str(node.get("id", ""))
        if not node_id:
            continue
        component_id = str(node.get("component_id") or "c0000")
        cluster_lane = str(node.get("cluster_lane") or "narrative")
        lane_members.setdefault((component_id, cluster_lane), []).append(node_id)

    lane_index_by_node: dict[str, int] = {}
    for lane_key, lane_nodes in lane_members.items():
        for lane_index, node_id in enumerate(sorted(lane_nodes)):
            lane_index_by_node[f"{lane_key[0]}::{lane_key[1]}::{node_id}"] = lane_index

    # Build Cytoscape elements
    cy_elements = []
    for n in nodes_raw:
        nid = str(n.get("id", n.get("label", "")))
        label = str(n.get("label", nid))
        kind = str(n.get("type", n.get("kind", "node")))
        file_path = str(n.get("file", ""))
        line = n.get("line")
        line_start = n.get("line_start")
        line_end = n.get("line_end")
        node_meta = n.get("meta", {})
        is_reachable = bool(n.get("is_reachable", True))
        terminal_end = bool(n.get("terminal_end", False))
        dead_end = bool(n.get("dead_end", False))
        component_id = str(n.get("component_id") or "c0000")
        cluster_lane = str(n.get("cluster_lane") or "narrative")
        cluster_anchor = n.get("cluster_anchor", {})
        layout_position = n.get("layout_position", {})
        if not isinstance(cluster_anchor, dict):
            cluster_anchor = {}
        if not isinstance(layout_position, dict):
            layout_position = {}
        fallback_x = component_rank.get(component_id, 0) * 640
        base_x = int(cluster_anchor.get("x", fallback_x))
        base_y = int(cluster_anchor.get("y", 0)) + (
            component_rank.get(component_id, 0) * 420
        )
        slot_key = f"{component_id}::{cluster_lane}::{nid}"
        slot_index = lane_index_by_node.get(slot_key, 0)
        preset_x = int(layout_position.get("x", base_x))
        preset_y = int(layout_position.get("y", base_y + (slot_index * 90)))
        badges = []
        if not is_reachable:
            badges.append("UNR")
        if dead_end:
            badges.append("WARN")
        elif terminal_end:
            badges.append("TERM")
        display_label = label + (" [" + ",".join(badges) + "]" if badges else "")
        cy_elements.append(
            {
                "data": {
                    "id": nid,
                    "label": label,
                    "display_label": display_label,
                    "kind": kind,
                    "file": file_path,
                    "line": line,
                    "line_start": line_start,
                    "line_end": line_end,
                    "is_reachable": is_reachable,
                    "terminal_end": terminal_end,
                    "dead_end": dead_end,
                    "entry_distance": n.get("entry_distance"),
                    "preset_x": preset_x,
                    "preset_y": preset_y,
                    "warning_codes": n.get("warning_codes", []),
                }
            }
        )

    aggregated_edges: dict[tuple[str, str], dict[str, Any]] = {}
    for e in edges_raw:
        # Support multiple edge schemas from collapsed graph emitters.
        src = str(
            e.get(
                "source",
                e.get(
                    "from",
                    e.get("src", e.get("from_node", e.get("from_id", ""))),
                ),
            )
        )
        tgt = str(
            e.get(
                "target",
                e.get("to", e.get("dst", e.get("to_node", e.get("to_id", "")))),
            )
        )
        if src and tgt:
            key = (src, tgt)
            bucket = aggregated_edges.setdefault(
                key,
                {
                    "source": src,
                    "target": tgt,
                    "origins": set(),
                    "labels": set(),
                    "kinds": set(),
                    "count": 0,
                },
            )
            label = str(e.get("label", e.get("edge_type", e.get("kind", "")))).strip()
            origin = str(e.get("origin", "")).strip()
            kind = str(e.get("edge_type", e.get("kind", ""))).strip()
            if label:
                bucket["labels"].add(label)
            if origin:
                bucket["origins"].add(origin)
            if kind:
                bucket["kinds"].add(kind)
            meta = e.get("meta", {})
            if isinstance(meta, dict):
                meta_origins = meta.get("origins", [])
                if isinstance(meta_origins, list):
                    for meta_origin in meta_origins:
                        if meta_origin:
                            bucket["origins"].add(str(meta_origin))
            bucket["count"] += 1

    for edge_index, bucket in enumerate(aggregated_edges.values()):
        labels = sorted(bucket["labels"])
        kinds = sorted(bucket["kinds"])
        origins = sorted(bucket["origins"])
        primary_kind = "choice" if "choice" in kinds else (kinds[0] if kinds else "")
        primary_label = labels[0] if labels else (primary_kind or "edge")
        cy_elements.append(
            {
                "data": {
                    "id": f"{bucket['source']}::{bucket['target']}::{edge_index}",
                    "source": bucket["source"],
                    "target": bucket["target"],
                    "label": primary_label,
                    "origin": origins[0] if len(origins) == 1 else "merged",
                    "kind": primary_kind,
                    "count": bucket["count"],
                }
            }
        )

    n_nodes = len(nodes_raw)
    n_edges = len(edges_raw)
    n_visual_edges = len(aggregated_edges)
    reachable_count = max(0, n_nodes - unreachable_count)
    reachable_pct = round(reachable_count * 100 / n_nodes) if n_nodes > 0 else 100
    is_large_and_sparse = n_nodes > 300 and reachable_pct < 15

    # Detect degenerate preset positions: if all nodes share the same x coordinate
    # (or the x-spread is trivially small), the preset layout produces an invisible
    # single-column spine.  This happens for large single-component projects where
    # cluster_anchor / layout_position data is absent — every node falls back to
    # component_rank * 640 = 0.  In that case we fall back to breadthfirst so the
    # graph is immediately visible in the browser.
    node_xs = [
        el["data"].get("preset_x", 0)
        for el in cy_elements
        if "source" not in el["data"]  # nodes only, not edges
    ]
    x_spread = (max(node_xs) - min(node_xs)) if node_xs else 0
    # Threshold: less than 200px spread across all nodes → degenerate preset
    use_preset = x_spread >= 200
    # NOTE: plain string (NOT f-string) — use single braces for JS object literals.
    # This value is interpolated verbatim via {initial_layout_js} in the f-string below.
    # Always use breadthfirst as the initial layout for stable first-open display.
    # Users can switch to Narrative (preset) via the Layout dropdown if needed.
    initial_layout_js = """{
                name: 'breadthfirst',
                directed: true,
                padding: 30,
                spacingFactor: 1.3,
                fit: true,
                animate: false
            }"""

    elements_json = json.dumps(cy_elements, ensure_ascii=False)
    _grp_strip = {"score", "motif_type"}
    _groups_raw = unified_data.get("collapsed_graph", {}).get("groups", [])
    groups_json = json.dumps(
        [{k: v for k, v in g.items() if k not in _grp_strip} for g in _groups_raw],
        ensure_ascii=False,
    )
    _gbp_raw = unified_data.get("collapsed_graph", {}).get("groups_by_preset", {})
    groups_by_preset_json = json.dumps(
        {p: [{k: v for k, v in g.items() if k not in _grp_strip} for g in gl]
         for p, gl in _gbp_raw.items()},
        ensure_ascii=False,
    )

    body = f"""
<h1>BranchPy Flowchart — {project_name}</h1>
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:2px;">
    <p class="meta" style="margin-bottom:0;">{html.escape(str(project_root))} &nbsp;·&nbsp; {n_nodes} nodes &nbsp;·&nbsp; {n_visual_edges} visual edges &nbsp;·&nbsp; {n_edges} source edges &nbsp;·&nbsp; {entry_count} entries &nbsp;·&nbsp; {unreachable_count} unreachable from entries &nbsp;·&nbsp; {terminal_end_count} terminal endpoints &nbsp;·&nbsp; {dead_end_count} dead-end warnings</p>
    <button id="controls-toggle-btn" title="Collapse/expand toolbar panels" style="margin-left:12px; flex-shrink:0; padding:3px 10px; border-radius:5px; border:1px solid #2a2d3a; background:#1a1d27; color:#7a7d8c; font-size:0.74rem; cursor:pointer; white-space:nowrap;">&#9660; Controls</button>
</div>

<div id="top-controls-band">
<div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap; margin-bottom:10px; margin-top:12px;">
    <button id="fit-btn" style="padding:6px 10px; border-radius:6px; border:1px solid #2a2d3a; background:#1a1d27; color:#e4e6f0;">Fit</button>
    <button id="zoom-in-btn" style="padding:6px 10px; border-radius:6px; border:1px solid #2a2d3a; background:#1a1d27; color:#e4e6f0;">Zoom In</button>
    <button id="zoom-out-btn" style="padding:6px 10px; border-radius:6px; border:1px solid #2a2d3a; background:#1a1d27; color:#e4e6f0;">Zoom Out</button>
    <button id="side-panel-btn" title="Toggle side details panel" style="padding:6px 10px; border-radius:6px; border:1px solid #2a2d3a; background:#1a1d27; color:#7a7d8c;">&#8856; Panel</button>
    <button id="help-panel-btn" title="Keyboard &amp; interaction reference" style="padding:6px 10px; border-radius:6px; border:1px solid #2a2d3a; background:#1a1d27; color:#7a7d8c;">? Help</button>
    <label style="color:var(--muted); font-size:0.78rem;">Search:
        <input id="node-search" type="text" placeholder="label..." style="margin-left:4px; padding:6px 8px; min-width:170px; background:#0f1117; color:#e4e6f0; border:1px solid #2a2d3a; border-radius:4px;">
    </label>
    <button id="search-btn" style="padding:6px 10px; border-radius:6px; border:1px solid #2a2d3a; background:#1a1d27; color:#e4e6f0;">Find</button>
    <span id="search-status" style="font-size:0.76rem; color:#facc15;"></span>
    <label style="color:var(--muted); font-size:0.78rem;">Layout:
        <select id="layout-mode" style="margin-left:4px; padding:6px 8px; background:#0f1117; color:#e4e6f0; border:1px solid #2a2d3a; border-radius:4px;">
            <option value="cluster"{"" if use_preset else " disabled"}>Narrative Layout (M4)</option>
            <option value="breadthfirst"{"" if use_preset else ' selected'}>Breadth-first</option>
            <option value="cose">Force-directed</option>
            <option value="connectivity">Connectivity</option>
            <option value="grid">Grid</option>
            <option value="circle">Circle</option>
        </select>
    </label>
    <label style="color:var(--muted); font-size:0.78rem;">Highlight:
        <select id="trace-mode" style="margin-left:4px; padding:6px 8px; background:#0f1117; color:#e4e6f0; border:1px solid #2a2d3a; border-radius:4px;">
            <option value="neighbors">Immediate neighbors</option>
            <option value="forward">Full path forward</option>
            <option value="backward">Full path backward</option>
            <option value="connected">Full connected path</option>
        </select>
    </label>
    <label style="color:var(--muted); font-size:0.78rem;">Editor:
        <select id="editor-mode" style="margin-left:4px; padding:6px 8px; background:#0f1117; color:#e4e6f0; border:1px solid #2a2d3a; border-radius:4px;">
            <option value="vscode">VS Code</option>
            <option value="cursor">Cursor</option>
            <option value="zed">Zed</option>
            <option value="file">File URL</option>
            <option value="none">Disabled</option>
        </select>
    </label>
    <button id="expand-all-btn" style="padding:5px 9px; border-radius:5px; border:1px solid #2a2d3a; background:#1a1d27; color:#7ce7db; font-size:0.75rem; display:none;">Expand All</button>
    <label style="color:var(--muted); font-size:0.78rem;">Compress:
        <select id="group-preset-mode" style="margin-left:4px; padding:6px 8px; background:#0f1117; color:#e4e6f0; border:1px solid #2a2d3a; border-radius:4px;" title="Semantic auto-grouping preset">
            <option value="off" selected>off</option>
            <option value="conservative">conservative</option>
            <option value="balanced">balanced</option>
            <option value="aggressive">aggressive</option>
        </select>
        <span id="group-status-badge" style="display:none; font-size:0.73rem; padding:1px 6px; border-radius:3px; margin-left:4px; white-space:nowrap;"></span>
    </label>
    <span id="collapse-hint" style="font-size:0.73rem; color:#555; margin-left:6px;">Shift-drag to select &nbsp;·&nbsp; Ctrl+Click to add &nbsp;·&nbsp; right-click to collapse &nbsp;·&nbsp; right-click group to expand</span>
    <!-- Collapsible quick-reference for grouping/collapsing -->
    <details style="display:inline-block; margin-left:8px; vertical-align:middle;">
        <summary style="font-size:0.73rem; color:#4a9; cursor:pointer; list-style:none; user-select:none;">&#9432; Grouping help</summary>
        <div style="position:absolute; z-index:1000; background:#1a1d27; border:1px solid #3a3d4a; border-radius:7px; padding:12px 16px; font-size:0.78rem; color:#c8ccd8; line-height:1.75; min-width:340px; max-width:480px; box-shadow:0 4px 18px rgba(0,0,0,0.55); margin-top:4px;">
            <strong style="color:#7ce7db; display:block; margin-bottom:6px;">Grouping &amp; Collapsing Labels</strong>
            <ul style="margin:0 0 0 16px; padding:0;">
                <li><strong>Select nodes:</strong> Shift+drag for a box, or Ctrl+Click individual nodes (need 2+)</li>
                <li><strong>Collapse:</strong> Right-click any selected node &rarr; <em>Collapse Highlighted Nodes</em></li>
                <li><strong>Expand one group:</strong> Right-click the group node &rarr; <em>Expand This Group</em></li>
                <li><strong>Expand all:</strong> Right-click anywhere &rarr; <em>Expand All</em>, or use the <em>Expand All</em> button that appears in the toolbar</li>
                <li><strong>Nested groups:</strong> Collapse a group node together with other nodes to stack groups further</li>
                <li><em style="color:#7a7d8c;">Visual only — your .rpy source is never modified</em></li>
            </ul>
        </div>
    </details>
    <span style="display:inline-flex; gap:10px; align-items:center; font-size:0.75rem; color:var(--muted); margin-left:6px;">
        <span><span style="display:inline-block;width:9px;height:9px;border-radius:2px;background:#1d4d35;border:1px solid #4ade80;margin-right:3px;vertical-align:middle;"></span>Entry</span>
        <span><span style="display:inline-block;width:9px;height:9px;border-radius:2px;background:#4d1f1f;border:1px solid #f87171;margin-right:3px;vertical-align:middle;"></span>Exit</span>
        <span><span style="display:inline-block;width:9px;height:9px;border-radius:2px;background:#3b3417;border:1px solid #facc15;margin-right:3px;vertical-align:middle;"></span>Routing</span>
        <span><span style="display:inline-block;width:9px;height:9px;border-radius:2px;background:#1f4157;border:1px solid #7ce7db;margin-right:3px;vertical-align:middle;"></span>Narrative</span>
        <span title="No outgoing edge in extracted graph — may be a valid ending, return, or intentionally final label"><span style="display:inline-block;width:9px;height:9px;border-radius:2px;background:#4d1f1f;border:2px solid #fca5a5;margin-right:3px;vertical-align:middle;"></span>Terminal endpoint</span>
        <span title="Not reachable from detected entry points — may include side content, utility paths, menus, or engine-managed flow"><span style="display:inline-block;width:9px;height:9px;border-radius:2px;background:#40261d;border:1px dashed #fb923c;margin-right:3px;vertical-align:middle;"></span>Unreachable from entries</span>
        <span><span style="display:inline-block;width:9px;height:9px;border-radius:2px;background:#3b3417;border:2px solid #fde047;box-shadow:0 0 0 2px rgba(253,224,71,.35);margin-right:3px;vertical-align:middle;"></span>Dead-end warning</span>
    </span>
    <span class="meta">Click a node for details &nbsp;·&nbsp; double-click to focus &nbsp;·&nbsp; click and drag to rearrange &nbsp;·&nbsp; click canvas to clear</span>
</div>

<div id="flow-health-strip" style="display:flex; gap:8px; align-items:center; flex-wrap:wrap; margin:0 0 10px 0;">
    <span id="layout-indicator" style="padding:3px 8px; border-radius:999px; background:rgba(124,231,219,.10); color:#7ce7db; border:1px solid rgba(124,231,219,.35); font-size:0.74rem;">Layout: Narrative (M4)</span>
    <span title="Percentage of nodes reachable from detected entry points by BFS traversal of the extracted graph." style="padding:3px 8px; border-radius:999px; background:rgba(124,231,219,.08); color:#94a3b8; border:1px solid rgba(124,231,219,.2); font-size:0.74rem; cursor:help;">{reachable_count}/{n_nodes} reachable ({reachable_pct}%)</span>
    <span title="Not reachable from detected entry points. This often includes side content, utility paths, menus, or engine-managed flow — not necessarily broken labels." style="padding:3px 8px; border-radius:999px; background:rgba(74,222,128,.10); color:#86efac; border:1px solid rgba(74,222,128,.35); font-size:0.74rem; cursor:help;">{('✓ All nodes reachable from entries' if unreachable_count == 0 else f'{unreachable_count} unreachable from entries')}</span>
    <span title="Reachable nodes with no outgoing edge in the extracted graph, based on static analysis context. Not all are bugs — check with the Focus button." style="padding:3px 8px; border-radius:999px; background:rgba(250,204,21,.10); color:#fde047; border:1px solid rgba(250,204,21,.35); font-size:0.74rem; cursor:help;">{('No dead-end warnings' if dead_end_count == 0 else f'{dead_end_count} dead-end warning(s)')}</span>
    <span title="Nodes with no outgoing edge in the extracted graph. This can include valid endings, returns, stops, or intentionally final labels — not necessarily errors." style="padding:3px 8px; border-radius:999px; background:rgba(248,113,113,.10); color:#fca5a5; border:1px solid rgba(248,113,113,.35); font-size:0.74rem; cursor:help;">{terminal_end_count} terminal endpoint(s)</span>
</div>
{"" if not is_large_and_sparse else '<div style="display:flex;align-items:flex-start;gap:10px;padding:8px 12px;background:rgba(250,204,21,.07);border:1px solid rgba(250,204,21,.2);border-radius:6px;font-size:0.78rem;color:#fde68a;margin-bottom:8px;line-height:1.6;"><span style="flex-shrink:0;">&#9432;</span><span><strong>Why so many unreachable nodes?</strong> — Large VN projects often contain many independent entry points, dynamic routing paths, and engine-managed labels that are not linearly reachable from a single &ldquo;start&rdquo;. A low reachability percentage is expected and normal for projects like MAS. It does not indicate broken code; use &ldquo;Unreachable from entries&rdquo; focus filter to explore.</span></div>'}

<div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap; margin:0 0 10px 0;">
    <span style="color:var(--muted); font-size:0.76rem;">Focus:</span>
    <button class="focus-filter-btn" id="filter-entry" style="padding:4px 8px; border-radius:999px; border:1px solid #2a2d3a; background:#1a1d27; color:#d2fddf; cursor:pointer; font-size:0.74rem;">Entries</button>
    <button class="focus-filter-btn" id="filter-unreachable" title="Not reachable from detected entry points — may include side content, utility paths, or engine-managed flow" style="padding:4px 8px; border-radius:999px; border:1px solid #2a2d3a; background:#1a1d27; color:#fdba74; cursor:pointer; font-size:0.74rem;">Unreachable from entries</button>
    <button class="focus-filter-btn" id="filter-dead-end" title="Reachable nodes with no outgoing edge detected by static analysis — potentially suspicious, but not necessarily bugs" style="padding:4px 8px; border-radius:999px; border:1px solid #2a2d3a; background:#1a1d27; color:#fde047; cursor:pointer; font-size:0.74rem;">Dead-end warnings</button>
    <button class="focus-filter-btn" id="filter-terminal" title="Nodes with no outgoing edge in the extracted graph — can include valid endings, returns, stops, or intentionally final labels" style="padding:4px 8px; border-radius:999px; border:1px solid #2a2d3a; background:#1a1d27; color:#fca5a5; cursor:pointer; font-size:0.74rem;">Terminal endpoints</button>
    <button class="focus-filter-btn" id="filter-clear" style="padding:4px 8px; border-radius:999px; border:1px solid #2a2d3a; background:#1a1d27; color:#e4e6f0; cursor:pointer; font-size:0.74rem;">Clear focus</button>
    <span id="focus-state" style="font-size:0.74rem; color:var(--muted);">focused: none</span>
    <span id="qa-state" style="font-size:0.74rem; color:var(--muted); margin-left:8px;">Layout: {"Narrative (M4)" if use_preset else "Breadth-first (auto)"} · Focus: none</span>
</div>

{"" if use_preset else '<div style="background:rgba(250,204,21,.08);border:1px solid rgba(250,204,21,.25);border-radius:6px;padding:7px 12px;font-size:0.78rem;color:#fde68a;margin-bottom:8px;">⚠ Narrative layout skipped — no spatial position data available for this project. Graph is showing Breadth-first layout. <em>Narrative layout requires a fresh run with full position export.</em></div>'}

</div><!-- #top-controls-band -->

<div id="cy-tooltip" style="position:fixed; display:none; background:#1a1d27; border:1px solid #2a2d3a; border-radius:6px; padding:8px 12px; font-size:0.78rem; color:#e4e6f0; pointer-events:none; z-index:9999; white-space:pre; max-width:320px;"></div>

<!-- Context menu for manual collapse -->
<div id="cy-context-menu" style="position:fixed; display:none; background:#1a1d27; border:1px solid #3a3d4a; border-radius:6px; padding:4px 0; font-size:0.82rem; color:#e4e6f0; z-index:10000; min-width:180px; box-shadow:0 4px 16px rgba(0,0,0,0.5);">
    <div id="ctx-collapse" style="padding:7px 14px; cursor:pointer;">Collapse Highlighted Nodes</div>
    <div id="ctx-expand-group" style="padding:7px 14px; cursor:pointer; display:none;">Expand This Group</div>
    <div style="border-top:1px solid #2a2d3a; margin:3px 0;"></div>
    <div id="ctx-expand-all" style="padding:7px 14px; cursor:pointer;">Expand All</div>
</div>

<!-- Slide-in Help panel (right side, mutually exclusive with side-panel) -->
<div id="help-panel" style="position:fixed; top:0; right:-380px; width:370px; height:100vh; background:#10131c; border-left:1px solid #2a2d3a; z-index:8000; display:flex; flex-direction:column; transition:right 0.22s ease; box-shadow:-4px 0 22px rgba(0,0,0,0.55); overflow:hidden;">
    <div style="display:flex; align-items:center; justify-content:space-between; padding:12px 14px; border-bottom:1px solid #2a2d3a; flex-shrink:0;">
        <strong style="color:#7ce7db; font-size:0.9rem;">? Help &amp; Reference</strong>
        <button id="help-panel-close" style="background:none; border:none; color:#7a7d8c; font-size:1.1rem; cursor:pointer; padding:2px 6px; border-radius:4px;">&#x2715;</button>
    </div>
    <div style="overflow-y:auto; flex:1 1 0; padding:14px; font-size:0.8rem; color:#c8ccd8; line-height:1.7;">

        <div style="background:rgba(250,204,21,.07); border:1px solid rgba(250,204,21,.22); border-radius:5px; padding:8px 12px; margin-bottom:14px; font-size:0.75rem; color:#fde68a;">
            &#9888; The graph is built from the <strong>last Analyze run</strong>. If you edited .rpy files since, re-run Analyze and regenerate the HTML.
        </div>

        <h4 style="color:#7ce7db; margin:0 0 6px 0; font-size:0.82rem; border-bottom:1px solid #2a2d3a; padding-bottom:4px;">Navigation</h4>
        <ul style="margin:0 0 14px 14px; padding:0;">
            <li><strong>Pan:</strong> Click &amp; drag canvas</li>
            <li><strong>Zoom:</strong> Mouse wheel / trackpad pinch</li>
            <li><strong>Fit:</strong> Fit button or double-click canvas</li>
            <li><strong>Find node:</strong> Search box &rarr; Find (cycles through matches)</li>
        </ul>

        <h4 style="color:#7ce7db; margin:0 0 6px 0; font-size:0.82rem; border-bottom:1px solid #2a2d3a; padding-bottom:4px;">Selection</h4>
        <ul style="margin:0 0 14px 14px; padding:0;">
            <li><strong>Single click:</strong> Select node + show trace highlight</li>
            <li><strong>Ctrl+Click:</strong> Add/remove from multi-select &mdash; non-selected dims</li>
            <li><strong>Shift+drag:</strong> Box-select many nodes</li>
            <li><strong>Click canvas:</strong> Clear selection &amp; all dim/highlight</li>
        </ul>

        <h4 style="color:#7ce7db; margin:0 0 6px 0; font-size:0.82rem; border-bottom:1px solid #2a2d3a; padding-bottom:4px;">Highlight <span style="font-size:0.72rem; color:#888;">(trace mode)</span></h4>
        <ul style="margin:0 0 14px 14px; padding:0;">
            <li>Click a node &rarr; highlighted path glows <strong style="color:#FFD700;">gold</strong>, the rest dims to ~15% opacity</li>
            <li>Path direction controlled by the <strong>Highlight</strong> dropdown: Immediate neighbors / Forward / Backward / Connected</li>
            <li>Ctrl+click multiple nodes &rarr; only selected nodes stay lit, others dim</li>
            <li>Click canvas to clear</li>
        </ul>

        <h4 style="color:#7ce7db; margin:0 0 6px 0; font-size:0.82rem; border-bottom:1px solid #2a2d3a; padding-bottom:4px;">Focus <span style="font-size:0.72rem; color:#888;">(structural isolation)</span></h4>
        <ul style="margin:0 0 14px 14px; padding:0;">
            <li><strong>Double-click node:</strong> Centers view + greys everything outside its neighborhood</li>
            <li><strong>Focus buttons</strong> (Entries / Unreachable from entries / Dead-end warnings / Terminal endpoints): shows only nodes of that category, everything else grey</li>
            <li><strong>Clear focus:</strong> Removes all dimming</li>
        </ul>

        <h4 style="color:#7ce7db; margin:0 0 6px 0; font-size:0.82rem; border-bottom:1px solid #2a2d3a; padding-bottom:4px;">Collapsing &amp; Groups</h4>
        <ul style="margin:0 0 14px 14px; padding:0;">
            <li><strong>Collapse manual:</strong> Select 2+ nodes &rarr; right-click &rarr; <em>Collapse Highlighted Nodes</em></li>
            <li><strong>Expand one:</strong> Right-click group node &rarr; <em>Expand This Group</em></li>
            <li><strong>Expand all:</strong> Right-click anywhere &rarr; <em>Expand All</em>, or toolbar button</li>
            <li><strong>Compress preset:</strong> Use the <em>Compress</em> dropdown to auto-collapse semantic corridors (conservative / balanced / aggressive)</li>
            <li>Visual only &mdash; .rpy source is never modified</li>
        </ul>

        <h4 style="color:#7ce7db; margin:0 0 6px 0; font-size:0.82rem; border-bottom:1px solid #2a2d3a; padding-bottom:4px;">Layouts</h4>
        <ul style="margin:0 0 14px 14px; padding:0;">
            <li><strong>Breadth-first:</strong> Default; stable top-down hierarchy</li>
            <li><strong>Force-directed:</strong> Clusters related nodes (slow on MAS)</li>
            <li><strong>Connectivity:</strong> Community-clustering variant — connected nodes group together, weakly-connected regions drift apart. Best for large graphs</li>
            <li><strong>Grid / Circle:</strong> Geometric arrangements</li>
            <li><strong>Narrative (M4):</strong> Uses spatial position data baked at analysis time &mdash; only available when the project has been analyzed with full position export</li>
        </ul>

        <h4 style="color:#7ce7db; margin:0 0 6px 0; font-size:0.82rem; border-bottom:1px solid #2a2d3a; padding-bottom:4px;">Node colours</h4>
        <div style="display:flex; flex-direction:column; gap:4px; margin-bottom:14px; font-size:0.77rem;">
            <span><span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:#1d4d35;border:1px solid #4ade80;margin-right:6px;vertical-align:middle;"></span>Entry &mdash; story start</span>
            <span><span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:#4d1f1f;border:1px solid #f87171;margin-right:6px;vertical-align:middle;"></span>Exit &mdash; end / return</span>
            <span><span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:#3b3417;border:1px solid #facc15;margin-right:6px;vertical-align:middle;"></span>Routing &mdash; conditional / jump</span>
            <span><span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:#1f4157;border:1px solid #7ce7db;margin-right:6px;vertical-align:middle;"></span>Narrative &mdash; dialogue / content</span>
            <span><span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:#4d1f1f;border:2px solid #fca5a5;margin-right:6px;vertical-align:middle;"></span>Terminal endpoint &mdash; no outgoing edge in extracted graph; may be a valid ending, return, or stop</span>
            <span><span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:#40261d;border:1px dashed #fb923c;margin-right:6px;vertical-align:middle;"></span>Unreachable from entries &mdash; not reachable from detected entry points; may include side content, utility paths, or engine-managed flow</span>
            <span><span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:#3b3417;border:2px solid #fde047;margin-right:6px;vertical-align:middle;"></span>Dead-end warning &mdash; reachable node with no outgoing edge detected by static analysis; not all are bugs</span>
        </div>

        <h4 style="color:#7ce7db; margin:0 0 6px 0; font-size:0.82rem; border-bottom:1px solid #2a2d3a; padding-bottom:4px;">Edge styles</h4>
        <ul style="margin:0 0 14px 14px; padding:0;">
            <li><strong>Solid:</strong> Certain &mdash; always executes</li>
            <li><strong>Dashed:</strong> Likely &mdash; high confidence</li>
            <li><strong>Dotted:</strong> Unknown condition</li>
            <li>Hover an edge for type &amp; certainty details</li>
        </ul>

        <div style="background:rgba(124,231,219,.06); border:1px solid rgba(124,231,219,.18); border-radius:5px; padding:8px 12px; font-size:0.75rem; color:#7a7d8c; margin-top:4px;">
            All graphics (collapse groups, layout changes) are visual-only &mdash; your .rpy source is never modified.
        </div>
    </div>
</div>

<div id="main-layout" style="display:flex; gap:12px; align-items:flex-start; height:calc(100vh - 140px); min-height:520px;">
    <div style="flex:1 1 0; min-width:0; height:100%; border:1px solid #2a2d3a; border-radius:8px; overflow:hidden; background:#0f1117;">
        <div id="cy" style="width:100%; height:100%;">
            <div id="cy-loading-msg" style="height:100%;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:10px;color:#7ce7db;font-size:0.85rem;">
                <div style="font-size:1.5rem;">&#8987;</div>
                <div>Initializing graph renderer&#8230;</div>
            </div>
        </div>
    </div>
    <div id="side-panel" style="flex:0 0 340px; height:100%; overflow-y:auto; display:flex; flex-direction:column; gap:10px;">
        <div id="node-info" class="card" style="padding:12px; flex-shrink:0;">
            <h2 style="margin:0 0 10px 0; font-size:1rem;">Node Details</h2>
            <div id="node-empty" class="meta">Click a node to view details.</div>
            <table id="node-table" style="display:none; font-size:0.8rem;">
                <tbody>
                    <tr><th style="width:80px; white-space:nowrap;">Label</th><td id="node-id" style="word-break:break-all;"></td></tr>
                    <tr><th>Type</th><td id="node-type"></td></tr>
                    <tr><th>File</th><td id="node-file" style="word-break:break-all;"></td></tr>
                    <tr><th>Line</th><td id="node-line"></td></tr>
                    <tr><th>Reachable</th><td id="node-reachable"></td></tr>
                    <tr><th>Terminal</th><td id="node-terminal"></td></tr>
                    <tr><th>Dead End</th><td id="node-dead-end"></td></tr>
                    <tr><th>Distance</th><td id="node-distance"></td></tr>
                    <tr><th>Out</th><td id="node-outgoing"></td></tr>
                    <tr><th>In</th><td id="node-incoming"></td></tr>
                    <tr><th>Downstream</th><td id="node-downstream"></td></tr>
                    <tr><th>Upstream</th><td id="node-upstream"></td></tr>
                    <tr><th>Reachable Exits</th><td id="node-reachable-exits"></td></tr>
                    <tr><th>Source</th><td id="node-source"></td></tr>
                    <tr><th>Analysis</th><td id="node-analysis" style="word-break:break-all;"></td></tr>
                    <tr><th>Meta</th><td id="node-meta" style="word-break:break-all;"></td></tr>
                </tbody>
            </table>
            <!-- Compressed group debug section — shown only when a proxy node is selected -->
            <div id="node-group-info" style="display:none; margin-top:10px; padding:8px 10px; border-radius:5px; border:1px solid #3a2d6a; background:#1a1528; font-size:0.78rem; color:#c8c0dc;">
                <div style="color:#9d8df1; font-weight:600; margin-bottom:5px;">&#9672; Compressed group</div>
                <div style="color:#888; font-size:0.72rem; margin-bottom:7px;">Auto-generated proxy &#8212; right-click &#8594; Expand group to restore members.</div>
                <table style="border-collapse:collapse; width:100%;">
                    <tr><th style="text-align:left; color:#888; font-weight:normal; padding:2px 8px 2px 0; width:110px;">Members</th><td id="grp-members" style="word-break:break-all;"></td></tr>
                    <tr><th style="text-align:left; color:#888; font-weight:normal; padding:2px 8px 2px 0;">Entry edge from</th><td id="grp-entry-from"></td></tr>
                    <tr><th style="text-align:left; color:#888; font-weight:normal; padding:2px 8px 2px 0;">Exit edge to</th><td id="grp-exit-to"></td></tr>
                    <tr><th style="text-align:left; color:#888; font-weight:normal; padding:2px 8px 2px 0;">Score</th><td id="grp-score"></td></tr>
                    <tr><th style="text-align:left; color:#888; font-weight:normal; padding:2px 8px 2px 0;">Motif</th><td id="grp-motif"></td></tr>
                </table>
            </div>
            <div style="margin-top:10px;">
                <a id="node-open-file" target="_blank" rel="noopener noreferrer" style="display:inline-block; padding:6px 10px; border-radius:6px; border:1px solid #2a2d3a; background:#1a1d27; color:#e4e6f0; text-decoration:none; opacity:.5; pointer-events:none;">Open in editor</a>
            </div>
        </div>
        <div id="edge-info" class="card" style="display:none; padding:12px; font-size:0.85rem;">
            <div style="color:var(--muted); font-size:0.7rem; margin-bottom:4px;">EDGE</div>
            <strong id="edge-label"></strong>
            <span class="meta" id="edge-kind"></span>
        </div>
        <details class="card" open style="padding:12px; font-size:0.8rem;">
            <summary style="list-style:none; cursor:pointer; color:var(--muted); font-size:0.7rem; margin-bottom:6px;">GRAPH ANALYSIS</summary>
            <div style="display:flex; gap:6px; flex-wrap:wrap;">
                <span class="tag ok">entries {entry_count}</span>
                <span class="tag info">clusters {cluster_count}</span>
                <span class="tag info">backbone length {backbone_length}</span>
                <span class="tag info">branch bundles {branch_bundle_count}</span>
                <span class="tag info">terminal bundles {terminal_bundle_count}</span>
                <span class="tag info">merge corridors {merge_corridor_count}</span>
                <span class="tag info">crossings {crossing_count_before_cleanup}→{crossing_count}</span>
                <span class="tag info">normalized crossings {normalized_crossings_before_cleanup:.3f}→{normalized_crossings:.3f}</span>
                <span class="tag info">edge overlaps {edge_overlap_count_before_cleanup}→{edge_overlap_count}</span>
                <span class="tag info">local nudges {local_nudge_count}</span>
                <span class="tag info">reordered hubs {reordered_branch_hub_count}</span>
                <span class="tag info">terminal endpoints {terminal_end_count}</span>
                <span class="tag warn">dead-end warnings {dead_end_count}</span>
                <span class="tag err">unreachable from entries {unreachable_count}</span>
            </div>
        </details>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/cytoscape/3.28.1/cytoscape.min.js"
                crossorigin="anonymous"
                referrerpolicy="no-referrer"
                onerror="this.onerror=null; var s=document.createElement('script'); s.src='https://unpkg.com/cytoscape@3.28.1/dist/cytoscape.min.js'; document.head.appendChild(s);">
</script>
<script>
(function() {{
    var elements = {elements_json};
    var groupsByPreset = {groups_by_preset_json};
    // groupData is the currently-active preset's group list (starts from the baked default).
    // When the user changes the Group: selector we swap this out from groupsByPreset.
    var groupData = {groups_json};
    // In-memory state for group collapsed/expanded UI (not persisted across page loads)
    var groupState = {{}};
    groupData.forEach(function(g) {{
        groupState[g.group_id] = {{
            collapsed: g.collapsed !== false,  // null → default=true for auto, treat as collapsed
            pinned: g.pinned,
            stale: g.stale
        }};
    }});
    var initAttempts = 0;

    function showGraphLoadError(message) {{
        var host = document.getElementById('cy');
        if (!host) return;
        host.innerHTML = '<div style="height:100%;display:flex;align-items:center;justify-content:center;padding:16px;text-align:center;color:#f87171;font-size:0.86rem;">' +
            String(message || 'Unable to load graph renderer.') +
            '</div>';
    }}

    function initCy() {{
        if (typeof cytoscape === 'undefined') {{
            initAttempts += 1;
            if (initAttempts > 40) {{
                showGraphLoadError('Unable to load Cytoscape from CDN. Check network access, then refresh this report.');
                return;
            }}
            setTimeout(initCy, 200);
            return;
        }}

        var cy = cytoscape({{
            container: document.getElementById('cy'),
            elements: elements,
            style: [
                {{
                    selector: 'node',
                    style: {{
                        'background-color': '#0f766e',
                        'border-color': '#7ce7db',
                        'border-width': 1.8,
                        'color': '#e4e6f0',
                        'label': 'data(display_label)',
                        'text-valign': 'center',
                        'text-halign': 'center',
                        'font-size': 11,
                        'padding': 8,
                        'shape': 'round-rectangle',
                        'text-wrap': 'wrap',
                        'text-max-width': 120,
                        'text-outline-color': '#0f1117',
                        'text-outline-width': 1.2,
                        'min-width': 40,
                        'min-height': 24
                    }}
                }},
                {{ selector: 'node[kind = "entry"]', style: {{ 'background-color': '#16a34a', 'border-color': '#86efac' }} }},
                {{ selector: 'node[kind = "exit"]', style: {{ 'background-color': '#dc2626', 'border-color': '#fca5a5' }} }},
                {{ selector: 'node[kind = "routing"]', style: {{ 'background-color': '#f59e0b', 'border-color': '#fde047', 'color': '#0b0c0f', 'text-outline-color': '#fde68a' }} }},
                {{ selector: 'node[kind = "narrative"]', style: {{ 'background-color': '#0f766e', 'border-color': '#7ce7db' }} }},
                {{ selector: 'node[terminal_end = true]', style: {{ 'border-color': '#fca5a5', 'border-width': 2.8 }} }},
                {{ selector: 'node[is_reachable = false]', style: {{ 'border-color': '#fdba74', 'border-style': 'dashed', 'border-width': 3.0, 'opacity': 0.76 }} }},
                {{ selector: 'node[dead_end = true]', style: {{ 'border-color': '#fde047', 'border-width': 3.4, 'shadow-blur': 18, 'shadow-color': '#fde047', 'shadow-opacity': 0.42 }} }},
                {{
                    selector: 'edge',
                    style: {{
                        'width': 1.5,
                        'line-color': '#2a2d3a',
                        'target-arrow-color': '#7ce7db',
                        'target-arrow-shape': 'triangle',
                        'curve-style': 'bezier',
                        'font-size': 9,
                        'color': '#7a7d8c',
                        'label': 'data(label)',
                        'text-rotation': 'autorotate'
                    }}
                }},
                {{ selector: 'edge[origin = "cfg"]', style: {{ 'line-color': '#4b6a8b', 'target-arrow-color': '#7ce7db' }} }},
                {{ selector: 'edge[kind = "choice"]', style: {{ 'line-style': 'dashed' }} }},
                {{ selector: '.pathNode', style: {{ 'border-color': '#7ce7db', 'border-width': 3 }} }},
                {{ selector: '.pathEdge', style: {{ 'line-color': '#7ce7db', 'target-arrow-color': '#7ce7db', 'width': 3.5 }} }},
                {{ selector: '.pathOrigin', style: {{ 'border-color': '#facc15', 'border-width': 4, 'shadow-blur': 18, 'shadow-color': '#facc15', 'shadow-opacity': 0.75 }} }},
                {{ selector: '.filterNode', style: {{ 'border-color': '#ffffff', 'border-width': 3.4, 'shadow-blur': 18, 'shadow-color': '#ffffff', 'shadow-opacity': 0.3 }} }},
                {{ selector: '.filterEdge', style: {{ 'line-color': '#ffffff', 'target-arrow-color': '#ffffff', 'width': 2.8 }} }},
                {{
                    selector: '.neighborNode',
                    style: {{
                        'border-color': '#7ce7db',
                        'border-width': 3,
                        'shadow-blur': 14,
                        'shadow-color': '#7ce7db',
                        'shadow-opacity': 0.5
                    }}
                }},
                {{
                    selector: '.neighborEdge',
                    style: {{
                        'line-color': '#7ce7db',
                        'target-arrow-color': '#7ce7db',
                        'width': 3.5
                    }}
                }},
                {{ selector: 'node.hl-dimmed', style: {{ 'opacity': 0.15 }} }},
                {{ selector: 'edge.hl-dimmed', style: {{ 'opacity': 0.06 }} }},
                {{
                    selector: 'node.focus-dimmed',
                    style: {{ 'opacity': 0.08, 'background-color': '#333', 'color': '#555' }}
                }},
                {{ selector: 'edge.focus-dimmed', style: {{ 'opacity': 0.04, 'line-color': '#444' }} }},
                {{
                    selector: ':selected',
                    style: {{
                        'border-color': '#ffffff',
                        'border-width': 3.5,
                        'shadow-color': '#ffffff',
                        'shadow-blur': 20,
                        'shadow-opacity': 0.5
                    }}
                }},
                {{
                    selector: 'node[group_collapsed = "true"]',
                    style: {{
                        'shape': 'round-rectangle',
                        'border-style': 'dashed',
                        'border-width': 2,
                        'border-color': '#888',
                        'background-color': '#1c2c3a',
                        'background-opacity': 0.55,
                        'label': 'data(label)',
                        'font-size': 11,
                        'text-valign': 'center',
                        'text-halign': 'center',
                        'width': 140,
                        'height': 44,
                        'color': '#c8ccd8',
                        'text-outline-color': '#0f1117',
                        'text-outline-width': 1
                    }}
                }},
                {{
                    selector: 'node[group_collapsed = "true"][stale = "true"]',
                    style: {{
                        'border-color': '#e08800',
                        'border-width': 3
                    }}
                }}
            ],
            layout: {initial_layout_js},
            wheelSensitivity: 0.3,
            boxSelectionEnabled: true,
            selectionType: 'additive'
        }});

        // --- Semantic grouping helpers ---

        function _applyGroupCollapse(group) {{
            var memberSet = new Set(group.member_node_ids);
            var isStale = groupState[group.group_id] && groupState[group.group_id].stale;
            var proxyId = 'grp_' + group.group_id;

            // 1. Collect external edge data BEFORE removing nodes.
            //    Cytoscape auto-removes all incident edges when a node is removed,
            //    so we must snapshot them first or they will be gone before we can reroute.
            var reroutedEdges = [];
            var seenKey = {{}};
            cy.edges().forEach(function(e) {{
                var src = e.data('source'), tgt = e.data('target');
                var srcIn = memberSet.has(src), tgtIn = memberSet.has(tgt);
                if (srcIn && tgtIn) return;   // internal — will be auto-removed
                if (!srcIn && !tgtIn) return;  // fully external — leave alone
                var newSrc = srcIn ? proxyId : src;
                var newTgt = tgtIn ? proxyId : tgt;
                var key = newSrc + '::' + newTgt;
                if (!seenKey[key]) {{
                    seenKey[key] = true;
                    reroutedEdges.push({{ id: key + '::grp', source: newSrc, target: newTgt }});
                }}
            }});

            // 2. Compute proxy position (entry-node position if unique, else centroid)
            var proxyPos = {{ x: 0, y: 0 }};
            var entryIds = group.entry_node_ids || [];
            if (entryIds.length === 1) {{
                var ep = cy.$('#' + CSS.escape(entryIds[0]));
                if (ep.length) proxyPos = {{ x: ep.position('x'), y: ep.position('y') }};
            }} else {{
                var memberNodes = cy.nodes().filter(function(n) {{ return memberSet.has(n.id()); }});
                if (memberNodes.length) {{
                    var sumX = 0, sumY = 0;
                    memberNodes.forEach(function(n) {{ sumX += n.position('x'); sumY += n.position('y'); }});
                    proxyPos = {{ x: sumX / memberNodes.length, y: sumY / memberNodes.length }};
                }}
            }}

            // 3. Remove member nodes (auto-removes all their incident edges)
            cy.nodes().filter(function(n) {{ return memberSet.has(n.id()); }}).remove();

            // 4. Add proxy node at computed position
            if (!cy.$('#' + CSS.escape(proxyId)).length) {{
                cy.add({{
                    data: {{
                        id: proxyId,
                        label: group.label + (isStale ? '\\n⚠' : ''),
                        group_collapsed: 'true',
                        group_id: group.group_id,
                        stale: isStale ? 'true' : 'false',
                        origin: group.origin,
                        member_count: group.member_node_ids.length
                    }},
                    position: proxyPos
                }});
            }}

            // 5. Add rerouted edges
            reroutedEdges.forEach(function(ed) {{
                cy.add({{ data: ed }});
            }});
        }}

        function _expandAutoGroup(group) {{
            var proxyId = 'grp_' + group.group_id;
            var proxyEl = cy.$('#' + CSS.escape(proxyId));
            if (!proxyEl.length) return;
            // Remove proxy (auto-removes its rerouted edges)
            proxyEl.remove();
            // Re-add member nodes from the original elements snapshot
            var memberSet = new Set(group.member_node_ids);
            var memberEls = elements.filter(function(el) {{ return el.data && memberSet.has(el.data.id); }});
            memberEls.forEach(function(el) {{
                if (!cy.$('#' + CSS.escape(el.data.id)).length) cy.add(el);
            }});
            // Re-add internal edges
            var internalEdges = elements.filter(function(el) {{
                return el.data && el.data.source && memberSet.has(el.data.source) && memberSet.has(el.data.target);
            }});
            internalEdges.forEach(function(el) {{
                if (el.data.id && !cy.$('#' + CSS.escape(el.data.id)).length) cy.add(el);
            }});
            // Re-add canonical external edges that touch the chain entry/exit nodes
            var entryExitSet = new Set((group.entry_node_ids || []).concat(group.exit_node_ids || []));
            var externalEdges = elements.filter(function(el) {{
                if (!el.data || !el.data.source || !el.data.target) return false;
                var srcIsEE = entryExitSet.has(el.data.source);
                var tgtIsEE = entryExitSet.has(el.data.target);
                if (!srcIsEE && !tgtIsEE) return false;
                var srcExternal = !memberSet.has(el.data.source);
                var tgtExternal = !memberSet.has(el.data.target);
                return srcExternal || tgtExternal;
            }});
            externalEdges.forEach(function(el) {{
                if (el.data.id && !cy.$('#' + CSS.escape(el.data.id)).length) cy.add(el);
            }});
            groupState[group.group_id] = {{ collapsed: false, pinned: group.pinned, stale: group.stale }};
        }}

        function applyGroups() {{
            groupData.forEach(function(group) {{
                var state = groupState[group.group_id];
                if (!state) return;
                var shouldCollapse = state.collapsed !== false;  // null or true = collapse
                if (shouldCollapse) {{
                    _applyGroupCollapse(group);
                }}
            }});
        }}

        applyGroups();

        function clearNeighborHighlight() {{
            cy.elements().removeClass('neighborNode neighborEdge pathNode pathEdge pathOrigin filterNode filterEdge hl-dimmed focus-dimmed');
        }}

        function currentEditorMode() {{
            var sel = document.getElementById('editor-mode');
            return sel ? String(sel.value || 'vscode') : 'vscode';
        }}

        function updateOpenButtonLabel(mode) {{
            var link = document.getElementById('node-open-file');
            if (!link) return;
            link.textContent = mode === 'file' ? 'Open file' : 'Open in editor';
        }}

        function toEditorUri(path, line) {{
            var normalized = String(path || '').split(String.fromCharCode(92)).join('/');
            if (!normalized) return '';
            var targetLine = line || 1;
            var mode = currentEditorMode();
            if (mode === 'none') return '';
            if (mode === 'vscode') return 'vscode://file/' + encodeURI(normalized) + ':' + String(targetLine) + ':1';
            if (mode === 'cursor') return 'cursor://file/' + encodeURI(normalized) + ':' + String(targetLine) + ':1';
            if (mode === 'zed') return 'zed://file/' + encodeURI(normalized) + ':' + String(targetLine) + ':1';
            return 'file:///' + encodeURI(normalized) + '#L' + String(targetLine);
        }}

        function setNodeOpenLink(path, line) {{
            var link = document.getElementById('node-open-file');
            if (!link) return;
            var mode = currentEditorMode();
            updateOpenButtonLabel(mode);
            var href = toEditorUri(path, line);
            if (!href || path === '(not provided)') {{
                link.removeAttribute('href');
                link.style.opacity = '.5';
                link.style.pointerEvents = 'none';
                link.title = mode === 'none' ? 'Editor opening disabled' : 'No file target available';
                return;
            }}
            link.href = href;
            link.style.opacity = '1';
            link.style.pointerEvents = 'auto';
            link.title = mode === 'file' ? 'Open file in browser/OS handler' : ('Open in ' + mode);
        }}

        function renderNodeDetails(node) {{
            var data = node.data() || {{}};
            var incoming = node.incomers('edge').length;
            var outgoing = node.outgoers('edge').length;

            function firstValue(obj, keys) {{
                for (var i = 0; i < keys.length; i++) {{
                    var k = keys[i];
                    if (Object.prototype.hasOwnProperty.call(obj, k) && obj[k] !== null && obj[k] !== undefined && obj[k] !== '') {{
                        return obj[k];
                    }}
                }}
                return null;
            }}

            function firstElement(ids) {{
                for (var i = 0; i < ids.length; i++) {{
                    var el = document.getElementById(ids[i]);
                    if (el) return el;
                }}
                return null;
            }}

            var emptyEl = firstElement(['node-empty', 'node-details-empty']);
            var tableEl = firstElement(['node-table', 'node-details-table']);
            var idEl = firstElement(['node-id', 'node-label', 'node-name']);
            var typeEl = firstElement(['node-type', 'node-kind']);
            var fileEl = firstElement(['node-file', 'node-path']);
            var lineEl = firstElement(['node-line', 'node-lineno']);
            var outgoingEl = firstElement(['node-outgoing', 'node-out']);
            var incomingEl = firstElement(['node-incoming', 'node-in']);
            var reachableEl = firstElement(['node-reachable']);
            var terminalEl = firstElement(['node-terminal']);
            var deadEndEl = firstElement(['node-dead-end']);
            var distanceEl = firstElement(['node-distance']);
            var downstreamEl = firstElement(['node-downstream']);
            var upstreamEl = firstElement(['node-upstream']);
            var reachableExitsEl = firstElement(['node-reachable-exits']);
            var sourceEl = firstElement(['node-source']);
            var analysisEl = firstElement(['node-analysis']);
            var metaEl = firstElement(['node-meta', 'node-details-body', 'node-details']);

            if (!idEl || !typeEl || !fileEl || !lineEl || !incomingEl || !outgoingEl || !metaEl || !reachableEl || !terminalEl || !deadEndEl || !distanceEl || !downstreamEl || !upstreamEl || !reachableExitsEl || !sourceEl || !analysisEl) {{
                return;
            }}

            if (emptyEl) emptyEl.style.display = 'none';
            if (tableEl) tableEl.style.display = 'table';

            var label = firstValue(data, ['label', 'name', 'title', 'id']);
            var kind = firstValue(data, ['kind', 'type', 'node_type', 'category']) || 'node';
            var filePath = firstValue(data, ['file', 'path', 'source_file', 'script']) || '(not provided)';
            var line = firstValue(data, ['line', 'lineno', 'line_number']);
            var lineStart = firstValue(data, ['line_start', 'start_line']);
            var lineEnd = firstValue(data, ['line_end', 'end_line']);

            idEl.textContent = String(label || '');
            typeEl.textContent = String(kind);
            fileEl.textContent = String(filePath);

            var lineText = '(not provided)';
            if (lineStart && lineEnd && lineStart !== lineEnd) {{
                lineText = String(lineStart) + '-' + String(lineEnd);
            }} else if (line || lineStart || lineEnd) {{
                lineText = String(line || lineStart || lineEnd);
            }}
            lineEl.textContent = lineText;
            outgoingEl.textContent = String(outgoing);
            incomingEl.textContent = String(incoming);
            var isReachable = data.is_reachable !== false;
            var isTerminal = data.terminal_end === true;
            var isDeadEnd = data.dead_end === true;
            reachableEl.textContent = isReachable ? 'yes' : 'no';
            terminalEl.textContent = isTerminal ? 'yes' : 'no';
            deadEndEl.textContent = isDeadEnd ? 'yes' : 'no';
            distanceEl.textContent = data.entry_distance === null || data.entry_distance === undefined ? 'n/a' : String(data.entry_distance);
            var downstreamNodes = node.successors('node');
            var upstreamNodes = node.predecessors('node');
            var reachableExitNodes = downstreamNodes.filter(function(ele) {{
                var dd = ele.data() || {{}};
                return String(dd.kind || '') === 'exit';
            }});
            downstreamEl.textContent = String(downstreamNodes.length);
            upstreamEl.textContent = String(upstreamNodes.length);
            reachableExitsEl.textContent = String(reachableExitNodes.length + (kind === 'exit' ? 1 : 0));
            sourceEl.textContent = String(data.classification_source || 'graph reachability analysis');
            var warnings = Array.isArray(data.warning_codes) ? data.warning_codes : [];
            if (warnings.length > 0) {{
                analysisEl.textContent = warnings.join(' | ');
            }} else if (!isReachable) {{
                analysisEl.textContent = 'Not reachable from any entry node.';
            }} else if (isDeadEnd) {{
                analysisEl.textContent = 'Reachable non-exit node with no outgoing flow.';
            }} else if (isTerminal) {{
                analysisEl.textContent = 'Terminal end (outgoing flow count is zero).';
            }} else {{
                analysisEl.textContent = 'No flow warnings.';
            }}
            setNodeOpenLink(filePath, lineStart || line || lineEnd || 1);

            // Compressed group debug section
            var grpInfoEl = document.getElementById('node-group-info');
            if (grpInfoEl) {{
                if (data.group_collapsed === 'true') {{
                    var gid = data.group_id;
                    var grpDef = gid ? groupData.find(function(g) {{ return g.group_id === gid; }}) : null;
                    if (grpDef) {{
                        var memberLabels = (grpDef.member_node_ids || []).map(function(mid) {{
                            var mn = elements.find(function(el) {{ return el.data && el.data.id === mid; }});
                            return mn ? String(mn.data.label || mid) : String(mid);
                        }});
                        var entryLabels = node.incomers('node').map(function(n) {{ return String(n.data('label') || n.id()); }}).join(', ') || 'none';
                        var exitLabels = node.outgoers('node').map(function(n) {{ return String(n.data('label') || n.id()); }}).join(', ') || 'none';
                        var membEl = document.getElementById('grp-members');
                        var entEl = document.getElementById('grp-entry-from');
                        var extEl = document.getElementById('grp-exit-to');
                        var scoreEl = document.getElementById('grp-score');
                        var motifEl = document.getElementById('grp-motif');
                        if (membEl) membEl.textContent = grpDef.member_node_ids.length + ' nodes: ' + memberLabels.join(', ');
                        if (entEl) entEl.textContent = entryLabels;
                        if (extEl) extEl.textContent = exitLabels;
                        if (scoreEl) scoreEl.textContent = grpDef.score != null ? grpDef.score.toFixed(3) : 'n/a';
                        if (motifEl) motifEl.textContent = String(grpDef.motif_type || 'auto');
                        grpInfoEl.style.display = 'block';
                    }} else {{
                        grpInfoEl.style.display = 'none';
                    }}
                }} else {{
                    grpInfoEl.style.display = 'none';
                }}
            }}

            var meta = firstValue(data, ['meta', 'details', 'payload']);
            if (!meta || typeof meta !== 'object') {{
                metaEl.textContent = String(kind || 'narrative');
                return;
            }}

            var keys = Object.keys(meta);
            if (keys.length === 0) {{
                metaEl.textContent = String(kind || 'narrative');
                return;
            }}

            var pairs = [];
            for (var i = 0; i < keys.length; i++) {{
                var k = keys[i];
                var v = meta[k];
                if (typeof v === 'object') {{
                    try {{ v = JSON.stringify(v); }} catch (_) {{ v = String(v); }}
                }}
                pairs.push(k + ': ' + String(v));
                if (pairs.length >= 6) break;
            }}
            metaEl.textContent = pairs.join(' | ');
        }}

        function highlightNodeNeighborhood(node) {{
            clearNeighborHighlight();
            node.addClass('neighborNode');
            var connected = node.connectedEdges();
            connected.addClass('neighborEdge');
            var nbrs = connected.connectedNodes();
            nbrs.addClass('neighborNode');
            // Dim everything outside the neighborhood
            cy.elements().addClass('hl-dimmed');
            node.removeClass('hl-dimmed');
            connected.removeClass('hl-dimmed');
            nbrs.removeClass('hl-dimmed');
        }}

        function highlightNodePath(node) {{
            clearNeighborHighlight();
            var modeEl = document.getElementById('trace-mode');
            var mode = modeEl ? modeEl.value : 'neighbors';
            node.addClass('pathOrigin');
            if (mode === 'neighbors') {{
                highlightNodeNeighborhood(node);  // handles dimming internally
                node.addClass('pathOrigin');
                return;
            }}
            var collection = cy.collection();
            if (mode === 'forward' || mode === 'connected') collection = collection.union(node.successors());
            if (mode === 'backward' || mode === 'connected') collection = collection.union(node.predecessors());
            collection.nodes().addClass('pathNode');
            collection.edges().addClass('pathEdge');
            // Dim everything not part of the path
            cy.elements().addClass('hl-dimmed');
            node.removeClass('hl-dimmed');
            collection.nodes().removeClass('hl-dimmed');
            collection.edges().removeClass('hl-dimmed');
        }}

        function focusNode(node) {{
            // Grey out everything outside this node's immediate neighborhood
            cy.elements().removeClass('focus-dimmed');
            cy.elements().addClass('focus-dimmed');
            var nbhd = node.closedNeighborhood();
            nbhd.removeClass('focus-dimmed');
            cy.animate({{
                center: {{ eles: node }},
                zoom: Math.max(cy.zoom() * 1.18, 1.2)
            }}, {{ duration: 220 }});
        }}

        function applyLayout(mode) {{
            var selected = String(mode || 'cluster');
            var stableSort = function(a, b) {{
                return String(a.id() || '').localeCompare(String(b.id() || ''));
            }};

            // Narrative (M4): use preset coordinates baked at analysis time.
            // Manual fit to positioned nodes only — avoids blank-canvas when proxy nodes
            // or fallback-zero nodes pull the automatic bounding box to origin.
            if (selected === 'cluster') {{
                var presetLayout = cy.layout({{
                    name: 'preset',
                    positions: function(node) {{
                        return {{
                            x: Number(node.data('preset_x') || 0),
                            y: Number(node.data('preset_y') || 0)
                        }};
                    }},
                    padding: 40,
                    fit: false,
                    animate: false
                }});
                presetLayout.on('layoutstop', function() {{
                    // Fit only to nodes that have real (non-zero) preset positions
                    var positioned = cy.nodes().filter(function(n) {{
                        return !!(Number(n.data('preset_x')) || Number(n.data('preset_y')));
                    }});
                    if (positioned.length > 5) {{
                        cy.fit(positioned, 50);
                    }} else {{
                        cy.fit(undefined, 30);
                    }}
                    updateQaState();
                }});
                presetLayout.run();
                return;
            }}

            // Connectivity: community-clustering cose variant — connected nodes group
            // together, weakly-connected regions drift apart visually.
            if (selected === 'connectivity') {{
                var connLayout = cy.layout({{
                    name: 'cose',
                    padding: 50,
                    animate: true,
                    animationDuration: 600,
                    fit: true,
                    randomize: false,
                    nodeRepulsion: function() {{ return 6000; }},
                    idealEdgeLength: function() {{ return 40; }},
                    edgeElasticity: function() {{ return 450; }},
                    nestingFactor: 5,
                    gravity: 65,
                    numIter: 1500,
                    initialTemp: 200,
                    coolingFactor: 0.99,
                    minTemp: 1.0
                }});
                connLayout.on('layoutstop', function() {{ updateQaState(); }});
                connLayout.run();
                return;
            }}

            var layoutCfg = {{
                name: 'breadthfirst',
                directed: true,
                padding: 24,
                spacingFactor: 1.2,
                avoidOverlap: true,
                sort: stableSort,
            }};
            if (selected === 'cose') layoutCfg = {{
                name: 'cose',
                padding: 24,
                animate: true,
                animationDuration: 220,
                fit: true,
                randomize: false,
            }};
            else if (selected === 'grid') layoutCfg = {{ name: 'grid', padding: 24, avoidOverlap: true, sort: stableSort }};
            else if (selected === 'circle') layoutCfg = {{ name: 'circle', padding: 24, sort: stableSort }};
            var l = cy.layout(layoutCfg);
            l.on('layoutstop', function() {{ updateQaState(); }});
            l.run();
        }}

        function selectNode(node, shouldFocus) {{
            if (!node || !node.length) return;
            var edgeInfo = document.getElementById('edge-info');
            if (edgeInfo) edgeInfo.style.display = 'none';
            renderNodeDetails(node);
            highlightNodePath(node);
            cy.elements().unselect();
            node.select();
            if (shouldFocus) focusNode(node);
        }}

        function applyQuickFilter(mode) {{
            clearNeighborHighlight();
            cy.elements().removeClass('focus-dimmed');
            if (!mode || mode === 'none') return 0;
            var nodes = cy.nodes().filter(function(ele) {{
                var d = ele.data() || {{}};
                if (mode === 'entry') return String(d.kind || '') === 'entry';
                if (mode === 'unreachable') return d.is_reachable === false;
                if (mode === 'dead_end') return d.dead_end === true;
                if (mode === 'terminal') return d.terminal_end === true;
                return false;
            }});
            if (!nodes || !nodes.length) return 0;
            nodes.addClass('filterNode');
            nodes.connectedEdges().addClass('filterEdge');
            // Dim everything not in the focus set so focused nodes stand out clearly
            cy.elements().addClass('focus-dimmed');
            nodes.removeClass('focus-dimmed');
            nodes.connectedEdges().removeClass('focus-dimmed');
            cy.fit(nodes, 40);
            return nodes.length;
        }}

        var activeFocusMode = 'none';
        var focusButtonToMode = {{
            'filter-entry': 'entry',
            'filter-unreachable': 'unreachable',
            'filter-dead-end': 'dead_end',
            'filter-terminal': 'terminal',
            'filter-clear': 'none'
        }};

        function updateQaState() {{
            var qa = document.getElementById('qa-state');
            if (!qa) return;
            var layoutIndicator = document.getElementById('layout-indicator');
            var layoutSel = document.getElementById('layout-mode');
            var layout = layoutSel ? String(layoutSel.value || 'cluster') : 'cluster';
            var layoutLabelByMode = {{
                'cluster': 'Narrative (M4)',
                'breadthfirst': 'Breadth-first',
                'cose': 'Force-directed',
                'connectivity': 'Connectivity',
                'grid': 'Grid',
                'circle': 'Circle',
            }};
            var layoutLabel = layoutLabelByMode[layout] || layout;
            var focus = activeFocusMode === 'none' ? 'none' : activeFocusMode.replace('_', '-');
            qa.textContent = 'Layout: ' + layoutLabel + ' · Focus: ' + focus;
            if (layoutIndicator) layoutIndicator.textContent = 'Layout: ' + layoutLabel;
        }}

        function refreshFocusStateUi() {{
            var ids = Object.keys(focusButtonToMode);
            for (var i = 0; i < ids.length; i++) {{
                var id = ids[i];
                var mode = focusButtonToMode[id];
                var btn = document.getElementById(id);
                if (!btn) continue;
                var active = mode === activeFocusMode && mode !== 'none';
                btn.style.borderColor = active ? '#7ce7db' : '#2a2d3a';
                btn.style.boxShadow = active ? '0 0 0 1px rgba(124,231,219,.35) inset' : 'none';
                btn.style.background = active ? '#223347' : '#1a1d27';
            }}
        }}

        function setFocusMode(mode) {{
            activeFocusMode = mode || 'none';
            var count = applyQuickFilter(activeFocusMode);
            refreshFocusStateUi();
            var chip = document.getElementById('focus-state');
            if (!chip) return;
            if (activeFocusMode === 'none') {{
                chip.textContent = 'focused: none';
                return;
            }}
            var labels = {{
                'entry': 'entries',
                'unreachable': 'unreachable nodes',
                'dead_end': 'dead-end warnings',
                'terminal': 'terminal ends'
            }};
            var label = labels[activeFocusMode] || activeFocusMode.replace('_', '-');
            chip.textContent = count > 0 ? ('focused: ' + label + ' (' + String(count) + ')') : ('no ' + label);
            updateQaState();
        }}

        var lastTapNodeId = null;
        var lastTapAt = 0;

        cy.on('tap', 'node', function(evt) {{
            var node = evt.target;
            // Collapsed super-nodes are toggled additively; no detail panel.
            if (node.data('_isCollapsedGroup')) return;

            var isCtrl = !!(evt.originalEvent && (evt.originalEvent.ctrlKey || evt.originalEvent.metaKey));
            if (isCtrl) {{
                // Ctrl+click: additive multi-select — toggle dim based on selection
                setTimeout(function() {{
                    var sel = cy.$('node:selected');
                    if (sel.length > 1) {{
                        cy.elements().addClass('hl-dimmed');
                        sel.removeClass('hl-dimmed');
                        sel.connectedEdges().removeClass('hl-dimmed');
                    }} else {{
                        cy.elements().removeClass('hl-dimmed');
                    }}
                }}, 0);
                return;
            }}

            selectNode(node, false);

            var now = Date.now();
            var nodeId = String(node.id());
            if (lastTapNodeId === nodeId && (now - lastTapAt) <= 320) {{
                focusNode(node);
                lastTapNodeId = null;
                lastTapAt = 0;
            }} else {{
                lastTapNodeId = nodeId;
                lastTapAt = now;
            }}
        }});

        cy.on('tap', function(evt) {{
            if (evt.target === cy) {{
                document.getElementById('edge-info').style.display = 'none';
                clearNeighborHighlight();
                cy.elements().unselect();
            }}
        }});

        cy.on('tap', 'edge', function(evt) {{
            var edge = evt.target;
            var info = document.getElementById('edge-info');
            clearNeighborHighlight();
            cy.elements().unselect();
            var origins = edge.data('origins') || [];
            var count = Number(edge.data('count') || 1);
            var detail = (edge.data('kind') || edge.data('label') || 'edge');
            if (origins.length) detail += ' · ' + origins.join(', ');
            if (count > 1) detail += ' · merged x' + String(count);
            document.getElementById('edge-label').textContent = edge.data('source') + ' -> ' + edge.data('target');
            document.getElementById('edge-kind').textContent = ' (' + detail + ')';
            info.style.display = 'block';
        }});

        document.getElementById('fit-btn').addEventListener('click', function() {{ cy.fit(undefined, 30); }});
        document.getElementById('zoom-in-btn').addEventListener('click', function() {{
            cy.zoom({{ level: cy.zoom() * 1.2, renderedPosition: {{ x: cy.width() / 2, y: cy.height() / 2 }} }});
        }});
        document.getElementById('zoom-out-btn').addEventListener('click', function() {{
            cy.zoom({{ level: cy.zoom() * 0.84, renderedPosition: {{ x: cy.width() / 2, y: cy.height() / 2 }} }});
        }});
        document.getElementById('trace-mode').addEventListener('change', function() {{
            var selected = cy.$('node:selected');
            if (selected && selected.length) selectNode(selected[0], false);
        }});
        var layoutSel = document.getElementById('layout-mode');
        if (layoutSel) {{
            layoutSel.value = 'breadthfirst';
            layoutSel.addEventListener('change', function() {{
                var mode = String(layoutSel.value || 'cluster');
                applyLayout(mode);
                updateQaState();
            }});
        }}
        var groupPresetSel = document.getElementById('group-preset-mode');
        var groupStatusEl = document.getElementById('group-status-badge');
        function _updateGroupStatusBadge(preset, count) {{
            if (!groupStatusEl) return;
            if (preset === 'off') {{ groupStatusEl.style.display = 'none'; return; }}
            groupStatusEl.style.display = 'inline';
            if (count === 0) {{
                groupStatusEl.textContent = '\u2014 none found';
                groupStatusEl.style.color = '#555';
                groupStatusEl.style.border = 'none';
                groupStatusEl.style.background = 'transparent';
                var totalAcross = Object.keys(groupsByPreset).reduce(function(s, k) {{ return s + (groupsByPreset[k] || []).length; }}, 0);
                var tip;
                if (totalAcross > 0) {{
                    var better = ['aggressive','balanced','conservative'].filter(function(p) {{ return (groupsByPreset[p]||[]).length > 0; }}).map(function(p) {{ return p.charAt(0).toUpperCase()+p.slice(1); }});
                    tip = 'No structures at the ' + preset + ' level. Try: ' + better.join(' or ') + ' \u2014 that preset has results.';
                }} else if (preset === 'aggressive') {{
                    tip = 'No compressible structures found \u2014 even at Aggressive. This graph may be a pure branching story. Use right-click to collapse nodes manually.';
                }} else {{
                    tip = 'No structures at ' + preset + ' level. Try Aggressive \u2014 it uses shorter minimum chain length.';
                }}
                groupStatusEl.title = tip;
            }} else {{
                groupStatusEl.textContent = count + ' compressed';
                groupStatusEl.style.color = '#7ce7db';
                groupStatusEl.style.border = '1px solid #7ce7db';
                groupStatusEl.style.background = 'rgba(124,231,219,0.08)';
                groupStatusEl.title = count + ' structure(s) compressed. Right-click proxy node \u2192 Expand to restore.';
            }}
        }}
        if (groupPresetSel) {{
            groupPresetSel.addEventListener('change', function() {{
                var preset = groupPresetSel.value;
                // Swap active group list from precomputed groups_by_preset (same as VS Code applyPreset)
                cy.elements().remove();
                cy.add(elements);
                groupData = (preset === 'off') ? [] : (groupsByPreset[preset] || []);
                groupState = {{}};
                groupData.forEach(function(g) {{
                    groupState[g.group_id] = {{ collapsed: g.collapsed !== false, pinned: g.pinned, stale: g.stale }};
                }});
                if (preset !== 'off') {{
                    groupData.forEach(function(g) {{
                        var state = groupState[g.group_id];
                        if (state && state.collapsed !== false) _applyGroupCollapse(g);
                    }});
                }}
                // Re-run the active layout so nodes don't stack at default positions
                applyLayout(layoutSel ? layoutSel.value : 'breadthfirst');
                _updateGroupStatusBadge(preset, groupData.length);
            }});
        }}
        _updateGroupStatusBadge('off', 0);  // initial state is off
        var searchResults = [];
        var searchIndex = -1;
        var lastSearchQuery = '';

        function findAndFocusNode(cycle) {{
            var input = document.getElementById('node-search');
            var status = document.getElementById('search-status');
            var query = String(input && input.value || '').trim().toLowerCase();
            if (!query) {{
                searchResults = [];
                searchIndex = -1;
                lastSearchQuery = '';
                if (status) status.textContent = '';
                return;
            }}
            var changedQuery = query !== lastSearchQuery;
            if (changedQuery) {{
                searchResults = cy.nodes().filter(function(ele) {{
                    var label = String(ele.data('label') || ele.id() || '').toLowerCase();
                    return label.indexOf(query) >= 0;
                }});
                searchIndex = -1;
                lastSearchQuery = query;
            }}
            if (searchResults.length) {{
                if (changedQuery || !cycle) searchIndex = 0;
                else searchIndex = (searchIndex + 1) % searchResults.length;
                var target = searchResults[searchIndex];
                selectNode(target, true);
                if (status) status.textContent = '';
                if (status) status.textContent = 'Match ' + String(searchIndex + 1) + '/' + String(searchResults.length) + ' for "' + query + '" (Enter to cycle)';
            }} else {{
                if (status) status.textContent = 'No node found for "' + query + '"';
            }}
        }}
        document.getElementById('search-btn').addEventListener('click', function() {{ findAndFocusNode(false); }});
        document.getElementById('node-search').addEventListener('keydown', function(evt) {{
            if (evt.key === 'Enter') findAndFocusNode(true);
        }});
        document.getElementById('node-search').addEventListener('input', function() {{
            searchResults = [];
            searchIndex = -1;
            lastSearchQuery = '';
            var status = document.getElementById('search-status');
            if (status) status.textContent = '';
        }});
        document.getElementById('filter-entry').addEventListener('click', function() {{ setFocusMode('entry'); }});
        document.getElementById('filter-unreachable').addEventListener('click', function() {{ setFocusMode('unreachable'); }});
        document.getElementById('filter-dead-end').addEventListener('click', function() {{ setFocusMode('dead_end'); }});
        document.getElementById('filter-terminal').addEventListener('click', function() {{ setFocusMode('terminal'); }});
        document.getElementById('filter-clear').addEventListener('click', function() {{ setFocusMode('none'); }});
        var editorModeSel = document.getElementById('editor-mode');
        if (editorModeSel) {{
            var savedMode = localStorage.getItem('branchpy.flowchart.editorMode');
            if (savedMode) editorModeSel.value = savedMode;
            updateOpenButtonLabel(currentEditorMode());
            editorModeSel.addEventListener('change', function() {{
                localStorage.setItem('branchpy.flowchart.editorMode', String(editorModeSel.value || 'vscode'));
                updateOpenButtonLabel(currentEditorMode());
                var selected = cy.$('node:selected');
                if (selected && selected.length) renderNodeDetails(selected[0]);
            }});
        }}
        refreshFocusStateUi();
        updateQaState();

        // ── Manual Collapse v1 ────────────────────────────────────────────────
        // State: map of groupId → stored original elements + child ids
        var collapsedGroups = {{}};
        var collapseCounter = 0;
        var expandAllBtnEl = document.getElementById('expand-all-btn');
        var collapseHintEl = document.getElementById('collapse-hint');
        // Canonical snapshot taken before first collapse for Expand-All hard reset
        var canonicalSnapshot = null;

        function updateCollapseChrome() {{
            var hasGroups = Object.keys(collapsedGroups).length > 0;
            if (expandAllBtnEl) expandAllBtnEl.style.display = hasGroups ? 'inline-block' : 'none';
        }}

        function collapseHighlighted() {{
            // Snapshot before first collapse so Expand All can restore the pristine graph
            if (!canonicalSnapshot) canonicalSnapshot = cy.elements().jsons();

            var selected = cy.$('node:selected').filter(function(n) {{ return !n.data('_isCollapsedGroup'); }});
            // Also allow collapsing collapsed groups together with regular nodes
            var allSelected = cy.$('node:selected');
            if (allSelected.length < 2) return;

            var selectedIds = {{}};
            allSelected.forEach(function(n) {{ selectedIds[n.id()] = true; }});
            var groupId = '__mc_' + (collapseCounter++);

            // Boundary edges: exactly one endpoint inside selection
            var boundaryEdges = [];
            var seenBoundaryKey = {{}};
            cy.edges().forEach(function(e) {{
                var s = e.source().id(), t = e.target().id();
                var sIn = !!selectedIds[s], tIn = !!selectedIds[t];
                if (sIn !== tIn) boundaryEdges.push(e);
            }});

            // Centroid position
            var sumX = 0, sumY = 0, cnt = 0;
            allSelected.forEach(function(n) {{
                sumX += n.position('x'); sumY += n.position('y'); cnt++;
            }});
            var cx = cnt ? sumX / cnt : 0, cy_y = cnt ? sumY / cnt : 0;

            // Pick label from first non-group node
            var firstName = '';
            allSelected.forEach(function(n) {{
                if (!firstName && !n.data('_isCollapsedGroup')) firstName = String(n.data('label') || n.id());
            }});
            var label = firstName + ' +' + String(allSelected.length - 1);

            // Store originals
            var storedNodes = [];
            allSelected.forEach(function(n) {{
                storedNodes.push({{ data: JSON.parse(JSON.stringify(n.data())), position: {{ x: n.position('x'), y: n.position('y') }} }});
            }});
            var storedEdges = [];
            cy.edges().forEach(function(e) {{
                var s = e.source().id(), t = e.target().id();
                if (!!selectedIds[s] || !!selectedIds[t]) {{
                    storedEdges.push({{ data: JSON.parse(JSON.stringify(e.data())) }});
                }}
            }});

            collapsedGroups[groupId] = {{ nodes: storedNodes, edges: storedEdges, childIds: selectedIds }};

            // Remove selected nodes (Cytoscape auto-removes connected edges)
            cy.remove(allSelected);

            // Add super-node
            cy.add({{ data: {{
                id: groupId, label: label, display_label: label,
                _isCollapsedGroup: true, _childCount: cnt, _groupId: groupId
            }}, position: {{ x: cx, y: cy_y }} }});

            // Collapsed indicator: double border only — preserves original type color.
            // No border-color override so the :selected rule can apply its white border freely.
            cy.$('#' + groupId).style({{
                'border-style': 'double',
                'border-width': 4,
                'width': Math.max(60, Math.min(120, 30 + cnt * 2)),
                'height': Math.max(30, Math.min(60, 20 + cnt))
            }});

            // Add deduplicated boundary edges
            var seenBe = {{}};
            boundaryEdges.forEach(function(e) {{
                var s = e.source().id(), t = e.target().id();
                var realS = !!selectedIds[s] ? groupId : s;
                var realT = !!selectedIds[t] ? groupId : t;
                var ek = realS + '__' + realT;
                if (!seenBe[ek]) {{
                    seenBe[ek] = true;
                    cy.add({{ data: {{
                        id: '__be_' + groupId + '_' + ek,
                        source: realS, target: realT,
                        _boundaryOf: groupId,
                        label: '', kind: 'boundary', origins: [], origin: '', count: 1
                    }} }});
                }}
            }});

            cy.elements().unselect();
            updateCollapseChrome();
        }}

        function expandGroup(groupId) {{
            var stored = collapsedGroups[groupId];
            if (!stored) return;
            // Remove super-node and its boundary edges (filter avoids selector-escaping issues)
            cy.remove(cy.$('#' + groupId));
            cy.edges().filter(function(e) {{ return e.data('_boundaryOf') === groupId; }}).remove();
            // Restore original nodes at stored positions; re-apply size style for nested groups
            stored.nodes.forEach(function(n) {{
                cy.add({{ group: 'nodes', data: n.data, position: n.position }});
                if (n.data._isCollapsedGroup) {{
                    var cnt = n.data._childCount || 1;
                    cy.$('#' + n.data.id).style({{
                        'border-style': 'double',
                        'border-width': 4,
                        'width': Math.max(60, Math.min(120, 30 + cnt * 2)),
                        'height': Math.max(30, Math.min(60, 20 + cnt))
                    }});
                }}
            }});
            // Restore original edges (skip if endpoints not present)
            stored.edges.forEach(function(e) {{
                try {{
                    if (cy.getElementById(e.data.source).length && cy.getElementById(e.data.target).length) {{
                        cy.add({{ group: 'edges', data: e.data }});
                    }}
                }} catch(_) {{}}
            }});
            delete collapsedGroups[groupId];
            updateCollapseChrome();
            cy.fit(undefined, 30);
        }}

        function expandAll() {{
            if (canonicalSnapshot) {{
                // Hard reset from pristine snapshot — safe for nested collapse hierarchies
                cy.elements().remove();
                cy.add(canonicalSnapshot);
                Object.keys(collapsedGroups).forEach(function(k) {{ delete collapsedGroups[k]; }});
                updateCollapseChrome();
                cy.fit(undefined, 30);
            }} else {{
                Object.keys(collapsedGroups).forEach(function(gid) {{ expandGroup(gid); }});
            }}
        }}

        // Right-click context menu
        var ctxMenu = document.getElementById('cy-context-menu');
        var ctxCollapse = document.getElementById('ctx-collapse');
        var ctxExpandGroup = document.getElementById('ctx-expand-group');
        var ctxExpandAll = document.getElementById('ctx-expand-all');
        var ctxTargetGroupId = null;

        function hideCtxMenu() {{ if (ctxMenu) ctxMenu.style.display = 'none'; ctxTargetGroupId = null; }}

        cy.on('cxttap', 'node', function(evt) {{
            if (!ctxMenu) return;
            var node = evt.target;
            var selectedCount = cy.$('node:selected').length;
            ctxTargetGroupId = null;

            if (node.data('_isCollapsedGroup')) {{
                // Manual collapsed group
                ctxTargetGroupId = node.data('_groupId');
                if (ctxExpandGroup) {{ ctxExpandGroup.style.display = 'block'; ctxExpandGroup.textContent = 'Expand This Group (' + String(node.data('_childCount') || '?') + ' nodes)'; }}
                // Also offer Collapse if 2+ nodes are selected (group can be merged with others)
                if (ctxCollapse) {{
                    if (selectedCount >= 2) {{
                        var extra = ' (' + String(selectedCount) + ' selected)';
                        ctxCollapse.textContent = 'Collapse Highlighted Nodes' + extra;
                        ctxCollapse.style.opacity = '1';
                        ctxCollapse.style.display = 'block';
                    }} else {{
                        ctxCollapse.style.display = 'none';
                    }}
                }}
            }} else if (node.data('group_collapsed') === 'true') {{
                // Auto-group proxy (M1/M2/M3 semantic-compression)
                ctxTargetGroupId = node.data('group_id');
                var memberCount = node.data('member_count') || '?';
                if (ctxExpandGroup) {{ ctxExpandGroup.style.display = 'block'; ctxExpandGroup.textContent = 'Expand group (\u25c8 ' + String(memberCount) + ' nodes)'; }}
                if (ctxCollapse) ctxCollapse.style.display = 'none';
            }} else {{
                // Regular node
                if (ctxCollapse) {{
                    ctxCollapse.style.display = 'block';
                    var extra = selectedCount > 1 ? ' (' + String(selectedCount) + ' selected)' : '';
                    ctxCollapse.textContent = 'Collapse Highlighted Nodes' + extra;
                    ctxCollapse.style.opacity = selectedCount >= 2 ? '1' : '0.45';
                }}
                if (ctxExpandGroup) ctxExpandGroup.style.display = 'none';
            }}

            var hasGroups = Object.keys(collapsedGroups).length > 0;
            if (ctxExpandAll) ctxExpandAll.style.opacity = hasGroups ? '1' : '0.45';

            ctxMenu.style.left = (evt.originalEvent.clientX + 2) + 'px';
            ctxMenu.style.top = (evt.originalEvent.clientY + 2) + 'px';
            ctxMenu.style.display = 'block';
        }});

        cy.on('tap', function() {{ hideCtxMenu(); }});
        document.addEventListener('click', function() {{ hideCtxMenu(); }}, false);
        document.addEventListener('keydown', function(e) {{ if (e.key === 'Escape') hideCtxMenu(); }});

        function setupCtxItem(el, fn) {{
            if (!el) return;
            el.addEventListener('mouseenter', function() {{ el.style.background = '#2a2d3a'; }});
            el.addEventListener('mouseleave', function() {{ el.style.background = ''; }});
            el.addEventListener('click', function(e) {{ e.stopPropagation(); fn(); hideCtxMenu(); }});
        }}

        setupCtxItem(ctxCollapse, function() {{
            if (cy.$('node:selected').length >= 2) collapseHighlighted();
        }});
        setupCtxItem(ctxExpandGroup, function() {{
            if (!ctxTargetGroupId) return;
            // Auto-group proxy: find the matching groupData entry and restore members
            var autoGroup = groupData.find ? groupData.find(function(g) {{ return g.group_id === ctxTargetGroupId; }}) : null;
            if (autoGroup) {{
                _expandAutoGroup(autoGroup);
            }} else {{
                expandGroup(ctxTargetGroupId);
            }}
        }});
        setupCtxItem(ctxExpandAll, function() {{ expandAll(); }});

        if (expandAllBtnEl) {{
            expandAllBtnEl.addEventListener('click', function() {{ expandAll(); }});
        }}

        // Hover tooltips
        var cyTooltip = document.getElementById('cy-tooltip');
        cy.on('mouseover', 'node', function(evt) {{
            var d = evt.target.data() || {{}};
            var label = String(d.label || d.id || '');
            var file = String(d.file || d.path || '');
            var line = d.line || d.line_start || '';
            var text = label;
            if (d.is_reachable === false) text += '\\nunreachable';
            if (d.terminal_end === true) text += '\\nterminal end';
            if (d.dead_end === true) text += '\\ndead end';
            if (file && file !== '(not provided)') {{
                text += '\\n' + file;
                if (line) text += ':' + String(line);
            }}
            cyTooltip.textContent = text;
            cyTooltip.style.display = 'block';
        }});
        cy.on('mouseout', 'node', function() {{ cyTooltip.style.display = 'none'; }});
        cy.on('mouseover', 'edge', function(evt) {{
            var d = evt.target.data() || {{}};
            var kind = String(d.kind || d.label || 'edge');
            var origin = String(d.origin || '');
            var count = Number(d.count || 1);
            var text = kind;
            if (origin) text += '\\norigin: ' + origin;
            if (count > 1) text += '\\ncount: ' + String(count);
            cyTooltip.textContent = text;
            cyTooltip.style.display = 'block';
        }});
        cy.on('mouseout', 'edge', function() {{ cyTooltip.style.display = 'none'; }});
        document.getElementById('cy').addEventListener('mousemove', function(e) {{
            cyTooltip.style.left = (e.clientX + 14) + 'px';
            cyTooltip.style.top = (e.clientY - 10) + 'px';
        }});

        // ── Panel collapse / expand controls ─────────────────────────────────
        function adjustMainLayout() {{
            var ml = document.getElementById('main-layout');
            if (!ml) return;
            var rect = ml.getBoundingClientRect();
            var h = Math.max(520, window.innerHeight - rect.top - 24);
            ml.style.height = h + 'px';
            cy.resize();
        }}

        var ctrlBand = document.getElementById('top-controls-band');
        var ctrlBtn = document.getElementById('controls-toggle-btn');
        if (ctrlBtn && ctrlBand) {{
            ctrlBtn.addEventListener('click', function() {{
                var hidden = ctrlBand.style.display === 'none';
                ctrlBand.style.display = hidden ? '' : 'none';
                ctrlBtn.innerHTML = hidden ? '&#9660; Controls' : '&#9654; Controls';
                requestAnimationFrame(adjustMainLayout);
            }});
        }}

        var sideEl = document.getElementById('side-panel');
        var sideBtnEl = document.getElementById('side-panel-btn');
        if (sideBtnEl && sideEl) {{
            sideBtnEl.addEventListener('click', function() {{
                var hidden = sideEl.style.display === 'none';
                sideEl.style.display = hidden ? '' : 'none';
                sideBtnEl.innerHTML = hidden ? '&#8856; Panel' : '&#9655; Panel';
                requestAnimationFrame(function() {{ cy.resize(); }});
            }});
        }}

        // Help panel — slides in from the right; mutually exclusive with side-panel
        var helpEl = document.getElementById('help-panel');
        var helpBtnEl = document.getElementById('help-panel-btn');
        var helpCloseEl = document.getElementById('help-panel-close');
        var sidePanelWasVisible = true;  // track whether side panel was visible before help opened

        function openHelp() {{
            if (!helpEl) return;
            // Collapse the info panel if it's visible so we don't overlap content
            sidePanelWasVisible = sideEl ? sideEl.style.display !== 'none' : false;
            if (sideEl && sidePanelWasVisible) {{
                sideEl.style.display = 'none';
                if (sideBtnEl) sideBtnEl.innerHTML = '&#9655; Panel';
                requestAnimationFrame(function() {{ cy.resize(); }});
            }}
            helpEl.style.right = '0';
            if (helpBtnEl) {{ helpBtnEl.style.borderColor = '#7ce7db'; helpBtnEl.style.color = '#7ce7db'; }}
        }}
        function closeHelp() {{
            if (!helpEl) return;
            helpEl.style.right = '-380px';
            if (helpBtnEl) {{ helpBtnEl.style.borderColor = '#2a2d3a'; helpBtnEl.style.color = '#7a7d8c'; }}
            // Restore side panel to previous state (but don't force-expand if it was closed)
            if (sideEl && sidePanelWasVisible) {{
                sideEl.style.display = '';
                if (sideBtnEl) sideBtnEl.innerHTML = '&#8856; Panel';
                requestAnimationFrame(function() {{ cy.resize(); }});
            }}
        }}
        if (helpBtnEl) {{
            helpBtnEl.addEventListener('click', function() {{
                var isOpen = helpEl && helpEl.style.right === '0px';
                if (isOpen) {{ closeHelp(); }} else {{ openHelp(); }}
            }});
        }}
        if (helpCloseEl) {{
            helpCloseEl.addEventListener('click', closeHelp);
        }}

        window.addEventListener('resize', adjustMainLayout);
        requestAnimationFrame(adjustMainLayout);
        // ─────────────────────────────────────────────────────────────────────

        cy.fit(undefined, 30);

        // Clear loading state
        var loadingMsg = document.getElementById('cy-loading-msg');
        if (loadingMsg) loadingMsg.remove();
    }}

    initCy();
}})();
</script>
"""

    if not cy_elements:
        body = (
            f"<h1>BranchPy Flowchart — {project_name}</h1>\n"
            '<p class="meta">No graph data found. Run <code>branchpy --project '
            f"{project_name} analyze --format json</code> first to generate story data.</p>\n"
        )

    page = _html_wrap(f"Flowchart — {project_name} · BranchPy", body)

    target = out_path or _default_html_path(project_root, "flowchart")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(page, encoding="utf-8")
    return target
