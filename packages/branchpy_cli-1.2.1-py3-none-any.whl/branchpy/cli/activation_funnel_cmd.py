"""
BranchPy CLI — Activation Funnel Upload

Uploads locally-stored activation funnel events (written by the VS Code
extension's ActivationFunnelWriter) to the BranchPy telemetry backend.

This command is called automatically by the VS Code extension on each
activation to flush pending events.  It is designed to be silent and
idempotent — the server ignores duplicate event_ids via ON CONFLICT DO NOTHING.

File read: <getBranchPyBase()>/telemetry/activation_funnel.jsonl
Endpoint : POST https://api.branchpy.com/api/telemetry/upload
Auth     : Bearer <telemetry_token> from ~/.branchpy/auth.json  (Windows: %LOCALAPPDATA%/BranchPy/auth.json)
"""

import json
import os
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Platform-aware base path (mirrors branchpyPaths.ts getBranchPyBase())
# ---------------------------------------------------------------------------

def _get_branchpy_base() -> Path:
    if platform.system() == "Windows":
        local = os.environ.get("LOCALAPPDATA") or str(
            Path.home() / "AppData" / "Local"
        )
        return Path(local) / "BranchPy"
    return Path.home() / ".branchpy"


def _get_activation_funnel_path() -> Path:
    return _get_branchpy_base() / "telemetry" / "activation_funnel.jsonl"


def _get_auth_path() -> Path:
    return _get_branchpy_base() / "auth.json"


# ---------------------------------------------------------------------------
# Auth token resolution
# ---------------------------------------------------------------------------

def _read_telemetry_token() -> Optional[str]:
    """Read telemetry_token from ~/.branchpy/auth.json written by the VS Code extension."""
    auth_path = _get_auth_path()
    try:
        with auth_path.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data.get("telemetry_token") or None
    except (OSError, json.JSONDecodeError):
        return None


# ---------------------------------------------------------------------------
# Device ID hash (matches package_builder.py generate_device_id_hash())
# ---------------------------------------------------------------------------

def _generate_device_id_hash() -> str:
    import hashlib
    import socket

    fingerprint = "|".join([
        platform.system(),
        platform.machine(),
        socket.gethostname(),
    ])
    first = hashlib.sha256(fingerprint.encode("utf-8")).hexdigest()
    return hashlib.sha256(first.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# Event loading
# ---------------------------------------------------------------------------

def _load_uploadable_events(funnel_path: Path) -> List[Dict[str, Any]]:
    """
    Read funnel JSONL and return only events eligible for remote upload.
    Skips lines that are malformed or have local_only=true.
    """
    if not funnel_path.exists():
        return []

    events: List[Dict[str, Any]] = []
    try:
        with funnel_path.open("r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if rec.get("local_only"):
                    continue
                events.append(rec)
    except OSError:
        pass
    return events


# ---------------------------------------------------------------------------
# Package assembly
# ---------------------------------------------------------------------------

def _build_package(events: List[Dict[str, Any]], device_id_hash: str) -> Dict[str, Any]:
    """
    Assemble a TelemetryPackage v1.0.0 from activation funnel events.

    The server's normalizeEvent() stores:
        event_type, timestamp, device_id_hash, metadata (JSONB)

    adminOnboardingFunnelRouter.js reads metadata->>'client_version', so we
    fold client_version + platform + event payload into the metadata field.
    """
    now = datetime.now(timezone.utc).isoformat()

    # Determine time range from events (fall back to now)
    timestamps = [e.get("timestamp", now) for e in events]
    time_start = min(timestamps) if timestamps else now
    time_end = max(timestamps) if timestamps else now

    # Detect client (extension) version from first event if available
    first_version = events[0].get("client_version", "unknown") if events else "unknown"

    normalized_events = []
    for evt in events:
        metadata: Dict[str, Any] = {}
        # Propagate envelope fields the dashboard queries
        if evt.get("client_version"):
            metadata["client_version"] = evt["client_version"]
        if evt.get("platform"):
            metadata["platform"] = evt["platform"]
        if evt.get("submodule"):
            metadata["submodule"] = evt["submodule"]
        # Merge payload into metadata (no nested object; server stores JSONB flat)
        payload = evt.get("payload") or {}
        if isinstance(payload, dict):
            metadata.update(payload)

        normalized_events.append({
            "event_id": evt.get("event_id"),
            "event_type": evt.get("event_type", "unknown"),
            "timestamp": evt.get("timestamp", now),
            "metadata": metadata,
        })

    return {
        "schema_version": "1.0.0",
        "generated_at": now,
        "time_range_start": time_start,
        "time_range_end": time_end,
        "device_id_hash": device_id_hash,
        "client": {
            "vscode_extension_version": first_version,
        },
        "events": normalized_events,
    }


# ---------------------------------------------------------------------------
# HTTP upload (stdlib only — no requests dependency required here)
# ---------------------------------------------------------------------------

def _upload(package: Dict[str, Any], endpoint: str, token: Optional[str]) -> bool:
    """POST package to endpoint.  Returns True on success (2xx)."""
    import urllib.request

    body = json.dumps(package).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    req = urllib.request.Request(endpoint, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return 200 <= resp.status < 300
    except Exception:
        return False


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main(argv: Optional[List[str]] = None) -> int:
    """
    Usage: python -m branchpy.cli.activation_funnel_cmd upload [--dry-run] [--verbose]

    Exit codes:
        0 — success (or nothing to upload)
        1 — upload failed (network / auth error)
        2 — no auth token available (silently skipped)
    """
    import argparse

    parser = argparse.ArgumentParser(
        prog="activation_funnel_cmd",
        description="Upload activation funnel events to BranchPy telemetry.",
    )
    sub = parser.add_subparsers(dest="cmd")

    upload_p = sub.add_parser("upload", help="Upload pending funnel events")
    upload_p.add_argument("--dry-run", action="store_true", help="Print what would be sent, do not POST")
    upload_p.add_argument("--verbose", "-v", action="store_true", help="Show progress messages")
    upload_p.add_argument(
        "--endpoint",
        default="https://api.branchpy.com/api/telemetry/upload",
        help="Override upload endpoint",
    )

    args = parser.parse_args(argv if argv is not None else sys.argv[1:])

    if args.cmd != "upload":
        parser.print_help()
        return 0

    verbose: bool = args.verbose
    dry_run: bool = args.dry_run
    endpoint: str = args.endpoint

    # --- Load events ---
    funnel_path = _get_activation_funnel_path()
    events = _load_uploadable_events(funnel_path)

    if not events:
        if verbose:
            print(f"[funnel-upload] No uploadable events in {funnel_path}", flush=True)
        return 0

    if verbose:
        print(f"[funnel-upload] {len(events)} event(s) to upload", flush=True)

    # --- Auth token ---
    token = _read_telemetry_token()
    if not token:
        if verbose:
            print("[funnel-upload] No telemetry_token in auth.json — skipping", flush=True)
        return 2

    # --- Build package ---
    device_id_hash = _generate_device_id_hash()
    package = _build_package(events, device_id_hash)

    if dry_run:
        print(json.dumps(package, indent=2))
        return 0

    # --- Upload ---
    ok = _upload(package, endpoint, token)
    if ok:
        if verbose:
            print(f"[funnel-upload] Uploaded {len(events)} event(s) successfully", flush=True)
        return 0
    else:
        if verbose:
            print("[funnel-upload] Upload failed", flush=True)
        return 1


if __name__ == "__main__":
    sys.exit(main())
