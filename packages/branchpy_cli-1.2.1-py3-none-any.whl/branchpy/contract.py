# branchpy/contract.py

"""
BranchPy contract: VERSION constant, schema paths, and base output folder.
"""
try:
    from importlib.metadata import version as _pkg_version
    VERSION = _pkg_version("branchpy-cli")
except Exception:
    VERSION = "1.1.24"  # fallback if package metadata unavailable


class Exit(IntError := int):
    OK = 0  # ran, no issues
    ISSUES_FOUND = 1  # ran, issues present
    LIC_INVALID = 2
    LIC_NETWORK = 3
    INTERNAL = 10


ISSUE_KINDS = (
    "missing_media",
    "unused_media",
    "missing_label",
    "unused_label",
    "missing_jump_target",
    "orphan_label",
    "dead_end_label",
    "stat_inconsistency",
    "duplicate_variable",
    "dynamic_unresolved",
)


def json_boilerplate():
    return {
        "version": VERSION,
        "license": {"plan": "free", "valid": True, "expires": None},
        "summary": {"files": 0, "labels": 0, "issues": 0},
        "issues": [],  # list of {kind, path, line, value, severity}
    }
