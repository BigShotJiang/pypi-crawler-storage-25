# ...existing imports...
import argparse
import importlib
import sys
import time
import uuid
from pathlib import Path
from typing import Dict, Tuple

# Import structured logging
from . import logs
from .cli_help import HelpFmt, fmt_examples
from .contract import VERSION

# =============================================================================
# Lazy Command Registry — Phase 4 v0.7.19
# =============================================================================
# Command map: name -> (module_path, add_parser_func, run_func)
# This prevents eager imports - modules only loaded when command is invoked
_CMD_MAP: Dict[str, Tuple[str, str, str]] = {
    # Core commands with run() entry points
    "analyze": ("branchpy.commands.analyze_cmd", "add_parser", "main"),
    "flowchart": ("branchpy.commands.flowchart_cmd", "add_parser", "run"),
    "compare": ("branchpy.commands.compare_cmd", "add_parser", "run"),
    "report": ("branchpy.commands.report_cmd", "add_parser", "cmd_report"),
    "debug": ("branchpy.cli.debug_cmd", "add_parser", "run"),
    "serve": ("branchpy.commands.serve_cmd", "add_parser", "run"),
    "tests": ("branchpy.commands.tests_cmd", "add_parser", "run"),
    "test": ("branchpy.commands.cmd_test", "add_parser", "run"),  # Alias
    "media": ("branchpy.commands.media_cmd", "add_parser", "run"),
    "stats": ("branchpy.commands.stats_cmd", "add_parser", "run"),
    "pilot": (
        "branchpy.commands.stats2_cmd",
        "register_command",
        "run",
    ),  # Renamed from stats2
    "stats2": (
        "branchpy.commands.stats2_cmd",
        "register_command",
        "run",
    ),  # Legacy alias for pilot
    "omega": (
        "branchpy.commands.omega_cmd",
        "add_parser",
        "run",
    ),  # State-space analysis from PILOT
    "insights": (
        "branchpy.commands.insights_cmd",
        "add_parser",
        "run",
    ),  # InsightSummary: normalized L2 flattening of current run
    "guard": ("branchpy.commands.guard_cmd", "add_parser", "run"),
    "doctor": ("branchpy.commands.doctor_cmd", "add_parser", "run"),
    "logs": ("branchpy.commands.logs_cmd", "add_parser", "run"),
    "support": ("branchpy.commands.support_cmd", "add_parser", "run"),
    "policy": (
        "branchpy.cli.policy_cmd",
        "add_parser",
        "run",
    ),  # Click-based with argparse bridge
    "watch": ("branchpy.commands.watch_cmd", "add_parser", "run"),
    "dev": ("branchpy.commands.dev_cmd", "add_parser", "run"),
    "migrate": ("branchpy.commands.migrate_cmd", "add_parser", "run"),
    "help": ("branchpy.commands.help_cmd", "add_parser", "run"),
    "validate": (
        "branchpy.commands.validate_cmd",
        "add_parser",
        "run",
    ),  # Image Validation V3
    # Commands with custom handler registration (use add_parser conventions)
    "projects": ("branchpy.commands.projects_cmd", "add_parser", "run"),
    "patches": ("branchpy.commands.patches_cmd", "add_parser", "cmd_patches"),
    "patch": (
        "branchpy.cli.commands.patch_cmd",
        "add_parser",
        "run",
    ),  # v0.9.9 - Patch Engine Core
    "undo": (
        "branchpy.cli.commands.undo_cmd",
        "undo",
        "undo",
    ),  # v0.9.1.5 - History Timeline
    "redo": (
        "branchpy.cli.commands.redo_cmd",
        "redo",
        "redo",
    ),  # v0.9.1.5 - History Timeline
    "config": ("branchpy.commands.config_cmd", "add_parser", "run"),
    "renpy": ("branchpy.commands.renpy_cmd", "add_parser", "run"),
    "semantics": (
        "branchpy.commands.semantics_cmd",
        "register_semantics_parser",
        "cmd_semantics",
    ),
    "semantics2": (
        "branchpy.cli.commands.semantics_v2_cmd",
        "register_semantics_parser",
        "cmd_semantics",
    ),  # v0.9.4 Phase 2 Semantics V2
    "semantics-engine": (
        "branchpy.commands.semantics_engine_cmd",
        "add_parser",
        "run",
    ),  # v0.9.6 SemanticsV2Engine orchestrator
    # Namespace dispatcher (l10n_cmd already has lazy loading internally)
    "l10n": ("branchpy.commands.l10n_cmd", "add_parser", "run"),
    # Phase 3A: Automatic trace generation management
    "trace": ("branchpy.commands.trace_cmd", "add_parser", "run"),
    # License commands
    "activate": ("branchpy.commands.cmd_activate", "build", "run"),
    "status": ("branchpy.commands.cmd_status", "build", "run"),
    "deactivate": ("branchpy.commands.cmd_deactivate", "build", "run"),
    # WebSocket daemon (v0.7.21)
    "ws": ("branchpy.cli.commands.ws_cmd", "build_arg_parser", "run_ws_cmd"),
    # Team Audit Log (v0.8.1)
    "identity": ("branchpy.commands.identity_cmd", "add_parser", "run"),
    "audit": ("branchpy.commands.audit_cmd", "add_parser", "run"),
    # Server Daemon Management (v0.8.5)
    "server": ("branchpy.cli.server_cmd", "add_parser", "main"),
    # Project Function Index (v0.8.9)
    "pfi": ("branchpy.commands.pfi_cmd", "add_pfi_subcommand", "run_pfi_command"),
    # Media Export (v0.9.0.2)
    "export-media": (
        "branchpy.cli.commands.export_media_cmd",
        "export_media",
        "export_media",
    ),
    # Telemetry (v0.9.1.2 H4-G5)
    "telemetry": ("branchpy.cli.telemetry_cmd", "add_parser", "run"),
    # Interactive Diff (v0.9.1.4 Compare UX)
    "interactive-diff": ("branchpy.commands.interactive_diff_cmd", "add_parser", "run"),
    # Journal (v0.9.1.5 Unified Timeline)
    "journal": ("branchpy.cli.commands.journal_cmd", "journal", "journal"),
    # Merge (v0.9.1.5 Safe Merge Engine)
    "merge": ("branchpy.cli.commands.merge_cmd", "merge", "merge"),
    # Bootstrap Doctor (v0.9.2 WS-R2)
    "bootstrap": (
        "branchpy.commands.bootstrap_cmd",
        "add_parser",
        "cmd_bootstrap_remote",
    ),
    # Hub + Identity + Projects (v0.9.3 Federation & Cloud)
    "login": ("branchpy.cli.commands.identity_hub_cmd", "add_parser", "run"),
    "whoami": ("branchpy.cli.commands.identity_hub_cmd", "add_parser", "run"),
    "logout": ("branchpy.cli.commands.identity_hub_cmd", "add_parser", "run"),
    "federation": ("branchpy.cli.commands.federation_cmd", "add_parser", "run"),
    "templates": ("branchpy.cli.commands.templates_cmd", "add_parser", "run"),
    # AI Features (v0.9.5)
    "ai": ("branchpy.cli.ai_cli", "add_ai_subparser", "handle_ai_command"),
    # Cloud Mock (v0.9.5)
    "cloud": ("branchpy.cli.cloud_cli", "add_cloud_subparser", "handle_cloud_command"),
    # Auto-Detect → BQF Policy Conversion (v0.9.6)
    "auto-detect": ("branchpy.cli.commands.auto_detect_cmd", "add_parser", "run"),
    # Analyzer (Phase C v0.9.7 - Engine Adapters with ScriptGraph + PFI)
    "analyzer": ("branchpy.commands.analyzer_media_cmd", "add_parser", "run"),
    # License Management (v1.0.0)
    "license": ("branchpy.cli.commands.license_cmd", "add_parser", "run"),
    # Image Validation panel pipeline (v1.1 real data)
    "image-validate": ("branchpy.commands.image_validate_cmd", "add_parser", "run"),
    # Uninstall (v1.1.12) — remove CLI, VS Code extension, optional local data
    "uninstall": ("branchpy.commands.uninstall_cmd", "add_parser", "run"),
    # Getting-started welcome guide for CLI-only (non-VS Code) users
    "welcome": ("branchpy.commands.welcome_cmd", "add_parser", "run"),
}


def _project_size_bucket(project_path) -> str:
    """
    Estimate project size as a privacy-safe bucket.

    Counts script files in the project directory up to a shallow depth
    to avoid performance impact on large projects.

    Returns "small" (<20 files), "medium" (20–100), or "large" (>100).
    Falls back to "unknown" on any error.
    """
    try:
        _SCRIPT_EXTS = {".rpy", ".gd", ".cs", ".ink", ".yarn", ".twee", ".js", ".py"}
        count = 0
        root = Path(project_path)
        for depth, dirpath in enumerate(root.rglob("*")):
            if count > 100:
                return "large"
            if dirpath.suffix.lower() in _SCRIPT_EXTS and dirpath.is_file():
                count += 1
        if count < 20:
            return "small"
        if count <= 100:
            return "medium"
        return "large"
    except Exception:
        return "unknown"


def _safe_argv_summary(argv: list) -> dict:
    """
    Privacy-safe summary of argv:
    - Keep flags (e.g. --project, -v)
    - Keep bare command token (first non-flag token)
    - Do NOT keep values, paths, or user-provided strings
    """
    flags = []
    command_token = None

    for tok in argv:
        if tok.startswith("-"):
            # record flags only; strip any '=value'
            flags.append(tok.split("=", 1)[0])
        else:
            if command_token is None:
                command_token = tok
            # do not record positional args beyond the command token

    return {
        "command_token": command_token,
        "flags": flags[:25],  # cap to avoid huge payload
        "argc": len(argv),
    }


def _emit_parse_error_telemetry(
    command: str | None, argv: list, err: BaseException, exit_code: int
) -> None:
    """
    Emit telemetry for parse errors (stage='parse') with safe argv summary.

    Args:
        command: Command name if known, else None
        argv: Original argv list
        err: Exception that was raised
        exit_code: Exit code to return
    """
    try:
        from branchpy.telemetry import collector as telemetry_collector

        # Avoid emitting on standard help flows
        argv_l = [a.lower() for a in argv]
        if ("-h" in argv_l) or ("--help" in argv_l):
            return

        props = {
            "stage": "parse",
            "command": command or "unknown",
            "exit_code": int(exit_code),
            "error_type": type(err).__name__,
            "error_hash": telemetry_collector.hash_error(str(err)),
            **_safe_argv_summary(argv),
        }

        telemetry_collector.emit("cli.command.error", props)
    except Exception:
        # Never let telemetry block CLI behavior
        return


def _lazy_import_command(cmd_name: str):
    """Import command module on demand and return (module, add_parser_func, run_func)"""
    if cmd_name not in _CMD_MAP:
        return None, None, None
    mod_path, parser_func_name, run_func_name = _CMD_MAP[cmd_name]
    try:
        mod = importlib.import_module(mod_path)
        parser_func = getattr(mod, parser_func_name, None)
        run_func = getattr(mod, run_func_name, None)
        return mod, parser_func, run_func
    except (ImportError, AttributeError) as e:
        print(f"[BranchPy] Failed to load command '{cmd_name}': {e}", file=sys.stderr)
        return None, None, None


# Dispatcher adapter to unpack args for handlers that expect individual parameters


def _coerce_project(p):
    """Coerce project parameter to a Path-like object."""
    if isinstance(p, (str, Path)):
        return str(Path(p))
    elif isinstance(p, bytes):
        return str(Path(p.decode()))
    # Tolerate Namespace if someone refactors and forgets
    if hasattr(p, "project"):
        return str(Path(p.project))
    raise TypeError(f"project must be path-like, got {type(p).__name__}")


def call_tests(handler, args):
    """Centralized dispatcher for tests command."""
    return handler(
        project=_coerce_project(args.project),
        out=getattr(args, "out", None),
        as_json=(getattr(args, "format", "text") == "json"),
        dot_path=getattr(args, "dot", None),
        png_path=getattr(args, "png", None),
        dry_run=getattr(args, "dry_run", False),
        save_report=getattr(args, "save_report", False),
        matrix=getattr(args, "matrix", None),
        args=args,  # Pass args for emit settings
    )


def call_media(handler, args):
    """Centralized dispatcher for media command."""
    # Handle media subcommands (missing/unused/referenced)
    command = None
    if getattr(args, "missing", False):
        command = "missing"
    elif getattr(args, "unused", False):
        command = "unused"
    elif getattr(args, "referenced", False):
        command = "referenced"

    return handler(
        command=command,
        project=_coerce_project(args.project),
        assets=getattr(args, "assets", "game"),
        ext=getattr(args, "ext", None),
        as_json=getattr(args, "json", False),
        fail_on_unused=getattr(args, "fail_on_unused", False),
        ignore=getattr(args, "ignore", None),
        out=getattr(args, "out", None),
        html=getattr(args, "html", False),
        open_browser=getattr(args, "open_browser", False),
        args=args,  # Pass args for emit settings
    )


def call_stats(handler, args):
    """Centralized dispatcher for stats command."""
    return handler(
        project=_coerce_project(args.project),
        as_json=(getattr(args, "format", "text") == "json"),
        out=getattr(args, "out", None),
        args=args,  # Pass args for emit settings
    )


def call_guard(handler, args):
    """Centralized dispatcher for guard command."""
    return handler(
        action=getattr(args, "action", None),
        project=_coerce_project(args.project),
        assets=getattr(args, "assets", "game"),
        checks=getattr(args, "checks", "missing,unused,stats"),
        strict=getattr(args, "strict", "missing,unused"),
        ext=getattr(args, "ext", ".png,.webp,.ogg,.mp3"),
        integration=getattr(args, "integration", "none"),
        json_out=(getattr(args, "format", "text") == "json"),
        dot_path=getattr(args, "dot_path", None),
    )


from .patch_store import ensure_project_registered, get_project_patches_dir

# report and logs handlers are not implemented, use stubs for now

# =============================================================================
# Phase 4 (v0.7.19): Legacy wrappers commented out - no longer needed with registry dispatch
# =============================================================================
# def cmd_report(args):
#     """
#     Export results to text/JSON/HTML. Defaults to latest analysis data where applicable.
#     """
#     # For demo: just run tests and export that result (real: load from cache or arg)
#     from .commands.tests_cmd import run as run_tests
#     import json
#     import os
#     # Run tests to get results (simulate analysis)
#     results = None
#     try:
#         # Use the same args as tests
#         results = run_tests(args.project, as_json=True)
#         if isinstance(results, str):
#             results = json.loads(results)
#     except Exception as e:
#         print(f"Failed to generate report: {e}")
#         return 1
#     # Output
#     if not isinstance(results, dict):
#         print("Failed to generate report: no results.")
#         return 1
#     if args.out:
#         save_report(results, args.out, as_json=(args.format == "json"))
#         print(f"Report written to {args.out}")
#     else:
#         print_report(results, as_json=(args.format == "json"))
#     return 0
#
# def cmd_compare_wrapper(args):
#     """
#     Wrapper function to adapt argparse Namespace to compare_cmd.run() parameters.
#     """
#     return cmd_compare(
#         a=args.old,
#         b=args.new,
#         project=getattr(args, 'project', None),
#         format_type="json" if getattr(args, "json", False) else "text"
#     )
# =============================================================================

# ...existing code...


def ensure_branchpy_dirs(project_root: Path) -> None:
    """
    Ensure .branchpy/{patches,reports,logs} exist under the resolved project root.
    Safe to call repeatedly.
    """
    if project_root is None:
        return
    base = project_root / ".branchpy"
    for sub in ("patches", "reports", "logs"):
        (base / sub).mkdir(parents=True, exist_ok=True)


def _pretty_print_log_lines(lines, as_json: bool):
    import json

    if as_json:
        print("\n".join(lines))
        return
    for raw in lines:
        try:
            ev = json.loads(raw)
            ts = ev.get("ts", "?")
            name = ev.get("event", "?")
            payload = ev.get("payload", {})
            op = ev.get("operation_id")
            extra = []
            if op:
                extra.append(f"op={op}")
            if isinstance(payload, dict) and payload:
                keys = list(payload.keys())[:2]
                extra.extend([f"{k}={payload[k]!r}" for k in keys])
            suffix = (" " + " ".join(extra)) if extra else ""
            print(f"[{ts}] {name}{suffix}")
        except Exception:
            print(raw)


def _tail_follow(log_path, as_json: bool, interval: float = 0.5):
    """Follow a file like `tail -f`, tolerant to truncation/rotation."""
    import os
    import time

    try:
        # open and seek to EOF
        f = open(log_path, "r", encoding="utf-8", errors="ignore")
        f.seek(0, os.SEEK_END)
        last_stat = os.stat(log_path)
        last_ino = getattr(last_stat, "st_ino", None)
        last_size = last_stat.st_size
        print(f"[following] {log_path}  (Ctrl+C to stop)")
        while True:
            where = f.tell()
            line = f.readline()
            if line:
                # may contain multiple lines if buffering; split safely
                parts = line.splitlines()
                # if readline cut the newline, keep printing as lines still fine
                _pretty_print_log_lines(parts, as_json)
                continue
            # no new data: sleep a bit
            time.sleep(interval)
            # detect truncation/rotation
            try:
                st = os.stat(log_path)
            except FileNotFoundError:
                # file removed → wait for it to come back
                time.sleep(interval)
                continue
            ino = getattr(st, "st_ino", None)
            if st.st_size < where or (last_ino is not None and ino != last_ino):
                # truncated or rotated → reopen and seek to start
                try:
                    f.close()
                except Exception:
                    pass
                f = open(log_path, "r", encoding="utf-8", errors="ignore")
                where = 0
                last_ino = ino
                last_size = st.st_size
            else:
                last_size = st.st_size
    except KeyboardInterrupt:
        print("\n[stopped]")
    except Exception as e:
        print(f"[logs] follow error: {e}")


# =============================================================================
# ⚙️  Temporary Type & Helper Stubs  — BranchPy v0.6.5
# -----------------------------------------------------------------------------
# These definitions exist solely to keep Pylance and static analysis tools happy
# while the CLI architecture is being finalized (v0.6.x → v0.6.66).
#
# They provide:
#   • Minimal regex / helper stubs for internal scanning functions
#   • A lightweight MutableMapping type alias for AppCfg
#   • Placeholder implementations for media/stat/graph utilities
#
# These stubs are harmless at runtime and can be safely removed once the real
# implementations are imported from their proper modules.
#
# TODO (v0.6.66):
#   - Move AppCfg definition to config.py and type it as a TypedDict
#   - Replace stubbed _scan_labels_and_edges / _graph_findings / etc.
#   - Remove temporary regex constants once tests_cmd is finalized
# =============================================================================
import re
from pathlib import Path

# AppCfg is a mutable mapping with clear(), update(), etc.
from typing import Any, Mapping, MutableMapping, cast

# ---- AppCfg typing (minimal, unblocks Pylance quickly)


AppCfg = MutableMapping[str, Any]  # has clear(), update(), etc.

# --- temporary stubs to satisfy Pylance / avoid NameError ---
# basic assignment patterns
STAT_ASSIGN_RE = re.compile(
    r"^\s*(?:define|default|\$)\s+([A-Za-z_]\w*)\s*(=|\+=|-=|\*=|/=)\s*(.+)$"
)
SET_VARIABLE_RE = re.compile(
    r'SetVariable\(\s*["\']([A-Za-z_]\w*)["\']\s*,\s*(.+?)\s*\)'
)


def _infer_literal_type(s: str) -> str:
    s = (s or "").strip()
    if s.startswith(("'", '"')):
        return "str"
    if s in {"True", "False"}:
        return "bool"
    try:
        int(s)
        return "int"
    except Exception:
        pass
    try:
        float(s)
        return "float"
    except Exception:
        pass
    return "other"


def _has_bom(p: Path) -> bool:
    try:
        with open(p, "rb") as f:
            return f.read(3) == b"\xef\xbb\xbf"
    except Exception:
        return False


# label graph placeholders (no-op)
def _scan_labels_and_edges(project: Path):
    # return (labels_dict, edges_list)
    return ({}, [])


def _graph_findings(labels, edges):
    # return (issues_list, label_count)
    return ([], 0)


# media disk index placeholder so media block won’t crash if used via new runner
# (your real implementation likely lives in commands/media_cmd.py)
disk_set: set[str] = set()
import warnings
from pathlib import Path

from branchpy.commands.media import _collect_references

# Consolidated imports to avoid redefinition
from branchpy.obs import end_operation, start_operation
from branchpy.project_config import ProjectConfig, load_project_config
from branchpy.tools.bugbundle import create_bug_bundle

from .config_store import ConfigStore
from .contract import json_boilerplate
from .scan_context import IMG_EXTS, SND_EXTS, _is_ignored


def load_config() -> AppCfg:
    store = ConfigStore()
    return cast(AppCfg, store.cfg)


def save_config(cfg: Mapping[str, Any]) -> None:
    store = ConfigStore()
    # mutate the existing mapping instead of replacing the attribute
    store.cfg.clear()
    store.cfg.update_dict(cfg)
    store.save()


def get_command_names():
    """Return sorted list of all available command names from the command map."""
    return sorted(_CMD_MAP.keys())


# --- CLI parser builder ---


def cmd_patches(args: argparse.Namespace) -> int:
    if not args.list:
        print("Use: branchpy patches --list [--json]")
        return 2

    # Project resolution
    friendly, proj_path, auto = ensure_project_registered(
        getattr(args, "project", None)
    )
    pdir = get_project_patches_dir(friendly)

    # TODO: your real listing logic here
    patches = list_patches(proj_path, all_projects=args.all_projects)

    print(f"Project: {friendly}")
    print(f"Root:    {proj_path}")
    print(f"Store:   {pdir}")
    if auto:
        print(
            f"(This project was auto-registered. To rename: branchpy projects rename '{friendly}' <newname>)"
        )

    if args.json:
        import json

        print(
            json.dumps(
                {"project": str(proj_path), "patches": patches}, ensure_ascii=False
            )
        )
    else:
        if not patches:
            print("(no patches found)")
            return 0
        print("=== Patches ===")
        for p in patches:
            print(f"- {p}")
    return 0


def list_patches(project_root: Path, all_projects: bool = False):
    # Stub implementation; replace with your real index lookup
    if all_projects:
        # e.g., scan known projects directory/registry
        return []
    # e.g., read .branchpy/patches in project_root
    return []


# =============================================================================
# Lazy Parser Builders — Phase 4 v0.7.19 (Registry-Based)
# =============================================================================


def _build_base_parser() -> argparse.ArgumentParser:
    """
    Build lightweight base parser with placeholder subcommands.
    NO module imports - allows `branchpy --help` to work instantly.
    """
    parser = argparse.ArgumentParser(
        prog="branchpy",
        description="BranchPy CLI — analysis, media checks, patches, reports.",
        epilog=fmt_examples(
            "branchpy welcome                        # first-time setup guide",
            "branchpy analyze --html --open          # analyze + open HTML report",
            "branchpy --project C:\\path\\to\\proj patches --list",
            "branchpy --project mygame tests",
            "branchpy projects list",
        ),
        formatter_class=HelpFmt,
    )

    # Global flags
    parser.add_argument("--version", action="version", version=f"BranchPy {VERSION}")
    parser.add_argument(
        "--project",
        type=str,
        default=".",
        help="Path to project root (run from anywhere). Default: current directory.",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    # Register placeholder subparsers for all commands (no module imports!)
    for cmd_name in _CMD_MAP.keys():
        # Register both 'pilot' and 'stats2' as aliases for the same command
        if cmd_name == "pilot":
            subparsers.add_parser("pilot", add_help=False)
            subparsers.add_parser("stats2", add_help=False)
        elif cmd_name != "stats2":
            subparsers.add_parser(cmd_name, add_help=False)
    # Add special version command (no registry entry needed)
    subparsers.add_parser("version", add_help=False)
    # Add test command alias (if not already in registry)
    if "test" not in _CMD_MAP:
        subparsers.add_parser("test", add_help=False)

    return parser


def _build_full_parser_for_command(cmd_name: str) -> argparse.ArgumentParser:
    """
    Build complete parser for ONE specific command by lazy-importing only that module.
    This is called after command name extraction - imports on demand.
    """
    parser = argparse.ArgumentParser(
        prog="branchpy",
        description="BranchPy CLI — analysis, media checks, patches, reports.",
        formatter_class=HelpFmt,
    )

    # Global flags (same as base)
    parser.add_argument("--version", action="version", version=f"BranchPy {VERSION}")
    parser.add_argument(
        "--project",
        type=str,
        default=".",
        help="Path to project root (run from anywhere). Default: current directory.",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    # Special case: version command (no module to import)
    if cmd_name == "version":

        def _cmd_version(args):
            print(f"BranchPy {VERSION}")
            return 0

        version_p = subparsers.add_parser("version", help="Show version and exit.")
        version_p.set_defaults(handler=_cmd_version)
        return parser

    # Special case: test alias → maps to cmd_test module
    if cmd_name == "test":
        # Import cmd_test module
        from .commands import cmd_test

        cmd_test.add_parser(subparsers)
        return parser

    # Import and register only the requested command
    # For 'pilot' and 'stats2', register both as aliases to the same handler
    key = "pilot" if cmd_name == "pilot" else cmd_name
    mod, add_parser_func, run_func = _lazy_import_command(key)
    if not add_parser_func:
        print(
            f"[BranchPy] Command '{cmd_name}' has no add_parser function",
            file=sys.stderr,
        )
        sys.exit(2)
    # Commands that use build(subparser) pattern (not add_parser(subparsers) pattern)
    if add_parser_func.__name__ == "build":
        sub_p = subparsers.add_parser(cmd_name)
        add_parser_func(sub_p)
        sub_p.set_defaults(handler=run_func)
    else:
        add_parser_func(subparsers)

    return parser


def build_parser() -> argparse.ArgumentParser:
    # Phase 4 (v0.7.19): Import commands inside function to enable lazy loading
    # These imports only execute if build_parser() is called (e.g., for --help or legacy tests)
    from .commands import (
        cmd_activate,
        cmd_deactivate,
        cmd_status,
        cmd_test,
        config_cmd,
        dev_cmd,
        l10n_cmd,
        logs_cmd,
        patches_cmd,
        projects_cmd,
        redo_cmd,
        renpy_cmd,
        report_cmd,
        serve_cmd,
        undo_cmd,
        watch_cmd,
    )
    from .commands.compare_cmd import run as cmd_compare
    from .commands.guard_cmd import run as cmd_guard_raw
    from .commands.media_cmd import run as cmd_media_raw
    from .commands.stats_cmd import run as cmd_stats_raw
    from .commands.tests_cmd import run as cmd_tests_raw

    parser = argparse.ArgumentParser(
        prog="branchpy",
        description="BranchPy CLI — analysis, media checks, patches, reports.",
        epilog=fmt_examples(
            "branchpy welcome                        # first-time setup guide",
            "branchpy analyze --html --open          # analyze + open HTML report",
            "branchpy --project C:\\path\\to\\proj patches --list",
            "branchpy --project mygame tests",
            "branchpy projects list",
        ),
        formatter_class=HelpFmt,
    )

    # Global flag: prints version and exits before requiring a command
    parser.add_argument("--version", action="version", version=f"BranchPy {VERSION}")

    parser.add_argument(
        "--project",
        type=str,
        default=".",
        help="Path to project root (run from anywhere). Default: current directory.",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)
    undo_cmd.add_parser(subparsers)
    redo_cmd.add_parser(subparsers)
    config_cmd.add_parser(subparsers)
    renpy_cmd.add_parser(subparsers)
    l10n_cmd.add_parser(subparsers)
    cmd_test.add_parser(subparsers)

    # License activation commands
    activate_p = subparsers.add_parser("activate", help="Activate a commercial license")
    cmd_activate.build(activate_p)
    activate_p.set_defaults(handler=cmd_activate.run)

    status_p = subparsers.add_parser("status", help="Show license status")
    cmd_status.build(status_p)
    status_p.set_defaults(handler=cmd_status.run)

    deactivate_p = subparsers.add_parser(
        "deactivate", help="Deactivate license (seat transfer/cleanup)"
    )
    cmd_deactivate.build(deactivate_p)
    deactivate_p.set_defaults(handler=cmd_deactivate.run)
    # Register dev helper command
    dev_cmd.add_parser(subparsers)

    # patches subcommand (centralized)
    patches_cmd.add_parser(subparsers)

    # projects subcommand (call the parser registration function)
    projects_cmd.add_parser(subparsers)

    # Optional subcommand parity: `branchpy version`
    def _cmd_version(args):
        print(f"BranchPy {VERSION}")
        return 0

    version_p = subparsers.add_parser("version", help="Show version and exit.")
    version_p.set_defaults(handler=_cmd_version)

    # tests subcommand
    tests_p = subparsers.add_parser(
        "tests",
        help="Scan .rpy for structural issues (jumps, calls, orphans).",
        description=(
            "Analyze Ren'Py scripts for missing jump/call targets, orphan labels, dead ends, etc. "
            "Outputs a summary and issues. Use --format json for machine-readable output."
        ),
        epilog=fmt_examples(
            "branchpy --project C:\\proj tests",
            "branchpy --project mygame tests --format json",
            "branchpy --project mygame tests --out results.json",
            "branchpy --project mygame tests --dot graph.dot",
            "branchpy --project mygame tests --png graph.png",
            "branchpy --project mygame tests --dry-run",
        ),
        formatter_class=HelpFmt,
    )
    tests_p.set_defaults(handler=cmd_tests_raw)
    tests_p.add_argument(
        "--out",
        type=str,
        metavar="PATH",
        help="Write output to file (JSON if .json, text otherwise).",
    )
    tests_p.add_argument(
        "--format", choices=["text", "json"], default="text", help="Output format."
    )
    tests_p.add_argument(
        "--dot", type=str, metavar="PATH", help="Export label graph as DOT file."
    )
    tests_p.add_argument(
        "--png",
        type=str,
        metavar="PATH",
        help="Export label graph as PNG (requires Graphviz).",
    )
    tests_p.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be done, but don’t write files.",
    )

    # media subcommand
    media_p = subparsers.add_parser(
        "media",
        help="Media checks (missing/unused).",
        description=(
            "Scan the project for referenced-but-missing assets, and/or unused files on disk. "
            "Use sub-flags --missing or --unused."
        ),
        epilog=fmt_examples(
            "branchpy --project C:\\proj media --missing",
            "branchpy --project mygame media --unused",
            "branchpy --project mygame media --missing --assets game",
            "branchpy --project mygame media --unused --ext .png,.jpg",
            "branchpy --project mygame media --missing --ignore '*/test/*'",
        ),
        formatter_class=HelpFmt,
    )
    media_p.set_defaults(handler=cmd_media_raw)
    group = media_p.add_mutually_exclusive_group(required=True)
    group.add_argument(
        "--missing",
        action="store_true",
        help="Report referenced assets that are missing.",
    )
    group.add_argument(
        "--unused",
        action="store_true",
        help="Report on-disk assets not referenced by scripts.",
    )
    group.add_argument(
        "--referenced",
        action="store_true",
        help="Report on-disk assets that are referenced by scripts.",
    )
    media_p.add_argument(
        "--assets",
        type=str,
        default="game",
        metavar="DIR",
        help="Assets directory (default: game)",
    )
    media_p.add_argument(
        "--ext",
        type=str,
        default=".png,.webp,.ogg,.mp3",
        metavar="EXTS",
        help="Comma-separated extensions to scan.",
    )
    media_p.add_argument(
        "--ignore", type=str, metavar="PATTERN", help="Glob pattern(s) to ignore."
    )
    media_p.add_argument("--json", action="store_true", help="Show output as JSON.")
    media_p.add_argument(
        "--fail-on-unused",
        action="store_true",
        help="Exit with error if unused assets are found.",
    )

    # stats subcommand
    stats_p = subparsers.add_parser(
        "stats",
        help="Stat/flag sanity checks.",
        description="Check stat variables (trust, boldness, obedience, etc.) for duplicates/misuse.",
        epilog=fmt_examples(
            "branchpy --project C:\\proj stats",
            "branchpy --project mygame stats",
            "branchpy --project mygame stats --json",
            "branchpy --project mygame stats --out stats.json",
        ),
        formatter_class=HelpFmt,
    )
    stats_p.set_defaults(handler=cmd_stats_raw)
    stats_p.add_argument("--json", action="store_true", help="Show output as JSON.")
    stats_p.add_argument(
        "--out", type=str, metavar="PATH", help="Write output to file (JSON format)."
    )

    # guard subcommand
    guard_p = subparsers.add_parser(
        "guard",
        help="Safety checks / guardrails.",
        description="Run guard checks (e.g., naming rules, file hygiene) to prevent common mistakes.",
        epilog=fmt_examples(
            "branchpy --project C:\\proj guard",
            "branchpy --project mygame guard run",
            "branchpy --project mygame guard init --integration pre-commit",
            "branchpy --project mygame guard enable --integration workflow",
        ),
        formatter_class=HelpFmt,
    )
    guard_p.set_defaults(handler=cmd_guard_raw)
    guard_p.add_argument(
        "action",
        choices=["init", "enable", "disable", "run"],
        nargs="?",
        help="Guard action to perform.",
    )
    guard_p.add_argument(
        "--checks",
        type=str,
        default="missing,unused,stats",
        help="Checks to run (comma-separated).",
    )
    guard_p.add_argument(
        "--strict",
        type=str,
        default="missing,unused",
        help="Checks that must pass (comma-separated).",
    )
    guard_p.add_argument(
        "--integration",
        choices=["none", "pre-push", "pre-commit", "workflow"],
        default="none",
        help="Integration type.",
    )
    guard_p.add_argument(
        "--dot", type=str, metavar="PATH", help="Export label graph as DOT file."
    )
    guard_p.add_argument(
        "--png",
        type=str,
        metavar="PATH",
        help="Export label graph as PNG (requires Graphviz).",
    )

    # doctor subcommand
    doctor_cmd.add_parser(subparsers)

    # logs subcommand
    logs_cmd.add_parser(subparsers)

    # watch subcommand
    watch_cmd.add_parser(subparsers)

    # serve subcommand
    serve_cmd.add_parser(subparsers)

    # report subcommand
    report_p = subparsers.add_parser(
        "report",
        help="Export reports.",
        description="Export results to text/JSON/HTML. Defaults to latest analysis data where applicable.",
        epilog=fmt_examples(
            "branchpy --project C:\\proj report --format html --out C:\\out\\report.html",
            "branchpy --project mygame report --format json",
            "branchpy --project mygame report --format text",
            "branchpy --project mygame report --out report.txt",
        ),
        formatter_class=HelpFmt,
    )
    report_p.set_defaults(handler=report_cmd.cmd_report)
    report_p.add_argument(
        "--format",
        choices=["text", "json", "html"],
        default="text",
        help="Output format for the report.",
    )
    report_p.add_argument(
        "--out", type=str, metavar="PATH", help="Output path for file formats."
    )

    # compare subcommand
    compare_p = subparsers.add_parser(
        "compare",
        help="Compare two reports.",
        description="Compare deltas between two saved analysis reports.",
        epilog=fmt_examples(
            "branchpy --project C:\\proj compare --old .logs/rep1.json --new .logs/rep2.json",
            "branchpy compare --old rep1.json --new rep2.json",
            "branchpy compare --old rep1.json --new rep2.json > diff.txt",
        ),
        formatter_class=HelpFmt,
    )
    compare_p.set_defaults(handler=cmd_compare)
    compare_p.add_argument(
        "--old", required=True, metavar="PATH", help="Old report path."
    )
    compare_p.add_argument(
        "--new", required=True, metavar="PATH", help="New report path."
    )
    compare_p.add_argument(
        "--json", action="store_true", help="Output results in JSON format."
    )

    # analyze subcommand
    from .commands import analyze_cmd

    analyze_cmd.add_parser(subparsers)

    # tests
    sp = subparsers.add_parser(
        "tests", help="Scan project, print report, export DOT/PNG."
    )
    sp.add_argument("-p", "--project", default=".")
    sp.add_argument("--out")
    sp.add_argument("--json", dest="as_json", action="store_true")
    sp.add_argument("--dot", dest="dot_path")
    sp.add_argument("--png", dest="png_path")
    sp.add_argument("--dry-run", action="store_true")
    sp.add_argument(
        "--matrix",
        help="Run tests across multiple SDKs (comma-separated: sdk1,sdk2,sdk3)",
    )
    sp.add_argument(
        "--save-report", action="store_true", help="Save report to timestamped file"
    )

    # media
    sm = subparsers.add_parser("media", help="Scan media for missing/unused.")
    sm.add_argument("-p", "--project", default=".")
    sm.add_argument("--assets", default="game")
    sm.add_argument("--ext", dest="ext", default=".png,.webp,.ogg,.mp3")
    sm.add_argument("--ignore", dest="ignore")
    sm.add_argument("--json", dest="as_json", action="store_true")
    group = sm.add_mutually_exclusive_group(required=True)
    group.add_argument("--missing", action="store_true")
    group.add_argument("--unused", action="store_true")

    # stats
    ss = subparsers.add_parser("stats", help="Print simple project stats.")
    ss.add_argument("--json", dest="as_json", action="store_true")
    ss.add_argument(
        "--out", type=str, metavar="PATH", help="Write output to file (JSON format)."
    )

    # guard
    sg = subparsers.add_parser("guard", help="Configure/execute guard checks.")
    sg.add_argument("action", choices=["init", "enable", "disable", "run"], nargs="?")
    sg.add_argument("-p", "--project", default=".")
    sg.add_argument("--assets", default="game")
    sg.add_argument("--checks", default="missing,unused,stats")
    sg.add_argument("--strict", default="missing,unused")
    sg.add_argument("--ext", default=".png,.webp,.ogg,.mp3")
    sg.add_argument(
        "--integration",
        choices=["none", "pre-push", "pre-commit", "workflow"],
        default="none",
    )
    sg.add_argument("--json", dest="json_out", action="store_true")
    sg.add_argument("--dot", dest="dot_path")
    sg.add_argument("--png", dest="png_path")

    return parser


# Existing subcommand runners (kept for back-compat)
from .commands import (
    compare_cmd,
    doctor_cmd,
    guard_cmd,
    help_cmd,
    media_cmd,
    patches_cmd,
    stats_cmd,
    tests_cmd,
)

COMMANDS = {
    "help": help_cmd.run,
    "tests": tests_cmd.run,
    "media": media_cmd.run,
    "stats": stats_cmd.run,
    "guard": guard_cmd.run,
    # "patches": patches_cmd.run,  # Removed: no 'run' in patches_cmd
    "compare": compare_cmd.run,
    # "doctor": handled by new subparser system
}
COMMANDS["undo"] = None  # No direct undo/redo in new patches_cmd; handled by handler
COMMANDS["redo"] = None
import os


def _dispatch(args, cfg) -> int:
    """
    Route CLI to the correct subcommand. Returns an integer exit code.
    Assumes global flags (--version/--telemetry) were already handled by main().
    """

    # Test hook to force a crash in CI/smoke tests
    if os.environ.get("BRANCHPY_FORCE_CRASH") == "1":
        raise RuntimeError("forced crash for test")

    # --- helpers --------------------------------------------------------------
    def _filter_kwargs_by_signature(fn, args_dict):
        import inspect

        sig = inspect.signature(fn)
        return {k: v for k, v in args_dict.items() if k in sig.parameters}

    cmd = getattr(args, "cmd", None)
    if not cmd:
        print("BranchPy: no command specified. Try `branchpy help`.")
        return 2

    # --- bugbundle support for report --bundle ---
    if cmd == "report" and getattr(args, "bundle", None):
        op = start_operation("bugbundle.create", {"target": args.bundle})
        out = create_bug_bundle(
            args.bundle, include_report=getattr(args, "include", None)
        )
        end_operation(op, "bugbundle.create", meta={"path": str(out)})
        print(str(out))
        return 0

    if cmd == "patches":
        return patches_cmd.cmd_patches(args)
    if cmd == "undo":
        print("[BranchPy] 'undo' is not implemented in this version.")
        return 2
    if cmd == "redo":
        print("[BranchPy] 'redo' is not implemented in this version.")
        return 2
    if cmd == "compare":
        op = start_operation("compare.run", {"a": args.old, "b": args.new})
        rc = compare_cmd.run(
            a=args.old,
            b=args.new,
            format_type="json" if getattr(args, "json", False) else "text",
        )
        end_operation(op, "compare.run", exit_code=rc)
        return rc
    if cmd == "report":
        op = start_operation("bugbundle.create", {"target": args.bundle})
        out = create_bug_bundle(
            args.bundle, include_report=getattr(args, "include", None)
        )
        end_operation(op, "bugbundle.create", meta={"path": str(out)})
        print(str(out))
        return 0

    if cmd == "logs":
        from branchpy import obs

        log_path = obs._state_root() / "logs" / "action.log.jsonl"
        if not log_path.exists():
            print(f"No log file found at {log_path}")
            return 0

        # print last N first
        lines = log_path.read_text(encoding="utf-8", errors="ignore").splitlines()
        tail = lines[-args.tail :] if args.tail > 0 else []
        _pretty_print_log_lines(tail, as_json=getattr(args, "json", False))

        # then optionally follow
        if getattr(args, "follow", False):
            _tail_follow(str(log_path), as_json=getattr(args, "json", False))
        return 0
    if cmd in COMMANDS:
        run_fn = COMMANDS[cmd]
        accepted = _filter_kwargs_by_signature(run_fn, vars(args))
        return _call_sigsafe(run_fn, **accepted)

    print("BranchPy: unknown command %r. Try `branchpy help`." % cmd)
    return 2


# Minimal _call_sigsafe implementation to avoid NameError
def _call_sigsafe(fn, **kwargs):
    try:
        return fn(**kwargs)
    except TypeError as e:
        print(f"Error calling {fn.__name__}: {e}")
        return 2


# New subcommand runners (v0.6.5+)

# Hide the noisy runpy warning users see with `py -m ...`
warnings.filterwarnings(
    "ignore", message=".*found in sys.modules after import of package 'branchpy'.*"
)


def _scan_stats(project: Path, ignore: list[str] | None = None) -> list[dict]:
    """
    Collect variable assignments and flag:
      - duplicate_variable
      - stat_inconsistency (mixed literal types)
      - dynamic_unresolved (non-literal RHS / SetVariable)
    """
    issues: list[dict] = []
    seen: dict[str, list[tuple[str, int, str, str]]] = (
        {}
    )  # var -> [(file,line,op,value)]

    global _bom_warned
    for p in Path(project).rglob("*.rpy"):
        if ignore and _is_ignored(project, p, ignore):
            continue
        try:
            if not _bom_warned and _has_bom(p):
                print(
                    f"[BranchPy WARNING] BOM detected in: {p}. Recommend saving as UTF-8 (no BOM) for best compatibility.",
                    file=sys.stderr,
                )
                _bom_warned = True
            with p.open("r", encoding="utf-8-sig", errors="replace") as f:
                for i, raw in enumerate(f, 1):
                    line = raw.rstrip("\n\r")

                    # $ or define/default assignments
                    m = STAT_ASSIGN_RE.match(line)
                    if m:
                        var, op, rhs = m.group(1), m.group(2), m.group(3)
                        seen.setdefault(var, []).append((str(p), i, op, rhs))
                        continue

                    # SetVariable("x", value)
                    sm = SET_VARIABLE_RE.search(line)
                    if sm:
                        var, rhs = sm.group(1), sm.group(2)
                        # treat SetVariable as dynamic unless literal
                        t = _infer_literal_type(rhs)
                        if t == "other":
                            issues.append(
                                {
                                    "kind": "dynamic_unresolved",
                                    "path": str(p),
                                    "line": i,
                                    "value": f'SetVariable("{var}", {rhs})',
                                    "severity": "info",
                                }
                            )
                        seen.setdefault(var, []).append((str(p), i, "=", rhs))
                        continue
        except Exception:
            pass

    # Analyze per-variable
    for var, defs in seen.items():
        # Duplicates: more than one assignment/definition anywhere
        if len(defs) > 1:
            f, line_num, _, _ = defs[0]
            issues.append(
                {
                    "kind": "duplicate_variable",
                    "path": f,
                    "line": line_num,
                    "value": var,
                    "severity": "warning",
                }
            )

        # Type consistency (literals only)
        types = set()
        for _, _, op, rhs in defs:
            # compound ops like "+=" imply numeric intent; mark as "numeric"
            if op in ("+=", "-=", "*=", "/="):
                types.add("numeric")
                continue
            t = _infer_literal_type(rhs)
            types.add(t)

        # If multiple distinct literal kinds → inconsistency (ignore combos involving only numeric/float/int)
        simplified = set("int" if t == "numeric" else t for t in types)
        numericish = {"int", "float"}
        if len(simplified - {"other"}) > 1:
            # allow int/float mixing without warning
            if not (simplified - {"other"}).issubset(numericish):
                f, line_num, _, _ = defs[0]
                issues.append(
                    {
                        "kind": "stat_inconsistency",
                        "path": f,
                        "line": line_num,
                        "value": f"{var} → {sorted(simplified)}",
                        "severity": "warning",
                    }
                )

        # If **all** assignments were non-literal “other”, surface one informational hint
        if simplified == {"other"}:
            f, line_num, _, rhs0 = defs[0]
            issues.append(
                {
                    "kind": "dynamic_unresolved",
                    "path": f,
                    "line": line_num,
                    "value": f"{var} = {rhs0}",
                    "severity": "info",
                }
            )

    return issues


# ---------------------------
# LINT aggregator
# ---------------------------
def run_checks(
    project: Path,
    assets: Path | None,
    exts: list[str],
    checks: set[str],
    ignore: list[str] | None = None,
) -> dict:
    out = json_boilerplate()
    issues: list[dict] = []

    assets = assets or project / "game"
    assets = Path(assets)

    # MEDIA (missing + unused)
    if "media" in checks:
        user_exts = set(e.lower().strip() for e in exts if e.strip().startswith("."))
        img_exts = user_exts & IMG_EXTS if user_exts else IMG_EXTS
        aud_exts = user_exts & SND_EXTS if user_exts else SND_EXTS
        all_exts = img_exts | aud_exts

        refs = _collect_references(project.rglob("*.rpy"))
        # TODO: implement or import _scan_disk
        # disk_set = _scan_disk(assets, all_exts, ignore=ignore or [])

        # Missing
        for file_path, line_no, kind, value in refs:
            candidate = value.replace("\\", "/")
            if candidate not in disk_set:
                issues.append(
                    {
                        "kind": "missing_media",
                        "path": file_path,
                        "line": line_no,
                        "value": value,
                        "severity": "error",
                    }
                )

        # Unused
        ref_set: set[str] = set(v.replace("\\", "/") for _, _, _, v in refs)
        for rel in sorted(disk_set):
            if rel not in ref_set:
                issues.append(
                    {
                        "kind": "unused_media",
                        "path": str(assets / rel),
                        "line": 0,
                        "value": rel,
                        "severity": "warning",
                    }
                )

    # LABELS/JUMPS
    if "labels" in checks or "jumps" in checks:
        labels, edges = _scan_labels_and_edges(project)
        g_issues, label_count = _graph_findings(labels, edges)
        issues.extend(g_issues)
        out["summary"]["labels"] = label_count

    # STATS
    if "stats" in checks:
        issues.extend(_scan_stats(project, ignore=ignore or []))

    out["issues"] = issues
    out["summary"]["issues"] = len(issues)
    out["summary"]["files"] = out["summary"].get("files", 0)  # keep key populated
    out["summary"]["files"] = sum(1 for _ in Path(project).rglob("*.rpy"))
    return out


def merge_project_config_with_args(
    args: argparse.Namespace, project_config: ProjectConfig
) -> argparse.Namespace:
    """
    Merge project configuration defaults with parsed CLI arguments.
    CLI arguments take precedence over project config.
    """
    # Only apply defaults if the CLI argument wasn't explicitly set
    # This is done by checking if the arg value is the same as the parser default

    # Get the command being run
    command = getattr(args, "command", None)

    # Media command defaults
    if command == "media":
        # Apply project config defaults only if CLI args are at their defaults
        if (
            hasattr(args, "ext")
            and args.ext == ".png,.webp,.ogg,.mp3"
            and project_config.media_exts
        ):
            args.ext = project_config.media_exts
        if hasattr(args, "ignore") and not args.ignore and project_config.media_ignore:
            args.ignore = project_config.media_ignore
        if (
            hasattr(args, "assets")
            and args.assets == "game"
            and project_config.media_assets_root
        ):
            args.assets = project_config.media_assets_root

    # Tests command defaults
    elif command == "tests":
        if (
            hasattr(args, "format")
            and args.format == "text"
            and project_config.tests_format != "summary"
        ):
            if project_config.tests_format == "json":
                args.format = "json"
        # Auto-enable save-report if configured in project
        if (
            hasattr(args, "save_report")
            and not args.save_report
            and project_config.tests_save_report
        ):
            args.save_report = True

    # Compare command defaults
    elif command == "compare":
        if (
            hasattr(args, "json")
            and not args.json
            and project_config.compare_format == "json"
        ):
            args.json = True

    return args


# ---------------------------------------------------------------------------
# First-run welcome nudge
# ---------------------------------------------------------------------------
_WELCOME_SKIP_CMDS = frozenset(
    {"welcome", "login", "logout", "whoami", "doctor", "version", "help", "activate",
     "status", "deactivate", "config", "support"}
)


def _maybe_show_welcome_hint(command: str | None) -> None:
    """
    Print a single-line nudge the first time a user runs *any* real command,
    directing them to `branchpy welcome` for the full getting-started guide.

    Uses a sentinel file so the hint appears only once per machine.
    Skips silently on any OS/permissions error — never blocks CLI operation.
    """
    if command in _WELCOME_SKIP_CMDS:
        return
    try:
        import os
        if sys.platform == "win32":
            base = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
        else:
            base = Path.home() / ".BranchPy"
        sentinel = base / "BranchPy" / "cli_welcomed"
        if sentinel.exists():
            return
        # Show the nudge before any output
        print(
            "\n💡 New to BranchPy?  Run  branchpy welcome  for the full getting-started guide.\n",
            file=sys.stderr,
        )
        sentinel.parent.mkdir(parents=True, exist_ok=True)
        sentinel.touch()
    except Exception:
        pass  # Sentinel errors are non-fatal


def main(argv=None) -> int:
    """
    Two-pass lazy CLI dispatcher (Phase 4 v0.7.19):
    1st pass: lightweight parse to extract command name (NO imports)
    2nd pass: import ONLY that command's module and reparse with full flags
    This eliminates ~200ms of wasted imports for unused commands.
    """
    # Ensure UTF-8 output on Windows — prevents cp1252 UnicodeEncodeError for
    # Unicode status symbols (✓, ↻, …) used across commands (omega, flowchart, …).
    # No-op on macOS/Linux and modern Windows Terminal which already use UTF-8.
    for _stream in (sys.stdout, sys.stderr):
        if hasattr(_stream, "reconfigure"):
            try:
                _stream.reconfigure(encoding="utf-8")
            except Exception:
                pass

    # Suppress harmless SyntaxWarning from dynamic code execution
    # (appears during AST parsing, doesn't affect functionality)
    import warnings

    warnings.filterwarnings(
        "ignore", category=SyntaxWarning, message="invalid escape sequence"
    )

    argv = argv or sys.argv[1:]

    # Initialize logging context
    run_id = str(uuid.uuid4())
    session_id = str(uuid.uuid4())
    logs.set_context(component="cli", session_id=session_id, run_id=run_id)
    t0 = time.perf_counter()

    # Friendly tip if --project is after the subcommand
    if "patches" in argv and "--project" in argv:
        i_cmd = argv.index("patches")
        i_proj = argv.index("--project")
        if i_proj > i_cmd:
            print(
                "[BranchPy] Tip: --project is a global flag and must come before the subcommand.\n"
                "Try: branchpy --project <name|path> patches --list"
            )
            # fall through to normal parse (argparse will still error)

    # === PASS 1: Extract command name (no imports) ===
    base_parser = _build_base_parser()
    try:
        ns, remaining = base_parser.parse_known_args(argv)
    except SystemExit as e:
        # Fix: Don't convert 0 to 2 - preserve exit code from argparse (e.g. --version exits with 0)
        code = e.code if e.code is not None else 2
        _emit_parse_error_telemetry(command=None, argv=argv, err=e, exit_code=code)
        return code
    except Exception as e:
        _emit_parse_error_telemetry(command=None, argv=argv, err=e, exit_code=2)
        return 2

    command = ns.command
    original_command = command  # Store original command before remapping
    # Remap legacy 'stats2' to 'pilot' for CLI compatibility
    if command == "stats2":
        command = "pilot"

    # Log command start
    safe_args = _safe_args_repr(argv)
    logs.info(
        "cli.command_start",
        msg=f"Starting command: {command or '(none)'}",
        cmd=command,
        args=safe_args[:500],
    )  # Truncate long arg lists

    # First-run nudge (one-time hint to run `branchpy welcome`)
    _maybe_show_welcome_hint(command)

    # Special case: no command → show full help (requires imports)
    if not command:
        try:
            full_parser = build_parser()  # Legacy full parser for backward compat
            full_parser.parse_args(argv)
            return 0
        except SystemExit as e:
            # Fix: Preserve exit code from argparse (don't convert 0 to default)
            code = e.code if e.code is not None else 0
            # Usually help returns 0; only emit if non-zero
            if code != 0:
                _emit_parse_error_telemetry(
                    command=None, argv=argv, err=e, exit_code=code
                )
            return code

    # Special case: global --help (no command specified yet)
    if (
        "--help" in argv
        and original_command
        and argv.index("--help") < argv.index(original_command)
    ):
        full_parser = build_parser()
        full_parser.parse_args(argv)
        return 0

    # Special case: Click-based commands that bypass argparse entirely
    _CLICK_COMMANDS = {
        "login": ("branchpy.cli.commands.identity_hub_cmd", "login_toplevel"),
        "whoami": ("branchpy.cli.commands.identity_hub_cmd", "whoami_toplevel"),
        "logout": ("branchpy.cli.commands.identity_hub_cmd", "logout_toplevel"),
        # These are @click.command()-decorated and have no add_parser / build functions.
        # They must be dispatched here; falling through to _build_full_parser_for_command
        # causes AttributeError: 'Command' object has no attribute '__name__'.
        "export-media": ("branchpy.cli.commands.export_media_cmd", "export_media"),
        "journal": ("branchpy.cli.commands.journal_cmd", "journal"),
        "merge": ("branchpy.cli.commands.merge_cmd", "merge"),
    }
    if command in _CLICK_COMMANDS:
        mod_path, func_name = _CLICK_COMMANDS[command]
        import importlib

        mod = importlib.import_module(mod_path)
        click_cmd = getattr(mod, func_name)
        try:
            # Strip the command name from argv before passing to Click
            click_argv = [a for a in argv if a != command]
            click_cmd(click_argv, standalone_mode=False)
            return 0
        except SystemExit as e:
            return e.code if e.code is not None else 0
        except Exception:
            return 1

    # === PASS 2: Build full parser for this command ONLY (lazy import) ===
    full_parser = _build_full_parser_for_command(command)
    try:
        # Special case: 'test' command uses parse_known_args to forward pytest arguments
        if command == "test":
            args, unknown_args = full_parser.parse_known_args(argv)
            # Store unknown args for pytest pass-through
            args._pytest_extra_args = unknown_args if unknown_args else None
        else:
            args = full_parser.parse_args(argv)
    except SystemExit as e:
        # Fix: Preserve exit code from argparse (e.g. --help exits with 0)
        code = e.code if e.code is not None else 2
        _emit_parse_error_telemetry(command=command, argv=argv, err=e, exit_code=code)
        return code
    except Exception as e:
        _emit_parse_error_telemetry(command=command, argv=argv, err=e, exit_code=2)
        return 2

    # Special case: version command already handled by parser
    if command == "version":
        logs.info(
            "cli.command_ok",
            cmd="version",
            duration_ms=int((time.perf_counter() - t0) * 1000),
            rc=0,
        )
        return 0  # handler already executed

    # Load project configuration and merge with CLI args
    project_path = Path(getattr(args, "project", None) or ".").resolve()
    project_config = load_project_config(project_path)
    args = merge_project_config_with_args(args, project_config)

    # Update logging context with project
    logs.set_context(project_id=logs._hash_project(str(project_path)))

    # Ensure .branchpy directories exist
    ensure_branchpy_dirs(project_path)

    # Get handler from args (set by add_parser())
    handler = getattr(args, "handler", None)

    # If no handler, try to get run function from registry
    if handler is None:
        mod, add_parser_func, run_func = _lazy_import_command(command)
        if run_func:
            handler = run_func
        else:
            err_msg = f"Command '{command}' has no handler or run function"
            print(f"[BranchPy] {err_msg}", file=sys.stderr)
            logs.error(
                "cli.command_err",
                msg=err_msg,
                cmd=command,
                duration_ms=int((time.perf_counter() - t0) * 1000),
            )
            return 2

    # === Dispatch-level telemetry (Phase 2) ===
    # Wraps ALL commands with baseline telemetry at the dispatch boundary
    # Uses stable event types with command as property for analytics consistency
    from branchpy.telemetry import collector as telemetry_collector

    # Compute once, shared across all dispatch events
    _size_bucket = _project_size_bucket(project_path)

    # Emit cli.command.started event
    telemetry_collector.emit(
        "cli.command.started",
        {
            "command": command,
            "session_id": session_id,
            "source": "cli",
            "project_size_bucket": _size_bucket,
        },
    )

    # Execute the command handler with telemetry wrapper
    try:
        result = handler(args)
        rc = int(result or 0)
        duration_ms = int((time.perf_counter() - t0) * 1000)

        # Emit cli.command.finished event (stable type, command in properties)
        telemetry_collector.emit(
            "cli.command.finished",
            {
                "command": command,
                "duration_ms": duration_ms,
                "exit_code": rc,
                "error_hash": None,
                "session_id": session_id,
                "source": "cli",
                "project_size_bucket": _size_bucket,
            },
        )

        logs.info(
            "cli.command_ok",
            msg=f"Command completed: {command}",
            cmd=command,
            duration_ms=duration_ms,
            rc=rc,
        )
        return rc
    except KeyboardInterrupt:
        duration_ms = int((time.perf_counter() - t0) * 1000)

        # Emit interrupted event
        telemetry_collector.emit(
            "cli.command.interrupted",
            {
                "command": command,
                "duration_ms": duration_ms,
                "exit_code": 130,
                "session_id": session_id,
                "source": "cli",
            },
        )

        logs.warn("cli.command_interrupted", cmd=command, duration_ms=duration_ms)
        print("\n[BranchPy] Interrupted by user", file=sys.stderr)
        return 130  # Standard SIGINT exit code
    except Exception as e:
        duration_ms = int((time.perf_counter() - t0) * 1000)

        # Emit cli.command.error event with error hash (stable type)
        error_hash = telemetry_collector.hash_error(str(e))
        telemetry_collector.emit(
            "cli.command.error",
            {
                "command": command,
                "duration_ms": duration_ms,
                "exit_code": 1,
                "error_hash": error_hash,
                "error_type": type(e).__name__,
                "session_id": session_id,
                "source": "cli",
            },
        )

        logs.error(
            "cli.command_err",
            msg=str(e),
            cmd=command,
            duration_ms=duration_ms,
            exc_type=type(e).__name__,
            traceback=_get_traceback_summary(),
        )
        raise  # Re-raise to preserve stack trace for user


def _safe_args_repr(argv: list) -> str:
    """Create safe string representation of args, redacting sensitive values."""
    safe = []
    skip_next = False
    for i, arg in enumerate(argv):
        if skip_next:
            safe.append("***")
            skip_next = False
            continue

        # Redact values for sensitive flags
        if arg in ["--token", "--key", "--password", "--api-key"]:
            safe.append(arg)
            skip_next = True
        elif "=" in arg and any(
            k in arg.lower() for k in ["token", "key", "password", "secret"]
        ):
            parts = arg.split("=", 1)
            safe.append(f"{parts[0]}=***")
        else:
            safe.append(arg)

    return " ".join(safe)


def _get_traceback_summary() -> str:
    """Get abbreviated traceback for logging (last 3 frames)."""
    import traceback

    lines = traceback.format_exc().split("\n")
    # Take header + last 3 frames
    if len(lines) > 10:
        return "\n".join(lines[:2] + ["..."] + lines[-8:])
    return "\n".join(lines)


# Keep legacy shim if you still expose it anywhere
def main_legacy(argv: list[str] | None = None) -> int:
    return main(argv)


if __name__ == "__main__":
    import sys

    sys.exit(main())


def cmd_update(args, cfg: ConfigStore) -> int:
    """Forward‑compatible stub for the future auto‑update feature."""
    # Accept flags now so scripts/CI won't break later.
    channel = getattr(args, "channel", None) or cfg.cfg.update_cfg.channel
    sub = getattr(args, "subcmd", None)
    if sub in {"check", "apply"}:
        print("Auto-update is planned for a further version of BranchPy")
        print(f"Channel: {channel}")
        return 0
    print("Usage: branchpy update [check|apply] [--channel stable|beta|nightly]")
    return 2
