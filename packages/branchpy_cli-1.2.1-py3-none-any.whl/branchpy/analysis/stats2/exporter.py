"""Stats 2.0 JSON Export Schema

Exports path-aware statistics in a structured JSON format for visualization
and further analysis.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from branchpy.contract import VERSION as BRANCHPY_VERSION


class Stats2Exporter:
    """Exports Stats 2.0 data to JSON format."""

    VERSION = BRANCHPY_VERSION  # Imported from branchpy.contract
    SCHEMA_VERSION = "2.0"

    def __init__(self, project_root: Optional[Path] = None):
        """Initialize exporter.

        Args:
            project_root: Project root directory
        """
        self.project_root = Path(project_root) if project_root else None

    def export(
        self,
        aggregates: Dict[str, Any],
        path_analyses: Optional[Dict[List[str], Dict[str, List[Any]]]] = None,
        output_path: Optional[Path] = None,
        analysis_duration_ms: Optional[int] = None,
        path_analyzer: Optional[
            Any
        ] = None,  # PathStatsAnalyzer for PILOT state changes
    ) -> Dict[str, Any]:
        """Export stats to JSON format.

        Args:
            aggregates: Aggregate statistics from StatsAggregator
            path_analyses: Optional per-path analysis results
            output_path: Optional output file path
            analysis_duration_ms: Optional analysis duration in milliseconds
            path_analyzer: Optional PathStatsAnalyzer instance for state changes

        Returns:
            Dictionary representing the stats2.json structure
        """
        # Convert VariableAggregateStats objects to dicts if needed
        from .aggregator import VariableAggregateStats

        agg_dicts = {}
        for var_name, stats in aggregates.items():
            if isinstance(stats, VariableAggregateStats):
                agg_dicts[var_name] = stats.to_dict()
            else:
                agg_dicts[var_name] = stats

        # Extract project name from project_root (e.g., "HoS" from "/path/to/HoS")
        project_name = self.project_root.name if self.project_root else None

        report = {
            "schema_version": self.SCHEMA_VERSION,
            "branchpy_version": self.VERSION,
            "projectVersion": self.VERSION,  # RC: Contract version
            "cfgVersion": "v1",  # RC: CFG schema version
            "statsVersion": "2",  # RC: Stats2 format version
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "project": project_name,  # PILOT: Project identifier
            "project_root": str(self.project_root) if self.project_root else None,
            "summary": {
                "total_variables": len(agg_dicts),
                "total_paths": 0,  # Will be filled from path_analyses
                "stat_variables": sum(
                    1
                    for stats in agg_dicts.values()
                    if stats.get("flags", {}).get("is_stat", False)
                ),
                "flag_variables": sum(
                    1
                    for stats in agg_dicts.values()
                    if stats.get("flags", {}).get("is_flag", False)
                ),
                "type_inconsistencies": sum(
                    1
                    for stats in agg_dicts.values()
                    if not stats.get("type_consistency", {}).get("is_consistent", True)
                ),
                "potentially_unused": sum(
                    1
                    for stats in agg_dicts.values()
                    if stats.get("flags", {}).get("potentially_unused", False)
                ),
            },
            "performance": (
                {
                    "analysis_duration_ms": analysis_duration_ms,
                }
                if analysis_duration_ms
                else None
            ),
            "aggregates": agg_dicts,
            "paths": (
                self._export_paths(path_analyses, path_analyzer)
                if path_analyses
                else []
            ),
        }

        # Update total_paths from path_analyses
        if path_analyses:
            report["summary"]["total_paths"] = len(path_analyses)

        # Write to file if output_path provided
        if output_path:
            output_path = Path(output_path)  # Ensure it's a Path object
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, "w", encoding="utf-8") as f:
                json.dump(report, f, indent=2, ensure_ascii=False)

        return report

    def _export_paths(
        self,
        path_analyses: Dict[List[str], Dict[str, List[Any]]],
        path_analyzer: Optional[Any] = None,
    ) -> List[Dict[str, Any]]:
        """Export per-path analysis results.

        Args:
            path_analyses: Dictionary mapping paths to variable timelines
            path_analyzer: Optional PathStatsAnalyzer for PILOT state changes

        Returns:
            List of path analysis dictionaries
        """
        paths = []

        # Generate sequential path IDs
        for idx, (path_labels, var_timelines) in enumerate(
            path_analyses.items(), start=1
        ):
            path_id = f"p{idx:03d}"  # e.g., p001, p002, p003

            path_data = {
                "pathId": path_id,  # PILOT: Sequential path identifier
                "path": list(path_labels),
                "length": len(path_labels),
                "variables": {},
            }

            # PILOT: Add engine-agnostic state changes
            if path_analyzer and hasattr(path_analyzer, "get_state_changes_for_path"):
                try:
                    state_changes = path_analyzer.get_state_changes_for_path(
                        list(path_labels)
                    )
                    path_data["stateChanges"] = state_changes
                except Exception:
                    # Graceful degradation if state tracker not available
                    path_data["stateChanges"] = []
            else:
                path_data["stateChanges"] = []

            # Export variable timelines for this path
            for var_name, changes in var_timelines.items():
                timeline = []

                for change in changes:
                    change_data = {
                        "label": getattr(change, "label", None),
                        "operation": getattr(change, "operation", "assign"),
                        "file": getattr(change, "file", None),
                        "line": getattr(change, "line", None),
                    }

                    # Add before/after states if available
                    if hasattr(change, "before") and change.before:
                        change_data["before"] = {
                            "value": getattr(change.before, "value", None),
                            "type": getattr(change.before, "value_type", "unknown"),
                        }

                    if hasattr(change, "after") and change.after:
                        change_data["after"] = {
                            "value": getattr(change.after, "value", None),
                            "type": getattr(change.after, "value_type", "unknown"),
                        }

                    # Add delta if numeric
                    if hasattr(change, "delta"):
                        delta = change.delta()
                        if delta is not None:
                            change_data["delta"] = delta

                    # Phase 3: Add expression evaluation diagnostics (optional, non-breaking)
                    if hasattr(change, "expr") and change.expr:
                        change_data["expr"] = change.expr

                    if hasattr(change, "eval_result") and change.eval_result:
                        change_data["eval"] = change.eval_result

                    if hasattr(change, "is_calculated"):
                        change_data["calc"] = change.is_calculated

                    # Phase 3 Commit 5: Add guard annotation (optional, non-breaking)
                    if hasattr(change, "guard") and change.guard:
                        change_data["guard"] = change.guard

                    timeline.append(change_data)

                path_data["variables"][var_name] = {
                    "changes": timeline,
                    "change_count": len(timeline),
                }

            paths.append(path_data)

        return paths

    @staticmethod
    def load(file_path: Path) -> Dict[str, Any]:
        """Load a stats2.json file.

        Args:
            file_path: Path to stats2.json file

        Returns:
            Parsed stats2 data
        """
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)

    @staticmethod
    def build_thin_payload(full_payload: Dict[str, Any]) -> Dict[str, Any]:
        """Build a Class B public-facing payload from the full internal payload.

        The thin payload retains only user-actionable fields: schema metadata,
        project identity, summary counts, warnings, and narrative summary
        counts.  Per-variable aggregates (scoring heuristics), full path
        timelines, and narrative topology are Class C internals and are
        excluded from the public file.

        Args:
            full_payload: Full internal payload as returned by ``export()``.

        Returns:
            Thin dict safe to write to the public ``stats2.json`` path.
        """
        # Narrative summary: keep human-readable fields only; drop topology.
        raw_narrative = full_payload.get("narrative_summary", {})
        thin_narrative: Dict[str, Any] = {}
        if raw_narrative:
            for key in (
                "narrative_entry_label",
                "narrative_paths_estimate",
                "narrative_outcomes_estimate",
                "narrative_confidence",
                "narrative_notes",
                # Entry-resolution provenance (added in stats2_cmd step 4b).
                # These let the VS Code panel display "Detected / Override / Status"
                # without requiring the full internal payload.
                "entry_override_requested",
                "entry_resolution_status",
                # Root candidates and unavailability reason: safe to expose in thin
                # payload — they are label names only, no engine internals.
                "narrative_root_candidates",
                "narrative_unavailable_reason",
            ):
                if key in raw_narrative:
                    thin_narrative[key] = raw_narrative[key]
            # narrative_topology is Class C — not included in public output.

        thin: Dict[str, Any] = {
            "schema_version": full_payload.get("schema_version"),
            "branchpy_version": full_payload.get("branchpy_version"),
            "projectVersion": full_payload.get("projectVersion"),
            "cfgVersion": full_payload.get("cfgVersion"),
            "statsVersion": full_payload.get("statsVersion"),
            "generated_at": full_payload.get("generated_at"),
            "project": full_payload.get("project"),
            "warnings": full_payload.get("warnings"),
            "meta": full_payload.get("meta"),
        }
        # summary: copy all keys except drill-down label lists (Class C only).
        full_summary = full_payload.get("summary") or {}
        _CLASS_C_SUMMARY_KEYS = {"structure_covered_labels", "structure_uncovered_labels"}
        thin_summary = {k: v for k, v in full_summary.items() if k not in _CLASS_C_SUMMARY_KEYS}
        thin["summary"] = thin_summary or None
        thin["performance"] = full_payload.get("performance")
        if thin_narrative:
            thin["narrative_summary"] = thin_narrative
        # Preserve legacy version alias
        if "version" in full_payload:
            thin["version"] = full_payload["version"]
        # Remove None-valued top-level keys to keep the file clean
        return {k: v for k, v in thin.items() if v is not None}
