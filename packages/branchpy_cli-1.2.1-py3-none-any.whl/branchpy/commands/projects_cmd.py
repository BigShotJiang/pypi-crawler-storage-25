# branchpy/commands/projects_cmd.py
from __future__ import annotations

import argparse
import json
from pathlib import Path

from ..config_store import ConfigStore


def cmd_projects(args: argparse.Namespace) -> int:
    store = ConfigStore()
    cfg = store.cfg

    if args.action == "add":
        path = Path(args.path).expanduser().resolve()
        cfg.set_project(args.name, str(path))
        store.save()
        print(f"Added '{args.name}' → {path}")
        return 0

    if args.action == "remove":
        ok = cfg.remove_project(args.name)
        store.save()
        print("Removed." if ok else "Not found.")
        return 0

    if args.action == "rename":
        ok = cfg.rename_project(args.old, args.new)
        store.save()
        print("Renamed." if ok else "Failed (exists or missing).")
        return 0

    if args.action == "list":
        out = {
            "default": cfg.default_project,
            "projects": cfg.projects,
        }
        if args.json:
            print(json.dumps(out, ensure_ascii=False, indent=2))
        else:
            print("=== Projects ===")
            if not out["projects"]:
                print("(none)")
            for name, path in out["projects"].items():
                star = " *default" if name == out["default"] else ""
                print(f"- {name}: {path}{star}")
        return 0

    if args.action == "set-default":
        name_or_path = args.name_or_path
        if name_or_path in cfg.projects:
            cfg.set_default_project(name_or_path)
            store.save()
            print(f"Default set → {cfg.projects[name_or_path]}")
            return 0
        p = Path(name_or_path).expanduser().resolve()
        if p.exists():
            synth = p.name
            cfg.set_project(synth, str(p))
            cfg.set_default_project(synth)
            store.save()
            print(f"Default set → {p} (registered as '{synth}')")
            return 0
        print("Failed to set default.")
        return 1

    if args.action == "show":
        if args.name in cfg.projects:
            print(cfg.projects[args.name])
            return 0
        print("Not found.")
        return 1

    return 2


def add_parser(subparsers):
    from ..cli_help import HelpFmt, fmt_examples

    p = subparsers.add_parser(
        "projects",
        help="Manage friendly project names and defaults.",
        description="Register, list, rename, and set a default project.",
        epilog=fmt_examples(
            "branchpy projects add mygame C:/VN/tests/game",
            "branchpy projects list",
            "branchpy projects set-default mygame",
            "branchpy projects rename mygame mygame2",
            "branchpy projects remove mygame2",
            "branchpy projects show mygame",
            "branchpy projects list --json",
            "branchpy projects set-default C:/VN/tests/game",
        ),
        formatter_class=HelpFmt,  # optional if you want nice help formatting
    )

    sp = p.add_subparsers(dest="action", required=True)

    # Each sub-action (add, remove, list, etc.)
    a = sp.add_parser("add", help="Add a project mapping.")
    a.add_argument("name")
    a.add_argument("path")

    r = sp.add_parser("remove", help="Remove a project mapping.")
    r.add_argument("name")

    rn = sp.add_parser("rename", help="Rename a project mapping.")
    rn.add_argument("old")
    rn.add_argument("new")

    ls = sp.add_parser("list", help="List all projects.")
    ls.add_argument("--json", action="store_true")

    sd = sp.add_parser(
        "set-default", help="Set default project (by name or absolute path)."
    )
    sd.add_argument("name_or_path")

    sh = sp.add_parser("show", help="Show path for a project name.")
    sh.add_argument("name")

    # Assign the handler for all project subcommands
    p.set_defaults(handler=cmd_projects)
