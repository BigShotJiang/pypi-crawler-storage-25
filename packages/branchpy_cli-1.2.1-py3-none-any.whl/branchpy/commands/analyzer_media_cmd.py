"""
Analyzer Media Command — Phase C v0.9.7

Ticket: WP-26
Module: branchpy.commands.analyzer_media_cmd
Version: v0.9.7

Modern media analysis command using Phase C adapter system.
Replaces old regex-based media.py with ScriptGraph + PFI integration.

Usage:
    branchpy analyzer media --referenced --json
    branchpy analyzer media --missing
    branchpy analyzer media --engine renpy
"""

import json
import sys
from pathlib import Path
from typing import Optional

from branchpy.analyze.media_adapters import detect_engine, get_phase_c_adapter


def cmd_analyzer_media_referenced(
    project_root: str,
    engine: Optional[str] = None,
    as_json: bool = False,
) -> int:
    """
    Extract referenced media using Phase C adapters.

    Args:
        project_root: Path to project root
        engine: Engine name (auto-detected if None)
        as_json: Output JSON format

    Returns:
        Exit code (0 = success)
    """
    project_path = Path(project_root).resolve()

    # Auto-detect engine if not specified
    if engine is None:
        engine = detect_engine(project_path) or "generic"

    # Get appropriate Phase C adapter (no constructor args for Phase C adapters)
    try:
        adapter = get_phase_c_adapter(engine)
    except Exception as e:
        print(
            f"Error: Failed to create extractor for engine '{engine}': {e}",
            file=sys.stderr,
        )
        return 1

    # Run Phase C collection
    try:
        phase_c_result = adapter.collect_phase_c(project_path)

        if as_json:
            print(
                json.dumps(phase_c_result.to_json_dict(), indent=2, ensure_ascii=False)
            )
        else:
            # Human-readable output
            files = phase_c_result.files
            print(f"Referenced Media: {len(files)} tags")
            for record in files:
                kind = (
                    record.kind.value
                    if hasattr(record.kind, "value")
                    else str(record.kind)
                )
                exists = (
                    "✓" if record.exists else ("✗" if record.exists is False else "?")
                )
                print(f"  {exists} [{kind:5}] {record.tag}")
            for warning in phase_c_result.warnings:
                print(f"  WARNING: {warning}", file=sys.stderr)

        return 0

    except Exception as e:
        print(f"Error: Media extraction failed: {e}", file=sys.stderr)
        import traceback

        traceback.print_exc()
        return 1


def add_parser(subparsers):
    """
    Register analyzer media command with CLI.

    Args:
        subparsers: Argparse subparsers object
    """
    # Create 'analyzer' parent command
    analyzer_parser = subparsers.add_parser(
        "analyzer",
        help="Advanced analyzer commands (Phase C+)",
        description="Modern analyzer commands using ScriptGraph + PFI",
    )
    analyzer_subs = analyzer_parser.add_subparsers(
        dest="analyzer_command", required=True
    )

    # Add 'media' subcommand
    media_parser = analyzer_subs.add_parser(
        "media",
        help="Media analysis using Phase C adapters",
        description="Extract and validate media references using engine-specific adapters",
    )

    # Subcommand flags
    media_parser.add_argument(
        "--referenced", action="store_true", help="List all referenced media files"
    )
    media_parser.add_argument(
        "--missing",
        action="store_true",
        help="List missing media files (not yet implemented)",
    )

    # Options
    media_parser.add_argument(
        "--engine",
        choices=["renpy", "unity", "godot", "generic"],
        help="Override engine auto-detection",
    )
    media_parser.add_argument(
        "--json", action="store_true", help="Output in JSON format"
    )

    # Handler
    def media_handler(args):
        if args.referenced:
            return cmd_analyzer_media_referenced(
                project_root=args.project,
                engine=args.engine,
                as_json=args.json,
            )
        elif args.missing:
            print(
                "Error: --missing not yet implemented (use 'branchpy media --missing')",
                file=sys.stderr,
            )
            return 1
        else:
            print("Error: Specify --referenced or --missing", file=sys.stderr)
            return 1

    media_parser.set_defaults(handler=media_handler)


def run(args):
    """
    CLI entry point for analyzer command.

    Args:
        args: Parsed arguments

    Returns:
        Exit code
    """
    # The handler was already set by add_parser, just call it
    if hasattr(args, "handler"):
        return args.handler(args)
    else:
        print("Error: No handler found for analyzer command", file=sys.stderr)
        return 1


if __name__ == "__main__":
    # Standalone test
    import sys

    sys.exit(cmd_analyzer_media_referenced(".", as_json=True))
