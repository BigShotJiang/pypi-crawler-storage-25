# branchpy/commands/media_cmd.py
import fnmatch
import logging
import os
import re
import sys
import time
from typing import Dict, List, Literal, Optional, Set, Tuple

from branchpy.report import safe_print, safe_print_err
from branchpy.report_writer import (
    create_media_report,
    should_emit_from_args,
    write_report_and_emit,
)

log = logging.getLogger("branchpy.media")

# ---- Regexes ---------------------------------------

# Image/file references defined via: image foo bar = "images/bg.png"
IMAGE_DEF_RE = re.compile(r'^\s*image\s+[A-Za-z0-9_ ]+\s*=\s*"(.*?)"\s*$', re.MULTILINE)

# Ren'Py image placeholder definitions: image eileen happy = "characters/eileen_happy.png"
# Captures the placeholder name (e.g., "eileen happy") for later resolution
IMAGE_PLACEHOLDER_DEF_RE = re.compile(
    r'^\s*image\s+([A-Za-z0-9_ ]+)\s*=\s*"(.*?)"\s*$', re.MULTILINE
)

# Show/scene with placeholders: show eileen happy, scene bg kitchen
# Captures the placeholder name for lookup
SHOW_SCENE_PLACEHOLDER_RE = re.compile(
    r"^\s*(?:show|scene)\s+([A-Za-z0-9_]+(?: [A-Za-z0-9_]+)*)\s*(?:at|with|behind|onlayer|as|zorder|$)",
    re.MULTILINE,
)

# "play music/sound/voice" lines: play music "music/soft.ogg"
PLAY_RE = re.compile(r'^\s*play\s+(?:music|sound|voice)\s+"(.*?)"\s*$', re.MULTILINE)

# Video playback lines: play movie "cutscene.webm"
MOVIE_RE = re.compile(r'^\s*play\s+movie\s+"(.*?)"\s*$', re.MULTILINE)

# Python-side movie playback: $ renpy.movie_cutscene("intro.mp4")
MOVIE_CUTSCENE_RE = re.compile(r'renpy\.movie_cutscene\(\s*"(.*?)"\s*\)')

# Voice shortcut: voice "voice/line_001.ogg"
VOICE_RE = re.compile(r'^\s*voice\s+"(.*?)"\s*$', re.MULTILINE)

# Show/scene with direct file path (rare, but supported when quoted):
#   scene "bg/room.png"
#   show expression "sprites/claire/happy.png"
SCENE_SHOW_PATH_RE = re.compile(
    r'^\s*(?:scene|show(?:\s+expression)?)\s+"(.*?)"\s*$', re.MULTILINE
)

# Anything that looks like a dynamic/format string we'll skip and report as unresolved
DYNAMIC_QUOTED_RE = re.compile(r'["\']\s*\{.*?\}\s*["\']')

# ---- Helpers ----------------------------------------------------------------


def _read_text(path: str) -> str:
    try:
        with open(path, encoding="utf-8") as f:
            return f.read()
    except UnicodeDecodeError:
        with open(path, encoding="latin-1") as f:
            return f.read()


def _norm(p: str) -> str:
    # normalize slashes and collapse .. segments; keep case as-is (Ren'Py is case-sensitive on Linux)
    return os.path.normpath(p.replace("\\", "/")).replace("\\", "/")


def _categorize_media(path: str) -> str:
    """
    Infer media category from file path and name using Ren'Py conventions.
    Returns: 'character', 'background', 'ui', 'effect', 'music', 'sfx', 'voice', 'video', 'other'
    """
    path_lower = path.lower().replace("\\", "/")
    name = os.path.basename(path_lower)

    # Check path segments for common folder patterns
    if any(x in path_lower for x in ["/character", "/sprite", "/chr", "/npc"]):
        return "character"
    if any(x in path_lower for x in ["/background", "/bg", "/scene"]):
        return "background"
    if any(x in path_lower for x in ["/ui", "/gui", "/button", "/icon", "/menu"]):
        return "ui"
    if any(x in path_lower for x in ["/effect", "/fx", "/particle", "/overlay"]):
        return "effect"
    if any(x in path_lower for x in ["/music", "/bgm", "/ost"]):
        return "music"
    if any(x in path_lower for x in ["/sound", "/sfx", "/audio/s"]):
        return "sfx"
    if any(x in path_lower for x in ["/voice", "/vo", "/dialogue"]):
        return "voice"
    if any(x in path_lower for x in ["/video", "/movie", "/cutscene", "/movies"]):
        return "video"

    # Check file extension for audio files without clear path
    ext = os.path.splitext(name)[1].lower()
    if ext in [".ogg", ".mp3", ".wav", ".opus"]:
        # Try to infer from filename
        if any(x in name for x in ["music", "bgm", "theme", "ost"]):
            return "music"
        if any(x in name for x in ["voice", "vo_", "dlg_"]):
            return "voice"
        return "sfx"  # Default for audio

    if ext in [".mp4", ".webm", ".ogv", ".avi", ".mov", ".mkv"]:
        return "video"

    # Check for image types by name patterns
    if ext in [".png", ".jpg", ".jpeg", ".webp"]:
        # Common character name patterns (ends with emotion/pose)
        if any(
            x in name
            for x in [
                "_happy",
                "_sad",
                "_angry",
                "_neutral",
                "_smile",
                "_blush",
                "_surprised",
                "_worried",
                "_vhappy",
                "_concerned",
            ]
        ):
            return "character"
        # Background indicators
        if any(
            x in name
            for x in ["bg_", "background_", "_day", "_night", "_evening", "_morning"]
        ):
            return "background"
        # UI elements
        if any(
            x in name
            for x in ["button", "icon", "cursor", "frame", "box", "bar_", "gui_"]
        ):
            return "ui"

    return "other"


def _suggest_categories(media_files: List[str]) -> List[Dict]:
    """
    Auto-suggest custom categories by analyzing filename patterns.
    Returns list of suggested categories with regex patterns.

    Examples:
      - eileen_happy.png, eileen_sad.png → Category: "Eileen" with pattern: ^eileen_
      - bg_kitchen.jpg, bg_bedroom.jpg → Category: "Backgrounds" with pattern: ^bg_
    """
    import re
    from collections import defaultdict

    # Group files by common prefixes (character names, etc.)
    prefix_groups = defaultdict(list)

    for path in media_files:
        filename = os.path.basename(path).lower()
        name_without_ext = os.path.splitext(filename)[0]

        # Look for common patterns: name_emotion, name_pose, etc.
        parts = re.split(r"[_\-\s]", name_without_ext)
        if len(parts) >= 2:
            # First part is likely the character/object name
            prefix = parts[0]
            if (
                len(prefix) >= 3 and prefix.isalpha()
            ):  # Valid name (at least 3 letters, all alphabetic)
                prefix_groups[prefix].append(filename)

    # Generate suggestions for groups with 3+ files
    suggestions = []
    for prefix, files in prefix_groups.items():
        if len(files) >= 3:  # Only suggest if we have at least 3 files with this prefix
            category_name = prefix.capitalize()
            regex_pattern = f"^{prefix}_"

            suggestions.append(
                {
                    "name": category_name,
                    "icon": "👤",  # Default to character icon
                    "regex": regex_pattern,
                    "folder": "",
                    "sample_files": files[:5],  # Include sample files for preview
                    "match_count": len(files),
                }
            )

    # Sort by match count (most common first)
    suggestions.sort(key=lambda x: x["match_count"], reverse=True)

    return suggestions


def _rel_norm(base: str, full: str) -> str:
    try:
        rel = os.path.relpath(full, base)
    except ValueError:
        rel = full
    return _norm(rel)


# ---- Scan script refs --------------------------------------------------------
def _is_ignored(base: str, path: str, patterns: Optional[list[str]]) -> bool:
    """Return True if path (relative to base) matches any ignore glob."""
    if not patterns:
        return False
    rel = os.path.relpath(path, base)
    return any(fnmatch.fnmatch(rel.replace("\\", "/"), pat) for pat in patterns)


def _line_of(text: str, idx: int) -> int:
    # 1-based line number (handles \r\n and \n by counting \n)
    return text.count("\n", 0, idx) + 1


def _collect_refs_in_text(
    text: str, file_path: str, placeholder_registry: Dict[str, str]
) -> Tuple[List[Dict], List[Dict]]:
    refs = []
    skipped = []

    # Collect all image placeholder definitions in THIS file (already in global registry)
    for m in IMAGE_PLACEHOLDER_DEF_RE.finditer(text):
        file_path_str = m.group(2)
        line = _line_of(text, m.start(2))

        if DYNAMIC_QUOTED_RE.search(file_path_str):
            skipped.append(
                {
                    "kind": "dynamic",
                    "file": file_path,
                    "value": file_path_str,
                    "line": line,
                }
            )
            continue

        # Add to refs (file itself is referenced by the definition)
        refs.append(
            {
                "kind": "img",
                "file": file_path,
                "value": _norm(file_path_str),
                "line": line,
            }
        )

    def add(kind: str, m: re.Match):
        raw = m.group(1)
        line = _line_of(text, m.start(1))
        if DYNAMIC_QUOTED_RE.search(raw):
            skipped.append(
                {"kind": "dynamic", "file": file_path, "value": raw, "line": line}
            )
            return
        refs.append(
            {"kind": kind, "file": file_path, "value": _norm(raw), "line": line}
        )

    # Resolve show/scene placeholder references
    for m in SHOW_SCENE_PLACEHOLDER_RE.finditer(text):
        placeholder_name = m.group(1).strip().lower()
        line = _line_of(text, m.start(1))

        # Try to resolve placeholder to actual file
        if placeholder_name in placeholder_registry:
            resolved_path = placeholder_registry[placeholder_name]
            refs.append(
                {"kind": "img", "file": file_path, "value": resolved_path, "line": line}
            )
        else:
            # Placeholder not defined - try common naming convention
            # "eileen happy" -> "eileen_happy.png" or "eileen/happy.png"
            guessed_path = placeholder_name.replace(" ", "_")
            skipped.append(
                {
                    "kind": "unresolved_placeholder",
                    "file": file_path,
                    "value": placeholder_name,
                    "guessed": guessed_path,
                    "line": line,
                }
            )

    # Collect audio references (always quoted)
    for m in PLAY_RE.finditer(text):
        add("snd", m)
    for m in VOICE_RE.finditer(text):
        add("snd", m)
    for m in MOVIE_RE.finditer(text):
        add("vid", m)
    for m in MOVIE_CUTSCENE_RE.finditer(text):
        add("vid", m)

    # Collect direct quoted image paths
    for m in SCENE_SHOW_PATH_RE.finditer(text):
        add("img", m)

    return refs, skipped


def _scan_project_for_media(
    project_root: str, ignore: Optional[list[str]] = None
) -> Tuple[List[Dict], List[Dict]]:
    refs_all: List[Dict] = []
    skipped_all: List[Dict] = []
    placeholder_registry = {}  # Global placeholder registry across all files

    # First pass: Collect all .rpy files and build placeholder registry
    rpy_files = []
    for r, dirs, files in os.walk(project_root):
        if ignore:
            # prune ignored directories early
            dirs[:] = [
                d
                for d in dirs
                if not _is_ignored(project_root, os.path.join(r, d), ignore)
            ]
        for fn in files:
            full = os.path.join(r, fn)
            if not fn.endswith(".rpy"):
                continue
            if ignore and _is_ignored(project_root, full, ignore):
                continue
            rpy_files.append(full)

    # First pass: Build placeholder registry from all image definitions
    for full in rpy_files:
        text = _read_text(full)
        for m in IMAGE_PLACEHOLDER_DEF_RE.finditer(text):
            placeholder_name = m.group(1).strip().lower()
            file_path_str = m.group(2)

            # Skip dynamic strings
            if DYNAMIC_QUOTED_RE.search(file_path_str):
                continue

            # Store in global registry
            placeholder_registry[placeholder_name] = _norm(file_path_str)

    # Second pass: Collect all references using the registry
    for full in rpy_files:
        text = _read_text(full)
        refs, skipped = _collect_refs_in_text(text, full, placeholder_registry)
        refs_all.extend(refs)
        skipped_all.extend(skipped)

    return refs_all, skipped_all


def _exists_under_assets(asset_root: str, rel_path: str) -> bool:
    # Most scripts reference paths relative to the game/ folder.
    # If rel_path is absolute, just check it; otherwise join to asset_root.
    candidate = (
        rel_path if os.path.isabs(rel_path) else os.path.join(asset_root, rel_path)
    )
    return os.path.exists(candidate)


# ---- Missing -----------------------------------------------------------------


def run_missing(
    project: str,
    assets_root: str,
    as_json: bool = False,
    ignore: Optional[list[str]] = None,
    emit: bool = True,
    export_csv: Optional[str] = None,
    bqf_media: bool = False,
    policy_mode: str = "off",
    policy_config: Optional[str] = None,
) -> int:
    """
    Scan project for missing media files.

    v0.7.29: Added CSV export support for missing images.
    WS-B1: Added BQF policy enforcement with exit codes.

    Returns:
        0: Success
        65: BQF policy violation
        66: BQF remote error
        67: BQF partial analysis
    """
    start_time = time.time()
    refs, skipped = _scan_project_for_media(project, ignore=ignore)
    missing = [r for r in refs if not _exists_under_assets(assets_root, r["value"])]
    ok_count = len(refs) - len(missing)

    # Add categories to missing items
    for item in missing:
        item["category"] = _categorize_media(item["value"])

    duration_ms = int((time.time() - start_time) * 1000)

    # v0.7.29: Export to CSV if requested
    if export_csv:
        import csv
        from pathlib import Path

        csv_path = Path(export_csv)
        csv_path.parent.mkdir(parents=True, exist_ok=True)

        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["path", "label", "referenced_by"])

            for m in missing:
                # Extract label from file path (last component before extension)
                label = Path(m["value"]).stem
                ref_location = f"{m['file']}:{m.get('line', '?')}"
                writer.writerow([m["value"], label, ref_location])

        safe_print(f"Exported {len(missing)} missing file(s) to {csv_path}")
        return 0

    if as_json:
        payload = {
            "mode": "missing",
            "summary": {"issues": len(missing)},
            "issues": missing,
            "skipped": skipped,
        }
        from json import dumps as _dumps

        safe_print(_dumps(payload, indent=2, ensure_ascii=False))
    else:
        safe_print(f"Missing media ({len(missing)})")
        if len(missing) == 0:
            safe_print("  ✓ All media files found (no issues)")
        else:
            for m in missing:
                tag = "img" if m["kind"] == "img" else "snd"
                safe_print(f"{tag:3} {m['value']:<35} {m['file']}:{m.get('line', '?')}")
        if skipped:
            safe_print(f"\nSkipped (dynamic/unresolved) ({len(skipped)})")
            for s in skipped:
                safe_print(f"- dynamic: {s['file']}:{s.get('line', '?')}  {s['value']}")

    # Emit dashboard report
    if emit:
        project_name = os.path.basename(os.path.abspath(project))

        # Convert missing items to dashboard format
        items = []
        for m in missing:
            items.append(
                {
                    "type": "image" if m["kind"] == "img" else "sound",
                    "path": m["value"],
                    "status": "missing",
                    "ref": f"{m['file']}:{m.get('line', '?')}",
                }
            )

        # Add OK items for completeness
        for r in refs:
            if not any(m["value"] == r["value"] for m in missing):
                items.append(
                    {
                        "type": "image" if r["kind"] == "img" else "sound",
                        "path": r["value"],
                        "status": "ok",
                        "ref": f"{r['file']}:{r.get('line', '?')}",
                    }
                )

        report = create_media_report(
            kind="media-missing",
            title="Media — Missing",
            project_name=project_name,
            missing_count=len(missing),
            ok_count=ok_count,
            total_count=len(refs),
            duration_ms=duration_ms,
            items=items,
        )

        # M-12: Write to canonical .branchpy/media/ (primary); /out/ backward-compat copy is
        # written automatically by write_report_and_emit when out≠None and outside /out/.
        _media_dir = os.path.join(os.path.abspath(project), ".branchpy", "media")
        os.makedirs(_media_dir, exist_ok=True)
        _ts = time.strftime("%Y%m%d-%H%M%S")
        _media_out = os.path.join(_media_dir, f"media-{project_name}-{_ts}.json")
        write_report_and_emit(report, project, emit, out=_media_out)

    return 1 if missing else 0


# ---- Unused ------------------------------------------------------------------

_DEFAULT_EXTS = [
    ".png",
    ".webp",
    ".jpg",
    ".jpeg",
    ".ogg",
    ".mp3",
    ".wav",
    ".opus",
    ".mp4",
    ".webm",
    ".ogv",
]


def _asset_lookup_keys(path: str) -> Set[str]:
    normalized = _norm(path).lower()
    no_ext = os.path.splitext(normalized)[0]
    stem = os.path.basename(no_ext)
    keys = {normalized, no_ext, stem}
    for prefix in (
        "images/",
        "audio/",
        "music/",
        "sound/",
        "voice/",
        "video/",
        "movies/",
    ):
        if no_ext.startswith(prefix):
            keys.add(no_ext[len(prefix) :])
    return {k for k in keys if k}


def _build_asset_lookup(on_disk: List[str]) -> Dict[str, List[str]]:
    lookup: Dict[str, List[str]] = {}
    for path in on_disk:
        for key in _asset_lookup_keys(path):
            lookup.setdefault(key, []).append(path)
    return lookup


def _resolve_logical_asset(
    raw_value: str,
    guessed_value: str,
    lookup: Dict[str, List[str]],
) -> Optional[str]:
    candidates: List[str] = []
    for value in (raw_value, guessed_value):
        normalized = _norm(value).lower().strip()
        if not normalized:
            continue
        candidates.extend(
            [
                normalized,
                normalized.replace("_", " "),
                normalized.replace(" ", "_"),
            ]
        )

    seen: Set[str] = set()
    for key in candidates:
        if key in seen:
            continue
        seen.add(key)
        matches = lookup.get(key, [])
        if len(matches) == 1:
            return matches[0]
    return None


def _parse_exts(exts: Optional[list[str]]) -> Set[str]:
    """
    Returns a normalized set like {'.png', '.jpg'}.
    If exts is None/empty, falls back to _DEFAULT_EXTS.
    """
    if not exts:
        return set(_DEFAULT_EXTS)

    out: Set[str] = set()
    for e in exts:
        e = (e or "").strip().lower().lstrip(".")
        if e:
            out.add(f".{e}")
    # If user passed only blanks, fall back to defaults
    return out or set(_DEFAULT_EXTS)


def _walk_assets(
    asset_root: str, exts: Set[str], ignore: Optional[list[str]] = None
) -> List[str]:
    results: List[str] = []
    for r, dirs, files in os.walk(asset_root):
        if ignore:
            # prune ignored directories early
            dirs[:] = [
                d
                for d in dirs
                if not _is_ignored(asset_root, os.path.join(r, d), ignore)
            ]
        for fn in files:
            full = os.path.join(r, fn)
            if ignore and _is_ignored(asset_root, full, ignore):
                continue
            if os.path.splitext(fn)[1].lower() in exts:
                results.append(_rel_norm(asset_root, full))
    return results


def run_unused(
    project: str,
    assets_root: str,
    exts: Optional[list[str]],
    as_json: bool = False,
    fail_on_unused: bool = False,
    ignore: Optional[list[str]] = None,
    emit: bool = True,
) -> int:
    start_time = time.time()
    refs, _ = _scan_project_for_media(project, ignore=ignore)
    ref_set = set(_norm(r["value"]).lower() for r in refs)

    exts_set = _parse_exts(exts)  # now strictly Set[str]
    on_disk = _walk_assets(assets_root, exts_set, ignore=ignore)
    if len(on_disk) == 0:
        safe_print_err(
            "Warning: No assets were scanned (scanned == 0). Check --assets path; try tests/media_demo/game"
        )

    unused = [p for p in on_disk if _norm(p).lower() not in ref_set]

    # Convert to dict format with categories
    unused_with_category = [
        {"path": p, "category": _categorize_media(p)} for p in unused
    ]

    duration_ms = int((time.time() - start_time) * 1000)

    if as_json:
        from json import dumps as _dumps

        payload = {
            "mode": "unused",
            "summary": {"issues": len(unused)},
            "issues": unused_with_category,
        }
        safe_print(_dumps(payload, indent=2, ensure_ascii=False))
    else:
        safe_print(f"Unused media ({len(unused)})")
        if len(unused) == 0:
            safe_print("  ✓ All media files are used (no issues)")
        else:
            for item in unused_with_category:
                safe_print(f"  [{item['category']:10}] {item['path']}")

    # Emit dashboard report
    if emit:
        project_name = os.path.basename(os.path.abspath(project))

        # Convert to dashboard format
        items = []
        for path in unused:
            # Determine file type from extension
            ext = os.path.splitext(path)[1].lower()
            file_type = (
                "image" if ext in [".png", ".webp", ".jpg", ".jpeg"] else "sound"
            )
            items.append(
                {"type": file_type, "path": path, "status": "unused", "ref": ""}
            )

        # Add used items for context
        for r in refs:
            if _norm(r["value"]).lower() in ref_set:
                items.append(
                    {
                        "type": "image" if r["kind"] == "img" else "sound",
                        "path": r["value"],
                        "status": "ok",
                        "ref": f"{r['file']}:{r.get('line', '?')}",
                    }
                )

        report = create_media_report(
            kind="media-unused",
            title="Media — Unused",
            project_name=project_name,
            unused_count=len(unused),
            ok_count=len(refs),
            total_count=len(on_disk),
            duration_ms=duration_ms,
            items=items,
        )

        # M-12: canonical .branchpy/media/ write
        _media_dir = os.path.join(os.path.abspath(project), ".branchpy", "media")
        os.makedirs(_media_dir, exist_ok=True)
        _ts = time.strftime("%Y%m%d-%H%M%S")
        _media_out = os.path.join(_media_dir, f"media-{project_name}-{_ts}.json")
        write_report_and_emit(report, project, emit, out=_media_out)

    return 2 if (fail_on_unused and unused) else 0


# ---- Referenced --------------------------------------------------------------


def run_referenced(
    project: str,
    assets_root: str,
    exts: Optional[list[str]],
    as_json: bool = False,
    ignore: Optional[list[str]] = None,
    emit: bool = True,
) -> int:
    """
    Scan project for media files that are both on disk AND referenced in scripts.
    This is the intersection of on-disk files and script references.
    """
    start_time = time.time()
    refs, _ = _scan_project_for_media(project, ignore=ignore)
    ref_set = set(_norm(r["value"]).lower() for r in refs)

    exts_set = _parse_exts(exts)
    on_disk = _walk_assets(assets_root, exts_set, ignore=ignore)

    # Intersection: files that exist on disk AND are referenced
    referenced = [p for p in on_disk if _norm(p).lower() in ref_set]

    # Convert to dict format with categories
    referenced_with_category = [
        {"path": p, "category": _categorize_media(p)} for p in referenced
    ]

    duration_ms = int((time.time() - start_time) * 1000)

    if as_json:
        from json import dumps as _dumps

        payload = {
            "mode": "referenced",
            "summary": {"count": len(referenced)},
            "files": referenced_with_category,  # Array of {path, category} objects
        }
        safe_print(_dumps(payload, indent=2, ensure_ascii=False))
    else:
        safe_print(f"Referenced media ({len(referenced)} files)")
        if len(referenced) == 0:
            safe_print("  No referenced files found")
        else:
            for item in referenced_with_category:
                safe_print(f"  [{item['category']:10}] {item['path']}")

    # Emit dashboard report
    if emit:
        project_name = os.path.basename(os.path.abspath(project))

        items = []
        for path in referenced:
            ext = os.path.splitext(path)[1].lower()
            file_type = (
                "image" if ext in [".png", ".webp", ".jpg", ".jpeg"] else "sound"
            )
            # Find the reference info
            ref_info = next(
                (r for r in refs if _norm(r["value"]).lower() == _norm(path).lower()),
                None,
            )
            ref_str = (
                f"{ref_info['file']}:{ref_info.get('line', '?')}" if ref_info else ""
            )

            items.append(
                {"type": file_type, "path": path, "status": "ok", "ref": ref_str}
            )

        report = create_media_report(
            kind="media-referenced",
            title="Media — Referenced",
            project_name=project_name,
            ok_count=len(referenced),
            total_count=len(on_disk),
            duration_ms=duration_ms,
            items=items,
        )

        # M-12: canonical .branchpy/media/ write
        _media_dir = os.path.join(os.path.abspath(project), ".branchpy", "media")
        os.makedirs(_media_dir, exist_ok=True)
        _ts = time.strftime("%Y%m%d-%H%M%S")
        _media_out = os.path.join(_media_dir, f"media-{project_name}-{_ts}.json")
        write_report_and_emit(report, project, emit, out=_media_out)

    return 0


def _is_protected_path(path: str) -> bool:
    """Return True if the asset is in a Ren'Py-managed directory."""
    p = path.lower().replace("\\", "/")
    # Mid-path markers (e.g. "sprites/gui/icons.png")
    protected_markers = ("/gui/", "/ui/", "/menu/", "/screens/", "/fonts/", "/system/")
    if any(m in p for m in protected_markers):
        return True
    # Leading-path prefixes: paths relative to game/ assets root (e.g. "gui/frame.png")
    protected_prefixes = ("gui/", "ui/", "menu/", "screens/", "fonts/", "system/")
    return any(p.startswith(pr) for pr in protected_prefixes)


def _protection_reason(path: str) -> str:
    """Return a human-readable reason why an asset path is protected from cleanup analysis."""
    p = path.lower().replace("\\", "/")
    if "/gui/" in p or p.startswith("gui/"):
        return "Ren'Py GUI system"
    if "/fonts/" in p or p.startswith("fonts/"):
        return "Font assets"
    if "/screens/" in p or p.startswith("screens/"):
        return "UI screen assets"
    if "/ui/" in p or p.startswith("ui/"):
        return "UI directory"
    if "/menu/" in p or p.startswith("menu/"):
        return "Menu assets"
    if "/system/" in p or p.startswith("system/"):
        return "System files"
    return "Protected directory"


def _build_media_browser_payload(
    project: str,
    assets_root: str,
    exts: Optional[list[str]],
    ignore: Optional[list[str]] = None,
) -> Dict:
    """Build a review-focused media payload for HTML rendering."""
    from difflib import SequenceMatcher, get_close_matches

    refs, skipped = _scan_project_for_media(project, ignore=ignore)
    exts_set = _parse_exts(exts)
    on_disk = _walk_assets(assets_root, exts_set, ignore=ignore)
    asset_lookup = _build_asset_lookup(on_disk)

    resolved_refs_by_path: Dict[str, List[Dict[str, str]]] = {}
    resolved_unresolved_placeholders: List[Dict] = []
    unresolved_skipped: List[Dict] = []
    for item in skipped:
        if item.get("kind") != "unresolved_placeholder":
            unresolved_skipped.append(item)
            continue
        resolved_path = _resolve_logical_asset(
            str(item.get("value", "")),
            str(item.get("guessed", "")),
            asset_lookup,
        )
        if not resolved_path:
            unresolved_skipped.append(item)
            continue
        ref_label = f"{item.get('file', '')}:{item.get('line', '?')}"
        key = _norm(resolved_path).lower()
        resolved_unresolved_placeholders.append(
            {
                "path": resolved_path,
                "ref": ref_label,
                "reason": "Resolved from Ren'Py image tag",
                "confidence": "resolved",
            }
        )
        resolved_refs_by_path.setdefault(key, []).append(
            resolved_unresolved_placeholders[-1]
        )

    direct_refs_by_path: Dict[str, List[Dict[str, str]]] = {}
    for ref in refs:
        value = str(ref.get("value", ""))
        if not _exists_under_assets(assets_root, value):
            continue
        key = _norm(value).lower()
        direct_refs_by_path.setdefault(key, []).append(
            {
                "path": value,
                "ref": f"{ref.get('file', '')}:{ref.get('line', '?')}",
                "reason": "Direct file reference",
                "confidence": "definite",
            }
        )

    ref_set = set(direct_refs_by_path.keys()) | set(resolved_refs_by_path.keys())
    missing = [r for r in refs if not _exists_under_assets(assets_root, r["value"])]
    unused = [p for p in on_disk if _norm(p).lower() not in ref_set]
    referenced = [p for p in on_disk if _norm(p).lower() in ref_set]

    protected_set = {p for p in on_disk if _is_protected_path(p)}
    protected_unused = [p for p in unused if p in protected_set]
    cleanup_candidates = [p for p in unused if p not in protected_set]

    needs_review = []
    for m in missing:
        needs_review.append(
            {
                "path": m.get("value", ""),
                "category": _categorize_media(m.get("value", "")),
                "confidence": "definite",
                "ref": f"{m.get('file', '')}:{m.get('line', '?')}",
                "reason": "Not found on disk",
            }
        )

    dynamic_risk = []
    for s in unresolved_skipped:
        val = s.get("value") or s.get("guessed") or ""
        reason = "Template / variable path"
        if s.get("kind") == "unresolved_placeholder":
            reason = "Unresolved Ren'Py image tag"
        dynamic_risk.append(
            {
                "path": val,
                "category": "dynamic",
                "confidence": "dynamic",
                "ref": f"{s.get('file', '')}:{s.get('line', '?')}",
                "reason": reason,
            }
        )

    used_items = []
    for path in referenced:
        key = _norm(path).lower()
        refs_for_path = direct_refs_by_path.get(key, []) + resolved_refs_by_path.get(
            key, []
        )
        reason = "Direct file reference"
        confidence = "definite"
        if refs_for_path and all(
            r.get("reason") == "Resolved from Ren'Py image tag" for r in refs_for_path
        ):
            reason = "Resolved from Ren'Py image tag"
            confidence = "resolved"
        elif refs_for_path and any(
            r.get("reason") == "Resolved from Ren'Py image tag" for r in refs_for_path
        ):
            reason = "Script reference + Ren'Py image tag"
        # Collect all unique script refs for the evidence panel
        all_refs = list({r.get("ref", "") for r in refs_for_path if r.get("ref", "")})
        used_items.append(
            {
                "path": path,
                "category": _categorize_media(path),
                "confidence": confidence,
                "ref": all_refs[0] if all_refs else "",
                "all_refs": all_refs[:10],
                "reason": reason,
            }
        )

    cleanup_items = [
        {
            "path": p,
            "category": _categorize_media(p),
            "confidence": "definite",
            "ref": "",
            "reason": "No script reference found",
        }
        for p in cleanup_candidates
    ]

    protected_items = [
        {
            "path": p,
            "category": _categorize_media(p),
            "confidence": "dynamic",
            "ref": "",
            "reason": _protection_reason(p),
        }
        for p in protected_unused
    ]

    # Rename-pair hints: suggest close on-disk matches for missing paths.
    rename_hints = []
    on_disk_by_name = {os.path.basename(p).lower(): p for p in on_disk}
    on_disk_names = list(on_disk_by_name.keys())
    for m in missing[:600]:
        miss_path = str(m.get("value", ""))
        miss_name = os.path.basename(miss_path).lower()
        if not miss_name:
            continue
        best = get_close_matches(miss_name, on_disk_names, n=1, cutoff=0.72)
        if not best:
            continue
        match_name = best[0]
        score = SequenceMatcher(None, miss_name, match_name).ratio()
        rename_hints.append(
            {
                "missing": miss_path,
                "suggested": on_disk_by_name.get(match_name, match_name),
                "score": round(score, 3),
            }
        )

    return {
        "summary": {
            "used": len(referenced),
            "referenced": len(referenced),
            "unused": len(unused),
            "missing": len(missing),
            "protected": len(protected_set),
            "dynamic_risk": len(dynamic_risk),
            "safe_cleanup": len(cleanup_candidates),
            "total_on_disk": len(on_disk),
            "total_refs": len(refs) + len(resolved_unresolved_placeholders),
        },
        "tiers": {
            "used": used_items,
            "protected": protected_items,
            "cleanup_candidates": cleanup_items,
            "needs_review": needs_review,
            "dynamic_risk": dynamic_risk,
        },
        "rename_hints": rename_hints,
    }


# ---- Entrypoint from CLI -----------------------------------------------------


def run(
    command: Optional[Literal["missing", "unused", "referenced"]] = None,
    project: str = ".",
    assets: str = "game",
    ext: Optional[str] = None,
    as_json: bool = False,
    fail_on_unused: bool = False,
    ignore: Optional[list[str]] = None,
    export_csv: Optional[str] = None,  # v0.7.29: CSV export support
    bqf_media: bool = False,  # WS-B1: Enable BQF policy enforcement
    policy_mode: str = "off",  # WS-B1: BQF enforcement mode
    policy_config: Optional[str] = None,  # WS-B1: BQF policy configuration
    engine: Optional[str] = None,  # WS-C1: Engine override
    remote_debug: bool = False,  # WS-C1: Display remote/engine context
    out: Optional[str] = None,  # HTML output path (via wrapper/dispatcher)
    html: bool = False,  # HTML artifact request (handled in parser wrapper)
    open_browser: bool = False,  # Browser launch request (handled in parser wrapper)
    args=None,  # For accessing emit settings
) -> int:
    import os
    import re

    # WS-C1: Display remote/engine context if debug enabled
    if remote_debug:
        try:
            from branchpy.core.engine_resolver import EngineResolver
            from branchpy.core.remote_context import RemoteContext

            remote_ctx = RemoteContext.detect()
            print(f"[Remote Context] Type: {remote_ctx.type.value}")
            print(f"[Remote Context] Is Remote: {remote_ctx.is_remote}")
            print(f"[Remote Context] Is CI: {remote_ctx.is_ci}")
            print(f"[Remote Context] Session: {remote_ctx.session_id}")

            engine_ctx = EngineResolver().detect()
            print(f"[Engine Detection] Type: {engine_ctx.engine_type.value}")
            print(f"[Engine Detection] Confidence: {engine_ctx.confidence:.2f}")
            if engine_ctx.version:
                print(f"[Engine Detection] Version: {engine_ctx.version}")
            print()
        except Exception as e:
            print(f"[WS-C1] Context detection error: {e}\n")

    # assets relative to project
    if assets and not os.path.isabs(assets):
        assets = os.path.join(project, assets)

    # normalize --ext → list[str] or None
    exts_list: Optional[list[str]] = None
    if ext:
        parts = [
            p.strip().lstrip(".").lower() for p in re.split(r"[,\s]+", ext) if p.strip()
        ]
        exts_list = parts or None

    # Determine if we should emit events
    emit = should_emit_from_args(args) if args else True

    if command == "missing":
        return run_missing(
            project=project,
            assets_root=assets,
            as_json=as_json,
            ignore=ignore,
            emit=emit,
            export_csv=export_csv,
            bqf_media=bqf_media,
            policy_mode=policy_mode,
            policy_config=policy_config,
        )

    if command == "unused":
        return run_unused(
            project=project,
            assets_root=assets,
            exts=exts_list,
            as_json=as_json,
            fail_on_unused=fail_on_unused,
            ignore=ignore,
            emit=emit,
        )

    if command == "referenced":
        return run_referenced(
            project=project,
            assets_root=assets,
            exts=exts_list,
            as_json=as_json,
            ignore=ignore,
            emit=emit,
        )

    safe_print(
        "branchpy media: specify a subcommand (e.g., --missing, --unused, or --referenced)"
    )
    return 1


def add_parser(subparsers):
    """Register the media command with the CLI parser."""
    from branchpy.cli_help import HelpFmt, fmt_examples

    media_p = subparsers.add_parser(
        "media",
        help="Scan project for missing or unused media files.",
        description="Validate media file references and detect unused assets.",
        epilog=fmt_examples(
            "branchpy --project /path/to/project media --missing",
            "branchpy --project /path/to/project media --unused",
            "branchpy --project /path/to/project media --missing --export-csv missing.csv",
        ),
        formatter_class=HelpFmt,
    )

    def media_handler(args):
        html_requested = getattr(args, "html", False) or getattr(
            args, "open_browser", False
        )

        # Browser mode defaults to triage/all when no explicit mode is given.
        if (
            html_requested
            and not getattr(args, "scan_all", False)
            and not getattr(args, "missing", False)
            and not getattr(args, "unused", False)
            and not getattr(args, "referenced", False)
        ):
            args.scan_all = True

        # Handle --all flag
        if getattr(args, "scan_all", False):
            # For JSON output, collect results and combine them
            if args.json:
                import json
                from io import StringIO

                results = {}
                exit_codes = []

                # Capture output for each mode
                for mode in ["missing", "unused", "referenced"]:
                    old_stdout = sys.stdout
                    sys.stdout = StringIO()

                    try:
                        exit_code = run(
                            command=mode,
                            project=args.project,
                            assets=args.assets,
                            ext=args.ext,
                            as_json=True,
                            fail_on_unused=args.fail_on_unused,
                            ignore=args.ignore,
                            export_csv=None,
                            bqf_media=getattr(args, "bqf_media", False),
                            policy_mode=getattr(args, "policy_mode", "off"),
                            policy_config=getattr(args, "policy_config", None),
                            engine=getattr(args, "engine", None),
                            remote_debug=getattr(args, "remote_debug", False),
                            args=args,
                        )
                        output = sys.stdout.getvalue()
                        if output.strip():
                            results[mode] = json.loads(output)
                        exit_codes.append(exit_code)
                    finally:
                        sys.stdout = old_stdout

                # Print combined JSON
                print(json.dumps(results, indent=2))
                result_code = max(exit_codes)
            else:
                # Non-JSON: run each mode normally
                exit_codes = []
                for mode in ["missing", "unused", "referenced"]:
                    exit_codes.append(
                        run(
                            command=mode,
                            project=args.project,
                            assets=args.assets,
                            ext=args.ext,
                            as_json=False,
                            fail_on_unused=args.fail_on_unused,
                            ignore=args.ignore,
                            export_csv=None,
                            bqf_media=getattr(args, "bqf_media", False),
                            policy_mode=getattr(args, "policy_mode", "off"),
                            policy_config=getattr(args, "policy_config", None),
                            engine=getattr(args, "engine", None),
                            remote_debug=getattr(args, "remote_debug", False),
                            args=args,
                        )
                    )
                result_code = max(exit_codes)

            if html_requested:
                try:
                    from pathlib import Path

                    from branchpy.cli.html_report import (
                        announce_html_report,
                        generate_media_html,
                    )
                    from branchpy.cli.html_report import (
                        open_in_browser as _open_browser,
                    )
                    from branchpy.cli.html_report import resolve_html_output_path

                    # assets relative to project
                    assets_root = args.assets
                    if assets_root and not os.path.isabs(assets_root):
                        assets_root = os.path.join(args.project, assets_root)

                    exts_list = None
                    if args.ext:
                        exts_list = [
                            p.strip().lstrip(".").lower()
                            for p in re.split(r"[,\s]+", args.ext)
                            if p.strip()
                        ]

                    payload = _build_media_browser_payload(
                        project=args.project,
                        assets_root=assets_root,
                        exts=exts_list,
                        ignore=args.ignore,
                    )
                    project_root = Path(args.project).resolve()
                    html_path = generate_media_html(
                        payload,
                        project_root,
                        resolve_html_output_path(project_root, "media", args.out),
                    )
                    announce_html_report("media", html_path)
                    if getattr(args, "open_browser", False):
                        print(
                            "[bpy] Opening interactive media report in browser...",
                            file=sys.stderr,
                        )
                        _open_browser(html_path)
                except Exception as _html_err:
                    print(
                        f"[bpy] Warning: Media HTML generation failed: {_html_err}",
                        file=sys.stderr,
                    )

            return result_code

        # Single mode
        command = (
            "missing"
            if args.missing
            else (
                "unused" if args.unused else ("referenced" if args.referenced else None)
            )
        )
        result_code = run(
            command=command,
            project=args.project,
            assets=args.assets,
            ext=args.ext,
            as_json=args.json,
            fail_on_unused=args.fail_on_unused,
            ignore=args.ignore,
            export_csv=args.export_csv,
            bqf_media=getattr(args, "bqf_media", False),
            policy_mode=getattr(args, "policy_mode", "off"),
            policy_config=getattr(args, "policy_config", None),
            engine=getattr(args, "engine", None),
            remote_debug=getattr(args, "remote_debug", False),
            args=args,
        )

        if html_requested:
            try:
                from pathlib import Path

                from branchpy.cli.html_report import (
                    announce_html_report,
                    generate_media_html,
                )
                from branchpy.cli.html_report import open_in_browser as _open_browser
                from branchpy.cli.html_report import resolve_html_output_path

                assets_root = args.assets
                if assets_root and not os.path.isabs(assets_root):
                    assets_root = os.path.join(args.project, assets_root)

                exts_list = None
                if args.ext:
                    exts_list = [
                        p.strip().lstrip(".").lower()
                        for p in re.split(r"[,\s]+", args.ext)
                        if p.strip()
                    ]

                payload = _build_media_browser_payload(
                    project=args.project,
                    assets_root=assets_root,
                    exts=exts_list,
                    ignore=args.ignore,
                )
                project_root = Path(args.project).resolve()
                html_path = generate_media_html(
                    payload,
                    project_root,
                    resolve_html_output_path(project_root, "media", args.out),
                )
                announce_html_report("media", html_path)
                if getattr(args, "open_browser", False):
                    print(
                        "[bpy] Opening interactive media report in browser...",
                        file=sys.stderr,
                    )
                    _open_browser(html_path)
            except Exception as _html_err:
                print(
                    f"[bpy] Warning: Media HTML generation failed: {_html_err}",
                    file=sys.stderr,
                )

        return result_code

    media_p.set_defaults(handler=media_handler)

    # Subcommand flags
    media_p.add_argument(
        "--missing",
        action="store_true",
        help="Scan for missing media files referenced by scripts",
    )
    media_p.add_argument(
        "--unused",
        action="store_true",
        help="Scan for unused media files in the asset directory",
    )
    media_p.add_argument(
        "--referenced",
        action="store_true",
        help="Scan for media files that are both on disk and referenced by scripts",
    )
    media_p.add_argument(
        "--all",
        dest="scan_all",
        action="store_true",
        help="Run all scan modes (missing, unused, referenced)",
    )

    # Options
    media_p.add_argument(
        "--assets",
        default="game",
        help="Assets directory relative to project (default: game)",
    )
    media_p.add_argument(
        "--ext",
        type=str,
        default="",
        help="Comma-separated list of file extensions to scan (e.g., png,jpg,ogg)",
    )
    media_p.add_argument(
        "--json", action="store_true", help="Output results in JSON format"
    )
    media_p.add_argument(
        "--html",
        action="store_true",
        help="Generate a review-focused HTML media report artifact.",
    )
    media_p.add_argument(
        "--open",
        dest="open_browser",
        action="store_true",
        help="Generate and open the media report in the browser (implies --html).",
    )
    media_p.add_argument(
        "--out",
        type=str,
        default="",
        metavar="PATH",
        help="Output path for HTML (used when --html or --open is set).",
    )
    media_p.add_argument(
        "--fail-on-unused",
        action="store_true",
        help="Exit with code 2 if unused files are found",
    )
    media_p.add_argument(
        "--ignore",
        type=str,
        action="append",
        help="Glob patterns to ignore (can be specified multiple times)",
    )
    media_p.add_argument(
        "--export-csv",
        type=str,
        default=None,
        help="Export missing files to CSV (missing mode only)",
    )

    # BQF-Media integration (WS-B1)
    media_p.add_argument(
        "--bqf-media",
        dest="bqf_media",
        action="store_true",
        default=False,
        help="Enable BQF policy enforcement for media analysis",
    )
    media_p.add_argument(
        "--policy-mode",
        choices=["off", "warn", "strict", "ci"],
        default="off",
        help="BQF enforcement mode: off (disabled), warn (log only), strict (fail on any violation), ci (fail on errors only)",
    )
    media_p.add_argument(
        "--policy-config",
        type=str,
        metavar="PATH",
        help="Path to BQF policy configuration file (YAML/TOML)",
    )

    # WS-C1: Remote context and engine detection
    media_p.add_argument(
        "--engine",
        choices=["renpy", "unity", "godot", "generic"],
        help="Override engine detection (WS-C1)",
    )
    media_p.add_argument(
        "--remote-debug",
        dest="remote_debug",
        action="store_true",
        help="Display remote environment and engine context (WS-C1)",
    )
