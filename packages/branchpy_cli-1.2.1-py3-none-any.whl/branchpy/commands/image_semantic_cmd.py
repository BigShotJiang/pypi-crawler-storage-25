"""
CLI Command: branchpy semantic

Semantic analysis and auto-tagging for images
"""

import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def add_parser(subparsers):
    """Add 'semantic' subcommand to CLI parser"""
    parser = subparsers.add_parser(
        "semantic", help="Semantic analysis and auto-tagging for images"
    )

    parser.add_argument(
        "--project-dir",
        type=str,
        default=".",
        help="Project directory (default: current directory)",
    )

    parser.add_argument(
        "--backend",
        type=str,
        choices=["clip"],
        default="clip",
        help="Backend (CLIP required for semantic understanding)",
    )

    parser.add_argument(
        "--similarity-threshold",
        type=float,
        default=0.75,
        help="Similarity threshold for auto-linking (0-1, default: 0.75)",
    )

    parser.add_argument(
        "--min-cluster-size",
        type=int,
        default=3,
        help="Minimum images to form cluster (default: 3)",
    )

    parser.add_argument(
        "--confidence-threshold",
        type=float,
        default=0.5,
        help="Minimum confidence to display (0-1, default: 0.5)",
    )

    parser.add_argument(
        "--output",
        type=str,
        help="Output report path (default: .branchpy/reports/semantic_audit.html)",
    )

    parser.add_argument(
        "--format",
        type=str,
        choices=["html", "json"],
        default="html",
        help="Output format (default: html)",
    )

    parser.add_argument(
        "--no-cache", action="store_true", help="Disable feature caching"
    )


def run(args):
    """Execute semantic analysis"""
    project_dir = Path(args.project_dir).resolve()

    if not project_dir.exists():
        print(f"\u274c Error: Project directory not found: {project_dir}")
        return 1

    # Check CLIP availability upfront with a clear, actionable message
    try:
        import clip  # noqa: F401
    except ImportError:
        print("\n[image-semantic] CLIP is not installed.")
        print()
        print("This command uses a local CLIP model for semantic image similarity.")
        print("It is an optional advanced feature — standard image validation works without it.")
        print()
        print("To enable it, install CLIP and its dependencies:")
        print("  pip install torch torchvision")
        print("  pip install git+https://github.com/openai/CLIP.git")
        print()
        print("For standard image validation (no extra install required):")
        print("  branchpy media --project <path>")
        print("  branchpy image-validate --project <path>")
        return 1

    # Check backend
    if args.backend != "clip":
        print("\u274c Error: Semantic analysis requires CLIP backend")
        return 1

    # Import internal modules (CLIP is confirmed available at this point)
    try:
        from branchpy.analysis.image_validation.backends.clip_backend import CLIPBackend
        from branchpy.analysis.image_validation.scanner import ImageScanner
        from branchpy.analysis.image_validation.semantic import SemanticLinker
    except ImportError as e:
        print(f"\u274c Error: Failed to import required modules: {e}")
        print("  pip install torch torchvision")
        print("  pip install git+https://github.com/openai/CLIP.git")
        return 1

    # Default output path
    if args.output:
        output_path = Path(args.output)
    else:
        ext = "html" if args.format == "html" else "json"
        output_path = project_dir / ".branchpy" / "reports" / f"semantic_audit.{ext}"

    try:
        print("[Semantic] Starting semantic analysis...")
        print(f"  Project: {project_dir}")
        print(f"  Backend: {args.backend}")
        print(f"  Similarity threshold: {args.similarity_threshold}")

        # Initialize CLIP backend
        print("\n[1/4] Loading CLIP model...")
        backend = CLIPBackend()

        # Scan images
        print("\n[2/4] Scanning images...")
        scanner = ImageScanner(project_dir)
        images = scanner.scan()

        if not images:
            print("No images found in game/images directory")
            return 0

        print(f"  Found {len(images)} images")

        # Extract embeddings
        print("\n[3/4] Extracting CLIP embeddings...")
        embeddings = {}

        for idx, img in enumerate(images, 1):
            if idx % 20 == 0:
                print(f"  Processed {idx}/{len(images)} images...")

            embedding = backend.extract_features(img.abs_path)
            embeddings[str(img.abs_path)] = embedding

        # Build semantic graph
        print("\n[4/4] Building semantic graph...")
        linker = SemanticLinker(
            backend=backend,
            similarity_threshold=args.similarity_threshold,
            min_cluster_size=args.min_cluster_size,
        )

        image_paths = [img.abs_path for img in images]
        graph = linker.build_graph(image_paths, embeddings)

        # Filter by confidence
        filtered_nodes = {
            node_id: node
            for node_id, node in graph.nodes.items()
            if node.confidence >= args.confidence_threshold
        }

        print(f"\n  Total nodes: {len(graph.nodes)}")
        print(f"  High-confidence nodes: {len(filtered_nodes)}")

        # Export report
        if args.format == "json":
            _export_json(graph, output_path, args.confidence_threshold)
        else:
            _export_html(graph, output_path, args.confidence_threshold)

        # Print summary
        print("\n" + "=" * 60)
        print("SEMANTIC ANALYSIS SUMMARY")
        print("=" * 60)

        stats = graph.stats()
        print(f"Total images:     {stats['total_images']}")
        print(f"Total nodes:      {stats['total_nodes']}")

        for node_type, type_stats in stats.get("by_type", {}).items():
            print(
                f"  {node_type.capitalize():12s}: {type_stats['count']} nodes, {type_stats['images']} images"
            )

        print("=" * 60)
        print(f"\n📄 Report: {output_path}")

        return 0

    except Exception as e:
        print(f"\n❌ Semantic analysis failed: {e}")
        import traceback

        traceback.print_exc()
        return 1


def _export_json(graph, output_path: Path, confidence_threshold: float):
    """Export semantic graph to JSON"""
    import json

    data = {
        "stats": graph.stats(),
        "nodes": [
            node.to_dict()
            for node in graph.nodes.values()
            if node.confidence >= confidence_threshold
        ],
    }

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    print(f"\n📄 JSON report saved to: {output_path}")


def _export_html(graph, output_path: Path, confidence_threshold: float):
    """Export semantic graph to HTML with thumbnail grid"""

    # Generate HTML
    html = _generate_html_report(graph, confidence_threshold)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"\n📄 HTML report saved to: {output_path}")


def _generate_html_report(graph, confidence_threshold: float) -> str:
    """Generate HTML report with semantic nodes"""
    from branchpy.analysis.image_validation.semantic.nodes import NodeType

    # Filter nodes by confidence
    nodes_by_type = {node_type: [] for node_type in NodeType}

    for node in graph.nodes.values():
        if node.confidence >= confidence_threshold:
            nodes_by_type[node.node_type].append(node)

    # Sort by member count (largest first)
    for node_list in nodes_by_type.values():
        node_list.sort(key=lambda n: len(n.members), reverse=True)

    stats = graph.stats()

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Semantic Analysis Report - BranchPy</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif; background: #f5f5f5; padding: 20px; }}
        .container {{ max-width: 1400px; margin: 0 auto; }}
        h1 {{ color: #2c3e50; margin-bottom: 10px; }}
        .stats {{ background: white; padding: 20px; border-radius: 8px; margin-bottom: 30px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
        .stats-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-top: 15px; }}
        .stat-card {{ text-align: center; }}
        .stat-value {{ font-size: 32px; font-weight: bold; color: #3498db; }}
        .stat-label {{ color: #7f8c8d; font-size: 14px; margin-top: 5px; }}
        .section {{ background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
        .section-title {{ font-size: 20px; color: #2c3e50; margin-bottom: 15px; border-bottom: 2px solid #3498db; padding-bottom: 10px; }}
        .node-grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 15px; }}
        .node-card {{ border: 1px solid #e0e0e0; border-radius: 6px; padding: 15px; background: #fafafa; }}
        .node-header {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }}
        .node-name {{ font-weight: bold; color: #2c3e50; }}
        .node-confidence {{ background: #3498db; color: white; padding: 2px 8px; border-radius: 12px; font-size: 12px; }}
        .node-confidence.medium {{ background: #f39c12; }}
        .node-confidence.low {{ background: #95a5a6; }}
        .node-meta {{ color: #7f8c8d; font-size: 13px; margin-bottom: 10px; }}
        .image-list {{ max-height: 100px; overflow-y: auto; font-size: 12px; color: #555; }}
        .image-list li {{ margin-bottom: 3px; }}
        .empty-state {{ text-align: center; color: #95a5a6; padding: 40px; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🎨 Semantic Analysis Report</h1>
        <p style="color: #7f8c8d; margin-bottom: 20px;">Auto-tagged characters, scenes, locations, and objects</p>
        
        <div class="stats">
            <h2 style="margin-bottom: 15px;">Summary</h2>
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-value">{stats['total_images']}</div>
                    <div class="stat-label">Total Images</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">{stats['total_nodes']}</div>
                    <div class="stat-label">Semantic Nodes</div>
                </div>
"""

    # Add type-specific stats
    for node_type in NodeType:
        if node_type.value in stats.get("by_type", {}):
            type_stats = stats["by_type"][node_type.value]
            html += f"""
                <div class="stat-card">
                    <div class="stat-value">{type_stats['count']}</div>
                    <div class="stat-label">{node_type.value.capitalize()}s</div>
                </div>
"""

    html += """
            </div>
        </div>
"""

    # Add sections for each node type
    for node_type in [
        NodeType.CHARACTER,
        NodeType.SCENE,
        NodeType.LOCATION,
        NodeType.OBJECT,
        NodeType.UNKNOWN,
    ]:
        nodes = nodes_by_type[node_type]

        if not nodes:
            continue

        html += f"""
        <div class="section">
            <div class="section-title">{node_type.value.capitalize()}s ({len(nodes)})</div>
            <div class="node-grid">
"""

        for node in nodes:
            confidence_class = (
                "high"
                if node.confidence >= 0.8
                else "medium" if node.confidence >= 0.6 else "low"
            )
            confidence_pct = int(node.confidence * 100)

            html += f"""
                <div class="node-card">
                    <div class="node-header">
                        <span class="node-name">{node.display_name}</span>
                        <span class="node-confidence {confidence_class}">{confidence_pct}%</span>
                    </div>
                    <div class="node-meta">{len(node.members)} image{'s' if len(node.members) != 1 else ''}</div>
                    <ul class="image-list">
"""

            for member in node.members[:10]:  # Show first 10
                from pathlib import Path

                filename = Path(member).name
                html += f"                        <li>{filename}</li>\n"

            if len(node.members) > 10:
                html += f"                        <li><em>... and {len(node.members) - 10} more</em></li>\n"

            html += """
                    </ul>
                </div>
"""

        html += """
            </div>
        </div>
"""

    html += """
    </div>
</body>
</html>
"""

    return html
