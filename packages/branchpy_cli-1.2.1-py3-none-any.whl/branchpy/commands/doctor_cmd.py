"""
Enhanced BranchPy Doctor - Comprehensive diagnostics and auto-repair
Supports selective checks, JSON output, and automated repairs.
Saves reports to .branchpy/doctor/ directory.
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from branchpy.config_store import ConfigStore
from branchpy.core.paths import BASE, CACHE, CONFIG, LOGS
from branchpy.core.paths_v2 import (
    get_base_dir,
    get_cache_dir,
    get_config_dir,
    get_logs_dir,
    get_temp_dir,
)

# License gating (v1.0.0)
from branchpy.license.gating import require_feature_cli
from branchpy.patch_store import ensure_project_registered, get_project_patches_dir

# Optional dependencies
try:
    import psutil  # type: ignore[import]
except ImportError:
    psutil = None


class DoctorResult:
    """Container for doctor check results."""

    def __init__(self):
        self.timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        self.checks: List[Dict[str, Any]] = []
        self.repairs: List[Dict[str, Any]] = []
        self.summary = {
            "totalChecks": 0,
            "passed": 0,
            "warnings": 0,
            "failed": 0,
            "repairsRun": 0,
            "repairsSucceeded": 0,
        }

    def add_check(
        self, check_id: str, name: str, status: str, message: str, details: str = ""
    ):
        """Add a check result."""
        self.checks.append(
            {
                "id": check_id,
                "name": name,
                "status": status,  # 'pass', 'warn', 'fail'
                "message": message,
                "details": details,
            }
        )
        self.summary["totalChecks"] += 1
        if status == "pass":
            self.summary["passed"] += 1
        elif status == "warn":
            self.summary["warnings"] += 1
        elif status == "fail":
            self.summary["failed"] += 1

    def add_repair(self, repair_id: str, name: str, status: str, message: str):
        """Add a repair result."""
        self.repairs.append(
            {
                "id": repair_id,
                "name": name,
                "status": status,  # 'success', 'failed', 'skipped'
                "message": message,
            }
        )
        self.summary["repairsRun"] += 1
        if status == "success":
            self.summary["repairsSucceeded"] += 1

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {
            "timestamp": self.timestamp,
            "checks": self.checks,
            "repairs": self.repairs,
            "summary": self.summary,
        }

        # Add omega metadata if present (Track 2: Doctor ↔ Omega Coupling)
        if hasattr(self, "omega"):
            result["omega"] = self.omega

        return result


# ============================================================================
# Helper Functions
# ============================================================================


def _can_display_unicode() -> bool:
    """Check if the terminal can display Unicode/emoji safely."""
    try:
        if os.environ.get("PYTHONUTF8") == "1":
            return True
        if os.environ.get("LC_ALL", "").lower().endswith("utf-8"):
            return True
        if os.environ.get("LANG", "").lower().endswith("utf-8"):
            return True

        if platform.system() == "Windows":
            try:
                test_emoji = "🩺"
                test_emoji.encode(sys.stdout.encoding or "utf-8")
                return True
            except (UnicodeEncodeError, LookupError):
                return False

        return True
    except Exception:
        return False


def _get_emoji_or_fallback(emoji: str, fallback: str) -> str:
    """Get emoji if Unicode is supported, otherwise return fallback."""
    return emoji if _can_display_unicode() else fallback


def _ok(b: bool) -> str:
    """Return OK or FAIL message with safe encoding."""
    return (
        "✓ OK"
        if b
        else "✗ FAIL" if _can_display_unicode() else ("[OK]" if b else "[FAIL]")
    )


def _warn(b: bool) -> str:
    """Return WARN or OK message with safe encoding."""
    return (
        "⚠ WARN"
        if not b
        else "✓ OK" if _can_display_unicode() else ("[WARN]" if not b else "[OK]")
    )


# ============================================================================
# Check Functions
# ============================================================================


def check_python_version(result: DoctorResult) -> bool:
    """Check Python version (>=3.11 required)."""
    version_info = sys.version_info
    python_ok = (version_info.major, version_info.minor) >= (3, 11)
    version_str = f"{version_info.major}.{version_info.minor}.{version_info.micro}"

    result.add_check(
        "python-version",
        "Python Version",
        "pass" if python_ok else "fail",
        version_str,
        "Python 3.11+ required" if not python_ok else "",
    )
    return python_ok


def check_python_modules(result: DoctorResult) -> bool:
    """Check essential Python modules are available."""
    essential_modules = ["json", "pathlib", "subprocess", "argparse", "tomllib"]
    optional_modules = ["appdirs", "psutil"]

    all_ok = True
    missing = []

    for module in essential_modules:
        try:
            __import__(module)
        except ImportError:
            missing.append(module)
            all_ok = False

    status = "pass" if all_ok else "fail"
    message = (
        "All essential modules available"
        if all_ok
        else f'Missing: {", ".join(missing)}'
    )

    result.add_check("python-modules", "Python Modules", status, message)

    # Check optional modules (warnings only)
    for module in optional_modules:
        try:
            __import__(module)
        except ImportError:
            result.add_check(
                f"python-module-{module}",
                f"Optional: {module}",
                "warn",
                "Not installed (recommended)",
            )

    return all_ok


def check_system_info(result: DoctorResult) -> bool:
    """Check system and platform info."""
    # Platform info
    result.add_check(
        "system-platform",
        "Platform",
        "pass",
        f"{platform.system()} {platform.release()} ({platform.machine()})",
    )

    # Disk space
    try:
        if BASE.exists():
            stat = shutil.disk_usage(BASE)
            free_gb = stat.free / (1024**3)
            space_ok = free_gb > 1.0  # At least 1GB free

            result.add_check(
                "system-disk-space",
                "Disk Space",
                "pass" if space_ok else "warn",
                f"{free_gb:.1f}GB free",
                "Less than 1GB free" if not space_ok else "",
            )
        else:
            result.add_check(
                "system-disk-space",
                "Disk Space",
                "warn",
                "BranchPy data dir not accessible",
            )
    except Exception as e:
        result.add_check("system-disk-space", "Disk Space", "fail", f"Error: {e}")
        return False

    # Memory check (optional)
    if psutil is not None:
        try:
            mem = psutil.virtual_memory()
            mem_ok = mem.available / (1024**3) > 0.5  # At least 512MB available
            result.add_check(
                "system-memory",
                "Available Memory",
                "pass" if mem_ok else "warn",
                f"{mem.available / (1024**3):.1f}GB available",
            )
        except Exception as e:
            result.add_check("system-memory", "Available Memory", "warn", f"Error: {e}")

    return True


def check_branchpy_dirs(result: DoctorResult) -> bool:
    """Verify data, logs, cache, and config directories."""
    dirs_to_check = [
        ("branchpy-dir-config", "Config Directory", CONFIG.parent),
        ("branchpy-dir-cache", "Cache Directory", CACHE),
        ("branchpy-dir-logs", "Logs Directory", LOGS),
        ("branchpy-dir-base", "Base Directory", BASE),
    ]

    all_ok = True

    for check_id, name, path in dirs_to_check:
        if path.exists():
            readable = os.access(path, os.R_OK)
            writable = os.access(path, os.W_OK)

            if readable and writable:
                result.add_check(
                    check_id, name, "pass", "Exists with read/write access"
                )
            else:
                perm_str = f"r={'OK' if readable else 'FAIL'}, w={'OK' if writable else 'FAIL'}"
                result.add_check(
                    check_id, name, "warn", f"Permissions issue: {perm_str}"
                )
                all_ok = False
        else:
            result.add_check(check_id, name, "warn", "Missing (can be created)")
            all_ok = False

    return all_ok


def check_storage_layout(result: DoctorResult) -> bool:
    """
    Report v1.0.0 storage layout (OS-standard paths).

    This check displays the resolved paths for the new storage architecture
    to help users understand where BranchPy stores data and to assist with
    debugging.
    """
    # Get all resolved paths
    base_dir = get_base_dir()
    cache_dir = get_cache_dir()
    logs_dir = get_logs_dir()
    temp_dir = get_temp_dir()
    config_dir = get_config_dir()

    # Report each path (informational only, all "pass" status)
    result.add_check(
        "storage-base",
        "Global Base Directory",
        "pass",
        str(base_dir),
        f"Platform: {platform.system()}",
    )

    result.add_check(
        "storage-cache",
        "Global Cache Directory",
        "pass",
        str(cache_dir),
        "Ephemeral cache (safe to delete)",
    )

    # Show AI cache specifically
    ai_cache_dir = cache_dir / "ai"
    result.add_check(
        "storage-ai-cache",
        "AI Cache Directory",
        "pass",
        str(ai_cache_dir),
        "Per-project AI cache (responses, embeddings)",
    )

    result.add_check(
        "storage-logs",
        "Global Logs Directory",
        "pass",
        str(logs_dir),
        "Persistent logs for all projects",
    )

    result.add_check(
        "storage-temp",
        "Temporary Directory",
        "pass",
        str(temp_dir),
        "System temp location",
    )

    result.add_check(
        "storage-config",
        "Configuration Directory",
        "pass",
        str(config_dir),
        "User settings and config",
    )

    # Optionally warn about legacy directories
    legacy_warnings = []

    # Check for old .branchpy/wsd in home directory
    legacy_wsd = Path.home() / ".branchpy" / "wsd"
    if legacy_wsd.exists():
        legacy_warnings.append(str(legacy_wsd))

    if legacy_warnings:
        result.add_check(
            "storage-legacy",
            "Legacy Directories Detected",
            "warn",
            f"Found {len(legacy_warnings)} old directory(ies)",
            f"Run 'branchpy migrate-storage' to clean up: {', '.join(legacy_warnings)}",
        )

    return True


def check_config_integrity(result: DoctorResult) -> bool:
    """Validate .branchpy.toml and config store."""
    try:
        cfg = ConfigStore()
        result.add_check(
            "config-integrity", "Config Store", "pass", "Loads successfully"
        )

        # Check projects registry
        projects = cfg.cfg.projects
        if projects:
            valid_projects = sum(1 for path in projects.values() if Path(path).exists())

            if valid_projects == len(projects):
                result.add_check(
                    "config-projects",
                    "Project Registry",
                    "pass",
                    f"{len(projects)} project(s), all valid",
                )
            else:
                result.add_check(
                    "config-projects",
                    "Project Registry",
                    "warn",
                    f"{valid_projects}/{len(projects)} projects valid",
                )
        else:
            result.add_check(
                "config-projects",
                "Project Registry",
                "pass",
                "Empty (normal for new installation)",
            )

        # Check default project
        default = cfg.cfg.default_project
        if default:
            if default in projects and Path(projects[default]).exists():
                result.add_check(
                    "config-default", "Default Project", "pass", f"'{default}' exists"
                )
            else:
                result.add_check(
                    "config-default",
                    "Default Project",
                    "warn",
                    f"'{default}' invalid/missing",
                )

        return True

    except Exception as e:
        result.add_check("config-integrity", "Config Store", "fail", f"Error: {e}")
        return False


def check_git_availability(result: DoctorResult) -> bool:
    """Check Git installation and availability."""
    git = shutil.which("git")

    if not git:
        result.add_check(
            "git-availability",
            "Git Integration",
            "warn",
            "Git not found in PATH",
            "Install Git from https://git-scm.com/downloads for patch features",
        )
        return False

    try:
        cp = subprocess.run(
            [git, "--version"], capture_output=True, text=True, check=True
        )
        version = cp.stdout.strip()
        result.add_check("git-availability", "Git Integration", "pass", f"{version}")
        return True
    except Exception:
        result.add_check(
            "git-availability",
            "Git Integration",
            "warn",
            f"Found at {git} but version check failed",
        )
        return False


def check_git_status(result: DoctorResult, project_root: Optional[Path] = None) -> bool:
    """Check for uncommitted changes in git repository."""
    if not project_root:
        result.add_check(
            "git-status", "Git Repository Status", "pass", "No project specified"
        )
        return True

    git = shutil.which("git")
    if not git:
        return True  # Already reported in git-availability check

    try:
        cp = subprocess.run(
            [git, "status", "--porcelain"],
            cwd=str(project_root),
            capture_output=True,
            text=True,
        )

        if cp.returncode == 0:
            if not cp.stdout.strip():
                result.add_check(
                    "git-status",
                    "Git Repository Status",
                    "pass",
                    "Clean (safe for patches)",
                )
            else:
                result.add_check(
                    "git-status",
                    "Git Repository Status",
                    "warn",
                    "Uncommitted changes detected",
                    "Consider committing changes before applying patches",
                )
        else:
            result.add_check(
                "git-status", "Git Repository Status", "warn", "Not a git repository"
            )
    except Exception as e:
        result.add_check(
            "git-status", "Git Repository Status", "warn", f"Could not check: {e}"
        )

    return True


def check_project_structure(
    result: DoctorResult, project_root: Optional[Path] = None
) -> bool:
    """Verify project directories and files."""
    if not project_root:
        result.add_check(
            "project-structure", "Project Structure", "pass", "No project specified"
        )
        return True

    # Check for common Ren'Py files
    renpy_indicators = [
        project_root / "game" / "script.rpy",
        project_root / "game" / "options.rpy",
        project_root / "script.rpy",
        project_root / "options.rpy",
    ]

    has_renpy = any(f.exists() for f in renpy_indicators)

    if has_renpy:
        result.add_check(
            "project-structure", "Project Structure", "pass", "Ren'Py project detected"
        )
    else:
        result.add_check(
            "project-structure",
            "Project Structure",
            "warn",
            "No Ren'Py indicators found",
            "This may not be a Ren'Py project",
        )

    return True


def check_patch_directory(
    result: DoctorResult, project_name: Optional[str] = None
) -> bool:
    """Check patch storage directory and permissions."""
    if not project_name:
        result.add_check(
            "patch-directory", "Patch Directory", "pass", "No project specified"
        )
        return True

    try:
        pdir = get_project_patches_dir(project_name)

        if pdir.exists():
            if os.access(pdir, os.W_OK):
                result.add_check(
                    "patch-directory",
                    "Patch Directory",
                    "pass",
                    f"Accessible at {pdir}",
                )
            else:
                result.add_check(
                    "patch-directory",
                    "Patch Directory",
                    "warn",
                    f"Not writable: {pdir}",
                )
                return False
        else:
            result.add_check(
                "patch-directory",
                "Patch Directory",
                "warn",
                f"Missing: {pdir} (can be created)",
            )
            return False

        return True
    except Exception as e:
        result.add_check("patch-directory", "Patch Directory", "fail", f"Error: {e}")
        return False


def check_patch_state(result: DoctorResult, project_name: Optional[str] = None) -> bool:
    """Validate patch state file integrity."""
    if not project_name:
        result.add_check(
            "patch-state", "Patch State JSON", "pass", "No project specified"
        )
        return True

    try:
        from branchpy.patch_state import _state_path

        pdir = get_project_patches_dir(project_name)
        state_path = _state_path(pdir)

        if state_path.exists():
            try:
                with open(state_path, "r", encoding="utf-8") as f:
                    json.load(f)
                result.add_check(
                    "patch-state", "Patch State JSON", "pass", "Valid JSON"
                )
            except Exception as e:
                result.add_check(
                    "patch-state", "Patch State JSON", "warn", f"Invalid JSON: {e}"
                )
                return False
        else:
            result.add_check(
                "patch-state",
                "Patch State JSON",
                "pass",
                "Not present (will be created as needed)",
            )

        return True
    except Exception as e:
        result.add_check("patch-state", "Patch State JSON", "fail", f"Error: {e}")
        return False


def check_renpy_sdk_project(
    result: DoctorResult, project_root: Optional[Path] = None
) -> bool:
    """Check project-specific Ren'Py SDK configuration."""
    if not project_root:
        result.add_check(
            "renpy-sdk-project", "Project Ren'Py SDK", "pass", "No project specified"
        )
        return True

    try:
        from branchpy.project_config import load_project_config
        from branchpy.renpy_sdk import RenpySdkManager

        config = load_project_config(str(project_root))
        manager = RenpySdkManager()

        if config.renpy_project_pin:
            sdk = manager.get_sdk(config.renpy_project_pin)
            if sdk and sdk.valid:
                result.add_check(
                    "renpy-sdk-project",
                    "Project Ren'Py SDK",
                    "pass",
                    f"{config.renpy_project_pin} ({sdk.version or 'unknown'})",
                )
            else:
                result.add_check(
                    "renpy-sdk-project",
                    "Project Ren'Py SDK",
                    "warn",
                    f"{config.renpy_project_pin} (invalid or missing)",
                )
                return False
        else:
            # Check if this appears to be a Ren'Py project
            renpy_files = [
                project_root / "game" / "options.rpy",
                project_root / "game" / "script.rpy",
            ]

            if any(f.exists() for f in renpy_files):
                result.add_check(
                    "renpy-sdk-project",
                    "Project Ren'Py SDK",
                    "warn",
                    "Ren'Py project detected but no SDK configured",
                )
                return False
            else:
                result.add_check(
                    "renpy-sdk-project",
                    "Project Ren'Py SDK",
                    "pass",
                    "Not a Ren'Py project (no SDK needed)",
                )

        return True
    except Exception as e:
        result.add_check(
            "renpy-sdk-project", "Project Ren'Py SDK", "warn", f"Check failed: {e}"
        )
        return False


def check_renpy_sdk_global(result: DoctorResult) -> bool:
    """Verify global Ren'Py SDK installations."""
    try:
        from branchpy.renpy_sdk import RenpySdkManager

        manager = RenpySdkManager()
        sdks = manager.list_sdks()

        if not sdks:
            result.add_check(
                "renpy-sdk-global",
                "Global Ren'Py SDK Registry",
                "warn",
                "No SDKs registered",
                "Run 'branchpy renpy detect' to auto-detect SDKs",
            )
            return False

        valid_count = sum(1 for sdk in sdks.values() if sdk.valid)

        if valid_count == len(sdks):
            result.add_check(
                "renpy-sdk-global",
                "Global Ren'Py SDK Registry",
                "pass",
                f"{len(sdks)} SDK(s) registered, all valid",
            )
        else:
            result.add_check(
                "renpy-sdk-global",
                "Global Ren'Py SDK Registry",
                "warn",
                f"{valid_count}/{len(sdks)} SDKs valid",
            )

        return True
    except Exception as e:
        result.add_check(
            "renpy-sdk-global",
            "Global Ren'Py SDK Registry",
            "warn",
            f"Check failed: {e}",
        )
        return False


def check_cache_integrity(result: DoctorResult, ci_mode: bool = False) -> bool:
    """Check for corrupted or stale cache files."""
    try:
        if not CACHE.exists():
            result.add_check(
                "cache-integrity",
                "Cache Integrity",
                "pass",
                "No cache directory (normal)",
            )
            return True

        # Check cache files
        cache_files = list(CACHE.glob("**/*.cache")) + list(CACHE.glob("**/*.pkl"))
        corrupted = []

        for cache_file in cache_files:
            try:
                # Try to read the file
                with open(cache_file, "rb") as f:
                    f.read(1024)  # Read first 1KB to check if accessible
            except Exception:
                corrupted.append(cache_file.name)

        if corrupted:
            result.add_check(
                "cache-integrity",
                "Cache Integrity",
                "warn",
                f"{len(corrupted)} corrupted cache file(s) found",
                f'Files: {", ".join(corrupted[:3])}',
            )
            return False
        elif len(cache_files) == 0:
            # Task 3: In CI mode, 0 cache files = WARN (no evidence to validate)
            status = "warn" if ci_mode else "pass"
            message = (
                "No cache files found" if ci_mode else "0 cache file(s) (clean state)"
            )
            result.add_check(
                "cache-integrity",
                "Cache Integrity",
                status,
                message,
            )
            return True  # Not a hard failure; exit code comes from status field (warn/pass)
        else:
            result.add_check(
                "cache-integrity",
                "Cache Integrity",
                "pass",
                f"{len(cache_files)} cache file(s), all valid",
            )

        return True
    except Exception as e:
        result.add_check("cache-integrity", "Cache Integrity", "warn", f"Error: {e}")
        return False


def check_reports_validity(
    result: DoctorResult, project_root: Optional[Path] = None
) -> bool:
    """Verify analyze/stats reports are valid JSON."""
    if not project_root:
        result.add_check(
            "reports-validity", "Reports Validity", "pass", "No project specified"
        )
        return True

    try:
        reports_dir = project_root / ".branchpy"

        if not reports_dir.exists():
            result.add_check(
                "reports-validity",
                "Reports Validity",
                "pass",
                "No reports directory (normal for new project)",
            )
            return True

        # Check for report directories
        report_types = ["analyze", "stats", "tests", "media"]
        invalid_reports = []
        total_reports = 0

        for report_type in report_types:
            type_dir = reports_dir / report_type
            if type_dir.exists():
                json_files = list(type_dir.glob("*.json"))
                total_reports += len(json_files)

                for json_file in json_files:
                    try:
                        with open(json_file, "r", encoding="utf-8") as f:
                            json.load(f)
                    except Exception:
                        invalid_reports.append(f"{report_type}/{json_file.name}")

        # (M-04) Legacy fallback: during transition from .branchpy/reports/ to
        # .branchpy/analyze/, also scan the old location so existing snapshots
        # are counted. Remove this block once the transition window closes.
        legacy_analyze_dir = reports_dir / "reports"
        if legacy_analyze_dir.exists():
            legacy_json_files = [
                f
                for f in legacy_analyze_dir.glob("analyze-*.json")
                if not (reports_dir / "analyze" / f.name).exists()
            ]
            for json_file in legacy_json_files:
                total_reports += 1
                try:
                    with open(json_file, "r", encoding="utf-8") as f:
                        json.load(f)
                except Exception:
                    invalid_reports.append(f"reports/{json_file.name}")

        if invalid_reports:
            result.add_check(
                "reports-validity",
                "Reports Validity",
                "warn",
                f"{len(invalid_reports)} invalid report(s) out of {total_reports}",
                f'Invalid: {", ".join(invalid_reports[:3])}',
            )
            return False
        elif total_reports > 0:
            result.add_check(
                "reports-validity",
                "Reports Validity",
                "pass",
                f"{total_reports} report(s), all valid",
            )
        else:
            result.add_check(
                "reports-validity",
                "Reports Validity",
                "pass",
                "No reports found (normal for new project)",
            )

        return True
    except Exception as e:
        result.add_check("reports-validity", "Reports Validity", "warn", f"Error: {e}")
        return False


def check_media_phase_c(
    result: DoctorResult, project_root: Optional[Path] = None
) -> bool:
    """Check media integrity using Phase C adapter (missing assets, coverage)."""
    if not project_root:
        result.add_check(
            "media-phase-c",
            "Media Intelligence (Phase C)",
            "pass",
            "No project specified",
        )
        return True

    try:
        # Import Phase C adapter
        from branchpy.analyze.media_adapters import get_phase_c_adapter

        # Detect engine and get adapter
        adapter = get_phase_c_adapter("renpy", str(project_root))

        if not adapter:
            result.add_check(
                "media-phase-c",
                "Media Intelligence (Phase C)",
                "warn",
                "No Phase C adapter available for this project",
            )
            return False

        # Run Phase C collection
        phase_c_result = adapter.collect_phase_c(project_root)

        # Calculate metrics
        total_tags = len(phase_c_result.files)
        missing_count = sum(1 for tag in phase_c_result.files if tag.exists is False)
        resolved_count = sum(1 for tag in phase_c_result.files if tag.resolved_files)
        orphaned_count = sum(1 for tag in phase_c_result.files if not tag.used_by)

        # Calculate coverage percentage
        coverage_pct = (resolved_count / total_tags * 100) if total_tags > 0 else 100.0

        # Determine status
        if missing_count > 0:
            status = "warn"
            message = f"{missing_count} missing asset(s) found"
            details = f"Total tags: {total_tags}, Resolved: {resolved_count}, Missing: {missing_count}, Coverage: {coverage_pct:.1f}%"
        elif orphaned_count > 0:
            status = "warn"
            message = f"{orphaned_count} orphaned tag(s) found (defined but never used)"
            details = f"Total tags: {total_tags}, Resolved: {resolved_count}, Orphaned: {orphaned_count}"
        else:
            status = "pass"
            message = f"All {total_tags} media tag(s) resolved successfully"
            details = f"Coverage: {coverage_pct:.1f}%, No missing assets"

        result.add_check(
            "media-phase-c", "Media Intelligence (Phase C)", status, message, details
        )
        return status == "pass"

    except Exception as e:
        result.add_check(
            "media-phase-c", "Media Intelligence (Phase C)", "fail", f"Error: {e}"
        )
        return False


def check_media_coverage(
    result: DoctorResult, project_root: Optional[Path] = None
) -> bool:
    """Check media asset coverage (% of tags with resolved files)."""
    if not project_root:
        result.add_check(
            "media-coverage", "Media Coverage", "pass", "No project specified"
        )
        return True

    try:
        from branchpy.analyze.media_adapters import get_phase_c_adapter

        adapter = get_phase_c_adapter("renpy", str(project_root))
        if not adapter:
            result.add_check(
                "media-coverage",
                "Media Coverage",
                "warn",
                "Phase C adapter not available",
            )
            return False

        phase_c_result = adapter.collect_phase_c(project_root)

        total_tags = len(phase_c_result.files)
        if total_tags == 0:
            result.add_check(
                "media-coverage",
                "Media Coverage",
                "pass",
                "No media tags found (normal for new project)",
            )
            return True

        resolved_count = sum(
            1 for tag in phase_c_result.files if tag.resolved_files and tag.exists
        )
        coverage_pct = resolved_count / total_tags * 100

        # Coverage thresholds
        if coverage_pct >= 95:
            status = "pass"
            message = f"{coverage_pct:.1f}% coverage (excellent)"
        elif coverage_pct >= 80:
            status = "warn"
            message = f"{coverage_pct:.1f}% coverage (good, but {total_tags - resolved_count} tag(s) unresolved)"
        else:
            status = "warn"
            message = f"{coverage_pct:.1f}% coverage (low, {total_tags - resolved_count} tag(s) unresolved)"

        result.add_check("media-coverage", "Media Coverage", status, message)
        return status == "pass"

    except Exception as e:
        result.add_check("media-coverage", "Media Coverage", "fail", f"Error: {e}")
        return False


def check_media_integrity(
    result: DoctorResult, project_root: Optional[Path] = None
) -> bool:
    """Check for missing media files and broken references."""
    if not project_root:
        result.add_check(
            "media-integrity", "Media Integrity", "pass", "No project specified"
        )
        return True

    try:
        from branchpy.analyze.media_adapters import get_phase_c_adapter

        adapter = get_phase_c_adapter("renpy", str(project_root))
        if not adapter:
            result.add_check(
                "media-integrity",
                "Media Integrity",
                "warn",
                "Phase C adapter not available",
            )
            return False

        phase_c_result = adapter.collect_phase_c(project_root)

        # Find broken references (tags where exists=False)
        broken_refs = [tag for tag in phase_c_result.files if tag.exists is False]

        if not broken_refs:
            result.add_check(
                "media-integrity",
                "Media Integrity",
                "pass",
                f"All {len(phase_c_result.files)} media reference(s) valid",
            )
            return True
        else:
            # Group by kind for better reporting
            broken_by_kind = {}
            for tag in broken_refs:
                kind = tag.kind
                if kind not in broken_by_kind:
                    broken_by_kind[kind] = []
                broken_by_kind[kind].append(tag.tag)

            summary = ", ".join(
                [f"{len(tags)} {kind}" for kind, tags in broken_by_kind.items()]
            )

            result.add_check(
                "media-integrity",
                "Media Integrity",
                "fail",
                f"{len(broken_refs)} broken reference(s) found: {summary}",
                f'Missing tags: {", ".join([t.tag for t in broken_refs[:5]])}{"..." if len(broken_refs) > 5 else ""}',
            )
            return False

    except Exception as e:
        result.add_check("media-integrity", "Media Integrity", "fail", f"Error: {e}")
        return False


def check_bqf_compliance(
    result: DoctorResult, project_root: Optional[Path] = None
) -> bool:
    """Generate BQF (BranchPy Quality Framework) summary report."""
    if not project_root:
        result.add_check(
            "bqf-compliance", "BQF Compliance", "pass", "No project specified"
        )
        return True

    try:
        # Collect BQF metrics
        bqf_scores = {
            "code_standards": 0,
            "performance": 0,
            "security": 0,
            "cross_platform": 0,
            "engine_agnostic": 0,
            "dependencies": 0,
        }

        # Check media integrity for code standards
        from branchpy.analyze.media_adapters import get_phase_c_adapter

        adapter = get_phase_c_adapter("renpy", str(project_root))

        if adapter:
            phase_c_result = adapter.collect_phase_c(project_root)
            total_tags = len(phase_c_result.files)

            if total_tags > 0:
                # Code Standards: No broken references
                broken_count = sum(
                    1 for tag in phase_c_result.files if tag.exists is False
                )
                bqf_scores["code_standards"] = max(
                    0, 100 - (broken_count / total_tags * 100)
                )

                # Performance: High coverage (resolved_files populated)
                resolved_count = sum(
                    1 for tag in phase_c_result.files if tag.resolved_files
                )
                bqf_scores["performance"] = resolved_count / total_tags * 100

                # Security: No orphaned assets (defined but never used)
                orphaned_count = sum(
                    1 for tag in phase_c_result.files if not tag.used_by
                )
                bqf_scores["security"] = max(
                    0, 100 - (orphaned_count / total_tags * 50)
                )

                # Cross-platform: All paths use forward slashes
                bad_paths = sum(
                    1
                    for tag in phase_c_result.files
                    if tag.resolved_files and any("\\" in f for f in tag.resolved_files)
                )
                bqf_scores["cross_platform"] = max(
                    0, 100 - (bad_paths / total_tags * 100)
                )

                # Engine Agnostic: Uses Phase C contract
                bqf_scores["engine_agnostic"] = (
                    100  # Phase C is engine-agnostic by design
                )

                # Dependencies: stdlib only
                bqf_scores["dependencies"] = 100  # RenpyMediaExtractor uses stdlib only

        # Calculate overall score
        overall_score = sum(bqf_scores.values()) / len(bqf_scores)

        # Determine status
        if overall_score >= 90:
            status = "pass"
            message = f"{overall_score:.1f}% BQF compliance (excellent)"
        elif overall_score >= 70:
            status = "warn"
            message = f"{overall_score:.1f}% BQF compliance (good)"
        else:
            status = "warn"
            message = f"{overall_score:.1f}% BQF compliance (needs improvement)"

        pillar_details = ", ".join([f"{k}: {v:.0f}%" for k, v in bqf_scores.items()])

        result.add_check(
            "bqf-compliance", "BQF Compliance", status, message, pillar_details
        )
        return status == "pass"

    except Exception as e:
        result.add_check("bqf-compliance", "BQF Compliance", "warn", f"Error: {e}")
        return False


# ============================================================================
# Repair Functions
# ============================================================================


def repair_create_missing_dirs(result: DoctorResult) -> bool:
    """Create any missing BranchPy data directories."""
    try:
        dirs_to_create = [CONFIG.parent, CACHE, LOGS, BASE]
        created = []

        for dir_path in dirs_to_create:
            if not dir_path.exists():
                dir_path.mkdir(parents=True, exist_ok=True)
                created.append(str(dir_path))

        if created:
            result.add_repair(
                "create-missing-dirs",
                "Create Missing Directories",
                "success",
                f'Created {len(created)} directory(ies): {", ".join(created)}',
            )
        else:
            result.add_repair(
                "create-missing-dirs",
                "Create Missing Directories",
                "skipped",
                "All directories already exist",
            )

        return True
    except Exception as e:
        result.add_repair(
            "create-missing-dirs", "Create Missing Directories", "failed", f"Error: {e}"
        )
        return False


def repair_fix_config_syntax(result: DoctorResult) -> bool:
    """Repair malformed .branchpy.toml files."""
    try:
        # For now, just ensure a basic config exists
        if not CONFIG.exists():
            CONFIG.parent.mkdir(parents=True, exist_ok=True)

            # Create a minimal valid config
            basic_config = {"projects": {}, "default_project": None}

            with open(CONFIG, "w", encoding="utf-8") as f:
                json.dump(basic_config, f, indent=2)

            result.add_repair(
                "fix-config-syntax",
                "Fix Config Syntax",
                "success",
                "Created default config",
            )
        else:
            result.add_repair(
                "fix-config-syntax",
                "Fix Config Syntax",
                "skipped",
                "Config already exists and is valid",
            )

        return True
    except Exception as e:
        result.add_repair(
            "fix-config-syntax", "Fix Config Syntax", "failed", f"Error: {e}"
        )
        return False


def repair_clear_stale_cache(result: DoctorResult) -> bool:
    """Remove old or corrupted cache files."""
    try:
        if not CACHE.exists():
            result.add_repair(
                "clear-stale-cache",
                "Clear Stale Cache",
                "skipped",
                "No cache directory",
            )
            return True

        # Remove all .cache and .pkl files older than 30 days
        import time

        now = time.time()
        thirty_days = 30 * 24 * 60 * 60

        cache_files = list(CACHE.glob("**/*.cache")) + list(CACHE.glob("**/*.pkl"))
        removed = []

        for cache_file in cache_files:
            try:
                if now - cache_file.stat().st_mtime > thirty_days:
                    cache_file.unlink()
                    removed.append(cache_file.name)
            except Exception:
                # Try to remove corrupted files
                try:
                    cache_file.unlink()
                    removed.append(cache_file.name)
                except Exception:
                    pass

        if removed:
            result.add_repair(
                "clear-stale-cache",
                "Clear Stale Cache",
                "success",
                f"Removed {len(removed)} stale cache file(s)",
            )
        else:
            result.add_repair(
                "clear-stale-cache",
                "Clear Stale Cache",
                "skipped",
                "No stale cache files found",
            )

        return True
    except Exception as e:
        result.add_repair(
            "clear-stale-cache", "Clear Stale Cache", "failed", f"Error: {e}"
        )
        return False


def repair_rebuild_patch_state(
    result: DoctorResult, project_name: Optional[str] = None
) -> bool:
    """Regenerate patch_state.json from patch files."""
    if not project_name:
        result.add_repair(
            "rebuild-patch-state",
            "Rebuild Patch State",
            "skipped",
            "No project specified",
        )
        return True

    try:
        from branchpy.patch_state import _state_path

        pdir = get_project_patches_dir(project_name)
        state_path = _state_path(pdir)

        # Create a fresh patch state
        fresh_state = {
            "stack": [],
            "metadata": {},
            "last_updated": datetime.now().isoformat(),
        }

        state_path.parent.mkdir(parents=True, exist_ok=True)
        with open(state_path, "w", encoding="utf-8") as f:
            json.dump(fresh_state, f, indent=2)

        result.add_repair(
            "rebuild-patch-state",
            "Rebuild Patch State",
            "success",
            "Patch state rebuilt successfully",
        )
        return True
    except Exception as e:
        result.add_repair(
            "rebuild-patch-state", "Rebuild Patch State", "failed", f"Error: {e}"
        )
        return False


def repair_fix_permissions(result: DoctorResult) -> bool:
    """Set correct permissions on BranchPy directories."""
    try:
        dirs_to_fix = [CONFIG.parent, CACHE, LOGS, BASE]
        fixed = []

        for dir_path in dirs_to_fix:
            if dir_path.exists() and not os.access(dir_path, os.W_OK):
                try:
                    # Try to fix permissions (platform-dependent)
                    if platform.system() != "Windows":
                        os.chmod(dir_path, 0o755)
                        fixed.append(str(dir_path))
                except Exception:
                    pass

        if fixed:
            result.add_repair(
                "fix-permissions",
                "Fix Directory Permissions",
                "success",
                f"Fixed {len(fixed)} directory(ies)",
            )
        else:
            result.add_repair(
                "fix-permissions",
                "Fix Directory Permissions",
                "skipped",
                "All permissions OK or not fixable",
            )

        return True
    except Exception as e:
        result.add_repair(
            "fix-permissions", "Fix Directory Permissions", "failed", f"Error: {e}"
        )
        return False


def repair_cleanup_invalid_reports(
    result: DoctorResult, project_root: Optional[Path] = None
) -> bool:
    """Remove or repair corrupted report files."""
    if not project_root:
        result.add_repair(
            "cleanup-invalid-reports",
            "Cleanup Invalid Reports",
            "skipped",
            "No project specified",
        )
        return True

    try:
        reports_dir = project_root / ".branchpy"

        if not reports_dir.exists():
            result.add_repair(
                "cleanup-invalid-reports",
                "Cleanup Invalid Reports",
                "skipped",
                "No reports directory",
            )
            return True

        report_types = ["analyze", "stats", "tests", "media"]
        removed = []

        for report_type in report_types:
            type_dir = reports_dir / report_type
            if type_dir.exists():
                json_files = list(type_dir.glob("*.json"))

                for json_file in json_files:
                    try:
                        with open(json_file, "r", encoding="utf-8") as f:
                            json.load(f)
                    except Exception:
                        # Remove invalid JSON file
                        json_file.unlink()
                        removed.append(f"{report_type}/{json_file.name}")

        if removed:
            result.add_repair(
                "cleanup-invalid-reports",
                "Cleanup Invalid Reports",
                "success",
                f"Removed {len(removed)} invalid report(s)",
            )
        else:
            result.add_repair(
                "cleanup-invalid-reports",
                "Cleanup Invalid Reports",
                "skipped",
                "No invalid reports found",
            )

        return True
    except Exception as e:
        result.add_repair(
            "cleanup-invalid-reports",
            "Cleanup Invalid Reports",
            "failed",
            f"Error: {e}",
        )
        return False


def repair_create_default_config(
    result: DoctorResult, project_root: Optional[Path] = None
) -> bool:
    """Generate a default .branchpy.toml if missing."""
    if not project_root:
        result.add_repair(
            "create-default-config",
            "Create Default Config",
            "skipped",
            "No project specified",
        )
        return True

    try:
        config_path = project_root / ".branchpy.toml"

        if config_path.exists():
            result.add_repair(
                "create-default-config",
                "Create Default Config",
                "skipped",
                "Config already exists",
            )
            return True

        default_config = """# BranchPy Configuration
# See https://branchpy.org/docs/configuration for full documentation

[project]
name = "My Project"
description = "BranchPy managed project"

[watch]
debounce_ms = 300
default_command = "tests"
include = ["**/*.rpy", "assets/**", "game/**", ".branchpy.toml"]
exclude = ["**/__pycache__/**", "**/.git/**", "**/build/**"]

[logs]
level = "info"
max_lines = 2000

[features]
auto_update = true
"""

        with open(config_path, "w", encoding="utf-8") as f:
            f.write(default_config)

        result.add_repair(
            "create-default-config",
            "Create Default Config",
            "success",
            "Created default .branchpy.toml",
        )
        return True
    except Exception as e:
        result.add_repair(
            "create-default-config", "Create Default Config", "failed", f"Error: {e}"
        )
        return False


# ============================================================================
# Omega Artifacts Check (Track 2: Doctor ↔ Omega Coupling)
# ============================================================================


def check_omega_readiness(
    result: DoctorResult, project_root: Optional[Path] = None
) -> bool:
    """
    Check Omega artifacts readiness (promotion-only, read-only).

    Validates presence and basic structure of Omega cache and PF triads artifacts.
    Does NOT recompute or generate artifacts - pure validation.

    Status logic:
    - PASS: Omega cache exists, parseable, and schema-valid
    - WARN: Omega cache missing (encourages adoption)
    - FAIL: Omega cache exists but corrupt/unparseable

    Args:
        result: DoctorResult to populate
        project_root: Project root directory (optional)

    Returns:
        bool: True if check passed, False otherwise
    """
    from branchpy.doctor.omega_artifacts import (
        find_pf_triads,
        read_json,
        validate_pf_triads_minimal,
    )
    from branchpy.omega.cache_validator import validate_omega_cache

    if project_root is None:
        result.add_check(
            "omega_readiness",
            "Omega Artifacts Readiness",
            "warn",
            "No project root available",
            "Project context required for Omega artifact checks",
        )
        return False

    # Locate omega_metrics.json (canonical BPY-OMEGA-03 path, then legacy fallback)
    metrics_path = project_root / ".branchpy" / "omega" / "omega_metrics.json"
    if not metrics_path.exists():
        legacy_metrics = project_root / ".branchpy" / "omega_metrics.json"
        if legacy_metrics.exists():
            metrics_path = legacy_metrics

    # Delegate to the shared cache validator
    val = validate_omega_cache(metrics_path)

    # Map validator result to Doctor status/message
    # missing (exit 2, file absent) → "warn" (encourages adoption)
    # corrupt (exit 2, file present but bad) → "fail"
    # schema mismatch (exit 1) → "warn" (non-blocking)
    # valid (exit 0) → "pass"
    if val.exit_code == 2:
        if not metrics_path.exists():
            cache_status = "warn"
            cache_message = "Omega metrics cache not found"
            cache_details = "Run `branchpy omega` to generate Omega artifacts"
        else:
            cache_status = "fail"
            cache_message = val.message
            cache_details = str(metrics_path)
    elif val.exit_code == 1:
        cache_status = "warn"
        cache_message = val.message
        cache_details = str(metrics_path)
    else:
        cache_status = "pass"
        cache_message = val.message
        cache_details = str(metrics_path)

    # Build cache_info for JSON output
    cache_info: dict = {
        "path": str(metrics_path),
        "present": metrics_path.exists(),
        "readable": val.exit_code != 2 or metrics_path.exists() and val.status != "invalid",
        "schema_version": None,
        "generated_at": None,
        "branchpy_version": None,
    }
    if metrics_path.exists() and val.exit_code != 2:
        try:
            import json as _json
            _data = _json.loads(metrics_path.read_text(encoding="utf-8"))
            cache_info["schema_version"] = _data.get("schema_version")
            cache_info["generated_at"] = _data.get("generated_at", _data.get("timestamp_utc"))
            cache_info["branchpy_version"] = _data.get("branchpy_version")
            cache_info["readable"] = True
        except Exception:
            pass

    # Check PF triads artifact (optional, less strict)
    pf_path = find_pf_triads(project_root)
    pf_info = {
        "path": ".branchpy/pf_triads.json" if pf_path else None,
        "present": pf_path is not None,
        "readable": False,
        "schema_version": None,
        "generated_at": None,
    }

    pf_notes = []
    if pf_path:
        data, error = read_json(pf_path)
        if error:
            pf_notes.append(f"PF triads artifact corrupt: {error}")
            pf_info["readable"] = False
        else:
            pf_info["readable"] = True
            is_valid, info, val_error = validate_pf_triads_minimal(data)
            pf_info.update(info)

            if not is_valid:
                pf_notes.append(f"PF triads artifact invalid: {val_error}")
    else:
        pf_notes.append(
            "PF triads artifact not found (optional). Run `branchpy omega pf-report` after omega analyze."
        )

    # Add main check result
    result.add_check(
        "omega_readiness",
        "Omega Artifacts Readiness",
        cache_status,
        cache_message,
        cache_details,
    )

    # Store omega metadata in result for JSON output
    if not hasattr(result, "omega"):
        result.omega = {
            "cache": cache_info,
            "pf_triads": pf_info,
            "readiness": cache_status,
            "notes": pf_notes,
        }

    return cache_status == "pass"


# ============================================================================
# Narrative Insight Check (project_structure context — v1.2.1)
# ============================================================================


def check_narrative_insight(
    result: DoctorResult, project_root: Optional[Path] = None
) -> bool:
    """Read insight_summary and contextualise narrative-entry availability.

    For hub-based projects, "no narrative entry" and "multiple entry roots"
    are *expected* — Doctor should say so explicitly rather than being silent
    (or, worse, implying a problem).

    Rules:
    - project_structure == 'hub'   → pass, explain hub behaviour
    - project_structure == 'mixed' → pass, note that entry label is optional
    - project_structure == 'linear' and no insight  → pass (no data to check)
    - No insight_summary at all    → pass (artifact not yet generated)
    """
    if not project_root:
        result.add_check(
            "narrative-insight",
            "Narrative Structure Context",
            "pass",
            "No project specified",
        )
        return True

    try:
        from branchpy.insight_summary import ARTIFACT_FILENAME

        # New canonical location (.branchpy/insights/), fall back to root
        canonical = project_root / ".branchpy" / "insights" / ARTIFACT_FILENAME
        legacy    = project_root / ".branchpy" / ARTIFACT_FILENAME
        summary_path = canonical if canonical.exists() else (legacy if legacy.exists() else None)

        if summary_path is None:
            result.add_check(
                "narrative-insight",
                "Narrative Structure Context",
                "pass",
                "No insight_summary found — run Analyze first",
            )
            return True

        with open(summary_path, "r", encoding="utf-8") as f:
            summary = json.load(f)

        ps_domain = summary.get("project_structure") or {}
        structure  = ps_domain.get("project_structure")
        confidence = ps_domain.get("structure_confidence")
        signals    = ps_domain.get("structure_signals") or {}

        if structure is None:
            # Old schema — field not yet computed
            result.add_check(
                "narrative-insight",
                "Narrative Structure Context",
                "pass",
                "Project structure not yet classified — re-run Analyze to compute",
            )
            return True

        conf_pct = f"{int(confidence * 100)}%" if confidence is not None else "n/a"

        if structure == "hub":
            result.add_check(
                "narrative-insight",
                "Narrative Structure Context",
                "pass",
                f"Hub-based project ({conf_pct} confidence) — multiple entry points are expected",
                (
                    "Hub projects use shared scenes and dispatch points instead of a single story start. "
                    "'No narrative entry resolved' and 'Multiple entry roots' findings in PILOT are "
                    "informational for this project type, not errors. "
                    "Set branchpy.narrativeEntryLabel only if you want path-based narrative analysis."
                ),
            )
        elif structure == "mixed":
            result.add_check(
                "narrative-insight",
                "Narrative Structure Context",
                "pass",
                f"Mixed structure ({conf_pct} confidence) — narrative analysis is optional",
                (
                    "This project combines linear story scenes with hub/system scenes. "
                    "Narrative path analysis may be partial if no entry label is configured. "
                    "Set branchpy.narrativeEntryLabel to target a specific story entry."
                ),
            )
        else:  # linear
            total_labels = signals.get("total_labels", 0)
            result.add_check(
                "narrative-insight",
                "Narrative Structure Context",
                "pass",
                f"Linear structure ({conf_pct} confidence, {total_labels} labels) — narrative analysis available",
            )

        return True

    except Exception as e:
        result.add_check(
            "narrative-insight", "Narrative Structure Context", "warn", f"Error: {e}"
        )
        return False


# ============================================================================
# Main Doctor Command
# ============================================================================

# Available checks and their functions
AVAILABLE_CHECKS = {
    "python-version": check_python_version,
    "python-modules": check_python_modules,
    "system-info": check_system_info,
    "branchpy-dirs": check_branchpy_dirs,
    "storage-layout": check_storage_layout,  # v1.0.0 Storage architecture paths
    "config-integrity": check_config_integrity,
    "git-availability": check_git_availability,
    "git-status": check_git_status,
    "project-structure": check_project_structure,
    "patch-directory": check_patch_directory,
    "patch-state": check_patch_state,
    "renpy-sdk-project": check_renpy_sdk_project,
    "renpy-sdk-global": check_renpy_sdk_global,
    "cache-integrity": check_cache_integrity,
    "reports-validity": check_reports_validity,
    "media-phase-c": check_media_phase_c,  # v0.9.7 Phase C integration
    "media-coverage": check_media_coverage,  # v0.9.7 Coverage metrics
    "media-integrity": check_media_integrity,  # v0.9.7 Integrity checks
    "bqf-compliance": check_bqf_compliance,  # v0.9.7 BQF summary
    "omega_readiness": check_omega_readiness,  # v1.1.2 Track 2: Omega artifacts
    "narrative-insight": check_narrative_insight,  # v1.2.1 Hub structure context
}

# Task 3: Doctor CI Standardization (v1.1.2)
# CI-safe check subset: stable, non-flaky, meaningful in automated environments
CI_CHECK_IDS = [
    "python-version",
    "python-modules",
    "config-integrity",
    "git-availability",
    "cache-integrity",
    "omega_readiness",  # Track 2: promotion-only, deterministic
]

# Available repairs and their functions
AVAILABLE_REPAIRS = {
    "create-missing-dirs": repair_create_missing_dirs,
    "fix-config-syntax": repair_fix_config_syntax,
    "clear-stale-cache": repair_clear_stale_cache,
    "rebuild-patch-state": repair_rebuild_patch_state,
    "fix-permissions": repair_fix_permissions,
    "cleanup-invalid-reports": repair_cleanup_invalid_reports,
    "create-default-config": repair_create_default_config,
}


def cmd_doctor(args: argparse.Namespace) -> int:
    """Enhanced doctor command with comprehensive diagnostics and auto-repair."""
    # LIC-CLI-1: Full doctor requires doctor_full feature (Pro+ or Ren'Py)
    # Lite mode (basic checks) is always available
    is_full_mode = (
        args.remote
        or args.slo
        or args.path_mapping
        or (hasattr(args, "checks") and args.checks and len(args.checks.split(",")) > 5)
    )
    if is_full_mode:
        require_feature_cli("doctor_full", "Full Doctor Diagnostics", None)

    result = DoctorResult()

    # WS-R1/WS-R3: Remote environment and path mapping diagnostics (v0.9.2)
    if args.remote:
        from remote.bootstrap_doctor import UnifiedBootstrapDoctor

        doctor = UnifiedBootstrapDoctor()
        diagnostic_result = doctor.diagnostic_remote()

        # Convert DiagnosticResult to DoctorResult format
        for check in diagnostic_result.checks:
            status_map = {
                "pass": "pass",
                "warn": "warn",
                "fail": "fail",
                "skip": "pass",  # Treat skip as pass for summary
            }
            result.add_check(
                check.check_id,
                check.name,
                status_map.get(check.status.value, "warn"),
                check.message,
                check.details or "",
            )

        if not args.json:
            print("\n🌐 Remote Environment Diagnostics")
            print(f"   Duration: {diagnostic_result.duration_ms:.0f}ms")
            if "remote_mode" in diagnostic_result.metadata:
                print(f"   Mode: {diagnostic_result.metadata['remote_mode']}")
                print(f"   Platform: {diagnostic_result.metadata['platform']}")

        # WS-C1: Display remote context details (v0.9.2)
        if not args.json:
            try:
                from branchpy.core.engine_resolver import EngineResolver
                from branchpy.core.remote_context import RemoteContext

                remote_ctx = RemoteContext.detect()
                print("\n   🔍 WS-C1 Remote Context:")
                print(f"      Type: {remote_ctx.type.value}")
                print(f"      Is Remote: {remote_ctx.is_remote}")
                print(f"      Is CI: {remote_ctx.is_ci}")
                print(f"      Session: {remote_ctx.session_id}")

                engine_ctx = EngineResolver().detect()
                print("\n   🎮 WS-C1 Engine Detection:")
                print(f"      Type: {engine_ctx.engine_type.value}")
                print(f"      Confidence: {engine_ctx.confidence:.2f}")
                if engine_ctx.version:
                    print(f"      Version: {engine_ctx.version}")
            except Exception as e:
                print(f"\n   ⚠️  WS-C1 context detection error: {e}")

    # WS-R2: Service level objective verification (v0.9.2)
    if args.slo:
        from remote.bootstrap_doctor import UnifiedBootstrapDoctor

        doctor = UnifiedBootstrapDoctor()
        diagnostic_result = doctor.diagnostic_slo()

        # Convert DiagnosticResult to DoctorResult format
        for check in diagnostic_result.checks:
            status_map = {
                "pass": "pass",
                "warn": "warn",
                "fail": "fail",
                "skip": "pass",
            }
            result.add_check(
                check.check_id,
                check.name,
                status_map.get(check.status.value, "warn"),
                check.message,
                check.details or "",
            )

        if not args.json:
            print("\n⏱️  Service Level Objectives (SLO)")
            print(f"   Duration: {diagnostic_result.duration_ms:.0f}ms")
            summary = diagnostic_result.get_summary()
            print(f"   Passed: {summary['passed']}/{summary['total']}")
            if summary["failed"] > 0:
                print(f"   ⚠️  {summary['failed']} SLO(s) not met")

    # WS-R3: Path mapping diagnostics (v0.9.2)
    if args.path_mapping:
        from remote.bootstrap_doctor import UnifiedBootstrapDoctor

        doctor = UnifiedBootstrapDoctor()
        diagnostic_result = doctor.diagnostic_path_mapping()

        # Convert DiagnosticResult to DoctorResult format
        for check in diagnostic_result.checks:
            status_map = {
                "pass": "pass",
                "warn": "warn",
                "fail": "fail",
                "skip": "pass",
            }
            result.add_check(
                check.check_id,
                check.name,
                status_map.get(check.status.value, "warn"),
                check.message,
                check.details or "",
            )

        if not args.json:
            print("\n🗺️  Path Mapping Diagnostics")
            print(f"   Duration: {diagnostic_result.duration_ms:.0f}ms")
            if "translator_active" in diagnostic_result.metadata:
                translator_status = (
                    "Active"
                    if diagnostic_result.metadata["translator_active"]
                    else "Identity (local)"
                )
                print(f"   Translator: {translator_status}")
                print(
                    f"   Custom rules: {diagnostic_result.metadata.get('custom_rules', 0)}"
                )

            # Show cache stats if available
            cache_stats = diagnostic_result.metadata.get("cache_stats", {})
            if cache_stats.get("total", 0) > 0:
                print("\n   Cache Statistics:")
                print(f"     Total translations: {cache_stats['total']}")
                print(f"     Hit rate: {cache_stats.get('hit_rate_percent', 0):.1f}%")
                if "p95_latency_ms" in cache_stats:
                    print(f"     P95 latency: {cache_stats['p95_latency_ms']:.2f}ms")

    #     pass

    # Task 3: CI mode enforcement (v1.1.2)
    ci_mode = getattr(args, "ci", False)

    if ci_mode:
        # CI mode forces JSON output
        args.json = True
        # CI mode disables repairs (read-only)
        args.repairs = None

    # Determine which checks to run
    if args.checks:
        check_ids = [c.strip() for c in args.checks.split(",")]
    elif ci_mode:
        # CI mode uses stable subset
        check_ids = CI_CHECK_IDS
    else:
        check_ids = list(AVAILABLE_CHECKS.keys())

    # Determine which repairs to run
    if args.repairs:
        repair_ids = [r.strip() for r in args.repairs.split(",")]
    else:
        repair_ids = []

    # Get project info if available
    project_root = None
    project_name = None

    try:
        project_name, proj_root, _ = ensure_project_registered(
            getattr(args, "project", None)
        )
        project_root = Path(proj_root)
    except (SystemExit, Exception):
        pass  # No project available

    # Run checks
    if not args.json:
        print(
            f"{_get_emoji_or_fallback('🩺', 'Doctor')} BranchPy Doctor — Running checks"
        )
        print("=" * 60)

    for check_id in check_ids:
        if check_id in AVAILABLE_CHECKS:
            check_func = AVAILABLE_CHECKS[check_id]

            # Pass appropriate parameters based on check requirements
            if check_id in [
                "git-status",
                "project-structure",
                "reports-validity",
                "renpy-sdk-project",
                "media-phase-c",
                "media-coverage",
                "media-integrity",
                "bqf-compliance",
                "omega_readiness",  # Track 2: requires project_root
            ]:
                check_func(result, project_root)
            elif check_id in ["patch-directory", "patch-state"]:
                check_func(result, project_name)
            elif check_id == "cache-integrity":
                # Task 3: Pass ci_mode to cache-integrity for proper semantics
                check_func(result, ci_mode)
            else:
                check_func(result)

    # Run repairs if requested
    if repair_ids:
        if not args.json:
            print(f"\n{_get_emoji_or_fallback('🔧', 'Repair')} Running Auto-Repairs")
            print("=" * 60)

        for repair_id in repair_ids:
            if repair_id in AVAILABLE_REPAIRS:
                repair_func = AVAILABLE_REPAIRS[repair_id]

                # Pass appropriate parameters
                if repair_id in ["rebuild-patch-state"]:
                    repair_func(result, project_name)
                elif repair_id in ["cleanup-invalid-reports", "create-default-config"]:
                    repair_func(result, project_root)
                else:
                    repair_func(result)

    # Save report to .branchpy/doctor/
    if project_root:
        try:
            doctor_dir = project_root / ".branchpy" / "doctor"
            doctor_dir.mkdir(parents=True, exist_ok=True)

            timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            report_path = doctor_dir / f"doctor_{timestamp}.json"

            with open(report_path, "w", encoding="utf-8") as f:
                json.dump(result.to_dict(), f, indent=2)

            if not args.json:
                print(
                    f"\n{_get_emoji_or_fallback('💾', 'Save')} Report saved to: {report_path}"
                )
        except Exception as e:
            if not args.json:
                print(
                    f"\n{_get_emoji_or_fallback('⚠️', 'Warning')} Could not save report: {e}"
                )

    # Output results
    if args.json:
        print(json.dumps(result.to_dict(), indent=2))
    else:
        # Human-readable summary
        print(f"\n{_get_emoji_or_fallback('📊', 'Summary')} Findings Summary")
        print("=" * 60)
        print(f"Total Checks: {result.summary['totalChecks']}")
        print(
            f"  {_get_emoji_or_fallback('✓', 'Pass')} Passed: {result.summary['passed']}"
        )
        print(
            f"  {_get_emoji_or_fallback('⚠️', 'Warn')} Warnings: {result.summary['warnings']}"
        )
        print(
            f"  {_get_emoji_or_fallback('✗', 'Fail')} Failed: {result.summary['failed']}"
        )

        if result.summary["repairsRun"] > 0:
            print(
                f"\nRepairs: {result.summary['repairsSucceeded']}/{result.summary['repairsRun']} successful"
            )

        print()

        # Show detailed results
        for check in result.checks:
            icon = (
                "✓"
                if check["status"] == "pass"
                else "⚠️" if check["status"] == "warn" else "✗"
            )
            icon = _get_emoji_or_fallback(icon, f"[{check['status'].upper()}]")
            print(f"{icon} {check['name']}: {check['message']}")
            if check.get("details"):
                print(f"  → {check['details']}")

        if result.repairs:
            print(f"\n{_get_emoji_or_fallback('🔧', 'Repairs')} Repairs Applied:")
            for repair in result.repairs:
                icon = (
                    "✓"
                    if repair["status"] == "success"
                    else "○" if repair["status"] == "skipped" else "✗"
                )
                icon = _get_emoji_or_fallback(icon, f"[{repair['status'].upper()}]")
                print(f"{icon} {repair['name']}: {repair['message']}")

    # Return appropriate exit code
    if result.summary["failed"] > 0:
        return 2  # Critical errors
    elif result.summary["warnings"] > 0:
        return 1  # Warnings
    else:
        return 0  # All clear


def add_parser(subparsers):
    """Add doctor command parser."""
    p = subparsers.add_parser(
        "doctor",
        help="Project health checks and analysis interpretation.",
        description="Run environment checks and analysis interpretation for your BranchPy project. Reports saved to .branchpy/doctor/",
    )
    p.add_argument(
        "--json",
        action="store_true",
        help="Output results in JSON format for programmatic use",
    )
    # Task 3: CI mode flags (v1.1.2)
    p.add_argument(
        "--ci",
        action="store_true",
        help="[v1.1.2] CI mode: JSON output, read-only, non-interactive (runs CI_CHECK_IDS subset)",
    )
    p.add_argument(
        "--ci-mode",
        action="store_true",
        dest="ci",
        help="[Deprecated] Alias for --ci",
    )
    p.add_argument(
        "--checks",
        type=str,
        help="Comma-separated list of check IDs to run (default: all)",
    )
    p.add_argument(
        "--repairs",
        type=str,
        help="Comma-separated list of repair IDs to run (default: none)",
    )
    # WS-R1: Remote environment detection hook (v0.9.2)
    p.add_argument(
        "--remote",
        action="store_true",
        help="[v0.9.2] Run remote environment diagnostics (SSH, Codespaces, Docker, WSL, CI)",
    )
    # WS-R2: Service level objective verification hook (v0.9.2)
    p.add_argument(
        "--slo",
        action="store_true",
        help="[v0.9.2] Verify service level objectives (performance budgets, latency targets)",
    )
    # WS-R3: Path mapping diagnostics hook (v0.9.2)
    p.add_argument(
        "--path-mapping",
        action="store_true",
        help="[v0.9.2] Run path mapping diagnostics (host ↔ remote translation, cache stats)",
    )
    p.set_defaults(handler=cmd_doctor)
