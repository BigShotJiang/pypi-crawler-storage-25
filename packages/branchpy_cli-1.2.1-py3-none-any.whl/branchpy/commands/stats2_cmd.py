"""
PILOT Command - Path-aware variable analysis (v0.7.26)

Generates comprehensive variable behavior analysis across execution paths,
including variance detection, type consistency checking, and timeline tracking.

Usage:
    branchpy stats2
    branchpy --project mygame stats2
    branchpy stats2 --max-paths 1000 --max-depth 150
"""

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Type

# License gating (v1.0.0)
from branchpy.license.gating import require_feature_cli

# PILOT: Semantics call index builder
try:
    from branchpy.pilot.collect_call_index import build_call_index

    _HAS_CALL_INDEX = True
except Exception:
    _HAS_CALL_INDEX = False
    build_call_index = None  # type: ignore

# SAE infrastructure (same as stats_cmd)
try:
    from branchpy.analysis.sae.cfg_builder import StatementCFGBuilder
    from branchpy.analysis.sae.indexer import Indexer

    _HAS_SAE = True
except Exception:
    _HAS_SAE = False
    Indexer: Optional[Type] = None  # type: ignore
    StatementCFGBuilder: Optional[Type] = None  # type: ignore

# PILOT foundation
try:
    from branchpy.analysis.stats2 import (
        PathStatsAnalyzer,
        Stats2Exporter,
        StatsAggregator,
    )

    _HAS_STATS2 = True
except Exception:
    _HAS_STATS2 = False
    PathStatsAnalyzer: Optional[Type] = None  # type: ignore
    StatsAggregator: Optional[Type] = None  # type: ignore
    Stats2Exporter: Optional[Type] = None  # type: ignore

# Logging fallback
try:
    from branchpy.core.logging import log  # type: ignore
except ImportError:

    class _FallbackLog:
        def debug(self, msg, *args, **kwargs):
            pass

        def info(self, msg, *args, **kwargs):
            pass

        def warn(self, msg, *args, **kwargs):
            pass

        def error(self, msg, *args, **kwargs):
            pass

    log = _FallbackLog()


def _resolve_entry_labels_from_cfg(
    nodes_dict: dict, requested_labels: List[str]
) -> List[Tuple[str, str]]:
    """
    Resolve a list of label name strings to (node_id, label_name) tuples using
    the CFG nodes dict.  Returns only labels that were found; logs a warning for
    each that was not found.
    """
    # Build name → node_id lookup for LABEL nodes
    name_to_node: Dict[str, str] = {}
    for node_id, node in nodes_dict.items():
        kind = (
            node.get("kind") if isinstance(node, dict) else getattr(node, "kind", None)
        )
        kind_str = str(kind) if kind else None
        if not (kind_str and "LABEL" in kind_str):
            continue
        name = (
            node.get("name") if isinstance(node, dict) else getattr(node, "name", None)
        )
        if name:
            name_to_node[name] = node_id

    resolved: List[Tuple[str, str]] = []
    seen: set = set()
    for label in requested_labels:
        if label in seen:
            continue
        seen.add(label)
        node_id = name_to_node.get(label)
        if node_id:
            resolved.append((node_id, label))
        else:
            print(f"[PILOT] WARNING: entry label '{label}' not found in CFG — skipping")
    return resolved


def _enumerate_paths_simple(
    cfg,
    max_paths: int = 500,
    max_depth: int = 100,
    entry_node_ids: Optional[List[Tuple[str, str]]] = None,
) -> Tuple[Dict[str, List[str]], Dict[str, str]]:
    """
    Full-path enumeration using DFS from entry label(s) to terminal nodes.

    Returns (paths, entry_source_map) where:
      paths: dict mapping path_id -> list of label names
      entry_source_map: dict mapping path_id -> entry label name

    Multi-entry: if entry_node_ids is provided as [(node_id, label_name), ...],
    one independent DFS is run per entry.  The max_paths budget is shared across
    all entries.  If entry_node_ids is None, a single entry is auto-detected
    (prefer 'start', fallback to first label node).

    Paths represent complete playthroughs from an entry label to terminal labels
    (nodes with no outgoing edges).  Fragments (<3 labels) are filtered.

    Uses branch-signature tracking to allow convergent branches:
    - visited = set of (node_id, branch_signature) tuples, reset per entry
    - branch_signature = tuple of recent branch decisions
    - This allows same node to be visited via different routes
    """
    paths: Dict[str, List[str]] = {}
    entry_source_map: Dict[str, str] = {}
    path_count = 0

    # Get nodes and edges from CFG
    nodes_dict = (
        cfg.nodes if hasattr(cfg, "nodes") and isinstance(cfg.nodes, dict) else {}
    )
    edges_list = (
        cfg.edges if hasattr(cfg, "edges") and isinstance(cfg.edges, list) else []
    )

    if not nodes_dict or not edges_list:
        log.warn("[PILOT] No nodes or edges found in CFG")
        return {"p001": []}, {}

    # Build adjacency list with edge type info
    adj: Dict[str, List[tuple]] = {}  # node_id -> [(target_id, edge_type), ...]
    for edge in edges_list:
        # Handle both dict and object edge formats
        src = (
            edge.get("from")
            if isinstance(edge, dict)
            else getattr(edge, "from_node", None) or getattr(edge, "src", None)
        )
        dst = (
            edge.get("to")
            if isinstance(edge, dict)
            else getattr(edge, "to_node", None) or getattr(edge, "dst", None)
        )
        edge_type = (
            edge.get("type")
            if isinstance(edge, dict)
            else getattr(edge, "edge_type", None)
        )
        edge_type_str = str(edge_type) if edge_type else "seq"

        if src and dst:
            adj.setdefault(src, []).append((dst, edge_type_str))

    # Find all label nodes
    label_nodes = []
    for node_id, node in nodes_dict.items():
        kind = (
            node.get("kind") if isinstance(node, dict) else getattr(node, "kind", None)
        )
        kind_str = str(kind) if kind else None
        if kind_str and "LABEL" in kind_str:  # Handle both "label" and "NodeKind.LABEL"
            label_nodes.append(node_id)

    if not label_nodes:
        log.warn("[PILOT] No label nodes found")
        return {"p001": []}, {}

    # Resolve entry list: use supplied entries or auto-detect a single entry
    if entry_node_ids:
        entry_list: List[Tuple[str, str]] = list(entry_node_ids)
    else:
        # Auto-detect: prefer 'start', fallback to first label
        auto_entry_id: Optional[str] = None
        auto_entry_name: Optional[str] = None
        for node_id in label_nodes:
            node = nodes_dict.get(node_id)
            name = (
                node.get("name")
                if isinstance(node, dict)
                else getattr(node, "name", None)
            )
            if name and name.lower() == "start":
                auto_entry_id = node_id
                auto_entry_name = name
                log.info(f"[PILOT] Found 'start' entry label: {name}")
                break

        if not auto_entry_id:
            auto_entry_id = label_nodes[0]
            node = nodes_dict.get(auto_entry_id)
            auto_entry_name = (
                node.get("name")
                if isinstance(node, dict)
                else getattr(node, "name", None)
            )
            log.info(f"[PILOT] Using first label as entry: {auto_entry_name}")

        entry_list = [(auto_entry_id, auto_entry_name or auto_entry_id)]

    # DFS with branch-signature tracking — one independent sweep per entry.
    # Stack: (current_node_id, path_of_node_ids, depth, branch_signature)
    # branch_signature: tuple of last N branch decisions (for convergence handling)
    SIGNATURE_WINDOW = 32  # Keep last 32 branch decisions

    for entry_node_id, entry_label in entry_list:
        if path_count >= max_paths:
            log.info(
                f"[PILOT] max_paths={max_paths} reached before entry '{entry_label}'"
            )
            break

        log.info(f"[PILOT] Starting DFS from entry '{entry_label}' ({entry_node_id})")
        entry_paths_before = path_count

        visited = set()  # Fresh visited set per entry
        stack = [(entry_node_id, [entry_node_id], 0, tuple())]

        while stack and path_count < max_paths:
            node_id, path, depth, signature = stack.pop()

            # Check visited with signature
            visit_key = (node_id, signature)
            if visit_key in visited:
                continue
            visited.add(visit_key)

            # Check if we've reached max depth
            if depth >= max_depth:
                continue

            # Check if this is a terminal node (no outgoing edges)
            neighbors = adj.get(node_id, [])

            if not neighbors:
                # Terminal node reached - extract labels from path
                # Convert node IDs to label names (only LABEL kind nodes)
                label_path = []
                for nid in path:
                    node = nodes_dict.get(nid)
                    if node:
                        name = (
                            node.get("name")
                            if isinstance(node, dict)
                            else getattr(node, "name", None)
                        )
                        kind = (
                            node.get("kind")
                            if isinstance(node, dict)
                            else getattr(node, "kind", None)
                        )
                        kind_str = str(kind) if kind else None
                        if kind_str and "LABEL" in kind_str and name:
                            label_path.append(name)

                # Only save paths with minimum 3 labels (filter fragments)
                if len(label_path) >= 3:
                    path_id = f"p{path_count + 1:03d}"
                    paths[path_id] = label_path
                    entry_source_map[path_id] = entry_label
                    path_count += 1
                    log.info(
                        f"[PILOT] Path {path_id}: {len(label_path)} labels "
                        f"({label_path[0]} → ... → {label_path[-1]})"
                    )
                else:
                    log.debug(
                        f"[PILOT] Skipped fragment with {len(label_path)} labels"
                    )
                continue

            # Explore ALL neighbors to find all branches
            for neighbor_tuple in neighbors:
                neighbor, edge_type = neighbor_tuple

                # Build new signature based on edge type
                branch_marker = None
                if "BRANCH_TRUE" in edge_type:
                    branch_marker = (node_id, "T")
                elif "BRANCH_FALSE" in edge_type:
                    branch_marker = (node_id, "F")
                elif len(neighbors) > 1 and "JUMP" in edge_type:
                    # Multiple JUMP edges from same node = menu choices
                    # Use neighbor ID suffix as choice identifier
                    branch_marker = (node_id, f"J{neighbor[-4:]}")

                # Extend signature
                new_signature = signature
                if branch_marker:
                    new_signature = (signature + (branch_marker,))[-SIGNATURE_WINDOW:]

                # Check for simple cycles (same node in current path with same signature)
                # Allow revisiting if signature differs (different route)
                if neighbor in path:
                    if (neighbor, new_signature) in visited:
                        continue
                    # Allow revisit via different branch (signature differs)

                new_path = path + [neighbor]
                stack.append((neighbor, new_path, depth + 1, new_signature))

        entry_paths_found = path_count - entry_paths_before
        log.info(
            f"[PILOT] Entry '{entry_label}': {entry_paths_found} paths found, "
            f"{len(visited)} states explored"
        )

    log.info(f"[PILOT] Enumerated {len(paths)} full execution paths total")
    return paths, entry_source_map


def run(args) -> int:
    """
    Main entry point for stats2 command.

    Args:
        args: Namespace with project, max_paths, max_depth, output_dir

    Returns:
        Exit code (0 = success, 1 = error)
    """
    # LIC-CLI-1: Require pilot_mode feature (Pro+ or Ren'Py)
    project_path = (
        Path(args.project) if hasattr(args, "project") and args.project else None
    )
    require_feature_cli("pilot_mode", "Pilot Mode", project_path)

    start_time = time.time()

    # Check dependencies
    if not _HAS_SAE:
        print("[PILOT] ERROR: SAE module not available")
        print("  PILOT requires SAE (Statement Analysis Engine)")
        return 1

    if not _HAS_STATS2:
        print("[PILOT] ERROR: PILOT foundation not available")
        print("  Missing: branchpy.analysis.stats2 module")
        return 1

    # Parse arguments
    project_root = Path(getattr(args, "project", ".")).resolve()
    max_paths = getattr(args, "max_paths", 500)
    max_depth = getattr(args, "max_depth", 100)
    output_dir_name = getattr(args, "output_dir", "stats2")
    narrative_entry_label: Optional[str] = (
        getattr(args, "narrative_entry_label", None) or None
    )

    # Phase 3a: multi-entry PILOT exploration roots
    _entry_labels_raw: Optional[str] = getattr(args, "entry_labels", None) or None
    requested_entry_labels: List[str] = (
        [lbl.strip() for lbl in _entry_labels_raw.split(",") if lbl.strip()]
        if _entry_labels_raw
        else []
    )

    if not project_root.exists():
        print(f"[PILOT] ERROR: Project not found: {project_root}")
        return 1

    print(f"[PILOT] Starting analysis: {project_root.name}")
    print(f"[PILOT] Limits: max_paths={max_paths}, max_depth={max_depth}")
    log.info(f"Stats2 analysis started for {project_root}")

    try:
        # Step 1: Build CFG using SAE
        print("[PILOT] Step 1/5: Building control flow graph...")
        indexer = Indexer(str(project_root))  # type: ignore
        index = indexer.build_index()

        cfg_builder = StatementCFGBuilder(index, project_root=str(project_root))  # type: ignore
        cfg = cfg_builder.build()

        if not cfg or not hasattr(cfg, "nodes"):
            print("[PILOT] ERROR: Failed to build CFG")
            return 1

        node_count = len(cfg.nodes)
        edge_count = len(cfg.edges) if hasattr(cfg, "edges") else 0
        print(f"[PILOT] CFG built: {node_count} nodes, {edge_count} edges")

        # PILOT v0.9.0: Build semantics call index for Control Center
        if _HAS_CALL_INDEX and build_call_index:
            try:
                print("[PILOT] Building semantics call index...")
                build_call_index(cfg, index, project_root)  # type: ignore
            except Exception as e:
                log.warn(f"Call index build failed (non-critical): {e}")

        # Step 2: Enumerate paths
        print("[PILOT] Step 2/5: Enumerating execution paths...")

        # Resolve explicit entry labels, or fall back to narrative_entry_label / auto-detect
        pilot_entry_node_ids: Optional[List[Tuple[str, str]]] = None
        if requested_entry_labels:
            pilot_entry_node_ids = _resolve_entry_labels_from_cfg(
                cfg.nodes if hasattr(cfg, "nodes") else {}, requested_entry_labels
            )
            if not pilot_entry_node_ids:
                print(
                    "[PILOT] ERROR: None of the requested --entry-labels were found in the CFG"
                )
                return 1
        elif narrative_entry_label:
            # Use narrative entry label as the single PILOT exploration root too
            resolved_from_narrative = _resolve_entry_labels_from_cfg(
                cfg.nodes if hasattr(cfg, "nodes") else {}, [narrative_entry_label]
            )
            if resolved_from_narrative:
                pilot_entry_node_ids = resolved_from_narrative
            # Silently fall through to auto-detect if not found (narrative resolve is best-effort)

        paths, entry_source_map = _enumerate_paths_simple(
            cfg,
            max_paths=max_paths,
            max_depth=max_depth,
            entry_node_ids=pilot_entry_node_ids,
        )
        print(f"[PILOT] Generated {len(paths)} paths")

        if not paths:
            print("[PILOT] WARNING: No paths found")
            # Continue with empty result

        # Step 3: Analyze variable timelines
        print("[PILOT] Step 3/5: Analyzing variable timelines...")
        analyzer = PathStatsAnalyzer(cfg, index=index, project_root=project_root)  # type: ignore

        timelines = {}
        for path_id, label_path in paths.items():
            try:
                timeline = analyzer.analyze_path(label_path)
                if timeline:
                    timelines[path_id] = timeline
            except Exception as e:
                log.debug(f"Path analysis failed for {path_id}: {e}")
                continue

        var_count = len(
            set(var for timeline in timelines.values() for var in timeline.keys())
        )
        print(f"[PILOT] Tracked {var_count} variables across {len(timelines)} paths")

        # Step 4: Aggregate statistics
        print("[PILOT] Step 4/5: Computing aggregates and warnings...")
        aggregator = StatsAggregator()  # type: ignore
        aggregates = aggregator.aggregate_paths(timelines)

        # Step 4b: Compute Narrative Paths (heuristic — non-blocking)
        print("[PILOT] Step 4b/5: Estimating narrative paths...")
        narrative_summary: dict = {}
        try:
            from branchpy.analysis.stats2.narrative_paths import compute_narrative_paths

            # Collect stat variable names for better branch scoring
            stat_var_names = {
                var_name
                for var_name, agg in aggregates.items()
                if getattr(agg, "flags", None) and getattr(agg.flags, "is_stat", False)
            }
            narrative_summary = compute_narrative_paths(
                cfg,
                stat_variable_names=stat_var_names,
                entry_label_override=narrative_entry_label,
                paths_enumerated=len(paths),
                path_label_union={
                    label
                    for label_path in paths.values()
                    for label in label_path
                },
            )
            np_est = narrative_summary.get("narrative_paths_estimate")
            np_conf = narrative_summary.get("narrative_confidence", "?")
            print(f"[PILOT] Narrative Paths: {np_est} ({np_conf} confidence)")
        except Exception as _np_err:
            log.warn(
                f"[PILOT] Narrative paths computation failed (non-critical): {_np_err}"
            )
            narrative_summary = {
                "narrative_entry_label": None,
                "narrative_paths_estimate": None,
                "narrative_outcomes_estimate": None,
                "narrative_confidence": "not_computed",
                "narrative_notes": [f"Computation error: {_np_err}"],
                "narrative_breakdown": [],
                "structure_type": "not_computed",
                "structure_confidence": "not_computed",
                "structure_summary": None,
                "structure_path_coverage_ratio": None,
                "structure_covered_labels": [],
                "structure_uncovered_labels": [],
            }

        # Entry-resolution provenance: store what was requested vs what was resolved,
        # so the VS Code panel can display a clear "Detected / Override / Status" strip.
        #
        # Contract enum (must remain stable — UI logic depends on exact string values):
        #   "override_applied"           – configured override found and used
        #   "override_not_found_fallback"– override label absent, fell back to auto-detect
        #   "override_not_found_no_entry"– override label absent, no fallback resolved either
        #   "auto_detected"              – no override configured, entry resolved automatically
        #   "not_resolved"               – no override, no auto-detect (multiple roots / no start)
        # Phase 3 note: when multi-entry is added, this field will describe the
        # per-run resolution of the *primary* entry.  Per-entry statuses will be
        # stored alongside the individual entry selections.
        _resolved_label = narrative_summary.get("narrative_entry_label")
        if narrative_entry_label:
            # Override was configured — was it applied or did it fall back?
            if _resolved_label == narrative_entry_label:
                _entry_resolution_status = "override_applied"
            elif _resolved_label is not None:
                _entry_resolution_status = "override_not_found_fallback"
            else:
                _entry_resolution_status = "override_not_found_no_entry"
        else:
            # Auto-detection path
            if _resolved_label:
                _entry_resolution_status = "auto_detected"
            else:
                _entry_resolution_status = "not_resolved"
        narrative_summary["entry_override_requested"] = narrative_entry_label or None
        narrative_summary["entry_resolution_status"] = _entry_resolution_status

        # Detect high variance and type issues
        warnings = {
            "highVariance": [],
            "typeInconsistencies": [],
            "potentiallyUnused": [],
        }

        for var_name, stats in aggregates.items():
            # High variance detection (use correct attribute names)
            if stats.stddev_value and stats.mean_value:
                if stats.stddev_value > max(10, stats.mean_value * 0.25):
                    warnings["highVariance"].append(var_name)

        print(
            f"[PILOT] Warnings: {len(warnings['highVariance'])} high variance variables"
        )

        # Step 5: Export to JSON
        print("[PILOT] Step 5/5: Exporting report...")
        output_dir = project_root / ".branchpy" / output_dir_name
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = output_dir / "stats2.json"

        # Build metadata (include enumerated paths count even if no variables)
        metadata = {
            "paths_enumerated": len(
                paths
            ),  # Total paths found, not just ones with variables
            "cfg_nodes": node_count,
            "cfg_edges": edge_count,
        }

        # Export using Stats2Exporter
        exporter = Stats2Exporter(project_root=project_root)  # type: ignore
        duration_ms = int((time.time() - start_time) * 1000)

        # PILOT: Build complete path_analyses dict with ALL paths
        # Include paths even if they have no variable mutations detected
        path_analyses_complete = {}
        for path_id, label_path in paths.items():
            # Use existing timeline if available, otherwise empty dict
            path_analyses_complete[tuple(label_path)] = timelines.get(path_id, {})

        payload = exporter.export(
            aggregates=aggregates,
            path_analyses=path_analyses_complete,
            analysis_duration_ms=duration_ms,
            path_analyzer=analyzer,  # PILOT: Pass analyzer for state change export
        )

        # Add metadata and warnings to payload
        # Build PILOT multi-entry summary fields
        pilot_entry_labels: List[str] = sorted(set(entry_source_map.values()))
        pilot_entry_summary: Dict[str, dict] = {}
        for pid, entry_label in entry_source_map.items():
            pilot_entry_summary.setdefault(entry_label, {"path_count": 0})
            pilot_entry_summary[entry_label]["path_count"] += 1

        payload.setdefault("summary", {}).update(
            {
                "paths_enumerated": metadata["paths_enumerated"],
                "cfg_nodes": metadata["cfg_nodes"],
                "cfg_edges": metadata["cfg_edges"],
                "max_paths": max_paths,
                "paths_capped": len(paths) >= max_paths,
                # Multi-entry PILOT fields (Phase 3a)
                "pilot_entry_labels": pilot_entry_labels,
                "pilot_entry_summary": pilot_entry_summary,
                # Narrative Paths metrics (spec §8)
                **narrative_summary,
            }
        )
        payload["warnings"] = warnings
        # Internal-only per-path attribution (Class C — excluded from thin payload)
        payload["pilot_entry_source_map"] = entry_source_map

        # Legacy format compatibility: add "version" alias for "schema_version"
        if "schema_version" in payload and "version" not in payload:
            payload["version"] = payload["schema_version"]

        # Legacy format: wrap metadata in "meta" for old tests
        if "project" in payload or "generated_at" in payload:
            payload.setdefault("meta", {})
            if "project" in payload:
                payload["meta"]["projectName"] = payload.get("project")
            if "generated_at" in payload:
                payload["meta"]["generatedAt"] = payload.get("generated_at")
            if "summary" in payload:
                if "total_paths" in payload["summary"]:
                    payload["meta"]["pathCount"] = payload["summary"]["total_paths"]
                if "total_variables" in payload["summary"]:
                    payload["meta"]["variableCount"] = payload["summary"][
                        "total_variables"
                    ]

        # Write JSON with retry logic for Windows file locking.
        # Two-file output contract (§3.3 SOP):
        #   - stats2.json            → Class B thin public output (summary + warnings)
        #   - .internal/stats2_full.json → Class C full payload for VS Code panel / daemon
        import time as time_module

        internal_dir = output_dir / ".internal"
        internal_dir.mkdir(parents=True, exist_ok=True)
        internal_path = internal_dir / "stats2_full.json"

        thin_payload = Stats2Exporter.build_thin_payload(payload)  # type: ignore

        max_retries = 3
        for dest, data in [
            (internal_path, payload),  # full payload → internal
            (output_path, thin_payload),  # thin payload → public
        ]:
            for attempt in range(max_retries):
                try:
                    with open(dest, "w", encoding="utf-8") as f:
                        json.dump(data, f, indent=2, ensure_ascii=False)
                    break
                except PermissionError:
                    if attempt < max_retries - 1:
                        time_module.sleep(0.1)
                        continue
                    else:
                        raise

        # Phase 5: Embed source_revision + run identity for freshness model
        try:
            from branchpy.artifact_freshness import patch_artifact_metadata
            from branchpy.run_context import RunContext

            _ctx = getattr(args, "_run_ctx", None)
            if _ctx is None:
                from branchpy.artifact_freshness import get_source_revision

                _ctx = RunContext.start(
                    project_root, get_source_revision(project_root)
                ).complete()
            patch_artifact_metadata(output_path, project_root, "pilot", run_ctx=_ctx)
        except Exception:
            pass  # non-fatal; freshness metadata is best-effort

        # (M-08) Write timestamped history snapshot alongside the stable latest.
        # Snapshot name: pilot-{YYYYMMDD_HHMMSS}.json in the same directory.
        # Snapshots use the thin payload (same Class B schema as stats2.json) so they
        # don't accumulate engine internals over time.
        # Consumers must use the latest pointer (stats2.json) for current data;
        # snapshots are for history/compare only.
        try:
            _snap_ts = time.strftime("%Y%m%d_%H%M%S")
            _snap_path = output_dir / f"pilot-{_snap_ts}.json"
            _snap_path.write_text(
                json.dumps(thin_payload, indent=2, ensure_ascii=False), encoding="utf-8"
            )
        except Exception:
            pass  # non-fatal; latest file was already written successfully

        duration_ms = int((time.time() - start_time) * 1000)
        print(f"[PILOT] Report saved to: {output_path}")
        print(f"[PILOT] Analysis complete ({duration_ms}ms)")

        # Print summary — narrative block first, execution second
        print("\n" + "=" * 60)
        print("PILOT Summary")
        print("=" * 60)
        # Narrative Paths block
        np_est = narrative_summary.get("narrative_paths_estimate")
        np_conf = narrative_summary.get("narrative_confidence", "not_computed")
        np_entry = narrative_summary.get("narrative_entry_label")
        if np_conf != "not_computed" and np_est is not None:
            prefix = "~" if np_conf in ("medium", "low") else ""
            np_display = np_est if isinstance(np_est, str) else f"{prefix}{np_est}"
            np_topo = narrative_summary.get("narrative_topology", "")
            topo_ctx = ""
            if np_topo and np_topo != "not_computed":
                np_out = narrative_summary.get("narrative_outcomes_estimate")
                if np_topo == "linear_variant":
                    topo_ctx = "  (Linear story with branching scene variations)"
                elif np_topo == "hub_loop":
                    segs = (
                        f", {np_out} reachable segments" if np_out is not None else ""
                    )
                    topo_ctx = f"  (Loop-based structure{segs})"
                elif np_topo == "branching":
                    routes = f", {np_out} distinct routes" if np_out is not None else ""
                    topo_ctx = f"  (Branching story{routes})"
                # linear: no extra context
            print(f"Narrative Paths:    {np_display}  ({np_conf} confidence){topo_ctx}")
            if np_entry:
                print(f"Narrative Entry:    {np_entry}")
        else:
            print("Narrative Paths:    — (not computed)")
        notes = narrative_summary.get("narrative_notes", [])
        for note in notes:
            print(f"  Note: {note}")
        print("-" * 60)
        # Execution Paths block
        print(
            f"Execution Paths:    {len(paths)}{'+' if len(paths) >= max_paths else ''}"
        )
        print(f"Variables tracked:  {var_count}")
        print(
            f"Stat variables:     {payload.get('summary', {}).get('stat_variables', 0)}"
        )
        print(f"High-variance vars: {len(warnings['highVariance'])}")
        print(f"Type inconsistencies: {len(warnings['typeInconsistencies'])}")
        print(f"\nReport: {output_path}")
        print("=" * 60)

        # v0.7.29: Policy evaluation
        policy_mode = getattr(args, "policy_mode", "off")
        policy_json_path = getattr(args, "policy_json", "")

        if policy_mode != "off":
            from pathlib import Path as PolicyPath

            from branchpy.policy.eval import evaluate as eval_policy

            policy_json = PolicyPath(policy_json_path) if policy_json_path else None
            policy_result = eval_policy(payload, policy_json)

            if policy_result.fail_count > 0 or policy_result.warning_count > 0:
                print(
                    f"\n[Policy] {policy_result.fail_count} violations, {policy_result.warning_count} warnings"
                )
                for violation in policy_result.violations + policy_result.warnings:
                    print(
                        f"  [{violation.severity.upper()}] {violation.rule_id}: {violation.message}"
                    )

            if policy_mode == "strict" and policy_result.fail_count > 0:
                print(
                    f"\n[Policy] STRICT mode: Exiting with code 1 due to {policy_result.fail_count} policy violations"
                )
                return 1

        # --html / --open: generate standalone HTML report
        if getattr(args, "html", False) or getattr(args, "open_after", False):
            try:
                from branchpy.cli.html_report import (
                    announce_html_report,
                    generate_pilot_html,
                )
                from branchpy.cli.html_report import open_in_browser as _open_browser
                from branchpy.cli.html_report import resolve_html_output_path

                html_path = generate_pilot_html(
                    payload,
                    project_root,
                    resolve_html_output_path(project_root, "pilot", None),
                )
                announce_html_report("pilot", html_path)
                if getattr(args, "open_after", False):
                    _open_browser(html_path)
            except Exception as _html_err:
                print(
                    f"[bpy] Warning: HTML report generation failed: {_html_err}",
                    file=sys.stderr,
                )

        return 0

    except Exception as e:
        print(f"[PILOT] ERROR: {e}")
        import traceback

        traceback.print_exc()
        log.error(f"Stats2 failed: {e}")
        return 1


def register_command(subparsers) -> None:
    """Register both 'pilot' and 'stats2' commands with argument parser."""
    description = """
Analyze variable behavior across execution paths with variance detection,
type consistency checking, and per-path timelines.

This command generates a PILOT report showing how variables change
along different story paths, highlighting potential issues like high
variance (imbalanced stats) and type inconsistencies.
    """

    epilog = """
Examples:
  branchpy pilot
  branchpy --project mygame pilot
  branchpy pilot --max-paths 1000 --max-depth 150
  branchpy pilot --output-dir my-pilot-report
  branchpy stats2 (legacy alias for pilot)
  branchpy --project mygame stats2
    """

    # Register both 'pilot' and 'stats2' as command names
    for cmd_name in ["pilot", "stats2"]:
        parser = subparsers.add_parser(
            cmd_name,
            help="Path-aware variable analysis (PILOT)",
            description=description,
        )

        parser.add_argument(
            "--max-paths",
            type=int,
            default=500,
            metavar="N",
            help="Maximum number of paths to analyze (default: 500)",
        )

        parser.add_argument(
            "--max-depth",
            type=int,
            default=100,
            metavar="N",
            help="Maximum path depth in nodes (default: 100)",
        )

        parser.add_argument(
            "--output-dir",
            type=str,
            default="stats2",
            metavar="DIR",
            help="Output directory name under .branchpy/ (default: stats2)",
        )

        # Policy enforcement (v0.7.29)
        parser.add_argument(
            "--policy-mode",
            choices=["off", "warn", "strict"],
            default="off",
            help="Policy enforcement mode (off=disabled, warn=log only, strict=exit on violations)",
        )

        parser.add_argument(
            "--policy-json",
            type=str,
            default="",
            metavar="FILE",
            help="Path to policy JSON file with custom rules and severities",
        )

        parser.add_argument(
            "--open",
            dest="open_after",
            action="store_true",
            help="Open the PILOT report after generation (handled by the VS Code extension).",
        )

        parser.add_argument(
            "--narrative-entry-label",
            type=str,
            default="",
            metavar="LABEL",
            dest="narrative_entry_label",
            help=(
                "Override the narrative entry label used for Narrative Paths analysis. "
                "Use when your project has no 'start' label or multiple story roots "
                "(e.g. --narrative-entry-label compare_start)."
            ),
        )

        parser.add_argument(
            "--entry-labels",
            type=str,
            default="",
            metavar="LABELS",
            dest="entry_labels",
            help=argparse.SUPPRESS,  # Phase 3a — internal/extension-facing, not in public help
        )

        parser.add_argument(
            "--html",
            action="store_true",
            help="Generate a standalone HTML report artifact (saved to .branchpy/reports/).",
        )

        parser.set_defaults(handler=run)
        parser.epilog = epilog


def add_parser(subparsers) -> None:
    """Alternative registration method for backward compatibility."""
    register_command(subparsers)
