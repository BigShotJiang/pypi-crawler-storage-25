"""
Story Graph Data Structures
Phase 5: Story Structure & Completeness Validation

Provides graph representation of Ren'Py story flow for narrative analysis.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set


class NodeType(Enum):
    """Types of nodes in the story graph"""

    LABEL = "label"
    MENU = "menu"
    CHOICE = "choice"
    CONDITIONAL = "conditional"
    TERMINAL = "terminal"


class EdgeType(Enum):
    """Types of edges in the story graph"""

    JUMP = "jump"
    CALL = "call"
    RETURN = "return"
    CHOICE = "choice"
    CONDITIONAL = "conditional"
    IMPLICIT = "implicit"  # Fall-through to next label
    # D17b: dynamic dispatch (call/jump expression <expr>)
    DYNAMIC_CALL = "dynamic_call"   # call expression — target resolved or unresolved
    DYNAMIC_JUMP = "dynamic_jump"   # jump expression — target resolved or unresolved
    # D18: while loop branch directions
    LOOP_TRUE = "while_true"    # while body entered (condition was true)
    LOOP_FALSE = "while_false"  # while loop exited / skipped (condition was false)
    # D19: screen action families
    SCREEN_JUMP = "screen_jump"      # Jump("label") in a screen block — literal target
    SCREEN_CALL = "screen_call"      # Call("label") in a screen block — literal target
    SCREEN_RETURN = "screen_return"  # Return() in a screen block — to_label="?" (runtime)
    # D20: Python literal transfer families
    PYTHON_JUMP = "python_jump"      # renpy.jump("label") in $ / python: — literal target
    PYTHON_CALL = "python_call"      # renpy.call("label") in $ / python: — literal target
    PYTHON_RETURN = "python_return"  # renpy.return_statement() in $ / python: — to_label="?"
    # D22: Engine lifecycle entry families
    ENTRY_POINT = "entry_point"      # implicit ENGINE -> lifecycle label (start/splashscreen/after_load)
    # D23: Creator-defined custom transfer (provable literal target)
    CUSTOM_TRANSFER = "custom_transfer"  # custom helper e.g. go_to("dest") in python: block


class LabelType(Enum):
    """Types of labels for flowchart classification and filtering"""

    NARRATIVE = "narrative"  # Story content: dialogue, menus, show/hide
    ROUTING = "routing"  # Logic/passthrough: conditionals, state checks
    SYSTEM = "system"  # Engine/GUI/screens
    ENTRY = "entry"  # Story entry points (start, main menu)
    EXIT = "exit"  # Terminal nodes (return, end)
    UNKNOWN = "unknown"  # Unclassified or ambiguous
    IMPLICIT = "implicit"  # Fall-through to next label


@dataclass
class Location:
    """Source code location"""

    file: str
    line: int
    column: int = 0


@dataclass
class LabelNode:
    """Represents a Ren'Py label in the story graph"""

    name: str
    location: Location
    node_type: NodeType = NodeType.LABEL

    # Content analysis
    has_dialogue: bool = False
    has_menu: bool = False
    has_return: bool = False
    has_jump: bool = False
    has_call: bool = False

    # Variable tracking (from Phase 3)
    modifies_variables: Set[str] = field(default_factory=set)
    reads_variables: Set[str] = field(default_factory=set)

    # Save point tracking
    has_save_point: bool = False
    save_point_type: Optional[str] = None  # 'explicit' or 'implicit_menu'

    # Label classification for flowchart filtering (Phase 1+2 v1.0)
    label_type: "LabelType" = None  # type: ignore
    has_python_block: bool = False
    has_conditional: bool = False
    has_show_hide: bool = False

    # Metadata
    line_count: int = 0
    content_hash: Optional[str] = None

    def __hash__(self):
        return hash(self.name)

    def __eq__(self, other):
        return isinstance(other, LabelNode) and self.name == other.name


@dataclass
class MenuNode:
    """Represents a menu (choice point) in the story"""

    menu_id: str
    label: str  # Label containing this menu
    location: Location

    # Menu metadata
    prompt: Optional[str] = None  # Menu question/prompt text
    choices: List["ChoiceOption"] = field(default_factory=list)

    # Analysis flags
    is_false_choice: bool = False  # All choices lead to same destination
    impact_score: float = 0.0  # 0.0 to 1.0

    def __hash__(self):
        return hash(self.menu_id)


@dataclass
class ChoiceOption:
    """Individual option within a menu"""

    choice_id: str
    text: str
    destination: Optional[str] = None  # Target label (if jump)

    # Variable effects
    modifies_variables: Set[str] = field(default_factory=set)
    variable_changes: Dict[str, Any] = field(default_factory=dict)

    # Conditional choice
    condition: Optional[str] = None  # if clause for choice availability

    # Impact analysis
    leads_to_unique_path: bool = False
    affects_ending: bool = False


@dataclass
class Transition:
    """Edge in the story graph representing control flow"""

    from_label: str
    to_label: str
    edge_type: EdgeType

    # Conditional transitions
    condition: Optional[str] = None
    is_conditional: bool = False

    # D17a: branch direction for EdgeType.CONDITIONAL edges
    # "true"  → the if/elif branch (condition was satisfied)
    # "false" → the else/elif-false branch (condition was not satisfied)
    # None    → non-conditional edge or direction unknown
    condition_branch: Optional[str] = None

    # D17b: original expression for EdgeType.DYNAMIC_CALL / DYNAMIC_JUMP edges.
    # Populated whether or not the target was resolved.
    # When to_label == "?" the expression was not statically resolvable.
    dynamic_expr: Optional[str] = None

    # Menu-related
    menu_id: Optional[str] = None
    choice_id: Optional[str] = None

    # Metadata
    location: Optional[Location] = None

    def __hash__(self):
        return hash((self.from_label, self.to_label, self.edge_type))


@dataclass
class SavePoint:
    """Detected save point in the story"""

    label: str
    location: Location
    save_type: str  # 'explicit', 'implicit_menu', 'checkpoint'

    # Context
    nearby_content: Optional[str] = None
    in_animation: bool = False  # Poor placement flag
    in_choice_block: bool = False  # Poor placement flag


@dataclass
class SaveGap:
    """Sequence of labels without save points"""

    start_label: str
    end_label: str
    label_sequence: List[str] = field(default_factory=list)
    label_count: int = 0
    severity: str = "warning"


@dataclass
class ChoiceImpact:
    """Analysis results for a menu's impact"""

    menu_id: str

    # Impact dimensions
    variable_impact: bool = False
    path_divergence: bool = False
    ending_impact: Dict[str, Set[str]] = field(
        default_factory=dict
    )  # choice_id -> reachable endings

    # Modified variables across all choices
    modified_vars: Set[str] = field(default_factory=set)

    # Overall impact score (0.0 to 1.0)
    score: float = 0.0

    # Classification
    is_trivial: bool = False
    is_high_impact: bool = False


class StoryGraph:
    """
    Complete graph representation of story structure.

    Nodes: Labels, menus, conditionals
    Edges: Jumps, calls, returns, choices
    """

    def __init__(self):
        # Core graph data
        self.nodes: Dict[str, LabelNode] = {}
        self.menus: Dict[str, MenuNode] = {}
        self.edges: List[Transition] = []

        # Adjacency structures for efficient traversal
        self._successors: Dict[str, List[str]] = {}
        self._predecessors: Dict[str, List[str]] = {}

        # Save points
        self.save_points: List[SavePoint] = []

        # D21: Hotspot diagnostics (unresolved / static-limit constructs)
        self.hotspot_diagnostics: List[HotspotDiagnostic] = []

        # Analysis results (cached)
        self._reachable_cache: Optional[Set[str]] = None
        self._terminal_labels_cache: Optional[Set[str]] = None

    def add_label(self, label: LabelNode) -> None:
        """Add a label node to the graph"""
        self.nodes[label.name] = label
        if label.name not in self._successors:
            self._successors[label.name] = []
        if label.name not in self._predecessors:
            self._predecessors[label.name] = []

    def add_menu(self, menu: MenuNode) -> None:
        """Add a menu node to the graph"""
        self.menus[menu.menu_id] = menu

        # Mark containing label as having a menu
        if menu.label in self.nodes:
            self.nodes[menu.label].has_menu = True
            self.nodes[menu.label].has_save_point = True
            self.nodes[menu.label].save_point_type = "implicit_menu"

    def add_transition(self, transition: Transition) -> None:
        """Add an edge to the graph"""
        self.edges.append(transition)

        # Update adjacency lists
        if transition.from_label not in self._successors:
            self._successors[transition.from_label] = []
        if transition.to_label not in self._predecessors:
            self._predecessors[transition.to_label] = []

        self._successors[transition.from_label].append(transition.to_label)
        self._predecessors[transition.to_label].append(transition.from_label)

        # Invalidate caches
        self._reachable_cache = None

    def get_successors(self, label: str) -> List[str]:
        """Get all labels reachable from the given label"""
        return self._successors.get(label, [])

    def get_predecessors(self, label: str) -> List[str]:
        """Get all labels that can reach the given label"""
        return self._predecessors.get(label, [])

    def get_outgoing_edges(self, label: str) -> List[Transition]:
        """Get all transitions originating from a label"""
        return [e for e in self.edges if e.from_label == label]

    def get_incoming_edges(self, label: str) -> List[Transition]:
        """Get all transitions leading to a label"""
        return [e for e in self.edges if e.to_label == label]

    def has_label(self, label: str) -> bool:
        """Check if label exists in graph"""
        return label in self.nodes

    def add_hotspot_diagnostic(self, diagnostic: "HotspotDiagnostic") -> None:
        """D21: Append a hotspot diagnostic record."""
        self.hotspot_diagnostics.append(diagnostic)

    def get_label(self, label: str) -> Optional[LabelNode]:
        """Get label node by name"""
        return self.nodes.get(label)

    def get_menu(self, menu_id: str) -> Optional[MenuNode]:
        """Get menu by ID"""
        return self.menus.get(menu_id)

    def add_save_point(self, save_point: SavePoint) -> None:
        """Register a save point"""
        self.save_points.append(save_point)

        # Mark the label
        if save_point.label in self.nodes:
            self.nodes[save_point.label].has_save_point = True
            self.nodes[save_point.label].save_point_type = save_point.save_type

    def get_all_labels(self) -> Set[str]:
        """Get set of all label names"""
        return set(self.nodes.keys())

    def get_terminal_labels(self) -> Set[str]:
        """Get labels that are terminal (endings)"""
        if self._terminal_labels_cache is not None:
            return self._terminal_labels_cache

        terminals = set()

        for label, node in self.nodes.items():
            # Heuristic 1: Name contains ending keywords
            if any(
                term in label.lower()
                for term in ["end", "ending", "finale", "conclusion"]
            ):
                terminals.add(label)

            # Heuristic 2: Has return and no outgoing edges
            # BUT: Exclude subroutines (labels with incoming RETURN edges)
            elif node.has_return and len(self.get_successors(label)) == 0:
                # Check if this label has incoming RETURN edges (i.e., it's called)
                incoming_edges = self.get_incoming_edges(label)
                has_return_callers = any(
                    e.edge_type == EdgeType.RETURN for e in incoming_edges
                )

                # Only mark as terminal if it's NOT a subroutine
                if not has_return_callers:
                    terminals.add(label)

        self._terminal_labels_cache = terminals
        return terminals

    def clear_caches(self) -> None:
        """Clear all cached analysis results"""
        self._reachable_cache = None
        self._terminal_labels_cache = None

    def get_stats(self) -> Dict[str, Any]:
        """Get graph statistics"""
        return {
            "total_labels": len(self.nodes),
            "total_transitions": len(self.edges),
            "total_menus": len(self.menus),
            "total_save_points": len(self.save_points),
            "terminal_labels": len(self.get_terminal_labels()),
            "edge_types": self._count_edge_types(),
        }

    def _count_edge_types(self) -> Dict[str, int]:
        """Count edges by type"""
        counts = {}
        for edge in self.edges:
            edge_type = edge.edge_type.value
            counts[edge_type] = counts.get(edge_type, 0) + 1
        return counts

    def to_dict(self) -> Dict[str, Any]:
        """Export graph to dictionary (for JSON serialization)"""
        return {
            "nodes": [
                {
                    "name": node.name,
                    "type": node.node_type.value,
                    "location": {
                        "file": node.location.file,
                        "line": node.location.line,
                    },
                    "has_dialogue": node.has_dialogue,
                    "has_menu": node.has_menu,
                    "has_save_point": node.has_save_point,
                    "modifies_variables": list(node.modifies_variables),
                    "reads_variables": list(node.reads_variables),
                }
                for node in self.nodes.values()
            ],
            "edges": [
                {
                    "from": edge.from_label,
                    "to": edge.to_label,
                    "type": edge.edge_type.value,
                    "conditional": edge.is_conditional,
                    "condition": edge.condition,
                }
                for edge in self.edges
            ],
            "menus": [
                {
                    "id": menu.menu_id,
                    "label": menu.label,
                    "location": {
                        "file": menu.location.file,
                        "line": menu.location.line,
                    },
                    "choices": len(menu.choices),
                    "impact_score": menu.impact_score,
                    "is_false_choice": menu.is_false_choice,
                }
                for menu in self.menus.values()
            ],
            "stats": self.get_stats(),
        }


@dataclass
class StoryArc:
    """Represents a narrative arc (sequence of related labels)"""

    arc_name: str
    start_label: str
    expected_end_labels: List[str] = field(default_factory=list)

    # Arc metadata
    labels_in_arc: Set[str] = field(default_factory=set)
    is_complete: bool = False
    missing_endings: List[str] = field(default_factory=list)

    # Analysis
    reachable_endings: Set[str] = field(default_factory=set)


@dataclass
class ReachabilityResult:
    """Results of reachability analysis"""

    reachable_labels: Set[str] = field(default_factory=set)
    unreachable_labels: Set[str] = field(default_factory=set)

    # Dead ends (reachable but no exit)
    dead_end_labels: Set[str] = field(default_factory=set)

    # Orphaned content
    orphaned_labels: Set[str] = field(default_factory=set)

    # Coverage metrics
    coverage_percentage: float = 0.0
    total_labels: int = 0

    # Circular loops
    circular_loops: List[List[str]] = field(default_factory=list)


@dataclass
class CompletenessResult:
    """Results of story completeness analysis"""

    total_arcs: int = 0
    complete_arcs: int = 0
    incomplete_arcs: List[StoryArc] = field(default_factory=list)

    # Missing elements
    missing_endings: List[str] = field(default_factory=list)
    unfinished_branches: List[str] = field(default_factory=list)
    missing_transitions: List[tuple] = field(
        default_factory=list
    )  # (from_label, expected_to)

    # Terminal labels
    terminal_labels: Set[str] = field(default_factory=set)
    unreachable_terminals: Set[str] = field(default_factory=set)


@dataclass
class ChoiceAnalysisResult:
    """Results of choice impact analysis"""

    total_choices: int = 0
    impactful_choices: int = 0
    trivial_choices: int = 0
    impact_percentage: float = 0.0

    # Detailed analysis
    choice_impacts: Dict[str, ChoiceImpact] = field(default_factory=dict)
    false_choices: List[str] = field(default_factory=list)  # menu IDs
    high_impact_choices: List[str] = field(default_factory=list)  # menu IDs


@dataclass
class SavePointAnalysisResult:
    """Results of save point analysis"""

    total_save_points: int = 0
    explicit_saves: int = 0
    implicit_saves: int = 0

    # Issues
    save_gaps: List[SaveGap] = field(default_factory=list)
    poor_placements: List[SavePoint] = field(default_factory=list)


@dataclass
class StoryAnalysisResult:
    """Complete Phase 5 analysis results"""

    graph: StoryGraph

    # Analysis results
    reachability: ReachabilityResult
    completeness: CompletenessResult
    choice_analysis: ChoiceAnalysisResult
    save_analysis: SavePointAnalysisResult

    # Diagnostics (to be generated)
    diagnostics: List["Diagnostic"] = field(default_factory=list)

    # Metadata
    analysis_version: str = "1.0.0"
    timestamp: Optional[str] = None


@dataclass
class Diagnostic:
    """Story structure diagnostic message"""

    rule_id: str
    severity: str  # 'error', 'warning', 'info'
    message: str

    # Location
    file: str
    line: int
    column: int = 0

    # Details
    details: Dict[str, Any] = field(default_factory=dict)
    fix_suggestions: List[str] = field(default_factory=list)

    # Category
    category: str = "story_structure"  # For filtering in UI


class DiagnosticCategory:
    """D21: Category constants for HotspotDiagnostic records."""

    PYTHON_INDIRECT_TRANSFER = "python_indirect_transfer"
    """$ renpy.jump(var) / renpy.call(expr) — non-literal Python transfer."""

    UNRESOLVED_DYNAMIC_JUMP = "unresolved_dynamic_jump"
    """jump expression <complex-expr> — not resolvable by D17b's simple-var path."""

    UNRESOLVED_DYNAMIC_CALL = "unresolved_dynamic_call"
    """call expression <complex-expr> — not resolvable by D17b's simple-var path."""

    SCREEN_INDIRECT_TARGET = "screen_indirect_target"
    """Jump(var) / Call(expr) inside a screen block — non-literal target."""

    CUSTOM_STATEMENT_TRANSFER_CANDIDATE = "custom_statement_transfer_candidate"
    """Python block with an unknown method call that looks like a transfer."""

    PYTHON_RETURN_UNRESOLVED = "python_return_unresolved"
    """renpy.return_statement() — edge to '?' is emitted, diagnostic annotates it."""


@dataclass
class HotspotDiagnostic:
    """D21: A control-flow construct the static analyzer detected but cannot resolve.

    The analyzer either:
    - emitted NO edge (categories A, C, D) — destination is unknowable statically
    - emitted an edge to '?' AND this diagnostic (categories B, E) — the edge
      exists but its target is runtime-dependent

    Fields
    ------
    category    : DiagnosticCategory constant
    from_label  : label in which the construct appears
    location    : file path + line number
    reason      : human-readable explanation for the diagnostic
    edge_emitted: True when a parallel edge (to '?') also exists in the graph
    edge_kind   : the EdgeType value-string of that parallel edge, if any
    """

    category: str
    from_label: str
    location: "Location"
    reason: str
    edge_emitted: bool = False
    edge_kind: Optional[str] = None


# ============================================================================
# Label Classification
# ============================================================================


def classify_label(label: LabelNode, is_system_file: bool = False) -> LabelType:
    """
    Classify a label into one of the flowchart types.

    Classification rules:
    1. SYSTEM: Labels in system files (screens.rpy, gui.rpy, etc.)
    2. ENTRY: Known entry points (start, splashscreen) or root labels
    3. EXIT: Terminal labels (only return/no outgoing edges)
    4. NARRATIVE: Has dialogue, menus, or show/hide operations
    5. ROUTING: Python blocks, conditionals, mostly control flow
    6. UNKNOWN: Fallback

    Args:
        label: LabelNode to classify
        is_system_file: True if label is in screens.rpy, gui.rpy, etc.

    Returns:
        LabelType enum value
    """
    # System files (GUI, screens, etc.)
    if is_system_file:
        return LabelType.SYSTEM

    # Entry points - known starting labels
    entry_labels = {"start", "splashscreen", "main_menu", "before_main_menu"}
    if label.name in entry_labels or label.name.startswith("start_"):
        return LabelType.ENTRY

    # Exit points - terminal labels (only returns, no outgoing flow)
    # Check if label has return but no jump/call
    # IMPORTANT: Don't classify subroutines as EXIT - they have RETURN edges pointing TO them
    # NOTE: This function doesn't have access to edges, so this check is limited.
    # The caller should use get_terminal_labels() for accurate terminal detection.
    if label.has_return and not label.has_jump and not label.has_call:
        return LabelType.EXIT

    # Narrative - has story content
    narrative_indicators = (
        label.has_dialogue  # Has say statements
        or label.has_menu  # Has menu choices
        or label.has_show_hide  # Has show/hide/scene operations
    )

    if narrative_indicators:
        return LabelType.NARRATIVE

    # Routing - logic/passthrough labels
    # Has Python blocks or conditionals, minimal narrative content
    routing_indicators = (
        label.has_python_block
        or label.has_conditional
        or (label.has_jump or label.has_call)  # Pure control flow
    )

    # If it has any routing indicators and no narrative, it's routing
    if routing_indicators and not narrative_indicators:
        return LabelType.ROUTING

    # Fallback - if we can't classify, mark as routing (safe default)
    # Most unclassified labels in MAS are routing/delegation labels
    return LabelType.ROUTING


def get_label_type_stats(graph: StoryGraph) -> Dict[str, int]:
    """
    Get count of labels by type for logging/debugging.

    Args:
        graph: StoryGraph with classified labels

    Returns:
        Dict mapping label type to count
    """
    stats = {
        LabelType.NARRATIVE.value: 0,
        LabelType.ROUTING.value: 0,
        LabelType.SYSTEM.value: 0,
        LabelType.ENTRY.value: 0,
        LabelType.EXIT.value: 0,
        LabelType.UNKNOWN.value: 0,
    }

    for label in graph.nodes.values():
        if label.label_type:
            stats[label.label_type.value] += 1

    return stats


# Export key classes for easier imports
__all__ = [
    "StoryGraph",
    "LabelNode",
    "MenuNode",
    "ChoiceOption",
    "Transition",
    "SavePoint",
    "SaveGap",
    "ChoiceImpact",
    "StoryArc",
    "NodeType",
    "EdgeType",
    "LabelType",
    "Location",
    "ReachabilityResult",
    "CompletenessResult",
    "ChoiceAnalysisResult",
    "SavePointAnalysisResult",
    "StoryAnalysisResult",
    "Diagnostic",
    "DiagnosticCategory",
    "HotspotDiagnostic",
    "classify_label",
    "get_label_type_stats",
]
