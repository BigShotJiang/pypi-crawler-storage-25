# branchpy/config_store.py
from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass
from typing import Dict, Optional

from branchpy import logs

APP_DIRNAME = ".branchpy"
CONFIG_FILENAME = "config.json"
LOG_DIRNAME = "logs"


def _user_data_dir() -> str:
    # Cross‑platform per‑user data dir (~/.branchpy or %LOCALAPPDATA%\BranchPy)
    if os.name == "nt":
        root = os.getenv("LOCALAPPDATA") or os.path.expanduser("~")
        return os.path.join(root, "BranchPy")
    return os.path.join(os.path.expanduser("~"), APP_DIRNAME)


def ensure_dirs() -> dict:
    base = _user_data_dir()
    os.makedirs(base, exist_ok=True)
    logs = os.path.join(base, LOG_DIRNAME)
    os.makedirs(logs, exist_ok=True)
    return {"base": base, "logs": logs}


@dataclass
class UpdateCfg:
    channel: str = "stable"
    last_check: Optional[str] = None  # ISO string or None
    check_interval_days: int = 7
    auto_apply: bool = False


@dataclass
class TelemetryCfg:
    enabled: bool = False


@dataclass
class LogsCfg:
    """Logging configuration for BranchPy v0.7.21+"""

    level: str = "INFO"  # TRACE, DEBUG, INFO, WARN, ERROR, FATAL
    maxFileMB: int = 10  # Max file size before rotation
    rotation_count: int = 5  # Number of rotated files to keep
    redaction: str = "standard"  # standard | strict | off
    debugWindowMinutes: int = 20  # Auto-downshift after this many minutes
    includeVSCodeInBundle: bool = True  # Include VS Code logs in support bundles
    ringBufferSize: int = 5000  # In-memory event buffer size


from collections.abc import MutableMapping


class AppCfg(MutableMapping):
    def __init__(
        self,
        update: Optional[UpdateCfg] = None,
        telemetry: Optional[TelemetryCfg] = None,
        logs: Optional[LogsCfg] = None,
        projects: Optional[Dict[str, str]] = None,
        default_project: Optional[str] = None,
        **kwargs,
    ):
        self._update = update if update is not None else UpdateCfg()
        self._telemetry = telemetry if telemetry is not None else TelemetryCfg()
        self._logs = logs if logs is not None else LogsCfg()
        self._projects = dict(projects or {})
        self._default_project = default_project
        self._data = dict(
            update=self._update,
            telemetry=self._telemetry,
            logs=self._logs,
            projects=self._projects,
            default_project=self._default_project,
        )
        self._data.update(kwargs)

    @property
    def update_cfg(self) -> UpdateCfg:
        # Defensive: ensure correct type
        if isinstance(self._update, UpdateCfg):
            return self._update
        # fallback: try to reconstruct
        if isinstance(self._update, dict):
            try:
                d = dict(self._update)
                # Build a new dict with correct types
                out = {}
                for k, v in d.items():
                    if k == "check_interval_days":
                        try:
                            out[k] = int(v)
                        except Exception:
                            out[k] = 7
                    elif k == "auto_apply":
                        if isinstance(v, bool):
                            out[k] = v
                        elif isinstance(v, str):
                            out[k] = v.lower() in ("1", "true", "yes", "on")
                        else:
                            out[k] = False
                    else:
                        out[k] = v
                return UpdateCfg(**out)
            except Exception:
                return UpdateCfg()
        return UpdateCfg()

    @update_cfg.setter
    def update_cfg(self, value: UpdateCfg):
        self._update = value
        self._data["update"] = value

    @property
    def telemetry(self) -> TelemetryCfg:
        if isinstance(self._telemetry, TelemetryCfg):
            return self._telemetry
        if isinstance(self._telemetry, dict):
            try:
                return TelemetryCfg(**self._telemetry)
            except Exception:
                return TelemetryCfg()
        return TelemetryCfg()

    @telemetry.setter
    def telemetry(self, value: TelemetryCfg):
        self._telemetry = value
        self._data["telemetry"] = value

    @property
    def logs(self) -> LogsCfg:
        if isinstance(self._logs, LogsCfg):
            return self._logs
        if isinstance(self._logs, dict):
            try:
                return LogsCfg(**self._logs)
            except Exception:
                return LogsCfg()
        return LogsCfg()

    @logs.setter
    def logs(self, value: LogsCfg):
        self._logs = value
        self._data["logs"] = value

    def __getitem__(self, key):
        return self._data[key]

    def __setitem__(self, key, value):
        self._data[key] = value
        if key == "update":
            self._update = value
        elif key == "telemetry":
            self._telemetry = value
        elif key == "logs":
            self._logs = value
        elif key == "projects":
            self._projects = dict(value or {})
        elif key == "default_project":
            self._default_project = value

    def __delitem__(self, key):
        del self._data[key]

    def __iter__(self):
        return iter(self._data)

    def __len__(self):
        return len(self._data)

    def clear(self):
        self._data.clear()
        self._update = UpdateCfg()
        self._telemetry = TelemetryCfg()
        self._logs = LogsCfg()
        self._projects = {}
        self._default_project = None
        self._data["update"] = self._update
        self._data["telemetry"] = self._telemetry
        self._data["logs"] = self._logs
        self._data["projects"] = self._projects
        self._data["default_project"] = self._default_project

    def update_dict(self, *args, **kwargs):
        self._data.update(*args, **kwargs)
        if "update" in self._data:
            self._update = self._data["update"]
        if "telemetry" in self._data:
            self._telemetry = self._data["telemetry"]
        if "logs" in self._data:
            self._logs = self._data["logs"]
        if "projects" in self._data:
            projs = self._data["projects"]
            if isinstance(projs, dict):
                self._projects = dict(projs)
            else:
                self._projects = {}
        if "default_project" in self._data:
            self._default_project = self._data["default_project"]

    @staticmethod
    def default() -> "AppCfg":
        return AppCfg(projects={}, default_project=None)

    # --- Project registry convenience ---
    @property
    def projects(self) -> Dict[str, str]:
        return self._projects

    @property
    def default_project(self) -> Optional[str]:
        return self._default_project

    def set_project(self, name: str, path: str) -> None:
        self._projects[name] = path
        self._data["projects"] = self._projects

    def remove_project(self, name: str) -> bool:
        if name in self._projects:
            del self._projects[name]
            if self._default_project == name:
                self._default_project = None
            self._data["projects"] = self._projects
            self._data["default_project"] = self._default_project
            return True
        return False

    def rename_project(self, old: str, new: str) -> bool:
        if old in self._projects and new not in self._projects:
            self._projects[new] = self._projects.pop(old)
            if self._default_project == old:
                self._default_project = new
            self._data["projects"] = self._projects
            self._data["default_project"] = self._default_project
            return True
        return False

    def set_default_project(self, name: Optional[str]) -> None:
        self._default_project = name
        self._data["default_project"] = self._default_project


class ConfigStore:
    def __init__(self) -> None:
        paths = ensure_dirs()
        self.base_dir = paths["base"]
        self.log_dir = paths["logs"]
        self.config_path = os.path.join(self.base_dir, CONFIG_FILENAME)
        self._cfg = AppCfg.default()
        self.load()

    @property
    def logs_path(self) -> str:
        return self.log_dir

    @property
    def path(self) -> str:
        return self.config_path

    @property
    def cfg(self) -> AppCfg:
        return self._cfg

    def load(self) -> None:
        if not os.path.exists(self.config_path):
            self.save()
            return
        try:
            with open(self.config_path, "r", encoding="utf-8") as f:

                raw = json.load(f)
            upd = raw.get("update", {})
            tel = raw.get("telemetry", {})
            log_cfg = raw.get("logs", {})
            projs = raw.get("projects", {})
            default_proj = raw.get("default_project", None)
            self._cfg = AppCfg(
                update=UpdateCfg(**{**asdict(UpdateCfg()), **upd}),
                telemetry=TelemetryCfg(**{**asdict(TelemetryCfg()), **tel}),
                logs=LogsCfg(**{**asdict(LogsCfg()), **log_cfg}),
                projects=projs or {},
                default_project=default_proj,
            )
        except Exception as e:
            # On corruption, rewrite defaults but keep a backup and escalate to FATAL for ops visibility
            try:
                os.replace(self.config_path, self.config_path + ".bak")
                backup_path = self.config_path + ".bak"
            except Exception as bak_err:
                backup_path = None
                logs.error(
                    "config_store.backup_failed",
                    "Failed to backup corrupt config",
                    error=str(bak_err),
                )
            self._cfg = AppCfg.default()
            self.save()
            logs.fatal(
                "config_store.corrupt_config",
                "Configuration file corrupted; defaults restored",
                error=str(e),
                backup=backup_path,
                path=self.config_path,
            )

    def save(self) -> None:
        data = {
            "update": asdict(self._cfg.update_cfg),
            "telemetry": asdict(self._cfg.telemetry),
            "logs": asdict(self._cfg.logs),
            "projects": dict(self._cfg.projects),
            "default_project": self._cfg.default_project,
        }
        with open(self.config_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
