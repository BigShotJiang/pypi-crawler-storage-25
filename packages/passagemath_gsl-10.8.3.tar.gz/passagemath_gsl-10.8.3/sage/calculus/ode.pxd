# sage_setup: distribution = sagemath-gsl
cdef class ode_system:
    cdef int  c_j(self, double , const double *, double *, double *) noexcept

    cdef int c_f(self, double t, const double* , double*) noexcept
