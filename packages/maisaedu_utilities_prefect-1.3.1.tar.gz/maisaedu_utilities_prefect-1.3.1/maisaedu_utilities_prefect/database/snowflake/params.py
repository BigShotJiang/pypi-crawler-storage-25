from pydantic import BaseModel

from maisaedu_utilities_prefect.constants.env import LOCAL, DEV, HLG, PROD

_DATABASE_BY_ENV = {
    LOCAL: "MAIS_A_DEV",
    DEV: "MAIS_A_DEV",
    HLG: "MAIS_A_HLG",
    PROD: "MAIS_A_PROD",
}


def get_database(env: str) -> str:
    """Return the Snowflake database name for the given environment.

    local | dev  -> MAIS_A_DEV
    hlg          -> MAIS_A_HLG
    prod         -> MAIS_A_PROD
    """
    database = _DATABASE_BY_ENV.get(env)
    if database is None:
        raise ValueError(f"No Snowflake database mapped for env '{env}'. Expected one of: {list(_DATABASE_BY_ENV)}")
    return database


class SnowflakeParams(BaseModel):
    env: str = PROD
    role: str | None = None
    user: str | None = None
    warehouse: str | None = None
    database: str | None = None
