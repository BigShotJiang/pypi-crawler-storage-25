import base64
import os

from .params import SnowflakeParams, PROD, get_database
from .service import SnowflakeService

SNOWFLAKE_ACCOUNT = "A6020211027671-MAISA"
SNOWFLAKE_USER_PROD = "PREFECT_PROD"
SNOWFLAKE_USER_DEV = "PREFECT_DEV"


_DATA_DIRS = [
    os.path.join(os.getcwd(), "data"),                # same resolution as dw.py (relative to CWD)
    "/data",                                          # prod container
    "/app/data",                                      # local docker (project mounted at /app)
    os.path.join(os.path.dirname(__file__), "data"),  # direct local dev (pip install -e .)
]


def _get_private_key_path(env: str) -> str:
    filename = "dw-snowflake-prefect-prod.text" if env == PROD else "dw-snowflake-prefect-dev.text"
    for data_dir in _DATA_DIRS:
        path = os.path.join(data_dir, filename)
        if os.path.exists(path):
            return path
    return os.path.join(_DATA_DIRS[-1], filename)


def _load_private_key_bytes(env: str) -> bytes:
    path = _get_private_key_path(env)
    if not os.path.exists(path):
        tried = ", ".join(f"'{d}'" for d in _DATA_DIRS)
        raise FileNotFoundError(
            f"Snowflake private key not found. Tried directories: {tried}. "
            "Place the key file in one of these locations."
        )
    with open(path) as f:
        return base64.b64decode(f.read().strip())


def _resolve_user(env: str, user: str | None) -> str:
    if user is not None:
        return user
    return SNOWFLAKE_USER_PROD if env == PROD else SNOWFLAKE_USER_DEV


def build_snowflake_service(params: SnowflakeParams) -> SnowflakeService:
    database = params.database or get_database(params.env)
    return SnowflakeService(
        account=SNOWFLAKE_ACCOUNT,
        user=_resolve_user(params.env, params.user),
        private_key_bytes=_load_private_key_bytes(params.env),
        role=params.role,
        warehouse=params.warehouse,
        database=database,
    )
