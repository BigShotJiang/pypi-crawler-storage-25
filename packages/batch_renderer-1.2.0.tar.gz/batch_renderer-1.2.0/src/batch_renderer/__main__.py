"""Entry point for batch renderer."""

from .cli import main

if __name__ == "__main__":
    main()
