"""Image rendering using Poe API."""

import base64
import hashlib
import re
import time
from pathlib import Path
from typing import Optional, Tuple
import openai
from rich.console import Console
import structlog

from .config import Config
from .patterns import Prompt
from .error_parser import ErrorParser, ErrorCategory
from .model_registry import get_registry

console = Console()


class RenderResult:
    """Result of a render operation."""

    def __init__(
        self,
        prompt: Prompt,
        success: bool,
        output_path: Optional[Path] = None,
        error: Optional[str] = None,
        is_text: bool = False,
        tokens: int = 0,
        duration_seconds: float = 0.0,
        retries: int = 0,
    ):
        self.prompt = prompt
        self.success = success
        self.output_path = output_path
        self.error = error
        self.is_text = is_text
        self.tokens = tokens
        self.duration_seconds = duration_seconds
        self.retries = retries


class Renderer:
    """Handles image rendering via Poe API."""

    def __init__(
        self,
        config: Config,
        logger: Optional[structlog.BoundLogger] = None,
        tracker: Optional[object] = None,
    ):
        """
        Initialize renderer.

        Args:
            config: Configuration object
            logger: Structured logger instance (optional)
            tracker: TokenTracker instance (optional)
        """
        self.config = config
        self.logger = logger or structlog.get_logger("batch_renderer.renderer")
        self.tracker = tracker

        # Track safety rejections for reporting
        self.safety_rejections = []

        if not config.api_key:
            raise ValueError(
                "POE_API_KEY not found. Please set it in .env or pass via --api-key"
            )

        self.client = openai.OpenAI(
            api_key=config.api_key,
            base_url="https://api.poe.com/v1",
        )

        # Initialize error parser with model registry for intelligent suggestions
        try:
            model_registry = get_registry(api_key=config.api_key, logger=self.logger)
            model_registry.load()  # Pre-load registry
            self.error_parser = ErrorParser(logger=self.logger, model_registry=model_registry)
        except Exception as e:
            # If registry fails, create parser without it
            self.logger.warning("Failed to load model registry for error parser", error=str(e))
            self.error_parser = ErrorParser(logger=self.logger)

    def render(self, prompt: Prompt, retry_count: Optional[int] = None) -> RenderResult:
        """
        Render a single prompt to an image.

        Args:
            prompt: The prompt to render
            retry_count: Number of retries on failure (default: 3, or from metadata)

        Returns:
            RenderResult object
        """
        # Track timing
        start_time = time.time()

        # Standard metadata keys
        STANDARD_KEYS = {"model", "format", "skip", "retries"}

        # Check if prompt should be skipped
        if prompt.metadata.get("skip", "").lower() == "true":
            console.print(f"  [yellow]⊘[/yellow]  {prompt.id}: Skipped (skip=true in metadata)")
            self.logger.info("prompt_skipped",
                prompt_id=prompt.id,
                title=prompt.title,
            )
            return RenderResult(
                prompt=prompt,
                success=True,
                output_path=None,
            )

        # Validate metadata based on validation mode
        self._validate_metadata(prompt, STANDARD_KEYS)

        # Determine model with precedence: hard-coded < env < inline metadata < CLI
        if self.config.cli_model:
            model = self.config.cli_model
        elif "model" in prompt.metadata:
            model = prompt.metadata["model"]
        else:
            model = self.config.model

        # Determine retry count: default < metadata < parameter
        if retry_count is None:
            retry_count = int(prompt.metadata.get("retries", 3))

        # Build extra_body from metadata (excluding standard keys)
        extra_body = {}
        for key, value in prompt.metadata.items():
            if key not in STANDARD_KEYS:
                # Try to convert to appropriate type
                if value.lower() in ("true", "false"):
                    extra_body[key] = value.lower() == "true"
                elif value.isdigit():
                    extra_body[key] = int(value)
                else:
                    extra_body[key] = value

        # Attempt render with retries
        last_error = None
        total_retries = 0

        for attempt in range(retry_count):
            try:
                # Log API call
                self.logger.debug("api_request_start",
                    prompt_id=prompt.id,
                    model=model,
                    attempt=attempt + 1,
                    max_retries=retry_count,
                    extra_body=extra_body if extra_body else {},
                )

                response = self.client.chat.completions.create(
                    model=model,
                    messages=[{"role": "user", "content": prompt.prompt}],
                    extra_body=extra_body if extra_body else None,
                    stream=False,  # Recommended for image generation
                )

                content = response.choices[0].message.content

                # Extract tokens from response
                tokens = getattr(response.usage, 'total_tokens', 0) if hasattr(response, 'usage') else 0

                # Calculate duration
                duration = time.time() - start_time

                # Log successful API call
                self.logger.info("api_request_success",
                    prompt_id=prompt.id,
                    model=model,
                    tokens=tokens,
                    duration_seconds=round(duration, 2),
                    retries=total_retries,
                )

                # Process the response
                result = self._process_response(prompt, content, model, tokens, duration, total_retries)

                # Track in TokenTracker if available
                if self.tracker:
                    file_size = result.output_path.stat().st_size if result.output_path and result.output_path.exists() else None
                    self.tracker.track(
                        prompt_id=prompt.id,
                        model=model,
                        tokens=tokens,
                        success=result.success,
                        duration_seconds=duration,
                        file_size_bytes=file_size,
                        retries=total_retries,
                    )

                return result

            except Exception as e:
                last_error = str(e)
                total_retries += 1

                # Parse error for intelligent handling
                error_info = self.error_parser.parse_error(
                    e,
                    model_id=model,
                    prompt_id=prompt.id
                )

                # Log with error category and recovery hint
                self.logger.warning("api_request_failed",
                    prompt_id=prompt.id,
                    model=model,
                    attempt=attempt + 1,
                    error=last_error,
                    error_category=error_info.category.value,
                    is_recoverable=error_info.is_recoverable(),
                    recovery_hint=error_info.get_recovery_hint(),
                    suggested_models=error_info.suggested_models,
                )

                # Try aspect ratio auto-fix if enabled and this is an aspect ratio validation error
                if (error_info.category == ErrorCategory.VALIDATION
                    and error_info.valid_aspect_ratios
                    and self.config.aspect_fix_mode != "none"
                    and attempt < retry_count - 1):

                    # Determine which aspect ratio parameter to use
                    aspect_param = None
                    if "aspect" in extra_body:
                        aspect_param = "aspect"
                    elif "aspect_ratio" in extra_body:
                        aspect_param = "aspect_ratio"

                    if aspect_param:
                        original_aspect = extra_body[aspect_param]
                        fixed_aspect = None

                        if self.config.aspect_fix_mode == "auto":
                            # Use "auto" to let model decide
                            fixed_aspect = "auto"
                            self.logger.warning("aspect_ratio_auto_fix",
                                prompt_id=prompt.id,
                                model=model,
                                original_aspect=original_aspect,
                                fixed_aspect=fixed_aspect,
                                fix_mode="auto",
                                valid_aspects=error_info.valid_aspect_ratios,
                            )

                        elif self.config.aspect_fix_mode == "calculated":
                            # Calculate closest valid aspect ratio
                            fixed_aspect = self.error_parser.model_registry.calculate_closest_aspect_ratio(
                                model, original_aspect
                            )
                            self.logger.warning("aspect_ratio_auto_fix",
                                prompt_id=prompt.id,
                                model=model,
                                original_aspect=original_aspect,
                                fixed_aspect=fixed_aspect,
                                fix_mode="calculated",
                                valid_aspects=error_info.valid_aspect_ratios,
                            )

                        if fixed_aspect:
                            # Apply the fix
                            extra_body[aspect_param] = fixed_aspect
                            console.print(
                                f"[yellow]Auto-fixing aspect ratio: {original_aspect} → {fixed_aspect}[/yellow]"
                            )
                            continue  # Retry with fixed aspect ratio

                # Try model auto-fallback if model not found
                if (error_info.category == ErrorCategory.MODEL_NOT_FOUND
                    and error_info.suggested_models
                    and attempt < retry_count - 1):

                    fallback_model = error_info.suggested_models[0]
                    console.print(
                        f"[yellow]Model '{model}' not found. Auto-fallback to '{fallback_model}'[/yellow]"
                    )
                    self.logger.warning("model_auto_fallback",
                        prompt_id=prompt.id,
                        original_model=model,
                        fallback_model=fallback_model,
                        suggested_models=error_info.suggested_models,
                    )

                    # Update model for subsequent attempts
                    model = fallback_model
                    continue  # Retry with fallback model

                if attempt < retry_count - 1:
                    # Show error with recovery hint if available
                    hint = error_info.get_recovery_hint()
                    if hint:
                        console.print(
                            f"[yellow]Attempt {attempt + 1} failed: {error_info.message}[/yellow]"
                        )
                        console.print(f"[dim]Hint: {hint}[/dim]")
                    else:
                        console.print(
                            f"[yellow]Attempt {attempt + 1} failed: {last_error}. Retrying...[/yellow]"
                        )
                continue

        # All retries failed - parse final error for insights
        duration = time.time() - start_time

        # Parse the final error
        final_error_info = self.error_parser.parse_error(
            Exception(last_error),
            model_id=model,
            prompt_id=prompt.id
        )

        self.logger.error("render_failed",
            prompt_id=prompt.id,
            model=model,
            error=last_error,
            error_category=final_error_info.category.value,
            is_recoverable=final_error_info.is_recoverable(),
            recovery_hint=final_error_info.get_recovery_hint(),
            suggested_models=final_error_info.suggested_models,
            retries=total_retries,
            duration_seconds=round(duration, 2),
        )

        # Track failure if tracker available
        if self.tracker:
            self.tracker.track(
                prompt_id=prompt.id,
                model=model,
                tokens=0,
                success=False,
                duration_seconds=duration,
                retries=total_retries,
            )

        # Log failed prompt to redo.jsonl
        self._log_failed_prompt(prompt, model, final_error_info, last_error)

        # Track safety rejections separately
        if final_error_info.category == ErrorCategory.SAFETY:
            self._track_safety_rejection(prompt, model, final_error_info, last_error)

        # Enhance error message with recovery hint
        enhanced_error = last_error
        hint = final_error_info.get_recovery_hint()
        if hint:
            enhanced_error = f"{last_error}\n[Hint: {hint}]"

        return RenderResult(
            prompt=prompt,
            success=False,
            error=enhanced_error,
            tokens=0,
            duration_seconds=duration,
            retries=total_retries,
        )

    def _validate_metadata(self, prompt: Prompt, standard_keys: set):
        """
        Validate metadata based on validation mode.

        Args:
            prompt: The prompt with metadata to validate
            standard_keys: Set of known standard keys
        """
        if self.config.validation_mode == "lenient":
            # Just warnings for everything
            return

        for key, value in prompt.metadata.items():
            is_standard = key in standard_keys

            # Validate standard keys more strictly
            if is_standard:
                if key == "skip" and value.lower() not in ("true", "false"):
                    msg = f"Metadata '{key}' should be 'true' or 'false', got '{value}'"
                    if self.config.validation_mode == "strict":
                        raise ValueError(f"{prompt.id}: {msg}")
                    console.print(f"[yellow]Warning[/yellow] {prompt.id}: {msg}")

                elif key == "retries" and not value.isdigit():
                    msg = f"Metadata '{key}' should be a number, got '{value}'"
                    if self.config.validation_mode == "strict":
                        raise ValueError(f"{prompt.id}: {msg}")
                    console.print(f"[yellow]Warning[/yellow] {prompt.id}: {msg}")
            else:
                # Custom keys - just log in hybrid mode if suspicious
                if self.config.validation_mode == "hybrid":
                    # Could add checks for common typos, etc.
                    pass

    def _process_response(
        self,
        prompt: Prompt,
        content: str,
        model: str,
        tokens: int,
        duration: float,
        retries: int
    ) -> RenderResult:
        """
        Process API response and save the result.

        Args:
            prompt: The original prompt
            content: Response content from API
            model: Model used for generation
            tokens: Tokens used
            duration: Duration in seconds
            retries: Number of retries

        Returns:
            RenderResult object
        """
        # Check if response contains an image URL
        url_match = re.search(r'https?://[^\s\)]+\.(?:png|jpg|jpeg|gif|webp)', content)

        # Check if response is markdown image
        md_image_match = re.search(r'!\[.*?\]\((https?://[^\s\)]+)\)', content)

        if md_image_match:
            image_url = md_image_match.group(1)
            return self._download_and_save_image(prompt, image_url, tokens, duration, retries)
        elif url_match:
            image_url = url_match.group(0)
            return self._download_and_save_image(prompt, image_url, tokens, duration, retries)
        elif content.startswith("data:image/"):
            # Base64 encoded image
            return self._save_base64_image(prompt, content, tokens, duration, retries)
        else:
            # Response is text, not an image
            return self._save_text_response(prompt, content, tokens, duration, retries)

    def _download_and_save_image(
        self,
        prompt: Prompt,
        url: str,
        tokens: int,
        duration: float,
        retries: int
    ) -> RenderResult:
        """Download image from URL and save it."""
        import requests

        try:
            response = requests.get(url, timeout=30)
            response.raise_for_status()
            image_data = response.content

            # Save the image
            output_path = self._get_output_path(prompt)
            output_path.write_bytes(image_data)

            # Cache if enabled
            if self.config.cache_images:
                self._cache_image(prompt, image_data)

            return RenderResult(
                prompt=prompt,
                success=True,
                output_path=output_path,
                tokens=tokens,
                duration_seconds=duration,
                retries=retries,
            )

        except Exception as e:
            return RenderResult(
                prompt=prompt,
                success=False,
                error=f"Failed to download image: {e}",
                tokens=tokens,
                duration_seconds=duration,
                retries=retries,
            )

    def _save_base64_image(
        self,
        prompt: Prompt,
        data_url: str,
        tokens: int,
        duration: float,
        retries: int
    ) -> RenderResult:
        """Save base64-encoded image."""
        try:
            # Extract base64 data
            match = re.match(r'data:image/[^;]+;base64,(.+)', data_url)
            if not match:
                raise ValueError("Invalid base64 image data")

            image_data = base64.b64decode(match.group(1))

            # Save the image
            output_path = self._get_output_path(prompt)
            output_path.write_bytes(image_data)

            # Cache if enabled
            if self.config.cache_images:
                self._cache_image(prompt, image_data)

            return RenderResult(
                prompt=prompt,
                success=True,
                output_path=output_path,
                tokens=tokens,
                duration_seconds=duration,
                retries=retries,
            )

        except Exception as e:
            return RenderResult(
                prompt=prompt,
                success=False,
                error=f"Failed to save base64 image: {e}",
                tokens=tokens,
                duration_seconds=duration,
                retries=retries,
            )

    def _save_text_response(
        self,
        prompt: Prompt,
        text: str,
        tokens: int,
        duration: float,
        retries: int
    ) -> RenderResult:
        """Save text response when model doesn't return an image."""
        output_path = self._get_output_path(prompt, extension="txt")
        output_path.write_text(text, encoding="utf-8")

        console.print(
            f"[yellow]Warning: Model returned text instead of image for '{prompt.title}'[/yellow]"
        )

        return RenderResult(
            prompt=prompt,
            success=True,
            output_path=output_path,
            is_text=True,
            tokens=tokens,
            duration_seconds=duration,
            retries=retries,
        )

    def _cache_image(self, prompt: Prompt, image_data: bytes):
        """Cache image data to log folder."""
        if not self.config.cache_dir:
            return

        # Generate cache filename from prompt hash
        prompt_hash = hashlib.md5(prompt.prompt.encode()).hexdigest()[:12]
        cache_path = self.config.cache_dir / f"{prompt.id}_{prompt_hash}.{self.config.image_format}"

        cache_path.write_bytes(image_data)

    def _get_output_path(self, prompt: Prompt, extension: Optional[str] = None) -> Path:
        """
        Get the output path for a prompt.

        Args:
            prompt: The prompt object
            extension: File extension (default: from config)

        Returns:
            Path object for the output file
        """
        ext = extension or self.config.image_format

        # Generate filename
        from .patterns import slugify
        filename = f"concept-{prompt.id}-{slugify(prompt.title)}.{ext}"

        if self.config.flatten:
            # Flat structure
            output_path = self.config.output_dir / filename
        else:
            # Nested structure with section folders
            if prompt.section:
                section_slug = slugify(prompt.section)
                section_dir = self.config.output_dir / f"{prompt.id.split('.')[0]}-{section_slug}"
                section_dir.mkdir(parents=True, exist_ok=True)
                output_path = section_dir / filename
            else:
                output_path = self.config.output_dir / filename

        return output_path

    def _log_failed_prompt(
        self,
        prompt: Prompt,
        model: str,
        error_info,
        error_message: str
    ):
        """Log failed prompt to redo.jsonl for replay.

        Args:
            prompt: The prompt that failed
            model: The model that was being used
            error_info: ErrorInfo object with parsed error details
            error_message: The error message string
        """
        import json
        from pathlib import Path

        redo_log = Path("logs/redo.jsonl")
        redo_log.parent.mkdir(parents=True, exist_ok=True)

        # Build replay entry with all necessary details
        entry = {
            "prompt_id": prompt.id,
            "source_file": prompt.source_file,
            "source_line": prompt.source_line,
            "section": prompt.section,
            "title": prompt.title,
            "prompt": prompt.prompt,
            "metadata": prompt.metadata,
            "model": model,
            "error_category": error_info.category.value,
            "error_message": error_message,
            "recovery_hint": error_info.get_recovery_hint(),
            "suggested_models": error_info.suggested_models,
            "valid_aspect_ratios": error_info.valid_aspect_ratios,
        }

        # Append to redo log
        with redo_log.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")

        self.logger.debug("failed_prompt_logged",
            prompt_id=prompt.id,
            redo_log=str(redo_log)
        )

    def _track_safety_rejection(
        self,
        prompt: Prompt,
        model: str,
        error_info,
        error_message: str
    ):
        """Track a safety rejection for reporting.

        Args:
            prompt: The prompt that was rejected
            model: The model that rejected it
            error_info: ErrorInfo object with parsed error details
            error_message: The error message string
        """
        rejection = {
            "prompt_id": prompt.id,
            "source_file": prompt.source_file,
            "source_line": prompt.source_line,
            "title": prompt.title,
            "prompt": prompt.prompt,
            "model": model,
            "error_message": error_message,
        }
        self.safety_rejections.append(rejection)

        # Also log to separate file
        import json
        from pathlib import Path

        safety_log = Path("logs/safety-rejections.jsonl")
        safety_log.parent.mkdir(parents=True, exist_ok=True)

        with safety_log.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rejection) + "\n")

        self.logger.info("safety_rejection_tracked",
            prompt_id=prompt.id,
            model=model
        )

    def get_safety_rejections(self) -> list:
        """Get list of safety rejections.

        Returns:
            List of safety rejection dictionaries
        """
        return self.safety_rejections

    def generate_safety_report(self, output_dir: Path) -> Optional[Path]:
        """Generate human-readable safety rejection report.

        Args:
            output_dir: Directory to save the report

        Returns:
            Path to the report file, or None if no rejections
        """
        if not self.safety_rejections:
            return None

        from datetime import datetime

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_path = output_dir / f"safety-rejections-{timestamp}.md"

        with report_path.open("w", encoding="utf-8") as f:
            f.write("# Safety Rejection Report\n\n")
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            f.write(f"Total rejections: {len(self.safety_rejections)}\n\n")
            f.write("---\n\n")

            for i, rejection in enumerate(self.safety_rejections, 1):
                f.write(f"## Rejection {i}: {rejection['title']}\n\n")
                f.write(f"**Prompt ID:** {rejection['prompt_id']}\n\n")

                if rejection['source_file'] and rejection['source_line']:
                    f.write(f"**Source:** {rejection['source_file']}:{rejection['source_line']}\n\n")

                f.write(f"**Model:** {rejection['model']}\n\n")
                f.write(f"**Error:** {rejection['error_message']}\n\n")
                f.write(f"**Prompt Text:**\n\n")
                f.write(f"> {rejection['prompt']}\n\n")
                f.write("---\n\n")

        self.logger.info("safety_report_generated",
            report_path=str(report_path),
            rejection_count=len(self.safety_rejections)
        )

        return report_path
