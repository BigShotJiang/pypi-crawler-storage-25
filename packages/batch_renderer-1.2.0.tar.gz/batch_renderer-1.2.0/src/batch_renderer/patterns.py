"""Configurable pattern dictionaries for prompt extraction."""

import re
from typing import Dict, List, NamedTuple, Optional


class Prompt(NamedTuple):
    """Extracted prompt information."""
    id: str
    section: str
    title: str
    prompt: str
    metadata: Dict[str, str]
    source_file: Optional[str] = None
    source_line: Optional[int] = None


class PatternConfig(NamedTuple):
    """Configuration for a prompt extraction pattern."""
    name: str
    description: str
    heading_pattern: str
    section_pattern: str = None


# Built-in pattern dictionaries
PATTERNS = {
    "concept": PatternConfig(
        name="concept",
        description="Extract 'Concept X.Y: Title' style prompts",
        heading_pattern=r"^### Concept (\d+)\.(\d+): (.+)",
        section_pattern=r"^## (\d+)\. (.+)"
    ),
    "numbered": PatternConfig(
        name="numbered",
        description="Extract '### X.Y Title' style prompts",
        heading_pattern=r"^### (\d+)\.(\d+) (.+)",
        section_pattern=r"^## (\d+)\. (.+)"
    ),
    "simple": PatternConfig(
        name="simple",
        description="Extract all level-3 headings as prompts",
        heading_pattern=r"^### (.+)",
        section_pattern=r"^## (.+)"
    ),
}


def _calculate_line_number(text: str, position: int) -> int:
    """Calculate line number from character position in text."""
    return text[:position].count('\n') + 1


def extract_prompts(
    markdown_text: str,
    pattern_name: str = "concept",
    source_file: Optional[str] = None,
    ignore_undefined_tags: bool = False
) -> List[Prompt]:
    """
    Extract prompts from markdown text using the specified pattern.

    This function processes TAG LIBRARY sections first, resolves all tag
    definitions, and substitutes [TAG_NAME] references before extracting prompts.

    Args:
        markdown_text: The markdown content to parse
        pattern_name: Name of the pattern to use (from PATTERNS dict)
        source_file: Optional source filename for clickable file:line references
        ignore_undefined_tags: If True, continue with warnings for undefined tags

    Returns:
        List of extracted Prompt objects

    Raises:
        UndefinedTagError: If undefined tags found and ignore_undefined_tags=False
        CircularDependencyError: If circular tag dependencies detected
    """
    if pattern_name not in PATTERNS:
        raise ValueError(
            f"Unknown pattern '{pattern_name}'. "
            f"Available: {', '.join(PATTERNS.keys())}"
        )

    # Process tag substitution first (ADR-0006)
    from .tag_substitution import process_markdown_with_tags, UndefinedTagError, CircularDependencyError

    try:
        markdown_text, resolved_tags = process_markdown_with_tags(
            markdown_text,
            ignore_undefined=ignore_undefined_tags
        )

        # Log tag library info if tags were found
        if resolved_tags:
            import structlog
            logger = structlog.get_logger("batch_renderer.patterns")
            logger.info("tag_library_loaded",
                tag_count=len(resolved_tags),
                tags=list(resolved_tags.keys())
            )

    except (UndefinedTagError, CircularDependencyError) as e:
        # Re-raise with source file context if available
        if source_file:
            raise type(e)(f"In file {source_file}: {str(e)}") from e
        raise

    pattern_config = PATTERNS[pattern_name]
    prompts = []

    # Split into sections if we have a section pattern
    sections = []
    if pattern_config.section_pattern:
        section_matches = list(re.finditer(
            pattern_config.section_pattern,
            markdown_text,
            re.MULTILINE
        ))

        for i, match in enumerate(section_matches):
            section_start = match.end()
            section_end = (
                section_matches[i + 1].start()
                if i + 1 < len(section_matches)
                else len(markdown_text)
            )
            section_title = match.group(match.lastindex)
            sections.append({
                'title': section_title,
                'text': markdown_text[section_start:section_end],
                'offset': section_start  # Track offset in original text
            })
    else:
        sections = [{'title': '', 'text': markdown_text, 'offset': 0}]

    # Extract prompts from each section
    for section in sections:
        section_text = section['text']
        section_title = section['title']
        section_offset = section['offset']

        # Find all heading matches
        heading_matches = list(re.finditer(
            pattern_config.heading_pattern,
            section_text,
            re.MULTILINE
        ))

        for i, match in enumerate(heading_matches):
            # Extract the prompt text (paragraph following the heading)
            prompt_start = match.end()
            prompt_end = (
                heading_matches[i + 1].start()
                if i + 1 < len(heading_matches)
                else len(section_text)
            )

            # Get the text after the heading
            prompt_block = section_text[prompt_start:prompt_end].strip()

            # Parse metadata (bullet points with key: value OR HTML comments)
            metadata = {}
            prompt_text_lines = []
            in_metadata = True

            for line in prompt_block.split('\n'):
                line = line.strip()
                if not line:
                    continue

                # Check if it's a metadata line in bullet format (- key: value)
                if in_metadata and line.startswith('-'):
                    metadata_match = re.match(r'^-\s*([^:]+):\s*(.+)$', line)
                    if metadata_match:
                        key = metadata_match.group(1).strip()
                        value = metadata_match.group(2).strip()
                        metadata[key] = value
                        continue

                # Check if it's a metadata line in HTML comment format (<!-- key: value -->)
                if in_metadata and line.startswith('<!--') and line.endswith('-->'):
                    comment_content = line[4:-3].strip()  # Remove <!-- and -->
                    metadata_match = re.match(r'^([^:]+):\s*(.+)$', comment_content)
                    if metadata_match:
                        key = metadata_match.group(1).strip()
                        value = metadata_match.group(2).strip()
                        metadata[key] = value
                        continue

                # Once we hit non-metadata, all subsequent lines are prompt text
                in_metadata = False
                prompt_text_lines.append(line)

            prompt_text = ' '.join(prompt_text_lines)

            # Extract ID and title based on pattern
            if pattern_name == "concept":
                major = match.group(1)
                minor = match.group(2)
                title = match.group(3).strip()
                prompt_id = f"{major}.{minor}"
            elif pattern_name == "numbered":
                major = match.group(1)
                minor = match.group(2)
                title = match.group(3).strip()
                prompt_id = f"{major}.{minor}"
            else:  # simple
                title = match.group(1).strip()
                prompt_id = str(i + 1)

            # Calculate line number in original file
            absolute_position = section_offset + match.start()
            line_number = _calculate_line_number(markdown_text, absolute_position) if source_file else None

            prompts.append(Prompt(
                id=prompt_id,
                section=section_title,
                title=title,
                prompt=prompt_text,
                metadata=metadata,
                source_file=source_file,
                source_line=line_number
            ))

    return prompts


class PatternDetectionResult(NamedTuple):
    """Result from pattern auto-detection."""
    pattern_name: str
    prompts: List[Prompt]
    score: float
    prompt_count: int
    with_metadata: int
    all_results: Dict[str, dict]


def auto_detect_pattern(
    markdown_text: str,
    source_file: Optional[str] = None,
    ignore_undefined_tags: bool = False
) -> PatternDetectionResult:
    """
    Try all available patterns and return the one with highest score.

    Score = prompt_count + (prompts_with_metadata * 0.5)

    Higher weight for prompts with complete metadata (aspect, quality, etc.)
    suggests more intentional formatting.

    Args:
        markdown_text: The markdown content to parse
        source_file: Optional source filename for clickable file:line references
        ignore_undefined_tags: If True, continue with warnings for undefined tags

    Returns:
        PatternDetectionResult with best pattern and all results

    Raises:
        ValueError: If no prompts found with any pattern
    """
    results = {}

    for pattern_name in PATTERNS.keys():
        try:
            prompts = extract_prompts(
                markdown_text,
                pattern_name=pattern_name,
                source_file=source_file,
                ignore_undefined_tags=ignore_undefined_tags
            )

            # Count prompts with metadata
            with_metadata = sum(1 for p in prompts if p.metadata)

            results[pattern_name] = {
                'count': len(prompts),
                'with_metadata': with_metadata,
                'score': len(prompts) + (with_metadata * 0.5),
                'prompts': prompts
            }
        except Exception as e:
            results[pattern_name] = {
                'count': 0,
                'with_metadata': 0,
                'score': 0,
                'error': str(e),
                'prompts': []
            }

    # Pick highest scoring pattern
    # If tied, prefer: concept > numbered > simple (most to least structured)
    pattern_priority = {'concept': 3, 'numbered': 2, 'simple': 1}

    best_pattern = max(
        results.keys(),
        key=lambda p: (results[p]['score'], pattern_priority.get(p, 0))
    )
    best_result = results[best_pattern]

    if best_result['count'] == 0:
        raise ValueError(
            f"No prompts found with any pattern. Tried: {list(results.keys())}"
        )

    return PatternDetectionResult(
        pattern_name=best_pattern,
        prompts=best_result['prompts'],
        score=best_result['score'],
        prompt_count=best_result['count'],
        with_metadata=best_result['with_metadata'],
        all_results=results
    )


def slugify(text: str) -> str:
    """Convert text to a URL-friendly slug."""
    # Convert to lowercase
    text = text.lower()
    # Replace spaces and underscores with hyphens
    text = re.sub(r'[\s_]+', '-', text)
    # Remove non-alphanumeric characters except hyphens
    text = re.sub(r'[^a-z0-9-]', '', text)
    # Remove duplicate hyphens
    text = re.sub(r'-+', '-', text)
    # Strip hyphens from ends
    text = text.strip('-')
    return text
