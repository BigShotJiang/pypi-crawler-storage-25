"""Error parsing and categorization for intelligent error recovery."""

import re
from dataclasses import dataclass
from enum import Enum
from typing import Optional, List, Dict, Any, TYPE_CHECKING
import structlog

if TYPE_CHECKING:
    from .model_registry import ModelRegistry


class ErrorCategory(Enum):
    """Categories of errors that can occur during rendering."""

    VALIDATION = "validation"           # Invalid parameters (aspect ratio, quality, etc.)
    SAFETY = "safety"                   # Content policy violation
    MODEL_NOT_FOUND = "model_not_found" # Model doesn't exist or no access
    RATE_LIMIT = "rate_limit"           # API rate limiting
    SERVER_ERROR = "server_error"       # Server-side errors (5xx)
    AUTHENTICATION = "authentication"   # Invalid API key
    UNKNOWN = "unknown"                 # Unparsable or unexpected errors


@dataclass
class ErrorInfo:
    """Parsed information about an error."""

    category: ErrorCategory
    original_error: str
    error_code: Optional[str] = None
    error_type: Optional[str] = None
    message: Optional[str] = None

    # Actionable information extracted from error
    valid_aspect_ratios: Optional[List[str]] = None
    suggested_models: Optional[List[str]] = None
    retry_after_seconds: Optional[int] = None

    # Request context
    request_id: Optional[str] = None
    model_id: Optional[str] = None

    def is_recoverable(self) -> bool:
        """Check if this error is potentially recoverable."""
        return self.category in (
            ErrorCategory.VALIDATION,
            ErrorCategory.MODEL_NOT_FOUND,
            ErrorCategory.RATE_LIMIT,
        )

    def get_recovery_hint(self) -> Optional[str]:
        """Get a human-readable hint for recovering from this error."""
        if self.category == ErrorCategory.MODEL_NOT_FOUND:
            if self.suggested_models:
                models = ", ".join(self.suggested_models[:3])
                return f"Model not found. Try one of these instead: {models}"
            return "Model not found. Use --list-models to see available models"

        elif self.category == ErrorCategory.VALIDATION:
            if self.valid_aspect_ratios:
                ratios = ", ".join(self.valid_aspect_ratios)
                if self.model_id:
                    return f"Invalid aspect ratio for {self.model_id}. Valid: {ratios}"
                return f"Invalid aspect ratio. Valid: {ratios}"
            if self.model_id:
                return f"Invalid parameters for {self.model_id}. Use --model-info {self.model_id} for details"
            return "Invalid parameters. Use --model-info <model> to see valid options"

        elif self.category == ErrorCategory.SAFETY:
            return "Content policy violation. Try rephrasing the prompt"

        elif self.category == ErrorCategory.RATE_LIMIT:
            if self.retry_after_seconds:
                return f"Rate limited. Retry after {self.retry_after_seconds} seconds"
            return "Rate limited. Please wait before retrying"

        elif self.category == ErrorCategory.AUTHENTICATION:
            return "Authentication failed. Check your POE_API_KEY"

        elif self.category == ErrorCategory.SERVER_ERROR:
            return "Server error. This is temporary, retry may succeed"

        return None


class ErrorParser:
    """Parses API errors and extracts actionable information."""

    def __init__(
        self,
        logger: Optional[structlog.BoundLogger] = None,
        model_registry: Optional["ModelRegistry"] = None
    ):
        """Initialize error parser.

        Args:
            logger: Optional structlog logger for debugging
            model_registry: Optional model registry for intelligent suggestions
        """
        self.logger = logger or structlog.get_logger()
        self.model_registry = model_registry

    def parse_error(
        self,
        error: Exception,
        model_id: Optional[str] = None,
        prompt_id: Optional[str] = None
    ) -> ErrorInfo:
        """Parse an error and extract actionable information.

        Args:
            error: The exception to parse
            model_id: The model ID that was being used (if known)
            prompt_id: The prompt ID that failed (if known)

        Returns:
            ErrorInfo with parsed error details
        """
        error_str = str(error)

        # Try to parse structured error from OpenAI-compatible API
        error_dict = self._extract_error_dict(error_str)

        if error_dict:
            return self._parse_structured_error(error_dict, error_str, model_id)

        # Fall back to pattern matching on error message
        error_info = self._parse_unstructured_error(error_str, model_id)

        # Log unparsable errors (UNKNOWN category) for analysis
        if error_info.category == ErrorCategory.UNKNOWN:
            self._log_unparsable_error(error_str, model_id, prompt_id)

        return error_info

    def _extract_error_dict(self, error_str: str) -> Optional[Dict[str, Any]]:
        """Extract error dictionary from error string.

        The OpenAI-compatible API returns errors like:
        "Error code: 404 - {'error': {'message': '...', 'type': '...', 'code': '...'}}"
        """
        import ast

        # Pattern: "Error code: NNN - {json}"
        match = re.search(r"Error code: (\d+) - ({.*})", error_str)
        if match:
            http_code = match.group(1)
            dict_str = match.group(2)

            try:
                # Use ast.literal_eval to safely parse Python dict literals
                error_data = ast.literal_eval(dict_str)
                if 'error' in error_data:
                    error_data['error']['http_code'] = http_code
                    return error_data['error']
            except (ValueError, SyntaxError):
                pass

        return None

    def _parse_structured_error(
        self,
        error_dict: Dict[str, Any],
        original_error: str,
        model_id: Optional[str]
    ) -> ErrorInfo:
        """Parse a structured error dictionary from the API."""

        error_code = error_dict.get('code')
        error_type = error_dict.get('type')
        message = error_dict.get('message', '')
        http_code = error_dict.get('http_code')

        # Categorize based on error code and type
        category = self._categorize_error(error_code, error_type, http_code, message)

        # Extract actionable information
        valid_aspect_ratios = None
        suggested_models = None

        if category == ErrorCategory.VALIDATION:
            valid_aspect_ratios = self._extract_aspect_ratios(message)

        # Get model suggestions if model not found
        if category == ErrorCategory.MODEL_NOT_FOUND and model_id and self.model_registry:
            try:
                suggestions = self.model_registry.suggest_fallback_models(model_id, count=3)
                suggested_models = [m.id for m in suggestions]
            except Exception as e:
                self.logger.warning("Failed to get model suggestions", error=str(e))

        return ErrorInfo(
            category=category,
            original_error=original_error,
            error_code=error_code,
            error_type=error_type,
            message=message,
            valid_aspect_ratios=valid_aspect_ratios,
            suggested_models=suggested_models,
            model_id=model_id
        )

    def _parse_unstructured_error(
        self,
        error_str: str,
        model_id: Optional[str]
    ) -> ErrorInfo:
        """Parse an unstructured error message using pattern matching."""

        error_lower = error_str.lower()

        # Check for common error patterns
        if 'model_not_found' in error_lower or 'bot does not exist' in error_lower:
            category = ErrorCategory.MODEL_NOT_FOUND
        elif 'rate limit' in error_lower or 'too many requests' in error_lower:
            category = ErrorCategory.RATE_LIMIT
        elif 'authentication' in error_lower or 'unauthorized' in error_lower or 'invalid api key' in error_lower:
            category = ErrorCategory.AUTHENTICATION
        elif 'safety' in error_lower or 'content policy' in error_lower or 'policy violation' in error_lower:
            category = ErrorCategory.SAFETY
        elif 'invalid' in error_lower or 'validation' in error_lower:
            category = ErrorCategory.VALIDATION
        elif '500' in error_str or '502' in error_str or '503' in error_str:
            category = ErrorCategory.SERVER_ERROR
        else:
            category = ErrorCategory.UNKNOWN

        # Extract aspect ratios if present
        valid_aspect_ratios = self._extract_aspect_ratios(error_str)

        return ErrorInfo(
            category=category,
            original_error=error_str,
            message=error_str,
            valid_aspect_ratios=valid_aspect_ratios,
            model_id=model_id
        )

    def _categorize_error(
        self,
        error_code: Optional[str],
        error_type: Optional[str],
        http_code: Optional[str],
        message: str
    ) -> ErrorCategory:
        """Categorize an error based on its code and type."""

        # Check error code first (most specific)
        if error_code == 'model_not_found':
            return ErrorCategory.MODEL_NOT_FOUND
        elif error_code == 'rate_limit_exceeded':
            return ErrorCategory.RATE_LIMIT
        elif error_code == 'invalid_request_error' and 'invalid' in message.lower():
            return ErrorCategory.VALIDATION
        elif error_code == 'content_policy_violation':
            return ErrorCategory.SAFETY

        # Check error type
        if error_type == 'invalid_request_error':
            # Check message content for safety before defaulting to validation
            message_lower = message.lower()
            if 'safety' in message_lower or 'policy' in message_lower or 'rejected' in message_lower:
                return ErrorCategory.SAFETY
            if 'model' in message_lower and 'not found' in message_lower:
                return ErrorCategory.MODEL_NOT_FOUND
            return ErrorCategory.VALIDATION
        elif error_type == 'authentication_error':
            return ErrorCategory.AUTHENTICATION

        # Check HTTP code
        if http_code:
            if http_code in ('401', '403'):
                return ErrorCategory.AUTHENTICATION
            elif http_code == '404':
                return ErrorCategory.MODEL_NOT_FOUND
            elif http_code == '429':
                return ErrorCategory.RATE_LIMIT
            elif http_code.startswith('5'):
                return ErrorCategory.SERVER_ERROR

        # Check message content
        message_lower = message.lower()
        if 'safety' in message_lower or 'policy' in message_lower:
            return ErrorCategory.SAFETY

        return ErrorCategory.UNKNOWN

    def _extract_aspect_ratios(self, text: str) -> Optional[List[str]]:
        """Extract valid aspect ratios from error message.

        Looks for patterns like:
        - "Valid aspect ratios: 1:1, 3:2, 16:9"
        - "aspect must be one of: 1:1, 3:2, 16:9, auto"
        - "aspect should be one of 1:1, 3:2, 2:3, auto"
        """
        # Pattern: find lists of aspect ratios (e.g., "1:1, 3:2, 16:9, auto")
        # Capture everything after the pattern including "auto"
        patterns = [
            r'(?:should|must) be one of[:\s]+([0-9:,\s]+(?:,\s*auto)?\.?)',
            r'valid (?:aspect ratios?|values?)[:\s]+([0-9:,\s]+(?:,\s*auto)?\.?)',
            r'allowed (?:aspect ratios?|values?)[:\s]+([0-9:,\s]+(?:,\s*auto)?\.?)',
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                ratios_str = match.group(1)
                # Extract individual ratios (numeric like "1:1" AND keyword "auto")
                ratios = re.findall(r'\d+:\d+|auto', ratios_str, re.IGNORECASE)
                if ratios:
                    # Normalize "auto" to lowercase
                    return [r.lower() if r.lower() == 'auto' else r for r in ratios]

        return None

    def _log_unparsable_error(
        self,
        error_str: str,
        model_id: Optional[str],
        prompt_id: Optional[str]
    ) -> None:
        """Log unparsable errors to new-errors.jsonl for analysis.

        Args:
            error_str: The full error string
            model_id: The model ID that was being used (if known)
            prompt_id: The prompt ID that failed (if known)
        """
        import json
        from pathlib import Path
        from datetime import datetime

        new_errors_log = Path("logs/new-errors.jsonl")
        new_errors_log.parent.mkdir(parents=True, exist_ok=True)

        entry = {
            "timestamp": datetime.now().isoformat(),
            "error": error_str,
            "model_id": model_id,
            "prompt_id": prompt_id,
        }

        with new_errors_log.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")

        self.logger.warning("unparsable_error_logged",
            error=error_str[:100],  # Log first 100 chars
            model_id=model_id,
            prompt_id=prompt_id,
            log_file=str(new_errors_log)
        )
