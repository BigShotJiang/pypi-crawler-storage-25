"""Model registry for discovering and validating Poe models and their parameters."""

import os
import json
from pathlib import Path
from typing import Dict, List, Optional, Set
from dataclasses import dataclass
from datetime import datetime, timedelta
import structlog

logger = structlog.get_logger(__name__)


@dataclass
class ModelParameter:
    """Represents a model parameter with its schema and metadata."""
    name: str
    schema: Dict
    default_value: Optional[any] = None
    description: Optional[str] = None

    def get_enum_values(self) -> Optional[List[str]]:
        """Extract enum values if parameter is an enum."""
        return self.schema.get('enum')

    def is_aspect_ratio(self) -> bool:
        """Check if this parameter controls aspect ratio."""
        return self.name in ('aspect', 'aspect_ratio')


@dataclass
class ModelInfo:
    """Complete information about a Poe model."""
    id: str
    display_name: str
    description: str
    owned_by: str
    parameters: List[ModelParameter]
    architecture: Dict
    context_window: Optional[Dict] = None
    pricing: Optional[Dict] = None

    def get_aspect_ratios(self) -> Optional[List[str]]:
        """Get list of supported aspect ratios for this model."""
        for param in self.parameters:
            if param.is_aspect_ratio():
                return param.get_enum_values()
        return None

    def supports_parameter(self, param_name: str) -> bool:
        """Check if model supports a specific parameter."""
        return any(p.name == param_name for p in self.parameters)

    def is_image_generation(self) -> bool:
        """Check if this is an image generation model."""
        modality = self.architecture.get('modality', '')
        output_modalities = self.architecture.get('output_modalities', [])
        return 'image' in output_modalities or '->image' in modality.lower()


class ModelRegistry:
    """Registry for querying and caching Poe model information."""

    CACHE_FILE = Path("logs/model-registry-cache.json")
    CACHE_DURATION = timedelta(hours=24)  # Refresh cache daily

    def __init__(self, api_key: Optional[str] = None, logger: Optional[structlog.BoundLogger] = None):
        """Initialize model registry.

        Args:
            api_key: Poe API key (reads from POE_API_KEY env var if not provided)
            logger: Structured logger instance
        """
        self.api_key = api_key or os.getenv("POE_API_KEY")
        self.logger = logger or structlog.get_logger(__name__)
        self._models: Dict[str, ModelInfo] = {}
        self._cache_loaded = False
        self._cache_timestamp: Optional[datetime] = None

    def _fetch_models_from_api(self) -> Dict:
        """Fetch model list from Poe API."""
        from urllib.request import Request, urlopen
        from urllib.error import HTTPError, URLError

        if not self.api_key:
            raise ValueError("POE_API_KEY not found in environment")

        self.logger.info("fetching_models_from_api")

        try:
            req = Request("https://api.poe.com/v1/models")
            req.add_header("Authorization", f"Bearer {self.api_key}")
            req.add_header("Content-Type", "application/json")

            response = urlopen(req, timeout=15)
            body = response.read().decode('utf-8')
            data = json.loads(body)

            self.logger.info("models_fetched",
                model_count=len(data.get('data', [])),
                response_size=len(body))

            return data

        except (HTTPError, URLError) as e:
            self.logger.error("failed_to_fetch_models", error=str(e))
            raise

    def _save_cache(self, data: Dict):
        """Save model data to cache file."""
        cache_data = {
            'timestamp': datetime.now().isoformat(),
            'models': data
        }

        self.CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(self.CACHE_FILE, 'w') as f:
            json.dump(cache_data, f, indent=2)

        self.logger.debug("model_cache_saved", cache_file=str(self.CACHE_FILE))

    def _load_cache(self) -> Optional[Dict]:
        """Load model data from cache if valid."""
        if not self.CACHE_FILE.exists():
            return None

        try:
            with open(self.CACHE_FILE) as f:
                cache_data = json.load(f)

            cache_time = datetime.fromisoformat(cache_data['timestamp'])
            age = datetime.now() - cache_time

            if age > self.CACHE_DURATION:
                self.logger.debug("model_cache_expired", age_hours=age.total_seconds()/3600)
                return None

            self.logger.debug("model_cache_loaded",
                cache_file=str(self.CACHE_FILE),
                age_hours=age.total_seconds()/3600)

            self._cache_timestamp = cache_time
            return cache_data['models']

        except (json.JSONDecodeError, KeyError, ValueError) as e:
            self.logger.warning("model_cache_invalid", error=str(e))
            return None

    def _parse_models(self, data: Dict):
        """Parse API response into ModelInfo objects."""
        for model_data in data.get('data', []):
            try:
                # Parse parameters
                parameters = []
                for param_data in model_data.get('parameters', []):
                    param = ModelParameter(
                        name=param_data['name'],
                        schema=param_data.get('schema', {}),
                        default_value=param_data.get('default_value'),
                        description=param_data.get('description')
                    )
                    parameters.append(param)

                # Create ModelInfo
                model_info = ModelInfo(
                    id=model_data['id'],
                    display_name=model_data.get('metadata', {}).get('display_name', model_data['id']),
                    description=model_data.get('description', ''),
                    owned_by=model_data.get('owned_by', ''),
                    parameters=parameters,
                    architecture=model_data.get('architecture', {}),
                    context_window=model_data.get('context_window'),
                    pricing=model_data.get('pricing')
                )

                self._models[model_data['id']] = model_info

            except KeyError as e:
                self.logger.warning("failed_to_parse_model",
                    model_id=model_data.get('id'),
                    error=str(e))

    def load(self, force_refresh: bool = False):
        """Load models from cache or API.

        Args:
            force_refresh: Force fetch from API even if cache is valid
        """
        if self._cache_loaded and not force_refresh:
            return

        # Try cache first
        if not force_refresh:
            cached_data = self._load_cache()
            if cached_data:
                self._parse_models(cached_data)
                self._cache_loaded = True
                return

        # Fetch from API
        data = self._fetch_models_from_api()
        self._parse_models(data)
        self._save_cache(data)
        self._cache_loaded = True
        self._cache_timestamp = datetime.now()

    def get_model(self, model_id: str) -> Optional[ModelInfo]:
        """Get information about a specific model.

        Args:
            model_id: Model ID (e.g., 'GPT-Image-1', 'Nano-Banana-Pro')

        Returns:
            ModelInfo if found, None otherwise
        """
        self.load()

        # Try exact match first
        if model_id in self._models:
            return self._models[model_id]

        # Try case-insensitive match
        model_id_lower = model_id.lower()
        for mid, info in self._models.items():
            if mid.lower() == model_id_lower:
                return info

        return None

    def list_models(self, filter_image_generation: bool = False) -> List[ModelInfo]:
        """List all available models.

        Args:
            filter_image_generation: Only return image generation models

        Returns:
            List of ModelInfo objects
        """
        self.load()

        models = list(self._models.values())

        if filter_image_generation:
            models = [m for m in models if m.is_image_generation()]

        return models

    def find_models_with_aspect_ratio(self, aspect_ratio: str) -> List[ModelInfo]:
        """Find all models that support a specific aspect ratio.

        Args:
            aspect_ratio: Aspect ratio string (e.g., '16:9', '1:1')

        Returns:
            List of models supporting this aspect ratio
        """
        self.load()

        matching = []
        for model in self._models.values():
            ratios = model.get_aspect_ratios()
            if ratios and aspect_ratio in ratios:
                matching.append(model)

        return matching

    def calculate_closest_aspect_ratio(self,
                                      model_id: str,
                                      requested: str) -> Optional[str]:
        """Calculate the closest valid aspect ratio for a model.

        Args:
            model_id: Model ID
            requested: Requested aspect ratio (e.g., '16:9')

        Returns:
            Closest valid aspect ratio, or None if model not found
        """
        model = self.get_model(model_id)
        if not model:
            return None

        valid_ratios = model.get_aspect_ratios()
        if not valid_ratios:
            return None

        # If requested ratio is valid, return it
        if requested in valid_ratios:
            return requested

        # Parse requested ratio
        try:
            req_w, req_h = map(int, requested.split(':'))
            req_ratio = req_w / req_h
        except (ValueError, ZeroDivisionError):
            self.logger.warning("invalid_aspect_ratio_format",
                aspect_ratio=requested)
            return valid_ratios[0] if valid_ratios else None

        # Calculate distances to all valid ratios
        best_match = None
        best_distance = float('inf')

        for valid in valid_ratios:
            # Skip special values
            if valid == 'auto':
                continue

            try:
                v_w, v_h = map(int, valid.split(':'))
                v_ratio = v_w / v_h
                distance = abs(v_ratio - req_ratio)

                if distance < best_distance:
                    best_distance = distance
                    best_match = valid

            except (ValueError, ZeroDivisionError):
                continue

        # If no numeric match found, default to first valid ratio
        if best_match is None and valid_ratios:
            best_match = valid_ratios[0]

        self.logger.debug("calculated_closest_aspect_ratio",
            model_id=model_id,
            requested=requested,
            closest=best_match,
            distance=best_distance)

        return best_match

    def suggest_fallback_models(self, invalid_model_id: str, count: int = 3) -> List[ModelInfo]:
        """Suggest similar models as fallbacks for an invalid model.

        Args:
            invalid_model_id: The model ID that doesn't exist
            count: Number of suggestions to return

        Returns:
            List of suggested fallback models
        """
        self.load()

        # Normalize separators (. -> -, _ -> -) for better matching
        def normalize(s):
            return s.lower().replace('.', '-').replace('_', '-')

        invalid_normalized = normalize(invalid_model_id)
        invalid_tokens = set(invalid_normalized.replace('-', ' ').split())

        # Score each model by similarity
        scored_models = []
        for model in self._models.values():
            score = 0
            model_normalized = normalize(model.id)
            model_tokens = set(model_normalized.replace('-', ' ').split())

            # Exact match after normalization (e.g., FLUX.1 matches flux-1)
            if invalid_normalized == model_normalized:
                score += 100

            # Starts with same prefix (e.g., FLUX.1 and flux-1-pro)
            if model_normalized.startswith(invalid_normalized) or invalid_normalized.startswith(model_normalized):
                score += 50

            # Exact substring match
            if invalid_normalized in model_normalized or model_normalized in invalid_normalized:
                score += 25

            # Common tokens
            common_tokens = invalid_tokens & model_tokens
            score += len(common_tokens) * 10

            # Prefer image generation models if the invalid name suggests image
            if any(token in invalid_normalized for token in ['image', 'img', 'flux', 'dall', 'stable', 'gpt']):
                if model.is_image_generation():
                    score += 5

            if score > 0:
                scored_models.append((score, model))

        # Sort by score and return top N
        scored_models.sort(key=lambda x: x[0], reverse=True)
        return [model for _, model in scored_models[:count]]


# Singleton instance
_registry: Optional[ModelRegistry] = None


def get_registry(api_key: Optional[str] = None,
                 logger: Optional[structlog.BoundLogger] = None) -> ModelRegistry:
    """Get or create the global model registry instance."""
    global _registry
    if _registry is None:
        _registry = ModelRegistry(api_key=api_key, logger=logger)
    return _registry
