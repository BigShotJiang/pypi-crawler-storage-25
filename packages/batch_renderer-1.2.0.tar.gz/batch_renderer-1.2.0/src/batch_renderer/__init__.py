"""Batch Renderer - CLI tool for batch rendering AI image prompts from markdown files."""

__version__ = "0.1.0"
