"""Structured logging configuration for batch renderer."""

from pathlib import Path
from typing import Optional
import sys
import structlog


def configure_logging(
    log_file: Optional[Path] = None,
    verbose: bool = False,
) -> structlog.BoundLogger:
    """
    Configure structlog for batch renderer.

    Args:
        log_file: Path to log file (default: logs/batch-renderer.log)
        verbose: Enable DEBUG level console output

    Returns:
        Configured logger instance
    """
    # Default log file
    if log_file is None:
        log_file = Path("logs/batch-renderer.log")

    # Ensure log directory exists
    log_file.parent.mkdir(parents=True, exist_ok=True)

    # Console processor chain (human-readable for TTY)
    console_processors = [
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.dev.ConsoleRenderer() if sys.stderr.isatty() else structlog.processors.JSONRenderer(),
    ]

    # File processor chain (always JSON)
    file_processors = [
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.JSONRenderer(),
    ]

    # Configure structlog
    structlog.configure(
        processors=[
            structlog.stdlib.filter_by_level,  # Filter by log level first
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            structlog.processors.CallsiteParameterAdder(
                parameters=[
                    structlog.processors.CallsiteParameter.FILENAME,
                    structlog.processors.CallsiteParameter.FUNC_NAME,
                    structlog.processors.CallsiteParameter.LINENO,
                ]
            ),
            structlog.processors.JSONRenderer(),
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

    # Set up file handler (always DEBUG)
    import logging
    import logging.handlers

    # Root logger for file output
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)

    # File handler (JSON, DEBUG level)
    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(
        logging.Formatter("%(message)s")  # structlog handles formatting
    )
    root_logger.addHandler(file_handler)

    # Console handler (only in verbose mode)
    # In normal mode, structured logs go to file only; console uses rich for user-facing output
    if verbose:
        console_handler = logging.StreamHandler(sys.stderr)
        console_handler.setLevel(logging.DEBUG)
        console_handler.setFormatter(
            logging.Formatter("%(message)s")  # structlog handles formatting
        )
        root_logger.addHandler(console_handler)

    # Get logger instance
    logger = structlog.get_logger("batch_renderer")

    # Log startup
    logger.info("logging_configured",
        log_file=str(log_file),
        console_level="DEBUG" if verbose else "INFO",
        file_level="DEBUG"
    )

    return logger


class TokenTracker:
    """Track token usage across prompts and models."""

    def __init__(self, logger: structlog.BoundLogger):
        self.logger = logger
        self.per_prompt: list[dict] = []
        self.per_model: dict[str, dict] = {}

    def track(
        self,
        prompt_id: str,
        model: str,
        tokens: int,
        success: bool,
        duration_seconds: float,
        file_size_bytes: Optional[int] = None,
        retries: int = 0,
    ) -> None:
        """Track a render operation."""
        # Per-prompt tracking
        entry = {
            "prompt_id": prompt_id,
            "model": model,
            "tokens": tokens,
            "success": success,
            "duration_seconds": round(duration_seconds, 2),
            "retries": retries,
        }
        if file_size_bytes is not None:
            entry["file_size_bytes"] = file_size_bytes

        self.per_prompt.append(entry)

        # Per-model aggregation
        if model not in self.per_model:
            self.per_model[model] = {
                "prompts": 0,
                "tokens": 0,
                "successes": 0,
                "failures": 0,
                "total_duration": 0.0,
                "total_file_size": 0,
            }

        stats = self.per_model[model]
        stats["prompts"] += 1
        stats["tokens"] += tokens
        if success:
            stats["successes"] += 1
        else:
            stats["failures"] += 1
        stats["total_duration"] += duration_seconds
        if file_size_bytes is not None:
            stats["total_file_size"] += file_size_bytes

        # Log the operation
        self.logger.debug("render_tracked", **entry)

    def get_summary(self) -> dict:
        """Get summary statistics."""
        total_tokens = sum(m["tokens"] for m in self.per_model.values())
        total_prompts = len(self.per_prompt)
        total_duration = sum(m["total_duration"] for m in self.per_model.values())

        return {
            "total_prompts": total_prompts,
            "total_tokens": total_tokens,
            "total_duration_seconds": round(total_duration, 2),
            "models": {
                model: {
                    "prompts": stats["prompts"],
                    "tokens": stats["tokens"],
                    "successes": stats["successes"],
                    "failures": stats["failures"],
                    "avg_duration": round(stats["total_duration"] / stats["prompts"], 2),
                }
                for model, stats in self.per_model.items()
            },
        }

    def log_summary(self) -> None:
        """Log final summary."""
        summary = self.get_summary()
        self.logger.info("batch_summary", **summary)

    def format_summary(self) -> str:
        """Format summary for console output."""
        summary = self.get_summary()

        # Duration formatting
        duration = summary["total_duration_seconds"]
        if duration < 60:
            duration_str = f"{duration:.0f}s"
        else:
            minutes = int(duration // 60)
            seconds = int(duration % 60)
            duration_str = f"{minutes}m {seconds}s"

        # Token formatting
        tokens = summary["total_tokens"]
        if tokens >= 1_000_000:
            tokens_str = f"{tokens / 1_000_000:.1f}M"
        elif tokens >= 1_000:
            tokens_str = f"{tokens / 1_000:.1f}K"
        else:
            tokens_str = str(tokens)

        # Build summary string
        parts = [
            f"Generated {summary['total_prompts']} image(s)",
            f"in {duration_str}",
            f"using {tokens_str} tokens",
        ]

        # Per-model breakdown
        model_parts = []
        for model, stats in summary["models"].items():
            model_parts.append(f"{model} ({stats['prompts']} prompts, {stats['tokens']} tokens)")

        if model_parts:
            parts.append(f"across {', '.join(model_parts)}")

        return " ".join(parts)
