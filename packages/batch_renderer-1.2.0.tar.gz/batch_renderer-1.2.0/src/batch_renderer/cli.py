"""Command-line interface for batch renderer."""

from pathlib import Path
from typing import Optional
import sys
import click
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.prompt import Confirm

from .config import Config
from .patterns import extract_prompts, auto_detect_pattern, PATTERNS, slugify, Prompt
from .renderer import Renderer
from .logging import configure_logging, TokenTracker
from .model_registry import get_registry

console = Console()


def format_prompt_location(prompt: Prompt) -> str:
    """Format prompt location as 'file:line' when available, otherwise just ID."""
    if prompt.source_file and prompt.source_line:
        return f"{prompt.source_file}:{prompt.source_line}"
    return prompt.id


def _load_prompts_from_redo(redo_file: Path) -> list[Prompt]:
    """Load prompts from a redo.jsonl file.

    Args:
        redo_file: Path to redo.jsonl file

    Returns:
        List of Prompt objects reconstructed from failed prompts
    """
    import json

    prompts = []

    with redo_file.open('r', encoding='utf-8') as f:
        for line_num, line in enumerate(f, 1):
            try:
                entry = json.loads(line)

                # Reconstruct Prompt from redo entry
                prompt = Prompt(
                    id=entry['prompt_id'],
                    section=entry['section'],
                    title=entry['title'],
                    prompt=entry['prompt'],
                    metadata=entry['metadata'],
                    source_file=entry.get('source_file'),
                    source_line=entry.get('source_line')
                )
                prompts.append(prompt)

            except (json.JSONDecodeError, KeyError) as e:
                console.print(f"[yellow]Warning: Skipping invalid line {line_num} in redo file: {e}[/yellow]")
                continue

    return prompts


def _copy_logs_to_output(output_dir: Path) -> None:
    """Copy log files to output directory with timestamp.

    Args:
        output_dir: Output directory to copy logs to
    """
    from datetime import datetime
    from shutil import copy2

    # Generate timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    # Files to copy
    log_files = [
        (Path("logs/batch-renderer.log"), f"batch-renderer-{timestamp}.log"),
        (Path("logs/redo.jsonl"), f"redo-{timestamp}.jsonl"),
        (Path("logs/safety-rejections.jsonl"), f"safety-rejections-{timestamp}.jsonl"),
        (Path("logs/new-errors.jsonl"), f"new-errors-{timestamp}.jsonl"),
    ]

    copied_files = []
    for source, dest_name in log_files:
        if source.exists():
            dest = output_dir / dest_name
            try:
                copy2(source, dest)
                copied_files.append(dest_name)
            except Exception as e:
                console.print(f"[yellow]Warning: Could not copy {source}: {e}[/yellow]")

    if copied_files:
        console.print(f"\n[dim]Logs copied to output folder:[/dim]")
        for filename in copied_files:
            console.print(f"  [dim]- {filename}[/dim]")


@click.command()
@click.argument("input_file", type=click.Path(exists=True, path_type=Path), required=False)
@click.option(
    "--model", "-m",
    default=None,
    help="Model to use for rendering (default: from env POE_DEFAULT_MODEL or 'Nano-Banana')"
)
@click.option(
    "--output", "-o",
    type=click.Path(path_type=Path),
    default="out",
    help="Output directory (default: ./out)"
)
@click.option(
    "--pattern", "-p",
    type=click.Choice(list(PATTERNS.keys())),
    default="concept",
    help="Pattern to use for prompt extraction (default: concept)"
)
@click.option(
    "--auto-detect-pattern",
    is_flag=True,
    help="Auto-detect the best pattern by trying all available patterns"
)
@click.option(
    "--format", "-f",
    default="png",
    help="Output image format (default: png)"
)
@click.option(
    "--flatten",
    is_flag=True,
    help="Flatten output structure (no subdirectories)"
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Extract and display prompts without rendering"
)
@click.option(
    "--no-confirm",
    is_flag=True,
    help="Skip confirmation prompt before rendering"
)
@click.option(
    "--skip-existing",
    is_flag=True,
    help="Skip prompts with existing output files (idempotent rendering)"
)
@click.option(
    "--cache-images",
    is_flag=True,
    help="Cache images in logs/image_cache directory"
)
@click.option(
    "--validation-mode",
    type=click.Choice(["strict", "lenient", "hybrid"]),
    default="hybrid",
    help="Metadata validation mode (default: hybrid)"
)
@click.option(
    "--aspect-fix-mode",
    type=click.Choice(["auto", "calculated", "none"]),
    default="auto",
    help="Aspect ratio auto-fix mode: auto (use 'auto'), calculated (closest valid), none (disable)"
)
@click.option(
    "--api-key",
    envvar="POE_API_KEY",
    help="Poe API key (or set POE_API_KEY env var)"
)
@click.option(
    "--new-template",
    is_flag=True,
    help="Generate template to stdout (use > to save to file)"
)
@click.option(
    "--list-models",
    is_flag=True,
    help="List all available models from Poe API"
)
@click.option(
    "--model-info",
    type=str,
    metavar="MODEL_ID",
    help="Show detailed information about a specific model"
)
@click.option(
    "--image-only",
    is_flag=True,
    help="Filter to image generation models only (use with --list-models)"
)
@click.option(
    "--verbose", "-v",
    is_flag=True,
    help="Enable verbose logging (DEBUG level to console)"
)
@click.option(
    "--redo",
    type=click.Path(exists=True, path_type=Path),
    metavar="REDO_FILE",
    help="Retry failed prompts from redo.jsonl file (e.g., logs/redo.jsonl)"
)
@click.option(
    "--ignore-undefined-tags",
    is_flag=True,
    help="Continue with warnings if undefined tags found (useful for debugging tag libraries)"
)
def main(
    input_file: Optional[Path],
    model: Optional[str],
    output: Path,
    pattern: str,
    auto_detect_pattern: bool,
    format: str,
    flatten: bool,
    dry_run: bool,
    no_confirm: bool,
    skip_existing: bool,
    cache_images: bool,
    validation_mode: str,
    aspect_fix_mode: str,
    api_key: Optional[str],
    new_template: bool,
    list_models: bool,
    model_info: Optional[str],
    image_only: bool,
    verbose: bool,
    redo: Optional[Path],
    ignore_undefined_tags: bool,
):
    """
    Batch render AI image prompts from markdown files.

    INPUT_FILE: Path to markdown file containing prompts

    \b
    Getting Started:
      Generate a template to get started:
        $ batch-renderer --new-template > my-prompts.md

      Then edit the template and render:
        $ batch-renderer my-prompts.md
    """
    # Handle template generation (mutually exclusive with rendering)
    if new_template:
        _generate_template()
        return

    # Handle model discovery commands (mutually exclusive with rendering)
    if list_models:
        _list_models(api_key=api_key, image_only=image_only, verbose=verbose)
        return

    if model_info:
        _show_model_info(model_id=model_info, api_key=api_key, verbose=verbose)
        return

    # Require input_file if not generating template or querying models
    # Require either input_file OR redo
    if input_file is None and redo is None:
        console.print("[bold red]Error:[/bold red] Either INPUT_FILE or --redo is required")
        console.print("\n[yellow]Hint:[/yellow] Generate a template first:")
        console.print("  $ batch-renderer --new-template my-prompts.md")
        console.print("  $ batch-renderer --new-template  # outputs to stdout")
        console.print("\nOr retry failed prompts:")
        console.print("  $ batch-renderer --redo logs/redo.jsonl")
        raise click.Abort()

    # Configure structured logging
    logger = configure_logging(verbose=verbose)
    tracker = TokenTracker(logger)

    # Create config
    config = Config(
        model=model,
        output_dir=output,
        pattern=pattern,
        image_format=format,
        flatten=flatten,
        dry_run=dry_run,
        confirm=not no_confirm,
        skip_existing=skip_existing,
        cache_images=cache_images,
        validation_mode=validation_mode,
        aspect_fix_mode=aspect_fix_mode,
        api_key=api_key,
        cli_model=model,  # Track if model was explicitly set via CLI
        cli_format=format if format != "png" else None,  # Track if format was explicitly set
    )

    # Display configuration
    console.print("\n[bold cyan]Batch Renderer Configuration[/bold cyan]")
    if redo:
        console.print(f"  Redo file: [yellow]{redo}[/yellow]")
    else:
        console.print(f"  Input file: [yellow]{input_file}[/yellow]")
    if auto_detect_pattern:
        console.print(f"  Pattern: [yellow]auto-detect[/yellow]")
    else:
        console.print(f"  Pattern: [yellow]{pattern}[/yellow]")
    console.print(f"  Model: [yellow]{config.model}[/yellow]")
    console.print(f"  Output: [yellow]{config.output_dir}[/yellow]")
    console.print(f"  Format: [yellow]{config.image_format}[/yellow]")
    console.print(f"  Structure: [yellow]{'flat' if flatten else 'nested'}[/yellow]")
    if dry_run:
        console.print("  [bold yellow]Mode: DRY RUN (no rendering)[/bold yellow]")
    console.print()

    # Load prompts from either input file or redo file
    if redo:
        # Load from redo file
        console.print("[bold]Loading failed prompts from redo file...[/bold]")
        try:
            prompts = _load_prompts_from_redo(redo)
        except Exception as e:
            console.print(f"[bold red]Error reading redo file:[/bold red] {e}")
            raise click.Abort()

        if not prompts:
            console.print("[bold red]No prompts found in redo file![/bold red]")
            raise click.Abort()

        console.print(f"[green]Loaded {len(prompts)} failed prompt(s) for retry[/green]\n")
    else:
        # Read and parse markdown file
        console.print("[bold]Extracting prompts...[/bold]")
        try:
            markdown_text = input_file.read_text(encoding="utf-8")

            # Use auto-detect or explicit pattern
            if auto_detect_pattern:
                from .patterns import auto_detect_pattern as auto_detect_fn, PatternDetectionResult

                try:
                    detection_result = auto_detect_fn(
                        markdown_text,
                        source_file=input_file.name,
                        ignore_undefined_tags=ignore_undefined_tags
                    )

                    prompts = detection_result.prompts
                    detected_pattern = detection_result.pattern_name

                    # Display detection results
                    console.print(f"\n[bold green]Auto-detected pattern:[/bold green] '{detected_pattern}' ({detection_result.prompt_count} prompts, {detection_result.with_metadata} with metadata)\n")

                    console.print("[bold cyan]Pattern detection results:[/bold cyan]")
                    for pattern_name, result in detection_result.all_results.items():
                        if result['count'] > 0:
                            icon = "✓" if pattern_name == detected_pattern else "✗"
                            console.print(f"  {icon} [yellow]{pattern_name}[/yellow]: {result['count']} prompts ({result['with_metadata']} with metadata)")
                        else:
                            console.print(f"  ✗ [dim]{pattern_name}[/dim]: 0 prompts")
                    console.print()

                    # Log all detected concept titles for manual review
                    if prompts:
                        console.print(f"[bold cyan]Detected concepts ({detected_pattern} pattern):[/bold cyan]")
                        for i, prompt in enumerate(prompts, 1):
                            console.print(f"  {i}. ### {prompt.title}")
                        console.print()
                        console.print("[dim]Review the above list for anomalies before proceeding.[/dim]\n")

                except ValueError as e:
                    console.print(f"[bold red]Error: {e}[/bold red]")
                    console.print("\n[yellow]Tried patterns:[/yellow]")
                    for pattern_name, pattern_config in PATTERNS.items():
                        console.print(f"  - [cyan]{pattern_name}[/cyan]: {pattern_config.description}")
                    console.print("\nSee documentation: https://github.com/jlumbroso/batch-renderer#prompt-formats")
                    raise click.Abort()
            else:
                prompts = extract_prompts(
                    markdown_text,
                    pattern_name=pattern,
                    source_file=input_file.name,
                    ignore_undefined_tags=ignore_undefined_tags
                )
        except Exception as e:
            console.print(f"[bold red]Error reading file:[/bold red] {e}")
            raise click.Abort()

        if not prompts:
            console.print("[bold red]No prompts found in file![/bold red]")
            if not auto_detect_pattern:
                console.print(f"Make sure your file uses the '{pattern}' pattern.")
                console.print(f"\nPattern description: {PATTERNS[pattern].description}")
            raise click.Abort()

        if not auto_detect_pattern:
            console.print(f"[green]Found {len(prompts)} prompt(s)[/green]\n")

    # Display prompts in a table
    table = Table(title="Extracted Prompts", show_lines=True)
    table.add_column("ID", style="cyan", width=8)
    table.add_column("Section", style="magenta", width=20)
    table.add_column("Title", style="yellow", width=30)
    table.add_column("Model", style="green", width=15)
    table.add_column("Prompt Preview", style="white", width=50)

    for prompt in prompts:
        # Get model (from metadata or config)
        prompt_model = prompt.metadata.get("model", config.model)

        # Truncate prompt for preview
        prompt_preview = prompt.prompt[:100] + "..." if len(prompt.prompt) > 100 else prompt.prompt

        table.add_row(
            prompt.id,
            prompt.section or "(none)",
            prompt.title[:30],
            prompt_model,
            prompt_preview
        )

    console.print(table)

    # Show metadata if any prompts have it
    prompts_with_metadata = [p for p in prompts if p.metadata]
    if prompts_with_metadata:
        console.print(f"\n[bold cyan]Metadata found in {len(prompts_with_metadata)} prompt(s):[/bold cyan]")
        for prompt in prompts_with_metadata:
            console.print(f"  [cyan]{prompt.id}[/cyan]: {', '.join(f'{k}={v}' for k, v in prompt.metadata.items())}")
        console.print()

    # Dry run mode - stop here
    if dry_run:
        console.print("[bold green]Dry run complete. No images rendered.[/bold green]")
        return

    # Pre-create renderer to check for existing files
    renderer = Renderer(config, logger=logger, tracker=tracker)

    # Count existing files when --skip-existing is enabled
    existing_count = 0
    if config.skip_existing:
        for prompt in prompts:
            output_path = renderer._get_output_path(prompt)
            if output_path.exists():
                existing_count += 1

    # Confirmation
    if config.confirm:
        console.print()
        to_render = len(prompts) - existing_count

        if existing_count > 0:
            message = f"[bold]Render {to_render} image(s)?[/bold] [dim]({existing_count} already exist)[/dim]"
        else:
            message = f"[bold]Render {len(prompts)} image(s)?[/bold]"

        should_proceed = Confirm.ask(message, default=True)
        if not should_proceed:
            console.print("[yellow]Cancelled by user.[/yellow]")
            return
        console.print()
    results = []

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("[cyan]Rendering images...", total=len(prompts))

        for prompt in prompts:
            progress.update(
                task,
                description=f"[cyan]Rendering: {prompt.title[:40]}..."
            )

            # Check if output file exists and skip if --skip-existing
            if config.skip_existing:
                output_path = renderer._get_output_path(prompt)
                if output_path.exists():
                    prompt_loc = format_prompt_location(prompt)
                    console.print(f"  [dim]⊙[/dim]  {prompt_loc}: Skipped (file exists)")
                    progress.advance(task)
                    continue

            result = renderer.render(prompt)
            results.append(result)

            if result.success:
                if result.is_text:
                    console.print(f"  [yellow]⚠[/yellow]  {prompt.id}: Saved text response")
                else:
                    console.print(f"  [green]✓[/green]  {prompt.id}: {result.output_path.name}")
            else:
                console.print(f"  [red]✗[/red]  {prompt.id}: {result.error}")

            progress.advance(task)

    # Summary
    console.print()
    console.print("[bold cyan]=" * 50 + "[/bold cyan]")
    console.print("[bold]Summary[/bold]")

    successful = [r for r in results if r.success and not r.is_text]
    text_responses = [r for r in results if r.success and r.is_text]
    failed = [r for r in results if not r.success]

    console.print(f"  [green]✓ Successful:[/green] {len(successful)}/{len(prompts)}")
    if text_responses:
        console.print(f"  [yellow]⚠ Text responses:[/yellow] {len(text_responses)}")
    if failed:
        console.print(f"  [red]✗ Failed:[/red] {len(failed)}")

    # Token usage summary with per-model breakdown
    if tracker:
        tracker.log_summary()
        summary = tracker.get_summary()

        # Per-model breakdown table
        if summary["models"]:
            console.print(f"\n  [bold cyan]Usage by Model:[/bold cyan]")
            model_table = Table(show_header=True, box=None, padding=(0, 2))
            model_table.add_column("Model", style="cyan")
            model_table.add_column("Prompts", justify="right")
            model_table.add_column("Tokens", justify="right")
            model_table.add_column("Failed", justify="right", style="red")

            for model_name, stats in summary["models"].items():
                tokens_str = f"{stats['tokens']:,}" if stats['tokens'] > 0 else "N/A"
                failed_str = str(stats['failures']) if stats['failures'] > 0 else "-"

                model_table.add_row(
                    model_name,
                    str(stats['prompts']),
                    tokens_str,
                    failed_str
                )

            console.print(model_table)

    console.print(f"\n  Output directory: [yellow]{config.output_dir}[/yellow]")

    if cache_images:
        console.print(f"  Cache directory: [yellow]{config.cache_dir}[/yellow]")

    console.print("[bold cyan]=" * 50 + "[/bold cyan]\n")

    # Generate safety rejection report if any occurred
    if renderer.get_safety_rejections():
        safety_report = renderer.generate_safety_report(config.output_dir)
        if safety_report:
            console.print(f"[yellow]Safety rejection report generated: {safety_report.name}[/yellow]")

    # Copy logs to output directory for record-keeping
    _copy_logs_to_output(config.output_dir)


def _generate_template() -> None:
    """Generate template to stdout from embedded template."""
    import importlib.resources
    import os

    # Read template from package
    try:
        # Python 3.9+ compatible way to read package resource
        if sys.version_info >= (3, 9):
            template_text = (
                importlib.resources.files("batch_renderer.templates")
                .joinpath("canonical-template.md")
                .read_text(encoding="utf-8")
            )
        else:
            # Fallback for Python 3.7-3.8
            import importlib.resources as pkg_resources
            with pkg_resources.open_text("batch_renderer.templates", "canonical-template.md") as f:
                template_text = f.read()
    except Exception as e:
        console.print(f"[bold red]Error reading template:[/bold red] {e}", file=sys.stderr)
        raise click.Abort()

    # Try to append real model information from registry
    try:
        api_key = os.getenv("POE_API_KEY")
        if api_key:
            # Load model registry and generate appendix
            logger = configure_logging(verbose=False)
            registry = get_registry(api_key=api_key, logger=logger)
            registry.load()

            model_appendix = _generate_model_appendix(registry)

            # Replace generic model information with real data
            template_text = _replace_generic_model_info(template_text, registry)

            # Append detailed model reference
            template_text += "\n" + model_appendix
    except Exception as e:
        # If model registry fails, just use the template as-is
        # This allows template generation to work even without API key
        pass

    # Output to stdout
    sys.stdout.write(template_text)
    sys.stdout.flush()


def _replace_generic_model_info(template: str, registry) -> str:
    """Replace generic model information with real data from registry."""
    from .model_registry import ModelRegistry

    # Get image generation models
    models = registry.list_models(filter_image_generation=True)
    models.sort(key=lambda m: m.id)

    # Build replacement text for Available Models section
    models_section = "**Available Models:**\n"
    popular_models = [m for m in models if m.id in ['GPT-Image-1', 'GPT-Image-1.5', 'Nano-Banana-Pro', 'FLUX-2-Pro', 'FLUX-1-Pro', 'Amazon-Nova-Canvas']]
    if popular_models:
        for model in popular_models[:6]:  # Show top 6 popular models
            models_section += f"- {model.id}"
            if model.display_name and model.display_name != model.id:
                models_section += f" ({model.display_name})"
            models_section += "\n"
    models_section += f"- (Run `batch-renderer --list-models --image-only` to see all {len(models)} available models)\n"

    # Build replacement text for Aspect Ratios section
    # Collect all unique aspect ratios across models
    all_ratios = set()
    for model in models:
        ratios = model.get_aspect_ratios()
        if ratios:
            all_ratios.update(ratios)

    # Sort aspect ratios by numeric value
    def ratio_sort_key(r):
        if r == 'auto':
            return 999  # Put 'auto' at end
        try:
            parts = r.split(':')
            return float(parts[0]) / float(parts[1])
        except:
            return 0

    sorted_ratios = sorted(all_ratios, key=ratio_sort_key)

    aspect_section = "**Aspect Ratios:**\n"
    aspect_section += "Note: Available ratios vary by model. Use `batch-renderer --model-info MODEL_ID` to see specific model capabilities.\n\n"
    aspect_section += "Common aspect ratios:\n"
    for ratio in sorted_ratios[:10]:  # Show first 10
        if ratio != 'auto':
            parts = ratio.split(':')
            if len(parts) == 2:
                try:
                    w, h = int(parts[0]), int(parts[1])
                    if w == h:
                        desc = "square"
                    elif w > h:
                        desc = "landscape"
                    else:
                        desc = "portrait"
                    aspect_section += f"- {ratio} ({desc})\n"
                except:
                    aspect_section += f"- {ratio}\n"
    if 'auto' in sorted_ratios:
        aspect_section += "- auto (model decides)\n"

    # Replace sections in template
    import re

    # Replace Available Models section
    template = re.sub(
        r'\*\*Available Models:\*\*\n(?:- .*\n)+',
        models_section,
        template
    )

    # Replace Aspect Ratios section
    template = re.sub(
        r'\*\*Aspect Ratios:\*\*\n(?:- .*\n)+',
        aspect_section,
        template
    )

    return template


def _generate_model_appendix(registry) -> str:
    """Generate detailed model reference appendix."""
    from .model_registry import ModelRegistry

    appendix = "---\n\n"
    appendix += "# Model Reference (Auto-Generated)\n\n"
    appendix += "This section provides detailed information about available image generation models.\n"
    appendix += "**Note:** This information is fetched from the Poe API and reflects current model capabilities.\n\n"

    # Get image generation models
    models = registry.list_models(filter_image_generation=True)
    models.sort(key=lambda m: m.id)

    # Group models by owner for better organization
    by_owner = {}
    for model in models:
        owner = model.owned_by or "Other"
        if owner not in by_owner:
            by_owner[owner] = []
        by_owner[owner].append(model)

    # Generate sections by owner
    for owner in sorted(by_owner.keys()):
        owner_models = by_owner[owner]
        appendix += f"## {owner} Models\n\n"

        for model in owner_models[:5]:  # Limit to 5 models per owner to keep template reasonable
            appendix += f"### {model.id}\n\n"

            if model.display_name and model.display_name != model.id:
                appendix += f"**Display Name:** {model.display_name}\n\n"

            if model.description:
                appendix += f"{model.description}\n\n"

            # Parameters
            if model.parameters:
                appendix += "**Parameters:**\n\n"
                for param in model.parameters:
                    enum_values = param.get_enum_values()
                    if enum_values:
                        appendix += f"- `{param.name}`: {', '.join(enum_values)}\n"
                    else:
                        param_type = param.schema.get('type', 'string')
                        appendix += f"- `{param.name}`: {param_type}\n"
                appendix += "\n"

            # Architecture info
            if model.architecture:
                input_mod = model.architecture.get('input_modalities', [])
                output_mod = model.architecture.get('output_modalities', [])
                if input_mod or output_mod:
                    appendix += "**Capabilities:**\n"
                    if input_mod:
                        appendix += f"- Input: {', '.join(input_mod)}\n"
                    if output_mod:
                        appendix += f"- Output: {', '.join(output_mod)}\n"
                    appendix += "\n"

        if len(owner_models) > 5:
            appendix += f"*...and {len(owner_models) - 5} more {owner} models. Use `batch-renderer --list-models --image-only` to see all.*\n\n"

    appendix += "---\n\n"
    appendix += "*To see detailed information about a specific model, use:*\n"
    appendix += "```bash\n"
    appendix += "batch-renderer --model-info MODEL_ID\n"
    appendix += "```\n"

    return appendix


def _list_models(api_key: Optional[str], image_only: bool, verbose: bool) -> None:
    """List all available models from Poe API."""
    # Configure logging for registry
    logger = configure_logging(verbose=verbose)

    try:
        registry = get_registry(api_key=api_key, logger=logger)
        registry.load()

        models = registry.list_models(filter_image_generation=image_only)

        if not models:
            console.print("[yellow]No models found.[/yellow]")
            return

        # Sort by ID for consistent display
        models.sort(key=lambda m: m.id)

        # Create table
        table = Table(
            title=f"Available {'Image Generation ' if image_only else ''}Models ({len(models)} total)",
            show_lines=False,
            show_header=True,
            header_style="bold cyan"
        )
        table.add_column("Model ID", style="cyan", no_wrap=True)
        table.add_column("Display Name", style="yellow")
        table.add_column("Owner", style="green")
        table.add_column("Aspect Ratios", style="magenta", overflow="fold")
        table.add_column("Modality", style="white", overflow="fold")

        for model in models:
            # Get aspect ratios
            aspect_ratios = model.get_aspect_ratios()
            aspect_str = ", ".join(aspect_ratios) if aspect_ratios else "-"

            # Get modality info
            output_modalities = model.architecture.get('output_modalities', [])
            modality_str = ", ".join(output_modalities) if output_modalities else "-"

            table.add_row(
                model.id,
                model.display_name or "-",
                model.owned_by or "-",
                aspect_str,
                modality_str
            )

        console.print(table)
        console.print(f"\n[dim]Use --model-info MODEL_ID to see detailed information about a specific model[/dim]")

    except Exception as e:
        console.print(f"[bold red]Error loading models:[/bold red] {e}", file=sys.stderr)
        if verbose:
            import traceback
            console.print(traceback.format_exc(), file=sys.stderr)
        raise click.Abort()


def _show_model_info(model_id: str, api_key: Optional[str], verbose: bool) -> None:
    """Show detailed information about a specific model."""
    # Configure logging for registry
    logger = configure_logging(verbose=verbose)

    try:
        registry = get_registry(api_key=api_key, logger=logger)
        registry.load()

        model = registry.get_model(model_id)

        if not model:
            console.print(f"[bold red]Model not found:[/bold red] {model_id}")

            # Suggest fallbacks
            suggestions = registry.suggest_fallback_models(model_id, count=3)
            if suggestions:
                console.print("\n[yellow]Did you mean one of these?[/yellow]")
                for suggestion in suggestions:
                    console.print(f"  - [cyan]{suggestion.id}[/cyan] ({suggestion.display_name})")
            return

        # Display model information
        console.print(f"\n[bold cyan]Model Information: {model.id}[/bold cyan]\n")

        # Basic info
        info_table = Table(show_header=False, box=None, padding=(0, 2))
        info_table.add_column("Field", style="yellow", no_wrap=True)
        info_table.add_column("Value", style="white")

        info_table.add_row("Display Name", model.display_name or "-")
        info_table.add_row("Owner", model.owned_by or "-")
        info_table.add_row("Description", model.description or "-")

        # Architecture
        if model.architecture:
            input_mod = ", ".join(model.architecture.get('input_modalities', []))
            output_mod = ", ".join(model.architecture.get('output_modalities', []))
            info_table.add_row("Input Modalities", input_mod or "-")
            info_table.add_row("Output Modalities", output_mod or "-")
            info_table.add_row("Modality", model.architecture.get('modality', '-'))

        # Context window
        if model.context_window:
            max_input = model.context_window.get('max_input_tokens', '-')
            max_output = model.context_window.get('max_output_tokens', '-')
            info_table.add_row("Max Input Tokens", str(max_input))
            info_table.add_row("Max Output Tokens", str(max_output))

        console.print(info_table)

        # Parameters
        if model.parameters:
            console.print("\n[bold cyan]Parameters:[/bold cyan]\n")

            param_table = Table(show_lines=True)
            param_table.add_column("Parameter", style="cyan", no_wrap=True)
            param_table.add_column("Type", style="yellow")
            param_table.add_column("Options", style="magenta", overflow="fold")
            param_table.add_column("Default", style="green")
            param_table.add_column("Description", style="white", overflow="fold")

            for param in model.parameters:
                # Determine type
                param_type = "string"
                if 'enum' in param.schema:
                    param_type = "enum"
                elif 'type' in param.schema:
                    param_type = param.schema['type']

                # Get options (for enums)
                options = ""
                if param.get_enum_values():
                    options = ", ".join(param.get_enum_values())

                # Default value
                default = str(param.default_value) if param.default_value is not None else "-"

                param_table.add_row(
                    param.name,
                    param_type,
                    options,
                    default,
                    param.description or "-"
                )

            console.print(param_table)

        # Pricing info (if available)
        if model.pricing:
            console.print("\n[bold cyan]Pricing:[/bold cyan]")
            console.print(f"  {model.pricing}")

        console.print()

    except Exception as e:
        console.print(f"[bold red]Error loading model info:[/bold red] {e}", file=sys.stderr)
        if verbose:
            import traceback
            console.print(traceback.format_exc(), file=sys.stderr)
        raise click.Abort()


if __name__ == "__main__":
    main()
