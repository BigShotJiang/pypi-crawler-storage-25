"""Tag-based template system for prompt composition.

This module implements ADR-0006: Tag-Based Prompt Template System.

Features:
- Parse TAG LIBRARY sections from markdown
- Resolve tag references using iterative DAG-based algorithm
- Support tag variants with [TAG_NAME:variant] syntax
- Composable tags using {TAG_NAME} within definitions
- Case-sensitive tag matching with helpful error messages
"""

import re
from typing import Dict, List, Tuple, Set, Optional
from dataclasses import dataclass


@dataclass
class TagDefinition:
    """Represents a single tag definition."""
    name: str  # Full name including variant, e.g., "WORLD_STYLE_BASE:corrupted"
    raw_value: str  # The definition text before substitution
    resolved_value: Optional[str] = None  # After substitution
    source_line: Optional[int] = None  # Line number where defined


@dataclass
class UndefinedTagError(Exception):
    """Exception raised when undefined tags are found."""
    undefined_tags: Set[str]
    defined_tags: Set[str]
    context: str  # e.g., "in prompt 2.3" or "in tag definition GHOUL:Stage3"

    def __str__(self):
        msg = f"Undefined tags found {self.context}:\n"
        msg += f"  Undefined: {', '.join(sorted(self.undefined_tags))}\n"

        # Check for case-sensitivity issues
        undefined_lower = {tag.lower() for tag in self.undefined_tags}
        defined_lower = {tag.lower() for tag in self.defined_tags}
        case_issues = undefined_lower & defined_lower

        if case_issues:
            msg += f"\n  ⚠️  Case-sensitivity issue detected!\n"
            msg += f"  These tags exist but with different casing:\n"
            for issue in case_issues:
                # Find the actual defined version
                matching = [t for t in self.defined_tags if t.lower() == issue]
                if matching:
                    msg += f"    - You may have meant: {matching[0]}\n"

        if self.defined_tags:
            msg += f"\n  Available tags: {', '.join(sorted(self.defined_tags))}"

        return msg


@dataclass
class CircularDependencyError(Exception):
    """Exception raised when circular tag dependencies are detected."""
    unresolved_tags: Set[str]
    max_iterations: int

    def __str__(self):
        msg = f"Circular tag dependencies detected after {self.max_iterations} iterations.\n"
        msg += f"  Unresolved tags: {', '.join(sorted(self.unresolved_tags))}\n"
        msg += f"\n  This usually means tags reference each other in a loop."
        return msg


def parse_tag_libraries(markdown_text: str) -> Dict[str, TagDefinition]:
    """
    Parse all TAG LIBRARY sections from markdown text.

    TAG LIBRARY sections can appear anywhere in the file and are loaded
    progressively. Later definitions can override earlier ones.

    Syntax:
        ## TAG LIBRARY
        ## TAG LIBRARY: Subtitle

        ## [TAG_NAME]
        Definition text...

        ## [TAG_NAME:variant]
        {TAG_NAME} with additional text...

    Args:
        markdown_text: The markdown content to parse

    Returns:
        Dictionary mapping tag names to TagDefinition objects
    """
    tag_library = {}

    # Find all TAG LIBRARY sections
    # Pattern matches: ## TAG LIBRARY or ## TAG LIBRARY: subtitle
    library_pattern = r'^## TAG LIBRARY(?::\s*(.+))?\s*$'

    lines = markdown_text.split('\n')
    in_library = False
    current_tag = None
    current_tag_lines = []
    library_count = 0

    for line_num, line in enumerate(lines, 1):
        # Check if entering a TAG LIBRARY section
        library_match = re.match(library_pattern, line, re.IGNORECASE)
        if library_match:
            in_library = True
            library_count += 1

            # Save any pending tag
            if current_tag:
                tag_library[current_tag['name']] = TagDefinition(
                    name=current_tag['name'],
                    raw_value='\n'.join(current_tag_lines).strip(),
                    source_line=current_tag['line']
                )
                current_tag = None
                current_tag_lines = []

            continue

        # Check if exiting TAG LIBRARY (horizontal rule --- or a non-tag ## heading)
        if in_library:
            # --- acts as a section divider, exiting the TAG LIBRARY
            is_horizontal_rule = re.match(r'^---+\s*$', line)
            is_non_tag_heading = line.startswith('## ') and not re.match(r'^## \[', line)
            is_tag_heading = line.startswith('## ') and re.match(r'^## \[([A-Z_][A-Z0-9_]*(?::[A-Za-z0-9_-]+)?)\]\s*$', line)

            if is_horizontal_rule or is_non_tag_heading:
                # Save any pending tag and exit TAG LIBRARY
                if current_tag:
                    tag_library[current_tag['name']] = TagDefinition(
                        name=current_tag['name'],
                        raw_value='\n'.join(current_tag_lines).strip(),
                        source_line=current_tag['line']
                    )
                    current_tag = None
                    current_tag_lines = []

                in_library = False
                continue

            elif is_tag_heading:
                tag_def_match = re.match(r'^## \[([A-Z_][A-Z0-9_]*(?::[A-Za-z0-9_-]+)?)\]\s*$', line)
                # Save previous tag if any
                if current_tag:
                    tag_library[current_tag['name']] = TagDefinition(
                        name=current_tag['name'],
                        raw_value='\n'.join(current_tag_lines).strip(),
                        source_line=current_tag['line']
                    )

                # Start new tag
                tag_name = tag_def_match.group(1)
                current_tag = {'name': tag_name, 'line': line_num}
                current_tag_lines = []
                continue

        # Accumulate tag definition lines
        if in_library and current_tag:
            current_tag_lines.append(line)

    # Save final tag if any
    if current_tag:
        tag_library[current_tag['name']] = TagDefinition(
            name=current_tag['name'],
            raw_value='\n'.join(current_tag_lines).strip(),
            source_line=current_tag['line']
        )

    # Log warning if multiple TAG LIBRARY sections found
    if library_count > 1:
        import structlog
        logger = structlog.get_logger("batch_renderer.tag_substitution")
        logger.warning("multiple_tag_libraries",
            count=library_count,
            message="Multiple TAG LIBRARY sections found. Later definitions may override earlier ones."
        )

    return tag_library


def resolve_tag_library(
    tag_library: Dict[str, TagDefinition],
    max_iterations: int = 10
) -> Dict[str, str]:
    """
    Resolve tag definitions using iterative DAG-based algorithm.

    Tags can reference other tags using {TAG_NAME} syntax within their definitions.
    This function iteratively substitutes tag references until all tags are resolved
    or a circular dependency is detected.

    Args:
        tag_library: Dictionary of TagDefinition objects
        max_iterations: Maximum number of resolution iterations

    Returns:
        Dictionary mapping tag names to fully resolved values

    Raises:
        CircularDependencyError: If circular dependencies detected
    """
    # Initialize resolved values with raw values
    for tag_def in tag_library.values():
        tag_def.resolved_value = tag_def.raw_value

    # Pattern for {TAG_NAME} or {TAG_NAME:variant} references
    curly_pattern = re.compile(r'\{([A-Z_][A-Z0-9_]*(?::[A-Za-z0-9_-]+)?)\}')

    # Iteratively resolve tags
    for iteration in range(max_iterations):
        changed = False

        for tag_name, tag_def in tag_library.items():
            current_value = tag_def.resolved_value

            # Find all {TAG} references in current value
            def replace_tag_ref(match):
                nonlocal changed
                ref_name = match.group(1)

                # Look up the referenced tag
                if ref_name in tag_library:
                    ref_value = tag_library[ref_name].resolved_value
                    changed = True
                    return ref_value
                else:
                    # Keep unresolved for now (will check after iterations)
                    return match.group(0)

            new_value = curly_pattern.sub(replace_tag_ref, current_value)
            tag_def.resolved_value = new_value

        # If nothing changed, we've converged
        if not changed:
            break

    # Check for unresolved tags (circular dependencies or undefined references)
    unresolved = set()
    for tag_name, tag_def in tag_library.items():
        remaining_refs = curly_pattern.findall(tag_def.resolved_value)
        if remaining_refs:
            unresolved.add(tag_name)

    if unresolved:
        raise CircularDependencyError(
            unresolved_tags=unresolved,
            max_iterations=max_iterations
        )

    # Return mapping of tag names to resolved values
    return {name: tag_def.resolved_value for name, tag_def in tag_library.items()}


def substitute_tags_in_text(
    text: str,
    resolved_tags: Dict[str, str],
    context: str = "in text",
    ignore_undefined: bool = False
) -> str:
    """
    Substitute [TAG_NAME] and [TAG_NAME:variant] references in text.

    Args:
        text: Text containing tag references
        resolved_tags: Dictionary of fully resolved tag values
        context: Context string for error messages (e.g., "in prompt 2.3")
        ignore_undefined: If True, log warnings instead of raising errors

    Returns:
        Text with all tag references substituted

    Raises:
        UndefinedTagError: If undefined tags found and ignore_undefined=False
    """
    # Pattern for [TAG_NAME] or [TAG_NAME:variant] references
    square_pattern = re.compile(r'\[([A-Z_][A-Z0-9_]*(?::[A-Za-z0-9_-]+)?)\]')

    # Find all tag references
    undefined = set()

    def replace_tag_ref(match):
        tag_name = match.group(1)

        if tag_name in resolved_tags:
            return resolved_tags[tag_name]
        else:
            undefined.add(tag_name)

            if ignore_undefined:
                # Log warning and leave as-is
                import structlog
                logger = structlog.get_logger("batch_renderer.tag_substitution")
                logger.warning("undefined_tag_ignored",
                    tag_name=tag_name,
                    context=context
                )
                return match.group(0)  # Leave as literal [TAG_NAME]
            else:
                # Will be handled after substitution
                return match.group(0)

    result = square_pattern.sub(replace_tag_ref, text)

    # If there are undefined tags and we're not ignoring them, raise error
    if undefined and not ignore_undefined:
        raise UndefinedTagError(
            undefined_tags=undefined,
            defined_tags=set(resolved_tags.keys()),
            context=context
        )

    return result


def process_markdown_with_tags(
    markdown_text: str,
    ignore_undefined: bool = False
) -> Tuple[str, Dict[str, str]]:
    """
    Process markdown text to extract and resolve tag library, then substitute tags.

    This is the main entry point for tag substitution in the batch renderer.

    Args:
        markdown_text: Markdown content with optional TAG LIBRARY sections
        ignore_undefined: If True, continue with warnings for undefined tags

    Returns:
        Tuple of (processed_markdown, resolved_tags_dict)
        The processed markdown has all TAG LIBRARY sections intact but no [TAG] refs

    Raises:
        UndefinedTagError: If undefined tags found and ignore_undefined=False
        CircularDependencyError: If circular tag dependencies detected
    """
    # Parse tag libraries
    tag_library = parse_tag_libraries(markdown_text)

    # If no tags defined, return as-is
    if not tag_library:
        return markdown_text, {}

    # Resolve tag definitions
    try:
        resolved_tags = resolve_tag_library(tag_library)
    except CircularDependencyError as e:
        # Log the error
        import structlog
        logger = structlog.get_logger("batch_renderer.tag_substitution")
        logger.error("circular_dependency",
            error=str(e),
            unresolved=list(e.unresolved_tags)
        )
        raise

    # Substitute tags in the markdown (outside TAG LIBRARY sections)
    # We'll process line by line to avoid substituting within TAG LIBRARY sections
    lines = markdown_text.split('\n')
    processed_lines = []
    in_library = False

    library_pattern = re.compile(r'^## TAG LIBRARY(?::\s*(.+))?\s*$', re.IGNORECASE)

    for line in lines:
        # Track TAG LIBRARY sections
        if library_pattern.match(line):
            in_library = True
            processed_lines.append(line)
            continue

        if in_library and line.startswith('## ') and not re.match(r'^## \[', line):
            in_library = False

        # Substitute tags in non-library lines
        if not in_library:
            try:
                line = substitute_tags_in_text(
                    line,
                    resolved_tags,
                    context="in markdown content",
                    ignore_undefined=ignore_undefined
                )
            except UndefinedTagError:
                # Re-raise with line context if needed
                raise

        processed_lines.append(line)

    return '\n'.join(processed_lines), resolved_tags
