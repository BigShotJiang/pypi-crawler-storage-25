"""Configuration management for batch renderer."""

import os
from pathlib import Path
from typing import Optional
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


class Config:
    """Configuration for the batch renderer."""

    def __init__(
        self,
        model: Optional[str] = None,
        output_dir: Optional[Path] = None,
        pattern: str = "concept",
        image_format: str = "png",
        flatten: bool = False,
        dry_run: bool = False,
        confirm: bool = True,
        skip_existing: bool = False,
        cache_images: bool = False,
        validation_mode: str = "hybrid",
        aspect_fix_mode: str = "auto",
        api_key: Optional[str] = None,
        cli_model: Optional[str] = None,
        cli_format: Optional[str] = None,
    ):
        """
        Initialize configuration.

        Args:
            model: Model name (default from env POE_DEFAULT_MODEL or 'Nano-Banana')
            output_dir: Output directory (default: ./out)
            pattern: Pattern name for extraction (default: 'concept')
            image_format: Image file format (default: 'png')
            flatten: Flatten output structure (default: False - use nested folders)
            dry_run: Dry run mode - extract and print only (default: False)
            confirm: Confirmation mode - ask before rendering (default: True)
            skip_existing: Skip prompts with existing output files (default: False)
            cache_images: Cache images in log folder (default: False)
            validation_mode: Metadata validation mode: strict, lenient, or hybrid (default: hybrid)
            aspect_fix_mode: Aspect ratio auto-fix mode: auto, calculated, or none (default: auto)
            api_key: Poe API key (default from env POE_API_KEY)
            cli_model: Model explicitly set via CLI (for precedence)
            cli_format: Format explicitly set via CLI (for precedence)
        """
        # Precedence: hard-coded < env < (inline metadata handled later) < CLI
        self.model = model or os.getenv("POE_DEFAULT_MODEL", "Nano-Banana")
        self.output_dir = output_dir or Path("out")
        self.pattern = pattern
        self.image_format = image_format
        self.flatten = flatten
        self.dry_run = dry_run
        self.confirm = confirm
        self.skip_existing = skip_existing
        self.cache_images = cache_images
        self.validation_mode = validation_mode
        self.aspect_fix_mode = aspect_fix_mode
        self.api_key = api_key or os.getenv("POE_API_KEY")

        # Track CLI overrides for precedence
        self.cli_model = cli_model
        self.cli_format = cli_format

        # Create output directory if it doesn't exist
        if not self.dry_run:
            self.output_dir.mkdir(parents=True, exist_ok=True)

        # Create cache directory if caching is enabled
        if self.cache_images:
            self.cache_dir = Path("logs/image_cache")
            self.cache_dir.mkdir(parents=True, exist_ok=True)
        else:
            self.cache_dir = None

    def __repr__(self) -> str:
        """String representation of config."""
        return (
            f"Config(model={self.model}, output_dir={self.output_dir}, "
            f"pattern={self.pattern}, format={self.image_format}, "
            f"flatten={self.flatten}, dry_run={self.dry_run}, "
            f"confirm={self.confirm})"
        )
