"""Tests for tag-based prompt composition (ADR-0006)."""

import pytest
from batch_renderer.tag_substitution import (
    parse_tag_libraries,
    resolve_tag_library,
    substitute_tags_in_text,
    process_markdown_with_tags,
    UndefinedTagError,
    CircularDependencyError,
)
from batch_renderer.patterns import extract_prompts


class TestParseTagLibraries:
    def test_empty_markdown_returns_empty(self):
        result = parse_tag_libraries("# Title\n\nNo library here.")
        assert result == {}

    def test_basic_tag_parsed(self, tagged_markdown):
        lib = parse_tag_libraries(tagged_markdown)
        assert "STYLE" in lib
        assert "CHARACTER" in lib

    def test_variant_tag_parsed(self, tagged_markdown):
        lib = parse_tag_libraries(tagged_markdown)
        assert "STYLE:detailed" in lib
        assert "CHARACTER:masked" in lib

    def test_tag_definition_content(self, tagged_markdown):
        lib = parse_tag_libraries(tagged_markdown)
        assert "Black ink on white" in lib["STYLE"].raw_value

    def test_variant_contains_curly_reference(self, tagged_markdown):
        lib = parse_tag_libraries(tagged_markdown)
        assert "{STYLE}" in lib["STYLE:detailed"].raw_value

    def test_separator_does_not_pollute_last_tag(self, tagged_markdown):
        lib = parse_tag_libraries(tagged_markdown)
        for tag_def in lib.values():
            assert "---" not in tag_def.raw_value

    def test_multiple_library_sections(self):
        md = """\
## TAG LIBRARY: First

## [TAG_A]
Definition A

---

## 1. Section

## TAG LIBRARY: Second

## [TAG_B]
Definition B

---
"""
        lib = parse_tag_libraries(md)
        assert "TAG_A" in lib
        assert "TAG_B" in lib

    def test_tag_library_case_insensitive_header(self):
        md = "## tag library\n\n## [MY_TAG]\nContent\n\n---\n"
        lib = parse_tag_libraries(md)
        assert "MY_TAG" in lib


class TestResolveTagLibrary:
    def test_no_references_returns_raw(self, tagged_markdown):
        lib = parse_tag_libraries(tagged_markdown)
        resolved = resolve_tag_library(lib)
        assert resolved["STYLE"] == lib["STYLE"].raw_value

    def test_curly_reference_resolved(self, tagged_markdown):
        lib = parse_tag_libraries(tagged_markdown)
        resolved = resolve_tag_library(lib)
        # STYLE:detailed is {STYLE} + additional text
        assert "Black ink on white" in resolved["STYLE:detailed"]
        assert "Meticulous precision" in resolved["STYLE:detailed"]

    def test_chain_resolved(self, tagged_markdown):
        lib = parse_tag_libraries(tagged_markdown)
        resolved = resolve_tag_library(lib)
        # CHARACTER:masked references {CHARACTER}
        assert "tall figure" in resolved["CHARACTER:masked"]
        assert "white mask" in resolved["CHARACTER:masked"]

    def test_circular_raises(self, circular_tagged_markdown):
        lib = parse_tag_libraries(circular_tagged_markdown)
        with pytest.raises(CircularDependencyError) as exc_info:
            resolve_tag_library(lib)
        assert "TAG_A" in str(exc_info.value) or "TAG_B" in str(exc_info.value)


class TestSubstituteTagsInText:
    def test_simple_substitution(self):
        resolved = {"STYLE": "Black ink on white"}
        result = substitute_tags_in_text("[STYLE]\nA cat.", resolved)
        assert "Black ink on white" in result
        assert "[STYLE]" not in result

    def test_variant_substitution(self):
        resolved = {"STYLE:detailed": "Fine crosshatching"}
        result = substitute_tags_in_text("[STYLE:detailed]\nA cat.", resolved)
        assert "Fine crosshatching" in result

    def test_multiple_tags_substituted(self):
        resolved = {"A": "Alpha", "B": "Beta"}
        result = substitute_tags_in_text("[A]\n[B]\nText.", resolved)
        assert "Alpha" in result
        assert "Beta" in result

    def test_undefined_raises_by_default(self):
        resolved = {"STYLE": "Black ink"}
        with pytest.raises(UndefinedTagError) as exc_info:
            substitute_tags_in_text("[STYLE]\n[UNDEFINED]", resolved)
        err = exc_info.value
        assert "UNDEFINED" in err.undefined_tags
        assert "STYLE" in err.defined_tags

    def test_undefined_ignored_when_flag_set(self):
        resolved = {"STYLE": "Black ink"}
        result = substitute_tags_in_text(
            "[STYLE]\n[UNDEFINED]", resolved, ignore_undefined=True
        )
        assert "Black ink" in result
        assert "[UNDEFINED]" in result  # left as literal

    def test_case_sensitivity_warning_in_error(self):
        resolved = {"WORLD_STYLE_BASE": "Style text"}
        with pytest.raises(UndefinedTagError) as exc_info:
            # Same name but different case — not matched
            substitute_tags_in_text("[WORLD_STYLE_BAZE]", resolved)
        err = exc_info.value
        # Should list available tags for debugging
        assert "WORLD_STYLE_BASE" in err.defined_tags


class TestProcessMarkdownWithTags:
    def test_no_library_returns_unchanged(self, simple_markdown):
        result, resolved = process_markdown_with_tags(simple_markdown)
        assert resolved == {}

    def test_tags_expanded_in_prompts(self, tagged_markdown):
        result, _ = process_markdown_with_tags(tagged_markdown)
        # The [STYLE] reference in prompts should be expanded
        assert "Black ink on white" in result
        # But [STYLE] as a tag name should not appear outside the library
        # (it appears in the library itself, but the prompts should show expanded text)

    def test_library_section_preserved(self, tagged_markdown):
        result, _ = process_markdown_with_tags(tagged_markdown)
        # TAG LIBRARY heading still present
        assert "## TAG LIBRARY" in result

    def test_undefined_tag_raises(self, undefined_tag_markdown):
        with pytest.raises(UndefinedTagError):
            process_markdown_with_tags(undefined_tag_markdown)

    def test_undefined_tag_ignored_with_flag(self, undefined_tag_markdown):
        result, _ = process_markdown_with_tags(
            undefined_tag_markdown, ignore_undefined=True
        )
        assert "[UNDEFINED_TAG]" in result

    def test_circular_raises(self, circular_tagged_markdown):
        with pytest.raises(CircularDependencyError):
            process_markdown_with_tags(circular_tagged_markdown)


class TestTagIntegrationWithExtractPrompts:
    def test_prompts_receive_expanded_text(self, tagged_markdown):
        prompts = extract_prompts(tagged_markdown)
        p11 = next(p for p in prompts if p.id == "1.1")
        # [STYLE] should be expanded in prompt text
        assert "Black ink on white" in p11.prompt

    def test_variant_expanded_in_prompt(self, tagged_markdown):
        prompts = extract_prompts(tagged_markdown)
        p12 = next(p for p in prompts if p.id == "1.2")
        # [STYLE:detailed] should expand and include the base {STYLE}
        assert "Black ink on white" in p12.prompt
        assert "Meticulous precision" in p12.prompt

    def test_multi_tag_prompt(self, tagged_markdown):
        prompts = extract_prompts(tagged_markdown)
        p13 = next(p for p in prompts if p.id == "1.3")
        assert "Black ink on white" in p13.prompt
        assert "tall figure" in p13.prompt
        assert "white mask" in p13.prompt

    def test_no_tag_prompt_unaffected(self, tagged_markdown):
        prompts = extract_prompts(tagged_markdown)
        p14 = next(p for p in prompts if p.id == "1.4")
        assert "plain prompt" in p14.prompt

    def test_undefined_tag_raises_from_extract(self, undefined_tag_markdown):
        with pytest.raises(UndefinedTagError):
            extract_prompts(undefined_tag_markdown)

    def test_ignore_flag_propagates(self, undefined_tag_markdown):
        prompts = extract_prompts(undefined_tag_markdown, ignore_undefined_tags=True)
        assert len(prompts) == 1
        assert "[UNDEFINED_TAG]" in prompts[0].prompt
