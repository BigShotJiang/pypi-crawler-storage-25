"""Tests for prompt extraction patterns."""

import pytest
from batch_renderer.patterns import extract_prompts, slugify, PATTERNS


class TestExtractPrompts:
    def test_basic_extraction(self, simple_markdown):
        prompts = extract_prompts(simple_markdown)
        assert len(prompts) == 3

    def test_prompt_ids(self, simple_markdown):
        prompts = extract_prompts(simple_markdown)
        ids = [p.id for p in prompts]
        assert "1.1" in ids
        assert "1.2" in ids
        assert "2.1" in ids

    def test_prompt_titles(self, simple_markdown):
        prompts = extract_prompts(simple_markdown)
        assert prompts[0].title == "First Concept"
        assert prompts[1].title == "Second Concept"
        assert prompts[2].title == "Third Concept"

    def test_sections_assigned(self, simple_markdown):
        prompts = extract_prompts(simple_markdown)
        assert prompts[0].section == "First Section"
        assert prompts[1].section == "First Section"
        assert prompts[2].section == "Second Section"

    def test_metadata_parsing(self, simple_markdown):
        prompts = extract_prompts(simple_markdown)
        p12 = next(p for p in prompts if p.id == "1.2")
        assert p12.metadata["model"] == "GPT-Image-1"
        assert p12.metadata["aspect"] == "3:2"

    def test_no_metadata_on_plain_prompt(self, simple_markdown):
        prompts = extract_prompts(simple_markdown)
        p11 = next(p for p in prompts if p.id == "1.1")
        assert p11.metadata == {}

    def test_prompt_text_captured(self, simple_markdown):
        prompts = extract_prompts(simple_markdown)
        p11 = next(p for p in prompts if p.id == "1.1")
        assert "simple prompt" in p11.prompt

    def test_source_file_recorded(self, simple_markdown):
        prompts = extract_prompts(simple_markdown, source_file="test.md")
        assert all(p.source_file == "test.md" for p in prompts)
        assert all(p.source_line is not None for p in prompts)

    def test_unknown_pattern_raises(self, simple_markdown):
        with pytest.raises(ValueError, match="Unknown pattern"):
            extract_prompts(simple_markdown, pattern_name="nonexistent")

    def test_empty_markdown_returns_empty(self):
        prompts = extract_prompts("# Just a title\n\nNo concepts here.")
        assert prompts == []

    def test_numbered_pattern(self):
        md = "## 1. Section\n\n### 1.1 Title\nPrompt text.\n"
        prompts = extract_prompts(md, pattern_name="numbered")
        assert len(prompts) == 1
        assert prompts[0].title == "Title"

    def test_simple_pattern(self):
        md = "## Section\n\n### Any Heading\nPrompt text.\n"
        prompts = extract_prompts(md, pattern_name="simple")
        assert len(prompts) == 1
        assert prompts[0].title == "Any Heading"


class TestSlugify:
    def test_basic(self):
        assert slugify("Hello World") == "hello-world"

    def test_special_chars(self):
        assert slugify("Hello, World!") == "hello-world"

    def test_underscores_become_hyphens(self):
        assert slugify("hello_world") == "hello-world"

    def test_multiple_spaces(self):
        assert slugify("hello   world") == "hello-world"

    def test_strip_leading_trailing(self):
        assert slugify("  hello  ") == "hello"

    def test_numbers_preserved(self):
        assert slugify("concept 1.1") == "concept-11"
