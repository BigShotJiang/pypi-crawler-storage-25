'''
This file contains needed sparse jax operations. Mainly for the lsmr algorithm for solving KKT systems.

Note LSMR and sym_ortho implementations are primarily copied from the scipy implementation, but rewritten in jax. 
'''

import jax.numpy as jnp
import jax
import lineax as lx
from typing import NamedTuple, Callable, Tuple
from jax.typing import ArrayLike
from jax import Array
import jax.lax as lax
#These four functions are branches for the sym_ortho funciton
def _b_zero(a:ArrayLike,b:ArrayLike)->tuple[Array, Array, Array]:
    return jnp.sign(a), jnp.zeros_like(jnp.sign(a)), jnp.abs(a)

def _a_zero(a:ArrayLike,b:ArrayLike)->tuple[Array, Array, Array]:
    return jnp.zeros_like(jnp.sign(b)), jnp.sign(b), jnp.abs(b)

def _absb_gt_absa(a:ArrayLike,b:ArrayLike)->tuple[Array, Array, Array]:
    tau = jnp.divide(a, b)
    s = jnp.sign(b)*lax.rsqrt(1 + tau**2)
    c = s * tau
    r = jnp.divide(b, s)
    return c, s, r

def _ortho_otherwise(a:ArrayLike,b:ArrayLike)->tuple[Array, Array, Array]:
    tau = jnp.divide(b,a)
    c = jnp.sign(a)*lax.rsqrt(1 + tau**2)
    s = c * tau
    r = jnp.divide(a, c)
    return c, s, r


def _sym_ortho(a:ArrayLike,b:ArrayLike)->tuple[Array, Array, Array]:
    '''
    Stable implementation of the symmetric Givens rotation. from scipy.sparse lsqr implementation. Adapted to jax.
    '''
    a = jnp.asarray(a)
    b = jnp.asarray(b)
    
    bool_list = jnp.asarray([jnp.equal(b, 0), jnp.equal(a, 0), jnp.greater(jnp.abs(b), jnp.abs(a)), 1])

    index = jnp.nonzero(bool_list, size=1)[0][0]
    return jax.lax.switch(index, [_b_zero, _a_zero, _absb_gt_absa, _ortho_otherwise], a, b)

class _ConjugateResidualState(NamedTuple):
    x: jnp.ndarray
    r: jnp.ndarray
    p: jnp.ndarray
    Ap: jnp.ndarray
    Ar: jnp.ndarray
    rAr: jax.typing.ArrayLike
    atol: float
    rtol: float
    step_number: int
    max_steps: int


def _conjugate_residual_step(
    state: _ConjugateResidualState, linear_operator: lx.AbstractLinearOperator
) -> _ConjugateResidualState:
    alpha = state.rAr / jnp.square(jnp.linalg.vector_norm(state.Ap))
    new_x = state.x + alpha * state.p
    new_r = state.r - alpha * state.Ar
    new_Ar = linear_operator(new_r)
    new_rAr = jnp.real(jnp.vdot(new_r, new_Ar))
    beta = new_rAr / state.rAr
    new_p = new_r + beta * state.p
    new_Ap = new_Ar + beta * state.Ap

    return _ConjugateResidualState(
        x=new_x,
        r=new_r,
        p=new_p,
        Ap=new_Ap,
        Ar=linear_operator @ new_p,
        rAr=new_rAr,
        atol=state.atol,
        rtol=state.rtol,
        step_number=state.step_number + 1,
        max_steps=state.max_steps,
    )


def _conjugate_residual_cond(
    state: _ConjugateResidualState,
) -> jnp.ndarray:
    return jnp.logical_and(
        jnp.greater(state.rAr, state.atol),
        jnp.less(state.step_number, state.max_steps),
    )


def conjugate_residual(
    linear_operator: lx.AbstractLinearOperator,
    rhs: jnp.ndarray,
    x0: jnp.ndarray,
    atol: float = 1e-6,
    rtol: float = 1e-6,
    max_steps: int = 1000,
) -> jnp.ndarray:
    """Conjugate Residual method for solving linear systems.

    Args:
        linear_operator (lx.LinearOperator): Linear operator representing the system.
        rhs (jax.Array): Right-hand side vector.
        x0 (jax.Array): Initial guess.
        atol (float): Absolute tolerance for convergence.
        rtol (float): Relative tolerance for convergence.
        max_steps (int): Maximum number of iterations.

    Returns:
        jax.Array: Solution vector.
    """
    initial_r = rhs - linear_operator @ x0
    initial_Ar = linear_operator @ initial_r

    init_state = _ConjugateResidualState(
        x=x0,
        r=initial_r,
        p=initial_r,
        Ap=initial_Ar,
        Ar=initial_Ar,
        rAr=jnp.vdot(initial_r, initial_Ar),
        atol=atol,
        rtol=rtol,
        step_number=0,
        max_steps=max_steps,
    )

    step_func = jax.tree_util.Partial(
        _conjugate_residual_step, linear_operator=linear_operator
    )

    state = init_state
    while _conjugate_residual_cond(state):
        state = step_func(state)

    return state.x

class _LSMRState(NamedTuple):
    u: Array
    v: Array
    h: Array
    h_bar: Array
    x: Array
    beta: ArrayLike
    alpha: ArrayLike
    alpha_bar: ArrayLike
    zeta_bar: ArrayLike
    rho: ArrayLike
    rho_bar: ArrayLike
    c_bar: ArrayLike
    s_bar: ArrayLike
    step_number: int
    max_steps: int
    '''Variables for residual estimation: (don't blame me for naming, it comes from the original paper)'''
    zeta:ArrayLike
    beta_double_dot:ArrayLike
    beta_dot:ArrayLike
    rho_dot:ArrayLike
    tau_tilde:ArrayLike
    theta_tilde:ArrayLike
    residual_estimate:ArrayLike
    d:ArrayLike
    #Variables to estimate norm(A) and cond(A):
    normAsq: ArrayLike
    maxrbar: ArrayLike
    minrbar: ArrayLike
    normA: ArrayLike
    condA: ArrayLike
    normx: ArrayLike
    termination_status: ArrayLike

status_strings = ["LSMR Converged Succesfully. System Compatible; LSMR returned minimum norm solution.",
 "LSMR Converged Succesfully. System Incompatible; LSMR returned least squares solution.",
 "LSMR Converged Succesfully. System Ill-Conditioned; LSMR returned step-regularized least squares solution.",
 "LSMR reached the maximum number of iterations.",
 "LSMR failed to converge."]

class LSMRResult(NamedTuple):
    x: Array
    succesfully_converged: ArrayLike
    termination_status: ArrayLike
    iteration_number: ArrayLike
    residual_estimate: ArrayLike
    normA: ArrayLike
    condA: ArrayLike

def _lsmr_step(
    state: _LSMRState, a_tol:ArrayLike, b_tol:ArrayLike,cond_limit:ArrayLike, norm_b:ArrayLike, damping_parameter:ArrayLike,linear_operator: Callable, linear_operator_T: Callable) -> _LSMRState:
    '''Main Part of LSMR:'''
    u = linear_operator(state.v) - state.alpha * state.u
    beta = jnp.linalg.vector_norm(u)
    u = u / beta
    v = linear_operator_T(u) - beta * state.v
    alpha = jnp.linalg.vector_norm(v)
    v = v / alpha

    c_hat, s_hat, alpha_hat = _sym_ortho(state.alpha_bar, damping_parameter)

    c,s,rho = _sym_ortho(alpha_hat, beta)
    theta = s * alpha
    alpha_bar = c * alpha

    theta_bar = state.s_bar * rho
    rho_temp = state.c_bar*rho
    c_bar, s_bar, rho_bar = _sym_ortho(rho_temp, theta)
    zeta = c_bar * state.zeta_bar
    zeta_bar = -s_bar * state.zeta_bar


    h_bar = state.h - ((theta_bar * rho)/(state.rho*state.rho_bar)) * state.h_bar
    x = state.x + (zeta/(rho*rho_bar)) * h_bar
    h = v - (theta/rho) * state.h
    '''Residual estimation variables:'''
    beta_acute = c_hat*state.beta_double_dot
    beta_check = -s_hat*state.beta_double_dot

    beta_hat = c * beta_acute
    beta_double_dot = -s * beta_acute

    c_tilde, s_tilde, rho_tilde = _sym_ortho(state.rho_dot, theta_bar)

    theta_tilde = s_tilde * rho_bar
    rho_dot = c_tilde * rho_bar
    beta_dot = -s_tilde * state.beta_dot + c_tilde * beta_hat


    tau_tilde = jnp.subtract(state.zeta, state.theta_tilde*state.tau_tilde) / rho_tilde
    tau_dot = (zeta - theta_tilde*tau_tilde) / rho_dot
    d = state.d + jnp.square(beta_check)
    residual_estimate = jnp.sqrt(d +jnp.square(beta_dot - tau_dot) + jnp.square(beta_double_dot))

    #Estimate ||A||_F and cond(A):
    normAsq = state.normAsq + jnp.square(beta)
    normA = jnp.sqrt(normAsq)
    normAsq = normAsq + jnp.square(alpha)

    maxrbar = jnp.maximum(state.maxrbar, state.rho_bar)
    minrbar = jnp.where(state.step_number>0, jnp.minimum(state.minrbar, state.rho_bar), state.minrbar)
    condA = jnp.maximum(maxrbar, rho_temp)/jnp.minimum(minrbar, rho_temp)


    norm_ATr = jnp.abs(zeta_bar)
    normx = jnp.linalg.vector_norm(x)



    rtol = b_tol*norm_b + a_tol*normA*normx

    termination_conditions = jnp.asarray([jnp.less(residual_estimate, rtol), jnp.less(norm_ATr, a_tol*normA*residual_estimate),jnp.greater_equal(condA, cond_limit), jnp.greater_equal(state.step_number + 1, state.max_steps), 1])
    termination_status = jnp.nonzero(termination_conditions, size=1)[0][0]

    return _LSMRState(
        u=u,
        v=v,
        h=h,
        h_bar=h_bar,
        x=x,
        beta=beta,
        alpha=alpha,
        alpha_bar=alpha_bar,
        zeta_bar=zeta_bar,
        rho=rho,
        rho_bar=rho_bar,
        c_bar=c_bar,
        s_bar=s_bar,
        step_number=state.step_number + 1,
        max_steps=state.max_steps,
        zeta=zeta,
        beta_double_dot=beta_double_dot,
        beta_dot=beta_dot,
        rho_dot=rho_dot,
        tau_tilde=tau_tilde,
        theta_tilde=theta_tilde,
        residual_estimate=residual_estimate,
        d=d,
        normAsq=normAsq,
        maxrbar=maxrbar,
        minrbar=minrbar,
        normA=normA,
        condA=condA,
        normx=normx,
        termination_status=termination_status
    )
def _lsmr_cond(state:_LSMRState)->Array:
    return jnp.equal(state.termination_status, 4)

def LSMR(linear_operator:Callable, rhs:ArrayLike, x0:ArrayLike, a_tol:float=1e-6, b_tol:float=1e-6, cond_limit:float=1e15, max_steps:int=1000, damping_parameter:float=0.0)->LSMRResult:
    '''LSMR algorithm for solving linear systems. Adapted to jax from the original paper and scipy implementation.'''
    rhs = jnp.asarray(rhs)
    x0 = jnp.asarray(x0)
    norm_b = jnp.linalg.vector_norm(rhs)
    transpose_operator = jax.linear_transpose(linear_operator, x0)

    def tranpose_op(v):
        return transpose_operator(v)[0]
    

    u = rhs - linear_operator(x0)
    beta = jnp.linalg.vector_norm(u)
    u = u / beta
    v = tranpose_op(u)
    alpha = jnp.linalg.vector_norm(v)
    v = jnp.where(alpha > 0, v / alpha, v) #To avoid NaNs in the case of alpha = 0. In that case, v is not used in the algorithm, so it doesn't matter what we set it to. Setting it to 0 is a safe choice.

    init_state = _LSMRState(
        u=u,
        v=v,
        h=v.copy(),
        h_bar=jnp.zeros_like(v),
        x=x0.copy(),
        beta=beta,
        alpha=alpha,
        alpha_bar=alpha,
        zeta_bar=alpha*beta,
        rho=1.0,
        rho_bar=1.0,
        c_bar=1.0,
        s_bar=0.0,
        step_number=0,
        max_steps=max_steps,
        zeta=0.0,
        beta_double_dot=beta,
        beta_dot=0.0,
        rho_dot=1.0,
        tau_tilde=0.0,
        theta_tilde=0.0,
        residual_estimate=beta,
        d=0.0,
        normAsq=jnp.square(alpha),
        maxrbar=0.0,
        minrbar=jnp.inf,
        normA=alpha,
        condA=1.0,
        normx=0.0,
        termination_status=4
    )
    

    step_func = jax.tree_util.Partial(
        _lsmr_step, a_tol=a_tol, b_tol=b_tol, cond_limit=cond_limit, norm_b=norm_b, damping_parameter=damping_parameter, linear_operator=linear_operator, linear_operator_T=tranpose_op
    )

    state = lax.while_loop(_lsmr_cond, step_func, init_state)
    return LSMRResult(
        x=state.x,
        succesfully_converged=jnp.less(state.termination_status, 4),
        termination_status=state.termination_status,
        residual_estimate=state.residual_estimate,
        normA=state.normA,
        condA=state.condA,
        iteration_number=state.step_number
    )



def _flatten_complex_to_real(complex_array:Array)->Array:
    flat_complex = jnp.ravel(complex_array)
    return jnp.concatenate([jnp.real(flat_complex), jnp.imag(flat_complex)])


def _unflatten_real_to_complex(flat_array:Array, original_shape:Tuple[int, ...])->Array:
    half_length = flat_array.shape[0] // 2
    real_part = flat_array[:half_length]
    imag_part = flat_array[half_length:]
    return (real_part + 1j * imag_part).reshape(original_shape)


def _lsmr_irfftn_linear_operator(
    flat_real_autocorr:Array,
    least_squares_weights:Array,
    autocorr_mask:Array,
    packed_shape:Tuple[int, ...],
)->Array:
    '''Real-valued view of the IRFFTN operator used by LSMR.'''
    autocorr = _unflatten_real_to_complex(flat_real_autocorr, packed_shape)
    return least_squares_weights * jnp.fft.irfftn(
        autocorr_mask * autocorr,
        s=least_squares_weights.shape,
    )


def _LSMR_irfftn(rhs:Array, x0:Array, autocorr_mask:Array, least_squares_weights:Array, a_tol:float=1e-6, b_tol:float=1e-6, cond_limit:float=1e15, max_steps:int=1000, damping_parameter:float=0.0)->LSMRResult:
    '''Solve the IRFFTN least-squares problem through a real-valued view of the packed spectrum.'''
    rhs = jnp.asarray(rhs)
    x0 = jnp.asarray(x0)
    packed_shape = x0.shape
    flat_x0 = _flatten_complex_to_real(x0)

    def linear_operator(flat_real_autocorr:Array)->Array:
        return _lsmr_irfftn_linear_operator(
            flat_real_autocorr,
            least_squares_weights=least_squares_weights,
            autocorr_mask=autocorr_mask,
            packed_shape=packed_shape,
        )

    flat_result = LSMR(
        linear_operator,
        rhs=rhs,
        x0=flat_x0,
        a_tol=a_tol,
        b_tol=b_tol,
        cond_limit=cond_limit,
        max_steps=max_steps,
        damping_parameter=damping_parameter,
    )
    residual = linear_operator(flat_result.x) - rhs
    residual_estimate = jnp.linalg.vector_norm(residual)
    transpose_operator = jax.linear_transpose(linear_operator, flat_result.x)
    norm_ATr = jnp.linalg.vector_norm(transpose_operator(residual)[0])
    norm_b = jnp.linalg.vector_norm(rhs)
    normx = jnp.linalg.vector_norm(flat_result.x)
    rtol = b_tol * norm_b + a_tol * flat_result.normA * normx
    termination_conditions = jnp.asarray([
        jnp.less(residual_estimate, rtol),
        jnp.less(norm_ATr, a_tol * flat_result.normA * residual_estimate),
        jnp.greater_equal(flat_result.condA, cond_limit),
        jnp.greater_equal(flat_result.iteration_number, max_steps),
        1,
    ])
    termination_status = jnp.nonzero(termination_conditions, size=1)[0][0]

    return LSMRResult(
        x=_unflatten_real_to_complex(flat_result.x, packed_shape),
        succesfully_converged=jnp.less(termination_status, 4),
        termination_status=termination_status,
        residual_estimate=residual_estimate,
        normA=flat_result.normA,
        condA=flat_result.condA,
        iteration_number=flat_result.iteration_number,
    )
