import jax
from jax.typing import ArrayLike
import jax.numpy as jnp
from jax import Array
import numpy as np
import proxsuite


@jax.jit
def bccb_submatrix_from_eigenvalues(v: Array, ind: Array) -> Array:
    """Return ``C[ind, ind]`` for a BCCB matrix without materializing ``C``.

    The matrix is assumed to satisfy

    ``C = F @ diag(v.ravel()) @ F.conj().T``

    where ``F`` is the unitary 2D discrete Fourier transform on arrays with the
    same shape as ``v``. For this convention, the BCCB kernel is
    ``jnp.fft.ifft2(v)``, and each matrix entry is a wrapped lookup into that
    kernel determined by the circular displacement between the corresponding
    linear indices.

    Args:
        v: Two-dimensional array of BCCB eigenvalues.
        ind: One-dimensional array of linear indices into the flattened matrix.

    Returns:
        The principal submatrix ``C[ind, ind]`` with shape
        ``(len(ind), len(ind))``.
    """

    """
    if v.ndim != 2:
        raise ValueError(f"`v` must be 2D, got shape {v.shape}.")
    """
    ind = jnp.ravel(ind)
    """
    if ind.ndim != 1:
        raise ValueError("`ind` must be convertible to a 1D array of indices.")
    """
    kernel = jnp.fft.ifft2(v)
    coords = jnp.stack(jnp.unravel_index(ind, v.shape), axis=-1)

    def gather_row(row_coord: Array) -> Array:
        delta0 = jnp.mod(coords[:, 0] - row_coord[0], v.shape[0])
        delta1 = jnp.mod(coords[:, 1] - row_coord[1], v.shape[1])
        return kernel[delta0, delta1]

    return jax.lax.map(gather_row, coords)


def numpy_bccb_submatrix_from_eigenvalues(
    output: np.ndarray, v: np.ndarray, ind: np.ndarray
) -> np.ndarray:
    """Fill ``output`` with ``C[ind, ind]`` for the BCCB matrix defined by ``v``.

    This mirrors :func:`bccb_submatrix_from_eigenvalues`, but writes directly
    into the provided ``output`` array and reuses small scratch buffers so we
    avoid materializing the full pairwise displacement grids.
    """

    if v.ndim != 2:
        raise ValueError(f"`v` must be 2D, got shape {v.shape}.")

    flat_ind = np.asarray(ind, dtype=np.intp).ravel()
    n_ind = flat_ind.size
    if output.shape != (n_ind, n_ind):
        raise ValueError(
            f"`output` must have shape {(n_ind, n_ind)}, got {output.shape}."
        )

    kernel_flat = np.real(np.fft.ifft2(v)).reshape(-1)
    n_rows, n_cols = v.shape
    row_coords, col_coords = np.unravel_index(flat_ind, v.shape)

    flat_offsets = np.empty(n_ind, dtype=np.intp)
    col_offsets = np.empty(n_ind, dtype=np.intp)

    for row_index, (row_coord, col_coord) in enumerate(
        zip(row_coords, col_coords, strict=True)
    ):
        np.subtract(row_coords, row_coord, out=flat_offsets)
        np.remainder(flat_offsets, n_rows, out=flat_offsets)
        np.multiply(flat_offsets, n_cols, out=flat_offsets)

        np.subtract(col_coords, col_coord, out=col_offsets)
        np.remainder(col_offsets, n_cols, out=col_offsets)
        flat_offsets += col_offsets

        np.take(kernel_flat, flat_offsets, out=output[row_index])

    return output


def _nnls_autocorr(autocorr_mask, rhs, far_field_indices, damping=0.0, tol=1e-5):
    n = jnp.size(far_field_indices)
    # Set up parameters for x'Qx - 2 q'x
    Q = jnp.real(
        bccb_submatrix_from_eigenvalues(autocorr_mask, far_field_indices)
    ) + damping * jnp.eye(n)
    q = jnp.real(jnp.fft.fft2(autocorr_mask * rhs))
    q_flat = jnp.ravel(q)
    q = q_flat[far_field_indices]

    Q_np = np.asarray(Q)
    q_np = -np.asarray(q)

    H = Q_np
    g = q_np
    A = None
    b = None
    C = None
    C_lower = None
    C_upper = None
    l_box = np.zeros(n)
    u_box = np.inf * np.ones(n)
    qp = proxsuite.proxqp.dense.QP(
        n, 0, 0, True, dense_backend=proxsuite.proxqp.dense.DenseBackend.PrimalDualLDLT
    )
    qp.init(H, g, A, b, C, C_lower, C_upper, l_box, u_box)
    qp.settings.verbose = False
    qp.settings.eps_abs = tol
    qp.solve()
    return qp.results.x


def feasible_mat_free_PDQIP_nnls():
    """Implementation of a feasible quadratic primual dual interior point methtod using the CVXOPT Formulation, but with matrix free methods and specialized for non-negative least squares with no linear constraints."""
    return None


def _solve_nnls_newton_system(P, p_diag, s, z, bx, bz, M=None, cg_tol=1e-4):
    """To Do: rework this to take advantage that the newton system becomes an augmented least squares system"""
    """Routine for solving the newton system arising in primal dual formulation of non-negative least-squares.
    For nestrov-todd scaling W (given via s and z, W = diag(sqrt(s)/sqrt(z))), and quadratic cost P (represented as an operator) (representing A^T A for least-squares solution of Ax - b) solves:
    [P   I ] [Delta x] = [b_x]
    [I -W'W] [Delta z] = [b_z]
    By the reduction:
    (P + W^(-1)W^(-T)) x = b_x + W^(-1)W^(-T)b_z
    We diagonally equilibriate the lhs via symmetric diagonal preconditioner D_i = (s_i/(s_i p_ii + z_i))
    Call H = (P + W^(-1)W^(-T))
    Then we are solving
    D^(1/2) H D^(1/2)w = D_i^(1/2) (b_x + W^(-1)W^(-T)b_z)
    (we need to backsolve w = D^(-1/2)x at the end)
    And for numerical stabiltiy, we explicitly expand the system matrix to:
    D^(1/2) H D^(1/2) = D^(1/2) P D^(1/2) + diag(z_i/(s_i p_ii + z_i))
    We perform the explicit expansion, as opposed to to implicitly applying the preconditioner, to avoid catastrophic numerics as z or s go to zero
    We then solve the system using pcg
    set delta_z = W^(-2)(x - b_z)
    returns delta_x delta_z
    """
    D_sqrt = jnp.sqrt(s / (s * p_diag + z))
    D_2 = z / (s * p_diag + z)

    def psd_operator(x):
        return D_sqrt * P(D_sqrt * x) + D_2

    rhs = D_sqrt * (bx + (z * bz) / s)
    delta_w = jax.scipy.sparse.linalg.cg(psd_operator, rhs, tol=cg_tol, M=M)
    delta_x = D_sqrt * delta_w
    delta_z = z / s * (delta_x - bz)
    return delta_x, delta_z
