import jax.numpy as jnp
import jax
from jax.scipy.signal import fftconvolve

def fejer_kernel_coefficients(m: int):
    k = jnp.arange(-(m-1),m)
    b = (m-jnp.abs(k))/(2*jnp.pi*m)
    return b

def autoconvolution(i, a):
    return fftconvolve(a, a, mode='same')

def jackson_kernel_coefficients(m:int, r:int):
    b_init = fejer_kernel_coefficients(m)
    b_init = jnp.pad(b_init, (r-1)*(m-1), mode='constant')
    num_loops = r-1
    b = jax.lax.fori_loop(0, num_loops, autoconvolution, b_init)
    b = jnp.fft.ifftshift(b)
    b = b/(jnp.pi*2*b[0])
    b = jnp.fft.fftshift(b)
    return b


print(jackson_kernel_coefficients(10, 1))