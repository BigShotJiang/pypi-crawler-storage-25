from typing import NamedTuple, Callable
import jax.numpy as jnp
from jax.tree_util import Partial
import jax


class PCGLSState(NamedTuple):
    x: jnp.ndarray
    h: jnp.ndarray
    r: jnp.ndarray
    s: jnp.ndarray
    p: jnp.ndarray
    sh: jnp.ndarray
    Ap: jnp.ndarray
    step_num: int


class CGLSState(NamedTuple):
    x: jnp.ndarray
    r: jnp.ndarray
    p: jnp.ndarray
    gamma: jnp.ndarray
    step_num: int


def _pcgls_step(
    A: Callable[[jnp.ndarray], jnp.ndarray],
    A_T: Callable[[jnp.ndarray], jnp.ndarray],
    M_inv: Callable[[jnp.ndarray], jnp.ndarray],
    state: PCGLSState,
) -> PCGLSState:
    Ap = A(state.p)
    alpha = state.sh / jnp.square(jnp.linalg.vector_norm(Ap))
    x = state.x + alpha * state.p
    r = state.r - alpha * Ap
    s = A_T(r)
    h = M_inv(s)
    sh = jnp.vdot(s, h)
    beta = sh / state.sh
    p = h + beta * state.p
    return PCGLSState(
        x=x, sh=sh, h=h, r=r, s=s, p=p, Ap=Ap, step_num=state.step_num + 1
    )


def _pcgls_shift_step(
    A: Callable[[jnp.ndarray], jnp.ndarray],
    A_T: Callable[[jnp.ndarray], jnp.ndarray],
    b_shift: jnp.ndarray,
    diag_shift: jnp.ndarray,  # Make sure this is sqrt(D) if the rhs matrix is A'A + D, where D is diagonal
    M_inv: Callable[[jnp.ndarray], jnp.ndarray],
    state: PCGLSState,
) -> PCGLSState:
    Ap = A(state.p)
    alpha = state.sh / (
        jnp.square(jnp.linalg.vector_norm(Ap))
        + jnp.square(jnp.linalg.vector_norm(diag_shift * state.p))
    )
    x = state.x + alpha * state.p
    r = state.r - alpha * Ap
    s = A_T(r) + (b_shift - diag_shift * x)
    h = M_inv(s)
    sh = jnp.vdot(s, h)
    beta = sh / state.sh
    p = h + beta * state.p
    return PCGLSState(
        x=x, sh=sh, h=h, r=r, s=s, p=p, Ap=Ap, step_num=state.step_num + 1
    )


def _diag_pcgls_shift_step(
    A: Callable[[jnp.ndarray], jnp.ndarray],
    A_T: Callable[[jnp.ndarray], jnp.ndarray],
    b_shift: jnp.ndarray,  # Given by P^{-1}b_2 for Least Squares system (A'A + D^2)x = A'b + b_2, where P is the preconditioner and D is the diagonal shift
    DP_invsq: jnp.ndarray,  # (DP^{-1})^2 for system A'A + D^2 right preconditioned by diagonal P^{-1}
    diag_P_inv: jnp.ndarray,
    state: CGLSState,
) -> CGLSState:
    Ap = A(diag_P_inv * (state.p))
    alpha = state.gamma / (
        jnp.square(jnp.linalg.vector_norm(Ap))
        + jnp.square(jnp.linalg.vector_norm(jnp.sqrt(DP_invsq) * state.p))
    )
    x = state.x + alpha * state.p
    r = state.r - alpha * Ap
    s = diag_P_inv * A_T(r) + (b_shift - DP_invsq * x)
    gamma = jnp.square(jnp.linalg.vector_norm(s))
    beta = gamma / state.gamma
    p = s + beta * state.p
    return CGLSState(x=x, gamma=gamma, r=r, p=p, step_num=state.step_num + 1)


def _pcgls_cond(atol: float, rtol: float, norm_0: float, maxit: int, state: PCGLSState):
    return (
        (jnp.linalg.norm(state.r) > atol)
        & (state.step_num < maxit)
        & (jnp.linalg.norm(state.r) > rtol * norm_0)
    )


def _diag_pcgls_shift_cond(
    atol: float, rtol: float, norm_0: float, maxit: int, state: CGLSState
):
    return (
        (state.gamma > atol) & (state.step_num < maxit) & (state.gamma > rtol * norm_0)
    )


def pcgls(
    A: Callable[[jnp.ndarray], jnp.ndarray],
    M_inv: Callable[[jnp.ndarray], jnp.ndarray],
    x0: jnp.ndarray,
    b: jnp.ndarray,
    atol: float,
    rtol: float,
    maxit: int,
):
    at_fun = jax.linear_transpose(A, x0)

    def A_T(x):
        return at_fun(x)[0]

    r0 = b - A(x0)
    s0 = A_T(r0)
    h0 = M_inv(s0)
    sh0 = jnp.vdot(s0, h0)
    p0 = h0
    state = PCGLSState(x=x0, h=h0, r=r0, s=s0, p=p0, sh=sh0, Ap=A(p0), step_num=0)
    cond_fun = Partial(_pcgls_cond, atol, rtol, jnp.linalg.norm(state.r), maxit)
    step_fun = Partial(_pcgls_step, A, A_T, M_inv)
    state_out = jax.lax.while_loop(cond_fun, step_fun, state)
    return state_out.x


def pcgls_shift(
    A: Callable[[jnp.ndarray], jnp.ndarray],
    M_inv: Callable[[jnp.ndarray], jnp.ndarray],
    diag_shift: jnp.ndarray,
    x0: jnp.ndarray,
    b: jnp.ndarray,
    b_shift: jnp.ndarray,
    atol: float,
    rtol: float,
    maxit: int,
) -> jnp.ndarray:
    at_fun = jax.linear_transpose(A, x0)

    def A_T(x):
        return at_fun(x)[0]

    r0 = b - A(x0)
    s0 = A_T(r0) + (b_shift - diag_shift * x0)
    h0 = M_inv(s0)
    sh0 = jnp.vdot(s0, h0)
    p0 = h0
    state = PCGLSState(x=x0, h=h0, r=r0, s=s0, p=p0, sh=sh0, Ap=A(p0), step_num=0)
    cond_fun = Partial(_pcgls_cond, atol, rtol, jnp.linalg.norm(state.r), maxit)
    step_fun = Partial(_pcgls_shift_step, A, A_T, b_shift, diag_shift, M_inv)
    state_out = jax.lax.while_loop(cond_fun, step_fun, state)
    return state_out.x


def PDIP_pcgls(
    A: Callable[[jnp.ndarray], jnp.ndarray],
    A_T: Callable[[jnp.ndarray], jnp.ndarray],
    D: jnp.ndarray,
    diag_P_inv: jnp.ndarray,
    x0: jnp.ndarray,
    b1: jnp.ndarray,
    b2: jnp.ndarray,
    atol: float,
    rtol: float,
    maxit: int,
) -> jnp.ndarray:
    """
    Solves Least Squares problem min_x ||Ax - b1||^2 + ||Dx - b2||^2 using PCGLS with diagonal right preconditioner P^{-1}.
    This function is optimized for D and P^{-1} diagonal. Namely we avoid performance regressions from XLA missing optimizations.
    """
    DP_invsq = jnp.square(diag_P_inv * D)
    b_shift = diag_P_inv * D * b2
    prec_x0 = x0
    r0 = b1 - A(diag_P_inv * prec_x0)
    s0 = diag_P_inv * A_T(r0) + (b_shift - DP_invsq * prec_x0)
    gamma0 = jnp.square(jnp.linalg.norm(s0))
    p0 = s0
    init_state = CGLSState(x=prec_x0, r=r0, p=p0, gamma=gamma0, step_num=0)
    cond_fun = Partial(_diag_pcgls_shift_cond, atol, rtol, gamma0, maxit)
    step_fun = Partial(_diag_pcgls_shift_step, A, A_T, b_shift, DP_invsq, diag_P_inv)
    state_out = jax.lax.while_loop(cond_fun, step_fun, init_state)
    return diag_P_inv * state_out.x
