from phastinterp._sparsejax import LSMRResult
from jax._src.basearray import Array
from jax import Array
from typing import Any, Callable

from .._sparsejax import LSMR
import jax
import jax.numpy as jnp
from jax.tree_util import Partial
from jax.numpy import ndarray

from .pcgls import pcgls_shift, PDIP_pcgls


def lsmr(A: Callable, b: Array, x0: Array) -> Array:
    out = LSMR(A, b, x0, a_tol=1e-9, b_tol=1e-9)
    return out.x


def preconditioned_augmented_A(A, d1, d2, x):
    Ad1x = A(d1 * x)
    return jnp.hstack([Ad1x, d2 * x])


def scaling_matrix(s: jnp.ndarray, z: jnp.ndarray) -> jnp.ndarray:
    return jnp.diag(jnp.sqrt(s) / jnp.sqrt(z))


def solve_newton_system(
    A: Callable[[jnp.ndarray], jnp.ndarray],
    A_T: Callable[[jnp.ndarray], jnp.ndarray],
    b: jnp.ndarray,
    x: jnp.ndarray,
    s: jnp.ndarray,
    z: jnp.ndarray,
    dz: jnp.ndarray,
    ds: jnp.ndarray,
    lam: jnp.ndarray,
    w: jnp.ndarray,
    a_col_norms_sq: jnp.ndarray,
    delta_x0: jnp.ndarray,
) -> tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray]:
    qz = dz - w * ds / lam
    u = b - A(x)
    v = w * z + -qz / w

    D = 1 / w
    diag_precond = jnp.sqrt(s / (s * a_col_norms_sq + z))
    delta_x = PDIP_pcgls(
        A,
        A_T,
        D,
        diag_precond,
        delta_x0,
        u,
        v,
        1e-14,
        1e-30,
        1000,
    )
    u2 = u - A(delta_x)
    v2 = v - D * delta_x
    delta_x_2 = PDIP_pcgls(
        A,
        A_T,
        D,
        diag_precond,
        jnp.zeros_like(delta_x),
        u2,
        v2,
        1e-14,
        1e-30,
        1000,
    )
    delta_x = delta_x + delta_x_2
    delta_z = jnp.square(jnp.reciprocal(w)) * (-delta_x - qz)
    delta_s = w * (ds / lam - w * delta_z)
    return delta_x, delta_z, delta_s


def max_step(z: Array, dz: Array, s: Array, ds: Array) -> Array:
    rho = ds / s
    sigma = dz / z
    alpha_inverse = jnp.maximum(-jnp.min(rho), -jnp.min(sigma))
    alpha = jnp.where(alpha_inverse > 0, 1 / alpha_inverse, 1)
    return jnp.minimum(alpha, 1)


def residuals(A: Callable, A_T: Callable, b: Array, x: Array, z: Array, s: Array):
    rx = A_T(A(x) - b) - z
    rz = s - x
    return rx, rz


def mehrotra_predictor(w: Array, delta_s: Array, delta_z: Array):
    return (delta_s / w) * (delta_z * w)


def matfreePDIP_body(
    A: Callable,
    A_T: Callable,
    a_col_norms_sq: Array,
    b: Array,
    m: int,
    value: tuple[Array, Array, Array, int, bool],
):
    x, z, s, iteration, is_nan_old = value
    w = jnp.sqrt(s) / jnp.sqrt(z)
    lam = jnp.sqrt(z * s)
    mu = jnp.linalg.vecdot(lam, lam) / m
    rx, rz = residuals(A, A_T, b, x, z, s)
    delta_xa, delta_za, delta_sa = solve_newton_system(
        A,
        A_T,
        b,
        x,
        s,
        z,
        -rz,
        -jnp.square(lam),
        lam,
        w,
        a_col_norms_sq,
        jnp.zeros_like(x),
    )
    alpha_aff = max_step(z, delta_za, s, delta_sa)
    rho = jnp.linalg.vecdot(
        z + alpha_aff * delta_za, s + alpha_aff * delta_sa
    ) / jnp.linalg.vecdot(z, s)
    sigma = jnp.power(jnp.maximum(0, jnp.minimum(1, rho)), 3)
    ds_2 = -jnp.square(lam) + sigma * mu - mehrotra_predictor(w, delta_sa, delta_za)
    delta_x, delta_z, delta_s = solve_newton_system(
        A, A_T, b, x, s, z, -rz, ds_2, lam, w, a_col_norms_sq, delta_xa
    )
    scale = jnp.maximum(0.99, 1 - mu)
    delta_scaled_s = delta_s / (w)
    delta_scaled_z = w * delta_z / (1.0)
    alpha = max_step(lam, delta_scaled_z, lam, delta_scaled_s)
    is_nan_x = jnp.isnan(scale * alpha * delta_x)
    is_nan_z = jnp.isnan(scale * alpha * delta_z)
    is_nan_s = jnp.isnan(scale * alpha * delta_s)
    is_nan = is_nan_x | is_nan_z | is_nan_s
    is_nan = jnp.any(is_nan)
    x = jax.lax.select(is_nan, x, x + scale * alpha * delta_x)
    z = jax.lax.select(is_nan, z, z + scale * alpha * delta_z)
    s = jax.lax.select(is_nan, s, s + scale * alpha * delta_s)
    return (x, z, s, iteration + 1, is_nan)


def matfreePDIP_cond(
    A: Callable, A_T: Callable, b, m, tolerance, max_iterations, value
):
    x, z, s, iteration, is_nan_old = value
    rx, rz = residuals(A, A_T, b, x, z, s)
    rx_norm = jnp.linalg.vector_norm(rx, ord=jnp.inf)
    rz_norm = jnp.linalg.vector_norm(rz, ord=jnp.inf)
    c1 = jnp.greater(rx_norm / jnp.linalg.vector_norm(b, ord=jnp.inf), tolerance)
    c2 = jnp.greater(
        rz_norm
        / (
            jnp.linalg.vector_norm(x, ord=jnp.inf)
            + jnp.linalg.vector_norm(s, ord=jnp.inf)
        ),
        tolerance,
    )
    c3 = jnp.greater(jnp.abs(jnp.vdot(z, s)), tolerance)
    c4 = jnp.less(iteration, max_iterations)
    return (c1 | c2 | c3) & c4 & ~is_nan_old


def initialize(A, b, n, epsilon) -> tuple[Array, Array, Array]:
    out: LSMRResult = LSMR(
        A,
        b,
        a_tol=1e-9,
        b_tol=1e-9,
        x0=jnp.zeros(n, dtype=b.dtype),
        damping_parameter=1.0,
        max_steps=10000,
    )
    x0: Array = out.x
    x_min = jnp.min(x0)
    s = jnp.copy(x0)
    if x_min <= epsilon:
        alpha_p = epsilon - x_min
        s0 = s + alpha_p
    else:
        s0 = s
    z = -x0
    z_min = jnp.min(z)
    if z_min <= epsilon:
        alpha_d = epsilon - z_min
        z0 = z + alpha_d
    else:
        z0 = z
    return x0, z0, s0


def matfreePDIP(
    A: Callable, b, n, a_col_norms_sq, epsilon=1.0, tolerance=1e-9, max_iterations=100
):
    x, z, s = initialize(A, b, n, epsilon)
    iteration = 0
    m = jnp.size(b)
    A_T = jax.linear_transpose(A, x)

    def A_T_op(x):
        return A_T(x)[0]

    body_func = Partial(matfreePDIP_body, A, A_T_op, a_col_norms_sq, b, m)
    cond_func = Partial(matfreePDIP_cond, A, A_T_op, b, m, tolerance, max_iterations)
    x, z, s, iteration, is_nan = jax.lax.while_loop(
        cond_func, body_func, (x, z, s, iteration, False)
    )
    return x, z, s, iteration, is_nan
