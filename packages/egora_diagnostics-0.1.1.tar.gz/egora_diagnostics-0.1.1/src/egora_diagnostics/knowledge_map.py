"""
Knowledge Map — Where does knowledge live in the model?
=========================================================
Three complementary probing techniques:

1. **Logit Lens**: Project each layer's hidden state to vocabulary space.
   Shows when factual knowledge "crystallizes" during the forward pass.

2. **Attention Probing**: Per-head accuracy on domain-specific QA.
   Identifies which heads carry factual, syntactic, or reasoning knowledge.

3. **Knowledge Concentration Index (KCI)**: Gini coefficient over head
   contributions — high KCI = knowledge concentrated in few heads (fragile),
   low KCI = knowledge distributed (robust).

Usage::

    from egora_diagnostics.knowledge_map import run_knowledge_map

    summary = run_knowledge_map(model, tokenizer, output_dir="analysis/")
    print(f"KCI: {summary['kci_overall']:.4f}")
    print(f"Factual heads: {summary['n_factual_heads']}")
"""

import json
import os
from collections import defaultdict
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch
import torch.nn.functional as F


DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Knowledge domains to probe
KNOWLEDGE_DOMAINS: Dict[str, Dict[str, List[Tuple[str, str]]]] = {
    'factual': {
        'prompts': [
            ("The capital of France is", "Paris"),
            ("The chemical symbol for water is", "H2O"),
            ("The speed of light is approximately", "300"),
            ("The largest planet in our solar system is", "Jupiter"),
            ("DNA stands for", "deoxyribonucleic"),
            ("The boiling point of water in Celsius is", "100"),
            ("Albert Einstein developed the theory of", "relativity"),
            ("The human body has approximately how many bones:", "206"),
        ],
    },
    'syntactic': {
        'prompts': [
            ("The cat sat on the", "mat"),
            ("She goes to school every", "day"),
            ("They have been waiting for", "hours"),
            ("If I had known, I would have", "gone"),
            ("Neither the students nor the teacher", "was"),
            ("The committee has made its", "decision"),
            ("Running quickly through the park,", "she"),
            ("Despite the rain, they decided to", "go"),
        ],
    },
    'reasoning': {
        'prompts': [
            ("If all cats are animals and all animals breathe, then all cats", "breathe"),
            ("2 + 2 = 4, so 4 - 2 =", "2"),
            ("If it rains, the ground gets wet. The ground is wet, so it probably", "rained"),
            ("The opposite of hot is", "cold"),
            ("If A is bigger than B and B is bigger than C, then A is bigger than", "C"),
            ("Monday comes before Tuesday, and Tuesday comes before", "Wednesday"),
        ],
    },
}


def logit_lens(
    model: torch.nn.Module,
    tokenizer,
    prompts: Optional[List[Tuple[str, str]]] = None,
    max_prompts: int = 20,
) -> Dict[str, Any]:
    """Project each layer's hidden state to vocab space (logit lens).

    For each prompt, records which layer first predicts the correct next token.

    Args:
        model: A HuggingFace causal LM.
        tokenizer: The tokenizer.
        prompts: List of ``(prompt_text, domain_label)`` tuples.
            Defaults to built-in knowledge domain prompts.
        max_prompts: Maximum number of prompts to process.

    Returns:
        Dict with ``layer_accuracy``, ``n_layers``, and ``first_correct`` details.
    """
    if prompts is None:
        prompts = []
        for domain, data in KNOWLEDGE_DOMAINS.items():
            for p, _ in data['prompts']:
                prompts.append((p, domain))

    model.eval()
    n_layers = model.config.num_hidden_layers
    layer_correct = np.zeros(n_layers)
    layer_total = np.zeros(n_layers)
    first_correct_layer = []

    lm_head = None
    if hasattr(model, 'lm_head'):
        lm_head = model.lm_head
    elif hasattr(model, 'embed_out'):
        lm_head = model.embed_out

    if lm_head is None:
        return {}

    for prompt_text, domain in prompts[:max_prompts]:
        tokens = tokenizer(prompt_text, return_tensors='pt').to(DEVICE)
        with torch.no_grad():
            outputs = model(**tokens, output_hidden_states=True)

        hidden_states = outputs.hidden_states
        target_id = outputs.logits[0, -1].argmax().item()

        found_first = None
        for layer_idx in range(n_layers):
            hs = hidden_states[layer_idx + 1]
            logits_at_layer = lm_head(hs[0, -1:])
            pred = logits_at_layer.argmax(-1).item()
            layer_total[layer_idx] += 1
            if pred == target_id:
                layer_correct[layer_idx] += 1
                if found_first is None:
                    found_first = layer_idx

        if found_first is not None:
            first_correct_layer.append({
                'prompt': prompt_text, 'domain': domain,
                'first_correct_layer': found_first,
                'fraction_through': found_first / n_layers,
            })

    layer_accuracy = layer_correct / np.maximum(layer_total, 1)

    return {
        'layer_accuracy': layer_accuracy.tolist(),
        'n_layers': n_layers,
        'first_correct': first_correct_layer,
    }


def attention_probe(
    model: torch.nn.Module,
    tokenizer,
    target_modules: Optional[List[str]] = None,
    max_samples: int = 50,
) -> Dict[str, Any]:
    """Per-head probing: which heads respond to which knowledge domains.

    For each domain, measures how much each head's attention pattern
    changes when the answer token is present vs absent.

    Args:
        model: A HuggingFace causal LM.
        tokenizer: The tokenizer.
        target_modules: Projection names (unused, kept for API compat).
        max_samples: Max samples per domain.

    Returns:
        Dict with ``domain_scores``, ``head_assignments``, ``n_layers``, ``n_heads``.
    """
    model.eval()
    n_layers = model.config.num_hidden_layers
    n_heads = model.config.num_attention_heads

    domain_scores: Dict[str, Any] = {}

    for domain, data in KNOWLEDGE_DOMAINS.items():
        head_activations = np.zeros((n_layers, n_heads))
        n_processed = 0

        for prompt, answer in data['prompts'][:max_samples]:
            full = prompt + " " + answer
            try:
                tokens = tokenizer(full, return_tensors='pt').to(DEVICE)

                attentions = None
                try:
                    with torch.no_grad():
                        out = model(**tokens, output_attentions=True)
                    attentions = out.attentions
                except Exception:
                    pass

                if attentions is not None:
                    for layer_idx, attn in enumerate(attentions):
                        if layer_idx >= n_layers:
                            break
                        attn_matrix = attn[0]
                        nh = min(attn_matrix.shape[0], n_heads)
                        last_col = attn_matrix[:nh, :, -1].mean(dim=1)
                        head_activations[layer_idx, :nh] += last_col.cpu().numpy()
                else:
                    with torch.no_grad():
                        out = model(**tokens, output_hidden_states=True)
                    hidden_states = out.hidden_states
                    for layer_idx in range(min(n_layers, len(hidden_states) - 1)):
                        h_prev = hidden_states[layer_idx][0, -1]
                        h_next = hidden_states[layer_idx + 1][0, -1]
                        delta = (h_next - h_prev).float()
                        head_dim = delta.shape[0] // n_heads
                        for hi in range(n_heads):
                            chunk = delta[hi * head_dim:(hi + 1) * head_dim]
                            head_activations[layer_idx, hi] += chunk.norm().item()

                n_processed += 1
            except Exception:
                continue

        if n_processed > 0:
            head_activations /= n_processed

        domain_scores[domain] = head_activations.tolist()

    # Classify each head by dominant domain
    head_assignments = []
    for layer in range(n_layers):
        for head in range(n_heads):
            scores = {d: domain_scores[d][layer][head] for d in KNOWLEDGE_DOMAINS}
            dominant = max(scores, key=scores.get)
            head_assignments.append({
                'layer': layer, 'head': head,
                'dominant_domain': dominant,
                'scores': scores,
                'specificity': max(scores.values()) / (sum(scores.values()) + 1e-10),
            })

    return {
        'domain_scores': domain_scores,
        'head_assignments': head_assignments,
        'n_layers': n_layers,
        'n_heads': n_heads,
    }


def knowledge_concentration_index(
    head_assignments: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """Compute Gini coefficient over head contributions per domain.

    High KCI = knowledge concentrated in few heads (fragile).
    Low KCI = knowledge distributed (robust).

    Args:
        head_assignments: List from :func:`attention_probe` output.

    Returns:
        Dict with ``per_domain`` Gini values and ``overall`` KCI.
    """
    kci_per_domain = {}
    for domain in KNOWLEDGE_DOMAINS:
        specificities = [h['scores'][domain] for h in head_assignments]
        specificities = np.array(sorted(specificities))
        n = len(specificities)
        if n == 0 or specificities.sum() == 0:
            kci_per_domain[domain] = 0.0
            continue
        index = np.arange(1, n + 1)
        gini = (2 * np.sum(index * specificities) / (n * np.sum(specificities))) - (n + 1) / n
        kci_per_domain[domain] = float(gini)

    overall_kci = float(np.mean(list(kci_per_domain.values())))
    return {'per_domain': kci_per_domain, 'overall': overall_kci}


def run_knowledge_map(
    model: torch.nn.Module,
    tokenizer,
    output_dir: str,
    target_modules: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Full knowledge mapping pipeline.

    Saves to ``knowledge_map/`` subfolder:
      - ``logit_lens.json``
      - ``attention_probe.json``
      - ``head_assignments.json``
      - ``kci.json``
      - ``knowledge_map_summary.json``

    Args:
        model: A HuggingFace causal LM.
        tokenizer: The tokenizer.
        output_dir: Base output directory.
        target_modules: Projection names for attention probe.

    Returns:
        Summary dict with KCI, head counts, and crystallization info.
    """
    km_dir = os.path.join(output_dir, 'knowledge_map')
    os.makedirs(km_dir, exist_ok=True)

    # 1. Logit lens
    lens_results = logit_lens(model, tokenizer)
    with open(os.path.join(km_dir, 'logit_lens.json'), 'w') as f:
        json.dump(lens_results, f, indent=2)

    # 2. Attention probing
    probe_results = attention_probe(model, tokenizer, target_modules)
    with open(os.path.join(km_dir, 'head_assignments.json'), 'w') as f:
        json.dump(probe_results['head_assignments'], f, indent=2)
    with open(os.path.join(km_dir, 'attention_probe.json'), 'w') as f:
        json.dump({k: v for k, v in probe_results.items()
                   if k != 'head_assignments'}, f, indent=2)

    # 3. Knowledge concentration index
    kci = knowledge_concentration_index(probe_results['head_assignments'])
    with open(os.path.join(km_dir, 'kci.json'), 'w') as f:
        json.dump(kci, f, indent=2)

    # 4. Summary
    summary: Dict[str, Any] = {
        'n_layers': probe_results.get('n_layers'),
        'n_heads': probe_results.get('n_heads'),
        'kci_overall': kci['overall'],
        'kci_per_domain': kci['per_domain'],
        'n_factual_heads': sum(1 for h in probe_results['head_assignments']
                               if h['dominant_domain'] == 'factual'),
        'n_syntactic_heads': sum(1 for h in probe_results['head_assignments']
                                 if h['dominant_domain'] == 'syntactic'),
        'n_reasoning_heads': sum(1 for h in probe_results['head_assignments']
                                 if h['dominant_domain'] == 'reasoning'),
    }
    if lens_results.get('first_correct'):
        avg_crystal = np.mean([x['first_correct_layer']
                               for x in lens_results['first_correct']])
        summary['avg_crystallization_layer'] = float(avg_crystal)
        summary['crystallization_fraction'] = float(
            avg_crystal / lens_results.get('n_layers', 1))

    with open(os.path.join(km_dir, 'knowledge_map_summary.json'), 'w') as f:
        json.dump(summary, f, indent=2)

    return summary
