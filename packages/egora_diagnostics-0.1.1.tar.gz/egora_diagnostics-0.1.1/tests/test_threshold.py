"""Unit tests for egora_diagnostics.threshold."""

import math
import tempfile
import os
import numpy as np
import pytest


def test_predicted_threshold_128():
    """arcsin(1/sqrt(128)) should be ~5.06 degrees."""
    from egora_diagnostics.threshold import predicted_threshold
    t = predicted_threshold(128)
    assert abs(t - 5.06) < 0.1


def test_predicted_threshold_64():
    """arcsin(1/sqrt(64)) = arcsin(1/8) ~ 7.18 degrees."""
    from egora_diagnostics.threshold import predicted_threshold
    t = predicted_threshold(64)
    assert abs(t - 7.18) < 0.1


def test_check_dimensionality_basic():
    """check_dimensionality_threshold returns valid result dict."""
    from egora_diagnostics.threshold import check_dimensionality_threshold

    np.random.seed(42)
    thetas = np.concatenate([
        np.random.normal(2.0, 0.5, 50),   # preserved
        np.random.normal(8.0, 1.0, 30),   # damaged
    ])
    result = check_dimensionality_threshold(thetas, d_head=128, model_name="test")

    assert result["d_head"] == 128
    assert result["n_heads"] == 80
    assert 0 <= result["damaged_at_predicted"] <= 100
    assert 0 <= result["damaged_at_5deg"] <= 100


def test_check_dimensionality_with_output(tmp_path):
    """Saves JSON when output_dir is provided."""
    from egora_diagnostics.threshold import check_dimensionality_threshold

    thetas = np.random.uniform(1, 10, 50)
    result = check_dimensionality_threshold(
        thetas, d_head=128, output_dir=str(tmp_path)
    )
    assert os.path.exists(os.path.join(str(tmp_path), "dimensionality_threshold.json"))


def test_golden_ratio_k():
    """check_golden_ratio_k computes k correctly."""
    from egora_diagnostics.threshold import check_golden_ratio_k

    result = check_golden_ratio_k(theta_bar=5.0, mmlu_delta=-3.0)
    assert result["k"] == pytest.approx(0.6, abs=0.01)
    assert "one_over_phi" in result
    assert "relative_error_pct" in result


def test_golden_ratio_k_zero_theta():
    """k is None when theta_bar is too small."""
    from egora_diagnostics.threshold import check_golden_ratio_k

    result = check_golden_ratio_k(theta_bar=0.001, mmlu_delta=-1.0)
    assert result["k"] is None


def test_golden_ratio_k_aggregate():
    """Aggregate k comparison returns best match."""
    from egora_diagnostics.threshold import check_golden_ratio_k_aggregate

    k_values = [0.45, 0.60, 0.45, 0.76, 0.69, 0.91, 0.51, 0.59, 0.22]
    result = check_golden_ratio_k_aggregate(k_values)

    assert result["n_conditions"] == 9
    assert "mean_k" in result
    assert "best_match" in result
    assert result["best_match"] in result["comparisons"]


def test_check_phase_transition():
    """Phase transition check returns valid result (requires scipy)."""
    pytest.importorskip("scipy")
    from egora_diagnostics.threshold import check_phase_transition

    theta = [2.33, 2.07, 2.57, 6.89, 6.93, 6.09, 6.16, 7.00, 7.14]
    loss = [1.04, 1.89, 0.56, 3.11, 4.15, 4.61, 4.26, 3.56, 4.22]

    result = check_phase_transition(theta, loss)
    assert "f_statistic" in result
    assert "p_value" in result
    assert "conclusion" in result
    assert isinstance(result["is_phase_transition"], bool)


def test_check_phase_transition_too_few():
    """Returns error with < 5 data points."""
    pytest.importorskip("scipy")
    from egora_diagnostics.threshold import check_phase_transition

    result = check_phase_transition([1, 2, 3], [0.5, 1.0, 1.5])
    assert "error" in result


def test_head_dims_lookup():
    """HEAD_DIMS contains known architectures."""
    from egora_diagnostics.threshold import HEAD_DIMS

    assert HEAD_DIMS["llama_8b"] == 128
    assert HEAD_DIMS["llama_1b"] == 64
    assert HEAD_DIMS["phi3_mini"] == 96


def test_run_threshold_analysis_no_dhead():
    """Returns error when d_head can't be determined."""
    from egora_diagnostics.threshold import run_threshold_analysis

    result = run_threshold_analysis({}, model_name="unknown_model")
    assert "error" in result


def test_run_threshold_analysis_basic(tmp_path):
    """Full pipeline runs on synthetic geometry data."""
    from egora_diagnostics.threshold import run_threshold_analysis

    geometry = {
        "theta_bar_deg": 5.0,
        "heads": [{"rotation_angle_deg": float(a)} for a in np.random.uniform(1, 10, 32)],
    }

    result = run_threshold_analysis(
        geometry,
        model_name="llama_8b",
        mmlu_base=63.42,
        mmlu_after=60.0,
        output_dir=str(tmp_path),
    )

    assert result["d_head"] == 128
    assert "dimensionality_check" in result
    assert "golden_ratio_k" in result
    assert os.path.exists(os.path.join(str(tmp_path), "threshold_analysis", "threshold_analysis_summary.json"))
