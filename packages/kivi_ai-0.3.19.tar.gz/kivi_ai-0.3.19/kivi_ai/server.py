"""Unified AI Chat Server — FastAPI routing layer."""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import uuid
from pathlib import Path
from typing import Any

import httpx

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s %(levelname)s %(name)s: %(message)s')
logger = logging.getLogger("kivi.server")

import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse, FileResponse
from starlette.middleware.cors import CORSMiddleware

from .core.registry import Registry
from .core.types import ChunkType, Message, ProviderType, Role, StreamChunk, ToolCall, ToolResult
from .providers.config import DEFAULT_MODELS, estimate_cost
from .sessions.compaction import check_and_compact
from .sessions.manager import SessionManager
from .sessions.store import SQLiteSessionStore
from .streaming.adapter import normalize_stream
from .streaming.sse import stream_to_sse
from .tools.builtins import register_builtin_tools

VLLM_URL = os.environ.get("VLLM_URL", "http://192.168.170.49:8077")
OPENCODE_URL = os.environ.get("OPENCODE_URL", "http://127.0.0.1:4096")
WORK_DIR = os.path.expanduser("~")
KIVI_MD_PATH = Path.home() / ".kivi" / "KIVI.md"

DEFAULT_KIVI_MD = """\
# KIVI.md

## Output
- LaTeX: `$...$` inline, `$$...$$` block
- Markdown with syntax-highlighted code blocks

## Render Tags
To display files inline, use `<render_inline>` tags:
- `<render_inline type="image" src="/path/to/file.png"/>` — image preview
- `<render_inline type="video" src="/path/to/file.mp4"/>` — video player
- `<render_inline type="text" src="/path/to/file.txt"/>` — file content
- `<render_inline type="file" src="/path/to/file.pdf"/>` — download link
Only use render_inline when you want to display the file. Plain paths stay as text.
"""

app = FastAPI(title="Unified AI Chat")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ── Globals ──────────────────────────────────────────────────────────
_session_manager: SessionManager | None = None
_kivi_md: str = ""

# Active agent/streaming sessions tracker
# { session_id: { provider, model, mode, start_time, status, tool_count, last_event } }
_active_agents: dict[str, dict[str, Any]] = {}


def _load_kivi_md() -> str:
    global _kivi_md
    if not KIVI_MD_PATH.exists():
        KIVI_MD_PATH.parent.mkdir(parents=True, exist_ok=True)
        KIVI_MD_PATH.write_text(DEFAULT_KIVI_MD)
    _kivi_md = KIVI_MD_PATH.read_text().strip()
    return _kivi_md


def _mgr() -> SessionManager:
    global _session_manager
    if _session_manager is None:
        _session_manager = SessionManager()
    return _session_manager


# ── Lifecycle ────────────────────────────────────────────────────────

@app.on_event("startup")
async def startup():
    _load_kivi_md()
    register_builtin_tools()
    _register_providers()
    await Registry.initialize_all()


@app.on_event("shutdown")
async def shutdown():
    await Registry.shutdown_all()


def _register_providers():
    from .providers.openai_provider import OpenAIProvider
    from .providers.copilot_provider import CopilotProvider
    from .providers.claude_provider import ClaudeProvider

    # OpenAI (direct API)
    Registry.register_provider("openai", OpenAIProvider(
        api_key=os.environ.get("OPENAI_API_KEY", "sk-xxx"),
    ))

    VLLM_MODEL = os.environ.get("VLLM_MODEL", "default")

    # vLLM (OpenAI-compatible local)
    Registry.register_provider("vllm", OpenAIProvider(
        api_key="sk-xxx",
        base_url=f"{VLLM_URL}/v1",
        default_model=VLLM_MODEL,
        provider_label="vllm",
    ))

    # GitHub Copilot
    Registry.register_provider("copilot", CopilotProvider())

    # Copilot + vLLM backend
    Registry.register_provider("qwen-copilot", CopilotProvider(vllm_url=VLLM_URL))

    # Claude (Anthropic)
    Registry.register_provider("claude", ClaudeProvider())

    # Claude + vLLM backend
    Registry.register_provider("qwen-claude", ClaudeProvider(vllm_url=VLLM_URL))


# ── Unified Chat Streaming ──────────────────────────────────────────

@app.post("/api/chat/stream")
async def chat_stream(request: Request):
    """Unified streaming endpoint for all providers.

    Body: {
        session_id: str (optional — creates new if missing),
        provider: "openai"|"vllm"|"copilot"|"qwen-copilot"|"claude"|"qwen-claude",
        model: str (optional),
        messages: [{role, content}] (current conversation),
        system_prompt: str (optional),
        temperature: float (optional),
    }
    """
    data = await request.json()
    provider_name = data.get("provider", "openai")
    model = data.get("model", "")
    session_id = data.get("session_id")
    raw_messages = data.get("messages", [])
    system_prompt = data.get("system_prompt")
    # Append KIVI.md to any system prompt (skills/render tags available to all modes)
    if _kivi_md and system_prompt:
        system_prompt = system_prompt + "\n\n---\n" + _kivi_md
    temperature = data.get("temperature")
    top_p = data.get("top_p")
    top_k = data.get("top_k")
    presence_penalty = data.get("presence_penalty")
    repetition_penalty = data.get("repetition_penalty")
    enable_thinking = data.get("enable_thinking", True)

    try:
        provider = Registry.get_provider(provider_name)
    except KeyError as e:
        return JSONResponse({"error": str(e)}, status_code=400)

    if not model:
        # Map compound provider names to their base ProviderType for default model lookup
        _provider_type_map = {
            "openai": ProviderType.OPENAI, "vllm": ProviderType.OPENAI,
            "copilot": ProviderType.COPILOT, "qwen-copilot": ProviderType.COPILOT,
            "claude": ProviderType.CLAUDE, "qwen-claude": ProviderType.CLAUDE,
        }
        base_type = _provider_type_map.get(provider_name, ProviderType.OPENAI)
        model = DEFAULT_MODELS.get(base_type, "gpt-4.1")

    mgr = _mgr()

    # Create or load session
    if not session_id:
        title = "Untitled"
        if raw_messages:
            for m in raw_messages:
                if m.get("role") == "user":
                    title = SessionManager.generate_title(m.get("content", ""))
                    break
        session_id = await mgr.create_session(provider=provider_name, model=model, title=title)
    else:
        session = await mgr.get_session(session_id)
        if not session:
            session_id = await mgr.create_session(provider=provider_name, model=model, title="Untitled")

    # Convert raw messages to Message objects
    messages = [Message.from_dict(m) for m in raw_messages]

    # Store only the NEW user message (last one from frontend)
    if messages and messages[-1].role == Role.USER:
        await mgr.add_message(session_id, messages[-1])

    # Update session provider/model if changed
    await mgr.update_session(session_id, provider=provider_name, model=model)

    # Build the authoritative message list from DB (source of truth)
    # This ensures session reload works — all persisted messages are included
    stored_messages = await mgr.get_messages(session_id)
    if stored_messages:
        messages = stored_messages

    # Check compaction before streaming
    use_vllm = provider_name.startswith("qwen-")

    # Tool schemas are sent based on mode — server decides, not the UI
    # chat mode = no tools; all other modes (kivi, copilot, claude, qwen-*) = full tool set
    mode = data.get("mode", "kivi")
    tool_schemas = None
    if mode != "chat" and provider.supports_tools:
        tools_list = Registry.list_tools()
        if tools_list:
            tool_schemas = [t.schema for t in tools_list]
    logger.debug(f"REQUEST mode={mode} provider={provider_name} model={model} tools={[t.name for t in tool_schemas] if tool_schemas else None} enable_thinking={enable_thinking}")

    async def generate():
        # Register as active agent
        _active_agents[session_id] = {
            "provider": provider_name,
            "model": model,
            "mode": mode,
            "start_time": time.time(),
            "status": "running",
            "tool_count": 0,
            "last_event": time.time(),
            "title": "",
        }
        # Get title from session or first message
        try:
            s = await mgr.get_session(session_id)
            if s:
                _active_agents[session_id]["title"] = s.get("title", "")
        except Exception:
            pass
        if not _active_agents[session_id]["title"] and raw_messages:
            for m in raw_messages:
                if m.get("role") == "user":
                    _active_agents[session_id]["title"] = m.get("content", "")[:60]
                    break

        try:
            # Compaction check
            compaction_chunk = await check_and_compact(session_id, mgr, provider, model)
            if compaction_chunk:
                yield f"data: {json.dumps(compaction_chunk.to_sse_dict())}\n\n"
                # Reload messages after compaction
                stored = await mgr.get_messages(session_id)
                messages_to_send = stored
            else:
                messages_to_send = messages

            # Emit session_id for the frontend
            yield f"data: {json.dumps({'type': 'session', 'session_id': session_id})}\n\n"

        # Tool execution loop — keeps going until model produces text (no tool calls)
            current_messages = list(messages_to_send)
            full_content = ""
            full_thinking = ""
            stream_meta: dict[str, Any] = {}
            tool_round = 0

            while True:
                tool_round += 1
                round_content = ""
                round_thinking = ""
                round_tool_calls: list[dict] = []
                logger.debug(f"ROUND {tool_round} starting, messages={len(current_messages)}")

                try:
                    raw_stream = provider.stream(
                        current_messages, model,
                        tools=tool_schemas,
                        system_prompt=system_prompt,
                        temperature=temperature,
                        top_p=top_p,
                        top_k=top_k,
                        presence_penalty=presence_penalty,
                        repetition_penalty=repetition_penalty,
                        enable_thinking=enable_thinking,
                        use_vllm=use_vllm,
                    )
                    async for chunk in normalize_stream(raw_stream):
                        if chunk.type == ChunkType.DELTA:
                            round_content += chunk.content
                        elif chunk.type == ChunkType.THINKING_DELTA:
                            round_thinking += chunk.content
                        elif chunk.type == ChunkType.DONE:
                            stream_meta = chunk.metadata
                            round_tool_calls = stream_meta.get("tool_calls", [])
                            logger.debug(f"ROUND {tool_round} DONE: tool_calls={[tc['name'] for tc in round_tool_calls]} content_len={len(round_content)} thinking_len={len(round_thinking)}")
                            continue
                        elif chunk.type == ChunkType.TOOL_START:
                            logger.debug(f"ROUND {tool_round} TOOL_START: {chunk.metadata}")
                            if session_id in _active_agents:
                                _active_agents[session_id]["tool_count"] += 1
                                _active_agents[session_id]["last_event"] = time.time()
                        yield f"data: {json.dumps(chunk.to_sse_dict())}\n\n"
                except Exception as e:
                    yield f"data: {json.dumps({'type': 'error', 'content': str(e)})}\n\n"
                    yield "data: [DONE]\n\n"
                    return

                full_content += round_content
                full_thinking += round_thinking

                # If no tool calls, we're done
                if not round_tool_calls:
                    break

                # Execute each tool call
                # First, add assistant message with tool calls to context and persist it
                assistant_tc_msg = Message(
                    role=Role.ASSISTANT,
                    content=round_content,
                    tool_calls=[
                        ToolCall(id=tc["id"], name=tc["name"], arguments=tc["arguments"])
                        for tc in round_tool_calls
                    ],
                )
                current_messages.append(assistant_tc_msg)
                await mgr.add_message(session_id, assistant_tc_msg)

                tool_results_for_msg: list[ToolResult] = []
                for tc in round_tool_calls:
                    tool_name = tc["name"]
                    tool_args = tc["arguments"]
                    tool_call_id = tc["id"]

                    # Execute the tool
                    try:
                        tool_impl = Registry.get_tool(tool_name)
                        result = await tool_impl.execute(tool_args, work_dir=WORK_DIR)

                        # Emit tool_complete event
                        yield f"data: {json.dumps({'type': 'tool_complete', 'tool_call_id': tool_call_id, 'name': tool_name, 'result': result.content, 'is_error': result.is_error})}\n\n"

                        tool_results_for_msg.append(ToolResult(
                            tool_call_id=tool_call_id,
                            content=result.content,
                            is_error=result.is_error,
                        ))
                    except Exception as e:
                        error_msg = f"Tool '{tool_name}' failed: {str(e)}"
                        yield f"data: {json.dumps({'type': 'tool_complete', 'tool_call_id': tool_call_id, 'name': tool_name, 'result': error_msg, 'is_error': True})}\n\n"
                        tool_results_for_msg.append(ToolResult(
                            tool_call_id=tool_call_id,
                            content=error_msg,
                            is_error=True,
                        ))

                # Add tool results as a message for next round and persist
                tool_result_msg = Message(
                    role=Role.TOOL,
                    content="",
                    tool_results=tool_results_for_msg,
                )
                current_messages.append(tool_result_msg)
                await mgr.add_message(session_id, tool_result_msg)

                # Signal UI that model is processing tool results
                yield f"data: {json.dumps({'type': 'processing'})}\n\n"

            # Store final assistant response (the text reply, not tool-call rounds)
            if full_content or full_thinking:
                assistant_msg = Message(
                    role=Role.ASSISTANT,
                    content=full_content,
                    thinking=full_thinking or None,
                    metadata={"model": model, "provider": provider_name},
                )
                await mgr.add_message(session_id, assistant_msg)

            # Log token usage
            input_tokens = stream_meta.get("input_tokens", 0)
            output_tokens = stream_meta.get("output_tokens", 0)
            if not input_tokens:
                input_tokens = provider.count_tokens(" ".join(m.content for m in messages), model)
            if not output_tokens:
                output_tokens = provider.count_tokens(full_content, model)
            cost = stream_meta.get("cost_usd", estimate_cost(model, input_tokens, output_tokens))
            await mgr.log_usage(session_id, model, input_tokens, output_tokens, cost)

            # Send final DONE with token/cost metadata
            yield f"data: {json.dumps({'type': 'done', 'content': '', 'input_tokens': input_tokens, 'output_tokens': output_tokens, 'cost_usd': cost, 'model': model})}\n\n"

        finally:
            # Mark agent as completed
            if session_id in _active_agents:
                _active_agents[session_id]["status"] = "done"
                _active_agents[session_id]["end_time"] = time.time()

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ── OpenCode Proxy ───────────────────────────────────────────────────

OPENCODE_DEFAULT_MODEL = "deepseek/deepseek-v4-flash:free"

# kivi_session_id → opencode_session_id mapping
_opencode_sessions: dict[str, str] = {}
# kivi_session_id → opencode model id
_opencode_models: dict[str, str] = {}


@app.get("/api/opencode/models")
async def opencode_models():
    """Proxy opencode model list — free models first, then alphabetical."""
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get(f"{OPENCODE_URL}/api/model", headers={"Accept": "application/json"})
            r.raise_for_status()
            items = r.json()
            if isinstance(items, dict):
                items = items.get("items", [])
        models = [{"id": m["id"], "name": m.get("name", m["id"])} for m in items]
        models.sort(key=lambda m: (0 if "free" in m["id"].lower() or "free" in m["name"].lower() else 1, m["name"].lower()))
        return JSONResponse(models)
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=502)


async def _opencode_get_session(kivi_sid: str) -> str:
    """Return opencode session ID for this kivi session, creating one if needed."""
    if kivi_sid in _opencode_sessions:
        return _opencode_sessions[kivi_sid]
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.post(
            f"{OPENCODE_URL}/session",
            headers={"Accept": "application/json", "Content-Type": "application/json"},
            json={},
        )
        r.raise_for_status()
        oc_sid = r.json()["id"]
    _opencode_sessions[kivi_sid] = oc_sid
    return oc_sid


@app.post("/api/opencode/chat")
async def opencode_chat(request: Request):
    """Stream opencode response via /event SSE + prompt_async."""
    data = await request.json()
    user_text = data.get("message", "")
    kivi_sid = data.get("session_id") or f"oc-{uuid.uuid4().hex[:8]}"
    model_id = data.get("model") or _opencode_models.get(kivi_sid) or OPENCODE_DEFAULT_MODEL
    _opencode_models[kivi_sid] = model_id

    async def generate():
        oc_sid = ""
        try:
            oc_sid = await _opencode_get_session(kivi_sid)
            yield f"data: {json.dumps({'type': 'session', 'session_id': kivi_sid})}\n\n"

            # Queue for events from the SSE reader coroutine
            q: asyncio.Queue = asyncio.Queue()

            async def read_events():
                """Subscribe to opencode /event and push relevant events to q."""
                try:
                    async with httpx.AsyncClient(timeout=None) as client:
                        async with client.stream(
                            "GET", f"{OPENCODE_URL}/event",
                            headers={"Accept": "text/event-stream"},
                        ) as resp:
                            async for raw_line in resp.aiter_lines():
                                raw_line = raw_line.strip()
                                if not raw_line.startswith("data: "):
                                    continue
                                try:
                                    evt = json.loads(raw_line[6:])
                                except Exception:
                                    continue
                                props = evt.get("properties", {})
                                if props.get("sessionID") == oc_sid or evt.get("type") == "server.connected":
                                    await q.put(evt)
                                    if evt.get("type") == "session.idle" and props.get("sessionID") == oc_sid:
                                        break
                except Exception as exc:
                    await q.put({"__error": str(exc)})
                finally:
                    await q.put(None)  # sentinel

            # Start event reader
            reader_task = asyncio.create_task(read_events())

            # Wait for server.connected before firing prompt
            while True:
                evt = await asyncio.wait_for(q.get(), timeout=5)
                if evt and evt.get("type") == "server.connected":
                    break

            # Fire prompt asynchronously
            async with httpx.AsyncClient(timeout=10) as client:
                r = await client.post(
                    f"{OPENCODE_URL}/session/{oc_sid}/prompt_async",
                    headers={"Accept": "application/json", "Content-Type": "application/json"},
                    json={"parts": [{"type": "text", "text": user_text}], "modelID": model_id},
                )
                r.raise_for_status()

            # Track which partIDs are reasoning vs text
            reasoning_parts: set[str] = set()
            # Track tool states: callID → last status
            tool_states: dict[str, str] = {}
            input_tokens = 0
            output_tokens = 0
            cost = 0.0
            model = "opencode"

            while True:
                try:
                    evt = await asyncio.wait_for(q.get(), timeout=120)
                except asyncio.TimeoutError:
                    break

                if evt is None:
                    break
                if "__error" in evt:
                    yield f"data: {json.dumps({'type': 'error', 'content': evt['__error']})}\n\n"
                    break

                etype = evt.get("type", "")
                props = evt.get("properties", {})

                if etype == "message.part.delta":
                    part_id = props.get("partID", "")
                    field = props.get("field", "")
                    delta = props.get("delta", "")
                    if field == "text" and delta:
                        if part_id in reasoning_parts:
                            yield f"data: {json.dumps({'type': 'thinking_delta', 'content': delta})}\n\n"
                        else:
                            yield f"data: {json.dumps({'type': 'delta', 'content': delta})}\n\n"

                elif etype == "message.part.updated":
                    part = props.get("part", {})
                    ptype = part.get("type", "")
                    part_id = part.get("id", "")

                    if ptype == "reasoning":
                        reasoning_parts.add(part_id)

                    elif ptype == "tool":
                        call_id = part.get("callID", "")
                        tool_name = part.get("tool", "unknown")
                        state = part.get("state", {})
                        status = state.get("status", "")
                        prev_status = tool_states.get(call_id, "")

                        if status == "running" and prev_status != "running":
                            tool_states[call_id] = "running"
                            inp = state.get("input", {})
                            desc = state.get("metadata", {}).get("description") or inp.get("description") or ""
                            yield f"data: {json.dumps({'type': 'tool_start', 'tool_call_id': call_id, 'name': tool_name, 'arguments': inp, 'description': desc})}\n\n"

                        elif status == "completed" and prev_status != "completed":
                            tool_states[call_id] = "completed"
                            out = state.get("output", "") or state.get("metadata", {}).get("output", "")
                            yield f"data: {json.dumps({'type': 'tool_complete', 'tool_call_id': call_id, 'name': tool_name, 'result': str(out)[:2000], 'is_error': False})}\n\n"

                    elif ptype == "step-finish":
                        tokens = part.get("tokens", {})
                        if tokens:
                            input_tokens += tokens.get("input", 0)
                            output_tokens += tokens.get("output", 0)
                            cost += part.get("cost", 0)
                            model = part.get("modelID", model)

                elif etype == "session.idle" and props.get("sessionID") == oc_sid:
                    break

            reader_task.cancel()
            yield f"data: {json.dumps({'type': 'done', 'content': '', 'input_tokens': input_tokens, 'output_tokens': output_tokens, 'cost_usd': cost, 'model': model})}\n\n"

        except Exception as exc:
            logger.error(f"opencode_chat error: {exc}", exc_info=True)
            yield f"data: {json.dumps({'type': 'error', 'content': str(exc)})}\n\n"

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ── Session API ──────────────────────────────────────────────────────

@app.get("/api/agents")
async def list_agents():
    """Return active and recently completed agent sessions."""
    now = time.time()
    # Clean up old completed agents (keep last 30 minutes)
    stale = [k for k, v in _active_agents.items() if v["status"] == "done" and now - v.get("end_time", now) > 1800]
    for k in stale:
        del _active_agents[k]

    agents = []
    for sid, info in _active_agents.items():
        elapsed = now - info["start_time"]
        agents.append({
            "session_id": sid,
            "title": info.get("title", ""),
            "provider": info["provider"],
            "model": info["model"],
            "mode": info["mode"],
            "status": info["status"],
            "elapsed": round(elapsed, 1),
            "tool_count": info["tool_count"],
            "start_time": info["start_time"],
            "end_time": info.get("end_time"),
        })
    # Sort: running first, then by start_time desc
    agents.sort(key=lambda a: (0 if a["status"] == "running" else 1, -a["start_time"]))
    return JSONResponse(agents)


@app.get("/api/sessions")
async def list_sessions():
    return JSONResponse(await _mgr().list_sessions())


@app.get("/api/sessions/{session_id}")
async def get_session(session_id: str):
    s = await _mgr().get_session(session_id)
    if not s:
        return JSONResponse({"error": "not found"}, status_code=404)
    return JSONResponse(s)


@app.post("/api/sessions")
async def create_session(request: Request):
    data = await request.json()
    sid = await _mgr().create_session(
        provider=data.get("provider", "openai"),
        model=data.get("model", ""),
        title=data.get("title", "Untitled"),
    )
    return JSONResponse({"id": sid})


@app.put("/api/sessions/{session_id}")
async def update_session(session_id: str, request: Request):
    data = await request.json()
    await _mgr().update_session(session_id, **data)
    return JSONResponse({"ok": True})


@app.delete("/api/sessions/{session_id}")
async def delete_session(session_id: str):
    await _mgr().delete_session(session_id)
    return JSONResponse({"ok": True})


@app.get("/api/sessions/{session_id}/messages")
async def get_session_messages(session_id: str):
    msgs = await _mgr().get_messages(session_id)
    return JSONResponse([m.to_dict() for m in msgs])


# ── Provider switching ───────────────────────────────────────────────

@app.post("/api/sessions/{session_id}/switch")
async def switch_provider(session_id: str, request: Request):
    data = await request.json()
    provider = data.get("provider", "openai")
    model = data.get("model", "")
    await _mgr().switch_provider(session_id, provider, model)
    return JSONResponse({"ok": True, "provider": provider, "model": model})


# ── Provider & model discovery ───────────────────────────────────────

@app.get("/api/providers")
async def list_providers():
    providers = []
    for name in Registry.list_providers():
        p = Registry.get_provider(name)
        providers.append({
            "name": name,
            "supports_streaming": p.supports_streaming,
            "supports_tools": p.supports_tools,
            "supports_thinking": p.supports_thinking,
        })
    return JSONResponse(providers)


@app.get("/api/models/{provider_name}")
async def list_models(provider_name: str):
    try:
        provider = Registry.get_provider(provider_name)
        models = await provider.list_models()
        return JSONResponse([m.to_dict() for m in models])
    except KeyError as e:
        return JSONResponse({"error": str(e)}, status_code=404)


# ── Tool listing ─────────────────────────────────────────────────────

@app.get("/api/tools")
async def list_tools():
    tools = Registry.list_tools()
    return JSONResponse([t.schema.to_openai_schema() for t in tools])


# ── KIVI.md ──────────────────────────────────────────────────────────

@app.get("/api/kivi-md")
async def get_kivi_md():
    return JSONResponse({"content": _kivi_md, "path": str(KIVI_MD_PATH)})


@app.post("/api/kivi-md/reload")
async def reload_kivi_md():
    _load_kivi_md()
    return JSONResponse({"ok": True, "content": _kivi_md})


# ── Usage stats ──────────────────────────────────────────────────────

@app.get("/api/usage")
async def usage_stats():
    return JSONResponse(await _mgr().store.get_usage_stats())


@app.get("/api/usage/{session_id}")
async def session_usage(session_id: str):
    return JSONResponse(await _mgr().store.get_usage_stats(session_id))


# ── File utilities (carried over from old server) ────────────────────

@app.get("/api/files")
async def search_files(q: str = "", cwd: str = "", limit: int = 5):
    search_dir = cwd or os.path.expanduser("~")
    if not os.path.isdir(search_dir):
        search_dir = os.path.expanduser("~")
    try:
        proc = await asyncio.create_subprocess_exec(
            "rg", "--files",
            "--glob", "!node_modules", "--glob", "!__pycache__",
            "--glob", "!*.pyc", "--glob", "!.*/",
            search_dir,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
        files = stdout.decode().strip().splitlines()
        if q:
            q_lower = q.lower()
            scored = []
            for f in files:
                fname = os.path.basename(f).lower()
                if q_lower in fname:
                    scored.append((0, f))
                elif q_lower in f.lower():
                    scored.append((1, f))
            scored.sort(key=lambda x: (x[0], len(x[1])))
            return JSONResponse([s[1] for s in scored[:limit]])
        return JSONResponse(files[:limit])
    except Exception:
        return JSONResponse([])


@app.get("/api/file-preview")
async def file_preview(path: str):
    path = os.path.expanduser(path)
    resolved = os.path.realpath(path)
    # Sandbox: only serve files under user's home directory
    home = os.path.expanduser("~")
    if not resolved.startswith(home):
        return JSONResponse({"error": "Access denied: path outside home directory"}, status_code=403)
    if not os.path.isfile(resolved):
        return JSONResponse({"error": "File not found"}, status_code=404)
    ext = os.path.splitext(path)[1].lower()
    mime_map = {
        ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
        ".gif": "image/gif", ".webp": "image/webp", ".svg": "image/svg+xml",
        ".mp4": "video/mp4", ".webm": "video/webm",
        ".txt": "text/plain", ".md": "text/markdown",
        ".json": "application/json", ".csv": "text/csv",
        ".py": "text/plain", ".js": "text/plain", ".html": "text/html",
        ".pdf": "application/pdf",
    }
    mime = mime_map.get(ext, "application/octet-stream")
    return FileResponse(path, media_type=mime)


# ── Git endpoints (carried over) ─────────────────────────────────────

@app.get("/api/git/diff")
async def git_diff(path: str):
    if not os.path.isdir(path):
        return JSONResponse({"error": "Not a directory"}, status_code=400)

    async def run(cmd):
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, cwd=path
        )
        out, err = await proc.communicate()
        return proc.returncode, out.decode().strip(), err.decode().strip()

    rc, _, _ = await run(["git", "rev-parse", "--is-inside-work-tree"])
    if rc != 0:
        return JSONResponse({"error": "Not a git repo"}, status_code=400)

    _, branch, _ = await run(["git", "branch", "--show-current"])
    _, status, _ = await run(["git", "status", "--short"])
    _, staged, _ = await run(["git", "diff", "--cached"])
    _, unstaged, _ = await run(["git", "diff"])
    _, log_out, _ = await run(["git", "log", "-10", "--format=%H|%h|%s|%an|%ai"])

    commits = []
    for line in log_out.splitlines():
        parts = line.split("|", 4)
        if len(parts) >= 5:
            commits.append({"sha": parts[0], "short": parts[1], "msg": parts[2], "author": parts[3], "date": parts[4]})

    return JSONResponse({
        "branch": branch, "status": status, "staged": staged,
        "unstaged": unstaged, "commits": commits,
        "has_changes": bool(status.strip()),
    })


@app.post("/api/git/commit")
async def git_commit(request: Request):
    data = await request.json()
    path, message = data.get("path", ""), data.get("message", "")
    if not path or not message:
        return JSONResponse({"error": "path and message required"}, status_code=400)

    async def run(cmd):
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, cwd=path
        )
        out, err = await proc.communicate()
        return proc.returncode, out.decode().strip(), err.decode().strip()

    stage = data.get("files")
    if stage:
        for f in stage:
            await run(["git", "add", f])
    else:
        await run(["git", "add", "-A"])
    rc, out, err = await run(["git", "commit", "-m", message])
    return JSONResponse({"success": rc == 0, "output": out or err})


@app.post("/api/git/push")
async def git_push(request: Request):
    data = await request.json()
    path = data.get("path", "")
    proc = await asyncio.create_subprocess_exec(
        "git", "push", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, cwd=path
    )
    out, err = await proc.communicate()
    return JSONResponse({"success": proc.returncode == 0, "output": (out or err or b"").decode().strip()})


# ── Serve frontend ───────────────────────────────────────────────────

from fastapi.staticfiles import StaticFiles
from starlette.middleware.base import BaseHTTPMiddleware

class NoCacheStaticMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        response = await call_next(request)
        if request.url.path.startswith("/static/"):
            response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        return response

app.add_middleware(NoCacheStaticMiddleware)

_frontend_dir = Path(__file__).parent / "frontend"
app.mount("/static/css", StaticFiles(directory=str(_frontend_dir / "css")), name="static-css")
app.mount("/static/js", StaticFiles(directory=str(_frontend_dir / "js")), name="static-js")


@app.get("/")
async def serve_index():
    html_path = _frontend_dir / "index.html"
    if not html_path.exists():
        return HTMLResponse("<h1>Unified AI Chat</h1><p>Frontend not built yet.</p>")
    return HTMLResponse(html_path.read_text())


# ── Entry point ──────────────────────────────────────────────────────

def main():
    print("Unified AI Chat → http://localhost:8899")
    uvicorn.run(app, host="0.0.0.0", port=8899, log_level="info")


if __name__ == "__main__":
    main()
