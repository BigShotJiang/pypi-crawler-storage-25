import asyncio
import base64
import contextlib
import json
import signal
import sqlite3
import sys
import termios
import tty
import uuid
from dataclasses import dataclass
from pathlib import Path

from openai import AsyncOpenAI
from kivi_ai.tools.builtins import BashTool, ReadTool, WriteTool, GlobTool, GrepTool, WebSearchTool
from kivi_ai.core.interfaces import ToolInterface
from kivi_ai.rich import Live

BASE_URL = "http://192.168.170.76:8077/v1"
MODEL = "/home/ng6309/datascience/santhosh/models/qwen3-4b"

client = AsyncOpenAI(base_url=BASE_URL, api_key="x")


# --- tools registry ---

tools_map: dict[str, ToolInterface] = {
    t.schema.name: t for t in [BashTool(), ReadTool(), WriteTool(), GlobTool(), GrepTool(), WebSearchTool()]
}

permissions: dict[str, list[str]] = {
    "allow": ["bash", "read", "write", "glob", "grep", "web_search"],
}


def allowed_schemas() -> list[dict]:
    return [tools_map[n].schema.to_openai_schema() for n in permissions["allow"] if n in tools_map]


async def call_tool(name: str, arguments: str) -> str:
    if name not in permissions["allow"]:
        return f"[denied: {name} not in allow list]"
    return (await tools_map[name].execute(json.loads(arguments))).content


# --- events ---

@dataclass
class TextChunk:
    text: str
    def __str__(self): return self.text

@dataclass
class ToolCall:
    id: str
    name: str
    arguments: str
    def __str__(self): return f"\n[tool:{self.name} args={self.arguments}]\n"

@dataclass
class ToolResult:
    id: str
    name: str
    result: str
    def __str__(self): return f"\n[result:{self.name} => {self.result}]\n"


# --- session ---

DB_PATH = Path(__file__).parent / "session.db"


def _db() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH)
    con.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            session_id TEXT,
            message    TEXT
        )
    """)
    con.commit()
    return con


class Session:
    def __init__(self, session_id: str | None = None):
        self.session_id = session_id or uuid.uuid4().hex
        self.messages: list[dict] = []
        self._con = _db()
        if session_id:
            self._load()
        print(f"session: {self.session_id}")

    def _load(self):
        rows = self._con.execute(
            "SELECT message FROM sessions WHERE session_id=? ORDER BY rowid",
            (self.session_id,)
        ).fetchall()
        self.messages = [json.loads(r[0]) for r in rows]
        print(f"loaded {len(self.messages)} messages")

    def _save(self, msg: dict):
        self._con.execute(
            "INSERT INTO sessions VALUES (?,?)",
            (self.session_id, json.dumps(msg))
        )
        self._con.commit()

    def add(self, role: str, content):
        msg = {"role": role, "content": content}
        self.messages.append(msg)
        self._save(msg)

    def add_tool_calls(self, calls: list[ToolCall]):
        msg = {
            "role": "assistant", "content": None,
            "tool_calls": [
                {"id": c.id, "type": "function", "function": {"name": c.name, "arguments": c.arguments}}
                for c in calls
            ],
        }
        self.messages.append(msg)
        self._save(msg)

    def add_tool_result(self, tr: ToolResult):
        msg = {"role": "tool", "tool_call_id": tr.id, "name": tr.name, "content": tr.result}
        self.messages.append(msg)
        self._save(msg)


# --- input file helpers ---

def _read_input_file(path: str) -> list[dict]:
    p = Path(path)
    suffix = p.suffix.lower()

    if suffix == ".pdf":
        import fitz
        doc = fitz.open(str(p))
        parts = []
        for page in doc:
            pix = page.get_pixmap(matrix=fitz.Matrix(2, 2))
            b64 = base64.b64encode(pix.tobytes("jpeg")).decode()
            parts.append({"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}})
        return parts

    if suffix in (".png", ".jpg", ".jpeg", ".webp", ".gif"):
        mime = {"png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
                ".webp": "image/webp", ".gif": "image/gif"}.get(suffix, "image/png")
        b64 = base64.b64encode(p.read_bytes()).decode()
        return [{"type": "image_url", "image_url": {"url": f"data:{mime};base64,{b64}"}}]

    return [{"type": "text", "text": p.read_text(errors="replace")}]


# --- cancel context ---

@contextlib.contextmanager
def interruptible_stdin():
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    tty.setcbreak(fd)
    cancelled = asyncio.Event()
    loop = asyncio.get_event_loop()
    loop.add_reader(fd, lambda: cancelled.set() if sys.stdin.buffer.read(1) in (b"\x1b", b"\x03") else None)
    loop.add_signal_handler(signal.SIGINT, cancelled.set)
    try:
        yield cancelled
    finally:
        loop.remove_reader(fd)
        loop.remove_signal_handler(signal.SIGINT)
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


# --- streaming ---

async def stream_events(session: Session, think: bool = False, params: dict | None = None):
    kwargs = {"model": MODEL, "messages": session.messages, "stream": True,
              "tools": allowed_schemas(),
              "extra_body": {"chat_template_kwargs": {"enable_thinking": think}},
              **(params or {})}
    stream = await client.chat.completions.create(**kwargs)
    tool_calls: dict[int, ToolCall] = {}

    with interruptible_stdin() as cancelled:
        async for chunk in stream:
            if cancelled.is_set():
                break
            delta = chunk.choices[0].delta
            if delta.content:
                yield TextChunk(delta.content)
            for tc in delta.tool_calls or []:
                t = tool_calls.setdefault(tc.index, ToolCall(tc.id or "", tc.function.name or "", ""))
                t.arguments += tc.function.arguments or ""

    for tc in tool_calls.values():
        yield tc


# --- agent loop ---

async def run_agentic(session: Session, user_input: str, think: bool = False, params: dict | None = None):
    session.add("user", user_input)
    while True:
        text, calls = "", []
        with Live() as live:
            async for event in stream_events(session, think=think, params=params):
                if isinstance(event, TextChunk):
                    live.write(event.text)
                    text += event.text
                elif isinstance(event, ToolCall):
                    calls.append(event)
        if text:  session.add("assistant", text)
        if not calls: break
        # pre-tool hook
        session.add_tool_calls(calls)
        for tc in calls:
            result = await call_tool(tc.name, tc.arguments)
            tr = ToolResult(id=tc.id, name=tc.name, result=str(result))
            # print(tr, flush=True)
            # post-tool hook
            session.add_tool_result(tr)


async def run_once(session: Session, think: bool = False, params: dict | None = None):
    with Live() as live:
        async for event in stream_events(session, think=think, params=params):
            if isinstance(event, TextChunk):
                live.write(event.text)


# --- entry point ---

async def main():
    import argparse
    parser = argparse.ArgumentParser(prog="agent")
    parser.add_argument("-p", "--prompt", help="prompt string (non-interactive)")
    parser.add_argument("-i", "--input", help="input file (pdf/image/text) — single LLM call, no agent loop")
    parser.add_argument("--resume", metavar="SESSION_ID", help="resume a previous session")
    parser.add_argument("--think", action="store_true", help="enable thinking mode")
    parser.add_argument("--params", help='extra chat completion params as JSON e.g. \'{"temperature":0.7}\'')
    args, rest = parser.parse_known_args()
    if rest and not args.prompt:
        args.prompt = " ".join(rest)

    params = json.loads(args.params) if args.params else None
    session = Session(session_id=args.resume)

    if args.input:
        parts = _read_input_file(args.input)
        prompt = args.prompt or "Describe this."
        session.add("user", [{"type": "text", "text": prompt}] + parts)
        await run_once(session, think=args.think, params=params)
        return

    if args.prompt:
        await run_agentic(session, args.prompt, think=args.think, params=params)
        return

    first = True
    while True:
        try:
            if not first:
                print()
            user_input = input("\033[38;2;143;188;143mai\033[0m: ").strip()
            first = False
        except (EOFError, KeyboardInterrupt):
            break
        if user_input:
            print()
            await run_agentic(session, user_input, think=args.think, params=params)


if __name__ == "__main__":
    asyncio.run(main())
