"""Minimal live-streaming markdown renderer. Zero deps, pure ANSI."""
import re
import sys

# ANSI
RESET  = "\033[0m"
BOLD   = "\033[1m"
ITALIC = "\033[3m"
DIM    = "\033[2m"
SAGE   = "\033[38;2;143;188;143m"
CYAN   = "\033[36m"
YELLOW = "\033[33m"
BG_DARK= "\033[48;2;40;44;52m"
WHITE  = "\033[97m"


def _ansi_len(s: str) -> int:
    return len(re.sub(r'\033\[[^m]*m', '', s))


def _inline(text: str) -> str:
    text = text.replace("<br>", "\n")
    text = re.sub(r'`([^`]+)`', lambda m: f"{BG_DARK}{CYAN}{m.group(1)}{RESET}", text)
    text = re.sub(r'\*\*\*(.+?)\*\*\*', lambda m: f"{BOLD}{ITALIC}{m.group(1)}{RESET}", text)
    text = re.sub(r'\*\*(.+?)\*\*', lambda m: f"{BOLD}{m.group(1)}{RESET}", text)
    text = re.sub(r'\*(.+?)\*', lambda m: f"{ITALIC}{m.group(1)}{RESET}", text)
    return text


def _is_table_row(line: str) -> bool:
    return bool(re.match(r'^\s*\|', line))

def _is_separator(line: str) -> bool:
    return bool(re.match(r'^\s*\|[\s\-|:]+\|\s*$', line))

def _parse_row(line: str) -> list[str]:
    line = line.strip().strip('|')
    return [c.strip() for c in line.split('|')]


def _strip_md(text: str) -> str:
    text = re.sub(r'\*{1,3}(.+?)\*{1,3}', r'\1', text)
    text = re.sub(r'`([^`]+)`', r'\1', text)
    return text.strip()


def _wrap(text: str, width: int) -> list[str]:
    words, lines, cur = text.split(), [], ""
    for w in words:
        if cur and len(cur) + 1 + len(w) > width:
            lines.append(cur)
            cur = w
        else:
            cur = (cur + " " + w).strip()
    if cur:
        lines.append(cur)
    return lines or [""]


def _render_table(rows: list[str]) -> str:
    parsed = [_parse_row(r) for r in rows if not _is_separator(r)]
    if not parsed:
        return ""
    ncols = max(len(r) for r in parsed)
    for r in parsed:
        while len(r) < ncols:
            r.append("")

    # terminal width budget
    try:
        term_w = __import__("shutil").get_terminal_size().columns
    except Exception:
        term_w = 100
    # borders take ncols+1 chars + 2 spaces per col
    budget = term_w - (ncols + 1) - (ncols * 2)
    budget = max(budget, ncols * 8)

    # natural widths from stripped text
    nat = [0] * ncols
    for r in parsed:
        for i, cell in enumerate(r):
            nat[i] = max(nat[i], len(_strip_md(cell)))

    # scale down proportionally if overflow
    total = sum(nat)
    if total > budget:
        widths = [max(6, int(n / total * budget)) for n in nat]
    else:
        widths = nat

    def border(l, m, r_, h="─"):
        segs = [h * (widths[i] + 2) for i in range(ncols)]
        return f"{DIM}{l}{m.join(segs)}{r_}{RESET}"

    def fmt_row(cells, is_header=False):
        # wrap each cell
        wrapped = [_wrap(_strip_md(c) if is_header else c.replace("<br>", " "), widths[i])
                   for i, c in enumerate(cells)]
        height = max(len(w) for w in wrapped)
        out = []
        for ln in range(height):
            parts = []
            for i in range(ncols):
                raw = wrapped[i][ln] if ln < len(wrapped[i]) else ""
                rendered = f"{BOLD}{raw}{RESET}" if is_header else _inline(raw)
                pad = widths[i] - len(raw)
                parts.append(f" {rendered}{' ' * pad} ")
            out.append(f"{DIM}│{RESET}" + f"{DIM}│{RESET}".join(parts) + f"{DIM}│{RESET}")
        return "\n".join(out)

    lines = [border("┌", "┬", "┐")]
    for idx, row in enumerate(parsed):
        lines.append(fmt_row(row, is_header=(idx == 0)))
        lines.append(border("├" if idx == 0 else "├", "┼" if idx == 0 else "┼", "┤" if idx == 0 else "┤"))
    lines[-1] = border("└", "┴", "┘")
    return "\n".join(lines)


def _term_width() -> int:
    try:
        return __import__("shutil").get_terminal_size().columns
    except Exception:
        return 100


def render_line(line: str) -> str:
    m = re.match(r'^(#{1,6})\s+(.*)', line)
    if m:
        level = len(m.group(1))
        color = BOLD + (SAGE if level == 1 else YELLOW if level == 2 else WHITE)
        return f"{color}{_inline(m.group(2))}{RESET}"

    if re.match(r'^[-*_]{3,}\s*$', line):
        return f"{DIM}{'─' * _term_width()}{RESET}"

    m = re.match(r'^(\s*)[*\-+]\s+(.*)', line)
    if m:
        indent = m.group(1)
        wrapped = _wrap(m.group(2), _term_width() - len(indent) - 2)
        first = f"{indent}{SAGE}•{RESET} {_inline(wrapped[0])}"
        rest = [f"{indent}  {_inline(l)}" for l in wrapped[1:]]
        return "\n".join([first] + rest)

    m = re.match(r'^(\s*)(\d+)\.\s+(.*)', line)
    if m:
        return f"{m.group(1)}{SAGE}{m.group(2)}.{RESET} {_inline(m.group(3))}"

    m = re.match(r'^>\s?(.*)', line)
    if m:
        return f"{DIM}{ITALIC}│ {_inline(m.group(1))}{RESET}"

    # plain paragraph — word wrap to terminal width
    if line.strip():
        w = _term_width()
        rendered = _inline(line)
        # wrap on raw text width (no ANSI), re-inline each chunk
        chunks = _wrap(_strip_md(line), w)
        if len(chunks) <= 1:
            return rendered
        return "\n".join(_inline(c) for c in chunks)

    return ""


class Live:
    def __init__(self, file=None):
        self._file = file or sys.stdout
        self._buf = ""
        self._in_code_block = False
        self._table_buf: list[str] = []

    def write(self, token: str):
        self._buf += token
        while "\n" in self._buf:
            line, self._buf = self._buf.split("\n", 1)
            self._flush_line(line)

    def _flush_line(self, line: str):
        if self._in_code_block:
            if re.match(r'^```', line):
                self._in_code_block = False
                self._print(f"{BG_DARK}{DIM}└─{RESET}")
            else:
                self._print(f"{BG_DARK}{CYAN}{line}{RESET}")
            return

        if re.match(r'^```(\w*)', line):
            lang = re.match(r'^```(\w*)', line).group(1)
            self._in_code_block = True
            label = f" {lang} " if lang else "─"
            self._print(f"{BG_DARK}{DIM}┌── {label}{'─' * max(0, _term_width() - 6 - len(label))}┐{RESET}")
            return

        # table buffering
        if _is_table_row(line):
            self._table_buf.append(line)
            return

        # flush table if we just left it
        if self._table_buf:
            self._print(_render_table(self._table_buf))
            self._table_buf = []

        self._print(render_line(line))

    def _print(self, text: str):
        self._file.write(text + "\n")
        self._file.flush()

    def flush(self):
        if self._table_buf:
            self._print(_render_table(self._table_buf))
            self._table_buf = []
        if self._buf:
            self._flush_line(self._buf)
            self._buf = ""

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.flush()
