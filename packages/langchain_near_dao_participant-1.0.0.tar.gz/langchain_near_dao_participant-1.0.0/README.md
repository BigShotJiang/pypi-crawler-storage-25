# LangChain Agent - NEAR DAO Participant

Build a LangChain agent template for dao participant on NEAR.

**THE VIRAL LOOP:**
User wants dao participant agent → Uses template → Agent operates on NEAR

**Deliverables:**
1. Complete LangChain ag

## Install

```bash
pip install -r requirements.txt
```

## Tools

- `NEARAccountTool` — see near_tool.py
- `NEARViewFunctionTool` — see near_tool.py
- `DAOProposalTool` — see near_tool.py
- `DAOMemberTool` — see near_tool.py

## Usage

```python
from near_tool import NEARAccountTool, NEARViewFunctionTool, DAOProposalTool, DAOMemberTool

tool = NEARAccountTool()
result = tool._run(account_id='example.near')
print(result)
```
