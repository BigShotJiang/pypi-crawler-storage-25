"""
LangChain tools for NEAR Protocol.
Generated for: LangChain Agent - NEAR DAO Participant
"""
import requests
import json
import base64
from typing import Optional, Type, Any, List, Dict, Union, Tuple, Set, Callable
from pydantic import BaseModel, Field

try:
    from langchain.tools import BaseTool
except ImportError:
    from langchain_core.tools import BaseTool  # langchain v0.2+

NEAR_RPC_MAINNET = "https://rpc.mainnet.near.org"
NEAR_RPC_TESTNET = "https://rpc.testnet.near.org"


def _near_rpc(method: str, params: Any, network: str = "mainnet") -> dict:
    """Execute NEAR JSON-RPC call."""
    url = NEAR_RPC_MAINNET if network == "mainnet" else NEAR_RPC_TESTNET
    resp = requests.post(url, json={"jsonrpc":"2.0","id":"1","method":method,"params":params}, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    if "error" in data:
        raise RuntimeError(f"NEAR RPC error: {data['error']}")
    return data.get("result", {})


class NEARAccountInput(BaseModel):
    account_id: str = Field(description="NEAR account ID (e.g. example.near)")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARAccountTool(BaseTool):
    """Query NEAR account balance and storage info."""
    name: str = "near_account_info"
    description: str = "Get NEAR account balance and info. Input: account_id, network (optional)"
    args_schema: Type[BaseModel] = NEARAccountInput

    def _run(self, account_id: str, network: str = "mainnet") -> str:
        result = _near_rpc("query", {
            "request_type": "view_account", "finality": "final", "account_id": account_id
        }, network)
        near = int(result.get("amount", 0)) / 10**24
        return json.dumps({"account_id": account_id, "balance_near": f"{near:.4f}",
            "storage_bytes": result.get("storage_usage", 0)})

    async def _arun(self, account_id: str, network: str = "mainnet") -> str:
        return self._run(account_id, network)


class NEARViewFunctionInput(BaseModel):
    contract_id: str = Field(description="NEAR contract ID")
    method_name: str = Field(description="View method name")
    args: dict = Field(default={}, description="Method arguments")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARViewFunctionTool(BaseTool):
    """Call a view function on a NEAR smart contract."""
    name: str = "near_view_function"
    description: str = "Call a NEAR contract view function. Input: contract_id, method_name, args"
    args_schema: Type[BaseModel] = NEARViewFunctionInput

    def _run(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        args_b64 = base64.b64encode(json.dumps(args).encode()).decode()
        result = _near_rpc("query", {
            "request_type": "call_function", "finality": "final",
            "account_id": contract_id, "method_name": method_name, "args_base64": args_b64
        }, network)
        decoded = json.loads(bytes(result["result"]).decode())
        return json.dumps(decoded, indent=2)

    async def _arun(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        return self._run(contract_id, method_name, args, network)


class DAOProposalInput(BaseModel):
    dao_account: str = Field(description="DAO contract account ID, e.g. 'mydao.sputnik-dao.near'")
    proposal_id: Optional[int] = Field(None, description="Specific proposal ID to fetch; omit to list recent proposals")
    limit: Optional[int] = Field(10, description="Number of proposals to fetch when listing")

class DAOProposalTool(BaseTool):
    name: str = "dao_proposal_viewer"
    description: str = (
        "View proposals in a NEAR Sputnik DAO. "
        "Fetch a single proposal by ID or list recent proposals. "
        "Returns proposal status, description, votes, and kind."
    )
    args_schema: Type[BaseModel] = DAOProposalInput

    def _run(self, dao_account: str, proposal_id: Optional[int] = None, limit: int = 10) -> str:
        try:
            if proposal_id is not None:
                params = {
                    "request_type": "call_function",
                    "finality": "final",
                    "account_id": dao_account,
                    "method_name": "get_proposal",
                    "args_base64": __import__("base64").b64encode(
                        __import__("json").dumps({"id": proposal_id}).encode()
                    ).decode(),
                }
                result = _near_rpc("query", params)
                raw = bytes(result.get("result", []))
                proposal = __import__("json").loads(raw.decode())
                return __import__("json").dumps(proposal, indent=2)
            else:
                last_result = _near_rpc("query", {
                    "request_type": "call_function", "finality": "final",
                    "account_id": dao_account, "method_name": "get_last_proposal_id",
                    "args_base64": __import__("base64").b64encode(b"{}").decode(),
                })
                last_id = __import__("json").loads(bytes(last_result.get("result", [b'0'])).decode())
                from_index = max(0, last_id - limit + 1)
                params = {
                    "request_type": "call_function", "finality": "final",
                    "account_id": dao_account, "method_name": "get_proposals",
                    "args_base64": __import__("base64").b64encode(
                        __import__("json").dumps({"from_index": from_index, "limit": limit}).encode()
                    ).decode(),
                }
                result = _near_rpc("query", params)
                proposals = __import__("json").loads(bytes(result.get("result", [])).decode())
                summary = [{"id": p.get("id"), "status": p.get("status"), "kind": list(p.get("kind", {}).keys()), "description": p.get("description", "")[:120]} for p in proposals]
                return __import__("json").dumps(summary, indent=2)
        except Exception as e:
            return f"Error fetching DAO proposals: {e}"

    async def _arun(self, dao_account: str, proposal_id: Optional[int] = None, limit: int = 10) -> str:
        return self._run(dao_account, proposal_id, limit)


class DAOMemberInput(BaseModel):
    dao_account: str = Field(description="DAO contract account ID, e.g. 'mydao.sputnik-dao.near'")
    member_account: Optional[str] = Field(None, description="Account ID to check membership/role for; omit to list all roles/policy")

class DAOMemberTool(BaseTool):
    name: str = "dao_membership_checker"
    description: str = (
        "Check NEAR Sputnik DAO membership, roles, and voting policy. "
        "Provide member_account to check a specific member's roles, "
        "or omit it to retrieve the full DAO policy including roles and vote thresholds."
    )
    args_schema: Type[BaseModel] = DAOMemberInput

    def _run(self, dao_account: str, member_account: Optional[str] = None) -> str:
        try:
            import base64, json
            policy_result = _near_rpc("query", {
                "request_type": "call_function", "finality": "final",
                "account_id": dao_account, "method_name": "get_policy",
                "args_base64": base64.b64encode(b"{}").decode(),
            })
            policy = json.loads(bytes(policy_result.get("result", [])).decode())
            if member_account is None:
                roles_summary = [{"name": r.get("name"), "kind": r.get("kind"), "vote_policy": r.get("vote_policy")} for r in policy.get("roles", [])]
                return json.dumps({"default_vote_policy": policy.get("default_vote_policy"), "roles": roles_summary}, indent=2)
            member_roles = []
            for role in policy.get("roles", []):
                kind = role.get("kind", {})
                if isinstance(kind, dict) and "Group" in kind:
                    if member_account in kind["Group"]:
                        member_roles.append(role.get("name"))
                elif kind == "Everyone":
                    member_roles.append(role.get("name") + " (everyone)")
            return json.dumps({"account": member_account, "dao": dao_account, "roles": member_roles, "is_member": len(member_roles) > 0}, indent=2)
        except Exception as e:
            return f"Error checking DAO membership: {e}"

    async def _arun(self, dao_account: str, member_account: Optional[str] = None) -> str:
        return self._run(dao_account, member_account)