"""SubscribeFlow API client."""

from __future__ import annotations

import json
from typing import Any
from urllib.parse import quote

import httpx

from subscribeflow.exceptions import SubscribeFlowError
from subscribeflow.models import (
    AccountDeleteResult,
    Campaign,
    CampaignCreate,
    CampaignSendResponse,
    CampaignUpdate,
    CheckoutSession,
    DataExportResult,
    EmailSendRequest,
    EmailSendResponse,
    EmailTemplate,
    EmailTemplateCreate,
    EmailTemplateUpdate,
    EmailTrigger,
    NoteCreate,
    NoteUpdate,
    PaginatedResponse,
    PortalSession,
    PreferenceCenterInfo,
    RecipientCountResponse,
    Subscriber,
    SubscriberCreate,
    SubscriberNote,
    SubscriberTagsResult,
    SubscriberUpdate,
    SubscriptionInfo,
    SyncResult,
    Tag,
    TagCreate,
    TagFilter,
    TagSubscriptionResult,
    TagUpdate,
    TemplatePreview,
    TokenResponse,
    TriggerCreate,
    TriggerUpdate,
    WebhookCreate,
    WebhookDelivery,
    WebhookDeliveryDetail,
    WebhookDeliveryStats,
    WebhookEndpoint,
    WebhookEndpointWithSecret,
    WebhookTestResult,
    WebhookUpdate,
)


class SubscribersResource:
    """Subscriber management operations."""

    def __init__(self, client: SubscribeFlowClient) -> None:
        self._client = client

    async def create(
        self,
        email: str,
        *,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Subscriber:
        """Create a new subscriber.

        Args:
            email: Subscriber email address
            tags: List of tag IDs (UUIDs) or tag names to subscribe to
            metadata: Custom metadata

        Returns:
            The created subscriber

        Raises:
            ConflictError: If a subscriber with this email already exists
            ValidationError: If any tag ID/name is invalid

        Example:
            >>> subscriber = await client.subscribers.create(
            ...     email="user@example.com",
            ...     tags=["newsletter"],
            ...     metadata={"source": "website"},
            ... )
        """
        data = SubscriberCreate(
            email=email,
            tags=tags or [],
            metadata=metadata or {},
        )
        response = await self._client._request(
            "POST",
            "/api/v1/subscribers",
            json=data.model_dump(mode="json"),
        )
        return Subscriber.model_validate(response)

    async def list(
        self,
        *,
        cursor: str | None = None,
        limit: int = 50,
        status: str | None = None,
        tag: str | None = None,
    ) -> PaginatedResponse[Subscriber]:
        """List subscribers with optional filtering.

        Args:
            cursor: Pagination cursor from previous response
            limit: Maximum number of results (1-100)
            status: Filter by status (active, unsubscribed, etc.)
            tag: Filter by tag ID

        Returns:
            Paginated list of subscribers
        """
        params: dict[str, Any] = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        if status:
            params["status"] = status
        if tag:
            params["tag"] = tag

        response = await self._client._request(
            "GET",
            "/api/v1/subscribers",
            params=params,
        )
        return PaginatedResponse[Subscriber](
            items=[Subscriber.model_validate(item) for item in response["items"]],
            total=response["total"],
            next_cursor=response.get("cursor"),
        )

    async def get(self, subscriber_id: str) -> Subscriber:
        """Get a subscriber by ID.

        Args:
            subscriber_id: Subscriber UUID

        Returns:
            The subscriber

        Raises:
            NotFoundError: If subscriber doesn't exist
        """
        response = await self._client._request(
            "GET",
            f"/api/v1/subscribers/{subscriber_id}",
        )
        return Subscriber.model_validate(response)

    async def get_by_email(self, email: str) -> Subscriber:
        """Get a subscriber by email address.

        Args:
            email: Subscriber email address

        Returns:
            The subscriber

        Raises:
            NotFoundError: If subscriber doesn't exist
        """
        response = await self._client._request(
            "GET",
            f"/api/v1/subscribers/by-email/{quote(email, safe='')}",
        )
        return Subscriber.model_validate(response)

    async def get_or_create(
        self,
        email: str,
        *,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> tuple[Subscriber, bool]:
        """Get an existing subscriber or create a new one.

        This is a convenience method that handles the common pattern of
        creating a subscriber if they don't exist, or returning the existing one.

        Note: If the subscriber already exists, the provided tags and metadata
        are NOT applied. Use update() separately if you need to modify an
        existing subscriber.

        Args:
            email: Subscriber email address
            tags: List of tag IDs or names (only used on create)
            metadata: Custom metadata (only used on create)

        Returns:
            Tuple of (Subscriber, created: bool).
            created is True if a new subscriber was created, False if existing.

        Example:
            >>> subscriber, created = await client.subscribers.get_or_create(
            ...     email="user@example.com",
            ...     tags=["newsletter"],
            ...     metadata={"source": "website"},
            ... )
            >>> if created:
            ...     print(f"New subscriber: {subscriber.id}")
            ... else:
            ...     print(f"Existing subscriber: {subscriber.id}")
        """
        from subscribeflow.exceptions import ConflictError

        try:
            subscriber = await self.create(
                email=email,
                tags=tags,
                metadata=metadata,
            )
            return subscriber, True
        except ConflictError:
            subscriber = await self.get_by_email(email)
            return subscriber, False

    async def update(
        self,
        subscriber_id: str,
        *,
        metadata: dict[str, Any] | None = None,
        status: str | None = None,
    ) -> Subscriber:
        """Update a subscriber.

        Args:
            subscriber_id: Subscriber UUID
            metadata: New metadata (replaces existing)
            status: New status (active or unsubscribed)

        Returns:
            The updated subscriber

        Raises:
            ValueError: If no update fields are provided
        """
        if metadata is None and status is None:
            msg = "At least one of 'metadata' or 'status' must be provided"
            raise ValueError(msg)

        data = SubscriberUpdate(metadata=metadata, status=status)
        response = await self._client._request(
            "PUT",
            f"/api/v1/subscribers/{subscriber_id}",
            json=data.model_dump(mode="json", exclude_none=True),
        )
        return Subscriber.model_validate(response)

    async def delete(self, subscriber_id: str) -> None:
        """Delete a subscriber.

        Args:
            subscriber_id: Subscriber UUID
        """
        await self._client._request(
            "DELETE",
            f"/api/v1/subscribers/{subscriber_id}",
        )

    async def add_tags(
        self,
        subscriber_id: str,
        tag_ids: list[str],
    ) -> SubscriberTagsResult:
        """Add tags to a subscriber.

        Args:
            subscriber_id: The subscriber's UUID
            tag_ids: List of tag UUIDs to add

        Returns:
            SubscriberTagsResult with subscriber_id, tags list, and total count

        Raises:
            ValueError: If tag_ids is empty

        Example:
            >>> result = await client.subscribers.add_tags(
            ...     "sub-uuid",
            ...     ["tag-uuid-1", "tag-uuid-2"],
            ... )
        """
        if not tag_ids:
            raise ValueError("tag_ids must not be empty — provide at least one tag UUID")
        response = await self._client._request(
            "POST",
            f"/api/v1/subscribers/{subscriber_id}/tags",
            json={"tag_ids": tag_ids},
        )
        return SubscriberTagsResult.model_validate(response)

    async def remove_tag(
        self,
        subscriber_id: str,
        tag_id: str,
    ) -> None:
        """Remove a tag from a subscriber.

        Args:
            subscriber_id: The subscriber's UUID
            tag_id: The tag's UUID to remove

        Example:
            >>> await client.subscribers.remove_tag("sub-uuid", "tag-uuid")
        """
        await self._client._request(
            "DELETE",
            f"/api/v1/subscribers/{subscriber_id}/tags/{tag_id}",
        )

    # TODO: This endpoint (POST /api/v1/subscribers/{subscriber_id}/token) does not exist
    # as an HTTP route in the backend. The token is generated server-side only via
    # the service layer (subscriber_service.generate_preference_token). This SDK method
    # will fail at runtime. Either remove it or add the corresponding backend endpoint.
    async def generate_token(self, subscriber_id: str) -> TokenResponse:
        """Generate a preference center token for a subscriber.

        Args:
            subscriber_id: Subscriber UUID

        Returns:
            Token response with JWT and expiration
        """
        response = await self._client._request(
            "POST",
            f"/api/v1/subscribers/{subscriber_id}/token",
        )
        return TokenResponse.model_validate(response)


class TagsResource:
    """Tag management operations."""

    def __init__(self, client: SubscribeFlowClient) -> None:
        self._client = client

    async def create(
        self,
        name: str,
        *,
        description: str | None = None,
        category: str | None = None,
        is_public: bool = True,
    ) -> Tag:
        """Create a new tag.

        Args:
            name: Tag display name (must be unique)
            description: Tag description
            category: Category for grouping tags in Preference Center
            is_public: Whether the tag is visible in Preference Center

        Returns:
            The created tag

        Raises:
            ConflictError: If a tag with this name already exists
        """
        data = TagCreate(
            name=name,
            description=description,
            category=category,
            is_public=is_public,
        )
        response = await self._client._request(
            "POST",
            "/api/v1/tags",
            json=data.model_dump(mode="json"),
        )
        return Tag.model_validate(response)

    async def list(
        self,
        *,
        cursor: str | None = None,
        limit: int = 50,
    ) -> PaginatedResponse[Tag]:
        """List all tags.

        Args:
            cursor: Pagination cursor from previous response
            limit: Maximum number of results (1-100)

        Returns:
            Paginated list of tags
        """
        params: dict[str, Any] = {"limit": limit}
        if cursor:
            params["cursor"] = cursor

        response = await self._client._request(
            "GET",
            "/api/v1/tags",
            params=params,
        )
        return PaginatedResponse[Tag](
            items=[Tag.model_validate(item) for item in response["items"]],
            total=response["total"],
            next_cursor=response.get("cursor"),
        )

    async def get(self, tag_id: str) -> Tag:
        """Get a tag by ID.

        Args:
            tag_id: Tag UUID

        Returns:
            The tag
        """
        response = await self._client._request(
            "GET",
            f"/api/v1/tags/{tag_id}",
        )
        return Tag.model_validate(response)

    async def get_by_name(self, name: str) -> Tag:
        """Get a tag by its unique name.

        Args:
            name: Tag name to look up

        Returns:
            The tag

        Raises:
            NotFoundError: If no tag with this name exists

        Example:
            >>> tag = await client.tags.get_by_name("newsletter")
            >>> print(tag.id)
        """
        response = await self._client._request(
            "GET",
            f"/api/v1/tags/by-name/{quote(name, safe='')}",
        )
        return Tag.model_validate(response)

    async def get_or_create(
        self,
        name: str,
        *,
        description: str | None = None,
        category: str | None = None,
        is_public: bool = True,
    ) -> tuple[Tag, bool]:
        """Get an existing tag or create a new one.

        This is a convenience method that handles the common pattern of
        creating a tag if it doesn't exist, or returning the existing one.

        Args:
            name: Tag name (unique identifier)
            description: Tag description (only used on create)
            category: Category for grouping (only used on create)
            is_public: Visibility in Preference Center (only used on create)

        Returns:
            Tuple of (Tag, created: bool).
            created is True if a new tag was created, False if existing.

        Example:
            >>> tag, created = await client.tags.get_or_create(
            ...     name="newsletter",
            ...     description="Weekly updates",
            ... )
            >>> if created:
            ...     print(f"Created new tag: {tag.id}")
            ... else:
            ...     print(f"Using existing tag: {tag.id}")
        """
        from subscribeflow.exceptions import ConflictError

        try:
            tag = await self.create(
                name=name,
                description=description,
                category=category,
                is_public=is_public,
            )
            return tag, True
        except ConflictError:
            tag = await self.get_by_name(name)
            return tag, False

    async def update(
        self,
        tag_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        category: str | None = None,
        is_public: bool | None = None,
    ) -> Tag:
        """Update a tag.

        Args:
            tag_id: Tag UUID
            name: New display name
            description: New description
            category: New category
            is_public: New visibility setting

        Returns:
            The updated tag

        Raises:
            ValueError: If no update fields are provided
        """
        if name is None and description is None and category is None and is_public is None:
            msg = "At least one of 'name', 'description', 'category', or 'is_public' required"
            raise ValueError(msg)

        data = TagUpdate(name=name, description=description, category=category, is_public=is_public)
        response = await self._client._request(
            "PUT",
            f"/api/v1/tags/{tag_id}",
            json=data.model_dump(mode="json", exclude_none=True),
        )
        return Tag.model_validate(response)

    async def delete(self, tag_id: str) -> None:
        """Delete a tag.

        Args:
            tag_id: Tag UUID
        """
        await self._client._request(
            "DELETE",
            f"/api/v1/tags/{tag_id}",
        )


class WebhooksResource:
    """Webhook management operations."""

    def __init__(self, client: SubscribeFlowClient) -> None:
        self._client = client

    async def create(
        self,
        url: str,
        events: list[str],
        *,
        description: str | None = None,
    ) -> WebhookEndpointWithSecret:
        """Create a new webhook endpoint.

        Args:
            url: Webhook delivery URL
            events: List of event types to subscribe to
            description: Endpoint description

        Returns:
            The created webhook endpoint with signing secret

        Note:
            The signing secret is only returned on creation.
            Store it securely for signature verification.
        """
        data = WebhookCreate(
            url=url,
            events=events,
            description=description,
        )
        response = await self._client._request(
            "POST",
            "/api/v1/webhooks",
            json=data.model_dump(mode="json"),
        )
        return WebhookEndpointWithSecret.model_validate(response)

    async def list(
        self,
        *,
        cursor: str | None = None,
        limit: int = 50,
    ) -> PaginatedResponse[WebhookEndpoint]:
        """List all webhook endpoints.

        Args:
            cursor: Pagination cursor from previous response
            limit: Maximum number of results (1-100)

        Returns:
            Paginated list of webhook endpoints
        """
        params: dict[str, Any] = {"limit": limit}
        if cursor:
            params["cursor"] = cursor

        response = await self._client._request(
            "GET",
            "/api/v1/webhooks",
            params=params,
        )
        items_key = "data" if "data" in response else "items"
        return PaginatedResponse[WebhookEndpoint](
            items=[WebhookEndpoint.model_validate(item) for item in response[items_key]],
            total=response["total"],
            next_cursor=response.get("cursor"),
        )

    async def get(self, webhook_id: str) -> WebhookEndpoint:
        """Get a webhook endpoint by ID.

        Args:
            webhook_id: Webhook endpoint UUID

        Returns:
            The webhook endpoint
        """
        response = await self._client._request(
            "GET",
            f"/api/v1/webhooks/{webhook_id}",
        )
        return WebhookEndpoint.model_validate(response)

    async def delete(self, webhook_id: str) -> None:
        """Delete a webhook endpoint.

        Args:
            webhook_id: Webhook endpoint UUID
        """
        await self._client._request(
            "DELETE",
            f"/api/v1/webhooks/{webhook_id}",
        )

    async def test(self, webhook_id: str) -> WebhookTestResult:
        """Test a webhook endpoint.

        Sends a test event to the webhook URL and returns the result.

        Args:
            webhook_id: Webhook endpoint UUID

        Returns:
            Test result with success status and response details
        """
        response = await self._client._request(
            "POST",
            f"/api/v1/webhooks/{webhook_id}/test",
        )
        return WebhookTestResult.model_validate(response)

    async def update(
        self,
        endpoint_id: str,
        *,
        url: str | None = None,
        description: str | None = None,
        events: list[str] | None = None,
        is_active: bool | None = None,
    ) -> WebhookEndpoint:
        """Update a webhook endpoint.

        Args:
            endpoint_id: Webhook endpoint UUID
            url: New webhook URL
            description: New description
            events: New event types
            is_active: New active state

        Returns:
            The updated webhook endpoint

        Raises:
            ValueError: If no update fields are provided
        """
        if all(v is None for v in (url, description, events, is_active)):
            msg = "At least one field must be provided for update"
            raise ValueError(msg)

        data = WebhookUpdate(
            url=url,
            description=description,
            events=events,
            is_active=is_active,
        )
        response = await self._client._request(
            "PUT",
            f"/api/v1/webhooks/{endpoint_id}",
            json=data.model_dump(mode="json", exclude_none=True),
        )
        return WebhookEndpoint.model_validate(response)

    async def regenerate_secret(self, endpoint_id: str) -> WebhookEndpointWithSecret:
        """Regenerate the signing secret for a webhook endpoint.

        Args:
            endpoint_id: Webhook endpoint UUID

        Returns:
            The webhook endpoint with new signing secret
        """
        response = await self._client._request(
            "POST",
            f"/api/v1/webhooks/{endpoint_id}/regenerate-secret",
        )
        return WebhookEndpointWithSecret.model_validate(response)

    async def list_deliveries(
        self,
        endpoint_id: str,
        *,
        event_type: str | None = None,
        status: str | None = None,
        limit: int = 50,
    ) -> PaginatedResponse[WebhookDelivery]:
        """List deliveries for a webhook endpoint.

        Args:
            endpoint_id: Webhook endpoint UUID
            event_type: Filter by event type
            status: Filter by delivery status
            limit: Maximum results

        Returns:
            Paginated list of deliveries
        """
        params: dict[str, Any] = {"limit": limit}
        if event_type:
            params["event_type"] = event_type
        if status:
            params["status"] = status

        response = await self._client._request(
            "GET",
            f"/api/v1/webhooks/{endpoint_id}/deliveries",
            params=params,
        )
        return PaginatedResponse[WebhookDelivery](
            items=[WebhookDelivery.model_validate(item) for item in response["items"]],
            total=response["total"],
            next_cursor=response.get("cursor"),
        )

    async def get_delivery(self, endpoint_id: str, delivery_id: str) -> WebhookDeliveryDetail:
        """Get a specific delivery with payload details.

        Args:
            endpoint_id: Webhook endpoint UUID
            delivery_id: Delivery UUID

        Returns:
            Detailed delivery record with payload
        """
        response = await self._client._request(
            "GET",
            f"/api/v1/webhooks/{endpoint_id}/deliveries/{delivery_id}",
        )
        return WebhookDeliveryDetail.model_validate(response)

    async def retry_delivery(self, endpoint_id: str, delivery_id: str) -> WebhookTestResult:
        """Retry a failed delivery.

        Args:
            endpoint_id: Webhook endpoint UUID
            delivery_id: Delivery UUID

        Returns:
            Retry result
        """
        response = await self._client._request(
            "POST",
            f"/api/v1/webhooks/{endpoint_id}/deliveries/{delivery_id}/retry",
        )
        return WebhookTestResult.model_validate(response)

    async def get_stats(self, endpoint_id: str, *, days: int = 30) -> WebhookDeliveryStats:
        """Get delivery statistics for a webhook endpoint.

        Args:
            endpoint_id: Webhook endpoint UUID
            days: Number of days to include (default: 30)

        Returns:
            Delivery statistics
        """
        response = await self._client._request(
            "GET",
            f"/api/v1/webhooks/{endpoint_id}/stats",
            params={"days": days},
        )
        return WebhookDeliveryStats.model_validate(response)

    async def list_all_deliveries(
        self,
        *,
        event_type: str | None = None,
        status: str | None = None,
        limit: int = 50,
    ) -> PaginatedResponse[WebhookDelivery]:
        """List deliveries across all webhook endpoints.

        Args:
            event_type: Filter by event type
            status: Filter by delivery status
            limit: Maximum results

        Returns:
            Paginated list of deliveries
        """
        params: dict[str, Any] = {"limit": limit}
        if event_type:
            params["event_type"] = event_type
        if status:
            params["status"] = status

        response = await self._client._request(
            "GET",
            "/api/v1/webhooks/deliveries/all",
            params=params,
        )
        return PaginatedResponse[WebhookDelivery](
            items=[WebhookDelivery.model_validate(item) for item in response["items"]],
            total=response["total"],
            next_cursor=response.get("cursor"),
        )

    async def get_global_stats(self, *, days: int = 30) -> WebhookDeliveryStats:
        """Get delivery statistics across all webhook endpoints.

        Args:
            days: Number of days to include (default: 30)

        Returns:
            Global delivery statistics
        """
        response = await self._client._request(
            "GET",
            "/api/v1/webhooks/stats/all",
            params={"days": days},
        )
        return WebhookDeliveryStats.model_validate(response)

    async def list_event_types(self) -> dict[str, Any]:
        """List all available webhook event types.

        Returns:
            Dictionary of event types with descriptions
        """
        response = await self._client._request(
            "GET",
            "/api/v1/webhooks/event-types",
        )
        return response


class TemplatesResource:
    """Email template management operations."""

    def __init__(self, client: SubscribeFlowClient) -> None:
        self._client = client

    async def create(
        self,
        name: str,
        subject: str,
        mjml_content: str,
        *,
        variables_schema: dict[str, Any] | None = None,
        category: str = "transactional",
    ) -> EmailTemplate:
        """Create a new email template.

        Args:
            name: Template display name
            subject: Email subject line
            mjml_content: MJML template content
            variables_schema: JSON Schema for template variables
            category: Template category (default: transactional)

        Returns:
            The created email template
        """
        data = EmailTemplateCreate(
            name=name,
            subject=subject,
            mjml_content=mjml_content,
            variables_schema=variables_schema,
            category=category,
        )
        response = await self._client._request(
            "POST",
            "/api/v1/templates",
            json=data.model_dump(mode="json"),
        )
        return EmailTemplate.model_validate(response)

    async def list(
        self,
        *,
        skip: int = 0,
        limit: int = 50,
        category: str | None = None,
    ) -> PaginatedResponse[EmailTemplate]:
        """List email templates with optional filtering.

        Args:
            skip: Number of items to skip (offset-based pagination)
            limit: Maximum number of results (1-100)
            category: Filter by template category

        Returns:
            Paginated list of email templates
        """
        params: dict[str, Any] = {"skip": skip, "limit": limit}
        if category:
            params["category"] = category

        response = await self._client._request(
            "GET",
            "/api/v1/templates",
            params=params,
        )
        return PaginatedResponse[EmailTemplate](
            items=[EmailTemplate.model_validate(item) for item in response["items"]],
            total=response["total"],
            next_cursor=response.get("cursor"),
        )

    async def get(self, slug: str) -> EmailTemplate:
        """Get an email template by slug.

        Args:
            slug: Template slug identifier

        Returns:
            The email template

        Raises:
            NotFoundError: If template doesn't exist
        """
        response = await self._client._request(
            "GET",
            f"/api/v1/templates/{quote(slug, safe='')}",
        )
        return EmailTemplate.model_validate(response)

    async def update(
        self,
        slug: str,
        *,
        name: str | None = None,
        subject: str | None = None,
        mjml_content: str | None = None,
        variables_schema: dict[str, Any] | None = None,
        category: str | None = None,
    ) -> EmailTemplate:
        """Update an email template.

        Args:
            slug: Template slug identifier
            name: New display name
            subject: New subject line
            mjml_content: New MJML template content
            variables_schema: New JSON Schema for template variables
            category: New category

        Returns:
            The updated email template

        Raises:
            ValueError: If no update fields are provided
        """
        if all(v is None for v in (name, subject, mjml_content, variables_schema, category)):
            msg = "At least one field must be provided for update"
            raise ValueError(msg)

        data = EmailTemplateUpdate(
            name=name,
            subject=subject,
            mjml_content=mjml_content,
            variables_schema=variables_schema,
            category=category,
        )
        response = await self._client._request(
            "PUT",
            f"/api/v1/templates/{quote(slug, safe='')}",
            json=data.model_dump(mode="json", exclude_none=True),
        )
        return EmailTemplate.model_validate(response)

    async def delete(self, slug: str) -> None:
        """Delete an email template.

        Args:
            slug: Template slug identifier
        """
        await self._client._request(
            "DELETE",
            f"/api/v1/templates/{quote(slug, safe='')}",
        )

    async def preview(
        self,
        slug: str,
        variables: dict[str, Any] | None = None,
    ) -> TemplatePreview:
        """Preview a rendered email template.

        Args:
            slug: Template slug identifier
            variables: Template variables for rendering

        Returns:
            Rendered template preview with HTML and subject
        """
        json_body: dict[str, Any] = {"variables": variables or {}}
        response = await self._client._request(
            "POST",
            f"/api/v1/templates/{quote(slug, safe='')}/preview",
            json=json_body,
        )
        return TemplatePreview.model_validate(response)


class EmailsResource:
    """Email sending operations."""

    def __init__(self, client: SubscribeFlowClient) -> None:
        self._client = client

    async def send(
        self,
        template_slug: str,
        to: str,
        *,
        variables: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> EmailSendResponse:
        """Send an email using a template.

        Args:
            template_slug: Template slug to use
            to: Recipient email address
            variables: Template variables for rendering
            idempotency_key: Idempotency key for deduplication

        Returns:
            Email send response with status and metadata
        """
        data = EmailSendRequest(
            template_slug=template_slug,
            to=to,
            variables=variables or {},
            idempotency_key=idempotency_key,
        )
        response = await self._client._request(
            "POST",
            "/api/v1/emails/send",
            json=data.model_dump(mode="json", exclude_none=True),
        )
        return EmailSendResponse.model_validate(response)


class CampaignsResource:
    """Campaign management operations."""

    def __init__(self, client: SubscribeFlowClient) -> None:
        self._client = client

    async def create(
        self,
        name: str,
        template_id: str,
        *,
        tag_filter: dict[str, Any] | None = None,
    ) -> Campaign:
        """Create a new campaign (draft status).

        Args:
            name: Campaign name
            template_id: Template UUID to use
            tag_filter: Tag-based recipient filter with
                include_tags, exclude_tags, match

        Returns:
            The created campaign in draft status
        """
        data = CampaignCreate(
            name=name,
            template_id=template_id,
            tag_filter=(TagFilter(**tag_filter) if tag_filter else None),
        )
        response = await self._client._request(
            "POST",
            "/api/v1/campaigns",
            json=data.model_dump(mode="json", exclude_none=True),
        )
        return Campaign.model_validate(response)

    async def list(
        self,
        *,
        cursor: str | None = None,
        limit: int = 50,
        status: str | None = None,
        sort_by: str | None = None,
        sort_desc: bool = True,
    ) -> PaginatedResponse[Campaign]:
        """List campaigns with optional filtering and sorting.

        Args:
            cursor: Pagination cursor
            limit: Maximum results (1-100)
            status: Filter by status (draft, sending, completed,
                cancelled)
            sort_by: Sort field (created_at, name)
            sort_desc: Sort descending (default: True)

        Returns:
            Paginated list of campaigns
        """
        params: dict[str, Any] = {
            "limit": limit,
            "sort_desc": sort_desc,
        }
        if cursor:
            params["cursor"] = cursor
        if status:
            params["status"] = status
        if sort_by:
            params["sort_by"] = sort_by

        response = await self._client._request(
            "GET",
            "/api/v1/campaigns",
            params=params,
        )
        return PaginatedResponse[Campaign](
            items=[Campaign.model_validate(item) for item in response["items"]],
            total=response["total"],
            next_cursor=response.get("cursor"),
        )

    async def get(self, campaign_id: str) -> Campaign:
        """Get a campaign by ID (includes stats).

        Args:
            campaign_id: Campaign UUID

        Returns:
            The campaign with statistics
        """
        response = await self._client._request(
            "GET",
            f"/api/v1/campaigns/{campaign_id}",
        )
        return Campaign.model_validate(response)

    async def update(
        self,
        campaign_id: str,
        *,
        name: str | None = None,
        template_id: str | None = None,
        tag_filter: dict[str, Any] | None = None,
    ) -> Campaign:
        """Update a campaign (draft status only).

        Args:
            campaign_id: Campaign UUID
            name: New campaign name
            template_id: New template UUID
            tag_filter: New recipient filter

        Returns:
            The updated campaign

        Raises:
            ValueError: If no update fields are provided
        """
        if name is None and template_id is None and tag_filter is None:
            msg = "At least one of 'name', 'template_id', or 'tag_filter' required"
            raise ValueError(msg)

        data = CampaignUpdate(
            name=name,
            template_id=template_id,
            tag_filter=(TagFilter(**tag_filter) if tag_filter else None),
        )
        response = await self._client._request(
            "PUT",
            f"/api/v1/campaigns/{campaign_id}",
            json=data.model_dump(mode="json", exclude_none=True),
        )
        return Campaign.model_validate(response)

    async def send(
        self,
        campaign_id: str,
        *,
        batch_size: int = 50,
    ) -> CampaignSendResponse:
        """Trigger campaign sending.

        Args:
            campaign_id: Campaign UUID
            batch_size: Emails per batch (1-500, default: 50)

        Returns:
            Send response with recipient count
        """
        response = await self._client._request(
            "POST",
            f"/api/v1/campaigns/{campaign_id}/send",
            json={"batch_size": batch_size},
        )
        return CampaignSendResponse.model_validate(response)

    async def cancel(self, campaign_id: str) -> Campaign:
        """Cancel a sending campaign.

        Args:
            campaign_id: Campaign UUID

        Returns:
            The cancelled campaign
        """
        response = await self._client._request(
            "POST",
            f"/api/v1/campaigns/{campaign_id}/cancel",
        )
        return Campaign.model_validate(response)

    async def retry(self, campaign_id: str) -> CampaignSendResponse:
        """Retry sending a failed campaign.

        Args:
            campaign_id: Campaign UUID

        Returns:
            Send response with recipient count
        """
        response = await self._client._request(
            "POST",
            f"/api/v1/campaigns/{campaign_id}/retry",
            json={},
        )
        return CampaignSendResponse.model_validate(response)

    async def duplicate(self, campaign_id: str) -> Campaign:
        """Duplicate an existing campaign.

        Args:
            campaign_id: Campaign UUID

        Returns:
            The newly created campaign (draft copy)
        """
        response = await self._client._request(
            "POST",
            f"/api/v1/campaigns/{campaign_id}/duplicate",
            json={},
        )
        return Campaign.model_validate(response)

    async def count_recipients(
        self,
        *,
        include_tags: list[str] | None = None,
        exclude_tags: list[str] | None = None,
        match: str = "any",
    ) -> int:
        """Count recipients matching a tag filter.

        Count without creating a campaign.

        Args:
            include_tags: Tag IDs to include
            exclude_tags: Tag IDs to exclude
            match: Match mode: 'any' or 'all'

        Returns:
            Number of matching recipients
        """
        response = await self._client._request(
            "POST",
            "/api/v1/campaigns/count-recipients",
            json={
                "include_tags": include_tags or [],
                "exclude_tags": exclude_tags or [],
                "match": match,
            },
        )
        return RecipientCountResponse.model_validate(response).count


class TriggersResource:
    """Email trigger management operations."""

    def __init__(self, client: SubscribeFlowClient) -> None:
        self._client = client

    async def create(
        self,
        event_type: str,
        template_id: str,
        *,
        description: str | None = None,
        is_active: bool = True,
    ) -> EmailTrigger:
        """Create a new email trigger.

        Args:
            event_type: Event type to trigger on (e.g., subscriber.created)
            template_id: Template UUID to send when triggered
            description: Trigger description
            is_active: Whether the trigger is active immediately

        Returns:
            The created trigger
        """
        data = TriggerCreate(
            event_type=event_type,
            template_id=template_id,
            description=description,
            is_active=is_active,
        )
        response = await self._client._request(
            "POST",
            "/api/v1/email-triggers",
            json=data.model_dump(mode="json"),
        )
        return EmailTrigger.model_validate(response)

    async def list(self) -> list[EmailTrigger]:
        """List all email triggers.

        Returns:
            List of email triggers
        """
        response = await self._client._request(
            "GET",
            "/api/v1/email-triggers",
        )
        return [EmailTrigger.model_validate(item) for item in response["items"]]

    async def get(self, trigger_id: str) -> EmailTrigger:
        """Get a trigger by ID.

        Args:
            trigger_id: Trigger UUID

        Returns:
            The trigger
        """
        response = await self._client._request(
            "GET",
            f"/api/v1/email-triggers/{trigger_id}",
        )
        return EmailTrigger.model_validate(response)

    async def update(
        self,
        trigger_id: str,
        *,
        event_type: str | None = None,
        template_id: str | None = None,
        description: str | None = None,
        is_active: bool | None = None,
    ) -> EmailTrigger:
        """Update a trigger.

        Args:
            trigger_id: Trigger UUID
            event_type: New event type
            template_id: New template UUID
            description: New description
            is_active: New active state

        Returns:
            The updated trigger

        Raises:
            ValueError: If no update fields are provided
        """
        if all(v is None for v in (event_type, template_id, description, is_active)):
            msg = "At least one field must be provided for update"
            raise ValueError(msg)

        data = TriggerUpdate(
            event_type=event_type,
            template_id=template_id,
            description=description,
            is_active=is_active,
        )
        response = await self._client._request(
            "PUT",
            f"/api/v1/email-triggers/{trigger_id}",
            json=data.model_dump(mode="json", exclude_none=True),
        )
        return EmailTrigger.model_validate(response)

    async def delete(self, trigger_id: str) -> None:
        """Delete a trigger.

        Args:
            trigger_id: Trigger UUID
        """
        await self._client._request(
            "DELETE",
            f"/api/v1/email-triggers/{trigger_id}",
        )


class PreferenceCenterResource:
    """Preference Center operations (JWT token auth).

    This resource uses JWT token authentication instead of API key auth.
    Obtain a token via client.subscribers.generate_token().
    """

    def __init__(self, base_url: str, token: str, timeout: float = 30.0) -> None:
        self._base_url = base_url.rstrip("/")
        self._token = token
        self._timeout = timeout

    async def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        """Make a JWT-authenticated request."""
        params = kwargs.pop("params", {})
        params["token"] = self._token
        async with httpx.AsyncClient(
            base_url=self._base_url,
            headers={"Content-Type": "application/json"},
            timeout=httpx.Timeout(self._timeout),
        ) as client:
            response = await client.request(method, path, params=params, **kwargs)
            if response.status_code in (200, 201, 202):
                return response.json()
            if response.status_code == 204:
                return {}
            try:
                error_data = response.json()
            except (json.JSONDecodeError, ValueError):
                error_data = {"detail": response.text or "Unknown error"}
            raise SubscribeFlowError.from_response(error_data, response.status_code)

    async def get_preferences(self) -> PreferenceCenterInfo:
        """Get subscriber preferences and available tags."""
        response = await self._request("GET", "/preference-center")
        return PreferenceCenterInfo.model_validate(response)

    async def subscribe_tag(self, tag_id: str) -> TagSubscriptionResult:
        """Subscribe to a public tag."""
        response = await self._request("PUT", f"/preference-center/tags/{tag_id}")
        return TagSubscriptionResult.model_validate(response)

    async def unsubscribe_tag(self, tag_id: str) -> TagSubscriptionResult:
        """Unsubscribe from a tag."""
        response = await self._request("DELETE", f"/preference-center/tags/{tag_id}")
        return TagSubscriptionResult.model_validate(response)

    async def export_data(self) -> DataExportResult:
        """Export all stored data (DSGVO right of access)."""
        response = await self._request("GET", "/preference-center/data-export")
        return DataExportResult.model_validate(response)

    async def delete_account(self) -> AccountDeleteResult:
        """Delete account and all data (DSGVO right to erasure)."""
        response = await self._request("DELETE", "/preference-center/account")
        return AccountDeleteResult.model_validate(response)


class NotesResource:
    """Subscriber note management operations."""

    def __init__(self, client: SubscribeFlowClient) -> None:
        self._client = client

    async def create(
        self,
        subscriber_id: str,
        content: str,
        *,
        source: str = "api",
        subject: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> SubscriberNote:
        """Create a note for a subscriber.

        Args:
            subscriber_id: Subscriber UUID
            content: Note content
            source: Note source (contact_form, admin, api, system)
            subject: Optional subject line
            metadata: Optional metadata

        Returns:
            The created note

        Example:
            >>> note = await client.notes.create(
            ...     subscriber_id="...",
            ...     content="Customer inquiry about pricing.",
            ...     source="contact_form",
            ...     subject="SubscribeFlow",
            ... )
        """
        data = NoteCreate(
            content=content,
            source=source,
            subject=subject,
            metadata=metadata or {},
        )
        response = await self._client._request(
            "POST",
            f"/api/v1/subscribers/{subscriber_id}/notes",
            json=data.model_dump(mode="json"),
        )
        return SubscriberNote.model_validate(response)

    async def list(
        self,
        subscriber_id: str,
        *,
        cursor: str | None = None,
        limit: int = 50,
        source: str | None = None,
        search: str | None = None,
        created_after: str | None = None,
        created_before: str | None = None,
        sort: str = "desc",
    ) -> PaginatedResponse[SubscriberNote]:
        """List notes for a subscriber.

        Args:
            subscriber_id: Subscriber UUID
            cursor: Pagination cursor
            limit: Items per page (1-100)
            source: Filter by source
            search: Full-text search in content
            created_after: Filter by creation date (ISO 8601)
            created_before: Filter by creation date (ISO 8601)
            sort: Sort order (asc or desc)

        Returns:
            Paginated list of notes
        """
        params: dict[str, Any] = {"limit": limit, "sort": sort}
        if cursor:
            params["cursor"] = cursor
        if source:
            params["source"] = source
        if search:
            params["search"] = search
        if created_after:
            params["created_after"] = created_after
        if created_before:
            params["created_before"] = created_before

        response = await self._client._request(
            "GET",
            f"/api/v1/subscribers/{subscriber_id}/notes",
            params=params,
        )
        return PaginatedResponse[SubscriberNote].model_validate(
            {
                "items": [
                    SubscriberNote.model_validate(item) for item in response.get("items", [])
                ],
                "total": response.get("total", 0),
                "next_cursor": response.get("cursor"),
            }
        )

    async def get(self, subscriber_id: str, note_id: str) -> SubscriberNote:
        """Get a note by ID.

        Args:
            subscriber_id: Subscriber UUID
            note_id: Note UUID

        Returns:
            The note

        Raises:
            NotFoundError: If the note does not exist
        """
        response = await self._client._request(
            "GET",
            f"/api/v1/subscribers/{subscriber_id}/notes/{note_id}",
        )
        return SubscriberNote.model_validate(response)

    async def update(
        self,
        subscriber_id: str,
        note_id: str,
        *,
        content: str | None = None,
        subject: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> SubscriberNote:
        """Update a note.

        Args:
            subscriber_id: Subscriber UUID
            note_id: Note UUID
            content: Updated content
            subject: Updated subject
            metadata: Updated metadata

        Returns:
            The updated note
        """
        data = NoteUpdate(
            content=content,
            subject=subject,
            metadata=metadata,
        )
        response = await self._client._request(
            "PUT",
            f"/api/v1/subscribers/{subscriber_id}/notes/{note_id}",
            json=data.model_dump(mode="json", exclude_unset=True),
        )
        return SubscriberNote.model_validate(response)

    async def delete(self, subscriber_id: str, note_id: str) -> None:
        """Delete a note.

        Args:
            subscriber_id: Subscriber UUID
            note_id: Note UUID
        """
        await self._client._request(
            "DELETE",
            f"/api/v1/subscribers/{subscriber_id}/notes/{note_id}",
        )


class BillingResource:
    """Billing and subscription management operations."""

    def __init__(self, client: SubscribeFlowClient) -> None:
        self._client = client

    async def get_subscription(self) -> SubscriptionInfo:
        """Get the current billing subscription info.

        Returns:
            Current subscription details including tier, limits, and usage.
        """
        response = await self._client._request("GET", "/api/v1/billing/subscription")
        return SubscriptionInfo.model_validate(response)

    async def create_checkout_session(self, price_id: str) -> CheckoutSession:
        """Create a Stripe checkout session for plan upgrade.

        Args:
            price_id: Stripe price ID to subscribe to.

        Returns:
            Checkout session with redirect URL.
        """
        response = await self._client._request(
            "POST",
            "/api/v1/billing/create-checkout-session",
            json={"price_id": price_id},
        )
        return CheckoutSession.model_validate(response)

    async def create_portal_session(self) -> PortalSession:
        """Create a Stripe customer portal session.

        Returns:
            Portal session with redirect URL.
        """
        response = await self._client._request(
            "POST",
            "/api/v1/billing/customer-portal",
        )
        return PortalSession.model_validate(response)

    async def sync_subscription(self) -> SyncResult:
        """Manually sync subscription state from Stripe.

        Returns:
            Sync result with current tier and status.
        """
        response = await self._client._request(
            "POST",
            "/api/v1/billing/sync-subscription",
        )
        return SyncResult.model_validate(response)


class AdminResource:
    """Platform admin operations (requires is_platform_admin org)."""

    def __init__(self, client: SubscribeFlowClient) -> None:
        self._client = client

    async def list_organizations(self) -> list[dict[str, Any]]:
        """List all organizations with subscriber and member counts."""
        response = await self._client._request("GET", "/api/v1/admin/organizations")
        return response  # type: ignore[return-value]

    async def get_organization(self, org_id: str) -> dict[str, Any]:
        """Get detailed organization info with member list."""
        response = await self._client._request("GET", f"/api/v1/admin/organizations/{org_id}")
        return response

    async def update_organization(
        self,
        org_id: str,
        *,
        name: str | None = None,
        slug: str | None = None,
        subscription_tier: str | None = None,
        is_platform_admin: bool | None = None,
    ) -> dict[str, Any]:
        """Update organization fields (name, slug, subscription_tier, is_platform_admin)."""
        data: dict[str, Any] = {}
        if name is not None:
            data["name"] = name
        if slug is not None:
            data["slug"] = slug
        if subscription_tier is not None:
            data["subscription_tier"] = subscription_tier
        if is_platform_admin is not None:
            data["is_platform_admin"] = is_platform_admin
        response = await self._client._request(
            "PATCH", f"/api/v1/admin/organizations/{org_id}", json=data
        )
        return response

    async def delete_organization(self, org_id: str) -> None:
        """Delete an organization if it is empty."""
        await self._client._request("DELETE", f"/api/v1/admin/organizations/{org_id}")

    async def list_users(self) -> list[dict[str, Any]]:
        """List all users with their organization memberships."""
        response = await self._client._request("GET", "/api/v1/admin/users")
        return response  # type: ignore[return-value]

    async def get_user(self, user_id: str) -> dict[str, Any]:
        """Get a user with all organization memberships."""
        response = await self._client._request("GET", f"/api/v1/admin/users/{user_id}")
        return response

    async def list_org_members(self, org_id: str) -> list[dict[str, Any]]:
        """List members of an organization."""
        response = await self._client._request(
            "GET", f"/api/v1/admin/organizations/{org_id}/members"
        )
        return response  # type: ignore[return-value]

    async def add_org_member(self, org_id: str, email: str, role: str = "member") -> dict[str, Any]:
        """Add a member to an organization, creating the user if needed."""
        response = await self._client._request(
            "POST",
            f"/api/v1/admin/organizations/{org_id}/members",
            json={"email": email, "role": role},
        )
        return response

    async def remove_org_member(self, org_id: str, user_id: str) -> None:
        """Remove a member from an organization."""
        await self._client._request(
            "DELETE", f"/api/v1/admin/organizations/{org_id}/members/{user_id}"
        )

    async def set_org_tier(self, org_id: str, tier: str) -> dict[str, Any]:
        """Set an organization's subscription tier and sync limits."""
        response = await self._client._request(
            "POST",
            f"/api/v1/admin/organizations/{org_id}/tier",
            json={"tier": tier},
        )
        return response


class SubscribeFlowClient:
    """SubscribeFlow API client.

    An async client for interacting with the SubscribeFlow API.
    Use as an async context manager for automatic resource cleanup.

    Example:
        >>> async with SubscribeFlowClient(api_key="sf_live_xxx") as client:
        ...     subscriber = await client.subscribers.create(email="user@example.com")

    Attributes:
        subscribers: Subscriber management operations
        tags: Tag management operations
        webhooks: Webhook management operations
        templates: Email template management operations
        emails: Email sending operations
        campaigns: Campaign management operations
        triggers: Email trigger management operations
        admin: Platform admin operations
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://api.subscribeflow.net",
        timeout: float = 30.0,
    ) -> None:
        """Initialize the SubscribeFlow client.

        Args:
            api_key: Your SubscribeFlow API key (e.g., sf_live_xxx)
            base_url: API base URL (default: https://api.subscribeflow.net)
            timeout: Request timeout in seconds (default: 30)
        """
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._client: httpx.AsyncClient | None = None

        # Resource namespaces
        self.subscribers = SubscribersResource(self)
        self.tags = TagsResource(self)
        self.webhooks = WebhooksResource(self)
        self.templates = TemplatesResource(self)
        self.emails = EmailsResource(self)
        self.campaigns = CampaignsResource(self)
        self.triggers = TriggersResource(self)
        self.notes = NotesResource(self)
        self.billing = BillingResource(self)
        self.admin = AdminResource(self)

    async def __aenter__(self) -> SubscribeFlowClient:
        """Enter async context manager."""
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
                "User-Agent": "subscribeflow-python/0.1.0",
            },
            timeout=httpx.Timeout(self._timeout),
        )
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit async context manager."""
        if self._client:
            await self._client.aclose()
            self._client = None

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make an API request.

        Args:
            method: HTTP method
            path: API path
            params: Query parameters
            json: Request body

        Returns:
            Response JSON data

        Raises:
            SubscribeFlowError: On API errors
        """
        if self._client is None:
            # Create a one-off client if not using context manager
            async with httpx.AsyncClient(
                base_url=self._base_url,
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                    "User-Agent": "subscribeflow-python/0.1.0",
                },
                timeout=httpx.Timeout(self._timeout),
            ) as client:
                return await self._do_request(client, method, path, params=params, json=json)
        else:
            return await self._do_request(self._client, method, path, params=params, json=json)

    async def _do_request(
        self,
        client: httpx.AsyncClient,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Execute the HTTP request."""
        response = await client.request(method, path, params=params, json=json)

        # Handle successful responses
        if response.status_code in (200, 201, 202):
            return response.json()

        if response.status_code == 204:
            return {}

        # Handle errors
        try:
            error_data = response.json()
        except (json.JSONDecodeError, ValueError):
            error_data = {"detail": response.text or "Unknown error"}

        raise SubscribeFlowError.from_response(error_data, response.status_code)

    async def close(self) -> None:
        """Close the client and release resources.

        This is called automatically when using the client as a context manager.
        """
        if self._client:
            await self._client.aclose()
            self._client = None

    def preference_center(self, token: str) -> PreferenceCenterResource:
        """Create a Preference Center resource with JWT token auth.

        Args:
            token: JWT token from subscribers.generate_token()

        Returns:
            PreferenceCenterResource for subscriber self-management
        """
        return PreferenceCenterResource(
            base_url=self._base_url,
            token=token,
            timeout=self._timeout,
        )
