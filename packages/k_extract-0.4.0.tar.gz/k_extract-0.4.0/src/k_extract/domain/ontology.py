"""Ontology type definitions and container model.

Implements the dual-type architecture (entities + relationships) with
schema (type definitions) and data (instances).
"""

from __future__ import annotations

import enum
import re

from pydantic import BaseModel, field_validator, model_validator

from k_extract.domain.entities import EntityInstance
from k_extract.domain.relationships import RelationshipInstance

PASCAL_CASE_RE = re.compile(r"^[A-Z][a-zA-Z0-9]*$")
UPPER_SNAKE_CASE_RE = re.compile(r"^[A-Z][A-Z0-9]*(_[A-Z0-9]+)*$")


class Tier(enum.StrEnum):
    """Entity type classification tier (spec section 1.5)."""

    STRUCTURAL = "structural"
    FILE_BASED = "file-based"
    SCENARIO_BASED = "scenario-based"


class RelationshipCategory(enum.StrEnum):
    """Relationship type classification category (spec section 1.6)."""

    STRUCTURAL = "structural"
    AGENT_MANAGED = "agent-managed"
    AGGREGATOR_MANAGED = "aggregator-managed"


class RelationshipDirection(BaseModel):
    """Forward or reverse relationship descriptor."""

    type: str
    description: str = ""

    @field_validator("type")
    @classmethod
    def validate_upper_snake_case(cls, v: str) -> str:
        if not UPPER_SNAKE_CASE_RE.match(v):
            msg = f"Relationship type name must be UPPER_SNAKE_CASE: {v!r}"
            raise ValueError(msg)
        return v


class EntityTypeDefinition(BaseModel):
    """Schema for an entity type (spec section 1.2)."""

    type: str
    description: str
    tier: Tier
    required_properties: list[str]
    optional_properties: list[str]
    property_definitions: dict[str, str]
    property_defaults: dict[str, str | bool | int | list[str]] = {}
    tag_definitions: dict[str, str] = {}

    @field_validator("type")
    @classmethod
    def validate_pascal_case(cls, v: str) -> str:
        if not PASCAL_CASE_RE.match(v):
            msg = f"Entity type name must be PascalCase: {v!r}"
            raise ValueError(msg)
        return v

    @property
    def is_structural(self) -> bool:
        """Structural types are protected from agent modification."""
        return self.tier == Tier.STRUCTURAL


class RelationshipTypeDefinition(BaseModel):
    """Schema for a relationship type (spec section 1.3).

    Keyed by composite key: "SourceEntityType|RELATIONSHIP_NAME|TargetEntityType"
    """

    source_entity_type: str
    target_entity_type: str
    forward_relationship: RelationshipDirection
    reverse_relationship: RelationshipDirection | None = None
    category: RelationshipCategory
    required_parameters: list[str]
    optional_parameters: list[str]
    property_definitions: dict[str, str] = {}

    @field_validator("source_entity_type", "target_entity_type")
    @classmethod
    def validate_entity_type_pascal_case(cls, v: str) -> str:
        if not PASCAL_CASE_RE.match(v):
            msg = f"Entity type name must be PascalCase: {v!r}"
            raise ValueError(msg)
        return v

    @property
    def composite_key(self) -> str:
        """Construct the composite key: SourceType|REL_NAME|TargetType."""
        return (
            f"{self.source_entity_type}"
            f"|{self.forward_relationship.type}"
            f"|{self.target_entity_type}"
        )

    @property
    def is_structural(self) -> bool:
        """Structural types are protected from agent modification."""
        return self.category == RelationshipCategory.STRUCTURAL

    @staticmethod
    def parse_composite_key(key: str) -> tuple[str, str, str]:
        """Parse a composite key into (source_type, rel_name, target_type).

        Raises ValueError if the key does not have exactly 3 parts.
        """
        parts = key.split("|")
        if len(parts) != 3:
            msg = f"Composite key must have exactly 3 parts separated by '|': {key!r}"
            raise ValueError(msg)
        return parts[0], parts[1], parts[2]


class Ontology(BaseModel):
    """Container for entity/relationship type definitions and instances.

    Provides lookup methods and validation for the ontology as a whole.
    """

    entity_types: dict[str, EntityTypeDefinition] = {}
    relationship_types: dict[str, RelationshipTypeDefinition] = {}
    entities: dict[str, EntityInstance] = {}
    relationships: list[RelationshipInstance] = []

    @model_validator(mode="after")
    def validate_relationship_type_keys(self) -> Ontology:
        """Ensure relationship_types dict keys match the composite keys."""
        for key, rel_type in self.relationship_types.items():
            if key != rel_type.composite_key:
                msg = (
                    f"Relationship type dict key {key!r} does not match "
                    f"composite key {rel_type.composite_key!r}"
                )
                raise ValueError(msg)
        return self

    @model_validator(mode="after")
    def validate_entity_type_keys(self) -> Ontology:
        """Ensure entity_types dict keys match the type field."""
        for key, entity_type in self.entity_types.items():
            if key != entity_type.type:
                msg = (
                    f"Entity type dict key {key!r} does not match "
                    f"type field {entity_type.type!r}"
                )
                raise ValueError(msg)
        return self

    @model_validator(mode="after")
    def validate_relationship_uniqueness(self) -> Ontology:
        """Ensure (composite_key, source_slug, target_slug) triples are unique."""
        seen: set[tuple[str, str, str]] = set()
        for rel in self.relationships:
            triple = (rel.composite_key, rel.source_slug, rel.target_slug)
            if triple in seen:
                msg = (
                    f"Duplicate relationship: {rel.composite_key!r} with "
                    f"source={rel.source_slug!r}, target={rel.target_slug!r}"
                )
                raise ValueError(msg)
            seen.add(triple)
        return self

    @model_validator(mode="after")
    def validate_entity_keys(self) -> Ontology:
        """Ensure entities dict keys match the slug field."""
        for key, entity in self.entities.items():
            if key != entity.slug:
                msg = (
                    f"Entity dict key {key!r} does not match slug field {entity.slug!r}"
                )
                raise ValueError(msg)
        return self

    @model_validator(mode="after")
    def validate_no_kebab_prefix_collisions(self) -> Ontology:
        """Ensure no two entity types produce the same kebab-case slug prefix.

        Different PascalCase names can map to the same kebab-case prefix
        (e.g., SREFile and SreFile both → sre-file), which would break
        slug-based lookups. Reject such collisions.
        """
        seen: dict[str, str] = {}
        for type_name in self.entity_types:
            kebab = _pascal_to_kebab(type_name)
            if kebab in seen:
                msg = (
                    f"Entity types {seen[kebab]!r} and {type_name!r} both produce "
                    f"kebab-case prefix {kebab!r} — slug prefixes must be unique"
                )
                raise ValueError(msg)
            seen[kebab] = type_name
        return self

    def get_entity_type(self, type_name: str) -> EntityTypeDefinition | None:
        """Look up an entity type definition by type name."""
        return self.entity_types.get(type_name)

    def get_relationship_type(
        self, composite_key: str
    ) -> RelationshipTypeDefinition | None:
        """Look up a relationship type definition by composite key."""
        return self.relationship_types.get(composite_key)

    def get_entity_by_slug(self, slug: str) -> EntityInstance | None:
        """Look up an entity instance by slug."""
        return self.entities.get(slug)

    def get_entities_by_type(self, type_name: str) -> list[EntityInstance]:
        """Get all entity instances of a given type.

        Args:
            type_name: PascalCase entity type name.
        """
        prefix = _pascal_to_kebab(type_name)
        return [e for e in self.entities.values() if e.entity_type == prefix]

    def find_entity_type_for_slug(self, slug: str) -> EntityTypeDefinition | None:
        """Find the entity type definition that matches a slug's type prefix."""
        slug_prefix = slug.split(":")[0]
        for entity_type_def in self.entity_types.values():
            if _pascal_to_kebab(entity_type_def.type) == slug_prefix:
                return entity_type_def
        return None

    def get_relationships_by_composite_key(
        self, composite_key: str
    ) -> list[RelationshipInstance]:
        """Get all relationship instances for a given composite key."""
        return [r for r in self.relationships if r.composite_key == composite_key]

    def validate_entity(self, entity: EntityInstance) -> list[str]:
        """Validate an entity instance against the ontology.

        Returns a list of validation error messages (empty if valid).
        """
        errors: list[str] = []

        # Find matching entity type definition via slug prefix
        entity_type_def = self.find_entity_type_for_slug(entity.slug)
        if entity_type_def is None:
            errors.append(
                f"Unknown entity type for slug prefix: {entity.entity_type!r}"
            )
            return errors

        # Structural type protection (spec section 4.4)
        if entity_type_def.is_structural:
            errors.append(
                f"Cannot modify entity of structural type "
                f"{entity_type_def.type!r}: protected from agent edits"
            )
            return errors

        # Check required properties
        for prop in entity_type_def.required_properties:
            if prop not in entity.properties:
                errors.append(
                    f"Missing required property {prop!r} on entity {entity.slug!r}"
                )

        # Check property types
        for prop_name, prop_value in entity.properties.items():
            if not _is_valid_property_value(prop_value):
                errors.append(
                    f"Invalid property type for {prop_name!r} on entity "
                    f"{entity.slug!r}: must be str, bool, int, or list[str]"
                )

        # Check tag validation
        if "tags" in entity.properties and entity_type_def.tag_definitions:
            tags = entity.properties["tags"]
            if isinstance(tags, list):
                allowed_tags = set(entity_type_def.tag_definitions.keys())
                for tag in tags:
                    if isinstance(tag, str) and tag not in allowed_tags:
                        errors.append(
                            f"Invalid tag {tag!r} on entity {entity.slug!r}. "
                            f"Allowed tags: {sorted(allowed_tags)}"
                        )
            else:
                errors.append(
                    f"Property 'tags' on entity {entity.slug!r} must be an "
                    f"array of strings, got {type(tags).__name__}"
                )

        return errors

    def validate_relationship(self, relationship: RelationshipInstance) -> list[str]:
        """Validate a relationship instance against the ontology.

        Returns a list of validation error messages (empty if valid).
        """
        errors: list[str] = []

        # Check relationship type exists
        rel_type_def = self.get_relationship_type(relationship.composite_key)
        if rel_type_def is None:
            errors.append(f"Unknown relationship type: {relationship.composite_key!r}")
            return errors

        # Structural type protection (spec section 4.4)
        if rel_type_def.is_structural:
            errors.append(
                f"Cannot modify relationship of structural type "
                f"{relationship.composite_key!r}: protected from agent edits"
            )
            return errors

        # Check referential integrity — source and target entities must exist
        # and their types must match the declared entity types (spec 4.2 rules 4-5)
        source_entity = self.get_entity_by_slug(relationship.source_slug)
        if source_entity is None:
            errors.append(f"Source entity not found: {relationship.source_slug!r}")
        else:
            expected_prefix = _pascal_to_kebab(relationship.source_entity_type)
            if source_entity.entity_type != expected_prefix:
                errors.append(
                    f"Source entity {relationship.source_slug!r} is of type "
                    f"{source_entity.entity_type!r}, expected "
                    f"{expected_prefix!r} (from {relationship.source_entity_type!r})"
                )

        target_entity = self.get_entity_by_slug(relationship.target_slug)
        if target_entity is None:
            errors.append(f"Target entity not found: {relationship.target_slug!r}")
        else:
            expected_prefix = _pascal_to_kebab(relationship.target_entity_type)
            if target_entity.entity_type != expected_prefix:
                errors.append(
                    f"Target entity {relationship.target_slug!r} is of type "
                    f"{target_entity.entity_type!r}, expected "
                    f"{expected_prefix!r} (from {relationship.target_entity_type!r})"
                )

        # Check required parameters
        for param in rel_type_def.required_parameters:
            if param not in relationship.properties:
                errors.append(
                    f"Missing required parameter {param!r} on relationship "
                    f"{relationship.composite_key!r}"
                )

        return errors

    def is_structural_entity_type(self, type_name: str) -> bool:
        """Check whether an entity type is structural (protected from agent edits)."""
        entity_type_def = self.get_entity_type(type_name)
        if entity_type_def is None:
            return False
        return entity_type_def.is_structural


def _is_valid_property_value(value: object) -> bool:
    """Check if a value is a valid property type (str, bool, int, list[str])."""
    if isinstance(value, str | bool | int):
        return True
    if isinstance(value, list):
        return all(isinstance(item, str) for item in value)
    return False


def _pascal_to_kebab(name: str) -> str:
    """Convert PascalCase to kebab-case for slug type prefix matching.

    Examples:
        'DataSource' -> 'data-source'
        'Product' -> 'product'
        'SREFile' -> 'sre-file'
        'ProductFile' -> 'product-file'
    """
    # Insert hyphen between a lowercase/digit and an uppercase letter
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1-\2", name)
    # Insert hyphen between consecutive uppercase when followed by lowercase
    # e.g., "SRE" + "File" -> "SRE-File"
    s = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1-\2", s)
    return s.lower()
