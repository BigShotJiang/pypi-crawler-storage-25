
class BaseService:
    pass
