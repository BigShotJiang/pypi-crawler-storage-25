

class Entity:
    pass
