"""Channels: send messages to running agent sessions via the backend API.

Channels use the backend API endpoints (POST /v1/channels/{session_id}/send,
GET /subscribe) with Redis PubSub for cross-instance delivery.

The daemon's PTY relay subscribes to the backend SSE stream and injects
messages into agent sessions via tmux send-keys.
"""
