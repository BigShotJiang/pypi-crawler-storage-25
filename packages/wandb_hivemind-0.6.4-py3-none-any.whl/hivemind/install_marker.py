"""Read the install-method marker written by ``scripts/install.sh``.

Kept in its own module so callers (e.g. ``service.py``) can read marker
fields without pulling in ``upgrade_watcher.py``'s httpx/packaging deps.
"""

from __future__ import annotations

import os
from pathlib import Path


def install_method_marker_path() -> Path:
    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = Path(xdg) if xdg else Path.home() / ".config"
    return base / "hivemind" / "install-method"


def read_install_marker_field(field: str) -> str | None:
    """Read a single value from the install-method marker.

    The marker is a tiny TOML-shaped key/value file; we parse it by hand
    to avoid an extra stdlib payload in the Nuitka onefile startup path.
    """
    try:
        text = install_method_marker_path().read_text(encoding="utf-8")
    except OSError:
        return None
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        if key.strip() != field:
            continue
        value = value.strip()
        if (value.startswith('"') and value.endswith('"')) or (
            value.startswith("'") and value.endswith("'")
        ):
            value = value[1:-1]
        return value or None
    return None
