"""File system watcher for session files.

Performance considerations:
- File events can fire rapidly (dozens per second during active editing)
- Expensive operations (SQLite queries, JSON parsing) must NOT run in callbacks
- Callbacks run in watchdog's thread pool - keep them minimal
- Use PendingPathTracker to collect paths, process them in the main loop
"""

from __future__ import annotations

import logging
import os
import sys
import threading
import time
from collections import OrderedDict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

# Import library adapters for consistent path resolution
from agentstream.adapters import get_all_watch_paths as _lib_get_watch_paths
from watchdog.events import (
    FileCreatedEvent,
    FileModifiedEvent,
    PatternMatchingEventHandler,
)
from watchdog.observers import Observer
from watchdog.observers.polling import PollingObserver

logger = logging.getLogger(__name__)


@dataclass
class HotSessionTracker:
    """Bounded tracker for recently-changed sessions.

    Thread-safe via GIL for simple operations. Uses OrderedDict
    to track insertion order for LRU eviction.
    """

    max_size: int = 100
    inactive_timeout: float = 3600.0  # 1 hour default

    # Internal state
    _sessions: OrderedDict = field(default_factory=OrderedDict)
    _timestamps: dict = field(default_factory=dict)

    @property
    def hot_sessions(self) -> set[str]:
        """Get set of hot session IDs."""
        return set(self._sessions.keys())

    def add(self, session_id: str, file_path: str) -> None:
        """Add or update a session in the hot set."""
        # Remove if exists (to update position in OrderedDict)
        if session_id in self._sessions:
            del self._sessions[session_id]

        # Add to end
        self._sessions[session_id] = file_path
        self._timestamps[session_id] = time.monotonic()

        # Evict oldest if over capacity
        while len(self._sessions) > self.max_size:
            oldest_id, _ = self._sessions.popitem(last=False)
            self._timestamps.pop(oldest_id, None)

    def get_path(self, session_id: str) -> str | None:
        """Get file path for a session."""
        return self._sessions.get(session_id)

    def drain(self) -> dict[str, str]:
        """Return all sessions and clear the hot set."""
        result = dict(self._sessions)
        self._sessions.clear()
        self._timestamps.clear()
        return result

    def prune_inactive(self) -> int:
        """Remove sessions inactive longer than timeout. Returns count removed."""
        now = time.monotonic()
        to_remove = [
            sid for sid, ts in self._timestamps.items() if now - ts > self.inactive_timeout
        ]
        for sid in to_remove:
            self._sessions.pop(sid, None)
            self._timestamps.pop(sid, None)
        return len(to_remove)


class PendingPathTracker:
    """Thread-safe tracker for paths with pending changes.

    Designed to be written from watchdog callbacks (fast, lock-free writes)
    and read from the main sync loop (batched drains).

    Uses a dict to deduplicate rapid changes to the same file.
    """

    def __init__(self, max_size: int = 1000):
        self._paths: dict[str, float] = {}  # path -> last_change_time
        self._lock = threading.Lock()
        self._max_size = max_size

    def add(self, path: Path) -> None:
        """Record a path change. Fast, safe to call from callbacks."""
        path_str = str(path)
        now = time.monotonic()

        with self._lock:
            self._paths[path_str] = now

            # Evict oldest if over capacity (unlikely but safe)
            if len(self._paths) > self._max_size:
                # Remove the oldest entry
                oldest = min(self._paths.items(), key=lambda x: x[1])
                del self._paths[oldest[0]]

    def drain(self) -> list[Path]:
        """Return all pending paths and clear the tracker.

        Returns paths sorted by change time (oldest first).
        """
        with self._lock:
            if not self._paths:
                return []

            # Sort by timestamp, return as Path objects
            sorted_items = sorted(self._paths.items(), key=lambda x: x[1])
            paths = [Path(p) for p, _ in sorted_items]
            self._paths.clear()
            return paths

    def __len__(self) -> int:
        """Return number of pending paths."""
        with self._lock:
            return len(self._paths)


def get_watch_paths() -> list[Path]:
    """Get paths to watch for session files.

    If the ``HIVEMIND_WATCH_PATHS`` environment variable is set, it is
    treated as a comma/``os.pathsep``-separated list of directories and those are used
    *instead* of the default adapter paths.  This is the primary
    mechanism for Docker/sidecar deployments where agent session files
    are mounted at non-standard locations (e.g. ``/watch/.claude``).

    Otherwise, uses library adapters for consistent path resolution.
    Adapters are auto-registered when agentstream.adapters is imported.
    """
    override = os.environ.get("HIVEMIND_WATCH_PATHS")
    if override:
        # Filter by is_dir(): observer.schedule(..., recursive=True) silently
        # no-ops on a file path, which would leave the daemon "running" but
        # not watching anything — a very confusing state for container ops.
        normalized = override.replace(os.pathsep, ",")
        paths = [Path(p.strip()).expanduser() for p in normalized.split(",") if p.strip()]
        return [p for p in paths if p.is_dir()]
    return _lib_get_watch_paths()


# On macOS, FSEvents does not detect appends to files with open file
# descriptors (Codex keeps its JSONL fd open). These paths use a
# stat-based PollingObserver instead. On Linux, inotify handles this
# correctly so no override is needed.
POLLING_PATHS = {Path.home() / ".codex" / "sessions"} if sys.platform == "darwin" else set()


def _session_path_from_event(path: Path) -> Path:
    """Normalize path for downstream session processing.

    SQLite WAL mode writes to *.vscdb-wal / *.db-wal, not the main DB file.
    We watch -wal so we see live writes; downstream code expects the main
    DB path (opening it will see latest data via WAL).
    """
    if path.name.endswith("-wal") and (".vscdb-wal" in path.name or ".db-wal" in path.name):
        return path.parent / path.name[: -len("-wal")]
    return path


class SessionEventHandler(PatternMatchingEventHandler):
    """Handle file system events for session files.

    Uses PatternMatchingEventHandler for efficient filtering at the
    watchdog level, before events reach our callback.

    Watches *.vscdb-wal so we see live Cursor/SQLite writes (WAL mode
    writes to -wal, not the main .vscdb file). Events for -wal are
    normalized to the corresponding .vscdb path for the rest of the pipeline.
    """

    # File patterns we care about. PatternMatchingEventHandler uses
    # fnmatch against the full event path. The ``runtime-logs/output.log``
    # entry is for the Copilot cloud SWE-agent's stdout capture at
    # ``$RUNNER_TEMP/runtime-logs/output.log``; scoping the pattern to
    # the parent directory keeps the watcher from waking on unrelated
    # ``output.log`` files elsewhere on disk (the adapter rejects them
    # later, but matching here is hot-path).
    SESSION_PATTERNS = [
        "*.jsonl",
        "*.json",
        "*.vscdb",
        "*.vscdb-wal",
        "*.db-wal",
        "*/runtime-logs/output.log",
    ]

    def __init__(self, on_change: Callable[[Path], None]):
        # Initialize with patterns - watchdog filters for us
        super().__init__(
            patterns=self.SESSION_PATTERNS,
            ignore_directories=True,
            case_sensitive=True,
        )
        self.on_change = on_change

    def on_created(self, event: FileCreatedEvent) -> None:
        """Handle file creation."""
        src_path = (
            os.fsdecode(event.src_path) if isinstance(event.src_path, bytes) else event.src_path
        )
        path = _session_path_from_event(Path(src_path))
        self.on_change(path)

    def on_modified(self, event: FileModifiedEvent) -> None:
        """Handle file modification."""
        src_path = (
            os.fsdecode(event.src_path) if isinstance(event.src_path, bytes) else event.src_path
        )
        path = _session_path_from_event(Path(src_path))
        self.on_change(path)

    def on_moved(self, event) -> None:
        """Handle rename/move events (e.g. temp file -> session file)."""
        raw_dest = getattr(event, "dest_path", None)
        raw_src = getattr(event, "src_path", None)
        raw_path = raw_dest if raw_dest else raw_src
        if not raw_path:
            return
        path_str = os.fsdecode(raw_path) if isinstance(raw_path, bytes) else raw_path
        path = _session_path_from_event(Path(path_str))
        self.on_change(path)

    def on_closed(self, event) -> None:
        """Handle close events for platforms that emit delayed write notifications."""
        raw_src = getattr(event, "src_path", None)
        if not raw_src:
            return
        path_str = os.fsdecode(raw_src) if isinstance(raw_src, bytes) else raw_src
        path = _session_path_from_event(Path(path_str))
        self.on_change(path)


class SessionWatcher:
    """Watch directories for session file changes.

    The watcher collects changed paths in a PendingPathTracker.
    Expensive operations (SQLite queries, session extraction) should
    be done by the caller after draining pending paths.

    Usage:
        watcher = SessionWatcher()
        watcher.start()

        # In your main loop:
        for path in watcher.drain_pending():
            # Do expensive processing here, not in callbacks
            sessions = extract_sessions_from_path(path)
            ...
    """

    def __init__(
        self,
        watch_paths: list[Path] | None = None,
        on_change: Callable[[Path], None] | None = None,
        poll_interval: float = 2.0,
    ):
        """Initialize the watcher.

        Args:
            watch_paths: Directories to watch. Defaults to all adapter paths.
            on_change: Optional callback for immediate notification (keep lightweight!).
                      For most use cases, use drain_pending() instead.
            poll_interval: Polling interval in seconds for directories that need
                          stat-based watching (agents that keep fds open).
        """
        self.watch_paths = watch_paths or get_watch_paths()
        self._pending = PendingPathTracker()
        self._external_callback = on_change
        self._poll_interval = poll_interval
        self.observer = Observer()
        self._polling_observer: PollingObserver | None = None

        # Internal callback that records path and optionally notifies
        def _on_change(path: Path) -> None:
            self._pending.add(path)
            if self._external_callback:
                self._external_callback(path)

        self.handler = SessionEventHandler(_on_change)

    def _needs_polling(self, path: Path) -> bool:
        """Check if a path needs stat-based polling instead of FSEvents."""
        resolved = path.resolve()
        return any(
            resolved == pp.resolve() or pp.resolve() in resolved.parents for pp in POLLING_PATHS
        )

    def start(self) -> None:
        """Start watching for file changes.

        Paths in POLLING_PATHS use a PollingObserver (stat-based) because
        some agents (e.g. Codex) keep file descriptors open, which prevents
        macOS FSEvents from detecting writes.  All other paths use the
        default FSEvents observer.
        """
        fsevents_paths = []
        polling_paths = []

        for path in self.watch_paths:
            if not path.exists():
                logger.debug(f"Skipping non-existent watch path: {path}")
                continue
            if self._needs_polling(path):
                polling_paths.append(path)
            else:
                fsevents_paths.append(path)

        # Schedule FSEvents paths on the default observer
        for path in fsevents_paths:
            try:
                self.observer.schedule(self.handler, str(path), recursive=True)
                logger.info(f"Watching (fsevents): {path}")
            except OSError as e:
                logger.warning(f"Failed to watch {path}: {e}")

        # Schedule polling paths on a separate PollingObserver
        if polling_paths:
            self._polling_observer = PollingObserver(timeout=self._poll_interval)
            for path in polling_paths:
                try:
                    self._polling_observer.schedule(self.handler, str(path), recursive=True)
                    logger.info(f"Watching (polling, {self._poll_interval}s): {path}")
                except OSError as e:
                    logger.warning(f"Failed to poll-watch {path}: {e}")

        try:
            self.observer.start()
        except OSError as e:
            logger.error(f"Failed to start file watcher: {e}")
            raise

        if self._polling_observer:
            try:
                self._polling_observer.start()
            except OSError as e:
                logger.warning(f"Failed to start polling observer: {e}")
                self._polling_observer = None

    def stop(self) -> None:
        """Stop watching for file changes."""
        self.observer.stop()
        self.observer.join(timeout=5)
        if self._polling_observer:
            self._polling_observer.stop()
            self._polling_observer.join(timeout=5)

    def is_alive(self) -> bool:
        """Check if watcher is running."""
        return self.observer.is_alive()

    def drain_pending(self) -> list[Path]:
        """Get all paths with pending changes and clear the queue.

        Call this periodically from your main loop to process changes.
        Returns paths sorted by change time (oldest first).
        """
        return self._pending.drain()

    def pending_count(self) -> int:
        """Return number of paths with pending changes."""
        return len(self._pending)
