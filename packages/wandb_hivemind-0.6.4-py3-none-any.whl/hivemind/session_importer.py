"""Session import logic for server-side normalization.

This module provides daemon-specific session metadata extraction on top of the
shared discovery logic in agentstream.discovery.

The discovery and source entry reading functions are provided by the library,
while this module adds metadata extraction that includes git information and
agent version detection.
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import sqlite3
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from agentstream.discovery import (
    discover_all_sessions,
    extract_branch_from_file,
    extract_cwd_from_file,
    get_session_cwd,
    read_source_entries,
)
from agentstream.adapters.copilot import _is_copilot_output_log, resolve_swe_agent_model
from agentstream.git_utils import get_git_branch_from_cwd, get_git_commit, get_git_repo

from hivemind import __version__ as DAEMON_VERSION

# Sentinel used when we have no record of which branch a session was created
# on. We deliberately avoid falling back to the current cwd HEAD for catch-up
# / historic syncs because the user may have switched branches since the
# session ran — attributing those sessions to today's branch produces
# misleading per-branch analytics. Empty string is reserved for "no git repo
# at all"; ``"unknown"`` means "we know there was a repo but can't tell which
# branch this session was on".
UNKNOWN_BRANCH = "unknown"

# Re-export library functions for backwards compatibility
__all__ = [
    "discover_all_sessions",
    "read_source_entries",
    "extract_session_metadata",
    "build_metadata_for_file",
    "get_session_cwd",
    "get_agent_version",
    "extract_cwd_from_file",
    "UNKNOWN_BRANCH",
]

logger = logging.getLogger(__name__)


def _path_exists_safe(path: str | Path) -> bool:
    """``Path.exists()`` that returns False on OSError (permission, etc)."""
    try:
        return Path(path).exists()
    except OSError:
        return False


# Cache for CLI version lookups (persists for daemon lifetime)
# Maps agent_type -> version string (or "unknown" if lookup failed)
_cli_version_cache: dict[str, str] = {}

# Common paths where CLI binaries might be installed
# These are checked when the binary isn't found via PATH
_COMMON_BIN_PATHS = [
    "/usr/local/bin",
    "/opt/homebrew/bin",
    str(Path.home() / ".local" / "bin"),
    str(Path.home() / "bin"),
]


# =============================================================================
# Branch Resolution
# =============================================================================


# Sentinel: distinguishes "caller did not pass git_repo" from "caller passed
# None/empty meaning no repo". Without it, we can't tell whether the catch-up
# branch should default to UNKNOWN_BRANCH (legacy callers) or "" (callers that
# computed git_repo and got None back).
_GIT_REPO_UNSET: object = object()


def _resolve_git_branch(
    *,
    recorded: str | None,
    file_path: Path | None,
    source_format: str | None,
    cwd: str | None,
    live: bool,
    git_repo: str | None | object = _GIT_REPO_UNSET,
) -> str:
    """Pick the best ``git_branch`` value for a session's metadata.

    Priority:
        1. ``recorded`` — branch captured at session creation (from discovery
           metadata). Always wins when present.
        2. (live only) branch extracted from the session file itself
           (``extract_branch_from_file``).
        3. (live only) current cwd HEAD (``get_git_branch_from_cwd``).
        4. ``UNKNOWN_BRANCH`` for catch-up / historic flows; empty string when
           there's no git repo at all.

    The catch-up path skips steps 2–3 so we don't backfill old sessions with
    today's branch — the user may have switched branches since the session
    ran.

    ``git_repo`` is the resolved repo URL for ``cwd`` (if already computed by
    the caller). When the caller explicitly passes a falsy value (``None`` or
    ``""``), we know the cwd isn't in a repo and return ``""`` rather than
    ``UNKNOWN_BRANCH`` — empty string is reserved for "no git repo at all"
    while ``UNKNOWN_BRANCH`` means "we know there was a repo but can't tell
    which branch".
    """
    if recorded:
        return recorded

    if not live:
        # Caller passed git_repo info: a falsy value means "no repo" → "".
        if git_repo is not _GIT_REPO_UNSET and not git_repo:
            return ""
        return UNKNOWN_BRANCH

    if file_path is not None and source_format:
        from_file = extract_branch_from_file(file_path, source_format)
        if from_file:
            return from_file

    if cwd:
        # Missing cwd → UNKNOWN_BRANCH rather than "" so the upload still
        # proceeds with usable metadata for deleted worktrees.
        if not _path_exists_safe(cwd):
            return UNKNOWN_BRANCH
        return get_git_branch_from_cwd(cwd) or ""

    return ""


# =============================================================================
# Cursor Metadata Building
# =============================================================================


def _extract_cursor_session_timestamps(vscdb_path: Path, composer_id: str) -> dict:
    """Extract session-level timestamps from Cursor's composerData.

    These timestamps are used as fallback when individual bubbles don't have
    createdAt fields, enabling duration calculation for older Cursor sessions.

    Args:
        vscdb_path: Path to workspace state.vscdb file.
        composer_id: The composerId to extract timestamps for.

    Returns:
        Dict with createdAt and/or lastUpdatedAt if found, empty dict otherwise.
    """
    timestamps: dict = {}

    try:
        conn = sqlite3.connect(f"file:{vscdb_path}?mode=ro", uri=True, timeout=10)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        cursor.execute(
            "SELECT value FROM ItemTable WHERE key = ?",
            ("composer.composerData",),
        )
        row = cursor.fetchone()
        conn.close()

        if not row:
            return timestamps

        composer_data = json.loads(row["value"])
        if isinstance(composer_data, dict):
            composer_data = composer_data.get("allComposers", [])
        if not isinstance(composer_data, list):
            return timestamps

        # Find the specific composer by ID
        for composer in composer_data:
            if isinstance(composer, dict) and composer.get("composerId") == composer_id:
                if "createdAt" in composer:
                    timestamps["createdAt"] = composer["createdAt"]
                if "lastUpdatedAt" in composer:
                    timestamps["lastUpdatedAt"] = composer["lastUpdatedAt"]
                break

    except (sqlite3.Error, json.JSONDecodeError, TypeError, OSError):
        # Silently ignore errors - timestamps are optional metadata.
        # Missing/corrupt data just means we won't have session-level timestamps.
        pass

    return timestamps


def _get_cursor_folder_path(workspace_dir: Path) -> str | None:
    """Get folder_path from Cursor's workspace.json.

    Args:
        workspace_dir: Path to workspace directory (parent of state.vscdb).

    Returns:
        The folder path (project cwd) or None if not found.
    """
    workspace_json = workspace_dir / "workspace.json"
    if not workspace_json.is_file():
        return None

    try:
        with open(workspace_json) as f:
            workspace_data = json.load(f)
            folder = workspace_data.get("folder")
            if folder and folder.startswith("file://"):
                return folder[7:]
    except (json.JSONDecodeError, OSError):
        # Silently ignore errors - folder_path is optional metadata.
        # Missing/corrupt workspace.json just means we won't have project path.
        pass

    return None


def _build_cursor_metadata(
    session: dict | None = None,
    file_path: Path | None = None,
    session_id: str | None = None,
    *,
    live: bool,
) -> dict:
    """Build metadata for Cursor session (unified for all sync modes).

    This function handles both cases:
    - session dict available (from discovery): uses pre-populated metadata
    - file_path only (from live sync): derives metadata from path structure

    Args:
        session: Session dict from discover_all_sessions() (optional).
        file_path: Path to state.vscdb file (required if no session).
        session_id: Composer ID (required if no session).
        live: ``True`` when called from the live sync path (hot-tracker
            watcher), ``False`` when called from a catch-up / historic
            import. Cursor doesn't record branch in its session data, so
            ``live=False`` returns ``UNKNOWN_BRANCH`` for ``git_branch``
            instead of falling back to the current cwd HEAD.

    Returns:
        Metadata dict with keys:
        - agent_type: "cursor"
        - agent_version: Version string or 'unknown'
        - daemon_version: Hivemind daemon version string
        - composerId: Composer session ID
        - workspace_dir: Path to workspace directory
        - cursor_user: Path to Cursor user directory
        - cwd: Working directory (project folder)
        - git_commit, git_repo, git_branch: Git info
        - createdAt, lastUpdatedAt: Session timestamps (for duration fallback)
        - import_time: ISO timestamp of import

    Raises:
        ValueError: If neither session nor (file_path, session_id) provided.
    """
    if session:
        # Extract from session dict (has metadata from discovery)
        file_path = Path(session["path"])
        session_id = session["id"]
        session_metadata = session.get("metadata", {})
    elif file_path and session_id:
        session_metadata = {}
    else:
        raise ValueError("Must provide either session dict or (file_path, session_id)")

    # Derive paths from vscdb location
    # e.g., .../Cursor/User/workspaceStorage/abc123/state.vscdb
    workspace_dir = file_path.parent
    cursor_user = workspace_dir.parent.parent  # workspaceStorage -> User

    # Get folder_path (project cwd) - prefer from session metadata, fallback to workspace.json
    folder_path = session_metadata.get("folder_path")
    if not folder_path:
        folder_path = _get_cursor_folder_path(workspace_dir)

    # cwd is folder_path if available, otherwise workspace_dir
    cwd = folder_path or str(workspace_dir)

    # Build base metadata
    metadata = {
        "agent_type": "cursor",
        "agent_version": get_agent_version("cursor", file_path),
        "daemon_version": DAEMON_VERSION,
        "composerId": session_id,
        "workspace_dir": str(workspace_dir),
        "cursor_user": str(cursor_user),
        "cwd": cwd,
        "import_time": datetime.now(timezone.utc).isoformat(),
    }

    # Extract git info from the project cwd (if we have a real folder path)
    if folder_path:
        folder_exists = _path_exists_safe(folder_path)
        git_commit = get_git_commit(folder_path) if folder_exists else None
        git_repo = get_git_repo(folder_path) if folder_exists else None

        metadata["git_commit"] = git_commit or ""
        metadata["git_repo"] = git_repo or ""
        # Cursor doesn't record branch in its session data, so for catch-up
        # we use UNKNOWN_BRANCH; for live sync the cwd HEAD is reliable
        # because the watcher only fires on active edits.
        metadata["git_branch"] = _resolve_git_branch(
            recorded=session_metadata.get("git_branch"),
            file_path=None,
            source_format=None,
            cwd=folder_path,
            live=live,
            git_repo=git_repo,
        )
    else:
        metadata["git_commit"] = ""
        metadata["git_repo"] = ""
        metadata["git_branch"] = ""

    # Add session-level timestamps (for duration fallback when bubbles lack createdAt)
    # Prefer from session metadata (already extracted during discovery)
    if "createdAt" in session_metadata:
        metadata["createdAt"] = session_metadata["createdAt"]
    if "lastUpdatedAt" in session_metadata:
        metadata["lastUpdatedAt"] = session_metadata["lastUpdatedAt"]

    # If timestamps not in session metadata, extract from composerData
    if "createdAt" not in metadata or "lastUpdatedAt" not in metadata:
        try:
            timestamps = _extract_cursor_session_timestamps(file_path, session_id)
            if "createdAt" in timestamps and "createdAt" not in metadata:
                metadata["createdAt"] = timestamps["createdAt"]
            if "lastUpdatedAt" in timestamps and "lastUpdatedAt" not in metadata:
                metadata["lastUpdatedAt"] = timestamps["lastUpdatedAt"]
        except Exception:
            pass  # Timestamps are optional

    return metadata


# =============================================================================
# Main Metadata Extraction Functions
# =============================================================================


def extract_session_metadata(session: dict) -> dict:
    """Extract metadata for a session.

    Extracts agent type, version, git information, and other metadata needed
    for server-side processing.

    Args:
        session: Session dict from discover_all_sessions() with 'path', 'format',
            'id', and 'metadata' keys.

    Returns:
        Metadata dict with keys:
        - agent_type: Agent type ('claude', 'codex', 'cursor', 'gemini')
        - agent_version: Version string or 'unknown'
        - daemon_version: Hivemind daemon version string
        - git_commit: Current git commit SHA or empty string
        - git_repo: Git repository URL or empty string
        - git_branch: Current git branch or empty string
        - cwd: Working directory path
        - import_time: ISO timestamp of import

        For Cursor, additional keys:
        - composerId: Composer session ID
        - workspace_dir: Path to workspace directory
        - cursor_user: Path to Cursor user directory
        - createdAt, lastUpdatedAt: Session timestamps (optional)

        NOTE: ``model`` is generally absent — for most agents it lives in
        source entries and is extracted by backend normalization. The one
        exception is the Copilot cloud SWE-agent (``runtime-logs/output.log``):
        no source entry carries the model on disk, so the daemon injects
        a placeholder via ``resolve_swe_agent_model()`` (real model from
        ``COPILOT_AGENT_MODEL``, or ``swe-agent`` fallback) so the
        backend's ``primary_model`` gate can emit ``SESSION_METADATA``.

    Raises:
        ValueError: If session has no cwd metadata.
    """
    session_format = session["format"]
    session_metadata = session.get("metadata") or {}

    # Cursor has special metadata handling
    if session_format == "cursor":
        return _build_cursor_metadata(session=session, live=False)

    # Get working directory for git metadata
    cwd = get_session_cwd(session)

    # cwd should NEVER be None - it's populated during session discovery
    if not cwd:
        logger.debug(f"Session {session.get('id')} has no cwd (e.g. unresolved Gemini hash)")
        raise ValueError(f"Session has no cwd: {session}")

    # Extract git metadata. Branch is resolved separately so we can prefer
    # the value the session was recorded on over the current cwd HEAD —
    # historic catch-up sessions are commonly imported long after the user
    # has switched branches, and attributing them to today's branch
    # produces misleading per-branch analytics.
    git_commit = get_git_commit(cwd)
    git_repo = get_git_repo(cwd)
    git_branch = _resolve_git_branch(
        recorded=session_metadata.get("git_branch"),
        file_path=None,
        source_format=None,
        cwd=None,
        live=False,
        git_repo=git_repo,
    )

    # The daemon is "dumb" — model comes from source entries and is extracted by
    # backend normalization. One exception lives below: the Copilot cloud
    # SWE-agent's output.log has no model anywhere on disk, so we attach a
    # ``swe-agent`` placeholder so the backend's primary_model gate doesn't
    # skip SESSION_METADATA emission.

    metadata = {
        "agent_type": session_format,
        "agent_version": get_agent_version(session_format, session["path"]),
        "daemon_version": DAEMON_VERSION,
        "git_commit": git_commit or "",
        "git_repo": git_repo or "",
        "git_branch": git_branch,
        "cwd": str(cwd),
        "import_time": datetime.now(timezone.utc).isoformat(),
    }

    # Cloud SWE-agent (Copilot's runtime-logs/output.log) never writes a
    # session.start or session.model_change to disk — the model lives only
    # in API response bodies the eBPF firewall sees as opaque bytes.
    # Without a model the backend's primary_model gate skips
    # SESSION_METADATA, the session-summary upsert never runs, and the
    # dashboard 404s. Ship a stable placeholder so the row lands.
    if _is_cloud_swe_agent_session(session_format, session["path"]):
        metadata["model"] = resolve_swe_agent_model()

    # Propagate parent_agent_session_id from discovery metadata (sub-agents)
    session_metadata = session.get("metadata") or {}
    if session_metadata.get("parent_agent_session_id"):
        metadata["parent_agent_session_id"] = session_metadata["parent_agent_session_id"]

    return metadata


def _is_cloud_swe_agent_session(source_format: str, file_path) -> bool:
    if source_format != "copilot":
        return False
    p = file_path if isinstance(file_path, Path) else Path(file_path)
    return _is_copilot_output_log(p)


def _extract_opencode_cwd(db_path: Path, session_id: str) -> Path | None:
    """Extract cwd for a specific OpenCode session from SQLite."""
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=10)
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT s.directory, p.worktree FROM session s "
            "LEFT JOIN project p ON s.project_id = p.id "
            "WHERE s.id = ?",
            (session_id,),
        ).fetchone()
        conn.close()
        if row:
            cwd_str = row["worktree"] or row["directory"]
            if cwd_str:
                return Path(cwd_str)
    except (sqlite3.Error, OSError):
        pass
    return None


def build_metadata_for_file(
    file_path: Path,
    source_format: str,
    session_id: str | None = None,
) -> dict:
    """Build metadata for a single session file (no discovery session dict).

    This is used by the live sync path where we only have a file path,
    not a full session dict from discovery. Uses the same logic as
    extract_session_metadata but extracts cwd directly from the file.

    Args:
        file_path: Path to the session file.
        source_format: Agent type ('claude', 'codex', 'cursor', 'gemini').
        session_id: Session ID (required for Cursor, optional for others).

    Returns:
        Metadata dict with keys:
        - agent_type: Agent type
        - agent_version: Version string or 'unknown'
        - daemon_version: Hivemind daemon version string
        - git_commit: Current git commit SHA or empty string
        - git_repo: Git repository URL or empty string
        - git_branch: Current git branch or empty string
        - cwd: Working directory path
        - import_time: ISO timestamp of import

        For Cursor, additional keys:
        - composerId: Composer session ID
        - workspace_dir: Path to workspace directory
        - cursor_user: Path to Cursor user directory
        - createdAt, lastUpdatedAt: Session timestamps (optional)

    Raises:
        ValueError: If cwd cannot be extracted from the file, or if Cursor
            format is used without session_id.
    """
    # Cursor has special metadata handling
    if source_format == "cursor":
        if not session_id:
            raise ValueError("session_id is required for Cursor format")
        return _build_cursor_metadata(file_path=file_path, session_id=session_id, live=True)

    # OpenCode: extract cwd from SQLite using the specific session_id
    if source_format == "opencode" and session_id and file_path.suffix == ".db":
        cwd = _extract_opencode_cwd(file_path, session_id)
    else:
        # Extract cwd from file content (handles all formats including [hash:...] placeholders)
        cwd = extract_cwd_from_file(file_path, source_format)

    if not cwd:
        # For Claude sessions, this typically means the session only has
        # file-history-snapshot entries without a cwd field yet. The cwd
        # appears with the first user/assistant message.
        raise ValueError(f"Could not extract cwd from {file_path}")

    # Skip filesystem git resolution when the cwd is gone — find_git_root would
    # walk up and mis-attribute a deleted worktree to its parent repo.
    cwd_exists = _path_exists_safe(cwd)
    git_commit = get_git_commit(cwd) if cwd_exists else None
    git_repo = get_git_repo(cwd) if cwd_exists else None
    git_branch = _resolve_git_branch(
        recorded=None,
        file_path=file_path,
        source_format=source_format,
        cwd=str(cwd),
        live=True,
    )

    metadata = {
        "agent_type": source_format,
        "agent_version": get_agent_version(source_format, file_path),
        "daemon_version": DAEMON_VERSION,
        "git_commit": git_commit or "",
        "git_repo": git_repo or "",
        "git_branch": git_branch,
        "cwd": str(cwd),
        "import_time": datetime.now(timezone.utc).isoformat(),
    }

    if _is_cloud_swe_agent_session(source_format, file_path):
        metadata["model"] = resolve_swe_agent_model()

    # Detect sub-agent files and extract parent session ID from path
    if file_path.parent.name == "subagents" and file_path.stem.startswith("agent-"):
        parent_uuid = file_path.parent.parent.name
        metadata["parent_agent_session_id"] = parent_uuid

    return metadata


def _find_cli_binary(binary_name: str) -> str | None:
    """Find a CLI binary, checking PATH and common installation locations.

    Args:
        binary_name: Name of the binary (e.g., "cursor", "claude")

    Returns:
        Full path to binary if found, None otherwise
    """
    # First try shutil.which (uses PATH)
    path = shutil.which(binary_name)
    if path:
        return path

    # Check common installation locations
    for bin_dir in _COMMON_BIN_PATHS:
        candidate = Path(bin_dir) / binary_name
        if candidate.is_file() and os.access(candidate, os.X_OK):
            return str(candidate)

    return None


def _get_cli_version(agent_type: str) -> str:
    """Get agent version by running CLI command (with caching).

    Results are cached for the daemon lifetime since CLI versions don't change.

    Args:
        agent_type: Agent type (claude, cursor, gemini, codex)

    Returns:
        Version string or "unknown" if not detected
    """
    # Check cache first
    if agent_type in _cli_version_cache:
        return _cli_version_cache[agent_type]

    # Binary names for each agent type
    binary_names = {
        "cursor": "cursor",
        "claude": "claude",
        "gemini": "gemini",
        "codex": "codex",
    }

    binary_name = binary_names.get(agent_type)
    if not binary_name:
        _cli_version_cache[agent_type] = "unknown"
        return "unknown"

    # Find the binary
    binary_path = _find_cli_binary(binary_name)
    if not binary_path:
        logger.debug(f"CLI binary not found: {binary_name}")
        _cli_version_cache[agent_type] = "unknown"
        return "unknown"

    try:
        # Run command with timeout to avoid hanging
        result = subprocess.run(
            [binary_path, "--version"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,  # Don't raise on non-zero exit
        )

        if result.returncode == 0 and result.stdout:
            # Get first line (e.g., "2.3.38" or "codex-cli 0.84.0")
            first_line = result.stdout.strip().split("\n")[0]
            # For codex, extract just the version number
            if agent_type == "codex" and "codex-cli" in first_line:
                parts = first_line.split()
                if len(parts) >= 2:
                    version = parts[1]  # "0.84.0"
                    _cli_version_cache[agent_type] = version
                    return version
            if first_line:
                _cli_version_cache[agent_type] = first_line
                return first_line

        _cli_version_cache[agent_type] = "unknown"
        return "unknown"

    except (subprocess.TimeoutExpired, subprocess.SubprocessError, OSError) as e:
        logger.debug(f"Failed to get version via CLI for {agent_type}: {e}")
        _cli_version_cache[agent_type] = "unknown"
        return "unknown"


def get_agent_version(agent_type: str, session_path: Path | None = None) -> str:
    """Get agent version from source data or by running CLI command.

    First attempts to read version from the session file itself (for JSONL-based
    formats), then falls back to running the CLI command (with caching).

    Args:
        agent_type: Agent type (claude, cursor, gemini, codex)
        session_path: Optional path to session file (to read version from source)

    Returns:
        Version string or "unknown" if not detected
    """
    # First, try to read version from source data (only for JSONL-based formats)
    if session_path and session_path.is_file() and agent_type in ("claude", "codex", "copilot"):
        try:
            with open(session_path, encoding="utf-8", errors="replace") as f:
                # Claude version may not be in the first entry (could be a
                # file-history-snapshot prelude). Copilot's session.start is
                # the first event today, but allow a small scan in case
                # telemetry/blank lines ever land before it. Codex records
                # the version in its first ``session_meta`` line.
                max_lines = 10 if agent_type in ("claude", "copilot") else 1

                for _ in range(max_lines):
                    line = f.readline()
                    if not line:
                        break

                    try:
                        data = json.loads(line)
                    except json.JSONDecodeError:
                        # Skip malformed lines and keep scanning.
                        continue

                    # Claude: version field directly in entry
                    if agent_type == "claude" and "version" in data:
                        return data["version"]

                    # Codex: cli_version in payload (in first line session_meta)
                    if agent_type == "codex" and data.get("type") == "session_meta":
                        payload = data.get("payload", {})
                        cli_version = payload.get("cli_version")
                        if cli_version:
                            return cli_version

                    # Copilot: copilotVersion in data of first session.start event
                    if agent_type == "copilot" and data.get("type") == "session.start":
                        copilot_version = (data.get("data") or {}).get("copilotVersion")
                        if copilot_version:
                            return copilot_version

        except (OSError, UnicodeDecodeError) as e:
            logger.debug(f"Failed to read version from session file: {e}")

    # Fallback: run CLI command (cached)
    return _get_cli_version(agent_type)
