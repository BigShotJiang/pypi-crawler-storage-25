"""File-drop IPC for ``hivemind alpha launch`` → daemon relay registration.

When ``hivemind alpha launch`` starts a new agent session it writes a small
JSON file into ``~/.hivemind/launches/`` and sends SIGUSR1 to the daemon.
The daemon picks up the file, registers an SSE relay for the session, and
deletes it.

This replaces the old indirect discovery path (file watcher → sync → scan
all 600+ sessions → resolve pane → resolve backend ID via API).
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import asdict, dataclass
from pathlib import Path

logger = logging.getLogger(__name__)

LAUNCH_DIR = Path.home() / ".hivemind" / "launches"

# Ignore launch files older than this (stale leftovers from crashes)
LAUNCH_MAX_AGE_S = 3600  # 1 hour


@dataclass
class LaunchRecord:
    """Metadata written by ``alpha launch`` for the daemon to pick up."""

    marker: str  # UUID, same as @hivemind_pane_id and --session-id
    agent: str  # e.g. "claude", "codex"
    pane_target: str  # tmux target like "0:0.0"

    # Optional — present when a worktree was created
    worktree_path: str | None = None
    launched_at: float = 0.0


def create_launch(record: LaunchRecord) -> Path:
    """Write a launch file for the daemon to pick up.

    Called by ``hivemind alpha launch`` before starting the agent.
    """
    LAUNCH_DIR.mkdir(parents=True, exist_ok=True)
    if record.launched_at == 0.0:
        record.launched_at = time.time()
    file_path = LAUNCH_DIR / f"{record.marker}.json"
    file_path.write_text(json.dumps(asdict(record), indent=2))
    logger.debug(f"Created launch file: {file_path.name}")
    return file_path


def check_for_launches() -> list[tuple[LaunchRecord, Path]]:
    """Read and validate pending launch files.

    Returns list of (record, file_path) tuples.  Stale files (> 1 hour)
    are deleted silently.
    """
    if not LAUNCH_DIR.exists():
        return []

    results: list[tuple[LaunchRecord, Path]] = []
    now = time.time()

    for launch_file in LAUNCH_DIR.glob("*.json"):
        try:
            data = json.loads(launch_file.read_text())
        except (json.JSONDecodeError, OSError) as e:
            logger.warning(f"Invalid launch file {launch_file.name}: {e}")
            continue

        if not isinstance(data, dict):
            logger.warning(f"Invalid launch file {launch_file.name}: not a JSON object")
            continue

        marker = data.get("marker")
        agent = data.get("agent")
        pane_target = data.get("pane_target")
        if not marker or not agent or not pane_target:
            logger.warning(f"Invalid launch file {launch_file.name}: missing required fields")
            continue

        launched_at = data.get("launched_at", 0.0)
        if launched_at and (now - launched_at) > LAUNCH_MAX_AGE_S:
            logger.debug(f"Deleting stale launch file {launch_file.name}")
            _delete_file(launch_file)
            continue

        record = LaunchRecord(
            marker=marker,
            agent=agent,
            pane_target=pane_target,
            worktree_path=data.get("worktree_path"),
            launched_at=launched_at,
        )
        results.append((record, launch_file))

    return results


def delete_launch(file_path: Path) -> bool:
    """Delete a launch file after the daemon has processed it."""
    return _delete_file(file_path)


def _delete_file(path: Path) -> bool:
    try:
        path.unlink()
        return True
    except OSError as e:
        logger.warning(f"Failed to delete launch file {path}: {e}")
        return False
