"""Configure SSL to prefer the system trust store over bundled certificates.

No-op on source installs: `truststore.inject_into_ssl()` only runs inside
the Nuitka-compiled binary (detected via the `__compiled__` module marker).
Source installs keep using certifi via httpx defaults so existing user
behavior is unchanged.
"""

from __future__ import annotations

import logging

import truststore

log = logging.getLogger(__name__)

_configured = False


def configure_ssl() -> None:
    global _configured
    if _configured or "__compiled__" not in globals():
        return
    _configured = True

    truststore.inject_into_ssl()
    log.debug("SSL: using system trust store via truststore")
