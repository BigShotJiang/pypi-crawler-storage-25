"""MCP server for `hivemind mcp` — runs the daemon loop alongside JSON-RPC over stdio."""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any, Literal

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from hivemind.mcp.status import get_status

logger = logging.getLogger(__name__)

Mode = Literal["active", "passive_observer"]

# Copilot agent runs are short; sync more often than the desktop default (30s).
DEFAULT_MCP_INTERVAL = 5


def build_server(state_path: Path, mode: Mode = "active") -> Server:
    server: Server = Server("hivemind")

    @server.list_tools()
    async def _list_tools() -> list[Tool]:
        return [
            Tool(
                name="status",
                description=(
                    "Return the HiveMind daemon's live sync state: how many "
                    "sessions have been discovered and uploaded, any "
                    "quarantined or failing sessions, last sync timestamp, "
                    "and the most recent auth error if any. Also reports "
                    "`mode`: 'active' (this MCP process is the daemon) or "
                    "'passive_observer' (another daemon holds the lock and "
                    "is doing the syncing — we just report its state)."
                ),
                inputSchema={"type": "object", "properties": {}, "additionalProperties": False},
            )
        ]

    @server.call_tool()
    async def _call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        if name != "status":
            raise ValueError(f"Unknown tool: {name}")
        snapshot = get_status(state_path, mode=mode)
        return [TextContent(type="text", text=json.dumps(snapshot, indent=2, default=str))]

    return server


async def serve_stdio(server: Server) -> None:
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


async def run_mcp(
    state_path: Path,
    interval: int,
    skip_historic_import: bool,
    skip_catchup: bool,
    mode: Mode = "active",
) -> None:
    server = build_server(state_path, mode=mode)
    mcp_task = asyncio.create_task(serve_stdio(server), name="hivemind-mcp-server")

    if mode == "passive_observer":
        logger.info("MCP server running in passive_observer mode (system daemon owns the lock)")
        try:
            await mcp_task
        except (KeyboardInterrupt, asyncio.CancelledError):
            mcp_task.cancel()
            await asyncio.gather(mcp_task, return_exceptions=True)
        return

    # Deferred so setup_mcp_logging() can run before any daemon imports.
    from hivemind.cli import _run_daemon  # noqa: PLC0415

    daemon_task = asyncio.create_task(
        _run_daemon(
            interval=interval,
            state_path=state_path,
            skip_historic_import=skip_historic_import,
            skip_catchup=skip_catchup,
            test_mode=False,
            relay=False,
        ),
        name="hivemind-daemon-loop",
    )

    try:
        done, pending = await asyncio.wait(
            {daemon_task, mcp_task},
            return_when=asyncio.FIRST_COMPLETED,
        )
        for task in pending:
            task.cancel()
        for task in pending:
            try:
                await task
            except asyncio.CancelledError:
                pass
            except Exception:
                logger.exception("Background task %s raised during shutdown", task.get_name())
        # Prefer daemon_task's exception — a daemon crash is the more serious failure.
        if daemon_task in done and (exc := daemon_task.exception()):
            if not isinstance(exc, asyncio.CancelledError):
                raise exc
        if mcp_task in done and (exc := mcp_task.exception()):
            if not isinstance(exc, asyncio.CancelledError):
                raise exc
    except (KeyboardInterrupt, asyncio.CancelledError):
        daemon_task.cancel()
        mcp_task.cancel()
        await asyncio.gather(daemon_task, mcp_task, return_exceptions=True)
