from hivemind.mcp.logging import setup_mcp_logging

__all__ = ["setup_mcp_logging"]
