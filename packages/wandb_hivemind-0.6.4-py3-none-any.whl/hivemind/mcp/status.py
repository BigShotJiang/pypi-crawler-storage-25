"""Read live daemon state for the MCP `status` tool."""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

from hivemind.config import get_base_endpoint, get_effective_endpoint
from hivemind.state import load_state

if TYPE_CHECKING:
    from hivemind.mcp.server import Mode

logger = logging.getLogger(__name__)


def get_status(state_path: Path, mode: "Mode" = "active") -> dict[str, Any]:
    """Snapshot of sync state for the `status` MCP tool.

    Returns ``ready=False`` when ``state.json`` doesn't exist yet — callers
    use this to distinguish a fresh boot from a healthy empty state.
    """
    state_file = state_path / "state.json"

    if not state_file.exists():
        return {
            "ready": False,
            "mode": mode,
            "reason": "state file not yet written",
            "state_file": str(state_file),
        }

    try:
        state = load_state(state_file)
    except Exception as exc:
        logger.warning("Failed to load state for MCP status tool: %s", exc)
        return {
            "ready": False,
            "mode": mode,
            "reason": f"state load failed: {exc}",
            "state_file": str(state_file),
        }

    endpoint = get_effective_endpoint()
    base = get_base_endpoint(endpoint)
    server_state = state.get_server_state(base)

    now = time.time()
    sessions = server_state.sessions
    sessions_synced = sum(1 for s in sessions.values() if s.last_entry_idx >= 0)
    quarantined = sum(1 for s in sessions.values() if s.quarantined_until > now)
    failing = {
        sid: s.consecutive_failures for sid, s in sessions.items() if s.consecutive_failures > 0
    }

    return {
        "ready": True,
        "mode": mode,
        "endpoint": endpoint,
        "sessions_total": len(sessions),
        "sessions_synced": sessions_synced,
        "quarantined": quarantined,
        "failing": failing,
        "last_sync_at_ms": server_state.last_sync_ts,
        "last_auth_error": server_state.last_auth_error or None,
        "last_auth_error_message": server_state.last_auth_error_message or None,
    }
