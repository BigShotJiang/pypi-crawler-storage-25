"""Stdio-safe logging for `hivemind mcp`: stderr-only logger + click.echo redirect."""

from __future__ import annotations

import logging
import os
import sys

import click

_DEFAULT_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"

_original_click_echo = click.echo
_click_echo_redirected = False


def _level_from_env() -> int:
    raw = os.environ.get("HIVEMIND_LOG_LEVEL", "INFO").upper()
    return getattr(logging, raw, logging.INFO)


def setup_mcp_logging() -> None:
    """Install a stderr-only handler on the root logger (idempotent)."""
    root = logging.getLogger()
    root.setLevel(_level_from_env())

    for existing in root.handlers[:]:
        stream = getattr(existing, "stream", None)
        if stream is sys.stdout:
            root.removeHandler(existing)
            continue
        if isinstance(existing, logging.StreamHandler) and stream is sys.stderr:
            root.removeHandler(existing)

    handler = logging.StreamHandler(sys.stderr)
    handler.setLevel(_level_from_env())
    handler.setFormatter(logging.Formatter(_DEFAULT_FORMAT))
    root.addHandler(handler)

    logging.getLogger("watchdog").setLevel(logging.WARNING)
    logging.getLogger("fsevents").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)

    _redirect_click_echo_to_stderr()


def _redirect_click_echo_to_stderr() -> None:
    global _click_echo_redirected
    if _click_echo_redirected:
        return

    def _echo_to_stderr_default(message=None, file=None, **kwargs):
        if file is None:
            file = sys.stderr
        return _original_click_echo(message, file=file, **kwargs)

    # wrapper accepts click.echo's full kwargs via **kwargs
    click.echo = _echo_to_stderr_default  # ty: ignore[invalid-assignment]
    _click_echo_redirected = True
