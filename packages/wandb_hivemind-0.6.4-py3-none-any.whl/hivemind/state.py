"""Daemon state management with file locking."""

from __future__ import annotations

import fcntl
import json
import logging
import os
import shutil
import subprocess
import tempfile
import time
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Generator

from pydantic import BaseModel, Field

if TYPE_CHECKING:
    from agentstream.adapters.base import Adapter

logger = logging.getLogger(__name__)

# Current state schema version - bump when making breaking changes
CURRENT_STATE_VERSION = 4

# Sessions older than ~6 months are pruned from state
SESSION_MAX_AGE_SECONDS = 180 * 86400


class SessionSyncState(BaseModel):
    """Minimal per-session tracking for incremental sync.

    ~100 bytes per session when serialized to JSON.
    """

    file_path: str  # Path to session file for quick access
    last_entry_idx: int = -1  # Last entry index we uploaded (-1 = never synced)
    last_mtime: float = 0.0  # File mtime when last synced
    consecutive_failures: int = 0  # Resets on a successful sync
    quarantined_until: float = 0.0  # Unix seconds; 0 = not quarantined


class ServerState(BaseModel):
    """Per-server state for tracking sync progress.

    Each server endpoint has its own independent state for sessions,
    sync timestamps, and import history. This allows syncing to multiple
    servers (e.g., dev, staging, production) without interference.
    """

    # Per-session sync tracking (session_id -> SessionSyncState)
    sessions: dict[str, SessionSyncState] = Field(default_factory=dict)

    # Millisecond timestamp of last synced event
    last_sync_ts: int = 0

    # Pending events buffer
    pending_buffer: list[dict] = Field(default_factory=list)

    # Unix timestamp (seconds) of last historic import, 0 = never imported
    historic_import_ts: int = 0

    # Unix timestamp (seconds) when daemon was last running
    # Updated periodically during runtime and on shutdown
    # Used by catch-up sync to detect sessions modified while daemon was stopped
    last_daemon_run_ts: int = 0

    # Unix timestamp (milliseconds) of last globalStorage scan for Cursor
    # Used for incremental scanning: only query bubbles created after this time
    cursor_last_global_scan_ts: int = 0

    # Sessions with mtime <= this were pruned after being synced.
    # Discovery should skip unknown sessions at or below this mtime.
    pruned_before_ts: float = 0.0

    # Last authentication error the daemon encountered against this server
    # (e.g. "sso_required"). Empty string when the last sync attempt succeeded.
    # Surfaced by `hivemind status` so users can see that the daemon is
    # running but failing every upload, and what action they should take.
    last_auth_error: str = ""
    last_auth_error_ts: int = 0
    last_auth_error_message: str = ""

    @property
    def historic_import_completed(self) -> bool:
        """Check if historic import was completed for this server."""
        return self.historic_import_ts > 0

    def prune_old_sessions(self) -> int:
        """Remove sessions older than 6 months from state. Returns count removed."""
        cutoff = time.time() - SESSION_MAX_AGE_SECONDS
        # Only prune sessions that are old AND have never been successfully synced.
        # Cursor sessions may have ancient workspace file mtimes even when they
        # have recent entries (data lives in globalStorage, not the workspace vscdb).
        # Without the last_entry_idx check, these get pruned immediately after sync
        # and then re-synced from scratch on the next cycle — an infinite loop.
        to_remove = [
            sid
            for sid, s in self.sessions.items()
            if 0 < s.last_mtime < cutoff and s.last_entry_idx < 0
        ]
        if to_remove:
            max_pruned_mtime = max(self.sessions[sid].last_mtime for sid in to_remove)
            self.pruned_before_ts = max(self.pruned_before_ts, max_pruned_mtime)
            for sid in to_remove:
                del self.sessions[sid]
        return len(to_remove)


def _normalize_endpoint(endpoint: str) -> str:
    """Normalize endpoint URL for use as a dictionary key.

    Strips trailing slashes and known path suffixes to ensure consistent keys.
    """
    key = endpoint.rstrip("/")
    for suffix in ["/v1/ingest/sessions", "/v1/ingest"]:
        if key.endswith(suffix):
            key = key[: -len(suffix)]
            break
    return key


# Default endpoint used for migrating v1 state (before server scoping existed)
# V1 users were likely using localhost:8080 during development
DEFAULT_MIGRATION_ENDPOINT = "http://localhost:8080"


class PendingRestart(BaseModel):
    """Upgrade metadata persisted before the daemon exits so the
    service supervisor (launchd / brew services / systemd) can
    restart it with a newly-installed binary or wheel.

    The upgrade watcher sets this field after a successful apply and
    *separately* signals ``shutdown_event`` to initiate the exit —
    this field is NOT what triggers the shutdown, it's just a
    post-restart breadcrumb. The daemon main loop reads it at
    startup, logs / emits telemetry for the version transition, and
    clears it.
    """

    from_version: str
    to_version: str
    applied_at: int  # Unix seconds
    method: str  # "brew-cask", "brew", "pkg", "uv-tool", ...
    reason: str = ""


class DaemonState(BaseModel):
    """Persistent state for the daemon.

    State is scoped per-server to support syncing to multiple endpoints
    (e.g., localhost:8080 for dev, production server, etc.).
    """

    version: int = CURRENT_STATE_VERSION
    device_id: str = ""

    # Per-server state, keyed by normalized endpoint URL
    servers: dict[str, ServerState] = Field(default_factory=dict)

    # Breadcrumb written by the upgrade watcher after a successful
    # apply, inspected by the daemon at startup to log/report the
    # version transition. The SHUTDOWN itself is signalled by the
    # watcher (via shutdown_event.set()), not by the main loop
    # reading this field — so this is strictly a post-restart
    # marker. Default None means "no upgrade just happened". Old
    # state files without this key load fine because Pydantic uses
    # the default.
    pending_restart: PendingRestart | None = None

    # Hot set: session_ids with recent file activity (bounded, not persisted)
    # Note: This is transient - populated by watcher, cleared on shutdown
    hot_sessions: set[str] = Field(default_factory=set, exclude=True)

    def get_server_state(self, endpoint: str) -> ServerState:
        """Get or create state for a specific server endpoint.

        Args:
            endpoint: The server endpoint URL (will be normalized).

        Returns:
            ServerState for the given endpoint.
        """
        key = _normalize_endpoint(endpoint)
        if key not in self.servers:
            self.servers[key] = ServerState()
        return self.servers[key]

    # Backwards-compatibility properties that delegate to default server
    # These are DEPRECATED but kept for gradual migration of calling code
    @property
    def sessions(self) -> dict[str, SessionSyncState]:
        """DEPRECATED: Use get_server_state(endpoint).sessions instead."""
        return self.get_server_state(DEFAULT_MIGRATION_ENDPOINT).sessions

    @property
    def last_sync_ts(self) -> int:
        """DEPRECATED: Use get_server_state(endpoint).last_sync_ts instead."""
        return self.get_server_state(DEFAULT_MIGRATION_ENDPOINT).last_sync_ts

    @last_sync_ts.setter
    def last_sync_ts(self, value: int) -> None:
        """DEPRECATED setter for last_sync_ts."""
        self.get_server_state(DEFAULT_MIGRATION_ENDPOINT).last_sync_ts = value

    @property
    def pending_buffer(self) -> list[dict]:
        """DEPRECATED: Use get_server_state(endpoint).pending_buffer instead."""
        return self.get_server_state(DEFAULT_MIGRATION_ENDPOINT).pending_buffer

    @property
    def historic_import_ts(self) -> int:
        """DEPRECATED: Use get_server_state(endpoint).historic_import_ts instead."""
        return self.get_server_state(DEFAULT_MIGRATION_ENDPOINT).historic_import_ts

    @historic_import_ts.setter
    def historic_import_ts(self, value: int) -> None:
        """DEPRECATED setter for historic_import_ts."""
        self.get_server_state(DEFAULT_MIGRATION_ENDPOINT).historic_import_ts = value

    @property
    def historic_import_completed(self) -> bool:
        """DEPRECATED: Use get_server_state(endpoint).historic_import_completed instead."""
        return self.get_server_state(DEFAULT_MIGRATION_ENDPOINT).historic_import_completed


# =============================================================================
# State Migrations
# =============================================================================


def _migrate_v1_to_v2(data: dict) -> dict:
    """Migrate v1 -> v2: Add server scoping and convert historic_import_completed.

    V2 introduces per-server state scoping. All v1 state is moved under the
    default production server endpoint. This allows users to sync to multiple
    servers (dev, staging, production) with independent state.

    Migration strategy:
    1. Move sessions, last_sync_ts, pending_buffer under servers[default_endpoint]
    2. Convert historic_import_completed bool to historic_import_ts timestamp
    3. Remove deprecated flat fields from root
    """
    # Get session count before migration for logging
    sessions = data.get("sessions", {})
    session_count = len(sessions) if isinstance(sessions, dict) else 0

    # Calculate historic_import_ts from v1 data
    # Check multiple sources in priority order:
    # 1. Existing historic_import_ts (some v1 states already have this field)
    # 2. historic_import_completed boolean (original v1 field)
    # 3. Default to 0 (never imported)
    existing_ts = data.get("historic_import_ts", 0)
    if existing_ts:
        # Preserve existing timestamp
        historic_import_ts = existing_ts
    elif data.get("historic_import_completed", False):
        # Convert boolean to timestamp using last_sync_ts or sentinel value
        last_sync_ms = data.get("last_sync_ts", 0)
        historic_import_ts = (last_sync_ms // 1000) if last_sync_ms else 1
    else:
        historic_import_ts = 0

    # Build the per-server state from v1 flat fields
    server_state = {
        "sessions": sessions,
        "last_sync_ts": data.get("last_sync_ts", 0),
        "pending_buffer": data.get("pending_buffer", []),
        "historic_import_ts": historic_import_ts,
    }

    # Move state under the default server endpoint
    data["servers"] = {
        DEFAULT_MIGRATION_ENDPOINT: server_state,
    }

    # Remove deprecated flat fields from root
    data.pop("historic_import_completed", None)
    data.pop("sessions", None)
    data.pop("last_sync_ts", None)
    data.pop("pending_buffer", None)
    data.pop("historic_import_ts", None)

    data["version"] = 2

    logger.info(
        f"Migrated state from v1 to v2: {session_count} sessions moved under "
        f"{DEFAULT_MIGRATION_ENDPOINT} (historic_import_ts={historic_import_ts})"
    )
    return data


def _migrate_v2_to_v3(data: dict) -> dict:
    """Migrate v2 -> v3: Add last_daemon_run_ts for catch-up sync.

    V3 adds per-server last_daemon_run_ts tracking. This field records when the
    daemon was last running, allowing catch-up sync to detect sessions modified
    while the daemon was stopped.

    Migration strategy:
    - Compute initial last_daemon_run_ts from max session mtime for each server
    - This ensures first catch-up sync doesn't re-sync everything
    """
    servers = data.get("servers", {})

    # Validate that servers is a dict - if not, the state is malformed
    if not isinstance(servers, dict):
        raise ValueError(f"Invalid servers field type: {type(servers).__name__}, expected dict")

    for endpoint, server_state in servers.items():
        # Compute last_daemon_run_ts from max session mtime
        sessions = server_state.get("sessions", {})
        max_mtime = 0.0
        for session_state in sessions.values():
            mtime = session_state.get("last_mtime", 0.0)
            if mtime > max_mtime:
                max_mtime = mtime

        # Set last_daemon_run_ts to max mtime (or 0 if no sessions)
        server_state["last_daemon_run_ts"] = int(max_mtime)

        if max_mtime > 0:
            logger.info(
                f"v2->v3 migration: {endpoint} last_daemon_run_ts set to {int(max_mtime)} "
                f"(computed from {len(sessions)} sessions)"
            )

    data["version"] = 3
    return data


def _migrate_v3_to_v4(data: dict) -> dict:
    """Migrate v3 -> v4: Add cursor_last_global_scan_ts for incremental scanning.

    V4 adds per-server cursor_last_global_scan_ts tracking. This field records the
    last time we scanned Cursor's globalStorage for new bubbles, allowing incremental
    scanning instead of full discovery on every globalStorage change.

    Migration strategy:
    - Initialize cursor_last_global_scan_ts to 0 (will do full scan on first change)
    """
    servers = data.get("servers", {})

    if not isinstance(servers, dict):
        raise ValueError(f"Invalid servers field type: {type(servers).__name__}, expected dict")

    for server_state in servers.values():
        # Initialize cursor_last_global_scan_ts to 0
        # This means first globalStorage change will do a full scan to catch up
        server_state["cursor_last_global_scan_ts"] = 0

    data["version"] = 4
    logger.info("Migrated state from v3 to v4: added cursor_last_global_scan_ts")
    return data


# Registry of migrations: source_version -> migration_function
_MIGRATIONS: dict[int, Callable[[dict], dict]] = {
    1: _migrate_v1_to_v2,
    2: _migrate_v2_to_v3,
    3: _migrate_v3_to_v4,
}


def _migrate_state_data(data: dict) -> dict:
    """Apply sequential migrations to bring state data to current version.

    Migrations are applied in order from the data's version to CURRENT_STATE_VERSION.
    Each migration function receives the data dict and returns the updated dict.
    """
    version = data.get("version", 1)

    # Handle invalid version types gracefully
    if not isinstance(version, int):
        logger.warning(f"Invalid version type {type(version).__name__}, treating as v1")
        version = 1
        data["version"] = 1

    if version > CURRENT_STATE_VERSION:
        logger.warning(
            f"State version {version} is newer than supported {CURRENT_STATE_VERSION}. "
            f"This may indicate running an older daemon version. Proceeding with caution."
        )
        return data

    while version < CURRENT_STATE_VERSION:
        if version not in _MIGRATIONS:
            logger.error(f"No migration path from version {version}")
            break

        logger.info(f"Migrating state from v{version} to v{version + 1}")
        data = _MIGRATIONS[version](data)
        version = data.get("version", version + 1)

    return data


def _backup_state_file(state_file: Path, reason: str) -> Path | None:
    """Create a timestamped backup of the state file.

    Returns the backup path if successful, None otherwise.
    """
    if not state_file.exists():
        return None

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = state_file.with_suffix(f".backup_{timestamp}.json")

    try:
        shutil.copy2(state_file, backup_path)
        logger.warning(f"Created backup of state file: {backup_path} (reason: {reason})")
        return backup_path
    except OSError as e:
        logger.error(f"Failed to create state backup: {e}")
        return None


def load_state(state_file: Path) -> DaemonState:
    """Load state from file, returning default if missing.

    If the state file exists but cannot be parsed, creates a backup
    before returning empty state to prevent data loss.
    """
    if not state_file.exists():
        logger.info(f"No state file found at {state_file}, starting fresh")
        return DaemonState()

    try:
        content = state_file.read_text()
        if not content.strip():
            logger.warning(f"State file {state_file} is empty, starting fresh")
            return DaemonState()

        data = json.loads(content)

        # Run migrations if needed
        data = _migrate_state_data(data)

        return DaemonState.model_validate(data)

    except json.JSONDecodeError as e:
        _backup_state_file(state_file, f"JSON parse error: {e}")
        logger.error(
            f"State file {state_file} contains invalid JSON: {e}. "
            f"A backup was created. Starting with fresh state."
        )
        return DaemonState()

    except ValueError as e:
        _backup_state_file(state_file, f"validation error: {e}")
        logger.error(
            f"State file {state_file} failed validation: {e}. "
            f"A backup was created. Starting with fresh state."
        )
        return DaemonState()


def save_state(state: DaemonState, state_file: Path) -> None:
    """Atomically save state to file."""
    state_file.parent.mkdir(parents=True, exist_ok=True)

    # Write to temp file first
    fd, tmp_path = tempfile.mkstemp(dir=state_file.parent, prefix=".state_", suffix=".tmp")
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(state.model_dump(), f)
            f.flush()
            os.fsync(f.fileno())

        # Atomic rename
        os.rename(tmp_path, state_file)
    except Exception:
        # Clean up temp file on error
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)
        raise


@contextmanager
def acquire_lock(lock_file: Path) -> Generator[None, None, None]:
    """Acquire exclusive lock to ensure single daemon instance."""
    lock_file.parent.mkdir(parents=True, exist_ok=True)

    # Open with "a" (append) to avoid truncating an existing PID while
    # another daemon holds the lock.  We truncate only after acquiring it.
    lock_fd = open(lock_file, "a")
    try:
        fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        lock_fd.close()
        raise RuntimeError("Another hivemind daemon is already running")

    try:
        lock_fd.seek(0)
        lock_fd.truncate()
        lock_fd.write(str(os.getpid()))
        lock_fd.flush()
        yield
    finally:
        fcntl.flock(lock_fd, fcntl.LOCK_UN)
        lock_fd.close()


# =============================================================================
# Daemon Running Detection
# =============================================================================

# Default state directory
DEFAULT_STATE_DIR = Path.home() / ".hivemind"


def is_daemon_running(state_dir: Path | None = None) -> bool:
    """Check if daemon lock is held.

    Tests whether another daemon process is currently running by attempting
    to acquire the lock file non-blocking. If the lock fails with
    BlockingIOError, another process holds the lock.

    Args:
        state_dir: Optional path to state directory. Defaults to ~/.hivemind.

    Returns:
        True if daemon is running (lock held), False otherwise.
    """
    if state_dir is None:
        state_dir = DEFAULT_STATE_DIR

    lock_path = state_dir / "daemon.lock"
    if not lock_path.exists():
        return False

    try:
        with open(lock_path) as f:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)
            return False
    except BlockingIOError:
        return True


def find_daemon_pid(state_dir: Path | None = None) -> int | None:
    """Find the running daemon's PID using lock file or pgrep fallback.

    1. Reads PID from daemon.lock and validates with os.kill(pid, 0)
    2. If lock file is empty/unreadable but flock is held, falls back to
       pgrep -f "hivemind run" to recover the PID

    Args:
        state_dir: Optional path to state directory. Defaults to ~/.hivemind.

    Returns:
        The daemon PID if found and running, None otherwise.
    """
    if state_dir is None:
        state_dir = DEFAULT_STATE_DIR

    lock_path = state_dir / "daemon.lock"
    if not lock_path.exists():
        return None

    # Try reading PID from lock file
    try:
        pid_str = lock_path.read_text().strip()
        if pid_str:
            pid = int(pid_str)
            os.kill(pid, 0)  # Validate process exists
            return pid
    except (OSError, ValueError):
        pass  # Fall through to pgrep
    except ProcessLookupError:
        pass  # PID in file is stale

    # Lock file empty or PID stale — check if lock is actually held
    if not is_daemon_running(state_dir):
        return None

    # Lock is held but we couldn't read PID — try pgrep
    try:
        result = subprocess.run(
            ["pgrep", "-f", "hivemind run"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            # pgrep may return multiple PIDs; take the first one
            for line in result.stdout.strip().splitlines():
                line = line.strip()
                if line:
                    pid = int(line)
                    try:
                        os.kill(pid, 0)
                        return pid
                    except (ProcessLookupError, PermissionError):
                        continue
    except (subprocess.TimeoutExpired, FileNotFoundError, ValueError):
        pass

    return None


# =============================================================================
# State Update Helpers
# =============================================================================


def _get_adapter_for_path(file_path: Path) -> "Adapter | None":
    """Get adapter that matches a file path.

    Imports agentstream adapters lazily to avoid circular imports
    during module initialization.
    """
    from agentstream.adapters import get_adapter_for_path  # noqa: PLC0415

    return get_adapter_for_path(file_path)


# Valid agent types for clear_sessions_by_agent_type
VALID_AGENT_TYPES = frozenset(
    {"claude", "claude_web", "copilot", "cursor", "codex", "gemini", "opencode"}
)


def clear_sessions_by_agent_type(
    state: DaemonState,
    agent_type: str,
    server_url: str | None = None,
) -> int:
    """Clear all sessions for a specific agent type.

    Removes sessions from daemon state where the file_path matches the given
    agent type (determined by adapter matching).

    Args:
        state: The DaemonState to modify.
        agent_type: Agent type to clear (claude, claude_web, copilot, cursor, codex, gemini, opencode).
        server_url: Optional server endpoint to target. If None, clears from all servers.

    Returns:
        Count of sessions cleared.

    Raises:
        ValueError: If agent_type is not valid.
    """
    if agent_type not in VALID_AGENT_TYPES:
        raise ValueError(
            f"Invalid agent_type '{agent_type}'. "
            f"Valid types: {', '.join(sorted(VALID_AGENT_TYPES))}"
        )

    cleared_count = 0

    # Determine which servers to process
    if server_url is not None:
        server_key = _normalize_endpoint(server_url)
        if server_key not in state.servers:
            return 0
        servers_to_process = {server_key: state.servers[server_key]}
    else:
        servers_to_process = state.servers

    for server_state in servers_to_process.values():
        # Find session IDs to remove
        session_ids_to_remove: list[str] = []

        for session_id, session_sync_state in server_state.sessions.items():
            # Web sessions use virtual paths (web://session_...) that don't
            # match any adapter. Match them by the "web:" session ID prefix.
            if agent_type == "claude_web" and session_id.startswith("web:"):
                session_ids_to_remove.append(session_id)
                continue

            file_path = Path(session_sync_state.file_path)
            adapter = _get_adapter_for_path(file_path)

            if adapter is not None and adapter.name == agent_type:
                session_ids_to_remove.append(session_id)

        # Remove matched sessions
        for session_id in session_ids_to_remove:
            del server_state.sessions[session_id]
            cleared_count += 1

    return cleared_count


@contextmanager
def locked_state_update(state_dir: Path | None = None) -> Generator[None, None, None]:
    """Context manager for CLI to safely modify state when daemon not running.

    Acquires the daemon lock file to ensure no daemon is running while
    making state modifications. Raises an error if daemon is running.

    Args:
        state_dir: Optional path to state directory. Defaults to ~/.hivemind.

    Yields:
        None - use within a with block to perform state modifications.

    Raises:
        RuntimeError: If daemon is running (lock cannot be acquired).

    Example:
        with locked_state_update():
            state = load_state(state_file)
            # modify state...
            save_state(state, state_file)
    """
    if state_dir is None:
        state_dir = DEFAULT_STATE_DIR

    lock_path = state_dir / "daemon.lock"
    state_dir.mkdir(parents=True, exist_ok=True)

    lock_file = open(lock_path, "a")
    try:
        try:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError("Cannot modify state: daemon is running.")

        yield
    finally:
        # Release lock if held, then close file
        try:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
        except OSError:
            pass  # Lock may not have been acquired
        lock_file.close()
