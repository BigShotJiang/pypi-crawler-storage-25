"""Authentication manager for Hivemind daemon."""

from __future__ import annotations

import logging
import os
import subprocess
import sys
import time
import uuid
from typing import Any

import httpx

from hivemind.auth.credentials import CredentialStore, StoredCredentials
from hivemind.auth.jwt_utils import decode_jwt_payload

# AuthError is re-exported from device_flow so the auth package has a
# single canonical class — we used to have a separate class with the
# same name here, which meant a device_flow.AuthError raised inside
# `hivemind login` slipped past `except (AuthError, OIDCAuthError)` in
# cli.py and surfaced as a raw traceback.
from hivemind.auth.device_flow import AuthError, DeviceFlowAuth  # noqa: F401
from hivemind.auth.discovery import (
    AuthDiscovery,
    DeviceFlowAuthMethod,
    SSHAuthMethod,
    TokenAuthMethod,
)
from hivemind.auth.hardware import HardwareInfo, collect_hardware_info
from hivemind.auth.oidc import OIDCAuthError, auth_via_oidc_browser, auth_via_oidc_device
from hivemind.auth.ssh_sign import create_ssh_signature

logger = logging.getLogger(__name__)

# Buffer used when deciding whether to attempt a provider refresh. Env-aware
# OIDC providers can't truly rotate on demand — Modal id tokens are static
# for the container lifetime, k8s tokens are rotated in-place by kubelet at
# ~80% TTL, and GitHub Actions exchanges waste a round-trip if we refresh
# eagerly. Honoring force_refresh on a still-fresh token JTI-replay-fails
# for the first two and burns cycles on the third. We only attempt a refresh
# when the token is genuinely close to expiry.
_NEAR_EXPIRY_REFRESH_BUFFER_S = 300


def _get_git_email() -> str | None:
    """Get the user's email from git config."""
    try:
        result = subprocess.run(
            ["git", "config", "--global", "user.email"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except (subprocess.SubprocessError, FileNotFoundError):
        pass
    return None


class PermanentAuthError(AuthError):
    """Auth error that should not be retried (e.g., org membership restriction).

    Used when the server returns 403 indicating the user is not authorized
    to use the service at all, not just a temporary auth failure.
    """

    pass


class AuthManager:
    """Manages daemon authentication lifecycle."""

    def __init__(
        self,
        endpoint: str,
        credential_store: CredentialStore | None = None,
        config: Any = None,
    ):
        self.endpoint = endpoint.rstrip("/")
        self.store = credential_store or CredentialStore()
        self.discovery = AuthDiscovery()
        self._device_id: str | None = None
        self._hardware_info: HardwareInfo | None = None
        self._config = config
        # In-memory hints carried into _credentials_from_oidc_result.
        self.sso_org_id: str | None = None
        self.sso_required: bool = False
        # Populated by refresh_via_stored_token / _refresh_via_* when a
        # refresh attempt fails, so callers can surface the real cause
        # (HTTP status, IdP error code) instead of a generic message.
        self._last_refresh_error: str | None = None
        # Credentials supplied by an ephemeral (in-memory) provider, e.g.
        # HIVEMIND_TOKEN or GitHub Actions OIDC. Kept separate from the on-disk
        # store so env-derived credentials don't pollute the credential file.
        self._in_memory_creds: StoredCredentials | None = None
        # The provider that last resolved credentials. Used by get_token() to
        # decide whether a force_refresh should call provider.refresh() (for
        # OIDC-style providers) vs falling through to the discovery flow.
        self._active_provider: Any = None  # type: CredentialProvider | None
        # Lazily constructed (depends on `self` being fully initialized).
        self._provider_chain: list[Any] | None = None

    @property
    def device_id(self) -> str:
        """Get or create persistent device ID."""
        if self._device_id:
            return self._device_id

        device_file = self.store.config_dir / "device_id"

        if device_file.exists():
            self._device_id = device_file.read_text().strip()
        else:
            self._device_id = str(uuid.uuid4())
            self.store._ensure_config_dir()
            device_file.write_text(self._device_id)
            device_file.chmod(0o600)

        return self._device_id

    @property
    def hardware_info(self) -> HardwareInfo:
        """Get cached hardware information."""
        if self._hardware_info is None:
            self._hardware_info = collect_hardware_info()
        return self._hardware_info

    def _build_provider_chain(self) -> list[Any]:
        """Build the default ordered credential provider chain.

        Order matters: stored creds first (fast path for already-authenticated
        daemons), then environment-aware providers (static token > OIDC > dev
        mode), then the interactive discovery chain. HIVEMIND_TOKEN precedes
        OIDC so operators have an explicit break-glass override when a
        federation is misconfigured.
        """
        # Import locally to avoid a circular import with auth.providers (which
        # references AuthManager in TYPE_CHECKING).
        from hivemind.auth.providers import (  # noqa: PLC0415
            DevModeProvider,
            DiscoveryProvider,
            EnvTokenProvider,
            GitHubActionsOIDCProvider,
            KubernetesOIDCProvider,
            ModalOIDCProvider,
            StoredCredentialProvider,
        )

        # HIVEMIND_TOKEN takes precedence over OIDC providers: it's an
        # explicit, intentional override (by definition, the user set it)
        # and is useful for breaking glass when an OIDC federation is
        # misconfigured. Stored creds still win first so an interactive
        # `hivemind login` isn't silently shadowed by env-var auth.
        return [
            StoredCredentialProvider(self.store),
            EnvTokenProvider(),
            GitHubActionsOIDCProvider(),
            ModalOIDCProvider(),
            KubernetesOIDCProvider(),
            DevModeProvider(self),
            DiscoveryProvider(self),
        ]

    @property
    def provider_chain(self) -> list[Any]:
        """Lazily constructed provider chain."""
        if self._provider_chain is None:
            self._provider_chain = self._build_provider_chain()
        return self._provider_chain

    @property
    def last_resolution_errors(self) -> list[tuple[str, str]]:
        """Provider-level failures from the most recent resolve(), as (name, error) pairs.

        Callers surface these when the chain returns None so users see *why*
        federation failed rather than a generic "Not authenticated".
        """
        return [
            (p.name, str(p.last_error))
            for p in (self._provider_chain or [])
            if getattr(p, "last_error", None) is not None
        ]

    def _find_refreshable_provider(self, auth_method: str | None) -> Any:
        """Return an available, refresh-capable provider whose auth_method matches.

        Used by ``get_token(force_refresh=True)`` to re-mint env-aware OIDC
        credentials loaded from disk without falling through to interactive
        discovery.
        """
        if not auth_method:
            return None
        for provider in self.provider_chain:
            if provider.name == "stored" or not getattr(provider, "supports_refresh", False):
                continue
            if getattr(provider, "auth_method", None) != auth_method:
                continue
            try:
                if not provider.is_available():
                    continue
            except Exception as err:
                logger.debug("provider %s is_available() raised: %s", provider.name, err)
                continue
            return provider
        return None

    def get_current_credentials(self) -> StoredCredentials | None:
        """Return the currently active credentials.

        Checks in-memory credentials (supplied by ephemeral providers like
        ``HIVEMIND_TOKEN`` or GitHub Actions OIDC) before falling back to the
        on-disk credential store. This is the single source of truth used by
        the daemon to rebuild the syncer after a token refresh.
        """
        if self._in_memory_creds is not None:
            return self._in_memory_creds
        return self.store.load(self.endpoint)

    async def resolve_credentials(self, *, skip_stored: bool = False) -> StoredCredentials | None:
        """Resolve credentials by iterating the provider chain.

        Returns the first successfully resolved credentials, or ``None`` if no
        provider is both available and able to produce credentials.
        Persistent providers write to the credential store; ephemeral providers
        set ``self._in_memory_creds`` instead.

        Args:
            skip_stored: If True, bypass the ``StoredCredentialProvider`` so the
                resolver only considers fresh sources (env token, OIDC, discovery).
                Used by the age-expired pre-start path, which needs to force a
                re-auth instead of echoing back the stale on-disk creds.
        """
        for provider in self.provider_chain:
            if skip_stored and provider.name == "stored":
                continue
            try:
                if not provider.is_available():
                    continue
            except Exception as e:
                logger.debug("Provider %s is_available() raised: %s", provider.name, e)
                continue

            try:
                creds = await provider.resolve(self.endpoint, self.device_id)
            except PermanentAuthError:
                # Let permanent failures propagate — caller pauses the daemon.
                raise
            except Exception as e:
                logger.debug("Provider %s resolve() raised: %s", provider.name, e)
                continue

            if creds is None:
                continue

            self._active_provider = provider
            if provider.persists_to_disk:
                # StoredCredentialProvider already loaded from disk; DevModeProvider
                # writes via its own path. Saving again here is a no-op for
                # StoredCredentialProvider but ensures any newly minted creds
                # from DiscoveryProvider or OIDCExchangeProvider subclasses are
                # durable across subprocess invocations.
                if provider.name not in ("stored", "dev_mode"):
                    self.store.save(creds, self.endpoint)
            # Always track the active creds in memory, regardless of disk
            # persistence. The in-memory path drives same-process refresh via
            # self._active_provider.refresh() — critical for OIDC providers
            # whose refresh semantics differ from the refresh_token flow.
            self._in_memory_creds = creds
            logger.info("Credentials resolved via provider: %s", provider.name)
            return creds

        return None

    async def get_token(
        self,
        force_method: str | None = None,
        force_refresh: bool = False,
        preferred_method: str | None = None,
    ) -> str:
        """Get a valid authentication token, refreshing if needed.

        Args:
            force_method: If set, force a specific auth method instead of auto-detect.
                         Values: "ssh", "device", "credential", "gh"
            force_refresh: If True, force re-authentication even if token is still valid.
                          Used when server signals token needs refresh (secret rotation).
            preferred_method: If set, try this method first when auto-detecting.
                            Used to skip slower methods that previously failed.
        """
        # Ephemeral (in-memory) credentials from environment-aware providers
        # (HIVEMIND_TOKEN, GitHub Actions OIDC, etc.) take precedence — they
        # are never written to the store, so the disk path below would miss
        # them. Refresh is best-effort: only attempt it when the token is
        # near expiry, regardless of force_refresh.
        if self._in_memory_creds is not None:
            near_expiry = self.store.is_expired(
                self._in_memory_creds, buffer_seconds=_NEAR_EXPIRY_REFRESH_BUFFER_S
            )
            if (
                near_expiry
                and self._active_provider is not None
                and self._active_provider.supports_refresh
            ):
                refreshed = await self._active_provider.refresh(self.endpoint, self.device_id)
                if refreshed is not None:
                    self._in_memory_creds = refreshed
                    return refreshed.token
                raise AuthError(
                    f"Provider {self._active_provider.name} failed to refresh credentials"
                )
            return self._in_memory_creds.token

        # Try loading existing credentials for this endpoint (skip if forcing).
        # Use load_raw() to evaluate freshness against the BASE token's
        # expires_at — load() would apply a cached escalation token but
        # leave expires_at on the base (see _maybe_apply_escalation), which
        # is exactly what we want for refresh decisions. When the base is
        # still fresh, fetch with load() so the returned token is the
        # escalated one if present.
        if not force_method and not force_refresh:
            base = self.store.load_raw(self.endpoint)
            if base and not self.store.is_expired(base):
                escalated = self.store.load(self.endpoint)
                return (escalated or base).token
            creds = base

            if creds:
                logger.info(f"Token expired for {creds.github_user}, re-authenticating...")
                # Use previously successful method as preference for re-auth
                if not preferred_method:
                    preferred_method = creds.auth_method
                # When we hold a refresh token, try the silent refresh first.
                # ssh_signature/credential_helper/gh_cli never store one, so
                # they fall straight through to discovery as before; only
                # device_flow (GitHub) and oidc_* land here.
                # OIDC failures are fatal: discover_all() would otherwise
                # downgrade us to ssh_signature and the next sync would hit
                # 403 sso_required for SSO-enforced orgs. GitHub failures
                # fall through to discovery, which can legitimately succeed
                # via ssh/credential/gh on a non-SSO org.
                if creds.refresh_token:
                    refreshed = await self.refresh_via_stored_token()
                    if refreshed:
                        self.store.save(refreshed, self.endpoint)
                        return refreshed.token
                    if creds.auth_method and creds.auth_method.startswith("oidc_"):
                        raise AuthError(
                            "OIDC credentials expired and could not be refreshed. "
                            "Run 'hivemind login' to re-authenticate."
                        )
                    logger.info(
                        "GitHub refresh failed for %s, falling through to discovery",
                        creds.github_user,
                    )
        else:
            creds = self.store.load(self.endpoint) if force_refresh else None
            if force_refresh and creds:
                logger.info(f"Force refreshing token for {creds.github_user}...")
                if not preferred_method:
                    preferred_method = creds.auth_method
                # Same trigger as the expired-on-load branch above.
                if creds.refresh_token:
                    refreshed = await self.refresh_via_stored_token()
                    if refreshed:
                        self.store.save(refreshed, self.endpoint)
                        return refreshed.token
                    if creds.auth_method and creds.auth_method.startswith("oidc_"):
                        # TODO(#378): Remove this fallback once the server-side fix
                        # (OIDC device flow returning refresh_token) is deployed.
                        if not self.store.is_expired(creds):
                            logger.info(
                                "OIDC refresh unavailable but access token still valid, continuing"
                            )
                            return creds.token
                        raise AuthError(
                            "OIDC credentials could not be refreshed. "
                            "Run 'hivemind login' to re-authenticate."
                        )
                    logger.info(
                        "GitHub refresh failed for %s, falling through to discovery",
                        creds.github_user,
                    )
                # Env-aware OIDC creds (GH Actions/Kubernetes/Modal) carry no
                # refresh_token — they re-mint from the runtime env. Use the
                # provider directly so headless runners don't fall through to
                # interactive discovery, but only when the token is actually
                # near expiry (these providers can't truly rotate on demand).
                provider = self._find_refreshable_provider(creds.auth_method)
                if provider is not None:
                    if not self.store.is_expired(
                        creds, buffer_seconds=_NEAR_EXPIRY_REFRESH_BUFFER_S
                    ):
                        return creds.token
                    refreshed = await provider.refresh(self.endpoint, self.device_id)
                    if refreshed is not None:
                        self._active_provider = provider
                        self._in_memory_creds = refreshed
                        return refreshed.token
                    raise AuthError(f"Provider {provider.name} failed to refresh credentials")

        new_creds = await self._authenticate(force_method, preferred_method=preferred_method)
        self.store.save(new_creds, self.endpoint)

        return new_creds.token

    async def _authenticate(
        self, force_method: str | None = None, preferred_method: str | None = None
    ) -> StoredCredentials:
        """Perform authentication using discovered or forced method.

        Args:
            force_method: If set, use this specific method instead of auto-detect.
                         Values: "ssh", "device", "credential", "gh"
            preferred_method: If set, try this method first when auto-detecting.
        """
        if force_method:
            return await self._authenticate_forced(force_method)

        auth_methods = self.discovery.discover_all(preferred=preferred_method)
        last_error: AuthError | None = None

        for auth_method in auth_methods:
            try:
                if isinstance(auth_method, SSHAuthMethod):
                    return await self._auth_via_ssh(auth_method)
                elif isinstance(auth_method, TokenAuthMethod):
                    return await self._auth_via_token_exchange(auth_method)
                elif isinstance(auth_method, DeviceFlowAuthMethod):
                    return await self._auth_via_device_flow()
            except PermanentAuthError:
                raise
            except AuthError as e:
                logger.info(f"Auth method failed, trying next: {e}")
                last_error = e
                continue

        if last_error:
            raise last_error
        raise AuthError("No authentication method available")

    async def _authenticate_forced(self, method: str) -> StoredCredentials:
        """Authenticate using a specific forced method."""
        if method == "ssh":
            ssh_method = self._try_ssh_method()
            if not ssh_method:
                raise AuthError("SSH authentication not available (no SSH key or GitHub user)")
            return await self._auth_via_ssh(ssh_method)

        elif method == "device":
            return await self._auth_via_device_flow()

        elif method == "credential":
            token_method = self._try_credential_method()
            if not token_method:
                raise AuthError("Git credential helper not available or no stored credentials")
            return await self._auth_via_token_exchange(token_method)

        elif method == "gh":
            token_method = self._try_gh_method()
            if not token_method:
                raise AuthError("GitHub CLI (gh) not available or not authenticated")
            return await self._auth_via_token_exchange(token_method)

        elif method == "oidc_browser":
            return await self._auth_via_oidc_sso()

        elif method == "oidc_device":
            return await self._auth_via_oidc_device()

        elif method == "oidc_refresh":
            result = await self.refresh_via_stored_token()
            if result:
                return result
            # Caller adds its own prefix; keep the detail unprefixed.
            detail = self._last_refresh_error or "unknown reason"
            raise AuthError(detail)

        else:
            raise AuthError(f"Unknown authentication method: {method}")

    def _try_ssh_method(self) -> SSHAuthMethod | None:
        """Try to get SSH auth method."""
        if ssh_key := self.discovery._find_ssh_key():
            if github_user := self.discovery._get_username_via_ssh():
                return SSHAuthMethod(key_path=ssh_key, github_user=github_user)
        return None

    def _try_credential_method(self) -> TokenAuthMethod | None:
        """Try to get git credential helper method."""
        if cred := self.discovery._get_git_credential():
            if github_user := self.discovery._get_username_via_api(cred.password):
                return TokenAuthMethod(
                    token=cred.password, github_user=github_user, source="credential_helper"
                )
        return None

    def _try_gh_method(self) -> TokenAuthMethod | None:
        """Try to get gh CLI method."""
        if gh_token := self.discovery._get_gh_token():
            if github_user := self.discovery._get_username_via_api(gh_token):
                return TokenAuthMethod(token=gh_token, github_user=github_user, source="gh_cli")
        return None

    def _get_github_token_locally(self) -> str | None:
        """Try to get a GitHub token from local sources.

        Probes gh CLI and git credential helper for a token. The token is
        included in the signed SSH payload so the server can query the GitHub
        API for org memberships server-side. This is more secure than sending
        pre-fetched org lists, which a manipulated client could spoof.

        Returns:
            GitHub token string, or None if no token available.
        """
        token = self.discovery._get_gh_token()
        if not token:
            cred = self.discovery._get_git_credential()
            if cred:
                token = cred.password

        if token:
            logger.debug("Found local GitHub token for SSH auth enrichment")

        return token

    async def _auth_via_ssh(self, method: SSHAuthMethod) -> StoredCredentials:
        """Authenticate using SSH signature."""
        git_email = _get_git_email()
        hw = self.hardware_info

        # Include a GitHub token in the signed payload (if available) so the
        # server can query the GitHub API for org memberships directly. This
        # replaces the previous approach of sending pre-fetched org lists,
        # which was vulnerable to spoofing by a manipulated client.
        github_token = self._get_github_token_locally()

        sig_data = create_ssh_signature(
            key_path=method.key_path,
            github_user=method.github_user,
            device_id=self.device_id,
            git_email=git_email,
            github_token=github_token,
        )

        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.endpoint}/v1/auth/ssh",
                json={
                    "github_user": method.github_user,
                    "payload": sig_data["payload"],
                    "signature": sig_data["signature"],
                    "git_email": git_email,
                    **hw.to_dict(),
                },
                timeout=30,
            )

        if response.status_code == 403:
            # Permanent auth failure - user not authorized (e.g., org restriction)
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            raise PermanentAuthError(f"Access denied: {detail}")

        if response.status_code != 200:
            raise AuthError(f"SSH auth failed: {response.text}")

        data = response.json()

        now = int(time.time())
        return StoredCredentials(
            token=data["token"],
            user_id=data["user_id"],
            github_user=data["github_user"],
            email=data["email"],
            expires_at=data["expires_at"],
            auth_method="ssh_signature",
            device_id=self.device_id,
            created_at=now,
            updated_at=now,
        )

    async def _auth_via_token_exchange(
        self,
        method: TokenAuthMethod,
        preserve_created_at: int | None = None,
    ) -> StoredCredentials:
        """Authenticate by exchanging GitHub token."""
        git_email = _get_git_email()
        hw = self.hardware_info

        exchange_body = {
            "github_token": method.token,
            "auth_method": method.source,
            "device_id": self.device_id,
            "git_email": git_email,
            **hw.to_dict(),
        }
        # Forward the GitHub refresh token to the server if we got one from
        # device flow. The server doesn't persist it — the daemon remains
        # authoritative for refresh storage — but forwarding lets the server
        # normalize `refresh_token_expires_in` into an absolute expiry in the
        # response, so every caller gets `refresh_token_expires_at` without
        # re-implementing the time math on the client.
        if method.refresh_token:
            exchange_body["github_refresh_token"] = method.refresh_token
            if method.refresh_token_expires_in:
                exchange_body["github_refresh_token_expires_in"] = method.refresh_token_expires_in

        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.endpoint}/v1/auth/exchange",
                json=exchange_body,
                timeout=30,
            )

        if response.status_code == 403:
            # Permanent auth failure - user not authorized (e.g., org restriction)
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            raise PermanentAuthError(f"Access denied: {detail}")

        if response.status_code != 200:
            raise AuthError(f"Token exchange failed: {response.text}")

        data = response.json()

        now = int(time.time())

        # Determine refresh token: prefer what the method provides (e.g., GitHub device flow)
        refresh_fields: dict = {}
        if method.refresh_token:
            refresh_fields["refresh_token"] = method.refresh_token
            refresh_fields["refresh_token_type"] = "github"
            if method.refresh_token_expires_in:
                refresh_fields["refresh_token_expires_at"] = now + method.refresh_token_expires_in

        # Server may also echo a refresh_token (e.g. when it orchestrated the
        # OAuth handshake itself). When present, prefer the server value — it
        # is authoritative for rotation and carries the matching expiry.
        if data.get("refresh_token"):
            refresh_fields["refresh_token"] = data["refresh_token"]
            refresh_fields["refresh_token_type"] = data.get("refresh_token_type", "github")
            if data.get("refresh_token_expires_at"):
                refresh_fields["refresh_token_expires_at"] = data["refresh_token_expires_at"]

        return StoredCredentials(
            token=data["token"],
            user_id=data["user_id"],
            github_user=data["github_user"],
            email=data["email"],
            expires_at=data["expires_at"],
            auth_method=method.source,
            device_id=self.device_id,
            created_at=preserve_created_at if preserve_created_at is not None else now,
            updated_at=now,
            **refresh_fields,
        )

    async def _auth_via_device_flow(self) -> StoredCredentials:
        """Authenticate using OAuth device flow."""
        device_flow = DeviceFlowAuth()
        method = await device_flow.authenticate()

        return await self._auth_via_token_exchange(method)

    async def _auth_via_oidc_sso(self) -> StoredCredentials:
        """Authenticate via SSO with smart flow selection.

        Picks the best OIDC flow based on the environment:
        - No TTY: fail immediately (can't do interactive auth)
        - SSH session: use device flow (browser won't open on remote machine)
        - Local TTY: try browser flow, fall back to device flow on timeout
        """
        if not sys.stdin.isatty():
            raise AuthError(
                "SSO authentication requires an interactive terminal. "
                "Run 'hivemind login' from a terminal."
            )

        # SSH session: browser won't work, go straight to device flow
        if os.environ.get("SSH_CLIENT") or os.environ.get("SSH_TTY"):
            logger.info("SSH session detected, using OIDC device flow")
            return await self._auth_via_oidc_device()

        # Local TTY: try browser, fall back to device on failure
        try:
            return await self._auth_via_oidc_browser()
        except OIDCAuthError as e:
            logger.info(f"Browser OIDC flow failed ({e}), falling back to device flow")
            return await self._auth_via_oidc_device()

    async def _auth_via_oidc_browser(self, acr_values: str = "") -> StoredCredentials:
        """Authenticate via OIDC browser PKCE flow.

        Opens the system browser to the OIDC login page. FastPass handles
        authentication silently on Macs with Okta Verify. The token is
        delivered back to a local loopback server.

        Args:
            acr_values: Optional ACR value (e.g. "phrh" for biometric).
        """
        org_id = self._get_sso_org_id()
        result = await auth_via_oidc_browser(
            endpoint=self.endpoint,
            org_id=org_id,
            acr_values=acr_values,
        )
        return self._credentials_from_oidc_result(result, "oidc_browser")

    async def auth_via_oidc_escalation(self) -> dict:
        """Run a phrh OIDC step-up flow to obtain an escalation token.

        Reuses the same loopback/browser machinery as regular OIDC login but
        requests ``purpose=escalation`` and parses the escalation-shaped
        form_post response. Returns a dict with ``escalation_token``,
        ``user_id``, ``expires_at``. The caller persists it via
        ``CredentialStore.save_escalation``.
        """
        org_id = self._get_sso_org_id()
        return await auth_via_oidc_browser(
            endpoint=self.endpoint,
            org_id=org_id,
            acr_values="phrh",
            purpose="escalation",
        )

    async def _auth_via_oidc_device(self) -> StoredCredentials:
        """Authenticate via OIDC Device Authorization Grant.

        The flow's panel + spinner come from ``hivemind.auth.device_ui``
        (shared with the GitHub device flow), so no rendering happens here.
        """
        org_id = self._get_sso_org_id()
        result = await auth_via_oidc_device(endpoint=self.endpoint, org_id=org_id)
        return self._credentials_from_oidc_result(result, "oidc_device")

    async def refresh_via_stored_token(self) -> StoredCredentials | None:
        """Attempt to refresh credentials using a stored refresh token.

        Both refresh paths POST to a server endpoint that brokers the IdP /
        GitHub token exchange — the daemon never sees the IdP's token
        endpoint URL or the GitHub App's client_secret. Supported types:
        - "okta":   POST /v1/auth/oidc/refresh    (server brokers Okta exchange)
        - "github": POST /v1/auth/github/refresh  (server brokers GitHub App exchange)

        Returns new StoredCredentials on success, None on failure (caller may
        then prompt for interactive login, or fall through to discovery for
        non-SSO sessions — see ``get_token``).
        """
        self._last_refresh_error = None
        creds = self.store.load(self.endpoint)
        if not creds:
            self._last_refresh_error = "No stored credentials for this endpoint"
            return None
        if not creds.refresh_token:
            self._last_refresh_error = "Stored credentials have no refresh_token"
            return None
        if not creds.refresh_token_type:
            self._last_refresh_error = "Stored credentials have no refresh_token_type"
            return None

        # Check if refresh token itself has expired
        if creds.refresh_token_expires_at and time.time() >= creds.refresh_token_expires_at:
            self._last_refresh_error = "Refresh token has expired"
            logger.info("Refresh token expired, cannot use for silent refresh")
            return None

        try:
            if creds.refresh_token_type == "okta":
                return await self._refresh_via_server(creds)
            elif creds.refresh_token_type == "github":
                return await self._refresh_via_github(creds)
            else:
                self._last_refresh_error = (
                    f"Unknown refresh_token_type: {creds.refresh_token_type!r}"
                )
                logger.warning(self._last_refresh_error)
                return None
        except Exception as e:
            self._last_refresh_error = f"{type(e).__name__}: {e}"
            logger.info("Refresh token exchange failed: %s", e)
            return None

    async def _refresh_via_server(self, creds: StoredCredentials) -> StoredCredentials | None:
        """Refresh by posting the stored refresh token to /v1/auth/oidc/refresh.

        The server brokers the IdP exchange so the daemon never sees
        client_secret or the IdP's token endpoint URL.
        """
        assert creds.refresh_token is not None  # Guaranteed by caller
        org_id = self._get_sso_org_id()

        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.endpoint}/v1/auth/oidc/refresh",
                json={
                    "refresh_token": creds.refresh_token,
                    "org_id": org_id,
                    "auth_method": creds.auth_method,
                    "device_id": self.device_id,
                },
                timeout=15,
            )

        body = (resp.text or "(empty body)")[:300]
        if resp.status_code == 401:
            # IdP says the refresh token is dead — caller should pause and
            # prompt for an interactive login rather than keep retrying.
            self._last_refresh_error = f"Refresh token rejected by IdP (401): {body}"
            logger.info(
                "Refresh token rejected by IdP for %s; re-login required: %s",
                creds.github_user,
                resp.text,
            )
            return None

        if resp.status_code != 200:
            # Treat anything else (502, network blip) as transient.
            self._last_refresh_error = (
                f"Server-side OIDC refresh failed: HTTP {resp.status_code} {body}"
            )
            logger.info(self._last_refresh_error)
            return None

        new_creds = self._credentials_from_oidc_result(
            resp.json(),
            creds.auth_method,
            preserve_created_at=creds.created_at,
            existing_creds=creds,
            existing_sso_org_id=creds.sso_org_id,
        )
        self.store.save(new_creds, self.endpoint)
        logger.info("Token refreshed via server for %s", creds.github_user)
        return new_creds

    async def _refresh_via_github(self, creds: StoredCredentials) -> StoredCredentials | None:
        """Refresh by posting the stored GitHub refresh token to /v1/auth/github/refresh.

        The server brokers the GitHub App token exchange (which requires the
        App's ``client_secret`` — kept server-side — and is therefore not
        runnable from the daemon directly), then runs the same user-resolution
        pipeline as ``/v1/auth/exchange`` to issue a new AgentStream JWT in a
        single round trip.
        """
        git_email = _get_git_email()
        hw = self.hardware_info

        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.endpoint}/v1/auth/github/refresh",
                json={
                    "refresh_token": creds.refresh_token,
                    "auth_method": creds.auth_method,
                    "device_id": self.device_id,
                    "git_email": git_email,
                    **hw.to_dict(),
                },
                timeout=30,
            )

        body = (resp.text or "(empty body)")[:300]
        if resp.status_code == 401:
            # GitHub says the refresh token is dead — caller should pause and
            # prompt for an interactive login rather than keep retrying.
            self._last_refresh_error = f"GitHub refresh token rejected (401): {body}"
            logger.info(
                "GitHub refresh token rejected for %s; re-login required: %s",
                creds.github_user,
                resp.text,
            )
            return None

        if resp.status_code != 200:
            # 502 (transient), 503 (unconfigured), 500 (bug) — daemon retries
            # next cycle (or falls through to discovery for non-SSO sessions).
            self._last_refresh_error = (
                f"Server-side GitHub refresh failed: HTTP {resp.status_code} {body}"
            )
            logger.info(self._last_refresh_error)
            return None

        new_creds = self._credentials_from_oidc_result(
            resp.json(),
            creds.auth_method,
            preserve_created_at=creds.created_at,
            existing_creds=creds,
            existing_sso_org_id=creds.sso_org_id,
        )
        self.store.save(new_creds, self.endpoint)
        logger.info("Token refreshed via GitHub refresh token for %s", creds.github_user)
        return new_creds

    def mark_sso_required(self, org_id: str | None = None) -> None:
        """Mark this endpoint as SSO-enforced. Updates in-memory + disk state."""
        if org_id:
            self.sso_org_id = org_id
        self.sso_required = True
        self.store.save_sso_state(
            self.endpoint,
            org_id=org_id or self.sso_org_id,
            sso_required=True,
        )

    def _get_sso_org_id(self) -> str:
        """Get the SSO org ID from override, environment, stored creds, or JWT.

        Priority:
        1. sso_org_id attribute (set by daemon when server signals SSO required)
        2. HIVEMIND_ORG_ID environment variable (set by MDM or admin)
        3. Stored credentials for this endpoint (persisted per-endpoint from a
           previous sso_required signal)
        4. Existing JWT from a previous session
        """
        # Check override first (set by daemon run loop from 403 response)
        if self.sso_org_id:
            return self.sso_org_id

        # Check environment variable (MDM-provisioned devices)
        env_org_id = os.environ.get("HIVEMIND_ORG_ID", "")
        if env_org_id:
            return env_org_id

        # Check stored credentials (persisted per-endpoint from a previous
        # sso_required signal)
        existing = self.store.load(self.endpoint)
        if existing and existing.sso_org_id:
            return existing.sso_org_id

        # Check if we have it from the JWT of a previous session
        if existing:
            try:
                org_id = decode_jwt_payload(existing.token).get("org_id", "")
                if org_id:
                    return org_id
            except Exception:
                pass

        raise AuthError(
            "OIDC SSO requires an organization ID. "
            "Set HIVEMIND_ORG_ID environment variable or authenticate with "
            "another method first to establish your organization."
        )

    def _credentials_from_oidc_result(
        self,
        result: dict,
        auth_method: str,
        *,
        preserve_created_at: int | None = None,
        existing_creds: StoredCredentials | None = None,
        existing_sso_org_id: str | None = None,
    ) -> StoredCredentials:
        """Build StoredCredentials from an OIDC auth result dict.

        ``preserve_created_at`` keeps the original interactive-login
        timestamp on refresh. ``existing_creds`` carries forward the prior
        refresh token (and its expiry) when the IdP didn't rotate — the
        server omits ``refresh_token`` from the response and we'd otherwise
        lose ours mid-refresh.
        """
        now = int(time.time())
        refresh_fields = self._extract_refresh_fields(result)
        if (
            "refresh_token" not in refresh_fields
            and existing_creds
            and existing_creds.refresh_token
        ):
            refresh_fields["refresh_token"] = existing_creds.refresh_token
            if existing_creds.refresh_token_type:
                refresh_fields["refresh_token_type"] = existing_creds.refresh_token_type
            if existing_creds.refresh_token_expires_at:
                refresh_fields["refresh_token_expires_at"] = existing_creds.refresh_token_expires_at

        # Carry forward SSO state: in-memory hint > caller-supplied > disk.
        # A locked keychain shouldn't block a fresh login — fall back to
        # defaults and let the next discovery refill.
        sso_org_id = self.sso_org_id or existing_sso_org_id
        sso_required = self.sso_required
        if not sso_org_id or not sso_required:
            try:
                existing = self.store.load_raw(self.endpoint)
            except Exception:
                logger.debug("Could not load creds for SSO carry-forward", exc_info=True)
                existing = None
            if existing:
                if not sso_org_id:
                    sso_org_id = existing.sso_org_id
                if not sso_required:
                    sso_required = existing.sso_required

        return StoredCredentials(
            token=result["token"],
            user_id=result["user_id"],
            github_user=result["github_user"],
            email=result["email"],
            expires_at=result["expires_at"],
            auth_method=auth_method,
            device_id=self.device_id,
            created_at=preserve_created_at if preserve_created_at is not None else now,
            updated_at=now,
            sso_org_id=sso_org_id,
            sso_required=sso_required,
            **refresh_fields,
        )

    @staticmethod
    def _extract_refresh_fields(result: dict) -> dict:
        """Extract refresh token fields from an auth result dict."""
        fields: dict = {}
        if result.get("refresh_token"):
            fields["refresh_token"] = result["refresh_token"]
        if result.get("refresh_token_type"):
            fields["refresh_token_type"] = result["refresh_token_type"]
        if result.get("refresh_token_expires_at"):
            fields["refresh_token_expires_at"] = result["refresh_token_expires_at"]
        return fields

    def get_auth_header(self, token: str) -> dict[str, str]:
        """Get Authorization header for requests."""
        return {"Authorization": f"Bearer {token}"}

    async def whoami(self) -> dict | None:
        """Return current authenticated user info for this endpoint.

        Checks ephemeral (in-memory) credentials first, then falls back to
        the credential store on disk.
        """
        creds = self._in_memory_creds or self.store.load(self.endpoint)
        if not creds:
            return None

        return {
            "user_id": creds.user_id,
            "github_user": creds.github_user,
            "email": creds.email,
            "auth_method": creds.auth_method,
            "expires_at": creds.expires_at,
            "expired": self.store.is_expired(creds, buffer_seconds=0),
            "endpoint": self.endpoint,
        }

    def logout(self) -> None:
        """Clear stored credentials for this endpoint."""
        self.store.clear(self.endpoint)
        logger.info(f"Logged out from {self.endpoint}, credentials cleared")
