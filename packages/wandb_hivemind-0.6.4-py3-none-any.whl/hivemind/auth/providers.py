"""Credential providers for the daemon auth system.

A ``CredentialProvider`` is a pluggable source of credentials. The
:class:`AuthManager` iterates a chain of providers at startup; the first
provider that reports ``is_available()`` and successfully ``resolve()`` wins.

Providers come in two flavors:

* **Persistent** (``persists_to_disk=True``) — credentials are written to the
  credential store via ``CredentialStore.save()``. The normal interactive
  auth flows (SSH signature, git credential helper, gh CLI, OIDC browser/
  device flow) fall into this bucket.

* **Ephemeral** (``persists_to_disk=False``) — credentials live in memory
  only for the lifetime of the daemon process. Used for environment-derived
  credentials (``HIVEMIND_TOKEN``, GitHub Actions OIDC) where writing fake
  user info to disk would pollute the credential store.

Ephemeral credentials can optionally support refresh (``supports_refresh``).
For GitHub Actions OIDC this means re-fetching the id token from the runner
and re-exchanging it with the backend. For ``HIVEMIND_TOKEN`` refresh is a
no-op because the token is static.
"""

from __future__ import annotations

import hashlib
import logging
import os
import shutil
import time
from typing import TYPE_CHECKING, Protocol, runtime_checkable

import httpx

from hivemind.auth.credentials import CredentialStore, StoredCredentials
from hivemind.auth.jwt_utils import decode_jwt_payload

if TYPE_CHECKING:
    from hivemind.auth.manager import AuthManager

logger = logging.getLogger(__name__)


# Fallback audience used when the server endpoint cannot be derived (e.g. the
# daemon has no configured endpoint yet). We prefer the configured server URL
# so tokens are scoped to the specific Hivemind deployment; see
# :func:`_audience_for_endpoint` below.
DEFAULT_OIDC_AUDIENCE = "https://hivemind.wandb.tools"

#: Env vars that select / configure providers in the chain. Test fixtures
#: strip these so each test starts from a known state. Keep in sync with
#: any new provider that reads from the environment.
PROVIDER_ENV_VARS: tuple[str, ...] = (
    "HIVEMIND_TOKEN",
    "HIVEMIND_DEV_MODE",
    "ACTIONS_ID_TOKEN_REQUEST_URL",
    "ACTIONS_ID_TOKEN_REQUEST_TOKEN",
    "MODAL_IDENTITY_TOKEN",
    "HIVEMIND_K8S_TOKEN_FILE",
)


def _audience_for_endpoint(endpoint: str) -> str:
    """Canonical OIDC audience for a Hivemind server URL.

    We use the endpoint (with trailing slash stripped) as the audience so each
    Hivemind deployment has a distinct audience. Tokens minted for one server
    can't be replayed against another. Keep this aligned with
    ``DEFAULT_AUDIENCE`` in ``backend/api/src/agentstream_api/oidc_providers.py``.
    """
    stripped = (endpoint or "").rstrip("/")
    return stripped or DEFAULT_OIDC_AUDIENCE


@runtime_checkable
class CredentialProvider(Protocol):
    """Pluggable source of credentials.

    Each provider is checked in order by :class:`AuthManager.resolve_credentials`.
    """

    #: Short name for logging (e.g. ``"github_actions_oidc"``).
    name: str

    #: If True, resolved credentials are persisted via ``CredentialStore.save()``.
    #: If False, they live in memory only on the manager.
    persists_to_disk: bool

    #: If True, the provider can refresh credentials without interactive input
    #: (e.g. re-fetch an OIDC id token). Used by the 401 retry path.
    supports_refresh: bool

    def is_available(self) -> bool:
        """Return True if this provider can be used in the current environment."""

    async def resolve(self, endpoint: str, device_id: str) -> StoredCredentials | None:
        """Resolve credentials. Return None to fall through to the next provider."""

    async def refresh(self, endpoint: str, device_id: str) -> StoredCredentials | None:
        """Refresh credentials. Default implementation calls resolve()."""


class StoredCredentialProvider:
    """Return existing credentials from the credential store if still fresh."""

    name = "stored"
    persists_to_disk = True
    supports_refresh = False

    def __init__(self, store: CredentialStore) -> None:
        self._store = store

    def is_available(self) -> bool:
        return True

    async def resolve(self, endpoint: str, device_id: str) -> StoredCredentials | None:
        creds = self._store.load(endpoint)
        if creds and not self._store.is_expired(creds):
            return creds
        return None

    async def refresh(self, endpoint: str, device_id: str) -> StoredCredentials | None:
        # Refresh of stored credentials is handled by AuthManager.refresh_via_stored_token
        # and the existing discovery flow. This provider intentionally does not duplicate it.
        return None


class EnvTokenProvider:
    """Use ``HIVEMIND_TOKEN`` as a bearer token directly.

    The token is used as-is — no server validation, no disk write. It may be
    a service account token (``sa_*``) or a pre-minted JWT. Invalid tokens
    will be rejected by the server on the first API call, and the daemon's
    existing 401 handling will surface the error.
    """

    name = "env_token"
    persists_to_disk = False
    supports_refresh = False

    ENV_VAR = "HIVEMIND_TOKEN"

    def is_available(self) -> bool:
        return bool(os.environ.get(self.ENV_VAR))

    async def resolve(self, endpoint: str, device_id: str) -> StoredCredentials | None:
        token = os.environ.get(self.ENV_VAR)
        if not token:
            return None
        now = int(time.time())
        logger.info("Using credentials from %s env var", self.ENV_VAR)
        return StoredCredentials(
            token=token,
            user_id="env-token",
            github_user="env-token",
            email="",
            # Long-lived: we don't know the real expiry. Server-side rejection
            # on 401 is the source of truth; the uploader's 401 path
            # (uploader.py) drives the reactive refresh.
            expires_at=now + 365 * 86400,
            auth_method="env_token",
            device_id=device_id,
            created_at=now,
            updated_at=now,
        )

    async def refresh(self, endpoint: str, device_id: str) -> StoredCredentials | None:
        # Static token — nothing to refresh. Return the same creds so the
        # caller can still rebuild its syncer without hitting None.
        return await self.resolve(endpoint, device_id)


class OIDCExchangeProvider:
    """Base class for providers that exchange an OIDC id token for an AgentStream JWT.

    Subclasses implement :meth:`_get_id_token` to supply a fresh id token
    (either from an HTTP endpoint on the runner, an environment variable,
    or a file). The base class handles the ``POST /v1/auth/actions/exchange``
    call, constructs the resulting :class:`StoredCredentials`, and implements
    :meth:`refresh` as a full re-exchange.

    **JTI replay protection.** The backend rejects any id token whose ``jti``
    has already been exchanged. This base class tracks used jti fingerprints
    so refresh short-circuits on identity platforms that don't rotate (notably
    Modal, whose ``MODAL_IDENTITY_TOKEN`` is static for the container lifetime).
    """

    name: str = "oidc_exchange"
    auth_method: str = "oidc_exchange"
    #: Fallback ``user_id`` / ``github_user`` when the backend does not
    #: return a ``service_account_id`` / ``repository`` for this token.
    default_identity: str = "oidc"

    # Persisting the exchanged JWT lets subprocess invocations (whoami, status)
    # see the authenticated state without re-running the exchange.
    persists_to_disk = True
    supports_refresh = True

    def __init__(self) -> None:
        self._used_token_fingerprints: set[str] = set()
        # Cleared at the start of each resolve() so the previous failure
        # doesn't persist into a successful attempt.
        self.last_error: Exception | None = None

    def is_available(self) -> bool:  # pragma: no cover - abstract
        raise NotImplementedError

    async def _get_id_token(self, endpoint: str) -> str | None:
        """Return a fresh OIDC id token, or ``None`` if unavailable.

        Subclasses implement this to read from an environment variable, an
        HTTP endpoint, a file, etc. The ``endpoint`` is the configured
        AgentStream server URL — providers that actively request an audience
        from their identity platform (e.g. GitHub Actions) should derive it
        from the endpoint so tokens are scoped to this specific deployment.
        Returning ``None`` signals that the provider cannot produce a token
        right now (the chain will fall through to the next provider).
        """
        raise NotImplementedError

    @staticmethod
    def _extract_jti(id_token: str) -> str | None:
        try:
            jti = decode_jwt_payload(id_token).get("jti")
        except Exception:
            return None
        return str(jti) if jti else None

    def _token_fingerprint(self, id_token: str) -> str:
        """Stable, bounded-length identifier for an id token.

        Prefers the ``jti`` claim when present (short, intended for exactly
        this purpose). Falls back to a SHA-256 hash of the full token so we
        never retain raw credentials in memory.
        """
        jti = self._extract_jti(id_token)
        if jti:
            return f"jti:{jti}"
        return f"hash:{hashlib.sha256(id_token.encode()).hexdigest()}"

    async def resolve(self, endpoint: str, device_id: str) -> StoredCredentials | None:
        # Reset on every attempt so a successful resolve clears any earlier
        # failure recorded for this provider instance.
        self.last_error = None
        try:
            id_token = await self._get_id_token(endpoint)
        except Exception as e:
            self.last_error = e
            logger.warning("%s: failed to fetch id token: %s", self.name, e)
            return None
        if not id_token:
            return None

        fingerprint = self._token_fingerprint(id_token)
        if fingerprint in self._used_token_fingerprints:
            # Same id token we've already exchanged. The backend rejects
            # replays by JTI, so re-posting would fail — don't bother.
            # The caller (AuthManager.get_token) will raise AuthError and
            # pause the daemon.
            self.last_error = RuntimeError(
                "id token has already been exchanged (identity platform did not rotate jti)"
            )
            logger.info(
                "%s: id token has already been exchanged (no rotation); skipping replay",
                self.name,
            )
            return None

        try:
            exchange = await self._exchange_id_token(endpoint, id_token)
        except Exception as e:
            self.last_error = e
            logger.warning("%s: exchange failed: %s", self.name, e)
            return None

        self._used_token_fingerprints.add(fingerprint)

        now = int(time.time())
        sa_id = exchange.get("service_account_id") or self.default_identity
        repo = exchange.get("repository") or self.default_identity
        logger.info(
            "%s: authenticated as service account %s for %s",
            self.name,
            sa_id,
            repo,
        )
        return StoredCredentials(
            token=exchange["token"],
            user_id=sa_id,
            github_user=repo,
            email="",
            expires_at=int(exchange["expires_at"]),
            auth_method=self.auth_method,
            device_id=device_id,
            created_at=now,
            updated_at=now,
        )

    async def refresh(self, endpoint: str, device_id: str) -> StoredCredentials | None:
        # Rotation path: re-read the id token source and exchange again. The
        # JTI guard in resolve() short-circuits if the identity platform has
        # not rotated the token since our last exchange.
        return await self.resolve(endpoint, device_id)

    async def _exchange_id_token(self, endpoint: str, id_token: str) -> dict:
        """Exchange an OIDC id token for an AgentStream JWT."""
        url = f"{endpoint.rstrip('/')}/v1/auth/actions/exchange"
        async with httpx.AsyncClient() as client:
            resp = await client.post(url, json={"id_token": id_token}, timeout=10.0)
            if resp.status_code != 200:
                raise RuntimeError(f"exchange returned {resp.status_code}: {resp.text[:200]}")
            return resp.json()


class GitHubActionsOIDCProvider(OIDCExchangeProvider):
    """Exchange a GitHub Actions OIDC id token for an AgentStream JWT.

    Activates automatically when the workflow has been granted ``id-token: write``
    and the runner exposes ``ACTIONS_ID_TOKEN_REQUEST_URL`` /
    ``ACTIONS_ID_TOKEN_REQUEST_TOKEN``. Fetches the id token from the runner
    and delegates to :class:`OIDCExchangeProvider` for the backend exchange.
    """

    name = "github_actions_oidc"
    auth_method = "github_actions_oidc"
    default_identity = "gh-actions"

    ENV_URL = "ACTIONS_ID_TOKEN_REQUEST_URL"
    ENV_TOKEN = "ACTIONS_ID_TOKEN_REQUEST_TOKEN"

    def is_available(self) -> bool:
        return bool(os.environ.get(self.ENV_URL)) and bool(os.environ.get(self.ENV_TOKEN))

    async def _get_id_token(self, endpoint: str) -> str | None:
        request_url = os.environ.get(self.ENV_URL)
        request_token = os.environ.get(self.ENV_TOKEN)
        if not (request_url and request_token):
            return None
        audience = _audience_for_endpoint(endpoint)
        return await self._fetch_id_token(request_url, request_token, audience)

    async def _fetch_id_token(self, request_url: str, request_token: str, audience: str) -> str:
        """Fetch an OIDC id token from the GitHub Actions runner.

        The ``audience`` is scoped to the configured Hivemind endpoint so
        tokens can't be replayed against other servers.

        Docs: https://docs.github.com/en/actions/deployment/security-hardening-your-deployments/about-security-hardening-with-openid-connect
        """
        sep = "&" if "?" in request_url else "?"
        url = f"{request_url}{sep}audience={audience}"
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                url,
                headers={"Authorization": f"Bearer {request_token}"},
                timeout=10.0,
            )
            resp.raise_for_status()
            value = resp.json().get("value")
            if not isinstance(value, str) or not value:
                raise RuntimeError("OIDC endpoint returned empty 'value' field")
            return value


class KubernetesOIDCProvider(OIDCExchangeProvider):
    """Exchange a Kubernetes projected service account token for an AgentStream JWT.

    In Kubernetes, pods can opt into OIDC federation by mounting a projected
    service account token with a specific audience. The token is written to a
    file by kubelet, rotated in-place before expiry (typically at 80% of TTL),
    and must match the audience configured on the AgentStream service account.

    Example pod spec::

        spec:
          volumes:
          - name: hivemind-token
            projected:
              sources:
              - serviceAccountToken:
                  path: hivemind-token
                  audience: https://hivemind.wandb.tools
                  expirationSeconds: 3600
          containers:
          - name: hivemind
            volumeMounts:
            - name: hivemind-token
              mountPath: /var/run/secrets/hivemind
              readOnly: true

    The token path defaults to ``/var/run/secrets/hivemind/token`` and can be
    overridden via the ``HIVEMIND_K8S_TOKEN_FILE`` env var. We intentionally
    do NOT fall back to ``/var/run/secrets/kubernetes.io/serviceaccount/token``
    — that token has the Kubernetes API as its audience and would fail the
    AgentStream exchange.
    """

    name = "kubernetes_oidc"
    auth_method = "kubernetes_oidc"
    default_identity = "kubernetes"

    ENV_VAR = "HIVEMIND_K8S_TOKEN_FILE"
    DEFAULT_PATH = "/var/run/secrets/hivemind/token"

    def _token_path(self) -> str:
        return os.environ.get(self.ENV_VAR) or self.DEFAULT_PATH

    def is_available(self) -> bool:
        import os.path  # noqa: PLC0415

        return os.path.isfile(self._token_path())

    async def _get_id_token(self, endpoint: str) -> str | None:
        # The audience is baked into the projected token by kubelet at mount
        # time — it must be configured in the pod spec to match the server's
        # expected audience (see the example in the class docstring).
        path = self._token_path()
        try:
            with open(path) as f:
                token = f.read().strip()
        except OSError as e:
            logger.debug("Kubernetes OIDC: could not read %s: %s", path, e)
            return None
        return token or None


class ModalOIDCProvider(OIDCExchangeProvider):
    """Exchange a Modal identity token for an AgentStream JWT.

    Modal Functions that opt into OIDC integration receive an id token in the
    ``MODAL_IDENTITY_TOKEN`` environment variable. The token is injected once
    at container start and **does not rotate for the container lifetime** —
    calling :meth:`refresh` will re-read the same env var, the JTI guard in
    the base class will notice it's the same token we already exchanged, and
    return ``None``. The caller raises ``AuthError`` and pauses sync.

    This matches the backend's JTI replay protection: each id token can be
    exchanged exactly once. Long-running Modal Functions should be scoped
    shorter than the AgentStream JWT TTL (1 hour by default) so auth never
    needs to be refreshed.

    Docs: https://modal.com/docs/guide/oidc-integration
    """

    name = "modal_oidc"
    auth_method = "modal_oidc"
    default_identity = "modal"

    ENV_VAR = "MODAL_IDENTITY_TOKEN"

    def is_available(self) -> bool:
        return bool(os.environ.get(self.ENV_VAR))

    async def _get_id_token(self, endpoint: str) -> str | None:
        # Re-read the env var every time so rotated tokens are picked up.
        # Modal's audience is fixed by the provider (https://oidc.modal.com)
        # and verified server-side regardless of endpoint.
        return os.environ.get(self.ENV_VAR) or None


class DiscoveryProvider:
    """Wrap the existing SSH / credential helper / gh CLI auth discovery.

    Delegates to :meth:`AuthManager._authenticate` which returns freshly
    minted ``StoredCredentials``. Persists to disk via the manager's normal
    save path.
    """

    name = "discovery"
    persists_to_disk = True
    supports_refresh = False

    def __init__(self, manager: AuthManager) -> None:
        self._manager = manager

    def is_available(self) -> bool:
        # is_available() is called from an async context and must NOT do
        # network or subprocess work. Resolving credentials does — those
        # calls happen in resolve() below, which the manager runs only
        # after this fast filter passes.
        #
        # SSO gate: skip discovery for OIDC/SSO users. ssh/credential/gh would
        # mint non-OIDC tokens that an SSO-enforced org rejects with 403,
        # silently overwriting the user's working OIDC creds. SSO users must
        # go through the interactive oidc_browser/oidc_device path instead.
        try:
            existing = self._manager.store.load_raw(self._manager.endpoint)
        except Exception:
            existing = None
        if existing and (
            getattr(existing, "sso_required", False)
            or (existing.auth_method or "").startswith("oidc_")
        ):
            return False
        # Cheap proxies: a key/binary on disk means resolve() has *something*
        # to try. False positives are fine (resolve() will fall through);
        # false negatives would skip a working provider.
        disc = self._manager.discovery
        if disc._find_ssh_key():
            return True
        if shutil.which("gh"):
            return True
        if shutil.which("git"):
            return True
        return False

    async def resolve(self, endpoint: str, device_id: str) -> StoredCredentials | None:
        # Import locally to avoid a circular import at module load time.
        from hivemind.auth.manager import AuthError  # noqa: PLC0415

        for method in ("ssh", "credential", "gh"):
            try:
                return await self._manager._authenticate(force_method=method)
            except AuthError as e:
                logger.debug("Discovery method %s failed: %s", method, e)
                continue
        return None

    async def refresh(self, endpoint: str, device_id: str) -> StoredCredentials | None:
        return await self.resolve(endpoint, device_id)


class DevModeProvider:
    """Wrap the ``HIVEMIND_DEV_MODE`` auto-login flow.

    Delegates to a caller-supplied coroutine (normally ``_dev_mode_authenticate``
    in ``cli.py``) which calls the local API's ``/v1/auth/me`` endpoint and
    writes real dev-mode credentials to disk.
    """

    name = "dev_mode"
    persists_to_disk = True
    supports_refresh = False

    ENV_VAR = "HIVEMIND_DEV_MODE"

    def __init__(self, manager: AuthManager) -> None:
        self._manager = manager

    def is_available(self) -> bool:
        if os.environ.get(self.ENV_VAR, "").lower() not in ("1", "true", "yes"):
            return False
        # DEV_MODE auto-login via /v1/auth/me only makes sense against a local
        # dev server. A remote endpoint like hivemind.qa.wandb.tools must use
        # real auth even when the env var is set (e.g. when dev.repo re-execs
        # against a remote server). See main's PR #427 for the original fix.
        from urllib.parse import urlparse  # noqa: PLC0415

        host = urlparse(self._manager.endpoint).hostname or ""
        return host in ("localhost", "127.0.0.1", "::1") or host.endswith(".test")

    async def resolve(self, endpoint: str, device_id: str) -> StoredCredentials | None:
        # Delegate to the existing cli-level helper. Imported lazily to avoid
        # a circular import between cli and auth.
        from hivemind.cli import _dev_mode_authenticate  # noqa: PLC0415

        ok = await _dev_mode_authenticate(self._manager)
        if not ok:
            return None
        # _dev_mode_authenticate writes to disk; load the fresh creds back.
        return self._manager.store.load(endpoint)

    async def refresh(self, endpoint: str, device_id: str) -> StoredCredentials | None:
        return await self.resolve(endpoint, device_id)
