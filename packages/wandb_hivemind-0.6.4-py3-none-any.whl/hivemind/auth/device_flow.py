"""GitHub OAuth device flow for AgentStream daemon."""

from __future__ import annotations

import asyncio
import contextlib
import os
import sys
import time
import webbrowser
from typing import Any

import httpx

from hivemind.auth.device_ui import (
    poll_with_countdown,
    render_login_panel,
    wait_for_continue_or_issuer,
)
from hivemind.auth.discovery import TokenAuthMethod


class AuthError(Exception):
    """Authentication error."""

    pass


class OIDCSwitchRequested(Exception):
    """User entered an Okta URL at the device flow prompt to switch to OIDC SSO.

    The login flow catches this and re-runs auth via the OIDC device flow
    using ``issuer_hint`` to discover the org's sso_org_id.
    """

    def __init__(self, issuer_hint: str):
        super().__init__(f"User requested OIDC switch to {issuer_hint!r}")
        self.issuer_hint = issuer_hint


# GitHub App with "Expiring user tokens" enabled, so device flow returns
# a refresh_token and the daemon can refresh silently inside systemd/launchd.
# Both prod (hivemind.wandb.tools) and QA (hivemind.qa.wandb.tools) are
# registered as allowed callbacks on this App. Override with
# HIVEMIND_GITHUB_CLIENT_ID for local development against a different App.
GITHUB_CLIENT_ID = "Iv23liV6n9amGfGY20Js"

DEVICE_FLOW_SCOPE = "read:user read:org"


def get_github_client_id() -> str:
    """Return the GitHub OAuth client ID, honoring HIVEMIND_GITHUB_CLIENT_ID."""
    return os.getenv("HIVEMIND_GITHUB_CLIENT_ID") or GITHUB_CLIENT_ID


class DeviceFlowAuth:
    """GitHub OAuth device flow."""

    DEVICE_CODE_URL = "https://github.com/login/device/code"
    ACCESS_TOKEN_URL = "https://github.com/login/oauth/access_token"

    def __init__(self, client_id: str | None = None):
        self.client_id = client_id or get_github_client_id()
        if not self.client_id:
            raise AuthError("GitHub OAuth client ID not configured")

    async def authenticate(self) -> TokenAuthMethod:
        """Run device flow and return token auth method.

        Refuses to run in a headless (no-TTY) environment because the flow
        requires the user to copy a code and press Enter. Without this guard
        `input()` returns immediately with EOF, which the daemon previously
        surfaced as a cryptic "EOF when reading a line" warning when a
        refresh was triggered inside systemd/launchd (see the user report).
        """

        if not sys.stdin.isatty():
            raise AuthError(
                "GitHub device flow requires an interactive terminal. "
                "Run `hivemind login` from a shell to re-authenticate."
            )

        # Request device code
        async with httpx.AsyncClient() as client:
            response = await client.post(
                self.DEVICE_CODE_URL,
                data={
                    "client_id": self.client_id,
                    "scope": DEVICE_FLOW_SCOPE,
                },
                headers={"Accept": "application/json"},
                timeout=30,
            )

        if response.status_code != 200:
            # GitHub usually replies with a JSON body like
            # {"error": "...", "error_description": "..."}; surface the
            # description (which is human-readable) rather than the raw
            # response when we can.
            description: str | None = None
            try:
                payload = response.json()
            except ValueError:
                payload = None
            if isinstance(payload, dict):
                description = payload.get("error_description") or payload.get("error")
            detail = description or response.text or f"HTTP {response.status_code}"
            raise AuthError(f"GitHub rejected the device-flow request: {detail}")

        data = response.json()
        device_code = data["device_code"]
        user_code = data["user_code"]
        verification_uri = data["verification_uri"]
        interval = data.get("interval", 5)
        expires_in = data.get("expires_in", 900)

        render_login_panel(
            title="GitHub Authentication Required",
            code=user_code,
            url=verification_uri,
            has_code_in_url=False,
            allow_sso_escape=True,
        )

        # Single-keystroke gate: Enter to continue, '!' to drop into SSO
        # issuer entry, anything else (including focus-event escape codes
        # from cmd+tab) is silently ignored.
        issuer = wait_for_continue_or_issuer(allow_sso_escape=True)
        if issuer:
            raise OIDCSwitchRequested(issuer)

        # Best-effort browser launch — headless/SSH sessions and missing
        # display servers raise here, but the panel above already shows
        # the URL+code so the user can open it manually.
        with contextlib.suppress(Exception):
            webbrowser.open(verification_uri)

        # Poll with the shared spinner+countdown.
        token_result = await poll_with_countdown(
            self._poll_for_token(
                device_code=device_code,
                interval=interval,
                expires_in=expires_in,
            ),
            label="Waiting for GitHub authorization",
            timeout=expires_in,
        )

        access_token = token_result["access_token"]
        refresh_token = token_result.get("refresh_token")
        refresh_token_expires_in = token_result.get("refresh_token_expires_in")

        github_user = await self._get_github_user(access_token)

        print(f"  Authenticated as: {github_user}")
        print()

        return TokenAuthMethod(
            token=access_token,
            github_user=github_user,
            source="device_flow",
            refresh_token=refresh_token,
            refresh_token_expires_in=refresh_token_expires_in,
        )

    async def _poll_for_token(
        self,
        device_code: str,
        interval: int,
        expires_in: int,
    ) -> dict[str, Any]:
        """Poll GitHub until user authorizes.

        Returns a dict with 'access_token' (str) and optionally 'refresh_token'
        (str) plus 'refresh_token_expires_in' (int) when the GitHub App has
        expiring user tokens enabled.
        """
        deadline = time.time() + expires_in

        async with httpx.AsyncClient() as client:
            while time.time() < deadline:
                await asyncio.sleep(interval)

                response = await client.post(
                    self.ACCESS_TOKEN_URL,
                    data={
                        "client_id": self.client_id,
                        "device_code": device_code,
                        "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                    },
                    headers={"Accept": "application/json"},
                    timeout=30,
                )

                data = response.json()

                if "access_token" in data:
                    result: dict[str, Any] = {"access_token": data["access_token"]}
                    # GitHub returns refresh_token when App has expiring tokens enabled
                    if data.get("refresh_token"):
                        result["refresh_token"] = data["refresh_token"]
                    # refresh_token_expires_in is seconds from now — the caller
                    # converts to an absolute timestamp when persisting.
                    if data.get("refresh_token_expires_in"):
                        # Drop a malformed value rather than failing auth —
                        # the caller falls back to no refresh expiry.
                        with contextlib.suppress(TypeError, ValueError):
                            result["refresh_token_expires_in"] = int(
                                data["refresh_token_expires_in"]
                            )
                    return result

                error = data.get("error")

                if error == "authorization_pending":
                    continue
                elif error == "slow_down":
                    interval += 5
                elif error == "expired_token":
                    raise AuthError("Device code expired")
                elif error == "access_denied":
                    raise AuthError("Authorization denied")
                else:
                    raise AuthError(f"Device flow error: {error}")

        raise AuthError("Device flow timed out")

    async def _get_github_user(self, token: str) -> str:
        """Get GitHub username from access token."""
        async with httpx.AsyncClient() as client:
            response = await client.get(
                "https://api.github.com/user",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Accept": "application/vnd.github+json",
                },
                timeout=10,
            )

        if response.status_code != 200:
            raise AuthError("Failed to get GitHub user info")

        return response.json()["login"]
