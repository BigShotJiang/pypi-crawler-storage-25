"""OIDC SSO authentication flows for the Hivemind daemon.

Two flows:
1. Browser PKCE — opens browser, FastPass handles it, token comes back via loopback
2. Device Authorization Grant — headless CLI over SSH, user approves in browser
"""

from __future__ import annotations

import asyncio
import contextlib
import hmac
import html
import json as _json
import logging
import secrets
import webbrowser
from http.server import HTTPServer, BaseHTTPRequestHandler
from threading import Thread
from urllib.parse import parse_qs, urlencode, urlparse

import httpx

from hivemind.auth.device_ui import (
    poll_with_countdown,
    render_login_panel,
    wait_for_continue_or_issuer,
)
from hivemind.health import collect_status as _collect_status

logger = logging.getLogger(__name__)


class OIDCAuthError(Exception):
    """OIDC authentication error."""

    pass


def _render_landing_page(user: str, email: str) -> bytes:
    """Render the OIDC success landing page. Status checks load asynchronously."""
    if user and email:
        signed_in = f"Signed in as <strong>{html.escape(user)}</strong> ({html.escape(email)})"
    elif user:
        signed_in = f"Signed in as <strong>{html.escape(user)}</strong>"
    elif email:
        signed_in = f"Signed in as <strong>{html.escape(email)}</strong>"
    else:
        signed_in = "Signed in"
    return f"""<!DOCTYPE html>
<html>
<head>
    <title>Hivemind — Authenticated</title>
    <meta charset="utf-8">
    <style>
        * {{ margin:0; padding:0; box-sizing:border-box }}
        body {{ background:#09090b; color:#e4e4e7; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif; display:flex; justify-content:center; padding:60px 20px }}
        .card {{ background:#18181b; border:1px solid #27272a; border-radius:12px; padding:40px; max-width:520px; width:100% }}
        .header {{ display:flex; align-items:center; gap:12px; margin-bottom:24px }}
        .logo {{ width:36px; height:36px; background:linear-gradient(135deg,#fca5a5,#e11d48); border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:22px }}
        h1 {{ font-size:20px; font-weight:600 }}
        .success {{ color:#22c55e; font-size:14px; margin-bottom:24px; display:flex; align-items:center; gap:8px }}
        .user {{ background:#27272a; border-radius:8px; padding:12px 16px; margin-bottom:24px; font-size:14px }}
        .user strong {{ color:#f4f4f5 }}
        .checks {{ margin-bottom:20px }}
        .checks-title {{ font-size:13px; color:#71717a; text-transform:uppercase; letter-spacing:0.05em; margin-bottom:8px }}
        .check-row {{ display:flex; align-items:center; gap:10px; padding:8px 0; border-bottom:1px solid #27272a }}
        .check-icon {{ font-size:18px; width:20px; text-align:center }}
        .check-label {{ color:#e4e4e7; flex:1 }}
        .check-detail {{ color:#a1a1aa; font-size:13px }}
        .spinner {{ display:inline-block; animation:spin 1s linear infinite }}
        @keyframes spin {{ to {{ transform:rotate(360deg) }} }}
        .closing {{ color:#71717a; font-size:13px; text-align:center; margin-top:24px }}
        code {{ background:#27272a; padding:2px 6px; border-radius:4px; font-size:12px; color:#a1a1aa }}
    </style>
</head>
<body>
    <div class="card">
        <div class="header">
            <div class="logo">🧠</div>
            <h1>Hivemind</h1>
        </div>
        <div class="success">
            <span style="font-size:18px">✓</span> Authentication successful
        </div>
        <div class="user">
            {signed_in}
        </div>
        <div class="checks">
            <div class="checks-title">System Status</div>
            <div id="status-checks">
                <div class="check-row">
                    <span class="check-icon spinner" style="color:#71717a">◌</span>
                    <span class="check-label">Checking system status...</span>
                </div>
            </div>
        </div>
        <div class="closing">You can close this tab.</div>
    </div>
    <script>
    fetch('/status')
        .then(r => r.json())
        .then(checks => {{
            const el = document.getElementById('status-checks');
            el.innerHTML = '';
            checks.forEach(c => {{
                let icon, color;
                if (c.ok === true) {{ icon = '✓'; color = '#22c55e'; }}
                else if (c.ok === false) {{ icon = '✗'; color = '#ef4444'; }}
                else {{ icon = '—'; color = '#a1a1aa'; }}
                const row = document.createElement('div');
                row.className = 'check-row';
                row.innerHTML = `<span class="check-icon" style="color:${{color}}">${{icon}}</span>`;
                const label = document.createElement('span');
                label.className = 'check-label';
                label.textContent = c.label;
                const detail = document.createElement('span');
                detail.className = 'check-detail';
                detail.textContent = c.detail;
                row.appendChild(label);
                row.appendChild(detail);
                el.appendChild(row);
            }});
        }})
        .catch(() => {{
            document.getElementById('status-checks').innerHTML =
                '<div class="check-row"><span class="check-icon" style="color:#a1a1aa">—</span><span class="check-label">Could not load status</span></div>';
        }});
    </script>
</body>
</html>""".encode()


def _render_error_page(error: str) -> bytes:
    """Render the OIDC error landing page."""
    return f"""<!DOCTYPE html>
<html>
<head>
    <title>Hivemind — Authentication Failed</title>
    <meta charset="utf-8">
    <style>
        * {{ margin:0; padding:0; box-sizing:border-box }}
        body {{ background:#09090b; color:#e4e4e7; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif; display:flex; justify-content:center; padding:60px 20px }}
        .card {{ background:#18181b; border:1px solid #27272a; border-radius:12px; padding:40px; max-width:520px; width:100% }}
        .header {{ display:flex; align-items:center; gap:12px; margin-bottom:24px }}
        .logo {{ width:36px; height:36px; background:linear-gradient(135deg,#ef4444,#dc2626); border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:22px }}
        h1 {{ font-size:20px; font-weight:600 }}
        .error {{ color:#ef4444; font-size:14px; margin-bottom:16px }}
        .detail {{ background:#27272a; border-radius:8px; padding:12px 16px; font-size:13px; color:#a1a1aa; word-break:break-word }}
        .hint {{ color:#71717a; font-size:13px; text-align:center; margin-top:24px }}
    </style>
</head>
<body>
    <div class="card">
        <div class="header">
            <div class="logo">🧠</div>
            <h1>Hivemind</h1>
        </div>
        <div class="error">✗ Authentication failed</div>
        <div class="detail">{html.escape(error)}</div>
        <div class="hint">Close this tab and try again from the terminal.</div>
    </div>
</body>
</html>""".encode()


_MAX_FORM_BODY_BYTES = 16 * 1024  # 16 KB is more than enough for our fields


class _CallbackHandler(BaseHTTPRequestHandler):
    """HTTP handler that captures the OIDC callback token via form_post.

    Security model:

    * The credential is delivered via HTTP POST with an
      ``application/x-www-form-urlencoded`` body, never the URL. This is OIDC
      ``response_mode=form_post`` and is the standard answer to "how do I get
      a bearer token out of the browser without leaking it via history,
      Referer, screenshots, or proxy logs."
    * Each ``hivemind login`` invocation generates a fresh ``expected_state``
      nonce (32 random bytes via ``secrets.token_urlsafe``) which it ships to
      the backend in the login URL. The backend echoes it back in the form
      body, and we ``hmac.compare_digest`` it before accepting any fields.
      A local attacker who guesses our random port can't forge a callback
      because they don't know the nonce.
    * The ``Host`` header must be a loopback address. This blocks DNS
      rebinding attacks where an attacker-controlled hostname resolves to
      127.0.0.1 — the browser would still send the attacker's hostname in
      ``Host``, and we would reject it.
    * After accepting the POST we 303 See Other to ``/done`` (Post/Redirect/
      Get) so the browser address bar lands on a clean URL and reloading the
      success page can't replay the form.
    """

    # Class-level state — set by auth_via_oidc_browser before the server starts
    token_data: dict | None = None
    error: str | None = None
    expected_state: str = ""
    # When True, the loopback expects an escalation callback shape from the
    # backend (escalation_token + expires_at + user_id, no refresh token /
    # email / github_user).
    expect_escalation: bool = False

    # ----- helpers -----

    def _send_html(self, status: int, body: bytes, *, extra_headers: dict | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra_headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _reject(self, status: int, error: str) -> None:
        _CallbackHandler.error = error
        self._send_html(status, _render_error_page(error))

    def _host_is_loopback(self) -> bool:
        host_header = self.headers.get("Host", "")
        # Strip port; tolerate IPv6 brackets.
        host = host_header.rsplit(":", 1)[0].strip("[]") if host_header else ""
        return host in ("127.0.0.1", "localhost", "::1")

    # ----- routing -----

    def do_GET(self):
        parsed = urlparse(self.path)

        if parsed.path == "/status":
            # Async status endpoint — called by the landing page JS
            checks = _collect_status()
            payload = _json.dumps(checks).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(payload)
            return

        if parsed.path == "/done" and _CallbackHandler.token_data:
            user = _CallbackHandler.token_data.get("github_user", "")
            email = _CallbackHandler.token_data.get("email", "")
            self._send_html(200, _render_landing_page(user, email))
            return

        params = parse_qs(parsed.query)
        if "error" in params:
            err = params.get("error_description", params["error"])[0]
            self._reject(400, err)
            return

        # /callback is POST-only now (form_post). GETs to /callback are
        # bounced so accidental reloads / browser prefetches can't replay.
        if parsed.path == "/callback":
            self.send_response(405)
            self.send_header("Allow", "POST")
            self.end_headers()
            return

        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path != "/callback":
            self.send_response(404)
            self.end_headers()
            return

        # Defense against DNS rebinding: the browser must address us by a
        # loopback name. An attacker page hosted at evil.com can't trick the
        # browser into sending Host: 127.0.0.1.
        if not self._host_is_loopback():
            self._reject(400, "Invalid Host header on loopback callback")
            return

        # We only speak form-encoded — anything else is suspicious.
        ctype = self.headers.get("Content-Type", "").split(";")[0].strip().lower()
        if ctype != "application/x-www-form-urlencoded":
            self._reject(415, f"Unsupported Content-Type: {ctype!r}")
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self._reject(411, "Missing or invalid Content-Length")
            return
        if length <= 0 or length > _MAX_FORM_BODY_BYTES:
            self._reject(413, "Callback body missing or too large")
            return

        try:
            raw = self.rfile.read(length)
        except OSError as exc:
            self._reject(400, f"Failed to read callback body: {exc}")
            return

        try:
            fields = parse_qs(raw.decode("utf-8"), keep_blank_values=False)
        except UnicodeDecodeError:
            self._reject(400, "Callback body is not valid UTF-8")
            return

        # CSRF / replay defense: the backend echoes back the nonce we
        # generated when starting this loopback server. Constant-time compare.
        provided_state = fields.get("state", [""])[0]
        if not _CallbackHandler.expected_state or not hmac.compare_digest(
            provided_state, _CallbackHandler.expected_state
        ):
            # Don't tell the attacker which half failed.
            self._reject(403, "Callback state mismatch")
            return

        token_field = "escalation_token" if _CallbackHandler.expect_escalation else "token"
        token = fields.get(token_field, [""])[0]
        if not token:
            self._reject(400, f"Callback body missing {token_field}")
            return

        try:
            expires_at = int(fields.get("expires_at", ["0"])[0])
        except (ValueError, TypeError):
            self._reject(400, "Invalid expires_at in callback body")
            return

        if _CallbackHandler.expect_escalation:
            _CallbackHandler.token_data = {
                "escalation_token": token,
                "user_id": fields.get("user_id", [""])[0],
                "github_user": fields.get("github_user", [""])[0],
                "email": fields.get("email", [""])[0],
                "expires_at": expires_at,
            }
        else:
            _CallbackHandler.token_data = {
                "token": token,
                "user_id": fields.get("user_id", [""])[0],
                "github_user": fields.get("github_user", [""])[0],
                "email": fields.get("email", [""])[0],
                "expires_at": expires_at,
            }
            if "refresh_token" in fields:
                _CallbackHandler.token_data["refresh_token"] = fields["refresh_token"][0]
                _CallbackHandler.token_data["refresh_token_type"] = fields.get(
                    "refresh_token_type", ["okta"]
                )[0]
                if "refresh_token_expires_at" in fields:
                    # Drop a malformed value rather than failing the
                    # callback — the daemon will simply re-login when
                    # the access token next expires.
                    with contextlib.suppress(ValueError, TypeError):
                        _CallbackHandler.token_data["refresh_token_expires_at"] = int(
                            fields["refresh_token_expires_at"][0]
                        )

        # Post/Redirect/Get: 303 See Other forces the browser to do a GET on
        # /done, so the address bar lands on a clean URL and a page reload
        # won't re-POST the (now-stale) form.
        self.send_response(303)
        self.send_header("Location", "/done")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

    def log_message(self, format, *args):
        """Suppress default HTTP server logging (would otherwise spam stderr
        with every callback request, including the loopback POST line)."""
        pass


async def _discover_oidc_urls(endpoint: str, org_id: str) -> dict:
    """Discover the correct OIDC URLs from the server.

    The server knows its public HTTPS URL (which may differ from the daemon's
    endpoint in dev when using tailscale funnel). The config endpoint returns
    URLs with the correct scheme and hostname.
    """
    async with httpx.AsyncClient() as client:
        resp = await client.get(
            f"{endpoint}/v1/auth/oidc/config",
            params={"org_id": org_id},
            timeout=10,
        )
    if resp.status_code != 200:
        # Fall back to constructing URL from endpoint
        return {
            "login_url": f"{endpoint}/v1/auth/oidc/login",
        }
    return resp.json()


async def auth_via_oidc_browser(
    endpoint: str,
    org_id: str,
    timeout: int = 120,
    acr_values: str = "",
    purpose: str = "",
) -> dict:
    """Authenticate via OIDC browser PKCE flow with local loopback server.

    Opens the system browser to the OIDC login endpoint. After authentication
    (FastPass handles it silently on Macs with Okta Verify), the server
    redirects back to our local loopback with the token.

    Args:
        endpoint: The Hivemind API endpoint (e.g. https://hivemind.wandb.tools)
        org_id: Organization ID to authenticate with
        timeout: Seconds to wait for the callback
        acr_values: Authentication Context Class Reference for step-up auth.
            Use "phrh" for sudo mode (triggers Touch ID / biometric).
        purpose: Flow purpose. Pass ``"escalation"`` to run the admin-mode
            step-up flow; the backend forces ``acr=phrh`` and the callback
            mints an escalation token instead of a full session. The
            returned dict shape differs (see below).

    Returns:
        For a normal login (``purpose=""``): dict with ``token``,
        ``user_id``, ``github_user``, ``email``, ``expires_at`` and
        optionally ``refresh_token`` / ``refresh_token_type``.

        For ``purpose="escalation"``: dict with ``escalation_token``,
        ``user_id``, ``expires_at``. No session token or profile fields
        are returned — the caller must already have a base login, and
        should store the result in the credential escalation slot via
        ``CredentialStore.save_escalation``.
    """
    # Discover the correct public login URL from the server.
    # In dev, the daemon endpoint is localhost but the OIDC callback must be HTTPS.
    # The config endpoint returns URLs based on the request's host, so if we
    # hit it via localhost we get an unusable https://localhost URL.
    # Use the endpoint directly — in production it's already the right URL.
    # In dev, the user should set HIVEMIND_ENDPOINT to the funnel URL.
    login_base = f"{endpoint}/v1/auth/oidc/login"
    if "localhost" not in endpoint and "127.0.0.1" not in endpoint:
        urls = await _discover_oidc_urls(endpoint, org_id)
        login_base = urls.get("login_url", login_base)

    # Generate a fresh CSRF nonce for this login attempt. The backend will
    # echo it back in the form_post body and the loopback handler validates
    # it via constant-time compare. Without this, any local program that can
    # guess the random port could POST a forged token to /callback.
    cli_state = secrets.token_urlsafe(32)

    # Reset handler state
    _CallbackHandler.token_data = None
    _CallbackHandler.error = None
    _CallbackHandler.expected_state = cli_state
    _CallbackHandler.expect_escalation = purpose == "escalation"

    # Start local callback server on a random port
    server = HTTPServer(("127.0.0.1", 0), _CallbackHandler)
    port = server.server_address[1]
    server_thread = Thread(target=server.serve_forever, daemon=True)
    server_thread.start()

    try:
        # Use 127.0.0.1 (not "localhost") so the form_post Host header is
        # always a literal loopback IP, sidestepping any /etc/hosts shenanigans
        # and matching the CSP `form-action` allow-list on the backend.
        callback_url = f"http://127.0.0.1:{port}/callback"
        login_params = {
            "org_id": org_id,
            "cli_redirect": callback_url,
            "cli_state": cli_state,
        }
        if acr_values:
            login_params["acr_values"] = acr_values
        if purpose:
            login_params["purpose"] = purpose
        login_url = f"{login_base}?{urlencode(login_params)}"

        logger.info(f"Opening browser for OIDC login (callback on port {port})")
        webbrowser.open(login_url)

        # Wait for the callback
        elapsed = 0
        while elapsed < timeout:
            if _CallbackHandler.token_data is not None:
                # Keep the server alive briefly so the browser can fetch /status
                await asyncio.sleep(3)
                return _CallbackHandler.token_data
            if _CallbackHandler.error is not None:
                raise OIDCAuthError(f"OIDC authentication failed: {_CallbackHandler.error}")
            await asyncio.sleep(1)
            elapsed += 1

        raise OIDCAuthError(f"OIDC authentication timed out after {timeout}s")
    finally:
        server.shutdown()
        # Clear the nonce so it can't be reused after this function returns
        # (token_data is intentionally left for the caller to consume).
        _CallbackHandler.expected_state = ""
        _CallbackHandler.expect_escalation = False


async def auth_via_oidc_device(
    endpoint: str,
    org_id: str,
    timeout: int = 600,
) -> dict:
    """Authenticate via OIDC Device Authorization Grant.

    Uses the shared device-login UI. When the IdP returns
    ``verification_uri_complete`` we show only that URL (the code is
    embedded) and skip the separate code step.
    """
    # Initiate device authorization
    async with httpx.AsyncClient() as client:
        resp = await client.post(
            f"{endpoint}/v1/auth/oidc/device",
            params={"org_id": org_id},
            timeout=10,
        )

    if resp.status_code != 200:
        detail = (
            resp.json().get("detail", resp.text)
            if "json" in resp.headers.get("content-type", "")
            else resp.text
        )
        raise OIDCAuthError(f"Device authorization failed: {detail}")

    data = resp.json()
    device_code = data["device_code"]
    interval = data.get("interval", 5)
    has_complete_uri = "verification_uri_complete" in data
    verification_uri = data.get("verification_uri_complete") or data.get("verification_uri", "")
    user_code = data.get("user_code") or None

    render_login_panel(
        title="Sign in with SSO",
        code=user_code,
        url=verification_uri,
        has_code_in_url=has_complete_uri,
        allow_sso_escape=False,
    )

    # Wait so SSH/headless users can copy the URL before the browser opens.
    wait_for_continue_or_issuer(allow_sso_escape=False)

    # Best-effort browser launch — headless/SSH sessions and missing
    # display servers raise here, but the panel above already shows
    # the URL+code so the user can open it manually.
    with contextlib.suppress(Exception):
        webbrowser.open(verification_uri)

    return await poll_with_countdown(
        _poll_oidc_device(endpoint, device_code, org_id, interval, timeout),
        label="Waiting for SSO sign-in",
        timeout=timeout,
    )


async def _poll_oidc_device(
    endpoint: str,
    device_code: str,
    org_id: str,
    interval: int,
    timeout: int,
) -> dict:
    """Poll the AS device-token endpoint until the IdP authorizes the grant."""
    elapsed = 0
    async with httpx.AsyncClient() as client:
        while elapsed < timeout:
            await asyncio.sleep(interval)
            elapsed += interval

            resp = await client.post(
                f"{endpoint}/v1/auth/oidc/device/token",
                json={"device_code": device_code, "org_id": org_id},
                timeout=10,
            )

            # Misbehaving proxies / upstream 502s can return HTML; surface
            # as a friendly error instead of a JSONDecodeError trace.
            try:
                resp_data = resp.json()
            except ValueError:
                snippet = resp.text[:200].strip().replace("\n", " ")
                raise OIDCAuthError(
                    f"Device flow polling got non-JSON response "
                    f"(HTTP {resp.status_code}): {snippet!r}"
                ) from None

            status = resp_data.get("status")
            if status == "authorized":
                return resp_data
            if status == "pending":
                continue

            error = resp_data.get("detail", resp_data.get("error", str(resp_data)))
            raise OIDCAuthError(f"Device flow failed: {error}")

    raise OIDCAuthError(f"Device flow timed out after {timeout}s")
