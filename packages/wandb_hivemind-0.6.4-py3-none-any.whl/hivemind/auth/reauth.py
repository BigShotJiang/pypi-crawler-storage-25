"""Single source of truth for "does the user need to re-authenticate?"

Used by interactive CLI commands (`hivemind start`, `hivemind restart`, and
eventually other user-invoked commands like `hivemind search`) to decide
whether to prompt for an interactive login before proceeding. This is a
preflight gate that runs in the user's terminal — it is NOT consulted by
the daemon's sync loop, so AGE_EXPIRED / EXPIRED decisions here will never
cause the running daemon to pause. The daemon pauses only on hard auth
failures (server sso_required responses, or a broken OIDC refresh chain).
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from enum import Enum

from hivemind.auth.credentials import StoredCredentials

# Hard cap on credential age (since the last *interactive* login). After this
# many days, we force the user back through the login flow even if their
# token is still being refreshed in the background. Daemon-side constant.
MAX_CREDENTIAL_AGE_DAYS = 60

# Cushion before token expiry that still counts as "expired" for re-auth
# purposes. Matches CredentialStore.is_expired's default buffer.
EXPIRY_BUFFER_SECONDS = 3600


class ReauthDecision(str, Enum):
    """The reason a re-authentication is (or isn't) needed."""

    OK = "ok"
    CREDS_MISSING = "creds_missing"
    EXPIRED = "expired"
    AGE_EXPIRED = "age_expired"
    SSO_REQUIRED = "sso_required"


@dataclass
class ReauthResult:
    decision: ReauthDecision
    sso_org_id: str | None = None
    age_days: float | None = None

    @property
    def needs_reauth(self) -> bool:
        return self.decision is not ReauthDecision.OK

    def message(self) -> str:
        """Human-readable explanation suitable for printing to the user."""
        if self.decision is ReauthDecision.OK:
            return "Credentials are valid."
        if self.decision is ReauthDecision.CREDS_MISSING:
            return "No saved credentials found — signing you in."
        if self.decision is ReauthDecision.EXPIRED:
            return "Your session has expired — signing you in again."
        if self.decision is ReauthDecision.AGE_EXPIRED:
            days = int(self.age_days or 0)
            return (
                f"Credentials are {days} days old (max {MAX_CREDENTIAL_AGE_DAYS}). "
                "Please sign in again."
            )
        if self.decision is ReauthDecision.SSO_REQUIRED:
            return "Your organization now requires SSO sign-in. Opening browser…"
        return "Re-authentication required."


def evaluate_reauth(
    creds: StoredCredentials | None,
    *,
    now: float | None = None,
) -> ReauthResult:
    """Decide whether the user needs to re-authenticate.

    Order of checks (first match wins):
    1. No credentials → CREDS_MISSING
    2. Token past expiry (+ buffer) → EXPIRED
    3. Last interactive login older than MAX_CREDENTIAL_AGE_DAYS → AGE_EXPIRED
    4. Org requires SSO and current creds aren't from an SSO method → SSO_REQUIRED
    5. Otherwise → OK

    Args:
        creds: Currently stored credentials, or None.
        now: Override current time (for tests).
    """
    current_time = now if now is not None else time.time()

    if creds is None:
        return ReauthResult(ReauthDecision.CREDS_MISSING)

    if current_time >= (creds.expires_at - EXPIRY_BUFFER_SECONDS):
        return ReauthResult(ReauthDecision.EXPIRED)

    age_days = (current_time - creds.created_at) / 86400.0
    if age_days >= MAX_CREDENTIAL_AGE_DAYS:
        return ReauthResult(ReauthDecision.AGE_EXPIRED, age_days=age_days)

    if creds.sso_required and not (creds.auth_method or "").startswith("oidc_"):
        return ReauthResult(ReauthDecision.SSO_REQUIRED, sso_org_id=creds.sso_org_id)

    return ReauthResult(ReauthDecision.OK)
