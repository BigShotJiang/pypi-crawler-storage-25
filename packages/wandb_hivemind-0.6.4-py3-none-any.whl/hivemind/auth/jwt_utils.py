"""Unverified JWT payload decoding.

The daemon never validates JWT signatures locally — the backend is the
authority on that — but it occasionally needs to read a claim out of a
token it already trusts (its own session JWT, or an OIDC id token it's
about to exchange). One helper, one padding formula.
"""

from __future__ import annotations

import base64
import json
from typing import Any


def decode_jwt_payload(token: str) -> dict[str, Any]:
    """Decode the payload of a JWT without verifying its signature.

    Raises ``ValueError`` (or ``json.JSONDecodeError``, a subclass) if the
    token is malformed. Callers that want a quiet fallback should catch
    ``Exception``.
    """
    parts = token.split(".")
    if len(parts) < 2:
        raise ValueError("token is not a JWT (missing payload segment)")
    payload_b64 = parts[1]
    # ``-len % 4`` yields 0..3 — the modular inverse, never 4.
    payload_b64 += "=" * (-len(payload_b64) % 4)
    return json.loads(base64.urlsafe_b64decode(payload_b64))
