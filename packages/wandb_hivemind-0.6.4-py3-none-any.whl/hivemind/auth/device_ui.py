"""Shared rich-based UI for the GitHub and OIDC device-flow logins."""

from __future__ import annotations

import asyncio
import contextlib
import os
import signal
import sys
import time
from collections.abc import Awaitable
from contextlib import asynccontextmanager
from typing import TypeVar

from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.spinner import Spinner
from rich.text import Text

T = TypeVar("T")

_console = Console()


def render_login_panel(
    *,
    title: str,
    code: str | None,
    url: str,
    has_code_in_url: bool,
    allow_sso_escape: bool,
) -> None:
    """Render the device-login instruction panel.

    ``has_code_in_url`` is true for OIDC's ``verification_uri_complete``,
    where the URL already embeds the code so the "copy this code" step
    can be skipped.
    """
    body = Text()

    if has_code_in_url or code is None:
        body.append("Open this URL in your browser:\n\n", style="bold")
        body.append(f"  {url}\n", style=f"cyan link {url}")
    else:
        body.append("1. Copy this code:    ", style="dim")
        body.append(f"{code}\n\n", style="bold yellow")
        body.append("2. Open in browser:   ", style="dim")
        body.append(f"{url}\n", style=f"cyan link {url}")
        body.append("3. Paste the code in the browser and approve.\n", style="dim")

    body.append("\n")
    body.append("Press ", style="dim")
    body.append("Enter", style="bold green")
    body.append(" to continue", style="dim")
    if allow_sso_escape:
        body.append(", ", style="dim")
        body.append("!", style="bold yellow")
        body.append(" to switch to SSO", style="dim")
    body.append(", or ", style="dim")
    body.append("Ctrl+C", style="bold red")
    body.append(" to cancel.", style="dim")

    _console.print(Panel(body, title=title, border_style="blue", padding=(1, 2)))


def wait_for_continue_or_issuer(*, allow_sso_escape: bool) -> str | None:
    """Block until the user presses Enter, Ctrl+C, or (when allowed) ``!``.

    Returns ``None`` for Enter (proceed) or a non-empty issuer URL when
    the user typed ``!`` then entered one. Other keystrokes — focus
    events, arrows, escape sequences emitted when the user clicks the
    OSC 8 hyperlink in the panel, stray letters — are swallowed
    silently. Auto-returns ``None`` when stdin isn't a real TTY.

    Ctrl+C cancels via SIGINT (preferred, with ``ISIG`` forced on) or
    by reading ``\\x03`` directly as a fallback. Bare Esc is *not*
    treated as cancel — hyperlink clicks emit ``\\x1b``-prefixed focus
    reports that would false-trigger.
    """
    if not sys.stdin.isatty():
        return None

    import termios  # noqa: PLC0415  POSIX-only; Windows daemons don't reach here.

    # pytest's capture wrappers report isatty() True but fileno() raises.
    try:
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
    except (OSError, ValueError, AttributeError):
        return None

    _request_legacy_keyboard()
    try:
        _set_cbreak_with_isig(fd)
        # Buffer recently-read bytes so we can recognize multi-byte
        # cancel sequences (kitty keyboard protocol Ctrl+C) even though
        # the legacy-keyboard push above should usually prevent the
        # terminal from sending them.
        buf = bytearray()
        while True:
            ch = sys.stdin.read(1)
            if ch == "\x03":
                # Belt-and-suspenders: only reaches here if ISIG was
                # off and the kernel delivered Ctrl+C as a byte.
                raise KeyboardInterrupt
            if ch in ("\r", "\n"):
                return None
            if ch == "!" and allow_sso_escape:
                # Restore cooked mode so input() can edit the line.
                termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
                print()
                try:
                    issuer = input("  SSO issuer (e.g. company.okta.com): ").strip()
                except EOFError:
                    issuer = ""
                return issuer or None
            # Anything else — bare Esc, escape sequences, stray letters
            # — is swallowed, but we keep a sliding window of recent
            # bytes to spot kitty-protocol Ctrl+C (``\x1b[99;5u``).
            buf.extend(ch.encode("latin-1", errors="replace"))
            if len(buf) > 32:
                del buf[:-32]
            if _is_kitty_ctrl_c(bytes(buf)):
                raise KeyboardInterrupt
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        _restore_keyboard_mode()


def _set_cbreak_with_isig(fd: int) -> None:
    """Like ``tty.setcbreak`` but forces ``ISIG`` on regardless of prior state.

    Without this, a terminal that arrived with ``ISIG`` cleared (raw
    mode left over from another program, ``stty -isig`` in dotfiles,
    etc.) would silently swallow Ctrl+C.

    Uses ``TCSANOW`` rather than ``TCSAFLUSH`` (which stdlib
    ``tty.setcbreak`` defaults to). ``TCSAFLUSH`` discards anything in
    the kernel's input queue at the moment the mode changes — so a key
    the user pressed after the panel rendered but before this call
    finishes gets silently swallowed. The same flush also makes the
    PTY-based cancel tests racy: the test writes the kitty Ctrl+C
    sequence as soon as it sees the legacy-keyboard request marker,
    which lands between the marker write and this tcsetattr on a slow
    runner — TCSAFLUSH then drops it before the read loop starts.
    """
    import termios  # noqa: PLC0415

    mode = termios.tcgetattr(fd)
    mode[3] = (mode[3] & ~(termios.ECHO | termios.ICANON)) | termios.ISIG
    mode[6][termios.VMIN] = 1
    mode[6][termios.VTIME] = 0
    termios.tcsetattr(fd, termios.TCSANOW, mode)


# Kitty keyboard-protocol "progressive enhancement" stack ops. Modern
# terminals (Kitty, Ghostty, WezTerm, recent iTerm2) and some shells/
# tooling can have this protocol enabled — when it is, Ctrl+C arrives
# as the escape sequence ``CSI 99;5 u`` instead of the legacy byte
# ``\x03``. The kernel never sees ``\x03``, so ISIG-based SIGINT
# generation never happens, and our cbreak reader just absorbs the
# escape bytes one at a time without recognizing them. While we own the
# device-flow UI we push "no enhancements" onto the stack so the
# terminal falls back to legacy mode; on exit we pop to restore the
# user's previous setting. Terminals that don't support the protocol
# silently ignore both sequences.
_KITTY_KEYBOARD_PUSH_LEGACY = b"\x1b[>0u"
_KITTY_KEYBOARD_POP = b"\x1b[<u"


def _request_legacy_keyboard() -> None:
    """Tell the terminal to send keys in legacy mode (``\\x03`` for Ctrl+C)."""
    # Best-effort: stdout may be closed/redirected (non-TTY pipelines,
    # daemon contexts) — terminals that don't support the sequence just
    # ignore it, so failures here are safe to swallow.
    with contextlib.suppress(OSError):
        os.write(1, _KITTY_KEYBOARD_PUSH_LEGACY)


def _restore_keyboard_mode() -> None:
    """Pop the keyboard-protocol stack to restore the user's previous mode."""
    # Best-effort restore — same reasoning as _request_legacy_keyboard.
    with contextlib.suppress(OSError):
        os.write(1, _KITTY_KEYBOARD_POP)


def _is_kitty_ctrl_c(data: bytes) -> bool:
    """Detect a kitty keyboard protocol Ctrl+C in *data*.

    The format is ``CSI <keycode>;<modifiers>[;<text>] u`` where keycode
    is the unmodified key as a Unicode codepoint and modifiers ``5``
    means Ctrl. So Ctrl+C arrives as ``\\x1b[99;5u`` (lowercase) or
    ``\\x1b[67;5u`` (uppercase). We look anywhere in the buffer rather
    than parsing strictly because a single read can pick up multiple
    sequences batched together.
    """
    return b"\x1b[99;5u" in data or b"\x1b[67;5u" in data


class _Countdown:
    def __init__(self, label: str, timeout: int) -> None:
        self.label = label
        self.timeout = timeout
        self.start = time.monotonic()

    def __rich__(self) -> Spinner:
        remaining = max(0, self.timeout - int(time.monotonic() - self.start))
        text = Text.assemble(
            (f"{self.label}... ", "dim"),
            (f"{_format_remaining(remaining)} remaining", "yellow"),
            ("  (Ctrl+C to cancel)", "dim"),
        )
        return Spinner("dots", text=text, style="cyan")


def _format_remaining(seconds: int) -> str:
    if seconds < 60:
        return f"{seconds}s"
    minutes, secs = divmod(seconds, 60)
    return f"{minutes}m{secs:02d}s"


@asynccontextmanager
async def live_countdown(label: str, timeout: int):
    with Live(_Countdown(label, timeout), refresh_per_second=8, transient=True):
        yield


async def poll_with_countdown(
    coro: Awaitable[T],
    *,
    label: str = "Waiting for sign-in",
    timeout: int,
) -> T:
    """Run *coro* to completion (within *timeout* seconds) with a spinner+countdown.

    Ctrl+C cancels via SIGINT (preferred) or by reading ``\\x03`` from
    an asyncio stdin reader and self-SIGINT'ing — see
    :func:`_ctrl_c_watcher` for the dual-path mechanics.
    """
    async with _ctrl_c_watcher(), live_countdown(label, timeout):
        return await asyncio.wait_for(coro, timeout=timeout)


@asynccontextmanager
async def _ctrl_c_watcher():
    """Set cbreak on stdin and self-SIGINT if ``\\x03`` (or the kitty
    encoding of it) shows up — covers the case where ``ISIG`` is off
    and the kernel didn't generate SIGINT itself. No-ops when stdin
    isn't a TTY.
    """
    if not sys.stdin.isatty():
        yield
        return

    import termios  # noqa: PLC0415  POSIX-only; Windows daemons don't reach here.

    try:
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
    except (OSError, ValueError, AttributeError):
        yield
        return

    loop = asyncio.get_running_loop()
    pid = os.getpid()

    def _on_input() -> None:
        try:
            data = os.read(fd, 1024)
        except (OSError, BlockingIOError):
            return
        # Legacy Ctrl+C is a single byte; kitty keyboard protocol
        # encodes it as ``CSI <c|C>;5 u`` (i.e. ``\x1b[99;5u`` for
        # lowercase c, ``\x1b[67;5u`` for uppercase C, possibly with
        # an extra ``;<text>`` before the ``u``). Match either form.
        if b"\x03" in data or _is_kitty_ctrl_c(data):
            # Pretend the user hit Ctrl+C "for real" — sending SIGINT
            # to ourselves routes through the same handler the CLI
            # installed at the top level.
            with contextlib.suppress(ProcessLookupError, OSError):
                os.kill(pid, signal.SIGINT)

    reader_added = False
    _request_legacy_keyboard()
    try:
        _set_cbreak_with_isig(fd)
        try:
            loop.add_reader(fd, _on_input)
            reader_added = True
        except NotImplementedError:
            # Event loops that don't support add_reader on stdin (e.g.
            # Windows ProactorEventLoop) — SIGINT path still works.
            pass
        yield
    finally:
        if reader_added:
            with contextlib.suppress(ValueError, OSError):
                loop.remove_reader(fd)
        with contextlib.suppress(termios.error, OSError):
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        _restore_keyboard_mode()
