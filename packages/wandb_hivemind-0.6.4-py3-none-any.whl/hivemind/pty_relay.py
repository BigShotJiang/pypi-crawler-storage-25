"""PTY relay for injecting messages into agent sessions running in tmux.

Writes directly to the agent's terminal input via ``tmux send-keys``.
This is agent-agnostic and works with any terminal-based agent.

Architecture:
  Backend SSE (/v1/channels/{id}/subscribe)
    → TmuxRelay (this module, runs inside the daemon)
      → tmux send-keys -t {pane} "message" Enter
        → Agent receives as keyboard input

The existing backend channel endpoints (send/subscribe/list) are reused as-is.

Lifecycle:
  - ``hivemind alpha launch`` writes a launch file and signals the daemon.
  - The daemon calls ``relay.register_session()`` with the marker, agent
    type, and pane target.  The backend session ID is computed locally.
  - On daemon boot, ``recover_from_tmux()`` re-discovers running sessions
    by scanning tmux panes for ``@hivemind_pane_id`` markers.
  - ``prune_exited()`` detects panes whose marker has been cleared (agent
    exited) and cancels their relay tasks.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import subprocess
import time as _time

import httpx

from hivemind.auth.jwt_utils import decode_jwt_payload

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# tmux helpers
# ---------------------------------------------------------------------------


def is_tmux_available() -> bool:
    """Check if tmux is installed and a server is running.

    If tmux is installed but no server is running, starts one automatically
    so that ``hivemind alpha launch`` can create sessions later.
    """
    try:
        result = subprocess.run(
            ["tmux", "list-sessions"],
            capture_output=True,
            timeout=5,
        )
        if result.returncode == 0:
            return True
        # tmux is installed but no server running — start one
        start = subprocess.run(
            ["tmux", "new-session", "-d", "-s", "hivemind"],
            capture_output=True,
            timeout=5,
        )
        if start.returncode == 0:
            logger.info("Started tmux server (session: hivemind)")
            return True
        return False
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def inject_via_tmux(pane_target: str, message: str, agent: str = "claude") -> bool:
    """Send a message to a tmux pane as simulated keyboard input.

    Uses ``tmux send-keys -l`` (literal mode) so that special key names
    like ``Enter``, ``C-c``, ``Up`` in the message text are sent as-is
    rather than interpreted as key presses.  The submit keystroke is sent
    separately afterwards.
    """
    try:
        # -l = literal mode, -- = end of options (prevents message starting with -)
        result = subprocess.run(
            ["tmux", "send-keys", "-t", pane_target, "-l", "--", message],
            capture_output=True,
            timeout=5,
        )
        if result.returncode != 0:
            logger.warning(f"tmux send-keys failed for {pane_target}: {result.stderr.decode()}")
            return False
        # Codex uses crossterm which enables the Kitty keyboard protocol.
        # Plain "Enter" sends bare CR (0x0D) which crossterm treats as a
        # newline in Codex's multi-line input editor. The CSI u sequence
        # for Enter (ESC [ 13 u) is recognized as the actual Enter key.
        # Claude Code and other non-Kitty apps need plain Enter.
        if agent == "codex":
            # Small delay so the TUI processes the literal text before
            # receiving the CSI u submit sequence.
            _time.sleep(0.05)
            result = subprocess.run(
                ["tmux", "send-keys", "-t", pane_target, "-H", "1B", "5B", "31", "33", "75"],
                capture_output=True,
                timeout=5,
            )
        else:
            result = subprocess.run(
                ["tmux", "send-keys", "-t", pane_target, "Enter"],
                capture_output=True,
                timeout=5,
            )
        if result.returncode == 0:
            submit_method = "CSI-u" if agent == "codex" else "Enter"
            logger.info(
                f"Injected message into tmux pane {pane_target} "
                f"({len(message)} chars, agent={agent}, submit={submit_method})"
            )
            return True
        else:
            logger.warning(f"tmux send-keys Enter failed for {pane_target}")
            return False
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        logger.warning(f"tmux send-keys failed: {e}")
        return False


# ---------------------------------------------------------------------------
# Pane info
# ---------------------------------------------------------------------------


def _build_pane_info() -> list[dict]:
    """Get marker, agent type, target, and cwd for all tmux panes in one call.

    Returns list of ``{marker, agent, target, cwd}`` dicts.  Only panes with a
    non-empty ``@hivemind_pane_id`` marker are useful for relay registration.
    """
    try:
        result = subprocess.run(
            [
                "tmux",
                "list-panes",
                "-a",
                "-F",
                "#{@hivemind_pane_id}\t#{@hivemind_agent_type}\t#{session_name}:#{window_index}.#{pane_index}\t#{pane_current_path}",
            ],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return []
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return []

    panes = []
    for line in result.stdout.strip().splitlines():
        parts = line.split("\t")
        if len(parts) >= 3:
            panes.append(
                {
                    "marker": parts[0] if parts[0] else None,
                    "agent": parts[1] if parts[1] else "claude",
                    "target": parts[2],
                    "cwd": parts[3] if len(parts) > 3 and parts[3] else None,
                }
            )
    return panes


def get_marked_panes() -> list[dict]:
    """Return only panes that have a ``@hivemind_pane_id`` marker.

    Each dict has ``marker``, ``agent``, ``target``.
    """
    return [p for p in _build_pane_info() if p["marker"]]


# ---------------------------------------------------------------------------
# Backend ID computation
# ---------------------------------------------------------------------------


def github_id_from_token(token: str) -> int:
    """Extract ``github_id`` from a JWT without verifying the signature.

    The daemon already trusts its own stored token so we just need the
    payload claim.  Falls back to hashing the ``sub`` claim for SSO
    tokens that lack ``github_id``.
    """
    try:
        payload = decode_jwt_payload(token)
        gid = payload.get("github_id")
        if gid:
            return int(gid)
        # SSO tokens may not have github_id — derive a stable int from sub
        sub = payload.get("sub", "")
        if sub:
            return int(hashlib.sha256(sub.encode()).hexdigest()[:15], 16)
        return 0
    except Exception:
        return 0


def compute_backend_id(github_id: int, agent_type: str, agent_session_id: str) -> str:
    """Compute the backend's deterministic session UUID locally.

    Mirrors ``agentstream.analytics.generate_session_id`` so the daemon
    can derive backend IDs without an API call.
    """
    from agentstream.analytics import generate_session_id  # noqa: PLC0415

    return generate_session_id(github_id, agent_type, agent_session_id)


# ---------------------------------------------------------------------------
# SSE subscription + relay loop
# ---------------------------------------------------------------------------


async def relay_session(
    backend_id: str,
    pane_target: str,
    base_url: str,
    token: str,
    shutdown_event: asyncio.Event,
    agent: str = "claude",
) -> None:
    """Subscribe to backend SSE for one session and relay messages via tmux.

    Runs until *shutdown_event* is set.  Reconnects with exponential
    backoff on SSE failures.  Exits cleanly if the pane no longer exists.
    """

    subscribe_url = f"{base_url}/v1/channels/{backend_id}/subscribe"
    headers = {"Authorization": f"Bearer {token}"}

    backoff = 1.0
    max_backoff = 30.0
    # Server sends keepalives every 30s; allow margin before treating
    # the connection as stalled.
    read_timeout = 90.0

    while not shutdown_event.is_set():
        try:
            timeout = httpx.Timeout(connect=10.0, read=read_timeout, write=None, pool=None)
            async with httpx.AsyncClient(timeout=timeout) as client:
                async with client.stream("GET", subscribe_url, headers=headers) as resp:
                    if resp.status_code != 200:
                        logger.warning(
                            f"SSE connect failed for {backend_id[:8]}...: {resp.status_code}"
                        )
                        await asyncio.sleep(backoff)
                        backoff = min(backoff * 2, max_backoff)
                        continue

                    logger.info(f"Connected SSE relay for {backend_id[:8]}... → {pane_target}")
                    backoff = 1.0

                    event_type = None
                    data_lines: list[str] = []

                    async for line in resp.aiter_lines():
                        if shutdown_event.is_set():
                            return

                        if line.startswith("event: "):
                            event_type = line[7:]
                            data_lines = []
                        elif line.startswith("data: "):
                            data_lines.append(line[6:])
                        elif line == "" and event_type:
                            data = "\n".join(data_lines)

                            if event_type == "message":
                                try:
                                    msg = json.loads(data)
                                    content = msg.get("content", "")
                                    if content:
                                        inject_via_tmux(pane_target, content, agent=agent)
                                except Exception as e:
                                    logger.warning(f"Failed to relay message: {e}")

                            event_type = None
                            data_lines = []
                        elif line.startswith(":"):
                            pass  # keepalive comment

        except Exception as conn_err:
            err_name = type(conn_err).__name__
            if "ConnectError" in err_name:
                logger.debug(f"Cannot connect SSE for {backend_id[:8]}..., retrying in {backoff}s")
            else:
                logger.debug(f"SSE error for {backend_id[:8]}...: {conn_err}")

        await asyncio.sleep(backoff)
        backoff = min(backoff * 2, max_backoff)


# ---------------------------------------------------------------------------
# TmuxRelay — manages relay tasks for launched sessions
# ---------------------------------------------------------------------------


class TmuxRelay:
    """Manages SSE→tmux relay tasks for sessions started via ``hivemind alpha launch``.

    Sessions are registered explicitly (not discovered via polling).
    ``prune_exited()`` is called each daemon loop to clean up sessions whose
    pane marker has been cleared (i.e. the agent process exited and
    ``alpha launch`` ran its cleanup).
    """

    def __init__(
        self,
        base_url: str,
        token: str,
        shutdown_event: asyncio.Event,
        github_id: int,
    ):
        self.base_url = base_url
        self.token = token
        self.shutdown_event = shutdown_event
        self.github_id = github_id
        self._tasks: dict[str, asyncio.Task] = {}  # marker -> relay task
        self._pane_targets: dict[str, str] = {}  # marker -> pane target
        self._agent_types: dict[str, str] = {}  # marker -> agent type

    def update_credentials(self, base_url: str, token: str) -> None:
        """Update backend credentials (e.g. after token refresh)."""
        self.base_url = base_url
        self.token = token
        new_gid = github_id_from_token(token)
        if new_gid:
            self.github_id = new_gid

    async def register_session(
        self,
        marker: str,
        agent: str,
        pane_target: str,
    ) -> None:
        """Register a launched session and start its SSE relay.

        *marker* is the session UUID (same as ``@hivemind_pane_id`` and the
        agent's ``--session-id``).  The backend ID is computed locally from
        ``(github_id, agent, marker)``.

        Also pre-registers the session with the backend via a metadata-only
        ingest so that the subscribe endpoint and Live tab work immediately,
        even before the agent writes its first log entry.
        """
        if marker in self._tasks and not self._tasks[marker].done():
            return  # already running

        backend_id = compute_backend_id(self.github_id, agent, marker)
        self._pane_targets[marker] = pane_target
        self._agent_types[marker] = agent

        logger.info(
            f"Registering relay: {marker[:8]}... → {pane_target} (backend {backend_id[:8]}...)"
        )

        # Pre-register session with backend so subscribe/Live work immediately
        await self._pre_register(marker, agent)

        task = asyncio.create_task(
            relay_session(
                backend_id=backend_id,
                pane_target=pane_target,
                base_url=self.base_url,
                token=self.token,
                shutdown_event=self.shutdown_event,
                agent=agent,
            )
        )
        self._tasks[marker] = task

    async def _pre_register(self, marker: str, agent: str) -> None:
        """Ingest a stub entry so the backend creates the session immediately.

        This ensures the subscribe endpoint returns 200 and the session
        appears in the Live tab before the agent writes any log entries.
        A single ``RUN_STARTED`` event (entry_index 0) is enough for the
        normalization worker to create the session row.
        """

        now_ms = int(_time.time() * 1000)
        stub_entry = json.dumps(
            {
                "type": "assistant",
                "message": {
                    "id": "pre-register",
                    "type": "text",
                    "role": "assistant",
                    "content": [],
                },
                "timestamp": _time.strftime("%Y-%m-%dT%H:%M:%S.000Z", _time.gmtime()),
            }
        )
        payload = {
            "agent_session_id": marker,
            "source_format": agent,
            "metadata": {"agent_type": agent},
            "source_entries": [
                {
                    "entry_index": -2,
                    "entry_content": stub_entry,
                    "entry_timestamp_ms": now_ms,
                },
            ],
        }
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(10.0)) as client:
                resp = await client.post(
                    f"{self.base_url}/v1/ingest/sessions",
                    json=payload,
                    headers={"Authorization": f"Bearer {self.token}"},
                )
                if resp.status_code == 200:
                    logger.info(f"Pre-registered session {marker[:8]}... with backend")
                else:
                    logger.warning(f"Pre-register failed for {marker[:8]}...: {resp.status_code}")
        except Exception as e:
            logger.warning(f"Pre-register failed for {marker[:8]}...: {e}")

    async def unregister_session(self, marker: str) -> None:
        """Cancel the relay for a session and notify the backend."""
        agent_type = self._agent_types.pop(marker, "claude")
        task = self._tasks.pop(marker, None)
        self._pane_targets.pop(marker, None)
        if task and not task.done():
            task.cancel()
            try:
                await task
            except (asyncio.CancelledError, Exception):
                pass

        # Explicitly tell the backend this channel is disconnected.
        # This is more reliable than the SSE generator's finally block.
        backend_id = compute_backend_id(self.github_id, agent_type, marker)
        await self._notify_disconnect(backend_id)

    async def _notify_disconnect(self, backend_id: str) -> None:
        """Call DELETE /v1/channels/{id} to clean up server-side state."""

        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(5.0)) as client:
                resp = await client.delete(
                    f"{self.base_url}/v1/channels/{backend_id}",
                    headers={"Authorization": f"Bearer {self.token}"},
                )
                if resp.status_code == 200:
                    logger.info(f"Notified backend of disconnect for {backend_id[:8]}...")
        except Exception as e:
            logger.debug(f"Disconnect notify failed for {backend_id[:8]}...: {e}")

    async def prune_exited(self) -> int:
        """Remove relays whose tmux pane marker has been cleared.

        ``alpha launch`` clears ``@hivemind_pane_id`` when the agent exits.
        This method detects that and cancels the corresponding relay task.

        Returns the number of relays pruned.
        """
        if not self._tasks:
            return 0

        live_markers = {p["marker"] for p in get_marked_panes()}
        exited = [m for m in self._tasks if m not in live_markers]

        for marker in exited:
            logger.info(f"Pruning exited relay: {marker[:8]}...")
            await self.unregister_session(marker)

        return len(exited)

    async def stop(self) -> None:
        """Cancel all relay tasks and notify the backend of disconnects."""
        # Notify backend for each active session before cancelling tasks
        for marker in list(self._tasks):
            agent_type = self._agent_types.get(marker, "claude")
            backend_id = compute_backend_id(self.github_id, agent_type, marker)
            await self._notify_disconnect(backend_id)

        for task in self._tasks.values():
            task.cancel()
        if self._tasks:
            await asyncio.gather(*self._tasks.values(), return_exceptions=True)
        self._tasks.clear()
        self._pane_targets.clear()
        self._agent_types.clear()

    @property
    def active_count(self) -> int:
        """Number of active relay tasks."""
        return sum(1 for t in self._tasks.values() if not t.done())
