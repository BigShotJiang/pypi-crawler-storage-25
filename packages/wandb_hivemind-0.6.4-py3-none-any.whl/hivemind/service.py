"""Cross-platform daemon service management.

Provides start/stop/restart/status operations using the best available
service manager for the current platform:
1. Homebrew services (macOS and Linux Homebrew installs)
2. systemd user services (Linux with systemd)
3. Direct process management (universal fallback)
"""

from __future__ import annotations

import json
import logging
import os
import plistlib
import shutil
import signal
import subprocess
import sys
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from hivemind.config import get_endpoint_override
from hivemind.install_channels import CHANNELS, get_channel
from hivemind.logging_config import DEFAULT_LOG_FILE
from hivemind.state import DEFAULT_STATE_DIR, find_daemon_pid, is_daemon_running

logger = logging.getLogger(__name__)


@dataclass
class ServiceStatus:
    """Status of the daemon service."""

    running: bool
    pid: int | None = None
    uptime: str | None = None
    method: str = "unknown"
    service_name: str | None = None
    brew_desync: bool = False
    # Supervisor reports running but the daemon lock isn't held — worker
    # crashed or is stuck restarting (e.g. dev-mode hupper import failure).
    lock_unheld: bool = False


class ServicePlatform(Enum):
    """Available service management platforms."""

    HOMEBREW = "homebrew"
    LAUNCHD = "launchd"
    SYSTEMD = "systemd"
    DIRECT = "direct"


def _format_uptime(seconds: float) -> str:
    """Format seconds into a human-readable uptime string."""
    seconds = int(seconds)
    if seconds < 60:
        return f"{seconds}s"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes}m {seconds % 60}s"
    hours = minutes // 60
    remaining_min = minutes % 60
    if hours < 24:
        return f"{hours}h {remaining_min}m"
    days = hours // 24
    remaining_hours = hours % 24
    return f"{days}d {remaining_hours}h"


def detect_platform() -> ServicePlatform:
    """Detect the best available service management platform.

    Checks in order:
    1. Homebrew: brew services is the active supervisor for the formula
    2. launchd: a per-user LaunchAgent exists at the canonical path
       (pkg / cask / install-service / curl|sh path)
    3. systemd: systemctl available and unit file exists
    4. Direct: universal fallback
    """
    if _is_homebrew_available():
        return ServicePlatform.HOMEBREW

    if sys.platform == "darwin" and _DARWIN_USER_PLIST.exists():
        return ServicePlatform.LAUNCHD

    if _is_systemd_available():
        return ServicePlatform.SYSTEMD

    return ServicePlatform.DIRECT


_DARWIN_USER_PLIST = Path.home() / "Library" / "LaunchAgents" / "com.wandb.hivemind.plist"
_DARWIN_LAUNCHD_LABEL = "com.wandb.hivemind"


def _preferred_install_method() -> str:
    """Highest-priority install channel present on disk, or "unknown".

    Disk-based, unlike `_macos_active_supervisor()` which reads the
    currently-loaded LaunchAgent. `get_service_manager()` uses this to
    pick a manager before anything is bootstrapped — so a fresh
    pkg/uv-tool install can `hivemind start` without a separate
    install-service step.
    """
    if sys.platform != "darwin":
        return "unknown"
    return next((c.name for c in CHANNELS if c.is_installed()), "unknown")


def _render_launch_agent_plist(binary_path: Path) -> str:
    """Per-user LaunchAgent plist body. Mirrors cask postflight / pkg
    postinstall / `hivemind install-service` so takeover is a no-op."""
    log_dir = Path.home() / "Library" / "Logs" / "hivemind"
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" '
        '"http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
        '<plist version="1.0">\n'
        "<dict>\n"
        "    <key>Label</key>\n"
        f"    <string>{_DARWIN_LAUNCHD_LABEL}</string>\n"
        "    <key>ProgramArguments</key>\n"
        "    <array>\n"
        f"        <string>{binary_path}</string>\n"
        "        <string>run</string>\n"
        "    </array>\n"
        "    <key>RunAtLoad</key>\n"
        "    <true/>\n"
        "    <key>KeepAlive</key>\n"
        "    <true/>\n"
        "    <key>StandardOutPath</key>\n"
        f"    <string>{log_dir}/hivemind.out.log</string>\n"
        "    <key>StandardErrorPath</key>\n"
        f"    <string>{log_dir}/hivemind.err.log</string>\n"
        "</dict>\n"
        "</plist>\n"
    )


def _macos_active_supervisor() -> str | None:
    """Identify which install channel currently owns the per-user LaunchAgent.

    macOS has a single launchd label slot (``com.wandb.hivemind`` in the
    user's ``gui/<UID>`` domain), so whichever channel last bootstrapped
    wins. The plist's ``ProgramArguments`` reveals which binary that
    channel drops on disk, which we map back to a channel name.

    Returns the name of any registered channel (``"pkg"``, ``"script"``,
    ``"brew-cask"``, ``"brew"``, ``"uv-tool"``), ``"launchd"`` (a known
    plist whose binary we don't recognise), or ``None`` if no per-user
    plist exists.

    Walks every channel against the plist's *unresolved* binary first —
    ``~/.local/bin/hivemind`` is the cross-channel canonical symlink and
    ``.resolve()`` would walk it into whichever channel owns the target,
    losing the script/uv-tool distinction. Only when no channel claims
    the unresolved path do we resolve symlinks and try again.
    """
    if not _DARWIN_USER_PLIST.exists():
        return None
    try:
        with _DARWIN_USER_PLIST.open("rb") as f:
            data = plistlib.load(f)
    except (OSError, plistlib.InvalidFileException, ValueError):
        return None
    args = data.get("ProgramArguments") or []
    if not args:
        return None
    binary = str(args[0])

    for c in CHANNELS:
        if c.match_unresolved(binary):
            return c.name

    try:
        resolved = str(Path(binary).resolve())
    except (OSError, ValueError):
        resolved = binary
    for c in CHANNELS:
        if c.match_resolved(resolved):
            return c.name

    return "launchd"


def _is_homebrew_available() -> bool:
    """Check if hivemind is currently managed by Homebrew services.

    A formula on disk isn't enough: pkg/cask installs share the
    ``com.wandb.hivemind`` launchd label and follow a "last writer
    wins" policy, so a coexisting formula can leave its files behind
    while the .pkg's per-user LaunchAgent is what's actually running.
    On macOS we only treat brew as the supervisor when the active
    plist points at a brew-installed binary, OR when no plist is
    loaded yet (fresh formula install that hasn't been started).
    """
    brew_path = shutil.which("brew")
    if not brew_path:
        return False

    if sys.platform == "darwin":
        active = _macos_active_supervisor()
        if active is not None and active != "brew":
            return False

    # Check if our formula is installed
    try:
        result = subprocess.run(
            ["brew", "list", "wandb/taps/hivemind"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return False


def _is_systemd_available() -> bool:
    """Check if systemd user services are available with our unit file."""
    unit_path = Path.home() / ".config" / "systemd" / "user" / "hivemind.service"
    if not unit_path.exists():
        return False

    try:
        result = subprocess.run(
            ["systemctl", "--user", "show-environment"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return False


class ServiceManager(ABC):
    """Abstract base class for service managers."""

    @abstractmethod
    def start(self, **kwargs: object) -> tuple[bool, str]:
        """Start the daemon service.

        Returns:
            Tuple of (success, message).
        """

    @abstractmethod
    def stop(self, force: bool = False) -> tuple[bool, str]:
        """Stop the daemon service.

        Args:
            force: If True, forcefully kill the process.

        Returns:
            Tuple of (success, message).
        """

    @abstractmethod
    def restart(self, **kwargs: object) -> tuple[bool, str]:
        """Restart the daemon service.

        Returns:
            Tuple of (success, message).
        """

    @abstractmethod
    def status(self) -> ServiceStatus:
        """Get the current service status.

        Returns:
            ServiceStatus with current state information.
        """


class HomebrewServiceManager(ServiceManager):
    """Manage the daemon via Homebrew services."""

    FORMULA = "wandb/taps/hivemind"

    def __init__(self, state_dir: Path | None = None) -> None:
        self.state_dir = state_dir or DEFAULT_STATE_DIR

    def start(self, **kwargs: object) -> tuple[bool, str]:
        try:
            result = subprocess.run(
                ["brew", "services", "start", self.FORMULA],
                capture_output=True,
                text=True,
                timeout=10,
            )
            output = (result.stdout + result.stderr).strip()
            if result.returncode == 0:
                return True, output or f"Started {self.FORMULA} via Homebrew services"
            return False, output or f"Failed to start {self.FORMULA}"
        except subprocess.TimeoutExpired:
            return False, "Timed out starting Homebrew service"
        except (FileNotFoundError, OSError) as e:
            return False, f"Failed to run brew: {e}"

    def stop(self, force: bool = False) -> tuple[bool, str]:
        try:
            result = subprocess.run(
                ["brew", "services", "stop", self.FORMULA],
                capture_output=True,
                text=True,
                timeout=10,
            )
            output = (result.stdout + result.stderr).strip()
            if result.returncode == 0:
                return True, output or f"Stopped {self.FORMULA} via Homebrew services"
            return False, output or f"Failed to stop {self.FORMULA}"
        except subprocess.TimeoutExpired:
            return False, "Timed out stopping Homebrew service"
        except (FileNotFoundError, OSError) as e:
            return False, f"Failed to run brew: {e}"

    def restart(self, **kwargs: object) -> tuple[bool, str]:
        try:
            result = subprocess.run(
                ["brew", "services", "restart", self.FORMULA],
                capture_output=True,
                text=True,
                timeout=10,
            )
            output = (result.stdout + result.stderr).strip()
            if result.returncode == 0:
                return True, output or f"Restarted {self.FORMULA} via Homebrew services"
            return False, output or f"Failed to restart {self.FORMULA}"
        except subprocess.TimeoutExpired:
            return False, "Timed out restarting Homebrew service"
        except (FileNotFoundError, OSError) as e:
            return False, f"Failed to run brew: {e}"

    def status(self) -> ServiceStatus:
        running = False
        pid = None
        try:
            result = subprocess.run(
                ["brew", "services", "info", self.FORMULA, "--json"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip():
                data = json.loads(result.stdout)
                # brew services info --json returns a list
                info = data[0] if isinstance(data, list) else data
                running = info.get("status") == "started"
                pid = info.get("pid")
            else:
                # brew command ran but returned non-zero or empty output
                running = is_daemon_running(self.state_dir)
                pid = find_daemon_pid(self.state_dir) if running else None
        except (
            subprocess.TimeoutExpired,
            FileNotFoundError,
            OSError,
            json.JSONDecodeError,
            KeyError,
            IndexError,
        ):
            # Fallback: use lock-file detection
            running = is_daemon_running(self.state_dir)
            pid = find_daemon_pid(self.state_dir) if running else None

        # Cross-check: brew may report "stopped" while the daemon is actually
        # running (e.g., brew service state got out of sync after a crash or
        # manual restart).  Trust the lock file as ground truth.
        brew_desync = False
        if not running and is_daemon_running(self.state_dir):
            running = True
            brew_desync = True
            pid = pid or find_daemon_pid(self.state_dir)

        # Inverse desync: brew says running but the lock isn't held —
        # supervisor up, worker crashed (e.g. dev-mode hupper).
        lock_unheld = bool(running and not brew_desync and not is_daemon_running(self.state_dir))

        uptime = _uptime_from_pid(pid) if running and pid else None
        return ServiceStatus(
            running=running,
            pid=pid,
            uptime=uptime,
            method="homebrew",
            service_name=self.FORMULA,
            brew_desync=brew_desync,
            lock_unheld=lock_unheld,
        )


class SystemdServiceManager(ServiceManager):
    """Manage the daemon via systemd user services."""

    UNIT = "hivemind.service"

    def __init__(self, state_dir: Path | None = None) -> None:
        self.state_dir = state_dir or DEFAULT_STATE_DIR

    def start(self, **kwargs: object) -> tuple[bool, str]:
        try:
            result = subprocess.run(
                ["systemctl", "--user", "start", self.UNIT],
                capture_output=True,
                text=True,
                timeout=10,
            )
            output = (result.stdout + result.stderr).strip()
            if result.returncode == 0:
                return True, output or f"Started {self.UNIT} via systemd"
            return False, output or f"Failed to start {self.UNIT}"
        except subprocess.TimeoutExpired:
            return False, "Timed out starting systemd service"
        except (FileNotFoundError, OSError) as e:
            return False, f"Failed to run systemctl: {e}"

    def stop(self, force: bool = False) -> tuple[bool, str]:
        try:
            result = subprocess.run(
                ["systemctl", "--user", "stop", self.UNIT],
                capture_output=True,
                text=True,
                timeout=10,
            )
            output = (result.stdout + result.stderr).strip()
            if result.returncode == 0:
                return True, output or f"Stopped {self.UNIT} via systemd"
            return False, output or f"Failed to stop {self.UNIT}"
        except subprocess.TimeoutExpired:
            return False, "Timed out stopping systemd service"
        except (FileNotFoundError, OSError) as e:
            return False, f"Failed to run systemctl: {e}"

    def restart(self, **kwargs: object) -> tuple[bool, str]:
        try:
            result = subprocess.run(
                ["systemctl", "--user", "restart", self.UNIT],
                capture_output=True,
                text=True,
                timeout=10,
            )
            output = (result.stdout + result.stderr).strip()
            if result.returncode == 0:
                return True, output or f"Restarted {self.UNIT} via systemd"
            return False, output or f"Failed to restart {self.UNIT}"
        except subprocess.TimeoutExpired:
            return False, "Timed out restarting systemd service"
        except (FileNotFoundError, OSError) as e:
            return False, f"Failed to run systemctl: {e}"

    def status(self) -> ServiceStatus:
        try:
            result = subprocess.run(
                [
                    "systemctl",
                    "--user",
                    "show",
                    self.UNIT,
                    "--property=ActiveState,MainPID,ExecMainStartTimestamp",
                ],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                props: dict[str, str] = {}
                for line in result.stdout.strip().splitlines():
                    if "=" in line:
                        key, _, value = line.partition("=")
                        props[key.strip()] = value.strip()

                running = props.get("ActiveState") == "active"
                pid_str = props.get("MainPID", "0")
                pid = int(pid_str) if pid_str and pid_str != "0" else None

                uptime = None
                start_ts = props.get("ExecMainStartTimestamp", "")
                if running and start_ts:
                    try:
                        # systemd returns timestamps like "Mon 2024-01-15 10:30:00 PST"
                        # Use subprocess to get epoch seconds for reliability
                        ts_result = subprocess.run(
                            [
                                "systemctl",
                                "--user",
                                "show",
                                self.UNIT,
                                "--property=ExecMainStartTimestampMonotonic",
                            ],
                            capture_output=True,
                            text=True,
                            timeout=5,
                        )
                        if ts_result.returncode == 0:
                            for ts_line in ts_result.stdout.strip().splitlines():
                                if "=" in ts_line:
                                    _, _, ts_val = ts_line.partition("=")
                                    mono_usec = int(ts_val.strip())
                                    if mono_usec > 0:
                                        # mono_usec is ExecMainStartTimestampMonotonic (CLOCK_MONOTONIC
                                        # at service start, in microseconds). Subtract from current
                                        # monotonic time to get elapsed seconds since start.
                                        uptime_sec = mono_usec / 1_000_000
                                        uptime = _format_uptime(time.monotonic() - uptime_sec)
                    except (ValueError, OSError):
                        pass

                # systemd says active but the lock isn't held — worker crashed.
                lock_unheld = bool(running and not is_daemon_running(self.state_dir))

                return ServiceStatus(
                    running=running,
                    pid=pid,
                    uptime=uptime,
                    method="systemd",
                    service_name=self.UNIT,
                    lock_unheld=lock_unheld,
                )
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            pass

        return ServiceStatus(running=False, method="systemd", service_name=self.UNIT)


class DirectServiceManager(ServiceManager):
    """Manage the daemon as a direct background process."""

    def __init__(self, state_dir: Path | None = None) -> None:
        self.state_dir = state_dir or DEFAULT_STATE_DIR

    def start(self, **kwargs: object) -> tuple[bool, str]:
        if is_daemon_running(self.state_dir):
            pid = find_daemon_pid(self.state_dir)
            return True, f"Daemon is already running (PID {pid})"

        # Find the hivemind executable
        exe = shutil.which("hivemind")
        if not exe:
            # Try using the current Python interpreter's entry point
            exe = shutil.which("hivemind", path=str(Path(sys.executable).parent))
        if not exe:
            return False, "Cannot find 'hivemind' executable on PATH"

        # Build the command
        cmd = [exe, "run"]

        # Pass through endpoint override flags
        endpoint_override = get_endpoint_override()
        if endpoint_override:
            cmd.extend(["--endpoint", endpoint_override])

        cmd.extend(["--state-dir", str(self.state_dir)])

        # Set up log file for stdout/stderr
        log_file = DEFAULT_LOG_FILE

        try:
            log_file.parent.mkdir(parents=True, exist_ok=True)
            log_fd = open(log_file, "a")

            proc = subprocess.Popen(
                cmd,
                stdout=log_fd,
                stderr=log_fd,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
            )

            # Wait briefly to check if it started successfully
            time.sleep(1.0)

            if proc.poll() is not None:
                log_fd.close()
                return False, f"Daemon exited immediately with code {proc.returncode}"

            log_fd.close()
            return True, f"Daemon started (PID {proc.pid}), logging to {log_file}"

        except OSError as e:
            return False, f"Failed to start daemon: {e}"

    def stop(self, force: bool = False) -> tuple[bool, str]:
        if not is_daemon_running(self.state_dir):
            return True, "Daemon is not running"

        pid = find_daemon_pid(self.state_dir)
        if pid is None:
            return False, "Daemon is running but PID could not be determined"

        try:
            if force:
                os.kill(pid, signal.SIGKILL)
                return True, f"Sent SIGKILL to daemon (PID {pid})"

            # Graceful shutdown with SIGTERM
            os.kill(pid, signal.SIGTERM)

            # Wait up to 10 seconds for graceful shutdown
            for _ in range(20):
                time.sleep(0.5)
                try:
                    os.kill(pid, 0)
                except ProcessLookupError:
                    return True, f"Daemon stopped (PID {pid})"

            # Process still running after timeout - force kill
            logger.warning(f"Daemon (PID {pid}) did not stop after 10s, sending SIGKILL")
            os.kill(pid, signal.SIGKILL)
            time.sleep(0.5)

            try:
                os.kill(pid, 0)
                return False, f"Failed to stop daemon (PID {pid}) even with SIGKILL"
            except ProcessLookupError:
                return True, f"Daemon force-killed (PID {pid})"

        except ProcessLookupError:
            return True, f"Daemon (PID {pid}) already stopped"
        except PermissionError:
            return False, f"No permission to stop daemon (PID {pid})"
        except OSError as e:
            return False, f"Failed to stop daemon: {e}"

    def restart(self, **kwargs: object) -> tuple[bool, str]:
        if is_daemon_running(self.state_dir):
            success, msg = self.stop()
            if not success:
                return False, f"Failed to stop daemon for restart: {msg}"
        return self.start(**kwargs)

    def status(self) -> ServiceStatus:
        running = is_daemon_running(self.state_dir)
        pid = find_daemon_pid(self.state_dir) if running else None
        uptime = _uptime_from_pid(pid) if running and pid else None

        method = "direct"
        if sys.platform == "darwin":
            active = _macos_active_supervisor()
            if active:
                method = active

        return ServiceStatus(
            running=running,
            pid=pid,
            uptime=uptime,
            method=method,
        )


class LaunchctlServiceManager(ServiceManager):
    """Manage the daemon via a per-user launchd LaunchAgent.

    Used when an install channel (pkg, hivemind-app cask, the curl|sh
    installer, or ``hivemind install-service`` for a uv-tool / dev
    install) has dropped a plist at
    ``~/Library/LaunchAgents/com.wandb.hivemind.plist``. The install
    channel normally owns that file, but ``start()`` will auto-write a
    fresh plist via ``_ensure_plist()`` if none exists yet — keyed off
    the highest-priority install channel on disk — so a fresh
    pkg/uv-tool install can ``hivemind start`` without a separate
    install-service step. Lifecycle operations go through ``launchctl
    bootstrap/bootout/kickstart`` against the user's gui domain so
    ``KeepAlive=true`` doesn't fight a SIGTERM.
    """

    LABEL = _DARWIN_LAUNCHD_LABEL

    def __init__(self, state_dir: Path | None = None, channel: str | None = None) -> None:
        self.state_dir = state_dir or DEFAULT_STATE_DIR
        self.plist_path = _DARWIN_USER_PLIST
        self._uid = os.getuid()
        # Picks the binary path when start() auto-writes a missing plist.
        # None falls back to _preferred_install_method().
        self.channel = channel

    def _domain(self) -> str:
        return f"gui/{self._uid}"

    def _service_target(self) -> str:
        return f"{self._domain()}/{self.LABEL}"

    def _ensure_plist(self) -> tuple[bool, str | None]:
        """Write a fresh plist if one isn't on disk. Returns
        ``(ok, message_to_prepend_to_success_or_None)``."""
        if self.plist_path.exists():
            return True, None
        channel = self.channel or _preferred_install_method()
        descriptor = get_channel(channel)
        binary = descriptor.binary_path() if descriptor is not None else None
        if binary is None:
            return False, (
                f"No LaunchAgent at {self.plist_path} and no install channel "
                "to bootstrap from. Reinstall hivemind (pkg / brew-cask / uv-tool) "
                "or run `hivemind install-service`."
            )
        log_dir = Path.home() / "Library" / "Logs" / "hivemind"
        try:
            log_dir.mkdir(parents=True, exist_ok=True)
            self.plist_path.parent.mkdir(parents=True, exist_ok=True)
            self.plist_path.write_text(_render_launch_agent_plist(binary))
        except OSError as e:
            return False, f"Failed to write {self.plist_path}: {e}"
        return True, f"Wrote LaunchAgent plist for {channel} install ({binary})"

    def start(self, **kwargs: object) -> tuple[bool, str]:
        ok, write_msg = self._ensure_plist()
        if not ok:
            assert write_msg is not None
            return False, write_msg
        try:
            result = subprocess.run(
                ["launchctl", "bootstrap", self._domain(), str(self.plist_path)],
                capture_output=True,
                text=True,
                timeout=10,
            )
            output = (result.stdout + result.stderr).strip()
            if result.returncode == 0:
                msg = output or f"Bootstrapped {self.LABEL}"
                return True, f"{write_msg}\n{msg}" if write_msg else msg
            # bootstrap is not idempotent — retrying when already loaded
            # returns 17 ("Bootstrap failed: 5: Input/output error" or
            # "service already loaded"). Treat already-loaded as success.
            lower = output.lower()
            if "already loaded" in lower or "service already" in lower:
                msg = "Daemon already loaded."
                return True, f"{write_msg}\n{msg}" if write_msg else msg
            return False, output or f"launchctl bootstrap failed (exit {result.returncode})"
        except subprocess.TimeoutExpired:
            return False, "Timed out running launchctl bootstrap"
        except (FileNotFoundError, OSError) as e:
            return False, f"Failed to run launchctl: {e}"

    def stop(self, force: bool = False) -> tuple[bool, str]:
        # bootout removes the agent entirely so KeepAlive doesn't restart it.
        # `force` is honored by sending SIGKILL to any survivor after bootout.
        if not self.plist_path.exists():
            # No plist to bootout — fall back to direct kill so a stray
            # process doesn't leak when the install was uninstalled.
            return DirectServiceManager(self.state_dir).stop(force=force)
        try:
            result = subprocess.run(
                ["launchctl", "bootout", self._domain(), str(self.plist_path)],
                capture_output=True,
                text=True,
                timeout=15,
            )
            output = (result.stdout + result.stderr).strip()
            if result.returncode == 0:
                msg = output or f"Booted out {self.LABEL}"
            else:
                lower = output.lower()
                if "could not find" in lower or "not currently loaded" in lower:
                    msg = "Daemon was not loaded."
                else:
                    return False, output or f"launchctl bootout failed (exit {result.returncode})"
        except subprocess.TimeoutExpired:
            return False, "Timed out running launchctl bootout"
        except (FileNotFoundError, OSError) as e:
            return False, f"Failed to run launchctl: {e}"

        if force:
            pid = find_daemon_pid(self.state_dir)
            if pid is not None:
                try:
                    os.kill(pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                except (PermissionError, OSError):
                    pass

        return True, msg

    def restart(self, **kwargs: object) -> tuple[bool, str]:
        # `launchctl kickstart -k` restarts the service in place — preferred
        # because it leaves the agent loaded and keeps KeepAlive semantics.
        # Falls back to bootout+bootstrap if the agent isn't loaded yet.
        try:
            result = subprocess.run(
                ["launchctl", "kickstart", "-k", self._service_target()],
                capture_output=True,
                text=True,
                timeout=15,
            )
            if result.returncode == 0:
                output = (result.stdout + result.stderr).strip()
                return True, output or f"Restarted {self.LABEL}"
            # Service not loaded — fall through to stop+start.
        except subprocess.TimeoutExpired:
            return False, "Timed out running launchctl kickstart"
        except (FileNotFoundError, OSError) as e:
            return False, f"Failed to run launchctl: {e}"

        stop_ok, stop_msg = self.stop()
        if not stop_ok:
            return False, f"restart: {stop_msg}"
        return self.start(**kwargs)

    def status(self) -> ServiceStatus:
        running = is_daemon_running(self.state_dir)
        pid = find_daemon_pid(self.state_dir) if running else None
        uptime = _uptime_from_pid(pid) if running and pid else None

        method = _macos_active_supervisor() or "launchd"

        return ServiceStatus(
            running=running,
            pid=pid,
            uptime=uptime,
            method=method,
        )


def _uptime_from_pid(pid: int) -> str | None:
    """Get human-readable uptime for a process by PID using ps."""
    try:
        result = subprocess.run(
            ["ps", "-o", "etime=", "-p", str(pid)],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return _parse_ps_etime(result.stdout.strip())
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass
    return None


def _parse_ps_etime(etime: str) -> str | None:
    """Parse ps elapsed time format into human-readable uptime.

    ps etime formats: "MM:SS", "HH:MM:SS", "D-HH:MM:SS"
    """
    etime = etime.strip()
    if not etime:
        return None

    try:
        days = 0
        if "-" in etime:
            day_part, etime = etime.split("-", 1)
            days = int(day_part)

        parts = etime.split(":")
        if len(parts) == 2:
            minutes, seconds = int(parts[0]), int(parts[1])
            total_seconds = days * 86400 + minutes * 60 + seconds
        elif len(parts) == 3:
            hours, minutes, seconds = int(parts[0]), int(parts[1]), int(parts[2])
            total_seconds = days * 86400 + hours * 3600 + minutes * 60 + seconds
        else:
            return etime  # Return as-is if unparseable

        return _format_uptime(total_seconds)
    except (ValueError, IndexError):
        return etime


def get_service_manager(state_dir: Path | None = None) -> ServiceManager:
    """Return the right service manager for this platform / install channel.

    macOS: dispatches by `_preferred_install_method()` precedence. brew
    formula → HomebrewServiceManager (uses `brew services`); the
    launchd-managed channels (pkg / script / brew-cask / uv-tool) →
    LaunchctlServiceManager, which auto-writes a plist on first start.
    Falls back to `detect_platform()` for "unknown" so existing plists
    and Linux still work.
    """
    if sys.platform == "darwin":
        method = _preferred_install_method()
        if method == "brew":
            return HomebrewServiceManager(state_dir=state_dir)
        if method in ("pkg", "script", "brew-cask", "uv-tool"):
            return LaunchctlServiceManager(state_dir=state_dir, channel=method)
        # "unknown" falls through so an existing manual-install-service plist
        # is still picked up by detect_platform()'s LAUNCHD branch.

    platform = detect_platform()

    if platform == ServicePlatform.HOMEBREW:
        return HomebrewServiceManager(state_dir=state_dir)
    elif platform == ServicePlatform.LAUNCHD:
        return LaunchctlServiceManager(state_dir=state_dir)
    elif platform == ServicePlatform.SYSTEMD:
        return SystemdServiceManager(state_dir=state_dir)
    else:
        return DirectServiceManager(state_dir=state_dir)
