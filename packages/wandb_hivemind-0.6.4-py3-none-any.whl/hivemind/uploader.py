"""HTTP client for uploading events to backend."""

from __future__ import annotations

import asyncio
import gzip
import json
import logging
import time
from dataclasses import dataclass
from typing import Any

import httpx
from agentstream.git_utils import sanitize_git_url
from pydantic import BaseModel

from hivemind import __version__
from hivemind.config import get_base_endpoint
from hivemind.redactor import redact_dict_counted, redact_secrets_counted

logger = logging.getLogger(__name__)


def _track(event_name: str, properties: dict) -> None:
    """Lazy-import telemetry.track to avoid circular import. Never throws."""
    try:
        from hivemind.telemetry import track  # noqa: PLC0415

        track(event_name, properties)
    except Exception:
        pass


@dataclass
class UploadResult:
    """Result of an upload operation."""

    success: bool
    needs_token_refresh: bool = False
    sso_required: bool = False
    sso_org_id: str = ""


@dataclass
class HeartbeatResult:
    """Result of a daemon heartbeat ping.

    `ok=True` means the server replied 2xx with the current credentials —
    a positive proof of auth health that the daemon uses to clear any
    stale `last_auth_error` from `state.json`. `sso_required=True` means
    the server explicitly rejected the heartbeat with the SSO upgrade
    code; the daemon enters its pause-and-poll state immediately
    instead of waiting for the next sync cycle to discover the
    rejection. `needs_token_refresh=True` means the token should be
    refreshed — either the server signaled it via the
    X-AgentStream-Refresh-Token header, or the request was rejected
    with 401 and the credentials are old enough to warrant a retry.
    """

    ok: bool
    sso_required: bool = False
    sso_org_id: str = ""
    needs_token_refresh: bool = False


def get_user_agent() -> str:
    """Build User-Agent header with daemon version."""
    return f"hivemind/{__version__}"


class SourceEntryInput(BaseModel):
    """Source entry for server-side normalization."""

    entry_index: int
    entry_content: str  # Raw JSON string
    entry_timestamp_ms: int


class SessionIngestRequest(BaseModel):
    """Request for server-side normalization ingest.

    Daemon sends raw source_entries + metadata.
    Server processes them into events in background.
    """

    agent_session_id: str
    source_format: str  # 'claude', 'codex', 'cursor', 'gemini'
    metadata: dict[str, Any]  # Daemon metadata (agent_type, version, git_*, etc.)
    source_entries: list[SourceEntryInput]
    secrets_redacted_count: int = 0  # Number of secrets redacted in this batch


# Legacy models for backward compatibility
class SessionBatch(BaseModel):
    """Batch of data for a single session."""

    session_id: str
    events: list[dict[str, Any]]
    source_entries: list[dict[str, Any]]
    session_summary: dict[str, Any]


class IngestBatch(BaseModel):
    """Full ingest payload."""

    device_id: str
    user_id: str
    batch: list[SessionBatch]


def _redact_entry_content(entry_content: str) -> tuple[str, int]:
    """Redact secrets inside raw entry content.

    Returns:
        Tuple of (redacted_content, number_of_secrets_redacted).
    """
    try:
        parsed = json.loads(entry_content)
    except json.JSONDecodeError:
        redacted, count = redact_secrets_counted(entry_content)
        return redacted, count
    redacted, count = redact_dict_counted(parsed)
    return json.dumps(redacted), count


def _redact_request(request: SessionIngestRequest) -> SessionIngestRequest:
    """Return a copy of request with metadata and entry content redacted.

    The returned request includes a secrets_redacted_count reflecting
    the total number of secrets redacted across metadata and all entries
    in this batch.
    """
    total_count = 0

    redacted_metadata = dict(request.metadata)
    git_repo = redacted_metadata.get("git_repo")
    if isinstance(git_repo, str):
        redacted_metadata["git_repo"] = sanitize_git_url(git_repo)
    redacted_metadata, meta_count = redact_dict_counted(redacted_metadata)
    total_count += meta_count

    redacted_entries = []
    for entry in request.source_entries:
        redacted_content, entry_count = _redact_entry_content(entry.entry_content)
        total_count += entry_count
        redacted_entries.append(
            SourceEntryInput(
                entry_index=entry.entry_index,
                entry_content=redacted_content,
                entry_timestamp_ms=entry.entry_timestamp_ms,
            )
        )

    return SessionIngestRequest(
        agent_session_id=request.agent_session_id,
        source_format=request.source_format,
        metadata=redacted_metadata,
        source_entries=redacted_entries,
        secrets_redacted_count=total_count,
    )


class Uploader:
    """Upload events to AgentStream backend."""

    # Credentials older than this can trigger auto-refresh on 401
    AUTH_REFRESH_MIN_AGE_SECONDS = 3600  # 1 hour

    def __init__(
        self,
        endpoint: str,
        auth_token: str | None = None,
        credential_created_at: int | None = None,
        cert_path: str | None = None,
        key_path: str | None = None,
        ca_path: str | None = None,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        timeout: float = 30.0,
    ):
        self.endpoint = endpoint
        self.auth_token = auth_token
        self.credential_created_at = credential_created_at
        self.cert_path = cert_path
        self.key_path = key_path
        self.ca_path = ca_path
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.timeout = timeout

    def _get_ssl_context(self) -> httpx.Limits | None:
        """Build SSL context for mTLS if certs provided."""
        if not self.cert_path:
            return None

        # httpx handles cert/key via the cert parameter
        return None

    async def upload(self, batch: IngestBatch) -> bool:
        """Upload batch with retry logic (legacy endpoint)."""
        cert = None
        if self.cert_path and self.key_path:
            cert = (self.cert_path, self.key_path)
        elif self.cert_path:
            cert = self.cert_path

        # Build headers with auth if token provided
        headers = {
            "Content-Type": "application/json",
            "User-Agent": get_user_agent(),
        }
        if self.auth_token:
            headers["Authorization"] = f"Bearer {self.auth_token}"

        for attempt in range(self.max_retries):
            try:
                async with httpx.AsyncClient(
                    cert=cert,
                    verify=self.ca_path or True,
                    timeout=self.timeout,
                ) as client:
                    response = await client.post(
                        self.endpoint,
                        json=batch.model_dump(),
                        headers=headers,
                    )

                    if response.status_code == 200:
                        logger.info(f"Upload successful: {len(batch.batch)} sessions")
                        return True

                    logger.warning(
                        f"Upload failed (attempt {attempt + 1}/{self.max_retries}): "
                        f"status={response.status_code}"
                    )

            except httpx.RequestError as e:
                logger.warning(f"Upload error (attempt {attempt + 1}/{self.max_retries}): {e}")

            if attempt < self.max_retries - 1:
                await asyncio.sleep(self.retry_delay * (2**attempt))

        logger.error(f"Upload failed after {self.max_retries} attempts")
        return False

    async def upload_session(self, request: SessionIngestRequest) -> UploadResult:
        """Upload session for server-side normalization.

        Uses gzip compression for large payloads (>100KB) to reduce
        network transfer time significantly (JSON compresses ~10:1).

        Args:
            request: SessionIngestRequest with source_entries and metadata.

        Returns:
            UploadResult with success status and token refresh signal.
        """
        cert = None
        if self.cert_path and self.key_path:
            cert = (self.cert_path, self.key_path)
        elif self.cert_path:
            cert = self.cert_path

        # Payload prep errors (pydantic, json, gzip) aren't retryable.
        try:
            redacted_request = _redact_request(request)
            json_bytes = json.dumps(redacted_request.model_dump()).encode("utf-8")
            if len(json_bytes) > 100 * 1024:
                body = gzip.compress(json_bytes, compresslevel=6)
                headers = {
                    "Content-Type": "application/json",
                    "Content-Encoding": "gzip",
                    "User-Agent": get_user_agent(),
                }
                logger.debug(
                    f"Compressed {len(json_bytes) / 1024:.0f}KB -> {len(body) / 1024:.0f}KB "
                    f"({len(body) / len(json_bytes) * 100:.0f}%)"
                )
            else:
                body = json_bytes
                headers = {
                    "Content-Type": "application/json",
                    "User-Agent": get_user_agent(),
                }
        except Exception as e:
            logger.error(
                f"Failed to prepare upload payload for "
                f"{request.agent_session_id[:20]}... ({type(e).__name__}): {e}"
            )
            _track(
                "daemon.upload_failed",
                {
                    "status_code": 0,
                    "error_type": "payload_prep_failed",
                },
            )
            return UploadResult(success=False)

        if self.auth_token:
            headers["Authorization"] = f"Bearer {self.auth_token}"

        for attempt in range(self.max_retries):
            try:
                async with httpx.AsyncClient(
                    cert=cert,
                    verify=self.ca_path or True,
                    timeout=self.timeout,
                ) as client:
                    # Wrap the HTTP request in an overall timeout to prevent
                    # indefinite hangs when the server holds the connection open
                    # or a proxy trickles data that resets httpx's per-phase timeout.
                    response = await asyncio.wait_for(
                        client.post(
                            self.endpoint,
                            content=body,
                            headers=headers,
                        ),
                        timeout=self.timeout * 3,  # 90s hard cap per attempt
                    )

                    if response.status_code == 200:
                        logger.info(
                            f"Upload successful: session {redacted_request.agent_session_id[:20]}..."
                        )
                        # Check for token refresh signal from server
                        needs_refresh = (
                            response.headers.get("X-AgentStream-Refresh-Token", "").lower()
                            == "true"
                        )
                        if needs_refresh:
                            logger.info("Server signaled token refresh needed")
                        return UploadResult(success=True, needs_token_refresh=needs_refresh)

                    # 401 = token rejected, don't retry
                    # Signal refresh only if credentials are old enough (avoid death loop)
                    if response.status_code == 401:
                        creds_age = (
                            time.time() - self.credential_created_at
                            if self.credential_created_at
                            else float("inf")
                        )
                        if creds_age > self.AUTH_REFRESH_MIN_AGE_SECONDS:
                            logger.warning(
                                f"Auth rejected (401), credentials are {creds_age / 3600:.1f}h old, "
                                "signaling refresh"
                            )
                            _track(
                                "daemon.upload_failed",
                                {
                                    "status_code": 401,
                                    "error_type": "auth",
                                },
                            )
                            return UploadResult(success=False, needs_token_refresh=True)
                        else:
                            logger.warning(
                                f"Auth rejected (401) but credentials are only {creds_age / 60:.0f}m old. "
                                "Not signaling refresh (may be permanent auth issue)."
                            )
                            _track(
                                "daemon.upload_failed",
                                {
                                    "status_code": 401,
                                    "error_type": "auth_permanent",
                                },
                            )
                            return UploadResult(success=False)

                    if response.status_code == 403:
                        try:
                            response_body = response.json()
                        except Exception:
                            response_body = {}
                        if response_body.get("code") == "sso_required":
                            logger.warning("Organization requires SSO authentication")
                            _track(
                                "daemon.upload_failed",
                                {
                                    "status_code": 403,
                                    "error_type": "sso_required",
                                },
                            )
                            return UploadResult(
                                success=False,
                                sso_required=True,
                                sso_org_id=response_body.get("org_id", ""),
                            )
                        _track(
                            "daemon.upload_failed",
                            {
                                "status_code": 403,
                                "error_type": "forbidden",
                            },
                        )
                        return UploadResult(success=False)

                    # Non-401/403 4xx is deterministic — don't burn retries.
                    if 400 <= response.status_code < 500:
                        snippet = response.text[:200] if response.text else ""
                        logger.error(
                            f"Upload rejected by server (status={response.status_code}, "
                            f"non-retryable): {snippet}"
                        )
                        _track(
                            "daemon.upload_failed",
                            {
                                "status_code": response.status_code,
                                "error_type": "client_error",
                            },
                        )
                        return UploadResult(success=False)

                    logger.warning(
                        f"Upload failed (attempt {attempt + 1}/{self.max_retries}): "
                        f"status={response.status_code}"
                    )

            except asyncio.TimeoutError:
                logger.warning(
                    f"Upload timed out (attempt {attempt + 1}/{self.max_retries}): "
                    f"exceeded {self.timeout * 3:.0f}s hard cap"
                )
            except httpx.RequestError as e:
                logger.warning(f"Upload error (attempt {attempt + 1}/{self.max_retries}): {e}")
            except OSError as e:
                # httpx can surface transient I/O as bare OSError (e.g. EBADF
                # on a recycled socket); retry rather than escape uncategorized.
                logger.warning(
                    f"Upload OS error (attempt {attempt + 1}/{self.max_retries}, "
                    f"{type(e).__name__}): {e}"
                )
            except Exception as e:
                # Unknown errors aren't retried; quarantine handles persistence.
                logger.error(
                    f"Unexpected upload error for "
                    f"{request.agent_session_id[:20]}... "
                    f"({type(e).__name__}): {e}"
                )
                _track(
                    "daemon.upload_failed",
                    {
                        "status_code": 0,
                        "error_type": "unexpected_exception",
                    },
                )
                return UploadResult(success=False)

            if attempt < self.max_retries - 1:
                await asyncio.sleep(self.retry_delay * (2**attempt))

        logger.error(f"Upload failed after {self.max_retries} attempts")
        _track(
            "daemon.upload_failed",
            {
                "status_code": 0,
                "error_type": "retries_exhausted",
            },
        )
        return UploadResult(success=False)

    async def heartbeat(self) -> "HeartbeatResult":
        """Send a heartbeat to the backend so it knows the daemon is alive.

        Single attempt, fire-and-forget. Returns a HeartbeatResult that
        distinguishes the cases the auth-health logic in the daemon
        cares about: ok (2xx), sso_required (403 with the SSO code),
        other_error (any other non-2xx, network failure, timeout, etc.).
        """
        # Derive base URL from the configured ingest endpoint. Uses the shared
        # normalization helper so heartbeat and the rest of the daemon agree on
        # what counts as a "base" endpoint, regardless of whether the user
        # configured `…`, `…/v1/ingest`, or `…/v1/ingest/sessions`.
        base = get_base_endpoint(self.endpoint)

        url = f"{base}/v1/daemon/heartbeat"
        headers = {
            "User-Agent": get_user_agent(),
        }
        if self.auth_token:
            headers["Authorization"] = f"Bearer {self.auth_token}"

        # Reuse the same mTLS / custom-CA config as upload() so environments
        # using client certs don't get heartbeat failures while uploads succeed.
        cert = None
        if self.cert_path and self.key_path:
            cert = (self.cert_path, self.key_path)
        elif self.cert_path:
            cert = self.cert_path

        try:
            async with httpx.AsyncClient(
                cert=cert,
                verify=self.ca_path or True,
                timeout=5.0,
            ) as client:
                response = await client.post(url, headers=headers)
                if 200 <= response.status_code < 300:
                    needs_refresh = (
                        response.headers.get("X-AgentStream-Refresh-Token", "").lower() == "true"
                    )
                    return HeartbeatResult(ok=True, needs_token_refresh=needs_refresh)
                if response.status_code == 401:
                    creds_age = (
                        time.time() - self.credential_created_at
                        if self.credential_created_at
                        else float("inf")
                    )
                    if creds_age > self.AUTH_REFRESH_MIN_AGE_SECONDS:
                        logger.warning(
                            "Heartbeat auth rejected (401), credentials are "
                            f"{creds_age / 3600:.1f}h old, signaling refresh"
                        )
                        return HeartbeatResult(ok=False, needs_token_refresh=True)
                    else:
                        logger.warning(
                            f"Heartbeat auth rejected (401) but credentials are only "
                            f"{creds_age / 60:.0f}m old"
                        )
                        return HeartbeatResult(ok=False)
                if response.status_code == 403:
                    try:
                        body = response.json()
                    except Exception:
                        body = {}
                    if body.get("code") == "sso_required":
                        return HeartbeatResult(
                            ok=False,
                            sso_required=True,
                            sso_org_id=body.get("org_id", ""),
                        )
                return HeartbeatResult(ok=False)
        except httpx.RequestError:
            return HeartbeatResult(ok=False)
