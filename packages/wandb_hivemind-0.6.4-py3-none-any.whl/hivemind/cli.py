"""Command-line interface for hivemind daemon."""

from __future__ import annotations

import asyncio
import contextlib
import difflib
import getpass
import json
import logging
import os
import platform
import plistlib
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import textwrap
import time
import tomllib
import uuid
from collections import Counter, OrderedDict, defaultdict
from datetime import UTC, datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

import click
import httpx

# Import remote modules from the agentstream library
from agentstream.git_utils import normalize_git_url, resolve_git_repo
from agentstream.remote import (
    WebSessionPoller,
    WebSessionsClient,
    has_claude_credentials,
    read_claude_credentials,
)
from packaging.version import Version
from rich.console import Console
from rich.table import Table
from rich.text import Text
from watchdog.events import FileCreatedEvent, FileModifiedEvent, FileSystemEventHandler
from watchdog.observers import Observer

from hivemind import __version__
from hivemind.agent import (
    _AGENT_FILENAME,
    _PLATFORM_DIRS,
    AGENT_VERSION,
    install_agent,
    uninstall_agent,
)
from hivemind.auth.credentials import CredentialStore, KeychainLockedError, StoredCredentials
from hivemind.auth.device_flow import OIDCSwitchRequested
from hivemind.auth.hardware import collect_hardware_info
from hivemind.auth.manager import AuthError, AuthManager, PermanentAuthError
from hivemind.auth.oidc import OIDCAuthError
from hivemind.auth.reauth import ReauthDecision, evaluate_reauth
from hivemind.config import (
    DEFAULT_CONFIG_PATH,
    DEV_ENDPOINT,
    DEV_WORKTREE_ENDPOINT,
    PROD_ENDPOINT,
    QA_ENDPOINT,
    UpgradeMode,
    get_base_endpoint,
    get_effective_endpoint,
    get_endpoint_override,
    get_value,
    load_config,
    set_endpoint_override,
    update_config,
    validate_dev_repo,
)
from hivemind.install_channels import CHANNELS, get_channel
from hivemind.ssl_config import configure_ssl
from hivemind.logging_config import (
    LogSource,
    configure_logging,
    get_default_log_path,
    resolve_log_source,
)

# Local web sync module (uses library's client)
from hivemind.remote.web_sync import WebSessionSyncer, sync_web_sessions
from hivemind.session_importer import (
    build_metadata_for_file,
    discover_all_sessions,
    extract_session_metadata,
    read_source_entries,
)
from hivemind.state import (
    VALID_AGENT_TYPES,
    DaemonState,
    _normalize_endpoint,
    acquire_lock,
    clear_sessions_by_agent_type,
    find_daemon_pid,
    is_daemon_running,
    load_state,
    locked_state_update,
    save_state,
)
from hivemind.upgrade_watcher import UpgradeWatcher, detect_install_method
from hivemind.sync import (
    MIN_ENTRIES_FOR_INITIAL_UPLOAD,
    QUARANTINE_FAILURE_THRESHOLD,
    SessionSyncer,
    SyncResult,
    build_composer_workspace_map,
    get_recent_cursor_composer_ids,
    repo_matches,
)
from hivemind.telemetry import flush as flush_telemetry
from hivemind.telemetry import set_paused as set_telemetry_paused
from hivemind.telemetry import track
from hivemind.triggers import check_for_triggers, create_trigger, delete_trigger
from hivemind.uploader import SessionIngestRequest, SourceEntryInput, Uploader
from hivemind.launches import LaunchRecord, check_for_launches, create_launch, delete_launch
from hivemind.pty_relay import (
    TmuxRelay,
    get_marked_panes,
    github_id_from_token,
    is_tmux_available,
)
from hivemind.watcher import (
    HotSessionTracker,
    SessionWatcher,
    get_watch_paths,
)
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
)

# Default paths
DEFAULT_STATE_DIR = Path.home() / ".hivemind"
DEFAULT_STATE_FILE = DEFAULT_STATE_DIR / "state.json"
DEFAULT_LOCK_FILE = DEFAULT_STATE_DIR / "daemon.lock"

# Subcommands that never touch the network — skip configure_ssl() so
# we don't pay the truststore keychain cost on cold-start.
_LOCAL_ONLY_SUBCOMMANDS = frozenset(
    {
        "install-service",
        "uninstall",
        "hup",
        "version",
    }
)

# Command organization for --help output
COMMAND_SECTIONS = OrderedDict(
    {
        "Daemon": [
            "start",
            "stop",
            "restart",
            "status",
            "logs",
            "doctor",
            "run",
        ],
        "Auth": ["login", "logout", "whoami"],
        "Sessions": ["import", "transcript", "search", "fork", "insights", "export"],
        "Channels": ["send", "channels"],
        "Config": ["config"],
    }
)

DEV_COMMANDS = {"hup", "resync", "web-sessions", "api", "dump"}

# Commands that are only useful on certain platforms. A command listed
# here is hidden from `--help` output on platforms not in its allow-list,
# but can still be invoked directly (the command body handles the
# "wrong platform" case explicitly).
PLATFORM_COMMANDS: dict[str, set[str]] = {
    "install-service": {"linux", "darwin"},
}


class HivemindGroup(click.Group):
    """Custom Click group that renders commands in named sections."""

    def format_commands(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        # ctx.params is empty during help rendering, so check sys.argv
        show_dev = any(arg.startswith("--dev") for arg in sys.argv)
        commands = self.list_commands(ctx)

        for section, section_cmds in COMMAND_SECTIONS.items():
            rows = []
            for name in section_cmds:
                if name not in commands:
                    continue
                # Hide platform-specific commands on other platforms
                if name in PLATFORM_COMMANDS and sys.platform not in PLATFORM_COMMANDS[name]:
                    continue
                cmd = self.get_command(ctx, name)
                if cmd is None or getattr(cmd, "hidden", False):
                    continue
                help_text = cmd.get_short_help_str(limit=150)
                rows.append((name, help_text))
            if rows:
                with formatter.section(section):
                    formatter.write_dl(rows)

        if show_dev:
            rows = []
            for name in sorted(DEV_COMMANDS):
                if name not in commands:
                    continue
                cmd = self.get_command(ctx, name)
                if cmd is None:
                    continue
                help_text = cmd.get_short_help_str(limit=150)
                rows.append((name, help_text))
            if rows:
                with formatter.section("Development"):
                    formatter.write_dl(rows)


def get_git_email() -> str:
    """Get the user's email from git config.

    Returns:
        Git email or empty string if not configured.
    """
    try:
        result = subprocess.run(
            ["git", "config", "--global", "user.email"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except (subprocess.SubprocessError, FileNotFoundError):
        pass
    return ""


def get_git_username() -> str:
    """Get the user's name from git config.

    Returns:
        Git user.name or empty string if not configured.
    """
    try:
        result = subprocess.run(
            ["git", "config", "--global", "user.name"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except (subprocess.SubprocessError, FileNotFoundError):
        pass
    return ""


def get_default_email() -> str:
    """Get the default email for user identification.

    Tries in order:
    1. Git user.email
    2. username@hostname.local (fallback)

    Returns:
        Email string.
    """
    email = get_git_email()
    if email:
        return email

    # Fallback: construct pseudo-email from username@hostname
    username = getpass.getuser()
    hostname = socket.gethostname()
    return f"{username}@{hostname}.local"


def get_default_username() -> str:
    """Get the default username for display.

    Tries in order:
    1. Git user.name
    2. System username

    Returns:
        Username string.
    """
    username = get_git_username()
    if username:
        return username
    return getpass.getuser()


def get_default_device_id() -> str:
    """Get the default device ID from hostname.

    Returns:
        Device identifier string (hostname).
    """
    return socket.gethostname()


# Logger is configured in run() for daemon mode, or uses defaults for CLI commands
logger = logging.getLogger(__name__)


def _read_worktree_marker(cwd: str) -> str | None:
    """Read a launch marker from a .hivemind/session-marker file in cwd or parents.

    Returns the marker string if found, None otherwise.
    """
    if not cwd:
        return None
    path = Path(cwd)
    # Check the cwd and up to 3 parents (worktree root is usually 0-2 levels up)
    for _ in range(4):
        marker_file = path / ".hivemind" / "session-marker"
        try:
            marker = marker_file.read_text().strip()
            if marker:
                return marker
        except OSError:
            pass
        parent = path.parent
        if parent == path:
            break
        path = parent
    return None


def _detect_source_format(file_path: Path) -> str | None:
    """Detect agent source format from file path.

    Uses library adapters for consistent detection.

    Args:
        file_path: Path to the session file.

    Returns:
        Source format string (claude, codex, cursor, gemini) or None if unknown.
    """

    from agentstream.adapters import get_adapter_for_path  # noqa: PLC0415 — mocked in tests via agentstream.adapters

    adapter = get_adapter_for_path(file_path)
    return adapter.name if adapter else None


# Maximum time (in seconds) a single session sync is allowed to take.
# This is a hard cap that aborts the entire sync attempt (entry reading +
# a single upload cycle including its internal retries). If upload retries
# alone exceed this budget the sync is cancelled mid-retry — the session
# will be retried on the next daemon cycle with a fresh timeout.
PER_SESSION_SYNC_TIMEOUT = 120

# How often to save state during bulk operations (historic import, catch-up).
# Saving after every N successful syncs prevents losing all progress if the
# daemon hangs or is killed mid-import.
BULK_SYNC_SAVE_INTERVAL = 5

# Map stored auth_method values to force_method values used by AuthManager
_AUTH_METHOD_TO_FORCE = {
    "ssh_signature": "ssh",
    "credential_helper": "credential",
    "gh_cli": "gh",
}

# Auth methods whose successful login mints a refresh_token. Any other
# method (ssh_signature, credential_helper, gh_cli) cannot do silent
# refresh — refresh_via_stored_token() would just fail. Used by the
# shared auth helpers to decide whether to try a silent refresh before
# falling back to interactive flows.
REFRESHABLE_AUTH_METHODS = frozenset({"oidc_device", "oidc_browser", "device_flow"})


def _can_refresh(creds: StoredCredentials | None) -> bool:
    """Whether *creds* satisfies every prerequisite for a silent refresh.

    Returns True iff the auth_method is one that mints refresh tokens
    AND a refresh_token + refresh_token_type are actually present. The
    server requires both to broker the IdP / GitHub token exchange in
    ``refresh_via_stored_token``.
    """
    if not creds:
        return False
    if creds.auth_method not in REFRESHABLE_AUTH_METHODS:
        return False
    return bool(creds.refresh_token) and bool(creds.refresh_token_type)


def _is_sso_user(creds: StoredCredentials | None) -> bool:
    """Whether *creds* belong to an SSO/OIDC user.

    True if the credential was issued via OIDC (auth_method starts with
    ``oidc_``) OR the server has flagged this org as SSO-enforced. Either
    signal indicates that ssh_signature / credential_helper / gh_cli would
    be rejected by the server with 403 sso_required, so those methods must
    NOT be used as fallbacks for this user — doing so silently overwrites
    their working OIDC credentials with ones that immediately fail.
    """
    if not creds:
        return False
    if creds.sso_required:
        return True
    return (creds.auth_method or "").startswith("oidc_")


def _interactive_auth_method(auth: AuthManager) -> str:
    """Return the right interactive ``force_method`` for the stored user.

    SSO/OIDC users get ``oidc_browser``, which is *not* literally "always
    open a browser" — it routes through ``AuthManager._auth_via_oidc_sso``
    which picks the best OIDC flow for the environment:

    - Local TTY: open the system browser (FastPass-friendly), fall back
      to device flow if the browser flow times out.
    - SSH session (``SSH_CLIENT`` / ``SSH_TTY`` set): skip the browser and
      go straight to device flow — the browser would open on the wrong
      machine.
    - No TTY: raise immediately so the daemon doesn't hang.

    Hardcoding ``oidc_device`` here would force device flow on every
    laptop login, defeating the FastPass UX. Hardcoding ``oidc_browser``
    on a remote SSH host would pop a browser the user can't see.

    Everyone else gets the legacy GitHub ``device`` flow. The choice is
    made from locally-stored credentials only — callers don't need
    network access.
    """
    try:
        creds = auth.store.load_raw(auth.endpoint)
    except Exception:
        creds = None
    return "oidc_browser" if _is_sso_user(creds) else "device"


def _get_preferred_methods(default_order: list[str]) -> list[str]:
    """Reorder auth methods list to try the preferred method first.

    Reads the most-recently-used auth method from the stored credentials
    for the current endpoint and maps it (e.g. 'ssh_signature') to the
    force_method value used by AuthManager (e.g. 'ssh').

    Args:
        default_order: Default ordered list of method keys (e.g., ["ssh", "credential", "gh"]).

    Returns:
        Reordered list with preferred method first.
    """
    preferred: str | None = None
    try:
        endpoint = get_base_endpoint(get_effective_endpoint())
        creds = CredentialStore().load_raw(endpoint)
        if creds:
            preferred = creds.auth_method
    except Exception:
        pass
    preferred_key = _AUTH_METHOD_TO_FORCE.get(preferred or "", preferred)
    if preferred_key and preferred_key in default_order:
        methods = list(default_order)
        methods.remove(preferred_key)
        methods.insert(0, preferred_key)
        return methods
    return default_order


def _create_syncer(
    creds: StoredCredentials,
    endpoint: str,
    state: DaemonState,
    private_sessions: bool = False,
    org_repos: list[str] | None = None,
    private_repos: list[str] | None = None,
) -> SessionSyncer:
    """Create a SessionSyncer from credentials.

    Extracts device identification from hardware info and builds
    the syncer with all required authentication details.

    Args:
        creds: Stored credentials with auth token and user info.
        endpoint: Base API endpoint URL.
        state: Daemon state for session tracking.
        private_sessions: When True, tag sessions as private (personal org only).
        org_repos: Repos always treated as non-private (eligible for org attribution).
        private_repos: Repos always treated as private (personal workspace only).

    Returns:
        Configured SessionSyncer instance.
    """
    hw = collect_hardware_info()
    device_id = hw.hardware_uuid or hw.hostname
    base = get_base_endpoint(endpoint)
    ingest_endpoint = f"{base}/v1/ingest/sessions"

    return SessionSyncer(
        state=state,
        endpoint=ingest_endpoint,
        auth_token=creds.token,
        user_id=creds.user_id,
        device_id=device_id,
        email=creds.email,
        github_user=creds.github_user,
        credential_created_at=creds.created_at,
        private_sessions=private_sessions,
        org_repos=org_repos,
        private_repos=private_repos,
    )


def _create_web_syncer(
    creds: StoredCredentials,
    endpoint: str,
    state: DaemonState,
    web_client: WebSessionsClient,
    private_sessions: bool = False,
    org_repos: list[str] | None = None,
    private_repos: list[str] | None = None,
) -> WebSessionSyncer:
    """Create a WebSessionSyncer from credentials.

    Args:
        creds: Stored credentials with auth token and user info.
        endpoint: Base API endpoint URL.
        state: Daemon state for session tracking.
        web_client: WebSessionsClient for fetching web sessions.
        private_sessions: When True, tag sessions as private (personal org only).
        org_repos: Repos always treated as non-private (eligible for org attribution).
        private_repos: Repos always treated as private (personal workspace only).

    Returns:
        Configured WebSessionSyncer instance.
    """
    hw = collect_hardware_info()
    device_id = hw.hardware_uuid or hw.hostname
    base = get_base_endpoint(endpoint)
    ingest_endpoint = f"{base}/v1/ingest/sessions"

    return WebSessionSyncer(
        state=state,
        endpoint=ingest_endpoint,
        auth_token=creds.token,
        web_client=web_client,
        user_id=creds.user_id,
        device_id=device_id,
        email=creds.email,
        github_user=creds.github_user,
        credential_created_at=creds.created_at,
        private_sessions=private_sessions,
        org_repos=org_repos,
        private_repos=private_repos,
    )


async def _try_noninteractive_auth(auth: AuthManager) -> bool:
    """Authenticate non-interactively, returning True on success.

    Strategy:
    1. If the stored credentials are refreshable (see :func:`_can_refresh`),
       try a silent refresh via the server-brokered IdP exchange. This is
       the *only* path that works for SSO-enforced orgs.
    2. If the user is SSO-bound (see :func:`_is_sso_user`) and the refresh
       failed, stop here. ssh/credential/gh would mint non-OIDC tokens
       that the server immediately rejects with 403 sso_required,
       silently overwriting the user's working OIDC credentials.
    3. Otherwise (non-SSO users only) fall through to the legacy
       ssh / credential helper / gh CLI methods in priority order.

    Device flow is never attempted here — it requires browser
    interaction. Callers needing an interactive fallback should call
    :func:`_interactive_auth_method` and pass the result to
    ``auth.get_token(force_method=...)``.

    Args:
        auth: AuthManager instance for authentication.

    Returns:
        True if authentication succeeded, False otherwise.

    Raises:
        PermanentAuthError: When the server permanently rejects the
            user (e.g., not in the allow-list). Re-raised so callers
            can surface a distinct ACCESS DENIED message instead of
            treating it as a transient failure that warrants retry.
    """
    # 0. Env-aware in-memory providers (HIVEMIND_TOKEN, GHA / Modal / K8s OIDC)
    #    drive their own refresh via the active provider — refresh_via_stored_token
    #    only knows about on-disk creds. When the daemon was launched from one of
    #    these providers, route the refresh through the provider's exchange flow.
    #
    #    Use getattr so test fixtures (e.g. MagicMock(spec=AuthManager)) that
    #    don't carry the instance attributes still work — the production code
    #    sets both in AuthManager.__init__.
    in_memory_creds = getattr(auth, "_in_memory_creds", None)
    if in_memory_creds is not None:
        active = getattr(auth, "_active_provider", None)
        if active is not None and getattr(active, "supports_refresh", False):
            try:
                refreshed = await active.refresh(auth.endpoint, auth.device_id)
            except PermanentAuthError:
                raise
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.debug("Active provider refresh failed", exc_info=True)
                refreshed = None
            if refreshed is not None:
                auth._in_memory_creds = refreshed
                return True
        # Static-token providers (HIVEMIND_TOKEN) cannot refresh; the daemon's
        # disk store is intentionally bypassed by env-aware providers, so there
        # is no fallback path for them here.
        return False

    # Snapshot stored credentials once. KeychainLockedError or a missing
    # entry both mean "we don't know the prior method"; conservatively
    # allow the non-OIDC fallback in that case so we don't regress users
    # with no SSO requirement.
    creds: StoredCredentials | None = None
    try:
        creds = auth.store.load_raw(auth.endpoint)
    except Exception:
        logger.debug("Could not load stored credentials", exc_info=True)

    # 1. Silent refresh — only for methods that mint refresh tokens.
    if _can_refresh(creds):
        try:
            if await auth.refresh_via_stored_token():
                return True
        except asyncio.CancelledError:
            # Preserve task cancellation semantics — never swallow this.
            raise
        except KeychainLockedError:
            logger.debug("Stored-token refresh failed: keychain is locked")
        except Exception:
            logger.debug("Stored-token refresh failed", exc_info=True)

    # 2. SSO users must not fall through. They need a fresh interactive
    #    login (oidc_browser / oidc_device) which only the caller can drive.
    if _is_sso_user(creds):
        stored_method = creds.auth_method if creds else None
        sso_org_id = creds.sso_org_id if creds else None
        logger.info(
            "Silent refresh unavailable for %s (sso_org_id=%s); not "
            "falling through to non-OIDC auth methods (would be rejected "
            "by SSO-enforced orgs). Run 'hivemind login' to re-authenticate.",
            stored_method,
            sso_org_id,
        )
        return False

    # 3. Non-OIDC fallbacks. PermanentAuthError is intentionally re-raised
    #    so the daemon can pause sync with a clear message and `hivemind
    #    start` can show ACCESS DENIED instead of generic "auth failed".
    for method in _get_preferred_methods(["ssh", "credential", "gh"]):
        try:
            await auth.get_token(force_method=method)
            return True
        except PermanentAuthError:
            raise
        except AuthError:
            continue
    return False


def _is_resumable_after_pause(
    reloaded: StoredCredentials | None,
    paused_fingerprint: str,
    expired: bool,
) -> bool:
    """Whether the recovery poll should treat *reloaded* as fresh-after-login.

    The ``expired`` check guards the empty-string ``paused_fingerprint`` sentinel
    used after an endpoint switch with no prior creds: without it, ANY stored
    token compares unequal — including aged-out leftovers from a previous
    session.
    """
    if reloaded is None or not reloaded.token:
        return False
    if reloaded.token == paused_fingerprint:
        return False
    if expired:
        return False
    return True


async def _maybe_refresh_token(
    auth: AuthManager,
    syncer: SessionSyncer | None,
    state: DaemonState,
    endpoint: str,
) -> SessionSyncer | None:
    """Rebuild the syncer when credentials on disk change out-of-band.

    Refresh itself is reactive — heartbeat/upload 401s drive
    :func:`_try_noninteractive_auth` in the main loop. This only swaps
    the syncer when its in-flight token no longer matches what's on disk
    (e.g. a concurrent ``hivemind login`` in another terminal).
    """
    creds = auth.get_current_credentials()
    if not creds:
        return syncer

    # Detect out-of-band credential changes (e.g., user ran `hivemind
    # login` in another terminal, or a heartbeat / 401-driven refresh
    # rotated the token elsewhere in this process).
    if syncer and creds.token != syncer.auth_token:
        logger.info("Credentials changed on disk (external login?), rebuilding syncer")
        return _create_syncer(
            creds,
            endpoint,
            state,
            private_sessions=syncer.private_sessions,
            org_repos=syncer.org_repos,
            private_repos=syncer.private_repos,
        )

    return syncer


def _apply_sync_failure(
    syncer: SessionSyncer,
    session_id: str,
    file_path: Path | str,
    state_file: Path | None = None,
) -> None:
    """Bump the failure counter; warn once when quarantine first engages."""
    failures, until = syncer.record_sync_failure(session_id, file_path)
    if failures == QUARANTINE_FAILURE_THRESHOLD and until > 0:
        delay = max(until - time.time(), 0.0)
        state_path = str(state_file) if state_file else "~/.hivemind/state.json"
        logger.warning(
            f"Session {session_id[:16]}... has failed {failures} times in a row; "
            f"quarantining for {delay:.0f}s. Inspect {state_path} to "
            f"investigate, or remove the session entry to retry from scratch."
        )


async def _run_sync_cycle(
    state: DaemonState,
    hot_tracker: HotSessionTracker,
    syncer: SessionSyncer,
    state_file: Path | None = None,
) -> dict:
    """Run a single sync cycle, processing all hot sessions.

    Args:
        state: Daemon state for persistence.
        hot_tracker: Tracker with recently-changed sessions.
        syncer: SessionSyncer for uploading.

    Returns:
        Stats dict with processed, success, failed counts.
    """
    # Drain hot sessions atomically
    sessions_to_sync = hot_tracker.drain()

    if not sessions_to_sync:
        return {
            "processed": 0,
            "success": 0,
            "skipped": 0,
            "failed": 0,
            "needs_token_refresh": False,
            "sso_required": False,
            "sso_org_id": "",
        }

    # Logged at DEBUG to avoid INFO-spam when most cycles end up entirely
    # skipped (e.g. Cursor's chatty SQLite writes wake us every ~2s but
    # frequently leave nothing to upload). The result line below upgrades
    # to INFO whenever real work happened.
    logger.debug(f"Sync cycle: processing {len(sessions_to_sync)} sessions")

    success_count = 0
    skipped_count = 0
    failed_count = 0
    quarantine_cleared = 0
    needs_token_refresh = False
    sso_required = False
    sso_org_id = ""
    synced_by_agent: dict[str, int] = defaultdict(int)

    for session_id, file_path in sessions_to_sync.items():
        file_path = Path(file_path)

        # Quarantine prevents one broken session from starving the queue.
        if syncer.is_quarantined(session_id):
            remaining = syncer.quarantine_remaining(session_id)
            logger.debug(
                f"Skipping quarantined session {session_id[:16]}... ({remaining:.0f}s remaining)"
            )
            skipped_count += 1
            continue

        # Determine source format from path
        source_format = _detect_source_format(file_path)
        if not source_format:
            logger.warning(f"Unknown format for {file_path}, skipping")
            failed_count += 1
            continue

        # Build metadata - unified for all formats (including Cursor)
        try:
            metadata = build_metadata_for_file(file_path, source_format, session_id)
        except ValueError as e:
            # Session doesn't have a valid cwd yet (e.g., Claude session with only
            # file-history-snapshot entries). Only re-add to hot tracker if the file
            # was recently modified - this prevents old abandoned sessions from
            # accumulating forever in the hot tracker.
            try:
                mtime = file_path.stat().st_mtime
                age_seconds = time.time() - mtime
                # Only defer if modified in last hour
                if age_seconds < 3600:
                    logger.debug(f"Deferring sync for {session_id[:16]}...: {e}")
                    hot_tracker.add(session_id, str(file_path))
                else:
                    logger.debug(
                        f"Dropping stale session {session_id[:16]}... "
                        f"(no cwd, last modified {age_seconds / 3600:.1f}h ago)"
                    )
            except OSError:
                pass  # File disappeared, don't re-add
            skipped_count += 1
            continue
        except Exception as e:
            logger.error(
                f"Error building metadata for {session_id[:16]}... ({type(e).__name__}): {e}"
            )
            _apply_sync_failure(syncer, session_id, file_path, state_file=state_file)
            failed_count += 1
            continue

        # For non-Claude agents launched via `alpha launch`, the agent generates
        # its own session ID that doesn't match the channel marker.  Check for a
        # .hivemind/session-marker file in the cwd to link back to the launch marker.
        skip_id_resolution = False
        if source_format != "claude":
            cwd = metadata.get("cwd", "")
            resolved_marker = _read_worktree_marker(cwd)
            if resolved_marker and resolved_marker != session_id:
                logger.info(
                    f"Linking {source_format} session {session_id[:16]}... "
                    f"to launch marker {resolved_marker[:8]}..."
                )
                # Migrate sync state from the old ID to the marker so:
                # (a) we don't lose last_entry_idx progress
                # (b) the old ID is removed, preventing duplicate sessions
                if syncer and hasattr(syncer, "_server_state"):
                    old_state = syncer._server_state.sessions.pop(session_id, None)
                    if old_state and resolved_marker not in syncer._server_state.sessions:
                        syncer._server_state.sessions[resolved_marker] = old_state
                session_id = resolved_marker
                skip_id_resolution = True

                # The early is_quarantined() check above ran on the
                # pre-remap tracker ID. Failures recorded under the
                # resolved marker (the canonical id used from here on)
                # would otherwise bypass quarantine entirely.
                if syncer.is_quarantined(session_id):
                    remaining = syncer.quarantine_remaining(session_id)
                    logger.debug(
                        f"Skipping quarantined session {session_id[:16]}... ({remaining:.0f}s remaining)"
                    )
                    skipped_count += 1
                    continue

        try:
            outcome = await asyncio.wait_for(
                syncer.sync_session(
                    session_id=session_id,
                    file_path=file_path,
                    source_format=source_format,
                    metadata=metadata,
                    skip_id_resolution=skip_id_resolution,
                ),
                timeout=PER_SESSION_SYNC_TIMEOUT,
            )
            if outcome.needs_token_refresh:
                needs_token_refresh = True
            if outcome.sso_required:
                sso_required = True
                sso_org_id = outcome.sso_org_id or sso_org_id
            if outcome.result == SyncResult.SYNCED:
                if syncer.record_sync_success(session_id):
                    quarantine_cleared += 1
                success_count += 1
                synced_by_agent[source_format] += 1
            elif outcome.result == SyncResult.SKIPPED:
                if syncer.record_sync_success(session_id):
                    quarantine_cleared += 1
                skipped_count += 1
            else:
                _apply_sync_failure(syncer, session_id, file_path, state_file=state_file)
                failed_count += 1
        except asyncio.TimeoutError:
            logger.error(
                f"Sync timed out for {session_id[:16]}... after {PER_SESSION_SYNC_TIMEOUT}s"
            )
            _apply_sync_failure(syncer, session_id, file_path, state_file=state_file)
            failed_count += 1
        except Exception as e:
            logger.error(f"Error syncing {session_id[:16]}... ({type(e).__name__}): {e}")
            _apply_sync_failure(syncer, session_id, file_path, state_file=state_file)
            failed_count += 1

    # Prune inactive sessions from hot tracker periodically
    hot_tracker.prune_inactive()

    return {
        "processed": len(sessions_to_sync),
        "success": success_count,
        "skipped": skipped_count,
        "failed": failed_count,
        "quarantine_cleared": quarantine_cleared,
        "needs_token_refresh": needs_token_refresh,
        "sso_required": sso_required,
        "sso_org_id": sso_org_id,
        "synced_by_agent": dict(synced_by_agent),
    }


def _get_import_max_age_days() -> int:
    """Get the historic import max age in days.

    Priority (highest to lowest):
    1. HIVEMIND_IMPORT_MAX_AGE_DAYS environment variable
    2. Config file ([import] max_age_days)
    3. Default: 90 days

    Returns:
        Max age in days, or 0 for unlimited.
    """
    env_val = os.environ.get("HIVEMIND_IMPORT_MAX_AGE_DAYS")
    if env_val is not None:
        try:
            return int(env_val)
        except ValueError:
            logger.warning(
                f"Invalid HIVEMIND_IMPORT_MAX_AGE_DAYS={env_val!r}, using config default"
            )

    config = load_config()
    return config.import_.max_age_days


async def _run_historic_import(
    syncer: SessionSyncer,
    state: DaemonState,
    endpoint: str,
    state_file: Path | None = None,
) -> dict:
    """Import historic sessions on first boot.

    By default, only imports sessions from the last 90 days. This can be
    configured via the [import] max_age_days config option or the
    HIVEMIND_IMPORT_MAX_AGE_DAYS environment variable. Set to 0 for unlimited.

    Args:
        syncer: SessionSyncer instance for uploading.
        state: DaemonState for tracking sync progress.
        endpoint: Server endpoint (used to get server-scoped state).
        state_file: Path to state file for periodic saving (optional).

    Returns:
        Stats dict with discovered, success, failed, skipped counts.
    """
    max_age_days = _get_import_max_age_days()

    if max_age_days > 0:
        since_ts = time.time() - (max_age_days * 86400)
        click.echo(f"Importing historic sessions (last {max_age_days} days)...")
        logger.info(f"Starting historic session import (max_age_days={max_age_days})")
    else:
        since_ts = None
        click.echo("Importing historic sessions (all time)...")
        logger.info("Starting historic session import (unlimited)")

    # Get server-scoped state for session tracking
    server_state = state.get_server_state(endpoint)

    # Discover sessions from home directory (searches all agent paths)
    all_sessions = discover_all_sessions(Path.home(), since_ts=since_ts)

    if not all_sessions:
        click.echo("  No historic sessions found.")
        logger.info("No historic sessions found")
        return {"discovered": 0, "success": 0, "failed": 0, "skipped": 0}

    click.echo(f"  Found {len(all_sessions)} sessions to import...")

    success_count = 0
    failed_count = 0
    skipped_count = 0
    unsaved_syncs = 0

    for session in all_sessions:
        session_id = session["id"]
        file_path = Path(session["path"])
        source_format = session["format"]

        # Skip if we've already fully synced this session
        if session_id in server_state.sessions:
            session_state = server_state.sessions[session_id]
            # Check if file has been modified since last sync
            try:
                current_mtime = file_path.stat().st_mtime
                if current_mtime <= session_state.last_mtime:
                    skipped_count += 1
                    continue
            except OSError:
                skipped_count += 1
                continue
        else:
            # Skip sessions below the pruning horizon (already synced, then pruned from state)
            session_mtime = session.get("modified_at", 0)
            if 0 < session_mtime <= server_state.pruned_before_ts:
                skipped_count += 1
                continue

        # Build metadata - unified for all formats (including Cursor)
        try:
            metadata = extract_session_metadata(session)
        except ValueError as e:
            logger.warning(f"Failed to extract metadata for {session_id[:16]}...: {e}")
            failed_count += 1
            continue

        try:
            outcome = await asyncio.wait_for(
                syncer.sync_session(
                    session_id=session_id,
                    file_path=file_path,
                    source_format=source_format,
                    metadata=metadata,
                ),
                timeout=PER_SESSION_SYNC_TIMEOUT,
            )
            if outcome.result == SyncResult.SYNCED:
                success_count += 1
                unsaved_syncs += 1
            elif outcome.result == SyncResult.SKIPPED:
                skipped_count += 1
            else:
                failed_count += 1
        except asyncio.TimeoutError:
            logger.warning(
                f"Historic import timed out for {session_id[:16]}... "
                f"after {PER_SESSION_SYNC_TIMEOUT}s, skipping"
            )
            failed_count += 1
        except Exception as e:
            logger.warning(f"Historic import failed for {session_id[:16]}...: {e}")
            failed_count += 1

        # Save state periodically so progress isn't lost if daemon hangs or is killed
        if state_file and unsaved_syncs >= BULK_SYNC_SAVE_INTERVAL:
            save_state(state, state_file)
            unsaved_syncs = 0

    # Final save for any remaining unsaved progress
    if state_file and unsaved_syncs > 0:
        save_state(state, state_file)

    # Log summary
    click.echo(
        f"  Historic import complete: {success_count} synced, "
        f"{skipped_count} skipped, {failed_count} failed"
    )
    logger.info(
        f"Historic import complete: {success_count} synced, "
        f"{skipped_count} skipped, {failed_count} failed"
    )

    return {
        "discovered": len(all_sessions),
        "success": success_count,
        "failed": failed_count,
        "skipped": skipped_count,
    }


async def _run_catchup_sync(
    syncer: SessionSyncer,
    state: DaemonState,
    endpoint: str,
    state_file: Path | None = None,
) -> dict:
    """Sync sessions modified while daemon was stopped.

    This "catch-up sync" discovers all sessions and syncs any that have new
    entries. Per-session mtime/entry_idx checks handle dedup, so we don't need
    a time-based discovery filter.

    Args:
        syncer: SessionSyncer instance for uploading.
        state: DaemonState for tracking sync progress.
        endpoint: Server endpoint (used to get server-scoped state).
        state_file: Path to state file for periodic saving (optional).

    Returns:
        Stats dict with discovered, success, failed, skipped counts.
    """
    server_state = state.get_server_state(endpoint)

    logger.info("Running catch-up sync for all discoverable sessions")

    # Discover all sessions — rely on per-session mtime/entry_idx for dedup
    all_sessions = discover_all_sessions(Path.home())

    if not all_sessions:
        logger.info("No sessions found for catch-up sync")
        return {"discovered": 0, "success": 0, "failed": 0, "skipped": 0}

    click.echo(f"  Catch-up: found {len(all_sessions)} sessions modified since last run...")

    success_count = 0
    failed_count = 0
    skipped_count = 0
    unsaved_syncs = 0
    timed_out_sessions: set[str] = set()

    for session in all_sessions:
        session_id = session["id"]
        file_path = Path(session["path"])
        source_format = session["format"]

        # Skip sessions that already timed out in this catch-up run.
        # Without this, a single large session can block catch-up
        # indefinitely by timing out and retrying in a loop (e.g. if
        # discover_all_sessions returns duplicate paths for the same ID).
        if session_id in timed_out_sessions:
            skipped_count += 1
            continue

        # Check if already tracked and unchanged
        if session_id in server_state.sessions:
            session_state = server_state.sessions[session_id]
            try:
                current_mtime = file_path.stat().st_mtime
                if current_mtime <= session_state.last_mtime and session_state.last_entry_idx >= 0:
                    # File unchanged AND previously synced successfully — skip
                    skipped_count += 1
                    continue
            except OSError:
                skipped_count += 1
                continue
        else:
            # Skip sessions below the pruning horizon (already synced, then pruned from state)
            session_mtime = session.get("modified_at", 0)
            if 0 < session_mtime <= server_state.pruned_before_ts:
                skipped_count += 1
                continue

        # Build metadata - unified for all formats (including Cursor)
        try:
            metadata = extract_session_metadata(session)
        except ValueError as e:
            logger.warning(f"Catch-up: failed to extract metadata for {session_id[:16]}...: {e}")
            failed_count += 1
            continue

        try:
            outcome = await asyncio.wait_for(
                syncer.sync_session(
                    session_id=session_id,
                    file_path=file_path,
                    source_format=source_format,
                    metadata=metadata,
                ),
                timeout=PER_SESSION_SYNC_TIMEOUT,
            )
            if outcome.result == SyncResult.SYNCED:
                success_count += 1
                unsaved_syncs += 1
            elif outcome.result == SyncResult.SKIPPED:
                skipped_count += 1
            else:
                failed_count += 1
        except asyncio.TimeoutError:
            timed_out_sessions.add(session_id)
            logger.warning(
                f"Catch-up sync timed out for {session_id[:16]}... "
                f"after {PER_SESSION_SYNC_TIMEOUT}s, skipping"
            )
            failed_count += 1
        except Exception as e:
            logger.warning(f"Catch-up sync failed for {session_id[:16]}...: {e}")
            failed_count += 1

        # Save state periodically so progress isn't lost
        if state_file and unsaved_syncs >= BULK_SYNC_SAVE_INTERVAL:
            save_state(state, state_file)
            unsaved_syncs = 0

    # Final save for any remaining unsaved progress
    if state_file and unsaved_syncs > 0:
        save_state(state, state_file)

    logger.info(
        f"Catch-up sync complete: {success_count} synced, "
        f"{skipped_count} skipped, {failed_count} failed"
    )

    return {
        "discovered": len(all_sessions),
        "success": success_count,
        "failed": failed_count,
        "skipped": skipped_count,
    }


def parse_since(value: str | None) -> float | None:
    """Parse --since value into a Unix timestamp.

    Accepts:
    - ISO 8601 datetime: "2024-01-15T10:30:00"
    - Date only: "2024-01-15"
    - Relative: "1d", "2h", "30m" (days, hours, minutes ago)
    - Unix timestamp: "1705312200"
    """
    if not value:
        return None

    # Try relative format first (e.g., "1d", "2h", "30m")
    if value[-1] in "dhm" and value[:-1].isdigit():
        num = int(value[:-1])
        unit = value[-1]
        seconds = {"d": 86400, "h": 3600, "m": 60}[unit]
        return time.time() - (num * seconds)

    # Try Unix timestamp
    if value.isdigit():
        return float(value)

    # Try ISO 8601 / date formats
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(value, fmt)
            return dt.replace(tzinfo=timezone.utc).timestamp()
        except ValueError:
            continue

    raise click.BadParameter(
        f"Invalid date format: {value}. Use ISO 8601 (2024-01-15T10:30:00), "
        "date (2024-01-15), relative (1d, 2h, 30m), or Unix timestamp."
    )


def _is_local_dev_endpoint(endpoint: str) -> bool:
    """Return True if endpoint is a local dev server (localhost or *.test domain).

    DEV_MODE auto-login via /v1/auth/me is only safe against local servers.
    A remote endpoint like hivemind.qa.wandb.tools should never receive
    unauthenticated /v1/auth/me probes, even when dev.repo is configured.
    """
    from urllib.parse import urlparse  # noqa: PLC0415

    host = urlparse(endpoint).hostname or ""
    return host in ("localhost", "127.0.0.1", "::1") or host.endswith(".test")


async def _dev_mode_authenticate(auth: AuthManager) -> bool:
    """Attempt DEV_MODE authentication by calling GET /v1/auth/me on the local API.

    In DEV_MODE, the API auto-creates a dev user and returns a JWT cookie
    without requiring GitHub OAuth. This enables the daemon to authenticate
    in environments without GitHub credentials (e.g., CI, Claude Code web).

    Only called when the endpoint is a local dev server; callers must gate
    on _is_local_dev_endpoint() before invoking this function.

    Args:
        auth: AuthManager instance (endpoint must be localhost or *.test).

    Returns:
        True if authentication succeeded, False otherwise.
    """
    endpoint = auth.endpoint.rstrip("/")
    url = f"{endpoint}/v1/auth/me"
    logger.info(f"DEV_MODE: Attempting auto-login via {url}")

    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get(url, timeout=10)
            if resp.status_code != 200:
                logger.warning(f"DEV_MODE: /v1/auth/me returned {resp.status_code}")
                return False

            # Extract JWT from set-cookie header
            token = None
            for cookie_header in resp.headers.get_list("set-cookie"):
                if cookie_header.startswith("agentstream_token="):
                    token = cookie_header.split("=", 1)[1].split(";")[0]
                    break

            if not token:
                logger.warning("DEV_MODE: No agentstream_token cookie in response")
                return False

            data = resp.json()
            now = int(time.time())
            creds = StoredCredentials(
                token=token,
                user_id=data.get("user_id", "dev-user"),
                github_user=data.get("username", "dev"),
                email=data.get("email", "dev@localhost"),
                expires_at=now + 30 * 86400,  # 30 days
                auth_method="dev_mode",
                device_id="dev-device",
                created_at=now,
                updated_at=now,
            )
            auth.store.save(creds, auth.endpoint)
            logger.info(f"DEV_MODE: Authenticated as {creds.github_user}")
            return True

    except Exception as e:
        logger.warning(f"DEV_MODE: Auto-login failed: {e}")
        return False


async def _ensure_authenticated(auth: AuthManager) -> tuple[bool, bool]:
    """Ensure the daemon has valid credentials, attempting auto-login if needed.

    Tries silent refresh / non-OIDC fallbacks via :func:`_try_noninteractive_auth`
    first (handles SSO no-downgrade and stored OIDC refresh), then falls
    through to the env-aware provider chain via
    :meth:`AuthManager.resolve_credentials` for headless runtimes
    (HIVEMIND_TOKEN, GitHub Actions / Modal / Kubernetes OIDC, HIVEMIND_DEV_MODE).

    In dev mode (env var HIVEMIND_DEV_MODE=true) against a local endpoint,
    the DevModeProvider invokes the API's /v1/auth/me to mint a dev JWT.

    Args:
        auth: AuthManager instance.

    Returns:
        Tuple of (authenticated, permanent_failure).
        - (True, False) if successfully authenticated
        - (False, True) if permanent auth failure (e.g., org restriction)
        - (False, False) if temporary auth failure (can retry later)
    """
    existing = await auth.whoami()
    if existing and not existing["expired"]:
        logger.info(f"Authenticated as {existing['github_user']} (via {existing['auth_method']})")
        return True, False

    if existing and existing["expired"]:
        logger.info(f"Token expired for {existing['github_user']}, attempting re-authentication...")

    # DEV_MODE bypass: authenticate via the API's dev auto-login.
    # Only attempted when HIVEMIND_DEV_MODE=1 (set explicitly by the user or
    # by dev.repo re-exec) AND the endpoint is a local dev server. Remote
    # endpoints like hivemind.qa.wandb.tools must use real auth even when
    # dev.repo is configured. (DevModeProvider also enforces this gate, but
    # we keep the inline path so the fallback chain order matches main.)
    dev_mode = os.environ.get("HIVEMIND_DEV_MODE", "").lower() in ("1", "true", "yes")
    if dev_mode and _is_local_dev_endpoint(auth.endpoint):
        if await _dev_mode_authenticate(auth):
            return True, False
        logger.warning("DEV_MODE: Auto-login failed, falling back to standard auth methods")

    # 1. Silent refresh + non-OIDC fallbacks for users with stored credentials.
    #    Handles in-memory env/OIDC providers (re-exchange via active provider),
    #    refresh_token-bearing stored creds (server-brokered IdP refresh), and
    #    ssh/credential/gh fallback for non-SSO stored users. Respects SSO
    #    no-downgrade.
    try:
        if await _try_noninteractive_auth(auth):
            info = await auth.whoami()
            if info:
                logger.info(f"Authenticated as {info['github_user']} (via {info['auth_method']})")
                return True, False
    except PermanentAuthError as e:
        # Permanent failure — user is not authorized to use this service.
        logger.error(f"Permanent auth failure: {e}")
        return False, True

    # 2. Environment-aware provider chain for headless runtimes with no stored
    #    credentials (HIVEMIND_TOKEN, GitHub Actions / Modal / Kubernetes OIDC,
    #    DEV_MODE on local endpoints). Skip stored: whoami already evaluated
    #    on-disk creds; expired ones are handled by step 1's refresh path.
    try:
        creds = await auth.resolve_credentials(skip_stored=True)
    except PermanentAuthError as e:
        logger.error(f"Permanent auth failure: {e}")
        return False, True
    except AuthError as e:
        logger.debug(f"Credential resolution failed: {e}")
        creds = None

    if creds:
        logger.info(f"Authenticated as {creds.github_user} (via {creds.auth_method})")
        return True, False

    logger.warning("Authentication required. Run 'hivemind login' to authenticate this device.")
    logger.warning("The daemon will continue running but syncing is disabled until authenticated.")
    return False, False


async def _maybe_upgrade_to_sso(auth: AuthManager, endpoint: str) -> bool:
    """Check if the user's org requires SSO and upgrade credentials if so.

    Called after a successful non-SSO login. Uses the fresh token to call
    /v1/auth/me and check sso_required. If yes, attempts OIDC SSO flow.

    Returns True if SSO upgrade was performed, False if not needed.
    """
    creds = auth.store.load(auth.endpoint)
    if not creds or creds.auth_method.startswith("oidc_"):
        return False  # Already SSO

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(
                f"{endpoint}/v1/auth/me",
                headers={"Authorization": f"Bearer {creds.token}"},
            )
        if resp.status_code != 200:
            return False
        me = resp.json()
        if not me.get("sso_required"):
            return False
    except Exception:
        return False

    # Org requires SSO — extract org_id and attempt upgrade
    parsed = urlparse(me.get("sso_login_url", ""))
    org_id = parse_qs(parsed.query).get("org_id", [""])[0]
    auth.mark_sso_required(org_id or None)

    click.echo("Your organization requires SSO. Upgrading credentials...")
    try:
        await auth.get_token(force_method="oidc_browser")
        return True
    except Exception as e:
        click.echo(f"SSO upgrade failed: {e}", err=True)
        click.echo("Run 'hivemind login' to authenticate with SSO.", err=True)
        raise SystemExit(1)


async def _pre_start_auth_check_async(state_path: Path) -> str | None:
    """Verify authentication before starting the daemon.

    Checks for valid credentials and attempts non-interactive auth methods.
    Falls back to interactive device flow if a TTY is available.

    Args:
        state_path: Path to the state directory (used to resolve endpoint).

    Raises:
        SystemExit: If authentication fails and no TTY is available,
            or if a permanent auth failure occurs.
    """
    effective_endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth = AuthManager(endpoint=base_endpoint)

    # Soft re-auth gate: inspect locally-saved credentials and decide whether
    # re-authentication is required *even if* the token still validates with
    # the server. Used for credential-age and "org now requires SSO" cases.
    try:
        saved_creds = auth.store.load(base_endpoint)
    except Exception:
        saved_creds = None
    if saved_creds is not None and not isinstance(saved_creds, StoredCredentials):
        saved_creds = None  # defensive: tests may inject mocks

    soft_reauth = evaluate_reauth(saved_creds) if saved_creds else None
    if soft_reauth and soft_reauth.decision in (
        ReauthDecision.AGE_EXPIRED,
        ReauthDecision.SSO_REQUIRED,
    ):
        click.secho(soft_reauth.message(), fg="yellow")
        track("cli.preflight_auth", {"reauth_reason": soft_reauth.decision.value})
        if soft_reauth.decision is ReauthDecision.SSO_REQUIRED and soft_reauth.sso_org_id:
            auth.mark_sso_required(soft_reauth.sso_org_id)
            if sys.stdin.isatty():
                try:
                    await auth.get_token(force_method="oidc_browser")
                    info = await auth.whoami()
                    if info:
                        click.secho(
                            f"✓ Authenticated as {info['github_user']} ({base_endpoint})",
                            fg="green",
                        )
                        return soft_reauth.decision.value
                except PermanentAuthError as e:
                    click.echo(f"\nACCESS DENIED: {e}", err=True)
                    raise SystemExit(1)
                except AuthError as e:
                    click.echo(f"SSO sign-in failed: {e}", err=True)
                    raise SystemExit(1)
            else:
                click.echo(
                    "SSO sign-in requires an interactive terminal. "
                    "Run `hivemind login` from a terminal.",
                    err=True,
                )
                raise SystemExit(1)
        # AGE_EXPIRED → fall through to the existing non-interactive → interactive
        # recovery chain below; skip the whoami short-circuit so we actually force
        # a fresh login even if the server still considers the token valid.

    skip_whoami = bool(soft_reauth and soft_reauth.decision is ReauthDecision.AGE_EXPIRED)

    # Check existing valid credentials
    if not skip_whoami:
        info = await auth.whoami()
        if info and not info["expired"]:
            click.secho(f"✓ Authenticated as {info['github_user']} ({base_endpoint})", fg="green")
            return soft_reauth.decision.value if soft_reauth else ReauthDecision.OK.value

    # 1. Silent refresh + non-OIDC fallbacks for stored users. Handles
    #    in-memory env/OIDC providers, refresh_token-bearing stored creds, and
    #    ssh/credential/gh fallback for non-SSO users. Runs even on AGE_EXPIRED:
    #    refreshing a refreshable token rotates created_at, and ssh/credential/gh
    #    mint fresh creds — both satisfy the age gate without dragging the user
    #    through an interactive login.
    try:
        if await _try_noninteractive_auth(auth):
            info = await auth.whoami()
            if info:
                click.secho(
                    f"✓ Authenticated as {info['github_user']} ({base_endpoint})", fg="green"
                )
                # Check if org requires SSO upgrade
                if await _maybe_upgrade_to_sso(auth, base_endpoint):
                    click.secho("✓ SSO authentication complete", fg="green")
                return soft_reauth.decision.value if soft_reauth else ReauthDecision.OK.value
    except PermanentAuthError as e:
        click.echo("\n" + "=" * 60, err=True)
        click.echo("ACCESS DENIED", err=True)
        click.echo("=" * 60, err=True)
        click.echo(str(e), err=True)
        click.echo("\nYour GitHub account is not authorized to use this service.", err=True)
        click.echo("Contact your administrator if you believe this is an error.", err=True)
        click.echo("=" * 60 + "\n", err=True)
        raise SystemExit(1) from e

    # 2. Environment-aware provider chain (HIVEMIND_TOKEN, GitHub Actions /
    #    Modal / Kubernetes OIDC, dev mode). Lets headless runtimes use
    #    `hivemind start` with federated credentials. When the soft re-auth
    #    gate flagged AGE_EXPIRED we skip StoredCredentialProvider so the
    #    same on-disk creds that triggered the age gate don't short-circuit
    #    the chain and defeat the forced re-auth.
    try:
        resolved = await auth.resolve_credentials(skip_stored=skip_whoami)
    except PermanentAuthError as e:
        click.echo("\n" + "=" * 60, err=True)
        click.echo("ACCESS DENIED", err=True)
        click.echo("=" * 60, err=True)
        click.echo(str(e), err=True)
        click.echo("\nYour GitHub account is not authorized to use this service.", err=True)
        click.echo("Contact your administrator if you believe this is an error.", err=True)
        click.echo("=" * 60 + "\n", err=True)
        raise SystemExit(1) from e
    except Exception as e:
        logger.debug("Provider chain resolution failed: %s", e)
        resolved = None

    if resolved:
        click.secho(f"✓ Authenticated as {resolved.github_user} ({base_endpoint})", fg="green")
        return soft_reauth.decision.value if soft_reauth else ReauthDecision.OK.value

    # All non-interactive methods failed
    if sys.stdin.isatty():
        click.echo("No valid credentials found. Starting interactive login...")
        # Pick the right interactive flow for this user: SSO/OIDC users
        # need oidc_device (Okta), GitHub users need device (GitHub).
        # Hardcoding "device" here would force OIDC users through GitHub
        # device flow, which 403s against SSO-enforced orgs.
        interactive_method = _interactive_auth_method(auth)
        try:
            await auth.get_token(force_method=interactive_method)
            info = await auth.whoami()
            if info:
                click.secho(
                    f"✓ Authenticated as {info['github_user']} ({base_endpoint})", fg="green"
                )
                # Check if org requires SSO upgrade (only relevant for the
                # GitHub device flow path; oidc_device is already SSO).
                if await _maybe_upgrade_to_sso(auth, base_endpoint):
                    click.secho("✓ SSO authentication complete", fg="green")
                return soft_reauth.decision.value if soft_reauth else ReauthDecision.OK.value
        except PermanentAuthError as e:
            click.echo("\n" + "=" * 60, err=True)
            click.echo("ACCESS DENIED", err=True)
            click.echo("=" * 60, err=True)
            click.echo(str(e), err=True)
            click.echo("\nYour GitHub account is not authorized to use this service.", err=True)
            click.echo("Contact your administrator if you believe this is an error.", err=True)
            click.echo("=" * 60 + "\n", err=True)
            raise SystemExit(1) from e
        except AuthError as e:
            click.echo(f"Authentication failed: {e}", err=True)
            raise SystemExit(1) from e
    else:
        click.echo("Authentication required. Run 'hivemind login' to authenticate.", err=True)
        raise SystemExit(1)


# Reason codes persisted in per-server state when sync is paused on auth.
# Distinguishing these lets `hivemind status` tell the user whether they hit
# an org-level SSO gate (server-side) or a broken refresh-token chain
# (daemon-side, Okta can't refresh). TODO: in future, forward this reason to
# the backend (e.g. on heartbeat or a follow-up /v1/daemon/status ping) and
# persist on the device row so the dashboard can render a specific banner
# instead of a generic "daemon inactive" message.
_PAUSE_REASON_SSO_REQUIRED = "sso_required"
_PAUSE_REASON_LOGIN_REQUIRED = "login_required"

_AUTH_ERR_SSO_MSG = "Organization requires SSO. Run 'hivemind login' to re-authenticate."
_AUTH_ERR_REFRESH_MSG = (
    "OIDC credentials could not be refreshed. Run 'hivemind login' to re-authenticate."
)


def _mark_auth_paused(
    state: DaemonState,
    state_file: Path,
    endpoint: str,
    reason: str,
    message: str,
) -> None:
    """Persist a 'sync paused, auth failing' marker for `hivemind status`.

    `reason` is one of `_PAUSE_REASON_SSO_REQUIRED` or
    `_PAUSE_REASON_LOGIN_REQUIRED`. It's written to `last_auth_error` so the
    status command can surface it; the human-readable `message` carries the
    full explanation.
    """
    srv = state.get_server_state(endpoint)
    srv.last_auth_error = reason
    srv.last_auth_error_ts = int(time.time())
    srv.last_auth_error_message = message
    save_state(state, state_file)


def _mark_auth_healthy(
    state: DaemonState,
    state_file: Path,
    endpoint: str,
) -> None:
    """Clear any persisted auth error. No-op if already clear."""
    srv = state.get_server_state(endpoint)
    if not srv.last_auth_error:
        return
    srv.last_auth_error = ""
    srv.last_auth_error_ts = 0
    srv.last_auth_error_message = ""
    save_state(state, state_file)


def _pause_sync(
    state: DaemonState,
    state_file: Path,
    endpoint: str,
    reason: str,
    message: str,
    *,
    trigger: str,
    detail: str = "",
    auth: AuthManager | None = None,
) -> None:
    """Mark the daemon paused and emit a structured warning log.

    `trigger` identifies which code path detected the problem
    (e.g. "pre_catchup_refresh", "heartbeat", "sync_403",
    "refresh_signal"). `detail` carries any underlying error text.
    Identity fields (user, device_id) are pulled from the stored
    credentials if an `auth` manager is provided.
    """
    _mark_auth_paused(state, state_file, endpoint, reason, message)
    set_telemetry_paused(True)
    user = "?"
    device = "?"
    if auth is not None:
        try:
            creds = auth.store.load(auth.endpoint)
            if creds:
                user = creds.github_user or "?"
                device = creds.device_id or "?"
        except Exception:
            logger.debug("Failed to load creds for paused log", exc_info=True)
    logger.warning(
        "daemon.paused reason=%s trigger=%s user=%s device_id=%s endpoint=%s detail=%r. "
        "Run 'hivemind login' to re-authenticate.",
        reason,
        trigger,
        user,
        device,
        endpoint,
        detail,
    )


def _clear_last_auth_error(endpoint: str) -> None:
    """Clear a persisted `last_auth_error` on the per-server state.

    Called from `hivemind login` after a successful authentication so
    that the running daemon's `hivemind status` returns to green
    immediately instead of waiting for the daemon's credential-poll to
    detect the fresh token on its next sync interval.

    Silently no-ops if the state file doesn't exist or the error was
    already clear.
    """
    try:
        if not DEFAULT_STATE_FILE.exists():
            return
        state = load_state(DEFAULT_STATE_FILE)
        srv = state.get_server_state(endpoint)
        if not srv.last_auth_error:
            return
        srv.last_auth_error = ""
        srv.last_auth_error_ts = 0
        srv.last_auth_error_message = ""
        save_state(state, DEFAULT_STATE_FILE)
    except Exception:
        # Best-effort: never fail the login flow over a state write.
        logger.debug("Failed to clear last_auth_error", exc_info=True)


def _pre_start_auth_check(state_path: Path) -> str:
    """Sync wrapper for _pre_start_auth_check_async. Skips in test mode.

    Returns the ReauthDecision value (e.g. "ok", "sso_required") for the
    caller to use in telemetry. Returns "skipped" in test mode.
    """
    if os.environ.get("HIVEMIND_TEST_MODE") == "1":
        return "skipped"
    return asyncio.run(_pre_start_auth_check_async(state_path)) or "ok"


def _handle_post_upgrade_state(state: DaemonState) -> bool:
    """Process the ``pending_restart`` marker on daemon boot, in place.

    Returns ``True`` if the marker was set and has been cleared (caller
    should persist state), ``False`` otherwise. Extracted from
    ``_run_daemon`` so the post-upgrade detection logic is unit-testable
    without standing up auth, network, or the asyncio loop.

    Behavior:
      - If the running version matches the pending target, log the
        transition + emit ``daemon.upgrade_completed`` telemetry.
      - If the running version doesn't match, log a warning (binary
        was clobbered, supervisor ran the wrong path, or the upgrade
        was reverted). Watcher will retry on its next interval.
      - Always clears the marker.
    """
    if state.pending_restart is None:
        return False

    pending = state.pending_restart
    if pending.to_version == __version__:
        logger.info(
            "Restarted after upgrade: %s → %s (method=%s)",
            pending.from_version,
            pending.to_version,
            pending.method,
        )
        click.echo(f"  Upgraded:  {pending.from_version} → {pending.to_version} ({pending.method})")
        track(
            "daemon.upgrade_completed",
            {
                "from_version": pending.from_version,
                "to_version": pending.to_version,
                "method": pending.method,
            },
        )
    else:
        logger.warning(
            "pending_restart says %s but running %s — upgrade may have been reverted",
            pending.to_version,
            __version__,
        )
    state.pending_restart = None
    return True


async def _run_daemon(
    interval: int,
    state_path: Path,
    skip_historic_import: bool = False,
    skip_catchup: bool = False,
    test_mode: bool = False,
    relay: bool = False,
) -> None:
    """Run the daemon main loop.

    Args:
        interval: Sync interval in seconds.
        state_path: Path to state directory.
        skip_historic_import: If True, skip importing historic sessions on first boot.
        skip_catchup: If True, skip catch-up sync for sessions modified while daemon was stopped.
        test_mode: If True, skip authentication and syncing. Used in CI to verify
            the daemon process lifecycle without requiring credentials.
        relay: If True, enable the tmux PTY relay for remote-control
            channels (alpha feature, requires tmux).
    """
    state_file = state_path / "state.json"

    # Configure logging (dev.debug in config enables DEBUG level)
    config = load_config()
    log_level = logging.DEBUG if config.dev.debug else logging.INFO
    log_dest = configure_logging(level=log_level)
    # When in debug, suppress noisy library logs that clutter our debug output.
    # - watchdog/fsevents: File system events for state.json, .state_*.tmp in .hivemind
    # - httpcore/httpx: Low-level HTTP connection details
    if config.dev.debug:
        logging.getLogger("watchdog").setLevel(logging.WARNING)
        logging.getLogger("fsevents").setLevel(logging.WARNING)
        logging.getLogger("httpcore").setLevel(logging.WARNING)
        logging.getLogger("httpx").setLevel(logging.INFO)

    # Determine effective endpoint (config module priority chain: config file > env var > default)
    config_path = DEFAULT_CONFIG_PATH
    effective_endpoint = get_effective_endpoint(config_path)
    endpoint_source = _get_endpoint_source(config_path)

    # Print startup banner
    click.echo("Hivemind daemon starting...")
    click.echo(f"  Version:   {__version__}")
    click.echo(f"  Logging to: {log_dest}")
    if config.dev.debug:
        click.echo("  Debug:     on (verbose logging)")
    click.echo(f"  State dir:  {state_path}")
    click.echo(f"  Endpoint:   {effective_endpoint} ({endpoint_source})")
    click.echo(f"  Interval:   {interval}s")

    # Check for test mode (CLI flag or env var)
    test_mode = test_mode or os.environ.get("HIVEMIND_TEST_MODE") == "1"
    if test_mode:
        click.echo("  Test mode:  ENABLED (auth and sync skipped)")

    # Dev mode banner: auto-login only applies to local endpoints.
    dev_mode_env = os.environ.get("HIVEMIND_DEV_MODE", "").lower() in ("1", "true", "yes")
    if dev_mode_env and not test_mode:
        if _is_local_dev_endpoint(effective_endpoint):
            click.echo("  Dev mode:   ENABLED (auto-login via API)")
        else:
            click.echo("  Dev mode:   dev repo active (auto-login skipped, remote endpoint)")

    logger.info("Hivemind daemon starting...")
    logger.info(f"Version: {__version__}")
    logger.info(f"Logging to: {log_dest}")
    logger.info(f"State directory: {state_path}")
    logger.info(f"Endpoint: {effective_endpoint} ({endpoint_source})")
    logger.info(f"Sync interval: {interval}s")
    if test_mode:
        logger.info("Test mode enabled - authentication and syncing skipped")

    # Auto-install/update the @hivemind agent across supported platforms
    if not test_mode:
        try:
            if install_agent(quiet=True):
                logger.info("Installed/updated @hivemind agent")
        except Exception:
            logger.debug("Failed to install @hivemind agent", exc_info=True)

    # Setup auth and authenticate
    base_endpoint = get_base_endpoint(effective_endpoint)
    creds = None

    if test_mode:
        authenticated = True
        permanent_failure = False
    else:
        auth = AuthManager(endpoint=base_endpoint, config=config)
        authenticated, permanent_failure = await _ensure_authenticated(auth)

        if permanent_failure:
            click.echo("\n" + "=" * 60)
            click.echo("ACCESS DENIED")
            click.echo("=" * 60)
            click.echo("Your GitHub account is not authorized to use this service.")
            click.echo("Contact your administrator if you believe this is an error.")
            click.echo("=" * 60 + "\n")
            return  # Exit cleanly without starting the daemon loop

        # Get credentials for syncer setup (keyed by endpoint, falls through
        # to in-memory creds from ephemeral providers like HIVEMIND_TOKEN or
        # GitHub Actions OIDC).
        creds = auth.get_current_credentials()

    # Load state and get server-specific state
    state = load_state(state_file)
    server_state = state.get_server_state(base_endpoint)
    logger.info(f"Loaded state: {len(server_state.sessions)} tracked sessions for {base_endpoint}")

    # Post-upgrade detection: if the previous run of the daemon staged
    # a new binary via the upgrade watcher, we're the restart that the
    # supervisor kicked off to pick it up. Log the transition and clear
    # the marker so we don't report it twice.
    if _handle_post_upgrade_state(state):
        save_state(state, state_file)

    # Set up HotSessionTracker
    hot_tracker = HotSessionTracker(max_size=250, inactive_timeout=3600.0)

    # Load config for session privacy and web session settings
    config = load_config()

    # Set up SessionSyncer (only if authenticated and not in test mode).
    # buffer_seconds=0 admits short-TTL tokens (HIVEMIND_OIDC_TOKEN_TTL_SECONDS
    # in QA); refresh runs reactively from heartbeat/upload 401s.
    syncer = None
    if not test_mode and creds and not auth.store.is_expired(creds, buffer_seconds=0):
        syncer = _create_syncer(
            creds,
            effective_endpoint,
            state,
            private_sessions=config.sessions.private,
            org_repos=config.sessions.org_repos,
            private_repos=config.sessions.private_repos,
        )
        logger.info(f"Syncer initialized for user {creds.github_user}")
        # Verify auth health BEFORE assuming the loaded creds are good.
        # A startup heartbeat is a real authenticated server call — if the
        # server accepts it, the persisted last_auth_error from a prior
        # daemon process is genuinely stale and we clear it. If the
        # server rejects with sso_required, leave the error in place so
        # `hivemind status` keeps showing the warning until the user
        # runs `hivemind login` and the recovery poll catches it.
        try:
            _hb = await syncer.heartbeat()
        except Exception:
            _hb = None
        _startup_srv = state.get_server_state(effective_endpoint)
        if _hb is not None and _hb.ok and _startup_srv.last_auth_error:
            logger.info(
                "Startup heartbeat OK; clearing stale auth error: %s",
                _startup_srv.last_auth_error,
            )
            _mark_auth_healthy(state, state_file, effective_endpoint)

    # Set up web session polling (if enabled, not in test mode, and Claude credentials exist)
    web_poller: WebSessionPoller | None = None
    web_syncer: WebSessionSyncer | None = None
    web_client: WebSessionsClient | None = None

    if not test_mode and config.web_sessions.enabled and has_claude_credentials():
        try:
            web_client = WebSessionsClient()
            web_poller = WebSessionPoller(
                client=web_client,
                poll_interval=float(config.web_sessions.poll_interval),
            )
            # Skip initial poll if daemon ran recently (within poll interval)
            # This prevents scanning all web sessions on every dev reload
            time_since_last_run = time.time() - server_state.last_daemon_run_ts
            if (
                server_state.last_daemon_run_ts > 0
                and time_since_last_run < web_poller._poll_interval
            ):
                web_poller._last_poll_time = time.monotonic()
                logger.debug(
                    f"Skipping initial web poll (daemon ran {time_since_last_run:.0f}s ago)"
                )
            if creds and not auth.store.is_expired(creds, buffer_seconds=0):
                web_syncer = _create_web_syncer(
                    creds,
                    effective_endpoint,
                    state,
                    web_client,
                    private_sessions=config.sessions.private,
                    org_repos=config.sessions.org_repos,
                    private_repos=config.sessions.private_repos,
                )
            click.echo(
                f"  Web sync:   Enabled (poll interval: {config.web_sessions.poll_interval}s)"
            )
            logger.info(
                f"Web session polling enabled (interval: {config.web_sessions.poll_interval}s)"
            )
        except Exception as e:
            logger.warning(f"Failed to initialize web session polling: {e}")
            web_poller = None
            web_syncer = None
    elif config.web_sessions.enabled:
        click.echo("  Web sync:   Disabled (no Claude credentials)")
        logger.info("Web session polling disabled: no Claude credentials found")
    else:
        click.echo("  Web sync:   Disabled (config)")
        logger.info("Web session polling disabled by configuration")

    # Run historic import on first boot (if authenticated and not skipped)
    if syncer and not server_state.historic_import_completed and not skip_historic_import:
        try:
            await _run_historic_import(syncer, state, base_endpoint, state_file=state_file)
            server_state.historic_import_ts = int(time.time())
            save_state(state, state_file)
        except Exception as e:
            logger.error(f"Historic import failed: {e}")
            # Continue anyway - we'll try again on next boot
    elif skip_historic_import and not server_state.historic_import_completed:
        click.echo("  Skipping historic import (--skip-historic-import)")
        logger.info("Historic import skipped via CLI flag")

    # Token fingerprint captured when sync is paused due to sso_required.
    # The recovery poll in the main loop compares the current credential
    # store token against this value and rebuilds the syncer when a fresh
    # login is detected. Declared here (above pre-catchup) so the
    # pre-catchup refresh-failure handler can enter the same pause state
    # as the main sync loop.
    paused_token_fingerprint: str | None = None

    # Run catch-up sync if historic import already completed (daemon was restarted)
    # This syncs sessions modified while the daemon was stopped
    if syncer and server_state.historic_import_completed and not skip_catchup:
        try:
            # Refresh creds so the server has fresh github_orgs for org resolution.
            # get_token() short-circuits for env-aware OIDC tokens that aren't
            # near expiry — those re-mint via env vars and have no user cache.
            try:
                await auth.get_token(force_refresh=True)
                new_creds = auth.get_current_credentials()
                if new_creds:
                    syncer = _create_syncer(
                        new_creds,
                        effective_endpoint,
                        state,
                        private_sessions=config.sessions.private,
                        org_repos=config.sessions.org_repos,
                        private_repos=config.sessions.private_repos,
                    )
                    logger.info("Pre-catchup token refresh succeeded")
            except AuthError as refresh_err:
                # Don't continue with a stale syncer that will 401 on every
                # upload until the ~5 min heartbeat catches it. Pause now so
                # the main loop's recovery poll picks up the next login.
                _pause_sync(
                    state,
                    state_file,
                    effective_endpoint,
                    _PAUSE_REASON_LOGIN_REQUIRED,
                    _AUTH_ERR_REFRESH_MSG,
                    trigger="pre_catchup_refresh",
                    detail=str(refresh_err),
                    auth=auth,
                )
                paused_token_fingerprint = syncer.auth_token if syncer is not None else None
                syncer = None
            except Exception as refresh_err:
                logger.warning(f"Pre-catchup token refresh failed: {refresh_err}")

            if syncer is None:
                # Refresh failed and we paused above; skip catch-up entirely.
                # The main loop's recovery poll will resume sync once the
                # user runs `hivemind login`.
                click.echo("  Catch-up: skipped (auth paused)")
            else:
                stats = await _run_catchup_sync(syncer, state, base_endpoint, state_file=state_file)
                click.echo(f"  Catch-up: {stats['success']} synced, {stats['skipped']} skipped")
            # Update last_daemon_run_ts after catch-up
            server_state.last_daemon_run_ts = int(time.time())
            save_state(state, state_file)
        except Exception as e:
            logger.error(f"Catch-up sync failed: {e}")
            # Continue anyway - live sync will catch changes
    elif skip_catchup and server_state.historic_import_completed:
        click.echo("  Skipping catch-up sync (--skip-catchup)")
        logger.info("Catch-up sync skipped via CLI flag")

    # Set up shutdown, reload, and flush events
    shutdown_event = asyncio.Event()
    reload_event = asyncio.Event()
    flush_event = asyncio.Event()

    def handle_shutdown(signum: int) -> None:
        logger.info(f"Received signal {signum}, shutting down...")
        shutdown_event.set()

    def handle_reload(signum: int) -> None:
        logger.info(f"Received SIGHUP (signal {signum}), will reload config...")
        reload_event.set()

    def handle_flush(signum: int) -> None:
        logger.debug("Received SIGUSR1, triggering immediate sync...")
        flush_event.set()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, handle_shutdown, sig)
    loop.add_signal_handler(signal.SIGHUP, handle_reload, signal.SIGHUP)
    loop.add_signal_handler(signal.SIGUSR1, handle_flush, signal.SIGUSR1)

    # Start watcher for session files
    watch_paths = get_watch_paths()

    # If in dev mode, show the repo we're running from
    if os.environ.get("HIVEMIND_DEV_MODE") == "1":
        config = load_config()
        if config.dev.repo:
            dev_repo_path = Path(config.dev.repo).expanduser().resolve()
            click.echo(f"  Dev repo:   {dev_repo_path}")
            logger.info(f"Running from dev repo: {dev_repo_path}")

    click.echo(f"  Watching:   {len(watch_paths)} directories")
    logger.info(f"Watching paths: {[str(p) for p in watch_paths]}")

    # Watcher collects changed paths - expensive processing happens in the main loop.
    # The on_change callback wakes the daemon loop via flush_event so that file
    # changes are synced within seconds instead of waiting for the full interval.
    # Debounced to avoid waking on every write during streaming output.
    # When an event is suppressed, a deferred flush is scheduled so the last
    # write in a burst is always picked up within the debounce window.
    _last_watcher_flush = 0.0
    _WATCHER_DEBOUNCE_S = 2.0
    _deferred_flush_handle: asyncio.TimerHandle | None = None

    # These helpers run on the event loop thread (called via call_soon_threadsafe)
    # so _deferred_flush_handle is only accessed from one thread. _flush_now
    # must reset _last_watcher_flush — otherwise the next file change passes
    # the debounce check immediately and triggers a back-to-back sync.
    def _flush_now() -> None:
        nonlocal _deferred_flush_handle, _last_watcher_flush
        if _deferred_flush_handle is not None:
            _deferred_flush_handle.cancel()
            _deferred_flush_handle = None
        _last_watcher_flush = time.monotonic()
        flush_event.set()

    def _schedule_deferred_flush(delay: float) -> None:
        nonlocal _deferred_flush_handle
        if _deferred_flush_handle is not None:
            _deferred_flush_handle.cancel()
        _deferred_flush_handle = loop.call_later(delay, _flush_now)

    def _watcher_on_change(path: Path) -> None:
        now = time.monotonic()
        if now - _last_watcher_flush < _WATCHER_DEBOUNCE_S:
            # Suppressed by debounce — schedule a deferred flush so the
            # pending change is picked up after the debounce window expires.
            remaining = _WATCHER_DEBOUNCE_S - (now - _last_watcher_flush) + 0.05
            loop.call_soon_threadsafe(_schedule_deferred_flush, remaining)
            return
        loop.call_soon_threadsafe(_flush_now)

    watcher = SessionWatcher(watch_paths=watch_paths, on_change=_watcher_on_change)
    watcher.start()

    # Set up config file watcher
    config_observer = None

    class ConfigEventHandler(FileSystemEventHandler):
        def __init__(self, config_file: Path, reload_evt: asyncio.Event):
            self.config_file = config_file
            self.reload_evt = reload_evt

        def _is_config_file(self, event_path: str | bytes) -> bool:
            # Handle both str and bytes from watchdog
            path_str = os.fsdecode(event_path) if isinstance(event_path, bytes) else event_path
            return Path(path_str).resolve() == self.config_file.resolve()

        def on_modified(  # type: ignore[override]
            self, event: FileModifiedEvent
        ) -> None:
            if not event.is_directory and self._is_config_file(event.src_path):
                logger.info("Config file changed, will reload...")
                self.reload_evt.set()

        def on_created(  # type: ignore[override]
            self, event: FileCreatedEvent
        ) -> None:
            if not event.is_directory and self._is_config_file(event.src_path):
                logger.info("Config file created, will reload...")
                self.reload_evt.set()

    if config_path.parent.exists():
        config_observer = Observer()
        config_handler = ConfigEventHandler(config_path, reload_event)
        try:
            config_observer.schedule(config_handler, str(config_path.parent), recursive=False)
            config_observer.start()
            logger.info(f"Watching config file: {config_path}")
        except OSError as e:
            logger.warning(f"Could not watch config file: {e}")
            config_observer = None

    # Channels v2: channel server moved to backend API — no daemon-side server needed
    else:
        click.echo("  Channels:   Disabled")

    # Set up tmux relay for sending messages to agent sessions
    tmux_relay = None
    if relay and not test_mode and is_tmux_available():
        if syncer:
            _github_id = github_id_from_token(creds.token) if creds else 0
            tmux_relay = TmuxRelay(
                base_url=base_endpoint,
                token=creds.token if creds else "",
                shutdown_event=shutdown_event,
                github_id=_github_id,
            )

            # Boot recovery: reconnect to any running alpha-launched sessions
            # (panes that still have @hivemind_pane_id set)
            for pane in get_marked_panes():
                await tmux_relay.register_session(
                    marker=pane["marker"],
                    agent=pane["agent"],
                    pane_target=pane["target"],
                )

            # Also process any launch files that arrived before/during boot

            for record, launch_path in check_for_launches():
                await tmux_relay.register_session(
                    marker=record.marker,
                    agent=record.agent,
                    pane_target=record.pane_target,
                )
                delete_launch(launch_path)

            if tmux_relay.active_count > 0:
                click.echo(f"  Tmux relay: Enabled ({tmux_relay.active_count} recovered)")
            else:
                click.echo("  Tmux relay: Enabled")
        else:
            click.echo("  Tmux relay: Disabled (not authenticated)")
    elif relay and not test_mode:
        click.echo("  Tmux relay: Disabled (tmux not running)")

    click.echo("Daemon ready. Press Ctrl+C to stop.")

    # Flush stdout so banner text is written to the log file immediately.
    # When running as a background service, stdout is redirected to a file
    # and Python uses full buffering, so click.echo output may not appear
    # on disk until the buffer fills or the process exits.
    sys.stdout.flush()

    daemon_start_time = time.monotonic()
    track(
        "daemon.started",
        {
            "version": __version__,
        },
    )
    flush_telemetry()

    # Self-update watcher: gated on [daemon] auto_upgrade != "off".
    # APPLY mode also sets shutdown_event so the supervisor restarts us
    # on the new binary.
    #
    # Constructed lazily so we can also start/stop it on config reload below.
    upgrade_task: asyncio.Task[None] | None = None
    detected_method: str = "unknown"

    async def _start_upgrade_watcher() -> asyncio.Task[None] | None:
        nonlocal detected_method
        if test_mode or UpgradeWatcher.disabled_via_env():
            return None
        if detected_method == "unknown":
            try:
                detected_method = await asyncio.to_thread(detect_install_method)
            except Exception:
                pass
        watcher = UpgradeWatcher(
            state=state,
            state_file=state_file,
            current_version=__version__,
            shutdown_event=shutdown_event,
            install_method=detected_method,
            apply_enabled=lambda: config.daemon.auto_upgrade == UpgradeMode.APPLY,
        )
        return asyncio.create_task(watcher.run(), name="hivemind-upgrade-watcher")

    if config.daemon.auto_upgrade != UpgradeMode.OFF:
        upgrade_task = await _start_upgrade_watcher()

    # Heartbeat is gated on wall-clock time, not loop iterations: the loop
    # wakes early on flush_event whenever a watched file changes (Cursor's
    # state.vscdb gets touched ~every 2s even idle), which would fire an
    # iteration-counter heartbeat 15× faster than the intended cadence.
    HEARTBEAT_INTERVAL_S = 300.0  # 5 minutes
    last_heartbeat_ts = time.monotonic()
    watcher_events_seen: dict[str, int] = defaultdict(int)
    synced_sessions: dict[str, int] = defaultdict(int)

    try:
        while not shutdown_event.is_set():
            # When the user completes `hivemind login` from another terminal,
            # the stored token changes and we resume without a daemon restart.
            if syncer is None and paused_token_fingerprint is not None:
                try:
                    reloaded = auth.store.load(auth.endpoint)
                except Exception:
                    reloaded = None
                # Use exact expiry (no refresh buffer) so a freshly minted
                # short-TTL token (e.g. HIVEMIND_OIDC_TOKEN_TTL_SECONDS in QA)
                # isn't classified as already-expired by the default 3600s
                # buffer, which would block resume forever.
                if reloaded is not None and _is_resumable_after_pause(
                    reloaded,
                    paused_token_fingerprint,
                    expired=auth.store.is_expired(reloaded, buffer_seconds=0),
                ):
                    logger.info(
                        "Detected fresh credentials for %s (method=%s). Resuming sync.",
                        reloaded.github_user,
                        reloaded.auth_method,
                    )
                    track(
                        "daemon.sso_resolved",
                        {
                            "method": reloaded.auth_method or "unknown",
                        },
                    )
                    syncer = _create_syncer(
                        reloaded,
                        effective_endpoint,
                        state,
                        private_sessions=config.sessions.private,
                        org_repos=config.sessions.org_repos,
                        private_repos=config.sessions.private_repos,
                    )
                    paused_token_fingerprint = None
                    set_telemetry_paused(False)
                    # Point the relay at the (possibly new) endpoint with the
                    # fresh token so future launches hit the right server.
                    if tmux_relay:
                        tmux_relay.update_credentials(
                            get_base_endpoint(effective_endpoint), reloaded.token
                        )
                    _mark_auth_healthy(state, state_file, effective_endpoint)

            # Periodic heartbeat log so operators can confirm the daemon is
            # alive. Gated on wall-clock time (not loop_count) so the cadence
            # stays at HEARTBEAT_INTERVAL_S regardless of how often
            # flush_event wakes the loop.
            now_mono = time.monotonic()
            if now_mono - last_heartbeat_ts >= HEARTBEAT_INTERVAL_S:
                last_heartbeat_ts = now_mono
                tracked = len(server_state.sessions) if server_state else 0
                logger.info(
                    "Heartbeat: alive, %s sessions tracked | watcher_events=%s | synced=%s%s",
                    tracked,
                    dict(watcher_events_seen),
                    dict(synced_sessions),
                    "" if syncer else " | no syncer (auth pending?)",
                )
                if syncer:
                    try:
                        hb = await syncer.heartbeat()
                    except Exception:
                        logger.warning("Server heartbeat failed (network error)", exc_info=False)
                        hb = None
                    if hb is not None:
                        if hb.ok:
                            # Positive auth-health proof even on idle daemons.
                            _mark_auth_healthy(state, state_file, effective_endpoint)
                            if hb.needs_token_refresh:
                                logger.info("Server requested token refresh via heartbeat response")
                        elif hb.needs_token_refresh:
                            try:
                                _current = auth.store.load(auth.endpoint)
                                _current_method = _current.auth_method if _current else "?"
                            except Exception:
                                _current_method = "?"
                            logger.info(
                                "Heartbeat token refresh needed (current auth_method=%s), "
                                "re-authenticating...",
                                _current_method,
                            )
                            # Use the shared non-interactive helper so SSO
                            # detection, refresh-token gating, and the
                            # PermanentAuthError contract match the startup
                            # and proactive-refresh paths exactly.
                            refresh_err: Exception | None = None
                            refreshed = False
                            try:
                                refreshed = await _try_noninteractive_auth(auth)
                            except PermanentAuthError as err:
                                logger.error("Token refresh permanently rejected: %s", err)
                                refresh_err = err
                            except Exception as err:
                                logger.warning(f"Token refresh via heartbeat failed: {err}")
                                refresh_err = err

                            if refreshed:
                                new_creds = auth.store.load(auth.endpoint)
                                if new_creds:
                                    syncer = _create_syncer(
                                        new_creds,
                                        effective_endpoint,
                                        state,
                                        private_sessions=config.sessions.private,
                                        org_repos=config.sessions.org_repos,
                                        private_repos=config.sessions.private_repos,
                                    )
                                    set_telemetry_paused(False)
                                    logger.info(f"Re-authenticated as {new_creds.github_user}")
                            elif refresh_err is None:
                                # Refresh quietly returned False (e.g. OIDC
                                # user with no usable refresh path). Pause
                                # sync until an interactive `hivemind login`.
                                _pause_sync(
                                    state,
                                    state_file,
                                    effective_endpoint,
                                    _PAUSE_REASON_LOGIN_REQUIRED,
                                    _AUTH_ERR_REFRESH_MSG,
                                    trigger="heartbeat_refresh",
                                    detail="silent refresh unavailable",
                                    auth=auth,
                                )
                                paused_token_fingerprint = (
                                    syncer.auth_token if syncer is not None else None
                                )
                                syncer = None
                            elif isinstance(refresh_err, AuthError):
                                _pause_sync(
                                    state,
                                    state_file,
                                    effective_endpoint,
                                    _PAUSE_REASON_LOGIN_REQUIRED,
                                    _AUTH_ERR_REFRESH_MSG,
                                    trigger="heartbeat_refresh",
                                    detail=str(refresh_err),
                                    auth=auth,
                                )
                                paused_token_fingerprint = (
                                    syncer.auth_token if syncer is not None else None
                                )
                                syncer = None
                        elif hb.sso_required:
                            # No client-side track() — the daemon's bearer is the
                            # exact one the server just rejected with 403, so the
                            # POST to /v1/telemetry/track would 403 too. The API
                            # logs sso_required rejections server-side instead.
                            _pause_sync(
                                state,
                                state_file,
                                effective_endpoint,
                                _PAUSE_REASON_SSO_REQUIRED,
                                _AUTH_ERR_SSO_MSG,
                                trigger="heartbeat",
                                detail=hb.sso_org_id or "",
                                auth=auth,
                            )
                            auth.mark_sso_required(hb.sso_org_id or None)
                            paused_token_fingerprint = (
                                syncer.auth_token if syncer is not None else None
                            )
                            syncer = None

            # Process pending launch registrations (file-drop IPC from `alpha launch`)
            # and prune relays for sessions whose pane marker was cleared (agent exited).
            if tmux_relay:
                for record, launch_path in check_for_launches():
                    await tmux_relay.register_session(
                        marker=record.marker,
                        agent=record.agent,
                        pane_target=record.pane_target,
                    )
                    delete_launch(launch_path)

                await tmux_relay.prune_exited()

            # Check for config reload (SIGHUP or config file change)
            if reload_event.is_set():
                reload_event.clear()

                # Reload config
                config = load_config(config_path)
                new_endpoint = get_effective_endpoint(config_path)
                new_source = _get_endpoint_source(config_path)

                # Update session privacy on existing syncers
                if syncer:
                    syncer.private_sessions = config.sessions.private
                    syncer.org_repos = config.sessions.org_repos
                    syncer.private_repos = config.sessions.private_repos
                if web_syncer:
                    web_syncer.private_sessions = config.sessions.private
                    web_syncer.org_repos = config.sessions.org_repos
                    web_syncer.private_repos = config.sessions.private_repos

                # OFF stops the watcher; NOTIFY/APPLY both need it running.
                # apply_enabled closes over config so APPLY/NOTIFY flips
                # don't need a watcher restart.
                want_watcher = config.daemon.auto_upgrade != UpgradeMode.OFF
                have_watcher = upgrade_task is not None and not upgrade_task.done()
                if want_watcher and not have_watcher:
                    logger.info(
                        "Starting upgrade watcher (auto_upgrade=%s)",
                        config.daemon.auto_upgrade.value,
                    )
                    upgrade_task = await _start_upgrade_watcher()
                elif not want_watcher and have_watcher:
                    logger.info("Stopping upgrade watcher (auto_upgrade=off)")
                    assert upgrade_task is not None
                    upgrade_task.cancel()
                    try:
                        await upgrade_task
                    except (asyncio.CancelledError, Exception):
                        pass
                    upgrade_task = None

                if new_endpoint != effective_endpoint:
                    logger.info(
                        f"Endpoint changed: {effective_endpoint} -> {new_endpoint} ({new_source})"
                    )
                    effective_endpoint = new_endpoint

                    # Update server_state to track the new endpoint
                    base_endpoint = get_base_endpoint(effective_endpoint)
                    server_state = state.get_server_state(base_endpoint)

                    if not test_mode:
                        # Recreate auth manager with new endpoint
                        auth = AuthManager(endpoint=base_endpoint, config=config)

                        # Only force-refresh when we already have stored creds
                        # for the new endpoint. Without this guard, get_token
                        # falls through to auth discovery and silently mints an
                        # ssh_signature token against an endpoint the user has
                        # never logged in to — which SSO-enforced orgs then
                        # reject with 403 on every subsequent upload. Wait for
                        # an interactive `hivemind login` instead; the recovery
                        # poll at the top of each loop picks up the new token.
                        #
                        # If the keychain is locked we treat it as "no usable
                        # creds" rather than letting the exception terminate
                        # the daemon mid-reload.
                        try:
                            existing_creds = auth.store.load_raw(auth.endpoint)
                        except KeychainLockedError as err:
                            existing_creds = None
                            logger.warning(
                                "Keychain locked while probing credentials for %s: %s. "
                                "Treating as unauthenticated; unlock the keychain and "
                                "re-run 'hivemind login' to resume.",
                                effective_endpoint,
                                err,
                            )
                        if existing_creds:
                            try:
                                await auth.get_token(force_refresh=True)
                                logger.info("Token refreshed for new endpoint")
                            except Exception as refresh_err:
                                logger.warning(
                                    f"Token refresh for new endpoint failed: {refresh_err}"
                                )

                        # Recreate syncer if authenticated (using new endpoint's credentials).
                        # get_current_credentials() returns in-memory env/OIDC creds when
                        # an active provider supplied them, falling back to the on-disk
                        # store. Keychain errors only surface from the disk path.
                        try:
                            creds = auth.get_current_credentials()
                        except KeychainLockedError as err:
                            creds = None
                            logger.warning(
                                "Keychain locked while loading credentials for %s: %s. "
                                "Syncing paused until the keychain is unlocked.",
                                effective_endpoint,
                                err,
                            )
                        if creds and not auth.store.is_expired(creds):
                            syncer = _create_syncer(
                                creds,
                                effective_endpoint,
                                state,
                                private_sessions=config.sessions.private,
                                org_repos=config.sessions.org_repos,
                                private_repos=config.sessions.private_repos,
                            )
                            # Clear any stale pause state from the previous
                            # endpoint; the new syncer is healthy.
                            paused_token_fingerprint = None
                            logger.info(
                                f"Syncer recreated with new endpoint for {creds.github_user}"
                            )
                            # Also recreate web syncer if enabled
                            if web_client:
                                web_syncer = _create_web_syncer(
                                    creds,
                                    effective_endpoint,
                                    state,
                                    web_client,
                                    private_sessions=config.sessions.private,
                                    org_repos=config.sessions.org_repos,
                                    private_repos=config.sessions.private_repos,
                                )
                                logger.info("Web syncer recreated with new endpoint")

                            # Point the tmux relay at the new endpoint. Existing
                            # relay tasks were spawned with the old base_url/token
                            # so we stop them (notifies the old backend of
                            # disconnects) and re-register currently marked panes
                            # against the new endpoint.
                            if tmux_relay:
                                await tmux_relay.stop()
                                tmux_relay.update_credentials(base_endpoint, creds.token)
                                for pane in get_marked_panes():
                                    await tmux_relay.register_session(
                                        marker=pane["marker"],
                                        agent=pane["agent"],
                                        pane_target=pane["target"],
                                    )

                            # Run catch-up sync for the new endpoint
                            # This ensures sessions are synced to the new server,
                            # not just forwarding live changes
                            try:
                                stats = await _run_catchup_sync(
                                    syncer, state, base_endpoint, state_file=state_file
                                )
                                click.echo(
                                    f"  Catch-up: {stats['success']} synced, "
                                    f"{stats['skipped']} skipped"
                                )
                                server_state.last_daemon_run_ts = int(time.time())
                                save_state(state, state_file)
                            except Exception as e:
                                logger.error(f"Catch-up sync after endpoint change failed: {e}")
                        else:
                            syncer = None
                            web_syncer = None
                            # Cancel any in-flight relay tasks so they stop
                            # hitting the previous endpoint with stale creds.
                            # The relay object is preserved so the recovery
                            # poll can re-register sessions once creds land.
                            if tmux_relay:
                                await tmux_relay.stop()
                                tmux_relay.update_credentials(base_endpoint, "")
                            # Prime the recovery poll so a subsequent
                            # `hivemind login` for the new endpoint is picked
                            # up within one loop iteration. Empty string is a
                            # sentinel: any real token will compare unequal.
                            paused_token_fingerprint = ""
                            logger.info(
                                "No credentials for %s — syncing paused. "
                                "Run 'hivemind login' to authenticate.",
                                effective_endpoint,
                            )
                else:
                    logger.info(f"Config reloaded, endpoint unchanged: {effective_endpoint}")

            # Check for reset triggers at the start of each sync cycle
            triggers = check_for_triggers()
            for trigger in triggers:
                agent_type = trigger["agent_type"]
                trigger_file = trigger["_file_path"]
                requested_by = trigger.get("requested_by", "unknown")

                try:
                    cleared_count = clear_sessions_by_agent_type(state, agent_type)
                    logger.info(
                        f"Reset trigger processed: cleared {cleared_count} {agent_type} sessions "
                        f"(requested by: {requested_by})"
                    )
                    # Delete trigger file as acknowledgment
                    delete_trigger(trigger_file)
                    # Save state immediately after clearing
                    if cleared_count > 0:
                        save_state(state, state_file)

                    # Re-discover and sync sessions directly (bypass hot tracker's 100 limit)
                    # This ensures ALL sessions are re-synced, not just 100
                    all_sessions = discover_all_sessions(Path.home(), since_ts=None)
                    matching_sessions = [s for s in all_sessions if s.get("format") == agent_type]
                    if matching_sessions and syncer:
                        logger.info(
                            f"Re-discovered {len(matching_sessions)} {agent_type} sessions, "
                            f"syncing directly..."
                        )
                        # Sync each session directly instead of through hot tracker
                        success = 0
                        skipped = 0
                        failed = 0
                        for session in matching_sessions:
                            session_id = session["id"]
                            file_path = Path(session["path"])
                            source_format = session.get("format", agent_type)
                            try:
                                # Build metadata - unified for all formats (including Cursor)
                                metadata = extract_session_metadata(session)
                                outcome = await asyncio.wait_for(
                                    syncer.sync_session(
                                        session_id=session_id,
                                        file_path=file_path,
                                        source_format=source_format,
                                        metadata=metadata,
                                    ),
                                    timeout=PER_SESSION_SYNC_TIMEOUT,
                                )
                                if outcome.result == SyncResult.SYNCED:
                                    success += 1
                                elif outcome.result == SyncResult.SKIPPED:
                                    skipped += 1
                                else:
                                    failed += 1
                            except asyncio.TimeoutError:
                                logger.debug(
                                    f"Resync timed out for {session_id[:16]}... "
                                    f"after {PER_SESSION_SYNC_TIMEOUT}s"
                                )
                                failed += 1
                            except Exception as e:
                                logger.debug(f"Resync error for {session_id[:16]}...: {e}")
                                failed += 1
                        logger.info(
                            f"Resync complete: {success} synced, {skipped} skipped, {failed} failed"
                        )
                        save_state(state, state_file)
                    elif matching_sessions:
                        logger.warning(
                            f"Found {len(matching_sessions)} {agent_type} sessions but no syncer "
                            f"(not authenticated?)"
                        )
                    else:
                        logger.info(f"No {agent_type} sessions found on disk to re-sync")
                except Exception as e:
                    logger.error(f"Failed to process reset trigger for {agent_type}: {e}")

            # Proactive token refresh
            if syncer:
                syncer = await _maybe_refresh_token(auth, syncer, state, effective_endpoint)
                # Keep the relay's credentials in sync after a token refresh
                if tmux_relay and syncer:
                    tmux_relay.update_credentials(
                        get_base_endpoint(syncer.endpoint), syncer.auth_token
                    )

            # Process pending file changes from watcher
            # This moves expensive work (SQLite queries, JSON parsing) out of
            # the watchdog callback thread and into the main async loop

            pending_paths = watcher.drain_pending()
            if pending_paths:
                logger.debug(f"Processing {len(pending_paths)} pending file changes")
                for path in pending_paths:
                    logger.debug(f"  File changed: {path}")
                    try:
                        # Cursor bubbles are written to globalStorage/state.vscdb; that file
                        # doesn't list composers, so we need to check which Cursor sessions
                        # have new entries. Use incremental scan to avoid processing all 400+
                        # sessions on every change.
                        #
                        # Note: SQLite WAL mode writes may not trigger FSEvents reliably on
                        # macOS, but state.vscdb.options.json does get updated. We trigger on
                        # any state.vscdb* file change to catch updates.
                        if "globalStorage" in path.parts and path.name.startswith("state.vscdb"):
                            watcher_events_seen["cursor"] += 1
                            # Normalize path to the main database file for querying
                            global_db_path = path.parent / "state.vscdb"
                            logger.debug(
                                f"globalStorage change detected: {path} (using {global_db_path.name})"
                            )
                            server_state = state.get_server_state(effective_endpoint)
                            last_scan_ts = server_state.cursor_last_global_scan_ts
                            logger.debug(f"  cursor_last_global_scan_ts={last_scan_ts}")

                            # Get composerIds with bubbles created after our last scan
                            scan_result = get_recent_cursor_composer_ids(
                                global_db_path, since_ts_ms=last_scan_ts
                            )
                            logger.debug(
                                f"  scan_result: {len(scan_result.composer_ids)} composers, "
                                f"max_bubble_ts={scan_result.max_bubble_ts}"
                            )

                            if scan_result.composer_ids:
                                # Build mapping from composerId to workspace state.vscdb
                                cursor_user = global_db_path.parent.parent  # globalStorage -> User
                                workspace_map = build_composer_workspace_map(
                                    cursor_user, scan_result.composer_ids
                                )
                                logger.debug(f"  workspace_map has {len(workspace_map)} entries")
                                added_count = 0
                                for composer_id, (state_path, folder_path) in workspace_map.items():
                                    hot_tracker.add(composer_id, str(state_path))
                                    added_count += 1

                                if added_count > 0:
                                    logger.debug(
                                        f"Added {added_count} Cursor sessions with new bubbles "
                                        f"(queried {len(scan_result.composer_ids)} composerIds)"
                                    )
                            else:
                                logger.debug("  No recent composerIds found")

                            # Update scan timestamp to max bubble timestamp we found
                            # (not current time, to avoid race conditions with in-flight writes)
                            server_state.cursor_last_global_scan_ts = scan_result.max_bubble_ts
                            continue
                        source_format = _detect_source_format(path)
                        if source_format:
                            watcher_events_seen[source_format] += 1
                        from agentstream.adapters import extract_sessions_from_path  # noqa: PLC0415 — mocked in tests

                        sessions = extract_sessions_from_path(path)
                        if sessions:
                            logger.debug(
                                f"  extract_sessions_from_path returned {len(sessions)} sessions"
                            )
                        for session in sessions:
                            session_id = session["id"]
                            hot_tracker.add(session_id, str(path))
                    except Exception as e:
                        logger.warning(f"Error processing {path}: {e}")

            # Run sync cycle if we have a syncer
            if syncer:
                try:
                    stats = await _run_sync_cycle(
                        state=state,
                        hot_tracker=hot_tracker,
                        syncer=syncer,
                        state_file=state_file,
                    )
                    for agent_type, count in stats.get("synced_by_agent", {}).items():
                        synced_sessions[agent_type] += count
                    if stats["processed"] > 0:
                        # Only INFO-log when there's real progress — a cycle
                        # that drained N hot sessions and skipped them all
                        # (no new entries on disk yet) is just noise. Cursor's
                        # chatty SQLite writes wake us every ~2s and most
                        # cycles fall into this skipped-everything bucket.
                        result_line = (
                            f"Sync cycle: {stats['success']} succeeded, "
                            f"{stats['skipped']} skipped, {stats['failed']} failed "
                            f"({stats['processed']} processed)"
                        )
                        if stats["success"] > 0 or stats["failed"] > 0:
                            logger.info(result_line)
                        else:
                            logger.debug(result_line)
                        # Persist on success (last_entry_idx), on failure
                        # (quarantine state), and on quarantine clears that
                        # arrived via SKIPPED only — without the third case a
                        # session that recovers without producing new entries
                        # would stay quarantined across a restart.
                        if (
                            stats.get("success", 0) > 0
                            or stats.get("failed", 0) > 0
                            or stats.get("quarantine_cleared", 0) > 0
                        ):
                            save_state(state, state_file)
                    else:
                        logger.debug("Sync cycle: 0 sessions (no file changes this interval)")
                    # Positive auth-health proof: the server accepted at least
                    # one upload this cycle. The sso_required pause path runs
                    # further down with the full handler (fingerprint + syncer
                    # null). Cycles with processed > 0 but zero successes
                    # never reached the server, so we can't infer auth health
                    # from them — the heartbeat covers the empty-cycle case.
                    if stats.get("success", 0) > 0:
                        _mark_auth_healthy(state, state_file, effective_endpoint)
                    # Handle token refresh signal (server header or 401 with stale creds)
                    if stats.get("needs_token_refresh"):
                        # Capture the current credential's auth_method so the
                        # log clearly shows whether we're about to refresh an
                        # OIDC session or a github-based one. Useful for
                        # diagnosing unexpected refresh signals (e.g. JWT
                        # secret rotation race or empty org_id in JWT).
                        try:
                            _current = auth.get_current_credentials()
                            _current_method = _current.auth_method if _current else "?"
                        except Exception:
                            _current_method = "?"
                        logger.info(
                            "Token refresh needed (current auth_method=%s), re-authenticating...",
                            _current_method,
                        )
                        # Use the shared non-interactive helper so SSO
                        # detection, refresh-token gating, and the
                        # PermanentAuthError contract match every other
                        # refresh path (heartbeat, _maybe_refresh_token).
                        refresh_err: Exception | None = None
                        refreshed = False
                        try:
                            refreshed = await _try_noninteractive_auth(auth)
                        except PermanentAuthError as err:
                            logger.error("Token refresh permanently rejected: %s", err)
                            refresh_err = err
                        except Exception as err:
                            logger.warning(f"Re-authentication failed: {err}")
                            refresh_err = err

                        if refreshed:
                            # get_current_credentials() returns in-memory env/OIDC creds
                            # when the active provider supplied them, otherwise reads from
                            # the disk store.
                            new_creds = auth.get_current_credentials()
                            if new_creds:
                                syncer = _create_syncer(
                                    new_creds,
                                    effective_endpoint,
                                    state,
                                    private_sessions=config.sessions.private,
                                    org_repos=config.sessions.org_repos,
                                    private_repos=config.sessions.private_repos,
                                )
                                logger.info(f"Re-authenticated as {new_creds.github_user}")
                        elif refresh_err is None or isinstance(refresh_err, AuthError):
                            # Refresh failed (returned False or raised an
                            # AuthError, which includes PermanentAuthError).
                            # Pause sync and wait for interactive login.
                            _pause_sync(
                                state,
                                state_file,
                                effective_endpoint,
                                _PAUSE_REASON_LOGIN_REQUIRED,
                                _AUTH_ERR_REFRESH_MSG,
                                trigger="refresh_signal",
                                detail=str(refresh_err)
                                if refresh_err
                                else "silent refresh unavailable",
                                auth=auth,
                            )
                            paused_token_fingerprint = (
                                syncer.auth_token if syncer is not None else None
                            )
                            syncer = None
                    # Handle SSO upgrade signal (403 sso_required).
                    #
                    # The daemon runs non-interactively under launchd/systemd,
                    # so we cannot open a browser here. Previously we tried
                    # `oidc_browser` anyway, raised immediately, and `break`ed
                    # out of the sync loop — the daemon exited, launchd
                    # restarted it, and the cycle repeated every few seconds.
                    #
                    # Instead, pause sync (drop the syncer), persist the auth
                    # error, and KEEP THE DAEMON RUNNING. The top of each
                    # cycle will poll the credential store for a new token
                    # (e.g. from `hivemind login` in another terminal)
                    # and resume sync automatically when one arrives.
                    if stats.get("sso_required"):
                        sso_oid = stats.get("sso_org_id", "")
                        # No client-side track() — the bearer was just rejected
                        # with 403 sso_required, so /v1/telemetry/track would
                        # reject too. The API logs sso_required server-side.
                        auth.mark_sso_required(sso_oid or None)
                        # CRITICAL: snapshot the token the syncer was actually
                        # using when the rejection happened, NOT whatever's in
                        # the keychain right now. The user may have already
                        # run `hivemind login` between syncer creation and the
                        # 403, so reading the keychain here would capture the
                        # NEW token, the recovery poll would compare it to
                        # itself on the next iteration, find no change, and
                        # leave the daemon paused on stale state forever.
                        paused_token_fingerprint = syncer.auth_token if syncer is not None else None
                        _pause_sync(
                            state,
                            state_file,
                            effective_endpoint,
                            _PAUSE_REASON_SSO_REQUIRED,
                            _AUTH_ERR_SSO_MSG,
                            trigger="sync_403",
                            detail=sso_oid,
                            auth=auth,
                        )
                        syncer = None
                except Exception as e:
                    logger.error(f"Sync cycle error: {e}")

            # Poll and sync web sessions (if enabled)
            if web_poller and web_syncer and web_poller.should_poll:
                try:
                    web_sessions = await web_poller.poll()
                    if web_sessions:
                        web_stats = await sync_web_sessions(
                            web_sessions, web_syncer, reload_event=reload_event
                        )
                        if web_stats["total"] > 0:
                            logger.info(
                                f"Web sync: {web_stats['success']}/{web_stats['total']} succeeded"
                            )
                        # Handle token refresh signal (server header or 401 with stale creds)
                        if web_stats.get("needs_token_refresh"):
                            logger.info("Token refresh needed, re-authenticating...")
                            try:
                                await auth.get_token(force_refresh=True)
                                new_creds = auth.get_current_credentials()
                                if new_creds and web_client:
                                    syncer = _create_syncer(
                                        new_creds,
                                        effective_endpoint,
                                        state,
                                        private_sessions=config.sessions.private,
                                        org_repos=config.sessions.org_repos,
                                        private_repos=config.sessions.private_repos,
                                    )
                                    web_syncer = _create_web_syncer(
                                        new_creds,
                                        effective_endpoint,
                                        state,
                                        web_client,
                                        private_sessions=config.sessions.private,
                                        org_repos=config.sessions.org_repos,
                                        private_repos=config.sessions.private_repos,
                                    )
                                    logger.info(f"Re-authenticated as {new_creds.github_user}")
                            except Exception as refresh_err:
                                logger.warning(f"Re-authentication failed: {refresh_err}")
                except Exception as e:
                    logger.error(f"Web session sync error: {e}")
            # Update last_daemon_run_ts to track when daemon was last active
            # This is used by catch-up sync on next startup
            server_state.last_daemon_run_ts = int(time.time())

            # Prune old sessions to bound state file growth
            pruned = server_state.prune_old_sessions()
            if pruned:
                logger.info(f"Pruned {pruned} sessions older than 6 months from state")

            # Save state
            save_state(state, state_file)

            # Wait for interval, shutdown, or flush signal
            try:
                done, _ = await asyncio.wait(
                    [
                        asyncio.create_task(shutdown_event.wait()),
                        asyncio.create_task(flush_event.wait()),
                    ],
                    timeout=interval,
                    return_when=asyncio.FIRST_COMPLETED,
                )
                # Cancel pending waiters
                for task in _:
                    task.cancel()
                if shutdown_event.is_set():
                    break
                if flush_event.is_set():
                    flush_event.clear()
                    logger.debug("Flush signal received, running immediate sync cycle")
            except asyncio.TimeoutError:
                pass  # Normal timeout, continue loop

    finally:
        watcher.stop()
        if tmux_relay:
            await tmux_relay.stop()
        if config_observer is not None:
            config_observer.stop()
            config_observer.join(timeout=5)
        # Cancel and await the upgrade watcher task so we don't leave a
        # stray coroutine running after the main loop exits. The watcher
        # already checks shutdown_event between polls, so cancel is just
        # a defensive belt-and-suspenders here.
        if upgrade_task is not None and not upgrade_task.done():
            upgrade_task.cancel()
            try:
                await upgrade_task
            except (asyncio.CancelledError, Exception):
                pass
        # Update last_daemon_run_ts on shutdown for accurate catch-up sync on restart
        server_state.last_daemon_run_ts = int(time.time())
        save_state(state, state_file)
        uptime_s = int(time.monotonic() - daemon_start_time)
        track(
            "daemon.stopped",
            {
                "version": __version__,
                "uptime_s": uptime_s,
            },
        )
        flush_telemetry()
        logger.info(f"Daemon stopped. Final state: {len(state.sessions)} sessions tracked")


def _compare_versions(version1: str, version2: str) -> int:
    """Compare two PEP 440 versions.

    Returns:
        -1 if version1 < version2
        0 if version1 == version2
        1 if version1 > version2
    """

    try:
        v1, v2 = Version(version1), Version(version2)
        return -1 if v1 < v2 else (1 if v1 > v2 else 0)
    except Exception:
        return 0  # Can't compare, assume equal


def _version_callback(ctx: click.Context, param: click.Parameter, value: bool) -> None:
    if not value or ctx.resilient_parsing:
        return

    console = Console()
    console.print(f"hivemind [cyan]{__version__}[/cyan]")

    # Update check is binary-only; source installs upgrade via brew/uv-tool.
    if "__compiled__" in globals():
        endpoint = get_effective_endpoint()
        try:
            with httpx.Client(timeout=5) as client:
                response = client.get(f"{endpoint}/health")
                if response.status_code == 200:
                    min_version = response.json().get("min_daemon_version", "")
                    if min_version and _compare_versions(__version__, min_version) < 0:
                        console.print()
                        console.print(
                            f"[yellow]A new version is available (v{min_version}). "
                            "Run 'hivemind restart' to apply.[/yellow]"
                        )
        except Exception:
            pass

    ctx.exit()


@click.group(cls=HivemindGroup)
@click.option(
    "--version",
    "-V",
    is_flag=True,
    callback=_version_callback,
    expose_value=False,
    is_eager=True,
    help="Show version and check for updates.",
)
@click.option(
    "--dev",
    is_flag=True,
    hidden=True,
    help=f"Use local development server ({DEV_ENDPOINT})",
)
@click.option(
    "--qa",
    is_flag=True,
    hidden=True,
    help=f"Use QA server ({QA_ENDPOINT})",
)
@click.option(
    "--prod",
    is_flag=True,
    hidden=True,
    help=f"Use production server ({PROD_ENDPOINT})",
)
@click.option(
    "--dev-worktree",
    "dev_worktree",
    type=click.IntRange(1, 9),
    hidden=True,
    help=(
        "Use OrbStack worktree dev server (1-9), "
        f"e.g. --dev-worktree=1 → {DEV_WORKTREE_ENDPOINT.format(n=1)}"
    ),
)
@click.pass_context
def main(ctx: click.Context, dev: bool, qa: bool, prod: bool, dev_worktree: int | None):
    """Hivemind — sync agentic coding sessions to the cloud.

    \b
    Use 'hivemind start' to run the daemon and 'hivemind login' to authenticate.
    Run 'hivemind doctor' if something isn't working.
    """
    # Skip the SSL truststore injection for subcommands that never make
    # network calls. On corporate Macs with smart-card-loaded keychains,
    # truststore's first SSLContext construction can be tens of ms — no
    # reason to pay it for `install-service` / `hup` / local utilities.
    # `--help` and `--version` are eager click flags that exit before
    # this function body runs, so they're already free.
    if ctx.invoked_subcommand not in _LOCAL_ONLY_SUBCOMMANDS:
        configure_ssl()

    ctx.ensure_object(dict)
    ctx.obj["dev"] = dev or dev_worktree is not None

    # Check for mutually exclusive flags
    flags_set = sum([dev, qa, prod, dev_worktree is not None])
    if flags_set > 1:
        click.echo(
            "Error: --dev, --dev-worktree, --qa, and --prod are mutually exclusive",
            err=True,
        )
        raise SystemExit(1)

    if dev:
        set_endpoint_override(os.environ.get("HIVEMIND_ENDPOINT", DEV_ENDPOINT))
    elif dev_worktree is not None:
        set_endpoint_override(DEV_WORKTREE_ENDPOINT.format(n=dev_worktree))
    elif qa:
        set_endpoint_override(QA_ENDPOINT)
    elif prod:
        set_endpoint_override(PROD_ENDPOINT)


@main.command()
@click.option("--interval", default=30, help="Sync interval in seconds")
@click.option("--state-dir", type=click.Path(), default=str(DEFAULT_STATE_DIR))
@click.option(
    "--skip-historic-import",
    is_flag=True,
    help="Skip importing historic sessions on first boot",
)
@click.option(
    "--skip-catchup",
    is_flag=True,
    help="Skip catch-up sync for sessions modified while daemon was stopped",
)
@click.option(
    "--test-mode",
    is_flag=True,
    help="Run without authentication or syncing (for CI lifecycle tests). "
    "Also enabled by HIVEMIND_TEST_MODE=1 env var.",
)
@click.option(
    "--relay",
    is_flag=True,
    help="Enable the tmux PTY relay for remote-control channels (alpha).",
)
@click.pass_context
def run(
    ctx: click.Context,
    interval: int,
    state_dir: str,
    skip_historic_import: bool,
    skip_catchup: bool,
    test_mode: bool,
    relay: bool,
):
    """Run the daemon in the foreground (not daemonized).

    The endpoint is determined by (highest to lowest priority):
    1. --dev flag (http://localhost:8080) or --dev-worktree=N (http://api-wN.hivemind.local)
    2. Config file (~/.hivemind/config.toml)
    3. HIVEMIND_ENDPOINT environment variable
    4. Default endpoint

    When dev.repo is configured, the daemon will re-exec using the dev repo's
    Python interpreter. Use 'hivemind hup' to manually reload after code changes.
    """
    # Check for dev mode exec early, before any other initialization
    # This may call os.execve() and never return
    _maybe_exec_dev_mode()

    # Prune onefile cache dirs from older versions before the daemon
    # settles in. Cheap (directory listing + rmtree) and only relevant
    # when running from a Nuitka onefile binary, but safe in all modes.
    _prune_onefile_cache()

    # If we're in dev mode (re-exec'd), set up hupper for auto-reload
    if os.environ.get("HIVEMIND_DEV_MODE") == "1":
        config = load_config()
        if config.dev.repo and _run_with_hupper(config.dev.repo):
            # hupper started the reloader, return and let hupper take over
            return

    state_path = Path(state_dir)
    lock_file = state_path / "daemon.lock"

    try:
        with acquire_lock(lock_file):
            asyncio.run(
                _run_daemon(
                    interval=interval,
                    state_path=state_path,
                    skip_historic_import=skip_historic_import,
                    skip_catchup=skip_catchup,
                    test_mode=test_mode,
                    relay=relay,
                )
            )
    except RuntimeError as e:
        logger.error(str(e))
        sys.exit(1)


@main.command()
@click.option(
    "--interval",
    default=None,
    type=int,
    help="Sync interval in seconds (default: 5, override with HIVEMIND_MCP_POLL_INTERVAL).",
)
@click.option("--state-dir", type=click.Path(), default=str(DEFAULT_STATE_DIR))
@click.option(
    "--skip-historic-import",
    is_flag=True,
    help="Skip importing historic sessions on first boot.",
)
@click.option(
    "--skip-catchup",
    is_flag=True,
    help="Skip catch-up sync for sessions modified while daemon was stopped.",
)
def mcp(interval: int | None, state_dir: str, skip_historic_import: bool, skip_catchup: bool):
    """Run the daemon as an MCP server on stdio (stdout reserved for JSON-RPC)."""
    from hivemind.mcp.logging import setup_mcp_logging  # noqa: PLC0415

    setup_mcp_logging()

    from hivemind.mcp.server import DEFAULT_MCP_INTERVAL, Mode, run_mcp  # noqa: PLC0415

    if interval is None:
        env_val = os.environ.get("HIVEMIND_MCP_POLL_INTERVAL")
        try:
            interval = int(env_val) if env_val else DEFAULT_MCP_INTERVAL
        except ValueError:
            logger.warning(
                "Invalid HIVEMIND_MCP_POLL_INTERVAL=%r; using default %ds",
                env_val,
                DEFAULT_MCP_INTERVAL,
            )
            interval = DEFAULT_MCP_INTERVAL

    state_path = Path(state_dir)
    state_path.mkdir(parents=True, exist_ok=True)
    lock_file = state_path / "daemon.lock"

    def _run(mode: Mode) -> None:
        asyncio.run(
            run_mcp(
                state_path=state_path,
                interval=interval,
                skip_historic_import=skip_historic_import,
                skip_catchup=skip_catchup,
                mode=mode,
            )
        )

    try:
        with acquire_lock(lock_file):
            _run("active")
    except RuntimeError as e:
        if "already running" not in str(e):
            logger.error(str(e))
            sys.exit(1)
        logger.warning(
            "Another hivemind daemon already holds %s — running MCP server in "
            "passive_observer mode (existing daemon does the syncing).",
            lock_file,
        )
        _run("passive_observer")


@main.command()
@click.option("--foreground", "-f", is_flag=True, help="Run in foreground (same as 'hivemind run')")
@click.option("--state-dir", type=click.Path(), default=str(DEFAULT_STATE_DIR))
@click.option(
    "--relay",
    is_flag=True,
    help="Enable the tmux PTY relay for remote-control channels (alpha).",
)
@click.pass_context
def start(ctx, foreground, state_dir, relay):
    """Start the daemon as a background process.

    Automatically uses the best available method:
    - Homebrew services (if installed via brew)
    - systemd user service (if installed on Linux)
    - Background process (fallback)

    Use --foreground to run in the foreground (equivalent to 'hivemind run').
    """

    state_path = Path(state_dir)

    if foreground:
        ctx.invoke(run, state_dir=state_dir, relay=relay)
        return

    _pre_start_auth_check(state_path)

    if is_daemon_running(state_path):
        pid = find_daemon_pid(state_path)
        click.echo(f"Daemon is already running (PID {pid}).")
        return

    _warn_on_binary_mismatch()

    from hivemind.service import get_service_manager  # noqa: PLC0415 — mocked in tests via hivemind.service

    mgr = get_service_manager(state_dir=state_path)
    success, message = mgr.start()
    click.echo(message)
    track("cli.start")
    if not success:
        raise SystemExit(1)


@main.command()
@click.option("--force", is_flag=True, help="Force stop (SIGKILL)")
@click.option("--state-dir", type=click.Path(), default=str(DEFAULT_STATE_DIR))
def stop(force, state_dir):
    """Stop the running daemon."""

    state_path = Path(state_dir)
    from hivemind.service import get_service_manager  # noqa: PLC0415 — mocked in tests via hivemind.service

    mgr = get_service_manager(state_dir=state_path)
    success, message = mgr.stop(force=force)
    click.echo(message)
    track("cli.stop", {"force": force})
    if not success:
        raise SystemExit(1)


@main.command()
@click.option("--state-dir", type=click.Path(), default=str(DEFAULT_STATE_DIR))
@click.pass_context
def restart(ctx, state_dir):
    """Restart the daemon."""

    state_path = Path(state_dir)
    reauth_reason = _pre_start_auth_check(state_path)
    from hivemind.service import get_service_manager  # noqa: PLC0415 — mocked in tests via hivemind.service

    mgr = get_service_manager(state_dir=state_path)
    success, message = mgr.restart()
    click.echo(message)
    track("cli.restart", {"reauth_reason": reauth_reason})
    if not success:
        raise SystemExit(1)


@main.command()
@click.option("--state-dir", type=click.Path(), default=str(DEFAULT_STATE_DIR))
@click.option("--quiet", "-q", is_flag=True, help="Suppress output, exit code only")
def health(state_dir: str, quiet: bool):
    """Check if the daemon process is running (for container healthchecks).

    Exits 0 if the daemon holds its lock file, 1 otherwise.
    Designed to be fast and lightweight for use in Docker HEALTHCHECK
    or Kubernetes liveness probes.
    """
    running = is_daemon_running(Path(state_dir))
    if not quiet:
        click.echo("ok" if running else "not running")
    raise SystemExit(0 if running else 1)


@main.command()
@click.option("--state-dir", type=click.Path(), default=str(DEFAULT_STATE_DIR))
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def status(state_dir, as_json):
    """Show daemon status and sync info."""

    state_path = Path(state_dir)
    state_file = state_path / "state.json"
    from hivemind.service import get_service_manager  # noqa: PLC0415 — mocked in tests via hivemind.service

    endpoint = get_effective_endpoint()
    log_source = resolve_log_source()
    log_location = log_source.display

    # Fan out the three slow I/O calls in parallel. Previously these ran
    # sequentially and dominated command latency:
    #   brew services info  ~1.6s
    #   httpx.get /health   ~0.2s  (up to 3s on slow networks)
    #   keychain load       ~0.1s
    # On a typical run that was ~2s of sequential I/O on top of Python
    # startup. Running concurrently drops the I/O portion to whichever
    # call is slowest (usually brew).
    def _fetch_svc_status():
        return get_service_manager(state_dir=state_path).status()

    def _fetch_auth_info():
        result = {
            "auth_user": None,
            "auth_method": None,
            "keychain_locked": False,
            "credential_backend": "unknown",
        }
        try:
            base = get_base_endpoint(endpoint)
            auth = AuthManager(endpoint=base)
            backend_name = getattr(auth.store._secrets, "backend_name", None)
            if isinstance(backend_name, str):
                result["credential_backend"] = backend_name
            creds = auth.store.load(auth.endpoint)
            if creds and not auth.store.is_expired(creds):
                result["auth_user"] = creds.github_user
                result["auth_method"] = creds.auth_method
        except KeychainLockedError:
            result["keychain_locked"] = True
        except Exception:
            pass
        return result

    def _fetch_server_health():
        try:
            resp = httpx.get(f"{endpoint}/health", timeout=3)
            if resp.status_code == 200:
                return resp.json()
        except Exception:
            pass
        return {}

    import concurrent.futures  # noqa: PLC0415 — only needed by this command

    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        svc_fut = executor.submit(_fetch_svc_status)
        auth_fut = executor.submit(_fetch_auth_info)
        health_fut = executor.submit(_fetch_server_health)
        svc_status = svc_fut.result()
        auth_info = auth_fut.result()
        health = health_fut.result()

    auth_user = auth_info["auth_user"]
    auth_method = auth_info["auth_method"]
    keychain_locked = auth_info["keychain_locked"]
    credential_backend = auth_info["credential_backend"]

    server_version = health.get("version")
    server_build_sha = health.get("build_sha")
    min_daemon_version = health.get("min_daemon_version")

    total_sessions = 0
    sessions_24h = 0
    last_sync = 0
    pending_events = 0
    last_auth_error = ""
    last_auth_error_ts = 0
    last_auth_error_message = ""
    cutoff_24h = time.time() - 86400
    if state_file.exists():
        state = load_state(state_file)
        # Use the current endpoint's server state for session counts
        norm_endpoint = _normalize_endpoint(endpoint)
        server_state = state.servers.get(norm_endpoint)
        if server_state:
            total_sessions = len(server_state.sessions)
            for sess in server_state.sessions.values():
                if sess.last_mtime >= cutoff_24h:
                    sessions_24h += 1
            last_sync = server_state.last_sync_ts
            pending_events = len(server_state.pending_buffer)
            last_auth_error = server_state.last_auth_error
            last_auth_error_ts = server_state.last_auth_error_ts
            last_auth_error_message = server_state.last_auth_error_message

    if as_json:
        data = {
            "running": svc_status.running,
            "pid": svc_status.pid,
            "uptime": svc_status.uptime,
            "method": svc_status.method,
            "endpoint": endpoint,
            "authenticated": auth_user is not None,
            "auth_user": auth_user,
            "auth_method": auth_method,
            "credential_backend": credential_backend,
            "keychain_locked": keychain_locked,
            "version": __version__,
            "server_version": server_version,
            "server_build_sha": server_build_sha,
            "min_daemon_version": min_daemon_version,
            "sessions_tracked": total_sessions,
            "sessions_last_24h": sessions_24h,
            "last_sync_ts": last_sync,
            "pending_events": pending_events,
            "log_file": log_location,
            "brew_desync": svc_status.brew_desync,
            "lock_unheld": svc_status.lock_unheld,
            "last_auth_error": last_auth_error,
            "last_auth_error_ts": last_auth_error_ts,
            "last_auth_error_message": last_auth_error_message,
        }
        click.echo(json.dumps(data, indent=2))
        return

    console = Console()

    # Status header — degrade to yellow "auth failing" when the daemon is
    # running but the last sync cycle was rejected (e.g. sso_required).
    # Use explicit hex colors so the output renders correctly regardless
    # of the user's terminal palette. Some themes remap the basic ANSI
    # `green` to a brownish/orange shade, which made the healthy state
    # look identical to the failing state. Hex values force rich into
    # truecolor mode (when supported) and stay true to intent.
    _OK_COLOR = "#22c55e"  # tailwind green-500
    _WARN_COLOR = "#eab308"  # tailwind yellow-500
    _ERR_COLOR = "#ef4444"  # tailwind red-500

    if svc_status.running:
        if svc_status.lock_unheld:
            status_str = f"[bold {_WARN_COLOR}]Running (worker not active)[/bold {_WARN_COLOR}]"
        elif last_auth_error:
            status_str = f"[bold {_WARN_COLOR}]Running (auth failing)[/bold {_WARN_COLOR}]"
        else:
            status_str = f"[bold {_OK_COLOR}]Running[/bold {_OK_COLOR}]"
        if svc_status.pid:
            status_str += f" (PID {svc_status.pid})"
    else:
        status_str = f"[bold {_ERR_COLOR}]Stopped[/bold {_ERR_COLOR}]"

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Key", style="bold")
    table.add_column("Value")

    table.add_row("Status", status_str)
    if svc_status.uptime:
        table.add_row("Uptime", svc_status.uptime)
    table.add_row("Method", svc_status.method)
    table.add_row("Endpoint", endpoint)
    if keychain_locked:
        auth_str = (
            f"[{_WARN_COLOR}]Keychain locked[/{_WARN_COLOR}] (run [bold]hivemind login[/bold])"
        )
    elif auth_user:
        auth_str = f"[{_OK_COLOR}]{auth_user}[/{_OK_COLOR}]"
        if auth_method:
            auth_str += f" [dim]({auth_method})[/dim]"
    else:
        auth_str = (
            f"[{_ERR_COLOR}]Not authenticated[/{_ERR_COLOR}] (run [bold]hivemind login[/bold])"
        )
    table.add_row("Auth", auth_str)
    table.add_row("Secrets", credential_backend)

    # Version with upgrade warning
    version_str = __version__
    needs_upgrade = False
    if min_daemon_version:
        needs_upgrade = _compare_versions(__version__, min_daemon_version) < 0
    if needs_upgrade:
        if svc_status.method == "homebrew":
            upgrade_cmd = "brew upgrade wandb/taps/hivemind"
        else:
            upgrade_cmd = "uv tool upgrade wandb-hivemind"
        version_str = f"[bold red]{__version__}[/bold red] (run {upgrade_cmd})"
    if server_version:
        server_info = f"  server {server_version}"
        if server_build_sha:
            server_info += f" ({server_build_sha})"
        version_str += server_info
    table.add_row("Version", version_str)

    table.add_row("Sessions", f"{total_sessions} ({sessions_24h} in last 24h)")
    if last_sync > 0:
        sync_dt = datetime.fromtimestamp(last_sync / 1000, tz=timezone.utc)
        table.add_row("Last sync", sync_dt.strftime("%Y-%m-%d %H:%M:%S UTC"))
    if pending_events > 0:
        table.add_row("Pending", str(pending_events))
    table.add_row("Log file", log_location)

    console.print()
    console.print(table)

    if last_auth_error:
        console.print()
        since = ""
        if last_auth_error_ts > 0:
            since_dt = datetime.fromtimestamp(last_auth_error_ts, tz=timezone.utc)
            since = f" (since {since_dt.strftime('%Y-%m-%d %H:%M:%S UTC')})"
        console.print(
            f"[{_WARN_COLOR}]Last sync rejected: {last_auth_error}{since}[/{_WARN_COLOR}]"
        )
        if last_auth_error_message:
            console.print(f"[{_WARN_COLOR}]  {last_auth_error_message}[/{_WARN_COLOR}]")

    if not svc_status.running:
        console.print()
        console.print("[dim]  Start with: hivemind restart[/dim]")

    if svc_status.brew_desync:
        console.print()
        console.print(
            "[yellow]Warning: Homebrew thinks the service is stopped but the daemon "
            "is running outside Homebrew's control.[/yellow]"
        )
        console.print(
            "[yellow]  This may cause issues with 'brew services stop/restart' and "
            "'brew upgrade'.[/yellow]"
        )
        console.print("[dim]  Fix: hivemind restart[/dim]")

    if svc_status.lock_unheld:
        console.print()
        console.print(
            "[yellow]Warning: supervisor is alive but no worker holds the daemon "
            "lock — sessions are NOT being synced.[/yellow]"
        )
        console.print(
            "[yellow]  Common in dev mode when the worker fails to import "
            "(e.g. missing dep in your venv).[/yellow]"
        )
        console.print(f"[dim]  Check the log: {log_location}[/dim]")
        console.print("[dim]  Then: hivemind restart[/dim]")

    console.print()
    track("cli.status")


@main.command()
@click.option("--state-dir", type=click.Path(), default=str(DEFAULT_STATE_DIR))
def hup(state_dir: str):
    """Send reload signal to the running daemon.

    Sends SIGHUP to the running daemon, causing it to restart and pick up
    code changes. This is useful when developing with dev.repo configured.

    The daemon must be running with dev.repo for this to trigger a full
    code reload. Without dev.repo, SIGHUP only reloads the config file.
    """
    state_path = Path(state_dir)

    if not is_daemon_running(state_path):
        click.echo("Daemon is not running.", err=True)
        raise SystemExit(1)

    pid = find_daemon_pid(state_path)
    if pid is None:
        click.echo(
            "Daemon is running but PID could not be determined.\nTry: hivemind doctor --fix",
            err=True,
        )
        raise SystemExit(1)

    # Send SIGHUP to trigger reload
    try:
        os.kill(pid, signal.SIGHUP)
        click.echo(f"Sent SIGHUP to daemon (PID {pid}). Reloading...")
    except PermissionError:
        click.echo(f"No permission to signal daemon process {pid}.", err=True)
        raise SystemExit(1)
    except OSError as e:
        click.echo(f"Failed to send SIGHUP to daemon: {e}", err=True)
        raise SystemExit(1)


def _detect_other_channels(active_method: str) -> list[tuple[str, str]]:
    """Probe disk for hivemind installs from channels other than ``active_method``.

    Returns ``(label, uninstall_cmd)`` tuples. Each install channel writes
    to the same ``com.wandb.hivemind`` launchd label, so coexistence is
    silent — only the most recently bootstrapped daemon runs. Surfacing
    other channels lets users clean up unused installs before they bite.
    """
    others: list[tuple[str, str]] = []
    for c in CHANNELS:
        if c.name == active_method or not c.is_installed():
            continue
        cmd = c.uninstall_cmd()
        if cmd is not None:
            others.append((c.label, cmd))
    return others


def _detect_install_orphans() -> list[tuple[str, str]]:
    """macOS-only: return ``(issue, fix)`` pairs for broken install state.

    Coexisting channels are *not* orphans (those go through
    `_detect_other_channels`). This catches state that actually breaks
    the daemon — currently just stranded pkgutil receipts.
    """
    orphans: list[tuple[str, str]] = []

    try:
        receipt = subprocess.run(
            ["pkgutil", "--pkg-info", "com.wandb.hivemind"],
            capture_output=True,
            timeout=5,
        )
        if receipt.returncode == 0 and not Path("/usr/local/hivemind/bin/hivemind").exists():
            orphans.append(
                (
                    "Orphaned pkgutil receipt for com.wandb.hivemind (payload already removed)",
                    "sudo pkgutil --forget com.wandb.hivemind",
                )
            )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    return orphans


def _registered_daemon_binary() -> Path | None:
    """Return the binary path the macOS LaunchAgent will run, or None.

    Reads ProgramArguments[0] out of the per-user plist. Used to warn
    when ``hivemind start`` is invoked from a binary that doesn't match
    the one launchd will actually spawn.
    """
    plist_path = Path.home() / "Library" / "LaunchAgents" / "com.wandb.hivemind.plist"
    if not plist_path.exists():
        return None
    try:
        with plist_path.open("rb") as f:
            data = plistlib.load(f)
    except (OSError, plistlib.InvalidFileException):
        return None
    args = data.get("ProgramArguments") or []
    if not args:
        return None
    return Path(args[0])


def _warn_on_binary_mismatch() -> None:
    """Print a warning when the CLI binary doesn't match the LaunchAgent's.

    Common when multiple install channels are present (e.g. pkg is the
    daemon, uv-tool is first on $PATH). Surfaces the surprise instead of
    silently starting a different binary than the user invoked.
    """
    if platform.system() != "Darwin":
        return
    registered = _registered_daemon_binary()
    if registered is None:
        return
    invoked_str = shutil.which("hivemind")
    if invoked_str is None:
        return
    try:
        if Path(invoked_str).resolve() == registered.resolve():
            return
    except OSError:
        return
    click.echo(
        f"Note: you invoked {invoked_str}, but the LaunchAgent will run "
        f"{registered}. The daemon's binary won't match the CLI you just "
        f"used. Run `hivemind doctor` to inspect coexisting channels.",
        err=True,
    )


def _check_auth_for_post_install(state_path: Path) -> tuple[str, str]:
    """Check auth status without modifying credentials or making network calls.

    Performs a read-only check of local credential and tool availability.
    Used by ``doctor --post-install`` so the Homebrew formula never writes
    to ``credentials.json`` during install/upgrade.

    Returns:
        (status, detail) where status is one of:
        - "authenticated": valid credentials exist (detail = github username)
        - "auto_ssh": SSH key pair found (detail = key type e.g. "ED25519")
        - "auto_gh": gh CLI has a stored token (detail = "GitHub CLI")
        - "auto_git": git credential helper configured (detail = helper name)
        - "none": no auth method detected
    """
    creds_file = state_path / "credentials.json"

    # 1. Check existing credentials (read-only — no CredentialStore to avoid
    #    v1->v2 migration writes)
    if creds_file.exists():
        try:
            data = json.loads(creds_file.read_text())
            if isinstance(data, dict) and isinstance(data.get("servers"), dict):
                for server_data in data["servers"].values():
                    if isinstance(server_data, dict) and server_data.get("github_user"):
                        expires_at = server_data.get("expires_at", 0)
                        # Same 1-hour buffer as CredentialStore.is_expired
                        if time.time() < (expires_at - 3600):
                            return ("authenticated", server_data["github_user"])
        except (json.JSONDecodeError, ValueError, OSError):
            pass

    # 2. Check for SSH keys (local file check only, no network)
    ssh_dir = Path.home() / ".ssh"
    for name in ["id_ed25519", "id_rsa", "id_ecdsa"]:
        if (ssh_dir / name).exists() and (ssh_dir / f"{name}.pub").exists():
            return ("auto_ssh", name.replace("id_", "").upper())

    # 3. Check gh CLI token (local only, no network)
    try:
        result = subprocess.run(
            ["gh", "auth", "token"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            return ("auto_gh", "GitHub CLI")
    except (subprocess.SubprocessError, FileNotFoundError):
        pass

    # 4. Check git credential helper configuration
    try:
        result = subprocess.run(
            ["git", "config", "--get", "credential.helper"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            return ("auto_git", result.stdout.strip())
    except (subprocess.SubprocessError, FileNotFoundError):
        pass

    return ("none", "")


def _count_health_issues_silent(state_path: Path) -> int:
    """Count health issues without printing anything.

    Only checks for conditions that ``doctor --fix`` can repair:
    corrupted credentials, stale lock files, and empty lock files.
    """
    creds_file = state_path / "credentials.json"
    lock_file = state_path / "daemon.lock"
    issues = 0

    # Corrupted credentials
    if creds_file.exists():
        try:
            data = json.loads(creds_file.read_text())
            if not isinstance(data, dict):
                issues += 1
            elif "version" in data and not isinstance(data.get("servers"), dict):
                issues += 1
        except (json.JSONDecodeError, ValueError, OSError):
            issues += 1

    # Stale lock file
    if lock_file.exists() and not is_daemon_running(state_path):
        issues += 1

    # Empty lock with running daemon
    if lock_file.exists() and is_daemon_running(state_path):
        try:
            if not lock_file.read_text().strip():
                issues += 1
        except OSError:
            pass

    return issues


def _is_service_installed() -> bool:
    """Check if the hivemind service was previously configured (upgrade hint)."""
    if platform.system() == "Darwin":
        plist = Path.home() / "Library/LaunchAgents/com.wandb.hivemind.plist"
        return plist.exists()
    else:
        unit = Path.home() / ".config/systemd/user/hivemind.service"
        return unit.exists()


def _doctor_post_install(state_path: Path) -> None:
    """Print post-install summary designed for Homebrew formula output.

    This is the primary user-facing output after ``brew install`` or
    ``brew upgrade``.  It checks auth availability (read-only), runs a
    silent health check, and prints service start/restart guidance.
    """
    is_upgrade = _is_service_installed() or is_daemon_running(state_path)

    click.echo()
    click.echo(f"  Hivemind v{__version__}")
    click.echo()

    # --- Auth status ---
    auth_status, auth_detail = _check_auth_for_post_install(state_path)
    if auth_status == "authenticated":
        click.echo(f"  Auth:     \u2713 Authenticated as {auth_detail}")
    elif auth_status.startswith("auto_"):
        method_name = {
            "auto_ssh": f"SSH key ({auth_detail})",
            "auto_gh": "GitHub CLI (gh)",
            "auto_git": f"Git credentials ({auth_detail})",
        }.get(auth_status, auth_detail)
        click.echo(
            f"  Auth:     \u2713 {method_name} detected \u2014 will auto-authenticate on first sync"
        )
    else:
        click.echo("  Auth:     \u2717 No authentication method detected")
        click.echo("            \u2192 Run: hivemind login")

    # --- Health summary ---
    issues = _count_health_issues_silent(state_path)
    if issues > 0:
        noun = "issue" if issues == 1 else "issues"
        click.echo(f"  Health:   \u2717 {issues} {noun} found \u2014 run `hivemind doctor --fix`")
    else:
        click.echo("  Health:   \u2713 No issues detected")

    click.echo()

    # --- Service guidance ---
    if is_upgrade:
        click.echo("  To apply the update:")
        click.echo("    hivemind restart")
    else:
        click.echo("  To get started:")
        click.echo("    hivemind start")

    click.echo()
    click.echo("  Other commands:")
    click.echo("    hivemind status             Check daemon status")
    click.echo("    hivemind logs               View daemon logs")
    click.echo("    hivemind doctor             Diagnose issues")
    click.echo()


@main.command()
@click.option("--fix", is_flag=True, help="Attempt to auto-fix detected issues")
@click.option(
    "--post-install",
    is_flag=True,
    hidden=True,
    help="Post-install summary for Homebrew formula (always exits 0)",
)
@click.option("--state-dir", type=click.Path(), default=str(DEFAULT_STATE_DIR))
def doctor(fix: bool, post_install: bool, state_dir: str):
    """Diagnose and fix common issues."""
    state_path = Path(state_dir)

    if post_install:
        _doctor_post_install(state_path)
        return

    lock_file = state_path / "daemon.lock"
    creds_file = state_path / "credentials.json"

    issues_found = 0
    fixes_applied = 0

    # --- Check 1: Lock file health (empty lock + daemon running) ---
    daemon_running = is_daemon_running(state_path)
    lock_exists = lock_file.exists()
    lock_pid_str = ""
    if lock_exists:
        try:
            lock_pid_str = lock_file.read_text().strip()
        except OSError:
            pass

    if daemon_running and not lock_pid_str:
        # Lock held but PID empty — the old truncate-on-open bug
        issues_found += 1
        recovered_pid = find_daemon_pid(state_path)
        if recovered_pid is not None:
            click.echo(
                f"  \u2717 Lock file is empty but daemon is running (recovered PID: {recovered_pid})"
            )
            if fix:
                try:
                    lock_file.write_text(str(recovered_pid))
                    click.echo(f"    \u2192 Fixed: wrote PID {recovered_pid} to lock file")
                    fixes_applied += 1
                except OSError as e:
                    click.echo(f"    \u2192 Could not fix: {e}")
            else:
                click.echo("    \u2192 Run with --fix to write recovered PID to lock file")
        else:
            click.echo("  \u2717 Lock file is empty and daemon PID could not be recovered")
            click.echo("    \u2192 Restart the daemon to fix this")
    elif daemon_running and lock_pid_str:
        click.echo(f"  \u2713 Lock file healthy (PID: {lock_pid_str})")
    elif not daemon_running and not lock_exists:
        click.echo("  \u2713 No lock file (daemon not running)")
    # else: handled by stale lock check below

    # --- Check 2: Stale lock file ---
    if lock_exists and not daemon_running:
        issues_found += 1
        click.echo("  \u2717 Stale lock file (daemon not running, lock not held)")
        if fix:
            try:
                lock_file.unlink()
                click.echo("    \u2192 Fixed: removed stale lock file")
                fixes_applied += 1
            except OSError as e:
                click.echo(f"    \u2192 Could not fix: {e}")
        else:
            click.echo("    \u2192 Run with --fix to remove stale lock file")

    # --- Check 3: Credentials health ---
    try:
        if creds_file.exists():
            content = creds_file.read_text()
            data = json.loads(content)
            if not isinstance(data, dict):
                raise ValueError("credentials file is not a JSON object")
            if "version" in data and not isinstance(data.get("servers"), dict):
                raise ValueError("invalid v2 structure")
            click.echo("  \u2713 Credentials file healthy")
        else:
            click.echo("  \u2713 No credentials file (not yet authenticated)")
    except (json.JSONDecodeError, ValueError, OSError) as e:
        issues_found += 1
        click.echo(f"  \u2717 Credentials file corrupted: {e}")
        if fix:
            try:
                creds_file.unlink(missing_ok=True)
                click.echo(
                    "    \u2192 Fixed: removed corrupted credentials (re-authentication required)"
                )
                fixes_applied += 1
            except OSError as e2:
                click.echo(f"    \u2192 Could not fix: {e2}")
        else:
            click.echo("    \u2192 Run with --fix to reset credentials")

    # --- Check 4: Keychain health ---
    try:
        store = CredentialStore(config_dir=state_path)
        diag = store.diagnose(endpoint=get_base_endpoint(get_effective_endpoint()))

        if not diag.is_keychain:
            click.echo(f"  \u2713 Secret storage: {diag.backend_name}")
        elif diag.keychain_unlocked:
            click.echo(f"  \u2713 Keychain: {diag.backend_name} (unlocked)")
            if diag.secrets_accessible:
                click.echo("  \u2713 Keychain secrets accessible")
            elif diag.secrets_accessible is False:
                issues_found += 1
                click.echo("  \u2717 Keychain secrets not accessible")
        else:
            if diag.has_keychain_secrets:
                issues_found += 1
                click.echo(f"  \u2717 Keychain: {diag.backend_name} (locked)")
                click.echo("    \u2192 Secrets are stored in the keychain but cannot be read")
                click.echo("    \u2192 Run `hivemind login` to re-authenticate")
                for suggestion in diag.suggestions:
                    click.echo(f"    \u2192 {suggestion}")
            else:
                click.echo(f"  \u2713 Keychain: {diag.backend_name} (locked, no secrets stored)")

        for issue in diag.issues:
            if "expired" in issue.lower():
                click.echo(f"  \u2717 {issue}")
                issues_found += 1
    except Exception as e:
        click.echo(f"  \u2717 Keychain check failed: {e}")
        issues_found += 1

    # --- Check 5: Service sync (macOS only) ---
    if platform.system() == "Darwin":
        try:
            # Try the full tap name first (wandb/taps/hivemind), then fall back
            # to bare "hivemind". The bare name resolves to homebrew.mxcl.hivemind
            # which is a different (empty) formula from the tap's com.wandb.hivemind.
            svc = None
            for formula_name in ["wandb/taps/hivemind", "hivemind"]:
                result = subprocess.run(
                    ["brew", "services", "info", formula_name, "--json"],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                if result.returncode == 0:
                    svc_info = json.loads(result.stdout)
                    candidate = svc_info[0] if isinstance(svc_info, list) else svc_info
                    # Use this result if the service is actually registered/loaded
                    if candidate.get("loaded") or candidate.get("status") not in (
                        "none",
                        None,
                    ):
                        svc = candidate
                        break
                    # Keep as fallback if we haven't found anything better
                    if svc is None:
                        svc = candidate

            if svc is not None:
                svc_status = svc.get("status", "unknown")
                if svc_status == "started":
                    if daemon_running:
                        click.echo("  \u2713 Homebrew service running and daemon lock held")
                    else:
                        issues_found += 1
                        click.echo(
                            "  \u2717 Homebrew service reports running but daemon lock not held"
                        )
                        click.echo("    \u2192 Try: hivemind restart")
                elif svc_status in ("none", "stopped"):
                    if daemon_running:
                        issues_found += 1
                        click.echo(
                            "  \u2717 Daemon running but Homebrew thinks the service is stopped"
                        )
                        if fix:
                            # Kill the orphan process so brew can take over cleanly
                            orphan_pid = find_daemon_pid(state_path)
                            orphan_stopped = False
                            if orphan_pid:
                                try:
                                    os.kill(orphan_pid, signal.SIGTERM)
                                    # Wait briefly for graceful shutdown
                                    for _ in range(10):
                                        time.sleep(0.5)
                                        try:
                                            os.kill(orphan_pid, 0)
                                        except ProcessLookupError:
                                            orphan_stopped = True
                                            break
                                    if not orphan_stopped:
                                        # Escalate to SIGKILL
                                        os.kill(orphan_pid, signal.SIGKILL)
                                        time.sleep(0.5)
                                        try:
                                            os.kill(orphan_pid, 0)
                                        except ProcessLookupError:
                                            orphan_stopped = True
                                except ProcessLookupError:
                                    orphan_stopped = True
                                except PermissionError:
                                    pass
                            else:
                                orphan_stopped = True

                            if not orphan_stopped:
                                click.echo(
                                    "    \u2192 Could not fix: failed to stop orphan "
                                    f"daemon (PID {orphan_pid})"
                                )
                            else:
                                result = subprocess.run(
                                    ["brew", "services", "restart", "wandb/taps/hivemind"],
                                    capture_output=True,
                                    text=True,
                                    timeout=10,
                                )
                                if result.returncode == 0:
                                    click.echo("    \u2192 Fixed: restarted service via Homebrew")
                                    fixes_applied += 1
                                else:
                                    click.echo(
                                        "    \u2192 Could not fix: brew services restart failed"
                                    )
                        else:
                            click.echo("    \u2192 Run with --fix, or: hivemind restart")
                    else:
                        click.echo("  \u2713 Homebrew service stopped (daemon not running)")
                else:
                    click.echo(f"  \u2713 Homebrew service status: {svc_status}")
            else:
                click.echo(
                    "  \u2713 Homebrew hivemind formula not installed (skipping service check)"
                )
        except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError):
            click.echo("  \u2713 Homebrew not available (skipping service check)")

    # --- Check 6: Cross-channel coexistence (macOS only) ---
    if platform.system() == "Darwin":
        try:
            active_method = detect_install_method()
        except Exception:
            active_method = "unknown"
        other_channels = _detect_other_channels(active_method)
        if other_channels and active_method == "dev":
            # Dev mode coexisting with a real install is the whole point of
            # [dev] repo \u2014 inform, don't flag.
            labels = ", ".join(label for label, _ in other_channels)
            click.echo(f"  \u2139 Dev mode active \u2014 also installed via: {labels}")
            click.echo(
                "    (this is expected when [dev] repo is set; the installed "
                "daemon re-execs into your checkout)"
            )
        elif other_channels:
            issues_found += 1
            click.echo(f"  \u2717 Multiple install channels detected (active: {active_method})")
            click.echo(
                "    \u2192 Only one daemon runs at a time \u2014 channels share the "
                "com.wandb.hivemind launchd label. Clean up unused install(s):"
            )
            for label, cmd in other_channels:
                click.echo(f"      {cmd}    # {label}")
        elif active_method not in ("dev", "unknown"):
            click.echo(f"  \u2713 Single install channel: {active_method}")

        for issue, remediation in _detect_install_orphans():
            issues_found += 1
            click.echo(f"  \u2717 {issue}")
            click.echo(f"    \u2192 {remediation}")

        # --- Check 7: MDM-deferred LaunchAgent registration (macOS only) ---
        mdm_marker = Path("/Library/Application Support/Hivemind/postinstall-pending.json")
        if mdm_marker.exists():
            issues_found += 1
            click.echo("  \u2717 Hivemind .pkg installed without a console user")
            click.echo("    (typical for MDM rollouts \u2014 JAMF/Intune/Mosyle/Kandji)")
            click.echo(
                "    \u2192 Run 'hivemind start' to register the LaunchAgent and start the daemon."
            )
            click.echo(
                "      MDM admins: schedule a login-trigger policy that runs that "
                "command as the logged-in user. See docs/MDM.md."
            )

        # --- Check 8: Canonical CLI path on PATH (macOS only) ---
        # Every install channel drops a symlink at ~/.local/bin/hivemind
        # so that "last writer wins" works for the CLI the same way it
        # does for the daemon's launchd label. If the canonical symlink
        # exists but a different binary is first on $PATH, the CLI the
        # user runs (`hivemind --version`) can drift from the daemon
        # process \u2014 quietly. Don't warn when the canonical doesn't
        # exist: that means the user installed via a method that didn't
        # write the symlink (e.g. a dev venv) and they don't expect
        # PATH consistency.
        canonical_cli = Path.home() / ".local" / "bin" / "hivemind"
        active_cli = shutil.which("hivemind")
        if canonical_cli.exists() and active_cli:
            try:
                same = Path(active_cli).resolve() == canonical_cli.resolve()
            except (OSError, ValueError):
                same = False
            if not same:
                issues_found += 1
                click.echo(
                    f"  \u2717 PATH points at {active_cli}, not the canonical {canonical_cli}"
                )
                click.echo(
                    "    \u2192 Put ~/.local/bin first on $PATH so all install "
                    "channels stay consistent"
                )

    # --- Summary ---
    click.echo()
    track("cli.doctor", {"fix": fix, "issues_found": issues_found})
    if issues_found == 0:
        click.echo("All checks passed.")
    elif fix:
        unfixed = issues_found - fixes_applied
        if unfixed == 0:
            click.echo(f"Fixed {fixes_applied} issue(s).")
        else:
            click.echo(f"Fixed {fixes_applied} issue(s), {unfixed} remaining.")
            raise SystemExit(1)
    else:
        click.echo(f"Found {issues_found} issue(s). Run with --fix to attempt repairs.")
        raise SystemExit(1)


def _find_git_root(start_path: Path) -> Path | None:
    """Find the git repository root from start_path, or None if not in a repo."""
    current = start_path.resolve()
    while current != current.parent:
        if (current / ".git").exists():
            return current
        current = current.parent
    return None


@main.command("import")
@click.option(
    "--since",
    envvar="HIVEMIND_IMPORT_SINCE",
    help="Import sessions modified after this time (e.g., '1d', '2h', '2024-01-15')",
)
@click.option(
    "--path",
    type=click.Path(exists=True),
    multiple=True,
    help="Paths to search for sessions (default: git repo root or current directory)",
)
@click.option(
    "--all",
    "import_all",
    is_flag=True,
    help="Import ALL sessions from all agent directories (bypasses path filtering)",
)
@click.option("--dry-run", is_flag=True, help="Show what would be imported without uploading")
@click.option(
    "--agents",
    help="Comma-separated list of agent types to import (e.g., 'claude,cursor'). Default: all agents",
)
@click.option(
    "--allow-empty",
    is_flag=True,
    help=(
        "Exit 0 when no sessions are discovered. By default, finding zero "
        "sessions exits non-zero so CI hooks can detect missing-adapter / "
        "wrong-path / wrong-agent misconfiguration."
    ),
)
@click.pass_context
def import_sessions(
    ctx: click.Context,
    since: str | None,
    path: tuple[str, ...],
    import_all: bool,
    dry_run: bool,
    agents: str | None,
    allow_empty: bool,
):
    """Import sessions from local agent history.

    Requires authentication. Run 'hivemind login' first.

    By default, imports sessions from the current git repository (or current directory
    if not in a repo). Use --all to import from all agent directories.

    Examples:

        # Import to local dev server
        hivemind --dev import --since 1d

        # Import sessions from current git repo
        hivemind import --since 1d

        # Import ALL sessions from all agent directories
        hivemind import --all --since 1d

        # Import only specific agent types
        hivemind import --agents claude,cursor

        # Import sessions since a specific date
        hivemind import --since 2024-01-15

        # Dry run to see what would be imported
        hivemind import --dry-run

        # Import from specific paths
        hivemind import --path ~/projects/myapp --path ~/projects/other
    """
    # Determine effective endpoint
    effective_endpoint = get_effective_endpoint()

    # Require authentication. Resolve through the full provider chain so
    # CI environments (GitHub Actions OIDC, Modal, Kubernetes, HIVEMIND_TOKEN)
    # work without an interactive `hivemind login`.
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth_manager = AuthManager(base_endpoint)
    try:
        creds = asyncio.run(auth_manager.resolve_credentials())
    except (AuthError, PermanentAuthError) as e:
        click.echo(f"Error: Authentication failed: {e}", err=True)
        raise SystemExit(1) from e

    if not creds:
        lines = [
            "Error: Not authenticated. Run 'hivemind login' first, or set "
            "HIVEMIND_TOKEN / configure OIDC federation for CI use.",
        ]
        provider_errors = auth_manager.last_resolution_errors
        if provider_errors:
            lines.append("")
            lines.append("Provider failures during the credential resolve:")
            for name, err in provider_errors:
                lines.append(f"  - {name}: {err}")
        click.echo("\n".join(lines), err=True)
        raise SystemExit(1)

    user_id = creds.user_id
    auth_token = creds.token
    username = creds.github_user
    email = creds.email

    # Get device ID from hardware info

    hardware_info = collect_hardware_info()
    # Prefer hardware_uuid, fallback to hostname
    device_id = hardware_info.hardware_uuid or hardware_info.hostname
    logger.info(f"Device ID: {device_id}")

    # Log user and device identification
    logger.info(f"Authenticated as: {username} ({email})")
    logger.info(f"User ID: {user_id}")

    # Parse since filter
    since_ts = parse_since(since)
    if since_ts:
        since_dt = datetime.fromtimestamp(since_ts, tz=timezone.utc)
        logger.info(f"Importing sessions modified since {since_dt.isoformat()}")
    else:
        logger.info("Importing ALL sessions (no --since filter)")

    # Determine search paths
    if path:
        # Explicit paths provided
        search_paths = [Path(p) for p in path]
    elif import_all:
        # --all flag: search from home to find all sessions
        search_paths = [Path.home()]
    else:
        # Default: use git root or current directory
        git_root = _find_git_root(Path.cwd())
        if git_root:
            logger.info(f"Using git repository root: {git_root}")
            search_paths = [git_root]
        else:
            search_paths = [Path.cwd()]

    # Parse agents filter
    allowed_agents = None
    if agents:
        allowed_agents = set(a.strip().lower() for a in agents.split(","))
        logger.info(f"Filtering to agents: {', '.join(sorted(allowed_agents))}")

    all_sessions = []

    for search_path in search_paths:
        logger.info(f"Searching {search_path}...")
        sessions = discover_all_sessions(search_path, since_ts=since_ts)
        all_sessions.extend(sessions)

    # Filter by agent type if specified
    if allowed_agents:
        all_sessions = [s for s in all_sessions if s["format"] in allowed_agents]

    logger.info(f"Found {len(all_sessions)} sessions")

    if not all_sessions:
        if allow_empty:
            click.echo("No sessions to import.")
            return
        click.echo(
            "Error: No sessions discovered. Pass --allow-empty if a no-op "
            "is expected, or check --path / --agents / --since filters and "
            "that the agent's session format is supported.",
            err=True,
        )
        raise SystemExit(1)

    # Show summary by agent type using Rich

    console = Console()
    agent_counts = Counter(s["format"] for s in all_sessions)

    # Summary table
    summary_table = Table(
        title=f"[bold]Found {len(all_sessions)} sessions[/bold]", show_header=True
    )
    summary_table.add_column("Agent", style="cyan")
    summary_table.add_column("Count", justify="right")
    for agent_type, count in sorted(agent_counts.items()):
        summary_table.add_row(agent_type, str(count))
    console.print()
    console.print(summary_table)

    # Recent sessions table
    recent_table = Table(title="[bold]Recent Sessions[/bold]", show_header=True)
    recent_table.add_column("Agent", style="cyan", width=8)
    recent_table.add_column("Session ID", style="dim")
    recent_table.add_column("Modified", style="green")
    for session in all_sessions[:10]:  # Show first 10
        mod_time = datetime.fromtimestamp(session["modified_at"], tz=timezone.utc)
        recent_table.add_row(
            session["format"],
            session["id"][:40] + "...",
            mod_time.strftime("%Y-%m-%d %H:%M"),
        )
    if len(all_sessions) > 10:
        recent_table.add_row("...", f"({len(all_sessions) - 10} more sessions)", "")
    console.print()
    console.print(recent_table)

    if dry_run:
        click.echo("\n--dry-run: No changes made.")
        return

    # Upload sessions
    # Use new server-side normalization endpoint
    base = get_base_endpoint(effective_endpoint)
    ingest_endpoint = f"{base}/v1/ingest/sessions"

    console = Console()
    console.print(f"\n[bold]Uploading to[/bold] {ingest_endpoint}")
    console.print(f"[bold]User:[/bold] {username}\n")

    uploader = Uploader(endpoint=ingest_endpoint, auth_token=auth_token)

    # Import the minimum entries threshold

    success_count = 0
    skip_count = 0
    error_count = 0
    errors: list[tuple[str, str, str]] = []  # (session_id, agent_type, error_msg)

    # Rich progress bar with multiple columns
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        MofNCompleteColumn(),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("[cyan]Importing sessions...", total=len(all_sessions))

        for session in all_sessions:
            session_desc = f"[dim]{session['format']}[/dim] {session['id'][:16]}..."
            progress.update(task, description=f"[cyan]Importing[/cyan] {session_desc}")

            try:
                # Read raw source entries
                source_entries = read_source_entries(session)

                # Skip trivial sessions (likely just initialized but never used)
                if len(source_entries) < MIN_ENTRIES_FOR_INITIAL_UPLOAD:
                    skip_count += 1
                    logger.debug(
                        f"Skipping trivial session {session['id'][:20]}... "
                        f"(only {len(source_entries)} entries)"
                    )
                    progress.advance(task)
                    continue

                # Extract metadata
                metadata = extract_session_metadata(session)
                metadata["user_id"] = user_id
                metadata["device_id"] = device_id
                metadata["email"] = email
                metadata["github_user"] = username

                # Build request
                request = SessionIngestRequest(
                    agent_session_id=session["id"],
                    source_format=session["format"],
                    metadata=metadata,
                    source_entries=[
                        SourceEntryInput(
                            entry_index=entry["entry_index"],
                            entry_content=entry["entry_content"],
                            entry_timestamp_ms=entry["entry_timestamp_ms"],
                        )
                        for entry in source_entries
                    ],
                )

                # Upload
                upload_result = asyncio.run(uploader.upload_session(request))
                if upload_result.success:
                    success_count += 1
                    logger.debug(
                        f"Imported {session['id'][:20]}... ({len(source_entries)} entries)"
                    )
                else:
                    error_count += 1
                    errors.append((session["id"][:16], session["format"], "Upload failed"))
                    logger.error(f"Failed to import {session['id'][:20]}...")

            except Exception as e:
                error_count += 1
                errors.append((session["id"][:16], session["format"], str(e)[:50]))
                logger.error(f"Error importing {session['id'][:20]}...: {e}")

            progress.advance(task)

    # Summary
    console.print()
    skip_msg = f", [dim]{skip_count} skipped[/dim]" if skip_count > 0 else ""
    if error_count == 0:
        console.print(
            f"[bold green]✓ Import complete:[/bold green] {success_count} sessions{skip_msg}"
        )
    else:
        console.print(
            f"[bold yellow]Import complete:[/bold yellow] "
            f"[green]{success_count} succeeded[/green], [red]{error_count} failed[/red]{skip_msg}"
        )

        # Show error table if there are errors
        if errors:
            console.print()
            error_table = Table(title="[red]Failed Sessions[/red]", show_header=True)
            error_table.add_column("Session ID", style="dim")
            error_table.add_column("Agent", style="cyan")
            error_table.add_column("Error", style="red")
            for sid, agent, err in errors[:10]:  # Show first 10 errors
                error_table.add_row(sid, agent, err)
            if len(errors) > 10:
                error_table.add_row("...", "...", f"({len(errors) - 10} more)")
            console.print(error_table)

    track(
        "cli.import",
        {
            "agent_types": sorted(set(s["format"] for s in all_sessions)),
            "session_count": success_count,
        },
    )

    if error_count > 0:
        raise SystemExit(1)


@main.command("dump")
@click.option(
    "--agent",
    "-a",
    type=click.Choice(["claude", "cursor", "gemini", "codex"], case_sensitive=False),
    required=True,
    help="Agent type to dump session from",
)
@click.option(
    "--session-id",
    "-s",
    help="Specific session ID to dump (defaults to most recent)",
)
@click.option(
    "--path",
    type=click.Path(exists=True),
    help="Search path for sessions (defaults to current directory)",
)
def dump_session(agent: str, session_id: str | None, path: str | None):
    """Dump raw session data as JSONL.

    Outputs JSONL to stdout where each line contains:
    {"entry_index": N, "entry_content": "{...}", "entry_timestamp_ms": ...}

    This is useful for creating test fixtures or debugging normalization.

    Examples:
        # Dump most recent Claude session in current directory
        hivemind dump -a claude > tests/fixtures/claude/source_events.jsonl

        # Dump specific session
        hivemind dump -a cursor -s abc123... > cursor_session.jsonl
    """

    # Determine search path
    search_path = Path(path) if path else Path.cwd()

    # Discover sessions for this agent type
    sessions = discover_all_sessions(search_path, since_ts=None)

    # Filter by agent type
    sessions = [s for s in sessions if s["format"] == agent.lower()]

    if not sessions:
        click.echo(f"No {agent} sessions found in {search_path}", err=True)
        raise SystemExit(1)

    # Select session
    if session_id:
        # Find by ID
        session = next((s for s in sessions if s["id"] == session_id), None)
        if not session:
            click.echo(f"Session {session_id} not found", err=True)
            raise SystemExit(1)
    else:
        # Use most recent
        sessions.sort(key=lambda s: s["modified_at"], reverse=True)
        session = sessions[0]

    # Read source entries
    try:
        source_entries = read_source_entries(session)
    except Exception as e:
        click.echo(f"Error reading session: {e}", err=True)
        raise SystemExit(1)

    # Extract daemon metadata (same as what gets sent to API)

    try:
        daemon_metadata = extract_session_metadata(session)
    except Exception as e:
        click.echo(f"Error extracting metadata: {e}", err=True)
        raise SystemExit(1)

    # Output as JSONL (same format as sent to API)

    # First, output synthetic daemon_metadata entry (entry_index: -1)
    # This represents the SESSION_METADATA custom event created by the API
    metadata_entry = {
        "entry_index": -1,
        "entry_content": json.dumps(
            {
                "type": "daemon_metadata",
                "metadata": daemon_metadata,
            }
        ),
        "entry_timestamp_ms": source_entries[0]["entry_timestamp_ms"] if source_entries else 0,
    }
    click.echo(json.dumps(metadata_entry))

    # Then output all source entries
    for entry in source_entries:
        json_line = json.dumps(
            {
                "entry_index": entry["entry_index"],
                "entry_content": entry["entry_content"],
                "entry_timestamp_ms": entry["entry_timestamp_ms"],
            }
        )
        click.echo(json_line)

    # Log metadata to stderr so it doesn't interfere with stdout
    click.echo(
        f"# Dumped {len(source_entries)} source entries + 1 metadata entry from {agent} session {session['id'][:16]}... "
        f"(modified: {datetime.fromtimestamp(session['modified_at'], tz=timezone.utc).isoformat()})",
        err=True,
    )
    track("cli.dump", {"session_id": session["id"]})


@main.command("transcript")
@click.argument("session_id")
@click.option(
    "--event-types",
    default=None,
    help=(
        "Comma-separated event categories to include: user, assistant, reasoning, tools, files, errors. "
        'Use "all" to include everything.'
    ),
)
@click.option(
    "--verbose/--no-verbose",
    default=False,
    help="Show request details (default: false)",
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["markdown", "jsonl", "atif"]),
    default="markdown",
    help="Output format (default: markdown)",
)
@click.pass_context
def transcript(
    ctx: click.Context,
    session_id: str,
    event_types: str | None,
    verbose: bool,
    output_format: str,
):
    """Fetch and display a session transcript.

    Retrieves the transcript from the backend API and outputs it to stdout.
    The transcript is formatted for LLM consumption with conversation turns.

    SESSION_ID is the agent session ID (the full UUID or a prefix).

    Examples:

        # Get markdown transcript for a session
        hivemind transcript abc12345-...

        # Only user and assistant messages
        hivemind transcript abc12345 --event-types user,assistant

        # Include everything
        hivemind transcript abc12345 --event-types all

        # Output as JSONL (raw source entries)
        hivemind transcript abc12345 --format jsonl

        # Output as ATIF (Agent Trajectory Interchange Format)
        hivemind transcript abc12345 --format atif

        # Save to file
        hivemind transcript abc12345 > session.md
    """
    # Determine effective endpoint
    effective_endpoint = get_effective_endpoint()

    # Require authentication
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth_manager = AuthManager(base_endpoint)
    creds = auth_manager.store.load(auth_manager.endpoint)

    if not creds or auth_manager.store.is_expired(creds):
        click.echo(
            "Error: Not authenticated. Run 'hivemind login' first.",
            err=True,
        )
        raise SystemExit(1)

    # Expand "all" shorthand for event_types
    all_event_types = "user,assistant,reasoning,tools,files,errors"
    effective_event_types = all_event_types if event_types == "all" else event_types

    # Build the API URL
    url = f"{base_endpoint}/v1/sessions/{session_id}/llm"
    params: dict[str, Any] = {
        "format": output_format,
    }
    if effective_event_types:
        params["event_types"] = effective_event_types

    if verbose:
        click.echo(f"GET {url}", err=True)
        click.echo(f"  params: {params}", err=True)

    try:
        with httpx.Client(timeout=60.0) as client:
            response = client.get(
                url,
                params=params,
                headers={"Authorization": f"Bearer {creds.token}"},
            )
            response.raise_for_status()

            data = response.json()
            track("cli.transcript", {"session_id": session_id, "format": output_format})

            if output_format == "markdown":
                # Output the markdown content
                markdown = data.get("markdown", "")
                if markdown:
                    click.echo(markdown)
                else:
                    click.echo("No transcript content available.", err=True)
                    raise SystemExit(1)
            elif output_format == "atif":
                # ATIF format - output the trajectory as pretty-printed JSON
                trajectory = data.get("trajectory", {})
                if trajectory:
                    click.echo(json.dumps(trajectory, indent=2))
                else:
                    click.echo("No ATIF trajectory available.", err=True)
                    raise SystemExit(1)
            else:
                # JSONL format - output each entry as a JSON line
                entries = data.get("entries", [])
                for entry in entries:
                    click.echo(json.dumps(entry))

    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            click.echo(f"Error: Session '{session_id}' not found.", err=True)
        else:
            click.echo(f"HTTP error: {e.response.status_code} - {e.response.text}", err=True)
        raise SystemExit(1)
    except httpx.RequestError as e:
        click.echo(f"Connection error: {e}", err=True)
        raise SystemExit(1)


def _fork_command_options(fn):
    fn = click.argument("session_id")(fn)
    fn = click.option(
        "--agent",
        type=click.Choice(["claude", "codex", "cursor-agent"]),
        default=None,
        help="Agent to use for the forked session. Defaults to the original session's agent.",
    )(fn)
    fn = click.option(
        "--no-checkout",
        is_flag=True,
        default=False,
        help="Skip git branch checkout.",
    )(fn)
    fn = click.option(
        "--dry-run",
        is_flag=True,
        default=False,
        help="Print the fork context without launching an agent.",
    )(fn)
    fn = click.option(
        "--full-history",
        is_flag=True,
        default=False,
        help="Request the full unsummarized transcript instead of server-compacted context.",
    )(fn)
    fn = click.pass_context(fn)
    return fn


def _get_fork_request_timeout_seconds() -> float:
    """Return the timeout for fork-context fetches."""
    raw_value = os.getenv("HIVEMIND_FORK_TIMEOUT_SECONDS", "").strip()
    if not raw_value:
        return 600.0

    try:
        parsed = float(raw_value)
    except ValueError:
        logger.warning(
            "Invalid HIVEMIND_FORK_TIMEOUT_SECONDS=%r; using default=600",
            raw_value,
        )
        return 600.0

    return max(parsed, 30.0)


def _run_fork(
    ctx: click.Context,
    session_id: str,
    agent: str | None,
    no_checkout: bool,
    dry_run: bool,
    full_history: bool,
):
    """Fork work from a previous Hivemind session.

    Fetches the session's fork context and launches an interactive
    agent session with that context pre-loaded.

    SESSION_ID is the session UUID (full or prefix).

    Examples:

        # Fork a session with the same agent type
        hivemind fork abc12345-...

        # Fork with a specific agent
        hivemind fork abc12345 --agent codex

        # Preview the compacted fork context without launching an agent
        hivemind fork abc12345 --dry-run

        # Request the full, unsummarized transcript
        hivemind fork abc12345 --full-history

        # Fork without checking out the session's branch
        hivemind fork abc12345 --no-checkout
    """
    # --- Authenticate ---
    effective_endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth_manager = AuthManager(base_endpoint)
    creds = auth_manager.store.load(auth_manager.endpoint)

    if not creds or auth_manager.store.is_expired(creds):
        click.echo(
            "Error: Not authenticated. Run 'hivemind login' first.",
            err=True,
        )
        raise SystemExit(1)

    # --- Fetch fork context ---
    click.echo(f"Fetching fork context for session {session_id}...", err=True)

    url = f"{base_endpoint}/v1/sessions/{session_id}/fork-context"
    params = {"full_history": "true"} if full_history else None
    fork_timeout_seconds = _get_fork_request_timeout_seconds()
    try:
        with httpx.Client(timeout=fork_timeout_seconds) as client:
            response = client.get(
                url,
                params=params,
                headers={"Authorization": f"Bearer {creds.token}"},
            )
            response.raise_for_status()
            data = response.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            click.echo(f"Error: Session '{session_id}' not found.", err=True)
        else:
            click.echo(
                f"HTTP error: {e.response.status_code} - {e.response.text}",
                err=True,
            )
        raise SystemExit(1)
    except httpx.RequestError as e:
        click.echo(f"Connection error: {e}", err=True)
        raise SystemExit(1)

    fork_context = data.get("fork_context") or data.get("compaction_summary", "")
    context_mode = data.get("context_mode", "compacted")
    system_prompt = data.get("system_prompt", "")
    git_repo = data.get("git_repo", "")
    git_branch = data.get("git_branch", "")
    session_agent = data.get("agent_type", "claude")
    title = data.get("title", "")
    token_count = data.get("token_count", 0)

    # Resolve which agent to use
    if agent:
        target_agent = agent
    elif not dry_run:
        # Interactive prompt — detect available agents
        agents = []
        for cmd in ("claude", "codex", "cursor-agent"):
            check = subprocess.run(["which", cmd], capture_output=True, text=True, timeout=5)
            if check.returncode == 0:
                agents.append(cmd)

        if not agents:
            click.echo(
                "Error: No supported agent found on PATH (claude, codex, cursor-agent). "
                "Install one first.",
                err=True,
            )
            raise SystemExit(1)
        elif len(agents) == 1:
            target_agent = agents[0]
        else:
            # Both available — ask the user
            click.echo(f"\n  Session: {title or session_id}", err=True)
            click.echo(f"  Context: ~{token_count} tokens\n", err=True)
            choice = click.prompt(
                "Fork with",
                type=click.Choice(agents, case_sensitive=False),
                default=session_agent if session_agent in agents else agents[0],
            )
            target_agent = choice
    else:
        target_agent = (
            session_agent if session_agent in ("claude", "codex", "cursor-agent") else "claude"
        )

    click.echo(f"  Session: {title or session_id}", err=True)
    click.echo(f"  Agent: {target_agent}", err=True)
    click.echo(f"  Context: ~{token_count} tokens ({context_mode})", err=True)
    track("cli.fork", {"session_id": session_id, "agent_type": target_agent})

    # --- Dry run: just print the context ---
    if dry_run:
        click.echo("\n--- Fork Context ---\n")
        click.echo(fork_context)
        return

    # --- Validate git state ---
    # Check we're in a git repo
    git_check = subprocess.run(
        ["git", "rev-parse", "--is-inside-work-tree"],
        capture_output=True,
        text=True,
        timeout=5,
    )
    if git_check.returncode != 0:
        click.echo(
            "Error: Not inside a git repository. "
            "Please run this command from within the repository.",
            err=True,
        )
        raise SystemExit(1)

    # Check that we're in the same repo
    if git_repo:
        local_repo_result = subprocess.run(
            ["git", "config", "--get", "remote.origin.url"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if local_repo_result.returncode == 0:
            local_repo_url = local_repo_result.stdout.strip()
            local_repo_normalized = normalize_git_url(local_repo_url)
            session_repo_normalized = normalize_git_url(git_repo)
            if (
                local_repo_normalized
                and session_repo_normalized
                and local_repo_normalized != session_repo_normalized
            ):
                click.echo(
                    f"Error: Repository mismatch.\n"
                    f"  Session repo: {git_repo}\n"
                    f"  Local repo:   {local_repo_url}\n"
                    f"Please run this command from the correct repository.",
                    err=True,
                )
                raise SystemExit(1)

    # --- Git branch checkout ---
    if not no_checkout and git_branch:
        # Check if the branch exists locally or remotely
        branch_exists_local = subprocess.run(
            ["git", "rev-parse", "--verify", f"refs/heads/{git_branch}"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        branch_exists_remote = subprocess.run(
            ["git", "rev-parse", "--verify", f"refs/remotes/origin/{git_branch}"],
            capture_output=True,
            text=True,
            timeout=5,
        )

        if branch_exists_local.returncode == 0 or branch_exists_remote.returncode == 0:
            # Branch exists - check it out
            current_branch = subprocess.run(
                ["git", "branch", "--show-current"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            current = current_branch.stdout.strip() if current_branch.returncode == 0 else ""

            if current != git_branch:
                # Check for uncommitted changes
                status = subprocess.run(
                    ["git", "status", "--porcelain"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if status.stdout.strip():
                    click.echo(
                        f"Warning: You have uncommitted changes. "
                        f"Skipping checkout of branch '{git_branch}'.",
                        err=True,
                    )
                else:
                    click.echo(f"  Checking out branch '{git_branch}'...", err=True)
                    checkout = subprocess.run(
                        ["git", "checkout", git_branch],
                        capture_output=True,
                        text=True,
                        timeout=15,
                    )
                    if checkout.returncode != 0:
                        click.echo(
                            f"Warning: Failed to checkout branch '{git_branch}': "
                            f"{checkout.stderr.strip()}",
                            err=True,
                        )
            else:
                click.echo(f"  Already on branch '{git_branch}'.", err=True)
        else:
            # Branch doesn't exist - check if it was merged
            click.echo(
                f"  Branch '{git_branch}' not found. "
                f"It may have been merged or deleted. Using current branch.",
                err=True,
            )

    # --- Write fork context to temp file ---
    context_file = tempfile.NamedTemporaryFile(
        mode="w",
        suffix=".md",
        prefix="hivemind-fork-",
        delete=False,
    )
    context_file.write(fork_context)
    context_file.close()
    context_path = context_file.name

    click.echo(f"  Fork context written to {context_path}", err=True)

    # --- Launch agent ---
    # Note: os.execvp replaces the current process, so the temp file
    # in /tmp will persist until the OS cleans it up. This is intentional
    # since the agent needs the file to be readable during its session.
    if target_agent == "claude":
        _launch_claude(context_path, system_prompt)
    elif target_agent == "codex":
        _launch_codex(context_path, system_prompt)
    elif target_agent == "cursor-agent":
        _launch_cursor_agent(context_path, system_prompt)


@main.command("fork")
@_fork_command_options
def fork(
    ctx: click.Context,
    session_id: str,
    agent: str | None,
    no_checkout: bool,
    dry_run: bool,
    full_history: bool,
):
    """Fork work from a previous Hivemind session."""
    return _run_fork(ctx, session_id, agent, no_checkout, dry_run, full_history)


@main.command("resume", hidden=True)
@_fork_command_options
def resume(
    ctx: click.Context,
    session_id: str,
    agent: str | None,
    no_checkout: bool,
    dry_run: bool,
    full_history: bool,
):
    """Deprecated alias for `hivemind fork`."""
    click.echo("Warning: 'hivemind resume' is deprecated; use 'hivemind fork'.", err=True)
    return _run_fork(ctx, session_id, agent, no_checkout, dry_run, full_history)


def _launch_claude(context_path: str, system_prompt: str) -> None:
    """Launch an interactive Claude Code session with fork context."""
    claude_check = subprocess.run(
        ["which", "claude"],
        capture_output=True,
        text=True,
        timeout=5,
    )
    if claude_check.returncode != 0:
        click.echo(
            "Error: 'claude' command not found. Please install Claude Code first.",
            err=True,
        )
        raise SystemExit(1)

    click.echo("\nLaunching Claude Code with fork context...\n", err=True)

    # Pass the system prompt and explicitly instruct Claude to read the
    # context file so the handoff is actually consumed.
    prompt = (
        system_prompt + f"\n\nRead the file at {context_path} to load the prior session handoff."
    )
    cmd = ["claude", "--append-system-prompt", prompt]

    # exec replaces the current process so claude gets full terminal control
    os.execvp("claude", cmd)


def _launch_codex(context_path: str, system_prompt: str) -> None:
    """Launch an interactive Codex session with fork context."""
    codex_check = subprocess.run(
        ["which", "codex"],
        capture_output=True,
        text=True,
        timeout=5,
    )
    if codex_check.returncode != 0:
        click.echo(
            "Error: 'codex' command not found. Please install Codex CLI first.",
            err=True,
        )
        raise SystemExit(1)

    click.echo("\nLaunching Codex with fork context...\n", err=True)

    # Codex takes a prompt as the first positional argument
    prompt = (
        f"Read the file at {context_path} — it contains a handoff from a prior session "
        f"you are forking from. Then continue if the next step is obvious, otherwise ask what to work on next."
    )
    cmd = ["codex", prompt]

    os.execvp("codex", cmd)


def _launch_cursor_agent(context_path: str, system_prompt: str) -> None:
    """Launch an interactive Cursor Agent session with fork context."""
    cursor_check = subprocess.run(
        ["which", "cursor-agent"],
        capture_output=True,
        text=True,
        timeout=5,
    )
    if cursor_check.returncode != 0:
        click.echo(
            "Error: 'cursor-agent' command not found. Please install Cursor Agent first.",
            err=True,
        )
        raise SystemExit(1)

    click.echo("\nLaunching Cursor Agent with fork context...\n", err=True)

    prompt = (
        f"Read the file at {context_path} — it contains a handoff from a prior session "
        f"you are forking from. Then continue if the next step is obvious, otherwise ask what to work on next."
    )
    cmd = ["cursor-agent", prompt]

    os.execvp("cursor-agent", cmd)


def _resolve_sso_org(auth: AuthManager, endpoint: str, issuer_hint: str | None = None) -> None:
    """Resolve the SSO org_id for OIDC login.

    Resolution order:
    0. Explicit `issuer_hint` (e.g. from `--issuer` on the command
       line). Skips discovery and prompts entirely. Use this in
       non-interactive environments (CI, headless boxes).
    1. Existing sources (env var, stored config, current JWT). Cheapest.
    2. Try GitHub-first auth so the server's /v1/auth/me can tell us
       which org enforces SSO and return its org_id in sso_login_url.
    3. Prompt the user for an Okta URL or company email and call the
       /v1/auth/oidc/discover endpoint to look up the org.
    """

    def _discover_org(hint: str) -> bool:
        """Call /v1/auth/oidc/discover and set auth.sso_org_id.

        Hint must be an Okta URL/domain (matched server-side against
        the org's stored OIDC issuer). Email lookups are not supported
        because they would let an unauthenticated attacker enumerate
        SCIM-provisioned users via this endpoint — see the security
        notes on `discover_sso_org` server-side.
        """
        hint = hint.replace("https://", "").replace("http://", "").rstrip("/")
        try:
            resp = httpx.get(
                f"{endpoint}/v1/auth/oidc/discover",
                params={"issuer_hint": hint},
                timeout=10,
            )
            if resp.status_code == 200:
                data = resp.json()
                auth.mark_sso_required(data["org_id"])
                click.echo(f"Found organization: {data.get('org_name', data['org_id'])}")
                return True
            if resp.status_code == 404:
                click.secho(
                    f"No organization found for '{hint}'. "
                    "Check the URL and ensure SSO is configured.",
                    fg="red",
                    err=True,
                )
            else:
                click.secho(f"Discovery failed: {resp.text}", fg="red", err=True)
        except httpx.RequestError as e:
            click.secho(f"Could not reach server: {e}", fg="red", err=True)
        return False

    # 0. Explicit hint short-circuits everything (non-interactive use)
    if issuer_hint:
        if not _discover_org(issuer_hint):
            raise SystemExit(1)
        return

    # 1. Existing sources (env var, stored config, current JWT)
    try:
        auth._get_sso_org_id()
        return  # Already have it
    except Exception:
        pass

    # 2. Try GitHub auth to discover the org via /v1/auth/me
    click.echo("Checking your organization's SSO configuration...")
    try:
        token = asyncio.run(auth.get_token())
        resp = httpx.get(
            f"{endpoint}/v1/auth/me",
            headers={"Authorization": f"Bearer {token}"},
            timeout=10,
        )
        if resp.status_code == 200:
            me = resp.json()
            if me.get("sso_required") and me.get("sso_login_url"):
                parsed = urlparse(me["sso_login_url"])
                org_id = parse_qs(parsed.query).get("org_id", [""])[0]
                if org_id:
                    auth.mark_sso_required(org_id)
                    click.echo(f"Your organization requires SSO (org: {org_id})")
                    return
    except Exception:
        pass  # GitHub auth failed, fall through to prompt

    # 3. Interactive prompt — only safe to reach here if we have a TTY.
    if not sys.stdin.isatty():
        click.secho(
            "Cannot resolve SSO organization in non-interactive mode. "
            "Re-run with `--issuer your-okta-domain.okta.com` (or set "
            "HIVEMIND_SSO_ORG_ID).",
            fg="red",
            err=True,
        )
        raise SystemExit(1)
    click.echo("SSO login requires your organization's Okta URL.")
    okta_url = click.prompt(
        "Enter your Okta URL (e.g., yourcompany.okta.com)",
        type=str,
    ).strip()
    if not _discover_org(okta_url):
        raise SystemExit(1)


def _sync_sso_state_from_me(
    auth: AuthManager,
    base_endpoint: str,
    info: dict,
    *,
    show_super_admin_hint: bool,
) -> None:
    """Pull current_org + sso_required from /v1/auth/me and persist on creds.

    Also upgrades to OIDC immediately when the org enforces SSO but the
    user authenticated via a non-SSO method. Called from both the silent-
    refresh and the interactive paths so creds always carry the user's
    current org id, regardless of how the login completed.
    """
    try:
        creds = auth.store.load(auth.endpoint)
        if not creds:
            return
        me_resp = httpx.get(
            f"{base_endpoint}/v1/auth/me",
            headers={"Authorization": f"Bearer {creds.token}"},
            timeout=10,
        )
        if me_resp.status_code != 200:
            return
        me = me_resp.json()
        sso_required_now = bool(me.get("sso_required"))
        org_id = (me.get("current_org") or {}).get("org_id") or ""
        if not org_id and me.get("sso_login_url"):
            parsed = urlparse(me["sso_login_url"])
            org_id = parse_qs(parsed.query).get("org_id", [""])[0]

        auth.store.save_sso_state(
            auth.endpoint,
            org_id=org_id or None,
            sso_required=sso_required_now,
        )
        if org_id:
            auth.sso_org_id = org_id
        auth.sso_required = sso_required_now

        if sso_required_now and not info["auth_method"].startswith("oidc_"):
            click.echo("\nYour organization requires SSO. Opening browser for SSO login...")
            asyncio.run(auth.get_token(force_method="oidc_browser"))
            sso_info = asyncio.run(auth.whoami())
            if sso_info:
                click.echo(
                    f"SSO authentication complete — "
                    f"{sso_info['github_user']} via {sso_info['auth_method']}"
                )

        if show_super_admin_hint and me.get("actual_role") == "super_admin":
            click.echo(
                "Note: super_admin sessions start in member mode. "
                "Run 'hivemind login --sudo' to elevate."
            )
    except Exception as e:
        click.echo(
            f"\nPost-login check failed: {e}\nRun 'hivemind login' to re-authenticate.",
            err=True,
        )


@main.command()
@click.option(
    "--method",
    type=click.Choice(
        [
            "auto",
            "ssh",
            "device",
            "credential",
            "gh",
            "oidc_browser",
            "oidc_device",
            "oidc_refresh",
        ]
    ),
    default="auto",
    help="Authentication method: auto (detect), ssh (SSH key), device (browser OAuth), credential (git credential helper), gh (GitHub CLI), oidc_browser (Okta OIDC via browser + FastPass), oidc_device (Okta device code flow), oidc_refresh (refresh using stored Okta/GitHub refresh token)",
)
@click.option(
    "--sudo",
    is_flag=True,
    default=False,
    help="Obtain a short-lived (~1h) super_admin escalation token on top of the existing login. "
    "In DEV_MODE this is granted immediately; in production it requires a phrh step-up (Touch ID / biometric) "
    "via the OIDC browser flow. Requires `hivemind login` first.",
)
@click.option(
    "--revoke-sudo",
    is_flag=True,
    default=False,
    help="Revoke any cached escalation token (leaves the base login intact).",
)
@click.option(
    "--issuer",
    "issuer_hint",
    default=None,
    metavar="ISSUER",
    help="Skip interactive SSO discovery and use this Okta URL "
    "(e.g. --issuer yourcompany.okta.com). Use in non-interactive "
    "environments where the SSO org_id is not yet stored in config. "
    "Email lookups are not supported — log in via GitHub first if you "
    "don't know your Okta URL.",
)
def login(method: str, sudo: bool, revoke_sudo: bool, issuer_hint: str | None):
    """Authenticate with Hivemind.

    Automatically detects the best authentication method:
    - SSH key signing (if SSH key exists)
    - Git credential helper (if PAT is stored)
    - GitHub CLI token (if gh is authenticated)
    - OAuth device flow (fallback, requires browser)

    If your organization requires SSO, the login flow upgrades to OIDC
    automatically — either because the org_id is already stored in your
    config, or because the post-login `/v1/auth/me` check reports that
    SSO is enforced. There is no `--sso` flag; just run `hivemind login`.

    Use --method to force a specific authentication method.
    Use --sudo to get an elevated session (requires Touch ID / biometric).
    """
    effective_endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(effective_endpoint)

    # --sudo / --revoke-sudo act on the existing login without re-running
    # the base auth flow. They short-circuit here.
    if sudo or revoke_sudo:
        _handle_sudo_flow(base_endpoint, revoke=revoke_sudo, issuer_hint=issuer_hint)
        return

    # An explicit --issuer also forces an OIDC flow.
    if issuer_hint and method == "auto":
        method = "oidc_browser"
    login_config = load_config()
    auth = AuthManager(endpoint=base_endpoint, config=login_config)

    # Reading sso_required from creds (not global config) means switching
    # endpoints — prod ↔ localhost — won't carry over a stale flag.
    _existing_creds = auth.store.load_raw(base_endpoint)
    _stored_sso_required = bool(_existing_creds.sso_required) if _existing_creds else False
    _stored_sso_org_id = _existing_creds.sso_org_id if _existing_creds else None

    if method == "auto" and _stored_sso_required:
        method = "oidc_browser"
        click.echo(f"Organization requires SSO (org: {_stored_sso_org_id or 'unknown'})")

    if method in ("oidc_browser", "oidc_device"):
        _resolve_sso_org(auth, base_endpoint, issuer_hint=issuer_hint)

    # Auto mode: confirm, then try silent refresh, then fall through to
    # interactive. Explicit --method skips both — `--method device` should
    # always run the device flow, not refresh a token from another method.
    if method == "auto":
        existing = asyncio.run(auth.whoami())
        if existing and not existing["expired"]:
            click.echo(f"Already authenticated as {existing['github_user']}.")
            if not click.confirm("Re-authenticate?", default=False):
                return

        if _existing_creds is not None and _can_refresh(_existing_creds):
            click.echo(f"Refreshing login for {_existing_creds.github_user}...")
            try:
                asyncio.run(auth.get_token(force_method="oidc_refresh"))
            except (AuthError, OIDCAuthError) as e:
                logger.debug("Refresh failed, falling back to interactive: %s", e)
                click.echo("Stored login expired, signing in again.")
            else:
                info = asyncio.run(auth.whoami())
                if info:
                    click.echo(
                        f"Authenticated as {info['github_user']} via refresh "
                        f"(was {_existing_creds.auth_method})"
                    )
                    _clear_last_auth_error(effective_endpoint)
                    _sync_sso_state_from_me(auth, base_endpoint, info, show_super_admin_hint=False)
                    _signal_daemon_reload()
                    track(
                        "cli.login",
                        {
                            "method": "oidc_refresh",
                            "requested_method": method,
                            "success": True,
                        },
                    )
                    return

        # Clear stale creds so the interactive flow starts clean.
        auth.logout()

    # Authenticate
    force_method = None if method == "auto" else method
    # Use the most-recently-used auth method from stored credentials when
    # auto-detecting (convenience, not a user preference).
    preferred_method = None
    if method == "auto" and _existing_creds:
        preferred_method = _existing_creds.auth_method

    # asyncio.Runner only replaces the SIGINT handler when the current
    # one is signal.default_int_handler — so installing a non-default
    # handler keeps it in place for the whole login flow, including the
    # blocking sys.stdin.read in the device-flow gate (which has no
    # await point and can't observe asyncio's task-cancel mechanism).
    # Body stays minimal: no I/O from inside a signal handler, since
    # stdio locks can deadlock against Rich's Live display thread.
    def _force_keyboard_interrupt(_sig: int, _frame: object) -> None:
        raise KeyboardInterrupt

    try:
        prev_sigint_handler = signal.signal(signal.SIGINT, _force_keyboard_interrupt)
    except (ValueError, OSError):
        prev_sigint_handler = None

    try:
        if method != "auto":
            click.echo(f"Authenticating via {method}...")
        try:
            asyncio.run(
                auth.get_token(force_method=force_method, preferred_method=preferred_method)
            )
        except OIDCSwitchRequested as switch:
            # User typed an Okta URL at the GitHub device-flow prompt to
            # skip GitHub and go straight to SSO. Discover the org, then
            # re-run via OIDC device flow.
            click.echo(f"\nSwitching to SSO via {switch.issuer_hint}...")
            _resolve_sso_org(auth, base_endpoint, issuer_hint=switch.issuer_hint)
            asyncio.run(auth.get_token(force_method="oidc_device"))
        info = asyncio.run(auth.whoami())
        if info:
            click.echo(f"Authenticated as {info['github_user']} via {info['auth_method']}")
            # auth_method is already persisted on StoredCredentials by the
            # successful get_token() call, so no separate config write needed.
            # Clear any persisted last_auth_error for this endpoint so the
            # running daemon's `hivemind status` flips back to green
            # immediately, rather than waiting for the daemon's recovery
            # poll to run on its next sync interval.
            _clear_last_auth_error(effective_endpoint)

            _sync_sso_state_from_me(auth, base_endpoint, info, show_super_admin_hint=True)
            # Nudge the running daemon so it picks up the new token on its
            # next loop iteration rather than waiting for _maybe_refresh_token
            # between sync cycles (which may be minutes away during catch-up).
            _signal_daemon_reload()
            track(
                "cli.login",
                {"method": info["auth_method"], "requested_method": method, "success": True},
            )
    except KeyboardInterrupt:
        track(
            "cli.login",
            {
                "method": method,
                "requested_method": method,
                "success": False,
                "cancelled": True,
            },
        )
        click.echo("\nLogin cancelled.", err=True)
        raise SystemExit(130)
    except PermanentAuthError as e:
        track("cli.login", {"method": method, "requested_method": method, "success": False})
        click.echo("\n" + "=" * 60, err=True)
        click.echo("ACCESS DENIED", err=True)
        click.echo("=" * 60, err=True)
        click.echo(str(e), err=True)
        click.echo("\nYour GitHub account is not authorized to use this service.", err=True)
        click.echo("Contact your administrator if you believe this is an error.", err=True)
        click.echo("=" * 60 + "\n", err=True)
        raise SystemExit(1)
    except (AuthError, OIDCAuthError) as e:
        track("cli.login", {"method": method, "requested_method": method, "success": False})
        click.echo(f"Authentication failed: {e}", err=True)
        raise SystemExit(1)
    finally:
        if prev_sigint_handler is not None:
            with contextlib.suppress(ValueError, OSError):
                signal.signal(signal.SIGINT, prev_sigint_handler)


@main.command()
def whoami():
    """Show authenticated user and device info."""
    effective_endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth = AuthManager(endpoint=base_endpoint)
    info = asyncio.run(auth.whoami())

    # Always show device info, even if not authenticated
    hw = collect_hardware_info()

    click.echo("Device Information:")
    click.echo(f"  Hostname:      {hw.hostname}")
    click.echo(f"  OS:            {hw.os} {hw.os_version}")
    if hw.serial_number:
        click.echo(f"  Serial:        {hw.serial_number}")
    if hw.hardware_uuid:
        click.echo(f"  Hardware UUID: {hw.hardware_uuid}")
    if hw.machine_id:
        click.echo(f"  Machine ID:    {hw.machine_id}")
    if hw.mac_addresses:
        click.echo(f"  MAC Addresses: {', '.join(hw.mac_addresses[:3])}")
        if len(hw.mac_addresses) > 3:
            click.echo(f"                 (+{len(hw.mac_addresses) - 3} more)")

    click.echo()

    if not info:
        click.echo("Authentication: Not authenticated")
        click.echo("Run 'hivemind login' to authenticate.")
        return

    click.echo("Authentication:")
    click.echo(f"  User:        {info['github_user']}")
    click.echo(f"  Email:       {info['email']}")
    click.echo(f"  User ID:     {info['user_id']}")
    click.echo(f"  Auth Method: {info['auth_method']}")
    expires_dt = datetime.fromtimestamp(info["expires_at"])
    click.echo(f"  Expires:     {expires_dt.strftime('%Y-%m-%d %H:%M:%S')}")
    if info["expired"]:
        click.echo("  Status:      EXPIRED (will refresh on next request)")
    else:
        click.echo("  Status:      Valid")


def _handle_sudo_flow(base_endpoint: str, *, revoke: bool, issuer_hint: str | None) -> None:
    """Handle `hivemind login --sudo` / `--revoke-sudo`.

    Requires an existing base credential. For --sudo, first tries
    POST /v1/auth/escalate (DEV_MODE fast path). On 403 phrh_required,
    falls through to an OIDC phrh step-up via the browser loopback.
    The resulting escalation token is saved in the escalation slot,
    leaving the base credential untouched.
    """
    store = CredentialStore()

    try:
        creds = store.load_base_only(base_endpoint)
    except KeychainLockedError as e:
        click.echo(f"Error: {e}", err=True)
        raise SystemExit(1)

    # Revoke should always clear the local escalation slot even if the
    # base credential is missing/expired — we never want a stale
    # escalation token surviving a failed base credential. The server
    # call is best-effort.
    if revoke:
        if creds is not None and not store.is_expired(creds):
            try:
                resp = httpx.post(
                    f"{base_endpoint}/v1/auth/escalate/revoke",
                    headers={"Authorization": f"Bearer {creds.token}"},
                    timeout=10,
                )
                if resp.status_code not in (200, 204):
                    click.echo(f"Warning: revoke endpoint returned {resp.status_code}", err=True)
            except httpx.RequestError as e:
                click.echo(f"Warning: could not reach revoke endpoint: {e}", err=True)
        else:
            click.echo(
                "No valid base credential — clearing local escalation only.",
                err=True,
            )
        store.clear_escalation(base_endpoint)
        click.echo("Escalation revoked.")
        track("cli.sudo_revoke")
        return

    if creds is None or store.is_expired(creds):
        click.echo(
            f"Error: Not authenticated for {base_endpoint}. Run 'hivemind login' first.",
            err=True,
        )
        raise SystemExit(1)

    # First attempt: direct escalate (DEV_MODE / already-phrh sessions).
    try:
        resp = httpx.post(
            f"{base_endpoint}/v1/auth/escalate",
            headers={"Authorization": f"Bearer {creds.token}"},
            timeout=15,
        )
    except httpx.RequestError as e:
        click.echo(f"Error: failed to reach {base_endpoint}: {e}", err=True)
        raise SystemExit(1)

    if resp.status_code == 200:
        body = resp.json()
        escalation_jwt = body.get("token")
        if not escalation_jwt:
            for cookie_name, cookie_value in resp.cookies.items():
                if cookie_name == "agentstream_escalation":
                    escalation_jwt = cookie_value
                    break
        if not escalation_jwt:
            click.echo("Error: backend did not return an escalation token.", err=True)
            raise SystemExit(1)
        expires_at = int(body.get("expires_at") or (time.time() + 3600))
        store.save_escalation(base_endpoint, escalation_jwt, expires_at)
        mins = max(1, (expires_at - int(time.time())) // 60)
        click.echo(f"Admin mode active, expires in {mins}m.")
        track("cli.sudo", {"flow": "direct"})
        return

    # 403 phrh_required → fall through to OIDC step-up.
    needs_stepup = False
    if resp.status_code == 403:
        try:
            detail = resp.json().get("detail")
        except ValueError:
            detail = None
        if isinstance(detail, dict) and detail.get("code") == "phrh_required":
            needs_stepup = True

    if not needs_stepup:
        click.echo(f"Error: escalation failed ({resp.status_code}): {resp.text}", err=True)
        raise SystemExit(1)

    # OIDC phrh step-up via browser loopback.
    click.echo("Biometric step-up required — opening browser...")
    login_config = load_config()
    auth = AuthManager(endpoint=base_endpoint, config=login_config)
    _resolve_sso_org(auth, base_endpoint, issuer_hint=issuer_hint)

    try:
        result = asyncio.run(auth.auth_via_oidc_escalation())
    except OIDCAuthError as e:
        click.echo(f"Error: escalation step-up failed: {e}", err=True)
        raise SystemExit(1)

    escalation_jwt = result.get("escalation_token")
    expires_at = int(result.get("expires_at") or (time.time() + 3600))
    if not escalation_jwt:
        click.echo("Error: step-up callback did not return an escalation token.", err=True)
        raise SystemExit(1)

    store.save_escalation(base_endpoint, escalation_jwt, expires_at)
    mins = max(1, (expires_at - int(time.time())) // 60)
    click.echo(f"Admin mode active, expires in {mins}m.")
    track("cli.sudo", {"flow": "oidc_stepup"})


@main.command()
def logout():
    """Clear stored credentials."""
    track("cli.logout")
    auth = AuthManager(endpoint="")  # Endpoint not needed for logout
    auth.logout()
    click.echo("Logged out successfully.")


# ---------------------------------------------------------------------------
# Alpha commands — experimental features, hidden from main help
# ---------------------------------------------------------------------------


@main.group(hidden=True)
def alpha():
    """Experimental commands (subject to change)."""
    pass


@alpha.command()
@click.option("--state-dir", type=click.Path(), default=str(DEFAULT_STATE_DIR))
def flush(state_dir: str):
    """Trigger an immediate sync cycle in the running daemon.

    Sends SIGUSR1 to the daemon process, causing it to wake up and sync
    all tracked sessions immediately instead of waiting for the next interval.

    Debounced: skips if a flush was sent less than 1 second ago (PostToolUse
    hooks can fire dozens of times per turn).
    """
    state_path = Path(state_dir)

    # Debounce: skip if last flush was < 1s ago
    stamp_file = state_path / ".flush_stamp"
    now = time.time()
    try:
        if stamp_file.exists():
            last = float(stamp_file.read_text().strip())
            if now - last < 1.0:
                raise SystemExit(0)
    except (ValueError, OSError):
        pass

    pid = find_daemon_pid(state_path)
    if pid is None:
        raise SystemExit(0)

    try:
        os.kill(pid, signal.SIGUSR1)
        # Record timestamp for debounce
        try:
            stamp_file.write_text(str(now))
        except OSError:
            pass
    except ProcessLookupError:
        raise SystemExit(0)
    except PermissionError:
        click.echo(f"Permission denied sending signal to daemon (PID {pid})", err=True)
        raise SystemExit(1)


@alpha.command()
@click.argument("agent", type=str)
@click.argument("agent_args", nargs=-1, type=click.UNPROCESSED)
@click.option("--no-worktree", is_flag=True, help="Skip worktree creation, use current directory")
@click.pass_context
def launch(ctx: click.Context, agent: str, agent_args: tuple[str, ...], no_worktree: bool):
    """Launch an agent in a fresh git worktree with remote-control support.

    Creates a git worktree (hivemind-<id>), stamps the tmux pane with a
    marker, and launches the agent inside it. The unique worktree path
    lets the daemon reliably route dashboard messages to this pane.

    On exit, prompts whether to delete the worktree.

    \b
    Examples:
        hivemind alpha launch claude
        hivemind alpha launch claude -- --model opus
        hivemind alpha launch codex
        hivemind alpha launch claude --no-worktree
    """
    # If not inside tmux, create a session and re-exec inside it.
    # The re-exec'd process will see TMUX set and proceed normally.
    if not os.environ.get("TMUX"):
        # Verify tmux is installed
        if not shutil.which("tmux"):
            click.echo("Error: tmux is required but not found in PATH.", err=True)
            if sys.platform == "darwin":
                click.echo("Install it with: brew install tmux", err=True)
            else:
                click.echo("Install it with your package manager, e.g.: apt install tmux", err=True)
            raise SystemExit(1)

        short_id = str(uuid.uuid4())[:8]
        session_name = f"{agent}-{short_id}"

        # Rebuild the command to re-exec inside tmux
        hivemind_path = shutil.which("hivemind") or sys.argv[0]
        inner_cmd = [hivemind_path, "alpha", "launch", agent]
        if no_worktree:
            inner_cmd.append("--no-worktree")
        if agent_args:
            inner_cmd.append("--")
            inner_cmd.extend(agent_args)

        click.echo(f"Starting tmux session: {session_name}")
        os.execvp("tmux", ["tmux", "new-session", "-s", session_name, "--", *inner_cmd])

    # Must be in a git repo (for worktree creation)
    if not no_worktree:
        repo_root_result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if repo_root_result.returncode != 0:
            click.echo("Error: not inside a git repository.", err=True)
            raise SystemExit(1)
        repo_root = repo_root_result.stdout.strip()

    # Verify the agent command exists
    agent_path = shutil.which(agent)
    if not agent_path:
        click.echo(f"Error: '{agent}' not found in PATH.", err=True)
        raise SystemExit(1)

    # Generate unique IDs
    marker = str(uuid.uuid4())
    short_id = marker[:8]

    # Create git worktree with unique name off the repo's default branch
    worktree_path = None
    if not no_worktree:
        worktree_name = f"hivemind-{short_id}"
        worktree_path = str(Path(repo_root) / ".hivemind" / "worktrees" / worktree_name)

        # Determine the default branch (main/master) and create a new branch
        # off of it, matching Claude Code's native --worktree behavior.
        start_point = "HEAD"
        for candidate in ("main", "master"):
            check = subprocess.run(
                ["git", "rev-parse", "--verify", f"refs/heads/{candidate}"],
                capture_output=True,
                timeout=5,
            )
            if check.returncode == 0:
                start_point = candidate
                break

        wt_result = subprocess.run(
            ["git", "worktree", "add", "-b", worktree_name, worktree_path, start_point],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if wt_result.returncode != 0:
            click.echo(f"Error creating worktree: {wt_result.stderr.strip()}", err=True)
            raise SystemExit(1)

        click.echo(f"  Worktree: {worktree_path}")

        # Write marker file so the daemon can link discovered sessions
        # (e.g. Codex, which generates its own session ID) back to this marker.
        marker_dir = Path(worktree_path) / ".hivemind"
        marker_dir.mkdir(parents=True, exist_ok=True)
        (marker_dir / "session-marker").write_text(marker)

    # Set tmux pane markers (ID + agent type for boot recovery)
    subprocess.run(
        ["tmux", "set-option", "-p", "@hivemind_pane_id", marker],
        capture_output=True,
        timeout=5,
    )
    subprocess.run(
        ["tmux", "set-option", "-p", "@hivemind_agent_type", agent],
        capture_output=True,
        timeout=5,
    )

    # Get current pane target for the launch file
    pane_result = subprocess.run(
        ["tmux", "display-message", "-p", "#{session_name}:#{window_index}.#{pane_index}"],
        capture_output=True,
        text=True,
        timeout=5,
    )
    pane_target = pane_result.stdout.strip() if pane_result.returncode == 0 else ""

    # Register session with daemon via file-drop IPC
    create_launch(
        LaunchRecord(
            marker=marker,
            agent=agent,
            pane_target=pane_target,
            worktree_path=worktree_path,
        )
    )

    # Signal daemon to pick up the launch file immediately
    pid = find_daemon_pid(DEFAULT_STATE_DIR)
    if pid:
        try:
            os.kill(pid, signal.SIGUSR1)
        except (ProcessLookupError, PermissionError):
            pass

    click.echo(f"  Marker:   {short_id}...")

    # Build args
    args = [agent_path]

    # Claude Code: pass --session-id so JSONL filename == marker (guaranteed match)
    if agent == "claude":
        args.extend(["--session-id", marker])

    args.extend(agent_args)

    click.echo(f"Launching {agent} with hivemind remote-control\n")

    # Run agent as subprocess (not exec) so we can prompt for cleanup after
    cwd = worktree_path or os.getcwd()
    try:
        proc = subprocess.run(args, cwd=cwd)
        exit_code = proc.returncode
    except KeyboardInterrupt:
        exit_code = 130
    finally:
        # Clear pane markers (signals daemon to prune the relay)
        subprocess.run(
            ["tmux", "set-option", "-pu", "@hivemind_pane_id"],
            capture_output=True,
            timeout=5,
        )
        subprocess.run(
            ["tmux", "set-option", "-pu", "@hivemind_agent_type"],
            capture_output=True,
            timeout=5,
        )

    # Prompt for worktree cleanup
    if worktree_path and Path(worktree_path).exists():
        click.echo()
        # Check for uncommitted changes
        status = subprocess.run(
            ["git", "-C", worktree_path, "status", "--porcelain"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        has_changes = bool(status.stdout.strip())

        if has_changes:
            click.echo(f"Worktree has uncommitted changes: {worktree_path}")
            if click.confirm("Delete worktree anyway? (changes will be lost)", default=False):
                subprocess.run(
                    ["git", "worktree", "remove", "--force", worktree_path],
                    timeout=30,
                )
                click.echo("Worktree deleted.")
            else:
                click.echo(f"Worktree kept at: {worktree_path}")
        else:
            if click.confirm("Delete worktree?", default=True):
                subprocess.run(
                    ["git", "worktree", "remove", worktree_path],
                    timeout=30,
                )
                click.echo("Worktree deleted.")
            else:
                click.echo(f"Worktree kept at: {worktree_path}")

    raise SystemExit(exit_code)


@main.command("dev-token", hidden=True)
def dev_token():
    """Get a dev-mode JWT for local frontend development.

    Authenticates via GitHub CLI (gh) and exchanges for a token
    with dev:true in the payload. Prints the token to stdout.
    """

    # Get GitHub token from gh CLI
    try:
        result = subprocess.run(["gh", "auth", "token"], capture_output=True, text=True, timeout=5)
        if result.returncode != 0:
            click.echo(
                "Error: GitHub CLI (gh) not authenticated. Run 'gh auth login' first.", err=True
            )
            raise SystemExit(1)
        gh_token = result.stdout.strip()
    except FileNotFoundError:
        click.echo(
            "Error: GitHub CLI (gh) not found. Install it from https://cli.github.com", err=True
        )
        raise SystemExit(1)
    except subprocess.TimeoutExpired:
        click.echo("Error: GitHub CLI (gh) timed out. Check your network connection.", err=True)
        raise SystemExit(1)

    # Exchange for dev token
    effective_endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(effective_endpoint)
    hw = collect_hardware_info()

    try:
        response = httpx.post(
            f"{base_endpoint}/v1/auth/exchange",
            json={
                "github_token": gh_token,
                "auth_method": "gh_cli",
                "device_id": hw.hardware_uuid or hw.hostname or "dev",
                "dev": True,
                "hostname": hw.hostname,
                "os": hw.os,
                "os_version": hw.os_version,
            },
            timeout=30,
        )
    except (httpx.RequestError, httpx.TimeoutException) as exc:
        click.echo(f"Error: Failed to connect to {base_endpoint}: {exc}", err=True)
        raise SystemExit(1)

    if response.status_code != 200:
        click.echo(
            f"Error: Token exchange failed ({response.status_code}): {response.text}", err=True
        )
        raise SystemExit(1)

    # Print just the token (for use in scripts/Makefile)
    click.echo(response.json()["token"])


@main.command()
@click.argument(
    "agent_type",
    type=click.Choice(sorted(VALID_AGENT_TYPES)),
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Show what would be deleted without making changes",
)
@click.option(
    "--yes",
    "-y",
    is_flag=True,
    help="Skip confirmation prompt",
)
@click.option(
    "--state-dir",
    type=click.Path(),
    default=str(DEFAULT_STATE_DIR),
    help="State directory path",
)
def resync(
    agent_type: str,
    dry_run: bool,
    yes: bool,
    state_dir: str,
) -> None:
    """Force re-sync all sessions for an agent type.

    Deletes all sessions for the specified agent type from both the backend
    server and local daemon state, allowing them to be re-discovered and
    re-synced from scratch.

    Examples:

        # Preview what would be deleted
        hivemind resync cursor --dry-run

        # Delete and re-sync cursor sessions (with confirmation)
        hivemind resync cursor

        # Delete without confirmation
        hivemind resync cursor --yes
    """

    effective_endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(effective_endpoint)
    state_path = Path(state_dir)
    state_file = state_path / "state.json"

    # Check authentication
    auth = AuthManager(endpoint=base_endpoint)
    creds = auth.store.load(auth.endpoint)

    if not creds or auth.store.is_expired(creds):
        click.echo("Not authenticated. Run 'hivemind login' first.", err=True)
        raise SystemExit(1)

    # Dry run: just show preview
    if dry_run:
        preview_url = f"{base_endpoint}/v1/sessions/cleanup/preview"
        try:
            response = httpx.get(
                preview_url,
                params={"agent_type": agent_type},
                headers={"Authorization": f"Bearer {creds.token}"},
                timeout=30.0,
            )

            if response.status_code == 401:
                click.echo("Not authenticated. Run 'hivemind login' first.", err=True)
                raise SystemExit(1)

            if response.status_code == 429:
                retry_after = response.headers.get("Retry-After", "60")
                click.echo(f"Rate limited. Please try again in {retry_after} seconds.", err=True)
                raise SystemExit(1)

            response.raise_for_status()
            data = response.json()

            click.echo(f"\nDry run: resync {agent_type} sessions for {creds.email}")
            click.echo(f"\nBackend cleanup preview ({base_endpoint}):")
            click.echo(f"  Sessions:       {data.get('session_count', 0):,}")
            click.echo(f"  Events:         {data.get('event_count', 0):,}")
            click.echo(f"  Source entries: {data.get('source_entry_count', 0):,}")

            # Count local sessions
            if state_file.exists():
                state = load_state(state_file)
                local_count = _count_local_sessions_by_agent_type(state, agent_type)
                click.echo("\nLocal state preview:")
                click.echo(f"  Sessions:       {local_count:,}")

            click.echo("\nNo changes made. Run without --dry-run to proceed.")
            return

        except httpx.HTTPStatusError as e:
            click.echo(f"HTTP error: {e.response.status_code} - {e.response.text}", err=True)
            raise SystemExit(1)
        except httpx.RequestError as e:
            click.echo(f"Connection error: {e}", err=True)
            raise SystemExit(1)

    # Get preview counts for confirmation
    preview_url = f"{base_endpoint}/v1/sessions/cleanup/preview"
    try:
        response = httpx.get(
            preview_url,
            params={"agent_type": agent_type},
            headers={"Authorization": f"Bearer {creds.token}"},
            timeout=30.0,
        )

        if response.status_code == 401:
            click.echo("Not authenticated. Run 'hivemind login' first.", err=True)
            raise SystemExit(1)

        if response.status_code == 429:
            retry_after = response.headers.get("Retry-After", "60")
            click.echo(f"Rate limited. Please try again in {retry_after} seconds.", err=True)
            raise SystemExit(1)

        response.raise_for_status()
        preview_data = response.json()
        session_count = preview_data.get("session_count", 0)

    except httpx.HTTPStatusError as e:
        click.echo(f"HTTP error: {e.response.status_code} - {e.response.text}", err=True)
        raise SystemExit(1)
    except httpx.RequestError as e:
        click.echo(f"Connection error: {e}", err=True)
        raise SystemExit(1)

    # Confirm with user (only if there are sessions to delete)
    if not yes and session_count > 0:
        if not click.confirm(
            f"This will delete {session_count:,} {agent_type} sessions. Continue?"
        ):
            click.echo("Aborted.")
            return

    # Output summary header
    click.echo(f"\nResync {agent_type} sessions for {creds.email}")
    click.echo()

    # Call backend DELETE endpoint (only if there are sessions to delete)
    cleanup_data: dict[str, int] = {}
    if session_count > 0:
        cleanup_url = f"{base_endpoint}/v1/sessions/cleanup"
        try:
            response = httpx.request(
                "DELETE",
                cleanup_url,
                json={"agent_type": agent_type},
                headers={"Authorization": f"Bearer {creds.token}"},
                timeout=60.0,
            )

            if response.status_code == 401:
                click.echo("Not authenticated. Run 'hivemind login' first.", err=True)
                raise SystemExit(1)

            if response.status_code == 429:
                retry_after = response.headers.get("Retry-After", "60")
                click.echo(f"Rate limited. Please try again in {retry_after} seconds.", err=True)
                raise SystemExit(1)

            response.raise_for_status()
            cleanup_data = response.json()

        except httpx.HTTPStatusError as e:
            click.echo(f"HTTP error: {e.response.status_code} - {e.response.text}", err=True)
            raise SystemExit(1)
        except httpx.RequestError as e:
            click.echo(f"Connection error: {e}", err=True)
            raise SystemExit(1)

        # Backend cleanup summary
        click.echo("Backend cleanup:")
        click.echo(f"  ✓ Deleted {cleanup_data.get('deleted_sessions', 0):,} sessions")
        click.echo(f"  ✓ Deleted {cleanup_data.get('deleted_events', 0):,} events")
        click.echo(f"  ✓ Deleted {cleanup_data.get('deleted_source_entries', 0):,} source entries")
        click.echo()
    else:
        click.echo("Backend cleanup:")
        click.echo(f"  ✓ No {agent_type} sessions to delete")
        click.echo()

    # Update local state
    click.echo("Local state:")
    daemon_running = is_daemon_running(state_path)
    local_state_error = False

    if daemon_running:
        # Create trigger file for daemon to pick up
        try:
            trigger_path = create_trigger(agent_type, "resync-command")
            click.echo(f"  ✓ Signaled daemon to reset {agent_type} state")

            # Poll for trigger deletion (daemon acknowledgment)
            acknowledged = _poll_for_trigger_deletion(trigger_path, timeout=30.0)

            if acknowledged:
                click.echo("  ✓ Daemon acknowledged reset")
            else:
                click.echo(
                    "  ! Daemon did not acknowledge within 30s (trigger may still be processed)",
                    err=True,
                )
        except Exception as e:
            local_state_error = True
            click.echo(f"  ! Error signaling daemon: {e}", err=True)
            click.echo(f"    You may need to manually clear state from {state_file}")
    else:
        # Daemon not running, update state directly
        try:
            with locked_state_update(state_path):
                state = load_state(state_file)
                cleared_count = clear_sessions_by_agent_type(
                    state, agent_type, server_url=base_endpoint
                )
                save_state(state, state_file)
                click.echo(f"  ✓ Cleared {cleared_count:,} {agent_type} sessions from local state")
        except RuntimeError as e:
            # This shouldn't happen since we checked is_daemon_running
            local_state_error = True
            click.echo(f"  ! Error updating local state: {e}", err=True)
            click.echo(f"    State file: {state_file}")
        except Exception as e:
            local_state_error = True
            click.echo(f"  ! Error updating local state: {e}", err=True)
            click.echo(f"    State file: {state_file}")

    click.echo()
    track("cli.resync", {"agent_type": agent_type})
    if local_state_error:
        click.echo(
            "Warning: Backend cleanup succeeded but local state update failed.\n"
            "Consider restarting the daemon to ensure clean state."
        )
    else:
        click.echo(f"Next: Daemon will re-discover and sync {agent_type} sessions automatically.")


def _count_local_sessions_by_agent_type(state: DaemonState, agent_type: str) -> int:
    """Count sessions matching an agent type across all servers."""

    from agentstream.adapters import get_adapter_for_path  # noqa: PLC0415 — mocked in tests via agentstream.adapters

    count = 0
    for server_state in state.servers.values():
        for session_sync_state in server_state.sessions.values():
            file_path = Path(session_sync_state.file_path)
            adapter = get_adapter_for_path(file_path)
            if adapter is not None and adapter.name == agent_type:
                count += 1
    return count


def _poll_for_trigger_deletion(trigger_file: Path, timeout: float = 30.0) -> bool:
    """Poll for trigger file deletion (daemon acknowledgment).

    Args:
        trigger_file: Path to the trigger file to watch.
        timeout: Maximum time to wait in seconds.

    Returns:
        True if trigger was deleted (daemon acknowledged), False if timeout.
    """

    start_time = time.time()
    poll_interval = 0.1  # 100ms

    while time.time() - start_time < timeout:
        if not trigger_file.exists():
            return True
        time.sleep(poll_interval)

    return False


@main.command()
@click.argument("message")
@click.option("--session", "session_id", required=True, help="Target Claude session ID")
def send(message: str, session_id: str):
    """Send a message to a running Claude Code session via channels.

    \b
    Examples:
        hivemind send --session fc004127 "please run the test suite"
        hivemind send --session 39ab577f-02d3-5acf-b07e-817845de9f63 "check the build"

    The session must have an active MCP channel bridge (hivemind-channel)
    connected to receive the message.
    """
    # Authenticate via backend API (same pattern as `hivemind api`)
    effective_endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth = AuthManager(endpoint=base_endpoint)
    creds = auth.store.load(auth.endpoint)

    if not creds or auth.store.is_expired(creds):
        click.echo(
            f"Error: Not authenticated for {base_endpoint}. Run 'hivemind login' first.",
            err=True,
        )
        raise SystemExit(1)

    url = f"{base_endpoint}/v1/channels/{session_id}/send"
    headers = {
        "Authorization": f"Bearer {creds.token}",
        "Content-Type": "application/json",
    }

    try:
        resp = httpx.post(
            url,
            json={"content": message},
            headers=headers,
            timeout=10.0,
        )
    except httpx.ConnectError:
        click.echo(f"Error: Cannot connect to {base_endpoint}", err=True)
        raise SystemExit(1)

    if resp.status_code == 200:
        data = resp.json()
        if data.get("ok"):
            click.echo("Message delivered.")
        else:
            click.echo(f"Warning: {data.get('detail', 'No active subscriber')}", err=True)
    elif resp.status_code == 404:
        click.echo("Error: Session not found (check session ID and ensure you own it)", err=True)
        raise SystemExit(1)
    else:
        click.echo(f"Error: {resp.status_code} - {resp.text}", err=True)
        raise SystemExit(1)


@main.group()
def channels():
    """Manage channel server for Claude Code integration."""
    pass


@channels.command("install")
def channels_install():
    """Register hivemind-channel MCP server with Claude Code.

    \b
    This adds the server to ~/.claude.json (user-level MCP config) so Claude
    Code knows how to start it. You still need to activate it per-session
    with the --dangerously-load-development-channels flag:

        claude --dangerously-load-development-channels server:hivemind-channel

    The "server:" prefix means a bare MCP server from your local config
    (vs "plugin:" for published marketplace channels). The --dangerously flag
    is required because hivemind-channel is not on the published allowlist.
    """
    # Use ~/.claude.json for user-level MCP config (not settings.json)
    config_path = Path.home() / ".claude.json"

    if not (Path.home() / ".claude").exists():
        click.echo("Error: ~/.claude directory not found. Is Claude Code installed?", err=True)
        raise SystemExit(1)

    # Load existing config
    if config_path.exists():
        with open(config_path) as f:
            config = json.load(f)
    else:
        config = {}

    mcp_servers = config.setdefault("mcpServers", {})

    if "hivemind-channel" in mcp_servers:
        click.echo("hivemind-channel is already registered.")
        click.echo("\nActivate per-session with:")
        click.echo("  claude --dangerously-load-development-channels server:hivemind-channel")
        return

    mcp_servers["hivemind-channel"] = {
        "command": "hivemind-channel",
        "args": [],
    }

    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)
        f.write("\n")

    click.echo("Registered hivemind-channel in ~/.claude.json")
    click.echo("\nActivate per-session with:")
    click.echo("  claude --dangerously-load-development-channels server:hivemind-channel")
    click.echo("\nOr add a shell alias:")
    click.echo(
        "  alias claude-hm='claude --dangerously-load-development-channels server:hivemind-channel'"
    )


@channels.command("status")
def channels_status():
    """Show active channel connections for your sessions."""
    effective_endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth = AuthManager(endpoint=base_endpoint)
    creds = auth.store.load(auth.endpoint)

    if not creds or auth.store.is_expired(creds):
        click.echo(
            f"Error: Not authenticated for {base_endpoint}. Run 'hivemind login' first.",
            err=True,
        )
        raise SystemExit(1)

    try:
        resp = httpx.get(
            f"{base_endpoint}/v1/channels",
            headers={"Authorization": f"Bearer {creds.token}"},
            timeout=10.0,
        )
    except httpx.ConnectError:
        click.echo(f"Error: Cannot connect to {base_endpoint}", err=True)
        raise SystemExit(1)

    if resp.status_code == 200:
        data = resp.json()
        channels_list = data.get("channels", [])
        click.echo(f"Backend: {base_endpoint}")
        if channels_list:
            click.echo(f"\nActive channel connections ({len(channels_list)}):")
            for ch in channels_list:
                click.echo(f"  session: {ch['session_id']}")
        else:
            click.echo("\nNo active channel connections.")
            click.echo(
                "Start Claude with: claude --dangerously-load-development-channels server:hivemind-channel"
            )
    else:
        click.echo(f"Error: {resp.status_code} - {resp.text}", err=True)
        raise SystemExit(1)


@main.command()
@click.argument("path")
@click.option(
    "-X",
    "--method",
    default="GET",
    type=click.Choice(["GET", "POST", "PUT", "DELETE", "PATCH"], case_sensitive=False),
    help="HTTP method (default: GET)",
)
@click.option(
    "-d",
    "--data",
    help="Request body (JSON string)",
)
@click.option(
    "-q",
    "--query",
    multiple=True,
    help="Query parameter as key=value (can be repeated)",
)
@click.option(
    "--raw",
    is_flag=True,
    help="Output raw JSON without pretty printing",
)
@click.option(
    "-v",
    "--verbose",
    is_flag=True,
    help="Show request details",
)
def api(
    path: str,
    method: str,
    data: str | None,
    query: tuple[str, ...],
    raw: bool,
    verbose: bool,
):
    """Make authenticated API requests (curl-like).

    PATH is the API endpoint path. It will be prefixed with /v1 if it doesn't
    start with /v1. Examples:

    \b
        # Get a session
        hivemind api /sessions/5144a9f9-abc8-5c7e-811d-24964af1eb06

        # List sessions with query params
        hivemind api /sessions -q limit=10

        # Get session summary
        hivemind api /sessions/abc123/summary

        # Trigger enrichment (PUT request)
        hivemind api -X PUT /sessions/abc123/summary

        # Get stats
        hivemind api /stats/active-users

    The command automatically uses your stored authentication token.
    """

    # Determine effective endpoint
    effective_endpoint = get_effective_endpoint()

    # Get authentication. Use load_base_only() so the Bearer header always
    # carries the base session JWT — the server's purpose-binding guard
    # rejects escalation JWTs (esc=true) presented as bearer credentials
    # (see backend/api/src/agentstream_api/main.py). If an active escalation
    # is present we attach it separately via the agentstream_escalation
    # cookie, matching the browser flow.
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth = AuthManager(endpoint=base_endpoint)
    creds = auth.store.load_base_only(auth.endpoint)

    if not creds or auth.store.is_expired(creds):
        if _is_local_dev_endpoint(base_endpoint):
            if asyncio.run(_dev_mode_authenticate(auth)):
                creds = auth.store.load_base_only(auth.endpoint)

    if not creds or auth.store.is_expired(creds):
        click.echo(
            f"Error: Not authenticated for {base_endpoint}. Run 'hivemind login' first.", err=True
        )
        raise SystemExit(1)

    # Build URL
    # Normalize path - add /v1 prefix if needed (except for root-level endpoints)
    if not path.startswith("/"):
        path = "/" + path
    # Don't add /v1 prefix for root-level endpoints like /health
    if not path.startswith("/v1") and path not in ("/health",):
        path = "/v1" + path

    url = base_endpoint + path

    # Parse query parameters
    params = {}
    for q in query:
        if "=" in q:
            key, value = q.split("=", 1)
            params[key] = value
        else:
            click.echo(f"Invalid query parameter: {q} (expected key=value)", err=True)
            raise SystemExit(1)

    # Parse request body
    body = None
    if data:
        try:
            body = json.loads(data)
        except json.JSONDecodeError as e:
            click.echo(f"Invalid JSON data: {e}", err=True)
            raise SystemExit(1)

    # Build headers
    headers = {
        "Authorization": f"Bearer {creds.token}",
        "Content-Type": "application/json",
    }

    # Attach escalation as a cookie if admin mode is active. The server
    # reads this from request.cookies["agentstream_escalation"] and uses
    # it to raise the effective role for the request. Expired escalations
    # are silently ignored server-side, so we also check locally.
    cookies = None
    if (
        creds.escalation_token
        and creds.escalation_expires_at
        and int(time.time()) < creds.escalation_expires_at
    ):
        cookies = {"agentstream_escalation": creds.escalation_token}

    if verbose:
        click.echo(f"{method.upper()} {url}", err=True)
        if params:
            click.echo(f"Query: {params}", err=True)
        if cookies:
            click.echo("Admin mode: attaching escalation cookie", err=True)
        if body:
            click.echo(f"Body: {json.dumps(body)}", err=True)
        click.echo("", err=True)

    # Make request
    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.request(
                method=method.upper(),
                url=url,
                params=params if params else None,
                json=body,
                headers=headers,
                cookies=cookies,
            )

        # Output response
        if verbose:
            click.echo(f"Status: {response.status_code}", err=True)
            click.echo("", err=True)

        # Try to parse as JSON
        try:
            result = response.json()
            if raw:
                click.echo(json.dumps(result))
            else:
                click.echo(json.dumps(result, indent=2))
        except json.JSONDecodeError:
            # Not JSON, output as text
            click.echo(response.text)

        track("cli.api", {"method": method.upper(), "path": path})

        # Exit with error code if not 2xx
        if not response.is_success:
            raise SystemExit(1)

    except httpx.RequestError as e:
        click.echo(f"Request failed: {e}", err=True)
        raise SystemExit(1)


@main.command()
@click.option("-f", "--follow", is_flag=True, help="Follow log output (like tail -f)")
@click.option("-n", "--lines", default=50, help="Number of lines to show (default: 50)")
def logs(follow: bool, lines: int):
    """View or follow the daemon log file.

    Dispatches to the same source ``hivemind status`` reports: journald
    on Linux/systemd, the platform log file otherwise.

    Examples:

        # View recent logs
        hivemind logs

        # Follow logs in real-time
        hivemind logs -f

        # Show last 100 lines
        hivemind logs -n 100
    """
    source = resolve_log_source()

    if source.kind == "journald":
        _logs_journald(follow, lines)
    elif source.kind == "syslog_file" and source.path is not None:
        _tail_file(source.path, follow, lines, filter_pattern=source.filter_pattern)
    else:
        _logs_file(source, follow, lines)


def _logs_journald(follow: bool, lines: int):
    """View logs from journald via journalctl -t hivemind."""
    try:
        if follow:
            click.echo("Streaming logs (Ctrl+C to stop)...")
            click.echo("-" * 60)

            process = subprocess.Popen(
                ["journalctl", "-t", "hivemind", "-f", "--no-pager"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )

            try:
                if process.stdout:
                    for line in process.stdout:
                        click.echo(line.rstrip())
            except KeyboardInterrupt:
                process.terminate()
                click.echo("\nStopped.")
        else:
            click.echo(f"Showing last {lines} log entries...")
            click.echo("-" * 60)

            result = subprocess.run(
                ["journalctl", "-t", "hivemind", "-n", str(lines), "--no-pager"],
                capture_output=True,
                text=True,
                timeout=30,
            )

            if result.returncode == 0 and result.stdout.strip():
                click.echo(result.stdout)
            else:
                # journald has no hivemind entries yet (daemon never ran or
                # logs went elsewhere). Fall back to file-based search so
                # we don't leave the user staring at a blank screen.
                click.echo("No journalctl entries found, checking log files...")
                _logs_file(resolve_log_source(), follow, lines)
    except FileNotFoundError:
        # journalctl missing despite being on the discovery path; degrade
        # to file-based output.
        _logs_file(resolve_log_source(), follow, lines)


def _logs_file(source: LogSource, follow: bool, lines: int):
    """View logs from ``source.path`` if it exists, else explain what was checked."""
    if source.path is not None and source.path.exists():
        click.echo(f"Log file: {source.path}")
        _tail_file(source.path, follow, lines, filter_pattern=source.filter_pattern)
        return

    default_path = get_default_log_path()
    click.echo("No log file found. Checked:")
    click.echo(f"  - {default_path} (default)")
    click.echo("  - /opt/homebrew/var/log/hivemind.log (Homebrew Apple Silicon)")
    click.echo("  - /usr/local/var/log/hivemind.log (Homebrew Intel)")
    click.echo("  - /tmp/hivemind.log (legacy)")
    click.echo("\nThe daemon may not have been started yet.")


def _tail_file(file_path: Path, follow: bool, lines: int, filter_pattern: str | None = None):
    """Tail a log file, optionally filtering by pattern.

    Args:
        file_path: Path to the file to tail.
        follow: If True, follow the file like 'tail -f'.
        lines: Number of lines to show initially.
        filter_pattern: Optional pattern to filter lines.
    """
    if not file_path.exists():
        click.echo(f"File not found: {file_path}")
        return

    if follow:
        click.echo(f"Following {file_path} (Ctrl+C to stop)...")
        click.echo("-" * 60)

        try:
            # Build tail command
            cmd = ["tail", "-f", "-n", str(lines), str(file_path)]

            if filter_pattern:
                # Pipe through grep
                tail_proc = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                )
                grep_proc = subprocess.Popen(
                    ["grep", "--line-buffered", filter_pattern],
                    stdin=tail_proc.stdout,
                    stdout=subprocess.PIPE,
                    text=True,
                )

                if grep_proc.stdout:
                    for line in grep_proc.stdout:
                        click.echo(line.rstrip())

                tail_proc.terminate()
                grep_proc.terminate()
            else:
                process = subprocess.Popen(cmd, stdout=subprocess.PIPE, text=True)
                if process.stdout:
                    for line in process.stdout:
                        click.echo(line.rstrip())
                process.terminate()

        except KeyboardInterrupt:
            click.echo("\nStopped.")
    else:
        click.echo(f"Showing last {lines} lines from {file_path}...")
        click.echo("-" * 60)

        try:
            if filter_pattern:
                # grep then tail
                grep_proc = subprocess.Popen(
                    ["grep", filter_pattern, str(file_path)],
                    stdout=subprocess.PIPE,
                    text=True,
                )
                result = subprocess.run(
                    ["tail", "-n", str(lines)],
                    stdin=grep_proc.stdout,
                    capture_output=True,
                    text=True,
                )
                grep_proc.wait()
                if result.stdout:
                    click.echo(result.stdout.rstrip())
            else:
                result = subprocess.run(
                    ["tail", "-n", str(lines), str(file_path)],
                    capture_output=True,
                    text=True,
                )
                if result.stdout:
                    click.echo(result.stdout.rstrip())
        except FileNotFoundError:
            # tail/grep not available, read manually
            with open(file_path) as f:
                all_lines = f.readlines()
                if filter_pattern:
                    all_lines = [line for line in all_lines if filter_pattern in line]
                for line in all_lines[-lines:]:
                    click.echo(line.rstrip())


_DARWIN_LAUNCHD_LABEL = "com.wandb.hivemind"
_DARWIN_USER_PLIST = Path.home() / "Library" / "LaunchAgents" / f"{_DARWIN_LAUNCHD_LABEL}.plist"

# Marker the .pkg postinstall writes when no GUI user was logged in at
# install time (typical for MDM rollouts). install-service consumes it
# once the LaunchAgent is registered so doctor stops nagging.
_DARWIN_POSTINSTALL_MARKER = Path("/Library/Application Support/Hivemind/postinstall-pending.json")


def _resolve_invoking_hivemind() -> str | None:
    """Return the path of the hivemind binary executing this code.

    Prefers ``sys.executable`` resolved up to its entry-point shim so we
    pick the binary the user actually invoked, not whichever ``hivemind``
    happens to be earliest on PATH. Falls back to ``shutil.which`` for
    cases where ``sys.executable`` is a generic Python (dev runs of
    ``python -m hivemind``, pytest, etc.) and doesn't end in ``hivemind``.
    """
    exe = Path(sys.executable)
    if exe.name == "hivemind" or exe.name.startswith("hivemind"):
        return str(exe)
    # uv-tool / pipx put a `hivemind` shim next to `python`; prefer that.
    sibling = exe.parent / "hivemind"
    if sibling.exists():
        return str(sibling)
    return shutil.which("hivemind")


def _consume_postinstall_marker() -> None:
    """Best-effort: clear the MDM postinstall marker after registration.

    The marker lives under /Library/Application Support/ which is
    root-owned, so we can only delete it if invoked with sufficient
    privilege. On a normal interactive `hivemind install-service`
    invocation we won't have permission and the marker will linger;
    `hivemind doctor` will still display it but the LaunchAgent is
    actually registered, so the user can ignore the nag (or run with
    sudo). Silent is fine here — the marker is informational.
    """
    if not _DARWIN_POSTINSTALL_MARKER.exists():
        return
    try:
        _DARWIN_POSTINSTALL_MARKER.unlink()
    except OSError:
        pass


def _install_service_darwin(*, enable: bool, uninstall: bool) -> None:
    """macOS implementation of install-service.

    Writes a per-user LaunchAgent plist that runs whichever ``hivemind``
    binary is currently on ``$PATH`` (i.e. the same one the user just
    used to run this command — which is what they'd expect from
    ``pipx install``, ``uv tool install``, or a dev venv). If another
    install method has already registered a LaunchAgent under the
    ``com.wandb.hivemind`` label, we **take it over**: bootout the
    old one, write our plist, and bootstrap. launchd enforces label
    uniqueness inside ``gui/<UID>`` so there's only ever one daemon
    loaded at a time. The daemon lock file in ``~/.hivemind/`` is a
    second line of defence if something slips past launchd.

    Split out from ``install_service`` to keep the click command body
    small and because the macOS path is test-worthy independently.
    """
    uid = os.getuid()

    if uninstall:
        # Bootout is idempotent — it returns non-zero if the agent
        # isn't loaded, which is fine. We always delete the file if it
        # exists and report what we did.
        subprocess.run(
            ["launchctl", "bootout", f"gui/{uid}", str(_DARWIN_USER_PLIST)],
            capture_output=True,
        )
        if _DARWIN_USER_PLIST.exists():
            _DARWIN_USER_PLIST.unlink()
            click.echo(f"Removed {_DARWIN_USER_PLIST}")
        else:
            click.echo("No LaunchAgent file to remove.")
        click.echo("Hivemind LaunchAgent uninstalled.")
        return

    # Detect the install channel for the currently running hivemind CLI.
    # This reflects the binary invoking this command (via sys.executable),
    # not which binary an existing LaunchAgent may already be running.
    # We don't refuse on overlap — we take over — but we do want to tell
    # the user what's happening.
    try:
        current_channel = detect_install_method()
    except Exception:
        current_channel = "unknown"

    # `dev` and `unknown` aren't real install channels — there's no other
    # install to "take over" from, so skip the note. Everything else maps
    # to a registered channel with a human-readable label.
    descriptor = get_channel(current_channel)
    if descriptor is not None and current_channel not in ("dev", "unknown"):
        click.echo(f"Note: taking over LaunchAgent from the {descriptor.label}.")
        click.echo(
            "  The old install's binary stays on disk — you can remove it later if you want."
        )
    elif _DARWIN_USER_PLIST.exists():
        click.echo(f"Note: {_DARWIN_USER_PLIST} already exists; overwriting.")

    # Prefer sys.executable resolved up to its `hivemind` entry point
    # over `shutil.which("hivemind")`. With both a cask and a uv-tool
    # install present, `which` returns whichever shim comes first on
    # PATH — which may not be the binary the user just invoked. We
    # want the LaunchAgent to launch the same hivemind they're holding
    # in their hand.
    hivemind_bin = _resolve_invoking_hivemind()
    if not hivemind_bin:
        click.echo("Error: Could not find 'hivemind' executable on PATH.", err=True)
        click.echo(
            "Install hivemind first (e.g. pipx install wandb-hivemind or "
            "uv tool install wandb-hivemind).",
            err=True,
        )
        raise SystemExit(1)
    which_path = shutil.which("hivemind")
    if which_path and Path(which_path).resolve() != Path(hivemind_bin).resolve():
        click.echo(
            f"Note: PATH lookup found a different hivemind at {which_path}.\n"
            f"  Using {hivemind_bin} (the binary you invoked) for the LaunchAgent."
        )

    # Plist body mirrors the cask's postflight so a machine that was
    # on the cask and then switched to (say) a uv-tool install keeps
    # the same log-file paths and launchd behavior.
    log_dir = Path.home() / "Library" / "Logs" / "hivemind"
    log_dir.mkdir(parents=True, exist_ok=True)
    plist_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{_DARWIN_LAUNCHD_LABEL}</string>
    <key>ProgramArguments</key>
    <array>
        <string>{hivemind_bin}</string>
        <string>run</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>{log_dir}/hivemind.out.log</string>
    <key>StandardErrorPath</key>
    <string>{log_dir}/hivemind.err.log</string>
</dict>
</plist>
"""
    _DARWIN_USER_PLIST.parent.mkdir(parents=True, exist_ok=True)
    _DARWIN_USER_PLIST.write_text(plist_content)
    click.echo(f"Installed LaunchAgent: {_DARWIN_USER_PLIST}")

    # Always bootout first so an upgrade (re-running install-service)
    # doesn't fail with "already loaded".
    subprocess.run(
        ["launchctl", "bootout", f"gui/{uid}", str(_DARWIN_USER_PLIST)],
        capture_output=True,
    )

    if enable:
        result = subprocess.run(
            ["launchctl", "bootstrap", f"gui/{uid}", str(_DARWIN_USER_PLIST)],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            click.echo("LaunchAgent loaded (will start at next login and run now).")
            _consume_postinstall_marker()
        else:
            click.echo(
                f"Error: launchctl bootstrap failed: {result.stderr.strip()}",
                err=True,
            )
            click.echo(
                "  Try: launchctl load -w " + str(_DARWIN_USER_PLIST),
                err=True,
            )
            # The plist is on disk but launchd refused it. A wrapping
            # script (e.g. an MDM login policy) needs a non-zero exit
            # to know the registration didn't actually succeed.
            raise SystemExit(1)
    else:
        # We deliberately point the user at launchctl, NOT at
        # `hivemind start`. The generic ServiceManager abstraction
        # doesn't know about this specific plist — it falls through to
        # DirectServiceManager which would spawn a background process
        # completely outside launchd's control, leaving the LaunchAgent
        # unloaded. Loading it via launchctl is the one thing that
        # actually activates the plist we just wrote.
        click.echo(
            "To load the LaunchAgent now:\n"
            f"  launchctl bootstrap gui/$(id -u) {_DARWIN_USER_PLIST}\n"
            "It will also load automatically at next login."
        )

    click.echo()
    click.echo("To check status:  hivemind status")
    click.echo(f"To view logs:     tail -f {log_dir}/hivemind.out.log")
    click.echo("To remove:        hivemind install-service --uninstall")


@main.command("install-service", hidden=True)
@click.option("--enable/--no-enable", default=True, help="Enable service to start on login")
@click.option("--uninstall", is_flag=True, help="Remove installed service file")
def install_service(enable: bool, uninstall: bool):
    """[deprecated] Install the hivemind service. Prefer ``hivemind start``.

    ``hivemind start`` now auto-writes the LaunchAgent / unit file when
    one is missing, so there's no longer any reason to run this command
    explicitly. Kept for scripts and the ``--uninstall`` path.

    On Linux: installs a systemd user unit file and enables it.
    On macOS: writes a per-user LaunchAgent plist and bootstraps it
    into the user's gui domain. Will take over the LaunchAgent from
    another channel (cask / formula / .pkg) using the "last writer
    wins" policy — the previous channel's binary stays on disk but
    the daemon now runs from the binary `hivemind` resolves to on
    the current PATH.

    Examples:

        # Install and enable the service
        hivemind install-service

        # Install without enabling (create file only)
        hivemind install-service --no-enable

        # Remove the service
        hivemind install-service --uninstall
    """

    system = platform.system().lower()

    if system == "darwin":
        _install_service_darwin(enable=enable, uninstall=uninstall)
        return

    if system != "linux":
        click.echo(f"Service installation is not supported on {platform.system()}.")
        return

    unit_dir = Path.home() / ".config" / "systemd" / "user"
    unit_file = unit_dir / "hivemind.service"

    if uninstall:
        # Stop and disable the service, then remove the unit file
        subprocess.run(
            ["systemctl", "--user", "stop", "hivemind"],
            capture_output=True,
        )
        subprocess.run(
            ["systemctl", "--user", "disable", "hivemind"],
            capture_output=True,
        )
        if unit_file.exists():
            unit_file.unlink()
            click.echo(f"Removed {unit_file}")
        else:
            click.echo("Service file not found, nothing to remove.")
        subprocess.run(
            ["systemctl", "--user", "daemon-reload"],
            capture_output=True,
        )
        click.echo("Hivemind service uninstalled.")
        return

    # Find the hivemind executable
    hivemind_bin = shutil.which("hivemind")
    if not hivemind_bin:
        click.echo("Error: Could not find 'hivemind' executable on PATH.", err=True)
        click.echo(
            "Install hivemind first (e.g., pip install hivemind or pipx install hivemind).",
            err=True,
        )
        raise SystemExit(1)

    # Generate unit file content with the actual executable path
    unit_content = f"""\
[Unit]
Description=Hivemind - Sync agentic coding sessions
Documentation=https://github.com/wandb/agentstream-py
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart={hivemind_bin} run
ExecReload=/bin/kill -HUP $MAINPID
Restart=on-failure
RestartSec=10

# Logging - let journald handle it (hivemind also writes to file)
StandardOutput=journal
StandardError=journal
SyslogIdentifier=hivemind

# Security hardening (user service, minimal restrictions)
NoNewPrivileges=true

[Install]
WantedBy=default.target
"""

    # Write the unit file
    unit_dir.mkdir(parents=True, exist_ok=True)
    unit_file.write_text(unit_content)
    click.echo(f"Installed service file: {unit_file}")

    # Reload systemd
    result = subprocess.run(
        ["systemctl", "--user", "daemon-reload"],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        click.echo(f"Warning: daemon-reload failed: {result.stderr.strip()}", err=True)

    if enable:
        result = subprocess.run(
            ["systemctl", "--user", "enable", "hivemind"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            click.echo("Service enabled (will start on login).")
        else:
            click.echo(f"Warning: enable failed: {result.stderr.strip()}", err=True)

    click.echo()
    click.echo("To start the service now:")
    click.echo("  systemctl --user start hivemind")
    click.echo()
    click.echo("To check status:")
    click.echo("  systemctl --user status hivemind")
    click.echo()
    click.echo("To view logs:")
    click.echo("  journalctl --user -t hivemind -f")


@main.command("web-sessions")
@click.option("--sync", "do_sync", is_flag=True, help="Sync unsynced web sessions now.")
def web_sessions(do_sync: bool):
    """List web sessions from Claude Code cloud.

    Shows sessions available in the cloud with their sync status.
    Web sessions are discovered from Claude Code web (claude.ai) using
    the same API as the --teleport feature.

    Requires Claude Code to be installed and authenticated with claude.ai.

    To configure web session syncing:
        hivemind config set web_sessions.enabled true
        hivemind config set web_sessions.poll_interval 900

    Examples:

        # List web sessions
        hivemind web-sessions

        # Sync unsynced web sessions now
        hivemind web-sessions --sync
    """
    # Check for credentials
    if not has_claude_credentials():
        click.echo("\nNo Claude credentials found.")
        click.echo("Web sessions require Claude Code to be installed and authenticated.")
        click.echo("\nTo authenticate:")
        click.echo("  1. Install Claude Code: https://claude.ai/code")
        click.echo("  2. Run: claude login")
        return

    creds = read_claude_credentials()
    if not creds:
        click.echo("\nFailed to read Claude credentials.")
        return

    if creds.is_expired:
        click.echo("\nClaude credentials are expired.")
        click.echo("Please re-authenticate with: claude login")
        return

    # Load state to check sync status
    state_file = DEFAULT_STATE_FILE
    state = load_state(state_file) if state_file.exists() else DaemonState()
    config = load_config()
    endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(endpoint)
    server_state = state.get_server_state(base_endpoint)

    # Get synced session IDs (web sessions have "web:" prefix).
    # Only consider sessions with last_entry_idx >= 0 as synced — sessions with -1
    # had their initial upload fail or were skipped as trivial.
    synced_ids = {
        sid.replace("web:", "")
        for sid, ss in server_state.sessions.items()
        if sid.startswith("web:") and ss.last_entry_idx >= 0
    }

    # Fetch sessions
    click.echo("\nFetching web sessions from Claude API...")

    web_client = WebSessionsClient(credentials=creds)

    async def fetch_sessions():
        return await web_client.list_sessions(limit=50)

    try:
        sessions = asyncio.run(fetch_sessions())
    except Exception as e:
        click.echo(f"\nError fetching sessions: {e}", err=True)
        return

    if not sessions:
        click.echo("No web sessions found.")
        return

    # Show config status
    click.echo(
        f"\nWeb sync: {'enabled' if config.web_sessions.enabled else 'disabled'} "
        f"(poll every {config.web_sessions.poll_interval // 60} min)"
    )
    click.echo(f"\nWeb Sessions ({len(sessions)} total):")
    click.echo("-" * 72)

    for session in sessions:
        # Format timestamps
        updated = ""
        if session.updated_at:
            updated = session.updated_at.strftime("%Y-%m-%d %H:%M")
        elif session.created_at:
            updated = session.created_at.strftime("%Y-%m-%d %H:%M")

        # Sync status
        is_synced = session.id in synced_ids
        status = click.style("✓", fg="green") if is_synced else click.style("○", fg="yellow")

        # Session name (truncated)
        name = session.name or "(unnamed)"
        if len(name) > 28:
            name = name[:25] + "..."

        # Project path (truncated)
        project = session.project_path or ""
        if len(project) > 24:
            project = "..." + project[-21:]

        click.echo(f"  {status}  {updated}  {name:<28}  {project}")

    click.echo("-" * 72)
    synced_count = len([s for s in sessions if s.id in synced_ids])
    click.echo(f"  {synced_count}/{len(sessions)} sessions synced")

    if not config.web_sessions.enabled:
        click.echo("\n  To enable web sync: hivemind config set web_sessions.enabled true")

    # Manual sync
    if do_sync:
        unsynced = [s for s in sessions if s.id not in synced_ids]
        if not unsynced:
            click.echo("\nAll sessions already synced.")
            return

        # Load hivemind credentials for backend auth
        auth = AuthManager(endpoint=base_endpoint)
        hm_creds = auth.store.load(auth.endpoint)
        if not hm_creds:
            click.echo("\nNot authenticated with AgentStream. Run: hivemind login", err=True)
            return

        syncer = _create_web_syncer(hm_creds, endpoint, state, web_client)

        click.echo(f"\nSyncing {len(unsynced)} sessions...")

        async def run_sync():

            return await sync_web_sessions(unsynced, syncer)

        try:
            stats = asyncio.run(run_sync())
            click.echo(
                f"  Done: {stats['success']} synced, {stats['failed']} failed "
                f"(of {stats['total']} total)"
            )
            # Save state so daemon picks up the new sync positions
            save_state(state, state_file)
        except Exception as e:
            click.echo(f"\nSync error: {e}", err=True)


# =============================================================================
# Dev mode exec and hupper support
# =============================================================================


def _onefile_cache_root() -> Path | None:
    """Return the directory Nuitka onefile extracts into, or None.

    Mirrors Nuitka's ``{CACHE_DIR}`` resolution per platform:
    macOS uses ``~/Library/Caches``, Linux uses ``$XDG_CACHE_HOME``
    (default ``~/.cache``), Windows uses ``%LOCALAPPDATA%`` (we don't
    ship onefile on Windows but the resolution is harmless).
    """
    system = platform.system()
    if system == "Darwin":
        return Path.home() / "Library" / "Caches"
    if system == "Linux":
        xdg = os.environ.get("XDG_CACHE_HOME")
        return Path(xdg) if xdg else Path.home() / ".cache"
    return None


def _prune_onefile_cache() -> None:
    """Remove `hivemind-X.Y.Z` cache directories from older versions.

    Nuitka onefile mode extracts to ``{CACHE_DIR}/hivemind-{VERSION}``
    on first launch and reuses it on subsequent launches. Without
    pruning, every upgrade leaves ~50 MB behind. Best-effort: silently
    ignore failures (we're a long-lived daemon, the user's disk isn't
    on fire because of us).
    """
    root = _onefile_cache_root()
    if root is None or not root.exists():
        return
    current = f"hivemind-{__version__}"
    try:
        entries = list(root.iterdir())
    except OSError:
        return
    for entry in entries:
        if not entry.is_dir():
            continue
        if not entry.name.startswith("hivemind-"):
            continue
        if entry.name == current:
            continue
        try:
            shutil.rmtree(entry, ignore_errors=True)
        except OSError:
            pass


def _maybe_exec_dev_mode() -> None:
    """Check for dev mode configuration and re-exec using the dev repo Python.

    This function is called early in the 'run' command to allow the Homebrew-installed
    daemon to transparently switch to using the development repo code.

    The flow is:
    1. Check if HIVEMIND_DEV_MODE=1 env var is set (already re-exec'd)
    2. Load config and check for dev.repo setting
    3. Validate the dev repo path
    4. If valid, exec to the dev Python with updated PYTHONPATH

    This uses os.execve() to replace the current process (same PID), which is
    important for launchd/brew services compatibility.
    """
    # Skip if already re-exec'd (prevents infinite loop)
    if os.environ.get("HIVEMIND_DEV_MODE") == "1":
        return

    # Load config to check for dev.repo
    config = load_config()
    dev_repo = config.dev.repo
    if not dev_repo:
        return

    # Validate the dev repo path
    is_valid, message = validate_dev_repo(dev_repo)
    if not is_valid:
        logger.warning(f"Dev mode disabled: {message}")
        return

    # Build paths for the dev repo
    dev_repo_path = Path(dev_repo).expanduser().resolve()
    dev_python = dev_repo_path / ".venv" / "bin" / "python"
    daemon_src = dev_repo_path / "daemon" / "src"

    # Build new environment with dev mode flag and PYTHONPATH
    new_env = os.environ.copy()
    new_env["HIVEMIND_DEV_MODE"] = "1"

    # Set PYTHONPATH to include both daemon/src and the repo root (for agentstream)
    pythonpath_parts = [str(daemon_src), str(dev_repo_path)]
    existing_pythonpath = os.environ.get("PYTHONPATH")
    if existing_pythonpath:
        pythonpath_parts.append(existing_pythonpath)
    new_env["PYTHONPATH"] = os.pathsep.join(pythonpath_parts)

    # Build the command line args: python -m hivemind.cli <original args>
    # sys.argv[0] is typically 'hivemind' or the script path
    # We want to pass all the original arguments after the command name
    new_args = [str(dev_python), "-m", "hivemind.cli"] + sys.argv[1:]

    # Log before exec (this is the last thing that runs in the original process)
    click.echo(f"Dev mode: switching to {dev_repo_path}")

    # Replace the current process with the dev Python
    os.execve(str(dev_python), new_args, new_env)


def _check_hupper_flapping(state_dir: Path) -> None:
    """Detect and throttle rapid restart loops in hupper dev mode.

    Tracks worker start timestamps in a file.  If too many starts occur
    within a short window, sleeps before continuing so the CPU isn't
    pegged by a crash-restart loop (e.g. after a machine reboot with
    stale state).

    Args:
        state_dir: Directory to store the restart history file.
    """
    # Thresholds: if >=MAX_STARTS happen within WINDOW seconds, sleep COOLDOWN.
    MAX_STARTS = 5
    WINDOW = 30.0
    COOLDOWN = 10.0

    history_file = state_dir / "hupper_starts.txt"
    now = time.time()

    # Ensure state directory exists — in dev mode this runs before
    # acquire_lock() creates ~/.hivemind.
    try:
        state_dir.mkdir(parents=True, exist_ok=True)
    except OSError:
        return

    # Read existing timestamps, discard anything older than WINDOW.
    recent: list[float] = []
    try:
        if history_file.exists():
            for line in history_file.read_text().splitlines():
                try:
                    ts = float(line.strip())
                    if now - ts < WINDOW:
                        recent.append(ts)
                except ValueError:
                    pass
    except OSError:
        pass

    # Record this start.
    recent.append(now)
    try:
        history_file.write_text("\n".join(str(t) for t in recent) + "\n")
    except OSError:
        pass

    if len(recent) >= MAX_STARTS:
        click.echo(
            f"Warning: dev daemon restarted {len(recent)} times in "
            f"{WINDOW:.0f}s — possible crash loop. "
            f"Cooling down {COOLDOWN:.0f}s...",
            err=True,
        )
        logger.warning(
            "Hupper flap detected: %d restarts in %.0fs, sleeping %.0fs",
            len(recent),
            WINDOW,
            COOLDOWN,
        )
        time.sleep(COOLDOWN)


def _run_with_hupper(dev_repo: str) -> bool:
    """Set up hupper process supervisor for dev mode.

    This function is called when running in dev mode (HIVEMIND_DEV_MODE=1) to
    enable manual restart via 'hivemind hup' command.

    Note: Automatic file watching is disabled. Use 'hivemind hup' to manually
    trigger a reload after making code changes.

    Args:
        dev_repo: Path to the dev repo checkout.

    Returns:
        True if hupper started a reloader (caller should return immediately).
        False if already in a hupper worker process (caller should continue).
    """
    try:
        import hupper  # noqa: PLC0415
    except ImportError:
        click.echo(
            "Warning: 'hupper' package not installed. Manual reload disabled.",
            err=True,
        )
        return False

    # Check if we're already in a reloader worker process
    if hupper.is_active():
        # Worker process — check for flapping before continuing.
        _check_hupper_flapping(DEFAULT_STATE_DIR)
        return False

    click.echo("Starting dev server (use 'hivemind hup' to reload after code changes)...")

    # Start the reloader, which will re-exec this process
    # Note: We intentionally do NOT watch files for automatic reload.
    # Use 'hivemind hup' to manually trigger a reload.
    hupper.start_reloader(
        "hivemind.cli.main",
        reload_interval=1,
    )

    # Return True to indicate caller should return (hupper takes over)
    return True


# =============================================================================
# Config command group
# =============================================================================


def _get_endpoint_source(config_path: Path) -> str:
    """Determine the source of the effective endpoint value.

    Args:
        config_path: Path to the config file.

    Returns:
        Source string: "dev mode", "config file", "env var", or "default".
    """

    # Check runtime override first (--dev flag)
    if get_endpoint_override() is not None:
        return "dev mode"

    # Check config file (highest priority after override)
    if config_path.exists():
        try:
            with open(config_path, "rb") as f:
                data = tomllib.load(f)
            file_endpoint = data.get("server", {}).get("endpoint")
            if file_endpoint and file_endpoint != CONFIG_DEFAULTS.get("server.endpoint"):
                return "config file"
        except Exception:
            pass

    # Check environment variable
    if os.environ.get("HIVEMIND_ENDPOINT"):
        return "env var"

    return "default"


def _signal_daemon_reload() -> bool:
    """Signal running daemon to reload config via SIGHUP.

    Reads PID from lock file and sends SIGHUP signal.
    Returns True if signal was sent, False otherwise.
    """
    lock_file = DEFAULT_LOCK_FILE

    if not lock_file.exists():
        return False

    try:
        pid = int(lock_file.read_text().strip())
        os.kill(pid, signal.SIGHUP)
        return True
    except (ValueError, ProcessLookupError, PermissionError, OSError):
        return False


# List of valid config keys for error messages
VALID_CONFIG_KEYS = [
    "server.endpoint",
    "dev.repo",
    "dev.debug",
    "web_sessions.enabled",
    "web_sessions.poll_interval",
    "import.max_age_days",
    "sessions.private",
    "sessions.org_repos",
    "sessions.private_repos",
    "daemon.auto_upgrade",
]

# Config keys that hold lists (comma-separated on input, stored as TOML arrays)
LIST_CONFIG_KEYS = {"sessions.org_repos", "sessions.private_repos"}

# Default values for config keys (for showing in config show)
CONFIG_DEFAULTS: dict[str, Any] = {
    "server.endpoint": "https://hivemind.wandb.tools",
    "dev.repo": None,
    "dev.debug": False,
    "web_sessions.enabled": True,
    "web_sessions.poll_interval": 1800,
    "import.max_age_days": 90,
    "sessions.private": False,
    "sessions.org_repos": [],
    "sessions.private_repos": [],
    "daemon.auto_upgrade": "notify",
}


def _check_claude_cli() -> bool:
    """Check if the Claude CLI is available and logged in."""
    # Cannot nest Claude Code sessions
    if os.environ.get("CLAUDECODE"):
        return False
    try:
        result = subprocess.run(
            ["claude", "auth", "status"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            data = json.loads(result.stdout)
            return data.get("loggedIn", False)
    except (subprocess.TimeoutExpired, json.JSONDecodeError, FileNotFoundError):
        pass
    return False


def _check_codex_cli() -> bool:
    """Check if the Codex CLI is available and logged in."""
    try:
        result = subprocess.run(
            ["codex", "login", "status"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return "Logged in" in result.stdout
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return False


def _check_cursor_cli() -> bool:
    """Check if the Cursor Agent CLI is available and authenticated."""
    try:
        # --version only checks install, not auth. Run a trivial prompt
        # in print mode to verify the agent can actually start.
        result = subprocess.run(
            ["cursor-agent", "-p", "say ok"],
            capture_output=True,
            text=True,
            timeout=15,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def _find_llm_provider() -> str:
    """Find an available LLM provider.

    Checks in order: Claude CLI, Codex CLI, Cursor Agent CLI.
    Returns "claude-cli", "codex-cli", or "cursor-cli", or raises SystemExit.
    """
    if _check_claude_cli():
        return "claude-cli"

    if _check_codex_cli():
        return "codex-cli"

    if _check_cursor_cli():
        return "cursor-cli"

    click.echo(
        "  Error: No agent CLI available for smart merge.\n"
        "  Install and log in to one of:\n"
        "    1. Claude Code    — claude auth login\n"
        "    2. Codex CLI      — codex login\n"
        "    3. Cursor Agent   — cursor-agent login",
        err=True,
    )
    raise SystemExit(1)


def _llm_merge_cli(provider: str, suggested_content: str, file_path: Path) -> bool:
    """Use an agent CLI to merge a suggestion directly into a file.

    The CLI agent reads the file itself, merges the suggestion, and writes it back.
    Returns True if the file was modified.
    """
    prompt = (
        f"Read the file {file_path} and merge the following suggestion into it. "
        f"If the suggestion is already covered (even if worded differently), "
        f"leave the file unchanged. Otherwise, find the best section to place it "
        f"and match the existing formatting style.\n\n"
        f"SUGGESTION TO MERGE IN:\n{suggested_content}"
    )

    if provider == "claude-cli":
        cmd = [
            "claude",
            "-p",
            "--model",
            "sonnet",
            "--permission-mode",
            "bypassPermissions",
            "--allowedTools",
            "Edit,Read",
        ]
        # If file is outside cwd, grant access to its parent directory
        try:
            file_path.relative_to(Path.cwd())
        except ValueError:
            cmd.extend(["--add-dir", str(file_path.parent)])
        result = subprocess.run(
            cmd,
            input=prompt,
            text=True,
            timeout=120,
        )
        if result.returncode != 0:
            raise SystemExit(1)
    elif provider == "codex-cli":
        result = subprocess.run(
            ["codex", "exec", "--full-auto", prompt],
            text=True,
            timeout=120,
        )
        if result.returncode != 0:
            raise SystemExit(1)
    elif provider == "cursor-cli":
        result = subprocess.run(
            ["cursor-agent", "-p", "--force", prompt],
            text=True,
            timeout=120,
        )
        if result.returncode != 0:
            raise SystemExit(1)

    return True


@main.group()
def insights():
    """Manage contextual intelligence suggestions."""
    pass


@insights.command("list")
@click.option("--status", type=click.Choice(["pending", "applied", "dismissed"]), default="pending")
@click.option(
    "--repo", default=None, help="Filter by git repo (defaults to current directory's repo)"
)
def insights_list(status: str, repo: str | None):
    """List insights suggestions for the current project."""

    effective_endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth = AuthManager(endpoint=base_endpoint)
    creds = auth.store.load(auth.endpoint)

    if not creds or auth.store.is_expired(creds):
        click.echo("Error: Not authenticated. Run 'hivemind login' first.", err=True)
        raise SystemExit(1)

    # Auto-detect git repo if not specified
    if repo is None:
        detected = resolve_git_repo(Path.cwd())
        if detected:
            repo = detected

    headers = {
        "Authorization": f"Bearer {creds.token}",
        "Content-Type": "application/json",
    }

    params: dict[str, str] = {"status": status, "limit": "50"}
    if repo:
        params["git_repo"] = repo

    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.get(
                f"{base_endpoint}/v1/insights/items",
                params=params,
                headers=headers,
            )

        if not response.is_success:
            click.echo(f"Error: {response.status_code} {response.text}", err=True)
            raise SystemExit(1)

        data = response.json()
        items = data.get("items", [])

        if not items:
            click.echo(f"No {status} suggestions found.")
            if repo:
                click.echo(f"  (filtered to repo: {repo})")
            return

        # Group by repo
        by_repo: dict[str, list] = {}
        for item in items:
            r = item.get("git_repo", "Unknown")
            if r not in by_repo:
                by_repo[r] = []
            by_repo[r].append(item)

        for repo_name, repo_items in by_repo.items():
            click.echo(f"\n  Insights — {repo_name}")
            click.echo(f"  {len(repo_items)} {status} suggestion(s)\n")

            for i, item in enumerate(repo_items, 1):
                category = item.get("category", "").capitalize()
                title = item.get("title", "")
                confidence = item.get("confidence", 0)
                evidence = item.get("evidence_count", 0)
                affected = item.get("affected_user_count", 0)
                apply_cmd = item.get("apply_command", "")

                conf_label = (
                    "High" if confidence >= 0.8 else "Medium" if confidence >= 0.5 else "Low"
                )

                user_info = f", {affected} users" if affected >= 2 else ""
                click.echo(
                    f"  {i}. [{category}] {title} ({conf_label} confidence, {evidence} sessions{user_info})"
                )
                if apply_cmd and status == "pending":
                    click.secho(f"     $ {apply_cmd}", fg="cyan")
                click.echo()

        track("cli.insights_list", {"status": status, "count": len(items)})

    except httpx.RequestError as e:
        click.echo(f"Request failed: {e}", err=True)
        raise SystemExit(1)


AGENT_CONTEXT_FILES: dict[str, list[str]] = {
    "claude": ["CLAUDE.md", "AGENTS.md"],
    "cursor": [".cursorrules", ".cursor/rules"],
    "codex": ["AGENTS.md", "codex.md"],
    "generic": ["AGENTS.md"],
}


def _resolve_context_file() -> Path | None:
    """Ask the user which agent and find the appropriate project context file."""
    agents = ["claude", "cursor", "codex", "generic"]
    click.echo("\n  Which agent is this for?")
    for i, agent in enumerate(agents, 1):
        click.echo(f"    {i}. {agent.capitalize()}")

    choice = click.prompt("  Choice", type=int, default=1)
    if choice < 1 or choice > len(agents):
        click.echo("  Invalid choice.", err=True)
        return None
    agent = agents[choice - 1]

    candidates = AGENT_CONTEXT_FILES[agent]

    cwd = Path.cwd()
    for candidate in candidates:
        path = cwd / candidate
        if path.exists():
            click.echo(f"  Found existing: {path}")
            return path

    # No existing file — use first candidate
    target = cwd / candidates[0]
    click.echo(f"  Will create: {target}")
    return target


@insights.command("apply")
@click.argument("suggestion_id")
@click.option("--yes", "-y", is_flag=True, help="Apply without confirmation")
def insights_apply(suggestion_id: str, yes: bool):
    """Apply a suggestion to a context file.

    SUGGESTION_ID is the short ID from 'hivemind insights list'.
    Interactively asks which agent and finds the appropriate context file.
    """

    effective_endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth = AuthManager(endpoint=base_endpoint)
    creds = auth.store.load(auth.endpoint)

    if not creds or auth.store.is_expired(creds):
        click.echo("Error: Not authenticated. Run 'hivemind login' first.", err=True)
        raise SystemExit(1)

    headers = {
        "Authorization": f"Bearer {creds.token}",
        "Content-Type": "application/json",
    }

    # Auto-detect git repo for scoping
    detected_repo = resolve_git_repo(Path.cwd())
    fetch_params: dict[str, str] = {"status": "pending", "limit": "200"}
    if detected_repo:
        fetch_params["git_repo"] = detected_repo

    # Fetch suggestion details
    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.get(
                f"{base_endpoint}/v1/insights/items",
                params=fetch_params,
                headers=headers,
            )

        if not response.is_success:
            click.echo(f"Error fetching suggestions: {response.status_code}", err=True)
            raise SystemExit(1)

        data = response.json()
        items = data.get("items", [])

        matching = [item for item in items if item.get("item_id", "").startswith(suggestion_id)]

        if not matching:
            click.echo(f"No pending suggestion found matching '{suggestion_id}'", err=True)
            raise SystemExit(1)
        if len(matching) > 1:
            click.echo(
                f"Ambiguous ID '{suggestion_id}' matches {len(matching)} items. Use a longer prefix.",
                err=True,
            )
            raise SystemExit(1)

        item = matching[0]

    except httpx.RequestError as e:
        click.echo(f"Request failed: {e}", err=True)
        raise SystemExit(1)

    # Get the suggestion content
    item_content = item.get("content", {})
    suggested_content = item_content.get("suggested_content", "")
    reasoning = item_content.get("reasoning", "")

    if not suggested_content:
        click.echo("Error: Suggestion has no content to apply.", err=True)
        raise SystemExit(1)

    affected = item.get("affected_user_count", 0)
    click.echo(f"\n  Suggestion: {item.get('title', '')}")
    click.echo(f"  Category:   {item.get('category', '').capitalize()}")
    if affected >= 2:
        click.echo(f"  Users:      {affected} users affected")
    if reasoning:
        reason_lines = textwrap.wrap(
            reasoning, width=68, initial_indent="  Reason:     ", subsequent_indent="              "
        )
        for rl in reason_lines:
            click.echo(rl)

    inner_width = 68
    click.echo("\n  Content:")
    click.echo(f"  ┌{'─' * inner_width}┐")
    for line in suggested_content.split("\n"):
        wrapped = textwrap.wrap(line, width=inner_width - 2) or [""]
        for wl in wrapped:
            click.echo(f"  │ {wl:<{inner_width - 2}} │")
    click.echo(f"  └{'─' * inner_width}┘")

    # Ask where to apply
    target_path = _resolve_context_file()
    if not target_path:
        return

    try:
        target_file = str(target_path.relative_to(Path.cwd()))
    except ValueError:
        # Path is outside cwd (e.g. ~/.claude/CLAUDE.md)
        target_file = str(target_path)

    # Use LLM to intelligently merge
    provider = _find_llm_provider()
    provider_labels = {
        "claude-cli": "Claude CLI",
        "codex-cli": "Codex CLI",
        "cursor-cli": "Cursor Agent",
    }
    provider_label = provider_labels.get(provider, provider.split("/")[-1])
    click.echo(f"  Merging with AI ({provider_label})...")

    # Snapshot file before merge
    current_content = target_path.read_text() if target_path.exists() else ""

    # CLI agents read and edit the file themselves
    target_path.parent.mkdir(parents=True, exist_ok=True)
    if not target_path.exists():
        target_path.write_text("")
    _llm_merge_cli(provider, suggested_content, target_path)
    new_content = target_path.read_text()

    # Show diff
    diff_lines = list(
        difflib.unified_diff(
            current_content.splitlines(keepends=True),
            new_content.splitlines(keepends=True),
            fromfile=f"a/{target_file}",
            tofile=f"b/{target_file}",
            n=3,
        )
    )
    if diff_lines:
        click.echo()
        for line in diff_lines:
            line = line.rstrip("\n")
            if line.startswith("+") and not line.startswith("+++"):
                click.secho(f"  {line}", fg="green")
            elif line.startswith("-") and not line.startswith("---"):
                click.secho(f"  {line}", fg="red")
            else:
                click.echo(f"  {line}")
        click.echo()
    else:
        click.echo("  No changes needed — suggestion is already covered. Resolving.")
        try:
            with httpx.Client(timeout=30.0) as client:
                resp = client.patch(
                    f"{base_endpoint}/v1/insights/items/{item['item_id']}",
                    json={"status": "applied"},
                    headers=headers,
                )
                resp.raise_for_status()
        except Exception as exc:
            click.echo(f"  Warning: failed to mark suggestion as applied: {exc}", err=True)
        return

    # Mark as applied via API
    try:
        with httpx.Client(timeout=30.0) as client:
            resp = client.patch(
                f"{base_endpoint}/v1/insights/items/{item['item_id']}",
                json={"status": "applied"},
                headers=headers,
            )
            resp.raise_for_status()
    except Exception as exc:
        click.echo(f"  Warning: failed to mark suggestion as applied: {exc}", err=True)

    click.echo(f"  Applied to {target_file}")
    track("cli.insights_apply", {"suggestion_id": suggestion_id, "success": True})


@main.group()
def config():
    """View and manage configuration settings."""
    pass


def _get_config_source(key: str, config_path: Path) -> str:
    """Determine the source of a config value.

    Args:
        key: The config key (e.g., "server.endpoint").
        config_path: Path to the config file.

    Returns:
        Source string: one of "dev mode", "config file", "env var", or "default".
        "env var" and "dev mode" are only used for the "server.endpoint" key; other
        keys return either "config file" or "default".
    """

    # Special handling for server.endpoint (supports env var and dev mode)
    if key == "server.endpoint":
        return _get_endpoint_source(config_path)

    # For other keys, check if they're explicitly set in the config file
    # to a non-default value
    if config_path.exists():
        try:
            with open(config_path, "rb") as f:
                data = tomllib.load(f)

            # Navigate the dotted path
            parts = key.split(".")
            current = data
            for part in parts[:-1]:
                current = current.get(part, {})

            if parts[-1] in current:
                # Key exists in config file — only report "config file" if
                # the value differs from the default
                file_value = current[parts[-1]]
                default_value = CONFIG_DEFAULTS.get(key)
                if file_value != default_value:
                    return "config file"
        except Exception:
            # If the config file cannot be read or parsed, treat it as absent
            # and fall back to reporting the value as coming from "default".
            pass

    return "default"


@config.command("show")
def config_show():
    """Show current configuration.

    Displays all configuration values with their sources
    (config file, environment variable, or default).

    Examples:

        hivemind config show
    """
    console = Console()
    config_path = DEFAULT_CONFIG_PATH
    cfg = load_config(config_path)

    console.print("[bold]Configuration:[/bold]")

    for key in VALID_CONFIG_KEYS:
        # Get effective value
        if key == "server.endpoint":
            value = get_effective_endpoint(config_path)
        else:
            value = get_value(key, cfg)

        # Get source
        source = _get_config_source(key, config_path)

        # Build styled output
        line = Text()
        line.append("  ")
        line.append(key, style="cyan")
        line.append(" = ")

        # Format and style value
        if value is None:
            line.append("(not set)", style="dim")
        elif isinstance(value, list):
            if value:
                line.append(", ".join(value), style="yellow")
            else:
                line.append("[]", style="dim")
        elif isinstance(value, bool):
            line.append(str(value).lower(), style="green" if value else "red")
        elif isinstance(value, int):
            line.append(str(value), style="magenta")
        else:
            line.append(str(value), style="yellow")

        # Only show source label for defaults
        if source == "default":
            line.append("  (default)", style="dim italic")

        console.print(line)

    console.print()
    console.print(f"[bold]Config file:[/bold] {config_path}")
    if config_path.exists():
        console.print("  Status: [green]exists[/green]")
    else:
        console.print("  Status: [dim]not created (using defaults)[/dim]")


@config.command("get")
@click.argument("key")
def config_get(key: str):
    """Get a configuration value by key.

    KEY is the dotted path to the configuration value (e.g., server.endpoint).

    Outputs just the value for easy scripting. Exits with code 1 if key not found.

    Examples:

        # Get the endpoint URL
        hivemind config get server.endpoint

        # Use in scripts
        ENDPOINT=$(hivemind config get server.endpoint)
    """
    config_path = DEFAULT_CONFIG_PATH

    # For server.endpoint, use the effective endpoint (respects priority chain)
    if key == "server.endpoint":
        click.echo(get_effective_endpoint(config_path))
        return

    # For other keys, load config and get value
    cfg = load_config(config_path)
    try:
        value = get_value(key, cfg)
        if isinstance(value, list):
            click.echo(",".join(value) if value else "")
        else:
            click.echo(value)
    except KeyError:
        click.echo(f"Unknown config key: {key}", err=True)
        click.echo(f"Valid keys: {', '.join(VALID_CONFIG_KEYS)}", err=True)
        raise SystemExit(1)


@config.command("set")
@click.argument("key")
@click.argument("value")
def config_set(key: str, value: str):
    """Set a configuration value.

    KEY is the dotted path to the configuration value (e.g., server.endpoint).
    VALUE is the new value to set.

    Updates the config file (creates it if needed) and signals the running
    daemon to reload configuration via SIGHUP.

    Examples:

        # Set a custom endpoint
        hivemind config set server.endpoint https://custom.example.com

        # Reset to default by setting the default value
        hivemind config set server.endpoint https://hivemind.wandb.tools
    """
    config_path = DEFAULT_CONFIG_PATH

    # Coerce string values to the appropriate type
    config_value: str | bool | int | list[str] | UpgradeMode = value
    if key in ("dev.debug", "web_sessions.enabled", "sessions.private"):
        config_value = value.lower() in ("true", "1", "yes")
    elif key in ("web_sessions.poll_interval", "import.max_age_days"):
        try:
            config_value = int(value)
        except ValueError:
            click.echo(f"Invalid integer value for {key}: {value}", err=True)
            raise SystemExit(1)
    elif key == "daemon.auto_upgrade":
        try:
            config_value = UpgradeMode(value.lower())
        except ValueError:
            click.echo(
                f"Invalid value for {key}: {value!r}. "
                f"Expected one of: {', '.join(m.value for m in UpgradeMode)}",
                err=True,
            )
            raise SystemExit(1)
    elif key in LIST_CONFIG_KEYS:
        # Comma-separated string → list (empty string clears the list)
        if value.strip() == "":
            config_value = []
        else:
            config_value = [v.strip() for v in value.split(",") if v.strip()]

    # Update the single value while preserving unknown keys
    try:
        update_config(key, config_value, config_path)
    except KeyError:
        click.echo(f"Unknown config key: {key}", err=True)
        click.echo(f"Valid keys: {', '.join(VALID_CONFIG_KEYS)}", err=True)
        raise SystemExit(1)

    click.echo(f"Set {key} = {config_value}")
    click.echo(f"Saved to {config_path}")
    track("cli.config_changed", {"action": "set", "key": key})

    # Signal daemon to reload
    if _signal_daemon_reload():
        click.echo("Sent SIGHUP to running daemon.")
        click.echo("Note: Daemon will reload config if it has a SIGHUP handler.")
    else:
        click.echo("No running daemon found (or could not signal).")


@config.command("add")
@click.argument("key")
@click.argument("value")
def config_add(key: str, value: str):
    """Add a value to a list configuration key.

    KEY must be a list config key (sessions.org_repos or sessions.private_repos).
    VALUE is the repo to add (e.g., "github.com/org/repo" or "org/repo").

    Examples:

        # Always share a repo with your org (overrides global private)
        hivemind config add sessions.org_repos github.com/myorg/public-repo

        # Always keep a repo private
        hivemind config add sessions.private_repos myorg/secret-repo
    """
    config_path = DEFAULT_CONFIG_PATH

    if key not in LIST_CONFIG_KEYS:
        click.echo(
            f"'config add' only works with list keys: {', '.join(sorted(LIST_CONFIG_KEYS))}",
            err=True,
        )
        raise SystemExit(1)

    cfg = load_config(config_path)
    current: list[str] = get_value(key, cfg)
    value = value.strip()

    # Check for duplicates using normalized matching (not just verbatim)
    if value in current:
        click.echo(f"'{value}' is already in {key}")
        return
    for existing in current:
        if repo_matches(value, [existing]):
            click.echo(f"'{value}' already matches existing entry '{existing}' in {key}")
            return

    # Warn if the repo is in the opposite list
    opposite_key = "sessions.private_repos" if key == "sessions.org_repos" else "sessions.org_repos"
    opposite: list[str] = get_value(opposite_key, cfg)
    if repo_matches(value, opposite):
        click.echo(
            f"Warning: '{value}' also matches an entry in {opposite_key}. "
            f"{'private_repos' if 'private' in opposite_key else 'org_repos'} takes precedence.",
            err=True,
        )

    current.append(value)
    update_config(key, current, config_path)
    click.echo(f"Added '{value}' to {key}")
    click.echo(f"Current list: {', '.join(current)}")
    track("cli.config_changed", {"action": "add", "key": key})

    if _signal_daemon_reload():
        click.echo("Sent SIGHUP to running daemon.")
    else:
        click.echo("No running daemon found (or could not signal).")


@config.command("remove")
@click.argument("key")
@click.argument("value")
def config_remove(key: str, value: str):
    """Remove a value from a list configuration key.

    KEY must be a list config key (sessions.org_repos or sessions.private_repos).
    VALUE is the repo to remove.

    Examples:

        hivemind config remove sessions.org_repos github.com/myorg/public-repo
    """
    config_path = DEFAULT_CONFIG_PATH

    if key not in LIST_CONFIG_KEYS:
        click.echo(
            f"'config remove' only works with list keys: {', '.join(sorted(LIST_CONFIG_KEYS))}",
            err=True,
        )
        raise SystemExit(1)

    cfg = load_config(config_path)
    current: list[str] = get_value(key, cfg)
    value = value.strip()

    # Find the entry to remove using normalized matching (not just verbatim)
    match = None
    if value in current:
        match = value
    else:
        for existing in current:
            if repo_matches(value, [existing]):
                match = existing
                break

    if match is None:
        click.echo(f"'{value}' is not in {key}", err=True)
        click.echo(f"Current list: {', '.join(current) if current else '(empty)'}", err=True)
        raise SystemExit(1)

    current.remove(match)
    update_config(key, current, config_path)
    click.echo(f"Removed '{value}' from {key}")
    if current:
        click.echo(f"Current list: {', '.join(current)}")
    else:
        click.echo(f"{key} is now empty")
    track("cli.config_changed", {"action": "remove", "key": key})

    if _signal_daemon_reload():
        click.echo("Sent SIGHUP to running daemon.")
    else:
        click.echo("No running daemon found (or could not signal).")


@config.command("reset")
@click.option(
    "--yes",
    "-y",
    is_flag=True,
    help="Skip confirmation prompt",
)
def config_reset(yes: bool):
    """Reset configuration to defaults.

    Removes the config file, causing all settings to revert to defaults.
    Use --yes/-y to skip the confirmation prompt.

    Examples:

        # Reset with confirmation
        hivemind config reset

        # Reset without confirmation
        hivemind config reset -y
    """
    config_path = DEFAULT_CONFIG_PATH

    if not config_path.exists():
        click.echo("No config file exists. Already using defaults.")
        return

    if not yes:
        click.confirm(
            f"Remove config file at {config_path}? This will reset all settings to defaults",
            abort=True,
        )

    try:
        config_path.unlink()
        click.echo(f"Removed {config_path}")
        click.echo("Configuration reset to defaults.")
        track("cli.config_changed", {"action": "reset", "key": ""})

        # Signal daemon to reload
        if _signal_daemon_reload():
            click.echo("Sent SIGHUP to running daemon.")
            click.echo("Note: Daemon will reload config if it has a SIGHUP handler.")
    except OSError as e:
        click.echo(f"Error removing config file: {e}", err=True)
        raise SystemExit(1)


@config.command("path")
def config_path():
    """Show the config file path.

    Useful for debugging or locating the config file.

    Examples:

        hivemind config path
    """
    click.echo(DEFAULT_CONFIG_PATH)


@config.command("reset-server")
@click.argument("server")
@click.option(
    "--yes",
    "-y",
    is_flag=True,
    help="Skip confirmation prompt",
)
@click.option(
    "--state-dir",
    type=click.Path(),
    default=str(DEFAULT_STATE_DIR),
    help="State directory (default: ~/.hivemind)",
)
def config_reset_server(server: str, yes: bool, state_dir: str):
    """Reset sync state for a specific server.

    SERVER is the endpoint URL (e.g., http://localhost:8080).

    This removes all tracked session state for the specified server from
    the state file, causing the daemon to re-import all sessions on next
    sync. Useful when you've blown away your local dev database.

    This does NOT delete your sessions from the server - it only clears
    the local tracking state.

    Examples:

        # Reset localhost dev server state
        hivemind config reset-server http://localhost:8080

        # Skip confirmation
        hivemind config reset-server http://localhost:8080 -y
    """
    state_path = Path(state_dir)
    state_file = state_path / "state.json"

    if not state_file.exists():
        click.echo(f"No state file found at {state_file}", err=True)
        raise SystemExit(1)

    # Load state
    state = load_state(state_file)

    # Normalize the server URL for lookup
    normalized = _normalize_endpoint(server)

    # Check if server exists in state
    if normalized not in state.servers:
        click.echo(f"Error: No state found for server '{normalized}'", err=True)
        click.echo("\nKnown servers:", err=True)
        if state.servers:
            for endpoint in sorted(state.servers.keys()):
                server_state = state.servers[endpoint]
                click.echo(f"  - {endpoint} ({len(server_state.sessions)} sessions)", err=True)
        else:
            click.echo("  (none)", err=True)
        raise SystemExit(1)

    # Show what will be deleted
    server_state = state.servers[normalized]
    session_count = len(server_state.sessions)
    click.echo(f"Server: {normalized}")
    click.echo(f"  Sessions tracked: {session_count}")
    click.echo(
        f"  Historic import: {'completed' if server_state.historic_import_completed else 'not done'}"
    )

    if not yes:
        click.confirm(
            f"\nReset all sync state for '{normalized}'? "
            "This will cause sessions to be re-imported on next sync",
            abort=True,
        )

    # Delete the server state
    del state.servers[normalized]

    # Save state
    save_state(state, state_file)

    click.echo(f"\n✓ Removed state for '{normalized}' ({session_count} sessions cleared)")
    click.echo("The daemon will re-import sessions on next sync cycle.")


@main.command("install-agent")
@click.option("--force", is_flag=True, help="Overwrite even if already at current version")
def install_agent_cmd(force: bool):
    """Install the @hivemind agent for supported platforms.

    Writes the agent definition to <platform>/agents/wandb-hivemind.md for each
    platform directory (~/.claude, ~/.codex, ~/.cursor) that exists on disk.

    The agent is automatically updated when a newer version is available.
    """

    written = install_agent(force=force)
    if written:
        targets = [
            f"~/{d.name}/agents/{_AGENT_FILENAME}"
            for d in _PLATFORM_DIRS
            if (d / "agents" / _AGENT_FILENAME).exists()
        ]
        click.echo(f"Installed @hivemind agent v{AGENT_VERSION} to:")
        for t in targets:
            click.echo(f"  {t}")
        platforms = [
            d.name.lstrip(".") for d in _PLATFORM_DIRS if (d / "agents" / _AGENT_FILENAME).exists()
        ]
        track("cli.agent_installed", {"platforms": platforms})
    else:
        has_any = any(d.is_dir() for d in _PLATFORM_DIRS)
        if not has_any:
            click.echo("No supported platform found (~/.claude, ~/.codex, ~/.cursor).")
            click.echo("Install Claude Code, Codex, or Cursor first, then re-run this command.")
            raise SystemExit(1)
        click.echo(f"@hivemind agent is already at v{AGENT_VERSION}")


@main.command("uninstall-agent")
def uninstall_agent_cmd():
    """Remove the @hivemind agent from all platforms.

    Removes wandb-hivemind.md from each platform's agents directory.
    Only removes files that were installed by hivemind (verified by content).
    """

    # Capture which agent files exist before uninstall so we only report those
    existing_platforms = [
        d.name.lstrip(".") for d in _PLATFORM_DIRS if (d / "agents" / _AGENT_FILENAME).exists()
    ]
    existing_targets = [
        f"~/{d.name}/agents/{_AGENT_FILENAME}"
        for d in _PLATFORM_DIRS
        if (d / "agents" / _AGENT_FILENAME).exists()
    ]

    removed = uninstall_agent()
    if removed:
        click.echo("Removed @hivemind agent from:")
        for target in existing_targets:
            click.echo(f"  {target}")
        track("cli.agent_uninstalled", {"platforms": existing_platforms})
    else:
        click.echo("No @hivemind agent files found to remove.")


@main.command("search")
@click.argument("query", required=False, default=None)
@click.option("--limit", default=5, help="Maximum sessions to return (default: 5)")
@click.option(
    "--repo",
    default=None,
    help='Filter by git repository. Auto-detected from git remote if not specified. Pass "all" to disable filtering.',
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["json", "markdown"]),
    default="markdown",
    help="Output format (default: markdown)",
)
@click.option(
    "--include-transcript/--no-transcript",
    default=True,
    help="Include session transcripts (default: true)",
)
@click.option(
    "--event-types",
    default=None,
    help=(
        "Comma-separated event categories to include in transcript (default: user,assistant). "
        "Categories: user (prompts), assistant (responses), reasoning (thinking blocks), "
        "tools (tool calls with args and results), files (file read/write with content/diffs), "
        'errors (error events). Use "all" to include everything.'
    ),
)
@click.option(
    "--verbose/--no-verbose",
    default=False,
    help="Show all intermediate assistant messages per turn, not just the final response (default: false)",
)
@click.option(
    "--users",
    default="me",
    help='Filter by user. "me" = authenticated user, "all" = no filter, or a username. (default: me)',
)
@click.option(
    "--org",
    "org_id",
    default=None,
    help="Organization ID to scope the search to (sets X-Org-Id header).",
)
@click.option(
    "--order",
    default=None,
    help=(
        "Sort order: relevance (default with query), started_at, last_activity_at. "
        "Prefix with +/- for ASC/DESC (default DESC)."
    ),
)
@click.option(
    "--subagents/--no-subagents",
    default=None,
    help="Filter sub-agent sessions. --subagents = only sub-agents, --no-subagents = exclude them. (default: all)",
)
@click.pass_context
def search(
    ctx: click.Context,
    query: str | None,
    limit: int,
    repo: str | None,
    output_format: str,
    include_transcript: bool,
    event_types: str | None,
    verbose: bool,
    users: str,
    org_id: str | None,
    order: str | None,
    subagents: bool | None,
):
    """Search previous coding sessions or list recent sessions.

    Returns session transcripts formatted for LLM consumption with
    metadata about modified files, tool usage, and decisions made.

    When QUERY is omitted, lists sessions by last activity (list mode).

    By default, results are filtered to the authenticated user (--users me)
    and the current git repository (auto-detected from the git remote URL).
    Use --users all to search across all users, or --repo all to search
    across all repositories.

    QUERY uses the hivemind search syntax:

    \b
      Simple terms:    "authentication bug"
      File filter:     "file:cli.py"
      Repo filter:     "repo:agentstream"
      Exact phrase:    '"session importer"'
      OR operator:     "fix OR improve"
      Combined:        "improve file:daemon.py"

    \b
    Transcript detail is controlled by --event-types (default: user,assistant):
      user,assistant   Prompts and final responses only (compact)
      +reasoning       Add thinking/reasoning blocks (as blockquotes)
      +files           Add file read/write operations with content/diffs
      +tools           Add tool calls with arguments and results
      all              Everything including errors

    \b
    Examples:
        hivemind search
        hivemind search "authentication"
        hivemind search "file:cli.py"
        hivemind search "refactor file:daemon" --limit 3
        hivemind search "error handling" --repo all
        hivemind search "error handling" --users all
        hivemind search --event-types user,assistant,files
        hivemind search "query" --order -started_at
    """
    # Determine effective endpoint
    effective_endpoint = get_effective_endpoint()

    # Require authentication
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth_manager = AuthManager(base_endpoint)
    creds = auth_manager.store.load(auth_manager.endpoint)

    if not creds or auth_manager.store.is_expired(creds):
        click.echo(
            "Error: Not authenticated. Run 'hivemind login' first.",
            err=True,
        )
        raise SystemExit(1)

    headers: dict[str, str] = {"Authorization": f"Bearer {creds.token}"}

    # Set org header if specified
    if org_id:
        headers["X-Org-Id"] = org_id

    # Resolve --users filter: send username(s) to API
    user_filter: list[str] | None = None
    if users == "me":
        user_filter = [creds.github_user]
    elif users == "all":
        user_filter = None
    else:
        # Treat as comma-separated usernames
        user_filter = [u.strip() for u in users.split(",") if u.strip()]

    # Colorize stderr when connected to a TTY
    use_color = sys.stderr.isatty()

    def _info(msg: str) -> None:
        click.echo(click.style(msg, dim=True) if use_color else msg, err=True)

    def _label(label: str, value: str, extra: str = "") -> None:
        if use_color:
            msg = click.style(label, fg="cyan") + " " + value
            if extra:
                msg += " " + click.style(extra, dim=True)
        else:
            msg = f"{label} {value}"
            if extra:
                msg += f" {extra}"
        click.echo(msg, err=True)

    def _warn(msg: str) -> None:
        click.echo(click.style(msg, fg="yellow") if use_color else msg, err=True)

    def _err(msg: str) -> None:
        click.echo(click.style(msg, fg="red") if use_color else msg, err=True)

    # Expand "all" shorthand for event_types
    all_event_types = "user,assistant,reasoning,tools,files,errors"
    effective_event_types = all_event_types if event_types == "all" else event_types

    # Resolve git_repo filter
    git_repo: str | None = None
    if repo == "all" or repo == "*":
        # Explicit: no repo filtering (accept both "all" and legacy "*")
        _label("Repo filter:", "disabled", "(--repo all)")
    elif repo is not None:
        # Normalize user-provided repo (handles full URLs, credentials, .git suffix)
        normalized = normalize_git_url(repo)
        if normalized:
            git_repo = normalized
        elif "/" in repo and "." in repo.split("/")[0]:
            # Already in host/org/repo format (e.g., github.com/org/repo)
            git_repo = repo
        else:
            _err(
                f"Error: Invalid repository '{repo}'. Expected a git URL or host/org/repo format.\n"
                f"Examples: github.com/org/repo, https://github.com/org/repo, git@github.com:org/repo"
            )
            raise SystemExit(1)
        _label("Repo filter:", git_repo)
    else:
        # Auto-detect from current directory
        detected = resolve_git_repo(Path.cwd())
        if detected:
            git_repo = detected
            _label("Repo filter:", git_repo, "(auto-detected)")
        else:
            _label("Repo filter:", "none", "(not in a git repository)")

    try:
        with httpx.Client(timeout=30.0) as client:
            # Step 1: Search for matching sessions
            _label("Endpoint:", base_endpoint)

            # Determine mode and default order
            if query is None:
                _info("No query provided, listing sessions")
                effective_order = order or "-last_activity_at"
            else:
                _label("Searching for:", query)
                effective_order = order

            # Show order info
            if effective_order:
                _label("Order:", effective_order)
            elif query is not None:
                _label("Order:", "relevance")

            search_params: dict[str, Any] = {
                "limit": limit,
            }
            if query is not None:
                search_params["q"] = query
            if git_repo:
                search_params["git_repo"] = git_repo
            if user_filter:
                search_params["users"] = user_filter
            if effective_order:
                search_params["order"] = effective_order
            if subagents is not None:
                search_params["subagents"] = str(subagents).lower()

            search_url = f"{base_endpoint}/v1/search"
            search_response = client.get(
                search_url,
                params=search_params,
                headers=headers,
            )
            search_response.raise_for_status()
            search_data = search_response.json()

            results = search_data.get("results", [])
            total_count = search_data.get("total_count", 0)

            if not results:
                _warn("No matching sessions found.")
                raise SystemExit(1)

            _info(f"Found {total_count} matches, returning top {len(results)}")

            # Step 2: Fetch transcripts for each result
            sessions = []
            for result in results:
                session_id = result["session_id"]
                session_entry: dict[str, Any] = {
                    "session_id": session_id,
                    "title": result.get("title", ""),
                    "username": result.get("username", ""),
                    "display_name": result.get("display_name", ""),
                    "author_name": result.get("author_name", "")
                    or result.get("display_name")
                    or result.get("username", "")
                    or result.get("user_id", ""),
                    "started_at": result.get("started_at", ""),
                    "last_activity_at": result.get("last_activity_at", ""),
                    "agent_type": result.get("agent_type", ""),
                    "model": result.get("model", ""),
                    "git_repo": result.get("git_repo", ""),
                    "git_branch": result.get("git_branch", ""),
                    "turn_count": result.get("turn_count", 0),
                    "tool_call_count": result.get("tool_call_count", 0),
                    "active_duration_ms": result.get("active_duration_ms", 0),
                    "total_additions": result.get("total_additions", 0),
                    "total_deletions": result.get("total_deletions", 0),
                    "matched_files": result.get("matched_files", []),
                    "files_modified": result.get("modified_files", []),
                    "matched_prompts": [
                        s.get("text", s) if isinstance(s, dict) else s
                        for s in result.get("matched_prompts", [])
                    ],
                }

                if include_transcript:
                    _info(f"Fetching transcript for {session_id}...")
                    try:
                        transcript_params: dict[str, str] = {
                            "format": "markdown",
                        }
                        if verbose:
                            transcript_params["verbose"] = "true"
                        if effective_event_types:
                            transcript_params["event_types"] = effective_event_types
                        transcript_url = f"{base_endpoint}/v1/sessions/{session_id}/llm"
                        transcript_response = client.get(
                            transcript_url,
                            params=transcript_params,
                            headers=headers,
                        )
                        transcript_response.raise_for_status()
                        transcript_data = transcript_response.json()
                        session_entry["transcript"] = transcript_data.get("markdown", "")
                        session_entry["transcript_tokens"] = transcript_data.get("token_count", 0)
                        transcript_meta = transcript_data.get("metadata", {})
                        session_entry["files_read"] = transcript_meta.get("files_read", [])
                        session_entry["files_modified"] = transcript_meta.get("files_modified", [])
                    except httpx.HTTPStatusError as e:
                        _warn(
                            f"Could not fetch transcript for {session_id[:12]}: {e.response.status_code}"
                        )
                        session_entry["transcript"] = ""
                        session_entry["transcript_tokens"] = 0

                sessions.append(session_entry)

            # Report token counts to stderr
            total_tokens = 0
            for s in sessions:
                tokens = s.get("transcript_tokens", 0)
                total_tokens += tokens
                title = s.get("title") or "Untitled"
                sid = s["session_id"][:12]
                if use_color:
                    click.echo(
                        f"  {click.style(sid, dim=True)}  "
                        f"{click.style(f'{tokens:,} tokens', fg='cyan')}  "
                        f"{title}",
                        err=True,
                    )
                else:
                    click.echo(f"  {sid}  {tokens:,} tokens  {title}", err=True)
            if len(sessions) > 1:
                if use_color:
                    click.echo(
                        f"  {'total':<12}  "
                        f"{click.style(f'{total_tokens:,} tokens', fg='cyan', bold=True)}",
                        err=True,
                    )
                else:
                    click.echo(f"  {'total':<12}  {total_tokens:,} tokens", err=True)

            # Step 3: Output
            track("cli.search", {"query": query or "", "result_count": len(sessions)})
            if output_format == "json":
                output = {
                    "query": query,
                    "total_matches": total_count,
                    "sessions": sessions,
                }
                click.echo(json.dumps(output, indent=2))
            else:
                # Markdown format: only output concatenated transcripts
                transcripts = []
                for s in sessions:
                    t = s.get("transcript", "")
                    if t:
                        transcripts.append(t)
                if transcripts:
                    click.echo("\n\n<!-- session_boundary -->\n\n".join(transcripts))
                else:
                    _warn("No transcripts found.")

    except httpx.HTTPStatusError as e:
        _err(f"HTTP error: {e.response.status_code} - {e.response.text}")
        raise SystemExit(1)
    except httpx.RequestError as e:
        _err(f"Connection error: {e}")
        raise SystemExit(1)


def _check_duckdb_backends() -> tuple[bool, bool]:
    """Return (has_python_duckdb, has_duckdb_binary).

    Used to pick an execution path for ``hivemind export --format duckdb``
    without importing the Python ``duckdb`` module eagerly (it's a 60 MB
    install and an optional [export] extra).
    """
    try:
        import duckdb  # noqa: PLC0415, F401

        has_python = True
    except ImportError:
        has_python = False
    has_binary = shutil.which("duckdb") is not None
    return has_python, has_binary


def _build_duckdb_init_sql(files: list[dict]) -> list[str]:
    """SQL that mounts the exported parquet files as views.

    Run this first — subsequent SQL depends on the views existing so we
    can DESCRIBE them to decide which helper-view form to emit.
    """
    stmts: list[str] = [
        "INSTALL httpfs",
        "LOAD httpfs",
        # DuckDB caches parquet metadata and HTTP range responses so
        # repeated queries against the same row groups don't re-fetch.
        "SET enable_object_cache=true",
        "SET enable_http_metadata_cache=true",
    ]
    for f in files:
        name = f["name"]
        url = f.get("download_url")
        if not url:
            continue
        table_name = name.replace(".parquet", "")
        escaped_url = url.replace("'", "''")
        stmts.append(
            f"CREATE OR REPLACE VIEW {table_name} AS SELECT * FROM read_parquet('{escaped_url}')"
        )
    return stmts


def _build_duckdb_extension_sql(has_event_name: bool) -> list[str]:
    """SQL that materializes hot tables and creates friendly helper views.

    Split from ``_build_duckdb_init_sql`` because the helper views need
    to know whether ``event_name`` exists as a native column on the
    events parquet (added by the backend export after PR #XXX). For
    older cached exports we fall back to extracting the name from the
    JSON payload — works but defeats parquet row-group pruning.
    """
    name_expr = "event_name" if has_event_name else "json_extract_string(event_data, '$.name')"
    return [
        # Hot tables — sessions and session_summary_analyses are small
        # enough to materialize locally. Most analytical queries filter
        # and group on these, so paying the one-time copy is a huge win
        # over re-streaming from GCS on every query.
        "CREATE OR REPLACE TABLE sessions_local AS SELECT * FROM sessions",
        "CREATE OR REPLACE TABLE session_summary_analyses_local AS "
        "SELECT * FROM session_summary_analyses",
        # Friendly helper views — hide the AG-UI custom event JSONPath
        # extraction. Callers can write `SELECT file_path FROM
        # file_operations WHERE timestamp_ms > ...` instead of
        # memorizing `$.value.file_path`.
        f"""CREATE OR REPLACE VIEW file_operations AS
            SELECT session_id, timestamp_ms,
                   json_extract_string(event_data, '$.value.file_path') AS file_path,
                   json_extract_string(event_data, '$.value.operation') AS operation
            FROM events
            WHERE {name_expr} = 'UNIFIED_FILE_OPERATION'""",
        f"""CREATE OR REPLACE VIEW skill_activations AS
            SELECT session_id, timestamp_ms,
                   json_extract_string(event_data, '$.value.name') AS skill_name
            FROM events
            WHERE {name_expr} = 'UNIFIED_SKILL_ACTIVATION'""",
        f"""CREATE OR REPLACE VIEW token_usage_events AS
            SELECT session_id, timestamp_ms,
                   CAST(json_extract(event_data, '$.value.input_tokens') AS BIGINT)
                     AS input_tokens,
                   CAST(json_extract(event_data, '$.value.output_tokens') AS BIGINT)
                     AS output_tokens,
                   CAST(json_extract(event_data, '$.value.cached_read_tokens') AS BIGINT)
                     AS cached_read_tokens,
                   CAST(json_extract(event_data, '$.value.cached_write_tokens') AS BIGINT)
                     AS cached_write_tokens,
                   json_extract_string(event_data, '$.value._linked_message_id')
                     AS linked_message_id
            FROM events
            WHERE {name_expr} = 'TOKEN_USAGE'""",
        f"""CREATE OR REPLACE VIEW todo_updates AS
            SELECT session_id, timestamp_ms,
                   json_extract_string(event_data, '$.value.content') AS content,
                   json_extract_string(event_data, '$.value.status') AS status
            FROM events
            WHERE {name_expr} = 'UNIFIED_TODO_UPDATE'""",
    ]


def _duckdb_binary_exec(db_path: Path, sql: str, capture: bool = False) -> str:
    """Run a SQL script through the duckdb CLI binary.

    Uses stdin to pass the script so we don't need a tempfile. Returns
    stdout (stripped) when ``capture`` is true; otherwise returns "".
    """
    args: list[str] = ["duckdb", str(db_path)]
    if capture:
        args.extend(["-csv", "-noheader"])
    result = subprocess.run(
        args,
        input=sql,
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise click.ClickException(
            f"duckdb CLI failed: {result.stderr.strip() or result.stdout.strip()}"
        )
    return result.stdout.strip() if capture else ""


def _create_duckdb_with_views(
    db_path: Path,
    files: list[dict],
    console: Console,
) -> list[tuple[str, int]]:
    """Build a DuckDB file with httpfs views, hot tables, and helper views.

    Prefers the Python ``duckdb`` package; falls back to shelling out to
    the ``duckdb`` CLI binary if the package is not installed. The
    resulting file contains:

    - One VIEW per exported parquet file (via httpfs, no download)
    - Performance pragmas (object cache + HTTP metadata cache)
    - Materialized ``sessions_local`` + ``session_summary_analyses_local``
      for fast filter/group/join on the hot path
    - Friendly helper views ``file_operations``, ``skill_activations``,
      ``token_usage_events``, ``todo_updates`` that hide JSONPath extraction

    Returns a list of ``(table_name, row_count)`` tuples for display.
    """
    if db_path.exists():
        db_path.unlink()

    init_sql = _build_duckdb_init_sql(files)
    has_python, has_binary = _check_duckdb_backends()

    if has_python:
        import duckdb  # noqa: PLC0415

        table_info: list[tuple[str, int]] = []
        con = duckdb.connect(str(db_path))
        try:
            for stmt in init_sql:
                con.execute(stmt)

            # Detect whether `event_name` exists as a native column on
            # the events parquet (added by the backend after PR #XXX).
            # Stale cached exports predating that change fall back to
            # JSON extraction inside the helper views.
            has_event_name = bool(
                con.execute(
                    "SELECT count(*) FROM duckdb_columns() "
                    "WHERE table_name = 'events' AND column_name = 'event_name'"
                ).fetchone()[0]
            )

            for f in files:
                table_name = f["name"].replace(".parquet", "")
                file_bytes = f.get("bytes", 0)
                if not f.get("download_url"):
                    console.print(f"  [yellow]⚠[/yellow] {table_name} - no download URL available")
                    continue
                row_count = con.execute(f"SELECT count(*) FROM {table_name}").fetchone()[0]
                table_info.append((table_name, row_count))
                console.print(
                    f"  [green]✓[/green] {table_name}: {row_count:,} rows ({file_bytes:,} bytes)"
                )

            # Only create extension views/tables if the required base
            # views exist.  If a parquet had no download URL above, the
            # corresponding view was skipped, and trying to CREATE TABLE
            # sessions_local AS SELECT * FROM sessions would error out.
            created_views = {t for t, _ in table_info}
            required = {"sessions", "session_summary_analyses"}
            if required.issubset(created_views):
                for stmt in _build_duckdb_extension_sql(has_event_name):
                    con.execute(stmt)
            else:
                missing = required - created_views
                console.print(
                    f"  [yellow]⚠[/yellow] Skipping helper views — "
                    f"missing base tables: {', '.join(sorted(missing))}"
                )
        finally:
            con.close()

        if not has_event_name:
            console.print(
                "  [dim]Note: cached export predates the event_name column; "
                "helper views use a slower JSONPath fallback. "
                "Next export will be faster.[/dim]"
            )
        return table_info

    if has_binary:
        # Binary fallback: three subprocess invocations (init / detect /
        # extend). Slightly slower than the single-connection Python
        # path but avoids the 60 MB duckdb python dependency.
        _duckdb_binary_exec(db_path, ";\n".join(init_sql) + ";")

        detect_out = _duckdb_binary_exec(
            db_path,
            "SELECT count(*) FROM duckdb_columns() "
            "WHERE table_name = 'events' AND column_name = 'event_name';",
            capture=True,
        )
        has_event_name = detect_out.strip() != "0"

        table_info = []
        for f in files:
            table_name = f["name"].replace(".parquet", "")
            file_bytes = f.get("bytes", 0)
            if not f.get("download_url"):
                console.print(f"  [yellow]⚠[/yellow] {table_name} - no download URL available")
                continue
            row_count_out = _duckdb_binary_exec(
                db_path,
                f"SELECT count(*) FROM {table_name};",
                capture=True,
            )
            row_count = int(row_count_out)
            table_info.append((table_name, row_count))
            console.print(
                f"  [green]✓[/green] {table_name}: {row_count:,} rows ({file_bytes:,} bytes)"
            )

        created_views = {t for t, _ in table_info}
        required = {"sessions", "session_summary_analyses"}
        if required.issubset(created_views):
            _duckdb_binary_exec(
                db_path,
                ";\n".join(_build_duckdb_extension_sql(has_event_name)) + ";",
            )
        else:
            missing = required - created_views
            console.print(
                f"  [yellow]⚠[/yellow] Skipping helper views — "
                f"missing base tables: {', '.join(sorted(missing))}"
            )

        if not has_event_name:
            console.print(
                "  [dim]Note: cached export predates the event_name column; "
                "helper views use a slower JSONPath fallback. "
                "Next export will be faster.[/dim]"
            )
        return table_info

    # Should never reach here — the caller checks up-front.
    raise click.ClickException(
        "No DuckDB backend available. Install one of:\n"
        '  pip install "wandb-hivemind[export]"   (Python package)\n'
        "  brew install duckdb                    (CLI binary)\n"
        "  or see https://duckdb.org/docs/installation/"
    )


@main.command("export")
@click.option(
    "--dir",
    "output_dir",
    default=None,
    help="Output directory (default: ~/.hivemind/exports/me)",
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["duckdb", "parquet"]),
    default="duckdb",
    help="Export format (default: duckdb)",
)
@click.option(
    "-i",
    "--interactive",
    is_flag=True,
    help="Drop into a DuckDB shell after export (requires duckdb format)",
)
@click.option(
    "--poll-interval",
    default=3,
    hidden=True,
    help="Seconds between status polls (default: 3)",
)
@click.pass_context
def export_cmd(
    ctx: click.Context,
    output_dir: str | None,
    output_format: str,
    interactive: bool,
    poll_interval: int,
):
    """Export all your session data as Parquet or DuckDB.

    Downloads your source entries, events, sessions, and session summaries
    from the API as Parquet files. Optionally converts them into a single
    DuckDB database for easy querying.

    \b
    Examples:
        hivemind export                        # Export as DuckDB to ~/.hivemind/exports/me
        hivemind export --format parquet        # Export as raw Parquet files
        hivemind export -i                      # Export and open DuckDB shell
        hivemind export --dir ~/my-export       # Custom output directory
    """
    console = Console(stderr=True)

    if interactive and output_format != "duckdb":
        click.echo("Error: --interactive requires --format duckdb", err=True)
        raise SystemExit(1)

    # Fail fast on missing DuckDB backend *before* triggering a 30-60 second
    # server-side export. Previously we'd poll to completion and then die on
    # an ImportError at the end, which was a miserable UX.
    if output_format == "duckdb":
        has_python, has_binary = _check_duckdb_backends()
        if not has_python and not has_binary:
            click.echo(
                "Error: no DuckDB backend available for --format duckdb.\n"
                "Install one of:\n"
                '  pip install "wandb-hivemind[export]"   (Python package)\n'
                "  brew install duckdb                    (CLI binary)\n"
                "  or see https://duckdb.org/docs/installation/",
                err=True,
            )
            raise SystemExit(1)

    # Resolve output directory
    today = datetime.now(UTC).strftime("%Y-%m-%d")
    if output_dir is None:
        output_dir = str(Path.home() / ".hivemind" / "exports" / "me")
    out_path = Path(output_dir).resolve()

    # Authenticate
    effective_endpoint = get_effective_endpoint()
    base_endpoint = get_base_endpoint(effective_endpoint)
    auth_manager = AuthManager(base_endpoint)
    creds = auth_manager.store.load(auth_manager.endpoint)

    if not creds or auth_manager.store.is_expired(creds):
        if _is_local_dev_endpoint(base_endpoint):
            if asyncio.run(_dev_mode_authenticate(auth_manager)):
                creds = auth_manager.store.load(auth_manager.endpoint)

    if not creds or auth_manager.store.is_expired(creds):
        click.echo(
            f"Error: Not authenticated for {base_endpoint}. Run 'hivemind login' first.",
            err=True,
        )
        raise SystemExit(1)

    headers = {"Authorization": f"Bearer {creds.token}"}
    api_base = base_endpoint + "/v1"

    with httpx.Client(timeout=60.0) as client:
        # Step 1: Check for existing export or trigger a new one
        console.print("[bold]Checking export status...[/bold]")
        resp = client.get(f"{api_base}/users/me/data-export", headers=headers)

        # Detect non-JSON responses (e.g. frontend catch-all serving HTML)
        content_type = resp.headers.get("content-type", "")
        if resp.is_success and "application/json" not in content_type:
            click.echo(
                f"Error: Expected JSON response but got {content_type or 'unknown content type'}.\n"
                f"The server at {base_endpoint} may not support this endpoint yet.\n"
                f"If testing locally, use: hivemind --dev export ...",
                err=True,
            )
            raise SystemExit(1)

        needs_trigger = False
        if resp.status_code == 404:
            needs_trigger = True
        elif resp.is_success:
            status_data = resp.json()
            if status_data["status"] == "failed":
                needs_trigger = True
            elif status_data["status"] == "completed":
                # Check if the completed export is from today
                if status_data.get("export_date", "") != today:
                    needs_trigger = True
                # else: reuse the completed export
        else:
            click.echo(f"Error checking export status: {resp.status_code} - {resp.text}", err=True)
            raise SystemExit(1)

        if needs_trigger:
            console.print("[bold]Requesting data export...[/bold]")
            resp = client.post(f"{api_base}/users/me/data-export", headers=headers)
            if resp.status_code == 429:
                click.echo(
                    "An export has already been requested today. Try again tomorrow.", err=True
                )
                raise SystemExit(1)
            if not resp.is_success:
                click.echo(f"Error triggering export: {resp.status_code} - {resp.text}", err=True)
                raise SystemExit(1)

        # Step 2: Poll until export completes with a progress bar
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("{task.completed}/{task.total} tables"),
            TimeElapsedColumn(),
            console=console,
        ) as progress:
            # We export 4 tables: source_entries, events, sessions, session_summary_analyses
            task = progress.add_task("Exporting...", total=4)

            while True:
                resp = client.get(f"{api_base}/users/me/data-export", headers=headers)
                if not resp.is_success:
                    console.print(f"[red]Error polling status: {resp.text}[/red]")
                    raise SystemExit(1)

                status_data = resp.json()
                status = status_data["status"]
                phase = status_data.get("phase", "")

                if status == "completed":
                    progress.update(task, completed=4, description="[green]Export complete!")
                    break
                elif status == "failed":
                    console.print(
                        f"[red]Export failed: {status_data.get('error_message', 'Unknown error')}[/red]"
                    )
                    raise SystemExit(1)
                else:
                    # Map phase to progress
                    phase_map = {
                        "counting": 0,
                        "exporting_source_entries": 0,
                        "uploading_source_entries": 0,
                        "exporting_events": 1,
                        "uploading_events": 1,
                        "exporting_sessions": 2,
                        "uploading_sessions": 2,
                        "exporting_session_summary_analyses": 3,
                        "uploading_session_summary_analyses": 3,
                    }
                    completed = phase_map.get(phase, 0)
                    desc = phase.replace("_", " ").capitalize() if phase else "Waiting..."
                    progress.update(task, completed=completed, description=desc)

                time.sleep(poll_interval)

        # Step 3: Collect file info and download if needed
        files = status_data.get("files", [])
        if not files:
            console.print("[yellow]Export completed but no files found.[/yellow]")
            raise SystemExit(1)

        out_path.mkdir(parents=True, exist_ok=True)

        # For DuckDB format, create views pointing directly at the parquet URLs
        # (no download needed). For parquet format, download files to disk.
        if output_format == "duckdb":
            db_path = out_path / "export.duckdb"
            console.print(f"\n[bold]Creating DuckDB database: {db_path}[/bold]")

            table_info = _create_duckdb_with_views(db_path, files, console)

            db_size = db_path.stat().st_size
            console.print(f"\n[bold green]Done![/bold green] {db_path} ({db_size:,} bytes)")

        else:
            # Parquet format: download files to disk
            downloaded = 0
            console.print(f"\n[bold]Downloading {len(files)} files to {out_path}[/bold]")
            for file_info in files:
                name = file_info["name"]
                download_url = file_info.get("download_url")

                if not download_url:
                    console.print(f"  [yellow]⚠[/yellow] {name} - no download URL available")
                    continue

                dest = out_path / name
                with client.stream("GET", download_url) as dl_resp:
                    if not dl_resp.is_success:
                        console.print(
                            f"  [red]✗[/red] {name} - download failed: {dl_resp.status_code}"
                        )
                        continue
                    with open(dest, "wb") as f:
                        for chunk in dl_resp.iter_bytes(chunk_size=65536):
                            f.write(chunk)

                actual_size = dest.stat().st_size
                console.print(f"  [green]✓[/green] {name} ({actual_size:,} bytes)")
                downloaded += 1

            if not downloaded:
                console.print("[red]No files were downloaded successfully.[/red]")
                raise SystemExit(1)

            console.print(f"\n[bold green]Done![/bold green] Parquet files saved to {out_path}")
            db_path = None

    track("cli.export", {"format": output_format})

    # Step 5: Drop into DuckDB shell if interactive
    if interactive and db_path:
        # Build banner with table info and expiry note
        banner_lines = ["\n[bold]Opening DuckDB shell...[/bold]"]
        if table_info:
            banner_lines.append("[dim]Available tables:[/dim]")
            for tname, tcount in table_info:
                banner_lines.append(f"  [dim]- {tname} ({tcount:,} rows)[/dim]")
        banner_lines.append(
            "\n[yellow]Note:[/yellow] [dim]Views read from signed URLs valid for 24 hours."
        )
        banner_lines.append("Re-run [bold]hivemind export[/bold] to refresh.[/dim]")
        banner_lines.append("[dim]Type .quit to exit, .tables to list tables[/dim]\n")
        console.print("\n".join(banner_lines))

        # Try the duckdb CLI first, fall back to Python REPL
        try:
            subprocess.run(["duckdb", str(db_path)])
        except FileNotFoundError:
            # No duckdb CLI installed, use Python interactive mode
            try:
                import duckdb  # noqa: PLC0415

                con = duckdb.connect(str(db_path))
                import code  # noqa: PLC0415

                code.interact(
                    banner=f"DuckDB interactive shell — connected to {db_path}",
                    local={"con": con, "duckdb": duckdb},
                )
                con.close()
            except ImportError:
                click.echo("Error: duckdb not available for interactive mode", err=True)


if __name__ == "__main__":
    main()
