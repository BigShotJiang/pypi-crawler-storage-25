"""Secrets detection and redaction."""

from __future__ import annotations

import re
from typing import Any

REDACTED = "[REDACTED]"

# Known secret patterns
SECRET_PATTERNS = [
    # OpenAI - sk-proj- prefix with any alphanumeric characters
    (r"sk-proj-[a-zA-Z0-9_-]+", "OpenAI Project API Key"),
    # OpenAI - generic sk- prefix (but not sk-ant- or sk-proj-)
    (r"sk-(?!ant-|proj-)[a-zA-Z0-9]{20,}", "OpenAI API Key"),
    # Anthropic - sk-ant- prefix
    (r"sk-ant-[a-zA-Z0-9_-]+", "Anthropic API Key"),
    # AWS — \b prefix prevents matching inside base64 image blobs
    (r"\bAKIA[0-9A-Z]{16}", "AWS Access Key"),
    (r"\bASIA[0-9A-Z]{16}", "AWS Temp Access Key"),
    # GitHub - tokens have varying lengths, match 20+ characters
    (r"ghp_[a-zA-Z0-9]{20,}", "GitHub PAT"),
    (r"gho_[a-zA-Z0-9]{20,}", "GitHub OAuth"),
    (r"ghs_[a-zA-Z0-9]{20,}", "GitHub App Token"),
    (r"ghr_[a-zA-Z0-9]{20,}", "GitHub Refresh Token"),
    (r"github_pat_[a-zA-Z0-9_]{20,}", "GitHub Fine-grained PAT"),
    (r"pat_[a-zA-Z0-9_]{20,}", "Generic PAT"),
    (r"glpat-[a-zA-Z0-9_-]{20,}", "GitLab PAT"),
    (r"npm_[a-zA-Z0-9]{36}", "NPM Token"),
    # Google — \b prefix prevents matching inside base64 image blobs
    (r"\bAIza[0-9A-Za-z_-]{35}", "Google API Key"),
    (r"sk_live_[0-9a-zA-Z]{16,}", "Stripe Secret Key"),
    (r"rk_live_[0-9a-zA-Z]{16,}", "Stripe Restricted Key"),
    (r"hf_[a-zA-Z0-9]{20,}", "Hugging Face Token"),
    # Slack
    (r"xox[baprs]-[0-9a-zA-Z-]{10,}", "Slack Token"),
    (r"xoxc-[0-9a-zA-Z-]{10,}", "Slack Session Token"),
    # Generic assignment patterns — \b(?!\s*[.(]) after the value prevents
    # matching function calls like `get_api_key(args)` and property access
    # like `authentication_bearer.credentials`.
    (r'api[_-]?key["\']?\s*[:=]\s*["\']?([a-zA-Z0-9_-]{20,})\b(?!\s*[.(])["\']?', "API Key"),
    (
        r'aws[_-]?secret[_-]?access[_-]?key["\']?\s*[:=]\s*["\']?([A-Za-z0-9/+=]{40})["\']?',
        "AWS Secret Access Key",
    ),
    # Password and Secret assignment patterns are handled by
    # CONTEXT_SECRET_ASSIGNMENT_PATTERN which has better heuristics (requires
    # a digit in the value, excludes parens/brackets, skips function calls).
    (r'token["\']?\s*[:=]\s*["\']?([a-zA-Z0-9_-]{20,})\b(?!\s*[.(])["\']?', "Token"),
]

# Compile patterns
COMPILED_PATTERNS = [(re.compile(p, re.IGNORECASE), name) for p, name in SECRET_PATTERNS]
CREDENTIAL_URL_PATTERN = re.compile(r"(https?://[^/\s:@]+:)([^@/\s]+)(@)")
# Schemeless git remote credentials: `user:token@github.com`.
# Anchored to known GitHub token prefixes to avoid catastrophic
# backtracking on large base64 blobs (the old `[^@/\s]{8,}` pattern
# was O(n^2+) on 86KB screenshot data).  Plain-text passwords are no
# longer matched — GitHub deprecated password auth and the credential
# URL pattern (CREDENTIAL_URL_PATTERN) handles the `https://` case.
SCHEMELESS_GITHUB_CREDENTIAL_PATTERN = re.compile(
    r"(?<![a-zA-Z0-9])"  # username must not be preceded by an ASCII alphanumeric
    r"([a-zA-Z0-9._-]+:)"
    r"((?:ghp_|gho_|ghs_|ghr_|github_pat_|pat_)[a-zA-Z0-9_-]+)"
    r"(@github\.com)",
    re.IGNORECASE,
)
BEARER_TOKEN_PATTERN = re.compile(
    r"(authorization\s*[:=]\s*bearer\s+)([a-zA-Z0-9._~+/=-]{16,})",
    re.IGNORECASE,
)
JWT_PATTERN = re.compile(r"\beyJ[a-zA-Z0-9_-]{8,}\.[a-zA-Z0-9._-]{8,}\.[a-zA-Z0-9._-]{8,}\b")
# Match secret-looking assignments like `API_KEY=sk-xxxx` or `password: "hunter2"`.
# The value must look like a credential, not a code expression. We require at least
# one digit in the value and exclude parens/brackets and similar punctuation to
# distinguish secrets from code identifiers like `re.compile`, `auth_token`, `data.get`.
CONTEXT_SECRET_ASSIGNMENT_PATTERN = re.compile(
    r"(?P<prefix>"
    r"(?<!/)\b[A-Za-z0-9_.-]*"
    r"(?:api[_-]?key|access[_-]?token|refresh[_-]?token|id[_-]?token|"
    r"auth(?:orization)?[_-]?token|session[_-]?token|client[_-]?secret|"
    r"private[_-]?key|password|passwd|secret)"
    r"[A-Za-z0-9_.-]*\s*[:=]\s*[\"']?"
    r")(?P<value>(?=[^\s\"'`;,(){}\[\]=]*[0-9])[^\s\"'`;,(){}\[\]=]{8,})",
    re.IGNORECASE,
)
# Env-var convention: UPPER_SNAKE names ending in a sensitive suffix.
# Complements CONTEXT_SECRET_ASSIGNMENT_PATTERN, which targets code-style
# assignments (lowercase, requires a digit in the value). Shell/env-style
# assignments use UPPER_SNAKE_CASE and the values are often alphabetic-only
# passwords or opaque tokens, so we use broader heuristics here:
#   * the variable name must be UPPER_SNAKE and end in a known sensitive suffix
#     (PASS / PASSWORD / PASSWD / SECRET / TOKEN / API_KEY / APIKEY /
#      PRIVATE_KEY / ACCESS_KEY / AUTH)
#   * the value must be 4+ non-whitespace, non-quote, non-shell-meta chars
#   * no digit requirement
# Anchored to start-of-line or shell separators (`;`, `&`, `|`, `(`, whitespace)
# and tolerates an optional `export ` prefix.
ENV_SECRET_ASSIGNMENT_PATTERN = re.compile(
    r"(?P<prefix>(?:^|[\s;&|(])(?:export\s+)?"
    r"[_A-Z][A-Z0-9_]*"
    r"(?:PASSWORD|PASSWD|PASS|SECRET|TOKEN|API_?KEY|PRIVATE_?KEY|ACCESS_?KEY|AUTH)"
    r"\s*=\s*[\"']?)"
    r"(?P<value>[^\s\"'`;&|(){}\[\],]{4,})"
)
# Known code-reference prefixes used to skip ENV_SECRET_ASSIGNMENT_PATTERN
# matches whose "value" is actually an attribute lookup rather than a literal
# credential (e.g. `CLIENT_SECRET = process.env.X`). Narrowly scoped to
# well-known module/object names so literal dot-delimited tokens (some JWT-ish
# or domain-prefixed secrets) are still redacted.
_CODE_REF_VALUE_RE = re.compile(
    r"^(?:process\.env|os\.environ|os\.getenv|config|settings|env|this|self)\b"
)


def _env_secret_repl(m: re.Match[str]) -> str:
    """Skip env-secret matches whose value is a code reference (e.g.
    ``CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET``)."""
    value = m.group("value")
    if _CODE_REF_VALUE_RE.match(value):
        return m.group(0)
    rest = m.string[m.end() :]
    if rest.lstrip().startswith("("):  # function call: foo = bar(...)
        return m.group(0)
    return m.group("prefix") + REDACTED


QUERY_SECRET_PARAM_PATTERN = re.compile(
    r"(?P<prefix>[?&](?:api[_-]?key|access[_-]?token|refresh[_-]?token|id[_-]?token|"
    r"auth[_-]?token|client[_-]?secret|password|secret)=)(?P<value>[^&\s]{8,})",
    re.IGNORECASE,
)
PRIVATE_KEY_BLOCK_PATTERN = re.compile(
    r"-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]+?-----END [A-Z ]*PRIVATE KEY-----",
    re.MULTILINE,
)


def _subn(pattern: re.Pattern[str], repl: str, text: str) -> tuple[str, int]:
    """Apply pattern substitution and return (result, substitution_count)."""
    return pattern.subn(repl, text)


_FILE_EXT_BEFORE_COLON_RE = re.compile(r"\.\w{1,5}\s*:\s*$")


def _context_secret_repl(m: re.Match[str]) -> str:
    """Replacement callback for CONTEXT_SECRET_ASSIGNMENT_PATTERN.

    Skips matches where:
    - the captured value is immediately followed by ``(``, indicating a
      function call (e.g. ``auth_token = base64.b64encode(...)``), or
    - the prefix ends with a file extension before the colon, indicating a
      file path listing (e.g. ``30-secrets.sh: content-sha256=...``).
    """
    rest = m.string[m.end() :]
    if rest.lstrip().startswith("("):
        return m.group(0)  # leave unchanged — function call
    prefix = m.group("prefix")
    if _FILE_EXT_BEFORE_COLON_RE.search(prefix):
        return m.group(0)  # leave unchanged — file path listing
    return prefix + REDACTED


def _credential_url_repl(m: re.Match[str]) -> str:
    """Replacement callback for credential URL patterns.

    Skips matches where the password portion is already ``[REDACTED]`` so that
    re-processing previously redacted text doesn't inflate the count.
    """
    password = m.group(2)
    if password == REDACTED:
        return m.group(0)  # already redacted — leave unchanged
    return m.group(1) + REDACTED + m.group(3)


# Strings longer than this are checked for binary/base64 content before
# running regex patterns.  No legitimate secret is anywhere near 100KB;
# base64-encoded images and file blobs are the common case and can trigger
# catastrophic backtracking in some patterns.
_MAX_REDACT_SCAN_LEN = 100_000


_BASE64_ALPHABET = frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=")


def _looks_like_base64(text: str) -> bool:
    """Fast heuristic: sample the middle of the string for base64 density.

    Returns True if a short ASCII window is dominated by base64-alphabet
    characters (alphanumeric plus ``+``, ``/``, ``=``), which is typical
    of inline image or binary data.
    """
    sample_size = 200
    mid = len(text) // 2
    sample = text[mid : mid + sample_size]
    if not sample or not sample.isascii():
        return False
    base64_chars = sum(1 for c in sample if c in _BASE64_ALPHABET)
    return base64_chars / len(sample) > 0.90


def redact_secrets_counted(text: str) -> tuple[str, int]:
    """Redact secrets from text and return the count of redactions.

    Returns:
        Tuple of (redacted_text, number_of_secrets_redacted).
    """
    # Skip large strings that look like base64/binary blobs.  Running
    # regex patterns against 86KB+ base64 image data can cause catastrophic
    # backtracking (observed: 68s per entry).  Secrets are short strings;
    # no real secret lives inside a base64 blob.
    if len(text) > _MAX_REDACT_SCAN_LEN and _looks_like_base64(text):
        return text, 0

    result = text
    count = 0

    # Redact private key blocks and common auth token wrappers first.
    result, n = _subn(PRIVATE_KEY_BLOCK_PATTERN, REDACTED, result)
    count += n
    result, n = _subn(BEARER_TOKEN_PATTERN, rf"\1{REDACTED}", result)
    count += n
    result, n = _subn(JWT_PATTERN, REDACTED, result)
    count += n

    # Context secret assignments — use callback to skip function calls.
    new_result = CONTEXT_SECRET_ASSIGNMENT_PATTERN.sub(_context_secret_repl, result)
    # Count how many replacements actually happened (callback returns
    # the original text for skipped matches, so compare).
    if new_result != result:
        count += new_result.count(REDACTED) - result.count(REDACTED)
        result = new_result

    new_result = ENV_SECRET_ASSIGNMENT_PATTERN.sub(_env_secret_repl, result)
    if new_result != result:
        count += new_result.count(REDACTED) - result.count(REDACTED)
        result = new_result

    result, n = _subn(QUERY_SECRET_PARAM_PATTERN, rf"\g<prefix>{REDACTED}", result)
    count += n

    # Redact URL-embedded credentials but keep the URL structure.
    # Use callback to skip already-redacted passwords (idempotency).
    # Count by comparing REDACTED occurrences since the callback may leave
    # matches unchanged.
    for url_pattern in (CREDENTIAL_URL_PATTERN, SCHEMELESS_GITHUB_CREDENTIAL_PATTERN):
        new_result = url_pattern.sub(_credential_url_repl, result)
        if new_result != result:
            count += new_result.count(REDACTED) - result.count(REDACTED)
            result = new_result

    # Apply known patterns
    for pattern, _ in COMPILED_PATTERNS:
        result, n = pattern.subn(REDACTED, result)
        count += n

    return result, count


def redact_secrets(text: str) -> str:
    """Redact secrets from text."""
    result, _ = redact_secrets_counted(text)
    return result


# Keys whose values are opaque binary blobs (encrypted content, cryptographic
# signatures).  Substring matches inside these are always false positives.
OPAQUE_BLOB_KEYS = frozenset(
    {
        "encrypted_content",
        "signature",
    }
)


def redact_dict_counted(data: Any) -> tuple[Any, int]:
    """Recursively redact secrets from a dictionary structure, counting redactions.

    Returns:
        Tuple of (redacted_data, number_of_secrets_redacted).
    """
    if isinstance(data, str):
        return redact_secrets_counted(data)
    elif isinstance(data, dict):
        count = 0
        out = {}
        for k, v in data.items():
            if k in OPAQUE_BLOB_KEYS:
                out[k] = v  # skip — opaque blob, never user-supplied secrets
            else:
                redacted, n = redact_dict_counted(v)
                out[k] = redacted
                count += n
        return out, count
    elif isinstance(data, list):
        count = 0
        out_list = []
        for item in data:
            redacted, n = redact_dict_counted(item)
            out_list.append(redacted)
            count += n
        return out_list, count
    else:
        return data, 0


def redact_dict(data: Any) -> Any:
    """Recursively redact secrets from a dictionary structure."""
    result, _ = redact_dict_counted(data)
    return result
