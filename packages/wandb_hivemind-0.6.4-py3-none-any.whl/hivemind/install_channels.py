"""Single registry for hivemind install-channel descriptors.

Before this module, "what does install channel X look like?" was
answered by partial copies in ``service.py`` (``_channel_installed``,
``_channel_binary_path``, ``_macos_active_supervisor``) and ``cli.py``
(``_detect_other_channels``, ``_DARWIN_CHANNEL_LABELS``). Adding a new
channel meant edits in five places, and the probes drifted apart in
practice (e.g. the script channel honoured ``read_install_marker_field``
in some places but not others). This module collapses those into one
ordered tuple of :class:`Channel` descriptors.

``CHANNELS`` order is the precedence used by ``hivemind start`` when
multiple channels are on disk: pkg > script > brew-cask > brew > uv-tool.
``brew`` is in the list for that precedence, but it goes through
``brew services`` rather than the per-user LaunchAgent label, so
``get_service_manager()`` routes it to ``HomebrewServiceManager`` before
the launchd-managed channels are considered.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from hivemind.install_marker import read_install_marker_field


@dataclass(frozen=True)
class Channel:
    """Descriptor for one hivemind install channel.

    The match callables are split between unresolved and resolved
    variants because :func:`hivemind.service._macos_active_supervisor`
    walks every channel against the plist's unresolved
    ``ProgramArguments[0]`` first (so ``~/.local/bin/hivemind`` can be
    classified as ``script`` even though it might resolve into a pkg or
    cask install) before falling back to the resolved path for plists
    that point at generic symlinks we don't recognise on the surface.
    """

    name: str
    label: str
    is_installed: Callable[[], bool]
    binary_path: Callable[[], Path | None]
    match_unresolved: Callable[[str], bool]
    match_resolved: Callable[[str], bool]
    # Callable rather than a static string because `script` honors the
    # install-marker binary path (non-default --prefix installs) and the
    # right `rm <path>` depends on what the marker recorded. Other
    # channels just return a constant.
    uninstall_cmd: Callable[[], str | None] = lambda: None


# ----- pkg -------------------------------------------------------------------

_PKG_BINARY = Path("/usr/local/hivemind/bin/hivemind")


def _pkg_installed() -> bool:
    return _PKG_BINARY.exists()


def _pkg_binary_path() -> Path | None:
    return _PKG_BINARY if _PKG_BINARY.exists() else None


def _pkg_match(path: str) -> bool:
    return path.startswith("/usr/local/hivemind/")


# ----- script (curl|sh installer) -------------------------------------------


def _script_installed() -> bool:
    marker_binary = read_install_marker_field("binary")
    if marker_binary:
        p = Path(marker_binary)
        return p.exists() and not p.is_symlink()
    p = Path.home() / ".local" / "bin" / "hivemind"
    return p.exists() and not p.is_symlink()


def _script_binary_path() -> Path | None:
    marker_binary = read_install_marker_field("binary")
    if marker_binary:
        p = Path(marker_binary)
        return p if p.exists() and not p.is_symlink() else None
    p = Path.home() / ".local" / "bin" / "hivemind"
    return p if p.exists() and not p.is_symlink() else None


def _script_match_unresolved(path: str) -> bool:
    if path == str(Path.home() / ".local" / "bin" / "hivemind"):
        return True
    marker_binary = read_install_marker_field("binary")
    return bool(marker_binary) and path == marker_binary


def _script_uninstall_cmd() -> str:
    # install.sh writes the marker for non-default --prefix installs, so a
    # custom-prefix script needs `rm <marker_binary>` rather than the
    # default `rm ~/.local/bin/hivemind` — which (a) wouldn't exist there
    # and (b) might clobber uv-tool's shim if uv-tool is also installed.
    marker_binary = read_install_marker_field("binary")
    if marker_binary:
        return f"rm {marker_binary}"
    return "rm ~/.local/bin/hivemind"


# ----- brew-cask ------------------------------------------------------------

_BREW_CASK_PREFIXES = ("/opt/homebrew", "/usr/local")


def _brew_cask_installed() -> bool:
    return any(Path(p + "/Caskroom/hivemind-app").exists() for p in _BREW_CASK_PREFIXES)


def _brew_cask_binary_path() -> Path | None:
    for prefix in _BREW_CASK_PREFIXES:
        p = Path(prefix) / "bin" / "hivemind"
        if p.exists():
            return p
    return None


def _brew_cask_match(path: str) -> bool:
    return "/Caskroom/hivemind-app/" in path


# ----- brew (formula) -------------------------------------------------------


def _brew_installed() -> bool:
    return any(Path(p + "/Cellar/hivemind").exists() for p in _BREW_CASK_PREFIXES)


def _brew_match_unresolved(path: str) -> bool:
    return "/Cellar/hivemind/" in path or "/opt/hivemind/" in path


def _brew_match_resolved(path: str) -> bool:
    return "/Cellar/hivemind/" in path


# ----- uv-tool --------------------------------------------------------------


def _uv_tool_dir() -> Path:
    # Lazy: tests patch Path.home() and need this to re-evaluate per call.
    return Path.home() / ".local" / "share" / "uv" / "tools" / "wandb-hivemind"


def _uv_tool_installed() -> bool:
    return _uv_tool_dir().exists()


def _uv_tool_binary_path() -> Path | None:
    # Prefer the ~/.local/bin shim so `uv tool upgrade` doesn't strand
    # the LaunchAgent on a versioned path.
    shim = Path.home() / ".local" / "bin" / "hivemind"
    if shim.exists() and shim.is_symlink():
        return shim
    direct = _uv_tool_dir() / "bin" / "hivemind"
    return direct if direct.exists() else None


def _uv_tool_match_unresolved(path: str) -> bool:
    return "/uv/tools/" in path


# ----- registry -------------------------------------------------------------


def _never(_: str) -> bool:
    return False


# Order is the disk-probe precedence used by `hivemind start` when more
# than one channel is on disk. brew is part of the list, but it routes
# through `brew services` rather than the launchd label — see
# `service.get_service_manager()`.
CHANNELS: tuple[Channel, ...] = (
    Channel(
        name="pkg",
        label=".pkg installer",
        is_installed=_pkg_installed,
        binary_path=_pkg_binary_path,
        match_unresolved=_pkg_match,
        match_resolved=_pkg_match,
        uninstall_cmd=lambda: "sudo /usr/local/hivemind/uninstall.sh",
    ),
    Channel(
        name="script",
        label="curl|sh installer",
        is_installed=_script_installed,
        binary_path=_script_binary_path,
        match_unresolved=_script_match_unresolved,
        # script's binary lives at ~/.local/bin/hivemind; resolving a
        # cross-channel symlink will land us in pkg/brew/cask, never
        # back at the script binary itself.
        match_resolved=_never,
        uninstall_cmd=_script_uninstall_cmd,
    ),
    Channel(
        name="brew-cask",
        label="Homebrew cask (hivemind-app)",
        is_installed=_brew_cask_installed,
        binary_path=_brew_cask_binary_path,
        match_unresolved=_brew_cask_match,
        match_resolved=_brew_cask_match,
        uninstall_cmd=lambda: "brew uninstall --cask wandb/taps/hivemind-app",
    ),
    Channel(
        name="brew",
        label="Homebrew formula (wandb/taps/hivemind)",
        is_installed=_brew_installed,
        # brew goes through `brew services`, not the launchd label, so
        # nothing in the registry asks for the brew binary path. Keep
        # it explicit by returning None.
        binary_path=lambda: None,
        match_unresolved=_brew_match_unresolved,
        match_resolved=_brew_match_resolved,
        uninstall_cmd=lambda: "brew uninstall wandb/taps/hivemind",
    ),
    Channel(
        name="uv-tool",
        label="uv tool install",
        is_installed=_uv_tool_installed,
        binary_path=_uv_tool_binary_path,
        match_unresolved=_uv_tool_match_unresolved,
        # uv-tool's plist points directly at the versioned binary inside
        # ~/.local/share/uv/tools/, so the unresolved path already
        # carries the `/uv/tools/` substring — resolved only matters
        # if someone routes through a third-party symlink we don't
        # currently recognise.
        match_resolved=_never,
        uninstall_cmd=lambda: "uv tool uninstall wandb-hivemind",
    ),
)


def get_channel(name: str) -> Channel | None:
    """Return the registry entry named ``name``, or ``None`` if absent.

    ``name`` may also be ``"dev"``, ``"unknown"``, or ``"launchd"`` —
    those aren't registry entries, so callers handle them as literals.
    """
    for c in CHANNELS:
        if c.name == name:
            return c
    return None
