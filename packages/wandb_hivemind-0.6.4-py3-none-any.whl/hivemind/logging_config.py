"""Logging configuration for hivemind daemon.

Provides syslog integration with fallback to file-based logging.
"""

from __future__ import annotations

import logging
import logging.handlers
import os
import platform
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

# Daemon identifier for syslog
DAEMON_NAME = "hivemind"

# httpx URL substrings whose request logs should be demoted to DEBUG. These
# fire on every daemon cycle (heartbeat ~5min, telemetry flush ~30s) and bury
# the genuinely useful INFO logs from `/v1/ingest`, `/v1/auth/*`, etc.
_HTTPX_DEBUG_PATHS = ("/v1/daemon/heartbeat", "/v1/telemetry/track")


class HttpxNoisyPathFilter(logging.Filter):
    """Demote httpx request logs for noisy/repetitive endpoints to DEBUG.

    httpx emits "HTTP Request: METHOD URL ..." at INFO for every request.
    Mutating the record's level to DEBUG lets the rest of httpx stay at INFO
    while these specific endpoints only surface when DEBUG is enabled.
    """

    def filter(self, record: logging.LogRecord) -> bool:
        if record.levelno != logging.INFO:
            return True
        msg = record.getMessage()
        for path in _HTTPX_DEBUG_PATHS:
            if path in msg:
                record.levelno = logging.DEBUG
                record.levelname = "DEBUG"
                break
        return True


def get_default_log_path() -> Path:
    """Get the platform-appropriate default log file path.

    Priority:
    1. HIVEMIND_LOG_FILE environment variable (already works for Homebrew)
    2. Platform-specific default:
       - macOS: ~/Library/Logs/hivemind/hivemind.log
       - Linux: ~/.local/state/hivemind/hivemind.log (XDG_STATE_HOME)
       - Fallback: ~/.hivemind/hivemind.log
    """
    env_path = os.environ.get("HIVEMIND_LOG_FILE")
    if env_path:
        return Path(env_path)

    system = platform.system().lower()
    if system == "darwin":
        return Path.home() / "Library" / "Logs" / "hivemind" / "hivemind.log"
    elif system == "linux":
        xdg_state = os.environ.get("XDG_STATE_HOME", str(Path.home() / ".local" / "state"))
        return Path(xdg_state) / "hivemind" / "hivemind.log"
    else:
        return Path.home() / ".hivemind" / "hivemind.log"


# For backward compatibility - computed on first access
DEFAULT_LOG_FILE = get_default_log_path()
DEFAULT_ERR_FILE = Path("/tmp/hivemind.err")


def _get_syslog_address() -> str | tuple[str, int] | None:
    """Get the appropriate syslog address for the current platform.

    Returns:
        Syslog socket path (str), (host, port) tuple, or None if unavailable.
    """
    system = platform.system().lower()

    if system == "darwin":
        # macOS unified logging doesn't reliably show SysLogHandler messages
        # from Python, so we use file-based logging instead
        return None
    elif system == "linux":
        # Linux typically uses /dev/log
        for path in ["/dev/log", "/var/run/syslog"]:
            if os.path.exists(path):
                return path

    return None


def _create_syslog_handler() -> logging.Handler | None:
    """Create a syslog handler if available.

    Returns:
        SysLogHandler or None if syslog is not available.
    """
    address = _get_syslog_address()
    if not address:
        return None

    try:
        handler = logging.handlers.SysLogHandler(
            address=address,
            facility=logging.handlers.SysLogHandler.LOG_DAEMON,
        )
        # Format with daemon name for syslog
        handler.setFormatter(logging.Formatter(f"{DAEMON_NAME}: %(levelname)s %(message)s"))
        return handler
    except (OSError, ConnectionError) as e:
        # Syslog socket exists but we can't connect
        print(f"Warning: Could not connect to syslog: {e}", file=sys.stderr)
        return None


def _create_file_handler(log_file: Path) -> logging.Handler:
    """Create a file handler with rotation.

    Args:
        log_file: Path to the log file.

    Returns:
        RotatingFileHandler configured for the log file.
    """
    # Ensure parent directory exists
    log_file.parent.mkdir(parents=True, exist_ok=True)

    handler = logging.handlers.RotatingFileHandler(
        log_file,
        maxBytes=10 * 1024 * 1024,  # 10 MB
        backupCount=3,
    )
    handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
    return handler


def configure_logging(
    level: int = logging.INFO,
    log_file: Path | None = None,
    force_file: bool = False,
) -> str:
    """Configure logging for the daemon.

    Attempts to use syslog first, falling back to file-based logging.

    Args:
        level: Logging level (default: INFO).
        log_file: Path to log file for fallback (default: /tmp/hivemind.log).
        force_file: If True, skip syslog and use file logging directly.

    Returns:
        String indicating the logging destination ("syslog" or file path).
    """
    log_file = log_file or DEFAULT_LOG_FILE
    root_logger = logging.getLogger()
    root_logger.setLevel(level)

    # Remove any existing handlers
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    # Demote httpx logs for repetitive endpoints (heartbeat, telemetry) to
    # DEBUG. Reattach idempotently so reconfigure_logging() doesn't stack
    # filters on the httpx logger.
    httpx_logger = logging.getLogger("httpx")
    for existing in list(httpx_logger.filters):
        if isinstance(existing, HttpxNoisyPathFilter):
            httpx_logger.removeFilter(existing)
    httpx_logger.addFilter(HttpxNoisyPathFilter())

    # Try syslog first (unless forced to use file)
    if not force_file:
        syslog_handler = _create_syslog_handler()
        if syslog_handler:
            # Pin the handler to the configured level. Default Handler.level
            # is NOTSET (0), which accepts every record that reaches it — so
            # filters that demote records (HttpxNoisyPathFilter) would have no
            # effect. Setting the level here makes the handler-level gate in
            # callHandlers() reject demoted records as intended.
            syslog_handler.setLevel(level)
            root_logger.addHandler(syslog_handler)
            # Also add a minimal console handler for immediate feedback
            console = logging.StreamHandler(sys.stderr)
            console.setLevel(logging.WARNING)  # Only warnings and above to console
            console.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
            root_logger.addHandler(console)
            return "syslog"

    # Fall back to file logging
    file_handler = _create_file_handler(log_file)
    file_handler.setLevel(level)  # See note above re: Handler.level NOTSET default.
    root_logger.addHandler(file_handler)

    # Console handler for warnings and errors only (avoid noise in foreground)
    console = logging.StreamHandler(sys.stderr)
    console.setLevel(logging.WARNING)
    console.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    root_logger.addHandler(console)

    return str(log_file)


LogSourceKind = Literal["journald", "syslog_file", "file"]


@dataclass(frozen=True)
class LogSource:
    """Where to find hivemind daemon logs.

    Mirrors the destination chosen by ``configure_logging()`` so that
    ``hivemind status`` and ``hivemind logs`` agree on a single source
    of truth.
    """

    kind: LogSourceKind
    path: Path | None = None
    filter_pattern: str | None = None

    @property
    def display(self) -> str:
        """Human-readable string for ``hivemind status``."""
        if self.kind == "journald":
            # `-e` jumps the pager to the end so a copy-paste shows recent
            # entries instead of the oldest. Without it, `journalctl -t
            # hivemind` opens at the top of the journal — confusing on a
            # box with weeks of history.
            return "journalctl -t hivemind -e"
        if self.kind == "syslog_file":
            return f"{self.path} (filtered: {self.filter_pattern})"
        return str(self.path)


def resolve_log_source() -> LogSource:
    """Determine where hivemind logs are being written.

    Mirrors ``configure_logging()``'s decision: if the daemon would route
    through syslog (Linux with /dev/log or /var/run/syslog), report that
    destination. Otherwise return the most recently modified log file
    among known candidates, falling back to the platform default path.

    Returns:
        A LogSource describing the destination. ``kind == "file"`` and
        ``path`` may point to a path that doesn't exist yet (the daemon
        hasn't started); callers should handle that.
    """
    env_path = os.environ.get("HIVEMIND_LOG_FILE")
    if env_path:
        return LogSource(kind="file", path=Path(env_path))

    if _get_syslog_address():
        if shutil.which("journalctl"):
            return LogSource(kind="journald")
        for path_str in ("/var/log/syslog", "/var/log/messages"):
            path = Path(path_str)
            if path.exists():
                return LogSource(
                    kind="syslog_file",
                    path=path,
                    filter_pattern=DAEMON_NAME,
                )

    candidates: list[Path] = [get_default_log_path()]
    if platform.system().lower() == "darwin":
        # launchd's StandardOutPath / StandardErrorPath, written by every
        # macOS install channel (pkg postinstall, brew-cask postflight,
        # `hivemind install-service`). Separate from `hivemind.log`, which
        # holds the Python logger output — startup banners and uncaught
        # tracebacks land here, not in `hivemind.log`.
        macos_log_dir = Path.home() / "Library" / "Logs" / "hivemind"
        candidates.append(macos_log_dir / "hivemind.out.log")
        candidates.append(macos_log_dir / "hivemind.err.log")
        candidates.append(Path("/opt/homebrew/var/log/hivemind.log"))
        candidates.append(Path("/usr/local/var/log/hivemind.log"))
    candidates.append(Path("/tmp/hivemind.log"))

    # Deduplicate while preserving order so the default path wins on ties.
    seen: set[Path] = set()
    ordered: list[Path] = []
    for c in candidates:
        if c not in seen:
            ordered.append(c)
            seen.add(c)

    existing = [p for p in ordered if p.exists()]
    if existing:
        return LogSource(kind="file", path=max(existing, key=lambda p: p.stat().st_mtime))
    return LogSource(kind="file", path=get_default_log_path())
