"""Self-update watcher for the hivemind daemon.

Polls a release manifest on a timer and, when a newer signed release is
available, applies the upgrade *in place* and requests a clean exit.
Under a supervisor (launchd / brew services / systemd), the daemon is
restarted automatically and picks up the new code.

Supported install methods:

- ``brew-cask`` — download signed darwin-arm64 binary, verify
  sha256 + codesign + Team ID, strip the quarantine xattr, and
  ``os.replace`` it over the binary inside the Caskroom.
- ``pkg`` — same binary-swap as ``brew-cask``, targeting
  ``/usr/local/hivemind/bin/hivemind``. The pkg postinstall chowns
  that directory to the console user so this works without sudo;
  on legacy installs that still have it root-owned the strategy
  noops with a clear "no write access" message.
- ``brew`` (formula) — shell out to the formula venv's pip to
  ``pip install --upgrade --no-deps wandb-hivemind wandb-agentstream``.
  Runs as the user (brew prefix is user-owned).
- ``uv-tool`` — ``uv tool upgrade wandb-hivemind``. uv rebuilds the
  managed venv and updates the entry-point shim in ``~/.local/bin``.
- ``dev`` / ``unknown`` — no auto-apply. The watcher polls and logs
  that a newer release is available but does not persist a separate
  marker for it — only successful applies write ``pending_restart``
  to state. Users on these channels upgrade manually via their
  package manager (``pip install --upgrade``, ``uv tool upgrade``,
  ``brew upgrade``) and ``hivemind restart``.

See ``docs/BREW_AUTO_UPGRADE_DESIGN.md`` (Phase 3) for the wider design
and the rationale behind each trade-off. This module is the runtime
half; the release workflow's ``publish-cask`` job is what populates
the manifest it reads.

Configuration (precedence: env var > config > default):

- ``[daemon] auto_upgrade`` (``"off"`` / ``"notify"`` / ``"apply"``,
  default ``"notify"``) — see ``DaemonConfig`` / ``UpgradeMode``.
- ``HIVEMIND_UPGRADE_WATCHER_DISABLED=1`` — hard kill-switch for CI / debug.
- ``HIVEMIND_UPGRADE_APPLY_ENABLED=1`` — force auto-apply on, useful
  for staging environments where you want apply without committing it
  to the user's config file.

The auto-apply default reflects v0.x maturity: we want telemetry into
who's running what, but we don't want a regressed release to mass-flip
user binaries before we can roll the manifest back.
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import platform
import shutil
import subprocess
import sys
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

import httpx
from packaging.version import InvalidVersion, Version

from hivemind.install_marker import read_install_marker_field
from hivemind.state import PendingRestart, save_state

if TYPE_CHECKING:
    from hivemind.state import DaemonState

logger = logging.getLogger(__name__)

# The release workflow commits these manifests to wandb/homebrew-taps;
# raw.githubusercontent.com serves them without API rate limits.
DEFAULT_MANIFEST_URL = (
    "https://raw.githubusercontent.com/wandb/homebrew-taps/main/manifests/hivemind-latest.json"
)
PRERELEASE_MANIFEST_URL = (
    "https://raw.githubusercontent.com/wandb/homebrew-taps/main/manifests/hivemind-prerelease.json"
)

# Intervals (seconds). Kept as module-level constants so tests can monkey-patch.
STARTUP_DELAY_SECONDS = 5 * 60  # wait 5 min after daemon start before first poll
POLL_INTERVAL_SECONDS = 6 * 60 * 60  # 6 hours between subsequent polls
DOWNLOAD_TIMEOUT_SECONDS = 120

# Expected Team ID for the signed darwin binary. The release workflow
# signs with `Developer ID Application: Weights and Biases, Inc.` whose
# TeamIdentifier is 58UA579432. We pin this so a stolen signing cert
# for a different Team ID can't hijack the upgrade channel.
EXPECTED_TEAM_ID = "58UA579432"

# Environment variables
ENV_WATCHER_DISABLED = "HIVEMIND_UPGRADE_WATCHER_DISABLED"
# Auto-apply is opt-in: the watcher only swaps the binary if this is
# truthy. Setting it to "0" / unset / empty all leave apply OFF.
ENV_APPLY_ENABLED = "HIVEMIND_UPGRADE_APPLY_ENABLED"
ENV_MANIFEST_URL = "HIVEMIND_UPGRADE_MANIFEST_URL"


# =============================================================================
# Manifest parsing
# =============================================================================


@dataclass
class PlatformAsset:
    """Per-platform entry in the release manifest."""

    binary_url: str
    binary_sha256: str
    team_id: str | None = None


@dataclass
class ReleaseManifest:
    """Parsed upgrade manifest.

    Only the fields the watcher needs are materialized. Extra fields in
    the JSON are ignored so the manifest format can grow without
    breaking old clients.
    """

    version: str
    minimum_supported: str
    released_at: str
    rollout_percentage: int
    platforms: dict[str, PlatformAsset]

    @classmethod
    def parse(cls, data: dict[str, Any]) -> ReleaseManifest:
        platforms_raw = data.get("platforms", {}) or {}
        platforms: dict[str, PlatformAsset] = {}
        for key, entry in platforms_raw.items():
            if not isinstance(entry, dict):
                continue
            binary_url = entry.get("binary_url", "")
            binary_sha256 = entry.get("binary_sha256", "")
            if not binary_url or not binary_sha256:
                continue
            platforms[key] = PlatformAsset(
                binary_url=binary_url,
                binary_sha256=binary_sha256,
                team_id=entry.get("team_id"),
            )

        return cls(
            version=str(data.get("version", "")),
            minimum_supported=str(data.get("minimum_supported", "")),
            released_at=str(data.get("released_at", "")),
            rollout_percentage=int(data.get("rollout_percentage", 100)),
            platforms=platforms,
        )


# =============================================================================
# Version comparison
# =============================================================================


def is_newer(candidate: str, current: str) -> bool:
    """Return True if ``candidate`` is a strictly newer version than ``current``.

    Uses PEP 440 semantics via packaging.Version. If either version is
    unparseable, returns False (safer to skip than upgrade).
    """
    try:
        return Version(candidate) > Version(current)
    except (InvalidVersion, TypeError):
        return False


def current_platform_key() -> str | None:
    """Return the platforms-dict key for the current machine.

    Returns None on platforms we don't build binaries for. The watcher
    degrades to noop in that case.
    """
    system = platform.system()
    machine = platform.machine()
    if system == "Darwin" and machine == "arm64":
        return "darwin-arm64"
    if system == "Darwin" and machine == "x86_64":
        return "darwin-x86_64"
    if system == "Linux" and machine in ("aarch64", "arm64"):
        return "linux-arm64"
    if system == "Linux" and machine == "x86_64":
        return "linux-x86_64"
    return None


# =============================================================================
# Install-method detection
# =============================================================================


def _script_install_path() -> Path:
    """Path the curl|sh installer drops the binary at.

    Reads the prefix from ``$XDG_CONFIG_HOME/hivemind/install-method``
    (written by ``scripts/install.sh``) so non-default ``--prefix``
    installs are detected as ``script`` and eligible for in-place
    upgrades. Falls back to the default ``~/.local/bin/hivemind``.
    """
    marker_binary = read_install_marker_field("binary")
    if marker_binary:
        return Path(marker_binary)
    marker_prefix = read_install_marker_field("prefix")
    if marker_prefix:
        return Path(marker_prefix) / "bin" / "hivemind"
    return Path.home() / ".local" / "bin" / "hivemind"


def detect_install_method() -> str:
    """Guess which install method placed the currently-running hivemind.

    Returns one of: ``pkg``, ``brew-cask``, ``brew``, ``uv-tool``,
    ``script``, ``dev``, ``unknown``. The watcher uses this to pick an
    upgrade strategy.
    """
    raw_exe = sys.executable
    try:
        resolved_exe = str(Path(raw_exe).resolve())
    except (OSError, ValueError):
        resolved_exe = raw_exe

    # Check venv-like patterns against the UNRESOLVED path first —
    # otherwise .resolve() walks through to /opt/homebrew/... and we
    # mis-detect dev venvs and uv-tool installs as brew.
    if "/.venv/" in raw_exe or "/venv/" in raw_exe:
        return "dev"
    if "/uv/tools/" in raw_exe:
        return "uv-tool"

    # Cask: binary lives in /opt/homebrew/Caskroom/hivemind-app/. Nuitka
    # onefile extracts to a temp dir, so also check the Caskroom
    # directory directly.
    if "/Caskroom/hivemind-app/" in raw_exe or "/Caskroom/hivemind-app/" in resolved_exe:
        return "brew-cask"
    for p in ("/opt/homebrew/Caskroom/hivemind-app", "/usr/local/Caskroom/hivemind-app"):
        if Path(p).exists():
            return "brew-cask"

    # .pkg installer: stable install prefix plus a pkgutil receipt.
    # Only probe pkgutil on macOS — on Linux the binary doesn't exist
    # at all, so the subprocess call is wasted fork+exec that adds
    # startup latency for no signal.
    if raw_exe.startswith("/usr/local/hivemind/") or resolved_exe.startswith(
        "/usr/local/hivemind/"
    ):
        return "pkg"
    if platform.system() == "Darwin":
        try:
            result = subprocess.run(
                ["pkgutil", "--pkg-info", "com.wandb.hivemind"],
                capture_output=True,
                timeout=5,
            )
            if result.returncode == 0:
                return "pkg"
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

    # Brew formula: /opt/homebrew/Cellar/hivemind or /usr/local/Cellar/hivemind
    if "/Cellar/hivemind/" in raw_exe or "/Cellar/hivemind/" in resolved_exe:
        return "brew"

    # curl | sh installer: bare binary at ~/.local/bin/hivemind. Nuitka
    # onefile extracts to a temp dir, so sys.executable points there;
    # detect via filesystem instead. We check this LAST so that other
    # channels (especially uv-tool, which can shim into ~/.local/bin)
    # win when their signal is present.
    script_path = _script_install_path()
    if script_path.exists():
        return "script"

    return "unknown"


def detect_install_channel() -> str:
    """Return ``"stable"`` or ``"prerelease"`` for the running install.

    The script channel is sticky: install.sh writes a ``channel`` field
    into the install-method marker, and the watcher honors it across
    daemon restarts. Without that, a prerelease user would silently
    move back to stable on the next stable release because the watcher
    polls the default (stable) manifest. See docs/DAEMON.md and
    BREW_AUTO_UPGRADE_DESIGN.md for the rationale.

    Brew-cask channel is detected by the cask's directory name —
    ``hivemind-app-prerelease`` vs ``hivemind-app``. Other channels
    (formula / pkg / uv-tool) are stable-only today.
    """
    method = detect_install_method()
    if method == "script":
        marker_channel = read_install_marker_field("channel")
        if marker_channel == "prerelease":
            return "prerelease"
        return "stable"
    if method == "brew-cask":
        for prefix in ("/opt/homebrew/Caskroom", "/usr/local/Caskroom"):
            if Path(f"{prefix}/hivemind-app-prerelease").exists():
                return "prerelease"
        return "stable"
    return "stable"


def resolved_manifest_url() -> str:
    """Pick the right manifest URL for the running install's channel.

    Precedence: ``HIVEMIND_UPGRADE_MANIFEST_URL`` env override beats
    everything (escape hatch + tests). Otherwise the watcher follows
    the install's channel, defaulting to stable.
    """
    if env_url := os.environ.get(ENV_MANIFEST_URL):
        return env_url
    if detect_install_channel() == "prerelease":
        return PRERELEASE_MANIFEST_URL
    return DEFAULT_MANIFEST_URL


# =============================================================================
# Supervisor detection
# =============================================================================


def running_under_supervisor() -> bool:
    """True if this daemon is being supervised by launchd / systemd / brew.

    Only supervised daemons should exit-on-upgrade, because the
    supervisor is what restarts us with the new code. A foreground
    ``hivemind run`` invocation should never silently vanish out
    from under the user even if a new version is available.
    """
    # macOS: launchd is pid 1. A direct child of launchd has ppid 1.
    # ``brew services`` also bootstraps into launchd, so the same check
    # covers brew-installed daemons.
    try:
        ppid = os.getppid()
    except OSError:
        ppid = 0
    if platform.system() == "Darwin" and ppid == 1:
        return True

    # Linux systemd sets INVOCATION_ID in the service environment.
    # It's the canonical signal for "I was started by systemd".
    if os.environ.get("INVOCATION_ID"):
        return True

    return False


# =============================================================================
# Download + verification
# =============================================================================


def sha256_file(path: Path) -> str:
    """Compute the hex sha256 of a file on disk."""
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def download_binary(url: str, dest: Path) -> None:
    """Stream-download ``url`` into ``dest``.

    Raises httpx.HTTPError on network failure and OSError on disk
    failure. Caller is responsible for sha256 verification and any
    atomic-replace logic.
    """
    logger.info("Downloading %s → %s", url, dest)
    with httpx.stream("GET", url, follow_redirects=True, timeout=DOWNLOAD_TIMEOUT_SECONDS) as r:
        r.raise_for_status()
        with dest.open("wb") as f:
            for chunk in r.iter_bytes(1024 * 1024):
                f.write(chunk)


def verify_codesign_team_id(path: Path, expected_team_id: str) -> None:
    """Verify a macOS signed binary and check its Team ID.

    Calls ``codesign --verify`` then parses ``codesign -dv`` output to
    extract the ``TeamIdentifier`` field. Raises RuntimeError if any
    check fails. No-op on non-Darwin.
    """
    if platform.system() != "Darwin":
        return

    # Step 1: cryptographic verification of the signature itself.
    verify = subprocess.run(
        ["codesign", "--verify", "--verbose=2", str(path)],
        capture_output=True,
        text=True,
        timeout=30,
    )
    if verify.returncode != 0:
        raise RuntimeError(
            f"codesign --verify failed for {path}: {(verify.stderr or verify.stdout).strip()}"
        )

    # Step 2: read the signature and extract TeamIdentifier. codesign
    # writes this info to stderr, not stdout (yes, really).
    display = subprocess.run(
        ["codesign", "-dv", "--verbose=4", str(path)],
        capture_output=True,
        text=True,
        timeout=30,
    )
    blob = (display.stderr or "") + "\n" + (display.stdout or "")
    team_id: str | None = None
    for line in blob.splitlines():
        line = line.strip()
        if line.startswith("TeamIdentifier="):
            team_id = line.split("=", 1)[1].strip()
            break

    if team_id is None:
        raise RuntimeError(f"codesign output for {path} has no TeamIdentifier")
    if team_id != expected_team_id:
        raise RuntimeError(
            f"Team ID mismatch for {path}: got {team_id!r}, expected {expected_team_id!r}"
        )


def strip_quarantine(path: Path) -> None:
    """Remove ``com.apple.quarantine`` xattr from a downloaded binary.

    Since we just verified the signature + Team ID ourselves, Gatekeeper
    doesn't need to do its own online check on next launch. Stripping
    the quarantine xattr saves ~2s on cold-starts and works offline.

    No-op if the xattr isn't present or xattr isn't installed.
    """
    try:
        subprocess.run(
            ["xattr", "-d", "com.apple.quarantine", str(path)],
            capture_output=True,
            timeout=10,
            check=False,
        )
    except (FileNotFoundError, OSError):
        pass


# =============================================================================
# Upgrade strategies
# =============================================================================


@dataclass
class UpgradeResult:
    """Outcome of attempting an upgrade."""

    applied: bool
    from_version: str
    to_version: str
    method: str
    message: str = ""


class UpgradeStrategy:
    """Base strategy — per install method.

    Subclasses override ``apply()``. The default is a safe no-op: a
    machine whose install method we can't confidently handle never has
    its binary rewritten.
    """

    method: str = "noop"

    def apply(
        self,
        manifest: ReleaseManifest,
        current_version: str,
    ) -> UpgradeResult:
        return UpgradeResult(
            applied=False,
            from_version=current_version,
            to_version=manifest.version,
            method=self.method,
            message=(
                "No auto-upgrade path for this install method. "
                "Upgrade manually via your package manager or reinstall."
            ),
        )


class BinarySwapStrategy(UpgradeStrategy):
    """Atomic on-disk binary swap, used by ``brew-cask`` and ``pkg``.

    Download + verify the new signed Nuitka binary, ``os.replace`` it
    over the install path, and exit. The running process keeps its FD
    on the old file (Unix semantics) until launchd restarts us.
    """

    def __init__(self, install_path: Path, method: str) -> None:
        self.install_path = install_path
        self.method = method

    def apply(
        self,
        manifest: ReleaseManifest,
        current_version: str,
    ) -> UpgradeResult:
        platform_key = current_platform_key()
        if platform_key is None or platform_key not in manifest.platforms:
            return UpgradeResult(
                applied=False,
                from_version=current_version,
                to_version=manifest.version,
                method=self.method,
                message=f"No platform asset for {platform_key!r}",
            )

        asset = manifest.platforms[platform_key]
        # Team ID pinning: we ALWAYS enforce EXPECTED_TEAM_ID regardless
        # of what the manifest advertises. If the manifest ships a
        # team_id field, it has to match — otherwise a tampered manifest
        # could set a malicious team_id and bypass the pin. The field is
        # informational only (useful for third-party tooling that wants
        # to know what signed the build without having to read the
        # binary's CMS blob), not a configuration knob.
        if asset.team_id is not None and asset.team_id != EXPECTED_TEAM_ID:
            return UpgradeResult(
                applied=False,
                from_version=current_version,
                to_version=manifest.version,
                method=self.method,
                message=(
                    f"Manifest team_id {asset.team_id!r} does not match "
                    f"pinned Team ID {EXPECTED_TEAM_ID!r} — refusing upgrade"
                ),
            )
        expected_team = EXPECTED_TEAM_ID

        if not self.install_path.exists():
            return UpgradeResult(
                applied=False,
                from_version=current_version,
                to_version=manifest.version,
                method=self.method,
                message=f"Install path does not exist: {self.install_path}",
            )
        if not os.access(self.install_path.parent, os.W_OK):
            return UpgradeResult(
                applied=False,
                from_version=current_version,
                to_version=manifest.version,
                method=self.method,
                message=f"No write access to {self.install_path.parent}",
            )

        # Stage into a sibling file so os.replace is cross-device-safe
        # (the atomic rename only works within a filesystem).
        staging = self.install_path.with_suffix(
            self.install_path.suffix + f".upgrade-{os.getpid()}"
        )
        try:
            download_binary(asset.binary_url, staging)

            actual_sha = sha256_file(staging)
            if actual_sha != asset.binary_sha256:
                raise RuntimeError(
                    f"sha256 mismatch: got {actual_sha}, expected {asset.binary_sha256}"
                )

            staging.chmod(0o755)
            verify_codesign_team_id(staging, expected_team)
            strip_quarantine(staging)

            # Atomic-replace. The running process's open FD keeps the
            # old binary on disk (Unix semantics) until we exit.
            os.replace(staging, self.install_path)
            logger.info(
                "Staged upgrade: %s → %s at %s",
                current_version,
                manifest.version,
                self.install_path,
            )
            return UpgradeResult(
                applied=True,
                from_version=current_version,
                to_version=manifest.version,
                method=self.method,
                message=f"Replaced {self.install_path}",
            )
        except Exception as e:
            logger.warning("BinarySwap upgrade failed: %s", e)
            # Clean up staged file on failure so we don't leave junk
            # next to the real binary.
            try:
                if staging.exists():
                    staging.unlink()
            except OSError:
                pass
            return UpgradeResult(
                applied=False,
                from_version=current_version,
                to_version=manifest.version,
                method=self.method,
                message=str(e),
            )


class PipUpgradeStrategy(UpgradeStrategy):
    """Formula strategy: ``pip install --upgrade`` into the formula venv.

    The brew formula installs a Python wheel into a venv at
    ``/opt/homebrew/Cellar/hivemind/VERSION/libexec/``. That venv is
    user-owned (brew prefix is user-owned on both Apple Silicon and
    Intel). We run pip inside it to replace the wheel in place.

    Trade-off: ``brew list --versions hivemind`` will go out of sync
    with what's actually running, because brew tracks the Cellar
    directory name, not the installed wheel. On next ``brew upgrade``
    brew may reinstall the formula from scratch, possibly downgrading.
    The watcher detects "current < manifest.minimum_supported" on next
    start and re-runs the upgrade loop to catch up. Same drift problem
    the cask has — see the design doc.
    """

    method = "brew"

    def __init__(self, python_executable: Path) -> None:
        # python_executable is the venv python that the running daemon
        # itself is executing from. We reuse it for pip so we're
        # guaranteed to install into the right venv.
        self.python_executable = python_executable

    def apply(
        self,
        manifest: ReleaseManifest,
        current_version: str,
    ) -> UpgradeResult:
        # We let pip fetch wheels from PyPI over TLS. Note: pip does NOT
        # independently verify wheel hashes unless --require-hashes is
        # used; we rely on TLS transport security here. We install
        # both hivemind and agentstream to keep the version constraint
        # between them satisfied; `--no-deps` prevents pip from trying
        # to touch system-site-package deps like pydantic (which the
        # formula pulls from Homebrew separately and ships with a
        # Cellar-incompatible install_name_tool fixup on arm64).
        upgrade_cmd = [
            str(self.python_executable),
            "-m",
            "pip",
            "install",
            "--upgrade",
            "--no-deps",
            "--quiet",
            f"wandb-hivemind=={manifest.version}",
            f"wandb-agentstream=={manifest.version}",
        ]
        logger.info("Running: %s", " ".join(upgrade_cmd))
        try:
            result = subprocess.run(
                upgrade_cmd,
                capture_output=True,
                text=True,
                timeout=300,
            )
        except (FileNotFoundError, subprocess.TimeoutExpired) as e:
            return UpgradeResult(
                applied=False,
                from_version=current_version,
                to_version=manifest.version,
                method=self.method,
                message=f"pip invocation failed: {e}",
            )

        if result.returncode != 0:
            return UpgradeResult(
                applied=False,
                from_version=current_version,
                to_version=manifest.version,
                method=self.method,
                message=(result.stderr or result.stdout).strip(),
            )

        # `--no-deps` means pip will not install any new transitive deps
        # introduced in the upgrade. If a future release adds a hard
        # dependency (e.g. someone imports `aiosqlite`), the wheel
        # installs cleanly but the daemon will ImportError on next boot
        # and the supervisor will restart-loop. Run `pip check` to
        # detect the missing dep, and roll back to ``current_version``
        # so the running daemon stays on a known-good state.
        check = subprocess.run(
            [str(self.python_executable), "-m", "pip", "check"],
            capture_output=True,
            text=True,
            timeout=60,
        )
        if check.returncode != 0:
            problem = (check.stdout or check.stderr).strip()
            logger.error(
                "pip check failed after upgrade to %s — rolling back: %s",
                manifest.version,
                problem,
            )
            rollback_cmd = [
                str(self.python_executable),
                "-m",
                "pip",
                "install",
                "--no-deps",
                "--quiet",
                f"wandb-hivemind=={current_version}",
                f"wandb-agentstream=={current_version}",
            ]
            subprocess.run(rollback_cmd, capture_output=True, timeout=300)
            return UpgradeResult(
                applied=False,
                from_version=current_version,
                to_version=manifest.version,
                method=self.method,
                message=(
                    f"pip check failed after upgrade ({problem}); rolled back to {current_version}"
                ),
            )

        return UpgradeResult(
            applied=True,
            from_version=current_version,
            to_version=manifest.version,
            method=self.method,
            message=f"pip upgraded wandb-hivemind to {manifest.version}",
        )


class UvToolUpgradeStrategy(UpgradeStrategy):
    """uv-tool strategy: ``uv tool upgrade wandb-hivemind``.

    ``uv tool install`` places the daemon in its own managed venv under
    ``~/.local/share/uv/tools/wandb-hivemind/``. The corresponding
    upgrade command is a one-liner that fetches a new wheel from PyPI
    (uv verifies hashes over TLS), rebuilds the venv, and updates the
    entry-point shim at ``~/.local/bin/hivemind``.

    Like PipUpgradeStrategy, this relies on Unix semantics: the running
    process keeps its open FD on the old wheel files until it exits,
    so the upgrade can land safely while the daemon is still running.
    The watcher then signals shutdown and launchd/systemd restarts us.

    uv-tool installs don't register a launchd service automatically, so
    this strategy only makes sense on machines where the user ran
    ``hivemind install-service`` (or an equivalent) themselves.
    """

    method = "uv-tool"

    def __init__(self, uv_binary: str = "uv") -> None:
        self.uv_binary = uv_binary

    def apply(
        self,
        manifest: ReleaseManifest,
        current_version: str,
    ) -> UpgradeResult:
        cmd = [self.uv_binary, "tool", "upgrade", "wandb-hivemind"]
        logger.info("Running: %s", " ".join(cmd))
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,
            )
        except (FileNotFoundError, subprocess.TimeoutExpired) as e:
            return UpgradeResult(
                applied=False,
                from_version=current_version,
                to_version=manifest.version,
                method=self.method,
                message=f"uv invocation failed: {e}",
            )

        if result.returncode != 0:
            return UpgradeResult(
                applied=False,
                from_version=current_version,
                to_version=manifest.version,
                method=self.method,
                message=(result.stderr or result.stdout).strip(),
            )

        return UpgradeResult(
            applied=True,
            from_version=current_version,
            to_version=manifest.version,
            method=self.method,
            message=f"uv tool upgraded wandb-hivemind to {manifest.version}",
        )


def _resolve_or_self(p: Path) -> Path:
    try:
        return p.resolve(strict=False)
    except OSError:
        return p


def _find_uv_binary() -> str | None:
    """Locate the ``uv`` executable.

    Tries ``PATH`` first, then the well-known install locations where
    the rustup-style uv installer drops its binary. Returns None if
    uv isn't available — the watcher degrades to noop for uv-tool
    installs in that case.
    """
    found = shutil.which("uv")
    if found:
        return found
    for candidate in (
        Path.home() / ".local" / "bin" / "uv",
        Path("/opt/homebrew/bin/uv"),
        Path("/usr/local/bin/uv"),
    ):
        if candidate.exists():
            return str(candidate)
    return None


def choose_strategy(install_method: str) -> UpgradeStrategy:
    """Return the right strategy for a detected install method.

    Keeping the dispatch table in one place makes it easy to unit-test
    each branch in isolation and to add new channels without touching
    the watcher loop.
    """
    if install_method == "brew-cask":
        # /opt/homebrew/bin/hivemind is a symlink into the Caskroom; we
        # need the real path for os.replace. Tolerate the symlink not
        # existing (daemon running from a dev venv on a cask machine).
        for prefix in ("/opt/homebrew/bin/hivemind", "/usr/local/bin/hivemind"):
            link = Path(prefix)
            if link.exists() or link.is_symlink():
                return BinarySwapStrategy(_resolve_or_self(link), method="brew-cask")
        return UpgradeStrategy()

    if install_method == "pkg":
        return BinarySwapStrategy(
            _resolve_or_self(Path("/usr/local/hivemind/bin/hivemind")),
            method="pkg",
        )

    if install_method == "brew":
        # The venv python is sys.executable when running inside the
        # brew formula install. Use it as-is.
        return PipUpgradeStrategy(Path(sys.executable))

    if install_method == "uv-tool":
        uv_bin = _find_uv_binary()
        if uv_bin is None:
            # uv somehow vanished between install and runtime — fall
            # through to noop. Extremely unlikely but not impossible.
            strategy = UpgradeStrategy()
            strategy.method = "uv-tool"
            return strategy
        return UvToolUpgradeStrategy(uv_binary=uv_bin)

    if install_method == "script":
        # curl|sh installer puts a bare signed binary at
        # ~/.local/bin/hivemind. Atomic-replace it the same way we do
        # for the cask. On macOS the codesign Team ID check inside
        # BinarySwapStrategy.apply enforces our signing identity; on
        # Linux it's a no-op (sha256 still pinned).
        return BinarySwapStrategy(_resolve_or_self(_script_install_path()), method="script")

    # dev / unknown — no auto-apply.
    strategy = UpgradeStrategy()
    strategy.method = install_method
    return strategy


# =============================================================================
# Manifest fetch
# =============================================================================


async def fetch_manifest(url: str = DEFAULT_MANIFEST_URL) -> ReleaseManifest | None:
    """Download and parse the release manifest.

    Returns None on any failure — the watcher logs and retries next
    interval rather than crashing the daemon.
    """
    override = os.environ.get(ENV_MANIFEST_URL)
    if override:
        url = override

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.get(url)
            response.raise_for_status()
            return ReleaseManifest.parse(response.json())
    except (httpx.HTTPError, ValueError) as e:
        logger.debug("Manifest fetch failed (%s): %s", url, e)
        return None


# =============================================================================
# Watcher loop
# =============================================================================


class UpgradeWatcher:
    """Background coroutine that polls the manifest and applies upgrades.

    Owns no state beyond the passed-in references. Integration point:
    call ``await UpgradeWatcher(...).run()`` as an asyncio task from
    the daemon main loop.
    """

    def __init__(
        self,
        *,
        state: DaemonState,
        state_file: Path,
        current_version: str,
        shutdown_event: asyncio.Event,
        install_method: str,
        apply_enabled: Callable[[], bool] = lambda: False,
        # None → resolve from install channel (the right default for
        # production). Tests + CLI overrides pass an explicit URL.
        manifest_url: str | None = None,
        startup_delay: float = STARTUP_DELAY_SECONDS,
        poll_interval: float = POLL_INTERVAL_SECONDS,
    ) -> None:
        self.state = state
        self.state_file = state_file
        self.current_version = current_version
        self.shutdown_event = shutdown_event
        self.install_method = install_method
        # Callable so the daemon can re-read [daemon] auto_upgrade on
        # config reload without restarting the watcher task.
        self._apply_enabled = apply_enabled
        # Resolve the manifest URL once at construction. We deliberately
        # don't re-resolve per-poll: the install channel is set at
        # install time and shouldn't change while a daemon is running.
        # ENV_MANIFEST_URL still wins via resolved_manifest_url().
        self.manifest_url = manifest_url if manifest_url is not None else resolved_manifest_url()
        self.startup_delay = startup_delay
        self.poll_interval = poll_interval

    @classmethod
    def disabled_via_env(cls) -> bool:
        return os.environ.get(ENV_WATCHER_DISABLED, "") == "1"

    def _apply_enabled_effective(self) -> bool:
        """Env var override > config provider."""
        if os.environ.get(ENV_APPLY_ENABLED, "") == "1":
            return True
        return self._apply_enabled()

    async def run(self) -> None:
        if self.disabled_via_env():
            logger.info("Upgrade watcher disabled via %s", ENV_WATCHER_DISABLED)
            return

        logger.info(
            "Upgrade watcher started (method=%s, current=%s, poll=%ds)",
            self.install_method,
            self.current_version,
            int(self.poll_interval),
        )

        # Initial delay — avoid polling at startup when many daemons may
        # restart at once (e.g. after a machine wakes from sleep).
        try:
            await asyncio.wait_for(
                self.shutdown_event.wait(),
                timeout=self.startup_delay,
            )
            return
        except asyncio.TimeoutError:
            pass

        while not self.shutdown_event.is_set():
            try:
                await self._check_once()
            except Exception as e:  # defensive: watcher must not crash the daemon
                logger.warning("Upgrade check raised: %s", e, exc_info=True)

            if self.shutdown_event.is_set():
                return

            try:
                await asyncio.wait_for(
                    self.shutdown_event.wait(),
                    timeout=self.poll_interval,
                )
                return
            except asyncio.TimeoutError:
                continue

    async def _check_once(self) -> None:
        """Fetch the manifest, compare versions, apply if newer."""
        manifest = await fetch_manifest(self.manifest_url)
        if manifest is None:
            return
        if not manifest.version:
            logger.debug("Manifest has no version, skipping")
            return

        if not is_newer(manifest.version, self.current_version):
            logger.debug(
                "Upgrade watcher: no upgrade (manifest=%s, current=%s)",
                manifest.version,
                self.current_version,
            )
            return

        logger.info(
            "Upgrade available: %s → %s (method=%s)",
            self.current_version,
            manifest.version,
            self.install_method,
        )

        if not self._apply_enabled_effective():
            logger.info(
                "Upgrade %s available but auto-apply is off — set "
                '[daemon] auto_upgrade = "apply" (or %s=1) to enable, or '
                "run the install command for your channel manually",
                manifest.version,
                ENV_APPLY_ENABLED,
            )
            return

        strategy = choose_strategy(self.install_method)
        result = await asyncio.to_thread(strategy.apply, manifest, self.current_version)

        if not result.applied:
            logger.warning(
                "Upgrade did not apply (%s → %s, method=%s): %s",
                result.from_version,
                result.to_version,
                result.method,
                result.message,
            )
            return

        logger.info(
            "Upgrade applied: %s → %s via %s. %s",
            result.from_version,
            result.to_version,
            result.method,
            result.message,
        )

        self._mark_pending_restart(result)

        if running_under_supervisor():
            logger.info("Running under supervisor — signalling clean exit for restart")
            self.shutdown_event.set()
        else:
            logger.info(
                "Not running under a supervisor — new binary is staged, "
                "but the daemon will not auto-restart. Please run `hivemind restart`."
            )

    def _mark_pending_restart(self, result: UpgradeResult) -> None:
        """Persist a PendingRestart marker so the next boot can log it."""
        self.state.pending_restart = PendingRestart(
            from_version=result.from_version,
            to_version=result.to_version,
            applied_at=int(time.time()),
            method=result.method,
            reason=result.message,
        )
        try:
            save_state(self.state, self.state_file)
        except Exception as e:
            # Non-fatal: the apply already succeeded; losing the marker
            # just means we won't log the pretty "restarted after
            # upgrade" line on next boot.
            logger.debug("Failed to persist pending_restart: %s", e)
