"""
Main validate function - entry point for EDI validation.
"""

from pathlib import Path
from validedi.engine.models import ValidationResult
from validedi.engine.parser import parse
from validedi.engine.config_loader import get_config
from validedi.engine.rule_executor import RuleExecutor


def validate(source: str | Path) -> ValidationResult:
    """
    Parse and validate EDI file or string.
    
    Args:
        source: Either a file path (str/Path) or raw EDI string
                - If it's a valid file path, reads the file
                - Otherwise treats it as raw EDI content
        
    Returns:
        ValidationResult with parsed data and validation errors
        
    Raises:
        EDIParseError: If EDI cannot be parsed
        UnsupportedTransactionError: If transaction type not supported
        FileNotFoundError: If file path doesn't exist
    
    Examples:
        # Validate from file
        result = validate('claim.edi')
        result = validate('/path/to/file.edi')
        result = validate(Path('claim.edi'))
        
        # Validate from string
        result = validate('ISA*00*...')
    """
    # Parse the EDI (handles both file and string)
    parsed = parse(source)
    
    # Load configuration
    config = get_config(parsed.envelope.transaction_type)
    
    # Execute validation rules
    executor = RuleExecutor(config)
    errors = executor.execute_all(parsed.loops)
    
    return ValidationResult(
        parsed=parsed,
        errors=errors
    )
