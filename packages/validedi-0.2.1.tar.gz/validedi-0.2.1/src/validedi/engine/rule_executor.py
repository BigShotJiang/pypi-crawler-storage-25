"""
Rule executor - dispatches and executes validation rules.
"""

import re
from typing import Any
from validedi.engine.models import Loop, ValidationError
from validedi.engine.config_loader import TransactionConfig, RuleConfig
from validedi.handlers import BUILTIN_HANDLERS


class RuleExecutor:
    """Executes validation rules against parsed EDI data."""
    
    def __init__(self, config: TransactionConfig):
        self.config = config
        self._regex_cache: dict[str, re.Pattern] = {}
    
    def execute_all(self, loops: list[Loop]) -> list[ValidationError]:
        """
        Execute all validation rules against loop hierarchy.
        
        Args:
            loops: Top-level loops from parsed EDI
            
        Returns:
            List of all validation errors found
        """
        errors: list[ValidationError] = []
        
        # Execute rules for each loop recursively
        for loop in loops:
            errors.extend(self._execute_loop_rules(loop))
        
        # Execute transaction-scope rules
        errors.extend(self._execute_transaction_rules(loops))
        
        return errors
    
    def _execute_loop_rules(self, loop: Loop) -> list[ValidationError]:
        """Execute rules for a specific loop and its children."""
        errors: list[ValidationError] = []
        
        # Find rules for this loop
        loop_rules = self._get_rules_for_loop(loop.loop_id)
        
        for rule in loop_rules:
            errors.extend(self._execute_rule(rule, loop))
        
        # Recursively process children
        for child in loop.children:
            errors.extend(self._execute_loop_rules(child))
        
        return errors
    
    def _execute_transaction_rules(self, loops: list[Loop]) -> list[ValidationError]:
        """Execute transaction-scope rules."""
        errors: list[ValidationError] = []
        
        for rule_id, rule in self.config.rules.items():
            if rule.scope == 'transaction':
                if rule.type == 'builtin' and rule.handler:
                    handler = BUILTIN_HANDLERS.get(rule.handler)
                    if handler:
                        try:
                            result = handler(loops)
                            if isinstance(result, list):
                                errors.extend(result)
                        except Exception as e:
                            # Log error but don't fail validation
                            pass
        
        return errors

    
    def _get_rules_for_loop(self, loop_id: str) -> list[RuleConfig]:
        """Get all rules that apply to a specific loop."""
        rules = []
        for rule_id, rule in self.config.rules.items():
            if rule.loop == loop_id or (not rule.loop and not rule.scope):
                rules.append(rule)
        return rules
    
    def _execute_rule(self, rule: RuleConfig, context: Loop) -> list[ValidationError]:
        """Execute a single rule in the given context."""
        if rule.type == 'regex':
            return self._execute_regex_rule(rule, context)
        elif rule.type == 'code_set':
            return self._execute_code_set_rule(rule, context)
        elif rule.type == 'composite_code_set':
            return self._execute_composite_code_set_rule(rule, context)
        elif rule.type == 'expression':
            return self._execute_expression_rule(rule, context)
        elif rule.type == 'builtin':
            return self._execute_builtin_rule(rule, context)
        return []
    
    def _execute_regex_rule(self, rule: RuleConfig, context: Loop) -> list[ValidationError]:
        """Execute a regex validation rule."""
        errors = []
        
        if not rule.pattern or not rule.target:
            return errors
        
        # Get or compile regex pattern
        if rule.id not in self._regex_cache:
            self._regex_cache[rule.id] = re.compile(rule.pattern)
        pattern = self._regex_cache[rule.id]
        
        # Extract target value
        value = self._extract_target_value(rule.target, context)
        if value is None:
            return errors
        
        # Test pattern
        if not pattern.match(value):
            segment_id, element_num = self._parse_target(rule.target)
            segment = context.find_segment(segment_id) if segment_id else None
            
            errors.append(ValidationError(
                code=rule.id,
                severity=rule.severity,
                segment=segment_id or 'UNKNOWN',
                element=rule.target,
                loop=context.loop_id,
                position=segment.position if segment else 0,
                message=rule.message.format(value=value)
            ))
        
        return errors
    
    def _execute_code_set_rule(self, rule: RuleConfig, context: Loop) -> list[ValidationError]:
        """Execute a code set validation rule."""
        errors = []
        
        if not rule.code_set_id or not rule.target:
            return errors
        
        # Get code set
        code_set = self.config.code_sets.get(rule.code_set_id)
        if not code_set:
            return errors
        
        # Extract target value
        value = self._extract_target_value(rule.target, context)
        if value is None:
            return errors
        
        # Check membership
        if value not in code_set:
            segment_id, element_num = self._parse_target(rule.target)
            segment = context.find_segment(segment_id) if segment_id else None
            
            errors.append(ValidationError(
                code=rule.id,
                severity=rule.severity,
                segment=segment_id or 'UNKNOWN',
                element=rule.target,
                loop=context.loop_id,
                position=segment.position if segment else 0,
                message=rule.message.format(value=value)
            ))
        
        return errors
    
    def _execute_composite_code_set_rule(self, rule: RuleConfig, context: Loop) -> list[ValidationError]:
        """
        Execute a composite code set validation rule.
        Extracts a specific component from a composite element before validating.
        
        Example: CLM05 = "11:B:1" with component=1 extracts "11" for validation
        """
        errors = []
        
        if not rule.code_set_id or not rule.target:
            return errors
        
        # Get code set
        code_set = self.config.code_sets.get(rule.code_set_id)
        if not code_set:
            return errors
        
        # Extract target element (not just value)
        segment_id, element_num = self._parse_target(rule.target)
        if not segment_id or not element_num:
            return errors
        
        segment = context.find_segment(segment_id)
        if not segment:
            return errors
        
        element = segment.get(element_num)
        if not element.raw:
            return errors
        
        # Extract component (default to first component)
        component_index = getattr(rule, 'component', 1)
        
        # If element has components, extract the specified one
        if element.components:
            value = element.get(component_index)
        else:
            # No components - use raw value (might be simple element)
            value = element.raw
        
        if not value:
            return errors
        
        # Check membership in code set
        if value not in code_set:
            errors.append(ValidationError(
                code=rule.id,
                severity=rule.severity,
                segment=segment_id,
                element=rule.target,
                loop=context.loop_id,
                position=segment.position,
                message=rule.message.format(value=element.raw)  # Show full composite in message
            ))
        
        return errors
    
    def _execute_expression_rule(self, rule: RuleConfig, context: Loop) -> list[ValidationError]:
        """Execute an expression validation rule."""
        # Simplified expression evaluation - would need full implementation
        return []
    
    def _execute_builtin_rule(self, rule: RuleConfig, context: Loop) -> list[ValidationError]:
        """Execute a builtin handler rule."""
        errors = []
        
        if not rule.handler:
            return errors
        
        handler = BUILTIN_HANDLERS.get(rule.handler)
        if not handler:
            return errors
        
        try:
            if rule.target:
                # Single-value handler
                value = self._extract_target_value(rule.target, context)
                if value is not None:
                    result = handler(value)
                    if isinstance(result, bool) and not result:
                        segment_id, _ = self._parse_target(rule.target)
                        segment = context.find_segment(segment_id) if segment_id else None
                        errors.append(ValidationError(
                            code=rule.id,
                            severity=rule.severity,
                            segment=segment_id or 'UNKNOWN',
                            element=rule.target,
                            loop=context.loop_id,
                            position=segment.position if segment else 0,
                            message=rule.message.format(value=value)
                        ))
            else:
                # Context handler (takes Loop)
                result = handler(context)
                if isinstance(result, list):
                    errors.extend(result)
        except Exception as e:
            # Log but don't fail validation
            pass
        
        return errors
    
    def _extract_target_value(self, target: str, context: Loop) -> str | None:
        """Extract value from target specification (e.g., 'NM109', 'CLM02')."""
        segment_id, element_num = self._parse_target(target)
        if not segment_id:
            return None
        
        segment = context.find_segment(segment_id)
        if not segment:
            return None
        
        if element_num:
            return segment.get_value(element_num)
        
        return None
    
    def _parse_target(self, target: str) -> tuple[str | None, int | None]:
        """Parse target like 'NM109' into ('NM1', 9)."""
        if not target:
            return None, None
        
        # Extract segment ID (letters) and element number (digits)
        segment_id = ''
        element_str = ''
        
        for char in target:
            if char.isalpha():
                segment_id += char
            elif char.isdigit():
                element_str += char
        
        element_num = int(element_str) if element_str else None
        
        return segment_id or None, element_num
