"""
ValidEDI - X12 EDI Parser and Validator

A library-first approach to parsing and validating healthcare EDI transactions.
Supports 837P, 837I, 835, and 834 transaction types.

Features:
- Parse and validate EDI files
- YAML-driven configuration
- LLM-powered explanations (bring your own LLM)
- Plain-English error messages
"""

from validedi.engine.models import (
    ParsedEDI,
    ValidationResult,
    ValidationError,
    EnvelopeMeta,
    Loop,
    Segment,
    Element,
)
from validedi.utils.exceptions import (
    ValidEDIError,
    EDIParseError,
    EDIValidationError,
    UnsupportedTransactionError,
    BadConfigError,
)

# Import core functions
from validedi.engine.parser import parse
from validedi.engine.validator import validate

__version__ = "0.1.0"

__all__ = [
    # Core functions
    "parse",
    "validate",
    # Models
    "ParsedEDI",
    "ValidationResult",
    "ValidationError",
    "EnvelopeMeta",
    "Loop",
    "Segment",
    "Element",
    # Exceptions
    "ValidEDIError",
    "EDIParseError",
    "EDIValidationError",
    "UnsupportedTransactionError",
    "BadConfigError",
]

# LLM module is available as validedi.llm
# from validedi.llm import explain, ask_followup
