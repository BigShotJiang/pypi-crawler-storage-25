"""
ValidEDI LLM Integration
========================

LLM-powered explanations and Q&A for EDI validation results.

Usage:
    from validedi import parse, validate
    from validedi.llm import explain, ask_followup
    
    # Define your LLM function (any provider)
    def my_llm(prompt: str) -> str:
        # Your LLM implementation
        return response
    
    # Parse and validate
    edi_result = parse("file.edi")
    val_result = validate(edi_result)
    
    # Get explanation
    explanation = explain(edi_result, val_result, llm=my_llm)
    print(explanation.report)
    
    # Ask follow-up questions
    answer = ask_followup("What is the total billed?", edi_result, val_result, llm=my_llm)
    print(answer)
"""

from .explainer import LLMExplainer, ExplainResult, explain, ask_followup

__all__ = ['LLMExplainer', 'ExplainResult', 'explain', 'ask_followup']
