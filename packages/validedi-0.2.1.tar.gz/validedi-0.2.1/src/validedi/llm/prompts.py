"""
Prompt templates and builders for LLM explanations.
"""

from typing import Any


def build_explanation_prompt(edi_result: Any, val_result: Any) -> str:
    """
    Build a prompt for generating a plain-English EDI explanation.
    
    Args:
        edi_result: Parsed EDI result from parser
        val_result: Validation result from validator
        
    Returns:
        Formatted prompt string for LLM
    """
    tx = edi_result.transaction_type
    parsed = edi_result.parsed

    # Build validation issues summary
    if val_result.issues:
        issue_lines = [
            f"  [{i.level.upper()}] {i.code} — {i.segment_id}: {i.message}"
            for i in val_result.issues[:15]
        ]
        issues_text = "\n".join(issue_lines)
    else:
        issues_text = "  No issues found."

    # Extract key facts
    facts = extract_key_facts(tx, parsed)

    return f"""You are a healthcare EDI specialist. Convert the following parsed X12 {tx} EDI data into a clear, plain-English report suitable for a non-technical healthcare billing professional.

TRANSACTION TYPE: {tx} — {edi_result.subtype}
SENDER: {edi_result.sender_id}
RECEIVER: {edi_result.receiver_id}
MODE: {edi_result.test_indicator}
VERSION: {edi_result.version}

KEY DATA:
{facts}

VALIDATION RESULTS:
{val_result.summary}
{issues_text}

Write a structured report with these sections:
1. OVERVIEW — What this EDI file is and its purpose (2-3 sentences)
2. KEY PARTIES — Who is sending, receiving, billing, paying
3. FINANCIAL SUMMARY — Amounts, dates, claim counts (use bullet points)
4. VALIDATION STATUS — Plain-language explanation of any errors or warnings and exactly how to fix them
5. ACTION ITEMS — What the recipient should do next (numbered list)

Use plain English. Avoid raw EDI codes where possible. When you must use codes, explain them in parentheses.
Be concise but complete. Format numbers as currency where appropriate."""


def build_qa_prompt(question: str, edi_result: Any, val_result: Any) -> str:
    """
    Build a prompt for answering follow-up questions about the EDI file.
    
    Args:
        question: User's question
        edi_result: Parsed EDI result
        val_result: Validation result
        
    Returns:
        Formatted prompt string for LLM
    """
    context = extract_key_facts(edi_result.transaction_type, edi_result.parsed)
    issues_brief = "; ".join(f"{i.code}: {i.message}" for i in val_result.issues[:8])

    return f"""You are a healthcare EDI expert. Answer the user's question about their {edi_result.transaction_type} EDI file.

FILE CONTEXT:
{context}

VALIDATION: {val_result.summary}
ISSUES: {issues_brief if issues_brief else "None"}

USER QUESTION: {question}

Answer concisely in plain English. Be specific and actionable."""


def extract_key_facts(tx: str, parsed: dict) -> str:
    """
    Extract key facts from parsed EDI data based on transaction type.
    
    Args:
        tx: Transaction type (837P, 837I, 835, 834)
        parsed: Parsed EDI data dictionary
        
    Returns:
        Formatted string with key facts
    """
    lines = []

    if tx.startswith("837"):
        # 837 Professional/Institutional Claims
        bh = parsed.get("transaction_purpose", {})
        if bh:
            lines.append(f"• Transaction Purpose: {bh.get('purpose', '')} — {bh.get('transaction_type', '')}")
            lines.append(f"• Submission Date: {bh.get('date', '')}")
        
        sub = parsed.get("submitter", {})
        if sub:
            lines.append(f"• Submitter: {sub.get('name', '')} (ID: {sub.get('id', '')})")
        
        bp = parsed.get("billing_provider", {})
        if bp:
            lines.append(f"• Billing Provider: {bp.get('name', '')} (NPI: {bp.get('id', '')})")
        
        claims = parsed.get("claims", [])
        lines.append(f"• Total Claims: {len(claims)}")
        
        # Calculate total billed
        total = sum(
            float(c.get("total_charge", "$0").replace("$", "").replace(",", ""))
            for c in claims
        )
        lines.append(f"• Total Billed Amount: ${total:,.2f}")
        
        # Show first 3 claims
        for i, claim in enumerate(claims[:3], 1):
            lines.append(f"\nCLAIM #{i}: {claim.get('claim_id', '')}")
            lines.append(f"  Charge: {claim.get('total_charge', '')}")
            diags = claim.get("diagnosis_codes", [])
            if diags:
                lines.append(f"  Diagnoses: {', '.join(d['code'] for d in diags[:3])}")

    elif tx == "835":
        # 835 Remittance Advice
        fi = parsed.get("financial_info", {})
        if fi:
            lines.append(f"• Total Payment: {fi.get('total_payment_amount', '')}")
            lines.append(f"• Payment Method: {fi.get('payment_method', '')}")
            lines.append(f"• Payment Date: {fi.get('check_eft_date', '')}")
        
        payer = parsed.get("payer", {})
        payee = parsed.get("payee", {})
        if payer:
            lines.append(f"• Payer: {payer.get('name', '')}")
        if payee:
            lines.append(f"• Payee/Provider: {payee.get('name', '')}")
        
        claims = parsed.get("claim_payments", [])
        lines.append(f"• Claims in Remittance: {len(claims)}")

    elif tx == "834":
        # 834 Benefit Enrollment
        lines.append(f"• Transaction Purpose: {parsed.get('transaction_purpose', '')}")
        lines.append(f"• Effective Date: {parsed.get('effective_date', '')}")
        
        sponsor = parsed.get("sponsor", {})
        payer = parsed.get("payer", {})
        if sponsor:
            lines.append(f"• Plan Sponsor: {sponsor.get('name', '')}")
        if payer:
            lines.append(f"• Insurance Carrier: {payer.get('name', '')}")
        
        members = parsed.get("members", [])
        lines.append(f"• Total Members: {len(members)}")

    return "\n".join(lines) if lines else "No structured data extracted."
