"""Inventory search (Phase 6.3).

This service searches an external catalog (starting with Mouser) for candidates
that could fill gaps in an inventory file.

Design goals:
- No file I/O (CLI handles reading/writing)
- Deterministic, testable behavior
- No API calls required in unit tests (provider can be mocked)
"""

from __future__ import annotations

import re
import sys
import time
from collections import defaultdict
from dataclasses import dataclass

from jbom.common.component_classification import normalize_component_type
from jbom.common.types import Component, InventoryItem
from jbom.common.value_parsing import farad_to_eia, henry_to_eia, ohms_to_eia
from jbom.config.defaults import DefaultsConfig, get_defaults
from jbom.config.fabricators import FabricatorConfig
from jbom.config.suppliers import resolve_supplier_by_id
from jbom.services.search.cache import normalize_query
from jbom.services.search.filtering import SearchSorter, apply_default_filters
from jbom.services.search.models import SearchResult
from jbom.services.search.provider import SearchProvider
from jbom.services.search.query_shaping import (
    expand_led_color_token,
    normalize_ascii_token,
    shape_search_query,
)
from jbom.services.sophisticated_inventory_matcher import (
    MatchingOptions,
    SophisticatedInventoryMatcher,
)


@dataclass(frozen=True)
class InventorySearchCandidate:
    """One scored candidate for an inventory item."""

    result: SearchResult
    match_score: int


@dataclass(frozen=True)
class InventorySearchRecord:
    """Search outcomes for one inventory item."""

    inventory_item: InventoryItem
    query: str
    candidates: list[InventorySearchCandidate]
    error: str | None = None


def _normalize_ascii_value(text: str) -> str:
    """Normalize value strings to ASCII-friendly equivalents."""
    return normalize_ascii_token(text)


def _category_token(category: str) -> str:
    """Return a normalized category token usable for comparisons."""

    return normalize_component_type(category or "")


def _category_matches(item_category: str, selector: str) -> bool:
    """Return True if an inventory category matches a selector token."""

    cat = (item_category or "").strip().upper()
    sel = (selector or "").strip().upper()
    if not cat or not sel:
        return False

    return cat == sel or cat.startswith(sel) or (sel in cat)


class InventorySearchService:
    """Service that searches external catalogs for inventory backfill candidates."""

    @staticmethod
    def is_sparse_for_fabricator(
        item: InventoryItem, fabricator: FabricatorConfig
    ) -> bool:
        """Return True if item has no SPN for any supplier in fabricator.suppliers.

        Sparseness is defined relative to the fabricator's ordered supplier list.
        An item is considered non-sparse when its ``supplier`` field matches any
        fabricator supplier AND its ``spn`` is non-empty.
        """

        if not fabricator.suppliers:
            return False

        item_supplier = (item.supplier or "").strip().lower()
        item_spn = (item.spn or "").strip()

        if not item_spn:
            # No SPN at all — definitely sparse regardless of supplier list.
            return True

        for supplier_id in fabricator.suppliers:
            supplier = resolve_supplier_by_id(supplier_id)
            if supplier is None:
                continue
            if (
                item_supplier == supplier.id
                or item_supplier == supplier.supplier_label.lower()
            ):
                return False  # Has SPN for a known fabricator supplier

        return True

    @staticmethod
    def filter_sparse_items_for_fabricator(
        items: list[InventoryItem], *, fabricator: FabricatorConfig
    ) -> list[InventoryItem]:
        """Filter to items that are sparse for this fabricator."""

        return [
            i
            for i in items
            if InventorySearchService.is_sparse_for_fabricator(i, fabricator)
        ]

    @staticmethod
    def split_rows_by_type(
        items: list[InventoryItem],
    ) -> tuple[list[InventoryItem], list[InventoryItem]]:
        """Return (component_rows, item_rows) based on RowType."""
        component_rows: list[InventoryItem] = []
        item_rows: list[InventoryItem] = []
        for item in items:
            row_type = (item.row_type or "ITEM").strip().upper()
            if row_type == "COMPONENT":
                component_rows.append(item)
            else:
                item_rows.append(item)
        return component_rows, item_rows

    @staticmethod
    def row_identity(item: InventoryItem) -> str:
        """Return stable row identity for record mapping across mixed row types."""
        row_type = (item.row_type or "ITEM").strip().upper()
        if row_type == "COMPONENT":
            component_id = (item.component_id or "").strip()
            if component_id:
                return f"COMPONENT:{component_id}"
            return f"COMPONENT_UUID:{(item.uuid or '').strip()}"
        return f"ITEM:{(item.ipn or '').strip()}"

    def __init__(
        self,
        provider: SearchProvider,
        *,
        candidate_limit: int = 3,
        request_delay_seconds: float = 0.0,
        defaults: DefaultsConfig | None = None,
        verbose: bool = False,
    ) -> None:
        self._provider = provider
        self._candidate_limit = max(1, int(candidate_limit))
        self._request_delay_seconds = max(0.0, float(request_delay_seconds))
        self._matcher = SophisticatedInventoryMatcher(MatchingOptions())
        self._verbose = verbose
        # Load defaults once at construction time (injectable for tests / library users).
        self._defaults: DefaultsConfig = (
            defaults if defaults is not None else get_defaults()
        )
        # Build merged category→keyword map once: generic baseline + supplier override.
        self._type_query_keywords: dict[str, str] = self._build_type_query_keywords()

    def _build_type_query_keywords(self) -> dict[str, str]:
        """Build merged category→keyword map: generic supplier baseline + specific override."""

        generic = resolve_supplier_by_id("generic")
        specific = resolve_supplier_by_id(self._provider.provider_id)
        base: dict[str, str] = dict(
            (generic.search_type_query_keywords if generic else {}) or {}
        )
        override: dict[str, str] = dict(
            (specific.search_type_query_keywords if specific else {}) or {}
        )
        return {**base, **override}

    @staticmethod
    def filter_searchable_items(
        items: list[InventoryItem],
        *,
        categories: str | None,
        defaults: DefaultsConfig | None = None,
    ) -> list[InventoryItem]:
        """Filter to items suitable for catalog search.

        Uses a denylist model: all categories pass unless explicitly excluded in
        the defaults profile (``search_excluded_categories``).
        When ``categories`` is provided it acts as an explicit allowlist selector,
        restricting results to only those matched categories.

        Pure logic — no provider or network access required.
        Safe to call without instantiating the service (e.g. dry-run mode).
        """

        cfg = defaults if defaults is not None else get_defaults()
        excluded = cfg.get_search_excluded_categories()

        selectors: set[str] | None
        if categories:
            selectors = {
                _category_token(t) for t in re.split(r"[\s,]+", categories) if t.strip()
            }
        else:
            selectors = None  # denylist-only: every non-excluded category is searchable

        out: list[InventoryItem] = []
        for item in items:
            cat_raw = (item.category or "").strip()
            if not cat_raw:
                continue

            cat_norm = _category_token(cat_raw)
            if cat_norm in excluded:
                continue

            min_value_len = 1 if cat_norm == "LED" else 2
            if not item.value or len(str(item.value).strip()) < min_value_len:
                continue

            if selectors is not None and not any(
                _category_matches(cat_raw, s) for s in selectors
            ):
                continue

            out.append(item)

        return out

    def build_query(self, item: InventoryItem) -> str:
        """Build a provider-friendly keyword query string.

        Primary value token selection:
        - Passives (RES/CAP/IND): use the typed numeric field formatted back to an
          EIA string for consistent, normalised search terms.  Falls back to the
          raw Value string when the typed field is absent.
        - LEDs: normalize color shorthand before query shaping.
        - Non-passives: prefer the Name field (e.g. 'LM358D', 'AMS1117-3.3');
          fall back to Value when Name is empty.
        """

        parts: list[str] = []

        cat = _category_token(item.category)

        # Determine the primary value token.
        if cat == "RES" and item.resistance is not None:
            value_token = ohms_to_eia(item.resistance)
        elif cat == "CAP" and item.capacitance is not None:
            value_token = farad_to_eia(item.capacitance)
        elif cat == "IND" and item.inductance is not None:
            value_token = henry_to_eia(item.inductance)
        elif cat in ("RES", "CAP", "IND"):
            # Typed field absent — fall back to raw value string.
            value_token = _normalize_ascii_value(item.value)
        elif cat == "LED":
            value_token = expand_led_color_token(item.value)
            if not value_token and item.name:
                value_token = _normalize_ascii_value(item.name)
        elif item.name:
            # Non-passive with an explicit component name.
            value_token = item.name
        else:
            value_token = _normalize_ascii_value(item.value)

        if value_token:
            parts.append(value_token)

        if cat in self._type_query_keywords:
            parts.append(self._type_query_keywords[cat])

        if item.package:
            parts.append(_normalize_ascii_value(item.package))

        if (
            item.tolerance
            and item.tolerance.strip()
            and item.tolerance.strip().upper() != "N/A"
        ):
            parts.append(_normalize_ascii_value(item.tolerance))

        raw_query = " ".join(p for p in parts if p).strip()
        return shape_search_query(raw_query, category=cat, package=item.package)

    def search(self, items: list[InventoryItem]) -> list[InventorySearchRecord]:
        """Search for candidates for each inventory item.

        Deduplicates provider calls by normalized query so repeated inventory rows
        do not burn additional API quota.

        Issue #106 routing:
        - When the provider is LCSC (JlcpcbProvider) and the inventory item has an
          explicit MPN (`InventoryItem.mfgpn`), attempt a deterministic MPN lookup
          first (MPN → best available LCSC C-number).
        - If the lookup returns a match, emit it as Candidate 1 and skip catalog
          search for that item.
        - If no match is found, fall back to the existing keyword-based search.
        """

        if not items:
            return []

        deterministic_score = 1000

        records_by_index: list[InventorySearchRecord | None] = [None] * len(items)
        remaining_items: list[InventoryItem] = []
        remaining_indices: list[int] = []

        # Group MPN lookups to avoid redundant API calls.
        mpn_groups: dict[str, tuple[str, str, list[int]]] = {}

        for idx, item in enumerate(items):
            mpn = (item.mfgpn or "").strip()
            if not mpn:
                remaining_items.append(item)
                remaining_indices.append(idx)
                continue

            mfg = (item.manufacturer or "").strip()
            key = normalize_query(f"mpn:{mpn} manufacturer:{mfg}")
            if key not in mpn_groups:
                mpn_groups[key] = (mfg, mpn, [])
            mpn_groups[key][2].append(idx)  # type: ignore[index]

        # Resolve each unique (manufacturer, mpn) once.
        mpn_results: dict[str, SearchResult | None] = {}
        mpn_errors: dict[str, str] = {}

        n_mpn_groups = len(mpn_groups)
        for i, (key, (mfg, mpn, _indices)) in enumerate(mpn_groups.items(), 1):
            if self._verbose:
                label = f"{mfg} {mpn}".strip() or mpn
                print(
                    f"  [MPN lookup {i}/{n_mpn_groups}] {label}",
                    file=sys.stderr,
                )
            try:
                mpn_results[key] = self._provider.lookup_by_mpn(mfg, mpn)
            except Exception as exc:
                mpn_errors[key] = str(exc)

            if self._request_delay_seconds > 0:
                time.sleep(self._request_delay_seconds)

        # Fan out deterministic matches; queue misses for fallback.
        for key, (mfg, mpn, indices) in mpn_groups.items():
            query = f"{mfg} {mpn}".strip()

            if key in mpn_errors:
                for idx in indices:
                    records_by_index[idx] = InventorySearchRecord(
                        inventory_item=items[idx],
                        query=query,
                        candidates=[],
                        error=mpn_errors[key],
                    )
                continue

            res = mpn_results.get(key)
            if res is not None:
                for idx in indices:
                    records_by_index[idx] = InventorySearchRecord(
                        inventory_item=items[idx],
                        query=query,
                        candidates=[
                            InventorySearchCandidate(
                                result=res, match_score=deterministic_score
                            )
                        ],
                    )
                continue

            # Miss: fall back to keyword-based search.
            for idx in indices:
                remaining_items.append(items[idx])
                remaining_indices.append(idx)

        keyword_records: list[InventorySearchRecord] = []
        if remaining_items:
            keyword_records = self._search_by_keyword(remaining_items)

        for idx, rec in zip(remaining_indices, keyword_records, strict=True):
            records_by_index[idx] = rec

        # Preserve input ordering.
        out: list[InventorySearchRecord] = []
        for rec in records_by_index:
            if rec is not None:
                out.append(rec)
        return out

    def _search_by_keyword(
        self, items: list[InventoryItem]
    ) -> list[InventorySearchRecord]:
        """Original keyword-based search implementation (Phase 6.3)."""

        # Phase 6.3 behavior: limit is purely service configuration.
        provider_limit = max(10, self._candidate_limit * 3)

        query_groups: dict[str, list[tuple[InventoryItem, str]]] = defaultdict(list)
        per_item_query: list[tuple[InventoryItem, str, str]] = []

        for item in items:
            query = self.build_query(item)
            key = normalize_query(query)
            per_item_query.append((item, query, key))

            if query:
                query_groups[key].append((item, query))

        # Dispatch unique queries.
        ranked_by_query: dict[str, list[SearchResult]] = {}
        error_by_query: dict[str, str] = {}

        n_queries = len(query_groups)
        for i, (key, group) in enumerate(query_groups.items(), 1):
            # Keep the original (non-normalized) query string for the provider call.
            provider_query = group[0][1]
            representative_item = group[0][0]

            if self._verbose:
                print(
                    f"  [keyword search {i}/{n_queries}] {provider_query!r}",
                    file=sys.stderr,
                )

            try:
                raw_results = self._provider.search_for_item(
                    representative_item,
                    query=provider_query,
                    limit=provider_limit,
                )
                filtered = apply_default_filters(raw_results)
                ranked_by_query[key] = SearchSorter.rank(filtered)
            except Exception as exc:
                error_by_query[key] = str(exc)

            # Be conservative with public APIs (configurable for tests).
            if self._request_delay_seconds > 0:
                time.sleep(self._request_delay_seconds)

        # Fan-out per-item scoring.
        records: list[InventorySearchRecord] = []
        for item, query, key in per_item_query:
            if not query:
                records.append(
                    InventorySearchRecord(
                        inventory_item=item,
                        query=query,
                        candidates=[],
                        error="empty query",
                    )
                )
                continue

            if key in error_by_query:
                records.append(
                    InventorySearchRecord(
                        inventory_item=item,
                        query=query,
                        candidates=[],
                        error=error_by_query[key],
                    )
                )
                continue

            ranked = ranked_by_query.get(key, [])
            candidates = self._score_candidates(item, ranked)
            records.append(
                InventorySearchRecord(
                    inventory_item=item,
                    query=query,
                    candidates=candidates[: self._candidate_limit],
                )
            )

        return records

    def _score_candidates(
        self, base_item: InventoryItem, results: list[SearchResult]
    ) -> list[InventorySearchCandidate]:
        comp = self._inventory_item_to_component(base_item)

        scored: list[InventorySearchCandidate] = []
        for r in results:
            candidate_item = self._search_result_to_inventory_item(r, base_item)
            matches = self._matcher.find_matches(comp, [candidate_item])
            score = matches[0].score if matches else 0
            if score <= 0:
                continue
            scored.append(InventorySearchCandidate(result=r, match_score=score))

        scored.sort(
            key=lambda c: (
                -c.match_score,
                -c.result.stock_quantity,
                _price_to_float(c.result.price),
            )
        )
        return scored

    @staticmethod
    def _inventory_item_to_component(item: InventoryItem) -> Component:
        cat = _category_token(item.category)
        # Choose a lib_id that makes get_component_type return the correct type.
        lib_id_map = {
            "RES": "Device:R",
            "CAP": "Device:C",
            "IND": "Device:L",
            "DIO": "Device:D",
            "LED": "Device:LED",
            "Q": "Device:Q",
            "IC": "Device:U",
            "REG": "Device:U",
            "OSC": "Device:U",
            "CON": "Connector:Conn",
            "CONN": "Connector:Conn",
        }
        lib_id = lib_id_map.get(cat, f"{cat}:{item.ipn}" if cat else "Device:Generic")

        props: dict[str, str] = {}
        if item.tolerance:
            props["Tolerance"] = item.tolerance
        if item.voltage:
            props["Voltage"] = item.voltage
        if item.wattage:
            props["Wattage"] = item.wattage

        footprint_full = str((item.raw_data or {}).get("footprint_full", "")).strip()
        symbol_name = str((item.raw_data or {}).get("symbol_name", "")).strip()
        return Component(
            reference=item.component_id or item.ipn or "",
            lib_id=symbol_name or lib_id,
            value=item.value or "",
            footprint=footprint_full or item.package or "",
            properties=props,
        )

    @staticmethod
    def _search_result_to_inventory_item(
        result: SearchResult, base_item: InventoryItem
    ) -> InventoryItem:
        # For scoring we only need a subset of fields used by SophisticatedInventoryMatcher.
        # Category/value/package are the most important.
        return InventoryItem(
            ipn="",
            keywords="",
            category=base_item.category or "",
            description=result.description,
            smd="",
            value=_value_from_search_result(result, base_item),
            type="",
            tolerance=result.attributes.get("Tolerance", "") or base_item.tolerance,
            voltage=result.attributes.get("Voltage", "") or base_item.voltage,
            amperage="",
            wattage=result.attributes.get("Power", "") or base_item.wattage,
            manufacturer=result.manufacturer,
            mfgpn=result.mpn,
            datasheet=result.datasheet,
            package=_package_from_search_result(result, base_item),
            raw_data={},
        )

    def generate_report(self, records: list[InventorySearchRecord]) -> str:
        total = len(records)
        successes = sum(1 for r in records if r.candidates)
        failures = total - successes

        unique_queries = {
            normalize_query(r.query) for r in records if (r.query or "").strip()
        }

        by_cat: dict[str, dict[str, int]] = {}
        for r in records:
            cat = (r.inventory_item.category or "").strip().upper() or "(missing)"
            stats = by_cat.setdefault(cat, {"total": 0, "success": 0})
            stats["total"] += 1
            if r.candidates:
                stats["success"] += 1

        lines: list[str] = []
        lines.append("INVENTORY SEARCH REPORT")
        lines.append(f"Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append("")
        lines.append(f"Total searchable items: {total}")
        lines.append(
            f"Unique queries dispatched: {len(unique_queries)} (of {total} items)"
        )
        if total:
            lines.append(
                f"Successful searches: {successes} ({successes/total*100:.1f}%)"
            )
            lines.append(f"Failed searches: {failures} ({failures/total*100:.1f}%)")
        lines.append("")
        lines.append("By category:")
        for cat, stats in sorted(by_cat.items()):
            rate = (
                (stats["success"] / stats["total"] * 100.0) if stats["total"] else 0.0
            )
            lines.append(f"  {cat}: {stats['success']}/{stats['total']} ({rate:.1f}%)")

        return "\n".join(lines) + "\n"

    def enhanced_csv_columns(self) -> list[str]:
        cols: list[str] = ["Search Query", "Search Success"]
        for idx in range(1, self._candidate_limit + 1):
            cols.extend(
                [
                    f"Candidate {idx} Manufacturer",
                    f"Candidate {idx} MPN",
                    f"Candidate {idx} Distributor PN",
                    f"Candidate {idx} Availability",
                    f"Candidate {idx} Stock",
                    f"Candidate {idx} Price",
                    f"Candidate {idx} Lifecycle",
                    f"Candidate {idx} Match Score",
                ]
            )
        return cols

    def enhance_inventory_rows(
        self,
        original_items: list[InventoryItem],
        *,
        original_field_order: list[str],
        records: list[InventorySearchRecord],
    ) -> list[dict[str, str]]:
        by_identity = {
            InventorySearchService.row_identity(r.inventory_item): r for r in records
        }

        enhanced: list[dict[str, str]] = []
        for item in original_items:
            row = dict(item.raw_data or {})

            # Ensure all original fields exist.
            for f in original_field_order:
                row.setdefault(f, "")

            rec = by_identity.get(InventorySearchService.row_identity(item))
            if rec is None:
                # Not searched / filtered out.
                row["Search Query"] = ""
                row["Search Success"] = ""
                for col in self.enhanced_csv_columns()[2:]:
                    row[col] = ""
                enhanced.append(row)
                continue

            row["Search Query"] = rec.query
            row["Search Success"] = "Yes" if rec.candidates else "No"

            # Fill candidate columns.
            for i in range(1, self._candidate_limit + 1):
                prefix = f"Candidate {i} "
                if i <= len(rec.candidates):
                    c = rec.candidates[i - 1]
                    row[prefix + "Manufacturer"] = c.result.manufacturer
                    row[prefix + "MPN"] = c.result.mpn
                    row[prefix + "Distributor PN"] = c.result.distributor_part_number
                    row[prefix + "Availability"] = c.result.availability
                    row[prefix + "Stock"] = str(c.result.stock_quantity)
                    row[prefix + "Price"] = c.result.price
                    row[prefix + "Lifecycle"] = c.result.lifecycle_status
                    row[prefix + "Match Score"] = str(c.match_score)
                else:
                    row[prefix + "Manufacturer"] = ""
                    row[prefix + "MPN"] = ""
                    row[prefix + "Distributor PN"] = ""
                    row[prefix + "Availability"] = ""
                    row[prefix + "Stock"] = ""
                    row[prefix + "Price"] = ""
                    row[prefix + "Lifecycle"] = ""
                    row[prefix + "Match Score"] = ""

            enhanced.append(row)

        return enhanced


def _price_to_float(price: str) -> float:
    try:
        t = re.sub(r"[^0-9\.]", "", price or "")
        return float(t)
    except ValueError:
        return float("inf")


def _value_from_search_result(result: SearchResult, base_item: InventoryItem) -> str:
    # Attempt to preserve semantic value for passives.
    cat = _category_token(base_item.category)

    if cat == "RES":
        return result.attributes.get("Resistance", "") or base_item.value

    if cat == "CAP":
        return result.attributes.get("Capacitance", "") or base_item.value

    if cat == "IND":
        return result.attributes.get("Inductance", "") or base_item.value

    return base_item.value


def _package_from_search_result(result: SearchResult, base_item: InventoryItem) -> str:
    return result.attributes.get("Package", "") or base_item.package


__all__ = [
    "InventorySearchCandidate",
    "InventorySearchRecord",
    "InventorySearchService",
]
