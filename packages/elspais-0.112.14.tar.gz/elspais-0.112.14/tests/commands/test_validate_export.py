# Validates REQ-d00085
"""Tests for elspais validate --export and --json flags (legacy, now part of health)."""

import argparse
import json
import os
import subprocess

import pytest


def _clean_git_env() -> dict[str, str]:
    """Return environment with GIT_DIR/GIT_WORK_TREE removed for test isolation."""
    env = os.environ.copy()
    env.pop("GIT_DIR", None)
    env.pop("GIT_WORK_TREE", None)
    return env


@pytest.fixture
def spec_repo(tmp_path):
    """Create a minimal spec repo with requirements."""
    env = _clean_git_env()

    # Initialize git repo
    subprocess.run(
        ["git", "init", "-b", "main"], cwd=tmp_path, env=env, capture_output=True, check=True
    )
    subprocess.run(
        ["git", "config", "user.email", "test@test.com"],
        cwd=tmp_path,
        env=env,
        capture_output=True,
        check=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "Test"],
        cwd=tmp_path,
        env=env,
        capture_output=True,
        check=True,
    )

    # Create elspais config
    config_file = tmp_path / ".elspais.toml"
    config_file.write_text(
        """
version = 3

[project]
name = "test-project"
namespace = "REQ"

[scanning.spec]
directories = ["spec"]
"""
    )

    # Create spec directory with a requirement
    spec_dir = tmp_path / "spec"
    spec_dir.mkdir()

    spec_file = spec_dir / "prd-test.md"
    spec_file.write_text(
        """# Test Requirements

## REQ-p00001: Test Requirement

**Level**: PRD | **Status**: Active | **Implements**: -

Some intro text.

## Assertions

A. The system SHALL do something.
B. The system SHALL do something else.

*End* *Test Requirement* | **Hash**: abcd1234

---
""",
        encoding="utf-8",
    )

    # Initial commit
    subprocess.run(["git", "add", "."], cwd=tmp_path, env=env, capture_output=True, check=True)
    subprocess.run(
        ["git", "commit", "-m", "init"],
        cwd=tmp_path,
        env=env,
        capture_output=True,
        check=True,
    )

    return tmp_path


class TestValidateExport:
    """Tests for validate --export flag."""

    def test_REQ_d00085_export_outputs_requirement_dict(self, spec_repo, capsys):
        """REQ-d00085-B: --export outputs requirements as JSON dict keyed by ID."""
        from elspais.commands.validate import run

        args = argparse.Namespace(
            spec_dir=spec_repo / "spec",
            config=spec_repo / ".elspais.toml",
            export=True,
            fix=False,
            dry_run=False,
            skip_rule=None,
            json=False,
            quiet=False,
            mode="combined",
        )

        result = run(args)

        assert result == 0
        captured = capsys.readouterr()
        data = json.loads(captured.out)

        # Should be a dict keyed by requirement ID
        assert isinstance(data, dict)
        assert "REQ-p00001" in data

        # Should have expected fields with correct values
        req = data["REQ-p00001"]
        assert req["title"] == "Test Requirement"
        assert req["level"] == "prd"
        assert req["status"] == "Active"
        assert "assertions" in req
        assert len(req["assertions"]) == 2

    def test_REQ_d00085_export_includes_hash_and_file(self, spec_repo, capsys):
        """REQ-d00085-B: --export includes hash and file path."""
        from elspais.commands.validate import run

        args = argparse.Namespace(
            spec_dir=spec_repo / "spec",
            config=spec_repo / ".elspais.toml",
            export=True,
            fix=False,
            dry_run=False,
            skip_rule=None,
            json=False,
            quiet=False,
            mode="combined",
        )

        result = run(args)

        assert result == 0
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        req = data["REQ-p00001"]

        assert "hash" in req
        assert "file" in req
        assert "prd-test.md" in req["file"]


class TestValidateJsonStillWorks:
    """Tests that --json still outputs validation results."""

    def test_REQ_d00085_A_json_still_outputs_validation_results(self, spec_repo, capsys):
        """REQ-d00085-A: --json outputs validation results, not export format."""
        from elspais.commands.validate import run

        args = argparse.Namespace(
            spec_dir=spec_repo / "spec",
            config=spec_repo / ".elspais.toml",
            export=False,
            fix=False,
            dry_run=False,
            skip_rule=None,
            json=True,
            quiet=False,
            mode="combined",
        )

        result = run(args)

        # Fixture has stale hash → hash.mismatch is an error
        assert result == 1
        captured = capsys.readouterr()
        data = json.loads(captured.out)

        # Should be validation results format (not a dict keyed by ID)
        assert isinstance(data, dict)
        assert "valid" in data
        assert data["valid"] is False
        assert "errors" in data
        assert "warnings" in data
        assert "requirements_count" in data
