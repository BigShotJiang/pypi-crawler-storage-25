# REQ-d00001: Password Hashing

**Level**: Dev | **Status**: Active | **Implements**: REQ-p00001

## Assertions

A. The implementation SHALL use bcrypt with cost factor >= 12.
B. The implementation SHALL NOT store plaintext passwords.
C. The implementation SHALL reject passwords shorter than 8 characters.

## Rationale

bcrypt is resistant to GPU-based attacks.

*End* *Password Hashing* | **Hash**: 2f7c9b91
---

# REQ-d00002: Session Token Generation

**Level**: Dev | **Status**: Active | **Implements**: REQ-p00002

## Assertions

A. Tokens SHALL be cryptographically random using secure PRNG.
B. Tokens SHALL be at least 256 bits in length.
C. Tokens SHALL be stored hashed in the database.

*End* *Session Token Generation* | **Hash**: 3274b592
---
