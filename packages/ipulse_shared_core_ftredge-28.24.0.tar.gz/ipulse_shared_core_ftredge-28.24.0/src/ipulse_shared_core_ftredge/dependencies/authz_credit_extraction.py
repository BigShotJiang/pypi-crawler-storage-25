"""Helpers to extract telemetry-relevant requestor data from authz responses."""

from typing import Optional, Dict, Any
import logging

logger = logging.getLogger(__name__)


def _as_optional_str(value: Any) -> Optional[str]:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def extract_credits_from_authz_response(authz_info: Any) -> Optional[Dict[str, float]]:
    """
    Extract credit information from OPA authorization decision.

    This function replaces the complex PreFetchedCredits dependency by directly
    extracting credit information from the authorization response.

    Args:
        authz_info: Authorization information from OPA decision (typically AuthorizedRequest)

    Returns:
        Dictionary with credit information or None if not available:
        {
            "sbscrptn_based_insight_credits": float,
            "extra_insight_credits": float
        }
    """
    if not authz_info:
        logger.debug("No authorization info provided for credit extraction")
        return None

    try:
        # Handle dict-like authorization info (AuthorizedRequest typically converts to dict)
        if isinstance(authz_info, dict) and 'opa_decision' in authz_info:
            requestor_info = authz_info['opa_decision'].get("requestor_post_authz", {})
            if requestor_info:
                extracted_credits = {
                    "sbscrptn_based_insight_credits": float(requestor_info.get("sbscrptn_based_insight_credits", 0.0)),
                    "extra_insight_credits": float(requestor_info.get("extra_insight_credits", 0.0))
                }
                logger.debug("Successfully extracted credits from authz response: %s", extracted_credits)
                return extracted_credits
            else:
                logger.debug("No requestor_post_authz found in OPA decision")
                return None

        # Handle object-like authorization info with attributes
        elif hasattr(authz_info, 'opa_decision'):
            opa_decision = getattr(authz_info, 'opa_decision', {})
            if isinstance(opa_decision, dict):
                requestor_info = opa_decision.get("requestor_post_authz", {})
                if requestor_info:
                    extracted_credits = {
                        "sbscrptn_based_insight_credits": float(requestor_info.get("sbscrptn_based_insight_credits", 0.0)),
                        "extra_insight_credits": float(requestor_info.get("extra_insight_credits", 0.0))
                    }
                    logger.debug("Successfully extracted credits from authz response (object): %s", extracted_credits)
                    return extracted_credits

        logger.debug("No valid OPA decision structure found in authz_info for credit extraction")
        return None

    except (AttributeError, KeyError, TypeError, ValueError) as e:
        logger.warning("Failed to extract credits from authz response: %s", e)
        return None


def extract_requestor_context_from_authz_response(authz_info: Any) -> Dict[str, Optional[str]]:
    """Extract requestor identity/subscription context from authz_info for event logging.

    Returns a stable shape with nullable values:
    {
        "user_uid": Optional[str],
        "user_email": Optional[str],
        "active_subscription_plan_id": Optional[str],
        "active_subscription_plan_name": Optional[str],
    }
    """
    result: Dict[str, Optional[str]] = {
        "user_uid": None,
        "user_email": None,
        "active_subscription_plan_id": None,
        "active_subscription_plan_name": None,
    }

    if not authz_info:
        return result

    try:
        if isinstance(authz_info, dict):
            # Preferred source: requestor_context injected by authz middleware.
            requestor_context = authz_info.get("requestor_context", {})
            if isinstance(requestor_context, dict):
                result["user_uid"] = _as_optional_str(requestor_context.get("uid"))
                result["user_email"] = _as_optional_str(requestor_context.get("email"))
                result["active_subscription_plan_id"] = _as_optional_str(
                    requestor_context.get("active_subscription_plan_id")
                )
                result["active_subscription_plan_name"] = _as_optional_str(
                    requestor_context.get("active_subscription_plan_name")
                )

            # Compatibility fallback when context is absent.
            opa_decision = authz_info.get("opa_decision", {})
            requestor_post_authz = (
                opa_decision.get("requestor_post_authz", {})
                if isinstance(opa_decision, dict)
                else {}
            )

            if isinstance(requestor_post_authz, dict):
                result["active_subscription_plan_id"] = (
                    result["active_subscription_plan_id"]
                    or _as_optional_str(requestor_post_authz.get("active_subscription_plan_id"))
                )
                result["active_subscription_plan_name"] = (
                    result["active_subscription_plan_name"]
                    or _as_optional_str(requestor_post_authz.get("active_subscription_plan_name"))
                )

            return result

        if hasattr(authz_info, "requestor_context"):
            requestor_context = getattr(authz_info, "requestor_context", {})
            if isinstance(requestor_context, dict):
                result["user_uid"] = _as_optional_str(requestor_context.get("uid"))
                result["user_email"] = _as_optional_str(requestor_context.get("email"))
                result["active_subscription_plan_id"] = _as_optional_str(
                    requestor_context.get("active_subscription_plan_id")
                )
                result["active_subscription_plan_name"] = _as_optional_str(
                    requestor_context.get("active_subscription_plan_name")
                )

    except Exception as e:  # noqa: BLE001
        logger.warning("Failed to extract requestor context from authz response: %s", e)

    return result
