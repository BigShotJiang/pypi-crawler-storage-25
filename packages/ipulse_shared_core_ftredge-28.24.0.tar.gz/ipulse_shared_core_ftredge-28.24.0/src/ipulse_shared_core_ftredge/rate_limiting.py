"""Lightweight in-memory rate limiting for FastAPI services.

The limiter is intentionally process-local. On Cloud Run this means each
instance has an independent bucket, which is acceptable for low-cost abuse
prevention but not a strict global quota.
"""

from __future__ import annotations

import asyncio
import json
import logging
import math
import os
import re
import time
from collections import deque
from dataclasses import dataclass
from typing import Any, Deque, Iterable, Literal, Optional, Sequence

from fastapi import HTTPException, Request
from fastapi.responses import JSONResponse

from ipulse_shared_core_ftredge.models import BaseAPIResponse

RateLimitScope = Literal["ip", "uid"]

_RATE_LIMIT_PATTERN = re.compile(
    r"^\s*(?P<count>\d+)\s*/\s*(?P<period>second|sec|s|minute|min|m|hour|hr|h|day|d)s?\s*$",
    re.IGNORECASE,
)

_PERIOD_SECONDS = {
    "second": 1,
    "sec": 1,
    "s": 1,
    "minute": 60,
    "min": 60,
    "m": 60,
    "hour": 3600,
    "hr": 3600,
    "h": 3600,
    "day": 86400,
    "d": 86400,
}

_RATE_LIMIT_EXEMPT_PREFIXES = (
    "/health",
    "/docs",
    "/redoc",
    "/openapi.json",
    "/favicon.ico",
)

_RATE_LIMITED_BY_SERVICE_HEADER = "X-Rate-Limited-By-Service"


@dataclass(frozen=True)
class WindowLimit:
    """One rate-limit window such as 100 requests per 60 seconds."""

    request_count: int
    window_seconds: int


@dataclass(frozen=True)
class RateLimitPolicy:
    """A named policy matched by route prefix and request method."""

    name: str
    scope: RateLimitScope
    limits: tuple[WindowLimit, ...]
    path_prefixes: tuple[str, ...]
    methods: tuple[str, ...] = ("GET", "POST", "PATCH", "PUT", "DELETE")


@dataclass(frozen=True)
class RateLimitExceeded:
    """Decision payload returned when a bucket has exceeded a policy."""

    policy_name: str
    identifier: str
    scope: RateLimitScope
    limit: WindowLimit
    retry_after_seconds: int


class InMemorySlidingWindowRateLimiter:
    """Async-safe process-local sliding-window limiter."""

    def __init__(self) -> None:
        self._events: dict[str, Deque[float]] = {}
        self._lock = asyncio.Lock()

    async def check(
        self,
        *,
        bucket_key: str,
        limits: Sequence[WindowLimit],
        now: Optional[float] = None,
    ) -> Optional[RateLimitExceeded]:
        """Record a request if all windows allow it, otherwise return denial."""
        current_time = now if now is not None else time.time()

        async with self._lock:
            for limit in limits:
                scoped_key = self._window_key(bucket_key, limit.window_seconds)
                events = self._events.setdefault(scoped_key, deque())
                self._discard_expired(events, current_time, limit.window_seconds)

                if len(events) >= limit.request_count:
                    oldest = events[0]
                    retry_after = max(1, math.ceil((oldest + limit.window_seconds) - current_time))
                    policy_name, scope, identifier = self._parse_bucket_key(bucket_key)
                    return RateLimitExceeded(
                        policy_name=policy_name,
                        identifier=identifier,
                        scope=scope,
                        limit=limit,
                        retry_after_seconds=retry_after,
                    )

            for limit in limits:
                scoped_key = self._window_key(bucket_key, limit.window_seconds)
                self._events.setdefault(scoped_key, deque()).append(current_time)

        return None

    def clear(self) -> None:
        """Clear all process-local buckets. Intended for tests."""
        self._events.clear()

    @staticmethod
    def _window_key(bucket_key: str, window_seconds: int) -> str:
        return f"{bucket_key}:window:{window_seconds}"

    @staticmethod
    def _discard_expired(events: Deque[float], current_time: float, window_seconds: int) -> None:
        cutoff = current_time - window_seconds
        while events and events[0] <= cutoff:
            events.popleft()

    @staticmethod
    def _parse_bucket_key(bucket_key: str) -> tuple[str, RateLimitScope, str]:
        parts = bucket_key.split(":", 2)
        if len(parts) != 3:
            return bucket_key, "ip", "unknown"
        policy_name, scope, identifier = parts
        return policy_name, scope if scope in ("ip", "uid") else "ip", identifier


_limiter = InMemorySlidingWindowRateLimiter()


def _env_bool(name: str, default: bool) -> bool:
    raw_value = os.getenv(name)
    if raw_value is None:
        return default
    return raw_value.strip().lower() in {"1", "true", "yes", "on"}


def is_rate_limiting_enabled() -> bool:
    return _env_bool("RATE_LIMIT_ENABLED", True)


def is_rate_limit_observe_only() -> bool:
    return _env_bool("RATE_LIMIT_OBSERVE_ONLY", False)


def parse_limits(raw_value: Optional[str], default_limits: Sequence[WindowLimit]) -> tuple[WindowLimit, ...]:
    """Parse env limit text like '100/minute,1000/hour,2000/day'."""
    if not raw_value:
        return tuple(default_limits)

    parsed_limits: list[WindowLimit] = []
    for part in re.split(r"[,;]", raw_value):
        cleaned = part.strip()
        if not cleaned:
            continue
        match = _RATE_LIMIT_PATTERN.match(cleaned)
        if not match:
            raise ValueError(f"Invalid rate limit format: {cleaned!r}")
        parsed_limits.append(
            WindowLimit(
                request_count=int(match.group("count")),
                window_seconds=_PERIOD_SECONDS[match.group("period").lower()],
            )
        )

    return tuple(parsed_limits) if parsed_limits else tuple(default_limits)


def get_limits_from_env(env_name: str, default_limits: Sequence[WindowLimit]) -> tuple[WindowLimit, ...]:
    """Resolve named env limits while keeping service-owned defaults nearby."""
    return parse_limits(os.getenv(env_name), default_limits)


def parse_rate_limit_policies(raw_value: Optional[str], *, scope: RateLimitScope) -> tuple[RateLimitPolicy, ...]:
    """Parse JSON policy config from env for service-level policy overrides.

    Expected shape:
    [
      {
        "name": "custom_policy",
        "limits": "100/minute,1000/hour,2000/day",
        "path_prefixes": ["/api/v1/example"],
        "methods": ["GET"],
        "scope": "ip"
      }
    ]
    """
    if not raw_value:
        return ()

    try:
        payload = json.loads(raw_value)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid rate-limit policies JSON: {exc}") from exc

    if isinstance(payload, dict) and "policies" in payload:
        payload = payload["policies"]
    elif isinstance(payload, dict):
        payload = [payload]

    if not isinstance(payload, list):
        raise ValueError("Rate-limit policies JSON must be a list or an object with a 'policies' list")

    return tuple(_policy_from_config(item, scope=scope) for item in payload)


def merge_rate_limit_policies(
    default_policies: Sequence[RateLimitPolicy],
    env_policies: Sequence[RateLimitPolicy],
) -> tuple[RateLimitPolicy, ...]:
    """Merge service defaults with env policies, overriding same-name policies."""
    merged_by_name = {policy.name: policy for policy in default_policies}
    ordered_names = [policy.name for policy in default_policies]

    for policy in env_policies:
        if policy.name not in merged_by_name:
            ordered_names.append(policy.name)
        merged_by_name[policy.name] = policy

    return tuple(merged_by_name[name] for name in ordered_names)


def _policy_from_config(raw_policy: Any, *, scope: RateLimitScope) -> RateLimitPolicy:
    if not isinstance(raw_policy, dict):
        raise ValueError("Each rate-limit policy must be a JSON object")

    name = str(raw_policy.get("name", "")).strip()
    if not name:
        raise ValueError("Rate-limit policy requires a non-empty 'name'")

    raw_scope = str(raw_policy.get("scope", scope)).strip().lower()
    if raw_scope not in {"ip", "uid"}:
        raise ValueError(f"Rate-limit policy {name!r} has invalid scope {raw_scope!r}")
    if raw_scope != scope:
        raise ValueError(f"Rate-limit policy {name!r} scope {raw_scope!r} does not match expected scope {scope!r}")
    policy_scope: RateLimitScope = "ip" if raw_scope == "ip" else "uid"

    raw_limits = raw_policy.get("limits")
    if not isinstance(raw_limits, str):
        raise ValueError(f"Rate-limit policy {name!r} requires string 'limits'")
    limits = parse_limits(raw_limits, ())
    if not limits:
        raise ValueError(f"Rate-limit policy {name!r} must define at least one limit")

    path_prefixes = _parse_string_tuple(raw_policy.get("path_prefixes", raw_policy.get("paths")), "path_prefixes", name)
    if not path_prefixes:
        raise ValueError(f"Rate-limit policy {name!r} must define at least one path prefix")

    methods = _parse_string_tuple(raw_policy.get("methods", ("GET", "POST", "PATCH", "PUT", "DELETE")), "methods", name)
    if not methods:
        raise ValueError(f"Rate-limit policy {name!r} must define at least one HTTP method")

    return RateLimitPolicy(
        name=name,
        scope=policy_scope,
        limits=limits,
        path_prefixes=path_prefixes,
        methods=tuple(method.upper() for method in methods),
    )


def _parse_string_tuple(raw_value: Any, field_name: str, policy_name: str) -> tuple[str, ...]:
    if isinstance(raw_value, str):
        values = [value.strip() for value in re.split(r"[,;]", raw_value) if value.strip()]
    elif isinstance(raw_value, (list, tuple)):
        values = [str(value).strip() for value in raw_value if str(value).strip()]
    else:
        raise ValueError(f"Rate-limit policy {policy_name!r} requires string or list '{field_name}'")

    return tuple(values)


def get_client_ip(request: Request) -> str:
    """Return the best available client IP for direct Cloud Run requests."""
    forwarded_for = request.headers.get("x-forwarded-for")
    if forwarded_for:
        first_ip = forwarded_for.split(",", 1)[0].strip()
        if first_ip:
            return first_ip

    real_ip = request.headers.get("x-real-ip")
    if real_ip:
        return real_ip.strip()

    if request.client and request.client.host:
        return request.client.host

    return "unknown"


def _normalize_path(path: str) -> str:
    normalized = (path or "/").strip().lower()
    if not normalized.startswith("/"):
        normalized = f"/{normalized}"
    return normalized.rstrip("/") or "/"


def _path_matches(path: str, prefixes: Iterable[str]) -> bool:
    normalized = _normalize_path(path)
    for prefix in prefixes:
        normalized_prefix = _normalize_path(prefix)
        if normalized == normalized_prefix or normalized.startswith(f"{normalized_prefix}/"):
            return True
    return False


def _is_exempt_request(request: Request) -> bool:
    if request.method.upper() in {"OPTIONS", "HEAD"}:
        return True
    return _path_matches(request.url.path, _RATE_LIMIT_EXEMPT_PREFIXES)


def _matching_policies(request: Request, policies: Sequence[RateLimitPolicy]) -> tuple[RateLimitPolicy, ...]:
    method = request.method.upper()
    return tuple(
        policy
        for policy in policies
        if method in policy.methods and _path_matches(request.url.path, policy.path_prefixes)
    )


def _bucket_key(policy: RateLimitPolicy, identifier: str) -> str:
    sanitized_identifier = identifier.replace(":", "_")
    return f"{policy.name}:{policy.scope}:{sanitized_identifier}"


def _resolve_request_policies(
    request: Request,
    policies: Optional[Sequence[RateLimitPolicy]],
    state_attr_name: str,
) -> tuple[RateLimitPolicy, ...]:
    if policies is not None:
        return tuple(policies)

    app = getattr(request, "app", None)
    state = getattr(app, "state", None) if app else None
    if state is None:
        return ()

    return tuple(getattr(state, state_attr_name, ()) or ())


def get_rate_limited_by_service(request: Request) -> str:
    """Resolve the service identifier used for rate-limit attribution."""
    app = getattr(request, "app", None)
    state = getattr(app, "state", None) if app else None
    service_name = getattr(state, "rate_limiter_service_name", None) if state else None
    if not service_name:
        service_name = os.getenv("K_SERVICE") or os.getenv("RATE_LIMIT_SERVICE_NAME") or "unknown"
    return str(service_name)


def _rate_limit_response(exceeded: RateLimitExceeded, request: Request) -> JSONResponse:
    rate_limited_by_service = get_rate_limited_by_service(request)
    return JSONResponse(
        status_code=429,
        headers={_RATE_LIMITED_BY_SERVICE_HEADER: rate_limited_by_service},
        content=BaseAPIResponse(
            success=False,
            error="Rate limit exceeded",
            message="Request limit reached.",
            metadata={
                "path": str(request.url),
                "method": request.method,
                "rate_limited_by_service": rate_limited_by_service,
            },
        ).model_dump(exclude_none=True),
    )


def _rate_limit_http_exception(exceeded: RateLimitExceeded, request: Request) -> HTTPException:
    rate_limited_by_service = get_rate_limited_by_service(request)
    return HTTPException(
        status_code=429,
        detail="Request limit reached.",
        headers={_RATE_LIMITED_BY_SERVICE_HEADER: rate_limited_by_service},
    )


async def rate_limit_request_by_ip(
    request: Request,
    *,
    policies: Optional[Sequence[RateLimitPolicy]] = None,
    logger: Optional[logging.Logger] = None,
) -> Optional[JSONResponse]:
    """Apply matching IP policies and return a 429 response when exceeded."""
    if not is_rate_limiting_enabled() or _is_exempt_request(request):
        return None

    identifier = get_client_ip(request)
    active_policies = _resolve_request_policies(request, policies, "rate_limit_ip_policies")
    for policy in _matching_policies(request, active_policies):
        exceeded = await _limiter.check(bucket_key=_bucket_key(policy, identifier), limits=policy.limits)
        if exceeded:
            if logger:
                logger.warning(
                    f"Rate limit exceeded: policy={exceeded.policy_name}, scope=ip, identifier={identifier}, path={request.url.path}"
                )
            if is_rate_limit_observe_only():
                continue
            return _rate_limit_response(exceeded, request)

    return None


async def enforce_authenticated_rate_limit(
    request: Request,
    *,
    user_uid: Optional[str],
    policies: Optional[Sequence[RateLimitPolicy]] = None,
    logger: Optional[logging.Logger] = None,
) -> None:
    """Apply matching UID policies after Firebase token verification."""
    if not is_rate_limiting_enabled() or _is_exempt_request(request) or not user_uid:
        return

    active_policies = _resolve_request_policies(request, policies, "rate_limit_uid_policies")
    for policy in _matching_policies(request, active_policies):
        exceeded = await _limiter.check(bucket_key=_bucket_key(policy, user_uid), limits=policy.limits)
        if exceeded:
            if logger:
                logger.warning(
                    f"Rate limit exceeded: policy={exceeded.policy_name}, scope=uid, user_uid={user_uid}, path={request.url.path}"
                )
            if is_rate_limit_observe_only():
                continue
            raise _rate_limit_http_exception(exceeded, request)


def reset_rate_limiter_for_tests() -> None:
    """Clear limiter state for deterministic unit tests."""
    _limiter.clear()
