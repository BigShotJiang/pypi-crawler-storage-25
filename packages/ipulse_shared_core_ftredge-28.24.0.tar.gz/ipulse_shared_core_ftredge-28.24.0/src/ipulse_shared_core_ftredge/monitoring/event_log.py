"""Shared event logging contract and emitter for microservices."""

from __future__ import annotations

import json
import logging
import sys
import uuid
from datetime import datetime, timezone
from enum import StrEnum
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator, field_validator


EVENT_STREAM_CREDIT_ACTIVITY_V1 = "papp_credit_activity_v1"
EVENT_SCHEMA_VERSION_V1 = 1
EVENT_SCHEMA_VERSION_V2 = 2
EVENT_SCHEMA_VERSION_ACTIVE = EVENT_SCHEMA_VERSION_V2


class EventType(StrEnum):
    """Supported microservice analytics event types."""

    CREDIT_CHECK = "credit_check"
    CREDIT_CHARGED = "credit_charged"
    CREDIT_CHARGE_FAILED = "credit_charge_failed"
    CREDIT_GRANTED = "credit_granted"
    CREDIT_ADJUSTED = "credit_adjusted"
    CREDIT_REFRESHED = "credit_refreshed"
    RESOURCE_ACCESS = "resource_access"
    AUTHZ_REVIEW = "authz_review"


class EventOutcome(StrEnum):
    """Outcome categories for analytics and debugging."""

    SUCCESS = "success"
    PARTIAL_SUCCESS = "partial_success"
    FAILURE = "failure"
    DENIED = "denied"
    SKIPPED = "skipped"


class EventLog(BaseModel):
    """Strict flat event payload for sinked analytics logs."""

    model_config = ConfigDict(extra="forbid", frozen=False)

    # Stream contract metadata
    event_stream: str = Field(default=EVENT_STREAM_CREDIT_ACTIVITY_V1)
    schema_version: int = Field(default=EVENT_SCHEMA_VERSION_ACTIVE, ge=1)

    # Auto-populated common metadata
    event_id: Optional[str] = Field(default=None)
    event_time_utc: Optional[datetime] = Field(default=None)
    environment: Optional[str] = Field(default=None)
    service_name: Optional[str] = Field(default=None)

    # Core event dimensions
    user_uid: str = Field(..., min_length=1)
    user_email: Optional[str] = Field(default=None)
    active_subscription_plan_id: Optional[str] = Field(default=None)
    active_subscription_plan_name: Optional[str] = Field(default=None)
    event_type: EventType
    outcome: EventOutcome
    success: Optional[bool] = Field(default=None)

    # Credit debugging and accounting fields
    credits_delta: Optional[float] = Field(default=None)
    credits_charged: Optional[float] = Field(default=None, ge=0)
    subs_credits_before: Optional[float] = Field(default=None, ge=0)
    subs_credits_after: Optional[float] = Field(default=None, ge=0)
    extra_credits_before: Optional[float] = Field(default=None, ge=0)
    extra_credits_after: Optional[float] = Field(default=None, ge=0)
    total_before: Optional[float] = Field(default=None, ge=0)
    total_after: Optional[float] = Field(default=None, ge=0)

    # Operation and resource dimensions
    operation: str = Field(..., min_length=1)
    resource_type: Optional[str] = Field(default=None)
    resource_id: Optional[str] = Field(default=None)

    # Request context
    http_method: Optional[str] = Field(default=None)
    http_path: Optional[str] = Field(default=None)
    http_status_code: Optional[int] = Field(default=None, ge=100, le=599)
    request_id: Optional[str] = Field(default=None)
    trace_id: Optional[str] = Field(default=None)

    # Optional behavior dimensions for analytics users
    subject_id: Optional[str] = Field(default=None)
    subject_category: Optional[str] = Field(default=None)
    dataset_type: Optional[str] = Field(default=None)

    # Error context
    error_code: Optional[str] = Field(default=None)
    error_message: Optional[str] = Field(default=None)

    @field_validator("event_stream")
    @classmethod
    def validate_event_stream(cls, value: str) -> str:
        if value != EVENT_STREAM_CREDIT_ACTIVITY_V1:
            raise ValueError(
                f"event_stream must be '{EVENT_STREAM_CREDIT_ACTIVITY_V1}'"
            )
        return value

    @field_validator("user_uid", "operation")
    @classmethod
    def validate_non_empty_str(cls, value: str) -> str:
        stripped = value.strip()
        if not stripped:
            raise ValueError("value cannot be empty or whitespace")
        return stripped

    @field_validator("http_method")
    @classmethod
    def normalize_http_method(cls, value: Optional[str]) -> Optional[str]:
        if value is None:
            return None
        return value.strip().upper()

    @field_validator("event_time_utc")
    @classmethod
    def ensure_aware_utc(cls, value: Optional[datetime]) -> Optional[datetime]:
        if value is None:
            return None
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)

    @model_validator(mode="after")
    def normalize_derived_fields(self) -> "EventLog":
        if self.success is None:
            self.success = self.outcome in {
                EventOutcome.SUCCESS,
                EventOutcome.PARTIAL_SUCCESS,
            }

        if self.credits_charged is not None and self.credits_delta is None:
            self.credits_delta = -float(self.credits_charged)

        if (
            self.total_before is None
            and self.subs_credits_before is not None
            and self.extra_credits_before is not None
        ):
            self.total_before = float(self.subs_credits_before) + float(self.extra_credits_before)

        if (
            self.total_after is None
            and self.subs_credits_after is not None
            and self.extra_credits_after is not None
        ):
            self.total_after = float(self.subs_credits_after) + float(self.extra_credits_after)

        return self


def build_event_logger(logger_name: str, level: int = logging.INFO) -> logging.Logger:
    """Create a dedicated JSON-line logger for sinked analytics events."""

    logger = logging.getLogger(logger_name)
    logger.setLevel(level)
    logger.propagate = False

    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter("%(message)s"))
        logger.addHandler(handler)

    return logger


def _coalesce_event_metadata(
    event: EventLog,
    *,
    environment: str,
    service_name: str,
) -> EventLog:
    """Inject mandatory common metadata for consistent cross-service emissions."""

    env = environment.strip()
    svc = service_name.strip()

    if not env:
        raise ValueError("environment cannot be empty")
    if not svc:
        raise ValueError("service_name cannot be empty")

    if event.environment and event.environment != env:
        raise ValueError("event.environment does not match emitter environment")
    if event.service_name and event.service_name != svc:
        raise ValueError("event.service_name does not match emitter service_name")

    updates = {
        "environment": event.environment or env,
        "service_name": event.service_name or svc,
        "event_id": event.event_id or str(uuid.uuid4()),
        "event_time_utc": event.event_time_utc or datetime.now(timezone.utc),
    }

    return event.model_copy(update=updates)


def emit_event_log(
    event_logger: logging.Logger,
    event: EventLog,
    *,
    environment: str,
    service_name: str,
) -> EventLog:
    """Emit one flat JSON event line through a dedicated event logger."""

    if not isinstance(event, EventLog):
        raise TypeError("event must be an EventLog instance")

    materialized = _coalesce_event_metadata(
        event,
        environment=environment,
        service_name=service_name,
    )

    payload = materialized.model_dump(mode="json", exclude_none=True)
    event_logger.info(json.dumps(payload, ensure_ascii=True, separators=(",", ":")))

    return materialized
