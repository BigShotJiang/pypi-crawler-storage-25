"""Unit tests for UserChargingOperations event emission behavior."""

import io
import json
import logging

import pytest

from ipulse_shared_core_ftredge.monitoring import build_event_logger
from ipulse_shared_core_ftredge.services.user.user_charging_operations import UserChargingOperations


class _DummyUserStatusOps:
    """Minimal stub to satisfy UserChargingOperations constructor."""

    def __init__(self) -> None:
        self.db = object()


def _capture_stream_for_logger(logger: logging.Logger) -> tuple[logging.StreamHandler, io.StringIO, object]:
    stream_handler = None
    for handler in logger.handlers:
        if isinstance(handler, logging.StreamHandler):
            stream_handler = handler
            break

    if stream_handler is None:
        raise AssertionError("Event logger does not have a StreamHandler")

    original_stream = stream_handler.stream
    capture_stream = io.StringIO()
    stream_handler.setStream(capture_stream)
    return stream_handler, capture_stream, original_stream


@pytest.mark.asyncio
async def test_single_item_charging_emits_denied_event() -> None:
    event_logger = build_event_logger("test_user_charging_event_denied")
    handler, capture_stream, original_stream = _capture_stream_for_logger(event_logger)

    try:
        charging_ops = UserChargingOperations(
            userstatus_ops=_DummyUserStatusOps(),
            logger=logging.getLogger("test_user_charging_event_denied_ops"),
            event_logger=event_logger,
            event_environment="test",
            event_service_name="papp-oracle-fincore-prediction",
        )

        async def fake_cost() -> float:
            return 7.5

        async def fake_verify(*args, **kwargs):
            return False, {
                "sbscrptn_based_insight_credits": 2.0,
                "extra_insight_credits": 1.0,
            }

        charging_ops.verify_enough_credits = fake_verify  # type: ignore[method-assign]

        result = await charging_ops.process_single_item_charging(
            user_uid="user_denied",
            item_id="prediction_task_abc",
            get_cost_func=fake_cost,
            credits_extracted_from_authz_response={
                "sbscrptn_based_insight_credits": 2.0,
                "extra_insight_credits": 1.0,
            },
            operation_description="Prediction dataset access",
            event_context={
                "resource_type": "prediction_market_dataset",
                "resource_id": "prediction_task_abc",
                "dataset_type": "eod_close_price_investment_thesis_and_timeseries",
                "http_method": "GET",
                "http_path": "/api/v1/papp/oracle/fincore/prediction/market/datasets/eod_close_price_investment_thesis_and_timeseries/prediction_task/prediction_task_abc",
            },
        )

        assert result["access_granted"] is False
        assert result["reason"] == "insufficient_credits"

        output = capture_stream.getvalue().strip()
        assert output

        payload = json.loads(output.splitlines()[-1])
        assert payload["event_type"] == "credit_check"
        assert payload["outcome"] == "denied"
        assert payload["error_code"] == "insufficient_credits"
        assert payload["resource_id"] == "prediction_task_abc"
        assert payload["dataset_type"] == "eod_close_price_investment_thesis_and_timeseries"
        assert payload["service_name"] == "papp-oracle-fincore-prediction"
    finally:
        handler.setStream(original_stream)


@pytest.mark.asyncio
async def test_single_item_charging_emits_success_charge_event() -> None:
    event_logger = build_event_logger("test_user_charging_event_success")
    handler, capture_stream, original_stream = _capture_stream_for_logger(event_logger)

    try:
        charging_ops = UserChargingOperations(
            userstatus_ops=_DummyUserStatusOps(),
            logger=logging.getLogger("test_user_charging_event_success_ops"),
            event_logger=event_logger,
            event_environment="test",
            event_service_name="papp-oracle-fincore-historic",
        )

        async def fake_cost() -> float:
            return 4.0

        async def fake_verify(*args, **kwargs):
            return True, {
                "sbscrptn_based_insight_credits": 10.0,
                "extra_insight_credits": 2.0,
            }

        async def fake_debit(*args, **kwargs):
            return True, {
                "sbscrptn_based_insight_credits": 6.0,
                "extra_insight_credits": 2.0,
            }

        charging_ops.verify_enough_credits = fake_verify  # type: ignore[method-assign]
        charging_ops.debit_credits_transaction = fake_debit  # type: ignore[method-assign]

        result = await charging_ops.process_single_item_charging(
            user_uid="user_success",
            item_id="equity_aapl",
            get_cost_func=fake_cost,
            credits_extracted_from_authz_response={
                "sbscrptn_based_insight_credits": 10.0,
                "extra_insight_credits": 2.0,
            },
            operation_description="Historic dataset access",
            event_context={
                "resource_type": "historic_market_dataset",
                "resource_id": "eod_close_with_actions:equity_aapl",
                "subject_id": "equity_aapl",
                "dataset_type": "eod_close_with_actions",
                "http_method": "GET",
                "http_path": "/api/v1/papp/oracle/fincore/historic/market/datasets/eod_close_with_actions/asset/equity_aapl",
            },
        )

        assert result["access_granted"] is True
        assert result["charge_successful"] is True
        assert result["cost"] == 4.0

        output = capture_stream.getvalue().strip()
        assert output

        payload = json.loads(output.splitlines()[-1])
        assert payload["event_type"] == "credit_charged"
        assert payload["outcome"] == "success"
        assert payload["credits_charged"] == 4.0
        assert payload["credits_delta"] == -4.0
        assert payload["subs_credits_before"] == 10.0
        assert payload["subs_credits_after"] == 6.0
        assert payload["service_name"] == "papp-oracle-fincore-historic"
        assert payload["resource_id"] == "eod_close_with_actions:equity_aapl"
    finally:
        handler.setStream(original_stream)
