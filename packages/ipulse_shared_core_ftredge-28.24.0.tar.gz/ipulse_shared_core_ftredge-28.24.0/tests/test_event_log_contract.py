"""Contract tests for shared EventLog payloads and emitter behavior."""

import io
import json
import logging

import pytest
from pydantic import ValidationError

from ipulse_shared_core_ftredge.monitoring import (
    EVENT_SCHEMA_VERSION_ACTIVE,
    EVENT_STREAM_CREDIT_ACTIVITY_V1,
    EventLog,
    EventOutcome,
    EventType,
    build_event_logger,
    emit_event_log,
)


def _capture_stream_for_logger(logger: logging.Logger) -> tuple[logging.StreamHandler, io.StringIO, object]:
    stream_handler = None
    for handler in logger.handlers:
        if isinstance(handler, logging.StreamHandler):
            stream_handler = handler
            break

    if stream_handler is None:
        raise AssertionError("Event logger does not have a StreamHandler")

    original_stream = stream_handler.stream
    capture_stream = io.StringIO()
    stream_handler.setStream(capture_stream)
    return stream_handler, capture_stream, original_stream


def test_event_log_golden_payload_contract() -> None:
    logger = build_event_logger("test_event_log_contract_logger")
    handler, capture_stream, original_stream = _capture_stream_for_logger(logger)

    try:
        event = EventLog(
            user_uid="user_123",
            event_type=EventType.CREDIT_CHARGED,
            outcome=EventOutcome.SUCCESS,
            operation="dataset_access",
            credits_charged=4.0,
            subs_credits_before=39.2,
            subs_credits_after=35.2,
            extra_credits_before=0.0,
            extra_credits_after=0.0,
            resource_type="market_dataset",
            resource_id="commodity_35be58ef-7f43-54c9-a726-3c869a214507",
            http_method="get",
            http_path="/api/v1/papp/oracle/fincore/historic/market/datasets/eod_close_with_actions/asset/commodity_35be58ef-7f43-54c9-a726-3c869a214507",
            http_status_code=200,
            request_id="req_001",
            trace_id="trace_001",
            subject_id="commodity_35be58ef-7f43-54c9-a726-3c869a214507",
            subject_category="commodity",
            dataset_type="eod_close_with_actions",
        )

        emitted = emit_event_log(
            logger,
            event,
            environment="production",
            service_name="papp-oracle-fincore-historic",
        )

        output = capture_stream.getvalue().strip()
        assert output

        payload = json.loads(output.splitlines()[-1])

        assert payload["event_stream"] == EVENT_STREAM_CREDIT_ACTIVITY_V1
        assert payload["schema_version"] == EVENT_SCHEMA_VERSION_ACTIVE
        assert payload["environment"] == "production"
        assert payload["service_name"] == "papp-oracle-fincore-historic"
        assert payload["user_uid"] == "user_123"
        assert payload["event_type"] == "credit_charged"
        assert payload["outcome"] == "success"
        assert payload["success"] is True
        assert payload["credits_charged"] == 4.0
        assert payload["credits_delta"] == -4.0
        assert payload["total_before"] == 39.2
        assert payload["total_after"] == 35.2
        assert payload["event_id"] == emitted.event_id
        expected_event_time = emitted.event_time_utc.isoformat().replace("+00:00", "Z")
        assert payload["event_time_utc"] == expected_event_time

        # Contract stays flat for sink-friendliness.
        assert all(not isinstance(value, (dict, list)) for value in payload.values())
    finally:
        handler.setStream(original_stream)


def test_event_log_rejects_unknown_fields() -> None:
    with pytest.raises(ValidationError):
        EventLog(
            user_uid="user_123",
            event_type=EventType.CREDIT_CHECK,
            outcome=EventOutcome.SUCCESS,
            operation="credit_precheck",
            not_allowed="x",
        )


def test_emit_event_log_requires_event_model() -> None:
    logger = build_event_logger("test_event_log_requires_model")

    with pytest.raises(TypeError):
        emit_event_log(
            logger,
            event={"bad": "payload"},
            environment="test",
            service_name="papp-core",
        )
