"""Device parser and validation utilities for Host Link."""

from __future__ import annotations

import re
from dataclasses import dataclass

from .errors import HostLinkProtocolError

SUPPORTED_FORMATS = {"", ".U", ".S", ".D", ".L", ".H"}
BIT_BANK_DEVICE_TYPES = {"R", "MR", "LR", "CR"}
XYM_BIT_DEVICE_TYPES = {"X", "Y"}

# KEYENCE expression + XYM expression
DEVICE_RANGES = {
    "R": (0, 199915, 10),
    "B": (0, 0x7FFF, 16),
    "MR": (0, 399915, 10),
    "LR": (0, 99915, 10),
    "CR": (0, 7915, 10),
    "VB": (0, 0xF9FF, 16),
    "DM": (0, 65534, 10),
    "EM": (0, 65534, 10),
    "FM": (0, 32767, 10),
    "ZF": (0, 524287, 10),
    "W": (0, 0x7FFF, 16),
    "TM": (0, 511, 10),
    "Z": (1, 12, 10),
    "T": (0, 3999, 10),
    "TC": (0, 3999, 10),
    "TS": (0, 3999, 10),
    "C": (0, 3999, 10),
    "CC": (0, 3999, 10),
    "CS": (0, 3999, 10),
    "AT": (0, 7, 10),
    "CM": (0, 7599, 10),
    "VM": (0, 589823, 10),
    "X": (0, 1999 * 16 + 15, 10),
    "Y": (0, 63999 * 16 + 15, 10),
    "M": (0, 63999, 10),
    "L": (0, 15999, 10),
    "D": (0, 65534, 10),
    "E": (0, 65534, 10),
    "F": (0, 32767, 10),
}

FORCE_DEVICE_TYPES = {"R", "B", "MR", "LR", "CR", "T", "C", "VB"}
MBS_DEVICE_TYPES = {"R", "B", "MR", "LR", "CR", "T", "C", "VB", "X", "Y", "M", "L"}
MWS_DEVICE_TYPES = {
    "R",
    "B",
    "MR",
    "LR",
    "CR",
    "VB",
    "X",
    "Y",
    "DM",
    "EM",
    "FM",
    "W",
    "TM",
    "Z",
    "TC",
    "TS",
    "CC",
    "CS",
    "CM",
    "VM",
}
RDC_DEVICE_TYPES = {
    "R",
    "B",
    "MR",
    "LR",
    "CR",
    "DM",
    "EM",
    "FM",
    "ZF",
    "W",
    "TM",
    "Z",
    "T",
    "C",
    "CM",
    "X",
    "Y",
    "M",
    "L",
    "D",
    "E",
    "F",
}
WS_DEVICE_TYPES = {"T", "C"}

DEFAULT_FORMAT_BY_DEVICE_TYPE = {
    "R": "",
    "B": "",
    "MR": "",
    "LR": "",
    "CR": "",
    "VB": "",
    "DM": ".U",
    "EM": ".U",
    "FM": ".U",
    "ZF": ".U",
    "W": ".U",
    "TM": ".U",
    "Z": ".U",
    "AT": ".U",
    "CM": ".U",
    "VM": ".U",
    "T": ".D",
    "TC": ".D",
    "TS": ".D",
    "C": ".D",
    "CC": ".D",
    "CS": ".D",
    # XYM aliases
    "X": "",
    "Y": "",
    "M": "",
    "L": "",
    "D": ".U",
    "E": ".U",
    "F": ".U",
}

_COUNT_CATEGORY_BY_DEVICE_TYPE = {
    # up to 1000 for 16-bit/bit, up to 500 for 32-bit
    "R": "up_to_1000",
    "B": "up_to_1000",
    "MR": "up_to_1000",
    "LR": "up_to_1000",
    "CR": "up_to_1000",
    "VB": "up_to_1000",
    "DM": "up_to_1000",
    "EM": "up_to_1000",
    "FM": "up_to_1000",
    "ZF": "up_to_1000",
    "W": "up_to_1000",
    "CM": "up_to_1000",
    "VM": "up_to_1000",
    "X": "up_to_1000",
    "Y": "up_to_1000",
    "M": "up_to_1000",
    "L": "up_to_1000",
    "D": "up_to_1000",
    "E": "up_to_1000",
    "F": "up_to_1000",
    # up to 512 for 16-bit, up to 256 for 32-bit
    "TM": "tm",
    # up to 12
    "Z": "z",
    # up to 8
    "AT": "at",
    # up to 120
    "T": "t_c",
    "TC": "t_c",
    "TS": "t_c",
    "C": "t_c",
    "CC": "t_c",
    "CS": "t_c",
}

TYPE_PATTERN = "|".join(sorted(DEVICE_RANGES.keys(), key=len, reverse=True))
DEVICE_RE = re.compile(rf"^(?P<type>{TYPE_PATTERN})?(?P<number>[0-9A-F]+)(?P<suffix>\.[USDLH])?$")


@dataclass(frozen=True)
class DeviceAddress:
    device_type: str
    number: int
    suffix: str = ""

    def to_text(self) -> str:
        _, _, base = DEVICE_RANGES[self.device_type]
        if self.device_type in BIT_BANK_DEVICE_TYPES:
            number = _format_bit_bank_number(self.number)
        elif self.device_type in XYM_BIT_DEVICE_TYPES:
            number = _format_xym_bit_number(self.number)
        elif base == 16:
            number = format(self.number, "X")
        else:
            number = str(self.number)
        return f"{self.device_type}{number}{self.suffix}"


def normalize_suffix(suffix: str | None) -> str:
    if not suffix:
        return ""
    s = suffix.upper()
    if not s.startswith("."):
        s = f".{s}"
    if s not in SUPPORTED_FORMATS:
        raise HostLinkProtocolError(f"Unsupported data format suffix: {suffix!r}")
    return s


def parse_device(text: str, *, allow_omitted_type: bool = True) -> DeviceAddress:
    raw = text.strip().upper()
    match = DEVICE_RE.match(raw)
    if not match:
        if allow_omitted_type and raw.isdigit():
            return parse_device(f"R{raw}", allow_omitted_type=False)
        valid_types = ", ".join(sorted(DEVICE_RANGES.keys()))
        raise HostLinkProtocolError(f"Invalid device string {text!r}. Valid device types: {valid_types}")

    device_type = match.group("type") or "R"
    number_text = match.group("number")
    suffix = normalize_suffix(match.group("suffix"))

    lo, hi, base = DEVICE_RANGES[device_type]
    try:
        number = (
            _parse_xym_bit_number(device_type, number_text)
            if device_type in XYM_BIT_DEVICE_TYPES
            else int(number_text, base)
        )
    except HostLinkProtocolError:
        raise
    except ValueError as exc:
        raise HostLinkProtocolError(f"Invalid device number for {device_type}: {number_text!r}") from exc
    if number < lo or number > hi:
        raise HostLinkProtocolError(
            f"Device number out of range: {device_type}{number_text} "
            f"(allowed: {_format_device_number(device_type, lo)}..{_format_device_number(device_type, hi)})"
        )
    if device_type in BIT_BANK_DEVICE_TYPES and number % 100 > 15:
        raise HostLinkProtocolError(
            f"Invalid bit-bank device number: {device_type}{number_text} (lower two digits must be 00..15)"
        )
    return DeviceAddress(device_type=device_type, number=number, suffix=suffix)


def parse_device_text(text: str, *, default_suffix: str = "") -> str:
    """Parse/validate device text and return normalized command token."""
    addr = parse_device(text)
    suffix = normalize_suffix(default_suffix) if default_suffix else addr.suffix
    if suffix != addr.suffix:
        addr = DeviceAddress(addr.device_type, addr.number, suffix)
    return addr.to_text()


def _format_bit_bank_number(number: int) -> str:
    bank = number // 100
    bit = number % 100
    return f"{bank}{bit:02d}"


def _format_xym_bit_number(number: int) -> str:
    bank = number // 16
    bit = number % 16
    return f"{bank}{bit:X}"


def _format_device_number(device_type: str, number: int) -> str:
    if device_type in BIT_BANK_DEVICE_TYPES:
        return _format_bit_bank_number(number)
    if device_type in XYM_BIT_DEVICE_TYPES:
        return _format_xym_bit_number(number)

    _, _, base = DEVICE_RANGES[device_type]
    return format(number, "X") if base == 16 else str(number)


def _parse_xym_bit_number(device_type: str, number_text: str) -> int:
    bank_text = "0" if len(number_text) == 1 else number_text[:-1]
    if not bank_text.isdigit():
        raise HostLinkProtocolError(
            f"Invalid X/Y device number: {device_type}{number_text} "
            "(bank digits must be decimal and bit digit must be 0..F)"
        )

    bank = int(bank_text, 10)
    bit = int(number_text[-1], 16)
    return bank * 16 + bit


def resolve_effective_format(device_type: str, suffix: str) -> str:
    return suffix if suffix else DEFAULT_FORMAT_BY_DEVICE_TYPE.get(device_type, "")


def validate_device_type(command: str, device_type: str, allowed_types: set[str]) -> None:
    if device_type not in allowed_types:
        supported = ", ".join(sorted(allowed_types))
        raise HostLinkProtocolError(
            f"Command '{command}' does not support device type '{device_type}'. Supported types: {supported}"
        )


def validate_device_count(device_type: str, effective_format: str, count: int) -> None:
    category = _COUNT_CATEGORY_BY_DEVICE_TYPE.get(device_type)
    if category is None:
        raise HostLinkProtocolError(f"No count constraint metadata for device type: {device_type}")

    is_32bit = effective_format in {".D", ".L"}
    if category == "up_to_1000":
        lo, hi = (1, 500) if is_32bit else (1, 1000)
    elif category == "tm":
        lo, hi = (1, 256) if is_32bit else (1, 512)
    elif category == "z":
        lo, hi = (1, 12)
    elif category == "at":
        lo, hi = (1, 8)
    elif category == "t_c":
        lo, hi = (1, 120)
    else:
        raise HostLinkProtocolError(f"Unsupported count category: {category}")

    validate_range("count", count, lo, hi)


def validate_device_span(device_type: str, start_number: int, effective_format: str, count: int = 1) -> None:
    lo, hi, _ = DEVICE_RANGES[device_type]
    if count < 1:
        raise HostLinkProtocolError(f"count out of range: {count} (allowed: 1..)")

    word_width = 2 if effective_format in {".D", ".L"} else 1
    end_number = start_number + (count * word_width) - 1
    if start_number < lo or start_number > hi or end_number > hi:
        start_text = _format_device_number(device_type, start_number)
        end_text = _format_device_number(device_type, end_number)
        raise HostLinkProtocolError(
            f"Device span out of range: {device_type}{start_text}..{device_type}{end_text} "
            f"with format '{effective_format}'"
        )


def validate_expansion_buffer_count(effective_format: str, count: int) -> None:
    lo, hi = (1, 500) if effective_format in {".D", ".L"} else (1, 1000)
    validate_range("count", count, lo, hi)


def validate_expansion_buffer_span(address: int, effective_format: str, count: int) -> None:
    if count < 1:
        raise HostLinkProtocolError(f"count out of range: {count} (allowed: 1..)")

    word_width = 2 if effective_format in {".D", ".L"} else 1
    end_address = address + (count * word_width) - 1
    if address < 0 or address > 59999 or end_address > 59999:
        raise HostLinkProtocolError(
            f"Expansion buffer span out of range: {address}..{end_address} with format '{effective_format}'"
        )


def validate_range(name: str, value: int, lo: int, hi: int) -> None:
    if value < lo or value > hi:
        raise HostLinkProtocolError(f"{name} out of range: {value} (allowed: {lo}..{hi})")
