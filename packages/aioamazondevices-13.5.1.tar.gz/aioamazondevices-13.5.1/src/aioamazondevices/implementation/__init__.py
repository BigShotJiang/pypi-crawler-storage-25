"""Amazon devices implementation package."""
