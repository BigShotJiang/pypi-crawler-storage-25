# privaterag-langchain

Thin LangChain retriever adapter for the core PrivateRAG Python SDK.

The adapter keeps LangChain imports isolated to this package. The core
`privaterag` SDK does not import LangChain.

## Install

Published packages declare the core `privaterag` SDK as a dependency. If
LangChain is not already present in the environment, install the optional extra:

```bash
python -m pip install privaterag-langchain[langchain]
```

The v0 supported framework range is `langchain-core>=1.0,<1.4`; see
`../../docs/adapter_compatibility.md` for the tested lower-bound and
current-version matrix.

For local editable development:

```bash
python -m pip install -e python/privaterag
python -m pip install -e "python/privaterag-langchain[langchain]"
```

## Usage

```python
from privaterag import PrivateRAGClient
from privaterag_langchain import PrivateRAGRetriever

client = PrivateRAGClient.from_manifest(
    "http://127.0.0.1:18090/manifest.json",
    embed_query=local_embed_query,
)

retriever = PrivateRAGRetriever(
    client,
    top_k=2,
    retrieval_count=4,
)

documents = retriever.get_relevant_documents("What needs review before onboarding?")
```

`top_k` must be positive. `retrieval_count`, when provided, must be positive
and greater than or equal to `top_k`; otherwise the adapter fails before
delegating to the SDK. See `../../docs/padding_policy.md`.

Returned LangChain `Document` objects use retrieved chunk text as
`page_content`. Metadata includes the original chunk metadata plus
`chunk_id`, `document_id` when present, `score` when present, and namespaced
`privaterag_*` copies of those retrieval fields.

The adapter delegates retrieval to `privaterag.PrivateRAGClient`. It does not
implement embedding providers, LLM calls, reranking, server-side vector search,
or direct chunk lookup. The current supported `simplepir-rs-v0-1000-1k` backend
is supported only within its documented v0 limits and remains unaudited, not
externally audited, and not production-grade cryptographic assurance. The old
`simplepir-rs-experimental-v0` profile remains smoke-scale, experimental,
unaudited, and compatibility/development-only.
