"""LangChain retriever adapter for the PrivateRAG Python SDK."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Sequence

try:
    import pydantic
    from pydantic import ConfigDict
except ImportError:
    ConfigDict = None
    _PYDANTIC_MAJOR_VERSION = 0
else:
    _PYDANTIC_MAJOR_VERSION = int(pydantic.version.VERSION.split(".", maxsplit=1)[0])

_USE_PYDANTIC_V2_CONFIG = ConfigDict is not None and _PYDANTIC_MAJOR_VERSION >= 2
DEFAULT_TOP_K = 2
DEFAULT_RETRIEVAL_COUNT = 4


class LangChainDependencyError(ImportError):
    """Raised when the LangChain adapter is used without LangChain installed."""


def _load_langchain_types() -> tuple[type[Any] | None, type[Any], BaseException | None]:
    try:
        from langchain_core.documents import Document
        from langchain_core.retrievers import BaseRetriever

        return Document, BaseRetriever, None
    except ImportError as first_error:
        try:
            from langchain.schema import BaseRetriever, Document

            return Document, BaseRetriever, None
        except ImportError:
            try:
                from langchain.schema import Document
                from langchain.schema.retriever import BaseRetriever

                return Document, BaseRetriever, None
            except ImportError:
                return None, object, first_error


_LANGCHAIN_DOCUMENT, _LANGCHAIN_BASE_RETRIEVER, _LANGCHAIN_IMPORT_ERROR = _load_langchain_types()


def _require_langchain() -> None:
    if _LANGCHAIN_IMPORT_ERROR is None and _LANGCHAIN_DOCUMENT is not None:
        return
    raise LangChainDependencyError(
        "privaterag-langchain requires LangChain document/retriever classes. "
        "Install langchain-core or install this package with its langchain extra."
    ) from _LANGCHAIN_IMPORT_ERROR


def _validate_retrieval_options(
    *,
    top_k: int,
    retrieval_count: int | None,
    timeout_seconds: float | None,
) -> None:
    if top_k <= 0:
        raise ValueError("top_k must be positive")
    if retrieval_count is not None and retrieval_count <= 0:
        raise ValueError("retrieval_count must be positive")
    if retrieval_count is not None and retrieval_count < top_k:
        raise ValueError("retrieval_count must be greater than or equal to top_k")
    if timeout_seconds is not None and timeout_seconds <= 0:
        raise ValueError("timeout_seconds must be positive")


class PrivateRAGRetriever(_LANGCHAIN_BASE_RETRIEVER):
    """Thin LangChain retriever wrapper around ``privaterag.PrivateRAGClient``."""

    private_rag_client: Any
    top_k: int = DEFAULT_TOP_K
    retrieval_count: int | None = None
    timeout_seconds: float | None = None

    if _USE_PYDANTIC_V2_CONFIG:
        model_config = ConfigDict(arbitrary_types_allowed=True)
    else:

        class Config:
            arbitrary_types_allowed = True

    def __init__(
        self,
        client: Any | None = None,
        *,
        private_rag_client: Any | None = None,
        top_k: int = DEFAULT_TOP_K,
        retrieval_count: int | None = None,
        timeout_seconds: float | None = None,
        **kwargs: Any,
    ) -> None:
        _require_langchain()
        if client is not None and private_rag_client is not None:
            raise ValueError("pass either client or private_rag_client, not both")
        resolved_client = private_rag_client if private_rag_client is not None else client
        if resolved_client is None:
            raise ValueError("PrivateRAGRetriever requires a PrivateRAGClient instance")
        _validate_retrieval_options(
            top_k=top_k,
            retrieval_count=retrieval_count,
            timeout_seconds=timeout_seconds,
        )

        values = {
            "private_rag_client": resolved_client,
            "top_k": top_k,
            "retrieval_count": retrieval_count,
            "timeout_seconds": timeout_seconds,
            **kwargs,
        }
        try:
            super().__init__(**values)
        except TypeError:
            super().__init__()
            for name, value in values.items():
                setattr(self, name, value)

    @classmethod
    def from_manifest(
        cls,
        manifest_url: str,
        *,
        cache_dir: str | Path | None = None,
        embed: Callable[[str], Sequence[float]] | None = None,
        embed_query: Callable[[str], Sequence[float]] | None = None,
        top_k: int = DEFAULT_TOP_K,
        retrieval_count: int = DEFAULT_RETRIEVAL_COUNT,
        timeout_seconds: float = 30.0,
        **kwargs: Any,
    ) -> "PrivateRAGRetriever":
        """Create a retriever from a PrivateRAG manifest URL."""

        _require_langchain()
        _validate_retrieval_options(
            top_k=top_k,
            retrieval_count=retrieval_count,
            timeout_seconds=timeout_seconds,
        )
        from privaterag import PrivateRAGClient

        client = PrivateRAGClient.from_manifest(
            manifest_url,
            cache_dir=cache_dir,
            retrieval_count=retrieval_count,
            timeout_seconds=timeout_seconds,
            embed=embed,
            embed_query=embed_query,
        )
        return cls(
            private_rag_client=client,
            top_k=top_k,
            retrieval_count=retrieval_count,
            timeout_seconds=timeout_seconds,
            **kwargs,
        )

    def _get_relevant_documents(
        self,
        query: str,
        *,
        run_manager: Any | None = None,
    ) -> list[Any]:
        del run_manager
        return self.retrieve_documents(query)

    def retrieve_documents(
        self,
        query: str,
        *,
        top_k: int | None = None,
        retrieval_count: int | None = None,
        timeout_seconds: float | None = None,
    ) -> list[Any]:
        """Retrieve PrivateRAG chunks and convert them to LangChain documents."""

        resolved_top_k = self.top_k if top_k is None else top_k
        resolved_retrieval_count = (
            self.retrieval_count if retrieval_count is None else retrieval_count
        )
        resolved_timeout_seconds = (
            self.timeout_seconds if timeout_seconds is None else timeout_seconds
        )
        _validate_retrieval_options(
            top_k=resolved_top_k,
            retrieval_count=resolved_retrieval_count,
            timeout_seconds=resolved_timeout_seconds,
        )
        result = self.private_rag_client.retrieve(
            query,
            top_k=resolved_top_k,
            retrieval_count=resolved_retrieval_count,
            timeout_seconds=resolved_timeout_seconds,
        )
        return [self._chunk_to_document(chunk) for chunk in result.chunks]

    def get_relevant_documents(self, query: str) -> list[Any]:
        """Compatibility wrapper for older LangChain retriever callers."""

        return self.retrieve_documents(query)

    def invoke(
        self,
        input: str,
        config: Any | None = None,
        **kwargs: Any,
    ) -> list[Any]:
        """Fallback invoke implementation for tests and lightweight stubs."""

        if hasattr(super(), "invoke"):
            return super().invoke(input, config=config, **kwargs)
        del config, kwargs
        return self.retrieve_documents(input)

    def _chunk_to_document(self, chunk: Any) -> Any:
        _require_langchain()
        metadata = dict(getattr(chunk, "metadata", {}) or {})
        chunk_id = getattr(chunk, "chunk_id")
        document_id = getattr(chunk, "document_id", None)
        score = getattr(chunk, "score", None)

        metadata["privaterag_chunk_id"] = chunk_id
        metadata.setdefault("chunk_id", chunk_id)
        if document_id is not None:
            metadata["privaterag_document_id"] = document_id
            metadata.setdefault("document_id", document_id)
        if score is not None:
            metadata["privaterag_score"] = score
            metadata.setdefault("score", score)

        return _LANGCHAIN_DOCUMENT(
            page_content=getattr(chunk, "text"),
            metadata=metadata,
        )


__all__ = ["LangChainDependencyError", "PrivateRAGRetriever"]
