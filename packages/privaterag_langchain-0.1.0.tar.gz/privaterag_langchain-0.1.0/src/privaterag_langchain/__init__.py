"""LangChain adapter package for PrivateRAG."""

from dataclasses import dataclass

from .retriever import LangChainDependencyError, PrivateRAGRetriever

__version__ = "0.1.0"


@dataclass(frozen=True)
class PackageBoundary:
    """Describes a Python package responsibility boundary."""

    name: str
    responsibility: str


LANGCHAIN_BOUNDARY = PackageBoundary(
    name="privaterag-langchain",
    responsibility="thin LangChain retriever adapter for the PrivateRAG client SDK",
)

__all__ = [
    "LANGCHAIN_BOUNDARY",
    "LangChainDependencyError",
    "PackageBoundary",
    "PrivateRAGRetriever",
    "__version__",
]
