"""AWS Braket backend via qiskit-braket-provider.

Same shape as `IBMBackend`: a thin specialisation of `QiskitBackend`
that names devices `braket.<device>` and provides a `from_env()`
classmethod for the production path.

For tests we use `BraketLocalBackend` from `qiskit_braket_provider`
— an offline AWS Braket simulator that requires no AWS credentials.
Real submission to SV1/DM1/TN1 simulators or Rigetti/IonQ/OQC QPUs
goes through `BraketProvider`, which uses standard AWS credentials
(env vars, `~/.aws/credentials`, IAM roles) via boto3.
"""

import os
from typing import Any

from qbron.backend import BackendError
from qbron.qiskit_backend import QiskitBackend

# Default to Braket's general-purpose state-vector simulator. Cheap,
# always available, and a sensible "I just want to try it" target.
_DEFAULT_DEVICE_ARN = (
    "arn:aws:braket:::device/quantum-simulator/amazon/sv1"
)


class BraketBackend(QiskitBackend):
    def __init__(self, qiskit_backend: Any) -> None:
        device = getattr(qiskit_backend, "name", "unknown")
        super().__init__(qiskit_backend, name=f"braket.{device}")

    @classmethod
    def from_env(cls, device_arn: str | None = None) -> "BraketBackend":
        """Construct a BraketBackend from AWS creds in the environment.

        Standard AWS env vars are picked up by boto3 under the hood:
        `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY` /
        `AWS_DEFAULT_REGION`, or `AWS_PROFILE`. We sanity-check at
        least one of these is set so the user gets a clear error
        instead of a deep boto3 stack trace.
        """
        if not (
            os.environ.get("AWS_ACCESS_KEY_ID")
            or os.environ.get("AWS_PROFILE")
        ):
            raise BackendError(
                "AWS credentials not found. "
                "Set AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY (and "
                "AWS_DEFAULT_REGION), or AWS_PROFILE, before calling "
                "BraketBackend.from_env()."
            )
        from qiskit_braket_provider import BraketProvider

        provider = BraketProvider()
        return cls(provider.get_backend(device_arn or _DEFAULT_DEVICE_ARN))
