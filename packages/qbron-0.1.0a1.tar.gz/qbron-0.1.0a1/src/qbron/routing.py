"""Smart routing: pick the cheapest backend that can run a circuit.

This is the differentiator the business plan calls out (`Vercel for
quantum` / `LiteLLM for QPUs`): write a circuit once, route it to
whichever connected backend is cheapest and capable. Today the
selection is simple — capability filter, then minimum cost.amount —
but the function signature is the surface that smarter policies
(latency-aware, queue-depth-aware, currency-converting) will plug
into later.
"""

from typing import Iterable

from qbron.backend import Backend, BackendError, validate
from qbron.circuit import Circuit
from qbron.cost import convert


def route(
    circuit: Circuit,
    shots: int,
    backends: Iterable[Backend],
    target_currency: str = "USD",
) -> Backend:
    """Return the cheapest backend able to run `circuit` for `shots` shots.

    Costs are normalised to `target_currency` before comparison via
    `qbron.cost.convert`, so a 100 SEK quote and a 50 USD quote get
    compared honestly. `free` always normalises to 0 and beats any
    priced offer.

    Capability mismatches are silently skipped; `BackendError` is
    raised only when *no* backend in the list fits.
    """
    candidates: list[tuple[float, Backend]] = []
    for backend in backends:
        try:
            validate(circuit, backend.capabilities())
        except BackendError:
            continue
        cost = backend.estimate_cost(circuit, shots)
        normalised = convert(cost, target_currency)
        candidates.append((normalised.amount, backend))

    if not candidates:
        gates_used = sorted(
            {getattr(g, "qasm_name", type(g).__name__) for g in circuit.gates}
        )
        raise BackendError(
            f"no available backend supports this circuit "
            f"({circuit.num_qubits} qubits, gates: {gates_used})"
        )
    candidates.sort(key=lambda c: c[0])
    return candidates[0][1]
