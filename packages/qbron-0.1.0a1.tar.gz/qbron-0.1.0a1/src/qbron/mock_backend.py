"""A pretend remote backend for tests, demos, and CLI smoke runs.

Wraps a `LocalSimulator` so the counts are real, but advertises smaller
capabilities and a priced cost so it exercises the same code paths that
a real provider (IBM, IQM, …) will: capability rejection, cost
estimation, currency-aware billing. No network, no credentials.
"""

from qbron.backend import Capabilities, Cost, RunResult, validate
from qbron.circuit import Circuit
from qbron.simulator import LocalSimulator

# Deliberately tighter than LocalSimulator so capability-mismatch paths
# show up in tests. A real provider will look much like this.
_MAX_QUBITS = 5
_GATE_SET = frozenset(
    {"h", "x", "y", "z", "s", "sdg", "t", "tdg", "cx", "rx", "ry", "rz", "measure"}
)

# Fake price: 1 öre per shot. Real backends will read from a price table.
_SEK_PER_SHOT = 0.01


class MockRemoteBackend:
    name = "mock"

    def __init__(self, seed: int | None = None) -> None:
        self._inner = LocalSimulator(seed=seed)

    def capabilities(self) -> Capabilities:
        return Capabilities(max_qubits=_MAX_QUBITS, gate_set=_GATE_SET)

    def estimate_cost(self, circuit: Circuit, shots: int) -> Cost:
        return Cost(currency="SEK", amount=shots * _SEK_PER_SHOT)

    def run(self, circuit: Circuit, shots: int) -> RunResult:
        validate(circuit, self.capabilities())
        return self._inner.run(circuit, shots)
