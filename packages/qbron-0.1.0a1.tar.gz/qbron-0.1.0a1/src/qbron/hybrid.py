"""Hybrid classical-quantum optimisation primitives.

The dominant near-term-useful quantum algorithms (VQE, QAOA) all share
one shape: a parameterised quantum ansatz produces an expectation
value, a classical optimiser iterates the parameters to minimise it.
This module provides the classical half — the inner-loop driver — so
end-users can write `objective(params) -> float` without re-deriving
finite-difference gradients each time.

Sketched cost model: each gradient_descent iteration evaluates the
objective `2N + 1` times (N parameters, central finite difference plus
the logging value). For a VQE objective backed by `Backend.run()`,
that's roughly `(2N + 1) × shots` backend submissions per iteration.
"""

from dataclasses import dataclass, field
from typing import Callable


@dataclass(frozen=True)
class OptimizationResult:
    """Outcome of a hybrid optimisation run."""

    params: list[float]
    value: float
    history: list[float] = field(default_factory=list)
    iterations: int = 0
    converged: bool = False


def gradient_descent(
    objective: Callable[[list[float]], float],
    initial_params: list[float],
    learning_rate: float = 0.3,
    epsilon: float = 0.01,
    max_iterations: int = 50,
    tolerance: float = 1e-3,
) -> OptimizationResult:
    """Finite-difference gradient descent.

    Generic enough to drive any `(params: list[float]) -> float`
    objective: pure-classical functions for testing the optimiser, or
    `lambda p: backend.run(circuit_at(p), shots).expectation()` for
    VQE/QAOA-shape problems.

    Convergence is declared when the largest gradient component drops
    below `tolerance`. With shot-noise objectives, set `tolerance`
    above the noise floor (sampling noise ≈ 1/√shots).
    """
    params = list(initial_params)
    history: list[float] = []
    converged = False
    iterations = 0

    for iterations in range(1, max_iterations + 1):
        history.append(objective(params))

        gradient: list[float] = []
        for j in range(len(params)):
            plus = params.copy()
            plus[j] += epsilon
            minus = params.copy()
            minus[j] -= epsilon
            gradient.append((objective(plus) - objective(minus)) / (2 * epsilon))

        if max(abs(g) for g in gradient) < tolerance:
            converged = True
            break

        params = [p - learning_rate * g for p, g in zip(params, gradient)]

    final_value = objective(params)
    history.append(final_value)

    return OptimizationResult(
        params=params,
        value=final_value,
        history=history,
        iterations=iterations,
        converged=converged,
    )
