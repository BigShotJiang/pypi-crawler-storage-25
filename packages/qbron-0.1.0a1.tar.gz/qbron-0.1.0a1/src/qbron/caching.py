"""Result caching: memoise (circuit, backend, shots) → RunResult.

Iterative quantum development re-runs the same circuit constantly
(VQE inner loops, debugging, parameter sweeps repeating an outer
circuit). The cache turns those into free local lookups instead of
repeated paid hits to a remote backend.

Cache key: `(hash(circuit), inner.name, shots)`. Circuits are frozen
dataclasses with hashable gate tuples, so `hash(circuit)` is exact and
fast — no need to round-trip through QASM.
"""

from typing import MutableMapping

from qbron.backend import Backend, Capabilities, Cost, RunResult
from qbron.circuit import Circuit


class CachedBackend:
    """Decorator backend that caches identical (circuit, shots) calls.

    The wrapped `inner` backend is hit only on cache misses; subsequent
    calls with the same circuit + shots return the stored `RunResult`.
    `estimate_cost()` reports the inner cost on misses and free on
    hits, so smart routing can pick a warm cache over a cold paid run.
    """

    def __init__(
        self,
        inner: Backend,
        cache: MutableMapping[tuple, RunResult] | None = None,
    ) -> None:
        self._inner = inner
        self._cache: MutableMapping[tuple, RunResult] = (
            cache if cache is not None else {}
        )
        self.name = f"cached.{inner.name}"

    def capabilities(self) -> Capabilities:
        return self._inner.capabilities()

    def estimate_cost(self, circuit: Circuit, shots: int) -> Cost:
        if self._key(circuit, shots) in self._cache:
            return Cost(currency="free", amount=0.0)
        return self._inner.estimate_cost(circuit, shots)

    def run(self, circuit: Circuit, shots: int) -> RunResult:
        key = self._key(circuit, shots)
        cached = self._cache.get(key)
        if cached is not None:
            return cached
        result = self._inner.run(circuit, shots)
        self._cache[key] = result
        return result

    def _key(self, circuit: Circuit, shots: int) -> tuple:
        return (hash(circuit), self._inner.name, shots)
