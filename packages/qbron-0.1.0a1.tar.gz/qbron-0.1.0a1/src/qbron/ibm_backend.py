"""IBM Quantum hardware backend.

Production:
    backend = IBMBackend.from_env("ibm_brisbane")  # reads QBRON_IBM_TOKEN

Tests:
    from qiskit_ibm_runtime.fake_provider import FakeBrisbane
    backend = IBMBackend(FakeBrisbane())

`IBMBackend` is a thin specialisation of `QiskitBackend` — it just
prefixes the name with `ibm.<device>` and provides the env-var-based
constructor for the real-hardware path. The actual circuit submission
goes through Qiskit's transpile + backend.run pipeline.
"""

import os
from typing import Any

from qbron.backend import BackendError
from qbron.qiskit_backend import QiskitBackend


class IBMBackend(QiskitBackend):
    def __init__(self, qiskit_backend: Any) -> None:
        device = getattr(qiskit_backend, "name", "unknown")
        super().__init__(qiskit_backend, name=f"ibm.{device}")

    @classmethod
    def from_env(cls, backend_name: str = "ibm_brisbane") -> "IBMBackend":
        """Construct an IBMBackend from the QBRON_IBM_TOKEN env var.

        Raises BackendError with a clear message if the token is
        missing — credentials must be set explicitly so users don't
        accidentally hit production providers from a test environment.
        """
        token = os.environ.get("QBRON_IBM_TOKEN")
        if not token:
            raise BackendError(
                "QBRON_IBM_TOKEN is not set. "
                "Get a token at https://quantum.ibm.com and "
                "export QBRON_IBM_TOKEN=<token> before calling from_env()."
            )
        from qiskit_ibm_runtime import QiskitRuntimeService

        service = QiskitRuntimeService(token=token, channel="ibm_quantum")
        return cls(service.backend(backend_name))
