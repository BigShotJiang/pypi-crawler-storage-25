"""Backend Protocol and shared result/capability types.

`Backend` is the structural contract that every concrete backend
(`LocalSimulator`, `MockRemoteBackend`, future `IBMBackend` …) must
satisfy. It is `runtime_checkable` so tests can `isinstance(b, Backend)`
without dependency injection scaffolding.
"""

from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from qbron.circuit import Circuit


class BackendError(RuntimeError):
    """Raised when a backend rejects a circuit or run request."""


@dataclass(frozen=True)
class Capabilities:
    """What a backend can run.

    Connectivity and noise model are deferred until a real noisy backend
    needs them — current users can route around incompatibility by gate
    set and qubit count alone.
    """

    max_qubits: int
    gate_set: frozenset[str]


@dataclass(frozen=True)
class Cost:
    """Estimated cost for a single run.

    `currency="free"` is reserved for local / simulator backends. Real
    providers use ISO 4217 codes ("SEK", "USD", "EUR").
    """

    currency: str
    amount: float


@dataclass(frozen=True)
class RunResult:
    """Outcome of a backend run — measurement counts keyed by bitstring."""

    counts: dict[str, int]


@runtime_checkable
class Backend(Protocol):
    """Structural contract for anything that can execute a Circuit."""

    name: str

    def capabilities(self) -> Capabilities: ...

    def estimate_cost(self, circuit: Circuit, shots: int) -> Cost: ...

    def run(self, circuit: Circuit, shots: int) -> RunResult: ...


def validate(circuit: Circuit, capabilities: Capabilities) -> None:
    """Raise BackendError if the circuit can't run on this backend.

    Backends should call this from `run()` before doing any real work, so
    a misconfigured client gets a clear error at the boundary instead of
    a confusing failure deep inside execution.
    """
    if circuit.num_qubits > capabilities.max_qubits:
        raise BackendError(
            f"circuit needs {circuit.num_qubits} qubits, "
            f"backend supports at most {capabilities.max_qubits}"
        )
    for gate in circuit.gates:
        name = getattr(gate, "qasm_name", None)
        if name is None or name not in capabilities.gate_set:
            raise BackendError(
                f"backend does not support gate {name!r} "
                f"(supported: {sorted(capabilities.gate_set)})"
            )
