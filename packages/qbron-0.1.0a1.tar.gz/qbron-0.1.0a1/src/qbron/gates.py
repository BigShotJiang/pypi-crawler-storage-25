from dataclasses import dataclass
from typing import ClassVar


@dataclass(frozen=True)
class H:
    qasm_name: ClassVar[str] = "h"
    target: int


@dataclass(frozen=True)
class X:
    qasm_name: ClassVar[str] = "x"
    target: int


@dataclass(frozen=True)
class Y:
    qasm_name: ClassVar[str] = "y"
    target: int


@dataclass(frozen=True)
class Z:
    qasm_name: ClassVar[str] = "z"
    target: int


@dataclass(frozen=True)
class S:
    qasm_name: ClassVar[str] = "s"
    target: int


@dataclass(frozen=True)
class Sdg:
    """Adjoint of S: matrix [[1, 0], [0, -i]]. Inverse satisfies S·S† = I."""

    qasm_name: ClassVar[str] = "sdg"
    target: int


@dataclass(frozen=True)
class T:
    qasm_name: ClassVar[str] = "t"
    target: int


@dataclass(frozen=True)
class Tdg:
    """Adjoint of T: matrix [[1, 0], [0, exp(-iπ/4)]]."""

    qasm_name: ClassVar[str] = "tdg"
    target: int


@dataclass(frozen=True)
class CX:
    qasm_name: ClassVar[str] = "cx"
    control: int
    target: int


@dataclass(frozen=True)
class RX:
    """Single-qubit X-axis rotation. Matrix:
    [[cos(θ/2), -i sin(θ/2)], [-i sin(θ/2), cos(θ/2)]]."""

    qasm_name: ClassVar[str] = "rx"
    target: int
    theta: float


@dataclass(frozen=True)
class RY:
    """Single-qubit Y-axis rotation by angle `theta` (radians).

    Matrix: [[cos(θ/2), -sin(θ/2)], [sin(θ/2), cos(θ/2)]].
    The first parameterised gate qbron supports — required by hybrid
    classical-quantum optimisation (VQE/QAOA).
    """

    qasm_name: ClassVar[str] = "ry"
    target: int
    theta: float


@dataclass(frozen=True)
class RZ:
    """Single-qubit Z-axis rotation. Matrix:
    [[exp(-iθ/2), 0], [0, exp(iθ/2)]]."""

    qasm_name: ClassVar[str] = "rz"
    target: int
    theta: float


@dataclass(frozen=True)
class Measure:
    qasm_name: ClassVar[str] = "measure"
    target: int
