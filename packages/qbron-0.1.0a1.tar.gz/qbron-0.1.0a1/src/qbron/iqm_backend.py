"""IQM Resonance hardware backend (Nordic-sovereignty story).

Same shape as `IBMBackend`: a thin specialisation of `QiskitBackend`
that names the device `iqm.<name>` and provides `from_env()` for
production use.

**Current status:** the upstream `qiskit-iqm` package pins
`qiskit < 2` and `qiskit-aer < 0.16`, which conflicts with our
`qiskit==2.x` runtime. Until that's resolved, `IQMBackend(qiskit_backend)`
works for users who plumb in a Qiskit-compatible IQM backend by hand,
and `from_env()` raises a clear error pointing at the dep conflict.

When `qiskit-iqm` ships a release compatible with qiskit 2.x, replace
the body of `from_env` with:

    from qiskit_iqm import IQMProvider
    provider = IQMProvider("https://iqm.example.com/cocos", token=token)
    return cls(provider.get_backend(station))
"""

import os
from typing import Any

from qbron.backend import BackendError
from qbron.qiskit_backend import QiskitBackend


class IQMBackend(QiskitBackend):
    def __init__(self, qiskit_backend: Any) -> None:
        device = getattr(qiskit_backend, "name", "unknown")
        super().__init__(qiskit_backend, name=f"iqm.{device}")

    @classmethod
    def from_env(cls, station: str = "garnet") -> "IQMBackend":
        """Construct an IQMBackend from QBRON_IQM_TOKEN.

        Currently raises BackendError because `qiskit-iqm` is
        incompatible with our pinned qiskit version. The error
        message is intentionally specific so users know the path
        forward (install qiskit-iqm manually once it supports
        qiskit 2.x, then construct IQMBackend(provider.get_backend(...)).
        """
        token = os.environ.get("QBRON_IQM_TOKEN")
        if not token:
            raise BackendError(
                "QBRON_IQM_TOKEN is not set. "
                "Get a token from your IQM Resonance account and "
                "export QBRON_IQM_TOKEN=<token> before calling from_env()."
            )
        try:
            from qiskit_iqm import IQMProvider  # type: ignore[import-not-found]
        except ImportError as exc:
            raise BackendError(
                "qiskit-iqm is not installed and currently has a "
                "dependency conflict with qiskit>=2 (it pins qiskit<2). "
                "Until upstream catches up, instantiate IQMBackend "
                "directly: IQMBackend(provider.get_backend(...)). "
                f"(import error: {exc})"
            ) from exc
        provider = IQMProvider(
            os.environ.get("QBRON_IQM_URL", "https://demo.qc.iqm.fi/cocos"),
            token=token,
        )
        return cls(provider.get_backend(station))
