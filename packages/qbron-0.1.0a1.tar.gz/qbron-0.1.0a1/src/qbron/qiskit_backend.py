"""QiskitBackend — adapter from qbron's Backend Protocol to any Qiskit backend.

Wraps a Qiskit `BackendV2` (e.g. `AerSimulator`, `FakeBackendV2` from the
fake_provider, or a real IBM hardware backend obtained via
`QiskitRuntimeService.backend(...)`). The qbron Circuit is translated
through OpenQASM 3.0 — the lingua franca we already round-trip — so the
adapter doesn't need to know about Qiskit's gate classes.

Endianness: Qiskit emits bitstrings with the highest-indexed classical
bit on the left; qbron's convention is qubit 0 on the left. We reverse
each key on the way out, matching the pattern in test_aer_parity.py.
"""

from typing import Any

from qiskit import qasm3, transpile

from qbron.backend import Capabilities, Cost, RunResult, validate
from qbron.circuit import Circuit
from qbron.gates import Measure

# Gates qbron knows how to emit. The capabilities of the wrapped backend
# are intersected with this set, so we never advertise a gate the
# emitter can't produce.
_QBRON_EMITTABLE: frozenset[str] = frozenset(
    {"h", "x", "y", "z", "s", "sdg", "t", "tdg", "cx", "rx", "ry", "rz", "measure"}
)


class QiskitBackend:
    def __init__(self, qiskit_backend: Any, name: str | None = None) -> None:
        self._backend = qiskit_backend
        self.name = name or getattr(qiskit_backend, "name", "qiskit") or "qiskit"

    def capabilities(self) -> Capabilities:
        # The wrapped backend's *native* gate set is an implementation
        # detail handled by Qiskit's transpiler in run(); from qbron's
        # point of view we accept anything the emitter can produce.
        max_qubits = getattr(self._backend, "num_qubits", None)
        if max_qubits is None:
            max_qubits = self._backend.configuration().n_qubits
        return Capabilities(max_qubits=max_qubits, gate_set=_QBRON_EMITTABLE)

    def estimate_cost(self, circuit: Circuit, shots: int) -> Cost:
        # Real-hardware pricing comes from per-provider price tables in
        # later phases; for now we recognise simulator backends as free
        # and stub a placeholder cost for everything else.
        if "simulator" in self.name.lower() or "aer" in self.name.lower():
            return Cost(currency="free", amount=0.0)
        return Cost(currency="USD", amount=shots * 0.001)

    def run(self, circuit: Circuit, shots: int) -> RunResult:
        validate(circuit, self.capabilities())
        qc = qasm3.loads(circuit.to_qasm())
        if not any(isinstance(g, Measure) for g in circuit.gates):
            qc.measure_all()
        # Lower to the backend's native gate set. No-op for general-purpose
        # simulators; required for hardware where the basis gate set is
        # narrow (e.g. ecr/sx/rz on IBM).
        qc = transpile(qc, self._backend)
        result = self._backend.run(qc, shots=shots).result()
        raw = result.get_counts()
        # Qiskit puts the highest classical bit leftmost; we reverse so
        # qubit 0 (or first measure) ends up leftmost. Spaces appear when
        # multiple classical registers are present — we don't generate
        # those, but stripping is cheap insurance.
        return RunResult(counts={key.replace(" ", "")[::-1]: v for key, v in raw.items()})
