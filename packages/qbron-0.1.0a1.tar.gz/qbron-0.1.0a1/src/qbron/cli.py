from enum import Enum
from pathlib import Path
from typing import Optional

import typer

from qbron.backend import Backend, BackendError
from qbron.circuit import Circuit
from qbron.mock_backend import MockRemoteBackend
from qbron.routing import route
from qbron.simulator import LocalSimulator

app = typer.Typer(
    help="Qbron — unified SDK for quantum backends.",
    no_args_is_help=True,
    add_completion=False,
)


class BackendChoice(str, Enum):
    local = "local"
    mock = "mock"
    aer = "aer"
    ibm = "ibm"
    braket = "braket"
    braket_local = "braket-local"
    azure = "azure"
    auto = "auto"


def _build_backend(choice: BackendChoice, seed: Optional[int]) -> Backend:
    if choice is BackendChoice.local:
        return LocalSimulator(seed=seed)
    if choice is BackendChoice.mock:
        return MockRemoteBackend(seed=seed)
    # Qiskit-based backends are imported lazily so the local/mock paths
    # don't pay the qiskit import cost (~hundreds of ms) on every CLI
    # invocation.
    if choice is BackendChoice.aer:
        from qiskit_aer import AerSimulator

        from qbron.qiskit_backend import QiskitBackend

        return QiskitBackend(AerSimulator())
    if choice is BackendChoice.ibm:
        from qbron.ibm_backend import IBMBackend

        return IBMBackend.from_env()
    if choice is BackendChoice.braket:
        from qbron.braket_backend import BraketBackend

        return BraketBackend.from_env()
    if choice is BackendChoice.braket_local:
        from qiskit_braket_provider import BraketLocalBackend

        from qbron.braket_backend import BraketBackend

        return BraketBackend(BraketLocalBackend())
    if choice is BackendChoice.azure:
        from qbron.azure_backend import AzureBackend

        return AzureBackend.from_env()
    raise typer.BadParameter(f"unknown backend: {choice}")


@app.callback()
def _root() -> None:
    """Force Typer to treat 'run' as a subcommand even while it's the only one."""


@app.command()
def run(
    qasm_path: Path = typer.Argument(
        ...,
        exists=True,
        readable=True,
        help="Path to an OpenQASM 3.0 source file.",
    ),
    shots: int = typer.Option(1000, "--shots", "-n", help="Number of shots."),
    seed: Optional[int] = typer.Option(
        None, "--seed", "-s", help="RNG seed for reproducibility."
    ),
    backend: BackendChoice = typer.Option(
        BackendChoice.local,
        "--backend",
        "-b",
        case_sensitive=False,
        help="Which backend to run on.",
    ),
) -> None:
    """Run a circuit on the chosen backend and print measurement counts."""
    try:
        circuit = Circuit.from_qasm(qasm_path.read_text())
        if backend is BackendChoice.auto:
            # Free-tier auto routing: only credential-less backends are
            # candidates so the CLI never silently bills the user.
            backend_impl = route(
                circuit,
                shots,
                backends=[LocalSimulator(seed=seed), MockRemoteBackend(seed=seed)],
            )
        else:
            backend_impl = _build_backend(backend, seed)
        result = backend_impl.run(circuit, shots=shots)
    except BackendError as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(code=1)
    for bitstring in sorted(result.counts):
        typer.echo(f"{bitstring}: {result.counts[bitstring]}")


def main() -> None:
    app()


if __name__ == "__main__":
    main()
