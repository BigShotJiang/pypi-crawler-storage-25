from dataclasses import dataclass, field, replace
from typing import Union

from openqasm3 import ast
from openqasm3.parser import parse as _parse_qasm

from qbron.gates import CX, RX, RY, RZ, H, Measure, S, Sdg, T, Tdg, X, Y, Z

Gate = Union[H, X, Y, Z, S, Sdg, T, Tdg, CX, RX, RY, RZ, Measure]


@dataclass(frozen=True)
class Circuit:
    num_qubits: int
    gates: tuple = field(default=())

    def h(self, target: int) -> "Circuit":
        return replace(self, gates=self.gates + (H(target=target),))

    def x(self, target: int) -> "Circuit":
        return replace(self, gates=self.gates + (X(target=target),))

    def y(self, target: int) -> "Circuit":
        return replace(self, gates=self.gates + (Y(target=target),))

    def z(self, target: int) -> "Circuit":
        return replace(self, gates=self.gates + (Z(target=target),))

    def s(self, target: int) -> "Circuit":
        return replace(self, gates=self.gates + (S(target=target),))

    def t(self, target: int) -> "Circuit":
        return replace(self, gates=self.gates + (T(target=target),))

    def sdg(self, target: int) -> "Circuit":
        return replace(self, gates=self.gates + (Sdg(target=target),))

    def tdg(self, target: int) -> "Circuit":
        return replace(self, gates=self.gates + (Tdg(target=target),))

    def cx(self, control: int, target: int) -> "Circuit":
        return replace(self, gates=self.gates + (CX(control=control, target=target),))

    def rx(self, target: int, theta: float) -> "Circuit":
        return replace(self, gates=self.gates + (RX(target=target, theta=theta),))

    def ry(self, target: int, theta: float) -> "Circuit":
        return replace(self, gates=self.gates + (RY(target=target, theta=theta),))

    def rz(self, target: int, theta: float) -> "Circuit":
        return replace(self, gates=self.gates + (RZ(target=target, theta=theta),))

    def measure(self, target: int) -> "Circuit":
        return replace(self, gates=self.gates + (Measure(target=target),))

    def to_qasm(self) -> str:
        num_measurements = sum(1 for g in self.gates if isinstance(g, Measure))
        header = (
            'OPENQASM 3.0;\n'
            'include "stdgates.inc";\n'
            f'qubit[{self.num_qubits}] q;\n'
        )
        if num_measurements:
            header += f'bit[{num_measurements}] c;\n'
        measure_index = 0
        body_parts: list[str] = []
        for gate in self.gates:
            if isinstance(gate, Measure):
                body_parts.append(f'c[{measure_index}] = measure q[{gate.target}];\n')
                measure_index += 1
            else:
                body_parts.append(_gate_to_qasm(gate))
        return header + "".join(body_parts)

    @classmethod
    def from_qasm(cls, qasm: str) -> "Circuit":
        program = _parse_qasm(qasm)
        num_qubits = 0
        gates: tuple = ()
        for stmt in program.statements:
            if isinstance(stmt, ast.QubitDeclaration):
                assert isinstance(stmt.size, ast.IntegerLiteral)
                num_qubits = stmt.size.value
            elif isinstance(stmt, ast.QuantumGate):
                gates = gates + (_gate_from_qasm(stmt),)
            elif isinstance(stmt, ast.QuantumMeasurementStatement):
                target = _qubit_index(stmt.measure.qubit)
                gates = gates + (Measure(target=target),)
            # ClassicalDeclaration (bit register) is skipped — Circuit
            # doesn't model classical registers explicitly; the bit
            # register width is reconstructed by counting Measures on
            # emit.
        return cls(num_qubits=num_qubits, gates=gates)


_SINGLE_QUBIT_GATE_TYPES: tuple[type, ...] = (H, X, Y, Z, S, Sdg, T, Tdg)
_PARAMETERISED_1Q_TYPES: tuple[type, ...] = (RX, RY, RZ)
_FROM_QASM_SINGLE_QUBIT: dict[str, type] = {
    cls.qasm_name: cls for cls in _SINGLE_QUBIT_GATE_TYPES
}


def _gate_to_qasm(gate: object) -> str:
    if isinstance(gate, _SINGLE_QUBIT_GATE_TYPES):
        return f'{gate.qasm_name} q[{gate.target}];\n'
    if isinstance(gate, _PARAMETERISED_1Q_TYPES):
        return f'{gate.qasm_name}({gate.theta!r}) q[{gate.target}];\n'
    match gate:
        case CX(control=c, target=t):
            return f'cx q[{c}], q[{t}];\n'
        case _:
            raise TypeError(f"unsupported gate: {gate!r}")


def _qubit_index(qubit: ast.IndexedIdentifier | ast.Identifier) -> int:
    assert isinstance(qubit, ast.IndexedIdentifier)
    inner = qubit.indices[0]
    assert isinstance(inner, list)
    literal = inner[0]
    assert isinstance(literal, ast.IntegerLiteral)
    return literal.value


_FROM_QASM_PARAMETERISED: dict[str, type] = {
    cls.qasm_name: cls for cls in _PARAMETERISED_1Q_TYPES
}


def _gate_from_qasm(stmt: ast.QuantumGate) -> Gate:
    name = stmt.name.name
    qubits = [_qubit_index(q) for q in stmt.qubits]
    if name in _FROM_QASM_SINGLE_QUBIT and len(qubits) == 1:
        cls = _FROM_QASM_SINGLE_QUBIT[name]
        return cls(target=qubits[0])
    if name == "cx" and len(qubits) == 2:
        return CX(control=qubits[0], target=qubits[1])
    if name in _FROM_QASM_PARAMETERISED and len(qubits) == 1 and len(stmt.arguments) == 1:
        cls = _FROM_QASM_PARAMETERISED[name]
        return cls(target=qubits[0], theta=_literal_value(stmt.arguments[0]))
    raise ValueError(f"unsupported gate in QASM: {name!r}")


def _literal_value(node: ast.Expression) -> float:
    if isinstance(node, ast.FloatLiteral):
        return node.value
    if isinstance(node, ast.IntegerLiteral):
        return float(node.value)
    raise ValueError(f"non-literal gate argument: {node!r}")
