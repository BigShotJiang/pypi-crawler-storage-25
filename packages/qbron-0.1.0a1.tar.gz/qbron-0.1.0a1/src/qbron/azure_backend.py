"""Azure Quantum backend via azure-quantum[qiskit].

Same shape as `IBMBackend` and `BraketBackend`: a thin specialisation
of `QiskitBackend` that names devices `azure.<target>` and provides
`from_env()`.

Azure auth is heavier than IBM/Braket — there is no single token; you
need a Workspace coordinate (subscription, resource group, workspace
name, location) plus standard Azure credentials handled by
`DefaultAzureCredential`. We surface a clear error listing every
missing `QBRON_AZURE_*` variable so users don't get a deep Azure SDK
stack trace.

Targets include `ionq.simulator`, `ionq.qpu.aria-1`,
`quantinuum.qpu.h1-1`, `rigetti.sim.qvm`, etc. — see Azure Quantum
docs for the full catalogue.
"""

import os
from typing import Any

from qbron.backend import BackendError
from qbron.qiskit_backend import QiskitBackend

_REQUIRED_VARS = (
    "QBRON_AZURE_SUBSCRIPTION_ID",
    "QBRON_AZURE_RESOURCE_GROUP",
    "QBRON_AZURE_WORKSPACE_NAME",
    "QBRON_AZURE_LOCATION",
)


class AzureBackend(QiskitBackend):
    def __init__(self, qiskit_backend: Any) -> None:
        device = getattr(qiskit_backend, "name", "unknown")
        super().__init__(qiskit_backend, name=f"azure.{device}")

    @classmethod
    def from_env(cls, target: str = "ionq.simulator") -> "AzureBackend":
        """Construct an AzureBackend from QBRON_AZURE_* workspace vars.

        Required env vars:
          QBRON_AZURE_SUBSCRIPTION_ID
          QBRON_AZURE_RESOURCE_GROUP
          QBRON_AZURE_WORKSPACE_NAME
          QBRON_AZURE_LOCATION

        Standard Azure auth (DefaultAzureCredential) is picked up under
        the hood — typically `az login` or service-principal env vars.
        """
        missing = [v for v in _REQUIRED_VARS if not os.environ.get(v)]
        if missing:
            raise BackendError(
                f"Missing Azure workspace env vars: {missing}. "
                "Configure your Azure Quantum workspace and export "
                "QBRON_AZURE_SUBSCRIPTION_ID / RESOURCE_GROUP / "
                "WORKSPACE_NAME / LOCATION before calling from_env()."
            )
        from azure.quantum import Workspace
        from azure.quantum.qiskit import AzureQuantumProvider

        workspace = Workspace(
            subscription_id=os.environ["QBRON_AZURE_SUBSCRIPTION_ID"],
            resource_group=os.environ["QBRON_AZURE_RESOURCE_GROUP"],
            name=os.environ["QBRON_AZURE_WORKSPACE_NAME"],
            location=os.environ["QBRON_AZURE_LOCATION"],
        )
        provider = AzureQuantumProvider(workspace=workspace)
        return cls(provider.get_backend(target))
