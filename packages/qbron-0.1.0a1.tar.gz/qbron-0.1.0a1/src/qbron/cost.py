"""Cost normalization across currencies.

Smart routing needs to compare backend prices on a level field. With
SEK / USD / EUR / free all flying around, raw `Cost.amount` comparison
lies. `convert(cost, target_currency)` normalises to a single
currency via the static `DEFAULT_FX_RATES` table.

Real implementations should swap the static table for an FX feed —
this module exposes a `rates` parameter on `convert()` so production
deployments can inject live rates without forking the code.

`free` is its own pseudo-currency: backends like `LocalSimulator` use
it to mean "no monetary cost"; conversion preserves it.
"""

from qbron.backend import Cost

# Each value is "1 unit of <key> in USD". Numbers are illustrative —
# production code should pull these from a real FX provider rather
# than hardcoding them here.
DEFAULT_FX_RATES: dict[str, float] = {
    "USD": 1.0,
    "EUR": 1.08,
    "SEK": 0.092,
    "GBP": 1.27,
    "JPY": 0.0067,
}


def convert(
    cost: Cost,
    target_currency: str,
    rates: dict[str, float] | None = None,
) -> Cost:
    """Convert `cost` into `target_currency`.

    `cost.currency == 'free'` always returns a free Cost — free runs
    on local simulators stay free regardless of what currency we're
    routing in. Unknown currency strings raise `ValueError` so a
    typo in a backend's `estimate_cost` doesn't silently mis-route.
    """
    if cost.currency == "free":
        return Cost(currency="free", amount=0.0)
    if target_currency == "free":
        raise ValueError("cannot convert a priced cost into the 'free' pseudo-currency")
    if cost.currency == target_currency:
        return cost

    fx = rates if rates is not None else DEFAULT_FX_RATES
    if cost.currency not in fx:
        raise ValueError(f"unknown currency: {cost.currency!r}")
    if target_currency not in fx:
        raise ValueError(f"unknown target currency: {target_currency!r}")

    # Pivot through USD: amount × (USD per source) ÷ (USD per target).
    usd_amount = cost.amount * fx[cost.currency]
    return Cost(
        currency=target_currency,
        amount=usd_amount / fx[target_currency],
    )
