"""Error mitigation primitives.

First primitive: **readout error mitigation**. Build a confusion
matrix M[i][j] = P(measure j | prepared i) by running each
computational basis-state preparation circuit on the target backend,
then invert M for every subsequent run to undo measurement bias.

Assumptions (intentionally narrow for the first cut):
- The wrapped backend uses qbron's "measure-all" default (no explicit
  Measure gates in user circuits). The output bitstring is N qubits
  wide, matching the calibration matrix.
- Errors are stationary across calibration and run windows. Real
  hardware drifts; in production the calibration should be refreshed
  on a schedule.

ZNE (zero-noise extrapolation) and dynamical decoupling come next;
their wrappers will live in this module too.
"""

from dataclasses import dataclass, replace

from qbron.backend import Backend, Capabilities, Cost, RunResult, validate
from qbron.circuit import Circuit
from qbron.gates import CX, RX, RY, RZ, H, S, Sdg, T, Tdg, X, Y, Z

# Self-inverse gates fold as G G G ≡ G — physical operations multiply,
# noise accumulates, output unchanged.
_SELF_INVERSE_TYPES: tuple[type, ...] = (H, X, Y, Z, CX)

# Non-self-inverse gates fold as G G⁻¹ G ≡ G. Each entry maps a gate
# type to its adjoint type so fold() can synthesise the inverse from
# the same target qubit.
_INVERSE_OF: dict[type, type] = {
    S: Sdg,
    Sdg: S,
    T: Tdg,
    Tdg: T,
}

# Parameterised rotations invert by negating θ.
_PARAMETERISED_TYPES: tuple[type, ...] = (RX, RY, RZ)


@dataclass(frozen=True)
class ReadoutCalibration:
    """Measured confusion matrix for a backend's readout channel.

    `matrix[i][j]` is the empirical probability of measuring the
    bitstring `j` given the system was prepared in basis state `i`.
    Indexed by integer; `format(i, f'0{num_qubits}b')` gives the
    bitstring representation in qbron's big-endian convention.
    """

    matrix: tuple[tuple[float, ...], ...]
    num_qubits: int


def calibrate_readout(
    backend: Backend, num_qubits: int, shots: int = 1024
) -> ReadoutCalibration:
    """Run all 2^N basis-state preparation circuits and tabulate
    measured outcomes into a confusion matrix.

    Cost on a paid backend: 2^N shots × (calibration shots) — keep
    `num_qubits` modest. Real hardware deployments would cache the
    calibration and refresh it periodically rather than every run.
    """
    n = num_qubits
    rows: list[list[float]] = []
    for i in range(2**n):
        prep = Circuit(num_qubits=n)
        for q in range(n):
            if (i >> (n - 1 - q)) & 1:
                prep = prep.x(q)
        result = backend.run(prep, shots=shots)
        row = [0.0] * (2**n)
        for s, c in result.counts.items():
            row[int(s, 2)] = c / shots
        rows.append(row)
    return ReadoutCalibration(
        matrix=tuple(tuple(r) for r in rows),
        num_qubits=n,
    )


class ReadoutMitigatedBackend:
    """Backend wrapper that inverts a `ReadoutCalibration` on every run.

    Composable with `CachedBackend`, smart routing, and the rest of
    the Backend Protocol — `mitigated = ReadoutMitigatedBackend(
        CachedBackend(IBMBackend.from_env()), calibration
    )` is fine.
    """

    def __init__(
        self, inner: Backend, calibration: ReadoutCalibration
    ) -> None:
        self._inner = inner
        self._calibration = calibration
        self.name = f"mitigated.{inner.name}"

    def capabilities(self) -> Capabilities:
        return self._inner.capabilities()

    def estimate_cost(self, circuit: Circuit, shots: int) -> Cost:
        return self._inner.estimate_cost(circuit, shots)

    def run(self, circuit: Circuit, shots: int) -> RunResult:
        validate(circuit, self.capabilities())
        result = self._inner.run(circuit, shots)
        return _correct(result, self._calibration, shots)


def fold(circuit: Circuit, scale: int) -> Circuit:
    """Insert `(G⁻¹ G)` pairs after each gate to amplify noise without
    changing the unitary. `scale` must be a positive odd integer.

    Self-inverse gates (H X Y Z CX) fold to G G G... since G⁻¹ = G.
    Adjoint pairs (S↔Sdg, T↔Tdg) fold using the explicit inverse.
    Parameterised rotations (RX/RY/RZ) fold by negating θ.
    """
    if scale < 1 or scale % 2 == 0:
        raise ValueError("scale must be a positive odd integer")
    if scale == 1:
        return circuit
    pairs = (scale - 1) // 2
    new_gates: list = []
    for gate in circuit.gates:
        new_gates.append(gate)
        inverse = _inverse_of(gate)
        if inverse is None:
            continue  # not foldable in this version — pass through
        for _ in range(pairs):
            new_gates.append(inverse)
            new_gates.append(gate)
    return replace(circuit, gates=tuple(new_gates))


def _inverse_of(gate: object) -> object | None:
    """Return G⁻¹ for the gate types fold() knows how to invert."""
    if isinstance(gate, _SELF_INVERSE_TYPES):
        return gate
    inv_cls = _INVERSE_OF.get(type(gate))
    if inv_cls is not None:
        return inv_cls(target=gate.target)  # type: ignore[attr-defined]
    if isinstance(gate, _PARAMETERISED_TYPES):
        return type(gate)(target=gate.target, theta=-gate.theta)
    return None


class ZNEBackend:
    """Zero-noise extrapolation: run at multiple noise scales, linearly
    extrapolate per-bitstring probabilities back to scale=0.

    Composable with the rest of the Backend Protocol — chains naturally
    with `CachedBackend`, smart routing, and concrete providers. `run()`
    multiplies inner-backend cost by `len(scale_factors)` since each
    scale is a separate submission.
    """

    def __init__(
        self, inner: Backend, scale_factors: tuple[int, ...] = (1, 3, 5)
    ) -> None:
        if any(s < 1 or s % 2 == 0 for s in scale_factors):
            raise ValueError("scale_factors must be positive odd integers")
        self._inner = inner
        self._scale_factors = tuple(scale_factors)
        self.name = f"zne.{inner.name}"

    def capabilities(self) -> Capabilities:
        return self._inner.capabilities()

    def estimate_cost(self, circuit: Circuit, shots: int) -> Cost:
        # Sum cost across every scaled submission; assumes a single
        # currency, which is true for any single-provider inner.
        total = 0.0
        currency = "free"
        for s in self._scale_factors:
            cost = self._inner.estimate_cost(fold(circuit, s), shots)
            total += cost.amount
            if cost.currency != "free":
                currency = cost.currency
        return Cost(currency=currency, amount=total)

    def run(self, circuit: Circuit, shots: int) -> RunResult:
        validate(circuit, self.capabilities())
        per_scale: dict[int, dict[str, int]] = {}
        for s in self._scale_factors:
            per_scale[s] = self._inner.run(fold(circuit, s), shots).counts

        # Collect every observed bitstring across every scale; for each,
        # fit a line through (scale, p) and read off the intercept at 0.
        all_keys: set[str] = set()
        for counts in per_scale.values():
            all_keys.update(counts)

        extrapolated: dict[str, float] = {}
        xs = list(self._scale_factors)
        for key in all_keys:
            ys = [per_scale[s].get(key, 0) / shots for s in xs]
            extrapolated[key] = _linear_extrapolate_to_zero(xs, ys)

        # Clip non-physical negatives, renormalise, re-sample to ints.
        for k in extrapolated:
            extrapolated[k] = max(0.0, extrapolated[k])
        total = sum(extrapolated.values())
        if total > 0:
            extrapolated = {k: v / total for k, v in extrapolated.items()}

        out: dict[str, int] = {}
        for k, p in extrapolated.items():
            c = int(round(p * shots))
            if c > 0:
                out[k] = c
        return RunResult(counts=out)


def _linear_extrapolate_to_zero(xs: list[int], ys: list[float]) -> float:
    """Least-squares linear fit y = a + b*x; return `a` (the y-intercept)."""
    n = len(xs)
    sum_x = sum(xs)
    sum_y = sum(ys)
    sum_xy = sum(x * y for x, y in zip(xs, ys))
    sum_xx = sum(x * x for x in xs)
    denom = n * sum_xx - sum_x * sum_x
    if denom == 0:
        return sum_y / n
    b = (n * sum_xy - sum_x * sum_y) / denom
    return (sum_y - b * sum_x) / n


def _correct(
    result: RunResult, calibration: ReadoutCalibration, shots: int
) -> RunResult:
    """Solve M.T @ p_true = p_observed, clip, renormalise, re-sample.

    NumPy is required for the linear-algebra step; lazy-imported so
    users not exercising mitigation aren't forced into the dep.
    """
    import numpy as np

    n = calibration.num_qubits
    dim = 2**n
    p_observed = np.zeros(dim)
    for s, c in result.counts.items():
        p_observed[int(s, 2)] = c / shots

    matrix = np.array(calibration.matrix)
    p_true = np.linalg.solve(matrix.T, p_observed)
    # Inversion can produce small negative probabilities from sampling
    # noise; clip and renormalise so the output is a valid distribution.
    p_true = np.maximum(p_true, 0)
    total = p_true.sum()
    if total > 0:
        p_true = p_true / total

    corrected: dict[str, int] = {}
    for i in range(dim):
        c = int(round(p_true[i] * shots))
        if c > 0:
            corrected[format(i, f"0{n}b")] = c
    return RunResult(counts=corrected)
