"""OpenTelemetry-based tracing for backend.run() calls.

`TracedBackend(inner)` is a Backend Protocol-conformant wrapper that
emits a `qbron.backend.run` span around every `inner.run()` invocation,
tagged with the backend name, circuit shape, shot count, and (on
success) the number of distinct measurement outcomes.

Failures are recorded on the span via the standard OTel exception
semantic-convention so dashboards can surface error rates and stack
traces without bespoke logging.

`opentelemetry-api` is intentionally not a runtime dependency; install
it (and an SDK + exporter) yourself, or pip install qbron[observability]
once that extra is wired up. Lazy import below produces a clear error
if the user constructs `TracedBackend` without it.
"""

from typing import Any

from qbron.backend import Backend, BackendError, Capabilities, Cost, RunResult
from qbron.circuit import Circuit
from qbron.gates import Measure


class TracedBackend:
    """Wrap any Backend so each `run()` emits a structured OTel span."""

    def __init__(self, inner: Backend, tracer: Any | None = None) -> None:
        try:
            from opentelemetry import trace
        except ImportError as exc:
            raise BackendError(
                "TracedBackend requires opentelemetry-api. "
                "Install with: pip install opentelemetry-api opentelemetry-sdk"
            ) from exc
        self._inner = inner
        self._tracer = tracer or trace.get_tracer("qbron")
        self.name = f"traced.{inner.name}"

    def capabilities(self) -> Capabilities:
        return self._inner.capabilities()

    def estimate_cost(self, circuit: Circuit, shots: int) -> Cost:
        return self._inner.estimate_cost(circuit, shots)

    def run(self, circuit: Circuit, shots: int) -> RunResult:
        from opentelemetry.trace import Status, StatusCode

        with self._tracer.start_as_current_span(
            "qbron.backend.run",
            attributes={
                "backend.name": self._inner.name,
                "circuit.num_qubits": circuit.num_qubits,
                "circuit.num_gates": sum(
                    1 for g in circuit.gates if not isinstance(g, Measure)
                ),
                "circuit.num_measurements": sum(
                    1 for g in circuit.gates if isinstance(g, Measure)
                ),
                "shots": shots,
            },
        ) as span:
            try:
                result = self._inner.run(circuit, shots)
            except Exception as exc:
                span.record_exception(exc)
                span.set_status(Status(StatusCode.ERROR, str(exc)))
                raise
            span.set_attribute("result.distinct_outcomes", len(result.counts))
            span.set_attribute("result.total_counts", sum(result.counts.values()))
            return result
