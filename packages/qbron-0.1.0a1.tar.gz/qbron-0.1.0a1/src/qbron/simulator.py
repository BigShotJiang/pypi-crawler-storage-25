import cmath
import random

from qbron.backend import Capabilities, Cost, RunResult, validate
from qbron.circuit import Circuit
from qbron.gates import CX, RX, RY, RZ, H, Measure, S, Sdg, T, Tdg, X, Y, Z

_INV_SQRT2 = 1 / 2**0.5

# 2x2 unitaries for single-qubit gates, indexed by gate type.
_SINGLE_QUBIT_MATRICES: dict[type, tuple[tuple[complex, complex], tuple[complex, complex]]] = {
    H: ((_INV_SQRT2, _INV_SQRT2), (_INV_SQRT2, -_INV_SQRT2)),
    X: ((0 + 0j, 1 + 0j), (1 + 0j, 0 + 0j)),
    Y: ((0 + 0j, 0 - 1j), (0 + 1j, 0 + 0j)),
    Z: ((1 + 0j, 0 + 0j), (0 + 0j, -1 + 0j)),
    S: ((1 + 0j, 0 + 0j), (0 + 0j, 0 + 1j)),
    Sdg: ((1 + 0j, 0 + 0j), (0 + 0j, 0 - 1j)),
    T: ((1 + 0j, 0 + 0j), (0 + 0j, cmath.exp(1j * cmath.pi / 4))),
    Tdg: ((1 + 0j, 0 + 0j), (0 + 0j, cmath.exp(-1j * cmath.pi / 4))),
}

_SUPPORTED_GATES = frozenset(
    {"h", "x", "y", "z", "s", "sdg", "t", "tdg", "cx", "rx", "ry", "rz", "measure"}
)
_MAX_QUBITS = 20  # conservative ceiling for pure-Python statevector


class LocalSimulator:
    name = "local"

    def __init__(self, seed: int | None = None) -> None:
        self._rng = random.Random(seed)

    def capabilities(self) -> Capabilities:
        return Capabilities(max_qubits=_MAX_QUBITS, gate_set=_SUPPORTED_GATES)

    def estimate_cost(self, circuit: Circuit, shots: int) -> Cost:
        return Cost(currency="free", amount=0.0)

    def run(self, circuit: Circuit, shots: int) -> RunResult:
        validate(circuit, self.capabilities())
        n = circuit.num_qubits
        state: list[complex] = [0j] * (2**n)
        state[0] = 1 + 0j
        measured: list[int] = []
        for gate in circuit.gates:
            if isinstance(gate, Measure):
                measured.append(gate.target)
                continue
            state = _apply(state, gate, n)

        # Backwards compatible default: a circuit with no explicit
        # measurements implicitly measures every qubit in index order.
        if not measured:
            measured = list(range(n))

        probs = [abs(amp) ** 2 for amp in state]
        counts: dict[str, int] = {}
        for _ in range(shots):
            outcome = self._rng.choices(range(len(state)), weights=probs)[0]
            label = "".join(str(_bit(outcome, q, n)) for q in measured)
            counts[label] = counts.get(label, 0) + 1
        return RunResult(counts=counts)


def _bit(index: int, qubit: int, n: int) -> int:
    """Read the bit for `qubit` in basis-state `index`. Qubit 0 is MSB."""
    return (index >> (n - 1 - qubit)) & 1


def _flip(index: int, qubit: int, n: int) -> int:
    return index ^ (1 << (n - 1 - qubit))


def _apply(state: list[complex], gate: object, n: int) -> list[complex]:
    if isinstance(gate, RX):
        c = cmath.cos(gate.theta / 2).real
        s = cmath.sin(gate.theta / 2).real
        return _apply_1q(
            state, ((c + 0j, -1j * s), (-1j * s, c + 0j)), gate.target, n
        )
    if isinstance(gate, RY):
        c = cmath.cos(gate.theta / 2).real
        s = cmath.sin(gate.theta / 2).real
        return _apply_1q(
            state, ((c + 0j, -s + 0j), (s + 0j, c + 0j)), gate.target, n
        )
    if isinstance(gate, RZ):
        em = cmath.exp(-1j * gate.theta / 2)
        ep = cmath.exp(1j * gate.theta / 2)
        return _apply_1q(
            state, ((em, 0 + 0j), (0 + 0j, ep)), gate.target, n
        )
    matrix = _SINGLE_QUBIT_MATRICES.get(type(gate))
    if matrix is not None:
        return _apply_1q(state, matrix, gate.target, n)  # type: ignore[attr-defined]
    match gate:
        case CX(control=c, target=t):
            return _apply_cx(state, c, t, n)
        case _:
            raise TypeError(f"unsupported gate: {gate!r}")


def _apply_1q(
    state: list[complex],
    matrix: tuple[tuple[complex, complex], tuple[complex, complex]],
    target: int,
    n: int,
) -> list[complex]:
    new = state.copy()
    for i in range(len(state)):
        if _bit(i, target, n) == 0:
            j = _flip(i, target, n)
            a, b = state[i], state[j]
            new[i] = matrix[0][0] * a + matrix[0][1] * b
            new[j] = matrix[1][0] * a + matrix[1][1] * b
    return new


def _apply_cx(state: list[complex], control: int, target: int, n: int) -> list[complex]:
    new = state.copy()
    for i in range(len(state)):
        if _bit(i, control, n) == 1 and _bit(i, target, n) == 0:
            j = _flip(i, target, n)
            new[i], new[j] = state[j], state[i]
    return new
