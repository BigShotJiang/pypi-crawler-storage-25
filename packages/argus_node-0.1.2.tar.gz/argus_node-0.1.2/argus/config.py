import os
import socket
from dotenv import load_dotenv

load_dotenv()

class Config:
    SIMULATION_NAME = os.environ["SIMULATION_NAME"]

    HOSTNAME = socket.gethostname()

    GCP_BUCKET = os.environ.get('GCP_BUCKET', "detection-simulation")
    GOOGLE_CLOUD_PROJECT = os.environ.get('GOOGLE_CLOUD_PROJECT', "detection-network")
    COORDINATOR_ADDRESS = os.environ.get('COORDINATOR_ADDRESS', "http://127.0.0.1:10400")

    COORDINATOR_BOOT_TIMEOUT: int = int(os.getenv("COORDINATOR_TIMEOUT", 120))
    COORDINATOR_START_TIMEOUT: int = int(os.getenv("COORDINATOR_START_TIMEOUT", 600))

    LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")
    LOG_FORMAT = os.environ.get("LOG_FORMAT", "pretty")
    SERVICE_NAME = os.environ.get("SERVICE_NAME", "argus")
    PROMETHEUS_PORT: int = int(os.getenv("PROMETHEUS_PORT", 8000))
