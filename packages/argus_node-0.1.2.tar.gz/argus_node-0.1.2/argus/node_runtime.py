import asyncio
import inspect
import logging
import random
import tempfile
import time
from datetime import datetime, UTC
from typing import Callable, Any, List

from google.cloud import storage
from prometheus_client import start_http_server

from argus.camera import Camera
from argus.common import NodeState, Frame, Metadata
from argus.config import Config
from argus.coordinator import Coordinator, NoMoreAvailableCameraNodes
from argus.logging_config import configure_logging
from argus.metrics import frame_latency, frame_processing_time, frames_processed, queue_size

logger = logging.getLogger(__name__)

class CannotUpdateState(Exception):
    pass

class NodeRuntime:
    def __init__(self):
        configure_logging()

        self._state: NodeState = NodeState.STARTING
        self._prev_state: List[NodeState] = []

        self._config: None | Config = None
        self._coordinator_client: Coordinator | None = None

        self._start_time: None | datetime = None

        self._latency_fn: Callable[..., float] = lambda: 0
        self._process_fn: Callable[[Frame, Metadata], Any] = lambda frame, metadata: 0
        self._output_fn: Callable[[Any, Metadata], Any] = lambda output, metadata: 0
        self._camera_nodes: list[Camera] = []

    def update_state(self, state: NodeState):
        self._prev_state.append(self._state)
        self._state = state

    @property
    def state(self):
        return self._state

    def _start(self):
        self._config = Config()
        self._start_metrics_server()
        self._coordinator_client = Coordinator(self._config.COORDINATOR_ADDRESS)

        wait_start = datetime.now(UTC).timestamp()
        once = False
        while True:
            status = self._coordinator_client.status_check()
            if status["ready"] and status["up"]:
                break
            else:
                if status["up"] and not once:
                    once = True
                    logger.info("coordinator is up waiting for ready")

                time.sleep(random.randint(5, 10))
                if datetime.now(UTC).timestamp() - wait_start > self._config.COORDINATOR_BOOT_TIMEOUT:
                    logger.error(f"coordinator not ready after {self._config.COORDINATOR_BOOT_TIMEOUT} seconds")
                    raise TimeoutError("coordinator not ready")

    def _start_metrics_server(self):
        start_http_server(self._config.PROMETHEUS_PORT)
        self._metrics_server_started = True
        logger.info(
            "prometheus metrics server started",
            extra={
                "event": "metrics.server.started",
                "port": self._config.PROMETHEUS_PORT,
            },
        )


    def _download_videos(self, node_id: str, camera_ids: list[str]):
        videos = {}
        for camera_id in camera_ids:
            storage_client = storage.Client(project=self._config.GOOGLE_CLOUD_PROJECT)

            bucket = storage_client.bucket(Config.GCP_BUCKET)

            uri =f"{self._config.SIMULATION_NAME}/videos/{node_id}-{camera_id}.mp4"

            logger.info(f"downloading video for camera {camera_id}", extra={"uri":uri})
            blob = bucket.blob(uri)
            video_bytes = blob.download_as_bytes()

            tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".mp4")
            tmp.write(video_bytes)
            tmp.flush()
            videos[camera_id] = tmp.name

        return videos


    def _initialise(self):
        camera_metadata = self._coordinator_client.register(self._config.HOSTNAME)

        logger.info("camera metadata retrieved", extra={"metadata": camera_metadata})

        camera_ids = [cam["id"] for cam in camera_metadata["cameras"]]
        self._initialise_metrics(camera_ids)

        videos = self._download_videos(camera_metadata["node_id"], camera_ids)
        logger.info("videos downloaded", extra={"videos": videos})

        cameras = []
        for camera_id in camera_ids:
            cam = Camera(
                videos[camera_id],
                camera_id,
                self._config.HOSTNAME,
                self._latency_fn,
                self._process_fn
            )
            cam.load_video()
            cameras.append(cam)
        self._camera_nodes = cameras

    def _initialise_metrics(self, camera_ids: list[str]):
        queue_size.set(0)
        for camera_id in camera_ids:
            frames_processed.labels(camera_id)
            frame_processing_time.labels(camera_id)
            frame_latency.labels(camera_id)


    def _wait(self):
        start_wait = datetime.now(UTC).timestamp()
        while True:
            start_time, valid = self._coordinator_client.get_start_time()
            if valid:
                self._start_time = start_time
                break

            if (datetime.now(UTC).timestamp() - start_wait) > self._config.COORDINATOR_START_TIMEOUT:
                logger.error("coordinator start time not set in time")
                raise TimeoutError("coordinator start time not set in time")

            time.sleep(random.randint(5, 10))

    async def _run(self):
        start_event = asyncio.Event()
        out = asyncio.Queue()
        sentinel = object()
        queue_size.set(0)

        tasks = [
            asyncio.create_task(cam.run(start_event, out)) for cam in self._camera_nodes
        ]
        consumer_task = asyncio.create_task(self._consume_out_queue(out, sentinel))

        wait_time = max(self._start_time.timestamp() - datetime.now(UTC).timestamp(), 0)
        if wait_time > 0:
            logger.info(f"waiting for {wait_time} seconds before starting camera streams")
            await asyncio.sleep(wait_time)

        start_event.set()
        logger.info("started camera streams")

        try:
            await asyncio.gather(*tasks)
        finally:
            await out.put(sentinel)
            await consumer_task

    async def _consume_out_queue(self, out: asyncio.Queue, sentinel: object):
        while True:
            item = await out.get()
            if item is sentinel:
                queue_size.set(out.qsize())
                break

            output, metadata = item
            queue_size.set(out.qsize())
            try:
                result = self._output_fn(output, metadata)
                if inspect.isawaitable(result):
                    await result
            except Exception:
                logger.exception(
                    "node output handling failed",
                    extra={
                        "event": "node.output.failed",
                        "camera_id": metadata.camera_id,
                    },
                )
                raise


    def run(self):
        while True:
            match self._state:
                case NodeState.STARTING:
                    if len(self._prev_state) == 0:
                       self._start()
                       self.update_state(NodeState.INITIALISING)
                    else:
                        logging.error(f"Invalid state transition: {self._prev_state[-1]} -> STARTING")
                case NodeState.INITIALISING:
                    if self._prev_state[-1] == NodeState.STARTING:
                        try:
                            self._initialise()
                            self.update_state(NodeState.READY)
                            self._coordinator_client.update_pod_status(self._config.HOSTNAME, NodeState.READY.value)
                        except NoMoreAvailableCameraNodes as e:
                            self.update_state(NodeState.FINISHED)
                    else:
                        logging.error(f"Invalid state transition: {self._prev_state[-1]} -> INITIALISING")
                case NodeState.READY:
                    if self._prev_state[-1] == NodeState.INITIALISING:
                        self._wait()
                        self.update_state(NodeState.RUNNING)
                        self._coordinator_client.update_pod_status(self._config.HOSTNAME, NodeState.RUNNING.value)
                    else:
                        logging.error(f"Invalid state transition: {self._prev_state[-1]} -> READY")
                case NodeState.RUNNING:
                    if self._prev_state[-1] == NodeState.READY:
                        asyncio.run(self._run())
                        self.update_state(NodeState.FINISHED)
                        self._coordinator_client.update_pod_status(self._config.HOSTNAME, NodeState.FINISHED.value)
                    else:
                        logging.error(f"Invalid state transition: {self._prev_state[-1]} -> RUNNING")
                case NodeState.FINISHED:
                    logger.info("waiting for final prometheus pulls")
                    time.sleep(10)
                    logger.info("exiting...")
                    exit(0)
