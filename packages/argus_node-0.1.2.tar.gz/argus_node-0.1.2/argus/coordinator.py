from datetime import datetime, timedelta, UTC
import logging
from typing import Dict, Tuple

import requests

logger = logging.getLogger(__name__)

class NoMoreAvailableCameraNodes(Exception):
    pass

class Coordinator:
    def __init__(self, coordinator_uri: str):
        self._coordinator_uri = coordinator_uri

    def status_check(self) -> Dict[str, bool]:
        url = f"{self._coordinator_uri}/status"
        resp = requests.get(url)
        if resp.status_code == 200 and resp.json()["status"] == "ok":
            if resp.json()["state"] == "unconfigured":
                return {
                    "up": True,
                    "ready": False,
                }
            elif resp.json()["state"] == "configured":
                return {
                    "up": True,
                    "ready": True,
                }
        else:
            logger.warning("coordinator status check failed", extra={"status": resp.status_code, "response": resp.text, "url":url})
        return {
                    "up": False,
                    "ready": False,
                }

    def register(self, pod_id: str) -> None | Dict:
        url = f"{self._coordinator_uri}/onboarding/register"
        resp = requests.post(url, json={"pod_id": pod_id})
        if resp.status_code != 200:
            if resp.status_code == 409:
                logger.error("no more available camera nodes to register", extra={"pod_id": pod_id})
                raise NoMoreAvailableCameraNodes("no more available camera nodes to claim")
            else:
                logger.error("failed to register pod", extra={"status": resp.status_code, "response": resp.text, "url":url})
            return None
        else:
            logger.info("registered pod", extra={"pod_id": pod_id})
            return resp.json()

    def update_pod_status(self, pod_id: str, status: str) -> None | str:
        url = f"{self._coordinator_uri}/simulation/update_pod"
        resp = requests.post(url, json={"pod_id": pod_id, "pod_state": status})
        if resp.status_code != 200:
            logger.error(f"failed to update pod status to {status}", extra={"status": resp.status_code, "response": resp.text, "url":url})
            return None
        else:
            logger.info(f"updated pod status to {status}")
            return resp.json()["pod_state"]


    def get_start_time(self) -> Tuple[datetime,bool]:
        url = f"{self._coordinator_uri}/simulation/start_time"
        resp = requests.get(url)
        if resp.status_code != 200:
            raise Exception("failed to get start time")
        else:
            start_time = datetime.fromisoformat(resp.json()["start_time"])
            if start_time.tzinfo is None:
                start_time = start_time.replace(tzinfo=UTC)

            if (start_time - datetime.now(UTC)) > timedelta(days=1):
                logging.info("start time is not set", extra={"start_time": start_time, "url": url})
                time_set = False
            else:
                logger.info("fetched start time", extra={"start_time": start_time})
                time_set = True


            return start_time, time_set
