import asyncio
import sys
import types
from datetime import UTC, datetime

import pytest

try:
    import cv2  # noqa: F401
except ModuleNotFoundError:
    cv2 = types.ModuleType("cv2")
    cv2.CAP_PROP_FPS = 5
    cv2.Mat = object
    cv2.VideoCapture = object
    sys.modules["cv2"] = cv2

from argus.camera import Camera
from argus.common import Metadata


def test_load_video_initialises_capture_and_frame_timing(monkeypatch):
    fps = 4.0

    class FakeCapture:
        def __init__(self, filename):
            self.filename = filename

        def get(self, prop):
            assert prop == 5  # cv2.CAP_PROP_FPS
            return fps

    monkeypatch.setattr("argus.camera.cv2.VideoCapture", FakeCapture)

    camera = Camera("test.mp4", "camera-1", "node-1")
    camera.load_video()

    assert isinstance(camera._cap, FakeCapture)
    assert camera._fps == fps
    assert camera._frame_time == pytest.approx(1.0 / fps)


def test_run_respects_fps_and_calls_callbacks(monkeypatch):
    frames = ["frame-1", "frame-2"]
    fps = 4.0
    frame_duration = 1.0 / fps
    latency_calls = []
    process_calls = []
    sleep_calls = []
    queued_results = []

    class FakeCapture:
        def __init__(self, *_args, **_kwargs):
            self._frames = iter(frames)

        def get(self, prop):
            assert prop == 5  # cv2.CAP_PROP_FPS
            return fps

        def read(self):
            try:
                return True, next(self._frames)
            except StopIteration:
                return False, None

    class FakeQueue:
        async def put(self, value):
            queued_results.append(value)

        def qsize(self):
            return len(queued_results)

    class FakeClock:
        def __init__(self):
            self.now = 100.0

        def timestamp(self):
            return self.now

    clock = FakeClock()

    class FakeDateTime:
        @staticmethod
        def now(_tz=UTC):
            return datetime.fromtimestamp(clock.now, UTC)

    async def fake_sleep(duration):
        sleep_calls.append(duration)
        clock.now += duration

    def fake_latency():
        latency_calls.append("called")
        return 0.05

    def fake_process(frame, metadata):
        process_calls.append((frame, metadata.camera_id))
        clock.now += 0.03
        return f"processed-{frame}-{metadata.camera_id}"

    monkeypatch.setattr("argus.camera.cv2.VideoCapture", FakeCapture)
    monkeypatch.setattr("argus.camera.datetime", FakeDateTime)
    monkeypatch.setattr("argus.camera.asyncio.sleep", fake_sleep)

    camera = Camera("test.mp4", "camera-1", "node-1", latency_fn=fake_latency, process_fn=fake_process)
    camera.load_video()

    start_event = asyncio.Event()
    start_event.set()
    asyncio.run(camera.run(start_event, FakeQueue()))

    assert latency_calls == ["called", "called"]
    assert process_calls == [("frame-1", "camera-1"), ("frame-2", "camera-1")]
    assert queued_results == [
        ("processed-frame-1-camera-1", Metadata(camera_id="camera-1")),
        ("processed-frame-2-camera-1", Metadata(camera_id="camera-1")),
    ]
    assert sleep_calls == pytest.approx([
        0.05,
        frame_duration - 0.08,
        0.05,
        frame_duration - 0.08,
    ])
    assert clock.now - 100.0 == pytest.approx(len(frames) * frame_duration)
