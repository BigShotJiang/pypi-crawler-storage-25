"""Low-level HTTP transport for the WLT SDK.

Provides synchronous and asynchronous HTTP clients built on httpx,
with automatic two-step token authentication (apiKey -> token),
retry with exponential backoff, and business-error-code checking.

Authentication flow:
1. On construction, call POST /xt-console/api/user/loginByApiKey?apiKey={api_key}
   to exchange the API key for a short-lived Bearer token (unless a pre-set token
   is provided, in which case this step is skipped).
2. All subsequent requests use Authorization: Bearer {token}.
3. When a response returns any authentication error (AuthenticationError,
   PermissionError, or HTTP 401/403), the client automatically re-authenticates
   via loginByApiKey and retries the original request once.
"""

from __future__ import annotations

import json
import random
import time
from typing import Any, Callable, Generator, Iterator, Optional

import httpx

from ._config import ClientConfig
from ._exceptions import (
    AuthenticationError,
    ConnectionError,
    PermissionError,
    TimeoutError,
    raise_for_code,
)

_LOGIN_PATH = "/xt-console/api/user/loginByApiKey"
_AUTH_ERROR_CODES = {2000, 2002, 2007, 3001}  # All auth/permission codes


def _build_url(config: ClientConfig, path: str) -> str:
    """Build the full URL from config base_url and an API path."""
    if path.startswith("http://") or path.startswith("https://"):
        return path
    return f"{config.base_url}{path}"


def _backoff_delay(attempt: int) -> float:
    """Calculate exponential backoff delay with jitter.

    delay = min(2^attempt * 0.5, 8.0) + random jitter in [0, 0.5)
    """
    base = min(2**attempt * 0.5, 8.0)
    jitter = random.random() * 0.5  # noqa: S311
    return base + jitter


class SyncHTTPClient:
    """Synchronous HTTP client wrapping httpx.Client with two-step token authentication.

    The client automatically exchanges the api_key for a Bearer token via
    ``loginByApiKey`` at construction time (unless a pre-set token is provided),
    and refreshes it when the server returns any authentication error.

    Args:
        config: Client configuration.
        token: Optional pre-set Bearer token. If provided, skips loginByApiKey.
        on_token_refresh: Optional callback invoked with the new token string
            whenever the token is refreshed via loginByApiKey. Useful for
            persisting the token to a cache file.
    """

    def __init__(
        self,
        config: ClientConfig,
        token: Optional[str] = None,
        on_token_refresh: Optional[Callable[[str], None]] = None,
    ) -> None:
        self._config = config
        self._token: str = ""
        self._on_token_refresh = on_token_refresh
        self._client = httpx.Client(
            timeout=httpx.Timeout(config.timeout),
            headers=config.default_headers,
            follow_redirects=True,
        )
        if token:
            # Use pre-set token, skip loginByApiKey
            self._token = token
        else:
            # Obtain initial token via loginByApiKey
            self._authenticate()

    def _authenticate(self) -> None:
        """Call loginByApiKey to exchange api_key for a Bearer token."""
        url = _build_url(self._config, _LOGIN_PATH)
        try:
            response = self._client.request(
                "POST",
                url,
                params={"apiKey": self._config.api_key},
            )
            data = response.json()
            code = data.get("code", 0)
            if code != 200:
                message = data.get("message", "loginByApiKey failed")
                raise AuthenticationError(code=code, message=message)
            token = data.get("data", "")
            if not token:
                raise AuthenticationError(
                    code=code,
                    message="loginByApiKey returned empty token",
                )
            self._token = token
            # Notify caller of fresh token (e.g. for caching)
            if self._on_token_refresh:
                self._on_token_refresh(self._token)
        except httpx.TimeoutException as exc:
            raise TimeoutError(
                f"loginByApiKey timed out after {self._config.timeout}s"
            ) from exc
        except httpx.ConnectError as exc:
            raise ConnectionError(f"loginByApiKey connection failed: {exc}") from exc

    def get_token(self) -> str:
        """Return the current Bearer token."""
        return self._token

    def request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send an HTTP request with retry logic and return parsed JSON.

        If the server returns business code 3001 (token expired / permission
        denied), the client automatically re-authenticates via loginByApiKey
        and retries the request once.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE).
            path: API path, e.g. "/xt-console/api/secret/list".
            json: Request body as JSON dict (for POST/PUT).
            params: Query parameters dict (for GET/DELETE).

        Returns:
            Parsed JSON response as a dict.

        Raises:
            ConnectionError: On network-level failures.
            TimeoutError: When the request times out.
            APIError (or subclass): When the business code indicates an error.
        """
        url = _build_url(self._config, path)
        last_exc: Exception | None = None

        for attempt in range(self._config.max_retries + 1):
            try:
                response = self._client.request(
                    method,
                    url,
                    json=json,
                    params=params,
                    headers={"Authorization": f"Bearer {self._token}"},
                )
                # Handle HTTP-level errors (e.g. 500)
                if response.status_code >= 500:
                    if attempt < self._config.max_retries:
                        time.sleep(_backoff_delay(attempt))
                        continue
                    response.raise_for_status()

                # Handle HTTP 401/403 as auth errors
                if response.status_code in (401, 403):
                    self._authenticate()
                    response = self._client.request(
                        method,
                        url,
                        json=json,
                        params=params,
                        headers={"Authorization": f"Bearer {self._token}"},
                    )
                    if response.status_code in (401, 403):
                        response.raise_for_status()

                data = response.json()

                # Check business error code
                code = data.get("code", 200)
                message = data.get("message", "")

                # Auto-refresh token on any authentication/permission error code
                if code in _AUTH_ERROR_CODES:
                    self._authenticate()
                    # Retry the original request once with new token
                    response = self._client.request(
                        method,
                        url,
                        json=json,
                        params=params,
                        headers={"Authorization": f"Bearer {self._token}"},
                    )
                    data = response.json()
                    code = data.get("code", 200)
                    message = data.get("message", "")

                raise_for_code(code, message)

                return data

            except httpx.TimeoutException as exc:
                last_exc = exc
                if attempt < self._config.max_retries:
                    time.sleep(_backoff_delay(attempt))
                    continue
                raise TimeoutError(f"Request timed out after {self._config.timeout}s") from exc

            except httpx.ConnectError as exc:
                last_exc = exc
                if attempt < self._config.max_retries:
                    time.sleep(_backoff_delay(attempt))
                    continue
                raise ConnectionError(f"Connection failed: {exc}") from exc

            except httpx.HTTPStatusError as exc:
                raise ConnectionError(
                    f"HTTP {exc.response.status_code}: {exc.response.text}"
                ) from exc

        # Should not reach here, but just in case
        if last_exc is not None:
            raise ConnectionError(f"Request failed after retries: {last_exc}") from last_exc
        raise ConnectionError("Request failed after retries")

    def stream_request(
        self,
        method: str,
        path: str,
        *,
        json_body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Iterator[str]:
        """Send an HTTP request and yield SSE data lines.

        This method is designed for Server-Sent Events (SSE) endpoints
        like model stream inference. It yields each ``data:`` line content
        as a string (without the ``data:`` prefix).

        Args:
            method: HTTP method (GET, POST).
            path: API path.
            json_body: Request body as JSON dict.
            params: Query parameters dict.

        Yields:
            Each SSE data line content as a string.

        Raises:
            ConnectionError: On network-level failures.
            TimeoutError: When the request times out.
        """
        url = _build_url(self._config, path)
        try:
            with self._client.stream(
                method,
                url,
                json=json_body,
                params=params,
                headers={"Authorization": f"Bearer {self._token}"},
            ) as response:
                for line in response.iter_lines():
                    if line.startswith("data:"):
                        yield line[len("data:"):].strip()
        except httpx.TimeoutException as exc:
            raise TimeoutError(f"Stream request timed out after {self._config.timeout}s") from exc
        except httpx.ConnectError as exc:
            raise ConnectionError(f"Stream connection failed: {exc}") from exc

    def close(self) -> None:
        """Close the underlying HTTP client and release resources."""
        self._client.close()


class AsyncHTTPClient:
    """Asynchronous HTTP client wrapping httpx.AsyncClient with two-step token authentication.

    The client automatically exchanges the api_key for a Bearer token via
    ``loginByApiKey`` before the first request (unless a pre-set token is
    provided), and refreshes it when the server returns any authentication error.

    Args:
        config: Client configuration.
        token: Optional pre-set Bearer token. If provided, skips loginByApiKey.
        on_token_refresh: Optional callback invoked with the new token string
            whenever the token is refreshed via loginByApiKey.
    """

    def __init__(
        self,
        config: ClientConfig,
        token: Optional[str] = None,
        on_token_refresh: Optional[Callable[[str], None]] = None,
    ) -> None:
        self._config = config
        self._token: str = token or ""
        self._authenticated = bool(token)
        self._on_token_refresh = on_token_refresh
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(config.timeout),
            headers=config.default_headers,
            follow_redirects=True,
        )

    async def _authenticate(self) -> None:
        """Call loginByApiKey to exchange api_key for a Bearer token."""
        url = _build_url(self._config, _LOGIN_PATH)
        try:
            response = await self._client.request(
                "POST",
                url,
                params={"apiKey": self._config.api_key},
            )
            data = response.json()
            code = data.get("code", 0)
            if code != 200:
                message = data.get("message", "loginByApiKey failed")
                raise AuthenticationError(code=code, message=message)
            token = data.get("data", "")
            if not token:
                raise AuthenticationError(
                    code=code,
                    message="loginByApiKey returned empty token",
                )
            self._token = token
            self._authenticated = True
            # Notify caller of fresh token (e.g. for caching)
            if self._on_token_refresh:
                self._on_token_refresh(self._token)
        except httpx.TimeoutException as exc:
            raise TimeoutError(
                f"loginByApiKey timed out after {self._config.timeout}s"
            ) from exc
        except httpx.ConnectError as exc:
            raise ConnectionError(f"loginByApiKey connection failed: {exc}") from exc

    async def _ensure_authenticated(self) -> None:
        """Ensure the client has a valid token (lazy initialization for async)."""
        if not self._authenticated:
            await self._authenticate()

    def get_token(self) -> str:
        """Return the current Bearer token."""
        return self._token

    async def request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send an async HTTP request with retry logic and return parsed JSON.

        If the server returns any authentication/permission error, the client
        automatically re-authenticates via loginByApiKey and retries once.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE).
            path: API path, e.g. "/xt-console/api/secret/list".
            json: Request body as JSON dict (for POST/PUT).
            params: Query parameters dict (for GET/DELETE).

        Returns:
            Parsed JSON response as a dict.

        Raises:
            ConnectionError: On network-level failures.
            TimeoutError: When the request times out.
            APIError (or subclass): When the business code indicates an error.
        """
        import asyncio

        await self._ensure_authenticated()

        url = _build_url(self._config, path)
        last_exc: Exception | None = None

        for attempt in range(self._config.max_retries + 1):
            try:
                response = await self._client.request(
                    method,
                    url,
                    json=json,
                    params=params,
                    headers={"Authorization": f"Bearer {self._token}"},
                )
                if response.status_code >= 500:
                    if attempt < self._config.max_retries:
                        await asyncio.sleep(_backoff_delay(attempt))
                        continue
                    response.raise_for_status()

                # Handle HTTP 401/403 as auth errors
                if response.status_code in (401, 403):
                    await self._authenticate()
                    response = await self._client.request(
                        method,
                        url,
                        json=json,
                        params=params,
                        headers={"Authorization": f"Bearer {self._token}"},
                    )
                    if response.status_code in (401, 403):
                        response.raise_for_status()

                data = response.json()

                code = data.get("code", 200)
                message = data.get("message", "")

                # Auto-refresh token on any authentication/permission error code
                if code in _AUTH_ERROR_CODES:
                    await self._authenticate()
                    # Retry the original request once with new token
                    response = await self._client.request(
                        method,
                        url,
                        json=json,
                        params=params,
                        headers={"Authorization": f"Bearer {self._token}"},
                    )
                    data = response.json()
                    code = data.get("code", 200)
                    message = data.get("message", "")

                raise_for_code(code, message)

                return data

            except httpx.TimeoutException as exc:
                last_exc = exc
                if attempt < self._config.max_retries:
                    await asyncio.sleep(_backoff_delay(attempt))
                    continue
                raise TimeoutError(f"Request timed out after {self._config.timeout}s") from exc

            except httpx.ConnectError as exc:
                last_exc = exc
                if attempt < self._config.max_retries:
                    await asyncio.sleep(_backoff_delay(attempt))
                    continue
                raise ConnectionError(f"Connection failed: {exc}") from exc

            except httpx.HTTPStatusError as exc:
                raise ConnectionError(
                    f"HTTP {exc.response.status_code}: {exc.response.text}"
                ) from exc

        if last_exc is not None:
            raise ConnectionError(f"Request failed after retries: {last_exc}") from last_exc
        raise ConnectionError("Request failed after retries")

    async def stream_request(
        self,
        method: str,
        path: str,
        *,
        json_body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ):
        """Send an async HTTP request and yield SSE data lines.

        This method is designed for Server-Sent Events (SSE) endpoints.
        It yields each ``data:`` line content as a string.

        Args:
            method: HTTP method (GET, POST).
            path: API path.
            json_body: Request body as JSON dict.
            params: Query parameters dict.

        Yields:
            Each SSE data line content as a string.
        """
        await self._ensure_authenticated()
        url = _build_url(self._config, path)
        try:
            async with self._client.stream(
                method,
                url,
                json=json_body,
                params=params,
                headers={"Authorization": f"Bearer {self._token}"},
            ) as response:
                async for line in response.aiter_lines():
                    if line.startswith("data:"):
                        yield line[len("data:"):].strip()
        except httpx.TimeoutException as exc:
            raise TimeoutError(f"Stream request timed out after {self._config.timeout}s") from exc
        except httpx.ConnectError as exc:
            raise ConnectionError(f"Stream connection failed: {exc}") from exc

    async def close(self) -> None:
        """Close the underlying async HTTP client and release resources."""
        await self._client.aclose()
