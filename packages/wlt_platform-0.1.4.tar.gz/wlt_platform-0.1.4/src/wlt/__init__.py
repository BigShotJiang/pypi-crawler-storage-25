"""WLT Python SDK -- Official client library for the WLT (White Label Token) Console API.

Quick start::

    from wlt import WltClient

    client = WltClient(api_key="sk-xxx")
    result = client.secrets.list()
    print(result.data)

For async usage::

    from wlt import AsyncWltClient

    async def main():
        async with AsyncWltClient(api_key="sk-xxx") as client:
            result = await client.secrets.list()
"""

from .client import AsyncWltClient, WltClient

try:
    from importlib.metadata import PackageNotFoundError, version as _pkg_version
except ImportError:  # Python < 3.8 fallback (shouldn't happen, requires-python >=3.8)
    from importlib_metadata import PackageNotFoundError, version as _pkg_version  # type: ignore

try:
    __version__ = _pkg_version("wlt-platform")
except PackageNotFoundError:
    # Package is not installed (e.g. running from source tree without install)
    __version__ = "0.0.0+unknown"

__all__ = [
    "WltClient",
    "AsyncWltClient",
    "__version__",
]
