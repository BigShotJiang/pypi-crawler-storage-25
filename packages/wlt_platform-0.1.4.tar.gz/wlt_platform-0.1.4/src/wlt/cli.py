"""WLT CLI -- Command-line interface for the WLT Python SDK.

Usage::

    wlt --help
    wlt login --api-key <key> [--base-url <url>]
    wlt whoami
    wlt secret list
    wlt config set base_url https://your.host
    ...

Authentication priority (API Key):
    1. Command-line ``--api-key`` option
    2. Environment variable ``WLT_API_KEY``
    3. Config file ``~/.wlt/config.json`` (``api_key`` / ``apiKey``)

Base URL priority:
    1. Command-line ``--base-url`` option
    2. Environment variable ``WLT_BASE_URL``
    3. Config file ``~/.wlt/config.json`` (``base_url`` / ``baseUrl``)
    4. Default ``https://daily.sssxuntui.com``
"""

from __future__ import annotations

import json as json_mod
import os
import stat
import sys
from pathlib import Path
from typing import Any, Optional

import click

from . import __version__

# ---------------------------------------------------------------------------
# Config management (~/.wlt/config.json)
# ---------------------------------------------------------------------------

_CONFIG_DIR = Path.home() / ".wlt"
_CONFIG_FILE = _CONFIG_DIR / "config.json"


def _save_config(data: dict[str, Any]) -> None:
    """Save config to ~/.wlt/config.json with chmod 600."""
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _CONFIG_FILE.write_text(json_mod.dumps(data, indent=2))
    os.chmod(_CONFIG_FILE, stat.S_IRUSR | stat.S_IWUSR)  # 600


def _load_config() -> dict[str, Any]:
    """Load config from ~/.wlt/config.json."""
    if _CONFIG_FILE.exists():
        try:
            return json_mod.loads(_CONFIG_FILE.read_text())
        except (json_mod.JSONDecodeError, OSError):
            return {}
    return {}


def _resolve_api_key(ctx_api_key: Optional[str] = None) -> Optional[str]:
    """Resolve API key with priority: CLI > env > config file."""
    if ctx_api_key:
        return ctx_api_key
    env_key = os.environ.get("WLT_API_KEY")
    if env_key:
        return env_key
    cfg = _load_config()
    return cfg.get("api_key") or cfg.get("apiKey")


def _resolve_base_url(ctx_base_url: Optional[str] = None) -> Optional[str]:
    """Resolve base URL with priority: CLI flag > env > config file > None.

    Returns ``None`` if no override is found, letting the SDK fall back to
    its own default (``https://daily.sssxuntui.com``).
    """
    if ctx_base_url:
        return ctx_base_url
    env_url = os.environ.get("WLT_BASE_URL")
    if env_url:
        return env_url
    cfg = _load_config()
    return cfg.get("base_url") or cfg.get("baseUrl")


def _mask_api_key(value: str) -> str:
    """Mask an API key for display: first 6 + *** + last 4 chars."""
    if not value:
        return ""
    if len(value) <= 10:
        return "***"
    return f"{value[:6]}***{value[-4:]}"


def _save_token(token: str) -> None:
    """Persist a fresh token into the config file (merge with existing)."""
    cfg = _load_config()
    cfg["token"] = token
    _save_config(cfg)


def _get_client(api_key: Optional[str] = None, base_url: Optional[str] = None):
    """Create a WltClient, or exit with helpful message if no key.

    Authentication strategy:
    1. If a cached token exists in config, use it directly (skip loginByApiKey).
    2. If no cached token, use api_key to loginByApiKey and cache the new token.
    3. If the cached token expires during a request, the SDK auto-refreshes
       via loginByApiKey (handled by on_token_refresh callback which persists it).
    4. If api_key is also invalid, prompt re-login.

    Base URL is resolved via CLI flag > env > config file > SDK default.
    """
    key = _resolve_api_key(api_key)
    if not key:
        click.echo("Error: Not logged in. Please run: wlt login --api-key <your-key>", err=True)
        sys.exit(1)

    resolved_base_url = _resolve_base_url(base_url)

    config = _load_config()
    cached_token = config.get("token")

    from ._exceptions import AuthenticationError, ConnectionError as WltConnectionError, TimeoutError as WltTimeoutError
    from .client import WltClient

    try:
        if cached_token:
            # Use cached token, skip loginByApiKey
            client = WltClient(
                api_key=key,
                token=cached_token,
                base_url=resolved_base_url,
                on_token_refresh=_save_token,
            )
        else:
            # No cached token -- loginByApiKey will be called
            client = WltClient(
                api_key=key,
                base_url=resolved_base_url,
                on_token_refresh=_save_token,
            )
            # Cache the freshly obtained token
            _save_token(client.get_token())
        return client
    except AuthenticationError:
        click.echo(
            "\u2717 \u8ba4\u8bc1\u5df2\u8fc7\u671f\uff0c\u81ea\u52a8\u5237\u65b0\u5931\u8d25\u3002\n  \u8bf7\u91cd\u65b0\u767b\u5f55\uff1awlt login --api-key <your-key>",
            err=True,
        )
        sys.exit(1)
    except WltConnectionError:
        click.echo("\u2717 \u65e0\u6cd5\u8fde\u63a5\u670d\u52a1\u5668\uff0c\u8bf7\u68c0\u67e5\u7f51\u7edc", err=True)
        sys.exit(1)
    except WltTimeoutError:
        click.echo("\u2717 \u8fde\u63a5\u670d\u52a1\u5668\u8d85\u65f6\uff0c\u8bf7\u7a0d\u540e\u91cd\u8bd5", err=True)
        sys.exit(1)
    except Exception as exc:
        click.echo(f"Error: Failed to authenticate: {exc}", err=True)
        sys.exit(1)


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------

def _output(data: Any, as_json: bool = False) -> None:
    """Print data in human-readable or JSON format."""
    if as_json:
        if hasattr(data, "model_dump"):
            click.echo(json_mod.dumps(data.model_dump(mode="json"), indent=2, ensure_ascii=False, default=str))
        elif isinstance(data, dict):
            click.echo(json_mod.dumps(data, indent=2, ensure_ascii=False, default=str))
        elif isinstance(data, list):
            items = []
            for item in data:
                if hasattr(item, "model_dump"):
                    items.append(item.model_dump(mode="json"))
                else:
                    items.append(item)
            click.echo(json_mod.dumps(items, indent=2, ensure_ascii=False, default=str))
        else:
            click.echo(json_mod.dumps(data, indent=2, ensure_ascii=False, default=str))
        return

    # Human-readable
    if hasattr(data, "model_dump"):
        _print_dict(data.model_dump(mode="json"))
    elif isinstance(data, dict):
        _print_dict(data)
    elif isinstance(data, list):
        for i, item in enumerate(data):
            if i > 0:
                click.echo("---")
            if hasattr(item, "model_dump"):
                _print_dict(item.model_dump(mode="json"))
            elif isinstance(item, dict):
                _print_dict(item)
            else:
                click.echo(str(item))
    else:
        click.echo(str(data))


def _print_dict(d: dict[str, Any], indent: int = 0) -> None:
    """Pretty-print a dict as key: value pairs with indentation."""
    prefix = "  " * indent
    for key, value in d.items():
        if isinstance(value, dict):
            click.echo(f"{prefix}{key}:")
            _print_dict(value, indent + 1)
        elif isinstance(value, list):
            if not value:
                click.echo(f"{prefix}{key}: []")
            elif isinstance(value[0], dict):
                click.echo(f"{prefix}{key}:")
                for i, item in enumerate(value):
                    click.echo(f"{prefix}  [{i}]")
                    _print_dict(item, indent + 2)
            else:
                click.echo(f"{prefix}{key}: {value}")
        else:
            click.echo(f"{prefix}{key}: {value}")


def _handle_response(resp: Any, as_json: bool) -> None:
    """Handle a BaseResponse object: extract data or show error."""
    if hasattr(resp, "code") and resp.code != 200:
        click.echo(f"Error (code={resp.code}): {resp.message}", err=True)
        sys.exit(1)
    data = resp.data if hasattr(resp, "data") else resp
    if data is None:
        click.echo("No data returned.")
        return
    _output(data, as_json)


def _sdk_call(fn, as_json: bool = False):
    """Call an SDK function and handle common exceptions."""
    from ._exceptions import (
        AuthenticationError,
        ConnectionError as WltConnectionError,
        PermissionError as WltPermissionError,
        TimeoutError as WltTimeoutError,
        WltError,
    )
    try:
        result = fn()
        _handle_response(result, as_json)
    except (AuthenticationError, WltPermissionError):
        click.echo(
            "\u2717 \u8ba4\u8bc1\u5df2\u8fc7\u671f\uff0c\u81ea\u52a8\u5237\u65b0\u5931\u8d25\u3002\n  \u8bf7\u91cd\u65b0\u767b\u5f55\uff1awlt login --api-key <your-key>",
            err=True,
        )
        sys.exit(1)
    except WltConnectionError:
        click.echo("\u2717 \u65e0\u6cd5\u8fde\u63a5\u670d\u52a1\u5668\uff0c\u8bf7\u68c0\u67e5\u7f51\u7edc", err=True)
        sys.exit(1)
    except WltTimeoutError:
        click.echo("\u2717 \u8fde\u63a5\u670d\u52a1\u5668\u8d85\u65f6\uff0c\u8bf7\u7a0d\u540e\u91cd\u8bd5", err=True)
        sys.exit(1)
    except WltError as exc:
        click.echo(f"Error: {exc}", err=True)
        sys.exit(1)
    except Exception as exc:
        click.echo(f"Error: {exc}", err=True)
        sys.exit(1)


# ---------------------------------------------------------------------------
# CLI Root
# ---------------------------------------------------------------------------

@click.group()
@click.version_option(version=__version__, prog_name="wlt")
@click.option("--api-key", default=None, envvar="WLT_API_KEY", help="API Key (overrides env/config).")
@click.option("--base-url", default=None, help="Console API base URL (overrides env/config).")
@click.pass_context
def cli(ctx, api_key, base_url):
    """WLT CLI -- Command-line tool for the WLT platform."""
    ctx.ensure_object(dict)
    ctx.obj["api_key"] = api_key
    ctx.obj["base_url"] = base_url


# ---------------------------------------------------------------------------
# login / logout / whoami
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--api-key", required=True, help="Your WLT API Key.")
@click.option("--base-url", default=None, help="Console API base URL (optional; falls back to env/config/default).")
def login(api_key, base_url):
    """Validate API Key, obtain token, and store credentials locally."""
    from ._exceptions import AuthenticationError, ConnectionError as WltConnectionError, TimeoutError as WltTimeoutError, WltError
    from .client import WltClient

    # Resolve base URL: explicit flag > env > existing config > SDK default.
    # We pass None to WltClient if nothing is explicit, so the SDK can apply
    # its own env/default fallback.
    effective_base_url = _resolve_base_url(base_url)

    click.echo("Verifying API Key...")
    try:
        # Attempt loginByApiKey to validate the key and get a token
        client = WltClient(api_key=api_key, base_url=effective_base_url)
        token = client.get_token()
    except AuthenticationError:
        click.echo("\u2717 API Key \u65e0\u6548\uff0c\u8bf7\u68c0\u67e5\u540e\u91cd\u8bd5\u3002", err=True)
        return
    except WltConnectionError:
        click.echo("\u2717 \u65e0\u6cd5\u8fde\u63a5\u670d\u52a1\u5668\uff0c\u8bf7\u68c0\u67e5\u7f51\u7edc", err=True)
        return
    except WltTimeoutError:
        click.echo("\u2717 \u8fde\u63a5\u670d\u52a1\u5668\u8d85\u65f6\uff0c\u8bf7\u7a0d\u540e\u91cd\u8bd5", err=True)
        return

    # Key is valid -- save api_key + token (merge with existing config)
    cfg = _load_config()
    cfg["api_key"] = api_key
    cfg["apiKey"] = api_key
    cfg["token"] = token
    # Persist base_url only when user explicitly provided one via --base-url
    # (avoid clobbering an existing entry when user did not pass the flag).
    if base_url:
        cfg["base_url"] = base_url
        cfg["baseUrl"] = base_url
    _save_config(cfg)
    click.echo(f"Credentials saved to {_CONFIG_FILE}")

    # Fetch user info for welcome message
    try:
        resp = client.user.get_info()
        if resp.data:
            name = getattr(resp.data, "nickName", None) or getattr(resp.data, "userName", None) or "Unknown"
            click.echo(f"\u2713 Login successful! Welcome, {name}")
        else:
            click.echo("\u2713 Login successful!")
    except (WltError, Exception):
        click.echo("\u2713 Login successful!")
    finally:
        client.close()


@cli.command()
def logout():
    """Remove locally stored credentials."""
    if _CONFIG_FILE.exists():
        _CONFIG_FILE.unlink()
        click.echo("Credentials removed.")
    else:
        click.echo("No credentials found.")


@cli.command()
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def whoami(ctx, as_json):
    """Show current user information."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.user.get_info(), as_json)
    client.close()


# ---------------------------------------------------------------------------
# Config group (manage ~/.wlt/config.json)
# ---------------------------------------------------------------------------

#: Allowed keys for ``wlt config set/get``. Each is persisted with both
#: snake_case and camelCase aliases for cross-CLI compatibility.
_CONFIG_KEY_ALIASES: dict[str, tuple[str, str]] = {
    "api_key": ("api_key", "apiKey"),
    "base_url": ("base_url", "baseUrl"),
}


def _normalize_config_key(key: str) -> Optional[str]:
    """Map snake_case / camelCase user input to the canonical snake_case key."""
    if key in _CONFIG_KEY_ALIASES:
        return key
    for canonical, aliases in _CONFIG_KEY_ALIASES.items():
        if key in aliases:
            return canonical
    return None


@cli.group(name="config")
def config_group():
    """Manage local CLI configuration (~/.wlt/config.json)."""
    pass


@config_group.command(name="set")
@click.argument("key")
@click.argument("value")
def config_set(key, value):
    """Set a config value. Supported keys: api_key, base_url.

    The value is persisted under both snake_case and camelCase keys so the
    Python and Node.js CLIs can share the same config file.
    """
    canonical = _normalize_config_key(key)
    if canonical is None:
        supported = ", ".join(sorted(_CONFIG_KEY_ALIASES.keys()))
        click.echo(f"Error: Unsupported config key '{key}'. Supported: {supported}", err=True)
        sys.exit(1)
    cfg = _load_config()
    snake, camel = _CONFIG_KEY_ALIASES[canonical]
    cfg[snake] = value
    cfg[camel] = value
    _save_config(cfg)
    click.echo(f"Saved {canonical} to {_CONFIG_FILE}")


@config_group.command(name="get")
@click.argument("key")
def config_get(key):
    """Read a single config value. api_key is masked when printed."""
    canonical = _normalize_config_key(key)
    if canonical is None:
        supported = ", ".join(sorted(_CONFIG_KEY_ALIASES.keys()))
        click.echo(f"Error: Unsupported config key '{key}'. Supported: {supported}", err=True)
        sys.exit(1)
    cfg = _load_config()
    snake, camel = _CONFIG_KEY_ALIASES[canonical]
    value = cfg.get(snake) or cfg.get(camel)
    if value is None:
        click.echo("")
        return
    if canonical == "api_key":
        click.echo(_mask_api_key(value))
    else:
        click.echo(value)


@config_group.command(name="list")
def config_list():
    """List all local config entries. api_key is masked."""
    cfg = _load_config()
    if not cfg:
        click.echo("(empty)")
        return
    # Print canonical snake_case keys; collapse alias pairs so the user does
    # not see api_key + apiKey duplicated.
    printed: set[str] = set()
    # Known keys first, in stable order.
    for canonical, (snake, camel) in _CONFIG_KEY_ALIASES.items():
        value = cfg.get(snake) or cfg.get(camel)
        if value is None:
            continue
        if canonical == "api_key":
            click.echo(f"api_key:  {_mask_api_key(value)}")
        else:
            click.echo(f"{canonical}: {value}")
        printed.update({snake, camel})
    # Token & any other extra keys (do not surface raw token value).
    if cfg.get("token") and "token" not in printed:
        click.echo("token:    <cached>")
        printed.add("token")
    for k, v in cfg.items():
        if k in printed:
            continue
        click.echo(f"{k}: {v}")


# ---------------------------------------------------------------------------
# Auth group
# ---------------------------------------------------------------------------

@cli.group(name="auth")
def auth_group():
    """Authentication operations."""
    pass


@auth_group.command(name="tenant-info")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def auth_tenant_info(ctx, as_json):
    """Get tenant information."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.auth.tenant_info(), as_json)
    client.close()


# ---------------------------------------------------------------------------
# Secret group
# ---------------------------------------------------------------------------

@cli.group(name="secret")
def secret_group():
    """Secret management operations."""
    pass


@secret_group.command(name="list")
@click.option("--page-num", type=int, default=1, help="Page number (default 1).")
@click.option("--page-size", type=int, default=10, help="Items per page (default 10).")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def secret_list(ctx, page_num, page_size, as_json):
    """List secrets with pagination."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.secrets.list(page_num=page_num, page_size=page_size), as_json)
    client.close()


@secret_group.command(name="detail")
@click.argument("id", type=int)
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def secret_detail(ctx, id, as_json):
    """Get secret details by ID."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.secrets.detail(id=id), as_json)
    client.close()


@secret_group.command(name="create")
@click.option("--name", required=True, help="Secret name.")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def secret_create(ctx, name, as_json):
    """Create a new secret."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.secrets.create(name=name), as_json)
    client.close()


@secret_group.command(name="edit")
@click.argument("id", type=int)
@click.option("--name", required=True, help="New secret name.")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def secret_edit(ctx, id, name, as_json):
    """Edit an existing secret."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.secrets.edit(id=id, name=name), as_json)
    client.close()


@secret_group.command(name="enable")
@click.argument("id", type=int)
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def secret_enable(ctx, id, as_json):
    """Enable a secret."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.secrets.enable(id=id), as_json)
    client.close()


@secret_group.command(name="disable")
@click.argument("id", type=int)
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def secret_disable(ctx, id, as_json):
    """Disable a secret."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.secrets.disable(id=id), as_json)
    client.close()


@secret_group.command(name="delete")
@click.argument("id", type=int)
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def secret_delete(ctx, id, as_json):
    """Delete a secret."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.secrets.delete(id=id), as_json)
    client.close()


@secret_group.command(name="usage")
@click.argument("id", type=int)
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def secret_usage(ctx, id, as_json):
    """Get usage data for a secret."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.secrets.get_usage_data(id=id), as_json)
    client.close()


@secret_group.command(name="usage-by-model")
@click.argument("id", type=int)
@click.option("--page-num", type=int, default=1, help="Page number (default 1).")
@click.option("--page-size", type=int, default=10, help="Items per page (default 10).")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def secret_usage_by_model(ctx, id, page_num, page_size, as_json):
    """Get usage data broken down by model."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.secrets.usage_by_model(secret_id=id, page_num=page_num, page_size=page_size), as_json)
    client.close()


@secret_group.command(name="models")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def secret_models(ctx, as_json):
    """List available models for secrets."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.secrets.model_list(), as_json)
    client.close()


@secret_group.command(name="providers")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def secret_providers(ctx, as_json):
    """List available providers for secrets."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.secrets.provider_list(), as_json)
    client.close()


# ---------------------------------------------------------------------------
# ApiKey group
# ---------------------------------------------------------------------------

@cli.group(name="apikey")
def apikey_group():
    """API Key (BYOK) management operations."""
    pass


@apikey_group.command(name="list")
@click.option("--page-num", type=int, default=1, help="Page number (default 1).")
@click.option("--page-size", type=int, default=10, help="Items per page (default 10).")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def apikey_list(ctx, page_num, page_size, as_json):
    """List API keys with pagination."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.api_keys.list(page_num=page_num, page_size=page_size), as_json)
    client.close()


@apikey_group.command(name="create")
@click.option("--name", "key_name", required=True, help="Display name for the key.")
@click.option("--provider", required=True, help="Provider name (e.g. dashscope).")
@click.option("--key", "access_key_secret", required=True, help="Access key secret.")
@click.option("--key-id", "access_key_id", default=None, help="Access key ID (for providers that require it, e.g. Alibaba Cloud).")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def apikey_create(ctx, key_name, provider, access_key_secret, access_key_id, as_json):
    """Create a new BYOK API key."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(
        lambda: client.api_keys.create(provider=provider, key_name=key_name, access_key_secret=access_key_secret, access_key_id=access_key_id),
        as_json,
    )
    client.close()


@apikey_group.command(name="update")
@click.argument("id")
@click.option("--name", "key_name", required=True, help="New display name.")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def apikey_update(ctx, id, key_name, as_json):
    """Update an API key's name."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.api_keys.update(path_id=id, key_name=key_name), as_json)
    client.close()


@apikey_group.command(name="delete")
@click.argument("id")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def apikey_delete(ctx, id, as_json):
    """Delete an API key."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.api_keys.delete(id=id), as_json)
    client.close()


@apikey_group.command(name="enable")
@click.argument("id")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def apikey_enable(ctx, id, as_json):
    """Enable an API key."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.api_keys.enable(id=id), as_json)
    client.close()


@apikey_group.command(name="disable")
@click.argument("id")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def apikey_disable(ctx, id, as_json):
    """Disable an API key."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.api_keys.disable(id=id), as_json)
    client.close()


@apikey_group.command(name="test-connect")
@click.option("--provider", required=True, help="Provider name.")
@click.option("--key", "access_key_secret", required=True, help="Access key secret to test.")
@click.option("--key-id", "access_key_id", default=None, help="Access key ID (for providers that require it, e.g. Alibaba Cloud).")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def apikey_test_connect(ctx, provider, access_key_secret, access_key_id, as_json):
    """Test API key connectivity."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.api_keys.test_connect(provider=provider, access_key_secret=access_key_secret, access_key_id=access_key_id), as_json)
    client.close()


@apikey_group.command(name="providers")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def apikey_providers(ctx, as_json):
    """List available providers for API keys."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.api_keys.provider_list(), as_json)
    client.close()


# ---------------------------------------------------------------------------
# Usage group
# ---------------------------------------------------------------------------

@cli.group(name="usage")
def usage_group():
    """Usage query operations."""
    pass


@usage_group.command(name="summary")
@click.option("--start", required=True, help="Start date (YYYY-MM-DD).")
@click.option("--end", required=True, help="End date (YYYY-MM-DD).")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def usage_summary(ctx, start, end, as_json):
    """Query serverless usage summary."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.usage.serverless_summary(start_time=start, end_time=end), as_json)
    client.close()


@usage_group.command(name="detail")
@click.option("--start", required=True, help="Start date (YYYY-MM-DD).")
@click.option("--end", required=True, help="End date (YYYY-MM-DD).")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def usage_detail(ctx, start, end, as_json):
    """Query serverless usage detail (old API)."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.usage.serverless_usage(start_time=start, end_time=end), as_json)
    client.close()


@usage_group.command(name="list")
@click.option("--start", required=True, help="Start date (YYYY-MM-DD).")
@click.option("--end", required=True, help="End date (YYYY-MM-DD).")
@click.option("--page-num", type=int, default=1, help="Page number (default 1).")
@click.option("--page-size", type=int, default=10, help="Items per page (default 10).")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def usage_list(ctx, start, end, page_num, page_size, as_json):
    """Query serverless usage list (new API)."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(
        lambda: client.usage.serverless_list(start_time=start, end_time=end, page_num=page_num, page_size=page_size),
        as_json,
    )
    client.close()


@usage_group.command(name="charts")
@click.option("--start", required=True, help="Start date (YYYY-MM-DD).")
@click.option("--end", required=True, help="End date (YYYY-MM-DD).")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def usage_charts(ctx, start, end, as_json):
    """Get serverless usage chart data."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.usage.serverless_charts(start_time=start, end_time=end), as_json)
    client.close()


@usage_group.command(name="stats")
@click.option("--start", required=True, help="Start date (YYYY-MM-DD).")
@click.option("--end", required=True, help="End date (YYYY-MM-DD).")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def usage_stats(ctx, start, end, as_json):
    """Get serverless usage aggregated statistics."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.usage.serverless_stats(start_time=start, end_time=end), as_json)
    client.close()


@usage_group.command(name="history")
@click.option("--page-num", type=int, default=1, help="Page number (default 1).")
@click.option("--page-size", type=int, default=10, help="Items per page (default 10).")
@click.option("--start", default=None, help="Start date (YYYY-MM-DD).")
@click.option("--end", default=None, help="End date (YYYY-MM-DD).")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def usage_history(ctx, page_num, page_size, start, end, as_json):
    """Query API call history."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(
        lambda: client.usage.history(page_num=page_num, page_size=page_size, start_time=start, end_time=end),
        as_json,
    )
    client.close()


@usage_group.command(name="providers")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def usage_providers(ctx, as_json):
    """List gateway providers."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.usage.gateway_providers(), as_json)
    client.close()


# ---------------------------------------------------------------------------
# Billing group
# ---------------------------------------------------------------------------

@cli.group(name="billing")
def billing_group():
    """Billing operations."""
    pass


@billing_group.command(name="summary")
@click.option("--cycle", required=True, help="Billing cycle (YYYY-MM).")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def billing_summary(ctx, cycle, as_json):
    """Query total billing amount for a billing cycle."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.billing.query_all_amount(billing_cycle=cycle), as_json)
    client.close()


@billing_group.command(name="by-gpu")
@click.option("--cycle", required=True, help="Billing cycle (YYYY-MM).")
@click.option("--page-num", type=int, default=1, help="Page number (default 1).")
@click.option("--page-size", type=int, default=10, help="Items per page (default 10).")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def billing_by_gpu(ctx, cycle, page_num, page_size, as_json):
    """Query billing details by GPU spec."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(
        lambda: client.billing.query_bill_by_gpu(billing_cycle=cycle, page_num=page_num, page_size=page_size),
        as_json,
    )
    client.close()


@billing_group.command(name="by-service")
@click.option("--cycle", required=True, help="Billing cycle (YYYY-MM).")
@click.option("--page-num", type=int, default=1, help="Page number (default 1).")
@click.option("--page-size", type=int, default=10, help="Items per page (default 10).")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def billing_by_service(ctx, cycle, page_num, page_size, as_json):
    """Query billing details by AI service."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(
        lambda: client.billing.query_bill_by_service(billing_cycle=cycle, page_num=page_num, page_size=page_size),
        as_json,
    )
    client.close()


@billing_group.command(name="list")
@click.option("--cycle", required=True, help="Billing cycle (YYYY-MM).")
@click.option("--page-num", type=int, default=1, help="Page number (default 1).")
@click.option("--page-size", type=int, default=10, help="Items per page (default 10).")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def billing_list(ctx, cycle, page_num, page_size, as_json):
    """Query billing detail list."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(
        lambda: client.billing.query_bill_list(billing_cycle=cycle, page_num=page_num, page_size=page_size),
        as_json,
    )
    client.close()


# ---------------------------------------------------------------------------
# Payment group
# ---------------------------------------------------------------------------

@cli.group(name="payment")
def payment_group():
    """Payment / recharge operations."""
    pass


@payment_group.command(name="records")
@click.option("--page-num", type=int, default=1, help="Page number (default 1).")
@click.option("--page-size", type=int, default=10, help="Items per page (default 10).")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def payment_records(ctx, page_num, page_size, as_json):
    """Query recharge records with pagination."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.payment.records(page_num=page_num, page_size=page_size), as_json)
    client.close()


@payment_group.command(name="statistics")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def payment_statistics(ctx, as_json):
    """Query recharge statistics summary."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.payment.statistics(), as_json)
    client.close()


@payment_group.command(name="list")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def payment_list(ctx, as_json):
    """Query all recharge transactions."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.payment.list(), as_json)
    client.close()


@payment_group.command(name="detail")
@click.argument("transaction_no")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def payment_detail(ctx, transaction_no, as_json):
    """Get recharge record by transaction number."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.payment.get_record(transaction_no=transaction_no), as_json)
    client.close()


@payment_group.command(name="billing-list")
@click.option("--page-num", type=int, default=1, help="Page number (default 1).")
@click.option("--page-size", type=int, default=10, help="Items per page (default 10).")
@click.option("--start", default=None, help="Start time (YYYY-MM-DD HH:MM:SS).")
@click.option("--end", default=None, help="End time (YYYY-MM-DD HH:MM:SS).")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def payment_billing_list(ctx, page_num, page_size, start, end, as_json):
    """Query model usage billing list."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(
        lambda: client.payment.billing_list(page_num=page_num, page_size=page_size, start_time=start, end_time=end),
        as_json,
    )
    client.close()


@payment_group.command(name="billing-amount")
@click.option("--start", default=None, help="Start time (YYYY-MM-DD HH:MM:SS).")
@click.option("--end", default=None, help="End time (YYYY-MM-DD HH:MM:SS).")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def payment_billing_amount(ctx, start, end, as_json):
    """Query model usage billing total amount."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.payment.billing_query_all_amount(start_time=start, end_time=end), as_json)
    client.close()


# ---------------------------------------------------------------------------
# Model Gallery group
# ---------------------------------------------------------------------------

@cli.group(name="model")
def model_group():
    """Model Gallery operations."""
    pass


@model_group.command(name="list")
@click.option("--page-num", type=int, default=1, help="Page number (default 1).")
@click.option("--page-size", type=int, default=10, help="Items per page (default 10).")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def model_list(ctx, page_num, page_size, as_json):
    """List models with pagination."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.model_gallery.page(page_num=page_num, page_size=page_size), as_json)
    client.close()


@model_group.command(name="detail")
@click.argument("model_name")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def model_detail(ctx, model_name, as_json):
    """Get model detail by model name."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.model_gallery.detail(model_id=model_name), as_json)
    client.close()


@model_group.command(name="providers")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def model_providers(ctx, as_json):
    """List model providers."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.model_gallery.provider_list(), as_json)
    client.close()


@model_group.command(name="price")
@click.argument("model_name")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def model_price(ctx, model_name, as_json):
    """Get model API price."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.model_gallery.get_price(model_name=model_name), as_json)
    client.close()


# ---------------------------------------------------------------------------
# Model Lab group
# ---------------------------------------------------------------------------

@cli.group(name="lab")
def lab_group():
    """Model Lab operations (inference, sessions, parameters)."""
    pass


@lab_group.command(name="list")
@click.option("--page-num", type=int, default=1, help="Page number (default 1).")
@click.option("--page-size", type=int, default=20, help="Items per page (default 20).")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def lab_list(ctx, page_num, page_size, as_json):
    """List models available in Model Lab."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.model_lab.list(page_num=page_num, page_size=page_size), as_json)
    client.close()


@lab_group.command(name="session")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def lab_session(ctx, as_json):
    """Create a new chat session."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.model_lab.create_session(), as_json)
    client.close()


@lab_group.command(name="chat")
@click.option("--model", required=True, help="Model name.")
@click.option("--provider", required=True, help="Provider name.")
@click.option("--message", required=True, help="User message.")
@click.option("--session-id", default=None, help="Session ID for multi-turn chat.")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON chunks.")
@click.pass_context
def lab_chat(ctx, model, provider, message, session_id, as_json):
    """Stream chat with a model (SSE streaming output)."""
    from ._exceptions import WltError
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    try:
        for chunk in client.model_lab.stream(
            provider=provider,
            model_name=model,
            user_prompt=message,
            session_id=session_id,
        ):
            if as_json:
                click.echo(chunk)
            else:
                # Try to extract text content from SSE JSON
                try:
                    data = json_mod.loads(chunk)
                    # OpenAI-compatible format
                    choices = data.get("choices", [])
                    if choices:
                        delta = choices[0].get("delta", {})
                        content = delta.get("content", "")
                        if content:
                            click.echo(content, nl=False)
                    else:
                        # Fallback: print raw content field
                        content = data.get("content", "")
                        if content:
                            click.echo(content, nl=False)
                except (json_mod.JSONDecodeError, KeyError):
                    # Not JSON or unexpected format, print raw
                    if chunk.strip() and chunk.strip() != "[DONE]":
                        click.echo(chunk, nl=False)
        if not as_json:
            click.echo()  # Final newline
    except WltError as exc:
        click.echo(f"\nError: {exc}", err=True)
        sys.exit(1)
    except Exception as exc:
        click.echo(f"\nError: {exc}", err=True)
        sys.exit(1)
    finally:
        client.close()


@lab_group.command(name="params")
@click.argument("model_id")
@click.option("--provider", required=True, help="Provider name.")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def lab_params(ctx, model_id, provider, as_json):
    """Get model parameters configuration."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.model_lab.get_parameters(model_id=model_id, provider=provider), as_json)
    client.close()


@lab_group.command(name="code-samples")
@click.option("--model", "model_id", required=True, help="Model ID.")
@click.option("--provider", required=True, help="Provider name.")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON.")
@click.pass_context
def lab_code_samples(ctx, model_id, provider, as_json):
    """Get model code samples."""
    client = _get_client(ctx.obj.get("api_key"), ctx.obj.get("base_url"))
    _sdk_call(lambda: client.model_lab.code_samples(model_id=model_id, provider=provider), as_json)
    client.close()


# ---------------------------------------------------------------------------
# __main__ entry point
# ---------------------------------------------------------------------------

def main():
    """Entry point for the CLI."""
    cli(obj={})


if __name__ == "__main__":
    main()
