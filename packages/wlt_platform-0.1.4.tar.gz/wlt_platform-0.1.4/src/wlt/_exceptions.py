"""Exception hierarchy for the WLT SDK.

The exception hierarchy maps business error codes from BaseResponse.code
to specific exception types:

    WltError (base)
    +-- APIError (generic API error with code/message)
    |   +-- AuthenticationError (code 2000 / 2002 / 3001)
    |   +-- PermissionError (code 2007)
    |   +-- NotFoundError (code 1002)
    |   +-- ValidationError (code 1001)
    |   +-- RateLimitError (code 3002)
    |   +-- InternalError (code 1000)
    +-- ConnectionError (network-level failures)
    +-- TimeoutError (request timeout)
"""

from __future__ import annotations


class WltError(Exception):
    """Base exception for all WLT SDK errors."""

    def __init__(self, message: str = "An error occurred") -> None:
        self.message = message
        super().__init__(message)


class APIError(WltError):
    """Generic API error carrying business code and message from BaseResponse."""

    def __init__(self, code: int, message: str) -> None:
        self.code = code
        super().__init__(message)

    def __str__(self) -> str:
        return f"APIError(code={self.code}, message={self.message!r})"

    def __repr__(self) -> str:
        return f"APIError(code={self.code}, message={self.message!r})"


class AuthenticationError(APIError):
    """Raised when authentication fails (business code 2000, 2002, or 3001)."""

    def __str__(self) -> str:
        return f"AuthenticationError(code={self.code}, message={self.message!r})"


class PermissionError(APIError):
    """Raised when the user lacks permission (business code 2007)."""

    def __str__(self) -> str:
        return f"PermissionError(code={self.code}, message={self.message!r})"


class NotFoundError(APIError):
    """Raised when the requested resource is not found (business code 1002)."""

    def __str__(self) -> str:
        return f"NotFoundError(code={self.code}, message={self.message!r})"


class ValidationError(APIError):
    """Raised when request parameters are invalid (business code 1001)."""

    def __str__(self) -> str:
        return f"ValidationError(code={self.code}, message={self.message!r})"


class RateLimitError(APIError):
    """Raised when the request rate limit is exceeded (business code 3002)."""

    def __str__(self) -> str:
        return f"RateLimitError(code={self.code}, message={self.message!r})"


class InternalError(APIError):
    """Raised on system-level errors (business code 1000)."""

    def __str__(self) -> str:
        return f"InternalError(code={self.code}, message={self.message!r})"


class ConnectionError(WltError):
    """Raised when a network connection error occurs."""

    pass


class TimeoutError(WltError):
    """Raised when a request times out."""

    pass


# Mapping from business error code to exception class
_ERROR_CODE_MAP: dict[int, type[APIError]] = {
    1000: InternalError,
    1001: ValidationError,
    1002: NotFoundError,
    2000: AuthenticationError,
    2002: AuthenticationError,
    2007: PermissionError,
    3001: AuthenticationError,
    3002: RateLimitError,
}


def raise_for_code(code: int, message: str) -> None:
    """Raise the appropriate exception for the given business error code.

    If the code is 200 (success), this function does nothing. Otherwise,
    it looks up the code in the error map and raises the corresponding
    exception, falling back to APIError for unknown codes.
    """
    if code == 200:
        return
    exc_cls = _ERROR_CODE_MAP.get(code, APIError)
    raise exc_cls(code=code, message=message)
