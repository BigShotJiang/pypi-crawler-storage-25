"""Main client classes for the WLT SDK.

Provides WltClient (synchronous) and AsyncWltClient (asynchronous),
both offering the same resource-based API surface:

    client.auth          -- tenant info
    client.secrets       -- Secret CRUD, usage, models, providers
    client.api_keys      -- ApiKey CRUD, status, connectivity test
    client.usage         -- Serverless usage, call history, gateway providers
    client.user          -- Current user info
    client.billing       -- Monthly billing queries (GPU / AI service / detail)
    client.payment       -- Recharge records, statistics, model usage billing
    client.model_gallery -- Model detail, providers, prices
    client.model_lab     -- Model list, stream inference, session, parameters, code samples
"""

from __future__ import annotations

from ._config import ClientConfig
from ._http import AsyncHTTPClient, SyncHTTPClient
from .resources.api_key import ApiKeyResource, AsyncApiKeyResource
from .resources.auth import AsyncAuthResource, AuthResource
from .resources.billing import AsyncBillingResource, BillingResource
from .resources.model_gallery import AsyncModelGalleryResource, ModelGalleryResource
from .resources.model_lab import AsyncModelLabResource, ModelLabResource
from .resources.payment import AsyncPaymentResource, PaymentResource
from .resources.secret import AsyncSecretResource, SecretResource
from .resources.usage import AsyncUsageResource, UsageResource
from .resources.user import AsyncUserResource, UserResource


class WltClient:
    """Synchronous client for the WLT Console API.

    Usage::

        from wlt import WltClient

        client = WltClient(api_key="sk-xxx")

        # Access resources
        secrets = client.secrets.list()
        keys = client.api_keys.list()
        info = client.user.get_info()

        # Billing & Payment
        bill = client.billing.query_all_amount(billing_cycle="2026-04")
        stats = client.payment.statistics()

        # Model Gallery & Lab
        detail = client.model_gallery.detail(model_id="Qwen2.5-72B-Instruct")
        models = client.model_lab.list(usage_type="inference")

        # Clean up
        client.close()

    The client can also be used as a context manager::

        with WltClient(api_key="sk-xxx") as client:
            secrets = client.secrets.list()
            ...

    The client uses two-step token authentication internally:
    1. Exchanges api_key for a Bearer token via ``loginByApiKey``
       (skipped if a pre-set ``token`` is provided).
    2. Uses the token for all subsequent requests.
    3. Automatically refreshes the token on any authentication error.

    Args:
        api_key: API key used to obtain Bearer Token via loginByApiKey. Required.
        token: Optional pre-set Bearer token. If provided, skips the initial
            loginByApiKey call. When the token expires, the client falls back
            to api_key to obtain a new token automatically.
        base_url: The WLT Console API base URL. If omitted or ``None``,
            resolution falls back to the ``WLT_BASE_URL`` env var, then to
            the default ``https://daily.sssxuntui.com``.
        timeout: Request timeout in seconds (default 30).
        max_retries: Max retry attempts for transient failures (default 2).
        default_headers: Extra headers to send with every request.
        on_token_refresh: Optional callback ``(token: str) -> None`` invoked
            whenever a new token is obtained via loginByApiKey (useful for
            persisting the token to a cache file).
    """

    def __init__(
        self,
        api_key: str,
        *,
        token: str | None = None,
        base_url: str | None = None,
        timeout: float = 30.0,
        max_retries: int = 2,
        default_headers: dict[str, str] | None = None,
        on_token_refresh: object | None = None,
    ) -> None:
        self._config = ClientConfig(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            default_headers=default_headers or {},
        )
        self._http = SyncHTTPClient(
            self._config,
            token=token,
            on_token_refresh=on_token_refresh,
        )

        # Initialize resource namespaces
        self.auth = AuthResource(self._http)
        self.secrets = SecretResource(self._http)
        self.api_keys = ApiKeyResource(self._http)
        self.usage = UsageResource(self._http)
        self.user = UserResource(self._http)
        self.billing = BillingResource(self._http)
        self.payment = PaymentResource(self._http)
        self.model_gallery = ModelGalleryResource(self._http)
        self.model_lab = ModelLabResource(self._http)

    def get_token(self) -> str:
        """Return the current Bearer token held by the HTTP client."""
        return self._http.get_token()

    def close(self) -> None:
        """Close the underlying HTTP client and release resources."""
        self._http.close()

    def __enter__(self) -> WltClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncWltClient:
    """Asynchronous client for the WLT Console API.

    Usage::

        from wlt import AsyncWltClient

        async def main():
            client = AsyncWltClient(api_key="sk-xxx")

            secrets = await client.secrets.list()
            bill = await client.billing.query_all_amount(billing_cycle="2026-04")

            await client.close()

    The client can also be used as an async context manager::

        async with AsyncWltClient(api_key="sk-xxx") as client:
            secrets = await client.secrets.list()
            ...

    The client uses two-step token authentication internally:
    1. Exchanges api_key for a Bearer token via ``loginByApiKey``
       (lazy, before first request; skipped if pre-set ``token`` is provided).
    2. Uses the token for all subsequent requests.
    3. Automatically refreshes the token on any authentication error.

    Args:
        api_key: API key used to obtain Bearer Token via loginByApiKey. Required.
        token: Optional pre-set Bearer token. If provided, skips loginByApiKey.
        base_url: The WLT Console API base URL. If omitted or ``None``,
            resolution falls back to the ``WLT_BASE_URL`` env var, then to
            the default ``https://daily.sssxuntui.com``.
        timeout: Request timeout in seconds (default 30).
        max_retries: Max retry attempts for transient failures (default 2).
        default_headers: Extra headers to send with every request.
        on_token_refresh: Optional callback ``(token: str) -> None`` invoked
            whenever a new token is obtained via loginByApiKey.
    """

    def __init__(
        self,
        api_key: str,
        *,
        token: str | None = None,
        base_url: str | None = None,
        timeout: float = 30.0,
        max_retries: int = 2,
        default_headers: dict[str, str] | None = None,
        on_token_refresh: object | None = None,
    ) -> None:
        self._config = ClientConfig(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            default_headers=default_headers or {},
        )
        self._http = AsyncHTTPClient(
            self._config,
            token=token,
            on_token_refresh=on_token_refresh,
        )

        # Initialize resource namespaces
        self.auth = AsyncAuthResource(self._http)
        self.secrets = AsyncSecretResource(self._http)
        self.api_keys = AsyncApiKeyResource(self._http)
        self.usage = AsyncUsageResource(self._http)
        self.user = AsyncUserResource(self._http)
        self.billing = AsyncBillingResource(self._http)
        self.payment = AsyncPaymentResource(self._http)
        self.model_gallery = AsyncModelGalleryResource(self._http)
        self.model_lab = AsyncModelLabResource(self._http)

    def get_token(self) -> str:
        """Return the current Bearer token held by the HTTP client."""
        return self._http.get_token()

    async def close(self) -> None:
        """Close the underlying async HTTP client and release resources."""
        await self._http.close()

    async def __aenter__(self) -> AsyncWltClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
