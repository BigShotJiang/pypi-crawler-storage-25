"""Usage-related models."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Generic, List, Optional, TypeVar

from pydantic import BaseModel, Field

from .common import PageRequest

T = TypeVar("T")


# ---- Request models ----

class UsageServerlessRequest(PageRequest):
    """Request parameters for serverless usage summary and list (old)."""

    startTime: Optional[datetime] = None
    endTime: Optional[datetime] = None


class UsageServerlessPageRequest(PageRequest):
    """Request parameters for serverless usage list (new), charts, and stats."""

    startTime: datetime
    endTime: datetime
    apiKey: Optional[str] = None
    inputs: Optional[List[str]] = None
    outputs: Optional[List[str]] = None
    modelIds: Optional[List[str]] = None


class UsageHistoryRequest(BaseModel):
    """Request parameters for call history queries."""

    provider: Optional[str] = None
    feature: Optional[str] = None
    requestType: Optional[str] = None
    startTime: Optional[datetime] = None
    endTime: Optional[datetime] = None
    keyword: Optional[str] = None
    pageNum: Optional[int] = None
    pageSize: Optional[int] = None
    modelIds: Optional[List[str]] = None
    inputs: Optional[List[str]] = None
    outputs: Optional[List[str]] = None


# ---- Response models ----

class ServerLessSummaryResult(BaseModel):
    """Serverless usage summary statistics."""

    totalRequests: Optional[int] = None
    requestTrend: Optional[str] = None
    totalTokens: Optional[int] = None
    tokenTrend: Optional[str] = None
    avgResponseTime: Optional[float] = None
    avgResponseTrend: Optional[str] = None
    totalUseModel: Optional[int] = None
    totalUseModelTrend: Optional[str] = None
    avgLatency: Optional[float] = None
    avgLatencyTrend: Optional[str] = None


class ServerlessUsageInfo(BaseModel):
    """Serverless usage item (old API)."""

    modelName: Optional[str] = None
    requests: Optional[int] = None
    totalTokens: Optional[int] = None
    promptTokens: Optional[int] = None
    completionTokens: Optional[int] = None
    successRate: Optional[float] = None
    avgLatency: Optional[float] = None
    errorCount: Optional[int] = None
    throughput: Optional[float] = None
    provider: Optional[str] = None
    apiKeyName: Optional[str] = None


class ServerlessUsageRecord(BaseModel):
    """Serverless usage record (new API)."""

    modelName: Optional[str] = None
    apiKeyName: Optional[str] = None
    requests: Optional[str] = None
    totalTokens: Optional[str] = None
    avgLatency: Optional[str] = None
    successRate: Optional[str] = None
    errorCount: Optional[str] = None
    totalFee: Optional[str] = None
    throughput: Optional[str] = None
    usageStats: Optional[str] = None


class TrendItem(BaseModel, Generic[T]):
    """A single data point in a trend series."""

    dateLabel: Optional[str] = None
    value: Optional[Any] = None


class ServerlessChartsResult(BaseModel):
    """Serverless usage chart data (time-series trends)."""

    tokensTrend: Optional[List[TrendItem]] = None
    requestsTrend: Optional[List[TrendItem]] = None
    latencyTrend: Optional[List[TrendItem]] = None


class ServerlessStatsResult(BaseModel):
    """Serverless usage aggregated stats."""

    totalRequests: Optional[int] = None
    requestTrend: Optional[str] = None
    totalTokens: Optional[int] = None
    tokenTrend: Optional[str] = None
    totalUseModel: Optional[int] = None
    totalUseModelTrend: Optional[str] = None
    avgLatency: Optional[str] = None
    avgLatencyTrend: Optional[str] = None


class HistoryRecord(BaseModel):
    """API call history record."""

    requestId: Optional[str] = None
    modelNameVersion: Optional[str] = None
    statusCode: Optional[int] = None
    latency: Optional[float] = None
    totalTokens: Optional[int] = None
    timestamp: Optional[datetime] = None
    requestType: Optional[str] = None
    modelTechnology: Optional[str] = None
    promptTokens: Optional[int] = None
    completionTokens: Optional[int] = None
    providerTtft: Optional[float] = None
    providerLatency: Optional[float] = None
    providerResponseType: Optional[str] = None
    apiKeyName: Optional[str] = None
    gatewayRequestBodySize: Optional[int] = None
    errorMsg: Optional[str] = None
