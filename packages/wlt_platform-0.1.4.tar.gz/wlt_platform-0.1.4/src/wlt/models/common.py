"""Common models shared across all modules."""

from __future__ import annotations

from typing import Generic, List, Optional, TypeVar

from pydantic import BaseModel, Field

T = TypeVar("T")


class BaseResponse(BaseModel, Generic[T]):
    """Standard API response wrapper.

    All API responses are wrapped in this structure with a business code,
    message, and optional data payload.
    """

    code: int = 200
    message: str = "OK"
    data: Optional[T] = None


class PageRequest(BaseModel):
    """Base pagination request parameters."""

    pageNum: Optional[int] = Field(default=1, description="Page number, starting from 1")
    pageSize: Optional[int] = Field(default=10, description="Number of items per page")


class PageInfo(BaseModel, Generic[T]):
    """Paginated result set."""

    total: Optional[int] = 0
    list: List[T] = Field(default_factory=list)
    totalPages: Optional[int] = 0
    currentPage: Optional[int] = 1
    pageSize: Optional[int] = 10


class ProviderVO(BaseModel):
    """Provider information."""

    id: str
    name: str
