"""User information models."""

from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel


class UserPermissionResponse(BaseModel):
    """User permission details (opaque -- varies by deployment)."""

    model_config = {"extra": "allow"}


class LoginUser(BaseModel):
    """Current logged-in user information."""

    userId: Optional[int] = None
    aliyunPk: Optional[str] = None
    parentPk: Optional[str] = None
    accountStructure: Optional[int] = None
    cmUserId: Optional[str] = None
    tenantCode: Optional[str] = None
    userName: Optional[str] = None
    bucId: Optional[int] = None
    bid: Optional[str] = None
    needAuth: Optional[bool] = None
    parentUserId: Optional[int] = None
    securityToken: Optional[str] = None
    accessKeyId: Optional[str] = None
    timezone: Optional[str] = None
    region: Optional[str] = None
    userPermission: Optional[UserPermissionResponse] = None
    userType: Optional[str] = None
    partnerId: Optional[int] = None
    partnerName: Optional[str] = None
    partnerLogoUrl: Optional[str] = None
    sourceExternalTicket: Optional[str] = None
    thirdChannel: Optional[str] = None
