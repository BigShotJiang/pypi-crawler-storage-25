"""Model Gallery related models."""

from __future__ import annotations

from datetime import datetime
from typing import List, Optional, Set

from pydantic import BaseModel


# ---- Response models ----


class ModelDetailVO(BaseModel):
    """Model detail information."""

    modelImage: Optional[str] = None
    modelName: Optional[str] = None
    modelType: Optional[str] = None
    modelTag: Optional[str] = None
    modelSeries: Optional[str] = None
    price: Optional[str] = None
    newFlag: Optional[bool] = None
    updatedAt: Optional[datetime] = None
    createdOn: Optional[datetime] = None
    provider: Optional[str] = None
    originProvider: Optional[str] = None
    status: Optional[str] = None
    huggingFaceLink: Optional[str] = None
    modelSize: Optional[str] = None
    parameters: Optional[str] = None
    contextLength: Optional[int] = None
    language: Optional[str] = None
    supportedFunctionality: Optional[str] = None
    introduction: Optional[str] = None
    features: Optional[str] = None
    deployments: Optional[str] = None
    rawJson: Optional[str] = None


class TieredPricing(BaseModel):
    """Tiered pricing item."""

    model_config = {"extra": "allow"}


class VideoPricing(BaseModel):
    """Video pricing item."""

    model_config = {"extra": "allow"}


class ImagePricing(BaseModel):
    """Image pricing item."""

    model_config = {"extra": "allow"}


class PartnerApiPriceExtendDetail(BaseModel):
    """Partner API price extend detail (for Model Gallery price response)."""

    llmInput: Optional[str] = None
    llmOutput: Optional[str] = None
    vlmInput: Optional[str] = None
    vlmOutput: Optional[str] = None
    image: Optional[str] = None
    imageEa: Optional[str] = None
    imageStep: Optional[str] = None
    video: Optional[str] = None
    audio: Optional[str] = None
    tieredPricing: Optional[List[TieredPricing]] = None
    videoPricing: Optional[List[VideoPricing]] = None
    imagePricing: Optional[List[ImagePricing]] = None

    model_config = {"extra": "allow"}


class PartnerApiPriceResponse(BaseModel):
    """Model price response."""

    id: Optional[int] = None
    partnerId: Optional[int] = None
    modelName: Optional[str] = None
    modelType: Optional[str] = None
    type: Optional[str] = None
    originProvider: Optional[str] = None
    seriesProvider: Optional[str] = None
    capabilities: Optional[str] = None
    inputs: Optional[Set[str]] = None
    outputs: Optional[Set[str]] = None
    priceExtend: Optional[PartnerApiPriceExtendDetail] = None
    gmtCreate: Optional[datetime] = None
    gmtModified: Optional[datetime] = None
