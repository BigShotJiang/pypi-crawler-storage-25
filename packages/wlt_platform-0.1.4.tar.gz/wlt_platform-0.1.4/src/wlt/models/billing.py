"""Billing-related models."""

from __future__ import annotations

from decimal import Decimal
from typing import List, Optional

from pydantic import BaseModel, Field

from .common import PageInfo, PageRequest


# ---- Response models ----


class UserBillingMonthResponse(BaseModel):
    """Monthly billing amount summary."""

    afterDiscountAmountSum: Optional[Decimal] = None
    deductedByCouponsSum: Optional[Decimal] = None
    pretaxGrossAmountSum: Optional[Decimal] = None
    pretaxAmountSum: Optional[Decimal] = None
    currency: Optional[str] = None


class UserBillingGpuServiceResponse(BaseModel):
    """Billing detail by GPU spec."""

    afterDiscountAmountSum: Optional[Decimal] = None
    deductedByCouponsSum: Optional[Decimal] = None
    pretaxGrossAmountSum: Optional[Decimal] = None
    pretaxAmountSum: Optional[Decimal] = None
    listPrice: Optional[Decimal] = None
    currency: Optional[str] = None
    gpuSpec: Optional[str] = None
    servicePeriodUnit: Optional[str] = None
    servicePeriodSum: Optional[str] = None
    modelResource: Optional[str] = None


class UserBillingAiServiceResponse(BaseModel):
    """Billing detail by AI service."""

    afterDiscountAmountSum: Optional[Decimal] = None
    deductedByCouponsSum: Optional[Decimal] = None
    pretaxGrossAmountSum: Optional[Decimal] = None
    pretaxAmountSum: Optional[Decimal] = None
    currency: Optional[str] = None
    gpuSpec: Optional[str] = None
    modelResource: Optional[str] = None
    servicePeriodUnit: Optional[str] = None
    servicePeriodSum: Optional[str] = None
    bizType: Optional[str] = None


class UserBillingResponse(BaseModel):
    """Billing detail (line item)."""

    afterDiscountAmount: Optional[Decimal] = None
    deductedByCoupons: Optional[Decimal] = None
    pretaxGrossAmount: Optional[Decimal] = None
    pretaxAmount: Optional[Decimal] = None
    instanceID: Optional[str] = None
    currency: Optional[str] = None
    productCode: Optional[str] = None
    region: Optional[str] = None
    gpuSpec: Optional[str] = None
    modelResource: Optional[str] = None
    servicePeriodUnit: Optional[str] = None
    servicePeriod: Optional[str] = None
    bizType: Optional[str] = None
