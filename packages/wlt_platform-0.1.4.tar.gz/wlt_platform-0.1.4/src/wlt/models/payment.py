"""Payment-related models."""

from __future__ import annotations

from datetime import datetime
from typing import Any, List, Optional, Set

from pydantic import BaseModel, Field

from .common import PageRequest


# ---- Pagination: PageResponse (Payment-specific) ----


class PageResponse(BaseModel):
    """Payment module pagination structure (differs from PageInfo)."""

    pageNum: Optional[int] = 1
    pageSize: Optional[int] = 10
    total: Optional[int] = 0
    pages: Optional[int] = 0
    hasNext: Optional[bool] = None
    hasPrevious: Optional[bool] = None
    list: List[Any] = Field(default_factory=list)


# ---- Request models ----


class RechargeRecordsRequest(PageRequest):
    """Request parameters for querying recharge records (paginated)."""

    statusList: Optional[List[str]] = None
    startTime: Optional[datetime] = None
    endTime: Optional[datetime] = None
    transactionType: Optional[str] = None


class RechargeListRequest(BaseModel):
    """Request parameters for querying recharge records (non-paginated)."""

    statusList: Optional[List[str]] = None
    startTime: Optional[datetime] = None
    endTime: Optional[datetime] = None
    transactionType: Optional[str] = None


# ---- Response models ----


class RechargeTransactionResponse(BaseModel):
    """Recharge transaction record."""

    id: Optional[int] = None
    createdAtUtc: Optional[str] = None
    updatedAtUtc: Optional[str] = None
    userId: Optional[int] = None
    payChannel: Optional[str] = None
    payType: Optional[str] = None
    transactionType: Optional[str] = None
    status: Optional[str] = None
    callbackAtUtc: Optional[str] = None
    transactionNo: Optional[str] = None
    externalNo: Optional[str] = None
    amount: Optional[str] = None
    refundAmount: Optional[str] = None
    currency: Optional[str] = None
    refundStatus: Optional[str] = None
    originalTransactionNo: Optional[str] = None
    extend: Optional[str] = None


class RechargeStatisticsResponse(BaseModel):
    """Recharge statistics summary."""

    totalRechargedAmount: Optional[str] = None
    totalUsedRechargedAmount: Optional[str] = None
    totalBalanceRechargedAmount: Optional[str] = None
    totalRefundAmount: Optional[str] = None
    totalFreeAmount: Optional[str] = None
    currency: Optional[str] = None


class LmModelUsageBillingResponse(BaseModel):
    """Model usage billing record."""

    id: Optional[int] = None
    createdAtUtc: Optional[str] = None
    userId: Optional[int] = None
    username: Optional[str] = None
    modelName: Optional[str] = None
    modelType: Optional[str] = None
    feeType: Optional[str] = None
    unitPrice: Optional[str] = None
    currency: Optional[str] = None
    usedAmout: Optional[str] = None  # Note: field name matches backend spelling
    amount: Optional[str] = None
    billingTimeStart: Optional[str] = None
    billingTimeEnd: Optional[str] = None
    extend: Optional[str] = None
    inputs: Optional[Set[str]] = None
    outputs: Optional[Set[str]] = None


class ModelUsageBillingAmountResponse(BaseModel):
    """Model usage billing total amount."""

    totalBillingAmount: Optional[str] = None
    currency: Optional[str] = None
