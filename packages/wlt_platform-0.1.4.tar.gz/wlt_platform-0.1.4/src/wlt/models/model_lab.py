"""Model Lab related models."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel


# ---- Request models ----


class ModelLabListRequest(BaseModel):
    """Request parameters for model lab list.

    Matches ModelQueryRequest -- all 15 fields from the backend DTO.
    """

    modelName: Optional[str] = None
    provider: Optional[str] = None
    seriesProvider: Optional[str] = None
    modelType: Optional[str] = None
    viewAllFlag: Optional[int] = None
    pageSize: Optional[int] = None
    pageNum: Optional[int] = None
    usageType: Optional[str] = None
    trainingMethod: Optional[str] = None
    tags: Optional[List[str]] = None
    capability: Optional[str] = None
    modelTypeList: Optional[List[str]] = None
    originProviders: Optional[List[str]] = None
    inputs: Optional[List[str]] = None
    outputs: Optional[List[str]] = None


class OptionsDTO(BaseModel):
    """Model inference options."""

    temperature: Optional[float] = None
    maxToken: Optional[int] = None
    topP: Optional[float] = None
    topK: Optional[int] = None
    presencePenalty: Optional[float] = None
    frequencyPenalty: Optional[float] = None
    stopSequences: Optional[str] = None
    systemPrompt: Optional[str] = None
    enableThinking: Optional[bool] = None
    enableProgress: Optional[bool] = None
    timeoutSeconds: Optional[int] = None
    enableCache: Optional[bool] = None
    enableDocumentInlining: Optional[bool] = None
    budgetTokens: Optional[int] = None


class ModelStreamRequest(BaseModel):
    """Request parameters for model stream inference."""

    provider: str
    modelName: str
    userPrompt: Optional[str] = None
    sessionId: Optional[str] = None
    taskId: Optional[str] = None
    taskType: Optional[str] = "TEXT"
    isRetry: Optional[bool] = False
    options: Optional[OptionsDTO] = None


class CodeSamplesRequest(BaseModel):
    """Request parameters for getting model code samples."""

    modelId: str
    provider: str
    languages: Optional[List[str]] = None
    requestSchema: Optional[Any] = None
    modelType: Optional[str] = None


# ---- Response models ----


class ModelCodeSampleResponse(BaseModel):
    """Model code sample response."""

    samples: Optional[Dict[str, str]] = None
