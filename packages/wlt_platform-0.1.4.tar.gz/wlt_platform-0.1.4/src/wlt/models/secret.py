"""Secret-related models."""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any, List, Optional, Set

from pydantic import BaseModel, Field

from .common import PageInfo, PageRequest


# ---- Request models ----

class SecretListRequest(PageRequest):
    """Request parameters for listing secrets."""

    status: Optional[int] = Field(default=None, description="Status filter: 1=active, 0=disabled")
    expiredBeforeUtc: Optional[datetime] = Field(default=None, description="Expiry time upper bound (UTC)")


class SecretCreateRequest(BaseModel):
    """Request parameters for creating a secret."""

    name: Optional[str] = None
    allowedModels: Optional[List[str]] = None
    allowedProviders: Optional[List[str]] = None
    ipWhiteList: Optional[List[str]] = None
    minuteTokensQuota: Optional[int] = None
    annualTokensQuota: Optional[int] = None
    expiredAtUtc: Optional[datetime] = None
    byokIds: Optional[List[int]] = None


class SecretEditRequest(BaseModel):
    """Request parameters for editing a secret."""

    id: int
    name: Optional[str] = None
    allowedModels: Optional[List[str]] = None
    allowedProviders: Optional[List[str]] = None
    ipWhiteList: Optional[List[str]] = None
    minuteTokensQuota: Optional[int] = None
    annualTokensQuota: Optional[int] = None
    expiredAtUtc: Optional[datetime] = None
    byokIds: Optional[List[int]] = None


class SecretActionRequest(BaseModel):
    """Request parameters for secret status actions."""

    id: int
    status: str  # ENABLE / DISABLE / DELETE


class SecretUsageByModelRequest(PageRequest):
    """Request parameters for querying secret usage by model."""

    secretId: int
    startTime: Optional[datetime] = None
    endTime: Optional[datetime] = None


class ModelQueryRequest(BaseModel):
    """Request parameters for querying available models."""

    modelName: Optional[str] = None
    provider: Optional[str] = None
    seriesProvider: Optional[str] = None
    modelType: Optional[str] = None
    viewAllFlag: Optional[int] = None
    pageSize: Optional[int] = None
    pageNum: Optional[int] = None
    usageType: Optional[str] = None
    trainingMethod: Optional[str] = None
    tags: Optional[List[str]] = None
    capability: Optional[str] = None
    modelTypeList: Optional[List[str]] = None
    originProviders: Optional[List[str]] = None
    inputs: Optional[List[str]] = None
    outputs: Optional[List[str]] = None


# ---- Response models ----

class ApikeyVO(BaseModel):
    """API key summary (used inside SecretVO.byokList and ApiKey module)."""

    id: Optional[str] = None
    name: Optional[str] = None
    key: Optional[str] = None
    provider: Optional[str] = None
    providerId: Optional[str] = None
    account: Optional[str] = None
    accountId: Optional[str] = None
    projectID: Optional[str] = None
    created: Optional[datetime] = None
    lastUsedAt: Optional[datetime] = None
    status: Optional[str] = None
    accessKeyID: Optional[str] = None
    accessKeySecret: Optional[str] = None
    resaleStatus: Optional[str] = None


class SecretVO(BaseModel):
    """Secret detail."""

    id: Optional[int] = None
    name: Optional[str] = None
    keyId: Optional[str] = None
    status: Optional[str] = None
    createdAt: Optional[datetime] = None
    lastUsed: Optional[datetime] = None
    expiredFlag: Optional[bool] = None
    allowedModels: Optional[List[str]] = None
    allowedProviders: Optional[List[str]] = None
    ipWhiteList: Optional[List[str]] = None
    minuteTokensQuota: Optional[int] = None
    annualTokensQuota: Optional[int] = None
    description: Optional[str] = None
    expiredAtUtc: Optional[datetime] = None
    byokList: Optional[List[ApikeyVO]] = None
    defaultSecret: Optional[int] = None
    createUser: Optional[str] = None


class SecretPageResultVO(BaseModel):
    """Result for secret list queries including summary stats."""

    totalKeys: Optional[int] = None
    activeKeys: Optional[int] = None
    totalRequest: Optional[int] = None
    avgQps: Optional[float] = None
    pageInfo: Optional[PageInfo[SecretVO]] = None


class SecretUsageDataVO(BaseModel):
    """Secret usage statistics summary."""

    totalAPICalls: Optional[int] = None
    totalTokens: Optional[int] = None
    promptTokens: Optional[int] = None
    completionTokens: Optional[int] = None


class SecretModelUsageVO(BaseModel):
    """Secret usage breakdown by model."""

    model: Optional[str] = None
    requests: Optional[int] = None
    totalTokens: Optional[int] = None
    promptTokens: Optional[int] = None
    completionTokens: Optional[int] = None


class PartnerApiPriceExtend(BaseModel):
    """Tenant API price extension info (opaque)."""

    model_config = {"extra": "allow"}


class ModelInfoVO(BaseModel):
    """Model information."""

    modelId: Optional[str] = None
    modelName: Optional[str] = None
    modelImage: Optional[str] = None
    isNew: Optional[int] = None
    provider: Optional[str] = None
    providerName: Optional[str] = None
    originProvider: Optional[str] = None
    seriesProvider: Optional[str] = None
    modelType: Optional[str] = None
    tags: Optional[List[str]] = None
    modelSize: Optional[str] = None
    feature: Optional[str] = None
    price: Optional[Decimal] = None
    unit: Optional[str] = None
    available: Optional[bool] = None
    updated: Optional[datetime] = None
    deployPlatform: Optional[str] = None
    regionId: Optional[str] = None
    deployFrameworks: Optional[List[str]] = None
    labels: Optional[List[str]] = None
    capabilities: Optional[List[str]] = None
    inputs: Optional[List[str]] = None
    outputs: Optional[List[str]] = None
    priceExtend: Optional[PartnerApiPriceExtend] = None
    requestSchema: Optional[Any] = None
    dataSource: Optional[str] = None
