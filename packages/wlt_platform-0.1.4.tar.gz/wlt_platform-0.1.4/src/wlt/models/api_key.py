"""ApiKey-related models."""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel

from .common import PageInfo, PageRequest
from .secret import ApikeyVO


# ---- Request models ----

class ApiKeyQueryRequest(PageRequest):
    """Request parameters for listing API keys."""

    provider: Optional[str] = None
    timezone: Optional[str] = None


class ApiKeyCreateRequest(BaseModel):
    """Request parameters for creating an API key."""

    provider: str
    keyName: Optional[str] = None
    status: Optional[int] = None
    accessKeyID: Optional[str] = None
    accessKeySecret: Optional[str] = None
    tpmLimit: Optional[str] = None
    tokenLimit: Optional[str] = None


class ApiKeyUpdateRequest(BaseModel):
    """Request parameters for updating an API key."""

    id: Optional[int] = None
    provider: Optional[str] = None
    keyName: Optional[str] = None
    aliyunAccountID: Optional[str] = None
    status: Optional[int] = None
    accessKeyID: Optional[str] = None
    accessKeySecret: Optional[str] = None
    resaleStatus: Optional[str] = None
    tpmLimit: Optional[str] = None
    tokenLimit: Optional[str] = None


class ApiKeyTestRequest(BaseModel):
    """Request parameters for testing API key connectivity."""

    aliyunAccountID: Optional[str] = None
    accessKeyID: Optional[str] = None
    accessKeySecret: Optional[str] = None
    provider: Optional[str] = None


class ApiKeyQueryByProvidersOrIdsRequest(BaseModel):
    """Request parameters for querying API keys by providers or IDs."""

    secretId: Optional[int] = None
    providers: Optional[List[str]] = None
    ids: Optional[List[int]] = None


# ---- Response models ----

class ApiKeyResultVO(BaseModel):
    """Result for API key list queries including summary stats."""

    totalApiCalls: Optional[int] = None
    activeKeys: Optional[int] = None
    apiKeys: Optional[PageInfo[ApikeyVO]] = None
