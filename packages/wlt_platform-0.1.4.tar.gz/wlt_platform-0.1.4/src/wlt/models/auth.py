"""Authentication-related models."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel


class LoginRequest(BaseModel):
    """Login request parameters."""

    username: str
    password: str


class PartnerResponse(BaseModel):
    """Tenant (partner) information."""

    id: Optional[int] = None
    gmtCreate: Optional[datetime] = None
    gmtModified: Optional[datetime] = None
    userId: Optional[int] = None
    name: Optional[str] = None
    logo: Optional[str] = None
    status: Optional[str] = None
    extend: Optional[Any] = None
    url: Optional[str] = None
