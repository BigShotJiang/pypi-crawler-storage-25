"""Common type definitions for the WLT SDK."""

from __future__ import annotations

from typing import TypeVar

from pydantic import BaseModel

T = TypeVar("T")

# Sentinel for distinguishing "not provided" from None
_UNSET = object()


class _UnsetType:
    """Sentinel type used to distinguish 'not provided' from None."""

    _instance: _UnsetType | None = None

    def __new__(cls) -> _UnsetType:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __bool__(self) -> bool:
        return False

    def __repr__(self) -> str:
        return "UNSET"


UNSET = _UnsetType()


class HeadersDict(dict):
    """A dict subclass for HTTP headers."""

    pass
