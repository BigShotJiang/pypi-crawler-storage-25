"""Client configuration for the WLT SDK."""

from __future__ import annotations

import os
from dataclasses import dataclass, field

#: Default WLT Console API base URL when neither argument nor env var is set.
DEFAULT_BASE_URL = "https://daily.sssxuntui.com"

#: Environment variable name for overriding the base URL at the SDK layer.
BASE_URL_ENV = "WLT_BASE_URL"


def resolve_base_url(base_url: str | None = None) -> str:
    """Resolve effective base URL with priority: argument > env var > default.

    A ``None`` argument is treated the same as omitting the argument, so the
    SDK still falls back to the environment variable and finally to the
    hard-coded default. Trailing slashes are stripped.
    """
    if base_url:
        value = base_url
    else:
        env_value = os.environ.get(BASE_URL_ENV)
        value = env_value if env_value else DEFAULT_BASE_URL
    return value.rstrip("/")


@dataclass
class ClientConfig:
    """Configuration for the WLT client.

    Attributes:
        api_key: API key used to obtain a Bearer Token via loginByApiKey.
            The SDK automatically calls ``POST /xt-console/api/user/loginByApiKey``
            to exchange the api_key for a short-lived token, then uses that token
            in the ``Authorization: Bearer {token}`` header for all subsequent requests.
        base_url: The base URL of the WLT Console API.
            Resolution priority: explicit value > ``WLT_BASE_URL`` env var > default.
            Trailing slashes are stripped automatically.
        timeout: Request timeout in seconds. Default is 30.
        max_retries: Maximum number of retry attempts for transient failures.
            Default is 2. Retries use exponential backoff with jitter.
        default_headers: Additional headers to include in every request.
    """

    api_key: str = ""
    base_url: str | None = None
    timeout: float = 30.0
    max_retries: int = 2
    default_headers: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        # Resolve via priority chain: explicit > env > default.
        self.base_url = resolve_base_url(self.base_url)
        if not self.api_key:
            raise ValueError("api_key is required and must not be empty")
