"""Billing resource -- monthly billing queries."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional

from ..models.billing import (
    UserBillingAiServiceResponse,
    UserBillingGpuServiceResponse,
    UserBillingMonthResponse,
    UserBillingResponse,
)
from ..models.common import BaseResponse, PageInfo

if TYPE_CHECKING:
    from .._http import AsyncHTTPClient, SyncHTTPClient


class BillingResource:
    """Synchronous Billing operations."""

    def __init__(self, http: SyncHTTPClient) -> None:
        self._http = http

    def query_all_amount(
        self,
        *,
        billing_cycle: str,
    ) -> BaseResponse[UserBillingMonthResponse]:
        """Query total billing amount for a given billing cycle.

        Args:
            billing_cycle: Billing period, e.g. "2026-04".

        Returns:
            BaseResponse containing UserBillingMonthResponse.
        """
        raw = self._http.request(
            "GET",
            "/xt-console/api/billing/queryAllAmount",
            params={"billingCycle": billing_cycle},
        )
        data = raw.get("data")
        parsed_data = UserBillingMonthResponse(**data) if data is not None else None
        return BaseResponse[UserBillingMonthResponse](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def query_bill_by_gpu(
        self,
        *,
        billing_cycle: str,
        page_size: int = 10,
        page_num: int = 1,
    ) -> BaseResponse[PageInfo[UserBillingGpuServiceResponse]]:
        """Query billing details by GPU spec with pagination.

        Args:
            billing_cycle: Billing period, e.g. "2026-04".
            page_size: Items per page (default 10).
            page_num: Page number, starting from 1 (default 1).

        Returns:
            BaseResponse containing paginated GPU billing data.
        """
        raw = self._http.request(
            "GET",
            "/xt-console/api/billing/queryBillByGpu",
            params={
                "billingCycle": billing_cycle,
                "pageSize": page_size,
                "pageNum": page_num,
            },
        )
        data = raw.get("data")
        if data is not None:
            items = data.get("list", [])
            parsed_items = [UserBillingGpuServiceResponse(**item) for item in items]
            parsed_data = PageInfo[UserBillingGpuServiceResponse](
                total=data.get("total", 0),
                totalPages=data.get("totalPages", 0),
                currentPage=data.get("currentPage", 1),
                pageSize=data.get("pageSize", page_size),
                list=parsed_items,
            )
        else:
            parsed_data = None
        return BaseResponse[PageInfo[UserBillingGpuServiceResponse]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def query_bill_by_service(
        self,
        *,
        billing_cycle: str,
        page_size: int = 10,
        page_num: int = 1,
    ) -> BaseResponse[PageInfo[UserBillingAiServiceResponse]]:
        """Query billing details by AI service with pagination.

        Args:
            billing_cycle: Billing period, e.g. "2026-04".
            page_size: Items per page (default 10).
            page_num: Page number, starting from 1 (default 1).

        Returns:
            BaseResponse containing paginated AI service billing data.
        """
        raw = self._http.request(
            "GET",
            "/xt-console/api/billing/queryBillByService",
            params={
                "billingCycle": billing_cycle,
                "pageSize": page_size,
                "pageNum": page_num,
            },
        )
        data = raw.get("data")
        if data is not None:
            items = data.get("list", [])
            parsed_items = [UserBillingAiServiceResponse(**item) for item in items]
            parsed_data = PageInfo[UserBillingAiServiceResponse](
                total=data.get("total", 0),
                totalPages=data.get("totalPages", 0),
                currentPage=data.get("currentPage", 1),
                pageSize=data.get("pageSize", page_size),
                list=parsed_items,
            )
        else:
            parsed_data = None
        return BaseResponse[PageInfo[UserBillingAiServiceResponse]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def query_bill_list(
        self,
        *,
        billing_cycle: str,
        page_size: int = 10,
        page_num: int = 1,
    ) -> BaseResponse[PageInfo[UserBillingResponse]]:
        """Query billing detail list with pagination.

        Args:
            billing_cycle: Billing period, e.g. "2026-04".
            page_size: Items per page (default 10).
            page_num: Page number, starting from 1 (default 1).

        Returns:
            BaseResponse containing paginated billing detail data.
        """
        raw = self._http.request(
            "GET",
            "/xt-console/api/billing/queryBillList",
            params={
                "billingCycle": billing_cycle,
                "pageSize": page_size,
                "pageNum": page_num,
            },
        )
        data = raw.get("data")
        if data is not None:
            items = data.get("list", [])
            parsed_items = [UserBillingResponse(**item) for item in items]
            parsed_data = PageInfo[UserBillingResponse](
                total=data.get("total", 0),
                totalPages=data.get("totalPages", 0),
                currentPage=data.get("currentPage", 1),
                pageSize=data.get("pageSize", page_size),
                list=parsed_items,
            )
        else:
            parsed_data = None
        return BaseResponse[PageInfo[UserBillingResponse]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )


class AsyncBillingResource:
    """Asynchronous Billing operations."""

    def __init__(self, http: AsyncHTTPClient) -> None:
        self._http = http

    async def query_all_amount(
        self,
        *,
        billing_cycle: str,
    ) -> BaseResponse[UserBillingMonthResponse]:
        """Query total billing amount for a given billing cycle (async)."""
        raw = await self._http.request(
            "GET",
            "/xt-console/api/billing/queryAllAmount",
            params={"billingCycle": billing_cycle},
        )
        data = raw.get("data")
        parsed_data = UserBillingMonthResponse(**data) if data is not None else None
        return BaseResponse[UserBillingMonthResponse](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def query_bill_by_gpu(
        self,
        *,
        billing_cycle: str,
        page_size: int = 10,
        page_num: int = 1,
    ) -> BaseResponse[PageInfo[UserBillingGpuServiceResponse]]:
        """Query billing details by GPU spec with pagination (async)."""
        raw = await self._http.request(
            "GET",
            "/xt-console/api/billing/queryBillByGpu",
            params={
                "billingCycle": billing_cycle,
                "pageSize": page_size,
                "pageNum": page_num,
            },
        )
        data = raw.get("data")
        if data is not None:
            items = data.get("list", [])
            parsed_items = [UserBillingGpuServiceResponse(**item) for item in items]
            parsed_data = PageInfo[UserBillingGpuServiceResponse](
                total=data.get("total", 0),
                totalPages=data.get("totalPages", 0),
                currentPage=data.get("currentPage", 1),
                pageSize=data.get("pageSize", page_size),
                list=parsed_items,
            )
        else:
            parsed_data = None
        return BaseResponse[PageInfo[UserBillingGpuServiceResponse]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def query_bill_by_service(
        self,
        *,
        billing_cycle: str,
        page_size: int = 10,
        page_num: int = 1,
    ) -> BaseResponse[PageInfo[UserBillingAiServiceResponse]]:
        """Query billing details by AI service with pagination (async)."""
        raw = await self._http.request(
            "GET",
            "/xt-console/api/billing/queryBillByService",
            params={
                "billingCycle": billing_cycle,
                "pageSize": page_size,
                "pageNum": page_num,
            },
        )
        data = raw.get("data")
        if data is not None:
            items = data.get("list", [])
            parsed_items = [UserBillingAiServiceResponse(**item) for item in items]
            parsed_data = PageInfo[UserBillingAiServiceResponse](
                total=data.get("total", 0),
                totalPages=data.get("totalPages", 0),
                currentPage=data.get("currentPage", 1),
                pageSize=data.get("pageSize", page_size),
                list=parsed_items,
            )
        else:
            parsed_data = None
        return BaseResponse[PageInfo[UserBillingAiServiceResponse]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def query_bill_list(
        self,
        *,
        billing_cycle: str,
        page_size: int = 10,
        page_num: int = 1,
    ) -> BaseResponse[PageInfo[UserBillingResponse]]:
        """Query billing detail list with pagination (async)."""
        raw = await self._http.request(
            "GET",
            "/xt-console/api/billing/queryBillList",
            params={
                "billingCycle": billing_cycle,
                "pageSize": page_size,
                "pageNum": page_num,
            },
        )
        data = raw.get("data")
        if data is not None:
            items = data.get("list", [])
            parsed_items = [UserBillingResponse(**item) for item in items]
            parsed_data = PageInfo[UserBillingResponse](
                total=data.get("total", 0),
                totalPages=data.get("totalPages", 0),
                currentPage=data.get("currentPage", 1),
                pageSize=data.get("pageSize", page_size),
                list=parsed_items,
            )
        else:
            parsed_data = None
        return BaseResponse[PageInfo[UserBillingResponse]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )
