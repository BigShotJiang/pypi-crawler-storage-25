"""Model Gallery resource -- retained endpoints merged into Model module.

Retains 4 endpoints from Model Gallery:
- detail (GET /xt-console/api/models/{modelId})
- provider_list (GET /xt-console/api/models/provider)
- get_price (GET /xt-console/api/models/getPartnerApiPrice)
- page (POST /xt-console/api/models/page)  -- restored in v2.4

Removed: query, series_provider_list, technology_list, feature_list, new_models, all
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, List, Optional

from ..models.common import BaseResponse, PageInfo, ProviderVO
from ..models.model_gallery import (
    ModelDetailVO,
    PartnerApiPriceResponse,
)
from ..models.secret import ModelInfoVO, ModelQueryRequest

if TYPE_CHECKING:
    from .._http import AsyncHTTPClient, SyncHTTPClient


def _exclude_none(d: dict[str, Any]) -> dict[str, Any]:
    """Return a copy of dict with None values removed."""
    return {k: v for k, v in d.items() if v is not None}


class ModelGalleryResource:
    """Synchronous Model Gallery operations (retained endpoints only)."""

    def __init__(self, http: SyncHTTPClient) -> None:
        self._http = http

    def detail(self, *, model_id: str) -> BaseResponse[ModelDetailVO]:
        """Get model detail by model ID.

        Args:
            model_id: The model ID.

        Returns:
            BaseResponse containing ModelDetailVO.
        """
        raw = self._http.request(
            "GET",
            f"/xt-console/api/models/{model_id}",
        )
        data = raw.get("data")
        parsed_data = ModelDetailVO(**data) if data is not None else None
        return BaseResponse[ModelDetailVO](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def provider_list(self) -> BaseResponse[List[ProviderVO]]:
        """Get the list of model providers.

        Returns:
            BaseResponse containing a list of ProviderVO.
        """
        raw = self._http.request("GET", "/xt-console/api/models/provider")
        data = raw.get("data")
        parsed_data = (
            [ProviderVO(**item) for item in data] if data is not None else None
        )
        return BaseResponse[List[ProviderVO]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def get_price(
        self,
        *,
        model_name: str,
    ) -> BaseResponse[PartnerApiPriceResponse]:
        """Get model API price for current tenant.

        Args:
            model_name: Model name.

        Returns:
            BaseResponse containing PartnerApiPriceResponse.
        """
        raw = self._http.request(
            "GET",
            "/xt-console/api/models/getPartnerApiPrice",
            params={"modelName": model_name},
        )
        data = raw.get("data")
        parsed_data = PartnerApiPriceResponse(**data) if data is not None else None
        return BaseResponse[PartnerApiPriceResponse](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def page(
        self,
        *,
        model_name: Optional[str] = None,
        provider: Optional[str] = None,
        series_provider: Optional[str] = None,
        model_type: Optional[str] = None,
        view_all_flag: Optional[int] = None,
        page_size: Optional[int] = None,
        page_num: Optional[int] = None,
        usage_type: Optional[str] = None,
        training_method: Optional[str] = None,
        tags: Optional[List[str]] = None,
        capability: Optional[str] = None,
        model_type_list: Optional[List[str]] = None,
        origin_providers: Optional[List[str]] = None,
        inputs: Optional[List[str]] = None,
        outputs: Optional[List[str]] = None,
    ) -> BaseResponse[PageInfo[ModelInfoVO]]:
        """Query model list with pagination (Model Gallery).

        Args:
            model_name: Model name (fuzzy match).
            provider: Provider identifier.
            series_provider: Series provider identifier.
            model_type: Model type.
            view_all_flag: View all flag (1=view all).
            page_size: Page size (default 10).
            page_num: Page number, starting from 1 (default 1).
            usage_type: Usage type: "inference" or "train".
            training_method: Training method: "sft" or "dpo".
            tags: Tag list, e.g. ["New"], ["Fast"].
            capability: Capability identifier, e.g. "text_to_text".
            model_type_list: Model type list (multi-select filter).
            origin_providers: Origin providers list (multi-select filter).
            inputs: Input type list, e.g. ["text"].
            outputs: Output type list, e.g. ["text"].

        Returns:
            BaseResponse containing PageInfo[ModelInfoVO].
        """
        req = ModelQueryRequest(
            modelName=model_name,
            provider=provider,
            seriesProvider=series_provider,
            modelType=model_type,
            viewAllFlag=view_all_flag,
            pageSize=page_size,
            pageNum=page_num,
            usageType=usage_type,
            trainingMethod=training_method,
            tags=tags,
            capability=capability,
            modelTypeList=model_type_list,
            originProviders=origin_providers,
            inputs=inputs,
            outputs=outputs,
        )
        raw = self._http.request(
            "POST",
            "/xt-console/api/models/page",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        if data is not None:
            items = data.get("list", [])
            parsed_items = [ModelInfoVO(**item) for item in items] if items else []
            parsed_data = PageInfo[ModelInfoVO](
                total=data.get("total", 0),
                list=parsed_items,
                totalPages=data.get("totalPages"),
                currentPage=data.get("currentPage"),
                pageSize=data.get("pageSize"),
            )
        else:
            parsed_data = None
        return BaseResponse[PageInfo[ModelInfoVO]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )


class AsyncModelGalleryResource:
    """Asynchronous Model Gallery operations (retained endpoints only)."""

    def __init__(self, http: AsyncHTTPClient) -> None:
        self._http = http

    async def detail(self, *, model_id: str) -> BaseResponse[ModelDetailVO]:
        """Get model detail by model ID (async)."""
        raw = await self._http.request(
            "GET",
            f"/xt-console/api/models/{model_id}",
        )
        data = raw.get("data")
        parsed_data = ModelDetailVO(**data) if data is not None else None
        return BaseResponse[ModelDetailVO](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def provider_list(self) -> BaseResponse[List[ProviderVO]]:
        """Get the list of model providers (async)."""
        raw = await self._http.request("GET", "/xt-console/api/models/provider")
        data = raw.get("data")
        parsed_data = (
            [ProviderVO(**item) for item in data] if data is not None else None
        )
        return BaseResponse[List[ProviderVO]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def get_price(
        self,
        *,
        model_name: str,
    ) -> BaseResponse[PartnerApiPriceResponse]:
        """Get model API price for current tenant (async)."""
        raw = await self._http.request(
            "GET",
            "/xt-console/api/models/getPartnerApiPrice",
            params={"modelName": model_name},
        )
        data = raw.get("data")
        parsed_data = PartnerApiPriceResponse(**data) if data is not None else None
        return BaseResponse[PartnerApiPriceResponse](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def page(
        self,
        *,
        model_name: Optional[str] = None,
        provider: Optional[str] = None,
        series_provider: Optional[str] = None,
        model_type: Optional[str] = None,
        view_all_flag: Optional[int] = None,
        page_size: Optional[int] = None,
        page_num: Optional[int] = None,
        usage_type: Optional[str] = None,
        training_method: Optional[str] = None,
        tags: Optional[List[str]] = None,
        capability: Optional[str] = None,
        model_type_list: Optional[List[str]] = None,
        origin_providers: Optional[List[str]] = None,
        inputs: Optional[List[str]] = None,
        outputs: Optional[List[str]] = None,
    ) -> BaseResponse[PageInfo[ModelInfoVO]]:
        """Query model list with pagination (Model Gallery, async)."""
        req = ModelQueryRequest(
            modelName=model_name,
            provider=provider,
            seriesProvider=series_provider,
            modelType=model_type,
            viewAllFlag=view_all_flag,
            pageSize=page_size,
            pageNum=page_num,
            usageType=usage_type,
            trainingMethod=training_method,
            tags=tags,
            capability=capability,
            modelTypeList=model_type_list,
            originProviders=origin_providers,
            inputs=inputs,
            outputs=outputs,
        )
        raw = await self._http.request(
            "POST",
            "/xt-console/api/models/page",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        if data is not None:
            items = data.get("list", [])
            parsed_items = [ModelInfoVO(**item) for item in items] if items else []
            parsed_data = PageInfo[ModelInfoVO](
                total=data.get("total", 0),
                list=parsed_items,
                totalPages=data.get("totalPages"),
                currentPage=data.get("currentPage"),
                pageSize=data.get("pageSize"),
            )
        else:
            parsed_data = None
        return BaseResponse[PageInfo[ModelInfoVO]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )
