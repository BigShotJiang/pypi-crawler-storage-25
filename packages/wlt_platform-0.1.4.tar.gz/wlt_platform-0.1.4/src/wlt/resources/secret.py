"""Secret resource -- CRUD, usage, models, providers."""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any, Optional

from ..models.common import BaseResponse, PageInfo, ProviderVO
from ..models.secret import (
    ModelInfoVO,
    ModelQueryRequest,
    SecretActionRequest,
    SecretCreateRequest,
    SecretEditRequest,
    SecretListRequest,
    SecretModelUsageVO,
    SecretPageResultVO,
    SecretUsageByModelRequest,
    SecretUsageDataVO,
    SecretVO,
)

if TYPE_CHECKING:
    from .._http import AsyncHTTPClient, SyncHTTPClient


def _exclude_none(d: dict[str, Any]) -> dict[str, Any]:
    """Return a copy of dict with None values removed."""
    return {k: v for k, v in d.items() if v is not None}


class SecretResource:
    """Synchronous Secret operations."""

    def __init__(self, http: SyncHTTPClient) -> None:
        self._http = http

    def list(
        self,
        *,
        page_num: Optional[int] = 1,
        page_size: Optional[int] = 10,
        status: Optional[int] = None,
        expired_before_utc: Optional[datetime] = None,
    ) -> BaseResponse[SecretPageResultVO]:
        """List secrets with pagination and optional filters.

        Args:
            page_num: Page number (default 1).
            page_size: Items per page (default 10).
            status: Filter by status: 1=active, 0=disabled.
            expired_before_utc: Filter secrets expiring before this UTC time.

        Returns:
            BaseResponse containing SecretPageResultVO with stats and page data.
        """
        req = SecretListRequest(
            pageNum=page_num,
            pageSize=page_size,
            status=status,
            expiredBeforeUtc=expired_before_utc,
        )
        raw = self._http.request(
            "POST",
            "/xt-console/api/secret/list",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = SecretPageResultVO(**data) if data is not None else None
        return BaseResponse[SecretPageResultVO](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def detail(self, *, id: int) -> BaseResponse[SecretVO]:
        """Get a single secret's details.

        Args:
            id: The Secret ID.

        Returns:
            BaseResponse containing the SecretVO detail.
        """
        raw = self._http.request(
            "GET",
            "/xt-console/api/secret/detail",
            params={"id": id},
        )
        data = raw.get("data")
        parsed_data = SecretVO(**data) if data is not None else None
        return BaseResponse[SecretVO](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def create(
        self,
        *,
        name: Optional[str] = None,
        allowed_models: Optional[list[str]] = None,
        allowed_providers: Optional[list[str]] = None,
        ip_white_list: Optional[list[str]] = None,
        minute_tokens_quota: Optional[int] = None,
        annual_tokens_quota: Optional[int] = None,
        expired_at_utc: Optional[datetime] = None,
        byok_ids: Optional[list[int]] = None,
    ) -> BaseResponse[str]:
        """Create a new secret.

        Args:
            name: Secret name.
            allowed_models: List of allowed model names.
            allowed_providers: List of allowed provider names.
            ip_white_list: IP whitelist (CIDR notation).
            minute_tokens_quota: Per-minute token quota.
            annual_tokens_quota: Annual token quota.
            expired_at_utc: Expiry time in UTC.
            byok_ids: List of BYOK key IDs to associate.

        Returns:
            BaseResponse with data containing the generated API key string.
        """
        req = SecretCreateRequest(
            name=name,
            allowedModels=allowed_models,
            allowedProviders=allowed_providers,
            ipWhiteList=ip_white_list,
            minuteTokensQuota=minute_tokens_quota,
            annualTokensQuota=annual_tokens_quota,
            expiredAtUtc=expired_at_utc,
            byokIds=byok_ids,
        )
        raw = self._http.request(
            "POST",
            "/xt-console/api/secret",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        return BaseResponse[str](**raw)

    def edit(
        self,
        *,
        id: int,
        name: Optional[str] = None,
        allowed_models: Optional[list[str]] = None,
        allowed_providers: Optional[list[str]] = None,
        ip_white_list: Optional[list[str]] = None,
        minute_tokens_quota: Optional[int] = None,
        annual_tokens_quota: Optional[int] = None,
        expired_at_utc: Optional[datetime] = None,
        byok_ids: Optional[list[int]] = None,
    ) -> BaseResponse[bool]:
        """Edit an existing secret.

        Args:
            id: Secret ID (required).
            name: Updated name.
            allowed_models: Updated list of allowed model names.
            allowed_providers: Updated list of allowed providers.
            ip_white_list: Updated IP whitelist.
            minute_tokens_quota: Updated per-minute token quota.
            annual_tokens_quota: Updated annual token quota.
            expired_at_utc: Updated expiry time in UTC.
            byok_ids: Updated BYOK key IDs.

        Returns:
            BaseResponse with data=True on success.
        """
        req = SecretEditRequest(
            id=id,
            name=name,
            allowedModels=allowed_models,
            allowedProviders=allowed_providers,
            ipWhiteList=ip_white_list,
            minuteTokensQuota=minute_tokens_quota,
            annualTokensQuota=annual_tokens_quota,
            expiredAtUtc=expired_at_utc,
            byokIds=byok_ids,
        )
        body = req.model_dump(mode="json")
        # Always include 'id' even though it's not None
        body = {k: v for k, v in body.items() if v is not None or k == "id"}
        raw = self._http.request("POST", "/xt-console/api/secret/edit", json=body)
        return BaseResponse[bool](**raw)

    def action(self, *, id: int, status: str) -> BaseResponse[bool]:
        """Perform an action on a secret (enable, disable, or delete).

        Args:
            id: Secret ID.
            status: Action to perform: "ENABLE", "DISABLE", or "DELETE".

        Returns:
            BaseResponse with data=True on success.
        """
        req = SecretActionRequest(id=id, status=status)
        raw = self._http.request(
            "POST",
            "/xt-console/api/secret/action",
            json=req.model_dump(mode="json"),
        )
        return BaseResponse[bool](**raw)

    def enable(self, *, id: int) -> BaseResponse[bool]:
        """Enable a secret. Convenience wrapper around action()."""
        return self.action(id=id, status="ENABLE")

    def disable(self, *, id: int) -> BaseResponse[bool]:
        """Disable a secret. Convenience wrapper around action()."""
        return self.action(id=id, status="DISABLE")

    def delete(self, *, id: int) -> BaseResponse[bool]:
        """Delete a secret. Convenience wrapper around action()."""
        return self.action(id=id, status="DELETE")

    def get_usage_data(self, *, id: int) -> BaseResponse[SecretUsageDataVO]:
        """Get usage statistics for a specific secret.

        Args:
            id: Secret ID.

        Returns:
            BaseResponse containing usage stats (API calls, tokens, etc.).
        """
        raw = self._http.request(
            "GET",
            "/xt-console/api/secret/getUsageData",
            params={"id": id},
        )
        data = raw.get("data")
        parsed_data = SecretUsageDataVO(**data) if data is not None else None
        return BaseResponse[SecretUsageDataVO](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def usage_by_model(
        self,
        *,
        secret_id: int,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        page_num: Optional[int] = 1,
        page_size: Optional[int] = 10,
    ) -> BaseResponse[PageInfo[SecretModelUsageVO]]:
        """Query secret usage breakdown by model with pagination.

        Args:
            secret_id: Secret ID.
            start_time: Query start time.
            end_time: Query end time.
            page_num: Page number (default 1).
            page_size: Items per page (default 10).

        Returns:
            BaseResponse containing paginated model usage data.
        """
        req = SecretUsageByModelRequest(
            secretId=secret_id,
            startTime=start_time,
            endTime=end_time,
            pageNum=page_num,
            pageSize=page_size,
        )
        raw = self._http.request(
            "POST",
            "/xt-console/api/secret/usageByModel",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = PageInfo[SecretModelUsageVO](**data) if data is not None else None
        return BaseResponse[PageInfo[SecretModelUsageVO]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def model_list(
        self,
        *,
        model_name: Optional[str] = None,
        provider: Optional[str] = None,
        series_provider: Optional[str] = None,
        model_type: Optional[str] = None,
        view_all_flag: Optional[int] = None,
        page_size: Optional[int] = None,
        page_num: Optional[int] = None,
        usage_type: Optional[str] = None,
        training_method: Optional[str] = None,
        tags: Optional[list[str]] = None,
        capability: Optional[str] = None,
        model_type_list: Optional[list[str]] = None,
        origin_providers: Optional[list[str]] = None,
        inputs: Optional[list[str]] = None,
        outputs: Optional[list[str]] = None,
    ) -> BaseResponse[list[ModelInfoVO]]:
        """Query available models for secret binding.

        Args:
            model_name: Fuzzy search by model name.
            provider: Filter by provider.
            series_provider: Filter by series provider.
            model_type: Filter by model type.
            view_all_flag: Whether to view all models.
            page_size: Items per page.
            page_num: Page number.
            usage_type: Usage type: "inference" or "train".
            training_method: Training method: "sft" or "dpo".
            tags: Filter by tags (e.g. ["New", "Fast"]).
            capability: Filter by capability (e.g. "text_to_text").
            model_type_list: Filter by model type list.
            origin_providers: Filter by origin providers.
            inputs: Filter by input types.
            outputs: Filter by output types.

        Returns:
            BaseResponse containing a list of ModelInfoVO.
        """
        req = ModelQueryRequest(
            modelName=model_name,
            provider=provider,
            seriesProvider=series_provider,
            modelType=model_type,
            viewAllFlag=view_all_flag,
            pageSize=page_size,
            pageNum=page_num,
            usageType=usage_type,
            trainingMethod=training_method,
            tags=tags,
            capability=capability,
            modelTypeList=model_type_list,
            originProviders=origin_providers,
            inputs=inputs,
            outputs=outputs,
        )
        raw = self._http.request(
            "POST",
            "/xt-console/api/secret/modelList",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = (
            [ModelInfoVO(**item) for item in data] if data is not None else None
        )
        return BaseResponse[list[ModelInfoVO]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def provider_list(self) -> BaseResponse[list[ProviderVO]]:
        """Get the list of providers available for secrets.

        Returns:
            BaseResponse containing a list of ProviderVO.
        """
        raw = self._http.request("GET", "/xt-console/api/secret/provider")
        data = raw.get("data")
        parsed_data = (
            [ProviderVO(**item) for item in data] if data is not None else None
        )
        return BaseResponse[list[ProviderVO]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )


class AsyncSecretResource:
    """Asynchronous Secret operations."""

    def __init__(self, http: AsyncHTTPClient) -> None:
        self._http = http

    async def list(
        self,
        *,
        page_num: Optional[int] = 1,
        page_size: Optional[int] = 10,
        status: Optional[int] = None,
        expired_before_utc: Optional[datetime] = None,
    ) -> BaseResponse[SecretPageResultVO]:
        """List secrets with pagination and optional filters (async)."""
        req = SecretListRequest(
            pageNum=page_num,
            pageSize=page_size,
            status=status,
            expiredBeforeUtc=expired_before_utc,
        )
        raw = await self._http.request(
            "POST",
            "/xt-console/api/secret/list",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = SecretPageResultVO(**data) if data is not None else None
        return BaseResponse[SecretPageResultVO](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def detail(self, *, id: int) -> BaseResponse[SecretVO]:
        """Get a single secret's details (async)."""
        raw = await self._http.request(
            "GET",
            "/xt-console/api/secret/detail",
            params={"id": id},
        )
        data = raw.get("data")
        parsed_data = SecretVO(**data) if data is not None else None
        return BaseResponse[SecretVO](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def create(
        self,
        *,
        name: Optional[str] = None,
        allowed_models: Optional[list[str]] = None,
        allowed_providers: Optional[list[str]] = None,
        ip_white_list: Optional[list[str]] = None,
        minute_tokens_quota: Optional[int] = None,
        annual_tokens_quota: Optional[int] = None,
        expired_at_utc: Optional[datetime] = None,
        byok_ids: Optional[list[int]] = None,
    ) -> BaseResponse[str]:
        """Create a new secret (async)."""
        req = SecretCreateRequest(
            name=name,
            allowedModels=allowed_models,
            allowedProviders=allowed_providers,
            ipWhiteList=ip_white_list,
            minuteTokensQuota=minute_tokens_quota,
            annualTokensQuota=annual_tokens_quota,
            expiredAtUtc=expired_at_utc,
            byokIds=byok_ids,
        )
        raw = await self._http.request(
            "POST",
            "/xt-console/api/secret",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        return BaseResponse[str](**raw)

    async def edit(
        self,
        *,
        id: int,
        name: Optional[str] = None,
        allowed_models: Optional[list[str]] = None,
        allowed_providers: Optional[list[str]] = None,
        ip_white_list: Optional[list[str]] = None,
        minute_tokens_quota: Optional[int] = None,
        annual_tokens_quota: Optional[int] = None,
        expired_at_utc: Optional[datetime] = None,
        byok_ids: Optional[list[int]] = None,
    ) -> BaseResponse[bool]:
        """Edit an existing secret (async)."""
        req = SecretEditRequest(
            id=id,
            name=name,
            allowedModels=allowed_models,
            allowedProviders=allowed_providers,
            ipWhiteList=ip_white_list,
            minuteTokensQuota=minute_tokens_quota,
            annualTokensQuota=annual_tokens_quota,
            expiredAtUtc=expired_at_utc,
            byokIds=byok_ids,
        )
        body = req.model_dump(mode="json")
        body = {k: v for k, v in body.items() if v is not None or k == "id"}
        raw = await self._http.request("POST", "/xt-console/api/secret/edit", json=body)
        return BaseResponse[bool](**raw)

    async def action(self, *, id: int, status: str) -> BaseResponse[bool]:
        """Perform an action on a secret (async)."""
        req = SecretActionRequest(id=id, status=status)
        raw = await self._http.request(
            "POST",
            "/xt-console/api/secret/action",
            json=req.model_dump(mode="json"),
        )
        return BaseResponse[bool](**raw)

    async def enable(self, *, id: int) -> BaseResponse[bool]:
        """Enable a secret (async)."""
        return await self.action(id=id, status="ENABLE")

    async def disable(self, *, id: int) -> BaseResponse[bool]:
        """Disable a secret (async)."""
        return await self.action(id=id, status="DISABLE")

    async def delete(self, *, id: int) -> BaseResponse[bool]:
        """Delete a secret (async)."""
        return await self.action(id=id, status="DELETE")

    async def get_usage_data(self, *, id: int) -> BaseResponse[SecretUsageDataVO]:
        """Get usage statistics for a specific secret (async)."""
        raw = await self._http.request(
            "GET",
            "/xt-console/api/secret/getUsageData",
            params={"id": id},
        )
        data = raw.get("data")
        parsed_data = SecretUsageDataVO(**data) if data is not None else None
        return BaseResponse[SecretUsageDataVO](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def usage_by_model(
        self,
        *,
        secret_id: int,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        page_num: Optional[int] = 1,
        page_size: Optional[int] = 10,
    ) -> BaseResponse[PageInfo[SecretModelUsageVO]]:
        """Query secret usage breakdown by model (async)."""
        req = SecretUsageByModelRequest(
            secretId=secret_id,
            startTime=start_time,
            endTime=end_time,
            pageNum=page_num,
            pageSize=page_size,
        )
        raw = await self._http.request(
            "POST",
            "/xt-console/api/secret/usageByModel",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = PageInfo[SecretModelUsageVO](**data) if data is not None else None
        return BaseResponse[PageInfo[SecretModelUsageVO]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def model_list(
        self,
        *,
        model_name: Optional[str] = None,
        provider: Optional[str] = None,
        series_provider: Optional[str] = None,
        model_type: Optional[str] = None,
        view_all_flag: Optional[int] = None,
        page_size: Optional[int] = None,
        page_num: Optional[int] = None,
        usage_type: Optional[str] = None,
        training_method: Optional[str] = None,
        tags: Optional[list[str]] = None,
        capability: Optional[str] = None,
        model_type_list: Optional[list[str]] = None,
        origin_providers: Optional[list[str]] = None,
        inputs: Optional[list[str]] = None,
        outputs: Optional[list[str]] = None,
    ) -> BaseResponse[list[ModelInfoVO]]:
        """Query available models for secret binding (async)."""
        req = ModelQueryRequest(
            modelName=model_name,
            provider=provider,
            seriesProvider=series_provider,
            modelType=model_type,
            viewAllFlag=view_all_flag,
            pageSize=page_size,
            pageNum=page_num,
            usageType=usage_type,
            trainingMethod=training_method,
            tags=tags,
            capability=capability,
            modelTypeList=model_type_list,
            originProviders=origin_providers,
            inputs=inputs,
            outputs=outputs,
        )
        raw = await self._http.request(
            "POST",
            "/xt-console/api/secret/modelList",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = (
            [ModelInfoVO(**item) for item in data] if data is not None else None
        )
        return BaseResponse[list[ModelInfoVO]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def provider_list(self) -> BaseResponse[list[ProviderVO]]:
        """Get the list of providers available for secrets (async)."""
        raw = await self._http.request("GET", "/xt-console/api/secret/provider")
        data = raw.get("data")
        parsed_data = (
            [ProviderVO(**item) for item in data] if data is not None else None
        )
        return BaseResponse[list[ProviderVO]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )
