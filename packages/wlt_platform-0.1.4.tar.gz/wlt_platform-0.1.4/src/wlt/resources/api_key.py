"""ApiKey resource -- CRUD, status change, connectivity test, providers."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional

from ..models.api_key import (
    ApiKeyCreateRequest,
    ApiKeyQueryByProvidersOrIdsRequest,
    ApiKeyQueryRequest,
    ApiKeyResultVO,
    ApiKeyTestRequest,
    ApiKeyUpdateRequest,
)
from ..models.common import BaseResponse, ProviderVO
from ..models.secret import ApikeyVO

if TYPE_CHECKING:
    from .._http import AsyncHTTPClient, SyncHTTPClient


def _exclude_none(d: dict[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in d.items() if v is not None}


class ApiKeyResource:
    """Synchronous ApiKey (BYOK) operations."""

    def __init__(self, http: SyncHTTPClient) -> None:
        self._http = http

    def list(
        self,
        *,
        page_num: Optional[int] = 1,
        page_size: Optional[int] = 10,
        provider: Optional[str] = None,
        timezone: Optional[str] = None,
    ) -> BaseResponse[ApiKeyResultVO]:
        """List API keys with pagination and optional filters.

        Args:
            page_num: Page number (default 1).
            page_size: Items per page (default 10).
            provider: Filter by provider name.
            timezone: Timezone for time field localization.

        Returns:
            BaseResponse containing ApiKeyResultVO with stats and page data.
        """
        req = ApiKeyQueryRequest(
            pageNum=page_num,
            pageSize=page_size,
            provider=provider,
            timezone=timezone,
        )
        raw = self._http.request(
            "POST",
            "/xt-console/api/apiKeys/list",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = ApiKeyResultVO(**data) if data is not None else None
        return BaseResponse[ApiKeyResultVO](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def create(
        self,
        *,
        provider: str,
        key_name: Optional[str] = None,
        status: Optional[int] = None,
        access_key_id: Optional[str] = None,
        access_key_secret: Optional[str] = None,
        tpm_limit: Optional[str] = None,
        token_limit: Optional[str] = None,
    ) -> BaseResponse[ApikeyVO]:
        """Create a new BYOK API key.

        Args:
            provider: Provider name (must be a valid BYOK provider).
            key_name: Display name for the key.
            status: Initial status.
            access_key_id: AccessKey ID (e.g. for Alibaba Cloud).
            access_key_secret: AccessKey Secret.
            tpm_limit: Tokens per minute limit.
            token_limit: Total token limit.

        Returns:
            BaseResponse containing the newly created ApikeyVO.
        """
        req = ApiKeyCreateRequest(
            provider=provider,
            keyName=key_name,
            status=status,
            accessKeyID=access_key_id,
            accessKeySecret=access_key_secret,
            tpmLimit=tpm_limit,
            tokenLimit=token_limit,
        )
        raw = self._http.request(
            "POST",
            "/xt-console/api/apiKeys",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = ApikeyVO(**data) if data is not None else None
        return BaseResponse[ApikeyVO](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def update(
        self,
        *,
        path_id: str,
        id: Optional[int] = None,
        provider: Optional[str] = None,
        key_name: Optional[str] = None,
        aliyun_account_id: Optional[str] = None,
        status: Optional[int] = None,
        access_key_id: Optional[str] = None,
        access_key_secret: Optional[str] = None,
        resale_status: Optional[str] = None,
        tpm_limit: Optional[str] = None,
        token_limit: Optional[str] = None,
    ) -> BaseResponse[bool]:
        """Update an existing API key.

        Args:
            path_id: ApiKey ID for URL routing (string).
            id: ApiKey database primary key (int, for body).
            provider: Updated provider name.
            key_name: Updated key name.
            aliyun_account_id: Alibaba Cloud account ID.
            status: Updated status.
            access_key_id: Updated AccessKey ID.
            access_key_secret: Updated AccessKey Secret.
            resale_status: Updated resale status.
            tpm_limit: Updated TPM limit.
            token_limit: Updated token limit.

        Returns:
            BaseResponse with data=True on success.
        """
        req = ApiKeyUpdateRequest(
            id=id,
            provider=provider,
            keyName=key_name,
            aliyunAccountID=aliyun_account_id,
            status=status,
            accessKeyID=access_key_id,
            accessKeySecret=access_key_secret,
            resaleStatus=resale_status,
            tpmLimit=tpm_limit,
            tokenLimit=token_limit,
        )
        raw = self._http.request(
            "PUT",
            f"/xt-console/api/apiKeys/{path_id}",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        return BaseResponse[bool](**raw)

    def delete(self, *, id: str) -> BaseResponse[bool]:
        """Delete an API key.

        Args:
            id: ApiKey ID (string).

        Returns:
            BaseResponse with data=True on success.
        """
        raw = self._http.request("DELETE", f"/xt-console/api/apiKeys/{id}")
        return BaseResponse[bool](**raw)

    def change_status(self, *, id: str, status: int) -> BaseResponse[bool]:
        """Enable or disable an API key.

        Args:
            id: ApiKey ID.
            status: Target status: 1=enable, 0=disable.

        Returns:
            BaseResponse with data=True on success.
        """
        raw = self._http.request(
            "POST",
            "/xt-console/api/apiKeys/changeStatus",
            params={"id": id, "status": status},
        )
        return BaseResponse[bool](**raw)

    def enable(self, *, id: str) -> BaseResponse[bool]:
        """Enable an API key. Convenience wrapper around change_status()."""
        return self.change_status(id=id, status=1)

    def disable(self, *, id: str) -> BaseResponse[bool]:
        """Disable an API key. Convenience wrapper around change_status()."""
        return self.change_status(id=id, status=0)

    def test_connect(
        self,
        *,
        aliyun_account_id: Optional[str] = None,
        access_key_id: Optional[str] = None,
        access_key_secret: Optional[str] = None,
        provider: Optional[str] = None,
    ) -> BaseResponse[bool]:
        """Test API key connectivity.

        Args:
            aliyun_account_id: Alibaba Cloud account ID.
            access_key_id: AccessKey ID.
            access_key_secret: AccessKey Secret.
            provider: Provider name.

        Returns:
            BaseResponse with data=True if connection succeeds.
        """
        req = ApiKeyTestRequest(
            aliyunAccountID=aliyun_account_id,
            accessKeyID=access_key_id,
            accessKeySecret=access_key_secret,
            provider=provider,
        )
        raw = self._http.request(
            "POST",
            "/xt-console/api/apiKeys/testConnect",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        return BaseResponse[bool](**raw)

    def get_by_providers_or_ids(
        self,
        *,
        secret_id: Optional[int] = None,
        providers: Optional[list[str]] = None,
        ids: Optional[list[int]] = None,
    ) -> BaseResponse[list[ApikeyVO]]:
        """Query API keys by providers or IDs.

        Args:
            secret_id: Optional Secret ID for context.
            providers: List of provider names to filter by.
            ids: List of ApiKey IDs to filter by.

        Returns:
            BaseResponse containing a list of matching ApikeyVO.
        """
        req = ApiKeyQueryByProvidersOrIdsRequest(
            secretId=secret_id,
            providers=providers,
            ids=ids,
        )
        raw = self._http.request(
            "POST",
            "/xt-console/api/apiKeys/getByProvidersOrIds",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = (
            [ApikeyVO(**item) for item in data] if data is not None else None
        )
        return BaseResponse[list[ApikeyVO]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def provider_list(self) -> BaseResponse[list[ProviderVO]]:
        """Get the list of providers available for API keys.

        Returns:
            BaseResponse containing a list of ProviderVO.
        """
        raw = self._http.request("GET", "/xt-console/api/apiKeys/provider")
        data = raw.get("data")
        parsed_data = (
            [ProviderVO(**item) for item in data] if data is not None else None
        )
        return BaseResponse[list[ProviderVO]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )


class AsyncApiKeyResource:
    """Asynchronous ApiKey (BYOK) operations."""

    def __init__(self, http: AsyncHTTPClient) -> None:
        self._http = http

    async def list(
        self,
        *,
        page_num: Optional[int] = 1,
        page_size: Optional[int] = 10,
        provider: Optional[str] = None,
        timezone: Optional[str] = None,
    ) -> BaseResponse[ApiKeyResultVO]:
        """List API keys with pagination and optional filters (async)."""
        req = ApiKeyQueryRequest(
            pageNum=page_num,
            pageSize=page_size,
            provider=provider,
            timezone=timezone,
        )
        raw = await self._http.request(
            "POST",
            "/xt-console/api/apiKeys/list",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = ApiKeyResultVO(**data) if data is not None else None
        return BaseResponse[ApiKeyResultVO](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def create(
        self,
        *,
        provider: str,
        key_name: Optional[str] = None,
        status: Optional[int] = None,
        access_key_id: Optional[str] = None,
        access_key_secret: Optional[str] = None,
        tpm_limit: Optional[str] = None,
        token_limit: Optional[str] = None,
    ) -> BaseResponse[ApikeyVO]:
        """Create a new BYOK API key (async)."""
        req = ApiKeyCreateRequest(
            provider=provider,
            keyName=key_name,
            status=status,
            accessKeyID=access_key_id,
            accessKeySecret=access_key_secret,
            tpmLimit=tpm_limit,
            tokenLimit=token_limit,
        )
        raw = await self._http.request(
            "POST",
            "/xt-console/api/apiKeys",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = ApikeyVO(**data) if data is not None else None
        return BaseResponse[ApikeyVO](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def update(
        self,
        *,
        path_id: str,
        id: Optional[int] = None,
        provider: Optional[str] = None,
        key_name: Optional[str] = None,
        aliyun_account_id: Optional[str] = None,
        status: Optional[int] = None,
        access_key_id: Optional[str] = None,
        access_key_secret: Optional[str] = None,
        resale_status: Optional[str] = None,
        tpm_limit: Optional[str] = None,
        token_limit: Optional[str] = None,
    ) -> BaseResponse[bool]:
        """Update an existing API key (async)."""
        req = ApiKeyUpdateRequest(
            id=id,
            provider=provider,
            keyName=key_name,
            aliyunAccountID=aliyun_account_id,
            status=status,
            accessKeyID=access_key_id,
            accessKeySecret=access_key_secret,
            resaleStatus=resale_status,
            tpmLimit=tpm_limit,
            tokenLimit=token_limit,
        )
        raw = await self._http.request(
            "PUT",
            f"/xt-console/api/apiKeys/{path_id}",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        return BaseResponse[bool](**raw)

    async def delete(self, *, id: str) -> BaseResponse[bool]:
        """Delete an API key (async)."""
        raw = await self._http.request("DELETE", f"/xt-console/api/apiKeys/{id}")
        return BaseResponse[bool](**raw)

    async def change_status(self, *, id: str, status: int) -> BaseResponse[bool]:
        """Enable or disable an API key (async)."""
        raw = await self._http.request(
            "POST",
            "/xt-console/api/apiKeys/changeStatus",
            params={"id": id, "status": status},
        )
        return BaseResponse[bool](**raw)

    async def enable(self, *, id: str) -> BaseResponse[bool]:
        """Enable an API key (async)."""
        return await self.change_status(id=id, status=1)

    async def disable(self, *, id: str) -> BaseResponse[bool]:
        """Disable an API key (async)."""
        return await self.change_status(id=id, status=0)

    async def test_connect(
        self,
        *,
        aliyun_account_id: Optional[str] = None,
        access_key_id: Optional[str] = None,
        access_key_secret: Optional[str] = None,
        provider: Optional[str] = None,
    ) -> BaseResponse[bool]:
        """Test API key connectivity (async)."""
        req = ApiKeyTestRequest(
            aliyunAccountID=aliyun_account_id,
            accessKeyID=access_key_id,
            accessKeySecret=access_key_secret,
            provider=provider,
        )
        raw = await self._http.request(
            "POST",
            "/xt-console/api/apiKeys/testConnect",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        return BaseResponse[bool](**raw)

    async def get_by_providers_or_ids(
        self,
        *,
        secret_id: Optional[int] = None,
        providers: Optional[list[str]] = None,
        ids: Optional[list[int]] = None,
    ) -> BaseResponse[list[ApikeyVO]]:
        """Query API keys by providers or IDs (async)."""
        req = ApiKeyQueryByProvidersOrIdsRequest(
            secretId=secret_id,
            providers=providers,
            ids=ids,
        )
        raw = await self._http.request(
            "POST",
            "/xt-console/api/apiKeys/getByProvidersOrIds",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = (
            [ApikeyVO(**item) for item in data] if data is not None else None
        )
        return BaseResponse[list[ApikeyVO]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def provider_list(self) -> BaseResponse[list[ProviderVO]]:
        """Get the list of providers available for API keys (async)."""
        raw = await self._http.request("GET", "/xt-console/api/apiKeys/provider")
        data = raw.get("data")
        parsed_data = (
            [ProviderVO(**item) for item in data] if data is not None else None
        )
        return BaseResponse[list[ProviderVO]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )
