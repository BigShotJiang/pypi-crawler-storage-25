"""Model Lab resource -- model list, stream inference, parameters, code samples, session."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, Iterator, List, Optional

from ..models.common import BaseResponse
from ..models.model_lab import (
    CodeSamplesRequest,
    ModelCodeSampleResponse,
    ModelLabListRequest,
    ModelStreamRequest,
    OptionsDTO,
)
from ..models.secret import ModelInfoVO

if TYPE_CHECKING:
    from .._http import AsyncHTTPClient, SyncHTTPClient


def _exclude_none(d: dict[str, Any]) -> dict[str, Any]:
    """Return a copy of dict with None values removed."""
    return {k: v for k, v in d.items() if v is not None}


class ModelLabResource:
    """Synchronous Model Lab operations."""

    def __init__(self, http: SyncHTTPClient) -> None:
        self._http = http

    def list(
        self,
        *,
        model_name: Optional[str] = None,
        provider: Optional[str] = None,
        series_provider: Optional[str] = None,
        model_type: Optional[str] = None,
        view_all_flag: Optional[int] = None,
        page_size: Optional[int] = 20,
        page_num: Optional[int] = 1,
        usage_type: Optional[str] = None,
        training_method: Optional[str] = None,
        tags: Optional[List[str]] = None,
        capability: Optional[str] = None,
        model_type_list: Optional[List[str]] = None,
        origin_providers: Optional[List[str]] = None,
        inputs: Optional[List[str]] = None,
        outputs: Optional[List[str]] = None,
    ) -> BaseResponse[List[ModelInfoVO]]:
        """Get model list (non-paginated).

        Args:
            model_name: Model name (fuzzy match).
            provider: Provider identifier.
            series_provider: Series provider identifier.
            model_type: Model type.
            view_all_flag: View all flag (1=view all).
            page_size: Page size (required by backend, default 20).
            page_num: Page number (required by backend, default 1).
            usage_type: Usage type: "inference" or "train".
            training_method: Training method: "sft" or "dpo".
            tags: Tag list, e.g. ["New"], ["Fast"].
            capability: Capability identifier, e.g. "text_to_text".
            model_type_list: Model type list (multi-select filter).
            origin_providers: Origin providers list (multi-select filter).
            inputs: Input type list, e.g. ["text"].
            outputs: Output type list (max 1 element), e.g. ["text"].

        Returns:
            BaseResponse containing list of ModelInfoVO.
        """
        req = ModelLabListRequest(
            modelName=model_name,
            provider=provider,
            seriesProvider=series_provider,
            modelType=model_type,
            viewAllFlag=view_all_flag,
            pageSize=page_size,
            pageNum=page_num,
            usageType=usage_type,
            trainingMethod=training_method,
            tags=tags,
            capability=capability,
            modelTypeList=model_type_list,
            originProviders=origin_providers,
            inputs=inputs,
            outputs=outputs,
        )
        raw = self._http.request(
            "POST",
            "/xt-console/api/model/list",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = (
            [ModelInfoVO(**item) for item in data] if data is not None else None
        )
        return BaseResponse[List[ModelInfoVO]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def stream(
        self,
        *,
        provider: str,
        model_name: str,
        user_prompt: Optional[str] = None,
        session_id: Optional[str] = None,
        task_id: Optional[str] = None,
        task_type: Optional[str] = "TEXT",
        is_retry: Optional[bool] = False,
        options: Optional[OptionsDTO] = None,
    ) -> Iterator[str]:
        """Call model stream inference (SSE).

        Yields each SSE data chunk as a raw JSON string. Callers can
        parse each chunk with ``json.loads()`` to inspect delta content,
        finish_reason, usage, etc.

        Args:
            provider: Service provider identifier.
            model_name: Model name.
            user_prompt: User prompt text.
            session_id: Session ID for multi-turn conversations.
            task_id: Task ID (for retry).
            task_type: Task type (default TEXT).
            is_retry: Whether this is a retry request.
            options: Model parameter configuration.

        Yields:
            Raw JSON string for each SSE data event.
        """
        req = ModelStreamRequest(
            provider=provider,
            modelName=model_name,
            userPrompt=user_prompt,
            sessionId=session_id,
            taskId=task_id,
            taskType=task_type,
            isRetry=is_retry,
            options=options,
        )
        yield from self._http.stream_request(
            "POST",
            "/xt-console/api/model/stream",
            json_body=_exclude_none(req.model_dump(mode="json")),
        )

    def get_parameters(
        self,
        *,
        model_id: str,
        provider: str,
    ) -> BaseResponse[Dict[str, Any]]:
        """Get model parameter configuration.

        Args:
            model_id: Model ID.
            provider: Provider identifier.

        Returns:
            BaseResponse containing parameter config dict.
        """
        raw = self._http.request(
            "GET",
            "/xt-console/api/model/parameters",
            params={"modelId": model_id, "provider": provider},
        )
        return BaseResponse[Dict[str, Any]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=raw.get("data"),
        )

    def create_session(self) -> BaseResponse[str]:
        """Create a new chat session.

        Returns:
            BaseResponse containing the session ID (UUID string).
        """
        raw = self._http.request(
            "GET",
            "/xt-console/api/model/chat/session/create",
        )
        return BaseResponse[str](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=raw.get("data"),
        )

    def code_samples(
        self,
        *,
        model_id: str,
        provider: str,
        languages: Optional[List[str]] = None,
        request_schema: Optional[Any] = None,
        model_type: Optional[str] = None,
    ) -> BaseResponse[ModelCodeSampleResponse]:
        """Get model code samples in multiple languages.

        Args:
            model_id: Model ID.
            provider: Provider identifier.
            languages: Language codes (CURL / Python / JavaScript / Go / Java).
            request_schema: Custom request parameter JSON Schema.
            model_type: Model type (IMAGE / VIDEO etc.).

        Returns:
            BaseResponse containing ModelCodeSampleResponse.
        """
        req = CodeSamplesRequest(
            modelId=model_id,
            provider=provider,
            languages=languages,
            requestSchema=request_schema,
            modelType=model_type,
        )
        raw = self._http.request(
            "POST",
            "/xt-console/api/model/code-samples",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = ModelCodeSampleResponse(**data) if data is not None else None
        return BaseResponse[ModelCodeSampleResponse](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )


class AsyncModelLabResource:
    """Asynchronous Model Lab operations."""

    def __init__(self, http: AsyncHTTPClient) -> None:
        self._http = http

    async def list(
        self,
        *,
        model_name: Optional[str] = None,
        provider: Optional[str] = None,
        series_provider: Optional[str] = None,
        model_type: Optional[str] = None,
        view_all_flag: Optional[int] = None,
        page_size: Optional[int] = 20,
        page_num: Optional[int] = 1,
        usage_type: Optional[str] = None,
        training_method: Optional[str] = None,
        tags: Optional[List[str]] = None,
        capability: Optional[str] = None,
        model_type_list: Optional[List[str]] = None,
        origin_providers: Optional[List[str]] = None,
        inputs: Optional[List[str]] = None,
        outputs: Optional[List[str]] = None,
    ) -> BaseResponse[List[ModelInfoVO]]:
        """Get model list (async, non-paginated)."""
        req = ModelLabListRequest(
            modelName=model_name,
            provider=provider,
            seriesProvider=series_provider,
            modelType=model_type,
            viewAllFlag=view_all_flag,
            pageSize=page_size,
            pageNum=page_num,
            usageType=usage_type,
            trainingMethod=training_method,
            tags=tags,
            capability=capability,
            modelTypeList=model_type_list,
            originProviders=origin_providers,
            inputs=inputs,
            outputs=outputs,
        )
        raw = await self._http.request(
            "POST",
            "/xt-console/api/model/list",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = (
            [ModelInfoVO(**item) for item in data] if data is not None else None
        )
        return BaseResponse[List[ModelInfoVO]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def stream(
        self,
        *,
        provider: str,
        model_name: str,
        user_prompt: Optional[str] = None,
        session_id: Optional[str] = None,
        task_id: Optional[str] = None,
        task_type: Optional[str] = "TEXT",
        is_retry: Optional[bool] = False,
        options: Optional[OptionsDTO] = None,
    ):
        """Call model stream inference (SSE, async).

        Yields each SSE data chunk as a raw JSON string.
        """
        req = ModelStreamRequest(
            provider=provider,
            modelName=model_name,
            userPrompt=user_prompt,
            sessionId=session_id,
            taskId=task_id,
            taskType=task_type,
            isRetry=is_retry,
            options=options,
        )
        async for chunk in self._http.stream_request(
            "POST",
            "/xt-console/api/model/stream",
            json_body=_exclude_none(req.model_dump(mode="json")),
        ):
            yield chunk

    async def get_parameters(
        self,
        *,
        model_id: str,
        provider: str,
    ) -> BaseResponse[Dict[str, Any]]:
        """Get model parameter configuration (async)."""
        raw = await self._http.request(
            "GET",
            "/xt-console/api/model/parameters",
            params={"modelId": model_id, "provider": provider},
        )
        return BaseResponse[Dict[str, Any]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=raw.get("data"),
        )

    async def create_session(self) -> BaseResponse[str]:
        """Create a new chat session (async)."""
        raw = await self._http.request(
            "GET",
            "/xt-console/api/model/chat/session/create",
        )
        return BaseResponse[str](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=raw.get("data"),
        )

    async def code_samples(
        self,
        *,
        model_id: str,
        provider: str,
        languages: Optional[List[str]] = None,
        request_schema: Optional[Any] = None,
        model_type: Optional[str] = None,
    ) -> BaseResponse[ModelCodeSampleResponse]:
        """Get model code samples (async)."""
        req = CodeSamplesRequest(
            modelId=model_id,
            provider=provider,
            languages=languages,
            requestSchema=request_schema,
            modelType=model_type,
        )
        raw = await self._http.request(
            "POST",
            "/xt-console/api/model/code-samples",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = ModelCodeSampleResponse(**data) if data is not None else None
        return BaseResponse[ModelCodeSampleResponse](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )
