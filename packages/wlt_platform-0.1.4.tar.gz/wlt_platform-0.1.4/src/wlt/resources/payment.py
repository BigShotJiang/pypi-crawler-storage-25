"""Payment resource -- recharge records, statistics, model usage billing."""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..models.common import BaseResponse, PageInfo
from ..models.payment import (
    LmModelUsageBillingResponse,
    ModelUsageBillingAmountResponse,
    PageResponse,
    RechargeListRequest,
    RechargeRecordsRequest,
    RechargeStatisticsResponse,
    RechargeTransactionResponse,
)

if TYPE_CHECKING:
    from .._http import AsyncHTTPClient, SyncHTTPClient


def _exclude_none(d: dict[str, Any]) -> dict[str, Any]:
    """Return a copy of dict with None values removed."""
    return {k: v for k, v in d.items() if v is not None}


class PaymentResource:
    """Synchronous Payment operations."""

    def __init__(self, http: SyncHTTPClient) -> None:
        self._http = http

    def records(
        self,
        *,
        page_num: Optional[int] = 1,
        page_size: Optional[int] = 10,
        status_list: Optional[List[str]] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        transaction_type: Optional[str] = None,
    ) -> BaseResponse[PageResponse]:
        """Query recharge records with pagination.

        Args:
            page_num: Page number (default 1).
            page_size: Items per page (default 10, max 1000).
            status_list: Status filter list (0=processing, 1=success, 2=failed, 3=closed).
            start_time: Query start time.
            end_time: Query end time.
            transaction_type: Transaction type (Recharge / Refund).

        Returns:
            BaseResponse containing PageResponse with RechargeTransactionResponse items.
        """
        req = RechargeRecordsRequest(
            pageNum=page_num,
            pageSize=page_size,
            statusList=status_list,
            startTime=start_time,
            endTime=end_time,
            transactionType=transaction_type,
        )
        raw = self._http.request(
            "POST",
            "/xt-console/api/payment/records",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        if data is not None:
            items = data.get("list", [])
            parsed_items = [RechargeTransactionResponse(**item) for item in items]
            parsed_data = PageResponse(
                pageNum=data.get("pageNum", 1),
                pageSize=data.get("pageSize", page_size),
                total=data.get("total", 0),
                pages=data.get("pages", 0),
                hasNext=data.get("hasNext"),
                hasPrevious=data.get("hasPrevious"),
                list=parsed_items,
            )
        else:
            parsed_data = None
        return BaseResponse[PageResponse](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def statistics(self) -> BaseResponse[RechargeStatisticsResponse]:
        """Query recharge statistics summary.

        Returns:
            BaseResponse containing RechargeStatisticsResponse.
        """
        raw = self._http.request(
            "GET",
            "/xt-console/api/payment/statistics",
        )
        data = raw.get("data")
        parsed_data = RechargeStatisticsResponse(**data) if data is not None else None
        return BaseResponse[RechargeStatisticsResponse](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def list(
        self,
        *,
        status_list: Optional[List[str]] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        transaction_type: Optional[str] = None,
    ) -> BaseResponse[List[RechargeTransactionResponse]]:
        """Query recharge transaction list (non-paginated).

        Args:
            status_list: Status filter list.
            start_time: Query start time.
            end_time: Query end time.
            transaction_type: Transaction type (Recharge / Refund).

        Returns:
            BaseResponse containing list of RechargeTransactionResponse.
        """
        req = RechargeListRequest(
            statusList=status_list,
            startTime=start_time,
            endTime=end_time,
            transactionType=transaction_type,
        )
        raw = self._http.request(
            "POST",
            "/xt-console/api/payment/list",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = (
            [RechargeTransactionResponse(**item) for item in data]
            if data is not None
            else None
        )
        return BaseResponse[List[RechargeTransactionResponse]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def get_record(
        self,
        *,
        transaction_no: str,
    ) -> BaseResponse[RechargeTransactionResponse]:
        """Get a single recharge record by transaction number.

        Args:
            transaction_no: Platform transaction number.

        Returns:
            BaseResponse containing RechargeTransactionResponse.
        """
        raw = self._http.request(
            "GET",
            f"/xt-console/api/payment/record/{transaction_no}",
        )
        data = raw.get("data")
        parsed_data = RechargeTransactionResponse(**data) if data is not None else None
        return BaseResponse[RechargeTransactionResponse](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def billing_list(
        self,
        *,
        page_num: Optional[int] = 1,
        page_size: Optional[int] = 10,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        model_id: Optional[str] = None,
    ) -> BaseResponse[PageInfo[LmModelUsageBillingResponse]]:
        """Query model usage billing list with pagination.

        Args:
            page_num: Page number (default 1).
            page_size: Items per page (default 10, max 1000).
            start_time: Start time, format yyyy-MM-dd HH:mm:ss.
            end_time: End time, format yyyy-MM-dd HH:mm:ss.
            model_id: Model ID for exact filtering.

        Returns:
            BaseResponse containing paginated LmModelUsageBillingResponse.
        """
        params: dict[str, Any] = {
            "pageNum": page_num,
            "pageSize": page_size,
        }
        if start_time is not None:
            params["startTime"] = start_time
        if end_time is not None:
            params["endTime"] = end_time
        if model_id is not None:
            params["modelId"] = model_id
        raw = self._http.request(
            "GET",
            "/xt-console/api/payment/billing/list",
            params=params,
        )
        data = raw.get("data")
        if data is not None:
            items = data.get("list", [])
            parsed_items = [LmModelUsageBillingResponse(**item) for item in items]
            parsed_data = PageInfo[LmModelUsageBillingResponse](
                total=data.get("total", 0),
                totalPages=data.get("totalPages", 0),
                currentPage=data.get("currentPage", 1),
                pageSize=data.get("pageSize", page_size),
                list=parsed_items,
            )
        else:
            parsed_data = None
        return BaseResponse[PageInfo[LmModelUsageBillingResponse]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def billing_query_all_amount(
        self,
        *,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        model_id: Optional[str] = None,
    ) -> BaseResponse[ModelUsageBillingAmountResponse]:
        """Query model usage billing total amount.

        Args:
            start_time: Start time, format yyyy-MM-dd HH:mm:ss.
            end_time: End time, format yyyy-MM-dd HH:mm:ss.
            model_id: Model ID for exact filtering.

        Returns:
            BaseResponse containing ModelUsageBillingAmountResponse.
        """
        params: dict[str, Any] = {}
        if start_time is not None:
            params["startTime"] = start_time
        if end_time is not None:
            params["endTime"] = end_time
        if model_id is not None:
            params["modelId"] = model_id
        raw = self._http.request(
            "GET",
            "/xt-console/api/payment/billing/queryAllAmount",
            params=params,
        )
        data = raw.get("data")
        parsed_data = (
            ModelUsageBillingAmountResponse(**data) if data is not None else None
        )
        return BaseResponse[ModelUsageBillingAmountResponse](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )


class AsyncPaymentResource:
    """Asynchronous Payment operations."""

    def __init__(self, http: AsyncHTTPClient) -> None:
        self._http = http

    async def records(
        self,
        *,
        page_num: Optional[int] = 1,
        page_size: Optional[int] = 10,
        status_list: Optional[List[str]] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        transaction_type: Optional[str] = None,
    ) -> BaseResponse[PageResponse]:
        """Query recharge records with pagination (async)."""
        req = RechargeRecordsRequest(
            pageNum=page_num,
            pageSize=page_size,
            statusList=status_list,
            startTime=start_time,
            endTime=end_time,
            transactionType=transaction_type,
        )
        raw = await self._http.request(
            "POST",
            "/xt-console/api/payment/records",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        if data is not None:
            items = data.get("list", [])
            parsed_items = [RechargeTransactionResponse(**item) for item in items]
            parsed_data = PageResponse(
                pageNum=data.get("pageNum", 1),
                pageSize=data.get("pageSize", page_size),
                total=data.get("total", 0),
                pages=data.get("pages", 0),
                hasNext=data.get("hasNext"),
                hasPrevious=data.get("hasPrevious"),
                list=parsed_items,
            )
        else:
            parsed_data = None
        return BaseResponse[PageResponse](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def statistics(self) -> BaseResponse[RechargeStatisticsResponse]:
        """Query recharge statistics summary (async)."""
        raw = await self._http.request(
            "GET",
            "/xt-console/api/payment/statistics",
        )
        data = raw.get("data")
        parsed_data = RechargeStatisticsResponse(**data) if data is not None else None
        return BaseResponse[RechargeStatisticsResponse](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def list(
        self,
        *,
        status_list: Optional[List[str]] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        transaction_type: Optional[str] = None,
    ) -> BaseResponse[List[RechargeTransactionResponse]]:
        """Query recharge transaction list (non-paginated, async)."""
        req = RechargeListRequest(
            statusList=status_list,
            startTime=start_time,
            endTime=end_time,
            transactionType=transaction_type,
        )
        raw = await self._http.request(
            "POST",
            "/xt-console/api/payment/list",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = (
            [RechargeTransactionResponse(**item) for item in data]
            if data is not None
            else None
        )
        return BaseResponse[List[RechargeTransactionResponse]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def get_record(
        self,
        *,
        transaction_no: str,
    ) -> BaseResponse[RechargeTransactionResponse]:
        """Get a single recharge record by transaction number (async)."""
        raw = await self._http.request(
            "GET",
            f"/xt-console/api/payment/record/{transaction_no}",
        )
        data = raw.get("data")
        parsed_data = RechargeTransactionResponse(**data) if data is not None else None
        return BaseResponse[RechargeTransactionResponse](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def billing_list(
        self,
        *,
        page_num: Optional[int] = 1,
        page_size: Optional[int] = 10,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        model_id: Optional[str] = None,
    ) -> BaseResponse[PageInfo[LmModelUsageBillingResponse]]:
        """Query model usage billing list with pagination (async)."""
        params: dict[str, Any] = {
            "pageNum": page_num,
            "pageSize": page_size,
        }
        if start_time is not None:
            params["startTime"] = start_time
        if end_time is not None:
            params["endTime"] = end_time
        if model_id is not None:
            params["modelId"] = model_id
        raw = await self._http.request(
            "GET",
            "/xt-console/api/payment/billing/list",
            params=params,
        )
        data = raw.get("data")
        if data is not None:
            items = data.get("list", [])
            parsed_items = [LmModelUsageBillingResponse(**item) for item in items]
            parsed_data = PageInfo[LmModelUsageBillingResponse](
                total=data.get("total", 0),
                totalPages=data.get("totalPages", 0),
                currentPage=data.get("currentPage", 1),
                pageSize=data.get("pageSize", page_size),
                list=parsed_items,
            )
        else:
            parsed_data = None
        return BaseResponse[PageInfo[LmModelUsageBillingResponse]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def billing_query_all_amount(
        self,
        *,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        model_id: Optional[str] = None,
    ) -> BaseResponse[ModelUsageBillingAmountResponse]:
        """Query model usage billing total amount (async)."""
        params: dict[str, Any] = {}
        if start_time is not None:
            params["startTime"] = start_time
        if end_time is not None:
            params["endTime"] = end_time
        if model_id is not None:
            params["modelId"] = model_id
        raw = await self._http.request(
            "GET",
            "/xt-console/api/payment/billing/queryAllAmount",
            params=params,
        )
        data = raw.get("data")
        parsed_data = (
            ModelUsageBillingAmountResponse(**data) if data is not None else None
        )
        return BaseResponse[ModelUsageBillingAmountResponse](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )
