"""Authentication resource -- tenant info.

The SDK uses API Key -> Token two-step authentication handled automatically
by the HTTP client layer. This module exposes only the tenant info endpoint.
Login/logout methods have been removed as authentication is now fully managed
internally via ``loginByApiKey`` token exchange.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..models.auth import PartnerResponse
from ..models.common import BaseResponse

if TYPE_CHECKING:
    from .._http import AsyncHTTPClient, SyncHTTPClient


class AuthResource:
    """Synchronous authentication operations."""

    def __init__(self, http: SyncHTTPClient) -> None:
        self._http = http

    def tenant_info(self) -> BaseResponse[PartnerResponse]:
        """Get the current user's tenant information.

        Returns:
            BaseResponse with data containing tenant details, or data=None
            if the user does not belong to a tenant.

        Raises:
            AuthenticationError: If the token is invalid or expired (code 3001).
        """
        raw = self._http.request("GET", "/xt-console/api/partner/tenantInfo")
        data = raw.get("data")
        parsed_data = PartnerResponse(**data) if data is not None else None
        return BaseResponse[PartnerResponse](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )


class AsyncAuthResource:
    """Asynchronous authentication operations."""

    def __init__(self, http: AsyncHTTPClient) -> None:
        self._http = http

    async def tenant_info(self) -> BaseResponse[PartnerResponse]:
        """Get the current user's tenant information (async).

        Returns:
            BaseResponse with data containing tenant details.

        Raises:
            AuthenticationError: If the token is invalid or expired (code 3001).
        """
        raw = await self._http.request("GET", "/xt-console/api/partner/tenantInfo")
        data = raw.get("data")
        parsed_data = PartnerResponse(**data) if data is not None else None
        return BaseResponse[PartnerResponse](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )
