"""User information resource."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..models.common import BaseResponse
from ..models.user import LoginUser

if TYPE_CHECKING:
    from .._http import AsyncHTTPClient, SyncHTTPClient


class UserResource:
    """Synchronous User operations."""

    def __init__(self, http: SyncHTTPClient) -> None:
        self._http = http

    def get_info(self) -> BaseResponse[LoginUser]:
        """Get the current logged-in user's information.

        Returns:
            BaseResponse containing the LoginUser with user details,
            permissions, tenant info, and account source channel.

        Raises:
            AuthenticationError: If the token is invalid or expired (code 3001).
        """
        raw = self._http.request("GET", "/xt-console/api/user/info")
        data = raw.get("data")
        parsed_data = LoginUser(**data) if data is not None else None
        return BaseResponse[LoginUser](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )


class AsyncUserResource:
    """Asynchronous User operations."""

    def __init__(self, http: AsyncHTTPClient) -> None:
        self._http = http

    async def get_info(self) -> BaseResponse[LoginUser]:
        """Get the current logged-in user's information (async).

        Returns:
            BaseResponse containing the LoginUser.
        """
        raw = await self._http.request("GET", "/xt-console/api/user/info")
        data = raw.get("data")
        parsed_data = LoginUser(**data) if data is not None else None
        return BaseResponse[LoginUser](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )
