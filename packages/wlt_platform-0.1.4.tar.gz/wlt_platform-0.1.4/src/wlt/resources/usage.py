"""Usage resource -- serverless, history, gateway providers."""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any, Optional

from ..models.common import BaseResponse, PageInfo, ProviderVO
from ..models.usage import (
    HistoryRecord,
    ServerLessSummaryResult,
    ServerlessChartsResult,
    ServerlessStatsResult,
    ServerlessUsageInfo,
    ServerlessUsageRecord,
    UsageHistoryRequest,
    UsageServerlessPageRequest,
    UsageServerlessRequest,
)

if TYPE_CHECKING:
    from .._http import AsyncHTTPClient, SyncHTTPClient


def _exclude_none(d: dict[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in d.items() if v is not None}


class UsageResource:
    """Synchronous Usage operations."""

    def __init__(self, http: SyncHTTPClient) -> None:
        self._http = http

    # ---- Serverless ----

    def serverless_summary(
        self,
        *,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        page_num: Optional[int] = 1,
        page_size: Optional[int] = 10,
    ) -> BaseResponse[ServerLessSummaryResult]:
        """Query serverless usage summary statistics.

        Args:
            start_time: Query start time.
            end_time: Query end time.
            page_num: Page number (default 1).
            page_size: Items per page (default 10).

        Returns:
            BaseResponse containing ServerLessSummaryResult.
        """
        req = UsageServerlessRequest(
            startTime=start_time,
            endTime=end_time,
            pageNum=page_num,
            pageSize=page_size,
        )
        raw = self._http.request(
            "POST",
            "/xt-console/api/usage/serverless/summary",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = ServerLessSummaryResult(**data) if data is not None else None
        return BaseResponse[ServerLessSummaryResult](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def serverless_usage(
        self,
        *,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        page_num: Optional[int] = 1,
        page_size: Optional[int] = 10,
    ) -> BaseResponse[PageInfo[ServerlessUsageInfo]]:
        """Query serverless usage list (old API).

        Args:
            start_time: Query start time.
            end_time: Query end time.
            page_num: Page number (default 1).
            page_size: Items per page (default 10).

        Returns:
            BaseResponse containing paginated ServerlessUsageInfo.
        """
        req = UsageServerlessRequest(
            startTime=start_time,
            endTime=end_time,
            pageNum=page_num,
            pageSize=page_size,
        )
        raw = self._http.request(
            "POST",
            "/xt-console/api/usage/serverless",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = PageInfo[ServerlessUsageInfo](**data) if data is not None else None
        return BaseResponse[PageInfo[ServerlessUsageInfo]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def serverless_list(
        self,
        *,
        start_time: datetime,
        end_time: datetime,
        page_num: Optional[int] = 1,
        page_size: Optional[int] = 10,
        api_key: Optional[str] = None,
        inputs: Optional[list[str]] = None,
        outputs: Optional[list[str]] = None,
        model_ids: Optional[list[str]] = None,
    ) -> BaseResponse[PageInfo[ServerlessUsageRecord]]:
        """Query serverless usage list (new API) with filters.

        Args:
            start_time: Query start time (required).
            end_time: Query end time (required).
            page_num: Page number (default 1).
            page_size: Items per page (default 10).
            api_key: Filter by API key.
            inputs: Filter by input types.
            outputs: Filter by output types.
            model_ids: Filter by model IDs.

        Returns:
            BaseResponse containing paginated ServerlessUsageRecord.
        """
        req = UsageServerlessPageRequest(
            startTime=start_time,
            endTime=end_time,
            pageNum=page_num,
            pageSize=page_size,
            apiKey=api_key,
            inputs=inputs,
            outputs=outputs,
            modelIds=model_ids,
        )
        raw = self._http.request(
            "POST",
            "/xt-console/api/usage/serverless/list",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = PageInfo[ServerlessUsageRecord](**data) if data is not None else None
        return BaseResponse[PageInfo[ServerlessUsageRecord]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def serverless_charts(
        self,
        *,
        start_time: datetime,
        end_time: datetime,
        page_num: Optional[int] = 1,
        page_size: Optional[int] = 10,
        api_key: Optional[str] = None,
        inputs: Optional[list[str]] = None,
        outputs: Optional[list[str]] = None,
        model_ids: Optional[list[str]] = None,
    ) -> BaseResponse[ServerlessChartsResult]:
        """Get serverless usage chart data (time-series trends).

        Args:
            start_time: Query start time (required).
            end_time: Query end time (required).
            page_num: Page number (default 1).
            page_size: Items per page (default 10).
            api_key: Filter by API key.
            inputs: Filter by input types.
            outputs: Filter by output types.
            model_ids: Filter by model IDs.

        Returns:
            BaseResponse containing ServerlessChartsResult.
        """
        req = UsageServerlessPageRequest(
            startTime=start_time,
            endTime=end_time,
            pageNum=page_num,
            pageSize=page_size,
            apiKey=api_key,
            inputs=inputs,
            outputs=outputs,
            modelIds=model_ids,
        )
        raw = self._http.request(
            "POST",
            "/xt-console/api/usage/serverless/charts",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = ServerlessChartsResult(**data) if data is not None else None
        return BaseResponse[ServerlessChartsResult](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    def serverless_stats(
        self,
        *,
        start_time: datetime,
        end_time: datetime,
        page_num: Optional[int] = 1,
        page_size: Optional[int] = 10,
        api_key: Optional[str] = None,
        inputs: Optional[list[str]] = None,
        outputs: Optional[list[str]] = None,
        model_ids: Optional[list[str]] = None,
    ) -> BaseResponse[ServerlessStatsResult]:
        """Get serverless usage aggregated statistics.

        Args:
            start_time: Query start time (required).
            end_time: Query end time (required).
            page_num: Page number (default 1).
            page_size: Items per page (default 10).
            api_key: Filter by API key.
            inputs: Filter by input types.
            outputs: Filter by output types.
            model_ids: Filter by model IDs.

        Returns:
            BaseResponse containing ServerlessStatsResult.
        """
        req = UsageServerlessPageRequest(
            startTime=start_time,
            endTime=end_time,
            pageNum=page_num,
            pageSize=page_size,
            apiKey=api_key,
            inputs=inputs,
            outputs=outputs,
            modelIds=model_ids,
        )
        raw = self._http.request(
            "POST",
            "/xt-console/api/usage/serverless/stats",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = ServerlessStatsResult(**data) if data is not None else None
        return BaseResponse[ServerlessStatsResult](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    # ---- History ----

    def history(
        self,
        *,
        provider: Optional[str] = None,
        feature: Optional[str] = None,
        request_type: Optional[str] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        keyword: Optional[str] = None,
        page_num: Optional[int] = None,
        page_size: Optional[int] = None,
        model_ids: Optional[list[str]] = None,
        inputs: Optional[list[str]] = None,
        outputs: Optional[list[str]] = None,
    ) -> BaseResponse[PageInfo[HistoryRecord]]:
        """Query API call history with multi-dimension filters.

        Args:
            provider: Filter by provider.
            feature: Filter by feature module.
            request_type: Filter by request type.
            start_time: Query start time.
            end_time: Query end time.
            keyword: Keyword search.
            page_num: Page number.
            page_size: Items per page.
            model_ids: Filter by model IDs.
            inputs: Filter by input types.
            outputs: Filter by output types.

        Returns:
            BaseResponse containing paginated HistoryRecord.
        """
        req = UsageHistoryRequest(
            provider=provider,
            feature=feature,
            requestType=request_type,
            startTime=start_time,
            endTime=end_time,
            keyword=keyword,
            pageNum=page_num,
            pageSize=page_size,
            modelIds=model_ids,
            inputs=inputs,
            outputs=outputs,
        )
        raw = self._http.request(
            "POST",
            "/xt-console/api/usage/history",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = PageInfo[HistoryRecord](**data) if data is not None else None
        return BaseResponse[PageInfo[HistoryRecord]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    # ---- Gateway Providers ----

    def gateway_providers(self) -> BaseResponse[list[ProviderVO]]:
        """Get gateway provider list for usage filtering.

        Returns:
            BaseResponse containing a list of ProviderVO.
        """
        raw = self._http.request("GET", "/xt-console/api/usage/gateway-providers")
        data = raw.get("data")
        parsed_data = (
            [ProviderVO(**item) for item in data] if data is not None else None
        )
        return BaseResponse[list[ProviderVO]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )


class AsyncUsageResource:
    """Asynchronous Usage operations."""

    def __init__(self, http: AsyncHTTPClient) -> None:
        self._http = http

    # ---- Serverless ----

    async def serverless_summary(
        self,
        *,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        page_num: Optional[int] = 1,
        page_size: Optional[int] = 10,
    ) -> BaseResponse[ServerLessSummaryResult]:
        """Query serverless usage summary statistics (async)."""
        req = UsageServerlessRequest(
            startTime=start_time,
            endTime=end_time,
            pageNum=page_num,
            pageSize=page_size,
        )
        raw = await self._http.request(
            "POST",
            "/xt-console/api/usage/serverless/summary",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = ServerLessSummaryResult(**data) if data is not None else None
        return BaseResponse[ServerLessSummaryResult](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def serverless_usage(
        self,
        *,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        page_num: Optional[int] = 1,
        page_size: Optional[int] = 10,
    ) -> BaseResponse[PageInfo[ServerlessUsageInfo]]:
        """Query serverless usage list (old API, async)."""
        req = UsageServerlessRequest(
            startTime=start_time,
            endTime=end_time,
            pageNum=page_num,
            pageSize=page_size,
        )
        raw = await self._http.request(
            "POST",
            "/xt-console/api/usage/serverless",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = PageInfo[ServerlessUsageInfo](**data) if data is not None else None
        return BaseResponse[PageInfo[ServerlessUsageInfo]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def serverless_list(
        self,
        *,
        start_time: datetime,
        end_time: datetime,
        page_num: Optional[int] = 1,
        page_size: Optional[int] = 10,
        api_key: Optional[str] = None,
        inputs: Optional[list[str]] = None,
        outputs: Optional[list[str]] = None,
        model_ids: Optional[list[str]] = None,
    ) -> BaseResponse[PageInfo[ServerlessUsageRecord]]:
        """Query serverless usage list (new API, async)."""
        req = UsageServerlessPageRequest(
            startTime=start_time,
            endTime=end_time,
            pageNum=page_num,
            pageSize=page_size,
            apiKey=api_key,
            inputs=inputs,
            outputs=outputs,
            modelIds=model_ids,
        )
        raw = await self._http.request(
            "POST",
            "/xt-console/api/usage/serverless/list",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = PageInfo[ServerlessUsageRecord](**data) if data is not None else None
        return BaseResponse[PageInfo[ServerlessUsageRecord]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def serverless_charts(
        self,
        *,
        start_time: datetime,
        end_time: datetime,
        page_num: Optional[int] = 1,
        page_size: Optional[int] = 10,
        api_key: Optional[str] = None,
        inputs: Optional[list[str]] = None,
        outputs: Optional[list[str]] = None,
        model_ids: Optional[list[str]] = None,
    ) -> BaseResponse[ServerlessChartsResult]:
        """Get serverless usage chart data (async)."""
        req = UsageServerlessPageRequest(
            startTime=start_time,
            endTime=end_time,
            pageNum=page_num,
            pageSize=page_size,
            apiKey=api_key,
            inputs=inputs,
            outputs=outputs,
            modelIds=model_ids,
        )
        raw = await self._http.request(
            "POST",
            "/xt-console/api/usage/serverless/charts",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = ServerlessChartsResult(**data) if data is not None else None
        return BaseResponse[ServerlessChartsResult](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    async def serverless_stats(
        self,
        *,
        start_time: datetime,
        end_time: datetime,
        page_num: Optional[int] = 1,
        page_size: Optional[int] = 10,
        api_key: Optional[str] = None,
        inputs: Optional[list[str]] = None,
        outputs: Optional[list[str]] = None,
        model_ids: Optional[list[str]] = None,
    ) -> BaseResponse[ServerlessStatsResult]:
        """Get serverless usage aggregated statistics (async)."""
        req = UsageServerlessPageRequest(
            startTime=start_time,
            endTime=end_time,
            pageNum=page_num,
            pageSize=page_size,
            apiKey=api_key,
            inputs=inputs,
            outputs=outputs,
            modelIds=model_ids,
        )
        raw = await self._http.request(
            "POST",
            "/xt-console/api/usage/serverless/stats",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = ServerlessStatsResult(**data) if data is not None else None
        return BaseResponse[ServerlessStatsResult](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    # ---- History ----

    async def history(
        self,
        *,
        provider: Optional[str] = None,
        feature: Optional[str] = None,
        request_type: Optional[str] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        keyword: Optional[str] = None,
        page_num: Optional[int] = None,
        page_size: Optional[int] = None,
        model_ids: Optional[list[str]] = None,
        inputs: Optional[list[str]] = None,
        outputs: Optional[list[str]] = None,
    ) -> BaseResponse[PageInfo[HistoryRecord]]:
        """Query API call history (async)."""
        req = UsageHistoryRequest(
            provider=provider,
            feature=feature,
            requestType=request_type,
            startTime=start_time,
            endTime=end_time,
            keyword=keyword,
            pageNum=page_num,
            pageSize=page_size,
            modelIds=model_ids,
            inputs=inputs,
            outputs=outputs,
        )
        raw = await self._http.request(
            "POST",
            "/xt-console/api/usage/history",
            json=_exclude_none(req.model_dump(mode="json")),
        )
        data = raw.get("data")
        parsed_data = PageInfo[HistoryRecord](**data) if data is not None else None
        return BaseResponse[PageInfo[HistoryRecord]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )

    # ---- Gateway Providers ----

    async def gateway_providers(self) -> BaseResponse[list[ProviderVO]]:
        """Get gateway provider list for usage filtering (async)."""
        raw = await self._http.request("GET", "/xt-console/api/usage/gateway-providers")
        data = raw.get("data")
        parsed_data = (
            [ProviderVO(**item) for item in data] if data is not None else None
        )
        return BaseResponse[list[ProviderVO]](
            code=raw.get("code", 200),
            message=raw.get("message", "OK"),
            data=parsed_data,
        )
