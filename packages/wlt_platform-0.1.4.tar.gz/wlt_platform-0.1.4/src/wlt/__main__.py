"""Allow running as ``python -m wlt`` or ``python -m wlt.cli``."""
from wlt.cli import main

main()
