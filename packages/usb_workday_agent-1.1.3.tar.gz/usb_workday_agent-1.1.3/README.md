# USB Workday Agent

MCP integration for Workday automation using the wxO-nit virtual environment.

## Overview

This project provides an MCP (Model Context Protocol) server for automating Workday operations. It leverages the FastMCP framework to expose tools and resources for Workday integration.

## Prerequisites

- Python 3.10 or higher
- wxO-nit virtual environment (located at `../wxO-nit`)
- MCP-compatible client (e.g., Claude Desktop, Bob)

## Installation

### Using the wxO-nit Virtual Environment

This project uses the existing wxO-nit virtual environment:

```bash
# Activate the wxO-nit virtual environment
source ../wxO-nit/bin/activate

# Install this package in development mode
pip install -e .
```

### Standalone Installation

Alternatively, create a new virtual environment:

```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -e .
```

## Development

### Install Development Dependencies

```bash
pip install -e ".[dev]"
```

### Code Formatting

```bash
# Format code with black
black .

# Lint with ruff
ruff check .
```

### Testing

```bash
pytest
```

## Project Structure

```
usb-workday-agent/
├── README.md
├── pyproject.toml
├── setup.py
└── (source files to be added)
```

## Dependencies

- **mcp** (>=0.9.0): Model Context Protocol core library
- **fastmcp** (>=3.0.0): FastMCP framework for building MCP servers

## Running the MCP Server

### Start the Server

```bash
# Activate the wxO-nit virtual environment
source ../wxO-nit/bin/activate

# Run the server directly
python3 server.py

# Or use the installed command (after pip install -e .)
usb-workday-agent
```

### MCP Client Configuration

Add to your MCP client configuration (e.g., Claude Desktop):

```json
{
  "mcpServers": {
    "usb-workday-agent": {
      "command": "python",
      "args": ["/Users/amandawinkles/bob/usb-workday-agent/server.py"],
      "env": {
        "PYTHONPATH": "/Users/amandawinkles/bob/wxO-nit/lib/python3.10/site-packages"
      }
    }
  }
}
```

## Available Tools

The server provides the following tools for watsonx Orchestrate:

- **get_workday_status**: Check Workday integration status
- **query_workday_data**: Query data from Workday API endpoints
- **create_workday_record**: Create new records in Workday
- **update_workday_record**: Update existing Workday records
- **search_workday_records**: Search for records with criteria
- **execute_workday_report**: Run Workday reports and retrieve results

## Available Resources

- **workday://config**: Get Workday configuration details
- **workday://status**: Check connection status to Workday

## Configuration

Workday API credentials and configuration should be set via environment variables:

```bash
export WORKDAY_TENANT="your-tenant"
export WORKDAY_USERNAME="your-username"
export WORKDAY_PASSWORD="your-password"
export WORKDAY_API_VERSION="v1"
```

## License

MIT License

## Author

Amanda Winkles