"""USB Workday Agent - MCP integration for Workday automation."""

__version__ = "1.0.0"

from usb_workday_agent.server import main

__all__ = ["main", "__version__"]

# Made with Bob
