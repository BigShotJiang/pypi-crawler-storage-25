from typing import Union
from copy import copy


class Node:
    def __init__(self, node_id: str):
        self._parent: Node | None = None
        self._id = node_id

    @property
    def parent(self) -> Union['Node', None]:
        return self._parent

    @parent.setter
    def parent(self, parent: Union['Node', None]) -> None:
        self._parent = parent

    @property
    def id(self) -> str:
        return self._id



class ContainerNode(Node):
    def __init__(self, node_id: str):
        super().__init__(node_id=node_id)
        self._subnodes: dict[str, Node] = {}

    @property
    def subnodes(self) -> dict[str, Node]:
        return copy(self._subnodes)
