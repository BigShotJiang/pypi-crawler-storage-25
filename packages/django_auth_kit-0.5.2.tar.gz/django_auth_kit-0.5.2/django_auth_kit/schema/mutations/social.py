from __future__ import annotations

import strawberry
from asgiref.sync import sync_to_async
from strawberry.types import Info

from django_auth_kit.ratelimit import check_rate_limit
from django_auth_kit.schema.inputs import SocialLoginInput
from django_auth_kit.schema.types import AuthResponse
from django_auth_kit.schema.utils import get_request


@strawberry.type
class OAuthRedirectURL:
    url: str
    provider: str


@strawberry.type(name="Query")
class SocialQuery:
    @strawberry.field
    def social_login_url(
        self,
        info: Info,
        provider: str,
        next_url: str | None = None,
    ) -> OAuthRedirectURL:
        """
        Return the URL to initiate OAuth login for a redirect-based provider.

        The frontend should redirect the user to this URL. After the user
        authenticates with the provider, they will be redirected back with
        JWT tokens as query parameters.

        Args:
            provider: The allauth provider id (e.g. "microsoft").
            next_url: Optional frontend URL to redirect to after login.
        """
        from django.urls import reverse

        request = get_request(info)
        path = reverse("django_auth_kit:oauth_login", args=[provider])
        if next_url:
            path = f"{path}?next={next_url}"
        url = request.build_absolute_uri(path)
        return OAuthRedirectURL(url=url, provider=provider)


@strawberry.type(name="Mutation")
class SocialMutation:
    @strawberry.mutation
    async def social_login(self, info: Info, input: SocialLoginInput) -> AuthResponse:
        """
        Authenticate via a social provider using a token obtained client-side.

        Requires django-allauth to be installed with the desired provider
        configured. The provider must also be listed in
        AUTH_KIT["SOCIAL_PROVIDERS"].

        Pass ``access_token`` or ``id_token`` depending on the provider:
        - Google, Apple, OpenID Connect: ``id_token``
        - Facebook: ``access_token``

        For redirect-based providers (e.g. Microsoft), use the
        ``socialLoginUrl`` query to get the redirect URL instead.

        All user creation, account linking, and email matching is handled
        by django-allauth's adapter infrastructure.
        """
        allowed, retry_after = check_rate_limit(get_request(info), "social_login")
        if not allowed:
            return AuthResponse(
                success=False,
                message=f"Rate limit exceeded. Try again in {retry_after}s.",
            )
        try:
            return await sync_to_async(_do_social_login)(info, input)
        except ImportError:
            return AuthResponse(
                success=False,
                message="Social login is not available. Install django-allauth.",
            )
        except Exception as e:
            return AuthResponse(success=False, message=str(e))


def _do_social_login(info: Info, input: SocialLoginInput) -> AuthResponse:
    from django_auth_kit.jwt.service import JWTService
    from django_auth_kit.schema.queries import _user_to_type
    from django_auth_kit.schema.types import AuthTokens
    from django_auth_kit.social.service import SocialLoginService

    request = get_request(info)

    # Build the token dict that allauth providers expect
    token = {}
    if input.access_token:
        token["access_token"] = input.access_token
    if input.id_token:
        token["id_token"] = input.id_token
    if input.client_id:
        token["client_id"] = input.client_id

    if not token.get("access_token") and not token.get("id_token"):
        return AuthResponse(
            success=False,
            message="Either access_token or id_token is required.",
        )

    user = SocialLoginService.complete_login(request, input.provider, token)

    tokens = JWTService.create_token_pair(user)
    return AuthResponse(
        success=True,
        message="Social login successful.",
        tokens=AuthTokens(**tokens),
        user=_user_to_type(user),
    )
