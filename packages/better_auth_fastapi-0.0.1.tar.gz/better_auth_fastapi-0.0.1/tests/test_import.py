import better_auth.fastapi


def test_import():
    assert better_auth.fastapi.__name__ == "better_auth.fastapi"
