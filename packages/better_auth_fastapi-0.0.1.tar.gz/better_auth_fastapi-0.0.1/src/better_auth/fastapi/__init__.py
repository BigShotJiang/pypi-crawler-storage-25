"""FastAPI integration namespace."""
