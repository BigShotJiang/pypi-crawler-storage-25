# better-auth-fastapi

FastAPI integration package scaffold for `better-auth-py`.

This package reserves the public distribution and import namespace. Runtime
integration will be added when the FastAPI adapter API is implemented.
