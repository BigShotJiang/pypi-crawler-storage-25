(design)=

```{include} ../DESIGN.md
```
