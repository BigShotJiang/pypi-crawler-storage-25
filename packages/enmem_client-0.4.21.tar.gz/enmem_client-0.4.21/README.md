# enmem-client

Python client for **enn-memory** - Long-term memory system for AI agents.

## Installation

```bash
pip install enmem-client
```

## Quick Start

```python
from enmem_client import Enmem

# Initialize client
client = Enmem(base_url="http://localhost:8888")

# Store a memory
client.retain(
    bank_id="my-bank",
    content="User prefers Python programming"
)

# Search memories
results = client.recall(
    bank_id="my-bank",
    query="What does the user like?"
)
for r in results.results:
    print(r.text)

# Generate contextual answer
answer = client.reflect(
    bank_id="my-bank",
    query="What are the user's interests?"
)
print(answer.text)
```

## Documentation

Full documentation: https://github.com/enn-memory/ennmem-docs

## Features

- **Retain**: Store memories with automatic fact extraction
- **Recall**: Search memories using semantic similarity
- **Reflect**: Generate contextual responses using memories and mental models
- **Mental Models**: Create living documents that auto-refresh
- **Directives**: Set hard rules for reflect operations
- **Bank Management**: Create and configure memory banks

## License

MIT
