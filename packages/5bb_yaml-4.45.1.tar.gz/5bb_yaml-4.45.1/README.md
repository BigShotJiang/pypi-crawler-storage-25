# 5bb-yaml

> **yq** – a portable command-line YAML, JSON, XML, CSV, TOML and properties processor (like jq, but for YAML), distributed via PyPI/uv.

This package downloads and installs the [`yq`](https://github.com/mikefarah/yq) binary for your platform on first use. No compilation required.

## Installation

```bash
uv tool install 5bb-yaml
# or
pip install 5bb-yaml
```

## Usage

```bash
yq '.name' config.yml
yq -i '.version = "1.0.0"' pyproject.yml
```

The binary is downloaded from the official GitHub releases on first run and cached in `~/.cache/5bb-yaml/`.

## Configuration

Set `BB_CACHE_DIR` to override the cache location:

```bash
BB_CACHE_DIR=/opt/tools yq '.name' config.yml
```

## License

MIT – see the [LICENSE](../../LICENSE) file for details.
