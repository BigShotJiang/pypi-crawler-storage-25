import pytest
from spark_sizer.analyzer import PySparkAnalyzer
from spark_sizer.models import OperationType


@pytest.fixture
def analyzer():
    return PySparkAnalyzer()


SIMPLE_JOIN = """
df1.join(df2, "id", "inner")
df1.groupBy("col").agg({"val": "sum"})
df1.cache()
"""

BROADCAST_SCRIPT = """
from pyspark.sql.functions import broadcast
result = df1.join(broadcast(df2), "id")
"""

HEAVY_SHUFFLE = """
df.sort("col")
df.distinct()
df.repartition(200)
df.groupBy("a", "b").count()
df.union(df2)
df.join(df3, "id")
"""


def test_detects_join(analyzer):
    analysis = analyzer.analyze_source(SIMPLE_JOIN)
    assert analysis.join_count == 1


def test_detects_groupby(analyzer):
    analysis = analyzer.analyze_source(SIMPLE_JOIN)
    types = analysis.operation_types()
    assert OperationType.GROUP_BY in types


def test_detects_cache(analyzer):
    analysis = analyzer.analyze_source(SIMPLE_JOIN)
    assert analysis.cache_count == 1


def test_detects_broadcast(analyzer):
    analysis = analyzer.analyze_source(BROADCAST_SCRIPT)
    assert analysis.has_broadcast is True


def test_shuffle_count(analyzer):
    analysis = analyzer.analyze_source(HEAVY_SHUFFLE)
    assert analysis.shuffle_count >= 5


def test_no_false_positives_on_empty(analyzer):
    analysis = analyzer.analyze_source("")
    assert analysis.join_count == 0
    assert analysis.shuffle_count == 0
    assert analysis.cache_count == 0
