import pytest
from spark_sizer.estimator import SparkSizer
from spark_sizer.models import ClusterProfile, DataSource

SCRIPT_WITH_JOINS = """
events.join(users, "user_id").groupBy("date").count().cache()
"""

SCRIPT_NO_SHUFFLE = """
df = spark.read.parquet("s3://bucket/data/")
df.write.parquet("s3://out/")
"""


@pytest.fixture
def cluster():
    return ClusterProfile(num_nodes=10, cores_per_node=16, memory_gb_per_node=64.0)


@pytest.fixture
def sources():
    return [
        DataSource(name="events", size_gb=500.0),
        DataSource(name="users", size_gb=2.0),
    ]


@pytest.fixture
def sizer():
    return SparkSizer()


def test_basic_report(sizer, sources, cluster):
    report = sizer.size_from_source(SCRIPT_WITH_JOINS, sources, cluster)
    assert report.recommended_config is not None
    assert report.recommended_config.executor_instances > 0
    assert report.recommended_config.executor_memory_gb >= 4


def test_config_keys_present(sizer, sources, cluster):
    report = sizer.size_from_source(SCRIPT_WITH_JOINS, sources, cluster)
    conf = report.recommended_config.to_spark_conf()
    required_keys = {
        "spark.executor.instances",
        "spark.executor.cores",
        "spark.executor.memory",
        "spark.driver.memory",
        "spark.sql.shuffle.partitions",
        "spark.default.parallelism",
    }
    assert required_keys.issubset(conf.keys())


def test_pyspark_code_output(sizer, sources, cluster):
    report = sizer.size_from_source(SCRIPT_WITH_JOINS, sources, cluster)
    code = report.recommended_config.to_pyspark_code()
    assert "SparkSession" in code
    assert "spark.executor.memory" in code


def test_caching_increases_storage_fraction(sizer, cluster):
    cached_sources = [DataSource(name="data", size_gb=10.0, is_cached=True)]
    script = "df.cache()\ndf.groupBy('a').count()"
    report = sizer.size_from_source(script, cached_sources, cluster)
    assert report.recommended_config.memory_storage_fraction >= 0.5


def test_small_table_broadcast_warning(sizer, cluster):
    sources = [
        DataSource(name="big", size_gb=100.0),
        DataSource(name="small", size_gb=0.5),
    ]
    report = sizer.size_from_source("big.join(small, 'id')", sources, cluster)
    assert any("broadcast" in w.lower() for w in report.warnings)


def test_no_shuffle_ops(sizer, cluster):
    sources = [DataSource(name="input", size_gb=10.0)]
    report = sizer.size_from_source(SCRIPT_NO_SHUFFLE, sources, cluster)
    assert report.script_analysis.shuffle_count == 0
