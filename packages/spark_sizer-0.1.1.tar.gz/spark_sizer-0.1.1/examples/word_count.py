from pyspark.sql import SparkSession
from pyspark.sql.functions import explode, split, col

# Create Spark session
spark = SparkSession.builder \
    .appName("WordCountDataFrame") \
    .getOrCreate()

# Read text file (each line becomes a row)
df = spark.read.text("input.txt")

# Split lines into words, explode into rows, and count
word_counts = (
    df.select(explode(split(col("value"), "\\s+")).alias("word"))
      .groupBy("word")
      .count()
      .orderBy(col("count").desc())
)

# Show result
word_counts.show(truncate=False)

# Optional: write output
# word_counts.write.csv("output_path", header=True)

spark.stop()