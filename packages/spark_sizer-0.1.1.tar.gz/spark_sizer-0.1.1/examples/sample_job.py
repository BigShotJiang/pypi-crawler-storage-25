"""Example PySpark job — used as input to spark-sizer for demo purposes."""
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.window import Window

spark = SparkSession.builder.appName("SampleJob").getOrCreate()

events = spark.read.parquet("s3://bucket/events/")
users = spark.read.parquet("s3://bucket/users/")
products = spark.read.parquet("s3://bucket/products/")

# Broadcast the small products table
from pyspark.sql.functions import broadcast
enriched = events.join(broadcast(products), "product_id", "left")

# Large shuffle join
enriched = enriched.join(users, "user_id", "inner")

# Aggregation (shuffle)
daily_revenue = (
    enriched
    .groupBy("user_id", "date")
    .agg(F.sum("revenue").alias("total_revenue"), F.count("*").alias("event_count"))
)

# Window function (shuffle)
window_spec = Window.partitionBy("user_id").orderBy("date")
daily_revenue = daily_revenue.withColumn(
    "cumulative_revenue", F.sum("total_revenue").over(window_spec)
)

daily_revenue.cache()

# Second aggregation on cached data
top_users = (
    daily_revenue
    .groupBy("user_id")
    .agg(F.sum("total_revenue").alias("lifetime_revenue"))
    .orderBy(F.desc("lifetime_revenue"))
)

top_users.write.parquet("s3://bucket/output/top_users/")
