import math

from ..models import ClusterProfile, DataSource, ScriptAnalysis

_CORES_PER_EXECUTOR = 5  # optimal for HDFS throughput (3-5 threads per core)
_MEMORY_OVERHEAD_FRACTION = 0.1
_TARGET_DATA_GB_PER_EXECUTOR = 10.0  # ~2GB/core at 5 cores/executor


def recommend_executor_layout(
    cluster: ClusterProfile,
    sources: list[DataSource],
    analysis: ScriptAnalysis,
    executor_memory_gb: float,
) -> tuple[int, int, str]:
    """Returns (executor_instances, executor_cores, rationale)."""
    cores_per_executor = min(_CORES_PER_EXECUTOR, cluster.cores_per_node - 1)
    cores_per_executor = max(1, cores_per_executor)

    executors_per_node = (cluster.cores_per_node - 1) // cores_per_executor
    executors_per_node = max(1, executors_per_node)

    # Verify memory fits
    memory_with_overhead = executor_memory_gb * (1 + _MEMORY_OVERHEAD_FRACTION)
    max_executors_by_memory = int(
        cluster.memory_gb_per_node * 0.9 / memory_with_overhead
    )
    executors_per_node = min(executors_per_node, max(1, max_executors_by_memory))

    # Reserve one executor per node for the ApplicationMaster in YARN
    cluster_max = (cluster.num_nodes * executors_per_node) - 1

    # Cap based on data size — no point spinning up more executors than the data warrants.
    # Account for shuffle expansion (up to 3× for heavy shuffle jobs).
    total_data_gb = sum(s.size_gb for s in sources)
    shuffle_multiplier = min(3.0, 1.0 + analysis.shuffle_count * 0.3)
    effective_data_gb = total_data_gb * shuffle_multiplier
    data_driven_max = max(1, math.ceil(effective_data_gb / _TARGET_DATA_GB_PER_EXECUTOR))

    total_instances = min(cluster_max, data_driven_max)
    total_instances = max(1, total_instances)

    cap_reason = (
        f"data-driven cap ({effective_data_gb:.1f}GB effective / {_TARGET_DATA_GB_PER_EXECUTOR}GB per executor)"
        if data_driven_max < cluster_max
        else f"{executors_per_node} executors/node × {cluster.num_nodes} nodes, 1 reserved for AM"
    )
    rationale = f"{total_instances} instances ({cap_reason}), {cores_per_executor} cores each"
    return total_instances, cores_per_executor, rationale


def recommend_broadcast_threshold(
    sources: list[DataSource], analysis: ScriptAnalysis
) -> tuple[int, str]:
    """Returns (threshold_mb, rationale)."""
    if not analysis.join_count:
        return 10, "default (no joins detected)"

    # Find the smallest non-trivial table — good broadcast candidate
    sorted_sources = sorted(sources, key=lambda s: s.size_gb)
    if len(sorted_sources) >= 2:
        smallest_mb = sorted_sources[0].size_mb
        threshold = min(int(smallest_mb * 0.8), 200)
        threshold = max(10, threshold)
        return threshold, f"smallest source: {smallest_mb:.0f}MB"

    return 10, "default"
