from ..models import ClusterProfile, DataSource, ScriptAnalysis

_TARGET_PARTITION_SIZE_MB = 128


def recommend_shuffle_partitions(
    cluster: ClusterProfile,
    sources: list[DataSource],
    analysis: ScriptAnalysis,
    executor_cores: int,
) -> tuple[int, str]:
    """Returns (shuffle_partitions, rationale)."""
    total_mb = sum(s.size_mb for s in sources)

    # After shuffle, data may expand due to serialization overhead
    shuffle_data_mb = total_mb * 1.5 if analysis.shuffle_count > 0 else total_mb

    partitions_by_size = max(1, int(shuffle_data_mb / _TARGET_PARTITION_SIZE_MB))

    total_slots = cluster.num_nodes * (cluster.cores_per_node // 5) * executor_cores
    # Aim for 2-3x parallelism to keep all slots busy
    partitions_by_slots = total_slots * 3

    partitions = max(partitions_by_size, partitions_by_slots)

    # Round to a power of 2 for uniform distribution
    partitions = _round_to_nice(partitions)

    rationale = (
        f"Input data: {total_mb:.0f}MB, "
        f"target partition size: {_TARGET_PARTITION_SIZE_MB}MB, "
        f"total executor slots: {total_slots}"
    )
    return partitions, rationale


def recommend_default_parallelism(
    cluster: ClusterProfile, executor_cores: int
) -> int:
    executor_count = cluster.num_nodes * max(1, cluster.cores_per_node // 5)
    return executor_count * executor_cores * 2


def _round_to_nice(n: int) -> int:
    """Round to nearest multiple of 200 for human-readable partition counts."""
    if n <= 200:
        return max(50, (n // 50) * 50 or 50)
    return max(200, (n // 200) * 200)
