from ..models import ClusterProfile, DataSource, ScriptAnalysis


_OS_OVERHEAD_FRACTION = 0.1
_YARN_OVERHEAD_FRACTION = 0.1


def recommend_executor_memory(
    cluster: ClusterProfile,
    sources: list[DataSource],
    analysis: ScriptAnalysis,
) -> tuple[float, str]:
    """Returns (executor_memory_gb, rationale)."""
    usable_gb = cluster.memory_gb_per_node * (1 - _OS_OVERHEAD_FRACTION - _YARN_OVERHEAD_FRACTION)

    cached_gb = sum(s.size_gb for s in sources if s.is_cached)
    shuffle_gb = sum(s.size_gb for s in sources) * 0.3 * max(1, analysis.shuffle_count)

    # Each executor gets a share of the node memory
    executor_count_per_node = max(1, cluster.cores_per_node // 5)
    base_gb = usable_gb / executor_count_per_node

    if analysis.cache_count > 0:
        # Boost memory when caching is used
        cache_per_executor = cached_gb / (cluster.num_nodes * executor_count_per_node)
        base_gb = max(base_gb, cache_per_executor * 2.5)

    if analysis.shuffle_count > 3:
        base_gb *= 1.2

    # Clamp to sane range
    memory_gb = max(4.0, min(base_gb, 64.0))
    memory_gb = round(memory_gb / 2) * 2  # round to nearest even

    rationale = (
        f"Node usable memory: {usable_gb:.1f}g, "
        f"shuffle operations: {analysis.shuffle_count}, "
        f"cached datasets: {analysis.cache_count}"
    )
    return memory_gb, rationale


def recommend_driver_memory(
    cluster: ClusterProfile,
    sources: list[DataSource],
    analysis: ScriptAnalysis,
) -> tuple[float, str]:
    total_gb = sum(s.size_gb for s in sources)
    # Driver collects results; size to 10% of total data or 4g min
    driver_gb = max(4.0, min(total_gb * 0.1, 16.0))
    driver_gb = round(driver_gb / 2) * 2
    return driver_gb, f"Sized to 10% of total input ({total_gb:.1f}g)"
