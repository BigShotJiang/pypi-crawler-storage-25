import ast
import re
from pathlib import Path

from .models import DetectedOperation, OperationType, ScriptAnalysis

_SHUFFLE_OPS = {
    "join": OperationType.JOIN,
    "crossJoin": OperationType.CROSS_JOIN,
    "groupBy": OperationType.GROUP_BY,
    "groupby": OperationType.GROUP_BY,
    "sort": OperationType.SORT,
    "orderBy": OperationType.SORT,
    "distinct": OperationType.DISTINCT,
    "dropDuplicates": OperationType.DISTINCT,
    "repartition": OperationType.REPARTITION,
    "coalesce": OperationType.COALESCE,
    "union": OperationType.UNION,
    "unionAll": OperationType.UNION,
    "window": OperationType.WINDOW,
    "Window": OperationType.WINDOW,
    "cache": OperationType.CACHE,
    "persist": OperationType.PERSIST,
}

_BROADCAST_PATTERNS = [
    r"broadcast\s*\(",
    r"\.hint\s*\(\s*['\"]broadcast['\"]",
    r"broadcastHashJoin",
]


class PySparkAnalyzer:
    def analyze_file(self, path: str | Path) -> ScriptAnalysis:
        source = Path(path).read_text()
        return self.analyze_source(source)

    def analyze_source(self, source: str) -> ScriptAnalysis:
        analysis = ScriptAnalysis()
        try:
            tree = ast.parse(source)
            self._walk_ast(tree, analysis)
        except SyntaxError:
            pass

        analysis.has_broadcast = any(
            re.search(p, source) for p in _BROADCAST_PATTERNS
        )
        analysis.has_skew_hint = bool(
            re.search(r'\.hint\s*\(\s*[\'"]skew[\'"]', source)
        )

        analysis.shuffle_count = sum(
            1 for op in analysis.operations
            if op.op_type not in (OperationType.CACHE, OperationType.PERSIST,
                                  OperationType.COALESCE, OperationType.BROADCAST_JOIN)
        )
        analysis.cache_count = sum(
            1 for op in analysis.operations
            if op.op_type in (OperationType.CACHE, OperationType.PERSIST)
        )
        analysis.join_count = sum(
            1 for op in analysis.operations
            if op.op_type in (OperationType.JOIN, OperationType.CROSS_JOIN,
                              OperationType.BROADCAST_JOIN)
        )
        return analysis

    def _walk_ast(self, tree: ast.AST, analysis: ScriptAnalysis) -> None:
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                self._check_call(node, analysis)

    def _check_call(self, node: ast.Call, analysis: ScriptAnalysis) -> None:
        name = self._extract_call_name(node)
        if name and name in _SHUFFLE_OPS:
            op_type = _SHUFFLE_OPS[name]
            details = {}

            if op_type == OperationType.JOIN:
                details["join_type"] = self._extract_join_type(node)

            if op_type == OperationType.REPARTITION:
                details["num_partitions"] = self._extract_first_int_arg(node)

            analysis.operations.append(
                DetectedOperation(
                    op_type=op_type,
                    line_number=node.lineno if hasattr(node, "lineno") else 0,
                    details=details,
                )
            )

    def _extract_call_name(self, node: ast.Call) -> str | None:
        if isinstance(node.func, ast.Attribute):
            return node.func.attr
        if isinstance(node.func, ast.Name):
            return node.func.id
        return None

    def _extract_join_type(self, node: ast.Call) -> str:
        for kw in node.keywords:
            if kw.arg == "how" and isinstance(kw.value, ast.Constant):
                return kw.value.value
        for arg in node.args[1:]:
            if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                return arg.value
        return "inner"

    def _extract_first_int_arg(self, node: ast.Call) -> int | None:
        for arg in node.args:
            if isinstance(arg, ast.Constant) and isinstance(arg.value, int):
                return arg.value
        return None
