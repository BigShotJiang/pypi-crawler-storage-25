from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class OperationType(Enum):
    JOIN = "join"
    BROADCAST_JOIN = "broadcast_join"
    GROUP_BY = "groupBy"
    SORT = "sort"
    DISTINCT = "distinct"
    REPARTITION = "repartition"
    COALESCE = "coalesce"
    WINDOW = "window"
    CACHE = "cache"
    PERSIST = "persist"
    UNION = "union"
    CROSS_JOIN = "crossJoin"
    SKEW_JOIN = "skew_join"


@dataclass
class DataSource:
    name: str
    size_gb: float
    num_partitions: Optional[int] = None
    format: str = "parquet"
    is_cached: bool = False

    @property
    def size_mb(self) -> float:
        return self.size_gb * 1024


@dataclass
class DetectedOperation:
    op_type: OperationType
    line_number: int
    details: dict = field(default_factory=dict)


@dataclass
class ScriptAnalysis:
    operations: list[DetectedOperation] = field(default_factory=list)
    has_broadcast: bool = False
    has_skew_hint: bool = False
    shuffle_count: int = 0
    cache_count: int = 0
    join_count: int = 0
    max_join_size_gb: float = 0.0

    def operation_types(self) -> set[OperationType]:
        return {op.op_type for op in self.operations}


@dataclass
class ClusterProfile:
    """Hardware profile of the target cluster."""
    num_nodes: int
    cores_per_node: int
    memory_gb_per_node: float
    node_type: str = "generic"

    @property
    def total_cores(self) -> int:
        return self.num_nodes * self.cores_per_node

    @property
    def total_memory_gb(self) -> float:
        return self.num_nodes * self.memory_gb_per_node


@dataclass
class SparkConfig:
    """Recommended Spark configuration."""
    executor_instances: int
    executor_cores: int
    executor_memory_gb: float
    driver_memory_gb: float
    shuffle_partitions: int
    default_parallelism: int
    memory_fraction: float = 0.6
    memory_storage_fraction: float = 0.5
    broadcast_threshold_mb: int = 10
    adaptive_enabled: bool = True
    extra: dict = field(default_factory=dict)

    def to_spark_conf(self) -> dict[str, str]:
        conf = {
            "spark.executor.instances": str(self.executor_instances),
            "spark.executor.cores": str(self.executor_cores),
            "spark.executor.memory": f"{int(self.executor_memory_gb)}g",
            "spark.driver.memory": f"{int(self.driver_memory_gb)}g",
            "spark.sql.shuffle.partitions": str(self.shuffle_partitions),
            "spark.default.parallelism": str(self.default_parallelism),
            "spark.memory.fraction": str(self.memory_fraction),
            "spark.memory.storageFraction": str(self.memory_storage_fraction),
            "spark.sql.autoBroadcastJoinThreshold": f"{self.broadcast_threshold_mb}m",
            "spark.sql.adaptive.enabled": str(self.adaptive_enabled).lower(),
            "spark.sql.adaptive.coalescePartitions.enabled": str(self.adaptive_enabled).lower(),
            "spark.sql.adaptive.skewJoin.enabled": str(self.adaptive_enabled).lower(),
        }
        conf.update(self.extra)
        return conf

    def to_pyspark_code(self) -> str:
        lines = ["from pyspark.sql import SparkSession", "", "spark = (", "    SparkSession.builder"]
        for k, v in self.to_spark_conf().items():
            lines.append(f'    .config("{k}", "{v}")')
        lines += ["    .getOrCreate()", ")"]
        return "\n".join(lines)


@dataclass
class SizingReport:
    script_analysis: ScriptAnalysis
    data_sources: list[DataSource]
    cluster_profile: ClusterProfile
    recommended_config: SparkConfig
    warnings: list[str] = field(default_factory=list)
    rationale: dict[str, str] = field(default_factory=dict)

    @property
    def total_data_gb(self) -> float:
        return sum(ds.size_gb for ds in self.data_sources)
