"""CLI entry point: spark-sizer <script.py> [options]"""
import argparse
import json
import sys

from .estimator import SparkSizer
from .models import ClusterProfile, DataSource


def parse_data_sources(specs: list[str]) -> list[DataSource]:
    """Parse 'name:size_gb[:cached]' strings into DataSource objects."""
    sources = []
    for spec in specs:
        parts = spec.split(":")
        if len(parts) < 2:
            print(f"[warn] skipping malformed data source spec: {spec!r}", file=sys.stderr)
            continue
        name = parts[0]
        try:
            size_gb = float(parts[1])
        except ValueError:
            print(f"[warn] invalid size for source {name!r}: {parts[1]}", file=sys.stderr)
            continue
        cached = len(parts) > 2 and parts[2].lower() in ("cached", "true", "1")
        sources.append(DataSource(name=name, size_gb=size_gb, is_cached=cached))
    return sources


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="spark-sizer",
        description="Estimate ideal Spark config from a PySpark script and data sizes.",
    )
    p.add_argument("script", help="Path to the PySpark script to analyse")
    p.add_argument(
        "--data", "-d",
        metavar="NAME:SIZE_GB[:cached]",
        action="append",
        default=[],
        help="Data source spec (repeatable). E.g. --data events:500 --data users:0.5:cached",
    )
    p.add_argument("--nodes", "-n", type=int, default=10, help="Number of cluster nodes (default: 10)")
    p.add_argument("--cores", "-c", type=int, default=16, help="Cores per node (default: 16)")
    p.add_argument("--memory", "-m", type=float, default=64.0, help="Memory GB per node (default: 64)")
    p.add_argument(
        "--output", "-o",
        choices=["text", "json", "pyspark"],
        default="text",
        help="Output format (default: text)",
    )
    return p


def render_text(report) -> str:
    lines = []
    lines.append("=" * 60)
    lines.append("  spark-sizer: Recommended Spark Configuration")
    lines.append("=" * 60)

    lines.append(f"\nCluster: {report.cluster_profile.num_nodes} nodes × "
                 f"{report.cluster_profile.cores_per_node} cores, "
                 f"{report.cluster_profile.memory_gb_per_node}GB/node")
    lines.append(f"Total input: {report.total_data_gb:.1f} GB across "
                 f"{len(report.data_sources)} sources")

    lines.append(f"\nScript analysis:")
    a = report.script_analysis
    lines.append(f"  Shuffle operations : {a.shuffle_count}")
    lines.append(f"  Join operations    : {a.join_count}")
    lines.append(f"  Cache/persist      : {a.cache_count}")
    lines.append(f"  Broadcast hints    : {'yes' if a.has_broadcast else 'no'}")

    lines.append("\nRecommended config:")
    for k, v in report.recommended_config.to_spark_conf().items():
        lines.append(f"  {k} = {v}")

    if report.rationale:
        lines.append("\nRationale:")
        for key, reason in report.rationale.items():
            lines.append(f"  [{key}] {reason}")

    if report.warnings:
        lines.append("\nWarnings:")
        for w in report.warnings:
            lines.append(f"  ⚠ {w}")

    lines.append("")
    return "\n".join(lines)


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    data_sources = parse_data_sources(args.data)
    if not data_sources:
        print("[warn] No data sources provided. Using placeholder 10GB dataset.", file=sys.stderr)
        data_sources = [DataSource(name="input", size_gb=10.0)]

    cluster = ClusterProfile(
        num_nodes=args.nodes,
        cores_per_node=args.cores,
        memory_gb_per_node=args.memory,
    )

    sizer = SparkSizer()
    report = sizer.size_from_file(args.script, data_sources, cluster)

    if args.output == "json":
        conf = report.recommended_config.to_spark_conf()
        out = {
            "config": conf,
            "warnings": report.warnings,
            "rationale": report.rationale,
        }
        print(json.dumps(out, indent=2))
    elif args.output == "pyspark":
        print(report.recommended_config.to_pyspark_code())
    else:
        print(render_text(report))


if __name__ == "__main__":
    main()
