from .analyzer import PySparkAnalyzer
from .models import (
    ClusterProfile,
    DataSource,
    ScriptAnalysis,
    SizingReport,
    SparkConfig,
)
from .rules import (
    recommend_broadcast_threshold,
    recommend_default_parallelism,
    recommend_driver_memory,
    recommend_executor_layout,
    recommend_executor_memory,
    recommend_shuffle_partitions,
)


class SparkSizer:
    def __init__(self) -> None:
        self._analyzer = PySparkAnalyzer()

    def size_from_file(
        self,
        script_path: str,
        data_sources: list[DataSource],
        cluster: ClusterProfile,
    ) -> SizingReport:
        analysis = self._analyzer.analyze_file(script_path)
        return self._build_report(analysis, data_sources, cluster)

    def size_from_source(
        self,
        source: str,
        data_sources: list[DataSource],
        cluster: ClusterProfile,
    ) -> SizingReport:
        analysis = self._analyzer.analyze_source(source)
        return self._build_report(analysis, data_sources, cluster)

    def _build_report(
        self,
        analysis: ScriptAnalysis,
        sources: list[DataSource],
        cluster: ClusterProfile,
    ) -> SizingReport:
        rationale: dict[str, str] = {}
        warnings: list[str] = []

        executor_memory_gb, mem_rationale = recommend_executor_memory(cluster, sources, analysis)
        rationale["executor_memory"] = mem_rationale

        driver_memory_gb, drv_rationale = recommend_driver_memory(cluster, sources, analysis)
        rationale["driver_memory"] = drv_rationale

        executor_instances, executor_cores, layout_rationale = recommend_executor_layout(
            cluster, sources, analysis, executor_memory_gb
        )
        rationale["executor_layout"] = layout_rationale

        shuffle_partitions, part_rationale = recommend_shuffle_partitions(
            cluster, sources, analysis, executor_cores
        )
        rationale["shuffle_partitions"] = part_rationale

        default_parallelism = recommend_default_parallelism(cluster, executor_cores)

        broadcast_threshold_mb, bc_rationale = recommend_broadcast_threshold(sources, analysis)
        rationale["broadcast_threshold"] = bc_rationale

        memory_storage_fraction = 0.5
        if analysis.cache_count > 0:
            memory_storage_fraction = 0.6
            rationale["memory_storage_fraction"] = "Increased to 0.6 due to caching"

        extra: dict[str, str] = {}
        if analysis.has_skew_hint or analysis.join_count > 2:
            extra["spark.sql.adaptive.skewJoin.skewedPartitionFactor"] = "5"
            extra["spark.sql.adaptive.skewJoin.skewedPartitionThresholdInBytes"] = "256m"

        config = SparkConfig(
            executor_instances=executor_instances,
            executor_cores=executor_cores,
            executor_memory_gb=executor_memory_gb,
            driver_memory_gb=driver_memory_gb,
            shuffle_partitions=shuffle_partitions,
            default_parallelism=default_parallelism,
            broadcast_threshold_mb=broadcast_threshold_mb,
            memory_storage_fraction=memory_storage_fraction,
            extra=extra,
        )

        warnings.extend(self._generate_warnings(analysis, sources, cluster, config))

        return SizingReport(
            script_analysis=analysis,
            data_sources=sources,
            cluster_profile=cluster,
            recommended_config=config,
            warnings=warnings,
            rationale=rationale,
        )

    def _generate_warnings(
        self,
        analysis: ScriptAnalysis,
        sources: list[DataSource],
        cluster: ClusterProfile,
        config: SparkConfig,
    ) -> list[str]:
        warnings = []
        total_gb = sum(s.size_gb for s in sources)

        if analysis.join_count > 0 and not analysis.has_broadcast:
            small_sources = [s for s in sources if s.size_gb < 1.0]
            if small_sources:
                names = ", ".join(s.name for s in small_sources)
                warnings.append(
                    f"Consider broadcasting small tables ({names}) to avoid shuffle joins."
                )

        if total_gb > cluster.total_memory_gb * 0.5:
            warnings.append(
                "Input data exceeds 50% of total cluster memory — "
                "consider increasing cluster size or enabling adaptive coalescing."
            )

        if analysis.shuffle_count > 5:
            warnings.append(
                f"{analysis.shuffle_count} shuffle operations detected — "
                "consider caching intermediate results to reduce recomputation."
            )

        if cluster.num_nodes == 1:
            warnings.append(
                "Single-node cluster detected — local mode may be more efficient for development."
            )

        cluster_max_executors = cluster.num_nodes * max(1, cluster.cores_per_node // 5) - 1
        if config.executor_instances < cluster_max_executors * 0.5:
            idle_executors = cluster_max_executors - config.executor_instances
            warnings.append(
                f"Data is small relative to cluster size — {idle_executors} executors would sit idle. "
                f"Consider running on a smaller cluster ({max(1, cluster.num_nodes // 4)}–{max(2, cluster.num_nodes // 2)} nodes) "
                "or using dynamic allocation."
            )

        return warnings
