import math
from pathlib import Path
from typing import Literal, Optional, Union

from pharmpy.deps import pandas as pd
from pharmpy.internals.fn.signature import with_same_arguments_as
from pharmpy.internals.fn.type import with_runtime_arguments_type_check
from pharmpy.internals.fs.path import normalize_user_given_path, path_absolute
from pharmpy.mfl import ModelFeatures
from pharmpy.model import Model
from pharmpy.modeling import (
    add_iiv,
    convert_model,
    create_basic_kpd_model,
    create_basic_pd_model,
    filter_dataset,
    fix_parameters,
    get_observations,
    get_sigmas,
    is_binary,
    set_description,
    set_initial_estimates,
    set_name,
    set_placebo_model,
    set_proportional_error_model,
    unfix_parameters,
)
from pharmpy.modeling.mfl import generate_transformations
from pharmpy.tools.common import (
    create_plots,
    table_final_eta_shrinkage,
    update_initial_estimates,
)
from pharmpy.tools.modelfit import create_fit_workflow
from pharmpy.tools.run import run_subtool, summarize_modelfit_results
from pharmpy.workflows import ModelEntry, ModelfitResults, Task, Workflow, WorkflowBuilder

from .results import PDSearchResults


def create_workflow(
    input: Union[Path, str, Model],
    type: Literal['pd', 'kpd'],
    treatment_variable: Optional[str] = None,
    kpd_driver: Literal['ir', 'amount'] = 'ir',
    algorithm: Literal['stepwise', 'exhaustive_stepwise'] = 'stepwise',
    data_strategy: Literal['full', 'partial', 'fix'] = 'full',
    results: Optional[ModelfitResults] = None,
    strictness: str = "minimization_successful or (rounding_errors and sigdigs>=0.1)",
    parameter_uncertainty_method: Optional[Literal['SANDWICH', 'SMAT', 'RMAT', 'EFIM']] = None,
):
    """
    Build a PD model

    Parameters
    ----------
    input : Union[Path, str, Model]
        A PD/KPD dataset or PD/KPD model
    type : str
        Type of PD model to build ('pd' or 'kpd')
    treatment_variable : str
        Name of the variable representing the treatment, e.g. TRT, DOSE or AUC. Do not use if `type` is 'kpd'
    kpd_driver : str
        Driver for KPD model (virtual infusion rate 'ir' or 'amount')
    algorithm : str
        Which search algorithm to use. Either 'stepwise' or 'exhaustive_stepwise'
    data_strategy : str
        Strategy for using the dataset: 'full', 'partial' or 'fix'
    results : ModelfitResults (optional)
        Results to input model
    strictness : str
        Strictness criteria
    parameter_uncertainty_method : {'SANDWICH', 'SMAT', 'RMAT', 'EFIM'} or None
        Parameter uncertainty method. Will be used in ranking models if strictness includes
        parameter uncertainty

    Returns
    -------
    PDSearchResults
        PDSearch tool results object.

    """
    wb = WorkflowBuilder(name="pdsearch")

    # Needs to be done client side
    if isinstance(input, str):
        input = normalize_user_given_path(input)
        input = path_absolute(input)

    start_task = Task('start_pdsearch', start_pdsearch, input, type, kpd_driver, results)
    wb.add_task(start_task)

    if isinstance(input, Model):
        base_output = [start_task]
    else:
        fitbase = create_fit_workflow(n=1)
        wb.insert_workflow(fitbase, predecessors=[start_task])
        base_output = wb.output_tasks

    if algorithm == 'stepwise':
        placebo_task = Task(
            'run_placebo_models_and_rank',
            run_placebo_models_and_rank,
            strictness,
            parameter_uncertainty_method,
            treatment_variable,
            data_strategy,
        )
        wb.add_task(placebo_task, predecessors=base_output)

        de_task = Task(
            'run_drug_effect_models',
            run_drug_effect_models,
            treatment_variable,
            strictness,
            parameter_uncertainty_method,
            data_strategy,
            type,
        )
        wb.add_task(de_task)

        postprocess_task = Task('postprocess', postprocess, data_strategy)
        wb.add_task(postprocess_task, predecessors=de_task)

        wb.scatter(placebo_task, (de_task, postprocess_task))

    else:
        placebo_task = Task(
            'run_placebo_models', create_and_run_placebo_models, treatment_variable, data_strategy
        )
        wb.add_task(placebo_task, predecessors=base_output)

        de_task = Task(
            'run_drug_effect_models',
            run_drug_effect_models_exhaustive,
            treatment_variable,
            strictness,
            parameter_uncertainty_method,
            data_strategy,
            type,
        )
        wb.add_task(de_task, predecessors=placebo_task)

        postprocess_task = Task('postprocess', postprocess, data_strategy, None)
        wb.add_task(postprocess_task, predecessors=de_task)

    return Workflow(wb)


def _calc_pd_inits_from_data(model):
    idc = model.datainfo.id_column.name
    obs = get_observations(model)
    theta_init = obs.groupby(idc).median().median()
    variance = (obs.groupby(idc).std() ** 2).mean()
    mean = obs.groupby(idc).mean().mean()
    omega_init = math.log((1 + variance / mean**2))
    return theta_init, omega_init


def start_pdsearch(context, input, type, kpd_driver, results):
    context.log_info("Starting pdsearch")
    if isinstance(input, Model):
        me = ModelEntry.create(input, modelfit_results=results)
        context.store_input_model_entry(me)
        return me
    else:
        model = create_base_model(type, input, kpd_driver)
        me = ModelEntry.create(model=model)
        return me


def create_base_model(type, dataset, kpd_driver):
    if type == 'pd':
        model = create_basic_pd_model(dataset)
    else:
        model = create_basic_kpd_model(dataset, driver=kpd_driver)
    model = set_proportional_error_model(model, zero_protection=False)
    model = add_iiv(model, ["B"], "exp")
    if isinstance(dataset, Path):
        theta_init, omega_init = _calc_pd_inits_from_data(model)
        model = set_initial_estimates(model, {"POP_B": theta_init, "IIV_B": omega_init})
    model = convert_model(model, 'nonmem')  # FIXME: Workaround for results retrieval system
    return model


def create_and_run_placebo_models(context, treatment_variable, data_strategy, baseme):
    exprs = (
        ("linear", "*"),
        ("linear", "+"),
        ("exp_decrease", "*"),
        ("exp_increase", "*"),
        ("exp_decrease_to_new_SS", "+"),
        ("tmax", "*"),
        ("tmax", "+"),
    )
    context.log_info(f"Running {len(exprs)} placebo/disease progression models.")
    if data_strategy == 'full':
        current_me = baseme
    else:
        model = filter_dataset(baseme.model, f"{treatment_variable}!=0")
        if len(get_observations(model)) == 0:
            context.abort_workflow("No observations left in dataset after ignoring placebo data")
        current_me = ModelEntry.create(model=model, modelfit_results=baseme.modelfit_results)

    wb = WorkflowBuilder()
    for expr, op in exprs:
        create_task = Task(
            f'create_placebo_{expr}_{op}', create_placebo_model, expr, op, current_me
        )
        wb.add_task(create_task)
        fit_wf = create_fit_workflow(n=1)
        wb.insert_workflow(fit_wf, [create_task])

    wb.gather(wb.output_tasks)

    mes = context.call_workflow(Workflow(wb), "fit-placebo")
    return (baseme,) + mes


def run_placebo_models_and_rank(
    context, strictness, parameter_uncertainty_method, treatment_variable, data_strategy, baseme
):
    mes = create_and_run_placebo_models(context, treatment_variable, data_strategy, baseme)

    rank_res = run_subtool(
        tool_name='modelrank',
        ctx=context,
        models=[me.model for me in mes],
        results=[me.modelfit_results for me in mes],
        ref_model=mes[0].model,
        rank_type='bic_mixed',
        strictness=strictness,
        parameter_uncertainty_method=parameter_uncertainty_method,
    )

    final_model = rank_res.final_model
    if final_model is None:
        context.abort_workflow("No placebo/disease progression model selected")

    if data_strategy != 'full':
        final_model = final_model.replace(
            dataset=baseme.model.dataset, datainfo=baseme.model.datainfo
        )
        final_model = final_model.update_source()

    final_me = ModelEntry.create(model=final_model, modelfit_results=rank_res.final_results)

    return final_me, rank_res


def fix_thetas_and_omegas(me: ModelEntry) -> ModelEntry:
    model = me.model
    sigmas = get_sigmas(model).names
    thetas_and_omegas = set(model.parameters.names) - set(sigmas)
    model = fix_parameters(model, thetas_and_omegas)
    return ModelEntry.create(model=model, modelfit_results=me.modelfit_results)


def create_and_run_drug_effect_models(context, treatment_variable: str, data_strategy, type, mes):
    if isinstance(mes, ModelEntry):
        mes = [mes]

    if data_strategy == 'fix':
        mes = [fix_thetas_and_omegas(me) for me in mes]

    n_models = 0
    wb = WorkflowBuilder()
    for baseme in mes:
        if type == 'pd':
            mfl = ModelFeatures.create(
                "DIRECTEFFECT([STEP, EMAX, SIGMOID]);INDIRECTEFFECT([LINEAR, EMAX, SIGMOID], *)"
            )
        else:
            # INDIRECTEFFECT not supported for KPD models
            mfl = ModelFeatures.create("DIRECTEFFECT([STEP, EMAX, SIGMOID])")
        if treatment_variable is None or not is_binary(baseme.model, treatment_variable):
            # If the driver is binary linear and step are the same model
            # so add linear if not binary
            mfl = mfl + ModelFeatures.create("DIRECTEFFECT(LINEAR)")

        for feature in mfl:
            create_task = Task(
                f'create_drug_effect_{feature.args[0].lower()}',
                create_drug_effect_model,
                treatment_variable,
                feature,
                baseme,
            )
            wb.add_task(create_task)
            fit_wf = create_fit_workflow(n=1)
            wb.insert_workflow(fit_wf, [create_task])
            n_models += 1

    wb.gather(wb.output_tasks)

    context.log_info(f"Running {n_models} drug_effect models.")

    mes = context.call_workflow(Workflow(wb), "fit-drug_effect")
    return mes


def run_drug_effect_models(
    context,
    treatment_variable,
    strictness,
    parameter_uncertainty_method,
    data_strategy,
    type,
    baseme,
):
    mes = create_and_run_drug_effect_models(
        context, treatment_variable, data_strategy, type, baseme
    )

    rank_res = run_subtool(
        tool_name='modelrank',
        ctx=context,
        models=[me.model for me in mes] + [baseme.model],
        results=[me.modelfit_results for me in mes] + [baseme.modelfit_results],
        ref_model=baseme.model,
        rank_type='bic_mixed',
        strictness=strictness,
        parameter_uncertainty_method=parameter_uncertainty_method,
    )

    return rank_res


def run_drug_effect_models_exhaustive(
    context,
    treatment_variable,
    strictness,
    parameter_uncertainty_method,
    data_strategy,
    type,
    basemes,
):
    mes = create_and_run_drug_effect_models(
        context, treatment_variable, data_strategy, type, basemes
    )

    rank_res = run_subtool(
        tool_name='modelrank',
        ctx=context,
        models=[me.model for me in mes] + [me.model for me in basemes],
        results=[me.modelfit_results for me in mes] + [me.modelfit_results for me in basemes],
        ref_model=basemes[0].model,
        rank_type='bic_mixed',
        strictness=strictness,
        parameter_uncertainty_method=parameter_uncertainty_method,
    )

    return rank_res


def create_placebo_model(expr, op, baseme):
    base_model = baseme.model
    model = set_initial_estimates(base_model, baseme.modelfit_results.parameter_estimates)
    model = set_placebo_model(model, expr, op)
    if op == '*':
        txtop = 'mult'
    elif op == '+':
        txtop = 'add'
    else:
        txtop = op

    model = set_name(model, f"placebo_{txtop}_{expr}")
    model = set_description(model, f"PLACEBO({expr.upper()} {txtop})")
    if expr == 'linear':
        model = add_iiv(model, 'SLOPE', 'prop')
    me = ModelEntry.create(model=model, parent=base_model)
    return me


def create_drug_effect_model(treatment_variable, feature, baseme):
    if not treatment_variable:
        treatment_variable = 'KPD'
    base_model = baseme.model
    model = update_initial_estimates(base_model, baseme.modelfit_results, max_theta=True)
    mfl = ModelFeatures.create([feature])
    func = generate_transformations(mfl)[0]
    model = func(model, variable=treatment_variable)
    model = set_name(model, f"{base_model.name}_drug_{feature.args[0].lower()}")
    model = set_description(model, model.description + f"; {feature}")
    me = ModelEntry.create(model=model, parent=base_model)
    return me


def postprocess(context, data_strategy, rank_res, rank_res2):
    if rank_res is not None:
        step1 = rank_res.summary_tool.assign(step=1)
        step2 = rank_res2.summary_tool.assign(step=2)
        summary_tool = pd.concat((step1, step2))
    else:
        summary_tool = rank_res2.summary_tool.assign(step=1)

    final_model = rank_res2.final_model
    final_results = rank_res2.final_results

    if data_strategy == 'fix':
        unfixed_model = unfix_parameters(final_model, final_model.parameters.names)
        if unfixed_model != final_model:
            unfixed_model = set_name(unfixed_model, "unfixed_final")
            me = ModelEntry.create(model=unfixed_model)
            fit_wf = create_fit_workflow(me)

            context.log_info("Running final model with all parameters unfixed.")
            mes = context.call_workflow(fit_wf, "fit-unfixed_model")
            final_model = mes.model
            final_results = mes.modelfit_results

    summary_tool = summary_tool.reset_index().set_index(["model", "step"])
    summary_models = summarize_modelfit_results(context)

    plots = create_plots(final_model, final_results)
    eta_shrinkage = table_final_eta_shrinkage(final_model, final_results)

    context.store_final_model_entry(final_model)

    res = PDSearchResults(
        summary_tool=summary_tool,
        summary_models=summary_models,
        final_model=final_model,
        final_results=final_results,
        final_model_dv_vs_ipred_plot=plots['dv_vs_ipred'],
        final_model_dv_vs_pred_plot=plots['dv_vs_pred'],
        final_model_cwres_vs_idv_plot=plots['cwres_vs_idv'],
        final_model_abs_cwres_vs_ipred_plot=plots['abs_cwres_vs_ipred'],
        final_model_eta_distribution_plot=plots['eta_distribution'],
        final_model_eta_shrinkage=eta_shrinkage,
    )

    context.log_info("Finishing pdsearch")
    return res


@with_runtime_arguments_type_check
@with_same_arguments_as(create_workflow)
def validate_input(
    input,
    type,
    treatment_variable,
    kpd_driver,
    results,
    strictness,
    parameter_uncertainty_method,
):
    if type == 'pd' and treatment_variable is None:
        raise ValueError('Invalid `treatment_variable`: must be specified when type is `pd`')
