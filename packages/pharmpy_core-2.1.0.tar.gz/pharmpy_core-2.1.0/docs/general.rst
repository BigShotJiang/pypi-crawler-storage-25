.. _general:

=======
General
=======

General information about the Pharmpy tools can be found here:

.. toctree::
   :maxdepth: 1

   Common features <common_features>
   Model Feature Language (MFL) <mfl>
   Options <options>
   Strictness <strictness>
   Selection criteria <selection_criteria>
   Context <context>
   Dispatching <dispatching>
