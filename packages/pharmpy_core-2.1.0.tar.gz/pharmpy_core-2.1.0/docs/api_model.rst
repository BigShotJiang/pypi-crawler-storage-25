=====
Model
=====

.. automodapi:: pharmpy.model
