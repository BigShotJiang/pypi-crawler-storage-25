import os
import re
import sys

sys.path.append(os.path.abspath('./_ext'))

extensions = [
    'sphinx.ext.autodoc',
    'sphinx.ext.autosummary',
    'sphinx.ext.coverage',
    'sphinx.ext.doctest',
    'sphinx.ext.extlinks',
    'sphinx.ext.githubpages',
    'sphinx.ext.graphviz',
    'sphinx.ext.ifconfig',
    'sphinx.ext.inheritance_diagram',
    'sphinx.ext.mathjax',
    'sphinx.ext.napoleon',
    'sphinx.ext.viewcode',
    'sphinx_automodapi.automodapi',
    'jupyter_sphinx',
    'sphinx_tabs.tabs',
    'sphinxcontrib.autoprogram',
    'sphinxcontrib.bibtex',
    'pharmpy_snippet',
]
if os.getenv('SPELLCHECK'):
    extensions += 'sphinxcontrib.spelling',
    spelling_show_suggestions = True
    spelling_lang = 'en_US'

source_suffix = '.rst'
master_doc = 'index'
project = 'Pharmpy'
year = '2018-2026'
authors = ['the Pharmpy development team']
copyright = '{0}; {1}'.format(year, ', '.join(authors))
version = release = '2.1.0'
html_show_sourcelink = False

pygments_style = 'trac'
templates_path = ['.']

html_static_path = ['.']
html_theme = "pydata_sphinx_theme"
html_css_files = [
    'custom.css',
]
html_use_smartypants = True
html_last_updated_fmt = '%b %d, %Y'
html_split_index = False
html_theme_options = {
    'globaltoc_maxdepth': 2,
    "logo": {
        "image_light": "Pharmpy_logo.svg",
        "image_dark": "Pharmpy_logo_dark.svg",
    },
    'github_url': 'https://github.com/pharmpy/pharmpy',
    "icon_links": [
        {
            "name": "Report issues",
            "url": "https://github.com/pharmpy/pharmpy/issues",
            "icon": "fa fa-bug",
        },
        {
            "name": "Discussions",
            "url": "https://github.com/pharmpy/pharmpy/discussions",
            "icon": "fa fa-comments",
        },
    ]
}
html_favicon = 'images/Pharmpy_symbol.svg'
html_context = {
   "default_mode": "light"
}
html_short_title = '%s-%s' % (project, version)

napoleon_use_ivar = True
napoleon_use_rtype = False
napoleon_use_param = False

automodapi_inheritance_diagram = False
autodoc_typehints = 'none'
graphviz_output_format = 'svg'
bibtex_bibfiles = ['references.bib']

import doctest
doctest_show_success = False
doctest_default_flags = doctest.NORMALIZE_WHITESPACE
doctest_global_setup = '''
import pandas as pd
pd.set_option('display.width', 1000)
pd.set_option('display.max_columns', 1000)
'''

linkcheck_ignore = [r'https://doi.org/10.1002/psp4.12741', # Page is reachable from browser but gives 403 with GET
    r'https://doi.org/10.1515/ijb-2019-0082',
    r'https://projecteuclid.org/journals/electronic-journal-of-statistics/volume-8/issue-1/A-note-on-BIC-in-mixed-effects-models/10.1214/14-EJS890.full',
    r'https://www.page-meeting.org/?abstract=8683',
    r'https://www.page-meeting.org/default.asp?abstract=11600']

linkcheck_ignore = [re.escape(url) for url in linkcheck_ignore]
