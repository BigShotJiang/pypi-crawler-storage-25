import shutil

import pytest

from pharmpy.internals.fs.cwd import chdir
from pharmpy.model import Model
from pharmpy.modeling import (
    convert_model,
    create_basic_pk_model,
    fix_parameters,
    remove_parameter_uncertainty_step,
    set_direct_effect,
    transform_blq,
)
from pharmpy.tools import fit, read_modelfit_results, run_tool
from pharmpy.workflows import LocalDirectoryContext


def test_ruvsearch(tmp_path, testdata):
    with chdir(tmp_path):
        for path in (testdata / 'nonmem' / 'ruvsearch').glob('mox3.*'):
            shutil.copy2(path, tmp_path)
        shutil.copy2(testdata / 'nonmem' / 'ruvsearch' / 'moxo_simulated_resmod.csv', tmp_path)
        shutil.copy2(testdata / 'nonmem' / 'ruvsearch' / 'mytab', tmp_path)

        model = Model.parse_model('mox3.mod')
        results = read_modelfit_results('mox3.mod')
        model = remove_parameter_uncertainty_step(model)
        res = run_tool('ruvsearch', model=model, results=results, groups=4, p_value=0.05, skip=[])
        iteration = [1, 1, 1, 1, 1, 1, 2, 2, 2, 3, 3]
        ctx = LocalDirectoryContext("ruvsearch1")
        best_model = ctx.retrieve_final_model_entry().model
        assert (res.cwres_models.index.get_level_values('iteration') == iteration).all()
        assert best_model.code.split('\n')[12] == 'IF (TAD.LT.6.0) THEN'
        assert (
            best_model.code.split('\n')[13]
            == '    Y = A(2)/VC + A(2)*EPS(1)*THETA(4)*EXP(ETA_RV1)/VC'
        )
        assert best_model.code.split('\n')[15] == '    Y = A(2)/VC + A(2)*EPS(1)*EXP(ETA_RV1)/VC'
        assert best_model.code.split('\n')[20].startswith('$THETA  1.3800')
        assert best_model.code.split('\n')[26].startswith('$OMEGA  0.0314')


def test_ruvsearch_blq(tmp_path, testdata):
    with chdir(tmp_path):
        for path in (testdata / 'nonmem' / 'ruvsearch').glob('mox3.*'):
            shutil.copy2(path, tmp_path)
        shutil.copy2(testdata / 'nonmem' / 'ruvsearch' / 'moxo_simulated_resmod.csv', tmp_path)
        shutil.copy2(testdata / 'nonmem' / 'ruvsearch' / 'mytab', tmp_path)

        # Introduce 0 in CWRES to mimic rows BLQ
        with open('mytab') as f:
            mytab_new = f.read().replace('-2.4366E+00', '0.0000E+00')

        with open('mytab', 'w') as f:
            f.write(mytab_new)

        model = Model.parse_model('mox3.mod')
        results = read_modelfit_results('mox3.mod')

        model = transform_blq(model, method='m4', lloq=0.05)

        assert len(results.residuals.loc[results.residuals['CWRES'] == 0]) > 0

        res = run_tool(
            'ruvsearch',
            model=model,
            results=results,
            skip=['IIV_on_RUV', 'time_varying'],
            max_iter=1,
        )

        assert len(res.cwres_models) > 1


@pytest.mark.parametrize(
    'kwargs, no_of_steps, no_of_models',
    [
        (dict(), 3, 5),
        ({'skip': ['IIV_on_RUV', 'time_varying']}, 1, 3),
    ],
)
def test_ruvsearch_dummy(tmp_path, testdata, kwargs, no_of_steps, no_of_models):
    with chdir(tmp_path):
        for path in (testdata / 'nonmem' / 'ruvsearch').glob('mox3.*'):
            shutil.copy2(path, tmp_path)
        shutil.copy2(testdata / 'nonmem' / 'ruvsearch' / 'moxo_simulated_resmod.csv', tmp_path)
        shutil.copy2(testdata / 'nonmem' / 'ruvsearch' / 'mytab', tmp_path)

        model = Model.parse_model('mox3.mod')
        results = read_modelfit_results('mox3.mod')
        model = remove_parameter_uncertainty_step(model)
        res = run_tool(
            'ruvsearch',
            model=model,
            results=results,
            groups=4,
            p_value=0.05,
            esttool='dummy',
            dispatcher='local_serial',  # In order for dummy OFVs to work properly
            ncores=1,
            **kwargs,
        )

        steps = set(res.summary_tool.index.get_level_values('step'))
        assert len(steps) == no_of_steps

        models = set(res.summary_tool.index.get_level_values('model'))
        assert len(models) == no_of_models

        rundir = tmp_path / 'ruvsearch1'
        assert (rundir / 'models' / 'base_1' / 'model.ctl').exists()
        assert (rundir / 'models' / 'base_1' / 'model_results.json').exists()
        assert not (rundir / 'models' / 'base_1' / 'model.lst').exists()


def test_ruvsearch_dv(tmp_path, load_model_for_test, testdata):
    with chdir(tmp_path):
        dataset = testdata / "nonmem/pheno_pd.csv"
        model = create_basic_pk_model("iv", dataset_path=dataset)
        model = convert_model(model, 'nonmem')

        pkpd_model = fix_parameters(model, model.parameters.names)
        pkpd_model = set_direct_effect(pkpd_model, 'linear')
        pkpd_res = fit(pkpd_model)

        res_ruv = run_tool('ruvsearch', model=pkpd_model, results=pkpd_res, dv=2)
        assert res_ruv
