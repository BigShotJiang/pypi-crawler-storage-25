from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ActionResult:
    """Result from a mouse/keyboard/tap/swipe action."""

    status: str = "ok"

    @classmethod
    def from_dict(cls, d: dict) -> ActionResult:
        return cls(status=d.get("status", "ok"))


@dataclass
class CursorPosition:
    x: int
    y: int

    @classmethod
    def from_dict(cls, d: dict) -> CursorPosition:
        return cls(x=d.get("x", 0), y=d.get("y", 0))


@dataclass
class DisplayInfo:
    width: int
    height: int
    scale: float = 1.0

    @classmethod
    def from_dict(cls, d: dict) -> DisplayInfo:
        return cls(
            width=d.get("width", 0),
            height=d.get("height", 0),
            scale=d.get("scale", 1.0),
        )


@dataclass
class RecordingInfo:
    id: str
    status: str = ""
    name: str | None = None
    filename: str = ""
    file_size: int = 0

    @classmethod
    def from_dict(cls, d: dict) -> RecordingInfo:
        return cls(
            id=d.get("id") or d.get("recording_id", ""),
            status=d.get("status", ""),
            name=d.get("name"),
            filename=d.get("filename", ""),
            file_size=d.get("file_size", 0),
        )


@dataclass
class ExecResult:
    return_code: int
    stdout: str

    @classmethod
    def from_dict(cls, d: dict) -> ExecResult:
        return cls(
            return_code=d.get("return_code", 0),
            stdout=d.get("stdout", ""),
        )


@dataclass
class ActResult:
    """Result from a compound act() call."""

    screenshot: bytes | None = None
    data: dict = field(default_factory=dict)
