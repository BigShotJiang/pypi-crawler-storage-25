"""Write tools for optimization: submit_optimization, cancel_optimization.

Both go through the read-only gate. ``submit_optimization`` exposes the full
parameter surface per plan + code-review-2 G1 (``min_improvement`` and
``max_cost_usd`` are load-bearing for the org-level plateau settings).
"""

from __future__ import annotations

from typing import Any

from mcp.types import Tool
from ptm_client import PTMClient

from ..config import Settings
from ._helpers import call_client_safely
from ._writes import ensure_writes_allowed

_VISIBILITY_SCOPES = ("private_only", "org_visible", "group_visible")


def specs(settings: Settings) -> list[tuple[Tool, Any]]:
    return [
        (_submit_schema(), _make_submit_handler(settings)),
        (_cancel_schema(), _make_cancel_handler(settings)),
    ]


# ----------------------------------------------------------------------
# submit_optimization
# ----------------------------------------------------------------------


def _submit_schema() -> Tool:
    return Tool(
        name="submit_optimization",
        description=(
            "Queue an auto-optimization run for a library prompt. Evolves the prompt "
            "through evaluate -> analyze -> LLM-mutate cycles until target_score, "
            "max_cycles, max_cost_usd, or plateau. Requires PTM_MCP_READ_ONLY=false."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "prompt_id": {"type": "string"},
                "provider_profiles": {"type": "array", "items": {"type": "string"}},
                "judge_profile": {"type": ["string", "null"]},
                "max_cycles": {"type": "integer", "minimum": 1, "maximum": 50},
                "target_score": {"type": "number", "minimum": 0, "maximum": 100},
                "min_improvement": {"type": "number", "minimum": 0},
                "max_cost_usd": {"type": "number", "minimum": 0},
                "comparison_strategy": {"type": ["string", "null"]},
                "visibility_scope": {"type": "string", "enum": list(_VISIBILITY_SCOPES)},
            },
            "required": ["prompt_id"],
            "additionalProperties": False,
        },
    )


def _make_submit_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        prompt_id = _require_str(arguments, "prompt_id")

        # Forward only keys the caller supplied so ptm-client defaults
        # (max_cycles=10, target_score=90, etc.) stay authoritative.
        kwargs: dict[str, Any] = {}
        for key in (
            "provider_profiles",
            "judge_profile",
            "max_cycles",
            "target_score",
            "min_improvement",
            "max_cost_usd",
            "comparison_strategy",
            "visibility_scope",
        ):
            if arguments.get(key) is not None:
                kwargs[key] = arguments[key]

        return await call_client_safely(client.submit_optimization, prompt_id, **kwargs)

    return _handler


# ----------------------------------------------------------------------
# cancel_optimization
# ----------------------------------------------------------------------


def _cancel_schema() -> Tool:
    return Tool(
        name="cancel_optimization",
        description=("Cancel a running optimization by id. Requires PTM_MCP_READ_ONLY=false."),
        inputSchema={
            "type": "object",
            "properties": {"optimization_id": {"type": "string"}},
            "required": ["optimization_id"],
            "additionalProperties": False,
        },
    )


def _make_cancel_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        optimization_id = _require_str(arguments, "optimization_id")
        return await call_client_safely(client.cancel_optimization, optimization_id)

    return _handler


def _require_str(arguments: dict[str, Any], key: str) -> str:
    value = arguments.get(key)
    if not isinstance(value, str) or not value:
        raise ValueError(f"'{key}' is required and must be a non-empty string")
    return value
