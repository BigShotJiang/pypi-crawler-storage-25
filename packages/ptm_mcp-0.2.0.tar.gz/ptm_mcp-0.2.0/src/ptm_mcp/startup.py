"""Preflight checks run before the MCP server begins serving tools.

Executes in order: /healthz (with exponential backoff on transient network
errors), /auth/me (fatal on 4xx), /meta (reject if backend is older than
``MIN_BACKEND_VERSION``). Finally, emits warnings if the bearer token is a
PAT (should be a service account) or expires in under 7 days.

Each step has a dedicated exit code so an operator can tell at a glance
which layer failed without parsing log lines. See
``docs/mcp-ptm-phase1.md`` section 18.9 and ``code-review-1.md`` item C12.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from packaging.version import InvalidVersion, Version
from ptm_client import PTMClient, PTMError

from .config import MIN_BACKEND_VERSION, Settings

logger = logging.getLogger("ptm_mcp.startup")


# 1 + 2 + 4 + 8 + 16 = 31 seconds total. Enough to ride out a brief
# backend restart; short enough that MCP clients do not give up first.
_RETRY_DELAYS = (1, 2, 4, 8, 16)


@dataclass
class StartupReport:
    backend_version: str
    token_kind: str | None
    token_expires_at: str | None


class StartupError(RuntimeError):
    """Preflight check failed. Startup should exit with a specific code."""

    def __init__(self, message: str, exit_code: int) -> None:
        super().__init__(message)
        self.exit_code = exit_code


def run_preflight(client: PTMClient, settings: Settings) -> StartupReport:
    """Run the startup checks. Raises StartupError on failure.

    Steps:
      1. Health probe, retry transient errors.
      2. GET /auth/me, validate token + fetch kind/expiry.
      3. GET /meta, reject if backend < MIN_BACKEND_VERSION.
      4. Warn if token is a PAT or expires within 7 days.
    """
    del settings  # reserved for future checks (e.g. read_only validation)
    _probe_with_backoff(client, "/healthz", exit_code=2)
    me = _probe_auth_me(client, exit_code=3)
    version = _probe_meta_version(client, exit_code=4)
    _warn_token_type(me)
    return StartupReport(
        backend_version=version,
        token_kind=me.get("token_kind"),
        token_expires_at=me.get("token_expires_at"),
    )


# ----------------------------------------------------------------------
# Internal probes
# ----------------------------------------------------------------------


def _probe_with_backoff(client: PTMClient, path: str, *, exit_code: int) -> None:
    """Retry connection-level failures with exponential backoff. 4xx is fatal."""
    last_err: PTMError | None = None
    for attempt, delay in enumerate((0, *_RETRY_DELAYS)):
        if delay:
            logger.info("[ptm-mcp] %s retry %d/%d in %ds", path, attempt, len(_RETRY_DELAYS), delay)
            time.sleep(delay)
        try:
            client._get(path)  # type: ignore[attr-defined]
            return
        except PTMError as exc:
            if exc.status_code != 0:
                raise StartupError(f"backend rejected {path}: {exc}", exit_code=exit_code) from exc
            last_err = exc
    raise StartupError(
        f"backend unreachable after {len(_RETRY_DELAYS)} retries: {last_err}",
        exit_code=exit_code,
    )


def _probe_auth_me(client: PTMClient, *, exit_code: int) -> dict:
    try:
        return client._get("/api/v1/auth/me")  # type: ignore[attr-defined]
    except PTMError as exc:
        raise StartupError(
            f"GET /auth/me failed: {exc}. Check PTM_API_TOKEN.",
            exit_code=exit_code,
        ) from exc


def _probe_meta_version(client: PTMClient, *, exit_code: int) -> str:
    try:
        meta = client._get("/api/v1/meta")  # type: ignore[attr-defined]
    except PTMError as exc:
        raise StartupError(f"GET /meta failed: {exc}", exit_code=exit_code) from exc
    raw = (meta or {}).get("version", "")
    version_str = str(raw).strip()
    if not version_str:
        raise StartupError(
            f"backend /meta did not include a version; upgrade PTM to >= {MIN_BACKEND_VERSION}",
            exit_code=exit_code,
        )
    try:
        actual = Version(version_str)
        required = Version(MIN_BACKEND_VERSION)
    except InvalidVersion as exc:
        raise StartupError(
            f"backend returned unparseable version {version_str!r}",
            exit_code=exit_code,
        ) from exc
    # Pre-release-tolerant compare. PEP 440 sorts "1.9.0rc1" < "1.9.0", but
    # the rc is feature-equivalent in our release flow so it must satisfy
    # the gate. Compare against actual.base_version when actual is a
    # prerelease: Version("1.9.0rc1").base_version == "1.9.0", which then
    # compares equal to required. A plain Version >= Version check (and
    # SpecifierSet(prereleases=True)) both still reject the rc against the
    # base release because PEP 440 strictly orders prereleases earlier.
    effective = Version(actual.base_version) if actual.is_prerelease else actual
    if effective < required:
        raise StartupError(
            f"backend version {version_str} < required {MIN_BACKEND_VERSION}",
            exit_code=exit_code,
        )
    return version_str


def _warn_token_type(me: dict) -> None:
    kind = (me or {}).get("token_kind")
    if kind == "pat":
        logger.warning(
            "[ptm-mcp] bearer token is a PAT. Prefer a service-account token "
            "for MCP deployments so per-agent budgets and audit trails are accurate."
        )
    expires_at = (me or {}).get("token_expires_at")
    if expires_at:
        try:
            expiry = datetime.fromisoformat(str(expires_at).replace("Z", "+00:00"))
        except ValueError:
            return
        if expiry.tzinfo is None:
            expiry = expiry.replace(tzinfo=UTC)
        if expiry - datetime.now(UTC) < timedelta(days=7):
            logger.warning(
                "[ptm-mcp] bearer token expires at %s (<7 days). Rotate soon.",
                expires_at,
            )
