"""ptm-mcp: MCP stdio server for the Prompt Test Manager API."""

__version__ = "0.2.0"

__all__ = ["__version__"]
