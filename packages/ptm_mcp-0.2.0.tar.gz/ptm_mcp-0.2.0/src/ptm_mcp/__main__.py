"""CLI entry point. Invoked as ``python -m ptm_mcp`` or ``ptm-mcp``."""

from __future__ import annotations


def main() -> int:
    import asyncio
    import logging

    from .server import run

    try:
        return asyncio.run(run())
    except KeyboardInterrupt:
        return 130
    except Exception as exc:  # noqa: BLE001 - top-level boundary
        logging.getLogger("ptm_mcp").exception("fatal: %s", exc)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
