from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

import pytest

from pyinc import (
    Database,
    FrozenAdapterValue,
    FrozenGraph,
    FrozenRef,
    Input,
    MutationError,
    UnsupportedValueError,
    ValueAdapter,
    deserialize_snapshot,
    freeze,
    query,
    serialize_snapshot,
    thaw,
)
from pyinc.value import (
    FrozenDict,
    FrozenList,
    FrozenRecord,
    FrozenSet,
    _AdapterRegistry,
    assert_not_mutated,
    fingerprint,
    fingerprint_snapshot,
    semantic_equal,
)


@dataclass(frozen=True)
class Point:
    x: int
    y: int


class PointAdapter(ValueAdapter):
    def freeze(self, value: Point, freeze: Any) -> object:
        assert callable(freeze)
        return {"x": value.x, "y": value.y}

    def thaw(self, snapshot: Any, thaw: Any) -> Point:
        assert callable(thaw)
        data = cast(dict[str, Any], snapshot)
        return Point(
            x=thaw(data["x"]),
            y=thaw(data["y"]),
        )


@dataclass(frozen=True)
class Key:
    name: str

    def __repr__(self) -> str:
        raise RuntimeError("repr should not be used during freeze ordering")


class KeyAdapter(ValueAdapter):
    def freeze(self, value: Key, freeze: Any) -> object:
        assert callable(freeze)
        return {"name": value.name}

    def thaw(self, snapshot: Any, thaw: Any) -> Key:
        assert callable(thaw)
        data = cast(dict[str, Any], snapshot)
        return Key(name=thaw(data["name"]))


def test_freeze_handles_self_referential_list_via_frozen_graph() -> None:
    payload: list[object] = []
    payload.append(payload)

    snapshot = freeze(payload)
    assert isinstance(snapshot, FrozenGraph)
    assert len(snapshot.nodes) == 1
    assert snapshot.root == FrozenRef(0)
    assert snapshot.nodes[0] == FrozenList(items=(FrozenRef(0),))

    thawed = thaw(snapshot)
    assert isinstance(thawed, list)
    assert thawed[0] is thawed


def test_freeze_uses_canonical_sorting_without_repr() -> None:
    adapters = {Key: KeyAdapter()}
    snapshot = freeze({Key("b"): 1, Key("a"): 2}, adapters=adapters)
    round_trip = thaw(snapshot, adapters=adapters)
    assert round_trip == {Key("a"): 2, Key("b"): 1}


def test_adapter_round_trip_works_for_freeze_and_thaw() -> None:
    adapters = {Point: PointAdapter()}
    snapshot = freeze(Point(1, 2), adapters=adapters)

    assert isinstance(snapshot, FrozenAdapterValue)
    assert thaw(snapshot, adapters=adapters) == Point(1, 2)


def test_database_uses_adapters_for_boundary_values() -> None:
    adapters = {Point: PointAdapter()}
    payload = Input[Point]("payload")

    @query
    def total(db: Database) -> int:
        point = payload.read(db)
        assert isinstance(point, Point)
        return point.x + point.y

    db = Database(mode="checked", adapters=adapters)
    db.set(payload, Point(2, 3))
    assert db.get(total) == 5
    key, _ = db._query_key(total, (), {})
    assert db._records[key].last_decision == "executed"

    db.set(payload, Point(2, 3))
    assert db.get(total) == 5
    assert db._records[key].last_decision == "reused"


# ---------------------------------------------------------------------------
# Group A: Freeze/thaw round-trips
# ---------------------------------------------------------------------------


def test_freeze_thaw_round_trip_list() -> None:
    value = [1, "a", True, None]
    frozen = freeze(value)
    assert isinstance(frozen, FrozenList)
    assert thaw(frozen) == value


def test_freeze_thaw_round_trip_dict() -> None:
    value = {"b": 2, "a": 1}
    frozen = freeze(value)
    assert isinstance(frozen, FrozenDict)
    thawed = thaw(frozen)
    assert thawed == value


def test_freeze_thaw_round_trip_set() -> None:
    value = {3, 1, 2}
    frozen = freeze(value)
    assert isinstance(frozen, FrozenSet)
    assert frozen.kind == "set"
    assert thaw(frozen) == value


def test_freeze_thaw_round_trip_frozenset() -> None:
    value = frozenset([3, 1, 2])
    frozen = freeze(value)
    assert isinstance(frozen, FrozenSet)
    assert frozen.kind == "frozenset"
    assert thaw(frozen) == value


def test_freeze_thaw_round_trip_tuple() -> None:
    value = (1, [2, 3], {"k": "v"})
    frozen = freeze(value)
    assert isinstance(frozen, tuple)
    thawed = thaw(frozen)
    assert thawed == value


def test_freeze_thaw_round_trip_nested_combinations() -> None:
    value: dict[str, Any] = {"items": [1, {"nested": True}, (3, 4)], "meta": None}
    thawed = thaw(freeze(value))
    assert thawed == value


def test_freeze_thaw_round_trip_dataclass() -> None:
    @dataclass(frozen=True)
    class Config:
        name: str
        values: tuple[int, ...]

    frozen = freeze(Config("x", (1, 2)))
    assert isinstance(frozen, FrozenRecord)
    assert "Config" in frozen.type_name
    # Dataclasses thaw to dicts.
    thawed = thaw(frozen)
    assert thawed == {"name": "x", "values": (1, 2)}


# ---------------------------------------------------------------------------
# Group B: Container protocol operations
# ---------------------------------------------------------------------------


def test_frozen_list_indexing_iteration_len() -> None:
    fl = FrozenList(items=(10, 20, 30))
    assert fl[0] == 10
    assert fl[2] == 30
    assert len(fl) == 3
    assert list(fl) == [10, 20, 30]


def test_frozen_dict_lookup_iteration_keyerror() -> None:
    fd = FrozenDict(entries=(("a", 1), ("b", 2)))
    assert fd["a"] == 1
    assert fd["b"] == 2
    assert list(fd) == ["a", "b"]
    assert len(fd) == 2
    with pytest.raises(KeyError):
        fd["missing"]


def test_frozen_set_contains_iteration_len() -> None:
    fs = FrozenSet(kind="set", items=(1, 2, 3))
    assert 1 in fs
    assert 4 not in fs
    assert len(fs) == 3
    assert set(fs) == {1, 2, 3}


def test_frozen_record_lookup_iteration_keyerror() -> None:
    fr = FrozenRecord(type_name="Cfg", entries=(("x", 1), ("y", 2)))
    assert fr["x"] == 1
    assert fr["y"] == 2
    assert list(fr) == ["x", "y"]
    assert len(fr) == 2
    with pytest.raises(KeyError):
        fr["z"]


# ---------------------------------------------------------------------------
# Group C: Edge cases
# ---------------------------------------------------------------------------


def test_freeze_empty_containers() -> None:
    assert freeze([]) == FrozenList(items=())
    assert freeze({}) == FrozenDict(entries=())
    assert freeze(set()) == FrozenSet(kind="set", items=())
    assert freeze(()) == ()

    # Round-trip empties.
    assert thaw(freeze([])) == []
    assert thaw(freeze({})) == {}
    assert thaw(freeze(set())) == set()
    assert thaw(freeze(())) == ()


def test_freeze_single_element_containers() -> None:
    assert isinstance(freeze([42]), FrozenList)
    assert thaw(freeze([42])) == [42]

    assert isinstance(freeze({"k": "v"}), FrozenDict)
    assert thaw(freeze({"k": "v"})) == {"k": "v"}

    assert isinstance(freeze({99}), FrozenSet)
    assert thaw(freeze({99})) == {99}


def test_freeze_deeply_nested_five_levels() -> None:
    value: list[Any] = [{"a": [{"b": (1, [2, 3])}]}]
    thawed = thaw(freeze(value))
    assert thawed == value


def test_freeze_already_frozen_values_pass_through() -> None:
    fl = FrozenList(items=(1, 2))
    fd = FrozenDict(entries=(("a", 1),))
    fs = FrozenSet(kind="set", items=(1,))
    fr = FrozenRecord(type_name="R", entries=(("x", 1),))
    fa = FrozenAdapterValue(adapter_key="test:T", payload="data")
    fref = FrozenRef(index=0)
    fg = FrozenGraph(nodes=(FrozenList(items=(FrozenRef(0),)),), root=FrozenRef(0))

    # Already-frozen values hit the early return — identity preserved.
    assert freeze(fl) is fl
    assert freeze(fd) is fd
    assert freeze(fs) is fs
    assert freeze(fr) is fr
    assert freeze(fa) is fa
    assert freeze(fref) is fref
    assert freeze(fg) is fg


# ---------------------------------------------------------------------------
# Group D: Type conversion and rejection
# ---------------------------------------------------------------------------


def test_freeze_pathlike_converts_to_str() -> None:
    result = freeze(Path("/tmp/test.txt"))
    assert isinstance(result, str)
    assert result == "/tmp/test.txt"


def test_freeze_range_converts_to_tuple() -> None:
    result = freeze(range(1, 10, 2))
    assert result == ("range", 1, 10, 2)


def test_freeze_rejects_iterator_and_generator() -> None:
    with pytest.raises(UnsupportedValueError, match="Iterators and generators"):
        freeze(iter([1, 2]))

    def gen() -> Any:
        yield 1

    with pytest.raises(UnsupportedValueError, match="Iterators and generators"):
        freeze(gen())


def test_freeze_rejects_unsupported_types() -> None:
    with pytest.raises(UnsupportedValueError, match="Unsupported boundary value"):
        freeze(object())

    with pytest.raises(UnsupportedValueError, match="Unsupported boundary value"):
        freeze(lambda: None)


# ---------------------------------------------------------------------------
# Group E: Equality, fingerprint, mutation check
# ---------------------------------------------------------------------------


def test_semantic_equal_same_structure() -> None:
    assert semantic_equal([1, 2], [1, 2])
    assert semantic_equal({"a": 1, "b": [2]}, {"a": 1, "b": [2]})
    assert semantic_equal((1, 2, 3), (1, 2, 3))
    assert not semantic_equal([1, 2], [1, 3])


def test_semantic_equal_different_container_types() -> None:
    # list freezes to FrozenList, tuple stays tuple — not equal.
    assert not semantic_equal([1, 2], (1, 2))
    # set vs frozenset — different kind field.
    assert not semantic_equal({1, 2}, frozenset({1, 2}))


def test_fingerprint_determinism() -> None:
    # Same value → same digest.
    assert fingerprint({"a": [1, 2], "b": 3}) == fingerprint({"a": [1, 2], "b": 3})
    # Dict ordering doesn't matter (freeze sorts entries).
    assert fingerprint({"b": 3, "a": [1, 2]}) == fingerprint({"a": [1, 2], "b": 3})
    # Different values → different digests.
    assert fingerprint([1, 2]) != fingerprint([1, 3])


CANONICAL_FINGERPRINTS: dict[str, tuple[Any, str]] = {
    "none": (None, "bc84a14378e233c608ccc17f177919a6595f9d6331b9a5c5d8ffd0eade02bb87"),
    "true": (True, "d84c15ea4d5e0080d8dbabc5ce68dbd742fbbd0499d4df57ef079c53d8871b45"),
    "false": (
        False,
        "3f05aff300785adb8cdb12bb9993f3b494b7e1de18042e42a5f5e863e49cc5f8",
    ),
    "int-zero": (0, "1f5fe91ed5208d6477e3d13cca2812d9c1c42defb7dab70d784f45f65565b8fd"),
    "int-one": (1, "ec187eb76b8d83f7e32bd0b232f69735d1a65a8a78529b0654411717920e53cf"),
    "int-neg-one": (
        -1,
        "2d47fa0bc94ee71387d24889f9db1d68fb766b5c62d76709386c07ae630b94c6",
    ),
    "float-1.5": (
        1.5,
        "dd96a811716c46538b4197ff3950edf3f49ae9d60768708c746a752dadf10c56",
    ),
    "str-empty": (
        "",
        "482975b5aa2860a276737cba6db568490b691439406fbb367f3b604bb5210ba3",
    ),
    "str-hello": (
        "hello",
        "fc322c5025dd198cb3fb82b6bcd16933f825fbd6991e27c11f52159ce3196aff",
    ),
    "bytes-empty": (
        b"",
        "37591557e2971f9d22a13734870a227c1f09fa2db90410e374d5398b41458998",
    ),
    "bytes-deadbeef": (
        b"\xde\xad\xbe\xef",
        "2e7517169495c8c68748b8a7e4b5d65edda8e3f147186cbcb91f558ac5d1c1c8",
    ),
    "tuple-1-2": (
        (1, 2),
        "5c7369e88f8c1ac8aa9c6d40293d9bca89c7eefc7be95171520a7c26a420e17f",
    ),
    "frozenlist-1-2": (
        FrozenList((1, 2)),
        "cda055499f3951671946049d2351b5fd9cd819ddbadb4cd29196263ab2e3fea0",
    ),
    "frozendict-a1-b2": (
        FrozenDict((("a", 1), ("b", 2))),
        "a2314b9c7615be9706387bd492849f94b88a62c02a6f9d9efd7f65bc5947b4f4",
    ),
    "frozenset-set-1-2": (
        FrozenSet("set", (1, 2)),
        "ee2eaaecaa7809412de0bfa62e9c0911dc43d6ae94f5de8d56241764023b817e",
    ),
    "frozenset-frozenset-1-2": (
        FrozenSet("frozenset", (1, 2)),
        "a4fd14bb2105db0058518e6646536c1ff566c058e2d52da333485a0507c355b2",
    ),
    "frozenrecord-point-x1-y2": (
        FrozenRecord("Point", (("x", 1), ("y", 2))),
        "54d491b759c0fce6fd77da828a7a8b4dc0f2d8954109834a479b3ba5030758ed",
    ),
    "frozenadapter-mod-pt-1": (
        FrozenAdapterValue("mod:Pt", 1),
        "af0c41f8d3007f00c9a7ea5933f30f1b45fd4bef98a5f5d828fae6964a19da16",
    ),
    "complex-1+2j": (
        complex(1, 2),
        "7d5cd6c5ec8d30c14912b51d052e79e2e88752d5d815f43559a7cdc5a09eaa45",
    ),
}


def test_fingerprint_snapshot_pins_exact_bytes_for_canonical_values() -> None:
    for label, (value, expected_digest) in CANONICAL_FINGERPRINTS.items():
        actual = fingerprint_snapshot(value)
        assert (
            actual == expected_digest
        ), f"fingerprint_snapshot drift for {label!r}: got {actual}, expected {expected_digest}"


def test_fingerprint_snapshot_distinguishes_shapes() -> None:
    # bool vs int
    assert fingerprint_snapshot(False) != fingerprint_snapshot(0)
    assert fingerprint_snapshot(True) != fingerprint_snapshot(1)
    # FrozenList vs raw tuple
    assert fingerprint_snapshot(FrozenList((1, 2))) != fingerprint_snapshot((1, 2))
    # FrozenSet "set" vs "frozenset"
    assert fingerprint_snapshot(FrozenSet("set", (1, 2))) != fingerprint_snapshot(
        FrozenSet("frozenset", (1, 2))
    )
    # range-as-tuple vs raw tuple with same head
    assert fingerprint_snapshot(("range", 1, 10, 2)) != fingerprint_snapshot((1, 10, 2))
    # FrozenRecord differing type_name
    assert fingerprint_snapshot(
        FrozenRecord("Point", (("x", 1),))
    ) != fingerprint_snapshot(FrozenRecord("Other", (("x", 1),)))
    # FrozenAdapterValue differing adapter_key
    assert fingerprint_snapshot(FrozenAdapterValue("a", 1)) != fingerprint_snapshot(
        FrozenAdapterValue("b", 1)
    )
    # string length-prefix must defeat concatenation collisions
    assert fingerprint_snapshot(("ab", "cd")) != fingerprint_snapshot(("a", "bcd"))
    # bytes vs str with matching ASCII content
    assert fingerprint_snapshot("ab") != fingerprint_snapshot(b"ab")


def test_fingerprint_snapshot_rejects_non_snapshot_values() -> None:
    class NotASnapshot:
        pass

    with pytest.raises(TypeError, match="unsupported snapshot value"):
        fingerprint_snapshot(NotASnapshot())


def test_fingerprint_snapshot_equivalence_under_freeze_normalization() -> None:
    # freeze() sorts dict entries; two insertion-order dicts yield the same snapshot.
    left = freeze({"b": 1, "a": 2})
    right = freeze({"a": 2, "b": 1})
    assert fingerprint_snapshot(left) == fingerprint_snapshot(right)

    # Sets freeze by canonical sort — ordering of input items does not affect digest.
    assert fingerprint_snapshot(freeze({1, 2, 3})) == fingerprint_snapshot(
        freeze({3, 2, 1})
    )


def test_assert_not_mutated_matching_passes_different_raises() -> None:
    assert_not_mutated("abc123", "abc123")  # No exception.
    with pytest.raises(MutationError):
        assert_not_mutated("abc123", "xyz789")


# ---------------------------------------------------------------------------
# Group F: Adapter registry
# ---------------------------------------------------------------------------


def test_adapter_registry_mro_resolution() -> None:
    class Base:
        pass

    class Child(Base):
        pass

    class BaseAdapter:
        def freeze(self, value: Any, freeze_fn: Any) -> Any:
            return "frozen"

        def thaw(self, snapshot: Any, thaw_fn: Any) -> Any:
            return Base()

    registry = _AdapterRegistry({Base: BaseAdapter()})

    # Child resolves to Base adapter via MRO.
    result = registry.for_value(Child())
    assert result is not None
    assert result[1] is not None

    # Base itself resolves.
    result = registry.for_value(Base())
    assert result is not None


def test_thaw_without_matching_adapter_raises() -> None:
    frozen = FrozenAdapterValue(adapter_key="nonexistent:Type", payload="data")
    with pytest.raises(UnsupportedValueError, match="Cannot thaw adapted snapshot"):
        thaw(frozen)


def test_adapter_registry_for_value_returns_none_for_unknown_type() -> None:
    registry = _AdapterRegistry({Point: PointAdapter()})
    assert registry.for_value("a string") is None
    assert registry.for_value(42) is None


# ---------------------------------------------------------------------------
# Group G: Mutable graph support — shared identity and cycles via FrozenGraph
# ---------------------------------------------------------------------------


def test_freeze_preserves_shared_identity_in_list() -> None:
    inner = [1, 2, 3]
    payload = [inner, inner]

    snapshot = freeze(payload)
    assert isinstance(snapshot, FrozenGraph)

    thawed = thaw(snapshot)
    assert isinstance(thawed, list)
    assert thawed[0] is thawed[1]
    assert thawed[0] == [1, 2, 3]


def test_freeze_preserves_shared_identity_in_dict_value() -> None:
    shared = {"k": "v"}
    payload = {"a": shared, "b": shared}

    snapshot = freeze(payload)
    assert isinstance(snapshot, FrozenGraph)

    thawed = thaw(snapshot)
    assert isinstance(thawed, dict)
    assert thawed["a"] is thawed["b"]


def test_freeze_handles_mutual_reference_cycle() -> None:
    a: list[Any] = []
    b: list[Any] = []
    a.append(b)
    b.append(a)

    snapshot = freeze(a)
    assert isinstance(snapshot, FrozenGraph)

    thawed = thaw(snapshot)
    assert isinstance(thawed, list)
    # Walk the cycle: a → b → a
    assert thawed[0][0] is thawed


def test_freeze_handles_deep_mutual_graph_round_trips() -> None:
    nodes: list[list[Any]] = [[] for _ in range(10)]
    for i in range(10):
        nodes[i].append(nodes[(i + 1) % 10])

    snapshot = freeze(nodes[0])
    assert isinstance(snapshot, FrozenGraph)

    thawed = thaw(snapshot)
    cur = thawed
    for _ in range(20):
        cur = cur[0]
    # 20 hops on a 10-cycle starting from thawed-nodes[0] returns to thawed-nodes[0].
    assert cur is thawed


def test_freeze_pure_tree_does_not_wrap_in_frozen_graph() -> None:
    # Plain tree — no shared subtrees, no cycles. Existing flat shape preserved
    # so the common case stays zero-overhead.
    snapshot = freeze([1, [2, [3]]])
    assert isinstance(snapshot, FrozenList)


def test_frozen_graph_digest_is_deterministic_across_construction_orders() -> None:
    a: list[Any] = []
    a.append(a)
    digest_a = fingerprint(a)

    b: list[Any] = []
    b.append(b)
    digest_b = fingerprint(b)

    assert digest_a == digest_b


# ---------------------------------------------------------------------------
# Group H: Serialize/deserialize and K2 fingerprint prefix
# ---------------------------------------------------------------------------


def test_kernel_fingerprint_prefix_is_k2() -> None:
    # The serialized byte form (which is also the digest input) must carry a
    # version prefix so older durable caches cannot be silently accepted.
    payload = serialize_snapshot(freeze("hello"))
    assert payload.startswith(b"K2;")


def test_serialize_deserialize_round_trip_scalars() -> None:
    for value in (
        None,
        True,
        False,
        0,
        1,
        -1,
        1.5,
        "",
        "hello",
        b"",
        b"\xde\xad",
        complex(1, 2),
    ):
        payload = serialize_snapshot(freeze(value))
        assert deserialize_snapshot(payload) == freeze(value)


def test_serialize_deserialize_round_trip_containers() -> None:
    samples: list[Any] = [
        [1, 2, 3],
        {"b": 2, "a": 1},
        {1, 2, 3},
        frozenset({4, 5}),
        (1, "two", True),
    ]
    for value in samples:
        snapshot = freeze(value)
        payload = serialize_snapshot(snapshot)
        assert deserialize_snapshot(payload) == snapshot


def test_serialize_deserialize_round_trip_dataclass() -> None:
    @dataclass(frozen=True)
    class Cfg:
        name: str
        values: tuple[int, ...]

    snapshot = freeze(Cfg("x", (1, 2)))
    assert deserialize_snapshot(serialize_snapshot(snapshot)) == snapshot


def test_serialize_deserialize_round_trip_adapter_value() -> None:
    adapters = {Point: PointAdapter()}
    snapshot = freeze(Point(1, 2), adapters=adapters)
    assert deserialize_snapshot(serialize_snapshot(snapshot)) == snapshot


def test_serialize_deserialize_round_trip_frozen_graph_with_cycle() -> None:
    payload: list[Any] = []
    payload.append(payload)
    snapshot = freeze(payload)
    assert isinstance(snapshot, FrozenGraph)

    bytes_payload = serialize_snapshot(snapshot)
    decoded = deserialize_snapshot(bytes_payload)
    assert decoded == snapshot


def test_deserialize_rejects_payload_without_k2_prefix() -> None:
    with pytest.raises(UnsupportedValueError, match="kernel fingerprint version"):
        deserialize_snapshot(b"K1;N;")
    with pytest.raises(UnsupportedValueError, match="kernel fingerprint version"):
        deserialize_snapshot(b"N;")
    with pytest.raises(UnsupportedValueError, match="kernel fingerprint version"):
        deserialize_snapshot(b"")


def test_deserialize_rejects_trailing_garbage() -> None:
    payload = serialize_snapshot(freeze(42))
    with pytest.raises(UnsupportedValueError, match="trailing"):
        deserialize_snapshot(payload + b"junk")
