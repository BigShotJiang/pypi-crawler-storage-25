import click
from dotenv import load_dotenv
from . import corelogic as core

load_dotenv()


@click.group()
@click.version_option("0.1.3", prog_name="gitputra")
def main():
    """🔍 Gitputra — AI-powered GitHub repo analyzer."""
    pass


# ─────────────────────────────────────────────
# ANALYZE
# ─────────────────────────────────────────────
@main.command()
@click.argument("url")
@click.option(
    "--ai", "ai_choice",
    type=click.Choice(["gemini", "openai", "claude"], case_sensitive=False),
    default="gemini", show_default=True,
    help="AI provider to use."
)
@click.option(
    "--key",
    envvar="API_KEY", default=None,
    help="API key (or set API_KEY in .env). Avoid passing directly to keep it out of shell history."
)
@click.option(
    "--lang", default="English", show_default=True,
    help="Output language for the report."
)
@click.option(
    "--no-pdf", is_flag=True, default=False,
    help="Skip PDF generation."
)
@click.option(
    "--no-diagram", is_flag=True, default=False,
    help="Skip diagram generation."
)
def analyze(url, ai_choice, key, lang, no_pdf, no_diagram):
    """Clone a GitHub repo and generate an AI analysis report.

    \b
    Example:
        gitputra analyze https://github.com/user/repo --ai gemini --key AIza...
    """
    if not key:
        raise click.UsageError("API key required. Use --key or set API_KEY in .env")

    core.init(ai_choice.lower(), key, lang)

    repo_path, repo_name = core.clone_repo(url)
    files = core.load_files(repo_path)

    if not files:
        click.secho("❌ No supported source files found.", fg="red")
        raise SystemExit(1)

    collection = core.get_collection(repo_name)
    if collection.count() == 0:
        core.store_chunks(files, repo_name)
    else:
        click.secho("ℹ️  Using existing index (run 'clear-db' to re-index).", fg="cyan")

    analysis = core.analyze_repo(files)

    click.echo("\n" + analysis + "\n")

    if not no_diagram:
        core.generate_diagram(files)
        core.generate_mermaid(files)

    if not no_pdf:
        core.generate_pdf(analysis)

    click.secho("✅ Done! Outputs saved in ./output/", fg="green")


# ─────────────────────────────────────────────
# CHAT
# ─────────────────────────────────────────────
@main.command()
@click.argument("url")
@click.option(
    "--ai", "ai_choice",
    type=click.Choice(["gemini", "openai", "claude"], case_sensitive=False),
    default="gemini", show_default=True,
)
@click.option(
    "--key",
    envvar="API_KEY", default=None,
    help="API key (or set API_KEY in .env). Avoid passing directly to keep it out of shell history."
)
@click.option("--lang", default="English", show_default=True)
def chat(url, ai_choice, key, lang):
    """Start an interactive RAG chat about a repo.

    \b
    Example:
        gitputra chat https://github.com/user/repo --ai gemini
        Type 'exit' or Ctrl+C to quit.
    """
    if not key:
        raise click.UsageError("API key required. Use --key or set API_KEY in .env")

    core.init(ai_choice.lower(), key, lang)

    repo_path, repo_name = core.clone_repo(url)

    collection = core.get_collection(repo_name)
    if collection.count() == 0:
        click.secho("📂 No existing index found — indexing repo now...", fg="yellow")
        files = core.load_files(repo_path)
        if not files:
            click.secho("❌ No supported source files found.", fg="red")
            raise SystemExit(1)
        core.store_chunks(files, repo_name)
        click.secho("✅ Repo indexed.", fg="green")
    else:
        click.secho("✅ Using existing index.", fg="cyan")

    click.secho(f"\n💬 Chat mode [{repo_name}] — ask anything about the repo. Type 'exit' to quit.\n", fg="cyan")

    while True:
        try:
            question = click.prompt(">>", prompt_suffix=" ")
        except (KeyboardInterrupt, EOFError):
            click.echo("\nBye!")
            break

        if question.strip().lower() in ("exit", "quit", "q"):
            click.echo("Bye!")
            break

        answer = core.query_rag(question, repo_name)
        click.echo(f"\n{answer}\n")


# ─────────────────────────────────────────────
# CLEAR DB
# ─────────────────────────────────────────────
@main.command("clear-db")
def clear_db():
    """Wipe the local ChromaDB collection."""
    import chromadb
    client = chromadb.PersistentClient(path="./chroma_db")
    for col in client.list_collections():
        client.delete_collection(col.name)
    click.secho("🗑️  ChromaDB cleared.", fg="yellow")

@main.command()
def info():
    """Show supported AIs, languages, extensions, and commands."""
    click.secho("\n🔍 GitPutra — AI-powered GitHub Repo Analyzer", fg="cyan", bold=True)
    click.secho("   Version: 0.1.3\n", fg="cyan")

    click.secho("📦 Commands:", fg="yellow", bold=True)
    commands = [
        ("analyze", "Clone a repo and generate a full AI report"),
        ("chat",    "Interactive RAG-based Q&A about a repo"),
        ("clear-db","Wipe the local ChromaDB index"),
        ("info",    "Show this info screen"),
    ]
    for cmd, desc in commands:
        click.echo(f"   {'gitputra ' + cmd:<25} {desc}")

    click.secho("\n🤖 Supported AI Providers:", fg="yellow", bold=True)
    ais = [
        ("gemini", "Google Gemini 2.5 Flash",    "text-embedding-004"),
        ("openai", "OpenAI GPT-4o Mini",          "text-embedding-3-large"),
        ("claude", "Anthropic Claude Sonnet 4.5", "via GEMINI_API_KEY fallback"),
    ]
    for flag, model, embed in ais:
        click.echo(f"   --ai {flag:<10} model: {model:<35} embed: {embed}")

    click.secho("\n🌍 PDF Output Languages (~110 supported):", fg="yellow", bold=True)

    click.secho("   Latin script:", fg="white", bold=True)
    latin = [
        "English", "French", "Spanish", "Portuguese", "Italian", "German",
        "Dutch", "Swedish", "Norwegian", "Danish", "Finnish", "Polish",
        "Czech", "Slovak", "Hungarian", "Romanian", "Croatian", "Serbian (Latin)",
        "Slovenian", "Albanian", "Lithuanian", "Latvian", "Estonian",
        "Turkish", "Azerbaijani", "Uzbek", "Kazakh (Latin)", "Turkmen",
        "Indonesian", "Malay", "Filipino", "Swahili", "Zulu", "Xhosa",
        "Afrikaans", "Yoruba", "Igbo", "Hausa", "Somali", "Kinyarwanda",
        "Welsh", "Irish", "Basque", "Catalan", "Galician", "Maltese",
        "Icelandic", "Faroese", "Vietnamese", "Hawaiian", "Maori",
        "Tok Pisin", "Tswana", "Shona", "Sesotho",
    ]
    row = []
    for i, lang in enumerate(latin):
        row.append(f"{lang:<22}")
        if (i + 1) % 4 == 0:
            click.echo("      " + "".join(row))
            row = []
    if row:
        click.echo("      " + "".join(row))

    click.secho("   Bengali script:", fg="white", bold=True)
    bengali = ["Bengali", "Assamese"]
    click.echo("      " + "  |  ".join(bengali))

    click.secho("   Devanagari script:", fg="white", bold=True)
    devanagari = ["Hindi", "Marathi", "Nepali", "Sanskrit", "Maithili", "Konkani", "Bodo", "Dogri"]
    click.echo("      " + "  |  ".join(devanagari))

    click.echo()
    click.echo("   (AI response language depends on the chosen model's capability)")

    click.secho(f"\n📁 Supported File Extensions ({len(core.SUPPORTED_EXT)} types):", fg="yellow", bold=True)
    exts = sorted(core.SUPPORTED_EXT)
    row = []
    for i, ext in enumerate(exts):
        row.append(f"{ext:<12}")
        if (i + 1) % 8 == 0:
            click.echo("   " + "".join(row))
            row = []
    if row:
        click.echo("   " + "".join(row))

    click.secho("\n📂 Supported Special Files:", fg="yellow", bold=True)
    click.echo("   " + "  |  ".join(core.SUPPORTED_NAMES))

    click.echo()