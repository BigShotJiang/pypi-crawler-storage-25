from __future__ import annotations

from types import SimpleNamespace
from typing import List, Dict, Optional, Any, TYPE_CHECKING

if TYPE_CHECKING:
    import o6


class Namespace:
    def __init__(
        self, uri: str, version: str = "", publication_date: Optional[str] = None
    ) -> None:
        self.metadata = SimpleNamespace(
            uri=uri,
            version=version,
            publication_date=publication_date,
            short_name=self._extract_short_name(uri),
            namespace_index=None,
            namespace_uris=[],
        )

        self._required_namespaces: List[Dict[str, str]] = []

        self._structure_descriptions: List[o6.StructureDescription] = []
        self._enum_descriptions: List[o6.EnumDescription] = []
        self._alias_types: List[Dict[str, Any]] = []

        self.types: SimpleNamespace = SimpleNamespace()

        # holds the owner PyCapsule that keeps the UA_DataType array alive independent of any client/server.
        self._capsule: Any = None

        # Full canonical namespace table snapshot (URI → index) at build
        # time.  Used by clients to register all slots (incl. transitive
        # deps) so that canonical indices are reproduced exactly.
        self._canonical_ns_table: Dict[str, int] = {}

        # Original (pre-remap) NodeId strings for each description.
        # Stored before the first remap so that servers can rebuild from
        # original XML indices without re-parsing the XML.
        # Format: (struct_tuples, enum_id_strings) where each struct tuple
        # is (data_type_id, default_encoding_id | None, [field_data_types]).
        self._original_nodeids: (
            tuple[list[tuple[str, str | None, list[str]]], list[str]] | None
        ) = None

    def __dir__(self) -> list[str]:
        return ["metadata"] + list(vars(self.types).keys())

    def __getattr__(self, name: str) -> Any:
        try:
            return getattr(object.__getattribute__(self, "types"), name)
        except AttributeError:
            raise AttributeError(
                f"'{type(self).__name__}' object has no attribute '{name}'"
            ) from None

    def _copy_for_rebuild(self) -> Namespace:
        d = Namespace(
            self.metadata.uri, self.metadata.version, self.metadata.publication_date
        )
        d.metadata.short_name = self.metadata.short_name
        d.metadata.namespace_uris = list(self.metadata.namespace_uris)
        d._structure_descriptions = list(self._structure_descriptions)
        d._enum_descriptions = list(self._enum_descriptions)
        d._original_nodeids = self._original_nodeids
        return d

    def _extract_short_name(self, uri: str) -> str:
        if uri.startswith(("http://", "https://")):
            # splitting by /
            parts = [part.strip() for part in uri.split("/") if part.strip()]
        elif uri.startswith("urn:"):
            # splitting by : for URNs
            parts = [part.strip() for part in uri.split(":") if part.strip()]
        else:
            # For other schemes (test://, custom://), split by / after removing scheme
            scheme_end = uri.find("://") + 3 if "://" in uri else 0
            path_part = uri[scheme_end:]
            parts = [part.strip() for part in path_part.split("/") if part.strip()]

        # Try to return the last part, working backwards
        while parts:
            last_part = parts.pop()
            if last_part and last_part not in ["http", "https", "urn"]:
                return last_part

        return "unknown"

    def _add_required_namespace(self, uri: str, version: str = "") -> None:
        dependency = {"uri": uri, "version": version}
        if dependency not in self._required_namespaces:
            self._required_namespaces.append(dependency)

    def _add_alias_type(self, nodeid: Any, base_type_nodeid: Any) -> None:
        alias = {"nodeid": nodeid, "base_type_nodeid": base_type_nodeid}
        self._alias_types.append(alias)

    def _add_structure_description(
        self,
        nodeid: str,
        browse_name: str,
        struct_data: Dict[str, Any] | o6.StructureDefinition,
        default_encoding_id: str | None = None,
    ) -> None:
        import o6 as _o6

        sd = _o6.StructureDescription()
        sd.data_type_id = nodeid
        sd.name = browse_name

        if isinstance(struct_data, dict):
            defn = _o6.StructureDefinition()
            if "structure_type" in struct_data:
                defn.structure_type = _o6.StructureType(struct_data["structure_type"])
            if "fields" in struct_data and isinstance(struct_data["fields"], list):
                fields = []
                for fd in struct_data["fields"]:
                    if isinstance(fd, dict):
                        f = _o6.StructureField()
                        if "name" in fd:
                            f.name = fd["name"]
                        if "description" in fd:
                            f.description = fd["description"]
                        if "is_optional" in fd:
                            f.is_optional = fd["is_optional"]
                        if "value_rank" in fd:
                            f.value_rank = fd["value_rank"]
                        if "data_type" in fd:
                            f.data_type = fd["data_type"]
                        if "array_dimensions" in fd:
                            f.array_dimensions = fd["array_dimensions"]
                        if "max_string_length" in fd:
                            f.max_string_length = fd["max_string_length"]
                        fields.append(f)
                    else:
                        fields.append(fd)
                defn.fields = fields
            if default_encoding_id is not None:
                defn.default_encoding_id = default_encoding_id
            sd.structure_definition = defn
        else:
            sd.structure_definition = struct_data

        self._structure_descriptions.append(sd)

    def _add_enum_description(
        self,
        nodeid: str,
        browse_name: str,
        enum_data: Dict[str, Any] | o6.EnumDefinition,
    ) -> None:
        import o6 as _o6

        ed = _o6.EnumDescription()
        ed.data_type_id = nodeid
        ed.name = browse_name

        if isinstance(enum_data, dict):
            defn = _o6.EnumDefinition()
            if "fields" in enum_data and isinstance(enum_data["fields"], list):
                fields = []
                for fd in enum_data["fields"]:
                    if isinstance(fd, dict):
                        f = _o6.EnumField()
                        if "name" in fd:
                            f.name = fd["name"]
                        if "value" in fd:
                            f.value = fd["value"]
                        if "description" in fd:
                            f.description = fd["description"]
                        if "display_name" in fd:
                            f.display_name = fd["display_name"]
                        fields.append(f)
                    else:
                        fields.append(fd)
                defn.fields = fields
            ed.enum_definition = defn
        else:
            ed.enum_definition = enum_data

        self._enum_descriptions.append(ed)

    def _get_type_summary(self) -> Dict[str, Any]:
        return {
            "namespace_uri": self.metadata.uri,
            "namespace_index": self.metadata.namespace_index,
            "short_name": self.metadata.short_name,
            "structure_count": len(self._structure_descriptions),
            "enum_count": len(self._enum_descriptions),
            "alias_count": len(self._alias_types),
            "dependencies": [
                dep["uri"] if isinstance(dep, dict) else dep.uri
                for dep in self._required_namespaces
            ],
        }

    def _validate(self) -> List[str]:
        issues = []

        if not self.metadata.uri:
            issues.append("Namespace URI is required")

        # Allow more flexible URI formats for testing and custom protocols
        valid_schemes = (
            "http://",
            "https://",
            "urn:",
            "test://",
            "example://",
            "custom://",
        )
        if not self.metadata.uri.startswith(valid_schemes):
            issues.append(f"Invalid URI format: {self.metadata.uri}")

        # Validate required namespace references
        for i, req_ns in enumerate(self._required_namespaces):
            if not req_ns.get("uri"):
                issues.append(f"Required namespace {i} missing URI")

        return issues

    def _to_dict(self) -> Dict[str, Any]:
        return {
            "uri": self.metadata.uri,
            "version": self.metadata.version,
            "publication_date": self.metadata.publication_date,
            "short_name": self.metadata.short_name,
            "required_namespaces": self._required_namespaces,
            "structure_descriptions": self._structure_descriptions,
            "enum_descriptions": self._enum_descriptions,
            "alias_types": self._alias_types,
            "namespace_index": self.metadata.namespace_index,
        }

    def __str__(self) -> str:
        version_str = f" v{self.metadata.version}" if self.metadata.version else ""
        types_str = f" ({len(self._structure_descriptions)}S, {len(self._enum_descriptions)}E, {len(self._alias_types)}A)"
        return (
            f"{self.metadata.short_name}({self.metadata.uri}{version_str}){types_str}"
        )

    def __repr__(self) -> str:
        type_counts = {
            "structures": len(self._structure_descriptions),
            "enums": len(self._enum_descriptions),
            "aliases": len(self._alias_types),
        }
        return (
            f"Namespace(uri='{self.metadata.uri}', version='{self.metadata.version}', "
            f"short_name='{self.metadata.short_name}', types={type_counts})"
        )
