"""
OPC UA NodeSet2 XML Import System

This module provides functionality to load custom types from NodeSet2 XML files
and integrate them with the O6 client. It supports different OPC UA versions
and automatically detects the appropriate loading strategy.
"""

from typing import List, Dict, Optional, Any, Union, Tuple
from dataclasses import dataclass
import logging
import xml.etree.ElementTree as ET
from pathlib import Path
import re
from datetime import datetime

from .namespaces import Namespaces
from .namespace import Namespace
from ._namespace_xml_handlers import VersionHandlerFactory
from ._o6 import types as _o6_types

_logger = logging.getLogger(__name__)


@dataclass
class NodeSetInfo:
    """Information about a NodeSet XML file."""

    file_path: str
    namespace_uri: str
    version: str = ""
    publication_date: Optional[str] = None
    required_models: Optional[List[Dict[str, str]]] = None
    namespace_uris: Optional[List[str]] = None
    opc_ua_version: str = "1.04"  # Default OPC UA version

    def __post_init__(self):
        if self.required_models is None:
            self.required_models = []
        if self.namespace_uris is None:
            self.namespace_uris = []


class NodeSetParser:
    """
    Parser for NodeSet2 XML files.

    Handles different OPC UA versions and extracts namespace and type information.
    """

    def __init__(self, strict_mode: bool = True):
        self.strict_mode = strict_mode
        self._namespaces: Dict[str, str] = {}  # prefix -> uri mapping
        self._aliases: Dict[str, str] = {}  # alias -> NodeId mapping

    def parse_file(self, file_path: Union[str, Path]) -> NodeSetInfo:
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"NodeSet file not found: {file_path}")

        try:
            tree = ET.parse(file_path)
            return self._parse_root(tree.getroot(), str(file_path))
        except ET.ParseError as e:
            raise ValueError(f"Invalid XML in NodeSet file {file_path}: {e}")
        except Exception as e:
            raise RuntimeError(f"Error parsing NodeSet file {file_path}: {e}")

    def parse_content(
        self, xml_str: str, source_name: str = "<content>"
    ) -> NodeSetInfo:
        try:
            root = ET.fromstring(xml_str)
            return self._parse_root(root, source_name)
        except ET.ParseError as e:
            raise ValueError(f"Invalid XML in NodeSet content {source_name!r}: {e}")
        except Exception as e:
            raise RuntimeError(f"Error parsing NodeSet content {source_name!r}: {e}")

    def _parse_root(self, root: ET.Element, source_name: str) -> NodeSetInfo:
        namespace_uri = self._extract_namespace_uri(root)
        namespace_uris = self._extract_namespace_uris(root)
        version = self._extract_version(root)
        publication_date = self._extract_publication_date(root)
        required_models = self._extract_required_models(root)
        opc_ua_version = self._detect_opc_ua_version(root)

        return NodeSetInfo(
            file_path=source_name,
            namespace_uri=namespace_uri,
            version=version,
            publication_date=publication_date,
            required_models=required_models,
            namespace_uris=namespace_uris,
            opc_ua_version=opc_ua_version,
        )

    def _extract_namespace_uri(self, root: ET.Element) -> str:
        """Extract the main namespace URI from the NodeSet."""
        NS = "http://opcfoundation.org/UA/2011/03/UANodeSet.xsd"

        # Prefer <Models><Model ModelUri="..."> — the authoritative primary URI
        # (OPC UA 1.04+).  For companion specs with multiple dependencies, this
        # is the only reliable source because <NamespaceUris> lists ALL namespaces
        # in XML-index order and the spec's own URI is typically last, not first.
        models_elem = root.find(f".//{{{NS}}}Models")
        if models_elem is not None:
            model_elem = models_elem.find(f"{{{NS}}}Model")
            if model_elem is not None:
                model_uri = model_elem.get("ModelUri")
                if model_uri:
                    return model_uri

        # Fallback for older (pre-1.04) NodeSets that have no <Models> element:
        # use the last <Uri> in <NamespaceUris>.  Older standalone specs typically
        # list only their own URI there; companion specs with dependencies list
        # deps first and their own URI last.
        ns_uris_elem = root.find(f".//{{{NS}}}NamespaceUris")
        if ns_uris_elem is not None:
            uris = [
                el.text.strip()
                for el in ns_uris_elem.findall(f"{{{NS}}}Uri")
                if el.text
            ]
            if uris:
                return uris[-1]

        return "http://example.com/unknown"

    def _extract_namespace_uris(self, root: ET.Element) -> List[str]:
        ns_uris_elem = root.find(
            ".//{http://opcfoundation.org/UA/2011/03/UANodeSet.xsd}NamespaceUris"
        )
        if ns_uris_elem is None:
            return []
        uris: List[str] = []
        for uri_elem in ns_uris_elem.findall(
            "{http://opcfoundation.org/UA/2011/03/UANodeSet.xsd}Uri"
        ):
            if uri_elem.text:
                uris.append(uri_elem.text.strip())
        return uris

    def _extract_version(self, root: ET.Element) -> str:
        """Extract version information from the NodeSet."""
        models_elem = root.find(
            ".//{http://opcfoundation.org/UA/2011/03/UANodeSet.xsd}Models"
        )
        if models_elem is not None:
            model_elem = models_elem.find(
                ".//{http://opcfoundation.org/UA/2011/03/UANodeSet.xsd}Model"
            )
            if model_elem is not None:
                version = model_elem.get("Version")
                if version:
                    return version
        return "1.0.0"

    def _extract_publication_date(self, root: ET.Element) -> Optional[str]:
        """Extract publication date from the NodeSet."""
        models_elem = root.find(
            ".//{http://opcfoundation.org/UA/2011/03/UANodeSet.xsd}Models"
        )
        if models_elem is not None:
            model_elem = models_elem.find(
                ".//{http://opcfoundation.org/UA/2011/03/UANodeSet.xsd}Model"
            )
            if model_elem is not None:
                pub_date = model_elem.get("PublicationDate")
                if pub_date:
                    return pub_date
        return None

    def _extract_required_models(self, root: ET.Element) -> List[Dict[str, str]]:
        """Extract required model dependencies."""
        required_models = []
        models_elem = root.find(
            ".//{http://opcfoundation.org/UA/2011/03/UANodeSet.xsd}Models"
        )
        if models_elem is not None:
            for req_model in models_elem.findall(
                ".//{http://opcfoundation.org/UA/2011/03/UANodeSet.xsd}RequiredModel"
            ):
                model_info = {
                    "ModelUri": req_model.get("ModelUri", ""),
                    "Version": req_model.get("Version", ""),
                    "PublicationDate": req_model.get("PublicationDate", ""),
                }
                required_models.append(model_info)
        return required_models

    def _detect_opc_ua_version(self, root: ET.Element) -> str:
        """
        Detect the OPC UA version from the NodeSet structure.

        Different OPC UA versions have different type loading approaches:
        - 1.03 and earlier: Basic structure support
        - 1.04: Enhanced DataType definitions
        - 1.05: Full structure and union support
        """
        # Check for version-specific elements
        if (
            root.find(
                ".//{http://opcfoundation.org/UA/2011/03/UANodeSet.xsd}StructureDefinition"
            )
            is not None
        ):
            # 1.04+ has StructureDefinition elements
            if (
                root.find(
                    ".//{http://opcfoundation.org/UA/2011/03/UANodeSet.xsd}UnionDefinition"
                )
                is not None
            ):
                return "1.05"  # Unions introduced in 1.05
            return "1.04"

        # Check for DataTypeDefinition with Definition element (1.04 style)
        for datatype in root.findall(
            ".//{http://opcfoundation.org/UA/2011/03/UANodeSet.xsd}UADataType"
        ):
            definition = datatype.find(
                ".//{http://opcfoundation.org/UA/2011/03/UANodeSet.xsd}Definition"
            )
            if definition is not None:
                return "1.04"

        return "1.03"


class TypeLoader:
    """
    Main type loader that coordinates the loading process.

    Automatically detects OPC UA version and uses the appropriate loading strategy.
    """

    def __init__(self, namespaces: Namespaces) -> None:
        self.parser = NodeSetParser()
        self.namespaces = namespaces

    def load_types_from_files(
        self,
        file_paths: List[Union[str, Path]],
        target_namespace_index: Optional[int] = None,
    ) -> Tuple[List[Namespace], List[int], List[str]]:
        """
        Load types from multiple NodeSet2 XML files.

        Args:
            file_paths: List of paths to NodeSet2 XML files
            target_namespace_index: Optional starting namespace index

        Returns:
            Tuple of (loaded_descriptors, namespace_indices, errors)
        """
        loaded_namespaces = []
        namespace_indices = []
        errors = []

        current_index = (
            target_namespace_index if target_namespace_index is not None else 2
        )

        for file_path in file_paths:
            try:
                # Parse file info
                nodeset_info = self.parser.parse_file(file_path)
                _logger.info(
                    f"Loading NodeSet: {nodeset_info.namespace_uri} v{nodeset_info.version}"
                )

                # Create namespace description
                namespace_desc = self._create_namespace_description(
                    nodeset_info, current_index
                )

                # Load types based on OPC UA version
                self._load_types_by_version(nodeset_info, namespace_desc)

                loaded_namespaces.append(namespace_desc)
                namespace_indices.append(current_index)
                current_index += 1

                _logger.info(
                    f"Successfully loaded namespace {namespace_desc.metadata.short_name} at index {current_index-1}"
                )

            except Exception as e:
                error_msg = f"Failed to load {file_path}: {str(e)}"
                errors.append(error_msg)
                _logger.error(error_msg)

                if self.parser.strict_mode:
                    break

        return loaded_namespaces, namespace_indices, errors

    def _create_namespace_description(
        self, nodeset_info: NodeSetInfo, namespace_index: int
    ) -> Namespace:
        """Create a Namespace from NodeSetInfo."""
        namespace_desc = Namespace(
            uri=nodeset_info.namespace_uri,
            version=nodeset_info.version,
            publication_date=nodeset_info.publication_date,
        )
        namespace_desc.metadata.namespace_index = namespace_index
        namespace_desc.metadata.namespace_uris = nodeset_info.namespace_uris or []

        # Add required dependencies
        for req_model in (nodeset_info.required_models or []):
            namespace_desc._add_required_namespace(
                req_model.get("ModelUri", ""), req_model.get("Version", "")
            )

        return namespace_desc

    def _load_types_from_xml_root(
        self,
        xml_root: ET.Element,
        nodeset_info: NodeSetInfo,
        namespace_desc: Namespace,
    ) -> None:
        try:
            handler = VersionHandlerFactory.create_handler(
                nodeset_info.opc_ua_version, self.parser.strict_mode
            )
            handler.load_types(xml_root, namespace_desc)
            _logger.info(
                f"Successfully loaded types from {nodeset_info.file_path} "
                f"using OPC UA {nodeset_info.opc_ua_version} method"
            )
        except Exception as e:
            _logger.warning(
                f"XML parsing failed for {nodeset_info.file_path}, using fallback: {e}"
            )
            self._load_types_fallback(nodeset_info, namespace_desc)

    def _load_types_by_version(
        self, nodeset_info: NodeSetInfo, namespace_desc: Namespace
    ) -> None:
        try:
            tree = ET.parse(nodeset_info.file_path)
            xml_root = tree.getroot()
        except Exception as e:
            _logger.warning(
                f"XML parsing failed for {nodeset_info.file_path}, using fallback: {e}"
            )
            self._load_types_fallback(nodeset_info, namespace_desc)
            return
        self._load_types_from_xml_root(xml_root, nodeset_info, namespace_desc)

    def _load_types_fallback(
        self, nodeset_info: NodeSetInfo, namespace_desc: Namespace
    ) -> None:
        namespace_desc._add_structure_description(
            "i=0",
            "0:MockStruct",
            {
                "structure_type": 0,
                "fields": [
                    {
                        "name": f"Field1_{namespace_desc.metadata.short_name}",
                        "description": f"Mock field from {nodeset_info.file_path}",
                        "is_optional": False,
                        "value_rank": -1,
                    }
                ],
            },
        )
        namespace_desc._add_enum_description(
            "i=0",
            "0:MockEnum",
            {
                "fields": [
                    {"name": "Value1", "value": 0, "description": "First value"},
                    {"name": "Value2", "value": 1, "description": "Second value"},
                ],
            },
        )
        _logger.info(f"Used fallback mock loading for {nodeset_info.file_path}")
