from __future__ import annotations
from typing import Any, Optional, TYPE_CHECKING

import o6
from o6 import MaybeAwaitable, HasNodeId, NodeIdLike, AttributeId

if TYPE_CHECKING:
    from o6.client import Client

def _node_from_node_class(
    client: Client, nodeid: NodeIdLike, node_class: o6.NodeClass
) -> Node: ...

class Node(HasNodeId):
    _client: Client
    _nodeid: o6.NodeId
    _node_class: o6.NodeClass

    def __init__(
        self, client: Client, node_class: o6.NodeClass, nodeid: NodeIdLike
    ) -> None: ...
    def __call__(
        self,
        value: Optional[Any] = None,
        attr: Optional[AttributeId | str] = None,
    ) -> MaybeAwaitable[Any]: ...
    def __getattr__(self, name: str) -> Node | AwaitableNode: ...
    def __getitem__(self, key: str | o6.RelativePath) -> MaybeAwaitable[list[Any]]: ...

class AwaitableNode:
    """Supports chaining __getattr__ without intermediate awaits.

    Example::

        var = await client.root.objects.myfolder.myvariable
    """

    def __init__(self, client: Client, awaitable: Any) -> None: ...
    def __await__(self) -> Any: ...
    def __getattr__(self, name: str) -> AwaitableNode: ...
    def __call__(self, *args: Any, **kwargs: Any) -> AwaitableNode: ...

class ObjectNode(Node): ...

class VariableNode(Node):
    def __call__(
        self,
        value: Optional[Any] = None,
        attr: Optional[AttributeId | str] = None,
    ) -> MaybeAwaitable[Any]: ...

class VariableTypeNode(Node):
    def __call__(
        self,
        value: Optional[Any] = None,
        attr: Optional[AttributeId | str] = None,
    ) -> MaybeAwaitable[Any]: ...

class MethodNode(Node):
    _default_object: o6.NodeId

    def __call__(
        self,
        *args: Any,
        object_id: Optional[o6.NodeId] = None,
        attr: Optional[AttributeId | str] = None,
        value: Optional[Any] = None,
    ) -> MaybeAwaitable[Any]: ...

class ObjectTypeNode(Node): ...
class ReferenceTypeNode(Node): ...
class DataTypeNode(Node): ...
class ViewNode(Node): ...
