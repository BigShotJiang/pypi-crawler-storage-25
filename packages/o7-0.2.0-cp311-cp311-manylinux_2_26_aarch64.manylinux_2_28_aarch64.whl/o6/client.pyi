from __future__ import annotations
from typing import Any, Awaitable, Callable, Self, TypeAlias
from types import TracebackType
import asyncio
import datetime
import logging
import weakref

from . import _o6
import o6
import o6.client_nodes as nodes
from o6 import MaybeAwaitable, AwaitReturn, Future, NodeIdLike

from pathlib import Path

class Client(_o6.Client):
    """
    High-level OPC UA Client.

    Provides a pythonic interface for connecting to OPC UA servers and performing
    read, write, browse, and subscription operations.

    Examples:
        # Context manager usage (recommended)
        with Client("opc.tcp://localhost:4840") as client:
            value = client.read("ns=1;s=Temperature")
            client.write("ns=1;s=SetPoint", 25.0)
    """

    config: _o6.ClientConfig
    ns: o6.namespaces.Namespaces

    def __init__(
        self,
        endpoint_url: str | None = None,
        logger: logging.Logger | None = None,
        loop: asyncio.AbstractEventLoop | None = None,
        *,
        certificate: str | Path | bytes | None = None,
        private_key: str | Path | bytes | None = None,
        trust_list: list[str | Path | bytes] | None = None,
        revocation_list: list[str | Path | bytes] | None = None,
        security_mode: int | None = None,
        security_policy: str | None = None,
        application_uri: str | None = None,
        endpoint: o6.EndpointDescription | None = None,
        session_name: str | None = None,
        requested_session_timeout: int | None = None,
        session_locale_ids: list[str] | None = None,
    ) -> None: ...
    def _maybe_async(self, aw: Awaitable[Any]) -> MaybeAwaitable[Any]: ...
    @property
    def state(self) -> tuple[int, int, o6.StatusCode]:
        """Return (channel_state, session_state, connect_status)."""
        ...

    @property
    def connected(self) -> bool:
        """Test if the client is connected; partially connected also returns True."""
        ...

    @property
    def fully_connected(self) -> bool:
        """Test if a client has both SecureChannel and Session connected."""
        ...

    def connect(
        self,
        endpoint_url: str | None = None,
        username: str | None = None,
        password: str | None = None,
    ) -> Any: ...
    def disconnect(self) -> Any: ...
    def connect_secure_channel(self, endpoint_url: str | None = None) -> Any: ...
    def disconnect_secure_channel(self) -> Any: ...
    def start_reverse_connect(
        self, port: int, hostnames: list[str] | None = None
    ) -> Any: ...
    def activate_current_session(self) -> Any: ...
    def activate_session(self, auth_token: o6.NodeId, server_nonce: bytes) -> Any: ...
    def __enter__(self) -> Self: ...
    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None: ...
    async def __aenter__(self) -> Self: ...
    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None: ...

    # Default nodes as entry-points
    @property
    def root(self) -> MaybeAwaitable[nodes.Node]:
        """The OPC UA Root folder node (i=84)."""
        ...

    @property
    def objects(self) -> MaybeAwaitable[nodes.Node]:
        """The Objects folder node (i=85)."""
        ...

    @property
    def types(self) -> MaybeAwaitable[nodes.Node]:
        """The Types folder node (i=86)."""
        ...

    @property
    def views(self) -> MaybeAwaitable[nodes.Node]:
        """The Views folder node (i=87)."""
        ...
    #
    # Raw Service API
    #

    # Discovery Service Set

    def service_find_servers(
        self, request: o6.FindServersRequest
    ) -> MaybeAwaitable[o6.FindServersResponse]: ...
    def service_find_servers_on_network(
        self, request: o6.FindServersOnNetworkRequest
    ) -> MaybeAwaitable[o6.FindServersOnNetworkResponse]: ...
    def service_get_endpoints(
        self, request: o6.GetEndpointsRequest
    ) -> MaybeAwaitable[o6.GetEndpointsResponse]: ...

    # NodeManagement Service Set

    def service_add_nodes(
        self, request: o6.AddNodesRequest
    ) -> MaybeAwaitable[o6.AddNodesResponse]: ...
    def service_delete_nodes(
        self, request: o6.DeleteNodesRequest
    ) -> MaybeAwaitable[o6.DeleteNodesResponse]: ...
    def service_add_references(
        self, request: o6.AddReferencesRequest
    ) -> MaybeAwaitable[o6.AddReferencesResponse]: ...
    def service_delete_references(
        self, request: o6.DeleteReferencesRequest
    ) -> MaybeAwaitable[o6.DeleteReferencesResponse]: ...

    # View Service Set

    def service_browse(
        self, request: o6.BrowseRequest
    ) -> MaybeAwaitable[o6.BrowseResponse]: ...
    def service_browse_next(
        self, request: o6.BrowseNextRequest
    ) -> MaybeAwaitable[o6.BrowseNextResponse]: ...
    def service_translate_browse_paths_to_nodeids(
        self, request: o6.TranslateBrowsePathsToNodeIdsRequest
    ) -> MaybeAwaitable[o6.TranslateBrowsePathsToNodeIdsResponse]: ...
    def service_register_nodes(
        self, request: o6.RegisterNodesRequest
    ) -> MaybeAwaitable[o6.RegisterNodesResponse]: ...
    def service_unregister_nodes(
        self, request: o6.UnregisterNodesRequest
    ) -> MaybeAwaitable[o6.UnregisterNodesResponse]: ...

    # Attribute Service Set

    def service_read(
        self, request: o6.ReadRequest
    ) -> MaybeAwaitable[o6.ReadResponse]: ...
    def service_history_read(
        self, request: o6.HistoryReadRequest
    ) -> MaybeAwaitable[o6.HistoryReadResponse]: ...
    def service_write(
        self, request: o6.WriteRequest
    ) -> MaybeAwaitable[o6.WriteResponse]: ...
    def service_history_update(
        self, request: o6.HistoryUpdateRequest
    ) -> MaybeAwaitable[o6.HistoryUpdateResponse]: ...

    # Method Service Set

    def service_call(
        self, request: o6.CallRequest
    ) -> MaybeAwaitable[o6.CallResponse]: ...

    # DataType Utilities
    def get_remote_data_types(
        self, type_nodes: list[NodeIdLike] | None = None
    ) -> MaybeAwaitable[list[dict[str, Any]]]: ...

    # Discovery
    def get_endpoints(
        self,
        server_url: str,
        locale_ids: list[str] | None = None,
        profile_uris: list[str] | None = None,
    ) -> Any:
        """Get a list of endpoints of a server.

        Returns a list of ``EndpointDescription`` objects.
        """
        ...

    def find_servers(
        self,
        server_url: str,
        server_uris: list[str] | None = None,
        locale_ids: list[str] | None = None,
    ) -> Any:
        """Get a list of all registered servers at the given server.

        Returns a list of ``ApplicationDescription`` objects.
        """
        ...

    def find_servers_on_network(
        self,
        starting_record_id: int = 0,
        max_records_to_return: int = 0,
        server_capability_filter: list[str] | None = None,
    ) -> Any:
        """Get a list of all known servers on the network (LDS only).

        Returns a list of ``ServerOnNetwork`` objects.
        """
        ...

    def read(
        self,
        target: NodeIdLike | list[NodeIdLike],
        attribute_id: o6.AttributeId = ...,
        timestamps_to_return: int | None = None,
        as_datavalue: bool = False,
    ) -> Any: ...
    def write(
        self,
        target: NodeIdLike | dict[NodeIdLike, Any],
        value: Any | None = None,
        attribute_id: o6.AttributeId = ...,
    ) -> MaybeAwaitable[o6.StatusCode | list[o6.StatusCode]]: ...
    def call(
        self,
        object_id: NodeIdLike,
        method_id: NodeIdLike,
        input_args: list[Any] = ...,
    ) -> MaybeAwaitable[tuple[o6.StatusCode, ...]]: ...
    def browse(
        self,
        target: NodeIdLike,
        direction: o6.BrowseDirection = ...,
        reftype: NodeIdLike = ...,
        refsubtypes: bool = True,
        nodeclass_mask: o6.NodeClass = ...,
        result_mask: o6.BrowseResultMask = ...,
    ) -> MaybeAwaitable[list[o6.ReferenceDescription]]: ...

    # History Access
    def history_read(
        self,
        target: NodeIdLike | list[NodeIdLike],
        start_time: datetime.datetime,
        end_time: datetime.datetime,
        num_values_per_node: int = 0,
        return_bounds: bool = False,
        timestamps_to_return: o6.TimestampsToReturn = ...,
    ) -> Any: ...
    def history_read_modified(
        self,
        target: NodeIdLike | list[NodeIdLike],
        start_time: datetime.datetime,
        end_time: datetime.datetime,
        num_values_per_node: int = 0,
        return_bounds: bool = False,
        timestamps_to_return: o6.TimestampsToReturn = ...,
    ) -> Any: ...
    def history_read_at_time(
        self,
        target: NodeIdLike | list[NodeIdLike],
        timestamps: list[datetime.datetime],
        use_simple_bounds: bool = False,
    ) -> Any: ...
    def history_read_processed(
        self,
        target: NodeIdLike | list[NodeIdLike],
        start_time: datetime.datetime,
        end_time: datetime.datetime,
        processing_interval: float,
        aggregate_type: NodeIdLike = ...,
    ) -> Any: ...
    def history_update(
        self,
        target: NodeIdLike,
        values: list[o6.DataValue],
        mode: o6.PerformUpdateType = ...,
    ) -> Any: ...
    def history_delete(
        self,
        target: NodeIdLike,
        start_time: datetime.datetime,
        end_time: datetime.datetime,
    ) -> Any: ...

    # Node management
    def add_node(
        self,
        parent_nodeid: NodeIdLike,
        browse_name: o6.QualifiedName | str,
        node_class: o6.NodeClass,
        node_attributes: Any,
        requested_new_nodeid: NodeIdLike | None,
        reference_type_id: NodeIdLike,
        type_definition: NodeIdLike | None = None,
    ) -> MaybeAwaitable[o6.NodeId]: ...
    def add_variable_node(
        self,
        parent_nodeid: NodeIdLike,
        browse_name: o6.QualifiedName | str,
        node_attributes: o6.VariableAttributes,
        requested_new_nodeid: NodeIdLike | None = None,
        reference_type_id: NodeIdLike = ...,
        type_definition: NodeIdLike = ...,
    ) -> MaybeAwaitable[o6.NodeId]: ...
    def add_variable_type_node(
        self,
        parent_nodeid: NodeIdLike,
        browse_name: o6.QualifiedName | str,
        node_attributes: o6.VariableTypeAttributes,
        requested_new_nodeid: NodeIdLike | None = None,
        reference_type_id: NodeIdLike = ...,
    ) -> MaybeAwaitable[o6.NodeId]: ...
    def add_object_node(
        self,
        parent_nodeid: NodeIdLike,
        browse_name: o6.QualifiedName | str,
        node_attributes: o6.ObjectAttributes,
        requested_new_nodeid: NodeIdLike | None = None,
        reference_type_id: NodeIdLike = ...,
        type_definition: NodeIdLike = ...,
    ) -> MaybeAwaitable[o6.NodeId]: ...
    def add_object_type_node(
        self,
        parent_nodeid: NodeIdLike,
        browse_name: o6.QualifiedName | str,
        node_attributes: o6.ObjectTypeAttributes,
        requested_new_nodeid: NodeIdLike | None = None,
        reference_type_id: NodeIdLike = ...,
    ) -> MaybeAwaitable[o6.NodeId]: ...
    def add_view_node(
        self,
        parent_nodeid: NodeIdLike,
        browse_name: o6.QualifiedName | str,
        node_attributes: o6.ViewAttributes,
        requested_new_nodeid: NodeIdLike | None = None,
        reference_type_id: NodeIdLike = ...,
    ) -> MaybeAwaitable[o6.NodeId]: ...
    def add_reference_type_node(
        self,
        parent_nodeid: NodeIdLike,
        browse_name: o6.QualifiedName | str,
        node_attributes: o6.ReferenceTypeAttributes,
        requested_new_nodeid: NodeIdLike | None = None,
        reference_type_id: NodeIdLike = ...,
    ) -> MaybeAwaitable[o6.NodeId]: ...
    def add_data_type_node(
        self,
        parent_nodeid: NodeIdLike,
        browse_name: o6.QualifiedName | str,
        node_attributes: o6.DataTypeAttributes,
        requested_new_nodeid: NodeIdLike | None = None,
        reference_type_id: NodeIdLike = ...,
    ) -> MaybeAwaitable[o6.NodeId]: ...
    def add_method_node(
        self,
        parent_nodeid: NodeIdLike,
        browse_name: o6.QualifiedName | str,
        node_attributes: o6.MethodAttributes,
        requested_new_nodeid: NodeIdLike | None = None,
        reference_type_id: NodeIdLike = ...,
    ) -> MaybeAwaitable[o6.NodeId]: ...
    def delete_node(
        self,
        nodeid: NodeIdLike | list[NodeIdLike],
        delete_target_references: bool = True,
    ) -> MaybeAwaitable[None]: ...
    def add_reference(
        self,
        source_nodeid: NodeIdLike,
        reference_type_id: NodeIdLike,
        target_nodeid: NodeIdLike,
        is_forward: bool = True,
        target_node_class: o6.NodeClass = ...,
        target_server_uri: str = "",
    ) -> MaybeAwaitable[None]: ...
    def delete_reference(
        self,
        source_nodeid: NodeIdLike,
        reference_type_id: NodeIdLike,
        target_nodeid: NodeIdLike,
        is_forward: bool = True,
        delete_bidirectional: bool = True,
    ) -> MaybeAwaitable[None]: ...
    def __getitem__(self, key: NodeIdLike) -> MaybeAwaitable[nodes.Node]: ...
    def create_subscription(
        self,
        req: o6.CreateSubscriptionRequest | None = None,
        publishing_interval: float = 100.0,
        lifetime_count: int = 36000,
        max_keepalive_count: int = 10,
    ) -> MaybeAwaitable[Subscription]: ...
    def monitor(
        self,
        target: NodeIdLike | list[NodeIdLike],
        callback: MonitoredItem.DataChangeCallback | None = None,
        sampling_interval: float = 100.0,
        subscription: Subscription | None = None,
        context: Any = None,
    ) -> MaybeAwaitable[MonitoredItem | list[MonitoredItem]]: ...
    def monitor_event(
        self,
        nodeid: NodeIdLike,
        callback: MonitoredItem.EventCallback,
        event_filter: o6.EventFilter | str | None = None,
        subscription: Subscription | None = None,
        sampling_interval: float = 0.0,
        context: Any = None,
    ) -> MaybeAwaitable[MonitoredItem]: ...
    @property
    def subscriptions(self) -> dict[int, Subscription]: ...
    @property
    def default_subscription(self) -> Subscription: ...

class Subscription:
    """Represents an OPC UA subscription for monitoring data changes."""

    def __init__(
        self,
        client: Client,
        publishing_interval: float,
        lifetime_count: int,
        max_keepalive_count: int,
        max_notifications_per_publish: int = 10,
        publishing_enabled: bool = True,
    ) -> None: ...
    def __await__(self) -> AwaitReturn[Subscription]: ...
    def __bool__(self) -> bool: ...
    def monitor(
        self,
        nodeid: NodeIdLike,
        callback: MonitoredItem.DataChangeCallback | None = None,
        sampling_interval: float = 100.0,
        context: Any = None,
    ) -> MaybeAwaitable[MonitoredItem]: ...
    def monitor_event(
        self,
        nodeid: NodeIdLike,
        callback: MonitoredItem.EventCallback,
        event_filter: o6.EventFilter | str | None = None,
        sampling_interval: float = 0.0,
        context: Any = None,
    ) -> MaybeAwaitable[MonitoredItem]: ...
    def delete(self) -> Any: ...
    def modify(
        self,
        publishing_interval: float | None = None,
        lifetime_count: int | None = None,
        max_keepalive_count: int | None = None,
        max_notifications_per_publish: int | None = None,
        publishing_enabled: bool | None = None,
    ) -> Any: ...
    @property
    def client(self) -> Client: ...
    @property
    def subscription_id(self) -> int | None: ...
    @property
    def monitored_items(self) -> dict[int, MonitoredItem]: ...
    @property
    def publishing_interval(self) -> float: ...
    @property
    def lifetime_count(self) -> int: ...
    @property
    def max_keepalive_count(self) -> int: ...
    @property
    def max_notifications_per_publish(self) -> int: ...
    @property
    def publishing_enabled(self) -> bool: ...

class MonitoredItem:
    """Represents a monitored item within a subscription."""

    context: Any

    DataChangeCallback: TypeAlias = (
        Callable[[Any], None] | Callable[[MonitoredItem, Any], None]
    )
    EventCallback: TypeAlias = (
        Callable[[dict], None] | Callable[[MonitoredItem, dict], None]
    )

    def __init__(self, subscription: Subscription) -> None: ...
    @classmethod
    def data_change(
        cls,
        subscription: Subscription,
        nodeid: NodeIdLike,
        callback: MonitoredItem.DataChangeCallback,
        attribute_id: o6.AttributeId = ...,
        index_range: str = "",
        data_encoding: o6.QualifiedName | str = "",
        sampling_interval: float = 250.0,
        context: Any = None,
    ) -> MonitoredItem: ...
    @classmethod
    def event(
        cls,
        subscription: Subscription,
        nodeid: NodeIdLike,
        callback: MonitoredItem.EventCallback,
        event_filter: o6.EventFilter | str | None = None,
        sampling_interval: float = 0.0,
        context: Any = None,
    ) -> MonitoredItem: ...
    def __await__(self) -> AwaitReturn[MonitoredItem]: ...
    def __bool__(self) -> bool: ...
    def delete(self) -> Any: ...
    def modify(
        self,
        sampling_interval: float | None = None,
        queue_size: int | None = None,
        discard_oldest: bool | None = None,
        filter: o6.DataChangeFilter | o6.EventFilter | str | None = None,
    ) -> Any: ...
    def set_monitoring_mode(self, mode: o6.MonitoringMode) -> Any: ...
    def set_triggering(
        self,
        links_to_add: list[MonitoredItem] | None = None,
        links_to_remove: list[MonitoredItem] | None = None,
    ) -> Any: ...
    @property
    def client(self) -> Client: ...
    @property
    def subscription(self) -> Subscription: ...
    @property
    def item_to_monitor(self) -> o6.ReadValueId: ...
    @property
    def monitoring_params(self) -> o6.MonitoringParameters: ...
    @property
    def monitoring_mode(self) -> o6.MonitoringMode: ...
    @property
    def monitored_item_id(self) -> int | None: ...
