from types import SimpleNamespace
from typing import List, Dict, Optional, Any, Union, TYPE_CHECKING

if TYPE_CHECKING:
    import o6

class DescriptorMetadata:
    uri: str
    version: str
    publication_date: Optional[str]
    short_name: str
    namespace_index: int | None
    namespace_uris: List[str]

class Namespace:
    metadata: DescriptorMetadata
    _required_namespaces: List[Dict[str, str]]
    _structure_descriptions: List[Any]
    _enum_descriptions: List[Any]
    _alias_types: List[Dict[str, Any]]
    types: SimpleNamespace
    _capsule: list[Any] | None
    _canonical_ns_table: Dict[str, int]
    _original_nodeids: tuple[list[tuple[str, str | None, list[str]]], list[str]] | None

    def __init__(
        self, uri: str, version: str = "", publication_date: Optional[str] = None
    ) -> None: ...
    def __dir__(self) -> list[str]: ...
    def _copy_for_rebuild(self) -> Namespace:
        """Create a shallow copy suitable for rebuilding types with different
        namespace indices.  Copies metadata and original NodeIds but not
        built capsules or types."""
        ...

    def _extract_short_name(self, uri: str) -> str:
        """
        Extract a short name from the namespace URI.

        Examples:
        - "http://opcfoundation.org/UA/" -> "UA"
        - "http://example.com/MyModel/v1.0" -> "v1.0"
        - "urn:example:mymodel" -> "mymodel"
        """
        ...

    def _add_required_namespace(self, uri: str, version: str = "") -> None:
        """Add a required namespace dependency."""
        ...

    def _add_alias_type(self, nodeid: Any, base_type_nodeid: Any) -> None:
        """Add an alias type definition."""
        ...

    def _add_structure_description(
        self,
        nodeid: str,
        browse_name: str,
        struct_data: Dict[str, Any] | o6.StructureDefinition,
        default_encoding_id: str | None = None,
    ) -> None: ...
    def _add_enum_description(
        self,
        nodeid: str,
        browse_name: str,
        enum_data: Dict[str, Any] | o6.EnumDefinition,
    ) -> None: ...
    def _get_type_summary(self) -> Dict[str, Any]: ...
    def _validate(self) -> List[str]: ...
    def _to_dict(self) -> Dict[str, Any]: ...
    def __str__(self) -> str: ...
    def __repr__(self) -> str: ...
