"""
OPC UA Version-specific Type Loading Handlers

This module contains specialized handlers for loading types from different
OPC UA versions, each with their own parsing strategies and requirements.
"""

from typing import List, Dict, Optional, Any, Union
import xml.etree.ElementTree as ET
import logging
from abc import ABC, abstractmethod

from .namespace import Namespace

_logger = logging.getLogger(__name__)

NS = "{http://opcfoundation.org/UA/2011/03/UANodeSet.xsd}"

# ns0 DataType NodeIds that are not registered as concrete types in open62541
# and must be resolved to their nearest concrete ancestor before building.
_NS0_UNRESOLVABLE_SUBTYPES: Dict[str, str] = {
    "i=26": "i=24",  # Number -> Variant (abstract)
    "i=27": "i=24",  # Integer -> Variant (abstract)
    "i=28": "i=24",  # UInteger -> Variant (abstract)
    "i=30": "i=15",  # Image -> ByteString
    "i=50": "i=24",  # Decimal -> Variant (abstract)
    "i=25726": "i=12",  # EncodedTicket -> String
    "i=31917": "i=7",  # Handle -> UInt32
    "i=31918": "i=12",  # TrimmedString -> String
}


def _build_subtype_map(xml_root: ET.Element) -> Dict[str, str]:
    subtype_map: Dict[str, str] = {}
    for dt in xml_root.findall(f".//{NS}UADataType"):
        if (
            dt.find(f".//{NS}StructureDefinition") is not None
            or dt.find(f".//{NS}EnumDefinition") is not None
            or dt.find(f"{NS}Definition") is not None
            or dt.find(f"{NS}DataTypeDefinition") is not None
        ):
            continue
        nodeid = dt.get("NodeId", "")
        refs = dt.find(f"{NS}References")
        if refs is None:
            continue
        for ref in refs.findall(f"{NS}Reference"):
            if (
                ref.get("ReferenceType") == "HasSubtype"
                and ref.get("IsForward", "true") == "false"
                and ref.text
            ):
                subtype_map[nodeid] = ref.text.strip()
                break
    return subtype_map


def _resolve_field_data_type(data_type: str, subtype_map: Dict[str, str]) -> str:
    visited: set[str] = set()
    current = data_type
    while current not in visited:
        if current in subtype_map:
            visited.add(current)
            current = subtype_map[current]
        elif current in _NS0_UNRESOLVABLE_SUBTYPES:
            visited.add(current)
            current = _NS0_UNRESOLVABLE_SUBTYPES[current]
        else:
            break
    return current


def _get_nodeid(datatype: ET.Element) -> str:
    return datatype.get("NodeId", "")


def _get_browse_name(datatype: ET.Element) -> str:
    return datatype.get("BrowseName", "")


class BaseVersionHandler(ABC):

    def __init__(self, strict_mode: bool = True):
        self.strict_mode = strict_mode
        self._desc: Namespace = None  # type: ignore[assignment]  # set by load_types() before any parse helper is called

    @abstractmethod
    def load_types(self, xml_root: ET.Element, namespace_desc: Namespace) -> None:
        pass

    @abstractmethod
    def get_supported_versions(self) -> List[str]:
        pass


class OpcUaV103Handler(BaseVersionHandler):

    def get_supported_versions(self) -> List[str]:
        return ["1.00", "1.01", "1.02", "1.03"]

    def load_types(self, xml_root: ET.Element, namespace_desc: Namespace) -> None:
        self._desc = namespace_desc
        try:
            self._load_datatypes_v103(xml_root)
            _logger.info(
                f"Loaded {len(namespace_desc._structure_descriptions)} structures and "
                f"{len(namespace_desc._enum_descriptions)} enums using v1.03 method"
            )
        except Exception as e:
            error_msg = f"Error loading types with v1.03 handler: {e}"
            _logger.error(error_msg)
            if self.strict_mode:
                raise RuntimeError(error_msg)

    def _load_datatypes_v103(self, xml_root: ET.Element) -> None:
        for datatype in xml_root.findall(f".//{NS}UADataType"):
            try:
                definition = datatype.find(f"{NS}DataTypeDefinition")
                if definition is not None:
                    self._parse_datatype_definition_v103(definition, datatype)
            except Exception as e:
                _logger.warning(f"Failed to load DataType in v1.03 mode: {e}")
                if self.strict_mode:
                    raise

    def _parse_datatype_definition_v103(
        self, definition: ET.Element, datatype: ET.Element
    ) -> None:
        nodeid = _get_nodeid(datatype)
        browse_name = _get_browse_name(datatype)

        if definition.find(f".//{NS}Field") is not None:
            self._parse_structure_v103(definition, nodeid, browse_name)
        elif definition.find(f".//{NS}EnumField") is not None:
            self._parse_enumeration_v103(definition, nodeid, browse_name)

    def _parse_structure_v103(
        self, definition: ET.Element, nodeid: str, browse_name: str
    ) -> None:
        fields = []
        for f in definition.findall(f".//{NS}Field"):
            fields.append(
                {
                    "name": f.get("Name", "UnknownField"),
                    "description": f.get("Description", ""),
                    "is_optional": f.get("IsOptional", "false").lower() == "true",
                    "value_rank": int(f.get("ValueRank", "-1")),
                    "data_type": f.get("DataType", "i=24"),
                }
            )
        if fields:
            self._desc._add_structure_description(
                nodeid, browse_name, {"structure_type": 0, "fields": fields}
            )

    def _parse_enumeration_v103(
        self, definition: ET.Element, nodeid: str, browse_name: str
    ) -> None:
        fields = []
        for f in definition.findall(f".//{NS}EnumField"):
            fields.append(
                {
                    "name": f.get("Name", "UnknownValue"),
                    "value": int(f.get("Value", "0")),
                    "description": f.get("Description", ""),
                    "display_name": f.get("DisplayName", f.get("Name", "")),
                }
            )
        if fields:
            self._desc._add_enum_description(nodeid, browse_name, {"fields": fields})


class OpcUaV104Handler(BaseVersionHandler):

    def get_supported_versions(self) -> List[str]:
        return ["1.04"]

    def load_types(self, xml_root: ET.Element, namespace_desc: Namespace) -> None:
        self._desc = namespace_desc
        try:
            self._alias_map = self._build_alias_map(xml_root)
            self._binary_encoding_map = self._build_binary_encoding_map(xml_root)
            self._subtype_map = _build_subtype_map(xml_root)
            self._load_ua_datatypes(xml_root)
            _logger.info(
                f"Loaded {len(namespace_desc._structure_descriptions)} structures and "
                f"{len(namespace_desc._enum_descriptions)} enums using v1.04 method"
            )
        except Exception as e:
            error_msg = f"Error loading types with v1.04 handler: {e}"
            _logger.error(error_msg)
            if self.strict_mode:
                raise RuntimeError(error_msg)

    @staticmethod
    def _build_alias_map(xml_root: ET.Element) -> Dict[str, str]:
        alias_map: Dict[str, str] = {}
        for alias in xml_root.findall(f".//{NS}Alias"):
            name = alias.get("Alias", "")
            if name and alias.text:
                alias_map[name] = alias.text.strip()
        return alias_map

    def _resolve_alias(self, value: str) -> str:
        return self._alias_map.get(value, value)

    def _resolve_field_dt(self, value: str) -> str:
        resolved = self._resolve_alias(value)
        return _resolve_field_data_type(resolved, getattr(self, "_subtype_map", {}))

    @staticmethod
    def _build_binary_encoding_map(xml_root: ET.Element) -> Dict[str, str]:
        encoding_map: Dict[str, str] = {}

        # Collect all "Default Binary" UAObject node IDs.
        default_binary_ids: set[str] = set()
        for obj in xml_root.findall(f".//{NS}UAObject"):
            if obj.get("BrowseName") != "Default Binary":
                continue
            obj_id = obj.get("NodeId", "")
            default_binary_ids.add(obj_id)

            # Path 1: reverse HasEncoding ref on the UAObject → data type.
            refs = obj.find(f"{NS}References")
            if refs is None:
                continue
            for ref in refs.findall(f"{NS}Reference"):
                if (
                    ref.get("ReferenceType") == "HasEncoding"
                    and ref.get("IsForward", "true") == "false"
                    and ref.text
                ):
                    encoding_map[ref.text.strip()] = obj_id

        # Path 2: forward HasEncoding ref on the UADataType → encoding object.
        # Some nodesets only express the relationship in this direction.
        for dt in xml_root.findall(f".//{NS}UADataType"):
            dt_id = dt.get("NodeId", "")
            if dt_id in encoding_map:
                continue
            refs = dt.find(f"{NS}References")
            if refs is None:
                continue
            for ref in refs.findall(f"{NS}Reference"):
                if (
                    ref.get("ReferenceType") == "HasEncoding"
                    and ref.get("IsForward", "true") == "true"
                    and ref.text
                ):
                    target = ref.text.strip()
                    if target in default_binary_ids:
                        encoding_map[dt_id] = target
                        break

        return encoding_map

    def _load_ua_datatypes(self, xml_root: ET.Element) -> None:
        for datatype in xml_root.findall(f".//{NS}UADataType"):
            nodeid = _get_nodeid(datatype)
            browse_name = _get_browse_name(datatype)
            try:
                self._parse_ua_datatype(datatype, nodeid, browse_name)
            except Exception as e:
                _logger.warning(f"Failed to load UADataType {browse_name}: {e}")
                if self.strict_mode:
                    raise

    def _parse_ua_datatype(
        self, datatype: ET.Element, nodeid: str, browse_name: str
    ) -> None:
        # Try v1.04 explicit StructureDefinition/EnumDefinition first
        struct_def = datatype.find(f".//{NS}StructureDefinition")
        if struct_def is not None:
            self._parse_structure_definition(struct_def, nodeid, browse_name)
            return

        enum_def = datatype.find(f".//{NS}EnumDefinition")
        if enum_def is not None:
            self._parse_enum_definition(enum_def, nodeid, browse_name)
            return

        # Try inline <Definition> (v1.04 compact form)
        definition = datatype.find(f"{NS}Definition")
        if definition is not None:
            self._parse_inline_definition(definition, nodeid, browse_name)
            return

        # Try legacy <DataTypeDefinition> (v1.03 compat)
        dt_def = datatype.find(f"{NS}DataTypeDefinition")
        if dt_def is not None:
            handler = OpcUaV103Handler(self.strict_mode)
            handler._desc = self._desc
            handler._parse_datatype_definition_v103(dt_def, datatype)

    def _parse_inline_definition(
        self, definition: ET.Element, nodeid: str, browse_name: str
    ) -> None:
        fields = list(definition.findall(f"{NS}Field"))
        if not fields:
            encoding_id = getattr(self, "_binary_encoding_map", {}).get(nodeid)
            self._desc._add_structure_description(
                nodeid,
                browse_name,
                {"structure_type": 0, "fields": []},
                default_encoding_id=encoding_id,
            )
            return

        first = fields[0]
        if "Value" in first.attrib and "DataType" not in first.attrib:
            enum_fields = [
                {
                    "name": f.get("Name", "UnknownValue"),
                    "value": int(f.get("Value", "0")),
                    "description": f.get("Description", ""),
                    "display_name": f.get("DisplayName", f.get("Name", "")),
                }
                for f in fields
            ]
            self._desc._add_enum_description(
                nodeid, browse_name, {"fields": enum_fields}
            )
        else:
            struct_fields = [
                {
                    "name": f.get("Name", "UnknownField"),
                    "description": f.get("Description", ""),
                    "is_optional": f.get("IsOptional", "false").lower() == "true",
                    "value_rank": int(f.get("ValueRank", "-1")),
                    "data_type": self._resolve_field_dt(f.get("DataType", "i=24")),
                }
                for f in fields
            ]
            has_optional = any(fd["is_optional"] for fd in struct_fields)
            self._desc._add_structure_description(
                nodeid,
                browse_name,
                {"structure_type": 1 if has_optional else 0, "fields": struct_fields},
                default_encoding_id=getattr(self, "_binary_encoding_map", {}).get(
                    nodeid
                ),
            )

    def _parse_structure_definition(
        self, struct_def: ET.Element, nodeid: str, browse_name: str
    ) -> None:
        struct_type = int(struct_def.get("StructureType", "0"))
        fields = []
        for f in struct_def.findall(f".//{NS}StructureField"):
            fields.append(
                {
                    "name": f.get("Name", "UnknownField"),
                    "description": f.get("Description", ""),
                    "is_optional": f.get("IsOptional", "false").lower() == "true",
                    "value_rank": int(f.get("ValueRank", "-1")),
                    "data_type": self._resolve_field_dt(f.get("DataType", "i=24")),
                    "array_dimensions": f.get("ArrayDimensions", ""),
                    "max_string_length": int(f.get("MaxStringLength", "0")),
                }
            )
        encoding_id = getattr(self, "_binary_encoding_map", {}).get(nodeid)
        self._desc._add_structure_description(
            nodeid,
            browse_name,
            {"structure_type": struct_type, "fields": fields},
            default_encoding_id=encoding_id,
        )

    def _parse_enum_definition(
        self, enum_def: ET.Element, nodeid: str, browse_name: str
    ) -> None:
        fields = []
        for f in enum_def.findall(f".//{NS}EnumField"):
            fields.append(
                {
                    "name": f.get("Name", "UnknownValue"),
                    "value": int(f.get("Value", "0")),
                    "description": f.get("Description", ""),
                    "display_name": f.get("DisplayName", f.get("Name", "")),
                }
            )
        if fields:
            self._desc._add_enum_description(nodeid, browse_name, {"fields": fields})


class OpcUaV105Handler(OpcUaV104Handler):

    def get_supported_versions(self) -> List[str]:
        return ["1.05"]

    def load_types(self, xml_root: ET.Element, namespace_desc: Namespace) -> None:
        self._desc = namespace_desc
        try:
            self._load_ua_datatypes(xml_root)
            self._load_union_definitions(xml_root)
            _logger.info(f"Loaded types using v1.05 method with union support")
        except Exception as e:
            error_msg = f"Error loading types with v1.05 handler: {e}"
            _logger.error(error_msg)
            if self.strict_mode:
                raise RuntimeError(error_msg)

    def _load_union_definitions(self, xml_root: ET.Element) -> None:
        for datatype in xml_root.findall(f".//{NS}UADataType"):
            union_def = datatype.find(f".//{NS}UnionDefinition")
            if union_def is None:
                continue
            nodeid = _get_nodeid(datatype)
            browse_name = _get_browse_name(datatype)
            try:
                self._parse_union_definition(union_def, nodeid, browse_name)
            except Exception as e:
                _logger.warning(f"Failed to load UnionDefinition in v1.05 mode: {e}")
                if self.strict_mode:
                    raise

    def _parse_union_definition(
        self, union_def: ET.Element, nodeid: str, browse_name: str
    ) -> None:
        fields = []
        for f in union_def.findall(f".//{NS}StructureField"):
            fields.append(
                {
                    "name": f.get("Name", "UnknownField"),
                    "description": f.get("Description", ""),
                    "is_optional": f.get("IsOptional", "false").lower() == "true",
                    "value_rank": int(f.get("ValueRank", "-1")),
                    "data_type": self._resolve_field_dt(f.get("DataType", "i=24")),
                    "array_dimensions": f.get("ArrayDimensions", ""),
                    "max_string_length": int(f.get("MaxStringLength", "0")),
                }
            )
        if fields:
            self._desc._add_structure_description(
                nodeid, browse_name, {"structure_type": 2, "fields": fields}
            )


class VersionHandlerFactory:
    """Factory for creating appropriate version handlers."""

    _handlers = {
        "1.03": OpcUaV103Handler,
        "1.04": OpcUaV104Handler,
        "1.05": OpcUaV105Handler,
    }

    @classmethod
    def create_handler(
        cls, version: str, strict_mode: bool = True
    ) -> BaseVersionHandler:
        """
        Create an appropriate handler for the given OPC UA version.

        Args:
            version: OPC UA version (e.g., "1.04", "1.05")
            strict_mode: Whether to use strict error handling

        Returns:
            Appropriate version handler instance
        """
        # Find the best matching handler
        for handler_version, handler_class in cls._handlers.items():
            if version.startswith(handler_version):
                return handler_class(strict_mode)  # type: ignore[abstract]

        # Default to highest supported version
        _logger.warning(
            f"No specific handler for version {version}, using v1.05 handler"
        )
        return OpcUaV105Handler(strict_mode)
