from translate_can import main
main()