from fastmcp import FastMCP
import json
mcp=FastMCP("Can协议格式转换")
class customformat():
    def __init__(self,data):
            if len(data:="".join(data.split(" ")))%2:data="0"+data
            self.data=data.lower()
            self.error=False
            self.check_data()
    def to_dec(self):
        return int(self.data,16)
    def to_oct(self):
        return oct(self.to_dec())[2:]
    def to_bin(self):
        if len(data:=bin(self.to_dec())[2:])%2:data="0"+data
        return data
    def to_list(self):
        return [self.data[x:x+2] for x in range(0,len(self.data),2)]
    def to_hex(self):
        #你问我这个干嘛用的？留着可能以后有人会拿来用什么的
        pass
    def check_data(self):
        try:
            int(self.data,16)
        except ValueError:
            self.error=True
class motorola(customformat):
    def __init__(self, data):
        super().__init__(data)
class intel(customformat):
    def __init__(self, data):
        super().__init__(data)
        self.data=self.to_reverse()
    def to_reverse(self):
        res=[self.data[x:x+2] for x in range(0,len(self.data),2)]
        res.reverse()
        return "".join(res)
    def to_list(self):
        nowlist=super().to_list()
        nowlist.reverse()
        return nowlist
@mcp.tool
def translate_can(data : str):
    '''转换相输入的CAN协议数值到指定格式，方便分析。输入格式为{"Canformat":"intel","data":"1E","to":"to_dec"},其中Canfomat字段仅允许intel（小端）或motorola（大端）协议，data的值只能为CAN数据（仅16进制），to字段只能为to_dec（转至十进制）、to_oct（转至八进制）、to_bin（转至二进制）、to_list（转至列表）。
    注：输入的数值是不应该是全部输入，而是输入要转换的值.如E4 62 44 34其中E4 62是Motorola格式，表示为十进制的某些数值。44 34为intel格式，其中为的Bit x～Bit x的值101为什么，那么该{"Canfomat":"motorola","data":"E4 62","to":"to_dec"}然后再输入{"Canfomat":"intel","data":"1E","to":"to_dec"}'''
    data=json.loads(data)
    Canfomat_dict={"motorola":motorola,"intel":intel}
    try:
        formatClass=Canfomat_dict[data["Canformat"]](data["data"])
        if formatClass.error: return "数值输入有误，检查一下是不是正确的Can数据"
        return getattr(formatClass,data["to"])()
    except KeyError:
        return "输入格式出现错误"
    except AttributeError:
        return "未能找到对应的方法"
'''def test():
    Canfomat=["intel","motorola","",None]
    data=["00","FF","FF FF f","creeper","AAAAAA","00000"]
    to=["to_dec","to_oct","to_bin","to_list","miao"]
    for t1 in Canfomat:
        print(f"目前测试：{t1}")
        for t2 in data:
            print(f"    目前测试：{t2}")
            for t3 in  to:
                print("         "+str(translate_can('{{"Canfomat":"{0}","data":"{1}","to":"{2}"}}'.format(t1,t2,t3))))'''
if __name__ == "__main__":
    mcp.run(transport="stdio")