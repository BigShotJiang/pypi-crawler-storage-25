import argparse
from .translate_can import mcp
def main():
    parser = argparse.ArgumentParser(
        description="It can enable AI to understand data in CAN protocol"
    )
    parser.parse_args()
    mcp.run()
if __name__ == "__main__":
    main()
