"""Compliance-aware wrapper around :class:`SemvecState`.

:class:`ComplianceState` *composes* :class:`SemvecState` (the
underlying Rust class is not subclassable from Python). Any attribute
that isn't event-store-specific delegates to the wrapped state via
``__getattr__``. With no store attached the wrapper is a transparent
passthrough; with a store attached, every successful ``update()``
also appends a :class:`MemoryEvent`.

Failed updates (dim mismatch, empty vector, isolation filter) do
**not** append. Bad input that raises stays bad input; only mutations
that actually changed the state get logged.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np

from semvec import SemvecState
from semvec.compliance.event_store import MemoryEvent

if TYPE_CHECKING:
    from semvec import SemvecConfig
    from semvec.compliance.event_store import EventStore


class ComplianceState:
    """Drop-in wrapper that mirrors every successful ``update()``
    into an :class:`EventStore`.

    Constructor args mirror :class:`SemvecState` plus three
    compliance-specific kwargs:

    * ``event_store`` — optional :class:`EventStore`. ``None`` makes
      the wrapper transparent.
    * ``user_id`` — tenant identifier written into every appended
      event. Required when ``event_store`` is set.
    * ``default_meta`` — dict folded into every appended event's
      ``meta`` field (e.g. ``{"channel": "chat"}``).
    """

    def __init__(
        self,
        config: SemvecConfig | None = None,
        *,
        _test_subject_override: str | None = None,
        event_store: EventStore | None = None,
        user_id: str | None = None,
        default_meta: dict[str, Any] | None = None,
    ) -> None:
        if event_store is not None and not user_id:
            raise ValueError("ComplianceState: user_id is required when event_store is set")
        self._state = SemvecState(
            config=config,
            _test_subject_override=_test_subject_override,
        )
        self._event_store = event_store
        self._user_id = user_id
        self._default_meta = dict(default_meta or {})

    # ------------------------------------------------------------------
    # The intercepting method
    def update(
        self,
        input_embedding,
        text: str,
        *,
        meta: dict[str, Any] | None = None,
    ):
        """Forward to the wrapped state, then append an event when
        a store is attached. Raised exceptions propagate unchanged
        and skip the append (no half-state in the log).

        ``meta`` is an optional per-call override that merges into
        ``self._default_meta``; matching keys are taken from the
        per-call dict (the call site is the more specific source).
        We copy the merged dict before storing it so a caller that
        re-uses the same kwarg dict for a follow-up update cannot
        retroactively mutate already-appended events.
        """
        result = self._state.update(input_embedding, text)
        store = self._event_store
        if store is None:
            return result
        if isinstance(input_embedding, np.ndarray):
            emb_list = input_embedding.astype(float).tolist()
        else:
            emb_list = [float(x) for x in input_embedding]
        merged_meta = dict(self._default_meta)
        if meta is not None:
            merged_meta.update(meta)
        store.append(
            MemoryEvent.fresh(
                user_id=self._user_id,
                content=text,
                embedding=emb_list,
                meta=merged_meta,
            )
        )
        return result

    # ------------------------------------------------------------------
    # Transparent forwarding for everything else
    def __getattr__(self, name: str) -> Any:
        # __getattr__ runs only when the name is not on the wrapper —
        # so the compliance-specific attrs above (set in __init__)
        # short-circuit before we land here.
        return getattr(self._state, name)


__all__ = ["ComplianceState"]
