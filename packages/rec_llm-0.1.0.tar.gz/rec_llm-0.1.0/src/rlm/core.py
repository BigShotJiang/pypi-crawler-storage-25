"""Core RLM implementation."""

import asyncio
import re
from typing import Optional, Dict, Any, List

import litellm

from .types import Message
from .repl import REPLExecutor, REPLError
from .prompts import build_system_prompt
from .parser import parse_response, is_final


class RLMError(Exception):
    """Base error for RLM."""
    pass


class MaxIterationsError(RLMError):
    """Max iterations exceeded."""
    pass


class MaxDepthError(RLMError):
    """Max recursion depth exceeded."""
    pass


class RateLimitExceededError(RLMError):
    """Rate limit exceeded after retries."""
    pass


class RLM:
    """Recursive Language Model."""

    def __init__(
        self,
        model: str,
        recursive_model: Optional[str] = None,
        api_base: Optional[str] = None,
        api_key: Optional[str] = None,
        max_depth: int = 5,
        max_iterations: int = 30,
        rate_limit_retries: int = 3,
        rate_limit_backoff_seconds: float = 5.0,
        _current_depth: int = 0,
        **llm_kwargs: Any
    ):
        """
        Initialize RLM.

        Args:
            model: Model name (e.g., "gpt-4o", "claude-sonnet-4", "ollama/llama3.2")
            recursive_model: Optional cheaper model for recursive calls
            api_base: Optional API base URL
            api_key: Optional API key
            max_depth: Maximum recursion depth
            max_iterations: Maximum REPL iterations per call
            rate_limit_retries: Number of retries for provider 429 responses
            rate_limit_backoff_seconds: Default wait between retries when no
                provider-specific delay is present
            _current_depth: Internal current depth tracker
            **llm_kwargs: Additional LiteLLM parameters
        """
        self.model = model
        self.recursive_model = recursive_model or model
        self.api_base = api_base
        self.api_key = api_key
        self.max_depth = max_depth
        self.max_iterations = max_iterations
        self.rate_limit_retries = rate_limit_retries
        self.rate_limit_backoff_seconds = rate_limit_backoff_seconds
        self._current_depth = _current_depth
        self.llm_kwargs = llm_kwargs

        self.repl = REPLExecutor()

        # Stats
        self._llm_calls = 0
        self._iterations = 0

    def complete(
        self,
        query: str = "",
        context: str = "",
        env: Optional[Dict[str, Any]] = None,
        system_prompt_extra: str = "",
        **kwargs: Any
    ) -> str:
        """
        Sync wrapper for acomplete.

        Args:
            query: User query (optional if query is in context)
            context: Context to process (optional, can pass query here)
            **kwargs: Additional LiteLLM parameters

        Returns:
            Final answer string

        Examples:
            # Standard usage
            rlm.complete(query="Summarize this", context=document)

            # Query in context (RLM will extract task)
            rlm.complete(context="Summarize this document: ...")

            # Single string (treat as context)
            rlm.complete("Process this text and extract dates")
        """
        # If only one argument provided, treat it as context
        if query and not context:
            context = query
            query = ""

        return asyncio.run(
            self.acomplete(
                query,
                context,
                env=env,
                system_prompt_extra=system_prompt_extra,
                **kwargs,
            )
        )

    async def acomplete(
        self,
        query: str = "",
        context: str = "",
        env: Optional[Dict[str, Any]] = None,
        system_prompt_extra: str = "",
        **kwargs: Any
    ) -> str:
        """
        Main async complete method.

        Args:
            query: User query (optional if query is in context)
            context: Context to process (optional, can pass query here)
            **kwargs: Additional LiteLLM parameters

        Returns:
            Final answer string

        Raises:
            MaxIterationsError: If max iterations exceeded
            MaxDepthError: If max recursion depth exceeded

        Examples:
            # Explicit query and context
            await rlm.acomplete(query="What is this?", context=doc)

            # Query embedded in context
            await rlm.acomplete(context="Extract all dates from: ...")

            # LLM will figure out the task
            await rlm.acomplete(context=document_with_instructions)
        """
        # If only query provided, treat it as context
        if query and not context:
            context = query
            query = ""
        if self._current_depth >= self.max_depth:
            raise MaxDepthError(f"Max recursion depth ({self.max_depth}) exceeded")

        # Initialize REPL environment
        repl_env = self._build_repl_env(query, context, env)

        # Build initial messages
        system_prompt = build_system_prompt(
            len(context),
            self._current_depth,
            extra_instructions=system_prompt_extra,
        )
        messages: List[Message] = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": query}
        ]

        # Main loop
        for iteration in range(self.max_iterations):
            self._iterations = iteration + 1

            # Call LLM
            response = await self._call_llm(messages, **kwargs)

            # Check for FINAL
            if is_final(response):
                answer = parse_response(response, repl_env)
                if answer is not None:
                    return answer

            # Execute code in REPL
            try:
                exec_result = self.repl.execute(response, repl_env)
            except REPLError as e:
                exec_result = f"Error: {str(e)}"
            except Exception as e:
                exec_result = f"Unexpected error: {str(e)}"

            # Add to conversation
            messages.append({"role": "assistant", "content": response})
            messages.append({"role": "user", "content": exec_result})

        raise MaxIterationsError(
            f"Max iterations ({self.max_iterations}) exceeded without FINAL()"
        )

    async def _call_llm(
        self,
        messages: List[Message],
        **kwargs: Any
    ) -> str:
        """
        Call LLM API.

        Args:
            messages: Conversation messages
            **kwargs: Additional parameters (can override model here)

        Returns:
            LLM response text
        """
        self._llm_calls += 1

        # Choose model based on depth
        default_model = self.model if self._current_depth == 0 else self.recursive_model

        # Allow override via kwargs
        model = kwargs.pop('model', default_model)

        # Merge kwargs
        call_kwargs = {**self.llm_kwargs, **kwargs}
        if self.api_base:
            call_kwargs['api_base'] = self.api_base
        if self.api_key:
            call_kwargs['api_key'] = self.api_key

        last_error: Optional[Exception] = None

        for attempt in range(self.rate_limit_retries + 1):
            try:
                response = await litellm.acompletion(
                    model=model,
                    messages=messages,
                    **call_kwargs
                )
                return response.choices[0].message.content
            except Exception as e:
                last_error = e
                if not self._is_rate_limit_error(e) or attempt >= self.rate_limit_retries:
                    break

                retry_after = self._extract_retry_after_seconds(str(e))
                await asyncio.sleep(retry_after)

        if last_error is not None and self._is_rate_limit_error(last_error):
            raise RateLimitExceededError(
                "Rate limit exceeded after retries. "
                "Wait for the provider window to reset, reduce token usage, "
                "or use a higher-capacity model/tier."
            ) from last_error

        if last_error is not None:
            raise last_error

        raise RLMError("LLM call failed without returning a response")

    def _build_repl_env(
        self,
        query: str,
        context: str,
        extra_env: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Build REPL environment.

        Args:
            query: User query
            context: Context string

        Returns:
            Environment dict
        """
        env: Dict[str, Any] = {
            'context': context,
            'query': query,
            'recursive_llm': self._make_recursive_fn(),
            're': re,  # Whitelist re module
        }

        if extra_env:
            reserved = {'context', 'query', 'recursive_llm', 're'}
            overlapping = reserved.intersection(extra_env)
            if overlapping:
                overlap_list = ", ".join(sorted(overlapping))
                raise ValueError(
                    f"Reserved REPL env keys cannot be overridden: {overlap_list}"
                )
            env.update(extra_env)

        return env

    def _make_recursive_fn(self) -> Any:
        """
        Create recursive LLM function for REPL.

        Returns:
            Async function that can be called from REPL
        """
        async def recursive_llm(sub_query: str, sub_context: str) -> str:
            """
            Recursively process sub-context.

            Args:
                sub_query: Query for sub-context
                sub_context: Sub-context to process

            Returns:
                Answer from recursive call
            """
            if self._current_depth + 1 >= self.max_depth:
                return f"Max recursion depth ({self.max_depth}) reached"

            # Create sub-RLM with increased depth
            sub_rlm = RLM(
                model=self.recursive_model,
                recursive_model=self.recursive_model,
                api_base=self.api_base,
                api_key=self.api_key,
                max_depth=self.max_depth,
                max_iterations=self.max_iterations,
                _current_depth=self._current_depth + 1,
                **self.llm_kwargs
            )

            return await sub_rlm.acomplete(sub_query, sub_context)

        # Wrap in sync function for REPL compatibility
        def sync_recursive_llm(sub_query: str, sub_context: str) -> str:
            """Sync wrapper for recursive_llm."""
            # Check if we're in an async context
            try:
                loop = asyncio.get_running_loop()
                # We're in async context, but REPL is sync
                # Create a new thread to run async code
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as executor:
                    future = executor.submit(
                        asyncio.run,
                        recursive_llm(sub_query, sub_context)
                    )
                    return future.result()
            except RuntimeError:
                # No running loop, safe to use asyncio.run
                return asyncio.run(recursive_llm(sub_query, sub_context))

        return sync_recursive_llm

    def _is_rate_limit_error(self, error: Exception) -> bool:
        """Return True when an exception represents provider rate limiting."""
        error_name = error.__class__.__name__.lower()
        message = str(error).lower()
        return "ratelimit" in error_name or "rate limit" in message or "429" in message

    def _extract_retry_after_seconds(self, message: str) -> float:
        """Extract provider retry hints from an error message."""
        match = re.search(r"try again in\s+(\d+(?:\.\d+)?)s", message, re.IGNORECASE)
        if match:
            return float(match.group(1)) + 1.0

        return self.rate_limit_backoff_seconds

    @property
    def stats(self) -> Dict[str, int]:
        """Get execution statistics."""
        return {
            'llm_calls': self._llm_calls,
            'iterations': self._iterations,
            'depth': self._current_depth,
        }
