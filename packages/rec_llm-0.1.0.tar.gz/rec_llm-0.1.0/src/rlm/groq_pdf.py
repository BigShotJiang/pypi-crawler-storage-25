"""Helpers for analyzing local PDFs with Groq-backed RLM."""

from __future__ import annotations

from pathlib import Path

from .core import MaxIterationsError, RLM
from .document_processor import DocumentProcessor, SourceDocument
from .linearrag_adapter import LinearRAGRetriever


DEFAULT_QUERY = (
    "Analyze this PDF. Summarize the main points, extract the most important "
    "facts, and cite the relevant chunk ids for your conclusions."
)
DEFAULT_MODEL = "groq/llama-3.3-70b-versatile"
DEFAULT_RECURSIVE_MODEL = "groq/meta-llama/llama-4-scout-17b-16e-instruct"
DEFAULT_ANALYSIS_MODE = "plain_rlm"
DEFAULT_LINEARRAG_TOP_K = 5


def analyze_pdf_with_groq(
    pdf_path: str | Path,
    query: str = DEFAULT_QUERY,
    *,
    model: str = DEFAULT_MODEL,
    recursive_model: str = DEFAULT_RECURSIVE_MODEL,
    max_iterations: int = 10,
) -> str:
    """Run RLM analysis on a local PDF using Groq-hosted models."""
    resolved_path = Path(pdf_path).expanduser().resolve()

    if not resolved_path.exists():
        raise FileNotFoundError(f"File not found: {resolved_path}")

    if resolved_path.suffix.lower() != ".pdf":
        raise ValueError(f"Expected a .pdf file, got: {resolved_path.name}")

    rlm = RLM(
        model=model,
        recursive_model=recursive_model,
        max_iterations=max_iterations,
        rate_limit_retries=4,
        max_tokens=400,
        temperature=0,
    )
    processor = DocumentProcessor(
        rlm,
        chunk_size_chars=4000,
        chunk_overlap_chars=400,
    )

    try:
        return processor.process_documents(query, [resolved_path])
    except MaxIterationsError as exc:
        raise RuntimeError(
            "The Groq model did not finalize within the iteration limit. "
            "Try again, simplify the query, or increase max_iterations."
        ) from exc


def analyze_pdf_with_linearrag_groq(
    pdf_path: str | Path,
    query: str = DEFAULT_QUERY,
    *,
    model: str = DEFAULT_MODEL,
    recursive_model: str = DEFAULT_RECURSIVE_MODEL,
    max_iterations: int = 10,
    linearrag_repo_path: str | Path,
    linearrag_embedding_model: str,
    linearrag_spacy_model: str = "en_core_web_sm",
    linearrag_top_k: int = DEFAULT_LINEARRAG_TOP_K,
    linearrag_working_dir: str | Path | None = None,
    linearrag_use_vectorized_retrieval: bool = False,
) -> str:
    """Retrieve with LinearRAG, then answer with RLM."""
    resolved_path = Path(pdf_path).expanduser().resolve()

    if not resolved_path.exists():
        raise FileNotFoundError(f"File not found: {resolved_path}")

    if resolved_path.suffix.lower() != ".pdf":
        raise ValueError(f"Expected a .pdf file, got: {resolved_path.name}")

    retriever = LinearRAGRetriever(
        linearrag_repo_path,
        embedding_model=linearrag_embedding_model,
        spacy_model=linearrag_spacy_model,
        working_dir=linearrag_working_dir,
        retrieval_top_k=linearrag_top_k,
        use_vectorized_retrieval=linearrag_use_vectorized_retrieval,
    )
    retrieved_passages = retriever.retrieve_from_documents(query, [resolved_path])
    if not retrieved_passages:
        raise RuntimeError("LinearRAG did not return any passages for this query.")

    rlm = RLM(
        model=model,
        recursive_model=recursive_model,
        max_iterations=max_iterations,
        rate_limit_retries=4,
        max_tokens=400,
        temperature=0,
    )
    processor = DocumentProcessor(
        rlm,
        chunk_size_chars=4000,
        chunk_overlap_chars=400,
    )
    retrieved_documents = [
        SourceDocument(
            name=f"retrieved-{item.rank:02d}.txt",
            text=item.text,
            metadata={"score": item.score if item.score is not None else "n/a"},
        )
        for item in retrieved_passages
    ]

    query_with_instruction = (
        f"{query}\n\n"
        "The provided context has already been retrieved by LinearRAG. "
        "Base the answer only on these passages and cite the chunk ids you use."
    )

    try:
        return processor.process_documents(query_with_instruction, retrieved_documents)
    except MaxIterationsError as exc:
        raise RuntimeError(
            "The Groq model did not finalize within the iteration limit. "
            "Try again, simplify the query, or increase max_iterations."
        ) from exc
