"""Optional adapter for using LinearRAG as a retriever before RLM."""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
from pathlib import Path
import shutil
import sys
import tempfile
from typing import Iterator
from urllib.request import urlopen
import zipfile

from .document_processor import DocumentProcessor, SourceDocument

DEFAULT_LINEARRAG_REPO_URL = "https://github.com/DEEP-PolyU/LinearRAG.git"
DEFAULT_LINEARRAG_ARCHIVE_URL = (
    "https://github.com/DEEP-PolyU/LinearRAG/archive/refs/heads/main.zip"
)


@dataclass(frozen=True)
class RetrievedPassage:
    """A passage retrieved by LinearRAG."""

    text: str
    score: float | None = None
    rank: int = 0


class LinearRAGRetriever:
    """Use an external LinearRAG checkout as a retriever over local documents."""

    def __init__(
        self,
        repo_path: str | Path,
        *,
        embedding_model: str,
        spacy_model: str = "en_core_web_sm",
        working_dir: str | Path | None = None,
        retrieval_top_k: int = 5,
        max_workers: int = 4,
        use_vectorized_retrieval: bool = False,
    ) -> None:
        self.repo_path = Path(repo_path).expanduser().resolve()
        if not self.repo_path.exists():
            self._bootstrap_repo()
        if not (self.repo_path / "src" / "LinearRAG.py").exists():
            raise FileNotFoundError(
                f"LinearRAG.py not found under repo path: {self.repo_path / 'src' / 'LinearRAG.py'}"
            )
        if not (self.repo_path / "src" / "config.py").exists():
            raise FileNotFoundError(
                f"config.py not found under repo path: {self.repo_path / 'src' / 'config.py'}"
            )

        self.embedding_model = embedding_model
        self.spacy_model = spacy_model
        self.retrieval_top_k = retrieval_top_k
        self.max_workers = max_workers
        self.use_vectorized_retrieval = use_vectorized_retrieval

        if working_dir is None:
            working_dir = Path.cwd() / ".linearrag_cache"
        self.working_dir = Path(working_dir).expanduser().resolve()
        self.working_dir.mkdir(parents=True, exist_ok=True)

    def retrieve_from_documents(
        self,
        query: str,
        documents: list[str | Path | SourceDocument],
        *,
        chunk_size_chars: int = 1200,
        chunk_overlap_chars: int = 120,
    ) -> list[RetrievedPassage]:
        """Index the provided documents with LinearRAG and retrieve passages."""
        processor = DocumentProcessor(
            rlm=None,  # type: ignore[arg-type]
            chunk_size_chars=chunk_size_chars,
            chunk_overlap_chars=chunk_overlap_chars,
        )
        corpus = processor.prepare_documents(documents)
        passages = [
            f"{chunk.chunk_id} | {chunk.document_name} | chars={chunk.start_char}:{chunk.end_char}\n"
            f"{chunk.text}"
            for chunk in corpus.chunks
        ]
        if not passages:
            return []

        dataset_name = self._dataset_name_for_passages(passages)
        with self._linearrag_import_context():
            try:
                from sentence_transformers import SentenceTransformer
                from src.LinearRAG import LinearRAG  # type: ignore[import-not-found]
                from src.config import LinearRAGConfig  # type: ignore[import-not-found]
            except ImportError as exc:
                raise ImportError(
                    "LinearRAG mode requires the LinearRAG repo and its dependencies "
                    "(for example sentence-transformers, spaCy, python-igraph, pandas, pyarrow)."
                ) from exc

            embedding_model = SentenceTransformer(self.embedding_model)
            config = LinearRAGConfig(
                dataset_name=dataset_name,
                embedding_model=embedding_model,
                llm_model=None,
                spacy_model=self.spacy_model,
                working_dir=str(self.working_dir),
                max_workers=self.max_workers,
                retrieval_top_k=self.retrieval_top_k,
                use_vectorized_retrieval=self.use_vectorized_retrieval,
            )
            rag = LinearRAG(global_config=config)
            rag.index(passages)
            results = rag.retrieve([{"question": query, "answer": ""}])

        if not results:
            return []

        result = results[0]
        passages_out: list[RetrievedPassage] = []
        raw_scores = result.get("sorted_passage_scores", [])
        for index, text in enumerate(result.get("sorted_passage", []), start=1):
            score = raw_scores[index - 1] if index - 1 < len(raw_scores) else None
            passages_out.append(RetrievedPassage(text=text, score=score, rank=index))
        return passages_out

    @contextmanager
    def _linearrag_import_context(self) -> Iterator[None]:
        """Temporarily prioritize the external LinearRAG checkout on sys.path."""
        repo_path_str = str(self.repo_path)
        previous = list(sys.path)
        sys.path.insert(0, repo_path_str)
        try:
            yield
        finally:
            sys.path[:] = previous

    def _dataset_name_for_passages(self, passages: list[str]) -> str:
        """Build a stable cache key for the current passage set."""
        digest = hashlib.sha256("\n".join(passages).encode("utf-8")).hexdigest()[:16]
        return f"local_{digest}"

    def _bootstrap_repo(self) -> None:
        """Download a fresh LinearRAG checkout when the expected path is missing."""
        self.repo_path.parent.mkdir(parents=True, exist_ok=True)

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_dir_path = Path(temp_dir)
            archive_path = temp_dir_path / "linearrag.zip"

            try:
                with urlopen(DEFAULT_LINEARRAG_ARCHIVE_URL) as response, archive_path.open("wb") as file:
                    shutil.copyfileobj(response, file)
            except Exception as exc:
                raise FileNotFoundError(
                    "LinearRAG repo not found locally and automatic download failed. "
                    f"Tried: {DEFAULT_LINEARRAG_ARCHIVE_URL}"
                ) from exc

            extract_dir = temp_dir_path / "extract"
            extract_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(archive_path) as archive:
                archive.extractall(extract_dir)

            extracted_roots = [path for path in extract_dir.iterdir() if path.is_dir()]
            if not extracted_roots:
                raise FileNotFoundError("Downloaded LinearRAG archive did not contain a repository folder.")

            extracted_repo = extracted_roots[0]
            if self.repo_path.exists():
                shutil.rmtree(self.repo_path)
            shutil.move(str(extracted_repo), str(self.repo_path))
