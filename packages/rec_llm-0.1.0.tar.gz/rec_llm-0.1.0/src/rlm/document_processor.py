"""Document-oriented helpers built on top of RLM."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple, Union

import fitz

from .core import RLM


DocumentInput = Union["SourceDocument", Path, Mapping[str, Any], str]


@dataclass(frozen=True)
class SourceDocument:
    """A named document that can be processed by RLM."""

    name: str
    text: str
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class DocumentChunk:
    """A chunk of a source document with positional metadata."""

    chunk_id: str
    document_name: str
    chunk_index: int
    start_char: int
    end_char: int
    text: str

    @property
    def length(self) -> int:
        """Return the chunk length in characters."""
        return self.end_char - self.start_char


@dataclass
class PreparedCorpus:
    """Structured large-document corpus prepared for RLM."""

    documents: List[SourceDocument]
    chunks: List[DocumentChunk]
    context: str
    preview_chars: int = 160

    @property
    def total_chars(self) -> int:
        """Return the total number of source characters."""
        return sum(len(document.text) for document in self.documents)

    def build_env(self) -> Dict[str, Any]:
        """Build helper functions and metadata for the REPL."""
        document_map = {document.name: document for document in self.documents}
        chunk_map = {chunk.chunk_id: chunk for chunk in self.chunks}

        def list_documents() -> List[Dict[str, Any]]:
            return [
                {
                    "name": document.name,
                    "chars": len(document.text),
                    "metadata": dict(document.metadata),
                }
                for document in self.documents
            ]

        def list_chunk_ids(document_name: Optional[str] = None) -> List[str]:
            return [
                chunk.chunk_id
                for chunk in self.chunks
                if document_name is None or chunk.document_name == document_name
            ]

        def get_chunk(chunk_id: str) -> str:
            return chunk_map[chunk_id].text

        def get_document(document_name: str) -> str:
            return document_map[document_name].text

        def find_chunks(
            term: str,
            limit: int = 5,
            document_name: Optional[str] = None,
            case_sensitive: bool = False,
        ) -> List[Dict[str, Any]]:
            if limit <= 0:
                return []

            needle = term if case_sensitive else term.lower()
            matches: List[Dict[str, Any]] = []

            for chunk in self.chunks:
                if document_name is not None and chunk.document_name != document_name:
                    continue

                haystack = chunk.text if case_sensitive else chunk.text.lower()
                if needle not in haystack:
                    continue

                matches.append(
                    {
                        "chunk_id": chunk.chunk_id,
                        "document_name": chunk.document_name,
                        "chunk_index": chunk.chunk_index,
                        "start_char": chunk.start_char,
                        "end_char": chunk.end_char,
                        "preview": _preview_text(chunk.text, self.preview_chars),
                    }
                )

                if len(matches) >= limit:
                    break

            return matches

        return {
            "documents": list_documents(),
            "chunks": [
                {
                    "chunk_id": chunk.chunk_id,
                    "document_name": chunk.document_name,
                    "chunk_index": chunk.chunk_index,
                    "start_char": chunk.start_char,
                    "end_char": chunk.end_char,
                    "preview": _preview_text(chunk.text, self.preview_chars),
                }
                for chunk in self.chunks
            ],
            "list_documents": list_documents,
            "list_chunk_ids": list_chunk_ids,
            "get_chunk": get_chunk,
            "get_document": get_document,
            "find_chunks": find_chunks,
        }

    def build_system_prompt_extra(self) -> str:
        """Describe available corpus helpers for the model."""
        return (
            "This context is a structured corpus assembled from one or more large documents.\n"
            "Extra helpers are available in the REPL:\n"
            "- documents: metadata for each source document\n"
            "- chunks: metadata and previews for each chunk\n"
            "- list_documents() -> document metadata\n"
            "- list_chunk_ids(document_name=None) -> chunk ids\n"
            "- find_chunks(term, limit=5, document_name=None, "
            "case_sensitive=False) -> matching chunk previews\n"
            "- get_chunk(chunk_id) -> full chunk text\n"
            "- get_document(document_name) -> full source document text\n"
            "Use these helpers first to localize relevant regions before "
            "scanning large spans of `context`."
        )


class DocumentProcessor:
    """Prepare large documents and query them with RLM."""

    def __init__(
        self,
        rlm: RLM,
        chunk_size_chars: int = 4000,
        chunk_overlap_chars: int = 400,
        boundary_window_chars: int = 400,
        preview_chars: int = 160,
    ) -> None:
        if chunk_size_chars <= 0:
            raise ValueError("chunk_size_chars must be greater than 0")
        if chunk_overlap_chars < 0:
            raise ValueError("chunk_overlap_chars cannot be negative")
        if chunk_overlap_chars >= chunk_size_chars:
            raise ValueError(
                "chunk_overlap_chars must be smaller than chunk_size_chars"
            )
        if boundary_window_chars < 0:
            raise ValueError("boundary_window_chars cannot be negative")

        self.rlm = rlm
        self.chunk_size_chars = chunk_size_chars
        self.chunk_overlap_chars = chunk_overlap_chars
        self.boundary_window_chars = boundary_window_chars
        self.preview_chars = preview_chars

    def process_text(
        self,
        query: str,
        text: str,
        *,
        name: str = "document.txt",
        metadata: Optional[Mapping[str, Any]] = None,
        **kwargs: Any,
    ) -> str:
        """Process a single raw text document."""
        return self.process_documents(
            query,
            [SourceDocument(name=name, text=text, metadata=dict(metadata or {}))],
            **kwargs,
        )

    async def aprocess_text(
        self,
        query: str,
        text: str,
        *,
        name: str = "document.txt",
        metadata: Optional[Mapping[str, Any]] = None,
        **kwargs: Any,
    ) -> str:
        """Async version of process_text."""
        return await self.aprocess_documents(
            query,
            [SourceDocument(name=name, text=text, metadata=dict(metadata or {}))],
            **kwargs,
        )

    def process_documents(
        self,
        query: str,
        documents: Sequence[DocumentInput],
        **kwargs: Any,
    ) -> str:
        """Prepare a corpus and send it through RLM."""
        corpus = self.prepare_documents(documents)
        return self.rlm.complete(
            query=query,
            context=corpus.context,
            env=corpus.build_env(),
            system_prompt_extra=corpus.build_system_prompt_extra(),
            **kwargs,
        )

    async def aprocess_documents(
        self,
        query: str,
        documents: Sequence[DocumentInput],
        **kwargs: Any,
    ) -> str:
        """Async version of process_documents."""
        corpus = self.prepare_documents(documents)
        return await self.rlm.acomplete(
            query=query,
            context=corpus.context,
            env=corpus.build_env(),
            system_prompt_extra=corpus.build_system_prompt_extra(),
            **kwargs,
        )

    def prepare_documents(self, documents: Sequence[DocumentInput]) -> PreparedCorpus:
        """Normalize and chunk input documents into a searchable corpus."""
        normalized_documents = [
            self._coerce_document(document, index)
            for index, document in enumerate(documents)
        ]
        chunks = self._build_chunks(normalized_documents)
        context = self._build_context(normalized_documents, chunks)
        return PreparedCorpus(
            documents=normalized_documents,
            chunks=chunks,
            context=context,
            preview_chars=self.preview_chars,
        )

    def _coerce_document(self, document: DocumentInput, index: int) -> SourceDocument:
        """Convert user input into a SourceDocument."""
        if isinstance(document, SourceDocument):
            return document

        if isinstance(document, Path):
            return SourceDocument(
                name=document.name,
                text=self._read_document_path(document),
                metadata={"path": str(document)},
            )

        if isinstance(document, Mapping):
            if "text" not in document:
                raise ValueError("Document mappings must include a 'text' field")
            name = str(document.get("name", f"document-{index + 1}.txt"))
            metadata = dict(document.get("metadata", {}))
            return SourceDocument(
                name=name,
                text=str(document["text"]),
                metadata=metadata,
            )

        if isinstance(document, str):
            return SourceDocument(name=f"document-{index + 1}.txt", text=document)

        raise TypeError(f"Unsupported document input type: {type(document)!r}")

    def _read_document_path(self, path: Path) -> str:
        """Read a local document path into text."""
        if path.suffix.lower() == ".pdf":
            with fitz.open(path) as document:
                pages = [page.get_text() or "" for page in document]
            return "\n\n".join(pages)

        return path.read_text(encoding="utf-8")

    def _build_chunks(self, documents: Sequence[SourceDocument]) -> List[DocumentChunk]:
        """Chunk each document while preserving source boundaries."""
        chunks: List[DocumentChunk] = []

        for document in documents:
            base_id = _slugify(document.name)
            for chunk_index, (start_char, end_char, text) in enumerate(
                self._chunk_text(document.text)
            ):
                chunks.append(
                    DocumentChunk(
                        chunk_id=f"{base_id}-chunk-{chunk_index:04d}",
                        document_name=document.name,
                        chunk_index=chunk_index,
                        start_char=start_char,
                        end_char=end_char,
                        text=text,
                    )
                )

        return chunks

    def _chunk_text(self, text: str) -> List[Tuple[int, int, str]]:
        """Split text into boundary-aware chunks with overlap."""
        if not text:
            return []

        chunks: List[Tuple[int, int, str]] = []
        start_char = 0
        text_length = len(text)

        while start_char < text_length:
            max_end = min(start_char + self.chunk_size_chars, text_length)
            end_char = self._choose_chunk_end(text, start_char, max_end)
            if end_char <= start_char:
                end_char = max_end

            chunks.append((start_char, end_char, text[start_char:end_char]))
            if end_char >= text_length:
                break

            next_start = max(end_char - self.chunk_overlap_chars, start_char + 1)
            start_char = next_start

        return chunks

    def _choose_chunk_end(self, text: str, start_char: int, max_end: int) -> int:
        """Prefer breaking on structural boundaries near the target size."""
        if max_end >= len(text):
            return len(text)

        search_start = max(start_char + 1, max_end - self.boundary_window_chars)
        boundary_window = text[search_start:max_end]

        for separator in ("\n\n", "\n", ". ", " "):
            offset = boundary_window.rfind(separator)
            if offset != -1:
                return search_start + offset + len(separator)

        return max_end

    def _build_context(
        self,
        documents: Sequence[SourceDocument],
        chunks: Sequence[DocumentChunk],
    ) -> str:
        """Assemble a structured corpus string for RLM."""
        header_lines = [
            "=== CORPUS OVERVIEW ===",
            f"Documents: {len(documents)}",
            f"Chunks: {len(chunks)}",
            f"Total source characters: {sum(len(document.text) for document in documents)}",
            "",
            "=== DOCUMENT MANIFEST ===",
        ]

        for document in documents:
            metadata = ", ".join(
                f"{key}={value}" for key, value in sorted(document.metadata.items())
            )
            metadata_suffix = f" metadata: {metadata}" if metadata else ""
            header_lines.append(
                f"- {document.name} | chars={len(document.text)}{metadata_suffix}"
            )

        chunk_lines = ["", "=== CHUNK MANIFEST ==="]
        for chunk in chunks:
            chunk_lines.append(
                f"- {chunk.chunk_id} | document={chunk.document_name} | "
                f"chars={chunk.start_char}:{chunk.end_char} | "
                f"preview={_preview_text(chunk.text, self.preview_chars)}"
            )

        full_text_lines = ["", "=== FULL CHUNKS ==="]
        for chunk in chunks:
            full_text_lines.extend(
                [
                    (
                        f"--- BEGIN CHUNK {chunk.chunk_id} "
                        f"({chunk.document_name} {chunk.start_char}:{chunk.end_char}) ---"
                    ),
                    chunk.text,
                    f"--- END CHUNK {chunk.chunk_id} ---",
                    "",
                ]
            )

        return "\n".join(header_lines + chunk_lines + full_text_lines).strip()


def _preview_text(text: str, preview_chars: int) -> str:
    """Return a compact single-line preview."""
    normalized = re.sub(r"\s+", " ", text).strip()
    if len(normalized) <= preview_chars:
        return normalized
    return normalized[:preview_chars].rstrip() + "..."


def _slugify(text: str) -> str:
    """Create a stable identifier fragment."""
    slug = re.sub(r"[^A-Za-z0-9]+", "-", text).strip("-").lower()
    return slug or "document"
