"""Packaged Gradio UI for Groq-backed PDF analysis with RLM."""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

from .groq_pdf import (
    DEFAULT_ANALYSIS_MODE,
    DEFAULT_LINEARRAG_TOP_K,
    DEFAULT_MODEL,
    DEFAULT_QUERY,
    DEFAULT_RECURSIVE_MODEL,
    analyze_pdf_with_groq,
    analyze_pdf_with_linearrag_groq,
)


os.environ.setdefault("GRADIO_TEMP_DIR", r"C:\gradio_tmp")
load_dotenv()

DEFAULT_LINEARRAG_REPO_PATH = str((Path.cwd() / ".external" / "LinearRAG").resolve())
DEFAULT_LINEARRAG_EMBEDDING_MODEL = "sentence-transformers/all-mpnet-base-v2"
DEFAULT_LINEARRAG_SPACY_MODEL = "en_core_web_sm"
DEFAULT_LINEARRAG_CACHE_DIR = str((Path.cwd() / ".linearrag_cache").resolve())


def run_analysis(
    mode: str,
    pdf_path: str,
    query: str,
    model: str,
    recursive_model: str,
    linearrag_repo_path: str,
    linearrag_embedding_model: str,
    linearrag_spacy_model: str,
    linearrag_top_k: int | float,
    linearrag_working_dir: str,
    linearrag_use_vectorized_retrieval: bool,
) -> str:
    """Analyze a local PDF path and return the model output."""
    if not os.getenv("GROQ_API_KEY"):
        return "Error: GROQ_API_KEY not found. Set it in .env or your environment first."

    if not pdf_path or not str(pdf_path).strip():
        return "Error: enter the full local path to a PDF first."

    prompt = query.strip() or DEFAULT_QUERY

    try:
        if mode == "LinearRAG + RLM":
            if not linearrag_embedding_model or not str(linearrag_embedding_model).strip():
                return "Error: enter the embedding model path/name for LinearRAG mode."

            return analyze_pdf_with_linearrag_groq(
                str(pdf_path).strip(),
                prompt,
                model=model.strip() or DEFAULT_MODEL,
                recursive_model=recursive_model.strip() or DEFAULT_RECURSIVE_MODEL,
                linearrag_repo_path=str(linearrag_repo_path).strip() or DEFAULT_LINEARRAG_REPO_PATH,
                linearrag_embedding_model=str(linearrag_embedding_model).strip(),
                linearrag_spacy_model=str(linearrag_spacy_model).strip() or DEFAULT_LINEARRAG_SPACY_MODEL,
                linearrag_top_k=int(linearrag_top_k),
                linearrag_working_dir=str(linearrag_working_dir).strip() or None,
                linearrag_use_vectorized_retrieval=bool(linearrag_use_vectorized_retrieval),
            )

        return analyze_pdf_with_groq(
            str(pdf_path).strip(),
            prompt,
            model=model.strip() or DEFAULT_MODEL,
            recursive_model=recursive_model.strip() or DEFAULT_RECURSIVE_MODEL,
        )
    except Exception as exc:
        return f"Error: {exc}"


def build_demo():
    """Create the Gradio UI."""
    try:
        import gradio as gr
    except ImportError as exc:
        raise ImportError(
            "Gradio UI dependencies are not installed. Install with `pip install recursive-llm[ui]` "
            "or `pip install recursive-llm[all]`."
        ) from exc

    with gr.Blocks(title="Groq PDF Analyzer") as demo:
        gr.Markdown(
            """
            # Groq PDF Analyzer
            Enter a local PDF path, enter a question, and run Recursive Language Models against it using Groq.
            LinearRAG mode will auto-download the upstream repository on first use into `.external\\LinearRAG`.
            On Windows, prefer `en_core_web_sm` unless you specifically need the transformer spaCy model.
            """
        )

        with gr.Row():
            pdf_input = gr.Textbox(
                label="Local PDF path",
                placeholder=r"C:\Users\YourName\Documents\report.pdf",
            )
            with gr.Column():
                model_input = gr.Textbox(
                    label="Groq root model",
                    value=DEFAULT_MODEL,
                )
                recursive_model_input = gr.Textbox(
                    label="Groq recursive model",
                    value=DEFAULT_RECURSIVE_MODEL,
                )

        mode_input = gr.Radio(
            label="Analysis mode",
            choices=["Plain RLM", "LinearRAG + RLM"],
            value="Plain RLM" if DEFAULT_ANALYSIS_MODE == "plain_rlm" else "LinearRAG + RLM",
        )

        with gr.Column():
            linearrag_repo_input = gr.Textbox(
                label="LinearRAG repo path",
                value=DEFAULT_LINEARRAG_REPO_PATH,
            )
            linearrag_embedding_model_input = gr.Textbox(
                label="LinearRAG embedding model",
                value=DEFAULT_LINEARRAG_EMBEDDING_MODEL,
            )
            linearrag_spacy_model_input = gr.Textbox(
                label="LinearRAG spaCy model",
                value=DEFAULT_LINEARRAG_SPACY_MODEL,
            )
            linearrag_top_k_input = gr.Number(
                label="LinearRAG top-k",
                value=DEFAULT_LINEARRAG_TOP_K,
                precision=0,
            )
            linearrag_working_dir_input = gr.Textbox(
                label="LinearRAG cache directory",
                value=DEFAULT_LINEARRAG_CACHE_DIR,
            )
            linearrag_vectorized_input = gr.Checkbox(
                label="Use vectorized retrieval",
                value=False,
            )

        query_input = gr.Textbox(
            label="Analysis prompt",
            value=DEFAULT_QUERY,
            lines=5,
        )
        run_button = gr.Button("Analyze PDF", variant="primary")
        output = gr.Textbox(label="Result", lines=20)

        run_button.click(
            fn=run_analysis,
            inputs=[
                mode_input,
                pdf_input,
                query_input,
                model_input,
                recursive_model_input,
                linearrag_repo_input,
                linearrag_embedding_model_input,
                linearrag_spacy_model_input,
                linearrag_top_k_input,
                linearrag_working_dir_input,
                linearrag_vectorized_input,
            ],
            outputs=output,
        )

    return demo


def main() -> None:
    """Launch the Gradio UI."""
    demo = build_demo()
    demo.launch(share=True)


__all__ = [
    "build_demo",
    "main",
    "run_analysis",
]
