"""Recursive Language Models for unbounded context processing."""

from .core import (
    MaxDepthError,
    MaxIterationsError,
    RateLimitExceededError,
    RLM,
    RLMError,
)
from .document_processor import (
    DocumentChunk,
    DocumentProcessor,
    PreparedCorpus,
    SourceDocument,
)
from .gradio_app import build_demo, main as gradio_main
from .linearrag_adapter import LinearRAGRetriever, RetrievedPassage
from .repl import REPLError

__version__ = "0.1.0"

__all__ = [
    "RLM",
    "RLMError",
    "MaxIterationsError",
    "MaxDepthError",
    "RateLimitExceededError",
    "REPLError",
    "SourceDocument",
    "DocumentChunk",
    "PreparedCorpus",
    "DocumentProcessor",
    "build_demo",
    "gradio_main",
    "LinearRAGRetriever",
    "RetrievedPassage",
]
