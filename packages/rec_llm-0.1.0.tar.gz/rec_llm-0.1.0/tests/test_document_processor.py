"""Tests for document-oriented RLM processing."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from rlm import DocumentProcessor, RLM, SourceDocument


class MockResponse:
    """Mock LLM response."""

    def __init__(self, content):
        self.choices = [MagicMock(message=MagicMock(content=content))]


def test_prepare_documents_builds_chunks_and_context():
    """Prepared corpora should contain structured chunk metadata."""
    rlm = RLM(model="test-model")
    processor = DocumentProcessor(
        rlm,
        chunk_size_chars=40,
        chunk_overlap_chars=5,
        boundary_window_chars=10,
    )

    text = (
        "Alpha section.\n\n"
        "Beta section with more content.\n\n"
        "Gamma section closes the document."
    )
    corpus = processor.prepare_documents([SourceDocument(name="notes.txt", text=text)])

    assert corpus.documents[0].name == "notes.txt"
    assert len(corpus.chunks) >= 2
    assert corpus.chunks[0].start_char == 0
    assert corpus.chunks[-1].end_char == len(text)
    assert "=== CHUNK MANIFEST ===" in corpus.context
    assert "notes-txt-chunk-0000" in corpus.context


def test_prepare_documents_accepts_paths(tmp_path):
    """Path inputs should be loaded into the corpus with metadata."""
    file_path = tmp_path / "manual.txt"
    file_path.write_text("Retention period is 30 days.", encoding="utf-8")

    processor = DocumentProcessor(RLM(model="test-model"))
    corpus = processor.prepare_documents([file_path])

    assert corpus.documents[0].name == "manual.txt"
    assert corpus.documents[0].metadata["path"] == str(file_path)
    assert corpus.total_chars == len("Retention period is 30 days.")


def test_build_env_exposes_search_helpers():
    """Prepared corpora should expose chunk lookup helpers."""
    processor = DocumentProcessor(
        RLM(model="test-model"),
        chunk_size_chars=30,
        chunk_overlap_chars=5,
    )
    corpus = processor.prepare_documents(
        [
            {
                "name": "policy.txt",
                "text": "Retention rules apply here. Nothing else.\n\nRetention rules appear again.",
            }
        ]
    )

    env = corpus.build_env()
    matches = env["find_chunks"]("retention", limit=2)

    assert matches
    assert matches[0]["document_name"] == "policy.txt"
    assert "retention" in matches[0]["preview"].lower()
    chunk_text = env["get_chunk"](matches[0]["chunk_id"])
    assert chunk_text


@pytest.mark.asyncio
async def test_process_documents_uses_chunk_helpers():
    """DocumentProcessor should route helper-enriched corpora through RLM."""
    responses = [
        MockResponse('matches = find_chunks("retention", limit=2)\nprint(matches)'),
        MockResponse("FINAL_VAR(matches)"),
    ]

    with patch("rlm.core.litellm.acompletion") as mock:
        mock.side_effect = responses

        processor = DocumentProcessor(
            RLM(model="test-model"),
            chunk_size_chars=40,
            chunk_overlap_chars=5,
        )
        result = await processor.aprocess_documents(
            "Which chunks mention retention?",
            [
                SourceDocument(
                    name="policy.txt",
                    text="Retention starts here. Later, another retention clause appears.",
                )
            ],
        )

        assert "policy-txt-chunk" in result
        first_call = mock.call_args_list[0][1]
        assert "Additional corpus guidance" in first_call["messages"][0]["content"]
