from typing import Literal

BASE_URL = "https://coinos.io/api"
TYPES = Literal["lightning", "bitcoin"]
