# rampro

A high-performance numerical library for **Two-Dimensional (2D) Image Ramp Sampling**.

## Installation
```bash
pip install rampro
```

