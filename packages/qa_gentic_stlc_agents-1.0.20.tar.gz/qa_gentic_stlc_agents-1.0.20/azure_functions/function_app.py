"""
function_app.py — Azure Functions entry point for STLC Agents webhook bridge.

Exposes two HTTP-triggered functions:
  stlc_ado_webhook   — POST /api/webhook/ado
  stlc_jira_webhook  — POST /api/webhook/jira

Deploy:
  func azure functionapp publish <app-name>

Required App Settings (Azure Portal → Configuration → Application settings):
  ADO_ORGANIZATION_URL   JIRA_CLIENT_ID      WEBHOOK_SECRET
  ADO_PROJECT_NAME       JIRA_CLIENT_SECRET  ANTHROPIC_API_KEY
  ADO_PAT                JIRA_CLOUD_ID       APP_BASE_URL
  HELIX_PROJECT_ROOT     PLAYWRIGHT_MCP_URL  LLM_MODEL (optional)
"""
import json
import logging
import os

import azure.functions as func
from dotenv import load_dotenv

load_dotenv()

from stlc_agents.webhook_bridge.parsers import parse_ado, parse_jira
from stlc_agents.webhook_bridge.state_router import (
    route_ado, route_jira, STAGE_TEST_CASES, STAGE_FULL_PIPELINE,
)
from stlc_agents.ci_runner.pipeline import run_test_cases, run_post_done

log = logging.getLogger("stlc.azfunc")
app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)


def _dispatch_and_respond(event: dict) -> func.HttpResponse:
    platform = event["platform"]
    stage = (
        route_ado(event["state"], event["wi_type"])
        if platform == "ado"
        else route_jira(event["status"], event["issue_type"])
    )

    log.info("dispatch | stage=%s platform=%s", stage, platform)

    if stage == STAGE_TEST_CASES:
        result = run_test_cases(event)
    elif stage == STAGE_FULL_PIPELINE:
        result = run_post_done(event)  # Done: agents 2-4 only
    else:
        return func.HttpResponse(
            json.dumps({"status": "skipped"}),
            mimetype="application/json", status_code=200,
        )

    return func.HttpResponse(
        json.dumps(result, default=str),
        mimetype="application/json", status_code=200,
    )


@app.route(route="webhook/ado", methods=["POST"])
def stlc_ado_webhook(req: func.HttpRequest) -> func.HttpResponse:
    secret = os.getenv("WEBHOOK_SECRET", "")
    if secret:
        import hashlib, hmac as _hmac
        sig = req.headers.get("X-Hub-Signature-256", "")
        expected = "sha256=" + _hmac.new(
            secret.encode(), req.get_body(), hashlib.sha256
        ).hexdigest()
        if not _hmac.compare_digest(expected, sig):
            return func.HttpResponse("Unauthorized", status_code=401)

    try:
        payload = req.get_json()
    except ValueError:
        return func.HttpResponse("Bad Request", status_code=400)

    event = parse_ado(payload)
    if event is None:
        return func.HttpResponse(
            json.dumps({"status": "ignored"}),
            mimetype="application/json", status_code=200,
        )

    return _dispatch_and_respond(event)


@app.route(route="webhook/jira", methods=["POST"])
def stlc_jira_webhook(req: func.HttpRequest) -> func.HttpResponse:
    secret = os.getenv("WEBHOOK_SECRET", "")
    if secret:
        import hmac as _hmac
        token = req.headers.get("Authorization", "").removeprefix("Bearer ").strip()
        if not _hmac.compare_digest(token, secret):
            return func.HttpResponse("Unauthorized", status_code=401)

    try:
        payload = req.get_json()
    except ValueError:
        return func.HttpResponse("Bad Request", status_code=400)

    event = parse_jira(payload)
    if event is None:
        return func.HttpResponse(
            json.dumps({"status": "ignored"}),
            mimetype="application/json", status_code=200,
        )

    return _dispatch_and_respond(event)
