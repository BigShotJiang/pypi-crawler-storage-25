"""
register_jira_hooks.py — Register a Jira Cloud webhook pointing at the webhook bridge.

Creates one webhook listening for issue_updated and issue_created events,
filtered to transition events only.

Usage:
    python register_jira_hooks.py --bridge-url https://your-bridge.azurewebsites.net

Requires env vars: JIRA_CLIENT_ID, JIRA_CLIENT_SECRET, JIRA_CLOUD_ID, WEBHOOK_SECRET
"""
from __future__ import annotations

import argparse
import os
import sys

import requests
from dotenv import load_dotenv

load_dotenv()


def _get_jira_token() -> str:
    """Get an access token via Jira OAuth client credentials."""
    client_id     = os.getenv("JIRA_CLIENT_ID", "")
    client_secret = os.getenv("JIRA_CLIENT_SECRET", "")
    if not client_id or not client_secret:
        sys.exit("JIRA_CLIENT_ID and JIRA_CLIENT_SECRET must be set")

    resp = requests.post(
        "https://auth.atlassian.com/oauth/token",
        json={
            "grant_type":    "client_credentials",
            "client_id":     client_id,
            "client_secret": client_secret,
            "audience":      "api.atlassian.com",
        },
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bridge-url", required=True)
    parser.add_argument("--cloud-id", default=os.getenv("JIRA_CLOUD_ID", ""))
    args = parser.parse_args()

    if not args.cloud_id:
        sys.exit("JIRA_CLOUD_ID not set")

    secret      = os.getenv("WEBHOOK_SECRET", "")
    token       = _get_jira_token()
    api_base    = f"https://api.atlassian.com/ex/jira/{args.cloud_id}/rest/api/3"
    bridge_url  = f"{args.bridge_url.rstrip('/')}/webhook/jira"

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type":  "application/json",
    }

    payload = {
        "name": "stlc-agents-webhook",
        "url":  bridge_url,
        "events": [
            "jira:issue_updated",
            "jira:issue_created",
        ],
        "filters": {
            # Only fire on status field transitions
            "issue-related-events-section": "issue_transitioned",
        },
        "excludeBody": False,
    }

    # Include secret as a custom header if configured
    if secret:
        payload["headers"] = [
            {"name": "Authorization", "value": f"Bearer {secret}"}
        ]

    resp = requests.post(
        f"{api_base}/webhook",
        headers=headers,
        json=payload,
        timeout=30,
    )
    if not resp.ok:
        print(f"ERROR {resp.status_code}: {resp.text[:400]}", file=sys.stderr)
        resp.raise_for_status()

    data = resp.json()
    print(f"Jira webhook registered:")
    print(f"  webhookRegistrationResult: {data}")
    print(f"  url: {bridge_url}")
    print("Done. Verify in Jira → System → WebHooks.")


if __name__ == "__main__":
    main()
