#!/usr/bin/env python3
"""
scripts/apply_cost_tracking.py
────────────────────────────────
Automatically patches all 5 MCP server files to add cost tracking.
Run once after pip install, or after any server update.

    python scripts/apply_cost_tracking.py

The script is idempotent — running it twice is safe.
"""

from __future__ import annotations
import re
import sys
from pathlib import Path

ROOT = Path(__file__).parent.parent / "src" / "stlc_agents"

SERVERS = [
    ("agent_gherkin_generator",    "qa-gherkin-generator"),
    ("agent_test_case_manager",    "qa-test-case-manager"),
    ("agent_playwright_generator", "qa-playwright-generator"),
    ("agent_helix_writer",         "qa-helix-writer"),
    ("agent_jira_manager",         "qa-jira-manager"),
]

IMPORT_MARKER   = "from stlc_agents.shared.cost_tracker import track"
TIME_IMPORT     = "import time"
T0_MARKER       = "t0 = time.monotonic()"

# The exact return pattern emitted by every server (verbatim from source)
OLD_RETURN = (
    'return [types.TextContent(type="text", '
    'text=json.dumps(result, indent=2, ensure_ascii=False))]'
)
NEW_RETURN = "return track(result, tool_name=name, server={server!r}, t0=t0)"

OLD_ERR_BLOCK = """\
        return [types.TextContent(
            type="text",
            text=json.dumps({"error": str(exc), "tool": name}, indent=2),
        )]"""

NEW_ERR_BLOCK = """\
        err_result = {{"error": str(exc), "tool": name}}
        return track(err_result, tool_name=name, server={server!r}, t0=t0)"""


def patch_server(agent_dir: str, server_name: str) -> None:
    path = ROOT / agent_dir / "server.py"
    if not path.exists():
        print(f"  ⚠  Not found: {path}", flush=True)
        return

    src = path.read_text(encoding="utf-8")

    if IMPORT_MARKER in src:
        print(f"  ✓  {agent_dir}  — already patched, skipping", flush=True)
        return

    original = src

    # 1. Add `import time` after the existing `import sys` line
    if TIME_IMPORT not in src:
        src = src.replace("import sys\n", "import sys\nimport time\n", 1)

    # 2. Add cost_tracker import after the last `from stlc_agents...` import
    last_stlc_import = None
    for m in re.finditer(r"^from stlc_agents\..+\n", src, re.MULTILINE):
        last_stlc_import = m
    if last_stlc_import:
        pos = last_stlc_import.end()
        src = src[:pos] + f"from stlc_agents.shared.cost_tracker import track\n" + src[pos:]
    else:
        # Fallback: add after `from dotenv import load_dotenv`
        src = src.replace(
            "from dotenv import load_dotenv\n",
            "from dotenv import load_dotenv\nfrom stlc_agents.shared.cost_tracker import track\n",
            1,
        )

    # 3. Add t0 = time.monotonic() as first line inside call_tool()
    src = src.replace(
        "@app.call_tool()\nasync def call_tool(name: str, arguments: dict) -> list[types.TextContent]:\n    try:\n",
        "@app.call_tool()\nasync def call_tool(name: str, arguments: dict) -> list[types.TextContent]:\n    t0 = time.monotonic()\n    try:\n",
        1,
    )

    # 4. Replace all result return lines with track()
    new_ret = f"        {NEW_RETURN.format(server=server_name)}"
    src = src.replace(f"        {OLD_RETURN}", new_ret)

    # Some servers have 8-space or 12-space indented early returns
    for indent in ("            ", "                "):
        src = src.replace(
            f"{indent}{OLD_RETURN}",
            f"{indent}{NEW_RETURN.format(server=server_name)}",
        )

    # 5. Replace the error-path block
    new_err = NEW_ERR_BLOCK.format(server=server_name)
    src = src.replace(OLD_ERR_BLOCK, new_err)

    if src == original:
        print(f"  ⚠  {agent_dir}  — no changes made (pattern mismatch — manual patch needed)", flush=True)
        return

    path.write_text(src, encoding="utf-8")
    print(f"  ✓  {agent_dir}  — patched ({server_name})", flush=True)


def main() -> None:
    print("\nApplying cost tracking patches to stlc-agents MCP servers...\n")
    for agent_dir, server_name in SERVERS:
        patch_server(agent_dir, server_name)
    print("\nDone.  Cost tracking is now active on all servers.")
    print("Each tool call will show cost in stderr and log to ~/.qa-stlc/cost-<session>.jsonl")
    print("Control via env vars:")
    print("  STLC_COST_TRACKING=false          — disable entirely")
    print("  STLC_CODING_AGENT_MODEL=<model>   — set your coding agent's model for pricing")
    print("  STLC_COST_LOG_DIR=<path>          — change log directory\n")


if __name__ == "__main__":
    main()