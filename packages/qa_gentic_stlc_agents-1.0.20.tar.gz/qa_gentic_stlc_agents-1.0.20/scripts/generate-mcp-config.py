#!/usr/bin/env python3
"""
generate-mcp-config.py — Write MCP server config for Claude Code or VS Code.

Usage:
    python3 scripts/generate-mcp-config.py                             # Claude Code → .mcp.json (ado)
    python3 scripts/generate-mcp-config.py --vscode                    # VS Code     → .vscode/mcp.json (ado)
    python3 scripts/generate-mcp-config.py --vscode --integration jira # VS Code     → .vscode/mcp.json (jira)
    python3 scripts/generate-mcp-config.py --vscode --integration both # VS Code     → .vscode/mcp.json (both)
    python3 scripts/generate-mcp-config.py --print                     # Print both, write nothing

The generated config uses absolute paths to this project's .venv binaries so
the MCP servers start without needing the project on PATH.

Windows note: binaries live in .venv\\Scripts\\ not .venv/bin/
"""

import json
import pathlib
import platform
import sys

# ── Paths ─────────────────────────────────────────────────────────────────────
ROOT = pathlib.Path(__file__).parent.parent.resolve()

# Windows uses Scripts/, Unix uses bin/
BIN_DIR = ROOT / ".venv" / ("Scripts" if platform.system() == "Windows" else "bin")

# Binary extension on Windows
EXT = ".exe" if platform.system() == "Windows" else ""

ADO_AGENTS = {
    "qa-test-case-manager":    BIN_DIR / f"qa-test-case-manager{EXT}",
    "qa-gherkin-generator":    BIN_DIR / f"qa-gherkin-generator{EXT}",
    "qa-playwright-generator": BIN_DIR / f"qa-playwright-generator{EXT}",
    "qa-helix-writer":         BIN_DIR / f"qa-helix-writer{EXT}",
}

JIRA_AGENTS = {
    "qa-jira-manager":         BIN_DIR / f"qa-jira-manager{EXT}",
    "qa-gherkin-generator":    BIN_DIR / f"qa-gherkin-generator{EXT}",
    "qa-playwright-generator": BIN_DIR / f"qa-playwright-generator{EXT}",
    "qa-helix-writer":         BIN_DIR / f"qa-helix-writer{EXT}",
}

BOTH_AGENTS = {
    "qa-test-case-manager":    BIN_DIR / f"qa-test-case-manager{EXT}",
    "qa-jira-manager":         BIN_DIR / f"qa-jira-manager{EXT}",
    "qa-gherkin-generator":    BIN_DIR / f"qa-gherkin-generator{EXT}",
    "qa-playwright-generator": BIN_DIR / f"qa-playwright-generator{EXT}",
    "qa-helix-writer":         BIN_DIR / f"qa-helix-writer{EXT}",
}

# ── Validate binaries exist ───────────────────────────────────────────────────
def check_binaries(agents: dict):
    missing = [name for name, path in agents.items() if not path.exists()]
    if missing:
        print("⚠  Some binaries not found — run `make install` first:")
        for name in missing:
            print(f"   {agents[name]}")
        print()


JIRA_ENV = {
    "JIRA_CLIENT_ID":     "${env:JIRA_CLIENT_ID}",
    "JIRA_CLIENT_SECRET": "${env:JIRA_CLIENT_SECRET}",
    "JIRA_CLOUD_ID":      "${env:JIRA_CLOUD_ID}",
}


# ── Config builders ───────────────────────────────────────────────────────────
def claude_config(agents: dict) -> dict:
    """
    Claude Code format (.mcp.json):
    https://docs.claude.ai/en/docs/claude-code/mcp
    """
    servers = {
        name: {"command": str(path)}
        for name, path in agents.items()
    }
    if "qa-jira-manager" in agents:
        servers["qa-jira-manager"] = {
            "command": str(agents["qa-jira-manager"]),
            "env": JIRA_ENV,
        }
    servers["playwright"] = {
        "command": "npx",
        "args": ["@playwright/mcp@latest", "--isolated"],
    }
    return {"mcpServers": servers}


def vscode_config(agents: dict) -> dict:
    """
    VS Code MCP format (.vscode/mcp.json):
    https://code.visualstudio.com/docs/copilot/chat/mcp-servers

    Uses 'type: stdio' and splits command + args for compatibility with
    both GitHub Copilot and the VS Code MCP extension.
    """
    servers = {}
    for name, path in agents.items():
        entry: dict = {
            "type": "stdio",
            "command": str(path),
            "args": [],
        }
        if name == "qa-jira-manager":
            entry["env"] = JIRA_ENV
        servers[name] = entry
    servers["playwright"] = {
        "type": "stdio",
        "command": "npx",
        "args": ["@playwright/mcp@latest", "--isolated"],
    }
    return {"servers": servers}


# ── Main ──────────────────────────────────────────────────────────────────────
args = sys.argv[1:]

mode = "--claude"
integration = "ado"

i = 0
while i < len(args):
    if args[i] in ("--claude", "--vscode", "--print"):
        mode = args[i]
    elif args[i] == "--integration" and i + 1 < len(args):
        integration = args[i + 1]
        i += 1
    else:
        print(f"Unknown option: {args[i]}")
        print("Usage: python3 scripts/generate-mcp-config.py [--claude | --vscode | --print] [--integration ado|jira|both]")
        sys.exit(1)
    i += 1

if integration not in ("ado", "jira", "both"):
    print(f"Unknown integration: {integration}. Use ado, jira, or both.")
    sys.exit(1)

agents = {"ado": ADO_AGENTS, "jira": JIRA_AGENTS, "both": BOTH_AGENTS}[integration]

check_binaries(agents)

if mode == "--print":
    print(f"=== Claude Code  (.mcp.json) [integration={integration}] ===")
    print(json.dumps(claude_config(agents), indent=2))
    print(f"\n=== VS Code  (.vscode/mcp.json) [integration={integration}] ===")
    print(json.dumps(vscode_config(agents), indent=2))

elif mode == "--vscode":
    vscode_dir = ROOT / ".vscode"
    vscode_dir.mkdir(exist_ok=True)
    out = vscode_dir / "mcp.json"
    out.write_text(json.dumps(vscode_config(agents), indent=2) + "\n", encoding="utf-8")
    print(f"✓  Written to {out}  (integration={integration})")
    print()
    print("Next steps:")
    print("  1. Open VS Code in this workspace")
    print("  2. Reload the window — the qa-* servers will appear in the MCP panel")
    print("  3. GitHub Copilot Chat will pick them up automatically on next conversation")

else:  # --claude (default)
    out = ROOT / ".mcp.json"
    out.write_text(json.dumps(claude_config(agents), indent=2) + "\n", encoding="utf-8")
    print(f"✓  Written to {out}  (integration={integration})")
    print()
    print("Next steps:")
    print("  1. Open this project in Claude Code")
    print("  2. Run: /mcp  (to verify the servers are loaded)")
    print("  3. Ask: 'Generate test cases for work item #<id> in <project>'")