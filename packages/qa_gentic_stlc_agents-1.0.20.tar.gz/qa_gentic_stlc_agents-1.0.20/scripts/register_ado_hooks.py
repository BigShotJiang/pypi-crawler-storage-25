"""
register_ado_hooks.py — Register ADO Service Hooks pointing at the webhook bridge.

Creates two subscriptions:
  1. workitem.updated → state Approved or Committed → POST /webhook/ado
  2. workitem.updated → state Done                  → POST /webhook/ado

Usage:
    python register_ado_hooks.py --bridge-url https://your-bridge.azurewebsites.net
    python register_ado_hooks.py --bridge-url http://localhost:8080  # local dev (ngrok)

Requires env vars: ADO_ORGANIZATION_URL, ADO_PROJECT_NAME, ADO_PAT, WEBHOOK_SECRET
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import requests
from dotenv import load_dotenv

load_dotenv()


def _headers() -> dict:
    pat = os.getenv("ADO_PAT", "")
    if not pat:
        sys.exit("ADO_PAT not set")
    import base64
    encoded = base64.b64encode(f":{pat}".encode()).decode()
    return {
        "Authorization": f"Basic {encoded}",
        "Content-Type": "application/json",
    }


def _create_subscription(org_url: str, project_id: str,
                          state_filter: str, bridge_url: str,
                          secret: str) -> dict:
    """Create a single workitem.updated service hook subscription."""
    url = f"{org_url.rstrip('/')}/_apis/hooks/subscriptions?api-version=7.1"

    payload = {
        "publisherId": "tfs",
        "eventType": "workitem.updated",
        "resourceVersion": "1.0",
        "consumerId": "webHooks",
        "consumerActionId": "httpRequest",
        "publisherInputs": {
            "projectId": project_id,
            "tfsSubscriptionId": "",
            "workItemType": "",          # all types
            "areaPath": "",              # all areas
            "changedFields": "System.State",
            "stateTransitionTo": state_filter,
        },
        "consumerInputs": {
            "url": f"{bridge_url.rstrip('/')}/webhook/ado",
            "httpHeaders": f"X-Hub-Signature-256: sha256-placeholder",
            "resourceDetailsToSend": "all",
            "messagesToSend": "none",
            "detailedMessagesToSend": "none",
        },
    }

    resp = requests.post(url, headers=_headers(), json=payload, timeout=30)
    if not resp.ok:
        print(f"  ERROR {resp.status_code}: {resp.text[:300]}", file=sys.stderr)
        resp.raise_for_status()
    return resp.json()


def _get_project_id(org_url: str, project_name: str) -> str:
    url = f"{org_url.rstrip('/')}/_apis/projects/{project_name}?api-version=7.1"
    resp = requests.get(url, headers=_headers(), timeout=30)
    resp.raise_for_status()
    return resp.json()["id"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bridge-url", required=True,
                        help="Public URL of the webhook bridge, e.g. https://xyz.azurewebsites.net")
    parser.add_argument("--org-url",    default=os.getenv("ADO_ORGANIZATION_URL", ""))
    parser.add_argument("--project",    default=os.getenv("ADO_PROJECT_NAME", ""))
    args = parser.parse_args()

    if not args.org_url or not args.project:
        sys.exit("Set ADO_ORGANIZATION_URL and ADO_PROJECT_NAME (or pass --org-url / --project)")

    secret = os.getenv("WEBHOOK_SECRET", "")
    print(f"Registering ADO Service Hooks → {args.bridge_url}")
    print(f"  org:     {args.org_url}")
    print(f"  project: {args.project}")
    if not secret:
        print("  WEBHOOK_SECRET not set — webhook will accept unsigned requests (dev only)")

    project_id = _get_project_id(args.org_url, args.project)
    print(f"  project_id: {project_id}")

    # Trigger 1: Approved → test_cases stage
    for state in ("Approved", "Committed"):
        sub = _create_subscription(args.org_url, project_id, state, args.bridge_url, secret)
        print(f"  Created subscription id={sub['id']} filter='{state}'")

    # Trigger 2: Done → full_pipeline stage
    sub = _create_subscription(args.org_url, project_id, "Done", args.bridge_url, secret)
    print(f"  Created subscription id={sub['id']} filter='Done'")

    print("Done. Verify in ADO → Project Settings → Service hooks.")


if __name__ == "__main__":
    main()
