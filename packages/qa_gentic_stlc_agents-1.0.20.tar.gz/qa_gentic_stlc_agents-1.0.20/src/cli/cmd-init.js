/**
 * cmd-init.js — `qa-stlc init`
 *
 * Full bootstrap: install Python agents + skills + ORCHESTRATION_RULES.md + MCP config.
 * Accepts --integration <ado|jira|both>.  When omitted, reads
 * ~/.qa-stlc/integration (written by postinstall) or prompts interactively.
 */
"use strict";

const { execSync, spawnSync } = require("child_process");
const path = require("path");
const fs   = require("fs");
const os   = require("os");

const cmdSkills       = require("./cmd-skills");
const cmdMcpConfig    = require("./cmd-mcp-config");
const pickIntegration = require("./prompt-integration");

const PREF_FILE = path.join(os.homedir(), ".qa-stlc", "integration");

function readSavedIntegration() {
  try {
    if (fs.existsSync(PREF_FILE)) return fs.readFileSync(PREF_FILE, "utf8").trim();
  } catch (_) {}
  return null;
}

function saveIntegration(value) {
  try {
    fs.mkdirSync(path.dirname(PREF_FILE), { recursive: true });
    fs.writeFileSync(PREF_FILE, value, "utf8");
  } catch (_) {}
}

const C = {
  reset: "\x1b[0m", bold: "\x1b[1m",
  green: "\x1b[32m", cyan: "\x1b[36m",
  yellow: "\x1b[33m", red: "\x1b[31m", dim: "\x1b[2m",
};
const ok   = (m) => console.log(`${C.green}✓${C.reset}  ${m}`);
const info = (m) => console.log(`${C.cyan}→${C.reset}  ${m}`);
const warn = (m) => console.log(`${C.yellow}⚠${C.reset}  ${m}`);
const die  = (m) => { console.error(`${C.red}✗${C.reset}  ${m}`); process.exit(1); };

module.exports = async function init(opts) {
  console.log(`\n${C.bold}QA STLC Agents — init${C.reset}\n`);

  // ── 1. Check Python ──────────────────────────────────────────────────────
  const python = opts.python || "python3";
  info(`Checking Python (${python})…`);
  const pyCheck = spawnSync(python, ["--version"], { encoding: "utf8" });
  if (pyCheck.status !== 0) {
    die(`Python not found at '${python}'. Install Python 3.10+ or pass --python <path>.`);
  }
  const pyVersion = (pyCheck.stdout || pyCheck.stderr || "").trim();
  const match = pyVersion.match(/Python (\d+)\.(\d+)/);
  if (!match || parseInt(match[1]) < 3 || parseInt(match[2]) < 10) {
    die(`Python 3.10+ required, found: ${pyVersion}`);
  }
  ok(`${pyVersion} found.`);

  // ── 2. Resolve integration choice ────────────────────────────────────────
  // Priority: --integration flag > saved preference > interactive prompt
  let integration = (opts.integration || "").toLowerCase().trim();
  const validIntegrations = ["ado", "jira", "both"];
  if (integration && !validIntegrations.includes(integration)) {
    die(`Invalid --integration value: "${integration}". Use ado, jira, or both.`);
  }
  if (!integration) {
    integration = readSavedIntegration();
  }
  if (!integration) {
    integration = await pickIntegration("ado");
  }
  saveIntegration(integration);

  const needsAdo  = integration === "ado"  || integration === "both";
  const needsJira = integration === "jira" || integration === "both";
  info(`Integration: ${C.bold}${integration}${C.reset}`);

  // ── 3. pip install qa-gentic-stlc-agents ──────────────────────────────────
  info("Installing qa-gentic-stlc-agents (pip)…");
  const pip = spawnSync(python, ["-m", "pip", "install", "qa-gentic-stlc-agents>=1.0.1", "--quiet"], {
    stdio: "inherit",
    encoding: "utf8",
  });
  if (pip.status !== 0) {
    die("pip install failed. Run manually: pip install qa-gentic-stlc-agents");
  }
  ok("qa-gentic-stlc-agents installed.");

  // ── 4. Copy ORCHESTRATION_RULES.md to project root ─────────────────────────
  info("Installing ORCHESTRATION_RULES.md to project root…");
  try {
    const npmPkgDir = path.join(path.dirname(require.resolve("@qa-gentic/stlc-agents/package.json")));
    const srcRules = path.join(npmPkgDir, "ORCHESTRATION_RULES.md");
    const destRules = path.join(process.cwd(), "ORCHESTRATION_RULES.md");
    if (fs.existsSync(srcRules)) {
      fs.copyFileSync(srcRules, destRules);
      ok("ORCHESTRATION_RULES.md copied to project root.");
    } else {
      warn("ORCHESTRATION_RULES.md not found in npm package (expected in development).");
    }
  } catch (e) {
    // Silently skip if not available (common in dev environments before full build)
  }

  // ── 5. Install skills ─────────────────────────────────────────────────────
  info("Installing skills…");
  const skillTarget = opts.vscode ? "vscode" : "claude";
  await cmdSkills({ target: skillTarget, integration });

  // ── 5. Write MCP config ───────────────────────────────────────────────────
  info("Writing MCP config…");
  await cmdMcpConfig({
    vscode:         opts.vscode || false,
    print:          false,
    python:         python,
    playwrightPort: "8931",
    integration,
  });

  // ── 6. Done ───────────────────────────────────────────────────────────────
  const mcpLocation    = opts.vscode ? ".vscode/mcp.json" : ".mcp.json";
  const skillsLocation = opts.vscode
    ? ".github/copilot-instructions/  (reload VS Code window to activate)"
    : ".claude/skills/";

  const adoSection = needsAdo ? `
  ${C.dim}ADO pipeline:${C.reset}
  ${C.dim}1 →${C.reset} ${C.yellow}qa-test-case-manager${C.reset}     ${C.dim}ADO work item → manual test cases${C.reset}
  ${C.dim}2 →${C.reset} ${C.yellow}qa-gherkin-generator${C.reset}     ${C.dim}Epic / Feature / PBI → .feature file${C.reset}
  ${C.dim}3 →${C.reset} ${C.yellow}qa-playwright-generator${C.reset}  ${C.dim}Gherkin + live browser → self-healing Playwright${C.reset}
  ${C.dim}4 →${C.reset} ${C.yellow}qa-helix-writer${C.reset}          ${C.dim}Generated files → Helix-QA project${C.reset}` : "";

  const jiraSection = needsJira ? `
  ${C.dim}Jira pipeline:${C.reset}
  ${C.dim}1 →${C.reset} ${C.yellow}qa-jira-manager${C.reset}          ${C.dim}Fetch Jira issue + analyse acceptance criteria${C.reset}
  ${C.dim}2 →${C.reset} ${C.yellow}qa-jira-manager${C.reset}          ${C.dim}Generate test cases → create in Jira with 'is tested by' links${C.reset}
  ${C.dim}3 →${C.reset} ${C.yellow}qa-gherkin-generator${C.reset}     ${C.dim}Generate Gherkin .feature file from Jira issue AC${C.reset}
  ${C.dim}4 →${C.reset} ${C.yellow}qa-playwright-generator${C.reset}  ${C.dim}Gherkin + live browser → self-healing Playwright TypeScript${C.reset}
  ${C.dim}5 →${C.reset} ${C.yellow}qa-helix-writer${C.reset}          ${C.dim}Generated files → Helix-QA project on disk${C.reset}
  ${C.dim}   Requires: JIRA_CLIENT_ID + JIRA_CLIENT_SECRET + JIRA_CLOUD_ID in .env${C.reset}` : "";

  console.log(`
${C.bold}Setup complete.${C.reset}

  ${C.dim}Integration:${C.reset} ${C.bold}${integration}${C.reset}
  ${C.dim}MCP config :${C.reset} ${mcpLocation}
  ${C.dim}Skills     :${C.reset} ${skillsLocation}
  ${C.dim}Rules      :${C.reset} ORCHESTRATION_RULES.md ${C.dim}(project root — reference for multi-step workflows)${C.reset}

${C.bold}Start Playwright MCP${C.reset} ${C.dim}(keep running in a separate terminal):${C.reset}

  ${C.cyan}npx @playwright/mcp@latest --port 8931${C.reset}

${C.bold}STLC Workflow:${C.reset}
${adoSection}${jiraSection}

${C.dim}Change integration at any time:  qa-stlc init --integration <ado|jira|both>${C.reset}
`);
};