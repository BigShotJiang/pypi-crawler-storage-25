"""
pricing.py  —  Model pricing registry for stlc-agents cost tracking.

Prices: USD per million tokens (MTok).
Source: Anthropic official docs, April 2026.

Models this repo actually calls:
  - claude-sonnet-4-20250514  (LocatorHealer AI Vision, default)
  - gpt-4o                    (LocatorHealer AI Vision, copilot provider)
  + whatever coding agent the user runs (Claude / Copilot / Cursor / Windsurf)
    — the user declares this via STLC_CODING_AGENT_MODEL env var.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class ModelPricing:
    model_id: str
    display_name: str
    provider: str
    input_per_mtok: float        # USD / 1M input tokens
    output_per_mtok: float       # USD / 1M output tokens
    cache_write_per_mtok: float  # USD / 1M cache-write tokens
    cache_read_per_mtok: float   # USD / 1M cache-read tokens

    def cost(
        self,
        input_tokens: int = 0,
        output_tokens: int = 0,
        cache_write_tokens: int = 0,
        cache_read_tokens: int = 0,
    ) -> float:
        return (
            (input_tokens        / 1_000_000) * self.input_per_mtok
            + (output_tokens     / 1_000_000) * self.output_per_mtok
            + (cache_write_tokens/ 1_000_000) * self.cache_write_per_mtok
            + (cache_read_tokens / 1_000_000) * self.cache_read_per_mtok
        )


_REGISTRY: list[ModelPricing] = [
    # ── Anthropic ──────────────────────────────────────────────────────────
    ModelPricing("claude-sonnet-4-20250514", "Claude Sonnet 4",    "anthropic",  3.00, 15.00,  3.75, 0.30),
    ModelPricing("claude-sonnet-4-6",        "Claude Sonnet 4.6",  "anthropic",  3.00, 15.00,  3.75, 0.30),
    ModelPricing("claude-haiku-4-5-20251001","Claude Haiku 4.5",   "anthropic",  1.00,  5.00,  1.25, 0.10),
    ModelPricing("claude-opus-4-6",          "Claude Opus 4.6",    "anthropic",  5.00, 25.00,  6.25, 0.50),
    ModelPricing("claude-opus-4-7",          "Claude Opus 4.7",    "anthropic",  5.00, 25.00,  6.25, 0.50),
    # ── OpenAI / Copilot ──────────────────────────────────────────────────
    ModelPricing("gpt-4o",                   "GPT-4o",             "openai",     2.50, 10.00,  0.00, 0.00),
    ModelPricing("gpt-4o-mini",              "GPT-4o Mini",        "openai",     0.15,  0.60,  0.00, 0.00),
]

_by_id: dict[str, ModelPricing] = {p.model_id: p for p in _REGISTRY}


def get_pricing(model_id: str) -> Optional[ModelPricing]:
    """Exact match first, then longest substring match."""
    key = model_id.lower().strip()
    if key in _by_id:
        return _by_id[key]
    # Substring: "claude-sonnet-4-20250514" ⊇ "sonnet-4"
    for p in _REGISTRY:
        if key in p.model_id or p.model_id in key:
            return p
    return None


def list_models() -> list[ModelPricing]:
    return list(_REGISTRY)