# STLC Agents — Webhook / Auto-Trigger Setup

Automatically trigger the STLC pipeline when work items change state in ADO or Jira.

---

## Trigger Map

| Platform | State | Stage | Agents |
|---|---|---|---|
| ADO | `Approved` or `Committed` | `test_cases` | Agent 1 — `qa-test-case-manager` only |
| ADO | `Done` | `post_done` | Agents 2 → 3 → 4 (Gherkin → Playwright → Helix-QA) |
| Jira | `In Review` / `Ready for QA` | `test_cases` | `qa-jira-manager` test cases only |
| Jira | `Done` / `Closed` | `post_done` | Agents 2 → 3 → 4 (Gherkin → Playwright → Helix-QA) |

> **Why test cases are excluded from Done:** By the time a work item reaches Done,
> test cases were already created when it moved to Approved/Committed. The Done
> stage runs the code generation pipeline only.

State names are configurable in `src/stlc_agents/webhook_bridge/state_router.py`.

---

## Architecture

```
ADO Service Hook / Jira Webhook
          │  POST (JSON payload)
          ▼
Webhook Bridge  (qa-stlc-serve — FastAPI)
          │
          ├─ parsers.py        raw payload → normalised event dict
          ├─ state_router.py   event → STAGE_TEST_CASES | STAGE_FULL_PIPELINE | SKIP
          │
          └─ ci_runner/pipeline.py
                ├─ run_test_cases()  — Agent 1 / qa-jira-manager
                └─ run_post_done()   — Agents 2 → 3 → 4
                      │
                      ├─ mcp_client.py  — drives MCP servers as subprocesses
                      └─ llm_caller.py  — multi-provider LLM calls
```

---

## LLM Provider

The bridge uses the same `AI_HEALING_PROVIDER` env var already in your `.env`.
No new configuration needed if you already have a provider set.

Provider resolution order:
1. `LLM_PROVIDER` env var (explicit override)
2. `AI_HEALING_PROVIDER` env var (already in your `.env`)
3. Auto-detected from whichever API key is present

| Provider | Key(s) needed | Default model |
|---|---|---|
| `anthropic` | `AI_HEALING_API_KEY` or `ANTHROPIC_API_KEY` | `claude-haiku-4-5-20251001` |
| `claude-code` | `ANTHROPIC_API_KEY` (from claude CLI) | `claude-haiku-4-5-20251001` |
| `copilot` | `GITHUB_TOKEN` | `gpt-4o` |
| `openai` | `OPENAI_API_KEY` | `gpt-4o-mini` |
| `azure-openai` | `AZURE_OPENAI_API_KEY` + `AZURE_OPENAI_ENDPOINT` | `gpt-4o-mini` |
| `ollama` | none (`OLLAMA_HOST` optional) | `llama3.2` |

Override the model at any time: `LLM_MODEL=claude-sonnet-4-6`

---

## Quick Start — Local Dev

```bash
# 1. Install extra deps
pip install "qa-gentic-stlc-agents[webhook]"

# 2. Append webhook vars to your existing .env
cat .env.webhook.example >> .env

# 3. Start the bridge
qa-stlc-serve --reload

# 4. Expose via ngrok
ngrok http 8080

# 5. Register hooks
make register-ado-hooks  BRIDGE_URL=https://xxxx.ngrok.io
make register-jira-hooks BRIDGE_URL=https://xxxx.ngrok.io
```

---

## Deploy — Azure Functions

```bash
# Create Function App (Python 3.11)
az functionapp create \
  --resource-group my-rg \
  --consumption-plan-location uksouth \
  --runtime python --runtime-version 3.11 \
  --functions-version 4 \
  --name stlc-webhook-bridge \
  --storage-account mystorageacct

# Set app settings — only add what your provider needs
az functionapp config appsettings set \
  --name stlc-webhook-bridge --resource-group my-rg \
  --settings \
    ADO_ORGANIZATION_URL="https://dev.azure.com/myorg" \
    ADO_PROJECT_NAME="MyProject" \
    ADO_PAT="<pat>" \
    WEBHOOK_SECRET="<secret>" \
    AI_HEALING_PROVIDER="anthropic" \
    AI_HEALING_API_KEY="sk-ant-..." \
    APP_BASE_URL="https://your-app.example.com" \
    HELIX_PROJECT_ROOT="/tmp/helix-qa" \
    PLAYWRIGHT_MCP_URL=""

# Deploy
make deploy-azure FUNC_APP=stlc-webhook-bridge

# Register hooks
make register-ado-hooks  BRIDGE_URL=https://stlc-webhook-bridge.azurewebsites.net/api
make register-jira-hooks BRIDGE_URL=https://stlc-webhook-bridge.azurewebsites.net/api
```

---

## Deploy — Docker

```bash
docker build -f Dockerfile.webhook -t stlc-webhook-bridge .
docker run -p 8080:8080 --env-file .env stlc-webhook-bridge
```

---

## Deploy — GitHub Actions

The workflow triggers via `repository_dispatch` events `stlc_test_cases` and `stlc_post_done`.

Set these repository secrets (only what your provider needs):

```
ADO_ORGANIZATION_URL   ADO_PROJECT_NAME      ADO_PAT
JIRA_CLIENT_ID         JIRA_CLIENT_SECRET    JIRA_CLOUD_ID
AI_HEALING_PROVIDER    AI_HEALING_API_KEY    APP_BASE_URL
# or instead of AI_HEALING_API_KEY:
OPENAI_API_KEY         AZURE_OPENAI_API_KEY  AZURE_OPENAI_ENDPOINT
```

---

## Register ADO Service Hooks

```bash
# Script (recommended)
python scripts/register_ado_hooks.py --bridge-url https://your-bridge

# Manual: ADO → Project Settings → Service hooks → Create subscription
# Service: Web Hooks | Trigger: Work item updated
# Filter field: State → To: Approved    URL: https://your-bridge/webhook/ado
# Filter field: State → To: Done        URL: https://your-bridge/webhook/ado
```

---

## Register Jira Webhook

```bash
python scripts/register_jira_hooks.py --bridge-url https://your-bridge

# Manual: Jira → Settings → System → WebHooks → Create
# URL: https://your-bridge/webhook/jira
# Events: Issue updated, Issue created
```

---

## Customise State Triggers

Edit `src/stlc_agents/webhook_bridge/state_router.py`:

```python
ADO_STATE_MAP = {
    "approved":          STAGE_TEST_CASES,
    "committed":         STAGE_TEST_CASES,
    "ready for testing": STAGE_TEST_CASES,   # custom state
    "done":              STAGE_FULL_PIPELINE,
    "released":          STAGE_FULL_PIPELINE, # custom state
}
```

---

## Playwright in CI

Playwright code generation requires a running browser. If `PLAYWRIGHT_MCP_URL` is empty the stage is skipped gracefully — Gherkin and test cases still run.

```yaml
# docker-compose.ci.yml
services:
  playwright-mcp:
    image: mcr.microsoft.com/playwright:v1.48.0-jammy
    command: npx @playwright/mcp@latest --port 8931 --headless
    ports: ["8931:8931"]
```

Set `PLAYWRIGHT_MCP_URL=http://playwright-mcp:8931/mcp`.

---

## Token Cost (headless mode)

Using Haiku (default) the cost is minimal:

| Stage | Tokens / PBI | Cost |
|---|---|---|
| Test case generation (Approved) | ~8,000–15,000 | $0.01–$0.03 |
| Gherkin (Done) | ~10,000–18,000 | $0.01–$0.04 |
| Playwright TS (Done) | ~20,000–35,000 | $0.03–$0.07 |

Set `LLM_MODEL=claude-sonnet-4-6` or `LLM_MODEL=gpt-4o` for higher quality at higher cost.
Ollama (`LLM_PROVIDER=ollama`) has zero API cost if you have a local GPU.
