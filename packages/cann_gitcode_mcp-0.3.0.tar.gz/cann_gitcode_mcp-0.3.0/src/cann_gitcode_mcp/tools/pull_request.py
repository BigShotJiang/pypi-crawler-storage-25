from __future__ import annotations

import json
from typing import Any, Literal

from mcp.server.fastmcp import FastMCP
from pydantic import BaseModel

from cann_gitcode_mcp.client import GitCodeClient

_MAX_DIFF_LINES = 200


# ---------------------------------------------------------------------------
# Pydantic response models — schema documentation for tool responses.
# Used internally for validation; ready for structured_output when tools
# are split into single-return-type functions.
# ---------------------------------------------------------------------------

class SlimPR(BaseModel):
    number: int
    title: str
    state: str
    html_url: str | None = None
    body: str | None = None
    draft: bool | None = None
    mergeable: bool | None = None
    created_at: str | None = None
    updated_at: str | None = None
    head: str | None = None
    base: str | None = None
    user: str | None = None
    labels: list[str] | None = None


class SlimPRListItem(BaseModel):
    number: int
    title: str
    state: str
    html_url: str | None = None
    draft: bool | None = None
    head: str | None = None
    base: str | None = None
    user: str | None = None
    labels: list[str] | None = None


class SlimFile(BaseModel):
    filename: str | None = None
    status: str | None = None
    additions: int | None = None
    deletions: int | None = None
    diff: str | None = None


class SlimComment(BaseModel):
    id: int | None = None
    body: str | None = None
    created_at: str | None = None
    user: str | None = None

_client: GitCodeClient | None = None


def _get_client() -> GitCodeClient:
    global _client
    if _client is None:
        _client = GitCodeClient()
    return _client


def _text_result(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False)


def _extract_pr_fields(pr: dict[str, Any]) -> dict[str, Any]:
    """Extract common PR fields, resolving nested objects."""
    result: dict[str, Any] = {}
    for key in (
        "number", "title", "state", "html_url", "body",
        "draft", "mergeable", "created_at", "updated_at",
    ):
        if key in pr:
            result[key] = pr[key]
    head = pr.get("head")
    if isinstance(head, dict):
        result["head"] = head.get("ref")
    base = pr.get("base")
    if isinstance(base, dict):
        result["base"] = base.get("ref")
    user = pr.get("user")
    if isinstance(user, dict):
        result["user"] = user.get("login")
    labels = pr.get("labels")
    if isinstance(labels, list):
        result["labels"] = [lb.get("name", lb) if isinstance(lb, dict) else lb for lb in labels]
    return result


def _slim_pr(pr: dict[str, Any]) -> dict[str, Any]:
    """Extract only the fields an LLM needs from a PR object."""
    return SlimPR(**_extract_pr_fields(pr)).model_dump(exclude_none=True)


def _slim_pr_list_item(pr: dict[str, Any]) -> dict[str, Any]:
    """Compact PR summary for list results."""
    return SlimPRListItem(**_extract_pr_fields(pr)).model_dump(exclude_none=True)


def _summary_pr(pr: dict[str, Any]) -> dict[str, Any]:
    """Minimal PR summary for quick overview."""
    fields = _extract_pr_fields(pr)
    return {k: fields[k] for k in ("number", "title", "state", "html_url", "user") if k in fields}


def _summary_pr_list_item(pr: dict[str, Any]) -> dict[str, Any]:
    """Minimal PR list item."""
    fields = _extract_pr_fields(pr)
    return {k: fields[k] for k in ("number", "title", "state") if k in fields}


def _slim_file(f: dict[str, Any]) -> dict[str, Any]:
    """Extract essential fields from a PR file change."""
    raw: dict[str, Any] = {"filename": f.get("filename"), "status": f.get("status")}
    for key in ("additions", "deletions"):
        if key in f:
            raw[key] = f[key]
    patch = f.get("patch")
    if isinstance(patch, dict):
        diff = patch.get("diff")
        if diff:
            raw["diff"] = _truncate_diff(diff)
    elif isinstance(patch, str):
        raw["diff"] = _truncate_diff(patch)
    return SlimFile(**raw).model_dump(exclude_none=True)


def _truncate_diff(diff: str) -> str:
    """Truncate diff to _MAX_DIFF_LINES lines if needed."""
    lines = diff.split("\n")
    if len(lines) <= _MAX_DIFF_LINES:
        return diff
    truncated = "\n".join(lines[:_MAX_DIFF_LINES])
    return f"{truncated}\n[truncated: showing {_MAX_DIFF_LINES}/{len(lines)} lines]"


def _slim_comment(c: dict[str, Any]) -> dict[str, Any]:
    """Extract essential fields from a PR comment."""
    raw: dict[str, Any] = {}
    for key in ("id", "body", "created_at"):
        if key in c:
            raw[key] = c[key]
    user = c.get("user")
    if isinstance(user, dict):
        raw["user"] = user.get("login")
    return SlimComment(**raw).model_dump(exclude_none=True)


def register_pull_request_tools(mcp: FastMCP) -> None:

    @mcp.tool()
    async def pull_request_read(
        owner: str,
        repo: str,
        action: Literal["get", "list", "files", "comments"],
        number: int | None = None,
        detail: str = "full",
        state: str | None = None,
        head: str | None = None,
        base: str | None = None,
        sort: str | None = None,
        direction: str | None = None,
        page: int | None = None,
        per_page: int | None = None,
    ) -> str:
        """Read pull request data from GitCode.

        Args:
            owner: Repository namespace
            repo: Repository name
            action: "get" | "list" | "files" | "comments"
            number: PR number (required for get/files/comments)
            detail: "summary" (minimal) or "full" (default)
            state: open/closed/merged/all (list only)
            head: Filter by source branch (list only)
            base: Filter by target branch (list only)
            sort: created/updated/popularity (list only)
            direction: asc/desc (list only)
            page: Page number
            per_page: Results per page
        """
        client = _get_client()
        is_summary = detail == "summary"

        if action == "list":
            params = {
                k: v for k, v in {
                    "state": state, "head": head, "base": base,
                    "sort": sort, "direction": direction,
                    "page": page, "per_page": per_page,
                }.items() if v is not None
            }
            result = await client.get(f"/repos/{owner}/{repo}/pulls", **params)
            mapper = _summary_pr_list_item if is_summary else _slim_pr_list_item
            return _text_result([mapper(pr) for pr in result])

        # All other actions require number
        if number is None:
            return _text_result({"error": f"number is required for action '{action}'"})

        if action == "get":
            result = await client.get(f"/repos/{owner}/{repo}/pulls/{number}")
            mapper = _summary_pr if is_summary else _slim_pr
            return _text_result(mapper(result))

        if action == "files":
            result = await client.get(f"/repos/{owner}/{repo}/pulls/{number}/files")
            if is_summary:
                return _text_result([
                    {k: v for k, v in {
                        "filename": f.get("filename"),
                        "status": f.get("status"),
                        "additions": f.get("additions"),
                        "deletions": f.get("deletions"),
                    }.items() if v is not None}
                    for f in result
                ])
            return _text_result([_slim_file(f) for f in result])

        if action == "comments":
            params = {
                k: v for k, v in {"page": page, "per_page": per_page}.items()
                if v is not None
            }
            result = await client.get(
                f"/repos/{owner}/{repo}/pulls/{number}/comments", **params,
            )
            return _text_result([_slim_comment(c) for c in result])

        return _text_result({"error": f"unknown action '{action}'"})

    @mcp.tool()
    async def pull_request_write(
        owner: str,
        repo: str,
        action: Literal["create", "merge", "comment"],
        number: int | None = None,
        title: str | None = None,
        head: str | None = None,
        base: str | None = None,
        body: str | None = None,
        draft: bool | None = None,
        labels: str | None = None,
        assignees: str | None = None,
        testers: str | None = None,
        prune_source_branch: bool | None = None,
        squash: bool | None = None,
        merge_method: str | None = None,
    ) -> str:
        """Write pull request data on GitCode.

        Args:
            owner: Repository namespace
            repo: Repository name
            action: "create" | "merge" | "comment"
            number: PR number (required for merge/comment)
            title: PR title (create)
            head: Source branch (create)
            base: Target branch (create)
            body: Description or comment (Markdown)
            draft: Draft PR (create)
            labels: Comma-separated labels (create)
            assignees: Reviewer usernames (create)
            testers: Tester usernames (create)
            prune_source_branch: Delete source branch after merge
            squash: Squash merge (create)
            merge_method: merge/squash/rebase (merge, default merge)
        """
        client = _get_client()

        if action == "create":
            if not title or not head or not base:
                return _text_result({"error": "title, head, and base are required for action 'create'"})
            payload: dict[str, Any] = {"title": title, "head": head, "base": base}
            for key in ("body", "draft", "labels", "assignees", "testers",
                        "prune_source_branch", "squash"):
                val = locals()[key]
                if val is not None:
                    payload[key] = val
            result = await client.post(f"/repos/{owner}/{repo}/pulls", json=payload)
            return _text_result({
                "number": result.get("number"),
                "html_url": result.get("html_url"),
                "action": "created",
            })

        if action == "merge":
            if number is None:
                return _text_result({"error": "number is required for action 'merge'"})
            payload = {"merge_method": merge_method or "merge"}
            if prune_source_branch is not None:
                payload["prune_source_branch"] = prune_source_branch
            await client.put(
                f"/repos/{owner}/{repo}/pulls/{number}/merge", json=payload,
            )
            return _text_result({
                "pr": f"{owner}/{repo}#{number}",
                "action": "merged",
                "merge_method": merge_method or "merge",
            })

        if action == "comment":
            if number is None:
                return _text_result({"error": "number is required for action 'comment'"})
            if not body:
                return _text_result({"error": "body is required for action 'comment'"})
            result = await client.post(
                f"/repos/{owner}/{repo}/pulls/{number}/comments",
                json={"body": body},
            )
            return _text_result(_slim_comment(result))

        return _text_result({"error": f"unknown action '{action}'"})
