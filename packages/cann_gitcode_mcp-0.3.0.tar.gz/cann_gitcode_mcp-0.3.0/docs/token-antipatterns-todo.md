# Token 反模式 TODO

审计日期：2026-03-31
对照规则：AGENTS.md "Token Budget Rules"

## 反模式清单

### AP-1: `pull_request_write(create)` 透传原始 API 响应 [违反 O1, O6]

**文件**: `src/cann_gitcode_mcp/tools/pull_request.py:281`

```python
result = await client.post(f"/repos/{owner}/{repo}/pulls", json=payload)
return _text_result(result)  # ← 原始 API 响应，未裁剪
```

**问题**: create 返回完整 PR 对象（含 `_links`, `permissions`, `mergeable_state` 等 30+ 字段），写操作应只返回确认信息。

**修复**: 返回 `_slim_pr(result)` 或更精简的确认：`{"number": N, "html_url": "...", "action": "created"}`。

**预期节省**: ~200-400 tokens/次

**优先级**: P1

---

### AP-2: `pull_request_write(merge)` 透传原始 API 响应 [违反 O6]

**文件**: `src/cann_gitcode_mcp/tools/pull_request.py:292`

```python
result = await client.put(..., json=payload)
return _text_result(result)  # ← 原始 merge 响应
```

**问题**: merge 响应可能包含冗余字段。写操作应返回精简确认。

**修复**: 只返回 `{"pr": "owner/repo#N", "action": "merged", "merge_method": "..."}`。

**预期节省**: ~50-100 tokens/次

**优先级**: P2

---

### AP-3: `trigger_pr_pipeline` 响应中 message 冗余 [违反 I2 精神]

**文件**: `src/cann_gitcode_mcp/tools/pipeline.py:197-201`

```python
return _text_result({
    "pr": f"{owner}/{repo}#{pr_number}",
    "action": "pipeline_triggered",
    "message": "Posted 'compile' comment. Pipeline will start shortly. "
               "Use get_pr_pipeline_summary to check status.",
    "comment_id": result.get("id"),
})
```

**问题**: `message` 字段是给人看的指引文本，LLM 不需要被告知 "use tool X to do Y"。LLM 自己知道工具链。

**修复**: 删除 `message` 字段，或缩短为 `"status": "triggered"`。

**预期节省**: ~25 tokens/次

**优先级**: P3

---

### AP-4: CLAUDE.md 示例代码使用 `indent=2` [违反 O2]

**文件**: `CLAUDE.md:62`（已修复）

**问题**: 示例代码 `json.dumps(result, indent=2, ...)` 会误导新工具开发者加缩进。

**状态**: ✅ 已修复

---

### AP-5: AGENTS.md "Important Constraints" 也写了 `indent=2` [违反 O2]

**文件**: `AGENTS.md:126`（已修复）

**状态**: ✅ 已修复

---

### AP-6: `get_pr_pipeline_summary` 无结果时返回冗余 message [违反 O6 精神]

**文件**: `src/cann_gitcode_mcp/tools/pipeline.py:246-249`

```python
return _text_result({
    **base_result,
    "pipeline_found": False,
    "message": "No pipeline comments found from cann-robot",
})
```

**问题**: `pipeline_found: False` 已经表达了含义，`message` 冗余。

**修复**: 删除 `message` 字段。

**预期节省**: ~15 tokens/次

**优先级**: P3

---

### AP-7: `pull_request_read(files)` 不支持 `detail="summary"` [违反 O3]

**文件**: `src/cann_gitcode_mcp/tools/pull_request.py:217-218`

**问题**: files action 忽略 `detail` 参数。summary 模式可以只返回 filename + status（不含 diff），显著减少 token。

**修复**: `detail="summary"` 时只返回 `{"filename": ..., "status": ..., "additions": N, "deletions": N}`，不含 diff。

**预期节省**: 50-80% per file（diff 是大头）

**优先级**: P2

---

### AP-8: `pull_request_read(comments)` 不支持 `detail="summary"` [违反 O3]

**文件**: `src/cann_gitcode_mcp/tools/pull_request.py:220-228`

**问题**: comments action 忽略 `detail` 参数。summary 模式可以只返回 user + created_at（不含 body），用于快速浏览。

**修复**: `detail="summary"` 时只返回 `{"id": ..., "user": ..., "created_at": ...}`。

**预期节省**: 40-60% per comment（body 通常最长）

**优先级**: P3

---

### AP-9: 缺少 `pull_request_write(create)` 的 token budget 测试 [违反测试要求]

**文件**: `tests/test_token_budget.py`

**问题**: BUDGETS 中没有 `pull_request_write:create` 的预算定义，也没有对应测试。create 返回原始 API 响应（AP-1），修复后需要加测试守护。

**修复**: 添加 fixture + budget + 测试。

**优先级**: P1（跟 AP-1 一起修复）

---

## 优先级总结

| 优先级 | 编号 | 描述 | 预期节省 |
|--------|------|------|----------|
| **P1** | AP-1 | create PR 透传原始响应 | ~200-400 tok |
| **P1** | AP-9 | create PR 缺 token budget 测试 | 守护 |
| **P2** | AP-2 | merge PR 透传原始响应 | ~50-100 tok |
| **P2** | AP-7 | files 不支持 summary 模式 | 50-80%/file |
| **P3** | AP-3 | trigger_pipeline 冗余 message | ~25 tok |
| **P3** | AP-6 | pipeline 无结果冗余 message | ~15 tok |
| **P3** | AP-8 | comments 不支持 summary 模式 | 40-60%/comment |
| ✅ | AP-4 | CLAUDE.md indent=2 示例 | 已修复 |
| ✅ | AP-5 | AGENTS.md indent=2 约束 | 已修复 |
