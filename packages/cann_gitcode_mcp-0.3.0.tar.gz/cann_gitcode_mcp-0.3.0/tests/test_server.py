from cann_gitcode_mcp.server import mcp


def test_all_tools_registered():
    """Verify all tools are registered on the MCP server."""
    tools = mcp._tool_manager._tools
    expected_tools = [
        # PR tools (merged into read/write)
        "pull_request_read",
        "pull_request_write",
        # Pipeline tools
        "get_pr_pipeline_summary",
        "trigger_pr_pipeline",
    ]
    for tool_name in expected_tools:
        assert tool_name in tools, f"Tool '{tool_name}' not registered"


def test_server_metadata():
    """Verify server name."""
    assert mcp.name == "gitcode"
