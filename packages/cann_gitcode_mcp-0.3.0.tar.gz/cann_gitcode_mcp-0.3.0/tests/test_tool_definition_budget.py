"""Tool definition token budget tests.

Guards against tool definition bloat that inflates every conversation's
context window.
"""
from __future__ import annotations

import json
import os
from unittest.mock import patch

import pytest
from mcp.server.fastmcp import FastMCP

from cann_gitcode_mcp.tools.pull_request import register_pull_request_tools
from cann_gitcode_mcp.tools.pipeline import register_pipeline_tools


def _token_count(text: str) -> int:
    return len(text) // 4


@pytest.fixture
def full_server():
    server = FastMCP("test")
    with patch.dict(os.environ, {"GITCODE_API_TOKEN": "test-token"}):
        register_pull_request_tools(server)
        register_pipeline_tools(server)
    return server


class TestToolDefinitionBudget:
    MAX_TOOLS = 4
    MAX_TOTAL_TOKENS = 1300

    def test_tool_count(self, full_server):
        tools = full_server._tool_manager._tools
        assert len(tools) <= self.MAX_TOOLS, (
            f"Tool count {len(tools)} exceeds budget {self.MAX_TOOLS}. "
            f"Tools: {list(tools.keys())}"
        )

    def test_total_definition_tokens(self, full_server):
        tools = full_server._tool_manager._tools
        total = 0
        details = []
        for name, tool in tools.items():
            schema = json.dumps(tool.parameters, ensure_ascii=False)
            desc = tool.description or ""
            tool_text = f"{name}: {desc}\n{schema}"
            tokens = _token_count(tool_text)
            details.append((name, tokens))
            total += tokens

        print("\n" + "=" * 50)
        print("TOOL DEFINITION TOKEN REPORT")
        print("=" * 50)
        for name, tokens in sorted(details, key=lambda x: -x[1]):
            print(f"  {name:35s} {tokens:>5} tokens")
        print(f"  {'TOTAL':35s} {total:>5} tokens")
        print("=" * 50)

        assert total <= self.MAX_TOTAL_TOKENS, (
            f"Total definition tokens {total} exceeds budget {self.MAX_TOTAL_TOKENS}"
        )
