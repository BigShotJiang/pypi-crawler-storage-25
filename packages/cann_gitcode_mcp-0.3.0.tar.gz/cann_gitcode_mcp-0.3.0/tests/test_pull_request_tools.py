from __future__ import annotations

import json
from unittest.mock import AsyncMock, patch

import pytest

from cann_gitcode_mcp.tools.pull_request import register_pull_request_tools


@pytest.fixture(autouse=True)
def reset_client():
    """Reset the module-level client singleton between tests."""
    import cann_gitcode_mcp.tools.pull_request as pr_mod
    pr_mod._client = None
    yield
    pr_mod._client = None


@pytest.fixture
def mock_client():
    """Return a mock GitCodeClient and patch _get_client to return it."""
    client = AsyncMock()
    with patch("cann_gitcode_mcp.tools.pull_request._get_client", return_value=client):
        yield client


@pytest.fixture
def mcp_server():
    from mcp.server.fastmcp import FastMCP
    server = FastMCP("test")
    register_pull_request_tools(server)
    return server


class TestPullRequestReadGet:
    async def test_get_pr(self, mock_client, mcp_server):
        mock_client.get.return_value = {
            "number": 42,
            "title": "fix: build",
            "state": "open",
            "mergeable": True,
        }

        tool_fn = mcp_server._tool_manager._tools["pull_request_read"].fn
        result = await tool_fn(owner="org", repo="repo", action="get", number=42)

        parsed = json.loads(result)
        assert parsed["number"] == 42
        assert parsed["mergeable"] is True

        mock_client.get.assert_called_once_with("/repos/org/repo/pulls/42")

    async def test_get_pr_summary(self, mock_client, mcp_server):
        mock_client.get.return_value = {
            "number": 42, "title": "fix: build", "state": "open",
            "html_url": "https://gitcode.com/org/repo/pulls/42",
            "body": "Long description here...", "draft": False,
            "mergeable": True, "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-02T00:00:00Z",
            "user": {"login": "dev1", "id": 999},
        }
        tool_fn = mcp_server._tool_manager._tools["pull_request_read"].fn
        result = await tool_fn(
            owner="org", repo="repo", action="get", number=42, detail="summary",
        )
        parsed = json.loads(result)
        assert parsed["number"] == 42
        assert parsed["title"] == "fix: build"
        assert parsed["user"] == "dev1"
        # summary must NOT contain these fields
        assert "body" not in parsed
        assert "draft" not in parsed
        assert "created_at" not in parsed
        assert "mergeable" not in parsed

    async def test_get_pr_missing_number(self, mock_client, mcp_server):
        tool_fn = mcp_server._tool_manager._tools["pull_request_read"].fn
        result = await tool_fn(owner="org", repo="repo", action="get")

        parsed = json.loads(result)
        assert "error" in parsed
        assert "number is required" in parsed["error"]


class TestPullRequestReadList:
    async def test_list_prs_default(self, mock_client, mcp_server):
        mock_client.get.return_value = [
            {"number": 1, "title": "PR one", "state": "open"},
            {"number": 2, "title": "PR two", "state": "open"},
        ]

        tool_fn = mcp_server._tool_manager._tools["pull_request_read"].fn
        result = await tool_fn(owner="org", repo="repo", action="list")

        parsed = json.loads(result)
        assert len(parsed) == 2
        assert parsed[0]["number"] == 1

    async def test_list_prs_with_filters(self, mock_client, mcp_server):
        mock_client.get.return_value = []

        tool_fn = mcp_server._tool_manager._tools["pull_request_read"].fn
        await tool_fn(
            owner="org", repo="repo", action="list",
            state="closed", page=2, per_page=10,
        )

        mock_client.get.assert_called_once_with(
            "/repos/org/repo/pulls",
            state="closed", page=2, per_page=10,
        )

    async def test_list_prs_filter_by_head(self, mock_client, mcp_server):
        mock_client.get.return_value = [
            {"number": 5, "title": "feat: new", "state": "open"},
        ]

        tool_fn = mcp_server._tool_manager._tools["pull_request_read"].fn
        result = await tool_fn(
            owner="org", repo="repo", action="list",
            state="open", head="my-feature",
        )

        mock_client.get.assert_called_once_with(
            "/repos/org/repo/pulls",
            state="open", head="my-feature",
        )
        parsed = json.loads(result)
        assert len(parsed) == 1
        assert parsed[0]["number"] == 5

    async def test_list_prs_summary(self, mock_client, mcp_server):
        mock_client.get.return_value = [
            {"number": 1, "title": "PR one", "state": "open",
             "html_url": "https://gitcode.com/org/repo/pulls/1",
             "draft": False, "body": "desc", "user": {"login": "dev1"},
             "head": {"ref": "feat-a"}, "base": {"ref": "main"},
             "labels": [{"name": "bug"}]},
            {"number": 2, "title": "PR two", "state": "open",
             "html_url": "https://gitcode.com/org/repo/pulls/2"},
        ]
        tool_fn = mcp_server._tool_manager._tools["pull_request_read"].fn
        result = await tool_fn(
            owner="org", repo="repo", action="list", detail="summary",
        )
        parsed = json.loads(result)
        assert len(parsed) == 2
        for item in parsed:
            assert "number" in item
            assert "title" in item
            assert "state" in item
            # summary list items should NOT have these
            assert "html_url" not in item
            assert "draft" not in item
            assert "user" not in item

    async def test_list_prs_filter_by_base(self, mock_client, mcp_server):
        mock_client.get.return_value = []

        tool_fn = mcp_server._tool_manager._tools["pull_request_read"].fn
        await tool_fn(owner="org", repo="repo", action="list", base="master")

        mock_client.get.assert_called_once_with(
            "/repos/org/repo/pulls",
            base="master",
        )


class TestPullRequestReadFiles:
    async def test_get_pr_files(self, mock_client, mcp_server):
        mock_client.get.return_value = [
            {"filename": "src/main.py", "status": "modified", "additions": 10, "deletions": 2},
            {"filename": "tests/test_main.py", "status": "added", "additions": 25, "deletions": 0},
        ]

        tool_fn = mcp_server._tool_manager._tools["pull_request_read"].fn
        result = await tool_fn(owner="org", repo="repo", action="files", number=42)

        parsed = json.loads(result)
        assert len(parsed) == 2
        assert parsed[0]["filename"] == "src/main.py"

        mock_client.get.assert_called_once_with("/repos/org/repo/pulls/42/files")

    async def test_get_pr_files_missing_number(self, mock_client, mcp_server):
        tool_fn = mcp_server._tool_manager._tools["pull_request_read"].fn
        result = await tool_fn(owner="org", repo="repo", action="files")

        parsed = json.loads(result)
        assert "error" in parsed


class TestPullRequestReadComments:
    async def test_list_pr_comments(self, mock_client, mcp_server):
        mock_client.get.return_value = [
            {"id": 1, "body": "LGTM"},
            {"id": 2, "body": "Needs changes"},
        ]

        tool_fn = mcp_server._tool_manager._tools["pull_request_read"].fn
        result = await tool_fn(owner="org", repo="repo", action="comments", number=42)

        parsed = json.loads(result)
        assert len(parsed) == 2

        mock_client.get.assert_called_once_with(
            "/repos/org/repo/pulls/42/comments",
        )

    async def test_list_pr_comments_missing_number(self, mock_client, mcp_server):
        tool_fn = mcp_server._tool_manager._tools["pull_request_read"].fn
        result = await tool_fn(owner="org", repo="repo", action="comments")

        parsed = json.loads(result)
        assert "error" in parsed


class TestPullRequestWriteCreate:
    async def test_create_pr_minimal(self, mock_client, mcp_server):
        mock_client.post.return_value = {
            "number": 42,
            "title": "fix: build error",
            "html_url": "https://gitcode.com/org/repo/pulls/42",
            "state": "open",
        }

        tool_fn = mcp_server._tool_manager._tools["pull_request_write"].fn
        result = await tool_fn(
            owner="org", repo="repo", action="create",
            title="fix: build error", head="fix-branch", base="main",
        )

        parsed = json.loads(result)
        assert parsed["number"] == 42
        assert parsed["html_url"] == "https://gitcode.com/org/repo/pulls/42"

        mock_client.post.assert_called_once_with(
            "/repos/org/repo/pulls",
            json={"title": "fix: build error", "head": "fix-branch", "base": "main"},
        )

    async def test_create_pr_with_optional_fields(self, mock_client, mcp_server):
        mock_client.post.return_value = {"number": 43, "html_url": "https://gitcode.com/org/repo/merge_requests/43", "draft": True}

        tool_fn = mcp_server._tool_manager._tools["pull_request_write"].fn
        result = await tool_fn(
            owner="org", repo="repo", action="create",
            title="wip: new feature", head="feat-branch", base="develop",
            body="## Summary\nNew feature", draft=True, labels="enhancement",
        )

        parsed = json.loads(result)
        assert parsed["action"] == "created"
        assert parsed["number"] == 43

        call_json = mock_client.post.call_args[1]["json"]
        assert call_json["body"] == "## Summary\nNew feature"
        assert call_json["draft"] is True
        assert call_json["labels"] == "enhancement"

    async def test_create_pr_missing_required(self, mock_client, mcp_server):
        tool_fn = mcp_server._tool_manager._tools["pull_request_write"].fn
        result = await tool_fn(
            owner="org", repo="repo", action="create",
        )

        parsed = json.loads(result)
        assert "error" in parsed


class TestPullRequestWriteMerge:
    async def test_merge_pr_default(self, mock_client, mcp_server):
        mock_client.put.return_value = {"sha": "abc123", "merged": True}

        tool_fn = mcp_server._tool_manager._tools["pull_request_write"].fn
        result = await tool_fn(
            owner="org", repo="repo", action="merge", number=42,
        )

        parsed = json.loads(result)
        assert parsed["action"] == "merged"
        assert parsed["pr"] == "org/repo#42"

        mock_client.put.assert_called_once_with(
            "/repos/org/repo/pulls/42/merge",
            json={"merge_method": "merge"},
        )

    async def test_merge_pr_squash(self, mock_client, mcp_server):
        mock_client.put.return_value = {"sha": "def456", "merged": True}

        tool_fn = mcp_server._tool_manager._tools["pull_request_write"].fn
        await tool_fn(
            owner="org", repo="repo", action="merge",
            number=42, merge_method="squash",
        )

        call_json = mock_client.put.call_args[1]["json"]
        assert call_json["merge_method"] == "squash"

    async def test_merge_pr_missing_number(self, mock_client, mcp_server):
        tool_fn = mcp_server._tool_manager._tools["pull_request_write"].fn
        result = await tool_fn(
            owner="org", repo="repo", action="merge",
        )

        parsed = json.loads(result)
        assert "error" in parsed
        assert "number is required" in parsed["error"]


class TestPullRequestWriteComment:
    async def test_comment_pr(self, mock_client, mcp_server):
        mock_client.post.return_value = {
            "id": 100,
            "body": "LGTM!",
        }

        tool_fn = mcp_server._tool_manager._tools["pull_request_write"].fn
        result = await tool_fn(
            owner="org", repo="repo", action="comment",
            number=42, body="LGTM!",
        )

        parsed = json.loads(result)
        assert parsed["body"] == "LGTM!"

        mock_client.post.assert_called_once_with(
            "/repos/org/repo/pulls/42/comments",
            json={"body": "LGTM!"},
        )

    async def test_comment_pr_missing_number(self, mock_client, mcp_server):
        tool_fn = mcp_server._tool_manager._tools["pull_request_write"].fn
        result = await tool_fn(
            owner="org", repo="repo", action="comment",
            body="LGTM!",
        )

        parsed = json.loads(result)
        assert "error" in parsed

    async def test_comment_pr_missing_body(self, mock_client, mcp_server):
        tool_fn = mcp_server._tool_manager._tools["pull_request_write"].fn
        result = await tool_fn(
            owner="org", repo="repo", action="comment",
            number=42,
        )

        parsed = json.loads(result)
        assert "error" in parsed


# ---------------------------------------------------------------------------
# Diff truncation tests
# ---------------------------------------------------------------------------

class TestDiffTruncation:
    """Test that large diffs are truncated in _slim_file."""

    async def test_short_diff_not_truncated(self, mock_client, mcp_server):
        short_diff = "\n".join(f"+line {i}" for i in range(50))
        mock_client.get.return_value = [
            {"filename": "a.py", "status": "modified", "additions": 50,
             "deletions": 0, "patch": short_diff},
        ]
        tool_fn = mcp_server._tool_manager._tools["pull_request_read"].fn
        result = await tool_fn(
            owner="org", repo="repo", action="files", number=1,
        )
        parsed = json.loads(result)
        assert "[truncated" not in parsed[0]["diff"]
        assert parsed[0]["diff"] == short_diff

    async def test_long_diff_truncated(self, mock_client, mcp_server):
        long_diff = "\n".join(f"+line {i}" for i in range(500))
        mock_client.get.return_value = [
            {"filename": "big.py", "status": "modified", "additions": 500,
             "deletions": 0, "patch": long_diff},
        ]
        tool_fn = mcp_server._tool_manager._tools["pull_request_read"].fn
        result = await tool_fn(
            owner="org", repo="repo", action="files", number=1,
        )
        parsed = json.loads(result)
        assert "[truncated: showing 200/500 lines]" in parsed[0]["diff"]
        lines = parsed[0]["diff"].split("\n")
        assert lines[-1].startswith("[truncated")
