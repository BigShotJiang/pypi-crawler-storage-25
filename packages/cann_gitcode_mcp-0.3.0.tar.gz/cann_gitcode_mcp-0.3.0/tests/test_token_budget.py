"""End-to-end token budget tests.

These tests feed real API response fixtures through the actual tool functions
and assert that the output stays within a token budget.  This guards against
regressions that would inflate the context window for MCP clients.

Token counting uses len(text) // 4 as a simple approximation — conservative
enough for mixed Chinese/English content without requiring tiktoken.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, patch

import pytest
from mcp.server.fastmcp import FastMCP

from cann_gitcode_mcp.tools.pipeline import (
    _parse_pipeline_comment,
    register_pipeline_tools,
)
from cann_gitcode_mcp.tools.pull_request import register_pull_request_tools

FIXTURES = Path(__file__).parent / "fixtures"


def _load(name: str) -> Any:
    return json.loads((FIXTURES / f"{name}.json").read_text("utf-8"))


def _token_count(text: str) -> int:
    """Approximate token count: len / 4 for mixed CJK/ASCII."""
    return len(text) // 4


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _reset_clients():
    import cann_gitcode_mcp.tools.pull_request as pr_mod
    import cann_gitcode_mcp.tools.pipeline as pl_mod
    pr_mod._client = None
    pl_mod._client = None
    yield
    pr_mod._client = None
    pl_mod._client = None


@pytest.fixture
def pr_mock():
    client = AsyncMock()
    with patch("cann_gitcode_mcp.tools.pull_request._get_client", return_value=client):
        yield client


@pytest.fixture
def pipeline_mock():
    client = AsyncMock()
    with patch("cann_gitcode_mcp.tools.pipeline._get_client", return_value=client):
        yield client


@pytest.fixture
def pr_server():
    server = FastMCP("test")
    register_pull_request_tools(server)
    return server


@pytest.fixture
def pipeline_server():
    server = FastMCP("test")
    register_pipeline_tools(server)
    return server


# ---------------------------------------------------------------------------
# Token budgets — update these if you intentionally change response shape.
# The budget is per-tool-call, NOT per-item.
# ---------------------------------------------------------------------------

BUDGETS: dict[str, int] = {
    "pull_request_read:get": 200,
    "pull_request_read:get:summary": 50,
    "pull_request_read:list": 250,       # for up to 5 PRs
    "pull_request_read:list:summary": 50,
    "pull_request_read:files": 150,
    "pull_request_read:files:summary": 60,
    "pull_request_read:comments": 80,
    "pull_request_write:comment": 60,
    "pull_request_write:create": 60,
    "pull_request_write:merge": 40,
    "trigger_pr_pipeline": 100,
    "get_pr_pipeline_summary": 600,  # pipeline with many tasks
}


# ---------------------------------------------------------------------------
# PR tool token tests (consolidated pull_request_read / pull_request_write)
# ---------------------------------------------------------------------------

class TestPRToolTokenBudget:
    """Feed real fixtures through PR tools and check token budgets."""

    async def test_get_pull_request(self, pr_mock, pr_server):
        pr_mock.get.return_value = _load("get_pull_request")
        tool = pr_server._tool_manager._tools["pull_request_read"].fn
        result = await tool(
            owner="shengnan666", repo="cann-gitcode-mcp",
            action="get", number=1,
        )

        tokens = _token_count(result)
        budget = BUDGETS["pull_request_read:get"]
        assert tokens <= budget, (
            f"pull_request_read(get): {tokens} tokens > budget {budget}\n"
            f"Response:\n{result}"
        )
        parsed = json.loads(result)
        assert "number" in parsed
        assert "title" in parsed
        assert "state" in parsed
        assert "html_url" in parsed
        assert "head" in parsed
        assert "base" in parsed

    async def test_get_pull_request_summary(self, pr_mock, pr_server):
        pr_mock.get.return_value = _load("get_pull_request")
        tool = pr_server._tool_manager._tools["pull_request_read"].fn
        result = await tool(
            owner="shengnan666", repo="cann-gitcode-mcp",
            action="get", number=1, detail="summary",
        )
        tokens = _token_count(result)
        budget = BUDGETS["pull_request_read:get:summary"]
        assert tokens <= budget, (
            f"pull_request_read(get,summary): {tokens} tokens > budget {budget}\n"
            f"Response:\n{result}"
        )

    async def test_list_pull_requests_summary(self, pr_mock, pr_server):
        pr_mock.get.return_value = _load("list_pull_requests")
        tool = pr_server._tool_manager._tools["pull_request_read"].fn
        result = await tool(
            owner="shengnan666", repo="cann-gitcode-mcp",
            action="list", detail="summary",
        )
        tokens = _token_count(result)
        budget = BUDGETS["pull_request_read:list:summary"]
        assert tokens <= budget, (
            f"pull_request_read(list,summary): {tokens} tokens > budget {budget}\n"
            f"Response:\n{result}"
        )

    async def test_list_pull_requests(self, pr_mock, pr_server):
        pr_mock.get.return_value = _load("list_pull_requests")
        tool = pr_server._tool_manager._tools["pull_request_read"].fn
        result = await tool(
            owner="shengnan666", repo="cann-gitcode-mcp",
            action="list",
        )

        tokens = _token_count(result)
        budget = BUDGETS["pull_request_read:list"]
        assert tokens <= budget, (
            f"pull_request_read(list): {tokens} tokens > budget {budget}\n"
            f"Response:\n{result}"
        )
        parsed = json.loads(result)
        assert isinstance(parsed, list)
        for item in parsed:
            assert "number" in item
            assert "title" in item

    async def test_get_pull_request_files(self, pr_mock, pr_server):
        pr_mock.get.return_value = _load("get_pull_request_files")
        tool = pr_server._tool_manager._tools["pull_request_read"].fn
        result = await tool(
            owner="shengnan666", repo="cann-gitcode-mcp",
            action="files", number=1,
        )

        tokens = _token_count(result)
        budget = BUDGETS["pull_request_read:files"]
        assert tokens <= budget, (
            f"pull_request_read(files): {tokens} tokens > budget {budget}\n"
            f"Response:\n{result}"
        )
        parsed = json.loads(result)
        assert isinstance(parsed, list)
        for item in parsed:
            assert "filename" in item
            assert "status" in item

    async def test_get_pull_request_files_summary(self, pr_mock, pr_server):
        pr_mock.get.return_value = _load("get_pull_request_files")
        tool = pr_server._tool_manager._tools["pull_request_read"].fn
        result = await tool(
            owner="shengnan666", repo="cann-gitcode-mcp",
            action="files", number=1, detail="summary",
        )

        tokens = _token_count(result)
        budget = BUDGETS["pull_request_read:files:summary"]
        assert tokens <= budget, (
            f"pull_request_read(files,summary): {tokens} tokens > budget {budget}\n"
            f"Response:\n{result}"
        )
        parsed = json.loads(result)
        assert isinstance(parsed, list)
        for item in parsed:
            assert "filename" in item
            assert "diff" not in item

    async def test_list_pull_request_comments(self, pr_mock, pr_server):
        pr_mock.get.return_value = _load("list_pull_request_comments")
        tool = pr_server._tool_manager._tools["pull_request_read"].fn
        result = await tool(
            owner="shengnan666", repo="cann-gitcode-mcp",
            action="comments", number=1,
        )

        tokens = _token_count(result)
        budget = BUDGETS["pull_request_read:comments"]
        assert tokens <= budget, (
            f"pull_request_read(comments): {tokens} tokens > budget {budget}\n"
            f"Response:\n{result}"
        )
        parsed = json.loads(result)
        assert isinstance(parsed, list)
        for item in parsed:
            assert "body" in item
            assert "user" in item

    async def test_create_pull_request(self, pr_mock, pr_server):
        pr_mock.post.return_value = _load("create_pull_request")
        tool = pr_server._tool_manager._tools["pull_request_write"].fn
        result = await tool(
            owner="shengnan666", repo="cann-gitcode-mcp",
            action="create", title="feat: new feature",
            head="feat/new-feature", base="main",
        )

        tokens = _token_count(result)
        budget = BUDGETS["pull_request_write:create"]
        assert tokens <= budget, (
            f"pull_request_write(create): {tokens} tokens > budget {budget}\n"
            f"Response:\n{result}"
        )
        parsed = json.loads(result)
        assert parsed["action"] == "created"
        assert "number" in parsed
        assert "html_url" in parsed

    async def test_comment_pull_request(self, pr_mock, pr_server):
        pr_mock.post.return_value = _load("comment_pull_request")
        tool = pr_server._tool_manager._tools["pull_request_write"].fn
        result = await tool(
            owner="shengnan666", repo="cann-gitcode-mcp",
            action="comment", number=1, body="LGTM!",
        )

        tokens = _token_count(result)
        budget = BUDGETS["pull_request_write:comment"]
        assert tokens <= budget, (
            f"pull_request_write(comment): {tokens} tokens > budget {budget}\n"
            f"Response:\n{result}"
        )

    async def test_merge_pull_request(self, pr_mock, pr_server):
        pr_mock.put.return_value = _load("merge_pull_request")
        tool = pr_server._tool_manager._tools["pull_request_write"].fn
        result = await tool(
            owner="org", repo="repo",
            action="merge", number=1,
        )

        tokens = _token_count(result)
        budget = BUDGETS["pull_request_write:merge"]
        assert tokens <= budget, (
            f"pull_request_write(merge): {tokens} tokens > budget {budget}\n"
            f"Response:\n{result}"
        )


# ---------------------------------------------------------------------------
# Pipeline tool token tests
# ---------------------------------------------------------------------------

class TestPipelineToolTokenBudget:
    """Feed real fixtures through pipeline tools and check token budgets."""

    async def test_trigger_pr_pipeline(self, pipeline_mock, pipeline_server):
        pipeline_mock.post.return_value = {"id": 12345, "body": "compile"}
        tool = pipeline_server._tool_manager._tools["trigger_pr_pipeline"].fn
        result = await tool(owner="cann", repo="ge", pr_number=1647)

        tokens = _token_count(result)
        budget = BUDGETS["trigger_pr_pipeline"]
        assert tokens <= budget, (
            f"trigger_pr_pipeline: {tokens} tokens > budget {budget}\n"
            f"Response:\n{result}"
        )

    async def test_get_pr_pipeline_summary(self, pipeline_mock, pipeline_server):
        """Use real pipeline PR + comments fixtures."""
        pr_detail = _load("pipeline_get_pull_request")
        comments = _load("pipeline_list_comments")

        pipeline_mock.get.side_effect = [
            pr_detail,   # PR detail call
            comments,    # comments page 1 (< 100, so pagination stops)
        ]

        tool = pipeline_server._tool_manager._tools["get_pr_pipeline_summary"].fn
        result = await tool(owner="cann", repo="ge", pr_number=1647)

        tokens = _token_count(result)
        budget = BUDGETS["get_pr_pipeline_summary"]
        assert tokens <= budget, (
            f"get_pr_pipeline_summary: {tokens} tokens > budget {budget}\n"
            f"Response:\n{result}"
        )
        parsed = json.loads(result)
        assert "pipeline_status" in parsed
        assert "pr" in parsed


# ---------------------------------------------------------------------------
# Reduction ratio report — not an assertion, just informational
# ---------------------------------------------------------------------------

class TestTokenReductionReport:
    """Print a before/after comparison showing token savings."""

    def test_print_reduction_report(self):
        """Informational: show raw vs slim token counts for each fixture."""
        cases = [
            ("pull_request_read(get)", "get_pull_request",
             lambda d: json.dumps(d, indent=2, ensure_ascii=False),
             lambda d: self._slim_pr_result(d)),
            ("pull_request_read(list)", "list_pull_requests",
             lambda d: json.dumps(d, indent=2, ensure_ascii=False),
             lambda d: self._slim_list_result(d)),
            ("pull_request_read(files)", "get_pull_request_files",
             lambda d: json.dumps(d, indent=2, ensure_ascii=False),
             lambda d: self._slim_files_result(d)),
            ("pull_request_read(comments)", "list_pull_request_comments",
             lambda d: json.dumps(d, indent=2, ensure_ascii=False),
             lambda d: self._slim_comments_result(d)),
            ("pipeline (internal PR data)",
             "pipeline_get_pull_request",
             lambda d: json.dumps(d, indent=2, ensure_ascii=False),
             lambda d: json.dumps(d, indent=2, ensure_ascii=False)),
        ]

        print("\n" + "=" * 70)
        print("TOKEN REDUCTION REPORT")
        print("=" * 70)
        print(f"{'Tool':<45} {'Before':>7} {'After':>7} {'Saved':>7} {'%':>5}")
        print("-" * 70)

        for label, fixture_name, raw_fn, slim_fn in cases:
            data = _load(fixture_name)
            raw = raw_fn(data)
            slim = slim_fn(data)
            raw_tok = _token_count(raw)
            slim_tok = _token_count(slim)
            saved = raw_tok - slim_tok
            pct = (saved / raw_tok * 100) if raw_tok > 0 else 0
            print(f"{label:<45} {raw_tok:>7} {slim_tok:>7} {saved:>7} {pct:>4.0f}%")

        print("=" * 70)

    @staticmethod
    def _slim_pr_result(data: dict) -> str:
        from cann_gitcode_mcp.tools.pull_request import _slim_pr, _text_result
        return _text_result(_slim_pr(data))

    @staticmethod
    def _slim_list_result(data: list) -> str:
        from cann_gitcode_mcp.tools.pull_request import _slim_pr_list_item, _text_result
        return _text_result([_slim_pr_list_item(pr) for pr in data])

    @staticmethod
    def _slim_files_result(data: list) -> str:
        from cann_gitcode_mcp.tools.pull_request import _slim_file, _text_result
        return _text_result([_slim_file(f) for f in data])

    @staticmethod
    def _slim_comments_result(data: list) -> str:
        from cann_gitcode_mcp.tools.pull_request import _slim_comment, _text_result
        return _text_result([_slim_comment(c) for c in data])
