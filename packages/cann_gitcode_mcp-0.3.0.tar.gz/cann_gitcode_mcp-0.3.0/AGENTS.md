# AGENTS.md — cann-gitcode-mcp

## Project Overview

`cann-gitcode-mcp` is an MCP server that exposes GitCode REST API (v5, base `https://gitcode.com/api/v5`) as MCP tools for CANN developers. Package: `cann-gitcode-mcp`; module: `cann_gitcode_mcp`.

## Quick Reference

```bash
uv pip install -e ".[dev]"   # Install (or: pip install -e ".[dev]")
pytest -v                     # Run tests
python -m cann_gitcode_mcp    # Start MCP server (stdio)
```

| Env Variable | Required | Description |
|---|---|---|
| `GITCODE_API_TOKEN` | Yes | Personal access token from GitCode |
| `GITCODE_API_BASE_URL` | No | Override API base (default: `https://gitcode.com/api/v5`) |

## Architecture

```
src/cann_gitcode_mcp/
├── __init__.py          # Package metadata
├── __main__.py          # python -m entry → server.main()
├── server.py            # FastMCP instance; wires all tool modules
├── client.py            # GitCodeClient (async httpx wrapper)
└── tools/
    ├── __init__.py
    ├── pull_request.py  # 7 PR tools
    └── pipeline.py      # 2 pipeline tools (trigger + summary)
```

- **`server.py`** — creates `FastMCP("gitcode")`, calls every `register_*_tools(mcp)`. Single wiring point.
- **`client.py`** — `GitCodeClient` reads `GITCODE_API_TOKEN` from env, provides async `get/post/patch/put/delete`. Raises `ValueError` if token unset, `RuntimeError` on non-2xx.
- **`tools/`** — each file owns one domain. Tools registered via `@mcp.tool()` inside `register_*_tools(mcp)`.

## Code Rules

1. **Python 3.11+** — `from __future__ import annotations` at top of every file.
2. **Async** — all tool functions must be `async def`.
3. **Type hints** — all parameters and return types annotated.
4. **Return `str`** — `json.dumps(data, ensure_ascii=False)`, no `indent`.
5. **Docstrings** — first line = MCP tool description; `Args:` for params.
6. **Registration** — tools via `@mcp.tool()` inside `register_*_tools(mcp)`, never at module import time.
7. **No bare exceptions** — let errors propagate; MCP framework surfaces them.
8. **No global state beyond `_client`** — the singleton is reset between tests via `patch`.

## Adding a New Tool

### 1. Create `src/cann_gitcode_mcp/tools/<domain>.py`

```python
from __future__ import annotations
import json
from mcp.server.fastmcp import FastMCP
from cann_gitcode_mcp.client import GitCodeClient

_client: GitCodeClient | None = None

def _get_client() -> GitCodeClient:
    global _client
    if _client is None:
        _client = GitCodeClient()
    return _client

def register_<domain>_tools(mcp: FastMCP) -> None:

    @mcp.tool()
    async def get_thing(owner: str, repo: str, number: int) -> str:
        """One-line description for MCP.

        Args:
            owner: Repository namespace
            repo: Repository name
            number: Item number
        """
        client = _get_client()
        result = await client.get(f"/repos/{owner}/{repo}/things/{number}")
        return json.dumps(result, ensure_ascii=False)
```

### 2. Register in `server.py`

```python
from cann_gitcode_mcp.tools.<domain> import register_<domain>_tools
register_<domain>_tools(mcp)
```

### 3. Add tests in `tests/test_<domain>.py`

```python
import pytest
from unittest.mock import AsyncMock, patch
from mcp.server.fastmcp import FastMCP

@pytest.fixture
def mcp_server():
    server = FastMCP("test")
    with patch("cann_gitcode_mcp.tools.<domain>._client", None), \
         patch.dict("os.environ", {"GITCODE_API_TOKEN": "test-token"}):
        register_<domain>_tools(server)
        yield server

async def test_get_thing(mcp_server):
    tool_fn = mcp_server._tool_manager._tools["get_thing"].fn
    with patch("cann_gitcode_mcp.tools.<domain>.GitCodeClient.get",
               new_callable=AsyncMock, return_value={"id": 1}):
        result = await tool_fn(owner="org", repo="repo", number=1)
    assert '"id": 1' in result
```

### 4. Verify

```bash
pytest tests/ -v  # All tests must pass before committing
```

## Token Budget Rules

MCP tool tokens directly squeeze LLM context. Rules split into **input side** (tool definitions, fixed cost per turn) and **output side** (tool responses, variable cost per call).

### Input Side — Tool Definitions (Fixed Cost)

| # | Rule | Practice | Anti-pattern |
|---|---|---|---|
| I1 | 合并同域工具 | 相关操作合并为一个工具 + `action` 参数路由 | 一个 API endpoint = 一个 tool |
| I2 | 描述只写决策信息 | 一行说"做什么"，`Args:` 只写参数含义 | 写示例、教程、实现细节、重复 schema 约束 |
| I3 | enum 优先于 oneOf | `Literal["a","b"]` 生成 `enum` | `oneOf` 每个值一个 object，2-4x 膨胀 |
| I4 | 预算守护 | `test_tool_definition_budget.py` 断言工具 ≤ 4、定义 ≤ 1300 tokens | 加工具不跑预算测试 |
| I5 | 描述中不重复 schema | type/default/min/max 已在 JSON Schema，不再重复 | `"page: Page number (integer, minimum 1, default 1)"` |

### Output Side — Tool Responses (Variable Cost)

| # | Rule | Practice | Anti-pattern |
|---|---|---|---|
| O1 | 字段裁剪 | 只返回决策字段，用 `_slim_*`。丢弃 `_links`, `permissions`, `avatar_url` | 透传原始 API 响应（70-90% 冗余） |
| O2 | 紧凑 JSON | `json.dumps(data, ensure_ascii=False)` 不加缩进 | `indent=2` 增加 30-40% token |
| O3 | 摘要/详情分级 | `detail="summary"\|"full"` 参数；列表默认 key fields | 列表接口返回完整 body |
| O4 | 大内容截断 | diff/日志设上限 `_MAX_DIFF_LINES`，超出截断 | 无限制返回大 diff/日志 |
| O5 | 失败详细 / 成功折叠 | 失败项保留名称+状态+日志链接；成功项折叠为计数 | 成功失败全量输出 |
| O6 | 写操作返回确认 | create/merge/comment 只返回 id + url | 返回完整创建对象 |
| O7 | 公共前缀提取 | 多 URL 共享前缀时提取 `base_url` + 相对路径 | 每条记录完整 URL |
| O8 | structuredContent 不双送 | `content` 和 `structuredContent` 只送一份 | 两者相同但都发送 |

### Test Guards

| Test | Responsibility |
|---|---|
| `test_tool_definition_budget.py` | 工具数量和定义 token 总量不超预算 |
| `test_token_budget.py` | 每个工具响应 token ≤ 预算 |
| `TestTokenReductionReport` | raw vs slim token 对比（信息性） |

Token approximation: `len(text) // 4` (conservative for mixed CJK/English).

### Current Baseline (2026-03-31)

| Metric | Value |
|---|---|
| Tool count | 4 (2 PR + 2 pipeline) |
| Definition tokens | ~1263 (budget: 1300) |
| Max response budget | 600 tokens (`get_pr_pipeline_summary`) |
| Response trimming | 87-95% vs raw API |

### Scaling (When Tools > 8)

Not needed at 4 tools, but plan ahead:

- **Toolset filtering**: `--toolsets` flag, users enable only needed groups
- **Lazy loading**: expose name + one-line summary, load full schema on demand (91% input savings)
- **JSON `$ref`**: shared params defined once via `$ref`
- **Code Mode**: sandbox replaces N tools (98%+ savings, per Anthropic/Cloudflare)

## GitCode API Reference

- Base URL: `https://gitcode.com/api/v5`
- Auth: `Authorization: Bearer <token>`
- PR endpoints: `/repos/{owner}/{repo}/pulls[/{number}[/merge|comments|files]]`
- Pipeline data: extracted from cann-robot PR comments (no dedicated API); see `docs/pipeline-tools-research.md`
