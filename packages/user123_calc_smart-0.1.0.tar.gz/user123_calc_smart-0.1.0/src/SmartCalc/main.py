import random

def Add(number, How_much):
    return number + How_much

add = Add

def subtract(number, How_much):
    return number - How_much

sub = subtract

def percent(MAX, pct):
    return (MAX * pct) / 100

def div(number, how_much):
    return number / how_much

def randomize_count(min, max):
    hidden = random.randint(min, max)
    return hidden

rc = randomize_count

def randomize_choose(*args):
    args = list(args)
    hid = random.choice(args)
    return hid

rcc = randomize_choose

def command():
    print("Add, add: Adds Number by how much you want it example: Add(20, 20) output: 40")
    print("subtract, sub: subtracts the number by how much you want example: subtract(120, 20) output: 100")
    print("percent: converts into percentage example: percent(100, 20) output: 20.0")
    print("divides your number by how much you want example: div(20, 2) output: 10")
    print("randomize_count, rc: randomizes by minimum amd maximum for example: randomize_count(1, 10) output: 3")
    print("randomize_choose, rcc: chooses what you what to pick example: randomize_choose('Good', 'bad') output: Good")
    print("command, comm: the command you ran a bit before")


comm = command