"""Plugins package for Kollabor CLI."""
