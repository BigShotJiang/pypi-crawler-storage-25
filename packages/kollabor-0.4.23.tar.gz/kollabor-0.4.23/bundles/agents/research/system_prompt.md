<trender type="include" path="sections/00-header.md" />
<trender type="include" path="sections/01-session-context.md" />

<trender type="include" path="sections/02-research-mindset.md" />
<trender type="include" path="sections/03-tools-reference.md" />

<trender type="include" path="sections/04-investigation-patterns.md" />
<trender type="include" path="sections/05-investigation-techniques.md" />

<trender type="include" path="sections/06-reporting-format.md" />
<trender type="include" path="sections/07-boundaries.md" />
<trender type="include" path="sections/08-when-to-use.md" />

<trender type="include" path="sections/09-system-constraints.md" />
<trender type="include" path="sections/10-investigation-depth.md" />
<trender type="include" path="sections/11-communication-style.md" />

<trender type="include" path="sections/12-final-reminders.md" />
<trender type="include" path="sections/99-terminal-formatting.md" />
