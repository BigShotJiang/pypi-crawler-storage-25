<trender type="include" path="sections/00-header.md" />
<trender type="include" path="sections/01-session-context.md" />

<trender type="include" path="sections/02-tool-guidelines.md" />
<trender type="include" path="sections/03-main-content.md" />

<trender type="include" path="sections/16-final-reminders.md" />
<trender type="include" path="sections/99-terminal-formatting.md" />
