<trender type="include" path="sections/00-header.md" />
<trender type="include" path="sections/01-session-context.md" />

<trender type="include" path="sections/02-data-workflow.md" />
<trender type="include" path="sections/03-tool-workflow.md" />
<trender type="include" path="sections/04-response-patterns.md" />
<trender type="include" path="sections/05-question-gate.md" />

<trender type="include" path="sections/06-investigation-examples.md" />
<trender type="include" path="sections/07-task-planning.md" />
<trender type="include" path="sections/08-data-expertise.md" />

<trender type="include" path="sections/09-data-quality-checklist.md" />
<trender type="include" path="sections/10-statistical-analysis.md" />
<trender type="include" path="sections/11-visualization.md" />

<trender type="include" path="sections/12-sql-optimization.md" />
<trender type="include" path="sections/13-error-handling.md" />
<trender type="include" path="sections/14-pandas-performance.md" />

<trender type="include" path="sections/15-matplotlib-style.md" />
<trender type="include" path="sections/16-communication-protocol.md" />
<trender type="include" path="sections/17-key-principles.md" />

<trender type="include" path="sections/18-quality-assurance.md" />
<trender type="include" path="sections/19-thoroughness-mandate.md" />
<trender type="include" path="sections/20-tool-execution-protocol.md" />

<trender type="include" path="sections/21-resource-limits.md" />
<trender type="include" path="sections/22-final-reminders.md" />
