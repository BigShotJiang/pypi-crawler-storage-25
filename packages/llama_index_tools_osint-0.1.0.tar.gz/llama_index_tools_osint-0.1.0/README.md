# OSINT Tool for LlamaIndex

This tool connects to the [Agentix OSINT](https://osint.ahsan-tariq-ai.xyz) intelligence platform — a production OSINT system with 129+ RSS feeds across 15 categories, LLM-enriched briefings, domain recon, and social media lookup.

You will need an API key. Get one free at: https://osint.ahsan-tariq-ai.xyz

## Installation

```bash
pip install llama-index-tools-osint
```

## Usage

### Basic Setup

```python
from llama_index.tools.osint import OSINTToolSpec
from llama_index.agent.openai import OpenAIAgent
from llama_index.llms.openai import OpenAI

osint = OSINTToolSpec(api_key="osint_your_key_here")
tools = osint.to_tool_list()

agent = OpenAIAgent.from_tools(
    tools=tools,
    llm=OpenAI(model="gpt-4o"),
)

# Ask about current events
response = agent.chat("What's happening in cybersecurity today?")
print(response)
```

### Tool Methods

#### `get_enriched_reports(category=None)`

Get intelligence briefings from 129+ sources across 15 categories. Each report contains LLM-analyzed articles with confidence scores.

**Categories:** cybersecurity, geopolitics, finance, tech_ai, healthcare, legal, marketing, supply_chain, climate, realestate, education, energy, agriculture, entertainment, labor.

```python
# All categories
reports = osint.get_enriched_reports()

# Single category
cyber = osint.get_enriched_reports(category="cybersecurity")
```

#### `get_categories()`

List all available categories with confidence scores and article counts.

```python
categories = osint.get_categories()
```

#### `domain_recon(domain)`

Perform domain reconnaissance: DNS records, WHOIS, and IP intelligence.

```python
recon = osint.domain_recon("example.com")
```

#### `social_lookup(username)`

Look up profiles across 10 platforms (GitHub, Twitter, Instagram, Reddit, YouTube, Medium, GitLab, Keybase, SoundCloud, Twitch).

```python
profiles = osint.social_lookup("zuck")
```

### Direct Tool Usage

```python
from llama_index.core.tools.tool_spec.base import BaseToolSpec

osint = OSINTToolSpec(api_key="osint_key")

# Use individual methods
from llama_index.core.llms import ChatMessage

agent = OpenAIAgent.from_tools(
    tools=osint.to_tool_list(),
    llm=OpenAI(model="gpt-4o"),
    verbose=True,
)
```

### Custom Base URL

```python
osint = OSINTToolSpec(
    api_key="osint_key",
    base_url="https://osint.ahsan-tariq-ai.xyz",  # default
)
```

## Free Tier

- **50 requests/day** — reports, categories, recon, social
- **5 requests/min** rate limit
- **No credit card required** — sign up with just an email

### Paid Tiers

| Tier | Price | Daily Limit | Rate | Endpoints |
|------|-------|-------------|------|-----------|
| Free | $0 | 50 | 5/min | reports, recon, social |
| Pro | 10 USDC | 1,000 | 30/min | + personal, astrology |
| Enterprise | 50 USDC | 10,000 | 120/min | all endpoints |

## Architecture

```
┌─────────────────────────────────────────────────────┐
│  OSINT API (osint.ahsan-tariq-ai.xyz)               │
│                                                     │
│  129 RSS feeds → 15 categories → LLM analysis       │
│  Domain recon (DNS/WHOIS/IP)                        │
│  Social lookup (10 platforms)                       │
│                                                     │
│  ┌─────────────────────────────────────────────┐   │
│  │  LlamaIndex Tool Spec                       │   │
│  │  • get_enriched_reports()                   │   │
│  │  • get_categories()                         │   │
│  │  • domain_recon()                           │   │
│  │  • social_lookup()                          │   │
│  └─────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────┘
```

## API Reference

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/v1/signup` | POST | Get API key (email only) |
| `/api/v1/reports/enriched` | GET | Intelligence briefings |
| `/api/v1/reports/categories` | GET | Category listing |
| `/api/v1/recon/{domain}` | GET | Domain recon |
| `/api/v1/social/{username}` | GET | Social lookup |

## License

MIT
