"""OSINT intelligence platform tool for LlamaIndex."""

from typing import Optional

import requests
from llama_index.core.tools.tool_spec.base import BaseToolSpec

DEFAULT_BASE_URL = "https://osint.ahsan-tariq-ai.xyz"


class OSINTToolSpec(BaseToolSpec):
    """OSINT intelligence platform tool.

    Provides real-time intelligence reports across 15 categories
    from 129+ RSS feeds, domain recon, and social media lookup.

    Sign up for a free API key at: https://osint.ahsan-tariq-ai.xyz

    Args:
        api_key: Your OSINT API key (get one via POST /api/v1/signup)
        base_url: The OSINT API base URL. Defaults to
            https://osint.ahsan-tariq-ai.xyz

    Example:
        ```python
        from llama_index.tools.osint import OSINTToolSpec
        from llama_index.agent.openai import OpenAIAgent
        from llama_index.llms.openai import OpenAI

        osint = OSINTToolSpec(api_key="osint_abc123...")
        agent = OpenAIAgent.from_tools(
            tools=osint.to_tool_list(),
            llm=OpenAI(model="gpt-4o"),
        )
        agent.chat("What's happening in cybersecurity today?")
        ```
    """

    spec_functions = [
        "get_enriched_reports",
        "get_categories",
        "domain_recon",
        "social_lookup",
    ]

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
    ) -> None:
        """Initialize with API key and optional base URL."""
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")

    def _request(self, path: str, params: Optional[dict] = None) -> dict:
        """Make an authenticated GET request to the OSINT API."""
        url = f"{self.base_url}{path}"
        resp = requests.get(
            url,
            params={"api_key": self.api_key, **(params or {})},
            timeout=30,
        )
        if resp.status_code == 401:
            return {
                "status": "error",
                "message": "API key required. Sign up at https://osint.ahsan-tariq-ai.xyz",
            }
        if resp.status_code == 403:
            return {"status": "error", "message": "Invalid API key"}
        if resp.status_code == 429:
            data = resp.json() if resp.headers.get("content-type", "").startswith(
                "application/json"
            ) else {}
            return {
                "status": "error",
                "message": data.get("detail", {}).get("message", "Rate limit exceeded"),
            }
        resp.raise_for_status()
        return resp.json()

    def get_enriched_reports(self, category: Optional[str] = None) -> str:
        """Get intelligence briefings from 129+ OSINT sources across 15 categories.

        Each briefing contains LLM-analyzed articles with confidence scores.
        Categories: cybersecurity, geopolitics, finance, tech_ai, healthcare,
        legal, marketing, supply_chain, climate, realestate, education,
        energy, agriculture, entertainment, labor.

        Args:
            category: Optional filter to a single category
                (e.g. "cybersecurity", "geopolitics", "finance").
                If omitted, returns all 15 categories.

        Returns:
            JSON string containing intelligence briefings with articles,
            analysis, and confidence scores.
        """
        params = {}
        if category:
            params["category"] = category
        result = self._request("/api/v1/reports/enriched", params=params)
        if result.get("status") == "error":
            return f"OSINT API Error: {result.get('message')}"
        if not result.get("reports"):
            return "No reports available. Reports may not be cached yet."
        return str(result)

    def get_categories(self) -> str:
        """List all available intelligence report categories with metadata.

        Returns category names, confidence scores, and article counts
        for the current cached reports.

        Returns:
            JSON string listing all 15 categories with their confidence
            scores and article counts.
        """
        result = self._request("/api/v1/reports/categories")
        if result.get("status") == "error":
            return f"OSINT API Error: {result.get('message')}"
        return str(result)

    def domain_recon(self, domain: str) -> str:
        """Perform domain reconnaissance: DNS records, WHOIS, and IP intelligence.

        Returns A/AAAA/MX/NS/TXT DNS records, WHOIS registration data,
        and IP geolocation/ISP info for the primary A record.

        Args:
            domain: The domain to investigate (e.g. "example.com").
                HTTP prefixes and www. are automatically stripped.

        Returns:
            JSON string with DNS records, WHOIS data, and IP intelligence.
        """
        result = self._request(f"/api/v1/recon/{domain}")
        if result.get("status") == "error":
            return f"OSINT API Error: {result.get('message')}"
        return str(result)

    def social_lookup(self, username: str) -> str:
        """Look up social media profiles across 10 platforms.

        Probes GitHub, Twitter/X, Instagram, Reddit, YouTube, Medium,
        GitLab, Keybase, SoundCloud, and Twitch concurrently.

        Args:
            username: The username/handle to search for
                (e.g. "zuck", "johnsmith").

        Returns:
            JSON string with found profile URLs and HTTP status codes
            across all platforms.
        """
        result = self._request(f"/api/v1/social/{username}")
        if result.get("status") == "error":
            return f"OSINT API Error: {result.get('message')}"
        return str(result)
