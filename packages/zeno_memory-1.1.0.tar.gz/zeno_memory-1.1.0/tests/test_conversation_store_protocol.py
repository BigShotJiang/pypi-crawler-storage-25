"""Tests for the `ConversationStore` Protocol + `ConversationMessage` shape (IU2).

Test-first: these pin the v0.3.0 conversation primitive contract before any
SQLite implementation lands. Every non-Claude provider will persist turn
history through this surface, so schema drift here = migration pain for
downstream adapters. Lock format early.
"""

from __future__ import annotations

from datetime import UTC, datetime

import pytest
from zeno.memory.protocols import ConversationMessage, ConversationStore


def test_conversation_message_round_trip_fields() -> None:
    msg = ConversationMessage(
        role="assistant",
        content="hello",
        tool_calls=[{"id": "c1", "name": "recall", "arguments": "{}"}],
        tool_call_id=None,
        created_at=datetime(2026, 4, 21, 12, 0, 0, tzinfo=UTC),
    )
    assert msg.role == "assistant"
    assert msg.content == "hello"
    assert msg.tool_calls is not None
    assert msg.tool_calls[0]["id"] == "c1"
    assert msg.tool_call_id is None


def test_conversation_message_is_frozen() -> None:
    msg = ConversationMessage(
        role="user",
        content="hi",
        tool_calls=None,
        tool_call_id=None,
        created_at=datetime(2026, 4, 21, 12, 0, 0, tzinfo=UTC),
    )
    with pytest.raises((AttributeError, TypeError)):
        msg.content = "nope"  # type: ignore[misc]


def test_conversation_message_equality() -> None:
    t = datetime(2026, 4, 21, 12, 0, 0, tzinfo=UTC)
    a = ConversationMessage(
        role="user", content="hi", tool_calls=None, tool_call_id=None, created_at=t
    )
    b = ConversationMessage(
        role="user", content="hi", tool_calls=None, tool_call_id=None, created_at=t
    )
    assert a == b


def test_conversation_message_role_narrow_literal() -> None:
    # Sanity check that all four allowed roles construct fine.
    t = datetime(2026, 4, 21, 12, 0, 0, tzinfo=UTC)
    for role in ("user", "assistant", "tool", "system"):
        msg = ConversationMessage(
            role=role,
            content=None,
            tool_calls=None,
            tool_call_id=None,
            created_at=t,
        )
        assert msg.role == role


class _StubConversationStore:
    async def load(self, *, user_id: str, thread_key: str | None) -> list[ConversationMessage]:
        return []

    async def load_since(
        self,
        *,
        user_id: str,
        thread_key: str | None,
        after_sequence: int,
    ) -> list[tuple[int, ConversationMessage]]:
        return []

    async def append(
        self,
        *,
        user_id: str,
        thread_key: str | None,
        messages: list[ConversationMessage],
    ) -> None:
        return None

    async def clear(self, *, user_id: str, thread_key: str | None) -> None:
        return None


def test_stub_passes_protocol_isinstance() -> None:
    assert isinstance(_StubConversationStore(), ConversationStore)


def test_incomplete_class_fails_protocol_isinstance() -> None:
    class _Incomplete:
        async def load(self, *, user_id: str, thread_key: str | None) -> list[ConversationMessage]:
            return []

        # Missing append + clear.

    assert not isinstance(_Incomplete(), ConversationStore)
