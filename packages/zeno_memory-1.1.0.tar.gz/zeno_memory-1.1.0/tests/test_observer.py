"""Tests for `Observer.observe_for_window` (L4 Unit 5).

Covers:

  - Happy path: rounds since watermark → LLM JSON → batch insert + watermark advance.
  - Tool-call rounds serialised with `tool_call`/`tool_result` labels;
    long tool-result bodies truncated to ``tool_truncate_chars``.
  - Empty unprocessed window: no LLM call, no insert, no watermark advance,
    `MemoryObserved(observations_written=0, error=False)` event.
  - Malformed JSON / missing fields / hallucinated round ids: items dropped
    silently; if no observations parse, watermark still advances (the
    rounds were processed) but `observations_written=0`.
  - LLM raise → `error=True`, watermark unchanged.
  - `referenced_date=null` → stored as `None`.
  - `priority` outside the literal set → item dropped.
  - Tracer wired on `ctx.tracer` records `MemoryObserved` after every run.
"""

from __future__ import annotations

import asyncio
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest
from zeno.context import Ctx
from zeno.memory.observer import (
    Observer,
    _coerce_to_list,
    _extract_array,
    _parse_observations,
)
from zeno.memory.protocols import ConversationMessage, ObservationRunWatermark
from zeno.memory.sqlite.conversation_store import SqliteConversationStore
from zeno.memory.sqlite.observation_store import SqliteObservationStore
from zeno.observability.events import MemoryObserved


def _msg(
    role: str,
    content: str | None = None,
    *,
    tool_calls: list[dict[str, Any]] | None = None,
    tool_call_id: str | None = None,
) -> ConversationMessage:
    return ConversationMessage(
        role=role,  # type: ignore[arg-type]
        content=content,
        tool_calls=tool_calls,
        tool_call_id=tool_call_id,
        created_at=datetime(2026, 4, 30, 12, 0, 0, tzinfo=UTC),
    )


def _make_ctx(user_id: str = "alice", tracer: Any = None) -> Ctx:
    """Minimal `Ctx` stub — Observer only reads `user_id` and `tracer`."""
    ctx = MagicMock(spec=Ctx)
    ctx.user_id = user_id
    ctx.tracer = tracer
    return ctx


@pytest.fixture
def observation_store(tmp_path: Path) -> SqliteObservationStore:
    return SqliteObservationStore(tmp_path / "obs.db")


@pytest.fixture
def conversation_store(tmp_path: Path) -> SqliteConversationStore:
    return SqliteConversationStore(tmp_path / "conv.db")


async def _seed_rounds(
    conv: SqliteConversationStore,
    user_id: str,
    thread_key: str | None,
    messages: list[ConversationMessage],
) -> None:
    await conv.append(user_id=user_id, thread_key=thread_key, messages=messages)


def _stub_llm(reply: str) -> Any:
    async def _llm(_prompt: str) -> str:
        return reply

    return _llm


def _raising_llm(exc: BaseException) -> Any:
    async def _llm(_prompt: str) -> str:
        raise exc

    return _llm


async def test_happy_path_inserts_batch_and_advances_watermark(
    observation_store: SqliteObservationStore, conversation_store: SqliteConversationStore
) -> None:
    await _seed_rounds(
        conversation_store,
        "alice",
        None,
        [_msg("user", f"message {i}") for i in range(5)],
    )
    reply = json.dumps(
        [
            {
                "text": "alice prefers concise replies",
                "priority": "high",
                "referenced_date": None,
                "source_round_ids": [0, 1],
            },
            {
                "text": "alice is planning a trip",
                "priority": "medium",
                "referenced_date": 1_700_000_000,
                "source_round_ids": [3],
            },
            {
                "text": "alice mentioned coffee",
                "priority": "low",
                "referenced_date": None,
                "source_round_ids": [4],
            },
        ]
    )
    observer = Observer(
        store=observation_store,
        conversations=conversation_store,
        llm=_stub_llm(reply),
        now_fn=lambda: 1_700_000_500,
    )

    ctx = _make_ctx()
    await observer.observe_for_window(ctx, agent_id="root", thread_key=None)

    rows = await observation_store.list_active(user_id="alice", agent_id="root")
    assert {r.text for r in rows} == {
        "alice prefers concise replies",
        "alice is planning a trip",
        "alice mentioned coffee",
    }
    high = next(r for r in rows if r.priority == "high")
    assert high.source_round_ids == (0, 1)
    assert high.observation_date == 1_700_000_500
    medium = next(r for r in rows if r.priority == "medium")
    assert medium.referenced_date == 1_700_000_000

    wm = await observation_store.read_watermark(user_id="alice", agent_id="root", thread_key=None)
    assert wm is not None
    assert wm.last_processed_sequence == 4
    assert wm.last_run_status == "ok"


async def test_tool_call_and_tool_result_rounds_are_labelled(
    observation_store: SqliteObservationStore, conversation_store: SqliteConversationStore
) -> None:
    captured: list[str] = []

    async def llm(prompt: str) -> str:
        captured.append(prompt)
        return "[]"

    await _seed_rounds(
        conversation_store,
        "alice",
        None,
        [
            _msg("user", "hello"),
            _msg(
                "assistant",
                None,
                tool_calls=[{"id": "c1", "name": "search", "input": {"q": "foo"}}],
            ),
            _msg("tool", "tool result body", tool_call_id="c1"),
        ],
    )
    observer = Observer(
        store=observation_store,
        conversations=conversation_store,
        llm=llm,
        now_fn=lambda: 1_700_000_500,
    )
    await observer.observe_for_window(_make_ctx(), agent_id="root", thread_key=None)

    assert len(captured) == 1
    prompt = captured[0]
    assert "tool_call" in prompt
    assert "tool_result" in prompt
    assert '"q": "foo"' in prompt
    assert "tool result body" in prompt


async def test_long_tool_result_is_truncated(
    observation_store: SqliteObservationStore, conversation_store: SqliteConversationStore
) -> None:
    captured: list[str] = []

    async def llm(prompt: str) -> str:
        captured.append(prompt)
        return "[]"

    long_body = "x" * 5000
    await _seed_rounds(
        conversation_store,
        "alice",
        None,
        [_msg("tool", long_body, tool_call_id="c1")],
    )
    observer = Observer(
        store=observation_store,
        conversations=conversation_store,
        llm=llm,
        tool_truncate_chars=2000,
    )
    await observer.observe_for_window(_make_ctx(), agent_id="root", thread_key=None)

    assert "... (truncated)" in captured[0]
    # The full 5000-char body should NOT appear; only the first 2000 chars.
    assert "x" * 5000 not in captured[0]


async def test_empty_window_skips_llm_call_and_emits_event(
    observation_store: SqliteObservationStore, conversation_store: SqliteConversationStore
) -> None:
    """No unprocessed rounds → no LLM call, no insert, watermark unchanged."""
    llm_calls: list[str] = []

    async def llm(prompt: str) -> str:
        llm_calls.append(prompt)
        return "[]"

    tracer_events: list[Any] = []
    tracer = MagicMock()
    tracer.on_event = lambda e: tracer_events.append(e)

    observer = Observer(
        store=observation_store,
        conversations=conversation_store,
        llm=llm,
    )
    await observer.observe_for_window(_make_ctx(tracer=tracer), agent_id="root", thread_key=None)

    assert llm_calls == []
    assert (
        await observation_store.read_watermark(user_id="alice", agent_id="root", thread_key=None)
        is None
    )
    assert len(tracer_events) == 1
    event = tracer_events[0]
    assert isinstance(event, MemoryObserved)
    assert event.rounds_seen == 0
    assert event.observations_written == 0
    assert event.error is False


async def test_malformed_json_advances_watermark_with_zero_observations(
    observation_store: SqliteObservationStore, conversation_store: SqliteConversationStore
) -> None:
    """Garbage from the LLM ⇒ no observations parse, but the rounds were
    processed — advance the watermark so we don't re-spend tokens on the
    same window."""
    await _seed_rounds(
        conversation_store,
        "alice",
        None,
        [_msg("user", "hello"), _msg("assistant", "hi")],
    )
    observer = Observer(
        store=observation_store,
        conversations=conversation_store,
        llm=_stub_llm("not valid json at all"),
    )
    await observer.observe_for_window(_make_ctx(), agent_id="root", thread_key=None)

    rows = await observation_store.list_active(user_id="alice", agent_id="root")
    assert rows == []
    wm = await observation_store.read_watermark(user_id="alice", agent_id="root", thread_key=None)
    assert wm is not None
    assert wm.last_processed_sequence == 1
    assert wm.last_run_status == "empty"


async def test_invalid_priority_dropped(
    observation_store: SqliteObservationStore, conversation_store: SqliteConversationStore
) -> None:
    await _seed_rounds(conversation_store, "alice", None, [_msg("user", "hi")])
    reply = json.dumps(
        [
            {
                "text": "valid one",
                "priority": "high",
                "referenced_date": None,
                "source_round_ids": [0],
            },
            {
                "text": "invalid priority",
                "priority": "URGENT",
                "referenced_date": None,
                "source_round_ids": [0],
            },
        ]
    )
    observer = Observer(
        store=observation_store,
        conversations=conversation_store,
        llm=_stub_llm(reply),
    )
    await observer.observe_for_window(_make_ctx(), agent_id="root", thread_key=None)

    rows = await observation_store.list_active(user_id="alice", agent_id="root")
    assert [r.text for r in rows] == ["valid one"]


async def test_referenced_date_null_stored_as_none(
    observation_store: SqliteObservationStore, conversation_store: SqliteConversationStore
) -> None:
    await _seed_rounds(conversation_store, "alice", None, [_msg("user", "hi")])
    reply = json.dumps(
        [
            {
                "text": "no ref date",
                "priority": "medium",
                "referenced_date": None,
                "source_round_ids": [0],
            }
        ]
    )
    observer = Observer(
        store=observation_store,
        conversations=conversation_store,
        llm=_stub_llm(reply),
    )
    await observer.observe_for_window(_make_ctx(), agent_id="root", thread_key=None)

    rows = await observation_store.list_active(user_id="alice", agent_id="root")
    assert len(rows) == 1
    assert rows[0].referenced_date is None


async def test_hallucinated_round_id_dropped(
    observation_store: SqliteObservationStore, conversation_store: SqliteConversationStore
) -> None:
    await _seed_rounds(conversation_store, "alice", None, [_msg("user", "hi")])
    reply = json.dumps(
        [
            {
                "text": "real ids",
                "priority": "high",
                "referenced_date": None,
                "source_round_ids": [0],
            },
            {
                "text": "hallucinated only",
                "priority": "high",
                "referenced_date": None,
                "source_round_ids": [42, 99],
            },
            {
                "text": "mix of real and hallucinated keeps real",
                "priority": "high",
                "referenced_date": None,
                "source_round_ids": [99, 0],
            },
        ]
    )
    observer = Observer(
        store=observation_store,
        conversations=conversation_store,
        llm=_stub_llm(reply),
    )
    await observer.observe_for_window(_make_ctx(), agent_id="root", thread_key=None)

    rows = await observation_store.list_active(user_id="alice", agent_id="root")
    assert {r.text for r in rows} == {"real ids", "mix of real and hallucinated keeps real"}


async def test_llm_raise_marks_event_error_and_does_not_advance_watermark(
    observation_store: SqliteObservationStore, conversation_store: SqliteConversationStore
) -> None:
    await _seed_rounds(conversation_store, "alice", None, [_msg("user", "hi")])

    tracer_events: list[Any] = []
    tracer = MagicMock()
    tracer.on_event = lambda e: tracer_events.append(e)

    observer = Observer(
        store=observation_store,
        conversations=conversation_store,
        llm=_raising_llm(RuntimeError("provider boom")),
    )
    await observer.observe_for_window(_make_ctx(tracer=tracer), agent_id="root", thread_key=None)

    assert (
        await observation_store.read_watermark(user_id="alice", agent_id="root", thread_key=None)
        is None
    )
    assert len(tracer_events) == 1
    assert isinstance(tracer_events[0], MemoryObserved)
    assert tracer_events[0].error is True


async def test_tracer_records_event_after_successful_run(
    observation_store: SqliteObservationStore, conversation_store: SqliteConversationStore
) -> None:
    await _seed_rounds(conversation_store, "alice", None, [_msg("user", "hi")])
    reply = json.dumps(
        [
            {
                "text": "fact",
                "priority": "medium",
                "referenced_date": None,
                "source_round_ids": [0],
            }
        ]
    )
    tracer_events: list[Any] = []
    tracer = MagicMock()
    tracer.on_event = lambda e: tracer_events.append(e)

    observer = Observer(
        store=observation_store,
        conversations=conversation_store,
        llm=_stub_llm(reply),
    )
    await observer.observe_for_window(_make_ctx(tracer=tracer), agent_id="root", thread_key=None)

    assert len(tracer_events) == 1
    event = tracer_events[0]
    assert isinstance(event, MemoryObserved)
    assert event.observations_written == 1
    assert event.rounds_seen == 1
    assert event.error is False


async def test_resume_after_advance_only_processes_new_rounds(
    observation_store: SqliteObservationStore, conversation_store: SqliteConversationStore
) -> None:
    """A second run after watermark advance should only see new rounds."""
    await _seed_rounds(conversation_store, "alice", None, [_msg("user", "first")])
    observer = Observer(
        store=observation_store,
        conversations=conversation_store,
        llm=_stub_llm("[]"),
    )
    await observer.observe_for_window(_make_ctx(), agent_id="root", thread_key=None)
    wm1 = await observation_store.read_watermark(user_id="alice", agent_id="root", thread_key=None)
    assert wm1 is not None
    assert wm1.last_processed_sequence == 0

    captured: list[str] = []

    async def llm(prompt: str) -> str:
        captured.append(prompt)
        return "[]"

    await _seed_rounds(
        conversation_store, "alice", None, [_msg("user", "second"), _msg("user", "third")]
    )
    observer2 = Observer(store=observation_store, conversations=conversation_store, llm=llm)
    await observer2.observe_for_window(_make_ctx(), agent_id="root", thread_key=None)

    assert len(captured) == 1
    # The prompt should NOT contain "first" — only "second" and "third".
    assert "first" not in captured[0]
    assert "second" in captured[0]
    assert "third" in captured[0]

    wm2 = await observation_store.read_watermark(user_id="alice", agent_id="root", thread_key=None)
    assert wm2 is not None
    assert wm2.last_processed_sequence == 2


async def test_watermark_record_round_trips_through_observer(
    observation_store: SqliteObservationStore,
) -> None:
    """Sanity check: ObservationRunWatermark frozen dataclass round-trips
    via store reads/writes (covers the dataclass type used by observer)."""
    await observation_store.advance_watermark(
        user_id="alice",
        agent_id="root",
        thread_key=None,
        last_processed_sequence=12,
        last_run_status="ok",
    )
    wm = await observation_store.read_watermark(user_id="alice", agent_id="root", thread_key=None)
    assert isinstance(wm, ObservationRunWatermark)
    assert wm.last_processed_sequence == 12


# ---------------------------------------------------------------------------
# Constructor validation
# ---------------------------------------------------------------------------


def test_constructor_rejects_zero_tool_truncate_chars(
    observation_store: SqliteObservationStore, conversation_store: SqliteConversationStore
) -> None:
    with pytest.raises(ValueError, match="tool_truncate_chars must be >= 1"):
        Observer(
            store=observation_store,
            conversations=conversation_store,
            llm=_stub_llm(""),
            tool_truncate_chars=0,
        )


def test_constructor_rejects_zero_max_observations_per_run(
    observation_store: SqliteObservationStore, conversation_store: SqliteConversationStore
) -> None:
    with pytest.raises(ValueError, match="max_observations_per_run must be >= 1"):
        Observer(
            store=observation_store,
            conversations=conversation_store,
            llm=_stub_llm(""),
            max_observations_per_run=0,
        )


# ---------------------------------------------------------------------------
# Cancellation propagates through observe_for_window
# ---------------------------------------------------------------------------


async def test_cancellation_propagates_and_does_not_advance_watermark(
    observation_store: SqliteObservationStore, conversation_store: SqliteConversationStore
) -> None:
    """An LLM that raises CancelledError must propagate without swallowing,
    must not advance the watermark, and must emit a tracer event with
    error=True (covers the asyncio.CancelledError branch)."""
    await _seed_rounds(conversation_store, "alice", None, [_msg("user", "hi")])

    tracer_events: list[Any] = []
    tracer = MagicMock()
    tracer.on_event = lambda e: tracer_events.append(e)

    observer = Observer(
        store=observation_store,
        conversations=conversation_store,
        llm=_raising_llm(asyncio.CancelledError()),
    )
    with pytest.raises(asyncio.CancelledError):
        await observer.observe_for_window(
            _make_ctx(tracer=tracer), agent_id="root", thread_key=None
        )

    assert (
        await observation_store.read_watermark(user_id="alice", agent_id="root", thread_key=None)
        is None
    )
    assert len(tracer_events) == 1
    assert tracer_events[0].error is True


# ---------------------------------------------------------------------------
# Assistant tool_calls with non-JSON-serialisable contents falls back to str()
# ---------------------------------------------------------------------------


def test_render_body_assistant_tool_calls_unserialisable_falls_back_to_str(
    observation_store: SqliteObservationStore, conversation_store: SqliteConversationStore
) -> None:
    """When ``json.dumps(msg.tool_calls)`` raises (e.g. a set value inside),
    `_render_body` falls back to ``str()`` so the rendered window still
    goes to the LLM. Tested directly because the SQLite conversation store
    rejects unserialisable tool_calls upstream — the fallback is
    defensive against in-process callers that bypass the store."""
    observer = Observer(
        store=observation_store, conversations=conversation_store, llm=_stub_llm("[]")
    )
    weird_tool_calls: list[dict[str, Any]] = [{"name": "browse", "args": {"tags": {1, 2}}}]
    msg = _msg("assistant", None, tool_calls=weird_tool_calls)

    rendered = observer._render_body(msg)

    assert "browse" in rendered
    # The fallback `str(tool_calls)` representation includes the set repr.
    assert "{1, 2}" in rendered or "{2, 1}" in rendered


# ---------------------------------------------------------------------------
# _parse_observations: branch coverage
# ---------------------------------------------------------------------------


def test_parse_observations_drops_non_dict_items() -> None:
    reply = json.dumps(
        [
            "not-a-dict",
            {"text": "ok", "priority": "high", "referenced_date": None, "source_round_ids": [0]},
        ]
    )
    out = _parse_observations(reply, max_observations=10, valid_round_ids={0})
    assert len(out) == 1
    assert out[0]["text"] == "ok"


def test_parse_observations_drops_empty_text() -> None:
    reply = json.dumps(
        [
            {"text": "", "priority": "high", "referenced_date": None, "source_round_ids": [0]},
            {"text": "   ", "priority": "high", "referenced_date": None, "source_round_ids": [0]},
            {"text": None, "priority": "high", "referenced_date": None, "source_round_ids": [0]},
        ]
    )
    assert _parse_observations(reply, max_observations=10, valid_round_ids={0}) == []


def test_parse_observations_referenced_date_wrong_type_set_to_none() -> None:
    reply = json.dumps(
        [
            {
                "text": "fact",
                "priority": "high",
                "referenced_date": "2026-04-30",  # string, not int — must coerce to None
                "source_round_ids": [0],
            }
        ]
    )
    out = _parse_observations(reply, max_observations=10, valid_round_ids={0})
    assert len(out) == 1
    assert out[0]["referenced_date"] is None


def test_parse_observations_referenced_date_bool_set_to_none() -> None:
    """`bool` is a subclass of `int` in Python — guard against `True`/`False`
    sneaking through the int check."""
    reply = json.dumps(
        [
            {
                "text": "fact",
                "priority": "high",
                "referenced_date": True,
                "source_round_ids": [0],
            }
        ]
    )
    out = _parse_observations(reply, max_observations=10, valid_round_ids={0})
    assert len(out) == 1
    assert out[0]["referenced_date"] is None


def test_parse_observations_drops_when_source_round_ids_not_a_list() -> None:
    reply = json.dumps(
        [
            {
                "text": "fact",
                "priority": "high",
                "referenced_date": None,
                "source_round_ids": "0",  # string, not list
            }
        ]
    )
    assert _parse_observations(reply, max_observations=10, valid_round_ids={0}) == []


def test_parse_observations_filters_bool_and_non_int_round_ids() -> None:
    """`True`/`False` are `int` subclasses; strings/floats also disallowed."""
    reply = json.dumps(
        [
            {
                "text": "fact",
                "priority": "high",
                "referenced_date": None,
                "source_round_ids": [True, "0", 1.5, 0],
            }
        ]
    )
    out = _parse_observations(reply, max_observations=10, valid_round_ids={0})
    assert len(out) == 1
    assert out[0]["source_round_ids"] == [0]


def test_parse_observations_max_observations_cap_enforced() -> None:
    reply = json.dumps(
        [
            {
                "text": f"fact-{i}",
                "priority": "high",
                "referenced_date": None,
                "source_round_ids": [0],
            }
            for i in range(10)
        ]
    )
    out = _parse_observations(reply, max_observations=3, valid_round_ids={0})
    assert len(out) == 3
    assert [o["text"] for o in out] == ["fact-0", "fact-1", "fact-2"]


# ---------------------------------------------------------------------------
# _coerce_to_list / _extract_array: branch coverage
# ---------------------------------------------------------------------------


def test_coerce_to_list_finds_first_list_inside_dict() -> None:
    parsed = {"meta": "x", "observations": [{"a": 1}, {"b": 2}]}
    coerced = _coerce_to_list(parsed)
    assert coerced == [{"a": 1}, {"b": 2}]


def test_coerce_to_list_returns_none_for_dict_without_lists() -> None:
    assert _coerce_to_list({"a": 1, "b": "x"}) is None


def test_coerce_to_list_returns_none_for_non_list_non_dict() -> None:
    """Coverage: line 280 takes the False branch when ``parsed`` is a scalar."""
    assert _coerce_to_list(42) is None
    assert _coerce_to_list("string") is None
    assert _coerce_to_list(None) is None


def test_extract_array_via_nongreedy_regex_when_top_level_isnt_json() -> None:
    """Top-level decode fails on the surrounding prose, but the embedded
    bracketed JSON parses via the non-greedy regex pass."""
    reply = 'Here you go: [{"text": "ok", "priority": "high"}] thanks!'
    parsed = _extract_array(reply)
    assert parsed == [{"text": "ok", "priority": "high"}]


def test_extract_array_via_greedy_regex_when_nongreedy_doesnt_match() -> None:
    """A reply where the inner non-greedy match fails JSON decode but the
    greedy match (outermost brackets) succeeds — happens when the array
    contains nested brackets."""
    reply = 'Result: [{"k": [1, 2, 3]}] -- end.'
    parsed = _extract_array(reply)
    assert parsed == [{"k": [1, 2, 3]}]


def test_extract_array_returns_none_when_nothing_parses() -> None:
    assert _extract_array("no brackets at all") is None
    assert _extract_array("[not valid json [") is None
    assert _extract_array("") is None


def test_extract_array_falls_through_when_top_level_decode_yields_scalar() -> None:
    """Coverage: top-level json.loads succeeds but ``_coerce_to_list`` returns
    None (scalar/dict-without-list). Falls through to the regex passes."""
    # Top-level scalar: json.loads("42") → 42 → coerce returns None.
    # Neither regex matches, so the final return None is taken.
    assert _extract_array("42") is None


def test_extract_array_returns_none_when_greedy_match_is_invalid_json() -> None:
    """Coverage: greedy regex matches a `[...]` block that fails json.loads."""
    # The non-greedy regex matches the same block; json.loads also fails
    # there, the loop continues, then the greedy regex hits the
    # JSONDecodeError fallback at lines 365-366.
    assert _extract_array("[not valid json]") is None
