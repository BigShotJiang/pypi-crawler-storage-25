"""Tests for the schema migrator."""

from __future__ import annotations

import asyncio
from pathlib import Path

import aiosqlite
from zeno.memory.sqlite.migrate import ensure_schema


async def test_ensure_schema_creates_all_tables(tmp_db_path: Path) -> None:
    conn = await aiosqlite.connect(tmp_db_path)
    try:
        await ensure_schema(conn)
        cur = await conn.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
        tables = {row[0] for row in await cur.fetchall()}
    finally:
        await conn.close()

    assert "schema_version" in tables
    assert "sessions" in tables
    assert "user_memories" in tables
    assert "conversations" in tables
    assert "working_memory" in tables
    assert "observations" in tables
    assert "observation_runs" in tables


async def test_ensure_schema_upgrades_v02_db(tmp_db_path: Path) -> None:
    """A DB provisioned under v0.2 (three tables, migrations 1-3) gains the
    `conversations` table on next open, without touching existing rows.

    Simulates the operator's upgrade path: old persisted data stays intact
    and the 004 migration fills in the new table.
    """
    conn = await aiosqlite.connect(tmp_db_path)
    try:
        # Simulate the pre-IU2 state: apply migrations 1-3 only.
        await conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_version ("
            "version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)"
        )
        await conn.executescript(
            "CREATE TABLE sessions ("
            " user_id TEXT NOT NULL, channel TEXT NOT NULL, thread_key TEXT,"
            " sdk_session_id TEXT NOT NULL, created_at INTEGER NOT NULL,"
            " updated_at INTEGER NOT NULL, last_summary TEXT,"
            " PRIMARY KEY (user_id, channel, thread_key));"
        )
        await conn.executescript(
            "CREATE TABLE user_memories ("
            " id INTEGER PRIMARY KEY AUTOINCREMENT,"
            " user_id TEXT NOT NULL, text TEXT NOT NULL, meta TEXT,"
            " created_at INTEGER NOT NULL);"
        )
        await conn.executemany(
            "INSERT INTO schema_version (version, applied_at) VALUES (?, 0)",
            [(1,), (2,), (3,)],
        )
        # Seed a row that must survive the upgrade.
        await conn.execute(
            "INSERT INTO sessions"
            " (user_id, channel, thread_key, sdk_session_id, created_at, updated_at)"
            " VALUES ('alice', 'cli', NULL, 'sdk-legacy', 0, 0)"
        )
        await conn.commit()
    finally:
        await conn.close()

    conn = await aiosqlite.connect(tmp_db_path)
    try:
        await ensure_schema(conn)
        cur = await conn.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
        tables = {row[0] for row in await cur.fetchall()}
        cur = await conn.execute("SELECT sdk_session_id FROM sessions WHERE user_id = 'alice'")
        legacy = await cur.fetchone()
    finally:
        await conn.close()

    assert "conversations" in tables
    assert legacy is not None
    assert legacy[0] == "sdk-legacy"


async def test_ensure_schema_is_idempotent(tmp_db_path: Path) -> None:
    for _ in range(3):
        conn = await aiosqlite.connect(tmp_db_path)
        try:
            await ensure_schema(conn)
        finally:
            await conn.close()

    conn = await aiosqlite.connect(tmp_db_path)
    try:
        cur = await conn.execute("SELECT COUNT(*) FROM schema_version GROUP BY version")
        rows = await cur.fetchall()
    finally:
        await conn.close()

    # Each version should be recorded exactly once.
    assert all(row[0] == 1 for row in rows)


async def test_ensure_schema_handles_concurrent_init(tmp_db_path: Path) -> None:
    async def init_once() -> None:
        conn = await aiosqlite.connect(tmp_db_path)
        try:
            await ensure_schema(conn)
        finally:
            await conn.close()

    await asyncio.gather(*(init_once() for _ in range(4)))

    conn = await aiosqlite.connect(tmp_db_path)
    try:
        cur = await conn.execute("SELECT version, COUNT(*) FROM schema_version GROUP BY version")
        rows = await cur.fetchall()
    finally:
        await conn.close()

    # Each migration version applied exactly once.
    assert all(row[1] == 1 for row in rows)


async def test_ensure_schema_recovers_from_partial_apply(tmp_db_path: Path) -> None:
    """BUG-001: a migration that committed DDL but crashed before recording
    its version row must not break the next initializer.

    Simulates the failure mode by manually applying migration 005's first
    ALTER TABLE (and only that) before invoking ``ensure_schema``. The
    migrator should treat the resulting ``duplicate column name`` as a
    partial-apply signal, finish the remaining ALTERs / backfill, and
    record the version row.
    """
    conn = await aiosqlite.connect(tmp_db_path)
    try:
        # Lay down the v0.2 baseline and migration 004 cleanly.
        await conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_version ("
            "version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)"
        )
        await conn.executescript(
            "CREATE TABLE user_memories ("
            " id INTEGER PRIMARY KEY AUTOINCREMENT,"
            " user_id TEXT NOT NULL, text TEXT NOT NULL, meta TEXT,"
            " created_at INTEGER NOT NULL);"
        )
        await conn.executemany(
            "INSERT INTO schema_version (version, applied_at) VALUES (?, 0)",
            [(1,), (2,), (3,), (4,)],
        )
        # Partial-apply: add only the first column from 005 and don't
        # record the version.
        await conn.execute("ALTER TABLE user_memories ADD COLUMN tier TEXT NOT NULL DEFAULT 'long'")
        await conn.commit()
    finally:
        await conn.close()

    conn = await aiosqlite.connect(tmp_db_path)
    try:
        await ensure_schema(conn)
        # All four columns from 005 must now exist.
        cur = await conn.execute("PRAGMA table_info(user_memories)")
        cols = {row[1] for row in await cur.fetchall()}
        # Version row recorded.
        cur = await conn.execute("SELECT version FROM schema_version ORDER BY version")
        versions = [row[0] for row in await cur.fetchall()]
    finally:
        await conn.close()

    assert {"tier", "last_accessed_at", "hit_count", "archived_at"}.issubset(cols)
    assert 5 in versions


async def test_working_memory_migration_adds_table_and_index(tmp_db_path: Path) -> None:
    """Migration 007 creates the `working_memory` table, its leftmost-prefix
    index, and records the version row even when run on top of a DB that
    already has migrations 1–6 applied.
    """

    conn = await aiosqlite.connect(tmp_db_path)
    try:
        await ensure_schema(conn)
        cur = await conn.execute("PRAGMA table_info(working_memory)")
        cols = {row[1] for row in await cur.fetchall()}
        cur = await conn.execute(
            "SELECT name FROM sqlite_master "
            "WHERE type = 'index' AND tbl_name = 'working_memory' "
            "  AND name = 'ix_working_memory_user_agent'"
        )
        index_row = await cur.fetchone()
        cur = await conn.execute("SELECT version FROM schema_version ORDER BY version")
        versions = [row[0] for row in await cur.fetchall()]
    finally:
        await conn.close()

    assert {
        "user_id",
        "agent_id",
        "field_name",
        "value",
        "last_updated",
        "created_at",
    } == cols
    assert index_row is not None
    assert 7 in versions


async def test_observation_migrations_add_tables_and_indexes(tmp_db_path: Path) -> None:
    """Migrations 008 and 009 create the observation log + watermark tables,
    the active-row partial index, and the audit-trail leftmost-prefix index.
    """

    conn = await aiosqlite.connect(tmp_db_path)
    try:
        await ensure_schema(conn)
        cur = await conn.execute("PRAGMA table_info(observations)")
        obs_cols = {row[1] for row in await cur.fetchall()}
        cur = await conn.execute("PRAGMA table_info(observation_runs)")
        run_cols = {row[1] for row in await cur.fetchall()}
        cur = await conn.execute(
            "SELECT name FROM sqlite_master "
            "WHERE type = 'index' AND tbl_name = 'observations' "
            "ORDER BY name"
        )
        obs_indexes = {row[0] for row in await cur.fetchall()}
        cur = await conn.execute("SELECT version FROM schema_version ORDER BY version")
        versions = [row[0] for row in await cur.fetchall()]
    finally:
        await conn.close()

    assert {
        "id",
        "user_id",
        "agent_id",
        "text",
        "priority",
        "observation_date",
        "referenced_date",
        "source_round_ids",
        "created_at",
        "archived_at",
    } == obs_cols
    assert {
        "user_id",
        "agent_id",
        "thread_key",
        "last_processed_sequence",
        "last_run_at",
        "last_run_status",
    } == run_cols
    assert {"ix_observations_active", "ix_observations_user_agent"}.issubset(obs_indexes)
    assert 8 in versions
    assert 9 in versions
