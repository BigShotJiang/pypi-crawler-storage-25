"""Tests for `ObservationalMemory` — L4 orchestrator (Unit 7).

Covers:
  - lifecycle (idempotent start/stop)
  - threshold gating (no Observer fire below threshold)
  - happy path Observer + Reflector run on threshold crossing
  - single-flight per (user_id, agent_id, thread_key)
  - per-window isolation
  - error absorption (Observer raises -> orchestrator does not propagate)
"""

from __future__ import annotations

import asyncio
import json
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import pytest
from zeno.context import Ctx
from zeno.memory.observational import ObservationalMemory
from zeno.memory.observer import Observer
from zeno.memory.protocols import ConversationMessage
from zeno.memory.reflector import Reflector
from zeno.memory.sqlite.conversation_store import SqliteConversationStore
from zeno.memory.sqlite.observation_store import SqliteObservationStore
from zeno.observability.events import MemoryObserved, MemoryReflected


@dataclass
class _CaptureTracer:
    events: list[Any] = field(default_factory=list)
    observed: asyncio.Event = field(default_factory=asyncio.Event)
    reflected: asyncio.Event = field(default_factory=asyncio.Event)

    def on_event(self, event: Any) -> None:
        self.events.append(event)
        if isinstance(event, MemoryObserved):
            self.observed.set()
        elif isinstance(event, MemoryReflected):
            self.reflected.set()


def _scripted_llm(replies: list[str]) -> Callable[[str], Awaitable[str]]:
    queue = list(replies)

    async def _call(_prompt: str) -> str:
        if not queue:
            raise AssertionError("scripted LLM exhausted")
        return queue.pop(0)

    return _call


def _make_ctx(user_id: str, tracer: Any = None) -> Ctx:
    async def _reply(_text: str) -> None:
        return None

    async def _stream(_chunk: str) -> None:
        return None

    async def _finalize() -> None:
        return None

    return Ctx(
        user_id=user_id,
        session_id=None,
        channel="test",
        memory=None,  # type: ignore[arg-type]
        reply=_reply,
        stream=_stream,
        finalize=_finalize,
        http=None,  # type: ignore[arg-type]
        logger=None,
        tracer=tracer,
        state={},
        thread_key=None,
        secrets=None,  # type: ignore[arg-type]
        turn_id="t1",
    )


def _msg(
    role: str,
    content: str | None,
    *,
    tool_calls: list[dict[str, Any]] | None = None,
) -> ConversationMessage:
    return ConversationMessage(
        role=role,  # type: ignore[arg-type]
        content=content,
        tool_calls=tool_calls,
        tool_call_id=None,
        created_at=datetime.now(UTC),
    )


async def _seed_rounds(
    conversations: SqliteConversationStore,
    user_id: str,
    *,
    count: int,
    body: str = "x" * 200,
) -> None:
    """Seed *count* user/assistant message pairs into the store."""
    msgs: list[ConversationMessage] = []
    for _ in range(count):
        msgs.append(_msg("user", body))
        msgs.append(_msg("assistant", body))
    await conversations.append(user_id=user_id, thread_key=None, messages=msgs)


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------


async def test_start_stop_idempotent(tmp_db_path: Path) -> None:
    obs_store = SqliteObservationStore(tmp_db_path)
    convo = SqliteConversationStore(tmp_db_path)
    observer = Observer(store=obs_store, conversations=convo, llm=_scripted_llm([]))
    reflector = Reflector(store=obs_store, proposer=_scripted_llm([]))

    om = ObservationalMemory(
        observer=observer,
        reflector=reflector,
        conversations=convo,
        observations=obs_store,
    )
    # Multiple starts and stops must not raise.
    await om.start()
    await om.start()
    await om.stop()
    await om.stop()


async def test_below_threshold_no_observer_runs(tmp_db_path: Path) -> None:
    """Token count below threshold -> orchestrator returns; no events emitted."""
    obs_store = SqliteObservationStore(tmp_db_path)
    convo = SqliteConversationStore(tmp_db_path)
    tracer = _CaptureTracer()
    observer = Observer(store=obs_store, conversations=convo, llm=_scripted_llm([]))
    reflector = Reflector(store=obs_store, proposer=_scripted_llm([]))

    om = ObservationalMemory(
        observer=observer,
        reflector=reflector,
        conversations=convo,
        observations=obs_store,
        observer_threshold_tokens=10_000,  # well above seeded content
        reflector_threshold_tokens=20_000,
    )
    await om.start()
    try:
        await _seed_rounds(convo, "alice", count=2, body="hi")  # ~10 chars total
        await om.maybe_observe_and_reflect(
            _make_ctx("alice", tracer=tracer), agent_id="root", thread_key=None
        )
        await asyncio.sleep(0)  # yield once for any spawned task — none expected
        assert tracer.events == []
    finally:
        await om.stop()


async def test_not_started_is_noop(tmp_db_path: Path) -> None:
    """Calling maybe_observe_and_reflect before start() is a no-op."""
    obs_store = SqliteObservationStore(tmp_db_path)
    convo = SqliteConversationStore(tmp_db_path)
    observer = Observer(store=obs_store, conversations=convo, llm=_scripted_llm([]))
    reflector = Reflector(store=obs_store, proposer=_scripted_llm([]))

    om = ObservationalMemory(
        observer=observer,
        reflector=reflector,
        conversations=convo,
        observations=obs_store,
        observer_threshold_tokens=1,
    )
    await _seed_rounds(convo, "alice", count=1)
    # No start() — should silently no-op.
    await om.maybe_observe_and_reflect(_make_ctx("alice"), agent_id="root", thread_key=None)


# ---------------------------------------------------------------------------
# Happy paths — Observer fires, Reflector fires
# ---------------------------------------------------------------------------


async def test_threshold_crossed_runs_observer(tmp_db_path: Path) -> None:
    obs_store = SqliteObservationStore(tmp_db_path)
    convo = SqliteConversationStore(tmp_db_path)
    tracer = _CaptureTracer()

    observer_reply = json.dumps(
        [
            {
                "text": "alice greets the assistant",
                "priority": "medium",
                "referenced_date": None,
                "source_round_ids": [0],
            }
        ]
    )
    observer = Observer(store=obs_store, conversations=convo, llm=_scripted_llm([observer_reply]))
    reflector = Reflector(store=obs_store, proposer=_scripted_llm([]))  # not called

    om = ObservationalMemory(
        observer=observer,
        reflector=reflector,
        conversations=convo,
        observations=obs_store,
        tracer=tracer,
        observer_threshold_tokens=1,  # any non-empty round crosses
        reflector_threshold_tokens=10_000_000,  # never crossed
    )
    await om.start()
    try:
        await _seed_rounds(convo, "alice", count=1, body="hi alice")
        await om.maybe_observe_and_reflect(
            _make_ctx("alice", tracer=tracer), agent_id="root", thread_key=None
        )
        await asyncio.wait_for(tracer.observed.wait(), timeout=2.0)
        # Observer fired once, Reflector did not.
        observed = [e for e in tracer.events if isinstance(e, MemoryObserved)]
        reflected = [e for e in tracer.events if isinstance(e, MemoryReflected)]
        assert len(observed) == 1
        assert observed[0].rounds_seen >= 1
        assert reflected == []
    finally:
        await om.stop()


async def test_reflector_threshold_crossed_runs_reflector(tmp_db_path: Path) -> None:
    obs_store = SqliteObservationStore(tmp_db_path)
    convo = SqliteConversationStore(tmp_db_path)
    tracer = _CaptureTracer()

    # Observer writes one observation with a long body so the rendered
    # observation log crosses the (small) reflector threshold.
    long_body = "x" * 200
    observer_reply = json.dumps(
        [
            {
                "text": long_body,
                "priority": "medium",
                "referenced_date": None,
                "source_round_ids": [0],
            }
        ]
    )
    observer = Observer(store=obs_store, conversations=convo, llm=_scripted_llm([observer_reply]))
    # Reflector returns an empty edit set so we don't have to script
    # complex apply behaviour — we only care that it was invoked.
    reflector = Reflector(
        store=obs_store, proposer=_scripted_llm([json.dumps({"edits": []})]), tracer=tracer
    )

    om = ObservationalMemory(
        observer=observer,
        reflector=reflector,
        conversations=convo,
        observations=obs_store,
        tracer=tracer,
        observer_threshold_tokens=1,
        reflector_threshold_tokens=10,  # 200 chars / 4 = 50 tokens, crosses 10
    )
    await om.start()
    try:
        await _seed_rounds(convo, "alice", count=1, body="hi")
        await om.maybe_observe_and_reflect(
            _make_ctx("alice", tracer=tracer), agent_id="root", thread_key=None
        )
        await asyncio.wait_for(tracer.reflected.wait(), timeout=2.0)
        observed = [e for e in tracer.events if isinstance(e, MemoryObserved)]
        reflected = [e for e in tracer.events if isinstance(e, MemoryReflected)]
        assert len(observed) == 1
        assert len(reflected) == 1
    finally:
        await om.stop()


# ---------------------------------------------------------------------------
# Single-flight + window isolation
# ---------------------------------------------------------------------------


async def test_single_flight_per_window(tmp_db_path: Path) -> None:
    """Two concurrent calls for the same window -> only one Observer run."""
    obs_store = SqliteObservationStore(tmp_db_path)
    convo = SqliteConversationStore(tmp_db_path)
    tracer = _CaptureTracer()

    # Observer LLM blocks until released so we can fire a second
    # `maybe_observe_and_reflect` while the first is in flight.
    gate = asyncio.Event()
    observer_reply = json.dumps([])

    async def gated_llm(_prompt: str) -> str:
        await gate.wait()
        return observer_reply

    observer = Observer(store=obs_store, conversations=convo, llm=gated_llm)
    reflector = Reflector(store=obs_store, proposer=_scripted_llm([]))

    om = ObservationalMemory(
        observer=observer,
        reflector=reflector,
        conversations=convo,
        observations=obs_store,
        tracer=tracer,
        observer_threshold_tokens=1,
        reflector_threshold_tokens=10_000_000,
    )
    await om.start()
    try:
        await _seed_rounds(convo, "alice", count=1)
        ctx = _make_ctx("alice", tracer=tracer)

        # First call starts a worker; second call sees busy and returns.
        await om.maybe_observe_and_reflect(ctx, agent_id="root", thread_key=None)
        await asyncio.sleep(0)  # let the spawned task acquire its busy slot
        await om.maybe_observe_and_reflect(ctx, agent_id="root", thread_key=None)

        # Only one task in flight; releasing the gate completes it.
        gate.set()
        await asyncio.wait_for(tracer.observed.wait(), timeout=2.0)

        observed = [e for e in tracer.events if isinstance(e, MemoryObserved)]
        assert len(observed) == 1
    finally:
        gate.set()
        await om.stop()


async def test_concurrent_different_windows_run_independently(tmp_db_path: Path) -> None:
    obs_store = SqliteObservationStore(tmp_db_path)
    convo = SqliteConversationStore(tmp_db_path)
    tracer = _CaptureTracer()

    observer = Observer(
        store=obs_store, conversations=convo, llm=_scripted_llm([json.dumps([]), json.dumps([])])
    )
    reflector = Reflector(store=obs_store, proposer=_scripted_llm([]))

    om = ObservationalMemory(
        observer=observer,
        reflector=reflector,
        conversations=convo,
        observations=obs_store,
        tracer=tracer,
        observer_threshold_tokens=1,
        reflector_threshold_tokens=10_000_000,
    )
    await om.start()
    try:
        await _seed_rounds(convo, "alice", count=1)
        await _seed_rounds(convo, "bob", count=1)
        await om.maybe_observe_and_reflect(
            _make_ctx("alice", tracer=tracer), agent_id="root", thread_key=None
        )
        await om.maybe_observe_and_reflect(
            _make_ctx("bob", tracer=tracer), agent_id="root", thread_key=None
        )
        await om.wait_idle()
        observed = [e for e in tracer.events if isinstance(e, MemoryObserved)]
        assert {e.user_id for e in observed} == {"alice", "bob"}
    finally:
        await om.stop()


# ---------------------------------------------------------------------------
# Error path — Observer raises but orchestrator does not propagate
# ---------------------------------------------------------------------------


async def test_observer_raises_does_not_propagate(tmp_db_path: Path) -> None:
    obs_store = SqliteObservationStore(tmp_db_path)
    convo = SqliteConversationStore(tmp_db_path)
    tracer = _CaptureTracer()

    async def boom(_prompt: str) -> str:
        raise RuntimeError("LLM down")

    observer = Observer(store=obs_store, conversations=convo, llm=boom)
    reflector = Reflector(store=obs_store, proposer=_scripted_llm([]))

    om = ObservationalMemory(
        observer=observer,
        reflector=reflector,
        conversations=convo,
        observations=obs_store,
        tracer=tracer,
        observer_threshold_tokens=1,
        reflector_threshold_tokens=10_000_000,
    )
    await om.start()
    try:
        await _seed_rounds(convo, "alice", count=1)
        # The call must return; the spawned task absorbs the LLM raise.
        await om.maybe_observe_and_reflect(
            _make_ctx("alice", tracer=tracer), agent_id="root", thread_key=None
        )
        await asyncio.wait_for(tracer.observed.wait(), timeout=2.0)
        observed = [e for e in tracer.events if isinstance(e, MemoryObserved)]
        assert len(observed) == 1
        assert observed[0].error is True
        # Busy flag released -> next call is allowed (not a no-op due to busy).
        # Trigger a second call with a fresh LLM to confirm.
    finally:
        await om.stop()


async def test_busy_flag_released_after_observer_error(tmp_db_path: Path) -> None:
    obs_store = SqliteObservationStore(tmp_db_path)
    convo = SqliteConversationStore(tmp_db_path)
    tracer = _CaptureTracer()

    failures = [True]

    async def maybe_boom(_prompt: str) -> str:
        if failures[0]:
            failures[0] = False
            raise RuntimeError("first call fails")
        return json.dumps([])

    observer = Observer(store=obs_store, conversations=convo, llm=maybe_boom)
    reflector = Reflector(store=obs_store, proposer=_scripted_llm([]))

    om = ObservationalMemory(
        observer=observer,
        reflector=reflector,
        conversations=convo,
        observations=obs_store,
        tracer=tracer,
        observer_threshold_tokens=1,
        reflector_threshold_tokens=10_000_000,
    )
    await om.start()
    try:
        await _seed_rounds(convo, "alice", count=1)
        await om.maybe_observe_and_reflect(
            _make_ctx("alice", tracer=tracer), agent_id="root", thread_key=None
        )
        await asyncio.wait_for(tracer.observed.wait(), timeout=2.0)
        # Wait for the spawned task to finish so the busy flag is released
        # before we call maybe_observe_and_reflect again.
        await om.wait_idle()
        # Reset event so we can wait for the second.
        tracer.observed.clear()
        # The second call must not be filtered by a stale busy flag.
        await om.maybe_observe_and_reflect(
            _make_ctx("alice", tracer=tracer), agent_id="root", thread_key=None
        )
        await asyncio.wait_for(tracer.observed.wait(), timeout=2.0)
        observed = [e for e in tracer.events if isinstance(e, MemoryObserved)]
        assert len(observed) == 2
        assert observed[0].error is True
        assert observed[1].error is False
    finally:
        await om.stop()


# ---------------------------------------------------------------------------
# Construction guards
# ---------------------------------------------------------------------------


def test_constructor_rejects_zero_thresholds(tmp_db_path: Path) -> None:
    obs_store = SqliteObservationStore(tmp_db_path)
    convo = SqliteConversationStore(tmp_db_path)
    observer = Observer(store=obs_store, conversations=convo, llm=_scripted_llm([]))
    reflector = Reflector(store=obs_store, proposer=_scripted_llm([]))

    with pytest.raises(ValueError, match="observer_threshold_tokens"):
        ObservationalMemory(
            observer=observer,
            reflector=reflector,
            conversations=convo,
            observations=obs_store,
            observer_threshold_tokens=0,
        )
    with pytest.raises(ValueError, match="reflector_threshold_tokens"):
        ObservationalMemory(
            observer=observer,
            reflector=reflector,
            conversations=convo,
            observations=obs_store,
            reflector_threshold_tokens=0,
        )


def test_priority_markers_default_emoji(tmp_db_path: Path) -> None:
    obs_store = SqliteObservationStore(tmp_db_path)
    convo = SqliteConversationStore(tmp_db_path)
    observer = Observer(store=obs_store, conversations=convo, llm=_scripted_llm([]))
    reflector = Reflector(store=obs_store, proposer=_scripted_llm([]))

    om = ObservationalMemory(
        observer=observer,
        reflector=reflector,
        conversations=convo,
        observations=obs_store,
    )
    assert om.priority_markers == "emoji"
