"""Protocol-level checks for `ObservationStore` and the `Observation` record.

`SqliteObservationStore` MUST satisfy `isinstance(_, ObservationStore)`
(R1, R10) so out-of-tree implementations remain swappable. The dataclass
records pin frozen + slots so accidental mutation in the hot path raises
loudly instead of silently corrupting state.
"""

from __future__ import annotations

from dataclasses import FrozenInstanceError
from pathlib import Path

import pytest
from zeno.memory.protocols import (
    Observation,
    ObservationCounts,
    ObservationRunInput,
    ObservationRunWatermark,
    ObservationStore,
)
from zeno.memory.sqlite.observation_store import SqliteObservationStore


def test_sqlite_observation_store_satisfies_protocol(tmp_db_path: Path) -> None:
    store = SqliteObservationStore(tmp_db_path)
    assert isinstance(store, ObservationStore)


def test_observation_is_frozen() -> None:
    obs = Observation(
        id=1,
        user_id="alice",
        agent_id="root",
        text="likes ramen",
        priority="high",
        observation_date=1_700_000_000,
        referenced_date=None,
        source_round_ids=(7,),
        created_at=1_700_000_000,
    )
    with pytest.raises(FrozenInstanceError):
        obs.text = "no"  # type: ignore[misc]


def test_observation_run_watermark_is_frozen() -> None:
    wm = ObservationRunWatermark(
        user_id="alice",
        agent_id="root",
        thread_key=None,
        last_processed_sequence=0,
        last_run_at=0,
        last_run_status="empty",
    )
    with pytest.raises(FrozenInstanceError):
        wm.last_processed_sequence = 1  # type: ignore[misc]


def test_observation_counts_default_shape() -> None:
    counts = ObservationCounts(merges_applied=1, replaces_applied=2, deletes_applied=3, rejected=4)
    assert (
        counts.merges_applied,
        counts.replaces_applied,
        counts.deletes_applied,
        counts.rejected,
    ) == (1, 2, 3, 4)


def test_observation_run_input_carries_run_id() -> None:
    payload = ObservationRunInput(
        run_id="run-1",
        user_id="alice",
        agent_id="root",
        edits=(),
        started_at=1_700_000_000,
    )
    assert payload.run_id == "run-1"
    assert payload.edits == ()
