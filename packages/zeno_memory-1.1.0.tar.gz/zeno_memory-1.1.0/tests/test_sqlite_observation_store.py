"""Tests for `SqliteObservationStore` (L4 Unit 2).

Covers:

  - `insert_batch` round-trips priority + dates + source_round_ids,
    archived rows are filtered from `list_active`, ordering by referenced
    or observation date.
  - `apply_edits` archives source rows and inserts new merged/replaced
    rows preserving priority + provenance; deletes mark rows archived;
    edits referencing already-archived ids are counted as `rejected`.
  - Watermarks: `read_watermark` is `None` for fresh stores;
    `advance_watermark` upserts per `(user_id, agent_id, thread_key)` —
    `thread_key=None` is a coherent single watermark per
    `(user_id, agent_id)` pair (SQLite NULL-PK semantics).
  - Cross-`(user_id, agent_id)` isolation on reads (R5).
"""

from __future__ import annotations

from pathlib import Path

import pytest
from zeno.memory._edits import Delete, Merge, Replace
from zeno.memory.protocols import (
    Observation,
    ObservationRunInput,
)
from zeno.memory.sqlite.observation_store import SqliteObservationStore


def _obs(
    user_id: str,
    agent_id: str,
    text: str,
    *,
    priority: str = "medium",
    observation_date: int = 1_700_000_000,
    referenced_date: int | None = None,
    source_round_ids: tuple[int, ...] = (),
) -> Observation:
    return Observation(
        id=0,
        user_id=user_id,
        agent_id=agent_id,
        text=text,
        priority=priority,  # type: ignore[arg-type]
        observation_date=observation_date,
        referenced_date=referenced_date,
        source_round_ids=source_round_ids,
        created_at=observation_date,
    )


async def test_insert_batch_round_trips_rows(tmp_db_path: Path) -> None:
    store = SqliteObservationStore(tmp_db_path, now_fn=lambda: 1_700_000_500)
    await store.insert_batch(
        [
            _obs("alice", "root", "likes ramen", priority="high", source_round_ids=(7,)),
            _obs("alice", "root", "lives in Tokyo", priority="low", referenced_date=1_699_900_000),
        ]
    )
    rows = await store.list_active("alice", "root")
    assert [r.text for r in rows] == ["lives in Tokyo", "likes ramen"]
    assert rows[0].priority == "low"
    assert rows[0].referenced_date == 1_699_900_000
    assert rows[1].priority == "high"
    assert rows[1].source_round_ids == (7,)


async def test_list_active_filters_other_namespaces(tmp_db_path: Path) -> None:
    store = SqliteObservationStore(tmp_db_path)
    await store.insert_batch(
        [
            _obs("alice", "root", "alice fact"),
            _obs("bob", "root", "bob fact"),
            _obs("alice", "coder", "coder-only fact"),
        ]
    )
    alice_root = await store.list_active("alice", "root")
    bob_root = await store.list_active("bob", "root")
    alice_coder = await store.list_active("alice", "coder")
    assert [r.text for r in alice_root] == ["alice fact"]
    assert [r.text for r in bob_root] == ["bob fact"]
    assert [r.text for r in alice_coder] == ["coder-only fact"]


async def test_apply_edits_merge_archives_sources_and_inserts_new_row(
    tmp_db_path: Path,
) -> None:
    store = SqliteObservationStore(tmp_db_path, now_fn=lambda: 1_700_000_900)
    await store.insert_batch(
        [
            _obs("alice", "root", "morning runs", priority="medium", source_round_ids=(1,)),
            _obs("alice", "root", "evening runs", priority="high", source_round_ids=(2,)),
        ]
    )
    rows = await store.list_active("alice", "root")
    ids = sorted(r.id for r in rows)

    counts = await store.apply_edits(
        ObservationRunInput(
            run_id="r1",
            user_id="alice",
            agent_id="root",
            edits=(Merge(source_ids=tuple(ids), text="exercises daily"),),
            started_at=1_700_000_900,
        )
    )
    assert counts.merges_applied == 1
    assert counts.rejected == 0

    after = await store.list_active("alice", "root")
    assert len(after) == 1
    merged = after[0]
    assert merged.text == "exercises daily"
    assert merged.priority == "high"
    assert sorted(merged.source_round_ids) == [1, 2]


async def test_apply_edits_replace_preserves_priority_and_round_ids(
    tmp_db_path: Path,
) -> None:
    store = SqliteObservationStore(tmp_db_path, now_fn=lambda: 1_700_001_000)
    await store.insert_batch(
        [_obs("alice", "root", "old text", priority="high", source_round_ids=(3,))]
    )
    [original] = await store.list_active("alice", "root")
    counts = await store.apply_edits(
        ObservationRunInput(
            run_id="r2",
            user_id="alice",
            agent_id="root",
            edits=(Replace(source_id=original.id, text="new text"),),
            started_at=1_700_001_000,
        )
    )
    assert counts.replaces_applied == 1
    [after] = await store.list_active("alice", "root")
    assert after.text == "new text"
    assert after.priority == "high"
    assert after.source_round_ids == (3,)


async def test_apply_edits_delete_archives_row(tmp_db_path: Path) -> None:
    store = SqliteObservationStore(tmp_db_path)
    await store.insert_batch([_obs("alice", "root", "to remove")])
    [original] = await store.list_active("alice", "root")
    counts = await store.apply_edits(
        ObservationRunInput(
            run_id="r3",
            user_id="alice",
            agent_id="root",
            edits=(Delete(source_id=original.id),),
            started_at=0,
        )
    )
    assert counts.deletes_applied == 1
    assert await store.list_active("alice", "root") == []


async def test_apply_edits_counts_archived_sources_as_rejected(tmp_db_path: Path) -> None:
    store = SqliteObservationStore(tmp_db_path)
    await store.insert_batch([_obs("alice", "root", "doomed")])
    [row] = await store.list_active("alice", "root")
    # Archive it via a delete first.
    await store.apply_edits(
        ObservationRunInput(
            run_id="r-prep",
            user_id="alice",
            agent_id="root",
            edits=(Delete(source_id=row.id),),
            started_at=0,
        )
    )
    counts = await store.apply_edits(
        ObservationRunInput(
            run_id="r-replay",
            user_id="alice",
            agent_id="root",
            edits=(
                Delete(source_id=row.id),
                Replace(source_id=row.id, text="ghost"),
                Merge(source_ids=(row.id,), text="ghost"),
            ),
            started_at=0,
        )
    )
    assert counts.deletes_applied == 0
    assert counts.replaces_applied == 0
    assert counts.merges_applied == 0
    assert counts.rejected == 3


async def test_watermark_round_trip(tmp_db_path: Path) -> None:
    store = SqliteObservationStore(tmp_db_path, now_fn=lambda: 1_700_000_000)
    assert await store.read_watermark("alice", "root", None) is None

    await store.advance_watermark(
        user_id="alice",
        agent_id="root",
        thread_key=None,
        last_processed_sequence=12,
        last_run_status="ok",
    )
    wm = await store.read_watermark("alice", "root", None)
    assert wm is not None
    assert wm.last_processed_sequence == 12
    assert wm.last_run_status == "ok"
    assert wm.thread_key is None

    # Re-advancing upserts (last-write-wins).
    await store.advance_watermark(
        user_id="alice",
        agent_id="root",
        thread_key=None,
        last_processed_sequence=15,
        last_run_status="empty",
    )
    wm = await store.read_watermark("alice", "root", None)
    assert wm is not None
    assert wm.last_processed_sequence == 15
    assert wm.last_run_status == "empty"


async def test_watermark_per_thread_key_isolation(tmp_db_path: Path) -> None:
    store = SqliteObservationStore(tmp_db_path)
    await store.advance_watermark(
        user_id="alice",
        agent_id="root",
        thread_key="t1",
        last_processed_sequence=5,
        last_run_status="ok",
    )
    await store.advance_watermark(
        user_id="alice",
        agent_id="root",
        thread_key="t2",
        last_processed_sequence=9,
        last_run_status="ok",
    )
    a = await store.read_watermark("alice", "root", "t1")
    b = await store.read_watermark("alice", "root", "t2")
    none_thread = await store.read_watermark("alice", "root", None)
    assert a is not None
    assert b is not None
    assert a.last_processed_sequence == 5
    assert b.last_processed_sequence == 9
    assert none_thread is None


@pytest.mark.parametrize("status", ["ok", "error", "empty"])
async def test_watermark_accepts_all_status_values(tmp_db_path: Path, status: str) -> None:
    store = SqliteObservationStore(tmp_db_path)
    await store.advance_watermark(
        user_id="alice",
        agent_id="root",
        thread_key=None,
        last_processed_sequence=1,
        last_run_status=status,  # type: ignore[arg-type]
    )
    wm = await store.read_watermark("alice", "root", None)
    assert wm is not None
    assert wm.last_run_status == status
