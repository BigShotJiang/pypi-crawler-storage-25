"""Tests for `MemoryConsolidator` — the daily 3-phase pipeline."""

from __future__ import annotations

import json
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import aiosqlite
import pytest
from zeno.memory._edits import _coerce_edit, _dedupe_edits, _parse_edits
from zeno.memory.consolidation import (
    ConsolidationCounts,
    ConsolidationRunInput,
    Delete,
    MemoryConsolidator,
    Merge,
    Replace,
    _parse_verdicts,
)
from zeno.memory.sqlite.user_memory_store import SqliteUserMemoryStore
from zeno.observability.events import MemoryConsolidated

# `MemoryConsolidator` emits a `DeprecationWarning` from `__init__` (Unit 11).
# These tests construct the legacy class on every case; silence the warning
# at module level. A dedicated test below asserts the warning fires.
pytestmark = pytest.mark.filterwarnings("ignore::DeprecationWarning")


@dataclass
class _CaptureTracer:
    events: list[Any] = field(default_factory=list)

    def on_event(self, event: Any) -> None:
        self.events.append(event)


def _store_with_clock(tmp_db_path: Any, clock: list[int]) -> SqliteUserMemoryStore:
    return SqliteUserMemoryStore(tmp_db_path, now_fn=lambda: clock[0])


def _scripted_llm(replies: list[str]) -> Callable[[str], Awaitable[str]]:
    """Return an async callable that yields *replies* in order.

    Stubbing a queue rather than a Mock keeps the assertion surface
    explicit: each phase consumes exactly one reply and the test fails
    loudly if a phase is invoked with no scripted reply waiting.
    """
    queue = list(replies)

    async def _call(_prompt: str) -> str:
        if not queue:
            raise AssertionError("scripted LLM exhausted")
        return queue.pop(0)

    return _call


# ---------------------------------------------------------------------------
# Parsing helpers — surface the verbs and verdict shapes
# ---------------------------------------------------------------------------


def test_parse_edits_handles_all_three_verbs() -> None:
    reply = json.dumps(
        {
            "edits": [
                {"verb": "merge", "source_ids": [1, 2], "text": "alice likes coffee"},
                {"verb": "replace", "source_id": 3, "text": "bob is in NYC"},
                {"verb": "delete", "source_id": 4},
            ]
        }
    )
    edits = _parse_edits(reply, valid_ids={1, 2, 3, 4})
    assert edits == [
        Merge(source_ids=(1, 2), text="alice likes coffee"),
        Replace(source_id=3, text="bob is in NYC"),
        Delete(source_id=4),
    ]


def test_parse_edits_drops_unknown_ids() -> None:
    reply = json.dumps(
        {"edits": [{"verb": "delete", "source_id": 99}]},
    )
    assert _parse_edits(reply, valid_ids={1, 2}) == []


def test_parse_edits_rejects_single_source_merge() -> None:
    reply = json.dumps(
        {"edits": [{"verb": "merge", "source_ids": [1], "text": "x"}]},
    )
    assert _parse_edits(reply, valid_ids={1}) == []


def test_parse_edits_rejects_bool_ids() -> None:
    # Pythonic ``True`` is also an int — guard against accidental coercion.
    reply = json.dumps({"edits": [{"verb": "delete", "source_id": True}]})
    assert _parse_edits(reply, valid_ids={1}) == []


def test_parse_edits_returns_empty_on_garbage() -> None:
    assert _parse_edits("not JSON", valid_ids={1}) == []
    assert _parse_edits("{}", valid_ids={1}) == []
    assert _parse_edits('{"edits": "wrong"}', valid_ids={1}) == []


def test_dedupe_edits_drops_overlapping_sources() -> None:
    edits: list[Merge | Replace | Delete] = [
        Merge(source_ids=(1, 2), text="merged"),
        Replace(source_id=2, text="conflicting"),  # 2 already used
        Delete(source_id=3),
    ]
    deduped = _dedupe_edits(edits)
    assert deduped == [
        Merge(source_ids=(1, 2), text="merged"),
        Delete(source_id=3),
    ]


def test_parse_verdicts_filters_invalid_indices() -> None:
    reply = json.dumps(
        {
            "verdicts": [
                {"index": 0, "accept": True},
                {"index": 1, "accept": False},
                {"index": 5, "accept": True},  # out of range
                {"index": 0, "accept": True},  # duplicate
            ]
        }
    )
    assert _parse_verdicts(reply, max_index=3) == [0]


def test_coerce_edit_strips_text() -> None:
    edit = _coerce_edit(
        {"verb": "replace", "source_id": 1, "text": "  hello  "},
        valid_ids={1},
    )
    assert edit == Replace(source_id=1, text="hello")


def test_coerce_edit_rejects_unknown_verb() -> None:
    assert _coerce_edit({"verb": "rewrite", "source_id": 1}, valid_ids={1}) is None


def test_coerce_edit_merge_rejects_non_list_ids() -> None:
    assert (
        _coerce_edit(
            {"verb": "merge", "source_ids": "1,2", "text": "x"},
            valid_ids={1, 2},
        )
        is None
    )


def test_coerce_edit_merge_skips_bool_and_unknown_ids() -> None:
    edit = _coerce_edit(
        {"verb": "merge", "source_ids": [1, True, 99, 2], "text": "ok"},
        valid_ids={1, 2},
    )
    assert edit == Merge(source_ids=(1, 2), text="ok")


def test_coerce_edit_replace_rejects_bool_and_unknown_ids() -> None:
    assert _coerce_edit({"verb": "replace", "source_id": True, "text": "x"}, valid_ids={1}) is None
    assert _coerce_edit({"verb": "replace", "source_id": 99, "text": "x"}, valid_ids={1}) is None


def test_coerce_edit_replace_rejects_empty_text() -> None:
    assert _coerce_edit({"verb": "replace", "source_id": 1, "text": "   "}, valid_ids={1}) is None


def test_parse_edits_skips_non_dict_items() -> None:
    reply = json.dumps(
        {"edits": ["not a dict", {"verb": "delete", "source_id": 1}]},
    )
    assert _parse_edits(reply, valid_ids={1}) == [Delete(source_id=1)]


def test_parse_edits_handles_trailing_garbage_after_json() -> None:
    """Wrapper followed by stray text — trim-trailing loop must recover."""
    payload = json.dumps({"edits": [{"verb": "delete", "source_id": 1}]})
    reply = f"{payload}\n```\nthat's my answer"
    assert _parse_edits(reply, valid_ids={1}) == [Delete(source_id=1)]


def test_parse_edits_returns_empty_when_inner_value_is_not_dict() -> None:
    """Greedy regex match that parses to a non-dict (list) should yield []."""
    reply = "[1, 2, 3]"
    assert _parse_edits(reply, valid_ids={1}) == []


def test_parse_verdicts_returns_empty_on_non_object() -> None:
    assert _parse_verdicts("not JSON", max_index=3) == []


def test_parse_verdicts_returns_empty_when_field_missing() -> None:
    assert _parse_verdicts(json.dumps({"verdicts": "wrong"}), max_index=3) == []


def test_parse_verdicts_skips_malformed_items() -> None:
    reply = json.dumps(
        {
            "verdicts": [
                "not a dict",
                {"index": True, "accept": True},  # bool index
                {"index": 0, "accept": "yes"},  # non-bool accept
                {"index": 1, "accept": True},  # valid
            ]
        }
    )
    assert _parse_verdicts(reply, max_index=3) == [1]


# ---------------------------------------------------------------------------
# consolidate_user — happy paths
# ---------------------------------------------------------------------------


async def test_consolidate_no_candidates_writes_audit_noop(tmp_db_path: Path) -> None:
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)
    tracer = _CaptureTracer()

    consolidator = MemoryConsolidator(
        store=store,
        proposer=_scripted_llm([]),  # never called
        adversary=_scripted_llm([]),
        judge=_scripted_llm([]),
        tracer=tracer,
        now_fn=lambda: clock[0],
    )
    counts = await consolidator.consolidate_user("alice")

    assert counts == ConsolidationCounts(0, 0, 0)
    assert len(tracer.events) == 1
    event = tracer.events[0]
    assert isinstance(event, MemoryConsolidated)
    assert event.proposals_generated == 0
    assert event.proposals_accepted == 0

    # Audit row landed.
    async with aiosqlite.connect(tmp_db_path) as conn:
        cur = await conn.execute(
            "SELECT proposals_generated, proposals_accepted, error "
            "FROM consolidation_runs WHERE user_id = ?",
            ("alice",),
        )
        rows = list(await cur.fetchall())
    assert rows == [(0, 0, None)]


async def test_consolidate_judge_rejects_all_writes_audit_noop(tmp_db_path: Path) -> None:
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)
    await store.add("alice", "alice loves coffee", tier="long")
    await store.add("alice", "alice loves espresso", tier="long")

    tracer = _CaptureTracer()
    proposer_reply = json.dumps(
        {"edits": [{"verb": "merge", "source_ids": [1, 2], "text": "alice loves coffee/espresso"}]}
    )
    judge_reply = json.dumps({"verdicts": [{"index": 0, "accept": False}]})
    consolidator = MemoryConsolidator(
        store=store,
        proposer=_scripted_llm([proposer_reply]),
        adversary=_scripted_llm(["worried about info loss"]),
        judge=_scripted_llm([judge_reply]),
        tracer=tracer,
        now_fn=lambda: clock[0],
    )
    counts = await consolidator.consolidate_user("alice")

    assert counts == ConsolidationCounts(0, 0, 0)
    # Originals still active.
    hits = await store.search("alice", "loves", k=5)
    assert {h.text for h in hits} == {"alice loves coffee", "alice loves espresso"}

    async with aiosqlite.connect(tmp_db_path) as conn:
        cur = await conn.execute(
            "SELECT proposals_generated, proposals_accepted FROM consolidation_runs"
        )
        rows = list(await cur.fetchall())
    assert rows == [(1, 0)]


async def test_consolidate_merge_archives_sources(tmp_db_path: Path) -> None:
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)
    await store.add("alice", "alice likes coffee", tier="long")
    await store.add("alice", "alice drinks coffee daily", tier="long")

    proposer_reply = json.dumps(
        {
            "edits": [
                {
                    "verb": "merge",
                    "source_ids": [1, 2],
                    "text": "alice drinks coffee daily and likes it",
                }
            ]
        }
    )
    judge_reply = json.dumps({"verdicts": [{"index": 0, "accept": True}]})
    consolidator = MemoryConsolidator(
        store=store,
        proposer=_scripted_llm([proposer_reply]),
        adversary=_scripted_llm(["fine"]),
        judge=_scripted_llm([judge_reply]),
        now_fn=lambda: clock[0],
    )
    counts = await consolidator.consolidate_user("alice")

    assert counts == ConsolidationCounts(merges_applied=1, replaces_applied=0, deletes_applied=0)

    # Source rows archived; merged row at long (input tier).
    hits = await store.search("alice", "coffee", k=5)
    assert len(hits) == 1
    assert hits[0].text == "alice drinks coffee daily and likes it"
    assert hits[0].meta["tier"] == "long"


async def test_apply_consolidation_merge_uses_max_tier_of_sources(tmp_db_path: Path) -> None:
    """Direct store-level test for the tier-preservation invariant.

    Bypasses the consolidator since its phases operate on one tier at a
    time; the apply path is the only code that selects across tiers.
    """
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)
    await store.add("alice", "row one", tier="long")
    await store.add("alice", "row two", tier="permanent")

    run = ConsolidationRunInput(
        run_id="merge-tier",
        user_id="alice",
        started_at=clock[0],
        proposals_generated=1,
        proposals_accepted=1,
        merges=(Merge(source_ids=(1, 2), text="row one + row two"),),
        replaces=(),
        deletes=(),
        proposals_json=None,
        verdicts_json=None,
        error=None,
    )
    counts = await store.apply_consolidation(run)
    assert counts.merges_applied == 1

    hits = await store.search("alice", "row", k=5)
    assert len(hits) == 1
    assert hits[0].meta["tier"] == "permanent"


async def test_consolidate_replace_preserves_tier(tmp_db_path: Path) -> None:
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)
    await store.add("alice", "alice in nyc", tier="permanent")

    proposer_reply = json.dumps(
        {"edits": [{"verb": "replace", "source_id": 1, "text": "alice lives in New York City"}]}
    )
    judge_reply = json.dumps({"verdicts": [{"index": 0, "accept": True}]})
    consolidator = MemoryConsolidator(
        store=store,
        proposer=_scripted_llm([proposer_reply]),
        adversary=_scripted_llm(["ok"]),
        judge=_scripted_llm([judge_reply]),
        tier="permanent",
        now_fn=lambda: clock[0],
    )
    counts = await consolidator.consolidate_user("alice")

    assert counts.replaces_applied == 1
    hits = await store.search("alice", "york", k=5)
    assert len(hits) == 1
    assert hits[0].text == "alice lives in New York City"
    assert hits[0].meta["tier"] == "permanent"


async def test_consolidate_delete_archives_source(tmp_db_path: Path) -> None:
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)
    await store.add("alice", "redundant fact", tier="long")
    await store.add("alice", "useful fact", tier="long")

    proposer_reply = json.dumps({"edits": [{"verb": "delete", "source_id": 1}]})
    judge_reply = json.dumps({"verdicts": [{"index": 0, "accept": True}]})
    consolidator = MemoryConsolidator(
        store=store,
        proposer=_scripted_llm([proposer_reply]),
        adversary=_scripted_llm(["acceptable"]),
        judge=_scripted_llm([judge_reply]),
        now_fn=lambda: clock[0],
    )
    counts = await consolidator.consolidate_user("alice")

    assert counts.deletes_applied == 1
    assert await store.search("alice", "redundant", k=5) == []
    survivors = await store.search("alice", "useful", k=5)
    assert len(survivors) == 1


# ---------------------------------------------------------------------------
# Error paths
# ---------------------------------------------------------------------------


async def test_consolidate_proposer_raises_records_error_audit(tmp_db_path: Path) -> None:
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)
    await store.add("alice", "fact one", tier="long")

    async def _explode(_prompt: str) -> str:
        raise RuntimeError("boom")

    consolidator = MemoryConsolidator(
        store=store,
        proposer=_explode,
        adversary=_scripted_llm([]),
        judge=_scripted_llm([]),
        now_fn=lambda: clock[0],
    )
    counts = await consolidator.consolidate_user("alice")

    assert counts == ConsolidationCounts(0, 0, 0)
    async with aiosqlite.connect(tmp_db_path) as conn:
        cur = await conn.execute("SELECT error FROM consolidation_runs")
        rows = list(await cur.fetchall())
    assert rows
    assert rows[0][0] is not None and "boom" in rows[0][0]

    # No archives.
    hits = await store.search("alice", "fact", k=5)
    assert len(hits) == 1


async def test_consolidate_apply_failure_emits_zero_counts(
    tmp_db_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """`store.apply_consolidation` raising must not crash the run."""
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)
    await store.add("alice", "fact", tier="long")

    async def _boom(_run: Any) -> Any:
        raise RuntimeError("disk full")

    monkeypatch.setattr(store, "apply_consolidation", _boom)

    proposer_reply = json.dumps({"edits": [{"verb": "delete", "source_id": 1}]})
    judge_reply = json.dumps({"verdicts": [{"index": 0, "accept": True}]})
    tracer = _CaptureTracer()
    consolidator = MemoryConsolidator(
        store=store,
        proposer=_scripted_llm([proposer_reply]),
        adversary=_scripted_llm(["ok"]),
        judge=_scripted_llm([judge_reply]),
        tracer=tracer,
        now_fn=lambda: clock[0],
    )
    counts = await consolidator.consolidate_user("alice")
    assert counts == ConsolidationCounts(0, 0, 0)
    # Event still emitted with zero applied counts.
    assert len(tracer.events) == 1
    assert tracer.events[0].merges_applied == 0


async def test_consolidate_tracer_exception_is_swallowed(tmp_db_path: Path) -> None:
    """A misbehaving tracer must not break the run."""
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)

    class _BadTracer:
        def on_event(self, _event: Any) -> None:
            raise RuntimeError("tracer broke")

    consolidator = MemoryConsolidator(
        store=store,
        proposer=_scripted_llm([]),
        adversary=_scripted_llm([]),
        judge=_scripted_llm([]),
        tracer=_BadTracer(),
        now_fn=lambda: clock[0],
    )
    # Must not raise.
    counts = await consolidator.consolidate_user("alice")
    assert counts == ConsolidationCounts(0, 0, 0)


async def test_consolidate_invalid_batch_size_raises() -> None:
    with pytest.raises(ValueError, match="batch_size"):
        MemoryConsolidator(
            store=None,  # type: ignore[arg-type]
            proposer=_scripted_llm([]),
            adversary=_scripted_llm([]),
            judge=_scripted_llm([]),
            batch_size=0,
        )


async def test_consolidate_drops_hallucinated_ids(tmp_db_path: Path) -> None:
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)
    await store.add("alice", "real fact", tier="long")

    proposer_reply = json.dumps({"edits": [{"verb": "delete", "source_id": 9999}]})
    consolidator = MemoryConsolidator(
        store=store,
        proposer=_scripted_llm([proposer_reply]),
        adversary=_scripted_llm([]),  # never called: zero proposals after filtering
        judge=_scripted_llm([]),
        now_fn=lambda: clock[0],
    )
    counts = await consolidator.consolidate_user("alice")

    assert counts == ConsolidationCounts(0, 0, 0)
    # Real fact untouched.
    hits = await store.search("alice", "real", k=5)
    assert len(hits) == 1


# ---------------------------------------------------------------------------
# Store primitives — direct assertions
# ---------------------------------------------------------------------------


async def test_list_for_consolidation_orders_by_recency(tmp_db_path: Path) -> None:
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)
    await store.add("alice", "older", tier="long")
    clock[0] += 10
    await store.add("alice", "newer", tier="long")

    # Touch older so it becomes most recent.
    clock[0] += 10
    await store.search("alice", "older", k=5)

    candidates = await store.list_for_consolidation("alice", tier="long", limit=10)
    assert [c.text for c in candidates] == ["older", "newer"]


async def test_list_for_consolidation_skips_archived(tmp_db_path: Path) -> None:
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)
    await store.add("alice", "kept", tier="long")
    await store.add("alice", "gone", tier="long")
    await store.archive([2])

    candidates = await store.list_for_consolidation("alice", tier="long", limit=10)
    assert [c.text for c in candidates] == ["kept"]


async def test_list_for_consolidation_rejects_bad_args(tmp_db_path: Path) -> None:
    store = SqliteUserMemoryStore(tmp_db_path)
    with pytest.raises(ValueError, match="limit"):
        await store.list_for_consolidation("alice", tier="long", limit=0)
    with pytest.raises(ValueError, match="MemoryTier"):
        await store.list_for_consolidation(
            "alice",
            tier="bogus",  # type: ignore[arg-type]
            limit=10,
        )


async def test_apply_consolidation_skips_already_archived_source(tmp_db_path: Path) -> None:
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)
    await store.add("alice", "to be archived", tier="long")
    await store.archive([1])

    run = ConsolidationRunInput(
        run_id="run1",
        user_id="alice",
        started_at=clock[0],
        proposals_generated=1,
        proposals_accepted=1,
        merges=(),
        replaces=(Replace(source_id=1, text="rewritten"),),
        deletes=(),
        proposals_json=None,
        verdicts_json=None,
        error=None,
    )
    counts = await store.apply_consolidation(run)
    # Source already archived → replace silently skipped.
    assert counts.replaces_applied == 0

    # No new "rewritten" row was inserted.
    hits = await store.search("alice", "rewritten", k=5)
    assert hits == []


async def test_apply_consolidation_writes_audit_row_on_noop(tmp_db_path: Path) -> None:
    store = SqliteUserMemoryStore(tmp_db_path)
    run = ConsolidationRunInput(
        run_id="noop1",
        user_id="alice",
        started_at=1_000_000,
        proposals_generated=0,
        proposals_accepted=0,
        merges=(),
        replaces=(),
        deletes=(),
        proposals_json=None,
        verdicts_json=None,
        error=None,
    )
    counts = await store.apply_consolidation(run)
    assert counts == ConsolidationCounts(0, 0, 0)

    async with aiosqlite.connect(tmp_db_path) as conn:
        cur = await conn.execute("SELECT run_id, proposals_generated FROM consolidation_runs")
        rows = list(await cur.fetchall())
    assert rows == [("noop1", 0)]


@pytest.mark.filterwarnings("default::DeprecationWarning")
def test_construction_emits_deprecation_warning(tmp_db_path: Path) -> None:
    """`MemoryConsolidator.__init__` emits one `DeprecationWarning` (Unit 11)."""
    store = _store_with_clock(tmp_db_path, [1_000_000])
    with pytest.warns(DeprecationWarning, match="MemoryConsolidator is deprecated"):
        MemoryConsolidator(
            store=store,
            proposer=_scripted_llm([]),
            adversary=_scripted_llm([]),
            judge=_scripted_llm([]),
        )
