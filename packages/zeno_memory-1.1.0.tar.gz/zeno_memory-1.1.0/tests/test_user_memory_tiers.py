"""Tests for tier-aware bookkeeping on `SqliteUserMemoryStore`.

Covers add() tier kwarg, escalation-only dedup behaviour, search()
read-side touch (last_accessed_at + hit_count), archived_at filtering,
decay-candidate listing, promotion, archival, and prune helpers. The
clock is injected through `now_fn` so tests are deterministic.
"""

from __future__ import annotations

import asyncio
from pathlib import Path

import aiosqlite
import pytest
from zeno.memory.sqlite.user_memory_store import SqliteUserMemoryStore


def _store(path: Path, *, clock: list[int]) -> SqliteUserMemoryStore:
    return SqliteUserMemoryStore(path, now_fn=lambda: clock[0])


async def test_add_default_tier_is_long(tmp_db_path: Path) -> None:
    clock = [1000]
    store = _store(tmp_db_path, clock=clock)
    await store.add("alice", "fact one")
    hits = await store.search("alice", "fact")
    assert hits[0].meta["tier"] == "long"


async def test_add_explicit_short_tier_persists(tmp_db_path: Path) -> None:
    clock = [1000]
    store = _store(tmp_db_path, clock=clock)
    await store.add("alice", "transient", tier="short")
    hits = await store.search("alice", "transient")
    assert hits[0].meta["tier"] == "short"


async def test_dedup_escalates_tier_only(tmp_db_path: Path) -> None:
    clock = [1000]
    store = _store(tmp_db_path, clock=clock)
    await store.add("alice", "alice likes ramen", tier="long")
    # Re-discovery via extraction should not downgrade.
    await store.add("alice", "alice likes ramen", tier="short")
    hits = await store.search("alice", "ramen")
    assert hits[0].meta["tier"] == "long"
    # Explicit upgrade to permanent escalates.
    await store.add("alice", "alice likes ramen", tier="permanent")
    hits = await store.search("alice", "ramen")
    assert hits[0].meta["tier"] == "permanent"


async def test_search_bumps_hit_count_and_last_accessed(tmp_db_path: Path) -> None:
    clock = [1000]
    store = _store(tmp_db_path, clock=clock)
    await store.add("alice", "alice likes ramen")

    clock[0] = 2000
    await store.search("alice", "ramen")
    clock[0] = 3000
    await store.search("alice", "ramen")

    hits = await store.search("alice", "ramen")
    # `search()` returns the row first, then bumps `hit_count`. So after three
    # searches the third call's hits reflect the two prior increments only;
    # the third increment has been written to the row but is not visible on
    # this returned snapshot. A fourth search would observe 3.
    assert hits[0].meta["hit_count"] == 2

    hits = await store.search("alice", "ramen")
    assert hits[0].meta["hit_count"] == 3


async def test_archived_rows_excluded_from_search(tmp_db_path: Path) -> None:
    clock = [1000]
    store = _store(tmp_db_path, clock=clock)
    await store.add("alice", "old fact")
    candidates = await store.list_decay_candidates(tier="long", idle_seconds=0)
    assert len(candidates) == 1
    await store.archive([candidates[0].id])

    hits = await store.search("alice", "old")
    assert hits == []


async def test_list_decay_candidates_uses_created_at_when_never_accessed(
    tmp_db_path: Path,
) -> None:
    clock = [1000]
    store = _store(tmp_db_path, clock=clock)
    await store.add("alice", "fresh fact", tier="short")

    # 1 second later — not yet idle.
    clock[0] = 1001
    candidates = await store.list_decay_candidates(tier="short", idle_seconds=10)
    assert candidates == []

    # 100 seconds later — idle.
    clock[0] = 1100
    candidates = await store.list_decay_candidates(tier="short", idle_seconds=10)
    assert len(candidates) == 1
    assert candidates[0].user_id == "alice"
    assert candidates[0].hit_count == 0


async def test_list_decay_candidates_uses_last_accessed_when_set(
    tmp_db_path: Path,
) -> None:
    clock = [1000]
    store = _store(tmp_db_path, clock=clock)
    await store.add("alice", "warm fact", tier="short")

    clock[0] = 5000
    await store.search("alice", "warm")  # bumps last_accessed_at to 5000

    # Even though created_at is at 1000, the recent access reset the idle window.
    clock[0] = 5050
    assert await store.list_decay_candidates(tier="short", idle_seconds=100) == []

    clock[0] = 5200
    candidates = await store.list_decay_candidates(tier="short", idle_seconds=100)
    assert len(candidates) == 1


async def test_promote_changes_tier(tmp_db_path: Path) -> None:
    clock = [1000]
    store = _store(tmp_db_path, clock=clock)
    await store.add("alice", "graduate me", tier="short")
    candidates = await store.list_decay_candidates(tier="short", idle_seconds=0)
    n = await store.promote([c.id for c in candidates], to_tier="long")
    assert n == 1
    hits = await store.search("alice", "graduate")
    assert hits[0].meta["tier"] == "long"


async def test_archive_marks_archived_at(tmp_db_path: Path) -> None:
    clock = [1000]
    store = _store(tmp_db_path, clock=clock)
    await store.add("alice", "to-archive", tier="short")
    candidates = await store.list_decay_candidates(tier="short", idle_seconds=0)
    clock[0] = 9999
    n = await store.archive([c.id for c in candidates])
    assert n == 1

    prune_ids = await store.list_prune_candidates(archived_before=10000)
    assert prune_ids == [candidates[0].id]


async def test_hard_delete_removes_rows(tmp_db_path: Path) -> None:
    clock = [1000]
    store = _store(tmp_db_path, clock=clock)
    await store.add("alice", "delete me")
    candidates = await store.list_decay_candidates(tier="long", idle_seconds=0)
    # hard_delete only acts on archived rows — archive first, then delete.
    await store.archive([c.id for c in candidates])
    deleted = await store.hard_delete([c.id for c in candidates])
    assert deleted == 1
    assert await store.search("alice", "delete") == []


async def test_hard_delete_skips_unarchived_rows(tmp_db_path: Path) -> None:
    """BUG-015: hard_delete must not remove rows that are still active."""
    clock = [1000]
    store = _store(tmp_db_path, clock=clock)
    await store.add("alice", "still active")
    candidates = await store.list_decay_candidates(tier="long", idle_seconds=0)
    deleted = await store.hard_delete([c.id for c in candidates])
    assert deleted == 0
    # The row is still searchable.
    hits = await store.search("alice", "active")
    assert len(hits) == 1


@pytest.mark.parametrize("ids", [[], ()])
async def test_maintenance_helpers_no_op_on_empty(
    tmp_db_path: Path, ids: list[int] | tuple[int, ...]
) -> None:
    clock = [1000]
    store = _store(tmp_db_path, clock=clock)
    # All three helpers should return 0 without erroring on empty input.
    assert await store.promote(ids, to_tier="long") == 0
    assert await store.archive(ids) == 0
    assert await store.hard_delete(ids) == 0


# ---------------------------------------------------------------------------
# Adversarial-review regression tests (BUG-001/002/004/007/009/010/012/013/014/017)
# ---------------------------------------------------------------------------


async def _row_id_by_text(path: Path, *, user_id: str, text: str) -> int:
    """Test helper: read a row's id by exact text. Used when public APIs
    intentionally hide row ids (e.g., for permanent rows that
    `list_decay_candidates` refuses to surface)."""
    import aiosqlite

    async with aiosqlite.connect(str(path)) as conn:
        cur = await conn.execute(
            "SELECT id FROM user_memories WHERE user_id = ? AND text = ?",
            (user_id, text),
        )
        row = await cur.fetchone()
    assert row is not None
    return int(row[0])


# BUG-001: re-adding text whose previous row was archived must produce a
# fresh visible row, not silently update the archived dead row.
async def test_add_after_archive_inserts_fresh_row(tmp_db_path: Path) -> None:
    clock = [1000]
    store = _store(tmp_db_path, clock=clock)
    await store.add("alice", "fact x", tier="short")
    cands = await store.list_decay_candidates(tier="short", idle_seconds=0)
    await store.archive([cands[0].id])

    clock[0] = 2000
    await store.add("alice", "fact x", tier="long")

    hits = await store.search("alice", "fact")
    assert len(hits) == 1
    assert hits[0].meta["tier"] == "long"


# BUG-002: promote() never demotes — permanent rows survive a misdirected
# downgrade, and the call returns 0 (no rows changed) instead of silently
# corrupting tier state.
async def test_promote_does_not_demote_permanent(tmp_db_path: Path) -> None:
    clock = [1000]
    store = _store(tmp_db_path, clock=clock)
    await store.add("alice", "perm fact", tier="permanent")
    perm_id = await _row_id_by_text(tmp_db_path, user_id="alice", text="perm fact")

    assert await store.promote([perm_id], to_tier="short") == 0
    assert await store.promote([perm_id], to_tier="long") == 0

    hits = await store.search("alice", "perm")
    assert hits[0].meta["tier"] == "permanent"


async def test_promote_skips_rows_already_at_or_above_target(
    tmp_db_path: Path,
) -> None:
    clock = [1000]
    store = _store(tmp_db_path, clock=clock)
    await store.add("alice", "long fact", tier="long")
    long_id = await _row_id_by_text(tmp_db_path, user_id="alice", text="long fact")

    # long → long is a no-op; long → short is rejected.
    assert await store.promote([long_id], to_tier="long") == 0
    assert await store.promote([long_id], to_tier="short") == 0


# BUG-004: permanent never decays — `list_decay_candidates` refuses the
# terminal tier loudly so a maintenance bug cannot accidentally archive
# permanent memories.
async def test_list_decay_candidates_rejects_permanent_tier(tmp_db_path: Path) -> None:
    clock = [1000]
    store = _store(tmp_db_path, clock=clock)
    await store.add("alice", "perm fact", tier="permanent")

    with pytest.raises(ValueError, match="permanent"):
        await store.list_decay_candidates(tier="permanent", idle_seconds=0)


# BUG-007: invalid tier strings are rejected at the API boundary with a
# helpful ValueError instead of a bare KeyError leaking from internals.
async def test_add_rejects_invalid_tier(tmp_db_path: Path) -> None:
    store = _store(tmp_db_path, clock=[1000])
    with pytest.raises(ValueError, match="Invalid MemoryTier"):
        await store.add("alice", "fact", tier="LONG")  # type: ignore[arg-type]


async def test_promote_rejects_invalid_to_tier(tmp_db_path: Path) -> None:
    store = _store(tmp_db_path, clock=[1000])
    await store.add("alice", "fact", tier="short")
    fact_id = await _row_id_by_text(tmp_db_path, user_id="alice", text="fact")
    with pytest.raises(ValueError, match="Invalid MemoryTier"):
        await store.promote([fact_id], to_tier="archived")  # type: ignore[arg-type]


# BUG-009: DB-truth `tier` and `hit_count` always win over user-supplied
# meta keys with the same name. The synthesized fields are not shadow-able.
async def test_search_meta_db_truth_wins_over_user_meta(tmp_db_path: Path) -> None:
    store = _store(tmp_db_path, clock=[1000])
    await store.add(
        "alice",
        "fact",
        meta={"tier": "permanent", "hit_count": 999, "source": "irc"},
        tier="short",
    )
    hits = await store.search("alice", "fact")
    assert hits[0].meta["tier"] == "short"  # DB tier, not user meta
    assert hits[0].meta["hit_count"] == 0  # DB count, not user meta
    assert hits[0].meta["source"] == "irc"  # other user keys still pass through


# BUG-010: invalid k bounds are rejected. SQLite would otherwise treat
# LIMIT -1 as no-limit and dump the entire user's memory set.
@pytest.mark.parametrize("bad_k", [0, -1, -42])
async def test_search_rejects_non_positive_k(tmp_db_path: Path, bad_k: int) -> None:
    store = _store(tmp_db_path, clock=[1000])
    await store.add("alice", "fact", tier="long")
    with pytest.raises(ValueError, match="k must be"):
        await store.search("alice", "fact", k=bad_k)


# BUG-012: archive() is idempotent — re-archiving an already-archived row
# does NOT refresh archived_at, so the prune window is fixed at first
# archive time.
async def test_archive_already_archived_row_is_no_op(tmp_db_path: Path) -> None:
    clock = [1000]
    store = _store(tmp_db_path, clock=clock)
    await store.add("alice", "fact", tier="short")
    cands = await store.list_decay_candidates(tier="short", idle_seconds=0)

    clock[0] = 2000
    assert await store.archive([cands[0].id]) == 1

    clock[0] = 9000  # later sweep
    assert await store.archive([cands[0].id]) == 0  # already archived

    # Prune window is anchored at the first archive (t=2000), not at t=9000.
    assert await store.list_prune_candidates(archived_before=2001) == [cands[0].id]


# BUG-013 + BUG-014: _DecayCandidate is hashable and identity-keyed by `id`.
# Two snapshots of the same row with different hit_counts compare equal and
# can coexist in a set.
def test_decay_candidate_is_hashable_and_identity_keyed() -> None:
    from zeno.memory.sqlite.user_memory_store import _DecayCandidate

    a = _DecayCandidate(id=7, user_id="alice", hit_count=0)
    b = _DecayCandidate(id=7, user_id="alice", hit_count=5)
    c = _DecayCandidate(id=8, user_id="alice", hit_count=0)

    assert a == b  # same id → equal even with different hit_count
    assert hash(a) == hash(b)
    assert {a, b, c} == {a, c}  # set dedups by id


# BUG-017: re-adding via dedup refreshes last_accessed_at so an actively
# extracted fact is not archived as idle.
async def test_dedup_refreshes_last_accessed_at(tmp_db_path: Path) -> None:
    clock = [1000]
    store = _store(tmp_db_path, clock=clock)
    await store.add("alice", "active fact", tier="short")

    # Way past the idle window for the original created_at...
    clock[0] = 1_000_000
    # ...but a re-extraction lands now and resets the idle clock.
    await store.add("alice", "active fact", tier="short")

    clock[0] = 1_000_050  # 50s after re-add
    assert await store.list_decay_candidates(tier="short", idle_seconds=100) == []

    clock[0] = 1_000_200  # 200s after re-add — now idle
    cands = await store.list_decay_candidates(tier="short", idle_seconds=100)
    assert len(cands) == 1


async def test_concurrent_add_same_text_does_not_duplicate(tmp_db_path: Path) -> None:
    """BUG-002: SELECT-then-INSERT in `add()` must be atomic.

    Two concurrent add() calls for the same `(user_id, text)` must end with
    exactly one active row. Without `BEGIN IMMEDIATE` both racers see
    `existing = None` from the SELECT and both INSERT, producing duplicates.
    """
    clock = [1000]
    store = _store(tmp_db_path, clock=clock)

    # Race 32 callers; if the lock is missing this almost always produces
    # duplicates on a hot WAL.
    await asyncio.gather(*(store.add("alice", "alice likes ramen") for _ in range(32)))

    conn = await aiosqlite.connect(tmp_db_path)
    try:
        cur = await conn.execute(
            "SELECT COUNT(*) FROM user_memories "
            "WHERE user_id = 'alice' AND text = 'alice likes ramen' "
            "  AND archived_at IS NULL"
        )
        row = await cur.fetchone()
    finally:
        await conn.close()
    assert row is not None
    assert row[0] == 1


async def test_post_init_connection_has_busy_timeout(tmp_db_path: Path) -> None:
    """BUG-004: every `_connect()` must set `PRAGMA busy_timeout`.

    `ensure_schema` only runs on the first connection. Without an
    explicit per-connection pragma the post-init connections inherit
    SQLite's default 0 ms timeout and fail immediately under contention.
    """
    clock = [1000]
    store = _store(tmp_db_path, clock=clock)

    # Force schema init via a real call.
    await store.add("alice", "warm up")

    # Open a brand-new connection through `_connect` (post-init path).
    conn = await store._connect()
    try:
        cur = await conn.execute("PRAGMA busy_timeout")
        row = await cur.fetchone()
    finally:
        await conn.close()
    assert row is not None
    assert row[0] == 30000
