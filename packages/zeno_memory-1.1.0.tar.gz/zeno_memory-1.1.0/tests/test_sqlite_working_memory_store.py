"""Contract tests for `SqliteWorkingMemoryStore`.

Cover the verbs the `WorkingMemoryStore` protocol promises (R2/R3/R5/R6/R7/R10):
upsert with last-write-wins, partial-patch isolation, empty-string-as-clear,
namespacing across `(user_id, agent_id)` pairs, and concurrent writers.
"""

from __future__ import annotations

import asyncio
from collections.abc import Iterator
from pathlib import Path

import pytest
from zeno.memory.protocols import WorkingMemoryRecord, WorkingMemoryStore
from zeno.memory.sqlite.working_memory_store import SqliteWorkingMemoryStore


@pytest.fixture
def now_seq() -> Iterator[list[int]]:
    """Returns a list the test populates and the store consumes via `now_fn`."""

    yield []


def _make_store(path: Path, now_seq: list[int]) -> SqliteWorkingMemoryStore:
    """Build a store that returns each successive `now_seq` value per call.

    Falls back to a constant if the test ran out of values, so a missed
    `pop` doesn't crash; tests that care about freshness assert specific
    values.
    """

    fallback = 1_700_000_000

    def _now() -> int:
        return now_seq.pop(0) if now_seq else fallback

    return SqliteWorkingMemoryStore(path, now_fn=_now)


def test_store_satisfies_runtime_checkable_protocol(tmp_db_path: Path) -> None:
    store = SqliteWorkingMemoryStore(tmp_db_path)
    assert isinstance(store, WorkingMemoryStore)


async def test_update_inserts_and_get_returns_record(tmp_db_path: Path, now_seq: list[int]) -> None:
    now_seq.extend([1_700_000_001])
    store = _make_store(tmp_db_path, now_seq)

    await store.update("alice", "coder", {"name": "Alice"})
    rows = await store.get("alice", "coder")

    assert set(rows.keys()) == {"name"}
    record = rows["name"]
    assert record == WorkingMemoryRecord(
        user_id="alice",
        agent_id="coder",
        field_name="name",
        value="Alice",
        last_updated=1_700_000_001,
    )


async def test_update_overwrites_existing_value_and_advances_last_updated(
    tmp_db_path: Path, now_seq: list[int]
) -> None:
    now_seq.extend([1_700_000_001, 1_700_000_010])
    store = _make_store(tmp_db_path, now_seq)

    await store.update("alice", "coder", {"name": "Alice"})
    await store.update("alice", "coder", {"name": "Bob"})

    rows = await store.get("alice", "coder")
    assert rows["name"].value == "Bob"
    assert rows["name"].last_updated == 1_700_000_010


async def test_partial_patch_leaves_other_fields_untouched(
    tmp_db_path: Path, now_seq: list[int]
) -> None:
    now_seq.extend([1_700_000_001, 1_700_000_010])
    store = _make_store(tmp_db_path, now_seq)

    await store.update("alice", "coder", {"name": "Alice"})
    await store.update("alice", "coder", {"role": "Engineer"})

    rows = await store.get("alice", "coder")
    assert rows["name"].value == "Alice"
    assert rows["name"].last_updated == 1_700_000_001
    assert rows["role"].value == "Engineer"
    assert rows["role"].last_updated == 1_700_000_010


async def test_empty_string_value_clears_field(tmp_db_path: Path, now_seq: list[int]) -> None:
    now_seq.extend([1_700_000_001, 1_700_000_010])
    store = _make_store(tmp_db_path, now_seq)

    await store.update("alice", "coder", {"name": "Alice", "role": "Engineer"})
    await store.update("alice", "coder", {"role": ""})

    rows = await store.get("alice", "coder")
    assert set(rows.keys()) == {"name"}
    assert rows["name"].value == "Alice"


async def test_get_for_unseen_pair_returns_empty_dict(tmp_db_path: Path) -> None:
    store = SqliteWorkingMemoryStore(tmp_db_path)
    assert await store.get("alice", "coder") == {}


async def test_clear_removes_pair_rows_only(tmp_db_path: Path, now_seq: list[int]) -> None:
    now_seq.extend([1_700_000_001, 1_700_000_002])
    store = _make_store(tmp_db_path, now_seq)

    await store.update("alice", "coder", {"name": "Alice"})
    await store.update("alice", "triage", {"name": "Triage Alice"})

    await store.clear("alice", "coder")

    assert await store.get("alice", "coder") == {}
    triage_rows = await store.get("alice", "triage")
    assert triage_rows["name"].value == "Triage Alice"


async def test_namespacing_across_agents_and_users(tmp_db_path: Path, now_seq: list[int]) -> None:
    now_seq.extend([1_700_000_001, 1_700_000_002, 1_700_000_003])
    store = _make_store(tmp_db_path, now_seq)

    await store.update("alice", "coder", {"name": "A-Coder"})
    await store.update("alice", "triage", {"name": "A-Triage"})
    await store.update("bob", "coder", {"name": "B-Coder"})

    assert (await store.get("alice", "coder"))["name"].value == "A-Coder"
    assert (await store.get("alice", "triage"))["name"].value == "A-Triage"
    assert (await store.get("bob", "coder"))["name"].value == "B-Coder"


async def test_whitespace_value_stored_verbatim(tmp_db_path: Path, now_seq: list[int]) -> None:
    """Only literal `""` clears; whitespace-only is not normalised."""

    now_seq.extend([1_700_000_001])
    store = _make_store(tmp_db_path, now_seq)

    await store.update("alice", "coder", {"role": "   "})

    rows = await store.get("alice", "coder")
    assert rows["role"].value == "   "


async def test_empty_patch_is_noop(tmp_db_path: Path) -> None:
    store = SqliteWorkingMemoryStore(tmp_db_path)
    await store.update("alice", "coder", {})
    assert await store.get("alice", "coder") == {}


async def test_concurrent_updates_serialize_with_last_write_winning(
    tmp_db_path: Path,
) -> None:
    """Two coroutines updating the same field both succeed; last write wins.

    The per-store `asyncio.Lock` serializes writers so the final stored
    value is one of the two inputs (not a half-written hybrid). We can't
    deterministically assert which write goes last across runs, so we
    assert the value is one of the two and `last_updated` matches the
    winning write's timestamp.
    """

    timestamps = iter([1_700_000_001, 1_700_000_010])
    store = SqliteWorkingMemoryStore(tmp_db_path, now_fn=lambda: next(timestamps))

    await asyncio.gather(
        store.update("alice", "coder", {"name": "Alice"}),
        store.update("alice", "coder", {"name": "Bob"}),
    )

    rows = await store.get("alice", "coder")
    assert rows["name"].value in {"Alice", "Bob"}
    assert rows["name"].last_updated in {1_700_000_001, 1_700_000_010}
