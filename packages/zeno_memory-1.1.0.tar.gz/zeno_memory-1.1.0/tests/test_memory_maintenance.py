"""Tests for `MemoryMaintenance` — the decay + prune background loop."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any

import pytest
from zeno.memory.maintenance import MemoryMaintenance
from zeno.memory.sqlite.user_memory_store import SqliteUserMemoryStore
from zeno.observability.events import MemoryDecayed, MemoryPruned

# `MemoryMaintenance` emits a `DeprecationWarning` from `__init__` (Unit 11).
# These tests construct the legacy class on every case; silence the warning
# at module level. A dedicated test below asserts the warning fires.
pytestmark = pytest.mark.filterwarnings("ignore::DeprecationWarning")


@dataclass
class _CaptureTracer:
    events: list[Any] = field(default_factory=list)

    def on_event(self, event: Any) -> None:
        self.events.append(event)

    def of_kind(self, kind: str) -> list[Any]:
        return [e for e in self.events if e.kind == kind]


def _store_with_clock(tmp_db_path: Any, clock: list[int]) -> SqliteUserMemoryStore:
    return SqliteUserMemoryStore(tmp_db_path, now_fn=lambda: clock[0])


# ---------------------------------------------------------------------------
# decay_now: tier guards + happy paths
# ---------------------------------------------------------------------------


async def test_decay_now_rejects_permanent() -> None:
    m = MemoryMaintenance(store=None)  # type: ignore[arg-type]
    with pytest.raises(ValueError, match="permanent"):
        await m.decay_now("permanent")


async def test_decay_short_promotes_when_hits_threshold(tmp_db_path: Any) -> None:
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)
    # Distinct tokens so searches only bump one row at a time.
    await store.add("alice", "alpha word", tier="short")
    await store.add("alice", "beta word", tier="short")
    await store.search("alice", "alpha", k=5)
    await store.search("alice", "alpha", k=5)

    # Move clock forward past short_idle_seconds. Fully resetting
    # last_accessed_at on every row by computing the cutoff against the
    # fresh clock value.
    clock[0] += 8 * 24 * 3600

    tracer = _CaptureTracer()
    m = MemoryMaintenance(
        store=store,
        tracer=tracer,
        short_idle_seconds=7 * 24 * 3600,
        promote_short_at_hits=2,
        now_fn=lambda: clock[0],
    )
    event = await m.decay_now("short")

    assert isinstance(event, MemoryDecayed)
    assert event.tier == "short"
    assert event.candidates_seen == 2
    assert event.promoted == 1
    assert event.archived == 1
    assert tracer.events == [event]

    # The promoted row is now in `long` tier; the archived row is gone from search.
    long_hits = await store.search("alice", "alpha", k=5)
    assert long_hits and long_hits[0].meta["tier"] == "long"
    archived = await store.search("alice", "beta", k=5)
    assert archived == []


async def test_decay_long_promotes_to_permanent(tmp_db_path: Any) -> None:
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)
    await store.add("alice", "important fact", tier="long")
    # Hit it 5 times.
    for _ in range(5):
        await store.search("alice", "important fact", k=5)

    clock[0] += 31 * 24 * 3600

    m = MemoryMaintenance(
        store=store,
        long_idle_seconds=30 * 24 * 3600,
        promote_long_at_hits=5,
        now_fn=lambda: clock[0],
    )
    event = await m.decay_now("long")
    assert event.promoted == 1
    assert event.archived == 0

    hits = await store.search("alice", "important fact", k=5)
    assert hits and hits[0].meta["tier"] == "permanent"


async def test_decay_archives_when_below_threshold(tmp_db_path: Any) -> None:
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)
    await store.add("alice", "forgettable", tier="short")
    clock[0] += 8 * 24 * 3600

    m = MemoryMaintenance(
        store=store,
        short_idle_seconds=7 * 24 * 3600,
        promote_short_at_hits=2,
        now_fn=lambda: clock[0],
    )
    event = await m.decay_now("short")
    assert event.candidates_seen == 1
    assert event.promoted == 0
    assert event.archived == 1
    assert await store.search("alice", "forgettable", k=5) == []


# ---------------------------------------------------------------------------
# prune_now: archived → hard delete after retention
# ---------------------------------------------------------------------------


async def test_prune_now_disabled_raises(tmp_db_path: Any) -> None:
    store = SqliteUserMemoryStore(tmp_db_path)
    m = MemoryMaintenance(store=store, prune_after_seconds=None)
    with pytest.raises(RuntimeError, match="disabled"):
        await m.prune_now()


async def test_prune_now_deletes_archived_past_retention(tmp_db_path: Any) -> None:
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)
    await store.add("alice", "old", tier="short")
    await store.add("alice", "fresh", tier="short")
    # Archive both immediately.
    # We need their ids; SqliteUserMemoryStore exposes hard_delete by id but
    # archive takes ids too -- the simplest path is to use the maintenance
    # decay sweep with a 0-idle window to archive everything.
    clock[0] += 1
    m = MemoryMaintenance(
        store=store,
        short_idle_seconds=0,
        promote_short_at_hits=999,
        prune_after_seconds=10 * 24 * 3600,
        now_fn=lambda: clock[0],
    )
    await m.decay_now("short")  # archives both rows at clock=1_000_001

    # Move clock past retention for one row only -- but both rows share
    # the same archived_at (1_000_001). So we need both to age out together.
    clock[0] += 11 * 24 * 3600

    tracer = _CaptureTracer()
    m._tracer = tracer
    event = await m.prune_now()
    assert isinstance(event, MemoryPruned)
    assert event.pruned_count == 2
    assert event.archived_before == clock[0] - 10 * 24 * 3600
    assert tracer.events == [event]


async def test_prune_now_skips_recently_archived(tmp_db_path: Any) -> None:
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)
    await store.add("alice", "still recent", tier="short")
    clock[0] += 1

    m = MemoryMaintenance(
        store=store,
        short_idle_seconds=0,
        promote_short_at_hits=999,
        prune_after_seconds=10 * 24 * 3600,
        now_fn=lambda: clock[0],
    )
    await m.decay_now("short")
    # Don't advance the clock past retention.
    event = await m.prune_now()
    assert event.pruned_count == 0


# ---------------------------------------------------------------------------
# Loop lifecycle: start/stop, wait_idle, errors do not crash
# ---------------------------------------------------------------------------


async def test_start_is_idempotent(tmp_db_path: Any) -> None:
    store = SqliteUserMemoryStore(tmp_db_path)
    m = MemoryMaintenance(store=store, tick_s=10.0)
    await m.start()
    first = m._task
    await m.start()
    assert m._task is first
    await m.stop()


async def test_stop_without_start_is_safe(tmp_db_path: Any) -> None:
    store = SqliteUserMemoryStore(tmp_db_path)
    m = MemoryMaintenance(store=store)
    await m.stop()  # must not raise


async def test_loop_runs_decay_for_both_tiers_on_tick(tmp_db_path: Any) -> None:
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)
    tracer = _CaptureTracer()
    m = MemoryMaintenance(
        store=store,
        tracer=tracer,
        tick_s=3600.0,  # large; we will wake manually
        short_idle_seconds=0,
        long_idle_seconds=0,
        prune_after_seconds=None,
        now_fn=lambda: clock[0],
    )
    await m.start()
    try:
        await asyncio.wait_for(m.wait_idle(), timeout=2.0)
    finally:
        await m.stop()
    decayed = tracer.of_kind("memory_decayed")
    tiers = sorted(e.tier for e in decayed)
    assert tiers == ["long", "short"]


async def test_loop_continues_after_sweep_error(tmp_db_path: Any, caplog: Any) -> None:
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)

    real_list = store.list_decay_candidates
    calls = {"n": 0}

    async def flaky_list(**kwargs: Any) -> Any:
        calls["n"] += 1
        if calls["n"] == 1:
            raise RuntimeError("transient store hiccup")
        return await real_list(**kwargs)

    store.list_decay_candidates = flaky_list  # type: ignore[method-assign]

    tracer = _CaptureTracer()
    m = MemoryMaintenance(
        store=store,
        tracer=tracer,
        tick_s=3600.0,
        prune_after_seconds=None,
        now_fn=lambda: clock[0],
    )
    await m.start()
    try:
        await asyncio.wait_for(m.wait_idle(), timeout=2.0)
        await asyncio.wait_for(m.wait_idle(), timeout=2.0)
    finally:
        await m.stop()
    # Both ticks emitted decay events even though the first sweep hit the
    # injected error -- the loop did not crash.
    assert len(tracer.of_kind("memory_decayed")) >= 2


async def test_loop_runs_prune_when_due(tmp_db_path: Any) -> None:
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)
    tracer = _CaptureTracer()
    m = MemoryMaintenance(
        store=store,
        tracer=tracer,
        tick_s=3600.0,
        prune_after_seconds=10,
        prune_interval_s=1.0,
        short_idle_seconds=0,
        long_idle_seconds=0,
        now_fn=lambda: clock[0],
    )
    await m.start()
    try:
        await asyncio.wait_for(m.wait_idle(), timeout=2.0)
    finally:
        await m.stop()
    assert tracer.of_kind("memory_pruned"), "first tick should have pruned"


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


def test_invalid_promote_thresholds_rejected(tmp_db_path: Any) -> None:
    store = SqliteUserMemoryStore(tmp_db_path)
    with pytest.raises(ValueError):
        MemoryMaintenance(store=store, promote_short_at_hits=0)
    with pytest.raises(ValueError):
        MemoryMaintenance(store=store, promote_long_at_hits=0)


def test_invalid_tick_rejected(tmp_db_path: Any) -> None:
    store = SqliteUserMemoryStore(tmp_db_path)
    with pytest.raises(ValueError):
        MemoryMaintenance(store=store, tick_s=0)


def test_invalid_prune_interval_rejected(tmp_db_path: Any) -> None:
    store = SqliteUserMemoryStore(tmp_db_path)
    with pytest.raises(ValueError, match="prune_interval_s"):
        MemoryMaintenance(store=store, prune_interval_s=0)
    with pytest.raises(ValueError, match="prune_interval_s"):
        MemoryMaintenance(store=store, prune_interval_s=-5)


# ---------------------------------------------------------------------------
# Lifecycle / failure-mode regression tests (review-2 fixes)
# ---------------------------------------------------------------------------


async def test_wait_idle_raises_when_not_running(tmp_db_path: Any) -> None:
    """Without this guard, wait_idle blocks forever waiting for `_cycle_done`."""
    store = SqliteUserMemoryStore(tmp_db_path)
    m = MemoryMaintenance(store=store)
    with pytest.raises(RuntimeError, match="not running"):
        await m.wait_idle()
    await m.start()
    await m.stop()
    with pytest.raises(RuntimeError, match="not running"):
        await m.wait_idle()


async def test_loop_releases_wait_idle_on_cancel(tmp_db_path: Any) -> None:
    """Stopping mid-cycle must unblock any in-flight `wait_idle()`."""
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)

    block = asyncio.Event()

    async def slow_list(**_kwargs: Any) -> Any:
        await block.wait()
        return []

    store.list_decay_candidates = slow_list  # type: ignore[method-assign]

    m = MemoryMaintenance(
        store=store,
        tick_s=3600.0,
        prune_after_seconds=None,
        now_fn=lambda: clock[0],
    )
    await m.start()
    waiter = asyncio.create_task(m.wait_idle())
    # Give the first decay sweep a chance to enter `slow_list`.
    await asyncio.sleep(0.05)
    await m.stop()  # cancels the task while it is awaiting `block`
    block.set()  # release the slow path so the cancelled task can unwind
    # The waiter must not deadlock — `_cycle_done.set()` runs in the
    # finally block / cancellation handler.
    await asyncio.wait_for(waiter, timeout=2.0)


async def test_prune_failure_does_not_advance_cooldown(tmp_db_path: Any) -> None:
    """A failed prune must retry on the next tick instead of waiting 24h."""
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)

    failures = {"n": 0}
    real_list = store.list_prune_candidates

    async def flaky_list(**kwargs: Any) -> Any:
        failures["n"] += 1
        if failures["n"] == 1:
            raise RuntimeError("transient prune failure")
        return await real_list(**kwargs)

    store.list_prune_candidates = flaky_list  # type: ignore[method-assign]

    m = MemoryMaintenance(
        store=store,
        prune_after_seconds=10,
        prune_interval_s=3600.0,  # large; failure must NOT advance the timer
        now_fn=lambda: clock[0],
    )
    first = await m.prune_now()
    assert first.error is True
    assert m._last_prune_at is None  # cooldown unchanged after error

    second = await m.prune_now()
    assert second.error is False
    assert m._last_prune_at == clock[0]


async def test_decay_event_carries_error_flag(tmp_db_path: Any) -> None:
    clock = [1_000_000]
    store = _store_with_clock(tmp_db_path, clock)

    async def boom(**_kwargs: Any) -> Any:
        raise RuntimeError("decay failure")

    store.list_decay_candidates = boom  # type: ignore[method-assign]

    m = MemoryMaintenance(store=store, now_fn=lambda: clock[0])
    event = await m.decay_now("short")
    assert event.error is True
    assert event.candidates_seen == 0


@pytest.mark.filterwarnings("default::DeprecationWarning")
def test_construction_emits_deprecation_warning() -> None:
    """`MemoryMaintenance.__init__` emits one `DeprecationWarning` (Unit 11)."""
    with pytest.warns(DeprecationWarning, match="MemoryMaintenance is deprecated"):
        MemoryMaintenance(store=None)  # type: ignore[arg-type]
