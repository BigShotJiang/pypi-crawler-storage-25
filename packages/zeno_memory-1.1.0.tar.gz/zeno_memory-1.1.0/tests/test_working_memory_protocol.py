"""Contract tests for the `WorkingMemoryStore` protocol and `WorkingMemoryView` handle.

The view's job is to bind `(user_id, agent_id)` and forward verbs to the
store; the store's interpretation of empty-string-as-clear is exercised
in `test_sqlite_working_memory_store.py`. These tests use a tiny dict
fake so the abstract surface is locked down independently of any backend.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from zeno.memory.handles import WorkingMemoryView
from zeno.memory.protocols import (
    WorkingMemoryRecord,
    WorkingMemoryStore,
)


@dataclass
class _FakeWorkingMemoryStore:
    """Dict-backed fake; records every call so tests can assert delegation."""

    rows: dict[tuple[str, str, str], WorkingMemoryRecord] = field(default_factory=dict)
    update_calls: list[tuple[str, str, dict[str, str]]] = field(default_factory=list)
    clear_calls: list[tuple[str, str]] = field(default_factory=list)
    now: int = 1_700_000_000

    async def get(self, user_id: str, agent_id: str) -> dict[str, WorkingMemoryRecord]:
        return {
            field_name: rec
            for (uid, aid, field_name), rec in self.rows.items()
            if uid == user_id and aid == agent_id
        }

    async def update(self, user_id: str, agent_id: str, patch: dict[str, str]) -> None:
        self.update_calls.append((user_id, agent_id, patch))
        for field_name, value in patch.items():
            self.rows[(user_id, agent_id, field_name)] = WorkingMemoryRecord(
                user_id=user_id,
                agent_id=agent_id,
                field_name=field_name,
                value=value,
                last_updated=self.now,
            )

    async def clear(self, user_id: str, agent_id: str) -> None:
        self.clear_calls.append((user_id, agent_id))
        self.rows = {
            key: rec
            for key, rec in self.rows.items()
            if not (key[0] == user_id and key[1] == agent_id)
        }


def test_fake_satisfies_runtime_checkable_protocol() -> None:
    """Sanity: the fake structurally matches `WorkingMemoryStore`."""

    fake = _FakeWorkingMemoryStore()
    assert isinstance(fake, WorkingMemoryStore)


async def test_view_delegates_get_with_bound_ids() -> None:
    store = _FakeWorkingMemoryStore()
    await store.update("alice", "coder", {"name": "Alice"})
    view = WorkingMemoryView(_store=store, _user_id="alice", _agent_id="coder")

    result = await view.get()

    assert set(result.keys()) == {"name"}
    assert result["name"].value == "Alice"
    assert result["name"].user_id == "alice"
    assert result["name"].agent_id == "coder"


async def test_view_delegates_update_with_bound_ids() -> None:
    store = _FakeWorkingMemoryStore()
    view = WorkingMemoryView(_store=store, _user_id="alice", _agent_id="coder")

    await view.update({"name": "Alice", "role": "Engineer"})

    assert store.update_calls == [
        ("alice", "coder", {"name": "Alice", "role": "Engineer"}),
    ]


async def test_view_delegates_clear_with_bound_ids() -> None:
    store = _FakeWorkingMemoryStore()
    view = WorkingMemoryView(_store=store, _user_id="alice", _agent_id="coder")

    await view.clear()

    assert store.clear_calls == [("alice", "coder")]


async def test_view_get_for_untouched_pair_returns_empty_dict() -> None:
    store = _FakeWorkingMemoryStore()
    view = WorkingMemoryView(_store=store, _user_id="alice", _agent_id="coder")

    assert await view.get() == {}


async def test_view_namespacing_isolates_agents() -> None:
    """Two agents under the same user must not see each other's fields."""

    store = _FakeWorkingMemoryStore()
    coder_view = WorkingMemoryView(_store=store, _user_id="alice", _agent_id="coder")
    triage_view = WorkingMemoryView(_store=store, _user_id="alice", _agent_id="triage")

    await coder_view.update({"name": "Coder Alice"})
    await triage_view.update({"name": "Triage Alice"})

    coder_rows = await coder_view.get()
    triage_rows = await triage_view.get()

    assert coder_rows["name"].value == "Coder Alice"
    assert triage_rows["name"].value == "Triage Alice"


async def test_view_forwards_empty_string_verbatim_for_store_to_clear() -> None:
    """The view does not pre-interpret empty-string; the store decides clear semantics."""

    store = _FakeWorkingMemoryStore()
    view = WorkingMemoryView(_store=store, _user_id="alice", _agent_id="coder")

    await view.update({"role": ""})

    assert store.update_calls == [("alice", "coder", {"role": ""})]
