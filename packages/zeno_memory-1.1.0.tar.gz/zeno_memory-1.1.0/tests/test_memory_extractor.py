"""Unit tests for `MemoryExtractor` — the post-turn extraction hook."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any, cast

import pytest
from zeno.channels.messages import IncomingMessage
from zeno.context import Ctx
from zeno.memory.extractor import MemoryExtractor, _parse_facts
from zeno.memory.sqlite.user_memory_store import SqliteUserMemoryStore
from zeno.observability.events import MemoryExtracted

# `MemoryExtractor` emits a `DeprecationWarning` from `__init__` (Unit 11).
# These tests construct the legacy class on every case; silence the warning
# at module level. A dedicated test below asserts the warning fires.
pytestmark = pytest.mark.filterwarnings("ignore::DeprecationWarning")


@dataclass
class _CaptureTracer:
    events: list[Any] = field(default_factory=list)

    def on_event(self, event: Any) -> None:
        self.events.append(event)


@dataclass
class _Ctx:
    """Minimal duck-typed `Ctx` shape — extractor only reads three fields."""

    user_id: str
    turn_id: str
    session_id: str | None
    tracer: Any


def _msg(text: str = "remember I love mangoes", user_id: str = "alice") -> IncomingMessage:
    return IncomingMessage(user_id=user_id, text=text, received_at=datetime.now(UTC))


def _ctx(tracer: _CaptureTracer | None = None, *, user_id: str = "alice") -> Ctx:
    """Build a duck-typed ctx that satisfies the few fields the extractor reads.

    The extractor only touches `user_id`, `turn_id`, `session_id`, and
    `tracer`; constructing a real `Ctx` would require half a dozen plumbing
    callables. Cast at the boundary so callers stay compact.
    """
    stub = _Ctx(
        user_id=user_id,
        turn_id="turn-1",
        session_id="sess-1",
        tracer=tracer if tracer is not None else _CaptureTracer(),
    )
    return cast(Ctx, stub)


def _llm_returning(reply: str) -> Callable[[str], Awaitable[str]]:
    async def _call(_prompt: str) -> str:
        return reply

    return _call


# ---------------------------------------------------------------------------
# _parse_facts: robust to noise
# ---------------------------------------------------------------------------


def test_parse_facts_clean_array() -> None:
    assert _parse_facts('["fact one", "fact two"]', max_facts=5) == ["fact one", "fact two"]


def test_parse_facts_array_embedded_in_prose() -> None:
    reply = 'Here is the JSON you asked for:\n["a", "b"]\nHope that helps!'
    assert _parse_facts(reply, max_facts=5) == ["a", "b"]


def test_parse_facts_no_array_returns_empty() -> None:
    assert _parse_facts("I don't think anything is worth remembering.", max_facts=5) == []


def test_parse_facts_invalid_json_returns_empty() -> None:
    assert _parse_facts("[not valid, json]", max_facts=5) == []


def test_parse_facts_drops_non_strings() -> None:
    assert _parse_facts('["good", 42, null, "also good"]', max_facts=5) == ["good", "also good"]


def test_parse_facts_caps_at_max() -> None:
    reply = '["a", "b", "c", "d", "e", "f", "g"]'
    assert _parse_facts(reply, max_facts=3) == ["a", "b", "c"]


def test_parse_facts_dedupes_and_strips() -> None:
    assert _parse_facts('["foo", "  foo  ", "", "bar"]', max_facts=5) == ["foo", "bar"]


def test_parse_facts_array_inside_object_is_lifted() -> None:
    """If the model wraps the array in an object, lift the array rather than fail."""
    assert _parse_facts('{"facts": ["x", "y"]}', max_facts=5) == ["x", "y"]


def test_parse_facts_skips_bracketed_prose_before_array() -> None:
    """A noisy reply with bracketed phrases before the real array still parses."""
    reply = 'Note: [per the rules above], here is: ["user likes coffee"]'
    assert _parse_facts(reply, max_facts=5) == ["user likes coffee"]


# ---------------------------------------------------------------------------
# extract_for_turn: end-to-end against SqliteUserMemoryStore
# ---------------------------------------------------------------------------


async def test_extracts_and_writes_facts_to_store(
    user_memory_store: SqliteUserMemoryStore,
) -> None:
    extractor = MemoryExtractor(
        store=user_memory_store,
        llm=_llm_returning('["alice loves mangoes", "alice avoids cilantro"]'),
        min_chars=10,
    )
    tracer = _CaptureTracer()
    await extractor.extract_for_turn(
        _ctx(tracer),
        _msg("I love mangoes and avoid cilantro."),
        "Got it -- I will remember that you love mangoes and avoid cilantro for next time.",
    )

    hits = await user_memory_store.search("alice", "mangoes", k=5)
    assert any("mangoes" in hit.text for hit in hits)
    cilantro = await user_memory_store.search("alice", "cilantro", k=5)
    assert any("cilantro" in hit.text for hit in cilantro)

    [event] = tracer.events
    assert isinstance(event, MemoryExtracted)
    assert event.candidate_count == 2
    assert event.inserted_count == 2
    assert event.error is False


async def test_skips_when_assistant_text_below_min_chars(
    user_memory_store: SqliteUserMemoryStore,
) -> None:
    calls: list[str] = []

    async def _llm(prompt: str) -> str:
        calls.append(prompt)
        return "[]"

    extractor = MemoryExtractor(store=user_memory_store, llm=_llm, min_chars=100)
    tracer = _CaptureTracer()
    await extractor.extract_for_turn(_ctx(tracer), _msg("hello"), "too short")
    assert calls == []
    [event] = tracer.events
    assert event.candidate_count == 0
    assert event.inserted_count == 0
    assert event.error is False


async def test_skips_when_user_text_blank(
    user_memory_store: SqliteUserMemoryStore,
) -> None:
    calls: list[str] = []

    async def _llm(prompt: str) -> str:
        calls.append(prompt)
        return '["should not run"]'

    extractor = MemoryExtractor(store=user_memory_store, llm=_llm, min_chars=0)
    msg = IncomingMessage(user_id="alice", text="   ", received_at=datetime.now(UTC))
    await extractor.extract_for_turn(_ctx(), msg, "x" * 200)
    assert calls == []


async def test_llm_failure_emits_error_event_no_writes(
    user_memory_store: SqliteUserMemoryStore,
) -> None:
    async def _boom(_prompt: str) -> str:
        raise RuntimeError("upstream LLM down")

    extractor = MemoryExtractor(store=user_memory_store, llm=_boom, min_chars=5)
    tracer = _CaptureTracer()
    await extractor.extract_for_turn(_ctx(tracer), _msg(), "a" * 100)

    [event] = tracer.events
    assert event.error is True
    assert event.inserted_count == 0


async def test_unparseable_reply_is_treated_as_zero_facts(
    user_memory_store: SqliteUserMemoryStore,
) -> None:
    extractor = MemoryExtractor(
        store=user_memory_store,
        llm=_llm_returning("I don't have anything to remember today."),
        min_chars=5,
    )
    tracer = _CaptureTracer()
    await extractor.extract_for_turn(_ctx(tracer), _msg(), "a" * 100)
    [event] = tracer.events
    assert event.candidate_count == 0
    assert event.inserted_count == 0
    assert event.error is False


async def test_partial_store_failure_marks_event_errored(
    user_memory_store: SqliteUserMemoryStore,
) -> None:
    """When one fact fails to insert, others still land and the event flags the run."""
    calls = {"n": 0}
    real_add = user_memory_store.add

    async def flaky_add(*args: Any, **kwargs: Any) -> None:
        calls["n"] += 1
        if calls["n"] == 2:
            raise RuntimeError("store hiccup")
        await real_add(*args, **kwargs)

    user_memory_store.add = flaky_add  # type: ignore[method-assign]

    extractor = MemoryExtractor(
        store=user_memory_store,
        llm=_llm_returning('["one", "two", "three"]'),
        min_chars=5,
    )
    tracer = _CaptureTracer()
    await extractor.extract_for_turn(_ctx(tracer), _msg(), "a" * 100)

    [event] = tracer.events
    assert event.candidate_count == 3
    assert event.inserted_count == 2
    assert event.error is True


async def test_extracted_facts_land_in_short_tier(
    user_memory_store: SqliteUserMemoryStore,
) -> None:
    extractor = MemoryExtractor(
        store=user_memory_store,
        llm=_llm_returning('["alice prefers tea"]'),
        min_chars=5,
    )
    await extractor.extract_for_turn(_ctx(), _msg(), "a" * 100)
    hits = await user_memory_store.search("alice", "tea", k=5)
    assert hits
    assert hits[0].meta["tier"] == "short"
    assert hits[0].meta.get("source") == "extractor"


async def test_event_envelope_carries_turn_and_user(
    user_memory_store: SqliteUserMemoryStore,
) -> None:
    extractor = MemoryExtractor(
        store=user_memory_store,
        llm=_llm_returning("[]"),
        min_chars=5,
    )
    tracer = _CaptureTracer()
    ctx = cast(Ctx, _Ctx(user_id="bob", turn_id="t-42", session_id="s-9", tracer=tracer))
    await extractor.extract_for_turn(ctx, _msg(user_id="bob"), "a" * 100)
    [event] = tracer.events
    assert event.envelope.turn_id == "t-42"
    assert event.envelope.user_id == "bob"
    assert event.envelope.session_id == "s-9"


async def test_max_facts_caps_writes(
    user_memory_store: SqliteUserMemoryStore,
) -> None:
    extractor = MemoryExtractor(
        store=user_memory_store,
        llm=_llm_returning('["a", "b", "c", "d", "e"]'),
        max_facts=2,
        min_chars=5,
    )
    tracer = _CaptureTracer()
    await extractor.extract_for_turn(_ctx(tracer), _msg(), "a" * 100)
    [event] = tracer.events
    assert event.candidate_count == 2
    assert event.inserted_count == 2


def test_min_chars_must_be_non_negative() -> None:
    with pytest.raises(ValueError):
        MemoryExtractor(store=None, llm=_llm_returning("[]"), min_chars=-1)  # type: ignore[arg-type]


def test_max_facts_must_be_positive() -> None:
    with pytest.raises(ValueError):
        MemoryExtractor(store=None, llm=_llm_returning("[]"), max_facts=0)  # type: ignore[arg-type]


async def test_tracer_failure_does_not_propagate(
    user_memory_store: SqliteUserMemoryStore,
) -> None:
    class _BadTracer:
        def on_event(self, _event: Any) -> None:
            raise RuntimeError("tracer down")

    extractor = MemoryExtractor(
        store=user_memory_store,
        llm=_llm_returning('["x"]'),
        min_chars=5,
    )
    ctx = cast(Ctx, _Ctx(user_id="alice", turn_id="t", session_id=None, tracer=_BadTracer()))
    # If the tracer error escaped, this would raise.
    await extractor.extract_for_turn(ctx, _msg(), "a" * 100)


@pytest.mark.filterwarnings("default::DeprecationWarning")
def test_construction_emits_deprecation_warning(
    user_memory_store: SqliteUserMemoryStore,
) -> None:
    """`MemoryExtractor.__init__` emits one `DeprecationWarning` (Unit 11)."""
    with pytest.warns(DeprecationWarning, match="MemoryExtractor is deprecated"):
        MemoryExtractor(store=user_memory_store, llm=_llm_returning("[]"))
