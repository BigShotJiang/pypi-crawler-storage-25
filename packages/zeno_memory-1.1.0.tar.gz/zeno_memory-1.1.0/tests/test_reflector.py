"""Tests for `Reflector` — single-phase observation compressor (L4 Unit 6).

Mirrors the structure of `test_memory_consolidator.py` but adapted for
observations: priority is preserved across `Merge`/`Replace`, and the
3-phase adversary/judge pipeline is opt-in rather than mandatory.
"""

from __future__ import annotations

import json
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import pytest
from zeno.memory._edits import Delete, Merge, Replace
from zeno.memory.protocols import Observation, ObservationCounts
from zeno.memory.reflector import Reflector
from zeno.memory.sqlite.observation_store import SqliteObservationStore
from zeno.observability.events import MemoryReflected


@dataclass
class _CaptureTracer:
    events: list[Any] = field(default_factory=list)

    def on_event(self, event: Any) -> None:
        self.events.append(event)


def _scripted_llm(replies: list[str]) -> Callable[[str], Awaitable[str]]:
    """Return an async callable that yields *replies* in order."""
    queue = list(replies)

    async def _call(_prompt: str) -> str:
        if not queue:
            raise AssertionError("scripted LLM exhausted")
        return queue.pop(0)

    return _call


def _obs(
    user_id: str,
    agent_id: str,
    text: str,
    *,
    priority: str = "medium",
    observation_date: int = 1_700_000_000,
    referenced_date: int | None = None,
    source_round_ids: tuple[int, ...] = (),
) -> Observation:
    return Observation(
        id=0,
        user_id=user_id,
        agent_id=agent_id,
        text=text,
        priority=priority,  # type: ignore[arg-type]
        observation_date=observation_date,
        referenced_date=referenced_date,
        source_round_ids=source_round_ids,
        created_at=observation_date,
    )


# ---------------------------------------------------------------------------
# Construction guards
# ---------------------------------------------------------------------------


def test_constructor_rejects_partial_three_phase_pipeline(tmp_db_path: Path) -> None:
    store = SqliteObservationStore(tmp_db_path)
    with pytest.raises(ValueError, match="adversary and judge"):
        Reflector(
            store=store,
            proposer=_scripted_llm([]),
            adversary=_scripted_llm([]),
            judge=None,
        )
    with pytest.raises(ValueError, match="adversary and judge"):
        Reflector(
            store=store,
            proposer=_scripted_llm([]),
            adversary=None,
            judge=_scripted_llm([]),
        )


# ---------------------------------------------------------------------------
# reflect — happy paths
# ---------------------------------------------------------------------------


async def test_reflect_no_observations_writes_noop_event(tmp_db_path: Path) -> None:
    clock = [1_700_000_000]
    store = SqliteObservationStore(tmp_db_path, now_fn=lambda: clock[0])
    tracer = _CaptureTracer()

    reflector = Reflector(
        store=store,
        proposer=_scripted_llm([]),  # never called
        tracer=tracer,
        now_fn=lambda: clock[0],
    )
    counts = await reflector.reflect(user_id="alice", agent_id="root")

    assert counts == ObservationCounts(
        merges_applied=0, replaces_applied=0, deletes_applied=0, rejected=0
    )
    assert len(tracer.events) == 1
    event = tracer.events[0]
    assert isinstance(event, MemoryReflected)
    assert event.proposals_generated == 0
    assert event.proposals_accepted == 0
    assert event.merges_applied == 0
    assert event.error is False
    assert event.user_id == "alice"


async def test_reflect_proposer_returns_empty_edits(tmp_db_path: Path) -> None:
    clock = [1_700_000_000]
    store = SqliteObservationStore(tmp_db_path, now_fn=lambda: clock[0])
    await store.insert_batch([_obs("alice", "root", "alice likes coffee", priority="high")])
    tracer = _CaptureTracer()

    reflector = Reflector(
        store=store,
        proposer=_scripted_llm([json.dumps({"edits": []})]),
        tracer=tracer,
        now_fn=lambda: clock[0],
    )
    counts = await reflector.reflect(user_id="alice", agent_id="root")

    assert counts == ObservationCounts(0, 0, 0, 0)
    # Original row still active.
    rows = await store.list_active("alice", "root")
    assert [r.text for r in rows] == ["alice likes coffee"]
    assert len(tracer.events) == 1
    assert tracer.events[0].error is False


async def test_reflect_merge_archives_sources(tmp_db_path: Path) -> None:
    clock = [1_700_000_000]
    store = SqliteObservationStore(tmp_db_path, now_fn=lambda: clock[0])
    await store.insert_batch(
        [
            _obs("alice", "root", "alice likes coffee", priority="high"),
            _obs("alice", "root", "alice drinks coffee daily", priority="medium"),
        ]
    )
    rows = await store.list_active("alice", "root")
    ids = sorted(r.id for r in rows)

    proposer_reply = json.dumps(
        {
            "edits": [
                {
                    "verb": "merge",
                    "source_ids": ids,
                    "text": "alice drinks coffee daily and likes it",
                }
            ]
        }
    )
    tracer = _CaptureTracer()
    reflector = Reflector(
        store=store,
        proposer=_scripted_llm([proposer_reply]),
        tracer=tracer,
        now_fn=lambda: clock[0],
    )
    counts = await reflector.reflect(user_id="alice", agent_id="root")

    assert counts.merges_applied == 1
    active = await store.list_active("alice", "root")
    assert [r.text for r in active] == ["alice drinks coffee daily and likes it"]
    # Priority preserved at the highest source level (high).
    assert active[0].priority == "high"

    assert len(tracer.events) == 1
    event = tracer.events[0]
    assert isinstance(event, MemoryReflected)
    assert event.merges_applied == 1
    assert event.proposals_generated == 1
    assert event.proposals_accepted == 1


async def test_reflect_delete_archives_source(tmp_db_path: Path) -> None:
    clock = [1_700_000_000]
    store = SqliteObservationStore(tmp_db_path, now_fn=lambda: clock[0])
    await store.insert_batch(
        [
            _obs("alice", "root", "transient context", priority="low"),
            _obs("alice", "root", "stable preference", priority="high"),
        ]
    )
    rows = await store.list_active("alice", "root")
    transient_id = next(r.id for r in rows if r.text == "transient context")

    proposer_reply = json.dumps({"edits": [{"verb": "delete", "source_id": transient_id}]})
    tracer = _CaptureTracer()
    reflector = Reflector(
        store=store,
        proposer=_scripted_llm([proposer_reply]),
        tracer=tracer,
        now_fn=lambda: clock[0],
    )
    counts = await reflector.reflect(user_id="alice", agent_id="root")

    assert counts.deletes_applied == 1
    active = await store.list_active("alice", "root")
    assert [r.text for r in active] == ["stable preference"]


async def test_reflect_drops_hallucinated_ids(tmp_db_path: Path) -> None:
    clock = [1_700_000_000]
    store = SqliteObservationStore(tmp_db_path, now_fn=lambda: clock[0])
    await store.insert_batch([_obs("alice", "root", "real fact", priority="medium")])

    # Proposer references id 99 — not in list_active.
    proposer_reply = json.dumps({"edits": [{"verb": "delete", "source_id": 99}]})
    tracer = _CaptureTracer()
    reflector = Reflector(
        store=store,
        proposer=_scripted_llm([proposer_reply]),
        tracer=tracer,
        now_fn=lambda: clock[0],
    )
    counts = await reflector.reflect(user_id="alice", agent_id="root")

    assert counts == ObservationCounts(0, 0, 0, 0)
    active = await store.list_active("alice", "root")
    assert [r.text for r in active] == ["real fact"]
    event = tracer.events[0]
    assert event.proposals_generated == 0
    assert event.proposals_accepted == 0


# ---------------------------------------------------------------------------
# Optional 3-phase pipeline
# ---------------------------------------------------------------------------


async def test_reflect_three_phase_judge_rejects(tmp_db_path: Path) -> None:
    clock = [1_700_000_000]
    store = SqliteObservationStore(tmp_db_path, now_fn=lambda: clock[0])
    await store.insert_batch(
        [
            _obs("alice", "root", "alice likes coffee"),
            _obs("alice", "root", "alice likes espresso"),
        ]
    )
    rows = await store.list_active("alice", "root")
    ids = sorted(r.id for r in rows)

    proposer_reply = json.dumps(
        {"edits": [{"verb": "merge", "source_ids": ids, "text": "alice likes coffee/espresso"}]}
    )
    judge_reply = json.dumps({"verdicts": [{"index": 0, "accept": False}]})
    tracer = _CaptureTracer()
    reflector = Reflector(
        store=store,
        proposer=_scripted_llm([proposer_reply]),
        adversary=_scripted_llm(["worried about info loss"]),
        judge=_scripted_llm([judge_reply]),
        tracer=tracer,
        now_fn=lambda: clock[0],
    )
    counts = await reflector.reflect(user_id="alice", agent_id="root")

    assert counts == ObservationCounts(0, 0, 0, 0)
    active = await store.list_active("alice", "root")
    assert {r.text for r in active} == {"alice likes coffee", "alice likes espresso"}

    event = tracer.events[0]
    assert event.proposals_generated == 1
    assert event.proposals_accepted == 0


async def test_reflect_three_phase_judge_accepts(tmp_db_path: Path) -> None:
    clock = [1_700_000_000]
    store = SqliteObservationStore(tmp_db_path, now_fn=lambda: clock[0])
    await store.insert_batch(
        [
            _obs("alice", "root", "alice likes coffee", priority="medium"),
            _obs("alice", "root", "alice likes espresso", priority="medium"),
        ]
    )
    rows = await store.list_active("alice", "root")
    ids = sorted(r.id for r in rows)

    proposer_reply = json.dumps(
        {"edits": [{"verb": "merge", "source_ids": ids, "text": "alice likes coffee+espresso"}]}
    )
    judge_reply = json.dumps({"verdicts": [{"index": 0, "accept": True}]})
    tracer = _CaptureTracer()
    reflector = Reflector(
        store=store,
        proposer=_scripted_llm([proposer_reply]),
        adversary=_scripted_llm(["fine"]),
        judge=_scripted_llm([judge_reply]),
        tracer=tracer,
        now_fn=lambda: clock[0],
    )
    counts = await reflector.reflect(user_id="alice", agent_id="root")

    assert counts.merges_applied == 1
    active = await store.list_active("alice", "root")
    assert [r.text for r in active] == ["alice likes coffee+espresso"]
    event = tracer.events[0]
    assert event.proposals_generated == 1
    assert event.proposals_accepted == 1


# ---------------------------------------------------------------------------
# Error path
# ---------------------------------------------------------------------------


async def test_reflect_proposer_raises_emits_error_event(tmp_db_path: Path) -> None:
    clock = [1_700_000_000]
    store = SqliteObservationStore(tmp_db_path, now_fn=lambda: clock[0])
    await store.insert_batch([_obs("alice", "root", "untouched", priority="high")])
    tracer = _CaptureTracer()

    async def boom(_prompt: str) -> str:
        raise RuntimeError("LLM down")

    reflector = Reflector(
        store=store,
        proposer=boom,
        tracer=tracer,
        now_fn=lambda: clock[0],
    )
    counts = await reflector.reflect(user_id="alice", agent_id="root")

    assert counts == ObservationCounts(0, 0, 0, 0)
    active = await store.list_active("alice", "root")
    assert [r.text for r in active] == ["untouched"]
    assert len(tracer.events) == 1
    event = tracer.events[0]
    assert event.error is True


async def test_tracer_failure_does_not_crash_reflector(tmp_db_path: Path) -> None:
    clock = [1_700_000_000]
    store = SqliteObservationStore(tmp_db_path, now_fn=lambda: clock[0])

    class _BadTracer:
        def on_event(self, _event: Any) -> None:
            raise RuntimeError("tracer down")

    reflector = Reflector(
        store=store,
        proposer=_scripted_llm([]),
        tracer=_BadTracer(),
        now_fn=lambda: clock[0],
    )
    # No observations -> proposer never called -> tracer raises in _emit ->
    # caller still gets the counts back.
    counts = await reflector.reflect(user_id="alice", agent_id="root")
    assert counts == ObservationCounts(0, 0, 0, 0)


# ---------------------------------------------------------------------------
# Verb extraction sanity check
# ---------------------------------------------------------------------------


def test_verbs_importable_from_edits_module() -> None:
    """The shared verb tagged-union lives in `_edits.py`."""
    # If these imports break, the verb extraction in Unit 6 was incomplete.
    assert Merge.__module__ == "zeno.memory._edits"
    assert Replace.__module__ == "zeno.memory._edits"
    assert Delete.__module__ == "zeno.memory._edits"
