"""`MemoryConsolidator` — daily 3-phase rewrite of a user's memory tier.

Pipeline:

    proposer  → list[Merge | Replace | Delete]   (compute only)
    adversary → free-form challenge text         (compute only)
    judge     → list[Verdict]                    (compute only)
    apply     → store.apply_consolidation(...)   (one tx, archives + inserts + audit)

Every phase is a plain async ``Callable[[str], Awaitable[str]]`` so the
consolidator is provider-agnostic — tests stub three callables, production
wires three thin adapters around the configured `Provider`.

Concurrency invariants:

  - Only ``store.apply_consolidation`` mutates the database. Proposer,
    adversary, and judge are pure compute; if any phase fails, no rows
    move. The judge's verdicts are filtered to the accepted subset before
    the apply call, so a judge that returns nothing yields a no-op apply
    that still writes an audit row.
  - The candidate batch is bounded (``batch_size``, default 50). A user
    with thousands of facts gets one batch per run; subsequent runs visit
    the next slice ordered by ``last_accessed_at DESC``.
  - On any unhandled error in proposer/adversary/judge, we still write
    the audit row with ``error`` set so operators can see the failure
    without grepping logs.

The consolidator never directly archives or hard-deletes rows — it only
emits structured edits that the store materialises atomically. ``Delete``
is a soft-delete: the source row is archived and may be hard-deleted later
by ``MemoryMaintenance`` when ``prune_after_seconds`` elapses.
"""

from __future__ import annotations

import json
import logging
import time
import uuid
import warnings
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from zeno.memory._edits import (
    Delete,
    Edit,
    Merge,
    Replace,
    _dedupe_edits,
    _edit_to_dict,
    _parse_edits,
    _parse_top_level_object,
    _split_edits,
)
from zeno.memory.protocols import MemoryTier
from zeno.observability.events import MemoryConsolidated

if TYPE_CHECKING:
    from zeno.memory.sqlite.user_memory_store import SqliteUserMemoryStore

logger = logging.getLogger("zeno.memory.consolidation")

LLMCallable = Callable[[str], Awaitable[str]]
"""Provider-agnostic LLM seam (mirrors `extractor.LLMCallable`).

Takes a rendered prompt and returns the model's reply text. Each phase of
the consolidator owns its own callable so callers can route them to
different model tiers — e.g. a smaller model for the proposer and a
sharper one for the judge.
"""


# ---------------------------------------------------------------------------
# Edit verbs are now shared with the L4 Reflector (`zeno.memory._edits`)
# and re-exported here for one release so existing imports don't break.
# ---------------------------------------------------------------------------


__all__ = [
    "ConsolidationCandidate",
    "ConsolidationCounts",
    "ConsolidationRunInput",
    "Delete",
    "Edit",
    "LLMCallable",
    "MemoryConsolidator",
    "Merge",
    "Replace",
]


# ---------------------------------------------------------------------------
# Store I/O dataclasses — what the consolidator hands to the store.
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class ConsolidationCandidate:
    """One active row visible to the proposer for the current run."""

    id: int
    text: str
    hit_count: int


@dataclass(frozen=True, slots=True)
class ConsolidationRunInput:
    """Everything the store needs to apply a run atomically.

    The store writes the audit row from these fields in the same
    transaction as the edits, so a partial apply is impossible: either
    the audit row + all archives + all inserts commit together, or
    nothing does.
    """

    run_id: str
    user_id: str
    started_at: int
    proposals_generated: int
    proposals_accepted: int
    merges: tuple[Merge, ...]
    replaces: tuple[Replace, ...]
    deletes: tuple[Delete, ...]
    proposals_json: str | None
    verdicts_json: str | None
    error: str | None


@dataclass(frozen=True, slots=True)
class ConsolidationCounts:
    """Counts of edits the store actually mutated.

    These can be lower than the input list lengths — e.g. a ``Replace``
    whose source was archived between proposer and apply is silently
    skipped at the store level.
    """

    merges_applied: int
    replaces_applied: int
    deletes_applied: int


# ---------------------------------------------------------------------------
# Prompts — kept as module-level constants so callers can override per-run.
# ---------------------------------------------------------------------------

DEFAULT_PROPOSER_PROMPT = """\
You are reviewing a user's stored memory facts and proposing edits that improve
recall quality. Output a JSON object with a single ``edits`` key holding a
JSON array of edit objects -- nothing else.

Each edit object MUST be one of:
  {{"verb": "merge", "source_ids": [<int>, <int>, ...], "text": "<combined fact>"}}
  {{"verb": "replace", "source_id": <int>, "text": "<rewritten fact>"}}
  {{"verb": "delete", "source_id": <int>}}

Rules:
- Only reference ids that appear in the candidates below.
- Prefer ``merge`` for facts that say the same thing in different words.
- Prefer ``replace`` when one fact is strictly more precise than another it absorbs.
- Use ``delete`` for redundant or trivially false facts.
- Each id may appear in at most ONE edit. If you cannot decide, leave it alone.
- If nothing should change, return ``{{"edits": []}}``.

CANDIDATES:
{candidates}

JSON object:"""

DEFAULT_ADVERSARY_PROMPT = """\
You are auditing proposed edits to a user's memory store. Identify edits that
would lose information, alter user-stated facts, or misuse the merge/replace/delete
verbs. Reply with a short prose critique -- no JSON. The next reviewer will read
your critique alongside the proposals.

CANDIDATES:
{candidates}

PROPOSED EDITS:
{proposals_json}

Critique:"""

DEFAULT_JUDGE_PROMPT = """\
You are the final reviewer for a memory-consolidation run. Given the candidate
facts, the proposer's edits, and the adversary's critique, decide which edits
to accept. Output a JSON object with a single ``verdicts`` key holding a JSON
array of verdict objects -- nothing else.

Each verdict object MUST be:
  {{"index": <int>, "accept": <bool>}}

Where ``index`` is the 0-based position of the edit in the proposer's array.
Omit verdicts you cannot decide on; an omitted verdict is treated as REJECT.

CANDIDATES:
{candidates}

PROPOSED EDITS:
{proposals_json}

ADVERSARY CRITIQUE:
{adversary_critique}

JSON object:"""


# ---------------------------------------------------------------------------
# MemoryConsolidator — orchestrates one user's run.
# ---------------------------------------------------------------------------


class MemoryConsolidator:
    """Daily 3-phase rewrite for a single user's memory tier.

    Construction is cheap; reuse one instance across users and ticks. The
    consolidator does not own a loop — schedule ``consolidate_user`` from
    ``MemoryMaintenance`` or an external cron-style trigger.
    """

    def __init__(
        self,
        *,
        store: SqliteUserMemoryStore,
        proposer: LLMCallable,
        adversary: LLMCallable,
        judge: LLMCallable,
        tracer: Any = None,
        batch_size: int = 50,
        tier: MemoryTier = "long",
        proposer_prompt: str = DEFAULT_PROPOSER_PROMPT,
        adversary_prompt: str = DEFAULT_ADVERSARY_PROMPT,
        judge_prompt: str = DEFAULT_JUDGE_PROMPT,
        now_fn: Callable[[], int] | None = None,
    ) -> None:
        if batch_size < 1:
            raise ValueError(f"batch_size must be >= 1; got {batch_size}")
        warnings.warn(
            "MemoryConsolidator is deprecated; use ObservationalMemory in "
            "ZenoApp(observational_memory=...) instead. This class will be "
            "removed in the next minor release. See MIGRATION.md.",
            DeprecationWarning,
            stacklevel=2,
        )
        self._store = store
        self._proposer = proposer
        self._adversary = adversary
        self._judge = judge
        self._tracer = tracer
        self._batch_size = batch_size
        self._tier: MemoryTier = tier
        self._proposer_prompt = proposer_prompt
        self._adversary_prompt = adversary_prompt
        self._judge_prompt = judge_prompt
        self._now_fn: Callable[[], int] = now_fn or (lambda: int(time.time()))

    async def consolidate_user(self, user_id: str) -> ConsolidationCounts:
        """Run one consolidation pass for *user_id*. Returns mutation counts.

        Always writes a ``consolidation_runs`` audit row, even on no-op
        (empty batch / judge accepted nothing) and on error. Counts on
        the returned tuple match the audit row.
        """
        run_id = uuid.uuid4().hex[:12]
        started = time.monotonic()
        started_at = self._now_fn()

        proposals: list[Edit] = []
        accepted: list[Edit] = []
        proposals_json: str | None = None
        verdicts_json: str | None = None
        error_text: str | None = None

        try:
            candidates = await self._store.list_for_consolidation(
                user_id, tier=self._tier, limit=self._batch_size
            )
            if candidates:
                proposals, proposals_json = await self._propose(candidates)
                if proposals:
                    accepted, verdicts_json = await self._adjudicate(candidates, proposals)
        except Exception as exc:  # noqa: BLE001
            error_text = f"{type(exc).__name__}: {exc}"
            logger.exception("consolidation pre-apply failed user_id=%s run_id=%s", user_id, run_id)

        merges, replaces, deletes = _split_edits(accepted)
        run_input = ConsolidationRunInput(
            run_id=run_id,
            user_id=user_id,
            started_at=started_at,
            proposals_generated=len(proposals),
            proposals_accepted=len(accepted),
            merges=merges,
            replaces=replaces,
            deletes=deletes,
            proposals_json=proposals_json,
            verdicts_json=verdicts_json,
            error=error_text,
        )

        try:
            counts = await self._store.apply_consolidation(run_input)
        except Exception:  # noqa: BLE001
            # Apply failed: nothing committed (the store wraps in a single
            # tx). We still report the run so the caller can observe the
            # failure; surface zero-applied counts.
            logger.exception("consolidation apply failed user_id=%s run_id=%s", user_id, run_id)
            counts = ConsolidationCounts(0, 0, 0)
            error_text = error_text or "apply_failed"

        event = MemoryConsolidated(
            run_id=run_id,
            proposals_generated=len(proposals),
            proposals_accepted=len(accepted),
            merges_applied=counts.merges_applied,
            replaces_applied=counts.replaces_applied,
            deletes_applied=counts.deletes_applied,
            duration_ms=int((time.monotonic() - started) * 1000),
        )
        self._emit(event)
        return counts

    # ------------------------------------------------------------------
    # Phases
    # ------------------------------------------------------------------

    async def _propose(
        self, candidates: list[ConsolidationCandidate]
    ) -> tuple[list[Edit], str | None]:
        prompt = self._proposer_prompt.format(candidates=_render_candidates(candidates))
        reply = await self._proposer(prompt)
        valid_ids = {c.id for c in candidates}
        edits = _parse_edits(reply, valid_ids=valid_ids)
        if not edits:
            return [], None
        proposals_json = json.dumps([_edit_to_dict(e) for e in edits])
        return edits, proposals_json

    async def _adjudicate(
        self,
        candidates: list[ConsolidationCandidate],
        proposals: list[Edit],
    ) -> tuple[list[Edit], str | None]:
        proposals_json = json.dumps([_edit_to_dict(e) for e in proposals])
        adversary_prompt = self._adversary_prompt.format(
            candidates=_render_candidates(candidates),
            proposals_json=proposals_json,
        )
        critique = await self._adversary(adversary_prompt)
        judge_prompt = self._judge_prompt.format(
            candidates=_render_candidates(candidates),
            proposals_json=proposals_json,
            adversary_critique=critique.strip() or "(no critique)",
        )
        judge_reply = await self._judge(judge_prompt)
        accepted_indices = _parse_verdicts(judge_reply, max_index=len(proposals))
        if not accepted_indices:
            return [], judge_reply
        accepted = [proposals[i] for i in accepted_indices]
        accepted = _dedupe_edits(accepted)
        return accepted, judge_reply

    def _emit(self, event: Any) -> None:
        if self._tracer is None:
            return
        try:
            self._tracer.on_event(event)
        except Exception:  # noqa: BLE001
            logger.exception("tracer.on_event raised; consolidation continues")


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------


def _render_candidates(candidates: list[ConsolidationCandidate]) -> str:
    """Format candidates for inclusion in a phase prompt.

    One row per fact with id, text, and hit count so the proposer has the
    bookkeeping context (a fact recalled often is more important to
    preserve verbatim than one never read).
    """
    lines = [f"  id={c.id} hits={c.hit_count} text={json.dumps(c.text)}" for c in candidates]
    return "\n".join(lines) if lines else "  (none)"


def _parse_verdicts(reply: str, *, max_index: int) -> list[int]:
    """Parse the judge's verdicts into the list of accepted edit indices."""
    parsed = _parse_top_level_object(reply)
    if parsed is None:
        return []
    raw = parsed.get("verdicts")
    if not isinstance(raw, list):
        return []
    accepted: list[int] = []
    seen: set[int] = set()
    for item in raw:
        if not isinstance(item, dict):
            continue
        idx = item.get("index")
        accept = item.get("accept")
        if isinstance(idx, bool) or not isinstance(idx, int):
            continue
        if not isinstance(accept, bool):
            continue
        if not accept:
            continue
        if idx < 0 or idx >= max_index or idx in seen:
            continue
        seen.add(idx)
        accepted.append(idx)
    return accepted
