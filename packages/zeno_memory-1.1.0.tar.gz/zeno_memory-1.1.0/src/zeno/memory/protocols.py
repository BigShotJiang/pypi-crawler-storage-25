"""Store-side protocols — the contracts concrete backends implement (R20, R21, R22, R26, R7, R8).

These protocols describe the **raw** stores, keyed by `user_id` everywhere.
They are what adapters like `SqliteSessionStore`, `ChromaKnowledgeStore`,
`VectorBackedUserMemoryStore`, and `SqliteConversationStore` implement.

Distinct from `MemoryViewProtocol` in `zeno-core`, which is the
context-bound *consumer* surface the turn worker hands to tools — the
views hide `user_id` after the turn worker has bound them.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Iterable, Sequence
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Literal, Protocol, runtime_checkable

from zeno.memory._edits import Edit

SessionIdFactory = Callable[[], Awaitable[str]] | Callable[[], str]
"""Factory for minting a fresh SDK session id.

The session store calls the factory only when no record exists for the
``(user_id, channel, thread_key)`` key. Sync and async factories are both
supported so adapters can plug in cheap UUID generators or async HTTP
calls without forcing a wrapper. Stores must `await` the result if the
return type is awaitable.
"""


@dataclass(frozen=True, slots=True)
class SessionRecord:
    """A per-`(user_id, channel, thread_key)` session mapping."""

    user_id: str
    channel: str
    thread_key: str | None
    sdk_session_id: str
    created_at: int
    updated_at: int
    last_summary: str | None = None


@dataclass(frozen=True, slots=True)
class MemoryHit:
    """A single search hit from a memory or knowledge store."""

    text: str
    score: float
    meta: dict[str, Any]


@runtime_checkable
class SessionStore(Protocol):
    """Maps `(user_id, channel, thread_key) → sdk_session_id`.

    The session record survives process restarts so we can resume SDK
    sessions via `ClaudeAgentOptions(resume=...)`. Losing the record is
    acceptable — we mint a fresh SDK session and lose chat history; user
    memory and knowledge remain intact.
    """

    async def get(
        self, user_id: str, channel: str, thread_key: str | None
    ) -> SessionRecord | None: ...

    async def get_or_create(
        self,
        user_id: str,
        channel: str,
        thread_key: str | None,
        sdk_session_id_factory: SessionIdFactory,
    ) -> SessionRecord: ...

    async def touch(self, record: SessionRecord, summary: str | None = None) -> None:
        """Update `updated_at` and optionally `last_summary` on the record."""


MemoryTier = Literal["short", "long", "permanent"]
"""Lifecycle tier for a user-memory row.

- ``short``  — newly extracted facts; decayed to ``long`` after enough hits or archived.
- ``long``   — promoted or explicitly remembered facts; the default for ``remember(...)``.
- ``permanent`` — terminal tier; never decayed by the maintenance loop.
"""


@runtime_checkable
class UserMemoryStore(Protocol):
    """Per-user fact store (R20). Strictly scoped by `user_id`."""

    async def search(self, user_id: str, query: str, k: int = 5) -> list[MemoryHit]: ...

    async def add(
        self,
        user_id: str,
        text: str,
        meta: dict[str, Any] | None = None,
        *,
        tier: MemoryTier = "long",
    ) -> None: ...


@runtime_checkable
class KnowledgeStore(Protocol):
    """Shared knowledge base, multi-tenant by `user_id` (R21, R26).

    Adapters MUST filter every search by `user_id`. Writes MUST tag every
    inserted row with the inserting user's id so multi-tenant isolation
    holds across restarts.
    """

    async def search(self, user_id: str, query: str, k: int = 5) -> list[MemoryHit]: ...

    async def add(
        self,
        user_id: str,
        text: str,
        meta: dict[str, Any] | None = None,
    ) -> None: ...


@dataclass(frozen=True, slots=True)
class ConversationMessage:
    """One entry in an ordered per-`(user_id, thread_key)` conversation log (R7).

    The shape is deliberately OpenAI Chat-Completions-shaped so providers
    can serialise directly without a translation layer, while still
    covering the common Chat Completions tool-call dance:

    ``role``
        Speaker. Four-state literal; Chat Completions uses the same set.
    ``content``
        Natural-language text. ``None`` is valid for assistant turns that
        only produce tool calls, and for tool results that are structured.
    ``tool_calls``
        Raw OpenAI Chat Completions ``tool_calls`` list; only set on
        assistant turns requesting tool invocations.
    ``tool_call_id``
        The id the assistant asked us to respond to; only set on ``tool``
        role rows.
    ``created_at``
        Insertion time. Persisted as ISO-8601 in SQLite; providers use it
        for pruning and observability.
    """

    role: Literal["user", "assistant", "tool", "system"]
    content: str | None
    tool_calls: list[dict[str, Any]] | None
    tool_call_id: str | None
    created_at: datetime


@runtime_checkable
class ConversationStore(Protocol):
    """Ordered per-`(user_id, thread_key)` message log for non-Claude providers (R7, R8).

    ``ClaudeSDKProvider`` ignores this surface entirely — the Agent SDK
    owns session state. Every other provider (OpenAI-compat, Ollama, etc.)
    loads the current history at turn start, streams the new user + tool +
    assistant exchanges, and appends them before returning.

    Read failures MUST NOT crash a turn: adapters log and return ``[]`` so
    the turn continues with only the current message (KD12). Write failures
    MUST raise so the turn worker's ``on_turn_error`` runs and the operator
    sees the persistence bug loudly.
    """

    async def load(self, *, user_id: str, thread_key: str | None) -> list[ConversationMessage]: ...

    async def load_since(
        self,
        *,
        user_id: str,
        thread_key: str | None,
        after_sequence: int,
    ) -> list[tuple[int, ConversationMessage]]:
        """Return messages strictly after `after_sequence` paired with their sequence.

        Used by the L4 Observer to pull only the rounds it has not yet
        processed. Returned in `sequence` order, ascending. A
        `after_sequence < 0` MUST behave as "from the start".
        """
        ...

    async def append(
        self,
        *,
        user_id: str,
        thread_key: str | None,
        messages: Sequence[ConversationMessage],
    ) -> None: ...

    async def clear(self, *, user_id: str, thread_key: str | None) -> None: ...


@dataclass(frozen=True, slots=True)
class WorkingMemoryRecord:
    """One field of an agent's per-`(user_id, agent_id)` working-memory card.

    Working memory is a typed key-value scratchpad pinned to the system
    prompt — distinct from `UserMemoryStore` (free-form similarity search)
    and `SessionStore` (per-thread session resume metadata). Each row
    carries its own `last_updated` so the rendered prompt block can show a
    per-field freshness cue.
    """

    user_id: str
    agent_id: str
    field_name: str
    value: str
    last_updated: int


@runtime_checkable
class WorkingMemoryStore(Protocol):
    """Per-`(user_id, agent_id)` typed key-value memory.

    Concurrency posture: last-write-wins. Two coroutines updating the same
    `(user_id, agent_id, field_name)` triple in parallel each commit
    independently; the later write overwrites the earlier on overlapping
    fields. Implementations SHOULD serialise writes within one process via
    a per-store `asyncio.Lock` and rely on SQLite's `busy_timeout` (or the
    backend's equivalent) for cross-process safety.

    Empty-string values in a `patch` MUST be interpreted as "clear this
    field" (R7); the store is the authority on that semantic so callers can
    forward patches verbatim.
    """

    async def get(self, user_id: str, agent_id: str) -> dict[str, WorkingMemoryRecord]: ...

    async def update(self, user_id: str, agent_id: str, patch: dict[str, str]) -> None: ...

    async def clear(self, user_id: str, agent_id: str) -> None: ...


ObservationPriority = Literal["high", "medium", "low"]
"""Salience marker for an observation row.

Rendered as a leading 🔴/🟡/🟢 emoji (or `[high]`/`[med]`/`[low]` token in
`tokens` mode) at the top of the prompt observation block. The Observer
chooses the level when extracting; the Reflector preserves it on
`Merge`/`Replace`.
"""


@dataclass(frozen=True, slots=True)
class Observation:
    """One row in the per-`(user_id, agent_id)` observation log (R2, R13).

    Two date columns by design (LongMemEval § 5.1):

    - ``observation_date`` — when the Observer wrote this row. Always set.
    - ``referenced_date`` — the date the observed event happened. Often
      the same as ``observation_date`` for "user just said …" facts;
      distinct when a turn references the past ("last Friday I …").

    ``source_round_ids`` records which conversation rounds produced the
    observation so the Reflector can keep a coarse provenance trail.
    """

    id: int
    user_id: str
    agent_id: str
    text: str
    priority: ObservationPriority
    observation_date: int
    referenced_date: int | None
    source_round_ids: tuple[int, ...]
    created_at: int
    archived_at: int | None = None


@dataclass(frozen=True, slots=True)
class ObservationRunWatermark:
    """High-water mark for the Observer's per-window scan (R6).

    Keyed by `(user_id, agent_id, thread_key)`. Stores the highest
    `conversations.sequence` already processed so the next Observer run
    only sees genuinely new rounds. ``thread_key`` is nullable to match
    the conversations table.
    """

    user_id: str
    agent_id: str
    thread_key: str | None
    last_processed_sequence: int
    last_run_at: int
    last_run_status: Literal["ok", "error", "empty"]


@dataclass(frozen=True, slots=True)
class ObservationCounts:
    """Result of `ObservationStore.apply_edits` (R10).

    Mirrors `ConsolidationCounts` so dashboards reading both pipelines
    can normalise on the same shape. ``rejected`` counts edits that were
    structurally well-formed but referenced ids the store had already
    archived.
    """

    merges_applied: int
    replaces_applied: int
    deletes_applied: int
    rejected: int


@dataclass(frozen=True, slots=True)
class ObservationRunInput:
    """One Reflector run's payload to `ObservationStore.apply_edits`.

    Mirrors `ConsolidationRunInput`. ``run_id`` is a uuid the Reflector
    mints once per run so audit logs can correlate the proposer prompt,
    the parsed edits, and the resulting counts.
    """

    run_id: str
    user_id: str
    agent_id: str
    edits: tuple[Edit, ...]
    started_at: int


@runtime_checkable
class ObservationStore(Protocol):
    """Per-`(user_id, agent_id)` observation log (R1, R2, R3, R10, R11).

    The Observer writes rows; the Reflector edits them via
    `apply_edits`; the renderer reads via `list_active`. Watermarks live
    in a separate `(user_id, agent_id, thread_key)` table so a row's
    schema stays small (`source_round_ids` already carries provenance).

    Concurrency posture mirrors the rest of the SQLite stores:
    last-write-wins, per-store `asyncio.Lock` around mutating methods,
    `BEGIN IMMEDIATE` for write transactions, SQLite `busy_timeout` for
    cross-process safety. Read paths (`list_active`, `read_watermark`)
    do not hold the lock.
    """

    async def insert_batch(self, observations: Iterable[Observation]) -> None: ...

    async def list_active(self, user_id: str, agent_id: str) -> list[Observation]: ...

    async def apply_edits(self, run_input: ObservationRunInput) -> ObservationCounts: ...

    async def read_watermark(
        self, user_id: str, agent_id: str, thread_key: str | None
    ) -> ObservationRunWatermark | None: ...

    async def advance_watermark(
        self,
        *,
        user_id: str,
        agent_id: str,
        thread_key: str | None,
        last_processed_sequence: int,
        last_run_status: Literal["ok", "error", "empty"],
    ) -> None: ...


@runtime_checkable
class VectorStore(Protocol):
    """Low-level vector interface — optional backend contract.

    Most users go through `KnowledgeStore`. `VectorStore` exists so
    adapters can reuse a common embedding + search plumbing across
    stores without duplicating logic.
    """

    async def upsert(
        self,
        namespace: str,
        id: str,
        vector: list[float],
        meta: dict[str, Any],
    ) -> None: ...

    async def query(
        self,
        namespace: str,
        vector: list[float],
        k: int,
        filter: dict[str, Any] | None = None,
    ) -> list[MemoryHit]: ...
