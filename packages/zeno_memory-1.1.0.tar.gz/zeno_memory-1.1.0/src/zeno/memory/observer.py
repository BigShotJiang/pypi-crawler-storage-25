"""`Observer` — condenses unprocessed conversation rounds into observations (R4–R8).

Wired into the L4 `ObservationalMemory` orchestrator, which fires
`observe_for_window` from a fire-and-forget background coroutine when
the conversation log crosses the Observer threshold. The Observer is
provider-agnostic: the LLM seam is a plain async callable so tests stub
an in-memory function and production wires a thin adapter around the
configured `Provider`.

Concurrency / failure posture:

- The Observer is single-flight per ``(user_id, agent_id, thread_key)``
  window; the orchestrator owns the lock so two simultaneous threshold
  crossings cannot double-spend the same window.
- On any error (LLM raise, parse failure, store insert failure) the
  Observer logs, emits ``MemoryObserved(error=True)``, and *leaves the
  watermark unchanged* so the next threshold crossing retries the same
  window (R8).
- On success, the batch insert and watermark advance happen in the same
  coroutine; the store's per-store ``asyncio.Lock`` serialises the two
  writes against any concurrent ``apply_edits`` from the Reflector.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import re
import time
import uuid
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING, Any, get_args

from zeno.memory.protocols import Observation, ObservationPriority
from zeno.observability.events import MemoryObserved

if TYPE_CHECKING:
    from zeno.context import Ctx
    from zeno.memory.protocols import ConversationMessage, ConversationStore, ObservationStore

logger = logging.getLogger("zeno.memory.observer")

LLMCallable = Callable[[str], Awaitable[str]]
"""Provider-agnostic LLM seam (mirrors `extractor.LLMCallable`)."""

_VALID_PRIORITIES: frozenset[str] = frozenset(get_args(ObservationPriority))


DEFAULT_PROMPT = """\
You are condensing a chat history into durable observations a future
assistant turn can recall. Output a JSON array of objects -- nothing else.

Each object MUST be:
  {{"text": "<observation>", "priority": "high"|"medium"|"low",
    "referenced_date": <unix_ts_sec> | null, "source_round_ids": [<int>, ...]}}

Rules:
- One observation per noteworthy fact about the user, their goals, or
  decisions made in the conversation.
- Use ``high`` for stable preferences, identifiers, and decisions; use
  ``medium`` for context that may matter on a future turn; use ``low``
  for short-lived context.
- Set ``referenced_date`` to a Unix timestamp (seconds) only when the
  round explicitly refers to a date in the past or future; otherwise
  null.
- ``source_round_ids`` MUST list the sequence ids of the rounds this
  observation came from.
- Output at most {max_observations} observations. An empty array is OK.

ROUNDS:
{rounds}

JSON array:"""


_TRUNCATED_SUFFIX = "... (truncated)"


class Observer:
    """Reads unprocessed conversation rounds and writes a batch of observations.

    Construction is cheap; reuse one instance across windows. The
    Observer does not own its loop or scheduling — the
    `ObservationalMemory` orchestrator drives it.
    """

    def __init__(
        self,
        *,
        store: ObservationStore,
        conversations: ConversationStore,
        llm: LLMCallable,
        prompt_template: str = DEFAULT_PROMPT,
        tool_truncate_chars: int = 2000,
        max_observations_per_run: int = 50,
        now_fn: Callable[[], int] | None = None,
    ) -> None:
        if tool_truncate_chars < 1:
            raise ValueError(f"tool_truncate_chars must be >= 1; got {tool_truncate_chars}")
        if max_observations_per_run < 1:
            raise ValueError(
                f"max_observations_per_run must be >= 1; got {max_observations_per_run}"
            )
        self._store = store
        self._conversations = conversations
        self._llm = llm
        self._prompt_template = prompt_template
        self._tool_truncate_chars = tool_truncate_chars
        self._max_observations_per_run = max_observations_per_run
        self._now_fn: Callable[[], int] = now_fn or (lambda: int(time.time()))

    async def observe_for_window(
        self,
        ctx: Ctx,
        *,
        agent_id: str,
        thread_key: str | None,
    ) -> None:
        """Run one Observer pass for the `(ctx.user_id, agent_id, thread_key)` window.

        Reads the watermark, loads unprocessed rounds since it, calls
        the LLM, parses observations, inserts the batch, and advances
        the watermark. Always emits ``MemoryObserved`` with the run's
        outcome.
        """
        run_id = uuid.uuid4().hex[:12]
        started = time.monotonic()
        rounds_seen = 0
        observations_written = 0
        error = False

        try:
            watermark = await self._store.read_watermark(
                user_id=ctx.user_id, agent_id=agent_id, thread_key=thread_key
            )
            after_sequence = watermark.last_processed_sequence if watermark is not None else -1

            rounds = await self._conversations.load_since(
                user_id=ctx.user_id, thread_key=thread_key, after_sequence=after_sequence
            )
            rounds_seen = len(rounds)
            if not rounds:
                # Nothing new — skip the LLM call entirely. We do not
                # advance the watermark either; the orchestrator should
                # not have called us with an empty window anyway. The
                # `finally` block emits the event.
                return

            prompt = self._prompt_template.format(
                max_observations=self._max_observations_per_run,
                rounds=self._render_rounds(rounds),
            )
            reply = await self._llm(prompt)
            parsed = _parse_observations(
                reply,
                max_observations=self._max_observations_per_run,
                valid_round_ids={seq for seq, _ in rounds},
            )

            if parsed:
                now = self._now_fn()
                obs_batch = [
                    Observation(
                        id=0,  # Assigned by the store on insert.
                        user_id=ctx.user_id,
                        agent_id=agent_id,
                        text=item["text"],
                        priority=item["priority"],
                        observation_date=now,
                        referenced_date=item["referenced_date"],
                        source_round_ids=tuple(item["source_round_ids"]),
                        created_at=now,
                    )
                    for item in parsed
                ]
                await self._store.insert_batch(obs_batch)
                observations_written = len(obs_batch)

            highest_seq = rounds[-1][0]
            await self._store.advance_watermark(
                user_id=ctx.user_id,
                agent_id=agent_id,
                thread_key=thread_key,
                last_processed_sequence=highest_seq,
                last_run_status="ok" if observations_written > 0 else "empty",
            )
        except asyncio.CancelledError:
            error = True
            raise
        except Exception:  # noqa: BLE001
            error = True
            logger.exception(
                "observer run failed user_id=%s agent_id=%s thread_key=%s run_id=%s",
                ctx.user_id,
                agent_id,
                thread_key,
                run_id,
            )
        finally:
            await self._record_event(
                ctx,
                run_id=run_id,
                agent_id=agent_id,
                thread_key=thread_key,
                rounds_seen=rounds_seen,
                observations_written=observations_written,
                duration_ms=int((time.monotonic() - started) * 1000),
                error=error,
            )

    async def _record_event(
        self,
        ctx: Ctx,
        *,
        run_id: str,
        agent_id: str,
        thread_key: str | None,
        rounds_seen: int,
        observations_written: int,
        duration_ms: int,
        error: bool,
    ) -> None:
        event = MemoryObserved(
            run_id=run_id,
            user_id=ctx.user_id,
            agent_id=agent_id,
            thread_key=thread_key,
            rounds_seen=rounds_seen,
            observations_written=observations_written,
            duration_ms=duration_ms,
            error=error,
        )
        tracer = getattr(ctx, "tracer", None)
        if tracer is not None:
            with contextlib.suppress(Exception):
                tracer.on_event(event)

    def _render_rounds(self, rounds: list[tuple[int, ConversationMessage]]) -> str:
        lines: list[str] = []
        for seq, msg in rounds:
            label = self._label_for(msg)
            body = self._render_body(msg)
            lines.append(f"  [{seq}] {label}: {body}")
        return "\n".join(lines) if lines else "  (none)"

    def _label_for(self, msg: ConversationMessage) -> str:
        if msg.role == "tool":
            return "tool_result"
        if msg.role == "assistant" and msg.tool_calls:
            return "tool_call"
        return msg.role

    def _render_body(self, msg: ConversationMessage) -> str:
        if msg.role == "tool":
            content = msg.content or ""
            return self._truncate(content)
        if msg.role == "assistant" and msg.tool_calls:
            try:
                serialized = json.dumps(msg.tool_calls)
            except (TypeError, ValueError):
                serialized = str(msg.tool_calls)
            return self._truncate(serialized)
        return msg.content or ""

    def _truncate(self, text: str) -> str:
        if len(text) <= self._tool_truncate_chars:
            return text
        return text[: self._tool_truncate_chars] + _TRUNCATED_SUFFIX


_JSON_ARRAY_NONGREEDY = re.compile(r"\[.*?\]", re.DOTALL)
_JSON_ARRAY_GREEDY = re.compile(r"\[.*\]", re.DOTALL)


def _coerce_to_list(parsed: Any) -> list[Any] | None:
    if isinstance(parsed, list):
        return parsed
    if isinstance(parsed, dict):
        for value in parsed.values():
            if isinstance(value, list):
                return value
    return None


def _parse_observations(
    reply: str,
    *,
    max_observations: int,
    valid_round_ids: set[int],
) -> list[dict[str, Any]]:
    """Parse the LLM reply into a list of validated observation dicts.

    Drops items missing required fields, with invalid priority, or with
    no overlap between ``source_round_ids`` and ``valid_round_ids`` (a
    proposer that hallucinates a round id must not pin an observation
    to nothing). Returns at most ``max_observations`` items.
    """
    raw_list = _extract_array(reply)
    if raw_list is None:
        return []
    out: list[dict[str, Any]] = []
    for item in raw_list:
        if not isinstance(item, dict):
            continue
        text = item.get("text")
        priority = item.get("priority")
        if not isinstance(text, str) or not text.strip():
            continue
        if priority not in _VALID_PRIORITIES:
            continue
        referenced_date = item.get("referenced_date")
        if referenced_date is not None and (
            isinstance(referenced_date, bool) or not isinstance(referenced_date, int)
        ):
            referenced_date = None
        raw_ids = item.get("source_round_ids")
        if not isinstance(raw_ids, list):
            continue
        cleaned_ids: list[int] = []
        for raw_id in raw_ids:
            if isinstance(raw_id, bool) or not isinstance(raw_id, int):
                continue
            if raw_id in valid_round_ids:
                cleaned_ids.append(raw_id)
        if not cleaned_ids:
            continue
        out.append(
            {
                "text": text.strip(),
                "priority": priority,
                "referenced_date": referenced_date,
                "source_round_ids": cleaned_ids,
            }
        )
        if len(out) >= max_observations:
            break
    return out


def _extract_array(reply: str) -> list[Any] | None:
    stripped = reply.strip()
    if stripped:
        try:
            parsed = json.loads(stripped)
        except json.JSONDecodeError:
            pass
        else:
            coerced = _coerce_to_list(parsed)
            if coerced is not None:
                return coerced
    for match in _JSON_ARRAY_NONGREEDY.finditer(reply):
        try:
            parsed = json.loads(match.group(0))
        except json.JSONDecodeError:
            continue
        coerced = _coerce_to_list(parsed)
        if coerced is not None:
            return coerced
    greedy = _JSON_ARRAY_GREEDY.search(reply)
    if greedy is not None:
        try:
            return _coerce_to_list(json.loads(greedy.group(0)))
        except json.JSONDecodeError:
            return None
    return None


__all__ = [
    "DEFAULT_PROMPT",
    "LLMCallable",
    "Observer",
]
