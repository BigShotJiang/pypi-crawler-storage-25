"""zeno-memory — memory stores, protocols, and per-turn view handles."""

from __future__ import annotations

from zeno.memory.consolidation import (
    ConsolidationCandidate,
    ConsolidationCounts,
    ConsolidationRunInput,
    Delete,
    MemoryConsolidator,
    Merge,
    Replace,
)
from zeno.memory.extractor import LLMCallable, MemoryExtractor
from zeno.memory.handles import (
    ConversationHandle,
    KnowledgeView,
    MemoryView,
    ObservationView,
    SessionHandle,
    UserMemoryView,
    WorkingMemoryView,
)
from zeno.memory.maintenance import MemoryMaintenance
from zeno.memory.observational import ObservationalMemory
from zeno.memory.observer import Observer
from zeno.memory.protocols import (
    ConversationMessage,
    ConversationStore,
    KnowledgeStore,
    MemoryHit,
    MemoryTier,
    Observation,
    ObservationCounts,
    ObservationPriority,
    ObservationRunInput,
    ObservationRunWatermark,
    ObservationStore,
    SessionRecord,
    SessionStore,
    UserMemoryStore,
    VectorStore,
    WorkingMemoryRecord,
    WorkingMemoryStore,
)
from zeno.memory.reflector import Reflector
from zeno.memory.sqlite.observation_store import SqliteObservationStore
from zeno.memory.sqlite.user_memory_store import SqliteUserMemoryStore
from zeno.memory.sqlite.working_memory_store import SqliteWorkingMemoryStore
from zeno.memory.three_layer import ThreeLayer
from zeno.memory.vector_backed.user_memory_store import VectorBackedUserMemoryStore
from zeno.observability.events import MemoryObserved, MemoryReflected

__all__ = [
    # Handles (per-turn views)
    "ConversationHandle",
    "KnowledgeView",
    "MemoryView",
    "ObservationView",
    "SessionHandle",
    "UserMemoryView",
    "WorkingMemoryView",
    # Protocols
    "ConversationMessage",
    "ConversationStore",
    "KnowledgeStore",
    "MemoryHit",
    "MemoryTier",
    "Observation",
    "ObservationCounts",
    "ObservationPriority",
    "ObservationRunInput",
    "ObservationRunWatermark",
    "ObservationStore",
    "SessionRecord",
    "SessionStore",
    "UserMemoryStore",
    "VectorStore",
    "WorkingMemoryRecord",
    "WorkingMemoryStore",
    # Composer
    "ThreeLayer",
    # Adapters
    "SqliteObservationStore",
    "SqliteUserMemoryStore",
    "SqliteWorkingMemoryStore",
    "VectorBackedUserMemoryStore",
    # Post-turn extraction
    "LLMCallable",
    "MemoryExtractor",
    # L4 Observer + Reflector + Orchestrator
    "ObservationalMemory",
    "Observer",
    "Reflector",
    # L4 trace events (re-exported for convenience)
    "MemoryObserved",
    "MemoryReflected",
    # Maintenance
    "MemoryMaintenance",
    # Consolidation
    "ConsolidationCandidate",
    "ConsolidationCounts",
    "ConsolidationRunInput",
    "Delete",
    "MemoryConsolidator",
    "Merge",
    "Replace",
]
