"""Context-bound handles exposed on `Ctx.memory` (R25).

Bound at turn entry by the runtime; tool code sees only handles that have
already captured `user_id`. There is no way for a tool to search another
user's memory without going around the handle entirely.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Sequence

    from zeno.memory.protocols import (
        ConversationMessage,
        ConversationStore,
        KnowledgeStore,
        MemoryHit,
        MemoryTier,
        Observation,
        ObservationStore,
        SessionRecord,
        SessionStore,
        UserMemoryStore,
        WorkingMemoryRecord,
        WorkingMemoryStore,
    )


@dataclass(frozen=True, slots=True)
class UserMemoryView:
    """Per-turn view that only exposes `user_id`-free verbs."""

    _store: UserMemoryStore
    _user_id: str

    async def search(self, query: str, k: int = 5) -> list[MemoryHit]:
        return await self._store.search(self._user_id, query, k)

    async def add(
        self,
        text: str,
        meta: dict[str, Any] | None = None,
        *,
        tier: MemoryTier = "long",
    ) -> None:
        await self._store.add(self._user_id, text, meta, tier=tier)


@dataclass(frozen=True, slots=True)
class KnowledgeView:
    """Per-turn knowledge view. Multi-tenant by the bound `user_id`."""

    _store: KnowledgeStore
    _user_id: str

    async def search(self, query: str, k: int = 5) -> list[MemoryHit]:
        return await self._store.search(self._user_id, query, k)

    async def add(self, text: str, meta: dict[str, Any] | None = None) -> None:
        await self._store.add(self._user_id, text, meta)


@dataclass(frozen=True, slots=True)
class SessionHandle:
    """Session handle threaded onto `ctx.memory.session`.

    The handle's public surface only exposes methods useful within a turn.
    The turn worker itself calls the underlying `SessionStore` to resolve
    the SDK session id before the handler runs.
    """

    _store: SessionStore
    _user_id: str
    _channel: str
    _thread_key: str | None

    async def current(self) -> SessionRecord | None:
        return await self._store.get(self._user_id, self._channel, self._thread_key)

    async def update_summary(self, summary: str) -> None:
        record = await self._store.get(self._user_id, self._channel, self._thread_key)
        if record is not None:
            await self._store.touch(record, summary=summary)


@dataclass(frozen=True, slots=True)
class ConversationHandle:
    """Per-turn handle bound to `(user_id, thread_key)` (R7, R8, R11).

    Used by non-Claude providers to read and extend the ordered message log
    for the current turn's thread. The turn worker binds ``_user_id`` and
    ``_thread_key`` at ``Ctx`` construction so tools and providers never see
    another user's history through this handle.
    """

    _store: ConversationStore
    _user_id: str
    _thread_key: str | None

    async def load(self) -> list[ConversationMessage]:
        return await self._store.load(user_id=self._user_id, thread_key=self._thread_key)

    async def append(self, messages: Sequence[ConversationMessage]) -> None:
        await self._store.append(
            user_id=self._user_id, thread_key=self._thread_key, messages=messages
        )

    async def clear(self) -> None:
        await self._store.clear(user_id=self._user_id, thread_key=self._thread_key)


@dataclass(frozen=True, slots=True)
class WorkingMemoryView:
    """Per-turn handle for the agent's typed `(user_id, agent_id)` card.

    Bound at turn entry; tools see only `update` / `get` / `clear`. The
    `agent_id` is the active agent's `Agent.name` — renaming an agent
    creates a new namespace.
    """

    _store: WorkingMemoryStore
    _user_id: str
    _agent_id: str

    async def get(self) -> dict[str, WorkingMemoryRecord]:
        return await self._store.get(self._user_id, self._agent_id)

    async def update(self, patch: dict[str, str]) -> None:
        await self._store.update(self._user_id, self._agent_id, patch)

    async def clear(self) -> None:
        await self._store.clear(self._user_id, self._agent_id)


@dataclass(frozen=True, slots=True)
class ObservationView:
    """Per-turn handle for the agent's `(user_id, agent_id)` observation log.

    Read-only at the per-turn surface. The Observer and Reflector mutate
    the underlying store from background coroutines owned by the
    `ObservationalMemory` orchestrator — fire-and-forget per R7.
    """

    _store: ObservationStore
    _user_id: str
    _agent_id: str

    async def list_active(self) -> list[Observation]:
        return await self._store.list_active(self._user_id, self._agent_id)


@dataclass(frozen=True, slots=True)
class MemoryView:
    """Composite view matching `MemoryViewProtocol` in `zeno-core`."""

    user: UserMemoryView
    knowledge: KnowledgeView
    session: SessionHandle
    conversation: ConversationHandle
    working_memory: WorkingMemoryView
    observation_log: ObservationView
