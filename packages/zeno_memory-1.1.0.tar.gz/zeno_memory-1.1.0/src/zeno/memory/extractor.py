"""`MemoryExtractor` — post-turn fact extraction driven by a small LLM call.

Wired into `TurnDispatcher` as the ``on_turn_complete`` hook by `ZenoApp`.
Fires fire-and-forget after a successful handler return so the user-facing
reply is never delayed. Errors are logged and emitted as a `MemoryExtracted`
event with ``error=True``; they never propagate.

The LLM seam is a plain async callable so the extractor stays
provider-agnostic: tests pass an in-memory stub, production wires a thin
adapter around the configured `Provider`.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import re
import time
import warnings
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING, Any

from zeno.observability.events import MemoryExtracted, _Envelope

if TYPE_CHECKING:
    from zeno.channels.messages import IncomingMessage
    from zeno.context import Ctx
    from zeno.memory.protocols import UserMemoryStore

LLMCallable = Callable[[str], Awaitable[str]]
"""Provider-agnostic LLM seam.

Takes a single rendered prompt and returns the model's reply text. The
extractor parses a JSON array of facts from the reply; any other shape
becomes zero candidates plus a logged event with ``error=True``.
"""

DEFAULT_PROMPT = """\
You are extracting durable, user-specific facts from a single chat turn so a future
assistant turn can recall them. Output a JSON array of strings -- nothing else.

Rules:
- Only include facts about the user that will plausibly matter on a future turn
  (preferences, ongoing goals, stable identifiers, decisions they have made).
- Exclude one-off questions, transient acknowledgements, and anything inferable
  from a generic LLM context window.
- Each fact must be a self-contained sentence that makes sense without the turn.
- Output at most {max_facts} facts. If there is nothing worth remembering, return [].

USER:
{user_text}

ASSISTANT:
{assistant_text}

JSON array:"""


class MemoryExtractor:
    """Pulls durable facts from a finished turn and writes them to user memory.

    Construction is cheap; the instance is meant to be reused across turns.
    Call sites typically wire `extract_for_turn` directly as the
    ``on_turn_complete`` hook on `TurnDispatcher`.
    """

    def __init__(
        self,
        *,
        store: UserMemoryStore,
        llm: LLMCallable,
        min_chars: int = 40,
        max_facts: int = 5,
        prompt_template: str = DEFAULT_PROMPT,
    ) -> None:
        if min_chars < 0:
            raise ValueError(f"min_chars must be >= 0; got {min_chars}")
        if max_facts < 1:
            raise ValueError(f"max_facts must be >= 1; got {max_facts}")
        warnings.warn(
            "MemoryExtractor is deprecated; use ObservationalMemory in "
            "ZenoApp(observational_memory=...) instead. This class will be "
            "removed in the next minor release. See MIGRATION.md.",
            DeprecationWarning,
            stacklevel=2,
        )
        self._store = store
        self._llm = llm
        self._min_chars = min_chars
        self._max_facts = max_facts
        self._prompt_template = prompt_template

    async def extract_for_turn(self, ctx: Ctx, msg: IncomingMessage, assistant_text: str) -> None:
        """Hook entrypoint matching `TurnCompleteHook`.

        Catches every exception so a malformed model reply, a transient LLM
        error, or a store hiccup can never leak out of the post-turn task.
        Always emits a `MemoryExtracted` event so operators can observe
        skip / success / error rates in their tracer.
        """
        started = time.monotonic()
        candidate_count = 0
        inserted_count = 0
        error = False
        try:
            user_text = msg.text or ""
            if not user_text.strip() or len(assistant_text) < self._min_chars:
                return
            prompt = self._prompt_template.format(
                max_facts=self._max_facts,
                user_text=user_text,
                assistant_text=assistant_text,
            )
            reply = await self._llm(prompt)
            facts = _parse_facts(reply, max_facts=self._max_facts)
            candidate_count = len(facts)
            for fact in facts:
                try:
                    await self._store.add(ctx.user_id, fact, {"source": "extractor"}, tier="short")
                except Exception:  # noqa: BLE001
                    # One bad fact must not stop the rest; mark the run as
                    # errored so operators see the partial failure.
                    error = True
                else:
                    inserted_count += 1
        except asyncio.CancelledError:
            # The hook task was cancelled (shutdown, timeout). Mark the
            # event accordingly and re-raise so cancellation propagates
            # to the wrapper — otherwise observers would see a misleading
            # `error=False` event and the task would not unwind cleanly.
            error = True
            raise
        except Exception:  # noqa: BLE001
            error = True
        finally:
            duration_ms = int((time.monotonic() - started) * 1000)
            event = MemoryExtracted(
                envelope=_Envelope(
                    turn_id=ctx.turn_id,
                    sequence=0,
                    user_id=ctx.user_id,
                    session_id=ctx.session_id,
                ),
                candidate_count=candidate_count,
                inserted_count=inserted_count,
                duration_ms=duration_ms,
                error=error,
            )
            tracer = getattr(ctx, "tracer", None)
            if tracer is not None:
                with contextlib.suppress(Exception):
                    tracer.on_event(event)


_JSON_ARRAY_NONGREEDY = re.compile(r"\[.*?\]", re.DOTALL)
_JSON_ARRAY_GREEDY = re.compile(r"\[.*\]", re.DOTALL)


def _coerce_to_list(parsed: Any) -> list[Any] | None:
    """Return a list if `parsed` is one, or lift the first list value of an
    object (handles ``{"facts": [...]}``-style replies). Else ``None``."""
    if isinstance(parsed, list):
        return parsed
    if isinstance(parsed, dict):
        for value in parsed.values():
            if isinstance(value, list):
                return value
    return None


def _parse_facts(reply: str, *, max_facts: int) -> list[str]:
    """Best-effort extraction of a JSON array of strings from the LLM reply.

    Returns ``[]`` when no parseable array is present or when the array
    contains no usable strings. Non-string elements are silently dropped;
    duplicates and blank strings are removed; the result is capped at
    ``max_facts`` to bound the per-turn write fan-out.

    The scan tries non-greedy ``[...]`` matches in order so a noisy reply
    like ``"Note: [per the rules], here is: [\\"fact\\"]"`` returns the
    actual array instead of failing on the bracketed prose. A greedy
    fallback handles nested-array shapes the non-greedy scan misses.
    """
    raw_list: list[Any] | None = None
    for match in _JSON_ARRAY_NONGREEDY.finditer(reply):
        try:
            parsed = json.loads(match.group(0))
        except json.JSONDecodeError:
            continue
        coerced = _coerce_to_list(parsed)
        if coerced is not None:
            raw_list = coerced
            break
    if raw_list is None:
        greedy = _JSON_ARRAY_GREEDY.search(reply)
        if greedy is not None:
            try:
                raw_list = _coerce_to_list(json.loads(greedy.group(0)))
            except json.JSONDecodeError:
                raw_list = None
    if raw_list is None:
        return []
    seen: set[str] = set()
    facts: list[str] = []
    for item in raw_list:
        if not isinstance(item, str):
            continue
        text = item.strip()
        if not text or text in seen:
            continue
        seen.add(text)
        facts.append(text)
        if len(facts) >= max_facts:
            break
    return facts
