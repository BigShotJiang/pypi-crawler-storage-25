"""Shared `Merge` / `Replace` / `Delete` verbs and JSON parsers used by both
consolidation (legacy) and the L4 Reflector.

The verb semantics are identical across both pipelines:

- ``Merge`` — combine N source rows into one new row at the merged text.
- ``Replace`` — rewrite a single source row to new text.
- ``Delete`` — soft-delete a single source row (`archived_at`).

Parsing helpers are also shared: both pipelines wrap the proposer's edits
in ``{"edits": [...]}`` and use the same per-edit shape, so the parser
lives here too. Consolidation re-exports the public + private names for
backward compatibility with existing tests and out-of-tree imports.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any

__all__ = [
    "Delete",
    "Edit",
    "Merge",
    "Replace",
]


@dataclass(frozen=True, slots=True)
class Merge:
    """Combine *source_ids* into a single new row whose body is *text*.

    The store archives every source row and inserts one new row at the
    highest tier observed across the source set (or, for observations,
    at the highest priority observed). ``source_ids`` must be non-empty;
    an empty tuple is silently skipped at apply time so a sloppy
    proposer cannot insert orphan rows.
    """

    source_ids: tuple[int, ...]
    text: str


@dataclass(frozen=True, slots=True)
class Replace:
    """Rewrite *source_id* to *text*.

    The store archives the source row and inserts the rewritten body at
    the same tier (consolidation) or priority (reflection). A permanent
    fact stays permanent — neither pipeline silently downgrades.
    """

    source_id: int
    text: str


@dataclass(frozen=True, slots=True)
class Delete:
    """Soft-delete *source_id*.

    The store sets ``archived_at`` rather than hard-deleting; archived
    rows are no longer visible to renderers or to the proposer's next
    run, but remain on disk for audit until prune.
    """

    source_id: int


Edit = Merge | Replace | Delete
"""The verb tagged-union shared by `MemoryConsolidator` and `Reflector`."""


# ---------------------------------------------------------------------------
# JSON parsing helpers — shared by both pipelines.
# ---------------------------------------------------------------------------


_JSON_OBJECT_GREEDY = re.compile(r"\{.*\}", re.DOTALL)


def _parse_top_level_object(reply: str) -> dict[str, Any] | None:
    """Return the outermost ``{...}`` in *reply* that parses as a JSON object.

    A non-greedy scan would match the first nested edit object instead of
    the wrapper — e.g. ``{"edits": [...]}`` contains a smaller valid
    ``{"verb": "delete", "source_id": 1}`` literal that ``.*?`` would
    settle for. Going greedy from the first ``{`` to the last ``}`` is
    the only single-pass regex that captures the wrapper. We then strip
    trailing characters (e.g. a stray ``"...\\n}\\n"`` remark) until the
    parser succeeds or we run out of characters.
    """
    stripped = reply.strip()
    if stripped:
        try:
            parsed = json.loads(stripped)
        except json.JSONDecodeError:
            pass
        else:
            if isinstance(parsed, dict):
                return parsed
    match = _JSON_OBJECT_GREEDY.search(reply)
    if match is None:
        return None
    candidate = match.group(0)
    while candidate:
        try:
            parsed = json.loads(candidate)
        except json.JSONDecodeError:
            candidate = candidate[:-1]
            continue
        if isinstance(parsed, dict):
            return parsed
        return None
    return None


def _parse_edits(reply: str, *, valid_ids: set[int]) -> list[Edit]:
    """Parse a proposer reply into a list of edits.

    Drops edits whose ids are not in *valid_ids* — an LLM that
    hallucinates an id must not get a row archived. Each id is allowed
    to appear in at most one accepted edit; later duplicates are
    dropped silently so the apply phase cannot double-archive a source
    row.
    """
    parsed = _parse_top_level_object(reply)
    if parsed is None:
        return []
    raw = parsed.get("edits")
    if not isinstance(raw, list):
        return []
    edits: list[Edit] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        edit = _coerce_edit(item, valid_ids=valid_ids)
        if edit is not None:
            edits.append(edit)
    return _dedupe_edits(edits)


def _coerce_edit(obj: dict[str, Any], *, valid_ids: set[int]) -> Edit | None:
    verb = obj.get("verb")
    if verb == "merge":
        ids = obj.get("source_ids")
        text = obj.get("text")
        if not isinstance(ids, list) or not isinstance(text, str):
            return None
        cleaned: list[int] = []
        for raw_id in ids:
            if isinstance(raw_id, bool) or not isinstance(raw_id, int):
                continue
            if raw_id in valid_ids:
                cleaned.append(raw_id)
        text = text.strip()
        if len(cleaned) < 2 or not text:
            # A "merge" of one row is just a "replace"; refuse silently
            # to keep the apply path's contract simple.
            return None
        return Merge(source_ids=tuple(cleaned), text=text)
    if verb == "replace":
        raw_id = obj.get("source_id")
        text = obj.get("text")
        if isinstance(raw_id, bool) or not isinstance(raw_id, int):
            return None
        if raw_id not in valid_ids or not isinstance(text, str):
            return None
        text = text.strip()
        if not text:
            return None
        return Replace(source_id=raw_id, text=text)
    if verb == "delete":
        raw_id = obj.get("source_id")
        if isinstance(raw_id, bool) or not isinstance(raw_id, int):
            return None
        if raw_id not in valid_ids:
            return None
        return Delete(source_id=raw_id)
    return None


def _dedupe_edits(edits: list[Edit]) -> list[Edit]:
    """Drop later edits that reuse an id already touched by an earlier edit."""
    used: set[int] = set()
    result: list[Edit] = []
    for edit in edits:
        ids = _edit_source_ids(edit)
        if used.intersection(ids):
            continue
        used.update(ids)
        result.append(edit)
    return result


def _edit_source_ids(edit: Edit) -> tuple[int, ...]:
    if isinstance(edit, Merge):
        return edit.source_ids
    return (edit.source_id,)


def _edit_to_dict(edit: Edit) -> dict[str, Any]:
    if isinstance(edit, Merge):
        return {"verb": "merge", "source_ids": list(edit.source_ids), "text": edit.text}
    if isinstance(edit, Replace):
        return {"verb": "replace", "source_id": edit.source_id, "text": edit.text}
    return {"verb": "delete", "source_id": edit.source_id}


def _split_edits(
    edits: list[Edit],
) -> tuple[tuple[Merge, ...], tuple[Replace, ...], tuple[Delete, ...]]:
    merges: list[Merge] = []
    replaces: list[Replace] = []
    deletes: list[Delete] = []
    for edit in edits:
        if isinstance(edit, Merge):
            merges.append(edit)
        elif isinstance(edit, Replace):
            replaces.append(edit)
        else:
            deletes.append(edit)
    return tuple(merges), tuple(replaces), tuple(deletes)
