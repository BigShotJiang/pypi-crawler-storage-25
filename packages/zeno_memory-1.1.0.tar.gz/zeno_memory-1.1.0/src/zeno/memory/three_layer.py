"""`ThreeLayer` composer — session + user memory + knowledge + conversation (R7, R8, R20-R22).

Used by `ZenoApp` to build a single `MemoryView` per turn, wired to the
concrete backends the application picked. Tests instantiate it directly
with fakes.

The class is named ``ThreeLayer`` for historical reasons — it was born
carrying three primitives (session, user, knowledge). IU2 adds the
``conversation`` primitive so non-Claude providers have somewhere to
persist the ordered message log. We keep the name to avoid a breaking
import across the workspace and all external callers; the "four layers"
of v0.3.0 are described in docstrings and README, not in the type name.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from zeno.memory.handles import (
    ConversationHandle,
    KnowledgeView,
    MemoryView,
    ObservationView,
    SessionHandle,
    UserMemoryView,
    WorkingMemoryView,
)

if TYPE_CHECKING:
    from zeno.memory.protocols import (
        ConversationStore,
        KnowledgeStore,
        ObservationStore,
        SessionStore,
        UserMemoryStore,
        WorkingMemoryStore,
    )


@dataclass(frozen=True, slots=True)
class ThreeLayer:
    """Holds references to the six store backends; binds them per turn."""

    session: SessionStore
    user_memory: UserMemoryStore
    knowledge: KnowledgeStore
    conversation: ConversationStore
    working_memory: WorkingMemoryStore
    observation_log: ObservationStore

    def view_for(
        self,
        *,
        user_id: str,
        channel: str,
        thread_key: str | None,
        agent_id: str,
    ) -> MemoryView:
        return MemoryView(
            user=UserMemoryView(_store=self.user_memory, _user_id=user_id),
            knowledge=KnowledgeView(_store=self.knowledge, _user_id=user_id),
            session=SessionHandle(
                _store=self.session,
                _user_id=user_id,
                _channel=channel,
                _thread_key=thread_key,
            ),
            conversation=ConversationHandle(
                _store=self.conversation,
                _user_id=user_id,
                _thread_key=thread_key,
            ),
            working_memory=WorkingMemoryView(
                _store=self.working_memory,
                _user_id=user_id,
                _agent_id=agent_id,
            ),
            observation_log=ObservationView(
                _store=self.observation_log,
                _user_id=user_id,
                _agent_id=agent_id,
            ),
        )
