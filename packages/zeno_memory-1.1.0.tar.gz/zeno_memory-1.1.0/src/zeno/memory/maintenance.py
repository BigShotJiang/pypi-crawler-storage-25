"""`MemoryMaintenance` — periodic decay + prune background loop.

Owns the lifecycle of tiered user-memory rows after they land in the store:

  - **Decay** for ``short`` and ``long``: rows idle past a per-tier threshold
    are either *promoted* (if they cleared the per-tier hit-count bar) or
    *archived* (soft-deleted via ``archived_at``).
  - **Prune**: archived rows older than the retention window are hard-deleted
    so the table does not grow without bound.

Three explicit ``*_now`` methods drive the same code paths the loop uses, so
operators and tests can run a sweep without waiting for the next tick.

Permanent rows are never touched: they survived earlier sweeps by being
promoted into the terminal tier. The store's ``list_decay_candidates`` raises
on ``tier="permanent"`` so a misconfigured caller fails loudly rather than
silently archiving facts the user pinned.

The loop is single-task, error-isolated, and uses a ``wake`` event so tests
can trigger immediate ticks without sleeping. Errors during a sweep are
logged and surfaced on the event (``error=True``); the loop keeps running.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import time
import uuid
import warnings
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from zeno.memory.protocols import MemoryTier
from zeno.observability.events import MemoryDecayed, MemoryPruned

if TYPE_CHECKING:
    from zeno.memory.sqlite.user_memory_store import SqliteUserMemoryStore

logger = logging.getLogger("zeno.memory.maintenance")

_DAY = 24 * 3600

# Two tiers participate in decay; permanent is terminal and excluded.
_DECAY_TIERS: tuple[MemoryTier, MemoryTier] = ("short", "long")
_NEXT_TIER: dict[MemoryTier, MemoryTier] = {"short": "long", "long": "permanent"}


class MemoryMaintenance:
    """Background decay + prune loop for `SqliteUserMemoryStore`.

    Single asyncio task. Idempotent ``start()``/``stop()``. Three
    ``*_now()`` entrypoints for explicit sweeps. The loop cadence
    (``tick_s``) governs how often the worker wakes; per-pass thresholds
    (``short_idle_seconds``, ``long_idle_seconds``, ``prune_after_seconds``)
    govern *what* each pass touches.

    Defaults are conservative: a freshly extracted ``short`` fact has a
    week of idle time to be re-mentioned (and bumped to ``long``) before
    decay archives it, archived rows linger for 90 days before prune
    deletes them.
    """

    def __init__(
        self,
        store: SqliteUserMemoryStore,
        *,
        tracer: Any = None,
        # Decay thresholds.
        short_idle_seconds: int = 7 * _DAY,
        long_idle_seconds: int = 30 * _DAY,
        promote_short_at_hits: int = 2,
        promote_long_at_hits: int = 5,
        # Prune retention. ``None`` disables prune entirely; archived rows
        # remain forever and the operator is on the hook for cleanup.
        prune_after_seconds: int | None = 90 * _DAY,
        prune_interval_s: float = float(_DAY),
        # Loop cadence.
        tick_s: float = 3600.0,
        now_fn: Callable[[], int] | None = None,
    ) -> None:
        if promote_short_at_hits < 1:
            raise ValueError(f"promote_short_at_hits must be >= 1; got {promote_short_at_hits}")
        if promote_long_at_hits < 1:
            raise ValueError(f"promote_long_at_hits must be >= 1; got {promote_long_at_hits}")
        if tick_s <= 0:
            raise ValueError(f"tick_s must be > 0; got {tick_s}")
        if prune_interval_s <= 0:
            raise ValueError(f"prune_interval_s must be > 0; got {prune_interval_s}")
        warnings.warn(
            "MemoryMaintenance is deprecated; use ObservationalMemory in "
            "ZenoApp(observational_memory=...) instead. This class will be "
            "removed in the next minor release. See MIGRATION.md.",
            DeprecationWarning,
            stacklevel=2,
        )

        self._store = store
        self._tracer = tracer
        self._short_idle = short_idle_seconds
        self._long_idle = long_idle_seconds
        self._promote_at: dict[MemoryTier, int] = {
            "short": promote_short_at_hits,
            "long": promote_long_at_hits,
        }
        self._prune_after = prune_after_seconds
        self._prune_interval = prune_interval_s
        self._tick_s = tick_s
        self._now_fn: Callable[[], int] = now_fn or (lambda: int(time.time()))

        self._task: asyncio.Task[None] | None = None
        self._stopping = False
        self._wake = asyncio.Event()
        self._cycle_done = asyncio.Event()
        self._last_prune_at: int | None = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Start the background loop. Idempotent."""
        if self._task is not None and not self._task.done():
            return
        self._stopping = False
        self._task = asyncio.create_task(self._run(), name="memory-maintenance")

    async def stop(self) -> None:
        """Cancel the loop and await its task. Idempotent."""
        self._stopping = True
        self._wake.set()
        if self._task is not None and not self._task.done():
            self._task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await self._task
        self._task = None

    async def wait_idle(self) -> None:
        """Block until the worker loop completes one full cycle.

        Tests use this to assert that a tick has run after advancing the
        clock or poking ``_wake``, without relying on real wall-clock
        sleeps.

        Raises ``RuntimeError`` if the loop is not running — without this
        guard, the caller would block indefinitely on ``_cycle_done`` with
        no task to ever set it.
        """
        if self._task is None or self._task.done():
            raise RuntimeError("MemoryMaintenance is not running; call start() before wait_idle()")
        self._cycle_done.clear()
        self._wake.set()
        await self._cycle_done.wait()

    # ------------------------------------------------------------------
    # Public sweep entrypoints
    # ------------------------------------------------------------------

    async def decay_now(self, tier: MemoryTier) -> MemoryDecayed:
        """Run one decay sweep for *tier* immediately. Returns the event.

        The same event is also emitted to the configured tracer; the
        return value lets callers (operators, tests) inspect counts
        without going through the tracer.
        """
        if tier not in _DECAY_TIERS:
            raise ValueError(f"decay_now requires a non-permanent tier; got {tier!r}")
        return await self._sweep_decay(tier)

    async def prune_now(self) -> MemoryPruned:
        """Run one prune pass immediately. Returns the event."""
        if self._prune_after is None:
            raise RuntimeError(
                "prune is disabled (prune_after_seconds=None); enable it before calling prune_now()"
            )
        return await self._sweep_prune()

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    async def _run(self) -> None:
        try:
            while not self._stopping:
                self._cycle_done.clear()
                try:
                    try:
                        for tier in _DECAY_TIERS:
                            await self._sweep_decay(tier)
                        if self._should_prune():
                            await self._sweep_prune()
                    except Exception:  # noqa: BLE001
                        # The per-sweep paths already log + emit events, but
                        # an unexpected error in scheduling itself must not
                        # kill the loop.
                        logger.exception("MemoryMaintenance tick raised")
                finally:
                    # Always release `wait_idle` callers, even on cancel —
                    # otherwise a test that races stop() with wait_idle()
                    # would hang on _cycle_done forever.
                    self._cycle_done.set()
                if self._stopping:
                    break
                with contextlib.suppress(TimeoutError):
                    await asyncio.wait_for(self._wake.wait(), timeout=self._tick_s)
                self._wake.clear()
        except asyncio.CancelledError:
            self._cycle_done.set()

    def _should_prune(self) -> bool:
        if self._prune_after is None:
            return False
        now = self._now_fn()
        if self._last_prune_at is None:
            return True
        return (now - self._last_prune_at) >= self._prune_interval

    async def _sweep_decay(self, tier: MemoryTier) -> MemoryDecayed:
        run_id = uuid.uuid4().hex[:12]
        started = time.monotonic()
        idle_seconds = self._short_idle if tier == "short" else self._long_idle
        promote_threshold = self._promote_at[tier]

        candidates_seen = 0
        promoted = 0
        archived = 0
        error = False
        try:
            candidates = await self._store.list_decay_candidates(
                tier=tier, idle_seconds=idle_seconds
            )
            candidates_seen = len(candidates)
            promote_ids = [c.id for c in candidates if c.hit_count >= promote_threshold]
            archive_ids = [c.id for c in candidates if c.hit_count < promote_threshold]

            if promote_ids:
                next_tier = _NEXT_TIER[tier]
                promoted = await self._store.promote(promote_ids, next_tier)
            if archive_ids:
                archived = await self._store.archive(archive_ids)
        except Exception:  # noqa: BLE001
            error = True
            logger.exception("decay sweep failed for tier=%s run_id=%s", tier, run_id)

        event = MemoryDecayed(
            run_id=run_id,
            tier=tier,
            candidates_seen=candidates_seen,
            promoted=promoted,
            archived=archived,
            duration_ms=int((time.monotonic() - started) * 1000),
            error=error,
        )
        self._emit(event)
        return event

    async def _sweep_prune(self) -> MemoryPruned:
        run_id = uuid.uuid4().hex[:12]
        started = time.monotonic()
        # ``prune_now()`` raises when ``_prune_after`` is ``None`` and the
        # loop path is gated by ``_should_prune`` which returns ``False``.
        # Convert the residual case to a real error rather than asserting,
        # so ``python -O`` cannot turn this into a confusing TypeError on
        # the arithmetic below.
        if self._prune_after is None:
            raise RuntimeError("_sweep_prune invoked with prune disabled")
        archived_before = self._now_fn() - self._prune_after

        pruned_count = 0
        error = False
        try:
            ids = await self._store.list_prune_candidates(archived_before=archived_before)
            if ids:
                pruned_count = await self._store.hard_delete(ids)
        except Exception:  # noqa: BLE001
            error = True
            logger.exception("prune sweep failed run_id=%s", run_id)

        # Only advance the cooldown clock on success — otherwise a transient
        # store error would silently defer the next prune by ``prune_interval``
        # (default 24h) and let archived rows accumulate unobserved.
        if not error:
            self._last_prune_at = self._now_fn()
        event = MemoryPruned(
            run_id=run_id,
            pruned_count=pruned_count,
            archived_before=archived_before,
            duration_ms=int((time.monotonic() - started) * 1000),
            error=error,
        )
        self._emit(event)
        return event

    def _emit(self, event: Any) -> None:
        if self._tracer is None:
            return
        with contextlib.suppress(Exception):
            self._tracer.on_event(event)
