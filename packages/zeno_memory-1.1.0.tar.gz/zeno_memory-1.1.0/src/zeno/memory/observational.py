"""`ObservationalMemory` — L4 orchestrator wrapping Observer + Reflector.

Single subsystem object that the runtime hooks into the
``on_turn_complete`` callback. After each turn, the orchestrator checks
whether the unprocessed conversation tail crosses the Observer
threshold; if so, it spawns a fire-and-forget background task that
runs the Observer and (when the active observation log itself crosses
the Reflector threshold) the Reflector.

Concurrency / failure posture:

- Single-flight per ``(user_id, agent_id, thread_key)`` window. A
  second `maybe_observe_and_reflect` call while the first is still
  running is a silent no-op — the spec is "we already have a worker
  on this window; don't double up", not "queue another run".
- Different windows run in parallel; they each get their own busy
  flag and background task.
- Errors from the Observer or Reflector are absorbed: those classes
  already log + emit ``MemoryObserved(error=True)`` /
  ``MemoryReflected(error=True)``. The orchestrator just makes sure
  the busy flag is released so the next threshold crossing can retry.
- ``stop()`` cancels all in-flight tasks and awaits them. The
  Observer's ``CancelledError`` finally-block will still emit a
  ``MemoryObserved(error=True)`` event so cancelled work is visible
  in the trace.

Single-process caveat (mirrors `zeno-scheduler`): the busy flag set
lives in process memory. Two processes pointed at the same SQLite
file will not coordinate via this object — each process makes its own
independent threshold decision. If you need cross-process
coordination, hold the L4 pipeline single-process by deploying one
worker.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
from typing import TYPE_CHECKING, Any, Literal

from zeno.runtime.tokens import TokenCounter, count_tokens

if TYPE_CHECKING:
    from zeno.context import Ctx
    from zeno.memory.observer import Observer
    from zeno.memory.protocols import (
        ConversationMessage,
        ConversationStore,
        Observation,
        ObservationStore,
    )
    from zeno.memory.reflector import Reflector

logger = logging.getLogger("zeno.memory.observational")


_WindowKey = tuple[str, str, str | None]
"""(`user_id`, `agent_id`, `thread_key`) — the single-flight window key."""


class ObservationalMemory:
    """Threshold-driven Observer + Reflector orchestrator.

    Construction is cheap; reuse one instance across users and turns.
    Hook the ``maybe_observe_and_reflect`` method into the runtime's
    ``on_turn_complete`` callback (Unit 8 wires `ZenoApp` to do this).
    """

    def __init__(
        self,
        *,
        observer: Observer,
        reflector: Reflector,
        conversations: ConversationStore,
        observations: ObservationStore,
        tracer: Any = None,
        observer_threshold_tokens: int = 30_000,
        reflector_threshold_tokens: int = 40_000,
        priority_markers: Literal["emoji", "tokens"] = "emoji",
        token_counter: TokenCounter | None = None,
    ) -> None:
        if observer_threshold_tokens < 1:
            raise ValueError(
                f"observer_threshold_tokens must be >= 1; got {observer_threshold_tokens}"
            )
        if reflector_threshold_tokens < 1:
            raise ValueError(
                f"reflector_threshold_tokens must be >= 1; got {reflector_threshold_tokens}"
            )
        self._observer = observer
        self._reflector = reflector
        self._conversations = conversations
        self._observations = observations
        self._tracer = tracer
        self._observer_threshold = observer_threshold_tokens
        self._reflector_threshold = reflector_threshold_tokens
        self._priority_markers: Literal["emoji", "tokens"] = priority_markers
        self._token_counter: TokenCounter = token_counter or count_tokens

        self._started = False
        self._busy: set[_WindowKey] = set()
        self._tasks: set[asyncio.Task[None]] = set()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    @property
    def priority_markers(self) -> Literal["emoji", "tokens"]:
        """Renderer-facing priority style. Read by Unit 9's block renderer."""
        return self._priority_markers

    async def start(self) -> None:
        """Initialise internal state. Idempotent."""
        if self._started:
            return
        self._started = True
        self._busy.clear()
        self._tasks.clear()

    async def stop(self) -> None:
        """Cancel and await all in-flight tasks. Idempotent."""
        if not self._started:
            return
        self._started = False
        tasks = list(self._tasks)
        for task in tasks:
            task.cancel()
        for task in tasks:
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await task
        self._tasks.clear()
        self._busy.clear()

    async def wait_idle(self) -> None:
        """Wait for all in-flight Observer/Reflector tasks to finish.

        Tests use this to drive deterministic assertions: trigger a
        threshold crossing, then await `wait_idle` before checking
        emitted events. Returns immediately if nothing is in flight.
        """
        while self._tasks:
            tasks = list(self._tasks)
            await asyncio.gather(*tasks, return_exceptions=True)

    # ------------------------------------------------------------------
    # Public entrypoint
    # ------------------------------------------------------------------

    async def maybe_observe_and_reflect(
        self,
        ctx: Ctx,
        *,
        agent_id: str,
        thread_key: str | None,
    ) -> None:
        """Maybe spawn an Observer (+ Reflector) run for this window.

        Cheap when the threshold is not crossed: one watermark read,
        one ``load_since`` call, and one token count. Spawns a
        fire-and-forget task on threshold crossing — the caller does
        not await the work.
        """
        if not self._started:
            return
        key: _WindowKey = (ctx.user_id, agent_id, thread_key)
        if key in self._busy:
            return
        self._busy.add(key)

        spawned = False
        try:
            watermark = await self._observations.read_watermark(
                user_id=ctx.user_id, agent_id=agent_id, thread_key=thread_key
            )
            after_sequence = watermark.last_processed_sequence if watermark is not None else -1
            rounds = await self._conversations.load_since(
                user_id=ctx.user_id, thread_key=thread_key, after_sequence=after_sequence
            )
            if not rounds:
                return
            if self._token_counter(_serialize_rounds(rounds)) < self._observer_threshold:
                return

            task = asyncio.create_task(
                self._run_pipeline(ctx, agent_id=agent_id, thread_key=thread_key, key=key),
                name=f"observational-memory:{key[0]}:{agent_id}",
            )
            self._tasks.add(task)
            task.add_done_callback(self._tasks.discard)
            spawned = True
        finally:
            if not spawned:
                self._busy.discard(key)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    async def _run_pipeline(
        self,
        ctx: Ctx,
        *,
        agent_id: str,
        thread_key: str | None,
        key: _WindowKey,
    ) -> None:
        try:
            await self._observer.observe_for_window(ctx, agent_id=agent_id, thread_key=thread_key)
            observations = await self._observations.list_active(ctx.user_id, agent_id)
            if observations and (
                self._token_counter(_render_observations(observations)) >= self._reflector_threshold
            ):
                await self._reflector.reflect(user_id=ctx.user_id, agent_id=agent_id)
        except asyncio.CancelledError:
            # Observer/Reflector already emit their own error events when
            # cancelled; just propagate so the task transitions to
            # cancelled cleanly.
            raise
        except Exception:  # noqa: BLE001
            logger.exception(
                "observational memory worker failed user_id=%s agent_id=%s thread_key=%s",
                ctx.user_id,
                agent_id,
                thread_key,
            )
        finally:
            self._busy.discard(key)


# ---------------------------------------------------------------------------
# Threshold-detection helpers — cheap renderers used only for token counting.
# The real prompt rendering lives on the Observer and the Unit 9 block
# renderer; these are deliberately small to keep the threshold check fast.
# ---------------------------------------------------------------------------


def _serialize_rounds(rounds: list[tuple[int, ConversationMessage]]) -> str:
    """Concatenate round bodies for token counting.

    The Observer renders rounds with structured labels and tool-call
    truncation; we keep this lighter because the threshold check fires
    on every turn and we don't want to pay for full rendering when
    99 % of calls return below threshold. The estimate is consistent
    enough — content + tool-call payload — that the heuristic
    `count_tokens` (`len // 4`) lands in the right ballpark.
    """
    parts: list[str] = []
    for _seq, msg in rounds:
        if msg.content:
            parts.append(msg.content)
        if msg.tool_calls:
            try:
                parts.append(json.dumps(msg.tool_calls))
            except (TypeError, ValueError):
                parts.append(str(msg.tool_calls))
    return "\n".join(parts)


def _render_observations(observations: list[Observation]) -> str:
    """Concatenate observation bodies for token counting."""
    return "\n".join(o.text for o in observations)


__all__ = [
    "ObservationalMemory",
]
