"""`SqliteWorkingMemoryStore` — SQLite default for `WorkingMemoryStore`.

One row per `(user_id, agent_id, field_name)`. The store mirrors
`SqliteSessionStore` for connection lifecycle and `SqliteUserMemoryStore`
for write-path posture: a per-store `asyncio.Lock` serializes `update`
and `clear` within one process, and `BEGIN IMMEDIATE` plus the migrator's
`busy_timeout` cover cross-process safety.

Empty-string-as-clear is the only contract semantic the store interprets:
`update(..., patch={"role": ""})` deletes the `role` row instead of
writing an empty string. Whitespace-only and other non-empty values are
stored verbatim — callers that want richer normalisation must do it
upstream.
"""

from __future__ import annotations

import asyncio
import contextlib
import os
import time
from collections.abc import Callable
from typing import TYPE_CHECKING

import aiosqlite
from zeno.memory.protocols import WorkingMemoryRecord
from zeno.memory.sqlite.migrate import configure_connection, ensure_schema

if TYPE_CHECKING:
    from pathlib import Path


class SqliteWorkingMemoryStore:
    """Durable per-`(user_id, agent_id)` typed key-value memory."""

    def __init__(
        self,
        path: str | Path,
        *,
        now_fn: Callable[[], int] | None = None,
    ) -> None:
        self._path = str(path)
        self._initialized = False
        self._now_fn: Callable[[], int] = now_fn or (lambda: int(time.time()))
        self._write_lock = asyncio.Lock()

    async def _connect(self) -> aiosqlite.Connection:
        conn = await aiosqlite.connect(self._path)
        await configure_connection(conn)
        if not self._initialized:
            await ensure_schema(conn, path=self._path)
            self._chmod_secure()
            self._initialized = True
        return conn

    def _chmod_secure(self) -> None:
        """Best-effort: restrict DB file permissions to owner-only."""
        with contextlib.suppress(OSError):
            os.chmod(self._path, 0o600)

    async def get(self, user_id: str, agent_id: str) -> dict[str, WorkingMemoryRecord]:
        conn = await self._connect()
        try:
            cur = await conn.execute(
                "SELECT field_name, value, last_updated FROM working_memory "
                "WHERE user_id = ? AND agent_id = ?",
                (user_id, agent_id),
            )
            rows = await cur.fetchall()
        finally:
            await conn.close()
        return {
            row[0]: WorkingMemoryRecord(
                user_id=user_id,
                agent_id=agent_id,
                field_name=row[0],
                value=row[1],
                last_updated=int(row[2]),
            )
            for row in rows
        }

    async def update(self, user_id: str, agent_id: str, patch: dict[str, str]) -> None:
        if not patch:
            return
        now = self._now_fn()
        async with self._write_lock:
            conn = await self._connect()
            try:
                await conn.execute("BEGIN IMMEDIATE")
                for field_name, value in patch.items():
                    if value == "":
                        # R7: empty string clears the field.
                        await conn.execute(
                            "DELETE FROM working_memory "
                            "WHERE user_id = ? AND agent_id = ? AND field_name = ?",
                            (user_id, agent_id, field_name),
                        )
                    else:
                        await conn.execute(
                            "INSERT INTO working_memory "
                            "(user_id, agent_id, field_name, value, last_updated, created_at) "
                            "VALUES (?, ?, ?, ?, ?, ?) "
                            "ON CONFLICT(user_id, agent_id, field_name) "
                            "DO UPDATE SET value = excluded.value, "
                            "              last_updated = excluded.last_updated",
                            (user_id, agent_id, field_name, value, now, now),
                        )
                await conn.commit()
            finally:
                await conn.close()

    async def clear(self, user_id: str, agent_id: str) -> None:
        async with self._write_lock:
            conn = await self._connect()
            try:
                await conn.execute(
                    "DELETE FROM working_memory WHERE user_id = ? AND agent_id = ?",
                    (user_id, agent_id),
                )
                await conn.commit()
            finally:
                await conn.close()
