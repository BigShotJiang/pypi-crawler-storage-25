"""Idempotent schema migrator for the SQLite-backed memory stores.

Concurrency model:
  - Migration SQL scripts use ``CREATE TABLE IF NOT EXISTS`` /
    ``CREATE INDEX IF NOT EXISTS`` so re-running them is a no-op.
    SQLite has no ``ALTER TABLE ... ADD COLUMN IF NOT EXISTS``, so when
    a script adds columns we treat ``duplicate column name`` from
    ``executescript`` as a partial-apply signal: the prior run of this
    migration committed its DDL but crashed before recording the
    ``schema_version`` row, and the columns are now in their target
    state. We log and proceed to record the version.
  - The `schema_version` table has ``version`` as its PRIMARY KEY and we
    record applied migrations with ``INSERT OR IGNORE``. Two racing
    initializers may both run migration N, but at most one version row
    lands per version — the other insert is silently ignored.
  - ``PRAGMA busy_timeout=30000`` lets concurrent writers wait for the
    short-lived write lock instead of erroring with ``database is locked``.
  - A per-process ``asyncio.Lock`` serializes ``ensure_schema`` calls on
    the same event loop. Cross-connection races in the same process would
    otherwise see ``SQLITE_BUSY`` on first-init because
    ``PRAGMA journal_mode=WAL`` briefly requires an exclusive lock that
    is not always yielded to ``busy_timeout`` in a predictable window.

WAL mode is also enabled here to match the production recommendation.

We deliberately avoid wrapping the migration run in an explicit
``BEGIN EXCLUSIVE`` / ``COMMIT`` pair. Python's ``sqlite3`` treats DDL
and ``executescript()`` calls specially — they implicitly commit any
in-flight transaction, which makes the explicit pair fragile and depends
on the caller's ``isolation_level`` setting. Idempotent DDL + PK-backed
``INSERT OR IGNORE`` is simpler and works in every connection mode.
"""

from __future__ import annotations

import asyncio
import importlib.resources
import logging
import sqlite3
import time
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import aiosqlite

logger = logging.getLogger("zeno.memory.sqlite.migrate")

# Per-path locks: WAL initialization needs serialization for concurrent
# connections to the SAME database file, but stores backed by different
# files have no shared state and should not block each other at startup.
_INIT_LOCKS: dict[str, asyncio.Lock] = {}
_INIT_LOCKS_GUARD = asyncio.Lock()


async def _lock_for(key: str) -> asyncio.Lock:
    async with _INIT_LOCKS_GUARD:
        lock = _INIT_LOCKS.get(key)
        if lock is None:
            lock = asyncio.Lock()
            _INIT_LOCKS[key] = lock
        return lock


_MIGRATIONS_PACKAGE = "zeno.memory.sqlite.migrations"


def _load_migrations() -> list[tuple[int, str, str]]:
    """Return `[(version, name, sql), ...]` ordered by version."""
    resource = importlib.resources.files(_MIGRATIONS_PACKAGE)
    migrations: list[tuple[int, str, str]] = []
    for entry in resource.iterdir():
        name = entry.name
        if not name.endswith(".sql"):
            continue
        version_str = name.split("_", 1)[0]
        if not version_str.isdigit():
            continue
        with importlib.resources.as_file(entry) as path:
            sql = Path(path).read_text(encoding="utf-8")
        migrations.append((int(version_str), name, sql))
    migrations.sort(key=lambda t: t[0])
    return migrations


def _split_statements(sql: str) -> list[str]:
    """Split a migration script into individual statements.

    Strips line comments first so semicolons inside comments
    (e.g. ``-- short; long; permanent``) do not fool the splitter.
    Then naïvely splits on ``;`` — our scripts have no string literals
    containing semicolons and no triggers, so this is sufficient.

    We split because executing the script statement-by-statement is the
    only way to recover from per-statement errors (e.g., a duplicate
    column from a partial-apply) without losing later statements in the
    same script (e.g., a backfill UPDATE).
    """
    lines = [ln for ln in sql.splitlines() if not ln.strip().startswith("--")]
    cleaned_sql = "\n".join(lines)
    return [stmt for stmt in (chunk.strip() for chunk in cleaned_sql.split(";")) if stmt]


async def configure_connection(conn: aiosqlite.Connection) -> None:
    """Apply per-connection pragmas. Must run on every fresh connection.

    ``busy_timeout`` is connection-scoped — the value set inside
    ``ensure_schema`` only affects that one connection. Stores that open a
    new connection per call must call this helper or they'll inherit
    SQLite's default 0 ms timeout and fail immediately under any write
    contention.

    ``journal_mode=WAL`` is database-scoped (persisted on the file) so
    setting it once during ``ensure_schema`` suffices.
    """
    await conn.execute("PRAGMA busy_timeout=30000")


async def ensure_schema(conn: aiosqlite.Connection, *, path: str | None = None) -> None:
    """Apply any pending migrations. Idempotent; safe under concurrent calls.

    ``path`` is the database file path used to scope the WAL-init lock —
    concurrent connections to the *same* file serialize, but stores backed
    by *different* files initialize in parallel. ``None`` falls back to a
    single global lock (legacy behaviour).
    """
    lock = await _lock_for(path or "")
    async with lock:
        # busy_timeout must be set BEFORE any write: `PRAGMA journal_mode=WAL`
        # briefly requires an exclusive lock and would otherwise fail
        # immediately with `database is locked` under contention.
        await conn.execute("PRAGMA busy_timeout=30000")
        await conn.execute("PRAGMA journal_mode=WAL")
        await conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_version ("
            "version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)"
        )
        await conn.commit()

        cur = await conn.execute("SELECT MAX(version) FROM schema_version")
        row = await cur.fetchone()
        current = int(row[0]) if row and row[0] is not None else 0

        for version, name, sql in _load_migrations():
            if version <= current:
                continue
            for stmt in _split_statements(sql):
                try:
                    await conn.execute(stmt)
                except sqlite3.OperationalError as exc:
                    if "duplicate column name" not in str(exc):
                        raise
                    # Partial-apply recovery: a prior run of this
                    # migration committed an ALTER TABLE but crashed
                    # before recording the schema_version row. The
                    # column already exists; skip this statement and
                    # continue with the rest (e.g. a backfill UPDATE).
                    logger.warning(
                        "migration %s statement skipped (%s); column already exists",
                        name,
                        exc,
                    )
            await conn.execute(
                "INSERT OR IGNORE INTO schema_version (version, applied_at) VALUES (?, ?)",
                (version, int(time.time())),
            )
            await conn.commit()
