"""`SqliteObservationStore` — SQLite default for `ObservationStore` (R1, R2, R3, R10, R11).

Mirrors `SqliteWorkingMemoryStore` for connection lifecycle and
`SqliteUserMemoryStore.apply_consolidation` for atomic batch edits with
archive semantics.

Concurrency posture:
  - Per-store ``asyncio.Lock`` serializes ``insert_batch`` /
    ``apply_edits`` / ``advance_watermark`` within one process.
  - ``BEGIN IMMEDIATE`` covers cross-process safety in tandem with
    SQLite's ``busy_timeout``.
  - Reads (``list_active``, ``read_watermark``) do not hold the lock.

Storage notes:
  - ``source_round_ids`` is persisted as a JSON-encoded TEXT column,
    matching the precedent set by ``tool_calls_json`` in migration 004.
    Decoded back into a ``tuple[int, ...]`` on read.
  - ``apply_edits`` archives source rows (sets ``archived_at``) rather
    than hard-deleting them so the audit trail survives. Merge results
    inherit the highest priority and the union of source round ids.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import os
import time
from collections.abc import Callable, Iterable, Sequence
from typing import TYPE_CHECKING, Literal, cast

import aiosqlite
from zeno.memory._edits import Delete, Merge, Replace
from zeno.memory.protocols import (
    Observation,
    ObservationCounts,
    ObservationPriority,
    ObservationRunInput,
    ObservationRunWatermark,
)
from zeno.memory.sqlite.migrate import configure_connection, ensure_schema

if TYPE_CHECKING:
    from pathlib import Path


_PRIORITY_ORDER: dict[ObservationPriority, int] = {"low": 0, "medium": 1, "high": 2}


class SqliteObservationStore:
    """SQLite-backed observation log + per-`(user_id, agent_id, thread_key)` watermark."""

    def __init__(
        self,
        path: str | Path,
        *,
        now_fn: Callable[[], int] | None = None,
    ) -> None:
        self._path = str(path)
        self._initialized = False
        self._now_fn: Callable[[], int] = now_fn or (lambda: int(time.time()))
        self._write_lock = asyncio.Lock()

    async def _connect(self) -> aiosqlite.Connection:
        conn = await aiosqlite.connect(self._path)
        await configure_connection(conn)
        if not self._initialized:
            await ensure_schema(conn, path=self._path)
            self._chmod_secure()
            self._initialized = True
        return conn

    def _chmod_secure(self) -> None:
        with contextlib.suppress(OSError):
            os.chmod(self._path, 0o600)

    # ------------------------------------------------------------------
    # Observation rows.
    # ------------------------------------------------------------------

    async def insert_batch(self, observations: Iterable[Observation]) -> None:
        rows = list(observations)
        if not rows:
            return
        now = self._now_fn()
        async with self._write_lock:
            conn = await self._connect()
            try:
                await conn.execute("BEGIN IMMEDIATE")
                for obs in rows:
                    await conn.execute(
                        "INSERT INTO observations "
                        "(user_id, agent_id, text, priority, observation_date, "
                        " referenced_date, source_round_ids, created_at, archived_at) "
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        (
                            obs.user_id,
                            obs.agent_id,
                            obs.text,
                            obs.priority,
                            obs.observation_date,
                            obs.referenced_date,
                            json.dumps(list(obs.source_round_ids)),
                            obs.created_at if obs.created_at else now,
                            obs.archived_at,
                        ),
                    )
                await conn.commit()
            finally:
                await conn.close()

    async def list_active(self, user_id: str, agent_id: str) -> list[Observation]:
        conn = await self._connect()
        try:
            cur = await conn.execute(
                "SELECT id, text, priority, observation_date, referenced_date, "
                "       source_round_ids, created_at, archived_at "
                "FROM observations "
                "WHERE user_id = ? AND agent_id = ? AND archived_at IS NULL "
                "ORDER BY COALESCE(referenced_date, observation_date) ASC, id ASC",
                (user_id, agent_id),
            )
            rows = await cur.fetchall()
        finally:
            await conn.close()
        return [
            Observation(
                id=int(row[0]),
                user_id=user_id,
                agent_id=agent_id,
                text=row[1],
                priority=_coerce_priority(row[2]),
                observation_date=int(row[3]),
                referenced_date=int(row[4]) if row[4] is not None else None,
                source_round_ids=tuple(json.loads(row[5])) if row[5] else (),
                created_at=int(row[6]),
                archived_at=int(row[7]) if row[7] is not None else None,
            )
            for row in rows
        ]

    async def apply_edits(self, run_input: ObservationRunInput) -> ObservationCounts:
        """Atomically apply Merge/Replace/Delete edits.

        Source rows are archived (not hard-deleted) so a buggy proposer can
        be unwound by inspecting the run id. Merge inherits the highest
        priority among source rows and the union of their `source_round_ids`.
        Replace inherits priority and `referenced_date` from the source row.
        Edits referencing already-archived ids are counted as ``rejected``.
        """
        now = self._now_fn()
        merges_applied = 0
        replaces_applied = 0
        deletes_applied = 0
        rejected = 0
        async with self._write_lock:
            conn = await self._connect()
            try:
                await conn.execute("BEGIN IMMEDIATE")
                for edit in run_input.edits:
                    if isinstance(edit, Delete):
                        cur = await conn.execute(
                            "UPDATE observations SET archived_at = ? "
                            "WHERE id = ? AND user_id = ? AND agent_id = ? "
                            "  AND archived_at IS NULL",
                            (now, edit.source_id, run_input.user_id, run_input.agent_id),
                        )
                        if cur.rowcount:
                            deletes_applied += cur.rowcount
                        else:
                            rejected += 1
                    elif isinstance(edit, Replace):
                        source = await _read_active_observation(
                            conn, run_input.user_id, run_input.agent_id, edit.source_id
                        )
                        if source is None:
                            rejected += 1
                            continue
                        await conn.execute(
                            "UPDATE observations SET archived_at = ? "
                            "WHERE id = ? AND user_id = ? AND agent_id = ? "
                            "  AND archived_at IS NULL",
                            (now, edit.source_id, run_input.user_id, run_input.agent_id),
                        )
                        await conn.execute(
                            "INSERT INTO observations "
                            "(user_id, agent_id, text, priority, observation_date, "
                            " referenced_date, source_round_ids, created_at, archived_at) "
                            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL)",
                            (
                                run_input.user_id,
                                run_input.agent_id,
                                edit.text,
                                source.priority,
                                now,
                                source.referenced_date,
                                json.dumps(list(source.source_round_ids)),
                                now,
                            ),
                        )
                        replaces_applied += 1
                    elif isinstance(edit, Merge):
                        if not edit.source_ids:
                            rejected += 1
                            continue
                        sources = await _read_active_observations(
                            conn, run_input.user_id, run_input.agent_id, edit.source_ids
                        )
                        if not sources:
                            rejected += 1
                            continue
                        placeholders = ",".join("?" for _ in edit.source_ids)
                        await conn.execute(
                            "UPDATE observations SET archived_at = ? "
                            f"WHERE id IN ({placeholders}) AND user_id = ? AND agent_id = ? "
                            "  AND archived_at IS NULL",
                            (now, *edit.source_ids, run_input.user_id, run_input.agent_id),
                        )
                        priority = _max_priority(s.priority for s in sources)
                        merged_round_ids = sorted(
                            {rid for s in sources for rid in s.source_round_ids}
                        )
                        referenced = max(
                            (s.referenced_date for s in sources if s.referenced_date is not None),
                            default=None,
                        )
                        await conn.execute(
                            "INSERT INTO observations "
                            "(user_id, agent_id, text, priority, observation_date, "
                            " referenced_date, source_round_ids, created_at, archived_at) "
                            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL)",
                            (
                                run_input.user_id,
                                run_input.agent_id,
                                edit.text,
                                priority,
                                now,
                                referenced,
                                json.dumps(merged_round_ids),
                                now,
                            ),
                        )
                        merges_applied += 1
                await conn.commit()
            finally:
                await conn.close()
        return ObservationCounts(
            merges_applied=merges_applied,
            replaces_applied=replaces_applied,
            deletes_applied=deletes_applied,
            rejected=rejected,
        )

    # ------------------------------------------------------------------
    # Watermark.
    # ------------------------------------------------------------------

    async def read_watermark(
        self, user_id: str, agent_id: str, thread_key: str | None
    ) -> ObservationRunWatermark | None:
        conn = await self._connect()
        try:
            if thread_key is None:
                cur = await conn.execute(
                    "SELECT last_processed_sequence, last_run_at, last_run_status "
                    "FROM observation_runs "
                    "WHERE user_id = ? AND agent_id = ? AND thread_key IS NULL",
                    (user_id, agent_id),
                )
            else:
                cur = await conn.execute(
                    "SELECT last_processed_sequence, last_run_at, last_run_status "
                    "FROM observation_runs "
                    "WHERE user_id = ? AND agent_id = ? AND thread_key = ?",
                    (user_id, agent_id, thread_key),
                )
            row = await cur.fetchone()
        finally:
            await conn.close()
        if row is None:
            return None
        return ObservationRunWatermark(
            user_id=user_id,
            agent_id=agent_id,
            thread_key=thread_key,
            last_processed_sequence=int(row[0]),
            last_run_at=int(row[1]),
            last_run_status=_coerce_status(row[2]),
        )

    async def advance_watermark(
        self,
        *,
        user_id: str,
        agent_id: str,
        thread_key: str | None,
        last_processed_sequence: int,
        last_run_status: Literal["ok", "error", "empty"],
    ) -> None:
        now = self._now_fn()
        async with self._write_lock:
            conn = await self._connect()
            try:
                await conn.execute("BEGIN IMMEDIATE")
                # SQLite treats NULL primary-key columns as distinct, so an
                # explicit DELETE-then-INSERT is the cleanest way to keep a
                # single coherent watermark for `thread_key IS NULL`. For a
                # non-null thread_key the upsert via primary key conflict
                # works as usual.
                if thread_key is None:
                    await conn.execute(
                        "DELETE FROM observation_runs "
                        "WHERE user_id = ? AND agent_id = ? AND thread_key IS NULL",
                        (user_id, agent_id),
                    )
                    await conn.execute(
                        "INSERT INTO observation_runs "
                        "(user_id, agent_id, thread_key, last_processed_sequence, "
                        " last_run_at, last_run_status) "
                        "VALUES (?, ?, NULL, ?, ?, ?)",
                        (user_id, agent_id, last_processed_sequence, now, last_run_status),
                    )
                else:
                    await conn.execute(
                        "INSERT INTO observation_runs "
                        "(user_id, agent_id, thread_key, last_processed_sequence, "
                        " last_run_at, last_run_status) "
                        "VALUES (?, ?, ?, ?, ?, ?) "
                        "ON CONFLICT(user_id, agent_id, thread_key) "
                        "DO UPDATE SET last_processed_sequence = excluded.last_processed_sequence, "
                        "              last_run_at = excluded.last_run_at, "
                        "              last_run_status = excluded.last_run_status",
                        (
                            user_id,
                            agent_id,
                            thread_key,
                            last_processed_sequence,
                            now,
                            last_run_status,
                        ),
                    )
                await conn.commit()
            finally:
                await conn.close()


async def _read_active_observation(
    conn: aiosqlite.Connection, user_id: str, agent_id: str, row_id: int
) -> Observation | None:
    cur = await conn.execute(
        "SELECT id, text, priority, observation_date, referenced_date, "
        "       source_round_ids, created_at, archived_at "
        "FROM observations "
        "WHERE id = ? AND user_id = ? AND agent_id = ? AND archived_at IS NULL",
        (row_id, user_id, agent_id),
    )
    row = await cur.fetchone()
    if row is None:
        return None
    return Observation(
        id=int(row[0]),
        user_id=user_id,
        agent_id=agent_id,
        text=row[1],
        priority=_coerce_priority(row[2]),
        observation_date=int(row[3]),
        referenced_date=int(row[4]) if row[4] is not None else None,
        source_round_ids=tuple(json.loads(row[5])) if row[5] else (),
        created_at=int(row[6]),
        archived_at=int(row[7]) if row[7] is not None else None,
    )


async def _read_active_observations(
    conn: aiosqlite.Connection, user_id: str, agent_id: str, ids: Sequence[int]
) -> list[Observation]:
    placeholders = ",".join("?" for _ in ids)
    cur = await conn.execute(
        "SELECT id, text, priority, observation_date, referenced_date, "
        "       source_round_ids, created_at, archived_at "
        "FROM observations "
        f"WHERE id IN ({placeholders}) AND user_id = ? AND agent_id = ? "
        "  AND archived_at IS NULL",
        (*ids, user_id, agent_id),
    )
    rows = await cur.fetchall()
    return [
        Observation(
            id=int(row[0]),
            user_id=user_id,
            agent_id=agent_id,
            text=row[1],
            priority=_coerce_priority(row[2]),
            observation_date=int(row[3]),
            referenced_date=int(row[4]) if row[4] is not None else None,
            source_round_ids=tuple(json.loads(row[5])) if row[5] else (),
            created_at=int(row[6]),
            archived_at=int(row[7]) if row[7] is not None else None,
        )
        for row in rows
    ]


def _coerce_priority(value: str) -> ObservationPriority:
    if value not in _PRIORITY_ORDER:
        raise ValueError(f"Corrupted priority {value!r} in observations row")
    return value


def _coerce_status(value: str) -> Literal["ok", "error", "empty"]:
    if value not in ("ok", "error", "empty"):
        raise ValueError(f"Corrupted last_run_status {value!r} in observation_runs row")
    return cast('Literal["ok", "error", "empty"]', value)


def _max_priority(priorities: Iterable[ObservationPriority]) -> ObservationPriority:
    best: ObservationPriority = "low"
    for p in priorities:
        if _PRIORITY_ORDER[p] > _PRIORITY_ORDER[best]:
            best = p
    return best
