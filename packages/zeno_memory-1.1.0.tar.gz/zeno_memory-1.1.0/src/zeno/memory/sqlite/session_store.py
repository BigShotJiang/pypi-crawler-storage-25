"""`SqliteSessionStore` — durable `(user_id, channel, thread_key) → sdk_session_id`.

On restart, `get_or_create` returns the previously-minted SDK session id,
allowing the user's `agent_handler` to pass it to `ClaudeAgentOptions(resume=...)`.
If the SDK session id is no longer valid server-side, resumption fails —
the handler is expected to fall back to minting a fresh session. We do
not currently verify the id before returning it; that cost belongs to
the handler, which already has an SDK client open.
"""

from __future__ import annotations

import contextlib
import os
import time
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING, Any

import aiosqlite
from zeno.memory.protocols import SessionRecord
from zeno.memory.sqlite.migrate import configure_connection, ensure_schema

if TYPE_CHECKING:
    from pathlib import Path


class SqliteSessionStore:
    """Durable, single-writer session store backed by aiosqlite + WAL mode."""

    def __init__(self, path: str | Path) -> None:
        self._path = str(path)
        self._initialized = False

    async def _connect(self) -> aiosqlite.Connection:
        conn = await aiosqlite.connect(self._path)
        await configure_connection(conn)
        if not self._initialized:
            await ensure_schema(conn, path=self._path)
            self._chmod_secure()
            self._initialized = True
        return conn

    def _chmod_secure(self) -> None:
        """Best-effort: restrict DB file permissions to owner-only (R33/security).

        Non-fatal when the filesystem (Windows, remote mounts) rejects the
        call. The session id is treated as secret-grade data; deployments
        on those filesystems should layer their own protection.
        """
        with contextlib.suppress(OSError):
            os.chmod(self._path, 0o600)

    async def get(self, user_id: str, channel: str, thread_key: str | None) -> SessionRecord | None:
        conn = await self._connect()
        try:
            cur = await conn.execute(
                "SELECT user_id, channel, thread_key, sdk_session_id, "
                "       created_at, updated_at, last_summary "
                "FROM sessions WHERE user_id = ? AND channel = ? "
                "  AND thread_key IS ?",
                (user_id, channel, thread_key),
            )
            row = await cur.fetchone()
            if row is None:
                return None
            return SessionRecord(
                user_id=row[0],
                channel=row[1],
                thread_key=row[2],
                sdk_session_id=row[3],
                created_at=int(row[4]),
                updated_at=int(row[5]),
                last_summary=row[6],
            )
        finally:
            await conn.close()

    async def get_or_create(
        self,
        user_id: str,
        channel: str,
        thread_key: str | None,
        sdk_session_id_factory: Callable[[], Awaitable[str]] | Callable[[], str],
    ) -> SessionRecord:
        existing = await self.get(user_id, channel, thread_key)
        if existing is not None:
            return existing

        minted: Any = sdk_session_id_factory()
        if hasattr(minted, "__await__"):
            minted = await minted
        session_id: str = str(minted)

        now = int(time.time())
        conn = await self._connect()
        try:
            await conn.execute(
                "INSERT OR IGNORE INTO sessions "
                "  (user_id, channel, thread_key, sdk_session_id, created_at, "
                "   updated_at, last_summary) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (user_id, channel, thread_key, session_id, now, now, None),
            )
            await conn.commit()
        finally:
            await conn.close()

        # Re-read — a racing writer may have inserted first; returning the
        # authoritative row keeps the contract simple.
        fetched = await self.get(user_id, channel, thread_key)
        assert fetched is not None
        return fetched

    async def touch(self, record: SessionRecord, summary: str | None = None) -> None:
        now = int(time.time())
        conn = await self._connect()
        try:
            await conn.execute(
                "UPDATE sessions SET updated_at = ?, "
                "       last_summary = COALESCE(?, last_summary) "
                "WHERE user_id = ? AND channel = ? AND thread_key IS ?",
                (now, summary, record.user_id, record.channel, record.thread_key),
            )
            await conn.commit()
        finally:
            await conn.close()
