-- Per-`(user_id, agent_id, thread_key)` watermark for the L4 Observer.
--
-- Records the highest `conversations.sequence` already processed so the
-- Observer's next run only sees genuinely new rounds. `thread_key` is
-- nullable to match the `conversations` table — SQLite treats NULL PK
-- columns as distinct rows, so applications without thread keys still
-- get a single coherent watermark per `(user_id, agent_id)` pair.
--
-- `last_run_status` lets dashboards distinguish a successful no-op
-- (`empty` — nothing to observe) from a successful write (`ok`) and
-- from a failure (`error`) without joining against an audit table.
CREATE TABLE IF NOT EXISTS observation_runs (
    user_id                  TEXT    NOT NULL,
    agent_id                 TEXT    NOT NULL,
    thread_key               TEXT,
    last_processed_sequence  INTEGER NOT NULL,
    last_run_at              INTEGER NOT NULL,
    last_run_status          TEXT    NOT NULL CHECK (last_run_status IN ('ok', 'error', 'empty')),
    PRIMARY KEY (user_id, agent_id, thread_key)
);
