-- Per-`(user_id, agent_id)` typed key-value working memory (R2, R3).
--
-- Each row is one named field on an agent's working-memory card. The
-- composite primary key `(user_id, agent_id, field_name)` lets `update`
-- upsert with `INSERT ... ON CONFLICT DO UPDATE` and lets `clear` /
-- `get` filter by the `(user_id, agent_id)` prefix using SQLite's
-- leftmost-prefix index coverage.
CREATE TABLE IF NOT EXISTS working_memory (
    user_id      TEXT    NOT NULL,
    agent_id     TEXT    NOT NULL,
    field_name   TEXT    NOT NULL,
    value        TEXT    NOT NULL,
    last_updated INTEGER NOT NULL,
    created_at   INTEGER NOT NULL,
    PRIMARY KEY (user_id, agent_id, field_name)
);

-- The PK already covers `(user_id, agent_id)` prefix scans, but we
-- materialize an explicit index so the `get` path's intent is greppable
-- and so future migrations adding a non-`field_name` leading column
-- (e.g., a `tenant_id`) don't silently drop coverage for `get`.
CREATE INDEX IF NOT EXISTS ix_working_memory_user_agent
    ON working_memory (user_id, agent_id);
