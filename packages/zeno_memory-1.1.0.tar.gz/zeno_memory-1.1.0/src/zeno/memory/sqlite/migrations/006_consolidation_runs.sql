-- Audit log for `MemoryConsolidator` runs.
--
-- One row per consolidate_user() call, regardless of outcome. Even no-op
-- runs (empty batch or judge accepted zero proposals) record a row with
-- zero counts so an operator can see the loop is making forward progress
-- and reason about per-user cadence without grepping logs.
--
-- `proposals_json` and `verdicts_json` capture the LLM-generated structured
-- output from the proposer and judge phases respectively, so a failed run
-- can be reproduced from the audit row alone. We deliberately do NOT
-- persist the adversary's challenge — its only consumer is the judge, and
-- storing three copies of the same memory text bloats the audit table.
CREATE TABLE IF NOT EXISTS consolidation_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL UNIQUE,
    user_id TEXT NOT NULL,
    started_at INTEGER NOT NULL,
    finished_at INTEGER,
    proposals_generated INTEGER NOT NULL DEFAULT 0,
    proposals_accepted INTEGER NOT NULL DEFAULT 0,
    merges_applied INTEGER NOT NULL DEFAULT 0,
    replaces_applied INTEGER NOT NULL DEFAULT 0,
    deletes_applied INTEGER NOT NULL DEFAULT 0,
    proposals_json TEXT,
    verdicts_json TEXT,
    error TEXT
);

-- Per-user history scan for "when did consolidation last run for alice?".
CREATE INDEX IF NOT EXISTS ix_consolidation_runs_user_started
    ON consolidation_runs (user_id, started_at DESC);
