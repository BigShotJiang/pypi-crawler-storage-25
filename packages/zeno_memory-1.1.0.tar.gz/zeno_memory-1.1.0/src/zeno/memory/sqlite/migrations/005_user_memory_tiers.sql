-- Tiered memory: every fact lives at a tier, ages on access, and can be archived.
--
-- `tier` is one of 'short' | 'long' | 'permanent'. Auto-extracted facts default
-- to 'short'; explicit user `remember(...)` defaults to 'long'; consolidation
-- and the maintenance loop promote between tiers based on hit_count + idle time.
-- 'permanent' is a terminal tier and is never decayed.
--
-- `last_accessed_at` is a unix timestamp (seconds) updated on every search hit.
-- `hit_count` is incremented alongside.
--
-- `archived_at` is NULL for active rows. The maintenance loop sets it to a unix
-- timestamp when a row decays past its tier's TTL without enough hits to be
-- promoted. Archived rows are excluded from search but retained for audit /
-- recovery until the optional prune step hard-deletes them.
ALTER TABLE user_memories ADD COLUMN tier TEXT NOT NULL DEFAULT 'long';
ALTER TABLE user_memories ADD COLUMN last_accessed_at INTEGER NOT NULL DEFAULT 0;
ALTER TABLE user_memories ADD COLUMN hit_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE user_memories ADD COLUMN archived_at INTEGER;

-- Backfill pre-existing rows with a fresh idle clock starting at migration
-- time. Without this, rows whose `created_at` is older than long_idle_seconds
-- (default 30d) would be archived in a single sweep on the first maintenance
-- tick after upgrade — a silent data-loss event. The guard only touches
-- DEFAULT-0 rows, so the statement is idempotent across re-runs.
UPDATE user_memories
   SET last_accessed_at = CAST(strftime('%s', 'now') AS INTEGER)
 WHERE last_accessed_at = 0;

-- Search filters by archived_at IS NULL on every query; index it together with
-- user_id so the planner can use a single covering scan.
CREATE INDEX IF NOT EXISTS ix_user_memories_user_archived
    ON user_memories (user_id, archived_at);

-- The decay sweep visits rows by tier and idle window. Index supports that scan.
CREATE INDEX IF NOT EXISTS ix_user_memories_tier_accessed
    ON user_memories (tier, last_accessed_at);
