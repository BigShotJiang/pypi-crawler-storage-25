-- Per-`(user_id, agent_id)` observation log written by the L4 Observer
-- and edited by the L4 Reflector.
--
-- One row per durable observation. The Observer extracts each row from a
-- window of conversation rounds; the Reflector compacts the log via
-- `Merge` / `Replace` / `Delete` edits. Soft-delete via `archived_at` so
-- audit trails survive without bloating the active-row scan path used
-- by the renderer.
--
-- Two date columns by design (LongMemEval § 5.1 — `When-Did-X-Happen`
-- queries lift 6.8-11.3% with explicit temporal indexing):
--
--   * `observation_date` — when the Observer wrote the row. Always set.
--   * `referenced_date`  — the date the observed event happened. Often
--                          equal to `observation_date`; distinct when a
--                          turn references the past ("last Friday I …").
--
-- `source_round_ids` is a JSON array of `conversations.sequence` ids,
-- mirroring the JSON-as-TEXT precedent set by `tool_calls_json` in
-- migration 004.
CREATE TABLE IF NOT EXISTS observations (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id          TEXT    NOT NULL,
    agent_id         TEXT    NOT NULL,
    text             TEXT    NOT NULL,
    priority         TEXT    NOT NULL CHECK (priority IN ('high', 'medium', 'low')),
    observation_date INTEGER NOT NULL,
    referenced_date  INTEGER,
    source_round_ids TEXT    NOT NULL DEFAULT '[]',
    created_at       INTEGER NOT NULL,
    archived_at      INTEGER
);

-- Renderer hot path: list active rows for one `(user_id, agent_id)` pair
-- ordered by referenced_date (or observation_date when null). A partial
-- index on `archived_at IS NULL` keeps the index small once a long-lived
-- agent accumulates many archived rows.
CREATE INDEX IF NOT EXISTS ix_observations_active
    ON observations (user_id, agent_id, referenced_date, observation_date)
    WHERE archived_at IS NULL;

-- Audit-trail scan: "show me everything we ever observed for alice/root,
-- archived or not". Cheap leftmost-prefix index, used by audit tooling
-- not by the renderer.
CREATE INDEX IF NOT EXISTS ix_observations_user_agent
    ON observations (user_id, agent_id);
