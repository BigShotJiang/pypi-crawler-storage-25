"""`SqliteUserMemoryStore` — deterministic baseline for tests and bootstrapping.

**Not recommended for production.** Search is `LIKE %token%` keyword
matching with whitespace tokenization; there is no embedding, no stemming,
no vector scoring. Use `VectorBackedUserMemoryStore` wrapping a
`ChromaKnowledgeStore` or `QdrantKnowledgeStore` in production.

Why we ship it anyway:
  - Every memory test should be able to run with zero extra dependencies.
  - The contract (`add`/`search` with strict user-id scoping) is
    exercisable with determinism, which matters for S7.
  - Tier-aware bookkeeping (last_accessed_at, hit_count, archived_at)
    runs against this store; vector-backed adapters do not yet support
    those columns and the maintenance loop only operates on this backend.
"""

from __future__ import annotations

import json
import re
import time
from collections.abc import Callable, Sequence
from typing import TYPE_CHECKING, Any, cast

import aiosqlite
from zeno.memory.protocols import MemoryHit, MemoryTier
from zeno.memory.sqlite.migrate import configure_connection, ensure_schema

if TYPE_CHECKING:
    from pathlib import Path

    from zeno.memory.consolidation import (
        ConsolidationCandidate,
        ConsolidationCounts,
        ConsolidationRunInput,
    )


_TOKEN_RE = re.compile(r"[A-Za-z0-9]+")
_TIER_ORDER: dict[MemoryTier, int] = {"short": 0, "long": 1, "permanent": 2}

# `search` binds 2 * len(tokens) + 2 host parameters per query. SQLite's
# default `SQLITE_MAX_VARIABLE_NUMBER` is 999 on builds older than 3.32 —
# capping at 64 keeps us well under any reasonable limit and shields the
# query planner from a degenerate OR-tree on a query the keyword scorer
# could never use anyway.
_MAX_SEARCH_TOKENS = 64


def _tokens(query: str) -> list[str]:
    return [tok.lower() for tok in _TOKEN_RE.findall(query) if tok][:_MAX_SEARCH_TOKENS]


class SqliteUserMemoryStore:
    """Keyword-rank user memory store with tier-aware bookkeeping (baseline)."""

    def __init__(
        self,
        path: str | Path,
        *,
        now_fn: Callable[[], int] | None = None,
    ) -> None:
        self._path = str(path)
        self._initialized = False
        self._now_fn: Callable[[], int] = now_fn or (lambda: int(time.time()))

    async def _connect(self) -> aiosqlite.Connection:
        conn = await aiosqlite.connect(self._path)
        await configure_connection(conn)
        if not self._initialized:
            await ensure_schema(conn, path=self._path)
            self._initialized = True
        return conn

    async def add(
        self,
        user_id: str,
        text: str,
        meta: dict[str, Any] | None = None,
        *,
        tier: MemoryTier = "long",
    ) -> None:
        """Insert, de-duplicating on the same active text for one user.

        On dedup the row's metadata is updated, its tier is **escalated only**
        (``permanent`` over ``short`` upgrades, ``short`` over ``long`` does
        not downgrade), and ``last_accessed_at`` is refreshed so a re-extracted
        fact does not appear idle to the decay sweep. ``hit_count`` is *not*
        bumped — that counter tracks reads.

        Archived rows are NOT considered for dedup: a previously archived
        text re-added by the extractor produces a fresh active row.
        """
        if tier not in _TIER_ORDER:
            raise ValueError(f"Invalid MemoryTier {tier!r}; expected one of {list(_TIER_ORDER)}")
        now = self._now_fn()
        meta_json = json.dumps(meta) if meta else None
        conn = await self._connect()
        try:
            # `BEGIN IMMEDIATE` takes the write lock up-front so the
            # SELECT-then-INSERT/UPDATE pair is atomic against concurrent
            # writers. Without it, two extractor tasks racing on the same
            # `(user_id, text)` could both observe `existing = None` and
            # both insert, breaking the dedup invariant.
            await conn.execute("BEGIN IMMEDIATE")
            cur = await conn.execute(
                "SELECT id, tier FROM user_memories "
                "WHERE user_id = ? AND text = ? AND archived_at IS NULL "
                "LIMIT 1",
                (user_id, text),
            )
            existing = await cur.fetchone()
            if existing is not None:
                existing_id, existing_tier = existing
                new_tier = _max_tier(existing_tier, tier)
                await conn.execute(
                    "UPDATE user_memories "
                    "SET meta = COALESCE(?, meta), tier = ?, last_accessed_at = ? "
                    "WHERE id = ?",
                    (meta_json, new_tier, now, existing_id),
                )
            else:
                # `last_accessed_at = now` (not 0) so a fresh fact's idle
                # clock starts at insert time. The DEFAULT-0 only ever
                # marks rows from before migration 005; the CASE in
                # `list_decay_candidates` ages those from `created_at`.
                await conn.execute(
                    "INSERT INTO user_memories "
                    "(user_id, text, meta, created_at, tier, last_accessed_at, hit_count) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (user_id, text, meta_json, now, tier, now, 0),
                )
            await conn.commit()
        finally:
            await conn.close()

    async def search(self, user_id: str, query: str, k: int = 5) -> list[MemoryHit]:
        if k < 1:
            raise ValueError(f"k must be >= 1; got {k}")
        tokens = _tokens(query)
        if not tokens:
            return []

        # Build a SUM of LIKE-matches per row, ordered by match count then recency.
        like_clauses = " + ".join(
            "(CASE WHEN lower(text) LIKE ? THEN 1 ELSE 0 END)" for _ in tokens
        )
        sql = (
            f"SELECT id, text, meta, created_at, tier, hit_count, {like_clauses} AS score "
            "FROM user_memories "
            "WHERE user_id = ? AND archived_at IS NULL "
            f"  AND ({' OR '.join(['lower(text) LIKE ?'] * len(tokens))}) "
            "ORDER BY score DESC, created_at DESC "
            "LIMIT ?"
        )
        like_params = [f"%{tok}%" for tok in tokens]
        params = (*like_params, user_id, *like_params, k)

        conn = await self._connect()
        try:
            cur = await conn.execute(sql, params)
            rows = await cur.fetchall()

            if rows:
                hit_ids = [row[0] for row in rows]
                placeholders = ",".join("?" for _ in hit_ids)
                now = self._now_fn()
                await conn.execute(
                    "UPDATE user_memories "
                    "SET last_accessed_at = ?, hit_count = hit_count + 1 "
                    f"WHERE id IN ({placeholders})",
                    (now, *hit_ids),
                )
                await conn.commit()
        finally:
            await conn.close()

        hits: list[MemoryHit] = []
        for _id, text, meta_json, _created_at, tier, hit_count, score in rows:
            meta: dict[str, Any] = json.loads(meta_json) if meta_json else {}
            # DB-truth fields are surfaced on `meta` so downstream callers
            # (recall, auto-inject, consolidator) can reason about the row
            # without a second round-trip. The synthesized tier/hit_count
            # are written *last* so user-supplied meta cannot shadow them
            # — the DB row is the source of truth.
            enriched = {**meta, "tier": tier, "hit_count": hit_count}
            hits.append(MemoryHit(text=text, score=float(score), meta=enriched))
        return hits

    # ------------------------------------------------------------------
    # Maintenance helpers — used by `MemoryMaintenance`.
    # ------------------------------------------------------------------

    async def list_decay_candidates(
        self,
        *,
        tier: MemoryTier,
        idle_seconds: int,
        now: int | None = None,
    ) -> list[_DecayCandidate]:
        """Return active rows in *tier* idle for at least *idle_seconds*.

        Rows where ``last_accessed_at`` is 0 (never read) are aged from
        ``created_at`` instead, so a freshly inserted ``short`` fact still has
        a chance to be promoted before being archived.

        Raises ``ValueError`` if *tier* is ``"permanent"`` — the permanent tier
        is terminal and never decays. This guard prevents the maintenance loop
        from mistakenly archiving permanent rows.
        """
        if tier == "permanent":
            raise ValueError(
                "permanent rows are never eligible for decay; the permanent tier is terminal"
            )
        cutoff = (now if now is not None else self._now_fn()) - idle_seconds
        conn = await self._connect()
        try:
            cur = await conn.execute(
                "SELECT id, user_id, hit_count "
                "FROM user_memories "
                "WHERE tier = ? AND archived_at IS NULL "
                "  AND CASE WHEN last_accessed_at = 0 THEN created_at "
                "           ELSE last_accessed_at END <= ?",
                (tier, cutoff),
            )
            rows = await cur.fetchall()
        finally:
            await conn.close()
        return [_DecayCandidate(id=row[0], user_id=row[1], hit_count=row[2]) for row in rows]

    async def promote(self, ids: Sequence[int], to_tier: MemoryTier) -> int:
        """Escalate rows to *to_tier* — never downgrades. Returns rows touched.

        Rows whose current tier is at or above *to_tier* (per ``_TIER_ORDER``)
        are skipped, so a ``permanent`` row passed by mistake is never
        demoted. Archived rows are also skipped.
        """
        if not ids:
            return 0
        if to_tier not in _TIER_ORDER:
            raise ValueError(f"Invalid MemoryTier {to_tier!r}; expected one of {list(_TIER_ORDER)}")
        target_rank = _TIER_ORDER[to_tier]
        # Only promote rows whose current tier sits strictly below target_rank.
        # SQLite has no rank function, so enumerate the lower tiers explicitly.
        lower_tiers = [t for t, rank in _TIER_ORDER.items() if rank < target_rank]
        if not lower_tiers:
            # `to_tier` is "short"; nothing is below it. Refuse rather than
            # accept a no-op that hides a caller bug.
            return 0
        id_placeholders = ",".join("?" for _ in ids)
        tier_placeholders = ",".join("?" for _ in lower_tiers)
        conn = await self._connect()
        try:
            cur = await conn.execute(
                f"UPDATE user_memories SET tier = ? "
                f"WHERE id IN ({id_placeholders}) "
                f"  AND tier IN ({tier_placeholders}) "
                f"  AND archived_at IS NULL",
                (to_tier, *ids, *lower_tiers),
            )
            await conn.commit()
            return cur.rowcount or 0
        finally:
            await conn.close()

    async def archive(self, ids: Sequence[int], *, now: int | None = None) -> int:
        """Soft-delete rows by setting *archived_at*. Returns rows touched.

        Already-archived rows are skipped — re-archiving must not refresh
        ``archived_at`` because that would extend the prune-eligibility
        window indefinitely under repeated sweeps.
        """
        if not ids:
            return 0
        ts = now if now is not None else self._now_fn()
        placeholders = ",".join("?" for _ in ids)
        conn = await self._connect()
        try:
            cur = await conn.execute(
                f"UPDATE user_memories SET archived_at = ? "
                f"WHERE id IN ({placeholders}) AND archived_at IS NULL",
                (ts, *ids),
            )
            await conn.commit()
            return cur.rowcount or 0
        finally:
            await conn.close()

    async def list_prune_candidates(
        self,
        *,
        archived_before: int,
    ) -> list[int]:
        """Return ids of rows archived before *archived_before* (unix seconds)."""
        conn = await self._connect()
        try:
            cur = await conn.execute(
                "SELECT id FROM user_memories WHERE archived_at IS NOT NULL AND archived_at < ?",
                (archived_before,),
            )
            rows = await cur.fetchall()
        finally:
            await conn.close()
        return [row[0] for row in rows]

    async def hard_delete(self, ids: Sequence[int]) -> int:
        """Permanently remove archived rows. Returns rows touched.

        Only rows where ``archived_at IS NOT NULL`` are deleted. Callers
        normally pass ids straight from ``list_prune_candidates`` (which
        already filters by ``archived_at IS NOT NULL``); the guard exists
        so a misconfigured caller can't destroy active facts in one call.
        """
        if not ids:
            return 0
        placeholders = ",".join("?" for _ in ids)
        conn = await self._connect()
        try:
            cur = await conn.execute(
                "DELETE FROM user_memories "
                f"WHERE id IN ({placeholders}) AND archived_at IS NOT NULL",
                tuple(ids),
            )
            await conn.commit()
            return cur.rowcount or 0
        finally:
            await conn.close()

    # ------------------------------------------------------------------
    # Consolidation helpers — used by `MemoryConsolidator`.
    # ------------------------------------------------------------------

    async def list_for_consolidation(
        self,
        user_id: str,
        *,
        tier: MemoryTier,
        limit: int,
    ) -> list[ConsolidationCandidate]:
        """Return up to *limit* active rows for *user_id* in *tier*.

        Ordered by ``last_accessed_at DESC`` so a bounded sweep visits the
        currently-relevant set first; truly stale rows are decayed by the
        maintenance loop, not the consolidator.
        """
        if limit < 1:
            raise ValueError(f"limit must be >= 1; got {limit}")
        if tier not in _TIER_ORDER:
            raise ValueError(f"Invalid MemoryTier {tier!r}; expected one of {list(_TIER_ORDER)}")
        conn = await self._connect()
        try:
            cur = await conn.execute(
                "SELECT id, text, hit_count "
                "FROM user_memories "
                "WHERE user_id = ? AND tier = ? AND archived_at IS NULL "
                "ORDER BY last_accessed_at DESC "
                "LIMIT ?",
                (user_id, tier, limit),
            )
            rows = await cur.fetchall()
        finally:
            await conn.close()
        from zeno.memory.consolidation import ConsolidationCandidate

        return [ConsolidationCandidate(id=row[0], text=row[1], hit_count=row[2]) for row in rows]

    async def apply_consolidation(self, run: ConsolidationRunInput) -> ConsolidationCounts:
        """Atomically apply an edit batch and write the audit row.

        All three verbs (``merge``, ``replace``, ``delete``) plus the
        ``consolidation_runs`` row commit in a single transaction. A
        ``BEGIN IMMEDIATE`` takes the write lock up-front so concurrent
        ``add()`` callers can't insert against the source set mid-apply.

        Source rows are *archived* rather than hard-deleted so a buggy
        proposer can be unwound by inspecting the audit row and re-inserting
        from text. ``hard_delete`` remains a separate maintenance step.

        ``replace`` and ``merge`` insert the new fact at the same tier as
        the (highest-tier) source row, so consolidation never silently
        downgrades a permanent fact.

        Idempotent on no-change: if all three edit lists are empty, only
        the audit row lands. Counts in the returned tuple reflect the
        rows actually mutated, not the sizes of the input lists.
        """
        # Local import: edit types live in `consolidation.py`, which
        # imports the store under TYPE_CHECKING. Keeping this lazy avoids
        # the runtime cycle.
        from zeno.memory.consolidation import ConsolidationCounts

        now = self._now_fn()
        conn = await self._connect()
        try:
            await conn.execute("BEGIN IMMEDIATE")

            merges_applied = 0
            replaces_applied = 0
            deletes_applied = 0

            for delete in run.deletes:
                cur = await conn.execute(
                    "UPDATE user_memories SET archived_at = ? "
                    "WHERE id = ? AND user_id = ? AND archived_at IS NULL",
                    (now, delete.source_id, run.user_id),
                )
                deletes_applied += cur.rowcount or 0

            for replace in run.replaces:
                tier = await _read_active_tier(conn, run.user_id, replace.source_id)
                if tier is None:
                    # Source already archived — treat the edit as skipped
                    # rather than silently inserting an orphan row.
                    continue
                await conn.execute(
                    "UPDATE user_memories SET archived_at = ? "
                    "WHERE id = ? AND user_id = ? AND archived_at IS NULL",
                    (now, replace.source_id, run.user_id),
                )
                await conn.execute(
                    "INSERT INTO user_memories "
                    "(user_id, text, meta, created_at, tier, last_accessed_at, hit_count) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (
                        run.user_id,
                        replace.text,
                        json.dumps({"source": "consolidator", "run_id": run.run_id}),
                        now,
                        tier,
                        now,
                        0,
                    ),
                )
                replaces_applied += 1

            for merge in run.merges:
                if not merge.source_ids:
                    continue
                top_tier = await _read_max_active_tier(conn, run.user_id, merge.source_ids)
                if top_tier is None:
                    continue
                placeholders = ",".join("?" for _ in merge.source_ids)
                await conn.execute(
                    "UPDATE user_memories SET archived_at = ? "
                    f"WHERE id IN ({placeholders}) AND user_id = ? AND archived_at IS NULL",
                    (now, *merge.source_ids, run.user_id),
                )
                await conn.execute(
                    "INSERT INTO user_memories "
                    "(user_id, text, meta, created_at, tier, last_accessed_at, hit_count) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (
                        run.user_id,
                        merge.text,
                        json.dumps({"source": "consolidator", "run_id": run.run_id}),
                        now,
                        top_tier,
                        now,
                        0,
                    ),
                )
                merges_applied += 1

            await conn.execute(
                "INSERT INTO consolidation_runs "
                "(run_id, user_id, started_at, finished_at, proposals_generated, "
                " proposals_accepted, merges_applied, replaces_applied, deletes_applied, "
                " proposals_json, verdicts_json, error) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    run.run_id,
                    run.user_id,
                    run.started_at,
                    now,
                    run.proposals_generated,
                    run.proposals_accepted,
                    merges_applied,
                    replaces_applied,
                    deletes_applied,
                    run.proposals_json,
                    run.verdicts_json,
                    run.error,
                ),
            )
            await conn.commit()
        finally:
            await conn.close()
        return ConsolidationCounts(
            merges_applied=merges_applied,
            replaces_applied=replaces_applied,
            deletes_applied=deletes_applied,
        )


async def _read_active_tier(
    conn: aiosqlite.Connection, user_id: str, row_id: int
) -> MemoryTier | None:
    cur = await conn.execute(
        "SELECT tier FROM user_memories WHERE id = ? AND user_id = ? AND archived_at IS NULL",
        (row_id, user_id),
    )
    row = await cur.fetchone()
    if row is None:
        return None
    tier = row[0]
    if tier not in _TIER_ORDER:
        raise ValueError(f"Corrupted tier {tier!r} in user_memories row {row_id}")
    return cast("MemoryTier", tier)


async def _read_max_active_tier(
    conn: aiosqlite.Connection, user_id: str, ids: Sequence[int]
) -> MemoryTier | None:
    placeholders = ",".join("?" for _ in ids)
    cur = await conn.execute(
        f"SELECT tier FROM user_memories "
        f"WHERE id IN ({placeholders}) AND user_id = ? AND archived_at IS NULL",
        (*ids, user_id),
    )
    rows = await cur.fetchall()
    if not rows:
        return None
    best: MemoryTier = "short"
    for (tier,) in rows:
        if tier not in _TIER_ORDER:
            raise ValueError(f"Corrupted tier {tier!r} in user_memories")
        if _TIER_ORDER[tier] > _TIER_ORDER[best]:
            best = cast("MemoryTier", tier)
    return best


def _max_tier(a: str, b: MemoryTier) -> MemoryTier:
    """Return whichever tier sits higher in the lifecycle ordering.

    *b* is the caller's intended tier (typed). *a* is the existing DB row's
    tier — strings only because the migration writes them as TEXT. An
    unrecognized value in *a* indicates a corrupted row and is raised loudly
    rather than silently ranked at the bottom.
    """
    if a not in _TIER_ORDER:
        raise ValueError(f"Corrupted tier {a!r} in user_memories row")
    if b not in _TIER_ORDER:
        raise ValueError(f"Invalid MemoryTier {b!r}; expected one of {list(_TIER_ORDER)}")
    return b if _TIER_ORDER[b] > _TIER_ORDER[a] else a


class _DecayCandidate:
    """Decay sweep result row — identity is the row's primary key.

    Equality and hashing key on ``id`` only so that two snapshots of the
    same row taken at different times (e.g., before and after a stat
    update) compare equal and can coexist in a ``set``.
    """

    __slots__ = ("id", "user_id", "hit_count")

    def __init__(self, *, id: int, user_id: str, hit_count: int) -> None:
        self.id = id
        self.user_id = user_id
        self.hit_count = hit_count

    def __repr__(self) -> str:  # pragma: no cover - trivial
        return (
            f"_DecayCandidate(id={self.id!r}, user_id={self.user_id!r}, "
            f"hit_count={self.hit_count!r})"
        )

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, _DecayCandidate):
            return NotImplemented
        return self.id == other.id

    def __hash__(self) -> int:
        return hash(self.id)
