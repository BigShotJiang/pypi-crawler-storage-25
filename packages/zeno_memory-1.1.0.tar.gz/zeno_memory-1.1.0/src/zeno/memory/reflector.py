"""`Reflector` — compresses an active observation set via `Merge`/`Replace`/`Delete`.

The Reflector is the L4 twin of `MemoryConsolidator`: an LLM proposer
emits structured edits that an `ObservationStore.apply_edits` call
materialises atomically. v1 ships single-phase (proposer only) because
observations are short-lived and high-volume — running an adversary +
judge on every reflection would dominate the token bill. The
`adversary` and `judge` callables are kept as optional escalations for
deployments that need extra rigor.

Concurrency / failure posture:

- The Reflector is owned by the L4 `ObservationalMemory` orchestrator,
  which is single-flight per ``(user_id, agent_id)`` reflection window.
- `apply_edits` is the only mutating call; if any earlier phase fails,
  no rows move. The store wraps inserts + archives + audit row in one
  SQLite transaction.
- On any unhandled error in the proposer / adversary / judge phases the
  Reflector logs, emits ``MemoryReflected(error=True)``, and returns
  zero counts. The active set is unchanged so the next reflection
  window retries the same observations.
"""

from __future__ import annotations

import json
import logging
import time
import uuid
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING, Any

from zeno.memory._edits import (
    Edit,
    _dedupe_edits,
    _edit_to_dict,
    _parse_edits,
    _parse_top_level_object,
)
from zeno.memory.protocols import (
    Observation,
    ObservationCounts,
    ObservationRunInput,
)
from zeno.observability.events import MemoryReflected

if TYPE_CHECKING:
    from zeno.memory.protocols import ObservationStore

logger = logging.getLogger("zeno.memory.reflector")

LLMCallable = Callable[[str], Awaitable[str]]
"""Provider-agnostic LLM seam (mirrors `extractor.LLMCallable`)."""


DEFAULT_REFLECTOR_PROPOSER_PROMPT = """\
You are reviewing a user's stored observations and proposing edits that
improve recall quality. Output a JSON object with a single ``edits`` key
holding a JSON array of edit objects -- nothing else.

Each edit object MUST be one of:
  {{"verb": "merge", "source_ids": [<int>, <int>, ...], "text": "<combined observation>"}}
  {{"verb": "replace", "source_id": <int>, "text": "<rewritten observation>"}}
  {{"verb": "delete", "source_id": <int>}}

Rules:
- Only reference ids that appear in the observations below.
- Prefer ``merge`` for observations that say the same thing in different
  words, or that together describe one stable preference / fact.
- Prefer ``replace`` when one observation is strictly more precise than
  another it absorbs.
- Use ``delete`` for redundant, contradicted, or short-lived
  observations whose value has lapsed.
- Each id may appear in at most ONE edit. If you cannot decide, leave
  the observation alone.
- If nothing should change, return ``{{"edits": []}}``.

OBSERVATIONS:
{observations}

JSON object:"""


DEFAULT_REFLECTOR_ADVERSARY_PROMPT = """\
You are auditing proposed edits to a user's observation log. Identify
edits that would lose information, alter user-stated facts, or misuse
the merge/replace/delete verbs. Reply with a short prose critique --
no JSON. The next reviewer will read your critique alongside the
proposals.

OBSERVATIONS:
{observations}

PROPOSED EDITS:
{proposals_json}

Critique:"""


DEFAULT_REFLECTOR_JUDGE_PROMPT = """\
You are the final reviewer for an observation reflection run. Given the
active observations, the proposer's edits, and the adversary's
critique, decide which edits to accept. Output a JSON object with a
single ``verdicts`` key holding a JSON array of verdict objects --
nothing else.

Each verdict object MUST be:
  {{"index": <int>, "accept": <bool>}}

Where ``index`` is the 0-based position of the edit in the proposer's
array. Omit verdicts you cannot decide on; an omitted verdict is
treated as REJECT.

OBSERVATIONS:
{observations}

PROPOSED EDITS:
{proposals_json}

ADVERSARY CRITIQUE:
{adversary_critique}

JSON object:"""


class Reflector:
    """Single-phase observation compressor (with optional adversary/judge).

    Construction is cheap; reuse one instance across users and
    reflection windows. The Reflector does not own a loop — schedule
    `reflect` from `ObservationalMemory` after the observation block
    crosses the reflector threshold.
    """

    def __init__(
        self,
        *,
        store: ObservationStore,
        proposer: LLMCallable,
        adversary: LLMCallable | None = None,
        judge: LLMCallable | None = None,
        prompt_template: str = DEFAULT_REFLECTOR_PROPOSER_PROMPT,
        adversary_prompt: str = DEFAULT_REFLECTOR_ADVERSARY_PROMPT,
        judge_prompt: str = DEFAULT_REFLECTOR_JUDGE_PROMPT,
        tracer: Any = None,
        now_fn: Callable[[], int] | None = None,
    ) -> None:
        if (adversary is None) != (judge is None):
            raise ValueError(
                "adversary and judge must both be provided or both omitted; "
                "the 3-phase pipeline is all-or-nothing"
            )
        self._store = store
        self._proposer = proposer
        self._adversary = adversary
        self._judge = judge
        self._prompt_template = prompt_template
        self._adversary_prompt = adversary_prompt
        self._judge_prompt = judge_prompt
        self._tracer = tracer
        self._now_fn: Callable[[], int] = now_fn or (lambda: int(time.time()))

    async def reflect(self, *, user_id: str, agent_id: str) -> ObservationCounts:
        """Run one reflection pass for `(user_id, agent_id)`.

        Always emits a `MemoryReflected` event. On error, returns zero
        counts and emits with `error=True`; the store is not touched.
        """
        run_id = uuid.uuid4().hex[:12]
        started = time.monotonic()
        started_at = self._now_fn()

        proposals: list[Edit] = []
        accepted: list[Edit] = []
        error = False
        counts = ObservationCounts(
            merges_applied=0, replaces_applied=0, deletes_applied=0, rejected=0
        )

        try:
            observations = await self._store.list_active(user_id, agent_id)
            if observations:
                proposals = await self._propose(observations)
                if proposals and self._adversary is not None and self._judge is not None:
                    accepted = await self._adjudicate(observations, proposals)
                else:
                    accepted = list(proposals)
        except Exception:  # noqa: BLE001
            error = True
            logger.exception(
                "reflector pre-apply failed user_id=%s agent_id=%s run_id=%s",
                user_id,
                agent_id,
                run_id,
            )

        if not error and accepted:
            run_input = ObservationRunInput(
                run_id=run_id,
                user_id=user_id,
                agent_id=agent_id,
                edits=tuple(accepted),
                started_at=started_at,
            )
            try:
                counts = await self._store.apply_edits(run_input)
            except Exception:  # noqa: BLE001
                error = True
                logger.exception(
                    "reflector apply failed user_id=%s agent_id=%s run_id=%s",
                    user_id,
                    agent_id,
                    run_id,
                )
                counts = ObservationCounts(
                    merges_applied=0, replaces_applied=0, deletes_applied=0, rejected=0
                )

        event = MemoryReflected(
            run_id=run_id,
            user_id=user_id,
            proposals_generated=len(proposals),
            proposals_accepted=len(accepted),
            merges_applied=counts.merges_applied,
            replaces_applied=counts.replaces_applied,
            deletes_applied=counts.deletes_applied,
            duration_ms=int((time.monotonic() - started) * 1000),
            error=error,
        )
        self._emit(event)
        return counts

    # ------------------------------------------------------------------
    # Phases
    # ------------------------------------------------------------------

    async def _propose(self, observations: list[Observation]) -> list[Edit]:
        prompt = self._prompt_template.format(observations=_render_observations(observations))
        reply = await self._proposer(prompt)
        valid_ids = {o.id for o in observations}
        return _parse_edits(reply, valid_ids=valid_ids)

    async def _adjudicate(
        self, observations: list[Observation], proposals: list[Edit]
    ) -> list[Edit]:
        assert self._adversary is not None  # narrowed by caller
        assert self._judge is not None  # narrowed by caller
        proposals_json = json.dumps([_edit_to_dict(e) for e in proposals])
        adversary_prompt = self._adversary_prompt.format(
            observations=_render_observations(observations),
            proposals_json=proposals_json,
        )
        critique = await self._adversary(adversary_prompt)
        judge_prompt = self._judge_prompt.format(
            observations=_render_observations(observations),
            proposals_json=proposals_json,
            adversary_critique=critique.strip() or "(no critique)",
        )
        judge_reply = await self._judge(judge_prompt)
        accepted_indices = _parse_judge_verdicts(judge_reply, max_index=len(proposals))
        if not accepted_indices:
            return []
        accepted = [proposals[i] for i in accepted_indices]
        return _dedupe_edits(accepted)

    def _emit(self, event: Any) -> None:
        if self._tracer is None:
            return
        try:
            self._tracer.on_event(event)
        except Exception:  # noqa: BLE001
            logger.exception("tracer.on_event raised; reflection continues")


# ---------------------------------------------------------------------------
# Rendering / parsing helpers
# ---------------------------------------------------------------------------


def _render_observations(observations: list[Observation]) -> str:
    """Format the active observation set for the proposer prompt.

    One row per observation with id, priority, and text. We deliberately
    omit ``observation_date`` / ``referenced_date`` / ``source_round_ids``
    — the proposer is rewriting prose, not auditing provenance, and
    extra columns just inflate prompt tokens.
    """
    if not observations:
        return "  (none)"
    return "\n".join(
        f"  id={o.id} priority={o.priority} text={json.dumps(o.text)}" for o in observations
    )


def _parse_judge_verdicts(reply: str, *, max_index: int) -> list[int]:
    """Parse the judge's verdicts into the list of accepted edit indices."""
    parsed = _parse_top_level_object(reply)
    if parsed is None:
        return []
    raw = parsed.get("verdicts")
    if not isinstance(raw, list):
        return []
    accepted: list[int] = []
    seen: set[int] = set()
    for item in raw:
        if not isinstance(item, dict):
            continue
        idx = item.get("index")
        accept = item.get("accept")
        if isinstance(idx, bool) or not isinstance(idx, int):
            continue
        if not isinstance(accept, bool):
            continue
        if not accept:
            continue
        if idx < 0 or idx >= max_index or idx in seen:
            continue
        seen.add(idx)
        accepted.append(idx)
    return accepted


__all__ = [
    "DEFAULT_REFLECTOR_ADVERSARY_PROMPT",
    "DEFAULT_REFLECTOR_JUDGE_PROMPT",
    "DEFAULT_REFLECTOR_PROPOSER_PROMPT",
    "LLMCallable",
    "Reflector",
]
