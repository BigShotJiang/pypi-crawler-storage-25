import type {SidebarsConfig} from '@docusaurus/plugin-content-docs';

// Sidebar ordered for adoption funnel:
// 1. Quick wins first (Quickstart, Installation)
// 2. Concepts (What is a Claw?, Architecture)
// 3. Deep dives (Guides, Agent Support)
// 4. Reference last

const sidebars: SidebarsConfig = {
  tutorialSidebar: [
    'intro',
    'installation',
    {
      type: 'category',
      label: 'Guides',
      collapsed: false,
      items: [
        'guides/quickstart',
        'guides/host-setup',
        'guides/agent-onboarding',
        'guides/fleet-management',
      ],
    },
    'architecture',
    {
      type: 'category',
      label: 'OS Support',
      collapsed: true,
      items: [
        {
          type: 'category',
          label: 'Ubuntu',
          collapsed: true,
          items: [
            'os-support/ubuntu/24-04',
          ],
        },
        'os-support/macos',
      ],
    },
    {
      type: 'category',
      label: 'Agent Support',
      link: {
        type: 'doc',
        id: 'agent-support/index',
      },
      items: [
        'agent-support/openclaw',
        'agent-support/zeroclaw',
      ],
    },
    {
      type: 'category',
      label: 'Providers',
      link: {
        type: 'doc',
        id: 'agent-support/providers/index',
      },
      items: [
        'agent-support/providers/anthropic',
        'agent-support/providers/openai',
        'agent-support/providers/openrouter',
        'agent-support/providers/bedrock',
        'agent-support/providers/vertex',
        'agent-support/providers/ollama',
        'agent-support/providers/zai',
        'agent-support/providers/azure-openai',
      ],
    },
    {
      type: 'category',
      label: 'Channels',
      link: {
        type: 'doc',
        id: 'agent-support/channels/index',
      },
      items: [
        'agent-support/channels/cli',
        'agent-support/channels/discord',
        'agent-support/channels/slack',
        'agent-support/channels/web',
        'agent-support/channels/whatsapp',
      ],
    },
    {
      type: 'category',
      label: 'Integrations',
      link: {
        type: 'doc',
        id: 'agent-support/integrations/index',
      },
      items: [
        'agent-support/integrations/github',
        'agent-support/integrations/jira',
        'agent-support/integrations/gitlab',
        'agent-support/integrations/confluence',
        'agent-support/integrations/linear',
        'agent-support/integrations/notion',
      ],
    },
    {
      type: 'category',
      label: 'Reference',
      items: [
        'reference/configuration',
        {
          type: 'category',
          label: 'CLI Commands',
          link: {
            type: 'doc',
            id: 'reference/cli/index',
          },
          items: [
            'reference/cli/host',
            'reference/cli/agent',
            'reference/cli/provider',
            'reference/cli/secret',
            'reference/cli/registry',
          ],
        },
      ],
    },
    'troubleshooting',
    'contributing',
  ],
};

export default sidebars;
