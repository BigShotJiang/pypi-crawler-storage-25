#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Helper functions for naming conventions
"""

import re
from typing import List, Tuple


class NamingHelper:
    """Helper functions for naming conventions"""

    @staticmethod
    def get_class_struct_ranges(content: str) -> List[Tuple[str, int, int, str]]:
        """
        Get class and struct definition ranges

        Returns:
            List of tuples (type_name, start_pos, end_pos, type_keyword)
            type_keyword can be 'class' or 'struct'
        """
        ranges = []

        # Match class/struct definitions
        class_def_pattern = re.compile(r'\b(class|struct)\s+([A-Za-z_][A-Za-z0-9_]*)\s*[:{]')
        for match in class_def_pattern.finditer(content):
            type_keyword = match.group(1)
            type_name = match.group(2)
            start_pos = content.find('{', match.start())
            if start_pos == -1:
                continue

            # Find matching closing brace
            brace_count = 1
            i = start_pos + 1
            while i < len(content) and brace_count > 0:
                if content[i] == '{':
                    brace_count += 1
                elif content[i] == '}':
                    brace_count -= 1
                i += 1

            if brace_count == 0:
                ranges.append((type_name, start_pos + 1, i - 1, type_keyword))

        return ranges

    @staticmethod
    def create_position_markers(content: str, ranges: List[Tuple[str, int, int, str]]):
        """
        Create position markers for class and struct ranges

        Returns:
            Tuple of (in_class, in_struct, in_class_or_struct) boolean lists
        """
        in_class = [False] * len(content)
        in_struct = [False] * len(content)
        in_class_or_struct = [False] * len(content)

        for type_name, start, end, type_keyword in ranges:
            for i in range(start, end):
                if i < len(content):
                    if type_keyword == 'class':
                        in_class[i] = True
                    elif type_keyword == 'struct':
                        in_struct[i] = True
                    in_class_or_struct[i] = True

        return in_class, in_struct, in_class_or_struct

    @staticmethod
    def get_class_names(content: str) -> set:
        """Get all class and struct names"""
        class_names = set()
        class_pattern = re.compile(r'\b(class|struct)\s+([A-Za-z_][A-Za-z0-9_]*)\b')
        for match in class_pattern.finditer(content):
            class_names.add(match.group(2))
        return class_names

    @staticmethod
    def is_in_function(content: str, pos: int) -> bool:
        """Check if position is inside a function body"""
        # Find function bodies by tracking braces
        in_function = [False] * len(content)
        brace_count = 0
        i = 0
        while i < len(content):
            if content[i] == '{':
                brace_count += 1
                if brace_count == 1:
                    in_function[i] = True
            elif content[i] == '}':
                if brace_count == 1:
                    in_function[i] = True
                brace_count -= 1
            elif brace_count > 0:
                in_function[i] = True
            i += 1

        return pos < len(in_function) and in_function[pos]

    @staticmethod
    def is_in_init_list(content: str, match_start: int) -> bool:
        """Check if position is in constructor initialization list"""
        check_range = content[max(0, match_start - 100):match_start + 10]
        return ':' in check_range and re.search(r'\)\s*:', check_range)
