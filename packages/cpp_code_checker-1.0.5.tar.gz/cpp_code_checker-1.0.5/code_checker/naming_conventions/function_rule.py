#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Function naming rule
"""

import re
from typing import Dict, Any, List
from code_checker.base import BaseRule, Violation
from code_checker.naming_conventions.helper import NamingHelper


class FunctionRule(BaseRule):
    """Function naming rule - PascalCase for normal functions, camelCase for member functions"""

    def __init__(self, config: Dict[str, Any], whitelist: Dict[str, list]):
        super().__init__(config, whitelist)
        self.function_filtered = 0
        self.member_function_filtered = 0

    def check(self, file_path: str, content: str, lines: list) -> List[Violation]:
        """
        Check function naming convention

        只检查函数定义（声明和实现），不检查函数调用

        Args:
            file_path: Path to the file
            content: File content as string
            lines: File content as list of lines

        Returns:
            List of Violation objects
        """
        errors = []

        # Get class/struct ranges and markers
        class_ranges = NamingHelper.get_class_struct_ranges(content)
        in_class, in_struct, in_class_or_struct = NamingHelper.create_position_markers(
            content, class_ranges
        )
        class_names = NamingHelper.get_class_names(content)

        # Check function declarations (with semicolon) - 函数声明
        # 格式: ReturnType FunctionName(...);
        func_decl_pattern = re.compile(r'([A-Za-z_][A-Za-z0-9_]*)\s*\([^)]*\)\s*;')
        for match in func_decl_pattern.finditer(content):
            func_name = match.group(1)

            # 排除控制流语句
            if func_name in ["if", "for", "while", "switch", "catch", "do"]:
                continue

            # 排除析构函数（以 ~ 开头）
            if func_name.startswith('~'):
                continue

            # 排除构造函数（与类名相同）
            if func_name in class_names:
                continue

            # 检查前面是否有返回类型或类型前缀
            match_start = match.start()
            prev_text = content[max(0, match_start - 50):match_start].strip()

            # 检查是否是 lambda 调用
            # Lambda 特征：前面有 [ 或前面有 =
            check_range = content[max(0, match_start - 100):match_start]
            if '[' in check_range:
                # 可能是 lambda 调用，跳过
                continue
            if '=' in check_range:
                # 可能是 lambda 调用，跳过
                continue

            # 检查是否是函数声明（必须有返回类型或类型前缀）
            type_keywords = ['int', 'void', 'bool', 'char', 'float', 'double',
                           'long', 'short', 'unsigned', 'signed', 'std::',
                           'string', 'const', 'static', 'virtual', 'inline',
                           'explicit', 'constexpr', 'auto', 'size_t']
            has_return_type = any(kw in prev_text for kw in type_keywords)

            # 检查是否有类型前缀（大写字母结尾）
            has_type_prefix = re.search(r'[A-Z]\s*$', prev_text)

            # 如果没有返回类型和类型前缀，很可能是函数调用，跳过
            if not has_return_type and not has_type_prefix:
                continue

            # 检查是否是 lambda 或 lambda 调用
            if '(' in prev_text and ')' in prev_text:
                # 前面已经有括号，可能是 lambda 调用
                continue

            # 确定是否是成员函数
            check_pos = match.start()
            is_member = check_pos < len(in_class_or_struct) and in_class_or_struct[check_pos]

            if is_member:
                # 成员函数使用 camelCase
                pattern = self.config["naming_conventions"]["member_function"]["pattern"]
                whitelist_key = "member_function"
                rule_name = "member_function"
                desc = "驼峰命名法"
                func_type = "成员函数"
            else:
                # 普通函数使用 PascalCase
                pattern = self.config["naming_conventions"]["function"]["pattern"]
                whitelist_key = "function"
                rule_name = "function"
                desc = "帕斯卡命名法，可以加全大写前缀"
                func_type = "普通函数"

            if not re.match(pattern, func_name):
                # 不符合命名规范
                if func_name not in self.whitelist[whitelist_key]:
                    # 不在白名单中，添加错误
                    line_num = content[:match.start()].count('\n') + 1
                    errors.append(
                        f"[命名规范][{rule_name}] 第 {line_num} 行: {func_type}名 '{func_name}' 不符合规范（应使用{desc}）"
                    )
                else:
                    # 在白名单中，增加过滤计数
                    if whitelist_key == "member_function":
                        self.member_function_filtered += 1
                    else:
                        self.function_filtered += 1

        # Check function implementations (with braces) - 函数实现
        # 格式: ReturnType FunctionName(...) {
        # 或者: ClassName::FunctionName(...) {
        func_impl_pattern = re.compile(r'([A-Za-z_][A-Za-z0-9_]*)\s*\([^)]*\)\s*{')
        for match in func_impl_pattern.finditer(content):
            func_name = match.group(1)
            match_start = match.start()

            # 排除控制流语句
            if func_name in ["if", "for", "while", "switch", "catch", "do"]:
                continue

            # 排除析构函数（以 ~ 开头）
            if func_name.startswith('~'):
                continue

            # 排除构造函数（与类名相同）
            if func_name in class_names:
                continue

            # 检查是否在初始化列表中
            if NamingHelper.is_in_init_list(content, match_start):
                continue

            # 检查是否是类外实现的成员函数（格式：ClassName::FunctionName）
            # 检查函数名前面是否有类名限定符
            prev_text = content[max(0, match_start - 100):match_start].strip()
            class_qualified_pattern = re.compile(r'([A-Za-z_][A-Za-z0-9_]*)\s*::')
            class_qualified_match = class_qualified_pattern.search(prev_text)
            is_class_qualified = class_qualified_match is not None

            # 如果有类限定符，则肯定是成员函数
            if is_class_qualified:
                is_member = True
            else:
                # 确定是否是成员函数（通过位置判断）
                check_pos = match.start()
                is_member = check_pos < len(in_class_or_struct) and in_class_or_struct[check_pos]

            # 检查前面是否有返回类型或类型前缀
            if not is_class_qualified:
                # 如果不是类限定函数，需要检查返回类型
                prev_text = content[max(0, match_start - 50):match_start].strip()

                type_keywords = ['int', 'void', 'bool', 'char', 'float', 'double',
                               'long', 'short', 'unsigned', 'signed', 'std::',
                               'string', 'const', 'static', 'virtual', 'inline',
                               'explicit', 'constexpr', 'auto', 'size_t']
                has_return_type = any(kw in prev_text for kw in type_keywords)

                # 检查是否有类型前缀（大写字母结尾）
                has_type_prefix = re.search(r'[A-Z]\s*$', prev_text)

                # 如果没有返回类型和类型前缀，很可能是函数调用，跳过
                if not has_return_type and not has_type_prefix:
                    continue

                # 检查是否是 lambda 或 lambda 调用
                # Lambda 特征：前面有 [ 或前面有 =
                # 检查更大范围（100 字符）
                check_range = content[max(0, match_start - 100):match_start]
                if '[' in check_range:
                    # 检查是否是 lambda 赋值
                    if '=' in check_range:
                        # 可能是 lambda 赋值，跳过
                        continue
                    # 检查是否是 lambda 捕获列表
                    lambda_capture_pattern = re.compile(r'\[[^\]]*\]\s*=\s*[A-Za-z_]')
                    if lambda_capture_pattern.search(check_range):
                        continue

                # 检查前面是否有括号（可能是 lambda 调用）
                if '(' in prev_text and ')' in prev_text:
                    # 前面已经有括号，可能是 lambda 调用
                    continue

            if is_member:
                # 成员函数使用 camelCase
                pattern = self.config["naming_conventions"]["member_function"]["pattern"]
                whitelist_key = "member_function"
                rule_name = "member_function"
                desc = "驼峰命名法"
                func_type = "成员函数"
            else:
                # 普通函数使用 PascalCase
                pattern = self.config["naming_conventions"]["function"]["pattern"]
                whitelist_key = "function"
                rule_name = "function"
                desc = "帕斯卡命名法，可以加全大写前缀"
                func_type = "普通函数"

            if not re.match(pattern, func_name):
                # 不符合命名规范
                if func_name not in self.whitelist[whitelist_key]:
                    # 不在白名单中，添加错误
                    line_num = content[:match.start()].count('\n') + 1
                    errors.append(
                        f"[命名规范][{rule_name}] 第 {line_num} 行: {func_type}名 '{func_name}' 不符合规范（应使用{desc}）"
                    )
                else:
                    # 在白名单中，增加过滤计数
                    if whitelist_key == "member_function":
                        self.member_function_filtered += 1
                    else:
                        self.function_filtered += 1

        # 更新过滤计数
        self.whitelist_filtered_count = self.function_filtered + self.member_function_filtered

        return errors

    def get_function_filtered(self) -> int:
        """Get function filtered count"""
        return self.function_filtered

    def get_member_function_filtered(self) -> int:
        """Get member function filtered count"""
        return self.member_function_filtered
