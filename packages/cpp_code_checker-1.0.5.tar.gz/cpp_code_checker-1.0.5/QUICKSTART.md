# C++ Code Checker - 零依赖离线运行

## 📦 零依赖说明

本项目采用**零依赖**设计，**无需 pip 安装任何第三方包**！

只需 Python 3.8+ 标准库即可运行，可在完全离线的环境中使用。

## 🚀 快速启动

### Windows 用户

```cmd
# 方法1：双击运行（推荐）
双击 run.bat 文件

# 方法2：命令行运行
python run.py -d . --no-color

# 方法3：直接运行主程序
python code_checker/cpp_checker.py -d . --no-color
```

### Linux/Mac 用户

```bash
# 方法1：使用启动脚本（推荐）
./run.sh -d .

# 方法2：直接运行
python3 run.py -d .

# 方法3：直接运行主程序
python3 code_checker/cpp_checker.py -d .
```

## 📋 命令行参数

所有参数通过 `run.py` 传递，例如：

```bash
python run.py -d tests/ --no-color
python run.py -f main.cpp
python run.py -d src/ -o report.txt
python run.py -d tests/ --generate-whitelist
```

详细参数说明：运行 `python run.py --help`

## ✅ 依赖检查

本项目**无外部依赖**，使用 Python 标准库：
- `os`、`sys` - 系统操作
- `re` - 正则表达式
- `json` - 数据处理
- `typing` - 类型注解
- `dataclasses` - 数据类
- `argparse` - 参数解析

**确认无依赖**：
```bash
# 查看 pyproject.toml
cat pyproject.toml | grep dependencies
# 输出：dependencies = []  (空列表)
```

## 🔍 验证安装

运行以下命令验证工具是否正常工作：

```bash
python run.py -d tests/
```

如果看到错误报告，说明工具运行正常！

## 📖 详细文档

- [README.md](README.md) - 完整使用说明
- [OFFLINE_DEPLOY.md](OFFLINE_DEPLOY.md) - 离线部署详细指南

## ⚠️ 常见问题

### Q1: 运行时提示 "ModuleNotFoundError"

**原因**：未在项目根目录运行

**解决**：
```bash
# 确保当前目录包含以下文件：
# - run.py
# - code_checker/
# - config/

# 进入项目根目录
cd /path/to/cpp-code-checker

# 再次运行
python run.py -d .
```

### Q2: Windows 上中文显示为方框

**解决**：使用 `--no-color` 参数
```cmd
python run.py -d . --no-color
```

或输出到文件：
```cmd
python run.py -d . -o report.txt
```

### Q3: 如何在不联网的环境中使用？

**答案**：直接复制整个项目目录到目标计算机即可，无需安装任何依赖！

详细说明请查看：[OFFLINE_DEPLOY.md](OFFLINE_DEPLOY.md)

## 🎯 优势

1. **零依赖**：无需 pip 安装任何包
2. **离线可用**：完全离线环境运行
3. **跨平台**：Windows/Linux/Mac 通用
4. **自包含**：启动脚本自动处理所有配置
5. **便携**：整个项目就是一个独立的可执行单元
