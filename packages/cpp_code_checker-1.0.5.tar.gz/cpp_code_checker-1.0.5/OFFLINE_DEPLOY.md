# 离线部署说明

## 概述

本工具采用**零依赖**设计，只需要 Python 3.8+ 标准库即可运行，无需安装任何第三方依赖包（如通过 pip 安装）。

## 离线部署步骤

### 1. 下载项目

在联网环境中，将整个项目目录复制到目标计算机：

```bash
# 使用 U 盘、网络共享或其他方式复制
# 目标计算机不需要网络连接
```

### 2. 确认 Python 环境

在目标计算机上检查 Python 版本：

```bash
python --version
# 或
python3 --version
```

要求：Python 3.8 或更高版本

如果没有 Python，需要先安装：
- Windows：https://www.python.org/downloads/
- Linux：`sudo apt install python3` 或使用系统包管理器
- Mac：`brew install python3`

### 3. 运行工具

#### Windows 用户

**方法 1：双击运行**
```
双击 run.bat 文件
```

**方法 2：命令行运行**
```cmd
cd C:\path\to\cpp-code-checker
python run.py -d . --no-color
```

**方法 3：直接运行主程序**
```cmd
python code_checker/cpp_checker.py -d . --no-color
```

#### Linux/Mac 用户

**方法 1：使用启动脚本**
```bash
cd /path/to/cpp-code-checker
./run.sh -d .
```

**方法 2：直接运行**
```bash
python3 run.py -d .
```

**方法 3：直接运行主程序**
```bash
python3 code_checker/cpp_checker.py -d .
```

## 项目依赖说明

本项目**不依赖任何第三方 Python 包**，仅使用 Python 标准库：

- `os`：文件和目录操作
- `sys`：系统相关操作
- `re`：正则表达式
- `json`：JSON 数据处理
- `typing`：类型注解
- `dataclasses`：数据类（Python 3.7+）
- `argparse`：命令行参数解析
- `pathlib`：路径操作

**无需执行 `pip install` 命令！**

## 常见问题

### Q1: 运行时提示 "ModuleNotFoundError"

**原因**：未在项目根目录运行

**解决**：
```bash
# 确保当前目录包含以下文件：
# - run.py
# - code_checker/
# - config/

# 查看当前目录
ls

# 进入项目根目录
cd /path/to/cpp-code-checker

# 再次运行
python run.py -d .
```

### Q2: Windows 上中文显示为方框

**解决**：使用 `--no-color` 参数
```cmd
python run.py -d . --no-color
```

或输出到文件：
```cmd
python run.py -d . -o report.txt
```

### Q3: Linux 上提示权限不足

**解决**：添加执行权限
```bash
chmod +x run.sh
./run.sh -d .
```

或直接使用 Python 运行：
```bash
python3 run.py -d .
```

### Q4: 如何检查依赖情况？

**答案**：本项目无外部依赖，无需检查。

如果需要确认，可以查看 `pyproject.toml` 文件：
```toml
[project]
dependencies = []  # 空列表，表示无外部依赖
```

## 项目结构

```
cpp-code-checker/
├── run.py              # 启动脚本（推荐）
├── run.bat             # Windows 批处理脚本
├── run.sh              # Linux/Mac shell 脚本
├── code_checker/             # 源代码目录
│   ├── base.py         # 基础类和配置
│   ├── cpp_checker.py  # 主程序入口
│   ├── naming_conventions/  # 命名规范检查规则
│   ├── code_style/     # 代码样式检查规则
│   ├── best_practices/ # 最佳实践检查规则
│   └── ...
├── config/             # 配置文件目录
│   ├── coding_standards.json  # 编码规范配置
│   └── white_list.json        # 白名单配置
├── tests/              # 测试用例
├── README.md           # 项目说明
└── OFFLINE_DEPLOY.md   # 本文档（离线部署说明）
```

## 验证安装

运行以下命令验证工具是否正常工作：

```bash
# Windows
python run.py -d tests/

# Linux/Mac
python3 run.py -d tests/
```

如果看到错误报告，说明工具运行正常。

## 技术支持

如遇到问题，请检查：
1. Python 版本是否 >= 3.8
2. 是否在项目根目录运行
3. 文件路径是否正确
4. 是否有足够的文件读取权限

## 更新说明

本工具采用纯 Python 标准库实现，无需更新依赖包。
更新工具时，只需替换整个项目目录即可。
