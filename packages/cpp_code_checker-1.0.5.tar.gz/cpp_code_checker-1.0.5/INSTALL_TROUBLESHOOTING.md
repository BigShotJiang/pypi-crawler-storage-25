# 安装后问题解决方案

## 问题：python -m code_checker 无法找到模块

安装 `pip install cpp-code-checker` 后，执行 `python -m code_checker --help` 报错：
```
No module named code_checker
```

## 解决方案

### 方案1：使用正确的方式运行（推荐）

#### 方法A：直接使用模块名（推荐）
```powershell
python -m code_checker --help
```

#### 方法B：使用安装的脚本
```powershell
# 如果已将 Python Scripts 目录添加到 PATH
cpp-code-checker --help

# 或使用完整路径
C:\Users\like3\AppData\Roaming\Python\Python314\Scripts\cpp-code-checker.exe --help
```

#### 方法C：使用 python -m code_checker
```powershell
# 查看帮助
python -m code_checker --help

# 运行检查
python -m code_checker

# 生成白名单
python -m code_checker --generate-whitelist
```

### 方案2：添加 Scripts 目录到 PATH

将 Python Scripts 目录添加到系统 PATH：

1. 打开"系统属性" → "高级" → "环境变量"
2. 在"用户变量"中找到 `Path`
3. 点击"编辑" → "新建"
4. 添加：`C:\Users\like3\AppData\Roaming\Python\Python314\Scripts`
5. 保存并重新打开 PowerShell

然后可以直接使用：
```powershell
cpp-code-checker --help
```

### 方案3：创建 PowerShell 别名

编辑 PowerShell 配置文件：
```powershell
notepad $PROFILE
```

添加以下内容：
```powershell
function ccc { python -m code_checker $args }
```

重新加载配置：
```powershell
. $PROFILE
```

现在可以使用简写：
```powershell
ccc --help
```

## 包结构

```
安装后的结构：
site-packages/
  cpp_code_checker/  # 包（安装名）
    __init__.py
    config/
    base.py
    cpp_checker.py
    naming_conventions/
    best_practices/
    code_style/
    ...
```

## 重新安装（如果已安装旧版本）

```powershell
# 卸载旧版本
pip uninstall cpp-code-checker

# 重新构建并安装（从源码）
cd D:\09_AI\cpp-code-checker
pip install .

# 或从 wheel 文件安装
pip install dist\cpp_code_checker-1.0.0-py3-none-any.whl
```

## 验证安装

```powershell
# 检查是否安装
pip list | findstr cpp

# 测试运行
python -m code_checker --version

# 或测试完整功能
python -m code_checker -f tests\cases\class_and_struct_name\bad_class_struct.cpp
```

## 常用命令对照表

| 传统方式 | 替代方式 |
|---------|---------|
| `cpp-code-checker --help` | `python -m code_checker --help` |
| `run.bat` | `python -m code_checker` |
| `cpp-code-checker -f test.cpp` | `python -m code_checker -f test.cpp` |
| `cpp-code-checker --generate-whitelist` | `python -m code_checker --generate-whitelist` |

## 推荐做法

对于日常使用，推荐：
1. 添加 Scripts 目录到 PATH，使用 `cpp-code-checker` 命令
2. 或使用 PowerShell 别名 `ccc`
3. 备用方案：`python -m code_checker`

## 技术细节

### 包结构
```
cpp-code-checker (PyPI 包名)
└── code_checker (Python 模块)
    ├── __init__.py (导出 main 函数)
    ├── cpp_checker.py (主程序逻辑)
    ├── config/
    └── ...
```

### 入口点配置 (pyproject.toml)
```toml
[project.scripts]
cpp-code-checker = "code_checker:main"
```

这创建了 `cpp-code-checker.exe` 命令，调用 `code_checker` 模块的 `main` 函数。

