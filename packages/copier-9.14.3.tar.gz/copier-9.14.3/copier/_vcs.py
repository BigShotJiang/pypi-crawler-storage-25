"""Utilities related to VCS."""

from __future__ import annotations

import re
import sys
from contextlib import suppress
from pathlib import Path
from tempfile import TemporaryDirectory, mkdtemp
from warnings import warn

from packaging import version
from packaging.version import InvalidVersion, Version
from plumbum import TF, ProcessExecutionError, colors, local
from plumbum.machines import LocalCommand

from ._types import OptBool, OptStrOrPath, StrOrPath
from .errors import DirtyLocalWarning, ShallowCloneWarning

GIT_USER_NAME = "Copier"
GIT_USER_EMAIL = "copier@copier"


class _PathStr(str):
    """A string that represents a path."""


def get_git(context_dir: OptStrOrPath = None) -> LocalCommand:
    """Gets `git` command, or fails if it's not available."""
    command = local["git"].with_env(
        GIT_AUTHOR_NAME=GIT_USER_NAME,
        GIT_AUTHOR_EMAIL=GIT_USER_EMAIL,
        GIT_COMMITTER_NAME=GIT_USER_NAME,
        GIT_COMMITTER_EMAIL=GIT_USER_EMAIL,
    )
    if context_dir:
        command = command["-C", context_dir]
    return command


def get_git_version() -> Version:
    """Get the installed git version."""
    git = get_git()

    return Version(re.findall(r"\d+\.\d+(?:\.\d+)?", git("version"))[0])


GIT_PREFIX = ("git@", "git://", "git+", "https://github.com/", "https://gitlab.com/")
GIT_POSTFIX = ".git"
REPLACEMENTS = (
    (re.compile(r"^gh:/?(.*\.git)$"), r"https://github.com/\1"),
    (re.compile(r"^gh:/?(.*)$"), r"https://github.com/\1.git"),
    (re.compile(r"^gl:/?(.*\.git)$"), r"https://gitlab.com/\1"),
    (re.compile(r"^gl:/?(.*)$"), r"https://gitlab.com/\1.git"),
)


def is_git_repo_root(path: StrOrPath) -> bool:
    """Indicate if a given path is a git repo root directory."""
    try:
        return (
            Path(
                get_git()("-C", path, "rev-parse", "--show-toplevel").strip()
            ).resolve()
            == Path(path).resolve()
        )
    except (OSError, ProcessExecutionError):
        return False


def is_in_git_repo(path: StrOrPath) -> bool:
    """Indicate if a given path is in a git repo directory."""
    try:
        get_git()("-C", path, "rev-parse", "--show-toplevel")
        return True
    except (OSError, ProcessExecutionError):
        return False


def is_git_shallow_repo(path: StrOrPath) -> bool:
    """Indicate if a given path is a git shallow repo directory."""
    try:
        return (
            get_git()("-C", path, "rev-parse", "--is-shallow-repository").strip()
            == "true"
        )
    except (OSError, ProcessExecutionError):
        return False


def is_git_bundle(path: Path) -> bool:
    """Indicate if a path is a valid git bundle."""
    with suppress(OSError):
        path = path.resolve()
    with TemporaryDirectory(prefix=f"{__name__}.is_git_bundle.") as dirname:
        with local.cwd(dirname):
            get_git()("init")
            return bool(get_git()["bundle", "verify", path] & TF)


def get_repo(url: str) -> str | None:
    """Transform `url` into a git-parseable origin URL.

    Args:
        url:
            Valid examples:

            - gh:copier-org/copier
            - gl:copier-org/copier
            - git@github.com:copier-org/copier.git
            - git+https://mywebsiteisagitrepo.example.com/
            - /local/path/to/git/repo
            - /local/path/to/git/bundle/file.bundle
            - ~/path/to/git/repo
            - ~/path/to/git/repo.bundle
    """
    for pattern, replacement in REPLACEMENTS:
        url = re.sub(pattern, replacement, url)

    if url.endswith(GIT_POSTFIX) or url.startswith(GIT_PREFIX):
        if url.startswith("git+"):
            return url[4:]
        if url.startswith("https://") and not url.endswith(GIT_POSTFIX):
            return "".join((url, GIT_POSTFIX))
        return url

    url_path = Path(url)
    if url.startswith("~"):
        url_path = url_path.expanduser()

    if is_git_repo_root(url_path) or is_git_bundle(url_path):
        return _PathStr(url_path.as_posix())

    return None


def get_latest_tag(url: str, use_prereleases: OptBool = False) -> str:
    """Get latest git tag, sorted by PEP 440.

    Args:
        url:
            Git-parseable URL of the repo. As returned by
            [get_repo][copier.vcs.get_repo].
        use_prereleases:
            If `False`, skip prerelease git tags.

    Returns:
        The latest git tag, or `HEAD` if no valid tags are found.
    """
    # For local Git repos, `git ls-remote` requires an absolute path to work correctly,
    # it behaves unexpectedly with some relative paths, especially with parent path
    # traversal.
    #
    # See:
    # - https://github.com/copier-org/copier/issues/2589
    # - https://stackoverflow.com/q/59981939
    if isinstance(url, _PathStr):
        url = Path(url).resolve().as_posix()
    git = get_git()
    all_tags = (
        tag.split("\t", 1)[1].removeprefix("refs/tags/")
        for tag in git("ls-remote", "--tags", "--refs", url).splitlines()
    )
    all_tags = (tag for tag in all_tags if valid_version(tag))
    if not use_prereleases:
        all_tags = (tag for tag in all_tags if not version.parse(tag).is_prerelease)
    sorted_tags = sorted(all_tags, key=version.parse, reverse=True)
    try:
        return str(sorted_tags[0])
    except IndexError:
        print(
            colors.warn | "No git tags found in template; using HEAD as ref",
            file=sys.stderr,
        )
        return "HEAD"


def clone(url: str, ref: str = "HEAD") -> str:
    """Clone repo into some temporary destination.

    Includes dirty changes for local templates by copying into a temp
    directory and applying a wip commit there.

    Args:
        url:
            Git-parseable URL of the repo. As returned by
            [get_repo][copier.vcs.get_repo].
        ref:
            Reference to checkout. For Git repos, defaults to `HEAD`.
    """
    git = get_git()
    git_version = get_git_version()
    location = mkdtemp(prefix=f"{__name__}.clone.")
    _clone = git["clone", "--no-checkout", url, location]
    # Faster clones if possible
    if git_version >= Version("2.27"):
        if url_match := re.match("(file://)?(.*)", url):
            file_url = url_match.groups()[-1]
        else:
            file_url = url
        if is_git_shallow_repo(file_url):
            warn(
                f"The repository '{url}' is a shallow clone, this might lead to unexpected "
                "failure or unusually high resource consumption.",
                ShallowCloneWarning,
            )
        else:
            _clone = _clone["--filter=blob:none"]
    _clone()
    # Include dirty changes if checking out a local HEAD
    url_abspath = Path(url).absolute()
    if ref == "HEAD" and url_abspath.is_dir():
        is_dirty = False
        with local.cwd(url):
            is_dirty = bool(git("status", "--porcelain").strip())
        if is_dirty:
            with local.cwd(location):
                git("--git-dir=.git", f"--work-tree={url_abspath}", "add", "-A")
                git(
                    "--git-dir=.git",
                    f"--work-tree={url_abspath}",
                    "commit",
                    "-m",
                    "Copier automated commit for draft changes",
                    "--no-verify",
                    "--no-gpg-sign",
                )
                warn(
                    "Dirty template changes included automatically.",
                    DirtyLocalWarning,
                )

    with local.cwd(location):
        ## The `git checkout -f <ref>` command doesn't works when repo is local, dirty
        ## and core.fsmonitor is enabled
        ## ref: https://github.com/copier-org/copier/issues/1887
        git("-c", "core.fsmonitor=false", "checkout", "-f", ref)
        git("submodule", "update", "--checkout", "--init", "--recursive", "--force")

    return location


def valid_version(version_: str) -> bool:
    """Tell if a string is a valid [PEP 440][] version specifier.

    [PEP 440]: https://peps.python.org/pep-0440/
    """
    try:
        version.parse(version_)
    except InvalidVersion:
        return False
    return True
