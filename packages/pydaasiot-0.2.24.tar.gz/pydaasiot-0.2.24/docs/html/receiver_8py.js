var receiver_8py =
[
    [ "receiver.MyHandler", "classreceiver_1_1_my_handler.html", "classreceiver_1_1_my_handler" ],
    [ "receiver.handler", "namespacereceiver.html#a482154d8d12692248947d96b963abd5a", null ],
    [ "receiver.node", "namespacereceiver.html#a5ca543eb55416dd48a80dae4f55144e6", null ]
];