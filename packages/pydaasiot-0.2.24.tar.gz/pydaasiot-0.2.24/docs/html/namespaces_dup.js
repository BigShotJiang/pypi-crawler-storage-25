var namespaces_dup =
[
    [ "cli", "namespacecli.html", "namespacecli" ],
    [ "daas", "namespacedaas.html", "namespacedaas" ],
    [ "receiver", "namespacereceiver.html", "namespacereceiver" ],
    [ "sender", "namespacesender.html", "namespacesender" ],
    [ "setup", "namespacesetup.html", null ],
    [ "test", "namespacetest.html", [
      [ "v", "namespacetest.html#a05065d09950ced7525fc643dc4f9846d", null ],
      [ "wrapper", "namespacetest.html#a8312484af8950bb970be5eb1c34ae79d", null ]
    ] ]
];