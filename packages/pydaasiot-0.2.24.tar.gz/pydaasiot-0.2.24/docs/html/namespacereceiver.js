var namespacereceiver =
[
    [ "MyHandler", "classreceiver_1_1_my_handler.html", "classreceiver_1_1_my_handler" ],
    [ "handler", "namespacereceiver.html#a482154d8d12692248947d96b963abd5a", null ],
    [ "node", "namespacereceiver.html#a5ca543eb55416dd48a80dae4f55144e6", null ]
];