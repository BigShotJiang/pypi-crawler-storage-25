var structdaas_1_1api_1_1_driver_config =
[
    [ "link", "structdaas_1_1api_1_1_driver_config.html#a7c5a518cf1bb5538fccca3575b3a4fc8", null ],
    [ "uri", "structdaas_1_1api_1_1_driver_config.html#ac7996798d9a88a32fa046096915cbbbe", null ]
];