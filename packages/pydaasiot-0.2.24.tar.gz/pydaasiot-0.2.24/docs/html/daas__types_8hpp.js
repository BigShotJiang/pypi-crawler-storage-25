var daas__types_8hpp =
[
    [ "DDO", "class_d_d_o.html", "class_d_d_o" ],
    [ "Vector< T >", "class_vector.html", "class_vector" ],
    [ "IDaasApiEvent", "class_i_daas_api_event.html", "class_i_daas_api_event" ],
    [ "DaaSEvent", "class_daa_s_event.html", "class_daa_s_event" ],
    [ "IDepot", "class_i_depot.html", "class_i_depot" ],
    [ "dperf_info_result", "structdperf__info__result.html", "structdperf__info__result" ],
    [ "nodestate_t", "structnodestate__t.html", "structnodestate__t" ],
    [ "din_t", "daas__types_8hpp.html#ac159507b014eb6553ce0ac7c5eb552bc", null ],
    [ "dinlist_t", "daas__types_8hpp.html#ac61841b39b75fe6e13d1dc14e6d020d0", null ],
    [ "list_element", "daas__types_8hpp.html#a9eff49f27142bd6ff67a3b96142e3516", null ],
    [ "stime_t", "daas__types_8hpp.html#a0a3b80691bf6f835a28c799286ab99a8", null ],
    [ "tsetlist_t", "daas__types_8hpp.html#a1c995047abd115c5541147cc56f4ee7d", null ],
    [ "typeset_t", "daas__types_8hpp.html#a0fca3a800ac14988a9c332c195eb1feb", null ],
    [ "daas_error_t", "daas__types_8hpp.html#aa85413ba9eaa2c8cfa433917171cfe90", [
      [ "ERROR_NONE", "daas__types_8hpp.html#aa85413ba9eaa2c8cfa433917171cfe90a4edc8aade11e1de7bbbdc04704baae5f", null ],
      [ "ERROR_CORE_ALREADY_INITIALIZED", "daas__types_8hpp.html#aa85413ba9eaa2c8cfa433917171cfe90abe4aa1faff5f1320a5c9b15e336b32e6", null ],
      [ "ERROR_CORE_STOPPED", "daas__types_8hpp.html#aa85413ba9eaa2c8cfa433917171cfe90a016050988a7e8c9875a52a4551e812f6", null ],
      [ "ERROR_CANNOT_INITIALIZE", "daas__types_8hpp.html#aa85413ba9eaa2c8cfa433917171cfe90a09f21e1c7bb00cfeabe2e312cdc1d8e1", null ],
      [ "ERROR_CANNOT_CREATE_NODE", "daas__types_8hpp.html#aa85413ba9eaa2c8cfa433917171cfe90adbd108048df6f9e61d28c231e8699dd9", null ],
      [ "ERROR_DIN_ALREADY_EXIST", "daas__types_8hpp.html#aa85413ba9eaa2c8cfa433917171cfe90aedb586f6c19cb83fd463a6aefe9dfc14", null ],
      [ "ERROR_CANNOT_MAP_NODE", "daas__types_8hpp.html#aa85413ba9eaa2c8cfa433917171cfe90a78191d4e1c64c6c0c1e49789f6537358", null ],
      [ "ERROR_INVALID_USER_TYPESET", "daas__types_8hpp.html#aa85413ba9eaa2c8cfa433917171cfe90a15758b0e25d97984d30bd329d9fed2a6", null ],
      [ "ERROR_SEND_DDO", "daas__types_8hpp.html#aa85413ba9eaa2c8cfa433917171cfe90adc76d353859ef8ef497abd7e1d10f372", null ],
      [ "ERROR_NO_DDO_PRESENT", "daas__types_8hpp.html#aa85413ba9eaa2c8cfa433917171cfe90a857da3bdeea8ca11b37b7d90629490aa", null ],
      [ "ERROR_DIN_UNKNOWN", "daas__types_8hpp.html#aa85413ba9eaa2c8cfa433917171cfe90a933d53e83ac45cb1af3404b85eb74c76", null ],
      [ "ERROR_CHANNEL_FAILURE", "daas__types_8hpp.html#aa85413ba9eaa2c8cfa433917171cfe90aa544ecca9fbdb75a9544fbbed7319993", null ],
      [ "ERROR_ATS_NOT_SYNCED", "daas__types_8hpp.html#aa85413ba9eaa2c8cfa433917171cfe90a1d9691fa2130366ad5d8848dd78e3044", null ],
      [ "ERROR_INVALID_DME", "daas__types_8hpp.html#aa85413ba9eaa2c8cfa433917171cfe90a03bdb8b2d11302a0baac88d0def7ba1c", null ],
      [ "ERROR_THREADS_ALREADY_STARTED", "daas__types_8hpp.html#aa85413ba9eaa2c8cfa433917171cfe90a042096e5e766ffb36d0a8fc1a2b5acdd", null ],
      [ "ERROR_NOT_IMPLEMENTED", "daas__types_8hpp.html#aa85413ba9eaa2c8cfa433917171cfe90ab61c5ef368fbf03fdc1fb566c63f2f9a", null ],
      [ "ERROR_UNKNOWN", "daas__types_8hpp.html#aa85413ba9eaa2c8cfa433917171cfe90a2c8108ceb9a85cecbbe3af50dbc1cf8c", null ]
    ] ],
    [ "link_t", "daas__types_8hpp.html#a07f7359ebf68730b40908ef785af969b", [
      [ "_LINK_NONE", "daas__types_8hpp.html#a07f7359ebf68730b40908ef785af969ba53483561d0035e8ada57a3caf7e66dbc", null ],
      [ "_LINK_DAAS", "daas__types_8hpp.html#a07f7359ebf68730b40908ef785af969ba894aaa4c1ac9fe4928193e098f72ebd0", null ],
      [ "_LINK_INET4", "daas__types_8hpp.html#a07f7359ebf68730b40908ef785af969ba3f37f393b9d4f6d77f955870f921ce0d", null ],
      [ "_LINK_BT", "daas__types_8hpp.html#a07f7359ebf68730b40908ef785af969bae6069c9f495d96024db1631fc90be18a", null ],
      [ "_LINK_MQTT5", "daas__types_8hpp.html#a07f7359ebf68730b40908ef785af969ba251f792d0adecd195af21f8beb27a449", null ],
      [ "_LINK_UART", "daas__types_8hpp.html#a07f7359ebf68730b40908ef785af969ba9cfcb127d67a8593707bd9f6a8b28c89", null ]
    ] ],
    [ "performs_mode_t", "daas__types_8hpp.html#ae8eabb8c889d6ade263155b230598163", [
      [ "PERFORM_CORE_THREAD", "daas__types_8hpp.html#ae8eabb8c889d6ade263155b230598163ada1e8b969ddcb7eddd02932b7a7a6fc4", null ],
      [ "PERFORM_CORE_NO_THREAD", "daas__types_8hpp.html#ae8eabb8c889d6ade263155b230598163a3e3c62f5a2e0191b755e4d1d036d7f8f", null ]
    ] ],
    [ "syscode_t", "daas__types_8hpp.html#aa8b5d5e1e49eb93e03a5ca054b3fa343", [
      [ "___undefined", "daas__types_8hpp.html#aa8b5d5e1e49eb93e03a5ca054b3fa343a6021cd059b92438ab3deddcf11ca24f8", null ],
      [ "_cor_dme_sended", "daas__types_8hpp.html#aa8b5d5e1e49eb93e03a5ca054b3fa343ae6ed4056754ad2d47487c4bd34befbf1", null ],
      [ "_cor_dme_received", "daas__types_8hpp.html#aa8b5d5e1e49eb93e03a5ca054b3fa343a6dff82d7c9f61d3eb6aecd080e41b85e", null ],
      [ "_cor_rx_buffer", "daas__types_8hpp.html#aa8b5d5e1e49eb93e03a5ca054b3fa343a6113545031ed4cf781ec790ca323de26", null ],
      [ "_cor_tx_buffer", "daas__types_8hpp.html#aa8b5d5e1e49eb93e03a5ca054b3fa343a944c2b52c96cd6eb6c863b15191c055e", null ],
      [ "_ats_delta_avg", "daas__types_8hpp.html#aa8b5d5e1e49eb93e03a5ca054b3fa343a23c9b5eef65cfa2cb2b9e8a0d0effdbe", null ],
      [ "_ats_sync_counter", "daas__types_8hpp.html#aa8b5d5e1e49eb93e03a5ca054b3fa343ae0bdbfc99521a4dd57eca219126d4a8c", null ],
      [ "_ats_msg_decoded", "daas__types_8hpp.html#aa8b5d5e1e49eb93e03a5ca054b3fa343a6e3534121719b623a662e03f568f8634", null ],
      [ "_ats_msg_encoded", "daas__types_8hpp.html#aa8b5d5e1e49eb93e03a5ca054b3fa343ab4729ac7a4485851b1040b2c631f3013", null ]
    ] ]
];