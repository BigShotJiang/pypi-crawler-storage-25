var sender_8py =
[
    [ "sender.MyHandler", "classsender_1_1_my_handler.html", "classsender_1_1_my_handler" ],
    [ "sender.ddo", "namespacesender.html#a7395acdacd3909708d687feae13d05bf", null ],
    [ "sender.err", "namespacesender.html#ae6842516602e0ffb5091a0e4eb1ea3a8", null ],
    [ "sender.handler", "namespacesender.html#a68040613257aa0399649ae301d36fc3b", null ],
    [ "sender.node", "namespacesender.html#a534d995dc1f7a220b7a258f73ecc7767", null ]
];