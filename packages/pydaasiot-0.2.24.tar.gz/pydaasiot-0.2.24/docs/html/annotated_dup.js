var annotated_dup =
[
    [ "cli", "namespacecli.html", [
      [ "MyHandler", "classcli_1_1_my_handler.html", "classcli_1_1_my_handler" ]
    ] ],
    [ "daas", "namespacedaas.html", [
      [ "api", "namespacedaas_1_1api.html", [
        [ "DaasWrapper", "classdaas_1_1api_1_1_daas_wrapper.html", "classdaas_1_1api_1_1_daas_wrapper" ],
        [ "DriverConfig", "structdaas_1_1api_1_1_driver_config.html", "structdaas_1_1api_1_1_driver_config" ],
        [ "InterfaceInfo", "structdaas_1_1api_1_1_interface_info.html", "structdaas_1_1api_1_1_interface_info" ]
      ] ]
    ] ],
    [ "receiver", "namespacereceiver.html", [
      [ "MyHandler", "classreceiver_1_1_my_handler.html", "classreceiver_1_1_my_handler" ]
    ] ],
    [ "sender", "namespacesender.html", [
      [ "MyHandler", "classsender_1_1_my_handler.html", "classsender_1_1_my_handler" ]
    ] ],
    [ "DaasAPI", "class_daas_a_p_i.html", "class_daas_a_p_i" ],
    [ "DaaSEvent", "class_daa_s_event.html", "class_daa_s_event" ],
    [ "DDO", "class_d_d_o.html", "class_d_d_o" ],
    [ "dperf_info_result", "structdperf__info__result.html", "structdperf__info__result" ],
    [ "IDaasApiEvent", "class_i_daas_api_event.html", "class_i_daas_api_event" ],
    [ "IDepot", "class_i_depot.html", "class_i_depot" ],
    [ "nodestate_t", "structnodestate__t.html", "structnodestate__t" ],
    [ "Vector", "class_vector.html", "class_vector" ]
];