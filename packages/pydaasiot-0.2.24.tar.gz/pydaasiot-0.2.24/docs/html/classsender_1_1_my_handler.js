var classsender_1_1_my_handler =
[
    [ "atsSyncCompleted", "classsender_1_1_my_handler.html#a6bb1a57fe4e77d06f5cb18e7062a7d78", null ],
    [ "ddoReceivedEvent", "classsender_1_1_my_handler.html#a033b9a5ba87ecf1f91da68d23b2facc3", null ],
    [ "dinAcceptedEvent", "classsender_1_1_my_handler.html#ab1014a7871e535c6a4551bde8b9a0250", null ],
    [ "frisbeeDperfCompleted", "classsender_1_1_my_handler.html#a82d03c90c396f1aa6d009a4d4f329970", null ],
    [ "frisbeeReceivedEvent", "classsender_1_1_my_handler.html#a840ddd9c9111746c4c383c61919e8a67", null ],
    [ "nodeStateReceivedEvent", "classsender_1_1_my_handler.html#a1d008d594d2dec086dcf9642b02766d4", null ]
];