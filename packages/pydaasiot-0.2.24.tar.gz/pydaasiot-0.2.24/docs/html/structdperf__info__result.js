var structdperf__info__result =
[
    [ "local_end_timestamp", "structdperf__info__result.html#a701110a034b4dd3ddb06393faa557453", null ],
    [ "remote_data_counter", "structdperf__info__result.html#a7b8d2e20c096e9b9c681b3dd1e4b8cf7", null ],
    [ "remote_first_timestamp", "structdperf__info__result.html#a539d0526990531918e1ee21916532abd", null ],
    [ "remote_last_timestamp", "structdperf__info__result.html#a223a7bc9dd65fec7c54af1fc13173cfe", null ],
    [ "remote_pkt_counter", "structdperf__info__result.html#aee800a4c809ba4c63d6ff6b295874a49", null ],
    [ "sender_first_timestamp", "structdperf__info__result.html#a193b88ffb078e7222c46cc3794b90692", null ]
];