var class_i_depot =
[
    [ "clearSpace", "class_i_depot.html#a8e3834dda70b7e5ca2e55121e46902f4", null ],
    [ "close", "class_i_depot.html#a710a64ff9967b9f30de3e48214e2ee98", null ],
    [ "getSpaceInfo", "class_i_depot.html#a8995117c697a4c8d9e235614b612cf3b", null ],
    [ "load", "class_i_depot.html#ae3e70142c65e08965df44ba841c5e705", null ],
    [ "open", "class_i_depot.html#a4fa309c50f09dcd283b339f225a66590", null ],
    [ "save", "class_i_depot.html#a6058d9fc4176b4f3e84daf9312db20b8", null ],
    [ "trash", "class_i_depot.html#a5a2e30f40f3e61fb55dd2039b4391e8d", null ]
];