var structdaas_1_1api_1_1_interface_info =
[
    [ "name", "structdaas_1_1api_1_1_interface_info.html#acef851d0595278b172737a201cbbdc3d", null ],
    [ "status", "structdaas_1_1api_1_1_interface_info.html#ac1a813f22e55a50258ca2396e97868b5", null ],
    [ "type", "structdaas_1_1api_1_1_interface_info.html#acbffc3b6a6818878ab3b9be632a3785f", null ]
];