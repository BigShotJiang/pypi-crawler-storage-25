var structnodestate__t =
[
    [ "accept_all_requests", "structnodestate__t.html#ace38ae797f6ff1dce31b47f367467f5b", null ],
    [ "codec", "structnodestate__t.html#a0f80cb82c8ac3e4ea9e017f940869e37", null ],
    [ "form", "structnodestate__t.html#ae980e3a349e417d8b48d9d7a56713512", null ],
    [ "hwver", "structnodestate__t.html#a252a459ff595b73bac5f74f20f026e63", null ],
    [ "in_sync", "structnodestate__t.html#aa3fd60e096d6f94281a93e470fc934df", null ],
    [ "lasttime", "structnodestate__t.html#a279c55d0fc1e37bf518b8a2e0cb3aa5f", null ],
    [ "linked", "structnodestate__t.html#ae3f3e48c6be3ac95aa3392a0dbf9677e", null ],
    [ "lock", "structnodestate__t.html#aaacab64e3d6f9ac70fd72577458c7718", null ],
    [ "oCap_i", "structnodestate__t.html#aada075239eaf055e11834482c4803c41", null ],
    [ "on_time", "structnodestate__t.html#a17903a3353622fa3575bdd54f8d02344", null ],
    [ "skey", "structnodestate__t.html#a198ed7a7c2fe8b9710fba8cae7976d63", null ],
    [ "sklen", "structnodestate__t.html#a69d8894cccad7dea9a0f36d86a926576", null ]
];