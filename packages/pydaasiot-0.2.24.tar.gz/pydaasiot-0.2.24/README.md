# pydaasiot

**Python bindings for the DaaS-IoT SDK**

`pydaasiot` provides Python bindings for the DaaS-IoT native SDK, exposing the core features of `libdaas` through a Python-friendly API.

It allows Python applications to initialize DaaS-IoT nodes, configure network drivers, map remote nodes, exchange DDO messages, use real-time streams, inspect node status, and handle SDK events.

---

## Overview

DaaS-IoT is based on the concept of distributed nodes identified by:

- **SID**: Service/Session/Network identifier
- **DIN**: Device identifier inside the network
- **DDO**: DaaS Data Object, the message unit exchanged between nodes
- **Link**: communication backend, such as IPv4, Bluetooth, MQTT, UART, etc.

With `pydaasiot`, a Python application can act as a DaaS-IoT node and communicate with other nodes through the same native SDK used by C++ applications.

A minimal communication flow is:

```text
Receiver node
  DIN 101
  listens on 127.0.0.1:2222

Sender node
  DIN 102
  listens on 127.0.0.1:2223
  maps DIN 101
  pushes a DDO to DIN 101
```

---

## Main Features

- Initialize and manage DaaS-IoT nodes from Python
- Enable network drivers such as `LINK_INET4`
- Map remote DINs
- Send and receive DDO messages
- Access DDO payloads as bytes, text, or hex
- Use polling-based DDO reception
- Use event handlers through Python subclasses
- Access node status and runtime information
- Use real-time stream APIs
- Access diagnostics such as Frisbee ICMP and DPERF
- Query SDK version and statistics

---

## Installation

The package exposes the native module:

```python
import pydaasiot
```

Depending on the build configuration, the module is usually produced as a shared object similar to:

```text
pydaasiot.so
```

or, on Windows:

```text
pydaasiot.pyd
```

Make sure the generated module is visible from your Python environment.

Example:

```bash
python -c "import pydaasiot; print(pydaasiot)"
```

---

## Basic Concepts

### SID and DIN

Each node belongs to a SID and has a DIN.

```python
SID = 100
LOCAL_DIN = 102
REMOTE_DIN = 101
```

### Drivers

A node must enable at least one communication driver.

For IPv4 communication:

```python
node.enableDriver(pydaasiot._LINK_INET4, "127.0.0.1:2223")
```

The URI usually contains the address and port used by the local node.

### Mapping Remote Nodes

Before sending data to another DIN, the remote node must be mapped:

```python
node.map(101, pydaasiot._LINK_INET4, "127.0.0.1:2222")
```

### DDO Messages

A `DDO` is the basic message exchanged between nodes.

```python
ddo = pydaasiot.DDO(1)
ddo.setPayload(b"Hello from Python")
node.push(101, ddo)
```

The integer passed to `DDO(1)` is the typeset.

---

## Minimal Node Initialization

```python
import pydaasiot

SID = 100
LOCAL_DIN = 102

node = pydaasiot.DaasWrapper(None, None)

err = node.doInit(SID, LOCAL_DIN)
if err != pydaasiot.ERROR_NONE:
    raise RuntimeError(node.errorToString(err))

err = node.enableDriver(pydaasiot._LINK_INET4, "127.0.0.1:2223")
if err != pydaasiot.ERROR_NONE:
    raise RuntimeError(node.errorToString(err))

err = node.doPerform(pydaasiot.PERFORM_CORE_THREAD)
if err != pydaasiot.ERROR_NONE:
    raise RuntimeError(node.errorToString(err))
```

---

## Error Handling

Most SDK methods return a `daas_error_t`.

Use `errorToString()` to print a readable error message:

```python
err = node.doInit(100, 102)

if err != pydaasiot.ERROR_NONE:
    print("Error:", err, node.errorToString(err))
```

A small helper is useful:

```python
def check(node, err, label):
    if err != pydaasiot.ERROR_NONE:
        raise RuntimeError(f"{label} failed: {err} ({node.errorToString(err)})")
    print(f"{label}: OK")
```

---

# Sender / Receiver Example

The following example creates two local DaaS-IoT nodes communicating over IPv4.

The receiver listens on:

```text
127.0.0.1:2222
```

The sender listens on:

```text
127.0.0.1:2223
```

The sender sends a DDO to the receiver.

---

## receiver.py

```python
import time
import pydaasiot


SID = 100
RECEIVER_DIN = 101
SENDER_DIN = 102

RECEIVER_URI = "127.0.0.1:2222"
SENDER_URI = "127.0.0.1:2223"


class MyHandler(pydaasiot.IDaasApiEvent):
    def dinAccepted(self, din):
        print(f"[EVENT] DIN accepted: {din}")

    def ddoReceived(self, payload_size, typeset, din):
        print(
            f"[EVENT] DDO available: "
            f"din={din}, size={payload_size}, typeset={typeset}"
        )

    def frisbeeReceived(self, din):
        print(f"[EVENT] FRISBEE received from DIN {din}")

    def nodeStateReceived(self, din):
        print(f"[EVENT] Node state received from DIN {din}")

    def atsSyncCompleted(self, din):
        print(f"[EVENT] ATS sync completed with DIN {din}")

    def frisbeeDperfCompleted(self, din, packets_sent, block_size):
        print(
            f"[EVENT] Frisbee DPERF completed: "
            f"din={din}, packets={packets_sent}, block_size={block_size}"
        )

    def networkDiscovered(self, din, sid, link):
        print(f"[EVENT] Network discovered: din={din}, sid={sid}, link={link}")

    def nodeConnectedToNetwork(self, sid, din):
        print(f"[EVENT] Node connected to network: sid={sid}, din={din}")

    def streamInfoReceived(self, din, pkt_type, stream_id):
        print(
            f"[EVENT] Stream info: "
            f"din={din}, pkt_type={pkt_type}, stream_id={stream_id}"
        )


def check(node, err, label):
    if err != pydaasiot.ERROR_NONE:
        raise RuntimeError(f"{label} failed: {err} ({node.errorToString(err)})")
    print(f"{label}: OK")


def decode_payload(payload):
    if payload is None:
        return ""

    if isinstance(payload, str):
        return payload

    return payload.split(b"\x00", 1)[0].decode("utf-8", errors="replace")


def main():
    handler = MyHandler()

    node = pydaasiot.DaasWrapper(None, handler)

    check(node, node.doInit(SID, RECEIVER_DIN), "doInit")
    check(node, node.enableDriver(pydaasiot._LINK_INET4, RECEIVER_URI), "enableDriver")
    check(node, node.map(SENDER_DIN, pydaasiot._LINK_INET4, SENDER_URI), "map sender")
    check(node, node.doPerform(pydaasiot.PERFORM_CORE_THREAD), "doPerform")

    print("Receiver ready. Waiting for DDOs...")

    try:
        while True:
            err, count = node.availablesPull(SENDER_DIN)

            if err == pydaasiot.ERROR_NONE and count > 0:
                err, typeset, payload = node.pullPayload(SENDER_DIN)

                if err == pydaasiot.ERROR_NONE:
                    print(
                        f"[PULL] typeset={typeset}, "
                        f"raw={payload!r}, "
                        f"text={decode_payload(payload)!r}"
                    )
                else:
                    print(f"[PULL] failed: {err} ({node.errorToString(err)})")

            elif err != pydaasiot.ERROR_NONE and err != pydaasiot.ERROR_NO_DDO_PRESENT:
                print(f"[PULL] availablesPull failed: {err} ({node.errorToString(err)})")

            time.sleep(0.1)

    except KeyboardInterrupt:
        print("\nStopping receiver...")
    finally:
        node.doEnd()


if __name__ == "__main__":
    main()
```

---

## sender.py

```python
import time
import pydaasiot


SID = 100
SENDER_DIN = 102
RECEIVER_DIN = 101

SENDER_URI = "127.0.0.1:2223"
RECEIVER_URI = "127.0.0.1:2222"


class MyHandler(pydaasiot.IDaasApiEvent):
    def dinAccepted(self, din):
        print(f"[EVENT] DIN accepted: {din}")

    def ddoReceived(self, payload_size, typeset, din):
        print(
            f"[EVENT] DDO received on sender side: "
            f"din={din}, size={payload_size}, typeset={typeset}"
        )

    def frisbeeReceived(self, din):
        print(f"[EVENT] FRISBEE received from DIN {din}")

    def nodeStateReceived(self, din):
        print(f"[EVENT] Node state received from DIN {din}")

    def atsSyncCompleted(self, din):
        print(f"[EVENT] ATS sync completed with DIN {din}")

    def frisbeeDperfCompleted(self, din, packets_sent, block_size):
        print(
            f"[EVENT] Frisbee DPERF completed: "
            f"din={din}, packets={packets_sent}, block_size={block_size}"
        )

    def networkDiscovered(self, din, sid, link):
        print(f"[EVENT] Network discovered: din={din}, sid={sid}, link={link}")

    def nodeConnectedToNetwork(self, sid, din):
        print(f"[EVENT] Node connected to network: sid={sid}, din={din}")

    def streamInfoReceived(self, din, pkt_type, stream_id):
        print(
            f"[EVENT] Stream info: "
            f"din={din}, pkt_type={pkt_type}, stream_id={stream_id}"
        )


def check(node, err, label):
    if err != pydaasiot.ERROR_NONE:
        raise RuntimeError(f"{label} failed: {err} ({node.errorToString(err)})")
    print(f"{label}: OK")


def main():
    handler = MyHandler()

    node = pydaasiot.DaasWrapper(None, handler)

    check(node, node.doInit(SID, SENDER_DIN), "doInit")
    check(node, node.enableDriver(pydaasiot._LINK_INET4, SENDER_URI), "enableDriver")
    check(node, node.map(RECEIVER_DIN, pydaasiot._LINK_INET4, RECEIVER_URI), "map receiver")
    check(node, node.doPerform(pydaasiot.PERFORM_CORE_THREAD), "doPerform")

    time.sleep(1.0)

    ddo = pydaasiot.DDO(1)
    ddo.setPayload(b"Hello from sender!")

    err = node.push(RECEIVER_DIN, ddo)
    print(f"push result: {err} ({node.errorToString(err)})")

    input("Press Enter to exit...\n")
    node.doEnd()


if __name__ == "__main__":
    main()
```

---

## Running the Example

Start the receiver first:

```bash
python receiver.py
```

Then start the sender in another terminal:

```bash
python sender.py
```

Expected receiver output:

```text
doInit: OK
enableDriver: OK
map sender: OK
doPerform: OK
Receiver ready. Waiting for DDOs...
[PULL] typeset=1, raw=b'Hello from sender!', text='Hello from sender!'
```

---

# Using DDO Payload Helpers

`pydaasiot` exposes multiple helpers to access DDO payloads safely.

```python
ddo = pydaasiot.DDO(1)
ddo.setPayload(b"hello")

print(ddo.payload_bytes())
print(ddo.payload_text())
print(ddo.payload_hex())
```

Output:

```text
b'hello'
hello
68656c6c6f
```

If the payload contains C-style terminators or padding bytes, decode it safely:

```python
text = payload.split(b"\x00", 1)[0].decode("utf-8", errors="replace")
```

---

# Event Handlers

Event handlers can be implemented by subclassing `pydaasiot.IDaasApiEvent`.

```python
class MyHandler(pydaasiot.IDaasApiEvent):
    def ddoReceived(self, payload_size, typeset, din):
        print(f"DDO received from DIN {din}")
```

The handler must be passed when creating the wrapper:

```python
handler = MyHandler()
node = pydaasiot.DaasWrapper(None, handler)
```

Do not rely on setting the event handler later unless the native SDK explicitly supports runtime handler replacement.

---

# Configuration Files

The `DaasWrapper` constructor accepts a config parameter for compatibility:

```python
node = pydaasiot.DaasWrapper("config.json", handler)
```

However, in the current wrapper implementation, the constructor does not automatically load the file.

To configure a node from JSON, use:

```python
node.setupNode("config.json")
```

Example configuration:

```json
{
  "sid": 100,
  "din": 101,
  "drivers": [
    {
      "link": 2,
      "uri": "127.0.0.1:2222"
    }
  ]
}
```

Then:

```python
node = pydaasiot.DaasWrapper(None, handler)
err = node.setupNode("config.json")
```

---

# Common API Reference

## Lifecycle

```python
node.doInit(sid, din)
node.doPerform(pydaasiot.PERFORM_CORE_THREAD)
node.doEnd()
node.doReset()
```

## Drivers

```python
node.listAvailableDrivers()
node.enableDriver(pydaasiot._LINK_INET4, "127.0.0.1:2223")
```

## Mapping

```python
node.map(remote_din)
node.map(remote_din, pydaasiot._LINK_INET4, "127.0.0.1:2222")
node.remove(remote_din)
node.locate(remote_din)
```

## DDO Communication

```python
ddo = pydaasiot.DDO(1)
ddo.setPayload(b"message")

node.push(remote_din, ddo)

err, count = node.availablesPull(remote_din)
err, typeset, payload = node.pullPayload(remote_din)
```

## Node Status

```python
status = node.getStatus()
remote_status = node.status(remote_din)
```

## Statistics

```python
node.doStatisticsReset()
value = node.getSystemStatistics(pydaasiot._cor_dme_received)
timestamp = node.getSyncedTimestamp()
```

## Real-Time Stream API

```python
node.use(remote_din)
node.send(remote_din, b"stream payload")
available = node.received(remote_din)
data = node.receive(remote_din)
node.end(remote_din)
```

---

# Notes

## About `setEventHandler`

In the current wrapper implementation, the event handler is passed to the native `DaasAPI` object during construction.

Therefore, this is the recommended pattern:

```python
handler = MyHandler()
node = pydaasiot.DaasWrapper(None, handler)
```

Avoid this pattern unless the native SDK supports runtime handler replacement:

```python
node = pydaasiot.DaasWrapper(None, None)
node.setEventHandler(handler)
```

## About `setOrigin`

Older examples may use:

```python
ddo.setOrigin(102)
```

The current Python binding does not expose `setOrigin`.

The origin is expected to be managed internally by the SDK when the DDO is sent by a node.

Use:

```python
ddo = pydaasiot.DDO(1)
ddo.setPayload(b"Hello")
node.push(remote_din, ddo)
```

## About Polling vs Events

For robust Python examples, polling is recommended:

```python
err, count = node.availablesPull(remote_din)
if count > 0:
    err, typeset, payload = node.pullPayload(remote_din)
```

Events are still useful for logging and asynchronous notification, but polling keeps the data retrieval flow explicit and easy to debug.

---

# License

Add your project license here.

---

# Project Status

This binding targets the DaaS-IoT SDK `v0.22.0`.

The API is actively evolving. Some lower-level native SDK types are intentionally not exposed yet, especially when they require custom C++ containers, function pointers, or additional callback trampoline logic.
