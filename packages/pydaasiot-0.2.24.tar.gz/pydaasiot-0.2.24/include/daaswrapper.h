// daasiot/include/daaswrapper.h
#ifndef DAAS_WRAPPER_H
#define DAAS_WRAPPER_H

#include "daas.hpp"
#include "daas_types.hpp"

#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

/**
 * @file daaswrapper.h
 * @brief High-level wrapper for the DaaS-IoT SDK v0.22.0.
 *
 * @details
 * This class encapsulates the low-level DaasAPI and exposes a simpler, safer API
 * to initialize a node, enable drivers, and send/receive DDO packets.
 * Updated to support the DaaS-IoT SDK v0.22.0 API.
 *
 * © 2026 Sebyone Srl. All rights reserved.
 */

namespace daas {
namespace api {

/**
 * @struct DriverConfig
 * @brief Driver configuration entry used by the wrapper when loading from JSON.
 */
struct DriverConfig {
    link_t      link;   ///< Driver/link type (e.g., _LINK_INET4).
    std::string uri;    ///< Driver URI (e.g., "127.0.0.1:3000").
};

/**
 * @struct InterfaceInfo
 * @brief Basic information about a system network interface.
 */
struct InterfaceInfo {
    std::string name;    ///< Interface name (e.g., "eth0").
    std::string type;    ///< Interface type (implementation-defined).
    std::string status;  ///< Interface status (implementation-defined).
};

/**
 * @class DaasWrapper
 * @brief Convenience wrapper around libdaas.a (DaasAPI) v0.22.0.
 *
 * @warning
 * Unless explicitly stated, returned references mirror the underlying DaasAPI
 * behavior. In particular, see @ref pull for DDO ownership and lifetime.
 */
class DaasWrapper {
private:
    DaasAPI* daasInstance{nullptr};          ///< Underlying DaasAPI instance.
    IDaasApiEvent* eventHandler{nullptr};    ///< Optional event handler (not owned).

    // Internals
    char infoBuffer[256]{};                  ///< Internal buffer for getInfos().
    std::unordered_map<std::string, std::string> configCache; ///< Cached key/value config.
    std::vector<DriverConfig> driversCache;  ///< Drivers loaded from JSON.

public:
    /**
     * @brief Constructs the wrapper.
     * @param config Optional configuration file path (may be nullptr).
     * @param eventHandler Optional event handler for DaasAPI callbacks (not owned).
     */
    DaasWrapper(const char* config, IDaasApiEvent* eventHandler);

    /**
     * @brief Destroys the wrapper and its DaasAPI instance.
     */
    ~DaasWrapper();

    // ---------------------------------------------------------------------
    // Interfaces / Networking
    // ---------------------------------------------------------------------

    /**
     * @brief Returns a list of active network interface names.
     */
    std::vector<std::string> getActiveInterfaces();

    /**
     * @brief Returns detailed information about all system network interfaces.
     */
    std::vector<InterfaceInfo> listSystemInterfaces();

    // ---------------------------------------------------------------------
    // Lifecycle / State
    // ---------------------------------------------------------------------

    /**
     * @brief Initializes the node with a Service ID and Device ID.
     * @param sid Service Identifier.
     * @param din Device Identification Number.
     */
    daas_error_t doInit(din_t sid, din_t din);

    /**
     * @brief Starts the internal execution loop.
     * @param mode Threading mode (PERFORM_CORE_THREAD or PERFORM_CORE_NO_THREAD).
     */
    daas_error_t doPerform(performs_mode_t mode);

    /**
     * @brief Stops all node activities.
     */
    daas_error_t doEnd();

    /**
     * @brief Resets the node state.
     */
    daas_error_t doReset();

    /**
     * @brief Returns the library version string.
     */
    const char* getVersion();

    /**
     * @brief Returns a short "Version: X | Build: Y" string.
     * @return Pointer to an internal buffer valid until next call.
     */
    const char* getInfos();

    /**
     * @brief Converts a daas_error_t code into a human-readable string.
     */
    const char* errorToString(daas_error_t err);

    // ---------------------------------------------------------------------
    // Drivers / Setup
    // ---------------------------------------------------------------------

    /**
     * @brief Lists all drivers supported by the current build.
     */
    const char* listAvailableDrivers();

    /**
     * @brief Enables a communication driver.
     * @param link The link type to enable.
     * @param driver The driver URI or identifier.
     */
    daas_error_t enableDriver(link_t link, const char* driver);

    /**
     * @brief Comprehensive node setup using direct parameters.
     */
    daas_error_t setupNode(din_t sid, din_t din, link_t link, const char* uri);

    /**
     * @brief Comprehensive node setup using a JSON configuration file.
     */
    daas_error_t setupNode(const char* setupFilePath);

    // ---------------------------------------------------------------------
    // Network / Nodes
    // ---------------------------------------------------------------------

    /**
     * @brief Returns the status of the local node.
     */
    node_info_t getStatus();

    /**
     * @brief Returns the status of a remote node.
     */
    const node_info_t& status(din_t din);

    /**
     * @brief Fetches state information from a remote node.
     */
    const node_info_t& fetch(din_t din, uint16_t opts);

    /**
     * @brief Returns a list of all known nodes using the native libdaas network info list type.
     *
     * @note In SDK v0.22.0 DaasAPI::listNodes() returns network_info_list_t.
     */
    network_info_list_t listNodes();

    /**
     * @brief Returns a list of all known nodes as a standard C++ vector.
     *
     * @details Useful for pybind11 bindings because network_info_list_t is a custom Vector<T>.
     * In this SDK version, each entry is node_network_info_t.
     */
    std::vector<node_network_info_t> listNodesVector();

    /**
     * @brief Returns all node DINs belonging to a specific Service ID.
     *
     * @note Native wrapper around DaasAPI::getAllNodes(sid).
     */
    Vector<din_t> getAllNodes(din_t sid);

    /**
     * @brief Returns all node DINs belonging to a specific Service ID as a standard C++ vector.
     *
     * @details Useful for pybind11 bindings because DaasAPI::getAllNodes() returns Vector<din_t>.
     */
    std::vector<din_t> getAllNodesVector(din_t sid);

    /**
     * @brief Returns the native node map list.
     *
     * @note Native wrapper around DaasAPI::getNodeList().
     */
    node_map_list_t getNodeList();

    /**
     * @brief Persists current configuration via the provided storage interface.
     */
    bool storeConfiguration(IDepot* storage_interface);

    /**
     * @brief Loads configuration via the provided storage interface.
     */
    bool loadConfiguration(IDepot* storage_interface);

    /**
     * @brief Resets the system statistics.
     */
    bool doStatisticsReset();

    /**
     * @brief Returns a system statistic by syscode.
     */
    uint64_t getSystemStatistics(syscode_t label);

    /**
     * @brief Returns the synchronized timestamp of the local node.
     */
    uint64_t getSyncedTimestamp();

    // ---------------------------------------------------------------------
    // Features / Join / Requests
    // ---------------------------------------------------------------------

    /**
     * @brief Adds one or more features to the local node.
     */
    daas_error_t addNodeFeatures(feature_t features);

    /**
     * @brief Returns the list of features currently associated with the local node.
     */
    features_list getNodeFeatures();

    /**
     * @brief Returns the list of features currently associated with the local node as a standard C++ vector.
     *
     * @details Useful for pybind11 bindings because features_list is a custom Vector<T>.
     */
    std::vector<feature_t> getNodeFeaturesVector();

    /**
     * @brief Joins a DaaS network.
     *
     * @param sid Service ID to join. Defaults to 0.
     * @param link Link type to use. Defaults to _LINK_NONE.
     * @param timeout Timeout in milliseconds. Defaults to 5000.
     */
    daas_error_t join(
        din_t sid = 0,
        link_t link = _LINK_NONE,
        uint32_t timeout = 5000
    );

    /**
     * @brief Checks whether a remote node has a specific feature.
     */
    bool nodeHasFeature(din_t din, feature_t feature);

    /**
     * @brief Requests a feature from a remote node.
     */
    /*daas_error_t requestFeature(
        din_t din,
        feature_rq_t request,
        uint32_t timeout = 1000
    );*/

    // ---------------------------------------------------------------------
    // Policy / Options
    // ---------------------------------------------------------------------

    /**
     * @brief Configures whether the local node accepts incoming requests.
     */
    void setAcceptRequestsLevel(accept_request_policy_t policy_level);

    /**
     * @brief Configures how the node participates in discovery.
     */
    void setDiscoveryState(discovery_state_t mode);

    /**
     * @brief Sets the DDO delivery failure policy.
     */
    daas_error_t setDDOPolicy(ddo_policy_t policy);

    /**
     * @brief Configures a DaaS API option.
     */
    daas_error_t setOptions(option_t option, uint32_t val);

    /**
     * @brief Unbinds the local node from the current network.
     */
    daas_error_t unbindNetwork();

    // ---------------------------------------------------------------------
    // Mapping / Discovery / DDO Communication
    // ---------------------------------------------------------------------

    /**
     * @brief Maps a node DIN.
     */
    daas_error_t map(din_t din);

    /**
     * @brief Maps a node with specific link and URI.
     */
    daas_error_t map(din_t din, link_t link, const char* uri);

    /**
     * @brief Maps a node with link, URI and security key.
     */
    daas_error_t map(din_t din, link_t link, const char* uri, const char* securityKey);

    /**
     * @brief Removes a node from the mapping.
     */
    daas_error_t remove(din_t din);

    /**
    * @brief Locates a remote node by DIN.
    *
    * @param din Remote node DIN to locate.
    * @param timeout Timeout in milliseconds. Defaults to 1000.
    * @param ttl Maximum number of intermediate hops. Defaults to 10.
    */
    daas_error_t locate(din_t din, int timeout = 1000, int ttl = 10);

    /**
     * @brief Performs network discovery using all available links.
     */
    daas_error_t discovery();

    /**
     * @brief Performs network discovery using a specific link.
     */
    daas_error_t discovery(link_t link);

    /**
     * @brief Performs network discovery for a specific Service ID.
     */
    daas_error_t discovery(din_t sid);

    /**
     * @brief Sends the local node status to a remote node.
     */
    daas_error_t sendStatus(din_t din);

    /**
     * @brief Checks for available DDOs from a specific node.
     */
    daas_error_t availablesPull(din_t din, uint32_t& count);

    /**
     * @brief Receives a DDO from a remote node.
     * @param din Sender DIN.
     * @param inboundDDO Output pointer.
     *
     * @warning Ownership and lifetime follow the underlying DaasAPI behavior.
     */
    daas_error_t pull(din_t din, DDO** inboundDDO);

    /**
     * @brief Sends a DDO to a remote node.
     * @param din Destination DIN.
     * @param outboundDDO Pointer to DDO. Must remain valid during call.
     */
    daas_error_t push(din_t din, DDO* outboundDDO);

    // ---------------------------------------------------------------------
    // Real-time Stream API
    // ---------------------------------------------------------------------

    /**
     * @brief Starts a real-time session with a remote node.
     */
    bool use(
        din_t din,
        uint32_t rx_queue_size = 0,
        uint32_t retry = 3,
        uint32_t timeout = 1000
    );

    /**
     * @brief Ends a real-time session with a remote node.
     */
    bool end(din_t din);

    /**
     * @brief Sends raw data to a remote node in a real-time session.
     */
    uint32_t send(
        din_t din,
        uint8_t* outbound,
        uint32_t size,
        uint32_t timeout = 1000,
        uint32_t retry = 3
    );

    /**
     * @brief Checks whether real-time data is available from a remote node.
     */
    uint32_t received(din_t din);

    /**
     * @brief Receives raw data from a remote node in a real-time session.
     *
     * @warning The returned pointer lifetime follows the underlying DaasAPI behavior.
     */
    uint32_t receive(din_t din, uint8_t*& inbound);

    // ---------------------------------------------------------------------
    // Typesets
    // ---------------------------------------------------------------------

    /**
     * @brief Returns the list of user-defined typesets as a standard C++ vector.
     *
     * @details Useful for pybind11 bindings because the native list type is a custom Vector<T>.
     */
    std::vector<typeset_t> listTypesetsVector();

    /**
     * @brief Registers a user-defined typeset handler.
     *
     * @warning This uses a C function pointer and is not directly Python-friendly.
     */
    daas_error_t addTypeset(uint16_t typeset_code, typeset_fun fun);

    // ---------------------------------------------------------------------
    // Diagnostic
    // ---------------------------------------------------------------------

    /**
     * @brief Performs a DPERF throughput test.
     */
    daas_error_t frisbeeDPERF(
        din_t din,
        uint32_t packets = 10,
        uint32_t block_size = 1048576,
        uint32_t sender_trip_period = 0
    );

    /**
     * @brief Returns the result of the last DPERF throughput test.
     */
    dperf_info_result getFrisbeeResultDPERF();

    /**
     * @brief Performs an ICMP-like ping test.
     */
    daas_error_t frisbeeICMP(din_t din, uint32_t timeout, uint32_t retry);

    /**
     * @brief Sets a new event handler pointer on the wrapper side.
     *
     * @warning DaasAPI v0.22.0 does not expose a runtime event-handler setter.
     * This method updates only the wrapper-side pointer and does not reconfigure
     * the already-created DaasAPI instance.
     */
    void setEventHandler(IDaasApiEvent* event);

    // ---------------------------------------------------------------------
    // Safe-by-default helpers for DDO payload
    // ---------------------------------------------------------------------

    /**
     * @brief Returns the DDO payload as std::string with exact binary size.
     */
    std::string ddoPayloadAsString(DDO& ddo);

    /**
     * @brief Returns the DDO payload as a NUL-terminated copy.
     */
    std::string ddoPayloadAsCString(DDO& ddo);

    /**
     * @brief Returns a hexadecimal representation of the payload.
     */
    std::string ddoPayloadAsHex(DDO& ddo, size_t max_bytes = 0);
};

} // namespace api
} // namespace daas

#endif // DAAS_WRAPPER_H