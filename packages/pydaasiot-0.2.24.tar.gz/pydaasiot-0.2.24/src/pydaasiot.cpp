/**
 * @file pydaasiot_bindings.cpp
 * @brief Python bindings for DaaS-IoT SDK v0.22.0.
 * Integrated with numpy support, safe payload helpers, stream helpers,
 * diagnostics, policies, discovery, features, join/request APIs, and updated event trampoline.
 */

#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <pybind11/numpy.h>

#include <cstdint>
#include <sstream>
#include <string>
#include <vector>

#include "daaswrapper.h"

namespace py = pybind11;
using namespace daas::api;

/**
 * @class PyIDaasApiEvent
 * @brief Trampoline class for libdaas v0.22.0 event callbacks.
 */
class PyIDaasApiEvent : public IDaasApiEvent {
public:
    using IDaasApiEvent::IDaasApiEvent;

    void dinAccepted(din_t din) override {
        PYBIND11_OVERRIDE_PURE(void, IDaasApiEvent, dinAccepted, din);
    }

    void ddoReceived(int payload_size, typeset_t t, din_t din) override {
        PYBIND11_OVERRIDE_PURE(void, IDaasApiEvent, ddoReceived, payload_size, t, din);
    }

    void frisbeeReceived(din_t din) override {
        PYBIND11_OVERRIDE_PURE(void, IDaasApiEvent, frisbeeReceived, din);
    }

    void nodeStateReceived(din_t din) override {
        PYBIND11_OVERRIDE_PURE(void, IDaasApiEvent, nodeStateReceived, din);
    }

    void atsSyncCompleted(din_t din) override {
        PYBIND11_OVERRIDE_PURE(void, IDaasApiEvent, atsSyncCompleted, din);
    }

    void frisbeeDperfCompleted(din_t din, uint32_t packets_sent, uint32_t block_size) override {
        PYBIND11_OVERRIDE_PURE(
            void,
            IDaasApiEvent,
            frisbeeDperfCompleted,
            din,
            packets_sent,
            block_size
        );
    }

    void networkDiscovered(din_t din, din_t sid, link_t link) override {
        PYBIND11_OVERRIDE_PURE(void, IDaasApiEvent, networkDiscovered, din, sid, link);
    }

    void nodeConnectedToNetwork(din_t sid, din_t din) override {
        PYBIND11_OVERRIDE_PURE(void, IDaasApiEvent, nodeConnectedToNetwork, sid, din);
    }

    void streamInfoReceived(din_t din, stream_type pkt_type, uint32_t stream_id) override {
        PYBIND11_OVERRIDE_PURE(
            void,
            IDaasApiEvent,
            streamInfoReceived,
            din,
            pkt_type,
            stream_id
        );
    }
};

PYBIND11_MODULE(pydaasiot, m) {
    m.doc() = "Python bindings for libdaas.a v0.22.0 (DaaS-IoT SDK)";

    // ---------------------------------------------------------------------
    // Enums
    // ---------------------------------------------------------------------

    py::enum_<daas_error_t>(m, "daas_error_t")
        .value("ERROR_NONE", ERROR_NONE)
        .value("ERROR_CORE_ALREADY_INITIALIZED", ERROR_CORE_ALREADY_INITIALIZED)
        .value("ERROR_CORE_STOPPED", ERROR_CORE_STOPPED)
        .value("ERROR_CANNOT_INITIALIZE", ERROR_CANNOT_INITIALIZE)
        .value("ERROR_CANNOT_CREATE_NODE", ERROR_CANNOT_CREATE_NODE)
        .value("ERROR_DIN_ALREADY_EXIST", ERROR_DIN_ALREADY_EXIST)
        .value("ERROR_CANNOT_MAP_NODE", ERROR_CANNOT_MAP_NODE)
        .value("ERROR_INVALID_USER_TYPESET", ERROR_INVALID_USER_TYPESET)
        .value("ERROR_SEND_DDO", ERROR_SEND_DDO)
        .value("ERROR_NO_DDO_PRESENT", ERROR_NO_DDO_PRESENT)
        .value("ERROR_DIN_UNKNOWN", ERROR_DIN_UNKNOWN)
        .value("ERROR_CHANNEL_FAILURE", ERROR_CHANNEL_FAILURE)
        .value("ERROR_ATS_NOT_SYNCED", ERROR_ATS_NOT_SYNCED)
        .value("ERROR_DISCOVERY_DISABLED", ERROR_DISCOVERY_DISABLED)
        .value("ERROR_POLICY_STRICT_ENABLED", ERROR_POLICY_STRICT_ENABLED)
        .value("ERROR_INVALID_DME", ERROR_INVALID_DME)
        .value("ERROR_THREADS_ALREADY_STARTED", ERROR_THREADS_ALREADY_STARTED)
        .value("ERROR_NOT_IMPLEMENTED", ERROR_NOT_IMPLEMENTED)
        .value("ERROR_TX_QUEUE_FULL", ERROR_TX_QUEUE_FULL)
        .value("ERROR_UNKNOWN", ERROR_UNKNOWN)
        .export_values();

    py::enum_<link_t>(m, "link_t")
        .value("_LINK_NONE", _LINK_NONE)
        .value("_LINK_DAAS", _LINK_DAAS)
        .value("_LINK_INET4", _LINK_INET4)
        .value("_LINK_BLE", _LINK_BLE)
        .value("_LINK_MQTT5", _LINK_MQTT5)
        .value("_LINK_UART", _LINK_UART)
        .value("_LINK_LORA", _LINK_LORA)
        .value("_LINK_ZIGBEE", _LINK_ZIGBEE)
        .value("_LINK_RAW", _LINK_RAW)
        .value("MAX_LINKS", MAX_LINKS)
        .export_values();

    py::enum_<performs_mode_t>(m, "performs_mode_t")
        .value("PERFORM_CORE_THREAD", PERFORM_CORE_THREAD)
        .value("PERFORM_CORE_NO_THREAD", PERFORM_CORE_NO_THREAD)
        .export_values();

    py::enum_<discovery_state_t>(m, "discovery_state_t")
        .value("discovery_off", discovery_off)
        .value("discovery_sender_only", discovery_sender_only)
        .value("discovery_receiver_only", discovery_receiver_only)
        .value("discovery_full", discovery_full)
        .export_values();

    py::enum_<ddo_policy_t>(m, "ddo_policy_t")
        .value("ddo_policy_skip_on_failure", ddo_policy_skip_on_failure)
        .value("ddo_policy_retry_on_failure", ddo_policy_retry_on_failure)
        .value(
            "ddo_policy_exponential_backoff_retry_on_failure",
            ddo_policy_exponential_backoff_retry_on_failure
        )
        .export_values();

    py::enum_<option_t>(m, "option_t")
        .value("option_set_ddo_rx_buffer_size", option_set_ddo_rx_buffer_size)
        .value("option_set_ddo_tx_buffer_size", option_set_ddo_tx_buffer_size)
        .value("option_set_rt_buffer_size", option_set_rt_buffer_size)
        .value("option_set_max_ddo_retry", option_set_max_ddo_retry)
        .value("option_enable_auto_route_on_push_failure", option_enable_auto_route_on_push_failure)
        .value("option_set_route_timeout", option_set_route_timeout)
        .value("option_set_route_ttl", option_set_route_ttl)
        .value("option_set_packet_status_queue_size", option_set_packet_status_queue_size)
        .value("option_set_fetch_timeout", option_set_fetch_timeout)
        .export_values();

    py::enum_<accept_request_policy_t>(m, "accept_request_policy_t")
        .value("trust_none", trust_none)
        .value("trust_mapped_only", trust_mapped_only)
        .value("trust_mapped_and_same_network", trust_mapped_and_same_network)
        .value("trust_mapped_and_routed", trust_mapped_and_routed)
        .value(
            "trust_mapped_and_routed_and_same_network",
            trust_mapped_and_routed_and_same_network
        )
        .value("trust_all", trust_all)
        .export_values();

    py::enum_<stream_type>(m, "stream_type")
        .value("STREAM_OPEN", STREAM_OPEN)
        .value("STREAM_DATA", STREAM_DATA)
        .value("STREAM_CLOSE", STREAM_CLOSE)
        .export_values();

    py::enum_<syscode_t>(m, "syscode_t")
        .value("___undefined", ___undefined)
        .value("_cor_dme_sended", _cor_dme_sended)
        .value("_cor_dme_received", _cor_dme_received)
        .value("_cor_dme_routed", _cor_dme_routed)
        .value("_cor_rx_buffer_count", _cor_rx_buffer_count)
        .value("_cor_tx_buffer_count", _cor_tx_buffer_count)
        .value("_cor_rx_buffer_size", _cor_rx_buffer_size)
        .value("_cor_tx_buffer_size", _cor_tx_buffer_size)
        .value("_ats_delta_avg", _ats_delta_avg)
        .value("_ats_sync_counter", _ats_sync_counter)
        .value("_ats_msg_decoded", _ats_msg_decoded)
        .value("_ats_msg_encoded", _ats_msg_encoded)
        .export_values();

    // ---------------------------------------------------------------------
    // Structs
    // ---------------------------------------------------------------------

    py::class_<dperf_info_result>(m, "dperf_info_result")
        .def_readonly("sender_first_timestamp", &dperf_info_result::sender_first_timestamp)
        .def_readonly("local_end_timestamp", &dperf_info_result::local_end_timestamp)
        .def_readonly("remote_first_timestamp", &dperf_info_result::remote_first_timestamp)
        .def_readonly("remote_last_timestamp", &dperf_info_result::remote_last_timestamp)
        .def_readonly("remote_pkt_counter", &dperf_info_result::remote_pkt_counter)
        .def_readonly("remote_data_counter", &dperf_info_result::remote_data_counter)
        .def("__repr__", [](const dperf_info_result& r) {
            std::ostringstream oss;
            oss << "<pydaasiot.dperf_info_result "
                << "remote_pkt_counter=" << r.remote_pkt_counter
                << " remote_data_counter=" << r.remote_data_counter
                << ">";
            return oss.str();
        });

    py::class_<node_info_t>(m, "node_info_t")
        .def_readonly("power_on_time", &node_info_t::power_on_time)
        .def_readonly("linked", &node_info_t::linked)
        .def_readonly("lock", &node_info_t::lock)
        .def_readonly("sklen", &node_info_t::sklen)
        .def_readonly("accept_request_policy", &node_info_t::accept_request_policy)
        .def_readonly("ddo_policy", &node_info_t::ddo_policy)
        .def_readonly("discovery_state", &node_info_t::discovery_state)
        .def_readonly("oCap_net", &node_info_t::oCap_net)
        .def_readonly("net_in_sync", &node_info_t::net_in_sync)
        .def_property_readonly("skey", [](const node_info_t& s) {
            return py::bytes(reinterpret_cast<const char*>(s.skey), sizeof(s.skey));
        })
        .def("__repr__", [](const node_info_t& s) {
            std::ostringstream oss;
            oss << "<pydaasiot.node_info_t "
                << "linked=" << s.linked
                << " net_in_sync=" << (s.net_in_sync ? "true" : "false")
                << ">";
            return oss.str();
        });

    py::class_<node_network_info_t>(m, "node_network_info_t")
        .def("__repr__", [](const node_network_info_t&) {
            return std::string("<pydaasiot.node_network_info_t>");
        });

    py::class_<feature_rq_t>(m, "feature_rq_t")
        .def(py::init<>())
        .def("__repr__", [](const feature_rq_t&) {
            return std::string("<pydaasiot.feature_rq_t>");
        });

    py::class_<InterfaceInfo>(m, "InterfaceInfo")
        .def_readonly("name", &InterfaceInfo::name)
        .def_readonly("type", &InterfaceInfo::type)
        .def_readonly("status", &InterfaceInfo::status)
        .def("__repr__", [](const InterfaceInfo& i) {
            std::ostringstream oss;
            oss << "<pydaasiot.InterfaceInfo "
                << "name=" << i.name
                << " type=" << i.type
                << " status=" << i.status
                << ">";
            return oss.str();
        });

    // ---------------------------------------------------------------------
    // DDO
    // ---------------------------------------------------------------------

    py::class_<DDO>(m, "DDO")
        .def(py::init<>())
        .def(py::init<typeset_t>(), py::arg("typeset"))

        .def("clearPayload", &DDO::clearPayload)
        .def("setTypeset", &DDO::setTypeset)
        .def("getOrigin", &DDO::getOrigin)
        .def("getTypeset", &DDO::getTypeset)
        .def("getTimestamp", &DDO::getTimestamp)
        .def("allocatePayload", &DDO::allocatePayload)
        .def("getPayloadSize", &DDO::getPayloadSize)

        .def("appendPayloadData", [](DDO& self, py::bytes data) {
            std::string buffer = data;
            return self.appendPayloadData(
                buffer.data(),
                static_cast<uint32_t>(buffer.size())
            );
        })

        .def("appendPayloadData", [](DDO& self, py::buffer b) {
            py::buffer_info info = b.request();

            if (info.ndim != 1) {
                throw py::value_error("Expected 1-D buffer");
            }

            return self.appendPayloadData(
                info.ptr,
                static_cast<uint32_t>(info.size * info.itemsize)
            );
        })

        .def("setPayload", [](DDO& self, py::bytes data) {
            std::string buffer = data;
            return self.setPayload(
                buffer.data(),
                static_cast<uint32_t>(buffer.size())
            );
        })

        .def("setPayload", [](DDO& self, py::buffer b) {
            py::buffer_info info = b.request();

            if (info.ndim != 1) {
                throw py::value_error("Expected 1-D buffer");
            }

            return self.setPayload(
                info.ptr,
                static_cast<uint32_t>(info.size * info.itemsize)
            );
        })

        .def("getPayloadAsBinary", [](DDO& self) {
            const uint32_t size = self.getPayloadSize();

            std::vector<uint8_t> buf(size);
            if (size) {
                self.getPayloadAsBinary(buf.data(), 0u, size);
            }

            return py::bytes(reinterpret_cast<const char*>(buf.data()), size);
        })

        .def("payload_bytes", [](DDO& self) {
            const uint32_t size = self.getPayloadSize();

            std::vector<uint8_t> buf(size);
            if (size) {
                self.getPayloadAsBinary(buf.data(), 0u, size);
            }

            return py::bytes(reinterpret_cast<const char*>(buf.data()), size);
        })

        .def("payload_text", [](DDO& self) {
            const uint32_t size = self.getPayloadSize();

            std::string out;
            out.resize(size);

            if (size) {
                self.getPayloadAsBinary(
                    reinterpret_cast<uint8_t*>(out.data()),
                    0u,
                    size
                );
            }

            return out;
        })

        .def("payload_hex", [](DDO& self, size_t max_bytes) {
            const uint32_t n = self.getPayloadSize();

            std::vector<uint8_t> buf(n);
            if (n) {
                self.getPayloadAsBinary(buf.data(), 0u, n);
            }

            const size_t limit = (max_bytes && max_bytes < n) ? max_bytes : n;

            static const char* hex = "0123456789abcdef";

            std::string s;
            s.reserve(limit * 2 + (limit < n ? 3 : 0));

            for (size_t i = 0; i < limit; ++i) {
                s.push_back(hex[(buf[i] >> 4) & 0xF]);
                s.push_back(hex[buf[i] & 0xF]);
            }

            if (limit < n) {
                s += "...";
            }

            return s;
        }, py::arg("max_bytes") = 0)

        .def("__repr__", [](DDO& self) {
            std::ostringstream oss;
            oss << "<pydaasiot.DDO "
                << "typeset=" << self.getTypeset()
                << " origin=" << self.getOrigin()
                << " timestamp=" << self.getTimestamp()
                << " size=" << self.getPayloadSize()
                << ">";
            return oss.str();
        });

    // ---------------------------------------------------------------------
    // IDaasApiEvent
    // ---------------------------------------------------------------------

    py::class_<IDaasApiEvent, PyIDaasApiEvent>(m, "IDaasApiEvent")
        .def(py::init<>(), "Base class for DaaS event handlers");

    // ---------------------------------------------------------------------
    // DaasWrapper
    // ---------------------------------------------------------------------

    py::class_<DaasWrapper>(m, "DaasWrapper")
        .def(
            py::init<const char*, IDaasApiEvent*>(),
            py::arg("config") = nullptr,
            py::arg("eventHandler") = nullptr,
            py::keep_alive<1, 3>()
        )

        // Interfaces
        .def("getActiveInterfaces", &DaasWrapper::getActiveInterfaces)
        .def("listSystemInterfaces", &DaasWrapper::listSystemInterfaces)

        // Lifecycle
        .def("doInit", &DaasWrapper::doInit, py::arg("sid"), py::arg("din"))
        .def(
            "doPerform",
            &DaasWrapper::doPerform,
            py::arg("mode"),
            py::call_guard<py::gil_scoped_release>()
        )
        .def("doEnd", &DaasWrapper::doEnd)
        .def("doReset", &DaasWrapper::doReset)

        .def("getVersion", &DaasWrapper::getVersion)
        .def("getInfos", &DaasWrapper::getInfos)
        .def("errorToString", &DaasWrapper::errorToString)

        // Drivers / setup
        .def("listAvailableDrivers", &DaasWrapper::listAvailableDrivers)
        .def(
            "enableDriver",
            &DaasWrapper::enableDriver,
            py::arg("link"),
            py::arg("driver")
        )
        .def(
            "setupNode",
            py::overload_cast<din_t, din_t, link_t, const char*>(&DaasWrapper::setupNode),
            py::arg("sid"),
            py::arg("din"),
            py::arg("link"),
            py::arg("uri")
        )
        .def(
            "setupNode",
            py::overload_cast<const char*>(&DaasWrapper::setupNode),
            py::arg("setupFilePath")
        )

        // Status / network
        .def("getStatus", &DaasWrapper::getStatus)
        .def(
            "status",
            &DaasWrapper::status,
            py::arg("din"),
            py::return_value_policy::reference_internal
        )
        .def(
            "fetch",
            &DaasWrapper::fetch,
            py::arg("din"),
            py::arg("opts"),
            py::return_value_policy::reference_internal
        )
        .def("listNodes", &DaasWrapper::listNodesVector)
        .def("getAllNodes", &DaasWrapper::getAllNodesVector, py::arg("sid"))

        // getNodeList() is intentionally not bound yet because node_map_list_t
        // is a native libdaas custom list type and the element fields are not
        // exposed in this binding.

        // Configuration storage: IDepot is not exposed in this binding.
        // storeConfiguration/loadConfiguration are intentionally not bound.

        // Statistics / time
        .def("doStatisticsReset", &DaasWrapper::doStatisticsReset)
        .def(
            "getSystemStatistics",
            &DaasWrapper::getSystemStatistics,
            py::arg("label")
        )
        .def("getSyncedTimestamp", &DaasWrapper::getSyncedTimestamp)

        // Features / join / requests
        .def(
            "addNodeFeatures",
            [](DaasWrapper& self, uint64_t features) {
                return self.addNodeFeatures(static_cast<feature_t>(features));
            },
            py::arg("features")
        )
        .def("getNodeFeatures", [](DaasWrapper& self) {
            std::vector<feature_t> features = self.getNodeFeaturesVector();

            std::vector<uint64_t> out;
            out.reserve(features.size());

            for (uint32_t i = 0; i < features.size(); ++i) {
                out.push_back(static_cast<uint64_t>(features[i]));
            }

            return out;
        })
        .def(
            "join",
            &DaasWrapper::join,
            py::arg("sid") = 0,
            py::arg("link") = _LINK_NONE,
            py::arg("timeout") = 5000
        )
        .def(
            "nodeHasFeature",
            [](DaasWrapper& self, din_t din, uint64_t feature) {
                return self.nodeHasFeature(din, static_cast<feature_t>(feature));
            },
            py::arg("din"),
            py::arg("feature")
        )
        /*.def(
            "requestFeature",
            &DaasWrapper::requestFeature,
            py::arg("din"),
            py::arg("request"),
            py::arg("timeout") = 1000
        )*/

        // Policy / options
        .def(
            "setAcceptRequestsLevel",
            &DaasWrapper::setAcceptRequestsLevel,
            py::arg("policy_level")
        )
        .def(
            "setDiscoveryState",
            &DaasWrapper::setDiscoveryState,
            py::arg("mode")
        )
        .def(
            "setDDOPolicy",
            &DaasWrapper::setDDOPolicy,
            py::arg("policy")
        )
        .def(
            "setOptions",
            &DaasWrapper::setOptions,
            py::arg("option"),
            py::arg("val")
        )
        .def("unbindNetwork", &DaasWrapper::unbindNetwork)

        // Mapping
        .def("map", py::overload_cast<din_t>(&DaasWrapper::map), py::arg("din"))
        .def(
            "map",
            py::overload_cast<din_t, link_t, const char*>(&DaasWrapper::map),
            py::arg("din"),
            py::arg("link"),
            py::arg("uri")
        )
        .def(
            "map",
            py::overload_cast<din_t, link_t, const char*, const char*>(&DaasWrapper::map),
            py::arg("din"),
            py::arg("link"),
            py::arg("uri"),
            py::arg("securityKey")
        )
        .def("remove", &DaasWrapper::remove, py::arg("din"))
        .def(
            "locate",
            &DaasWrapper::locate,
            py::arg("din"),
            py::arg("timeout") = 1000,
            py::arg("ttl") = 10
        )

        // Discovery.
        // NOTE:
        // discovery(link_t) and discovery(din_t) are both integral at C++ level.
        // The explicit helper names avoid Python-side ambiguity.
        .def("discovery", py::overload_cast<>(&DaasWrapper::discovery))
        .def(
            "discoveryLink",
            py::overload_cast<link_t>(&DaasWrapper::discovery),
            py::arg("link")
        )
        .def(
            "discoverySid",
            py::overload_cast<din_t>(&DaasWrapper::discovery),
            py::arg("sid")
        )

        // DDO status / transfer
        .def("sendStatus", &DaasWrapper::sendStatus, py::arg("din"))

        .def("availablesPull", [](DaasWrapper& self, din_t din) -> py::tuple {
            uint32_t count = 0;
            daas_error_t err = self.availablesPull(din, count);
            return py::make_tuple(err, count);
        }, py::arg("din"))

        .def("pull", [](DaasWrapper& self, din_t din) -> py::tuple {
            DDO* ddo_ptr = nullptr;
            daas_error_t err = self.pull(din, &ddo_ptr);

            if (err != ERROR_NONE || ddo_ptr == nullptr) {
                return py::make_tuple(err, py::none());
            }

            return py::make_tuple(
                err,
                py::cast(ddo_ptr, py::return_value_policy::reference)
            );
        }, py::arg("din"))

        .def("pullPayload", [](DaasWrapper& self, din_t din) -> py::tuple {
            DDO* ddo_ptr = nullptr;
            daas_error_t err = self.pull(din, &ddo_ptr);

            if (err != ERROR_NONE || ddo_ptr == nullptr) {
                return py::make_tuple(err, py::none(), py::none());
            }

            const uint32_t size = ddo_ptr->getPayloadSize();

            std::vector<uint8_t> buf(size);
            if (size) {
                ddo_ptr->getPayloadAsBinary(buf.data(), 0u, size);
            }

            return py::make_tuple(
                err,
                ddo_ptr->getTypeset(),
                py::bytes(reinterpret_cast<const char*>(buf.data()), size)
            );
        }, py::arg("din"))

        .def(
            "push",
            [](DaasWrapper& self, din_t din, DDO* ddo) {
                return self.push(din, ddo);
            },
            py::arg("din"),
            py::arg("ddo"),
            py::keep_alive<1, 3>()
        )

        // Real-time stream API
        .def(
            "use",
            &DaasWrapper::use,
            py::arg("din"),
            py::arg("rx_queue_size") = 0,
            py::arg("retry") = 3,
            py::arg("timeout") = 1000
        )
        .def("end", &DaasWrapper::end, py::arg("din"))

        .def("send", [](DaasWrapper& self,
                        din_t din,
                        py::bytes data,
                        uint32_t timeout,
                        uint32_t retry) {
            std::string buffer = data;

            return self.send(
                din,
                reinterpret_cast<uint8_t*>(buffer.data()),
                static_cast<uint32_t>(buffer.size()),
                timeout,
                retry
            );
        },
        py::arg("din"),
        py::arg("data"),
        py::arg("timeout") = 1000,
        py::arg("retry") = 3)

        .def("send", [](DaasWrapper& self,
                        din_t din,
                        py::buffer b,
                        uint32_t timeout,
                        uint32_t retry) {
            py::buffer_info info = b.request();

            if (info.ndim != 1) {
                throw py::value_error("Expected 1-D buffer");
            }

            return self.send(
                din,
                reinterpret_cast<uint8_t*>(info.ptr),
                static_cast<uint32_t>(info.size * info.itemsize),
                timeout,
                retry
            );
        },
        py::arg("din"),
        py::arg("data"),
        py::arg("timeout") = 1000,
        py::arg("retry") = 3)

        .def("received", &DaasWrapper::received, py::arg("din"))

        .def("receive", [](DaasWrapper& self, din_t din) {
            uint8_t* inbound = nullptr;
            uint32_t size = self.receive(din, inbound);

            if (size == 0 || inbound == nullptr) {
                return py::bytes();
            }

            return py::bytes(reinterpret_cast<const char*>(inbound), size);
        }, py::arg("din"))

        // Typesets
        .def("listTypesets", &DaasWrapper::listTypesetsVector)

        // addTypeset is intentionally not bound because libdaas expects a C
        // function pointer: using typeset_fun = void(*)(din_t).
        // A Python callback requires a separate trampoline/registry layer.

        // Diagnostics
        .def(
            "frisbeeDPERF",
            &DaasWrapper::frisbeeDPERF,
            py::arg("din"),
            py::arg("packets") = 10,
            py::arg("block_size") = 1048576,
            py::arg("sender_trip_period") = 0
        )
        .def("getFrisbeeResultDPERF", &DaasWrapper::getFrisbeeResultDPERF)
        .def(
            "frisbeeICMP",
            &DaasWrapper::frisbeeICMP,
            py::arg("din"),
            py::arg("timeout"),
            py::arg("retry")
        )

        // Wrapper-side only event handler cache.
        // DaasAPI v0.22.0 does not expose a runtime event-handler setter.
        .def(
            "setEventHandler",
            &DaasWrapper::setEventHandler,
            py::arg("event")
        )

        // Safe DDO helpers
        .def(
            "ddoPayloadAsString",
            &DaasWrapper::ddoPayloadAsString,
            py::arg("ddo")
        )
        .def(
            "ddoPayloadAsCString",
            &DaasWrapper::ddoPayloadAsCString,
            py::arg("ddo")
        )
        .def(
            "ddoPayloadAsHex",
            &DaasWrapper::ddoPayloadAsHex,
            py::arg("ddo"),
            py::arg("max_bytes") = 0
        );
}