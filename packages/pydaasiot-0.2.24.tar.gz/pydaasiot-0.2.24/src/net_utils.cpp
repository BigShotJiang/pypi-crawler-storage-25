#include "net_utils.h"

#include <winsock2.h>
#include <iphlpapi.h>

#include <algorithm>
#include <string>
#include <vector>

#pragma comment(lib, "Iphlpapi.lib")

std::vector<std::string> listSystemNetworkInterfaces() {
    std::vector<std::string> interfaces;

    ULONG bufferSize = 0;

    DWORD result = GetAdaptersAddresses(
        AF_UNSPEC,
        GAA_FLAG_INCLUDE_PREFIX,
        nullptr,
        nullptr,
        &bufferSize
    );

    if (result != ERROR_BUFFER_OVERFLOW) {
        return interfaces;
    }

    std::vector<unsigned char> buffer(bufferSize);

    IP_ADAPTER_ADDRESSES* adapters =
        reinterpret_cast<IP_ADAPTER_ADDRESSES*>(buffer.data());

    result = GetAdaptersAddresses(
        AF_UNSPEC,
        GAA_FLAG_INCLUDE_PREFIX,
        nullptr,
        adapters,
        &bufferSize
    );

    if (result != NO_ERROR) {
        return interfaces;
    }

    for (IP_ADAPTER_ADDRESSES* adapter = adapters; adapter != nullptr; adapter = adapter->Next) {
        if (adapter->OperStatus != IfOperStatusUp) {
            continue;
        }

        if (adapter->AdapterName == nullptr) {
            continue;
        }

        std::string name(adapter->AdapterName);

        if (std::find(interfaces.begin(), interfaces.end(), name) == interfaces.end()) {
            interfaces.push_back(name);
        }
    }

    return interfaces;
}