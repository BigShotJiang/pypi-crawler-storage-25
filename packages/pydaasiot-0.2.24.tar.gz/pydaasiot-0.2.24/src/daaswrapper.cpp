// daasiot/src/daaswrapper.cpp
#include "daaswrapper.h"

#include <algorithm>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <nlohmann/json.hpp>
#include <regex>
#include <set>
#include <sstream>
#include <string>
#include <vector>

using json = nlohmann::json;

#define NODE_LHVER "GNUSDK_V22"

namespace daas {
namespace api {

DaasWrapper::DaasWrapper(const char* /*configPath*/, IDaasApiEvent* handler)
    : eventHandler(handler) {
    daasInstance = new DaasAPI(handler, NODE_LHVER);
}

DaasWrapper::~DaasWrapper() {
    delete daasInstance;
    daasInstance = nullptr;
}

// ------------------------------------
// INTERFACES (Stubs)
// ------------------------------------

std::vector<InterfaceInfo> DaasWrapper::listSystemInterfaces() {
    std::vector<InterfaceInfo> interfaces;
    // TODO: implementare versione cross-platform
    return interfaces;
}

std::vector<std::string> DaasWrapper::getActiveInterfaces() {
    return {};
}

// ------------------------------------
// LIFECYCLE & INFO
// ------------------------------------

daas_error_t DaasWrapper::doInit(din_t sid, din_t din) {
    return daasInstance->doInit(sid, din);
}

daas_error_t DaasWrapper::doPerform(performs_mode_t mode) {
    return daasInstance->doPerform(mode);
}

daas_error_t DaasWrapper::doEnd() {
    return daasInstance->doEnd();
}

daas_error_t DaasWrapper::doReset() {
    return daasInstance->doReset();
}

const char* DaasWrapper::getVersion() {
    return daasInstance->getVersion();
}

const char* DaasWrapper::getInfos() {
    const char* version = daasInstance->getVersion();
    const char* build   = daasInstance->getBuildInfo();

    if (!version) version = "UNKNOWN";
    if (!build)   build   = "UNKNOWN";

    std::snprintf(
        infoBuffer,
        sizeof(infoBuffer),
        "Version: %s | Build: %s",
        version,
        build
    );

    return infoBuffer;
}

const char* DaasWrapper::errorToString(daas_error_t err) {
    return daasInstance->errorToString(err);
}

// ------------------------------------
// DRIVERS & SETUP
// ------------------------------------

const char* DaasWrapper::listAvailableDrivers() {
    return daasInstance->listAvailableDrivers();
}

daas_error_t DaasWrapper::enableDriver(link_t link, const char* driver) {
    return daasInstance->enableDriver(link, driver);
}

daas_error_t DaasWrapper::setupNode(din_t sid, din_t din, link_t link, const char* uri) {
    daas_error_t err = doInit(sid, din);
    if (err != ERROR_NONE) return err;

    err = enableDriver(link, uri);
    return err;
}

daas_error_t DaasWrapper::setupNode(const char* configFilePath) {
    std::ifstream file(configFilePath);
    if (!file.is_open()) return ERROR_UNKNOWN;

    json config;
    try {
        file >> config;
    } catch (...) {
        return ERROR_UNKNOWN;
    }

    if (!config.contains("sid") || !config["sid"].is_number()) return ERROR_INVALID_DME;
    if (!config.contains("din") || !config["din"].is_number()) return ERROR_INVALID_DME;
    if (!config.contains("drivers") || !config["drivers"].is_array()) return ERROR_INVALID_DME;

    din_t sid = static_cast<din_t>(config["sid"].get<uint64_t>());
    din_t din = static_cast<din_t>(config["din"].get<uint64_t>());

    driversCache.clear();

    for (const auto& drv : config["drivers"]) {
        if (drv.contains("link") && drv.contains("uri")) {
            link_t link = static_cast<link_t>(drv["link"].get<int>());
            std::string uri = drv["uri"].get<std::string>();
            driversCache.push_back(DriverConfig{link, uri});
        }
    }

    daas_error_t err = doInit(sid, din);
    if (err != ERROR_NONE) return err;

    for (const auto& drv : driversCache) {
        err = enableDriver(drv.link, drv.uri.c_str());
        if (err != ERROR_NONE) return err;
    }

    return ERROR_NONE;
}

// ------------------------------------
// NETWORK & MAPPING
// ------------------------------------

node_info_t DaasWrapper::getStatus() {
    return daasInstance->getStatus();
}

const node_info_t& DaasWrapper::status(din_t din) {
    return daasInstance->status(din);
}

const node_info_t& DaasWrapper::fetch(din_t din, uint16_t opts) {
    return daasInstance->fetch(din, opts);
}

network_info_list_t DaasWrapper::listNodes() {
    return daasInstance->listNodes();
}

std::vector<node_network_info_t> DaasWrapper::listNodesVector() {
    network_info_list_t nodes = daasInstance->listNodes();

    std::vector<node_network_info_t> out;
    out.reserve(nodes.size());

    for (uint32_t i = 0; i < nodes.size(); ++i) {
        out.push_back(nodes[i]);
    }

    return out;
}

Vector<din_t> DaasWrapper::getAllNodes(din_t sid) {
    return daasInstance->getAllNodes(sid);
}

std::vector<din_t> DaasWrapper::getAllNodesVector(din_t sid) {
    Vector<din_t> nodes = daasInstance->getAllNodes(sid);

    std::vector<din_t> out;
    out.reserve(nodes.size());

    for (uint32_t i = 0; i < nodes.size(); ++i) {
        out.push_back(nodes[i]);
    }

    return out;
}

node_map_list_t DaasWrapper::getNodeList() {
    return daasInstance->getNodeList();
}

bool DaasWrapper::storeConfiguration(IDepot* storage_interface) {
    return daasInstance->storeConfiguration(storage_interface);
}

bool DaasWrapper::loadConfiguration(IDepot* storage_interface) {
    return daasInstance->loadConfiguration(storage_interface);
}

bool DaasWrapper::doStatisticsReset() {
    return daasInstance->doStatisticsReset();
}

uint64_t DaasWrapper::getSystemStatistics(syscode_t label) {
    return daasInstance->getSystemStatistics(label);
}

uint64_t DaasWrapper::getSyncedTimestamp() {
    return daasInstance->getSyncedTimestamp();
}

// ------------------------------------
// FEATURES / JOIN / REQUESTS
// ------------------------------------

daas_error_t DaasWrapper::addNodeFeatures(feature_t features) {
    return daasInstance->addNodeFeatures(features);
}

features_list DaasWrapper::getNodeFeatures() {
    return daasInstance->getNodeFeatures();
}

std::vector<feature_t> DaasWrapper::getNodeFeaturesVector() {
    features_list features = daasInstance->getNodeFeatures();

    std::vector<feature_t> out;
    out.reserve(features.size());

    for (uint32_t i = 0; i < features.size(); ++i) {
        out.push_back(features[i]);
    }

    return out;
}

daas_error_t DaasWrapper::join(din_t sid, link_t link, uint32_t timeout) {
    return daasInstance->join(sid, link, timeout);
}

bool DaasWrapper::nodeHasFeature(din_t din, feature_t feature) {
    return daasInstance->nodeHasFeature(din, feature);
}

/*daas_error_t DaasWrapper::requestFeature(
    din_t din,
    feature_rq_t request,
    uint32_t timeout
) {
    return daasInstance->requestFeature(din, request, timeout);
}*/

// ------------------------------------
// POLICY / OPTIONS
// ------------------------------------

void DaasWrapper::setAcceptRequestsLevel(accept_request_policy_t policy_level) {
    daasInstance->setAcceptRequestsLevel(policy_level);
}

void DaasWrapper::setDiscoveryState(discovery_state_t mode) {
    daasInstance->setDiscoveryState(mode);
}

daas_error_t DaasWrapper::setDDOPolicy(ddo_policy_t policy) {
    return daasInstance->setDDOPolicy(policy);
}

daas_error_t DaasWrapper::setOptions(option_t option, uint32_t val) {
    return daasInstance->setOptions(option, val);
}

daas_error_t DaasWrapper::unbindNetwork() {
    return daasInstance->unbindNetwork();
}

// ------------------------------------
// MAPPING / DISCOVERY / DDO COMMUNICATION
// ------------------------------------

daas_error_t DaasWrapper::map(din_t din) {
    return daasInstance->map(din);
}

daas_error_t DaasWrapper::map(din_t din, link_t link, const char* uri) {
    return daasInstance->map(din, link, uri);
}

daas_error_t DaasWrapper::map(din_t din, link_t link, const char* uri, const char* securityKey) {
    return daasInstance->map(din, link, uri, securityKey);
}

daas_error_t DaasWrapper::remove(din_t din) {
    return daasInstance->remove(din);
}

daas_error_t DaasWrapper::locate(din_t din, int timeout, int ttl) {
    return daasInstance->locate(din, timeout, ttl);
}

daas_error_t DaasWrapper::discovery() {
    return daasInstance->discovery();
}

daas_error_t DaasWrapper::discovery(link_t link) {
    return daasInstance->discovery(link);
}

daas_error_t DaasWrapper::discovery(din_t sid) {
    return daasInstance->discovery(sid);
}

daas_error_t DaasWrapper::sendStatus(din_t din) {
    return daasInstance->sendStatus(din);
}

daas_error_t DaasWrapper::availablesPull(din_t din, uint32_t& count) {
    return daasInstance->availablesPull(din, count);
}

daas_error_t DaasWrapper::pull(din_t din, DDO** inboundDDO) {
    return daasInstance->pull(din, inboundDDO);
}

daas_error_t DaasWrapper::push(din_t din, DDO* outboundDDO) {
    return daasInstance->push(din, outboundDDO);
}

// ------------------------------------
// REAL-TIME STREAM API
// ------------------------------------

bool DaasWrapper::use(
    din_t din,
    uint32_t rx_queue_size,
    uint32_t retry,
    uint32_t timeout
) {
    return daasInstance->use(din, rx_queue_size, retry, timeout);
}

bool DaasWrapper::end(din_t din) {
    return daasInstance->end(din);
}

uint32_t DaasWrapper::send(
    din_t din,
    uint8_t* outbound,
    uint32_t size,
    uint32_t timeout,
    uint32_t retry
) {
    return daasInstance->send(din, outbound, size, timeout, retry);
}

uint32_t DaasWrapper::received(din_t din) {
    return daasInstance->received(din);
}

uint32_t DaasWrapper::receive(din_t din, uint8_t*& inbound) {
    return daasInstance->receive(din, inbound);
}

// ------------------------------------
// TYPESETS
// ------------------------------------

std::vector<typeset_t> DaasWrapper::listTypesetsVector() {
    auto& typesets = daasInstance->listTypesets();

    std::vector<typeset_t> out;
    out.reserve(typesets.size());

    for (uint32_t i = 0; i < typesets.size(); ++i) {
        out.push_back(typesets[i]);
    }

    return out;
}

daas_error_t DaasWrapper::addTypeset(uint16_t typeset_code, typeset_fun fun) {
    return daasInstance->addTypeset(typeset_code, fun);
}

// ------------------------------------
// DIAGNOSTIC
// ------------------------------------

daas_error_t DaasWrapper::frisbeeDPERF(
    din_t din,
    uint32_t packets,
    uint32_t block_size,
    uint32_t sender_trip_period
) {
    return daasInstance->frisbeeDPERF(
        din,
        packets,
        block_size,
        sender_trip_period
    );
}

dperf_info_result DaasWrapper::getFrisbeeResultDPERF() {
    return daasInstance->getFrisbeeResultDPERF();
}

daas_error_t DaasWrapper::frisbeeICMP(din_t din, uint32_t timeout, uint32_t retry) {
    return daasInstance->frisbeeICMP(din, timeout, retry);
}

void DaasWrapper::setEventHandler(IDaasApiEvent* handler) {
    this->eventHandler = handler;
}

// ------------------------------------
// SAFE HELPERS
// ------------------------------------

std::string DaasWrapper::ddoPayloadAsString(DDO& ddo) {
    const uint32_t n = ddo.getPayloadSize();

    std::string out;
    out.resize(n);

    if (n) {
        ddo.getPayloadAsBinary(
            reinterpret_cast<uint8_t*>(out.data()),
            0u,
            n
        );
    }

    return out;
}

std::string DaasWrapper::ddoPayloadAsCString(DDO& ddo) {
    std::string s = ddoPayloadAsString(ddo);
    s.push_back('\0');
    return s;
}

std::string DaasWrapper::ddoPayloadAsHex(DDO& ddo, size_t max_bytes) {
    const uint32_t n = ddo.getPayloadSize();

    std::vector<uint8_t> buf(n);
    if (n) {
        ddo.getPayloadAsBinary(buf.data(), 0u, n);
    }

    const size_t limit = (max_bytes && max_bytes < buf.size())
        ? max_bytes
        : buf.size();

    static const char* hex = "0123456789abcdef";

    std::string s;
    s.reserve(limit * 2 + (limit < buf.size() ? 3 : 0));

    for (size_t i = 0; i < limit; ++i) {
        s.push_back(hex[(buf[i] >> 4) & 0xF]);
        s.push_back(hex[buf[i] & 0xF]);
    }

    if (limit < buf.size()) {
        s += "...";
    }

    return s;
}

} // namespace api
} // namespace daas