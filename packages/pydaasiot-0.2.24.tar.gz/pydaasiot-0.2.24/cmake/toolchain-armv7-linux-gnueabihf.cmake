# cmake/toolchain-armv7-linux-gnueabihf.cmake
# Toolchain per cross-compilare verso ARMv7 (hard-float) su Ubuntu con gcc-arm-linux-gnueabihf

set(CMAKE_SYSTEM_NAME Linux)
set(CMAKE_SYSTEM_PROCESSOR arm)

# Compilatori cross
set(CMAKE_C_COMPILER   arm-linux-gnueabihf-gcc)
set(CMAKE_CXX_COMPILER arm-linux-gnueabihf-g++)

# Flag tipici per ARMv7 hard-float (adatta se serve un target specifico)
set(CMAKE_C_FLAGS_INIT   "-march=armv7-a -mfpu=neon -mfloat-abi=hard")
set(CMAKE_CXX_FLAGS_INIT "-march=armv7-a -mfpu=neon -mfloat-abi=hard")

# Lasciamo che CMake usi i path impliciti del toolchain (multiarch Ubuntu)
# quindi NON impostiamo CMAKE_FIND_ROOT_PATH_* in modo aggressivo.
