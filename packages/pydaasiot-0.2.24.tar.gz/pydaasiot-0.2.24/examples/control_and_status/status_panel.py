import sys
import argparse
import pydaasiot

from PyQt6.QtCore import QObject, pyqtSignal, Qt
from PyQt6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QFrame,
    QGridLayout,
)

# ==========================
# TYPESET & ALERT CONSTANTS
# ==========================

TS_POWER_CMD   = 10
TS_ALERT_CMD   = 11
TS_MESSAGE_CMD = 12

ALERT_NONE = 0
ALERT_WARNING = 1
ALERT_CRITICAL = 2


# ==========================
# SIGNALS
# ==========================

class StatusSignals(QObject):
    power_changed = pyqtSignal(bool)
    alert_changed = pyqtSignal(int)
    message_changed = pyqtSignal(str)


# ==========================
# HANDLER RICEZIONE
# ==========================

class StatusEventHandler(pydaasiot.IDaasApiEvent):
    def __init__(self, signals: StatusSignals):
        super().__init__()
        self.signals = signals
        self.node = None

    def dinAcceptedEvent(self, din):
        print(f"[EVENT] DIN accepted: {din}")

    def ddoReceivedEvent(self, payload_size, typeset, din):
        print(f"[EVENT] DDO received: din={din}, size={payload_size}, ts={typeset}")

        if self.node is None:
            print("[WARN] node non impostato nel handler")
            return

        try:
            err, ddo = self.node.pull(din)
            if err != pydaasiot.daas_error_t.ERROR_NONE or ddo is None:
                print(f"[PULL] error={err}")
                return

            # typeset lo prendiamo dal parametro del callback
            ts = typeset

            if ts == TS_POWER_CMD:
                raw = ddo.payload_text()
                print(f"[DEBUG] POWER raw payload_text = {repr(raw)}")

                s = raw.strip()
                # prendiamo solo il primo carattere “utile”
                is_on = False
                if s:
                    first = s[0]
                    is_on = (first == "1")

                print(f"[STATUS] POWER -> {is_on}")
                self.signals.power_changed.emit(is_on)



            elif ts == TS_ALERT_CMD:
                raw = ddo.payload_text()
                print(f"[DEBUG] ALERT raw payload_text = {repr(raw)}")
                s = raw.strip()
                level = ALERT_NONE
                if s:
                    first = s[0]
                    if first == "1":
                        level = ALERT_WARNING
                    elif first == "2":
                        level = ALERT_CRITICAL
                    else:
                        level = ALERT_NONE
                print(f"[STATUS] ALERT -> {level}")
                self.signals.alert_changed.emit(level)


            elif ts == TS_MESSAGE_CMD:
                try:
                    msg = ddo.payload_text()
                except Exception as e:
                    print(f"[ERROR] payload_text failed: {e}")
                    msg = "<invalid message>"
                print(f"[STATUS] MESSAGE -> {msg}")
                self.signals.message_changed.emit(msg)

        except Exception as e:
            import traceback
            print("[ERROR] Exception in ddoReceivedEvent:")
            traceback.print_exc()

    def frisbeeReceivedEvent(self, din):
        print(f"[EVENT] FRISBEE from DIN {din}")

    def nodeStateReceivedEvent(self, din):
        print(f"[EVENT] Node state received from DIN {din}")

    def atsSyncCompleted(self, din):
        print(f"[EVENT] ATS sync completed for DIN {din}")

    def frisbeeDperfCompleted(self, din, packets_sent, block_size):
        print(f"[EVENT] Frisbee dperf completed: din={din}, pkt={packets_sent}, block={block_size}")


# ==========================
# GUI StatusWindow
# ==========================

class StatusWindow(QMainWindow):
    def __init__(self, node: pydaasiot.DaasWrapper, signals: StatusSignals,
                 sid: int, local_din: int, local_addr: str,
                 remote_din: int, remote_addr: str,
                 parent=None):
        super().__init__(parent)
        self.node = node
        self.sid = sid
        self.local_din = local_din
        self.local_addr = local_addr
        self.remote_din = remote_din
        self.remote_addr = remote_addr

        self.setWindowTitle(
            f"DaaS Status Panel  •  SID {sid}  •  DIN {local_din}"
        )
        self.resize(520, 380)

        central = QWidget()
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(14, 14, 14, 14)
        main_layout.setSpacing(12)

        # ==========================
        # HEADER
        # ==========================

        header_frame = QFrame()
        header_frame.setObjectName("headerFrame")
        header_layout = QGridLayout(header_frame)
        header_layout.setContentsMargins(10, 10, 10, 10)
        header_layout.setHorizontalSpacing(20)
        header_layout.setVerticalSpacing(4)

        title_label = QLabel("DaaS-IoT Device Status")
        title_label.setObjectName("titleLabel")

        tag_local = QLabel("DEVICE NODE")
        tag_local.setObjectName("tagLocal")
        tag_remote = QLabel("CONTROLLER NODE")
        tag_remote.setObjectName("tagRemote")

        local_din_label = QLabel(f"DIN {local_din}")
        local_din_label.setObjectName("dinLabel")
        local_addr_label = QLabel(f"{local_addr}")
        local_addr_label.setObjectName("addrLabel")

        remote_din_label = QLabel(f"DIN {remote_din}")
        remote_din_label.setObjectName("dinLabel")
        remote_addr_label = QLabel(f"{remote_addr}")
        remote_addr_label.setObjectName("addrLabel")

        sid_label = QLabel(f"SID {sid}")
        sid_label.setObjectName("sidLabel")

        header_layout.addWidget(title_label, 0, 0, 1, 2)
        header_layout.addWidget(sid_label, 0, 2, 1, 1, Qt.AlignmentFlag.AlignRight)

        header_layout.addWidget(tag_local, 1, 0)
        header_layout.addWidget(local_din_label, 2, 0)
        header_layout.addWidget(local_addr_label, 3, 0)

        header_layout.addWidget(tag_remote, 1, 1)
        header_layout.addWidget(remote_din_label, 2, 1)
        header_layout.addWidget(remote_addr_label, 3, 1)

        header_layout.setColumnStretch(0, 1)
        header_layout.setColumnStretch(1, 1)
        header_layout.setColumnStretch(2, 0)

        main_layout.addWidget(header_frame)

        # ==========================
        # POWER INDICATOR
        # ==========================

        power_frame = QFrame()
        power_frame.setObjectName("sectionFrame")
        power_layout = QHBoxLayout(power_frame)
        power_layout.setContentsMargins(10, 10, 10, 10)
        power_layout.setSpacing(10)

        power_label = QLabel("Power")
        power_label.setObjectName("sectionLabel")

        self.power_indicator = QFrame()
        self.power_indicator.setObjectName("powerIndicator")
        self.power_indicator.setFixedSize(40, 40)

        power_state_label = QLabel("OFF")
        power_state_label.setObjectName("powerText")
        self.power_state_label = power_state_label

        power_layout.addWidget(power_label)
        power_layout.addStretch(1)
        power_layout.addWidget(self.power_state_label)
        power_layout.addWidget(self.power_indicator)

        main_layout.addWidget(power_frame)

        # ==========================
        # ALERT INDICATOR
        # ==========================

        alert_frame = QFrame()
        alert_frame.setObjectName("sectionFrame")
        alert_layout = QHBoxLayout(alert_frame)
        alert_layout.setContentsMargins(10, 10, 10, 10)
        alert_layout.setSpacing(10)

        alert_label = QLabel("Alert")
        alert_label.setObjectName("sectionLabel")

        self.alert_badge = QLabel("NONE")
        self.alert_badge.setObjectName("alertBadge")
        self.alert_badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.alert_badge.setMinimumWidth(90)

        alert_layout.addWidget(alert_label)
        alert_layout.addStretch(1)
        alert_layout.addWidget(self.alert_badge)

        main_layout.addWidget(alert_frame)

        # ==========================
        # MESSAGE DISPLAY
        # ==========================

        msg_frame = QFrame()
        msg_frame.setObjectName("sectionFrame")
        msg_layout = QVBoxLayout(msg_frame)
        msg_layout.setContentsMargins(10, 10, 10, 10)
        msg_layout.setSpacing(8)

        msg_label = QLabel("Last message")
        msg_label.setObjectName("sectionLabel")

        self.message_label = QLabel("—")
        self.message_label.setObjectName("messageText")
        self.message_label.setWordWrap(True)

        msg_layout.addWidget(msg_label)
        msg_layout.addWidget(self.message_label)

        main_layout.addWidget(msg_frame)
        main_layout.addStretch(1)

        self.setCentralWidget(central)

        # ==========
        # COLLEGA SIGNALS
        # ==========
        signals.power_changed.connect(self.on_power_changed)
        signals.alert_changed.connect(self.on_alert_changed)
        signals.message_changed.connect(self.on_message_changed)

        # Stato iniziale
        self.update_power(False)
        self.update_alert(ALERT_NONE)

    # ==========
    # UPDATE LOGIC
    # ==========

    def update_power(self, is_on: bool):
        self.power_indicator.setProperty("powerState", "on" if is_on else "off")
        self.power_state_label.setText("ON" if is_on else "OFF")

        self.power_indicator.style().unpolish(self.power_indicator)
        self.power_indicator.style().polish(self.power_indicator)

    def update_alert(self, level: int):
        if level == ALERT_WARNING:
            text = "WARNING"
            state = "warning"
        elif level == ALERT_CRITICAL:
            text = "CRITICAL"
            state = "critical"
        else:
            text = "NONE"
            state = "none"

        self.alert_badge.setText(text)
        self.alert_badge.setProperty("alertState", state)
        self.alert_badge.style().unpolish(self.alert_badge)
        self.alert_badge.style().polish(self.alert_badge)

    # ==========
    # SLOT GUI
    # ==========

    def on_power_changed(self, is_on: bool):
        self.update_power(is_on)

    def on_alert_changed(self, level: int):
        self.update_alert(level)

    def on_message_changed(self, text: str):
        self.message_label.setText(text)


# ==========================
# PARSING ARGOMENTI
# ==========================

def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        description="DaaS-IoT Status Panel (PyQt + pydaasiot)"
    )
    parser.add_argument("--sid", type=int, default=100, help="SID del nodo locale (default: 100)")
    parser.add_argument("--local-din", type=int, required=True, help="DIN del nodo locale (device)")
    parser.add_argument("--local-addr", type=str, required=True, help='Indirizzo locale, es: "127.0.0.1:2223"')
    parser.add_argument("--remote-din", type=int, required=True, help="DIN del nodo remoto (controller)")
    parser.add_argument("--remote-addr", type=str, required=True, help='Indirizzo peer, es: "127.0.0.1:2222"')
    parser.add_argument("--config", type=str, default="config.json", help='Path al config DaaS (default: "config.json")')
    return parser.parse_args(argv)


# ==========================
# MAIN
# ==========================

def main(argv=None):
    args = parse_args(argv)

    print("=== DaaS Status Panel ===")
    print(f"  SID          : {args.sid}")
    print(f"  Local DIN    : {args.local_din}")
    print(f"  Local Addr   : {args.local_addr}")
    print(f"  Remote DIN   : {args.remote_din}")
    print(f"  Remote Addr  : {args.remote_addr}")
    print(f'  Config       : {args.config}')
    print("==========================")

    app = QApplication(sys.argv)

    app.setStyleSheet("""
    QMainWindow {
        background-color: #121212;
    }

    #headerFrame {
        background-color: #1e1e1e;
        border-radius: 12px;
        border: 1px solid #303030;
    }

    #titleLabel {
        font-size: 16px;
        font-weight: 600;
        color: #f5f5f5;
    }

    #sidLabel {
        font-size: 12px;
        color: #bbbbbb;
    }

    #tagLocal, #tagRemote {
        font-size: 11px;
        font-weight: 600;
        letter-spacing: 1px;
        text-transform: uppercase;
    }

    #tagLocal {
        color: #4caf50;
    }

    #tagRemote {
        color: #03a9f4;
    }

    #dinLabel {
        font-size: 14px;
        font-weight: 600;
        color: #f5f5f5;
    }

    #addrLabel {
        font-size: 12px;
        color: #aaaaaa;
    }

    #sectionFrame {
        background-color: #1e1e1e;
        border-radius: 10px;
        border: 1px solid #303030;
    }

    #sectionLabel {
        font-size: 13px;
        font-weight: 600;
        color: #f5f5f5;
    }

    #powerIndicator {
        border-radius: 20px;
        background-color: #424242;
        border: 1px solid #555555;
    }

    #powerIndicator[powerState="on"] {
        background-color: #4caf50;
        border-color: #4caf50;
    }

    #powerText {
        font-size: 14px;
        font-weight: 600;
        color: #f5f5f5;
    }

    #alertBadge {
        border-radius: 12px;
        padding: 4px 10px;
        font-size: 13px;
        font-weight: 600;
        color: #ffffff;
        background-color: #455a64; /* NONE */
    }

    #alertBadge[alertState="none"] {
        background-color: #455a64;
    }

    #alertBadge[alertState="warning"] {
        background-color: #fbc02d;
        color: #000000;
    }

    #alertBadge[alertState="critical"] {
        background-color: #d32f2f;
    }

    #messageText {
        font-size: 13px;
        color: #f5f5f5;
    }
    """)

    signals = StatusSignals()
    handler = StatusEventHandler(signals)
    node = pydaasiot.DaasWrapper(args.config, handler)
    handler.node = node

    node.doInit(args.sid, args.local_din)
    node.enableDriver(pydaasiot.link_t._LINK_INET4, args.local_addr)
    node.map(args.remote_din, pydaasiot.link_t._LINK_INET4, args.remote_addr)
    node.doPerform(pydaasiot.performs_mode_t.PERFORM_CORE_THREAD)

    window = StatusWindow(
        node=node,
        signals=signals,
        sid=args.sid,
        local_din=args.local_din,
        local_addr=args.local_addr,
        remote_din=args.remote_din,
        remote_addr=args.remote_addr,
    )
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
