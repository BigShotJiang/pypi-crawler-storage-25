import sys
import argparse
import pydaasiot

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QLineEdit,
    QComboBox,
    QFrame,
    QGridLayout,
)

# ==========================
# TYPESET & ALERT CONSTANTS
# ==========================

TS_POWER_CMD   = 10
TS_ALERT_CMD   = 11
TS_MESSAGE_CMD = 12

ALERT_NONE = 0
ALERT_WARNING = 1
ALERT_CRITICAL = 2


# ==========================
# HANDLER (LOGGING)
# ==========================

class LoggingEventHandler(pydaasiot.IDaasApiEvent):
    """
    Handler minimale che logga gli eventi, usato lato sender.
    """
    def __init__(self):
        super().__init__()
        self.node = None

    def dinAcceptedEvent(self, din):
        print(f"[EVENT] DIN accepted: {din}")

    def ddoReceivedEvent(self, payload_size, typeset, din):
        print(f"[EVENT] DDO received (sender side): din={din}, size={payload_size}, ts={typeset}")
        # volendo: err, ddo = self.node.pull(din) e payload_text(), ma non è necessario qui

    def frisbeeReceivedEvent(self, din):
        print(f"[EVENT] FRISBEE from DIN {din}")

    def nodeStateReceivedEvent(self, din):
        print(f"[EVENT] Node state received from DIN {din}")

    def atsSyncCompleted(self, din):
        print(f"[EVENT] ATS sync completed for DIN {din}")

    def frisbeeDperfCompleted(self, din, packets_sent, block_size):
        print(f"[EVENT] Frisbee dperf completed: din={din}, pkt={packets_sent}, block={block_size}")


# ==========================
# GUI ControlWindow
# ==========================

class ControlWindow(QMainWindow):
    def __init__(self, node: pydaasiot.DaasWrapper,
                 sid: int, local_din: int, local_addr: str,
                 remote_din: int, remote_addr: str,
                 parent=None):
        super().__init__(parent)
        self.node = node
        self.sid = sid
        self.local_din = local_din
        self.local_addr = local_addr
        self.remote_din = remote_din
        self.remote_addr = remote_addr

        self.power_on = False  # stato interno

        self.setWindowTitle(
            f"DaaS Control Panel  •  SID {sid}  •  DIN {local_din}"
        )
        self.resize(520, 360)

        central = QWidget()
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(14, 14, 14, 14)
        main_layout.setSpacing(12)

        # ==========================
        # HEADER CARD
        # ==========================

        header_frame = QFrame()
        header_frame.setObjectName("headerFrame")
        header_layout = QGridLayout(header_frame)
        header_layout.setContentsMargins(10, 10, 10, 10)
        header_layout.setHorizontalSpacing(20)
        header_layout.setVerticalSpacing(4)

        title_label = QLabel("DaaS-IoT Remote Control")
        title_label.setObjectName("titleLabel")

        tag_local = QLabel("CONTROLLER NODE")
        tag_local.setObjectName("tagLocal")
        tag_remote = QLabel("TARGET NODE")
        tag_remote.setObjectName("tagRemote")

        local_din_label = QLabel(f"DIN {local_din}")
        local_din_label.setObjectName("dinLabel")
        local_addr_label = QLabel(f"{local_addr}")
        local_addr_label.setObjectName("addrLabel")

        remote_din_label = QLabel(f"DIN {remote_din}")
        remote_din_label.setObjectName("dinLabel")
        remote_addr_label = QLabel(f"{remote_addr}")
        remote_addr_label.setObjectName("addrLabel")

        sid_label = QLabel(f"SID {sid}")
        sid_label.setObjectName("sidLabel")

        header_layout.addWidget(title_label, 0, 0, 1, 2)
        header_layout.addWidget(sid_label, 0, 2, 1, 1, Qt.AlignmentFlag.AlignRight)

        header_layout.addWidget(tag_local, 1, 0)
        header_layout.addWidget(local_din_label, 2, 0)
        header_layout.addWidget(local_addr_label, 3, 0)

        header_layout.addWidget(tag_remote, 1, 1)
        header_layout.addWidget(remote_din_label, 2, 1)
        header_layout.addWidget(remote_addr_label, 3, 1)

        header_layout.setColumnStretch(0, 1)
        header_layout.setColumnStretch(1, 1)
        header_layout.setColumnStretch(2, 0)

        main_layout.addWidget(header_frame)

        # ==========================
        # SEZIONE POWER
        # ==========================

        power_frame = QFrame()
        power_frame.setObjectName("sectionFrame")
        power_layout = QHBoxLayout(power_frame)
        power_layout.setContentsMargins(10, 10, 10, 10)
        power_layout.setSpacing(10)

        power_label = QLabel("Power")
        power_label.setObjectName("sectionLabel")

        self.power_button = QPushButton("OFF")
        self.power_button.setCheckable(True)
        self.power_button.setObjectName("powerButton")

        power_layout.addWidget(power_label)
        power_layout.addStretch(1)
        power_layout.addWidget(self.power_button)

        main_layout.addWidget(power_frame)

        # ==========================
        # SEZIONE ALERT LEVEL
        # ==========================

        alert_frame = QFrame()
        alert_frame.setObjectName("sectionFrame")
        alert_layout = QHBoxLayout(alert_frame)
        alert_layout.setContentsMargins(10, 10, 10, 10)
        alert_layout.setSpacing(10)

        alert_label = QLabel("Alert level")
        alert_label.setObjectName("sectionLabel")

        self.alert_combo = QComboBox()
        self.alert_combo.setObjectName("alertCombo")
        self.alert_combo.addItem("NONE", ALERT_NONE)
        self.alert_combo.addItem("WARNING", ALERT_WARNING)
        self.alert_combo.addItem("CRITICAL", ALERT_CRITICAL)
        self.alert_combo.setCurrentIndex(0)

        alert_layout.addWidget(alert_label)
        alert_layout.addStretch(1)
        alert_layout.addWidget(self.alert_combo)

        main_layout.addWidget(alert_frame)

        # ==========================
        # SEZIONE MESSAGE
        # ==========================

        msg_frame = QFrame()
        msg_frame.setObjectName("sectionFrame")
        msg_layout = QVBoxLayout(msg_frame)
        msg_layout.setContentsMargins(10, 10, 10, 10)
        msg_layout.setSpacing(8)

        msg_label = QLabel("Remote message")
        msg_label.setObjectName("sectionLabel")

        input_row = QHBoxLayout()
        self.message_line = QLineEdit()
        self.message_line.setPlaceholderText("Scrivi un messaggio da visualizzare sul device...")
        self.message_line.setObjectName("messageLine")

        self.send_msg_button = QPushButton("Send")
        self.send_msg_button.setObjectName("sendButton")

        input_row.addWidget(self.message_line, stretch=1)
        input_row.addWidget(self.send_msg_button)

        msg_layout.addWidget(msg_label)
        msg_layout.addLayout(input_row)

        main_layout.addWidget(msg_frame)

        main_layout.addStretch(1)
        self.setCentralWidget(central)

        # --- Signals ---
        self.power_button.clicked.connect(self.on_power_toggled)
        self.alert_combo.currentIndexChanged.connect(self.on_alert_changed)
        self.send_msg_button.clicked.connect(self.on_send_message)
        self.message_line.returnPressed.connect(self.on_send_message)

    # ==========
    # INVIO DDO (SOLO API NOTE)
    # ==========

    def _make_ddo_with_text(self, typeset: int, text: str) -> pydaasiot.DDO:
        payload = text.encode("utf-8")
        ddo = pydaasiot.DDO()
        ddo.setOrigin(self.local_din)
        ddo.setTypeset(typeset)
        ddo.allocatePayload(len(payload))
        ddo.appendPayloadData(payload)
        return ddo

    def send_power_ddo(self, is_on: bool):
        # "0" / "1" come stringa, così siamo sicuri che payload_text() funzioni
        value_str = "1" if is_on else "0"
        ddo = self._make_ddo_with_text(TS_POWER_CMD, value_str)
        err = self.node.push(self.remote_din, ddo)
        print(f"[PUSH] POWER ({value_str}) -> {self.remote_din}, err={err}")

    def send_alert_ddo(self, level: int):
        level_str = str(level)  # "0", "1", "2"
        ddo = self._make_ddo_with_text(TS_ALERT_CMD, level_str)
        err = self.node.push(self.remote_din, ddo)
        print(f"[PUSH] ALERT ({level_str}) -> {self.remote_din}, err={err}")

    def send_message_ddo(self, text: str):
        ddo = self._make_ddo_with_text(TS_MESSAGE_CMD, text)
        err = self.node.push(self.remote_din, ddo)
        print(f"[PUSH] MESSAGE -> {self.remote_din}, err={err}")

    # ==========
    # SLOT GUI
    # ==========

    def on_power_toggled(self, checked: bool):
        self.power_on = checked
        self.power_button.setText("ON" if checked else "OFF")
        self.power_button.setProperty("powerState", "on" if checked else "off")
        self.power_button.style().unpolish(self.power_button)
        self.power_button.style().polish(self.power_button)
        self.send_power_ddo(checked)

    def on_alert_changed(self, index: int):
        level = self.alert_combo.currentData()
        if level is None:
            return
        self.send_alert_ddo(int(level))

    def on_send_message(self):
        text = self.message_line.text().strip()
        if not text:
            return
        self.send_message_ddo(text)
        self.message_line.clear()


# ==========================
# PARSING ARGOMENTI
# ==========================

def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        description="DaaS-IoT Control Panel (PyQt + pydaasiot)"
    )
    parser.add_argument("--sid", type=int, default=100, help="SID del nodo locale (default: 100)")
    parser.add_argument("--local-din", type=int, required=True, help="DIN del nodo locale")
    parser.add_argument("--local-addr", type=str, required=True, help='Indirizzo locale, es: "127.0.0.1:2222"')
    parser.add_argument("--remote-din", type=int, required=True, help="DIN del nodo remoto (device)")
    parser.add_argument("--remote-addr", type=str, required=True, help='Indirizzo peer, es: "127.0.0.1:2223"')
    parser.add_argument("--config", type=str, default="config.json", help='Path al config DaaS (default: "config.json")')
    return parser.parse_args(argv)


# ==========================
# MAIN
# ==========================

def main(argv=None):
    args = parse_args(argv)

    print("=== DaaS Control Panel ===")
    print(f"  SID          : {args.sid}")
    print(f"  Local DIN    : {args.local_din}")
    print(f"  Local Addr   : {args.local_addr}")
    print(f"  Remote DIN   : {args.remote_din}")
    print(f"  Remote Addr  : {args.remote_addr}")
    print(f'  Config       : {args.config}')
    print("===========================")

    app = QApplication(sys.argv)

    # Stile "dark"
    app.setStyleSheet("""
    QMainWindow {
        background-color: #121212;
    }

    #headerFrame {
        background-color: #1e1e1e;
        border-radius: 12px;
        border: 1px solid #303030;
    }

    #titleLabel {
        font-size: 16px;
        font-weight: 600;
        color: #f5f5f5;
    }

    #sidLabel {
        font-size: 12px;
        color: #bbbbbb;
    }

    #tagLocal, #tagRemote {
        font-size: 11px;
        font-weight: 600;
        letter-spacing: 1px;
        text-transform: uppercase;
    }

    #tagLocal {
        color: #4caf50;
    }

    #tagRemote {
        color: #03a9f4;
    }

    #dinLabel {
        font-size: 14px;
        font-weight: 600;
        color: #f5f5f5;
    }

    #addrLabel {
        font-size: 12px;
        color: #aaaaaa;
    }

    #sectionFrame {
        background-color: #1e1e1e;
        border-radius: 10px;
        border: 1px solid #303030;
    }

    #sectionLabel {
        font-size: 13px;
        font-weight: 600;
        color: #f5f5f5;
    }

    #powerButton {
        min-width: 80px;
        padding: 6px 12px;
        border-radius: 18px;
        border: 1px solid #444;
        background-color: #b71c1c;
        color: #ffffff;
        font-weight: 600;
    }

    #powerButton[powerState="on"] {
        background-color: #2e7d32;
        border-color: #2e7d32;
    }

    #powerButton:hover {
        border-color: #888888;
    }

    #alertCombo {
        background-color: #181818;
        border-radius: 8px;
        border: 1px solid #303030;
        padding: 4px 8px;
        color: #f5f5f5;
    }

    #messageLine {
        background-color: #181818;
        border-radius: 18px;
        border: 1px solid #303030;
        padding: 6px 12px;
        color: #f5f5f5;
    }

    #messageLine:focus {
        border: 1px solid #4caf50;
        outline: none;
    }

    #sendButton {
        background-color: #4caf50;
        color: white;
        border-radius: 18px;
        padding: 6px 16px;
        border: none;
        font-weight: 600;
    }

    #sendButton:hover {
        background-color: #66bb6a;
    }

    #sendButton:pressed {
        background-color: #388e3c;
    }
    """)

    handler = LoggingEventHandler()
    node = pydaasiot.DaasWrapper(args.config, handler)
    handler.node = node

    node.doInit(args.sid, args.local_din)
    node.enableDriver(pydaasiot.link_t._LINK_INET4, args.local_addr)
    node.map(args.remote_din, pydaasiot.link_t._LINK_INET4, args.remote_addr)
    node.doPerform(pydaasiot.performs_mode_t.PERFORM_CORE_THREAD)

    window = ControlWindow(
        node=node,
        sid=args.sid,
        local_din=args.local_din,
        local_addr=args.local_addr,
        remote_din=args.remote_din,
        remote_addr=args.remote_addr,
    )
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
