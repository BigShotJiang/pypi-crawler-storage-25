import sys
import argparse
import signal
import time
import threading

import pydaasiot

# ==========================
# PRINT SINCRONIZZATO
# ==========================

print_lock = threading.Lock()

def safe_print(*args, **kwargs):
    with print_lock:
        print(*args, **kwargs)

# ==========================
# HANDLER EVENTI
# ==========================

class GenericEventHandler(pydaasiot.IDaasApiEvent):
    """
    Handler generico per i nodi DaaS.
    - Logga gli eventi.
    - Su DDO ricevuto fa pull e stampa DIN, typeset e payload_text().
    """
    def __init__(self):
        super().__init__()
        self.node = None  # verrà impostato dopo

    def dinAcceptedEvent(self, din):
        safe_print(f"[EVENT] DIN accepted: {din}")

    def ddoReceivedEvent(self, payload_size, typeset, din):
        safe_print(f"[EVENT] DDO received: din={din}, size={payload_size}, typeset={typeset}")

        if self.node is None:
            safe_print("[WARN] node non impostato nell'handler")
            return

        err, ddo = self.node.pull(din)
        if err != pydaasiot.daas_error_t.ERROR_NONE or ddo is None:
            safe_print(f"[PULL] error={err}, ddo=None")
            return

        try:
            raw = ddo.payload_text()
        except Exception as e:
            safe_print(f"[ERROR] payload_text() failed: {e}")
            raw = "<invalid payload>"

        safe_print(f"[PULL] DDO from DIN {din} | typeset={typeset} | payload={repr(raw[:-3])}")

    def frisbeeReceivedEvent(self, din):
        safe_print(f"[EVENT] FRISBEE from DIN {din}")

    def nodeStateReceivedEvent(self, din):
        safe_print(f"[EVENT] Node state received from DIN {din}")

    def atsSyncCompleted(self, din):
        safe_print(f"[EVENT] ATS sync completed for DIN {din}")

    def frisbeeDperfCompleted(self, din, packets_sent, block_size):
        safe_print(f"[EVENT] Frisbee dperf completed: din={din}, pkt={packets_sent}, block={block_size}")


# ==========================
# PARSING ARGOMENTI
# ==========================

def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        description="Nodo generico DaaS-IoT (pydaasiot) da deployare su VPS / dispositivi"
    )

    parser.add_argument("--sid", type=int, required=True,
                        help="SID del nodo (es. 100)")

    parser.add_argument("--din", type=int, required=True,
                        help="DIN locale del nodo")

    parser.add_argument("--addr", type=str, required=True,
                        help='Indirizzo locale per il driver, es: "0.0.0.0:3000"')

    parser.add_argument("--config", type=str, default="config.json",
                        help='Path al file di configurazione DaaS (default: "config.json")')

    parser.add_argument("--map", nargs=2, action="append", metavar=("REMOTE_DIN", "REMOTE_ADDR"),
                        help='Mappa un DIN remoto ad un indirizzo "ip:port". '
                             'Può essere ripetuto più volte.')

    return parser.parse_args(argv)


# ==========================
# FUNZIONE DI INVIO DDO
# ==========================

def send_text_ddo(node: pydaasiot.DaasWrapper, origin_din: int, target_din: int,
                  typeset: int, text: str):
    payload = text.encode("utf-8")

    ddo = pydaasiot.DDO()
    ddo.setOrigin(origin_din)
    ddo.setTypeset(typeset)
    ddo.allocatePayload(len(payload))
    ddo.appendPayloadData(payload)

    err = node.push(target_din, ddo)
    safe_print(f"[PUSH] to DIN {target_din} | typeset={typeset} | err={err}")


# ==========================
# MAIN
# ==========================

def main(argv=None):
    args = parse_args(argv)

    safe_print("=== DaaS Generic Node ===")
    safe_print(f"  SID        : {args.sid}")
    safe_print(f"  Local DIN  : {args.din}")
    safe_print(f"  Local addr : {args.addr}")
    safe_print(f"  Config     : {args.config}")
    if args.map:
        safe_print("  Mappings:")
        for rem_din, rem_addr in args.map:
            safe_print(f"    - DIN {rem_din} -> {rem_addr}")
    else:
        safe_print("  Mappings   : (nessuno)")
    safe_print("==========================")

    handler = GenericEventHandler()
    node = pydaasiot.DaasWrapper(args.config, handler)
    handler.node = node

    # Inizializza nodo
    node.doInit(args.sid, args.din)

    # Abilita driver INET4 locale
    node.enableDriver(pydaasiot.link_t._LINK_INET4, args.addr)

    # Configura le mappe
    if args.map:
        for rem_din_str, rem_addr in args.map:
            try:
                rem_din = int(rem_din_str)
            except ValueError:
                safe_print(f"[WARN] REMOTE_DIN non valido: {rem_din_str}, skip.")
                continue

            safe_print(f"[CFG] map DIN {rem_din} -> {rem_addr}")
            node.map(rem_din, pydaasiot.link_t._LINK_INET4, rem_addr)

    # Avvia thread interno DaaS
    node.doPerform(pydaasiot.performs_mode_t.PERFORM_CORE_THREAD)

    # Flag per uscita
    running = True

    def handle_sigint(sig, frame):
        nonlocal running
        safe_print("\n[SYS] SIGINT ricevuto, uscita…")
        running = False

    signal.signal(signal.SIGINT, handle_sigint)

    # ==========================
    # THREAD INPUT INTERATTIVO
    # ==========================

    def input_loop():
        while running:
            try:
                safe_print("\n-----------------------------------------")
                din = input("→ DIN destinatario (vuoto per saltare): ").strip()
                if not din:
                    continue

                if not din.isdigit():
                    safe_print("[WARN] DIN non numerico.")
                    continue

                typeset_raw = input("→ Typeset (numero intero): ").strip()
                if not typeset_raw.isdigit():
                    safe_print("[WARN] Typeset non valido.")
                    continue

                msg = input("→ Messaggio da inviare: ")

                send_text_ddo(
                    node=node,
                    origin_din=args.din,
                    target_din=int(din),
                    typeset=int(typeset_raw),
                    text=msg
                )

            except EOFError:
                break
            except Exception as e:
                safe_print(f"[ERROR input_loop] {e}")

    safe_print("\n-----------------------------------------")
    safe_print("[INTERACTIVE MODE] Thread input avviato.")
    safe_print("Premi CTRL+C per uscire.\n")

    input_thread = threading.Thread(target=input_loop, daemon=True)
    input_thread.start()

    # Loop principale “idle”
    try:
        while running:
            time.sleep(1.0)
    finally:
        safe_print("[SYS] Nodo terminato.")


if __name__ == "__main__":
    main()
