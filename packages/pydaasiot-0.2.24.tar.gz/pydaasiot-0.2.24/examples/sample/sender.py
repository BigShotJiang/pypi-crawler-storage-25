import pydaasiot

class MyHandler(pydaasiot.IDaasApiEvent):
    # Rimosso il suffisso "Event" dai nomi dei metodi
    def dinAccepted(self, din):
        print(f"[EVENT] DIN accepted: {din}")

    def ddoReceived(self, payload_size, typeset, din):
        print(f"[EVENT] DDO received (sender side)")

    def frisbeeReceived(self, din):
        print(f"[EVENT] FRISBEE")

    def nodeStateReceived(self, din):
        print(f"[EVENT] Node state received")

    # Aggiunti i nuovi callback obbligatori (anche se vuoti) per evitare problemi di astrazione
    def nodeDiscovered(self, din, link):
        pass
    def nodeConnectedToNetwork(self, sid, din):
        pass

handler = MyHandler()
node = pydaasiot.DaasWrapper("config.json", handler)

node.doInit(100, 102)
node.enableDriver(pydaasiot.link_t._LINK_INET4, "127.0.0.1:2223")
node.map(101, pydaasiot.link_t._LINK_INET4, "127.0.0.1:2222")

node.doPerform(pydaasiot.performs_mode_t.PERFORM_CORE_THREAD)

ddo = pydaasiot.DDO()
# ddo.setOrigin(102)  <-- RIMOSSO: ora lo fa il core automaticamente
ddo.setTypeset(1)
ddo.allocatePayload(32)
ddo.appendPayloadData(b"Hello from sender!")

err = node.push(101, ddo)
print(f"Push result: {err}")

input("Press Enter to exit...\n")