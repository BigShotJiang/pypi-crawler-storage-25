import sys
import argparse
import signal
import time
from collections import defaultdict
import pydaasiot


class HubEventHandler(pydaasiot.IDaasApiEvent):
    def __init__(self):
        super().__init__()
        self.node = None
        self.peers = []  # lista di DIN remoti

        # 🔢 CONTATORI BASIC PER L’HUB
        self.rx_from = defaultdict(int)   # DDO ricevuti per DIN sorgente
        self.total_rx = 0                 # totale DDO ricevuti

    def dinAcceptedEvent(self, din):
        print(f"[EVENT] DIN accepted: {din}")

    def ddoReceivedEvent(self, payload_size, typeset, din_sender):
        print(f"[HUB] DDO received from DIN {din_sender}, ts={typeset}, size={payload_size}")

        # Pull del DDO
        err, ddo = self.node.pull(din_sender)
        if err != pydaasiot.daas_error_t.ERROR_NONE or ddo is None:
            print(f"[HUB] Pull failed: {err}")
            return

        # Mostra payload (in debug)
        try:
            raw = ddo.payload_text()
        except Exception:
            raw = "<bad payload>"
        print(f"[HUB] Payload: {repr(raw)}")

        # 🔢 AGGIORNA STATISTICHE
        self.rx_from[din_sender] += 1
        self.total_rx += 1

        print("\n[HUB STATS - BASIC]")
        print(f"  Totale DDO ricevuti: {self.total_rx}")
        for src_din, count in self.rx_from.items():
            print(f"  - Da DIN {src_din}: {count} DDO")
        print()

        # Inoltra agli altri peer
        for peer in self.peers:
            if peer != din_sender:
                print(f"[HUB →] Forwarding to DIN {peer} ...")
                self.node.push(peer, ddo)

    # altri eventi opzionali
    def frisbeeReceivedEvent(self, din):
        pass

    def nodeStateReceivedEvent(self, din):
        pass

    def atsSyncCompleted(self, din):
        pass

    def frisbeeDperfCompleted(self, din, packets_sent, block_size):
        pass


def parse_args():
    p = argparse.ArgumentParser(description="DaaS BASIC HUB Server")
    p.add_argument("--sid", type=int, required=True)
    p.add_argument("--din", type=int, required=True)
    p.add_argument("--addr", type=str, required=True)
    p.add_argument("--config", type=str, default="config.json")

    # es:
    # --peer 101 "127.0.0.1:3001"
    # --peer 102 "127.0.0.1:3002"
    p.add_argument(
        "--peer",
        nargs=2,
        action="append",
        metavar=("PEER_DIN", "PEER_ADDR"),
        help="Nodo remoto da mappare",
    )
    return p.parse_args()


def main():
    args = parse_args()

    print("=== DaaS BASIC HUB ===")
    print(f" HUB SID: {args.sid}")
    print(f" HUB DIN: {args.din}")
    print(f" HUB ADDR: {args.addr}")
    print("=========================")

    handler = HubEventHandler()
    node = pydaasiot.DaasWrapper(args.config, handler)
    handler.node = node

    node.doInit(args.sid, args.din)
    node.enableDriver(pydaasiot.link_t._LINK_INET4, args.addr)

    # Mappatura peer
    if args.peer:
        for din_str, addr in args.peer:
            peer_din = int(din_str)
            handler.peers.append(peer_din)
            print(f"[HUB] map {peer_din} -> {addr}")
            node.map(peer_din, pydaasiot.link_t._LINK_INET4, addr)

    node.doPerform(pydaasiot.performs_mode_t.PERFORM_CORE_THREAD)

    print("\n[HUB RUNNING] Forwarding mode active.")
    print("CTRL+C per uscire.\n")

    running = True

    def handle(sig, frame):
        nonlocal running
        print("\n[HUB] Shutdown richiesto.")
        running = False

    signal.signal(signal.SIGINT, handle)

    while running:
        time.sleep(1.0)

    print("[HUB] Terminato.")


if __name__ == "__main__":
    main()
