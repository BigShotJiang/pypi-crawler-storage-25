import pydaasiot

from nacl.bindings import (
    crypto_kx_keypair,
    crypto_kx_client_session_keys,
    crypto_kx_PUBLIC_KEY_BYTES,
)

TYPESET_KX_PUBKEY = 999
PK_PREFIX = "PK:"


class MyHandler(pydaasiot.IDaasApiEvent):
    def __init__(self):
        super().__init__()
        self.node = None

        # Chiavi ECDH lato "client" (sender)
        self.client_pk = None
        self.client_sk = None

        # Public key del peer (receiver)
        self.peer_pk = None

        # Shared secret per A->B (client_tx == server_rx)
        self.shared_secret = None

    def dinAcceptedEvent(self, din):
        print(f"[EVENT] DIN accepted: {din}")

    def ddoReceivedEvent(self, payload_size, typeset, din):
        print(f"[EVENT] DDO received (sender side): din={din}, size={payload_size}, typeset={typeset}")

        # Pull del DDO
        err, ddo = self.node.pull(din)
        if err != pydaasiot.daas_error_t.ERROR_NONE or ddo is None:
            print(f"[PULL] Pull failed with error {err}")
            return

        # Qui USIAMO payload_text()
        raw_text = ddo.payload_text()
        text = raw_text.strip().replace("\x00", "")
        print(f"[DEBUG] payload_text (sender) = {repr(text)}")

        if typeset == TYPESET_KX_PUBKEY:
            self._handle_kx_pubkey_reply(din, text)
        else:
            print(f"[APP] Payload (non-KX) from DIN {din}: {text}")

    def _extract_pubkey_from_text(self, text: str):
        idx = text.find(PK_PREFIX)
        if idx == -1:
            print("[KX][ERROR] PK_PREFIX not found in payload_text()")
            return None

        start = idx + len(PK_PREFIX)
        end = start + (crypto_kx_PUBLIC_KEY_BYTES * 2)

        if end > len(text):
            print(f"[KX][ERROR] Not enough data after PK_PREFIX in text (len={len(text)}, need {end})")
            return None

        hex_str = text[start:end]
        try:
            pk = bytes.fromhex(hex_str)
        except Exception as e:
            print(f"[KX][ERROR] Failed to parse hex public key from text: {e}")
            return None

        if len(pk) != crypto_kx_PUBLIC_KEY_BYTES:
            print(f"[KX][ERROR] Parsed public key has wrong length: {len(pk)}")
            return None

        return pk

    def _handle_kx_pubkey_reply(self, din, text: str):
        print(f"[KX] Received SERVER KX payload from DIN {din}, text len={len(text)}")

        peer_pk = self._extract_pubkey_from_text(text)
        if peer_pk is None:
            print("[KX][ERROR] Could not extract SERVER public key")
            return

        self.peer_pk = peer_pk
        print(f"[KX] peer_pk (sender) = {self.peer_pk.hex()}")

        # Calcolo delle session keys lato "client"
        client_rx, client_tx = crypto_kx_client_session_keys(
            self.client_pk,  # public key nostra
            self.client_sk,  # secret key nostra
            self.peer_pk,    # public key del server
        )

        self.shared_secret = client_tx

        print("[KX] === CLIENT SESSION KEYS ===")
        print(f"[KX] client_rx                 = {client_rx.hex()}")
        print(f"[KX] client_tx (SHARED_SECRET) = {client_tx.hex()}")

        # Qui (STEP 2) useremo self.shared_secret con XChaCha20-Poly1305

    def frisbeeReceivedEvent(self, din):
        print(f"[EVENT] FRISBEE")

    def nodeStateReceivedEvent(self, din):
        print(f"[EVENT] Node state received")

    def atsSyncCompleted(self, din):
        print(f"[EVENT] ATS sync completed")

    def frisbeeDperfCompleted(self, din, packets_sent, block_size):
        print(f"[EVENT] Frisbee dperf completed")


# ===== MAIN SENDER =====

if __name__ == "__main__":
    handler = MyHandler()

    node = pydaasiot.DaasWrapper("config.json", handler)
    handler.node = node

    # Generiamo le chiavi ECDH lato "client"
    client_pk, client_sk = crypto_kx_keypair()
    handler.client_pk = client_pk
    handler.client_sk = client_sk

    print("=== SENDER ECDH KEYS ===")
    print(f"[KX] client_pk = {client_pk.hex()}")
    print(f"[KX] client_sk = {client_sk.hex()}")

    # SID=100, DIN=102 per il sender
    node.doInit(100, 102)

    # Driver INET4 per il sender
    node.enableDriver(pydaasiot.link_t._LINK_INET4, "127.0.0.1:2223")

    # Mappiamo il receiver (DIN 101)
    node.map(101, pydaasiot.link_t._LINK_INET4, "127.0.0.1:2222")

    # Avvia il core thread
    node.doPerform(pydaasiot.performs_mode_t.PERFORM_CORE_THREAD)

    # Inviamo la nostra public key come "PK:<hex>"
    pk_hex = client_pk.hex()
    payload_text = PK_PREFIX + pk_hex

    ddo_kx = pydaasiot.DDO()
    ddo_kx.setOrigin(102)  # DIN locale del sender
    ddo_kx.setTypeset(TYPESET_KX_PUBKEY)
    ddo_kx.allocatePayload(len(payload_text))
    ddo_kx.appendPayloadData(payload_text.encode("ascii"))

    err = node.push(101, ddo_kx)
    print(f"[KX] Sent CLIENT public key to DIN 101, push result: {err}")

    input("Sender pronto. Premi Invio per uscire...\n")
