import base64
import time
import pydaasiot
import nacl.utils

from nacl.bindings import (
    crypto_kx_keypair,
    crypto_kx_client_session_keys,
    crypto_kx_PUBLIC_KEY_BYTES,
    crypto_aead_xchacha20poly1305_ietf_encrypt,
    crypto_aead_xchacha20poly1305_ietf_NPUBBYTES,
)

TYPESET_KX_PUBKEY = 999
TYPESET_SECURE_APP = 1001
PK_PREFIX = "PK:"
ENC_PREFIX = "ENC:"


class MyHandler(pydaasiot.IDaasApiEvent):
    def __init__(self):
        super().__init__()
        self.node = None

        # Chiavi ECDH lato "client" (sender)
        self.client_pk = None
        self.client_sk = None

        # Public key del peer (receiver)
        self.peer_pk = None

        # Shared secret per A->B (client_tx == server_rx)
        self.shared_secret = None

        # Flag per dire al main che il KX è completato
        self.kx_done = False

    def dinAcceptedEvent(self, din):
        print(f"[EVENT] DIN accepted: {din}")

    def ddoReceivedEvent(self, payload_size, typeset, din):
        print(f"[EVENT] DDO received (sender side): din={din}, size={payload_size}, typeset={typeset}")

        # Pull del DDO
        err, ddo = self.node.pull(din)
        if err != pydaasiot.daas_error_t.ERROR_NONE or ddo is None:
            print(f"[PULL] Pull failed with error {err}")
            return

        # USIAMO payload_text()
        raw_text = ddo.payload_text()
        text = raw_text.strip().replace("\x00", "")
        print(f"[DEBUG] payload_text (sender) = {repr(text)}")

        if typeset == TYPESET_KX_PUBKEY:
            self._handle_kx_pubkey_reply(din, text)
        elif typeset == TYPESET_SECURE_APP:
            # In questo PoC non ci aspettiamo messaggi cifrati verso il sender
            print(f"[SEC] Received secure APP message on sender (not handled in PoC): {text}")
        else:
            print(f"[APP] Payload (non-KX) from DIN {din}: {text}")

    # ========================
    #  ECDH / HANDSHAKE
    # ========================

    def _extract_pubkey_from_text(self, text: str):
        idx = text.find(PK_PREFIX)
        if idx == -1:
            print("[KX][ERROR] PK_PREFIX not found in payload_text()")
            return None

        start = idx + len(PK_PREFIX)
        end = start + (crypto_kx_PUBLIC_KEY_BYTES * 2)

        if end > len(text):
            print(f"[KX][ERROR] Not enough data after PK_PREFIX in text (len={len(text)}, need {end})")
            return None

        hex_str = text[start:end]
        try:
            pk = bytes.fromhex(hex_str)
        except Exception as e:
            print(f"[KX][ERROR] Failed to parse hex public key from text: {e}")
            return None

        if len(pk) != crypto_kx_PUBLIC_KEY_BYTES:
            print(f"[KX][ERROR] Parsed public key has wrong length: {len(pk)}")
            return None

        return pk

    def _handle_kx_pubkey_reply(self, din, text: str):
        # Se il KX è già stato fatto, ignoriamo pacchetti duplicati
        if self.kx_done:
            print("[KX][INFO] KX already completed, ignoring extra SERVER PK")
            return

        print(f"[KX] Received SERVER KX payload from DIN {din}, text len={len(text)}")

        peer_pk = self._extract_pubkey_from_text(text)
        if peer_pk is None:
            print("[KX][ERROR] Could not extract SERVER public key")
            return

        self.peer_pk = peer_pk
        print(f"[KX] peer_pk (sender) = {self.peer_pk.hex()}")

        # Calcolo delle session keys lato "client"
        client_rx, client_tx = crypto_kx_client_session_keys(
            self.client_pk,  # public key nostra
            self.client_sk,  # secret key nostra
            self.peer_pk,    # public key del server
        )

        self.shared_secret = client_tx

        print("[KX] === CLIENT SESSION KEYS ===")
        print(f"[KX] client_rx                 = {client_rx.hex()}")
        print(f"[KX] client_tx (SHARED_SECRET) = {client_tx.hex()}")

        # NON mandiamo ancora il messaggio cifrato da qui.
        # Segnaliamo solo al main che il KX è pronto.
        self.kx_done = True
        print("[KX] Handshake completed on sender, shared_secret ready.")

    # ========================
    #  CIFRA MESSAGGI APP
    # ========================

    def encrypt_for_peer(self, plaintext: bytes) -> str | None:
        if self.shared_secret is None:
            print("[SEC][ERROR] shared_secret not ready, cannot encrypt")
            return None

        nonce = nacl.utils.random(crypto_aead_xchacha20poly1305_ietf_NPUBBYTES)
        ct = crypto_aead_xchacha20poly1305_ietf_encrypt(
            plaintext,
            b"",  # AAD (puoi usare anche None)
            nonce,
            self.shared_secret,
        )

        blob = nonce + ct
        b64 = base64.b64encode(blob).decode("ascii")
        return ENC_PREFIX + b64

    def send_secure_app_message(self, text: str):
        """
        Questo viene chiamato dal MAIN THREAD, non dal callback.
        """
        print(f"[SEC] Encrypting and sending message: {text}")

        payload_text = self.encrypt_for_peer(text.encode("utf-8"))
        if payload_text is None:
            return

        ddo = pydaasiot.DDO()
        ddo.setOrigin(102)  # DIN locale del sender
        ddo.setTypeset(TYPESET_SECURE_APP)
        ddo.allocatePayload(len(payload_text))
        ddo.appendPayloadData(payload_text.encode("ascii"))

        err = self.node.push(101, ddo)
        print(f"[SEC] Sent encrypted app message to DIN 101, push result: {err}")

    # ========================
    #  ALTRO
    # ========================

    def frisbeeReceivedEvent(self, din):
        print(f"[EVENT] FRISBEE")

    def nodeStateReceivedEvent(self, din):
        print(f"[EVENT] Node state received")

    def atsSyncCompleted(self, din):
        print(f"[EVENT] ATS sync completed")

    def frisbeeDperfCompleted(self, din, packets_sent, block_size):
        print(f"[EVENT] Frisbee dperf completed")


# ===== MAIN SENDER =====

if __name__ == "__main__":
    handler = MyHandler()

    node = pydaasiot.DaasWrapper("config.json", handler)
    handler.node = node

    # Generiamo le chiavi ECDH lato "client"
    client_pk, client_sk = crypto_kx_keypair()
    handler.client_pk = client_pk
    handler.client_sk = client_sk

    print("=== SENDER ECDH KEYS ===")
    print(f"[KX] client_pk = {client_pk.hex()}")
    print(f"[KX] client_sk = {client_sk.hex()}")

    # SID=100, DIN=102 per il sender
    node.doInit(100, 102)

    # Driver INET4 per il sender
    node.enableDriver(pydaasiot.link_t._LINK_INET4, "127.0.0.1:2223")

    # Mappiamo il receiver (DIN 101)
    node.map(101, pydaasiot.link_t._LINK_INET4, "127.0.0.1:2222")

    # Avvia il core thread
    node.doPerform(pydaasiot.performs_mode_t.PERFORM_CORE_THREAD)

    # Inviamo la nostra public key come "PK:<hex>" per iniziare l'handshake
    pk_hex = client_pk.hex()
    payload_text = PK_PREFIX + pk_hex

    ddo_kx = pydaasiot.DDO()
    ddo_kx.setOrigin(102)  # DIN locale del sender
    ddo_kx.setTypeset(TYPESET_KX_PUBKEY)
    ddo_kx.allocatePayload(len(payload_text))
    ddo_kx.appendPayloadData(payload_text.encode("ascii"))

    err = node.push(101, ddo_kx)
    print(f"[KX] Sent CLIENT public key to DIN 101, push result: {err}")

    # Aspettiamo che il KX sia completato (settato dal callback)
    print("[MAIN] Waiting for KX to complete on sender...")
    while not handler.kx_done:
        time.sleep(0.1)

    print("[MAIN] KX completed, sending secure app message...")
    handler.send_secure_app_message("Hello from secure sender with XChaCha20-Poly1305!")

    print("[MAIN] Messaggio cifrato inviato. Ora resto in attesa (input)...")
    input("Sender pronto. Premi Invio per uscire...\n")
