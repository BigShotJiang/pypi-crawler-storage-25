import base64
import re
import pydaasiot
import nacl.utils

from nacl.bindings import (
    crypto_kx_keypair,
    crypto_kx_server_session_keys,
    crypto_kx_PUBLIC_KEY_BYTES,
    crypto_aead_xchacha20poly1305_ietf_encrypt,
    crypto_aead_xchacha20poly1305_ietf_decrypt,
    crypto_aead_xchacha20poly1305_ietf_NPUBBYTES,
)

TYPESET_KX_PUBKEY = 999      # typeset dedicato per lo scambio chiavi
TYPESET_SECURE_APP = 1001    # typeset per i messaggi applicativi cifrati
PK_PREFIX = "PK:"            # prefisso testuale per le public key
ENC_PREFIX = "ENC:"          # prefisso testuale per i messaggi cifrati


class MyHandler(pydaasiot.IDaasApiEvent):
    def __init__(self):
        super().__init__()
        self.node = None

        # Chiavi ECDH lato "server" (receiver)
        self.server_pk = None
        self.server_sk = None

        # Public key del peer (sender)
        self.peer_pk = None

        # Shared secret (per messaggi A -> B, usiamo server_rx)
        self.shared_secret = None

    def dinAcceptedEvent(self, din):
        print(f"[EVENT] DIN accepted: {din}")

    def ddoReceivedEvent(self, payload_size, typeset, din):
        print(f"[EVENT] DDO received: din={din}, size={payload_size}, typeset={typeset}")

        # Pull del DDO dal nodo
        err, ddo = self.node.pull(din)
        if err != pydaasiot.daas_error_t.ERROR_NONE or ddo is None:
            print(f"[PULL] Pull failed with error {err}")
            return

        # USIAMO payload_text() per avere qualcosa di più pulito
        raw_text = ddo.payload_text()
        text = raw_text.replace("\x00", "").strip()
        print(f"[DEBUG] payload_text (receiver) = {repr(text)}")

        if typeset == TYPESET_KX_PUBKEY:
            self._handle_kx_pubkey(din, text)
        elif typeset == TYPESET_SECURE_APP:
            self._handle_secure_app(din, text)
        else:
            print(f"[APP] Payload (non-KX) from DIN {din}: {text}")

    # ========================
    #  ECDH / HANDSHAKE
    # ========================

    def _extract_pubkey_from_text(self, text: str):
        idx = text.find(PK_PREFIX)
        if idx == -1:
            print("[KX][ERROR] PK_PREFIX not found in payload_text()")
            return None

        start = idx + len(PK_PREFIX)
        end = start + (crypto_kx_PUBLIC_KEY_BYTES * 2)  # 64 char hex

        if end > len(text):
            print(f"[KX][ERROR] Not enough data after PK_PREFIX in text (len={len(text)}, need {end})")
            return None

        hex_str = text[start:end]
        try:
            pk = bytes.fromhex(hex_str)
        except Exception as e:
            print(f"[KX][ERROR] Failed to parse hex public key from text: {e}")
            return None

        if len(pk) != crypto_kx_PUBLIC_KEY_BYTES:
            print(f"[KX][ERROR] Parsed public key has wrong length: {len(pk)}")
            return None

        return pk

    def _handle_kx_pubkey(self, din, text: str):
        print(f"[KX] Received KX payload from DIN {din}, text len={len(text)}")

        peer_pk = self._extract_pubkey_from_text(text)
        if peer_pk is None:
            print("[KX][ERROR] Could not extract peer public key")
            return

        self.peer_pk = peer_pk
        print(f"[KX] peer_pk (receiver) = {self.peer_pk.hex()}")

        # Calcolo delle session keys lato "server"
        server_rx, server_tx = crypto_kx_server_session_keys(
            self.server_pk,  # public key nostra
            self.server_sk,  # secret key nostra
            self.peer_pk,    # public key del client
        )

        # Per convenzione usiamo server_rx come SHARED_SECRET per A->B
        self.shared_secret = server_rx

        print("[KX] === SERVER SESSION KEYS ===")
        print(f"[KX] server_rx (SHARED_SECRET) = {server_rx.hex()}")
        print(f"[KX] server_tx                 = {server_tx.hex()}")

        # Rispondiamo al sender con la nostra public key in formato "PK:<hex>"
        pk_hex = self.server_pk.hex()
        payload_text = PK_PREFIX + pk_hex

        reply = pydaasiot.DDO()
        reply.setOrigin(101)  # DIN locale del receiver
        reply.setTypeset(TYPESET_KX_PUBKEY)
        reply.allocatePayload(len(payload_text))
        reply.appendPayloadData(payload_text.encode("ascii"))

        err = self.node.push(102, reply)  # DIN del sender
        print(f"[KX] Sent SERVER public key to DIN 102, push result: {err}")

    # ========================
    #  DECRIPTA MESSAGGI APP
    # ========================

    def _handle_secure_app(self, din, text: str):
        print(f"[SEC] Received secure APP payload from DIN {din}, text len={len(text)}")

        if self.shared_secret is None:
            print("[SEC][ERROR] shared_secret not ready, cannot decrypt")
            return

        idx = text.find(ENC_PREFIX)
        if idx == -1:
            print("[SEC][ERROR] ENC_PREFIX not found in text")
            return

        # Parte dopo "ENC:"
        after_prefix = text[idx + len(ENC_PREFIX):]

        # Estraggo SOLO la run iniziale di caratteri validi base64 (A–Z a–z 0–9 + / =)
        m = re.match(r'([A-Za-z0-9+/=]+)', after_prefix)
        if not m:
            print("[SEC][ERROR] No valid base64 run after ENC_PREFIX")
            return

        b64_str = m.group(1)
        print(f"[SEC] Clean base64 string: {b64_str!r}, len={len(b64_str)}")

        try:
            blob = base64.b64decode(b64_str, validate=True)
        except Exception as e:
            print(f"[SEC][ERROR] base64 decode failed even after cleanup: {e}")
            return

        if len(blob) <= crypto_aead_xchacha20poly1305_ietf_NPUBBYTES:
            print("[SEC][ERROR] blob too short for nonce+ciphertext")
            return

        nonce = blob[:crypto_aead_xchacha20poly1305_ietf_NPUBBYTES]
        ct = blob[crypto_aead_xchacha20poly1305_ietf_NPUBBYTES:]

        try:
            # bindings: decrypt(ciphertext, ad, nonce, key)
            plaintext = crypto_aead_xchacha20poly1305_ietf_decrypt(
                ct,
                b"",      # AAD (non usata per ora)
                nonce,
                self.shared_secret,
            )
        except Exception as e:
            print(f"[SEC][ERROR] decryption failed: {e}")
            return

        try:
            msg = plaintext.decode("utf-8", errors="replace")
        except Exception:
            msg = repr(plaintext)

        print(f"[SEC] Decrypted secure message from DIN {din}: {msg}")

    # ========================
    #  ALTRO
    # ========================

    def frisbeeReceivedEvent(self, din):
        print(f"[EVENT] FRISBEE")

    def nodeStateReceivedEvent(self, din):
        print(f"[EVENT] Node state received")

    def atsSyncCompleted(self, din):
        print(f"[EVENT] ATS sync completed")

    def frisbeeDperfCompleted(self, din, packets_sent, block_size):
        print(f"[EVENT] Frisbee dperf completed")


# ===== MAIN RECEIVER =====

if __name__ == "__main__":
    handler = MyHandler()

    node = pydaasiot.DaasWrapper("config.json", handler)
    handler.node = node

    # Generiamo le chiavi ECDH lato "server"
    server_pk, server_sk = crypto_kx_keypair()
    handler.server_pk = server_pk
    handler.server_sk = server_sk

    print("=== RECEIVER ECDH KEYS ===")
    print(f"[KX] server_pk = {server_pk.hex()}")
    print(f"[KX] server_sk = {server_sk.hex()}")

    # SID=100, DIN=101 per il receiver
    node.doInit(100, 101)

    # Driver INET4 locale
    node.enableDriver(pydaasiot.link_t._LINK_INET4, "127.0.0.1:2222")

    # Mappiamo il sender (DIN 102)
    node.map(102, pydaasiot.link_t._LINK_INET4, "127.0.0.1:2223")

    # Avvia il core thread
    node.doPerform(pydaasiot.performs_mode_t.PERFORM_CORE_THREAD)

    input("Receiver pronto. Premi Invio per uscire...\n")

#ARMV7 Processor rev 4 (v7l)