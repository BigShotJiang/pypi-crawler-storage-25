import sys
import argparse
import pydaasiot

from PyQt6.QtCore import QObject, pyqtSignal, Qt
from PyQt6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QTextEdit,
    QLineEdit,
    QPushButton,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QFrame,
    QGridLayout,
)
from PyQt6.QtGui import QTextCursor  # (rimane, nel caso serva in futuro)


# ==========================
# UTILITY PER PULIRE IL PAYLOAD
# ==========================

def sanitize_payload_text(raw: str, payload_size: int | None = None) -> str:
    """
    Ripulisce il testo proveniente da ddo.payload_text()
    - Taglia alla lunghezza payload_size (per evitare padding extra)
    - Taglia alla prima occorrenza di '\\x00'
    - Rimuove eventuali caratteri non stampabili in coda
    come fatto in control/status panel.
    """
    if raw is None:
        return ""

    # 1) taglia a payload_size, se fornito
    if payload_size is not None and payload_size > 0:
        # In DaaS 1 byte = 1 char, quindi lo usiamo come lunghezza stringa
        print(payload_size)
        if len(raw) > payload_size:
            raw = raw[:payload_size-1]

    # 2) Taglia alla prima occorrenza di '\x00'
    zero_pos = raw.find("\x00")
    if zero_pos != -1:
        raw = raw[:zero_pos]

    # 3) Rimuovi eventuali altri caratteri non stampabili in coda
    # (teniamo solo newline e tab)
    while raw and ord(raw[-1]) < 32 and raw[-1] not in ("\n", "\t"):
        raw = raw[:-1]

    return raw.strip()


# ==========================
# SIGNALS / HANDLER
# ==========================

class ChatSignals(QObject):
    """
    Signal Qt per ricevere messaggi dal thread DaaS.
    """
    message_received = pyqtSignal(int, str)  # din, text


class DaasEventHandler(pydaasiot.IDaasApiEvent):
    """
    Handler degli eventi DaaS che gira nel thread interno di libdaas.
    Non deve mai toccare direttamente i widget Qt!
    Invece emette signal verso la GUI.
    """
    def __init__(self, signals: ChatSignals):
        super().__init__()
        self.signals = signals
        self.node = None  # verrà impostato dopo la creazione del DaasWrapper

    # --- Eventi DaaS ---

    def dinAcceptedEvent(self, din):
        print(f"[EVENT] DIN accepted: {din}")

    def ddoReceivedEvent(self, payload_size, typeset, din):
        print(f"[EVENT] DDO received: din={din}, size={payload_size}, typeset={typeset}")

        if self.node is None:
            print("[WARN] node non impostato in handler")
            return

        err, ddo = self.node.pull(din)
        if err == pydaasiot.daas_error_t.ERROR_NONE and ddo is not None:
            try:
                raw_text = ddo.payload_text()
                text = sanitize_payload_text(raw_text, payload_size=payload_size-1)
            except Exception as e:
                print(f"[ERROR] payload_text() failed: {e}")
                text = "<invalid payload>"

            print(f"[PULL] Payload from DIN {din}: raw={repr(raw_text)} -> clean={repr(text)}")
            # Emesso verso il thread GUI
            self.signals.message_received.emit(din, text)
        else:
            print(f"[PULL] Pull failed with error {err}")

    def frisbeeReceivedEvent(self, din):
        print(f"[EVENT] FRISBEE from DIN {din}")

    def nodeStateReceivedEvent(self, din):
        print(f"[EVENT] Node state received from DIN {din}")

    def atsSyncCompleted(self, din):
        print(f"[EVENT] ATS sync completed for DIN {din}")

    def frisbeeDperfCompleted(self, din, packets_sent, block_size):
        print(f"[EVENT] Frisbee dperf completed: din={din}, pkt={packets_sent}, block={block_size}")


# ==========================
# GUI ChatWindow
# ==========================

class ChatWindow(QMainWindow):
    def __init__(self, node: pydaasiot.DaasWrapper, signals: ChatSignals,
                 sid: int, local_din: int, local_addr: str,
                 remote_din: int, remote_addr: str,
                 parent=None):
        super().__init__(parent)
        self.node = node
        self.sid = sid
        self.local_din = local_din
        self.local_addr = local_addr
        self.remote_din = remote_din
        self.remote_addr = remote_addr

        self.setWindowTitle(
            f"DaaS Chat  •  SID {sid}  •  DIN {local_din}"
        )
        self.resize(600, 450)

        # --- Root widget/layout ---
        central = QWidget()
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(14, 14, 14, 14)
        main_layout.setSpacing(12)

        # ==========================
        # HEADER CARD
        # ==========================

        header_frame = QFrame()
        header_frame.setObjectName("headerFrame")
        header_layout = QGridLayout(header_frame)
        header_layout.setContentsMargins(10, 10, 10, 10)
        header_layout.setHorizontalSpacing(20)
        header_layout.setVerticalSpacing(4)

        # Titolo sopra
        title_label = QLabel("DaaS-IoT Chat Session")
        title_label.setObjectName("titleLabel")

        # Tag Local / Remote
        tag_local = QLabel("LOCAL NODE")
        tag_local.setObjectName("tagLocal")
        tag_remote = QLabel("REMOTE PEER")
        tag_remote.setObjectName("tagRemote")

        # Info Local
        local_din_label = QLabel(f"DIN {local_din}")
        local_din_label.setObjectName("dinLabel")
        local_addr_label = QLabel(f"{local_addr}")
        local_addr_label.setObjectName("addrLabel")

        # Info Remote
        remote_din_label = QLabel(f"DIN {remote_din}")
        remote_din_label.setObjectName("dinLabel")
        remote_addr_label = QLabel(f"{remote_addr}")
        remote_addr_label.setObjectName("addrLabel")

        # Piccola info SID
        sid_label = QLabel(f"SID {sid}")
        sid_label.setObjectName("sidLabel")

        # Layout header: titolo + due colonne
        header_layout.addWidget(title_label, 0, 0, 1, 2)
        header_layout.addWidget(sid_label, 0, 2, 1, 1, Qt.AlignmentFlag.AlignRight)

        # Colonna Local
        header_layout.addWidget(tag_local, 1, 0)
        header_layout.addWidget(local_din_label, 2, 0)
        header_layout.addWidget(local_addr_label, 3, 0)

        # Colonna Remote
        header_layout.addWidget(tag_remote, 1, 1)
        header_layout.addWidget(remote_din_label, 2, 1)
        header_layout.addWidget(remote_addr_label, 3, 1)

        header_layout.setColumnStretch(0, 1)
        header_layout.setColumnStretch(1, 1)
        header_layout.setColumnStretch(2, 0)

        main_layout.addWidget(header_frame)

        # ==========================
        # AREA CHAT (LISTA DI BUBBLE)
        # ==========================
        self.chat_list = QListWidget()
        self.chat_list.setObjectName("chatList")
        self.chat_list.setFrameShape(QFrame.Shape.NoFrame)
        self.chat_list.setSpacing(6)
        main_layout.addWidget(self.chat_list, stretch=1)

        # ==========================
        # INPUT BAR
        # ==========================
        input_layout = QHBoxLayout()
        input_layout.setSpacing(8)

        self.input_line = QLineEdit()
        self.input_line.setPlaceholderText("Scrivi un messaggio...")
        self.input_line.setObjectName("inputLine")

        self.send_button = QPushButton("Invia")
        self.send_button.setObjectName("sendButton")

        input_layout.addWidget(self.input_line, stretch=1)
        input_layout.addWidget(self.send_button)

        main_layout.addLayout(input_layout)

        self.setCentralWidget(central)

        # --- Signals ---
        self.send_button.clicked.connect(self.on_send_clicked)
        self.input_line.returnPressed.connect(self.on_send_clicked)

        signals.message_received.connect(self.on_message_received)

    # ==========
    # CHAT LOGIC
    # ==========

    def add_message_item(self, text: str, outbound: bool):
        """
        outbound=True  -> messaggio inviato (a destra, bubble verde)
        outbound=False -> messaggio ricevuto (a sinistra, bubble scura)
        """
        item = QListWidgetItem()

        # Widget contenitore per la riga
        row_widget = QWidget()
        row_layout = QHBoxLayout(row_widget)
        row_layout.setContentsMargins(6, 0, 6, 0)
        row_layout.setSpacing(6)

        # Bubble vera e propria
        bubble = QLabel(text)
        bubble.setWordWrap(True)
        bubble.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse
        )

        if outbound:
            bubble.setObjectName("bubbleOutgoing")
            # allinea a destra: stretch prima, bubble dopo
            row_layout.addStretch(1)
            row_layout.addWidget(bubble, 0)
        else:
            bubble.setObjectName("bubbleIncoming")
            # allinea a sinistra: bubble, poi stretch
            row_layout.addWidget(bubble, 0)
            row_layout.addStretch(1)

        row_widget.setLayout(row_layout)

        # La size dell'item si basa sul widget
        item.setSizeHint(row_widget.sizeHint())
        self.chat_list.addItem(item)
        self.chat_list.setItemWidget(item, row_widget)
        self.chat_list.scrollToBottom()

    # --- Slot GUI ---

    def on_message_received(self, din: int, text: str):
        # Messaggio in ingresso -> bubble a sinistra
        display_text = f"[DIN {din}] {text}"
        self.add_message_item(display_text, outbound=False)

    def on_send_clicked(self):
        text = self.input_line.text().strip()
        if not text:
            return

        # Mostra subito nella chat locale (bubble a destra)
        self.add_message_item(text, outbound=True)
        self.input_line.clear()

        # Crea un DDO e lo invia
        ddo = pydaasiot.DDO()
        ddo.setOrigin(self.local_din)
        ddo.setTypeset(1)  # typeset di esempio
        payload_bytes = text.encode("utf-8")

        ddo.allocatePayload(len(payload_bytes))
        ddo.appendPayloadData(payload_bytes)

        err = self.node.push(self.remote_din, ddo)
        print(f"[PUSH] Push result: {err}")


# ==========================
# PARSING ARGOMENTI
# ==========================

def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        description="DaaS-IoT Chat GUI (PyQt + pydaasiot)"
    )
    parser.add_argument(
        "--sid",
        type=int,
        default=100,
        help="SID del nodo locale (default: 100)",
    )
    parser.add_argument(
        "--local-din",
        type=int,
        required=True,
        help="DIN del nodo locale",
    )
    parser.add_argument(
        "--local-addr",
        type=str,
        required=True,
        help='Indirizzo per il driver locale, es: "127.0.0.1:2222"',
    )
    parser.add_argument(
        "--remote-din",
        type=int,
        required=True,
        help="DIN del nodo remoto (peer)",
    )
    parser.add_argument(
        "--remote-addr",
        type=str,
        required=True,
        help='Indirizzo del peer remoto, es: "127.0.0.1:2223"',
    )
    parser.add_argument(
        "--config",
        type=str,
        default="config.json",
        help='Path al file di configurazione DaaS (default: "config.json")',
    )
    return parser.parse_args(argv)


# ==========================
# MAIN
# ==========================

def main(argv=None):
    args = parse_args(argv)

    print("=== DaaS Chat GUI ===")
    print(f"  SID          : {args.sid}")
    print(f"  Local DIN    : {args.local_din}")
    print(f"  Local Addr   : {args.local_addr}")
    print(f"  Remote DIN   : {args.remote_din}")
    print(f"  Remote Addr  : {args.remote_addr}")
    print(f'  Config       : {args.config}')
    print("======================")

    app = QApplication(sys.argv)

    # --- Stile globale "chat moderna" ---
    app.setStyleSheet("""
    QMainWindow {
        background-color: #121212;
    }

    #headerFrame {
        background-color: #1e1e1e;
        border-radius: 12px;
        border: 1px solid #303030;
    }

    #titleLabel {
        font-size: 16px;
        font-weight: 600;
        color: #f5f5f5;
    }

    #sidLabel {
        font-size: 12px;
        color: #bbbbbb;
    }

    #tagLocal, #tagRemote {
        font-size: 11px;
        font-weight: 600;
        letter-spacing: 1px;
        text-transform: uppercase;
    }

    #tagLocal {
        color: #4caf50;
    }

    #tagRemote {
        color: #03a9f4;
    }

    #dinLabel {
        font-size: 14px;
        font-weight: 600;
        color: #f5f5f5;
    }

    #addrLabel {
        font-size: 12px;
        color: #aaaaaa;
    }

    #chatView {
        background-color: #181818;
        border-radius: 10px;
        border: 1px solid #303030;
        color: #f5f5f5;
        padding: 8px;
    }

    #chatList {
        background-color: #181818;
        border-radius: 10px;
        border: 1px solid #303030;
        padding: 8px;
    }

    #bubbleOutgoing {
        background-color: #2e7d32;
        color: #ffffff;
        border-radius: 14px;
        padding: 8px 12px;
        font-size: 13px;
    }

    #bubbleIncoming {
        background-color: #263238;
        color: #eceff1;
        border-radius: 14px;
        padding: 8px 12px;
        font-size: 13px;
    }

    #inputLine {
        background-color: #181818;
        border-radius: 18px;
        border: 1px solid #303030;
        padding: 6px 12px;
        color: #f5f5f5;
    }

    #inputLine:focus {
        border: 1px solid #4caf50;
        outline: none;
    }

    #sendButton {
        background-color: #4caf50;
        color: white;
        border-radius: 18px;
        padding: 6px 16px;
        border: none;
        font-weight: 600;
    }

    #sendButton:hover {
        background-color: #66bb6a;
    }

    #sendButton:pressed {
        background-color: #388e3c;
    }
    """)

    # Signals condivisi tra handler DaaS e GUI
    signals = ChatSignals()

    # Crea handler DaaS
    handler = DaasEventHandler(signals)

    # Crea e configura il nodo DaaS
    node = pydaasiot.DaasWrapper(args.config, handler)
    handler.node = node  # l'handler deve conoscere il node

    # Inizializza come nel tuo esempio, ma parametricamente
    node.doInit(args.sid, args.local_din)
    node.enableDriver(pydaasiot.link_t._LINK_INET4, args.local_addr)
    node.map(args.remote_din, pydaasiot.link_t._LINK_INET4, args.remote_addr)

    # Avvia il thread interno DaaS
    node.doPerform(pydaasiot.performs_mode_t.PERFORM_CORE_THREAD)

    # Crea e mostra la finestra
    window = ChatWindow(
        node=node,
        signals=signals,
        sid=args.sid,
        local_din=args.local_din,
        local_addr=args.local_addr,
        remote_din=args.remote_din,
        remote_addr=args.remote_addr,
    )
    window.show()

    # Event loop Qt
    exit_code = app.exec()

    # (opzionale) logica di shutdown del nodo se necessario
    # node.doStop()  # se esiste un metodo analogo

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
