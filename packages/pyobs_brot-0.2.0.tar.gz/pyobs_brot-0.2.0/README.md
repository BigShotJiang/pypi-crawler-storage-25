BROTlib module for *pyobs*
==========================

