#!/usr/bin/env bash
# SessionStart hook: ensure voice-bridge-mcp is installed at the required version.
#
# Strategy (in order):
#   1. If `voice-bridge-mcp` resolves on PATH AND its version >= REQUIRED_VERSION,
#      we're done.
#   2. If ~/.local/bin/voice-bridge-mcp exists at the right version (uv tool's
#      canonical location), we're done -- but warn if PATH-resolution differs,
#      because the user has a stale install shadowing it.
#   3. Else, install via `uv tool install` (preferred -- isolated, stable script
#      path in ~/.local/bin, no system Python pollution).
#   4. Else, fall back to `python3 -m pip install --user`. NOTE: this is
#      best-effort. Works on python.org installer Pythons; blocked on Pythons
#      with PEP 668 EXTERNALLY-MANAGED markers (Debian/Ubuntu, recent Homebrew).
#      The uv path above is the robust one.

set -euo pipefail

REQUIRED_VERSION="0.1.5"
UV_BIN="$HOME/.local/bin/voice-bridge-mcp"

emit() {
    printf '{"hookSpecificOutput":{"additionalContext":"[voice-bridge] %s"}}\n' "$1"
}

# Returns 0 if `$1 --version` >= REQUIRED_VERSION, else 1.
version_ok_at() {
    local cmd="$1" installed
    installed=$("$cmd" --version 2>/dev/null | awk '{print $NF}')
    [ -n "$installed" ] || return 1
    # `sort -V` puts older versions first; if required sorts first, installed is >=.
    [ "$(printf '%s\n%s\n' "$REQUIRED_VERSION" "$installed" | sort -V | head -1)" = "$REQUIRED_VERSION" ]
}

# 1. Already on PATH at the right version?
if command -v voice-bridge-mcp >/dev/null 2>&1 && version_ok_at voice-bridge-mcp; then
    exit 0
fi

# 2. uv-managed install present at canonical location? Trust it even if PATH points elsewhere.
if [ -x "$UV_BIN" ] && version_ok_at "$UV_BIN"; then
    # Detect a shadowing problem and inform the user once per session.
    on_path=$(command -v voice-bridge-mcp 2>/dev/null || true)
    if [ -n "$on_path" ] && [ "$on_path" != "$UV_BIN" ]; then
        emit "Up-to-date install at $UV_BIN, but PATH resolves voice-bridge-mcp to $on_path. Move ~/.local/bin earlier in PATH, or remove the stale install."
    fi
    exit 0
fi

# 3. Prefer uv tool install -- isolated, stable script path
if command -v uv >/dev/null 2>&1; then
    emit "Installing via uv tool install..."
    if uv tool install --quiet --force "ai-voice-bridge[edge,mcp]" 2>/dev/null; then
        emit "Installed via uv. Run \`voice-bridge test\` to verify audio."
        exit 0
    fi
fi

# 4. Fall back to pip --user. Best-effort: blocked by PEP 668 on EXTERNALLY-MANAGED Pythons.
emit "Installing via pip --user (best-effort fallback)..."
if python3 -m pip install --user --quiet --upgrade "ai-voice-bridge[edge,mcp]" 2>/dev/null; then
    emit "Installed. Ensure ~/.local/bin is on PATH."
    exit 0
fi

emit "Install failed. Install uv: curl -LsSf https://astral.sh/uv/install.sh | sh"
exit 0
