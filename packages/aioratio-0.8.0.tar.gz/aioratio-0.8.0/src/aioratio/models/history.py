"""Charge-session history dataclass models.

Sources: ``charger_history/domain/model/Session.java``,
``TimeDataModel.java`` and ``ChargeSessionHistoryResponse.java``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Self

from ..exceptions import RatioApiError
from .vehicle import Vehicle


def _required(data: dict[str, Any], key: str) -> Any:
    if key not in data:
        raise RatioApiError(f"missing required field: {key}")
    return data[key]


@dataclass(slots=True)
class TimeData:
    """Begin/end marker for a session.

    Source: ``TimeDataModel.java``.
    """

    time: int
    type: str | None = None
    user_uuid: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        return cls(
            time=int(data.get("time", 0)),
            type=data.get("type"),
            user_uuid=data.get("userUuid"),
        )

    def to_dict(self) -> dict[str, Any]:
        return {"time": self.time, "type": self.type, "userUuid": self.user_uuid}


@dataclass(slots=True)
class Session:
    """A single completed charge session.

    Source: ``Session.java``.
    """

    session_id: str
    charger_serial_number: str
    total_charging_energy: int
    begin: TimeData | None = None
    end: TimeData | None = None
    user_id: str | None = None
    vehicle: Vehicle | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        b = data.get("begin")
        e = data.get("end")
        v = data.get("vehicle")
        return cls(
            session_id=_required(data, "sessionId"),
            charger_serial_number=_required(data, "chargerSerialNumber"),
            total_charging_energy=int(data.get("totalChargingEnergy", 0)),
            begin=TimeData.from_dict(b) if isinstance(b, dict) else None,
            end=TimeData.from_dict(e) if isinstance(e, dict) else None,
            user_id=data.get("userId"),
            vehicle=Vehicle.from_dict(v) if isinstance(v, dict) else None,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "sessionId": self.session_id,
            "chargerSerialNumber": self.charger_serial_number,
            "totalChargingEnergy": self.total_charging_energy,
            "begin": self.begin.to_dict() if self.begin else None,
            "end": self.end.to_dict() if self.end else None,
            "userId": self.user_id,
            "vehicle": self.vehicle.to_dict() if self.vehicle else None,
        }


@dataclass(slots=True)
class SessionHistoryPage:
    """Paginated wrapper around a list of sessions.

    Source: ``ChargeSessionHistoryResponse.java`` — exposes
    ``chargeSessions`` and ``nextToken`` JSON keys.
    """

    sessions: list[Session] = field(default_factory=list)
    next_token: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        raw = data.get("chargeSessions") or data.get("sessions") or []
        return cls(
            sessions=[Session.from_dict(s) for s in raw if isinstance(s, dict)],
            next_token=data.get("nextToken"),
        )
