"""
全局 LMDB Environment 管理器

确保同一路径只开一个 env，支持 named sub-database。
"""

import os
import threading

import lmdb

from flaxkv2.utils.log import get_logger

logger = get_logger(__name__)

_DEFAULT_MAP_SIZE = 1 << 30  # 1GB
_MAX_DBS = 16


class EnvManager:
    """全局 LMDB Environment 管理器，引用计数管理 env 生命周期。"""

    def __init__(self):
        self._envs: dict[str, lmdb.Environment] = {}
        self._refcounts: dict[str, int] = {}
        self._db_handles: dict[tuple[str, str], object] = {}
        self._lock = threading.Lock()

    def acquire(
        self,
        path: str,
        map_size: int = _DEFAULT_MAP_SIZE,
        max_readers: int = 126,
    ) -> lmdb.Environment:
        """获取 env，引用计数 +1。同一路径复用已有 env。"""
        normalized = os.path.abspath(path)
        with self._lock:
            if normalized in self._envs:
                self._refcounts[normalized] += 1
                # 如果请求的 map_size 更大，扩容
                env = self._envs[normalized]
                current_size = env.info()["map_size"]
                if map_size > current_size:
                    env.set_mapsize(map_size)
                    logger.debug(
                        f"Env map_size expanded to {map_size / (1024*1024):.0f} MB: {normalized}"
                    )
                return env

            os.makedirs(normalized, exist_ok=True)
            env = lmdb.open(
                normalized,
                map_size=map_size,
                max_readers=max_readers,
                max_dbs=_MAX_DBS,
                subdir=True,
                lock=True,
                readahead=False,
            )
            self._envs[normalized] = env
            self._refcounts[normalized] = 1
            return env

    def release(self, path: str):
        """引用计数 -1，归零时关闭 env 并清理 db_handles。"""
        normalized = os.path.abspath(path)
        with self._lock:
            if normalized not in self._refcounts:
                logger.warning(f"release called for unknown path: {normalized}")
                return

            self._refcounts[normalized] -= 1
            if self._refcounts[normalized] <= 0:
                # 清理 db_handles
                to_remove = [k for k in self._db_handles if k[0] == normalized]
                for k in to_remove:
                    del self._db_handles[k]

                # 关闭 env
                env = self._envs.pop(normalized, None)
                self._refcounts.pop(normalized, None)
                if env is not None:
                    try:
                        env.close()
                    except Exception as e:
                        logger.error(f"Error closing env {normalized}: {e}")

    def open_db(self, path: str, sub_db: str | None) -> object | None:
        """获取 named database handle。sub_db=None 返回 None。"""
        if sub_db is None:
            return None

        normalized = os.path.abspath(path)
        cache_key = (normalized, sub_db)
        with self._lock:
            if cache_key in self._db_handles:
                return self._db_handles[cache_key]

            env = self._envs.get(normalized)
            if env is None:
                raise RuntimeError(
                    f"No env for path {normalized}. Call acquire() first."
                )

            handle = env.open_db(sub_db.encode("utf-8"))
            self._db_handles[cache_key] = handle
            return handle

    def resize_mapsize(self, path: str, new_size: int):
        """扩容 map_size（由 write_with_retry 在 MapFullError 时调用）。"""
        normalized = os.path.abspath(path)
        with self._lock:
            env = self._envs.get(normalized)
            if env is not None:
                env.set_mapsize(new_size)
                logger.warning(
                    f"LMDB map resized to {new_size / (1024*1024):.0f} MB: {normalized}"
                )

    def _cleanup_all(self):
        """清理所有 env（测试用）。"""
        with self._lock:
            for env in self._envs.values():
                try:
                    env.close()
                except Exception:
                    pass
            self._envs.clear()
            self._refcounts.clear()
            self._db_handles.clear()


env_manager = EnvManager()
