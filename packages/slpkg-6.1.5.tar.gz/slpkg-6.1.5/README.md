[![Latest Release](https://gitlab.com/dslackw/slpkg/-/badges/release.svg)](https://gitlab.com/dslackw/slpkg/-/releases)
[![pipeline status](https://img.shields.io/badge/pipeline-master-blue)](https://gitlab.com/dslackw/slpkg/-/commits/master)
[![coverage report](https://gitlab.com/dslackw/slpkg/badges/master/coverage.svg)](https://gitlab.com/dslackw/slpkg/-/commits/master)
[![Python](https://img.shields.io/badge/python-3.9_|_3.12-blue)](https://www.python.org/)
[![Code style: flake8](https://img.shields.io/badge/code%20style-flake8-orange)](https://flake8.pycqa.org/)
[![Type checked: mypy](https://img.shields.io/badge/type%20checked-mypy-blue)](https://mypy-lang.org/)
[![Linting: pylint](https://img.shields.io/badge/linting-pylint-yellowgreen)](https://pylint.org/)
[![License: GPL v3](https://img.shields.io/badge/license-GPLv3-blue)](LICENSE)

[<img src="https://gitlab.com/dslackw/slpkg/-/raw/site/docs/images/logo.png" title="slpkg">](https://dslackw.gitlab.io/slpkg)

## About

Slpkg is a feature-rich package manager for <a href="https://www.slackware.com" target="_blank">Slackware</a>-based systems. It installs, upgrades, removes, and builds packages from multiple repositories, including SlackBuilds.org (SBo, Ponce) and binary repositories. Slpkg automatically resolves and tracks dependencies, maintains a full installation history with transaction rollback, detects orphaned and foreign packages, and verifies the integrity of installed files. Additional features include reverse dependency analysis, package pinning and blacklisting, security auditing, file search within package indexes, and export/import of package lists. The tool follows the standards of the <a href="https://www.slackbuilds.org" target="_blank">slackbuilds.org</a> organization and Slackware Linux's official procedures for package installation, upgrades, and removal.

## Homepage

Visit the project website [here](https://dslackw.gitlab.io/slpkg/).

## Source

* <a href="https://gitlab.com/dslackw/slpkg" target="_blank">GitLab</a> repository.
* <a href="https://slackbuilds.org/repository/15.0/system/slpkg/" target="_blank">SlackBuilds.org</a> repository.
* <a href="https://sourceforge.net/projects/slpkg/" target="_blank">SourceForge</a> repository.
* <a href="https://pypi.org/project/slpkg/" target="_blank">PyPI</a> repository.

## License

[GNU General Public License v3 (GPLv3)](https://dslackw.gitlab.io/slpkg/license/)

## Donate

Did you know that developers love coffee?

[<img src="https://gitlab.com/dslackw/slpkg/-/raw/site/docs/images/paypaldonate.png" alt="paypal" title="donate">](https://www.paypal.me/dslackw)

## Support

Please support:

* <a href="https://www.patreon.com/slackwarelinux" target="_blank">Slackware</a> project.
* <a href="https://slackbuilds.org/contributors/" target="_blank">SlackBuilds</a> project.
* <a href="https://alien.slackbook.org/blog/" target="_blank">AlienBob</a> project.

Thank you all for your support!

## Contributing

Contributions are welcome! Please read the [Contributing Guide](CONTRIBUTING.md) before submitting issues or merge requests.

## NOTE
**The GitHub repository is a read-only mirror** of the official repository hosted on GitLab.
All development activity, including issues and contributions, takes place on GitLab.
Please visit the official repository at [gitlab.com/dslackw/slpkg](https://gitlab.com/dslackw/slpkg) to:
- 🐛 Report bugs or open issues
- 🔀 Submit merge requests
- 💬 Join discussions
- ⭐ Star the project

## Copyrights

Slackware® is a Registered Trademark of Patrick Volkerding.
Linux is a Registered Trademark of Linus Torvalds.
