#!/usr/bin/python3


from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

from slpkg.config import config_load

try:
    INSTALLED_VERSION = version("slpkg")
except PackageNotFoundError:
    INSTALLED_VERSION = "unknown"


class Version:  # pylint: disable=[R0903]
    """Print the version."""

    def __init__(self) -> None:
        self.version = INSTALLED_VERSION
        self.license = "GPLv3"
        self.homepage = "https://dslackw.gitlab.io/slpkg"
        self.arch = config_load.cpu_arch

    def view(self) -> None:
        """Print the version."""
        print(f"slpkg {self.version} ({self.arch})\nLicense: {self.license}\nHomepage: {self.homepage}")
