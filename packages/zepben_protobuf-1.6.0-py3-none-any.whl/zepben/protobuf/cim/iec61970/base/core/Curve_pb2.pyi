from zepben.protobuf.cim.iec61970.base.core import IdentifiedObject_pb2 as _IdentifiedObject_pb2
from zepben.protobuf.cim.iec61970.base.core import CurveData_pb2 as _CurveData_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Curve(_message.Message):
    __slots__ = ("io", "curveData")
    IO_FIELD_NUMBER: _ClassVar[int]
    CURVEDATA_FIELD_NUMBER: _ClassVar[int]
    io: _IdentifiedObject_pb2.IdentifiedObject
    curveData: _containers.RepeatedCompositeFieldContainer[_CurveData_pb2.CurveData]
    def __init__(self, io: _Optional[_Union[_IdentifiedObject_pb2.IdentifiedObject, _Mapping]] = ..., curveData: _Optional[_Iterable[_Union[_CurveData_pb2.CurveData, _Mapping]]] = ...) -> None: ...
