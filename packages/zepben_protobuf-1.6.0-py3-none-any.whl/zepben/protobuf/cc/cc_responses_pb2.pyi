from zepben.protobuf.cc import cc_data_pb2 as _cc_data_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GetIdentifiablesResponse(_message.Message):
    __slots__ = ("messageId", "identifiables")
    MESSAGEID_FIELD_NUMBER: _ClassVar[int]
    IDENTIFIABLES_FIELD_NUMBER: _ClassVar[int]
    messageId: int
    identifiables: _containers.RepeatedCompositeFieldContainer[_cc_data_pb2.CustomerIdentifiable]
    def __init__(self, messageId: _Optional[int] = ..., identifiables: _Optional[_Iterable[_Union[_cc_data_pb2.CustomerIdentifiable, _Mapping]]] = ...) -> None: ...

class GetCustomersForContainerResponse(_message.Message):
    __slots__ = ("messageId", "identifiables")
    MESSAGEID_FIELD_NUMBER: _ClassVar[int]
    IDENTIFIABLES_FIELD_NUMBER: _ClassVar[int]
    messageId: int
    identifiables: _containers.RepeatedCompositeFieldContainer[_cc_data_pb2.CustomerIdentifiable]
    def __init__(self, messageId: _Optional[int] = ..., identifiables: _Optional[_Iterable[_Union[_cc_data_pb2.CustomerIdentifiable, _Mapping]]] = ...) -> None: ...
