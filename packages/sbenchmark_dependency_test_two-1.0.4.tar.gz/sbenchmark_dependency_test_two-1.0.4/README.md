# sbenchmark-dependency-test-two

Minimal library exposing four functions:

Functions:
- `name() -> str`
- `version_number() -> str`
- `version() -> str`
- `dependency() -> str` (delegates to `sbenchmark-dependency-test-one.version()`)

## Usage

```python
from sbenchmark_dependency_test_two import name, version_number, version, dependency

print(name())           # "sbenchmark-dependency-test-two"
print(version_number()) # "1.0.3"
print(version())        # "sbenchmark-dependency-test-two,1.0.3"
print(dependency())     # "sbenchmark-dependency-test-one,1.0.4"
