from __future__ import annotations

from pathlib import Path

from ..types import Tempo, EdgeKind, Symbol
from ._utils import _is_test_file
from .focused import _cochange_orbit

def _blast_core_a_exposure(
    graph: "Tempo",
    file_path: str,
    symbols: list,
    importers: list[str],
    lines: list[str],
) -> None:
    # S99: Peak exposure — the exported symbol with the most cross-file callers.
    # When a file has many exported symbols, agents need to know WHICH one carries the most risk.
    # Only shown when 2+ exported symbols exist and the peak has >= 3 cross-file callers.
    _peak_sym: "Symbol | None" = None
    _peak_count = 0
    for _exp_sym in symbols:
        if not _exp_sym.exported or _exp_sym.kind.value not in ("function", "method"):
            continue
        _cf = len({c.file_path for c in graph.callers_of(_exp_sym.id) if c.file_path != file_path and not _is_test_file(c.file_path)})
        if _cf > _peak_count:
            _peak_count = _cf
            _peak_sym = _exp_sym
    _exp_sym_count = sum(1 for s in symbols if s.exported and s.kind.value in ("function", "method"))
    if _peak_sym and _peak_count >= 3 and _exp_sym_count >= 2:
        lines.append(f"Peak exposure: {_peak_sym.name} ({_peak_count} caller files) — most-called export")
        lines.append("")

    # S183: Large export count — blast target exports >= 10 symbols.
    # High export count = large public API surface; any change is a potential breaking change.
    # Only shown when the blast file exports >= 10 fn/method/class/interface symbols.
    _s183_exported = [
        s for s in symbols
        if s.exported and s.kind.value in ("function", "method", "class", "interface")
    ]
    if len(_s183_exported) >= 10:
        lines.append(
            f"large export count: {len(_s183_exported)} exported symbols"
            f" — broad public API surface, changes risk breaking callers"
        )

    # S301: Large API surface — target file exports 15+ distinct symbols.
    # Files with large symbol counts have wide blast radii even without explicit importers;
    # any rename, signature change, or removal can break many unknown consumers.
    # O(N) fix: use symbols param (already filtered to file_path) instead of graph.symbols.values().
    # Only fires when S183 did NOT already fire (avoids duplicate "large export" messages).
    _s301_exported = [
        s for s in symbols
        if s.exported
        and s.kind.value in ("function", "method", "class", "variable", "constant")
    ]
    if len(_s301_exported) >= 15 and len(_s183_exported) < 10:
        lines.append(
            f"large API surface: {len(_s301_exported)} exported symbols"
            f" — wide blast radius; renaming or removing any symbol breaks unknown callers"
        )

    # S307: Routing-layer blast — target is imported by files in routes/controllers/views dirs.
    # Route files are the entry-surface of the application; changes to imported utilities
    # may affect request handling, authentication, or serialization globally.
    _s307_route_dirs = ("routes", "controllers", "views", "handlers", "endpoints", "api")
    _s307_route_importers: list[str] = []
    for _imp307 in importers:
        _parts307 = _imp307.lower().replace("\\", "/").split("/")
        if any(p in _s307_route_dirs for p in _parts307):
            _s307_route_importers.append(_imp307)
    if len(_s307_route_importers) >= 2:
        _ri_names307 = ", ".join(fp.rsplit("/", 1)[-1] for fp in _s307_route_importers[:2])
        lines.append(
            f"routing-layer blast: imported by {len(_s307_route_importers)} route/controller file(s)"
            f" ({_ri_names307}) — changes here affect request handling directly"
        )


def _blast_core_a_callers(
    graph: "Tempo",
    file_path: str,
    symbols: list,
    importers: list[str],
    external_callers: dict,
    lines: list[str],
) -> None:
    # S177: Cross-module callers — callers of blast-target symbols span 4+ distinct top-level dirs.
    # When 4+ modules call this file, a change requires coordination across many subsystems.
    # Only shown when callers come from 4+ distinct top-level directories.
    _s177_caller_modules: set[str] = set()
    for _sym177 in symbols:
        for _c177 in graph.callers_of(_sym177.id):
            _parts177 = _c177.file_path.split("/")
            _mod177 = _parts177[0] if len(_parts177) > 1 else "."
            if _mod177 != file_path.split("/")[0]:  # exclude own module
                _s177_caller_modules.add(_mod177)
    if len(_s177_caller_modules) >= 4:
        _s177_mods_str = ", ".join(sorted(_s177_caller_modules)[:4])
        if len(_s177_caller_modules) > 4:
            _s177_mods_str += f" +{len(_s177_caller_modules) - 4} more"
        lines.append(
            f"cross-module callers: {len(_s177_caller_modules)} modules depend on this file"
            f" ({_s177_mods_str})"
        )

    # S219: Call concentration — ≥75% of external CALLS callers reference the same exported symbol.
    # When callers overwhelmingly use one specific symbol, the real blast bottleneck is narrower
    # than the file-level view suggests. Helps agents focus review on that one symbol.
    # Only shown when 4+ distinct non-test external caller files exist and concentration >= 75%.
    _s219_exp_ids = {s.id for s in symbols if s.exported and s.kind.value in ("function", "method")}
    _s219_unique_callers = {
        loc.split(":")[0]
        for locs in external_callers.values()
        for loc in locs
        if not _is_test_file(loc.split(":")[0])
    }
    if len(_s219_unique_callers) >= 4 and _s219_exp_ids:
        _s219_counts: dict[str, int] = {}
        for _sym_id219 in _s219_exp_ids:
            for _caller219 in graph.callers_of(_sym_id219):
                if _caller219.file_path != file_path and not _is_test_file(_caller219.file_path):
                    _s219_counts[_sym_id219] = _s219_counts.get(_sym_id219, 0) + 1
        if _s219_counts:
            _s219_total = sum(_s219_counts.values())
            _s219_top_id, _s219_top_n = max(_s219_counts.items(), key=lambda kv: kv[1])
            if _s219_total > 0 and _s219_top_n / _s219_total >= 0.75:
                _s219_name = next(
                    (s.name for s in symbols if s.id == _s219_top_id), _s219_top_id.split("::")[-1]
                )
                _s219_pct = int(_s219_top_n / _s219_total * 100)
                lines.append(
                    f"call concentration: {_s219_pct}% of callers use {_s219_name}"
                    f" — that symbol is the real blast bottleneck"
                )

    # S284: Cross-package blast — blast target is imported by files in 3+ top-level directories.
    # When a file's importers span many packages, a change creates a coordinated multi-team
    # blast; each package team must review and validate the impact.
    _s284_importer_dirs: set[str] = set()
    for _imp284 in graph.importers_of(file_path):
        if _imp284 in graph.files and _imp284 != file_path:
            _dir284 = _imp284.split("/")[0] if "/" in _imp284 else "."
            if not _dir284.startswith("."):
                _s284_importer_dirs.add(_dir284)
    if len(_s284_importer_dirs) >= 3:
        _dirs284 = sorted(_s284_importer_dirs)[:3]
        _dir_str284 = ", ".join(_dirs284)
        if len(_s284_importer_dirs) > 3:
            _dir_str284 += f" +{len(_s284_importer_dirs) - 3} more"
        lines.append(
            f"cross-package blast: imported by {len(_s284_importer_dirs)} packages ({_dir_str284})"
            f" — multi-team impact; coordinate changes across all consuming packages"
        )


def _blast_core_a_traversal(
    graph: "Tempo",
    file_path: str,
    symbols: list,
    importers: list[str],
    lines: list[str],
) -> None:
    # S88: Transitive blast — BFS through import graph to count all transitively affected files.
    # Direct blast shows 1 hop; transitive blast shows full ripple effect across the codebase.
    # Only shown when transitive count > direct count AND > 5 (otherwise direct already covers it).
    if importers:
        _trans_seen: set[str] = {file_path}
        _trans_depth = 0
        _trans_max_depth = 0
        _level_queue = list(importers)
        while _level_queue and _trans_depth < 8 and len(_trans_seen) < 200:
            _trans_depth += 1
            _next_level: list[str] = []
            for _tf in _level_queue:
                if _tf in _trans_seen:
                    continue
                _trans_seen.add(_tf)
                for _nxt in graph.importers_of(_tf):
                    if _nxt not in _trans_seen and _nxt in graph.files and not _is_test_file(_nxt):
                        _next_level.append(_nxt)
            if _next_level:
                _trans_max_depth = _trans_depth
            _level_queue = _next_level
        _trans_total = len(_trans_seen) - 1  # exclude the file itself
        if _trans_total > len(importers) and _trans_total >= 5:
            _non_test_direct = len([i for i in importers if not _is_test_file(i)])
            lines.append(
                f"Transitive blast: {_trans_total} total files affected "
                f"({_non_test_direct} direct, {_trans_max_depth} levels deep)"
            )
            lines.append("")

    # S171: Indirect blast — files that are 2 hops away via importers (importers of importers).
    # Changing this file ripples to direct importers AND to their importers.
    # Only shown when 5+ distinct 2nd-hop importer files exist.
    _s171_direct = {i for i in graph.importers_of(file_path) if i in graph.files and i != file_path}
    _s171_indirect: set[str] = set()
    for _dir171 in _s171_direct:
        for _ind171 in graph.importers_of(_dir171):
            if _ind171 in graph.files and _ind171 != file_path and _ind171 not in _s171_direct:
                _s171_indirect.add(_ind171)
    if len(_s171_indirect) >= 5:
        lines.append(
            f"indirect blast: {len(_s171_indirect)} files 2 hops away via importers"
            f" — change propagates further than direct importers"
        )

    # S269: Deep importer chain — a direct importer of this file is itself imported by many files.
    # This means changes here amplify: they affect the direct importer AND everything that
    # depends on that importer, creating a second-order blast radius.
    _s269_deep_importers = []
    for _imp269 in graph.importers_of(file_path):
        if _imp269 not in graph.files or _imp269 == file_path:
            continue
        _s269_second_order = len([
            f for f in graph.importers_of(_imp269)
            if f in graph.files and f != file_path and f != _imp269
        ])
        if _s269_second_order >= 5:
            _s269_deep_importers.append((_s269_second_order, _imp269.rsplit("/", 1)[-1]))
    if _s269_deep_importers:
        _s269_deep_importers.sort(reverse=True)
        _n269, _name269 = _s269_deep_importers[0]
        lines.append(
            f"deep importer chain: {_name269} imports this and is itself imported by {_n269} files"
            f" — second-order blast; changes propagate further than direct importers suggest"
        )


def _blast_core_a_coverage(
    graph: "Tempo",
    file_path: str,
    symbols: list,
    importers: list[str],
    external_callers: dict,
    lines: list[str],
) -> None:
    # S70: Singleton caller hint — file only imported by 1 non-test file.
    # This tight coupling suggests the two files may be candidates for merging.
    _src_imps = [imp for imp in importers if not _is_test_file(imp)]
    if len(_src_imps) == 1:
        lines.append(f"Singleton caller: only used by {_src_imps[0].rsplit('/', 1)[-1]} — consider merging")
        lines.append("")

    # S207: Single importer — exactly 1 file imports the blast target.
    # Narrow dependency means blast is contained; useful to know before refactoring.
    # Positive signal: suppressed when importers != 1 (too many = already shown in blast header).
    _s207_importers = [
        i for i in graph.importers_of(file_path)
        if i in graph.files and i != file_path
    ]
    if len(_s207_importers) == 1:
        _s207_name = _s207_importers[0].rsplit("/", 1)[-1]
        lines.append(
            f"single importer: only {_s207_name} imports this file"
            f" — narrow dependency, check that consumer before modifying"
        )

    # S124: Untested blast callers — how many source files importing this file have no test coverage.
    # Complements S122 (ratio) by listing concrete count for agents to action.
    # Only shown when 3+ non-test importers AND test files exist in the project.
    _s124_downstream_src = [f for f in importers if not _is_test_file(f) and f in graph.files]
    if len(_s124_downstream_src) >= 3:
        _s124_all_tests = {fp for fp in graph.files if _is_test_file(fp)}
        if _s124_all_tests:
            _s124_untested = [
                fp for fp in _s124_downstream_src
                if not any(fp.rsplit("/", 1)[-1].rsplit(".", 1)[0] in t for t in _s124_all_tests)
            ]
            if len(_s124_untested) >= 2:
                lines.append(f"untested callers: {len(_s124_untested)}/{len(_s124_downstream_src)} importing files have no tests")

    # S122: Downstream test coverage — fraction of files in blast radius that have tests.
    # Low downstream coverage = high blast risk: breakage can go undetected.
    # Only shown when 4+ non-test importers exist (otherwise blast radius too small to matter).
    _s122_downstream = [f for f in importers if not _is_test_file(f) and f in graph.files]
    if len(_s122_downstream) >= 4:
        _all_proj_test_fps_bl = {fp for fp in graph.files if _is_test_file(fp)}
        if _all_proj_test_fps_bl:
            _s122_tested = sum(
                1 for fp in _s122_downstream
                if any(fp.rsplit("/", 1)[-1].rsplit(".", 1)[0] in t for t in _all_proj_test_fps_bl)
            )
            _s122_total = len(_s122_downstream)
            _s122_pct = int(_s122_tested / _s122_total * 100)
            if _s122_pct < 80:
                lines.append(f"downstream coverage: {_s122_tested}/{_s122_total} importers have tests ({_s122_pct}%)")

    # S251: Well-tested blast — blast target's exported symbols have many test callers.
    # Positive signal: high test coverage means refactoring here has a safety net.
    # Only shown when 5+ distinct test files call into this blast target.
    _s251_test_caller_files: set[str] = set()
    for _sym251 in symbols:
        for _c251 in graph.callers_of(_sym251.id):
            if _is_test_file(_c251.file_path):
                _s251_test_caller_files.add(_c251.file_path)
    if len(_s251_test_caller_files) >= 5:
        lines.append(
            f"well-tested: {len(_s251_test_caller_files)} test file(s) cover this module"
            f" — high safety net; refactoring here is lower risk"
        )

    # S278: Test infrastructure blast — blast target is a conftest or shared test fixture.
    # Changes to test infrastructure (conftest.py, fixtures.py, test_utils.py) affect
    # ALL tests that rely on those fixtures; blast is test-suite-wide.
    _s278_infra_names = {"conftest", "fixtures", "test_utils", "test_helpers", "test_base",
                         "testutils", "testhelpers", "factory", "factories", "fakes", "mocks"}
    _s278_stem = file_path.rsplit("/", 1)[-1].rsplit(".", 1)[0].lower()
    if _s278_stem in _s278_infra_names or _is_test_file(file_path):
        _s278_test_importers = [
            f for f in graph.importers_of(file_path)
            if f in graph.files and _is_test_file(f)
        ]
        if _s278_test_importers:
            lines.append(
                f"test infra blast: {len(_s278_test_importers)} test file(s) depend on this fixture"
                f" — changes here affect the entire test suite"
            )


def _blast_core_a_chains(
    graph: "Tempo",
    file_path: str,
    symbols: list,
    lines: list[str],
) -> None:
    # S90: Call chain preview — top 2-3 entry paths reaching exported symbols in this file.
    # Shows 2-hop chains: "top_caller::fn → mid_caller::fn → target_sym".
    # Only shown when 2+ distinct two-hop chains exist — adds depth the 1-hop callers list misses.
    _cc_exported = sorted(
        (sym for sym in symbols if sym.exported and sym.kind.value in ("function", "method")),
        key=lambda s: -len([
            c for c in graph.callers_of(s.id)
            if c.file_path != file_path and not _is_test_file(c.file_path)
        ])
    )
    if _cc_exported:
        _cc_paths: list[str] = []
        _cc_seen: set[str] = set()
        for _cc_sym in _cc_exported[:4]:
            _cc_ext = [
                c for c in graph.callers_of(_cc_sym.id)
                if c.file_path != file_path and not _is_test_file(c.file_path)
            ]
            for _cc_mid in _cc_ext[:3]:
                _cc_top = [
                    c for c in graph.callers_of(_cc_mid.id)
                    if c.file_path != _cc_mid.file_path
                    and not _is_test_file(c.file_path)
                    and c.file_path != file_path
                ]
                if _cc_top:
                    _top = _cc_top[0]
                    _chain = (
                        f"{_top.file_path.rsplit('/', 1)[-1]}::{_top.name}"
                        f" → {_cc_mid.name} → {_cc_sym.name}"
                    )
                    if _chain not in _cc_seen:
                        _cc_seen.add(_chain)
                        _cc_paths.append(_chain)
        if len(_cc_paths) >= 2:
            lines.append("Call chains (entry paths):")
            for _path in _cc_paths[:3]:
                lines.append(f"  {_path}")
            lines.append("")

    # S165: Call depth — BFS through CALLS edges from blast target, longest chain depth.
    # Deep call chains (>= 4 hops) amplify risk: a change propagates through many stack frames.
    # Only shown when BFS from any symbol in the target file reaches depth >= 4.
    _s165_seed_ids = {s.id for s in symbols}
    _s165_max_depth = 0
    _s165_deepest_name = ""
    for _seed_id165 in list(_s165_seed_ids)[:10]:  # cap BFS seeds for performance
        _s165_visited: set[str] = {_seed_id165}
        _s165_frontier = [(_seed_id165, 0)]
        while _s165_frontier:
            _cur_id165, _depth165 = _s165_frontier.pop(0)
            if _depth165 > _s165_max_depth:
                _s165_max_depth = _depth165
                _s165_deepest_name = graph.symbols[_seed_id165].name if _seed_id165 in graph.symbols else ""
            if _depth165 >= 6:  # safety cap
                continue
            for _callee165 in graph.callees_of(_cur_id165):
                if _callee165.id not in _s165_visited:
                    _s165_visited.add(_callee165.id)
                    _s165_frontier.append((_callee165.id, _depth165 + 1))
    if _s165_max_depth >= 4:
        lines.append(
            f"call depth: {_s165_max_depth} hops from {_s165_deepest_name}"
            f" — deep call chain increases change blast"
        )

    # S239: Async function blast — blast target contains async functions.
    # Callers must properly await async functions; any refactoring to sync breaks all call sites.
    # Only shown when 1+ async function exists in the blast target (Python/JS/TS).
    _s239_async_syms = [
        s for s in symbols
        if s.kind.value in ("function", "method")
        and s.signature
        and (s.signature.startswith("async def ") or s.signature.startswith("async "))
    ]
    if _s239_async_syms:
        _s239_names = [s.name for s in _s239_async_syms[:3]]
        _s239_str = ", ".join(_s239_names)
        if len(_s239_async_syms) > 3:
            _s239_str += f" +{len(_s239_async_syms) - 3} more"
        lines.append(
            f"async blast: {len(_s239_async_syms)} async fn(s) ({_s239_str})"
            f" — callers must await; sync conversion breaks all call sites"
        )


def _blast_core_a_inheritance(
    graph: "Tempo",
    file_path: str,
    symbols: list,
    lines: list[str],
) -> None:
    # S145 and S246 use graph._subtypes dict (parent_id → [subclass_ids]) — O(1) per class
    # instead of O(N) scan of all graph.edges. _subtypes is built in build_indexes().

    # S145: Subclass count — when the blast target defines a class with INHERITS subclasses.
    # Changing a parent class ripples to all subclasses: method overrides, super() calls,
    # type annotations. Flag when 2+ subclasses extend a class defined in this file.
    _s145_classes = [s for s in symbols if s.kind.value in ("class", "interface")]
    if _s145_classes:
        _total_subclasses145: int = 0
        _s145_class_names: list[str] = []
        for _cls145 in _s145_classes:
            _sub_count = len(graph._subtypes.get(_cls145.id, []))
            if _sub_count >= 1:
                _total_subclasses145 += _sub_count
                _s145_class_names.append(f"{_cls145.name} ({_sub_count})")
        if _total_subclasses145 >= 2:
            _s145_str = ", ".join(_s145_class_names[:3])
            lines.append(f"subclass count: {_total_subclasses145} subclasses extend {_s145_str}")

    # S246: Mixin/base class blast — blast target defines a class that other classes inherit from.
    # Mixin or base class changes cascade silently through ALL inheriting classes.
    # Only shown when 1+ class in the file is a base/mixin (other classes inherit from it).
    _s246_mixin_indicators = ("mixin", "base", "abstract", "interface")
    _s246_class_syms = [s for s in symbols if s.kind.value == "class"]
    _s246_mixin_classes = [
        s for s in _s246_class_syms
        if any(ind in s.name.lower() for ind in _s246_mixin_indicators)
    ]
    if not _s246_mixin_classes:
        # Also detect via _subtypes: if any other class inherits from classes in this file
        _s246_this_class_ids = {s.id for s in _s246_class_syms}
        _s246_subclasses: list[str] = []
        for _cid in _s246_this_class_ids:
            for _src_id in graph._subtypes.get(_cid, []):
                if _src_id.split("::")[0] != file_path:
                    _s246_subclasses.append(_src_id.split("::")[-1])
        if len(_s246_subclasses) >= 2:
            _s246_mixin_classes = _s246_class_syms  # trigger signal
    if _s246_mixin_classes:
        _s246_names = [s.name for s in _s246_mixin_classes[:2]]
        _s246_str = ", ".join(_s246_names)
        # Count subclasses across the graph using _subtypes index
        _s246_all_ids = {s.id for s in _s246_mixin_classes}
        _s246_n_subs = sum(
            1 for _cid in _s246_all_ids
            for _src in graph._subtypes.get(_cid, [])
            if _src.split("::")[0] != file_path
        )
        if _s246_n_subs >= 1:
            lines.append(
                f"mixin/base blast: {_s246_str} has {_s246_n_subs} subclass(es)"
                f" — changes cascade silently through all inheritors"
            )


def _blast_core_a_imports(
    graph: "Tempo",
    file_path: str,
    symbols: list,
    importers: list[str],
    lines: list[str],
) -> None:
    # Precompute outgoing import targets once for S138, S256, and S263.
    # Uses pre-built _out_imports index — O(1) lookup instead of O(N) edge scan.
    _a_out_imports = graph.outgoing_imports_of(file_path)

    # S195: Blast fan-out — blast target's symbols call into 5+ distinct external files.
    # High outgoing call fan-out = the file reaches widely; changes ripple in multiple directions.
    # Only shown when symbols in blast target call into 5+ distinct non-target files.
    _s195_callee_files: set[str] = set()
    for _sym195 in symbols:
        for _callee195 in graph.callees_of(_sym195.id):
            if _callee195.file_path != file_path and not _is_test_file(_callee195.file_path):
                _s195_callee_files.add(_callee195.file_path)
    if len(_s195_callee_files) >= 5:
        _fan_names = [fp.rsplit("/", 1)[-1] for fp in sorted(_s195_callee_files)[:3]]
        _fan_str = ", ".join(_fan_names)
        if len(_s195_callee_files) > 3:
            _fan_str += f" +{len(_s195_callee_files) - 3} more"
        lines.append(
            f"blast fan-out: calls into {len(_s195_callee_files)} external files"
            f" ({_fan_str}) — wide outgoing dependency, changes may cascade"
        )

    # S138: Aggregator file — blast target imports from many other modules.
    # Files that pull from 5+ distinct source modules are barrel/aggregator files:
    # changes to any upstream propagate here, AND any change here propagates to all importers.
    # Highest blast-amplification pattern. Only shown when 5+ distinct imports found.
    _s138_imports_from = sorted(
        t for t in _a_out_imports
        if t in graph.files
        and not _is_test_file(t)
        and t != file_path
    )
    if len(_s138_imports_from) >= 5:
        lines.append(
            f"aggregator file: imports from {len(_s138_imports_from)} modules"
            f" — barrel/hub; upstream changes flow through here"
        )

    # S152: Cross-language blast — blast radius crosses language boundaries.
    # When a file in one language is imported/used by files in different languages,
    # changes require understanding both ecosystems. Flag when 2+ distinct languages found.
    _s152_target_lang = file_path.rsplit(".", 1)[-1] if "." in file_path else ""
    _s152_lang_ext: dict[str, int] = {}
    for _fp152 in importers:
        _ext152 = _fp152.rsplit(".", 1)[-1] if "." in _fp152 else ""
        if _ext152 and _ext152 != _s152_target_lang:
            _s152_lang_ext[_ext152] = _s152_lang_ext.get(_ext152, 0) + 1
    if _s152_lang_ext:
        _s152_langs_str = ", ".join(f".{ext}({n})" for ext, n in sorted(_s152_lang_ext.items())[:3])
        lines.append(f"cross-language blast: importers span {len(_s152_lang_ext)+1} languages ({_s152_langs_str})")

    # S201: Isolated file — blast target has 0 external importers and 0 external callers.
    # A file with no incoming dependencies is safe to modify or delete without coordination.
    # Only shown when file has neither external importers nor symbols with external callers.
    _s201_importers = [
        i for i in graph.importers_of(file_path)
        if i in graph.files and i != file_path
    ]
    _s201_has_ext_callers = any(
        any(c.file_path != file_path for c in graph.callers_of(s.id))
        for s in symbols
    )
    if not _s201_importers and not _s201_has_ext_callers:
        lines.append(
            f"isolated file: no external importers or callers"
            f" — safe to modify or delete without coordination"
        )

    # S256: High fan-out blast — blast target imports from many other modules.
    # A file with wide dependencies is harder to refactor in isolation; changes
    # often require updates across all its upstream dependencies.
    _s256_import_count = len(set(_a_out_imports))
    if _s256_import_count >= 6:
        lines.append(
            f"high fan-out: imports from {_s256_import_count} modules"
            f" — wide dependency surface; refactoring this file requires many upstream checks"
        )

    # S263: Leaf module — blast target has no outgoing imports (fully self-contained).
    # Leaf modules are the easiest to extract, test, or replace in isolation.
    # Positive signal: shown when blast target has 3+ symbols but zero import edges out.
    if symbols:
        if not _a_out_imports and len(symbols) >= 3:
            lines.append(
                f"leaf module: no outgoing imports"
                f" — self-contained; safe to extract, mock, or replace in isolation"
            )


def _blast_core_a_filekind(
    graph: "Tempo",
    file_path: str,
    symbols: list,
    importers: list[str],
    lines: list[str],
) -> None:
    # S158: Init-heavy — blast target is __init__.py with many exported symbols.
    # __init__ files are import entry points; high symbol count = many dependents at risk.
    # Only shown when file is __init__.py and has >= 8 exported symbols.
    _s158_basename = file_path.rsplit("/", 1)[-1]
    if _s158_basename in ("__init__.py", "index.ts", "index.js", "mod.rs"):
        _s158_exported = [
            s for s in symbols
            if s.exported and s.kind.value in ("function", "method", "class", "interface")
        ]
        if len(_s158_exported) >= 8:
            lines.append(
                f"init-heavy: {len(_s158_exported)} exported symbols in {_s158_basename}"
                f" — package entry point, changes affect all importers"
            )

    # S189: Sibling files — other source files sharing the same directory as the blast target.
    # Co-located files are often tightly coupled and may need coordinated updates.
    # Only shown when 2+ sibling source files exist in the same directory.
    _s189_target_dir = file_path.rsplit("/", 1)[0] if "/" in file_path else "."
    _s189_siblings = [
        fp for fp in graph.files
        if fp != file_path and not _is_test_file(fp)
        and (fp.rsplit("/", 1)[0] if "/" in fp else ".") == _s189_target_dir
    ]
    if len(_s189_siblings) >= 2:
        _sib_names = [fp.rsplit("/", 1)[-1] for fp in _s189_siblings[:3]]
        _sib_str = ", ".join(_sib_names)
        if len(_s189_siblings) > 3:
            _sib_str += f" +{len(_s189_siblings) - 3} more"
        lines.append(
            f"sibling files: {len(_s189_siblings)} co-located files ({_sib_str})"
            f" — may require coordinated updates"
        )

    # S217: Entry point blast — the blast target is an application entry point.
    # Entry points (main.py, app.py, index.js, cli.py) are widely invoked; changing them
    # affects startup, CLI behavior, or the entire request path.
    # Only shown when blast file stem matches known entry point names.
    _s217_entry_stems = {
        "main", "app", "index", "server", "cli", "run", "manage", "wsgi", "asgi", "__main__"
    }
    _s217_stem = file_path.rsplit("/", 1)[-1].rsplit(".", 1)[0].lower()
    if _s217_stem in _s217_entry_stems:
        lines.append(
            f"entry point blast: {file_path.rsplit('/', 1)[-1]} is an application entry point"
            f" — changes affect startup / CLI / full request path"
        )

    # S224: Test file blast — the blast target is a test file.
    # Test files typically have few or no production importers; changes are lower risk.
    # Positive signal: flagged as safe to refactor/delete without coordinating production code.
    if _is_test_file(file_path):
        lines.append(
            f"test file blast: {file_path.rsplit('/', 1)[-1]} is a test file"
            f" — no production code depends on this; safe to modify independently"
        )

    # S231: Package init blast — blast target is an __init__.py file.
    # __init__.py re-exports symbols for the entire package; all package importers are affected.
    # Only shown when blast file is an __init__.py.
    if file_path.rsplit("/", 1)[-1] in ("__init__.py", "__init__.ts", "__init__.js"):
        lines.append(
            f"package init blast: {file_path} is a package init"
            f" — all importers of the package are affected by changes here"
        )

    # S237: Internal-only file — blast target exports no symbols.
    # Files with no exports are internal implementation details; changes stay within the module.
    # Positive signal: safe to refactor without breaking callers' public interface expectations.
    if symbols and not any(s.exported for s in symbols):
        lines.append(
            f"internal-only file: {file_path.rsplit('/', 1)[-1]} has no exported symbols"
            f" — changes don't affect public interface"
        )

    # S261: Platform-specific blast — blast target file name indicates it's platform-specific.
    # Platform-specific code needs testing on that exact platform (CI may not cover it).
    # Only shown when file name contains a platform indicator.
    _s254_platform_markers = (
        "_windows", "_win32", "_win64", "_linux", "_darwin", "_macos", "_osx",
        "_posix", "_unix", "_freebsd", "_android", "_ios", "_arm", "_x86",
    )
    _s254_base254 = file_path.rsplit("/", 1)[-1].rsplit(".", 1)[0].lower()
    _s254_platform = next(
        (m.lstrip("_") for m in _s254_platform_markers if _s254_base254.endswith(m)),
        None
    )
    if _s254_platform:
        lines.append(
            f"platform-specific: {file_path.rsplit('/', 1)[-1]} targets {_s254_platform}"
            f" — test on that platform; CI may not cover it"
        )

    # S290: No importers — blast target has exported symbols but nothing imports it.
    # A non-test file with exported symbols and zero importers may be dead code,
    # a new module not yet wired in, or an external entry point (tested separately).
    if symbols:
        _s290_importers = [
            f for f in graph.importers_of(file_path)
            if f in graph.files and f != file_path
        ]
        _s290_exported = [s for s in symbols if s.exported]
        if not _s290_importers and _s290_exported and not _is_test_file(file_path):
            lines.append(
                f"no importers: {len(_s290_exported)} exported symbol(s) but nothing imports this file"
                f" — may be dead code, an unwired module, or a standalone entry point"
            )

    # S296: Generated code blast — blast target's path suggests it is auto-generated.
    # Generated files should not be edited directly; changes must be made in the
    # generator or template, then re-generated.
    _s296_gen_indicators = (
        "_generated", ".generated.", "_pb2", "_pb2_grpc", ".pb.", "_gen.",
        "/generated/", "/gen/", "/__generated__/", "/_generated/",
    )
    _s296_gen_stems = {"generated", "gen", "auto_generated", "autogenerated"}
    _fp296_lower = file_path.lower().replace("\\", "/")
    _stem296 = file_path.rsplit("/", 1)[-1].rsplit(".", 1)[0].lower()
    _is_generated296 = (
        any(ind in _fp296_lower for ind in _s296_gen_indicators)
        or _stem296 in _s296_gen_stems
    )
    if _is_generated296:
        lines.append(
            f"generated file: {file_path.rsplit('/', 1)[-1]} appears to be auto-generated"
            f" — edit the generator/template, not this file directly"
        )


def _signals_blast_core_a(
    graph: "Tempo",
    file_path: str,
    fi,
    symbols: list,
    importers: list[str],
    external_callers: dict,
    lines: list[str]
) -> None:
    _blast_core_a_exposure(graph, file_path, symbols, importers, lines)
    _blast_core_a_callers(graph, file_path, symbols, importers, external_callers, lines)
    _blast_core_a_traversal(graph, file_path, symbols, importers, lines)
    _blast_core_a_coverage(graph, file_path, symbols, importers, external_callers, lines)
    _blast_core_a_chains(graph, file_path, symbols, lines)
    _blast_core_a_inheritance(graph, file_path, symbols, lines)
    _blast_core_a_imports(graph, file_path, symbols, importers, lines)
    _blast_core_a_filekind(graph, file_path, symbols, importers, lines)



def _blast_core_b_naming(
    file_path: str,
    importers: list[str],
    symbols: list,
    lines: list[str],
) -> None:
    # S311: Deprecated API blast — target file name or path contains deprecated/legacy/compat.
    _s311_dep_words = ("deprecated", "legacy", "compat", "obsolete", "old_", "_old", "v1_", "_v1")
    _fp311_lower = file_path.lower().replace("\\", "/")
    _is_deprecated311 = any(w in _fp311_lower for w in _s311_dep_words)
    if _is_deprecated311 and importers:
        lines.append(
            f"deprecated API: {file_path.rsplit('/', 1)[-1]} is marked deprecated"
            f" but still imported by {len(importers)} file(s)"
            f" — callers may not know it's deprecated; add migration notes"
        )
    # S317: Core utility blast — target is in utils/helpers/common AND imported by 5+ files.
    _s317_util_dirs = ("utils", "helpers", "common", "shared", "lib", "core", "base")
    _s317_is_util = any(
        part in _s317_util_dirs
        for part in file_path.lower().replace("\\", "/").split("/")[:-1]
    ) or file_path.rsplit("/", 1)[-1].rsplit(".", 1)[0].lower() in _s317_util_dirs
    if _s317_is_util and len(importers) >= 5:
        lines.append(
            f"core utility blast: {file_path.rsplit('/', 1)[-1]} is a shared utility"
            f" imported by {len(importers)} files — utility changes ripple everywhere; test thoroughly"
        )
    # S323: Shared config blast — target is a settings/config file imported by 5+ files.
    _s323_cfg_names = {"settings", "config", "configuration", "constants", "env",
                       "defaults", "params", "options", "app_config"}
    _s323_stem = file_path.rsplit("/", 1)[-1].rsplit(".", 1)[0].lower()
    _is_config323 = (
        _s323_stem in _s323_cfg_names
        or _s323_stem.startswith("settings_")
        or _s323_stem.endswith("_config")
        or _s323_stem.endswith("_settings")
    )
    if _is_config323 and len(importers) >= 5:
        lines.append(
            f"config blast: {file_path.rsplit('/', 1)[-1]} is a config/settings file"
            f" imported by {len(importers)} files — default value changes affect all consumers silently"
        )
    # S325: Dual-purpose module — blast target contains both library symbols AND an entry point.
    _s325_has_lib = any(
        s.kind.value in ("function", "class") and s.exported for s in symbols
    )
    _s325_has_main = any(
        s.name in ("main", "__main__") or "if __name__" in (s.signature or "")
        for s in symbols
    )
    if _s325_has_lib and _s325_has_main and importers:
        lines.append(
            f"dual-purpose module: {file_path.rsplit('/', 1)[-1]} mixes library and script code"
            f" — changes to either side affect both library callers and script behavior"
        )


def _blast_core_b_schema(
    file_path: str,
    importers: list[str],
    symbols: list,
    lines: list[str],
) -> None:
    # S331: Schema blast — target defines ORM/schema models imported widely.
    _s331_schema_words = ("schema", "model", "entity", "orm", "record", "table", "migration")
    _fp331 = file_path.lower().replace("\\", "/")
    _is_schema331 = any(w in _fp331 for w in _s331_schema_words)
    if not _is_schema331:
        _stem331 = file_path.rsplit("/", 1)[-1].rsplit(".", 1)[0].lower()
        _is_schema331 = any(w in _stem331 for w in _s331_schema_words)
    if _is_schema331 and len(importers) >= 4:
        lines.append(
            f"schema blast: {file_path.rsplit('/', 1)[-1]} appears to be a schema/model file"
            f" imported by {len(importers)} files"
            f" — field/type changes propagate to serializers, validators, and API layers"
        )
    # S337: Version file blast — target defines __version__ and is imported by multiple files.
    _s337_has_version = any(
        s.name in ("__version__", "VERSION", "version", "APP_VERSION", "__version_info__")
        for s in symbols
    )
    if _s337_has_version and len(importers) >= 3:
        lines.append(
            f"version file blast: {file_path.rsplit('/', 1)[-1]} exports version info"
            f" imported by {len(importers)} files"
            f" — version string change may break runtime compatibility checks"
        )
    # S343: Conftest blast — target is a conftest.py or shared test fixture file.
    _fp343 = file_path.rsplit("/", 1)[-1].lower()
    _is_conftest343 = _fp343 in ("conftest.py", "fixtures.py", "test_helpers.py", "test_utils.py")
    if _is_conftest343 and importers:
        lines.append(
            f"conftest blast: {file_path.rsplit('/', 1)[-1]} is a shared test fixture"
            f" — changes here cascade through all dependent tests; run full test suite"
        )
    # S377: Protocol/interface blast — blast target defines abstract interfaces or Protocol classes.
    _s377_abstract_names = (
        "protocol", "interface", "abstract", "abc", "base_class", "base_model",
        "iservice", "irepository", "ihandler",
    )
    _s377_fp_lower = file_path.lower()
    _s377_is_protocol = (
        any(p in _s377_fp_lower for p in _s377_abstract_names)
        or any(
            s.name.lower().startswith(p)
            for s in symbols
            for p in ("Base", "Abstract", "Protocol", "Interface", "I")
            if len(s.name) > 2
        )
    )
    if _s377_is_protocol and importers:
        lines.append(
            f"protocol blast: {file_path.rsplit('/', 1)[-1]} defines abstract interface(s)"
            f" — every implementor is affected; check all concrete subclasses for breaking changes"
        )


def _blast_core_b_utility(
    graph: "Tempo",
    file_path: str,
    importers: list[str],
    symbols: list,
    lines: list[str],
) -> None:
    # S371: Utility belt blast — blast target has 15+ exported symbols each imported by different files.
    if len(symbols) >= 15 and len(importers) >= 5:
        _s371_sym_ids = {s.id for s in symbols}
        _s371_importer_syms: dict[str, set[str]] = {}
        for _sym_id371 in _s371_sym_ids:
            for _caller371 in graph.callers_of(_sym_id371):
                if _caller371.file_path != file_path and not _is_test_file(_caller371.file_path):
                    _s371_importer_syms.setdefault(_caller371.file_path, set()).add(_sym_id371)
        if len(_s371_importer_syms) >= 4:
            lines.append(
                f"utility belt: {len(symbols)} symbols in {file_path.rsplit('/', 1)[-1]}"
                f" used across {len(_s371_importer_syms)} files"
                f" — undifferentiated helper bag; extract domain-specific modules to reduce blast radius"
            )
    # S365: Middleware blast — blast target is a middleware/interceptor/decorator file.
    _fp365 = file_path.lower()
    _mw_patterns365 = (
        "middleware", "interceptor", "decorator", "wrapper", "filter",
        "hook", "plugin", "mixin",
    )
    _is_middleware365 = any(p in _fp365 for p in _mw_patterns365) and not _is_test_file(file_path)
    if _is_middleware365 and importers:
        lines.append(
            f"middleware blast: {file_path.rsplit('/', 1)[-1]} is a middleware/interceptor"
            f" used by {len(importers)} files"
            f" — wraps all code paths; changes affect every caller simultaneously"
        )
    # S359: Entrypoint blast — blast target is the application's main entry point.
    _fp359 = file_path.rsplit("/", 1)[-1].lower()
    _is_entry359 = _fp359 in (
        "__main__.py", "main.py", "index.js", "index.ts", "app.py", "server.py",
        "manage.py", "wsgi.py", "asgi.py", "entrypoint.py",
    )
    if _is_entry359 and importers:
        lines.append(
            f"entrypoint blast: {file_path.rsplit('/', 1)[-1]} is the application entrypoint"
            f" — startup/init order changes are not unit-testable; test in integration or staging"
        )
    # S353: Constants blast — blast target is a purely constants/enums file.
    _s353_const_kinds = {"variable", "constant"}
    _s353_fn_kinds = {"function", "method", "class"}
    _s353_all_const = symbols and all(
        s.kind.value in _s353_const_kinds or s.name.isupper()
        for s in symbols
    )
    _s353_no_fns = not any(s.kind.value in _s353_fn_kinds for s in symbols)
    if _s353_all_const and _s353_no_fns and len(importers) >= 3:
        lines.append(
            f"constants blast: {file_path.rsplit('/', 1)[-1]} is a constants/enums file"
            f" imported by {len(importers)} files"
            f" — value/rename changes may silently break consumers that hardcode expected values"
        )


def _blast_core_b_types(
    graph: "Tempo",
    file_path: str,
    importers: list[str],
    symbols: list,
    b_out_imports: list,
    lines: list[str],
) -> None:
    # S395: Type definition blast — blast target defines TS interfaces/types/enums.
    _fp395 = file_path.lower()
    _is_type_file395 = (
        (_fp395.endswith(".d.ts") or "types" in _fp395 or "interfaces" in _fp395
         or "enums" in _fp395 or "typings" in _fp395)
        and not _is_test_file(file_path)
    )
    if _is_type_file395 and len(importers) >= 3:
        lines.append(
            f"type definition blast: {file_path.rsplit('/', 1)[-1]} defines shared TypeScript types"
            f" imported by {len(importers)} files"
            f" — type changes cascade through compilation; check all consumers for type errors"
        )
    # S389: Database model blast — blast target is a DB model/schema file.
    _fp389 = file_path.rsplit("/", 1)[-1].lower()
    _db_patterns389 = (
        "model", "schema", "entity", "table", "migration", "orm",
        "dao", "repository", "activerecord",
    )
    _is_db389 = (
        any(p in _fp389 for p in _db_patterns389)
        and not _is_test_file(file_path)
        and not any(
            skip in _fp389 for skip in ("view", "controller", "route", "api")
        )
    )
    if _is_db389 and importers:
        lines.append(
            f"DB model blast: {file_path.rsplit('/', 1)[-1]} defines a data model"
            f" imported by {len(importers)} files"
            f" — schema changes require database migrations; review all ORM queries in consumers"
        )
    # S383: Test fixture blast — blast target is a shared test fixture/factory file.
    _fp383 = file_path.rsplit("/", 1)[-1].lower()
    _is_fixture383 = _fp383 in ("conftest.py", "fixtures.py", "factories.py", "test_helpers.py", "test_utils.py")
    _test_importers383 = [fp for fp in graph.importers_of(file_path) if _is_test_file(fp)]
    if _is_fixture383 and len(_test_importers383) >= 3:
        lines.append(
            f"test fixture blast: {file_path.rsplit('/', 1)[-1]} is a shared test fixture"
            f" imported by {len(_test_importers383)} test files"
            f" — fixture changes break test isolation; run full test suite after any modification"
        )
    # S401: Shared secrets blast — blast target file name or symbols suggest it holds credentials.
    _secret_words401 = (
        "secret", "credential", "api_key", "apikey", "token", "password",
        "passwd", "auth_key", "private_key", "access_key",
    )
    _fp401_lower = file_path.lower().replace("-", "_")
    _file_is_secret401 = any(w in _fp401_lower for w in _secret_words401)
    _sym_has_secret401 = any(
        any(w in s.name.lower() for w in _secret_words401)
        for s in symbols
    )
    _total_importers401 = len(importers)
    if (_file_is_secret401 or _sym_has_secret401) and _total_importers401 >= 3:
        lines.append(
            f"secrets blast: {file_path.rsplit('/', 1)[-1]} contains credentials/tokens"
            f" and is imported by {_total_importers401} file(s)"
            f" — wide credential sharing increases leak surface; scope access via DI or env-only"
        )
    # S407: Init-file blast — blast target is an __init__.py that re-exports many symbols.
    _fp407 = file_path.rsplit("/", 1)[-1].lower()
    _is_init407 = _fp407 in ("__init__.py", "index.js", "index.ts", "index.tsx")
    _init_dir407 = file_path.rsplit("/", 1)[0] if "/" in file_path else ""
    _init_package_size407 = sum(
        1 for fp in graph.files
        if (fp.rsplit("/", 1)[0] if "/" in fp else "") == _init_dir407
        and fp != file_path
    )
    if _is_init407 and len(b_out_imports) >= 5 and _init_package_size407 >= 3:
        lines.append(
            f"init-file blast: {_fp407} re-exports from {len(b_out_imports)} module(s)"
            f" in a package of {_init_package_size407} file(s)"
            f" — renaming any re-export silently breaks all downstream importers"
        )


def _blast_core_b_symbols(
    graph: "Tempo",
    file_path: str,
    importers: list[str],
    symbols: list,
    b_out_imports: list,
    lines: list[str],
) -> None:
    # S413: Symbol-dense blast — blast target file has 30+ symbols (classes, functions, constants).
    if len(symbols) >= 30:
        _kinds413: dict[str, int] = {}
        for s in symbols:
            _kinds413[s.kind.value] = _kinds413.get(s.kind.value, 0) + 1
        _top_kind413 = max(_kinds413, key=lambda k: _kinds413[k])
        lines.append(
            f"symbol-dense: {file_path.rsplit('/', 1)[-1]} defines {len(symbols)} symbols"
            f" ({_kinds413[_top_kind413]} {_top_kind413}s)"
            f" — each symbol is a blast propagation point; refactor to split by concern"
        )
    # S419: Type stub blast — blast target is a type stub file (.pyi).
    if file_path.lower().endswith(".pyi"):
        lines.append(
            f"type stub blast: {file_path.rsplit('/', 1)[-1]} is a type stub"
            f" imported/used by {len(importers)} file(s)"
            f" — stub changes break type checks without runtime errors; update callers together"
        )
    # S425: Constants-file blast — blast target is a file containing only constants.
    _s425_is_const_file = (
        len(symbols) >= 3
        and all(s.kind.value in ("variable", "constant") for s in symbols)
    )
    if _s425_is_const_file and len(importers) >= 3:
        lines.append(
            f"constants-file blast: {file_path.rsplit('/', 1)[-1]} defines"
            f" {len(symbols)} constant(s) imported by {len(importers)} file(s)"
            f" — constants files are silently high-impact; all importers pick up changes immediately"
        )
    # S431: Event emitter blast — blast target file contains event emit/dispatch functions.
    _s431_event_patterns = (
        "emit_", "dispatch_", "publish_", "fire_event_",
        "trigger_", "broadcast_", "send_event_",
    )
    _s431_event_syms = [
        s for s in symbols
        if s.kind.value in ("function", "method")
        and any(s.name.lower().startswith(p) for p in _s431_event_patterns)
    ]
    if len(_s431_event_syms) >= 2:
        _ev_names431 = ", ".join(s.name for s in _s431_event_syms[:3])
        lines.append(
            f"event emitter blast: {file_path.rsplit('/', 1)[-1]} has {len(_s431_event_syms)}"
            f" event dispatch fn(s) ({_ev_names431})"
            f" — subscribers are invisible in dependency trace; grep for event names to find all consumers"
        )
    # S437: Circular import risk — blast target has a mutual import relationship.
    _s437_outbound_files = {t for t in b_out_imports if t != file_path}
    _s437_circular = [fp for fp in _s437_outbound_files if file_path in graph.importers_of(fp)]
    if _s437_circular:
        _circ_name437 = _s437_circular[0].rsplit("/", 1)[-1]
        lines.append(
            f"circular import risk: {file_path.rsplit('/', 1)[-1]} ↔ {_circ_name437}"
            f" have mutual imports"
            f" — any change in either file can trigger import errors; refactor to break the cycle"
        )


def _blast_core_b_api(
    graph: "Tempo",
    file_path: str,
    importers: list[str],
    external_callers: dict,
    render_targets: set,
    symbols: list,
    lines: list[str],
) -> None:
    if not importers and not external_callers and not render_targets:
        lines.append("No external dependencies found — safe to modify in isolation.")
    # S443: Public API file — blast target exports functions/classes used across 5+ files.
    _s443_exported = [s for s in symbols if s.exported]
    _s443_consumer_files: set[str] = set()
    for _sym443 in _s443_exported:
        for _caller443 in graph.callers_of(_sym443.id):
            if _caller443.file_path != file_path:
                _s443_consumer_files.add(_caller443.file_path)
    if len(_s443_consumer_files) >= 5:
        lines.append(
            f"public API file: {len(_s443_exported)} exported symbol(s)"
            f" consumed by {len(_s443_consumer_files)} files"
            f" — any signature change is a breaking change; version or deprecate before removing"
        )
    # S449: Multi-package blast — blast target is imported across 3+ distinct package directories.
    _s449_importer_dirs: set[str] = set()
    for _imp449 in importers:
        _dir449 = _imp449.rsplit("/", 1)[0] if "/" in _imp449 else ""
        _s449_importer_dirs.add(_dir449)
    if len(_s449_importer_dirs) >= 3:
        lines.append(
            f"multi-package blast: imported from {len(_s449_importer_dirs)} distinct directories"
            f" — treat as shared library; incompatible changes require coordinated updates across all packages"
        )
    # S453: Middleware blast — blast target is a middleware or interceptor component.
    _s453_mw_keywords = ("middleware", "interceptor", "filter", "pipeline", "decorator", "hook")
    _s453_mw_name = file_path.lower().replace("\\", "/")
    _s453_is_mw = any(kw in _s453_mw_name for kw in _s453_mw_keywords)
    if _s453_is_mw and importers:
        lines.append(
            f"middleware blast: {file_path.rsplit('/', 1)[-1]} is a middleware/interceptor"
            f" used by {len(importers)} file(s)"
            f" — bugs or performance regressions affect every request through this pipeline"
        )
    # S459: Core utility blast — blast target has 20+ exported functions used across 5+ files.
    _s459_exported_fns = [
        s for s in symbols
        if s.kind.value in ("function", "method")
        and s.exported
    ]
    if len(_s459_exported_fns) >= 20 and len(importers) >= 5:
        lines.append(
            f"utility hub blast: {file_path.rsplit('/', 1)[-1]} exports {len(_s459_exported_fns)}"
            f" functions used by {len(importers)} files"
            f" — treat as a shared library; any breaking change needs broad coordination"
        )


def _blast_core_b_edges(
    graph: "Tempo",
    file_path: str,
    importers: list[str],
    symbols: list,
    b_out_imports: list,
    lines: list[str],
) -> None:
    # S467: Test-only importer — blast target is only imported from test files.
    _s467_all_importers = graph.importers_of(file_path)
    _s467_non_test = [fp for fp in _s467_all_importers if not _is_test_file(fp)]
    _s467_test = [fp for fp in _s467_all_importers if _is_test_file(fp)]
    if _s467_test and not _s467_non_test and not _is_test_file(file_path):
        lines.append(
            f"test-only importer: {file_path.rsplit('/', 1)[-1]} is only imported from test files"
            f" ({len(_s467_test)} test file(s))"
            f" — may be an unused helper; verify before keeping or deleting"
        )
    # S473: Constants-only blast — blast target contains only constant/variable definitions.
    if symbols:
        _s473_non_const = [
            s for s in symbols
            if s.kind.value not in ("variable", "constant", "property")
        ]
        if not _s473_non_const and len(symbols) >= 5 and importers:
            lines.append(
                f"constants-only blast: {file_path.rsplit('/', 1)[-1]} contains only {len(symbols)} constant/variable definitions"
                f" imported by {len(importers)} file(s)"
                f" — renaming or removing any constant silently breaks all consumers"
            )
    # S479: Bridge file blast — blast target imports from one component and is imported by another.
    _s479_outbound_dirs: set[str] = set()
    for _t479 in b_out_imports:
        _dir479 = _t479.rsplit("/", 1)[0] if "/" in _t479 else ""
        if _dir479 and _dir479 != (file_path.rsplit("/", 1)[0] if "/" in file_path else ""):
            _s479_outbound_dirs.add(_dir479)
    _s479_inbound_dirs: set[str] = set()
    for _imp479 in importers:
        _dir479 = _imp479.rsplit("/", 1)[0] if "/" in _imp479 else ""
        if _dir479 and _dir479 != (file_path.rsplit("/", 1)[0] if "/" in file_path else ""):
            _s479_inbound_dirs.add(_dir479)
    if _s479_outbound_dirs and _s479_inbound_dirs and not _s479_outbound_dirs & _s479_inbound_dirs:
        lines.append(
            f"bridge file: {file_path.rsplit('/', 1)[-1]} connects"
            f" {len(_s479_outbound_dirs)} outbound module(s) ↔ {len(_s479_inbound_dirs)} inbound module(s)"
            f" — removing it requires coordinated changes on both sides of the boundary"
        )
    # S484: Data model blast — blast target defines dataclasses, NamedTuples, or TypedDicts.
    _s484_model_markers = ("dataclass", "NamedTuple", "TypedDict", "dataclasses")
    _s484_file_imports = next(
        (fi.imports for fp, fi in graph.files.items() if fp == file_path), []
    ) or []
    _s484_is_model = any(
        any(m in imp for m in _s484_model_markers) for imp in _s484_file_imports
    )
    if _s484_is_model and importers:
        lines.append(
            f"data model blast: {file_path.rsplit('/', 1)[-1]} defines typed data models"
            f" imported by {len(importers)} file(s)"
            f" — field renames or type changes silently break all consumers; update together"
        )



def _blast_core_b_meta(
    file_path: str,
    importers: list[str],
    symbols: list,
    b_out_imports: list,
    lines: list[str],
) -> None:
    # S490: High-complexity blast target — the blast file contains a function with cx ≥ 15.
    _s490_complex = [
        s for s in symbols
        if s.kind.value in ("function", "method")
        and s.complexity is not None
        and s.complexity >= 15
    ]
    if _s490_complex:
        _top490 = max(_s490_complex, key=lambda s: s.complexity or 0)
        lines.append(
            f"high complexity: {_top490.name} has cyclomatic complexity {_top490.complexity}"
            f" — complex functions carry higher regression risk; add tests before modifying"
        )
    # S496: Package init blast — blast target is a package __init__.py.
    _basename496 = file_path.rsplit("/", 1)[-1]
    if _basename496 == "__init__.py" and importers:
        lines.append(
            f"package init blast: {file_path} is a package interface"
            f" used by {len(importers)} file(s)"
            f" — changes to __init__.py re-exports propagate to all consumers; review every import"
        )
    # S504: Leaf file blast — blast target imports from others but nothing imports it.
    _s504_outbound = {t for t in b_out_imports if t != file_path}
    if _s504_outbound and not importers:
        lines.append(
            f"leaf file blast: {file_path.rsplit('/', 1)[-1]} imports {len(_s504_outbound)} file(s) but has no importers"
            f" — blast radius is fully contained; changes are safe from propagation but test locally"
        )


def _signals_blast_core_b(
    graph: "Tempo",
    file_path: str,
    fi,
    symbols: list,
    importers: list[str],
    external_callers: dict,
    render_targets: set,
    lines: list[str]
) -> None:
    # Outgoing import targets — O(1) index lookup, no edge scan.
    _b_out_imports = graph.outgoing_imports_of(file_path)
    _blast_core_b_naming(file_path, importers, symbols, lines)
    _blast_core_b_schema(file_path, importers, symbols, lines)
    _blast_core_b_utility(graph, file_path, importers, symbols, lines)
    _blast_core_b_types(graph, file_path, importers, symbols, _b_out_imports, lines)
    _blast_core_b_symbols(graph, file_path, importers, symbols, _b_out_imports, lines)
    _blast_core_b_api(graph, file_path, importers, external_callers, render_targets, symbols, lines)
    _blast_core_b_edges(graph, file_path, importers, symbols, _b_out_imports, lines)
    _blast_core_b_meta(file_path, importers, symbols, _b_out_imports, lines)


def _blast_core_c_importers(
    graph: "Tempo",
    file_path: str,
    importers: list[str],
    lines: list[str]
) -> None:
    _fp = file_path.replace("\\", "/")
    # S511: Single-consumer blast
    if len(importers) == 1:
        _single511 = next(iter(importers))
        lines.append(
            f"single consumer: {file_path.rsplit('/', 1)[-1]} is only imported by {_single511.rsplit('/', 1)[-1]}"
            f" — tightly coupled to one consumer; safe to change in sync, but consider if the coupling is intentional"
        )
    # S521: Cross-package blast (importers span 3+ distinct top-level packages)
    if importers:
        _s521_src_importers = [imp for imp in importers if not _is_test_file(imp)]
        _s521_top_dirs = {imp.replace("\\", "/").split("/")[0] for imp in _s521_src_importers}
        if len(_s521_top_dirs) >= 3:
            lines.append(
                f"cross-package blast: {file_path.rsplit('/', 1)[-1]} is imported from"
                f" {len(_s521_top_dirs)} distinct packages ({', '.join(sorted(_s521_top_dirs)[:3])})"
                f" — changes require coordinated updates across ownership boundaries"
            )
    # S560: Test-only blast
    _importer_files560 = graph.importers_of(file_path)
    if _importer_files560 and all(_is_test_file(fp) for fp in _importer_files560):
        lines.append(
            f"test-only blast: {file_path.rsplit('/', 1)[-1]} is only imported by test files"
            f" — production code never uses this; verify it's not dead production code"
        )
    # S595: Low importer count
    _non_test_importers595 = [fp for fp in importers if not _is_test_file(fp)]
    if len(_non_test_importers595) <= 1 and not (_fp.endswith("__init__.py") or _fp == "__init__.py"):
        _msg595 = "no non-test importers" if not _non_test_importers595 else f"1 non-test importer ({_non_test_importers595[0].rsplit('/', 1)[-1]})"
        lines.append(
            f"low blast radius: {file_path.rsplit('/', 1)[-1]} has {_msg595}"
            f" — changes are locally contained; verify this file isn't an unreferenced orphan"
        )
    # S620: Cross-package blast (consumers from 3+ top-level packages)
    _importer_roots620 = {
        fp.replace("\\", "/").split("/")[0]
        for fp in importers
        if "/" in fp.replace("\\", "/")
        and not _is_test_file(fp)
    }
    if len(_importer_roots620) >= 3:
        _root_list620 = ", ".join(sorted(_importer_roots620)[:4])
        lines.append(
            f"cross-package blast: {file_path.rsplit('/', 1)[-1]} is used across"
            f" {len(_importer_roots620)} top-level packages ({_root_list620})"
            f" — breaking change here requires coordinated updates in multiple packages"
        )
    # S668: Single importer
    _importers668 = graph.importers_of(_fp)
    _ext_importers668 = [f for f in _importers668 if f != _fp]
    if len(_ext_importers668) == 1:
        lines.append(
            f"single importer: {_fp.rsplit('/', 1)[-1]} is only imported by"
            f" {_ext_importers668[0].rsplit('/', 1)[-1]}"
            f" — consider inlining or merging to reduce file count"
        )


def _blast_core_c_module_role(
    file_path: str,
    importers: list[str],
    lines: list[str]
) -> None:
    _fp = file_path.replace("\\", "/")
    # S515: Config file blast
    _s515_config_markers = ("config", "settings", "constants", "conf", "env")
    if any(m in file_path.lower() for m in _s515_config_markers):
        lines.append(
            f"config file blast: {file_path.rsplit('/', 1)[-1]} is a config/settings file"
            f" — runtime values propagate everywhere; verify all consumers handle changed defaults"
        )
    # S548: Module init blast
    _fp548 = file_path.replace("\\", "/")
    if _fp548.endswith("__init__.py") or _fp548 == "__init__.py":
        lines.append(
            f"module init: {file_path} is a package __init__ — changes cascade to all consumers of this package"
            f"; re-exports in __init__ silently affect downstream importers"
        )
    # S554: Entry point blast
    _basename554 = _fp.rsplit("/", 1)[-1].lower()
    _entry_names554 = frozenset(("main.py", "app.py", "server.py", "cli.py", "run.py", "wsgi.py", "asgi.py"))
    if _basename554 in _entry_names554:
        lines.append(
            f"entry point: {file_path} is an application entry point"
            f" — bugs here abort startup; validate initialization order carefully"
        )
    # S566: Utility module blast (utils/helpers path with 5+ importers)
    _s566_fp_lower = file_path.lower().replace("\\", "/")
    _s566_util_markers = ("utils", "helpers", "util", "helper", "common", "shared", "misc")
    if any(m in _s566_fp_lower for m in _s566_util_markers) and len(importers) >= 5:
        lines.append(
            f"utility module blast: {file_path.rsplit('/', 1)[-1]} is a utility file with {len(importers)} importers"
            f" — seemingly low-level but high impact; utility changes break many consumers at once"
        )
    # S589: Init-file blast
    if _fp.endswith("__init__.py") or _fp == "__init__.py":
        lines.append(
            f"init file blast: {file_path.rsplit('/', 1)[-1]} is a package __init__"
            f" — changes affect all consumers of this package; star-import contracts may break"
        )
    # S626: Utility file blast (canonical utils.py/helpers.py filename match)
    _util_names626 = ("utils.py", "helpers.py", "util.py", "helper.py", "common.py", "misc.py", "shared.py")
    _fp_base626 = _fp.rsplit("/", 1)[-1].lower()
    if _fp_base626 in _util_names626:
        _importer_count626 = len([fp for fp in importers if not _is_test_file(fp)])
        lines.append(
            f"utility file blast: {_fp.rsplit('/', 1)[-1]} is a shared utility file"
            f" with {_importer_count626} non-test importer(s)"
            f" — utility modules accumulate mixed concerns; consider splitting by domain"
        )
    # S674: Entry point blast (extended list including __main__.py, entrypoint.py)
    _entry_names674 = {
        "main.py", "app.py", "server.py", "cli.py", "__main__.py",
        "entrypoint.py", "entry.py", "wsgi.py", "asgi.py", "run.py",
    }
    _blast_basename674 = _fp.rsplit("/", 1)[-1]
    if _blast_basename674 in _entry_names674:
        lines.append(
            f"entry point blast: {_blast_basename674} is a known entry point"
            f" — changes here affect system startup; verify initialization order and side effects"
        )


def _blast_core_c_structure(
    graph: "Tempo",
    file_path: str,
    fi,
    lines: list[str]
) -> None:
    _fp = file_path.replace("\\", "/")
    # S527: Wide export surface
    if fi:
        _s527_exported = [
            sid for sid in fi.symbols
            if sid in graph.symbols and graph.symbols[sid].exported
        ]
        if len(_s527_exported) >= 20:
            lines.append(
                f"wide export surface: {file_path.rsplit('/', 1)[-1]} exports {len(_s527_exported)} symbols"
                f" — large public API; use blast --query <symbol> to target specific symbol blast radius"
            )
    # S572: Large file blast (300+ lines)
    if file_path in graph.files:
        _fi572 = graph.files[file_path]
        if _fi572.line_count >= 300:
            lines.append(
                f"large file blast: {file_path.rsplit('/', 1)[-1]} has {_fi572.line_count} lines"
                f" — high-density change surface; changes compete for reviewer attention and test coverage"
            )
    # S578: Shared module blast
    _shared_markers578 = ("/shared/", "/common/", "/core/", "/lib/", "/base/", "/foundation/")
    if any(m in f"/{_fp}/" for m in _shared_markers578):
        lines.append(
            f"shared module blast: {file_path.rsplit('/', 1)[-1]} is in a shared infrastructure directory"
            f" — changes here may break consumers not visible in the local import graph"
        )
    # S614: Deep path blast (4+ directories deep)
    _depth614 = len(_fp.split("/"))
    if _depth614 >= 4:
        lines.append(
            f"deep path blast: {file_path} is {_depth614} directories deep"
            f" — deeply nested files are often under-tested and overlooked in reviews"
        )
    # S662: Large blast target (300+ lines, slightly different message from S572)
    _fi662 = graph.files.get(_fp)
    if _fi662 and _fi662.line_count > 300:
        lines.append(
            f"large blast target: {_fp.rsplit('/', 1)[-1]} is {_fi662.line_count} lines"
            f" — large file has high coupling density; careful scoping of your change is needed"
        )


def _blast_core_c_cycles(
    graph: "Tempo",
    file_path: str,
    b_out_imports: list,
    lines: list[str]
) -> None:
    _fp = file_path.replace("\\", "/")
    # S533: Type stub paired
    if graph.root and file_path.endswith(".py"):
        from pathlib import Path as _Path533  # noqa: PLC0415
        _stub533 = _Path533(graph.root) / file_path.replace(".py", ".pyi")
        if _stub533.exists():
            lines.append(
                f"type stub paired: {file_path.rsplit('/', 1)[-1]} has a .pyi stub"
                f" — sync the stub after any signature change or type checking will fail"
            )
    # S539: Circular import blast
    _s539_fp_norm = _fp
    _s539_outbound = {
        t.replace("\\", "/") for t in b_out_imports
        if t.replace("\\", "/") != _s539_fp_norm
    }
    _s539_reverse_importers = {fp.replace("\\", "/") for fp in graph.importers_of(file_path)}
    _s539_cycle_partners = [dep for dep in _s539_outbound if dep in _s539_reverse_importers]
    if _s539_cycle_partners:
        _cycle_name539 = _s539_cycle_partners[0].rsplit("/", 1)[-1]
        lines.append(
            f"circular import blast: {file_path.rsplit('/', 1)[-1]} is in a circular import with {_cycle_name539}"
            f" — changes affect init order; test module-level attribute access after any modification"
        )
    # S650: Mutual import
    _import_targets650 = set(b_out_imports)
    _importers650 = graph.importers_of(file_path)
    _mutual650 = [
        fp for fp in _importers650
        if not _is_test_file(fp)
        and fp in _import_targets650
    ]
    if _mutual650:
        _mutual_name650 = _mutual650[0].rsplit("/", 1)[-1]
        lines.append(
            f"mutual import: {_fp.rsplit('/', 1)[-1]} and {_mutual_name650} import each other"
            f" — circular file dependency; can cause ImportError in Python; break the cycle"
        )


def _blast_core_c_symbols(
    graph: "Tempo",
    file_path: str,
    importers: list[str],
    lines: list[str]
) -> None:
    _fp = file_path.replace("\\", "/")
    # S583: Many callers per symbol
    _s583_syms = graph.symbols_in_file(_fp)
    if _s583_syms:
        _max_callers583 = max(len(graph.callers_of(s.id)) for s in _s583_syms)
        if _max_callers583 >= 10:
            _hot_sym583 = max(_s583_syms, key=lambda s: len(graph.callers_of(s.id)))
            lines.append(
                f"high-caller symbol: {_hot_sym583.name} has {_max_callers583} callers"
                f" — de-facto stable API; signature changes require updating many call sites"
            )
    # S638: Thin wrapper module
    _syms638 = [
        s for s in graph.symbols_in_file(_fp)
        if not _is_test_file(s.file_path) and s.parent_id is None
    ]
    _non_test_importers638 = [fp for fp in importers if not _is_test_file(fp)]
    if len(_syms638) == 1 and len(_non_test_importers638) >= 3:
        lines.append(
            f"thin wrapper: {_fp.rsplit('/', 1)[-1]} has 1 symbol and {len(_non_test_importers638)} importers"
            f" — single-purpose wrapper; consider merging into the most frequent caller"
        )
    # S644: Pure class module
    _exported_syms644 = [
        s for s in graph.symbols_in_file(_fp)
        if s.exported and s.parent_id is None and not _is_test_file(s.file_path)
    ]
    if len(_exported_syms644) >= 2:
        _all_classes644 = all(s.kind.value == "class" for s in _exported_syms644)
        if _all_classes644:
            lines.append(
                f"pure class module: all {len(_exported_syms644)} exported symbols in"
                f" {_fp.rsplit('/', 1)[-1]} are classes"
                f" — constructor changes break all callers; consider making init params keyword-only"
            )
    # S656: Constants-only module
    _all_syms656 = [
        s for s in graph.symbols_in_file(_fp)
        if s.exported and s.parent_id is None and not _is_test_file(s.file_path)
    ]
    if len(_all_syms656) >= 2:
        _all_consts656 = all(s.kind.value in ("constant", "variable") for s in _all_syms656)
        if _all_consts656:
            _importer_count656 = len([fp for fp in importers if not _is_test_file(fp)])
            lines.append(
                f"constants-only module: {_fp.rsplit('/', 1)[-1]} exports only constants"
                f" ({len(_all_syms656)} values, {_importer_count656} importer(s))"
                f" — config changes affect all importers silently; no API signature to grep"
            )


def _blast_core_c_patterns(
    graph: "Tempo",
    file_path: str,
    importers: list[str],
    b_out_imports: list,
    lines: list[str]
) -> None:
    _fp = file_path.replace("\\", "/")
    # S602: No test coverage
    _stem602 = _fp.rsplit("/", 1)[-1].replace(".py", "").replace(".js", "").replace(".ts", "")
    _test_fps602 = [
        fp for fp in graph.files
        if _is_test_file(fp) and _stem602 in fp.replace("\\", "/").rsplit("/", 1)[-1]
    ]
    if not _test_fps602 and not _fp.endswith("__init__.py"):
        lines.append(
            f"no test coverage: no test file found for {file_path.rsplit('/', 1)[-1]}"
            f" — changes here cannot be regression-tested; add tests before modifying"
        )
    # S608: High-churn name pattern
    _stem608 = _fp.rsplit("/", 1)[-1].lower()
    _churn_markers608 = ("handler", "router", "route", "controller", "middleware", "dispatch",
                         "gateway", "proxy", "adapter", "bridge")
    if any(m in _stem608 for m in _churn_markers608):
        lines.append(
            f"high-churn pattern: {file_path.rsplit('/', 1)[-1]} matches a high-churn naming pattern"
            f" — integration-boundary files change frequently; expect blast-radius changes often"
        )
    # S632: Import hub
    _fanin632 = len([fp for fp in importers if not _is_test_file(fp)])
    _fanout632 = len(set(b_out_imports))
    if _fanin632 >= 5 and _fanin632 >= _fanout632 * 3:
        lines.append(
            f"import hub: {_fp.rsplit('/', 1)[-1]} has {_fanin632} importers but only {_fanout632} dependencies"
            f" — pure consumer hub; changes here ripple widely with no upstream buffer"
        )


def _signals_blast_core_c(
    graph: "Tempo",
    file_path: str,
    fi,
    symbols: list,
    importers: list[str],
    lines: list[str]
) -> None:
    # Outgoing import targets — O(1) index lookup, no edge scan.
    _b_out_imports = graph.outgoing_imports_of(file_path)
    _blast_core_c_importers(graph, file_path, importers, lines)
    _blast_core_c_module_role(file_path, importers, lines)
    _blast_core_c_structure(graph, file_path, fi, lines)
    _blast_core_c_cycles(graph, file_path, _b_out_imports, lines)
    _blast_core_c_symbols(graph, file_path, importers, lines)
    _blast_core_c_patterns(graph, file_path, importers, _b_out_imports, lines)



def _blast_core_d_isolation(
    graph: "Tempo",
    file_path: str,
    lines: list[str]
) -> None:
    _fp = file_path.replace("\\", "/")
    _basename = _fp.rsplit("/", 1)[-1]
    # S680: Test file blast — blast target is a test file.
    if _is_test_file(_fp):
        lines.append(
            f"test file blast: {_basename} is a test file"
            f" — blast radius of test files is rarely meaningful; consider targeting the source file"
        )
    # S686: Zero-impact blast — blast target has no importers and no cross-file callers.
    _importers686 = graph.importers_of(_fp)
    _ext686 = [f for f in _importers686 if f != _fp]
    _fi686 = graph.files.get(_fp)
    _all_syms686 = graph.symbols_in_file(_fp) if _fi686 else []
    _has_ext_callers686 = any(graph.callers_of(s.id) for s in _all_syms686)
    if not _ext686 and not _has_ext_callers686 and not _is_test_file(_fp):
        lines.append(
            f"zero-impact blast: {_basename} has no importers or callers"
            f" — island file; changes are risk-free but file itself may be dead code"
        )
    # S692: Heavily imported — blast target is imported by 10+ files.
    _ext_importers692 = [f for f in graph.importers_of(_fp) if f != _fp]
    if len(_ext_importers692) >= 10:
        lines.append(
            f"heavily imported: {_basename} is imported by {len(_ext_importers692)} files"
            f" — wide coupling; interface changes require coordinated updates across the codebase"
        )
    # S698: Single export — blast target file exports exactly 1 public top-level symbol.
    _fi698 = graph.files.get(_fp)
    if _fi698 and not _is_test_file(_fp):
        _pub_syms698 = [
            s for s in graph.symbols_in_file(_fp)
            if s.parent_id is None and s.kind.value not in ("unknown", "module")
        ]
        if len(_pub_syms698) == 1:
            lines.append(
                f"single export: {_basename} exports only '{_pub_syms698[0].name}'"
                f" — single-symbol file; consider consolidating into a parent module"
            )
    # S704: No external dependencies — blast target makes no cross-file calls.
    _target_syms704 = graph.symbols_in_file(_fp)
    _has_ext_callees704 = any(
        any(c.file_path != _fp for c in graph.callees_of(s.id))
        for s in _target_syms704
    )
    if _target_syms704 and not _has_ext_callees704 and not _is_test_file(_fp):
        _importers704 = [f for f in graph.importers_of(_fp) if f != _fp]
        if _importers704:
            lines.append(
                f"no external dependencies: {_basename} calls nothing outside itself"
                f" — leaf module; changes are contained; only caller-side integration matters"
            )


def _blast_core_d_naming_a(
    graph: "Tempo",
    file_path: str,
    lines: list[str]
) -> None:
    _fp = file_path.replace("\\", "/")
    _basename = _fp.rsplit("/", 1)[-1]
    _stem = _basename.rsplit(".", 1)[0].lower()
    # S710: Deeply nested blast — blast target is 3+ directory levels below the repo root.
    _depth710 = len(_fp.split("/"))
    if _depth710 >= 4:
        lines.append(
            f"deeply nested: {_basename} is at depth {_depth710 - 1}"
            f" in the directory tree — hard-to-find file; consider flattening"
        )
    # S716: Config file blast — the blast target is a config/settings/constants/exceptions file.
    if _basename in {"config.py", "settings.py", "constants.py", "exceptions.py", "errors.py"}:
        lines.append(
            f"config file blast: {_basename} is a shared config/constants file"
            f" — changes here propagate to all importers; review blast radius carefully"
        )
    # S722: Utility file blast — utility-style name (util/helper/common etc).
    _util_kws722 = ("util", "helper", "common", "shared", "base", "mixin")
    if any(kw in _stem for kw in _util_kws722):
        lines.append(
            f"utility file blast: {_basename} has a utility-style name"
            f" — widely imported by convention; expect broad blast radius"
        )
    # S728: Package init blast — blast target is a __init__.py file.
    if _basename == "__init__.py":
        lines.append(
            f"package init blast: {_fp} is a package __init__.py"
            f" — all package consumers depend on this; changes affect the entire public API"
        )
    # S734: Data model blast — blast target is a data model/schema/entity file.
    _model_kws734 = ("model", "schema", "entity", "dto", "domain")
    if any(kw in _stem for kw in _model_kws734):
        lines.append(
            f"data model blast: {_basename} is a data model/schema file"
            f" — domain changes cascade to serializers, validators, and all consumers"
        )
    # S740: Middleware/decorator blast — blast target has a middleware or decorator filename.
    _mw_kws740 = ("middleware", "decorator", "wrapper", "interceptor", "hook")
    if any(kw in _stem for kw in _mw_kws740):
        lines.append(
            f"middleware blast: {_basename} is a middleware/decorator file"
            f" — cross-cutting concern; changes affect every code path using this wrapper"
        )
    # S746: Client file blast — the blast target has "client" in its filename.
    if "client" in _stem:
        lines.append(
            f"client file blast: {_basename} is a client/connector file"
            f" — changes affect all code reaching external services through this client"
        )
    # S752: Test helper blast — blast target is a test helper/fixture/conftest file.
    _test_helper_kws752 = ("conftest", "fixture", "factory", "helper", "mock", "fake", "stub")
    if any(kw in _stem for kw in _test_helper_kws752):
        _test_importers752 = [f for f in graph.importers_of(_fp) if _is_test_file(f)]
        if len(_test_importers752) >= 2:
            lines.append(
                f"test helper blast: {_basename} is a test helper used by"
                f" {len(_test_importers752)} test files — changes here break tests silently; review all usages"
            )
    # S758: Router file blast — blast target is a routing/URL dispatcher file.
    _router_kws758 = ("router", "routes", "routing", "urls", "url_conf", "endpoint", "endpoints")
    if any(kw in _stem for kw in _router_kws758):
        lines.append(
            f"router file blast: {_basename} is a routing/URL file"
            f" — changes here affect which handlers run per request; test all affected routes"
        )


def _blast_core_d_structure_a(
    graph: "Tempo",
    file_path: str,
    lines: list[str]
) -> None:
    _fp = file_path.replace("\\", "/")
    _basename = _fp.rsplit("/", 1)[-1]
    _stem = _basename.rsplit(".", 1)[0].lower()
    # S764: Large API file — blast target file has 10+ exported top-level symbols.
    _fi764 = graph.files.get(_fp)
    if _fi764 and not _is_test_file(_fp):
        _exported764 = [
            s for s in graph.symbols_in_file(_fp)
            if s.parent_id is None and s.exported
        ]
        if len(_exported764) >= 10:
            lines.append(
                f"large API file: {_basename} exports {len(_exported764)} public symbols"
                f" — large surface area; any change risks breaking a consumer; consider splitting"
            )
    # S770: Constants file blast — constants/settings/config file name pattern.
    _const_kws770 = ("constants", "consts", "settings", "config", "configuration", "defaults", "env")
    if any(kw == _stem or _stem.startswith(kw + "_") or _stem.endswith("_" + kw) for kw in _const_kws770):
        lines.append(
            f"constants file blast: {_basename} is a constants/settings file"
            f" — value changes silently affect every consumer; test all affected code paths"
        )
    # S776: Many-importer blast — blast target is imported by 10+ source files.
    _importers776 = [f for f in graph.importers_of(_fp) if not _is_test_file(f)]
    if len(_importers776) >= 10:
        lines.append(
            f"many-importer blast: {_basename} is imported by {len(_importers776)} source files"
            f" — structural hub; breaking changes cascade to {len(_importers776)} dependents"
        )
    # S788: Shared utility blast — exact utility/shared/common file name match.
    _util_kws788 = ("utils", "util", "helpers", "helper", "shared", "common", "base", "core", "lib", "tools")
    if any(kw == _stem or _stem == f"_{kw}" for kw in _util_kws788):
        lines.append(
            f"shared utility blast: {_basename} is a utility/shared file"
            f" — changes here often affect more callers than are immediately visible; check all importers"
        )
    # S806: High fan-out blast — blast target calls 10+ symbols in other files.
    # Iterate symbols IN _fp and collect their external callees (O(N_file_syms)) instead of
    # scanning all graph symbols and checking callers_of each (O(N_all_syms) = 7949 calls).
    _callee_set806: set[str] = set()
    for _sym806 in graph.symbols_in_file(_fp):
        for _callee806 in graph.callees_of(_sym806.id):
            if _callee806.file_path != _fp:
                _callee_set806.add(_callee806.id)
    if len(_callee_set806) >= 10:
        lines.append(
            f"high fan-out blast: {_basename} calls {len(_callee_set806)} external symbols"
            f" — dense dependency; changes require tracing effects through many call paths"
        )


def _blast_core_d_structure_b(
    graph: "Tempo",
    file_path: str,
    lines: list[str]
) -> None:
    _fp = file_path.replace("\\", "/")
    _basename = _fp.rsplit("/", 1)[-1]
    # S824: High import count blast — blast target file has 10+ unique imports.
    if _fp in graph.files:
        if len(graph.files[_fp].imports) >= 10:
            lines.append(
                f"high import count: {_basename} has {len(graph.files[_fp].imports)} imports"
                f" — many dependencies; transitive blast radius is wider than direct importers suggest"
            )
    # S836: Large file blast — blast target source file exceeds 500 lines.
    if _fp in graph.files:
        _lc836 = graph.files[_fp].line_count
        if _lc836 >= 500:
            lines.append(
                f"large file blast: {_basename} is {_lc836:,} lines"
                f" — large source file; blast analysis may undercount indirect symbol effects"
            )
    # S848: No direct symbol callers blast — blast target has importers but no graph callers.
    if _fp in graph.files:
        _importers848 = graph.importers_of(_fp)
        _syms848 = [graph.symbols[sid] for sid in graph.files[_fp].symbols if sid in graph.symbols]
        _callers848 = [c for s in _syms848 for c in graph.callers_of(s.id)]
        if len(_importers848) >= 3 and not _callers848:
            lines.append(
                f"no symbol callers: {_basename} has {len(_importers848)} importers but no tracked callers"
                f" — likely exports constants or type aliases; changes affect importers invisibly"
            )
    # S908: Dense file blast — blast target has 30+ symbols defined in it.
    _syms_in_file908 = graph.symbols_in_file(_fp)
    if len(_syms_in_file908) >= 30:
        lines.append(
            f"dense file blast: {_basename} has {len(_syms_in_file908)} symbols"
            f" — dense file; changes have higher chance of unintended side effects"
        )
    # S944: Widely-imported blast — blast target is imported by 5+ other source files.
    _file_syms944 = graph.symbols_in_file(_fp)
    _importers944 = {
        c.file_path
        for s in _file_syms944
        for c in graph.callers_of(s.id)
        if not _is_test_file(c.file_path) and c.file_path != _fp
    }
    if len(_importers944) >= 5:
        lines.append(
            f"widely-imported blast: {_basename} is imported by {len(_importers944)} source module(s)"
            f" — high fan-in; test all consumers after changes; regressions may surface in unexpected call sites"
        )


def _blast_core_d_naming_b(
    graph: "Tempo",
    file_path: str,
    lines: list[str]
) -> None:
    _fp = file_path.replace("\\", "/")
    _basename = _fp.rsplit("/", 1)[-1]
    _stem = _basename.rsplit(".", 1)[0].lower()
    # S782: Test file blast — blast target is itself a test file.
    if _is_test_file(_fp):
        lines.append(
            f"test file blast: {_basename} is a test file"
            f" — changes here affect test suite coverage and may break dependent test files"
        )
    # S794: CLI entry point blast — blast target is a CLI entry point file.
    if _stem in ("__main__", "cli", "main", "entrypoint", "entry_point", "run"):
        lines.append(
            f"CLI entry point blast: {_basename} is an application entry point"
            f" — changes affect startup sequence, argument parsing, and all initialization logic"
        )
    # S800: Plugin/hook registration blast — blast target is a plugin registry file.
    _plugin_kws800 = ("plugin", "plugins", "registry", "register", "hooks", "extensions", "middleware")
    if any(kw == _stem or _stem.startswith(kw + "_") or _stem.endswith("_" + kw) for kw in _plugin_kws800):
        lines.append(
            f"plugin registry blast: {_basename} is a plugin/hook registry file"
            f" — changes here affect all registered handlers, including external plugins"
        )
    # S812: Constants/config blast — config/constants/vars file name pattern.
    _cfg_kws812 = ("constants", "constant", "config", "settings", "conf", "consts", "vars", "env")
    if any(_stem == kw or _stem.startswith(kw + "_") or _stem.endswith("_" + kw) for kw in _cfg_kws812):
        lines.append(
            f"constants blast: {_basename} is a constants/config file"
            f" — value changes propagate silently to all importers without triggering call-graph alerts"
        )
    # S818: Test file blast — changing a test file affects test coverage and safety nets.
    if _is_test_file(_fp):
        lines.append(
            f"test file blast: {_basename} is a test file"
            f" — changes here affect coverage and safety nets; verify no fixtures are inadvertently modified"
        )
    # S830: Init file blast — blast target is an __init__.py.
    if _basename == "__init__.py":
        lines.append(
            f"init file blast: blast target is __init__.py"
            f" — package public surface; all importers of this package are in blast radius"
        )
    # S842: Constants file blast — constants/config/settings file name pattern (variant).
    _const_kws842 = ("constants", "config", "settings", "conf", "defaults", "env", "params")
    if any(_stem == kw or _stem.startswith(kw + "_") or _stem.endswith("_" + kw) for kw in _const_kws842):
        lines.append(
            f"constants file blast: {_basename} is a constants/config file"
            f" — value changes propagate to all consumers; blast radius is wider than direct callers"
        )
    # S854: Test helper blast — blast target is a shared test utility file.
    _test_helper_kws854 = ("test_utils", "test_helpers", "test_fixtures", "conftest", "fixtures", "factories")
    if any(_stem == kw or _stem.startswith(kw) for kw in _test_helper_kws854):
        lines.append(
            f"test helper blast: {_basename} is a shared test utility"
            f" — changing test helpers invalidates assumptions across the test suite"
        )
    # S860: API file blast — blast target is in an api/views/endpoints/routes directory.
    _api_kws860 = {"api", "views", "endpoints", "routes", "controllers", "handlers"}
    if any(part.lower() in _api_kws860 for part in _fp.split("/")[:-1]):
        lines.append(
            f"api layer blast: {_basename} is in an API layer directory"
            f" — external contracts; changes affect API consumers beyond the call graph"
        )
    # S866: Migration file blast — blast target is a database migration file.
    _migration_kws866 = ("migration", "migrate", "upgrade", "downgrade", "alembic")
    if any(kw in _stem for kw in _migration_kws866):
        lines.append(
            f"migration file blast: {_basename} is a database migration"
            f" — schema change; verify all models and queries match the new schema"
        )
    # S872: Serializer/formatter blast — blast target handles serialization or encoding.
    _serial_kws872 = ("serial", "format", "codec", "marshal", "encode", "decode", "schema")
    if any(kw in _stem for kw in _serial_kws872):
        lines.append(
            f"serializer blast: {_basename} handles serialization or encoding"
            f" — format changes affect all I/O boundaries; verify protocol compatibility"
        )
    # S884: Security-sensitive blast — blast target handles authentication or credentials.
    _sec_kws884 = ("auth", "token", "secret", "credential", "password", "jwt", "oauth", "crypto", "session")
    if any(kw in _stem for kw in _sec_kws884):
        lines.append(
            f"security blast: {_basename} handles authentication or security"
            f" — security-sensitive file; bugs here can expose data or bypass authorization"
        )
    # S878: Config file blast — blast target is a configuration or settings file.
    _config_kws878 = ("config", "settings", "conf", "setup", "options", "params")
    if any(kw in _stem for kw in _config_kws878):
        lines.append(
            f"config blast: {_basename} is a configuration or settings file"
            f" — config changes affect all modules that read from it; review startup and default values"
        )
    # S890: Database file blast — blast target handles database access or ORM operations.
    _db_kws890 = ("db", "database", "orm", "model", "migration", "repo", "repository", "dao", "query")
    if any(kw in _stem for kw in _db_kws890) and "mock" not in _stem and "test" not in _stem:
        lines.append(
            f"database blast: {_basename} handles database operations"
            f" — database changes risk data corruption or silent query failures; review transactions"
        )
    # S896: Event handler blast — blast target handles events, messages, or pub/sub.
    _event_kws896 = ("handler", "listener", "subscriber", "receiver", "consumer", "event", "message", "queue")
    if any(kw in _stem for kw in _event_kws896):
        lines.append(
            f"event handler blast: {_basename} handles events or messages"
            f" — event handler changes affect all producers and consumers; verify message contracts"
        )
    # S902: Router blast — blast target is a router, controller, or API endpoint file.
    _router_kws902 = ("route", "router", "endpoint", "controller", "view", "urls", "api")
    if any(kw in _stem for kw in _router_kws902):
        lines.append(
            f"router blast: {_basename} contains routes or endpoints"
            f" — changes affect API surface; review backward compatibility and client contracts"
        )
    # S914: Test file blast — blast radius requested for a test file (variant).
    if _is_test_file(_fp):
        lines.append(
            f"test file blast: {_basename} is a test file"
            f" — blast radius of test files is typically low; verify this is the intended target"
        )


def _blast_core_d_service(
    graph: "Tempo",
    file_path: str,
    lines: list[str]
) -> None:
    _fp = file_path.replace("\\", "/")
    _basename = _fp.rsplit("/", 1)[-1]
    _stem = _basename.rsplit(".", 1)[0].lower()
    # S920: Cache blast — blast target is a caching or session file.
    _cache_kws920 = ("cache", "redis", "memcache", "session", "store", "buffer")
    if any(kw in _stem for kw in _cache_kws920):
        lines.append(
            f"cache blast: {_basename} manages caching or sessions"
            f" — cache changes affect shared state; verify invalidation logic and concurrent access"
        )
    # S926: Middleware blast — blast target is a middleware or interceptor file.
    _mw_kws926 = ("middleware", "interceptor", "filter", "guard", "hook", "pipeline", "chain")
    if any(kw in _stem for kw in _mw_kws926):
        lines.append(
            f"middleware blast: {_basename} is a middleware or interceptor"
            f" — runs on every request; changes have maximum runtime impact; test exhaustively"
        )
    # S932: Utility blast — blast target is a shared utility file with active callers.
    _util_kws932 = ("util", "helper", "common", "shared", "lib", "base", "mixin")
    if any(kw in _stem for kw in _util_kws932):
        _callers_of_file932 = {
            c.file_path for s in graph.symbols_in_file(_fp)
            for c in graph.callers_of(s.id)
        }
        if len(_callers_of_file932) >= 3:
            lines.append(
                f"utility blast: {_basename} is a shared utility file used by {len(_callers_of_file932)} module(s)"
                f" — minor changes ripple widely; test all consumers before merging"
            )
    # S938: Loader blast — blast target is a file that loads, parses, or imports data.
    _loader_kws938 = ("loader", "load", "parser", "parse", "reader", "reader", "importer", "import_")
    if any(_stem == kw or _stem.endswith("_" + kw) or _stem.startswith(kw + "_") for kw in _loader_kws938):
        lines.append(
            f"loader blast: {_basename} loads or parses data at startup"
            f" — loader errors prevent application start; changes require extra caution and testing"
        )
    # S950: Context manager blast — blast target is a context manager or context utility file.
    _ctx_kws950 = ("context", "ctx", "contextlib", "contextmanager", "scope", "transaction")
    if any(_stem == kw or _stem.startswith(kw + "_") or _stem.endswith("_" + kw) for kw in _ctx_kws950):
        lines.append(
            f"context manager blast: {_basename} manages context/scope"
            f" — changes affect resource acquisition and cleanup in all 'with' block consumers"
        )
    # S956: Fixture blast — blast target is a shared test fixture file.
    _fname956 = _basename.lower()
    _stem956 = _fname956.rsplit(".", 1)[0]
    if _fname956 == "conftest.py" or _stem956 in ("fixtures", "conftest") or _stem956.startswith("conftest_"):
        lines.append(
            f"fixture blast: {_basename} is a shared fixture file"
            f" — pytest auto-imports this; changes silently affect all tests in its scope without explicit import"
        )


def _blast_core_d_integration(
    graph: "Tempo",
    file_path: str,
    lines: list[str]
) -> None:
    _fp = file_path.replace("\\", "/")
    _basename = _fp.rsplit("/", 1)[-1]
    _stem = _basename.rsplit(".", 1)[0].lower()
    # S962: Router blast — blast target is a routing/URL dispatch file (exact name match).
    _router_kws962 = ("router", "routes", "urls", "routing", "endpoints", "paths")
    if any(_stem == kw or _stem.startswith(kw + "_") or _stem.endswith("_" + kw) for kw in _router_kws962):
        lines.append(
            f"router blast: {_basename} is a routing file"
            f" — path/method changes may silently break existing endpoints; verify all routes are tested"
        )
    # S968: Migration blast — blast target is a database migration file (path or name).
    _mig_kws968 = ("migration", "migrate", "alembic", "schema", "flyway")
    _in_migrations968 = any(kw in _fp.lower() for kw in ("migrations/", "migration/", "alembic/"))
    if _in_migrations968 or any(_stem == kw or _stem.startswith(kw + "_") for kw in _mig_kws968):
        lines.append(
            f"migration blast: {_basename} is a database migration file"
            f" — schema changes are often irreversible; require DBA review and tested rollback plan"
        )
    # S974: Storage blast — blast target is a storage/repository/data access file.
    _store_kws974 = ("store", "storage", "repository", "repo", "dao", "data_access", "persistence")
    if any(_stem == kw or _stem.startswith(kw + "_") or _stem.endswith("_" + kw) for kw in _store_kws974):
        lines.append(
            f"storage blast: {_basename} is a data storage abstraction"
            f" — query shape or return type changes silently break all business logic callers"
        )
    # S980: Cache blast — blast target is a caching layer file (exact name match).
    _cache_kws980 = ("cache", "cached", "caching", "memoize", "memoization", "redis", "memcache", "memcached")
    if any(_stem == kw or _stem.startswith(kw + "_") or _stem.endswith("_" + kw) for kw in _cache_kws980):
        lines.append(
            f"cache blast: {_basename} is a caching layer"
            f" — eviction, key format, or TTL changes silently affect correctness for all cached call paths"
        )
    # S986: Config blast — blast target is a configuration file (exact name match).
    _config_kws986 = ("config", "configuration", "settings", "env", "environment", "options", "params", "parameters", "defaults", "conf")
    if any(_stem == kw or _stem.startswith(kw + "_") or _stem.endswith("_" + kw) for kw in _config_kws986):
        lines.append(
            f"config blast: {_basename} is a configuration file"
            f" — runtime behavior changes affect all consumers; flag for explicit review before merge"
        )
    # S992: Schema blast — blast target is a schema/model/entity definition file.
    _schema_kws992 = ("schema", "schemas", "model", "models", "entity", "entities", "types", "typedefs", "datamodel", "domain")
    if any(_stem == kw or _stem.startswith(kw + "_") or _stem.endswith("_" + kw) for kw in _schema_kws992):
        lines.append(
            f"schema blast: {_basename} is a schema/model definition"
            f" — changes require coordinated migration, serialization updates, and consumer validation"
        )
    # S1004: Security blast — blast target is an authentication or security file.
    _sec_kws1004 = ("auth", "authentication", "authorization", "security", "credentials", "crypto", "password", "passwords", "token", "tokens", "session", "sessions", "permission", "permissions", "acl", "oauth", "jwt")
    if any(_stem == kw or _stem.startswith(kw + "_") or _stem.endswith("_" + kw) for kw in _sec_kws1004):
        lines.append(
            f"security blast: {_basename} is an auth/security module"
            f" — high-stakes; changes may silently bypass checks, escalate privileges, or expose credentials"
        )
    # S1010: Serializer blast — blast target is a serialization/marshaling file.
    _ser_kws1010 = ("serializer", "serializers", "marshal", "marshaller", "codec", "codecs", "encoder", "encoders", "decoder", "decoders")
    if any(_stem == kw or _stem.startswith(kw + "_") or _stem.endswith("_" + kw) for kw in _ser_kws1010):
        lines.append(
            f"serializer blast: {_basename} is a serialization/marshaling file"
            f" — format changes break downstream consumers without any code change on their side"
        )
    # S1016: Task blast — blast target is a background task or job scheduling file.
    _task_kws1016 = ("task", "tasks", "job", "jobs", "worker", "workers", "celery", "queue", "queues", "scheduler", "beat")
    if any(_stem == kw or _stem.startswith(kw + "_") or _stem.endswith("_" + kw) for kw in _task_kws1016):
        lines.append(
            f"task blast: {_basename} is a background task or job file"
            f" — changes affect async work outside the request cycle; harder to trace and test end-to-end"
        )


def _signals_blast_core_d(
    graph: "Tempo",
    file_path: str,
    fi,
    symbols: list,
    importers: list[str],
    lines: list[str]
) -> None:
    _blast_core_d_isolation(graph, file_path, lines)
    _blast_core_d_naming_a(graph, file_path, lines)
    _blast_core_d_structure_a(graph, file_path, lines)
    _blast_core_d_structure_b(graph, file_path, lines)
    _blast_core_d_naming_b(graph, file_path, lines)
    _blast_core_d_service(graph, file_path, lines)
    _blast_core_d_integration(graph, file_path, lines)



def _resolve_blast_file_path(graph: Tempo, file_path: str) -> str:
    """Resolve file_path to a graph-relative path.

    Handles: absolute paths (strips repo root), and partial suffix paths.
    Returns the resolved relative path if a unique match is found, else
    returns the original file_path unchanged.
    """
    # Try absolute → relative (strip repo root prefix)
    if graph.root and Path(file_path).is_absolute():
        try:
            rel = str(Path(file_path).relative_to(Path(graph.root)))
            if rel in graph.files:
                return rel
        except ValueError:
            pass

    # Try suffix matching: "render/blast.py" or "blast.py" → "tempograph/render/blast.py"
    needle = file_path.lstrip("/").lstrip("./").replace("\\", "/")
    if needle:
        matches = [fp for fp in graph.files if fp == needle or fp.endswith("/" + needle)]
        if len(matches) == 1:
            return matches[0]

    return file_path


def _blast_lookup(graph: Tempo, file_path: str):
    """Resolve file_path to a FileInfo, returning (fi, path) on success or an error string."""
    fi = graph.files.get(file_path)
    if not fi:
        _resolved = _resolve_blast_file_path(graph, file_path)
        if _resolved != file_path:
            fi = graph.files.get(_resolved)
            if fi:
                file_path = _resolved
    if not fi:
        if file_path and Path(file_path).exists():
            parent_dir = Path(file_path).parent.name
            exclude_hint = (
                f" (e.g. '{parent_dir}' may be in your --exclude list)" if parent_dir else ""
            )
            return (
                f"⚠  '{file_path}' exists on disk but is not in the graph{exclude_hint}.\n"
                "   Re-run without --exclude to index it, or run "
                "`tempograph . --mode overview` to see what is currently indexed."
            )
        if file_path.lower().endswith(".pyi"):
            return (
                f"type stub blast: {file_path.rsplit('/', 1)[-1]} is a type stub"
                f" — stub changes break type checks without runtime errors;"
                f" update callers together\n"
                f"(stub files are not graph-indexed; run mypy/pyright to check downstream impact)"
            )
        _needle = file_path.lstrip("/").lstrip("./").replace("\\", "/")
        if _needle:
            _candidates = sorted(
                fp for fp in graph.files if fp == _needle or fp.endswith("/" + _needle)
            )
            if len(_candidates) > 1:
                _cand_lines = "\n".join(f"  {fp}" for fp in _candidates[:8])
                _hint = f"  Try: --file '{_candidates[0]}'" if _candidates else ""
                return (
                    f"Ambiguous path '{file_path}' — {len(_candidates)} files match:\n"
                    f"{_cand_lines}\n"
                    f"{_hint}"
                ).rstrip()
        return f"File '{file_path}' not found."
    return fi, file_path


def _blast_file_age(graph: Tempo, file_path: str, lines: list[str]) -> None:
    """Append file age signal (S108) to lines if available."""
    if not graph.root:
        return
    try:
        from ..git import file_last_modified_days as _fld_blast  # noqa: PLC0415
        _blast_age = _fld_blast(graph.root, file_path)
        if _blast_age is not None:
            if _blast_age <= 3:
                _age_label = f"last touched: {_blast_age}d ago (active)"
            elif _blast_age >= 90:
                _age_label = f"last touched: {_blast_age}d ago (stable)"
            else:
                _age_label = f"last touched: {_blast_age}d ago"
            lines.append(_age_label)
    except Exception:
        pass


def _blast_importers_section(
    graph: Tempo, file_path: str, symbols: list, importers: list[str], lines: list[str]
) -> None:
    """Append direct importers section with usage, safety, and recency info."""
    if not importers:
        return
    lines.append(f"Directly imported by ({len(importers)}):")
    # Build index: importer_file → [caller symbol names that call INTO blast target]
    _target_sym_ids = {sym.id for sym in symbols}
    _importer_users: dict[str, list[str]] = {}
    _importer_file_set = set(importers)
    for _sym_id_imp in _target_sym_ids:
        for _caller_imp in graph.callers_of(_sym_id_imp):
            if _caller_imp.file_path in _importer_file_set:
                _importer_users.setdefault(_caller_imp.file_path, []).append(_caller_imp.name)
    _all_test_fps = {fp for fp in graph.files if _is_test_file(fp)}
    _src_importers = [imp for imp in importers if not _is_test_file(imp)]
    # Sort by call count descending: most-dependent callers appear first.
    # Ties broken by file path for stable output.
    _sorted_importers = sorted(
        importers, key=lambda imp: (-len(_importer_users.get(imp, [])), imp)
    )
    for imp in _sorted_importers:
        users = _importer_users.get(imp, [])
        unique_users = list(dict.fromkeys(users))[:3]  # deduplicate, cap at 3
        if unique_users:
            lines.append(f"  {imp} — used by: {', '.join(unique_users)}")
        else:
            lines.append(f"  {imp}")
    # Refactor safety: how many source importers have test coverage?
    if _src_importers and _all_test_fps:
        _tested = sum(
            1 for imp in _src_importers
            if any(imp.rsplit("/", 1)[-1].rsplit(".", 1)[0] in t for t in _all_test_fps)
        )
        _pct = int(_tested / len(_src_importers) * 100)
        lines.append(f"  refactor safety: {_tested}/{len(_src_importers)} caller files tested ({_pct}%)")
    # S51: recent callers — importers modified in last 14 days signal blast radius growing
    if _src_importers and graph.root:
        try:
            from ..git import file_last_modified_days as _fld  # noqa: PLC0415
            _recent = [(imp, _fld(graph.root, imp)) for imp in _src_importers]
            _recent = [(imp, d) for imp, d in _recent if d is not None and d <= 14]
            if len(_recent) >= 2:
                _recent.sort(key=lambda x: x[1])
                _rec_parts = [f"{imp.rsplit('/', 1)[-1]} ({d}d ago)" for imp, d in _recent[:3]]
                lines.append(f"  Recent callers (14d): {', '.join(_rec_parts)}  ← blast radius growing")
        except Exception:
            pass
    lines.append("")


def _blast_symbols_section(
    graph: Tempo, file_path: str, symbols: list, lines: list[str]
) -> tuple[dict, set]:
    """Append export surface, external callers, untested exports, render targets; return (external_callers, render_targets)."""
    # S111: Export surface — fraction of symbols in blast file that are exported.
    # High export ratio = public API file = callers everywhere = max review caution.
    # Only shown when 3+ total symbols and ratio >= 50%.
    _all_file_syms = [s for s in symbols if s.kind.value in ("function", "method", "class", "interface")]
    _exported_file_syms = [s for s in _all_file_syms if s.exported]
    if len(_all_file_syms) >= 3 and len(_exported_file_syms) >= 2:
        _exp_pct = int(len(_exported_file_syms) / len(_all_file_syms) * 100)
        if _exp_pct >= 50:
            lines.append(f"export surface: {len(_exported_file_syms)}/{len(_all_file_syms)} symbols exported ({_exp_pct}%)")
    external_callers: dict[str, list[str]] = {}
    for sym in symbols:
        callers = graph.callers_of(sym.id)
        ext = [c for c in callers if c.file_path != file_path]
        if ext:
            external_callers[sym.qualified_name] = [f"{c.file_path}:{c.line_start}" for c in ext]
    if external_callers:
        lines.append("Externally called symbols:")
        for name, locations in sorted(external_callers.items()):
            lines.append(f"  {name}:")
            for loc in locations[:5]:
                lines.append(f"    {loc}")
        lines.append("")
    # S91: Untested exports — exported functions/methods with no test callers.
    # Agents need to know which symbols lack a safety net before making changes.
    # Only shown when 2+ qualify (single untested export is too common to be signal).
    _untested_exports = [
        sym for sym in symbols
        if sym.exported and sym.kind.value in ("function", "method")
        and not any(_is_test_file(c.file_path) for c in graph.callers_of(sym.id))
    ]
    if len(_untested_exports) >= 2:
        _ue_names = [s.name for s in _untested_exports[:5]]
        _ue_str = ", ".join(_ue_names)
        if len(_untested_exports) > 5:
            _ue_str += f" +{len(_untested_exports) - 5} more"
        lines.append(f"Untested exports ({len(_untested_exports)}): {_ue_str} — no test coverage")
        lines.append("")
    render_targets: set = set()
    for sym in symbols:
        for renderer in graph.renderers_of(sym.id):
            if renderer.file_path != file_path:
                render_targets.add(f"{renderer.file_path}:{renderer.line_start} renders {sym.name}")
    if render_targets:
        lines.append("Component render relationships:")
        for rt in sorted(render_targets):
            lines.append(f"  {rt}")
    return external_callers, render_targets


def _blast_cascade_section(
    graph: Tempo, file_path: str, importers: list[str], lines: list[str]
) -> None:
    """Append transitive import cascade BFS (cap: 5 levels, 200 files)."""
    if not importers:
        return
    _visited: set[str] = {file_path}
    _by_depth: dict[int, int] = {}
    _queue: list[tuple[str, int]] = [(fp, 1) for fp in importers]
    while _queue:
        fp, depth = _queue.pop(0)
        if fp in _visited or depth > 5:
            continue
        if sum(_by_depth.values()) >= 200:
            break
        _visited.add(fp)
        _by_depth[depth] = _by_depth.get(depth, 0) + 1
        _queue.extend((nfp, depth + 1) for nfp in graph.importers_of(fp) if nfp not in _visited)
    if len(_by_depth) > 1:  # only show when cascade goes beyond direct importers
        _total = sum(_by_depth.values())
        _max_d = max(_by_depth.keys())
        _depth_str = ", ".join(f"d{d}:{_by_depth[d]}" for d in sorted(_by_depth.keys()))
        lines.append(f"Transitive cascade: {_total} file(s) up to depth {_max_d} ({_depth_str})")
        lines.append("")


def _blast_tests_section(
    graph: Tempo, file_path: str, symbols: list, importers: list[str], lines: list[str]
) -> None:
    """Append test files that cover symbols in or directly import this file."""
    _blast_tests: dict[str, int] = {}  # test_file_path → symbol call count
    for sym in symbols:
        for caller in graph.callers_of(sym.id):
            if caller.file_path != file_path and _is_test_file(caller.file_path):
                _blast_tests[caller.file_path] = _blast_tests.get(caller.file_path, 0) + 1
    # Also include test files that directly import this file
    for imp in importers:
        if _is_test_file(imp):
            _blast_tests.setdefault(imp, 0)
    if not _blast_tests:
        return
    _sorted_tests = sorted(_blast_tests.items(), key=lambda x: -x[1])
    lines.append(f"Tests to run ({len(_blast_tests)}):")
    for _tfp, _cnt in _sorted_tests[:5]:
        _lbl = f" ({_cnt} call{'s' if _cnt != 1 else ''})" if _cnt else ""
        lines.append(f"  {_tfp}{_lbl}")
    if len(_blast_tests) > 5:
        lines.append(f"  ... and {len(_blast_tests) - 5} more")
    lines.append("")


def _blast_cochange_section(
    graph: Tempo, file_path: str, importers: list[str], lines: list[str]
) -> None:
    """Append co-change partners and recent callers (14d) sections."""
    _cc_orbit = _cochange_orbit(graph.root, [file_path], {file_path})
    if _cc_orbit:
        _cc_parts = []
        for _cc_fp, _cc_score, _cc_days in _cc_orbit[:4]:
            _cc_age = "recent" if _cc_days < 45 else ("aging" if _cc_days < 120 else "stale")
            _cc_parts.append(f"{_cc_fp.rsplit('/', 1)[-1]} ({_cc_score:.0%} {_cc_age})")
        lines.append(f"Co-change partners: {', '.join(_cc_parts)}")
        lines.append("")
    if not (importers and graph.root):
        return
    try:
        from ..git import file_last_modified_days as _fld  # noqa: PLC0415
        _recent_callers = [
            imp for imp in importers
            if not _is_test_file(imp)
            and (_fld(graph.root, imp) or 9999) <= 14
        ]
        if len(_recent_callers) >= 2:
            _rc_names = [fp.rsplit("/", 1)[-1] for fp in _recent_callers[:4]]
            _rc_str = ", ".join(_rc_names)
            if len(_recent_callers) > 4:
                _rc_str += f" +{len(_recent_callers) - 4} more"
            lines.append(f"Recent callers (14d): {_rc_str} — blast radius growing")
            lines.append("")
    except Exception:
        pass


def _blast_deps_section(graph: Tempo, file_path: str, lines: list[str]) -> None:
    """Append outgoing dependencies section (S74)."""
    _deps_of_target = sorted(
        t for t in graph.outgoing_imports_of(file_path)
        if t in graph.files
        and not _is_test_file(t)
        and t != file_path
    )
    if len(_deps_of_target) >= 3:
        _dep_names = [fp.rsplit("/", 1)[-1] for fp in _deps_of_target[:5]]
        _dep_str = ", ".join(_dep_names)
        if len(_deps_of_target) > 5:
            _dep_str += f" +{len(_deps_of_target) - 5} more"
        lines.append(f"Imports from ({len(_deps_of_target)}): {_dep_str}")
        lines.append("")


def render_blast_radius(graph: Tempo, file_path: str, query: str = "") -> str:
    """Show what might break if a file or symbol is modified.

    If query is given, shows blast radius for matching symbols instead of
    the whole file — much more useful for monolith files."""
    if query:
        return _render_symbol_blast(graph, query)

    result = _blast_lookup(graph, file_path)
    if isinstance(result, str):
        return result
    fi, file_path = result

    lines = [f"Blast radius for {file_path}:", ""]
    _blast_file_age(graph, file_path, lines)

    importers = graph.importers_of(file_path)
    symbols = [graph.symbols[sid] for sid in fi.symbols if sid in graph.symbols]

    _blast_importers_section(graph, file_path, symbols, importers, lines)
    external_callers, render_targets = _blast_symbols_section(graph, file_path, symbols, lines)
    _blast_cascade_section(graph, file_path, importers, lines)
    _blast_tests_section(graph, file_path, symbols, importers, lines)
    _blast_cochange_section(graph, file_path, importers, lines)
    _blast_deps_section(graph, file_path, lines)

    _signals_blast_core_a(graph, file_path, fi, symbols, importers, external_callers, lines)
    _signals_blast_core_b(graph, file_path, fi, symbols, importers, external_callers, render_targets, lines)
    _signals_blast_core_c(graph, file_path, fi, symbols, importers, lines)
    _signals_blast_core_d(graph, file_path, fi, symbols, importers, lines)
    return "\n".join(lines)


def _render_symbol_blast(graph: Tempo, query: str) -> str:
    """Blast radius for specific symbols — targeted alternative to whole-file blast."""
    matches = graph.search_symbols(query)
    if not matches:
        return f"No symbols matching '{query}'"

    lines = [f"Symbol blast radius for '{query}':", ""]
    for sym in matches[:5]:
        loc = f"{sym.file_path}:{sym.line_start}-{sym.line_end}"
        lines.append(f"● {sym.kind.value} {sym.qualified_name} — {loc}")

        callers = graph.callers_of(sym.id)
        if callers:
            ext = [c for c in callers if c.file_path != sym.file_path]
            local = [c for c in callers if c.file_path == sym.file_path]
            if ext:
                lines.append(f"  external callers ({len(ext)}):")
                for c in ext[:8]:
                    lines.append(f"    {c.file_path}:{c.line_start} — {c.qualified_name}")
            if local:
                lines.append(f"  same-file callers ({len(local)}):")
                for c in local[:5]:
                    lines.append(f"    L{c.line_start} — {c.qualified_name}")
        else:
            lines.append("  no callers")

        renderers = graph.renderers_of(sym.id)
        if renderers:
            lines.append(f"  rendered by ({len(renderers)}):")
            for r in renderers[:5]:
                lines.append(f"    {r.file_path}:{r.line_start} — {r.qualified_name}")

        children = graph.children_of(sym.id)
        if children:
            lines.append(f"  contains {len(children)} child symbol(s)")

        lines.append("")

    return "\n".join(lines)
