"""Build a Tempo from a repository root."""
from __future__ import annotations

import concurrent.futures
import fnmatch
import json
import os
import subprocess
import threading
from pathlib import Path
from typing import Sequence

from .cache import check_cache, load_cache, make_cache_entry, save_cache
from .storage import GraphDB, content_hash
from .types import Tempo, Edge, EdgeKind, FileInfo, Language, Symbol, SymbolKind, EXTENSION_TO_LANGUAGE
from .parser import FileParser
from .git import is_git_repo, recently_modified_files, changed_files_vs_head

DEFAULT_IGNORE_DIRS = frozenset({
    "node_modules", ".git", "__pycache__", "target", "dist", "build",
    ".next", ".nuxt", ".svelte-kit", "vendor", ".venv", "venv",
    "env", ".env", ".tox", ".mypy_cache", ".pytest_cache",
    ".cargo", "pkg", "coverage", ".turbo", ".cache",
})

DEFAULT_IGNORE_FILES = frozenset({
    "package-lock.json", "yarn.lock", "pnpm-lock.yaml", "Cargo.lock",
    "poetry.lock", "Pipfile.lock", "composer.lock",
})

# Languages with custom handlers (high-quality parsing)
CUSTOM_HANDLER_LANGUAGES = frozenset({
    Language.PYTHON, Language.TYPESCRIPT, Language.TSX,
    Language.JAVASCRIPT, Language.JSX, Language.RUST, Language.GO,
    Language.JAVA, Language.CSHARP, Language.RUBY, Language.BASH,
})

# Non-code languages that should never be parsed for symbols
_NON_CODE_LANGUAGES = frozenset({
    Language.JSON, Language.TOML, Language.YAML, Language.CSS,
    Language.HTML, Language.MARKDOWN, Language.UNKNOWN,
})

def _is_parseable(lang: Language) -> bool:
    """Check if a language can be parsed for symbols (custom handler or generic via language pack)."""
    if lang in _NON_CODE_LANGUAGES:
        return False
    if lang in CUSTOM_HANDLER_LANGUAGES:
        return True
    # Try language pack for extended languages
    try:
        from tempograph.parser import _get_ts_language
        return _get_ts_language(lang) is not None
    except Exception:
        return False

# Backward compat alias
PARSEABLE_LANGUAGES = CUSTOM_HANDLER_LANGUAGES

MAX_FILE_SIZE = 2 * 1024 * 1024  # 2MB — skip huge generated files

# Module-level Tempo cache keyed by (repo_path, exclude_key).
# Freshness is validated by stat-checking all tracked files against DB-stored mtimes.
# If all files match (no mtime change), the cached Tempo is returned immediately,
# skipping load_all (~13ms), build_indexes (~2ms), and resolve (~0ms) = ~22ms savings.
# Safe for concurrent use: protected by _TEMPO_CACHE_LOCK.
_TEMPO_CACHE: dict[tuple, "Tempo"] = {}
_TEMPO_CACHE_LOCK = threading.Lock()


def clear_tempo_cache() -> None:
    """Clear the module-level Tempo cache. Call from tests to ensure isolation."""
    with _TEMPO_CACHE_LOCK:
        _TEMPO_CACHE.clear()


def _any_file_changed(root: Path, stored_files: dict[str, tuple[str, int]]) -> bool:
    """Stat all tracked files against DB-stored mtime_ns. O(N) stats, no reads.

    Returns True if any file's mtime changed or was deleted since the last build.
    Does NOT detect purely new files (not in stored_files). In practice, new files
    are rare during active MCP sessions and are caught on the next full build.
    """
    for rel_path, (_, stored_mtime_ns) in stored_files.items():
        try:
            if os.stat(str(root / rel_path)).st_mtime_ns != stored_mtime_ns:
                return True
        except OSError:
            return True  # file deleted
    return False


def build_graph(
    root: str | Path,
    *,
    ignore_dirs: frozenset[str] = DEFAULT_IGNORE_DIRS,
    ignore_files: frozenset[str] = DEFAULT_IGNORE_FILES,
    include_patterns: Sequence[str] | None = None,
    exclude_patterns: Sequence[str] | None = None,
    exclude_dirs: Sequence[str] | None = None,
    use_cache: bool = True,
    use_config: bool = True,
    use_db: bool = True,
    lazy_edges: bool = False,
) -> Tempo:
    root = Path(root).resolve()
    # Normalize exclude_dirs: "a,b" string → ["a", "b"] list (str is Sequence[str] in Python,
    # so passing a comma-separated string would silently iterate over characters without this).
    if isinstance(exclude_dirs, str):
        exclude_dirs = [d.strip() for d in exclude_dirs.split(",") if d.strip()]

    # Merge exclude_dirs from .tempo/config.json, matching CLI and MCP server behavior.
    # Pass use_config=False to bypass (e.g. for tests that need raw unfiltered graph).
    if use_config:
        cfg_path = root / ".tempo" / "config.json"
        if cfg_path.exists():
            try:
                cfg_exclude = json.loads(cfg_path.read_text()).get("exclude_dirs", [])
                if cfg_exclude:
                    provided = list(exclude_dirs) if exclude_dirs else []
                    exclude_dirs = list(dict.fromkeys(cfg_exclude + provided)) or None
            except (json.JSONDecodeError, OSError):
                pass

    graph = Tempo(root=str(root))

    # Detect Tauri project: has src-tauri/ or tauri.conf.json
    is_tauri = (root / "src-tauri").is_dir() or (root / "tauri.conf.json").exists()

    # Open SQLite DB for persistent storage (preferred) or fall back to JSON cache
    db = GraphDB(root) if use_db else None
    cache = load_cache(root) if (use_cache and not use_db) else {}
    new_cache: dict = {}
    cache_hits = 0
    current_files: set[str] = set()

    # Bulk-fetch stored {path: (hash, mtime_ns)} — one query replaces per-file hash lookups.
    # mtime_ns check (nanosecond precision) skips read_bytes()+md5() for unchanged files.
    stored_files: dict[str, tuple[str, int]] = db.get_stored_files() if db else {}

    # Module-level process cache: if no tracked file changed on disk, return cached Tempo.
    # Validity: stat all tracked files against DB-stored mtimes (0.38ms DB + 2.88ms stats).
    # Saves ~22ms (load_all + build_indexes + resolve) per warm call when nothing changed.
    # Only active for DB-backed full builds; lazy_edges builds have different graph state.
    if use_db and db is not None and not lazy_edges and stored_files:
        exclude_key = tuple(sorted(exclude_dirs)) if exclude_dirs else ()
        process_cache_key = (str(root), exclude_key)
        with _TEMPO_CACHE_LOCK:
            cached_graph = _TEMPO_CACHE.get(process_cache_key)
        if cached_graph is not None and not _any_file_changed(root, stored_files):
            # Recompute hot_files: git-based, changes on each commit, not captured by mtime.
            if is_git_repo(str(root)):
                try:
                    all_hot = _get_hot_files(str(root))
                    cached_graph.hot_files = {f for f in all_hot if _is_hot_source_file(f)}
                except Exception:
                    pass
            db.close()
            return cached_graph

    # Batch all DB writes into one transaction (eliminates N per-file commits → 1).
    if db:
        db.begin_batch()

    # Kick off hot-file detection in background so it runs parallel to the parse loop.
    _is_git = is_git_repo(str(root))
    _hot_future: concurrent.futures.Future | None = None
    if _is_git:
        _hot_executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
        _hot_future = _hot_executor.submit(_get_hot_files, str(root))
        _hot_executor.shutdown(wait=False)

    for file_path_str, rel_path, ext in _walk_files(root, ignore_dirs, ignore_files, include_patterns, exclude_patterns, exclude_dirs):
        language = EXTENSION_TO_LANGUAGE.get(ext, Language.UNKNOWN)

        try:
            stat = os.stat(file_path_str)
            if stat.st_size > MAX_FILE_SIZE:
                continue
        except (OSError, PermissionError):
            continue

        # Fast path: mtime_ns match means file is unchanged — skip read + hash entirely.
        stored_entry = stored_files.get(rel_path)
        if stored_entry is not None and stat.st_mtime_ns == stored_entry[1]:
            current_files.add(rel_path)
            cache_hits += 1
            continue

        try:
            with open(file_path_str, "rb") as _f:
                source = _f.read()
        except (OSError, PermissionError):
            continue

        current_files.add(rel_path)
        line_count = source.count(b"\n") + (1 if source and not source.endswith(b"\n") else 0)
        file_hash = content_hash(source)
        file_mtime_ns = stat.st_mtime_ns

        if _is_parseable(language):
            # Reach here only when mtime changed; check hash to determine if content changed.
            if not db:
                cached = check_cache(cache, rel_path, source) if use_cache else None
                if cached:
                    cache_hits += 1
                    symbols = [_sym_from_dict(d) for d in cached["symbols"]]
                    edges = [_edge_from_dict(d) for d in cached["edges"]]
                    imports = cached["imports"]
                    new_cache[rel_path] = cached
                else:
                    symbols, edges, imports = _parse_file(rel_path, language, source, is_tauri)
                    if use_cache:
                        new_cache[rel_path] = make_cache_entry(
                            source,
                            [_sym_to_dict(s) for s in symbols],
                            [_edge_to_dict(e) for e in edges],
                            imports,
                        )
            elif stored_entry is not None and stored_entry[0] == file_hash:
                # Mtime changed but hash unchanged (e.g. `touch`): update mtime_ns only.
                db.update_file_mtime(rel_path, file_mtime_ns)
                cache_hits += 1
                symbols, edges, imports = [], [], []
            else:
                # New file or content changed — parse and store.
                symbols, edges, imports = _parse_file(rel_path, language, source, is_tauri)
                db.update_file(rel_path, file_hash, language.value, line_count,
                               len(source), symbols, edges, imports, mtime_ns=file_mtime_ns)

            # For DB path, skip per-file graph building — load_all() handles it
            if not db:
                file_info = FileInfo(
                    path=rel_path, language=language, line_count=line_count,
                    byte_size=len(source), symbols=[s.id for s in symbols], imports=imports,
                )
                for sym in symbols:
                    graph.symbols[sym.id] = sym
                graph.edges.extend(edges)
                graph.files[rel_path] = file_info
        else:
            if not db:
                file_info = FileInfo(
                    path=rel_path, language=language, line_count=line_count,
                    byte_size=len(source),
                )
                graph.files[rel_path] = file_info
            else:
                # Store non-parseable files in DB too (for file map/overview).
                # Reach here only when mtime changed; check hash to avoid re-storing.
                if stored_entry is not None and stored_entry[0] == file_hash:
                    db.update_file_mtime(rel_path, file_mtime_ns)
                else:
                    db.update_file(rel_path, file_hash, language.value, line_count,
                                   len(source), [], [], [], mtime_ns=file_mtime_ns)

    # Load entire graph from DB in one shot
    _edges_pre_resolved = False
    if db:
        db.remove_stale_files(current_files, db_files=set(stored_files.keys()))
        db.end_batch()
        files, symbols, edges, _edges_pre_resolved = db.load_all(lazy_edges=lazy_edges)
        graph.files = files
        graph.symbols = symbols
        graph.edges = edges
        graph._db = db  # type: ignore[attr-defined]  — kept open for hybrid search

    if use_cache and not use_db and new_cache:
        save_cache(root, new_cache)

    graph._cache_hits = cache_hits  # type: ignore[attr-defined]

    # Resolve import edges: match import statements to actual files
    # Resolve call edges: match target names to actual symbol IDs
    # Skip both when edges are pre-resolved (loaded from resolved_edges_blob) — saves ~14ms/build.
    if not lazy_edges:
        if _edges_pre_resolved:
            pass  # edges already include resolved IMPORTS + CALLS from previous build
        else:
            _resolve_imports(graph, root)
            _resolve_edges(graph)
            # Save resolved edges so next warm build can skip both resolution steps
            if db:
                # Store EdgeKind enum objects (not .value strings) so load_all() skips
                # per-edge get_edge_kind() dict lookup on the next warm build.
                edge_tuples = [
                    (e.kind, e.source_id, e.target_id, e.line)
                    for e in graph.edges
                ]
                db.save_resolved_edges_blob(edge_tuples, db._last_edge_count, db._last_sym_count)
    graph.build_indexes()

    # Temporal weighting: collect hot_files (background thread already running since before parse).
    # Source files only — test files and docs are excluded so that test symbols
    # don't outrank implementations for ambiguous queries.
    if _is_git:
        if _hot_future is not None:
            try:
                all_hot = _hot_future.result(timeout=5)
            except Exception:
                all_hot = set()
        else:
            all_hot = _get_hot_files(str(root))
        graph.hot_files = {f for f in all_hot if _is_hot_source_file(f)}

    # Store completed graph in process cache. Next call validates freshness via
    # _any_file_changed() before using this cached graph.
    if use_db and db is not None and not lazy_edges:
        exclude_key = tuple(sorted(exclude_dirs)) if exclude_dirs else ()
        process_cache_key = (str(root), exclude_key)
        with _TEMPO_CACHE_LOCK:
            _TEMPO_CACHE[process_cache_key] = graph

    return graph


def load_from_snapshot(repo_slug: str) -> Tempo:
    """Load a Tempo graph from a pre-built snapshot (no file parsing).

    The snapshot must have been downloaded first:
        python3 -m tempograph snapshot --repo <org/repo>

    Raises FileNotFoundError if the snapshot db does not exist.
    """
    from .snapshots import snapshot_path, snapshot_db_path

    db_path = snapshot_db_path(repo_slug)
    if not db_path.exists():
        snap_root = snapshot_path(repo_slug)
        raise FileNotFoundError(
            f"Snapshot not found: {db_path}\n"
            f"Run: python3 -m tempograph snapshot --repo {repo_slug}"
        )

    snap_root = snapshot_path(repo_slug)
    db = GraphDB(snap_root)
    graph = Tempo(root=str(snap_root))
    files, symbols, edges, _edges_pre_resolved = db.load_all()
    graph.files = files
    graph.symbols = symbols
    graph.edges = edges
    graph._db = db  # type: ignore[attr-defined]
    if not _edges_pre_resolved:
        _resolve_edges(graph)
    graph.build_indexes()
    return graph


def _parse_file(rel_path: str, language: Language, source: bytes, is_tauri: bool) -> tuple:
    """Parse a file with tree-sitter. Returns (symbols, edges, imports)."""
    try:
        parser = FileParser(rel_path, language, source, is_tauri=is_tauri)
        return parser.parse()
    except Exception:
        return [], [], []


# Path patterns that identify test and documentation files.
# These are excluded from the temporal bonus to prevent test symbols
# from outranking implementation symbols in search results.
_TEST_SEGMENTS = frozenset({"test", "tests", "__tests__", "spec", "specs", "__spec__"})
_TEST_PREFIXES = ("test_", "spec_")
_TEST_SUFFIXES = (
    "_test.py", "_spec.py",
    "_test.ts", "_spec.ts", ".spec.ts", ".test.ts",
    "_test.js", "_spec.js", ".spec.js", ".test.js",
    "_test.go", "_test.rb",
)
_DOC_EXTENSIONS = frozenset({".md", ".rst", ".txt", ".adoc"})


# Cache for _get_hot_files keyed on (repo_root, head_sha).
# Invalidated automatically when HEAD changes (new commit = new SHA = cache miss).
_hot_files_cache: dict[tuple[str, str], set[str]] = {}


def _get_head_sha(repo: str) -> str | None:
    """Read HEAD commit SHA via direct file read, subprocess fallback.

    Direct file read avoids ~16ms subprocess overhead (measures <1ms).
    Handles normal repos, worktrees, detached HEAD, and packed refs.
    """
    try:
        git_path = Path(repo) / ".git"
        if git_path.is_file():
            raw = git_path.read_text().strip()
            git_dir = (Path(repo) / raw[8:]).resolve() if raw.startswith("gitdir: ") else None
        elif git_path.is_dir():
            git_dir = git_path
        else:
            git_dir = None

        if git_dir:
            head_file = git_dir / "HEAD"
            if head_file.exists():
                head = head_file.read_text().strip()
                if not head.startswith("ref: "):
                    return head  # Detached HEAD
                ref = head[5:]
                ref_file = git_dir / ref
                if ref_file.exists():
                    return ref_file.read_text().strip()
                # Worktree: shared refs live in commondir
                commondir_file = git_dir / "commondir"
                if commondir_file.exists():
                    commondir = (git_dir / commondir_file.read_text().strip()).resolve()
                    ref_file = commondir / ref
                    if ref_file.exists():
                        return ref_file.read_text().strip()
    except (OSError, ValueError):
        pass
    # Subprocess fallback for edge cases (packed refs, unusual layouts)
    try:
        r = subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=repo,
            capture_output=True, text=True, timeout=5,
        )
        return r.stdout.strip() if r.returncode == 0 else None
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return None


def _get_hot_files(repo: str) -> set[str]:
    """Return candidate hot file paths for temporal weighting.

    Priority: working-tree changes (staged + unstaged) reflect what the developer
    is actively editing right now. If the working tree is clean, fall back to the
    last 2 commits so a freshly-committed session still gets a signal.

    Results are cached per (repo, HEAD SHA). Cache hit avoids ~20ms of git
    subprocess overhead. Invalidated automatically on new commits.
    """
    head_sha = _get_head_sha(repo)
    if head_sha:
        cache_key = (os.path.realpath(repo), head_sha)
        cached = _hot_files_cache.get(cache_key)
        if cached is not None:
            return cached

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
        fut_working = ex.submit(changed_files_vs_head, repo)
        fut_recent = ex.submit(recently_modified_files, repo, 2)
        working = set(fut_working.result())
        if working:
            result = working
        else:
            result = fut_recent.result()

    if head_sha:
        _hot_files_cache[cache_key] = result  # type: ignore[possibly-undefined]

    return result


def _is_hot_source_file(path: str) -> bool:
    """Return True if path is a source file eligible for temporal bonus.

    Excludes test files, spec files, and documentation files.
    """
    parts = path.replace("\\", "/").split("/")
    name = parts[-1] if parts else path
    # Exclude files inside test/spec directories
    if any(p.lower() in _TEST_SEGMENTS for p in parts[:-1]):
        return False
    # Exclude files whose name starts or ends with test/spec patterns
    nl = name.lower()
    if any(nl.startswith(p) for p in _TEST_PREFIXES):
        return False
    if any(nl.endswith(s) for s in _TEST_SUFFIXES):
        return False
    # Exclude documentation files by extension
    ext = "." + name.rsplit(".", 1)[-1] if "." in name else ""
    if ext.lower() in _DOC_EXTENSIONS:
        return False
    return True


def _sym_to_dict(sym: Symbol) -> dict:
    return {
        "id": sym.id, "name": sym.name, "qn": sym.qualified_name,
        "kind": sym.kind.value, "lang": sym.language.value,
        "fp": sym.file_path, "ls": sym.line_start, "le": sym.line_end,
        "sig": sym.signature, "doc": sym.doc, "pid": sym.parent_id,
        "exp": sym.exported, "cx": sym.complexity, "bs": sym.byte_size,
    }


def _sym_from_dict(d: dict) -> Symbol:
    return Symbol(
        id=d["id"], name=d["name"], qualified_name=d["qn"],
        kind=SymbolKind(d["kind"]), language=Language(d["lang"]),
        file_path=d["fp"], line_start=d["ls"], line_end=d["le"],
        signature=d.get("sig", ""), doc=d.get("doc", ""),
        parent_id=d.get("pid"), exported=d.get("exp", True),
        complexity=d.get("cx", 0), byte_size=d.get("bs", 0),
    )


def _edge_to_dict(e: Edge) -> dict:
    return {"k": e.kind.value, "s": e.source_id, "t": e.target_id, "l": e.line}


def _edge_from_dict(d: dict) -> Edge:
    return Edge(kind=EdgeKind(d["k"]), source_id=d["s"], target_id=d["t"], line=d.get("l", 0))


def _walk_files(
    root: Path,
    ignore_dirs: frozenset[str],
    ignore_files: frozenset[str],
    include_patterns: Sequence[str] | None,
    exclude_patterns: Sequence[str] | None,
    exclude_dirs: Sequence[str] | None = None,
):
    # Normalize exclude_dirs to path prefixes (strip trailing slashes)
    _exclude_prefixes = [p.rstrip("/") for p in (exclude_dirs or [])]

    # Precompute root string length once to avoid per-entry relative_to() calls
    root_str = str(root)
    root_len = len(root_str)

    for dirpath, dirnames, filenames in os.walk(root):
        # String-slice instead of Path.relative_to() — avoids ~45 Path objects per walk
        rel_dir = dirpath[root_len + 1:] if len(dirpath) > root_len else "."

        # Filter directories in-place — skip ignored names and excluded prefixes
        dirnames[:] = [
            d for d in dirnames
            if d not in ignore_dirs
            and not d.startswith(".")
            and not any(
                (rel_dir == "." and d == p) or
                (rel_dir + "/" + d == p) or
                (rel_dir + "/" + d).startswith(p + "/")
                for p in _exclude_prefixes
            )
        ]
        dirnames.sort()

        # Skip files inside excluded path prefixes
        if _exclude_prefixes and rel_dir != "." and any(
            rel_dir == p or rel_dir.startswith(p + "/") for p in _exclude_prefixes
        ):
            continue

        for filename in sorted(filenames):
            if filename in ignore_files or filename.startswith("."):
                continue
            ext = os.path.splitext(filename)[1].lower()
            if ext not in EXTENSION_TO_LANGUAGE:
                continue

            # Precompute rel_path using string ops — avoids Path.relative_to() per file
            rel = filename if rel_dir == "." else rel_dir + "/" + filename

            if include_patterns:
                if not any(fnmatch.fnmatch(rel, p) for p in include_patterns):
                    continue
            if exclude_patterns:
                if any(fnmatch.fnmatch(rel, p) for p in exclude_patterns):
                    continue

            # Yield string path + ext (already computed) — avoids Path object creation
            # and the subsequent pathlib property chains (.suffix, .stat, __fspath__, __str__).
            yield os.path.join(dirpath, filename), rel, ext


_RESOLVE_KINDS = frozenset([EdgeKind.CALLS, EdgeKind.RENDERS, EdgeKind.INHERITS, EdgeKind.IMPLEMENTS, EdgeKind.USES_TYPE])

_KNOWN_OOP_KINDS = frozenset(("class", "interface", "struct", "enum", "module", "trait"))


def _build_name_lookup(graph: Tempo) -> dict[str, list[str]]:
    """Build name→symbol-id lookup (both short name and qualified name)."""
    name_to_ids: dict[str, list[str]] = {}
    for sym in graph.symbols.values():
        name_to_ids.setdefault(sym.name, []).append(sym.id)
        if sym.qualified_name != sym.name:
            name_to_ids.setdefault(sym.qualified_name, []).append(sym.id)
    return name_to_ids


def _has_resolvable_edges(graph: Tempo, name_to_ids: dict[str, list[str]]) -> bool:
    """Return True if any edge has a resolvable symbolic target."""
    return any(
        e.kind in _RESOLVE_KINDS
        and "::" not in e.target_id
        and (name_to_ids.get(e.target_id) or ("." in e.target_id and name_to_ids.get(e.target_id.rsplit(".", 1)[-1])))
        for e in graph.edges
    )


def _build_file_scope(graph: Tempo) -> tuple[dict[str, set[str]], dict[str, set[str]]]:
    """Build file-level scope lookups for resolution.

    Returns:
        file_imports: file_path → set of imported file paths
        file_imported_names: file_path → set of explicitly imported symbol names
    """
    file_imports: dict[str, set[str]] = {}
    for edge in graph.edges:
        if edge.kind == EdgeKind.IMPORTS:
            file_imports.setdefault(edge.source_id, set()).add(edge.target_id)

    file_imported_names: dict[str, set[str]] = {}
    for fp, fi in graph.files.items():
        names: set[str] = set()
        for imp in fi.imports:
            if "import" not in imp:
                continue
            # Python: from x import a, b, c
            if "from" in imp and "import" in imp:
                after_import = imp.split("import", 1)[-1]
                for part in after_import.split(","):
                    name = part.strip().split(" as ")[0].strip().strip("{}")
                    if name and name != "*":
                        names.add(name)
            # JS: import { a, b } from 'x'
            elif "{" in imp:
                brace_content = imp.split("{", 1)[-1].split("}", 1)[0]
                for part in brace_content.split(","):
                    name = part.strip().split(" as ")[0].strip()
                    if name:
                        names.add(name)
        file_imported_names[fp] = names

    return file_imports, file_imported_names


def _build_inheritance_maps(
    graph: Tempo, name_to_ids: dict[str, list[str]]
) -> tuple[dict[str, list[str]], dict[str, list[str]]]:
    """Build parent/child class maps for mixin/inheritance resolution.

    Returns:
        children_of: class_id → list of child class ids
        parents_of: class_id → list of parent class ids
    """
    children_of: dict[str, list[str]] = {}
    parents_of: dict[str, list[str]] = {}
    for e in graph.edges:
        if e.kind.value == "inherits":
            child_id = e.source_id
            if "::" in e.target_id:
                parent_id = e.target_id
            else:
                parent_candidates = name_to_ids.get(e.target_id, [])
                parent_id = parent_candidates[0] if len(parent_candidates) == 1 else e.target_id
            parents_of.setdefault(child_id, []).append(parent_id)
            children_of.setdefault(parent_id, []).append(child_id)
    return children_of, parents_of


def _pick_best(
    source_id: str,
    candidates: list[str],
    graph: Tempo,
    file_imported_names: dict[str, set[str]],
    file_imports: dict[str, set[str]],
) -> str:
    """Pick the best candidate symbol using scope priority: same-file > imported-name > imported-file > exported > first."""
    if len(candidates) == 1:
        return candidates[0]
    source_file = source_id.split("::")[0]
    same_file = [c for c in candidates if c.startswith(source_file + "::")]
    if same_file:
        return same_file[0]
    imported_names = file_imported_names.get(source_file, set())
    if imported_names:
        for c in candidates:
            sym = graph.symbols.get(c)
            if sym and sym.name in imported_names:
                c_file = c.split("::")[0]
                if c_file in file_imports.get(source_file, set()):
                    return c
        for c in candidates:
            sym = graph.symbols.get(c)
            if sym and sym.name in imported_names:
                return c
    imported_files = file_imports.get(source_file, set())
    if imported_files:
        for c in candidates:
            if c.split("::")[0] in imported_files:
                return c
    for c in candidates:
        sym = graph.symbols.get(c)
        if sym and sym.exported:
            return c
    return candidates[0]


def _search_parent_classes(
    bare: str,
    source_class_id: str,
    parents_of: dict[str, list[str]],
    name_to_ids: dict[str, list[str]],
    graph: Tempo,
) -> list[str]:
    """Search parent classes for a method named `bare`."""
    for parent_id in parents_of.get(source_class_id, []):
        pname = parent_id.split("::")[-1] if "::" in parent_id else parent_id
        pfile = parent_id.split("::")[0] if "::" in parent_id else ""
        pq = f"{pfile}::{pname}.{bare}" if pfile else f"{pname}.{bare}"
        if pq in graph.symbols:
            return [pq]
        pq2 = f"{pname}.{bare}"
        if pq2 in name_to_ids:
            return name_to_ids[pq2]
    return []


def _search_child_classes(
    bare: str,
    source_class_id: str,
    children_of: dict[str, list[str]],
    name_to_ids: dict[str, list[str]],
    graph: Tempo,
) -> list[str]:
    """Search child classes for a method named `bare` (mixin pattern)."""
    for child_id in children_of.get(source_class_id, []):
        cname = child_id.split("::")[-1] if "::" in child_id else child_id
        cfile = child_id.split("::")[0] if "::" in child_id else ""
        cq = f"{cfile}::{cname}.{bare}" if cfile else f"{cname}.{bare}"
        if cq in graph.symbols:
            return [cq]
        cq2 = f"{cname}.{bare}"
        if cq2 in name_to_ids:
            return name_to_ids[cq2]
    return []


def _search_sibling_classes(
    bare: str,
    source_class_id: str,
    parents_of: dict[str, list[str]],
    children_of: dict[str, list[str]],
    name_to_ids: dict[str, list[str]],
    graph: Tempo,
) -> list[str]:
    """Search sibling classes (mixin composition: MixinA + MixinB → FileParser)."""
    siblings: set[str] = set()
    for child_id in children_of.get(source_class_id, []):
        for sib_id in parents_of.get(child_id, []):
            if sib_id != source_class_id:
                siblings.add(sib_id)
    for sib_id in siblings:
        sname = sib_id.split("::")[-1] if "::" in sib_id else sib_id
        sfile = sib_id.split("::")[0] if "::" in sib_id else ""
        sq = f"{sfile}::{sname}.{bare}" if sfile else f"{sname}.{bare}"
        if sq in graph.symbols:
            return [sq]
        sq2 = f"{sname}.{bare}"
        if sq2 in name_to_ids:
            return name_to_ids[sq2]
    return []


def _resolve_self_method_candidates(
    source_id: str,
    bare: str,
    name_to_ids: dict[str, list[str]],
    parents_of: dict[str, list[str]],
    children_of: dict[str, list[str]],
    graph: Tempo,
) -> list[str]:
    """Resolve self.method / cls.method call targets via class hierarchy.

    Tries in order: exact same-class match, class-qualified name, parent classes,
    child classes (mixin pattern), sibling classes (mixin composition), bare-name same-file.
    """
    source_parts = source_id.split("::")
    if len(source_parts) != 2 or "." not in source_parts[1]:
        return []

    class_name = source_parts[1].split(".")[0]
    source_file = source_parts[0]
    source_class_id = f"{source_file}::{class_name}"

    # 1. Exact match: same file, same class
    qualified_target = f"{source_class_id}.{bare}"
    if qualified_target in graph.symbols:
        return [qualified_target]

    # 2. Class-qualified name across all files
    candidates = name_to_ids.get(f"{class_name}.{bare}", [])
    if candidates:
        return candidates

    # 3–5. Hierarchy search: parents → children → siblings
    candidates = _search_parent_classes(bare, source_class_id, parents_of, name_to_ids, graph)
    if candidates:
        return candidates
    candidates = _search_child_classes(bare, source_class_id, children_of, name_to_ids, graph)
    if candidates:
        return candidates
    candidates = _search_sibling_classes(bare, source_class_id, parents_of, children_of, name_to_ids, graph)
    if candidates:
        return candidates

    # 6. Last resort: bare name in same file
    return [cid for cid in name_to_ids.get(bare, []) if cid.startswith(source_file + "::")]


def _resolve_edges(graph: Tempo) -> None:
    """Resolve symbolic call targets to actual symbol IDs where possible.
    Uses scope-aware resolution: same file > imported file > exported symbol > any."""
    name_to_ids = _build_name_lookup(graph)

    if not _has_resolvable_edges(graph, name_to_ids):
        return

    file_imports, file_imported_names = _build_file_scope(graph)
    children_of, parents_of = _build_inheritance_maps(graph, name_to_ids)

    resolved: list[Edge] = []
    for edge in graph.edges:
        if edge.kind not in _RESOLVE_KINDS or "::" in edge.target_id:
            resolved.append(edge)
            continue

        candidates = name_to_ids.get(edge.target_id, [])

        # self.method() / cls.method() resolution via class hierarchy
        if not candidates and "." in edge.target_id:
            qualifier, bare = edge.target_id.rsplit(".", 1)
            if qualifier in ("self", "cls"):
                candidates = _resolve_self_method_candidates(
                    edge.source_id, bare, name_to_ids, parents_of, children_of, graph
                )
                if candidates:
                    target = _pick_best(edge.source_id, candidates, graph, file_imported_names, file_imports)
                    resolved.append(Edge(edge.kind, edge.source_id, target, edge.line))
                    continue

        # Type.method fallback: only when qualifier is a known class/module in the graph
        if not candidates and "." in edge.target_id:
            qualifier, bare = edge.target_id.rsplit(".", 1)
            if any(
                graph.symbols.get(cid) is not None
                and graph.symbols[cid].kind.value in _KNOWN_OOP_KINDS
                for cid in name_to_ids.get(qualifier, [])
            ):
                candidates = name_to_ids.get(bare, [])

        if candidates:
            resolved.append(Edge(edge.kind, edge.source_id, _pick_best(edge.source_id, candidates, graph, file_imported_names, file_imports), edge.line))
        else:
            resolved.append(edge)

    graph.edges = resolved


def _resolve_imports(graph: Tempo, root: Path) -> None:
    """Create IMPORTS edges by resolving import paths to actual files."""
    import re

    # Build a lookup of file stems and paths
    path_lookup: dict[str, str] = {}  # stem → rel_path
    for fp in graph.files:
        stem = fp.rsplit("/", 1)[-1].rsplit(".", 1)[0]  # "Canvas" from "src/components/Canvas.tsx"
        path_lookup[stem] = fp
        path_lookup[fp] = fp

    # Patterns for extracting import targets
    js_from_re = re.compile(r"""from\s+['"]([^'"]+)['"]""")
    py_from_re = re.compile(r"""from\s+(\S+)\s+import\s+(.+)""")
    py_names_re = re.compile(r"""from\s+\S+\s+import\s+(.+)""")
    rust_use_re = re.compile(r"""use\s+(?:crate::)?(\S+)""")

    for fp, fi in graph.files.items():
        for imp_str in fi.imports:
            targets: list[str] = []

            # JS/TS: from './foo' or from '../lib/bar'
            m = js_from_re.search(imp_str)
            if m:
                raw = m.group(1)
                # Resolve relative path
                if raw.startswith("."):
                    base_dir = fp.rsplit("/", 1)[0] if "/" in fp else "."
                    parts = raw.split("/")
                    resolved_parts = base_dir.split("/")
                    for part in parts:
                        if part == ".":
                            continue
                        elif part == "..":
                            if resolved_parts:
                                resolved_parts.pop()
                        else:
                            resolved_parts.append(part)
                    candidate_base = "/".join(resolved_parts)
                    # Try with extensions
                    for ext in ("", ".ts", ".tsx", ".js", ".jsx", "/index.ts", "/index.tsx", "/index.js"):
                        candidate = candidate_base + ext
                        if candidate in graph.files:
                            targets.append(candidate)
                            break
                else:
                    # Package import — try to match by last segment
                    stem = raw.rsplit("/", 1)[-1]
                    if stem in path_lookup:
                        targets.append(path_lookup[stem])

            # Python: from foo.bar import baz, Qux  (absolute and relative)
            py_imported_names: list[str] = []
            if not targets:
                m = py_from_re.search(imp_str)
                if m:
                    raw_mod = m.group(1)
                    # Count leading dots for relative imports
                    dots = len(raw_mod) - len(raw_mod.lstrip("."))
                    if dots:
                        # Relative: resolve against current file's directory
                        file_parts = fp.split("/")[:-1]  # strip filename
                        for _ in range(dots - 1):  # one dot = same dir, two dots = parent
                            if file_parts:
                                file_parts.pop()
                        suffix = raw_mod[dots:].replace(".", "/")  # e.g. "types"
                        mod = "/".join(file_parts + [suffix]) if suffix else "/".join(file_parts)
                    else:
                        mod = raw_mod.replace(".", "/")
                    for ext in (".py", "/__init__.py"):
                        candidate = mod + ext
                        if candidate in graph.files:
                            targets.append(candidate)
                            # Extract named imports for symbol-level edges
                            names_str = m.group(2).strip().strip("()")
                            py_imported_names = [
                                n.strip().split(" as ")[0].strip()
                                for n in names_str.split(",")
                                if n.strip() and not n.strip().startswith("#")
                            ]
                            break

            # Rust: use crate::foo::bar — try multiple source directories
            if not targets:
                m = rust_use_re.search(imp_str)
                if m:
                    raw_mod = m.group(1).rstrip(";")
                    parts = raw_mod.split("::")
                    # Try resolving progressively: first module, then deeper
                    # Also try src-tauri/src/ for Tauri projects
                    source_dirs = ["src"]
                    # Detect if file is in src-tauri/
                    if fp.startswith("src-tauri/"):
                        source_dirs = ["src-tauri/src"]
                    for src_dir in source_dirs:
                        for depth in range(len(parts), 0, -1):
                            mod_path = "/".join(parts[:depth])
                            for candidate in (
                                f"{src_dir}/{mod_path}.rs",
                                f"{src_dir}/{mod_path}/mod.rs",
                            ):
                                if candidate in graph.files:
                                    targets.append(candidate)
                                    break
                            if targets:
                                break
                        if targets:
                            break

            for target in targets:
                graph.edges.append(Edge(EdgeKind.IMPORTS, fp, target))
                # Create symbol-level CALLS edges for named Python imports
                # This prevents false-positive dead code flags for exported names
                for name in py_imported_names:
                    sym_id = f"{target}::{name}"
                    if sym_id in graph.symbols:
                        graph.edges.append(Edge(EdgeKind.CALLS, fp, sym_id))
