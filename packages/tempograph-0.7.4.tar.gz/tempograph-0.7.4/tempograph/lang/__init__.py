"""Language-specific handler mixins for FileParser."""

from .python_handler import PythonHandlerMixin
from .js_handler import JSHandlerMixin
from .go_handler import GoHandlerMixin
from .java_handler import JavaHandlerMixin
from .csharp_handler import CsharpHandlerMixin
from .ruby_handler import RubyHandlerMixin
from .zig_handler import ZigHandlerMixin
from .c_handler import CHandlerMixin
from .rust_handler import RustHandlerMixin
from .swift_handler import SwiftHandlerMixin
from .php_handler import PHPHandlerMixin
from .kotlin_handler import KotlinHandlerMixin
from .dart_handler import DartHandlerMixin
from .elixir_handler import ElixirHandlerMixin
from .scala_handler import ScalaHandlerMixin
from .ocaml_handler import OCamlHandlerMixin
from .fsharp_handler import FSharpHandlerMixin
from .haskell_handler import HaskellHandlerMixin
from .lua_handler import LuaHandlerMixin
from .clojure_handler import ClojureHandlerMixin
from .erlang_handler import ErlangHandlerMixin
from .r_handler import RHandlerMixin
from .julia_handler import JuliaHandlerMixin
from .bash_handler import BashHandlerMixin

__all__ = [
    "PythonHandlerMixin",
    "JSHandlerMixin",
    "GoHandlerMixin",
    "JavaHandlerMixin",
    "CsharpHandlerMixin",
    "RubyHandlerMixin",
    "ZigHandlerMixin",
    "CHandlerMixin",
    "RustHandlerMixin",
    "SwiftHandlerMixin",
    "PHPHandlerMixin",
    "KotlinHandlerMixin",
    "DartHandlerMixin",
    "ElixirHandlerMixin",
    "ScalaHandlerMixin",
    "OCamlHandlerMixin",
    "FSharpHandlerMixin",
    "HaskellHandlerMixin",
    "LuaHandlerMixin",
    "ClojureHandlerMixin",
    "ErlangHandlerMixin",
    "RHandlerMixin",
    "JuliaHandlerMixin",
    "BashHandlerMixin",
]
