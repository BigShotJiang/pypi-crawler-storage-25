"""Learning engine — L1 per-task feedback loop.

Tracks what context was provided for each task and whether the task
succeeded. Over time, learns which context strategies work best for
different task types in this codebase.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

PLUGIN = {
    "name": "learn",
    "depends": ["context", "tokens"],
    "provides": ["learn", "insights"],
    "default": True,
    "description": "Per-task learning — adapts context strategy based on outcomes",
}


class TaskMemory:
    """Persistent per-codebase learning from task outcomes."""

    def __init__(self, repo_path: str):
        self._dir = Path(repo_path) / ".tempo" / "learn"
        self._dir.mkdir(parents=True, exist_ok=True)
        self._log = self._dir / "tasks.jsonl"
        self._insights = self._dir / "insights.json"

    def _load_tasks(self) -> list[dict]:
        if not self._log.exists():
            return []
        tasks = []
        for line in self._log.read_text().splitlines():
            if line.strip():
                try:
                    tasks.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return tasks

    def _update_insights(self) -> None:
        """Recompute insights from all task data."""
        tasks = self._load_tasks()
        if len(tasks) < 5:
            return

        insights = {}

        # Best context strategy per task type
        by_type: dict[str, list[dict]] = {}
        for t in tasks:
            tt = t.get("task_type", "unknown")
            if tt not in by_type:
                by_type[tt] = []
            by_type[tt].append(t)

        for tt, type_tasks in by_type.items():
            successes = [t for t in type_tasks if t.get("success")]
            if not successes:
                continue
            # Find most common context mode combo in successful tasks
            mode_counts: dict[str, int] = {}
            for t in successes:
                key = ",".join(sorted(m for m in t.get("context_modes", []) if m))
                mode_counts[key] = mode_counts.get(key, 0) + 1
            best = max(mode_counts, key=mode_counts.get)
            avg_tokens = sum(t["tokens_used"] for t in successes) // len(successes)
            insights[tt] = {
                "best_modes": best.split(","),
                "avg_tokens": avg_tokens,
                "success_rate": len(successes) / len(type_tasks),
                "sample_size": len(type_tasks),
            }

        with open(self._insights, "w") as f:
            json.dump(insights, f, indent=2)

    def get_recommendation(self, task_type: str) -> dict | None:
        """Get recommended context strategy for a task type."""
        if not self._insights.exists():
            return None
        try:
            insights = json.loads(self._insights.read_text())
            return insights.get(task_type)
        except (json.JSONDecodeError, OSError):
            return None

    def summary(self) -> str:
        tasks = self._load_tasks()
        if not tasks:
            return "No task data yet. Use tempo to build learning data."

        total = len(tasks)
        successes = sum(1 for t in tasks if t.get("success"))
        total_tokens = sum(t.get("tokens_used", 0) for t in tasks)

        lines = [
            f"Learning Engine: {total} tasks recorded",
            f"  Success rate: {successes}/{total} ({successes/total:.0%})",
            f"  Total tokens: {total_tokens:,}",
            "",
        ]

        if self._insights.exists():
            try:
                insights = json.loads(self._insights.read_text())
                lines.append("Learned strategies:")
                for tt, info in insights.items():
                    lines.append(
                        f"  {tt}: use [{', '.join(info['best_modes'])}] "
                        f"(~{info['avg_tokens']:,} tok, {info['success_rate']:.0%} success, n={info['sample_size']})"
                    )
            except (json.JSONDecodeError, OSError):
                pass

        return "\n".join(lines)


_MODE_TO_TASK_TYPE = {
    "focus": "code_navigation",
    "blast": "code_navigation",
    "lookup": "code_navigation",
    "symbols": "code_navigation",
    "map": "orientation",
    "dead": "cleanup",
    "hotspots": "refactor",
    "diff": "code_review",
    "overview": "orientation",
    "arch": "architecture",
    "deps": "dependency_audit",
    "context": "task_preparation",
    "quality": "output_review",
    "learn": "learning",
    "skills": "patterns",
}

# MCP tool names → canonical mode names (MCP logs "tool", CLI logs "mode")
_MCP_TOOL_TO_MODE = {
    "overview": "overview",
    "focus": "focus",
    "lookup": "lookup",
    "blast_radius": "blast",
    "hotspots": "hotspots",
    "diff_context": "diff",
    "dead_code": "dead",
    "symbols": "symbols",
    "file_map": "map",
    "dependencies": "deps",
    "architecture": "arch",
    "prepare_context": "context",
    "learn_recommendation": "learn",
    "get_patterns": "skills",
}
# Tools to skip when extracting context modes (infrastructure, not navigation)
_SKIP_TOOLS = {"index_repo", "stats", "report_feedback"}


def _entry_mode(entry: dict) -> str | None:
    """Return canonical mode name from a usage entry (works for CLI and MCP sources)."""
    m = entry.get("mode")
    if m:
        return m
    tool = entry.get("tool")
    if not tool or tool in _SKIP_TOOLS:
        return None
    return _MCP_TOOL_TO_MODE.get(tool, tool)


def infer_from_telemetry(repo_path: str) -> int:
    """Infer task outcomes from usage + feedback telemetry. Returns count of new records."""
    import hashlib
    from datetime import datetime, timezone
    from pathlib import Path

    usage_path = Path(repo_path) / ".tempograph" / "usage.jsonl"
    feedback_path = Path(repo_path) / ".tempograph" / "feedback.jsonl"

    if not usage_path.exists():
        return 0

    usage_lines = [json.loads(l) for l in usage_path.read_text().splitlines() if l.strip()]
    feedback_lines = []
    if feedback_path.exists():
        feedback_lines = [json.loads(l) for l in feedback_path.read_text().splitlines() if l.strip()]

    # Group usage into sessions (gap > 20 min = new session)
    sessions: list[list[dict]] = []
    current: list[dict] = []
    prev_ts = None
    for entry in sorted(usage_lines, key=lambda x: x.get("ts", "")):
        ts_str = entry.get("ts", "")
        if not ts_str:
            continue
        try:
            ts = datetime.fromisoformat(ts_str)
        except ValueError:
            continue
        if prev_ts and (ts - prev_ts).total_seconds() > 1200:  # 20 min gap
            if current:
                sessions.append(current)
                current = []
        current.append(entry)
        prev_ts = ts
    if current:
        sessions.append(current)

    # Build feedback lookup by timestamp proximity
    def find_feedback(session_end_ts, window_secs=3600):
        results = []
        for fb in feedback_lines:
            try:
                fb_ts = datetime.fromisoformat(fb.get("ts", ""))
                delta = abs((fb_ts - session_end_ts).total_seconds())
                if delta <= window_secs:
                    results.append(fb)
            except (ValueError, TypeError):
                pass
        return results

    mem = TaskMemory(repo_path)
    existing_tasks = mem._load_tasks()

    # Hash existing sessions to avoid duplicates
    def session_hash(session):
        key = "|".join(sorted(e.get("ts", "") for e in session))
        return hashlib.md5(key.encode()).hexdigest()[:8]

    existing_hashes = {t.get("session_hash") for t in existing_tasks if t.get("session_hash")}

    new_count = 0
    for session in sessions:
        sh = session_hash(session)
        if sh in existing_hashes:
            continue

        # Skip sessions that look like automated testing (too many calls too fast)
        if len(session) > 30:
            # If >30 calls in a 20-minute window, likely a test/audit run
            continue

        modes = [m for e in session for m in [_entry_mode(e)] if m and m not in ("stats", "report")]
        if not modes:
            continue

        total_tokens = sum(e.get("tokens", 0) for e in session)
        empty_count = sum(1 for e in session if e.get("empty"))

        # Prefer explicit --task-type labels; fall back to mode inference
        explicit_labels = [
            e["task_type"] for e in session
            if e.get("task_type") and e["task_type"] not in (None, "null", "unknown")
        ]
        if explicit_labels:
            task_type = max(set(explicit_labels), key=explicit_labels.count)
        else:
            mode_weights: dict[str, int] = {}
            for m in modes:
                tt = _MODE_TO_TASK_TYPE.get(m)
                if tt:
                    mode_weights[tt] = mode_weights.get(tt, 0) + 1
            task_type = max(mode_weights, key=mode_weights.get) if mode_weights else "general"

        # Determine success: prefer explicit feedback, fall back to heuristic
        last_ts_str = session[-1].get("ts", "")
        try:
            last_ts = datetime.fromisoformat(last_ts_str)
        except ValueError:
            last_ts = datetime.now(timezone.utc)

        feedbacks = find_feedback(last_ts)
        if feedbacks:
            success = any(f.get("helpful") is True for f in feedbacks)
        else:
            # Heuristic: success if < 50% empty results
            success = empty_count < len(session) * 0.5

        entry = {
            "ts": time.time(),
            "task_type": task_type,
            "context_modes": list(dict.fromkeys(modes)),
            "tokens_used": total_tokens,
            "success": success,
            "notes": f"inferred from {len(session)} usage events; task_type={'explicit' if explicit_labels else 'mode-inferred'}",
            "session_hash": sh,
        }
        with open(mem._log, "a") as f:
            f.write(json.dumps(entry) + "\n")
        new_count += 1

    if new_count > 0:
        mem._update_insights()

    return new_count


_L3_MIN_SESSIONS = 10
_L3_STALE_DAYS = 7
_L3_INSIGHTS_PATH = Path.home() / ".tempograph" / "global" / "l3_insights.json"
_L3_GLOBAL_DIR = Path.home() / ".tempograph" / "global"

_TEST_PATH_PATTERNS = ("pytest-of-", "/tmp/", "/T/pytest-", "test_telemetry_", "pytest-")


def _is_test_repo(path: str) -> bool:
    """Return True if the path looks like a pytest temp or test-generated directory."""
    return any(pat in path for pat in _TEST_PATH_PATTERNS)


def analyze_cross_repo_patterns() -> str:
    """L3: Identify universal improvement patterns across all repos.

    Reads global telemetry and extracts patterns that hold regardless of
    specific codebase. Requires at least _L3_MIN_SESSIONS sessions to produce
    meaningful output. Writes findings to ~/.tempograph/global/l3_insights.json.
    """
    from datetime import datetime, timezone

    usage_path = _L3_GLOBAL_DIR / "usage.jsonl"
    feedback_path = _L3_GLOBAL_DIR / "feedback.jsonl"

    if not usage_path.exists():
        return "L3: No global telemetry found. Use tempo on more repos to build data."

    skip_modes = {"stats", "report", "plugins", "serve"}
    _skip_tools_l3 = _SKIP_TOOLS | {"plugins", "serve"}
    usage_lines = [
        e for e in (json.loads(l) for l in usage_path.read_text().splitlines() if l.strip())
        if e.get("mode") not in skip_modes
        and e.get("tool") not in _skip_tools_l3
        and not _is_test_repo(e.get("repo_path", e.get("repo", "")))
    ]

    feedback_lines: list[dict] = []
    if feedback_path.exists():
        feedback_lines = [json.loads(l) for l in feedback_path.read_text().splitlines() if l.strip()]

    # Group into sessions per repo (20-min gap = new session)
    def to_sessions(entries: list[dict]) -> list[list[dict]]:
        sessions: list[list[dict]] = []
        current: list[dict] = []
        prev_ts = None
        for e in sorted(entries, key=lambda x: x.get("ts", "")):
            try:
                ts = datetime.fromisoformat(e["ts"])
            except (ValueError, KeyError):
                continue
            if prev_ts and (ts - prev_ts).total_seconds() > 1200:
                if current:
                    sessions.append(current)
                    current = []
            current.append(e)
            prev_ts = ts
        if current:
            sessions.append(current)
        return sessions

    sessions = to_sessions(usage_lines)
    total_sessions = len(sessions)

    if total_sessions < _L3_MIN_SESSIONS:
        remaining = _L3_MIN_SESSIONS - total_sessions
        return (
            f"L3: Insufficient data — {total_sessions}/{_L3_MIN_SESSIONS} sessions.\n"
            f"Need {remaining} more sessions across any repo. L3 auto-runs when threshold is met."
        )

    # Per-mode success rates from direct feedback (feedback has mode + helpful fields).
    # This is more accurate than session-level heuristics because each feedback
    # entry explicitly names which mode it rated.
    fb_by_mode: dict[str, dict] = {}
    for fb in feedback_lines:
        m = fb.get("mode")
        if not m or _is_test_repo(fb.get("repo_path", "")):
            continue
        if m not in fb_by_mode:
            fb_by_mode[m] = {"success": 0, "total": 0}
        fb_by_mode[m]["total"] += 1
        if fb.get("helpful") is True:
            fb_by_mode[m]["success"] += 1

    # Per-mode token averages from usage (feedback doesn't include token counts)
    mode_tokens: dict[str, dict] = {}
    repo_counts: dict[str, int] = {}

    for session in sessions:
        repo = session[0].get("repo_path", session[0].get("repo", "unknown"))
        repo_counts[repo] = repo_counts.get(repo, 0) + 1
        for e in session:
            m = _entry_mode(e)
            if not m:
                continue
            if m not in mode_tokens:
                mode_tokens[m] = {"tokens_total": 0, "tokens_count": 0}
            t = e.get("tokens", 0)
            if t:
                mode_tokens[m]["tokens_total"] += t
                mode_tokens[m]["tokens_count"] += 1

    # Merge per-mode feedback with token averages
    mode_rates: list[dict] = []
    all_modes = set(fb_by_mode) | set(mode_tokens)
    for m in all_modes:
        fb = fb_by_mode.get(m, {})
        tok = mode_tokens.get(m, {})
        if fb.get("total", 0) < 3:  # need at least 3 feedback entries
            continue
        rate = fb["success"] / fb["total"]
        avg_tokens = tok["tokens_total"] // tok["tokens_count"] if tok.get("tokens_count") else 0
        mode_rates.append({
            "mode": m,
            "success_rate": rate,
            "uses": fb["total"],
            "avg_tokens": avg_tokens,
        })
    mode_rates.sort(key=lambda x: -x["success_rate"])

    # Top repos by usage
    top_repos = sorted(repo_counts.items(), key=lambda x: -x[1])[:5]

    insights = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "sessions_analyzed": total_sessions,
        "repos_seen": len(repo_counts),
        "top_repos": [{"repo": r, "sessions": c} for r, c in top_repos],
        "mode_effectiveness": mode_rates,
    }

    _L3_INSIGHTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    _L3_INSIGHTS_PATH.write_text(json.dumps(insights, indent=2))

    lines = [
        f"L3 Cross-Repo Analysis — {total_sessions} sessions, {len(repo_counts)} repos",
        "",
        "Mode effectiveness (success rate, min 3 uses):",
    ]
    for r in mode_rates:
        lines.append(f"  {r['mode']:20s}  {r['success_rate']*100:.0f}%  ({r['uses']} uses, avg {r['avg_tokens']:,} tokens)")

    lines += ["", "Top repos by usage:"]
    for repo, count in top_repos:
        lines.append(f"  {count:3d} sessions  {repo}")

    lines.append(f"\nInsights written to {_L3_INSIGHTS_PATH}")
    lines.append(f"Freshness: just generated — valid for {_L3_STALE_DAYS} days")
    return "\n".join(lines)


def run(graph, **kwargs) -> str:
    query = (kwargs.get("query") or "").strip().lower()
    if query == "l3":
        return analyze_cross_repo_patterns()

    mem = TaskMemory(graph.root)
    new = infer_from_telemetry(graph.root)
    suffix = f"\n\n[Auto-inferred {new} new sessions from telemetry]" if new else ""

    if query and query != "summary":
        rec = mem.get_recommendation(query)
        if rec:
            modes = ", ".join(rec["best_modes"])
            return (
                f"Recommendation for '{query}':\n"
                f"  Use modes: [{modes}]\n"
                f"  Avg tokens: ~{rec['avg_tokens']:,}\n"
                f"  Success rate: {rec['success_rate']:.0%} (n={rec['sample_size']})"
                + suffix
            )
        return f"No learned strategy for '{query}' yet. Known types: {_list_known_types(mem)}" + suffix

    return mem.summary() + suffix


def _list_known_types(mem: "TaskMemory") -> str:
    if not mem._insights.exists():
        return "none"
    try:
        return ", ".join(json.loads(mem._insights.read_text()).keys()) or "none"
    except (json.JSONDecodeError, OSError):
        return "none"
