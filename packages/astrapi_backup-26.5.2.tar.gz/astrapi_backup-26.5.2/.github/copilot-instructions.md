# astrapi-backup – Projektkontext für GitHub Copilot

Wird im Repo versioniert und von VS Code Copilot automatisch geladen.

---

## Was ist astrapi-backup?

Web-UI zur zentralen Verwaltung von Backup-Jobs (Borg, Rsync, Proxmox, Remote-Geräte).
Basiert auf **astrapi-core** (FastAPI + Flask + HTMX + Jinja2).
PyPI-Paketname: `astrapi-backup`, Python-Paket: `astrapi_backup`.

---

## Stack

| Komponente | Details |
|---|---|
| Framework | astrapi-core (FastAPI + HTMX) |
| API | FastAPI (`/api/...`) |
| UI | FastAPI + HTMX + Jinja2 (`/`) – kein Flask mehr! |
| Persistenz | SQLite (über astrapi-core) |
| Verschlüsselung | Fernet (Secrets via astrapi-core) |
| Python | ≥ 3.11 |

---

## Verzeichnisstruktur

```
astrapi_backup/
├── _app.py              # ASGI-App-Factory (uvicorn-Einstiegspunkt)
├── _cli.py              # Console-Script: astrapi-backup
├── _paths.py            # package_dir(), work_dir(), db_path(), log_dir()
├── app.yaml             # name: astrapi-backup, display_name: Backup Control
├── navigation.yaml      # App-Navigation (Borg, Rsync, Proxmox, Remotes)
├── runner.py            # Job-Dispatcher
├── api/
│   ├── fastapi_app.py   # FastAPI-Factory, Run-Router-Registrierung
│   ├── storage.py       # SQLite-Tabellen (borg, rsync, proxmox_*, remotes)
│   ├── templates.py     # Jinja2-ChoiceLoader
│   └── routers/
│       └── run.py       # Generischer Run/Log/SSE-Router pro Modul
├── modules/
│   ├── borg/            # Borg-Backup-Modul
│   ├── rsync/           # Rsync-Modul
│   ├── proxmox_lxc/     # Proxmox LXC-Container
│   ├── proxmox_hosts/   # Proxmox-Host-Backups
│   ├── proxmox_jobs/    # Proxmox-Job-Verwaltung
│   └── remotes/         # Remote-Geräte (WoL, SSH)
└── overrides/
    └── sysinfo.py       # App-spezifische Sysinfo-Konfiguration
```

---

## App-Start

```
astrapi-backup --work-dir /opt/astrapi-backup --port 5001
```

- `_configure_paths("astrapi-backup")` setzt Runtime-Pfade
- `configure_updater(_pkg)` registriert `astrapi-backup` + `astrapi-core` im Updater
- Secrets-Key: `/var/lib/backupadm/secret.key` (Prod), `astrapi_backup/secret.key` (Dev)

---

## Template-Struktur (Modul-Konvention)

```
templates/
├── content.html              # Vollständiger Modul-Inhalt (page-header + Listenbereich)
├── partials/
│   ├── card_body.html        # Card-Body-Snippet für list_wrapper_inner (content_template)
│   ├── list_header.html      # Tabellen-Header-Spalten
│   ├── list_row.html         # Tabellen-Zeilen-Spalten
│   └── ...                   # Weitere kleine HTMX-Fragmente
└── modals/
    ├── edit.html             # Create/Edit-Dialog (falls modul-spezifisch)
    ├── create.html           # Nur-Create-Dialog (z.B. proxmox_lxc, proxmox_jobs)
    ├── log.html              # Log-Viewer
    └── ...                   # Weitere modul-spezifische Dialoge
```

---

## Modul-Konvention (Run-Module)

Run-Module (borg, rsync, proxmox_lxc, proxmox_hosts, proxmox_jobs) haben zusätzlich:

| Datei | Inhalt |
|---|---|
| `jobs.py` | `run_single(item_id)` – wird von `run.py` aufgerufen |
| `api.py` | Zusätzliche FastAPI-Endpunkte (preview, archives, stats, …) |

Run-Router: `POST /api/{module}/{item_id}/run`, `GET /api/{module}/{item_id}/logs`

---

## Datenbank

Tabellen in `astrapi_backup/api/storage.py`: `borg`, `rsync`, `proxmox_lxc`, `proxmox_hosts`, `proxmox_jobs`, `remotes`.
YAML-Migration beim ersten Zugriff automatisch.

---

## Versionsschema

CalVer: `YY.MM.patch.devN` – gesteuert via setuptools-scm + Git-Tags.

---

## Tests

```
pytest tests/unit/
```

- `conftest.py`: frische SQLite-DB je Test, isolierter Scheduler
- `test_template_resolution.py`: prüft alle `TemplateResponse`-Referenzen auf Auflösbarkeit
