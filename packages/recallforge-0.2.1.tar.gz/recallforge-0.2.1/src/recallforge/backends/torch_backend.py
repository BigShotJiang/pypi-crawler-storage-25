"""
torch_backend.py - PyTorch Backend for RecallForge.

Uses transformers + torch for model inference.
Device selection: CUDA > MPS > CPU.

Model IDs:
- Embedder: Qwen/Qwen3-VL-Embedding-2B
- Reranker: Qwen/Qwen3-VL-Reranker-2B
"""

import os
import re
import sys
import warnings
import logging
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from packaging.version import Version, InvalidVersion

import numpy as np

from .base import ModelBackend, BackendInfo

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# HuggingFace cache helpers
# ---------------------------------------------------------------------------

def _check_model_cached(repo_id: str) -> bool:
    """Return True if *repo_id* already exists in the local HuggingFace cache."""
    try:
        from huggingface_hub import try_to_load_from_cache
        result = try_to_load_from_cache(repo_id, "config.json")
        return result is not None
    except Exception:
        return False


class TorchBackend(ModelBackend):
    """
    PyTorch-based model backend.
    
    Supports CUDA, MPS (Apple Silicon), and CPU.
    Uses float16 for efficiency on GPU/MPS.
    """
    
    def __init__(
        self,
        mode: str = "hybrid",
        device: str = "auto",
        dtype: str = "float16",
    ):
        """
        Initialize PyTorch backend.
        
        Args:
            mode: Search mode - 'embed' or 'hybrid'
            device: 'auto', 'cuda', 'mps', or 'cpu'
            dtype: 'float16', 'bfloat16', or 'float32'
        """
        self._mode = mode
        self._device_requested = device
        self._dtype_requested = dtype
        
        # Lazy-loaded models
        self._embedder = None
        self._reranker = None
        
        # Resolved device/dtype
        self._device = None
        self._dtype = None
        
        # Model IDs
        self.EMBEDDER_MODEL = "Qwen/Qwen3-VL-Embedding-2B"
        self.RERANKER_MODEL = "Qwen/Qwen3-VL-Reranker-2B"
        
        # Apply transformers compatibility patch
        self._apply_transformers_patch()
        
        # Add Qwen3-VL-Embedding repo to path
        self._add_qwen_repo_to_path()
    
    def _apply_transformers_patch(self):
        """Apply compatibility patch for transformers 5.x."""
        try:
            import transformers.utils.generic as _generic
            if not hasattr(_generic, 'check_model_inputs'):
                _generic.check_model_inputs = lambda *args, **kwargs: None
        except Exception:
            pass
        
        try:
            import transformers.utils
            if not hasattr(transformers.utils, 'check_model_inputs'):
                transformers.utils.check_model_inputs = lambda *args, **kwargs: None
        except Exception:
            pass
    
    def _add_qwen_repo_to_path(self):
        """Add Qwen3-VL-Embedding repo to sys.path."""
        # Find the repo relative to this file
        qwen_repo = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "Qwen3-VL-Embedding")
        qwen_src = os.path.join(qwen_repo, "src")
        
        if os.path.exists(qwen_src) and qwen_src not in sys.path:
            sys.path.insert(0, qwen_src)
    
    def _get_device(self) -> str:
        """Determine best device for inference."""
        if self._device is not None:
            return self._device
        
        import torch
        
        if self._device_requested != "auto":
            self._device = self._device_requested
            return self._device
        
        if torch.cuda.is_available():
            self._device = "cuda"
        elif torch.backends.mps.is_available():
            self._device = "mps"
        else:
            self._device = "cpu"
        
        return self._device
    
    def _get_dtype(self):
        """Get torch dtype for model loading."""
        import torch
        
        if self._dtype is not None:
            return self._dtype
        
        dtype_map = {
            "float16": torch.float16,
            "bfloat16": torch.bfloat16,
            "float32": torch.float32,
        }
        
        requested = dtype_map.get(self._dtype_requested, torch.float16)
        
        # MPS doesn't support bfloat16
        device = self._get_device()
        if device == "mps" and requested == torch.bfloat16:
            requested = torch.float16
        
        self._dtype = requested
        return self._dtype
    
    def _get_attention_implementation(self) -> str:
        """Get attention implementation for device."""
        device = self._get_device()
        if device == "mps":
            return "eager"
        elif device == "cuda":
            return "flash_attention_2"
        else:
            return "eager"
    
    # =========================================================================
    # Embedder (Qwen3-VL-Embedding-2B, ~4GB)
    # =========================================================================
    
    def _is_qwen_video_transformers_bug_applicable(self) -> bool:
        """Return True when running the known Qwen3-VL video bug on transformers 5.3.x."""
        try:
            import transformers
        except Exception:
            return False

        try:
            version = Version(transformers.__version__)
        except (AttributeError, InvalidVersion, TypeError):
            return False

        if version.major != 5 or version.minor != 3:
            return False

        model_ids = [
            getattr(self, "EMBEDDER_MODEL", ""),
            getattr(self, "RERANKER_MODEL", ""),
            getattr(self, "EXPANDER_MODEL", ""),
        ]
        return any("qwen3-vl" in model_id.lower() or "qwen3.5" in model_id.lower() for model_id in model_ids)

    def _log_known_qwen_video_bug_warning(self):
        """Log a one-time proactive warning for the known upstream torch video bug."""
        if getattr(self, "_warned_qwen_video_bug", False):
            return
        if not self._is_qwen_video_transformers_bug_applicable():
            return

        logger.warning(
            "[TorchBackend] transformers %s with Qwen3-VL/Qwen3.5 may crash on video embedding due to known upstream bug (QwenLM/Qwen3.5#58). Frame-based fallback will be used if video embedding fails.",
            __import__("transformers").__version__,
        )
        self._warned_qwen_video_bug = True

    def _handle_video_embedding_failure(self, exc: Exception) -> None:
        """Normalize known upstream Qwen video embedding crashes into a clean RuntimeError."""
        logger.warning(
            "Video embedding failed due to known upstream transformers bug (QwenLM/Qwen3.5#58). Falling back to frame-based indexing."
        )
        raise RuntimeError(
            "Video embedding failed due to known upstream transformers bug (QwenLM/Qwen3.5#58); frame-based fallback should be used."
        ) from exc

    def _load_embedder(self):
        """Lazy-load the embedder model."""
        if self._embedder is not None:
            return
        
        import torch
        
        # Import from Qwen3-VL-Embedding repo
        # Try multiple import paths: installed package, repo src/models, direct
        try:
            from models.qwen3_vl_embedding import Qwen3VLEmbedder
        except ImportError:
            try:
                from qwen3_vl_embedding import Qwen3VLEmbedder
            except ImportError:
                # Find the Qwen3-VL-Embedding repo relative to this package
                import importlib.util
                _pkg_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                _repo_root = os.path.dirname(os.path.dirname(_pkg_root))
                _qwen_src = os.path.join(_repo_root, "Qwen3-VL-Embedding", "src")
                if os.path.isdir(_qwen_src) and _qwen_src not in sys.path:
                    sys.path.insert(0, _qwen_src)
                from models.qwen3_vl_embedding import Qwen3VLEmbedder
        
        device = self._get_device()
        dtype = self._get_dtype()
        attn = self._get_attention_implementation()
        
        if not _check_model_cached(self.EMBEDDER_MODEL):
            logger.info(
                "[RecallForge] Downloading embedder model (%s, ~4GB)... first run only.",
                self.EMBEDDER_MODEL.split("/")[-1],
            )

        # Suppress flash-linear-attention not-installed warning
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", message=".*The fast path is not available.*")
            warnings.filterwarnings("ignore", message=".*causal_conv1d.*")
            
            self._embedder = Qwen3VLEmbedder(
                model_name_or_path=self.EMBEDDER_MODEL,
                torch_dtype=dtype,
                attn_implementation=attn,
            )
        
        logger.info("[TorchBackend] Loaded embedder on %s with %s", device, dtype)
        self._log_known_qwen_video_bug_warning()
    
    def embed_text(self, text: str) -> np.ndarray:
        """Embed a single text string."""
        return self.embed_texts([text])[0]
    
    def embed_texts(self, texts: List[str]) -> np.ndarray:
        """Embed multiple text strings in a batch."""
        self._load_embedder()
        
        inputs = [
            {
                "text": text,
                "instruction": "Retrieve documents relevant to the user's query.",
            }
            for text in texts
        ]
        
        embeddings = self._embedder.process(inputs)
        return self._coerce_embeddings(embeddings)
    
    def embed_image(self, image_path: str) -> np.ndarray:
        """Embed a single image."""
        return self.embed_images([image_path])[0]
    
    def embed_images(self, image_paths: List[str]) -> np.ndarray:
        """Embed multiple images in a batch."""
        self._load_embedder()
        
        inputs = [
            {
                "image": path,
                "instruction": "Retrieve content relevant to the image.",
            }
            for path in image_paths
        ]
        
        embeddings = self._embedder.process(inputs)
        return self._coerce_embeddings(embeddings)

    def caption_image(self, image_path: str) -> str:
        """Generate a short one-sentence image caption for BM25 indexing."""
        self._load_embedder()

        prompt = "Describe this image in one sentence for search indexing."

        try:
            if hasattr(self._embedder, "caption_image") and callable(self._embedder.caption_image):
                caption = self._embedder.caption_image(
                    image_path=image_path,
                    prompt=prompt,
                    max_new_tokens=50,
                )
                if isinstance(caption, str) and caption.strip():
                    return re.sub(r"\s+", " ", caption).strip()

            if hasattr(self._embedder, "generate") and callable(self._embedder.generate):
                generated = self._embedder.generate(
                    [{"image": image_path, "text": prompt}],
                    max_new_tokens=50,
                )
                if isinstance(generated, str) and generated.strip():
                    return re.sub(r"\s+", " ", generated).strip()
                if isinstance(generated, list) and generated:
                    first = generated[0]
                    if isinstance(first, str) and first.strip():
                        return re.sub(r"\s+", " ", first).strip()

            raise RuntimeError("embedder does not expose a supported caption generation API")
        except Exception as exc:
            raise RuntimeError(f"caption_image failed for '{image_path}': {exc}") from exc

    def embed_video(self, video_path: str) -> np.ndarray:
        """Embed a single video."""
        self._load_embedder()

        inputs = [{
            "video": video_path,
            "instruction": "Retrieve content relevant to the video.",
        }]

        try:
            embeddings = self._embedder.process(inputs)
        except (StopIteration, RuntimeError) as exc:
            self._handle_video_embedding_failure(exc)
        return self._coerce_embeddings(embeddings)[0]

    def embed_videos(self, video_paths: List[str]) -> np.ndarray:
        """Embed multiple videos in a batch."""
        self._load_embedder()

        inputs = [
            {
                "video": path,
                "instruction": "Retrieve content relevant to the video.",
            }
            for path in video_paths
        ]

        try:
            embeddings = self._embedder.process(inputs)
        except (StopIteration, RuntimeError) as exc:
            self._handle_video_embedding_failure(exc)
        return self._coerce_embeddings(embeddings)

    def _coerce_embeddings(self, embeddings) -> np.ndarray:
        """Normalize backend outputs to float32 numpy arrays."""
        if isinstance(embeddings, np.ndarray):
            return embeddings.astype(np.float32)

        import torch

        if isinstance(embeddings, torch.Tensor):
            return embeddings.cpu().numpy().astype(np.float32)
        return np.array(embeddings, dtype=np.float32)
    
    # =========================================================================
    # Reranker (Qwen3-VL-Reranker-2B, ~4GB)
    # =========================================================================
    
    def _load_reranker(self):
        """Lazy-load the reranker model.
        
        On MPS, loads with float32 to avoid Apple Metal GEMV kernel crash
        (LORADOWN matrixRowPadElements overflow in float16).
        Embedder is fine with float16 — only the reranker triggers this bug.
        """
        if self._reranker is not None:
            return
        
        import torch
        
        try:
            from models.qwen3_vl_reranker import Qwen3VLReranker
        except ImportError:
            try:
                from qwen3_vl_reranker import Qwen3VLReranker
            except ImportError:
                # Fallback: find via Qwen3-VL-Embedding repo path
                _pkg_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                _repo_root = os.path.dirname(os.path.dirname(_pkg_root))
                _qwen_src = os.path.join(_repo_root, "Qwen3-VL-Embedding", "src")
                if os.path.isdir(_qwen_src) and _qwen_src not in sys.path:
                    sys.path.insert(0, _qwen_src)
                from models.qwen3_vl_reranker import Qwen3VLReranker
        
        device = self._get_device()
        attn = self._get_attention_implementation()
        
        # MPS float16 triggers Apple Metal GEMV kernel crash on reranker.
        # Use float32 on MPS — still GPU-accelerated, ~50ms penalty on 10 docs.
        if device == "mps":
            dtype = torch.float32
        else:
            dtype = self._get_dtype()
        
        if not _check_model_cached(self.RERANKER_MODEL):
            logger.info(
                "[RecallForge] Downloading reranker model (%s, ~4GB)... first run only.",
                self.RERANKER_MODEL.split("/")[-1],
            )

        # Suppress flash-linear-attention not-installed warning
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", message=".*The fast path is not available.*")
            warnings.filterwarnings("ignore", message=".*causal_conv1d.*")
            
            self._reranker = Qwen3VLReranker(
                model_name_or_path=self.RERANKER_MODEL,
                device=device,
                dtype=dtype,
                attn_implementation=attn,
            )
        
        logger.info("[TorchBackend] Loaded reranker on %s with %s", device, dtype)
    
    def rerank(
        self,
        query: str,
        documents: List[Dict[str, Any]],
        query_image_path: Optional[str] = None,
        query_video_path: Optional[str] = None,
    ) -> List[float]:
        """Rerank documents for a query.

        Args:
            query: Text query.  May be empty when query_image_path/query_video_path
                is provided.
            documents: Document dicts.
            query_image_path: Optional query image path (REC-138/139/150).
            query_video_path: Optional query video path.

        Note: TorchBackend does not yet support query-side VL reranking.
        The caller (HybridSearcher._rerank_candidates) falls back to captioning
        the query media and passing the caption as the text query when this backend
        is active, so scores remain meaningful.
        """
        if not documents:
            return []

        if not self.needs_reranker():
            # Hybrid mode not active, return neutral scores
            return [0.5] * len(documents)

        self._load_reranker()

        # Build query dict: prefer caption text already resolved by the caller.
        # query_image_path / query_video_path are accepted but not used natively here.
        query_entry: dict = {"text": query}

        doc_entries = []
        for d in documents:
            text = d.get("text", "") or d.get("text_body", "") or ""
            image_path = d.get("image_path")
            video_path = d.get("video_path")
            if image_path:
                doc_entries.append({"text": text, "image": image_path})
            elif video_path:
                doc_entries.append({"text": text, "video": video_path})
            else:
                doc_entries.append({"text": text})

        inputs = {
            "query": query_entry,
            "documents": doc_entries,
            "instruction": "Given a search query, retrieve relevant candidates that answer the query.",
        }
        
        try:
            scores = self._reranker.process(inputs)
            return list(scores) if scores else [0.0] * len(documents)
        except Exception as e:
            logger.error("[TorchBackend] Rerank error: %s", e)
            return [0.5] * len(documents)

    # =========================================================================
    # Warm-up and Status
    # =========================================================================
    
    def warm_up(self) -> None:
        """Preload all models for current mode."""
        import time
        
        logger.info("[TorchBackend] Warming up models (mode=%s)...", self._mode)
        start = time.time()
        
        # Always load embedder
        self._load_embedder()
        t1 = time.time()
        logger.info("[TorchBackend]   Embedder loaded in %.1fs", t1 - start)
        
        # Load reranker for hybrid mode
        if self.needs_reranker():
            self._load_reranker()
            t2 = time.time()
            logger.info("[TorchBackend]   Reranker loaded in %.1fs", t2 - t1)
        
        logger.info("[TorchBackend] All models ready in %.1fs total", time.time() - start)
    
    def get_info(self) -> BackendInfo:
        """Return backend information."""
        import torch
        
        device = self._get_device()
        dtype = str(self._get_dtype())
        
        # Estimate memory
        mem = 0
        if self._embedder:
            mem += 4000  # ~4GB
        if self._reranker:
            mem += 4000  # ~4GB
        
        return BackendInfo(
            name="torch",
            device=device,
            dtype=dtype,
            embedder_loaded=self._embedder is not None,
            reranker_loaded=self._reranker is not None,
            memory_allocated_gb=mem / 1000,
            supports_images=True,
            quantization=None,
        )
    
    def set_mode(self, mode: str) -> None:
        """Set the search mode."""
        if mode not in ("embed", "hybrid"):
            raise ValueError(f"Invalid mode: {mode}. Must be 'embed' or 'hybrid'")
        self._mode = mode
    
    def get_mode(self) -> str:
        """Get current search mode."""
        return self._mode
