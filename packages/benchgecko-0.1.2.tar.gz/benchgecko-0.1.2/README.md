# BenchGecko

Python SDK for [BenchGecko](https://benchgecko.ai) -- the data layer of the AI economy.

Query AI model benchmarks, cross-provider pricing, and performance data.

## Resources

- [BenchGecko](https://benchgecko.ai)
- [Model Rankings](https://benchgecko.ai/models)
- [Pricing](https://benchgecko.ai/pricing)
- [API Docs](https://benchgecko.ai/api-docs)
- [Economy](https://benchgecko.ai/economy)
- [Compute](https://benchgecko.ai/compute)
