"""BenchGecko Python SDK - Query AI model benchmarks and pricing data."""

__version__ = "0.1.2"
BASE_URL = "https://benchgecko.ai/api/v1"

import requests

def models(**params):
    return requests.get(f"{BASE_URL}/models", params=params).json()

def model(slug):
    return requests.get(f"{BASE_URL}/models/{slug}").json()

def benchmarks():
    return requests.get(f"{BASE_URL}/benchmarks").json()

def compare(*slugs):
    return requests.get(f"{BASE_URL}/compare", params={"models": ",".join(slugs)}).json()

def pricing(slug=None):
    url = f"{BASE_URL}/pricing/{slug}" if slug else f"{BASE_URL}/pricing"
    return requests.get(url).json()

def providers():
    return requests.get(f"{BASE_URL}/providers").json()

def agents():
    return requests.get(f"{BASE_URL}/agents").json()
