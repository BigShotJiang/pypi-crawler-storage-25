from setuptools import setup, find_packages

setup(
    name="benchgecko",
    version="0.1.2",
    description="Python SDK for BenchGecko. Query AI model benchmarks, cross-provider pricing, and performance data across hundreds of providers.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="BenchGecko",
    author_email="hello@benchgecko.ai",
    url="https://benchgecko.ai",
    project_urls={
        "Homepage": "https://benchgecko.ai",
        "Documentation": "https://benchgecko.ai/api-docs",
        "Source": "https://github.com/BenchGecko/benchgecko-python",
        "Changelog": "https://benchgecko.ai/changelog",
    },
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=["requests>=2.25.0"],
    keywords=["ai", "benchmarks", "llm", "pricing", "models", "api", "benchgecko"],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
