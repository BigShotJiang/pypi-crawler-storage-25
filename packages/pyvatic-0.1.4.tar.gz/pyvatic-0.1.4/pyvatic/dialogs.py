# -------------------------------------*- vatic -*----------------------------
#                               Open Source Risk Analysis
#
#                             Copyright (c) 2026, eggzec
#                          Contact: https://eggzec.github.io/
#
#                         License: GNU General Public License
#                              Version 3, 29 June 2007
#
# ----------------------------------------------------------------------------
#
#  Author(s)
#      Saud Zahir <m.saud.zahir@gmail.com>
#
#  Date
#      7 May 2026
#
#  Description
#      Qt dialogs for distribution parameter input.
#
# ----------------------------------------------------------------------------

from __future__ import annotations

from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QVBoxLayout,
    QWidget,
)

from pyvatic.distributions import (
    DistributionSpec,
    coerce_parameter_value,
    default_parameters,
)
from pyvatic.logger import get_logger


LOGGER = get_logger(__name__)


class ParameterDialog(QDialog):
    def __init__(
        self,
        spec: DistributionSpec,
        initial_values: dict[str, float | int] | None,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.spec = spec
        self._values: dict[str, float | int] = {}
        self._inputs: dict[str, QLineEdit] = {}

        self.setWindowTitle(f"Parameters - {spec.label}")
        self.resize(440, 10)
        LOGGER.debug("Parameter dialog opened | distribution=%s", spec.label)

        root = QVBoxLayout(self)
        hint = QLabel("Provide values for the selected distribution.")
        hint.setWordWrap(True)
        root.addWidget(hint)

        form = QFormLayout()
        resolved = dict(default_parameters(spec))
        if initial_values:
            resolved.update(initial_values)

        for parameter in spec.parameters:
            editor = QLineEdit(str(resolved.get(parameter.name, "")))
            editor.setPlaceholderText(parameter.kind)
            form.addRow(f"{parameter.name} ({parameter.kind})", editor)
            self._inputs[parameter.name] = editor

        root.addLayout(form)

        buttons = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

    def values(self) -> dict[str, float | int]:
        return dict(self._values)

    def _accept(self) -> None:
        try:
            parsed: dict[str, float | int] = {}
            for parameter in self.spec.parameters:
                widget = self._inputs[parameter.name]
                parsed[parameter.name] = coerce_parameter_value(
                    widget.text(), parameter
                )
            self._values = parsed
            LOGGER.debug(
                "Parameter dialog accepted | distribution=%s | values=%s",
                self.spec.label,
                parsed,
            )
            self.accept()
        except ValueError as exc:
            LOGGER.warning(
                "Parameter validation failed | distribution=%s | error=%s",
                self.spec.label,
                exc,
            )
            QMessageBox.critical(self, "Invalid Parameters", str(exc))
