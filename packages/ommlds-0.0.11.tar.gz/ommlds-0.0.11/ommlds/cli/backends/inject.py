r"""
    if cfg.backend is not None:
        lst.append(inj.bind(_types.BackendName, to_const=cfg.backend))
    else:
        lst.append(inj.bind(_types.BackendName, to_fn=inj.target(dbn=_types.DefaultBackendName)(lambda dbn: dbn)))

    backend_provider_pairs: list = [
        (_types.ChatChoicesServiceBackendProvider, _catalog.CatalogChatChoicesServiceBackendProvider),
        (_types.ChatChoicesStreamServiceBackendProvider, _catalog.CatalogChatChoicesStreamServiceBackendProvider),
        (_types.CompletionServiceBackendProvider, _catalog.CatalogCompletionServiceBackendProvider),
        (_types.EmbeddingServiceBackendProvider, _catalog.CatalogEmbeddingServiceBackendProvider),
    ]

    for bp_iface, bp_impl in backend_provider_pairs:
        bp_stack = inj.wrapper_binder_helper(bp_iface)

        if bp_iface is _types.ChatChoicesServiceBackendProvider:
            fiw_ben_lst: list[str] = [
                # 'openai',
                # 'anthropic',
                # 'groq',
                # 'cerebras',
            ]

            if fiw_ben_lst:
                for ben in fiw_ben_lst:
                    ben_bp_key: inj.Key = inj.Key(bp_impl, tag=ben)
                    lst.extend([
                        inj.private(
                            inj.bind(_types.BackendName, to_const=ben),
                            inj.bind(ben_bp_key, to_ctor=bp_impl, singleton=True, expose=True),
                            inj.bind(bp_iface, to_key=ben_bp_key),
                        ),
                        bp_stack.push_bind(to_key=ben_bp_key),
                    ])

                fiw_key: inj.Key = inj.Key(_meta.FirstInWinsBackendProvider, tag=bp_iface)
                lst.extend([
                    inj.private(
                        inj.set_binder[_types.BackendProvider]().bind(bp_stack.top),
                        inj.bind(fiw_key, to_ctor=_meta.FirstInWinsBackendProvider, singleton=True, expose=True),
                    ),
                    bp_stack.push_bind(to_key=fiw_key),
                ])

            else:
                lst.append(bp_stack.push_bind(to_ctor=bp_impl, singleton=True))

        else:
            lst.append(bp_stack.push_bind(to_ctor=bp_impl, singleton=True))

        if bp_iface is _types.ChatChoicesServiceBackendProvider:
            rt_key: inj.Key = inj.Key(_meta.RetryBackendProvider, tag=bp_iface)
            lst.extend([
                inj.private(
                    inj.bind(_types.BackendProvider, to_key=bp_stack.top),
                    inj.bind(rt_key, to_ctor=_meta.RetryBackendProvider, singleton=True, expose=True),
                ),
                bp_stack.push_bind(to_key=rt_key),
            ])

        elif bp_iface is _types.ChatChoicesStreamServiceBackendProvider:
            rts_key: inj.Key = inj.Key(_meta.RetryStreamBackendProvider, tag=bp_iface)
            lst.extend([
                inj.private(
                    inj.bind(_types.BackendProvider, to_key=bp_stack.top),
                    inj.bind(rts_key, to_ctor=_meta.RetryStreamBackendProvider, singleton=True, expose=True),
                ),
                bp_stack.push_bind(to_key=rts_key),
            ])

        lst.append(inj.bind(bp_iface, to_key=bp_stack.top))

    #

    async def catalog_backend_instantiator_provider(injector: inj.AsyncInjector) -> _catalog.CatalogBackendProvider.Instantiator:  # noqa
        async def inner(be: BackendInstantiator.Backend, cfgs: _types.BackendConfigs | None) -> ta.Any:
            kwt = inj.build_kwargs_target(be.factory, non_strict=True)
            kw = await injector.provide_kwargs(kwt)
            return be.factory(*tv.collect(*(be.configs or []), *(cfgs or []), override=True), **kw)

        return _catalog.CatalogBackendProvider.Instantiator(inner)

    lst.append(inj.bind(_catalog.CatalogBackendProvider.Instantiator, to_async_fn=catalog_backend_instantiator_provider))  # noqa

    return inj.as_elements(*lst)
"""  # noqa
import functools
import typing as ta

from omlish import inject as inj
from omlish import lang

from ... import minichain as mc
from .configs import BackendConfig
from .injection import backend_configs


with lang.auto_proxy_import(globals()):
    from . import types as _types


##


def bind_backends(
        service_cls_lst: ta.Sequence[ta.Any],
        /,
        cfg: BackendConfig = BackendConfig(),
) -> inj.Elements:
    lst: list[inj.Elemental] = []

    #

    lst.append(backend_configs().bind_items_provider(singleton=True))

    #

    if cfg.backend is not None:
        lst.append(inj.bind(_types.BackendName, to_const=cfg.backend))
    else:
        lst.append(inj.bind(_types.BackendName, to_fn=inj.target(dbn=_types.DefaultBackendName)(lambda dbn: dbn)))

    service_cls: ta.Any
    for service_cls in service_cls_lst:
        lst.append(
            inj.bind(
                mc.ServiceProvider[service_cls],  # noqa
                to_fn=inj.target(
                    spec=_types.BackendName,
                    configs=_types.BackendConfigs,
                )(functools.partial(
                    mc.BackendSpecServiceProvider,
                    service_cls,
                )),
                singleton=True,
            ),
        )

    #

    return inj.as_elements(*lst)
