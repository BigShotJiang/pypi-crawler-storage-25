from omlish import inject as inj
from omlish import lang

from ... import minichain as mc
from ..backends.configs import BackendConfig
from ..backends.types import DefaultBackendName
from ..types import Entrypoint
from .configs import DEFAULT_BACKEND
from .configs import CompletionConfig


with lang.auto_proxy_import(globals()):
    from ..backends import inject as _backends
    from . import entrypoint as _entrypoint


##


def bind_completion(cfg: CompletionConfig) -> inj.Elements:
    els: list[inj.Elemental] = []

    #

    els.extend([
        inj.bind(cfg),
        inj.bind(Entrypoint, to_ctor=_entrypoint.CompletionEntrypoint, singleton=True),
    ])

    #

    els.extend([
        _backends.bind_backends(
            [
                mc.CompletionService,
            ],
            BackendConfig(
                backend=cfg.backend,
            ),
        ),

        inj.bind(DefaultBackendName, to_const=DEFAULT_BACKEND),
    ])

    #

    return inj.as_elements(*els)
