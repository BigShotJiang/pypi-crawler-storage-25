import collections.abc
import typing as ta

from omlish import check
from omlish import dataclasses as dc
from omlish import lang
from omlish import marshal as msh
from omlish import reflect as rfl

from .blank import BlankContent
from .code import BlockCodeContent
from .code import InlineCodeContent
from .containers import BlocksContent
from .containers import ConcatContent
from .containers import FlowContent
from .content import Content
from .content import ContentBase
from .emphasis import BoldContent
from .emphasis import BoldItalicContent
from .emphasis import ItalicContent
from .images import ImageContent
from .itemlist import ItemListContent
from .json import JsonContent
from .link import LinkContent
from .markdown import MarkdownContent
from .placeholders import ContentPlaceholder
from .placeholders import PlaceholderContent
from .quote import QuoteContent
from .raw import NON_STR_SINGLE_RAW_CONTENT_TYPES
from .raw import NonStrSingleRawContent
from .raw import RawContent
from .raw import SingleRawContent
from .section import SectionContent
from .tag import TagContent
from .text import TextContent


##


class MarshalContent(lang.NotInstantiable, lang.Final):
    pass


MarshalContentUnion: ta.TypeAlias = ta.Union[  # noqa
    str,
    ContentBase,
    ta.Sequence[MarshalContent],
]


_MARSHAL_CONTENT_UNION_RTY = rfl.typeof(MarshalContentUnion)


@dc.dataclass(frozen=True)
class _ContentMarshaler(msh.Marshaler):
    bt: msh.Marshaler

    def marshal(self, ctx: msh.MarshalContext, o: ta.Any) -> msh.Value:
        if isinstance(o, str):
            return o
        elif isinstance(o, ta.Sequence):
            return [self.marshal(ctx, e) for e in o]
        elif isinstance(o, ContentBase):
            return self.bt.marshal(ctx, o)
        else:
            raise TypeError(o)


class _ContentMarshalerFactory(msh.MarshalerFactory):
    def make_marshaler(self, ctx: msh.MarshalFactoryContext, rty: rfl.Type) -> ta.Callable[[], msh.Marshaler] | None:
        if not (rty is MarshalContent or rty == _MARSHAL_CONTENT_UNION_RTY):
            return None
        return lambda: _ContentMarshaler(ctx.make_marshaler(ContentBase))


@dc.dataclass(frozen=True)
class _ContentUnmarshaler(msh.Unmarshaler):
    bt: msh.Unmarshaler

    def unmarshal(self, ctx: msh.UnmarshalContext, v: msh.Value) -> ta.Any:
        if isinstance(v, str):
            return v
        elif isinstance(v, ta.Sequence):
            return [self.unmarshal(ctx, e) for e in v]
        elif isinstance(v, collections.abc.Mapping):
            return self.bt.unmarshal(ctx, v)  # noqa
        else:
            raise TypeError(v)


class _ContentUnmarshalerFactory(msh.UnmarshalerFactory):
    def make_unmarshaler(self, ctx: msh.UnmarshalFactoryContext, rty: rfl.Type) -> ta.Callable[[], msh.Unmarshaler] | None:  # noqa
        if not (rty is MarshalContent or rty == _MARSHAL_CONTENT_UNION_RTY):
            return None
        return lambda: _ContentUnmarshaler(ctx.make_unmarshaler(ContentBase))


##


class MarshalSingleRawContent(lang.NotInstantiable, lang.Final):
    pass


_SINGLE_RAW_CONTENT_UNION_RTY = rfl.typeof(SingleRawContent)


@dc.dataclass(frozen=True)
class _SingleRawContentMarshaler(msh.Marshaler):
    nst: msh.Marshaler

    def marshal(self, ctx: msh.MarshalContext, o: ta.Any) -> msh.Value:
        if isinstance(o, str):
            return o
        elif isinstance(o, NON_STR_SINGLE_RAW_CONTENT_TYPES):
            return self.nst.marshal(ctx, o)
        else:
            raise TypeError(o)


class _SingleRawContentMarshalerFactory(msh.MarshalerFactory):
    def make_marshaler(self, ctx: msh.MarshalFactoryContext, rty: rfl.Type) -> ta.Callable[[], msh.Marshaler] | None:
        if not (rty is MarshalSingleRawContent or rty == _SINGLE_RAW_CONTENT_UNION_RTY):
            return None
        return lambda: _SingleRawContentMarshaler(ctx.make_marshaler(NonStrSingleRawContent))


@dc.dataclass(frozen=True)
class _SingleRawContentUnmarshaler(msh.Unmarshaler):
    nst: msh.Unmarshaler

    def unmarshal(self, ctx: msh.UnmarshalContext, v: msh.Value) -> ta.Any:
        if isinstance(v, str):
            return v
        elif isinstance(v, collections.abc.Mapping):
            return self.nst.unmarshal(ctx, v)  # noqa
        else:
            raise TypeError(v)


class _SingleRawContentUnmarshalerFactory(msh.UnmarshalerFactory):
    def make_unmarshaler(self, ctx: msh.UnmarshalFactoryContext, rty: rfl.Type) -> ta.Callable[[], msh.Unmarshaler] | None:  # noqa
        if not (rty is MarshalSingleRawContent or rty == _SINGLE_RAW_CONTENT_UNION_RTY):
            return None
        return lambda: _SingleRawContentUnmarshaler(ctx.make_unmarshaler(NonStrSingleRawContent))


##


class MarshalRawContent(lang.NotInstantiable, lang.Final):
    pass


MarshalRawContentUnion: ta.TypeAlias = ta.Union[  # noqa
    SingleRawContent,
    ta.Sequence[MarshalRawContent],
]


_MARSHAL_RAW_CONTENT_UNION_RTY = rfl.typeof(MarshalRawContentUnion)


@dc.dataclass(frozen=True)
class _RawContentMarshaler(msh.Marshaler):
    nst: msh.Marshaler

    def marshal(self, ctx: msh.MarshalContext, o: ta.Any) -> msh.Value:
        if isinstance(o, str):
            return o
        elif isinstance(o, ta.Sequence):
            return [self.marshal(ctx, e) for e in o]
        elif isinstance(o, NON_STR_SINGLE_RAW_CONTENT_TYPES):
            return self.nst.marshal(ctx, o)
        else:
            raise TypeError(o)


class _RawContentMarshalerFactory(msh.MarshalerFactory):
    def make_marshaler(self, ctx: msh.MarshalFactoryContext, rty: rfl.Type) -> ta.Callable[[], msh.Marshaler] | None:
        if not (rty is MarshalRawContent or rty == _MARSHAL_RAW_CONTENT_UNION_RTY):
            return None
        return lambda: _RawContentMarshaler(ctx.make_marshaler(NonStrSingleRawContent))


@dc.dataclass(frozen=True)
class _RawContentUnmarshaler(msh.Unmarshaler):
    nst: msh.Unmarshaler

    def unmarshal(self, ctx: msh.UnmarshalContext, v: msh.Value) -> ta.Any:
        if isinstance(v, str):
            return v
        elif isinstance(v, ta.Sequence):
            return [self.unmarshal(ctx, e) for e in v]
        elif isinstance(v, collections.abc.Mapping):
            return self.nst.unmarshal(ctx, v)  # noqa
        else:
            raise TypeError(v)


class _RawContentUnmarshalerFactory(msh.UnmarshalerFactory):
    def make_unmarshaler(self, ctx: msh.UnmarshalFactoryContext, rty: rfl.Type) -> ta.Callable[[], msh.Unmarshaler] | None:  # noqa
        if not (rty is MarshalRawContent or rty == _MARSHAL_RAW_CONTENT_UNION_RTY):
            return None
        return lambda: _RawContentUnmarshaler(ctx.make_unmarshaler(NonStrSingleRawContent))


##


_PLACEHOLDER_KEY = '\\$PLACEHOLDER'
_PLACEHOLDER_FQCN_KEY = '$'


class _PlaceholderContentMarshaler(msh.Marshaler):
    def marshal(self, ctx: msh.MarshalContext, o: ta.Any) -> msh.Value:
        pc = check.isinstance(o, PlaceholderContent)
        if isinstance(pc.k, str):
            return {_PLACEHOLDER_KEY: pc.k}
        elif isinstance(pc.k, type) and issubclass(pc.k, ContentPlaceholder):
            fq = lang.get_cls_fqcn(pc.k)
            return {_PLACEHOLDER_KEY: {_PLACEHOLDER_FQCN_KEY: fq}}
        else:
            raise TypeError(o)


class _PlaceholderContentUnmarshaler(msh.Unmarshaler):
    def unmarshal(self, ctx: msh.UnmarshalContext, v: msh.Value) -> ta.Any:
        dct = check.isinstance(v, ta.Mapping)
        [(k, v)] = dct.items()
        check.equal(k, _PLACEHOLDER_KEY)
        if isinstance(v, str):
            return PlaceholderContent(v)
        elif isinstance(v, ta.Mapping):
            [(mk, fq)] = v.items()
            check.equal(mk, _PLACEHOLDER_FQCN_KEY)
            cl = lang.get_fqcn_cls(check.isinstance(fq, str))  # noqa
            return PlaceholderContent(cl)
        else:
            raise TypeError(v)


##


class _ImageContentMarshaler(msh.Marshaler):
    def marshal(self, ctx: msh.MarshalContext, o: ta.Any) -> msh.Value:
        raise NotImplementedError


class _ImageContentUnmarshaler(msh.Unmarshaler):
    def unmarshal(self, ctx: msh.UnmarshalContext, v: msh.Value) -> ta.Any:
        raise NotImplementedError


##


@lang.static_init
def _install_standard_marshaling() -> None:
    base_content_poly = msh.Polymorphism(
        ContentBase,
        [

            msh.Impl(BlankContent, 'blank'),

            msh.Impl(InlineCodeContent, 'inline_code'),
            msh.Impl(BlockCodeContent, 'block_code'),

            msh.Impl(FlowContent, 'flow'),
            msh.Impl(ConcatContent, 'concat'),
            msh.Impl(BlocksContent, 'blocks'),

            msh.Impl(BoldContent, 'bold'),
            msh.Impl(ItalicContent, 'italic'),
            msh.Impl(BoldItalicContent, 'bold_italic'),

            msh.Impl(ImageContent, 'image'),

            msh.Impl(ItemListContent, 'item_list'),

            msh.Impl(JsonContent, 'json'),

            msh.Impl(LinkContent, 'link'),

            msh.Impl(MarkdownContent, 'markdown'),

            msh.Impl(QuoteContent, 'quote'),

            msh.Impl(SectionContent, 'section'),

            msh.Impl(TagContent, 'tag'),

            msh.Impl(TextContent, 'text'),

            msh.Impl(PlaceholderContent, 'placeholder'),

        ],
    )

    msh.install_standard_factories(
        *msh.standard_polymorphism_factories(base_content_poly),
    )

    #

    msh.install_standard_factories(
        _ContentMarshalerFactory(),
        _ContentUnmarshalerFactory(),
    )

    msh.update_global_config(
        Content,
        msh.ReflectOverride(MarshalContent),
        identity=True,
    )

    #

    msh.install_standard_factories(
        _SingleRawContentMarshalerFactory(),
        _SingleRawContentUnmarshalerFactory(),
    )

    msh.update_global_config(
        SingleRawContent,
        msh.ReflectOverride(MarshalSingleRawContent),
        identity=True,
    )

    #

    msh.install_standard_factories(
        _RawContentMarshalerFactory(),
        _RawContentUnmarshalerFactory(),
    )

    msh.update_global_config(
        RawContent,
        msh.ReflectOverride(MarshalRawContent),
        identity=True,
    )

    #

    msh.install_standard_factories(
        msh.TypeMapMarshalerFactory({
            ImageContent: _ImageContentMarshaler(),
            PlaceholderContent: _PlaceholderContentMarshaler(),
        }),
        msh.TypeMapUnmarshalerFactory({
            ImageContent: _ImageContentUnmarshaler(),
            PlaceholderContent: _PlaceholderContentUnmarshaler(),
        }),
    )
