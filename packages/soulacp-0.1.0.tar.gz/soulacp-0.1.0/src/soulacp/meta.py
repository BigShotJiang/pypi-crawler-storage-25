"""Package metadata constants."""

__version__ = "0.1.0"
CLIENT_NAME = "soulacp"
