# Beatcut

> **Name reserved. Under active development.**

Beatcut will be an open-source tool that automatically edits video footage to music — cutting on the beat, reacting to energy, and composing timelines from your source clips.

**Status**: v0.0.0 is a placeholder reservation. The first usable release (v0.1.0) is planned for 2026 Q2.

**Track progress**: [github.com/alanhuang67/beatcut](https://github.com/alanhuang67/beatcut)

---

## Do not install this version

This `0.0.0` release contains no functionality. Please wait for `v0.1.0`, or star the GitHub repo to be notified when it lands.

```bash
# Coming soon (not yet published)
pip install beatcut
```

## License

[AGPL-3.0-or-later](https://spdx.org/licenses/AGPL-3.0-or-later.html)

Copyright © 2026 Alan Huang
