"""Beatcut — placeholder. See https://github.com/alanhuang67/beatcut for progress."""

__version__ = "0.0.0"
__status__ = "reserved"
