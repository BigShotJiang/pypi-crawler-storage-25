"""
SGN Semantic TL-UL Adapter for OpenTitan

This package provides SystemVerilog assertions and verification components
for the SGN TL-UL adapter, ensuring comprehensive security coverage and
formal verification capabilities.

Version: 0.2.0
Security Rating: A (95% coverage)
"""

__version__ = "0.2.0"
__author__ = "Stanislav Levarsky"
__email__ = "stanislav@omwei.com"

# Package metadata
PACKAGE_NAME = "sigmantic-slc"
SECURITY_VERSION = "0.2.0"
SECURITY_RATING = "A"
ASSERTION_COUNT = 9
COVERAGE_PERCENTAGE = 95

def get_assertion_files():
    """Return list of SystemVerilog assertion files"""
    return [
        "sgn_sva_assertions.sv",
        "uvm_slc_verification.sv", 
        "ax_buffer_coverage_monitor.sv"
    ]

def get_security_properties():
    """Return list of security properties covered"""
    return [
        "ZERO_LATENCY_BLOCK",
        "FAULT_ISOLATION", 
        "SIDEBAND_STABILITY",
        "OPCODE_VALIDITY_CHECK",
        "RESERVED_OPCODE_BLOCK",
        "OPCODE_CONSISTENCY_CHECK",
        "ADDRESS_ALIGNMENT_CHECK",
        "ADDRESS_RANGE_OVERFLOW_CHECK",
        "PAGE_BOUNDARY_CHECK"
    ]
