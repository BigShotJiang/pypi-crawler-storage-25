from setuptools import setup, find_packages

setup(
    name="sigmantic-slc",
    version="0.2.0",
    packages=find_packages(),
    package_data={"": ["*.sv", "*.hjson", "*.md", "*.txt"]},
    include_package_data=True,
)
