"""Placeholder for the Tidewall OpenTelemetry instrumentation package.

The real implementation lives at https://github.com/tidewall-security/tidewall-otel
and is not yet released to PyPI.
"""

__version__ = "0.0.1"
