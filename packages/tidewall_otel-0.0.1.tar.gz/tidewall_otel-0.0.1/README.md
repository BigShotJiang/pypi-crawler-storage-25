# tidewall-otel

> Placeholder release — the real Tidewall OpenTelemetry instrumentation is not yet on PyPI.

`tidewall-otel` provides zero-code-change AI security instrumentation for OpenAI
and Anthropic SDKs, built on OpenTelemetry. Each LLM call is automatically
forwarded to a [Tidewall](https://github.com/tidewall-security/tidewall-server)
guard for prompt-injection / PII / secrets analysis before reaching the model.

Until the first PyPI release ships, install from source:

```bash
git clone https://github.com/tidewall-security/tidewall-otel.git
cd tidewall-otel/python
uv sync
```

Project home: https://tidewall.ai
