# CLIChatty

A curses-based terminal interface to the
[chatty](https://gitlab.gnome.org/World/Chatty) messaging app's database.
Messages are sent using
[mmcli](https://github.com/linux-mobile-broadband/ModemManager). It is designed
to be used via SSH, this way you can message from your computer. 

SSH into your phone, then run `clic` or `clichatty` to start the program. For help with
keybindings, press `H`.
