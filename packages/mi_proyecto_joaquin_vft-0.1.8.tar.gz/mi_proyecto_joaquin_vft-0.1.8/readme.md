# mi_proyecto_joaquin_f2py

Este es un software desarrollado en **Fortran** con una interfaz para **Python** utilizando `f2py` y `Meson`.

## Instalación

Puedes instalarlo directamente desde PyPI:

```bash
pip install mi_proyecto_joaquin_f2py


import modulo

# Calcular el área de un círculo con radio 5.0
resultado = modulo.constantes_y_calculos.area_circulo(5.0)
print(f"El área es: {resultado}")



