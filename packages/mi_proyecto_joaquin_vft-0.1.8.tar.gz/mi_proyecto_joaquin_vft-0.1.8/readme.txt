IMPORTANTE!!!! Si quiero usar opciones en pip para que modifique los valores de NS y NV haciendo, por ejemplo, 

pip install mi_proyecto_joaquin_vft -Csetup-args="-DNS=140" -Csetup-args="-DNV=200"

debo cambiar los dos fuentes (voftools.f90 y voftools.pyf) copiados en ./src para que fucione:

- CAMBIO EN voftools.f90

Sustituyo 

	INCLUDE 'dimpol.h'
por

#INCLUDE "dimpol.h"

notar que no debe dejar espacio antes del #INCLUDE

- CAMBIO EN voftools.pyf

Sustituir en los dimension los parámetros ns y nv por J_NS y J_NV
Esto se puede hacer relativamente fácil en emacs ya que estos parámetros aperecen solo en los dimension.

# Esto creará voftoolsmodule.c y voftools-f2pywrappers2.f90 en tu carpeta ./src
cd ./src
python -m numpy.f2py voftools.pyf dimpol.h

# Como fortranobject.c no lo encuentra lo tengo que mover manualmente asi:
cp $(python -c "import numpy.f2py; import os; print(os.path.join(os.path.dirname(numpy.f2py.__file__), 'src', 'fortranobject.c'))") ./


!---------------------------------------
1. Estructura de archivos

mi_proyecto_joaquin_f2py/
├── src/ (tus archivos .f90, .pyf, .h y los .c generados)
├── pyproject.toml
└── meson.build
└── __init__.py
└── readme.md

Modificar la version # dentro de meson.build

Ejecutar:

rm -rf dist/
rm -rf builddir/
rm -rf .mesonpy-*

pip install .

!-----------------------------------------
Ahora quiero subir a PyPI (Python Package Index) mi_proyecto. Subiré el código fuente (también se puede subir con Wheel el binario ya compilado).

Hay que instalar la herramienta build:

pip install build

Inicializar un repositorio Git

git init
git add .
git commit -m "mi_proyecto_joaquin_vft"

Y ejecutar:

pip cache purge 
python -m build

Esto generará una carpeta dist/ con dos archivos:

.tar.gz (sdist): El código fuente. Si alguien lo instala, su ordenador necesitará gfortran, gcc y ninja para compilarlo.

.whl (wheel): El paquete ya compilado para tu arquitectura (en tu caso, macOS ARM64). Ojo: Este wheel solo funcionará en otros Mac con Apple Silicon.

IMPORTANTE: como voy a pasar los argumentos, tengo que borrar de ./dist el fichero binario precompilado .whl, para que pip no me lo instale por defecto

Ahora hay que subir a PyPI

pip install twine

Si no tengo cuenta, hay que tener una cuenta PyPI. Entro en pypi.org y me registro (YA ESTA). Ahora genero el Token en PyPI: Configuracion de cuenta; Añadir ficha de API; Ponerle un nombre (por ejemplo, "mi-token-fortran"); Se generan códigos de seguridad para recuperar cuenta; En Scope seleccionar "Entire account"; pulsar create token:

pypi-AgEIcHlwaS5vcmcCJGRiYjA5MmU5LTUwYzMtNGYzNy05N2JjLTg5NjgxYTlmZTBkMwACKlszLCJlZDQ0Nzg1Ny00ODA0LTQzYzItYjg0MS1kZDkxYzVlNTMxMzQiXQAABiCUztaKXF6Hodk-XHhBiSlD2Byms5HgQTh20I_VrZsbfw

Este toquen lo he guardado en /Usrs/joaquinlopez/.pypirc y en el fichero pypirc que tengo en la raiz de este directorio


Ahora ejecuto

twine upload -r mi_proyecto_joaquin_vft dist/*

Requeriments en el ordenador remoto (gfortran, gcc, ninja)

Prueba de instalación remota:

pip install mi_proyecto_joaquin_vft

NOTA IMPORTANTE: Como no uso el mismo nombre del mi_proyecto y voftools, debo buscar donde me instala pip el fichero .so (por jemplo, /Users/joaquinlopez/miniconda3/envs/py3.13/lib/python3.13/site-packages o algo así) y renombrar el fichero instalado (por ejemplo, /Users/joaquinlopez/miniconda3/envs/py3.13/lib/python3.13/site-packages/mi_proyecto_joaquin_vft.cpython-313-darwin.so a /Users/joaquinlopez/miniconda3/envs/py3.13/lib/python3.13/site-packages/voftools.cpython-313-darwin.so). CUANDO INSTALE LA VERSION DEFINITIVA, DEBERÉ NOMBRAR AL PROYECTO COMO VOFTOOLS PARA QUE NO HAYA PROBLEMAS !!!!!!!!!!!!!!!!


!------------------------------------
Para subir una nueva versión, hay que crear una nueva versión tanto en el fichero meson.build como en el fichero pyproject.toml. Para automatizar esto y evitar que cada vez que se suba haya que cambiarlo a mano, se puede hacer lo siguiente:

Cambia en pyproject.toml lo siguiente

project]
name = "mi_proyecto_joaquin_vft"
dynamic = ["version"]  # <--- Esto indica que la versión se toma de Meson
dependencies = ["numpy"]

[tool.meson-python]
# Opcional: esto asegura que meson-python busque la versión en el project() de meson.build

Para que python pueda consultar la versión (ej. modulo.__version__), añadir esto a mi_proyecto_joaquin_vft/__init__.py

import importlib.metadata
__version__ = importlib.metadata.version("mi_proyecto_joaquin_vft")

Ahora cambia la versión (sólo un número) en la primera línea de meson.build

rm -rf dist/
rm -rf builddir/
rm -rf .mesonpy-*
git add .
git commit -m "Actualizando a version 0.1.3"
git tag v0.1.3
python -m build --no-isolation
twine upload -r mi_proyecto_joaquin_vft dist/*

NOTA: Una vez subida la versión con twine, hay que esperar un poco (sobre 1 minuto) para poder instalar en otro ordenador.

Una vez instalada la ultima versión en otro ordenador con pip install mi_proyecto_joaquin_vft==0.1.3 (o la versión que sea), podemos ver la información de lo que he instalado haciendo:

pip show mi_proyecto_joaquin_f2py

