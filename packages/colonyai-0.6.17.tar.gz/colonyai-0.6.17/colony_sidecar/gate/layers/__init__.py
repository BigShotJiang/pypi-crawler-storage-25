"""Gate layer implementations."""
