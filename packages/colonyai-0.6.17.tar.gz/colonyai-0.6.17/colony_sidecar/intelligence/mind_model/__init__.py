# mind_model
