import sys
import numpy as np
import pandas as pd
import warnings
import json

from PySide6 import QtWidgets, QtGui, QtUiTools
from PySide6.QtCore import Qt, Signal
from copy import copy
from os import path, getcwd

from scipy.stats.mstats import gmean
from scipy.stats import linregress


from .backend.efio import getSysDefaultDir
from .backend.qtModels import gateWidgetItem
from .backend.comp import autoFluoTbModel, spillMatTbModel
from .uiDesigns import UiLoader
from .backend.dataIO import FCSData_ef

class compWizard(QtWidgets.QWizard):
    mainCompValueEdited = Signal()

    def __init__(self, parent, chnlModel, smplWidget, gateWidget, dir4Save,
                 curMainAutoFluoModel:autoFluoTbModel, curMainSpillMatModel:spillMatTbModel) -> None:
        super().__init__(parent)
        UiLoader().loadUi('CompWizard.ui', self)

        # link the vertical scrollbars on page4
        self.spillMatTable.verticalScrollBar().valueChanged.connect(self.autoFluoTable.verticalScrollBar().setValue)
        self.autoFluoTable.verticalScrollBar().valueChanged.connect(self.spillMatTable.verticalScrollBar().setValue)

        # visual tweak for page4
        self.autoFluoTable.verticalHeader().setMaximumSize(125, 16777215)
        self.autoFluoTable.horizontalHeader().setMaximumSectionSize(125)

        self.setButtonText(QtWidgets.QWizard.FinishButton, 'Finish and apply')

        # setting up all the model for the page1
        self.wizChnlModel = wPage1Model(chnlItemModel=chnlModel)
        self.wizSmplModel = wPage1Model(smplTreeWidget=smplWidget)
        self.wizGateModel = wPage1Model(gateListWidget=gateWidget)

        self.chnlListView.setModel(self.wizChnlModel)
        self.smplListView.setModel(self.wizSmplModel)
        self.gateListView.setModel(self.wizGateModel)

        # UI boxed from page2
        self.p2AssignBoxes = []

        # Manage the button group at page3
        self.meanMethodBG = QtWidgets.QButtonGroup(self)
        for radio in [self.medRadio, self.gMeanRadio, self.meanRadio]:
            self.meanMethodBG.addButton(radio)

        # Save a copy of the channel name dict
        self.chnlNameDict = chnlModel.chnlNameDict

        # connect buttuns on several pages
        self.clearAllPB.clicked.connect(self.handle_P2ClearAll)
        self.load2MainPB.clicked.connect(self.handle_Load2MainComp)
        self.exportPB.clicked.connect(self.handle_ExportMat)
        self.noAutoFCheck.checkStateChanged.connect(self.handle_P3NoAutoFCheck)

        # finish_button = self.button(QtWidgets.QWizard.FinishButton)
        # # finish_button.disconnect()
        # finish_button.clicked.connect(self.handle_WizFinish)

        # other
        self.dir4Save = dir4Save
        self.newCompFlag = False
        self.curMainAutoFluoModel = curMainAutoFluoModel
        self.curMainSpillMatModel = curMainSpillMatModel


    def initializePage(self, id):
        super().initializePage(id)

        if id == 1:
            # The folloing code delet anything in the page2 scrollArea layout, very hecky
            layoutItem = self.wP2Scroll.layout().takeAt(0)
            while not (layoutItem is None):
                if layoutItem.widget() is None:
                    #That's probably the spacer, and the last one.
                    break
                layoutItem.widget().setParent(None)
                layoutItem = self.wP2Scroll.layout().takeAt(0)
            del layoutItem

            # Constract the lists of selected channel/sample/gate
            self.selectedChnlItems = \
                [self.wizChnlModel.item(idx) for idx in range(self.wizChnlModel.rowCount()) if self.wizChnlModel.item(idx).checkState() == Qt.Checked]
            self.selectedSmplItems = \
                [self.wizSmplModel.item(idx) for idx in range(self.wizSmplModel.rowCount()) if self.wizSmplModel.item(idx).checkState() == Qt.Checked]
            self.selectedGateItems = \
                [self.wizGateModel.item(idx) for idx in range(self.wizGateModel.rowCount()) if self.wizGateModel.item(idx).checkState() == Qt.Checked]

            # Model for the comboboxes
            self.selectedSmplModel = QtGui.QStandardItemModel()
            for smplItem in self.selectedSmplItems:
                comboItem = smplItem.clone()
                comboItem.setFlags(comboItem.flags() & (~Qt.ItemIsUserCheckable))
                comboItem.setData(None, role=Qt.CheckStateRole)
                self.selectedSmplModel.appendRow(comboItem)

            # Construct the boxes and add them to the scroll area
            autoFBox = smplAssignBox(self.wP2Scroll, 'auto-fl', self.selectedSmplModel)
            autoFBox.setTitle('No-color control (for auto-fluorescence)')
            self.wP2Scroll.layout().addWidget(autoFBox)
            self.p2AssignBoxes = [autoFBox]
            for chnlItem in self.selectedChnlItems:
                assignUnit = smplAssignBox(self.wP2Scroll, chnlItem.text(), self.selectedSmplModel)
                self.wP2Scroll.layout().addWidget(assignUnit)
                self.p2AssignBoxes.append(assignUnit)
            self.wP2Scroll.layout().addStretch()

        if id == 2:
            self.assignedPairs = []
            self.progressBar.setValue(0)
            for p2AssignBox in self.p2AssignBoxes:
                self.assignedPairs.append((p2AssignBox.chnlName, p2AssignBox.comboBox.currentIndex()))

            if self.assignedPairs[0][1] == -1:
                self.noAutoFCheck.setChecked(True)
            else:
                self.noAutoFCheck.setChecked(False)
            # Force trigger the check handler to show/hide warning label
            self.handle_P3NoAutoFCheck(self.noAutoFCheck.isChecked())
            
            self.noAutoF = self.noAutoFCheck.isChecked()

        if id == 3:
            self.autoFluoTable.setModel(self.preAutoFluoModel)
            self.spillMatTable.setModel(self.preSpillMatModel)

            self.autoFluoTable.selectionModel().selectionChanged.connect(self.handle_SelectSpillMat)

    def validateCurrentPage(self):
        if self.currentId() == 0:
            chnlN = len([self.wizChnlModel.item(idx) for idx in range(self.wizChnlModel.rowCount()) if self.wizChnlModel.item(idx).checkState() == Qt.Checked])
            smplN = len([self.wizSmplModel.item(idx) for idx in range(self.wizSmplModel.rowCount()) if self.wizSmplModel.item(idx).checkState() == Qt.Checked])
            
            if chnlN == 0 or smplN == 0:
                QtWidgets.QMessageBox.critical(self, 
                    'No channel or sample selected!', 'The wizard won\'t be able to work with no sample or channel!')
                return False

            elif smplN - chnlN < 0:
                input = QtWidgets.QMessageBox.warning(self, 
                    'Not enough sample for each channel', 
                    'There is not enough sample for every channel. \nIn the next page, ' + 
                        'channels that don\'t have a sample assigned will be ignored in calculation. Proceed?',
                    buttons=QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No
                    )

                if input == QtWidgets.QMessageBox.Yes:
                    return True
                else:
                    return False
    
            # elif smplN - chnlN < 1:
            #     input = QtWidgets.QMessageBox.warning(self, 
            #         'Not enough sample for each channel and auto-fluoresence', 
            #         'There is not enough sample for every channel and auto-fluoresence. \nIn the next page, ' +
            #             'auto-fluorescence will be ignored if no-color sample is not assigend. Or, ' +
            #             'channels that don\'t have a sample assigned will be ignored in calculation. Proceed?',
            #         buttons=QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No
            #         )

            #     if input == QtWidgets.QMessageBox.Yes:
            #         return True
            #     else:
            #         return False

            else:
                return True

        elif self.currentId() == 1:
            assignedIndices = []
            for p2AssignBox in self.p2AssignBoxes:
                assignedIndices.append(p2AssignBox.comboBox.currentIndex())
            
            assignedIndices = np.array(assignedIndices)
            uniqueSmpl, uniqueSmplCount = np.unique(assignedIndices, return_counts=True)

            if np.array_equal(uniqueSmpl, [-1]):
                QtWidgets.QMessageBox.critical(self, 
                    'Nothing is assigned!', 'Please assign the no-color and single-color samples to the channels')
                return False
            else:
                if np.any(uniqueSmplCount > 1):
                    input = QtWidgets.QMessageBox.warning(self, 
                        'Sample assigned to multiple channels', 
                        'One or more samples are assigned to multiple channels. ' +
                            'This may cause problem in further steps. proceed?',
                        buttons=QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No
                        )

                    if input == QtWidgets.QMessageBox.No:
                        return False

                if np.any(uniqueSmpl == -1):
                    input = QtWidgets.QMessageBox.warning(self, 
                    'Some channel (or auto-fluorescence) have no sample assigned', 
                    'Channels (or auto-fluorescence) without a assigned sample will be ignored during the calculation later. Proceed?',
                    buttons=QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No
                    )

                    if input == QtWidgets.QMessageBox.No:
                        return False
                    
                return True

        # The additional setting and calculation page
        elif self.currentId() == 2:
            self.progressLabel.setText('Starting...')
            self.progressBar.setValue(5)
                        
            gateList = [item.data(0x100) for item in self.selectedGateItems]
            self.chnlKeyList = [item.data(0x101) for item in self.selectedChnlItems]

            self.meanFunc = np.mean
            if self.meanMethodBG.checkedButton is self.medRadio:
                self.meanFunc = np.median
            elif self.meanMethodBG.checkedButton is self.gMeanRadio:
                self.meanFunc = gmean

            self.progressLabel.setText('Appplying gates...')
            self.progressBar.setValue(10)

            # Apply gates to samples
            gatedFCSs = []
            for chnlKey, smplIdx in self.assignedPairs:
                if smplIdx == -1:
                    gatedFCSs.append(None)
                    continue # No sample assigned to this channel
                
                smplFCS = self.selectedSmplItems[smplIdx].data(role=0x100)
                inGateFlag = np.ones(smplFCS.shape[0], dtype=bool)

                for gate in gateList:
                    if gate.chnls[0] in smplFCS.channels and gate.chnls[1] in smplFCS.channels:
                        newFlag = gate.isInsideGate(smplFCS)
                        inGateFlag = np.logical_and(gate.isInsideGate(smplFCS), inGateFlag)

                    else: 
                        warnings.warn('Sample does not have channel(s) for this gate, skipping this gate', RuntimeWarning)
                
                gatedFCS = smplFCS[inGateFlag, :]
                gatedFCSs.append(gatedFCS)

            
            self.progressLabel.setText('Calculating for auto-fluorescence...')
            self.progressBar.setValue(20)

            # Calculate the auto-fluorescence vector from no-color control
            if self.noAutoFCheck.checkState() == 0 and (not self.noAutoF):
                noColorFCS = gatedFCSs[0]
                self.autoFs = self.meanFunc(noColorFCS, 0, keepdims=True)

            # No-color control not available, use the minimal means acoss samples for channels
            else: 
                chnlMeans = [self.meanFunc(smplFCS, 0, keepdims=True) for smplFCS in gatedFCSs if not (smplFCS is None)]
                if len(chnlMeans) < 2:
                    QtWidgets.QMessageBox.critical(self, 
                        'Not enough samples for auto-fluorescence estimation!', 
                        'At least two single-color samples are required to estimate the auto-fluorescence. ' \
                        'Please assign a no-color sample or more single-color samples.',
                        buttons=QtWidgets.QMessageBox.Ok
                        )
                    return False
                
                self.autoFs = FCSData_ef.fromArray(chnlMeans[0], np.min(chnlMeans, axis=0))

                # Set the autofluorescence of channels without assigned sample to 0. We do not estimate channels not selected
                for chnlKey in self.autoFs.channels:
                    if chnlKey not in self.chnlKeyList:
                        self.autoFs[0, chnlKey] = 0

            self.progressLabel.setText('Calculating for spill matrix...')
            self.progressBar.setValue(30)

            smplSpills = dict()
            for idx, chnlKey in enumerate(self.chnlKeyList):
                smplIdx = self.assignedPairs[idx + 1][1]

                # Prepare the spillover array, diagonal is 1
                spills = np.zeros((1, len(self.chnlKeyList)))
                spills[0, idx] = 1.0 # diagonal is 1

                # If sample assigned to this channel: calculate the spillover from this channel
                if gatedFCSs[idx+1] is not None:                    
                    gatedFCS = gatedFCSs[idx+1]

                    for jdx, chnlKey2 in enumerate(self.chnlKeyList):
                        if chnlKey2 == chnlKey:
                            continue # skip self
                        else:
                            x = np.array(gatedFCS[:, chnlKey] - self.autoFs[0, chnlKey])
                            y = np.array(gatedFCS[:, chnlKey2] - self.autoFs[0, chnlKey2])

                            # Remove extreme values after autofluorescence compensation
                            x_low, x_high = np.percentile(x, [1, 99])
                            y_low, y_high = np.percentile(y, [1, 99])
                            mask = (x >= x_low) & (x <= x_high) & (y >= y_low) & (y <= y_high)
                            x = x[mask]
                            y = y[mask]

                            reg_res = linregress(x, y, alternative='greater')

                        spills[0, jdx] = max(reg_res.slope, 0) # avoid over-estimation

                    smplSpills[chnlKey] = spills

                # If no sample assigned to this channel
                else:
                    smplSpills[chnlKey] = spills # keep the spill as identity

                self.progressLabel.setText('Finishing calculation on spill matrix: ({0}/{1})'.format(idx, len(self.chnlKeyList)))
                self.progressBar.setValue(20 + 70 * ((idx + 1) / len(self.chnlKeyList)))

            self.progressLabel.setText('Preparing autofluorescence matrix for preview')
            self.progressBar.setValue(80)

            self.preAutoFluoModel = autoFluoTbModel(self.chnlKeyList, [self.chnlNameDict[chnl] for chnl in self.chnlKeyList], editable=False)
            self.preSpillMatModel = spillMatTbModel(self.chnlKeyList, editable=False)

            autoDF = pd.DataFrame(self.autoFs.T, index=(self.autoFs.channels))
            self.preAutoFluoModel.loadDF(autoDF)

            self.progressLabel.setText('Preparing spill matrix for preview')
            self.progressBar.setValue(90)
            
            spillDF = pd.DataFrame(columns=self.chnlKeyList)
            for idx, chnlKey in enumerate(self.chnlKeyList):
                if smplSpills[chnlKey] is None:
                    spillDF.loc[chnlKey] = [0] * idx + [1] + [0] * (len(self.chnlKeyList) - idx - 1)
                else:
                    spillDF.loc[chnlKey] = smplSpills[chnlKey][0]
            self.preSpillMatModel.loadMatDF(spillDF * 100)

            self.progressLabel.setText('Done!')
            self.progressBar.setValue(100)
            self.newCompFlag = True

            return True
        
        elif self.currentId() == 3:
            self.handle_Load2MainComp()
            return True
        else: 
            return True

    def handle_P2ClearAll(self):
        for child in self.wP2Scroll.children():
            if isinstance(child, smplAssignBox):
                child.handle_Clear()

    def handle_P3NoAutoFCheck(self, checked):
        self.noAutoF = checked
        if hasattr(self, 'assignedPairs'):
            if self.assignedPairs[0][1] == -1 and checked == Qt.Unchecked:
                self.p3EstiWarningLabel.setVisible(True)
            else:
                self.p3EstiWarningLabel.setVisible(False)
        else:
            return
                

    def handle_SelectSpillMat(self, selected):
        index = selected.indexes()[0]
        self.spillMatTable.selectRow(index.row())
    
    def handle_Load2MainComp(self):
        if not (self.curMainSpillMatModel.isIdentity() and self.curMainAutoFluoModel.isZeros()):
            input = QtWidgets.QMessageBox.warning(self, 
                    'Overwrite current compensation?',
                    'The current compensation is not zero/identity! This action will overwrite some part of the current one. ' +
                    'Yes to proceed.',
                    buttons=QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.Cancel
                    )
            if input == QtWidgets.QMessageBox.Cancel:
                return
            
        self.curMainAutoFluoModel.loadDF(self.preAutoFluoModel.dfData)
        self.curMainSpillMatModel.loadMatDF(self.preSpillMatModel.dfData)
        self.newCompFlag = False

    def handle_ExportMat(self):
        jDict = dict()
        jDict['useAutoFluo'] = None
        
        jDict['keyList'] = self.chnlKeyList
        jDict['autoFluo'] = self.preAutoFluoModel.to_json()
        jDict['spillMat'] = self.preSpillMatModel.to_json()

        saveFileDir, _ = QtWidgets.QFileDialog.getSaveFileName(self, 'Export compensation', self.dir4Save, filter='*.efComp')
        if not saveFileDir:
            return

        with open(saveFileDir, 'w+') as f:
            json.dump(jDict, f, sort_keys=True, indent=4)
        self.newCompFlag = False


# UI box on page2
class smplAssignBox(QtWidgets.QGroupBox):

    def __init__(self, parent, chnlName, comboModel):
        super().__init__(chnlName, parent)
        UiLoader().loadUi('CompWizard_SmplAssignBox.ui', self)
        
        self.chnlName = chnlName
        self.setTitle('Single-color sample for {0}'.format(chnlName))
        self.comboBox.setModel(comboModel)
        self.comboBox.setCurrentIndex(-1)

        self.clearPB.clicked.connect(self.handle_Clear)

    def handle_Clear(self):
        self.comboBox.setCurrentIndex(-1)


class wPage1Model(QtGui.QStandardItemModel):
    def __init__(self, smplTreeWidget=None, gateListWidget=None, chnlItemModel=None):
        super().__init__()

        items = []
        if smplTreeWidget is not None:
            # Copying items fror smplListWidget
            for idx in range(smplTreeWidget.topLevelItemCount()):
                newItem = QtGui.QStandardItem(smplTreeWidget.topLevelItem(idx).data(0, Qt.DisplayRole))
                newItem.setData(smplTreeWidget.topLevelItem(idx).data(0, 0x100), 0x100)
                newItem.setData(smplTreeWidget.topLevelItem(idx).data(0, 1), 1)
                newItem.setCheckState(Qt.Unchecked)
                items.append(newItem)

        elif gateListWidget is not None:
            # Copying items fror gatelListWidget
            for idx in range(gateListWidget.count()):
                newItem = QtGui.QStandardItem(gateListWidget.item(idx).data(Qt.DisplayRole))
                newItem.setData(gateListWidget.item(idx).data(0x100), 0x100)
                newItem.setData(gateListWidget.item(idx).data(1), 1)
                newItem.setCheckState(gateListWidget.item(idx).checkState())
                items.append(newItem)
            
        elif chnlItemModel is not None:
            # Copying items from standardItemModel / (channels)
            for idx in range(chnlItemModel.rowCount()):
                items.append(chnlItemModel.item(idx).clone())
                items[-1].setCheckState(Qt.Unchecked)
        else:
            return

        for newItem in items:
            newItem.setFlags(newItem.flags() | Qt.ItemIsUserCheckable)
            newItem.setFlags(newItem.flags() & (~Qt.ItemIsEditable))
            self.appendRow(newItem)


if __name__ == '__main__':

    app = QtWidgets.QApplication(sys.argv)

    dialog = compWizard(None)
    dialog.show()
    sys.exit(app.exec_())