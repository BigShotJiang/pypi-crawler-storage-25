import sys
from PySide6 import QtWidgets, QtCore, QtGui
from matplotlib.colors import to_hex
from os import path, getcwd

import pandas as pd
import numpy as np
import csv
import io
from xlsxwriter.utility import xl_col_to_name

from .backend.qtModels import pandasTableModel
from .backend.plotWidgets import cachedStats
from .uiDesigns import UiLoader

intFormater = '{:.0f}'.format
percFormater = '{:.2%}'.format
valFormater = '{:.4e}'.format

class statWindow(QtWidgets.QWidget):
    def __init__(self, sessionDir, curGateItems_func, curQSItem_func) -> None:

        super().__init__()
        UiLoader().loadUi('StatWindow.ui', self)

        self.statusBar = QtWidgets.QStatusBar(self)
        self.layout().addWidget(self.statusBar)

        self.sessionDir = sessionDir
        self.dataDF = pd.DataFrame()
        self.displayDF = pd.DataFrame()

        self.curGateItems = curGateItems_func
        self.curQSItem = curQSItem_func
        self.curFormaterList = []

        self.statTabelModel = pandasTableModel(self.displayDF)
        self.tableView.setModel(self.statTabelModel)
        self.tableView.horizontalHeader().setDefaultAlignment(QtCore.Qt.AlignLeft)
        self.tableView.verticalHeader().setDefaultAlignment(QtCore.Qt.AlignRight)

        self.exportStatsPB.clicked.connect(self.handle_ExportStats)
        self.copyTablePB.clicked.connect(self.handle_CopyEntireTable)

        self.tableView.installEventFilter(self)

    def updateStat(self, cachedPlotStats:cachedStats, forceUpdate=False):

        if (not self.isVisible()) and (not forceUpdate):
            return

        if cachedPlotStats.smplNumber == 0:
            self.dataDF = pd.DataFrame()
            self.displayDF = pd.DataFrame()

            self.statTabelModel = pandasTableModel(self.displayDF)
            self.tableView.setModel(self.statTabelModel)

            return

        firstItem = cachedPlotStats.smplItems[0]
        chnls = cachedPlotStats.chnls

        formaterList = [intFormater, percFormater]
        newDF = pd.DataFrame(columns=['Cell number', '% of total'], 
                             index=[smplItem.displayName for smplItem in cachedPlotStats.smplItems])

        newDF['Cell number'] = [gatedSmpl.shape[0] for gatedSmpl in cachedPlotStats.gatedSmpls]

        percs = []
        for idx in range(cachedPlotStats.smplNumber):
            percs.append(cachedPlotStats.gatedSmpls[idx].shape[0] / cachedPlotStats.smplItems[idx].fcsSmpl.shape[0])
        newDF['% of total'] = percs
        
        for idx, gateItem in enumerate(self.curGateItems()):
            newDF['% of parent in: \n{0}'.format(gateItem.text())] =  [gatedFrac[idx] for gatedFrac in cachedPlotStats.gatedFracs]
            formaterList.append(percFormater)

        if not (cachedPlotStats.selectedGateItem is None):
            newDF['% of parent in: \n{0} (selected)'.format(cachedPlotStats.selectedGateItem.text())] = [gatedFrac[-1] for gatedFrac in cachedPlotStats.gatedFracs]
            formaterList.append(percFormater)
                
        for chnl in chnls:
            newDF['Median of \n{0}:{1}'.format(chnl, firstItem.chnlNameDict[chnl])] = [np.median(gatedSmpl[:, chnl]) for gatedSmpl in cachedPlotStats.gatedSmpls]
            newDF['Mean of \n{0}:{1}'.format(chnl, firstItem.chnlNameDict[chnl])] = [np.mean(gatedSmpl[:, chnl]) for gatedSmpl in cachedPlotStats.gatedSmpls]

            formaterList += [valFormater] * 2
            
        if len(cachedPlotStats.splitFracs) > 0:
            newDF['% of cells in split: \nleft'] = [splitFrac[0] for splitFrac in cachedPlotStats.splitFracs]
            newDF['% of cells in split: \nright'] = [splitFrac[1] for splitFrac in cachedPlotStats.splitFracs]
            
            formaterList += [percFormater] * 2

        elif len(cachedPlotStats.quadFracs) > 0:
            newDF['% of cells in quad: \nlower left'] = [quadFrac[0] for quadFrac in cachedPlotStats.quadFracs]
            newDF['% of cells in quad: \nupper left'] = [quadFrac[1] for quadFrac in cachedPlotStats.quadFracs]
            newDF['% of cells in quad: \nlower right'] = [quadFrac[2] for quadFrac in cachedPlotStats.quadFracs]
            newDF['% of cells in quad: \nupper right'] = [quadFrac[3] for quadFrac in cachedPlotStats.quadFracs]

            formaterList += [percFormater] * 4


        # save the origin DF (number before conversion to str), and formatter
        self.dataDF = newDF
        self.curFormaterList = formaterList

        # Create the displayDF for display, numbers are convereted to strings
        self.displayDF = pd.DataFrame()
        for idx, col in enumerate(newDF.columns):
            self.displayDF[col] = newDF.iloc[:, idx].apply(formaterList[idx])
        
        self.statTabelModel = pandasTableModel(self.displayDF)
        self.tableView.setModel(self.statTabelModel)
        pass
    
    def handle_ExportStats(self):
        saveFileDir, _ = QtWidgets.QFileDialog.getSaveFileName(self, 'Export stats', self.sessionDir, filter='*.xlsx')
        if not saveFileDir:
            return
        elif not saveFileDir.endswith('.xlsx'):
            saveFileDir += '.xlsx'

        try:
            with pd.ExcelWriter(saveFileDir, engine='xlsxwriter') as writer:
                self.dataDF.to_excel(excel_writer=writer, sheet_name='stats')
                #format the fractions as percentage in excel
                percFmt = writer.book.add_format({'num_format': '0.00%'})

                for idx, formater in enumerate(self.curFormaterList):
                    if formater is percFormater:
                        # +1 because excel's first column is index (sample names)
                        writer.sheets['stats'].set_column(idx + 1, idx + 1, cell_format=percFmt)
        
        except PermissionError:
            QtWidgets.QMessageBox.warning(self, 'Permission Error', 'Please ensure you have writing permission to this directory, and the file is not opened elsewhere.')

        except BaseException as err:
            QtWidgets.QMessageBox.warning(self, 'Unexpected Error', 'Message: {0}'.format(err))

        pass

    def handle_CopyEntireTable(self):
        # this parts enables copy entire table.
        stream = io.StringIO()
        self.displayDF.to_csv(stream, sep='\t', index=True, header=True)
        QtGui.QClipboard().setText(stream.getvalue())

        self.statusBar.showMessage('Table copied to clipboard', 3000)
        return

    def eventFilter(self, source, event):

        if (event.type() == QtCore.QEvent.KeyPress and event.matches(QtGui.QKeySequence.Copy)):
            self.copySelection()
            return True

        return super().eventFilter(source, event)

    def copySelection(self):
        # this parts enables copy multiple cells.

        selection = self.tableView.selectedIndexes()
        if selection:
            rows = sorted(index.row() for index in selection)
            columns = sorted(index.column() for index in selection)
            rowcount = rows[-1] - rows[0] + 1
            colcount = columns[-1] - columns[0] + 1
            table = [[''] * colcount for _ in range(rowcount)]
            for index in selection:
                row = index.row() - rows[0]
                column = index.column() - columns[0]
                table[row][column] = index.data()
            stream = io.StringIO()
            csv.writer(stream, delimiter='\t').writerows(table)
            QtGui.QClipboard().setText(stream.getvalue())
        return

if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    window = statWindow('./demoSamples')
    window.show()
    sys.exit(app.exec_())