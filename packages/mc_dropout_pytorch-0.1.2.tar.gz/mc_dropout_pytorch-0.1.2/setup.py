from setuptools import setup, find_packages

exec(open('mc_dropout_pytorch/version.py').read())

setup(
    name = 'mc-dropout-pytorch',
    packages = find_packages(),
    version = __version__,
    license = 'MIT',
    description = 'MC Dropout (Gal & Ghahramani, 2016) - Pytorch',
    long_description = open('README.md').read(),
    long_description_content_type = 'text/markdown',
    author = 'MohamedFarag21',
    author_email = 'mibrahi2@gmail.com',
    url = 'https://github.com/lucidrains/mc-dropout-pytorch',
    keywords = [
        'artificial intelligence',
        'deep learning',
        'bayesian deep learning',
        'uncertainty estimation',
        'monte carlo dropout',
    ],
    install_requires = [
        'accelerate>=1.0',
        'einops>=0.8',
        'ema-pytorch>=0.7',
        'torch>=2.0',
        'tqdm',
    ],
    classifiers = [
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
    ],
)
