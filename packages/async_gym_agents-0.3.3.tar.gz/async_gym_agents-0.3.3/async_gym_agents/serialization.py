from __future__ import annotations

import pickle
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, BinaryIO, Generic, TypeVar

T = TypeVar("T")
FileLike = str | Path | BinaryIO


class Serializer(ABC, Generic[T]):
    @abstractmethod
    def dumps(self, value: T) -> bytes:
        raise NotImplementedError()

    @abstractmethod
    def loads(self, data: bytes) -> T:
        raise NotImplementedError()

    def dump(self, value: T, destination: FileLike) -> None:
        payload = self.dumps(value)
        if hasattr(destination, "write"):
            destination.write(payload)
            return

        Path(destination).write_bytes(payload)

    def load(self, source: FileLike) -> T:
        if hasattr(source, "read"):
            data = source.read()
        else:
            data = Path(source).read_bytes()
        return self.loads(data)


class PickleSerializer(Serializer[Any]):
    def __init__(self, protocol: int = pickle.HIGHEST_PROTOCOL):
        self.protocol = protocol

    def dumps(self, value: Any) -> bytes:
        return pickle.dumps(value, protocol=self.protocol)

    def loads(self, data: bytes) -> Any:
        return pickle.loads(data)
