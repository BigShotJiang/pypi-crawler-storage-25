# Copyright (C) 2025  The Software Heritage developers
# See the AUTHORS file at the top-level directory of this distribution
# License: GNU Affero General Public License version 3, or any later version
# See top-level LICENSE file for more information
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("swh_coarnotify_server", "0001_initial"),
    ]

    operations = [
        migrations.AddField(
            model_name="inboundnotification",
            name="process_task_id",
            field=models.BigIntegerField(null=True),
        ),
        migrations.AddField(
            model_name="outboundnotification",
            name="send_task_id",
            field=models.BigIntegerField(null=True),
        ),
    ]
