# Copyright (C) 2026  The Software Heritage developers
# See the AUTHORS file at the top-level directory of this distribution
# License: GNU Affero General Public License version 3, or any later version
# See top-level LICENSE file for more information
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("swh_coarnotify_server", "0002_tasks_id"),
    ]

    operations = [
        migrations.AddField(
            model_name="inboundnotification",
            name="handler",
            field=models.CharField(
                blank=True, choices=[("mention", "Mention")], max_length=20
            ),
        ),
        migrations.AlterField(
            model_name="inboundnotification",
            name="status",
            field=models.CharField(
                choices=[
                    ("pending", "Pending"),
                    ("rejected", "Rejected"),
                    ("accepted", "Accepted"),
                    ("processed", "Processed"),
                    ("unprocessable", "Unprocessable"),
                    ("retry", "Retry"),
                ],
                default="pending",
                max_length=20,
            ),
        ),
        migrations.AlterField(
            model_name="outboundnotification",
            name="status",
            field=models.CharField(
                choices=[
                    ("pending", "Pending"),
                    ("rejected", "Rejected"),
                    ("accepted", "Accepted"),
                    ("processed", "Processed"),
                    ("unprocessable", "Unprocessable"),
                    ("retry", "Retry"),
                ],
                default="pending",
                max_length=20,
            ),
        ),
    ]
