# Copyright (C) 2026  The Software Heritage developers
# See the AUTHORS file at the top-level directory of this distribution
# License: GNU Affero General Public License version 3, or any later version
# See top-level LICENSE file for more information
from django.apps.registry import Apps
from django.db import migrations, models
from django.db.backends.base.schema import BaseDatabaseSchemaEditor


def _fill_inbox_urls(apps: Apps, schema_editor: BaseDatabaseSchemaEditor) -> None:
    """Fill existing ``OutboundNotification.inbox`` values with senders inbox.

    Args:
        apps: apps registry
        schema_editor: schema editor
    """
    OutboundNotification = apps.get_model(
        "swh_coarnotify_server", "OutboundNotification"
    )
    for outbound in OutboundNotification.objects.all():
        inbound = outbound.in_reply_to
        if not inbound or not inbound.sender:
            outbound.inbox = "http://missing"
        else:
            outbound.inbox = inbound.sender.inbox
        outbound.save()


class Migration(migrations.Migration):
    """A 3 steps migration to add inbox urls to outbound notifications.

    All our existing outbound notifications are replies to existing inbound ones.
    We use a data migration to fill the existing outbound notifications with inbox
    URLS matching from one from the sender.
    """

    dependencies = [
        ("swh_coarnotify_server", "0003_handler"),
    ]

    operations = [
        migrations.AddField(
            model_name="outboundnotification",
            name="inbox",
            field=models.URLField(null=True),
        ),
        migrations.RunPython(_fill_inbox_urls, migrations.RunPython.noop),
        migrations.AlterField(
            model_name="outboundnotification",
            name="inbox",
            field=models.URLField(null=False),
        ),
    ]
