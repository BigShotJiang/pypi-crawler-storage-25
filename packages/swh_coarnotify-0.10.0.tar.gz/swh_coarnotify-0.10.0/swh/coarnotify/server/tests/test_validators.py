# Copyright (C) 2026  The Software Heritage developers
# See the AUTHORS file at the top-level directory of this distribution
# License: GNU Affero General Public License version 3, or any later version
# See top-level LICENSE file for more information


import pytest
from rdflib import BNode, URIRef
from rest_framework import serializers

from swh.coarnotify.namespaces import AS, CN, LDP, RDF
from swh.coarnotify.server.validators import (
    url_match,
    validate_mention,
    validate_notification,
)


@pytest.mark.parametrize(
    "url1,url2,expected",
    [
        ("https://inbox.swh.network", "https://inbox.swh.network", True),
        ("https://inbox.swh.network/", "https://inbox.swh.network", True),
        ("https://inbox.swh.network", "https://inbox.swh.network/", True),
        ("https://inbox.swh.network/a", "https://inbox.swh.network/", False),
    ],
)
def test_url_match(url1, url2, expected):
    assert url_match(url1, url2) is expected


def test_validate_notification(in_id, in_graph):
    assert validate_notification(in_graph, in_id, "http://testserver/") == {
        URIRef(CN.RelationshipAction),
        URIRef(AS.Announce),
    }


def test_validate_notification_type(in_id, in_graph):
    in_graph.remove((in_id, RDF.type, None))
    with pytest.raises(serializers.ValidationError) as excinfo:
        validate_notification(in_graph, in_id, "http://testserver/")
    assert (
        "The notification must have a RDF `type`"
        in excinfo.value.args[0][0].detail["type"]
    )


def test_validate_notification_origin(in_id, in_graph):
    msg = "The notification must have one Activity Streams `origin`"

    # no origin
    in_graph.remove((in_id, AS.origin, None))
    with pytest.raises(serializers.ValidationError) as excinfo:
        validate_notification(in_graph, in_id, "http://testserver/")
    assert msg in excinfo.value.args[0][0].detail["origin"]

    # more than one origin
    for origin_id in [
        URIRef("https://origin1.localhost"),
        URIRef("https://origin2.localhost"),
    ]:
        in_graph.add((in_id, AS.origin, origin_id))
        in_graph.add((origin_id, RDF.type, AS.Announce))

    with pytest.raises(serializers.ValidationError) as excinfo:
        validate_notification(in_graph, in_id, "http://testserver/")
    assert msg in excinfo.value.args[0][0].detail["origin"]


def test_validate_notification_origin_type(in_id, in_graph):
    origin_id = in_graph.value(in_id, AS.origin)
    in_graph.remove((origin_id, RDF.type, None))
    with pytest.raises(serializers.ValidationError) as excinfo:
        validate_notification(in_graph, in_id, "http://testserver/")
    assert (
        "The Activity Streams `origin` must have a RDF `type`"
        in excinfo.value.args[0][0].detail["origin"]
    )


def test_validate_notification_target(in_id, in_graph):
    msg = "The notification must have one Activity Streams `target`"

    # no target
    in_graph.remove((in_id, AS.target, None))
    with pytest.raises(serializers.ValidationError) as excinfo:
        validate_notification(in_graph, in_id, "http://testserver/")
    assert msg in excinfo.value.args[0][0].detail["target"]

    # more than one target
    for target_id in [
        URIRef("https://target1.localhost"),
        URIRef("https://target2.localhost"),
    ]:
        in_graph.add((in_id, AS.target, target_id))
        in_graph.add((target_id, RDF.type, AS.Announce))

    with pytest.raises(serializers.ValidationError) as excinfo:
        validate_notification(in_graph, in_id, "http://testserver/")
    assert msg in excinfo.value.args[0][0].detail["target"]


def test_validate_notification_target_type(in_id, in_graph):
    target_id = in_graph.value(in_id, AS.target)
    in_graph.remove((target_id, RDF.type, None))
    with pytest.raises(serializers.ValidationError) as excinfo:
        validate_notification(in_graph, in_id, "http://testserver/")
    assert (
        "The Activity Streams `target` must have a RDF `type`"
        in excinfo.value.args[0][0].detail["target"]
    )


def test_validate_notification_target_inbox(in_id, in_graph):
    target_id = in_graph.value(in_id, AS.target)

    # No inbox
    in_graph.remove((target_id, LDP.inbox, None))
    with pytest.raises(serializers.ValidationError) as excinfo:
        validate_notification(in_graph, in_id, "http://testserver/")
    assert (
        "The Activity Streams `target` must have a LDN `inbox`"
        in excinfo.value.args[0][0].detail["target"]
    )

    # Wrong inbox
    in_graph.add((target_id, LDP.inbox, URIRef("http://not-testserver/")))
    with pytest.raises(serializers.ValidationError) as excinfo:
        validate_notification(in_graph, in_id, "http://testserver/")
    assert (
        "http://testserver/ does not match "
        "the Activity Streams `target` `inbox` http://not-testserver/"
    ) in excinfo.value.args[0][0].detail["target"]


def test_validate_notification_object(in_id, in_graph):
    msg = "The notification must have one Activity Streams `object`"

    # no object
    in_graph.remove((in_id, AS.object, None))
    with pytest.raises(serializers.ValidationError) as excinfo:
        validate_notification(in_graph, in_id, "http://testserver/")
    assert msg in excinfo.value.args[0][0].detail["object"]

    # more than one object
    for object_id in [
        URIRef("https://object1.localhost"),
        URIRef("https://object2.localhost"),
    ]:
        in_graph.add((in_id, AS.object, object_id))
    with pytest.raises(serializers.ValidationError) as excinfo:
        validate_notification(in_graph, in_id, "http://testserver/")
    assert msg in excinfo.value.args[0][0].detail["object"]

    # no object id
    in_graph.remove((in_id, AS.object, None))
    in_graph.add((in_id, AS.object, BNode()))
    with pytest.raises(serializers.ValidationError) as excinfo:
        validate_notification(in_graph, in_id, "http://testserver/")
    assert (
        "The Activity Streams `object` must have an `id`"
        in excinfo.value.args[0][0].detail["object"]
    )


def test_validate_mention(in_id, in_graph, default_origin):
    assert validate_mention(in_graph, in_id) == default_origin.url


def test_validate_mention_context(in_id, in_graph):
    msg = "The notification must have one Activity Streams `context`"
    # no context
    in_graph.remove((in_id, AS.context, None))
    with pytest.raises(ValueError, match=msg):
        validate_mention(in_graph, in_id)

    # more than one context
    for context_id in [
        URIRef("https://context1.localhost"),
        URIRef("https://context2.localhost"),
    ]:
        in_graph.add((in_id, AS.context, context_id))
    with pytest.raises(ValueError, match=msg):
        validate_mention(in_graph, in_id)

    # no context id
    in_graph.remove((in_id, AS.context, None))
    in_graph.add((in_id, AS.context, BNode()))
    with pytest.raises(
        ValueError, match="The Activity Streams `context` must have an `id`"
    ):
        validate_mention(in_graph, in_id)

    # context id is not https?://
    in_graph.remove((in_id, AS.context, None))
    in_graph.add((in_id, AS.context, URIRef("ftp://context1.localhost")))
    with pytest.raises(
        ValueError, match="The Activity Streams `context` `id` is not a valid URL"
    ):
        validate_mention(in_graph, in_id)


def test_validate_mention_object_type(in_id, in_graph):
    object_id = in_graph.value(in_id, URIRef(AS.object))
    msg = "The Activity Streams `object` must have an Activity Streams Object `type`"
    in_graph.set((object_id, RDF.type, RDF.Statement))
    with pytest.raises(ValueError, match=msg):
        validate_mention(in_graph, in_id)


@pytest.mark.parametrize(
    "prop",
    ["subject", "relationship", "object"],
)
def test_validate_mention_object_triple(in_id, in_graph, prop):
    object_id = in_graph.value(in_id, URIRef(AS.object))
    msg = f"The Activity Streams `object` must have one Activity Streams `{prop}`"
    # missing property
    in_graph.remove((object_id, AS[prop], None))
    with pytest.raises(ValueError, match=msg):
        validate_mention(in_graph, in_id)
    # more than one property
    for prop_id in [
        URIRef("https://prop1.localhost"),
        URIRef("https://prop2.localhost"),
    ]:
        in_graph.add((object_id, AS[prop], prop_id))
    with pytest.raises(ValueError, match=msg):
        validate_mention(in_graph, in_id)


def test_validate_mention_returns_object_object(in_id, in_graph):
    object_id = in_graph.value(in_id, URIRef(AS.object))
    in_graph.set((object_id, AS.object, URIRef("https://localhost")))
    assert validate_mention(in_graph, in_id) == "https://localhost"
