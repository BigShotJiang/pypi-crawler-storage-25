# Copyright (C) 2025 - 2026  The Software Heritage developers
# See the AUTHORS file at the top-level directory of this distribution
# License: GNU Affero General Public License version 3, or any later version
# See top-level LICENSE file for more information

from http import HTTPStatus
import uuid

import pytest
from rdflib import URIRef
from rdflib.namespace import RDF
from rest_framework import serializers

from swh.coarnotify.namespaces import AS, CN
from swh.coarnotify.server.models import Handlers, OutboundNotification, Statuses
from swh.coarnotify.server.utils import (
    context_processor,
    create_accept_cn,
    create_reject_cn,
    create_unprocessable_cn,
    get_handler_from_types,
    get_in_reply_to,
    get_notification_urn,
    inbox_headers,
    reject,
    send_cn,
    unprocessable,
    uuid_from_urn,
)


@pytest.mark.django_db(transaction=True)
def test_send_cn_success(requests_mock, run_tasks):
    requests_mock.post("http://original.localhost", status_code=HTTPStatus.CREATED)

    notification = OutboundNotification.objects.create(
        payload={"target": {"inbox": "http://original.localhost"}}
    )
    previous_save_stamp = notification.updated_at

    send_cn(notification)
    assert notification.status == Statuses.PENDING
    run_tasks()
    notification.refresh_from_db()

    assert notification.status == Statuses.PROCESSED
    assert notification.updated_at > previous_save_stamp


@pytest.mark.django_db(transaction=True)
def test_send_cn_failure(settings, requests_mock, run_tasks):
    settings.CN_CLIENT = "swh.coarnotify.client.COARNotifyClient"
    requests_mock.post(
        "http://original.localhost", status_code=HTTPStatus.INSUFFICIENT_STORAGE
    )

    notification = OutboundNotification.objects.create(
        payload={"test": True}, inbox="http://original.localhost"
    )
    previous_save_stamp = notification.updated_at

    send_cn(notification)
    assert notification.status == Statuses.PENDING
    run_tasks(0)  # we know the sending task will fail
    notification.refresh_from_db()

    # send_outbound_cn will mark the notification to retry after the first failure
    assert notification.status == Statuses.RETRY
    assert "507 Server Error" in notification.error_message
    assert notification.updated_at > previous_save_stamp


def test_create_accept_cn(inbound_notification, settings):
    notification = create_accept_cn(inbound_notification)

    assert notification.pk != inbound_notification.pk
    assert notification.payload["@context"] == [
        "https://www.w3.org/ns/activitystreams",
        "https://coar-notify.net",
    ]
    assert notification.payload["id"] == f"urn:uuid:{notification.pk}"
    assert notification.payload["inReplyTo"] == f"urn:uuid:{inbound_notification.pk}"
    assert notification.payload["type"] == "Accept"

    assert notification.payload["object"]["id"] == f"urn:uuid:{inbound_notification.pk}"
    assert notification.in_reply_to == inbound_notification
    assert notification.inbox == inbound_notification.raw_payload["origin"]["inbox"]


def test_create_accept_cn_summary(inbound_notification):
    notification = create_accept_cn(inbound_notification, "test summary")
    assert notification.payload["summary"] == "test summary"


def test_create_unprocessable_cn(inbound_notification, settings):
    inbound_notification.error_message = "unprocessable summary"
    notification = create_unprocessable_cn(inbound_notification)

    assert notification.pk != inbound_notification.pk
    assert notification.payload["@context"] == [
        "https://www.w3.org/ns/activitystreams",
        "https://coar-notify.net",
    ]
    assert notification.payload["id"] == f"urn:uuid:{notification.pk}"
    assert notification.payload["inReplyTo"] == f"urn:uuid:{inbound_notification.pk}"
    assert notification.payload["type"] == [
        "Flag",
        "UnprocessableNotification",
    ]
    assert notification.payload["object"]["id"] == f"urn:uuid:{inbound_notification.pk}"
    assert notification.payload["summary"] == "unprocessable summary"
    assert notification.in_reply_to == inbound_notification
    assert notification.inbox == inbound_notification.raw_payload["origin"]["inbox"]


def test_create_reject_cn(inbound_notification, settings):
    inbound_notification.error_message = "reject summary"
    notification = create_reject_cn(inbound_notification)

    assert notification.pk != inbound_notification.pk
    assert notification.payload["@context"] == [
        "https://www.w3.org/ns/activitystreams",
        "https://coar-notify.net",
    ]
    assert notification.payload["id"] == f"urn:uuid:{notification.pk}"
    assert notification.payload["inReplyTo"] == f"urn:uuid:{inbound_notification.pk}"
    assert notification.payload["type"] == "Reject"

    assert notification.payload["object"]["id"] == f"urn:uuid:{inbound_notification.pk}"
    assert notification.payload["summary"] == "reject summary"
    assert notification.in_reply_to == inbound_notification
    assert notification.inbox == inbound_notification.raw_payload["origin"]["inbox"]


@pytest.mark.parametrize(
    "urn",
    [
        "http",
        "urn:issn:0767-7316",
        "urn:uuid:1234",
        "test:uuid:00000000-0000-0000-0000-000000000000",
        "",
        None,
    ],
)
def test_invalid_uuid_from_urn(urn):
    with pytest.raises(ValueError):
        uuid_from_urn(urn)


def test_uuid_from_urn():
    assert uuid_from_urn("urn:uuid:00000000-0000-0000-0000-000000000000") == uuid.UUID(
        "00000000-0000-0000-0000-000000000000"
    )


@pytest.mark.django_db(transaction=True)
def test_unprocessable(inbound_notification, swh_scheduler):
    unprocessable(inbound_notification, "my error")
    assert inbound_notification.status == Statuses.UNPROCESSABLE
    assert inbound_notification.error_message == "my error"
    assert inbound_notification.replied_by


@pytest.mark.django_db(transaction=True)
def test_reject(inbound_notification, swh_scheduler):
    reject(inbound_notification, "my error")
    assert inbound_notification.status == Statuses.REJECTED
    assert inbound_notification.error_message == "my error"
    assert inbound_notification.replied_by


def test_inbox_headers(rf):
    request = rf.get("/")
    assert inbox_headers(request) == {
        "Link": ('<http://testserver/>; rel="http://www.w3.org/ns/ldp#inbox')
    }


def test_context_processor(rf, settings):
    request = rf.get("/")
    settings.CN_VERSION = "s.w.h"
    context = context_processor(request)
    assert context["CN_VERSION"] == "s.w.h"


def test_get_in_reply_to(in_id, in_graph, outbound_notification):
    # no reply to
    in_graph.remove((in_id, AS.inReplyTo, None))
    assert get_in_reply_to(in_graph, in_id) is None
    # not a UUID
    in_graph.add((in_id, AS.inReplyTo, URIRef("https://localhost")))
    assert get_in_reply_to(in_graph, in_id) is None
    # valid UUID
    in_reply_to = URIRef(f"urn:uuid:{outbound_notification.pk}")
    in_graph.set((in_id, AS.inReplyTo, in_reply_to))
    assert get_in_reply_to(in_graph, in_id) == outbound_notification


def test_get_notification_urn(inbound_notification):
    document = inbound_notification.payload

    with pytest.raises(
        serializers.ValidationError,
        match=(
            "A COAR Notification with the id 00000000-0000-0000-0000-000000000000 "
            "has already been handled"
        ),
    ):
        get_notification_urn(document)

    document[0].pop("@id")
    with pytest.raises(
        serializers.ValidationError, match="The notification must have an ID"
    ):
        get_notification_urn(document)

    document[0]["@id"] = "http://localhost"
    with pytest.raises(
        serializers.ValidationError, match="The notification ID is invalid"
    ):
        get_notification_urn(document)
    document[0]["@id"] = f"urn:uuid:{uuid.uuid4()}"
    assert get_notification_urn(document) == document[0]["@id"]


@pytest.mark.parametrize(
    "types,expected",
    [
        ([AS.Announce, CN.RelationshipAction], Handlers.MENTION),
        ([AS.Announce, CN.EndorsementAction], None),
        ([AS.Announce, CN.ReviewAction], None),
    ],
)
def test_get_handler_from_types(in_id, in_graph, types, expected):
    in_graph.remove((in_id, RDF.type, None))
    for type_ in types:
        in_graph.add((in_id, RDF.type, type_))
    if expected:
        assert get_handler_from_types(in_graph, in_id) == expected
    else:
        assert get_handler_from_types(in_graph, in_id) is None
