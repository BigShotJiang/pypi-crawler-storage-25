# Copyright (C) 2025  The Software Heritage developers
# See the AUTHORS file at the top-level directory of this distribution
# License: GNU Affero General Public License version 3, or any later version
# See top-level LICENSE file for more information

from django.contrib.auth.forms import UserChangeForm, UserCreationForm

from .models import Actor


class ActorCreationForm(UserCreationForm):
    class Meta:
        model = Actor
        fields = ("email",)


class ActorChangeForm(UserChangeForm):
    class Meta:
        model = Actor
        fields = ("email",)
