# Copyright (C) 2025  The Software Heritage developers
# See the AUTHORS file at the top-level directory of this distribution
# License: GNU General Public License version 3, or any later version
# See top-level LICENSE file for more information
import pytest

from swh.coarnotify.client import (
    COARNotifyClient,
    ConsoleCOARNotifyClient,
    DevCOARNotifyClient,
    DummyCOARNotifyClient,
)
from swh.coarnotify.server.models import OutboundNotification


@pytest.fixture
def notification(db):
    return OutboundNotification.objects.create(
        payload={"test": True}, inbox="http://original/"
    )


def test_dummy(notification):
    client = DummyCOARNotifyClient()
    assert client.send(notification)


def test_dev(requests_mock, settings, notification):
    settings.CN_INBOX_URL_OVERRIDE = "http://overridden/"
    client = DevCOARNotifyClient()
    m = requests_mock.post("http://overridden/")
    client.send(notification)
    assert m.call_count == 1
    assert m.last_request.method == "POST"
    assert m.last_request.headers["Content-type"] == "application/ld+json"
    assert m.last_request.url == "http://overridden/"
    assert m.last_request.json() == {"test": True}


def test_basic(requests_mock, settings, notification):
    settings.CN_INBOX_URL_OVERRIDE = "http://ignored/"
    client = COARNotifyClient()
    m = requests_mock.post("http://original/")
    client.send(notification)
    assert m.call_count == 1
    assert m.last_request.method == "POST"
    assert m.last_request.headers["Content-type"] == "application/ld+json"
    assert m.last_request.url == "http://original/"
    assert m.last_request.json() == {"test": True}
    assert m.last_request.timeout == settings.CN_SEND_TIMEOUT


def test_console(capsys, notification):
    client = ConsoleCOARNotifyClient()
    client.send(notification)
    captured = capsys.readouterr()
    assert "{'test': True}\n" in captured.out
