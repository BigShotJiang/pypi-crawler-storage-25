# Copyright (C) 2026  The Software Heritage developers
# See the AUTHORS file at the top-level directory of this distribution
# License: GNU Affero General Public License version 3, or any later version
# See top-level LICENSE file for more information
"""Extra namespaces for rdflib."""

from rdflib import Namespace
from rdflib.namespace import RDF  # noqa: F401

AS = Namespace("https://www.w3.org/ns/activitystreams#")
CN = Namespace("http://coar-notify.net/specification/vocabulary/")
LDP = Namespace("http://www.w3.org/ns/ldp#")

# https://www.w3.org/ns/activitystreams#objects
AS_OBJECTS = {
    AS[obj]
    for obj in [
        "Activity",
        "Application",
        "Article",
        "Audio",
        "Collection",
        "CollectionPage",
        "Relationship",
        "Document",
        "Event",
        "Group",
        "Image",
        "IntransitiveActivity",
        "Note",
        "Object",
        "OrderedCollection",
        "OrderedCollectionPage",
        "Organization",
        "Page",
        "Person",
        "Place",
        "Profile",
        "Question",
        "Service",
        "Tombstone",
        "Video",
    ]
}

# https://www.w3.org/ns/activitystreams#activities
AS_ACTIVITIES = {
    AS[activity]
    for activity in [
        "Accept",
        "Add",
        "Announce",
        "Arrive",
        "Block",
        "Create",
        "Delete",
        "Dislike",
        "Flag",
        "Follow",
        "Ignore",
        "Invite",
        "Join",
        "Leave",
        "Like",
        "Listen",
        "Move",
        "Offer",
        "Question",
        "Reject",
        "Read",
        "Remove",
        "TentativeReject",
        "TentativeAccept",
        "Travel",
        "Undo",
        "Update",
        "View",
    ]
}
