"""Core PII detection and redaction logic."""

from __future__ import annotations

from typing import List, Optional

from .models import PIIMatch
from .patterns import (
    BANK_ACCOUNT_CONTEXT_WORDS,
    COMPILED_PATTERNS,
    REDACTION_LABELS,
)
from .utils import normalize_aadhaar, remove_overlapping_matches, verhoeff_validate

# Context window (characters) around a bank-account match to search for keywords
_BANK_CONTEXT_WINDOW = 60


class PIIDetector:
    """Detect and redact Indian PII in text.

    Usage::

        detector = PIIDetector()
        matches = detector.detect("My Aadhaar is 2234 5678 9012")
        redacted = detector.redact("My Aadhaar is 2234 5678 9012")

    Args:
        use_ner: Whether to use spaCy NER for name/address detection when
                 available.  Defaults to True.
        validate_aadhaar: Whether to apply Verhoeff checksum to Aadhaar
                          candidates.  Defaults to True.  Setting to False
                          may increase recall but also false positives.
    """

    def __init__(
        self,
        use_ner: bool = True,
        validate_aadhaar: bool = True,
    ) -> None:
        self._use_ner = use_ner
        self._validate_aadhaar = validate_aadhaar

        # Import NER lazily so the library works even without spaCy
        self._ner_module: Optional[object] = None
        if use_ner:
            try:
                from . import ner as _ner
                self._ner_module = _ner
            except Exception:  # pragma: no cover
                pass

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def detect(self, text: str) -> List[PIIMatch]:
        """Detect all PII in *text*.

        Args:
            text: The string to scan.

        Returns:
            Sorted, non-overlapping list of :class:`PIIMatch` objects.
        """
        if not text:
            return []

        matches: List[PIIMatch] = []

        # --- Regex-based detection ---
        for pii_type, pattern, base_confidence, needs_context in COMPILED_PATTERNS:
            for m in pattern.finditer(text):
                value = m.group(0)
                start = m.start()
                end = m.end()
                confidence = base_confidence

                # --- Aadhaar-specific: Verhoeff checksum ---
                if pii_type == "AADHAAR":
                    digits = normalize_aadhaar(value)
                    if len(digits) != 12:
                        continue
                    if self._validate_aadhaar:
                        if verhoeff_validate(digits):
                            confidence = 1.0
                        else:
                            # Failed checksum — skip to reduce false positives
                            continue

                # --- Bank account: require context words nearby ---
                elif pii_type == "BANK_ACCOUNT" and needs_context:
                    window_start = max(0, start - _BANK_CONTEXT_WINDOW)
                    window_end = min(len(text), end + _BANK_CONTEXT_WINDOW)
                    context = text[window_start:window_end]
                    if not BANK_ACCOUNT_CONTEXT_WORDS.search(context):
                        continue
                    # Longer account numbers get slightly higher confidence
                    digit_count = len(value)
                    if digit_count >= 15:
                        confidence = 0.85
                    elif digit_count >= 12:
                        confidence = 0.80

                matches.append(
                    PIIMatch(
                        pii_type=pii_type,
                        value=value,
                        start=start,
                        end=end,
                        confidence=confidence,
                    )
                )

        # --- NER-based detection ---
        if self._ner_module is not None:
            try:
                ner_matches = self._ner_module.detect_entities(text)  # type: ignore[attr-defined]
                matches.extend(ner_matches)
            except Exception:  # pragma: no cover
                pass

        # --- De-overlap and return ---
        return remove_overlapping_matches(matches)

    def redact(
        self,
        text: str,
        custom_labels: Optional[dict] = None,
    ) -> str:
        """Replace all detected PII in *text* with placeholder tokens.

        Args:
            text:          The string to redact.
            custom_labels: Optional mapping from pii_type to replacement string.
                           Merged with (and overrides) the built-in labels.

        Returns:
            The redacted string.
        """
        if not text:
            return text

        labels = dict(REDACTION_LABELS)
        if custom_labels:
            labels.update(custom_labels)

        matches = self.detect(text)
        if not matches:
            return text

        # Build the result by iterating through non-overlapping matches
        # (already sorted by start position from detect())
        parts: List[str] = []
        cursor = 0
        for match in matches:
            if match.start > cursor:
                parts.append(text[cursor : match.start])
            replacement = labels.get(match.pii_type, f"[{match.pii_type}_REDACTED]")
            parts.append(replacement)
            cursor = match.end

        parts.append(text[cursor:])
        return "".join(parts)
