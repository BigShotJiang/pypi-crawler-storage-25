"""Compiled regex patterns for all Indian PII types.

All patterns are compiled once at module load time for thread safety and
performance.  Each entry in PATTERNS is a tuple of:
    (pii_type, compiled_pattern, base_confidence, needs_context)

Where:
    pii_type        - canonical string label used in PIIMatch.pii_type
    compiled_re     - compiled regex object
    base_confidence - float confidence before any validation step
    needs_context   - bool; True means the pattern alone is weak and we
                      require surrounding context words to accept it
"""

import regex

# ---------------------------------------------------------------------------
# Helper: word-boundary wrapper that works with Unicode
# ---------------------------------------------------------------------------
_WB = r"(?<![0-9A-Za-z])"  # left boundary
_WB_R = r"(?![0-9A-Za-z])"  # right boundary


# ---------------------------------------------------------------------------
# 1. Aadhaar — 12 digits, optionally grouped as 4-4-4 with space or hyphen
#    First digit must NOT be 0 or 1 (UIDAI constraint).
# ---------------------------------------------------------------------------
_AADHAAR_RAW = (
    r"(?<![0-9])"
    r"[2-9][0-9]{3}"           # first group: 4 digits, starts with 2-9
    r"(?:[ \-]?)"              # optional separator
    r"[0-9]{4}"                # second group
    r"(?:[ \-]?)"              # optional separator
    r"[0-9]{4}"                # third group
    r"(?![0-9])"
)

# ---------------------------------------------------------------------------
# 2. PAN card — AAAAA9999A (case-insensitive)
# ---------------------------------------------------------------------------
_PAN_RAW = r"(?<![A-Za-z0-9])[A-Za-z]{5}[0-9]{4}[A-Za-z](?![A-Za-z0-9])"

# ---------------------------------------------------------------------------
# 3. UPI ID — localpart@provider
#    Local part: alphanumeric, dots, hyphens, underscores, up to 256 chars
#    Provider: alphanumeric, 2-20 chars (no dots, matching known UPI handles)
# ---------------------------------------------------------------------------
_UPI_RAW = (
    r"(?<![A-Za-z0-9._%+\-])"
    r"[A-Za-z0-9._%+\-]{3,256}"
    r"@"
    r"(?:upi|ybl|oksbi|okaxis|okicici|okhdfcbank|paytm|ibl|axl|"
    r"apl|abfspay|airtel|allbank|andb|aubank|barodampay|"
    r"cnrb|csbpay|dbs|dcb|equitas|fbl|federal|"
    r"hdfcbank|hsbc|icici|idbi|idfc|idfcbank|imobile|"
    r"indus|jkb|jsb|kbl|kbl052|kotak|kvb|"
    r"lvb|mahb|myicici|nsdl|obc|okbizaxis|"
    r"pnb|postpay|psb|purz|rbl|sbi|sc|"
    r"scmobile|sib|srcb|syndicate|tjsb|ubi|"
    r"ucb|unionbank|utbi|utkarshmb|vijb|yesbank|"
    r"[a-z]{2,20})"  # fallback: any lowercase 2-20 char handle
    r"(?![A-Za-z0-9])"
)

# ---------------------------------------------------------------------------
# 4. Indian mobile phone number
#    10 digits starting with 6-9, optional prefix: +91, 91, 0
#    Allow optional space or hyphen after country code / leading 0
# ---------------------------------------------------------------------------
_PHONE_RAW = (
    r"(?<![0-9])"
    r"(?:\+91|91|0)?"          # optional country/trunk code
    r"[\s\-]?"                 # optional separator after prefix
    r"[6-9][0-9]{9}"
    r"(?![0-9])"
)

# ---------------------------------------------------------------------------
# 5. Bank account number — 9 to 18 digits
#    Context-dependent: only accepted when nearby words indicate it is an
#    account number.  We embed the context check in the detector, not here.
# ---------------------------------------------------------------------------
_BANK_ACCOUNT_RAW = (
    r"(?<![0-9])"
    r"[0-9]{9,18}"
    r"(?![0-9])"
)

# Context words that must appear within ~60 characters of a bank account match
BANK_ACCOUNT_CONTEXT_WORDS = regex.compile(
    r"\b(?:account|acc(?:ount)?|a/c|acct|bank\s*(?:no|number|num|#)?)\b",
    regex.IGNORECASE,
)

# ---------------------------------------------------------------------------
# 6. IFSC code — 4 alpha + literal '0' + 6 alphanumeric
# ---------------------------------------------------------------------------
_IFSC_RAW = r"(?<![A-Za-z0-9])[A-Za-z]{4}0[A-Za-z0-9]{6}(?![A-Za-z0-9])"

# ---------------------------------------------------------------------------
# 7. Indian passport — 1 alpha + 7 digits
# ---------------------------------------------------------------------------
_PASSPORT_RAW = r"(?<![A-Za-z0-9])[A-Za-z][0-9]{7}(?![A-Za-z0-9])"

# ---------------------------------------------------------------------------
# 8. Voter ID (EPIC) — 3 alpha + 7 digits
# ---------------------------------------------------------------------------
_VOTER_ID_RAW = r"(?<![A-Za-z0-9])[A-Za-z]{3}[0-9]{7}(?![A-Za-z0-9])"

# ---------------------------------------------------------------------------
# 9. Driving license — state code (2 alpha) + 2 digits + year (2-4 digits)
#    + 7 digits, optionally space-separated segments
#    Examples: MH01 2011 0012345, MH0120110012345, DL-01-1234-0012345
# ---------------------------------------------------------------------------
_DL_RAW = (
    r"(?<![A-Za-z0-9])"
    r"[A-Za-z]{2}"             # state code
    r"[\s\-]?"
    r"[0-9]{2}"                # RTO code
    r"[\s\-]?"
    r"(?:19|20)?[0-9]{2}"     # year (optionally with century)
    r"[\s\-]?"
    r"[0-9]{7}"               # serial number
    r"(?![0-9A-Za-z])"
)

# ---------------------------------------------------------------------------
# 10. Email address
# ---------------------------------------------------------------------------
_EMAIL_RAW = (
    r"(?<![A-Za-z0-9._%+\-])"
    r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}"
    r"(?![A-Za-z0-9])"
)

# ---------------------------------------------------------------------------
# 11. Date of birth — DD/MM/YYYY or DD-MM-YYYY or DD.MM.YYYY
# ---------------------------------------------------------------------------
_DOB_RAW = (
    r"(?<![0-9/\-.])"
    r"(?:0?[1-9]|[12][0-9]|3[01])"   # day
    r"[/\-.]"
    r"(?:0?[1-9]|1[0-2])"            # month
    r"[/\-.]"
    r"(?:19|20)[0-9]{2}"             # year (1900-2099)
    r"(?![0-9])"
)

# ---------------------------------------------------------------------------
# Compile everything
# ---------------------------------------------------------------------------
# Structure: (pii_type, pattern_string, base_confidence, needs_context)
_RAW_PATTERNS = [
    ("AADHAAR",       _AADHAAR_RAW,      0.9,  False),
    ("PAN",           _PAN_RAW,          0.9,  False),
    ("UPI",           _UPI_RAW,          0.9,  False),
    ("PHONE",         _PHONE_RAW,        0.9,  False),
    ("BANK_ACCOUNT",  _BANK_ACCOUNT_RAW, 0.75, True),   # context-dependent
    ("IFSC",          _IFSC_RAW,         0.9,  False),
    ("PASSPORT",      _PASSPORT_RAW,     0.85, False),
    ("VOTER_ID",      _VOTER_ID_RAW,     0.85, False),
    ("DRIVING_LICENSE", _DL_RAW,         0.85, False),
    ("EMAIL",         _EMAIL_RAW,        0.9,  False),
    ("DOB",           _DOB_RAW,          0.85, False),
]

# Compiled patterns exported for use by detector.py
COMPILED_PATTERNS = [
    (pii_type, regex.compile(raw, regex.IGNORECASE), conf, ctx)
    for pii_type, raw, conf, ctx in _RAW_PATTERNS
]

# Redaction placeholders
REDACTION_LABELS = {
    "AADHAAR":         "[AADHAAR_REDACTED]",
    "PAN":             "[PAN_REDACTED]",
    "UPI":             "[UPI_REDACTED]",
    "PHONE":           "[PHONE_REDACTED]",
    "BANK_ACCOUNT":    "[BANK_ACCOUNT_REDACTED]",
    "IFSC":            "[IFSC_REDACTED]",
    "PASSPORT":        "[PASSPORT_REDACTED]",
    "VOTER_ID":        "[VOTER_ID_REDACTED]",
    "DRIVING_LICENSE": "[DRIVING_LICENSE_REDACTED]",
    "EMAIL":           "[EMAIL_REDACTED]",
    "DOB":             "[DOB_REDACTED]",
    "PERSON":          "[NAME_REDACTED]",
    "LOC":             "[LOCATION_REDACTED]",
    "ORG":             "[ORG_REDACTED]",
}
