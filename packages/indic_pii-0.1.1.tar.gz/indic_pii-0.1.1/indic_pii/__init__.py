"""indic_pii — Detection and redaction of Indian-specific PII.

Public API
----------
Class-based::

    from indic_pii import PIIDetector
    detector = PIIDetector()
    matches  = detector.detect(text)
    redacted = detector.redact(text)

Functional::

    import indic_pii
    matches  = indic_pii.detect(text)
    redacted = indic_pii.redact(text)
"""

from .detector import PIIDetector
from .models import PIIMatch
from . import ner  # expose ner sub-module

__version__ = "0.1.0"
__all__ = ["PIIDetector", "PIIMatch", "detect", "redact", "ner", "__version__"]

# ---------------------------------------------------------------------------
# Module-level singleton for the functional API
# ---------------------------------------------------------------------------
_default_detector = PIIDetector()


def detect(text: str):
    """Detect PII in *text* using the default detector.

    Returns a sorted, non-overlapping list of :class:`PIIMatch` objects.
    """
    return _default_detector.detect(text)


def redact(text: str, custom_labels: dict = None) -> str:
    """Return *text* with all detected PII replaced by placeholder tokens."""
    return _default_detector.redact(text, custom_labels=custom_labels)
