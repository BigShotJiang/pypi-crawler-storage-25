"""Utility functions including Verhoeff checksum for Aadhaar validation."""

# ---------------------------------------------------------------------------
# Verhoeff algorithm tables
# ---------------------------------------------------------------------------
# Multiplication table d
_VERHOEFF_D = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
    [1, 2, 3, 4, 0, 6, 7, 8, 9, 5],
    [2, 3, 4, 0, 1, 7, 8, 9, 5, 6],
    [3, 4, 0, 1, 2, 8, 9, 5, 6, 7],
    [4, 0, 1, 2, 3, 9, 5, 6, 7, 8],
    [5, 9, 8, 7, 6, 0, 4, 3, 2, 1],
    [6, 5, 9, 8, 7, 1, 0, 4, 3, 2],
    [7, 6, 5, 9, 8, 2, 1, 0, 4, 3],
    [8, 7, 6, 5, 9, 3, 2, 1, 0, 4],
    [9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
]

# Permutation table p
_VERHOEFF_P = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
    [1, 5, 7, 6, 2, 8, 3, 0, 9, 4],
    [5, 8, 0, 3, 7, 9, 6, 1, 4, 2],
    [8, 9, 1, 6, 0, 4, 3, 5, 2, 7],
    [9, 4, 5, 3, 1, 2, 6, 8, 7, 0],
    [4, 2, 8, 6, 5, 7, 3, 9, 0, 1],
    [2, 7, 9, 3, 8, 0, 6, 4, 1, 5],
    [7, 0, 4, 6, 9, 1, 3, 2, 5, 8],
]

# Inverse table inv
_VERHOEFF_INV = [0, 4, 3, 2, 1, 5, 6, 7, 8, 9]


def verhoeff_validate(number: str) -> bool:
    """Validate a numeric string using the Verhoeff algorithm.

    The Verhoeff algorithm is used by UIDAI to validate Aadhaar numbers.
    Returns True if the check digit is valid, False otherwise.

    Args:
        number: A string of digits (spaces/hyphens are stripped automatically).
    """
    # Strip non-digit characters (spaces, hyphens used in formatted Aadhaar)
    digits = "".join(ch for ch in number if ch.isdigit())
    if not digits:
        return False

    c = 0
    # Iterate from right to left
    for i, digit in enumerate(reversed(digits)):
        p = _VERHOEFF_P[i % 8][int(digit)]
        c = _VERHOEFF_D[c][p]
    return c == 0


def verhoeff_generate(number: str) -> str:
    """Generate the Verhoeff check digit for a partial number string.

    Tries each digit 0-9 as the check digit and returns the one that makes
    the full number pass :func:`verhoeff_validate`.

    Args:
        number: String of digits (WITHOUT the check digit).

    Returns:
        The check digit as a single character string, or "" if none found
        (should never happen for valid input).
    """
    digits = "".join(ch for ch in number if ch.isdigit())
    for candidate in range(10):
        if verhoeff_validate(digits + str(candidate)):
            return str(candidate)
    return ""  # pragma: no cover


def normalize_aadhaar(value: str) -> str:
    """Strip separators from an Aadhaar string and return only digits."""
    return "".join(ch for ch in value if ch.isdigit())


def remove_overlapping_matches(matches: list) -> list:
    """Remove overlapping PIIMatch objects, keeping the longer (more specific) one.

    When two matches overlap, the one with a greater span length is retained.
    If lengths are equal, the one with higher confidence is retained.

    Args:
        matches: List of PIIMatch objects, in any order.

    Returns:
        A sorted, non-overlapping list of PIIMatch objects.
    """
    if not matches:
        return []

    # Sort by start position, then by descending length (longest first)
    sorted_matches = sorted(matches, key=lambda m: (m.start, -(m.end - m.start)))

    result = []
    for candidate in sorted_matches:
        dominated = False
        for kept in result:
            if kept.overlaps(candidate):
                # If the kept match contains the candidate, skip candidate
                if kept.contains(candidate):
                    dominated = True
                    break
                # If the candidate contains the kept match, replace kept
                if candidate.contains(kept):
                    result.remove(kept)
                    break
                # Partial overlap: keep the longer one; on tie, higher confidence
                candidate_len = len(candidate)
                kept_len = len(kept)
                if kept_len > candidate_len:
                    dominated = True
                    break
                elif kept_len == candidate_len and kept.confidence >= candidate.confidence:
                    dominated = True
                    break
                else:
                    result.remove(kept)
                    break
        if not dominated:
            result.append(candidate)

    # Final sort by start position
    result.sort(key=lambda m: m.start)
    return result
