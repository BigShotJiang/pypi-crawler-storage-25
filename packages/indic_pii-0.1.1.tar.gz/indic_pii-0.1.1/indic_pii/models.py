"""Data models for PII detection results."""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class PIIMatch:
    """Represents a single PII match found in text.

    Attributes:
        pii_type:   Category of PII (e.g. "AADHAAR", "PAN", "PHONE").
        value:      The exact matched string from the source text.
        start:      Start index of the match in the source text (inclusive).
        end:        End index of the match in the source text (exclusive).
        confidence: Float in [0, 1].  1.0 = checksum-validated, 0.9 = pattern
                    match only, lower values for context-dependent heuristics.
    """

    pii_type: str
    value: str
    start: int
    end: int
    confidence: float = 0.9

    # ------------------------------------------------------------------ #
    # Convenience helpers                                                  #
    # ------------------------------------------------------------------ #

    def __len__(self) -> int:  # noqa: D401
        """Return the character length of the matched value."""
        return self.end - self.start

    def contains(self, other: "PIIMatch") -> bool:
        """Return True if *other* is fully contained within this match."""
        return self.start <= other.start and self.end >= other.end

    def overlaps(self, other: "PIIMatch") -> bool:
        """Return True if the spans overlap at all (including containment)."""
        return self.start < other.end and other.start < self.end

    def __repr__(self) -> str:
        return (
            f"PIIMatch(type={self.pii_type!r}, value={self.value!r}, "
            f"span=({self.start}, {self.end}), confidence={self.confidence})"
        )
