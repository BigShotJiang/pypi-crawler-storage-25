"""NER-based PII detection (names, locations, organisations).

Attempts to import spaCy and a suitable model.  If neither is available, all
public functions degrade gracefully by returning empty lists.

Supported entity types mapped to PII labels:
    spaCy label  →  PII type
    -----------     --------
    PERSON       →  PERSON
    GPE / LOC    →  LOC
    ORG          →  ORG
"""

from __future__ import annotations

from typing import TYPE_CHECKING, List

if TYPE_CHECKING:
    from .models import PIIMatch

# ---------------------------------------------------------------------------
# Attempt to load spaCy
# ---------------------------------------------------------------------------
_NLP = None  # module-level cached pipeline
_NER_AVAILABLE = False

# Preferred model names in order of preference
_CANDIDATE_MODELS = [
    "en_core_web_trf",
    "en_core_web_lg",
    "en_core_web_md",
    "en_core_web_sm",
]


def _try_load_spacy() -> None:
    """Try to import spaCy and load a model.  Silently sets _NER_AVAILABLE."""
    global _NLP, _NER_AVAILABLE
    try:
        import spacy  # noqa: F401 — check import before model load
    except ImportError:
        return

    for model_name in _CANDIDATE_MODELS:
        try:
            import spacy as _spacy
            _NLP = _spacy.load(model_name, disable=["tagger", "parser", "lemmatizer"])
            _NER_AVAILABLE = True
            return
        except OSError:
            continue


# Run once at import time
_try_load_spacy()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def is_available() -> bool:
    """Return True if NER detection is available (spaCy + model loaded)."""
    return _NER_AVAILABLE


def detect_entities(text: str) -> "List[PIIMatch]":
    """Run NER on *text* and return PIIMatch objects for name/place/org entities.

    Returns an empty list if spaCy is not available or no entities are found.

    Args:
        text: The input text to analyse.

    Returns:
        List of PIIMatch objects with pii_type in {"PERSON", "LOC", "ORG"}.
    """
    if not _NER_AVAILABLE or _NLP is None:
        return []

    from .models import PIIMatch  # local import to avoid circular dep at load

    doc = _NLP(text)
    matches: List[PIIMatch] = []
    for ent in doc.ents:
        if ent.label_ == "PERSON":
            pii_type = "PERSON"
            confidence = 0.75
        elif ent.label_ in ("GPE", "LOC"):
            pii_type = "LOC"
            confidence = 0.65
        elif ent.label_ == "ORG":
            pii_type = "ORG"
            confidence = 0.65
        else:
            continue

        matches.append(
            PIIMatch(
                pii_type=pii_type,
                value=ent.text,
                start=ent.start_char,
                end=ent.end_char,
                confidence=confidence,
            )
        )
    return matches
