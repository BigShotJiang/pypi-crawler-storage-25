"""Unit tests for individual regex patterns in indic_pii.patterns."""

import pytest
import regex

from indic_pii.patterns import COMPILED_PATTERNS, BANK_ACCOUNT_CONTEXT_WORDS


def _pattern_for(pii_type: str):
    """Return the compiled regex for a given pii_type."""
    for pt, pat, conf, ctx in COMPILED_PATTERNS:
        if pt == pii_type:
            return pat
    raise KeyError(f"No pattern registered for type: {pii_type!r}")


# ---------------------------------------------------------------------------
# Aadhaar
# ---------------------------------------------------------------------------
class TestAadhaarPattern:
    pat = _pattern_for("AADHAAR")

    def test_plain_12_digits(self):
        assert self.pat.search("304332181964")

    def test_space_separated(self):
        assert self.pat.search("3043 3218 1964")

    def test_hyphen_separated(self):
        assert self.pat.search("3043-3218-1964")

    def test_in_sentence(self):
        m = self.pat.search("Aadhaar: 3043 3218 1964 is mine")
        assert m is not None
        assert m.group(0) == "3043 3218 1964"

    def test_no_match_11_digits(self):
        assert not self.pat.search("30433218196")

    def test_no_match_starts_with_0(self):
        # First digit 0 or 1 not allowed
        assert not self.pat.search("034332181964")

    def test_no_match_starts_with_1(self):
        assert not self.pat.search("134332181964")

    def test_no_match_embedded_in_longer_number(self):
        # Should not match when surrounded by digits
        assert not self.pat.search("1304332181964")


# ---------------------------------------------------------------------------
# PAN card
# ---------------------------------------------------------------------------
class TestPANPattern:
    pat = _pattern_for("PAN")

    @pytest.mark.parametrize("pan", [
        "ABCDE1234F",
        "ZZZZZ9999Z",
        "abcde1234f",  # lowercase — pattern is case-insensitive
        "AABCP1234F",
    ])
    def test_valid_pan(self, pan):
        assert self.pat.search(pan), f"Expected match for {pan!r}"

    def test_pan_in_sentence(self):
        m = self.pat.search("PAN is ABCDE1234F please verify")
        assert m and m.group(0).upper() == "ABCDE1234F"

    def test_no_match_6_alpha(self):
        assert not self.pat.search("ABCDEF1234F")

    def test_no_match_4_digits(self):
        # 5 alpha + 3 digit + 1 alpha is invalid
        assert not self.pat.search("ABCDE123F")

    def test_no_match_embedded(self):
        assert not self.pat.search("XABCDE1234FY")


# ---------------------------------------------------------------------------
# UPI ID
# ---------------------------------------------------------------------------
class TestUPIPattern:
    pat = _pattern_for("UPI")

    @pytest.mark.parametrize("upi", [
        "rahul@upi",
        "9876543210@ybl",
        "name.surname@oksbi",
        "user123@paytm",
        "test_user@hdfcbank",
        "john.doe@okicici",
    ])
    def test_valid_upi(self, upi):
        assert self.pat.search(upi), f"Expected match for {upi!r}"

    def test_upi_in_sentence(self):
        m = self.pat.search("Please pay to rahul@upi for the service")
        assert m is not None

    def test_no_match_no_at(self):
        assert not self.pat.search("rahul.upi")


# ---------------------------------------------------------------------------
# Phone numbers
# ---------------------------------------------------------------------------
class TestPhonePattern:
    pat = _pattern_for("PHONE")

    @pytest.mark.parametrize("phone", [
        "9876543210",
        "+91 9876543210",
        "+919876543210",
        "09876543210",
        "091-9876543210",
        "6123456789",
        "7000000000",
        "8999999999",
    ])
    def test_valid_phone(self, phone):
        assert self.pat.search(phone), f"Expected match for {phone!r}"

    def test_phone_in_sentence(self):
        m = self.pat.search("Call me at 9876543210 anytime")
        assert m is not None

    def test_no_match_starts_with_5(self):
        assert not self.pat.search("5876543210")

    def test_no_match_9_digits(self):
        assert not self.pat.search("987654321")


# ---------------------------------------------------------------------------
# IFSC
# ---------------------------------------------------------------------------
class TestIFSCPattern:
    pat = _pattern_for("IFSC")

    @pytest.mark.parametrize("ifsc", [
        "SBIN0001234",
        "HDFC0000001",
        "ICIC0006897",
        "UTIB0002083",
    ])
    def test_valid_ifsc(self, ifsc):
        assert self.pat.search(ifsc), f"Expected match for {ifsc!r}"

    def test_ifsc_in_sentence(self):
        m = self.pat.search("IFSC code is SBIN0001234 for this branch")
        assert m and m.group(0).upper() == "SBIN0001234"

    def test_no_match_wrong_fifth_char(self):
        # 5th character must be '0'
        assert not self.pat.search("SBIN1001234")

    def test_no_match_3_alpha_prefix(self):
        assert not self.pat.search("SBI00001234")


# ---------------------------------------------------------------------------
# Passport
# ---------------------------------------------------------------------------
class TestPassportPattern:
    pat = _pattern_for("PASSPORT")

    @pytest.mark.parametrize("passport", [
        "A1234567",
        "Z9876543",
        "B0000001",
    ])
    def test_valid_passport(self, passport):
        assert self.pat.search(passport), f"Expected match for {passport!r}"

    def test_no_match_2_alpha(self):
        # Should not match (2 alpha + 7 digits — could match voter ID but not passport)
        assert not self.pat.fullmatch("AB1234567")

    def test_no_match_embedded(self):
        assert not self.pat.search("XA1234567Y")


# ---------------------------------------------------------------------------
# Voter ID
# ---------------------------------------------------------------------------
class TestVoterIDPattern:
    pat = _pattern_for("VOTER_ID")

    @pytest.mark.parametrize("voter_id", [
        "ABC1234567",
        "XYZ9876543",
        "DEF0000001",
    ])
    def test_valid_voter_id(self, voter_id):
        assert self.pat.search(voter_id), f"Expected match for {voter_id!r}"

    def test_no_match_2_alpha(self):
        assert not self.pat.fullmatch("AB1234567")

    def test_no_match_4_alpha(self):
        assert not self.pat.fullmatch("ABCD1234567")


# ---------------------------------------------------------------------------
# Driving license
# ---------------------------------------------------------------------------
class TestDrivingLicensePattern:
    pat = _pattern_for("DRIVING_LICENSE")

    @pytest.mark.parametrize("dl", [
        "MH0120110012345",
        "DL0120001234567",
        "KA0319990001234",
    ])
    def test_valid_dl(self, dl):
        assert self.pat.search(dl), f"Expected match for {dl!r}"

    def test_dl_with_spaces(self):
        assert self.pat.search("MH01 2011 0012345")


# ---------------------------------------------------------------------------
# Email
# ---------------------------------------------------------------------------
class TestEmailPattern:
    pat = _pattern_for("EMAIL")

    @pytest.mark.parametrize("email", [
        "user@example.com",
        "rahul.sharma@gmail.com",
        "test+tag@company.co.in",
        "info@bank.org",
    ])
    def test_valid_email(self, email):
        assert self.pat.search(email), f"Expected match for {email!r}"

    def test_no_match_missing_tld(self):
        assert not self.pat.search("user@example")

    def test_no_match_missing_at(self):
        assert not self.pat.search("userexample.com")


# ---------------------------------------------------------------------------
# DOB
# ---------------------------------------------------------------------------
class TestDOBPattern:
    pat = _pattern_for("DOB")

    @pytest.mark.parametrize("dob", [
        "01/01/1990",
        "31-12-2000",
        "15.08.1947",
        "5/3/1985",
    ])
    def test_valid_dob(self, dob):
        assert self.pat.search(dob), f"Expected match for {dob!r}"

    def test_no_match_wrong_year_prefix(self):
        # Year must start with 19 or 20
        assert not self.pat.search("01/01/1800")
        assert not self.pat.search("01/01/2100")

    def test_no_match_month_13(self):
        assert not self.pat.search("01/13/1990")


# ---------------------------------------------------------------------------
# Bank account context words
# ---------------------------------------------------------------------------
class TestBankAccountContext:
    def test_account_word(self):
        assert BANK_ACCOUNT_CONTEXT_WORDS.search("account number")

    def test_ac_shorthand(self):
        assert BANK_ACCOUNT_CONTEXT_WORDS.search("a/c no")

    def test_acc_shorthand(self):
        assert BANK_ACCOUNT_CONTEXT_WORDS.search("acc 123456789012")

    def test_no_match_random_text(self):
        assert not BANK_ACCOUNT_CONTEXT_WORDS.search("the quick brown fox")
