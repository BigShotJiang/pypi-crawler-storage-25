"""Comprehensive tests for PIIDetector and the functional API.

Valid Aadhaar numbers used in tests were generated with the Verhoeff algorithm
and verified to pass checksum validation:
  - 304332181964  (spaced: 3043 3218 1964, hyphened: 3043-3218-1964)
  - 201338908389  (spaced: 2013 3890 8389)
  - 837940265421  (spaced: 8379 4026 5421)
  - 912345678905  (spaced: 9123 4567 8905, hyphened: 9123-4567-8905)
"""

import pytest

import indic_pii
from indic_pii import PIIDetector, PIIMatch
from indic_pii.utils import verhoeff_validate


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def detector():
    """A PIIDetector instance with Aadhaar validation enabled, NER off."""
    return PIIDetector(use_ner=False, validate_aadhaar=True)


@pytest.fixture(scope="module")
def detector_no_val():
    """A PIIDetector with Aadhaar validation disabled (higher recall)."""
    return PIIDetector(use_ner=False, validate_aadhaar=False)


# ---------------------------------------------------------------------------
# Verhoeff utility tests
# ---------------------------------------------------------------------------

class TestVerhoeff:
    def test_known_valid(self):
        assert verhoeff_validate("304332181964")
        assert verhoeff_validate("201338908389")
        assert verhoeff_validate("837940265421")
        assert verhoeff_validate("912345678905")

    def test_valid_with_separators(self):
        assert verhoeff_validate("3043 3218 1964")
        assert verhoeff_validate("3043-3218-1964")

    def test_invalid_checksum(self):
        # Flip last digit
        assert not verhoeff_validate("304332181965")
        assert not verhoeff_validate("304332181963")

    def test_empty_string(self):
        assert not verhoeff_validate("")

    def test_non_digits_only(self):
        assert not verhoeff_validate("abc")


# ---------------------------------------------------------------------------
# Aadhaar detection
# ---------------------------------------------------------------------------

class TestAadhaarDetection:
    def test_plain_digits(self, detector):
        matches = detector.detect("Aadhaar: 304332181964")
        aadhaars = [m for m in matches if m.pii_type == "AADHAAR"]
        assert len(aadhaars) == 1
        assert aadhaars[0].value == "304332181964"
        assert aadhaars[0].confidence == 1.0

    def test_spaced_format(self, detector):
        matches = detector.detect("My aadhaar 3043 3218 1964 issued 2020")
        aadhaars = [m for m in matches if m.pii_type == "AADHAAR"]
        assert len(aadhaars) == 1
        assert "3043" in aadhaars[0].value

    def test_hyphen_format(self, detector):
        matches = detector.detect("UID: 3043-3218-1964")
        aadhaars = [m for m in matches if m.pii_type == "AADHAAR"]
        assert len(aadhaars) == 1

    def test_invalid_checksum_not_detected(self, detector):
        # 304332181965 has wrong last digit
        matches = detector.detect("Aadhaar: 304332181965")
        aadhaars = [m for m in matches if m.pii_type == "AADHAAR"]
        assert len(aadhaars) == 0

    def test_invalid_checksum_detected_without_validation(self, detector_no_val):
        matches = detector_no_val.detect("Aadhaar: 304332181965")
        aadhaars = [m for m in matches if m.pii_type == "AADHAAR"]
        assert len(aadhaars) == 1
        assert aadhaars[0].confidence == 0.9

    def test_starts_with_0_rejected(self, detector):
        matches = detector.detect("0043 3218 1964")
        aadhaars = [m for m in matches if m.pii_type == "AADHAAR"]
        assert len(aadhaars) == 0

    def test_redaction(self, detector):
        result = detector.redact("Aadhaar: 3043 3218 1964 is valid")
        assert "[AADHAAR_REDACTED]" in result
        assert "3043" not in result


# ---------------------------------------------------------------------------
# PAN card detection
# ---------------------------------------------------------------------------

class TestPANDetection:
    @pytest.mark.parametrize("text,expected", [
        ("PAN: ABCDE1234F", "ABCDE1234F"),
        ("pan abcde1234f issued", "abcde1234f"),  # case-insensitive match preserved
    ])
    def test_valid_pan(self, detector, text, expected):
        matches = detector.detect(text)
        pans = [m for m in matches if m.pii_type == "PAN"]
        assert len(pans) == 1
        assert pans[0].value.upper() == expected.upper()

    def test_redaction(self, detector):
        result = detector.redact("PAN ABCDE1234F")
        assert "[PAN_REDACTED]" in result
        assert "ABCDE1234F" not in result

    def test_no_false_positive_short(self, detector):
        matches = detector.detect("ABCD1234F")
        pans = [m for m in matches if m.pii_type == "PAN"]
        assert len(pans) == 0


# ---------------------------------------------------------------------------
# UPI ID detection
# ---------------------------------------------------------------------------

class TestUPIDetection:
    @pytest.mark.parametrize("upi", [
        "rahul@upi",
        "9876543210@ybl",
        "name.surname@oksbi",
    ])
    def test_detect_upi(self, detector, upi):
        matches = detector.detect(f"Pay to {upi} now")
        upis = [m for m in matches if m.pii_type == "UPI"]
        assert len(upis) >= 1, f"Expected UPI match for {upi!r}"

    def test_redaction(self, detector):
        result = detector.redact("Send to rahul@upi")
        assert "[UPI_REDACTED]" in result


# ---------------------------------------------------------------------------
# Phone number detection
# ---------------------------------------------------------------------------

class TestPhoneDetection:
    @pytest.mark.parametrize("phone,desc", [
        ("9876543210", "bare 10-digit"),
        ("+91 9876543210", "with +91 prefix"),
        ("+919876543210", "with +91 prefix no space"),
        ("091-9876543210", "with 0 prefix and hyphen"),
    ])
    def test_detect_phone(self, detector, phone, desc):
        matches = detector.detect(f"Call {phone} for details")
        phones = [m for m in matches if m.pii_type == "PHONE"]
        assert len(phones) >= 1, f"Expected phone match for {desc}: {phone!r}"

    def test_no_match_starts_with_5(self, detector):
        matches = detector.detect("5876543210")
        phones = [m for m in matches if m.pii_type == "PHONE"]
        assert len(phones) == 0

    def test_redaction(self, detector):
        result = detector.redact("Call 9876543210 now")
        assert "[PHONE_REDACTED]" in result
        assert "9876543210" not in result


# ---------------------------------------------------------------------------
# Bank account detection (context-dependent)
# ---------------------------------------------------------------------------

class TestBankAccountDetection:
    def test_detect_with_context(self, detector):
        text = "Please transfer to account 123456789012 immediately"
        matches = detector.detect(text)
        accs = [m for m in matches if m.pii_type == "BANK_ACCOUNT"]
        assert len(accs) == 1

    def test_no_detect_without_context(self, detector):
        # Same number, no account context words
        matches = detector.detect("The order number is 123456789012")
        accs = [m for m in matches if m.pii_type == "BANK_ACCOUNT"]
        assert len(accs) == 0

    def test_detect_a_c_shorthand(self, detector):
        text = "Debit from a/c 987654321098"
        matches = detector.detect(text)
        accs = [m for m in matches if m.pii_type == "BANK_ACCOUNT"]
        assert len(accs) == 1

    def test_redaction(self, detector):
        result = detector.redact("account 987654321098")
        assert "[BANK_ACCOUNT_REDACTED]" in result


# ---------------------------------------------------------------------------
# IFSC detection
# ---------------------------------------------------------------------------

class TestIFSCDetection:
    @pytest.mark.parametrize("ifsc", ["SBIN0001234", "HDFC0000001"])
    def test_detect_ifsc(self, detector, ifsc):
        matches = detector.detect(f"IFSC: {ifsc}")
        ifscs = [m for m in matches if m.pii_type == "IFSC"]
        assert len(ifscs) == 1

    def test_redaction(self, detector):
        result = detector.redact("Use IFSC SBIN0001234")
        assert "[IFSC_REDACTED]" in result


# ---------------------------------------------------------------------------
# Passport detection
# ---------------------------------------------------------------------------

class TestPassportDetection:
    @pytest.mark.parametrize("passport", ["A1234567", "Z9876543"])
    def test_detect_passport(self, detector, passport):
        matches = detector.detect(f"Passport no {passport}")
        passports = [m for m in matches if m.pii_type == "PASSPORT"]
        assert len(passports) == 1

    def test_redaction(self, detector):
        result = detector.redact("Passport: A1234567")
        assert "[PASSPORT_REDACTED]" in result


# ---------------------------------------------------------------------------
# Voter ID detection
# ---------------------------------------------------------------------------

class TestVoterIDDetection:
    def test_detect_voter_id(self, detector):
        matches = detector.detect("Voter ID: ABC1234567")
        voter_ids = [m for m in matches if m.pii_type == "VOTER_ID"]
        assert len(voter_ids) == 1
        assert voter_ids[0].value.upper() == "ABC1234567"

    def test_redaction(self, detector):
        result = detector.redact("EPIC: ABC1234567")
        assert "[VOTER_ID_REDACTED]" in result


# ---------------------------------------------------------------------------
# Email detection
# ---------------------------------------------------------------------------

class TestEmailDetection:
    @pytest.mark.parametrize("email", [
        "user@example.com",
        "rahul.sharma@gmail.com",
        "test+tag@company.co.in",
    ])
    def test_detect_email(self, detector, email):
        matches = detector.detect(f"Email me at {email}")
        emails = [m for m in matches if m.pii_type == "EMAIL"]
        assert len(emails) >= 1

    def test_redaction(self, detector):
        result = detector.redact("Email: user@example.com")
        assert "[EMAIL_REDACTED]" in result
        assert "user@example.com" not in result


# ---------------------------------------------------------------------------
# DOB detection
# ---------------------------------------------------------------------------

class TestDOBDetection:
    @pytest.mark.parametrize("dob", [
        "01/01/1990",
        "31-12-2000",
        "15.08.1947",
    ])
    def test_detect_dob(self, detector, dob):
        matches = detector.detect(f"DOB: {dob}")
        dobs = [m for m in matches if m.pii_type == "DOB"]
        assert len(dobs) == 1

    def test_redaction(self, detector):
        result = detector.redact("Born on 15/08/1947")
        assert "[DOB_REDACTED]" in result


# ---------------------------------------------------------------------------
# Mixed text paragraph
# ---------------------------------------------------------------------------

class TestMixedText:
    PARA = (
        "Dear Rahul, your Aadhaar 3043 3218 1964 and PAN ABCDE1234F have been "
        "verified. Your registered mobile +91 9876543210 and email rahul@gmail.com "
        "are on file. Bank account (a/c 987654321098) linked to IFSC SBIN0001234. "
        "Passport A1234567, Voter ID ABC1234567. DOB: 15/08/1980."
    )

    def test_all_types_detected(self, detector):
        matches = detector.detect(self.PARA)
        types_found = {m.pii_type for m in matches}
        assert "AADHAAR" in types_found
        assert "PAN" in types_found
        assert "PHONE" in types_found
        assert "EMAIL" in types_found
        assert "BANK_ACCOUNT" in types_found
        assert "IFSC" in types_found
        assert "PASSPORT" in types_found
        assert "VOTER_ID" in types_found
        assert "DOB" in types_found

    def test_no_overlapping_matches(self, detector):
        matches = detector.detect(self.PARA)
        for i, m1 in enumerate(matches):
            for m2 in matches[i + 1:]:
                assert not m1.overlaps(m2), (
                    f"Overlap between {m1} and {m2}"
                )

    def test_redact_removes_all_pii(self, detector):
        result = detector.redact(self.PARA)
        assert "3043" not in result
        assert "ABCDE1234F" not in result
        assert "9876543210" not in result
        assert "rahul@gmail.com" not in result
        assert "987654321098" not in result
        assert "SBIN0001234" not in result
        assert "A1234567" not in result
        assert "ABC1234567" not in result
        assert "15/08/1980" not in result

    def test_matches_are_sorted_by_start(self, detector):
        matches = detector.detect(self.PARA)
        starts = [m.start for m in matches]
        assert starts == sorted(starts)


# ---------------------------------------------------------------------------
# Functional API
# ---------------------------------------------------------------------------

class TestFunctionalAPI:
    def test_detect_function(self):
        matches = indic_pii.detect("PAN: ABCDE1234F")
        pans = [m for m in matches if m.pii_type == "PAN"]
        assert len(pans) == 1

    def test_redact_function(self):
        result = indic_pii.redact("PAN: ABCDE1234F")
        assert "[PAN_REDACTED]" in result

    def test_custom_labels(self):
        detector = PIIDetector(use_ner=False)
        result = detector.redact("Email: user@example.com", custom_labels={"EMAIL": "***"})
        assert "***" in result
        assert "user@example.com" not in result

    def test_empty_string(self):
        assert indic_pii.detect("") == []
        assert indic_pii.redact("") == ""

    def test_no_pii(self):
        text = "The quick brown fox jumps over the lazy dog."
        matches = indic_pii.detect(text)
        assert matches == []
        assert indic_pii.redact(text) == text


# ---------------------------------------------------------------------------
# PIIMatch model
# ---------------------------------------------------------------------------

class TestPIIMatchModel:
    def test_len(self):
        m = PIIMatch("PAN", "ABCDE1234F", 5, 15)
        assert len(m) == 10

    def test_contains(self):
        outer = PIIMatch("A", "hello world", 0, 11)
        inner = PIIMatch("B", "world", 6, 11)
        assert outer.contains(inner)
        assert not inner.contains(outer)

    def test_overlaps(self):
        m1 = PIIMatch("A", "hello", 0, 5)
        m2 = PIIMatch("B", "world", 3, 8)
        assert m1.overlaps(m2)
        assert m2.overlaps(m1)

    def test_no_overlap(self):
        m1 = PIIMatch("A", "hello", 0, 5)
        m2 = PIIMatch("B", "world", 5, 10)
        assert not m1.overlaps(m2)

    def test_repr(self):
        m = PIIMatch("PAN", "ABCDE1234F", 5, 15, 0.9)
        r = repr(m)
        assert "PAN" in r
        assert "ABCDE1234F" in r


# ---------------------------------------------------------------------------
# NER module graceful degradation
# ---------------------------------------------------------------------------

class TestNERModule:
    def test_is_available_returns_bool(self):
        from indic_pii import ner
        assert isinstance(ner.is_available(), bool)

    def test_detect_entities_returns_list(self):
        from indic_pii import ner
        # Should not raise even if spaCy is not installed
        result = ner.detect_entities("Rahul lives in Mumbai")
        assert isinstance(result, list)
