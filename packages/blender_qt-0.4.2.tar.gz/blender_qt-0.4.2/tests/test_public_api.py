import sys


def test_import_is_safe_outside_blender() -> None:
    import blender_qt

    assert blender_qt.__version__
    assert callable(blender_qt.init)
    assert callable(blender_qt.shutdown)
    assert "bpy" not in sys.modules


def test_public_exports_are_present() -> None:
    import blender_qt

    expected = {
        "__version__",
        "init",
        "shutdown",
        "register_qml_space",
        "register_widget_space",
        "registered_space_types",
        "unregister_space",
        "register_qml_viewport_gizmo",
        "register_widget_viewport_gizmo",
        "registered_viewport_gizmo_ids",
        "unregister_viewport_gizmo",
        "register_window",
        "managed_windows",
        "close_managed_windows",
        "get_qt_application",
    }

    assert expected.issubset(set(blender_qt.__all__))
