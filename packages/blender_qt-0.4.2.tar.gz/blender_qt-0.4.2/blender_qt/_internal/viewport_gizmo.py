"""Internal viewport gizmo runtimes and shared state."""

from __future__ import annotations

import logging
from typing import Iterable

import bpy
from bpy_extras.view3d_utils import location_3d_to_region_2d, region_2d_to_location_3d
from mathutils import Vector

from ..core.app import ensure_qt_app, register_renderer, unregister_renderer
from ..core.config import log_message
from ..core.constants import MOUSE_BUTTONS, KeyboardModifier, MouseButton, LogCategory, event_modifiers
from ..core.interfaces import IOffscreenRenderer, IViewportRuntime
from ..render.gpu import blit_qimage, blit_qimage_world_quad

LOGGER = logging.getLogger(__name__)

_GIZMO_RUNTIMES: dict[str, IViewportRuntime] = {}
_FOCUSED_GIZMO_ID: str | None = None


def get_focused_gizmo_id() -> str | None:
    return _FOCUSED_GIZMO_ID


def set_focused_gizmo(gizmo_id: str | None) -> None:
    global _FOCUSED_GIZMO_ID
    if _FOCUSED_GIZMO_ID == gizmo_id:
        return
    if _FOCUSED_GIZMO_ID is not None:
        previous = _GIZMO_RUNTIMES.get(_FOCUSED_GIZMO_ID)
        if previous is not None:
            previous.clear_focus()
    log_message(
        LOGGER, LogCategory.FOCUS, logging.INFO, "Focused gizmo changed from %r to %r", _FOCUSED_GIZMO_ID, gizmo_id
    )
    _FOCUSED_GIZMO_ID = gizmo_id


def _tag_redraw_viewports(space_type: str = "VIEW_3D") -> None:
    for screen in bpy.data.screens:
        for area in screen.areas:
            if area.type == space_type:
                area.tag_redraw()


class _ViewportPanelRuntimeBase:
    def __init__(
        self,
        gizmo_id: str,
        *,
        width: int = 260,
        height: int = 220,
        drag_height: int = 28,
        is_2d: bool = True,
        billboard: bool = True,
        panel_normal: tuple[float, float, float] = (0.0, -1.0, 0.0),
        panel_up: tuple[float, float, float] = (0.0, 0.0, 1.0),
        panel_world_width: float = 2.0,
        initial_position: tuple[int, int] = (100, 100),
        initial_3d_position: tuple[float, float, float] | None = None,
        use_depth_test: bool = False,
        cull_backfaces: bool = False,
        space_type: str = "VIEW_3D",
    ) -> None:
        ensure_qt_app()
        self.gizmo_id = gizmo_id
        self.panel_width = width
        self.panel_height = height
        self.drag_height = drag_height
        self.is_2d = bool(is_2d)
        self.space_type = space_type
        self.billboard = billboard
        self.panel_normal = panel_normal
        self.panel_up = panel_up
        self.panel_world_width = panel_world_width
        self.use_depth_test = bool(use_depth_test)
        self.cull_backfaces = bool(cull_backfaces)
        self.screen_x = initial_position[0]
        self.screen_y = initial_position[1]
        self._world_corners: tuple[Vector, Vector, Vector, Vector] | None = None
        self._projected_corners: (
            tuple[tuple[float, float], tuple[float, float], tuple[float, float], tuple[float, float]] | None
        ) = None
        self.world_position: list[float] | None = (
            list(initial_3d_position) if not self.is_2d and initial_3d_position is not None else None
        )
        self.renderer: IOffscreenRenderer | None = None

    def _attach_renderer(self, renderer: IOffscreenRenderer) -> None:
        self.renderer = renderer
        self.renderer.set_size(self.panel_width, self.panel_height)
        self.renderer.updated.connect(lambda: _tag_redraw_viewports(self.space_type))
        register_renderer(renderer)

    @property
    def draw_area(self) -> tuple[int, int, int, int]:
        if not self.is_2d and self._projected_corners is not None:
            xs = [point[0] for point in self._projected_corners]
            ys = [point[1] for point in self._projected_corners]
            min_x = int(min(xs))
            min_y = int(min(ys))
            return (
                min_x,
                min_y,
                max(1, int(max(xs) - min_x)),
                max(1, int(max(ys) - min_y)),
            )
        return (self.screen_x, self.screen_y, self.panel_width, self.panel_height)

    def update_screen_position(self, context: bpy.types.Context) -> None:
        if self.is_2d or self.world_position is None:
            return
        self._update_projected_geometry(context)

    def _update_projected_geometry(self, context: bpy.types.Context) -> None:
        if self.world_position is None:
            self._world_corners = None
            self._projected_corners = None
            return
        region = context.region
        rv3d = context.region_data
        if rv3d is None:
            self._world_corners = None
            self._projected_corners = None
            return
        corners_3d = self._panel_world_corners(context)
        self._world_corners = corners_3d
        projected: list[tuple[float, float]] = []
        for corner in corners_3d:
            screen = location_3d_to_region_2d(region, rv3d, corner)
            if screen is None:
                self._world_corners = None
                self._projected_corners = None
                return
            projected.append((float(screen.x), float(screen.y)))
        self._projected_corners = (projected[0], projected[1], projected[2], projected[3])
        self.screen_x = int(min(projected_point[0] for projected_point in projected))
        self.screen_y = int(min(projected_point[1] for projected_point in projected))

    def _panel_world_corners(self, context: bpy.types.Context) -> tuple[Vector, Vector, Vector, Vector]:
        origin = Vector(self.world_position or (0.0, 0.0, 0.0))
        aspect = self.panel_height / max(1, self.panel_width)
        half_width = self.panel_world_width * 0.5
        half_height = half_width * aspect
        right, up = self._panel_basis(context)
        return (
            origin + (-half_width) * right,
            origin + half_width * right,
            origin + half_width * right + (2.0 * half_height) * up,
            origin + (-half_width) * right + (2.0 * half_height) * up,
        )

    def _panel_basis(self, context: bpy.types.Context) -> tuple[Vector, Vector]:
        if self.billboard:
            rv3d = context.region_data
            if rv3d is not None:
                view_matrix = rv3d.view_matrix.inverted().to_3x3()
                right = (view_matrix @ Vector((1.0, 0.0, 0.0))).normalized()
                up = (view_matrix @ Vector((0.0, 1.0, 0.0))).normalized()
                if right.length > 0.0 and up.length > 0.0:
                    return right, up
        normal = Vector(self.panel_normal)
        up = Vector(self.panel_up)
        if normal.length == 0.0:
            normal = Vector((0.0, -1.0, 0.0))
        if up.length == 0.0:
            up = Vector((0.0, 0.0, 1.0))
        normal = normal.normalized()
        up = up.normalized()
        right = up.cross(normal)
        if right.length == 0.0:
            right = Vector((1.0, 0.0, 0.0))
        right = right.normalized()
        up = normal.cross(right)
        if up.length == 0.0:
            up = Vector((0.0, 0.0, 1.0))
        return right, up.normalized()

    def contains(self, screen_position: Vector) -> bool:
        screen_x = int(screen_position.x)
        screen_y = int(screen_position.y)
        if not self.is_2d and self._projected_corners is not None:
            return _point_in_quad(float(screen_x), float(screen_y), self._projected_corners)
        x, y, w, h = self.draw_area
        return x <= screen_x < x + w and y <= screen_y < y + h

    def in_drag_handle(self, screen_position: Vector) -> bool:
        screen_x = int(screen_position.x)
        screen_y = int(screen_position.y)
        if not self.is_2d and self._projected_corners is not None:
            bl, br, tr, tl = self._projected_corners
            drag_frac = self.drag_height / max(1, self.panel_height)
            bl2 = _lerp_pt(tl, bl, drag_frac)
            br2 = _lerp_pt(tr, br, drag_frac)
            return _point_in_quad(float(screen_x), float(screen_y), (bl2, br2, tr, tl))
        x, y, w, h = self.draw_area
        handle_bottom = y + h - self.drag_height
        return x <= screen_x < x + w and handle_bottom <= screen_y < y + h

    def to_surface_point(self, screen_position: Vector) -> Vector:
        screen_x = int(screen_position.x)
        screen_y = int(screen_position.y)
        if not self.is_2d and self._projected_corners is not None:
            return self._surface_point_from_projected(screen_x, screen_y)
        logical_x = max(0, min(self.panel_width - 1, screen_x - self.screen_x))
        logical_y = max(0, min(self.panel_height - 1, (self.panel_height - 1) - (screen_y - self.screen_y)))
        return Vector((float(logical_x), float(logical_y), 0.0))

    def _surface_point_from_projected(self, screen_x: int, screen_y: int) -> Vector:
        if self._projected_corners is None:
            return Vector((0.0, 0.0, 0.0))
        bl, br, tr, tl = self._projected_corners
        uv = _inverse_bilinear(float(screen_x), float(screen_y), bl, br, tr, tl)
        surface_x = max(0, min(self.panel_width - 1, int(uv[0] * self.panel_width)))
        surface_y = max(0, min(self.panel_height - 1, int(uv[1] * self.panel_height)))
        return Vector((float(surface_x), float(surface_y), 0.0))

    @staticmethod
    def event_modifiers(event: bpy.types.Event) -> KeyboardModifier:
        return event_modifiers(event)

    def has_keyboard_focus(self) -> bool:
        return False if self.renderer is None else self.renderer.has_keyboard_focus()

    def clear_focus(self) -> None:
        if self.renderer is not None:
            log_message(LOGGER, LogCategory.FOCUS, logging.INFO, "Clearing focus for gizmo %s", self.gizmo_id)
            self.renderer.clear_focus()

    def handle_mouse_move(self, screen_position: Vector, event: bpy.types.Event) -> None:
        if self.renderer is not None:
            log_message(
                LOGGER,
                LogCategory.MOUSE,
                logging.INFO,
                "Gizmo mouse move at (%.2f, %.2f) for %s",
                screen_position.x,
                screen_position.y,
                self.gizmo_id,
            )
            self.renderer.send_mouse_move(self.to_surface_point(screen_position), self.event_modifiers(event))

    def handle_mouse_press(self, screen_position: Vector, event: bpy.types.Event) -> None:
        if self.renderer is not None:
            button = MOUSE_BUTTONS.get(event.type, MouseButton.LEFT)
            log_message(
                LOGGER,
                LogCategory.MOUSE,
                logging.INFO,
                "Gizmo mouse press %s at (%.2f, %.2f) for %s",
                event.type,
                screen_position.x,
                screen_position.y,
                self.gizmo_id,
            )
            self.renderer.send_mouse_press(self.to_surface_point(screen_position), button, self.event_modifiers(event))

    def handle_mouse_release(self, screen_position: Vector, event: object) -> None:
        if self.renderer is None:
            return
        button = MOUSE_BUTTONS.get(getattr(event, "type", "LEFTMOUSE"), MouseButton.LEFT)
        log_message(
            LOGGER,
            LogCategory.MOUSE,
            logging.INFO,
            "Gizmo mouse release %s at (%.2f, %.2f) for %s",
            getattr(event, "type", "LEFTMOUSE"),
            screen_position.x,
            screen_position.y,
            self.gizmo_id,
        )
        self.renderer.send_mouse_release(self.to_surface_point(screen_position), button, event_modifiers(event))

    def handle_key_event(self, event: bpy.types.Event) -> bool:
        if self.renderer is None:
            return False
        unicode_text = getattr(event, "unicode", "") or ""
        log_message(
            LOGGER,
            LogCategory.KEYBOARD,
            logging.INFO,
            "Gizmo key %s/%s for %s",
            event.type,
            event.value,
            self.gizmo_id,
        )
        return self.renderer.send_key(event.type, event.value, unicode_text, self.event_modifiers(event))

    def drag_3d(self, context: bpy.types.Context, screen_position: Vector, drag_offset: tuple[int, int]) -> None:
        if self.world_position is None:
            return
        region = context.region
        rv3d = context.region_data
        if rv3d is None:
            return
        screen_x = int(screen_position.x)
        screen_y = int(screen_position.y)
        target_x = screen_x - drag_offset[0] + self.panel_width // 2
        target_y = screen_y - drag_offset[1]
        new_3d = region_2d_to_location_3d(region, rv3d, Vector((target_x, target_y)), Vector(self.world_position))
        self.world_position = [new_3d.x, new_3d.y, new_3d.z]

    def draw(self, context: bpy.types.Context) -> None:
        if self.renderer is None:
            return
        self.update_screen_position(context)
        self.renderer.set_size(self.panel_width, self.panel_height)
        self.renderer.mark_visible()
        image = self.renderer.render()
        if image.isNull():
            return
        import gpu

        gpu.state.blend_set("ALPHA")
        if not self.is_2d and self._world_corners is not None:
            blit_qimage_world_quad(
                image,
                tuple(tuple(float(component) for component in corner) for corner in self._world_corners),
                use_depth_test=self.use_depth_test,
                cull_backfaces=self.cull_backfaces,
            )
        else:
            blit_qimage(image, self.draw_area)
        gpu.state.blend_set("NONE")

    def cleanup(self) -> None:
        if self.renderer is not None:
            unregister_renderer(self.renderer)
            self.renderer.cleanup()
            self.renderer.deleteLater()
            self.renderer = None


def _cross_2d(ax: float, ay: float, bx: float, by: float) -> float:
    return ax * by - ay * bx


def _point_in_quad(
    px: float,
    py: float,
    quad: tuple[tuple[float, float], tuple[float, float], tuple[float, float], tuple[float, float]],
) -> bool:
    for index in range(4):
        ax, ay = quad[index]
        bx, by = quad[(index + 1) % 4]
        if _cross_2d(bx - ax, by - ay, px - ax, py - ay) < 0:
            return False
    return True


def _lerp_pt(a: tuple[float, float], b: tuple[float, float], t: float) -> tuple[float, float]:
    return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)


def _inverse_bilinear(
    px: float,
    py: float,
    bl: tuple[float, float],
    br: tuple[float, float],
    tr: tuple[float, float],
    tl: tuple[float, float],
) -> tuple[float, float]:
    ex = br[0] - bl[0]
    ey = br[1] - bl[1]
    fx = tl[0] - bl[0]
    fy = tl[1] - bl[1]
    gx = bl[0] - br[0] + tr[0] - tl[0]
    gy = bl[1] - br[1] + tr[1] - tl[1]
    hx = px - bl[0]
    hy = py - bl[1]
    k2 = _cross_2d(gx, gy, fx, fy)
    k1 = _cross_2d(ex, ey, fx, fy) + _cross_2d(hx, hy, gx, gy)
    k0 = _cross_2d(hx, hy, ex, ey)
    if abs(k2) < 1e-10:
        v = -k0 / k1 if abs(k1) > 1e-10 else 0.0
    else:
        disc = max(0.0, k1 * k1 - 4.0 * k2 * k0)
        sqrt_disc = disc**0.5
        v1 = (-k1 + sqrt_disc) / (2.0 * k2)
        v2 = (-k1 - sqrt_disc) / (2.0 * k2)
        v = v1 if 0.0 <= v1 <= 1.0 else v2
    denom_x = ex + gx * v
    denom_y = ey + gy * v
    if abs(denom_x) > abs(denom_y):
        u = (hx - fx * v) / denom_x if abs(denom_x) > 1e-10 else 0.0
    else:
        u = (hy - fy * v) / denom_y if abs(denom_y) > 1e-10 else 0.0
    return (max(0.0, min(1.0, u)), max(0.0, min(1.0, 1.0 - v)))


def iter_runtimes() -> Iterable[IViewportRuntime]:
    return tuple(_GIZMO_RUNTIMES.values())


def get_runtime(gizmo_id: str) -> IViewportRuntime | None:
    return _GIZMO_RUNTIMES.get(gizmo_id)


def set_runtime(gizmo_id: str, runtime: IViewportRuntime) -> None:
    _GIZMO_RUNTIMES[gizmo_id] = runtime


def remove_runtime(gizmo_id: str) -> None:
    runtime = _GIZMO_RUNTIMES.pop(gizmo_id, None)
    if runtime is not None:
        runtime.cleanup()


def clear_runtimes() -> None:
    for runtime in _GIZMO_RUNTIMES.values():
        try:
            runtime.cleanup()
        except Exception:
            LOGGER.exception("Error cleaning up gizmo runtime")
    _GIZMO_RUNTIMES.clear()
