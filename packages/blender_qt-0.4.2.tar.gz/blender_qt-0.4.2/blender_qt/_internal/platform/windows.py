"""Windows-native helpers for Blender Qt managed windows."""

from __future__ import annotations

import ctypes
import os
from ctypes import wintypes
from typing import Callable

from PySide6 import QtCore, QtWidgets

_USER32 = ctypes.windll.user32
_KEYEVENTF_KEYUP = 0x0002
_SWP_NOMOVE = 0x0002
_SWP_NOSIZE = 0x0001
_SWP_NOACTIVATE = 0x0010
_FOREGROUND_HOOK: int | None = None
_ON_BLENDER_ACTIVATED: Callable[[], None] | None = None
_CALLBACK_REF = None
_DISPATCHER: "_ForegroundDispatcher | None" = None
_DISPATCH_PENDING = False

_USER32.SetWindowPos.argtypes = [
    wintypes.HWND,
    wintypes.HWND,
    ctypes.c_int,
    ctypes.c_int,
    ctypes.c_int,
    ctypes.c_int,
    wintypes.UINT,
]
_USER32.SetWindowPos.restype = wintypes.BOOL


class _ForegroundDispatcher(QtCore.QObject):
    """Marshal native foreground callbacks back onto Qt's GUI thread."""

    @QtCore.Slot()
    def dispatch(self) -> None:
        global _DISPATCH_PENDING

        _DISPATCH_PENDING = False
        if _ON_BLENDER_ACTIVATED is None:
            return

        _ON_BLENDER_ACTIVATED()


def _queue_blender_activated() -> None:
    """Schedule the activation callback on the Qt event loop."""
    global _DISPATCH_PENDING

    if _ON_BLENDER_ACTIVATED is None or _DISPATCHER is None or _DISPATCH_PENDING:
        return

    _DISPATCH_PENDING = True
    QtCore.QMetaObject.invokeMethod(_DISPATCHER, "dispatch", QtCore.Qt.QueuedConnection)


def bind_widget(widget: QtWidgets.QWidget) -> bool:
    """Raise *widget* above Blender while Blender is foreground."""
    if not has_foreground():
        return False

    qt_hwnd = int(widget.winId())
    if qt_hwnd == 0:
        return False

    _HWND_TOP = 0
    _USER32.SetWindowPos(
        qt_hwnd,
        _HWND_TOP,
        0,
        0,
        0,
        0,
        _SWP_NOMOVE | _SWP_NOSIZE | _SWP_NOACTIVATE,
    )
    return True


def install_foreground_hook(on_blender_activated: Callable[[], None]) -> None:
    """Run *on_blender_activated* when a window from this process becomes foreground."""
    global _FOREGROUND_HOOK, _ON_BLENDER_ACTIVATED, _CALLBACK_REF, _DISPATCHER
    if _FOREGROUND_HOOK is not None:
        return

    _ON_BLENDER_ACTIVATED = on_blender_activated
    _DISPATCHER = _ForegroundDispatcher()

    _EVENT_SYSTEM_FOREGROUND = 0x0003
    _WINEVENT_OUTOFCONTEXT = 0x0000

    _WINEVENTPROC = ctypes.WINFUNCTYPE(
        None,
        wintypes.HANDLE,
        wintypes.DWORD,
        wintypes.HWND,
        ctypes.c_long,
        ctypes.c_long,
        wintypes.DWORD,
        wintypes.DWORD,
    )

    @_WINEVENTPROC
    def _on_foreground(hook, event, hwnd, id_object, id_child, event_thread, event_time):
        del hook, event, id_object, id_child, event_thread, event_time
        if _ON_BLENDER_ACTIVATED is None:
            return

        pid = wintypes.DWORD()
        _USER32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value == os.getpid():
            _queue_blender_activated()

    _CALLBACK_REF = _on_foreground

    _USER32.SetWinEventHook.argtypes = [
        wintypes.DWORD,
        wintypes.DWORD,
        wintypes.HANDLE,
        _WINEVENTPROC,
        wintypes.DWORD,
        wintypes.DWORD,
        wintypes.DWORD,
    ]
    _USER32.SetWinEventHook.restype = wintypes.HANDLE

    _FOREGROUND_HOOK = _USER32.SetWinEventHook(
        _EVENT_SYSTEM_FOREGROUND,
        _EVENT_SYSTEM_FOREGROUND,
        None,
        _on_foreground,
        0,
        0,
        _WINEVENT_OUTOFCONTEXT,
    )


def uninstall_foreground_hook() -> None:
    """Remove the active foreground hook."""
    global _FOREGROUND_HOOK, _ON_BLENDER_ACTIVATED, _CALLBACK_REF, _DISPATCHER, _DISPATCH_PENDING
    if _FOREGROUND_HOOK is None:
        return

    _USER32.UnhookWinEvent(_FOREGROUND_HOOK)
    _FOREGROUND_HOOK = None
    _ON_BLENDER_ACTIVATED = None
    _CALLBACK_REF = None
    _DISPATCH_PENDING = False
    if _DISPATCHER is not None:
        _DISPATCHER.deleteLater()
    _DISPATCHER = None


def has_foreground() -> bool:
    """Return `True` when a window owned by this process has focus."""
    hwnd = _USER32.GetForegroundWindow()
    if hwnd == 0:
        return False

    process_id = wintypes.DWORD()
    _USER32.GetWindowThreadProcessId(hwnd, ctypes.byref(process_id))
    return process_id.value == os.getpid()


def reset_modifier_state() -> None:
    """Force-release common modifier keys after Blender regains focus."""
    _VK_SHIFT = 0x10
    _VK_CONTROL = 0x11
    _VK_MENU = 0x12
    _VK_LWIN = 0x5B
    _VK_RWIN = 0x5C

    for key_code in (_VK_SHIFT, _VK_CONTROL, _VK_MENU, _VK_LWIN, _VK_RWIN):
        _USER32.keybd_event(key_code, 0, _KEYEVENTF_KEYUP, 0)


def find_blender_window() -> int | None:
    """Return the top-level visible window handle for this Blender process."""
    hwnds: list[int] = []
    current_pid = os.getpid()
    enum_windows_proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    @enum_windows_proc
    def _enum_windows(hwnd: int, lparam: int) -> bool:
        del lparam
        if not _USER32.IsWindowVisible(hwnd):
            return True

        process_id = wintypes.DWORD()
        _USER32.GetWindowThreadProcessId(hwnd, ctypes.byref(process_id))
        if process_id.value != current_pid:
            return True
        if _USER32.GetParent(hwnd) != 0:
            return True

        hwnds.append(int(hwnd))
        return True

    _USER32.EnumWindows(_enum_windows, 0)
    return hwnds[0] if hwnds else None
