"""Linux/X11-native helpers for Blender Qt managed windows."""

from __future__ import annotations

import ctypes as _ct
import ctypes.util as _ct_util
import logging
import os

from PySide6 import QtWidgets

LOGGER = logging.getLogger(__name__)
_X11 = None
_TRANSIENT_WIDGETS: set[int] = set()
_CACHED_BLENDER_HANDLE: int | None = None

try:
    _x11_path = _ct_util.find_library("X11")
    if _x11_path:
        _X11 = _ct.cdll.LoadLibrary(_x11_path)
        _X11.XOpenDisplay.argtypes = [_ct.c_char_p]
        _X11.XOpenDisplay.restype = _ct.c_void_p
        _X11.XCloseDisplay.argtypes = [_ct.c_void_p]
        _X11.XCloseDisplay.restype = _ct.c_int
        _X11.XDefaultRootWindow.argtypes = [_ct.c_void_p]
        _X11.XDefaultRootWindow.restype = _ct.c_ulong
        _X11.XInternAtom.argtypes = [_ct.c_void_p, _ct.c_char_p, _ct.c_int]
        _X11.XInternAtom.restype = _ct.c_ulong
        _X11.XGetWindowProperty.argtypes = [
            _ct.c_void_p,
            _ct.c_ulong,
            _ct.c_ulong,
            _ct.c_long,
            _ct.c_long,
            _ct.c_int,
            _ct.c_ulong,
            _ct.POINTER(_ct.c_ulong),
            _ct.POINTER(_ct.c_int),
            _ct.POINTER(_ct.c_ulong),
            _ct.POINTER(_ct.c_ulong),
            _ct.POINTER(_ct.POINTER(_ct.c_ubyte)),
        ]
        _X11.XGetWindowProperty.restype = _ct.c_int
        _X11.XFree.argtypes = [_ct.c_void_p]
        _X11.XFree.restype = _ct.c_int
        _X11.XSetTransientForHint.argtypes = [_ct.c_void_p, _ct.c_ulong, _ct.c_ulong]
        _X11.XSetTransientForHint.restype = _ct.c_int
        _X11.XFlush.argtypes = [_ct.c_void_p]
        _X11.XFlush.restype = _ct.c_int
except OSError:
    LOGGER.debug("X11 library not available", exc_info=True)


def bind_widget(widget: QtWidgets.QWidget) -> bool:
    """Mark *widget* transient for Blender's X11 window."""
    if _X11 is None:
        return False

    blender_window = find_blender_window()
    qt_window = int(widget.winId())
    if blender_window is None or qt_window == 0:
        return False
    if qt_window in _TRANSIENT_WIDGETS and blender_window == _CACHED_BLENDER_HANDLE:
        return True

    display = _X11.XOpenDisplay(None)
    if not display:
        return False

    try:
        _X11.XSetTransientForHint(display, qt_window, blender_window)
        _X11.XFlush(display)
        _TRANSIENT_WIDGETS.add(qt_window)
        return True
    finally:
        _X11.XCloseDisplay(display)


def has_foreground() -> bool:
    """Return `True` when the active X11 window belongs to this process."""
    if _X11 is None:
        return True

    display = _X11.XOpenDisplay(None)
    if not display:
        return False

    try:
        root = _X11.XDefaultRootWindow(display)
        active_window = _x11_get_cardinal_property(display, root, b"_NET_ACTIVE_WINDOW")
        if active_window is None:
            return False
        return _x11_get_cardinal_property(display, active_window, b"_NET_WM_PID") == os.getpid()
    finally:
        _X11.XCloseDisplay(display)


def find_blender_window() -> int | None:
    """Return a likely Blender top-level X11 window for this process."""
    global _CACHED_BLENDER_HANDLE
    if _CACHED_BLENDER_HANDLE is not None:
        return _CACHED_BLENDER_HANDLE
    if _X11 is None:
        return None

    display = _X11.XOpenDisplay(None)
    if not display:
        return None

    try:
        root = _X11.XDefaultRootWindow(display)
        for window in _x11_get_window_list(display, root):
            if _x11_get_cardinal_property(display, window, b"_NET_WM_PID") == os.getpid():
                _CACHED_BLENDER_HANDLE = window
                return window
    finally:
        _X11.XCloseDisplay(display)

    return None


def _x11_get_cardinal_property(display, window, atom_name: bytes) -> int | None:
    """Read a single CARDINAL-like property from *window*."""
    atom = _X11.XInternAtom(display, atom_name, False)
    actual_type = _ct.c_ulong()
    actual_format = _ct.c_int()
    nitems = _ct.c_ulong()
    bytes_after = _ct.c_ulong()
    prop = _ct.POINTER(_ct.c_ubyte)()

    status = _X11.XGetWindowProperty(
        display,
        window,
        atom,
        0,
        1,
        False,
        0,
        _ct.byref(actual_type),
        _ct.byref(actual_format),
        _ct.byref(nitems),
        _ct.byref(bytes_after),
        _ct.byref(prop),
    )
    if status != 0 or not prop or nitems.value == 0:
        if prop:
            _X11.XFree(prop)
        return None

    value = _ct.cast(prop, _ct.POINTER(_ct.c_ulong))[0]
    _X11.XFree(prop)
    return int(value)


def _x11_get_window_list(display, root) -> list[int]:
    """Return `_NET_CLIENT_LIST` window IDs from the root window."""
    atom = _X11.XInternAtom(display, b"_NET_CLIENT_LIST", False)
    actual_type = _ct.c_ulong()
    actual_format = _ct.c_int()
    nitems = _ct.c_ulong()
    bytes_after = _ct.c_ulong()
    prop = _ct.POINTER(_ct.c_ubyte)()

    status = _X11.XGetWindowProperty(
        display,
        root,
        atom,
        0,
        0x7FFFFFFF,
        False,
        0,
        _ct.byref(actual_type),
        _ct.byref(actual_format),
        _ct.byref(nitems),
        _ct.byref(bytes_after),
        _ct.byref(prop),
    )
    if status != 0 or not prop:
        return []

    ids = _ct.cast(prop, _ct.POINTER(_ct.c_ulong))
    result = [int(ids[index]) for index in range(nitems.value)]
    _X11.XFree(prop)
    return result