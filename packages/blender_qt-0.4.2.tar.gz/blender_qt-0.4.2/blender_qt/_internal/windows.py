"""Internal managed-window state and event filters."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Callable

from PySide6 import QtCore, QtWidgets

from ..core.config import get_runtime_options
from ..core.platform import bind_widget_to_blender_host

LOGGER = logging.getLogger(__name__)


@dataclass
class ManagedWindow:
    """Tracked managed top-level widget."""

    widget: QtWidgets.QWidget
    on_close: Callable[[QtWidgets.QWidget], None] | None = None


MANAGED_WINDOWS: list[ManagedWindow] = []
_WINDOW_EVENT_FILTER: "_ManagedWindowEventFilter | None" = None
_APPLICATION_EVENT_FILTER: "_ApplicationEventFilter | None" = None


class _ManagedWindowEventFilter(QtCore.QObject):
    """Per-window event filter for managed widgets."""

    def eventFilter(self, watched: QtCore.QObject, event: QtCore.QEvent) -> bool:  # noqa: N802
        if not isinstance(watched, QtWidgets.QWidget):
            return super().eventFilter(watched, event)

        event_type = event.type()
        if event_type in (QtCore.QEvent.Show, QtCore.QEvent.WindowActivate):
            if watched.isWindow() and watched.isVisible() and should_attach_to_host(watched):
                bind_widget_to_blender_host(watched)
        elif event_type == QtCore.QEvent.Close:
            if watched.property("blender_qtKeepManagedOnClose"):
                return super().eventFilter(watched, event)
            watched.setProperty("blender_qtClosing", True)
            _handle_widget_closed(watched)
        elif event_type == QtCore.QEvent.Destroy:
            remove_window(watched)

        return super().eventFilter(watched, event)


class _ApplicationEventFilter(QtCore.QObject):
    """App-wide event filter used for auto-registering top-level widgets."""

    def eventFilter(self, watched: QtCore.QObject, event: QtCore.QEvent) -> bool:  # noqa: N802
        if isinstance(watched, QtWidgets.QWidget) and event.type() == QtCore.QEvent.Show:
            if watched.property("blender_qtAutoRegister") and watched.isWindow():
                _adopt_window(watched)
        return super().eventFilter(watched, event)


def event_filter() -> _ManagedWindowEventFilter:
    """Return the shared managed-window event filter."""
    global _WINDOW_EVENT_FILTER

    if _WINDOW_EVENT_FILTER is None:
        _WINDOW_EVENT_FILTER = _ManagedWindowEventFilter()
    return _WINDOW_EVENT_FILTER


def application_event_filter() -> _ApplicationEventFilter:
    """Return the shared application event filter."""
    global _APPLICATION_EVENT_FILTER

    if _APPLICATION_EVENT_FILTER is None:
        _APPLICATION_EVENT_FILTER = _ApplicationEventFilter()
    return _APPLICATION_EVENT_FILTER


def apply_window_flags(widget: QtWidgets.QWidget, stay_on_top: bool) -> None:
    """Apply managed-window z-order behavior."""
    if not stay_on_top:
        return

    if not should_attach_to_host(widget):
        return

    bind_widget_to_blender_host(widget)


def should_attach_to_host(widget: QtWidgets.QWidget) -> bool:
    """Return whether *widget* should be attached above Blender."""
    options = get_runtime_options()
    if not options.attach_windows_to_blender:
        return False
    if widget.property("blender_qtClosing"):
        return False
    return widget.property("blender_qtAttachToHost") is not False


def iter_managed_windows() -> list[ManagedWindow]:
    """Return live managed windows and prune stale entries."""
    stale_entries: list[ManagedWindow] = []
    live_entries: list[ManagedWindow] = []

    for entry in MANAGED_WINDOWS:
        try:
            entry.widget.objectName()
        except RuntimeError:
            stale_entries.append(entry)
            continue
        live_entries.append(entry)

    for stale_entry in stale_entries:
        try:
            MANAGED_WINDOWS.remove(stale_entry)
        except ValueError:
            continue

    return live_entries


def remove_window(widget: QtWidgets.QWidget) -> None:
    """Forget *widget* if it is currently tracked."""
    for entry in list(MANAGED_WINDOWS):
        if entry.widget is widget:
            MANAGED_WINDOWS.remove(entry)


def _handle_widget_closed(widget: QtWidgets.QWidget) -> None:
    """Run the tracked close callback for *widget* once."""
    entry = next((candidate for candidate in iter_managed_windows() if candidate.widget is widget), None)
    if entry is None:
        _schedule_widget_delete(widget)
        return

    remove_window(widget)
    widget.removeEventFilter(event_filter())
    widget.setAttribute(QtCore.Qt.WA_DeleteOnClose, False)
    if entry.on_close is None:
        _schedule_widget_delete(widget)
        return

    try:
        entry.on_close(widget)
    except Exception:  # noqa: BLE001
        LOGGER.exception("Error running managed-window close callback for %r", widget)
    finally:
        _schedule_widget_delete(widget)


def _schedule_widget_delete(widget: QtWidgets.QWidget) -> None:
    """Delete *widget* after the close event finishes unwinding."""

    def _delete_later() -> None:
        try:
            widget.deleteLater()
        except RuntimeError:
            return

    QtCore.QTimer.singleShot(0, _delete_later)


def _adopt_window(widget: QtWidgets.QWidget) -> None:
    """Start managing an already shown top-level widget."""
    if any(entry.widget is widget for entry in iter_managed_windows()):
        return

    options = get_runtime_options()
    apply_window_flags(widget, options.stay_on_top_windows)
    widget.setAttribute(QtCore.Qt.WA_DeleteOnClose, False)
    widget.installEventFilter(event_filter())
    MANAGED_WINDOWS.append(ManagedWindow(widget, None))
