"""QML-specific space runtime."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

import bpy

from ...core.app import ensure_qt_app, register_renderer, unregister_renderer
from ...core.space.base import tag_redraw_custom_spaces
from ...core.space.runtime import SpaceRuntimeBase
from ...theme.scale import get_scale_model
from .renderer import OffscreenQuickRenderer

LOGGER = logging.getLogger(__name__)

_RUNTIME_BY_AREA: dict[int, "QmlSpaceRuntime"] = {}


class QmlSpaceRuntime(SpaceRuntimeBase):
    def __init__(self, context: bpy.types.Context, qml_path: Path, tree_type: str) -> None:
        area = getattr(context, "area", None)
        area_pointer = area.as_pointer() if area else None
        super().__init__(area_pointer)
        ensure_qt_app()
        self.tree_type = tree_type
        scale_model = get_scale_model(context)
        self.renderer = OffscreenQuickRenderer(qml_path, scale_model.render_scale)
        self.renderer.updated.connect(lambda: tag_redraw_custom_spaces(self.tree_type))
        register_renderer(self.renderer)

    def cleanup(self) -> None:
        if self.renderer is not None:
            unregister_renderer(self.renderer)
            self.renderer.cleanup()
            self.renderer.deleteLater()
        super().cleanup()

    def reload_surface(self) -> None:
        if self.renderer is None:
            return
        self.renderer._load_qml()
        self.renderer._request_update()


def _area_key(context: bpy.types.Context) -> Optional[int]:
    area = getattr(context, "area", None)
    return area.as_pointer() if area else None


def get_runtime(
    context: bpy.types.Context,
    *,
    create: bool = True,
    qml_path: Path | None = None,
    tree_type: str = "",
) -> Optional[QmlSpaceRuntime]:
    key = _area_key(context)
    if key is None:
        return None
    runtime = _RUNTIME_BY_AREA.get(key)
    if runtime is None and create and qml_path is not None:
        runtime = QmlSpaceRuntime(context, qml_path, tree_type)
        _RUNTIME_BY_AREA[key] = runtime
    return runtime


def clear_runtimes() -> None:
    for runtime in _RUNTIME_BY_AREA.values():
        try:
            runtime.cleanup()
        except Exception:
            LOGGER.exception("Error cleaning up QML runtime")
    _RUNTIME_BY_AREA.clear()
