"""Offscreen QML renderer."""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Optional

from mathutils import Vector
from PySide6 import QtCore, QtGui, QtQuick, QtQuickWidgets, QtWidgets

from ...core.app import (
    flush_posted_events,
    is_focus_owner,
    release_focus_owner,
    set_focus_owner,
)
from ...core.constants import KeyboardModifier, MouseButton
from ...core.qt_input import to_qt_button, to_qt_modifiers, to_qt_point
from ...theme.bridge import get_theme_bridge
from ...theme.sync import apply_theme_to_qml_object

LOGGER = logging.getLogger(__name__)
_VISIBILITY_TIMEOUT_SECONDS = 0.25
_TEXT_FOCUS_CLASS_TOKENS = (
    "TextInput",
    "TextEdit",
    "TextField",
    "TextArea",
    "SpinBox",
)
_VIRTUAL_HOST_ORIGIN = QtCore.QPoint(96, 96)


class _QuickHostWindow(QtWidgets.QWidget):
    def __init__(self) -> None:
        super().__init__(None, QtCore.Qt.Window | QtCore.Qt.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WA_DontShowOnScreen, True)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground, True)
        self.setAutoFillBackground(False)
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        self.surface = QtQuickWidgets.QQuickWidget(self)
        self.surface.setResizeMode(QtQuickWidgets.QQuickWidget.SizeRootObjectToView)
        self.surface.setClearColor(QtCore.Qt.transparent)
        self.surface.setFocusPolicy(QtCore.Qt.StrongFocus)
        layout.addWidget(self.surface)


class OffscreenQuickRenderer(QtCore.QObject):
    """Render a QML scene offscreen and expose it as a ``QImage``."""

    updated = QtCore.Signal()
    UPDATE_EVENTS: set[int] = {
        QtCore.QEvent.UpdateRequest,
        QtCore.QEvent.LayoutRequest,
        QtCore.QEvent.FocusIn,
        QtCore.QEvent.FocusOut,
        QtCore.QEvent.InputMethod,
        QtCore.QEvent.Paint,
        QtCore.QEvent.Show,
        QtCore.QEvent.Hide,
        QtCore.QEvent.Move,
        QtCore.QEvent.Resize,
        QtCore.QEvent.WindowActivate,
        QtCore.QEvent.WindowDeactivate,
        QtCore.QEvent.PolishRequest,
    }

    def __init__(self, qml_path: Path, render_scale: float, parent: Optional[QtCore.QObject] = None) -> None:
        super().__init__(parent)
        self.qml_path = qml_path
        self.render_scale = max(1.0, float(render_scale))
        self.window_size = QtCore.QSize(320, 240)
        screen = QtGui.QGuiApplication.primaryScreen()
        available = screen.availableGeometry() if screen is not None else QtCore.QRect(0, 0, 1920, 1080)
        self.max_window_size = QtCore.QSize(max(1, available.width()), max(1, available.height()))
        self.mutex = QtCore.QMutex()
        self.last_image = QtGui.QImage()
        self.host_window = _QuickHostWindow()
        self.host_window.move(_VIRTUAL_HOST_ORIGIN)
        self.host_window.resize(self.window_size)
        self.surface = self.host_window.surface
        self.surface.resize(self.window_size)
        self.quick_window = self.surface.quickWindow()
        self.qml_engine = self.surface.engine()
        self.qml_engine.rootContext().setContextProperty("blenderTheme", get_theme_bridge())
        self.root_item: Optional[QtQuick.QQuickItem] = None
        self.active_mouse_buttons = QtCore.Qt.NoButton
        self._dirty = True
        self._last_visible_at = 0.0
        self._continuous_redraw_until = 0.0
        application = QtWidgets.QApplication.instance()
        if application is not None:
            application.installEventFilter(self)
        self.host_window.installEventFilter(self)
        self.surface.installEventFilter(self)
        if self.quick_window is not None:
            self.quick_window.installEventFilter(self)
        self.surface.statusChanged.connect(self._on_status_changed)
        self.host_window.show()
        self.surface.show()
        self._load_qml()
        self._request_update(keep_redrawing_for=0.2)

    def _is_owned_object(self, watched: QtCore.QObject) -> bool:
        if watched in {self.host_window, self.surface, self.quick_window, self.root_item}:
            return True
        if isinstance(watched, QtWidgets.QWidget):
            widget: Optional[QtWidgets.QWidget] = watched
            while widget is not None:
                if widget is self.host_window:
                    return True
                widget = widget.parentWidget()
            return False
        if isinstance(watched, QtQuick.QQuickItem):
            item: Optional[QtQuick.QQuickItem] = watched
            while item is not None:
                if item is self.root_item:
                    return True
                item = item.parentItem()
            return False
        parent = watched.parent()
        while parent is not None:
            if parent in {self.host_window, self.surface, self.quick_window, self.root_item}:
                return True
            parent = parent.parent()
        return False

    def _request_update(self, *, keep_redrawing_for: float = 0.0) -> None:
        self._dirty = True
        if keep_redrawing_for > 0.0:
            self._continuous_redraw_until = max(self._continuous_redraw_until, time.monotonic() + keep_redrawing_for)

    def _needs_render(self) -> bool:
        return self._dirty or self.last_image.isNull() or time.monotonic() < self._continuous_redraw_until

    def _log_component_errors(self, operation_name: str) -> None:
        error_messages = [str(component_error) for component_error in self.surface.errors()]
        if not error_messages:
            LOGGER.error("%s failed without detailed QML errors.", operation_name)
            return
        for error_message in error_messages:
            LOGGER.error("%s: %s", operation_name, error_message)

    def _bind_root_item(self) -> None:
        if self.root_item is not None:
            try:
                self.root_item.removeEventFilter(self)
            except RuntimeError:
                LOGGER.debug("Failed to remove root item event filter", exc_info=True)
        root_object = self.surface.rootObject()
        if root_object is None:
            self.root_item = None
            return
        if not isinstance(root_object, QtQuick.QQuickItem):
            LOGGER.error("QML root object must be a QQuickItem, received %s.", type(root_object).__name__)
            self.root_item = None
            return
        self.root_item = root_object
        self.root_item.installEventFilter(self)
        apply_theme_to_qml_object(self.root_item)
        self.root_item.forceActiveFocus()
        self._request_update(keep_redrawing_for=0.2)

    def _on_status_changed(self, status: QtQuickWidgets.QQuickWidget.Status) -> None:
        if status == QtQuickWidgets.QQuickWidget.Status.Ready:
            self._bind_root_item()
        elif status == QtQuickWidgets.QQuickWidget.Status.Error:
            self._log_component_errors("QML load")

    def _load_qml(self) -> None:
        self.root_item = None
        self.surface.setSource(QtCore.QUrl.fromLocalFile(str(self.qml_path.resolve())))
        if self.surface.status() == QtQuickWidgets.QQuickWidget.Status.Ready:
            self._bind_root_item()
        elif self.surface.status() == QtQuickWidgets.QQuickWidget.Status.Error:
            self._log_component_errors("QML load")

    def eventFilter(self, watched: QtCore.QObject, event: QtCore.QEvent) -> bool:
        if event.type() in self.UPDATE_EVENTS and self._is_owned_object(watched):
            self._request_update(keep_redrawing_for=0.2)
        return super().eventFilter(watched, event)

    def _normalize_capture(self, image: QtGui.QImage, width: int, height: int) -> QtGui.QImage:
        if image.isNull():
            fallback = QtGui.QImage(width, height, QtGui.QImage.Format_ARGB32)
            fallback.fill(QtGui.QColor("#880000"))
            return fallback
        normalized = image.copy()
        if normalized.devicePixelRatio() != 1.0:
            normalized.setDevicePixelRatio(1.0)
        if normalized.width() != width or normalized.height() != height:
            normalized = normalized.scaled(width, height, QtCore.Qt.IgnoreAspectRatio, QtCore.Qt.SmoothTransformation)
        return normalized

    def apply_theme(self) -> None:
        if self.root_item is not None:
            apply_theme_to_qml_object(self.root_item)
            self.root_item.update()
        self.surface.update()
        self._request_update(keep_redrawing_for=0.2)

    def mark_visible(self) -> None:
        self._last_visible_at = time.monotonic()

    def is_visible(self) -> bool:
        return (time.monotonic() - self._last_visible_at) <= _VISIBILITY_TIMEOUT_SECONDS

    def is_dirty(self) -> bool:
        return self._needs_render()

    def set_size(self, width: int, height: int) -> None:
        width = max(1, min(width, self.max_window_size.width()))
        height = max(1, min(height, self.max_window_size.height()))
        if self.window_size.width() == width and self.window_size.height() == height:
            return
        self.window_size = QtCore.QSize(width, height)
        self.host_window.resize(width, height)
        self.surface.resize(width, height)
        self._request_update(keep_redrawing_for=0.2)

    def service(self) -> None:
        if not self._needs_render():
            return
        flush_posted_events()
        self._do_render()

    def _do_render(self) -> None:
        if not self._needs_render():
            return
        with QtCore.QMutexLocker(self.mutex):
            width = max(1, self.window_size.width())
            height = max(1, self.window_size.height())
            if self.host_window.width() != width or self.host_window.height() != height:
                self.host_window.resize(width, height)
                self.surface.resize(width, height)
            self.host_window.ensurePolished()
            self.surface.ensurePolished()
            layout = self.host_window.layout()
            if layout is not None:
                layout.activate()
            self.host_window.updateGeometry()
            self.surface.updateGeometry()
            self.surface.update()
            flush_posted_events()
            self.last_image = self._normalize_capture(self.surface.grabFramebuffer(), width, height)
            self._dirty = False
        self.updated.emit()

    def render(self) -> QtGui.QImage:
        self.mark_visible()
        if self._needs_render():
            self._do_render()
        with QtCore.QMutexLocker(self.mutex):
            return self.last_image.copy()

    def _surface_global_position(self, position: QtCore.QPoint) -> QtCore.QPointF:
        return QtCore.QPointF(self.surface.mapToGlobal(position))

    def _send_mouse_event(
        self,
        event_type: QtCore.QEvent.Type,
        surface_position: Vector,
        button: MouseButton,
        buttons: QtCore.Qt.MouseButtons,
        modifiers: KeyboardModifier,
    ) -> None:
        qt_position = to_qt_point(surface_position)
        event = QtGui.QMouseEvent(
            event_type,
            QtCore.QPointF(qt_position),
            self._surface_global_position(qt_position),
            to_qt_button(button),
            buttons,
            to_qt_modifiers(modifiers),
        )
        QtWidgets.QApplication.sendEvent(self.surface, event)

    def send_mouse_move(self, surface_position: Vector, modifiers: KeyboardModifier = KeyboardModifier.NONE) -> None:
        self._send_mouse_event(
            QtCore.QEvent.Type.MouseMove,
            surface_position,
            MouseButton.NONE,
            self.active_mouse_buttons,
            modifiers,
        )
        self._request_update(keep_redrawing_for=0.1)

    def send_mouse_press(
        self,
        surface_position: Vector,
        button: MouseButton,
        modifiers: KeyboardModifier = KeyboardModifier.NONE,
    ) -> None:
        qt_button = to_qt_button(button)
        self.active_mouse_buttons |= qt_button
        set_focus_owner(self)
        self.surface.setFocus(QtCore.Qt.MouseFocusReason)
        self._send_mouse_event(
            QtCore.QEvent.Type.MouseButtonPress,
            surface_position,
            button,
            self.active_mouse_buttons,
            modifiers,
        )
        self._request_update(keep_redrawing_for=0.35)

    def send_mouse_release(
        self,
        surface_position: Vector,
        button: MouseButton,
        modifiers: KeyboardModifier = KeyboardModifier.NONE,
    ) -> None:
        qt_button = to_qt_button(button)
        buttons_after = self.active_mouse_buttons & ~qt_button
        self._send_mouse_event(
            QtCore.QEvent.Type.MouseButtonRelease,
            surface_position,
            button,
            buttons_after,
            modifiers,
        )
        self.active_mouse_buttons = buttons_after
        self._request_update(keep_redrawing_for=0.35)

    def has_keyboard_focus(self) -> bool:
        if not is_focus_owner(self):
            return False
        if self.root_item is not None:
            try:
                qml_flag = self.root_item.property("hasTextFocus")
                if qml_flag is True:
                    return True
            except Exception:
                pass
        focus_item = None if self.quick_window is None else self.quick_window.activeFocusItem()
        if focus_item is None or focus_item is self.root_item:
            return False
        item: QtQuick.QQuickItem | None = focus_item
        while item is not None:
            try:
                if item.inputMethodQuery(QtCore.Qt.ImEnabled):
                    return True
            except Exception:
                pass
            try:
                cpp_name = item.metaObject().className()
                if any(token in cpp_name for token in _TEXT_FOCUS_CLASS_TOKENS):
                    return True
            except Exception:
                pass
            cls_name = type(item).__name__
            if any(token in cls_name for token in _TEXT_FOCUS_CLASS_TOKENS):
                return True
            item = item.parentItem()
        return False

    def clear_focus(self) -> None:
        if self.root_item is not None:
            self.root_item.forceActiveFocus()
        self.surface.setFocus(QtCore.Qt.OtherFocusReason)
        release_focus_owner(self)
        self._request_update(keep_redrawing_for=0.1)

    def send_key(
        self,
        event_type: str,
        event_value: str,
        unicode_text: str,
        modifiers: KeyboardModifier = KeyboardModifier.NONE,
    ) -> bool:
        from ...core.constants import KEY_MAP

        qt_key = KEY_MAP.get(event_type)
        if qt_key is None:
            return False
        if (
            self.root_item is not None
            and self.quick_window is not None
            and self.quick_window.activeFocusItem() is None
        ):
            self.root_item.forceActiveFocus()
        target = None if self.quick_window is None else self.quick_window.activeFocusItem()
        target = target or self.root_item or self.quick_window or self.surface
        qt_event_type = QtCore.QEvent.KeyPress if event_value == "PRESS" else QtCore.QEvent.KeyRelease
        key_event = QtGui.QKeyEvent(qt_event_type, qt_key, to_qt_modifiers(modifiers), unicode_text)
        QtWidgets.QApplication.sendEvent(target, key_event)
        self._request_update(keep_redrawing_for=0.15)
        return True

    def cleanup(self) -> None:
        """Release QML engine resources."""
        release_focus_owner(self)
        if self.root_item is not None:
            try:
                self.root_item.removeEventFilter(self)
            except RuntimeError:
                LOGGER.debug("Failed to remove root item event filter", exc_info=True)
            self.root_item = None
        if self.quick_window is not None:
            try:
                self.quick_window.removeEventFilter(self)
            except RuntimeError:
                LOGGER.debug("Failed to remove quick window event filter", exc_info=True)
        try:
            self.surface.removeEventFilter(self)
            self.host_window.removeEventFilter(self)
        except RuntimeError:
            LOGGER.debug("Failed to remove widget event filters", exc_info=True)
        application = QtWidgets.QApplication.instance()
        if application is not None:
            try:
                application.removeEventFilter(self)
            except RuntimeError:
                LOGGER.debug("Failed to remove application event filter", exc_info=True)
        self.qml_engine.clearComponentCache()
        self.host_window.close()
        self.host_window.deleteLater()
