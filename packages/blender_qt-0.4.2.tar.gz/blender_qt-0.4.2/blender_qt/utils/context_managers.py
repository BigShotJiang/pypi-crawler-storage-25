"""Context managers for Blender-aware execution paths."""

from __future__ import annotations

from contextlib import contextmanager
from typing import Iterator

import bpy


@contextmanager
def invoke_in_main() -> Iterator[None]:
    """Temporarily override Blender context to the main window."""
    from ..core.app import get_main_window  # noqa: WPS433

    window = get_main_window()
    if window is None:
        yield
        return

    with bpy.context.temp_override(window=window):
        yield
