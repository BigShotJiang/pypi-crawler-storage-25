"""Shared GPU blit — render a ``QImage`` into the current Blender region.

This eliminates the duplicated numpy -> GPUTexture -> shader draw code that
previously lived in both the QML and Widgets runtime modules.
"""

from __future__ import annotations

import logging

import numpy as np
from PySide6 import QtGui

LOGGER = logging.getLogger(__name__)


def _image_texture_data(image: QtGui.QImage) -> tuple[tuple[int, int], "object"]:
    import gpu  # noqa: WPS433
    from gpu.types import Buffer  # noqa: WPS433

    rgba_image = image.convertToFormat(QtGui.QImage.Format_RGBA8888)
    image_width = rgba_image.width()
    image_height = rgba_image.height()

    raw_pointer = rgba_image.constBits()
    bytes_per_line = rgba_image.bytesPerLine()

    pixel_data = np.frombuffer(raw_pointer, dtype=np.uint8, count=bytes_per_line * image_height)
    pixel_data = pixel_data.reshape((image_height, bytes_per_line))[:, : image_width * 4].flatten()

    float_buffer = Buffer(
        "FLOAT",
        image_width * image_height * 4,
        pixel_data.astype(np.float32) / 255.0,
    )
    texture = gpu.types.GPUTexture(
        (image_width, image_height),
        format="RGBA32F",
        data=float_buffer,
    )
    return (image_width, image_height), texture


def blit_qimage(
    image: QtGui.QImage,
    draw_area: tuple[int, int, int, int],
) -> None:
    """Draw *image* into the active Blender region using the GPU module.

    The image is converted to RGBA8888, uploaded as a float texture, and
    rendered via the built-in ``IMAGE`` shader.

    Args:
        image: Source Qt image.  Must not be null.
        draw_area: ``(x, y, width, height)`` of the target rectangle in
            region-local pixel coordinates.
    """
    # Late imports — these modules are only available inside Blender.
    import gpu  # noqa: WPS433
    from gpu_extras.batch import batch_for_shader  # noqa: WPS433

    (_, _), texture = _image_texture_data(image)

    draw_x, draw_y, draw_width, draw_height = draw_area
    vertices = [
        (draw_x, draw_y),
        (draw_x + draw_width, draw_y),
        (draw_x + draw_width, draw_y + draw_height),
        (draw_x, draw_y + draw_height),
    ]
    texture_coordinates = [(0, 1), (1, 1), (1, 0), (0, 0)]
    triangle_indices = [(0, 1, 2), (2, 3, 0)]

    shader = gpu.shader.from_builtin("IMAGE")
    batch = batch_for_shader(
        shader,
        "TRIS",
        {"pos": vertices, "texCoord": texture_coordinates},
        indices=triangle_indices,
    )

    try:
        shader.bind()
        shader.uniform_sampler("image", texture)
        batch.draw(shader)
    finally:
        del texture


def blit_qimage_quad(
    image: QtGui.QImage,
    corners: tuple[
        tuple[float, float],
        tuple[float, float],
        tuple[float, float],
        tuple[float, float],
    ],
    subdivisions: int = 16,
) -> None:
    """Draw *image* into an arbitrary quad defined by four screen-space corners.

    The quad is subdivided into a grid of sub-triangles to avoid perspective
    shearing artifacts that occur when the GPU linearly interpolates texture
    coordinates across a single large triangle.

    Corner order: bottom-left, bottom-right, top-right, top-left.

    Args:
        image: Source Qt image.  Must not be null.
        corners: Four ``(x, y)`` screen-space coordinates.
        subdivisions: Number of subdivisions per axis (higher = more accurate).
    """
    import gpu  # noqa: WPS433
    from gpu_extras.batch import batch_for_shader  # noqa: WPS433

    (_, _), texture = _image_texture_data(image)

    bl, br, tr, tl = corners
    n = max(1, subdivisions)

    vertices: list[tuple[float, float]] = []
    tex_coords: list[tuple[float, float]] = []
    indices: list[tuple[int, int, int]] = []

    # Generate a (n+1) x (n+1) grid of bilinearly interpolated positions.
    for row in range(n + 1):
        v = row / n
        for col in range(n + 1):
            u = col / n
            # Bilinear interpolation of the quad corners.
            x = (1 - u) * (1 - v) * bl[0] + u * (1 - v) * br[0] + u * v * tr[0] + (1 - u) * v * tl[0]
            y = (1 - u) * (1 - v) * bl[1] + u * (1 - v) * br[1] + u * v * tr[1] + (1 - u) * v * tl[1]
            vertices.append((x, y))
            # Texture: u maps left->right, v maps bottom->top; Qt images
            # are top-down so tex_v = 1 - v.
            tex_coords.append((u, 1.0 - v))

    # Build two triangles per grid cell.
    for row in range(n):
        for col in range(n):
            i00 = row * (n + 1) + col
            i10 = i00 + 1
            i01 = i00 + (n + 1)
            i11 = i01 + 1
            indices.append((i00, i10, i11))
            indices.append((i11, i01, i00))

    shader = gpu.shader.from_builtin("IMAGE")
    batch = batch_for_shader(
        shader,
        "TRIS",
        {"pos": vertices, "texCoord": tex_coords},
        indices=indices,
    )

    try:
        shader.bind()
        shader.uniform_sampler("image", texture)
        batch.draw(shader)
    finally:
        del texture


def blit_qimage_world_quad(
    image: QtGui.QImage,
    corners: tuple[
        tuple[float, float, float],
        tuple[float, float, float],
        tuple[float, float, float],
        tuple[float, float, float],
    ],
    *,
    use_depth_test: bool = False,
    cull_backfaces: bool = False,
) -> None:
    """Draw *image* on a 3D quad defined by four world-space corners."""
    import gpu  # noqa: WPS433
    from gpu_extras.batch import batch_for_shader  # noqa: WPS433

    (_, _), texture = _image_texture_data(image)

    shader = gpu.shader.from_builtin("IMAGE")
    batch = batch_for_shader(
        shader,
        "TRIS",
        {
            "pos": corners,
            "texCoord": ((0.0, 1.0), (1.0, 1.0), (1.0, 0.0), (0.0, 0.0)),
        },
        indices=((0, 1, 2), (2, 3, 0)),
    )

    gpu.state.depth_test_set("LESS_EQUAL" if use_depth_test else "NONE")
    gpu.state.depth_mask_set(False)
    gpu.state.face_culling_set("BACK" if cull_backfaces else "NONE")
    try:
        shader.bind()
        shader.uniform_sampler("image", texture)
        batch.draw(shader)
    finally:
        gpu.state.face_culling_set("NONE")
        gpu.state.depth_test_set("NONE")
        gpu.state.depth_mask_set(False)
        del texture
