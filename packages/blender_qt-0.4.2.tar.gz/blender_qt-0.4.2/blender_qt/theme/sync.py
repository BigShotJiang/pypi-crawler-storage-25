"""Global theme synchronisation between Blender and the running Qt application.

Call :func:`sync_application_theme` once per frame (typically from the event
timer) to detect Blender theme changes and propagate them to the ``QPalette``,
application font, and :class:`~blender_qt.theme.bridge.BlenderThemeBridge`.
"""

from __future__ import annotations

import logging

from PySide6 import QtCore, QtGui, QtQml, QtWidgets

from .bridge import get_theme_bridge
from .builder import build_theme_state
from .scale import as_qfont_weight

LOGGER = logging.getLogger(__name__)

_ACTIVE_SIGNATURE: tuple[int, ...] | None = None


def sync_application_theme(
    application: QtWidgets.QApplication | None = None,
) -> bool:
    """Compare the live Blender theme against the last snapshot and apply changes.

    If the theme signature has not changed since the last call this is a cheap
    no-op.  Otherwise the ``QPalette``, application font, and theme bridge are
    all updated.

    Args:
        application: Optional explicit ``QApplication``.  When ``None`` the
            current instance is used.

    Returns:
        ``True`` if the theme changed and was re-applied, ``False`` otherwise.
    """
    global _ACTIVE_SIGNATURE

    state = build_theme_state()
    if state.signature == _ACTIVE_SIGNATURE:
        return False

    _ACTIVE_SIGNATURE = state.signature

    target_application = application or QtWidgets.QApplication.instance()
    if target_application is not None:
        target_application.setPalette(QtGui.QPalette(state.palette))
        application_font = QtGui.QFont(target_application.font())
        application_font.setPointSizeF(state.metrics["widgetPointSize"])
        application_font.setWeight(as_qfont_weight(state.metrics["widgetWeight"]))
        target_application.setFont(application_font)

    get_theme_bridge().update(state.colors, state.metrics)
    return True


def apply_theme_to_widget(
    widget: QtWidgets.QWidget | None,
    include_children: bool = True,
) -> None:
    """Recursively apply the current application palette and font to *widget*.

    After setting the palette and font each widget is unpolished and re-polished
    so style-sheet-driven appearances update correctly.

    Args:
        widget: Root widget to theme.  ``None`` is silently ignored.
        include_children: When ``True`` (default) all child widgets are also
            themed.
    """
    if widget is None:
        return

    application = QtWidgets.QApplication.instance()
    if application is None:
        return

    current_palette = QtGui.QPalette(application.palette())
    current_font = QtGui.QFont(application.font())

    widgets_to_update: list[QtWidgets.QWidget] = [widget]
    if include_children:
        widgets_to_update.extend(widget.findChildren(QtWidgets.QWidget))

    for current_widget in widgets_to_update:
        current_widget.setPalette(QtGui.QPalette(current_palette))
        if current_widget.parentWidget() is None or current_widget.isWindow():
            current_widget.setFont(QtGui.QFont(current_font))

        style = current_widget.style()
        if style is not None:
            style.unpolish(current_widget)
            style.polish(current_widget)

        current_widget.updateGeometry()
        current_widget.repaint()


def apply_theme_to_qml_object(
    root_object: QtCore.QObject | None,
    include_children: bool = True,
) -> None:
    """Apply the current Qt palette to a QML object tree when supported.

    This updates any object exposing a writable ``palette`` property. Objects
    without that property are ignored.

    Args:
        root_object: Root QML object. ``None`` is silently ignored.
        include_children: When ``True`` (default) recurse through the full tree.
    """
    if root_object is None:
        return

    application = QtWidgets.QApplication.instance()
    if application is None:
        return

    theme_bridge = get_theme_bridge()
    palette_values = {
        "window": QtGui.QColor(theme_bridge.window),
        "windowText": QtGui.QColor(theme_bridge.windowText),
        "base": QtGui.QColor(theme_bridge.base),
        "alternateBase": QtGui.QColor(theme_bridge.alternateBase),
        "toolTipBase": QtGui.QColor(theme_bridge.toolTipBase),
        "toolTipText": QtGui.QColor(theme_bridge.toolTipText),
        "text": QtGui.QColor(theme_bridge.text),
        "button": QtGui.QColor(theme_bridge.button),
        "buttonText": QtGui.QColor(theme_bridge.buttonText),
        "highlight": QtGui.QColor(theme_bridge.highlight),
        "highlightedText": QtGui.QColor(theme_bridge.highlightedText),
        "placeholderText": QtGui.QColor(theme_bridge.mutedText),
    }

    for current_object in _iter_qml_objects(root_object, include_children=include_children):
        for property_name, value in palette_values.items():
            _write_qml_property(current_object, f"palette.{property_name}", value)

        update = getattr(current_object, "update", None)
        if callable(update):
            try:
                update()
            except Exception:
                LOGGER.debug("Failed to update themed QML object", exc_info=True)


def apply_popup_font_scale(
    widget: QtWidgets.QWidget | None,
) -> float:
    """Scale *widget*'s font for use in a popup (combo-box dropdown, menu).

    Args:
        widget: Widget to scale.

    Returns:
        The effective scale factor that was applied.
    """
    theme_bridge = get_theme_bridge()
    return _apply_widget_font_scale(widget, max(1.0, float(theme_bridge.popupScale)))


def apply_dialog_font_scale(
    widget: QtWidgets.QWidget | None,
) -> float:
    """Scale *widget*'s font for use in a modal dialog.

    Args:
        widget: Widget to scale.

    Returns:
        The effective scale factor that was applied.
    """
    theme_bridge = get_theme_bridge()
    return _apply_widget_font_scale(
        widget,
        max(1.0, float(theme_bridge.popupScale) * float(theme_bridge.logicalUiScale)),
    )


def apply_popup_font_scale_tree(
    widget: QtWidgets.QWidget | None,
) -> float:
    """Apply popup font scaling to *widget* and all its children.

    Args:
        widget: Root widget.

    Returns:
        The effective scale factor that was applied.
    """
    popup_scale = apply_popup_font_scale(widget)
    if widget is not None:
        for child in widget.findChildren(QtWidgets.QWidget):
            apply_popup_font_scale(child)
    return popup_scale


def apply_dialog_font_scale_tree(
    widget: QtWidgets.QWidget | None,
) -> float:
    """Apply dialog font scaling to *widget* and all its children.

    Args:
        widget: Root widget.

    Returns:
        The effective scale factor that was applied.
    """
    dialog_scale = apply_dialog_font_scale(widget)
    if widget is not None:
        for child in widget.findChildren(QtWidgets.QWidget):
            apply_dialog_font_scale(child)
    return dialog_scale


# MARK: Private helpers


def _apply_widget_font_scale(
    widget: QtWidgets.QWidget | None,
    scale: float,
) -> float:
    """Apply a font-size multiplier to *widget*.

    Args:
        widget: Target widget.  ``None`` is silently ignored.
        scale: Multiplier relative to the base widget point size.

    Returns:
        The *scale* factor that was passed in.
    """
    if widget is None:
        return scale

    theme_bridge = get_theme_bridge()
    logical_ui_scale = max(float(theme_bridge.logicalUiScale), 1e-6)
    font = QtGui.QFont(widget.font())

    if font.pointSizeF() > 0.0:
        base_point_size = max(1.0, float(theme_bridge.widgetPointSize) / logical_ui_scale)
        font.setPointSizeF(base_point_size * scale)
    elif font.pixelSize() > 0:
        base_pixel_size = max(1, int(round(font.pixelSize() / logical_ui_scale)))
        font.setPixelSize(max(1, int(round(base_pixel_size * scale))))

    widget.setFont(font)
    return scale


def _iter_qml_objects(
    root_object: QtCore.QObject,
    *,
    include_children: bool,
) -> list[QtCore.QObject]:
    objects: list[QtCore.QObject] = [root_object]
    if not include_children:
        return objects

    seen: set[int] = {id(root_object)}
    stack: list[QtCore.QObject] = [root_object]

    while stack:
        current_object = stack.pop()
        for child in current_object.children():
            if id(child) in seen:
                continue
            seen.add(id(child))
            objects.append(child)
            stack.append(child)

        child_items = getattr(current_object, "childItems", None)
        if not callable(child_items):
            continue

        for child_item in child_items():
            if id(child_item) in seen:
                continue
            seen.add(id(child_item))
            objects.append(child_item)
            stack.append(child_item)

    return objects


def _write_qml_property(
    target: QtCore.QObject,
    property_name: str,
    value: object,
) -> None:
    try:
        property_binding = QtQml.QQmlProperty(target, property_name)
    except Exception:
        return

    if not property_binding.isValid() or not property_binding.isWritable():
        return

    try:
        property_binding.write(value)
    except Exception:
        LOGGER.debug("Failed writing QML property %s", property_name, exc_info=True)
