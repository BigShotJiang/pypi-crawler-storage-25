"""UI scale helpers and font weight utilities.

Reads Blender preference values and provides helpers for scaling popup and
dialog widgets to match the current DPI / ui_scale configuration.
"""

from __future__ import annotations

import logging

import bpy
from PySide6 import QtGui

from ..core.structs import BlenderScale

LOGGER = logging.getLogger(__name__)

#: Fixed logical scale applied to Blender Qt rendering.  Matches the value used
#: during the prototype and is baked into font-size calculations.
LOGICAL_UI_SCALE: float = 1.75


def get_scale_model(context: bpy.types.Context | None = None) -> BlenderScale:
    """Read Blender preferences and return a :class:`BlenderScale`.

    Args:
        context: Optional Blender context.  Falls back to ``bpy.context``.

    Returns:
        A frozen snapshot of the current scale parameters.
    """
    preferences = (context or bpy.context).preferences
    popup_scale = float(preferences.view.ui_scale or 1.0)
    system_scale = float(preferences.system.ui_scale or 1.0)
    return BlenderScale(
        logical_ui_scale=LOGICAL_UI_SCALE,
        popup_scale=popup_scale,
        render_scale=max(1.0, system_scale),
        system_scale=system_scale,
    )


def as_qfont_weight(weight_value: float) -> QtGui.QFont.Weight:
    """Convert a numeric weight (100–900) to the nearest ``QFont.Weight``.

    Args:
        weight_value: CSS-style font weight (e.g. 400 for normal, 700 for bold).

    Returns:
        The closest ``QFont.Weight`` enum member.
    """
    rounded = int(round(float(weight_value) / 100.0) * 100)
    rounded = max(100, min(900, rounded))
    return QtGui.QFont.Weight(rounded)


def font_points_from_style(
    style: bpy.types.ThemeFontStyle | None,
    fallback_points: float,
    ui_scale: float,
) -> float:
    """Read the point size from a Blender font style and apply UI scale.

    Args:
        style: A Blender ``ThemeFontStyle`` or ``None``.
        fallback_points: Point size to use when *style* is unavailable.
        ui_scale: Multiplier applied to the raw point size.

    Returns:
        Scaled point size, always at least 1.0.
    """
    points = float(getattr(style, "points", 0.0) or fallback_points)
    return max(1.0, points * ui_scale)


def font_weight_from_style(
    style: bpy.types.ThemeFontStyle | None,
    fallback_weight: int = 400,
) -> float:
    """Read the character weight from a Blender font style.

    Args:
        style: A Blender ``ThemeFontStyle`` or ``None``.
        fallback_weight: Weight to use when *style* is unavailable.

    Returns:
        Clamped weight in the [100, 900] range.
    """
    raw_weight = int(getattr(style, "character_weight", fallback_weight) or fallback_weight)
    return float(max(100, min(900, raw_weight)))
