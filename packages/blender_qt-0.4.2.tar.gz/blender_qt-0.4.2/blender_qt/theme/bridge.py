"""QML-friendly QObject that exposes Blender theme colours and metrics.

The :class:`BlenderThemeBridge` is a singleton that can be injected as a QML
context property (``blenderTheme``) and also used from Python via its
:pyqt:`themeChanged` signal.
"""

from __future__ import annotations

from PySide6 import QtCore

from .scale import LOGICAL_UI_SCALE


class BlenderThemeBridge(QtCore.QObject):
    """Bridge between the Blender theme and the Qt property system.

    Every colour is exposed as a ``str`` property (hex ``#rrggbb``).
    Every metric is exposed as a ``float`` property.
    All emit :pyqt:`themeChanged` when :meth:`update` is called with new data.
    """

    themeChanged = QtCore.Signal()

    def __init__(
        self,
        colors: dict[str, str] | None = None,
        metrics: dict[str, float] | None = None,
    ) -> None:
        """Initialise the bridge with optional starting values.

        Args:
            colors: Initial named hex colour strings.
            metrics: Initial named float metrics.
        """
        super().__init__()
        self._colors: dict[str, str] = dict(colors or {})
        self._metrics: dict[str, float] = dict(metrics or {})

    def update(self, colors: dict[str, str], metrics: dict[str, float]) -> None:
        """Replace colours and metrics, emitting ``themeChanged`` if anything changed.

        Args:
            colors: Full set of named hex colour strings.
            metrics: Full set of named float metrics.
        """
        if colors == self._colors and metrics == self._metrics:
            return
        self._colors = dict(colors)
        self._metrics = dict(metrics)
        self.themeChanged.emit()

    # MARK: Colour properties

    @QtCore.Property(str, notify=themeChanged)  # type: ignore[arg-type]
    def window(self) -> str:
        """Background colour of panels and windows."""
        return self._colors.get("window", "#2f2f2f")

    @QtCore.Property(str, notify=themeChanged)  # type: ignore[arg-type]
    def windowText(self) -> str:
        """Default text colour on window backgrounds."""
        return self._colors.get("windowText", "#f0f0f0")

    @QtCore.Property(str, notify=themeChanged)  # type: ignore[arg-type]
    def base(self) -> str:
        """Background colour for input fields and list views."""
        return self._colors.get("base", "#252525")

    @QtCore.Property(str, notify=themeChanged)  # type: ignore[arg-type]
    def alternateBase(self) -> str:
        """Alternating row background colour."""
        return self._colors.get("alternateBase", "#323232")

    @QtCore.Property(str, notify=themeChanged)  # type: ignore[arg-type]
    def toolTipBase(self) -> str:
        """Tooltip background colour."""
        return self._colors.get("toolTipBase", "#252525")

    @QtCore.Property(str, notify=themeChanged)  # type: ignore[arg-type]
    def toolTipText(self) -> str:
        """Tooltip text colour."""
        return self._colors.get("toolTipText", "#f0f0f0")

    @QtCore.Property(str, notify=themeChanged)  # type: ignore[arg-type]
    def text(self) -> str:
        """General-purpose text colour."""
        return self._colors.get("text", "#f0f0f0")

    @QtCore.Property(str, notify=themeChanged)  # type: ignore[arg-type]
    def button(self) -> str:
        """Button background colour."""
        return self._colors.get("button", "#3a3a3a")

    @QtCore.Property(str, notify=themeChanged)  # type: ignore[arg-type]
    def buttonText(self) -> str:
        """Button label text colour."""
        return self._colors.get("buttonText", "#f0f0f0")

    @QtCore.Property(str, notify=themeChanged)  # type: ignore[arg-type]
    def highlight(self) -> str:
        """Accent / highlight colour (selection, active items)."""
        return self._colors.get("highlight", "#4f8cff")

    @QtCore.Property(str, notify=themeChanged)  # type: ignore[arg-type]
    def highlightedText(self) -> str:
        """Text colour on highlighted backgrounds."""
        return self._colors.get("highlightedText", "#ffffff")

    @QtCore.Property(str, notify=themeChanged)  # type: ignore[arg-type]
    def border(self) -> str:
        """General border / outline colour."""
        return self._colors.get("border", "#4a4a4a")

    @QtCore.Property(str, notify=themeChanged)  # type: ignore[arg-type]
    def panel(self) -> str:
        """Panel background colour (slightly offset from window)."""
        return self._colors.get("panel", "#383838")

    @QtCore.Property(str, notify=themeChanged)  # type: ignore[arg-type]
    def mutedText(self) -> str:
        """De-emphasised / secondary text colour."""
        return self._colors.get("mutedText", "#a8a8a8")

    # MARK: Metric properties

    @QtCore.Property(float, notify=themeChanged)  # type: ignore[arg-type]
    def uiScale(self) -> float:
        """Logical UI scale factor (same as ``logicalUiScale``)."""
        return float(self._metrics.get("uiScale", 1.0))

    @QtCore.Property(float, notify=themeChanged)  # type: ignore[arg-type]
    def logicalUiScale(self) -> float:
        """Fixed logical scale applied by Blender Qt to all rendering."""
        return float(self._metrics.get("logicalUiScale", self.uiScale))

    @QtCore.Property(float, notify=themeChanged)  # type: ignore[arg-type]
    def popupScale(self) -> float:
        """Blender ``preferences.view.ui_scale`` value."""
        return float(self._metrics.get("popupScale", 1.0))

    @QtCore.Property(float, notify=themeChanged)  # type: ignore[arg-type]
    def widgetPointSize(self) -> float:
        """Scaled point size for regular widget text."""
        return float(self._metrics.get("widgetPointSize", 11.0))

    @QtCore.Property(float, notify=themeChanged)  # type: ignore[arg-type]
    def systemScale(self) -> float:
        """Blender ``preferences.system.ui_scale`` value."""
        return float(self._metrics.get("systemScale", 1.0))

    @QtCore.Property(float, notify=themeChanged)  # type: ignore[arg-type]
    def renderScale(self) -> float:
        """Effective backing-store scale (at least 1.0)."""
        return float(self._metrics.get("renderScale", 1.0))

    @QtCore.Property(float, notify=themeChanged)  # type: ignore[arg-type]
    def globalScale(self) -> float:
        """Combined global scale factor."""
        return float(self._metrics.get("globalScale", LOGICAL_UI_SCALE))

    @QtCore.Property(float, notify=themeChanged)  # type: ignore[arg-type]
    def widgetWeight(self) -> float:
        """CSS-style font weight for regular widget text (100–900)."""
        return float(self._metrics.get("widgetWeight", 400.0))

    @QtCore.Property(float, notify=themeChanged)  # type: ignore[arg-type]
    def panelTitlePointSize(self) -> float:
        """Scaled point size for panel / group-box titles."""
        return float(self._metrics.get("panelTitlePointSize", self.widgetPointSize))

    @QtCore.Property(float, notify=themeChanged)  # type: ignore[arg-type]
    def panelTitleWeight(self) -> float:
        """CSS-style font weight for panel / group-box titles (100–900)."""
        return float(self._metrics.get("panelTitleWeight", 700.0))


# MARK: Singleton management

_THEME_BRIDGE_INSTANCE: BlenderThemeBridge | None = None


def get_theme_bridge() -> BlenderThemeBridge:
    """Return the singleton :class:`BlenderThemeBridge`, creating it on first call.

    The bridge is lazily initialised with the current Blender theme state.

    Returns:
        The global ``BlenderThemeBridge`` instance.
    """
    global _THEME_BRIDGE_INSTANCE

    if _THEME_BRIDGE_INSTANCE is None:
        from .builder import build_theme_state  # noqa: WPS433

        state = build_theme_state()
        _THEME_BRIDGE_INSTANCE = BlenderThemeBridge(state.colors, state.metrics)

    return _THEME_BRIDGE_INSTANCE
