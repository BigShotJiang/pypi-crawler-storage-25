"""Blender Qt theme — Blender-to-Qt theme translation engine."""
