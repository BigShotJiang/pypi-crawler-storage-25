"""Blender theme -> Qt palette / colour / metric translation.

The heavy lifting of reading ``bpy.context.preferences.themes[0]`` and
producing a fully populated :class:`~blender_qt.core.structs.BlenderThemeState`
lives here.
"""

from __future__ import annotations

import logging

import bpy
from PySide6 import QtCore, QtGui

from ..core.structs import BlenderThemeState
from .scale import (
    font_points_from_style,
    font_weight_from_style,
    get_scale_model,
)

LOGGER = logging.getLogger(__name__)


# MARK: Colour helpers


def _normalize_rgb(
    value: tuple[float, ...] | list[float],
    fallback: tuple[float, float, float] = (0.0, 0.0, 0.0),
) -> tuple[float, float, float]:
    """Return a three-float (R, G, B) tuple clamped from *value*.

    Args:
        value: Sequence of at least three floats.
        fallback: Returned when *value* cannot be unpacked.

    Returns:
        ``(r, g, b)`` in the 0.0–1.0 range.
    """
    try:
        return (float(value[0]), float(value[1]), float(value[2]))
    except (IndexError, TypeError, ValueError):
        LOGGER.debug("Could not normalize RGB value %r — using fallback", value)
        return fallback


def _to_qcolor(
    value: tuple[float, ...] | list[float],
    background: QtGui.QColor | None = None,
) -> QtGui.QColor:
    """Convert a Blender RGBA float tuple to a ``QColor``.

    When *background* is given and the source has an alpha < 1 the colour is
    pre-multiplied over *background* so the result is always fully opaque.

    Args:
        value: Blender colour (3 or 4 floats, 0–1 range).
        background: Optional base colour for alpha compositing.

    Returns:
        Fully opaque ``QColor``.
    """
    red, green, blue = _normalize_rgb(value)
    try:
        alpha = float(value[3])
    except (IndexError, TypeError, ValueError):
        alpha = 1.0

    if background is not None and alpha < 1.0:
        alpha = max(0.0, min(1.0, alpha))
        inverse_alpha = 1.0 - alpha
        red = (red * alpha) + (background.redF() * inverse_alpha)
        green = (green * alpha) + (background.greenF() * inverse_alpha)
        blue = (blue * alpha) + (background.blueF() * inverse_alpha)

    return QtGui.QColor(int(red * 255), int(green * 255), int(blue * 255))


def _mix_colors(
    color_a: QtGui.QColor,
    color_b: QtGui.QColor,
    factor: float,
) -> QtGui.QColor:
    """Linearly interpolate between two colours.

    Args:
        color_a: Starting colour (factor = 0).
        color_b: Ending colour (factor = 1).
        factor: Blend ratio clamped to [0, 1].

    Returns:
        Blended ``QColor``.
    """
    factor = max(0.0, min(1.0, factor))
    inverse_factor = 1.0 - factor
    return QtGui.QColor(
        int((color_a.red() * inverse_factor) + (color_b.red() * factor)),
        int((color_a.green() * inverse_factor) + (color_b.green() * factor)),
        int((color_a.blue() * inverse_factor) + (color_b.blue() * factor)),
    )


def _hex_string(color: QtGui.QColor) -> str:
    """Return the ``#rrggbb`` hex representation of *color*.

    Args:
        color: Source ``QColor``.

    Returns:
        Seven-character hex string.
    """
    return color.name(QtGui.QColor.HexRgb)


def _luminance(color: QtGui.QColor) -> float:
    """Compute the relative luminance of *color* (ITU BT.709).

    Args:
        color: Source ``QColor``.

    Returns:
        Luminance in the 0.0–1.0 range.
    """
    return (0.2126 * color.redF()) + (0.7152 * color.greenF()) + (0.0722 * color.blueF())


def _contrast_text_color(color: QtGui.QColor) -> QtGui.QColor:
    """Return a high-contrast text colour (dark or light) for the given background.

    Args:
        color: Background colour to test.

    Returns:
        Near-black or near-white ``QColor``.
    """
    return QtGui.QColor("#111111") if _luminance(color) > 0.6 else QtGui.QColor("#f7f7f7")


def _theme_widget_color(
    *widget_definitions: bpy.types.ThemeWidgetColors | None,
    attribute: str,
    fallback: tuple[float, ...],
    background: QtGui.QColor | None = None,
) -> QtGui.QColor:
    """Walk a priority list of widget colour structs and return the first match.

    Args:
        widget_definitions: Blender ``ThemeWidgetColors`` objects in priority order.
        attribute: Colour attribute name (e.g. ``"inner"``, ``"text"``).
        fallback: RGBA tuple used when no widget provides the attribute.
        background: Passed to :func:`_to_qcolor` for alpha compositing.

    Returns:
        Resolved ``QColor``.
    """
    for widget_definition in widget_definitions:
        if widget_definition is None:
            continue
        if hasattr(widget_definition, attribute):
            return _to_qcolor(getattr(widget_definition, attribute), background=background)
    return _to_qcolor(fallback, background=background)


# MARK: Public builder


def build_theme_state() -> BlenderThemeState:
    """Read the active Blender theme and produce a complete :class:`BlenderThemeState`.

    Returns:
        Immutable snapshot containing a ``QPalette``, named colours,
        named metrics, and a change-detection signature.
    """
    preferences = bpy.context.preferences
    theme_ui = preferences.themes[0].user_interface
    ui_style = preferences.ui_styles[0]
    scale_model = get_scale_model()

    widget_style = getattr(ui_style, "widget", None)
    panel_title_style = getattr(ui_style, "panel_title", widget_style)

    # Resolve widget colour structs with fallback chains.
    regular_widget = getattr(theme_ui, "wcol_regular", None)
    text_widget = getattr(theme_ui, "wcol_text", regular_widget)
    input_widget = getattr(theme_ui, "wcol_num", text_widget)
    slider_widget = getattr(theme_ui, "wcol_numslider", input_widget)
    list_widget = getattr(theme_ui, "wcol_list_item", text_widget)
    menu_widget = getattr(theme_ui, "wcol_menu", regular_widget)
    menu_back_widget = getattr(theme_ui, "wcol_menu_back", menu_widget)
    tooltip_widget = getattr(theme_ui, "wcol_tooltip", regular_widget)
    radio_widget = getattr(theme_ui, "wcol_radio", regular_widget)
    box_widget = getattr(theme_ui, "wcol_box", regular_widget)

    panel_back = _to_qcolor(getattr(theme_ui, "panel_back", getattr(box_widget, "inner", (0.18, 0.18, 0.18))))

    # MARK: Active colour group

    window_color = panel_back
    window_text_color = _theme_widget_color(
        regular_widget,
        text_widget,
        attribute="text",
        fallback=(0.94, 0.94, 0.94),
    )
    base_color = _theme_widget_color(
        text_widget,
        input_widget,
        regular_widget,
        menu_widget,
        attribute="inner",
        fallback=(0.14, 0.14, 0.14),
        background=panel_back,
    )
    alternate_base_color = _theme_widget_color(
        list_widget,
        text_widget,
        input_widget,
        regular_widget,
        attribute="inner",
        fallback=(0.18, 0.18, 0.18),
        background=panel_back,
    )
    tooltip_base_color = _theme_widget_color(
        tooltip_widget,
        text_widget,
        input_widget,
        attribute="inner",
        fallback=(0.14, 0.14, 0.14),
        background=panel_back,
    )
    tooltip_text_color = _theme_widget_color(
        tooltip_widget,
        regular_widget,
        attribute="text",
        fallback=(0.94, 0.94, 0.94),
    )
    text_color = _theme_widget_color(
        text_widget,
        input_widget,
        regular_widget,
        attribute="text",
        fallback=(0.94, 0.94, 0.94),
    )
    button_color = _theme_widget_color(
        regular_widget,
        menu_back_widget,
        text_widget,
        attribute="inner",
        fallback=(0.22, 0.22, 0.22),
        background=panel_back,
    )
    button_text_color = _theme_widget_color(
        regular_widget,
        menu_back_widget,
        text_widget,
        attribute="text",
        fallback=(0.94, 0.94, 0.94),
    )
    highlight_color = _theme_widget_color(
        slider_widget,
        text_widget,
        input_widget,
        regular_widget,
        radio_widget,
        attribute="item",
        fallback=getattr(radio_widget, "outline", (0.31, 0.55, 1.0)),
        background=panel_back,
    )
    highlighted_text_color = _theme_widget_color(
        input_widget,
        text_widget,
        regular_widget,
        attribute="text_sel",
        fallback=(1.0, 1.0, 1.0),
    )
    if highlighted_text_color == QtGui.QColor(0, 0, 0) and _luminance(highlight_color) < 0.15:
        highlighted_text_color = _contrast_text_color(highlight_color)

    border_color = _theme_widget_color(
        box_widget,
        menu_back_widget,
        regular_widget,
        attribute="outline",
        fallback=(0.3, 0.3, 0.3),
        background=panel_back,
    )

    panel_color = _mix_colors(panel_back, base_color, 0.12)
    muted_text_color = _mix_colors(text_color, window_color, 0.42)
    light_color = _mix_colors(button_color, QtGui.QColor("#ffffff"), 0.18)
    midlight_color = _mix_colors(button_color, light_color, 0.45)
    mid_color = _mix_colors(button_color, border_color, 0.45)
    dark_color = _mix_colors(button_color, window_color, 0.4)
    shadow_color = _mix_colors(dark_color, QtGui.QColor("#000000"), 0.5)

    # MARK: Build palette

    palette = QtGui.QPalette()
    palette.setColor(QtGui.QPalette.Window, window_color)
    palette.setColor(QtGui.QPalette.WindowText, window_text_color)
    palette.setColor(QtGui.QPalette.Base, base_color)
    palette.setColor(QtGui.QPalette.Text, text_color)
    palette.setColor(QtGui.QPalette.AlternateBase, alternate_base_color)
    palette.setColor(QtGui.QPalette.Button, button_color)
    palette.setColor(QtGui.QPalette.ButtonText, button_text_color)
    palette.setColor(QtGui.QPalette.Light, light_color)
    palette.setColor(QtGui.QPalette.Midlight, midlight_color)
    palette.setColor(QtGui.QPalette.Mid, mid_color)
    palette.setColor(QtGui.QPalette.Dark, dark_color)
    palette.setColor(QtGui.QPalette.Shadow, shadow_color)
    palette.setColor(QtGui.QPalette.ToolTipBase, tooltip_base_color)
    palette.setColor(QtGui.QPalette.ToolTipText, tooltip_text_color)
    palette.setColor(QtGui.QPalette.BrightText, QtGui.QColor(QtCore.Qt.red))
    palette.setColor(QtGui.QPalette.Link, highlight_color)
    palette.setColor(QtGui.QPalette.LinkVisited, _mix_colors(highlight_color, button_color, 0.35))
    palette.setColor(QtGui.QPalette.Highlight, highlight_color)
    palette.setColor(QtGui.QPalette.HighlightedText, highlighted_text_color)
    palette.setColor(QtGui.QPalette.PlaceholderText, muted_text_color)

    # MARK: Disabled colour group

    disabled_text_color = _mix_colors(text_color, window_color, 0.6)
    disabled_base_color = _mix_colors(base_color, window_color, 0.3)
    disabled_button_color = _mix_colors(button_color, window_color, 0.35)
    disabled_button_text_color = _mix_colors(button_text_color, button_color, 0.55)

    palette.setColor(QtGui.QPalette.Disabled, QtGui.QPalette.Base, disabled_base_color)
    palette.setColor(
        QtGui.QPalette.Disabled,
        QtGui.QPalette.AlternateBase,
        _mix_colors(alternate_base_color, window_color, 0.3),
    )
    palette.setColor(QtGui.QPalette.Disabled, QtGui.QPalette.Button, disabled_button_color)
    palette.setColor(QtGui.QPalette.Disabled, QtGui.QPalette.Text, disabled_text_color)
    palette.setColor(QtGui.QPalette.Disabled, QtGui.QPalette.WindowText, disabled_text_color)
    palette.setColor(QtGui.QPalette.Disabled, QtGui.QPalette.ButtonText, disabled_button_text_color)
    palette.setColor(
        QtGui.QPalette.Disabled,
        QtGui.QPalette.Highlight,
        _mix_colors(highlight_color, window_color, 0.45),
    )
    palette.setColor(
        QtGui.QPalette.Disabled,
        QtGui.QPalette.HighlightedText,
        _mix_colors(highlighted_text_color, window_color, 0.4),
    )

    # MARK: Named colour dict

    colors = {
        "window": _hex_string(window_color),
        "windowText": _hex_string(window_text_color),
        "base": _hex_string(base_color),
        "alternateBase": _hex_string(alternate_base_color),
        "toolTipBase": _hex_string(tooltip_base_color),
        "toolTipText": _hex_string(tooltip_text_color),
        "text": _hex_string(text_color),
        "button": _hex_string(button_color),
        "buttonText": _hex_string(button_text_color),
        "highlight": _hex_string(highlight_color),
        "highlightedText": _hex_string(highlighted_text_color),
        "border": _hex_string(border_color),
        "panel": _hex_string(panel_color),
        "mutedText": _hex_string(muted_text_color),
    }

    # MARK: Metrics dict

    widget_point_size = font_points_from_style(widget_style, 11.0, scale_model.logical_ui_scale)
    widget_weight = font_weight_from_style(widget_style)
    panel_title_point_size = font_points_from_style(panel_title_style, 12.0, scale_model.logical_ui_scale)
    panel_title_weight = font_weight_from_style(panel_title_style, 700)

    metrics: dict[str, float] = {
        "uiScale": float(scale_model.logical_ui_scale),
        "logicalUiScale": float(scale_model.logical_ui_scale),
        "popupScale": float(scale_model.popup_scale),
        "systemScale": float(scale_model.system_scale),
        "renderScale": float(scale_model.render_scale),
        "globalScale": float(scale_model.logical_ui_scale),
        "widgetPointSize": widget_point_size,
        "widgetWeight": widget_weight,
        "panelTitlePointSize": panel_title_point_size,
        "panelTitleWeight": panel_title_weight,
    }

    # MARK: Signature for change detection

    sampled_colors = (
        window_color,
        window_text_color,
        base_color,
        alternate_base_color,
        tooltip_base_color,
        tooltip_text_color,
        text_color,
        button_color,
        button_text_color,
        highlight_color,
        border_color,
        panel_color,
        muted_text_color,
    )
    color_signature = tuple(
        int(colour.red()) << 16 | int(colour.green()) << 8 | int(colour.blue()) for colour in sampled_colors
    )
    metric_signature = (
        int(round(metrics["uiScale"] * 1000)),
        int(round(metrics["logicalUiScale"] * 1000)),
        int(round(metrics["popupScale"] * 1000)),
        int(round(metrics["systemScale"] * 1000)),
        int(round(metrics["renderScale"] * 1000)),
        int(round(metrics["globalScale"] * 1000)),
        int(round(metrics["widgetPointSize"] * 100)),
        int(metrics["widgetWeight"]),
        int(round(metrics["panelTitlePointSize"] * 100)),
        int(metrics["panelTitleWeight"]),
    )

    return BlenderThemeState(
        signature=color_signature + metric_signature,
        palette=palette,
        colors=colors,
        metrics=metrics,
    )
