"""Offscreen widget renderer."""

from __future__ import annotations

import logging
import time
from typing import Optional

from mathutils import Vector
from PySide6 import QtCore, QtGui, QtWidgets

from ...core.app import (
    flush_posted_events,
    is_focus_owner,
    release_focus_owner,
    set_focus_owner,
)
from ...core.constants import KeyboardModifier, MouseButton
from ...core.interfaces import WidgetGeometryProvider
from ...core.qt_input import to_qt_button, to_qt_modifiers, to_qt_point
from ...theme.sync import apply_theme_to_widget

LOGGER = logging.getLogger(__name__)
_VISIBILITY_TIMEOUT_SECONDS = 0.25


VIRTUAL_HOST_ORIGIN = QtCore.QPoint(96, 96)


class OffscreenWidgetsRenderer(QtCore.QObject):
    updated = QtCore.Signal()
    UPDATE_EVENTS: set[int] = {
        QtCore.QEvent.UpdateRequest,
        QtCore.QEvent.LayoutRequest,
        QtCore.QEvent.FocusIn,
        QtCore.QEvent.FocusOut,
        QtCore.QEvent.Move,
        QtCore.QEvent.Resize,
        QtCore.QEvent.Show,
        QtCore.QEvent.Hide,
        QtCore.QEvent.Paint,
        QtCore.QEvent.WindowActivate,
        QtCore.QEvent.WindowDeactivate,
    }

    def __init__(
        self, host_window: "HostWindow", render_scale: float = 1.0, parent: Optional[QtCore.QObject] = None
    ) -> None:
        super().__init__(parent)
        self.host_window = host_window
        self.render_scale = max(1.0, float(render_scale))
        self.window_size = QtCore.QSize(host_window.width(), host_window.height())
        self.viewport_size = QtCore.QSize(self.window_size)
        screen = QtGui.QGuiApplication.primaryScreen()
        available = screen.availableGeometry() if screen is not None else QtCore.QRect(0, 0, 1920, 1080)
        self.max_window_size = QtCore.QSize(max(1, available.width()), max(1, available.height()))
        self.mutex = QtCore.QMutex()
        self.last_image = QtGui.QImage()
        self.active_mouse_buttons = QtCore.Qt.NoButton
        self.mouse_grabber: Optional[QtWidgets.QWidget] = None
        self.focus_widget: Optional[QtWidgets.QWidget] = None
        self._dirty = True
        self._needs_sync = True
        self._last_visible_at = 0.0
        self._anchor_cursor = QtCore.QPoint(self.host_window.x(), self.host_window.y())
        self._anchor_qt_point = QtCore.QPoint(0, 0)
        application = QtWidgets.QApplication.instance()
        if application is not None:
            application.installEventFilter(self)
        self._request_update()

    def apply_theme(self) -> None:
        apply_theme_to_widget(self.host_window)
        self.host_window.ensurePolished()
        self.host_window.surface.ensurePolished()
        self._needs_sync = True
        self._request_update()

    def _request_update(self) -> None:
        self._dirty = True

    def mark_visible(self) -> None:
        self._last_visible_at = time.monotonic()

    def is_visible(self) -> bool:
        return (time.monotonic() - self._last_visible_at) <= _VISIBILITY_TIMEOUT_SECONDS

    def is_dirty(self) -> bool:
        return self._dirty or self.last_image.isNull()

    def _is_owned_widget(self, watched: QtCore.QObject) -> bool:
        if not isinstance(watched, QtWidgets.QWidget):
            return False
        widget: Optional[QtWidgets.QWidget] = watched
        while widget is not None:
            if widget is self.host_window:
                return True
            parent_widget = widget.parentWidget()
            if parent_widget is not None:
                widget = parent_widget
                continue
            parent_object = widget.parent()
            widget = parent_object if isinstance(parent_object, QtWidgets.QWidget) else None
        return False

    def eventFilter(self, watched: QtCore.QObject, event: QtCore.QEvent) -> bool:
        if event.type() in self.UPDATE_EVENTS and self._is_owned_widget(watched):
            self._request_update()
        return super().eventFilter(watched, event)

    def update_host_origin(self, position: QtCore.QPoint) -> None:
        cursor_position = QtGui.QCursor.pos()
        origin = cursor_position - position
        if self.host_window.pos() != origin:
            self.host_window.move(origin)

    def sync_pointer_anchor(self, position: QtCore.QPoint) -> None:
        self._anchor_cursor = QtGui.QCursor.pos()
        self._anchor_qt_point = QtCore.QPoint(position)

    def logical_scale(self) -> tuple[float, float]:
        return (
            self.viewport_size.width() / max(1, self.window_size.width()),
            self.viewport_size.height() / max(1, self.window_size.height()),
        )

    def viewport_top_left(self) -> QtCore.QPointF:
        scale_x, scale_y = self.logical_scale()
        return QtCore.QPointF(
            self._anchor_cursor.x() - (self._anchor_qt_point.x() * scale_x),
            self._anchor_cursor.y() - (self._anchor_qt_point.y() * scale_y),
        )

    def popup_geometry_for_widget(self, widget: QtWidgets.QWidget) -> tuple[int, int, int, int]:
        root_widget = self.host_window.surface
        widget_top_left = widget.mapTo(root_widget, QtCore.QPoint(0, 0))
        widget_bottom_left = widget.mapTo(root_widget, QtCore.QPoint(0, widget.height()))
        scale_x, scale_y = self.logical_scale()
        viewport_origin = self.viewport_top_left()
        popup_x = int(round(viewport_origin.x() + widget_top_left.x() * scale_x))
        popup_y = int(round(viewport_origin.y() + widget_bottom_left.y() * scale_y))
        popup_width = max(1, int(round(widget.width() * scale_x)))
        return popup_x, popup_y, popup_width, -1

    def widget_rect_for_widget(self, widget: QtWidgets.QWidget) -> tuple[int, int, int, int]:
        root_widget = self.host_window.surface
        widget_top_left = widget.mapTo(root_widget, QtCore.QPoint(0, 0))
        scale_x, scale_y = self.logical_scale()
        viewport_origin = self.viewport_top_left()
        rect_x = int(round(viewport_origin.x() + widget_top_left.x() * scale_x))
        rect_y = int(round(viewport_origin.y() + widget_top_left.y() * scale_y))
        rect_width = max(1, int(round(widget.width() * scale_x)))
        rect_height = max(1, int(round(widget.height() * scale_y)))
        return rect_x, rect_y, rect_width, rect_height

    def set_size(self, width: int, height: int) -> None:
        width = max(1, width)
        height = max(1, height)
        self.viewport_size = QtCore.QSize(width, height)
        width = min(width, self.max_window_size.width())
        height = min(height, self.max_window_size.height())
        if self.window_size.width() == width and self.window_size.height() == height:
            return
        self.window_size = QtCore.QSize(width, height)
        self.host_window.resize(width, height)
        self.host_window.surface.resize(width, height)
        self._needs_sync = True
        self._request_update()

    def service(self) -> None:
        if not self._dirty and not self.last_image.isNull():
            return
        flush_posted_events()
        self._do_render()

    def _do_render(self) -> None:
        if not self._dirty and not self.last_image.isNull():
            return
        with QtCore.QMutexLocker(self.mutex):
            width = max(1, self.window_size.width())
            height = max(1, self.window_size.height())
            if self.host_window.width() != width or self.host_window.height() != height:
                self.host_window.resize(width, height)
                self.host_window.surface.resize(width, height)
                self._needs_sync = True
            if self._needs_sync:
                self.host_window.ensurePolished()
                self.host_window.surface.ensurePolished()
                layout = self.host_window.layout()
                if layout is not None:
                    layout.activate()
                self.host_window.updateGeometry()
                self.host_window.surface.updateGeometry()
                flush_posted_events()
                self._needs_sync = False
            image = QtGui.QImage(width, height, QtGui.QImage.Format_RGBA8888)
            image.fill(QtCore.Qt.transparent)
            painter = QtGui.QPainter(image)
            try:
                self.host_window.render(painter, QtCore.QPoint(0, 0), QtGui.QRegion(), QtWidgets.QWidget.DrawChildren)
            finally:
                painter.end()
            self.last_image = image
            self._dirty = False
        self.updated.emit()

    def render(self) -> QtGui.QImage:
        self.mark_visible()
        if self.last_image.isNull() or self._dirty:
            with QtCore.QMutexLocker(self.mutex):
                if self.last_image.isNull():
                    self.last_image = QtGui.QImage(self.window_size, QtGui.QImage.Format_RGBA8888)
                    self.last_image.fill(QtCore.Qt.transparent)
            self._do_render()
        with QtCore.QMutexLocker(self.mutex):
            return self.last_image.copy()

    def _map_canvas_to_global(self, position: QtCore.QPoint) -> QtCore.QPoint:
        return self.host_window.mapToGlobal(position)

    def _deepest_child_at(self, widget: QtWidgets.QWidget, global_position: QtCore.QPoint) -> QtWidgets.QWidget:
        target = widget
        while True:
            child = target.childAt(target.mapFromGlobal(global_position))
            if child is None or child is target:
                return target
            target = child

    def _pick_target(self, position: QtCore.QPoint) -> QtWidgets.QWidget:
        return self._deepest_child_at(self.host_window.surface, self._map_canvas_to_global(position))

    def _send_mouse_event(
        self,
        event_type: QtCore.QEvent.Type,
        surface_position: Vector,
        button: MouseButton,
        buttons: QtCore.Qt.MouseButtons,
        modifiers: KeyboardModifier,
    ) -> None:
        qt_position = to_qt_point(surface_position)
        target = self.mouse_grabber or self._pick_target(qt_position)
        global_position = self._map_canvas_to_global(qt_position)
        local_position = target.mapFrom(self.host_window.surface, qt_position)
        event = QtGui.QMouseEvent(
            event_type,
            QtCore.QPointF(local_position),
            QtCore.QPointF(global_position),
            to_qt_button(button),
            buttons,
            to_qt_modifiers(modifiers),
        )
        QtWidgets.QApplication.sendEvent(target, event)

    def send_mouse_move(self, surface_position: Vector, modifiers: KeyboardModifier = KeyboardModifier.NONE) -> None:
        qt_position = to_qt_point(surface_position)
        self.sync_pointer_anchor(qt_position)
        self._send_mouse_event(
            QtCore.QEvent.Type.MouseMove,
            surface_position,
            MouseButton.NONE,
            self.active_mouse_buttons,
            modifiers,
        )
        self._request_update()

    def send_mouse_press(
        self,
        surface_position: Vector,
        button: MouseButton,
        modifiers: KeyboardModifier = KeyboardModifier.NONE,
    ) -> None:
        qt_position = to_qt_point(surface_position)
        qt_button = to_qt_button(button)
        self.update_host_origin(qt_position)
        self.sync_pointer_anchor(qt_position)
        self.active_mouse_buttons |= qt_button
        self.mouse_grabber = self._pick_target(qt_position)
        focus_target = self.mouse_grabber.focusProxy() or self.mouse_grabber
        set_focus_owner(self)
        if focus_target.focusPolicy() != QtCore.Qt.NoFocus:
            focus_target.setFocus(QtCore.Qt.MouseFocusReason)
            self.focus_widget = focus_target
        else:
            self.host_window.surface.setFocus(QtCore.Qt.MouseFocusReason)
            self.focus_widget = self.host_window.surface
        self._send_mouse_event(
            QtCore.QEvent.Type.MouseButtonPress,
            surface_position,
            button,
            self.active_mouse_buttons,
            modifiers,
        )
        self._request_update()

    def send_mouse_release(
        self,
        surface_position: Vector,
        button: MouseButton,
        modifiers: KeyboardModifier = KeyboardModifier.NONE,
    ) -> None:
        qt_position = to_qt_point(surface_position)
        qt_button = to_qt_button(button)
        self.sync_pointer_anchor(qt_position)
        buttons_after = self.active_mouse_buttons & ~qt_button
        self._send_mouse_event(
            QtCore.QEvent.Type.MouseButtonRelease,
            surface_position,
            button,
            buttons_after,
            modifiers,
        )
        active_grabber = QtWidgets.QWidget.mouseGrabber()
        if active_grabber is not None:
            active_grabber.releaseMouse()
        self.active_mouse_buttons = buttons_after
        self.mouse_grabber = None
        self._request_update()

    def has_keyboard_focus(self) -> bool:
        if not is_focus_owner(self):
            return False
        focus = self.focus_widget
        if focus is None or focus is self.host_window.surface:
            return False
        return isinstance(
            focus, (QtWidgets.QLineEdit, QtWidgets.QTextEdit, QtWidgets.QPlainTextEdit, QtWidgets.QAbstractSpinBox)
        )

    def clear_focus(self) -> None:
        focus = self.focus_widget
        if focus is not None and focus is not self.host_window.surface and self._is_owned_widget(focus):
            focus.clearFocus()
        self.host_window.surface.setFocus(QtCore.Qt.OtherFocusReason)
        self.focus_widget = self.host_window.surface
        release_focus_owner(self)
        self._request_update()

    def send_key(
        self,
        event_type: str,
        event_value: str,
        unicode_text: str,
        modifiers: KeyboardModifier = KeyboardModifier.NONE,
    ) -> bool:
        from ...core.constants import KEY_MAP

        qt_key = KEY_MAP.get(event_type)
        if qt_key is None:
            return False
        popup = QtWidgets.QApplication.activePopupWidget()
        modal = QtWidgets.QApplication.activeModalWidget()
        if popup is not None and self._is_owned_widget(popup):
            target = popup
        elif modal is not None and self._is_owned_widget(modal):
            target = modal
        else:
            target = self.focus_widget or self.host_window.surface
        qt_event_type = QtCore.QEvent.KeyPress if event_value == "PRESS" else QtCore.QEvent.KeyRelease
        key_event = QtGui.QKeyEvent(qt_event_type, qt_key, to_qt_modifiers(modifiers), unicode_text)
        QtWidgets.QApplication.sendEvent(target, key_event)
        self._request_update()
        return True

    def cleanup(self) -> None:
        release_focus_owner(self)
        application = QtWidgets.QApplication.instance()
        if application is not None:
            application.removeEventFilter(self)
        self.host_window.close()
        self.host_window.deleteLater()


class HostWindow(QtWidgets.QWidget):
    def __init__(self) -> None:
        super().__init__(None, QtCore.Qt.Window | QtCore.Qt.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WA_DontShowOnScreen, True)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground, True)
        self.setWindowTitle("Blender Qt Host Window")
        self.setAutoFillBackground(False)
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        self.surface = QtWidgets.QWidget(self)
        self.surface.setObjectName("hostSurface")
        self.surface.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.surface.setMouseTracking(True)
        self.surface.setAutoFillBackground(True)
        layout.addWidget(self.surface)
        self.popup_geometry_provider: WidgetGeometryProvider | None = None
        self.widget_rect_provider: WidgetGeometryProvider | None = None
