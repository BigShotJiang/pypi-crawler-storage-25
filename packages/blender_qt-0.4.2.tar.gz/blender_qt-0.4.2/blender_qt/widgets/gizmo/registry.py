"""Widget-specific viewport gizmo registration."""

from __future__ import annotations

from ...core.gizmo.registry import LOGGER, is_gizmo_registered, register_runtime
from .runtime import WidgetViewportPanelRuntime

from ...core.interfaces import WidgetFactory


def register_viewport_gizmo(
    gizmo_id: str,
    widget_factory: WidgetFactory,
    *,
    space_type: str = "VIEW_3D",
    label: str = "Qt Panel",
    width: int = 260,
    height: int = 220,
    is_2d: bool = True,
    billboard: bool = True,
    panel_normal: tuple[float, float, float] = (0.0, -1.0, 0.0),
    panel_up: tuple[float, float, float] = (0.0, 0.0, 1.0),
    panel_world_width: float = 2.0,
    initial_position: tuple[int, int] = (100, 100),
    initial_3d_position: tuple[float, float, float] | None = None,
    use_depth_test: bool = False,
    cull_backfaces: bool = False,
) -> None:
    if is_gizmo_registered(gizmo_id):
        raise ValueError(f"Gizmo {gizmo_id!r} is already registered.")
    runtime = WidgetViewportPanelRuntime(
        gizmo_id,
        widget_factory,
        width=width,
        height=height,
        is_2d=is_2d,
        billboard=billboard,
        panel_normal=panel_normal,
        panel_up=panel_up,
        panel_world_width=panel_world_width,
        initial_position=initial_position,
        initial_3d_position=initial_3d_position,
        use_depth_test=use_depth_test,
        cull_backfaces=cull_backfaces,
        space_type=space_type,
        window_title=label,
    )
    register_runtime(
        gizmo_id=gizmo_id,
        runtime=runtime,
        space_type=space_type,
        is_2d=is_2d,
        draw_stage="POST_PIXEL" if is_2d else "POST_VIEW",
    )
