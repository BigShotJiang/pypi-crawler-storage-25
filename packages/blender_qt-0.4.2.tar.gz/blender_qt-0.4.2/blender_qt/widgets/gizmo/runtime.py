"""Widget viewport gizmo runtimes."""

from __future__ import annotations

import inspect

from PySide6 import QtWidgets

from ..._internal.viewport_gizmo import _ViewportPanelRuntimeBase, clear_runtimes, get_runtime
from ...core.interfaces import WidgetFactory
from ...theme.sync import apply_theme_to_widget
from ..render.renderer import HostWindow, OffscreenWidgetsRenderer, VIRTUAL_HOST_ORIGIN


def _instantiate_widget(factory: WidgetFactory, parent: QtWidgets.QWidget) -> QtWidgets.QWidget:
    if inspect.isclass(factory) and issubclass(factory, QtWidgets.QWidget):
        return factory(parent)

    signature = inspect.signature(factory)
    positional_count = sum(
        1
        for parameter in signature.parameters.values()
        if parameter.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)
    )
    widget = factory() if positional_count == 0 else factory(parent)
    if widget.parent() is not parent:
        widget.setParent(parent)
    return widget


class WidgetViewportPanelRuntime(_ViewportPanelRuntimeBase):
    def __init__(
        self,
        gizmo_id: str,
        surface_factory: WidgetFactory,
        *,
        window_title: str = "Blender Qt Widget Gizmo",
        **kwargs: object,
    ) -> None:
        super().__init__(gizmo_id, **kwargs)
        host_window = HostWindow()
        host_window.setWindowTitle(window_title)
        host_window.move(VIRTUAL_HOST_ORIGIN)
        host_window.resize(self.panel_width, self.panel_height)
        surface = host_window.surface
        widget = _instantiate_widget(surface_factory, surface)
        layout = QtWidgets.QVBoxLayout(surface)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(widget)
        host_window.show()
        apply_theme_to_widget(host_window)
        renderer = OffscreenWidgetsRenderer(host_window, 1.0)
        host_window.popup_geometry_provider = renderer.popup_geometry_for_widget
        host_window.widget_rect_provider = renderer.widget_rect_for_widget
        self._attach_renderer(renderer)


__all__ = ["WidgetViewportPanelRuntime", "clear_runtimes", "get_runtime"]
