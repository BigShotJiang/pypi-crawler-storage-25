"""Shared node-space input classes, keymaps, and key forwarding."""

from __future__ import annotations

import logging
from typing import Any

import bpy
from bpy.props import StringProperty

from ..interfaces import ContextPoll, GetSpaceRuntime
from ..constants import KEY_TYPES
from .gizmos import InputCaptureGizmoBase, InputCaptureGizmoGroupBase

LOGGER = logging.getLogger(__name__)

_ADDON_KEYMAPS: dict[str, list[tuple[Any, Any]]] = {}
_SPACE_INPUT_REGISTRY: dict[str, tuple[ContextPoll, GetSpaceRuntime]] = {}
_GLOBAL_OPERATOR_REGISTERED = False


def _space_tree_type(context: bpy.types.Context) -> str:
    space = getattr(context, "space_data", None)
    if space is None or space.type != "NODE_EDITOR":
        return ""
    return getattr(space, "tree_type", "")


def _resolve_runtime(get_runtime_function: GetSpaceRuntime, context: bpy.types.Context, *, create: bool):
    try:
        return get_runtime_function(context, create=create)
    except TypeError:
        return get_runtime_function(context)


def _active_registration(context: bpy.types.Context) -> tuple[str, ContextPoll, GetSpaceRuntime] | None:
    tree_type = _space_tree_type(context)
    registration = _SPACE_INPUT_REGISTRY.get(tree_type)
    if registration is None:
        return None
    poll_function, get_runtime_function = registration
    if not poll_function(context):
        return None
    return tree_type, poll_function, get_runtime_function


class BQT_OT_space_forward_key(bpy.types.Operator):
    """Single shared forward-key operator reused by all custom node spaces."""

    bl_idname = "blender_qt_space.forward_key"
    bl_label = "Blender Qt Space Forward Key"
    bl_options = {"INTERNAL"}
    _is_running: bool = False
    _area_pointer: int | None = None
    _tree_type: str = ""

    event_type: StringProperty(options={"SKIP_SAVE"})  # type: ignore[valid-type]

    @classmethod
    def _stop_modal(cls) -> None:
        cls._is_running = False
        cls._area_pointer = None
        cls._tree_type = ""

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        registration = _active_registration(context)
        if registration is None:
            return False
        _, _, get_runtime_function = registration
        return _resolve_runtime(get_runtime_function, context, create=False) is not None

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event) -> set[str]:
        if type(self)._is_running:
            return {"CANCELLED"}
        registration = _active_registration(context)
        if registration is None:
            return {"PASS_THROUGH"}
        tree_type, _, get_runtime_function = registration
        runtime = _resolve_runtime(get_runtime_function, context, create=False)
        if runtime is None:
            LOGGER.debug("No active runtime found for node space %s", tree_type)
            return {"PASS_THROUGH"}
        if not runtime.has_keyboard_focus():
            return {"PASS_THROUGH"}
        if not runtime.handle_key_event(context, event):
            return {"PASS_THROUGH"}
        if context.area is not None:
            context.area.tag_redraw()
        if event.value != "PRESS":
            return {"FINISHED"}
        type(self)._is_running = True
        type(self)._tree_type = tree_type
        area = getattr(context, "area", None)
        type(self)._area_pointer = area.as_pointer() if area is not None else None
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context: bpy.types.Context, event: bpy.types.Event) -> set[str]:
        operator_class = type(self)
        registration = _active_registration(context)
        if registration is None:
            operator_class._stop_modal()
            return {"PASS_THROUGH", "FINISHED"}

        tree_type, _, get_runtime_function = registration
        area = getattr(context, "area", None)
        area_pointer = area.as_pointer() if area is not None else None
        if tree_type != operator_class._tree_type or area_pointer != operator_class._area_pointer:
            operator_class._stop_modal()
            return {"PASS_THROUGH", "FINISHED"}

        runtime = _resolve_runtime(get_runtime_function, context, create=False)
        if runtime is None or not runtime.has_keyboard_focus() or event.type == "WINDOW_DEACTIVATE":
            operator_class._stop_modal()
            if area is not None:
                area.tag_redraw()
            return {"PASS_THROUGH", "FINISHED"}

        if event.type in KEY_TYPES:
            handled = runtime.handle_key_event(context, event)
            if area is not None:
                area.tag_redraw()
            return {"RUNNING_MODAL"} if handled else {"PASS_THROUGH"}
        return {"PASS_THROUGH"}


def ensure_global_operator() -> None:
    global _GLOBAL_OPERATOR_REGISTERED
    if _GLOBAL_OPERATOR_REGISTERED:
        return
    bpy.utils.register_class(BQT_OT_space_forward_key)
    _GLOBAL_OPERATOR_REGISTERED = True


def register_space_input(tree_type: str, poll_function: ContextPoll, get_runtime_function: GetSpaceRuntime) -> None:
    ensure_global_operator()
    _SPACE_INPUT_REGISTRY[tree_type] = (poll_function, get_runtime_function)


def unregister_space_input(tree_type: str) -> None:
    global _GLOBAL_OPERATOR_REGISTERED
    _SPACE_INPUT_REGISTRY.pop(tree_type, None)
    if _SPACE_INPUT_REGISTRY or not _GLOBAL_OPERATOR_REGISTERED:
        return
    try:
        bpy.utils.unregister_class(BQT_OT_space_forward_key)
    except RuntimeError:
        LOGGER.debug("Failed to unregister shared space forward-key operator", exc_info=True)
    _GLOBAL_OPERATOR_REGISTERED = False


def create_input_gizmo_classes(
    tree_type: str,
    poll_function: ContextPoll,
    get_runtime_function: GetSpaceRuntime,
    *,
    include_inbetween_mousemove: bool,
) -> tuple[type, type]:
    safe_name = tree_type.replace(".", "_").lower()
    gizmo_idname = f"BQT_{safe_name.upper()}_GT_input_capture"
    gizmo_group_idname = f"BQT_{safe_name.upper()}_GGT_input_capture"

    def _gizmo_get_runtime(self, context, *, create=True):
        return _resolve_runtime(get_runtime_function, context, create=create)

    input_gizmo = type(
        gizmo_idname,
        (InputCaptureGizmoBase,),
        {
            "bl_idname": gizmo_idname,
            "include_inbetween_mousemove": include_inbetween_mousemove,
            "get_runtime": _gizmo_get_runtime,
        },
    )

    def _group_poll(cls, context):
        return poll_function(context)

    input_gizmo_group = type(
        gizmo_group_idname,
        (InputCaptureGizmoGroupBase,),
        {
            "bl_idname": gizmo_group_idname,
            "bl_label": f"Blender Qt {tree_type} Input Capture",
            "gizmo_type": gizmo_idname,
            "get_runtime": lambda self, context: get_runtime_function(context),
            "poll": classmethod(_group_poll),
        },
    )

    return input_gizmo, input_gizmo_group


def register_keymaps(tree_type: str) -> None:
    ensure_global_operator()
    window_manager = bpy.context.window_manager
    keyconfig = window_manager.keyconfigs.addon
    if keyconfig is None:
        LOGGER.warning("Addon keyconfig is not available; keymaps not registered.")
        return
    keymap = keyconfig.keymaps.new(name="Node Editor", space_type="NODE_EDITOR", region_type="WINDOW")
    items: list[tuple[Any, Any]] = []
    for key_type in KEY_TYPES:
        for value in ("PRESS", "RELEASE"):
            keymap_item = keymap.keymap_items.new(
                BQT_OT_space_forward_key.bl_idname,
                key_type,
                value,
                any=True,
                head=True,
            )
            keymap_item.properties.event_type = key_type
            items.append((keymap, keymap_item))
    _ADDON_KEYMAPS[tree_type] = items


def unregister_keymaps(tree_type: str) -> None:
    for keymap, keymap_item in _ADDON_KEYMAPS.pop(tree_type, []):
        try:
            keymap.keymap_items.remove(keymap_item)
        except ReferenceError:
            LOGGER.debug("Keymap item already removed.", exc_info=True)
