"""Shared node-space plumbing used by both QML and widget backends."""

from .gizmos import InputCaptureGizmoBase, InputCaptureGizmoGroupBase
from .input import (
    create_input_gizmo_classes,
    register_keymaps,
    register_space_input,
    unregister_keymaps,
    unregister_space_input,
)
from .runtime import SpaceRuntimeBase

__all__ = [
    "InputCaptureGizmoBase",
    "InputCaptureGizmoGroupBase",
    "SpaceRuntimeBase",
    "create_input_gizmo_classes",
    "register_keymaps",
    "register_space_input",
    "unregister_keymaps",
    "unregister_space_input",
]
