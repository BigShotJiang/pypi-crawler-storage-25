"""Shared node-space registration plumbing used by backend packages."""

from __future__ import annotations

import logging
from typing import Callable

import bpy

from ..interfaces import ContextPoll, GetSpaceRuntime
from ..config import log_message
from ..constants import LogCategory
from .base import (
    CustomNodeTreeBase,
    CustomSpaceSpec,
    ensure_space_tree,
    get_current_space_tree,
    register_custom_header,
    unregister_custom_header,
)
from .input import (
    create_input_gizmo_classes,
    register_keymaps,
    register_space_input,
    unregister_keymaps,
    unregister_space_input,
)

LOGGER = logging.getLogger(__name__)

_REGISTERED_SPACES: dict[str, "_SpaceRegistration"] = {}


class _SpaceRegistration:
    __slots__ = (
        "tree_type",
        "spec",
        "blender_classes",
        "draw_handler",
        "get_runtime_function",
        "clear_runtimes_function",
    )

    def __init__(
        self,
        tree_type: str,
        spec: CustomSpaceSpec,
        blender_classes: list[type],
        draw_handler: object,
        get_runtime_function: GetSpaceRuntime,
        clear_runtimes_function: Callable[[], None],
    ) -> None:
        self.tree_type = tree_type
        self.spec = spec
        self.blender_classes = blender_classes
        self.draw_handler = draw_handler
        self.get_runtime_function = get_runtime_function
        self.clear_runtimes_function = clear_runtimes_function


def get_registered_tree_types() -> list[str]:
    return list(_REGISTERED_SPACES.keys())


def is_space_registered(tree_type: str) -> bool:
    """Return whether *tree_type* is currently registered."""
    return tree_type in _REGISTERED_SPACES


def unregister_space(tree_type: str) -> None:
    registration = _REGISTERED_SPACES.pop(tree_type, None)
    if registration is None:
        LOGGER.warning("Space %r is not registered; nothing to unregister.", tree_type)
        return
    unregister_keymaps(tree_type)
    unregister_space_input(tree_type)
    unregister_custom_header(tree_type)
    if registration.draw_handler is not None:
        bpy.types.SpaceNodeEditor.draw_handler_remove(registration.draw_handler, "WINDOW")
    registration.clear_runtimes_function()
    for blender_class in reversed(registration.blender_classes):
        try:
            bpy.utils.unregister_class(blender_class)
        except RuntimeError:
            LOGGER.debug("Failed to unregister %r", blender_class, exc_info=True)
    log_message(LOGGER, LogCategory.REGISTRATION, logging.INFO, "Unregistered space %r", tree_type)


def register_space_draw_handler(tree_type: str, get_runtime_function: GetSpaceRuntime) -> object:
    def draw_space() -> None:
        context = bpy.context
        space = getattr(context, "space_data", None)
        if space is None or space.type != "NODE_EDITOR":
            return
        if getattr(space, "tree_type", "") != tree_type:
            return
        active_runtime = get_runtime_function(context)
        if active_runtime is not None:
            active_runtime.draw(context)

    return bpy.types.SpaceNodeEditor.draw_handler_add(draw_space, (), "WINDOW", "POST_PIXEL")


def finalize_space_registration(
    *,
    tree_type: str,
    spec: CustomSpaceSpec,
    poll_function: ContextPoll,
    get_runtime_function: GetSpaceRuntime,
    clear_runtimes_function: Callable[[], None],
    is_qml: bool,
) -> None:
    blender_classes = _generate_blender_classes(
        spec=spec,
        poll_function=poll_function,
        get_runtime_function=get_runtime_function,
        is_qml=is_qml,
    )
    draw_handler = register_space_draw_handler(tree_type, get_runtime_function)
    for blender_class in blender_classes:
        bpy.utils.register_class(blender_class)
    register_space_input(tree_type, poll_function, get_runtime_function)
    register_custom_header(spec)
    register_keymaps(tree_type)
    _REGISTERED_SPACES[tree_type] = _SpaceRegistration(
        tree_type=tree_type,
        spec=spec,
        blender_classes=blender_classes,
        draw_handler=draw_handler,
        get_runtime_function=get_runtime_function,
        clear_runtimes_function=clear_runtimes_function,
    )


def _generate_blender_classes(
    spec: CustomSpaceSpec,
    poll_function: ContextPoll,
    get_runtime_function: GetSpaceRuntime,
    is_qml: bool,
) -> list[type]:
    safe_name = spec.tree_type.replace(".", "_").lower()
    classes: list[type] = []
    node_tree_class = type(
        f"BQT_{safe_name.upper()}_NT_graph",
        (CustomNodeTreeBase, bpy.types.NodeTree),
        {"bl_idname": spec.tree_type, "bl_label": spec.tree_label, "bl_icon": spec.tree_icon},
    )
    classes.append(node_tree_class)
    input_gizmo, input_gizmo_group = create_input_gizmo_classes(
        spec.tree_type,
        poll_function,
        get_runtime_function,
        include_inbetween_mousemove=True,
    )
    classes.extend([input_gizmo, input_gizmo_group])
    classes.append(_make_create_graph_operator(spec, poll_function))
    classes.append(_make_reload_operator(spec, poll_function, get_runtime_function))
    if spec.header_menu_idname:
        classes.append(_make_header_menu(spec))
    if spec.show_sidebar:
        classes.append(_make_sidebar_panel(spec, poll_function, get_runtime_function))
    return classes


def _make_create_graph_operator(spec: CustomSpaceSpec, poll_function: ContextPoll) -> type:
    safe_name = spec.tree_type.replace(".", "_").lower()

    class _CreateGraphOperator(bpy.types.Operator):
        bl_idname = spec.create_graph_operator
        bl_label = f"Create {spec.tree_label} Graph"

        @classmethod
        def poll(cls, context: bpy.types.Context) -> bool:
            return poll_function(context)

        def execute(self, context: bpy.types.Context) -> set[str]:
            tree = ensure_space_tree(context, spec)
            if tree is None:
                return {"CANCELLED"}
            context.area.tag_redraw()
            return {"FINISHED"}

    _CreateGraphOperator.__name__ = f"BQT_{safe_name.upper()}_OT_create_graph"
    _CreateGraphOperator.__qualname__ = _CreateGraphOperator.__name__
    return _CreateGraphOperator


def _make_reload_operator(
    spec: CustomSpaceSpec, poll_function: ContextPoll, get_runtime_function: GetSpaceRuntime
) -> type:
    safe_name = spec.tree_type.replace(".", "_").lower()

    class _ReloadOperator(bpy.types.Operator):
        bl_idname = spec.reload_operator
        bl_label = f"Reload {spec.tree_label}"

        @classmethod
        def poll(cls, context: bpy.types.Context) -> bool:
            return poll_function(context)

        def execute(self, context: bpy.types.Context) -> set[str]:
            tree = ensure_space_tree(context, spec)
            if tree is None:
                return {"CANCELLED"}
            runtime = get_runtime_function(context)
            if runtime is None:
                return {"CANCELLED"}
            runtime.reload_surface()
            context.area.tag_redraw()
            return {"FINISHED"}

    _ReloadOperator.__name__ = f"BQT_{safe_name.upper()}_OT_reload"
    _ReloadOperator.__qualname__ = _ReloadOperator.__name__
    return _ReloadOperator


def _make_header_menu(spec: CustomSpaceSpec) -> type:
    class _HeaderMenu(bpy.types.Menu):
        bl_label = spec.tree_label
        bl_idname = spec.header_menu_idname

        def draw(self, context: bpy.types.Context) -> None:
            if spec.menu_draw_callback is not None:
                spec.menu_draw_callback(self, context)

    _HeaderMenu.__name__ = spec.header_menu_idname
    _HeaderMenu.__qualname__ = spec.header_menu_idname
    return _HeaderMenu


def _make_sidebar_panel(
    spec: CustomSpaceSpec, poll_function: ContextPoll, get_runtime_function: GetSpaceRuntime
) -> type:
    safe_name = spec.tree_type.replace(".", "_").lower()
    panel_idname = f"BQT_{safe_name.upper()}_PT_sidebar"

    class _SidebarPanel(bpy.types.Panel):
        bl_label = spec.sidebar_label
        bl_idname = panel_idname
        bl_space_type = "NODE_EDITOR"
        bl_region_type = "UI"
        bl_category = spec.sidebar_category

        @classmethod
        def poll(cls, context: bpy.types.Context) -> bool:
            return poll_function(context)

        def draw(self, context: bpy.types.Context) -> None:
            layout = self.layout
            tree = get_current_space_tree(context, spec.tree_type)
            runtime = get_runtime_function(context)
            layout.operator(spec.reload_operator, icon="FILE_REFRESH")
            if tree is None:
                layout.label(text="No graph assigned", icon="INFO")
                layout.operator(spec.create_graph_operator, icon="NODETREE")
                return
            layout.label(text="Active graph", icon="CHECKMARK")
            if runtime is not None:
                layout.separator()
                layout.label(text=f"Viewport: {runtime.draw_area[2]} x {runtime.draw_area[3]}")

    _SidebarPanel.__name__ = panel_idname
    _SidebarPanel.__qualname__ = panel_idname
    return _SidebarPanel
