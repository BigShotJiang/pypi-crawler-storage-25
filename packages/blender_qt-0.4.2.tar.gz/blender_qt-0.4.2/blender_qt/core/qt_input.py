"""Shared Qt input conversion helpers used by offscreen renderers."""

from __future__ import annotations

from mathutils import Vector
from PySide6 import QtCore

from .constants import KeyboardModifier, MouseButton


def to_qt_point(surface_position: Vector) -> QtCore.QPoint:
    """Convert a surface-space vector into a Qt point."""

    return QtCore.QPoint(int(surface_position.x), int(surface_position.y))


def to_qt_modifiers(modifiers: KeyboardModifier) -> QtCore.Qt.KeyboardModifiers:
    """Convert project-local modifier flags into Qt modifiers."""

    qt_modifiers = QtCore.Qt.NoModifier
    if modifiers & KeyboardModifier.SHIFT:
        qt_modifiers |= QtCore.Qt.ShiftModifier
    if modifiers & KeyboardModifier.CTRL:
        qt_modifiers |= QtCore.Qt.ControlModifier
    if modifiers & KeyboardModifier.ALT:
        qt_modifiers |= QtCore.Qt.AltModifier
    return qt_modifiers


def to_qt_button(button: MouseButton) -> QtCore.Qt.MouseButton:
    """Convert project-local mouse button flags into a Qt mouse button."""

    if button & MouseButton.MIDDLE:
        return QtCore.Qt.MiddleButton
    if button & MouseButton.RIGHT:
        return QtCore.Qt.RightButton
    if button & MouseButton.LEFT:
        return QtCore.Qt.LeftButton
    return QtCore.Qt.NoButton
