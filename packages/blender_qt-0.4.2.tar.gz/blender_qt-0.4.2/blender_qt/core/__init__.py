"""Blender Qt core — application lifecycle, types, constants, and event loop."""
