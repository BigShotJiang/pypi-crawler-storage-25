"""Shared protocols and type aliases used across Blender Qt backends.

Coordinate-space naming used by the interfaces:

- ``screen_position``: Blender-facing pixel coordinates gathered from events or
    viewport picking.
- ``logical_position``: unscaled local coordinates after converting into the
    relevant Blender region or panel space.
- ``surface_position``: scaled renderer-local coordinates used by Qt surfaces.
"""

from __future__ import annotations

from typing import Callable, Protocol, TypeAlias

import bpy
from mathutils import Vector
from PySide6 import QtGui, QtWidgets

from .constants import KeyboardModifier, MouseButton

WidgetFactory: TypeAlias = (
    type[QtWidgets.QWidget] | Callable[[], QtWidgets.QWidget] | Callable[[QtWidgets.QWidget], QtWidgets.QWidget]
)
WidgetGeometryProvider: TypeAlias = Callable[[QtWidgets.QWidget], tuple[int, int, int, int]]


class IOffscreenRenderer(Protocol):
    """Renderer contract for translating Blender Qt surface-space input into Qt events.

    Coordinate spaces:
    - ``surface_position``: scaled renderer-local coordinates inside the Qt surface.
    - ``window_size``: current renderer backing size represented as a ``Vector``.
    """

    window_size: Vector

    def render(self) -> QtGui.QImage:
        """Return the latest rendered image for the current surface size."""
        ...

    def service(self) -> None:
        """Refresh internal Qt state and rebuild the image if the renderer is dirty."""
        ...

    def set_size(self, width: int, height: int) -> None:
        """Resize the logical surface in unscaled Qt surface pixels."""
        ...

    def send_mouse_move(
        self,
        surface_pixel_position: Vector,
        modifiers: KeyboardModifier = KeyboardModifier.NONE,
    ) -> None:
        """Forward mouse movement in scaled local surface pixels."""
        ...

    def send_mouse_press(
        self,
        surface_pixel_position: Vector,
        button: MouseButton,
        modifiers: KeyboardModifier = KeyboardModifier.NONE,
    ) -> None:
        """Forward a mouse press in scaled local surface pixels."""
        ...

    def send_mouse_release(
        self,
        surface_pixel_position: Vector,
        button: MouseButton,
        modifiers: KeyboardModifier = KeyboardModifier.NONE,
    ) -> None:
        """Forward a mouse release in scaled local surface pixels."""
        ...

    def send_key(
        self,
        event_type: str,
        event_value: str,
        unicode_text: str,
        modifiers: KeyboardModifier = KeyboardModifier.NONE,
    ) -> bool:
        """Forward a keyboard event using project-local modifier flags."""
        ...

    def has_keyboard_focus(self) -> bool:
        """Return whether the renderer currently owns a text-capable focus target."""
        ...

    def clear_focus(self) -> None:
        """Clear Qt-side focus owned by this renderer."""
        ...

    def mark_visible(self) -> None:
        """Mark the renderer as recently visible in Blender."""
        ...

    def is_visible(self) -> bool:
        """Return whether the renderer should still be considered visible this tick."""
        ...

    def is_dirty(self) -> bool:
        """Return whether a fresh render is needed."""
        ...

    def cleanup(self) -> None:
        """Release any renderer-owned resources."""
        ...

    def deleteLater(self) -> None:
        """Schedule the renderer for deferred destruction (Qt lifecycle)."""
        ...


class ISpaceRuntime(Protocol):
    """Runtime contract for custom node-editor spaces.

    A space runtime owns one offscreen renderer for a node-editor area and is
    responsible for translating Blender screen positions into unscaled logical
    positions, then mapping those logical positions into scaled surface
    positions before forwarding input to the renderer.
    """

    draw_area: tuple[int, int, int, int]
    renderer: IOffscreenRenderer | None

    def region_point(
        self,
        context: bpy.types.Context,
        screen_x: int,
        screen_y: int,
    ) -> tuple[int, int]:
        """Convert a Blender screen-space point into unscaled region pixel space."""
        ...

    def event_region_point(
        self,
        context: bpy.types.Context,
        event: bpy.types.Event,
    ) -> tuple[int, int]:
        """Extract an event position in unscaled region pixel space."""
        ...

    def sync_region(self, context: bpy.types.Context) -> None:
        """Update cached region bounds and renderer size from the active Blender region."""
        ...

    def contains(self, local_x: int, local_y: int) -> bool:
        """Return whether an unscaled region pixel position lies inside the space surface."""
        ...

    def to_surface_point(self, logical_position: tuple[int, int]) -> Vector:
        """Map unscaled logical pixels into scaled local surface pixels."""
        ...

    def has_keyboard_focus(self) -> bool:
        """Return whether the embedded Qt content wants keyboard input."""
        ...

    def handle_mouse_move(self, context: bpy.types.Context, event: bpy.types.Event) -> None:
        """Translate and forward mouse movement from Blender into the renderer."""
        ...

    def handle_mouse_press(self, context: bpy.types.Context, event: bpy.types.Event) -> None:
        """Translate and forward a mouse press from Blender into the renderer."""
        ...

    def handle_mouse_release(self, context: bpy.types.Context, event: bpy.types.Event) -> None:
        """Translate and forward a mouse release from Blender into the renderer."""
        ...

    def handle_key_event(self, context: bpy.types.Context, event: bpy.types.Event) -> bool:
        """Translate and forward a keyboard event from Blender into the renderer."""
        ...

    def schedule_mouse_release(
        self,
        logical_position: tuple[int, int],
        event_type: str,
        modifiers: KeyboardModifier = KeyboardModifier.NONE,
    ) -> None:
        """Queue a deferred mouse release in unscaled logical pixel space."""
        ...

    def draw(self, context: bpy.types.Context) -> None:
        """Draw the current renderer image into Blender."""
        ...

    def cleanup(self) -> None:
        """Dispose renderer-side resources owned by the runtime."""
        ...

    def reload_surface(self) -> None:
        """Rebuild the underlying Qt surface content in place."""
        ...


class IViewportRuntime(Protocol):
    """Runtime contract for viewport panel gizmos.

    Coordinate spaces:
    - ``screen_position``: an unscaled Blender-facing pixel position.
    - ``logical_position``: any intermediate unscaled local panel position.
    - ``surface_position``: the scaled local Qt panel-space position derived from it.
    """

    draw_area: tuple[int, int, int, int]
    is_2d: bool
    screen_x: int
    screen_y: int
    renderer: IOffscreenRenderer | None

    def update_screen_position(self, context: bpy.types.Context) -> None:
        """Refresh cached viewport placement for the panel."""
        ...

    def contains(self, screen_position: Vector) -> bool:
        """Return whether an unscaled screen position lies inside the panel."""
        ...

    def in_drag_handle(self, screen_position: Vector) -> bool:
        """Return whether an unscaled screen position lies inside the drag handle."""
        ...

    def to_surface_point(self, screen_position: Vector) -> Vector:
        """Map an unscaled screen position into scaled local panel surface pixels."""
        ...

    def has_keyboard_focus(self) -> bool:
        """Return whether the panel currently wants keyboard input."""
        ...

    def clear_focus(self) -> None:
        """Clear panel-side keyboard focus."""
        ...

    def handle_mouse_move(self, screen_position: Vector, event: bpy.types.Event) -> None:
        """Translate and forward mouse movement from screen space into the renderer."""
        ...

    def handle_mouse_press(self, screen_position: Vector, event: bpy.types.Event) -> None:
        """Translate and forward a mouse press from screen space into the renderer."""
        ...

    def handle_mouse_release(self, screen_position: Vector, event: object) -> None:
        """Translate and forward a mouse release from screen space into the renderer."""
        ...

    def handle_key_event(self, event: bpy.types.Event) -> bool:
        """Forward a keyboard event to the focused panel renderer."""
        ...

    def drag_3d(
        self,
        context: bpy.types.Context,
        screen_position: Vector,
        drag_offset: tuple[int, int],
    ) -> None:
        """Move a 3D panel using an unscaled screen position and drag offset."""
        ...

    def draw(self, context: bpy.types.Context) -> None:
        """Draw the current panel image into the Blender viewport."""
        ...

    def cleanup(self) -> None:
        """Dispose renderer-side resources owned by the viewport runtime."""
        ...


ContextPoll: TypeAlias = Callable[[bpy.types.Context], bool]
GetSpaceRuntime: TypeAlias = Callable[..., ISpaceRuntime | None]
GetViewportRuntime: TypeAlias = Callable[[], IViewportRuntime | None]
