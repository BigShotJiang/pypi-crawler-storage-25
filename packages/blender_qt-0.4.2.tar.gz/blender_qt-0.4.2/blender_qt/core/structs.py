"""Public dataclasses and type definitions for the Blender Qt package."""

from __future__ import annotations

from dataclasses import dataclass

from PySide6 import QtGui


@dataclass(frozen=True)
class SpaceConfig:
    """Configuration for registering a custom space in Blender.

    Attributes:
        tree_type: Unique node tree identifier (e.g. ``"MY_ADDON_QML_NT"``).
        label: Human-readable display name shown in the space header.
        icon: Blender icon identifier used in menus and headers.
        sidebar_category: N-panel tab name. Empty string disables the sidebar panel.
        sidebar_label: Label shown inside the N-panel section.  Falls back to *label* when empty.
    """

    tree_type: str
    label: str
    icon: str = "NODETREE"
    sidebar_category: str = ""
    sidebar_label: str = ""


@dataclass(frozen=True)
class BlenderScale:
    """Snapshot of Blender UI scale values used to size Qt surfaces.

    Attributes:
        logical_ui_scale: Fixed logical scale applied to all Blender Qt rendering.
        popup_scale: ``preferences.view.ui_scale`` — controls popup / combo box sizing.
        render_scale: Effective backing-store multiplier (at least 1.0).
        system_scale: ``preferences.system.ui_scale`` — system-level DPI factor.
    """

    logical_ui_scale: float
    popup_scale: float
    render_scale: float
    system_scale: float


@dataclass(frozen=True)
class BlenderThemeState:
    """Immutable snapshot of a translated Blender theme.

    Attributes:
        signature: Tuple of integers encoding every sampled colour and metric.
            Two states with the same signature are visually identical.
        palette: Fully populated :class:`QPalette` including disabled colour group.
        colors: Named hex colour strings (``window``, ``base``, ``highlight``, …).
        metrics: Named float metrics (``uiScale``, ``widgetPointSize``, …).
    """

    signature: tuple[int, ...]
    palette: QtGui.QPalette
    colors: dict[str, str]
    metrics: dict[str, float]
