"""QApplication singleton management and DPI configuration.

Only one QApplication may exist per process.  This module guarantees that
``ensure_qt_app()`` is idempotent and that the Blender event-loop timer is
registered exactly once.
"""

from __future__ import annotations

import logging
import os
import sys

from typing import TYPE_CHECKING, Any, Callable, TypeVar

import bpy
from PySide6 import QtCore, QtGui, QtWidgets

from .config import configure_logging, get_runtime_options
from .config import get_update_interval_seconds
from .interfaces import IOffscreenRenderer
from .platform import process_has_foreground_window, reset_modifier_state
from .space.base import tag_redraw_custom_spaces
from .space.registration import get_registered_tree_types
from ..theme.sync import sync_application_theme

if TYPE_CHECKING:
    pass

LOGGER = logging.getLogger(__name__)

T = TypeVar("T")

_QT_APPLICATION: QtWidgets.QApplication | None = None
_EVENT_TIMER_REGISTERED: bool = False
_QT_DPI_CONFIGURED: bool = False
_LAST_PROCESS_FOCUS: bool | None = None


def configure_qt_dpi() -> None:
    """Apply one-time Qt DPI / scale-factor environment overrides.

    Must be called **before** the first ``QApplication`` is constructed.
    Subsequent calls are no-ops.
    """
    global _QT_DPI_CONFIGURED

    if _QT_DPI_CONFIGURED:
        return

    os.environ.setdefault("QT_QUICK_BACKEND", "software")
    os.environ.setdefault("QT_OPENGL", "software")
    os.environ.setdefault("QT_QUICK_CONTROLS_STYLE", "Fusion")
    os.environ.setdefault("QT_SCALE_FACTOR", "1")
    os.environ.setdefault("QT_FONT_DPI", "96")

    try:
        QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_Use96Dpi, True)
    except RuntimeError:
        LOGGER.debug("AA_Use96Dpi attribute could not be set (application already exists)")

    try:
        QtGui.QGuiApplication.setHighDpiScaleFactorRoundingPolicy(
            QtCore.Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
        )
    except RuntimeError:
        LOGGER.debug("High-DPI rounding policy could not be set (application already exists)")

    _QT_DPI_CONFIGURED = True


def ensure_qt_app() -> QtWidgets.QApplication:
    """Return the singleton ``QApplication``, creating it if necessary.

    This also:
    - Configures DPI overrides.
    - Forces the *Fusion* style when no style argument is present.
    - Performs the first Blender→Qt theme sync.
    - Registers the persistent Blender timer that drives
      :func:`~blender_qt.core.events.process_qt_events`.

    Returns:
        The running ``QApplication`` instance.
    """
    global _QT_APPLICATION

    configure_logging()

    if _QT_APPLICATION is not None:
        sync_application_theme(_QT_APPLICATION)
        return _QT_APPLICATION

    configure_qt_dpi()

    if "-style" not in sys.argv and "--style" not in sys.argv:
        sys.argv[1:1] = ["-style", "Fusion"]

    existing_application = QtWidgets.QApplication.instance()
    _QT_APPLICATION = existing_application or QtWidgets.QApplication(sys.argv)
    sync_application_theme(_QT_APPLICATION)

    from .windows import install_application_callbacks  # noqa: WPS433

    install_application_callbacks(_QT_APPLICATION)

    _start_event_timer()

    return _QT_APPLICATION


def _start_event_timer() -> None:
    """Register the Blender timer that drives the Qt event loop."""
    global _EVENT_TIMER_REGISTERED

    if _EVENT_TIMER_REGISTERED:
        return

    if not bpy.app.timers.is_registered(process_qt_events):
        bpy.app.timers.register(process_qt_events, persistent=True)

    _EVENT_TIMER_REGISTERED = True


def stop_event_timer() -> None:
    """Unregister the Blender timer that drives the Qt event loop."""
    global _EVENT_TIMER_REGISTERED

    if bpy.app.timers.is_registered(process_qt_events):
        bpy.app.timers.unregister(process_qt_events)

    _EVENT_TIMER_REGISTERED = False


def shutdown_qt_app() -> None:
    """Detach Blender Qt from the current ``QApplication`` instance."""
    global _QT_APPLICATION, _LAST_PROCESS_FOCUS

    application = _QT_APPLICATION or QtWidgets.QApplication.instance()

    from .windows import uninstall_application_callbacks  # noqa: WPS433

    uninstall_application_callbacks(application)
    stop_event_timer()
    _LAST_PROCESS_FOCUS = None
    _QT_APPLICATION = None


def get_qt_application() -> QtWidgets.QApplication | None:
    """Return the managed ``QApplication`` or ``None`` if not yet created.

    Unlike :func:`ensure_qt_app` this will never create a new application.

    Returns:
        The current ``QApplication`` if one was created via Blender Qt, else ``None``.
    """
    return _QT_APPLICATION


def get_main_window() -> bpy.types.Window | None:
    """Return Blender's primary window, preferring root windows."""
    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is None:
        return None

    for window in window_manager.windows:
        if getattr(window, "parent", None) is None:
            return window

    return window_manager.windows[0] if window_manager.windows else None


def get_top_level_windows() -> list[bpy.types.Window]:
    """Return Blender top-level windows in display order."""
    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is None:
        return []

    return [window for window in window_manager.windows if getattr(window, "parent", None) is None]


def invoke_in_main(
    callback: Callable[..., T],
    *args: Any,
    **kwargs: Any,
) -> T:
    """Run *callback* inside a main-window context override when possible."""
    window = get_main_window()
    if window is None:
        return callback(*args, **kwargs)

    with bpy.context.temp_override(window=window):
        return callback(*args, **kwargs)


def execute_deferred(
    callback: Callable[..., Any],
    *args: Any,
    delay: float = 0.0,
    **kwargs: Any,
) -> None:
    """Schedule *callback* back onto Blender's timer-driven main thread."""

    def _run() -> None:
        invoke_in_main(callback, *args, **kwargs)
        return None

    bpy.app.timers.register(_run, first_interval=delay)


# MARK: Event-loop integration

# All active renderers that need per-tick servicing.
_ACTIVE_RENDERERS: list[IOffscreenRenderer] = []


def register_renderer(
    renderer: IOffscreenRenderer,
) -> None:
    """Add a renderer to the per-tick service list.

    Args:
        renderer: An offscreen renderer conforming to :class:`IOffscreenRenderer`.
    """
    if renderer not in _ACTIVE_RENDERERS:
        _ACTIVE_RENDERERS.append(renderer)


def unregister_renderer(
    renderer: IOffscreenRenderer,
) -> None:
    """Remove a renderer from the per-tick service list.

    Args:
        renderer: The renderer to remove.  Silently ignored if not registered.
    """
    try:
        _ACTIVE_RENDERERS.remove(renderer)
    except ValueError:
        pass


def flush_posted_events(passes: int = 4) -> None:
    """Flush the Qt posted-event queue without calling ``processEvents``.

    This is the core workaround for running Qt inside Blender's event loop.
    We call ``sendPostedEvents`` multiple times to ensure deferred-delete
    events and nested post chains are fully drained.

    Args:
        passes: Number of flush iterations.  The default of 4 covers most
            nested post/delete chains encountered in practice.
    """
    application = QtWidgets.QApplication.instance()
    if application is None:
        return

    for _ in range(max(1, passes)):
        QtCore.QCoreApplication.sendPostedEvents(None, 0)
        QtCore.QCoreApplication.sendPostedEvents(None, QtCore.QEvent.DeferredDelete)


def process_qt_events() -> float:
    """Blender timer callback that services the Qt event loop each frame.

    This function is registered as a persistent Blender timer.  It:

    1. Syncs the Blender theme into the Qt palette (if changed).
    2. Flushes posted Qt events.
    3. Calls ``service()`` on every active renderer.
    4. Triggers a Blender redraw when the theme changes.

    Returns:
        Timer interval in seconds (≈60 fps).
    """
    theme_changed = sync_application_theme()

    if theme_changed:
        _apply_theme_to_renderers()

    flush_posted_events()
    _service_managed_windows()
    _service_focus_recovery()

    for renderer in list(_ACTIVE_RENDERERS):
        try:
            if not renderer.is_dirty():
                continue
            if not renderer.is_visible():
                continue
            renderer.service()
        except Exception:
            LOGGER.exception("Error servicing renderer %r", renderer)

    if theme_changed:
        _redraw_all_custom_spaces()

    return get_update_interval_seconds(get_runtime_options().update_interval_ms / 1000.0)


def _redraw_all_custom_spaces() -> None:
    """Tag every registered custom space area for redraw after a theme change."""
    for tree_type in get_registered_tree_types():
        tag_redraw_custom_spaces(tree_type)


def _apply_theme_to_renderers() -> None:
    """Ask active renderers to refresh theme-dependent state."""
    for renderer in list(_ACTIVE_RENDERERS):
        try:
            apply_theme = getattr(renderer, "apply_theme", None)
            if callable(apply_theme):
                apply_theme()
        except Exception:
            LOGGER.exception("Error applying theme to renderer %r", renderer)


def clear_renderers() -> None:
    """Remove all renderers from the service list."""
    _ACTIVE_RENDERERS.clear()


# Exactly one renderer at a time is the "keyboard focus owner". Offscreen
# host windows can't reliably share Qt's global focus state, so we track it
# ourselves: whichever renderer was most recently clicked owns text input
# until another renderer claims it.
_FOCUS_OWNER: IOffscreenRenderer | None = None


def set_focus_owner(renderer: IOffscreenRenderer) -> None:
    """Mark *renderer* as the active keyboard-focus owner.

    Clears focus on the previous owner (if any). No-op when *renderer* is
    already the owner.
    """
    global _FOCUS_OWNER
    if _FOCUS_OWNER is renderer:
        return
    previous, _FOCUS_OWNER = _FOCUS_OWNER, renderer
    if previous is None:
        return
    clear = getattr(previous, "clear_focus", None)
    if not callable(clear):
        return
    try:
        clear()
    except Exception:
        LOGGER.exception("Error clearing focus on previous owner %r", previous)


def is_focus_owner(renderer: IOffscreenRenderer) -> bool:
    """Return whether *renderer* currently owns keyboard focus."""
    return _FOCUS_OWNER is renderer


def release_focus_owner(renderer: IOffscreenRenderer) -> None:
    """Drop ownership if *renderer* is the current owner."""
    global _FOCUS_OWNER
    if _FOCUS_OWNER is renderer:
        _FOCUS_OWNER = None


def _service_managed_windows() -> None:
    """Refresh any managed top-level tool windows."""
    if not get_runtime_options().manage_windows:
        return

    from .windows import service_windows  # noqa: WPS433

    service_windows()


def _service_focus_recovery() -> None:
    """Release stuck modifiers after focus returns to Blender on Windows."""
    global _LAST_PROCESS_FOCUS

    options = get_runtime_options()
    if not options.enable_focus_recovery:
        return

    has_focus = process_has_foreground_window()
    if _LAST_PROCESS_FOCUS is None:
        _LAST_PROCESS_FOCUS = has_focus
        return

    if has_focus and not _LAST_PROCESS_FOCUS:
        reset_modifier_state()

    _LAST_PROCESS_FOCUS = has_focus
