"""Managed top-level Qt window helpers for Blender Qt."""

from __future__ import annotations

import logging
from typing import Callable, Optional

from PySide6 import QtCore, QtWidgets

from .config import get_runtime_options
from .platform import bind_widget_to_blender_host, install_foreground_hook, uninstall_foreground_hook
from .._internal.windows import (
    ManagedWindow,
    MANAGED_WINDOWS,
    application_event_filter,
    apply_window_flags,
    event_filter,
    iter_managed_windows,
    remove_window,
    should_attach_to_host,
)

LOGGER = logging.getLogger(__name__)
_APPLICATION_CALLBACKS_INSTALLED = False


# MARK: public API


def register_window(
    widget: QtWidgets.QWidget,
    *,
    unique: bool | None = None,
    stay_on_top: bool | None = None,
    on_close: Callable[[QtWidgets.QWidget], None] | None = None,
) -> QtWidgets.QWidget:
    """Register and show a standalone managed top-level Qt window."""
    from .app import ensure_qt_app  # noqa: WPS433

    ensure_qt_app()

    options = get_runtime_options()
    unique = options.unique_windows if unique is None else unique
    stay_on_top = options.stay_on_top_windows if stay_on_top is None else stay_on_top

    managed_widget = widget

    if unique:
        object_name = managed_widget.objectName()
        existing_widget = find_window(object_name) if object_name else None
        if existing_widget is not None and existing_widget is not managed_widget:
            existing_widget.show()
            existing_widget.raise_()
            existing_widget.activateWindow()
            try:
                managed_widget.close()
                managed_widget.deleteLater()
            except RuntimeError:
                LOGGER.debug("Duplicate managed window already destroyed.", exc_info=True)
            return existing_widget

    apply_window_flags(managed_widget, stay_on_top)
    managed_widget.setAttribute(QtCore.Qt.WA_DeleteOnClose, False)
    managed_widget.installEventFilter(event_filter())

    existing_entry = next((entry for entry in iter_managed_windows() if entry.widget is managed_widget), None)
    if existing_entry is None:
        MANAGED_WINDOWS.append(ManagedWindow(managed_widget, on_close))
    else:
        existing_entry.on_close = on_close

    managed_widget.show()
    managed_widget.raise_()
    managed_widget.activateWindow()
    service_windows()
    return managed_widget


def install_application_callbacks(application: QtWidgets.QApplication) -> None:
    """Install lightweight callbacks used to auto-manage top-level windows."""
    global _APPLICATION_CALLBACKS_INSTALLED

    if _APPLICATION_CALLBACKS_INSTALLED:
        return

    af = application_event_filter()
    application.installEventFilter(af)
    install_foreground_hook(service_windows)
    _APPLICATION_CALLBACKS_INSTALLED = True


def uninstall_application_callbacks(application: QtWidgets.QApplication | None) -> None:
    """Remove lightweight application callbacks installed during startup."""
    global _APPLICATION_CALLBACKS_INSTALLED

    if not _APPLICATION_CALLBACKS_INSTALLED:
        return

    if application is not None:
        application.removeEventFilter(application_event_filter())
    uninstall_foreground_hook()
    _APPLICATION_CALLBACKS_INSTALLED = False


def service_windows() -> None:
    """Refresh native attachment for live managed windows."""
    options = get_runtime_options()
    if not options.manage_windows:
        return

    for entry in list(iter_managed_windows()):
        try:
            if entry.widget.isVisible() and should_attach_to_host(entry.widget):
                bind_widget_to_blender_host(entry.widget)
        except RuntimeError:
            remove_window(entry.widget)


def close_managed_windows() -> None:
    """Close all currently registered managed windows."""
    for entry in list(iter_managed_windows()):
        try:
            entry.widget.close()
        except RuntimeError:
            LOGGER.debug("Managed window already destroyed.", exc_info=True)
        finally:
            remove_window(entry.widget)


def managed_windows() -> list[QtWidgets.QWidget]:
    """Return all currently live managed windows."""
    return [entry.widget for entry in iter_managed_windows()]


def find_window(object_name: str | None) -> Optional[QtWidgets.QWidget]:
    """Return the live managed window with *object_name*, if any."""
    if not object_name:
        return None

    for entry in iter_managed_windows():
        try:
            if entry.widget.objectName() == object_name:
                return entry.widget
        except RuntimeError:
            remove_window(entry.widget)
    return None
