"""RSA signing utility - Ported from Java RsaUtil"""

import base64
import re
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.backends import default_backend
from enum import Enum
from typing import Optional


class SignAlgorithm(Enum):
    """Signature algorithm types"""
    SHA256withRSA = "SHA256withRSA"
    MD5withRSA = "MD5withRSA"


class RsaUtil:
    """RSA utility class for signing and verification"""
    
    @staticmethod
    def _normalize_header(header: str) -> str:
        """
        Normalize PEM header to correct format based on content type.
        
        PKCS#8 content starts with 0x30 (SEQUENCE) and can use 'PRIVATE KEY' header.
        PKCS#1 content starts with specific INTEGER sequences and needs 'RSA PRIVATE KEY' header.
        """
        # Extract the key type from header
        if 'RSA PRIVATE KEY' in header:
            # PKCS#1 format header
            return '-----BEGIN RSA PRIVATE KEY-----', '-----END RSA PRIVATE KEY-----'
        elif 'PRIVATE KEY' in header:
            # PKCS#8 format header
            return '-----BEGIN PRIVATE KEY-----', '-----END PRIVATE KEY-----'
        else:
            return header, header.replace('BEGIN', 'END')
    
    @staticmethod
    def _fix_header_mismatch(pem_data: str) -> str:
        """
        Fix header/content mismatch for PEM keys.
        
        If the content is PKCS#8 (starts with 0x30) but header says PKCS#1,
        or vice versa, adjust the header to match the content.
        """
        key = pem_data.strip()
        
        # Check if key has PEM headers
        pem_header_pattern = r'^-----BEGIN ([A-Z0-9 ]+)-----'
        pem_footer_pattern = r'-----END ([A-Z0-9 ]+)-----$'
        
        header_match = re.match(pem_header_pattern, key)
        footer_match = re.search(pem_footer_pattern, key)
        
        if not header_match or not footer_match:
            return key  # No headers, return as-is
        
        header_type = header_match.group(1).strip()
        footer_type = footer_match.group(1).strip()
        
        # Extract Base64 content
        content_start = header_match.end()
        content_end = footer_match.start()
        base64_content = key[content_start:content_end].replace('\r', '').replace('\n', '')
        
        # Decode first byte to check content type
        try:
            first_bytes = base64.b64decode(base64_content + '==')[:2]
            first_byte = first_bytes[0] if first_bytes else 0
            
            # 0x30 = SEQUENCE (PKCS#8 format)
            # Other values typically indicate PKCS#1 format
            if first_byte == 0x30:
                # Content is PKCS#8, ensure header matches
                if header_type != 'PRIVATE KEY' and 'RSA' in header_type:
                    # Fix: Use PKCS#8 header
                    return f"-----BEGIN PRIVATE KEY-----\n{base64_content}\n-----END PRIVATE KEY-----"
            else:
                # Content looks like PKCS#1, ensure header matches
                if header_type == 'PRIVATE KEY' and 'RSA' not in header_type:
                    # Fix: Use PKCS#1 header
                    return f"-----BEGIN RSA PRIVATE KEY-----\n{base64_content}\n-----END RSA PRIVATE KEY-----"
        except Exception:
            pass
        
        return key
    
    @staticmethod
    def _clean_key(key: str) -> str:
        """
        Clean the key by removing line breaks from Base64 content,
        while preserving PEM headers and fixing header/content mismatches.
        
        Handles both:
        - Full PEM format keys (with headers)
        - Raw Base64 keys (without headers)
        - Mismatched headers (PKCS#1 header with PKCS#8 content, etc.)
        """
        key = key.strip()
        
        # Check if key has PEM headers
        pem_header_pattern = r'^-----BEGIN [A-Z0-9 ]+-----'
        pem_footer_pattern = r'-----END [A-Z0-9 ]+-----$'
        
        has_header = bool(re.match(pem_header_pattern, key))
        has_footer = bool(re.search(pem_footer_pattern, key))
        
        if has_header and has_footer:
            # Full PEM format: extract and clean only the Base64 content
            header_match = re.match(pem_header_pattern, key)
            footer_match = re.search(pem_footer_pattern, key)
            
            header = header_match.group(0)
            footer = footer_match.group(0)
            
            # Extract content between header and footer
            content_start = header_match.end()
            content_end = footer_match.start()
            base64_content = key[content_start:content_end]
            
            # Clean line breaks only from Base64 content
            cleaned_base64 = base64_content.replace("\r", "").replace("\n", "")
            
            # Fix header/content mismatch
            corrected_pem = f"{header}\n{cleaned_base64}\n{footer}"
            return RsaUtil._fix_header_mismatch(corrected_pem)
        else:
            # Raw Base64 without headers - just remove line breaks
            return key.replace("\r", "").replace("\n", "")
    
    @staticmethod
    def get_private_key(private_key_pem: str) -> rsa.RSAPrivateKey:
        """
        Load private key from PEM string
        
        Args:
            private_key_pem: PEM formatted private key string
            
        Returns:
            RSAPrivateKey object
        """
        try:
            cleaned_key = RsaUtil._clean_key(private_key_pem)
            
            # Try loading as PKCS8 format first
            try:
                private_key = serialization.load_pem_private_key(
                    cleaned_key.encode('utf-8'),
                    password=None,
                    backend=default_backend()
                )
                return private_key
            except Exception:
                # Try loading as traditional RSA private key
                # Only wrap if not already in PEM format
                if cleaned_key.startswith("-----BEGIN"):
                    pem_data = cleaned_key.encode('utf-8')
                else:
                    pem_data = f"-----BEGIN RSA PRIVATE KEY-----\n{cleaned_key}\n-----END RSA PRIVATE KEY-----".encode('utf-8')
                
                private_key = serialization.load_pem_private_key(
                    pem_data,
                    password=None,
                    backend=default_backend()
                )
                return private_key
        except Exception as e:
            raise RuntimeError(f"Failed to load private key: {str(e)}")
    
    @staticmethod
    def get_public_key(public_key_pem: str) -> rsa.RSAPublicKey:
        """
        Load public key from PEM string
        
        Args:
            public_key_pem: PEM formatted public key string
            
        Returns:
            RSAPublicKey object
        """
        try:
            cleaned_key = RsaUtil._clean_key(public_key_pem)
            public_key = serialization.load_pem_public_key(
                cleaned_key.encode('utf-8'),
                backend=default_backend()
            )
            return public_key
        except Exception as e:
            raise RuntimeError(f"Failed to load public key: {str(e)}")
    
    @staticmethod
    def sign(content: str, private_key_pem: str, algorithm: SignAlgorithm = SignAlgorithm.SHA256withRSA) -> str:
        """
        Sign content using RSA private key
        
        Args:
            content: Content to sign
            private_key_pem: PEM formatted private key
            algorithm: Signature algorithm (default: SHA256withRSA)
            
        Returns:
            Base64 encoded signature string
        """
        try:
            private_key = RsaUtil.get_private_key(private_key_pem)
            
            # Map algorithm to hash function
            if algorithm == SignAlgorithm.SHA256withRSA:
                hash_algo = hashes.SHA256()
            elif algorithm == SignAlgorithm.MD5withRSA:
                hash_algo = hashes.MD5()
            else:
                raise ValueError(f"Unsupported algorithm: {algorithm}")
            
            # Sign the content
            signature = private_key.sign(
                content.encode('utf-8'),
                padding.PKCS1v15(),
                hash_algo
            )
            
            # Return base64 encoded signature
            return base64.b64encode(signature).decode('utf-8')
        except Exception as e:
            raise RuntimeError(f"Failed to sign content: {str(e)}")
    
    @staticmethod
    def verify(content: str, signature: str, public_key_pem: str, 
               algorithm: SignAlgorithm = SignAlgorithm.SHA256withRSA) -> bool:
        """
        Verify RSA signature
        
        Args:
            content: Original content
            signature: Base64 encoded signature
            public_key_pem: PEM formatted public key
            algorithm: Signature algorithm (default: SHA256withRSA)
            
        Returns:
            True if signature is valid, False otherwise
        """
        try:
            if signature is None:
                return False
            
            public_key = RsaUtil.get_public_key(public_key_pem)
            
            # Map algorithm to hash function
            if algorithm == SignAlgorithm.SHA256withRSA:
                hash_algo = hashes.SHA256()
            elif algorithm == SignAlgorithm.MD5withRSA:
                hash_algo = hashes.MD5()
            else:
                raise ValueError(f"Unsupported algorithm: {algorithm}")
            
            # Decode signature
            signature_bytes = base64.b64decode(signature.encode('utf-8'))
            
            # Verify the signature
            public_key.verify(
                signature_bytes,
                content.encode('utf-8'),
                padding.PKCS1v15(),
                hash_algo
            )
            return True
        except Exception:
            return False


class Signer:
    """Signature helper class - Compatible with Java Signer"""
    
    @staticmethod
    def sign(content: str, private_key: str, algorithm: SignAlgorithm = SignAlgorithm.SHA256withRSA) -> str:
        """
        Sign content using private key
        
        Args:
            content: Content to sign
            private_key: PEM formatted private key string
            algorithm: Signature algorithm
            
        Returns:
            Base64 encoded signature
        """
        return RsaUtil.sign(content, private_key, algorithm)
    
    @staticmethod
    def verify(content: str, signature: str, public_key: str,
               algorithm: SignAlgorithm = SignAlgorithm.SHA256withRSA) -> bool:
        """
        Verify signature
        
        Args:
            content: Original content
            signature: Base64 encoded signature
            public_key: PEM formatted public key string
            algorithm: Signature algorithm
            
        Returns:
            True if valid, False otherwise
        """
        return RsaUtil.verify(content, signature, public_key, algorithm)
