"""Nonce string generation utility"""

import random
import string


class NonceStrUtil:
    """Generate random nonce strings for API signatures"""
    
    SYMBOLS = string.digits + string.ascii_letters  # 0-9, a-z, A-Z
    
    @classmethod
    def generate(cls, length: int = 10) -> str:
        """
        Generate a random nonce string
        
        Args:
            length: Length of the nonce string (default: 10)
            
        Returns:
            Random nonce string
        """
        return ''.join(random.choice(cls.SYMBOLS) for _ in range(length))
