"""Configuration management for MCP Adapter"""

import os
from pathlib import Path
from typing import Optional
import yaml
from pydantic import BaseModel, Field


class SignatureConfig(BaseModel):
    """Open platform signature configuration
    
    Corresponds to Java OpenPlatformSignatureProperties and SignatureProperties:
    - app_id: Application ID (for auth_appId header)
    - app_instance_id: Application instance ID (for appInstanceId header in SaaSFeignConfig)
    - partner_id: Partner/Merchant ID (for auth_partnerId header in GlobalFeignConfig)
    - private_key: RSA private key for request signing
    - access_token: Access token for business authentication (optional)
    
    Note: app_instance_id and partner_id may have the same value in practice,
    but they are conceptually different configuration items from different Java config classes.
    """
    app_id: str = Field(..., description="Application ID (用于 auth_appId 请求头)")
    app_instance_id: str = Field(..., description="Application instance ID (用于 appInstanceId 请求头 - SaaSFeignConfig)")
    partner_id: str = Field(..., description="Partner/Merchant ID (用于 auth_partnerId 请求头 - GlobalFeignConfig)")
    app_instance_version: str = Field(default="1.0.0", description="Application instance version (用于 appVersion 请求头)")
    private_key: str = Field(..., description="RSA private key in PEM format (用于签名)")
    access_token: Optional[str] = Field(default=None, description="Access token for business authentication (用于 access_token 请求头, 可选)")


class OpenPlatformConfig(BaseModel):
    """Open platform configuration"""
    gateway_url: str = Field(..., description="Open platform gateway URL")
    signature: SignatureConfig = Field(..., description="Signature configuration")


class McpConfig(BaseModel):
    """MCP server configuration"""
    server_name: str = Field(default="subway-open-platform", description="MCP server name")
    server_version: str = Field(default="1.0.0", description="MCP server version")
    log_level: str = Field(default="INFO", description="Logging level")


class AppConfig(BaseModel):
    """Application configuration"""
    open_platform: OpenPlatformConfig
    mcp: McpConfig = Field(default_factory=McpConfig)

    @classmethod
    def from_yaml(cls, config_path: str) -> "AppConfig":
        """
        Load configuration from YAML file
        
        Args:
            config_path: Path to YAML configuration file
            
        Returns:
            AppConfig instance
        """
        with open(config_path, 'r', encoding='utf-8') as f:
            config_dict = yaml.safe_load(f)
        return cls(**config_dict)

    @classmethod
    def from_env(cls) -> "AppConfig":
        """
        Load configuration from environment variables
        
        Returns:
            AppConfig instance
        """
        signature_config = SignatureConfig(
            app_id=os.getenv("OPEN_PLATFORM_APP_ID", ""),
            app_instance_id=os.getenv("OPEN_PLATFORM_APP_INSTANCE_ID", ""),
            partner_id=os.getenv("OPEN_PLATFORM_PARTNER_ID", ""),
            app_instance_version=os.getenv("OPEN_PLATFORM_APP_INSTANCE_VERSION", "1.0.0"),
            private_key=os.getenv("OPEN_PLATFORM_PRIVATE_KEY", ""),
            access_token=os.getenv("OPEN_PLATFORM_ACCESS_TOKEN"),
        )

        open_platform_config = OpenPlatformConfig(
            gateway_url=os.getenv("OPEN_PLATFORM_GATEWAY_URL", ""),
            signature=signature_config,
        )

        mcp_config = McpConfig(
            log_level=os.getenv("MCP_LOG_LEVEL", "INFO"),
        )

        return cls(
            open_platform=open_platform_config,
            mcp=mcp_config,
        )


def load_config(config_path: Optional[str] = None) -> AppConfig:
    """
    Load application configuration
    
    Priority: config file > environment variables > defaults
    
    Args:
        config_path: Optional path to YAML config file
        
    Returns:
        AppConfig instance
    """
    if config_path and Path(config_path).exists():
        return AppConfig.from_yaml(config_path)
    else:
        return AppConfig.from_env()
