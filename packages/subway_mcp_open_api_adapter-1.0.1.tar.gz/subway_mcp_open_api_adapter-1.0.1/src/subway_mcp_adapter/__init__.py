"""Subway Open Platform MCP Adapter"""

__version__ = "1.0.0"
