"""Open Platform HTTP Client with signature support"""

import json
import logging
import time
from typing import Any, Dict, Optional
from urllib.parse import urljoin

import httpx

from .config import AppConfig
from .utils.nonce import NonceStrUtil
from .utils.rsa import Signer, SignAlgorithm

logger = logging.getLogger(__name__)


class OpenPlatformClient:
    """
    HTTP client for open platform API calls with automatic signature handling
    
    This client mirrors the Java SaaSFeignConfig behavior:
    - Generates timestamp and nonce
    - Signs request body using RSA private key
    - Adds required headers for authentication
    """
    
    # Sign template: timestamp;nonce;request_body;
    SIGN_TEMPLATE = "{};{};{};"
    
    def __init__(self, config: AppConfig):
        """
        Initialize the open platform client
        
        Args:
            config: Application configuration
        """
        self.config = config
        self.gateway_url = config.open_platform.gateway_url.rstrip('/')
        self.signature_config = config.open_platform.signature
        
        # Create HTTP client with common settings
        self.http_client = httpx.AsyncClient(
            timeout=30.0,
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
            }
        )
        
        logger.info(f"OpenPlatformClient initialized with gateway: {self.gateway_url}")
    
    def _generate_sign_headers(self, request_body: Optional[Dict[str, Any]] = None) -> Dict[str, str]:
        """
        Generate signature headers for API request
        
        Mirrors Java SaaSFeignConfig.requestInterceptor() behavior:
        1. Generate timestamp (milliseconds)
        2. Generate random nonce string
        3. Create sign string: timestamp;nonce;request_body;
        4. Sign using RSA private key with SHA256withRSA
        5. Add all required headers
        
        CRITICAL: The request_body_str used for signing MUST exactly match what Feign's
        requestTemplate.requestBody().asString() returns in Java.
        
        Args:
            request_body: Request body dictionary (optional)
            
        Returns:
            Dictionary of headers including signature
        """
        # Generate timestamp and nonce
        timestamp = str(int(time.time() * 1000))  # milliseconds
        nonce = NonceStrUtil.generate(10)
        
        # CRITICAL: Convert request body to JSON string exactly as Java Feign does
        # Java's requestTemplate.requestBody().asString() returns the raw body string
        # We need to match the exact format that httpx will send
        # Using separators=(',', ':') to remove all whitespace (compact JSON)
        # This matches typical Feign/Jackson default behavior
        request_body_str = json.dumps(request_body, ensure_ascii=False, separators=(',', ':')) if request_body else ""
        
        # Create sign string using template
        sign_str = self.SIGN_TEMPLATE.format(timestamp, nonce, request_body_str)
        
        # Sign the string
        signature = Signer.sign(
            sign_str,
            self.signature_config.private_key,
            SignAlgorithm.SHA256withRSA
        )
        
        # Build headers (matching Java implementation)
        headers = {
            "apiVersion": "v2",
            "appInstanceId": self.signature_config.app_instance_id,
            "appVersion": self.signature_config.app_instance_version,
            "nonce": nonce,
            "timestamp": timestamp,
            "sign": signature,
        }
        
        # Add business authentication headers (matching GlobalFeignConfig)
        # These headers are required for business API authentication
        if self.signature_config.access_token:
            headers["access_token"] = self.signature_config.access_token
        
        # Add partnerId and appId for business authentication
        # Note: auth_partnerId uses partner_id, which is different from app_instance_id
        headers["auth_partnerId"] = self.signature_config.partner_id
        headers["auth_appId"] = self.signature_config.app_id
        
        logger.debug(f"Generated sign headers: timestamp={timestamp}, nonce={nonce}")
        logger.debug(f"Sign string: {sign_str}")
        
        return headers
    
    async def request(
        self,
        method: str,
        path: str,
        body: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Make an API request to the open platform
        
        Args:
            method: HTTP method (GET, POST, PUT, DELETE, etc.)
            path: API path (e.g., "/opencenter/tripartite/menu/sync")
            body: Request body (for POST/PUT)
            params: Query parameters
            
        Returns:
            Response JSON dictionary
            
        Raises:
            httpx.HTTPStatusError: If request fails
            Exception: For other errors
        """
        # Build full URL
        url = urljoin(self.gateway_url + "/", path.lstrip('/'))
        
        # Generate signature headers
        headers = self._generate_sign_headers(body)
        
        # Log request
        logger.info(f"Making {method} request to {url}")
        logger.debug(f"Request body: {body}")
        
        try:
            # Make the request
            if method.upper() == "GET":
                response = await self.http_client.get(
                    url,
                    headers=headers,
                    params=params,
                )
            elif method.upper() == "POST":
                # CRITICAL: httpx's json= parameter uses json.dumps with default settings
                # which includes spaces after separators. We need to send compact JSON
                # to match what we signed. So we use content= with manually serialized JSON.
                if body is not None:
                    json_body = json.dumps(body, ensure_ascii=False, separators=(',', ':'))
                    response = await self.http_client.post(
                        url,
                        headers=headers,
                        content=json_body.encode('utf-8'),
                        params=params,
                    )
                else:
                    response = await self.http_client.post(
                        url,
                        headers=headers,
                        params=params,
                    )
            elif method.upper() == "PUT":
                # Same as POST - use compact JSON format
                if body is not None:
                    json_body = json.dumps(body, ensure_ascii=False, separators=(',', ':'))
                    response = await self.http_client.put(
                        url,
                        headers=headers,
                        content=json_body.encode('utf-8'),
                        params=params,
                    )
                else:
                    response = await self.http_client.put(
                        url,
                        headers=headers,
                        params=params,
                    )
            elif method.upper() == "DELETE":
                response = await self.http_client.delete(
                    url,
                    headers=headers,
                    params=params,
                )
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
            
            # Raise exception for error status codes
            response.raise_for_status()
            
            # Parse and return response
            result = response.json()
            logger.info(f"Request successful: {url}")
            logger.debug(f"Response: {result}")
            
            return result
            
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error: {e.response.status_code} - {e.response.text}")
            raise
        except Exception as e:
            logger.error(f"Request failed: {str(e)}")
            raise
    
    async def post(self, path: str, body: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Make a POST request
        
        Args:
            path: API path
            body: Request body
            
        Returns:
            Response JSON dictionary
        """
        return await self.request("POST", path, body=body)
    
    async def get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Make a GET request
        
        Args:
            path: API path
            params: Query parameters
            
        Returns:
            Response JSON dictionary
        """
        return await self.request("GET", path, params=params)
    
    async def close(self):
        """Close the HTTP client"""
        await self.http_client.aclose()
        logger.info("OpenPlatformClient closed")
