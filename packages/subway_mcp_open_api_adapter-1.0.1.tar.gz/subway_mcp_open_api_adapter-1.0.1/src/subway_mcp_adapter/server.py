"""MCP Server and Tools definition"""

import json
import logging
from typing import Any, Dict, List, Optional

from mcp.server.fastmcp import FastMCP

from .client import OpenPlatformClient
from .config import AppConfig, load_config

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class SubwayMCPAdapter:
    """
    MCP Adapter for Subway Open Platform
    
    Exposes open platform REST APIs as MCP tools with automatic
    signature handling and authentication.
    """
    
    def __init__(self, config: AppConfig):
        """
        Initialize the MCP adapter
        
        Args:
            config: Application configuration
        """
        self.config = config
        self.client = OpenPlatformClient(config)
        
        # Create MCP server
        self.mcp = FastMCP(
            name=config.mcp.server_name,
            version=config.mcp.server_version,
        )
        
        # Register tools
        self._register_tools()
        
        logger.info(f"SubwayMCPAdapter initialized: {config.mcp.server_name} v{config.mcp.server_version}")
    
    def _register_tools(self):
        """Register all MCP tools"""
        
        # Tool 1: 查询会员信息
        @self.mcp.tool(
            name="get_member_info",
            description="""
            查询会员信息。支持通过会员ID、手机号或动态码查询。
            
            对应Java接口: SaasMemberClient.getMember()
            API路径: POST /opencenter/customer/member/getMember
            
            查询方式（通过 ident_type 和 ident_id 组合）:
            - memberId: 会员编号查询
            - mobile: 手机号查询
            - dynamicCode: 动态码查询（格式：56#xxx#）
            
            示例:
            1. 通过会员ID查询: ident_type="memberId", ident_id="3742473176800792202"
            2. 通过手机号查询: ident_type="mobile", ident_id="13800138000"
            3. 通过动态码查询: ident_type="dynamicCode", ident_id="56#123456#"
            """
        )
        async def get_member_info(
            ident_type: str,
            ident_id: str
        ) -> str:
            """
            查询会员信息
            
            Args:
                ident_type: 身份识别类型 (memberId/mobile/dynamicCode)
                ident_id: 身份识别码
                
            Returns:
                JSON格式的会员信息
            """
            try:
                # 验证 ident_type
                valid_types = ["memberId", "mobile", "dynamicCode"]
                if ident_type not in valid_types:
                    return json.dumps({
                        "success": False,
                        "error": f"Invalid ident_type: {ident_type}",
                        "message": f"ident_type must be one of: {', '.join(valid_types)}"
                    }, ensure_ascii=False)
                
                # 构建请求体（匹配Java SaasGetMemberReq结构）
                body = {
                    "partnerId": self.config.open_platform.signature.partner_id,
                    "ident": {
                        "type": ident_type,
                        "id": ident_id
                    }
                }
                
                logger.info(f"Querying member info: type={ident_type}, id={ident_id}")
                
                # 调用API
                response = await self.client.post(
                    "/opencenter/customer/member/getMember",
                    body=body
                )
                
                return json.dumps(response, ensure_ascii=False, indent=2)
                
            except Exception as e:
                logger.error(f"Failed to get member info: {str(e)}")
                return json.dumps({
                    "success": False,
                    "error": str(e),
                    "message": "Failed to query member information"
                }, ensure_ascii=False)
        
        # Tool 2: 会员储值卡退款
        @self.mcp.tool(
            name="svc_refund",
            description="""
            会员储值卡退款。
            
            对应Java接口: SaasMemberSvcClient.svcRefund()
            API路径: POST /opencenter/mam/member/svc/refund
            
            示例:
            fpid: "FP001"
            out_order_no: "OUT123456"
            refund_trade_no: "REFUND789"
            refund_amount: 10000  (单位：分，10000=100元)
            refund_desc: "客户申请退款"
            """
        )
        async def svc_refund(
            fpid: str,
            out_order_no: str,
            refund_trade_no: str,
            refund_amount: int,
            refund_desc: Optional[str] = None
        ) -> str:
            """
            会员储值卡退款
            
            Args:
                fpid: 门店fpid
                out_order_no: 原外部交易流水号（最大32个字符）
                refund_trade_no: 退款单号（最大32个字符）
                refund_amount: 退款金额（单位：分）
                refund_desc: 退款描述（可选）
                
            Returns:
                JSON格式的退款结果
            """
            try:
                # 验证参数长度
                if len(out_order_no) > 32:
                    return json.dumps({
                        "success": False,
                        "error": "out_order_no too long",
                        "message": "out_order_no must be at most 32 characters"
                    }, ensure_ascii=False)
                
                if len(refund_trade_no) > 32:
                    return json.dumps({
                        "success": False,
                        "error": "refund_trade_no too long",
                        "message": "refund_trade_no must be at most 32 characters"
                    }, ensure_ascii=False)
                
                # 构建请求体（匹配Java SaasSvcRefundReq结构）
                body = {
                    "fpid": fpid,
                    "outOrderNo": out_order_no,
                    "partnerId": self.config.open_platform.signature.partner_id,
                    "refundAmount": refund_amount,
                    "refundTradeNo": refund_trade_no
                }
                
                # 添加可选字段
                if refund_desc:
                    body["refundDesc"] = refund_desc
                
                logger.info(f"Processing SVC refund: fpid={fpid}, amount={refund_amount}")
                
                # 调用API
                response = await self.client.post(
                    "/opencenter/mam/member/svc/refund",
                    body=body
                )
                
                return json.dumps(response, ensure_ascii=False, indent=2)
                
            except Exception as e:
                logger.error(f"Failed to process SVC refund: {str(e)}")
                return json.dumps({
                    "success": False,
                    "error": str(e),
                    "message": "Failed to process SVC refund"
                }, ensure_ascii=False)
        
        # Tool 2: 会员储值卡退款
        @self.mcp.tool(
            name="svc_refund",
            description="""
            会员储值卡退款。
            
            对应Java接口: SaasMemberSvcClient.svcRefund()
            API路径: POST /opencenter/mam/member/svc/refund
            
            示例:
            fpid: "FP001"
            out_order_no: "OUT123456"
            refund_trade_no: "REFUND789"
            refund_amount: 10000  (单位：分，10000=100元)
            refund_desc: "客户申请退款"
            """
        )
        async def svc_refund(
            fpid: str,
            out_order_no: str,
            refund_trade_no: str,
            refund_amount: int,
            refund_desc: Optional[str] = None
        ) -> str:
            """
            会员储值卡退款
            
            Args:
                fpid: 门店fpid
                out_order_no: 原外部交易流水号（最大32个字符）
                refund_trade_no: 退款单号（最大32个字符）
                refund_amount: 退款金额（单位：分）
                refund_desc: 退款描述（可选）
                
            Returns:
                JSON格式的退款结果
            """
            try:
                # 验证参数长度
                if len(out_order_no) > 32:
                    return json.dumps({
                        "success": False,
                        "error": "out_order_no too long",
                        "message": "out_order_no must be at most 32 characters"
                    }, ensure_ascii=False)
                
                if len(refund_trade_no) > 32:
                    return json.dumps({
                        "success": False,
                        "error": "refund_trade_no too long",
                        "message": "refund_trade_no must be at most 32 characters"
                    }, ensure_ascii=False)
                
                # 构建请求体（匹配Java SaasSvcRefundReq结构）
                body = {
                    "fpid": fpid,
                    "outOrderNo": out_order_no,
                    "partnerId": self.config.open_platform.signature.partner_id,
                    "refundAmount": refund_amount,
                    "refundTradeNo": refund_trade_no
                }
                
                # 添加可选字段
                if refund_desc:
                    body["refundDesc"] = refund_desc
                
                logger.info(f"Processing SVC refund: fpid={fpid}, amount={refund_amount}")
                
                # 调用API
                response = await self.client.post(
                    "/opencenter/mam/member/svc/refund",
                    body=body
                )
                
                return json.dumps(response, ensure_ascii=False, indent=2)
                
            except Exception as e:
                logger.error(f"Failed to process SVC refund: {str(e)}")
                return json.dumps({
                    "success": False,
                    "error": str(e),
                    "message": "Failed to process SVC refund"
                }, ensure_ascii=False)
        
        # Tool 2: 会员储值卡退款
        @self.mcp.tool(
            name="svc_refund",
            description="""
            会员储值卡退款。
            
            对应Java接口: SaasMemberSvcClient.svcRefund()
            API路径: POST /opencenter/mam/member/svc/refund
            
            示例:
            fpid: "FP001"
            out_order_no: "OUT123456"
            refund_trade_no: "REFUND789"
            refund_amount: 10000  (单位：分，10000=100元)
            refund_desc: "客户申请退款"
            """
        )
        async def svc_refund(
            fpid: str,
            out_order_no: str,
            refund_trade_no: str,
            refund_amount: int,
            refund_desc: Optional[str] = None
        ) -> str:
            """
            会员储值卡退款
            
            Args:
                fpid: 门店fpid
                out_order_no: 原外部交易流水号（最大32个字符）
                refund_trade_no: 退款单号（最大32个字符）
                refund_amount: 退款金额（单位：分）
                refund_desc: 退款描述（可选）
                
            Returns:
                JSON格式的退款结果
            """
            try:
                # 验证参数长度
                if len(out_order_no) > 32:
                    return json.dumps({
                        "success": False,
                        "error": "out_order_no too long",
                        "message": "out_order_no must be at most 32 characters"
                    }, ensure_ascii=False)
                
                if len(refund_trade_no) > 32:
                    return json.dumps({
                        "success": False,
                        "error": "refund_trade_no too long",
                        "message": "refund_trade_no must be at most 32 characters"
                    }, ensure_ascii=False)
                
                # 构建请求体（匹配Java SaasSvcRefundReq结构）
                body = {
                    "fpid": fpid,
                    "outOrderNo": out_order_no,
                    "partnerId": self.config.open_platform.signature.partner_id,
                    "refundAmount": refund_amount,
                    "refundTradeNo": refund_trade_no
                }
                
                # 添加可选字段
                if refund_desc:
                    body["refundDesc"] = refund_desc
                
                logger.info(f"Processing SVC refund: fpid={fpid}, amount={refund_amount}")
                
                # 调用API
                response = await self.client.post(
                    "/opencenter/mam/member/svc/refund",
                    body=body
                )
                
                return json.dumps(response, ensure_ascii=False, indent=2)
                
            except Exception as e:
                logger.error(f"Failed to process SVC refund: {str(e)}")
                return json.dumps({
                    "success": False,
                    "error": str(e),
                    "message": "Failed to process SVC refund"
                }, ensure_ascii=False)
        
        # Tool 2: 会员储值卡退款
        @self.mcp.tool(
            name="svc_refund",
            description="""
            会员储值卡退款。
            
            对应Java接口: SaasMemberSvcClient.svcRefund()
            API路径: POST /opencenter/mam/member/svc/refund
            
            示例:
            fpid: "FP001"
            out_order_no: "OUT123456"
            refund_trade_no: "REFUND789"
            refund_amount: 10000  (单位：分，10000=100元)
            refund_desc: "客户申请退款"
            """
        )
        async def svc_refund(
            fpid: str,
            out_order_no: str,
            refund_trade_no: str,
            refund_amount: int,
            refund_desc: Optional[str] = None
        ) -> str:
            """
            会员储值卡退款
            
            Args:
                fpid: 门店fpid
                out_order_no: 原外部交易流水号（最大32个字符）
                refund_trade_no: 退款单号（最大32个字符）
                refund_amount: 退款金额（单位：分）
                refund_desc: 退款描述（可选）
                
            Returns:
                JSON格式的退款结果
            """
            try:
                # 验证参数长度
                if len(out_order_no) > 32:
                    return json.dumps({
                        "success": False,
                        "error": "out_order_no too long",
                        "message": "out_order_no must be at most 32 characters"
                    }, ensure_ascii=False)
                
                if len(refund_trade_no) > 32:
                    return json.dumps({
                        "success": False,
                        "error": "refund_trade_no too long",
                        "message": "refund_trade_no must be at most 32 characters"
                    }, ensure_ascii=False)
                
                # 构建请求体（匹配Java SaasSvcRefundReq结构）
                body = {
                    "fpid": fpid,
                    "outOrderNo": out_order_no,
                    "partnerId": self.config.open_platform.signature.partner_id,
                    "refundAmount": refund_amount,
                    "refundTradeNo": refund_trade_no
                }
                
                # 添加可选字段
                if refund_desc:
                    body["refundDesc"] = refund_desc
                
                logger.info(f"Processing SVC refund: fpid={fpid}, amount={refund_amount}")
                
                # 调用API
                response = await self.client.post(
                    "/opencenter/mam/member/svc/refund",
                    body=body
                )
                
                return json.dumps(response, ensure_ascii=False, indent=2)
                
            except Exception as e:
                logger.error(f"Failed to process SVC refund: {str(e)}")
                return json.dumps({
                    "success": False,
                    "error": str(e),
                    "message": "Failed to process SVC refund"
                }, ensure_ascii=False)
    
    def run(self, transport: str = "stdio"):
        """
        Run the MCP server
        
        Args:
            transport: Transport protocol (stdio or sse)
        """
        logger.info(f"Starting MCP server with transport: {transport}")
        self.mcp.run(transport=transport)
    
    async def cleanup(self):
        """Cleanup resources"""
        await self.client.close()


def main():
    """Main entry point for the MCP adapter"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Subway Open Platform MCP Adapter")
    parser.add_argument(
        "--config",
        type=str,
        default=None,
        help="Path to YAML configuration file"
    )
    parser.add_argument(
        "--transport",
        type=str,
        default="stdio",
        choices=["stdio", "sse"],
        help="Transport protocol (default: stdio)"
    )
    
    args = parser.parse_args()
    
    # Load configuration
    config = load_config(args.config)
    
    # Set log level
    logging.getLogger().setLevel(getattr(logging, config.mcp.log_level, logging.INFO))
    
    # Create and run adapter
    adapter = SubwayMCPAdapter(config)
    
    try:
        adapter.run(transport=args.transport)
    except KeyboardInterrupt:
        logger.info("Server stopped by user")
    finally:
        import asyncio
        asyncio.run(adapter.cleanup())


if __name__ == "__main__":
    main()
