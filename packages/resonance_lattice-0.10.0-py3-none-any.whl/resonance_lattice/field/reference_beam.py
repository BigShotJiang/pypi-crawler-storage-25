"""Asymmetric reference beam field (Direction C).

Separates source identity from content by storing asymmetric outer products:
    F += r_i (x) phi_i    (instead of phi_i (x) phi_i)

Where r_i is a source-specific reference beam — a near-orthogonal vector
that acts as an "address" for the source in the field.

This decorrelates retrieval from content similarity. Even when all sources
have identical content vectors, they remain distinguishable via their
reference beams.

Storage: B * D^2 (same as dense field) + reference vectors.
Capacity: O(D) independent of corpus correlation.
Query cost: O(B * D^2) + O(N * D) for source identification.
"""

from __future__ import annotations

from typing import NamedTuple

import numpy as np
from numpy.typing import NDArray


class RefBeamResult(NamedTuple):
    """Result of reference beam retrieval."""
    resonance_vectors: NDArray  # (B, D) — per-band resonance (in reference space)
    fused: NDArray              # (D,) — weighted sum
    band_energies: NDArray      # (B,)
    source_scores: NDArray      # (N,) — per-source identification scores


class ReferenceBeamField:
    """Asymmetric field with reference beams for source identification.

    Reference beams can be:
    1. Random orthogonal (from QR decomposition)
    2. Deterministic hash-based (from source IDs)
    3. Learned (future: small MLP trained jointly with field loss)

    This implementation uses random orthogonal beams (up to D beams)
    and random near-orthogonal beams beyond D.
    """

    def __init__(
        self,
        bands: int,
        dim: int,
        ref_mode: str = "orthogonal",
        dtype: np.dtype = np.float32,
    ) -> None:
        """
        Args:
            bands: Number of bands B.
            dim: Dimensionality D.
            ref_mode: "orthogonal" (QR-based) or "random" (i.i.d. Gaussian).
            dtype: NumPy dtype.
        """
        self.bands = bands
        self.dim = dim
        self.ref_mode = ref_mode
        self.dtype = dtype

        # Field tensor: (B, D, D)
        self.F: NDArray = np.zeros((bands, dim, dim), dtype=dtype)
        # Reference beams: list of (D,) vectors, one per source
        self.refs: list[NDArray] = []
        self._source_count = 0
        self._rng = np.random.default_rng(42)

        # Pre-generate orthogonal basis (up to D vectors)
        if ref_mode == "orthogonal":
            self._ortho_basis = self._generate_orthogonal_basis()
        else:
            self._ortho_basis = None

    def _generate_orthogonal_basis(self) -> NDArray:
        """Generate D orthogonal unit vectors via QR decomposition."""
        A = self._rng.standard_normal((self.dim, self.dim)).astype(self.dtype)
        Q, _ = np.linalg.qr(A)
        return Q  # (D, D) — columns are orthonormal

    def _get_reference_beam(self, source_idx: int) -> NDArray:
        """Get or generate reference beam for a source.

        For orthogonal mode: uses pre-computed orthogonal basis (cyclic for N > D).
        For random mode: generates random unit vector.
        """
        if self.ref_mode == "orthogonal" and self._ortho_basis is not None:
            # Cycle through orthogonal basis if N > D
            return self._ortho_basis[:, source_idx % self.dim].copy()
        else:
            r = self._rng.standard_normal(self.dim).astype(self.dtype)
            r /= np.linalg.norm(r) + 1e-12
            return r

    @property
    def source_count(self) -> int:
        return self._source_count

    @property
    def size_bytes(self) -> int:
        base = self.F.nbytes
        if self.refs:
            base += sum(r.nbytes for r in self.refs)
        return base

    @property
    def size_mb(self) -> float:
        return self.size_bytes / (1024 * 1024)

    def superpose(
        self,
        phase_vectors: NDArray,
        salience: float = 1.0,
        source_idx: int | None = None,
    ) -> None:
        """Add a source with asymmetric outer product: F += r_i (x) phi_i.

        Args:
            phase_vectors: Shape (B, D) — content phase vectors.
            salience: Weight.
            source_idx: Override index for reference beam selection.
        """
        idx = source_idx if source_idx is not None else self._source_count
        ref = self._get_reference_beam(idx)
        self.refs.append(ref)

        for b in range(self.bands):
            phi = phase_vectors[b]
            self.F[b] += salience * np.outer(ref, phi)

        self._source_count += 1

    def superpose_batch(
        self,
        phase_batch: NDArray,
        saliences: NDArray | None = None,
    ) -> None:
        """Add multiple sources.

        Args:
            phase_batch: Shape (N, B, D).
            saliences: Shape (N,) or None.
        """
        N = phase_batch.shape[0]
        for i in range(N):
            s = saliences[i] if saliences is not None else 1.0
            self.superpose(phase_batch[i], salience=s)

    def remove(
        self,
        phase_vectors: NDArray,
        source_idx: int,
        salience: float = 1.0,
    ) -> None:
        """Remove a source. Requires the original source_idx for reference beam.

        Args:
            phase_vectors: Shape (B, D).
            source_idx: Index used during superpose.
            salience: Same weight used during superpose.
        """
        ref = self.refs[source_idx]
        for b in range(self.bands):
            phi = phase_vectors[b]
            self.F[b] -= salience * np.outer(ref, phi)

        self._source_count -= 1

    def resonate(
        self,
        query_phase: NDArray,
        band_weights: NDArray | None = None,
    ) -> RefBeamResult:
        """Retrieve via asymmetric field and score all sources by reference beam match.

        response = F @ q = sum_i r_i * <phi_i, q>
        score_i = <r_i, response> = <phi_i, q> + cross-talk

        Args:
            query_phase: Shape (B, D).
            band_weights: Shape (B,) for fusion.

        Returns:
            RefBeamResult with per-source identification scores.
        """
        B = self.bands
        D = self.dim

        if band_weights is None:
            band_weights = np.ones(B, dtype=self.dtype) / B

        resonance = np.zeros((B, D), dtype=self.dtype)
        band_energies = np.zeros(B, dtype=self.dtype)

        for b in range(B):
            r_b = self.F[b] @ query_phase[b]
            resonance[b] = r_b
            band_energies[b] = np.linalg.norm(r_b)

        # Fuse across bands
        fused = np.zeros(D, dtype=self.dtype)
        for b in range(B):
            fused += band_weights[b] * resonance[b]

        # Score each source by reference beam dot product
        if self.refs:
            ref_matrix = np.stack(self.refs)  # (N, D)
            source_scores = ref_matrix @ fused  # (N,)
        else:
            source_scores = np.array([], dtype=self.dtype)

        return RefBeamResult(
            resonance_vectors=resonance,
            fused=fused,
            band_energies=band_energies,
            source_scores=source_scores,
        )

    def retrieve_topk(
        self,
        query_phase: NDArray,
        all_phases: NDArray | None = None,
        top_k: int = 10,
    ) -> tuple[NDArray, NDArray]:
        """Retrieve top-k sources by reference beam matching.

        Unlike the linear field, this uses reference beam scores (not content
        similarity) for source identification.

        Args:
            query_phase: Shape (B, D).
            all_phases: Unused (identification is via reference beams).
            top_k: Number of results.

        Returns:
            indices, scores.
        """
        result = self.resonate(query_phase)
        scores = result.source_scores

        top_idx = np.argsort(scores)[::-1][:top_k]
        return top_idx, scores[top_idx]
