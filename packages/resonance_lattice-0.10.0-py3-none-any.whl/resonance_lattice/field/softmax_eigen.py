"""Softmax-over-eigenspectrum field (Direction A).

Compresses the dense field into its top-K eigenvectors per band, then
retrieves via softmax attention over the eigenspectrum. This introduces
non-linear competition between eigenmodes, suppressing the corpus common
mode and amplifying discriminative modes.

Storage: B * K * (D + 1) instead of B * D^2.
Capacity: O(K * D) — quadratic when K = O(D).
Query cost: O(B * K * D) — faster than dense field when K < D.
"""

from __future__ import annotations

from typing import NamedTuple

import numpy as np
from numpy.typing import NDArray


class SoftmaxEigenResult(NamedTuple):
    """Result of softmax-eigen retrieval."""
    resonance_vectors: NDArray  # (B, D) per-band resonance
    fused: NDArray              # (D,) weighted sum across bands
    band_energies: NDArray      # (B,) energy per band
    slot_weights: NDArray       # (B, K) softmax weights per band (diagnostic)


class SoftmaxEigenField:
    """Non-linear field using eigendecomposition + softmax retrieval.

    Can be built from:
    1. A dense field tensor (compress existing field)
    2. Raw phase vectors (compute covariance then eigendecompose)

    Retrieval:
        scores_k = <v_k, q>                    for k = 1..K
        weights  = softmax(scores / tau)
        r_b      = sum_k weights_k * lambda_k * v_k
    """

    def __init__(
        self,
        bands: int,
        dim: int,
        n_slots: int = 64,
        tau: float = 1.0,
        dtype: np.dtype = np.float32,
    ) -> None:
        self.bands = bands
        self.dim = dim
        self.n_slots = n_slots
        self.tau = tau
        self.dtype = dtype

        # Eigenvectors and eigenvalues per band
        self.V: NDArray | None = None  # (B, D, K)
        self.Lambda: NDArray | None = None  # (B, K)

        # Optional: keep the full field for incremental updates
        self._full_field: NDArray | None = None
        self._source_count = 0
        self._dirty = False  # True when field updated but eigens not recomputed

    @property
    def source_count(self) -> int:
        return self._source_count

    @property
    def size_bytes(self) -> int:
        if self.V is not None:
            return self.V.nbytes + self.Lambda.nbytes
        return 0

    @property
    def size_mb(self) -> float:
        return self.size_bytes / (1024 * 1024)

    def build_from_field(self, field_tensor: NDArray) -> None:
        """Compress a dense field tensor into top-K eigenvectors.

        Args:
            field_tensor: Shape (B, D, D) — the dense field.
        """
        B, D, _ = field_tensor.shape
        assert B == self.bands and D == self.dim
        K = min(self.n_slots, D)

        self.V = np.zeros((B, D, K), dtype=self.dtype)
        self.Lambda = np.zeros((B, K), dtype=self.dtype)

        for b in range(B):
            # Symmetric eigendecomposition (ascending order)
            eigvals, eigvecs = np.linalg.eigh(field_tensor[b])
            # Take top-K (largest eigenvalues)
            self.V[b] = eigvecs[:, -K:][:, ::-1]  # (D, K) descending
            self.Lambda[b] = eigvals[-K:][::-1]     # (K,) descending

        # Keep full field for incremental updates
        self._full_field = field_tensor.copy()
        self._dirty = False

    def build_from_phases(self, phase_batch: NDArray) -> None:
        """Build field from raw phase vectors, then eigendecompose.

        Args:
            phase_batch: Shape (N, B, D) — all source phase vectors.
        """
        N, B, D = phase_batch.shape
        assert B == self.bands and D == self.dim

        # Build dense field: F_b = X_b^T @ X_b
        field = np.zeros((B, D, D), dtype=self.dtype)
        for b in range(B):
            X = phase_batch[:, b, :]  # (N, D)
            field[b] = X.T @ X

        self._source_count = N
        self.build_from_field(field)

    def superpose(self, phase_vectors: NDArray, salience: float = 1.0) -> None:
        """Add a source and mark eigenvectors as stale.

        Args:
            phase_vectors: Shape (B, D).
            salience: Weight.
        """
        if self._full_field is None:
            self._full_field = np.zeros(
                (self.bands, self.dim, self.dim), dtype=self.dtype
            )

        for b in range(self.bands):
            phi = phase_vectors[b]
            self._full_field[b] += salience * np.outer(phi, phi)

        self._source_count += 1
        self._dirty = True

    def recompute_eigens(self) -> None:
        """Recompute eigendecomposition from the full field."""
        if self._full_field is not None:
            self.build_from_field(self._full_field)

    def resonate(
        self,
        query_phase: NDArray,
        band_weights: NDArray | None = None,
    ) -> SoftmaxEigenResult:
        """Non-linear retrieval via softmax over eigenspectrum.

        Args:
            query_phase: Shape (B, D).
            band_weights: Shape (B,) for multi-band fusion.

        Returns:
            SoftmaxEigenResult with resonance vectors and diagnostics.
        """
        if self._dirty:
            self.recompute_eigens()

        if self.V is None:
            raise RuntimeError("Field not built. Call build_from_phases or build_from_field first.")

        B, D, K = self.V.shape

        if band_weights is None:
            band_weights = np.ones(B, dtype=self.dtype) / B

        resonance = np.zeros((B, D), dtype=self.dtype)
        band_energies = np.zeros(B, dtype=self.dtype)
        all_weights = np.zeros((B, K), dtype=self.dtype)

        for b in range(B):
            v = self.V[b]         # (D, K)
            lam = self.Lambda[b]  # (K,)
            q = query_phase[b]    # (D,)

            # Project query onto eigenvectors
            scores = v.T @ q  # (K,) — dot product with each eigenvector

            # Softmax with temperature
            scores_scaled = scores / self.tau
            scores_scaled -= scores_scaled.max()  # Numerical stability
            exp_scores = np.exp(scores_scaled)
            weights = exp_scores / (exp_scores.sum() + 1e-12)

            all_weights[b] = weights

            # Weighted combination of eigenvectors (weighted by eigenvalue AND softmax)
            r_b = v @ (weights * lam)  # (D,)
            resonance[b] = r_b
            band_energies[b] = np.linalg.norm(r_b)

        # Multi-band fusion
        fused = np.zeros(D, dtype=self.dtype)
        for b in range(B):
            fused += band_weights[b] * resonance[b]

        return SoftmaxEigenResult(
            resonance_vectors=resonance,
            fused=fused,
            band_energies=band_energies,
            slot_weights=all_weights,
        )

    def retrieve_topk(
        self,
        query_phase: NDArray,
        all_phases: NDArray,
        top_k: int = 10,
    ) -> tuple[NDArray, NDArray]:
        """Full retrieval pipeline: resonate then match against all sources.

        Args:
            query_phase: Shape (B, D).
            all_phases: Shape (N, B, D) — all source phase vectors.
            top_k: Number of results.

        Returns:
            indices: Shape (top_k,) — indices of top sources.
            scores: Shape (top_k,) — similarity scores.
        """
        result = self.resonate(query_phase)
        fused = result.fused  # (D,)

        # Score all sources by cosine similarity with fused resonance
        all_phases.shape[0]
        # Fuse source phases too (uniform band weights)
        source_fused = np.mean(all_phases, axis=1)  # (N, D)

        scores = source_fused @ fused  # (N,)
        top_idx = np.argsort(scores)[::-1][:top_k]

        return top_idx, scores[top_idx]
