"""Tucker-factored cubic field (Direction B).

Higher-order tensor field that stores rank-1 order-3 tensor products:
    T += phi (x) phi (x) phi

Retrieval contracts two indices with the query (quadratic non-linearity):
    r_j = sum_{k,l} T_{jkl} * q_k * q_l

The full cubic tensor (D^3) is impractical, so we use Tucker decomposition:
    T = G x_1 U x_2 U x_3 U
where G in R^{R x R x R} and U in R^{D x R}.

Storage: B * (R^3 + D*R) instead of B * D^3.
Capacity: O(R^2 / s^4) — quadratic in Tucker rank.
Query cost: O(B * (D*R + R^3)).
"""

from __future__ import annotations

from typing import NamedTuple

import numpy as np
from numpy.typing import NDArray


class CubicResult(NamedTuple):
    """Result of cubic field retrieval."""
    resonance_vectors: NDArray  # (B, D)
    fused: NDArray              # (D,)
    band_energies: NDArray      # (B,)


class TuckerCubicField:
    """Tucker-factored cubic interference field.

    The factor matrix U is calibrated from a representative corpus sample.
    After calibration, sources are superposed into the core tensor G in
    the compressed R-dimensional space. Retrieval contracts two indices
    of G with the projected query.

    Build process:
    1. Calibrate U from corpus sample (SVD of stacked phase vectors)
    2. Superpose sources: G += u_i (x) u_i (x) u_i where u_i = U^T phi_i
    3. Retrieve: project query, contract with G, project back
    """

    def __init__(
        self,
        bands: int,
        dim: int,
        rank: int = 64,
        dtype: np.dtype = np.float32,
    ) -> None:
        self.bands = bands
        self.dim = dim
        self.rank = rank
        self.dtype = dtype

        # Factor matrix per band: (B, D, R)
        self.U: NDArray | None = None
        # Core tensor per band: (B, R, R, R)
        self.G: NDArray | None = None
        self._source_count = 0

    @property
    def source_count(self) -> int:
        return self._source_count

    @property
    def size_bytes(self) -> int:
        total = 0
        if self.U is not None:
            total += self.U.nbytes
        if self.G is not None:
            total += self.G.nbytes
        return total

    @property
    def size_mb(self) -> float:
        return self.size_bytes / (1024 * 1024)

    def calibrate(self, phase_sample: NDArray) -> None:
        """Calibrate factor matrices U from a corpus sample.

        Computes the top-R right singular vectors of the stacked phase
        vectors per band. These form the optimal projection basis.

        Args:
            phase_sample: Shape (N_sample, B, D) — representative sample.
        """
        N, B, D = phase_sample.shape
        assert B == self.bands and D == self.dim
        R = min(self.rank, D, N)

        self.U = np.zeros((B, D, R), dtype=self.dtype)

        for b in range(B):
            X = phase_sample[:, b, :]  # (N, D)
            # SVD: X = U_svd @ S @ Vt
            # Top-R right singular vectors = columns of V = rows of Vt
            _, _, Vt = np.linalg.svd(X, full_matrices=False)
            self.U[b] = Vt[:R].T  # (D, R)

        # Initialise core tensor
        self.G = np.zeros((B, R, R, R), dtype=self.dtype)
        self._source_count = 0

    def superpose(self, phase_vectors: NDArray, salience: float = 1.0) -> None:
        """Add a source to the cubic field.

        Projects to compressed space and adds rank-1 order-3 update to G.

        Args:
            phase_vectors: Shape (B, D).
            salience: Weight.
        """
        if self.U is None:
            raise RuntimeError("Must calibrate before superposing.")

        for b in range(self.bands):
            u = self.U[b].T @ phase_vectors[b]  # (R,) — project to compressed space
            # Rank-1 order-3 update: G += salience * u (x) u (x) u
            self.G[b] += salience * np.einsum("i,j,k->ijk", u, u, u)

        self._source_count += 1

    def superpose_batch(self, phase_batch: NDArray, saliences: NDArray | None = None) -> None:
        """Add multiple sources efficiently.

        Args:
            phase_batch: Shape (N, B, D).
            saliences: Shape (N,) or None.
        """
        if self.U is None:
            raise RuntimeError("Must calibrate before superposing.")

        N = phase_batch.shape[0]

        for b in range(self.bands):
            # Project all sources: (N, D) @ (D, R) -> (N, R)
            U_b = phase_batch[:, b, :] @ self.U[b]  # (N, R)

            if saliences is not None:
                U_b = U_b * saliences[:, np.newaxis]

            # Accumulate rank-1 order-3 updates
            # G_b += sum_i u_i (x) u_i (x) u_i
            for i in range(N):
                u = U_b[i]
                self.G[b] += np.einsum("i,j,k->ijk", u, u, u)

        self._source_count += N

    def remove(self, phase_vectors: NDArray, salience: float = 1.0) -> None:
        """Remove a source from the cubic field.

        Args:
            phase_vectors: Shape (B, D).
            salience: Weight (same as used in superpose).
        """
        if self.U is None:
            raise RuntimeError("Must calibrate before removing.")

        for b in range(self.bands):
            u = self.U[b].T @ phase_vectors[b]
            self.G[b] -= salience * np.einsum("i,j,k->ijk", u, u, u)

        self._source_count -= 1

    def resonate(
        self,
        query_phase: NDArray,
        band_weights: NDArray | None = None,
    ) -> CubicResult:
        """Non-linear retrieval via cubic contraction.

        r = U @ G(., u_q, u_q) where u_q = U^T @ q

        The quadratic dependence on q provides non-linear competition.

        Args:
            query_phase: Shape (B, D).
            band_weights: Shape (B,) for multi-band fusion.

        Returns:
            CubicResult with resonance vectors.
        """
        if self.U is None or self.G is None:
            raise RuntimeError("Field not built.")

        B = self.bands
        D = self.dim

        if band_weights is None:
            band_weights = np.ones(B, dtype=self.dtype) / B

        resonance = np.zeros((B, D), dtype=self.dtype)
        band_energies = np.zeros(B, dtype=self.dtype)

        for b in range(B):
            u_q = self.U[b].T @ query_phase[b]  # (R,) — project query

            # Contract indices 2 and 3 with u_q:
            # g_j = sum_{k,l} G[b, j, k, l] * u_q[k] * u_q[l]
            g = np.einsum("jkl,k,l->j", self.G[b], u_q, u_q)  # (R,)

            # Project back to full space
            r_b = self.U[b] @ g  # (D,)
            resonance[b] = r_b
            band_energies[b] = np.linalg.norm(r_b)

        # Multi-band fusion
        fused = np.zeros(D, dtype=self.dtype)
        for b in range(B):
            fused += band_weights[b] * resonance[b]

        return CubicResult(
            resonance_vectors=resonance,
            fused=fused,
            band_energies=band_energies,
        )

    def retrieve_topk(
        self,
        query_phase: NDArray,
        all_phases: NDArray,
        top_k: int = 10,
    ) -> tuple[NDArray, NDArray]:
        """Full retrieval: resonate then match against sources.

        Args:
            query_phase: Shape (B, D).
            all_phases: Shape (N, B, D).
            top_k: Number of results.

        Returns:
            indices, scores.
        """
        result = self.resonate(query_phase)
        fused = result.fused

        source_fused = np.mean(all_phases, axis=1)  # (N, D)
        scores = source_fused @ fused
        top_idx = np.argsort(scores)[::-1][:top_k]

        return top_idx, scores[top_idx]
