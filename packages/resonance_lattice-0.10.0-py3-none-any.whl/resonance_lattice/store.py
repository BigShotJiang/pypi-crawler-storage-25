"""Source Store — multi-resolution content storage for materialisation.

Stores the actual content that gets materialised after resonance identifies
bright spots. Content is stored at multiple resolutions:
  - Summary text (for Omega_1-2 landscape materialisation)
  - Relation triples (for Omega_3 structural materialisation)
  - Full text (for Omega_4-5 evidence materialisation)
  - Metadata (timestamp, source URI, authority, etc.)

Backed by SQLite for simplicity and portability.
"""

from __future__ import annotations

import csv
import json
import sqlite3
from pathlib import Path
from typing import Any


class SourceContent:
    """Multi-resolution content for a single source.

    Relations and metadata use lazy JSON deserialization — the raw JSON
    strings are stored and only parsed on first access.  This avoids
    ``json.loads`` overhead during batch retrieval when callers only
    need ``summary`` or ``full_text``.
    """

    __slots__ = (
        "source_id", "summary", "full_text",
        "_relations", "_metadata", "_relations_json", "_metadata_json",
    )

    def __init__(
        self,
        source_id: str,
        summary: str = "",
        relations: list[tuple[str, str, str]] | None = None,
        full_text: str = "",
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self.source_id = source_id
        self.summary = summary
        self.full_text = full_text
        self._relations = relations
        self._metadata = metadata
        self._relations_json = json.dumps(relations) if relations is not None else "[]"
        self._metadata_json = json.dumps(metadata) if metadata is not None else "{}"

    @property
    def relations(self) -> list[tuple[str, str, str]]:
        if self._relations is None:
            self._relations = [tuple(r) for r in json.loads(self._relations_json)]
        return self._relations

    @relations.setter
    def relations(self, value: list[tuple[str, str, str]]) -> None:
        self._relations = value
        self._relations_json = json.dumps(value)

    @property
    def metadata(self) -> dict[str, Any]:
        if self._metadata is None:
            self._metadata = json.loads(self._metadata_json)
        return self._metadata

    @metadata.setter
    def metadata(self, value: dict[str, Any]) -> None:
        self._metadata = value
        self._metadata_json = json.dumps(value)

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_id": self.source_id,
            "summary": self.summary,
            "relations": self.relations,
            "full_text": self.full_text,
            "metadata": self.metadata,
        }

    def __repr__(self) -> str:
        return f"SourceContent(source_id={self.source_id!r}, summary={self.summary[:50]!r}...)"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SourceContent:
        return cls(
            source_id=data["source_id"],
            summary=data.get("summary", ""),
            relations=[tuple(r) for r in data.get("relations", [])],
            full_text=data.get("full_text", ""),
            metadata=data.get("metadata", {}),
        )

    @classmethod
    def _from_row(
        cls, source_id: str, summary: str,
        relations_json: str, full_text: str, metadata_json: str,
    ) -> SourceContent:
        """Fast constructor from a SQLite row — defers JSON parsing."""
        obj = cls.__new__(cls)
        obj.source_id = source_id
        obj.summary = summary
        obj.full_text = full_text
        obj._relations = None
        obj._metadata = None
        obj._relations_json = relations_json
        obj._metadata_json = metadata_json
        return obj


class SourceStore:
    """SQLite-backed multi-resolution source content store.

    Includes a read-through LRU cache for frequently accessed sources
    and SQLite memory-mapping for zero-copy reads.
    """

    _CACHE_SIZE = 512

    def __init__(self, path: str | Path = ":memory:") -> None:
        """
        Args:
            path: Path to SQLite database file, or ":memory:" for in-memory.
        """
        self.path = str(path)
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA mmap_size=268435456")  # 256 MB mmap
        self._create_tables()
        self._cache: dict[str, SourceContent] = {}

    def _create_tables(self) -> None:
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS sources (
                source_id TEXT PRIMARY KEY,
                summary TEXT NOT NULL DEFAULT '',
                relations TEXT NOT NULL DEFAULT '[]',
                full_text TEXT NOT NULL DEFAULT '',
                metadata TEXT NOT NULL DEFAULT '{}'
            )
        """)
        self._conn.commit()

    @property
    def count(self) -> int:
        cursor = self._conn.execute("SELECT COUNT(*) FROM sources")
        return cursor.fetchone()[0]

    def store(self, content: SourceContent) -> None:
        """Store or update source content.

        Args:
            content: The multi-resolution content to store.
        """
        self._conn.execute(
            """INSERT OR REPLACE INTO sources (source_id, summary, relations, full_text, metadata)
               VALUES (?, ?, ?, ?, ?)""",
            (
                content.source_id,
                content.summary,
                json.dumps(content.relations),
                content.full_text,
                json.dumps(content.metadata),
            ),
        )
        self._conn.commit()
        self._cache.pop(content.source_id, None)

    def store_batch(self, contents: list[SourceContent]) -> None:
        """Store multiple sources in a single transaction."""
        self._conn.executemany(
            """INSERT OR REPLACE INTO sources (source_id, summary, relations, full_text, metadata)
               VALUES (?, ?, ?, ?, ?)""",
            [
                (
                    c.source_id,
                    c.summary,
                    json.dumps(c.relations),
                    c.full_text,
                    json.dumps(c.metadata),
                )
                for c in contents
            ],
        )
        self._conn.commit()

    def _evict_if_full(self) -> None:
        """Evict oldest entries if cache is over capacity."""
        while len(self._cache) > self._CACHE_SIZE:
            # dict preserves insertion order; pop the first key
            self._cache.pop(next(iter(self._cache)))

    def retrieve(self, source_id: str) -> SourceContent | None:
        """Retrieve content for a source.

        Args:
            source_id: The source identifier.

        Returns:
            SourceContent or None if not found.
        """
        cached = self._cache.get(source_id)
        if cached is not None:
            return cached

        cursor = self._conn.execute(
            "SELECT source_id, summary, relations, full_text, metadata FROM sources WHERE source_id = ?",
            (source_id,),
        )
        row = cursor.fetchone()
        if row is None:
            return None
        content = SourceContent._from_row(row[0], row[1], row[2], row[3], row[4])
        self._cache[source_id] = content
        self._evict_if_full()
        return content

    def retrieve_batch(self, source_ids: list[str]) -> list[SourceContent]:
        """Retrieve content for multiple sources (cache-aware)."""
        if not source_ids:
            return []

        results = []
        missing = []
        for sid in source_ids:
            cached = self._cache.get(sid)
            if cached is not None:
                results.append(cached)
            else:
                missing.append(sid)

        if missing:
            placeholders = ",".join("?" for _ in missing)
            cursor = self._conn.execute(
                f"SELECT source_id, summary, relations, full_text, metadata FROM sources WHERE source_id IN ({placeholders})",
                missing,
            )
            for row in cursor:
                content = SourceContent._from_row(row[0], row[1], row[2], row[3], row[4])
                self._cache[row[0]] = content
                results.append(content)
            self._evict_if_full()

        return results

    def remove(self, source_id: str) -> bool:
        """Remove a source from the store.

        Returns:
            True if the source existed and was removed.
        """
        cursor = self._conn.execute(
            "DELETE FROM sources WHERE source_id = ?", (source_id,)
        )
        self._conn.commit()
        self._cache.pop(source_id, None)
        return cursor.rowcount > 0

    def all_ids(self) -> list[str]:
        """Return all source IDs in the store."""
        cursor = self._conn.execute("SELECT source_id FROM sources")
        return [row[0] for row in cursor]

    def to_bytes(self) -> bytes:
        """Serialise the store to bytes for .rlat persistence.

        Uses SQLite binary backup for compact output and fast restore.
        The result starts with the SQLite file header ("SQLite format 3\\0").
        """
        import os
        import tempfile

        # Write to a temp file via backup(), then read the raw bytes
        fd, tmp_path = tempfile.mkstemp(suffix=".sqlite")
        try:
            os.close(fd)
            target = sqlite3.connect(tmp_path)
            self._conn.backup(target)
            target.close()
            with open(tmp_path, "rb") as f:
                return f.read()
        finally:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass

    @classmethod
    def from_bytes(cls, data: bytes) -> SourceStore:
        """Deserialise a store from bytes.

        Auto-detects format:
        - Binary SQLite (starts with "SQLite format 3\\0") — new format
        - SQL text dump (starts with "BEGIN"/"CREATE") — legacy format
        """
        store = cls.__new__(cls)
        store.path = ":memory:"
        store._conn = sqlite3.connect(":memory:", check_same_thread=False)
        store._cache = {}

        if not data:
            store._create_tables()
            return store

        # Sniff format: SQLite binary starts with "SQLite format 3\0"
        if data[:16] == b"SQLite format 3\x00":
            # Binary format: write to temp file, backup() into :memory:
            import os
            import tempfile
            fd, tmp_path = tempfile.mkstemp(suffix=".sqlite")
            try:
                os.close(fd)
                with open(tmp_path, "wb") as f:
                    f.write(data)
                source = sqlite3.connect(tmp_path)
                source.backup(store._conn)
                source.close()
            finally:
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
        else:
            # Legacy SQL text dump format
            sql = data.decode("utf-8")
            store._conn.executescript(sql)

        return store

    def close(self) -> None:
        """Close the database connection."""
        self._conn.close()

    def __del__(self) -> None:
        try:
            self._conn.close()
        except Exception:
            pass


class ExternalStore:
    """File-system-backed store that resolves source_ids to local files.

    Works with storeless .rlat cartridges: the field + registry provide
    semantic indexing, while this store reads content from source files
    on disk at query time.

    Source IDs are mapped back to files via a manifest (source_id -> file
    path) saved in the cartridge metadata, or by heuristic filename matching.
    """

    def __init__(
        self,
        source_root: str | Path,
        manifest: dict[str, str] | None = None,
        meta_store: SourceStore | None = None,
    ) -> None:
        """
        Args:
            source_root: Root directory for resolving source files.
            manifest: Optional mapping of source_id -> relative file path.
                Stored in the cartridge as __source_manifest__ when building
                with store_mode="external".
            meta_store: Optional embedded metadata store for __-prefixed
                entries (encoder config, source manifest, profile, etc.).
        """
        self.source_root = Path(source_root).resolve()
        self._manifest = manifest or {}
        self._meta_store: SourceStore | None = meta_store
        self._file_cache: dict[str, str] = {}
        self._chunk_cache: dict[str, list] = {}  # path -> list[Chunk]

    @property
    def count(self) -> int:
        return 0  # External store has no embedded count

    def _resolve_path(self, source_id: str) -> Path | None:
        """Try to resolve a source_id to a file path under source_root."""
        # 1. Use manifest if available (fast O(1) lookup)
        if source_id in self._manifest:
            sf = self._manifest[source_id]
            # Rich manifest entries are dicts with source_file key
            if isinstance(sf, dict):
                sf = sf.get("source_file", "")
            if not sf:
                return None
            candidate = self.source_root / sf
            if candidate.exists():
                return candidate
            # Try the path as-is (absolute)
            p = Path(sf)
            if p.exists():
                return p

        # 2. Heuristic: parse source_id "{stem}_{slug}_{hash}_{idx}"
        #    Only scan direct children to avoid slow rglob on large trees.
        if not self.source_root.exists():
            return None
        parts = source_id.rsplit("_", 2)  # last 2 parts: hash, idx
        if len(parts) >= 3:
            stem_part = parts[0].split("_")[0].lower()
            for f in self.source_root.iterdir():
                if f.is_file() and f.stem.lower() == stem_part:
                    return f

        return None

    def _read_file(self, path: Path) -> str:
        """Read file content, dispatching by extension.

        Text files are read directly. Binary formats (.docx, .pdf, .xlsx)
        use optional dependencies — if missing, a helpful message is returned
        instead of raising.
        """
        ext = path.suffix.lower()

        if ext == ".csv":
            return self._read_csv(path)
        elif ext == ".tsv":
            return self._read_csv(path, delimiter="\t")
        elif ext == ".docx":
            return self._read_docx(path)
        elif ext == ".pdf":
            return self._read_pdf(path)
        elif ext in (".xlsx", ".xls"):
            return self._read_xlsx(path)
        else:
            # Default: read as UTF-8 text (covers .txt, .md, .py, etc.)
            return path.read_text(encoding="utf-8", errors="replace")

    @staticmethod
    def _read_csv(path: Path, delimiter: str = ",") -> str:
        """Read CSV/TSV as pipe-separated text for readability."""
        rows = []
        with open(path, newline="", encoding="utf-8", errors="replace") as f:
            reader = csv.reader(f, delimiter=delimiter)
            for row in reader:
                rows.append(" | ".join(row))
        return "\n".join(rows)

    @staticmethod
    def _read_docx(path: Path) -> str:
        """Read .docx using python-docx (optional dependency)."""
        try:
            from docx import Document
        except ImportError:
            return f"[cannot read {path.name}: pip install python-docx]"
        try:
            doc = Document(str(path))
            return "\n\n".join(p.text for p in doc.paragraphs if p.text.strip())
        except Exception as e:
            return f"[error reading {path.name}: {e}]"

    @staticmethod
    def _read_pdf(path: Path) -> str:
        """Read .pdf using pymupdf or pdfplumber (optional dependency)."""
        # Try pymupdf first (fast), then pdfplumber
        try:
            import fitz  # pymupdf
            doc = fitz.open(str(path))
            pages = [page.get_text() for page in doc]
            doc.close()
            return "\n\n".join(pages)
        except ImportError:
            pass
        except Exception as e:
            return f"[error reading {path.name}: {e}]"
        try:
            import pdfplumber
            with pdfplumber.open(str(path)) as pdf:
                return "\n\n".join(
                    page.extract_text() or "" for page in pdf.pages
                )
        except ImportError:
            return f"[cannot read {path.name}: pip install pymupdf or pdfplumber]"
        except Exception as e:
            return f"[error reading {path.name}: {e}]"

    @staticmethod
    def _read_xlsx(path: Path) -> str:
        """Read .xlsx using openpyxl (optional dependency)."""
        try:
            from openpyxl import load_workbook
        except ImportError:
            return f"[cannot read {path.name}: pip install openpyxl]"
        try:
            wb = load_workbook(str(path), read_only=True, data_only=True)
        except Exception as e:
            return f"[error reading {path.name}: {e}]"
        sheets = []
        for ws in wb.worksheets:
            rows = []
            for row in ws.iter_rows(values_only=True):
                rows.append(" | ".join(str(c) if c is not None else "" for c in row))
            if rows:
                sheets.append(f"## {ws.title}\n" + "\n".join(rows))
        wb.close()
        return "\n\n".join(sheets)

    @staticmethod
    def _parse_chunk_index(source_id: str) -> int | None:
        """Extract chunk index from source_id (last _NNNN segment)."""
        parts = source_id.rsplit("_", 1)
        if len(parts) == 2:
            try:
                return int(parts[1])
            except ValueError:
                pass
        return None

    def _get_chunks(self, path: Path) -> list:
        """Read file and chunk it, caching the result."""
        key = str(path)
        if key not in self._chunk_cache:
            from resonance_lattice.chunker import auto_chunk
            if key not in self._file_cache:
                self._file_cache[key] = self._read_file(path)
            self._chunk_cache[key] = auto_chunk(
                self._file_cache[key], source_file=str(path),
            )
        return self._chunk_cache[key]

    def retrieve(self, source_id: str) -> SourceContent | None:
        """Retrieve content for a source by reading from the filesystem."""
        if source_id.startswith("__"):
            if self._meta_store is not None:
                return self._meta_store.retrieve(source_id)
            return None

        path = self._resolve_path(source_id)
        if path is None:
            return SourceContent(
                source_id=source_id,
                summary=f"[external: file not resolved for {source_id}]",
                full_text="",
                metadata={"resolved": False},
            )

        # Re-chunk the file and return the matching chunk
        chunk_idx = self._parse_chunk_index(source_id)
        chunks = self._get_chunks(path)

        if chunk_idx is not None and 0 <= chunk_idx < len(chunks):
            chunk = chunks[chunk_idx]
            return SourceContent(
                source_id=source_id,
                summary=chunk.text,
                full_text=chunk.text,
                metadata={
                    "source_file": str(path),
                    "heading": chunk.heading,
                    "chunk_type": chunk.chunk_type,
                    "resolved": True,
                },
            )

        # Fallback: file changed and chunk index is out of range
        if str(path) not in self._file_cache:
            self._file_cache[str(path)] = self._read_file(path)
        text = self._file_cache[str(path)]
        return SourceContent(
            source_id=source_id,
            summary=text[:200],
            full_text=text,
            metadata={
                "source_file": str(path),
                "resolved": True,
            },
        )

    def retrieve_batch(self, source_ids: list[str]) -> list[SourceContent]:
        """Retrieve content for multiple sources."""
        results = []
        for sid in source_ids:
            content = self.retrieve(sid)
            if content is not None:
                results.append(content)
        return results

    def store(self, content: SourceContent) -> None:
        """No-op for external store (files are managed externally)."""
        pass

    def remove(self, source_id: str) -> bool:
        """No-op for external store."""
        return False

    def all_ids(self) -> list[str]:
        """External store cannot enumerate — returns empty list."""
        return []

    def to_bytes(self) -> bytes:
        """External store has no bytes to serialise."""
        return b""

    def close(self) -> None:
        """No-op."""
        pass
