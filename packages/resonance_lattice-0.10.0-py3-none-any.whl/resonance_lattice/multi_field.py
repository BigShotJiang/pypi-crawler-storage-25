"""Multi-Field Composition: query N knowledge fields simultaneously.

The killer feature. Personal notes + company docs + public knowledge,
each as its own field, queried together. Each field contributes 6
memory tokens -> N*6 tokens total. Knowledge COMPOSES.

Usage:
    multi = MultiFieldMemory({
        "personal": memory_personal,
        "fabric":   memory_fabric,
    })
    readout = multi.query(query_phase)
    # readout.per_field has resonance from each field
    # readout.fused blends all fields weighted by energy
"""

from __future__ import annotations

from typing import NamedTuple

import numpy as np
from numpy.typing import NDArray

from .memory import MemoryReadout, ResonanceMemory


class MultiFieldReadout(NamedTuple):
    """Result of querying multiple fields."""
    per_field: dict[str, MemoryReadout]  # One readout per field
    fused: NDArray                        # (D,) weighted blend across all fields
    field_weights: dict[str, float]       # How much each field contributed
    total_sources: int                    # Sum of sources across all fields


class MultiFieldMemory:
    """Query N resonance memories simultaneously.

    Each field is independent (different corpus, different encoder is OK
    as long as bands and dim match). Results are merged by energy-weighted
    fusion.

    The multi-field readout can be projected to memory tokens:
    - N_fields * 6 tokens (one set per field)
    - Or compressed via cross-field fusion
    """

    def __init__(
        self,
        memories: dict[str, ResonanceMemory],
        weights: dict[str, float] | None = None,
    ) -> None:
        """
        Args:
            memories: Named resonance memories.
            weights: Optional per-field weights (default: energy-based).
        """
        self.memories = memories
        self.static_weights = weights

        # Validate compatible dimensions
        dims = set((m.B, m.D) for m in memories.values())
        if len(dims) > 1:
            raise ValueError(f"All fields must have same (B, D). Got: {dims}")

        first = next(iter(memories.values()))
        self.B = first.B
        self.D = first.D

    @property
    def field_names(self) -> list[str]:
        return list(self.memories.keys())

    @property
    def total_size_mb(self) -> float:
        return sum(m.size_mb for m in self.memories.values())

    @property
    def total_sources(self) -> int:
        return sum(m.N for m in self.memories.values())

    def query(
        self,
        query_phase: NDArray,
        top_k: int = 10,
    ) -> MultiFieldReadout:
        """Query all fields and produce a merged readout.

        Args:
            query_phase: Shape (B, D).
            top_k: Per-field top-K sources.

        Returns:
            MultiFieldReadout with per-field readouts and fused result.
        """
        per_field: dict[str, MemoryReadout] = {}
        field_energies: dict[str, float] = {}

        for name, memory in self.memories.items():
            readout = memory.query(query_phase, top_k=top_k)
            per_field[name] = readout
            field_energies[name] = float(readout.band_energies.sum())

        # Compute weights
        if self.static_weights is not None:
            weights = self.static_weights
        else:
            # Energy-based: fields with stronger resonance get more weight
            total_energy = sum(field_energies.values()) + 1e-12
            weights = {name: e / total_energy for name, e in field_energies.items()}

        # Fuse across all fields
        fused = np.zeros(self.D, dtype=np.float32)
        for name, readout in per_field.items():
            fused += weights[name] * readout.fused

        return MultiFieldReadout(
            per_field=per_field,
            fused=fused,
            field_weights=weights,
            total_sources=self.total_sources,
        )

    def query_ranked(
        self,
        query_phase: NDArray,
        passage_phases_per_field: dict[str, NDArray],
        chunks_per_field: dict[str, list[dict]],
        top_k: int = 10,
    ) -> list[dict]:
        """Full retrieval with ranked results across all fields.

        Returns a merged, deduplicated list of top sources across all fields.
        """
        readout = self.query(query_phase, top_k=top_k)

        all_sources = []
        for name, field_readout in readout.per_field.items():
            passage_phases_per_field[name]
            chunks = chunks_per_field[name]

            for rank, (idx, score) in enumerate(
                zip(field_readout.top_source_indices, field_readout.top_source_scores)
            ):
                all_sources.append({
                    "field": name,
                    "index": int(idx),
                    "score": float(score) * readout.field_weights[name],
                    "rank_in_field": rank,
                    "title": chunks[int(idx)].get("title", ""),
                    "text": chunks[int(idx)].get("text_preview", ""),
                })

        # Sort by weighted score, deduplicate by title
        all_sources.sort(key=lambda x: -x["score"])
        seen = set()
        deduped = []
        for s in all_sources:
            key = s["title"]
            if key not in seen:
                seen.add(key)
                deduped.append(s)
            if len(deduped) >= top_k:
                break

        return deduped
