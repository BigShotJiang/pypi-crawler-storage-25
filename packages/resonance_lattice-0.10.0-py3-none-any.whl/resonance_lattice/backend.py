"""Backend selection: Rust core with automatic Python fallback.

Tries to import the Rust extension module (resonance_lattice_core).
If unavailable, falls back to the pure-Python/NumPy implementations.

Usage:
    from resonance_lattice.backend import create_dense_field, create_pq_field, BACKEND

    field = create_dense_field(bands=5, dim=2048)
    # Returns RustDenseField if available, else DenseField
"""

from __future__ import annotations

import numpy as np

BACKEND: str = "numpy"  # Will be set to "rust" if extension loads

try:
    from resonance_lattice_core import DenseFieldRust, PQFieldRust
    BACKEND = "rust"
except ImportError:
    DenseFieldRust = None
    PQFieldRust = None


class RustDenseFieldAdapter:
    """Adapts the Rust DenseFieldRust to match the Python DenseField API.

    The Rust core returns raw arrays; this adapter wraps them into
    ResonanceResult named tuples for API compatibility.
    """

    def __init__(self, bands: int, dim: int, dtype=np.float32):
        self._rust = DenseFieldRust(bands, dim)
        self.bands = bands
        self.dim = dim
        self.dtype = dtype

    @property
    def source_count(self) -> int:
        return self._rust.source_count

    @property
    def size_bytes(self) -> int:
        return self._rust.size_bytes

    @property
    def size_mb(self) -> float:
        return self.size_bytes / (1024 * 1024)

    def superpose(self, phase_vectors, salience: float = 1.0):
        # Delegate to batch with N=1
        batch = phase_vectors[np.newaxis, :, :]  # (1, B, D)
        sal = np.array([salience], dtype=np.float32)
        self._rust.superpose_batch(batch, sal)

    def superpose_batch(self, phase_batch, saliences=None):
        if saliences is not None:
            saliences = np.asarray(saliences, dtype=np.float32)
        self._rust.superpose_batch(
            np.ascontiguousarray(phase_batch, dtype=np.float32),
            saliences,
        )

    def remove(self, phase_vectors, salience: float = 1.0):
        self._rust.remove(
            np.ascontiguousarray(phase_vectors, dtype=np.float32),
            salience,
        )

    def resonate(self, query_phase, band_weights=None):
        from resonance_lattice.field.dense import ResonanceResult

        if band_weights is not None:
            band_weights = np.asarray(band_weights, dtype=np.float32)

        resonance_vectors, fused, band_energies = self._rust.resonate(
            np.ascontiguousarray(query_phase, dtype=np.float32),
            band_weights,
        )
        return ResonanceResult(
            resonance_vectors=np.asarray(resonance_vectors),
            fused=np.asarray(fused),
            band_energies=np.asarray(band_energies),
        )

    def compute_snr(self, num_sources=None, sparsity=None):
        n = num_sources if num_sources is not None else self.source_count
        if n <= 1:
            return float("inf")
        s = sparsity if sparsity is not None else 1.0
        return self.dim / (s ** 2 * (n - 1))

    def energy(self):
        # Not implemented in Rust yet — fall back to resonate with identity
        return np.zeros(self.bands, dtype=self.dtype)

    def reset(self):
        self._rust.reset()


class RustPQFieldAdapter:
    """Adapts the Rust PQFieldRust to match the Python PQField API."""

    def __init__(self, bands: int, dim: int, num_subspaces: int = 8,
                 codebook_size: int = 1024, dtype=np.float32):
        self._rust = PQFieldRust(bands, dim, num_subspaces, codebook_size)
        self.bands = bands
        self.dim = dim
        self.M = num_subspaces
        self.K = codebook_size
        self.sub_dim = dim // num_subspaces
        self.dtype = dtype
        self._codebooks_trained = False

    @property
    def source_count(self) -> int:
        return self._rust.source_count

    @property
    def codebooks_trained(self) -> bool:
        return self._codebooks_trained

    @property
    def size_bytes(self) -> int:
        return self._rust.size_bytes

    @property
    def size_mb(self) -> float:
        return self.size_bytes / (1024 * 1024)

    def set_codebooks(self, codebooks: list[list[np.ndarray]]):
        """Transfer trained codebooks from Python to Rust."""
        for b in range(self.bands):
            for m in range(self.M):
                cb = np.ascontiguousarray(codebooks[b][m], dtype=np.float32)
                self._rust.set_codebook(b, m, cb)
        self._codebooks_trained = True

    def superpose_batch(self, phase_batch, saliences=None):
        if saliences is not None:
            saliences = np.asarray(saliences, dtype=np.float32)
        self._rust.superpose_batch(
            np.ascontiguousarray(phase_batch, dtype=np.float32),
            saliences,
        )

    def resonate(self, query_phase, band_weights=None):
        from resonance_lattice.field.dense import ResonanceResult

        if band_weights is not None:
            band_weights = np.asarray(band_weights, dtype=np.float32)

        resonance_vectors, fused, band_energies = self._rust.resonate(
            np.ascontiguousarray(query_phase, dtype=np.float32),
            band_weights,
        )
        return ResonanceResult(
            resonance_vectors=np.asarray(resonance_vectors),
            fused=np.asarray(fused),
            band_energies=np.asarray(band_energies),
        )

    def reset(self):
        self._rust.reset()


def create_dense_field(bands: int, dim: int, dtype=np.float32, force_numpy: bool = False):
    """Create a dense field, using Rust if available.

    Args:
        bands: Number of frequency bands.
        dim: Dimensionality per band.
        dtype: NumPy dtype (Rust always uses f32 internally).
        force_numpy: If True, always use Python/NumPy backend.

    Returns:
        DenseField or RustDenseFieldAdapter.
    """
    if BACKEND == "rust" and not force_numpy:
        return RustDenseFieldAdapter(bands, dim, dtype)

    from resonance_lattice.field.dense import DenseField
    return DenseField(bands, dim, dtype)


def create_pq_field(bands: int, dim: int, num_subspaces: int = 8,
                    codebook_size: int = 1024, dtype=np.float32,
                    force_numpy: bool = False):
    """Create a PQ field, using Rust if available.

    Args:
        bands: Number of frequency bands.
        dim: Dimensionality per band.
        num_subspaces: M — PQ subspaces.
        codebook_size: K — centroids per subspace.
        dtype: NumPy dtype.
        force_numpy: If True, always use Python/NumPy backend.

    Returns:
        PQField or RustPQFieldAdapter.
    """
    if BACKEND == "rust" and not force_numpy:
        return RustPQFieldAdapter(bands, dim, num_subspaces, codebook_size, dtype)

    from resonance_lattice.field.pq import PQField
    return PQField(bands, dim, num_subspaces, codebook_size, dtype)
