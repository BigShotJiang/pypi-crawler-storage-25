"""CLI interface for the Resonance Lattice.

Usage:
    rlat search corpus.rlat "How does auth work?"
    rlat profile corpus.rlat
    rlat build ./docs ./src -o corpus.rlat
    rlat compare a.rlat b.rlat
"""

from __future__ import annotations

import argparse
import contextlib
import io as _io
import json
import logging
import os
import re
import sys
import time
from pathlib import Path

logger = logging.getLogger(__name__)


# ── Output helpers ─────────────────────────────────────────────────────

def _die(message: str, code: int = 1) -> None:
    """Print error to stderr and exit."""
    print(f"Error: {message}", file=sys.stderr)
    sys.exit(code)


def _warn(message: str) -> None:
    """Print warning to stderr."""
    print(f"Warning: {message}", file=sys.stderr)


def _parse_band_energies(
    coverage: dict,
    fallback_names: list[str] | None = None,
) -> tuple[list[str], list[float]]:
    """Extract (names, values) from a coverage dict's band_energies field."""
    band_energies = coverage.get("band_energies", {})
    band_names = coverage.get("band_names", []) or fallback_names or []
    if isinstance(band_energies, dict):
        names = list(band_energies.keys())
        vals = [float(v) for v in band_energies.values()]
    else:
        names = band_names or [f"b{i}" for i in range(len(band_energies))]
        vals = [float(v) for v in band_energies]
    return names, vals


def _safe_bar(fraction: float, width: int = 20) -> str:
    """Render a progress bar using characters safe for the current terminal encoding."""
    fill_len = int(width * max(0.0, min(1.0, fraction)))
    empty_len = width - fill_len
    try:
        "\u2588".encode(sys.stdout.encoding or "utf-8")
        return "\u2588" * fill_len + "\u2591" * empty_len
    except (UnicodeEncodeError, LookupError):
        return "#" * fill_len + "-" * empty_len


def _display_name(result) -> str:
    """Human-readable name for a result: source_file / heading, falling back to source_id."""
    if result.content and result.content.metadata:
        source_file = result.content.metadata.get("source_file", "")
        heading = result.content.metadata.get("heading", "")
        stem = Path(source_file).stem if source_file else ""
        if stem and heading:
            return f"{stem} / {heading}"
        if stem:
            return stem
        if heading:
            return heading
    return result.source_id


def _truncate(text: str, max_chars: int = 200) -> str:
    """Truncate text to max_chars, breaking at a word boundary."""
    if len(text) <= max_chars:
        return text
    cut = text[:max_chars].rfind(" ")
    if cut < max_chars // 2:
        cut = max_chars
    return text[:cut] + "..."


def _clean_passage(text: str) -> str:
    """Strip markdown noise from a passage for clean terminal display."""
    import re
    # Strip heading markers
    text = re.sub(r'^#{1,6}\s+', '', text, flags=re.MULTILINE)
    # Strip bold/italic markers
    text = text.replace('**', '').replace('__', '')
    # Strip markdown links: [text](url) -> text
    text = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', text)
    # Strip blockquote markers (both start-of-line and inline after newlines)
    text = re.sub(r'^>\s*', '', text, flags=re.MULTILINE)
    text = re.sub(r'\s>\s', ' ', text)
    # Strip HTML-like tags (</BR>, :::, etc.)
    text = re.sub(r'</?[A-Za-z]+/?>', '', text)
    text = re.sub(r':::.*?:::', '', text, flags=re.DOTALL)
    # Strip [!NOTE], [!IMPORTANT], etc.
    text = re.sub(r'\[!(?:NOTE|IMPORTANT|WARNING|CAUTION|TIP)\]\s*', '', text)
    # Strip markdown table rows (lines that are mostly pipes and dashes)
    text = re.sub(r'\|[-\s|]+\|', '', text)
    # Clean remaining pipe-delimited table content
    text = re.sub(r'\|', ' ', text)
    # Collapse whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def _quiet_stderr():
    """Context manager that suppresses stderr (encoder loading noise)."""
    if os.environ.get("RLAT_VERBOSE"):
        return contextlib.nullcontext()
    return contextlib.redirect_stderr(_io.StringIO())


def _require_file(path: Path) -> None:
    """Exit with a friendly message if the file does not exist."""
    if not path.exists():
        _die(f"file not found: {path}")


# ── ANSI color helpers ─────────────────────────────────────────────────

def _use_color() -> bool:
    """Check if the terminal supports ANSI color."""
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("FORCE_COLOR"):
        return True
    if not hasattr(sys.stdout, "isatty"):
        return False
    return sys.stdout.isatty()


class _C:
    """ANSI color codes. All resolve to empty strings when color is off."""
    _on: bool = False

    @classmethod
    def init(cls):
        cls._on = _use_color()

    @classmethod
    def _code(cls, code: str) -> str:
        return code if cls._on else ""

    @classmethod
    def bold(cls, text: str) -> str:
        return f"{cls._code(chr(27) + '[1m')}{text}{cls._code(chr(27) + '[0m')}"

    @classmethod
    def dim(cls, text: str) -> str:
        return f"{cls._code(chr(27) + '[2m')}{text}{cls._code(chr(27) + '[0m')}"

    @classmethod
    def green(cls, text: str) -> str:
        return f"{cls._code(chr(27) + '[32m')}{text}{cls._code(chr(27) + '[0m')}"

    @classmethod
    def yellow(cls, text: str) -> str:
        return f"{cls._code(chr(27) + '[33m')}{text}{cls._code(chr(27) + '[0m')}"

    @classmethod
    def cyan(cls, text: str) -> str:
        return f"{cls._code(chr(27) + '[36m')}{text}{cls._code(chr(27) + '[0m')}"

    @classmethod
    def red(cls, text: str) -> str:
        return f"{cls._code(chr(27) + '[31m')}{text}{cls._code(chr(27) + '[0m')}"

    @classmethod
    def blue(cls, text: str) -> str:
        return f"{cls._code(chr(27) + '[34m')}{text}{cls._code(chr(27) + '[0m')}"


# ── File manifest for incremental sync ─────────────────────────────────

import hashlib as _hashlib


def _canonical_path(path: Path) -> str:
    """Normalize a file path to a stable canonical form for manifest keys.

    Uses CWD-relative POSIX paths so that the same source tree produces
    identical manifest keys regardless of where the repo is checked out.
    Falls back to the resolved filename if the path is outside CWD.
    Lowercased on Windows for case-insensitive matching.
    """
    try:
        rel = path.resolve().relative_to(Path.cwd().resolve())
    except ValueError:
        # Path is outside CWD — use the filename only
        rel = Path(path.name)
    posix = rel.as_posix()
    if sys.platform == "win32":
        posix = posix.lower()
    return posix


class FileManifest:
    """Tracks which files are in a cartridge and which chunks they produced.

    Persisted as a __manifest__ entry in the SourceStore so it survives
    save/load cycles. Keys are canonical POSIX paths (see _canonical_path).
    """

    def __init__(self) -> None:
        # canonical_path -> {hash, chunk_ids, encoder}
        self.entries: dict[str, dict] = {}

    def record(self, file_path: str, content_hash: str, chunk_ids: list[str],
               encoder_fp: str = "") -> None:
        self.entries[file_path] = {
            "hash": content_hash,
            "chunk_ids": chunk_ids,
            "encoder": encoder_fp,
        }

    def remove_file(self, file_path: str) -> list[str]:
        """Remove a file entry and return its chunk IDs for cleanup."""
        entry = self.entries.pop(file_path, None)
        return entry["chunk_ids"] if entry else []

    def needs_update(self, file_path: str, content_hash: str, encoder_fp: str = "") -> bool:
        """Check if a file needs re-ingestion.

        Returns True if the file is new, its content changed, OR the encoder
        fingerprint differs from what was used to encode it.
        """
        entry = self.entries.get(file_path)
        if entry is None:
            return True
        if entry["hash"] != content_hash:
            return True
        # Encoder mismatch = must re-encode
        if encoder_fp and entry.get("encoder") and entry["encoder"] != encoder_fp:
            return True
        return False

    def stored_encoder(self) -> str | None:
        """Return the encoder fingerprint used by existing entries, or None."""
        for entry in self.entries.values():
            fp = entry.get("encoder", "")
            if fp:
                return fp
        return None

    def known_files(self) -> set[str]:
        return set(self.entries.keys())

    def to_json(self) -> str:
        return json.dumps(self.entries, separators=(",", ":"))

    @classmethod
    def from_json(cls, data: str) -> FileManifest:
        m = cls()
        m.entries = json.loads(data) if data else {}
        return m

    @staticmethod
    def hash_file(path: Path) -> str:
        return _hashlib.md5(path.read_bytes()).hexdigest()


def _load_manifest(lattice) -> FileManifest:
    """Load the file manifest from a lattice's store.

    If the cartridge has no manifest (legacy), returns an empty manifest
    and prints a warning. The first add/sync will treat all files as new.
    """
    content = lattice.store.retrieve("__manifest__")
    if content and content.full_text:
        return FileManifest.from_json(content.full_text)
    # Legacy cartridge or first run
    if lattice.source_count > 0:
        print(
            "Warning: this cartridge has no file manifest (built before manifest support).\n"
            "  The first add/sync will treat all source files as new.\n"
            "  To avoid duplicates, rebuild with: rlat build ... -o cartridge.rlat",
            file=sys.stderr,
        )
    return FileManifest()


def _check_encoder_consistency(manifest: FileManifest, encoder_fp: str,
                               lattice=None) -> None:
    """Refuse to mix encoders in a single cartridge.

    Checks the manifest's stored encoder fingerprint first. For legacy
    cartridges without a manifest, falls back to comparing the stored
    __encoder__ config in the lattice itself.

    Raises SystemExit if the encoders don't match.
    """
    stored = manifest.stored_encoder()

    # Legacy fallback: if no manifest encoder, check the cartridge's stored encoder
    if not stored and lattice is not None and lattice.store.count > 0:
        enc_content = lattice.store.retrieve("__encoder__")
        if enc_content and enc_content.full_text:
            try:
                import json as _json
                enc_config = _json.loads(enc_content.full_text)
                # Build the same fingerprint from stored config
                parts = [
                    enc_config.get("encoder_type", ""),
                    enc_config.get("backbone", ""),
                    str(enc_config.get("bands", "")),
                    str(enc_config.get("dim", "")),
                    enc_config.get("checkpoint_path", ""),
                    str(enc_config.get("sparsities", "")),
                    enc_config.get("query_prefix", ""),
                    enc_config.get("passage_prefix", ""),
                    enc_config.get("pooling", ""),
                ]
                stored = _hashlib.md5("|".join(parts).encode()).hexdigest()[:12]
            except Exception:
                pass

    if stored and encoder_fp and stored != encoder_fp:
        print(
            f"Error: encoder mismatch.\n"
            f"  Cartridge was built with: {stored}\n"
            f"  Current encoder:          {encoder_fp}\n"
            f"  Mixing encoders degrades retrieval quality.\n"
            f"  Use the same --checkpoint, or rebuild the cartridge.",
            file=sys.stderr,
        )
        sys.exit(1)


def _save_manifest(lattice, manifest: FileManifest) -> None:
    """Persist the file manifest into the lattice's store."""
    from resonance_lattice.store import SourceContent
    lattice.store.remove("__manifest__")
    lattice.store.store(SourceContent(
        source_id="__manifest__",
        summary="file manifest",
        full_text=manifest.to_json(),
    ))


def cmd_init(args: argparse.Namespace) -> None:
    """Create a new empty lattice file."""
    from resonance_lattice.config import Compression, FieldType, LatticeConfig, Precision
    from resonance_lattice.lattice import Lattice

    config = LatticeConfig(
        bands=args.bands,
        dim=args.dim,
        field_type=FieldType(args.field_type),
        pq_subspaces=args.pq_subspaces,
        pq_codebook_size=args.pq_codebook_size,
        svd_rank=args.svd_rank,
        precision=Precision(args.precision),
        compression=Compression(args.compression),
    )

    lattice = Lattice(config=config)

    output = Path(args.output)
    lattice.save(output)
    print(f"Created empty lattice: {output}")
    print(f"  Field type: {config.field_type.value}")
    print(f"  Bands: {config.bands}, Dim: {config.dim}")
    print(f"  Estimated field size: {config.field_size_mb:.1f} MB")


def _describe_encoder(encoder) -> str:
    """Return a short human-readable encoder description."""
    config = encoder.get_config()
    encoder_type = config.get("encoder_type", "random")
    backbone = config.get("backbone", "random")
    return f"{encoder_type} ({backbone})"


def _encoder_fingerprint(encoder) -> str:
    """Return a stable fingerprint that distinguishes different encoder configs.

    Includes encoder_type, backbone, checkpoint_path, bands, dim, sparsities,
    and protocol fields (query_prefix, passage_prefix, pooling) so that
    encoders with different prefix/pooling contracts produce different
    fingerprints.
    """
    config = encoder.get_config()
    # Build a canonical key from all identity-relevant fields
    parts = [
        config.get("encoder_type", ""),
        config.get("backbone", ""),
        str(config.get("bands", "")),
        str(config.get("dim", "")),
        config.get("checkpoint_path", ""),
        str(config.get("sparsities", "")),
        config.get("query_prefix", ""),
        config.get("passage_prefix", ""),
        config.get("pooling", ""),
    ]
    return _hashlib.md5("|".join(parts).encode()).hexdigest()[:12]


def _has_encoder_override(args: argparse.Namespace) -> bool:
    """True when CLI args explicitly override a cartridge's stored encoder."""
    return bool(getattr(args, "checkpoint", None) or getattr(args, "encoder", None))


def _resolve_preset(name: str) -> dict | None:
    """Look up a named encoder preset. Returns config dict or None."""
    from resonance_lattice.config import ENCODER_PRESETS
    return ENCODER_PRESETS.get(name)


def _load_encoder(args: argparse.Namespace, bands: int, dim: int, lattice=None):
    """Helper to load encoder from CLI args, stored config, or default.

    Priority: --checkpoint > explicit --encoder > restored lattice encoder > default
    """
    from resonance_lattice.encoder import Encoder

    # 1. Explicit checkpoint flag
    if hasattr(args, "checkpoint") and args.checkpoint:
        print(f"Loading trained heads: {args.checkpoint}", file=sys.stderr)
        return Encoder.from_checkpoint(args.checkpoint, load_backbone=True)

    # 2. Explicit encoder flag (preset name or raw HuggingFace model ID)
    encoder_flag = getattr(args, "encoder", None)
    if encoder_flag is not None:
        if encoder_flag == "random":
            print("Using random encoder", file=sys.stderr)
            return Encoder.random(bands=bands, dim=dim)
        preset = _resolve_preset(encoder_flag)
        if preset:
            print(f"Loading encoder preset: {encoder_flag} ({preset['backbone']})", file=sys.stderr)
            return Encoder.from_backbone(
                model_name=preset["backbone"],
                bands=bands,
                dim=dim,
                query_prefix=preset["query_prefix"],
                passage_prefix=preset["passage_prefix"],
                pooling=preset["pooling"],
                max_length=preset["max_length"],
            )
        # Not a preset — treat as raw HuggingFace model ID
        print(f"Loading encoder: {encoder_flag}", file=sys.stderr)
        return Encoder.from_backbone(model_name=encoder_flag, bands=bands, dim=dim)

    # 3. Restored encoder on the lattice
    if lattice is not None and lattice.encoder is not None:
        print(f"Using stored encoder: {_describe_encoder(lattice.encoder)}", file=sys.stderr)
        return lattice.encoder

    # 4. Default: backbone encoder (real quality out of the box)
    print("Downloading encoder (intfloat/e5-large-v2, one-time)...", file=sys.stderr)
    return Encoder.from_backbone(
        model_name="intfloat/e5-large-v2",
        bands=bands,
        dim=dim,
    )


def _load_lattice_with_encoder(args: argparse.Namespace, lattice_path: Path):
    """Load a lattice while respecting stored encoder ownership.

    Suppresses HuggingFace/BERT loading noise unless RLAT_VERBOSE=1.
    """
    import warnings

    from resonance_lattice.lattice import Lattice
    verbose = os.environ.get("RLAT_VERBOSE")
    if not verbose:
        print(f"Loading {lattice_path.name}...", file=sys.stderr, end="", flush=True)
    source_root = getattr(args, "source_root", None)
    override = _has_encoder_override(args)
    with warnings.catch_warnings(record=True) as captured_warnings:
        warnings.simplefilter("always")
        with _quiet_stderr():
            lattice = Lattice.load(
                lattice_path,
                restore_encoder=not override,
                source_root=source_root,
            )
            if override or lattice.encoder is None:
                lattice.encoder = _load_encoder(args, lattice.config.bands, lattice.config.dim, lattice=lattice)
    if not verbose:
        print("\r\033[K", file=sys.stderr, end="", flush=True)  # clear loading line
    # Surface critical warnings (checkpoint missing, etc.) even when stderr is suppressed
    for w in captured_warnings:
        if issubclass(w.category, RuntimeWarning):
            _warn(str(w.message))
    if verbose and lattice.encoder is not None and not override:
        print(f"Encoder: {_describe_encoder(lattice.encoder)}", file=sys.stderr)
    if source_root:
        print(f"Store: external ({source_root})", file=sys.stderr)

    # Attach ONNX backbone if available (2-3x faster encoding)
    onnx_dir = getattr(args, "onnx", None)
    if not onnx_dir:
        # Auto-detect alongside cartridge
        from resonance_lattice.worker_main import _find_onnx_dir
        onnx_dir = _find_onnx_dir(lattice_path)
    if onnx_dir and lattice.encoder is not None:
        try:
            from resonance_lattice.encoder_onnx import attach_onnx_backbone
            attach_onnx_backbone(lattice.encoder, onnx_dir)
        except Exception:
            pass

    return lattice


def _get_system_prompt(mode: str, custom_prompt: str | None = None) -> str:
    """Get the system prompt for the specified injection mode."""
    from resonance_lattice.projector import AugmentProjector
    prompts = {
        "augment": AugmentProjector.SYSTEM_AUGMENT,
        "constrain": AugmentProjector.SYSTEM_CONSTRAIN,
        "knowledge": AugmentProjector.SYSTEM_KNOWLEDGE,
    }
    if mode == "custom":
        if not custom_prompt:
            _die("--custom-prompt required with --mode custom")
        return custom_prompt
    return prompts.get(mode, prompts["augment"])


INGEST_EXTENSIONS = {
    # Text / markup
    ".txt", ".md", ".rst", ".html", ".htm", ".xml",
    # Code
    ".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".c", ".cpp", ".h",
    ".hpp", ".go", ".rb", ".rs", ".swift", ".kt", ".lua", ".r", ".php",
    ".sh", ".sql", ".css", ".scss",
    # Data / config
    ".json", ".yaml", ".yml", ".toml", ".csv", ".tsv",
    # Binary (requires optional deps — graceful fallback in ExternalStore)
    ".docx", ".pdf", ".xlsx", ".xls",
}

# Directories to skip during recursive file discovery
SKIP_DIRS = {
    "__pycache__", ".git", ".hg", ".svn", "node_modules", "dist", "build",
    ".venv", "venv", ".env", ".tox", ".mypy_cache", ".pytest_cache",
    ".egg-info", ".eggs", "htmlcov", ".ipynb_checkpoints",
}


def _collect_files(paths: list[Path]) -> list[Path]:
    """Collect ingestable files from paths, filtering out noise directories."""
    files = []
    for input_path in paths:
        if input_path.is_file():
            if input_path.suffix.lower() in INGEST_EXTENSIONS:
                files.append(input_path)
            else:
                files.append(input_path)  # Explicit files always included
        elif input_path.is_dir():
            for ext in sorted(INGEST_EXTENSIONS):
                for f in sorted(input_path.rglob(f"*{ext}")):
                    if not any(skip in f.parts for skip in SKIP_DIRS):
                        files.append(f)
        else:
            print(f"Warning: not found, skipping: {input_path}", file=sys.stderr)
    return files


def _auto_detect_inputs() -> list[Path]:
    """Auto-detect common documentation and source directories in the current project."""
    cwd = Path(".")
    candidates = [
        cwd / "docs",
        cwd / "src",
        cwd / "lib",
        cwd / "README.md",
        cwd / "CLAUDE.md",
        cwd / "AGENTS.md",
    ]
    found = [p for p in candidates if p.exists()]
    if not found:
        # Fallback: scan current directory
        found = [cwd]
    return found


def cmd_ingest(args: argparse.Namespace) -> None:
    """Ingest documents into a lattice."""
    lattice_path = Path(args.lattice)
    # Support both positional input and --input flag
    input_str = args.input
    input_path = Path(input_str)

    if not lattice_path.exists():
        _die(f"lattice file not found: {lattice_path}")

    lattice = _load_lattice_with_encoder(args, lattice_path)
    manifest = _load_manifest(lattice)
    encoder_fp = _encoder_fingerprint(lattice.encoder) if lattice.encoder else ""
    _check_encoder_consistency(manifest, encoder_fp, lattice=lattice)

    # Collect input files
    files = _collect_files([input_path])
    if not files:
        _die(f"no ingestable files found in: {input_path}")

    start = time.time()
    count = 0

    from resonance_lattice.chunker import auto_chunk, generate_summary

    # Phase 1: Collect all chunks (fast, no GPU)
    all_texts: list[str] = []
    all_sids: list[str] = []
    all_metas: list[dict] = []
    all_summaries: list[str] = []

    try:
        from tqdm import tqdm
        file_iter = tqdm(files, desc="Chunking", unit="file", file=sys.stderr)
    except ImportError:
        print(f"Chunking {len(files)} files...", file=sys.stderr)
        file_iter = files

    for f in file_iter:
        text = f.read_text(encoding="utf-8", errors="replace")
        chunks = auto_chunk(text, source_file=str(f))

        for chunk in chunks:
            slug = chunk.heading[:40].replace(" ", "_").lower() if chunk.heading else ""
            sid = f"{f.stem}_{slug}_{count:06d}" if slug else f"{f.stem}_{count:06d}"
            all_texts.append(chunk.text)
            all_sids.append(sid)
            meta = {
                "source_file": str(f),
                "heading": chunk.heading,
                "chunk_type": chunk.chunk_type,
            }
            if chunk.metadata:
                meta.update(chunk.metadata)
            all_metas.append(meta)
            all_summaries.append(generate_summary(chunk))
            count += 1

    t_chunk = time.time() - start
    print(f"Chunked {count} chunks from {len(files)} files in {t_chunk:.1f}s")

    # Phase 2: Batch encode + superpose (GPU-accelerated)
    print(f"Encoding {count} chunks (batch_size=64, fp16 on GPU)...", file=sys.stderr)
    t_encode = time.time()
    lattice.superpose_text_batch(
        texts=all_texts,
        source_ids=all_sids,
        metadatas=all_metas,
        summaries=all_summaries,
        batch_size=64,
    )

    elapsed = time.time() - start
    encode_elapsed = time.time() - t_encode
    print(f"Ingested {count} chunks from {len(files)} files in {elapsed:.1f}s")
    print(f"  Chunking: {t_chunk:.1f}s, Encoding: {encode_elapsed:.1f}s")
    print(f"  Rate: {count / max(elapsed, 1e-3):.0f} chunks/s")

    lattice.save(lattice_path)
    print(f"Saved: {lattice_path}")


def cmd_query(args: argparse.Namespace) -> None:
    """Query a lattice and display results."""
    lattice_path = Path(args.lattice)
    lattice = _load_lattice_with_encoder(args, lattice_path)

    start = time.time()
    result = lattice.resonate_text(
        query=args.query,
        top_k=args.top_k,
    )
    elapsed = (time.time() - start) * 1000

    mode = getattr(args, "mode", None)
    system_prompt = _get_system_prompt(mode, getattr(args, "custom_prompt", None)) if mode else None

    if args.format == "json":
        output = {
            "query": args.query,
            "latency_ms": round(elapsed, 2),
            "results": [
                {
                    "source_id": r.source_id,
                    "score": round(r.score, 4),
                    "raw_score": round(r.raw_score, 4) if getattr(r, "raw_score", None) is not None else None,
                    "band_scores": r.band_scores.tolist() if r.band_scores is not None else None,
                    "summary": r.content.summary if r.content else None,
                    "full_text": r.content.full_text if r.content else None,
                    "source_file": (r.content.metadata or {}).get("source_file", "") if r.content else "",
                    "heading": (r.content.metadata or {}).get("heading", "") if r.content else "",
                    "provenance": getattr(r, "provenance", "dense"),
                }
                for r in result.results
            ],
            "coverage": None,
            "related": None,
            "contradictions": None,
        }
        if mode:
            output["mode"] = mode
            output["system_prompt"] = system_prompt
        print(json.dumps(output, indent=2))
    elif args.format == "context":
        if system_prompt:
            print(f"[System: {mode}]")
            print(system_prompt)
            print()
        lines = []
        for r in result.results[:args.top_k]:
            if r.content:
                text = r.content.full_text or r.content.summary or ""
                if text:
                    lines.append(f"- [{r.score:.2f}] {text}")
        print("\n".join(lines))
    elif args.format == "prompt":
        payload = {
            "query": args.query,
            "results": [
                {
                    "source_id": r.source_id,
                    "score": round(r.score, 4),
                    "summary": r.content.summary if r.content else None,
                    "full_text": r.content.full_text if r.content else None,
                    "source_file": (r.content.metadata or {}).get("source_file", "") if r.content else "",
                    "heading": (r.content.metadata or {}).get("heading", "") if r.content else "",
                }
                for r in result.results
            ],
            "coverage": {},
            "related_topics": [],
            "contradictions": [],
        }
        print(_dict_to_prompt(payload))
    else:
        if system_prompt:
            print(f"[Mode: {mode}]\n{system_prompt}\n")
        print(f"Query: {args.query}")
        print(f"Latency: {elapsed:.2f} ms")
        print(f"Results ({len(result.results)}):\n")
        for i, r in enumerate(result.results, 1):
            print(f"  {i}. [{r.score:.4f}] {r.source_id}")
            if r.content:
                text = (r.content.full_text or r.content.summary or "")[:500]
                print(f"     {text}")
            print()


def cmd_encoders(_args: argparse.Namespace) -> None:
    """List available encoder presets."""
    from resonance_lattice.config import ENCODER_PRESETS

    # Header
    print(f"{'Preset':<18} {'Backbone':<45} {'Tokens':>8}  {'Pooling':<6}  Query prefix")
    print(f"{'─' * 18} {'─' * 45} {'─' * 8}  {'─' * 6}  {'─' * 30}")

    for name, p in ENCODER_PRESETS.items():
        prefix = p["query_prefix"]
        # Truncate long prefixes for display
        if len(prefix) > 30:
            prefix = prefix[:27] + "..."
        prefix = repr(prefix) if prefix else "(none)"
        print(
            f"{name:<18} {p['backbone']:<45} {p['max_length']:>8}  "
            f"{p['pooling']:<6}  {prefix}"
        )

    print(f"\nPass any preset name to --encoder, or use a raw HuggingFace model ID.")


def cmd_info(args: argparse.Namespace) -> None:
    """Display lattice metadata."""
    from resonance_lattice.lattice import Lattice

    lattice_path = Path(args.lattice)
    lattice = Lattice.load(lattice_path, restore_encoder=False)
    info = lattice.info()

    print(f"Lattice: {lattice_path}")
    print(f"  Sources:    {info['source_count']}")
    print(f"  Bands:      {info['bands']}")
    print(f"  Dim:        {info['dim']}")
    print(f"  Field type: {info['field_type']}")
    print(f"  Field size: {info['field_size_mb']:.1f} MB")
    print(f"  SNR:        {info['snr']:.1f}")
    print(f"  Energy:     {info['field_energy']}")

    if "svd_rank" in info:
        print(f"  SVD rank:   {info['svd_rank']}")
    if "pq_subspaces" in info:
        print(f"  PQ M:       {info['pq_subspaces']}")
        print(f"  PQ K:       {info['pq_codebook_size']}")


def cmd_diff(args: argparse.Namespace) -> None:
    """Compute corpus subtraction between two lattices."""
    from resonance_lattice.lattice import Lattice

    path_a, path_b = Path(args.lattice_a), Path(args.lattice_b)
    _require_file(path_a)
    _require_file(path_b)
    a = Lattice.load(path_a, restore_encoder=False)
    b = Lattice.load(path_b, restore_encoder=False)

    delta = a.subtract(b)

    if args.output:
        delta.save(Path(args.output))
        print(f"Delta saved: {args.output}")

    info = delta.info()
    print(f"Delta field energy: {info['field_energy']}")
    print(f"Delta sources: ~{info['source_count']}")


def cmd_serve(args: argparse.Namespace) -> None:
    """Start the lattice HTTP server."""
    from resonance_lattice.server import serve

    lattice_path = Path(args.lattice)
    _require_file(lattice_path)
    lattice = _load_lattice_with_encoder(args, lattice_path)

    serve(lattice, host=args.host, port=args.port)


def cmd_build(args: argparse.Namespace) -> None:
    """Build a cartridge: create lattice + ingest documents in one step."""
    from resonance_lattice.config import Compression, FieldType, LatticeConfig, Precision
    from resonance_lattice.lattice import Lattice

    config = LatticeConfig(
        bands=args.bands,
        dim=args.dim,
        field_type=FieldType(args.field_type),
        precision=Precision(args.precision),
        compression=Compression(args.compression),
    )

    lattice = Lattice(config=config)
    lattice.encoder = _load_encoder(args, config.bands, config.dim)

    # Attach ONNX backbone if requested (2-5x faster encoding on CPU)
    onnx_dir = getattr(args, "onnx", None)
    if onnx_dir and lattice.encoder is not None:
        try:
            from resonance_lattice.encoder_onnx import attach_onnx_backbone
            attach_onnx_backbone(lattice.encoder, onnx_dir)
        except Exception as exc:
            _warn(f"ONNX backbone failed to load: {exc}")

    # Collect input files
    input_paths = [Path(s) for s in args.inputs]
    files = _collect_files(input_paths)

    if not files:
        _die(
            f"no files found to ingest.\n"
            f"  Searched: {', '.join(args.inputs)}\n"
            f"  Extensions: {', '.join(sorted(INGEST_EXTENSIONS))}"
        )

    # Show what we found
    ext_counts: dict[str, int] = {}
    for f in files:
        ext_counts[f.suffix.lower()] = ext_counts.get(f.suffix.lower(), 0) + 1
    ext_summary = ", ".join(f"{count} {ext}" for ext, count in sorted(ext_counts.items(), key=lambda x: -x[1]))
    progress = getattr(args, "progress", False)

    if progress:
        print(json.dumps({"phase": "scanning", "total_files": len(files), "extensions": ext_summary}), flush=True)
    else:
        print(f"Building cartridge from {len(files)} files ({ext_summary})")

    manifest = FileManifest()
    encoder_fp = _encoder_fingerprint(lattice.encoder) if lattice.encoder else ""

    fmt = getattr(args, "input_format", "")
    session = getattr(args, "session", "")
    ts = getattr(args, "timestamp", "")

    start = time.time()
    added, updated, skipped = _ingest_files_incremental(
        lattice, files, manifest, encoder_fp, progress=progress,
        format_override=fmt, session=session, timestamp=ts,
    )
    elapsed = time.time() - start

    _save_manifest(lattice, manifest)

    output = Path(args.output)
    quant_bits = getattr(args, "quantize_registry", 0)

    store_mode = getattr(args, "store_mode", "embedded")
    if progress:
        print(json.dumps({"phase": "saving"}), flush=True)
    else:
        print("Saving cartridge...", file=sys.stderr)
    lattice.save(output, registry_quantize=quant_bits, store_mode=store_mode)

    info = lattice.info()
    count = lattice.source_count
    if progress:
        print(json.dumps({"phase": "done", "chunks": count, "files": len(files),
                          "elapsed": round(elapsed, 1),
                          "field_size_mb": round(info["field_size_mb"], 1)}), flush=True)
    else:
        print(f"Built {output.name}: {count} chunks from {len(files)} files in {elapsed:.1f}s")
    print(f"  Field: {info['field_size_mb']:.1f} MB | Bands: {info['bands']} x {info['dim']}d")
    if quant_bits:
        print(f"  Registry: {quant_bits}-bit quantized")
    if store_mode == "external":
        print("  Store: external (use --source-root at query time)")

    # Update manifest if cartridge is in a .rlat/ directory
    if output.parent.name == ".rlat" or output.suffix == ".rlat":
        try:
            from resonance_lattice.discover import update_manifest
            manifest_dir = output.parent if output.parent.name == ".rlat" else output.parent
            manifest_path = manifest_dir / "manifest.json"
            source_strs = [str(f) for f in files]
            update_manifest(
                manifest_path, output, source_files=source_strs,
                source_count=count, bands=info["bands"], dim=info["dim"],
            )
        except Exception:
            pass  # manifest update is best-effort


def cmd_merge(args: argparse.Namespace) -> None:
    """Merge two lattices into one."""
    from resonance_lattice.algebra import FieldAlgebra
    from resonance_lattice.field.dense import DenseField
    from resonance_lattice.lattice import Lattice

    path_a, path_b = Path(args.lattice_a), Path(args.lattice_b)
    _require_file(path_a)
    _require_file(path_b)
    a = Lattice.load(path_a)
    b = Lattice.load(path_b)

    if not isinstance(a.field, DenseField) or not isinstance(b.field, DenseField):
        _die("merge only supports dense field backends.")

    # Validate encoder compatibility — merging fields built with different
    # heads produces meaningless results.
    fp_a = _encoder_fingerprint(a.encoder) if a.encoder else ""
    fp_b = _encoder_fingerprint(b.encoder) if b.encoder else ""
    if fp_a and fp_b and fp_a != fp_b:
        _warn("cartridges use different encoders — merged results may be unreliable.")

    result = FieldAlgebra.merge(a.field, b.field)

    merged = Lattice(config=a.config)
    assert isinstance(merged.field, DenseField)
    merged.field.F = result.field.F
    merged.field._source_count = result.source_count
    # Carry the encoder from the first cartridge so the merged .rlat is searchable
    merged.encoder = a.encoder

    output = Path(args.output)
    merged.save(output)

    print(f"Merged: {output}")
    print(f"  Sources:      {result.source_count}")
    print(f"  Total energy: {result.total_energy:.4f}")
    print(f"  Per-band:     {result.per_band_energy.tolist()}")


def cmd_forget(args: argparse.Namespace) -> None:
    """Remove a source from a lattice with a RemovalCertificate."""
    from resonance_lattice.lattice import Lattice

    lattice_path = Path(args.lattice)
    lattice = Lattice.load(lattice_path)

    source_id = args.source

    if source_id not in lattice._phase_cache:
        _die(f"source '{source_id}' not found.")

    success = lattice.remove(source_id)
    if success:
        lattice.save(lattice_path)
        print(f"Removed source '{source_id}' from {lattice_path}")
        print(f"  Remaining sources: {lattice.source_count}")
    else:
        _die(f"failed to remove source '{source_id}'.")


def cmd_summary(args: argparse.Namespace) -> None:
    """Generate a pre-injection context primer from a cartridge for CLAUDE.md inclusion.

    Runs multiple broad bootstrap queries against the cartridge and compiles
    the results into a structured markdown document. This is the session-primer
    pattern (TD-10): 3-5 broad queries upfront give the AI instant project
    orientation at 77x less context than file-reading tools.
    """
    lattice_path = Path(args.lattice)
    _require_file(lattice_path)
    lattice = _load_lattice_with_encoder(args, lattice_path)
    info = lattice.info()

    fmt = getattr(args, "format", "context")

    if fmt == "stats":
        # Legacy stats-only output
        lines = [
            f"<!-- Resonance Memory: {lattice_path.name} -->",
            f"<!-- Sources: {info['source_count']} | Field: {info['field_size_mb']:.0f} MB | "
            f"Bands: {info['bands']} x {info['dim']}d -->",
        ]
        print("\n".join(lines))
        return

    # Pre-injection context primer: run broad bootstrap queries
    default_queries = [
        "What is this project about? What problem does it solve and what are the key components?",
        "What is the architecture and how do the main abstractions interact?",
        "What operations, capabilities, and APIs does this system provide?",
        "What are the key design decisions, tradeoffs, and constraints?",
        "What are the important patterns, conventions, and workflows?",
    ]

    queries = default_queries
    if hasattr(args, "queries") and args.queries:
        queries = [q.strip() for q in args.queries.split(";") if q.strip()]

    top_k = getattr(args, "top_k", 20)

    budget = getattr(args, "budget", 2500)

    print(f"Generating context primer from {info['source_count']} sources...", file=sys.stderr)

    # ── Phase 1: Collect results from all bootstrap queries ──
    # Keep the full MaterialisedResult so we have band_scores + metadata
    from resonance_lattice.materialiser import _estimate_tokens, _truncate_to_tokens

    seen: dict[str, tuple[float, object]] = {}  # source_id -> (score, MaterialisedResult)
    for query in queries:
        if lattice.encoder is None:
            print(f"Warning: no encoder available, skipping query: {query[:50]}...", file=sys.stderr)
            break

        result = lattice.resonate_text(query=query, top_k=top_k)
        for r in result.results:
            if not r.content or r.source_id.startswith("__"):
                continue
            text = r.content.full_text or r.content.summary or ""
            if not text:
                continue
            existing = seen.get(r.source_id)
            if existing is None or r.score > existing[0]:
                seen[r.source_id] = (r.score, r)

    # Sort by score descending
    ranked_results = [r for _, r in sorted(seen.values(), key=lambda x: -x[0])]

    # Detect corpus type early so noise filters can adapt
    _CODE_EXTS = {".py", ".js", ".ts", ".go", ".rs", ".java", ".cs", ".rb", ".c", ".cpp", ".h"}
    corpus_has_code = any(
        Path((r.content.metadata or {}).get("source_file", "")).suffix.lower() in _CODE_EXTS
        for r in ranked_results if r.content
    )

    # Code-heavy repos need more token budget for meaningful coverage
    if corpus_has_code and budget == 2500:
        budget = 3500

    # Early noise filter: remove passages that will produce empty summaries
    # so they don't win dedup slots and block useful content from the same file
    def _early_clean(text: str) -> str:
        text = re.sub(r"citeturn\d+view\d+", "", text)
        lines = text.split("\n")
        lines = [l for l in lines if not re.match(r"^\s*#{1,4}\s+\S", l.strip()) and not re.match(r"^[-*_]{3,}\s*$", l.strip())]
        return re.sub(r"\n{3,}", "\n\n", "\n".join(lines)).strip()

    def _early_is_noise(text: str) -> bool:
        lines = [l.strip() for l in text.split("\n") if l.strip()]
        if not lines:
            return True
        toc = sum(1 for l in lines if re.match(r"^\d+\.\s*\[", l) or re.match(r"^-\s*\[.*\]\(.*\)", l))
        if len(lines) > 3 and toc / len(lines) > 0.6:
            return True
        # Import blocks — only filter for code corpora
        if corpus_has_code:
            imp = sum(1 for l in lines if re.match(r"^(import |from |#include )", l))
            if len(lines) > 3 and imp / len(lines) > 0.5:
                return True
        _box = set("│┌┐└┘├┤┬┴┼─▼▲")
        bx = sum(1 for l in lines if any(c in _box for c in l))
        if bx > 8 and bx / len(lines) > 0.4:
            return True
        # Changelog / release notes — version headers, date stamps, "Added/Changed/Fixed"
        changelog_pat = re.compile(
            r"^\[?\d+\.\d+(\.\d+)?\]?\s*[-–—]?\s*\d{4}[-/]|"  # [0.6.0] - 2021-03-17
            r"^#{1,3}\s*\[?\d+\.\d+|"                          # ## [1.2.0]
            r"^(Added|Changed|Fixed|Removed|Deprecated|Security)\b"  # keepachangelog headings
        )
        cl = sum(1 for l in lines if changelog_pat.match(l))
        if len(lines) > 2 and cl / len(lines) > 0.3:
            return True
        # License boilerplate
        lower = text.lower()
        if ("provided by the copyright holders" in lower
                or "permission is hereby granted" in lower
                or "as is" in lower and "warranty" in lower):
            return True
        # YAML/TOML config blocks (indented key-value pairs dominating the passage)
        # Softer threshold for code corpora — config files carry architecture info
        yaml_lines = sum(1 for l in lines if re.match(r"^[\w-]+:\s*([\w\"/']|$)", l))
        yaml_threshold = 0.8 if corpus_has_code else 0.5
        if len(lines) > 4 and yaml_lines / len(lines) > yaml_threshold:
            return True
        return False

    # Source files that are almost always low-orientation (changelogs, migration guides)
    _LOW_VALUE_STEMS = {"changelog", "changes", "history", "migration", "migrating",
                        "upgrading", "upgrade", "release", "releases", "news",
                        "license", "licence", "copying", "notice", "authors",
                        "contributing", "contributors", "pull_request_template",
                        "dependabot", "renovate", "code_of_conduct", "codeowners",
                        "issue_template", "bug_report", "feature_request",
                        "funding", "security", "1-issue", "2-bug"}
    _LOW_VALUE_FILENAMES = {"package-lock.json", "cargo.lock", "go.sum",
                            "tsconfig.json", "jest.config.js", "webpack.config.js",
                            ".eslintrc", ".prettierrc", ".editorconfig",
                            "yarn.lock", "pnpm-lock.yaml", "poetry.lock",
                            "pipfile.lock", "FUNDING.yml", "CODEOWNERS",
                            "codecov.yml", ".codecov.yml"}
    # Directories whose content is almost never orientation-relevant
    _LOW_VALUE_DIRS = {".github", ".circleci", ".buildkite", ".husky"}

    def _is_low_value_source(r) -> bool:
        sf = (r.content.metadata or {}).get("source_file", "") if r.content else ""
        if not sf:
            return False
        p = Path(sf)
        if p.stem.lower() in _LOW_VALUE_STEMS:
            return True
        if p.name.lower() in _LOW_VALUE_FILENAMES:
            return True
        # Files inside .github/ and similar dirs
        sf_lower = sf.lower().replace("\\", "/")
        if any(f"/{d}/" in sf_lower or sf_lower.startswith(f"{d}/") for d in _LOW_VALUE_DIRS):
            return True
        # Test files (multiple naming conventions)
        name_lower = p.name.lower()
        stem_lower = p.stem.lower()
        if (stem_lower.startswith("test_") or stem_lower.endswith("_test")
                or name_lower.endswith(".test.ts") or name_lower.endswith(".test.js")
                or name_lower.endswith(".test.tsx") or name_lower.endswith(".test.jsx")
                or name_lower.endswith("_test.go") or name_lower.endswith("_test.rs")
                or "/test/" in sf_lower or "/tests/" in sf_lower
                or "/__tests__/" in sf_lower):
            return True
        # Fixture / mock / snapshot files
        if any(kw in stem_lower for kw in ("fixture", "mock", "snapshot", "testdata")):
            return True
        return False

    ranked_results = [
        r for r in ranked_results
        if not _early_is_noise(_early_clean(r.content.full_text or r.content.summary or ""))
        and not _is_low_value_source(r)
    ]

    # ── Phase 2: Classify each result into a semantic section ──
    # Determine section list: custom, or auto-detect from corpus
    custom_sections = getattr(args, "sections", None)
    if custom_sections:
        section_names = [s.strip() for s in custom_sections.split(";") if s.strip()]
    else:
        if corpus_has_code:
            section_names = ["Overview", "Architecture", "Patterns & Conventions", "Reference"]
        else:
            section_names = ["Overview", "Key Concepts", "Details", "Reference"]

    sections: dict[str, list] = {name: [] for name in section_names}

    # Build keyword sets for each section for text-based classification
    # For well-known section names, use curated keyword expansions
    # For custom names, use the section name words as keywords
    _SECTION_KEYWORDS: dict[str, set[str]] = {
        "Overview": {"readme", "overview", "introduction", "about", "summary", "what is",
                     "getting started", "thesis", "purpose", "mission"},
        "Architecture": {"architecture", "design", "structure", "component", "layer",
                         "module", "abstractions", "system design", "diagram"},
        "Patterns & Conventions": {"pattern", "convention", "workflow", "practice",
                                   "guideline", "rule", "style", "process"},
        "Reference": {"reference", "api", "function", "class", "method", "endpoint",
                      "parameter", "specification"},
        "Key Concepts": {"concept", "definition", "principle", "theory", "foundation",
                         "fundamental", "model", "framework"},
        "Details": {"detail", "implementation", "analysis", "finding", "result",
                    "evidence", "data", "example", "case"},
        "Methods": {"method", "methodology", "approach", "procedure", "protocol",
                    "technique", "algorithm", "process"},
        "Findings": {"finding", "result", "outcome", "conclusion", "evidence",
                     "observation", "discovery", "insight"},
        "Background": {"background", "context", "history", "prior work", "literature",
                       "motivation", "problem statement"},
    }

    def _keywords_for_section(name: str) -> set[str]:
        """Get keyword set for a section — curated if known, derived if custom."""
        if name in _SECTION_KEYWORDS:
            return _SECTION_KEYWORDS[name]
        # For custom section names, split into lowercase words as keywords
        words = set(name.lower().split())
        # Also add the full lowercase name as a phrase
        words.add(name.lower())
        return words

    section_keywords = {name: _keywords_for_section(name) for name in section_names}

    # Global dedup: each source_file goes to one section only (highest score wins)
    global_file_assignment: dict[str, tuple[float, str]] = {}  # source_file -> (score, section)

    # Check if "Reference" is one of the sections (special handling for code files)
    has_reference_section = "Reference" in sections

    for r in ranked_results:
        meta = r.content.metadata if r.content else {}
        source_file = meta.get("source_file", "").lower()
        heading = meta.get("heading", "").lower()
        chunk_type = meta.get("chunk_type", "doc")
        file_ext = Path(source_file).suffix.lower() if source_file else ""
        file_stem = Path(source_file).stem.lower() if source_file else ""

        # Start with default (last non-Reference section, or first section)
        default_section = section_names[-1] if section_names[-1] != "Reference" else (
            section_names[-2] if len(section_names) > 1 else section_names[0]
        )
        section = default_section

        # README and top-level docs always go to Overview (first section)
        _OVERVIEW_STEMS = {"readme", "index", "overview", "introduction", "about",
                           "getting-started", "getting_started", "quickstart"}
        if file_stem in _OVERVIEW_STEMS and chunk_type == "doc":
            section = section_names[0]
        # Source code files: route to Key APIs if heading matches, else Reference
        elif has_reference_section and (chunk_type == "source" or file_ext in _CODE_EXTS):
            section = "Reference"
            if "Key APIs" in sections and heading:
                api_kws = section_keywords.get("Key APIs", set())
                if any(kw in heading for kw in api_kws):
                    section = "Key APIs"
        else:
            # Score each section by keyword matches in heading, file stem, and content
            # Require at least a heading or file_stem match (score >= 2) to override default
            text_snippet = ((r.content.full_text or "")[:300]).lower() if r.content else ""
            best_score = 0
            for sec_name in section_names:
                if sec_name == "Reference" and has_reference_section:
                    continue  # Reference is handled by file type, not keywords
                kws = section_keywords[sec_name]
                score = 0
                for kw in kws:
                    if kw in heading:
                        score += 3  # heading match is strongest signal
                    if kw in file_stem:
                        score += 2  # file stem is strong signal
                    if kw in text_snippet:
                        score += 1  # content match — weak, tiebreaker only
                if score > best_score and score >= 2:
                    best_score = score
                    section = sec_name

        # Band scores bias (only for default codebase sections)
        if not custom_sections and r.band_scores is not None and len(r.band_scores) >= 3:
            nb = len(r.band_scores)
            low = float(sum(r.band_scores[:min(2, nb)]))
            mid = float(r.band_scores[2]) if nb > 2 else 0.0
            high = float(sum(r.band_scores[min(3, nb):])) if nb > 3 else 0.0
            total = low + mid + high
            if total > 1e-8 and section not in ("Reference",):
                if low / total > 0.55:
                    section = section_names[0]  # first section = overview-like
                elif mid / total > 0.45 and len(section_names) > 1:
                    section = section_names[1]  # second section = architecture-like

        sections[section].append(r)

    # ── Phase 3: Deduplicate ──
    # 3a: Global cross-section dedup — each source_file appears in one section only
    for section_name in sections:
        for r in sections[section_name]:
            sf = (r.content.metadata or {}).get("source_file", r.source_id) if r.content else r.source_id
            prev = global_file_assignment.get(sf)
            if prev is None or r.score > prev[0]:
                global_file_assignment[sf] = (r.score, section_name)

    # Rebuild sections with global assignment
    for section_name in sections:
        sections[section_name] = [
            r for r in sections[section_name]
            if global_file_assignment.get(
                (r.content.metadata or {}).get("source_file", r.source_id) if r.content else r.source_id
            ) == (r.score, section_name)
        ]

    # 3b: Within-section dedup by source_file (keep highest-scoring chunk)
    for section_name in sections:
        by_file: dict[str, object] = {}
        for r in sections[section_name]:
            sf = (r.content.metadata or {}).get("source_file", r.source_id) if r.content else r.source_id
            if sf not in by_file or r.score > by_file[sf].score:
                by_file[sf] = r
        sections[section_name] = sorted(by_file.values(), key=lambda r: -r.score)

    # 3c: Content fingerprint dedup — skip near-duplicate text across sections
    seen_fingerprints: set[str] = set()
    for section_name in list(sections.keys()):
        filtered = []
        for r in sections[section_name]:
            text = (r.content.full_text or r.content.summary or "") if r.content else ""
            # Fingerprint: first 120 chars, stripped of URLs and links for dedup
            fp_text = re.sub(r"https?://\S+", "", text[:200])
            fp_text = re.sub(r"\[([^\]]*)\]\([^)]*\)", r"\1", fp_text)  # [text](url) → text
            fp = re.sub(r"\s+", " ", fp_text[:120]).strip().lower()
            if fp and fp in seen_fingerprints:
                continue
            if fp:
                seen_fingerprints.add(fp)
            filtered.append(r)
        sections[section_name] = filtered

    # ── Phase 3d: Rebalance starved sections ──
    # If Overview or other non-Reference sections are empty/near-empty
    # while Reference is overflowing, promote doc-like Reference results
    non_ref = [n for n in section_names if n != "Reference"]
    non_ref_total = sum(len(sections.get(n, [])) for n in non_ref)
    ref_count = len(sections.get("Reference", []))
    if non_ref_total < 2 and ref_count > 3 and non_ref:
        # Find Reference results from doc files (README, .md, .rst, .txt)
        _DOC_EXTS = {".md", ".rst", ".txt", ".html", ".htm"}
        ref_results = sections.get("Reference", [])
        promoted = []
        kept = []
        for r in ref_results:
            sf = (r.content.metadata or {}).get("source_file", "") if r.content else ""
            ext = Path(sf).suffix.lower() if sf else ""
            if ext in _DOC_EXTS and len(promoted) < 5:
                promoted.append(r)
            else:
                kept.append(r)
        if promoted:
            sections["Reference"] = kept
            target = non_ref[0]  # Put in Overview
            sections[target] = promoted + sections.get(target, [])

    # ── Phase 4: Build output with token budgets ──
    # Distribute budget: first section gets 30% (orientation), Reference gets
    # an adaptive share based on code density, remaining sections split the rest.
    code_result_count = sum(
        1 for sec_results in sections.values()
        for r in sec_results
        if (r.content.metadata or {}).get("chunk_type") == "source" if r.content
    )
    total_result_count = sum(len(v) for v in sections.values())
    code_ratio = code_result_count / max(1, total_result_count)

    def _allocate_budgets(names: list[str], total: int) -> dict[str, int]:
        budgets: dict[str, int] = {}
        remaining = total
        # First section gets orientation bonus
        budgets[names[0]] = int(total * 0.30)
        remaining -= budgets[names[0]]
        # Reference: adaptive — 20% for docs, up to 45% for pure code
        if "Reference" in names:
            ref_pct = 0.20 + 0.25 * code_ratio
            budgets["Reference"] = int(total * ref_pct)
            remaining -= budgets["Reference"]
        # Split the rest evenly among other sections
        others = [n for n in names if n not in budgets]
        if others:
            per_section = remaining // len(others)
            for n in others:
                budgets[n] = per_section
        return budgets

    token_budgets = _allocate_budgets(section_names, budget)

    total_passages = sum(len(v) for v in sections.values())

    lines = [
        f"# Project Memory: {lattice_path.stem}",
        "",
        f"<!-- Auto-generated by `rlat summary` from {lattice_path.name} -->",
        f"<!-- {info['source_count']} sources | {total_passages} passages | "
        f"{info['bands']} bands x {info['dim']}d -->",
        "",
    ]

    def _clean_passage(text: str) -> str:
        """Strip noise from passage text: citation markers, partial tables, embedded headers."""
        # Strip research citation markers (citeturnNviewN patterns)
        text = re.sub(r"citeturn\d+view\d+", "", text)
        lines = text.split("\n")
        cleaned_lines = []
        for line in lines:
            stripped = line.strip()
            # Skip orphaned table separator rows
            if re.match(r"^\|[-\s|:]+\|$", stripped):
                if not cleaned_lines or not cleaned_lines[-1].strip().startswith("|"):
                    continue
            # Skip lines that are just a partial table cell
            if stripped.startswith("|") and stripped.count("|") < 2 and len(stripped) < 40:
                continue
            # Skip embedded markdown section headers (## Foo) — these create fake structure
            if re.match(r"^#{1,4}\s+\S", stripped):
                continue
            # Skip horizontal rules (---, ***)
            if re.match(r"^[-*_]{3,}\s*$", stripped):
                continue
            cleaned_lines.append(line)
        # Strip leading partial table rows / sentence fragments
        while cleaned_lines:
            first = cleaned_lines[0].strip()
            # Skip leading blank lines
            if not first:
                cleaned_lines.pop(0)
                continue
            # Orphaned table cell continuation: ends with | but doesn't start with |
            if first.endswith("|") and not first.startswith("|"):
                cleaned_lines.pop(0)
                continue
            # Short fragment before a table row (passage starts mid-table)
            if (len(cleaned_lines) > 1 and cleaned_lines[1].strip().startswith("|")
                    and not first.startswith("|") and len(first) < 50):
                cleaned_lines.pop(0)
                continue
            # Leading sentence fragment: short, starts lowercase or doesn't start a sentence
            if (first and len(first) < 40 and len(cleaned_lines) > 1
                    and not first[0].isupper() and not first.startswith(("-", "*", "|"))):
                cleaned_lines.pop(0)
                continue
            break
        text = "\n".join(cleaned_lines)
        # Strip leading numbered-list prefix noise (e.g. "1. " at start of passage)
        text = re.sub(r"^\d+\.\s+", "", text)
        # Collapse excessive whitespace
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip()

    def _is_low_signal(text: str) -> bool:
        """Check if passage is mostly structural noise (ToC, imports, diagrams, changelogs)."""
        lines = [l.strip() for l in text.strip().split("\n") if l.strip()]
        if not lines:
            return True
        # Single-char or very short fragments: {, }, ], etc.
        if len(lines) == 1 and len(lines[0]) < 5:
            return True
        # License boilerplate
        lower = text.lower()
        if ("provided by the copyright holders" in lower
                or "permission is hereby granted" in lower
                or "as is" in lower and "warranty" in lower):
            return True
        # YAML config blocks (indented key-value pairs)
        yaml_lines = sum(1 for l in lines if re.match(r"^[\w-]+:\s*([\w\"/']|$)", l) or l.startswith("- "))
        if len(lines) > 3 and yaml_lines / len(lines) > 0.6:
            return True
        # Sphinx/RST directives (:members:, :param:, :type:)
        sphinx_lines = sum(1 for l in lines if re.match(r"^:\w+", l))
        if sphinx_lines > 0 and len(lines) <= 3:
            return True
        # Raw HTTP headers / binary data blobs (b'...' byte string patterns)
        if text.count("b'") > 3:
            return True
        # Table-of-contents: mostly numbered links or bullet links
        toc_lines = sum(1 for l in lines if re.match(r"^\d+\.\s*\[", l) or re.match(r"^-\s*\[.*\]\(.*\)", l))
        if len(lines) > 3 and toc_lines / len(lines) > 0.6:
            return True
        # Changelog / release notes — version entries, date stamps
        _cl_pat = re.compile(
            r"^\[?\d+\.\d+(\.\d+)?\]?\s*[-–—]?\s*\d{4}[-/]|"
            r"^#{1,3}\s*\[?\d+\.\d+|"
            r"^(Added|Changed|Fixed|Removed|Deprecated|Security)\b"
        )
        cl = sum(1 for l in lines if _cl_pat.match(l))
        if len(lines) > 2 and cl / len(lines) > 0.3:
            return True
        # Import blocks: only check for code corpora
        if corpus_has_code:
            import_lines = sum(1 for l in lines if re.match(r"^(import |from |#include )", l))
            if len(lines) > 3 and import_lines / len(lines) > 0.5:
                return True
        # Large ASCII box diagrams: lines containing box-drawing characters
        # Small diagrams (<= 8 lines) can be useful; large ones waste tokens
        _box_chars = set("│┌┐└┘├┤┬┴┼─▼▲")
        box_lines = sum(1 for l in lines if any(c in _box_chars for c in l))
        if box_lines > 8 and box_lines / len(lines) > 0.4:
            return True
        return False

    def _is_config_or_code_fragment(text: str, is_source: bool = False) -> bool:
        """Detect passages that are just config entries or code variable assignments.

        Must distinguish 'Summary: The project does X' (prose — keep) from
        'layout: "diff, flags, files"' (config — filter).  The heuristic:
        if text after the colon contains 5+ space-separated words, it's prose.

        When is_source=True, the content is expected to be code — skip checks
        that penalise brackets and assignments.
        """
        if is_source:
            return False
        stripped = text.strip()
        if not stripped:
            return False
        lines = [l.strip() for l in stripped.split("\n") if l.strip()]
        if not lines:
            return False
        first = lines[0]
        # Short fragments (1-3 lines, <200 chars) — check for config patterns
        if len(lines) <= 3 and len(stripped) < 200:
            m = re.match(r'^([\w.-]+)\s*[:=]\s*(.*)', first)
            if m:
                value_part = m.group(2).strip()
                # Prose with 5+ words is likely documentation, not config
                word_count = len(value_part.split())
                if word_count >= 5:
                    # But pure code lines (type annotations, assignments) look long too.
                    # Heuristic: real prose has articles/prepositions; code has unquoted brackets.
                    # Strip backtick-wrapped code spans before checking for bare code syntax.
                    sans_backticks = re.sub(r'`[^`]+`', '', value_part)
                    has_bare_brackets = bool(re.search(r'[\[\]{}()]', sans_backticks))
                    has_assignment = bool(re.search(r'\b\w+\s*=\s*\w', sans_backticks))
                    if has_bare_brackets or has_assignment:
                        return True
                    return False
                # Short value: likely config (key: "val", key: val)
                return True
        # Mostly code: lines starting with variable assignments, type annotations
        code_pat = re.compile(r'^(\w+\s*[:=]|def |class |if |for |while |return |import |from )')
        code_lines = sum(1 for l in lines if code_pat.match(l))
        if len(lines) > 1 and code_lines / len(lines) > 0.6:
            return True
        return False

    def _trim_to_sentence(text: str) -> str:
        """Trim text to the last complete sentence, avoiding mid-word cuts."""
        if not text:
            return text
        # Already ends with sentence punctuation
        if text.rstrip()[-1:] in ".!?":
            return text.rstrip()
        # Find last sentence boundary (. ! ? followed by space or end)
        for end_char in (".", "!", "?"):
            idx = text.rfind(end_char)
            if idx > len(text) * 0.4:
                return text[:idx + 1]
        # No sentence boundary found — try to end at a newline or list item
        last_nl = text.rfind("\n")
        if last_nl > len(text) * 0.5:
            return text[:last_nl].rstrip()
        return text

    def _effective_summary(r, max_chars: int = 300) -> str:
        """Get a real summary — extract one at read time if summary==full_text."""
        c = r.content
        if not c:
            return ""
        chunk_type = (c.metadata or {}).get("chunk_type", "doc") if c else "doc"
        is_src = chunk_type == "source"
        if c.summary and c.summary != c.full_text:
            cleaned = _clean_passage(c.summary)
            if _is_low_signal(cleaned) or _is_config_or_code_fragment(cleaned, is_source=is_src):
                return ""
            return cleaned
        # Legacy: extract from full_text
        text = c.full_text or c.summary or ""
        if not text:
            return ""
        text = _clean_passage(text)
        if _is_low_signal(text):
            return ""
        # Heading + first sentences
        heading = (c.metadata or {}).get("heading", "")
        # Strip numbered-list prefixes from heading (e.g. "4. Architecture" -> "Architecture")
        if heading:
            heading = re.sub(r"^\d+\.\s+", "", heading)
        body = text
        body_lines = body.split("\n", 1)
        if body_lines and body_lines[0].lstrip().startswith("#"):
            body = body_lines[1].strip() if len(body_lines) > 1 else ""
        if heading and body:
            # Skip headings that are just config keys or variable assignments
            if _is_config_or_code_fragment(heading, is_source=is_src):
                return ""
            prefix = f"{heading}: "
            remaining = max_chars - len(prefix)
            if remaining > 30:
                truncated = _truncate_to_tokens(body, remaining // 4)[:remaining]
                # Ensure we end at a sentence boundary if possible
                truncated = _trim_to_sentence(truncated)
                result = prefix + truncated
                if _is_config_or_code_fragment(result, is_source=is_src):
                    return ""
                return result if len(result) > 30 else ""
        truncated = _truncate_to_tokens(text, max_chars // 4)[:max_chars]
        truncated = _trim_to_sentence(truncated)
        # Skip config-like fragments and bare code assignments
        if _is_config_or_code_fragment(truncated, is_source=is_src):
            return ""
        return truncated if len(truncated) > 30 else ""

    section_order = section_names

    for section_name in section_order:
        results = sections[section_name]
        if not results:
            continue

        token_budget = token_budgets[section_name]
        remaining_tokens = token_budget
        lines.append(f"## {section_name}")
        lines.append("")

        if section_name == "Reference":
            # File list with key headings and summaries
            for r in results:
                if remaining_tokens <= 0:
                    break
                sf = (r.content.metadata or {}).get("source_file", "") if r.content else ""
                heading = (r.content.metadata or {}).get("heading", "") if r.content else ""
                summ = (r.content.summary or "") if r.content else ""
                if sf:
                    # Skip bare entries with no heading and no summary
                    if not heading and (not summ or len(summ) < 20):
                        continue
                    entry = f"- `{Path(sf).name}`"
                    if heading and heading != "module-level":
                        entry += f" — {heading}"
                    # Include summary for richer orientation
                    if summ and len(summ) > 20 and summ != (r.content.full_text or ""):
                        summ_clean = summ.strip().split("\n")[0][:150].strip()
                        # Skip summaries that are just file path comments or imports
                        if (summ_clean and summ_clean not in entry
                                and not summ_clean.startswith("// file:")
                                and not summ_clean.startswith("from ")
                                and not summ_clean.startswith("import ")):
                            entry += f"\n  {summ_clean}"
                    lines.append(entry)
                    remaining_tokens -= _estimate_tokens(entry)
            lines.append("")
        else:
            # Summary bullets for overview/architecture/patterns
            for r in results:
                if remaining_tokens <= 0:
                    break
                summ = _effective_summary(r, max_chars=remaining_tokens * 4)
                if not summ and section_name == section_names[0]:
                    # Overview fallback: strip HTML and use raw text from README/index
                    raw = (r.content.full_text or "") if r.content else ""
                    if raw:
                        # Strip HTML tags, badges, images
                        raw = re.sub(r"<[^>]+>", "", raw)
                        raw = re.sub(r"!\[[^\]]*\]\([^)]*\)", "", raw)  # markdown images
                        raw = re.sub(r"\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)", "", raw)  # badge links
                        raw = raw.strip()
                        if len(raw) > 30:
                            summ = _truncate_to_tokens(raw, min(remaining_tokens, 200))
                            summ = _trim_to_sentence(summ)
                if not summ:
                    continue
                summ = summ.strip().replace("\n\n\n", "\n\n")
                # Always use bullet format; indent continuation lines
                if "\n" in summ:
                    first, rest = summ.split("\n", 1)
                    indented = "\n".join("  " + l for l in rest.split("\n"))
                    entry = f"- {first}\n{indented}"
                else:
                    entry = f"- {summ}"
                tokens_used = _estimate_tokens(entry)
                if tokens_used > remaining_tokens:
                    entry = _truncate_to_tokens(entry, remaining_tokens)
                    tokens_used = _estimate_tokens(entry)
                lines.append(entry)
                lines.append("")
                remaining_tokens -= tokens_used

    source_root = getattr(args, "source_root", None)
    # Use just the filename in the footer command — absolute paths are machine-specific
    resonate_cmd = f'rlat resonate {lattice_path.name} "your question here"'
    if source_root:
        resonate_cmd += f" --source-root {source_root}"
    lines.extend([
        "---",
        "",
        "For deeper context, query the cartridge directly:",
        "```",
        resonate_cmd,
        "```",
    ])

    summary_text = "\n".join(lines)
    est_tokens = _estimate_tokens(summary_text)

    if args.output:
        Path(args.output).write_text(summary_text, encoding="utf-8")
        print(f"Context primer written to {args.output} "
              f"({len(summary_text)} chars, ~{est_tokens} tokens, "
              f"{total_passages} passages from {len(queries)} queries)",
              file=sys.stderr)
    else:
        sys.stdout.buffer.write(summary_text.encode("utf-8"))
        sys.stdout.buffer.write(b"\n")


def cmd_resonate(args: argparse.Namespace) -> None:
    """Query a lattice and return compressed context (optimised for AI tool injection)."""
    lattice_path = Path(args.lattice)
    lattice = _load_lattice_with_encoder(args, lattice_path)

    start = time.perf_counter()
    result = lattice.resonate_text(query=args.query, top_k=args.top_k)
    elapsed = (time.perf_counter() - start) * 1000

    mode = getattr(args, "mode", None)
    system_prompt = _get_system_prompt(mode, getattr(args, "custom_prompt", None)) if mode else None

    if args.format == "json":
        output = {
            "query": args.query,
            "latency_ms": round(elapsed, 2),
            "results": [
                {
                    "source_id": r.source_id,
                    "score": round(r.score, 4),
                    "raw_score": round(r.raw_score, 4) if getattr(r, "raw_score", None) is not None else None,
                    "band_scores": r.band_scores.tolist() if r.band_scores is not None else None,
                    "summary": r.content.summary if r.content else None,
                    "full_text": r.content.full_text if r.content else None,
                    "source_file": (r.content.metadata or {}).get("source_file", "") if r.content else "",
                    "heading": (r.content.metadata or {}).get("heading", "") if r.content else "",
                    "provenance": getattr(r, "provenance", "dense"),
                }
                for r in result.results
            ],
            "coverage": None,
            "related": None,
            "contradictions": None,
        }
        if system_prompt:
            output["mode"] = mode
            output["system_prompt"] = system_prompt
        print(json.dumps(output, indent=2))
    elif args.format == "context":
        if system_prompt:
            print(f"[System: {mode}]")
            print(system_prompt)
            print()
        lines = []
        for r in result.results[:args.top_k]:
            if r.content:
                text = r.content.full_text or r.content.summary or ""
                if text:
                    lines.append(f"- [{r.score:.2f}] {text}")
        print("\n".join(lines))
    elif args.format == "prompt":
        payload = {
            "query": args.query,
            "results": [
                {
                    "source_id": r.source_id,
                    "score": round(r.score, 4),
                    "summary": r.content.summary if r.content else None,
                    "full_text": r.content.full_text if r.content else None,
                    "source_file": (r.content.metadata or {}).get("source_file", "") if r.content else "",
                    "heading": (r.content.metadata or {}).get("heading", "") if r.content else "",
                }
                for r in result.results
            ],
            "coverage": {},
            "related_topics": [],
            "contradictions": [],
        }
        print(_dict_to_prompt(payload))
    else:
        if system_prompt:
            print(f"[Mode: {mode}]\n")
        for i, r in enumerate(result.results, 1):
            text = (r.content.full_text or r.content.summary or "")[:500] if r.content else ""
            print(f"  {i}. [{r.score:.4f}] {r.source_id}: {text}")


def _read_source_file(path: Path) -> str:
    """Read a source file, dispatching by extension for binary formats."""
    from resonance_lattice.store import ExternalStore
    ext = path.suffix.lower()
    if ext == ".csv":
        return ExternalStore._read_csv(path)
    elif ext == ".tsv":
        return ExternalStore._read_csv(path, delimiter="\t")
    elif ext == ".docx":
        return ExternalStore._read_docx(path)
    elif ext == ".pdf":
        return ExternalStore._read_pdf(path)
    elif ext in (".xlsx", ".xls"):
        return ExternalStore._read_xlsx(path)
    else:
        return path.read_text(encoding="utf-8", errors="replace")


def _ingest_files_incremental(lattice, files: list[Path], manifest: FileManifest,
                               encoder_fp: str = "",
                               progress: bool = False,
                               format_override: str = "",
                               session: str = "",
                               timestamp: str = "") -> tuple[int, int, int]:
    """Ingest files incrementally using the manifest. Returns (added, updated, skipped).

    Args:
        format_override: Force a specific chunker (e.g. "conversation").
        session: Session ID to annotate all chunks with.
        timestamp: ISO timestamp to annotate all chunks with.
    """
    from resonance_lattice.chunker import auto_chunk, chunk_conversation, contextualize_chunk, generate_summary

    added = updated = skipped = 0
    total = len(files)

    if progress:
        file_iter = files
    else:
        try:
            from tqdm import tqdm
            file_iter = tqdm(files, desc="Encoding", unit="file", file=sys.stderr)
        except ImportError:
            file_iter = files

    for idx, f in enumerate(file_iter):
        key = _canonical_path(f)
        content_hash = FileManifest.hash_file(f)

        if not manifest.needs_update(key, content_hash, encoder_fp):
            skipped += 1
            if progress:
                print(json.dumps({"phase": "encoding", "current": idx + 1, "total": total,
                                  "file": f.name, "status": "skipped"}), flush=True)
            continue

        # Remove old chunks if updating
        old_ids = manifest.remove_file(key)
        is_update = len(old_ids) > 0
        for sid in old_ids:
            lattice.remove(sid)

        # Chunk and encode — use format-aware reader for binary files
        text = _read_source_file(f)
        if format_override == "conversation":
            chunks = chunk_conversation(
                text, source_file=str(f),
                session_id=session, timestamp=timestamp,
            )
        else:
            chunks = auto_chunk(text, source_file=str(f), format_override=format_override)

        chunk_ids = []
        batch_texts = []
        batch_encode_texts = []
        batch_sids = []
        batch_metas = []
        batch_summaries = []
        for i, chunk in enumerate(chunks):
            slug = chunk.heading[:40].replace(" ", "_").lower() if chunk.heading else ""
            path_hash = _hashlib.md5(key.encode()).hexdigest()[:4]
            sid = f"{f.stem}_{slug}_{path_hash}_{i:04d}" if slug else f"{f.stem}_{path_hash}_{i:04d}"

            # Build metadata: base fields + chunk-level metadata (conversation fields, etc.)
            meta = {
                "source_file": str(f),
                "heading": chunk.heading,
                "chunk_type": chunk.chunk_type,
            }
            if chunk.metadata:
                meta.update(chunk.metadata)
            # CLI-level overrides for session/timestamp
            if session and "session_id" not in meta:
                meta["session_id"] = session
            if timestamp and "timestamp" not in meta:
                meta["timestamp"] = timestamp

            # Contextual chunking: prepend file/heading/position context
            # so the encoder captures WHERE the chunk came from.
            # Clean text stored for display; contextual text used for encoding.
            contextual_text = contextualize_chunk(
                chunk, total_chunks=len(chunks), chunk_index=i,
            )
            batch_texts.append(chunk.text)
            batch_encode_texts.append(contextual_text)
            batch_sids.append(sid)
            batch_metas.append(meta)
            batch_summaries.append(generate_summary(chunk))
            chunk_ids.append(sid)

        if batch_texts:
            lattice.superpose_text_batch(
                texts=batch_texts,
                source_ids=batch_sids,
                metadatas=batch_metas,
                summaries=batch_summaries,
                encode_texts=batch_encode_texts,
            )

        manifest.record(key, content_hash, chunk_ids, encoder_fp)
        if is_update:
            updated += 1
        else:
            added += 1
        if progress:
            print(json.dumps({"phase": "encoding", "current": idx + 1, "total": total,
                              "file": f.name, "status": "updated" if is_update else "added",
                              "chunks": len(chunk_ids)}), flush=True)

    return added, updated, skipped


def cmd_add(args: argparse.Namespace) -> None:
    """Incrementally add files to an existing cartridge."""
    lattice_path = Path(args.lattice)
    if not lattice_path.exists():
        _die(f"{lattice_path} not found. Use 'rlat build' to create a new cartridge.")

    lattice = _load_lattice_with_encoder(args, lattice_path)
    manifest = _load_manifest(lattice)
    encoder_fp = _encoder_fingerprint(lattice.encoder) if lattice.encoder else ""
    _check_encoder_consistency(manifest, encoder_fp, lattice=lattice)

    input_paths = [Path(s) for s in args.inputs]
    files = _collect_files(input_paths)
    if not files:
        print("No files found to add.", file=sys.stderr)
        sys.exit(1)

    fmt = getattr(args, "input_format", "")
    session = getattr(args, "session", "")
    ts = getattr(args, "timestamp", "")

    start = time.time()
    added, updated, skipped = _ingest_files_incremental(
        lattice, files, manifest, encoder_fp,
        format_override=fmt, session=session, timestamp=ts,
    )
    elapsed = time.time() - start

    _save_manifest(lattice, manifest)
    lattice.save(lattice_path)

    total = added + updated
    print(f"{_C.green(str(total))} chunks added" if total else "No new files to add.", end="")
    if skipped:
        print(f"  ({_C.dim(f'{skipped} unchanged, skipped')})", end="")
    if updated:
        print(f"  ({_C.yellow(f'{updated} updated')})", end="")
    print(f"  {_C.dim(f'in {elapsed:.1f}s')}")
    print(f"  Sources: {lattice.source_count}")


def cmd_sync(args: argparse.Namespace) -> None:
    """Sync a cartridge with source directories: add new, update changed, remove deleted."""
    lattice_path = Path(args.lattice)
    if not lattice_path.exists():
        _die(f"{lattice_path} not found. Use 'rlat build' to create a new cartridge.")

    lattice = _load_lattice_with_encoder(args, lattice_path)
    manifest = _load_manifest(lattice)
    encoder_fp = _encoder_fingerprint(lattice.encoder) if lattice.encoder else ""
    _check_encoder_consistency(manifest, encoder_fp, lattice=lattice)

    input_paths = [Path(s) for s in args.inputs]
    files = _collect_files(input_paths)
    current_files = {_canonical_path(f) for f in files}

    progress = getattr(args, "progress", False)

    # Phase 1: detect deleted files
    removed = 0
    for known_file in list(manifest.known_files()):
        if known_file not in current_files:
            old_ids = manifest.remove_file(known_file)
            for sid in old_ids:
                lattice.remove(sid)
            removed += 1

    if progress:
        print(json.dumps({"phase": "scanning", "total_files": len(files), "removed": removed}), flush=True)

    # Phase 2: add new + update changed
    fmt = getattr(args, "input_format", "")
    session = getattr(args, "session", "")
    ts = getattr(args, "timestamp", "")

    start = time.time()
    added, updated, skipped = _ingest_files_incremental(
        lattice, files, manifest, encoder_fp, progress=progress,
        format_override=fmt, session=session, timestamp=ts,
    )
    elapsed = time.time() - start

    _save_manifest(lattice, manifest)
    if progress:
        print(json.dumps({"phase": "saving"}), flush=True)
    lattice.save(lattice_path)

    if progress:
        print(json.dumps({"phase": "done", "added": added, "updated": updated,
                          "removed": removed, "skipped": skipped,
                          "sources": lattice.source_count,
                          "elapsed": round(elapsed, 1)}), flush=True)
    else:
        parts = []
        if added:
            parts.append(_C.green(f"+{added} added"))
        if updated:
            parts.append(_C.yellow(f"~{updated} updated"))
        if removed:
            parts.append(_C.red(f"-{removed} removed"))
        if skipped:
            parts.append(_C.dim(f"{skipped} unchanged"))

        print("  ".join(parts) if parts else "Nothing to sync.")
        print(f"  Sources: {lattice.source_count}  {_C.dim(f'in {elapsed:.1f}s')}")

    # Update manifest if cartridge is in a .rlat/ directory
    if lattice_path.parent.name == ".rlat" or lattice_path.suffix == ".rlat":
        try:
            from resonance_lattice.discover import update_manifest
            manifest_dir = lattice_path.parent if lattice_path.parent.name == ".rlat" else lattice_path.parent
            manifest_path = manifest_dir / "manifest.json"
            update_manifest(manifest_path, lattice_path, source_count=lattice.source_count)
        except Exception:
            pass


def cmd_compare(args: argparse.Namespace) -> None:
    """Compare two cartridges: what they share, what's unique to each."""
    from resonance_lattice.lattice import Lattice

    path_a, path_b = Path(args.lattice_a), Path(args.lattice_b)
    _require_file(path_a)
    _require_file(path_b)
    a = Lattice.load(path_a, restore_encoder=False)
    b = Lattice.load(path_b, restore_encoder=False)

    comparison = Lattice.compare(a, b)

    if args.format == "json":
        print(json.dumps(comparison, indent=2))
    else:
        print(f"Comparing: {args.lattice_a} ({comparison['a_sources']} sources) vs {args.lattice_b} ({comparison['b_sources']} sources)")
        print()
        for line in comparison["summary_lines"]:
            print(line)
        print()
        print("Per-band detail:")
        for bp in comparison["per_band"]:
            print(f"  {bp['name']}: overlap={bp['overlap']:.0%}  A={bp['energy_a']:.2f}  B={bp['energy_b']:.2f}  "
                  f"A-B={bp['diff_a_minus_b']:.2f}  B-A={bp['diff_b_minus_a']:.2f}")


def cmd_ls(args: argparse.Namespace) -> None:
    """List sources in a cartridge."""
    from resonance_lattice.lattice import Lattice

    lattice_path = Path(args.lattice)
    _require_file(lattice_path)
    lattice = Lattice.load(lattice_path, restore_encoder=False)

    source_ids = lattice.store.all_ids()
    # Filter out internal entries
    source_ids = [sid for sid in source_ids if not sid.startswith("__")]

    # Apply grep filter if provided
    pattern = getattr(args, "grep", None)
    if pattern:
        source_ids = [sid for sid in source_ids if pattern.lower() in sid.lower()]

    total = len(source_ids)

    # Apply head limit
    head = getattr(args, "head", None)
    if head is not None and head > 0:
        source_ids = source_ids[:head]

    if args.format == "json":
        output = {
            "lattice": str(lattice_path),
            "source_count": total,
            "shown": len(source_ids),
            "sources": source_ids,
        }
        print(json.dumps(output, indent=2))
    else:
        label = f"Sources in {lattice_path} ({total})"
        if pattern:
            label += f" matching '{pattern}'"
        if head and head < total:
            label += f" (showing first {head})"
        print(f"{label}:\n")
        for sid in source_ids:
            if args.verbose:
                content = lattice.store.retrieve(sid)
                summary = (content.summary[:80] if content and content.summary else "")
                print(f"  {sid}  {summary}")
            else:
                print(f"  {sid}")


def cmd_profile(args: argparse.Namespace) -> None:
    """Show semantic profile of a cartridge."""
    from resonance_lattice.calculus import FieldCalculus
    from resonance_lattice.field.dense import DenseField
    from resonance_lattice.lattice import BAND_NAMES, Lattice

    lattice_path = Path(args.lattice)
    _require_file(lattice_path)
    lattice = Lattice.load(lattice_path, restore_encoder=False)
    info = lattice.info()

    if not isinstance(lattice.field, DenseField):
        print(f"Profile requires DenseField backend (got {info['field_type']})", file=sys.stderr)
        sys.exit(1)

    B = lattice.config.bands
    band_names = list(BAND_NAMES[:B])
    if B > len(BAND_NAMES):
        band_names.extend(f"band_{i}" for i in range(len(BAND_NAMES), B))

    profile = {
        "lattice": str(lattice_path),
        "source_count": info["source_count"],
        "bands": B,
        "dim": lattice.config.dim,
        "field_size_mb": round(info["field_size_mb"], 1),
        "snr": round(info["snr"], 1),
        "band_profiles": [],
    }

    for b in range(B):
        fc = FieldCalculus.field_confidence(lattice.field, band=b, top_k=10)
        topo = lattice.eigendecompose(band=b, top_k=5)
        profile["band_profiles"].append({
            "band": b,
            "name": band_names[b],
            "energy": round(float(info["field_energy"][b]), 4),
            "effective_rank": round(fc.effective_rank, 1),
            "spectral_entropy": round(fc.spectral_entropy, 4),
            "condition_number": round(fc.condition_number, 1),
            "top_eigenvalues": [round(float(v), 4) for v in topo["eigenvalues"][:5]],
        })

    # Spectral community detection
    try:
        communities = lattice.detect_communities(n_communities=8, band=0)
        profile["communities"] = communities
    except Exception:
        logger.debug("Community detection failed", exc_info=True)
        communities = None

    if args.format == "json":
        print(json.dumps(profile, indent=2))
    else:
        print(f"Semantic Profile: {lattice_path}")
        print(f"  Sources: {info['source_count']} | Field: {info['field_size_mb']:.1f} MB | SNR: {info['snr']:.1f}")
        print()
        for bp in profile["band_profiles"]:
            print(f"  Band {bp['band']} ({bp['name']}):")
            print(f"    Energy:           {bp['energy']:.4f}")
            print(f"    Effective rank:   {bp['effective_rank']:.1f}")
            print(f"    Spectral entropy: {bp['spectral_entropy']:.4f}")
            print(f"    Condition number: {bp['condition_number']:.1f}")
            print(f"    Top eigenvalues:  {bp['top_eigenvalues']}")
            print()

        if communities and communities.get("communities"):
            print(f"  Topic Communities ({communities['n_communities']} detected):")
            print()
            for c in communities["communities"]:
                pct = c["fraction"] * 100
                coh = c["coherence"]
                reps = c["representatives"][:3]
                print(f"    Community {c['rank']:2d}: {c['size']:5d} sources ({pct:4.1f}%)  coherence={coh:.2f}")
                print(f"      Representatives: {', '.join(reps[:3])}")
            print()


def _dict_to_prompt(payload: dict) -> str:
    """Render prompt-oriented text from an EnrichedResult dict.

    Mirrors ``EnrichedResult.to_prompt()`` so that warm and cold paths
    produce contract-compatible output for ``--format prompt``.
    """
    lines: list[str] = []
    coverage = payload.get("coverage", {})
    confidence = coverage.get("confidence", 0)
    lines.append(f"## Resonance Results (confidence: {confidence:.0%})")
    lines.append("")

    # Coverage bars
    names, vals = _parse_band_energies(coverage)
    max_e = max(max(vals), 1e-8) if vals else 1e-8
    for name, energy in zip(names, vals):
        frac = energy / max_e
        bar = _safe_bar(frac, width=20)
        lines.append(f"  {name:<12} {bar} {energy:.2f}")
    lines.append("")

    gaps = coverage.get("gaps", [])
    if gaps:
        lines.append(f"**Knowledge gaps**: {', '.join(gaps)}")
        lines.append("")

    # Passages
    lines.append("### Passages")
    for i, r in enumerate(payload.get("results", []), 1):
        text = r.get("full_text", "") or r.get("summary", "") or ""
        band_scores = r.get("band_scores")
        band_str = ""
        if band_scores:
            band_str = f" bands=[{', '.join(f'{s:.2f}' for s in band_scores)}]"
        score = r.get("score", 0)
        raw_score = r.get("raw_score")
        score_str = f"{score:.3f}"
        if raw_score is not None:
            score_str += f", raw={raw_score:.3f}"
        # Display name
        source_file = r.get("source_file", "")
        heading = r.get("heading", "")
        stem = Path(source_file).stem if source_file else ""
        if stem and heading:
            display = f"{stem} / {heading}"
        elif stem:
            display = stem
        elif heading:
            display = heading
        else:
            display = r.get("source_id", "")
        lines.append(f"[{i}] ({score_str}{band_str}) {display}")
        if text:
            lines.append(f"    {_truncate(text, 500)}")
        lines.append("")

    # Related topics
    related = payload.get("related", []) or payload.get("related_topics", [])
    if related:
        lines.append("### Related Topics (via cascade)")
        for rt in related:
            summary = rt.get("summary", "") or ""
            sid = rt.get("source_id", "")
            hop = rt.get("hop", 0)
            score = rt.get("score", 0)
            lines.append(f"  - (hop {hop}, {score:.3f}) {sid}: {summary[:200]}")
        lines.append("")

    # Contradictions
    contradictions = payload.get("contradictions", [])
    if contradictions:
        lines.append("### Contradictions Detected")
        for c in contradictions:
            src_a = c.get("source_a", "")
            src_b = c.get("source_b", "")
            interf = c.get("interference", 0)
            lines.append(f"  \u26a1 {src_a} vs {src_b} (interference: {interf:.3f})")
            if c.get("summary_a"):
                lines.append(f"    A: {c['summary_a'][:150]}")
            if c.get("summary_b"):
                lines.append(f"    B: {c['summary_b'][:150]}")
        lines.append("")

    return "\n".join(lines)


def _output_search(args: argparse.Namespace, payload: dict, load_ms: float, warm: bool) -> None:
    """Format and print search results.

    *payload* is the dict form of an EnrichedResult (from to_dict() or
    from a warm worker JSON response).
    """
    if args.format == "json":
        payload["load_ms"] = round(load_ms, 2)
        payload["warm"] = warm
        print(json.dumps(payload, indent=2))
        return

    if args.format == "prompt":
        mode = getattr(args, "mode", None)
        system_prompt = _get_system_prompt(mode, getattr(args, "custom_prompt", None)) if mode else None
        if system_prompt:
            print(f"[System: {mode}]")
            print(system_prompt)
            print()
        print(_dict_to_prompt(payload))
        return

    if args.format == "context":
        mode = getattr(args, "mode", None)
        system_prompt = _get_system_prompt(mode, getattr(args, "custom_prompt", None)) if mode else None
        if system_prompt:
            print(f"[System: {mode}]")
            print(system_prompt)
            print()
        lines = []
        for r in payload.get("results", []):
            if isinstance(r, dict):
                text = r.get("full_text", "") or r.get("summary", "") or ""
                score = r.get("score", 0)
            else:
                text = (r.content.full_text or r.content.summary or "") if r.content else ""
                score = r.score
            if text:
                lines.append(f"- [{score:.2f}] {text}")
        print("\n".join(lines))
        return

    # ── text format ──
    query = payload.get("query", "")
    results = payload.get("results", [])
    coverage = payload.get("coverage", {})
    latency_ms = payload.get("latency_ms", 0)
    contradictions = payload.get("contradictions", [])
    related = payload.get("related_topics", []) or payload.get("related", [])
    timings_ms = payload.get("timings_ms")

    print()
    print(f"  {_C.bold(query)}")
    print()

    n = len(results)
    conf = coverage.get("confidence", 0)
    warm_label = _C.green("warm") if warm else f"cold, load: {load_ms:.0f}ms"
    print(f"  {_C.dim(f'{latency_ms:.0f}ms')} {_C.dim(f'({warm_label})')} {_C.dim('|')} {n} results {_C.dim('|')} confidence {_C.cyan(f'{conf:.0%}')}")

    # ── Query profile: confidence · source spread · match type ──
    unique_sources = set()
    scores = []
    for r in results:
        if isinstance(r, dict):
            sf = r.get("source_file", "")
            scores.append(r.get("score", 0))
        else:
            sf = (r.content.metadata or {}).get("source_file", "") if r.content else ""
            scores.append(r.score)
        if sf:
            unique_sources.add(Path(sf).stem)
    n_sources = len(unique_sources)
    source_label = f"{n_sources} source{'s' if n_sources != 1 else ''}"

    # Match type from score distribution
    if len(scores) >= 2:
        top5 = scores[:min(5, len(scores))]
        mean_top5 = sum(top5) / len(top5)
        if conf < 0.3:
            match_type = "weak match"
        elif mean_top5 > 0.7:
            match_type = "broad match"
        elif scores[0] - scores[1] > 0.4:
            match_type = "needle"
        else:
            match_type = "focused match"
    elif scores:
        match_type = "single hit"
    else:
        match_type = "no match"

    print(f"  {_C.dim(source_label)} {_C.dim(chr(0xB7))} {_C.dim(match_type)}")

    # ── Topic clustering: extract category from source_file paths ──
    category_counts: dict[str, int] = {}
    all_parts: list[tuple[str, ...]] = []
    for r in results:
        if isinstance(r, dict):
            sf = r.get("source_file", "")
        else:
            sf = (r.content.metadata or {}).get("source_file", "") if r.content else ""
        if sf:
            all_parts.append(Path(sf).parts)
    # Strip the longest common directory prefix so categories reflect
    # the first *differentiating* directory, regardless of corpus depth.
    if all_parts:
        prefix_len = 0
        for level_parts in zip(*all_parts):
            if len(set(level_parts)) == 1:
                prefix_len += 1
            else:
                break
        for parts in all_parts:
            remaining = parts[prefix_len:-1]  # strip prefix and filename
            if remaining:
                cat = remaining[0].replace("_", " ").replace("-", " ").title()
                category_counts[cat] = category_counts.get(cat, 0) + 1
    if category_counts:
        sorted_cats = sorted(category_counts.items(), key=lambda x: x[1], reverse=True)
        cluster_parts = [f"{cat}({count})" for cat, count in sorted_cats[:5]]
        print(f"  {_C.dim('topics: ' + '  '.join(cluster_parts))}")
    print()

    # ── Results ──
    for i, r in enumerate(results, 1):
        # r may be a dict (from to_dict() or warm worker) or a MaterialisedResult object
        if isinstance(r, dict):
            source_id = r.get("source_id", "")
            score = r.get("score", 0)
            raw_score = r.get("raw_score")
            # to_dict() flattens content fields to top level
            full_text = r.get("full_text", "") or r.get("summary", "") or ""
            source_file = r.get("source_file", "")
            heading = r.get("heading", "")
            provenance = r.get("provenance", "dense")
        else:
            source_id = r.source_id
            score = r.score
            raw_score = getattr(r, "raw_score", None)
            full_text = (r.content.full_text or r.content.summary or "") if r.content else ""
            metadata = (r.content.metadata or {}) if r.content else {}
            source_file = metadata.get("source_file", "")
            heading = metadata.get("heading", "")
            provenance = getattr(r, "provenance", "dense")

        # Human-readable name
        stem = Path(source_file).stem if source_file else ""
        if stem and heading:
            name = f"{stem} / {heading}"
        elif stem:
            name = stem
        elif heading:
            name = heading
        else:
            name = source_id

        text = _truncate(_clean_passage(full_text), 160) if full_text else ""

        score_color = _C.green if score > 0.3 else (_C.yellow if score > 0.1 else _C.dim)
        score_text = f"{score:.3f}"
        if raw_score is not None and getattr(args, "verbose", False):
            score_text += f" (raw {raw_score:.3f})"
        prov_tag = ""
        if provenance in ("keyword", "hybrid"):
            prov_tag = f" {_C.yellow(f'[{provenance}]')}"
        print(f"  {_C.dim(f'{i:>2}.')} {score_color(score_text)}  {_C.bold(name)}{prov_tag}")
        if text:
            print(f"      {_C.dim(text)}")
        if source_file:
            print(f"      {_C.cyan(source_file)}")

    # ── Related ──
    if related:
        print()
        print(f"  {_C.dim('Related:')}")
        for rt in related:
            if isinstance(rt, dict):
                summary = rt.get("summary", "") or ""
                sid = rt.get("source_id", "")
            else:
                summary = ""
                if hasattr(rt, "content") and rt.content:
                    summary = rt.content.summary or ""
                elif hasattr(rt, "summary") and rt.summary:
                    summary = rt.summary
                sid = rt.source_id
            if summary:
                label = _truncate(_clean_passage(summary), 100)
            else:
                sid_parts = sid.split("_")
                label = sid_parts[0] if sid_parts else sid
            print(f"    {_C.dim('-')} {label}")

    # ── Contradictions ──
    if contradictions:
        print()
        print(f"  {_C.red('Contradictions:')}")
        for c in contradictions:
            if isinstance(c, dict):
                sa = _truncate(_clean_passage(c.get("summary_a", "") or ""), 80) or c.get("source_a", "")
                sb = _truncate(_clean_passage(c.get("summary_b", "") or ""), 80) or c.get("source_b", "")
            else:
                sa = _truncate(_clean_passage(c.summary_a), 80) if c.summary_a else c.source_a
                sb = _truncate(_clean_passage(c.summary_b), 80) if c.summary_b else c.source_b
            print(f"    {sa}")
            print(f"    {_C.red('vs')} {sb}")

    print()

    # ── Verbose timing ──
    if os.environ.get("RLAT_VERBOSE") and timings_ms:
        t = timings_ms
        parts = (
            f"load={load_ms:.0f} encode={t['encode']:.0f} resonate={t['resonate']:.0f} "
            f"registry={t['registry']:.0f} store={t['store']:.0f} "
            f"cascade={t['cascade']:.0f} total={t['total']:.0f}ms"
        )
        print(f"  {_C.dim(parts)}")


def _apply_memory_filters(payload: dict, args: argparse.Namespace) -> dict:
    """Apply conversation memory filters (session, time range, speaker, recency) to search results."""
    session_filter = getattr(args, "session", None)
    after_filter = getattr(args, "after", None)
    before_filter = getattr(args, "before", None)
    speaker_filter = getattr(args, "speaker", None)
    recency_weight = getattr(args, "recency_weight", 0.0)

    if not any([session_filter, after_filter, before_filter, speaker_filter, recency_weight]):
        return payload

    results = payload.get("results", [])
    filtered = []
    for r in results:
        meta = r.get("metadata", {})
        # If result has no metadata, check source_file and other top-level fields
        if not meta:
            # Try to extract from content metadata if available
            content = r.get("content_metadata", {})
            if content:
                meta = content

        if session_filter and meta.get("session_id") != session_filter:
            continue
        if speaker_filter and meta.get("speaker") != speaker_filter:
            continue
        if after_filter and meta.get("timestamp", "") and meta["timestamp"] < after_filter:
            continue
        if before_filter and meta.get("timestamp", "") and meta["timestamp"] > before_filter:
            continue
        filtered.append(r)

    # Apply recency weighting
    if recency_weight > 0:
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc).isoformat()
        for r in filtered:
            meta = r.get("metadata", r.get("content_metadata", {}))
            ts = meta.get("timestamp", "")
            if ts:
                try:
                    t = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                    age_days = (datetime.now(timezone.utc) - t).total_seconds() / 86400
                    # Exponential decay: recency_score = exp(-age_days / 30)
                    import math
                    recency_score = math.exp(-age_days / 30)
                    original_score = r.get("score", 0.0)
                    r["score"] = (1 - recency_weight) * original_score + recency_weight * recency_score
                except (ValueError, TypeError):
                    pass
        # Re-sort by blended score
        filtered.sort(key=lambda r: r.get("score", 0.0), reverse=True)

    payload["results"] = filtered
    return payload


def cmd_search(args: argparse.Namespace) -> None:
    """Enriched search: passages + coverage + optional cascade and contradictions."""
    if not args.query or not args.query.strip():
        _die("query must not be empty")
    lattice_path = Path(args.lattice)
    _require_file(lattice_path)
    worker_ok = not getattr(args, "no_worker", False) and not os.environ.get("RLAT_NO_WORKER")

    # ── Warm path: try to reuse a running compatible worker ──
    if worker_ok:
        try:
            from resonance_lattice.worker import (
                cleanup_stale,
                probe,
                read_state,
                spawn_worker,
                warm_search,
                worker_key,
            )
            key = worker_key(lattice_path, getattr(args, "encoder", None), getattr(args, "checkpoint", None), source_root=getattr(args, "source_root", None))
            state = read_state(key)
            if state and probe(state["port"]):
                _rerank = getattr(args, "rerank", "auto")
                _rerank_val = "auto" if _rerank == "auto" else _rerank == "true"
                params = {
                    "text": args.query,
                    "top_k": args.top_k,
                    "cascade_depth": args.cascade_depth,
                    "contradiction_threshold": args.contradiction_threshold,
                    "enable_cascade": not args.no_cascade,
                    "enable_contradictions": args.enable_contradictions,
                    "enable_rerank": _rerank_val,
                    "enable_subgraph": getattr(args, "subgraph", False),
                    "subgraph_context_k": getattr(args, "subgraph_k", 3),
                }
                result = warm_search(state["port"], params)
                if result is not None:
                    result = _apply_memory_filters(result, args)
                    _output_search(args, result, load_ms=0, warm=True)
                    return
        except Exception:
            pass  # Any failure in warm path falls through to cold

    # ── Check for composition flags ──
    with_cartridges = getattr(args, "with_cartridges", []) or []
    through_cartridge = getattr(args, "through", None)
    diff_cartridge = getattr(args, "diff_against", None)
    boost_topics = getattr(args, "boost_topics", []) or []
    suppress_topics = getattr(args, "suppress_topics", []) or []
    boost_strength = getattr(args, "boost_strength", 0.5)
    suppress_strength = getattr(args, "suppress_strength", 0.3)
    explain_mode = getattr(args, "explain", False)
    has_composition = bool(with_cartridges or through_cartridge or diff_cartridge)
    lens_arg = getattr(args, "lens", None)
    has_sculpting = bool(boost_topics or suppress_topics)
    has_lens = bool(lens_arg)

    if has_composition or has_sculpting or has_lens:
        # ── Composition / sculpting path ──
        from resonance_lattice.composition import ComposedCartridge

        t_load_start = time.perf_counter()
        primary = _load_lattice_with_encoder(args, lattice_path)

        if through_cartridge:
            # Semantic projection: primary through lens
            lens_path = Path(through_cartridge)
            _require_file(lens_path)
            lens_lattice = _load_lattice_with_encoder(args, lens_path)
            composed = ComposedCartridge.project(
                source={lattice_path.stem: primary},
                lens={lens_path.stem: lens_lattice},
            )
        elif diff_cartridge:
            # Semantic diff: primary minus baseline
            baseline_path = Path(diff_cartridge)
            _require_file(baseline_path)
            baseline = _load_lattice_with_encoder(args, baseline_path)
            composed = ComposedCartridge.diff(
                newer={lattice_path.stem: primary},
                older={baseline_path.stem: baseline},
            )
        elif with_cartridges:
            # Merge: primary + additional cartridges
            constituents = {lattice_path.stem: primary}
            for extra_path_str in with_cartridges:
                extra_path = Path(extra_path_str)
                _require_file(extra_path)
                extra = _load_lattice_with_encoder(args, extra_path)
                constituents[extra_path.stem] = extra
            composed = ComposedCartridge.merge(constituents)
        else:
            # Sculpting only — wrap single cartridge as composed
            composed = ComposedCartridge.merge({lattice_path.stem: primary})

        # Apply topic sculpting if requested
        if has_sculpting:
            composed = composed.sculpt_topics(
                boost_topics=boost_topics,
                suppress_topics=suppress_topics,
                boost_strength=boost_strength,
                suppress_strength=suppress_strength,
            )

        # Apply knowledge lens if requested
        if has_lens:
            from resonance_lattice.lens import Lens, LensBuilder, LensOp
            if lens_arg in ("sharpen", "flatten", "denoise"):
                lens = getattr(LensBuilder, lens_arg)()
            elif Path(lens_arg).suffix == ".rlens" and Path(lens_arg).exists():
                lens = Lens.load(lens_arg)
            else:
                _die(f"Unknown lens: {lens_arg}. Use a .rlens file or one of: sharpen, flatten, denoise")
            # Apply lens to the composed field
            from resonance_lattice.composition.composed import ComposedCartridge as _CC
            viewed_field = lens.apply(composed.composed_field)
            composed = _CC(composed._constituents, viewed_field, composed._composition_type)

        load_ms = (time.perf_counter() - t_load_start) * 1000

        # Show composition diagnostics if --explain
        if explain_mode:
            from resonance_lattice.composition.diagnostics import (
                diagnose_composition,
                format_diagnostics,
            )
            diag = diagnose_composition(
                composed._constituents,
                composed_field=composed.composed_field,
            )
            sys.stderr.write(format_diagnostics(diag))
            if has_sculpting:
                sculpt_info = []
                if boost_topics:
                    sculpt_info.append(f"Boosted: {', '.join(boost_topics)} (strength={boost_strength})")
                if suppress_topics:
                    sculpt_info.append(f"Suppressed: {', '.join(suppress_topics)} (strength={suppress_strength})")
                sys.stderr.write("Topic sculpting:\n  " + "\n  ".join(sculpt_info) + "\n\n")

        # Search composed cartridge
        results = composed.search(args.query, top_k=args.top_k)

        # Format as enriched-compatible payload for _output_search
        payload = {
            "results": [
                {
                    "source_id": r.source_id,
                    "score": r.score,
                    "raw_score": r.raw_score,
                    "provenance": r.provenance,
                    "cartridge": r.cartridge,
                    "injection_mode": composed.get_injection_mode(r.cartridge),
                    "band_scores": r.band_scores.tolist() if r.band_scores is not None else None,
                    "content": r.content.full_text[:300] if r.content and r.content.full_text else "",
                    "source_file": (r.content.metadata or {}).get("source_file", "") if r.content else "",
                }
                for r in results
            ],
            "coverage": {"confidence": 0.0, "gaps": []},
            "composition": {
                "type": composed._composition_type,
                "constituents": composed.constituent_names,
                "total_sources": composed.total_sources,
            },
            "timings_ms": {"load": round(load_ms, 2)},
        }
        payload = _apply_memory_filters(payload, args)
        _output_search(args, payload, load_ms, warm=False)

    else:
        # ── Standard cold path: load in-process and query directly ──
        t_load_start = time.perf_counter()
        lattice = _load_lattice_with_encoder(args, lattice_path)
        load_ms = (time.perf_counter() - t_load_start) * 1000

        _rerank = getattr(args, "rerank", "auto")
        _rerank_val = "auto" if _rerank == "auto" else _rerank == "true"
        enriched = lattice.enriched_query(
            text=args.query,
            top_k=args.top_k,
            cascade_depth=args.cascade_depth,
            contradiction_threshold=args.contradiction_threshold,
            enable_cascade=not args.no_cascade,
            enable_contradictions=args.enable_contradictions,
            enable_rerank=_rerank_val,
            enable_subgraph=getattr(args, "subgraph", False),
            subgraph_context_k=getattr(args, "subgraph_k", 3),
        )

        payload = enriched.to_dict()
        if hasattr(enriched, "timings_ms"):
            payload["timings_ms"] = {k: round(v, 2) for k, v in enriched.timings_ms.items()}

        payload = _apply_memory_filters(payload, args)
        _output_search(args, payload, load_ms, warm=False)

    # ── Spawn worker for next time (fire-and-forget) ──
    if worker_ok:
        try:
            from resonance_lattice.worker import (
                cleanup_stale,
                probe,
                read_state,
                spawn_worker,
                worker_key,
            )
            key = worker_key(lattice_path, getattr(args, "encoder", None), getattr(args, "checkpoint", None), source_root=getattr(args, "source_root", None))
            state = read_state(key)
            if not (state and probe(state["port"])):
                spawn_worker(
                    str(lattice_path),
                    key,
                    encoder=getattr(args, "encoder", None),
                    checkpoint=getattr(args, "checkpoint", None),
                    onnx=getattr(args, "onnx", None),
                )
            # Opportunistic cleanup
            cleanup_stale()
        except Exception:
            pass


def cmd_contradictions(args: argparse.Namespace) -> None:
    """Find contradictions in a lattice for a given query."""
    lattice_path = Path(args.lattice)
    lattice = _load_lattice_with_encoder(args, lattice_path)

    if lattice.encoder is None:
        _die("encoder required for contradiction detection")

    phase = lattice.encoder.encode_query(args.query)
    pairs = lattice.find_contradictions(
        query_phase=phase,
        band=args.band,
        threshold=args.threshold,
        top_k=args.top_k,
    )

    if not pairs:
        print("No contradictions found.")
        return

    print(f"Contradictions (band {args.band}, threshold {args.threshold}):\n")
    for a_id, b_id, score in pairs:
        print(f"  [{score:.4f}] {a_id} <-> {b_id}")

        # Show content if available
        for sid in (a_id, b_id):
            contents = lattice.store.retrieve_batch([sid])
            for c in contents:
                if c.summary:
                    print(f"    {sid}: {c.summary[:100]}")


def cmd_topology(args: argparse.Namespace) -> None:
    """Eigendecompose a band to reveal knowledge topology."""
    from resonance_lattice.lattice import Lattice

    lattice = Lattice.load(Path(args.lattice))

    topo = lattice.eigendecompose(band=args.band, top_k=args.top_k)

    print(f"Knowledge Topology (band {args.band}):")
    print(f"  Total energy:      {topo['total_energy']:.4f}")
    print(f"  Top eigenvalues:   {topo['eigenvalues'][:5].tolist()}")
    print(f"  Explained var (5): {topo['explained_variance'][:5].tolist()}")
    print(f"  Spectral gaps:     {topo['spectral_gaps'][:5].tolist()}")

    if args.output:
        output = {
            "band": args.band,
            "total_energy": topo["total_energy"],
            "eigenvalues": topo["eigenvalues"].tolist(),
            "explained_variance": topo["explained_variance"].tolist(),
            "spectral_gaps": topo["spectral_gaps"].tolist(),
        }
        Path(args.output).write_text(json.dumps(output, indent=2))
        print(f"\nSaved: {args.output}")


def cmd_xray(args: argparse.Namespace) -> None:
    """Field X-Ray: corpus-level semantic diagnostics."""
    from resonance_lattice.field.dense import DenseField
    from resonance_lattice.lattice import Lattice
    from resonance_lattice.xray import FieldXRay

    lattice_path = Path(args.lattice)
    _require_file(lattice_path)
    lattice = Lattice.load(lattice_path, restore_encoder=False)

    if not isinstance(lattice.field, DenseField):
        _die(f"xray requires DenseField backend (got {lattice.info()['field_type']})")

    info = lattice.info()
    deep = getattr(args, "deep", False)

    if deep:
        result = FieldXRay.deep(lattice.field, info["source_count"], str(lattice_path), lattice=lattice)
    else:
        result = FieldXRay.quick(lattice.field, info["source_count"], str(lattice_path))

    fmt = getattr(args, "format", "text")
    if fmt == "json":
        print(json.dumps(result.to_dict(), indent=2))
    elif fmt == "prompt":
        print(result.to_prompt())
    else:
        print(result.to_text())


def cmd_locate(args: argparse.Namespace) -> None:
    """Query positioning: where does this question sit in the knowledge landscape?"""
    from resonance_lattice.field.dense import DenseField
    from resonance_lattice.locate import QueryLocator

    lattice_path = Path(args.lattice)
    _require_file(lattice_path)
    lattice = _load_lattice_with_encoder(args, lattice_path)

    if lattice.encoder is None:
        _die("encoder required for locate")
    if not isinstance(lattice.field, DenseField):
        _die("locate requires DenseField backend")

    phase = lattice.encoder.encode_query(args.query)
    result = QueryLocator.locate(
        lattice.field, phase.vectors, args.query,
        registry=lattice.registry, store=lattice.store,
    )

    fmt = getattr(args, "format", "text")
    if fmt == "json":
        print(json.dumps(result.to_dict(), indent=2))
    elif fmt == "prompt":
        print(result.to_prompt())
    else:
        print(result.to_text())


def cmd_probe(args: argparse.Namespace) -> None:
    """RQL quick insight recipes."""
    from resonance_lattice.field.dense import DenseField
    from resonance_lattice.probe import RECIPES, ProbeRecipes

    recipe = args.recipe
    if recipe not in RECIPES:
        _die(f"Unknown recipe '{recipe}'. Available: {', '.join(RECIPES.keys())}")

    lattice_path = Path(args.lattice)
    _require_file(lattice_path)

    needs_query = RECIPES[recipe]["needs_query"]
    query_text = getattr(args, "query", None) or ""
    if needs_query and not query_text.strip():
        _die(f"Recipe '{recipe}' requires a query argument")

    if needs_query:
        lattice = _load_lattice_with_encoder(args, lattice_path)
        if lattice.encoder is None:
            _die("encoder required for this recipe")
    else:
        from resonance_lattice.lattice import Lattice
        lattice = Lattice.load(lattice_path, restore_encoder=False)

    if not isinstance(lattice.field, DenseField):
        _die("probe requires DenseField backend")

    if recipe == "health":
        result = ProbeRecipes.health(lattice.field)
    elif recipe == "novelty":
        phase = lattice.encoder.encode_passage(query_text)
        result = ProbeRecipes.novelty(lattice.field, phase.vectors, query_text)
    elif recipe == "saturation":
        result = ProbeRecipes.saturation(lattice.field)
    elif recipe == "band-flow":
        result = ProbeRecipes.band_flow(lattice.field)
    elif recipe == "anti":
        phase = lattice.encoder.encode_query(query_text)
        result = ProbeRecipes.anti(lattice.field, phase.vectors, query_text)
    elif recipe == "gaps":
        result = ProbeRecipes.gaps(lattice.field)
    else:
        _die(f"Unknown recipe '{recipe}'")

    fmt = getattr(args, "format", "text")
    if fmt == "json":
        print(json.dumps(result.to_dict(), indent=2))
    elif fmt == "prompt":
        print(result.to_prompt())
    else:
        print(result.to_text())


def cmd_init_project(args: argparse.Namespace) -> None:
    """One-command project setup: build cartridge + generate summary + suggest integration.

    This is the golden workflow in a single command:
      1. Auto-detect or use provided source directories
      2. Build a .rlat cartridge
      3. Generate a pre-injection context primer
      4. Write it to .claude/resonance-context.md (or specified path)
      5. Print integration instructions
    """
    from resonance_lattice.config import Compression, FieldType, LatticeConfig, Precision
    from resonance_lattice.lattice import Lattice

    # Step 1: Determine input paths
    if args.inputs:
        input_paths = [Path(s) for s in args.inputs]
    else:
        input_paths = _auto_detect_inputs()
        print(f"Auto-detected: {', '.join(str(p) for p in input_paths)}", file=sys.stderr)

    files = _collect_files(input_paths)
    if not files:
        print("Error: no files found. Specify inputs: rlat init-project ./docs ./src", file=sys.stderr)
        sys.exit(1)

    # Step 2: Build cartridge
    rlat_dir = Path(".rlat")
    rlat_dir.mkdir(exist_ok=True)
    cartridge_path = rlat_dir / "project.rlat"

    config = LatticeConfig(
        bands=5, dim=2048,
        field_type=FieldType.DENSE,
        precision=Precision.F32,
        compression=Compression.NONE,
    )
    lattice = Lattice(config=config)
    lattice.encoder = _load_encoder(args, config.bands, config.dim)

    # Attach ONNX backbone if requested (2-5x faster encoding on CPU)
    onnx_dir = getattr(args, "onnx", None)
    if onnx_dir and lattice.encoder is not None:
        try:
            from resonance_lattice.encoder_onnx import attach_onnx_backbone
            attach_onnx_backbone(lattice.encoder, onnx_dir)
        except Exception as exc:
            _warn(f"ONNX backbone failed to load: {exc}")

    from resonance_lattice.chunker import auto_chunk, generate_summary

    ext_counts: dict[str, int] = {}
    for f in files:
        ext_counts[f.suffix.lower()] = ext_counts.get(f.suffix.lower(), 0) + 1
    ext_summary = ", ".join(f"{v} {k}" for k, v in sorted(ext_counts.items(), key=lambda x: -x[1]))
    print(f"Building cartridge from {len(files)} files ({ext_summary})...", file=sys.stderr)

    count = 0
    start = time.time()
    all_texts: list[str] = []
    all_sids: list[str] = []
    all_metas: list[dict] = []
    all_summaries: list[str] = []
    for f in files:
        text = f.read_text(encoding="utf-8", errors="replace")
        chunks = auto_chunk(text, source_file=str(f))
        for chunk in chunks:
            slug = chunk.heading[:40].replace(" ", "_").lower() if chunk.heading else ""
            sid = f"{f.stem}_{slug}_{count:06d}" if slug else f"{f.stem}_{count:06d}"
            all_texts.append(chunk.text)
            all_sids.append(sid)
            all_metas.append({"source_file": str(f), "heading": chunk.heading, "chunk_type": chunk.chunk_type})
            all_summaries.append(generate_summary(chunk))
            count += 1

    lattice.superpose_text_batch(
        texts=all_texts, source_ids=all_sids, metadatas=all_metas,
        summaries=all_summaries, batch_size=64,
    )
    lattice.save(cartridge_path)
    elapsed = time.time() - start
    print(f"Cartridge: {cartridge_path} ({count} chunks in {elapsed:.1f}s)", file=sys.stderr)

    # Step 3: Generate summary
    summary_path = Path(args.output) if args.output else Path(".claude") / "resonance-context.md"
    summary_path.parent.mkdir(parents=True, exist_ok=True)

    # Re-load to get stored encoder
    lattice = _load_lattice_with_encoder(args, cartridge_path)

    queries = [
        "What is this project about? What problem does it solve and what are the key components?",
        "What is the architecture and how do the main abstractions interact?",
        "What operations, capabilities, and APIs does this system provide?",
        "What are the key design decisions, tradeoffs, and constraints?",
        "What are the important patterns, conventions, and workflows?",
    ]

    all_passages: dict[str, tuple[float, str, str]] = {}
    for query in queries:
        if lattice.encoder is None:
            break
        result = lattice.resonate_text(query=query, top_k=20)
        for r in result.results:
            if r.content:
                text = r.content.full_text or r.content.summary or ""
                if text and r.source_id != "__encoder__":
                    existing = all_passages.get(r.source_id)
                    if existing is None or r.score > existing[0]:
                        all_passages[r.source_id] = (r.score, text, query)

    ranked = sorted(all_passages.values(), key=lambda x: -x[0])

    section_titles = {
        "What is this project about": "Overview",
        "What is the architecture": "Architecture",
        "What operations": "Capabilities",
        "What are the key design": "Design Decisions",
        "What are the important patterns": "Patterns & Conventions",
    }

    lines = [
        f"# Project Memory: {Path('.').resolve().name}",
        "",
        f"<!-- Auto-generated by `rlat init-project` from {cartridge_path} -->",
        f"<!-- {count} chunks | {len(ranked)} passages | "
        f"{len(queries)} bootstrap queries -->",
        "",
    ]

    query_groups: dict[str, list[tuple[float, str]]] = {}
    for score, text, query in ranked:
        query_groups.setdefault(query, []).append((score, text))

    for query in queries:
        passages = query_groups.get(query, [])
        if not passages:
            continue
        title = "Context"
        for prefix, t in section_titles.items():
            if query.startswith(prefix):
                title = t
                break
        lines.append(f"## {title}")
        lines.append("")
        for _score, text in passages[:8]:
            lines.append(text.strip().replace("\n\n\n", "\n\n"))
            lines.append("")

    lines.extend([
        "---",
        "",
        "For deeper context, query the cartridge directly:",
        "```",
        f'rlat resonate {cartridge_path} "your question here"',
        "```",
    ])

    summary = "\n".join(lines)
    summary_path.write_text(summary, encoding="utf-8")
    print(f"Summary: {summary_path} ({len(summary)} chars, {len(ranked)} passages)", file=sys.stderr)

    # Step 4: Generate manifest
    from resonance_lattice.discover import update_manifest
    manifest_path = rlat_dir / "manifest.json"
    source_file_strs = [str(f) for f in files]
    manifest = update_manifest(
        manifest_path=manifest_path,
        cartridge_path=cartridge_path,
        source_files=source_file_strs,
        primer_path=str(summary_path),
        project_name=Path(".").resolve().name,
    )
    print(f"Manifest: {manifest_path} ({len(manifest.cartridges)} cartridge(s))", file=sys.stderr)

    # Step 5: Auto-integrate if requested
    if getattr(args, "auto_integrate", False):
        from resonance_lattice.discover import inject_claude_md, update_mcp_json

        if update_mcp_json(manifest_path=manifest_path):
            print("Updated .mcp.json with rlat MCP server", file=sys.stderr)

        if inject_claude_md(manifest_path=manifest_path):
            print("Injected cartridge section into CLAUDE.md", file=sys.stderr)

    # Step 6: Integration instructions
    print(f"\n{'='*60}", file=sys.stderr)
    print("Project memory ready!", file=sys.stderr)
    print("", file=sys.stderr)
    if not getattr(args, "auto_integrate", False):
        print("  Run with --auto-integrate to wire everything in automatically, or:", file=sys.stderr)
        print("", file=sys.stderr)
        print("  Add this line to your CLAUDE.md (or .cursorrules):", file=sys.stderr)
        print(f"    @{summary_path}", file=sys.stderr)
    else:
        print("  Auto-integration complete. Your assistant now has:", file=sys.stderr)
        print(f"    - Cartridge manifest: {manifest_path}", file=sys.stderr)
        print(f"    - MCP server configured in .mcp.json", file=sys.stderr)
        print(f"    - Cartridge section in CLAUDE.md", file=sys.stderr)
    print("", file=sys.stderr)
    print("  For deeper queries:", file=sys.stderr)
    print(f'    rlat search {cartridge_path} "your question"', file=sys.stderr)
    print(f"{'='*60}", file=sys.stderr)


_HELP_EPILOG = """\
primary commands:
  search        Enriched semantic query (passages + coverage + related)
  profile       Inspect cartridge semantic shape
  compare       Compare two cartridges
  ls            List sources in a cartridge
  info          Show cartridge metadata

build commands:
  build         Build a cartridge from source files
  add           Incrementally add files (no full rebuild)
  sync          Sync with source dirs (add new, update changed, remove deleted)
  init-project  One-command setup (build + summary + integration hints)

serve commands:
  serve         Start HTTP server
  summary       Generate assistant primer

algebra commands:
  merge         Combine two cartridges
  forget        Remove a source
  diff          Compute corpus delta

skill commands:
  skill build      Build cartridge from a skill's reference materials
  skill sync       Incrementally sync a skill's cartridge
  skill search     Search a skill's cartridges
  skill inject     Four-tier adaptive context injection
  skill route      Rank skills by relevance to a query
  skill profile    Semantic profile of a skill's cartridge
  skill freshness  Check freshness of skill cartridges
  skill gaps       Detect knowledge gaps in a skill's cartridge
  skill compare    Compare two skills' cartridges for overlap
  skill info       Show skill cartridge configuration and status

export commands:
  export         Export cartridge (supports --field-only)

environment:
  RLAT_VERBOSE=1    Show encoder loading details and timing breakdown
  RLAT_NO_WORKER=1  Disable background warm-search worker
"""


class _GroupedHelpFormatter(argparse.RawDescriptionHelpFormatter):
    """Hide the flat subcommand list — the epilog has the grouped version."""
    def _format_action(self, action):
        if isinstance(action, argparse._SubParsersAction):
            return ""
        return super()._format_action(action)




def cmd_compose(args: argparse.Namespace) -> None:
    """Search with algebraic composition expressions or .rctx context files."""
    from resonance_lattice.composition import ComposedCartridge
    from resonance_lattice.composition.parser import (
        CartridgeRef, ContradictNode, DiffNode, MergeNode, ProjectNode,
        WeightedNode, collect_cartridge_paths, parse_expression,
    )

    expr_or_path = args.expression
    t_start = time.perf_counter()

    # Check if it's a .rctx context file
    if Path(expr_or_path).suffix in (".rctx", ".json", ".yaml", ".yml") and Path(expr_or_path).exists():
        from resonance_lattice.composition.context_file import load_context, validate_context
        config = load_context(expr_or_path)
        warnings = validate_context(config)
        for w in warnings:
            sys.stderr.write(f"Warning: {w}\n")

        # Load cartridges from config
        lattices = {}
        for alias, path in config.cartridges.items():
            lattices[alias] = _load_lattice_with_encoder(args, Path(path))

        # Build composition
        if config.expression:
            # Parse expression using aliases
            ast = parse_expression(config.expression)
            composed = _eval_compose_ast(ast, lattices)
        elif config.weights:
            composed = ComposedCartridge.merge(lattices, weights=config.weights)
        else:
            composed = ComposedCartridge.merge(lattices)

        # Apply config options
        if config.boost or config.suppress:
            composed = composed.sculpt_topics(
                boost_topics=config.boost,
                suppress_topics=config.suppress,
                boost_strength=config.boost_strength,
                suppress_strength=config.suppress_strength,
            )
        if config.injection_modes:
            composed.set_injection_modes(config.injection_modes)
        if config.lens:
            from resonance_lattice.lens import Lens, LensBuilder
            if config.lens in ("sharpen", "flatten", "denoise"):
                lens = getattr(LensBuilder, config.lens)()
            else:
                lens = Lens.load(config.lens)
            viewed = lens.apply(composed.composed_field)
            composed = ComposedCartridge(composed._constituents, viewed, composed._composition_type)

    else:
        # Parse as expression
        ast = parse_expression(expr_or_path)
        paths = collect_cartridge_paths(ast)

        # Load all referenced cartridges
        lattices = {}
        for p in paths:
            path = Path(p)
            if not path.exists():
                _die(f"Cartridge not found: {p}")
            stem = path.stem
            if stem not in lattices:
                lattices[stem] = _load_lattice_with_encoder(args, path)

        composed = _eval_compose_ast(ast, lattices)

    load_ms = (time.perf_counter() - t_start) * 1000

    # Show diagnostics if --explain
    if getattr(args, "explain", False):
        from resonance_lattice.composition.diagnostics import diagnose_composition, format_diagnostics
        diag = diagnose_composition(composed._constituents, composed.composed_field)
        sys.stderr.write(format_diagnostics(diag))

    # Search
    results = composed.search(args.query, top_k=args.top_k)

    # Output
    if getattr(args, "format", "text") == "json":
        import json as _json
        payload = [
            {
                "source_id": r.source_id,
                "score": r.score,
                "cartridge": r.cartridge,
                "content": r.content.full_text[:300] if r.content and r.content.full_text else "",
            }
            for r in results
        ]
        print(_json.dumps(payload, indent=2))
    else:
        for i, r in enumerate(results, 1):
            sf = (r.content.metadata or {}).get("source_file", "") if r.content else ""
            excerpt = r.content.full_text[:200] if r.content and r.content.full_text else ""
            print(f"{i}. [{r.score:.3f}] [{r.cartridge}] {r.source_id}")
            if sf:
                print(f"   {sf}")
            if excerpt:
                print(f"   {excerpt}")
            print()


def _eval_compose_ast(ast, lattices: dict) -> "ComposedCartridge":
    """Evaluate a parsed composition AST against loaded lattices."""
    from resonance_lattice.composition import ComposedCartridge
    from resonance_lattice.composition.parser import (
        CartridgeRef, ContradictNode, DiffNode, MergeNode, ProjectNode, WeightedNode,
    )

    if isinstance(ast, CartridgeRef):
        name = Path(ast.path).stem
        if name not in lattices:
            _die(f"Cartridge '{name}' not loaded")
        return ComposedCartridge.merge({name: lattices[name]})

    elif isinstance(ast, WeightedNode):
        inner = _eval_compose_ast(ast.child, lattices)
        # Scale the composed field
        from resonance_lattice.field.dense import DenseField
        scaled = DenseField(bands=inner.composed_field.bands, dim=inner.composed_field.dim)
        scaled.F = ast.weight * inner.composed_field.F.copy()
        scaled._source_count = inner.composed_field.source_count
        return ComposedCartridge(inner._constituents, scaled, "weighted")

    elif isinstance(ast, MergeNode):
        left = _eval_compose_ast(ast.left, lattices)
        right = _eval_compose_ast(ast.right, lattices)
        from resonance_lattice.algebra import FieldAlgebra
        merged = FieldAlgebra.merge(left.composed_field, right.composed_field)
        all_constituents = {**left._constituents, **right._constituents}
        return ComposedCartridge(all_constituents, merged.field, "merge")

    elif isinstance(ast, DiffNode):
        newer = _eval_compose_ast(ast.newer, lattices)
        older = _eval_compose_ast(ast.older, lattices)
        from resonance_lattice.algebra import FieldAlgebra
        diff = FieldAlgebra.diff(newer.composed_field, older.composed_field)
        all_constituents = {**newer._constituents, **older._constituents}
        return ComposedCartridge(all_constituents, diff.delta_field, "diff")

    elif isinstance(ast, ContradictNode):
        left = _eval_compose_ast(ast.left, lattices)
        right = _eval_compose_ast(ast.right, lattices)
        from resonance_lattice.algebra import FieldAlgebra
        contra = FieldAlgebra.contradict(left.composed_field, right.composed_field)
        all_constituents = {**left._constituents, **right._constituents}
        return ComposedCartridge(all_constituents, contra.contradiction_field, "contradict")

    elif isinstance(ast, ProjectNode):
        source = _eval_compose_ast(ast.source, lattices)
        lens = _eval_compose_ast(ast.lens, lattices)
        from resonance_lattice.algebra import FieldAlgebra
        proj = FieldAlgebra.project(source.composed_field, lens.composed_field)
        all_constituents = {**source._constituents, **lens._constituents}
        return ComposedCartridge(all_constituents, proj.projected_field, "project")

    else:
        _die(f"Unknown AST node type: {type(ast).__name__}")


def cmd_mcp(args) -> None:
    """Start the MCP server for Claude Code integration."""
    import asyncio
    from pathlib import Path

    from resonance_lattice.mcp_server import load_cartridge, run_server
    from resonance_lattice.worker_main import _find_onnx_dir

    # Detect ONNX dir for faster inference (passed to deferred loader)
    onnx_dir = getattr(args, "onnx", None) or _find_onnx_dir(Path(args.cartridge))

    # Configure only — cartridge + encoder load is deferred to first tool call
    # so the MCP handshake completes instantly
    load_cartridge(
        args.cartridge,
        source_root=getattr(args, "source_root", None),
        onnx_dir=str(onnx_dir) if onnx_dir else None,
    )

    asyncio.run(run_server())


def cmd_export(args) -> None:
    """Export a cartridge, with optional field-only mode."""
    from resonance_lattice.serialise import load_dense_field, save_field_only

    cartridge_path = args.cartridge
    output_path = args.output
    field_only = getattr(args, "field_only", False)

    if field_only:
        print("Exporting field-only cartridge (no source text)...")
        data = load_dense_field(cartridge_path)
        save_field_only(output_path, data)
        print(f"Field-only cartridge saved to: {output_path}")
    else:
        # Full copy export
        import shutil
        shutil.copy2(cartridge_path, output_path)
        print(f"Cartridge copied to: {output_path}")


# ── skill commands ──────────────────────────────────────────────────

def _find_skills_root() -> Path:
    """Find the .claude/skills/ directory from the current working directory."""
    cwd = Path.cwd()
    candidates = [
        cwd / ".claude" / "skills",
        cwd.parent / ".claude" / "skills",
    ]
    for c in candidates:
        if c.is_dir():
            return c
    return cwd / ".claude" / "skills"


def cmd_skill(args: argparse.Namespace) -> None:
    """Dispatch skill subcommands."""
    sub = getattr(args, "skill_command", None)
    if sub is None:
        print("Usage: rlat skill <build|sync|search|inject|route|info> [options]", file=sys.stderr)
        sys.exit(1)

    dispatch = {
        "build": cmd_skill_build,
        "sync": cmd_skill_sync,
        "search": cmd_skill_search,
        "info": cmd_skill_info,
        "inject": cmd_skill_inject,
        "route": cmd_skill_route,
        "profile": cmd_skill_profile,
        "freshness": cmd_skill_freshness,
        "gaps": cmd_skill_gaps,
        "compare": cmd_skill_compare,
    }
    if sub not in dispatch:
        print(f"Unknown skill command: {sub}", file=sys.stderr)
        print("Usage: rlat skill <command> [options]", file=sys.stderr)
        sys.exit(1)
    dispatch[sub](args)


def cmd_skill_build(args: argparse.Namespace) -> None:
    """Build a cartridge from a skill's reference materials."""
    from resonance_lattice.config import LatticeConfig
    from resonance_lattice.lattice import Lattice
    from resonance_lattice.skill import parse_skill_frontmatter

    skill_dir = Path(args.skill_dir)
    if not skill_dir.is_dir():
        _die(f"skill directory not found: {skill_dir}")

    skill = parse_skill_frontmatter(skill_dir)
    if skill is None:
        _die(f"no valid SKILL.md found in {skill_dir}")

    source_dirs = skill.resolve_source_paths()
    if not source_dirs:
        _die(f"no source directories found for skill '{skill.name}' "
             f"(set cartridge-sources in SKILL.md frontmatter, or add a references/ directory)")

    files = _collect_files(source_dirs)
    if not files:
        _die(f"no ingestible files found for skill '{skill.name}' in {[str(d) for d in source_dirs]}")

    ext_counts: dict[str, int] = {}
    for f in files:
        ext_counts[f.suffix.lower()] = ext_counts.get(f.suffix.lower(), 0) + 1
    ext_summary = ", ".join(f"{count} {ext}" for ext, count in sorted(ext_counts.items(), key=lambda x: -x[1]))
    print(f"Building cartridge for skill '{skill.name}' from {len(files)} files ({ext_summary})")

    output_path = skill.local_cartridge_path()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    config = LatticeConfig()
    lattice = Lattice(config=config)
    lattice.encoder = _load_encoder(args, config.bands, config.dim)

    onnx_dir = getattr(args, "onnx", None)
    if onnx_dir and lattice.encoder is not None:
        try:
            from resonance_lattice.encoder_onnx import attach_onnx_backbone
            attach_onnx_backbone(lattice.encoder, onnx_dir)
        except Exception as exc:
            _warn(f"ONNX backbone failed to load: {exc}")

    manifest = FileManifest()
    encoder_fp = _encoder_fingerprint(lattice.encoder) if lattice.encoder else ""

    import time as _time
    start = _time.time()
    added, updated, skipped = _ingest_files_incremental(
        lattice, files, manifest, encoder_fp, progress=False,
    )
    elapsed = _time.time() - start

    _save_manifest(lattice, manifest)
    lattice.save(output_path)

    count = lattice.source_count
    info = lattice.info()
    print(f"Built {output_path.name}: {count} chunks from {len(files)} files in {elapsed:.1f}s")
    print(f"  Field: {info['field_size_mb']:.1f} MB | Bands: {info['bands']} x {info['dim']}d")
    print(f"  Path: {output_path}")

    # Generate primer
    _generate_skill_primer(lattice, skill)


def cmd_skill_sync(args: argparse.Namespace) -> None:
    """Incrementally sync a skill's cartridge with its reference materials."""
    from resonance_lattice.lattice import Lattice
    from resonance_lattice.skill import parse_skill_frontmatter

    skill_dir = Path(args.skill_dir)
    if not skill_dir.is_dir():
        _die(f"skill directory not found: {skill_dir}")

    skill = parse_skill_frontmatter(skill_dir)
    if skill is None:
        _die(f"no valid SKILL.md found in {skill_dir}")

    cartridge_path = skill.local_cartridge_path()
    if not cartridge_path.exists():
        print(f"No existing cartridge — building from scratch...", file=sys.stderr)
        cmd_skill_build(args)
        return

    source_dirs = skill.resolve_source_paths()
    if not source_dirs:
        _die(f"no source directories for skill '{skill.name}'")

    files = _collect_files(source_dirs)
    if not files:
        _die(f"no ingestible files found for skill '{skill.name}'")

    print(f"Syncing cartridge for skill '{skill.name}'...")

    lattice = Lattice.load(cartridge_path, restore_encoder=True)
    override = _has_encoder_override(args)
    if override or lattice.encoder is None:
        lattice.encoder = _load_encoder(args, lattice.config.bands, lattice.config.dim, lattice=lattice)

    manifest = _load_manifest(lattice)
    encoder_fp = _encoder_fingerprint(lattice.encoder) if lattice.encoder else ""

    import time as _time
    start = _time.time()
    added, updated, skipped = _ingest_files_incremental(
        lattice, files, manifest, encoder_fp, progress=False,
    )
    elapsed = _time.time() - start

    if added + updated == 0:
        print(f"  No changes detected ({skipped} files up-to-date)")
        return

    _save_manifest(lattice, manifest)
    lattice.save(cartridge_path)
    print(f"  Synced: +{added} new, ~{updated} updated, {skipped} unchanged in {elapsed:.1f}s")

    _generate_skill_primer(lattice, skill)


def cmd_skill_search(args: argparse.Namespace) -> None:
    """Search a skill's cartridges."""
    from resonance_lattice.skill import find_skill, parse_skill_frontmatter

    skill_name = args.skill_name
    skills_root = _find_skills_root()

    # Try as a directory path first
    skill_path = Path(skill_name)
    if skill_path.is_dir():
        skill = parse_skill_frontmatter(skill_path)
    else:
        skill = find_skill(skills_root, skill_name)

    if skill is None:
        _die(f"skill not found: {skill_name}\n"
             f"  Looked in: {skills_root}")

    # Collect all searchable cartridges
    cartridge_paths = skill.resolve_cartridge_paths(project_root=Path.cwd())

    # Add skill-local cartridge if it exists
    local = skill.local_cartridge_path()
    if local.exists() and local not in cartridge_paths:
        cartridge_paths.append(local)

    if not cartridge_paths:
        _die(f"skill '{skill.name}' has no cartridges.\n"
             f"  Run: rlat skill build {skill.skill_dir}")

    # Filter to existing files
    existing = [p for p in cartridge_paths if p.exists()]
    if not existing:
        _die(f"no cartridge files found for skill '{skill.name}'.\n"
             f"  Expected: {[str(p) for p in cartridge_paths]}")

    query = args.query
    top_k = getattr(args, "top_k", 10)

    if len(existing) == 1:
        # Single cartridge: delegate directly to enriched search
        lattice = _load_lattice_with_encoder(args, existing[0])

        import time as _time
        t0 = _time.perf_counter()
        result = lattice.enriched_query(
            text=query,
            top_k=top_k,
            enable_cascade=False,
            enable_contradictions=False,
        )
        load_ms = (_time.perf_counter() - t0) * 1000

        fmt = getattr(args, "format", "text")
        if fmt == "text":
            print(f"Skill: {skill.name}")
        _output_search(args, result.to_dict(), load_ms=load_ms, warm=False)
    else:
        # Multiple cartridges: compose and search
        from resonance_lattice.composition.composed import ComposedCartridge
        from resonance_lattice.lattice import Lattice

        lattices = {}
        for p in existing:
            lat = Lattice.load(p, restore_encoder=True)
            lattices[p.stem] = lat

        composed = ComposedCartridge.merge(lattices)

        # ComposedCartridge.search takes query_text (str), encodes internally
        results = composed.search(query, top_k=top_k)

        fmt = getattr(args, "format", "text")
        if fmt == "json":
            print(json.dumps([
                {
                    "source_id": r.source_id,
                    "score": round(r.score, 4),
                    "cartridge": getattr(r, "cartridge", "?"),
                    "summary": (r.content.summary or "")[:200] if r.content else "",
                    "source_file": (r.content.metadata or {}).get("source_file", "") if r.content else "",
                }
                for r in results
            ], indent=2))
        else:
            print(f"Skill: {skill.name} ({len(existing)} cartridges)")
            print(f"Query: {query}")
            print()
            for i, r in enumerate(results, 1):
                score_str = f"{r.score:.3f}"
                cartridge = getattr(r, "cartridge", "?")
                summary = ""
                if r.content:
                    summary = r.content.summary or (r.content.full_text or "")[:200]
                source_file = ""
                if r.content and r.content.metadata:
                    source_file = r.content.metadata.get("source_file", "")
                print(f"  {i}. [{score_str}] ({cartridge}) {source_file}")
                if summary:
                    print(f"     {summary[:120]}")
                print()


def cmd_skill_info(args: argparse.Namespace) -> None:
    """Show skill cartridge configuration and status."""
    from resonance_lattice.skill import discover_skills, find_skill, parse_skill_frontmatter

    skill_name = getattr(args, "skill_name", None)
    skills_root = _find_skills_root()

    if skill_name:
        skill_path = Path(skill_name)
        if skill_path.is_dir():
            skill = parse_skill_frontmatter(skill_path)
        else:
            skill = find_skill(skills_root, skill_name)
        if skill is None:
            _die(f"skill not found: {skill_name}")
        _print_skill_info(skill)
    else:
        # List all skills
        skills = discover_skills(skills_root)
        if not skills:
            print(f"No skills found in {skills_root}")
            return
        print(f"Skills in {skills_root}:")
        print()
        for s in skills:
            cart_status = ""
            local = s.local_cartridge_path()
            if s.has_cartridges or local.exists():
                ext_count = len(s.cartridges)
                if local.exists():
                    size_mb = local.stat().st_size / (1024 * 1024)
                    cart_status = f"[local {size_mb:.0f}MB] "
                if ext_count:
                    cart_status += f"[{ext_count} external] "
                if s.cartridge_queries:
                    cart_status += f"[{len(s.cartridge_queries)} queries] "
            else:
                cart_status = "[no cartridge]"
            print(f"  {s.name:30s} {cart_status}")
        print()
        print(f"  {len(skills)} skills found")


def _print_skill_info(skill) -> None:
    """Print detailed skill cartridge info."""
    print(f"Skill: {skill.name}")
    print(f"  Directory: {skill.skill_dir}")
    print(f"  Description: {skill.description[:100]}{'...' if len(skill.description) > 100 else ''}")
    print()

    local = skill.local_cartridge_path()
    if not skill.has_cartridges and not local.exists():
        print("  No cartridge integration configured.")
        print(f"  To enable: add 'cartridges:' or 'cartridge-sources:' to SKILL.md frontmatter")
        return

    print("  Cartridge configuration:")
    if skill.cartridges:
        print(f"    External cartridges: {skill.cartridges}")
    if skill.cartridge_sources:
        print(f"    Sources: {skill.cartridge_sources}")
    print(f"    Mode: {skill.cartridge_mode}")
    print(f"    Budget: {skill.cartridge_budget} lines")
    print(f"    Rebuild: {skill.cartridge_rebuild}")
    print(f"    Derive: {skill.cartridge_derive} (max {skill.cartridge_derive_count} queries)")

    if skill.cartridge_queries:
        print(f"    Foundational queries ({len(skill.cartridge_queries)}):")
        for q in skill.cartridge_queries:
            print(f"      - {q}")

    local = skill.local_cartridge_path()
    if local.exists():
        size_mb = local.stat().st_size / (1024 * 1024)
        print(f"    Local cartridge: {local} ({size_mb:.1f} MB)")
    else:
        sources = skill.resolve_source_paths()
        if sources:
            print(f"    Local cartridge: not built (run: rlat skill build {skill.skill_dir})")

    primer = skill.local_primer_path()
    if primer.exists():
        print(f"    Primer: {primer}")


def cmd_skill_inject(args: argparse.Namespace) -> None:
    """Four-tier adaptive context injection for a skill."""
    from resonance_lattice.skill import find_skill, parse_skill_frontmatter
    from resonance_lattice.skill_projector import SkillProjector
    from resonance_lattice.skill_runtime import SkillRuntime

    skill_name = args.skill_name
    query = args.query
    skills_root = _find_skills_root()

    # Resolve skill
    skill_path = Path(skill_name)
    if skill_path.is_dir():
        skill = parse_skill_frontmatter(skill_path)
    else:
        skill = find_skill(skills_root, skill_name)

    if skill is None:
        _die(f"skill not found: {skill_name}")

    # Build runtime and projector
    print(f"Injecting context for skill '{skill.name}'...", file=sys.stderr)
    rt = SkillRuntime(skills_root, Path.cwd())
    projector = SkillProjector(rt)

    # Parse derived queries if provided
    derived = None
    derived_raw = getattr(args, "derived", None)
    if derived_raw:
        derived = [q.strip() for q in derived_raw.split(";") if q.strip()]

    injection = projector.project(skill, query, derived_queries=derived)

    fmt = getattr(args, "format", "text")

    if fmt == "json":
        import json as _json
        print(_json.dumps({
            "mode": injection.mode,
            "gated": injection.gated,
            "total_tokens": injection.total_tokens,
            "tier_tokens": injection.tier_tokens,
            "queries_used": injection.queries_used,
            "cartridge_hits": injection.cartridge_hits,
            "coverage_confidence": injection.coverage_confidence,
            "header_length": len(injection.header),
            "body_length": len(injection.body),
        }, indent=2))
    elif fmt == "context":
        # Output just the injectable body (for piping into prompts)
        if injection.body:
            print(injection.body)
    else:
        # text format: full diagnostic output
        use_c = _use_color()
        B = "\033[1m" if use_c else ""
        D = "\033[2m" if use_c else ""
        R = "\033[0m" if use_c else ""
        G = "\033[32m" if use_c else ""
        Y = "\033[33m" if use_c else ""

        print(f"{B}Skill Injection: {skill.name}{R}")
        print(f"  Query: {query}")
        print(f"  Mode: {injection.mode}")
        print(f"  Gated: {'yes (dynamic context suppressed)' if injection.gated else 'no'}")
        print(f"  Coverage: {injection.coverage_confidence:.0%}")
        print()

        print(f"{B}Token Budget:{R}")
        for tier, tokens in injection.tier_tokens.items():
            label = {"t1": "Tier 1 (static)", "t2": "Tier 2 (foundational)",
                     "t3": "Tier 3 (user query)", "t4": "Tier 4 (derived)"}.get(tier, tier)
            bar = _safe_bar(tokens / max(injection.total_tokens, 1), width=20)
            print(f"  {label:25s} {tokens:5d} tokens  {bar}")
        print(f"  {'Total':25s} {injection.total_tokens:5d} tokens")
        print()

        if injection.queries_used:
            print(f"{B}Queries Used ({len(injection.queries_used)}):{R}")
            for q in injection.queries_used:
                print(f"  - {q}")
            print()

        if injection.cartridge_hits:
            print(f"{B}Cartridge Hits:{R}")
            for cart, count in sorted(injection.cartridge_hits.items(), key=lambda x: -x[1]):
                print(f"  {cart}: {count} passages")
            print()

        if injection.body:
            print(f"{D}--- Dynamic Body ({_estimate_tokens_cli(injection.body)} tokens) ---{R}")
            # Print first 2000 chars to avoid flooding terminal
            preview = injection.body[:2000]
            if len(injection.body) > 2000:
                preview += f"\n... ({len(injection.body) - 2000} chars truncated)"
            print(preview)


def _estimate_tokens_cli(text: str) -> int:
    return max(1, len(text) // 4)


def cmd_skill_route(args: argparse.Namespace) -> None:
    """Rank all cartridge-backed skills by relevance to a query."""
    from resonance_lattice.skill_runtime import SkillRuntime

    query = args.query
    top_n = getattr(args, "top_n", 5)
    skills_root = _find_skills_root()

    print(f"Routing: \"{query}\"", file=sys.stderr)
    rt = SkillRuntime(skills_root, Path.cwd())

    matches = rt.route(query, top_n=top_n)

    if not matches:
        print("No cartridge-backed skills found.")
        print(f"  Skills root: {skills_root}")
        print("  Run 'rlat skill build' on skills with references/ directories.")
        return

    fmt = getattr(args, "format", "text")

    if fmt == "json":
        import json as _json
        print(_json.dumps([
            {"name": m.name, "energy": round(m.energy, 1),
             "coverage": m.coverage, "mode": m.mode}
            for m in matches
        ], indent=2))
    else:
        use_c = _use_color()
        B = "\033[1m" if use_c else ""
        R = "\033[0m" if use_c else ""
        G = "\033[32m" if use_c else ""
        Y = "\033[33m" if use_c else ""
        D = "\033[2m" if use_c else ""

        print(f"\n{B}Routing:{R} \"{query}\"\n")
        for i, m in enumerate(matches, 1):
            color = G if m.coverage == "high" else (Y if m.coverage == "medium" else D)
            print(f"  {i}. {color}{m.name:30s}{R}  energy={m.energy:>7.1f}  "
                  f"coverage={m.coverage:6s}  mode={m.mode}")

        print(f"\n  {len(matches)} skill(s) with relevant knowledge. Best: {matches[0].name}")


def cmd_skill_profile(args: argparse.Namespace) -> None:
    """Semantic profile of a skill's cartridge."""
    from resonance_lattice.skill import find_skill, parse_skill_frontmatter

    skill_name = args.skill_name
    skills_root = _find_skills_root()

    skill_path = Path(skill_name)
    if skill_path.is_dir():
        skill = parse_skill_frontmatter(skill_path)
    else:
        skill = find_skill(skills_root, skill_name)
    if skill is None:
        _die(f"skill not found: {skill_name}")

    cartridge = skill.local_cartridge_path()
    if not cartridge.exists():
        # Check external cartridges
        paths = skill.resolve_cartridge_paths(project_root=Path.cwd())
        existing = [p for p in paths if p.exists()]
        if not existing:
            _die(f"no cartridge found for skill '{skill.name}'.\n"
                 f"  Run: rlat skill build {skill.skill_dir}")
        cartridge = existing[0]

    # Delegate to existing profile logic
    args.lattice = str(cartridge)
    args.format = getattr(args, "format", "text")
    print(f"Skill: {skill.name}")
    cmd_profile(args)


def cmd_skill_freshness(args: argparse.Namespace) -> None:
    """Check freshness of skill cartridges."""
    from resonance_lattice.skill import discover_skills

    skills_root = _find_skills_root()
    skill_name = getattr(args, "skill_name", None)

    if skill_name:
        from resonance_lattice.skill import find_skill, parse_skill_frontmatter
        skill_path = Path(skill_name)
        if skill_path.is_dir():
            skill = parse_skill_frontmatter(skill_path)
        else:
            skill = find_skill(skills_root, skill_name)
        if skill is None:
            _die(f"skill not found: {skill_name}")
        skills = [skill]
    else:
        skills = discover_skills(skills_root)

    from datetime import datetime, timezone

    fmt = getattr(args, "format", "text")
    results = []

    for skill in skills:
        cartridge = skill.local_cartridge_path()
        if not cartridge.exists():
            results.append({
                "name": skill.name, "status": "no cartridge",
                "age_hours": None, "stale": None,
                "files_changed": None, "recommendation": "build first",
            })
            continue

        # Get cartridge mtime as built_at proxy
        mtime = cartridge.stat().st_mtime
        built = datetime.fromtimestamp(mtime, tz=timezone.utc)
        age_hours = (datetime.now(timezone.utc) - built).total_seconds() / 3600

        # Check source file changes
        source_dirs = skill.resolve_source_paths()
        files_changed = 0
        for src_dir in source_dirs:
            if not src_dir.is_dir():
                continue
            for f in src_dir.rglob("*"):
                if f.is_file() and f.stat().st_mtime > mtime:
                    files_changed += 1

        if age_hours < 24 and files_changed == 0:
            status = "fresh"
            stale = False
        elif age_hours < 72 and files_changed < 10:
            status = "consider rebuilding" if files_changed else "fresh"
            stale = False
        else:
            status = "stale"
            stale = True

        rec = status
        if stale:
            rec = f"stale ({age_hours:.0f}h old, {files_changed} files changed)"

        results.append({
            "name": skill.name, "status": status,
            "age_hours": round(age_hours, 1), "stale": stale,
            "files_changed": files_changed, "recommendation": rec,
        })

    if fmt == "json":
        print(json.dumps(results, indent=2))
    else:
        use_c = _use_color()
        G = "\033[32m" if use_c else ""
        Y = "\033[33m" if use_c else ""
        R_c = "\033[31m" if use_c else ""
        D = "\033[2m" if use_c else ""
        R = "\033[0m" if use_c else ""

        for r in results:
            if r["status"] == "fresh":
                color = G
                icon = "OK"
            elif r["status"] == "no cartridge":
                color = D
                icon = "--"
            elif r["stale"]:
                color = R_c
                icon = "!!"
            else:
                color = Y
                icon = "~~"

            age_str = f"{r['age_hours']:.0f}h" if r["age_hours"] is not None else "n/a"
            changed_str = str(r["files_changed"]) if r["files_changed"] is not None else "-"
            print(f"  {color}[{icon}]{R} {r['name']:30s}  age={age_str:>5s}  "
                  f"changed={changed_str:>3s}  {r['recommendation']}")


def cmd_skill_gaps(args: argparse.Namespace) -> None:
    """Detect knowledge gaps in a skill's cartridge."""
    from resonance_lattice.skill import find_skill, parse_skill_frontmatter

    skill_name = args.skill_name
    skills_root = _find_skills_root()

    skill_path = Path(skill_name)
    if skill_path.is_dir():
        skill = parse_skill_frontmatter(skill_path)
    else:
        skill = find_skill(skills_root, skill_name)
    if skill is None:
        _die(f"skill not found: {skill_name}")

    cartridge = skill.local_cartridge_path()
    if not cartridge.exists():
        paths = skill.resolve_cartridge_paths(project_root=Path.cwd())
        existing = [p for p in paths if p.exists()]
        if not existing:
            _die(f"no cartridge for skill '{skill.name}'")
        cartridge = existing[0]

    # Delegate to probe gaps recipe
    args.lattice = str(cartridge)
    args.recipe = "gaps"
    args.query = ""
    args.format = getattr(args, "format", "text")
    args.encoder = getattr(args, "encoder", None)
    args.checkpoint = getattr(args, "checkpoint", None)

    print(f"Skill: {skill.name}")
    cmd_probe(args)


def cmd_skill_compare(args: argparse.Namespace) -> None:
    """Compare two skills' cartridges for overlap."""
    from resonance_lattice.skill import find_skill, parse_skill_frontmatter

    skills_root = _find_skills_root()

    def _resolve_skill_cartridge(name: str) -> Path:
        skill_path = Path(name)
        if skill_path.is_dir():
            skill = parse_skill_frontmatter(skill_path)
        else:
            skill = find_skill(skills_root, name)
        if skill is None:
            _die(f"skill not found: {name}")
        cartridge = skill.local_cartridge_path()
        if not cartridge.exists():
            paths = skill.resolve_cartridge_paths(project_root=Path.cwd())
            existing = [p for p in paths if p.exists()]
            if not existing:
                _die(f"no cartridge for skill '{skill.name}'")
            cartridge = existing[0]
        return cartridge

    cart_a = _resolve_skill_cartridge(args.skill_a)
    cart_b = _resolve_skill_cartridge(args.skill_b)

    # Delegate to existing compare
    args.lattice_a = str(cart_a)
    args.lattice_b = str(cart_b)
    args.format = getattr(args, "format", "text")

    print(f"Comparing skills: {args.skill_a} vs {args.skill_b}")
    cmd_compare(args)


def _generate_skill_primer(lattice, skill) -> None:
    """Generate primer.md alongside the skill's cartridge."""
    if lattice.encoder is None:
        return

    from resonance_lattice.materialiser import _estimate_tokens, _truncate_to_tokens

    queries = [
        "What are the key concepts and patterns?",
        "What operations and workflows does this cover?",
        "What are the important conventions and best practices?",
    ]

    seen: dict[str, tuple[float, object]] = {}
    for query in queries:
        result = lattice.resonate_text(query=query, top_k=10)
        for r in result.results:
            if not r.content or r.source_id.startswith("__"):
                continue
            text = r.content.full_text or r.content.summary or ""
            if not text:
                continue
            existing = seen.get(r.source_id)
            if existing is None or r.score > existing[0]:
                seen[r.source_id] = (r.score, r)

    ranked = [r for _, r in sorted(seen.values(), key=lambda x: -x[0])]

    lines = [
        f"# Skill Primer: {skill.name}",
        "",
        f"<!-- Auto-generated by rlat skill build | {lattice.source_count} sources -->",
        "",
    ]

    budget_tokens = 1500
    used = 0
    for r in ranked:
        text = r.content.full_text or r.content.summary or ""
        tokens = _estimate_tokens(text)
        if used + tokens > budget_tokens:
            text = _truncate_to_tokens(text, budget_tokens - used)
            if not text.strip():
                break
        source_file = (r.content.metadata or {}).get("source_file", r.source_id)
        lines.append(f"- **{source_file}**: {text.strip()}")
        lines.append("")
        used += _estimate_tokens(text)
        if used >= budget_tokens:
            break

    primer_path = skill.local_primer_path()
    primer_path.parent.mkdir(parents=True, exist_ok=True)
    primer_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"  Primer: {primer_path.name} ({len(ranked)} passages, ~{used} tokens)")


def cmd_negotiate(args: argparse.Namespace) -> None:
    """Analyze the relationship between two knowledge cartridges."""
    import numpy as np
    from resonance_lattice.algebra import FieldAlgebra
    from resonance_lattice.field.dense import DenseField
    from resonance_lattice.lattice import Lattice

    path_a, path_b = Path(args.cartridge_a), Path(args.cartridge_b)
    if not path_a.exists():
        _die(f"file not found: {args.cartridge_a}")
    if not path_b.exists():
        _die(f"file not found: {args.cartridge_b}")

    lattice_a = Lattice.load(str(path_a))
    lattice_b = Lattice.load(str(path_b))

    if not isinstance(lattice_a.field, DenseField) or not isinstance(lattice_b.field, DenseField):
        _die("negotiate requires DenseField cartridges")
    if lattice_a.field.bands != lattice_b.field.bands or lattice_a.field.dim != lattice_b.field.dim:
        _die("cartridges must have matching dimensions")

    name_a, name_b = path_a.stem, path_b.stem

    # Intersection
    intersection = FieldAlgebra.intersect(lattice_a.field, lattice_b.field)
    print(f"Knowledge Negotiation: {name_a} vs {name_b}")
    print(f"  Shared ground: {intersection.overlap_fraction:.0%} overlap")
    print()

    # Novelty
    novelty_a, novelty_b = [], []
    if lattice_a.registry:
        for sid, entry in list(lattice_a.registry._source_index.items())[:100]:
            n = FieldAlgebra.novelty(lattice_b.field, entry.phase_vectors)
            novelty_a.append(n.score)
    if lattice_b.registry:
        for sid, entry in list(lattice_b.registry._source_index.items())[:100]:
            n = FieldAlgebra.novelty(lattice_a.field, entry.phase_vectors)
            novelty_b.append(n.score)

    avg_a = float(np.mean(novelty_a)) if novelty_a else 0
    avg_b = float(np.mean(novelty_b)) if novelty_b else 0
    print(f"  Unique to {name_a}: {avg_a:.0%} novelty")
    print(f"  Unique to {name_b}: {avg_b:.0%} novelty")
    print()

    # Contradictions
    contradiction = FieldAlgebra.contradict(lattice_a.field, lattice_b.field)
    if contradiction.contradiction_ratio < 0.01:
        print("  Disagreements: none detected")
    else:
        ratio_label = "high" if contradiction.contradiction_ratio > 0.15 else "moderate" if contradiction.contradiction_ratio > 0.05 else "low"
        print(f"  Disagreements: {ratio_label} ({contradiction.contradiction_ratio:.1%} contradiction ratio)")
    print()

    # Recommendation
    print("  Recommendation:")
    if contradiction.contradiction_ratio > 0.05:
        print("    Resolve disagreements before merging.")
    if avg_b > avg_a + 0.1:
        print(f"    {name_b} has significantly more unique knowledge.")
    elif avg_a > avg_b + 0.1:
        print(f"    {name_a} has significantly more unique knowledge.")
    if intersection.overlap_fraction > 0.7:
        print("    High overlap — merging adds limited new knowledge.")
    elif intersection.overlap_fraction < 0.3:
        print("    Low overlap — merge (--with) for broad coverage.")


def cmd_memory(args: argparse.Namespace) -> None:
    """Dispatch memory subcommands."""
    sub = getattr(args, "memory_command", None)
    if sub is None:
        print("Usage: rlat memory {search,add,forget,stats}")
        sys.exit(1)
    {
        "search": cmd_memory_search,
        "add": cmd_memory_add,
        "forget": cmd_memory_forget,
        "stats": cmd_memory_stats,
    }[sub](args)


def _find_memory_path() -> Path:
    """Find the standard memory cartridge path."""
    candidates = [Path(".rlat/memory.rlat"), Path("memory.rlat")]
    for c in candidates:
        if c.exists():
            return c
    return Path(".rlat/memory.rlat")  # default


def cmd_memory_search(args: argparse.Namespace) -> None:
    """Search memory for relevant prior context."""
    from resonance_lattice.lattice import Lattice
    mem_path = _find_memory_path()
    if not mem_path.exists():
        _die(f"No memory cartridge found at {mem_path}. Use 'rlat memory add' to create one.")

    lattice = Lattice.load(str(mem_path))
    result = lattice.enriched_query(args.query, top_k=args.top_k)

    print(f"Memory: {lattice.source_count} memories")
    print()
    for i, r in enumerate(result.results[:args.top_k], 1):
        text = ""
        session = ""
        if r.content:
            text = r.content.summary or (r.content.full_text or "")[:200]
            meta = r.content.metadata or {}
            session = meta.get("session_id", "")
        tag = f" [session: {session}]" if session else ""
        print(f"  {i}. [{r.score:.3f}]{tag} {text}")


def cmd_memory_add(args: argparse.Namespace) -> None:
    """Add content to the memory cartridge."""
    import tempfile
    from datetime import datetime, timezone
    from resonance_lattice.lattice import Lattice

    mem_path = _find_memory_path()
    mem_path.parent.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now(timezone.utc).isoformat()
    session_id = getattr(args, "session", "")
    header = f"---\nsession_id: {session_id}\ntimestamp: {timestamp}\n---\n"

    with tempfile.NamedTemporaryFile(mode="w", suffix=".md", delete=False, encoding="utf-8") as f:
        f.write(header + args.content)
        tmp = f.name

    try:
        if mem_path.exists():
            lattice = Lattice.load(str(mem_path))
            lattice.add_files([tmp])
            lattice.save(str(mem_path))
        else:
            from resonance_lattice.encoder import ResonanceEncoder
            encoder = ResonanceEncoder.from_preset("e5-large-v2")
            lattice = Lattice.build(paths=[tmp], encoder=encoder)
            lattice.save(str(mem_path))
        print(f"Saved to memory ({lattice.source_count} memories).")
    finally:
        Path(tmp).unlink(missing_ok=True)


def cmd_memory_forget(args: argparse.Namespace) -> None:
    """Provably remove a topic or session from memory."""
    from resonance_lattice.algebra import FieldAlgebra
    from resonance_lattice.field.dense import DenseField
    from resonance_lattice.lattice import Lattice

    mem_path = _find_memory_path()
    if not mem_path.exists():
        _die(f"No memory cartridge found at {mem_path}")

    topic = getattr(args, "topic", None)
    session_id = getattr(args, "session", None)
    if not topic and not session_id:
        _die("Provide --topic or --session to forget")

    lattice = Lattice.load(str(mem_path))
    if not isinstance(lattice.field, DenseField):
        _die("Memory requires DenseField")

    sources_to_forget = []
    if session_id and lattice.store:
        for sid in list(lattice.registry._source_index.keys()):
            content = lattice.store.retrieve(sid)
            if content and content.metadata and content.metadata.get("session_id") == session_id:
                sources_to_forget.append(sid)
    elif topic and lattice.encoder:
        result = lattice.enriched_query(topic, top_k=10)
        for r in result.results:
            if r.score > 0.3:
                sources_to_forget.append(r.source_id)

    if not sources_to_forget:
        print("No matching memories found.")
        return

    total_residual = 0.0
    for sid in sources_to_forget:
        entry = lattice.registry._source_index.get(sid)
        if entry is not None:
            cert = FieldAlgebra.forget(lattice.field, [entry.phase_vectors])
            total_residual = max(total_residual, cert.residual_ratio)
            lattice.registry.unregister(sid)
            if lattice.store:
                lattice.store.remove(sid)

    lattice.save(str(mem_path))

    label = f"topic \"{topic}\"" if topic else f"session \"{session_id}\""
    print(f"Removed {len(sources_to_forget)} memories about {label}.")
    print(f"Removal certificate: residual < {total_residual:.1e} (algebraically exact).")
    print(f"Memory: {lattice.source_count} memories remaining.")


def cmd_memory_stats(args: argparse.Namespace) -> None:
    """Show memory cartridge statistics."""
    from resonance_lattice.lattice import Lattice
    mem_path = _find_memory_path()
    if not mem_path.exists():
        print(f"No memory cartridge at {mem_path}")
        return

    lattice = Lattice.load(str(mem_path))
    size_mb = mem_path.stat().st_size / (1024 * 1024)
    print(f"Memory: {mem_path}")
    print(f"  Sources: {lattice.source_count}")
    print(f"  Size: {size_mb:.1f} MB")
    print(f"  Bands: {lattice.field.bands}")
    print(f"  Dim: {lattice.field.dim}")


def cmd_health(args: argparse.Namespace) -> None:
    """Knowledge health check: signal quality, band health, contradictions, drift."""
    from resonance_lattice.health import HealthCheck
    from resonance_lattice.lattice import Lattice

    lattice_path = Path(args.lattice)
    if not lattice_path.exists():
        _die(f"file not found: {args.lattice}")

    lattice = Lattice.load(str(lattice_path))

    baseline = None
    if args.baseline:
        baseline_path = Path(args.baseline)
        if not baseline_path.exists():
            _die(f"baseline not found: {args.baseline}")
        baseline = Lattice.load(str(baseline_path))

    report = HealthCheck.run(
        lattice=lattice,
        baseline=baseline,
        lattice_path=str(lattice_path),
    )

    fmt = getattr(args, "format", "text")
    if fmt == "json":
        import json
        print(json.dumps({
            "status": report.status,
            "snr": report.snr,
            "saturation": report.saturation,
            "remaining_capacity": report.remaining_capacity,
            "band_health": report.band_health,
            "contradiction_count": report.contradiction_count,
            "contradiction_ratio": report.contradiction_ratio,
            "coverage_changes": report.coverage_changes,
            "diagnostics": report.diagnostics,
        }, indent=2))
    else:
        print(report.to_text())

    if getattr(args, "ci", False) and report.status == "CRITICAL":
        sys.exit(1)


def cmd_lens(args: argparse.Namespace) -> None:
    """Dispatch lens subcommands."""
    sub = getattr(args, "lens_command", None)
    if sub is None:
        print("Usage: rlat lens {create,list,compose}")
        sys.exit(1)
    {"create": cmd_lens_create, "list": cmd_lens_list, "compose": cmd_lens_compose}[sub](args)


def cmd_lens_create(args: argparse.Namespace) -> None:
    """Create a .rlens file from topics or a cartridge eigenspace."""
    from resonance_lattice.lens import LensBuilder

    output = Path(args.output).with_suffix(".rlens")

    if args.topics:
        # Build from topic exemplars — requires an encoder
        topics = [t.strip() for t in args.topics.split(",") if t.strip()]
        if not topics:
            _die("--topics must provide at least one topic")

        from resonance_lattice.encoder import ResonanceEncoder
        encoder = ResonanceEncoder.from_preset(args.encoder or "e5-large-v2")
        phases = [encoder.encode_passage(t).vectors for t in topics]
        lens = LensBuilder.from_exemplars(
            name=",".join(topics[:3]),
            phase_vectors_list=phases,
            k=args.rank,
        )
        lens.save(output)
        print(f"Lens saved: {output} (from {len(topics)} topics, rank {lens.metadata.get('rank', '?')})")

    elif args.from_cartridge:
        # Build from cartridge eigenspace
        lattice = Lattice.load(args.from_cartridge)
        from resonance_lattice.field.dense import DenseField
        if not isinstance(lattice.field, DenseField):
            _die("Lens creation requires a DenseField cartridge")
        lens = LensBuilder.from_field(lattice.field, name=Path(args.from_cartridge).stem, k=args.rank)
        lens.save(output)
        print(f"Lens saved: {output} (from {args.from_cartridge}, rank {lens.metadata.get('rank', '?')})")

    else:
        _die("Provide --topics or --from to create a lens")


def cmd_lens_list(args: argparse.Namespace) -> None:
    """List .rlens files in a directory."""
    search_dir = Path(getattr(args, "dir", "."))
    rlens_files = sorted(search_dir.rglob("*.rlens"))
    if not rlens_files:
        print(f"No .rlens files found in {search_dir}")
        return
    print(f"Found {len(rlens_files)} lens(es):")
    for f in rlens_files:
        size_kb = f.stat().st_size / 1024
        print(f"  {f}  ({size_kb:.1f} KB)")


def cmd_lens_compose(args: argparse.Namespace) -> None:
    """Compose two lenses into one (subspace intersection)."""
    from resonance_lattice.lens import Lens as LensBase

    lens_a = LensBase.load(args.lens_a)
    lens_b = LensBase.load(args.lens_b)

    if not hasattr(lens_a, "compose"):
        _die(f"Lens {args.lens_a} does not support composition")

    composed = lens_a.compose(lens_b)
    output = Path(args.output).with_suffix(".rlens")
    composed.save(output)
    print(f"Composed lens saved: {output}")


def main() -> None:
    _C.init()
    # Enable ANSI on Windows 10+ and fix Unicode output
    if sys.platform == "win32":
        try:
            os.system("")  # triggers VT100 mode on Windows
        except Exception:
            pass
        # Force UTF-8 output on Windows to avoid cp1252 UnicodeEncodeError
        # when printing source text containing non-ASCII characters
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

    parser = argparse.ArgumentParser(
        prog="rlat",
        usage="rlat <command> [options]",
        description="Resonance Lattice — portable semantic model for knowledge.",
        epilog=_HELP_EPILOG,
        formatter_class=_GroupedHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest="command")

    # ── init ──
    p_init = subparsers.add_parser("init", help="Create a new lattice")
    p_init.add_argument("--bands", type=int, default=5)
    p_init.add_argument("--dim", type=int, default=2048)
    p_init.add_argument("--field-type", default="dense", choices=["dense", "factored", "pq"])
    p_init.add_argument("--pq-subspaces", type=int, default=8)
    p_init.add_argument("--pq-codebook-size", type=int, default=1024)
    p_init.add_argument("--svd-rank", type=int, default=512)
    p_init.add_argument("--precision", default="f32", choices=["f16", "bf16", "f32"])
    p_init.add_argument("--compression", default="none", choices=["none", "zstd", "lz4"])
    p_init.add_argument("--output", "-o", required=True, help="Output .rlat file")

    # ── ingest ──
    p_ingest = subparsers.add_parser("ingest", help="Ingest documents into a lattice")
    p_ingest.add_argument("lattice", help="Path to .rlat file")
    p_ingest.add_argument("input", help="Input file or directory to ingest")
    p_ingest.add_argument("--encoder", default=None, help="Encoder preset or HuggingFace model ID (run 'rlat encoders' to list presets)")
    p_ingest.add_argument("--checkpoint", help="Trained heads checkpoint (recommended: sparsity_sweep/uniform90)")
    p_ingest.add_argument("--onnx", default=None,
                           help="ONNX backbone directory for faster encoding")

    # ── query ──
    p_query = subparsers.add_parser("query", help="Basic retrieval: ranked passages without enrichment (scripts, debugging)")
    p_query.add_argument("lattice", help="Path to .rlat file")
    p_query.add_argument("query", help="Query text")
    p_query.add_argument("--top-k", type=int, default=10)
    p_query.add_argument("--encoder", default=None, help="Encoder preset or HuggingFace model ID (run 'rlat encoders' to list presets)")
    p_query.add_argument("--checkpoint", help="Trained heads checkpoint (recommended: sparsity_sweep/uniform90)")
    p_query.add_argument("--format", default="text", choices=["text", "json", "context", "prompt"])
    p_query.add_argument("--mode", default=None, choices=["augment", "constrain", "knowledge", "custom"],
                         help="Injection framing mode (augment=enrich, constrain=zero-hallucination)")
    p_query.add_argument("--custom-prompt", default=None, help="Custom system prompt (requires --mode custom)")

    # ── info ──
    p_info = subparsers.add_parser("info", help="Display lattice metadata")
    p_info.add_argument("lattice", help="Path to .rlat file")

    # ── diff ──
    p_diff = subparsers.add_parser("diff", help="Corpus subtraction between two lattices")
    p_diff.add_argument("lattice_a", help="First .rlat file")
    p_diff.add_argument("lattice_b", help="Second .rlat file")
    p_diff.add_argument("--output", "-o", help="Output delta .rlat file")

    # ── build ──
    p_build = subparsers.add_parser("build", help="Build a cartridge from source files")
    p_build.add_argument("inputs", nargs="+", help="Input files or directories")
    p_build.add_argument("--output", "-o", required=True, help="Output .rlat file")
    p_build.add_argument("--bands", type=int, default=5)
    p_build.add_argument("--dim", type=int, default=2048)
    p_build.add_argument("--field-type", default="dense", choices=["dense", "factored", "pq"])
    p_build.add_argument("--precision", default="f32", choices=["f16", "bf16", "f32"])
    p_build.add_argument("--compression", default="none", choices=["none", "zstd", "lz4"])
    p_build.add_argument("--encoder", default=None, help="Encoder preset or HuggingFace model ID (run 'rlat encoders' to list presets)")
    p_build.add_argument("--checkpoint", help="Trained heads checkpoint (recommended: sparsity_sweep/uniform90)")
    p_build.add_argument("--quantize-registry", type=int, default=0, metavar="BITS",
                          help="Quantize registry phases (0=off, 8=recommended 75%% compression, 4=aggressive 87%% compression)")
    p_build.add_argument("--store-mode", default="embedded", choices=["embedded", "external"],
                          help="embedded: full store in .rlat (default). external: field+registry only, resolve content from local files at query time via --source-root")
    p_build.add_argument("--progress", action="store_true",
                          help="Emit JSON progress lines to stdout (for programmatic consumers)")
    p_build.add_argument("--onnx", default=None,
                          help="ONNX backbone directory for faster encoding (2-5x CPU speedup)")
    p_build.add_argument("--input-format", default="", choices=["", "conversation"],
                          help="Force input format (default: auto-detect). 'conversation' uses turn-aware chunking.")
    p_build.add_argument("--session", default="", help="Session ID to tag all chunks with (conversation memory)")
    p_build.add_argument("--timestamp", default="", help="ISO timestamp to tag all chunks with (conversation memory)")

    # ── merge ──
    p_merge = subparsers.add_parser("merge", help="Merge two lattices into one")
    p_merge.add_argument("lattice_a", help="First .rlat file")
    p_merge.add_argument("lattice_b", help="Second .rlat file")
    p_merge.add_argument("--output", "-o", required=True, help="Output merged .rlat file")

    # ── forget ──
    p_forget = subparsers.add_parser("forget", help="Remove a source from a lattice")
    p_forget.add_argument("lattice", help="Path to .rlat file")
    p_forget.add_argument("--source", required=True, help="Source ID to remove")

    # ── summary ──
    p_summary = subparsers.add_parser("summary", help="Generate pre-injection context primer for CLAUDE.md")
    p_summary.add_argument("lattice", help="Path to .rlat file")
    p_summary.add_argument("--output", "-o", help="Output file (default: stdout)")
    p_summary.add_argument("--format", default="context", choices=["context", "stats"],
                           help="Output format: context (rich primer, default) or stats (field metadata only)")
    p_summary.add_argument("--queries", help="Custom bootstrap queries separated by semicolons")
    p_summary.add_argument("--top-k", type=int, default=20, help="Results per bootstrap query (default: 20)")
    p_summary.add_argument("--encoder", default=None, help="Encoder preset or HuggingFace model ID (run 'rlat encoders' to list presets)")
    p_summary.add_argument("--checkpoint", help="Trained heads checkpoint")
    p_summary.add_argument("--source-root", default=None,
                            help="External source root for file-backed store")
    p_summary.add_argument("--budget", type=int, default=2500,
                            help="Target token budget for output (default: 2500)")
    p_summary.add_argument("--sections",
                            help="Custom section names separated by semicolons "
                                 "(e.g. 'Background;Methods;Findings;Reference'). "
                                 "Default: auto-detect from corpus type")

    # ── resonate ──
    p_resonate = subparsers.add_parser("resonate", help="AI context: compressed output for LLM injection (use --mode to frame)")
    p_resonate.add_argument("lattice", help="Path to .rlat file")
    p_resonate.add_argument("query", help="Query text")
    p_resonate.add_argument("--top-k", type=int, default=10)
    p_resonate.add_argument("--encoder", default=None, help="Encoder preset or HuggingFace model ID (run 'rlat encoders' to list presets)")
    p_resonate.add_argument("--checkpoint", help="Trained heads checkpoint (recommended: sparsity_sweep/uniform90)")
    p_resonate.add_argument("--format", default="context", choices=["text", "json", "context", "prompt"])
    p_resonate.add_argument("--mode", default=None, choices=["augment", "constrain", "knowledge", "custom"],
                            help="Injection framing mode (augment=enrich, constrain=zero-hallucination)")
    p_resonate.add_argument("--custom-prompt", default=None, help="Custom system prompt (requires --mode custom)")
    p_resonate.add_argument("--source-root", default=None,
                             help="Resolve source content from local files under this directory instead of the embedded store")
    p_resonate.add_argument("--onnx", default=None,
                             help="ONNX backbone directory for faster encoding")
    p_resonate.add_argument("-v", "--verbose", action="store_true",
                             help="Show raw scores and detailed timings")

    # ── add (incremental) ──
    p_add = subparsers.add_parser("add", help="Incrementally add files to a cartridge")
    p_add.add_argument("lattice", help="Path to .rlat file")
    p_add.add_argument("inputs", nargs="+", help="Files or directories to add")
    p_add.add_argument("--encoder", default=None, help="Encoder preset or HuggingFace model ID (run 'rlat encoders' to list presets)")
    p_add.add_argument("--checkpoint", help="Trained heads checkpoint")
    p_add.add_argument("--onnx", default=None,
                        help="ONNX backbone directory for faster encoding")
    p_add.add_argument("--input-format", default="", choices=["", "conversation"],
                        help="Force input format (default: auto-detect). 'conversation' uses turn-aware chunking.")
    p_add.add_argument("--session", default="", help="Session ID to tag all chunks with (conversation memory)")
    p_add.add_argument("--timestamp", default="", help="ISO timestamp to tag all chunks with (conversation memory)")

    # ── sync ──
    p_sync = subparsers.add_parser("sync", help="Sync cartridge with source dirs (add/update/remove)")
    p_sync.add_argument("lattice", help="Path to .rlat file")
    p_sync.add_argument("inputs", nargs="+", help="Source directories to sync from")
    p_sync.add_argument("--encoder", default=None, help="Encoder preset or HuggingFace model ID (run 'rlat encoders' to list presets)")
    p_sync.add_argument("--checkpoint", help="Trained heads checkpoint")
    p_sync.add_argument("--progress", action="store_true",
                          help="Emit JSON progress lines to stdout (for programmatic consumers)")
    p_sync.add_argument("--onnx", default=None,
                          help="ONNX backbone directory for faster encoding")
    p_sync.add_argument("--input-format", default="", choices=["", "conversation"],
                          help="Force input format (default: auto-detect). 'conversation' uses turn-aware chunking.")
    p_sync.add_argument("--session", default="", help="Session ID to tag all chunks with (conversation memory)")
    p_sync.add_argument("--timestamp", default="", help="ISO timestamp to tag all chunks with (conversation memory)")

    # ── compare ──
    p_compare = subparsers.add_parser("compare", help="Compare two cartridges: overlap, unique coverage, depth")
    p_compare.add_argument("lattice_a", help="First .rlat file")
    p_compare.add_argument("lattice_b", help="Second .rlat file")
    p_compare.add_argument("--format", default="text", choices=["text", "json"])

    # ── ls ──
    p_ls = subparsers.add_parser("ls", help="List sources in a cartridge")
    p_ls.add_argument("lattice", help="Path to .rlat file")
    p_ls.add_argument("--format", default="text", choices=["text", "json"])
    p_ls.add_argument("-v", "--verbose", action="store_true", help="Show summaries")
    p_ls.add_argument("--head", type=int, default=None, help="Show only the first N sources")
    p_ls.add_argument("--grep", default=None, help="Filter sources by substring match")

    # ── profile ──
    p_profile = subparsers.add_parser("profile", help="Semantic profile of a cartridge")
    p_profile.add_argument("lattice", help="Path to .rlat file")
    p_profile.add_argument("--format", default="text", choices=["text", "json"])

    # ── search (enriched query) ──
    p_search = subparsers.add_parser("search", help="Primary search: enriched results with coverage, topics, and source paths")
    p_search.add_argument("lattice", help="Path to .rlat file")
    p_search.add_argument("query", help="Query text")
    p_search.add_argument("--top-k", type=int, default=10)
    p_search.add_argument("--format", default="text", choices=["text", "json", "context", "prompt"])
    p_search.add_argument("--cascade-depth", type=int, default=2, help="Cascade hop depth (default: 2)")
    p_search.add_argument("--contradiction-threshold", type=float, default=None,
                           help="Destructive interference threshold (default: -0.3 when enabled)")
    p_search.add_argument("--no-cascade", action="store_true", default=True,
                           help="Disable related topics cascade (default: disabled)")
    p_search.add_argument("--cascade", dest="no_cascade", action="store_false",
                           help="Enable related topics cascade")
    contradictions_group = p_search.add_mutually_exclusive_group()
    contradictions_group.add_argument("--with-contradictions", dest="enable_contradictions",
                                      action="store_true", help="Enable contradiction detection")
    contradictions_group.add_argument("--no-contradictions", dest="enable_contradictions",
                                      action="store_false", help="Disable contradiction detection")
    p_search.set_defaults(enable_contradictions=False)
    p_search.add_argument("--encoder", default=None, help="Encoder preset or HuggingFace model ID (run 'rlat encoders' to list presets)")
    p_search.add_argument("--checkpoint", help="Trained heads checkpoint")
    p_search.add_argument("--no-worker", action="store_true",
                           help="Disable background worker (env: RLAT_NO_WORKER=1)")
    p_search.add_argument("--source-root", default=None,
                           help="Resolve source content from local files under this directory instead of the embedded store")
    p_search.add_argument("--subgraph", action="store_true",
                           help="Expand results with spectral neighbours (richer context)")
    p_search.add_argument("--subgraph-k", type=int, default=3,
                           help="Neighbours per result for subgraph expansion (default: 3)")
    p_search.add_argument("--onnx", default=None,
                           help="ONNX backbone directory for faster encoding (auto-detects <stem>_onnx/)")
    p_search.add_argument("--rerank", default="auto", choices=["auto", "true", "false"],
                           help="Reranking mode: auto skips when dense is confident (default: auto)")
    p_search.add_argument("-v", "--verbose", action="store_true",
                           help="Show raw scores and detailed timings")
    p_search.add_argument("--mode", default=None, choices=["augment", "constrain", "knowledge", "custom"],
                           help="Injection framing mode for prompt/context formats")
    p_search.add_argument("--custom-prompt", default=None,
                           help="Custom system prompt (requires --mode custom)")
    # ── composition flags ──
    p_search.add_argument("--with", dest="with_cartridges", action="append", default=[],
                           help="Additional .rlat cartridge(s) to compose with (repeatable). "
                                "Merges fields, dispatches searches to each registry independently.")
    p_search.add_argument("--through", default=None,
                           help="Project primary cartridge through this .rlat's perspective "
                                "(semantic projection: 'show me A's knowledge through B's lens')")
    p_search.add_argument("--diff", dest="diff_against", default=None,
                           help="Show what's new in the primary cartridge vs this baseline .rlat "
                                "(queryable semantic diff)")
    # ── topic control flags ──
    p_search.add_argument("--boost", dest="boost_topics", action="append", default=[],
                           help="Boost a semantic topic during search (repeatable). "
                                "Amplifies the topic direction in the field before querying.")
    p_search.add_argument("--suppress", dest="suppress_topics", action="append", default=[],
                           help="Suppress a semantic topic during search (repeatable). "
                                "Attenuates the topic direction — like removing it on the fly.")
    p_search.add_argument("--boost-strength", type=float, default=0.5,
                           help="Strength of topic boosting (default: 0.5)")
    p_search.add_argument("--suppress-strength", type=float, default=0.3,
                           help="Strength of topic suppression (default: 0.3)")
    p_search.add_argument("--explain", action="store_true",
                           help="Show composition diagnostics before searching "
                                "(overlap, novelty, contradiction ratio between cartridges)")
    # ── cascade flags ──
    p_search.add_argument("--cascade-through", dest="cascade_route", nargs="+", default=None,
                           help="Cross-cartridge cascade: follow semantic links through a route of .rlat files. "
                                "E.g. --cascade-through docs.rlat incidents.rlat")
    p_search.add_argument("--access", default=None,
                           help="Apply an access policy (.rlens file or built from field). "
                                "Restricts visible knowledge to the policy's allowed subspace.")
    # ── lens flags ──
    p_search.add_argument("--lens", default=None,
                           help="Apply a named knowledge lens. Either a .rlens file path or a "
                                "built-in name: 'sharpen', 'flatten', 'denoise'")
    # ── conversation memory filters ──
    p_search.add_argument("--session", default=None,
                           help="Filter results by session ID (conversation memory)")
    p_search.add_argument("--after", default=None,
                           help="Filter results after ISO timestamp (conversation memory)")
    p_search.add_argument("--before", default=None,
                           help="Filter results before ISO timestamp (conversation memory)")
    p_search.add_argument("--speaker", default=None, choices=["human", "assistant", "system", "qa_pair"],
                           help="Filter results by speaker role (conversation memory)")
    p_search.add_argument("--recency-weight", type=float, default=0.0,
                           help="Blend recency into ranking (0.0=off, 0.3=moderate, 1.0=recency-only)")

    # ── compose (advanced expression-based composition) ──
    p_compose = subparsers.add_parser(
        "compose",
        help="Search with algebraic composition expressions or .rctx context files",
    )
    p_compose.add_argument("expression", help="Composition expression or path to .rctx file")
    p_compose.add_argument("query", help="Search query")
    p_compose.add_argument("--top-k", type=int, default=10)
    p_compose.add_argument("--format", default="text", choices=["text", "json"])
    p_compose.add_argument("--explain", action="store_true", help="Show composition diagnostics")
    p_compose.add_argument("--encoder", default=None)
    p_compose.add_argument("--checkpoint", default=None)
    p_compose.add_argument("--onnx", default=None)

    # ── contradictions ──
    p_contra = subparsers.add_parser("contradictions", help="Find contradicting sources")
    p_contra.add_argument("lattice", help="Path to .rlat file")
    p_contra.add_argument("query", help="Query text to check for contradictions")
    p_contra.add_argument("--band", type=int, default=2, help="Band to check (default: relations)")
    p_contra.add_argument("--threshold", type=float, default=0.7, help="Anti-correlation threshold")
    p_contra.add_argument("--top-k", type=int, default=20)
    p_contra.add_argument("--encoder", default=None, help="Encoder preset or HuggingFace model ID (run 'rlat encoders' to list presets)")
    p_contra.add_argument("--checkpoint", help="Trained heads checkpoint (recommended: sparsity_sweep/uniform90)")

    # ── serve ──
    p_serve = subparsers.add_parser("serve", help="Start lattice HTTP server")
    p_serve.add_argument("lattice", help="Path to .rlat file")
    p_serve.add_argument("--port", type=int, default=8080, help="Port number")
    p_serve.add_argument("--host", default="0.0.0.0", help="Bind address")
    p_serve.add_argument("--encoder", default=None, help="Encoder preset or HuggingFace model ID (run 'rlat encoders' to list presets)")
    p_serve.add_argument("--checkpoint", help="Trained heads checkpoint (recommended: sparsity_sweep/uniform90)")

    # ── topology ──
    p_topo = subparsers.add_parser("topology", help="Knowledge topology analysis")
    p_topo.add_argument("lattice", help="Path to .rlat file")
    p_topo.add_argument("--band", type=int, default=0)
    p_topo.add_argument("--top-k", type=int, default=20)
    p_topo.add_argument("--output", "-o", help="Output JSON file")

    # ── xray ──
    p_xray = subparsers.add_parser("xray", help="Field X-Ray: corpus-level semantic diagnostics")
    p_xray.add_argument("lattice", help="Path to .rlat file")
    p_xray.add_argument("--format", default="text", choices=["text", "json", "prompt"])
    p_xray.add_argument("--deep", action="store_true", help="Add topological analysis and community detection")

    # ── locate ──
    p_locate = subparsers.add_parser("locate", help="Query positioning: where does this question sit?")
    p_locate.add_argument("lattice", help="Path to .rlat file")
    p_locate.add_argument("query", help="Query text")
    p_locate.add_argument("--format", default="text", choices=["text", "json", "prompt"])
    p_locate.add_argument("--encoder", default=None, help="Encoder preset or HuggingFace model ID (run 'rlat encoders' to list presets)")
    p_locate.add_argument("--checkpoint", help="Trained heads checkpoint")

    # ── probe ──
    p_probe = subparsers.add_parser("probe", help="RQL quick insight recipes")
    p_probe.add_argument("lattice", help="Path to .rlat file")
    p_probe.add_argument("recipe", help="Recipe name: health, novelty, saturation, band-flow, anti, gaps")
    p_probe.add_argument("query", nargs="?", default="", help="Query text (required for novelty, anti)")
    p_probe.add_argument("--format", default="text", choices=["text", "json", "prompt"])
    p_probe.add_argument("--encoder", default=None, help="Encoder preset or HuggingFace model ID (run 'rlat encoders' to list presets)")
    p_probe.add_argument("--checkpoint", help="Trained heads checkpoint")

    # ── init-project ──
    p_initp = subparsers.add_parser("init-project",
        help="One-command setup: build cartridge + generate summary + integration instructions")
    p_initp.add_argument("inputs", nargs="*", help="Input files or directories (auto-detects if omitted)")
    p_initp.add_argument("--output", "-o", help="Summary output path (default: .claude/resonance-context.md)")
    p_initp.add_argument("--encoder", default=None, help="Encoder preset or HuggingFace model ID (run 'rlat encoders' to list presets)")
    p_initp.add_argument("--checkpoint", help="Trained heads checkpoint")
    p_initp.add_argument("--onnx", default=None,
                          help="ONNX backbone directory for faster encoding")
    p_initp.add_argument("--auto-integrate", action="store_true",
                          help="Automatically update .mcp.json, inject CLAUDE.md cartridge section, "
                               "and create .rlat/manifest.json")

    # ── encoders ──
    subparsers.add_parser("encoders", help="List available encoder presets")

    # ── Export subcommand (field-only cartridges, PR #60) ──────────
    p_export = subparsers.add_parser("export", help="Export a cartridge (supports field-only mode)")
    p_export.add_argument("cartridge", help="Source .rlat cartridge")
    p_export.add_argument("--output", "-o", required=True, help="Output path")
    p_export.add_argument("--field-only", action="store_true",
                          help="Export field+registry without source store (privacy-preserving)")

    # ── MCP server ───────────────────────────────────────────────────
    p_mcp = subparsers.add_parser("mcp", help="Start MCP server (stdio transport) for Claude Code")
    p_mcp.add_argument("cartridge", help="Path to .rlat cartridge")
    p_mcp.add_argument("--source-root", default=None,
                        help="External source root for file-backed store")
    p_mcp.add_argument("--onnx", default=None,
                        help="ONNX backbone directory for faster encoding")

    # ── skill ─────────────────────────────────────────────────────────
    p_skill = subparsers.add_parser("skill", help="Skill cartridge integration (build, sync, search)")
    skill_sub = p_skill.add_subparsers(dest="skill_command")

    p_sk_build = skill_sub.add_parser("build", help="Build cartridge from skill's reference materials")
    p_sk_build.add_argument("skill_dir", help="Path to skill directory (containing SKILL.md)")
    p_sk_build.add_argument("--encoder", default=None, help="Encoder preset or HuggingFace model ID")
    p_sk_build.add_argument("--checkpoint", default=None, help="Trained heads checkpoint")
    p_sk_build.add_argument("--onnx", default=None, help="ONNX backbone directory")

    p_sk_sync = skill_sub.add_parser("sync", help="Incrementally sync a skill's cartridge")
    p_sk_sync.add_argument("skill_dir", help="Path to skill directory (containing SKILL.md)")
    p_sk_sync.add_argument("--encoder", default=None, help="Encoder preset or HuggingFace model ID")
    p_sk_sync.add_argument("--checkpoint", default=None, help="Trained heads checkpoint")
    p_sk_sync.add_argument("--onnx", default=None, help="ONNX backbone directory")

    p_sk_search = skill_sub.add_parser("search", help="Search a skill's cartridges")
    p_sk_search.add_argument("skill_name", help="Skill name or path to skill directory")
    p_sk_search.add_argument("query", help="Search query")
    p_sk_search.add_argument("--top-k", type=int, default=10)
    p_sk_search.add_argument("--format", default="text", choices=["text", "json", "context", "prompt"])
    p_sk_search.add_argument("--encoder", default=None, help="Encoder preset or HuggingFace model ID")
    p_sk_search.add_argument("--checkpoint", default=None, help="Trained heads checkpoint")
    p_sk_search.add_argument("--source-root", default=None, help="External source root")
    p_sk_search.add_argument("--onnx", default=None, help="ONNX backbone directory")

    p_sk_info = skill_sub.add_parser("info", help="Show skill cartridge configuration and status")
    p_sk_info.add_argument("skill_name", nargs="?", default=None,
                           help="Skill name or path (omit to list all)")

    p_sk_inject = skill_sub.add_parser("inject", help="Four-tier adaptive context injection")
    p_sk_inject.add_argument("skill_name", help="Skill name or path to skill directory")
    p_sk_inject.add_argument("query", help="User query to inject context for")
    p_sk_inject.add_argument("--format", default="text", choices=["text", "json", "context"],
                              help="Output format (text=diagnostic, json=structured, context=injectable body)")
    p_sk_inject.add_argument("--derived", default=None,
                              help="Tier 4 derived queries (semicolon-separated). Omit to skip Tier 4.")
    p_sk_inject.add_argument("--encoder", default=None, help="Encoder preset or HuggingFace model ID")
    p_sk_inject.add_argument("--checkpoint", default=None, help="Trained heads checkpoint")
    p_sk_inject.add_argument("--source-root", default=None, help="External source root")
    p_sk_inject.add_argument("--onnx", default=None, help="ONNX backbone directory")

    p_sk_route = skill_sub.add_parser("route", help="Rank skills by relevance to a query")
    p_sk_route.add_argument("query", help="Query to route")
    p_sk_route.add_argument("--top-n", type=int, default=5, help="Max skills to return")
    p_sk_route.add_argument("--format", default="text", choices=["text", "json"])

    p_sk_profile = skill_sub.add_parser("profile", help="Semantic profile of a skill's cartridge")
    p_sk_profile.add_argument("skill_name", help="Skill name or path to skill directory")
    p_sk_profile.add_argument("--format", default="text", choices=["text", "json"])

    p_sk_fresh = skill_sub.add_parser("freshness", help="Check freshness of skill cartridges")
    p_sk_fresh.add_argument("skill_name", nargs="?", default=None,
                            help="Skill name or path (omit for all)")
    p_sk_fresh.add_argument("--format", default="text", choices=["text", "json"])

    p_sk_gaps = skill_sub.add_parser("gaps", help="Detect knowledge gaps in a skill's cartridge")
    p_sk_gaps.add_argument("skill_name", help="Skill name or path to skill directory")
    p_sk_gaps.add_argument("--format", default="text", choices=["text", "json", "prompt"])
    p_sk_gaps.add_argument("--encoder", default=None, help="Encoder preset or HuggingFace model ID")
    p_sk_gaps.add_argument("--checkpoint", default=None, help="Trained heads checkpoint")

    p_sk_compare = skill_sub.add_parser("compare", help="Compare two skills' cartridges")
    p_sk_compare.add_argument("skill_a", help="First skill name or path")
    p_sk_compare.add_argument("skill_b", help="Second skill name or path")
    p_sk_compare.add_argument("--format", default="text", choices=["text", "json"])

    # ── Health ──
    p_health = subparsers.add_parser("health", help="Knowledge health check: signal, bands, contradictions, drift")
    p_health.add_argument("lattice", help="Cartridge to check")
    p_health.add_argument("--baseline", default=None, help="Compare against baseline for drift/contradiction detection")
    p_health.add_argument("--ci", action="store_true", help="CI mode: exit 1 on CRITICAL status")
    p_health.add_argument("--format", default="text", choices=["text", "json"])

    # ── Negotiate ──
    p_negotiate = subparsers.add_parser("negotiate",
        help="Analyze relationship between two knowledge cartridges: shared ground, novelty, disagreements")
    p_negotiate.add_argument("cartridge_a", help="First cartridge")
    p_negotiate.add_argument("cartridge_b", help="Second cartridge")
    p_negotiate.add_argument("--query", default=None, help="Focus analysis on a specific topic")
    p_negotiate.add_argument("--format", default="text", choices=["text", "json"])

    # ── Memory subcommands ────────────────────────────────────────────
    p_memory = subparsers.add_parser("memory", help="Agent memory: search, add, forget, stats")
    memory_sub = p_memory.add_subparsers(dest="memory_command")

    p_mem_search = memory_sub.add_parser("search", help="Search memory for relevant prior context")
    p_mem_search.add_argument("query", help="What to recall")
    p_mem_search.add_argument("--top-k", type=int, default=5)
    p_mem_search.add_argument("--format", default="text", choices=["text", "json"])

    p_mem_add = memory_sub.add_parser("add", help="Add content to memory")
    p_mem_add.add_argument("--content", required=True, help="Text to remember")
    p_mem_add.add_argument("--session", default="", help="Session ID tag")

    p_mem_forget = memory_sub.add_parser("forget", help="Provably remove from memory")
    p_mem_forget.add_argument("--topic", default=None, help="Topic to forget")
    p_mem_forget.add_argument("--session", default=None, help="Session ID to forget")

    p_mem_stats = memory_sub.add_parser("stats", help="Memory cartridge statistics")

    # ── Lens subcommands ──────────────────────────────────────────────
    p_lens = subparsers.add_parser("lens", help="Knowledge lenses: named semantic perspectives")
    lens_sub = p_lens.add_subparsers(dest="lens_command")

    p_lens_create = lens_sub.add_parser("create", help="Create a lens from topics or a cartridge")
    p_lens_create.add_argument("-o", "--output", required=True, help="Output .rlens file path")
    p_lens_create.add_argument("--topics", default=None,
                                help="Comma-separated topic strings (e.g. 'security,auth,encryption')")
    p_lens_create.add_argument("--from", dest="from_cartridge", default=None,
                                help="Build lens from a cartridge's eigenspace")
    p_lens_create.add_argument("--rank", type=int, default=None,
                                help="Subspace rank (default: auto from effective rank)")
    p_lens_create.add_argument("--encoder", default=None, help="Encoder preset or HuggingFace model ID")
    p_lens_create.add_argument("--onnx", default=None, help="ONNX backbone directory")

    p_lens_list = lens_sub.add_parser("list", help="List available .rlens files")
    p_lens_list.add_argument("--dir", default=".", help="Directory to search (default: current)")

    p_lens_compose = lens_sub.add_parser("compose", help="Compose two lenses (subspace intersection)")
    p_lens_compose.add_argument("lens_a", help="First .rlens file")
    p_lens_compose.add_argument("lens_b", help="Second .rlens file")
    p_lens_compose.add_argument("-o", "--output", required=True, help="Output .rlens file path")

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    commands = {
        "init": cmd_init,
        "build": cmd_build,
        "ingest": cmd_ingest,
        "query": cmd_query,
        "resonate": cmd_resonate,
        "info": cmd_info,
        "summary": cmd_summary,
        "diff": cmd_diff,
        "merge": cmd_merge,
        "forget": cmd_forget,
        "add": cmd_add,
        "sync": cmd_sync,
        "compare": cmd_compare,
        "ls": cmd_ls,
        "profile": cmd_profile,
        "search": cmd_search,
        "compose": cmd_compose,
        "contradictions": cmd_contradictions,
        "serve": cmd_serve,
        "topology": cmd_topology,
        "xray": cmd_xray,
        "locate": cmd_locate,
        "probe": cmd_probe,
        "init-project": cmd_init_project,

        "encoders": cmd_encoders,
        "export": cmd_export,
        "mcp": cmd_mcp,
        "skill": cmd_skill,
        "lens": cmd_lens,
        "health": cmd_health,
        "negotiate": cmd_negotiate,
        "memory": cmd_memory,
    }

    commands[args.command](args)


if __name__ == "__main__":
    main()
