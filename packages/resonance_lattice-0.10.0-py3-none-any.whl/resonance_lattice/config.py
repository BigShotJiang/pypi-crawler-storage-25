"""Configuration dataclasses for the Resonance Lattice."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class FieldType(StrEnum):
    """Storage backend for the interference field tensor."""
    DENSE = "dense"
    ASYMMETRIC_DENSE = "asymmetric_dense"
    FACTORED = "factored"
    PQ = "pq"


class Precision(StrEnum):
    """Floating-point precision for field storage."""
    F16 = "f16"
    BF16 = "bf16"
    F32 = "f32"


class Compression(StrEnum):
    """Compression algorithm for serialisation."""
    NONE = "none"
    ZSTD = "zstd"
    LZ4 = "lz4"


class StoreMode(StrEnum):
    """How source content is stored in the cartridge."""
    EMBEDDED = "embedded"   # Full store inside .rlat (default)
    EXTERNAL = "external"   # No store — resolve source_ids to local files at query time


@dataclass(frozen=True)
class LatticeConfig:
    """Configuration for a Resonance Lattice instance.

    Attributes:
        bands: Number of frequency bands (Omega_1 through Omega_B).
        dim: Dimensionality per band (D). Phase vectors are D-dimensional.
            For symmetric field types (dense, factored, pq), D is used for both
            key and value. For asymmetric_dense, see dim_key and dim_value.
        field_type: Storage backend — dense, asymmetric_dense, factored (SVD),
            or pq (product-quantised).
        dim_key: Key dimensionality for asymmetric field. Either a single int
            (uniform across bands) or a tuple of length B (per-band sizing).
            Only used when field_type="asymmetric_dense". If None, falls back to dim.
        dim_value: Value dimensionality for asymmetric field. Either a single int
            or a tuple of length B. Only used when field_type="asymmetric_dense".
            If None, falls back to dim.
        pq_subspaces: M — number of PQ subspaces (only used when field_type="pq").
        pq_codebook_size: K — centroids per subspace (only used when field_type="pq").
        svd_rank: K — rank for factored SVD field (only used when field_type="factored").
        precision: Floating-point precision for field storage.
        compression: Compression for .rlat serialisation.
        temporal_windows: Number of time-horizon field tensors (e.g. recent/medium/archive).
    """
    bands: int = 5
    dim: int = 2048
    field_type: FieldType = FieldType.DENSE
    dim_key: int | tuple[int, ...] | None = None
    dim_value: int | tuple[int, ...] | None = None
    pq_subspaces: int = 8
    pq_codebook_size: int = 1024
    svd_rank: int = 512
    precision: Precision = Precision.F16
    compression: Compression = Compression.ZSTD
    temporal_windows: int = 3

    def __post_init__(self) -> None:
        if self.bands < 1:
            raise ValueError(f"bands must be >= 1, got {self.bands}")
        if self.dim < 64:
            raise ValueError(f"dim must be >= 64, got {self.dim}")
        if self.field_type == FieldType.PQ:
            if self.dim % self.pq_subspaces != 0:
                raise ValueError(
                    f"dim ({self.dim}) must be divisible by pq_subspaces ({self.pq_subspaces})"
                )
        if self.field_type == FieldType.ASYMMETRIC_DENSE:
            dk = self.dim_key if self.dim_key is not None else self.dim
            dv = self.dim_value if self.dim_value is not None else self.dim
            if isinstance(dk, tuple) and len(dk) != self.bands:
                raise ValueError(
                    f"dim_key tuple length ({len(dk)}) must equal bands ({self.bands})"
                )
            if isinstance(dv, tuple) and len(dv) != self.bands:
                raise ValueError(
                    f"dim_value tuple length ({len(dv)}) must equal bands ({self.bands})"
                )

    @property
    def subspace_dim(self) -> int:
        """Dimensionality of each PQ subspace (D / M)."""
        return self.dim // self.pq_subspaces

    @property
    def field_size_bytes(self) -> int:
        """Estimated field tensor size in bytes."""
        bytes_per_elem = 2 if self.precision in (Precision.F16, Precision.BF16) else 4
        if self.field_type == FieldType.DENSE:
            return self.bands * self.dim * self.dim * bytes_per_elem
        elif self.field_type == FieldType.ASYMMETRIC_DENSE:
            dk = self.dim_key if self.dim_key is not None else self.dim
            dv = self.dim_value if self.dim_value is not None else self.dim
            if isinstance(dk, tuple) and isinstance(dv, tuple):
                return sum(k * v for k, v in zip(dk, dv)) * bytes_per_elem
            dk_int = dk if isinstance(dk, int) else dk[0]
            dv_int = dv if isinstance(dv, int) else dv[0]
            return self.bands * dk_int * dv_int * bytes_per_elem
        elif self.field_type == FieldType.FACTORED:
            # U[D x K] + Sigma[K] + V[D x K] per band
            return self.bands * (2 * self.dim * self.svd_rank + self.svd_rank) * bytes_per_elem
        elif self.field_type == FieldType.PQ:
            # Per band, per subspace: codebook[K x D/M] + quantised_field[K x K]
            M = self.pq_subspaces
            K = self.pq_codebook_size
            d = self.subspace_dim
            per_band = M * (K * d + K * K) * bytes_per_elem
            return self.bands * per_band
        return 0

    @property
    def field_size_mb(self) -> float:
        """Estimated field tensor size in megabytes."""
        return self.field_size_bytes / (1024 * 1024)


# Default sparsity targets per band from the spec (Section 5.1).
# Relaxed from original spec: Topic 8%→25%, Entity 15%→37.5%.
# Denser representations let the field carry richer signal, improving
# field-only retrieval quality without relying on external indexes.
DEFAULT_SPARSITY_TARGETS = {
    1: 0.05,    # Omega_1 (Domain): 5%
    2: 0.25,    # Omega_2 (Topic): 25%  (was 8%)
    3: 0.10,    # Omega_3 (Relations): 10%
    4: 0.375,   # Omega_4 (Entities): 37.5%  (was 15%)
    5: 0.20,    # Omega_5 (Verbatim): 20%
}


# ── Encoder presets ────────────────────────────────────────────────
# Named configurations for supported backbones.  Each preset maps a
# short CLI name to the full set of encoder parameters the backbone
# requires.  Users select a preset with ``--encoder <name>`` or pass
# a raw HuggingFace model ID for unlisted models.

_QWEN3_QUERY_PREFIX = (
    "Instruct: Given a web search query, retrieve relevant passages "
    "that answer the query\nQuery: "
)

ENCODER_PRESETS: dict[str, dict] = {
    "e5-large-v2": {
        "backbone": "intfloat/e5-large-v2",
        "query_prefix": "query: ",
        "passage_prefix": "passage: ",
        "pooling": "mean",
        "max_length": 512,
    },
    "qwen3-0.6b": {
        "backbone": "Qwen/Qwen3-Embedding-0.6B",
        "query_prefix": _QWEN3_QUERY_PREFIX,
        "passage_prefix": "",
        "pooling": "mean",
        "max_length": 32768,
    },
    "qwen3-4b": {
        "backbone": "Qwen/Qwen3-Embedding-4B",
        "query_prefix": _QWEN3_QUERY_PREFIX,
        "passage_prefix": "",
        "pooling": "mean",
        "max_length": 32768,
    },
    "qwen3-8b": {
        "backbone": "Qwen/Qwen3-Embedding-8B",
        "query_prefix": _QWEN3_QUERY_PREFIX,
        "passage_prefix": "",
        "pooling": "mean",
        "max_length": 32768,
    },
    "arctic-embed-2": {
        "backbone": "Snowflake/snowflake-arctic-embed-l-v2.0",
        "query_prefix": "query: ",
        "passage_prefix": "",
        "pooling": "cls",
        "max_length": 8192,
    },
    "nemotron-1b": {
        "backbone": "nvidia/llama-nemotron-embed-1b-v2",
        "query_prefix": "query: ",
        "passage_prefix": "passage: ",
        "pooling": "mean",
        "max_length": 8192,
    },
    "nomic-v2": {
        "backbone": "nomic-ai/nomic-embed-text-v2-moe",
        "query_prefix": "search_query: ",
        "passage_prefix": "search_document: ",
        "pooling": "mean",
        "max_length": 8192,
    },
    "bge-m3": {
        "backbone": "BAAI/bge-m3",
        "query_prefix": "",
        "passage_prefix": "",
        "pooling": "cls",
        "max_length": 8192,
    },
    # ── Code-strong presets ──────────────────────────────────────────
    "gte-large": {
        "backbone": "Alibaba-NLP/gte-large-en-v1.5",
        "query_prefix": "",
        "passage_prefix": "",
        "pooling": "mean",
        "max_length": 8192,
    },
    "gte-qwen2-1.5b": {
        "backbone": "Alibaba-NLP/gte-Qwen2-1.5B-instruct",
        "query_prefix": "",
        "passage_prefix": "",
        "pooling": "mean",
        "max_length": 8192,
        "trust_remote_code": False,
    },
    "jina-v3": {
        "backbone": "jinaai/jina-embeddings-v3",
        "query_prefix": "",
        "passage_prefix": "",
        "pooling": "mean",
        "max_length": 8192,
    },
}


@dataclass(frozen=True)
class EncoderConfig:
    """Configuration for the multi-scale encoder.

    Attributes:
        backbone: HuggingFace model name for the shared transformer backbone.
        bands: Number of frequency bands to produce.
        dim: Output dimensionality per band (D).
        sparsity: Target sparsity (fraction of non-zero components) per band.
            Length must equal bands. If None, uses defaults from spec.
        backbone_dim: Hidden dimension of the backbone (auto-detected if None).
        query_prefix: Text prepended to queries before encoding (E5: "query: ").
        passage_prefix: Text prepended to passages before encoding (E5: "passage: ").
        pooling: Pooling strategy for backbone output. "mean" uses attention-masked
            mean pooling (E5 recipe, default for new cartridges). "cls" uses [CLS]
            token. Legacy cartridges loaded without protocol metadata fall back to
            "cls" for backward compatibility.
        max_length: Maximum token length for backbone tokenization. Defaults to 512
            for backward compatibility; presets override this per model.
    """
    backbone: str = "intfloat/e5-large-v2"
    bands: int = 2  # MVP default: topic + entity
    dim: int = 2048
    sparsity: tuple[float, ...] | None = None
    backbone_dim: int | None = None  # Auto-detected from model
    query_prefix: str = "query: "
    passage_prefix: str = "passage: "
    pooling: str = "mean"  # "mean" (E5 recipe) or "cls"; legacy fallback is "cls"
    max_length: int = 512

    def __post_init__(self) -> None:
        if self.sparsity is not None and len(self.sparsity) != self.bands:
            raise ValueError(
                f"sparsity length ({len(self.sparsity)}) must equal bands ({self.bands})"
            )

    def get_sparsity(self, band_index: int) -> float:
        """Get the sparsity target for a given band (0-indexed)."""
        if self.sparsity is not None:
            return self.sparsity[band_index]
        # Map to 1-indexed band numbers for the default lookup
        band_num = band_index + 1
        if self.bands == 2:
            # MVP: band 0 = Topic (Omega_2), band 1 = Entity (Omega_4)
            return DEFAULT_SPARSITY_TARGETS[2 if band_index == 0 else 4]
        return DEFAULT_SPARSITY_TARGETS.get(band_num, 0.10)


@dataclass(frozen=True)
class MaterialiserConfig:
    """Configuration for the context materialiser.

    Attributes:
        token_budget: Total token budget for the assembled context.
        landscape_tokens: Tokens allocated to landscape context (Omega_1-2).
        structure_tokens: Tokens allocated to structural context (Omega_3).
        evidence_tokens: Tokens allocated to evidence passages (Omega_4-5).
    """
    token_budget: int = 3000
    landscape_tokens: int = 300
    structure_tokens: int = 400
    evidence_tokens: int = 2000

    def __post_init__(self) -> None:
        allocated = self.landscape_tokens + self.structure_tokens + self.evidence_tokens
        if allocated > self.token_budget:
            raise ValueError(
                f"Allocated tokens ({allocated}) exceed budget ({self.token_budget})"
            )


@dataclass
class SalienceWeights:
    """Weights for computing source salience (alpha_i).

    salience = recency * authority * density * novelty
    Each component is in [0, 1].
    """
    recency: float = 1.0
    authority: float = 1.0
    density: float = 1.0
    novelty: float = 1.0

    @property
    def value(self) -> float:
        """Compute the combined salience weight."""
        return self.recency * self.authority * self.density * self.novelty
