"""Clustered registry for O(sqrt(N)) lookup via semantic routing.

Star schema principle: if many sources share similar key signatures,
store the shared signature once (as a cluster centroid) and route
queries to matching clusters before scoring individual sources.

This reduces brute-force scoring from O(N * B * D) to
O(C * B * D + n_c * B * D) where C = num_clusters and n_c is the
average cluster size for top-c matching clusters.

Build time: k-means clustering on key vectors.
Query time: score cluster centroids → score sources within top clusters.
"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

from resonance_lattice.registry import SourcePointer


class ClusteredRegistry:
    """Two-level registry: cluster centroids → per-cluster source lists.

    At build time, sources are assigned to clusters via k-means on their
    fused key vectors. At query time, cluster centroids are scored first
    (cheap: C << N), then individual sources within the top-c clusters
    are scored exactly (focused: only n_c sources per cluster).

    This is the registry equivalent of IVF (Inverted File) indexing.
    """

    def __init__(
        self,
        dim: int,
        bands: int,
        num_clusters: int | None = None,
        top_clusters: int = 3,
    ) -> None:
        """
        Args:
            dim: Key dimensionality per band (D_key). Used for fused vector dimension.
            bands: Number of frequency bands (B).
            num_clusters: Number of clusters (C). If None, auto-computed as sqrt(N)
                at build time.
            top_clusters: Number of clusters to probe at query time.
        """
        self.dim = dim
        self.bands = bands
        self.num_clusters = num_clusters
        self.top_clusters = top_clusters

        # Source storage
        self._source_keys: dict[str, NDArray[np.float32]] = {}   # source_id → (B, D)
        self._source_salience: dict[str, float] = {}
        self._source_fused: dict[str, NDArray[np.float32]] = {}  # source_id → (D,) fused

        # Cluster state (built by build_index)
        self._centroids: NDArray[np.float32] | None = None  # (C, D)
        self._cluster_assignments: dict[str, int] = {}       # source_id → cluster_id
        self._cluster_members: dict[int, list[str]] = {}     # cluster_id → [source_ids]
        self._index_built = False

    @property
    def source_count(self) -> int:
        return len(self._source_keys)

    def register(
        self,
        source_id: str,
        key_vectors: NDArray[np.float32],
        salience: float = 1.0,
    ) -> None:
        """Register a source. Index must be rebuilt after adding sources.

        Args:
            source_id: Unique identifier.
            key_vectors: Shape (B, D) — key-space vectors.
            salience: Source salience weight.
        """
        self._source_keys[source_id] = key_vectors.copy()
        self._source_salience[source_id] = salience
        # Fuse to D-dim for clustering/scoring
        self._source_fused[source_id] = key_vectors.mean(axis=0)
        self._index_built = False

    def unregister(self, source_id: str) -> None:
        """Remove a source. Index must be rebuilt after removal."""
        self._source_keys.pop(source_id, None)
        self._source_salience.pop(source_id, None)
        self._source_fused.pop(source_id, None)
        self._cluster_assignments.pop(source_id, None)
        self._index_built = False

    def build_index(self, max_iter: int = 20, seed: int = 42) -> None:
        """Build cluster index via k-means on fused key vectors.

        Args:
            max_iter: Maximum k-means iterations.
            seed: Random seed for centroid initialization.
        """
        N = self.source_count
        if N == 0:
            self._index_built = True
            return

        # Auto-compute cluster count
        C = self.num_clusters
        if C is None:
            C = max(1, int(np.sqrt(N)))
        C = min(C, N)  # Can't have more clusters than sources

        # Collect fused vectors
        source_ids = list(self._source_fused.keys())
        X = np.stack([self._source_fused[sid] for sid in source_ids])  # (N, D)

        # k-means
        rng = np.random.default_rng(seed)
        # Init: k-means++
        centroids = self._kmeans_pp_init(X, C, rng)

        for _ in range(max_iter):
            # Assign each point to nearest centroid
            dists = self._pairwise_distances(X, centroids)  # (N, C)
            assignments = dists.argmin(axis=1)  # (N,)

            # Update centroids
            new_centroids = np.zeros_like(centroids)
            for c in range(C):
                mask = assignments == c
                if mask.any():
                    new_centroids[c] = X[mask].mean(axis=0)
                else:
                    # Empty cluster — reinit to a random point
                    new_centroids[c] = X[rng.integers(N)]

            # Check convergence
            if np.allclose(centroids, new_centroids, atol=1e-6):
                break
            centroids = new_centroids

        # Store results
        self._centroids = centroids
        self._cluster_assignments = {}
        self._cluster_members = {c: [] for c in range(C)}
        for i, sid in enumerate(source_ids):
            c = int(assignments[i])
            self._cluster_assignments[sid] = c
            self._cluster_members[c].append(sid)

        self._index_built = True

    def lookup(
        self,
        query_key: NDArray[np.float32],
        top_k: int = 20,
        band_weights: NDArray[np.float32] | None = None,
    ) -> list[SourcePointer]:
        """Two-level lookup: score clusters, then score sources within top clusters.

        Args:
            query_key: Shape (B, D) — query key vectors.
            top_k: Number of results to return.
            band_weights: Per-band weights for scoring.

        Returns:
            List of SourcePointer sorted by score (descending).
        """
        if not self._index_built or self._centroids is None:
            return self._brute_force_lookup(query_key, top_k, band_weights)

        # Fuse query to D-dim
        q_fused = query_key.mean(axis=0)  # (D,)
        C = self._centroids.shape[0]
        c_to_probe = min(self.top_clusters, C)

        # Score cluster centroids
        centroid_scores = self._centroids @ q_fused  # (C,) — dot product
        top_c = np.argsort(-centroid_scores)[:c_to_probe]

        # Collect candidate source_ids from top clusters
        candidates = []
        for c in top_c:
            candidates.extend(self._cluster_members.get(int(c), []))

        if not candidates:
            return []

        # Exact scoring within candidates
        scored = []
        for sid in candidates:
            kv = self._source_keys[sid]
            sal = self._source_salience[sid]
            if band_weights is not None:
                score = float(sum(
                    band_weights[b] * np.dot(kv[b], query_key[b])
                    for b in range(self.bands)
                )) * sal
            else:
                score = float(sum(
                    np.dot(kv[b], query_key[b])
                    for b in range(self.bands)
                )) * sal
            # Compute band signature
            band_sig = np.array([
                np.dot(kv[b], query_key[b]) for b in range(self.bands)
            ], dtype=np.float32)
            scored.append(SourcePointer(
                source_id=sid,
                fidelity_score=score,
                band_signature=band_sig,
            ))

        # Sort by score and return top-k
        scored.sort(key=lambda sp: sp.fidelity_score, reverse=True)
        return scored[:top_k]

    def _brute_force_lookup(
        self,
        query_key: NDArray[np.float32],
        top_k: int,
        band_weights: NDArray[np.float32] | None,
    ) -> list[SourcePointer]:
        """Fallback brute-force scoring when index is not built."""
        scored = []
        for sid, kv in self._source_keys.items():
            sal = self._source_salience[sid]
            if band_weights is not None:
                score = float(sum(
                    band_weights[b] * np.dot(kv[b], query_key[b])
                    for b in range(self.bands)
                )) * sal
            else:
                score = float(sum(
                    np.dot(kv[b], query_key[b])
                    for b in range(self.bands)
                )) * sal
            scored.append(SourcePointer(
                source_id=sid,
                fidelity_score=score,
            ))
        scored.sort(key=lambda sp: sp.fidelity_score, reverse=True)
        return scored[:top_k]

    @staticmethod
    def _pairwise_distances(X: NDArray, centroids: NDArray) -> NDArray:
        """Compute squared L2 distances between X and centroids.

        Args:
            X: Shape (N, D).
            centroids: Shape (C, D).

        Returns:
            Shape (N, C) — squared distances.
        """
        # ||x - c||^2 = ||x||^2 + ||c||^2 - 2*x.c
        x_sq = np.sum(X ** 2, axis=1, keepdims=True)  # (N, 1)
        c_sq = np.sum(centroids ** 2, axis=1, keepdims=True).T  # (1, C)
        cross = X @ centroids.T  # (N, C)
        return x_sq + c_sq - 2 * cross

    @staticmethod
    def _kmeans_pp_init(X: NDArray, C: int, rng) -> NDArray:
        """k-means++ initialization for better centroid seeding.

        Picks the first centroid randomly, then each subsequent centroid
        with probability proportional to its squared distance from the
        nearest existing centroid.
        """
        N, D = X.shape
        centroids = np.zeros((C, D), dtype=X.dtype)

        # First centroid: random
        centroids[0] = X[rng.integers(N)]

        for c in range(1, C):
            # Squared distance from each point to nearest centroid
            dists = np.min(
                np.sum((X[:, np.newaxis, :] - centroids[np.newaxis, :c, :]) ** 2, axis=2),
                axis=1,
            )  # (N,)
            # Probability proportional to distance
            probs = dists / (dists.sum() + 1e-12)
            centroids[c] = X[rng.choice(N, p=probs)]

        return centroids

    def to_bytes(self) -> bytes:
        """Serialize cluster index to bytes.

        Format: [C:u32][D:u32][centroids: C*D*f32][num_assignments:u32][assignments...]
        """
        import struct

        if self._centroids is None:
            return struct.pack("<II", 0, self.dim)

        C, D = self._centroids.shape
        parts = [struct.pack("<II", C, D)]
        parts.append(self._centroids.astype(np.float32).tobytes())

        # Assignments
        parts.append(struct.pack("<I", len(self._cluster_assignments)))
        for source_id, cluster_id in self._cluster_assignments.items():
            id_bytes = source_id.encode("utf-8")
            parts.append(struct.pack("<HI", len(id_bytes), cluster_id))
            parts.append(id_bytes)

        return b"".join(parts)

    @classmethod
    def from_bytes(cls, data: bytes, dim: int, bands: int) -> ClusteredRegistry:
        """Deserialize cluster index."""
        import struct

        reg = cls(dim=dim, bands=bands)
        offset = 0

        C, D = struct.unpack_from("<II", data, offset)
        offset += 8

        if C == 0:
            return reg

        centroids_size = C * D * 4
        reg._centroids = np.frombuffer(
            data[offset:offset + centroids_size], dtype=np.float32
        ).reshape(C, D).copy()
        offset += centroids_size

        (num_assign,) = struct.unpack_from("<I", data, offset)
        offset += 4

        reg._cluster_members = {c: [] for c in range(C)}
        for _ in range(num_assign):
            id_len, cluster_id = struct.unpack_from("<HI", data, offset)
            offset += 6
            source_id = data[offset:offset + id_len].decode("utf-8")
            offset += id_len
            reg._cluster_assignments[source_id] = cluster_id
            reg._cluster_members[cluster_id].append(source_id)

        reg._index_built = True
        return reg
