"""
Resonance Lattice - A next-generation AI context retrieval layer.

Information is not stored as objects to be found. It is encoded as a field
to be excited. The query doesn't find the answer. The query IS the resonance
that makes the answer emerge.
"""

__version__ = "0.10.0"

# Lazy imports — heavy modules (torch, scipy) are only loaded when accessed.
# This keeps `python -m resonance_lattice.cli` startup fast for the warm
# worker path, which only needs stdlib.

_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    # Production SDK (WS1)
    "Config": ("resonance_lattice.lattice", "Config"),
    "Lattice": ("resonance_lattice.lattice", "Lattice"),
    "MaterialisedResult": ("resonance_lattice.lattice", "MaterialisedResult"),
    # Config
    "LatticeConfig": ("resonance_lattice.config", "LatticeConfig"),
    "EncoderConfig": ("resonance_lattice.config", "EncoderConfig"),
    "MaterialiserConfig": ("resonance_lattice.config", "MaterialiserConfig"),
    # Encoder (pulls in torch)
    "Encoder": ("resonance_lattice.encoder", "Encoder"),
    "PhaseSpectrum": ("resonance_lattice.encoder", "PhaseSpectrum"),
    # Fields
    "DenseField": ("resonance_lattice.field.dense", "DenseField"),
    "FactoredField": ("resonance_lattice.field.factored", "FactoredField"),
    "PQField": ("resonance_lattice.field.pq", "PQField"),
    # Materialiser
    "Materialiser": ("resonance_lattice.materialiser", "Materialiser"),
    "MaterialisedContext": ("resonance_lattice.materialiser", "MaterialisedContext"),
    # Registry & Store
    "PhaseRegistry": ("resonance_lattice.registry", "PhaseRegistry"),
    "SourceStore": ("resonance_lattice.store", "SourceStore"),
    "SourceContent": ("resonance_lattice.store", "SourceContent"),
    # Dynamic Field Algebra
    "FieldCalculus": ("resonance_lattice.calculus", "FieldCalculus"),
    "InterferenceSculptor": ("resonance_lattice.sculpting", "InterferenceSculptor"),
    "metabolise": ("resonance_lattice.metabolism", "metabolise"),
    "SubspaceField": ("resonance_lattice.metabolism", "SubspaceField"),
    "ResonanceCascade": ("resonance_lattice.cascade", "ResonanceCascade"),
    # Compiler
    "Chain": ("resonance_lattice.compiler", "Chain"),
    "Operator": ("resonance_lattice.compiler", "Operator"),
    "AutoTune": ("resonance_lattice.compiler", "AutoTune"),
    "ExpandQuery": ("resonance_lattice.compiler", "ExpandQuery"),
    "Sculpt": ("resonance_lattice.compiler", "Sculpt"),
    "SpectralFilter": ("resonance_lattice.compiler", "SpectralFilter"),
    "CrossBandCouple": ("resonance_lattice.compiler", "CrossBandCouple"),
    "Metabolise": ("resonance_lattice.compiler", "Metabolise"),
    "Cascade": ("resonance_lattice.compiler", "Cascade"),
    "precision_chain": ("resonance_lattice.compiler", "precision_chain"),
    "exploration_chain": ("resonance_lattice.compiler", "exploration_chain"),
    "focused_chain": ("resonance_lattice.compiler", "focused_chain"),
}

__all__ = [
    # Production SDK (WS1)
    "Config",
    "Lattice",
    "MaterialisedResult",
    # Internal / advanced
    "LatticeConfig",
    "EncoderConfig",
    "MaterialiserConfig",
    "Encoder",
    "PhaseSpectrum",
    "DenseField",
    "FactoredField",
    "PQField",
    "Materialiser",
    "MaterialisedContext",
    "PhaseRegistry",
    "SourceStore",
    "SourceContent",
    # Dynamic Field Algebra
    "FieldCalculus",
    "InterferenceSculptor",
    "metabolise",
    "SubspaceField",
    "ResonanceCascade",
    "Chain",
    "Operator",
    "AutoTune",
    "ExpandQuery",
    "Sculpt",
    "SpectralFilter",
    "CrossBandCouple",
    "Metabolise",
    "Cascade",
    "precision_chain",
    "exploration_chain",
    "focused_chain",
]


def __getattr__(name: str):
    if name in _LAZY_IMPORTS:
        module_path, attr = _LAZY_IMPORTS[name]
        import importlib
        mod = importlib.import_module(module_path)
        val = getattr(mod, attr)
        # Cache on the module so __getattr__ is not called again
        globals()[name] = val
        return val
    raise AttributeError(f"module 'resonance_lattice' has no attribute {name!r}")
