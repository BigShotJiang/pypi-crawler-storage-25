"""Streaming pipeline for the Resonance Lattice.

Watches a directory for file changes and auto-ingests into a lattice.
Pipeline: file watcher -> chunker -> encoder -> field superpose

Uses watchdog for cross-platform filesystem monitoring.

Usage:
    from resonance_lattice.stream import StreamPipeline
    pipeline = StreamPipeline(lattice, watch_dir="./docs")
    pipeline.start()  # Non-blocking, runs in background thread
    pipeline.stop()
"""

from __future__ import annotations

import hashlib
import logging
import threading
import time
from collections.abc import Callable
from pathlib import Path

from resonance_lattice.lattice import Lattice

logger = logging.getLogger(__name__)

# Supported file extensions for auto-ingestion
DEFAULT_EXTENSIONS = {".txt", ".md", ".rst", ".py", ".json", ".yaml", ".yml"}


def default_chunker(text: str, max_chunk_size: int = 1000) -> list[str]:
    """Split text into chunks on paragraph boundaries.

    Args:
        text: Input text.
        max_chunk_size: Maximum characters per chunk.

    Returns:
        List of non-empty chunks.
    """
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    chunks = []
    current = ""

    for para in paragraphs:
        if len(current) + len(para) + 2 > max_chunk_size and current:
            chunks.append(current)
            current = para
        else:
            current = f"{current}\n\n{para}" if current else para

    if current:
        chunks.append(current)

    return [c for c in chunks if len(c) >= 20]


class StreamPipeline:
    """File-watching streaming pipeline for continuous lattice ingestion.

    Watches a directory for new/modified files and auto-ingests them
    into the lattice. Removals are handled when files are deleted.

    Args:
        lattice: The Lattice instance to ingest into.
        watch_dir: Directory to watch for changes.
        extensions: File extensions to process.
        chunker: Custom chunking function (text -> list[str]).
        debounce_sec: Seconds to wait before processing a change (deduplication).
    """

    def __init__(
        self,
        lattice: Lattice,
        watch_dir: str | Path,
        extensions: set[str] | None = None,
        chunker: Callable[[str], list[str]] | None = None,
        debounce_sec: float = 1.0,
    ) -> None:
        self.lattice = lattice
        self.watch_dir = Path(watch_dir).resolve()
        self.extensions = extensions or DEFAULT_EXTENSIONS
        self.chunker = chunker or default_chunker
        self.debounce_sec = debounce_sec

        # Track file hashes to detect actual content changes
        self._file_hashes: dict[str, str] = {}
        # Track source_ids per file for removal on delete/update
        self._file_sources: dict[str, list[str]] = {}

        self._running = False
        self._thread: threading.Thread | None = None
        self._pending: dict[str, float] = {}  # path -> timestamp of last event
        self._lock = threading.Lock()

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def watched_files(self) -> int:
        return len(self._file_hashes)

    def start(self, initial_scan: bool = True) -> None:
        """Start the streaming pipeline in a background thread.

        Args:
            initial_scan: If True, ingest all existing files before watching.
        """
        if self._running:
            logger.warning("StreamPipeline already running")
            return

        if not self.watch_dir.exists():
            raise FileNotFoundError(f"Watch directory not found: {self.watch_dir}")

        self._running = True

        if initial_scan:
            self._scan_all()

        self._thread = threading.Thread(target=self._watch_loop, daemon=True)
        self._thread.start()
        logger.info("StreamPipeline started watching: %s", self.watch_dir)

    def stop(self) -> None:
        """Stop the streaming pipeline."""
        self._running = False
        if self._thread is not None:
            self._thread.join(timeout=5.0)
            self._thread = None
        logger.info("StreamPipeline stopped")

    def ingest_file(self, path: Path) -> int:
        """Ingest a single file into the lattice.

        Args:
            path: Path to the file.

        Returns:
            Number of chunks ingested.
        """
        path = path.resolve()
        rel = str(path.relative_to(self.watch_dir))

        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except (OSError, UnicodeDecodeError) as e:
            logger.warning("Failed to read %s: %s", path, e)
            return 0

        # Check if content actually changed
        content_hash = hashlib.md5(text.encode()).hexdigest()
        if self._file_hashes.get(rel) == content_hash:
            return 0  # No change

        # Remove old chunks for this file
        self._remove_file_sources(rel)

        # Chunk and ingest
        chunks = self.chunker(text)
        source_ids = []

        for i, chunk in enumerate(chunks):
            sid = f"{rel}:{i:04d}"
            self.lattice.add(
                source_id=sid,
                text=chunk,
                metadata={"source_file": rel, "chunk_index": i},
            )
            source_ids.append(sid)

        self._file_hashes[rel] = content_hash
        self._file_sources[rel] = source_ids

        logger.info("Ingested %s: %d chunks", rel, len(chunks))
        return len(chunks)

    def remove_file(self, path: Path) -> int:
        """Remove all chunks for a file from the lattice.

        Args:
            path: Path to the removed file.

        Returns:
            Number of chunks removed.
        """
        rel = str(path.resolve().relative_to(self.watch_dir))
        return self._remove_file_sources(rel)

    def _remove_file_sources(self, rel: str) -> int:
        """Remove all source IDs associated with a relative file path."""
        old_ids = self._file_sources.pop(rel, [])
        for sid in old_ids:
            self.lattice.remove(sid)
        self._file_hashes.pop(rel, None)
        return len(old_ids)

    def _scan_all(self) -> None:
        """Initial scan: ingest all matching files in the watch directory."""
        total_chunks = 0
        total_files = 0

        for path in sorted(self.watch_dir.rglob("*")):
            if path.is_file() and path.suffix in self.extensions:
                count = self.ingest_file(path)
                if count > 0:
                    total_files += 1
                    total_chunks += count

        logger.info(
            "Initial scan complete: %d chunks from %d files",
            total_chunks,
            total_files,
        )

    def _watch_loop(self) -> None:
        """Polling-based file watcher (no watchdog dependency required).

        Falls back to polling at 1-second intervals. For production use,
        install watchdog and the pipeline will use native OS events instead.
        """
        try:
            self._watch_with_watchdog()
        except ImportError:
            logger.info("watchdog not installed, falling back to polling")
            self._watch_with_polling()

    def _watch_with_watchdog(self) -> None:
        """Use watchdog for native filesystem events."""
        from watchdog.events import FileSystemEvent, FileSystemEventHandler
        from watchdog.observers import Observer

        pipeline = self

        class Handler(FileSystemEventHandler):
            def on_modified(self, event: FileSystemEvent) -> None:
                if not event.is_directory:
                    pipeline._enqueue(event.src_path)

            def on_created(self, event: FileSystemEvent) -> None:
                if not event.is_directory:
                    pipeline._enqueue(event.src_path)

            def on_deleted(self, event: FileSystemEvent) -> None:
                if not event.is_directory:
                    path = Path(event.src_path)
                    if path.suffix in pipeline.extensions:
                        pipeline.remove_file(path)

        observer = Observer()
        observer.schedule(Handler(), str(self.watch_dir), recursive=True)
        observer.start()

        try:
            while self._running:
                self._process_pending()
                time.sleep(self.debounce_sec)
        finally:
            observer.stop()
            observer.join()

    def _watch_with_polling(self) -> None:
        """Polling fallback when watchdog is not installed."""
        known_files: dict[str, float] = {}

        # Initial snapshot
        for path in self.watch_dir.rglob("*"):
            if path.is_file() and path.suffix in self.extensions:
                known_files[str(path)] = path.stat().st_mtime

        while self._running:
            time.sleep(self.debounce_sec)

            current_files: dict[str, float] = {}
            for path in self.watch_dir.rglob("*"):
                if path.is_file() and path.suffix in self.extensions:
                    current_files[str(path)] = path.stat().st_mtime

            # Detect new/modified
            for fpath, mtime in current_files.items():
                if fpath not in known_files or known_files[fpath] < mtime:
                    self.ingest_file(Path(fpath))

            # Detect deleted
            for fpath in set(known_files) - set(current_files):
                self.remove_file(Path(fpath))

            known_files = current_files

    def _enqueue(self, path_str: str) -> None:
        """Enqueue a file change for debounced processing."""
        path = Path(path_str)
        if path.suffix in self.extensions:
            with self._lock:
                self._pending[str(path)] = time.time()

    def _process_pending(self) -> None:
        """Process debounced pending file changes."""
        now = time.time()
        to_process = []

        with self._lock:
            for path_str, ts in list(self._pending.items()):
                if now - ts >= self.debounce_sec:
                    to_process.append(path_str)
                    del self._pending[path_str]

        for path_str in to_process:
            path = Path(path_str)
            if path.exists():
                self.ingest_file(path)
