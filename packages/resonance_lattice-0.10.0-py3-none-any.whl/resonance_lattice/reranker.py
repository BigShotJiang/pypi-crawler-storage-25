"""Cross-encoder reranker for domain-agnostic result quality.

Scores query-passage pairs using a cross-encoder transformer. Unlike the
existing keyword-overlap reranking, this generalizes across domains because
it reads the full text of both query and passage.

The model is loaded lazily on first use to avoid import-time overhead.
"""

from __future__ import annotations

import time
from dataclasses import replace
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from resonance_lattice.lattice import MaterialisedResult

DEFAULT_MODEL = "mixedbread-ai/mxbai-rerank-base-v1"


class CrossEncoderReranker:
    """Rerank retrieval results using a cross-encoder model.

    Args:
        model_name: HuggingFace model ID for the cross-encoder.
        batch_size: Number of query-passage pairs to score per forward pass.
        device: PyTorch device ("cpu", "cuda", etc.).
    """

    def __init__(
        self,
        model_name: str = DEFAULT_MODEL,
        batch_size: int = 32,
        device: str = "cpu",
    ) -> None:
        self.model_name = model_name
        self.batch_size = batch_size
        self.device = device
        self._model = None

    def _ensure_loaded(self) -> None:
        if self._model is not None:
            return
        from sentence_transformers import CrossEncoder
        self._model = CrossEncoder(self.model_name, device=self.device)

    def rerank(
        self,
        query: str,
        results: list[MaterialisedResult],
        top_k: int = 20,
        skip_margin: float = 0.15,
        blend_alpha: float = 0.7,
    ) -> tuple[list[MaterialisedResult], float]:
        """Rerank results by cross-encoder relevance score blended with retrieval.

        Blends cross-encoder scores with the prior stage's retrieval scores
        rather than replacing them entirely. This prevents cross-encoder
        errors from completely overriding a good field+keyword ordering,
        which is most valuable on out-of-domain queries.

        Args:
            query: The query text.
            results: Candidate results with content.full_text populated.
            top_k: Number of results to return.
            skip_margin: Skip reranking when the top-1 retrieval score
                exceeds top-2 by this relative margin (saves ~800ms when
                the retrieval ranking is already confident).
            blend_alpha: Weight for cross-encoder score (0-1). The prior
                stage's score gets weight (1 - blend_alpha). Default 0.7
                (cross-encoder dominant, field/keyword contributes).

        Returns:
            (reranked_results, latency_ms)
        """
        if not results:
            return results, 0.0

        t0 = time.perf_counter()

        # Selective reranking: skip when top-1 clearly dominates top-2
        if len(results) >= 2 and skip_margin > 0:
            s1, s2 = results[0].score, results[1].score
            if s2 > 0 and (s1 - s2) / s2 > skip_margin:
                latency_ms = (time.perf_counter() - t0) * 1000
                return results[:top_k], latency_ms

        self._ensure_loaded()

        # Build query-passage pairs
        pairs = []
        valid_indices = []
        for i, r in enumerate(results):
            text = ""
            if r.content:
                text = r.content.full_text or r.content.summary or ""
            if text:
                pairs.append((query, text))
                valid_indices.append(i)

        if not pairs:
            return results[:top_k], (time.perf_counter() - t0) * 1000

        # Score all pairs
        scores = self._model.predict(
            pairs, batch_size=self.batch_size, show_progress_bar=False,
        )

        # Normalize cross-encoder scores to [0,1] for blending
        ce_scores = [float(s) for s in scores]
        ce_min = min(ce_scores) if ce_scores else 0.0
        ce_max = max(ce_scores) if ce_scores else 1.0
        ce_range = ce_max - ce_min if ce_max > ce_min else 1.0

        # Blend cross-encoder with prior stage score
        reranked = []
        for idx, ce_score in zip(valid_indices, ce_scores):
            r = results[idx]
            ce_norm = (ce_score - ce_min) / ce_range
            prior_score = r.score  # Already [0,1] from _lexical_rerank
            blended = blend_alpha * ce_norm + (1.0 - blend_alpha) * prior_score
            reranked.append(replace(
                r,
                score=blended,
                raw_score=r.raw_score if r.raw_score is not None else r.score,
            ))

        # Add back results without text (keep at bottom)
        seen = set(valid_indices)
        for i, r in enumerate(results):
            if i not in seen:
                reranked.append(replace(r, score=-1e9))

        reranked.sort(key=lambda r: r.score, reverse=True)
        latency_ms = (time.perf_counter() - t0) * 1000

        return reranked[:top_k], latency_ms
