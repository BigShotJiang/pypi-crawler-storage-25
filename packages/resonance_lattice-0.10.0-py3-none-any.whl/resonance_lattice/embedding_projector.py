"""EmbeddingProjector: Map resonance vectors to LLM embedding space.

This is the core of the "soft prompt" approach. Instead of converting
resonance to text (~300 tokens), we project it directly into the LLM's
embedding space as 5 "memory tokens" (~5 tokens).

Architecture:
    resonance_vectors (B, D)  →  projector  →  memory_tokens (B, llm_dim)

    where B=5 bands, D=2048 resonance dim, llm_dim=4096 for Llama-3.1-8B

The projector is a lightweight MLP per band:
    memory_token_b = LayerNorm(W2 @ GELU(W1 @ resonance_b + bias1) + bias2)

Training (future):
    - Freeze LLM weights
    - Train only the projector MLP
    - Loss: next-token prediction on (memory_tokens + query → answer)
    - Data: (query, field, answer) triples from MS MARCO or NQ

For now: we build the architecture and measure the information content
of the resonance vectors vs raw passage embeddings to validate that
the resonance carries enough signal for the LLM to work with.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
import torch.nn as nn
from numpy.typing import NDArray

from .memory import MemoryReadout


@dataclass
class ProjectorConfig:
    """Configuration for the embedding projector."""
    resonance_dim: int = 2048       # D (resonance vector dimension per band)
    bands: int = 5                  # B (number of frequency bands)
    llm_dim: int = 4096             # Target LLM embedding dimension
    hidden_dim: int = 1024          # MLP hidden dimension
    n_memory_tokens: int = 5        # One per band (can be increased)
    dropout: float = 0.1
    layer_norm: bool = True


class BandProjector(nn.Module):
    """Project a single band's resonance vector to LLM embedding space.

    resonance_b (D,) → MLP → memory_token (llm_dim,)
    """

    def __init__(self, config: ProjectorConfig) -> None:
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(config.resonance_dim, config.hidden_dim),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(config.hidden_dim, config.llm_dim),
        )
        self.norm = nn.LayerNorm(config.llm_dim) if config.layer_norm else nn.Identity()

    def forward(self, resonance_b: torch.Tensor) -> torch.Tensor:
        """
        Args:
            resonance_b: Shape (batch, D) or (D,).
        Returns:
            memory_token: Shape (batch, llm_dim) or (llm_dim,).
        """
        return self.norm(self.mlp(resonance_b))


class EmbeddingProjector(nn.Module):
    """Map resonance vectors from all bands to LLM memory tokens.

    Input:  resonance_vectors (B, D) from MemoryReadout
    Output: memory_tokens (B, llm_dim) — one token per band

    These tokens are prepended to the LLM input as a "soft prompt":
        LLM input = [memory_token_0, ..., memory_token_4, query_tokens...]

    The LLM's self-attention naturally attends to these memory tokens,
    extracting the relevant information for generating the answer.
    """

    def __init__(self, config: ProjectorConfig | None = None) -> None:
        super().__init__()
        self.config = config or ProjectorConfig()

        # One projector per band (they see different semantic levels)
        self.band_projectors = nn.ModuleList([
            BandProjector(self.config) for _ in range(self.config.bands)
        ])

        # Optional: a fusion layer that creates additional cross-band tokens
        self.fusion = nn.Linear(
            self.config.bands * self.config.llm_dim,
            self.config.llm_dim,
        )

    def forward(self, resonance_vectors: torch.Tensor) -> torch.Tensor:
        """Project resonance vectors to LLM memory tokens.

        Args:
            resonance_vectors: Shape (B, D) or (batch, B, D).

        Returns:
            memory_tokens: Shape (B+1, llm_dim) or (batch, B+1, llm_dim).
            The extra token is the cross-band fusion token.
        """
        if resonance_vectors.dim() == 2:
            resonance_vectors = resonance_vectors.unsqueeze(0)  # (1, B, D)

        batch_size = resonance_vectors.shape[0]
        B = self.config.bands

        # Project each band independently
        band_tokens = []
        for b in range(B):
            token_b = self.band_projectors[b](resonance_vectors[:, b, :])  # (batch, llm_dim)
            band_tokens.append(token_b)

        band_stack = torch.stack(band_tokens, dim=1)  # (batch, B, llm_dim)

        # Fusion token: cross-band synthesis
        fused_input = band_stack.reshape(batch_size, -1)  # (batch, B*llm_dim)
        fusion_token = self.fusion(fused_input).unsqueeze(1)  # (batch, 1, llm_dim)

        # Concatenate: [fusion_token, band_0, ..., band_4]
        memory_tokens = torch.cat([fusion_token, band_stack], dim=1)  # (batch, B+1, llm_dim)

        return memory_tokens.squeeze(0) if batch_size == 1 else memory_tokens

    def from_readout(self, readout: MemoryReadout) -> torch.Tensor:
        """Convenience: convert a MemoryReadout to memory tokens.

        Args:
            readout: MemoryReadout from ResonanceMemory.query().

        Returns:
            memory_tokens: Shape (B+1, llm_dim) as a torch tensor.
        """
        resonance = torch.tensor(
            readout.resonance_vectors, dtype=torch.float32
        ).unsqueeze(0)  # (1, B, D)

        with torch.no_grad():
            tokens = self.forward(resonance)

        return tokens.squeeze(0)  # (B+1, llm_dim)

    @property
    def num_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters())

    @property
    def num_memory_tokens(self) -> int:
        return self.config.bands + 1  # band tokens + fusion token


def measure_information_content(
    readout: MemoryReadout,
    passage_embs: NDArray,
    passage_phases: NDArray,
    chunks: list[dict],
    top_k: int = 10,
) -> dict:
    """Measure how much retrievable information the resonance vector carries.

    Compares:
    1. Top-K passages by resonance score (field-guided)
    2. Top-K passages by E5 cosine (brute-force baseline)
    3. Overlap between the two (how much the field "knows")
    4. Diversity metrics (how different the field's choices are)

    This validates that the resonance embedding carries enough signal
    for the LLM to produce good answers without seeing full passages.
    """
    passage_embs.shape[0]

    # Field-guided top-K (from readout)
    set(readout.top_source_indices[:top_k].tolist())

    # Per-band top-1 (what each band thinks is most relevant)
    band_tops = {}
    band_names = ["domain", "topic", "relations", "entity", "verbatim"]
    B = readout.resonance_vectors.shape[0]
    for b in range(min(B, 5)):
        r_b = readout.resonance_vectors[b]
        scores = passage_phases[:, b, :] @ r_b
        top_idx = int(np.argmax(scores))
        name = band_names[b] if b < len(band_names) else f"band_{b}"
        band_tops[name] = {
            "index": top_idx,
            "title": chunks[top_idx].get("title", ""),
            "score": float(scores[top_idx]),
        }

    # Band diversity: how many UNIQUE passages across all bands?
    unique_band_indices = set(v["index"] for v in band_tops.values())
    band_diversity = len(unique_band_indices) / min(B, 5)

    # Resonance energy distribution across bands
    total_energy = float(readout.band_energies.sum())
    energy_dist = {
        band_names[b]: float(readout.band_energies[b] / total_energy)
        for b in range(min(B, 5))
    }

    # Effective dimensionality of the fused resonance vector
    fused = readout.fused
    sorted_abs = np.sort(np.abs(fused))[::-1]
    cumsum = np.cumsum(sorted_abs ** 2)
    total = cumsum[-1] + 1e-12
    k90 = int(np.searchsorted(cumsum / total, 0.90)) + 1
    eff_rank = (np.sum(np.abs(fused))) ** 2 / (np.sum(fused ** 2) + 1e-12)

    return {
        "band_tops": band_tops,
        "band_diversity": float(band_diversity),
        "energy_distribution": energy_dist,
        "fused_effective_rank": float(eff_rank),
        "fused_k90": k90,
        "fused_nonzero": int(np.count_nonzero(np.abs(fused) > 1e-6)),
    }
