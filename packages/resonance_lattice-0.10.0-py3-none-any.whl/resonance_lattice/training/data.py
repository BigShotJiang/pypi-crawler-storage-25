"""Training data pipeline for multi-scale encoder.

Prepares training batches for each frequency band:
  Omega_1: Domain classification labels
  Omega_2: Topic contrastive pairs (same section = positive)
  Omega_3: SVO relation triples
  Omega_4: Entity contrastive pairs (same entities = positive)
  Omega_5: Token reconstruction targets

Supports both HuggingFace datasets and local text files.
Spec reference: Section 9.3 (Training Data Sources).
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import torch
from torch.utils.data import Dataset

# ═══════════════════════════════════════════════════════════
# Domain taxonomy for Omega_1
# ═══════════════════════════════════════════════════════════

DEFAULT_DOMAINS = [
    "technology", "science", "medicine", "finance", "law",
    "education", "engineering", "arts", "politics", "sports",
    "environment", "business", "philosophy", "history", "mathematics",
    "linguistics", "psychology", "sociology", "biology", "physics",
]

# Simple keyword-based domain classifier (replaced by ML in production)
DOMAIN_KEYWORDS: dict[str, list[str]] = {
    "technology": ["software", "code", "api", "cloud", "data", "computer", "algorithm", "programming"],
    "science": ["research", "experiment", "hypothesis", "theory", "scientific", "discovery"],
    "medicine": ["patient", "treatment", "clinical", "disease", "medical", "health", "drug"],
    "finance": ["market", "stock", "investment", "banking", "financial", "revenue", "profit"],
    "law": ["legal", "court", "regulation", "statute", "compliance", "rights", "law"],
    "education": ["learning", "student", "curriculum", "teaching", "academic", "school"],
    "engineering": ["design", "system", "architecture", "infrastructure", "build", "engineer"],
    "biology": ["cell", "organism", "gene", "evolution", "species", "protein", "dna"],
    "physics": ["energy", "particle", "quantum", "force", "wave", "field", "relativity"],
    "mathematics": ["equation", "proof", "theorem", "algebra", "calculus", "function"],
}


def classify_domains(text: str, domains: list[str] = DEFAULT_DOMAINS) -> list[float]:
    """Simple keyword-based domain classification (bootstrap only).

    Returns a multi-hot vector of domain scores.
    """
    text_lower = text.lower()
    scores = []
    for domain in domains:
        keywords = DOMAIN_KEYWORDS.get(domain, [domain])
        count = sum(1 for kw in keywords if kw in text_lower)
        scores.append(min(1.0, count / max(1, len(keywords) * 0.3)))
    return scores


# ═══════════════════════════════════════════════════════════
# SVO extraction for Omega_3
# ═══════════════════════════════════════════════════════════

# Common verb patterns (simplified — use spaCy in production)
VERB_CLASSES = [
    "is", "has", "uses", "provides", "creates", "contains", "supports",
    "enables", "requires", "produces", "includes", "handles", "manages",
    "stores", "processes", "connects", "transforms", "generates", "defines",
    "implements", "extends", "inherits", "calls", "returns", "accepts",
    "runs", "executes", "builds", "deploys", "monitors", "optimises",
    "reduces", "increases", "improves", "replaces", "combines", "splits",
    "filters", "maps", "sorts", "validates", "encodes", "decodes",
    "compresses", "encrypts", "authenticates", "authorises", "logs", "caches",
]


def extract_svo_simple(text: str) -> list[tuple[str, str, str]]:
    """Extract simple subject-verb-object triples from text.

    This is a bootstrap heuristic. Production should use spaCy dependency parsing.
    """
    triples = []
    # Simple pattern: Noun VERB Noun
    sentences = re.split(r'[.!?]+', text)
    for sent in sentences:
        words = sent.strip().split()
        if len(words) < 3:
            continue
        for i, word in enumerate(words[1:-1], 1):
            word_lower = word.lower().rstrip("s").rstrip("e")
            for vc_idx, vc in enumerate(VERB_CLASSES):
                if word_lower == vc or word_lower == vc.rstrip("s").rstrip("e"):
                    subj = " ".join(words[max(0, i-2):i])
                    obj = " ".join(words[i+1:min(len(words), i+3)])
                    triples.append((subj.strip(), vc, obj.strip()))
                    break
    return triples


# ═══════════════════════════════════════════════════════════
# Entity extraction for Omega_4
# ═══════════════════════════════════════════════════════════

def extract_entities_simple(text: str) -> list[str]:
    """Extract named entities using capitalization heuristic.

    Production should use spaCy NER.
    """
    entities = set()
    # Find capitalized multi-word sequences (simple NER proxy)
    for match in re.finditer(r'\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b', text):
        entity = match.group(1)
        if len(entity) > 2 and entity not in {"The", "This", "That", "These", "Those", "When", "Where", "What", "How"}:
            entities.add(entity)
    return list(entities)


# ═══════════════════════════════════════════════════════════
# Training dataset
# ═══════════════════════════════════════════════════════════

@dataclass
class TrainingSample:
    """A single training sample with data for all bands."""
    text: str
    text_pair: str = ""           # Positive pair for contrastive losses
    domain_labels: list[float] = field(default_factory=list)
    svo_triples: list[tuple[str, str, str]] = field(default_factory=list)
    entities: list[str] = field(default_factory=list)
    token_ids: list[int] = field(default_factory=list)


class TextPairDataset(Dataset):
    """Dataset that produces training samples from text pairs.

    Each sample contains:
      - anchor text + positive text (same topic/entity group)
      - Domain labels (auto-classified)
      - SVO triples (auto-extracted)
      - Entities (auto-extracted)
      - Token IDs (from tokenizer)

    For the MVP, text pairs come from:
      - Adjacent paragraphs (topic pairs for Omega_2)
      - Paragraphs sharing entities (entity pairs for Omega_4)
    """

    def __init__(
        self,
        texts: list[str],
        text_pairs: list[str] | None = None,
        tokenizer: Any = None,
        max_length: int = 128,
        domains: list[str] = DEFAULT_DOMAINS,
    ) -> None:
        self.texts = texts
        self.text_pairs = text_pairs or texts  # Self-pairs as fallback
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.domains = domains

        assert len(self.texts) == len(self.text_pairs), \
            f"texts ({len(self.texts)}) and text_pairs ({len(self.text_pairs)}) must match"

    def __len__(self) -> int:
        return len(self.texts)

    def __getitem__(self, idx: int) -> dict[str, Any]:
        text = self.texts[idx]
        pair = self.text_pairs[idx]

        # Domain labels
        domain_labels = classify_domains(text, self.domains)

        # SVO triples
        triples = extract_svo_simple(text)

        # Entities
        entities = extract_entities_simple(text)

        # Token IDs
        if self.tokenizer is not None:
            enc = self.tokenizer(text, truncation=True, max_length=self.max_length,
                                 padding="max_length", return_tensors="pt")
            token_ids = enc["input_ids"].squeeze(0)
            token_mask = enc["attention_mask"].squeeze(0)
        else:
            # Fallback: character-level tokenization
            token_ids = torch.tensor([ord(c) % 256 for c in text[:self.max_length]], dtype=torch.long)
            token_mask = torch.ones(len(token_ids), dtype=torch.long)
            # Pad
            if len(token_ids) < self.max_length:
                pad_len = self.max_length - len(token_ids)
                token_ids = torch.cat([token_ids, torch.zeros(pad_len, dtype=torch.long)])
                token_mask = torch.cat([token_mask, torch.zeros(pad_len, dtype=torch.long)])

        # Verb label (first triple's verb, or 0)
        verb_label = 0
        if triples:
            verb = triples[0][1]
            if verb in VERB_CLASSES:
                verb_label = VERB_CLASSES.index(verb)

        return {
            "text": text,
            "text_pair": pair,
            "domain_labels": torch.tensor(domain_labels, dtype=torch.float32),
            "verb_label": torch.tensor(verb_label, dtype=torch.long),
            "token_ids": token_ids,
            "token_mask": token_mask,
            "has_triples": len(triples) > 0,
            "has_entities": len(entities) > 0,
        }


def create_topic_pairs_from_paragraphs(text: str) -> list[tuple[str, str]]:
    """Split text into paragraphs and create adjacent paragraph pairs.

    Adjacent paragraphs are assumed to be on the same topic.
    """
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip() and len(p.strip()) > 50]
    pairs = []
    for i in range(len(paragraphs) - 1):
        pairs.append((paragraphs[i], paragraphs[i + 1]))
    return pairs


def create_entity_pairs(texts: list[str]) -> list[tuple[str, str]]:
    """Group texts by shared entities and create pairs.

    Texts mentioning the same entity are positive pairs.
    """
    entity_to_texts: dict[str, list[int]] = {}
    for i, text in enumerate(texts):
        entities = extract_entities_simple(text)
        for ent in entities:
            entity_to_texts.setdefault(ent, []).append(i)

    pairs = []
    for ent, text_indices in entity_to_texts.items():
        if len(text_indices) >= 2:
            for i in range(len(text_indices)):
                for j in range(i + 1, min(i + 3, len(text_indices))):
                    pairs.append((texts[text_indices[i]], texts[text_indices[j]]))

    return pairs


def load_training_data(
    path: str | Path,
    max_samples: int = 10000,
) -> tuple[list[str], list[str]]:
    """Load training text pairs from a directory or file.

    Supports:
      - Directory of .txt/.md files -> paragraph pairs
      - JSONL file with "text" and "text_pair" fields
      - Single text file -> paragraph pairs

    Returns:
        (texts, text_pairs) lists of equal length.
    """
    path = Path(path)
    texts, pairs = [], []

    if path.is_dir():
        for f in sorted(path.rglob("*.txt"))[:max_samples]:
            content = f.read_text(encoding="utf-8", errors="replace")
            for a, b in create_topic_pairs_from_paragraphs(content):
                texts.append(a)
                pairs.append(b)
    elif path.suffix == ".jsonl":
        with open(path, encoding="utf-8") as f:
            for line in f:
                if len(texts) >= max_samples:
                    break
                data = json.loads(line)
                texts.append(data["text"])
                pairs.append(data.get("text_pair", data["text"]))
    else:
        content = path.read_text(encoding="utf-8", errors="replace")
        for a, b in create_topic_pairs_from_paragraphs(content):
            texts.append(a)
            pairs.append(b)

    return texts[:max_samples], pairs[:max_samples]
