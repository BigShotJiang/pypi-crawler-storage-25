"""Asymmetric key/value training losses.

Three losses that teach the key/value separation:
  1. KeyContrastiveLoss: InfoNCE on keys — keys must discriminate matching pairs
  2. ValueReconstructionLoss: cosine loss on values — values must carry source content
  3. KeyValueOrthogonalityLoss: regularizer — prevent collapse back to key ≈ value

Combined in AsymmetricMultiScaleLoss for the training loop.
"""

from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn as nn
import torch.nn.functional as F


class KeyContrastiveLoss(nn.Module):
    """InfoNCE contrastive loss on key vectors.

    Keys should produce high dot-product for matching query-passage pairs
    and low for non-matching. Uses tighter temperature (tau=0.02) than
    the symmetric TopicContrastiveLoss (tau=0.05) to force sharper
    discrimination in key-space.

    Positive pairs: paragraphs from the same section/topic.
    Negative pairs: in-batch negatives.
    """

    def __init__(self, temperature: float = 0.02) -> None:
        super().__init__()
        self.temperature = temperature

    def forward(
        self,
        anchor_keys: torch.Tensor,
        positive_keys: torch.Tensor,
    ) -> torch.Tensor:
        """InfoNCE loss with in-batch negatives on key vectors.

        Args:
            anchor_keys: (batch, D_key) — key vectors from anchor passages.
            positive_keys: (batch, D_key) — key vectors from matched passages.

        Returns:
            Scalar InfoNCE loss.
        """
        anchor_keys = F.normalize(anchor_keys, p=2, dim=-1)
        positive_keys = F.normalize(positive_keys, p=2, dim=-1)

        sim = torch.mm(anchor_keys, positive_keys.t()) / self.temperature
        labels = torch.arange(sim.size(0), device=sim.device)
        return F.cross_entropy(sim, labels)


class ValueReconstructionLoss(nn.Module):
    """Cosine embedding loss on value vectors.

    Values should carry rich, recoverable information about the source.
    The loss encourages value vectors to preserve the semantic content
    of the original backbone [CLS] embedding.

    This uses a small learned projection from value-space back to
    backbone-space, then measures cosine similarity with the target.
    """

    def __init__(self, value_dim: int, target_dim: int) -> None:
        """
        Args:
            value_dim: Dimensionality of value vectors (D_value).
            target_dim: Dimensionality of target embeddings (backbone_dim).
        """
        super().__init__()
        self.projection = nn.Linear(value_dim, target_dim, bias=False)

    def forward(
        self,
        value_vectors: torch.Tensor,
        target_embeddings: torch.Tensor,
    ) -> torch.Tensor:
        """Cosine reconstruction loss.

        Args:
            value_vectors: (batch, D_value) — value vectors for a band.
            target_embeddings: (batch, backbone_dim) — original [CLS] embeddings.

        Returns:
            Scalar loss (1 - cosine_similarity), averaged over batch.
        """
        projected = self.projection(value_vectors)
        projected = F.normalize(projected, p=2, dim=-1)
        targets = F.normalize(target_embeddings, p=2, dim=-1)
        # 1 - cosine_similarity: 0 = perfect reconstruction, 2 = anti-correlated
        return (1 - (projected * targets).sum(dim=-1)).mean()


class ValueDiversityLoss(nn.Module):
    """Penalizes value vectors being too similar to each other.

    Ensures values carry source-specific signal, not generic information.
    Without this, all value vectors could collapse to a shared direction
    (the principal component of the corpus).

    Implementation: mean pairwise cosine similarity within a batch,
    which we want to minimize toward zero.
    """

    def forward(self, value_vectors: torch.Tensor) -> torch.Tensor:
        """
        Args:
            value_vectors: (batch, D_value) — value vectors.

        Returns:
            Mean pairwise cosine similarity (to be minimized).
        """
        normed = F.normalize(value_vectors, p=2, dim=-1)
        sim = torch.mm(normed, normed.t())  # (batch, batch)
        # Zero out diagonal (self-similarity is always 1.0)
        mask = 1.0 - torch.eye(sim.size(0), device=sim.device)
        return (sim * mask).abs().sum() / (mask.sum() + 1e-8)


class KeyValueOrthogonalityLoss(nn.Module):
    """Regularizer: penalizes key and value pointing in the same direction.

    Prevents the system from collapsing back to symmetric (key ≈ value).
    Only meaningful when D_key == D_value; when they differ, the loss is
    computed on the shared minimum dimensionality.

    Implementation: mean |cosine(key, value)| pushed toward zero.
    """

    def forward(
        self,
        key_vectors: torch.Tensor,
        value_vectors: torch.Tensor,
    ) -> torch.Tensor:
        """
        Args:
            key_vectors: (batch, D_key) — key vectors.
            value_vectors: (batch, D_value) — value vectors.

        Returns:
            Mean |cosine similarity| between paired key and value vectors.
        """
        # Truncate to shared dimension if they differ
        min_dim = min(key_vectors.shape[-1], value_vectors.shape[-1])
        k = F.normalize(key_vectors[..., :min_dim], p=2, dim=-1)
        v = F.normalize(value_vectors[..., :min_dim], p=2, dim=-1)
        return (k * v).sum(dim=-1).abs().mean()


class SparsityPenalty(nn.Module):
    """L1 norm penalty on phase vectors. Reuses existing pattern."""

    def forward(self, vectors: torch.Tensor) -> torch.Tensor:
        """
        Args:
            vectors: (batch, D) or (batch, B, D) — phase vectors.

        Returns:
            Mean L1 norm.
        """
        return vectors.abs().mean()


class FLOPSRegularizer(nn.Module):
    """Per-dimension activation frequency penalty (SPLADE-style).

    L_FLOPS = sum_j (mean_i |a_ij|)^2

    Penalizes dimensions that activate frequently across the batch.
    Unlike L1 which shrinks magnitudes uniformly, FLOPS ensures no single
    dimension dominates — pushing toward genuinely sparse, spread-out
    activation patterns.

    This is the fix for the broken L1 + top-k + L2-norm loop: L1 shrinks
    magnitudes, L2 rescales them back. FLOPS operates on activation
    *frequency* across the batch, which L2 normalization cannot undo.

    Reference: Formal et al., "SPLADE: Sparse Lexical and Expansion
    Model for First Stage Ranking", SIGIR 2021.
    """

    def __init__(self, log_saturate: bool = True) -> None:
        """
        Args:
            log_saturate: If True, apply log1p to activations before computing
                frequency. Prevents large activations from dominating the loss.
        """
        super().__init__()
        self.log_saturate = log_saturate

    def forward(self, vectors: torch.Tensor) -> torch.Tensor:
        """
        Args:
            vectors: (batch, D) or (batch, B, D) — phase vectors.

        Returns:
            FLOPS regularization loss (scalar).
        """
        if vectors.dim() == 3:
            vectors = vectors.reshape(-1, vectors.shape[-1])
        activations = torch.log1p(vectors.abs()) if self.log_saturate else vectors.abs()
        # Per-dimension mean activation across batch
        dim_means = activations.mean(dim=0)  # (D,)
        # Penalize dimensions with high average activation
        return (dim_means ** 2).sum()


@dataclass
class AsymmetricLossWeights:
    """Weights for the asymmetric multi-scale loss."""
    key_contrastive: float = 1.0
    value_reconstruction: float = 0.5
    value_diversity: float = 0.3
    orthogonality: float = 0.1
    key_sparsity: float = 1.0    # Raised from 0.1 — FLOPS scale differs from L1
    value_sparsity: float = 0.1


class AsymmetricMultiScaleLoss(nn.Module):
    """Combined loss for asymmetric key/value training.

    L = w_key * L_key_contrastive
      + w_value_recon * L_value_reconstruction
      + w_value_div * L_value_diversity
      + w_ortho * L_orthogonality
      + w_key_sparse * L_key_sparsity
      + w_value_sparse * L_value_sparsity
    """

    def __init__(
        self,
        value_dim: int,
        backbone_dim: int,
        weights: AsymmetricLossWeights | None = None,
        key_temperature: float = 0.02,
    ) -> None:
        super().__init__()
        self.weights = weights or AsymmetricLossWeights()

        self.key_contrastive = KeyContrastiveLoss(temperature=key_temperature)
        self.value_reconstruction = ValueReconstructionLoss(value_dim, backbone_dim)
        self.value_diversity = ValueDiversityLoss()
        self.orthogonality = KeyValueOrthogonalityLoss()
        self.key_sparsity = FLOPSRegularizer()  # FLOPS, not L1 — fixes the topk+L1+L2 no-op
        self.value_sparsity = SparsityPenalty()  # Values keep L1 — they need richness

    def forward(
        self,
        anchor_keys: torch.Tensor,
        positive_keys: torch.Tensor,
        anchor_values: torch.Tensor,
        target_embeddings: torch.Tensor,
        key_vectors_all: torch.Tensor | None = None,
        value_vectors_all: torch.Tensor | None = None,
    ) -> dict[str, torch.Tensor]:
        """Compute all loss components.

        Args:
            anchor_keys: (batch, D_key) — key vectors for anchor passages.
            positive_keys: (batch, D_key) — key vectors for positive passages.
            anchor_values: (batch, D_value) — value vectors for anchor passages.
            target_embeddings: (batch, backbone_dim) — original [CLS] embeddings.
            key_vectors_all: (batch, B, D_key) — all-band keys for sparsity (optional).
            value_vectors_all: (batch, B, D_value) — all-band values for sparsity (optional).

        Returns:
            Dict with 'total' and per-component losses.
        """
        w = self.weights
        losses = {}

        # Key discrimination
        losses["key_contrastive"] = self.key_contrastive(anchor_keys, positive_keys)

        # Value reconstruction
        losses["value_reconstruction"] = self.value_reconstruction(
            anchor_values, target_embeddings
        )

        # Value diversity
        losses["value_diversity"] = self.value_diversity(anchor_values)

        # Key/value orthogonality
        losses["orthogonality"] = self.orthogonality(anchor_keys, anchor_values)

        # Sparsity penalties
        if key_vectors_all is not None:
            losses["key_sparsity"] = self.key_sparsity(key_vectors_all)
        else:
            losses["key_sparsity"] = self.key_sparsity(anchor_keys)

        if value_vectors_all is not None:
            losses["value_sparsity"] = self.value_sparsity(value_vectors_all)
        else:
            losses["value_sparsity"] = self.value_sparsity(anchor_values)

        # Weighted total
        losses["total"] = (
            w.key_contrastive * losses["key_contrastive"]
            + w.value_reconstruction * losses["value_reconstruction"]
            + w.value_diversity * losses["value_diversity"]
            + w.orthogonality * losses["orthogonality"]
            + w.key_sparsity * losses["key_sparsity"]
            + w.value_sparsity * losses["value_sparsity"]
        )

        return losses
