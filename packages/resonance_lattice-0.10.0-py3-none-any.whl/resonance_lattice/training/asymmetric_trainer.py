"""Asymmetric key/value encoder trainer.

Extends the EncoderTrainer to manage two sets of projection heads:
  - key_heads (the encoder's existing `heads`) — trained for matching discrimination
  - value_heads (new) — trained for evidence reconstruction

The backbone is frozen; only key heads, value heads, and loss parameters are updated.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch.utils.data import DataLoader

from resonance_lattice.config import DEFAULT_SPARSITY_TARGETS
from resonance_lattice.encoder import Encoder, ProjectionHead
from resonance_lattice.training.asymmetric_losses import (
    AsymmetricLossWeights,
    AsymmetricMultiScaleLoss,
)
from resonance_lattice.training.trainer import TrainingConfig, TrainingMetrics


@dataclass
class AsymmetricTrainingConfig(TrainingConfig):
    """Configuration for asymmetric key/value training."""
    dim_key: int = 256
    dim_value: int = 512
    loss_weights_kv: AsymmetricLossWeights = field(default_factory=AsymmetricLossWeights)
    key_temperature: float = 0.02
    key_sparsify_mode: str = "threshold"  # "threshold" for FLOPS-driven variable sparsity
    sparsity_warmup_frac: float = 0.3     # Ramp key_sparsity weight over first 30% of training


class AsymmetricEncoderTrainer:
    """Trains separate key and value projection heads on a frozen backbone.

    Key heads are trained with contrastive loss (sharper discrimination).
    Value heads are trained with reconstruction + diversity loss (richer evidence).
    An orthogonality regularizer prevents collapse back to key ≈ value.
    """

    def __init__(
        self,
        config: AsymmetricTrainingConfig,
        encoder: Encoder | None = None,
    ) -> None:
        self.config = config
        self.device = torch.device(config.device)
        self.global_step = 0
        self.best_recall = 0.0
        self.history: list[TrainingMetrics] = []

        # Create output directory
        self.output_dir = Path(config.output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.log_path = self.output_dir / config.log_file

        # Create or use provided encoder
        if encoder is not None:
            self.encoder = encoder
        else:
            if config.backbone == "random":
                self.encoder = Encoder.random(
                    bands=config.bands,
                    dim=config.dim_key,  # Key heads use dim_key
                    input_dim=768,
                )
            else:
                self.encoder = Encoder.from_backbone(
                    model_name=config.backbone,
                    bands=config.bands,
                    dim=config.dim_key,
                    device=config.device,
                )

        # Rebuild key heads with dim_key and threshold sparsification
        # Threshold mode produces variable sparsity — the learned theta
        # parameter rises as FLOPS loss penalizes activation frequency,
        # naturally eliminating dimensions. Hard top-k can't do this.
        backbone_dim = self.encoder._backbone_dim
        key_sparsify = getattr(config, 'key_sparsify_mode', 'threshold')
        self.encoder.heads = torch.nn.ModuleList([
            ProjectionHead(
                input_dim=backbone_dim,
                output_dim=config.dim_key,
                sparsity=self.encoder.config.get_sparsity(b),
                sparsify_mode=key_sparsify,
            )
            for b in range(config.bands)
        ])

        # Create value heads with dim_value
        self.encoder.init_value_heads(dim_value=config.dim_value)

        self.encoder.to(self.device)

        # Create asymmetric loss
        self.criterion = AsymmetricMultiScaleLoss(
            value_dim=config.dim_value,
            backbone_dim=backbone_dim,
            weights=config.loss_weights_kv,
            key_temperature=config.key_temperature,
        ).to(self.device)

        # Optimizer — train key heads, value heads, and loss parameters
        trainable_params = (
            list(self.encoder.heads.parameters())
            + list(self.encoder.value_heads.parameters())
            + list(self.criterion.parameters())
        )
        self.optimizer = torch.optim.AdamW(
            trainable_params,
            lr=config.learning_rate,
            weight_decay=config.weight_decay,
        )

        # Learning rate scheduler
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer,
            T_max=config.epochs * 1000,
        )

        # Sparsity warmup state
        self._base_key_sparsity_weight = config.loss_weights_kv.key_sparsity
        self._warmup_steps = int(config.sparsity_warmup_frac * config.epochs * 1000)

    def _get_key_sparsity_weight(self) -> float:
        """Ramp key sparsity weight from 10% to full over warmup period."""
        if self._warmup_steps <= 0:
            return self._base_key_sparsity_weight
        progress = min(self.global_step / self._warmup_steps, 1.0)
        # Ramp from 10% to 100% of base weight
        return self._base_key_sparsity_weight * (0.1 + 0.9 * progress)

    def train_step(self, batch: dict[str, torch.Tensor]) -> TrainingMetrics:
        """Single training step for asymmetric key/value heads.

        Args:
            batch: Training batch. Must have 'embeddings' (backbone output)
                or raw text that gets hash-embedded. Optionally 'pair_embeddings'
                for contrastive pairs.

        Returns:
            TrainingMetrics with per-component loss breakdown.
        """
        self.encoder.train()
        self.criterion.train()

        batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v
                 for k, v in batch.items()}

        # Get backbone embeddings — encode text through backbone if available
        if "embeddings" in batch:
            embeddings = batch["embeddings"]
        elif "text" in batch and self.encoder.has_backbone:
            texts = batch["text"]
            if isinstance(texts, (list, tuple)):
                embeddings = self.encoder._get_backbone_embedding(list(texts))
            else:
                embeddings = self.encoder._get_backbone_embedding([texts])
        else:
            batch_size = batch.get("domain_labels", torch.zeros(8)).size(0)
            embeddings = torch.randn(
                batch_size, self.encoder._backbone_dim, device=self.device,
            )

        # Project through key heads
        key_outputs = []
        for head in self.encoder.heads:
            key_outputs.append(head(embeddings))
        keys_all = torch.stack(key_outputs, dim=1)  # (batch, B, D_key)

        # Project through value heads
        val_outputs = []
        for head in self.encoder.value_heads:
            val_outputs.append(head(embeddings))
        vals_all = torch.stack(val_outputs, dim=1)  # (batch, B, D_value)

        # Create positive key pairs — encode the PAIR text through backbone
        # so contrastive loss sees genuinely different but related texts
        if "pair_embeddings" in batch:
            pair_emb = batch["pair_embeddings"]
        elif "text_pair" in batch and self.encoder.has_backbone:
            pair_texts = batch["text_pair"]
            if isinstance(pair_texts, (list, tuple)):
                pair_emb = self.encoder._get_backbone_embedding(list(pair_texts))
            else:
                pair_emb = self.encoder._get_backbone_embedding([pair_texts])
        else:
            # Synthesize pairs by adding noise (fallback for random backbone)
            pair_emb = embeddings + torch.randn_like(embeddings) * 0.1

        positive_keys = []
        for head in self.encoder.heads:
            positive_keys.append(head(pair_emb))
        pos_keys_all = torch.stack(positive_keys, dim=1)  # (batch, B, D_key)

        # Pick the primary band for loss computation
        # Use band 0 (or first active band) for the scalar losses
        primary_band = 0
        anchor_keys = keys_all[:, primary_band, :]    # (batch, D_key)
        pos_keys = pos_keys_all[:, primary_band, :]    # (batch, D_key)
        anchor_vals = vals_all[:, primary_band, :]     # (batch, D_value)

        # Apply sparsity warmup — ramp key_sparsity weight over early training
        current_kw = self._get_key_sparsity_weight()
        self.criterion.weights.key_sparsity = current_kw

        # Compute asymmetric losses
        losses = self.criterion(
            anchor_keys=anchor_keys,
            positive_keys=pos_keys,
            anchor_values=anchor_vals,
            target_embeddings=embeddings,  # Reconstruct backbone embedding
            key_vectors_all=keys_all,
            value_vectors_all=vals_all,
        )

        # Backward
        self.optimizer.zero_grad()
        losses["total"].backward()

        # Gradient clipping
        all_params = (
            list(self.encoder.heads.parameters())
            + list(self.encoder.value_heads.parameters())
            + list(self.criterion.parameters())
        )
        torch.nn.utils.clip_grad_norm_(all_params, self.config.grad_clip)

        self.optimizer.step()
        self.scheduler.step()
        self.global_step += 1

        # Sparsity metrics
        with torch.no_grad():
            key_sparsity = {}
            val_sparsity = {}
            for b in range(keys_all.size(1)):
                key_sparsity[b] = (keys_all[:, b, :].abs() > 1e-6).float().mean().item()
                val_sparsity[b] = (vals_all[:, b, :].abs() > 1e-6).float().mean().item()

        metrics = TrainingMetrics(
            step=self.global_step,
            loss_total=losses["total"].item(),
            loss_components={k: v.item() for k, v in losses.items() if k != "total"},
            sparsity_per_band={f"key_{k}": v for k, v in key_sparsity.items()},
            learning_rate=self.optimizer.param_groups[0]["lr"],
            timestamp=time.time(),
        )
        # Add value sparsity to the per-band dict
        metrics.sparsity_per_band.update({f"val_{k}": v for k, v in val_sparsity.items()})

        return metrics

    def evaluate(
        self,
        eval_dataloader: DataLoader,
        num_sources: int = 500,
    ) -> TrainingMetrics:
        """Evaluate asymmetric encoder on retrieval quality.

        Builds an AsymmetricDenseField, encodes sources, and measures
        recall@100 using key-space matching.
        """
        from resonance_lattice.field.asymmetric_dense import AsymmetricDenseField

        self.encoder.eval()
        field = AsymmetricDenseField(
            bands=self.config.bands,
            dim_key=self.config.dim_key,
            dim_value=self.config.dim_value,
        )

        all_keys = []
        all_values = []
        with torch.no_grad():
            for batch in eval_dataloader:
                if len(all_keys) >= num_sources:
                    break

                if "embeddings" in batch:
                    embeddings = batch["embeddings"].to(self.device)
                else:
                    batch_size = batch["domain_labels"].size(0)
                    embeddings = torch.randn(
                        batch_size, self.encoder._backbone_dim, device=self.device,
                    )

                # Key projection
                key_vecs = []
                for head in self.encoder.heads:
                    key_vecs.append(head(embeddings))
                keys = torch.stack(key_vecs, dim=1).cpu().numpy()

                # Value projection
                val_vecs = []
                for head in self.encoder.value_heads:
                    val_vecs.append(head(embeddings))
                values = torch.stack(val_vecs, dim=1).cpu().numpy()

                for i in range(keys.shape[0]):
                    if len(all_keys) >= num_sources:
                        break
                    all_keys.append(keys[i])
                    all_values.append(values[i])
                    field.superpose(keys[i], values[i], salience=1.0)

        all_keys = np.array(all_keys)

        # Recall@100: noisy key query → check if original source in top-100
        # Score using key-space dot products (not value-space resonance)
        rng = np.random.default_rng(42)
        hits = 0
        num_queries = min(100, len(all_keys))
        total_latency = 0.0

        for q in range(num_queries):
            target_idx = rng.integers(0, len(all_keys))
            noise = rng.standard_normal(all_keys[target_idx].shape).astype(np.float32) * 0.1
            query_key = all_keys[target_idx] + noise

            t0 = time.perf_counter()
            # Score via direct key-space dot product (bypasses field resonance)
            query_fused = query_key.mean(axis=0)  # (D_key,)
            scores = np.array([
                np.dot(query_fused, all_keys[i].mean(axis=0))
                for i in range(len(all_keys))
            ])
            total_latency += time.perf_counter() - t0

            top_k = np.argsort(scores)[-100:]
            if target_idx in top_k:
                hits += 1

        recall = hits / num_queries if num_queries > 0 else 0.0
        avg_latency = (total_latency / max(num_queries, 1)) * 1000

        return TrainingMetrics(
            step=self.global_step,
            recall_at_100=recall,
            latency_ms=avg_latency,
            timestamp=time.time(),
        )

    def train(
        self,
        train_dataloader: DataLoader,
        eval_dataloader: DataLoader | None = None,
        epochs: int | None = None,
    ) -> list[TrainingMetrics]:
        """Full training loop for asymmetric key/value heads."""
        epochs = epochs or self.config.epochs
        all_metrics = []

        print(f"Asymmetric training: {epochs} epochs, D_key={self.config.dim_key}, "
              f"D_value={self.config.dim_value}")
        print(f"Bands: {self.config.bands}, Device: {self.device}")

        for epoch in range(epochs):
            epoch_losses = []

            for batch_idx, batch in enumerate(train_dataloader):
                metrics = self.train_step(batch)
                metrics.epoch = epoch
                epoch_losses.append(metrics.loss_total)
                all_metrics.append(metrics)

                if self.global_step % 10 == 0:
                    avg_loss = np.mean(epoch_losses[-10:])
                    components = " | ".join(
                        f"{k}:{v:.3f}" for k, v in sorted(metrics.loss_components.items())
                    )
                    print(f"  step {self.global_step:5d} | loss {avg_loss:.4f} | {components}")

                if eval_dataloader and self.global_step % self.config.eval_every == 0:
                    eval_metrics = self.evaluate(eval_dataloader)
                    eval_metrics.epoch = epoch
                    all_metrics.append(eval_metrics)

                    improved = eval_metrics.recall_at_100 > self.best_recall
                    if improved:
                        self.best_recall = eval_metrics.recall_at_100
                        self.save_checkpoint("best")

                    marker = " *** NEW BEST ***" if improved else ""
                    print(f"  EVAL step {self.global_step}: recall@100={eval_metrics.recall_at_100:.3f}, "
                          f"latency={eval_metrics.latency_ms:.2f}ms{marker}")

                if self.global_step % self.config.save_every == 0:
                    self.save_checkpoint(f"step_{self.global_step}")

                self._log_metrics(metrics)

            avg_epoch_loss = np.mean(epoch_losses) if epoch_losses else 0.0
            print(f"Epoch {epoch+1}/{epochs} complete. Avg loss: {avg_epoch_loss:.4f}")

        if eval_dataloader:
            final_eval = self.evaluate(eval_dataloader)
            print(f"\nFinal recall@100: {final_eval.recall_at_100:.3f}")
            all_metrics.append(final_eval)

        self.save_checkpoint("final")
        self.history = all_metrics
        return all_metrics

    def save_checkpoint(self, name: str) -> Path:
        """Save both key and value head weights."""
        ckpt_dir = self.output_dir / name
        ckpt_dir.mkdir(parents=True, exist_ok=True)

        key_sparsities = [head.sparsity for head in self.encoder.heads]
        val_sparsities = [head.sparsity for head in self.encoder.value_heads]

        torch.save({
            "key_heads_state_dict": self.encoder.heads.state_dict(),
            "value_heads_state_dict": self.encoder.value_heads.state_dict(),
            "criterion_state_dict": self.criterion.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "global_step": self.global_step,
            "best_recall": self.best_recall,
            "config": {
                "bands": self.config.bands,
                "dim_key": self.config.dim_key,
                "dim_value": self.config.dim_value,
                "backbone": self.encoder.config.backbone,
                "backbone_dim": self.encoder._backbone_dim,
                "key_sparsities": key_sparsities,
                "value_sparsities": val_sparsities,
                "key_temperature": self.config.key_temperature,
                "query_prefix": self.encoder.config.query_prefix,
                "passage_prefix": self.encoder.config.passage_prefix,
                "pooling": self.encoder.config.pooling,
            },
        }, ckpt_dir / "checkpoint.pt")

        return ckpt_dir

    def load_checkpoint(self, path: str | Path) -> None:
        """Load both key and value head weights from checkpoint."""
        path = Path(path)
        ckpt = torch.load(path / "checkpoint.pt", map_location=self.device, weights_only=False)
        self.encoder.heads.load_state_dict(ckpt["key_heads_state_dict"])
        self.encoder.value_heads.load_state_dict(ckpt["value_heads_state_dict"])
        self.criterion.load_state_dict(ckpt["criterion_state_dict"])
        self.optimizer.load_state_dict(ckpt["optimizer_state_dict"])
        self.global_step = ckpt["global_step"]
        self.best_recall = ckpt["best_recall"]

    def _log_metrics(self, metrics: TrainingMetrics) -> None:
        """Append metrics to JSONL log file."""
        with open(self.log_path, "a") as f:
            f.write(json.dumps(metrics.to_dict()) + "\n")
