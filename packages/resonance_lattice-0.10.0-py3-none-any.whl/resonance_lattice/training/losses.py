"""Loss functions for multi-scale encoder training.

Each frequency band has its own loss function that pulls it toward a
different attractor in representation space:

  L_total = lambda_1*L_Omega1 + lambda_2*L_Omega2 + lambda_3*L_Omega3
          + lambda_4*L_Omega4 + lambda_5*L_Omega5 + lambda_s*L_sparse

Spec reference: Section 9.2 (Training Objectives).
"""

from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn as nn
import torch.nn.functional as F


class DomainClassificationLoss(nn.Module):
    """L_Omega1: Multi-label domain classification.

    Training signal: document-level domain labels.
    Loss: Binary cross-entropy per label.
    """

    def __init__(self, phase_dim: int, num_domains: int) -> None:
        super().__init__()
        self.classifier = nn.Linear(phase_dim, num_domains)

    def forward(
        self,
        phase_vectors: torch.Tensor,
        domain_labels: torch.Tensor,
    ) -> torch.Tensor:
        """
        Args:
            phase_vectors: (batch, D) — Omega_1 phase vectors.
            domain_labels: (batch, num_domains) — binary multi-label targets.

        Returns:
            Scalar loss.
        """
        logits = self.classifier(phase_vectors)
        return F.binary_cross_entropy_with_logits(logits, domain_labels.float())


class TopicContrastiveLoss(nn.Module):
    """L_Omega2: InfoNCE contrastive loss at paragraph/topic granularity.

    Positive pairs: paragraphs from the same section/topic.
    Negative pairs: in-batch negatives from different topics.
    Temperature: tau = 0.05 (from spec).
    """

    def __init__(self, temperature: float = 0.05) -> None:
        super().__init__()
        self.temperature = temperature

    def forward(
        self,
        anchors: torch.Tensor,
        positives: torch.Tensor,
    ) -> torch.Tensor:
        """InfoNCE loss with in-batch negatives.

        Args:
            anchors: (batch, D) — anchor phase vectors.
            positives: (batch, D) — positive phase vectors (same topic).

        Returns:
            Scalar InfoNCE loss.
        """
        # L2 normalise
        anchors = F.normalize(anchors, p=2, dim=-1)
        positives = F.normalize(positives, p=2, dim=-1)

        # Similarity matrix: (batch, batch)
        sim = torch.mm(anchors, positives.t()) / self.temperature

        # Positive pairs are on the diagonal
        labels = torch.arange(sim.size(0), device=sim.device)
        return F.cross_entropy(sim, labels)


class RelationPredictionLoss(nn.Module):
    """L_Omega3: Structural relation prediction.

    Given text, predict SVO triples extracted by dependency parser.
    Architecture: phi_Omega3 -> MLP -> (subject_emb, verb_class, object_emb)
    Loss: cross-entropy on verb class + cosine loss on entity embeddings.
    """

    def __init__(
        self,
        phase_dim: int,
        entity_dim: int = 128,
        num_verb_classes: int = 50,
    ) -> None:
        super().__init__()
        self.subject_head = nn.Sequential(
            nn.Linear(phase_dim, phase_dim // 2),
            nn.ReLU(),
            nn.Linear(phase_dim // 2, entity_dim),
        )
        self.object_head = nn.Sequential(
            nn.Linear(phase_dim, phase_dim // 2),
            nn.ReLU(),
            nn.Linear(phase_dim // 2, entity_dim),
        )
        self.verb_classifier = nn.Sequential(
            nn.Linear(phase_dim, phase_dim // 2),
            nn.ReLU(),
            nn.Linear(phase_dim // 2, num_verb_classes),
        )
        self.entity_dim = entity_dim

    def forward(
        self,
        phase_vectors: torch.Tensor,
        subject_targets: torch.Tensor,
        verb_labels: torch.Tensor,
        object_targets: torch.Tensor,
    ) -> torch.Tensor:
        """
        Args:
            phase_vectors: (batch, D) — Omega_3 phase vectors.
            subject_targets: (batch, entity_dim) — target subject embeddings.
            verb_labels: (batch,) — verb class indices.
            object_targets: (batch, entity_dim) — target object embeddings.

        Returns:
            Scalar loss (verb_ce + subject_cosine + object_cosine).
        """
        subj_pred = self.subject_head(phase_vectors)
        obj_pred = self.object_head(phase_vectors)
        verb_logits = self.verb_classifier(phase_vectors)

        verb_loss = F.cross_entropy(verb_logits, verb_labels)
        subj_loss = 1.0 - F.cosine_similarity(subj_pred, subject_targets).mean()
        obj_loss = 1.0 - F.cosine_similarity(obj_pred, object_targets).mean()

        return verb_loss + subj_loss + obj_loss


class EntityContrastiveLoss(nn.Module):
    """L_Omega4: InfoNCE contrastive loss at entity level.

    Positive pairs: passages mentioning the same named entities.
    Negative pairs: passages with different entities.
    Temperature: tau = 0.02 (tighter clusters than Omega_2).
    """

    def __init__(self, temperature: float = 0.02) -> None:
        super().__init__()
        self.temperature = temperature

    def forward(
        self,
        anchors: torch.Tensor,
        positives: torch.Tensor,
    ) -> torch.Tensor:
        """InfoNCE with tighter temperature for entity-level clustering.

        Args:
            anchors: (batch, D) — anchor entity phase vectors.
            positives: (batch, D) — positive entity phase vectors.

        Returns:
            Scalar InfoNCE loss.
        """
        anchors = F.normalize(anchors, p=2, dim=-1)
        positives = F.normalize(positives, p=2, dim=-1)

        sim = torch.mm(anchors, positives.t()) / self.temperature
        labels = torch.arange(sim.size(0), device=sim.device)
        return F.cross_entropy(sim, labels)


class TokenReconstructionLoss(nn.Module):
    """L_Omega5: Token reconstruction / autoencoding.

    phi_Omega5 -> small transformer decoder -> reconstruct original tokens.
    Loss: cross-entropy on token prediction.
    Makes Omega_5 an autoencoding channel for verbatim content.
    """

    def __init__(
        self,
        phase_dim: int,
        vocab_size: int = 32000,
        max_seq_len: int = 128,
        decoder_dim: int = 256,
        decoder_layers: int = 2,
        decoder_heads: int = 4,
    ) -> None:
        super().__init__()
        self.max_seq_len = max_seq_len
        self.vocab_size = vocab_size

        # Project phase vector to sequence of decoder inputs
        self.phase_to_seq = nn.Linear(phase_dim, max_seq_len * decoder_dim)

        # Small transformer decoder
        decoder_layer = nn.TransformerDecoderLayer(
            d_model=decoder_dim,
            nhead=decoder_heads,
            dim_feedforward=decoder_dim * 4,
            batch_first=True,
        )
        self.decoder = nn.TransformerDecoder(decoder_layer, num_layers=decoder_layers)

        # Output projection to vocabulary
        self.output_proj = nn.Linear(decoder_dim, vocab_size)
        self.decoder_dim = decoder_dim

    def forward(
        self,
        phase_vectors: torch.Tensor,
        token_ids: torch.Tensor,
        token_mask: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """
        Args:
            phase_vectors: (batch, D) — Omega_5 phase vectors.
            token_ids: (batch, seq_len) — target token IDs.
            token_mask: (batch, seq_len) — 1 for real tokens, 0 for padding.

        Returns:
            Scalar cross-entropy loss over token predictions.
        """
        batch = phase_vectors.size(0)
        seq_len = min(token_ids.size(1), self.max_seq_len)

        # Phase vector -> decoder memory
        memory = self.phase_to_seq(phase_vectors)
        memory = memory.view(batch, self.max_seq_len, self.decoder_dim)

        # Create causal mask for autoregressive decoding
        tgt = memory[:, :seq_len, :]  # Use as both memory and target
        causal_mask = nn.Transformer.generate_square_subsequent_mask(seq_len, device=phase_vectors.device)

        # Decode
        decoded = self.decoder(tgt, memory, tgt_mask=causal_mask)
        logits = self.output_proj(decoded)  # (batch, seq_len, vocab_size)

        # Flatten for cross-entropy
        logits_flat = logits.reshape(-1, self.vocab_size)
        targets_flat = token_ids[:, :seq_len].reshape(-1)

        if token_mask is not None:
            mask_flat = token_mask[:, :seq_len].reshape(-1).bool()
            logits_flat = logits_flat[mask_flat]
            targets_flat = targets_flat[mask_flat]

        return F.cross_entropy(logits_flat, targets_flat)


class SparsityPenalty(nn.Module):
    """L_sparse: L1 norm penalty on all phase vectors.

    Encourages sparse activations to maximise field capacity.
    L_sparse = sum_b ||phi_b||_1
    """

    def forward(self, phase_vectors: torch.Tensor) -> torch.Tensor:
        """
        Args:
            phase_vectors: (batch, B, D) — all band phase vectors.

        Returns:
            Mean L1 norm across batch and bands.
        """
        return phase_vectors.abs().mean()


class FLOPSRegularizer(nn.Module):
    """Per-dimension activation frequency penalty (SPLADE-style).

    L_FLOPS = sum_j (mean_i |a_ij|)^2

    Penalizes dimensions that activate frequently across the batch.
    Unlike L1 which shrinks magnitudes uniformly, FLOPS ensures no single
    dimension dominates — pushing toward genuinely sparse, spread-out
    activation patterns.

    Fixes the broken L1 + top-k + L2-norm loop: L1 shrinks magnitudes,
    L2 rescales them back. FLOPS operates on activation *frequency*
    across the batch, which L2 normalization cannot undo.
    """

    def __init__(self, log_saturate: bool = True) -> None:
        super().__init__()
        self.log_saturate = log_saturate

    def forward(self, phase_vectors: torch.Tensor) -> torch.Tensor:
        """
        Args:
            phase_vectors: (batch, B, D) or (batch, D) — phase vectors.

        Returns:
            FLOPS regularization loss (scalar).
        """
        if phase_vectors.dim() == 3:
            phase_vectors = phase_vectors.reshape(-1, phase_vectors.shape[-1])
        activations = torch.log1p(phase_vectors.abs()) if self.log_saturate else phase_vectors.abs()
        dim_means = activations.mean(dim=0)
        return (dim_means ** 2).sum()


@dataclass
class LossWeights:
    """Lambda weights for multi-task training."""
    domain: float = 1.0       # lambda_1
    topic: float = 1.0        # lambda_2
    relation: float = 0.5     # lambda_3
    entity: float = 1.0       # lambda_4
    reconstruction: float = 0.3  # lambda_5
    sparsity: float = 0.1     # lambda_s


class MultiScaleLoss(nn.Module):
    """Combined multi-task loss for all frequency bands.

    L_total = lambda_1*L_Omega1 + lambda_2*L_Omega2 + lambda_3*L_Omega3
            + lambda_4*L_Omega4 + lambda_5*L_Omega5 + lambda_s*L_sparse
    """

    def __init__(
        self,
        phase_dim: int,
        num_domains: int = 20,
        num_verb_classes: int = 50,
        vocab_size: int = 32000,
        weights: LossWeights | None = None,
        active_bands: list[int] | None = None,
        sparsity_mode: str = "l1",
    ) -> None:
        """
        Args:
            phase_dim: D — dimensionality of phase vectors.
            num_domains: Number of domain classification labels.
            num_verb_classes: Number of verb classes for relation prediction.
            vocab_size: Vocabulary size for token reconstruction.
            weights: Loss component weights.
            active_bands: Which bands to train (0-indexed). None = all 5.
            sparsity_mode: "l1" (original) or "flops" (SPLADE-style frequency penalty).
        """
        super().__init__()
        self.weights = weights or LossWeights()
        self.active_bands = active_bands or list(range(5))

        # Only create loss modules for active bands
        if 0 in self.active_bands:
            self.domain_loss = DomainClassificationLoss(phase_dim, num_domains)
        if 1 in self.active_bands:
            self.topic_loss = TopicContrastiveLoss(temperature=0.05)
        if 2 in self.active_bands:
            self.relation_loss = RelationPredictionLoss(phase_dim, num_verb_classes=num_verb_classes)
        if 3 in self.active_bands:
            self.entity_loss = EntityContrastiveLoss(temperature=0.02)
        if 4 in self.active_bands:
            self.reconstruction_loss = TokenReconstructionLoss(phase_dim, vocab_size=vocab_size)

        if sparsity_mode == "flops":
            self.sparsity_penalty = FLOPSRegularizer()
        else:
            self.sparsity_penalty = SparsityPenalty()

    def forward(self, batch: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
        """Compute all active losses.

        Args:
            batch: Dict with keys matching each loss function's requirements.
                Required: "phase_vectors" (batch, B, D) — all band outputs.
                Optional per band:
                  Band 0: "domain_labels" (batch, num_domains)
                  Band 1: "topic_anchors", "topic_positives" (batch, D)
                  Band 2: "subject_targets", "verb_labels", "object_targets"
                  Band 3: "entity_anchors", "entity_positives" (batch, D)
                  Band 4: "token_ids", "token_mask"

        Returns:
            Dict with "total", per-band losses, and "sparsity".
        """
        losses = {}
        total = torch.tensor(0.0, device=batch["phase_vectors"].device)
        phase = batch["phase_vectors"]  # (batch, B, D)

        if 0 in self.active_bands and "domain_labels" in batch:
            l = self.domain_loss(phase[:, 0, :], batch["domain_labels"])
            losses["domain"] = l
            total = total + self.weights.domain * l

        if 1 in self.active_bands and "topic_positives" in batch:
            l = self.topic_loss(phase[:, 1, :], batch["topic_positives"])
            losses["topic"] = l
            total = total + self.weights.topic * l

        if 2 in self.active_bands and "verb_labels" in batch:
            l = self.relation_loss(
                phase[:, 2, :],
                batch["subject_targets"],
                batch["verb_labels"],
                batch["object_targets"],
            )
            losses["relation"] = l
            total = total + self.weights.relation * l

        if 3 in self.active_bands and "entity_positives" in batch:
            l = self.entity_loss(phase[:, 3, :], batch["entity_positives"])
            losses["entity"] = l
            total = total + self.weights.entity * l

        if 4 in self.active_bands and "token_ids" in batch:
            l = self.reconstruction_loss(
                phase[:, 4, :],
                batch["token_ids"],
                batch.get("token_mask"),
            )
            losses["reconstruction"] = l
            total = total + self.weights.reconstruction * l

        # Sparsity penalty across all bands
        l_sparse = self.sparsity_penalty(phase)
        losses["sparsity"] = l_sparse
        total = total + self.weights.sparsity * l_sparse

        losses["total"] = total
        return losses
