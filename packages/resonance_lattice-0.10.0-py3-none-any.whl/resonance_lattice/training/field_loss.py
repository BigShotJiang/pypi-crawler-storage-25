"""Field-aware training losses.

Teaches projection heads to produce phase vectors that survive superposition
in the outer-product field. The key insight: during training, build a mini-field
from the batch and penalize cross-source interference.
"""

from __future__ import annotations

import torch
import torch.nn as nn


class FieldInterferenceLoss(nn.Module):
    """Penalizes cross-source interference in a mini-field built from the batch.

    For a batch of N phase vectors {phi_i} (single band):
      1. Build mini-field: F = X^T @ X  (sum of outer products)
      2. Resonance per source: r_i = F @ phi_i
      3. Self-signal: ||phi_i||^2 * phi_i  (each source's own contribution)
      4. Interference: r_i - self_signal
      5. Loss = mean(||interference||^2 / ||self_signal||^2)

    This teaches heads to produce phases whose outer products
    don't constructively interfere with each other.
    """

    def forward(self, phase_vectors: torch.Tensor) -> torch.Tensor:
        """Compute interference loss for a single band.

        Args:
            phase_vectors: (N, D) -- phase vectors for one band.

        Returns:
            Scalar signal-to-interference ratio loss (lower = less interference).
        """
        N, D = phase_vectors.shape

        # Build mini-field: F = sum_i (phi_i outer phi_i) = X^T @ X
        F = phase_vectors.T @ phase_vectors  # (D, D)

        # Resonance for each source: r_i = F @ phi_i
        # Batch shortcut: R = X @ F = X @ (X^T @ X)
        resonance = phase_vectors @ F  # (N, D)

        # Self-signal: each source's own contribution to its resonance
        # self_i = (phi_i . phi_i) * phi_i = ||phi_i||^2 * phi_i
        self_norms_sq = (phase_vectors * phase_vectors).sum(dim=-1, keepdim=True)  # (N, 1)
        self_signal = self_norms_sq * phase_vectors  # (N, D)

        # Interference = total resonance - self signal
        interference = resonance - self_signal

        # Loss = mean ratio of interference energy to self-signal energy
        interference_energy = (interference ** 2).sum(dim=-1)  # (N,)
        self_energy = (self_signal ** 2).sum(dim=-1) + 1e-8    # (N,)

        return (interference_energy / self_energy).mean()


class FieldRetrievalLoss(nn.Module):
    """End-to-end field retrieval loss with contrastive ranking.

    Build a mini-field from the batch, resonate each source,
    and ensure each source's resonance ranks itself highest
    among all sources (contrastive via the field).

    This is more direct than FieldInterferenceLoss: it optimizes
    the actual retrieval objective (correct source has highest score).
    """

    def __init__(self, temperature: float = 0.05) -> None:
        super().__init__()
        self.temperature = temperature

    def forward(self, phase_vectors: torch.Tensor) -> torch.Tensor:
        """Compute field retrieval contrastive loss.

        Args:
            phase_vectors: (N, D) -- phase vectors for one band.

        Returns:
            Scalar cross-entropy loss (field should retrieve each source correctly).
        """
        N, D = phase_vectors.shape

        # Build mini-field: F = X^T @ X
        F = phase_vectors.T @ phase_vectors  # (D, D)

        # Resonance for each source: r_i = F @ phi_i -> shape (N, D)
        resonance = phase_vectors @ F  # (N, D)

        # Score each source against each resonance:
        # score[i, j] = phi_j . r_i = phi_j . (F @ phi_i)
        # This is "how much does source j light up when we query with source i"
        scores = phase_vectors @ resonance.T  # (N, N)

        # Each source should score highest against its own resonance
        # => diagonal should be the max in each row
        labels = torch.arange(N, device=phase_vectors.device)

        return torch.nn.functional.cross_entropy(
            scores / self.temperature, labels
        )
