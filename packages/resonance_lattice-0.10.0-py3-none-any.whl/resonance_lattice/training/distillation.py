"""Retrieval-aligned knowledge distillation losses.

Trains projection heads to reproduce E5 flat baseline's ranking order
via KL-divergence between teacher (E5 cosine) and student (phase cosine)
similarity distributions.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class RankDistillationLoss(nn.Module):
    """KL-divergence between E5 cosine distribution and phase cosine distribution.

    For each anchor in a batch, computes:
      teacher = softmax(e5_sims / tau_teacher)   -- E5 cosine similarities
      student = softmax(phase_sims / tau_student) -- phase cosine similarities
      loss = KL(teacher || student)

    This teaches the heads to reproduce E5's ranking order through phase cosine.
    """

    def __init__(
        self,
        tau_teacher: float = 0.1,
        tau_student: float = 0.05,
    ) -> None:
        super().__init__()
        self.tau_teacher = tau_teacher
        self.tau_student = tau_student

    def forward(
        self,
        phase_vectors: torch.Tensor,
        e5_embeddings: torch.Tensor,
    ) -> torch.Tensor:
        """Compute rank distillation loss for a single band.

        Args:
            phase_vectors: (batch, D) -- projected phase vectors for one band.
            e5_embeddings: (batch, backbone_dim) -- raw E5 embeddings.

        Returns:
            Scalar KL-divergence loss.
        """
        # Teacher: E5 cosine similarity matrix
        e5_norm = F.normalize(e5_embeddings, p=2, dim=-1)
        e5_sims = e5_norm @ e5_norm.T  # (batch, batch)

        # Student: phase cosine similarity matrix
        phase_norm = F.normalize(phase_vectors, p=2, dim=-1)
        phase_sims = phase_norm @ phase_norm.T  # (batch, batch)

        # Mask self-similarity (diagonal) to avoid trivial solution
        batch_size = e5_sims.shape[0]
        mask = ~torch.eye(batch_size, dtype=torch.bool, device=e5_sims.device)

        # Apply mask: set diagonal to large negative so it doesn't dominate softmax
        e5_masked = e5_sims.masked_fill(~mask, -1e9)
        phase_masked = phase_sims.masked_fill(~mask, -1e9)

        # Softmax distributions
        teacher = F.softmax(e5_masked / self.tau_teacher, dim=-1)
        student_logits = phase_masked / self.tau_student
        student_log_probs = F.log_softmax(student_logits, dim=-1)

        # KL(teacher || student) = sum(teacher * log(teacher / student))
        # = sum(teacher * log(teacher)) - sum(teacher * log(student))
        loss = F.kl_div(student_log_probs, teacher, reduction="batchmean")

        return loss


class ListwiseRankingLoss(nn.Module):
    """ListNet-style listwise ranking loss.

    More directly optimizes ranking order than pointwise/pairwise.
    Cross-entropy between teacher and student probability distributions
    over the ranking permutation.

    P(d_i | q) = exp(s_i / tau) / sum(exp(s_j / tau))
    Loss = -sum_i P_teacher(d_i) * log(P_student(d_i))
    """

    def __init__(self, tau: float = 0.1) -> None:
        super().__init__()
        self.tau = tau

    def forward(
        self,
        phase_vectors: torch.Tensor,
        e5_embeddings: torch.Tensor,
    ) -> torch.Tensor:
        """Compute listwise ranking loss for a single band.

        Args:
            phase_vectors: (batch, D) -- projected phase vectors.
            e5_embeddings: (batch, backbone_dim) -- raw E5 embeddings.

        Returns:
            Scalar cross-entropy ranking loss.
        """
        e5_norm = F.normalize(e5_embeddings, p=2, dim=-1)
        phase_norm = F.normalize(phase_vectors, p=2, dim=-1)

        e5_sims = e5_norm @ e5_norm.T
        phase_sims = phase_norm @ phase_norm.T

        batch_size = e5_sims.shape[0]
        mask = ~torch.eye(batch_size, dtype=torch.bool, device=e5_sims.device)
        e5_masked = e5_sims.masked_fill(~mask, -1e9)
        phase_masked = phase_sims.masked_fill(~mask, -1e9)

        teacher_probs = F.softmax(e5_masked / self.tau, dim=-1)
        student_log_probs = F.log_softmax(phase_masked / self.tau, dim=-1)

        # Cross-entropy: -sum(teacher * log(student))
        loss = -(teacher_probs * student_log_probs).sum(dim=-1).mean()

        return loss
