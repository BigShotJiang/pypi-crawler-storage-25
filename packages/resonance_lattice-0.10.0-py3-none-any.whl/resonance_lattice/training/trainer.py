"""Encoder training loop with evaluation and checkpointing.

Trains projection heads on frozen backbone using multi-task losses.
Evaluates per-band retrieval quality, sparsity compliance, and
end-to-end recall on held-out data.

Spec reference: Section 9 (Multi-Scale Encoder Design).
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch.utils.data import DataLoader

from resonance_lattice.config import DEFAULT_SPARSITY_TARGETS
from resonance_lattice.encoder import Encoder
from resonance_lattice.training.losses import LossWeights, MultiScaleLoss


@dataclass
class TrainingConfig:
    """Configuration for encoder training."""
    # Model
    backbone: str = "intfloat/e5-large-v2"
    bands: int = 2             # MVP: 2 bands (topic + entity)
    dim: int = 2048
    active_bands: list[int] = field(default_factory=lambda: [1, 3])  # MVP: topic + entity

    # Training
    learning_rate: float = 1e-4
    weight_decay: float = 0.01
    batch_size: int = 32
    epochs: int = 10
    warmup_steps: int = 100
    grad_clip: float = 1.0

    # Loss weights
    loss_weights: LossWeights = field(default_factory=LossWeights)

    # Sparsity
    sparsity_mode: str = "l1"          # "l1" or "flops"
    sparsify_mode: str = "threshold"    # "topk", "threshold", "sparsemax"

    # Evaluation
    eval_every: int = 100      # Steps between evaluation
    save_every: int = 500      # Steps between checkpoints

    # Device
    device: str = "cpu"

    # Paths
    output_dir: str = "checkpoints"
    log_file: str = "training_log.jsonl"


@dataclass
class TrainingMetrics:
    """Metrics from a training step or evaluation."""
    step: int = 0
    epoch: int = 0
    loss_total: float = 0.0
    loss_components: dict[str, float] = field(default_factory=dict)
    sparsity_per_band: dict[int, float] = field(default_factory=dict)
    sparsity_target_met: bool = False
    recall_at_100: float = 0.0
    latency_ms: float = 0.0
    learning_rate: float = 0.0
    timestamp: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "step": self.step,
            "epoch": self.epoch,
            "loss_total": self.loss_total,
            "loss_components": self.loss_components,
            "sparsity_per_band": self.sparsity_per_band,
            "sparsity_target_met": self.sparsity_target_met,
            "recall_at_100": self.recall_at_100,
            "latency_ms": self.latency_ms,
            "learning_rate": self.learning_rate,
            "timestamp": self.timestamp,
        }


class EncoderTrainer:
    """Trains the multi-scale encoder's projection heads.

    The backbone is frozen; only projection heads are updated.
    Training uses multi-task loss with per-band objectives.
    """

    def __init__(
        self,
        config: TrainingConfig,
        encoder: Encoder | None = None,
    ) -> None:
        self.config = config
        self.device = torch.device(config.device)
        self.global_step = 0
        self.best_recall = 0.0
        self.history: list[TrainingMetrics] = []

        # Create output directory
        self.output_dir = Path(config.output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.log_path = self.output_dir / config.log_file

        # Create or use provided encoder
        if encoder is not None:
            self.encoder = encoder
        else:
            if config.backbone == "random":
                self.encoder = Encoder.random(
                    bands=config.bands,
                    dim=config.dim,
                )
            else:
                self.encoder = Encoder.from_backbone(
                    model_name=config.backbone,
                    bands=config.bands,
                    dim=config.dim,
                    device=config.device,
                )

        # Rebuild heads if trainer config specifies a different sparsify_mode
        # than what the encoder was created with
        current_mode = getattr(self.encoder.heads[0], "sparsify_mode", "threshold") if self.encoder.heads else "threshold"
        if config.sparsify_mode != current_mode:
            from resonance_lattice.encoder import ProjectionHead
            self.encoder.heads = torch.nn.ModuleList([
                ProjectionHead(
                    input_dim=self.encoder._backbone_dim,
                    output_dim=config.dim,
                    sparsity=self.encoder.config.get_sparsity(b),
                    sparsify_mode=config.sparsify_mode,
                )
                for b in range(config.bands)
            ])

        self.encoder.to(self.device)

        # Create loss function
        self.criterion = MultiScaleLoss(
            phase_dim=config.dim,
            weights=config.loss_weights,
            active_bands=config.active_bands,
            sparsity_mode=config.sparsity_mode,
        ).to(self.device)

        # Optimizer — only train projection heads + loss heads
        trainable_params = list(self.encoder.heads.parameters()) + list(self.criterion.parameters())
        self.optimizer = torch.optim.AdamW(
            trainable_params,
            lr=config.learning_rate,
            weight_decay=config.weight_decay,
        )

        # Learning rate scheduler
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer,
            T_max=config.epochs * 1000,  # Approximate total steps
        )

    def train_step(self, batch: dict[str, torch.Tensor]) -> TrainingMetrics:
        """Execute a single training step.

        Args:
            batch: Training batch with text embeddings and supervision signals.

        Returns:
            TrainingMetrics for this step.
        """
        self.encoder.train()
        self.criterion.train()

        # Move batch to device
        batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v
                 for k, v in batch.items()}

        # Forward: get embeddings from backbone
        if "embeddings" in batch:
            embeddings = batch["embeddings"]
        else:
            # Use random embeddings for testing
            embeddings = torch.randn(
                batch["domain_labels"].size(0),
                self.encoder._backbone_dim,
                device=self.device,
            )

        # Project through heads to get phase vectors
        phase_vectors = []
        for head in self.encoder.heads:
            phase_vectors.append(head(embeddings))
        phase_all = torch.stack(phase_vectors, dim=1)  # (batch, B, D)

        # For MVP 2-band: map to 5-band tensor with zeros for inactive bands
        if self.config.bands < 5:
            full_phase = torch.zeros(
                phase_all.size(0), 5, self.config.dim,
                device=self.device, dtype=phase_all.dtype,
            )
            for i, band_idx in enumerate(self.config.active_bands):
                if i < phase_all.size(1):
                    full_phase[:, band_idx, :] = phase_all[:, i, :]
        else:
            full_phase = phase_all

        # Build loss batch
        loss_batch = {"phase_vectors": full_phase}
        loss_batch.update(batch)

        # For contrastive losses: use phase vectors as both anchors and positives
        if "topic_positives" not in loss_batch and 1 in self.config.active_bands:
            # Create positive pairs by encoding pair texts through the same head
            if "pair_embeddings" in batch:
                pair_emb = batch["pair_embeddings"]
            else:
                pair_emb = embeddings + torch.randn_like(embeddings) * 0.1
            head_idx = self.config.active_bands.index(1) if 1 in self.config.active_bands else 0
            if head_idx < len(self.encoder.heads):
                loss_batch["topic_positives"] = self.encoder.heads[head_idx](pair_emb)

        if "entity_positives" not in loss_batch and 3 in self.config.active_bands:
            if "pair_embeddings" in batch:
                pair_emb = batch["pair_embeddings"]
            else:
                pair_emb = embeddings + torch.randn_like(embeddings) * 0.05
            head_idx = self.config.active_bands.index(3) if 3 in self.config.active_bands else 1
            if head_idx < len(self.encoder.heads):
                loss_batch["entity_positives"] = self.encoder.heads[head_idx](pair_emb)

        # Compute losses
        losses = self.criterion(loss_batch)

        # Backward
        self.optimizer.zero_grad()
        losses["total"].backward()

        # Gradient clipping
        torch.nn.utils.clip_grad_norm_(
            list(self.encoder.heads.parameters()) + list(self.criterion.parameters()),
            self.config.grad_clip,
        )

        self.optimizer.step()
        self.scheduler.step()
        self.global_step += 1

        # Compute sparsity metrics
        with torch.no_grad():
            sparsity_per_band = {}
            for i in range(phase_all.size(1)):
                nonzero_frac = (phase_all[:, i, :].abs() > 1e-6).float().mean().item()
                sparsity_per_band[self.config.active_bands[i] if i < len(self.config.active_bands) else i] = nonzero_frac

        # Check sparsity targets
        targets_met = True
        for band_idx, actual_sparsity in sparsity_per_band.items():
            target = DEFAULT_SPARSITY_TARGETS.get(band_idx + 1, 0.10)
            if actual_sparsity > target * 1.5:  # Allow 50% slack
                targets_met = False

        metrics = TrainingMetrics(
            step=self.global_step,
            loss_total=losses["total"].item(),
            loss_components={k: v.item() for k, v in losses.items() if k != "total"},
            sparsity_per_band=sparsity_per_band,
            sparsity_target_met=targets_met,
            learning_rate=self.optimizer.param_groups[0]["lr"],
            timestamp=time.time(),
        )

        return metrics

    def evaluate(
        self,
        eval_dataloader: DataLoader,
        num_sources: int = 1000,
    ) -> TrainingMetrics:
        """Evaluate encoder on retrieval quality.

        Encodes a corpus, builds a dense field, and measures recall@100.
        """
        from resonance_lattice.field.dense import DenseField

        self.encoder.eval()

        field = DenseField(bands=self.config.bands, dim=self.config.dim)

        all_phases = []
        with torch.no_grad():
            for batch in eval_dataloader:
                if len(all_phases) >= num_sources:
                    break

                if "embeddings" in batch:
                    embeddings = batch["embeddings"].to(self.device)
                else:
                    batch_size = batch["domain_labels"].size(0)
                    embeddings = torch.randn(batch_size, self.encoder._backbone_dim, device=self.device)

                # Project through heads
                phase_vectors = []
                for head in self.encoder.heads:
                    phase_vectors.append(head(embeddings))
                phase_all = torch.stack(phase_vectors, dim=1)  # (batch, B, D)
                phase_np = phase_all.cpu().numpy()

                for i in range(phase_np.shape[0]):
                    if len(all_phases) >= num_sources:
                        break
                    all_phases.append(phase_np[i])
                    field.superpose(phase_np[i], salience=1.0)

        all_phases = np.array(all_phases)

        # Recall@100: for each source, create a noisy query and check if original is in top-100
        rng = np.random.default_rng(42)
        hits = 0
        num_queries = min(100, len(all_phases))
        total_latency = 0.0

        for q in range(num_queries):
            target_idx = rng.integers(0, len(all_phases))
            noise = rng.standard_normal(all_phases[target_idx].shape).astype(np.float32) * 0.1
            query = all_phases[target_idx] + noise

            t0 = time.perf_counter()
            result = field.resonate(query)
            total_latency += time.perf_counter() - t0

            scores = np.array([
                np.dot(result.fused, all_phases[i].mean(axis=0))
                for i in range(len(all_phases))
            ])
            top_k = np.argsort(scores)[-100:]
            if target_idx in top_k:
                hits += 1

        recall = hits / num_queries
        avg_latency = (total_latency / num_queries) * 1000

        # Sparsity analysis
        sparsity_per_band = {}
        for b in range(all_phases.shape[1]):
            nonzero_frac = np.mean(np.abs(all_phases[:, b, :]) > 1e-6)
            sparsity_per_band[b] = float(nonzero_frac)

        return TrainingMetrics(
            step=self.global_step,
            recall_at_100=recall,
            latency_ms=avg_latency,
            sparsity_per_band=sparsity_per_band,
            timestamp=time.time(),
        )

    def train(
        self,
        train_dataloader: DataLoader,
        eval_dataloader: DataLoader | None = None,
        epochs: int | None = None,
    ) -> list[TrainingMetrics]:
        """Full training loop.

        Args:
            train_dataloader: Training data.
            eval_dataloader: Evaluation data (optional).
            epochs: Override config epochs.

        Returns:
            List of all training metrics.
        """
        epochs = epochs or self.config.epochs
        all_metrics = []

        print(f"Training encoder: {epochs} epochs, {len(train_dataloader)} batches/epoch")
        print(f"Active bands: {self.config.active_bands}")
        print(f"Device: {self.device}")

        for epoch in range(epochs):
            epoch_losses = []

            for batch_idx, batch in enumerate(train_dataloader):
                metrics = self.train_step(batch)
                metrics.epoch = epoch
                epoch_losses.append(metrics.loss_total)
                all_metrics.append(metrics)

                # Log
                if self.global_step % 10 == 0:
                    avg_loss = np.mean(epoch_losses[-10:])
                    sparsity_str = " ".join(
                        f"b{k}:{v:.3f}" for k, v in sorted(metrics.sparsity_per_band.items())
                    )
                    print(f"  step {self.global_step:5d} | loss {avg_loss:.4f} | "
                          f"sparsity [{sparsity_str}] | lr {metrics.learning_rate:.2e}")

                # Evaluate
                if eval_dataloader and self.global_step % self.config.eval_every == 0:
                    eval_metrics = self.evaluate(eval_dataloader)
                    eval_metrics.epoch = epoch
                    all_metrics.append(eval_metrics)

                    improved = eval_metrics.recall_at_100 > self.best_recall
                    if improved:
                        self.best_recall = eval_metrics.recall_at_100
                        self.save_checkpoint("best")

                    marker = " *** NEW BEST ***" if improved else ""
                    print(f"  EVAL step {self.global_step}: recall@100={eval_metrics.recall_at_100:.3f}, "
                          f"latency={eval_metrics.latency_ms:.2f}ms{marker}")

                # Checkpoint
                if self.global_step % self.config.save_every == 0:
                    self.save_checkpoint(f"step_{self.global_step}")

                # Log to file
                self._log_metrics(metrics)

            avg_epoch_loss = np.mean(epoch_losses) if epoch_losses else 0.0
            print(f"Epoch {epoch+1}/{epochs} complete. Avg loss: {avg_epoch_loss:.4f}")

        # Final evaluation
        if eval_dataloader:
            final_eval = self.evaluate(eval_dataloader)
            print(f"\nFinal recall@100: {final_eval.recall_at_100:.3f}")
            print(f"Final latency: {final_eval.latency_ms:.2f}ms")
            all_metrics.append(final_eval)

        # Save final checkpoint
        self.save_checkpoint("final")
        self.history = all_metrics
        return all_metrics

    def save_checkpoint(self, name: str) -> Path:
        """Save encoder heads and loss function state."""
        ckpt_dir = self.output_dir / name
        ckpt_dir.mkdir(parents=True, exist_ok=True)

        # Include all fields required by Encoder.from_checkpoint() for
        # faithful restore, including protocol fields and sparsities.
        enc_cfg = self.encoder.config
        sparsities = [head.sparsity for head in self.encoder.heads]

        torch.save({
            "heads_state_dict": self.encoder.heads.state_dict(),
            "criterion_state_dict": self.criterion.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "global_step": self.global_step,
            "best_recall": self.best_recall,
            "config": {
                "bands": self.config.bands,
                "dim": self.config.dim,
                "active_bands": self.config.active_bands,
                "backbone": self.encoder.config.backbone,
                "backbone_dim": self.encoder._backbone_dim,
                "sparsities": sparsities,
                "head_type": getattr(self, "_head_type", "linear"),
                "query_prefix": enc_cfg.query_prefix,
                "passage_prefix": enc_cfg.passage_prefix,
                "pooling": enc_cfg.pooling,
            },
        }, ckpt_dir / "checkpoint.pt")

        return ckpt_dir

    def load_checkpoint(self, path: str | Path) -> None:
        """Load encoder heads from checkpoint."""
        path = Path(path)
        ckpt = torch.load(path / "checkpoint.pt", map_location=self.device, weights_only=False)
        self.encoder.heads.load_state_dict(ckpt["heads_state_dict"])
        self.criterion.load_state_dict(ckpt["criterion_state_dict"])
        self.optimizer.load_state_dict(ckpt["optimizer_state_dict"])
        self.global_step = ckpt["global_step"]
        self.best_recall = ckpt["best_recall"]

    def _log_metrics(self, metrics: TrainingMetrics) -> None:
        """Append metrics to JSONL log file."""
        with open(self.log_path, "a") as f:
            f.write(json.dumps(metrics.to_dict()) + "\n")
