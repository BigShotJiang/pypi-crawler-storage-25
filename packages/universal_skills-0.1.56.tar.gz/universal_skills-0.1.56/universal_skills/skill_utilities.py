#!/usr/bin/python
# coding: utf-8

import os
from pathlib import Path
from importlib.resources import files, as_file
from typing import Optional

try:
    from openai import AsyncOpenAI
    from pydantic_ai.providers.openai import OpenAIProvider
except ImportError:
    AsyncOpenAI = None
    OpenAIProvider = None

try:
    from groq import AsyncGroq
    from pydantic_ai.providers.groq import GroqProvider
except ImportError:
    AsyncGroq = None
    GroqProvider = None

try:
    from mistralai import Mistral
    from pydantic_ai.providers.mistral import MistralProvider
except ImportError:
    Mistral = None
    MistralProvider = None

try:
    from pydantic_ai.models.anthropic import AnthropicModel
    from anthropic import AsyncAnthropic
    from pydantic_ai.providers.anthropic import AnthropicProvider
except ImportError:
    AnthropicModel = None
    AsyncAnthropic = None
    AnthropicProvider = None

__version__ = "0.1.56"


def get_universal_skills_package_name() -> str:
    """
    Returns the package name of universal_skills.
    """
    return "universal_skills"


def to_boolean(val) -> bool:
    if isinstance(val, bool):
        return val
    return str(val).lower() in ("true", "1", "t", "y", "yes")


# Default enablement state for specific skills or skill-graphs.
# If a skill/graph is not listed here, it follows the global default for its category.
SKILL_DEFAULTS = {
    # Niche skills disabled by default
    "cloudflare-deploy": False,
    "google-workspace": False,
    "jupyter-notebook": False,
    "skill-graph-builder": True,
    "web-crawler": True,
    "web-search": True,
    # Documentation graphs are False by default globally, but can be overridden here if needed.
}


def _get_enabled_paths(sub_dir: str, default_enabled: bool = True) -> list[str]:
    """
    Helper to return absolute paths of items in a sub-directory that are enabled via env vars.
    Checks inside the package directory.
    """
    base_dir = files(get_universal_skills_package_name()) / sub_dir
    with as_file(base_dir) as path:
        abs_path = str(path)

    enabled_paths = []
    if os.path.exists(abs_path):
        for item in os.listdir(abs_path):
            item_path = os.path.join(abs_path, item)
            if os.path.isdir(item_path):
                # Check for specific override in SKILL_DEFAULTS
                item_default = SKILL_DEFAULTS.get(item, default_enabled)

                env_var_name = f"{item.upper().replace('-', '_')}_ENABLE"
                is_enabled = to_boolean(os.environ.get(env_var_name, item_default))
                if is_enabled:
                    enabled_paths.append(item_path)
    return enabled_paths


def get_universal_skills_path() -> list[str]:
    """
    Returns a list of absolute paths pointing to the individual enabled universal skills.
    Specific skills can be enabled/disabled via environment variables formatted as:
    <SKILL_DIR_NAME_UPPER_UNDERSCORES>_ENABLE=True|False
    """
    return _get_enabled_paths("skills", default_enabled=True)


def get_skill_graph_path() -> list[str]:
    """
    Returns a list of absolute paths pointing to the individual enabled skill-graphs.
    Specific skill-graphs can be enabled/disabled via environment variables formatted as:
    <GRAPH_DIR_NAME_UPPER_UNDERSCORES>_ENABLE=True|False

    This scans the user's cache directory (~/.cache/universal-skills/skill-graphs)
    for subdirectories and includes them if their corresponding enable flag is set.
    """
    cache_base = os.environ.get("XDG_CACHE_HOME", os.path.expanduser("~/.cache"))
    cache_dir = Path(cache_base) / "universal-skills" / "skill-graphs"

    enabled_paths = []
    if cache_dir.exists() and cache_dir.is_dir():
        for item in os.listdir(cache_dir):
            item_path = cache_dir / item
            if item_path.is_dir():
                # Default to False for skill-graphs unless explicitly enabled
                env_var_name = f"{item.upper().replace('-', '_')}_ENABLE"
                is_enabled = to_boolean(os.environ.get(env_var_name, False))
                if is_enabled:
                    enabled_paths.append(str(item_path.resolve()))

    return enabled_paths


def resolve_mcp_reference(filename: str) -> Optional[str]:
    """
    Resolves an MCP configuration filename to its absolute path within the mcp-client skill.
    Supports .json, .md, and extensionless filenames (defaults to .json).
    """
    if not filename:
        return None

    # Check if it's already an absolute or relative path that exists
    if os.path.exists(filename):
        return str(Path(filename).resolve())

    try:
        # Standardize filename: if no extension, default to .json
        # If it has an extension (like .md), keep it.
        has_extension = any(filename.endswith(ext) for ext in [".json", ".md"])
        target_file = filename if has_extension else f"{filename}.json"

        # Resolve via importlib.resources
        ref_base = (
            files(get_universal_skills_package_name())
            / "skills"
            / "mcp-client"
            / "references"
            / target_file
        )
        with as_file(ref_base) as path:
            if path.exists():
                return str(path)
    except Exception as e:
        import logging

        logging.getLogger(__name__).debug(
            f"Error resolving MCP reference {filename}: {e}"
        )

    return None
