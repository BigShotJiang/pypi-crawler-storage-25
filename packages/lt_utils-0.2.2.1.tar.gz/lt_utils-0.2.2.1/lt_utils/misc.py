from __future__ import annotations

__all__ = [
    "default",
    "is_valid",
    "get_traceback_data",
    "get_os_info",
    "get_system_memory",
    "get_pid_by_name",
    "get_process_memory",
    "close_process_by_id",
    "close_process_by_name",
    "clear_all_caches",
    "malloc_trim",
    "clean_memory",
    "terminal",
    "cache_wrapper",
    "flatten_list",
    "filter_list",
    "ff_list",
    "safe_call",
    "import_functions",
    "get_current_time",
    "get_random_name",
    "args_to_kwargs",
    "filter_kwargs",
    "audio_array_to_bytes",
    "audio_bytes_to_array",
    "show_audio",
    "show_image",
    "show_video",
]

import re
import torch
import numpy as np
from functools import lru_cache, wraps
from .common import (
    Union,
    Any,
    List,
    Path,
    PathLike,
    Number,
    Optional,
    Dict,
    Tuple,
    Literal,
    Callable,
    get_args,
    TypeVar,
    TYPE_CHECKING,
    TypeGuard,
)

from .types import is_array, is_union, is_pathlike, is_tensor

if TYPE_CHECKING:
    from torch import Tensor
    from numpy import ndarray


T = TypeVar("T")


def updateDict(self, dct: dict[str, Any]):
    for k, v in dct.items():
        setattr(self, k, v)


def default(entry: Optional[T], other: T) -> T:
    return entry if entry is not None else other


def is_valid(
    entry: T,
    validate: bool = False,
) -> TypeGuard[T]:
    results = entry is not None
    assert not validate or results
    return results


def get_file_name(entry: PathLike, keep_extension: bool = True):
    is_pathlike(entry, False, True)
    f_name = Path(entry).name
    if keep_extension or "." not in f_name:
        return f_name
    return f_name[: f_name.rfind(".")]


def path_to_str(entry: PathLike, *, check: bool = True):
    if check:
        is_pathlike(entry, False, True)
    return str(entry).replace("\\", "/")


def filter_kwargs(
    target: object,
    kwargs: Dict[str, Any],
    ignore: List[str] = [],
):
    import inspect

    available_kwargs = list(inspect.signature(target).parameters.keys())
    validated_kwargs = {}
    for k, v in kwargs.items():
        if k in available_kwargs:
            if k not in ignore:
                validated_kwargs[k] = v
    return validated_kwargs


def get_traceback_data(
    tb: str,
) -> Tuple[List[Dict[str, Union[str, Number]]], List[str]]:
    results: List[dict[str, Number]] = []
    unprocessed: List[str] = []
    for gp in re.finditer(r"\w+ \"([\w+:\\\.\-\_/]+)\", line (\d+), in (.+)\n(.+)", tb):
        try:
            results.append(
                {
                    "module": gp[1].strip(),
                    "line_id": int(gp[2].strip()),
                    "in": gp[3].strip(),
                    "value": gp[4].strip(),
                }
            )

        except Exception as e:
            unprocessed.append(gp.string)
    return results, unprocessed


def get_os_info() -> Dict[str, str]:
    """Returns information about the operating system."""
    import platform

    return {
        "os": platform.system(),
        "release": platform.release(),
        "version": platform.version(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "python_version": platform.python_version(),
    }


def get_system_memory() -> Dict[str, Number]:
    """Returns system memory stats in bytes."""
    import psutil

    vm = psutil.virtual_memory()
    return {
        "total": vm.total,
        "available": vm.available,
        "used": vm.used,
        "free": vm.free,
        "percent": vm.percent,
    }


def get_pid_by_name(process_name: str, strict: bool = False) -> List[Dict[str, Any]]:
    import psutil

    if not strict:
        process_name = process_name.lower()
    results: List[Dict[str, Any]] = []
    for proc in psutil.process_iter():
        process_info = proc.as_dict(attrs=["pid", "name", "status", "ppid"])
        valid = (
            (process_name == process_info["name"])
            if strict
            else (process_name in process_info["name"].lower())
        )
        if valid:
            results.append(process_info)
    return results


def get_pid_by_name(process_name: str, strict: bool = False) -> List[Dict[str, Any]]:
    import psutil

    if not strict:
        process_name = process_name.lower()
    results: List[Dict[str, Any]] = []
    for proc in psutil.process_iter():
        process_info = proc.as_dict(attrs=["pid", "name", "status", "ppid"])
        valid = (
            (process_name == process_info["name"])
            if strict
            else (process_name in process_info["name"].lower())
        )
        if valid:
            results.append(process_info)
    return results


def get_process_memory(pid: int = None) -> Dict[str, Any]:
    """Returns memory usage of a given process (or current one)."""
    import os, psutil

    pid = pid or os.getpid()
    proc = psutil.Process(pid)
    mem_info = proc.memory_info()
    return {
        "rss": mem_info.rss,  # Resident Set Size
        "vms": mem_info.vms,  # Virtual Memory Size
        "shared": getattr(mem_info, "shared", 0),
        "text": getattr(mem_info, "text", 0),
        "lib": getattr(mem_info, "lib", 0),
        "data": getattr(mem_info, "data", 0),
        "dirty": getattr(mem_info, "dirty", 0),
    }


def close_process_by_id(pid: int):
    """Example: `close_process("notepad.exe")`"""
    import psutil

    proc = psutil.Process(pid)
    process_info = proc.as_dict(attrs=["pid", "name", "status", "ppid"])
    try:
        proc.terminate()
        process_info["results"] = {"stats": "success", "reason": None}
        process_info["status"] = "terminated"

    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess) as e:
        # Prudently handling potential exceptions arising during process information retrieval
        process_info["results"] = {"stats": "fail_safe", "reason": str(e)}
        pass

    except Exception as e:
        process_info["results"] = {"stats": "fail", "reason": str(e)}

    return process_info


def close_process_by_name(process_name: str, strict: bool = False):
    """Example: `close_process_by_name("notepad.exe")`"""
    if not strict:
        process_name = process_name.lower()
    results: List[Dict[str, Any]] = []
    import psutil

    for proc in psutil.process_iter():
        process_info = proc.as_dict(attrs=["pid", "name", "status", "ppid"])
        if not strict:
            valid = process_name in process_info["name"].lower()
        else:
            valid = process_info["name"] == process_name
        if not valid:
            continue
        try:
            proc.terminate()
            process_info["results"] = {"stats": "success", "reason": None}
            process_info["status"] = "terminated"
            print(f"Instance deletion successful: {process_info}")

        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            process_info["results"] = {"stats": "fail_safe", "reason": str(e)}

        except Exception as e:
            print(e)
            process_info["results"] = {"stats": "fail", "reason": str(e)}
        finally:
            results.append(process_info)

    return results


def clear_all_caches(registered_funcs: Optional[list] = None):
    """Clears global caches like lru_cache and runs garbage collection."""
    import gc

    gc.collect()
    if registered_funcs:
        for func in registered_funcs:
            try:
                func.cache_clear()
            except AttributeError:
                pass


def malloc_trim():
    """On Linux, frees memory from malloc() back to the OS."""
    import platform

    if platform.system() == "Linux":
        import ctypes

        libc = ctypes.CDLL("libc.so.6")
        libc.malloc_trim(0)


def clean_memory(clears: Optional[list] = None):
    """Performs full memory cleanup: gc, cache clears, and malloc_trim (Linux)."""
    clear_all_caches(clears)
    malloc_trim()


def terminal(
    *commant_lines: str,
    encoding: Optional[
        Union[
            Literal[
                "ascii",
                "utf-8",
                "iso-8859-1",
                "unicode-escape",
            ],
            str,
        ]
    ] = None,
    errors: Literal[
        "ignore",
        "strict",
        "replace",
        "backslashreplace",
        "surrogateescape",
    ] = "strict",
):
    """Terminal that returns the output
    made mostly to just to save a line of code."""
    import subprocess

    return subprocess.run(
        commant_lines,
        shell=True,
        capture_output=True,
        text=True,
        encoding=encoding,
        errors=errors,
    ).stdout


def cache_wrapper(func):
    """
    A decorator to cache the function result while keeping the original documentation, variable names, etc.

    Example
        ```py
        @cache_wrapper
        def your_function(arg1:int, arg2:int) -> bool:
            \"\"\"
            compares if the first number is larger than the second number.
            args:
                arg1(int): The number that is expected to be larger than arg2.
                arg2(int): The number expected to be smaller than arg1

            return:
                bool: True if arg1 is larger than arg2 otherwise False.
            \"\"\"
            return arg1 > arg2
        ```
    """
    cached_func = lru_cache(maxsize=None)(func)

    # Apply the wraps decorator to copy the metadata from the original function
    @wraps(func)
    def wrapper(*args, **kwargs):
        return cached_func(*args, **kwargs)

    return wrapper


def flatten_list(entry):
    """
    Example:
    ```py
    from gr1336_toolbox import flatten_list

    sample = ["test", [[[1]], [2]], 3, [{"last":4}]]
    results = flatten_list(sample)
    # results = ["test", 1, 2, 3, {"last": 4}]
    ```"""
    if is_array(entry, True):
        return [item for sublist in entry for item in flatten_list(sublist)]
    return [entry] if entry is not None else []


def filter_list(entry: Union[list, tuple], types: Union[T, tuple[T]]) -> list[T]:
    assert is_array(entry, False), "To filter a list, it must be a list or a tuple"
    if is_union(types):
        types = get_args(types)
    return [x for x in entry if isinstance(x, types)]


def ff_list(entry: Union[list, tuple], types: Union[T, tuple[T]]) -> List[T]:
    """Flattens and filters the provided list"""
    assert is_array(
        entry, False, False
    ), "To flatten and filter a list, it must be a list or a tuple"
    return filter_list(flatten_list(entry), types)


def safe_call(
    fn: Callable[[T], T],
    *,
    safe_default: Optional[T] = None,
    verbose_exception: bool = False,
    **fn_kwargs,
) -> T:
    """Can be used to call a function without an exception interrupting the process.

    Args:
        fn (Callable[[T, ...], T]): The function to be called safely.
        safe_default (T): The value that will be returned case an exception is raised.
        verbose_exception (bool, optional): If True, logs the traceback if the function raises anything. Defaults to False.
    Returns:
        T: The output type of the given function or the default value.
    """
    assert callable(fn), "The provided 'fn' is not a callable object!"
    try:
        return fn(filter_kwargs(fn, fn_kwargs))
    except Exception as e:
        if verbose_exception:
            from lt_utils.log import log_traceback

            log_traceback(
                e,
                stack_size=3,
            )
        return safe_default


def import_functions(
    path: Union[str, Path],
    target_function: str,
    pattern: str = "*.py",
    deep_scan: bool = True,
    validate_path: bool = False,
):
    """
    Imports and returns all functions from .py files in the specified directory matching a certain function name.

    Args:
        path (str or Path): The path of the directories to search for the Python files.
        target_function (str): The exact string representing the function name to be searched within each file.
        pattern (str, optional): Pattern of the file to be scanned. Defaults to "*.py" with covers all files with .py extension.
        deep_scan (bool, optional): Setting this to false will make only a surface level scan in the directory, while keeping it True, will scan all the sub-folders in the given directory. Defaults to True.
        validate_path (bool, optional): If True, this function will raise an "FileNotFoundError" exception when the given path does not exist. Defaults to False.

    Returns:
        list: A list containing all the functions with the given name found in the specified directory and subdirectories.

    Example:
        >>> import_functions('/path/to/directory', 'some_function')
        [<function some_function at 0x7f036b4c6958>, <function some_function at 0x7f036b4c69a0>]
    """
    is_pathlike(path, False, validate=True)
    results = []
    path = Path(path)
    if not path.exists():
        if validate_path:
            raise FileNotFoundError(f"'{path_to_str(path)}' does not exist!")
        return results
    if path.is_dir():
        from lt_utils.file import find_files

        python_files = [find_files(path, [pattern], deep=deep_scan)]
    else:
        python_files = [path]
    python_files = flatten_list(python_files)
    if python_files:
        import importlib.util

        for file in python_files:
            spec = importlib.util.spec_from_file_location(Path(file).name, file)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            if hasattr(module, target_function):
                results.append(getattr(module, target_function))
    return results


def get_current_time():
    """
    Returns the current date and time in a 'YYYY-MM-DD-HHMMSS' format.

    Returns:
        str: The current date and time.
    """
    from datetime import datetime

    return f"{datetime.now().strftime('%Y-%m-%d-%H%M%S')}"


def get_random_name(source: Literal["time", "uuid4", "uuid4-hex"] = "uuid4"):
    from uuid import uuid4

    assert isinstance(
        source, str
    ), f'Invalid type "{type(source)}". A value for `source` needs to be a valid str'
    assert source.strip(), "Source cannot be empty!"
    source = source.lower().strip()
    assert source in [
        "time",
        "uuid4",
        "uuid-hex",
    ], f'No such source \'{source}\'. It needs to be either "time", "uuid4" or "uuid4-hex"'
    match source:
        case "time":
            return get_current_time()
        case "uuid4":
            return str(uuid4())
        case _:
            return uuid4().hex


def args_to_kwargs(*args):
    import inspect

    frame = inspect.currentframe().f_back
    results = {}
    for name, value in frame.f_locals.items():
        if value in args:
            results[name] = value
    return results


def audio_array_to_bytes(
    audio_array: Union["Tensor", "ndarray"],
    sample_rate: int = 24000,
    mono: bool = True,
) -> bytes:
    import wave
    import io

    if is_tensor(audio_array):
        if torch.is_floating_point(audio_array):
            audio_array = audio_array.float()
        audio_array = audio_array.clone().detach().cpu().numpy()
    else:
        audio_array = np.asarray(audio_array)
    byte_io = io.BytesIO()
    with wave.open(byte_io, "wb") as wav_file:
        wav_file.setnchannels(2 - bool(mono))
        wav_file.setsampwidth(2)  # 16-bit audio
        wav_file.setframerate(sample_rate)
        wav_file.writeframes((audio_array * 32767).astype(np.int16).tobytes())
    return byte_io.getvalue()


def audio_bytes_to_array(
    audio_bytes: Union[bytes, PathLike],
    normalize: bool = True,
    mono: bool = True,
    output_type: Literal["torch", "numpy"] = "numpy",
) -> Tuple[Union["ndarray", "Tensor"], int]:
    """
    Convert raw WAV bytes  (from a wav file or audio_array_to_bytes conversion)
    back into a numpy array (float32 or int16).

    Args:
        audio_bytes: Bytes representing a WAV file (like from audio_array_to_bytes).
        mono: If True, will set the number of channels to 1.
        normalize: If True, scales int16 data to float range.
        output_type: If the audio array should be returned as a torch Tensor or a numpy ndarray.

    Returns:
        Tuple[Union[Tensor, np.ndarray, torch.FloatTensor], int]: (audio_array, sample_rate)
    """
    import wave
    import io

    if isinstance(audio_bytes, bytes):
        audio_bytes = io.BytesIO(audio_bytes)
    elif isinstance(audio_bytes, (str, Path)):
        audio_bytes = io.BytesIO(Path(audio_bytes).read_bytes())

    with wave.open(audio_bytes, "rb") as wav_file:
        num_channels = wav_file.getnchannels()
        sample_rate = wav_file.getframerate()
        sample_width = wav_file.getsampwidth()  # in bytes (2 = int16)
        num_frames = wav_file.getnframes()
        raw_data = wav_file.readframes(num_frames)

    if sample_width != 2:
        raise ValueError("Only 16-bit PCM WAV files are supported.")

    # Convert raw bytes to int16 array, and make it writable for torch
    audio = torch.as_tensor(np.frombuffer(raw_data, dtype=np.int16).copy())

    # Reshape
    if mono:
        if num_channels > 1:
            audio = audio.reshape(-1, num_channels)[:, -1:]

    audio = audio.to(torch.float32)
    if normalize:
        audio = audio / 32767.0
    if output_type == "numpy":
        audio = audio.numpy()
    return audio, sample_rate


def show_audio(
    audio_track: Union["ndarray", "Tensor", List],
    sample_rate: int = 24000,
):
    import IPython.display as iDisplay

    if is_tensor(audio_track):
        audio = audio_track.clone().detach()
        if torch.is_floating_point(audio):
            audio = audio.float()  # problems with bfloat16
        audio = audio.cpu().squeeze().numpy()
    else:
        audio = np.asarray(audio_track).squeeze()
    return iDisplay.display(iDisplay.Audio(audio, rate=sample_rate))


def compress_numbers(target: Any):

    if isinstance(target, float):
        return f"{target:.4f}"
    if isinstance(target, int):
        return format(target, ",").replace(",", ".")
    if isinstance(target, (Tensor, np.ndarray)):
        target = torch.as_tensor(target)
        if not torch.is_floating_point(target):
            return target
        if target.numel() < 2:
            return f"{target.item():.4f}"
        return torch.round(target, decimals=4)
    if hasattr(target, "values"):
        return compress_numbers(target.values)
    return target


def show_image(image: Any):
    import numpy as np
    import IPython.display as iDisplay

    if isinstance(image, (np.ndarray, Tensor)):
        from lt_utils.plot import plot_tensor_image

        try:
            image = plot_tensor_image(
                image,
                color_first=True,
            )
        except:
            image = plot_tensor_image(
                image,
                color_first=False,
            )

    try:
        return iDisplay.display(image)
    except Exception as e:
        try:
            return iDisplay.display(iDisplay.Image(image))
        except:
            raise e


def show_video(video: Any):
    import IPython.display as iDisplay

    try:
        return iDisplay.display(iDisplay.Video(video))
    except Exception as e:
        try:
            return iDisplay.display(video)
        except:
            raise e
