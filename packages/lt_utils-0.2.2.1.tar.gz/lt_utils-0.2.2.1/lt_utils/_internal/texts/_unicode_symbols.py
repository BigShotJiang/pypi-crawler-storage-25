# Unicode ranges grouped by script/language family
def get_unicode_map():
    return {
        # --- Core Latin + IPA ---
        "latin_basic": [("0000", "007F")],  # ASCII
        "latin_1": [("0080", "00FF")],  # Latin-1 Supplement
        "latin_extended": [
            ("0100", "017F"),  # Extended-A
            ("0180", "024F"),  # Extended-B
            ("1E00", "1EFF"),  # Extended Additional
        ],
        "ipa": [
            ("0250", "02AF"),  # IPA Extensions
            ("02B0", "02FF"),  # Spacing Modifier Letters
            ("0300", "036F"),  # Combining Diacritical Marks
            ("1D00", "1D7F"),  # Phonetic Extensions
            ("1D80", "1DBF"),  # Phonetic Extensions Supplement
        ],
        # --- Europe ---
        "greek": [("0370", "03FF")],
        "cyrillic": [("0400", "04FF")],
        # --- Middle East ---
        "hebrew": [("0590", "05FF")],
        "arabic": [
            ("0600", "06FF"),  # Arabic
            ("0750", "077F"),  # Arabic Supplement
            ("08A0", "08FF"),  # Arabic Extended-A
        ],
        # --- South Asia ---
        "devanagari": [("0900", "097F")],
        "bengali": [("0980", "09FF")],
        "gurmukhi": [("0A00", "0A7F")],
        "gujarati": [("0A80", "0AFF")],
        "oriya": [("0B00", "0B7F")],
        "tamil": [("0B80", "0BFF")],
        "telugu": [("0C00", "0C7F")],
        "kannada": [("0C80", "0CFF")],
        "malayalam": [("0D00", "0D7F")],
        "sinhala": [("0D80", "0DFF")],
        "thai": [("0E00", "0E7F")],
        "khmer": [("1780", "17FF")],
        # --- East Asia ---
        "hiragana": [("3040", "309F")],
        "katakana": [
            ("30A0", "30FF"),  # Katakana
            ("31F0", "31FF"),  # Katakana Extensions
        ],
        "cjk": [
            ("4E00", "9FFF"),  # Unified Ideographs
            ("3400", "4DBF"),  # Extension A
        ],
        "hangul": [
            ("AC00", "D7AF"),  # Hangul Syllables
            ("1100", "11FF"),  # Hangul Jamo
        ],
        # --- Southeast Asia / Philippines ---
        "tagalog": [("1700", "171F")],
        "hanunoo": [("1720", "173F")],
        "buhid": [("1740", "175F")],
        "tagbanwa": [("1760", "177F")],
        # --- Punctuation ---
        "punctuation": [
            ("2000", "206F"),  # General Punctuation
            ("2E00", "2E7F"),  # Supplemental Punctuation
        ],
    }

def get_phonetic_chars():
    from string import printable
    return list(
            list(printable)
            + [
                'ɓ', 'ã', 'ʈ͡', 'ʑ', 'ɭ', 'ˌ', 'ᵻ', 'ɪ', 'ɖ͡', '↓', '͡', '↑', 'ɶ', 'ɟ', 'ç', 'ʈ͡ʂ',
                'ɚ', 'ʊ', 'ẽ', 'ʡ', 'p͡', '‖', 'ɐ', 't͡s', 'ɤ', 'zt͡', 'ɳ', 'ɴ', 'k͡', 'œ', 'ɨ', 'ʍ',
                'd͡ʑ', 'd͡z', '˦', 'ʏ', '˨', 'ɢ', 'ɖ', 'ⱱ', 'ˑ', 'ɔ̃', 'ǃ', 'ɸ', '˩', 'ʷ', 'd͡', 'ŋ',
                'ʱ', 'ɗ', 't͡', 'ʎ', 'χ', 'ʤ', 'ɛ', 'ʧ', 'ʴ', 'ɕ', 'ˤ˞', 'ǀ', '↗', 'ɑ', 't̪͡', 'ɻ',
                'ɺ', 'ʢ', 'ʲ', 'ǂ', 'ʄ', 'ʟ', 'ɬ', 'ʂ', 'ɧ', 'ʒ', 'ˈ', 'ˀ', 'p͡f', 'ɠ', 'ɹ', 't̪͡s',
                'ʕ', 'ɣ', 'ʃ', 'ɮ', 'ʀ', 'ʉ', 't͡ɕ', 'd͡ʒ', "'̩", 'ʔ', 'ɒ', 'ø', 'ħ', 'ɜ', 'ǁ', '→',
                'ɯ', 'ɾ', 'ː', 'ʜ', 'ɖ͡ʐ', 'ɱ', 'ð', 'ɦ', 'ʁ', 'ʌ', 'ɫ', 'ʈ', 'ɥ', 'æ', 'ɡ', 'ʐ',
                'ɰ', 'ə', '↘', 'ʼ', 'b͡', 'β', 'ɔ', 't͡ʃ', 'k͡x', 'b͡v', 'θ', 'ʋ', 'ɞ', '˥', 'ɘ', 'ʘ',
                'ɽ', 'ˠ', 'ʰ', 'ɲ', 'ʙ', 'ʛ', 'ʝ', 'ɵ', '˧', 'ɝ',
            ] 
    )


def normalize_unique_chars(text: str):
    return text.translate(
        {
            96: "'",
            178: "2",
            179: "3",
            184: ",",
            185: "1",
            191: "?",
            577: "?",
            726: "+",
            803: ".",
            856: ".",
            894: "?",
            1548: ",",
            1567: "?",
            1643: ".",
            2429: "?",
            5038: "?",
            5161: "+",
            6152: ",",
            8216: "'",
            8217: "'",
            8218: ",",
            8219: "'",
            8220: '"',
            8221: '"',
            8222: '"',
            8228: ".",
            8291: ",",
            8292: "+",
            8330: "+",
            8724: "+",
            8853: "+",
            9072: "?",
            10075: "'",
            10076: "'",
            10079: ",",
            10080: '"',
            11822: "?",
            11841: ",",
            12317: '"',
            12318: '"',
            12319: '"',
            42233: ",",
            42798: "4,",
            64297: "+",
            65046: "?",
            65104: ",",
            65105: ",",
            65110: "?",
            65122: "+",
            65282: '"',
            65291: "+",
            65292: ",",
            65311: "?",
            65380: ",",
            93847: ",",
            127233: "0,",
            127234: "1,",
            127235: "2,",
            127236: "3,",
            127237: "4,",
            127238: "5,",
            127239: "6,",
            127240: "7,",
            127241: "8,",
            127242: "9,",
            128632: ",",
            917547: "+",
            917548: ",",
            917567: "?",
        }
    )
