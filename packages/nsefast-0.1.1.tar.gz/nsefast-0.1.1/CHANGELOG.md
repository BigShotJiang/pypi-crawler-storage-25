# Changelog

All notable changes to **nsefast** are documented in this file.
The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and the project adheres to [Semantic Versioning](https://semver.org/).

## [0.1.1] - 2026-05-06

### Added

- **Hive-partitioned parquet** — `save_parquet_partitioned(df, dataset, by=[…])`,
  `read_parquet_partitioned(dataset, filters=[(col, op, val), …])`,
  `derive_date_partitions(df, "trade_date", parts=("year","month","day"))`,
  `list_partitions(dataset)`. Pushdown predicates handled by PyArrow.
- **DuckDB analytics helpers** — `connect()`, `register_all(con)` registers
  one view per dataset, plus canned queries `top_gainers`, `top_losers`,
  `daily_summary`, `sector_leaderboard`. All views read with
  `hive_partitioning = true, union_by_name = true`.
- **Request cache layer** — `nsefast.cache.cached_get(session, url, ttl_seconds)`
  is a content-addressed on-disk cache (`data/cache/<sha>.bin` + meta sidecar).
  Default TTL 5 min. Never raises, never caches non-200, expires cleanly.
  CLI: `nsefast cache stats`, `nsefast cache clear`.
- **Structured logging** — `nsefast.logging_setup.setup_logging(level, fmt)`
  with `fmt="json"` emits one-line JSON per record (ts, level, logger, msg,
  plus any `extra={…}`). Configurable via `NSEFAST_LOG_FORMAT=json` and
  `NSEFAST_LOG_LEVEL=DEBUG`.
- **Install verification CLI** — `nsefast verify` smoke-tests imports,
  parquet roundtrip, duckdb in-memory query, and CLI registration. Pass
  `--network` to additionally test NSE warm-up + robots.txt fetch.
  `nsefast version` prints the installed version.
- 22 new unit tests covering all of the above (99 total, still no network).

### Fixed

- DuckDB view registration now inlines the validated parquet glob path
  (DuckDB does not accept prepared parameters alongside `hive_partitioning`).
  Single quotes in the path are SQL-escaped.

## [0.1.0] - 2026-05-06

### Added

- Initial public release.
- Polite HTTP client with warm-up cookie session, retries, and `robots.txt` enforcement.
- Live JSON collectors with full graceful-failure semantics:
  - `deals.bulk_deals(start, end)`, `deals.block_deals(start, end)`
  - `corporate.corporate_announcements(start, end)`, `corporate.corporate_actions(start, end)`
  - `corporate.dividends`, `bonuses`, `splits`, `rights_issues`, `mergers_demergers`, `record_and_ex_dates`
  - `derivatives.option_chain(symbol)`, `option_chain_equity`, `option_chain_index`
  - `indices.all_indices()`, `indices.sector_strength()`, `indices.is_sector_index(name)`
  - `equity.fifty_two_week_high_low()`, `fifty_two_week_high()`, `fifty_two_week_low()`
- Daily archive collectors:
  - `equity.daily_bhavcopy(date)`, `equity.delivery_data(date)`
  - `derivatives.fo_bhavcopy(date)`
  - `master.symbol_master()`
- Polars-first dataframe layer with canonical schemas per collector.
- Parquet canonical storage (`storage.parquet_store`), DuckDB analytics views
  (`storage.duckdb_store`), optional PostgreSQL (`storage.postgres_store`).
- Typer CLI: `nsefast collect …`, `nsefast features swing`, `nsefast export parquet`.
- Optional Rust core (`rust-core/`) exposing `fast_hash`, `dedup`, `snake_case` via PyO3.
- 77 unit tests covering field mapping, alternate field names, malformed payloads,
  network failures, HTTP errors, JSON decode errors, robots.txt blocks, schema
  ordering, chunk-window arithmetic, CE/PE leg flattening, and sector classification.

### Notes

- All public collectors return a Polars DataFrame with the canonical schema on
  **any** failure (network, JSON, malformed payload, polars error, etc.) and
  never raise — pipelines stay crash-proof.
- NSE blocks many datacenter IP ranges; from such hosts, collectors will
  return empty DataFrames rather than crash.
