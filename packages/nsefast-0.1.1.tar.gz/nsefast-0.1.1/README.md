# nsefast

Fast NSE India data collector for **swing trading**, **quant research**, **AI training**, **backtesting**, and **market intelligence**.

> ⚠️ **Ethics & Compliance:** `nsefast` only uses publicly downloadable NSE reports
> and pages allowed by NSE's `robots.txt`. It does **not** bypass logins, captchas,
> Cloudflare, anti-bot systems, or rate limits. Add appropriate delays and use
> responsibly. You are responsible for complying with NSE's terms of service.

## Features

- Polite, retrying HTTP client with `robots.txt` checks
- Modular collectors for **equity**, **derivatives**, **corporate**, **deals**,
  **indices**, **surveillance**, **calendar**, and **master** data
- [Polars](https://pola.rs) for fast dataframe processing
- [Parquet](https://parquet.apache.org/) primary storage, partitioned by dataset/date
- [DuckDB](https://duckdb.org) local analytics layer
- Optional PostgreSQL storage
- Optional Rust core (`rust-core/`) for hashing / dedup / large parsing
- Typer-based CLI

## Install

```bash
pip install nsefast
```

Optional extras:

```bash
pip install "nsefast[pandas]"      # pandas export helpers
pip install "nsefast[postgres]"    # PostgreSQL sink
pip install "nsefast[api]"         # FastAPI server scaffold
pip install "nsefast[dev]"         # pytest, ruff, build, twine
```

For development:

```bash
git clone https://github.com/nikhilshinde/nsefast
cd nsefast
pip install -e ".[dev]"
pytest -q
```

## Quick start

```bash
# Discover all downloadable report links from NSE public pages
nsefast collect-reports

# Run the full scaffold
nsefast collect-all

# Equity bhavcopy for a date
nsefast collect equity-bhavcopy --date 2026-05-07

# Corporate announcements range
nsefast collect corporate-announcements --start 2026-05-01 --end 2026-05-07

# Build swing-trading features
nsefast features swing --date 2026-05-07

# Export a dataset to Parquet
nsefast export parquet --dataset daily_bhavcopy
```

In Python:

```python
from nsefast.collectors.report_links import collect_report_links
from nsefast.storage.parquet_store import save_parquet

df = collect_report_links()  # polars DataFrame
save_parquet(df, dataset="report_links")
```

## Project layout

```text
nsefast/
├── pyproject.toml
├── requirements.txt
├── main.py
├── README.md
│
├── nsefast/
│   ├── config.py          # URLs, headers, paths
│   ├── http_client.py     # session + retries
│   ├── robots.py          # robots.txt checker
│   ├── collectors/        # one module per data domain
│   ├── processing/        # normalize, features, technicals
│   ├── storage/           # parquet, duckdb, postgres
│   └── cli.py             # Typer CLI
│
└── rust-core/             # optional pyo3 module
    ├── Cargo.toml
    └── src/lib.rs
```

## Storage zones

- `data/raw/`     — raw downloads exactly as fetched
- `data/clean/`   — normalized intermediate files
- `data/parquet/` — partitioned Parquet, the canonical store

## Rust core (optional)

The `rust-core/` crate exposes a `nsefast_core` Python module via
[PyO3](https://pyo3.rs/) for CPU-bound work (SHA-256 hashing, dedup,
fast CSV normalization). HTTP scraping stays in Python — it's I/O bound.

Build with [maturin](https://www.maturin.rs/):

```bash
cd rust-core
maturin develop --release
```

## Verify your install

```bash
pip install nsefast
nsefast verify              # offline checks: imports, parquet, duckdb
nsefast verify --network    # also pings NSE warm-up + robots.txt
nsefast version
```

## Cache, logging, partitioning

```bash
# Cache (5-min TTL by default; collectors opt in via cached_get())
nsefast cache stats
nsefast cache clear

# Structured JSON logs (for production / log shippers)
NSEFAST_LOG_FORMAT=json NSEFAST_LOG_LEVEL=INFO nsefast collect bulk-deals --start 2026-04-01 --end 2026-05-07
```

```python
# Hive-partitioned parquet writes
from nsefast.storage.parquet_store import (
    save_parquet_partitioned, read_parquet_partitioned, derive_date_partitions,
)
df = derive_date_partitions(df, "trade_date", parts=("year", "month"))
save_parquet_partitioned(df, dataset="daily_bhavcopy", by=["year", "month"])
# -> data/parquet/daily_bhavcopy/year=2026/month=05/*.parquet

q1 = read_parquet_partitioned("daily_bhavcopy",
                              filters=[("year","==",2026), ("month",">=",4)])

# DuckDB analytics
from nsefast.storage.duckdb_store import (
    connect, register_all, top_gainers, sector_leaderboard,
)
con = connect()
register_all(con)
top_gainers(con, dataset="all_indices", n=10)
sector_leaderboard(con, dataset="sector_strength")
```

## Documentation

- [`docs/USAGE.md`](docs/USAGE.md) — full Python + CLI usage, canonical schemas, polite-use rules
- [`docs/PUBLISHING.md`](docs/PUBLISHING.md) — how to release new versions to PyPI
- [`CHANGELOG.md`](CHANGELOG.md) — version history

## Failure semantics

Every public collector returns a Polars DataFrame with its canonical
schema on **any** failure (invalid input, network error, malformed
payload, polars error, robots block). Collectors **never raise** — your
pipelines stay crash-proof.

## Tests

```bash
pytest -q     # 77 unit tests, no network calls
```

## License

MIT — see [`LICENSE`](LICENSE)
