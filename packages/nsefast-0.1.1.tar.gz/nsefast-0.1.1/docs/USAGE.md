# nsefast — Usage Guide

> Public NSE India data only. Respects `robots.txt`, no anti-bot bypass.

## Install

```bash
pip install nsefast
# with optional extras
pip install "nsefast[pandas,postgres,api]"
```

For local development:

```bash
git clone https://github.com/nikhilshinde/nsefast
cd nsefast
pip install -e ".[dev]"
pytest -q
```

## Failure semantics (read this first)

Every public collector returns a **Polars DataFrame with its canonical
schema** on any failure (invalid input, network exception, HTTP non-200,
JSON decode error, malformed payload, polars construction error, robots
block). Collectors **never raise**. Empty DataFrame ≠ error — it just
means no data for that input.

```python
from nsefast.collectors.deals import bulk_deals
df = bulk_deals("not-a-date", "also-bad")   # logs a warning, returns empty df
assert df.is_empty()
assert df.columns == ["date","symbol","security_name","client_name",
                      "buy_sell","quantity","price","remarks","source_url"]
```

## Quick CLI tour

```bash
# Daily archives
nsefast collect equity-bhavcopy --date 2026-05-07
nsefast collect fo-bhavcopy     --date 2026-05-07
nsefast collect delivery        --date 2026-05-07
nsefast collect symbol-master

# Deals (date-range, 90-day chunked)
nsefast collect bulk-deals  --start 2026-04-01 --end 2026-05-07
nsefast collect block-deals --start 2026-04-01 --end 2026-05-07

# Corporate filings
nsefast collect corporate-announcements --start 2026-04-01 --end 2026-05-07
nsefast collect corporate-actions       --start 2026-04-01 --end 2026-05-07

# Live snapshots
nsefast collect option-chain    --symbol NIFTY
nsefast collect option-chain    --symbol RELIANCE
nsefast collect sector-strength
nsefast collect all-indices
nsefast collect 52w

# Discover all downloadable report URLs
nsefast collect-reports

# Build features
nsefast features swing --date 2026-05-07
```

All commands save partitioned Parquet under `data/parquet/<dataset>/…`.

## Python API

### Daily archives

```python
from nsefast.collectors import equity, derivatives, master

df = equity.daily_bhavcopy("2026-05-07")        # OHLCV per security
df = equity.delivery_data("2026-05-07")         # delivery quantity / %
df = derivatives.fo_bhavcopy("2026-05-07")      # F&O snapshot
df = master.symbol_master()                     # all listed symbols
```

### Date-range JSON collectors (90-day chunked, polite)

```python
from nsefast.collectors.deals import bulk_deals, block_deals
from nsefast.collectors.corporate import (
    corporate_announcements, corporate_actions,
    dividends, bonuses, splits, rights_issues, mergers_demergers,
)

deals = bulk_deals("2026-04-01", "2026-05-07")
ann   = corporate_announcements("2026-04-01", "2026-05-07")
divs  = dividends("2026-04-01", "2026-05-07")        # filtered slice
```

### Live snapshots

```python
from nsefast.collectors.derivatives import option_chain
from nsefast.collectors.indices import all_indices, sector_strength
from nsefast.collectors.equity import (
    fifty_two_week_high_low, fifty_two_week_high, fifty_two_week_low,
)

chain   = option_chain("NIFTY")          # CE & PE flattened, one row per leg
chain_r = option_chain("RELIANCE")       # auto-routes equity vs index endpoint

idx     = all_indices()                  # every index NSE publishes
strong  = sector_strength()              # sector-only, sorted by % change desc

w52     = fifty_two_week_high_low()      # 'category' column = "high" or "low"
highs   = fifty_two_week_high()
lows    = fifty_two_week_low()
```

### Storage

```python
from nsefast.storage.parquet_store import save_parquet, read_parquet

path = save_parquet(df, dataset="bulk_deals", partition="2026-05")
df2  = read_parquet("bulk_deals")

# DuckDB analytics over the parquet lake
from nsefast.storage.duckdb_store import register_view, query
register_view("bulk_deals")
top = query("SELECT symbol, SUM(quantity) AS q FROM bulk_deals "
            "GROUP BY symbol ORDER BY q DESC LIMIT 10")
```

### Optional PostgreSQL sink

```python
# pip install "nsefast[postgres]"
from nsefast.storage.postgres_store import write_dataframe
write_dataframe(df, table="bulk_deals", dsn="postgresql://user:pw@host/db")
```

## Canonical schemas

| Collector | Columns |
|---|---|
| `bulk_deals` / `block_deals` | `date, symbol, security_name, client_name, buy_sell, quantity, price, remarks, source_url` |
| `corporate_announcements` | `date, symbol, company_name, subject, details, attachment_url, source_url` |
| `corporate_actions` | `ex_date, record_date, symbol, company_name, purpose, face_value, source_url` |
| `option_chain*` | `symbol, underlying_value, expiry_date, strike_price, option_type, open_interest, change_in_oi, volume, implied_volatility, last_price, change, bid_qty, bid_price, ask_price, ask_qty, source_url, fetched_at` |
| `all_indices` / `sector_strength` | `index_name, last, change, percent_change, open, day_high, day_low, prev_close, year_high, year_low, advances, declines, unchanged, source_url, fetched_at` |
| `fifty_two_week_high_low` | `symbol, series, company_name, category, last_price, prev_high_low, prev_high_low_date, change, percent_change, source_url, fetched_at` |

## Network notes

- NSE blocks many datacenter IP ranges (AWS, GCP, Replit, etc.) at the
  edge. Run from a residential IP if collectors silently return empty.
- The HTTP client warms up cookies via `nseindia.com` before any
  `/api/...` call — if you build your own session, do the same.
- All endpoints are gated by `robots.txt`. Disallowed paths return empty.

## Polite-use checklist

1. Don't reduce `REQUEST_DELAY_SECONDS` (default in `nsefast.config`).
2. Cache results to Parquet; don't re-fetch the same range repeatedly.
3. Don't run more than one collector instance against NSE concurrently.
4. Comply with NSE's terms of service. You are responsible for usage.
