"""Common technical indicators implemented on Polars DataFrames."""

from __future__ import annotations

import polars as pl


def sma(df: pl.DataFrame, column: str = "close", window: int = 20) -> pl.DataFrame:
    return df.with_columns(pl.col(column).rolling_mean(window).alias(f"sma_{window}"))


def ema(df: pl.DataFrame, column: str = "close", window: int = 20) -> pl.DataFrame:
    return df.with_columns(
        pl.col(column).ewm_mean(span=window, adjust=False).alias(f"ema_{window}")
    )


def rsi(df: pl.DataFrame, column: str = "close", window: int = 14) -> pl.DataFrame:
    delta = pl.col(column).diff()
    gain = pl.when(delta > 0).then(delta).otherwise(0).rolling_mean(window)
    loss = pl.when(delta < 0).then(-delta).otherwise(0).rolling_mean(window)
    rs = gain / loss
    return df.with_columns((100 - (100 / (1 + rs))).alias(f"rsi_{window}"))


def macd(
    df: pl.DataFrame,
    column: str = "close",
    fast: int = 12,
    slow: int = 26,
    signal: int = 9,
) -> pl.DataFrame:
    fast_ema = pl.col(column).ewm_mean(span=fast, adjust=False)
    slow_ema = pl.col(column).ewm_mean(span=slow, adjust=False)
    macd_line = (fast_ema - slow_ema).alias("macd")
    df = df.with_columns(macd_line)
    return df.with_columns(
        pl.col("macd").ewm_mean(span=signal, adjust=False).alias("macd_signal")
    ).with_columns((pl.col("macd") - pl.col("macd_signal")).alias("macd_hist"))
