# This file is part of Torch Lens Maker
# Copyright (C) 2024-present Victor Poughon
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from typing import Any, Self

import torch
import torch.nn as nn
from jaxtyping import Float

from torchlensmaker.core.base_module import BaseModule
from torchlensmaker.core.tensor_manip import expand_bool_tuple, init_param, to_tensor
from torchlensmaker.kinematics.homogeneous_geometry import hom_identity
from torchlensmaker.sequential.model_trace import ModelTrace
from torchlensmaker.sequential.sequential_data import SequentialData
from torchlensmaker.types import (
    HomMatrix,
    ScalarTensor,
    Tf,
)

from .kinematics_kernels import (
    Gap2DKernel,
    Gap3DKernel,
    KinematicChainAppend2DKernel,
    KinematicChainAppend3DKernel,
    Rotate2DKernel,
    RotateX3DKernel,
    RotateY3DKernel,
    RotateZ3DKernel,
    Translate2DKernel,
    Translate3DKernel,
)


class KinematicElement(BaseModule):
    def __init__(self, reversed: bool):
        super().__init__()
        self.reversed = reversed

    def reverse(self) -> Self:
        return self.clone(reversed=not self.reversed)

    def forward(self, fk: Tf) -> Tf:
        raise NotImplementedError

    def trace(self, trace: ModelTrace, key: str, inputs: Any, outputs: Any) -> None:
        trace.add_input_joint(key, inputs)
        trace.add_output_joint(key, outputs)

    def sequential(self, data: SequentialData) -> SequentialData:
        tf_out = self(data.fk)
        return data.replace(fk=tf_out)


class Gap(KinematicElement):
    """
    Translation along the X axis
    Works in both 2D and 3D and shares a single parameter x.
    """

    def __init__(
        self,
        x: float | ScalarTensor | nn.Parameter,
        trainable: bool = False,
        reversed: bool = False,
    ):
        super().__init__(reversed)
        self.x = init_param(self, "x", x, trainable)
        self.kernel_joint2d = Gap2DKernel()
        self.kernel_joint3d = Gap3DKernel()
        self.kernel_fk2d = KinematicChainAppend2DKernel()
        self.kernel_fk3d = KinematicChainAppend3DKernel()

    def clone(self, **overrides: Any) -> Self:
        kwargs: dict[str, Any] = dict(
            x=self.x,
            trainable=self.x.requires_grad,
            reversed=self.reversed,
        )
        return type(self)(**kwargs | overrides)

    def __repr__(self) -> str:
        return f"{self._get_name()}(x={self.x.item()})"

    def forward(self, fk: Tf) -> Tf:
        kernel_joint = self.kernel_joint2d if fk.pdim() == 2 else self.kernel_joint3d
        kernel_fk = self.kernel_fk2d if fk.pdim() == 2 else self.kernel_fk3d
        joint = kernel_joint.apply(self.x)

        if self.reversed:
            joint = joint.flip()

        return kernel_fk.apply(fk, joint)


class Translate2D(KinematicElement):
    def __init__(
        self,
        x: float | ScalarTensor | nn.Parameter = 0.0,
        y: float | ScalarTensor | nn.Parameter = 0.0,
        trainable: bool | tuple[bool, ...] = False,
        reversed: bool = False,
    ):
        super().__init__(reversed)
        xt, yt = expand_bool_tuple(2, trainable)
        self.x = init_param(self, "x", x, xt)
        self.y = init_param(self, "y", y, yt)
        self.kernel_joint = Translate2DKernel()
        self.kernel_fk2d = KinematicChainAppend2DKernel()

    def clone(self, **overrides: Any) -> Self:
        kwargs: dict[str, Any] = dict(
            x=self.x,
            y=self.y,
            trainable=(self.x.requires_grad, self.y.requires_grad),
            reversed=self.reversed,
        )
        return type(self)(**kwargs | overrides)

    def __repr__(self) -> str:
        return f"{self._get_name()}(x={self.x.item()}, y={self.y.item()})"

    def forward(self, fk: Tf) -> Tf:
        joint = self.kernel_joint.apply(self.x, self.y)

        if self.reversed:
            joint = joint.flip()

        return self.kernel_fk2d.apply(fk, joint)


class TranslateVec2D(KinematicElement):
    def __init__(
        self,
        t: list[float] | Float[torch.Tensor, "2"] | nn.Parameter,
        trainable: bool = False,
        reversed: bool = False,
    ):
        super().__init__(reversed)
        self.t = init_param(self, "t", t, trainable)
        self.kernel_joint = Translate2DKernel()
        self.kernel_fk2d = KinematicChainAppend2DKernel()

    def clone(self, **overrides: Any) -> Self:
        kwargs: dict[str, Any] = dict(
            t=self.t,
            trainable=self.t.requires_grad,
            reversed=self.reversed,
        )
        return type(self)(**kwargs | overrides)

    def __repr__(self) -> str:
        return f"{self._get_name()}(t={self.t.tolist()})"

    def forward(self, fk: Tf) -> Tf:
        joint = self.kernel_joint.apply(*torch.unbind(self.t))

        if self.reversed:
            joint = joint.flip()

        return self.kernel_fk2d.apply(fk, joint)


class Translate3D(KinematicElement):
    def __init__(
        self,
        x: float | ScalarTensor | nn.Parameter = 0.0,
        y: float | ScalarTensor | nn.Parameter = 0.0,
        z: float | ScalarTensor | nn.Parameter = 0.0,
        trainable: bool | tuple[bool, ...] = False,
        reversed: bool = False,
    ):
        super().__init__(reversed)
        xt, yt, zt = expand_bool_tuple(3, trainable)
        self.x = init_param(self, "x", x, xt)
        self.y = init_param(self, "y", y, yt)
        self.z = init_param(self, "z", z, zt)
        self.kernel_joint = Translate3DKernel()
        self.kernel_fk3d = KinematicChainAppend3DKernel()

    def clone(self, **overrides: Any) -> Self:
        kwargs: dict[str, Any] = dict(
            x=self.x,
            y=self.y,
            z=self.z,
            trainable=(
                self.x.requires_grad,
                self.y.requires_grad,
                self.z.requires_grad,
            ),
            reversed=self.reversed,
        )
        return type(self)(**kwargs | overrides)

    def __repr__(self) -> str:
        return f"{self._get_name()}(x={self.x.item()}, y={self.y.item()}, z={self.z.item()})"

    def forward(self, fk: Tf) -> Tf:
        joint = self.kernel_joint.apply(self.x, self.y, self.z)

        if self.reversed:
            joint = joint.flip()

        return self.kernel_fk3d.apply(fk, joint)


class TranslateVec3D(KinematicElement):
    def __init__(
        self,
        t: list[float] | Float[torch.Tensor, "3"] | nn.Parameter,
        trainable: bool = False,
        reversed: bool = False,
    ):
        super().__init__(reversed)
        self.t = init_param(self, "t", t, trainable)
        self.kernel_joint = Translate3DKernel()
        self.kernel_fk3d = KinematicChainAppend3DKernel()

    def clone(self, **overrides: Any) -> Self:
        kwargs: dict[str, Any] = dict(
            t=self.t,
            trainable=self.t.requires_grad,
            reversed=self.reversed,
        )
        return type(self)(**kwargs | overrides)

    def __repr__(self) -> str:
        return f"{self._get_name()}(t={self.t.tolist()})"

    def forward(self, fk: Tf) -> Tf:
        joint = self.kernel_joint.apply(*torch.unbind(self.t))

        if self.reversed:
            joint = joint.flip()

        return self.kernel_fk3d.apply(fk, joint)


class Rotate2D(KinematicElement):
    "2D rotation (in degrees)"

    def __init__(
        self,
        theta: float | ScalarTensor | nn.Parameter = 0.0,
        trainable: bool = False,
        reversed: bool = False,
    ):
        super().__init__(reversed)
        self.theta = init_param(self, "theta", theta, trainable)
        self.kernel_joint = Rotate2DKernel()
        self.kernel_fk2d = KinematicChainAppend2DKernel()

    def clone(self, **overrides: Any) -> Self:
        kwargs: dict[str, Any] = dict(
            theta=self.theta,
            trainable=self.theta.requires_grad,
            reversed=self.reversed,
        )
        return type(self)(**kwargs | overrides)

    def __repr__(self) -> str:
        return f"{self._get_name()}(theta={self.theta.item()})"

    def forward(self, fk: Tf) -> Tf:
        joint = self.kernel_joint.apply(self.theta)

        if self.reversed:
            joint = joint.flip()

        return self.kernel_fk2d.apply(fk, joint)


class AbsolutePosition(KinematicElement):
    def __init__(
        self,
        reversed: bool = False,
    ):
        if reversed:
            raise RuntimeError("AbsolutePosition cannot be reversed")
        super().__init__(reversed)

    def clone(self, **overrides: Any) -> Self:
        return type(self)()

    def __repr__(self) -> str:
        return f"{self._get_name()}()"

    def forward(self, fk: Tf) -> Tf:
        return hom_identity(dim=fk.direct.shape[0] - 1)


class AbsolutePosition2D(KinematicElement):
    def __init__(
        self,
        x: float | ScalarTensor | nn.Parameter = 0.0,
        y: float | ScalarTensor | nn.Parameter = 0.0,
        trainable: bool | tuple[bool, ...] = False,
        reversed: bool = False,
    ):
        if reversed:
            raise RuntimeError("AbsolutePosition2D cannot be reversed")
        super().__init__(reversed)
        self.kernel_joint = Translate2DKernel()
        xt, yt = expand_bool_tuple(2, trainable)
        self.x = init_param(self, "x", x, xt)
        self.y = init_param(self, "y", y, yt)

    def clone(self, **overrides: Any) -> Self:
        kwargs: dict[str, Any] = dict(
            x=self.x,
            y=self.y,
            trainable=(self.x.requires_grad, self.y.requires_grad),
        )
        return type(self)(**kwargs | overrides)

    def __repr__(self) -> str:
        return f"{self._get_name()}(x={self.x.item()}, y={self.y.item()})"

    def forward(self, fk: Tf) -> Tf:
        return self.kernel_joint.apply(self.x, self.y)


class AbsolutePosition3D(KinematicElement):
    def __init__(
        self,
        x: float | ScalarTensor | nn.Parameter = 0.0,
        y: float | ScalarTensor | nn.Parameter = 0.0,
        z: float | ScalarTensor | nn.Parameter = 0.0,
        trainable: bool | tuple[bool, ...] = False,
        reversed: bool = False,
    ):
        if reversed:
            raise RuntimeError("AbsolutePosition2D cannot be reversed")
        super().__init__(reversed)
        self.kernel_joint = Translate3DKernel()
        xt, yt, zt = expand_bool_tuple(3, trainable)
        self.x = init_param(self, "x", x, xt)
        self.y = init_param(self, "y", y, yt)
        self.z = init_param(self, "z", z, zt)

    def clone(self, **overrides: Any) -> Self:
        kwargs: dict[str, Any] = dict(
            x=self.x,
            y=self.y,
            z=self.z,
            trainable=(
                self.x.requires_grad,
                self.y.requires_grad,
                self.z.requires_grad,
            ),
        )
        return type(self)(**kwargs | overrides)

    def __repr__(self) -> str:
        return f"{self._get_name()}(x={self.x.item()}, y={self.y.item()}, z={self.z.item()})"

    def forward(self, fk: Tf) -> Tf:
        return self.kernel_joint.apply(self.x, self.y, self.z)


class RotateX(KinematicElement):
    "3D rotation around the X axis, in degrees"

    def __init__(
        self,
        angle: float | ScalarTensor | nn.Parameter,
        trainable: bool = False,
        reversed: bool = False,
    ):
        super().__init__(reversed)
        self.kernel_joint = RotateX3DKernel()
        self.kernel_fk3d = KinematicChainAppend3DKernel()
        self.angle = init_param(self, "angle", angle, trainable)

    def clone(self, **overrides: Any) -> Self:
        kwargs: dict[str, Any] = dict(
            angle=self.angle,
            trainable=self.angle.requires_grad,
            reversed=self.reversed,
        )
        return type(self)(**kwargs | overrides)

    def __repr__(self) -> str:
        return f"{self._get_name()}(angle={self.angle.item()})"

    def forward(self, fk: Tf) -> Tf:
        joint = self.kernel_joint.apply(self.angle)

        if self.reversed:
            joint = joint.flip()

        return self.kernel_fk3d.apply(fk, joint)


class RotateY(KinematicElement):
    "3D rotation around the Y axis, in degrees"

    def __init__(
        self,
        angle: float | ScalarTensor | nn.Parameter,
        trainable: bool = False,
        reversed: bool = False,
    ):
        super().__init__(reversed)
        self.kernel_joint = RotateY3DKernel()
        self.kernel_fk3d = KinematicChainAppend3DKernel()
        self.angle = init_param(self, "angle", angle, trainable)

    def clone(self, **overrides: Any) -> Self:
        kwargs: dict[str, Any] = dict(
            angle=self.angle,
            trainable=self.angle.requires_grad,
            reversed=self.reversed,
        )
        return type(self)(**kwargs | overrides)

    def __repr__(self) -> str:
        return f"{self._get_name()}(angle={self.angle.item()})"

    def forward(self, fk: Tf) -> Tf:
        joint = self.kernel_joint.apply(self.angle)

        if self.reversed:
            joint = joint.flip()

        return self.kernel_fk3d.apply(fk, joint)


class RotateZ(KinematicElement):
    "3D rotation around the Z axis, in degrees"

    def __init__(
        self,
        angle: float | ScalarTensor | nn.Parameter,
        trainable: bool = False,
        reversed: bool = False,
    ):
        super().__init__(reversed)
        self.kernel_joint = RotateZ3DKernel()
        self.kernel_fk3d = KinematicChainAppend3DKernel()
        self.angle = init_param(self, "angle", angle, trainable)

    def clone(self, **overrides: Any) -> Self:
        kwargs: dict[str, Any] = dict(
            angle=self.angle,
            trainable=self.angle.requires_grad,
            reversed=self.reversed,
        )
        return type(self)(**kwargs | overrides)

    def __repr__(self) -> str:
        return f"{self._get_name()}(angle={self.angle.item()})"

    def forward(self, fk: Tf) -> Tf:
        joint = self.kernel_joint.apply(self.angle)

        if self.reversed:
            joint = joint.flip()

        return self.kernel_fk3d.apply(fk, joint)


class RotateMixed(KinematicElement):
    """
    Mixed dimension rotation around the Z axis.

    In 2D, this is a normal 2D rotation (around the inexistant Z axis)
    In 3D, this is a 3D rotation around the Z axis

    This effectively assumes that the 2D version of the model is not an
    arbitrary meridional plane, but the XY plane of the 3D system.
    """

    def __init__(
        self,
        angle: float | ScalarTensor | nn.Parameter,
        trainable: bool = False,
        reversed: bool = False,
    ):
        super().__init__(reversed)
        self.angle = init_param(self, "angle", angle, trainable)
        self.kernel_joint2d = Rotate2DKernel()
        self.kernel_joint3d = RotateZ3DKernel()
        self.kernel_fk2d = KinematicChainAppend2DKernel()
        self.kernel_fk3d = KinematicChainAppend3DKernel()

    def clone(self, **overrides: Any) -> Self:
        kwargs: dict[str, Any] = dict(
            angle=self.angle,
            trainable=(self.angle.requires_grad),
            reversed=self.reversed,
        )
        return type(self)(**kwargs | overrides)

    def __repr__(self) -> str:
        return f"{self._get_name()}(angle={self.angle.item()})"

    def forward(self, fk: Tf) -> Tf:
        if fk.pdim() == 2:
            joint = self.kernel_joint2d.apply(self.angle)
            kernel_fk = self.kernel_fk2d
        else:
            joint = self.kernel_joint3d.apply(self.angle)
            kernel_fk = self.kernel_fk3d

        if self.reversed:
            joint = joint.flip()

        return kernel_fk.apply(fk, joint)


class Translate(KinematicElement):
    """
    Mixed dimension translation
    """

    def __init__(
        self,
        x: float | ScalarTensor | nn.Parameter = 0.0,
        y: float | ScalarTensor | nn.Parameter = 0.0,
        z: float | ScalarTensor | nn.Parameter = 0.0,
        trainable: bool | tuple[bool, ...] = False,
        reversed: bool = False,
    ):
        super().__init__(reversed)
        xt, yt, zt = expand_bool_tuple(3, trainable)
        self.x = init_param(self, "x", x, xt)
        self.y = init_param(self, "y", y, yt)
        self.z = init_param(self, "z", z, zt)
        self.kernel_joint2d = Translate2DKernel()
        self.kernel_joint3d = Translate3DKernel()
        self.kernel_fk2d = KinematicChainAppend2DKernel()
        self.kernel_fk3d = KinematicChainAppend3DKernel()

    def clone(self, **overrides: Any) -> Self:
        kwargs: dict[str, Any] = dict(
            x=self.x,
            y=self.y,
            z=self.z,
            trainable=(
                self.x.requires_grad,
                self.y.requires_grad,
                self.z.requires_grad,
            ),
            reversed=self.reversed,
        )
        return type(self)(**kwargs | overrides)

    def __repr__(self) -> str:
        return f"{self._get_name()}(x={self.x.item()}, y={self.y.item()}, z={self.z.item()})"

    def forward(self, fk: Tf) -> Tf:
        if fk.pdim() == 2:
            joint = self.kernel_joint2d.apply(self.x, self.y)
            kernel_fk = self.kernel_fk2d
        else:
            joint = self.kernel_joint3d.apply(self.x, self.y, self.z)
            kernel_fk = self.kernel_fk3d

        if self.reversed:
            joint = joint.flip()

        return kernel_fk.apply(fk, joint)
