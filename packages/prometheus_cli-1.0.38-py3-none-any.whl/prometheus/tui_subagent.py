"""Round 141: subagent output attribution.

When a cohort/subagent emits text or tool calls, the chat log
prefixes each line with `[<agent_name>]` and indents the body
two columns. Matches Claude Code's pattern.

Pure data layer — the host's chat-log renderer calls
`render_block()` whenever a SubAgentTask emits an event.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Optional


# ---------- attribution renderer ----------


def attribution_tag(agent_name: str, *, fallback: str = "agent") -> str:
    """Round 141: bracketed prefix used by every line of
    subagent output. Falls back when the name is missing."""
    name = (agent_name or "").strip() or fallback
    return f"[{name}]"


def indent_lines(text: str, *, width: int = 2) -> str:
    """Round 141: indent every line by `width` spaces. Empty
    lines stay empty so paragraph breaks render cleanly."""
    if not text:
        return ""
    pad = " " * max(0, width)
    out_lines: list[str] = []
    for line in text.split("\n"):
        if line.strip():
            out_lines.append(pad + line)
        else:
            out_lines.append(line)
    return "\n".join(out_lines)


def render_block(
    *,
    agent_name: str,
    body: str,
    indent: int = 2,
) -> str:
    """Round 141: one indented, attributed block.

    First line gets the `[<agent_name>]` tag; subsequent lines
    are indented with no tag (so a long block reads cleanly).
    """
    if not body:
        return ""
    tag = attribution_tag(agent_name)
    lines = body.split("\n")
    out: list[str] = [f"{tag} {lines[0]}"]
    if len(lines) > 1:
        rest_indent = " " * (len(tag) + 1)
        for line in lines[1:]:
            if line.strip():
                out.append(rest_indent + line)
            else:
                out.append(line)
    return "\n".join(out)


def render_tool_call(
    *,
    agent_name: str,
    tool_name: str,
    detail: str = "",
) -> str:
    """Round 141: one-line attributed tool-call receipt.

    Example:
      [general-purpose] ● Bash(pwd)
    """
    tag = attribution_tag(agent_name)
    inner = f"{tool_name}({detail})" if detail else tool_name
    return f"{tag} ● {inner}"


def render_tool_result(
    *,
    agent_name: str,
    body: str,
    indent: int = 4,
) -> str:
    """Round 141: indented tool result body. Caller has already
    summarized; we just attach the indentation + the `└` glyph
    on the first non-empty line for visual continuity with the
    parent tool-call line."""
    if not body:
        return ""
    pad = " " * max(0, indent)
    out: list[str] = []
    leading_glyph_added = False
    for line in body.split("\n"):
        if line.strip() and not leading_glyph_added:
            out.append(f"{pad[:-2] if pad else ''}└ {line}")
            leading_glyph_added = True
        else:
            out.append(pad + line if line.strip() else "")
    return "\n".join(out)


# ---------- aggregate stream renderer ----------


@dataclass
class SubagentStreamRow:
    """Round 141: one row to render in the chat log from a
    subagent's event stream."""
    kind: str          # "text" / "tool_call" / "tool_result"
    body: str
    tool_name: str = ""
    detail: str = ""


def render_stream(
    agent_name: str,
    rows: Iterable[SubagentStreamRow],
) -> str:
    """Round 141: render a sequence of stream rows from one
    subagent into a single attributed block."""
    out: list[str] = []
    for r in rows:
        if r.kind == "text":
            out.append(render_block(
                agent_name=agent_name, body=r.body,
            ))
        elif r.kind == "tool_call":
            out.append(render_tool_call(
                agent_name=agent_name,
                tool_name=r.tool_name,
                detail=r.detail,
            ))
        elif r.kind == "tool_result":
            out.append(render_tool_result(
                agent_name=agent_name,
                body=r.body,
            ))
    return "\n".join(o for o in out if o)
