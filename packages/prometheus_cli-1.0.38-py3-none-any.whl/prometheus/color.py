"""Round 182: NO_COLOR / FORCE_COLOR / TERM auto-degrade.

The no-color.org spec is a universal CLI convention: when NO_COLOR is
set to any value (even the empty string), tools must disable color
output. FORCE_COLOR is the inverse — set it to any value and tools
must emit color even when piped or redirected. CLICOLOR=0 / CLICOLOR=1
is the older BSD convention, still widely honored.

Pre-R182 Prometheus had zero references to any of these env vars, so
piping output to a file produced literal ANSI escape codes embedded
in the saved log, and accessibility users had no way to silence the
spinner without setting `PROMETHEUS_REDUCED_MOTION=1` (a Prometheus-
native env var screen-reader users wouldn't have heard of).

This module owns the "should we emit color?" decision so callers
don't have to re-implement the precedence rules:

    from prometheus.color import should_use_color, strip_ansi
    if not should_use_color():
        text = strip_ansi(text)

The decision is cached per-process; call `clear_cache()` from tests
that mutate env vars."""
from __future__ import annotations

import os
import re
import sys


# ANSI CSI/OSC matcher. Captures both standard SGR ("\x1b[31m") and
# OSC sequences ("\x1b]8;;url\x07text\x1b]8;;\x07" — terminal links).
_ANSI_RX = re.compile(
    r"\x1b\[[0-?]*[ -/]*[@-~]"  # CSI
    r"|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)"  # OSC
)


_decision_cache: bool | None = None


def clear_cache() -> None:
    """Reset the cached decision. Tests that mutate the relevant env
    vars must call this to force a re-evaluation."""
    global _decision_cache
    _decision_cache = None


def _truthy(val: str | None) -> bool:
    """no-color.org: any value (even empty) means \"on\". So presence
    in the environment is what counts, not the value. We follow that
    convention for NO_COLOR and FORCE_COLOR; CLICOLOR uses the older
    integer convention (0 = off, anything else = on)."""
    return val is not None


def _cli_color_enabled(val: str | None) -> bool | None:
    """CLICOLOR / CLICOLOR_FORCE: integer-ish convention.

    Returns True if explicitly enabled, False if explicitly disabled,
    None if not set."""
    if val is None:
        return None
    s = val.strip().lower()
    if s in ("0", "false", "no", "off", ""):
        return False
    return True


def should_use_color(stream=None) -> bool:
    """Decide whether ANSI colors should be emitted to `stream` (or
    stdout by default).

    Precedence (highest first):
      1. NO_COLOR set         → False    (no-color.org spec)
      2. FORCE_COLOR set      → True     (override piping detection)
      3. CLICOLOR_FORCE set   → True/False (BSD convention)
      4. TERM=dumb            → False    (incapable terminal)
      5. CLICOLOR=0           → False    (BSD opt-out)
      6. stream is not a tty  → False    (piped to file/grep/CI)
      7. otherwise            → True

    The result is cached after the first call. Tests that mutate
    these env vars must call `clear_cache()`."""
    global _decision_cache
    if _decision_cache is not None and stream is None:
        return _decision_cache
    decision = _decide(stream or sys.stdout)
    if stream is None:
        _decision_cache = decision
    return decision


def _decide(stream) -> bool:
    env = os.environ
    # 1. NO_COLOR — highest precedence. Per no-color.org, any value
    #    (including empty string) disables color.
    if "NO_COLOR" in env:
        return False
    # 2. FORCE_COLOR — explicit override of piping detection.
    if "FORCE_COLOR" in env:
        return True
    # 3. CLICOLOR_FORCE — BSD convention to force on.
    forced = _cli_color_enabled(env.get("CLICOLOR_FORCE"))
    if forced is True:
        return True
    if forced is False:
        # CLICOLOR_FORCE=0 doesn't suppress; only NO_COLOR does.
        # Fall through to next check.
        pass
    # 4. TERM=dumb — explicit "I can't render escapes" signal.
    if env.get("TERM", "").lower() == "dumb":
        return False
    # 5. CLICOLOR=0 — opt-out.
    enabled = _cli_color_enabled(env.get("CLICOLOR"))
    if enabled is False:
        return False
    # 6. Piped → no color. Use the stream's isatty() if available.
    isatty = getattr(stream, "isatty", None)
    if callable(isatty):
        try:
            if not isatty():
                return False
        except (OSError, ValueError):
            # Stream may be closed during shutdown — assume not-tty.
            return False
    return True


def strip_ansi(text: str) -> str:
    """Remove ANSI CSI and OSC escape sequences from text. Safe for
    log writes, file persistence, and piped output."""
    return _ANSI_RX.sub("", text)


def colorize_if_enabled(text: str, ansi_prefix: str, ansi_suffix: str = "\x1b[0m") -> str:
    """Wrap `text` in `ansi_prefix` ... `ansi_suffix` only if color
    is currently enabled. When color is disabled, returns the text
    unchanged."""
    if should_use_color():
        return f"{ansi_prefix}{text}{ansi_suffix}"
    return text
