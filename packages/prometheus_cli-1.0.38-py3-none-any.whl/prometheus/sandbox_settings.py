"""Round 148-final-v3: OS-level sandbox settings.

Settings keys (under the `sandbox` namespace):

  enabled                          bool
  autoAllowBashIfSandboxed         bool
  excludedCommands                 list[str]
  filesystem.read                  list[str]   — allowed read paths
  filesystem.write                 list[str]   — allowed write paths
  network.allow                    list[str]   — allowed domains
  network.deny                     list[str]   — denied domains
  enableWeakerNestedSandbox        bool
  enableWeakerNetworkIsolation     bool
  allowUnsandboxedCommands         list[str]

Plus `PROMETHEUS_SANDBOX=1` env override.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any


_TRUTHY = ("1", "true", "yes", "on")


def _b(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in _TRUTHY
    return default


def _list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(s).strip() for s in value if str(s).strip()]


# ---------- env override ----------


def sandbox_env_enabled() -> bool:
    return os.environ.get(
        "PROMETHEUS_SANDBOX", "",
    ).strip().lower() in _TRUTHY


# ---------- schema ----------


@dataclass
class SandboxFilesystem:
    read: list[str] = field(default_factory=list)
    write: list[str] = field(default_factory=list)


@dataclass
class SandboxNetwork:
    allow: list[str] = field(default_factory=list)
    deny: list[str] = field(default_factory=list)


@dataclass
class SandboxConfig:
    enabled: bool = False
    auto_allow_bash_if_sandboxed: bool = False
    excluded_commands: list[str] = field(default_factory=list)
    filesystem: SandboxFilesystem = field(default_factory=SandboxFilesystem)
    network: SandboxNetwork = field(default_factory=SandboxNetwork)
    weaker_nested: bool = False
    weaker_network_isolation: bool = False
    allow_unsandboxed_commands: list[str] = field(default_factory=list)
    # 1.0.3 (CC parity): managed-mode lockdown flags. When True,
    # deny EVERYTHING outside the explicit allow list — even the
    # implicit project-root read access that's otherwise the
    # default. Used by admins to enforce strict sandboxing in
    # corporate environments where the agent must not read or
    # contact anything not explicitly whitelisted.
    allow_managed_read_paths_only: bool = False
    allow_managed_domains_only: bool = False


def resolve_sandbox(setting: Any = None) -> SandboxConfig:
    """Round 148-final-v3: resolve the sandbox config from a
    settings dict. The env override takes precedence on the
    `enabled` field — if `PROMETHEUS_SANDBOX=1` is set, we
    always run sandboxed regardless of settings."""
    s = setting if isinstance(setting, dict) else {}
    fs_raw = s.get("filesystem") or {}
    if not isinstance(fs_raw, dict):
        fs_raw = {}
    net_raw = s.get("network") or {}
    if not isinstance(net_raw, dict):
        net_raw = {}
    return SandboxConfig(
        enabled=sandbox_env_enabled() or _b(s.get("enabled")),
        auto_allow_bash_if_sandboxed=_b(
            s.get("autoAllowBashIfSandboxed"),
        ),
        excluded_commands=_list(s.get("excludedCommands")),
        filesystem=SandboxFilesystem(
            read=_list(fs_raw.get("read")),
            write=_list(fs_raw.get("write")),
        ),
        network=SandboxNetwork(
            allow=_list(net_raw.get("allow")),
            deny=_list(net_raw.get("deny")),
        ),
        weaker_nested=_b(s.get("enableWeakerNestedSandbox")),
        weaker_network_isolation=_b(
            s.get("enableWeakerNetworkIsolation"),
        ),
        allow_unsandboxed_commands=_list(
            s.get("allowUnsandboxedCommands"),
        ),
        allow_managed_read_paths_only=_b(
            s.get("allowManagedReadPathsOnly"),
        ),
        allow_managed_domains_only=_b(
            s.get("allowManagedDomainsOnly"),
        ),
    )


# ---------- decisions ----------


def filesystem_decision(
    path: str, *, op: str, cfg: SandboxConfig,
) -> tuple[bool, str]:
    """Round 148-final-v3 + 1.0.3: deny-by-default when sandboxed.
    Empty allow lists allow nothing — admins must enumerate
    what's permitted.

    1.0.3 (CC parity): `allow_managed_read_paths_only=True`
    forces read-list enforcement even when `cfg.enabled=False`,
    so admins can lock down read access without enabling the
    full sandbox.
    """
    read_locked = cfg.allow_managed_read_paths_only and op == "read"
    if not cfg.enabled and not read_locked:
        return (True, "sandbox off")
    norm = path.replace("\\", "/")
    table = (
        cfg.filesystem.write if op == "write"
        else cfg.filesystem.read
    )
    if not table:
        why = (
            "managed-paths-only with empty allowlist"
            if read_locked else "no allowlist"
        )
        return (False, f"sandbox denies {op}: {why}")
    for prefix in table:
        if norm.startswith(prefix):
            return (True, f"matches {op} allowlist: {prefix}")
    return (False, f"path not in {op} allowlist")


def network_decision(
    domain: str, *, cfg: SandboxConfig,
) -> tuple[bool, str]:
    """Round 148-final-v3 + 1.0.3: allow/deny resolution. Deny wins.

    1.0.3 (CC parity): `allow_managed_domains_only=True` forces
    domain-list enforcement even when `cfg.enabled=False`."""
    domain_locked = cfg.allow_managed_domains_only
    if not cfg.enabled and not domain_locked:
        return (True, "sandbox off")
    d = domain.lower()
    for blocked in cfg.network.deny:
        if d == blocked or d.endswith("." + blocked):
            return (False, f"network deny: {blocked}")
    if not cfg.network.allow:
        why = (
            "managed-domains-only with empty allowlist"
            if domain_locked else "no network allowlist"
        )
        return (False, why)
    for allowed in cfg.network.allow:
        if d == allowed or d.endswith("." + allowed):
            return (True, f"matches allow: {allowed}")
    return (False, "domain not in allowlist")


def bash_decision(
    command: str, *, cfg: SandboxConfig,
) -> tuple[bool, str]:
    """Round 148-final-v3: bash-specific gate. Reads the
    `allowUnsandboxedCommands` + `excludedCommands` lists."""
    if not cfg.enabled:
        return (True, "sandbox off")
    cmd = command.strip()
    if not cmd:
        return (False, "empty command")
    head = cmd.split()[0]
    for entry in cfg.excluded_commands:
        if head == entry or cmd.startswith(entry):
            return (False, f"excluded by sandbox: {entry}")
    for entry in cfg.allow_unsandboxed_commands:
        if head == entry or cmd.startswith(entry):
            return (True, f"allowed unsandboxed: {entry}")
    if cfg.auto_allow_bash_if_sandboxed:
        return (True, "auto-allow inside sandbox")
    return (False, "sandbox blocks bash by default")
