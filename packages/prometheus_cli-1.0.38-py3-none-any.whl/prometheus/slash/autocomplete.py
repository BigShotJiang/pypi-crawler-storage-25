"""Round 115: tab-autocomplete for slash commands.

Given a partial slash command (e.g. `/ses`), return the list of
candidates with their descriptions so the input layer can render
an inline dropdown. Sorted by best-prefix-match → fuzzy-match.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable


@dataclass
class CompletionEntry:
    """One entry the input dropdown can render."""
    name: str          # without the leading `/`
    description: str


def complete(
    typed: str,
    catalogue: Iterable[tuple[str, str]],
    *,
    limit: int = 12,
) -> list[CompletionEntry]:
    """Round 115: rank slash-command candidates against a partial
    user input.

    `typed` is what the user has in the buffer (with or without
    leading `/`). `catalogue` is `[(name, description), ...]` —
    typically `slash_router._cmds.items()`.

    Ranking:
      1. Exact prefix match on the name.
      2. Substring match anywhere in the name.
      3. Substring match in the description.
    """
    raw = typed.lstrip("/").lower().strip()
    cands = [(n.lower(), n, d) for n, d in catalogue]
    cands.sort()
    if not raw:
        return [
            CompletionEntry(name=n, description=d)
            for _, n, d in cands[:limit]
        ]
    prefix: list[CompletionEntry] = []
    substr: list[CompletionEntry] = []
    desc: list[CompletionEntry] = []
    for low, name, description in cands:
        if low.startswith(raw):
            prefix.append(CompletionEntry(name=name, description=description))
        elif raw in low:
            substr.append(CompletionEntry(name=name, description=description))
        elif raw in description.lower():
            desc.append(CompletionEntry(name=name, description=description))
    out = prefix + substr + desc
    return out[:limit]


def format_completion(entry: CompletionEntry, *, width: int = 80) -> str:
    """One-line `name — description` formatted for a dropdown row."""
    n = entry.name
    d = entry.description
    if len(n) + 3 + len(d) > width:
        d = d[: max(0, width - len(n) - 4)] + "…"
    return f"/{n} — {d}"


# ---- Round 170 / B4: terminal-height-aware popup scaling ----


# Documented Claude Code v2.1.132 fix: the popup grows with the
# terminal so users on tall screens don't see the same 3-5
# truncation as users on small ones. Cap at half the height so
# the popup never eats the whole screen, with a minimum visible
# count of 3 (the round-115 default) on tiny terminals.
DEFAULT_MIN_VISIBLE = 3
DEFAULT_MAX_VISIBLE_FRACTION = 0.5  # ½ of terminal height


def visible_window(
    matches: list[CompletionEntry],
    *,
    selected_index: int,
    terminal_height: int,
    min_visible: int = DEFAULT_MIN_VISIBLE,
    max_fraction: float = DEFAULT_MAX_VISIBLE_FRACTION,
) -> tuple[list[CompletionEntry], int]:
    """Round 170 / B4: pick the window of matches the popup
    should show.

    Returns `(window, highlight_offset)`:
      - `window` is the slice of `matches` to render.
      - `highlight_offset` is the index of `selected_index`
        within that slice — the renderer applies the highlight
        to row `highlight_offset` of the popup.

    The window is sized to `min(len(matches), terminal_height //
    2)` (clamped to `min_visible` floor) and centered on the
    selected index. As the user navigates with arrow keys past
    the centre, the window scrolls.

    Pre-fix (round 115), the popup capped at 12 entries
    regardless of terminal height; on a 40-row terminal that
    wasted half the available space, on a 24-row terminal it
    overflowed the screen.
    """
    if not matches:
        return [], 0
    n = len(matches)
    # Compute the cap.
    raw_cap = int(terminal_height * max_fraction)
    cap = max(min_visible, raw_cap)
    window_size = min(n, cap)
    if window_size >= n:
        # Whole list fits — no scrolling.
        return list(matches), max(0, min(n - 1, selected_index))
    # Center the selection in the window.
    half = window_size // 2
    start = selected_index - half
    # Clamp start so the window stays inside the list.
    start = max(0, min(n - window_size, start))
    end = start + window_size
    window = matches[start:end]
    return window, selected_index - start


def render_popup(
    matches: list[CompletionEntry],
    *,
    selected_index: int,
    terminal_height: int,
    width: int = 80,
) -> str:
    """Round 170 / B4: render the popup as plain text. The host
    applies highlight styling to the line at `highlight_offset`."""
    window, highlight = visible_window(
        matches, selected_index=selected_index,
        terminal_height=terminal_height,
    )
    lines: list[str] = []
    for i, entry in enumerate(window):
        marker = "▸" if i == highlight else " "
        lines.append(f"{marker} {format_completion(entry, width=width - 2)}")
    if len(matches) > len(window):
        # Tell the user there's more.
        more = len(matches) - len(window)
        lines.append(f"  …{more} more (continue typing to filter)")
    return "\n".join(lines)
