"""Slash command router.

Each command is a small async coroutine that takes the app and the
remaining argument string. Commands talk to the app directly to keep
state local. Adding a command is one line in build_default_router.
"""
from __future__ import annotations

import asyncio
import json
import os
import platform
import shlex
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Awaitable, Callable, TYPE_CHECKING

from prometheus import __version__ as VERSION
from prometheus.config import FREE_MODELS_PREFERRED, USER_MEMORY
from prometheus.ui.render import error_line, system_dim
from prometheus.ui.theme import AMBER, DIM, INK

if TYPE_CHECKING:
    from prometheus.ui.app import PrometheusApp


CommandFn = Callable[["PrometheusApp", str], Awaitable[None]]


@dataclass
class Command:
    name: str
    summary: str
    fn: CommandFn
    category: str = "meta"


def _suggest_commands(typo: str, names: list[str]) -> list[str]:
    """Round-96.10: deterministic command-aware "did you mean" ranker.

    Returns up to 2 suggestions for a misspelled / mistyped slash
    command, ordered by relevance. Two routing paths:

    1. **Multi-token (path-style) typo** — e.g. `sessions/resum`,
       `session/resume`, `resume/session`. Splits on `/` and
       whitespace, finds the best match per token via prefix-match
       first (`sessions` startswith `session` → `sessions`;
       `resume` startswith `resum` → `resume`), falls back to a
       tight per-token difflib (cutoff 0.6) when no prefix-hit. The
       per-token approach is the only way to surface BOTH commands
       in a paste-mishap like `/sessions/resum` — global difflib on
       the joined string never gets close enough to `resume` to
       cross any sane cutoff.

    2. **Single-token typo** — e.g. `sessons`. Tight global difflib
       at cutoff 0.7 so the obvious correction surfaces alone
       without close-but-different commands sneaking in. The
       earlier 96.9 cutoff of 0.55 let `permissions` slide in for
       `sessons` (ratio 0.55, exactly at the boundary). When two
       candidates pass cutoff but the top one is materially better
       (ratio gap > 0.15), drop the weaker.
    """
    import difflib
    import re as _re_split

    if not typo:
        return []

    tokens = [t for t in _re_split.split(r"[/\s]+", typo) if t]

    # ---- Multi-token (path-style) path ----
    if len(tokens) >= 2:
        suggestions: list[str] = []
        for token in tokens:
            best: str | None = None
            # 1) prefix-match (either direction): `sessions` matches
            #    typed `session` (cmd starts with token) and typed
            #    `sessons` matches `sessions` only weakly — handled
            #    by the difflib leg below.
            prefix_hits = [
                n for n in names
                if n.startswith(token) or token.startswith(n)
            ]
            if prefix_hits:
                # Pick the prefix-hit with the highest ratio so an
                # exact-match wins over a longer-name match.
                prefix_hits.sort(
                    key=lambda n: difflib.SequenceMatcher(
                        None, token, n,
                    ).ratio(),
                    reverse=True,
                )
                best = prefix_hits[0]
            else:
                # 2) per-token difflib at a moderate cutoff. Per-token
                #    matching is more forgiving than the joined-string
                #    approach because each token is short.
                close = difflib.get_close_matches(
                    token, names, n=1, cutoff=0.6,
                )
                if close:
                    best = close[0]
            if best and best not in suggestions:
                suggestions.append(best)
            if len(suggestions) >= 2:
                break
        return suggestions

    # ---- Single-token path ----
    # Tight cutoff so close-but-different commands don't bleed in.
    close = difflib.get_close_matches(typo, names, n=2, cutoff=0.7)
    if len(close) >= 2:
        r0 = difflib.SequenceMatcher(None, typo, close[0]).ratio()
        r1 = difflib.SequenceMatcher(None, typo, close[1]).ratio()
        # If the second match is clearly worse, return only the top
        # one. Avoids "sessons → /sessions or /permissions" where
        # the second candidate is borderline.
        if r0 - r1 > 0.15:
            return [close[0]]
    return close


# Round 96.11: reserved marker text for non-resumable session rows.
# Defined at module scope so the /sessions display + sanitization
# logic can share the exact same string the tests pin.
_EMPTY_SESSION_MARKER = "(empty — not resumable)"


def _is_session_resumable(store: Any, sid: str) -> bool:
    """Round 96.11: shared resumability check.

    Before this round, /sessions decided "resumable?" based on
    count_messages alone, while /resume's no-arg walk additionally
    required find_session_id to resolve and get_messages to return
    a non-empty list. A session whose row was findable by COUNT(*)
    but not by find_session_id (or whose get_messages raised) would
    appear in /sessions as resumable but be silently skipped by
    /resume — the public contradiction the user flagged.

    A session is resumable iff:
      1. count_messages > 0  (cheap COUNT short-circuit)
      2. find_session_id resolves the prefix  (or no resolver exists)
      3. get_messages returns a non-empty list

    Both /sessions (display) and /resume (selection) call this
    helper so they can never disagree.
    """
    if not sid:
        return False
    try:
        if store.count_messages(sid) <= 0:
            return False
    except Exception:
        return False
    try:
        resolved = (
            store.find_session_id(sid)
            if hasattr(store, "find_session_id") else sid
        )
    except Exception:
        return False
    if not resolved:
        return False
    try:
        msgs = store.get_messages(resolved)
    except Exception:
        return False
    return bool(msgs)


class SlashRouter:
    def __init__(self, app: "PrometheusApp") -> None:
        self.app = app
        self.cmds: dict[str, Command] = {}
        # MRU list (most-recent first) — used by the slash popup so
        # commands the user actually uses surface to the top.
        self.recent: list[str] = []

    def add(self, name: str, summary: str, fn: CommandFn, category: str = "meta") -> None:
        self.cmds[name] = Command(name, summary, fn, category)

    def names(self) -> list[str]:
        return sorted(self.cmds.keys())

    def complete(self, prefix: str) -> list[str]:
        """Return command names that start with the given prefix."""
        if prefix.startswith("/"):
            prefix = prefix[1:]
        return [n for n in self.names() if n.startswith(prefix)]

    async def dispatch(self, line: str) -> bool:
        # `/cmd args...`
        app = self.app
        if not line.startswith("/"):
            return False
        rest = line[1:].strip()
        if not rest:
            await self.cmds["help"].fn(app, "")
            return True
        parts = rest.split(maxsplit=1)
        name = parts[0]
        arg = parts[1] if len(parts) > 1 else ""
        cmd = self.cmds.get(name)
        if cmd is None:
            # Round-96.9 / 96.10: command-aware "did you mean"
            # ranking. The earlier 96.9 pass used a single difflib
            # cutoff of 0.55 for the whole typo and a substring
            # fallback that only fired when difflib returned zero.
            # Smoke 5 retest exposed two failures:
            #   /sessons         → suggested /sessions OR /permissions
            #     (permissions slid in at exactly the 0.55 cutoff)
            #   /sessions/resum  → suggested /sessions OR /permissions
            #     (difflib treated the joined string as one token,
            #      never reached the substring fallback that would
            #      have found /resume)
            # The new ranker:
            #   1. Tokenizes on `/` and whitespace.
            #   2. If multi-token (path-style typo), pick the best
            #      match per token via prefix-match first, then
            #      tight difflib (per-token cutoff 0.6). Returns up
            #      to 2 unique tokens' best matches.
            #   3. If single-token, tight difflib at cutoff 0.7 so
            #      trivial typos surface their exact correction
            #      without dragging in close-but-different commands.
            #      If two matches qualify but the top one is clearly
            #      better (ratio gap > 0.15), drop the second.
            suggestions = _suggest_commands(name, self.names())
            if suggestions:
                hint = " or ".join(f"/{s}" for s in suggestions)
                app._log(error_line(
                    f"unknown command: /{name} — did you mean {hint}?"
                ))
            else:
                app._log(error_line(
                    f"unknown command: /{name} — try /help"
                ))
            return True
        # Track recency so the slash popup orders by frequency-of-use.
        if name in self.recent:
            self.recent.remove(name)
        self.recent.insert(0, name)
        self.recent = self.recent[:30]
        try:
            await cmd.fn(app, arg)
        except Exception as e:
            app._log(error_line(f"/{name}: {e}"))
        return True


# ---------- command implementations ----------

CATEGORY_ORDER = ["custom", "session", "code", "files", "web", "memory", "safety", "meta"]
CATEGORY_LABELS = {
    "custom": "Custom (your .prometheus/commands/)",
    "session": "Session",
    "code": "Code",
    "files": "Files",
    "web": "Web",
    "memory": "Memory",
    "safety": "Safety",
    "meta": "Meta",
}

async def cmd_help(app: "PrometheusApp", _arg: str) -> None:
    assert app.slash
    by_cat: dict[str, list[Command]] = {}
    for c in app.slash.cmds.values():
        by_cat.setdefault(c.category, []).append(c)
    # Round 213: capitalized header + parenthesize the placeholder
    # so the user sees `<name>` is a parameter, not a literal. Match
    # Claude Code's "Slash Commands:" header style.
    app._log(system_dim("Slash commands  ·  type /<name> and press enter, or tab to complete"))
    for cat in CATEGORY_ORDER:
        rows = sorted(by_cat.get(cat, []), key=lambda c: c.name)
        if not rows:
            continue
        app._log(system_dim(""))
        app._log(system_dim(f"  {CATEGORY_LABELS[cat]}"))
        for c in rows:
            app._log(system_dim(f"    /{c.name:<16} {c.summary}"))
    app._log(system_dim(""))
    app._log(system_dim("  copy from chat:"))
    app._log(system_dim("    drag the mouse to select, then Ctrl+Shift+C  (Windows / Linux)"))
    app._log(system_dim("    drag the mouse to select, then Cmd+C          (macOS)"))
    app._log(system_dim("    /copy            copy last reply to clipboard"))
    app._log(system_dim("    /copy all        copy entire transcript"))
    app._log(system_dim("    /copy code       copy fenced code block from last reply"))
    app._log(system_dim("    ctrl+y           shortcut for /copy"))
    app._log(system_dim(""))
    app._log(system_dim("  shortcuts:"))
    app._log(system_dim("    shift+tab    cycle permission modes"))
    app._log(system_dim("    ctrl+r       browse prompt history"))
    app._log(system_dim("    ctrl+o       toggle verbose thought markers"))
    app._log(system_dim("    ctrl+y       copy last reply"))
    app._log(system_dim("    up / down    walk through prompt history"))
    app._log(system_dim("    esc esc      rewind last turn"))
    app._log(system_dim("    tab          autocomplete /command or @file"))
    app._log(system_dim("  chat scrollback:"))
    app._log(system_dim("    pageup       scroll chat up one page"))
    app._log(system_dim("    pagedown     scroll chat down one page"))
    app._log(system_dim("    ctrl+home    jump to top of conversation"))
    app._log(system_dim("    ctrl+end     jump to bottom & re-arm auto-scroll"))
    app._log(system_dim("  prefixes:"))
    app._log(system_dim("    /<cmd>       slash command (type / to see menu)"))
    app._log(system_dim("    !<command>   run shell command directly"))
    app._log(system_dim("    @<path>      attach a file (fuzzy picker)"))
    app._log(system_dim("    #<note>      append note to PROMETHEUS.md"))
    app._log(system_dim("    ?            show this help"))


async def cmd_clear(app: "PrometheusApp", _arg: str) -> None:
    app.action_clear()


async def cmd_quit(app: "PrometheusApp", _arg: str) -> None:
    app.exit()


async def cmd_model(app: "PrometheusApp", arg: str) -> None:
    # Round 130/135: model tier system. /model lists aliases +
    # current selection. /model <alias|id> switches mid-session.
    # /model --verbose reveals upstream ids.
    from prometheus.config import public_name
    from prometheus.model_tiers import (
        VALID_ALIASES, list_aliases, resolve_alias,
    )
    verbose = "--verbose" in arg or "-v" in arg
    arg_clean = arg.replace("--verbose", "").replace("-v", "").strip()
    if not arg_clean:
        cur = app.settings.model
        # List the round-135 tier aliases first.
        app._log(system_dim("model aliases:"))
        for alias, target in list_aliases():
            mark = "›" if cur == target or cur == alias else " "
            app._log(system_dim(f"  {mark} {alias:10s}  {target}"))
        app._log(system_dim(""))
        if verbose:
            app._log(system_dim(f"engine: {cur}"))
            app._log(system_dim(f"fast:   {app.settings.fast_model}"))
            app._log(system_dim(f"plan:   {app.settings.planner_model}"))
        else:
            app._log(system_dim(f"engine: {public_name(cur)}"))
            app._log(system_dim(
                "(use /model <alias|id> to switch; "
                "/model --verbose for upstream ids)"
            ))
        return
    permission_mode = (
        app.agent.permission_mode if app.agent else "default"
    )
    resolved = resolve_alias(
        arg_clean, permission_mode=permission_mode,
    )
    app.settings.model = resolved
    if arg_clean.lower() in VALID_ALIASES:
        app._log(system_dim(
            f"engine → {arg_clean.lower()}  ({public_name(resolved)})"
        ))
    else:
        app._log(system_dim(f"engine → {public_name(resolved)}"))
    app._update_status()


async def cmd_stats(app: "PrometheusApp", _arg: str) -> None:
    app._log(system_dim(f"workdir: {app.settings.workdir}"))
    if app.agent:
        app._log(system_dim(f"messages: {len(app.agent.messages)}"))
        app._log(system_dim(f"todos: {len(app.agent.todos)}  snapshots: {len(app.agent.snapshots)}"))
    app._log(system_dim(f"tokens in/out: ↑{app._tokens_total_in} ↓{app._tokens_total_out}"))


async def cmd_permissions(app: "PrometheusApp", arg: str) -> None:
    """Round 104: permissions surface — show mode, recently-denied
    ledger, circuit-breaker state.

    Usage:
      /permissions                — show mode + denied summary
      /permissions <mode>         — switch permission mode
      /permissions denied         — show recently-denied ledger
      /permissions reset-breaker  — clear circuit-breaker counts
    """
    arg = arg.strip()
    if arg in ("denied", "deny", "recent-denied", "recent"):
        ov = getattr(app, "overseer", None)
        if ov is None:
            app._log(system_dim("(no overseer; round 104 ledger unavailable)"))
            return
        if not ov.recently_denied:
            app._log(system_dim("no actions denied this session"))
            return
        app._log(system_dim(f"recently denied ({len(ov.recently_denied)}):"))
        for e in list(reversed(ov.recently_denied))[:20]:
            override = "(can override)" if e.can_override else "(hard deny)"
            app._log(system_dim(
                f"  {e.tool_name}({e.arg_summary[:40]}) "
                f"· {e.tier} {override}"
            ))
            app._log(system_dim(f"    reason: {e.reason}"))
        return
    if arg == "reset-breaker":
        ov = getattr(app, "overseer", None)
        if ov is None:
            app._log(system_dim("(no overseer)"))
            return
        ov.breaker.reset()
        app._log(system_dim("circuit breaker reset"))
        return
    if not arg:
        mode = app.agent.permission_mode if app.agent else "default"
        app._log(system_dim(f"mode: {mode}"))
        app._log(system_dim(
            "modes: default, acceptEdits, plan, skipAll, auto"
        ))
        ov = getattr(app, "overseer", None)
        if ov is not None:
            n = len(ov.recently_denied)
            if n:
                app._log(system_dim(
                    f"  /permissions denied  · {n} action(s) denied this session"
                ))
            if ov.breaker.tripped:
                app._log(system_dim(
                    f"  ⚠ circuit breaker tripped: {ov.breaker.last_trip_reason}"
                ))
                app._log(system_dim(
                    "  /permissions reset-breaker to clear"
                ))
        return
    if app.agent:
        app.agent.set_permission_mode(arg)
    app._update_status()


async def cmd_doctor(app: "PrometheusApp", arg: str) -> None:
    ok = bool(app.settings.api_key)
    app._log(system_dim(f"credentials: {'configured' if ok else 'missing'}"))
    app._log(system_dim(f"runtime: {platform.python_version()}  os: {platform.system()} {platform.release()}"))
    app._log(system_dim(f"local store: {app.session_store.db_path}"))
    if app.client:
        try:
            free = await app.client.free_models()
            app._log(system_dim(f"engine status: ok ({len(free)} engines available)"))
        except Exception as e:
            app._log(error_line(f"engine unreachable"))
            from prometheus import log as _log
            _log.get("slash.doctor").exception("engine unreachable: %s", e)
    # Round 150: pipeline health checks. Always shown unless
    # the user explicitly passes `--no-pipeline`.
    arg_low = (arg or "").strip().lower()
    if "--no-pipeline" not in arg_low:
        try:
            from prometheus.doctor_pipeline import (
                all_checks, render_health,
            )
            checks = all_checks()
            app._log(system_dim(""))
            for line in render_health(checks).splitlines():
                app._log(system_dim(line))
            failed = [c for c in checks if not c.ok]
            if failed:
                app._log(error_line(
                    f"⚠ {len(failed)} pipeline check(s) failing"
                ))
        except Exception as e:
            app._log(error_line(
                f"pipeline health check raised: {e}"
            ))


async def cmd_history(app: "PrometheusApp", _arg: str) -> None:
    app.action_history()


async def cmd_sessions(app: "PrometheusApp", _arg: str) -> None:
    """Round-43: Claude-Code-style session picker.

    Each row shows: time-ago, message count, git branch (if available),
    label, last-user-message preview. Sorted most-recent first.
    """
    import time as _t, subprocess as _sp
    from pathlib import Path as _P
    rows = app.session_store.list_sessions(limit=15)
    app._log(system_dim(f"recent sessions ({len(rows)}) — /resume <id> to continue:"))
    if not rows:
        app._log(system_dim("  (none)"))
        return
    now = _t.time()

    def _ago(ts: float) -> str:
        d = max(0, now - ts)
        if d < 60: return f"{int(d)}s ago"
        if d < 3600: return f"{int(d / 60)}m ago"
        if d < 86400: return f"{int(d / 3600)}h ago"
        return f"{int(d / 86400)}d ago"

    def _branch_for(workdir: str) -> str:
        try:
            p = _P(workdir or "")
            if not p.exists():
                return ""
            r = _sp.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                cwd=str(p), capture_output=True, text=True, timeout=2,
            )
            return r.stdout.strip() if r.returncode == 0 else ""
        except Exception:
            return ""

    for r in rows:
        ago = _ago(r["started_at"])
        sid = r["id"][:8]
        label = (r.get("label") or "").strip()
        msg_count = app.session_store.count_messages(r["id"])
        # Round 96.11: classify resumability via the shared helper so
        # /sessions display and /resume selection can never disagree.
        # Smoke 5 retest exposed a row that read
        #   `2 msgs · (empty — not resumable)`
        # — the count-based branch added "2 msgs" while the row's
        # last_user_message happened to be the literal marker string,
        # which then got appended as the preview. Both contracts are
        # now enforced at this layer.
        resumable = _is_session_resumable(app.session_store, r["id"])
        branch = _branch_for(r.get("workdir", ""))
        # Format: "10m ago  3df4da1c  on main  · 7 msgs · fix the failing tests"
        parts = [f"{ago:>9}", sid]
        if branch:
            parts.append(f"on {branch}")
        if not resumable:
            # Single source of truth for non-resumable rows: ONLY the
            # marker. No msg-count, no label, no preview — those just
            # add noise to a row the user can't act on.
            parts.append(_EMPTY_SESSION_MARKER)
        else:
            parts.append(
                f"{msg_count} msg{'s' if msg_count != 1 else ''}"
            )
            if label and label != sid:
                parts.append(label[:30])
            # Round 96.11: sanitize the preview so a stored user
            # message whose text happens to contain our reserved
            # marker can't be rendered back as if we put it there.
            # The marker is a render-time decoration of empty rows —
            # never a value that should appear next to "X msgs".
            last_user = app.session_store.last_user_message(r["id"])
            last_user_preview = last_user[:60].replace("\n", " ").strip()
            if len(last_user) > 60:
                last_user_preview += "…"
            if (
                last_user_preview
                and _EMPTY_SESSION_MARKER not in last_user_preview
            ):
                parts.append(last_user_preview)
        app._log(system_dim("  " + "  ·  ".join(parts)))


def _trim_resumed_messages_for_active_context(
    messages: list[dict], keep_last: int = 2,
) -> int:
    """Round-96.2: trim resumed-session active context.

    Pre-Round-96 sessions stored full bash stdout in tool messages
    (multi-KB warning blocks, raw pytest progress dumps). When a user
    runs /resume on those sessions today, the bloat carries forward
    into active context — which is exactly the "1.4m HUD after one
    run" failure on Round-96.1's smoke 4 retest.

    Strategy: walk every tool message, and for any whose content
    exceeds 1500 chars, replace it with a head+tail summary. The
    most recent `keep_last` tool messages are left intact in case
    the next-turn LLM call needs full fidelity for them. tool_call_id
    + name + role are always preserved so OpenAI's pairing constraint
    holds.

    Returns the number of messages trimmed.
    """
    tool_idxs = [
        i for i, m in enumerate(messages)
        if isinstance(m, dict) and m.get("role") == "tool"
    ]
    if len(tool_idxs) <= keep_last:
        return 0
    n_trimmed = 0
    cutoff_idxs = tool_idxs[:-keep_last] if keep_last > 0 else tool_idxs
    for i in cutoff_idxs:
        m = messages[i]
        content = m.get("content")
        if not isinstance(content, str):
            continue
        if len(content) <= 1500:
            continue
        head_chars = 600
        tail_chars = 600
        truncated_n = len(content) - head_chars - tail_chars
        m["content"] = (
            content[:head_chars]
            + f"\n…[{truncated_n} chars truncated on resume — "
            + "use /details last to recover from session disk log]…\n"
            + content[-tail_chars:]
        )
        n_trimmed += 1
    return n_trimmed


async def cmd_resume(app: "PrometheusApp", arg: str) -> None:
    sid = arg.strip()
    if not sid:
        # Round-95 turn-6 / Round-96.9: `/resume` with no arg picks
        # the most-recent OTHER session that's actually resumable.
        # Smoke 5 retest bug: the prior implementation grabbed the
        # first non-current row from list_sessions and announced
        # "resuming most-recent session X" *before* validating that
        # the session actually had any messages. When a stale 0-msg
        # session sat at the top of the list, the user saw:
        #   resuming most-recent session 9a544051 ...
        #   no session with id starting with 9a544051-aea1-4bcc-...
        # Now we walk the list looking for the first session that:
        #   - isn't the current one
        #   - has count_messages > 0
        #   - resolves cleanly via find_session_id
        #   - returns at least one message via get_messages
        # Only THEN do we announce the resume. If nothing qualifies,
        # we surface a clean message and return without trying.
        rows = app.session_store.list_sessions(limit=20)
        chosen_full: str | None = None
        chosen_msgs: list[dict] | None = None
        for r in rows:
            rid = (r.get("id") or "").strip()
            if not rid or rid == app.session_id:
                continue
            # Round 96.11: same resumability predicate /sessions uses
            # to classify rows. If the helper says no, /sessions will
            # render "(empty — not resumable)" — and /resume must
            # likewise skip. They can never disagree on the same id.
            if not _is_session_resumable(app.session_store, rid):
                continue
            # Helper passed → resolve + fetch for the announce. The
            # helper already paid for these calls once; the second
            # call here is the one we keep around for the resume.
            try:
                resolved = (
                    app.session_store.find_session_id(rid)
                    if hasattr(app.session_store, "find_session_id")
                    else rid
                )
                candidate_msgs = app.session_store.get_messages(resolved)
            except Exception:
                continue
            if not resolved or not candidate_msgs:
                continue
            chosen_full = resolved
            chosen_msgs = candidate_msgs
            break
        if not chosen_full or not chosen_msgs:
            app._log(system_dim(
                "No previous resumable session found. "
                "Use /sessions to browse."
            ))
            return
        sid = chosen_full
        msgs = chosen_msgs
        app._log(system_dim(
            f"resuming most-recent session {sid[:8]}  ·  "
            f"use /resume <id> to target a specific one, "
            f"/sessions to browse"
        ))
    else:
        # Explicit /resume <id> path — resolve 8-char prefixes (the
        # form displayed by /sessions + welcome card) to the full
        # uuid before querying. Without this, /resume <prefix> always
        # failed with "no session with id" — the displayed id
        # couldn't actually be used to resume.
        full_id = app.session_store.find_session_id(sid) if hasattr(
            app.session_store, "find_session_id"
        ) else None
        if full_id:
            sid = full_id
        msgs = app.session_store.get_messages(sid)
        if not msgs:
            app._log(error_line(f"no session with id starting with {sid}"))
            return
    app.action_clear()
    # Important: action_clear minted a new session_id. Switch back to
    # the resumed one so audit / persistence stay attached to it.
    app.session_id = sid
    if app.agent:
        app.agent.session_id = sid
        # Drop any historical system message — it was built against the
        # ORIGINAL workdir/tools/permission state. We rebuild a fresh
        # system prompt below using the current environment so resumed
        # sessions don't operate against stale context (audit P0:
        # without this, /resume in a new workdir uses the OLD
        # PROMETHEUS.md, OLD tool list, OLD permission mode hint).
        for m in msgs:
            if m.get("role") == "system":
                continue
            app.agent.messages.append({"role": m["role"], "content": m["content"]})
        # Drop the trailing assistant message if it had tool_calls but
        # no matching tool messages followed — that signals an
        # interrupted turn (DB write failed mid-tool, or the app
        # exited mid-stream). The model errors with "tool_call_id
        # without preceding response" if we leave the orphan.
        # Simple heuristic: pop assistant messages that came after the
        # last user message AND haven't been followed by a tool reply.
        msg_list = app.agent.messages
        i = len(msg_list) - 1
        while i >= 0 and msg_list[i].get("role") in ("assistant", "tool"):
            # Count tool_calls vs tool replies in this trailing run.
            block = msg_list[i:]
            tool_calls_in_block = 0
            tool_replies_in_block = 0
            for m in block:
                if m.get("role") == "assistant":
                    # tool_calls aren't persisted to the DB right now
                    # (only role+content), so any trailing assistant is
                    # safe content-only. Don't truncate it.
                    pass
                elif m.get("role") == "tool":
                    tool_replies_in_block += 1
            # No way to detect orphan tool_calls without persisting them
            # — for now leave the messages as-is; the assistant message
            # rebuilt by the model on next turn will overwrite history
            # naturally if it doesn't match tool_call_ids.
            break
        # Round-19: prefer the round-17 state.json snapshot when it
        # exists. The chat-log path above rebuilds messages without
        # tool_calls / metadata, but state.json has the exact in-memory
        # buffer including pending tool turns. If state.json is fresher
        # than the last DB message, swap in its messages over our
        # chat-log reconstruction.
        try:
            state = app.session_store.load_state(sid)
            if state and isinstance(state.get("messages"), list):
                # Replace the reconstructed messages with the in-memory
                # snapshot — same order, includes tool_calls, image
                # carrier flags, etc.
                app.agent.messages = list(state["messages"])
                if isinstance(state.get("todos"), list):
                    app.agent.todos.clear()
                    app.agent.todos.extend(state["todos"])
                pm = state.get("permission_mode")
                if isinstance(pm, str) and pm:
                    app.agent.permission_mode = pm
                # Round-96.2: trim resumed-session bloat. Pre-Round-96
                # snapshots can contain raw bash output (multi-KB
                # warning blocks, full pytest stdout) that today's
                # truncator would have collapsed at append time. Run
                # the same compactor over restored messages so the
                # active context starts clean. The compaction here
                # uses a generic head/tail truncation for run_bash
                # tool messages — we don't have the per-tc-id compact
                # forms restored, but we can still drop the bulk.
                trimmed = _trim_resumed_messages_for_active_context(
                    app.agent.messages,
                )
                app._log(system_dim(
                    f"  (restored agent buffer from state.json — "
                    f"{len(state['messages'])} messages, "
                    f"{trimmed} compacted on resume)"
                ))
        except Exception:
            pass
        # Rebuild the system prompt for the CURRENT environment.
        app.agent._ensure_system()
        # Re-hydrate the persisted task list (todo_write writes to
        # .prometheus/tasks/<sid>.json). Without this, /resume loses
        # the prior plan and the model thinks it's starting fresh.
        try:
            from prometheus.tools.todo import load_persisted_todos
            persisted = load_persisted_todos(app.settings.workdir, sid)
            if persisted:
                app.agent.todos.clear()
                app.agent.todos.extend(persisted)
                # Push to the TodoBar widget so the user sees the plan land.
                try:
                    tb = app.query_one("#todo-bar")
                    tb.todos = list(persisted)
                except Exception:
                    pass
        except Exception:
            pass
    app._log(system_dim(f"resumed session {sid[:8]}  messages={len(msgs)}"))


async def cmd_rename(app: "PrometheusApp", arg: str) -> None:
    if not arg:
        app._log(error_line("usage: /rename <label>"))
        return
    label = arg.strip()
    app.session_store.rename(app.session_id, label)
    app._session_label = label
    app._update_status()
    app._log(system_dim(f"session renamed → {label}"))


async def cmd_compact(app: "PrometheusApp", _arg: str) -> None:
    if not app.agent:
        return
    msgs = app.agent.messages
    if len(msgs) < 6:
        app._log(system_dim("nothing to compact"))
        return
    head = msgs[:1]  # system
    tail = msgs[-4:]
    summary_in = "\n".join(f"{m.get('role')}: {str(m.get('content',''))[:200]}" for m in msgs[1:-4])
    if app.client is None:
        return
    res = await app.client.collect(
        app.settings.fast_model,
        messages=[
            {"role": "system", "content": "Summarize the conversation below in a single short paragraph. Keep file/function/error names exactly. No preamble."},
            {"role": "user", "content": summary_in},
        ],
        fallback_models=FREE_MODELS_PREFERRED,
    )
    summary_msg = {"role": "system", "content": f"[compacted earlier turns]\n{res.text}"}
    app.agent.messages = head + [summary_msg] + tail
    app._log(system_dim(f"compacted: {len(msgs)} → {len(app.agent.messages)} messages"))
    app._update_status()


async def cmd_new(app: "PrometheusApp", _arg: str) -> None:
    app.action_clear()


async def cmd_diff(app: "PrometheusApp", arg: str) -> None:
    """Show this session's file changes as unified diffs.

    /diff               per-turn diffs from snapshots (no git needed)
    /diff git           full `git diff HEAD` for the workdir
    /diff stat          `git diff --stat HEAD`
    """
    sub = arg.strip().lower()
    if sub in ("git", "stat"):
        tool = app.registry.get("run_bash")
        if not tool:
            return
        ctx = app._make_ctx_for_direct_tool()
        cmd = "git diff HEAD" if sub == "git" else "git diff --stat HEAD"
        res = await tool.execute({"command": cmd, "description": "diff"}, ctx)
        from prometheus.ui.render import expanded_body, receipt_summary_line
        line_count = (res.output or "").count("\n") + 1
        app._log(receipt_summary_line(f"Bash $ {cmd}", res.summary, line_count, error=res.error))
        app._log(expanded_body(res))
        return

    # Default: per-turn diffs collected from this session's snapshots.
    if not app.agent or not app.agent.snapshots:
        app._log(system_dim("no file changes this session"))
        return
    import difflib
    from collections import defaultdict
    from prometheus.ui.render import expanded_body, receipt_summary_line
    by_path: dict[str, list[dict]] = defaultdict(list)
    for snap in app.agent.snapshots:
        by_path[snap["path"]].append(snap)
    app._log(system_dim(f"changes this session — {len(by_path)} file(s):"))
    for path, snaps in by_path.items():
        first_before = snaps[0].get("before") or ""
        last_after = snaps[-1].get("after") or ""
        if first_before == last_after:
            continue
        diff = list(difflib.unified_diff(
            first_before.splitlines(),
            last_after.splitlines(),
            fromfile=f"a/{path}",
            tofile=f"b/{path}",
            n=2, lineterm="",
        ))
        added = sum(1 for line in diff if line.startswith("+") and not line.startswith("+++"))
        removed = sum(1 for line in diff if line.startswith("-") and not line.startswith("---"))
        from prometheus.tools.base import ToolResult
        body = "\n".join(diff[:120])
        if len(diff) > 120:
            body += f"\n… ({len(diff) - 120} more diff lines)"
        rr = ToolResult(output=body, summary=f"+{added} −{removed}")
        app._log(receipt_summary_line(f"Diff {path}", rr.summary, len(diff)))
        app._log(expanded_body(rr))


async def cmd_run(app: "PrometheusApp", arg: str) -> None:
    if not arg:
        app._log(error_line("usage: /run <command>"))
        return
    await app._exec_bang(arg)


async def cmd_git(app: "PrometheusApp", arg: str) -> None:
    """Convenience shell-out for git. `/git` (no arg) → `git status`,
    otherwise `/git log -n 5` → `git log -n 5`. Faster than typing `!git ...`."""
    sub = arg.strip() or "status"
    await app._exec_bang(f"git {sub}")


async def cmd_status(app: "PrometheusApp", _arg: str) -> None:
    """One-shot project status: git branch, staged/unstaged counts,
    last commit, mode, todos. Designed to be the first thing power
    users hit after /resume to get oriented."""
    import subprocess
    workdir = str(app.settings.workdir)
    def _run(cmd: list[str]) -> str:
        try:
            r = subprocess.run(cmd, cwd=workdir, capture_output=True,
                               text=True, timeout=5)
            return (r.stdout or "").strip()
        except Exception:
            return ""
    branch = _run(["git", "rev-parse", "--abbrev-ref", "HEAD"]) or "(no git)"
    last_commit = _run(["git", "log", "-1", "--format=%h %s"]) or "(no commits)"
    porcelain = _run(["git", "status", "--porcelain"]).splitlines()
    staged = sum(1 for l in porcelain if l[:1] not in (" ", "?"))
    unstaged = sum(1 for l in porcelain if l[1:2] != " " and l[:1] != "?")
    untracked = sum(1 for l in porcelain if l.startswith("??"))
    mode = app.agent.permission_mode if app.agent else "default"
    todos = len(app.agent.todos) if app.agent else 0
    todos_done = sum(1 for t in (app.agent.todos if app.agent else [])
                     if t.get("status") == "completed")
    app._log(system_dim(f"workdir:  {workdir}"))
    app._log(system_dim(f"branch:   {branch}"))
    app._log(system_dim(f"last:     {last_commit}"))
    app._log(system_dim(
        f"changes:  {staged} staged · {unstaged} unstaged · {untracked} untracked"
    ))
    app._log(system_dim(f"mode:     {mode}"))
    if todos:
        app._log(system_dim(f"todos:    {todos_done}/{todos} done"))


async def cmd_tree(app: "PrometheusApp", arg: str) -> None:
    """Compact directory tree (3 levels deep, gitignore-respecting)."""
    from prometheus.tools.ignore import GitIgnore
    from pathlib import Path as _P
    root = _P(arg.strip()) if arg.strip() else app.settings.workdir
    if not root.is_absolute():
        root = (app.settings.workdir / root).resolve()
    if not root.exists() or not root.is_dir():
        app._log(error_line(f"not a directory: {root}"))
        return
    gi = GitIgnore.for_workdir(app.settings.workdir)
    rows: list[str] = [f"{root.name}/"]
    MAX_DEPTH = 3
    MAX_ROWS = 200
    def _walk(d: _P, prefix: str, depth: int) -> None:
        if depth > MAX_DEPTH or len(rows) >= MAX_ROWS:
            return
        try:
            kids = sorted(d.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
        except OSError:
            return
        kids = [k for k in kids if not gi.is_ignored(k) and not k.name.startswith(".")]
        for i, k in enumerate(kids):
            if len(rows) >= MAX_ROWS:
                rows.append(f"{prefix}…")
                return
            last = (i == len(kids) - 1)
            connector = "└── " if last else "├── "
            display = k.name + ("/" if k.is_dir() else "")
            rows.append(f"{prefix}{connector}{display}")
            if k.is_dir():
                _walk(k, prefix + ("    " if last else "│   "), depth + 1)
    _walk(root, "", 1)
    for line in rows:
        app._log(system_dim(line))


def _detect_runner(workdir: Path, kind: str) -> str | None:
    """Detect which lint/test/format command this project actually uses.

    Inspects pyproject.toml / package.json / Cargo.toml / go.mod and
    returns the most likely command. Returning None means "we don't
    know — ask the user". This is what makes /lint, /test, /format
    Just Work without per-project config.
    """
    files = {f.name: f for f in workdir.iterdir() if f.is_file()}
    if "package.json" in files:
        try:
            import json as _json
            data = _json.loads(files["package.json"].read_text(encoding="utf-8"))
            scripts = (data.get("scripts") or {}) if isinstance(data, dict) else {}
            preferred = {
                "lint":   ["lint", "eslint", "lint:check"],
                "test":   ["test", "test:unit", "test:ci"],
                "format": ["format", "fmt", "prettier"],
            }[kind]
            for name in preferred:
                if name in scripts:
                    return f"npm run {name}"
        except Exception:
            pass
    if "pyproject.toml" in files:
        if kind == "lint":
            return "ruff check ."
        if kind == "test":
            return "pytest -q"
        if kind == "format":
            return "ruff format ."
    if "Cargo.toml" in files:
        return {"lint": "cargo clippy", "test": "cargo test",
                "format": "cargo fmt"}[kind]
    if "go.mod" in files:
        return {"lint": "go vet ./...", "test": "go test ./...",
                "format": "gofmt -w ."}[kind]
    return None


async def cmd_lint(app: "PrometheusApp", arg: str) -> None:
    cmd = arg.strip() or _detect_runner(app.settings.workdir, "lint")
    if not cmd:
        app._log(error_line("could not auto-detect linter — try: /lint <command>"))
        return
    await app._exec_bang(cmd)


async def cmd_test(app: "PrometheusApp", arg: str) -> None:
    cmd = arg.strip() or _detect_runner(app.settings.workdir, "test")
    if not cmd:
        app._log(error_line("could not auto-detect test runner — try: /test <command>"))
        return
    await app._exec_bang(cmd)


async def cmd_format(app: "PrometheusApp", arg: str) -> None:
    cmd = arg.strip() or _detect_runner(app.settings.workdir, "format")
    if not cmd:
        app._log(error_line("could not auto-detect formatter — try: /format <command>"))
        return
    await app._exec_bang(cmd)


async def cmd_search(app: "PrometheusApp", arg: str) -> None:
    if not arg:
        app._log(error_line("usage: /search <query>"))
        return
    tool = app.registry.get("web_search")
    if not tool:
        return
    ctx = app._make_ctx_for_direct_tool()
    res = await tool.execute({"query": arg}, ctx)
    from prometheus.ui.render import expanded_body, receipt_summary_line
    line_count = (res.output or "").count("\n") + 1
    label = f'Searched "{arg[:60]}"'
    app._log(receipt_summary_line(label, res.summary, line_count, error=res.error))
    app._log(expanded_body(res))
    app._remember_result(label, res)


async def cmd_browse(app: "PrometheusApp", arg: str) -> None:
    if not arg:
        app._log(error_line("usage: /browse <url>"))
        return
    tool = app.registry.get("web_fetch")
    if not tool:
        return
    ctx = app._make_ctx_for_direct_tool()
    res = await tool.execute({"url": arg.strip()}, ctx)
    from prometheus.ui.render import receipt_summary_line
    line_count = (res.output or "").count("\n") + 1
    label = f"Fetched {arg.strip()[:80]}"
    app._log(receipt_summary_line(label, res.summary, line_count, error=res.error))
    app._remember_result(label, res)


async def cmd_index(app: "PrometheusApp", _arg: str) -> None:
    # Quick repo summary using the built-in tools.
    tool = app.registry.get("glob_files")
    if not tool:
        return
    ctx = app._make_ctx_for_direct_tool()
    res = await tool.execute({"pattern": "**/*", "limit": 1500}, ctx)
    files = [l for l in (res.output or "").splitlines() if l]
    by_ext: dict[str, int] = {}
    for f in files:
        ext = Path(f).suffix.lower() or "(no ext)"
        by_ext[ext] = by_ext.get(ext, 0) + 1
    top = sorted(by_ext.items(), key=lambda kv: -kv[1])[:15]
    app._log(system_dim(f"indexed {len(files)} files"))
    for ext, n in top:
        app._log(system_dim(f"  {ext:<10} {n}"))


async def cmd_init(app: "PrometheusApp", arg: str) -> None:
    """Round 98: scan the workdir, generate a tailored Charter
    draft, preview it, and write on confirmation.

    Usage:
      /init           — scan + show preview, ask before writing
      /init --force   — overwrite an existing PROMETHEUS.md
      /init --dry-run — show what WOULD be written, don't write
      /init --print   — print the draft to chat without writing
    """
    from prometheus.agent.charter_init import generate_charter
    args = arg.strip().split()
    force = "--force" in args
    dry_run = "--dry-run" in args
    print_only = "--print" in args
    target = app.settings.workdir / "PROMETHEUS.md"
    if target.exists() and not (force or dry_run or print_only):
        app._log(system_dim(f"PROMETHEUS.md already exists at {target}"))
        app._log(system_dim(
            "  re-scan + overwrite: /init --force   "
            "(or /init --print to preview)"
        ))
        return
    draft, scan = generate_charter(app.settings.workdir)
    # Detection summary so the user sees what /init found.
    summary_parts: list[str] = []
    if scan.languages:
        summary_parts.append(f"languages={','.join(scan.languages)}")
    if scan.frameworks:
        summary_parts.append(
            f"frameworks={','.join(scan.frameworks[:5])}"
        )
    if scan.test_commands:
        summary_parts.append(
            f"tests=[{', '.join(scan.test_commands[:3])}]"
        )
    if scan.has_dockerfile:
        summary_parts.append("docker=yes")
    if scan.has_ci:
        summary_parts.append("ci=yes")
    summary = " · ".join(summary_parts) if summary_parts else "(empty workdir)"
    app._log(system_dim(f"/init scan: {summary}"))
    app._log(system_dim(""))
    # Preview the draft inline.
    for line in draft.splitlines():
        app._log(system_dim(line))
    app._log(system_dim(""))
    if print_only:
        app._log(system_dim("(--print: not written)"))
        return
    if dry_run:
        app._log(system_dim(
            f"--dry-run: would write {len(draft)} chars to {target}"
        ))
        return
    if target.exists() and force:
        app._log(system_dim(
            f"overwriting existing {target} (--force)"
        ))
    try:
        target.write_text(draft, encoding="utf-8")
    except OSError as e:
        app._log(error_line(f"could not write {target}: {e}"))
        return
    app._log(system_dim(
        f"created {target} ({len(draft)} chars). Edit to taste; "
        f"PrometheUS reloads it on the next turn."
    ))


async def cmd_learn(app: "PrometheusApp", arg: str) -> None:
    if not arg:
        app._log(error_line("usage: /learn <preference text>"))
        return
    USER_MEMORY.parent.mkdir(parents=True, exist_ok=True)
    line = f"- {arg.strip()}\n"
    if USER_MEMORY.exists():
        with USER_MEMORY.open("a", encoding="utf-8") as f:
            f.write(line)
    else:
        USER_MEMORY.write_text("# user preferences\n" + line, encoding="utf-8")
    app._log(system_dim(f"saved → {USER_MEMORY}"))


async def cmd_version(app: "PrometheusApp", _arg: str) -> None:
    app._log(system_dim(f"PrometheUS {VERSION}"))


async def cmd_config(app: "PrometheusApp", _arg: str) -> None:
    from prometheus.config import public_name
    s = app.settings
    app._log(system_dim(f"engine: {public_name(s.model)}"))
    app._log(system_dim(f"max iterations: {s.max_iterations}"))
    app._log(system_dim(f"workdir: {s.workdir}"))
    app._log(system_dim("(/model --verbose for engine details)"))


async def cmd_cost(app: "PrometheusApp", _arg: str) -> None:
    # Live USD total — accumulated from each turn's `usage.cost` field.
    # Free engines report 0; paid engines (if the user has switched via
    # /model) report real spend. Hardcoding $0.00 lied to paid users
    # and was a P0 audit finding (Cline shipped spending limits in 3.78
    # specifically because the major terminal agents lack visible cost tracking).
    cost = float(getattr(app, "_cost_total_usd", 0.0) or 0.0)
    if cost == 0.0:
        app._log(system_dim("cost: $0.00  (free tier)"))
    elif cost < 0.01:
        app._log(system_dim(f"cost: <$0.01  (${cost:.4f})"))
    else:
        app._log(system_dim(f"cost: ${cost:.4f}"))
    app._log(system_dim(f"tokens: ↑{app._tokens_total_in} ↓{app._tokens_total_out}"))
    # Spending-limit display. Soft caps configured via env or settings.
    # When the running total crosses a threshold, the next turn shows
    # an inline warning (handled in _drive_agent). /cost surfaces the
    # current limit so users know what's set.
    daily = float(os.getenv("PROMETHEUS_DAILY_USD_LIMIT", "0") or 0)
    if daily > 0:
        pct = int(min(100, cost * 100 / daily)) if daily else 0
        app._log(system_dim(f"daily limit: ${daily:.2f}  (used {pct}%)"))
    # Round 137: per-tool call counts so users can see *where*
    # spend is going. Local — no API call.
    try:
        from prometheus.session_stats import (
            compute_cost_breakdown, render_cost,
        )
        if app.agent and getattr(app.agent, "messages", None):
            cb = compute_cost_breakdown(
                tokens_in=int(getattr(app, "_tokens_total_in", 0) or 0),
                tokens_out=int(getattr(app, "_tokens_total_out", 0) or 0),
                cost_usd=cost,
                messages=app.agent.messages,
            )
            if cb.per_tool_calls:
                app._log(system_dim(""))
                for line in render_cost(cb).splitlines():
                    app._log(system_dim(line))
    except Exception:
        pass


async def cmd_context(app: "PrometheusApp", _arg: str) -> None:
    """Round-95 probe: live in-session context inspector.

    Reports the data needed to diagnose the 323K-token observation:
    message count, approximate token total, top-N largest messages
    (with role + tool-name when applicable), whether bash output is
    being kept verbatim, and the post-/clear reset state.
    """
    if not app.agent:
        app._log(error_line("no agent — start a session first"))
        return
    msgs = app.agent.messages
    if not msgs:
        app._log(system_dim("messages: 0  approx tokens: 0  (cleared)"))
        return

    sized: list[tuple[int, int, dict]] = []
    for i, m in enumerate(msgs):
        try:
            sz = len(json.dumps(m))
        except Exception:
            sz = len(str(m))
        sized.append((sz, i, m))

    total_chars = sum(s for s, _, _ in sized)
    approx_tokens = total_chars // 4

    # Bash-verbatim detector: a tool message whose name suggests bash
    # AND whose content is large is the canonical bloat shape.
    bash_verbatim_total = 0
    bash_verbatim_count = 0
    for sz, _, m in sized:
        if m.get("role") == "tool":
            name = (m.get("name") or "").lower()
            if name in ("run_bash", "bash_output"):
                content = str(m.get("content") or "")
                if len(content) > 2000:  # arbitrary "large" threshold
                    bash_verbatim_count += 1
                    bash_verbatim_total += len(content)

    # Top-N largest messages with role + tool name + content head
    sized.sort(reverse=True)
    top_n = sized[:10]

    app._log(system_dim(f"=== /context probe (round-95) ==="))
    app._log(system_dim(
        f"messages         : {len(msgs)}"
    ))
    app._log(system_dim(
        f"approx chars     : {total_chars:,}"
    ))
    app._log(system_dim(
        f"approx tokens    : {approx_tokens:,}  "
        f"({100 * approx_tokens // 200_000}% of 200K ctx)"
    ))
    app._log(system_dim(
        f"bash verbatim    : {bash_verbatim_count} msgs, "
        f"{bash_verbatim_total:,} chars "
        f"({100 * bash_verbatim_total // max(1, total_chars)}% of total)"
    ))
    app._log(system_dim(f"--- top 10 largest messages ---"))
    for rank, (sz, idx, m) in enumerate(top_n, 1):
        role = m.get("role", "?")
        tn = m.get("name") or ""
        content = m.get("content") or ""
        if isinstance(content, list):
            content = " | ".join(
                (p.get("text", "")[:80] if isinstance(p, dict) else str(p)[:80])
                for p in content
            )
        head = str(content)[:80].replace("\n", " ")
        app._log(system_dim(
            f"  #{rank} [{idx:>3}] role={role:<10} "
            f"name={tn:<14} {sz:>7,}b  {head!r}"
        ))
    app._log(system_dim(f"--- /clear resets to 0 messages (try it) ---"))


async def cmd_compact(app: "PrometheusApp", _arg: str) -> None:
    """Round-96: switch the chat log to compact (default) display.

    Compact mode renders one-line tool receipts, filters bash output to
    success/error markers only (drops pytest progress dots + warnings),
    and skips the multi-line execution-receipt body. Use /verbose to
    flip back to full output (raw stdout, confidence scores, evidence,
    every tool's metadata block).
    """
    app._verbose_output = False
    # Round-96 keep `_compact_mode` for backward compat with audits
    # written against the round-95 attribute. Both names now mean the
    # same thing — compact display ON.
    app._compact_mode = True
    app._log(system_dim(
        "display: compact — tool receipts one-line, bash output "
        "filtered to success/error markers. /verbose to switch back."
    ))


async def cmd_stats(app: "PrometheusApp", arg: str) -> None:
    """Round-96.2/96.4: honest token + context breakdown.

    Default (compact public) /stats output:

        active ctx       : 1,983 tokens
        active ctx use   : 0%
        last model call  : ↑2.0k input / ↓87 output
        session total    : 266.6k tokens  (lifetime, across resumes)
        messages         : 7 in active buffer
        compact forms    : 2 cached  (156 bytes)
        recent tools     : 2 calls (1,325 bytes raw output)
        note             : active ctx is what is sent to the model right now.
                           session total grows across turns + resumes.

    `/stats --debug` adds the raw provider-reported counters that
    can confuse public users (lifetime input, lifetime output, raw
    bytes per category, last-compact event metadata).

    Round-96.4 fix: the previous `last turn` row mixed
    session-cumulative `_tokens_total_in` with per-turn output and
    showed `↑251.4k / ↓15.2k` after a smoke 4 turn. Users (correctly)
    read this as a single huge model call. The new label
    `last model call` uses honest per-turn deltas
    (`_turn_tokens_in` / `_turn_tokens_out`).
    """
    import json as _json
    if not app.agent:
        app._log(error_line("agent not initialized"))
        return
    debug_mode = (arg or "").strip().lower() in ("--debug", "debug")
    msgs = app.agent.messages or []
    # Active context — bytes-to-tokens at ~4 chars/token, the same
    # heuristic the agent loop uses for compaction triggers.
    active_bytes = sum(
        len(_json.dumps(m, default=str)) for m in msgs
    )
    active_tokens = active_bytes // 4
    try:
        from prometheus.ui.app import APPROX_CTX_TOKENS as _ctx_cap
        ctx_pct = min(100, int(active_tokens * 100 / _ctx_cap))
    except Exception:
        ctx_pct = 0
    sess_total = (
        getattr(app, "_tokens_total_in", 0)
        + getattr(app, "_tokens_total_out", 0)
    )
    turn_in = getattr(app, "_turn_tokens_in", 0)
    turn_out = getattr(app, "_turn_tokens_out", 0)

    def _fmt(n: int) -> str:
        if n >= 1_000_000:
            return f"{n / 1_000_000:.1f}m"
        if n >= 10_000:
            return f"{n / 1_000:.1f}k"
        if n >= 1_000:
            return f"{n / 1_000:.1f}k"
        return f"{n:,}"

    app._log(system_dim("=== /stats — token + context breakdown ==="))
    app._log(system_dim(f"  active ctx       : {_fmt(active_tokens)} tokens"))
    app._log(system_dim(f"  active ctx use   : {ctx_pct}%"))
    if turn_in or turn_out:
        app._log(system_dim(
            f"  last model call  : ↑{_fmt(turn_in)} input"
            f" / ↓{_fmt(turn_out)} output"
        ))
    else:
        app._log(system_dim(
            "  last model call  : (no completed turn yet)"
        ))
    app._log(system_dim(
        f"  session total    : {_fmt(sess_total)} tokens"
        f"  (lifetime, across resumes)"
    ))
    app._log(system_dim(
        f"  messages         : {len(msgs)} in active buffer"
    ))
    forms = getattr(app.agent, "_compact_tool_forms", {}) or {}
    if forms:
        compact_bytes = sum(len(v) for v in forms.values())
        app._log(system_dim(
            f"  compact forms    : {len(forms)} cached  "
            f"({compact_bytes:,} bytes)"
        ))
    recent = getattr(app, "_recent_results", []) or []
    if recent:
        raw_total = sum(
            len((rr.output or "")) for _, rr in recent if rr is not None
        )
        app._log(system_dim(
            f"  recent tools     : {len(recent)} calls "
            f"({raw_total:,} bytes raw output)"
        ))
    app._log(system_dim(
        "  note             : active ctx is what is sent to the model"
    ))
    app._log(system_dim(
        "                     right now. session total grows across"
    ))
    app._log(system_dim(
        "                     turns + resumes."
    ))
    if debug_mode:
        # Round-96.4: provider/lifetime counters live behind --debug
        # so the public default doesn't show the scary 251k input
        # number that misleads operators.
        app._log(system_dim(""))
        app._log(system_dim("  --- debug ---"))
        app._log(system_dim(
            f"  lifetime input   : ↑{getattr(app, '_tokens_total_in', 0):,} tokens"
            "  (cumulative, all model calls in session)"
        ))
        app._log(system_dim(
            f"  lifetime output  : ↓{getattr(app, '_tokens_total_out', 0):,} tokens"
        ))
        app._log(system_dim(
            f"  active ctx bytes : {active_bytes:,}"
        ))
        # Round 96.19: surface the live-rail direction picker so the
        # user can verify ↑/↓ flipping without watching the rail in
        # real time. Helpful for debugging the round-96.18 → 96.19
        # event-driven hand-off.
        rail_dir = getattr(app, "_live_token_dir", "(unset)")
        app._log(system_dim(
            f"  live rail arrow  : {rail_dir}  "
            "(flips up on iteration/tool_result, down on text streaming)"
        ))
        cost = getattr(app, "_cost_total_usd", 0.0)
        if cost > 0:
            app._log(system_dim(
                f"  lifetime cost    : ${cost:.4f}"
            ))
    # Round 137: detailed session breakdown (duration, by-role,
    # tool calls by type, files created/modified, errors).
    try:
        from prometheus.session_stats import (
            compute_session_stats, render_stats,
        )
        started = (
            float(getattr(app, "_session_started_at", 0))
            or float(getattr(app.agent, "started_at", 0))
            or 0.0
        )
        snap = compute_session_stats(
            messages=msgs,
            started_at=started or None,
        )
        app._log(system_dim(""))
        for line in render_stats(snap).splitlines():
            app._log(system_dim(line))
    except Exception:
        pass


async def cmd_details(app: "PrometheusApp", arg: str) -> None:
    """Round-96.1: show full output for the last (or specified) tool
    call from the recent timeline.

    Usage:
        /details last     — last tool call's full output
        /details N        — Nth most recent (1-indexed)

    Reads from app._recent_results which the chat-log renderer
    populates after each tool result. The full stdout (capped per
    shell.py at 30K chars) is included here even when the live
    renderer suppressed it under compact mode.
    """
    arg = (arg or "").strip().lower()
    recent = list(getattr(app, "_recent_results", []) or [])
    if not recent:
        app._log(system_dim("no tool calls recorded yet in this session"))
        return
    # Resolve index
    idx = -1  # default: last
    if arg in ("", "last"):
        idx = -1
    else:
        try:
            n = int(arg)
            if n <= 0 or n > len(recent):
                app._log(error_line(
                    f"index out of range — only {len(recent)} recent calls"
                ))
                return
            idx = -n
        except ValueError:
            app._log(error_line(
                "usage: /details last  OR  /details <N>"
            ))
            return
    label, rr = recent[idx]
    app._log(system_dim(f"=== details · {label} ==="))
    meta = (rr.metadata or {}) if rr else {}
    summary = (rr.summary or "").strip() if rr else ""
    if summary:
        app._log(system_dim(f"summary: {summary}"))
    # Surface the bash-execution metadata when present
    if "command" in meta:
        app._log(system_dim(f"command: {meta.get('command', '')}"))
    if "cwd" in meta:
        app._log(system_dim(f"cwd: {meta.get('cwd', '')}"))
    if "exit" in meta:
        app._log(system_dim(f"exit: {meta.get('exit', '?')}"))
    if "duration_s" in meta:
        app._log(system_dim(f"duration: {meta.get('duration_s', '?')}s"))
    output = (rr.output or "") if rr else ""
    if output.strip():
        app._log(system_dim("--- output ---"))
        # Cap at ~6000 chars in the chat to avoid blowing past the
        # textual buffer; the full audit log on disk has the rest.
        snippet = output if len(output) <= 6000 else (
            output[:5800] + f"\n…[+{len(output) - 5800} chars truncated, "
            f"see audit log for full output]"
        )
        for line in snippet.splitlines():
            app._log(system_dim(line))


async def cmd_verbose(app: "PrometheusApp", _arg: str) -> None:
    """Round-96: switch the chat log to verbose display.

    Verbose mode shows the full execution receipt (cwd / duration /
    last 20 output lines), all bash output verbatim (warnings,
    progress dots), and includes confidence + evidence on discovery
    receipts. Use /compact to flip back to the cleaner default.
    """
    app._verbose_output = True
    app._compact_mode = False
    app._log(system_dim(
        "display: verbose — full execution receipts, raw bash output, "
        "confidence + evidence visible. /compact to switch back."
    ))


async def cmd_timeline(app: "PrometheusApp", _arg: str) -> None:
    """Round-95: show the recent tool-call timeline for this session.
    Reads from `app._recent_results` which the chat-log renderer
    already populates after each tool result. Compact, scannable —
    one line per call with status pill."""
    recent = getattr(app, "_recent_results", []) or []
    if not recent:
        app._log(system_dim("no tool calls yet in this session"))
        return
    app._log(system_dim(f"=== timeline · {len(recent)} recent tool calls ==="))
    for label, rr in recent:
        status = "✓" if not rr.error else "✗"
        meta = rr.metadata or {}
        bits = []
        if meta.get("duration_s") is not None:
            bits.append(f"{meta['duration_s']}s")
        if meta.get("exit") not in (None, ""):
            bits.append(f"exit={meta['exit']}")
        suffix = "  ·  " + "  ·  ".join(bits) if bits else ""
        summary = (rr.summary or "")[:80]
        app._log(system_dim(
            f"  {status} {label:<28} {summary}{suffix}"
        ))


async def cmd_open(app: "PrometheusApp", arg: str) -> None:
    if not arg:
        app._log(error_line("usage: /open <path>"))
        return
    tool = app.registry.get("read_file")
    if not tool:
        return
    ctx = app._make_ctx_for_direct_tool()
    res = await tool.execute({"path": arg.strip()}, ctx)
    from prometheus.ui.render import expanded_body, receipt_summary_line
    line_count = (res.output or "").count("\n") + 1
    name = arg.strip().replace("\\", "/").split("/")[-1]
    label = f"Read {name}"
    app._log(receipt_summary_line(label, res.summary, line_count, error=res.error))
    app._log(expanded_body(res))
    app._remember_result(label, res)


async def cmd_plan(app: "PrometheusApp", _arg: str) -> None:
    if app.agent:
        app.agent.set_permission_mode("plan")
    app._update_status()
    app._log(system_dim("plan mode — read-only, no writes/exec"))


async def cmd_architect(app: "PrometheusApp", arg: str) -> None:
    """Architect/Editor split — strong reasoner plans, fast coder executes.

    Usage:
        /architect <task description>

    Sends the task to the planner chain in plan mode for a structured
    plan, then auto-flips to acceptEdits and re-runs against the coder
    chain to actually apply the edits. The plan cost is paid in fast-
    reasoner tokens; the editor cost is paid in cheap-coder tokens.
    The planner-then-coder split beats either alone on hard refactors.
    """
    task = arg.strip()
    if not task:
        app._log(error_line("usage: /architect <task description>"))
        return
    if not app.agent:
        return
    # Phase 1 — planner. Switch to plan mode so the strong model can't
    # write/exec; it just produces a plan.
    app._log(system_dim("architect: drafting plan with the planner chain…"))
    app.agent.set_permission_mode("plan")
    app._update_status()
    plan_prompt = (
        f"Architect mode. Produce a clear, numbered plan for this task. "
        f"Use read-only tools (read_file, glob_files, search_code) to "
        f"investigate. Reference specific file:line locations. End with "
        f"a single line: 'Run /proceed to execute.'\n\nTask: {task}"
    )
    await app._run_agent(plan_prompt)
    # Phase 2 — switch to acceptEdits and execute the plan via the
    # coder chain. We don't auto-fire this so the user gets a clear
    # checkpoint: review the plan, then /proceed when ready.
    app._log(system_dim("architect: plan ready · /proceed to execute"))


async def cmd_proceed(app: "PrometheusApp", _arg: str) -> None:
    if not app.agent:
        return
    plan = app.agent.last_plan or ""
    app.agent.set_permission_mode("acceptEdits")
    app._update_status()
    app._log(system_dim("acceptEdits — file edits auto-approved"))
    if plan.strip():
        app._log(system_dim("executing the approved plan…"))
        execute_prompt = (
            "The plan above has been approved by the user. Execute it now "
            "step by step. Use todo_write to track progress. After finishing, "
            "summarize the changes in 1-2 sentences with file:line references."
        )
        await app._run_agent(execute_prompt)


async def cmd_rewind(app: "PrometheusApp", arg: str) -> None:
    """Round 105: rewind menu with three restore modes.

    Usage:
      /rewind                       — list checkpoints (auto + manual anchors)
      /rewind <name>                — restore code AND conversation
      /rewind code <name>           — restore files only, keep transcript
      /rewind conversation <name>   — restore transcript only, keep files
      /rewind turn                  — legacy one-turn rewind (pre-105)
    """
    from prometheus.agent.anchors import AnchorRegistry
    args = arg.strip().split(maxsplit=1)
    sub = args[0] if args else ""
    rest = args[1] if len(args) > 1 else ""
    reg = AnchorRegistry(app.settings.workdir)
    # Legacy fast path: /rewind turn → one-turn rewind.
    if sub == "turn":
        app._rewind_one_turn()
        return
    if not sub:
        anchors = reg.list()
        if not anchors:
            app._log(system_dim(
                "no checkpoints yet · /anchor save \"label\" to save one"
            ))
            app._log(system_dim(
                "  /rewind turn   — legacy one-turn rewind"
            ))
            return
        app._log(system_dim(
            f"{len(anchors)} checkpoint(s) · pick a restore mode:"
        ))
        for a in anchors[-12:]:
            tag = "auto" if a.auto else "manual"
            app._log(system_dim(
                f"  {a.label[:40]:<40} [{tag}] {a.created_at[:19]}"
            ))
        app._log(system_dim(""))
        app._log(system_dim("restore modes:"))
        app._log(system_dim(
            "  /rewind <label>                — code + conversation"
        ))
        app._log(system_dim(
            "  /rewind code <label>           — files only"
        ))
        app._log(system_dim(
            "  /rewind conversation <label>   — transcript only"
        ))
        return
    if sub in ("code", "conversation", "conv"):
        if not rest:
            app._log(error_line(
                f"usage: /rewind {sub} <label>"
            ))
            return
        target = rest
        mode = "code" if sub == "code" else "conversation"
    else:
        # Default: full restore (code + conversation).
        target = arg.strip()
        mode = "full"
    payload = reg.restore(target)
    if payload is None:
        app._log(error_line(f"no checkpoint named {target!r}"))
        return
    if app.agent is None:
        app._log(error_line("no active session to restore into"))
        return
    if mode in ("full", "conversation"):
        app.agent.messages = list(payload.get("messages") or [])
        app.agent.todos = list(payload.get("todos") or [])
        app.agent.set_permission_mode(
            str(payload.get("permission_mode", "default"))
        )
        app.agent.read_history = set(payload.get("read_history") or [])
    if mode in ("full", "code"):
        # Round 105: code restore via Git when available, else
        # via per-file snapshots stored in the anchor payload.
        files = payload.get("file_snapshots") or {}
        from pathlib import Path as _P
        restored = 0
        for rel, content in files.items():
            target_path = app.settings.workdir / rel
            try:
                target_path.parent.mkdir(parents=True, exist_ok=True)
                target_path.write_text(
                    content, encoding="utf-8", errors="replace",
                )
                restored += 1
            except OSError:
                continue
        app._log(system_dim(
            f"restored {restored} file(s) from checkpoint {target!r}"
        ))
    if mode in ("full", "conversation"):
        app._log(system_dim(
            f"restored transcript ({len(app.agent.messages)} messages, "
            f"{len(app.agent.todos)} todos)"
        ))
    app._update_status()


async def cmd_redo(app: "PrometheusApp", _arg: str) -> None:
    app._redo_one_turn()


async def cmd_async(app: "PrometheusApp", arg: str) -> None:
    """Detach a turn into a background job. Usage: /async <prompt>.

    The current chat stays free for new prompts while the agent works
    on this in the background. /jobs to see status; /jobs results <id>
    to drop the final reply into the chat when it's done.
    """
    prompt = arg.strip()
    if not prompt:
        app._log(error_line("usage: /async <prompt>"))
        return
    if not app.agent:
        return
    if app.async_jobs.active_count() >= 4:
        app._log(error_line(
            f"async cap reached ({app.async_jobs.active_count()}/4 active). "
            f"Wait for one to finish or /jobs kill <id>."
        ))
        return

    # Build a fresh isolated AgentLoop per job so they don't share
    # message state with the foreground or with each other.
    def _factory():
        from prometheus.agent.loop import AgentLoop
        from prometheus.tools import build_default_registry
        sub_reg = build_default_registry(spawn_subagent=None, ask_user=None)
        loop = AgentLoop(
            client=app.client,
            registry=sub_reg,
            settings=app.settings,
            request_approval=app._request_approval,
            notify=app._notify,
            audit=app._audit,
            session_id=f"{app.session_id}.async.{uuid.uuid4().hex[:6]}",
        )
        if app.agent:
            loop.permission_mode = app.agent.permission_mode
        return loop

    def _on_done(job):
        # Bell + status-bar custom_line so user notices when they
        # come back. The job's final text waits for /jobs results.
        try:
            import sys as _sys
            _sys.__stdout__.write("\a")
            _sys.__stdout__.flush()
        except Exception:
            pass
        try:
            sb = app.query_one("#status-bar")
            tag = "✓" if not job.error else "✗"
            sb.custom_line = f"{tag} async {job.job_id} done · /jobs results {job.job_id}"
        except Exception:
            pass

    job = await app.async_jobs.submit(prompt, _factory, on_done=_on_done)
    if job is None:
        app._log(error_line("could not start job"))
        return
    app._log(system_dim(
        f"started async job {job.job_id} — /jobs to track, "
        f"/jobs results {job.job_id} when it's done"
    ))


async def cmd_jobs(app: "PrometheusApp", arg: str) -> None:
    """List, inspect, or cancel async agent jobs.

    Usage:
        /jobs                  — list all jobs (active + finished)
        /jobs <id>             — show transcript so far
        /jobs results <id>     — copy the finished reply into chat
        /jobs kill <id>        — cancel a running job
    """
    parts = arg.strip().split(maxsplit=1)
    sub = parts[0] if parts else ""
    target = parts[1].strip() if len(parts) > 1 else ""

    if not sub:
        # Round-17: tabular dashboard. Splits running vs finished so a
        # user managing several parallel agents (which is the killer
        # use case competitive research called out) can scan status
        # at a glance instead of reading prose.
        jobs = app.async_jobs.list()
        # Foreground bash from run_bash (Ctrl+B handoff) shares the
        # same conceptual surface; surface it too if active.
        bg_jobs_obj = getattr(app, "bg_jobs", None)
        bg_shells = []
        if bg_jobs_obj is not None and hasattr(bg_jobs_obj, "list"):
            try:
                bg_shells = bg_jobs_obj.list()
            except Exception:
                bg_shells = []
        if not jobs and not bg_shells:
            app._log(system_dim(
                "no jobs · /async <prompt> for a background agent · "
                "Ctrl+B inside a long bash to background it"
            ))
            return
        running = [j for j in jobs if not getattr(j, "finished", False)]
        finished = [j for j in jobs if getattr(j, "finished", False)]
        if running or bg_shells:
            app._log(system_dim(
                f"  {'id':<8} {'kind':<6} {'status':<10} {'elapsed':>7}  "
                f"{'cost':<10} prompt/cmd"
            ))
            app._log(system_dim("  " + "─" * 64))
            for j in running:
                short_prompt = j.prompt[:50] + ("…" if len(j.prompt) > 50 else "")
                cost = f"${j.cost_usd:.4f}" if getattr(j, "cost_usd", 0) else "$0"
                app._log(system_dim(
                    f"  {j.job_id:<8} {'agent':<6} {j.status:<10} "
                    f"{j.elapsed_s:>5}s   {cost:<10} {short_prompt}"
                ))
            for s in bg_shells:
                cmd_short = (getattr(s, "cmd", "") or "")[:50]
                if len(getattr(s, "cmd", "") or "") > 50:
                    cmd_short += "…"
                elapsed_s = int(getattr(s, "elapsed_s", 0) or 0)
                app._log(system_dim(
                    f"  {s.job_id:<8} {'bash':<6} {'running':<10} "
                    f"{elapsed_s:>5}s   {'$0':<10} {cmd_short}"
                ))
        if finished:
            app._log(system_dim(""))
            app._log(system_dim(f"  finished ({len(finished)}):"))
            for j in finished[-10:]:
                short_prompt = j.prompt[:50] + ("…" if len(j.prompt) > 50 else "")
                cost = f"${j.cost_usd:.4f}" if getattr(j, "cost_usd", 0) else "$0"
                app._log(system_dim(
                    f"    {j.job_id:<8} {j.status:<10} "
                    f"{j.elapsed_s:>5}s   {cost:<10} {short_prompt}"
                ))
        app._log(system_dim(""))
        app._log(system_dim(
            "  /jobs <id>          show output    "
            "/jobs results <id>  pull reply into chat"
        ))
        app._log(system_dim(
            "  /jobs kill <id>     cancel job    "
            "/async <prompt>     start another agent"
        ))
        return

    # Resolve subcommand.
    if sub == "kill":
        if not target:
            app._log(error_line("usage: /jobs kill <id>"))
            return
        ok = await app.async_jobs.kill(target)
        app._log(system_dim(f"kill {target}: {'ok' if ok else 'no such job'}"))
        return
    if sub == "results":
        if not target:
            app._log(error_line("usage: /jobs results <id>"))
            return
        job = app.async_jobs.get(target)
        if job is None:
            app._log(error_line(f"no job {target!r}"))
            return
        if not job.finished:
            app._log(system_dim(f"{target} still running ({job.elapsed_s}s)"))
            return
        if job.error:
            app._log(error_line(f"{target} failed: {job.error}"))
            return
        from prometheus.ui.render import assistant_markdown
        app._log(system_dim(f"=== async {target} reply ==="))
        app._log(assistant_markdown(job.final_text or "(empty)"))
        return

    # /jobs <id> — show transcript so far.
    job = app.async_jobs.get(sub)
    if job is None:
        app._log(error_line(f"no job {sub!r}"))
        return
    app._log(system_dim(
        f"job {sub} · {job.status} · {job.elapsed_s}s · "
        f"↑{job.tokens_in} ↓{job.tokens_out} · ${job.cost_usd:.4f}"
    ))
    body = job.tail()
    if body:
        from prometheus.ui.render import assistant_markdown
        app._log(assistant_markdown(body))
    else:
        app._log(system_dim("(no output yet)"))


async def cmd_plugins(app: "PrometheusApp", arg: str) -> None:
    """Manage plugins.

    Usage:
        /plugins                     — list installed + enabled
        /plugins install <path>      — install a plugin from a local directory
        /plugins remove <name>       — uninstall a plugin
        /plugins enable <name>       — toggle plugin on
        /plugins disable <name>      — toggle plugin off
        /plugins marketplace         — show entries from ~/.prometheus/marketplace.json
    """
    from pathlib import Path as _P
    from prometheus.plugins import (
        discover_installed,
        install_filesystem_plugin,
        uninstall_plugin,
        list_marketplace,
    )
    from prometheus.plugins.loader import _load_index, _save_index
    parts = arg.strip().split(maxsplit=1)
    sub = parts[0] if parts else ""
    target = parts[1].strip() if len(parts) > 1 else ""

    if not sub:
        plugins = discover_installed()
        if not plugins:
            app._log(system_dim("no plugins installed"))
            app._log(system_dim("  /plugins install <path-to-dir>"))
            app._log(system_dim("  /plugins marketplace  to see suggested entries"))
            return
        app._log(system_dim(f"{len(plugins)} plugin(s) installed:"))
        for p in plugins:
            m = p.manifest
            state = "on" if m.enabled else "off"
            comp = ",".join(k for k, v in m.components.items() if v) or "(none)"
            app._log(system_dim(
                f"  · {m.name:<20} v{m.version:<8} [{state}]  {comp}"
            ))
        return

    if sub == "marketplace":
        entries = list_marketplace()
        if not entries:
            app._log(system_dim("marketplace empty"))
            app._log(system_dim(f"  add entries to ~/.prometheus/marketplace.json"))
            return
        app._log(system_dim(f"{len(entries)} marketplace entrie(s):"))
        for e in entries:
            loc = e.path or e.url or "?"
            app._log(system_dim(f"  · {e.name:<20} {e.source:<10} {loc}"))
        return

    if sub == "install":
        if not target:
            app._log(error_line("usage: /plugins install <path-to-dir>"))
            return
        try:
            from os.path import expanduser
            src = _P(expanduser(target))
            plugin = install_filesystem_plugin(src)
            app._log(system_dim(
                f"installed {plugin.manifest.name} v{plugin.manifest.version}"
            ))
            app._log(system_dim("  /new to reload — slash commands take effect on next session"))
        except Exception as e:
            app._log(error_line(f"install failed: {e}"))
        return

    if sub == "remove":
        if not target:
            app._log(error_line("usage: /plugins remove <name>"))
            return
        uninstall_plugin(target)
        app._log(system_dim(f"removed {target}"))
        return

    if sub in ("enable", "disable"):
        if not target:
            app._log(error_line(f"usage: /plugins {sub} <name>"))
            return
        plugins = discover_installed()
        plugin = next((p for p in plugins if p.manifest.name == target), None)
        if plugin is None:
            app._log(error_line(f"no plugin named {target!r}"))
            return
        # Update the manifest on disk.
        import json as _json
        manifest_path = plugin.path / "plugin.json"
        try:
            data = _json.loads(manifest_path.read_text(encoding="utf-8"))
            data["enabled"] = (sub == "enable")
            manifest_path.write_text(_json.dumps(data, indent=2), encoding="utf-8")
            app._log(system_dim(f"{target} {sub}d"))
        except Exception as e:
            app._log(error_line(f"failed to update manifest: {e}"))
        return

    app._log(error_line(f"unknown subcommand: {sub}"))


async def cmd_voice(app: "PrometheusApp", _arg: str) -> None:
    """Toggle voice dictation. Same as Ctrl+Space.

    First call: start recording. Second call (or Ctrl+Space) stops and
    transcribes; the text appends to whatever's already in the prompt.
    Esc cancels without transcribing.
    """
    app.action_voice_toggle()


async def cmd_checkpoints(app: "PrometheusApp", arg: str) -> None:
    """Browse + restore individual file checkpoints.

    Usage:
        /checkpoints              — list all checkpoints in this session
        /checkpoints restore <N>  — restore checkpoint #N (1-based)

    Each file edit (write_file, edit_file, multi_edit, apply_patch)
    pushes a snapshot. /rewind undoes the LAST turn wholesale; this
    command lets a user surgically restore one specific file change
    without affecting later edits to other files.
    """
    if not app.agent:
        return
    snaps = app.agent.snapshots
    arg = arg.strip()
    if arg.startswith("restore"):
        try:
            n = int(arg.split()[-1]) - 1
        except (ValueError, IndexError):
            app._log(error_line("usage: /checkpoints restore <N>"))
            return
        if not (0 <= n < len(snaps)):
            app._log(error_line(f"index out of range (have {len(snaps)} checkpoints)"))
            return
        snap = snaps[n]
        from pathlib import Path as _P
        path = _P(snap["path"])
        before = snap.get("before")
        try:
            if before is None:
                if path.exists():
                    path.unlink()
                app._log(system_dim(f"removed {path}"))
            else:
                path.write_text(before, encoding="utf-8", newline="")
                app._log(system_dim(f"restored {path} (checkpoint #{n + 1})"))
        except Exception as e:
            app._log(error_line(f"restore failed: {e}"))
        return
    # List mode.
    if not snaps:
        app._log(system_dim("no checkpoints yet — file edits create them automatically"))
        return
    app._log(system_dim(f"{len(snaps)} checkpoint(s):"))
    for i, s in enumerate(snaps[-20:], 1):
        kind = s.get("kind", "?")
        path = s.get("path", "?")
        size = len(s.get("after") or "")
        app._log(system_dim(f"  {i:>2}. {kind:<12} {path}  ({size:,} bytes)"))
    app._log(system_dim("/checkpoints restore <N> to revert one"))


async def cmd_skills(app: "PrometheusApp", _arg: str) -> None:
    """Round 137: list discovered skills + aptitudes with their
    purpose descriptions + source (built-in/project/user/forge)."""
    from prometheus.agent.skills import discover_skills
    skills = discover_skills(app.settings.workdir)
    aptitudes: list = []
    try:
        from prometheus.agent.aptitudes import discover_aptitudes
        aptitudes = discover_aptitudes(app.settings.workdir) or []
    except Exception:
        aptitudes = []
    if not skills and not aptitudes:
        app._log(system_dim("no skills or aptitudes found"))
        app._log(system_dim("  add files to ~/.prometheus/skills/*.md (user-global)"))
        app._log(system_dim("  or .prometheus/skills/*.md in the workdir (after /trust)"))
        return
    if skills:
        app._log(system_dim(f"{len(skills)} skill(s) discovered:"))
        for s in skills:
            triggers = (
                ", ".join(s.triggers[:5]) if s.triggers else "always-on"
            )
            app._log(system_dim(f"  {s.name:<24} → {triggers}"))
    if aptitudes:
        if skills:
            app._log(system_dim(""))
        app._log(system_dim(
            f"{len(aptitudes)} aptitude(s) discovered:"
        ))
        for a in aptitudes:
            source = getattr(a, "source", "?")
            purpose = (
                getattr(a, "purpose", "") or ""
            ).splitlines()[0] if getattr(a, "purpose", "") else ""
            app._log(system_dim(
                f"  {a.name:<24} [{source:<8}] {purpose[:60]}"
            ))


async def cmd_blades(app: "PrometheusApp", arg: str) -> None:
    """Round 103: list / show / run Command Blades.

    Sub-commands:
      /blades                  — list discovered blades
      /blades show <name>      — show body + metadata
      /blades run <name>       — submit the blade body as the
                                 next user prompt (with allowed-
                                 tools forwarded to the system
                                 prompt)
    """
    from prometheus.agent.blades import discover_blades, get_blade
    args = arg.strip().split(maxsplit=1)
    sub = args[0] if args else ""
    rest = args[1] if len(args) > 1 else ""
    if not sub or sub == "list":
        blades = discover_blades(app.settings.workdir)
        if not blades:
            app._log(system_dim("no blades defined"))
            app._log(system_dim(
                "  add `<workdir>/.prometheus/blades/<name>.md`"
                " (project, after /trust)"
            ))
            app._log(system_dim(
                "  or `~/.prometheus/blades/<name>.md` (user)"
            ))
            return
        app._log(system_dim(f"{len(blades)} blade(s) discovered:"))
        for b in blades:
            tools_str = (
                f" tools=[{', '.join(b.allowed_tools[:4])}]"
                if b.allowed_tools else ""
            )
            app._log(system_dim(
                f"  /{b.name:<22} type={b.type:<7} "
                f"[{b.source}]{tools_str}"
            ))
            if b.description:
                app._log(system_dim(f"    {b.short_description(80)}"))
        return
    if sub == "show":
        if not rest:
            app._log(error_line("usage: /blades show <name>"))
            return
        b = get_blade(app.settings.workdir, rest)
        if b is None:
            app._log(error_line(f"no blade named {rest!r}"))
            return
        app._log(system_dim(f"# /{b.name}"))
        app._log(system_dim(f"description: {b.description}"))
        app._log(system_dim(f"type: {b.type}"))
        if b.allowed_tools:
            app._log(system_dim(
                f"allowed-tools: {', '.join(b.allowed_tools)}"
            ))
        app._log(system_dim(f"source: {b.source}"))
        app._log(system_dim(""))
        for line in b.body[:1600].splitlines():
            app._log(system_dim(f"  {line}"))
        return
    if sub == "run":
        if not rest:
            app._log(error_line("usage: /blades run <name>"))
            return
        b = get_blade(app.settings.workdir, rest)
        if b is None:
            app._log(error_line(f"no blade named {rest!r}"))
            return
        if b.type != "prompt":
            app._log(error_line(
                f"blade {rest!r} is type={b.type!r}; "
                f"only prompt-type blades are runnable in round 103"
            ))
            return
        app._log(system_dim(f"running blade /{b.name}"))
        # Submit the blade body as a fresh user prompt.
        try:
            await app._dispatch_text(b.body)
        except Exception as e:
            app._log(error_line(f"blade dispatch failed: {e}"))
        return
    app._log(error_line(
        f"unknown subcommand {sub!r}. Try /blades (list), "
        f"show, run."
    ))


async def cmd_ide(app: "PrometheusApp", _arg: str) -> None:
    """Round 103: show IDE/Workstation integration status.

    Detects IDE environment via env vars and prints any deep-link
    metadata available. Real bidirectional integration (file
    sync, native diff view, /ide connect) is round-103 polish —
    this command is the visible touchpoint."""
    import os as _os
    detected: list[str] = []
    if _os.environ.get("VSCODE_PID") or _os.environ.get("VSCODE_GIT_IPC_HANDLE"):
        detected.append("VS Code")
    if _os.environ.get("TERM_PROGRAM", "").lower() == "vscode":
        if "VS Code" not in detected:
            detected.append("VS Code")
    if _os.environ.get("INTELLIJ_ENVIRONMENT_READER") or _os.environ.get("IDEA_INITIAL_DIRECTORY"):
        detected.append("JetBrains IDE")
    if _os.environ.get("CURSOR_TRACE_ID") or _os.environ.get("CURSOR_AGENT"):
        detected.append("Cursor")
    if _os.environ.get("WT_SESSION"):
        detected.append("Windows Terminal")
    if _os.environ.get("ITERM_SESSION_ID"):
        detected.append("iTerm2")
    if not detected:
        app._log(system_dim("no IDE/Workstation detected"))
        app._log(system_dim(
            "  PrometheUS runs as a standalone terminal session."
            " Inside VS Code / JetBrains / Cursor, set the launch"
            " env vars or use the IDE's terminal."
        ))
        return
    app._log(system_dim(f"detected: {', '.join(detected)}"))
    cwd = _os.getcwd()
    app._log(system_dim(f"working directory: {cwd}"))
    # Best-effort deep-link guidance.
    if "VS Code" in detected:
        app._log(system_dim(
            "  vscode://file/<path>:<line>:<col> opens a file"
            " in the running VS Code window"
        ))
    if "JetBrains IDE" in detected:
        app._log(system_dim(
            "  jetbrains://idea/navigate/reference?project=<name>&path=<path>"
        ))


async def cmd_theme(app: "PrometheusApp", arg: str) -> None:
    """Round 114: theme picker with built-in palettes.

    Usage:
      /theme              — show available themes + active
      /theme <name>       — switch to a built-in theme
                            (dark/light/monokai/solarized/nord/custom)
    """
    from prometheus.ui.themes import (
        VALID_THEMES, load_active_theme, save_active_theme,
        get_theme_palette,
    )
    name = arg.strip().lower()
    if not name:
        active = load_active_theme()
        app._log(system_dim(f"active theme: {active}"))
        app._log(system_dim("available themes:"))
        for t in VALID_THEMES:
            mark = ">" if t == active else " "
            app._log(system_dim(f"  {mark} {t}"))
        app._log(system_dim(""))
        app._log(system_dim(
            "/theme <name>     — switch active theme"
        ))
        return
    ok, msg = save_active_theme(name)
    app._log(system_dim(msg) if ok else error_line(msg))
    if ok:
        app._log(system_dim(
            "theme will fully apply on next session restart"
        ))


async def cmd_config(app: "PrometheusApp", arg: str) -> None:
    """Round 114: unified configuration menu surface.

    Usage:
      /config              — show every configurable setting
      /config <subkey>     — drill into a specific setting

    Subkeys:
      model, output-style, editor-mode, permission-mode, theme,
      env, sentinels, aptitudes, charter
    """
    sub = arg.strip().lower()
    if not sub:
        app._log(system_dim("PrometheUS configuration:"))
        app._log(system_dim(""))
        # Model.
        if app.agent and getattr(app, "settings", None):
            app._log(system_dim(
                f"  model           : {app.settings.model}"
            ))
        # Output style.
        if app.agent:
            app._log(system_dim(
                f"  output-style    : {app.agent.output_style}"
            ))
        # Permission mode.
        if app.agent:
            app._log(system_dim(
                f"  permission-mode : {app.agent.permission_mode}"
            ))
        # Editor / vim.
        vim = bool(getattr(app, "_vim_enabled", False))
        app._log(system_dim(
            f"  editor-mode     : {'vim' if vim else 'normal'}"
        ))
        # Theme.
        try:
            from prometheus.ui.themes import load_active_theme
            app._log(system_dim(
                f"  theme           : {load_active_theme()}"
            ))
        except Exception:
            pass
        # Env summary.
        try:
            from prometheus.config_env import env_summary
            es = env_summary()
            simple = es.get("PROMETHEUS_SIMPLE", "0")
            app._log(system_dim(
                f"  simple-mode     : {'on' if simple == '1' else 'off'}"
            ))
        except Exception:
            pass
        app._log(system_dim(""))
        app._log(system_dim("drill in:"))
        app._log(system_dim(
            "  /config model           · /model"
        ))
        app._log(system_dim(
            "  /config output-style    · /output-style"
        ))
        app._log(system_dim(
            "  /config theme           · /theme"
        ))
        app._log(system_dim(
            "  /config permission-mode · /permissions"
        ))
        app._log(system_dim(
            "  /config sentinels       · /sentinels"
        ))
        return
    # Drill-down: route to the per-feature command.
    routes = {
        "model": ("/model", ""),
        "output-style": ("/output-style", ""),
        "editor-mode": ("/vim", "status"),
        "permission-mode": ("/permissions", ""),
        "theme": ("/theme", ""),
        "env": ("/doctor", ""),
        "sentinels": ("/sentinels", ""),
        "aptitudes": ("/aptitude", ""),
        "charter": ("/init", "--print"),
    }
    if sub not in routes:
        app._log(error_line(
            f"unknown subkey {sub!r}. Try one of: "
            f"{', '.join(routes.keys())}"
        ))
        return
    cmd_path, default_arg = routes[sub]
    app._log(system_dim(
        f"see {cmd_path} {default_arg}".rstrip()
    ))


async def cmd_team_onboarding(app: "PrometheusApp", arg: str) -> None:
    """Round 112: generate a teammate onboarding guide.

    Walks the project's PrometheUS configuration (Charter,
    Aptitudes, Cohorts, Rules, Sentinels, Forge kits) and
    writes `<workdir>/ONBOARDING.md`. New hires read this on
    day one.

    Usage:
      /team-onboarding              — write to ONBOARDING.md
      /team-onboarding --print      — print to chat, don't write
      /team-onboarding --force      — overwrite an existing file
    """
    from prometheus.agent.onboarding import generate_onboarding_guide
    args = arg.strip().split()
    print_only = "--print" in args
    force = "--force" in args
    target = app.settings.workdir / "ONBOARDING.md"
    guide = generate_onboarding_guide(app.settings.workdir)
    if print_only:
        for line in guide.splitlines():
            app._log(system_dim(line))
        return
    if target.exists() and not force:
        app._log(system_dim(f"{target} already exists"))
        app._log(system_dim(
            "  /team-onboarding --print     to preview"
        ))
        app._log(system_dim(
            "  /team-onboarding --force     to overwrite"
        ))
        return
    try:
        target.write_text(guide, encoding="utf-8")
    except OSError as e:
        app._log(error_line(f"could not write {target}: {e}"))
        return
    app._log(system_dim(
        f"wrote {target} ({len(guide)} chars). Commit it so new "
        f"hires see it on day one."
    ))


async def cmd_bash_mode(app: "PrometheusApp", arg: str) -> None:
    """Round 124: toggle bash-mode prefix detection.

    Usage:
      /bash-mode          — toggle on/off
      /bash-mode on
      /bash-mode off
      /bash-mode status
    """
    from prometheus.agent.input_prefix import (
        bash_mode_enabled, set_bash_mode,
    )
    sub = arg.strip().lower()
    if sub == "status":
        app._log(system_dim(
            f"bash mode: {'on' if bash_mode_enabled() else 'off'}"
        ))
        return
    if sub == "on":
        set_bash_mode(True)
    elif sub == "off":
        set_bash_mode(False)
    else:
        set_bash_mode(not bash_mode_enabled())
    app._log(system_dim(
        f"bash mode {'enabled' if bash_mode_enabled() else 'disabled'}"
    ))
    if bash_mode_enabled():
        app._log(system_dim(
            "  type `! <command>` to execute directly without "
            "an LLM call. Output flows into the conversation."
        ))


async def cmd_fork(app: "PrometheusApp", arg: str) -> None:
    """Round 125: fork the current session.

    Usage:
      /fork [<label>]     — copy current state to a new session
                            (alias: /branch)
    """
    from prometheus.agent.session_ops import (
        fork_session, fork_payload,
    )
    if app.agent is None:
        app._log(error_line("no active session to fork"))
        return
    label = arg.strip()
    parent_id = getattr(app, "session_id", "")
    res = fork_session(
        parent_session_id=parent_id,
        messages=app.agent.messages,
        todos=app.agent.todos,
        permission_mode=app.agent.permission_mode,
        read_history=app.agent.read_history,
    )
    # Persist via the AnchorRegistry — same shape works for /resume.
    try:
        from prometheus.agent.anchors import AnchorRegistry
        reg = AnchorRegistry(app.settings.workdir)
        reg.save(
            label=f"fork:{label}" if label else f"fork:{res.new_session_id}",
            messages=app.agent.messages,
            todos=app.agent.todos,
            permission_mode=app.agent.permission_mode,
            read_history=set(app.agent.read_history),
            description=f"forked from {parent_id}",
            auto=False,
        )
    except Exception:
        pass
    app._log(system_dim(
        f"forked → {res.new_session_id} "
        f"({res.messages_copied} messages, "
        f"{res.todos_copied} todos)"
    ))
    app._log(system_dim(
        f"  /rewind to switch · original session continues here"
    ))


async def cmd_export(app: "PrometheusApp", arg: str) -> None:
    """Round 125: export the current transcript as plain text.

    Usage:
      /export                     — show usage
      /export <file>              — write to file
      /export --clipboard         — copy to clipboard
    """
    from pathlib import Path as _P
    from prometheus.agent.session_ops import (
        export_transcript, write_transcript_file,
    )
    if app.agent is None:
        app._log(error_line("no active session to export"))
        return
    args = arg.strip()
    label = getattr(app, "_session_label", "") or ""
    if not args:
        app._log(system_dim("usage:"))
        app._log(system_dim(
            "  /export <file>           — write transcript to file"
        ))
        app._log(system_dim(
            "  /export --clipboard      — copy to clipboard"
        ))
        return
    if args == "--clipboard":
        body = export_transcript(app.agent.messages, label=label)
        try:
            import pyperclip
            pyperclip.copy(body)
            app._log(system_dim(
                f"copied transcript to clipboard ({len(body)} chars)"
            ))
        except Exception:
            app._log(error_line(
                "clipboard unavailable. Try `/export <file>` "
                "or install `pyperclip`."
            ))
        return
    target = _P(args).expanduser()
    if not target.is_absolute():
        target = (app.settings.workdir / target).resolve()
    ok, msg = write_transcript_file(
        app.agent.messages, target=target, label=label,
    )
    app._log(system_dim(msg) if ok else error_line(msg))


async def cmd_recap(app: "PrometheusApp", _arg: str) -> None:
    """Round 125: one-line recap of the current session."""
    from prometheus.agent.session_ops import (
        compute_recap, render_recap,
    )
    if app.agent is None:
        app._log(error_line("no active session to recap"))
        return
    started = getattr(app, "_session_started_at", 0.0) or 0.0
    if not started:
        # Best-effort fallback — first message timestamp if any.
        import time
        started = getattr(app, "_busy_started", 0.0) or time.time()
    stats = compute_recap(
        started_at=started,
        messages=app.agent.messages,
    )
    app._log(system_dim(render_recap(stats)))


async def cmd_processes(app: "PrometheusApp", arg: str) -> None:
    """Round 127: list/manage background bash processes.

    Usage:
      /processes              — list active bg bash jobs
      /processes kill <id>    — kill a specific job
    """
    bg = getattr(app, "bg_jobs", None)
    if bg is None:
        app._log(system_dim("no background-jobs registry"))
        return
    args = arg.strip().split()
    sub = args[0] if args else ""
    if sub == "kill":
        if len(args) < 2:
            app._log(error_line("usage: /processes kill <id>"))
            return
        job_id = args[1]
        try:
            ok = bg.kill(job_id) if hasattr(bg, "kill") else False
        except Exception:
            ok = False
        app._log(system_dim(
            f"killed {job_id}" if ok else f"could not kill {job_id}"
        ))
        return
    # Default: list.
    try:
        jobs = bg.list() if hasattr(bg, "list") else []
    except Exception:
        jobs = []
    if not jobs:
        app._log(system_dim("no background bash jobs"))
        return
    app._log(system_dim(f"{len(jobs)} background job(s):"))
    for j in jobs:
        app._log(system_dim(
            f"  {getattr(j, 'job_id', '?')}  "
            f"{getattr(j, 'cmd', '?')[:50]}"
        ))


async def cmd_context(app: "PrometheusApp", _arg: str) -> None:
    """Round 127: visualize context-window usage as a colored grid."""
    from prometheus.agent.context_viz import (
        snapshot_context, render_context_grid,
    )
    if app.agent is None or not app.agent.messages:
        app._log(system_dim("context: 0 messages (cleared)"))
        return
    snap = snapshot_context(app.agent.messages)
    for line in render_context_grid(snap).splitlines():
        app._log(system_dim(line))


async def cmd_insights(app: "PrometheusApp", _arg: str) -> None:
    """Round 127: write a session-insights markdown report."""
    from prometheus.agent.insights import (
        analyze_messages, render_insights_report, write_insights_report,
    )
    if app.agent is None:
        app._log(error_line("no active session to analyze"))
        return
    started = getattr(app, "_session_started_at", 0.0) or 0.0
    insights = analyze_messages(
        app.agent.messages,
        session_id=getattr(app, "session_id", "session"),
        started_at=started,
    )
    p = write_insights_report(insights)
    app._log(system_dim(f"insights written → {p}"))
    # Print a short summary inline.
    if insights.tool_usage:
        top = insights.tool_usage.most_common(3)
        app._log(system_dim(
            f"  top tools: "
            f"{', '.join(f'{name}({n})' for name, n in top)}"
        ))
    if insights.files_touched:
        app._log(system_dim(
            f"  files touched: {len(insights.files_touched)}"
        ))


async def cmd_btw(app: "PrometheusApp", arg: str) -> None:
    """Round 129: side question — read-only, doesn't pollute history.

    Usage:
      /btw <question>     — get an answer from session context
    """
    from prometheus.agent.side_question import synthesize_answer
    question = arg.strip()
    if not question:
        app._log(system_dim(
            "usage: /btw <question>  (asks against session "
            "context only — no model call, no tool access)"
        ))
        return
    messages = app.agent.messages if app.agent else []
    started = getattr(app, "_session_started_at", 0.0) or 0.0
    last = (
        getattr(app.agent, "last_assistant_text", "")
        if app.agent else ""
    )
    answer = synthesize_answer(
        question, messages=messages, started_at=started,
        last_assistant_text=last,
    )
    # Render as a dim overlay block. The answer is NOT appended
    # to agent.messages — that's the contract.
    app._log(system_dim(f"╭─ /btw"))
    for line in answer.splitlines():
        app._log(system_dim(f"│  {line}"))
    app._log(system_dim("╰─ (read-only · not added to context)"))


async def cmd_release_notes(app: "PrometheusApp", _arg: str) -> None:
    """Round 129: show the changelog for the current version."""
    from pathlib import Path as _P
    from prometheus.config import VERSION
    candidates = [
        _P(__file__).parent.parent.parent / "RELEASE_NOTES.md",
        _P(__file__).parent.parent.parent / "CHANGELOG.md",
        app.settings.workdir / "RELEASE_NOTES.md",
        app.settings.workdir / "CHANGELOG.md",
    ]
    body = ""
    used_path = None
    for p in candidates:
        if p.exists() and p.is_file():
            try:
                body = p.read_text(encoding="utf-8", errors="replace")
                used_path = p
                break
            except OSError:
                continue
    app._log(system_dim(f"PrometheUS {VERSION}"))
    if not body:
        app._log(system_dim(
            "no RELEASE_NOTES.md / CHANGELOG.md found"
        ))
        app._log(system_dim(
            "  drop one in the project root or "
            f"{candidates[0]}"
        ))
        return
    app._log(system_dim(f"  source: {used_path}"))
    app._log(system_dim(""))
    for line in body.splitlines()[:80]:
        app._log(system_dim(line))


async def cmd_extra_usage(app: "PrometheusApp", arg: str) -> None:
    """Round 129: configure rate-limit behavior.

    Usage:
      /extra-usage status         — show current policy
      /extra-usage retry          — auto-retry with exponential backoff
      /extra-usage notify         — notify and pause
      /extra-usage fallback       — switch to fallback model
    """
    import json as _json
    from pathlib import Path as _P
    p = _P.home() / ".prometheus" / "extra-usage.json"
    args = arg.strip().lower()
    if not args or args == "status":
        cfg = {"policy": "retry"}
        if p.exists():
            try:
                cfg = _json.loads(p.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                pass
        app._log(system_dim(
            f"extra-usage policy: {cfg.get('policy', 'retry')}"
        ))
        app._log(system_dim(
            "  retry · notify · fallback"
        ))
        return
    if args not in ("retry", "notify", "fallback"):
        app._log(error_line(
            f"unknown policy {args!r}. Try retry / notify / fallback."
        ))
        return
    p.parent.mkdir(parents=True, exist_ok=True)
    try:
        p.write_text(
            _json.dumps({"policy": args}, indent=2),
            encoding="utf-8",
        )
        app._log(system_dim(f"extra-usage policy → {args}"))
    except OSError as e:
        app._log(error_line(f"could not save policy: {e}"))


async def cmd_voice(app: "PrometheusApp", arg: str) -> None:
    """Round 119: toggle voice input mode.

    Usage:
      /voice          — toggle on/off
      /voice on
      /voice off
      /voice status
    """
    from prometheus.ui.voice import VoiceState, VOICE_OFF
    sub = arg.strip().lower()
    if not hasattr(app, "_voice_state"):
        app._voice_state = VoiceState()  # type: ignore[attr-defined]
    state = app._voice_state
    if sub == "status":
        if state.is_active:
            app._log(system_dim(f"voice mode: {state.status_label}"))
        else:
            app._log(system_dim("voice mode: off"))
        if not state.backend.available:
            app._log(system_dim(
                f"  backend: {state.backend.name} (no microphone "
                f"detected — voice unavailable)"
            ))
        return
    if sub == "on":
        if state.mode == VOICE_OFF:
            mode, msg = state.toggle()
        else:
            mode, msg = state.mode, "voice mode already on"
    elif sub == "off":
        if state.mode != VOICE_OFF:
            mode, msg = state.toggle()
        else:
            mode, msg = state.mode, "voice mode already off"
    else:
        mode, msg = state.toggle()
    app._log(system_dim(msg))
    if state.is_active:
        app._log(system_dim(
            "  hold space to record · release to transcribe"
        ))


async def cmd_outcomes(app: "PrometheusApp", arg: str) -> None:
    """Round 120: success-criteria-driven auto-retry.

    Usage:
      /outcomes <markdown-file>     — load a rubric, enable auto-retry
      /outcomes status              — show active rubric + retry count
      /outcomes stop                — clear the active rubric
    """
    from pathlib import Path as _P
    from prometheus.agent.outcomes import (
        Outcomes, load_rubric_file, max_retries,
    )
    args = arg.strip()
    if not hasattr(app, "_outcomes"):
        app._outcomes = Outcomes()  # type: ignore[attr-defined]
    state: Outcomes = app._outcomes
    if not args or args == "status":
        if not state.active:
            app._log(system_dim("outcomes: inactive"))
            return
        app._log(system_dim(
            f"outcomes: active · "
            f"{len(state.rubric.criteria)} criteria · "
            f"retries used {state.retries_used}/{max_retries()}"
        ))
        if state.last_scores:
            for s in state.last_scores:
                mark = "✓" if s.met else "·"
                app._log(system_dim(
                    f"  {mark} {s.criterion.short} "
                    f"(confidence {s.confidence:.2f})"
                ))
        return
    if args == "stop":
        was_active = state.active
        state.reset()
        app._log(system_dim(
            "outcomes cleared" if was_active else "outcomes inactive"
        ))
        return
    # Treat the arg as a rubric file path.
    path = _P(args).expanduser()
    if not path.is_absolute():
        path = (app.settings.workdir / path).resolve()
    rubric = load_rubric_file(path)
    if rubric is None:
        app._log(error_line(f"could not load rubric from {path}"))
        return
    state.rubric = rubric
    state.retries_used = 0
    state.completed = False
    state.last_scores = []
    app._log(system_dim(
        f"outcomes loaded: {len(rubric.criteria)} criteria from {path.name}"
    ))
    app._log(system_dim(
        f"  max retries: {max_retries()}  · /outcomes stop to clear"
    ))


async def cmd_dream(app: "PrometheusApp", arg: str) -> None:
    """Round 121 + 1.0.3: trigger an asynchronous self-improvement
    cycle. Autonomous consolidation runs by default; pass `review`
    to keep the original approval-only behavior.

    Usage:
      /dream                  — run autonomous cycle (consolidate + report)
      /dream review           — produce a report only, change nothing
      /dream status           — show last cycle + pending suggestions
      /dream schedule <cron>  — enable periodic dreams
      /dream schedule off
    """
    from prometheus.agent.dreaming import (
        DreamSchedule, list_dream_reports, render_dream_report,
        run_dream_cycle, write_dream_report,
    )
    args = arg.strip().split(maxsplit=1)
    sub = args[0] if args else ""
    rest = args[1] if len(args) > 1 else ""
    if sub == "status":
        sched = DreamSchedule.load()
        reports = list_dream_reports()
        if reports:
            app._log(system_dim(
                f"last dream: {reports[0].name}"
            ))
        else:
            app._log(system_dim("no dreams recorded yet"))
        if sched.cron:
            app._log(system_dim(f"schedule: {sched.cron}"))
            if sched.last_run_iso:
                app._log(system_dim(f"last scheduled run: {sched.last_run_iso}"))
        else:
            app._log(system_dim("schedule: off"))
        return
    if sub == "schedule":
        sched = DreamSchedule.load()
        if rest in ("", "off", "disable"):
            sched.cron = ""
            sched.save()
            app._log(system_dim("dream schedule disabled"))
            return
        # Parse the cron via the routines module to validate.
        try:
            from prometheus.agent.routines import parse_cron
            parse_cron(rest)
        except ValueError as e:
            app._log(error_line(f"bad cron: {e}"))
            return
        sched.cron = rest
        sched.save()
        app._log(system_dim(f"dream schedule set: {rest}"))
        return
    # Default: run an autonomous cycle. `review` opts into the
    # approval-only flow that never modifies memories.
    autonomous = sub != "review"
    app._log(system_dim(
        "dreaming…" if autonomous else "dreaming (review only)…"
    ))
    try:
        report = run_dream_cycle(autonomous=autonomous)
        path = write_dream_report(report)
    except Exception as e:
        app._log(error_line(f"dream cycle failed: {e}"))
        return
    app._log(system_dim(
        f"dream complete · {report.transcripts_scanned} transcripts scanned"
    ))
    app._log(system_dim(
        f"  patterns: {len(report.patterns)} · "
        f"suggested memories: {len(report.suggested_memories)}"
    ))
    c = report.consolidation
    if c is not None:
        applied = (
            len(c.deduplicated) + len(c.pruned_stale)
            + len(c.pruned_for_size)
        )
        app._log(system_dim(
            f"  consolidated: -{applied} entries · "
            f"dates rewritten: {len(c.dates_rewritten)}"
        ))
    app._log(system_dim(f"  report: {path}"))


async def cmd_powerup(app: "PrometheusApp", arg: str) -> None:
    """Round 122: interactive tutorials.

    Usage:
      /powerup                  — show tutorial menu
      /powerup <name>           — start a tutorial
      /powerup next             — advance to the next step
      /powerup quit             — exit current tutorial
    """
    from prometheus.agent.powerup import (
        discover_tutorials, get_tutorial, render_step,
    )
    args = arg.strip()
    if not hasattr(app, "_powerup_state"):
        app._powerup_state = {}  # type: ignore[attr-defined]
    state: dict = app._powerup_state
    if args == "next":
        if "tutorial" not in state:
            app._log(system_dim("no tutorial in progress"))
            return
        state["step_index"] = state.get("step_index", 0) + 1
        if state["step_index"] >= len(state["tutorial"].steps):
            app._log(system_dim(
                f"✓ tutorial complete · {state['tutorial'].name}"
            ))
            state.clear()
            return
        step = state["tutorial"].steps[state["step_index"]]
        for line in render_step(
            step, idx=state["step_index"],
            total=len(state["tutorial"].steps),
        ).splitlines():
            app._log(system_dim(line))
        app._log(system_dim(
            "  /powerup next — advance · /powerup quit — exit"
        ))
        return
    if args == "quit":
        if "tutorial" in state:
            app._log(system_dim(
                f"left tutorial: {state['tutorial'].name}"
            ))
        state.clear()
        return
    if not args:
        tutorials = discover_tutorials(app.settings.workdir)
        if not tutorials:
            app._log(system_dim("no tutorials found"))
            return
        app._log(system_dim(f"{len(tutorials)} tutorial(s):"))
        for t in tutorials:
            app._log(system_dim(
                f"  {t.name:<24} [{t.source}]  {t.description[:60]}"
            ))
        app._log(system_dim(""))
        app._log(system_dim("  /powerup <name>     — start"))
        return
    # /powerup <name>
    t = get_tutorial(app.settings.workdir, args)
    if t is None:
        app._log(error_line(f"no tutorial named {args!r}"))
        return
    if not t.steps:
        app._log(system_dim(f"tutorial {t.name!r} has no steps"))
        return
    state.clear()
    state["tutorial"] = t
    state["step_index"] = 0
    app._log(system_dim(f"# {t.name}"))
    app._log(system_dim(t.description))
    app._log(system_dim(""))
    for line in render_step(
        t.steps[0], idx=0, total=len(t.steps),
    ).splitlines():
        app._log(system_dim(line))
    app._log(system_dim(
        "  /powerup next — advance · /powerup quit — exit"
    ))


async def cmd_bridge(app: "PrometheusApp", arg: str) -> None:
    """Round 118: Remote Session Bridge.

    Usage:
      /bridge              — start bridge, print URL + pairing code
      /bridge stop         — stop bridge
      /bridge status       — show bridge state
      /bridge --lan        — bind to LAN-reachable IP (vs 127.0.0.1)
    """
    from prometheus.bridge import BridgeServer, detect_lan_host
    args = arg.strip().split()
    sub = args[0] if args else ""
    if sub == "stop":
        bridge = getattr(app, "_bridge", None)
        if bridge is None or not bridge.running:
            app._log(system_dim("bridge not running"))
            return
        ok, msg = bridge.stop()
        app._log(system_dim(msg) if ok else error_line(msg))
        return
    if sub == "status":
        bridge = getattr(app, "_bridge", None)
        if bridge is None or not bridge.running:
            app._log(system_dim("bridge: stopped"))
            return
        app._log(system_dim(f"bridge: running at {bridge.url}"))
        app._log(system_dim(
            f"transcript events: {len(bridge.transcript.events)}"
        ))
        return
    # Default: start.
    bridge = getattr(app, "_bridge", None)
    if bridge is not None and bridge.running:
        app._log(system_dim(
            f"bridge already running at {bridge.url} · "
            f"code {bridge.config.pairing_code}"
        ))
        return
    if bridge is None:
        bridge = BridgeServer()
        app._bridge = bridge  # type: ignore[attr-defined]
    host = "127.0.0.1"
    if "--lan" in args:
        host = detect_lan_host()

    def _on_prompt(body: str) -> None:
        # Round 118: a remote-submitted prompt drops into the
        # local app's _dispatch_text path so the local session
        # processes it as if the user typed it. Fire on the
        # event loop via call_soon_threadsafe so we cross the
        # bridge thread → asyncio thread boundary safely.
        try:
            import asyncio as _aio
            loop = _aio.get_event_loop()
            loop.call_soon_threadsafe(
                lambda: _aio.create_task(app._dispatch_text(body))
            )
        except Exception:
            pass

    ok, msg = bridge.start(on_prompt=_on_prompt, host=host)
    app._log(system_dim(msg) if ok else error_line(msg))
    if ok:
        app._log(system_dim(
            "  /bridge stop    — close the bridge"
        ))
        app._log(system_dim(
            "  read-only + prompt-send · no file access from remote"
        ))


async def cmd_routine(app: "PrometheusApp", arg: str) -> None:
    """Round 111: scheduled autonomous routines.

    Sub-commands:
      /routine                        — list routines
      /routine list
      /routine show <name>
      /routine create <name>          — interactive create wizard
      /routine create <name> "<desc>" "<cron>" "<prompt>"
      /routine run <name>             — execute now (one-shot)
      /routine delete <name>
      /routine validate <name>
    """
    from prometheus.agent.routines import RoutineRegistry
    args = arg.strip().split(maxsplit=4)
    sub = args[0] if args else ""
    reg = RoutineRegistry(app.settings.workdir)
    if not sub or sub == "list":
        routines = reg.list()
        if not routines:
            app._log(system_dim("no routines defined"))
            app._log(system_dim(
                "  /routine create <name> ... to add one"
            ))
            return
        app._log(system_dim(f"{len(routines)} routine(s):"))
        for r in routines:
            sched = r.schedule if r.schedule else "(no schedule)"
            app._log(system_dim(
                f"  {r.name:<24} trigger={r.trigger:<12} {sched}"
            ))
            if r.description:
                app._log(system_dim(f"    {r.description[:80]}"))
        return
    if sub == "show":
        if len(args) < 2:
            app._log(error_line("usage: /routine show <name>"))
            return
        r = reg.get(args[1])
        if r is None:
            app._log(error_line(f"no routine named {args[1]!r}"))
            return
        app._log(system_dim(f"# {r.name}"))
        app._log(system_dim(f"description: {r.description}"))
        app._log(system_dim(f"trigger: {r.trigger}"))
        if r.schedule:
            app._log(system_dim(f"schedule: {r.schedule}"))
        app._log(system_dim(f"model: {r.model}"))
        app._log(system_dim(f"permission_mode: {r.permission_mode}"))
        app._log(system_dim(""))
        app._log(system_dim("prompt:"))
        for line in r.prompt.splitlines():
            app._log(system_dim(f"  {line}"))
        return
    if sub == "create":
        if len(args) >= 5:
            # Non-interactive form.
            name = args[1]
            description = args[2].strip().strip('"').strip("'")
            schedule = args[3].strip().strip('"').strip("'")
            prompt = args[4].strip().strip('"').strip("'")
            r, msg = reg.create(
                name=name, description=description,
                schedule=schedule, prompt=prompt,
                trigger="schedule" if schedule else "manual",
            )
        elif len(args) == 2:
            # Minimal — name only, manual trigger, empty prompt.
            r, msg = reg.create(
                name=args[1], description="(edit me)",
                prompt="(replace this with the routine's prompt)",
                trigger="manual",
            )
        else:
            app._log(error_line(
                'usage: /routine create <name> '
                '"<description>" "<cron>" "<prompt>"'
            ))
            return
        app._log(system_dim(msg) if r else error_line(msg))
        return
    if sub == "run":
        if len(args) < 2:
            app._log(error_line("usage: /routine run <name>"))
            return
        r = reg.get(args[1])
        if r is None:
            app._log(error_line(f"no routine named {args[1]!r}"))
            return
        app._log(system_dim(
            f"running routine {r.name!r}: {r.description[:60]}"
        ))
        # Submit the routine prompt as if the user typed it.
        try:
            await app._dispatch_text(r.prompt)
        except Exception as e:
            app._log(error_line(f"routine dispatch failed: {e}"))
        return
    if sub == "delete":
        if len(args) < 2:
            app._log(error_line("usage: /routine delete <name>"))
            return
        ok, msg = reg.delete(args[1])
        app._log(system_dim(msg) if ok else error_line(msg))
        return
    if sub == "validate":
        if len(args) < 2:
            # Validate every routine.
            routines = reg.list()
            if not routines:
                app._log(system_dim("no routines to validate"))
                return
            n_ok = 0
            for r in routines:
                ok, issues = r.is_valid()
                if ok:
                    n_ok += 1
                    continue
                app._log(error_line(f"{r.name}:"))
                for i in issues:
                    app._log(system_dim(f"  · {i}"))
            app._log(system_dim(
                f"{n_ok}/{len(routines)} routines clean"
            ))
            return
        r = reg.get(args[1])
        if r is None:
            app._log(error_line(f"no routine named {args[1]!r}"))
            return
        ok, issues = r.is_valid()
        if ok:
            app._log(system_dim(f"{args[1]}: OK"))
            return
        for i in issues:
            app._log(system_dim(f"  · {i}"))
        return
    app._log(error_line(
        f"unknown subcommand {sub!r}. Try /routine (list), "
        f"create, run, delete, validate, show."
    ))


async def cmd_rules(app: "PrometheusApp", arg: str) -> None:
    """Round 109: path-scoped rules.

    Sub-commands:
      /rules                 — list rules + which paths they cover
      /rules show <name>     — show body
      /rules validate <name> — flag missing fields / empty globs
      /rules where <name>    — print path
    """
    from prometheus.agent.rules_engine import (
        discover_rules, get_rule, validate,
    )
    args = arg.strip().split(maxsplit=1)
    sub = args[0] if args else ""
    rest = args[1] if len(args) > 1 else ""
    if not sub or sub == "list":
        rules = discover_rules(app.settings.workdir)
        if not rules:
            app._log(system_dim("no rules defined"))
            app._log(system_dim(
                "  add `<workdir>/.prometheus/rules/<name>.md`"
                " (project, after /trust)"
            ))
            app._log(system_dim(
                "  or `~/.prometheus/rules/<name>.md` (user)"
            ))
            return
        app._log(system_dim(f"{len(rules)} rule(s) discovered:"))
        for r in rules:
            globs = ", ".join(r.paths[:3])
            if len(r.paths) > 3:
                globs += f" (+{len(r.paths) - 3} more)"
            app._log(system_dim(
                f"  {r.name:<24} [{r.source}]  {globs}"
            ))
            if r.description:
                app._log(system_dim(f"    {r.short_description(80)}"))
        return
    if sub == "show":
        if not rest:
            app._log(error_line("usage: /rules show <name>"))
            return
        r = get_rule(app.settings.workdir, rest)
        if r is None:
            app._log(error_line(f"no rule named {rest!r}"))
            return
        app._log(system_dim(f"# {r.name}"))
        app._log(system_dim(f"description: {r.description}"))
        app._log(system_dim(f"paths: {', '.join(r.paths)}"))
        app._log(system_dim(f"source: {r.source}"))
        app._log(system_dim(""))
        for line in r.body[:1600].splitlines():
            app._log(system_dim(f"  {line}"))
        return
    if sub == "validate":
        if not rest:
            # Validate every rule.
            rules = discover_rules(app.settings.workdir)
            if not rules:
                app._log(system_dim("no rules to validate"))
                return
            n_ok = 0
            for r in rules:
                issues = validate(r)
                if not issues:
                    n_ok += 1
                    continue
                app._log(error_line(f"{r.name}:"))
                for i in issues:
                    app._log(system_dim(f"  · {i}"))
            app._log(system_dim(
                f"{n_ok}/{len(rules)} rules clean"
            ))
            return
        r = get_rule(app.settings.workdir, rest)
        if r is None:
            app._log(error_line(f"no rule named {rest!r}"))
            return
        issues = validate(r)
        if not issues:
            app._log(system_dim(f"{rest!r}: OK"))
            return
        app._log(error_line(f"{rest!r}:"))
        for i in issues:
            app._log(system_dim(f"  · {i}"))
        return
    if sub == "where":
        if not rest:
            app._log(error_line("usage: /rules where <name>"))
            return
        r = get_rule(app.settings.workdir, rest)
        if r is None:
            app._log(error_line(f"no rule named {rest!r}"))
            return
        app._log(system_dim(str(r.path)))
        return
    app._log(error_line(
        f"unknown subcommand {sub!r}. Try /rules (list), "
        f"show, validate, where."
    ))


async def cmd_loop(app: "PrometheusApp", arg: str) -> None:
    """Round 107: periodic execution loop.

    Usage:
      /loop <interval> <prompt>     — schedule a recurring prompt
      /loop status                  — show active loops
      /loop stop                    — stop the most recent loop
      /loop stop <id>               — stop one specific loop

    Intervals: `5s`, `30s`, `5m`, `1h`. Anything bash-runnable that
    fits on one line works as the prompt."""
    import asyncio as _aio, re as _re
    args = arg.strip().split(maxsplit=1)
    sub = args[0] if args else ""
    rest = args[1] if len(args) > 1 else ""
    if not hasattr(app, "_loop_jobs"):
        app._loop_jobs = {}  # type: ignore[attr-defined]
    if sub == "status":
        jobs = app._loop_jobs
        if not jobs:
            app._log(system_dim("no active /loop jobs"))
            return
        app._log(system_dim(f"{len(jobs)} active loop(s):"))
        for jid, info in jobs.items():
            running = (
                "running" if not info["task"].done() else "stopped"
            )
            app._log(system_dim(
                f"  {jid}  every {info['interval']}  {running}"
            ))
            app._log(system_dim(f"    prompt: {info['prompt'][:60]}"))
        return
    if sub == "stop":
        jobs = app._loop_jobs
        if not jobs:
            app._log(system_dim("no active /loop jobs"))
            return
        target_id = rest.strip() if rest else next(reversed(jobs))
        if target_id not in jobs:
            app._log(error_line(f"no loop job named {target_id!r}"))
            return
        info = jobs.pop(target_id)
        info["task"].cancel()
        app._log(system_dim(f"stopped loop {target_id}"))
        return
    # Parse: `<interval> <prompt>`.
    m = _re.match(r"^\s*(\d+)\s*([smh])\s+(.*)$", arg.strip())
    if not m:
        app._log(error_line(
            "usage: /loop <interval> <prompt>  (e.g. /loop 5m check deploy)"
        ))
        return
    n = int(m.group(1))
    unit = m.group(2)
    prompt = m.group(3).strip()
    if not prompt:
        app._log(error_line("loop prompt required"))
        return
    seconds = n * {"s": 1, "m": 60, "h": 3600}[unit]
    if seconds < 5:
        app._log(error_line("minimum loop interval is 5s"))
        return

    job_id = f"loop-{len(app._loop_jobs) + 1}"

    async def _runner():
        try:
            while True:
                await _aio.sleep(seconds)
                try:
                    await app._dispatch_text(prompt)
                except Exception:
                    pass
        except _aio.CancelledError:
            return

    task = _aio.create_task(_runner())
    app._loop_jobs[job_id] = {
        "task": task, "prompt": prompt,
        "interval": f"{n}{unit}",
    }
    app._log(system_dim(
        f"loop {job_id} scheduled every {n}{unit}: {prompt[:60]}"
    ))
    app._log(system_dim(
        f"  /loop stop {job_id}    — cancel"
    ))


async def cmd_teams(app: "PrometheusApp", arg: str) -> None:
    """Round 107: list / show / send to Teammates.

    Sub-commands:
      /teams                  — list teammates
      /teams show <name>
      /teams send <name> <body>
      /teams broadcast <body>
      /teams remove <name>
      /teams enable           — enable team mode for this session
    """
    import os as _os
    from prometheus.agent.teams import TeamRegistry, is_team_mode_enabled
    args = arg.strip().split(maxsplit=2)
    sub = args[0] if args else ""
    if sub == "enable":
        _os.environ["PROMETHEUS_AGENT_TEAMS"] = "1"
        app._log(system_dim(
            "team mode enabled for this session"
        ))
        return
    enabled = is_team_mode_enabled()
    if not sub or sub == "list":
        reg = TeamRegistry.load(app.settings.workdir)
        teammates = reg.list()
        if not enabled:
            app._log(system_dim(
                "team mode disabled — /teams enable to turn on"
            ))
        if not teammates:
            app._log(system_dim("no teammates registered"))
            return
        app._log(system_dim(f"{len(teammates)} teammate(s):"))
        for t in teammates:
            inbox_n = sum(1 for m in t.inbox if not m.seen)
            inbox_str = f" · inbox={inbox_n}" if inbox_n else ""
            app._log(system_dim(
                f"  {t.name:<20} {t.role[:40]:<40} status={t.status}{inbox_str}"
            ))
        return
    if sub == "show":
        if len(args) < 2:
            app._log(error_line("usage: /teams show <name>"))
            return
        name = args[1]
        reg = TeamRegistry.load(app.settings.workdir)
        t = reg.get(name)
        if t is None:
            app._log(error_line(f"no teammate named {name!r}"))
            return
        app._log(system_dim(f"# {t.name}"))
        app._log(system_dim(f"role: {t.role}"))
        app._log(system_dim(f"status: {t.status}"))
        app._log(system_dim(f"color: {t.color}"))
        app._log(system_dim(f"inbox: {len(t.inbox)} messages"))
        for m in t.inbox[-5:]:
            seen = "✓" if m.seen else "•"
            app._log(system_dim(
                f"  {seen} from={m.sender}: {m.body[:60]}"
            ))
        return
    if sub == "remove":
        if len(args) < 2:
            app._log(error_line("usage: /teams remove <name>"))
            return
        reg = TeamRegistry.load(app.settings.workdir)
        ok, msg = reg.delete(args[1])
        app._log(system_dim(msg) if ok else error_line(msg))
        return
    if sub in ("send", "broadcast"):
        if not enabled:
            app._log(error_line(
                "team mode disabled. Run `/teams enable` first."
            ))
            return
        reg = TeamRegistry.load(app.settings.workdir)
        if sub == "send":
            if len(args) < 3:
                app._log(error_line(
                    "usage: /teams send <name> <body>"
                ))
                return
            ok, msg = reg.send(
                sender="lead", recipient=args[1], body=args[2],
            )
        else:
            if len(args) < 2:
                app._log(error_line(
                    "usage: /teams broadcast <body>"
                ))
                return
            body = " ".join(args[1:])
            ok, msg = reg.send(
                sender="lead", recipient="*", body=body,
            )
        app._log(system_dim(msg) if ok else error_line(msg))
        return
    app._log(error_line(
        f"unknown subcommand {sub!r}. Try /teams (list), "
        f"show, send, broadcast, remove, enable."
    ))


async def cmd_vim(app: "PrometheusApp", arg: str) -> None:
    """Round 106: toggle vim-style modal editing on the input
    buffer.

    Usage:
      /vim         — toggle on/off
      /vim on
      /vim off
      /vim status
    """
    sub = arg.strip().lower()
    enabled = bool(getattr(app, "_vim_enabled", False))
    if sub == "status":
        app._log(system_dim(
            f"vim mode: {'on' if enabled else 'off'}"
        ))
        return
    if sub == "on":
        new = True
    elif sub == "off":
        new = False
    else:
        new = not enabled
    app._vim_enabled = new  # type: ignore[attr-defined]
    if new and not hasattr(app, "_vim_state"):
        from prometheus.ui.vim_mode import VimState
        app._vim_state = VimState()  # type: ignore[attr-defined]
    # Flip the live Input's vim_enabled flag so VimInput's key
    # handler activates immediately, no restart required.
    try:
        from textual.widgets import Input
        inp = app.query_one("#prompt", Input)
        if hasattr(inp, "vim_enabled"):
            inp.vim_enabled = new
    except Exception:
        # Tests / non-Textual contexts don't have a live input;
        # the toggle still flips the app-level flag.
        pass
    app._log(system_dim(
        f"vim mode {'enabled' if new else 'disabled'}"
    ))
    if new:
        app._log(system_dim(
            "  Esc → Normal mode · i → Insert · h/j/k/l navigate"
        ))
        app._log(system_dim(
            "  w/b/e words · 0/$ line ends · dw/cw/yw operators"
        ))


async def cmd_keybindings(app: "PrometheusApp", _arg: str) -> None:
    """Round 106: open ~/.prometheus/keybindings.json in the
    system editor for live re-mapping."""
    import os, subprocess, sys
    from pathlib import Path as _P
    p = _P.home() / ".prometheus" / "keybindings.json"
    if not p.exists():
        p.parent.mkdir(parents=True, exist_ok=True)
        # Seed with the current reserved bindings so the user
        # has something to edit, not a blank file.
        seed = {
            "_comment": (
                "PrometheUS keybindings. Reserved keys "
                "(ctrl+c/ctrl+l/escape) cannot be remapped. Edit "
                "and save — the next session reloads this file."
            ),
            "bindings": {
                "ctrl+r": "history",
                "ctrl+y": "copy_last",
                "ctrl+b": "background_bash",
                "ctrl+o": "toggle_verbose_or_subagent_expand",
                "ctrl+t": "toggle_todo_panel",
                "ctrl+g": "external_editor",
                "shift+tab": "cycle_mode",
                "tab": "complete_slash",
                "escape": "interrupt",
            },
        }
        try:
            import json as _json
            p.write_text(
                _json.dumps(seed, indent=2),
                encoding="utf-8",
            )
        except OSError as e:
            app._log(error_line(f"could not seed {p}: {e}"))
            return
    app._log(system_dim(f"opening {p}"))
    # Round 154 fix: never use os.startfile() on Windows — it
    # invokes the shell's file-association handler, and when no
    # default is registered for `.json` Windows pops a modal
    # "How do you want to open this file?" picker that interrupts
    # the user. Always launch a known editor (notepad on Windows)
    # so the experience is predictable.
    editor = os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if not editor:
        editor = (
            "notepad.exe" if sys.platform == "win32"
            else "open" if sys.platform == "darwin"
            else "xdg-open"
        )
    try:
        subprocess.Popen([*editor.split(), str(p)])
    except Exception as e:
        app._log(error_line(f"could not open editor ({editor}): {e}"))


async def cmd_anchor(app: "PrometheusApp", arg: str) -> None:
    """Round 102: Anchor Points — named conversation checkpoints.

    Sub-commands:
      /anchor                       — list saved anchors
      /anchor list
      /anchor save "<label>"        — checkpoint the current state
      /anchor save "<label>" - <description>
      /anchor restore <label>       — rewind to a saved state
      /anchor remove <label>
    """
    from prometheus.agent.anchors import AnchorRegistry
    args = arg.strip()
    reg = AnchorRegistry(app.settings.workdir)
    if not args or args == "list":
        anchors = reg.list()
        if not anchors:
            app._log(system_dim("no anchors saved"))
            app._log(system_dim('  /anchor save "before refactor"'))
            return
        app._log(system_dim(f"{len(anchors)} anchor(s):"))
        for a in anchors:
            tag = "auto" if a.auto else "manual"
            app._log(system_dim(
                f"  {a.label[:40]:<40} [{tag}] {a.created_at[:19]}"
            ))
            if a.description:
                app._log(system_dim(f"    {a.description[:80]}"))
        return
    parts = args.split(maxsplit=1)
    sub = parts[0]
    rest = parts[1] if len(parts) > 1 else ""
    if sub == "save":
        if not rest:
            app._log(error_line('usage: /anchor save "<label>"'))
            return
        # Strip optional surrounding quotes; allow `label - description`.
        label = rest
        description = ""
        if " - " in label:
            label, description = label.split(" - ", 1)
        label = label.strip().strip('"').strip("'")
        if not label:
            app._log(error_line("anchor label required"))
            return
        if app.agent is None:
            app._log(error_line("no active session to anchor"))
            return
        anchor = reg.save(
            label=label,
            messages=app.agent.messages,
            todos=app.agent.todos,
            permission_mode=app.agent.permission_mode,
            read_history=app.agent.read_history,
            description=description,
            auto=False,
        )
        app._log(system_dim(
            f"anchored {anchor.label!r} → {anchor.path}"
        ))
        return
    if sub == "restore":
        if not rest:
            app._log(error_line("usage: /anchor restore <label>"))
            return
        if app.agent is None:
            app._log(error_line("no active session to restore into"))
            return
        payload = reg.restore(rest)
        if payload is None:
            app._log(error_line(f"no anchor named {rest!r}"))
            return
        app.agent.messages = list(payload.get("messages") or [])
        app.agent.todos = list(payload.get("todos") or [])
        app.agent.set_permission_mode(
            str(payload.get("permission_mode", "default"))
        )
        app.agent.read_history = set(payload.get("read_history") or [])
        app._log(system_dim(
            f"restored to anchor {rest!r} "
            f"({len(app.agent.messages)} messages, "
            f"{len(app.agent.todos)} todos)"
        ))
        return
    if sub == "remove":
        if not rest:
            app._log(error_line("usage: /anchor remove <label>"))
            return
        if reg.remove(rest):
            app._log(system_dim(f"removed anchor {rest!r}"))
        else:
            app._log(error_line(f"no anchor named {rest!r}"))
        return
    app._log(error_line(
        f"unknown subcommand {sub!r}. Try /anchor (list), "
        f"save, restore, remove."
    ))


async def cmd_memory(app: "PrometheusApp", arg: str) -> None:
    """Round 102: Memory Vault — manage persistent knowledge.

    Sub-commands:
      /memory                                 — list discovered memories
      /memory list
      /memory show <name>                     — show body
      /memory save <name> "<description>" - <body>
      /memory remove <name>
    """
    from prometheus.agent.memory_vault import (
        discover_memories, get_memory, save_memory, remove_memory,
    )
    args = arg.strip()
    if not args or args == "list":
        memories = discover_memories(app.settings.workdir)
        if not memories:
            app._log(system_dim("no memories saved"))
            app._log(system_dim(
                "  add files to ~/.prometheus/memory/*.md"
                " (private) or .prometheus/memory/ (project)"
            ))
            return
        app._log(system_dim(f"{len(memories)} memory/memories:"))
        for m in memories:
            stale = " · STALE" if m.is_stale else ""
            app._log(system_dim(
                f"  {m.name:<28} [{m.type}/{m.scope}]{stale}"
            ))
            if m.description:
                app._log(system_dim(f"    {m.description[:80]}"))
        return
    parts = args.split(maxsplit=1)
    sub = parts[0]
    rest = parts[1] if len(parts) > 1 else ""
    if sub == "show":
        if not rest:
            app._log(error_line("usage: /memory show <name>"))
            return
        m = get_memory(app.settings.workdir, rest)
        if m is None:
            app._log(error_line(f"no memory named {rest!r}"))
            return
        app._log(system_dim(f"# {m.name}"))
        app._log(system_dim(f"description: {m.description}"))
        app._log(system_dim(f"type: {m.type}  scope: {m.scope}"))
        if m.is_stale:
            app._log(system_dim(m.stale_warning()))
        app._log(system_dim(""))
        for line in m.body[:1600].splitlines():
            app._log(system_dim(f"  {line}"))
        return
    if sub == "remove":
        if not rest:
            app._log(error_line("usage: /memory remove <name>"))
            return
        if remove_memory(app.settings.workdir, rest):
            app._log(system_dim(f"removed memory {rest!r}"))
        else:
            app._log(error_line(f"no memory named {rest!r}"))
        return
    if sub == "save":
        # Parse: save <name> "<description>" - <body>
        # Lenient: if no " - " separator, body=description.
        if not rest:
            app._log(error_line(
                'usage: /memory save <name> "<description>" - <body>'
            ))
            return
        rest_parts = rest.split(maxsplit=1)
        if len(rest_parts) < 2:
            app._log(error_line(
                'usage: /memory save <name> "<description>" - <body>'
            ))
            return
        name = rest_parts[0]
        tail = rest_parts[1]
        if " - " in tail:
            description, body = tail.split(" - ", 1)
        else:
            description, body = tail, ""
        description = description.strip().strip('"').strip("'")
        body = body.strip()
        try:
            m = save_memory(
                app.settings.workdir,
                name=name, description=description,
                type_="project", body=body, scope="private",
            )
        except ValueError as e:
            app._log(error_line(str(e)))
            return
        app._log(system_dim(f"saved memory {m.name!r} → {m.path}"))
        return
    app._log(error_line(
        f"unknown subcommand {sub!r}. Try /memory (list), "
        f"show, save, remove."
    ))


async def cmd_overseer(app: "PrometheusApp", arg: str) -> None:
    """Round 102: inspect the Overseer classifier.

    Sub-commands:
      /overseer            — show rule counts
      /overseer rules      — list every rule
      /overseer test <tool> <arg>  — show what the classifier
                                     would decide for a call
    """
    from prometheus.safety.overseer import (
        DEFAULT_DENY_RULES, DEFAULT_ALLOW_RULES, evaluate,
    )
    args = arg.strip().split(maxsplit=2)
    sub = args[0] if args else ""
    if not sub or sub == "rules":
        app._log(system_dim(
            f"{len(DEFAULT_DENY_RULES)} deny rules · "
            f"{len(DEFAULT_ALLOW_RULES)} allow rules"
        ))
        if sub == "rules":
            app._log(system_dim(""))
            app._log(system_dim("DENY rules:"))
            for r in DEFAULT_DENY_RULES:
                app._log(system_dim(
                    f"  {r.rule_id:<28} {r.tool_pattern}({r.arg_pattern})"
                ))
            app._log(system_dim(""))
            app._log(system_dim("ALLOW rules:"))
            for r in DEFAULT_ALLOW_RULES:
                app._log(system_dim(
                    f"  {r.rule_id:<28} {r.tool_pattern}({r.arg_pattern})"
                ))
        return
    if sub == "test":
        if len(args) < 3:
            app._log(error_line("usage: /overseer test <tool> <arg>"))
            return
        tool_name = args[1]
        arg_text = args[2]
        # Best-effort arg dict — pick the right key from tool name.
        if tool_name in ("read_file", "write_file", "edit_file"):
            args_d = {"path": arg_text}
        elif tool_name == "run_bash":
            args_d = {"command": arg_text}
        elif tool_name in ("web_fetch", "web_search"):
            args_d = {"url": arg_text}
        else:
            args_d = {"command": arg_text}
        v = evaluate(tool_name, args_d)
        app._log(system_dim(
            f"decision: {v.decision.value}  "
            f"matched: {v.matched_rule or '(no match)'}"
        ))
        if v.reason:
            app._log(system_dim(f"reason: {v.reason}"))
        return
    app._log(error_line(
        f"unknown subcommand {sub!r}. Try /overseer (counts), "
        f"rules, or test <tool> <arg>."
    ))


async def cmd_lsp(app: "PrometheusApp", _arg: str) -> None:
    """Round 102: list configured LSP servers."""
    from prometheus.forge.lsp import discover_lsp_from_forge_kits
    reg = discover_lsp_from_forge_kits(app.settings.workdir)
    if not reg.servers:
        app._log(system_dim("no LSP servers configured"))
        app._log(system_dim(
            '  add `lspServers` to `.prometheus/settings.json`'
        ))
        return
    app._log(system_dim(f"{len(reg.servers)} LSP server(s):"))
    for s in reg.servers:
        exts = ", ".join(sorted(s.extension_to_language.keys())) \
            or "(no extensions)"
        app._log(system_dim(
            f"  {s.name:<16} {s.command} [{s.source}] · {exts}"
        ))


async def cmd_cohorts(app: "PrometheusApp", arg: str) -> None:
    """Round 101 (Phase 4): list / show Cohort definitions.

    Cohorts are specialized autonomous sub-assistants discovered
    from `.prometheus/cohorts/<name>.md` (project, Trust-gated)
    and `~/.prometheus/cohorts/<name>.md` (user). The legacy
    `.prometheus/agents/<name>.md` path is also discovered for
    backwards compatibility.

    Sub-commands:
      /cohorts                  — list all
      /cohorts show <name>      — print body + metadata
    """
    from prometheus.agent.cohorts import (
        discover_cohorts, get_cohort,
    )
    args = arg.strip().split(maxsplit=1)
    sub = args[0] if args else ""
    rest = args[1] if len(args) > 1 else ""
    if sub in ("", "list"):
        cohorts = discover_cohorts(app.settings.workdir)
        if not cohorts:
            app._log(system_dim("no cohorts defined"))
            app._log(system_dim(
                "  add `<workdir>/.prometheus/cohorts/<name>.md`"
                " (project, after /trust)"
            ))
            app._log(system_dim(
                "  or `~/.prometheus/cohorts/<name>.md` (user)"
            ))
            return
        app._log(system_dim(f"{len(cohorts)} cohort(s) discovered:"))
        for c in cohorts:
            iso = " · isolation=worktree" if c.isolation == "worktree" else ""
            bg = " · background" if c.background else ""
            app._log(system_dim(
                f"  {c.name:<24} model={c.model:<10} "
                f"effort={c.effort:<8} [{c.source}]{iso}{bg}"
            ))
            if c.description:
                app._log(system_dim(f"    {c.short_description(80)}"))
        return
    if sub == "show":
        if not rest:
            app._log(error_line("usage: /cohorts show <name>"))
            return
        c = get_cohort(app.settings.workdir, rest)
        if c is None:
            app._log(error_line(f"no cohort named {rest!r}"))
            return
        app._log(system_dim(f"# {c.name}"))
        app._log(system_dim(f"description: {c.description}"))
        app._log(system_dim(
            f"model={c.model} effort={c.effort} max_turns={c.max_turns}"
        ))
        if c.disallowed_tools:
            app._log(system_dim(
                f"disallowed-tools: {', '.join(c.disallowed_tools)}"
            ))
        if c.allowed_tools:
            app._log(system_dim(
                f"allowed-tools: {', '.join(c.allowed_tools)}"
            ))
        if c.skills:
            app._log(system_dim(f"skills: {', '.join(c.skills)}"))
        app._log(system_dim(
            f"memory={c.memory} background={c.background} "
            f"isolation={c.isolation}"
        ))
        app._log(system_dim(""))
        body = c.body[:1600]
        for line in body.splitlines():
            app._log(system_dim(f"  {line}"))
        return
    app._log(error_line(
        f"unknown subcommand {sub!r}. Try /cohorts (list) or "
        f"/cohorts show <name>."
    ))


async def cmd_tasks(app: "PrometheusApp", arg: str) -> None:
    """Round 101: Work Log task list (read-only view).

    Sub-commands:
      /tasks               — list all tasks
      /tasks pending       — filter by status
      /tasks in_progress
      /tasks completed
      /tasks show <id>
    """
    from prometheus.agent.worklog import WorkLog
    args = arg.strip().split(maxsplit=1)
    sub = args[0] if args else ""
    rest = args[1] if len(args) > 1 else ""
    log = WorkLog.load(app.settings.workdir)
    if sub == "show":
        if not rest:
            app._log(error_line("usage: /tasks show <id>"))
            return
        item = log.get(rest)
        if item is None:
            app._log(error_line(f"no task with id {rest!r}"))
            return
        app._log(system_dim(f"id: {item.id}"))
        app._log(system_dim(f"subject: {item.subject}"))
        app._log(system_dim(f"status: {item.status}"))
        app._log(system_dim(f"owner: {item.owner}"))
        app._log(system_dim(f"created_at: {item.created_at}"))
        app._log(system_dim(f"updated_at: {item.updated_at}"))
        if item.description:
            app._log(system_dim(f"description: {item.description}"))
        if item.dependencies:
            app._log(system_dim(
                f"dependencies: {', '.join(item.dependencies)}"
            ))
        if item.notes:
            app._log(system_dim("notes:"))
            for n in item.notes:
                app._log(system_dim(f"  · {n}"))
        return
    status_filter = sub if sub in (
        "pending", "in_progress", "completed", "failed", "cancelled",
    ) else None
    items = log.list(status=status_filter)
    summary = log.summary()
    if not items:
        if status_filter:
            app._log(system_dim(f"no tasks with status {status_filter!r}"))
        else:
            app._log(system_dim("no tasks in the work log"))
            app._log(system_dim(
                "  the model creates tasks via task_create — they"
                " persist in `.prometheus/worklog.json`"
            ))
        return
    app._log(system_dim(
        f"{len(items)} task(s) · {summary.get('pending', 0)} pending,"
        f" {summary.get('in_progress', 0)} in progress,"
        f" {summary.get('completed', 0)} completed"
    ))
    for it in items:
        app._log(system_dim(
            f"  {it.status:<12} {it.id}  {it.owner:<14} {it.subject[:60]}"
        ))


async def cmd_forge(app: "PrometheusApp", arg: str) -> None:
    """Round 100: Forge Kit management.

    Sub-commands:
      /forge                        — list installed kits
      /forge list                   — same as no-arg
      /forge install <path>         — install from a local directory
      /forge install <path> --user  — install under ~/.prometheus
      /forge install <path> --project — install under <workdir>/.prometheus
      /forge activate <name>        — mount a kit's components
      /forge deactivate <name>      — unmount a kit
      /forge uninstall <name>       — remove the kit's directory
      /forge show <name>            — print the manifest summary
    """
    from pathlib import Path as _P
    from prometheus.forge.registry import ForgeRegistry
    args = arg.strip().split()
    sub = args[0] if args else "list"
    workdir = app.settings.workdir
    reg = ForgeRegistry(workdir)
    if sub in ("", "list"):
        kits = reg.installed()
        if not kits:
            app._log(system_dim("no Forge Kits installed"))
            app._log(system_dim(
                "  /forge install <path> to add one"
            ))
            return
        app._log(system_dim(f"{len(kits)} Forge Kit(s) installed:"))
        for k in kits:
            mark = "● active" if k.active else "○ inactive"
            app._log(system_dim(
                f"  {k.name:<24} {k.manifest.version:<10} "
                f"[{k.source}] {mark}"
            ))
            if k.manifest.description:
                app._log(system_dim(f"    {k.manifest.description[:80]}"))
        return
    if sub == "install":
        if len(args) < 2:
            app._log(error_line("usage: /forge install <path> [--project|--user]"))
            return
        scope = "project" if "--project" in args else "user"
        # Path arg is the first non-flag arg after `install`.
        path_arg = next(
            (a for a in args[1:] if not a.startswith("--")),
            None,
        )
        if not path_arg:
            app._log(error_line("usage: /forge install <path>"))
            return
        src = _P(path_arg).expanduser().resolve()
        kit, msg = reg.install_from_path(src, scope=scope)
        app._log(system_dim(msg))
        return
    if sub == "activate":
        if len(args) < 2:
            app._log(error_line("usage: /forge activate <name>"))
            return
        ok, msg = reg.activate(args[1])
        app._log(system_dim(msg) if ok else error_line(msg))
        return
    if sub == "deactivate":
        if len(args) < 2:
            app._log(error_line("usage: /forge deactivate <name>"))
            return
        ok, msg = reg.deactivate(args[1])
        app._log(system_dim(msg) if ok else error_line(msg))
        return
    if sub == "uninstall":
        if len(args) < 2:
            app._log(error_line("usage: /forge uninstall <name>"))
            return
        ok, msg = reg.uninstall(args[1])
        app._log(system_dim(msg) if ok else error_line(msg))
        return
    if sub == "show":
        if len(args) < 2:
            app._log(error_line("usage: /forge show <name>"))
            return
        kit = reg.find(args[1])
        if kit is None:
            app._log(error_line(f"no kit named {args[1]!r}"))
            return
        m = kit.manifest
        app._log(system_dim(f"# {m.display_name}"))
        if m.description:
            app._log(system_dim(f"description: {m.description}"))
        if m.author:
            app._log(system_dim(f"author: {m.author}"))
        if m.license:
            app._log(system_dim(f"license: {m.license}"))
        if m.aptitudes:
            app._log(system_dim(f"aptitudes: {', '.join(m.aptitudes)}"))
        if m.blades:
            app._log(system_dim(f"blades: {', '.join(m.blades)}"))
        if m.cohorts:
            app._log(system_dim(f"cohorts: {', '.join(m.cohorts)}"))
        if m.mcp_servers:
            app._log(system_dim(
                f"mcp servers: {', '.join(sorted(m.mcp_servers.keys()))}"
            ))
        if m.lsp_servers:
            app._log(system_dim(
                f"lsp servers: {', '.join(sorted(m.lsp_servers.keys()))}"
            ))
        return
    app._log(error_line(
        f"unknown subcommand {sub!r}. Try /forge (list), "
        f"install, activate, deactivate, uninstall, show."
    ))


async def cmd_foundry(app: "PrometheusApp", arg: str) -> None:
    """Round 100: Foundry marketplace.

    Sub-commands:
      /foundry add <name> <url>   — register a Foundry catalog
      /foundry list                — show registered Foundries
      /foundry search <query>      — search across registered Foundries
      /foundry install <kit-name>  — install a kit by name (uses
                                     the first matching foundry)
      /foundry remove <name>       — unregister a Foundry
    """
    from prometheus.forge.foundry import (
        FoundryIndex, fetch_foundry, search_all,
    )
    from prometheus.forge.registry import ForgeRegistry
    from pathlib import Path as _P
    args = arg.strip().split(maxsplit=2)
    sub = args[0] if args else "list"
    if sub == "add":
        if len(args) < 3:
            app._log(error_line("usage: /foundry add <name> <url>"))
            return
        idx = FoundryIndex.load()
        ok, msg = idx.add(args[1], args[2])
        app._log(system_dim(msg) if ok else error_line(msg))
        return
    if sub in ("", "list"):
        idx = FoundryIndex.load()
        if not idx.foundries:
            app._log(system_dim("no foundries registered"))
            app._log(system_dim("  /foundry add <name> <url>"))
            return
        app._log(system_dim(f"{len(idx.foundries)} foundry/foundries:"))
        for f in idx.foundries:
            mark = "" if f.enabled else " (disabled)"
            app._log(system_dim(f"  {f.name:<24} {f.url}{mark}"))
        return
    if sub == "search":
        if len(args) < 2:
            app._log(error_line("usage: /foundry search <query>"))
            return
        query = " ".join(args[1:])
        results = search_all(query)
        if not results:
            app._log(system_dim(f"no kits match {query!r}"))
            return
        for foundry, kits in results:
            app._log(system_dim(f"# {foundry.name}"))
            for k in kits:
                app._log(system_dim(
                    f"  {k.name:<24} {k.version:<8} {k.description[:60]}"
                ))
        return
    if sub == "install":
        if len(args) < 2:
            app._log(error_line("usage: /foundry install <kit-name>"))
            return
        target = args[1]
        results = search_all(target)
        match = None
        for foundry, kits in results:
            for k in kits:
                if k.name == target:
                    match = k
                    break
            if match:
                break
        if match is None:
            app._log(error_line(f"no kit named {target!r} in any foundry"))
            return
        # Install from the kit's source path. URLs/git are stubbed
        # for round 100; local paths work today.
        src = _P(match.source).expanduser()
        if not src.is_absolute():
            # Resolve relative to the foundry source if possible.
            src = src.resolve()
        reg = ForgeRegistry(app.settings.workdir)
        kit, msg = reg.install_from_path(src)
        app._log(system_dim(msg) if kit else error_line(msg))
        return
    if sub == "remove":
        if len(args) < 2:
            app._log(error_line("usage: /foundry remove <name-or-url>"))
            return
        idx = FoundryIndex.load()
        ok, msg = idx.remove(args[1])
        app._log(system_dim(msg) if ok else error_line(msg))
        return
    app._log(error_line(
        f"unknown subcommand {sub!r}. Try /foundry (list), "
        f"add, search, install, remove."
    ))


async def cmd_sentinels(app: "PrometheusApp", _arg: str) -> None:
    """Round 99: list configured Sentinels.

    Sentinels load from `.prometheus/sentinels.json` (project,
    Trust-gated), `~/.prometheus/sentinels.json` (user), enterprise
    paths (POSIX `/etc/prometheus/sentinels.json`), and the legacy
    `hooks.json` files. Each Sentinel is one of five types
    (command, http, prompt, mcp_tool, agent) and fires on one of
    28 lifecycle events.
    """
    reg = getattr(app, "sentinel_registry", None)
    if reg is None:
        # Try to load now in case on_mount hasn't run yet (test path).
        try:
            from prometheus.safety.sentinels import load_sentinels
            reg = load_sentinels(app.settings.workdir)
        except Exception:
            app._log(error_line("could not load sentinels"))
            return
    if not reg.sentinels:
        app._log(system_dim("no sentinels configured"))
        app._log(system_dim(
            "  add `.prometheus/sentinels.json` (project, after /trust)"
        ))
        app._log(system_dim(
            "  or `~/.prometheus/sentinels.json` (user)"
        ))
        return
    app._log(system_dim(f"{len(reg.sentinels)} sentinel(s) loaded:"))
    for s in reg.sentinels:
        once = " · once-per-session" if s.once_per_session else ""
        app._log(system_dim(
            f"  {s.event.value:<22} {s.type.value:<10} "
            f"matcher={s.matcher.pattern!r:<22} [{s.source}]{once}"
        ))


async def cmd_aptitude(app: "PrometheusApp", arg: str) -> None:
    """Round 98: Aptitude management.

    Sub-commands:
      /aptitude                — list all discovered Aptitudes
      /aptitude show <name>    — show full body of one Aptitude
      /aptitude where <name>   — print the file path
      /aptitude run <name>     — explicitly load + activate one
                                 (force-load Tier 2 body for the
                                 next turn, bypassing trigger match)

    Aptitudes are extensible expertise packages following the Agent
    Skills open standard. Discovery looks in
    `<workdir>/.prometheus/aptitudes/`,
    `<workdir>/.prometheus/skills/` (legacy),
    `~/.prometheus/aptitudes/`,
    and `~/.prometheus/skills/` (legacy).
    """
    from prometheus.agent.aptitudes import (
        discover_aptitudes, get_aptitude,
    )
    workdir = app.settings.workdir
    args = arg.strip().split(maxsplit=1)
    sub = args[0] if args else ""
    rest = args[1] if len(args) > 1 else ""
    if not sub:
        # Default: list.
        aptitudes = discover_aptitudes(workdir)
        if not aptitudes:
            app._log(system_dim("no aptitudes found"))
            app._log(system_dim(
                "  add a folder under ~/.prometheus/aptitudes/<name>/"
                " with APTITUDE.md inside"
            ))
            app._log(system_dim(
                "  or .prometheus/aptitudes/<name>/ in the workdir"
                " (after /trust)"
            ))
            app._log(system_dim(
                "  legacy `.md` files under skills/ also work"
            ))
            return
        app._log(system_dim(f"{len(aptitudes)} aptitude(s) discovered:"))
        for a in aptitudes:
            triggers = (
                ", ".join(a.triggers[:5]) if a.triggers else "always-on"
            )
            disabled = " (model-invocation disabled)" \
                if a.disable_model_invocation else ""
            scope = f"[{a.source}]"
            app._log(system_dim(
                f"  {a.name:<24} {scope:<10} {a.short_purpose(60)}"
                f"{disabled}"
            ))
            app._log(system_dim(f"    triggers: {triggers}"))
        app._log(system_dim(
            "  /aptitude show <name>  · show body"
        ))
        app._log(system_dim(
            "  /aptitude where <name> · show path"
        ))
        app._log(system_dim(
            "  /aptitude run <name>   · activate next turn"
        ))
        return
    if sub == "show":
        if not rest:
            app._log(error_line("usage: /aptitude show <name>"))
            return
        a = get_aptitude(workdir, rest)
        if a is None:
            app._log(error_line(f"no aptitude named {rest!r}"))
            return
        app._log(system_dim(f"# {a.name}"))
        app._log(system_dim(f"purpose: {a.purpose}"))
        if a.triggers:
            app._log(system_dim(
                f"triggers: {', '.join(a.triggers)}"
            ))
        if a.allowed_tools:
            app._log(system_dim(
                f"allowed-tools: {', '.join(a.allowed_tools)}"
            ))
        if a.dependencies:
            app._log(system_dim(
                f"dependencies: {', '.join(a.dependencies)}"
            ))
        resources = a.list_resources()
        for label, files in resources.items():
            app._log(system_dim(
                f"{label}/: {', '.join(files[:6])}"
                + (f" (+{len(files) - 6} more)" if len(files) > 6 else "")
            ))
        app._log(system_dim(""))
        # Body — surfaced verbatim. Cap so the chat doesn't drown
        # in a 5KB blob; user can /aptitude where + read for full.
        body = a.body[:1600]
        for line in body.splitlines():
            app._log(system_dim(f"  {line}"))
        if len(a.body) > 1600:
            app._log(system_dim(
                f"  … ({len(a.body) - 1600} more chars; "
                f"`/aptitude where {a.name}` for full path)"
            ))
        return
    if sub == "where":
        if not rest:
            app._log(error_line("usage: /aptitude where <name>"))
            return
        a = get_aptitude(workdir, rest)
        if a is None:
            app._log(error_line(f"no aptitude named {rest!r}"))
            return
        app._log(system_dim(str(a.path)))
        return
    if sub == "run":
        if not rest:
            app._log(error_line("usage: /aptitude run <name>"))
            return
        a = get_aptitude(workdir, rest)
        if a is None:
            app._log(error_line(f"no aptitude named {rest!r}"))
            return
        # Force-activation: stash the chosen aptitude name on the
        # AgentLoop so the next `_ensure_system` call pulls its
        # full body in even without a trigger match. The loop
        # clears the list after building the system prompt so the
        # boost is one-shot.
        if app.agent is None:
            app._log(error_line(
                "agent not initialized; /aptitude run needs an "
                "active session"
            ))
            return
        app.agent.forced_aptitudes.append(a.name)
        app._log(system_dim(
            f"aptitude {a.name!r} activated for the next turn "
            f"({len(a.body)} body chars)"
        ))
        return
    app._log(error_line(
        f"unknown subcommand {sub!r}. Try /aptitude (list), "
        f"/aptitude show <name>, /aptitude where <name>, or "
        f"/aptitude run <name>"
    ))


async def cmd_statusline(app: "PrometheusApp", arg: str) -> None:
    """Manage the shell-driven custom statusline."""
    arg = arg.strip().lower()
    runner = getattr(app, "_statusline_runner", None)
    if runner is None:
        app._log(error_line("statusline runner not initialized"))
        return
    if arg == "reload":
        runner.reload(app)
        app._log(system_dim("statusline reloaded"))
        return
    if arg == "off":
        runner.stop()
        runner.disabled = True
        app._log(system_dim("statusline disabled"))
        return
    # Status report.
    from prometheus.ui.statusline import _script_path
    path = _script_path()
    if path is None:
        app._log(system_dim("no statusline script found"))
        app._log(system_dim("  create ~/.prometheus/statusline.sh (or .ps1 on Windows)"))
        app._log(system_dim("  it runs every 5s; first stdout line goes to the bar"))
        return
    state = "disabled" if runner.disabled else "running"
    app._log(system_dim(f"script:    {path}"))
    app._log(system_dim(f"state:     {state}"))
    app._log(system_dim(f"last out:  {runner.last_output or '(none yet)'}"))
    app._log(system_dim("  /statusline reload  → re-enable & reread script"))
    app._log(system_dim("  /statusline off     → disable until next /reload"))


async def cmd_escalate(app: "PrometheusApp", arg: str) -> None:
    """Route the NEXT turn to a stronger paid model instead of the free chain.

    Usage:
        /escalate            — Premium tier (cheapest paid; ~$0.004/turn typical)
        /escalate --mid      — Premium+ tier (~4× cost, mid capability)
        /escalate --hard     — Premium Max tier (~20× cost, most capable)

    Requires a premium API key in your environment. Cost is tracked in
    /credits; daily spend honored via PROMETHEUS_DAILY_USD_LIMIT.

    Credit-conservation default: bare /escalate uses the cheapest paid
    tier (Premium). This stretches a small budget roughly 4× longer for
    users who don't explicitly pick a higher tier.
    """
    if not app.agent:
        app._log(error_line("agent not ready"))
        return
    if not os.getenv("ANTHROPIC_API_KEY"):
        app._log(error_line(
            "escalation requires an upstream API key (ANTHROPIC_API_KEY) "
            "in your environment. Add it to .env or export it before launch."
        ))
        return
    arg_low = arg.lower()
    hard = "--hard" in arg_low or " -h" in (" " + arg_low) or arg_low.strip() == "-h"
    mid = "--mid" in arg_low
    app.agent.escalation.escalate_next_turn = True
    app.agent.escalation.next_turn_hard = hard
    app.agent.escalation.next_turn_sonnet = mid and not hard
    if hard:
        tier = "PrometheUS Premium Max"
    elif mid:
        tier = "PrometheUS Premium+"
    else:
        tier = "PrometheUS Premium"
    app._log(system_dim(
        f"next turn → {tier} · cost counts toward your daily cap"
    ))


async def cmd_byok(app: "PrometheusApp", arg: str) -> None:
    """Set or clear your own escalation API key for this session.

    Usage:
        /byok sk-ant-...     route paid escalations through YOUR key
                              (escalations no longer count against the
                               pooled daily cap)
        /byok off            revert to the pooled key (env var)
        /byok status         show whether a user key is active

    Round-13 cost-conservation feature. The key is in-memory only —
    it is NEVER persisted to disk and is dropped when the app exits.
    """
    arg = arg.strip()
    if arg == "status":
        active = bool(getattr(app, "_user_premium_key", None))
        app._log(system_dim(
            "user key active (escalations bill to YOUR account)"
            if active else "using pooled key"
        ))
        return
    if arg in ("off", "clear", ""):
        if getattr(app, "_user_premium_key", None):
            app._user_premium_key = None
            # Drop the cached client so the next escalation rebuilds
            # against the pooled key.
            if app.agent and hasattr(app.agent, "_escalation_client"):
                app.agent._escalation_client = None
            app._log(system_dim("reverted to pooled key"))
        else:
            app._log(error_line("usage: /byok <sk-...> or /byok off"))
        return
    if not (arg.startswith("sk-") or arg.startswith("api-")):
        app._log(error_line(
            "expected a valid escalation API key (starts with sk-…)."
        ))
        return
    app._user_premium_key = arg
    if app.agent and hasattr(app.agent, "_escalation_client"):
        app.agent._escalation_client = None
    app._log(system_dim(
        "user key set for this session — escalations bill to YOUR account, "
        "not the pooled cap. Key is in-memory only; not persisted."
    ))


async def cmd_credits(app: "PrometheusApp", _arg: str) -> None:
    """Show running spend across providers + escalation status."""
    cost = float(getattr(app, "_cost_total_usd", 0.0) or 0.0)
    cap = float(os.getenv("PROMETHEUS_DAILY_USD_LIMIT", "0") or 0)
    has_key = bool(os.getenv("ANTHROPIC_API_KEY"))
    next_esc = (
        app.agent.escalation.escalate_next_turn
        if app.agent and hasattr(app.agent, "escalation") else False
    )
    app._log(system_dim(f"running cost: ${cost:.4f}"))
    app._log(system_dim(f"tokens: ↑{app._tokens_total_in} ↓{app._tokens_total_out}"))
    if cap > 0:
        pct = int(min(100, cost * 100 / cap)) if cap else 0
        app._log(system_dim(f"daily cap: ${cap:.2f}  ({pct}% used)"))
    else:
        app._log(system_dim("daily cap: unset (set PROMETHEUS_DAILY_USD_LIMIT)"))
    app._log(system_dim(
        f"paid escalation: {'available' if has_key else 'unavailable (no key)'}"
    ))
    if next_esc:
        app._log(system_dim("next turn → paid tier (one-shot escalation armed)"))


async def cmd_trust(app: "PrometheusApp", arg: str) -> None:
    """Mark the current workdir (or a given path) as trusted.

    Trust grants permission to load `.prometheus/hooks.json`,
    `.prometheus/settings.json`, and `.prometheus/commands/*.md` from
    that directory. Without trust, project-local config is ignored —
    the defense against the CVE-2025-59536 attack class where a hostile
    repo ships executable config that auto-runs on first open.
    """
    from prometheus.safety.trust import trust, is_trusted
    target = Path(arg.strip()) if arg.strip() else app.settings.workdir
    if not target.exists() or not target.is_dir():
        app._log(error_line(f"not a directory: {target}"))
        return
    if is_trusted(target):
        app._log(system_dim(f"already trusted: {target}"))
        return
    trust(target)
    app._log(system_dim(f"✓ trusted: {target}"))
    app._log(system_dim("project-local hooks / settings / commands will load on next session"))


async def cmd_untrust(app: "PrometheusApp", arg: str) -> None:
    from prometheus.safety.trust import untrust, list_trusted
    target = Path(arg.strip()) if arg.strip() else app.settings.workdir
    if not arg.strip() and not list_trusted():
        app._log(system_dim("no directories are currently trusted"))
        return
    untrust(target)
    app._log(system_dim(f"✓ untrusted: {target}"))


async def cmd_trusted_list(app: "PrometheusApp", _arg: str) -> None:
    """Show the list of trusted directories."""
    from prometheus.safety.trust import list_trusted, is_trusted
    rows = list_trusted()
    if not rows:
        app._log(system_dim("no directories trusted yet · use /trust to grant"))
        return
    here = is_trusted(app.settings.workdir)
    app._log(system_dim(f"trusted directories ({len(rows)}):"))
    for r in rows:
        app._log(system_dim(f"  {r}"))
    app._log(system_dim(f"current workdir trusted: {'yes' if here else 'no'}"))


_HTML_TEMPLATE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<title>PrometheUS session {sid}</title>
<style>
 body{{font:14px/1.5 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
       background:#1a1a1a;color:#e6e6e6;max-width:48rem;margin:2rem auto;padding:0 1rem}}
 h1{{font-size:1rem;color:#d77757;font-weight:600;border-bottom:1px solid #333;padding-bottom:.5rem}}
 .role{{margin-top:1.2rem;font-weight:600}}
 .user .role{{color:#9ec5ff}}
 .assistant .role{{color:#e6a85c}}
 .tool .role{{color:#888}}
 .system .role{{color:#666}}
 pre{{background:#222;padding:.6rem .8rem;border-radius:4px;overflow-x:auto;
      white-space:pre-wrap;word-wrap:break-word}}
 .meta{{color:#666;font-size:.8rem;margin-bottom:1.5rem}}
</style></head><body>
<h1>PrometheUS session {sid}</h1>
<div class="meta">{n_messages} messages · exported {ts}</div>
{body}
</body></html>"""


def _render_html_transcript(session_id: str, messages: list[dict]) -> str:
    """Build a self-contained HTML page from the agent's message list."""
    import html as _h
    from datetime import datetime as _dt
    parts: list[str] = []
    n_visible = 0
    for m in messages:
        role = m.get("role", "?")
        if role == "system":
            continue
        n_visible += 1
        content = str(m.get("content") or "")
        parts.append(
            f'<div class="msg {role}">'
            f'<div class="role">{role}</div>'
            f'<pre>{_h.escape(content)}</pre>'
            f'</div>'
        )
    return _HTML_TEMPLATE.format(
        sid=_h.escape(session_id),
        body="\n".join(parts),
        n_messages=n_visible,
        ts=_dt.now().strftime("%Y-%m-%d %H:%M"),
    )


async def cmd_export(app: "PrometheusApp", arg: str) -> None:
    """Export the conversation as Markdown (.md) or HTML (.html).

    HTML mode produces a self-contained page (CSS inline, no external
    assets) that's safe to paste into Slack-share / gist / email and
    looks like the in-terminal transcript. The format is picked from
    the file extension; default is `.md`.
    """
    raw = arg.strip() or f"prometheus-session-{app.session_id[:8]}.md"
    pp = Path(raw)
    # Confine: absolute paths must be under HOME or workdir; relative
    # paths land under workdir. A user pasting `/export /etc/passwd`
    # should NOT silently overwrite system files when running as root.
    if pp.is_absolute():
        try:
            home = Path.home().resolve()
            workdir = app.settings.workdir.resolve()
            absp = pp.resolve()
            if not (str(absp).startswith(str(home)) or str(absp).startswith(str(workdir))):
                app._log(error_line(f"refused: {pp} is outside ~ and the workdir"))
                return
            target = absp
        except Exception:
            app._log(error_line("refused: invalid path"))
            return
    else:
        target = (app.settings.workdir / pp).resolve()
    if not app.agent:
        return
    if target.suffix.lower() in (".html", ".htm"):
        body = _render_html_transcript(app.session_id, app.agent.messages)
    else:
        lines = [f"# session {app.session_id}", ""]
        for m in app.agent.messages:
            if m.get("role") == "system":
                continue
            lines.append(f"## {m.get('role')}")
            lines.append(str(m.get("content") or ""))
            lines.append("")
        body = "\n".join(lines)
    target.write_text(body, encoding="utf-8")
    app._log(system_dim(f"exported → {target}"))


async def cmd_transcript(app: "PrometheusApp", arg: str) -> None:
    """Convenience: /transcript → exports an .html file by default."""
    fname = arg.strip() or f"prometheus-transcript-{app.session_id[:8]}.html"
    if not fname.lower().endswith((".html", ".htm", ".md")):
        fname += ".html"
    await cmd_export(app, fname)


async def cmd_review(app: "PrometheusApp", _arg: str) -> None:
    # Drives the agent with a focused review prompt.
    await app._run_agent("Review the pending changes on the current branch. Use git diff and grep tools. Call out bugs, security issues, missing tests, and unclear naming. Be terse.")


async def cmd_commit_msg(app: "PrometheusApp", _arg: str) -> None:
    await app._run_agent("Look at the staged git diff (git diff --cached) and propose a single commit message: a short imperative subject line under 70 chars, then a blank line, then a 1-2 line body explaining why.")


async def cmd_commit(app: "PrometheusApp", arg: str) -> None:
    """Round-16 WOW: stage every modified file in the workdir and create a
    semantic commit. With a message argument, commits with that message
    verbatim; without, asks the agent to draft a message from the diff
    and commit in a single shot. Commit-per-edit ergonomics on user demand."""
    msg = arg.strip()
    if msg:
        await app._run_agent(
            f"Run `git add -A` then `git commit -m {msg!r}` in the workdir. "
            f"If git is unavailable or there's nothing to commit, report it briefly."
        )
    else:
        await app._run_agent(
            "Stage all changed files (`git add -A`), then look at the staged "
            "diff, propose a short imperative commit subject (<70 chars), and "
            "run `git commit -m <subject>` to commit. Don't ask me to confirm "
            "the message — pick a reasonable one and commit. If there's "
            "nothing to commit, say so and stop."
        )


async def cmd_worktree(app: "PrometheusApp", arg: str) -> None:
    """Round-18 WOW: native git-worktree parallel agents.

    Spawns a fresh git worktree on a new branch, then dispatches an
    /async agent against it. Lets the user run 2-4 agents in parallel
    on different experiments without any cloud handoff and without
    polluting the main checkout.

    Usage:
        /worktree feature-x      "implement the X feature"
        /worktree refactor-auth  "rewrite middleware in auth/"

    Trees are created under `<workdir>/.prometheus-worktrees/<name>/`.
    """
    parts = arg.strip().split(maxsplit=1)
    if len(parts) < 2:
        app._log(error_line(
            "usage: /worktree <branch-name> <prompt for the agent>"
        ))
        return
    name, prompt = parts[0], parts[1]
    # Sanitize branch name to a kebab-case slug — git is strict about
    # what it accepts in a ref, and we want predictable directory paths.
    import re as _re
    slug = _re.sub(r"[^a-zA-Z0-9._-]+", "-", name).strip("-").lower() or "agent"
    if not slug:
        app._log(error_line("worktree name resolved to empty after sanitize"))
        return
    workdir = app.settings.workdir
    wt_root = workdir / ".prometheus-worktrees"
    wt_path = wt_root / slug
    branch = f"prom/{slug}"
    if wt_path.exists():
        app._log(error_line(
            f"worktree {wt_path.name} already exists — pick another name "
            f"or `git worktree remove {wt_path}`"
        ))
        return
    # Create worktree on a fresh branch off the current HEAD.
    setup_prompt = (
        f"Run these commands in order; if any fails, stop and report:\n"
        f"  mkdir -p {wt_root}\n"
        f"  git worktree add -b {branch} {wt_path} HEAD\n"
        f"Then say exactly: WORKTREE_READY"
    )
    await app._run_agent(setup_prompt)
    # Dispatch the actual work via /async on the new worktree.
    if not hasattr(app, "async_jobs"):
        app._log(system_dim(
            f"worktree {wt_path} created on branch {branch}; run "
            f"/async with cwd={wt_path} to dispatch work"
        ))
        return
    job_prompt = (
        f"You are operating inside a fresh git worktree at "
        f"{wt_path} on branch {branch}. Workdir is set there. "
        f"Task: {prompt}\n\n"
        f"When you're done, run `git status` and `git diff --stat` "
        f"so the user can review on the main thread."
    )
    try:
        job = app.async_jobs.start(prompt=job_prompt)
        app._log(system_dim(
            f"⏺︎ worktree {slug} → branch {branch} → job {job.job_id} "
            f"(/jobs to monitor)"
        ))
    except Exception as e:
        app._log(error_line(f"worktree dispatch failed: {e}"))


async def cmd_typecheck(app: "PrometheusApp", _arg: str) -> None:
    """Round-19: detect and run the project's static type checker.

    Auto-detects: tsc (tsconfig.json), pyright (pyrightconfig.json /
    pyproject [tool.pyright]), mypy (mypy.ini / [tool.mypy]), cargo
    check (Cargo.toml), go vet (go.mod). Falls back to ruff check
    for Python projects without a dedicated typechecker.

    Useful as a final pass after a multi-file edit — the agent fixes
    its own errors rather than waiting for the user's CI to fail.
    """
    workdir = app.settings.workdir
    cmd: str | None = None
    detected = ""
    if (workdir / "tsconfig.json").exists():
        cmd, detected = "npx --no-install tsc --noEmit", "tsc"
    elif (workdir / "pyrightconfig.json").exists():
        cmd, detected = "pyright", "pyright"
    elif (workdir / "mypy.ini").exists():
        cmd, detected = "mypy .", "mypy"
    elif (workdir / "Cargo.toml").exists():
        cmd, detected = "cargo check --quiet --all-targets", "cargo check"
    elif (workdir / "go.mod").exists():
        cmd, detected = "go vet ./...", "go vet"
    elif (workdir / "pyproject.toml").exists():
        try:
            body = (workdir / "pyproject.toml").read_text(encoding="utf-8")
            if "[tool.pyright]" in body:
                cmd, detected = "pyright", "pyright"
            elif "[tool.mypy]" in body:
                cmd, detected = "mypy .", "mypy"
            else:
                cmd, detected = "ruff check .", "ruff (no typechecker found)"
        except OSError:
            pass
    if not cmd:
        app._log(system_dim(
            "no typechecker auto-detected — add tsconfig.json / "
            "pyrightconfig.json / mypy.ini / Cargo.toml / go.mod"
        ))
        return
    app._log(system_dim(f"⏺︎ {detected} → {cmd}"))
    await app._run_agent(
        f"Run `{cmd}` via run_bash with a 90s cap. Read the output, "
        f"identify the 5 most actionable errors (file:line + message), "
        f"and propose specific fixes. Do NOT modify files unless the "
        f"user asks. End with TYPECHECK COMPLETE — N errors."
    )


async def cmd_visual(app: "PrometheusApp", arg: str) -> None:
    """Round-19 WOW: visual testing loop. Launches headless Playwright,
    screenshots the URL, hands the image to the vision-capable engine
    along with the user's natural-language assertion. Lets the agent
    "see" what it just built without leaving the TUI.

    Usage:
        /visual http://localhost:3000
        /visual http://localhost:3000  the login button should be blue

    Requires `pip install playwright` + `playwright install chromium`.
    Falls through to a clear error if either is missing — no implicit
    install. The screenshot is saved under
    `<workdir>/.prometheus/screenshots/<unix>.png` so the user can
    refer back to it.
    """
    parts = arg.strip().split(maxsplit=1)
    if not parts:
        app._log(error_line(
            "usage: /visual <url> [assertion in plain English]"
        ))
        return
    url = parts[0]
    assertion = parts[1] if len(parts) > 1 else "describe what you see"
    if not url.startswith(("http://", "https://")):
        app._log(error_line("url must be http(s)://"))
        return
    try:
        from playwright.async_api import async_playwright  # type: ignore
    except ImportError:
        app._log(error_line(
            "playwright not installed — `pip install \"prometheus-cli[visual]\"` "
            "or `pip install playwright && playwright install chromium`"
        ))
        return
    import time as _time
    out_dir = app.settings.workdir / ".prometheus" / "screenshots"
    try:
        out_dir.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        app._log(error_line(f"can't create screenshots dir: {e}"))
        return
    target = out_dir / f"{int(_time.time())}.png"
    app._log(system_dim(f"⏺︎ launching headless chromium → {url}"))
    try:
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()
            await page.goto(url, timeout=15_000, wait_until="networkidle")
            await page.screenshot(path=str(target), full_page=True)
            await browser.close()
    except Exception as e:
        app._log(error_line(f"playwright failed: {e}"))
        return
    app._log(system_dim(f"⏺︎ screenshot → {target}"))
    # Hand off to the vision engine via the agent.
    prompt = (
        f"Read the image at {target}. The user's assertion is:\n"
        f'  "{assertion}"\n\n'
        f"Inspect the screenshot. If the assertion holds, reply "
        f"VERIFIED with 1-2 supporting observations. If it fails, "
        f"reply FAILED and explain what you actually see."
    )
    await app._run_agent(prompt)


async def cmd_share(app: "PrometheusApp", _arg: str) -> None:
    """Round-19: read-only session export to a static HTML file under
    `<workdir>/.prometheus/shares/<sid>-<unix>.html`. Privacy-first —
    nothing leaves the user's machine. The user can then sftp / scp /
    paste-attach the file to share the session as evidence (audit
    trail, support ticket, blog post screenshot)."""
    from pathlib import Path
    import time as _time
    if not app.agent or not app.agent.messages:
        app._log(error_line("nothing to share — empty session"))
        return
    out_dir = app.settings.workdir / ".prometheus" / "shares"
    try:
        out_dir.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        app._log(error_line(f"can't create shares dir: {e}"))
        return
    fname = f"{app.session_id[:8]}-{int(_time.time())}.html"
    target = out_dir / fname
    body = _render_html_transcript(app.session_id, app.agent.messages)
    try:
        from prometheus.tools.files import _atomic_write_text
        _atomic_write_text(target, body)
    except Exception as e:
        app._log(error_line(f"write failed: {e}"))
        return
    app._log(system_dim(
        f"shared → {target}\n"
        f"  open with: file://{target}\n"
        f"  attach to a support ticket / paste into a PR / commit it"
    ))


async def cmd_implement(app: "PrometheusApp", arg: str) -> None:
    """Round-18 WOW: issue-driven dev. Pulls a Linear / Jira / GitHub
    ticket, creates a branch, opens a plan, asks the user to confirm
    before code starts.

    Usage:
        /implement github:owner/repo#123    — public GitHub issue
        /implement linear:ENG-4521          — Linear ticket
        /implement jira:PROJ-1234           — Jira ticket
        /implement <free-text spec>         — free-text fallback

    GitHub public issues are read directly via web_fetch. Linear/Jira
    require the user to have the relevant CLI authed (we just shell
    out and let the model paste the body into the plan). Use
    `/byok` or env tokens to wire private repos / non-public issues.
    """
    spec = arg.strip()
    if not spec:
        app._log(error_line(
            "usage: /implement github:owner/repo#123  or  /implement <free-text spec>"
        ))
        return
    if spec.startswith("github:"):
        ref = spec[len("github:"):].strip()
        prompt = (
            f"Issue-driven dev for GitHub issue {ref}.\n\n"
            f"1. Fetch https://api.github.com/repos/{ref.split('#')[0]}/issues/{ref.split('#')[1]} via web_fetch.\n"
            f"2. Read the title + body.\n"
            f"3. Run `git checkout -b implement-{ref.split('#')[1]}`.\n"
            f"4. Write a 5-bullet plan with file paths + acceptance criteria. STOP. Do NOT write code yet."
        )
    elif spec.startswith("linear:"):
        ticket = spec[len("linear:"):].strip()
        prompt = (
            f"Issue-driven dev for Linear ticket {ticket}.\n\n"
            f"1. Try `linear issue view {ticket}` (Linear CLI) via run_bash. "
            f"If unavailable or unauthed, ask the user to paste the body.\n"
            f"2. Run `git checkout -b implement-{ticket.lower()}`.\n"
            f"3. Write a 5-bullet plan with file paths + acceptance criteria. STOP."
        )
    elif spec.startswith("jira:"):
        ticket = spec[len("jira:"):].strip()
        prompt = (
            f"Issue-driven dev for Jira ticket {ticket}.\n\n"
            f"1. Try `jira issue view {ticket}` via run_bash. If unavailable, "
            f"ask the user to paste the body.\n"
            f"2. Run `git checkout -b implement-{ticket.lower()}`.\n"
            f"3. Write a 5-bullet plan with file paths + acceptance criteria. STOP."
        )
    else:
        prompt = (
            f"Issue-driven dev — free-text spec.\n\n"
            f"Spec: {spec}\n\n"
            f"1. Pick a short kebab-case branch name from the spec.\n"
            f"2. `git checkout -b implement-<that-name>`.\n"
            f"3. Write a 5-bullet plan with file paths + acceptance criteria. STOP."
        )
    await app._run_agent(prompt)


async def cmd_verify(app: "PrometheusApp", arg: str) -> None:
    """Round-17 WOW: verifier subagent. Re-checks the most recent
    assistant output against the most recent user request. The
    power-user community calls this "the single most impactful tip"
    for catching agent regressions — half-finished refactors, missed
    edge cases, files that were planned but never written.

    Usage:
        /verify              — re-verify against the most recent user
                                turn
        /verify <criteria>   — append extra success criteria the
                                verifier should check (e.g.
                                "tests pass" or "no Pydantic v1 imports")
    """
    if not app.agent:
        return
    msgs = [m for m in app.agent.messages if m.get("role") in ("user", "assistant")]
    last_user = next((m for m in reversed(msgs) if m.get("role") == "user"), None)
    last_assist = next(
        (m for m in reversed(msgs) if m.get("role") == "assistant"),
        None,
    )
    if last_user is None or last_assist is None:
        app._log(system_dim("nothing to verify yet"))
        return
    def _flatten(m: dict) -> str:
        c = m.get("content")
        if isinstance(c, str):
            return c
        if isinstance(c, list):
            return " ".join(
                str(b.get("text", "")) for b in c if isinstance(b, dict)
            )
        return str(c or "")
    user_text = _flatten(last_user)[:1500]
    assist_text = _flatten(last_assist)[:1500]
    extra = arg.strip()
    extra_block = f"\n\nAdditional criteria from the user: {extra}" if extra else ""
    prompt = (
        "Act as a verifier. Re-check the most recent assistant turn "
        "against the user's request. List EVERY missed requirement, "
        "half-finished change, or untested claim — verbatim, terse "
        "bullets. If everything is covered, reply with the single "
        "word: VERIFIED.\n\n"
        f"USER REQUESTED:\n{user_text}\n\n"
        f"ASSISTANT REPLIED:\n{assist_text}{extra_block}\n\n"
        "Use file-reading tools if you need to inspect actual file "
        "state (don't trust the assistant's claims). Don't re-do the "
        "work — only verify."
    )
    await app._run_agent(prompt)


async def cmd_revert(app: "PrometheusApp", arg: str) -> None:
    """Round-16 WOW: revert the most recent commit. Runs `git revert HEAD
    --no-edit`. With an argument like `HEAD~2`, reverts that ref instead.
    Pairs with /commit so a user can experiment freely and roll back any
    change in one keystroke."""
    target = arg.strip() or "HEAD"
    await app._run_agent(
        f"Run `git revert {target} --no-edit` in the workdir. If the target "
        f"is already reverted or git refuses (uncommitted changes), report "
        f"the error verbatim and stop without retrying."
    )


async def cmd_tests(app: "PrometheusApp", arg: str) -> None:
    target = arg.strip() or "the current changes"
    await app._run_agent(f"Write tests for {target}. Read the relevant files first, then write a test file using the project's existing framework.")


async def cmd_mouse(app: "PrometheusApp", arg: str) -> None:
    """Toggle terminal mouse capture.

    /mouse off   — terminal owns the mouse (default; enables drag-select + copy)
    /mouse on    — Textual owns the mouse (click-to-focus, scroll wheel)
    /mouse       — show current state
    """
    arg = arg.strip().lower()
    state = getattr(app, "_mouse_capture", "off")
    if not arg:
        app._log(system_dim(f"mouse capture: {state}"))
        app._log(system_dim("  off   terminal-native drag-select + copy (default)"))
        app._log(system_dim("  on    Textual click-to-focus + scroll wheel"))
        return
    if arg == "off":
        app._disable_mouse_capture()
        app._mouse_capture = "off"
        app._log(system_dim("mouse → off · use mouse drag to select, Ctrl+Shift+C / Cmd+C to copy"))
    elif arg == "on":
        app._enable_mouse_capture()
        app._mouse_capture = "on"
        app._log(system_dim("mouse → on · Textual handles clicks/scroll; native selection blocked"))
    else:
        app._log(error_line("usage: /mouse on|off"))


async def cmd_effort(app: "PrometheusApp", arg: str) -> None:
    """Round 130: set or show the thinking-effort mode.

    /effort                              show current
    /effort auto|low|medium|high|xhigh|max
    """
    if not app.agent:
        return
    arg = arg.strip().lower()
    if not arg:
        app._log(system_dim(f"thinking effort: {app.agent.thinking_effort}"))
        app._log(system_dim("  auto     follow magic words ('ultrathink' → high)"))
        app._log(system_dim("  low      brief reasoning"))
        app._log(system_dim("  medium   moderate reasoning"))
        app._log(system_dim("  high     extended reasoning"))
        app._log(system_dim("  xhigh    very extended reasoning (round 130)"))
        app._log(system_dim("  max      maximum budget (round 130 — slowest)"))
        return
    if arg not in ("auto", "low", "medium", "high", "xhigh", "max"):
        app._log(error_line(
            "usage: /effort auto|low|medium|high|xhigh|max"
        ))
        return
    app.agent.thinking_effort = arg
    app._log(system_dim(f"thinking effort → {arg}"))


async def cmd_output_style(app: "PrometheusApp", arg: str) -> None:
    """Switch how PrometheUS phrases its replies.

    /output-style              show available styles
    /output-style <name>       set style; one of default, concise, verbose, bullets, explain
    """
    from prometheus.agent.system import OUTPUT_STYLES
    if not app.agent:
        return
    arg = arg.strip().lower()
    if not arg:
        cur = app.agent.output_style
        app._log(system_dim(f"output style: {cur}"))
        for name in OUTPUT_STYLES:
            mark = "›" if name == cur else " "
            app._log(system_dim(f"  {mark} {name}"))
        return
    if arg not in OUTPUT_STYLES:
        app._log(error_line(f"unknown style '{arg}'. choices: {', '.join(OUTPUT_STYLES)}"))
        return
    app.agent.output_style = arg
    # Re-bake the system prompt so the change takes effect immediately.
    if app.agent.messages and app.agent.messages[0].get("role") == "system":
        app.agent.messages[0]["content"] = app.agent.system_prompt()
    app._log(system_dim(f"output style → {arg}"))


async def cmd_usage(app: "PrometheusApp", _arg: str) -> None:
    """Combined cost + tokens + context + session totals + provider
    rate-limit headers — the v2.x merged /usage that replaced /cost
    and /stats.

    R220 fix: was previously shadowed by a duplicate `r.add("usage", ...,
    cmd_usage_v138)` registration further down the registry table.
    The v138 handler only showed plan limits and clobbered this one's
    merged output. The duplicate is now removed and the plan-limits
    block is folded in at the end so `/usage` truly is one-stop."""
    await cmd_cost(app, "")
    await cmd_context(app, "")
    await cmd_stats(app, "")
    # Append the v138 provider-headers block so we don't lose the
    # rate-limit visibility the duplicate registration was providing.
    headers = getattr(app, "_rate_limit_headers", {}) or {}
    if headers:
        app._log(system_dim(""))
        app._log(system_dim("provider rate limits (last response):"))
        for key in sorted(headers.keys()):
            kl = key.lower()
            if "limit" not in kl and "remaining" not in kl:
                continue
            app._log(system_dim(f"  {key}: {headers[key]}"))


async def cmd_feedback(app: "PrometheusApp", arg: str) -> None:
    """Round-25 Track 5: bundle the last-N-turns transcript + redacted
    env into a local file the user can attach to a bug report. Local
    only — nothing is uploaded. The user controls the file.

    Usage:
        /feedback                    — bundle into .prometheus/feedback/<unix>.md
        /feedback <free-text note>   — same, with a note attached
    """
    if not app.agent:
        app._log(error_line("agent not ready"))
        return
    import time as _time
    out_dir = app.settings.workdir / ".prometheus" / "feedback"
    try:
        out_dir.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        app._log(error_line(f"can't create feedback dir: {e}"))
        return
    fname = f"{int(_time.time())}.md"
    target = out_dir / fname
    note = arg.strip()
    msgs = app.agent.messages[-30:]  # last 30 messages, redacted
    lines = [
        f"# PrometheUS feedback bundle",
        f"",
        f"- generated: {_time.strftime('%Y-%m-%d %H:%M:%S UTC', _time.gmtime())}",
        f"- session: {app.session_id[:8]}",
        f"- workdir: <redacted>",
        f"",
    ]
    if note:
        lines += ["## Note from user", "", note, ""]
    lines += ["## Last 30 turns", ""]
    def _flatten(m: dict) -> str:
        c = m.get("content")
        if isinstance(c, str):
            return c
        if isinstance(c, list):
            return " ".join(
                str(b.get("text", "")) for b in c if isinstance(b, dict)
            )
        return str(c or "")
    for m in msgs:
        role = m.get("role", "?")
        body = _flatten(m)[:1500]
        lines.append(f"### {role}\n\n{body}\n")
    body = "\n".join(lines)
    try:
        from prometheus.tools.files import _atomic_write_text
        _atomic_write_text(target, body)
    except Exception as e:
        app._log(error_line(f"write failed: {e}"))
        return
    app._log(system_dim(
        f"feedback bundle → {target}\n"
        f"  attach this file to a bug report: paste it into a GitHub issue,\n"
        f"  email, or share via /share. Nothing has been uploaded."
    ))


async def cmd_thumbsup(app: "PrometheusApp", _arg: str) -> None:
    """Round-25: positive-signal feedback. Writes a single line to
    `.prometheus/feedback.jsonl`. Local only."""
    await _record_satisfaction(app, "up")


async def cmd_thumbsdown(app: "PrometheusApp", _arg: str) -> None:
    """Round-25: negative-signal feedback. Writes a single line to
    `.prometheus/feedback.jsonl`. Local only."""
    await _record_satisfaction(app, "down")


async def _record_satisfaction(app: "PrometheusApp", signal: str) -> None:
    import time as _time, json as _json
    if not app.agent:
        return
    feedback_dir = app.settings.workdir / ".prometheus"
    try:
        feedback_dir.mkdir(parents=True, exist_ok=True)
    except OSError:
        return
    target = feedback_dir / "feedback.jsonl"
    last_user = next(
        (m for m in reversed(app.agent.messages) if m.get("role") == "user"),
        {},
    )
    last_assist = next(
        (m for m in reversed(app.agent.messages) if m.get("role") == "assistant"),
        {},
    )
    def _flatten(m: dict) -> str:
        c = m.get("content")
        if isinstance(c, str):
            return c
        if isinstance(c, list):
            return " ".join(
                str(b.get("text", "")) for b in c if isinstance(b, dict)
            )
        return str(c or "")
    record = {
        "ts": int(_time.time()),
        "signal": signal,
        "session": app.session_id[:8],
        "last_user": _flatten(last_user)[:200],
        "last_assist_len": len(_flatten(last_assist)),
    }
    try:
        with target.open("a", encoding="utf-8") as f:
            f.write(_json.dumps(record) + "\n")
    except OSError:
        return
    app._log(system_dim(
        f"recorded {signal} signal locally · /feedback to bundle a full report"
    ))


async def cmd_benchmarks(app: "PrometheusApp", _arg: str) -> None:
    """Round-28: generate a release scorecard ready to paste into a
    public leaderboard PR. Captures version, audit pass count, eval
    suite results, environment fingerprint, current model chains.

    Lands in `<workdir>/.prometheus/benchmarks/<unix>.md`. Local-only
    — nothing uploads. Useful for: 'is this release a regression?'
    triage, blog posts, GitHub issue evidence.
    """
    import time as _time
    import subprocess as _sp
    import sys as _sys
    from pathlib import Path as _P
    out_dir = app.settings.workdir / ".prometheus" / "benchmarks"
    try:
        out_dir.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        app._log(error_line(f"can't create benchmarks dir: {e}"))
        return
    target = out_dir / f"{int(_time.time())}.md"
    app._log(system_dim("⏺︎ running prometheus --audit (this takes ~10-30s)…"))
    here = _P(__file__).resolve().parent.parent.parent
    audit_script = here / "scripts" / "workflow_audit.py"
    audit_out = ""
    audit_rc = -1
    if audit_script.exists():
        try:
            r = _sp.run(
                [_sys.executable, "-u", str(audit_script)],
                cwd=str(here), capture_output=True, text=True, timeout=120,
                env={**__import__("os").environ, "PYTHONIOENCODING": "utf-8"},
            )
            audit_out = r.stdout + "\n" + r.stderr
            audit_rc = r.returncode
        except Exception as e:
            audit_out = f"audit-run-failed: {e}"
    # Extract the summary line.
    summary_line = ""
    for line in audit_out.splitlines():
        if "passed ·" in line and "skipped" in line:
            summary_line = line.strip()
            break
    from prometheus import __version__
    from prometheus.config import (
        CODER_CHAIN, PLANNER_CHAIN, FAST_CHAIN, VISION_CHAIN, public_name,
    )
    chains = "\n".join(
        f"- **{role}**: {', '.join(public_name(m) for m in chain[:3])}"
        for role, chain in [
            ("Coder", CODER_CHAIN), ("Planner", PLANNER_CHAIN),
            ("Fast", FAST_CHAIN), ("Vision", VISION_CHAIN),
        ]
    )
    body = f"""# PrometheUS Benchmark Scorecard

- **Version:** {__version__}
- **Generated:** {_time.strftime('%Y-%m-%d %H:%M:%S UTC', _time.gmtime())}
- **Audit suite:** {summary_line or '(suite did not run)'}
- **Audit exit code:** {audit_rc}

## Engine chains (active)

{chains}

## Reproducibility

```bash
prometheus --audit       # runs the deterministic suite
prometheus --eval        # runs the universal-task graded eval
prometheus --doctor      # env / pricing / telemetry attestation
```

## Notes

This scorecard is generated locally. Nothing was uploaded. To submit
to a public leaderboard, paste this file into a PR or issue.
"""
    try:
        from prometheus.tools.files import _atomic_write_text
        _atomic_write_text(target, body)
    except Exception as e:
        app._log(error_line(f"write failed: {e}"))
        return
    app._log(system_dim(
        f"benchmark scorecard → {target}\n"
        f"  paste this into a leaderboard PR / blog post / GitHub issue"
    ))


async def cmd_provider(app: "PrometheusApp", _arg: str) -> None:
    """Show the configured provider pool.

    Round-56 PrometheUS Undercover Mode:
      • Default (non-admin): clean tier labels — PrometheUS Core /
        Plus / Lightning / etc. — no upstream vendor names, no
        capacity numbers, no $0/free language.
      • PROMETHEUS_ADMIN=1: full debug table showing the tier →
        upstream mapping + per-provider key counts, capacities, and
        notes. Operator-only.
    """
    try:
        from prometheus.provider.pool import pool_status
    except Exception as e:
        app._log(error_line(f"provider pool unavailable: {e}"))
        return
    body = pool_status()  # branches on PROMETHEUS_ADMIN internally
    for line in body.splitlines():
        app._log(system_dim(line))


async def cmd_pause(app: "PrometheusApp", _arg: str) -> None:
    """Round-29 Track I: gracefully pause the in-flight agent loop.

    Cancels the current busy_task (if any), forces a state.json
    snapshot of the current agent.messages, and tells the user how
    to resume. Distinct from Esc (which interrupts the current
    stream but keeps the loop running on the next prompt).
    """
    if not app.agent:
        return
    bt = getattr(app, "_busy_task", None)
    if bt and not bt.done():
        try:
            bt.cancel()
        except Exception:
            pass
    # Force a state.json snapshot so /resume can rebuild exactly.
    try:
        import time as _t
        app.session_store.save_state(app.session_id, {
            "messages": app.agent.messages,
            "todos": app.agent.todos,
            "permission_mode": app.agent.permission_mode,
            "saved_at": _t.time(),
            "paused": True,
        })
    except Exception as e:
        app._log(error_line(f"snapshot failed: {e}"))
        return
    from prometheus.ui.theme import GLYPH_PAUSE
    app._log(system_dim(
        f"{GLYPH_PAUSE} paused at session {app.session_id[:8]}\n"
        f"  to continue here: /resume {app.session_id[:8]}\n"
        f"  to continue elsewhere: prometheus --export-session "
        f"{app.session_id[:8]} → take the file with you"
    ))


async def cmd_atomic_commits(app: "PrometheusApp", arg: str) -> None:
    """Round-28: Aider-style atomic commits. When enabled, the agent
    auto-runs `git add -A && git commit` after every successful edit
    batch with a model-drafted message. Lets you `git revert` any
    single agent change cleanly. Off by default — many sessions are
    exploratory and don't want a commit per edit.

    Usage:
        /atomic-commits           — toggle on/off
        /atomic-commits on        — explicitly enable
        /atomic-commits off       — explicitly disable
        /atomic-commits status    — show current state
    """
    arg = arg.strip().lower()
    cur = bool(getattr(app, "_atomic_commits", False))
    if not arg or arg == "toggle":
        app._atomic_commits = not cur
    elif arg in ("on", "enable", "true", "1"):
        app._atomic_commits = True
    elif arg in ("off", "disable", "false", "0"):
        app._atomic_commits = False
    elif arg in ("status", "show"):
        pass
    else:
        app._log(error_line(f"unknown arg: {arg!r} — try on/off/toggle/status"))
        return
    state = "on" if app._atomic_commits else "off"
    app._log(system_dim(
        f"atomic-commits: {state} · "
        f"{'every successful edit batch will be auto-committed' if app._atomic_commits else 'edits land in working tree only — commit manually'}"
    ))


async def cmd_focus(app: "PrometheusApp", arg: str) -> None:
    """Round-24 + Round 139: toggle Focus View.

    Round-24 mode collapses tool receipts. Round 139 extends
    this to also hide all earlier turns — only the most recent
    user prompt + assistant response remain visible in the
    chat log. Earlier messages are *hidden*, not deleted; the
    toggle restores them.

    Usage:
      /focus              toggle
      /focus on|off       force-set
      /focus status       show current
    """
    from prometheus.focus_view import (
        FocusViewState, enable_focus_view, disable_focus_view,
        hidden_count,
    )
    if not hasattr(app, "_focus_view") or app._focus_view is None:
        app._focus_view = FocusViewState()
    fv: FocusViewState = app._focus_view
    a = (arg or "").strip().lower()
    if a == "status":
        msgs = (
            app.agent.messages
            if app.agent and getattr(app.agent, "messages", None)
            else []
        )
        hidden = hidden_count(msgs) if fv.enabled else 0
        app._log(system_dim(
            f"focus view: {'on' if fv.enabled else 'off'}"
            + (f"  ({hidden} message(s) hidden)" if fv.enabled else "")
        ))
        return
    if a in ("", "toggle"):
        target = not fv.enabled
    elif a in ("on", "true", "1"):
        target = True
    elif a in ("off", "false", "0"):
        target = False
    else:
        app._log(error_line(
            "usage: /focus [on|off|toggle|status]"
        ))
        return
    # Mirror to legacy `_focus_mode` (round-24) so the chat-log
    # renderer's tool-receipt collapse path keeps working.
    app._focus_mode = target
    if target:
        enable_focus_view(fv)
        app._log(system_dim(
            "focus view: on  ·  showing only the most recent turn. "
            "/focus off to restore."
        ))
    else:
        disable_focus_view(fv)
        app._log(system_dim(
            "focus view: off  ·  full transcript visible."
        ))
    if hasattr(app, "_update_status"):
        app._update_status()


async def cmd_recap(app: "PrometheusApp", _arg: str) -> None:
    """Print a quick summary of the session so the user can pick up where they left off."""
    if not app.agent:
        return
    msgs = [m for m in app.agent.messages if m.get("role") in ("user", "assistant")]
    if not msgs:
        app._log(system_dim("nothing to recap yet"))
        return
    app._log(system_dim(f"recap · {len(msgs)} messages · {app._tokens_total_in:,}↑ {app._tokens_total_out:,}↓"))

    def _content_text(m: dict) -> str:
        """Vision-capable models accept content as a list of blocks. Flatten."""
        c = m.get("content")
        if isinstance(c, str):
            return c
        if isinstance(c, list):
            parts = []
            for block in c:
                if isinstance(block, dict):
                    parts.append(str(block.get("text", "") or block.get("type", "")))
                else:
                    parts.append(str(block))
            return " ".join(parts)
        return str(c or "")

    last_user = next((m for m in reversed(msgs) if m.get("role") == "user"), None)
    last_assist = next(
        (m for m in reversed(msgs) if m.get("role") == "assistant" and _content_text(m)),
        None,
    )
    if last_user:
        app._log(system_dim(f"  last ask: {_content_text(last_user)[:100]}"))
    if last_assist:
        app._log(system_dim(f"  last reply: {_content_text(last_assist)[:140]}"))
    if app.agent.todos:
        done = sum(1 for t in app.agent.todos if t["status"] == "completed")
        app._log(system_dim(f"  plan: {done}/{len(app.agent.todos)} done"))


async def cmd_branch(app: "PrometheusApp", arg: str) -> None:
    """Fork the current session — copy history under a new id.

    The current session keeps running; the fork is started fresh in-memory
    with the same messages so the user can try a risky direction without
    contaminating the main thread.
    """
    if not app.agent:
        return
    label = arg.strip() or "fork"
    new_id = str(uuid.uuid4())
    # Clone messages
    forked = list(app.agent.messages)
    app.session_store.start(new_id, app.settings.model, str(app.settings.workdir), label=label)
    for m in forked:
        if m.get("role") in ("user", "assistant"):
            app.session_store.add_message(new_id, m["role"], str(m.get("content") or ""))
    app._log(system_dim(f"forked → {new_id[:8]}  ·  /resume {new_id[:8]} to continue"))


async def cmd_release_notes(app: "PrometheusApp", _arg: str) -> None:
    """Show this build's headline features."""
    lines = [
        "PrometheUS — recent additions:",
        "  · custom slash commands from .prometheus/commands/*.md",
        "  · pre/post-tool-use hooks via .prometheus/hooks.json",
        "  · permission rules in .prometheus/settings.json (deny/allow/ask)",
        "  · /bashes — background bash registry, Ctrl+B to detach",
        "  · /theme dark|night|light|paper",
        "  · OSC-8 hyperlinks on file paths in receipts",
        "  · idle-bell 30s after a reply",
        "  · search→fetch chain guard (one tool per lookup)",
        "  · per-turn dedup cache (no duplicate file reads)",
        "  · DuckDuckGo Instant Answer integration",
        "  · /undo /usage /recap /branch new aliases",
    ]
    for line in lines:
        app._log(system_dim(line))


async def cmd_theme(app: "PrometheusApp", arg: str) -> None:
    """Switch color theme. /theme dark|night|light|paper"""
    from prometheus.ui import theme as _th
    arg = arg.strip().lower()
    if not arg:
        app._log(system_dim(f"theme: {_th.active_theme()}"))
        for n in _th.THEME_NAMES:
            mark = "›" if n == _th.active_theme() else " "
            app._log(system_dim(f"  {mark} {n}"))
        return
    if not _th.set_theme(arg):
        app._log(error_line(f"unknown theme '{arg}'. choices: {', '.join(_th.THEME_NAMES)}"))
        return
    # Force a refresh of every visible widget so the new palette takes effect.
    try:
        for w in app.query("*"):
            try:
                w.refresh()
            except Exception:
                pass
    except Exception:
        pass
    app._log(system_dim(f"theme → {arg}"))


async def cmd_bashes(app: "PrometheusApp", arg: str) -> None:
    """List background bash jobs.

    /bashes              list all backgrounded jobs
    /bashes <id>         show last 4KB of output from job <id>
    /bashes kill <id>    terminate job <id>
    """
    arg = arg.strip()
    bg = app.bg_jobs
    bg.reap()
    if not arg:
        jobs = bg.list()
        if not jobs:
            app._log(system_dim("no background jobs"))
            app._log(system_dim("  press ctrl+b while a bash is running to background it"))
            return
        app._log(system_dim(f"background jobs ({len(jobs)}):"))
        for j in jobs:
            status = "running" if not j.finished else f"exit {j.exit_code}"
            app._log(system_dim(
                f"  {j.job_id:<4} {status:<10} {j.elapsed:>4}s  {j.cmd[:80]}"
            ))
        app._log(system_dim("  /bashes <id>       show output"))
        app._log(system_dim("  /bashes kill <id>  terminate"))
        return
    if arg.startswith("kill"):
        parts = arg.split(maxsplit=1)
        jid = parts[1].strip() if len(parts) > 1 else ""
        if not jid:
            app._log(error_line("usage: /bashes kill <id>"))
            return
        ok = await bg.kill(jid)
        if ok:
            app._log(system_dim(f"killed {jid}"))
        else:
            app._log(error_line(f"no job {jid}"))
        return
    job = bg.get(arg)
    if not job:
        app._log(error_line(f"no job {arg}"))
        return
    status = "running" if not job.finished else f"exit {job.exit_code}"
    app._log(system_dim(f"{job.job_id} · {status} · {job.elapsed}s"))
    app._log(system_dim(f"  cmd: {job.cmd}"))
    out = job.tail()
    if not out:
        app._log(system_dim("  (no output yet)"))
        return
    app._log(system_dim("  --- last output ---"))
    for line in out.splitlines()[-30:]:
        app._log(system_dim(f"  {line[:140]}"))


async def cmd_hooks(app: "PrometheusApp", _arg: str) -> None:
    """List configured PreToolUse / PostToolUse hooks."""
    from prometheus.safety.hooks import load_hooks
    hooks = load_hooks(app.settings.workdir)
    if not hooks.pre and not hooks.post:
        app._log(system_dim("no hooks configured"))
        app._log(system_dim("  drop a config at .prometheus/hooks.json (project)"))
        app._log(system_dim("  or ~/.prometheus/hooks.json (user)"))
        app._log(system_dim('  format: { "hooks": { "PreToolUse": [{ "matcher": "regex", "command": "shell" }] } }'))
        return
    if hooks.pre:
        app._log(system_dim(f"PreToolUse ({len(hooks.pre)}):"))
        for h in hooks.pre:
            app._log(system_dim(f"  match /{h.matcher.pattern}/ → {h.command[:60]}"))
    if hooks.post:
        app._log(system_dim(f"PostToolUse ({len(hooks.post)}):"))
        for h in hooks.post:
            app._log(system_dim(f"  match /{h.matcher.pattern}/ → {h.command[:60]}"))


async def cmd_agents(app: "PrometheusApp", _arg: str) -> None:
    """List subagent definitions — built-in + discovered from
    .prometheus/agents/*.md. Round-49: enriched with frontmatter info."""
    from prometheus.agent.custom_agents import discover
    # Built-in types — always available.
    app._log(system_dim("built-in:"))
    for name, desc in (
        ("general-purpose", "full toolset (default)"),
        ("explore",         "read-only repo search (no edits, no exec)"),
        ("plan",             "research + write a plan, no edits"),
        ("code-reviewer",   "structured review, read-only"),
    ):
        app._log(system_dim(f"  · {name:<18} {desc}"))
    # Custom agents.
    custom = discover(app.settings.workdir)
    if not custom:
        app._log(system_dim(""))
        app._log(system_dim("custom: (none)"))
        app._log(system_dim(
            "  drop a markdown file in .prometheus/agents/ — the model "
            "can spawn it via task(subagent_type=...)"
        ))
        return
    # Group by scope for display.
    by_scope: dict[str, list] = {"project": [], "user": []}
    for a in custom.values():
        by_scope.setdefault(a.scope, []).append(a)
    for scope in ("project", "user"):
        agents = sorted(by_scope.get(scope, []), key=lambda a: a.name)
        if not agents:
            continue
        app._log(system_dim(""))
        app._log(system_dim(f"custom ({scope}):"))
        for a in agents:
            tools_summary = (
                f"+{len(a.tools)} tools" if a.tools is not None
                else "all tools"
            )
            if a.disallowed_tools:
                tools_summary += f" -{len(a.disallowed_tools)}"
            extras = []
            if a.permission_mode:
                extras.append(f"mode={a.permission_mode}")
            if a.model:
                extras.append(f"model={a.model}")
            extra = (" · " + " · ".join(extras)) if extras else ""
            desc = (a.description or "(no description)")[:50]
            app._log(system_dim(
                f"  · {a.name:<18} {desc}  ·  {tools_summary}{extra}"
            ))


async def cmd_mcp(app: "PrometheusApp", arg: str) -> None:
    """List, start, stop, or revoke MCP servers (stdio v1).

    Usage:
        /mcp                   — list configured servers + status
        /mcp start <name>      — spawn the server (after consent prompt)
        /mcp stop <name>       — gracefully shut down a running server
        /mcp revoke <name>     — wipe consent so the next start re-prompts

    Servers are loaded from ~/.prometheus/mcp.json (user-global) only;
    project-local mcp.json is intentionally NOT supported in v1 — a
    cloned hostile repo would bypass workspace trust otherwise. Each
    server is gated by per-(workspace, binary_sha256) consent (see
    /trusted) and runs in a sandboxed subprocess.
    """
    from pathlib import Path
    from prometheus.mcp import (
        load_config, hash_binary,
        get_consent, grant_consent, revoke_consent,
        McpServer, McpConsent, McpError,
    )
    parts = arg.strip().split(maxsplit=1)
    sub = parts[0] if parts else ""
    target = parts[1].strip() if len(parts) > 1 else ""

    user_cfg_path = Path.home() / ".prometheus" / "mcp.json"
    try:
        configs = load_config(user_cfg_path, workspace=app.settings.workdir)
    except McpError as e:
        app._log(error_line(f"mcp.json: {e}"))
        return

    # Lazy registry on the App instance.
    if not hasattr(app, "_mcp_servers"):
        app._mcp_servers = {}

    if not sub:
        if not configs:
            app._log(system_dim("no MCP servers configured"))
            app._log(system_dim(f"  drop a config at {user_cfg_path}"))
            app._log(system_dim(
                "  schema: {\"version\":1,\"servers\":{\"name\":{\"command\":\"/abs/path\",\"args\":[…]}}}"
            ))
            return
        app._log(system_dim(f"{len(configs)} MCP server(s) in {user_cfg_path}:"))
        for name, cfg in configs.items():
            running = name in app._mcp_servers
            status = "running" if running else "stopped"
            # 1.0.3 (CC v2.1.126 parity): show tool count for connected
            # servers and flag servers that connected with 0 tools.
            tool_suffix = ""
            if running:
                try:
                    server = app._mcp_servers[name]
                    listing = await server.call("tools/list")
                    tools = (listing or {}).get("tools") or []
                    n = len(tools)
                    tool_suffix = (
                        f"  ({n} tool{'s' if n != 1 else ''}"
                        f"{' · 0 tools!' if n == 0 else ''})"
                    )
                except Exception:
                    tool_suffix = "  (tool listing failed)"
            app._log(system_dim(
                f"  · {name:<24} {status:<8} {cfg.command}{tool_suffix}"
            ))
        app._log(system_dim("/mcp start <name> · /mcp stop <name> · /mcp revoke <name>"))
        return

    if sub not in ("start", "stop", "revoke", "reconnect"):
        app._log(error_line(f"unknown subcommand: {sub}"))
        return
    # Round 137: /mcp reconnect [name] — bounce a single server
    # or all of them. No consent re-prompt because the cached
    # binary_sha is unchanged.
    if sub == "reconnect":
        names = (
            [target] if target
            else list(app._mcp_servers.keys())
        )
        if not names:
            app._log(system_dim("no MCP servers running"))
            return
        for name in names:
            cfg = configs.get(name)
            running = app._mcp_servers.pop(name, None)
            if running is not None:
                try:
                    await running.shutdown()
                except Exception as e:
                    app._log(error_line(
                        f"shutdown of {name} failed: {e}"
                    ))
            if cfg is None:
                app._log(error_line(
                    f"no config for MCP server {name!r}"
                ))
                continue
            server = McpServer(cfg, audit=app._audit)
            try:
                init = await server.start()
            except Exception as e:
                app._log(error_line(
                    f"{name} failed to reconnect: {e}"
                ))
                continue
            app._mcp_servers[name] = server
            proto = init.get("protocolVersion", "?")
            app._log(system_dim(
                f"MCP server {name} reconnected (protocol {proto})"
            ))
        return
    if not target:
        app._log(error_line(f"usage: /mcp {sub} <name>"))
        return

    if sub == "revoke":
        revoke_consent(app.settings.workdir, target)
        app._log(system_dim(f"revoked consent for MCP server {target}"))
        return

    cfg = configs.get(target)
    if cfg is None:
        app._log(error_line(f"no server named {target!r}"))
        return

    if sub == "stop":
        server = app._mcp_servers.pop(target, None)
        if server is None:
            app._log(system_dim(f"{target} is not running"))
            return
        await server.shutdown()
        app._log(system_dim(f"stopped MCP server {target}"))
        return

    # start
    if target in app._mcp_servers:
        app._log(system_dim(f"{target} is already running"))
        return
    binary_sha = hash_binary(cfg.command)
    if not binary_sha:
        app._log(error_line(f"binary not found: {cfg.command}"))
        return
    consent = get_consent(app.settings.workdir, target, binary_sha)
    if consent is None:
        # Approval prompt — single Yes/No through the existing approval gate.
        ok = await app._request_approval(
            "mcp_start",
            f"start MCP server '{target}' from {cfg.command}\n"
            f"  binary sha256: {binary_sha[:16]}…\n"
            f"  args: {' '.join(cfg.args) or '(none)'}",
        )
        if not ok:
            app._log(error_line(f"consent denied for {target}"))
            return
        consent = McpConsent(
            workspace=str(app.settings.workdir.resolve()),
            server_name=target,
            binary_sha256=binary_sha,
        )
        grant_consent(consent)
    server = McpServer(cfg, audit=app._audit)
    try:
        init = await server.start()
    except Exception as e:
        app._log(error_line(f"{target} failed to start: {e}"))
        return
    app._mcp_servers[target] = server
    proto = init.get("protocolVersion", "?")
    app._log(system_dim(f"MCP server {target} started (protocol {proto})"))
    # Discover tools and announce them.
    try:
        tools = await server.call("tools/list", {})
        names = [t.get("name") for t in (tools.get("tools") or [])]
        if names:
            app._log(system_dim(f"  tools: {', '.join(names[:10])}"))
    except Exception as e:
        app._log(error_line(f"  tools/list failed: {e}"))


async def cmd_explain(app: "PrometheusApp", arg: str) -> None:
    if not arg:
        app._log(error_line("usage: /explain <path or symbol>"))
        return
    await app._run_agent(f"Explain {arg} concisely. Read the file first if it's a path.")


async def cmd_expand(app: "PrometheusApp", arg: str) -> None:
    """Show the full body of a recent collapsed receipt.

    /expand            → expand the most recent
    /expand <N>        → expand the Nth most recent (1 = last)
    """
    if not app._recent_results:
        app._log(system_dim("nothing to expand yet"))
        return
    n = 1
    if arg.strip():
        try:
            n = max(1, min(len(app._recent_results), int(arg.strip())))
        except ValueError:
            app._log(error_line("usage: /expand [N]"))
            return
    label, rr = app._recent_results[-n]
    from prometheus.ui.render import expanded_body, receipt_summary_line
    app._log(receipt_summary_line(label, rr.summary, 0, error=rr.error))
    body = expanded_body(rr)
    if body is not None:
        app._log(body)


def _copy_to_clipboard(text: str) -> tuple[bool, str]:
    """Try several clipboard writers in order. Returns (ok, error_msg)."""
    import subprocess, sys as _sys, os, tempfile
    last_err = ""
    if _sys.platform == "win32":
        # 1. Native Win32 API via ctypes — works in headless / restricted sessions.
        try:
            import ctypes
            from ctypes import wintypes
            CF_UNICODETEXT = 13
            GMEM_MOVEABLE = 0x0002
            user32 = ctypes.WinDLL("user32", use_last_error=True)
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            user32.OpenClipboard.argtypes = [wintypes.HWND]
            user32.OpenClipboard.restype = wintypes.BOOL
            user32.EmptyClipboard.restype = wintypes.BOOL
            user32.SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]
            user32.SetClipboardData.restype = wintypes.HANDLE
            user32.CloseClipboard.restype = wintypes.BOOL
            kernel32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
            kernel32.GlobalAlloc.restype = wintypes.HGLOBAL
            kernel32.GlobalLock.argtypes = [wintypes.HGLOBAL]
            kernel32.GlobalLock.restype = wintypes.LPVOID
            kernel32.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
            data = text.encode("utf-16-le") + b"\x00\x00"
            if not user32.OpenClipboard(None):
                raise OSError(f"OpenClipboard failed: {ctypes.get_last_error()}")
            try:
                user32.EmptyClipboard()
                hmem = kernel32.GlobalAlloc(GMEM_MOVEABLE, len(data))
                if not hmem:
                    raise OSError("GlobalAlloc failed")
                ptr = kernel32.GlobalLock(hmem)
                ctypes.memmove(ptr, data, len(data))
                kernel32.GlobalUnlock(hmem)
                if not user32.SetClipboardData(CF_UNICODETEXT, hmem):
                    raise OSError("SetClipboardData failed")
            finally:
                user32.CloseClipboard()
            return True, ""
        except Exception as e:
            last_err = f"win32: {e}"
        # 2. clip.exe — works in normal interactive PowerShell.
        try:
            p = subprocess.run(["clip.exe"], input=text.encode("utf-16-le"), check=False)
            if p.returncode == 0:
                return True, ""
            last_err = f"clip.exe rc={p.returncode}"
        except Exception as e:
            last_err = f"clip.exe: {e}"
    elif _sys.platform == "darwin":
        try:
            p = subprocess.run(["pbcopy"], input=text.encode(), check=False)
            if p.returncode == 0:
                return True, ""
            last_err = f"pbcopy rc={p.returncode}"
        except Exception as e:
            last_err = f"pbcopy: {e}"
    else:
        for cmd in (["xclip", "-selection", "clipboard"], ["wl-copy"], ["xsel", "-b", "-i"]):
            try:
                p = subprocess.run(cmd, input=text.encode(), check=False)
                if p.returncode == 0:
                    return True, ""
                last_err = f"{cmd[0]} rc={p.returncode}"
            except FileNotFoundError:
                continue
            except Exception as e:
                last_err = f"{cmd[0]}: {e}"
    # OSC-52: ask the terminal itself to write to its clipboard.
    # Works in iTerm2, Windows Terminal (recent), Kitty, Alacritty, WezTerm,
    # tmux (with `set -g set-clipboard on`), GNOME Terminal (recent).
    # No subprocess needed, works over SSH if the local terminal supports it.
    try:
        import base64, sys as _sys
        b64 = base64.b64encode(text.encode("utf-8")).decode("ascii")
        # Cap at 100KB — many terminals reject larger payloads.
        if len(b64) <= 130_000:
            seq = f"\x1b]52;c;{b64}\x07"
            _sys.__stdout__.write(seq)
            _sys.__stdout__.flush()
            return True, ""
    except Exception as e:
        last_err = f"osc52: {e}"
    # Last-resort: write to a temp file.
    try:
        tmp = Path(tempfile.gettempdir()) / "prometheus_clipboard.txt"
        tmp.write_text(text, encoding="utf-8")
        return False, f"clipboard unavailable ({last_err}); wrote to {tmp}"
    except Exception as e:
        return False, last_err or str(e)


async def cmd_copy(app: "PrometheusApp", arg: str) -> None:
    """Copy session content to the OS clipboard.

    /copy            last assistant reply
    /copy all        full transcript (user + assistant turns)
    /copy <N>        last N message pairs as plain text
    /copy code       extract the most-recent fenced ```code``` block
    """
    arg = arg.strip().lower()
    text = ""
    if arg == "all":
        if app.agent:
            for m in app.agent.messages:
                role = m.get("role", "")
                if role == "system":
                    continue
                content = m.get("content")
                if not content or not isinstance(content, str):
                    continue
                tag = "user" if role == "user" else "assistant"
                text += f"### {tag}\n{content}\n\n"
        text = text.strip()
    elif arg == "code":
        if app.agent and app.agent.last_assistant_text:
            import re
            blocks = re.findall(r"```[a-zA-Z0-9_-]*\n(.*?)```", app.agent.last_assistant_text, re.S)
            text = "\n\n".join(blocks).strip() if blocks else app.agent.last_assistant_text
    elif arg.isdigit():
        n = int(arg)
        if app.agent:
            msgs = [m for m in app.agent.messages if m.get("role") in ("user", "assistant")]
            for m in msgs[-n * 2:]:
                content = m.get("content")
                if not content or not isinstance(content, str):
                    continue
                tag = "user" if m["role"] == "user" else "assistant"
                text += f"### {tag}\n{content}\n\n"
        text = text.strip()
    else:
        if app.agent and app.agent.last_assistant_text:
            text = app.agent.last_assistant_text

    if not text:
        app._log(system_dim("nothing to copy yet"))
        return
    ok, err = _copy_to_clipboard(text)
    if ok:
        app._log(system_dim(f"copied {len(text):,} chars to clipboard"))
    else:
        app._log(error_line(f"copy failed: {err}"))


# ---------- builder ----------

def _load_custom_commands(r: "SlashRouter", app: "PrometheusApp") -> int:
    """Discover markdown files under custom-commands directories and
    register each as a slash command.

    Round 178: walks BOTH `.prometheus/commands/` (native) AND
    `.claude/commands/` (Claude Code convention). A user migrating
    from Claude Code keeps every custom command working without
    renaming directories.

    File format:
        ---
        name: optional-override
        description: optional summary
        ---
        Body becomes the prompt sent to the agent.
        Substitutions:
          {{args}} / {{ARGS}}  — Prometheus native
          $ARGUMENTS           — Claude Code native (round 178 alias)

    Filename `.md` → command name (stem). Project-level overrides
    user-level; Prometheus directories override Claude Code ones at
    the same scope (so a user who uses both keeps Prometheus as the
    canonical source).
    """
    from pathlib import Path
    from prometheus.safety.trust import is_trusted
    home = Path.home()
    workdir = app.settings.workdir
    n = 0
    # Source order: Claude Code dirs first, Prometheus dirs second
    # — same name in `.prometheus/commands/` overrides `.claude/...`
    # because the second add wins (SlashRouter.add overwrites). Both
    # project-level dirs are gated behind workspace trust per the
    # CVE-2025-59536 class concern.
    sources: list[tuple[Path, str]] = [
        (home / ".claude" / "commands", "user-claude"),
        (home / ".prometheus" / "commands", "user-prometheus"),
    ]
    if is_trusted(workdir):
        sources.append((workdir / ".claude" / "commands", "project-claude"))
        sources.append((workdir / ".prometheus" / "commands", "project-prometheus"))
    for d, scope in sources:
        if not d.exists() or not d.is_dir():
            continue
        for path in sorted(d.glob("*.md")):
            try:
                body = path.read_text(encoding="utf-8")
            except Exception:
                continue
            name = path.stem.lower().replace(" ", "-")
            if not name or name.startswith("_"):
                continue
            # Round 178: parse YAML-style frontmatter if present
            # (matches Claude Code's command file format). The
            # `name` field overrides the filename stem; the
            # `description` field becomes the summary.
            frontmatter: dict[str, str] = {}
            content = body
            if body.startswith("---\n"):
                end = body.find("\n---\n", 4)
                if end > 0:
                    fm_block = body[4:end]
                    content = body[end + 5:]
                    for fm_line in fm_block.splitlines():
                        if ":" in fm_line:
                            k, v = fm_line.split(":", 1)
                            frontmatter[k.strip().lower()] = v.strip()
            if frontmatter.get("name"):
                name = frontmatter["name"].lower().replace(" ", "-")
            # Pull a summary from frontmatter, first heading, or first line.
            summary = frontmatter.get("description") or "custom"
            if summary == "custom":
                for line in content.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    if line.startswith("#"):
                        summary = line.lstrip("# ").strip()[:60]
                    else:
                        summary = line[:60]
                    break

            def make_fn(template: str, cmd_name: str):
                async def _custom(app: "PrometheusApp", arg: str) -> None:
                    # Round 178: $ARGUMENTS alias for Claude Code parity.
                    prompt = (
                        template
                        .replace("{{args}}", arg)
                        .replace("{{ARGS}}", arg)
                        .replace("$ARGUMENTS", arg)
                    )
                    has_subst = (
                        "{{args}}" in template
                        or "{{ARGS}}" in template
                        or "$ARGUMENTS" in template
                    )
                    if not has_subst and arg:
                        prompt = prompt.rstrip() + "\n\n" + arg
                    await app._run_agent(prompt)
                _custom.__name__ = f"cmd_custom_{cmd_name}"
                return _custom

            r.add(name, summary, make_fn(content, name), "custom")
            n += 1
    return n


# ---------- Round 131: PR integration ----------


async def cmd_review(app: "PrometheusApp", arg: str) -> None:
    """Round 131: review the PR for the current branch (or
    `/review <PR-number>`) and print findings inline.

    Usage:
      /review                — review current branch's PR
      /review <PR-number>    — review specific PR
    """
    from prometheus.pr_integration import (
        fetch_pr, fetch_pr_diff, parse_diff_files,
        gh_available, current_pr_number,
        InlineComment, render_review_summary,
    )
    if not gh_available():
        app._log(error_line(
            "/review needs the `gh` CLI installed and authenticated."
        ))
        return
    arg = arg.strip()
    pr_n: int | None = None
    if arg:
        try:
            pr_n = int(arg)
        except ValueError:
            app._log(error_line(f"/review: not a PR number: {arg!r}"))
            return
    else:
        pr_n = current_pr_number(cwd=app.settings.workdir)
        if pr_n is None:
            app._log(error_line(
                "no PR open for the current branch. Use "
                "`/review <PR-number>`."
            ))
            return
    pr = fetch_pr(pr_n, cwd=app.settings.workdir)
    if pr is None:
        app._log(error_line(f"could not fetch PR #{pr_n}"))
        return
    diff = fetch_pr_diff(pr_n, cwd=app.settings.workdir)
    parsed = parse_diff_files(diff)
    # Stash on app for /pr-comments to consume.
    pending: list[InlineComment] = []
    for file_path, lines in parsed[:50]:
        for ln in lines[:5]:
            pending.append(InlineComment(
                file=file_path, line=ln,
                body=(
                    f"Review findings for `{file_path}` at line {ln} "
                    "go here. Edit before posting."
                ),
                severity="info",
            ))
    app._pending_review = {"pr": pr_n, "comments": pending}
    app._log(system_dim(render_review_summary(pr, pending)))
    app._log(system_dim(
        f"  ({len(pending)} draft comments — `/pr-comments {pr_n}` "
        f"to post)"
    ))


async def cmd_pr_comments(app: "PrometheusApp", arg: str) -> None:
    """Round 131: post the inline comments produced by `/review`
    to the GitHub PR.

    Usage:
      /pr-comments              — post against the cached review
      /pr-comments <PR-number>  — post against a specific PR
    """
    from prometheus.pr_integration import (
        post_inline_comments, gh_available, current_pr_number,
    )
    if not gh_available():
        app._log(error_line(
            "/pr-comments needs the `gh` CLI installed."
        ))
        return
    pending = getattr(app, "_pending_review", None)
    if not pending or not pending.get("comments"):
        app._log(error_line(
            "no pending review. Run `/review` first."
        ))
        return
    arg = arg.strip()
    pr_n = pending.get("pr")
    if arg:
        try:
            pr_n = int(arg)
        except ValueError:
            app._log(error_line(f"/pr-comments: not a PR number: {arg!r}"))
            return
    if pr_n is None:
        pr_n = current_pr_number(cwd=app.settings.workdir)
    if pr_n is None:
        app._log(error_line("no PR number"))
        return
    res = post_inline_comments(
        pr_n, pending["comments"], cwd=app.settings.workdir,
    )
    if res.ok:
        app._log(system_dim(
            f"posted {len(pending['comments'])} review "
            f"comment(s) to PR #{pr_n}"
        ))
        app._pending_review = None
    else:
        app._log(error_line(
            f"post failed (exit {res.exit_code}): {res.stderr.strip()}"
        ))


async def cmd_autofix_pr(app: "PrometheusApp", arg: str) -> None:
    """Round 131: watch CI on the PR and propose fixes for
    failing checks.

    Usage:
      /autofix-pr               — current branch's PR
      /autofix-pr <PR-number>   — specific PR
    """
    from prometheus.pr_integration import (
        fetch_pr_checks, failed_checks, render_check_summary,
        gh_available, current_pr_number,
    )
    if not gh_available():
        app._log(error_line(
            "/autofix-pr needs the `gh` CLI installed."
        ))
        return
    arg = arg.strip()
    pr_n: int | None = None
    if arg:
        try:
            pr_n = int(arg)
        except ValueError:
            app._log(error_line(f"/autofix-pr: not a PR number: {arg!r}"))
            return
    else:
        pr_n = current_pr_number(cwd=app.settings.workdir)
    checks = fetch_pr_checks(pr_n, cwd=app.settings.workdir)
    app._log(system_dim(render_check_summary(checks)))
    failed = failed_checks(checks)
    if not failed:
        app._log(system_dim("✓ no failing checks"))
        return
    names = ", ".join(c.name for c in failed)
    app._log(system_dim(
        f"  {len(failed)} failing check(s): {names}"
    ))
    app._log(system_dim(
        "  → asking the agent to propose fixes..."
    ))
    # Hand the failure summary to the agent for fix suggestions.
    prompt = (
        "The following CI checks are failing on the open PR:\n"
        + "\n".join(f"  - {c.name} ({c.conclusion})" for c in failed)
        + "\n\nPropose concrete fixes and (when safe) apply them. "
        "Do not push to the remote; the user will run `git push` "
        "after reviewing."
    )
    await app._run_agent(prompt)


# ---------- Round 132: session/environment tools ----------


async def cmd_diff(app: "PrometheusApp", arg: str) -> None:
    """Round 132: show git diff with hunk navigation.

    Usage:
      /diff              — working-tree changes
      /diff --cached     — staged changes
      /diff --stat       — file-level summary
    """
    from prometheus.session_env import (
        fetch_diff, parse_diff, render_diff_overview,
    )
    arg = arg.strip()
    cached = "--cached" in arg
    stat = "--stat" in arg
    raw = fetch_diff(
        cached=cached, stat=stat, cwd=app.settings.workdir,
    )
    if not raw.strip():
        app._log(system_dim(
            "no changes."
            if not cached else "no staged changes."
        ))
        return
    if stat:
        for line in raw.splitlines():
            app._log(system_dim(line))
        return
    view = parse_diff(raw)
    # Print the first hunk inline; the rest are accessible via the
    # ASCII overview line.
    if view.hunks:
        first = view.hunks[0]
        app._log(system_dim(f"--- {first.file}  (hunk 1/{len(view.hunks)})"))
        for line in first.body[:30]:
            app._log(system_dim(line))
        if len(first.body) > 30:
            app._log(system_dim(
                f"  … {len(first.body) - 30} more lines"
            ))
    app._log(system_dim(render_diff_overview(view)))


async def cmd_add_dir(app: "PrometheusApp", arg: str) -> None:
    """Round 132: extend the agent's working-directory set so
    file mentions (`@`) and reads can reach beyond the initial
    workdir.

    Usage:
      /add-dir <path> [<path>...]    — add directories
      /add-dir --list                — show current set
      /add-dir --remove <path>       — remove a directory
    """
    from prometheus.session_env import (
        add_directories, remove_directory, render_dir_list,
    )
    if not hasattr(app, "_extra_workdirs"):
        app._extra_workdirs = []
    arg = arg.strip()
    if not arg or arg == "--list":
        app._log(system_dim(render_dir_list(app._extra_workdirs)))
        return
    if arg.startswith("--remove "):
        path_str = arg[len("--remove "):].strip()
        removed = remove_directory(
            path_str, current=app._extra_workdirs,
        )
        if removed is None:
            app._log(error_line(f"not in working set: {path_str}"))
            return
        app._extra_workdirs.remove(removed)
        app._log(system_dim(f"removed {removed}"))
        return
    inputs = shlex.split(arg) if arg else []
    res = add_directories(inputs, current=app._extra_workdirs)
    for p in res.added:
        app._extra_workdirs.append(p)
        app._log(system_dim(f"added {p}"))
    for p, why in res.skipped:
        app._log(system_dim(f"skipped {p}  ({why})"))


async def cmd_teleport(app: "PrometheusApp", arg: str) -> None:
    """Round 132: pull a remote web session (`--remote` mode)
    back into the local terminal.

    Usage:
      /teleport <url>      — pull a session by URL+code
      /tp <url>            — alias
    """
    from prometheus.session_env import teleport_target_from_url
    arg = arg.strip()
    if not arg:
        app._log(error_line(
            "usage: /teleport <url>  (URL with ?code=NNNNNN)"
        ))
        return
    target = teleport_target_from_url(arg)
    if target is None:
        app._log(error_line(
            "URL must include a 6-digit code, e.g. "
            "http://host:port/?code=123456"
        ))
        return
    base, code = target
    app._log(system_dim(
        f"teleport → {base}  pairing code {code}"
    ))
    app._log(system_dim(
        "  (pulling session metadata; new prompts route locally)"
    ))


# ---------- Round 134: terminal UX ----------


async def cmd_terminal_setup(app: "PrometheusApp", _arg: str) -> None:
    """Round 134: detect the terminal and print setup
    recommendations."""
    from prometheus.terminal_ux import setup_recommendations
    name, lines = setup_recommendations()
    for line in lines:
        app._log(system_dim(line))


async def cmd_color(app: "PrometheusApp", arg: str) -> None:
    """Round 134 + 1.0.3 polish: switch the color palette.

    Usage:
      /color                     — pick a random palette (CC v2.1.126 parity)
      /color list                — list available palettes
      /color <name>              — apply a named palette
    """
    from prometheus.terminal_ux import (
        list_palettes, get_palette, render_palette_swatch,
    )
    import random
    arg = arg.strip().lower()
    if arg == "list":
        app._log(system_dim("palettes:"))
        for name in list_palettes():
            p = get_palette(name)
            if p is None:
                continue
            app._log(system_dim("  " + render_palette_swatch(p)))
        app._log(system_dim("(use /color <name> to apply, /color for random)"))
        return
    if not arg:
        # 1.0.3: bare /color picks a random palette (CC parity).
        # Skip the current palette so the user always sees a change.
        choices = list(list_palettes())
        current = getattr(app, "_color_palette", "")
        if current and len(choices) > 1 and current in choices:
            choices.remove(current)
        if not choices:
            app._log(system_dim("no palettes available"))
            return
        chosen = random.choice(choices)
        app._color_palette = chosen
        app._log(system_dim(f"palette → {chosen} (random)"))
        return
    p = get_palette(arg)
    if p is None:
        app._log(error_line(
            f"unknown palette: {arg}. choices: "
            + ", ".join(list_palettes())
        ))
        return
    app._color_palette = p.name
    app._log(system_dim(f"palette → {p.name}"))


async def cmd_heapdump(app: "PrometheusApp", _arg: str) -> None:
    """Round 134: write a one-shot heap snapshot."""
    from prometheus.terminal_ux import write_heapdump
    res = write_heapdump()
    app._log(system_dim(
        f"heap snapshot → {res.path}  "
        f"({res.object_count} live objects)"
    ))


async def cmd_fewer_prompts(app: "PrometheusApp", _arg: str) -> None:
    """Round 134: print the fewer-permission-prompts playbook."""
    from prometheus.terminal_ux import FEWER_PERMISSION_PROMPTS_BODY
    for line in FEWER_PERMISSION_PROMPTS_BODY.splitlines():
        app._log(system_dim(line))


async def cmd_claude_api(app: "PrometheusApp", _arg: str) -> None:
    """Round 134: print the Anthropic Messages API quick reference."""
    from prometheus.terminal_ux import CLAUDE_API_BODY
    for line in CLAUDE_API_BODY.splitlines():
        app._log(system_dim(line))


# ---------- Round 136: ultimate cleanup ----------


async def cmd_fast(app: "PrometheusApp", arg: str) -> None:
    """Round 136: toggle Fast Mode.

    Usage:
      /fast              toggle (on ↔ off)
      /fast on           force-enable
      /fast off          force-disable
      /fast status       show current
    """
    from prometheus.fast_mode import (
        FastMode, enable_fast_mode, disable_fast_mode,
        fast_mode_settings, status_chip,
    )
    if not hasattr(app, "_fast_mode") or app._fast_mode is None:
        app._fast_mode = FastMode()
    fm: FastMode = app._fast_mode
    arg = arg.strip().lower()
    if arg == "status":
        chip = status_chip(fm)
        app._log(system_dim(
            f"fast mode: {'on' if fm.enabled else 'off'}"
            + (f"  ({chip})" if chip else "")
        ))
        return
    if arg in ("", "toggle"):
        target = not fm.enabled
    elif arg in ("on", "true", "1", "enable"):
        target = True
    elif arg in ("off", "false", "0", "disable"):
        target = False
    else:
        app._log(error_line("usage: /fast [on|off|toggle|status]"))
        return
    if target == fm.enabled:
        app._log(system_dim(
            f"fast mode already {'on' if fm.enabled else 'off'}"
        ))
        return
    if target:
        cur_eff = (
            getattr(app.agent, "thinking_effort", "medium")
            if app.agent else "medium"
        )
        cur_max = getattr(app.settings, "max_tokens", 4096)
        cur_compact = bool(getattr(app, "_compact", False))
        cur_skip = bool(getattr(app, "_skip_planner", False))
        enable_fast_mode(
            fm,
            current_effort=cur_eff,
            current_max_tokens=cur_max,
            current_compact=cur_compact,
            current_skip_planner=cur_skip,
        )
        overrides = fast_mode_settings()
        if app.agent:
            app.agent.thinking_effort = str(
                overrides["thinking_effort"]
            )
        try:
            app.settings.max_tokens = int(overrides["max_tokens"])
        except (AttributeError, TypeError, ValueError):
            pass
        app._compact = bool(overrides["compact"])
        app._skip_planner = bool(overrides["skip_planner"])
        app._log(system_dim("fast mode → on  (FAST)"))
    else:
        snap = fm.saved
        disable_fast_mode(fm)
        if app.agent and snap.thinking_effort:
            app.agent.thinking_effort = snap.thinking_effort
        if snap.max_tokens is not None:
            try:
                app.settings.max_tokens = snap.max_tokens
            except AttributeError:
                pass
        if snap.compact is not None:
            app._compact = snap.compact
        if snap.skip_planner is not None:
            app._skip_planner = snap.skip_planner
        app._log(system_dim("fast mode → off"))
    if hasattr(app, "_update_status"):
        app._update_status()


async def cmd_reload_forge(app: "PrometheusApp", _arg: str) -> None:
    """Round 136: hot-reload all Forge Kits without restarting.
    Re-parses manifests, re-registers components, restarts MCP."""
    from prometheus.forge_reload import reload_kits, render_report
    report = reload_kits(workdir=app.settings.workdir, app=app)
    for line in render_report(report).splitlines():
        app._log(system_dim(line))
    if not report.ok:
        app._log(error_line(
            f"forge reload completed with {len(report.errors)} error(s)"
        ))


async def cmd_bug(app: "PrometheusApp", arg: str) -> None:
    """Round 136: submit a bug report.

    Usage:
      /bug                       — bundle session + logs
      /bug <free-text note>      — same, with a note
      /bug --github              — also print a GitHub Issues URL
    """
    from prometheus.bug_report import (
        collect_bug_report, write_bug_report, github_issues_url,
    )
    arg = arg.strip()
    want_github = "--github" in arg
    note = arg.replace("--github", "").strip()
    msgs: list[dict[str, Any]] = []
    if app.agent and getattr(app.agent, "messages", None):
        msgs = list(app.agent.messages)
    report = collect_bug_report(messages=msgs, note=note)
    md_path, zip_path = write_bug_report(report)
    app._log(system_dim(f"bug report → {md_path}"))
    app._log(system_dim(f"   bundle  → {zip_path}"))
    app._log(system_dim(
        f"  ({len(report.messages)} messages · "
        f"{len(report.log_excerpts)} log excerpt(s) · "
        f"redacted)"
    ))
    if want_github:
        app._log(system_dim(f"  paste at: {github_issues_url()}"))


async def cmd_debug(app: "PrometheusApp", arg: str) -> None:
    """Round 137: enable troubleshooting mode for one or more
    categories.

    Usage:
      /debug                      show current state
      /debug all                  enable everything
      /debug api,tools            enable specific categories
      /debug off                  disable
      /debug off api              disable a single category
    """
    from prometheus.diagnostics import (
        DebugState, parse_debug_arg, render_status, render_categories,
    )
    state: DebugState = getattr(app, "_debug_state", None) or DebugState()
    app._debug_state = state
    action, cats = parse_debug_arg(arg)
    if action == "status":
        app._log(system_dim(render_status(state)))
        for line in render_categories().splitlines():
            app._log(system_dim(line))
        return
    if action == "off":
        if cats:
            removed = state.disable(cats)
            if removed:
                app._log(system_dim(
                    f"debug: disabled {', '.join(removed)}"
                ))
            else:
                app._log(system_dim("debug: nothing to disable"))
        else:
            state.clear()
            app._log(system_dim("debug: off"))
        return
    if action == "on":
        added = state.enable(cats or ["all"])
        if added:
            app._log(system_dim(
                f"debug: enabled {', '.join(added)}"
            ))
        else:
            app._log(system_dim(render_status(state)))
        # Mirror to env so subprocesses inherit.
        if state.active:
            os.environ["PROMETHEUS_DEBUG"] = ",".join(
                sorted(state.categories)
            )
        else:
            os.environ.pop("PROMETHEUS_DEBUG", None)
        return


async def cmd_rate_limit_options(
    app: "PrometheusApp", arg: str,
) -> None:
    """Round 137: show or set the rate-limit handling strategy."""
    from prometheus.rate_limit import (
        render_options, set_strategy, current_strategy,
        VALID_STRATEGIES,
    )
    arg = arg.strip().lower()
    if not arg:
        for line in render_options().splitlines():
            app._log(system_dim(line))
        return
    out = set_strategy(arg)
    if out is None:
        app._log(error_line(
            "unknown strategy: "
            + arg
            + ". choices: "
            + ", ".join(VALID_STRATEGIES)
        ))
        return
    app._log(system_dim(f"rate-limit strategy → {out}"))


async def cmd_ghost(app: "PrometheusApp", arg: str) -> None:
    """Round 138: toggle Ghost Writer mode.

    Usage:
      /ghost              toggle
      /ghost on|off       force-set
      /ghost status       show current
    """
    from prometheus.ghost_mode import (
        GhostMode, enable_ghost, disable_ghost, status_chip,
    )
    if not hasattr(app, "_ghost_mode") or app._ghost_mode is None:
        app._ghost_mode = GhostMode()
    g: GhostMode = app._ghost_mode
    a = arg.strip().lower()
    if a == "status":
        chip = status_chip(g)
        app._log(system_dim(
            f"ghost mode: {'on' if g.enabled else 'off'}"
            + (f"  ({chip})" if chip else "")
        ))
        return
    if a in ("", "toggle"):
        target = not g.enabled
    elif a in ("on", "true", "1"):
        target = True
    elif a in ("off", "false", "0"):
        target = False
    else:
        app._log(error_line("usage: /ghost [on|off|toggle|status]"))
        return
    if target == g.enabled:
        app._log(system_dim(
            f"ghost mode already {'on' if g.enabled else 'off'}"
        ))
        return
    if target:
        enable_ghost(g)
        # Reseed the system prompt so the ghost block takes
        # effect on the next turn.
        if app.agent and app.agent.messages:
            try:
                app.agent.messages[0]["content"] = app.agent.system_prompt()
            except Exception:
                pass
        app._log(system_dim("ghost mode → on  (GHOST)"))
    else:
        disable_ghost(g)
        if app.agent and app.agent.messages:
            try:
                app.agent.messages[0]["content"] = app.agent.system_prompt()
            except Exception:
                pass
        app._log(system_dim("ghost mode → off"))
    if hasattr(app, "_update_status"):
        app._update_status()


async def cmd_tui(app: "PrometheusApp", arg: str) -> None:
    """Round 138 + 141: TUI rendering mode controls.

    Usage:
      /tui                       toggle fullscreen
      /tui fullscreen            enter fullscreen
      /tui off                   leave fullscreen
      /tui status                show current rendering mode
                                 + sticky-prompt + diff-render
                                 + hardware-scroll state
    """
    from prometheus.tui_mode import (
        TuiMode, enable_fullscreen, disable_fullscreen,
        parse_tui_arg,
    )
    if not hasattr(app, "_tui_mode") or app._tui_mode is None:
        app._tui_mode = TuiMode()
    state: TuiMode = app._tui_mode
    sub = parse_tui_arg(arg)
    if sub == "status":
        # Round 141: extended status — show all rendering flags.
        try:
            from prometheus.tui_layout import (
                resolve_layout, render_layout_status,
            )
            mode = resolve_layout(getattr(app, "_settings_dict", None))
            for line in render_layout_status(mode).splitlines():
                app._log(system_dim(line))
        except Exception:
            app._log(system_dim(
                f"tui: {'fullscreen' if state.fullscreen else 'windowed'}"
            ))
        return
    if sub == "fullscreen":
        target = True
    elif sub == "off":
        target = False
    elif sub == "":
        target = not state.fullscreen
    else:
        app._log(error_line(
            "usage: /tui [fullscreen|off|status]"
        ))
        return
    if target == state.fullscreen:
        app._log(system_dim(
            f"tui already {'fullscreen' if state.fullscreen else 'windowed'}"
        ))
        return
    if target:
        enable_fullscreen(state)
        app._log(system_dim("tui → fullscreen"))
    else:
        disable_fullscreen(state)
        app._log(system_dim("tui → windowed"))
    if hasattr(app, "_update_status"):
        app._update_status()


async def cmd_usage_v138(app: "PrometheusApp", _arg: str) -> None:
    """Round 138: show provider usage limits + consumption.

    Local — reads cached headers from the most recent provider
    response. No API call. The provider populates
    `app._rate_limit_headers` after each request."""
    headers = getattr(app, "_rate_limit_headers", {}) or {}
    cost = float(getattr(app, "_cost_total_usd", 0.0) or 0.0)
    in_tok = int(getattr(app, "_tokens_total_in", 0) or 0)
    out_tok = int(getattr(app, "_tokens_total_out", 0) or 0)
    app._log(system_dim("usage — this session:"))
    app._log(system_dim(f"  ↑ input  : {in_tok:,} tokens"))
    app._log(system_dim(f"  ↓ output : {out_tok:,} tokens"))
    app._log(system_dim(f"  ≈ cost   : ${cost:.4f}"))
    app._log(system_dim(""))
    if headers:
        app._log(system_dim("provider rate limits (last response):"))
        for key in sorted(headers.keys()):
            if "limit" not in key.lower() and "remaining" not in key.lower():
                continue
            app._log(system_dim(f"  {key}: {headers[key]}"))
    else:
        app._log(system_dim(
            "  (no provider rate-limit headers cached yet — "
            "make any request to populate)"
        ))


async def cmd_status(app: "PrometheusApp", _arg: str) -> None:
    """Round 138: quick session status snapshot."""
    import time as _t
    started = float(getattr(app, "_session_started_at", 0) or 0)
    elapsed = int(_t.time() - started) if started else 0
    if elapsed >= 60:
        m, s = divmod(elapsed, 60)
        dur = f"{m}m {s}s"
    else:
        dur = f"{elapsed}s"
    model = getattr(app.settings, "model", "?") if app.settings else "?"
    perm = getattr(app.agent, "permission_mode", "?") if app.agent else "?"
    cohorts = list(getattr(app, "background_agents", []) or [])
    n_cohorts = len(cohorts)
    n_running = sum(
        1 for c in cohorts
        if getattr(c, "state", "") in ("running", "queued")
    )
    tools = []
    try:
        if app.agent and getattr(app.agent, "registry", None):
            tools = list(app.agent.registry.all())
    except Exception:
        tools = []
    app._log(system_dim("status:"))
    app._log(system_dim(f"  duration:     {dur}"))
    app._log(system_dim(f"  model:        {model}"))
    app._log(system_dim(f"  permissions:  {perm}"))
    app._log(system_dim(
        f"  cohorts:      {n_running} running / {n_cohorts} total"
    ))
    app._log(system_dim(f"  tools:        {len(tools)}"))
    if hasattr(app, "_ghost_mode") and getattr(
        app._ghost_mode, "enabled", False,
    ):
        app._log(system_dim("  ghost mode:   on"))
    if hasattr(app, "_fast_mode") and getattr(
        app._fast_mode, "enabled", False,
    ):
        app._log(system_dim("  fast mode:    on"))


async def cmd_login(app: "PrometheusApp", arg: str) -> None:
    """Round 138: store provider credentials.

    Usage:
      /login <provider>        — uses PROMETHEUS_AUTH_KEY env
                                 to avoid blocking-prompt issues
                                 inside the TUI
      /login status            — show what's configured
    """
    from prometheus.auth import (
        store_credential, auth_status, normalize_provider,
        VALID_PROVIDERS,
    )
    a = arg.strip().lower()
    if not a or a == "status":
        res = auth_status()
        for line in res.output.splitlines():
            app._log(system_dim(line))
        return
    p = normalize_provider(a)
    if p is None:
        app._log(error_line(
            f"unknown provider: {a!r}. choices: "
            + ", ".join(VALID_PROVIDERS)
        ))
        return
    key = os.environ.get("PROMETHEUS_AUTH_KEY", "").strip()
    if not key:
        app._log(error_line(
            "set PROMETHEUS_AUTH_KEY in your shell, then re-run "
            "/login. (Interactive prompt isn't available "
            "inside the chat UI.)"
        ))
        return
    res = store_credential(p, key)
    app._log(system_dim(res.output))


async def cmd_logout(app: "PrometheusApp", arg: str) -> None:
    """Round 138: clear stored provider credentials."""
    from prometheus.auth import clear_credential
    a = arg.strip().lower()
    res = clear_credential(a or None)
    app._log(system_dim(res.output))


async def cmd_rc(app: "PrometheusApp", arg: str) -> None:
    """Round 138: in-session remote-control controls.

    Usage:
      /rc                  start a remote-control session
      /rc stop             end the active session
      /rc status           show current state
    """
    from prometheus.remote_control import (
        new_session, render_pair_banner, stop_session,
    )
    a = arg.strip().lower()
    rc = getattr(app, "_rc_session", None)
    if a == "status":
        if rc is None:
            app._log(system_dim("rc: no active session"))
        else:
            app._log(system_dim(
                f"rc: active  url={rc.display_url}  "
                f"paired={rc.paired}"
            ))
        return
    if a == "stop":
        if rc is None:
            app._log(system_dim("rc: no active session"))
            return
        stop_session(rc)
        app._rc_session = None
        app._log(system_dim("rc: stopped"))
        return
    # Default: start a new one. Reuse the round-118 bridge port
    # if available; otherwise pick a safe default.
    port = int(
        getattr(app, "_bridge_port", 0)
        or os.environ.get("PROMETHEUS_BRIDGE_PORT", "8765") or "8765"
    )
    public_url = (
        getattr(app, "_bridge_public_url", "")
        or f"http://127.0.0.1:{port}"
    )
    sess = new_session(public_url=public_url, bridge_port=port)
    app._rc_session = sess
    for line in render_pair_banner(sess).splitlines():
        app._log(system_dim(line))


async def cmd_verify_v2(app: "PrometheusApp", arg: str) -> None:
    """Round 144-final: verify the last assistant output
    against optional success criteria.

    Usage:
      /verify
      /verify must contain X | should mention Y
    """
    from prometheus.verification_agent import (
        verify, render_verdict, parse_verify_arg,
    )
    if not app.agent or not getattr(app.agent, "messages", None):
        app._log(error_line("nothing to verify — empty session"))
        return
    msgs = app.agent.messages
    last_user = ""
    last_asst = ""
    for m in reversed(msgs):
        if not isinstance(m, dict):
            continue
        if m.get("role") == "assistant" and not last_asst:
            content = m.get("content")
            if isinstance(content, list):
                last_asst = " ".join(
                    str(b.get("text", "")) if isinstance(b, dict)
                    else str(b) for b in content
                )
            else:
                last_asst = str(content or "")
        elif m.get("role") == "user" and not last_user:
            last_user = str(m.get("content") or "")
        if last_asst and last_user:
            break
    parsed = parse_verify_arg(arg)
    verdict = verify(
        user_prompt=last_user,
        agent_output=last_asst,
        success_criteria=parsed.get("success_criteria"),
    )
    for line in render_verdict(verdict).splitlines():
        app._log(system_dim(line))


async def cmd_workflow(app: "PrometheusApp", arg: str) -> None:
    """Round 144-final: list or run a workflow.

    Usage:
      /workflow                — list discovered workflows
      /workflow <name>         — run a workflow
    """
    from prometheus.workflow_scripts import (
        discover_workflows, find_workflow,
        render_workflow_list, render_workflow,
    )
    a = (arg or "").strip()
    if not a:
        rows = discover_workflows(app.settings.workdir)
        for line in render_workflow_list(rows).splitlines():
            app._log(system_dim(line))
        return
    w = find_workflow(app.settings.workdir, a)
    if w is None:
        app._log(error_line(f"no workflow named {a!r}"))
        return
    for line in render_workflow(w).splitlines():
        app._log(system_dim(line))
    app._log(system_dim(""))
    app._log(system_dim(
        f"  ({len(w.steps)} step(s) — agent will dispatch each in order)"
    ))
    # Stash for the next agent loop iteration to consume.
    app._pending_workflow = w


async def cmd_frustration(app: "PrometheusApp", arg: str) -> None:
    """Round 144-final: smoke the frustration detector."""
    from prometheus.agent.frustration_detector import (
        detect, render_reading,
    )
    text = (arg or "").strip()
    if not text:
        # Default: scan the last user message.
        if app.agent and getattr(app.agent, "messages", None):
            for m in reversed(app.agent.messages):
                if isinstance(m, dict) and m.get("role") == "user":
                    text = str(m.get("content") or "")
                    break
    if not text:
        app._log(error_line("usage: /frustration <text>"))
        return
    reading = detect(text)
    for line in render_reading(reading).splitlines():
        app._log(system_dim(line))


async def cmd_classify_bash(
    app: "PrometheusApp", arg: str,
) -> None:
    """Round 144-final: classify a bash command's safety tier."""
    from prometheus.bash_classifier import classify, render
    text = (arg or "").strip()
    if not text:
        app._log(error_line("usage: /classify-bash <command>"))
        return
    c = classify(text)
    for line in render(c).splitlines():
        app._log(system_dim(line))


# ---------- Round 150 visualization commands ----------


async def cmd_pipeline(app: "PrometheusApp", _arg: str) -> None:
    """Round 150: visualize the 9-step turn pipeline."""
    from prometheus.pipeline_viz import (
        render_pipeline,
    )
    tracker = getattr(app, "_pipeline_tracker", None)
    for line in render_pipeline(tracker=tracker).splitlines():
        app._log(system_dim(line))


async def cmd_tool_pool(app: "PrometheusApp", _arg: str) -> None:
    """Round 150: visualize the 5-step tool-pool assembly."""
    from prometheus.pipeline_viz import render_tool_pool
    tracker = getattr(app, "_tool_pool_tracker", None)
    for line in render_tool_pool(tracker=tracker).splitlines():
        app._log(system_dim(line))


async def cmd_recovery_paths(app: "PrometheusApp", _arg: str) -> None:
    """Round 150: list the 7 recovery paths."""
    from prometheus.recovery_paths import render_recovery_paths
    for line in render_recovery_paths().splitlines():
        app._log(system_dim(line))


async def cmd_compaction_strategies(
    app: "PrometheusApp", _arg: str,
) -> None:
    from prometheus.compaction_catalogue import (
        render_compaction_strategies,
    )
    for line in render_compaction_strategies().splitlines():
        app._log(system_dim(line))


async def cmd_concurrency_model(
    app: "PrometheusApp", _arg: str,
) -> None:
    from prometheus.concurrency_catalogue import render_concurrency
    for line in render_concurrency().splitlines():
        app._log(system_dim(line))


async def cmd_devtools(app: "PrometheusApp", _arg: str) -> None:
    from prometheus.devtools_panel import render
    for line in render().splitlines():
        app._log(system_dim(line))


async def cmd_frameworks(app: "PrometheusApp", _arg: str) -> None:
    """Round 143-v2: list prompt frameworks."""
    from prometheus.prompt_interceptor import render_catalogue
    for line in render_catalogue().splitlines():
        app._log(system_dim(line))


async def cmd_inbox(app: "PrometheusApp", arg: str) -> None:
    """Round 143-v2: cross-session inbox.

    Usage:
      /inbox                       — list unread messages
      /inbox all                   — include read messages
      /inbox read                  — mark all read
      /inbox send <to> <body>      — send a message
      /inbox who                   — list known sessions
      /inbox clear                 — clear our inbox
    """
    from prometheus.uds_inbox import (
        uds_inbox_enabled, render_inbox, list_known_sessions,
        send_message, mark_all_read, clear_inbox,
    )
    if not uds_inbox_enabled():
        app._log(error_line(
            "/inbox needs PROMETHEUS_UDS_INBOX=1 (opt-in)"
        ))
        return
    sname = (
        getattr(app, "_session_name", None)
        or getattr(app, "session_id", None)
        or "default"
    )
    sname = str(sname)[:32]
    a = (arg or "").strip()
    if not a:
        for line in render_inbox(session_name=sname).splitlines():
            app._log(system_dim(line))
        return
    if a == "all":
        for line in render_inbox(
            session_name=sname, include_read=True,
        ).splitlines():
            app._log(system_dim(line))
        return
    if a == "read":
        n = mark_all_read(session_name=sname)
        app._log(system_dim(f"marked {n} message(s) read"))
        return
    if a == "who":
        peers = list_known_sessions()
        if not peers:
            app._log(system_dim("no known sessions"))
            return
        for p in peers:
            app._log(system_dim(f"  {p}"))
        return
    if a == "clear":
        ok = clear_inbox(session_name=sname)
        app._log(system_dim(
            "inbox cleared" if ok else "nothing to clear"
        ))
        return
    if a.startswith("send "):
        rest = a[len("send "):].strip().split(maxsplit=1)
        if len(rest) < 2:
            app._log(error_line(
                "usage: /inbox send <to> <body>"
            ))
            return
        to, body = rest[0], rest[1]
        msg = send_message(to=to, from_session=sname, body=body)
        if msg is None:
            app._log(error_line("send failed"))
        else:
            app._log(system_dim(
                f"sent #{msg.id} → {to}"
            ))
        return
    app._log(error_line(f"unknown /inbox sub: {a!r}"))


async def cmd_torch(app: "PrometheusApp", arg: str) -> None:
    """Round 144-v2: toggle Torch mode."""
    from prometheus.tools_v144 import (
        TorchMode, enable_torch, disable_torch, torch_status_chip,
    )
    if not hasattr(app, "_torch_mode") or app._torch_mode is None:
        app._torch_mode = TorchMode()
    s: TorchMode = app._torch_mode
    a = (arg or "").strip().lower()
    if a == "status":
        chip = torch_status_chip(s)
        app._log(system_dim(
            f"torch mode: {'on' if s.enabled else 'off'}"
            + (f"  ({chip})" if chip else "")
        ))
        return
    target = (
        not s.enabled if a in ("", "toggle")
        else (a in ("on", "true", "1"))
    )
    if target == s.enabled:
        app._log(system_dim(
            f"torch mode already {'on' if s.enabled else 'off'}"
        ))
        return
    if target:
        enable_torch(s)
        app._log(system_dim("torch mode → on  (TORCH)"))
    else:
        disable_torch(s)
        app._log(system_dim("torch mode → off"))
    if hasattr(app, "_update_status"):
        app._update_status()


async def cmd_templates(app: "PrometheusApp", arg: str) -> None:
    """Round 144-v2: list / load templates."""
    from prometheus.tools_v144 import (
        discover_templates, find_template, render_template_list,
    )
    a = (arg or "").strip()
    if not a or a == "list":
        rows = discover_templates(app.settings.workdir)
        for line in render_template_list(rows).splitlines():
            app._log(system_dim(line))
        return
    t = find_template(app.settings.workdir, a)
    if t is None:
        app._log(error_line(f"no template named {a!r}"))
        return
    app._log(system_dim(
        f"loaded template '{t.name}' ({len(t.body)} chars)"
    ))
    # Stash on app for the next prompt to consume.
    app._loaded_template = t.body


async def cmd_backfill_sessions(
    app: "PrometheusApp", _arg: str,
) -> None:
    """Round 144-v2: rebuild session index."""
    from prometheus.tools_v144 import (
        backfill_session_index, render_backfill,
    )
    stats = backfill_session_index()
    for line in render_backfill(stats).splitlines():
        app._log(system_dim(line))


async def cmd_perf_issue(app: "PrometheusApp", _arg: str) -> None:
    """Round 144-v2: capture a performance snapshot."""
    from prometheus.tools_v144 import (
        collect_perf_snapshot, render_perf_snapshot,
    )
    durations: dict[str, list[float]] = {}
    # Pull tool durations from app._tool_durations if the
    # host populates it; otherwise we just report frames.
    durations = getattr(app, "_tool_durations", None) or {}
    snap = collect_perf_snapshot(tool_durations=durations)
    for line in render_perf_snapshot(snap).splitlines():
        app._log(system_dim(line))


async def cmd_buddy(app: "PrometheusApp", arg: str) -> None:
    """Round 145: virtual companion."""
    from prometheus.buddy import (
        get_or_create, render_panel, pet, render_pet_burst,
    )
    user_id = (
        getattr(app.settings, "user_email", None)
        or os.environ.get("USER")
        or os.environ.get("USERNAME")
        or "anon"
    )
    b = get_or_create(str(user_id))
    a = (arg or "").strip().lower()
    if a == "pet":
        pet(b)
        for line in render_pet_burst().splitlines():
            app._log(system_dim(line))
        app._log(system_dim(f"  ❤ {b.name} purrs (×{b.times_petted})"))
        return
    for line in render_panel(b).splitlines():
        app._log(system_dim(line))


async def cmd_share(app: "PrometheusApp", arg: str) -> None:
    """Round 143: export the current session as a sanitized
    Markdown file under ~/.prometheus/shared/.

    Usage:
      /share                      — write the file
      /share <label>              — title the export
      /share --clipboard          — also copy to clipboard
      /share <label> --clipboard  — both
    """
    from prometheus.share_blade import (
        write_share, copy_to_clipboard, render_summary,
    )
    raw = (arg or "").strip()
    want_clip = False
    if "--clipboard" in raw:
        want_clip = True
        raw = raw.replace("--clipboard", "").strip()
    label = raw or "PrometheUS shared session"
    msgs = []
    if app.agent and getattr(app.agent, "messages", None):
        msgs = list(app.agent.messages)
    if not msgs:
        app._log(error_line("nothing to share — empty session"))
        return
    export = write_share(messages=msgs, label=label)
    for line in render_summary(export).splitlines():
        app._log(system_dim(line))
    if want_clip:
        body = export.path.read_text(encoding="utf-8")
        if copy_to_clipboard(body):
            app._log(system_dim("  copied to clipboard"))
        else:
            app._log(system_dim(
                "  clipboard unavailable (pyperclip not "
                "installed or no clipboard backend)"
            ))


async def cmd_selftest(app: "PrometheusApp", arg: str) -> None:
    """Round 144: run the 25-step verification harness.

    Usage:
      /selftest               — run + print report
      /selftest report        — same (alias for clarity)
    """
    from prometheus.selftest import run_selftest, render_report
    report = run_selftest(workdir=app.settings.workdir)
    for line in render_report(report).splitlines():
        app._log(system_dim(line))
    if not report.ok:
        app._log(error_line(
            f"selftest failed: {report.failed} step(s) regressed"
        ))


async def cmd_break_cache(app: "PrometheusApp", _arg: str) -> None:
    """Round 142: invalidate the prompt cache for the next turn.

    Behind PROMETHEUS_BREAK_CACHE=1 — opt-in because most users
    won't need this. When enabled, generates a fresh cache
    marker the agent loop threads into the next request."""
    from prometheus.context_commands import (
        break_cache, render_break_cache_banner,
        break_cache_enabled,
    )
    if not break_cache_enabled():
        app._log(error_line(
            "/break-cache requires PROMETHEUS_BREAK_CACHE=1 (opt-in)"
        ))
        return
    res = break_cache(current_marker=getattr(app, "_cache_marker", ""))
    app._cache_marker = res.new_marker
    for line in render_break_cache_banner(res).splitlines():
        app._log(system_dim(line))


async def cmd_force_snip(app: "PrometheusApp", arg: str) -> None:
    """Round 142: drop old messages immediately. Optionally
    pass a keep-last count.

    Usage:
      /force-snip          — keep last 20 messages
      /force-snip 50       — keep last 50
    """
    from prometheus.context_commands import (
        force_snip, render_snip_banner,
        force_snip_keep_last_default,
    )
    if not app.agent or not getattr(app.agent, "messages", None):
        app._log(system_dim("nothing to snip — empty session"))
        return
    keep_last = force_snip_keep_last_default()
    arg = (arg or "").strip()
    if arg:
        try:
            keep_last = max(1, int(arg))
        except ValueError:
            app._log(error_line(
                "usage: /force-snip [<keep-last-count>]"
            ))
            return
    new_msgs, res = force_snip(
        list(app.agent.messages), keep_last=keep_last,
    )
    app.agent.messages = new_msgs
    app._log(system_dim(render_snip_banner(res)))


async def cmd_transcript(app: "PrometheusApp", _arg: str) -> None:
    """Round 141: open the transcript viewer.

    Same surface as the Ctrl+O keybinding. The slash form
    exists so users without that key (some terminals swallow
    Ctrl+O) can still reach it."""
    from prometheus.tui_transcript import (
        TranscriptViewer, open_viewer, render_status,
    )
    if not hasattr(app, "_transcript_viewer") or app._transcript_viewer is None:
        app._transcript_viewer = TranscriptViewer()
    viewer: TranscriptViewer = app._transcript_viewer
    msgs = []
    if app.agent and getattr(app.agent, "messages", None):
        msgs = list(app.agent.messages)
    open_viewer(viewer, messages=msgs)
    app._log(system_dim(
        f"transcript: {len(viewer.lines)} lines  ·  cursor at {viewer.cursor + 1}"
    ))
    app._log(system_dim(render_status(viewer)))


async def cmd_audit(app: "PrometheusApp", _arg: str) -> None:
    """Round 140: run the feature-matrix audit and print the
    result. Verifies every surface from rounds 137–139 is still
    importable + behaving at its documented contract."""
    from prometheus.feature_matrix import run_audit, render_audit
    report = run_audit()
    for line in render_audit(report).splitlines():
        app._log(system_dim(line))


async def cmd_schedule(app: "PrometheusApp", arg: str) -> None:
    """Round 139: register a cron-based remote agent.

    Two forms:
      /schedule
        — interactive: prompts for cron, task, model
      /schedule --cron "0 9 * * 1-5" --task "..." --model sonnet
        — non-interactive

    Both register a routine via the round-111 routines engine
    (writes to `~/.prometheus/routines/`).
    """
    from prometheus.scheduling import (
        parse_inline_args, validate_cron, make_routine,
        write_routine, render_routine,
        SCHEDULE_PROMPT_QUESTIONS,
    )
    inline = parse_inline_args(arg)
    if inline.get("cron") and inline.get("task"):
        ok, msg = validate_cron(inline["cron"])
        if not ok:
            app._log(error_line(f"/schedule: {msg}"))
            return
        routine = make_routine(
            cron=inline["cron"],
            task=inline["task"],
            model=inline.get("model", ""),
        )
        if routine is None:
            app._log(error_line(
                "/schedule: validation failed — check cron + task"
            ))
            return
        path = write_routine(routine)
        for line in render_routine(routine).splitlines():
            app._log(system_dim(line))
        app._log(system_dim(f"  written to {path}"))
        return
    # Interactive — surface the questions; the host's elicit
    # path picks them up.
    app._log(system_dim("schedule a routine — please supply:"))
    for q in SCHEDULE_PROMPT_QUESTIONS:
        app._log(system_dim(
            f"  • {q['label']:18s}  ({q['hint']})"
        ))
    app._log(system_dim(""))
    app._log(system_dim(
        "or run non-interactively: "
        "`/schedule --cron \"0 9 * * 1-5\" "
        "--task \"review PRs\" --model sonnet`"
    ))


async def cmd_projects(app: "PrometheusApp", arg: str) -> None:
    """Round 139: list and switch between Prometheus projects.

    Usage:
      /projects                  — list registered projects
      /projects <name>           — switch to project by name
      /projects remove <name>    — drop from registry
    """
    from prometheus.projects import (
        upsert_project, list_projects, find_project,
        remove_project, render_projects, parse_projects_arg,
    )
    # Always upsert the current workdir so it shows up.
    try:
        upsert_project(app.settings.workdir)
    except Exception:
        pass
    action, target = parse_projects_arg(arg)
    if action == "list":
        for line in render_projects(list_projects()).splitlines():
            app._log(system_dim(line))
        return
    if action == "remove":
        if not target:
            app._log(error_line("usage: /projects remove <name>"))
            return
        removed = remove_project(target)
        if removed is None:
            app._log(error_line(f"no project matching {target!r}"))
            return
        app._log(system_dim(
            f"removed {removed.name}  ({removed.path})"
        ))
        return
    # switch
    proj = find_project(target)
    if proj is None:
        app._log(error_line(f"no project matching {target!r}"))
        return
    app._log(system_dim(
        f"switching to {proj.name}  ({proj.path})"
    ))
    app._log(system_dim(
        f"  on launch: prometheus -C \"{proj.path}\""
    ))
    # Mark the chosen project on the app so the host can read
    # it on its next launch path.
    app._target_project = proj


async def cmd_shortcuts(app: "PrometheusApp", _arg: str) -> None:
    """Round 136: print the keyboard-shortcuts overlay text.
    The TUI's `?` key dispatches the same body via the overlay
    widget; this slash command makes it accessible from the
    chat history as well."""
    from prometheus.keyboard import (
        shortcut_catalogue, render_shortcut_overlay,
    )
    body = render_shortcut_overlay(shortcut_catalogue())
    for line in body.splitlines():
        app._log(system_dim(line))


def build_default_router(app: "PrometheusApp") -> "SlashRouter":
    r = SlashRouter(app)
    # session
    r.add("new",      "start a new session",                  cmd_new,      "session")
    r.add("clear",    "clear chat + reset session",           cmd_clear,    "session")
    r.add("history",  "show recent prompts",                  cmd_history,  "session")
    r.add("sessions", "list saved sessions",                  cmd_sessions, "session")
    r.add("resume",   "resume a saved session",               cmd_resume,   "session")
    r.add("rename",   "label the current session",            cmd_rename,   "session")
    r.add("compact",  "summarize older turns",                cmd_compact,  "session")
    r.add("recap",    "summarize this session at-a-glance",   cmd_recap,    "session")
    r.add("branch",   "fork the current session",             cmd_branch,   "session")
    r.add("export",   "export session (.md or .html)",        cmd_export,   "session")
    r.add("transcript", "export session as HTML page",         cmd_transcript, "session")
    # code
    r.add("explain",        "explain a file or symbol",       cmd_explain,    "code")
    r.add("review",         "review pending git changes",     cmd_review,     "code")
    r.add("tests",          "write tests for a target",       cmd_tests,      "code")
    r.add("commit-message", "draft a commit message",         cmd_commit_msg, "code")
    r.add("commit",      "stage all + commit with auto-message", cmd_commit,    "code")
    r.add("revert",      "git revert HEAD (or given ref)",     cmd_revert,      "code")
    r.add("verify",      "re-check last reply against request", cmd_verify,     "code")
    r.add("implement",   "issue-driven dev (github/linear/jira)", cmd_implement, "code")
    r.add("worktree",    "fork a worktree + dispatch /async agent", cmd_worktree, "code")
    r.add("share",       "export session to local static HTML",  cmd_share,    "session")
    r.add("visual",      "screenshot a URL and verify with vision", cmd_visual, "code")
    r.add("typecheck",   "run the project's typechecker + propose fixes", cmd_typecheck, "code")
    r.add("diff",           "show git diff stat",             cmd_diff,       "code")
    # files
    r.add("open",   "read a file",                      cmd_open,   "files")
    r.add("index",  "summarize files in workdir",       cmd_index,  "files")
    r.add("run",    "run a shell command",              cmd_run,    "files")
    r.add("expand", "show the full body of a receipt",  cmd_expand, "files")
    r.add("copy",   "copy last reply to clipboard",     cmd_copy,   "files")
    r.add("bashes", "manage background bash jobs",      cmd_bashes, "files")
    r.add("tree",   "directory tree (3 levels)",        cmd_tree,   "files")
    # workflow shortcuts — auto-detect runner from project files
    r.add("git",    "shortcut for git <subcommand>",    cmd_git,    "code")
    r.add("status", "git + project status overview",    cmd_status, "code")
    r.add("lint",   "run the project linter",           cmd_lint,   "code")
    r.add("test",   "run the project test suite",       cmd_test,   "code")
    r.add("format", "run the project formatter",        cmd_format, "code")
    # web
    r.add("search", "web search",                       cmd_search, "web")
    r.add("browse", "fetch a URL",                      cmd_browse, "web")
    # memory
    r.add("init",  "create PROMETHEUS.md",              cmd_init,  "memory")
    r.add("learn", "save a preference to user memory",  cmd_learn, "memory")
    # safety
    r.add("plan",        "switch to plan mode",         cmd_plan,        "safety")
    r.add("proceed",     "switch to acceptEdits mode",  cmd_proceed,     "safety")
    r.add("architect",   "plan with reasoner → /proceed with coder", cmd_architect, "safety")
    r.add("permissions", "show or set permission mode", cmd_permissions, "safety")
    r.add("rewind",      "undo last turn",              cmd_rewind,      "safety")
    r.add("undo",        "alias for /rewind",           cmd_rewind,      "safety")
    r.add("redo",        "step forward after /rewind",  cmd_redo,        "safety")
    r.add("trust",       "trust this directory's project config", cmd_trust,    "safety")
    r.add("untrust",     "revoke trust for a directory",          cmd_untrust,  "safety")
    r.add("trusted",     "list trusted directories",              cmd_trusted_list, "safety")
    r.add("escalate",    "next turn → paid tier",                 cmd_escalate, "meta")
    r.add("credits",     "show spend + escalation status",        cmd_credits,  "meta")
    r.add("byok",        "use your own escalation key (this session)", cmd_byok, "meta")
    r.add("checkpoints", "list/restore individual file snapshots", cmd_checkpoints, "safety")
    r.add("skills",      "list discovered skills",                cmd_skills,   "meta")
    r.add(
        "aptitude",
        "list / show / activate Aptitudes",
        cmd_aptitude,
        "meta",
    )
    r.add(
        "sentinels",
        "list configured Sentinel hooks",
        cmd_sentinels,
        "meta",
    )
    r.add(
        "forge",
        "manage Forge Kits (extensions)",
        cmd_forge,
        "meta",
    )
    r.add(
        "foundry",
        "manage Foundry marketplaces",
        cmd_foundry,
        "meta",
    )
    r.add(
        "cohorts",
        "list / show Cohort definitions",
        cmd_cohorts,
        "meta",
    )
    r.add(
        "tasks",
        "show Work Log tasks",
        cmd_tasks,
        "meta",
    )
    r.add(
        "anchor",
        "save / restore conversation checkpoints",
        cmd_anchor,
        "memory",
    )
    r.add(
        "memory",
        "manage Memory Vault entries",
        cmd_memory,
        "memory",
    )
    r.add(
        "overseer",
        "inspect / test the Overseer classifier",
        cmd_overseer,
        "meta",
    )
    r.add(
        "lsp",
        "list configured LSP servers",
        cmd_lsp,
        "meta",
    )
    r.add(
        "blades",
        "manage Command Blades (custom slash commands)",
        cmd_blades,
        "meta",
    )
    r.add(
        "ide",
        "show IDE/Workstation integration status",
        cmd_ide,
        "meta",
    )
    r.add(
        "vim",
        "toggle vim-mode editing on the input buffer",
        cmd_vim,
        "meta",
    )
    r.add(
        "loop",
        "schedule a periodic prompt (/loop 5m <prompt>)",
        cmd_loop,
        "meta",
    )
    # 1.0.3 (CC v2.1.105 parity): /proactive is a documented alias for /loop.
    r.add(
        "proactive",
        "alias for /loop — schedule a periodic prompt",
        cmd_loop,
        "meta",
    )
    r.add(
        "rules",
        "list / show / validate path-scoped rules",
        cmd_rules,
        "meta",
    )
    r.add(
        "routine",
        "manage scheduled autonomous routines",
        cmd_routine,
        "meta",
    )
    r.add(
        "team-onboarding",
        "generate ONBOARDING.md from project config",
        cmd_team_onboarding,
        "meta",
    )
    r.add(
        "theme",
        "switch terminal color theme",
        cmd_theme,
        "meta",
    )
    r.add(
        "bridge",
        "start a remote-view bridge for a phone/browser",
        cmd_bridge,
        "meta",
    )
    r.add(
        "voice",
        "toggle voice input mode",
        cmd_voice,
        "meta",
    )
    r.add(
        "outcomes",
        "load a success-criteria rubric for auto-retry",
        cmd_outcomes,
        "meta",
    )
    r.add(
        "dream",
        "run a self-improvement cycle and write a dream report",
        cmd_dream,
        "meta",
    )
    r.add(
        "powerup",
        "open an interactive tutorial",
        cmd_powerup,
        "meta",
    )
    # Round 124-129 final-parity surface.
    r.add(
        "bash-mode",
        "toggle bash-mode (! prefix executes shell directly)",
        cmd_bash_mode,
        "meta",
    )
    r.add(
        "fork",
        "fork the current session at the conversation point",
        cmd_fork,
        "session",
    )
    r.add(
        "branch",
        "alias for /fork",
        cmd_fork,
        "session",
    )
    r.add(
        "export",
        "export the current transcript as plain text",
        cmd_export,
        "session",
    )
    r.add(
        "recap",
        "one-line summary of the current session",
        cmd_recap,
        "session",
    )
    r.add(
        "processes",
        "list / kill background bash processes",
        cmd_processes,
        "meta",
    )
    r.add(
        "context",
        "visualize context-window usage",
        cmd_context,
        "meta",
    )
    r.add(
        "insights",
        "write a session-insights report",
        cmd_insights,
        "meta",
    )
    r.add(
        "btw",
        "side question against session context (no tools, no history)",
        cmd_btw,
        "meta",
    )
    r.add(
        "release-notes",
        "show the changelog for the current version",
        cmd_release_notes,
        "meta",
    )
    r.add(
        "extra-usage",
        "configure rate-limit behavior",
        cmd_extra_usage,
        "meta",
    )
    r.add(
        "teams",
        "manage Agent Team teammates",
        cmd_teams,
        "meta",
    )
    r.add(
        "keybindings",
        "open ~/.prometheus/keybindings.json in your editor",
        cmd_keybindings,
        "meta",
    )
    r.add("statusline",  "manage shell-driven custom statusline", cmd_statusline, "meta")
    r.add("voice",       "toggle voice dictation (Ctrl+Space)",   cmd_voice,    "meta")
    r.add("plugins",     "manage installed plugins",              cmd_plugins,  "meta")
    r.add("async",       "detach a prompt into a background job", cmd_async,    "files")
    r.add("jobs",        "list/inspect/kill async jobs",          cmd_jobs,     "files")
    # meta
    r.add("output-style", "switch reply style",   cmd_output_style, "meta")
    r.add("effort",       "set thinking effort",  cmd_effort,       "meta")
    r.add("theme",        "switch color theme",   cmd_theme,        "meta")
    r.add("mouse",        "toggle mouse capture", cmd_mouse,        "meta")
    r.add("hooks",        "list PreToolUse / PostToolUse hooks", cmd_hooks, "meta")
    r.add("agents",       "list subagent definitions", cmd_agents, "meta")
    r.add("mcp",          "list MCP servers",     cmd_mcp,          "meta")
    r.add("help",         "list commands",        cmd_help,         "meta")
    r.add("model",   "show or switch engine", cmd_model,   "meta")
    r.add("config",  "show configuration",    cmd_config,  "meta")
    r.add("doctor",  "run health checks",     cmd_doctor,  "meta")
    r.add("stats",   "show session stats",    cmd_stats,   "meta")
    r.add("cost",    "show running cost",     cmd_cost,    "meta")
    r.add("usage",   "merged cost + tokens + context (alias)", cmd_usage, "meta")
    r.add("focus",   "toggle low-noise view of chat", cmd_focus, "meta")
    r.add("atomic-commits", "auto-commit after every successful edit batch", cmd_atomic_commits, "code")
    r.add("benchmarks", "generate a release scorecard for leaderboard PRs", cmd_benchmarks, "meta")
    r.add("pause",   "snapshot now + stop the loop · /resume to continue", cmd_pause, "session")
    r.add("provider", "show free-tier provider pool + remaining capacity", cmd_provider, "meta")
    r.add("feedback", "bundle session transcript for a bug report (local-only)", cmd_feedback, "meta")
    r.add("thumbsup", "record a 👍 signal locally",          cmd_thumbsup, "meta")
    r.add("thumbsdown", "record a 👎 signal locally",        cmd_thumbsdown, "meta")
    r.add("context", "show context size",     cmd_context, "meta")
    r.add("compact", "compact display (default — clean public view)", cmd_compact, "meta")
    r.add("verbose", "verbose display (full receipts + raw output)",  cmd_verbose, "meta")
    r.add("details", "show full output for last tool call",            cmd_details, "meta")
    r.add("stats",   "honest token + active-context breakdown",         cmd_stats,   "meta")
    r.add("timeline", "list recent tool calls in this session",       cmd_timeline, "meta")
    r.add("release-notes", "what's new in this build", cmd_release_notes, "meta")
    r.add("version", "show version",          cmd_version, "meta")
    r.add("quit",    "exit",                  cmd_quit,    "meta")
    r.add("exit",    "exit",                  cmd_quit,    "meta")
    # ----- Round 131: PR integration -----
    r.add("review",       "review the open PR (or PR <N>)", cmd_review,        "code")
    r.add("pr-comments",  "post inline review comments to a PR", cmd_pr_comments, "code")
    r.add("autofix-pr",   "watch PR CI and propose+push fixes", cmd_autofix_pr, "code")
    # ----- Round 132: session/environment tools -----
    r.add("diff",     "interactive diff viewer (j/k nav)",  cmd_diff,        "code")
    r.add("add-dir",  "expand the workdir set",             cmd_add_dir,     "session")
    r.add("teleport", "pull a remote web session into the local terminal", cmd_teleport, "session")
    r.add("tp",       "alias of /teleport",                 cmd_teleport,    "session")
    # ----- Round 134: terminal UX -----
    r.add("terminal-setup", "tune the terminal for PrometheUS", cmd_terminal_setup, "meta")
    r.add("color",      "switch the color palette",            cmd_color,        "meta")
    r.add("heapdump",   "write a one-shot heap snapshot",      cmd_heapdump,     "meta")
    r.add("fewer-permission-prompts", "show the fewer-prompts playbook", cmd_fewer_prompts, "meta")
    r.add("claude-api", "show the Anthropic Messages API quick reference", cmd_claude_api, "meta")
    # ----- Round 136: ultimate cleanup -----
    r.add("fast",         "toggle Fast Mode (lower latency)",      cmd_fast,         "meta")
    r.add("reload-forge", "hot-reload all Forge Kits",             cmd_reload_forge, "meta")
    r.add("bug",          "submit a bug report (local-only)",      cmd_bug,          "meta")
    r.add("shortcuts",    "show keyboard shortcuts overlay",       cmd_shortcuts,    "meta")
    # ----- Round 137: TRUE-final commands -----
    r.add("debug",            "enable diagnostics by category",        cmd_debug,             "meta")
    r.add("rate-limit-options", "set rate-limit handling strategy",   cmd_rate_limit_options, "meta")
    # ----- Round 138: ABSOLUTE-final commands -----
    r.add("ghost",     "toggle Ghost Writer mode",          cmd_ghost,    "meta")
    r.add("tui",       "TUI mode controls (fullscreen)",    cmd_tui,      "meta")
    # R220: the previous `r.add("usage", ..., cmd_usage_v138)` here was
    # a duplicate that shadowed the merged-form `cmd_usage` registered
    # earlier. The plan-limits/headers block from cmd_usage_v138 is now
    # appended inside cmd_usage itself, so users get the merged output
    # plus rate-limit headers from a single /usage call. cmd_usage_v138
    # is kept as a public function for backwards compatibility but is
    # no longer wired to a slash command.
    r.add("status",    "quick session status snapshot",     cmd_status,   "meta")
    r.add("login",     "store provider credentials",        cmd_login,    "meta")
    r.add("logout",    "clear stored provider credentials", cmd_logout,   "meta")
    r.add("rc",        "remote-control session controls",   cmd_rc,       "session")
    # ----- Round 139: GENUINE-final commands -----
    r.add("schedule",  "register a cron-based remote agent",      cmd_schedule, "session")
    r.add("projects",  "list and switch between projects",        cmd_projects, "session")
    # ----- Round 140: feature-matrix audit -----
    r.add("audit",     "verify the round-140 feature matrix",     cmd_audit, "meta")
    # ----- Round 141: TUI alignment -----
    r.add("transcript", "open the transcript viewer (Ctrl+O)",     cmd_transcript, "session")
    # ----- Round 142: context-management commands -----
    r.add("break-cache", "invalidate the prompt cache",             cmd_break_cache, "session")
    r.add("force-snip",  "drop old messages now (history snip)",    cmd_force_snip, "session")
    # ----- Round 143: /share blade -----
    r.add("share",       "export sanitized session as Markdown",   cmd_share,      "session")
    # ----- Round 144: /selftest harness -----
    r.add("selftest",    "run the round-144 self-test harness",    cmd_selftest,   "meta")
    # ----- Round 143-v2: prompt frameworks + UDS inbox -----
    r.add("frameworks",  "list prompt frameworks (L99/OODA/...)",  cmd_frameworks, "meta")
    r.add("inbox",       "show cross-session inbox messages",      cmd_inbox,      "session")
    # ----- Round 144-v2: torch / templates / backfill / perf -----
    r.add("torch",       "toggle Torch mode (aggressive context burn)", cmd_torch, "meta")
    r.add("templates",   "list / load workflow templates",         cmd_templates,  "session")
    r.add("backfill-sessions", "rebuild session index from transcripts", cmd_backfill_sessions, "meta")
    r.add("perf-issue",  "capture a performance snapshot",         cmd_perf_issue, "meta")
    # ----- Round 145: buddy pet -----
    r.add("buddy",       "show your virtual companion (`/buddy pet` to pet)", cmd_buddy, "meta")
    # ----- Round 143-final / 144-final / 145-final -----
    r.add("verify",      "verify last agent output against criteria", cmd_verify_v2, "meta")
    r.add("workflow",    "list / run a declarative workflow",     cmd_workflow,    "session")
    r.add("frustration", "scan a message for frustration signals", cmd_frustration, "meta")
    r.add("classify-bash", "classify a bash command's safety tier", cmd_classify_bash, "meta")
    # ----- Round 150: pipeline visualization -----
    r.add("pipeline",      "visualize the 9-step turn pipeline",  cmd_pipeline,      "meta")
    r.add("tool-pool",     "visualize the 5-step tool-pool assembly", cmd_tool_pool, "meta")
    r.add("recovery-paths", "list the 7 recovery paths",          cmd_recovery_paths, "meta")
    r.add("compaction-strategies", "list compaction strategies + thresholds", cmd_compaction_strategies, "meta")
    r.add("concurrency-model", "tool concurrency classification", cmd_concurrency_model, "meta")
    r.add("devtools",      "developer debugging panel",           cmd_devtools,      "meta")
    # Discover user/project-defined commands. They show up alongside the
    # built-ins under the "Custom" category in /help.
    _load_custom_commands(r, app)
    # Discover plugin-shipped commands. Plugins live in ~/.prometheus/plugins/
    # and were installed via /plugins install.
    try:
        from prometheus.plugins import load_plugin_commands
        load_plugin_commands(app, r)
    except Exception:
        pass
    app.slash = r
    return r
