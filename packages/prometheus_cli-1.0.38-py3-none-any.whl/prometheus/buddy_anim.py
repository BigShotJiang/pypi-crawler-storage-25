"""Round 145-final: enhanced buddy animations.

Extends `prometheus/buddy.py` with:

  * full 3-frame ASCII animations per species (already in
    buddy.py — this module adds the *idle* tick + *pet
    burst* timeline)
  * `IdleTicker` at 500ms intervals
  * `HeartBurst` — 2.5s heart-emoji float over 5 frames

Pure data-layer. The host mounts a 500ms timer and pulls
`tick(now)` to know which frame to render; the pet command
spawns a `HeartBurst` and pulls frames over the next 2.5s.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional


# ---------- idle ticker ----------


_IDLE_INTERVAL_MS = 500


@dataclass
class IdleTicker:
    """Round 145-final: drives the 3-frame idle animation
    across 500ms ticks."""
    started_at: Optional[float] = None
    frame_count: int = 3

    def tick(self, *, now: Optional[float] = None) -> int:
        """Round 145-final: returns the frame index 0..N-1
        for the current monotonic time. Auto-starts on the
        first tick."""
        t = now if now is not None else time.monotonic()
        if self.started_at is None:
            self.started_at = t
            return 0
        elapsed_ms = (t - self.started_at) * 1000.0
        return int(elapsed_ms // _IDLE_INTERVAL_MS) % self.frame_count

    def reset(self) -> None:
        self.started_at = None


# ---------- heart-burst animation ----------


_BURST_DURATION_S = 2.5
_BURST_FRAMES = (
    "    ♥",
    "   ♥ ♥",
    "  ♥ ♥ ♥",
    "   ♥ ♥",
    "    ♥",
)


@dataclass
class HeartBurst:
    """Round 145-final: 5-frame floating heart emoji burst
    spread over 2.5s. Returns empty when the animation has
    completed."""
    started_at: Optional[float] = None

    def start(self, *, now: Optional[float] = None) -> None:
        self.started_at = now if now is not None else time.monotonic()

    def active(self, *, now: Optional[float] = None) -> bool:
        if self.started_at is None:
            return False
        t = now if now is not None else time.monotonic()
        return (t - self.started_at) <= _BURST_DURATION_S

    def frame(self, *, now: Optional[float] = None) -> str:
        """Round 145-final: current frame text. Empty when
        inactive."""
        if self.started_at is None:
            return ""
        t = now if now is not None else time.monotonic()
        elapsed = t - self.started_at
        if elapsed > _BURST_DURATION_S:
            return ""
        # Map elapsed → frame index via even spacing.
        n = len(_BURST_FRAMES)
        idx = min(n - 1, int((elapsed / _BURST_DURATION_S) * n))
        return _BURST_FRAMES[idx]

    def reset(self) -> None:
        self.started_at = None


# ---------- combined animation state ----------


@dataclass
class BuddyAnimationState:
    """Round 145-final: snapshot the host renders each frame.
    Composes the idle ticker + any active heart burst."""
    idle: IdleTicker = field(default_factory=IdleTicker)
    burst: HeartBurst = field(default_factory=HeartBurst)

    def trigger_pet(self, *, now: Optional[float] = None) -> None:
        self.burst.start(now=now)

    def render(
        self,
        *,
        species: str,
        now: Optional[float] = None,
    ) -> tuple[str, str]:
        """Round 145-final: returns (idle_frame, burst_frame).
        The host overlays the burst on top of the idle frame
        when the burst is active."""
        from prometheus.buddy import frame_at
        f = self.idle.tick(now=now)
        idle_text = frame_at(species, f)
        burst_text = (
            self.burst.frame(now=now) if self.burst.active(now=now)
            else ""
        )
        return (idle_text, burst_text)
