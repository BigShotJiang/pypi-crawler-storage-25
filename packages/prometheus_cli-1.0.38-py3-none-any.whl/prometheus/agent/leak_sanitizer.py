"""Round 97.1: tool-call-markup leak sanitizer.

Live failure on round 97: when the user asked PrometheUS to start
three background subagents, the model (a free-tier OpenRouter
model) emitted text like

    <function/run_bash{"command": "...", "run_in_background": true}</function>

three times INSIDE its assistant text instead of using the
tool_calls API channel. The UI rendered the raw markup directly
into the public conversation transcript — a serious public-facing
leak.

The fix has three layers:

  1. **Prevention** — system-prompt guardrail tells the model
     never to emit tool-call markup as text (lives in
     `prometheus/agent/system.py`).
  2. **Detection + suppression** at render time — this module.
     Strips the leaked markup from text BEFORE it hits the
     chat-log.
  3. **Self-correction signal** — when a leak is detected, we
     surface a one-line system note in the conversation so the
     user knows what happened and the model sees the correction
     in its own history on the next iteration.

Public API:
  * `detect_tool_call_leak(text)` → bool
  * `extract_leaks(text)` → list[ParsedLeak]
  * `sanitize(text)` → (cleaned_text, list[ParsedLeak])

The patterns covered are the ones we've seen in the wild:
  * `<function/NAME{...}</function>` — observed verbatim
  * `<function NAME>{...}</function>` — tag-style variant
  * `<tool_use>...</tool_use>` — defensive
  * `<function_calls>...</function_calls>` — defensive
  * `[tool_call: NAME(args)]` — defensive

Each pattern is matched conservatively — we'd rather miss a weird
new variant than false-positive on prose that happens to mention
`<function>`. New variants get added when we observe them.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ParsedLeak:
    """A parsed tool-call-markup leak. `args` is the parsed JSON
    dict on success, None when JSON parsing failed (in which case
    `raw_args` carries the original string for debugging)."""
    tool_name: str
    args: Optional[dict[str, Any]]
    raw_args: str
    raw: str

    @property
    def description(self) -> str:
        """One-line description for the system-warning surface."""
        if self.args is None:
            return self.raw_args[:80]
        # Common arg keys we care about: description, command, prompt,
        # path. Pick the first one present.
        for key in ("description", "command", "prompt", "path",
                    "subject"):
            v = self.args.get(key)
            if isinstance(v, str) and v.strip():
                return v.strip()[:80]
        return self.tool_name


# ---------- patterns ----------


# Primary pattern observed in the round 97.1 screenshot. The
# `function/` prefix is unusual — most function-calling APIs use
# `<function NAME>` or `<tool_use>`. This catches the exact form
# we saw in the wild.
_RE_FUNCTION_SLASH = re.compile(
    r"<function/([A-Za-z_][A-Za-z0-9_]*)\s*"
    r"(\{.*?\})\s*"
    r"</function>",
    flags=re.DOTALL,
)

# Defensive: `<function NAME>{...}</function>` (without the slash).
_RE_FUNCTION_SPACE = re.compile(
    r"<function\s+([A-Za-z_][A-Za-z0-9_]*)\s*>\s*"
    r"(\{.*?\})\s*"
    r"</function>",
    flags=re.DOTALL,
)

# Anthropic-style tool_use envelope. We don't try to parse the
# inner XML structure — just strip the whole envelope so it
# doesn't leak.
_RE_TOOL_USE = re.compile(
    r"<tool_use>.*?</tool_use>",
    flags=re.DOTALL,
)
_RE_FUNCTION_CALLS = re.compile(
    r"<function_calls>.*?</function_calls>",
    flags=re.DOTALL,
)

# Bracketed text-style markup: `[tool_call: name(args)]`. Less
# common but seen in some model outputs.
_RE_BRACKET_TOOL_CALL = re.compile(
    r"\[tool_call:\s*([A-Za-z_][A-Za-z0-9_]*)\s*\((.*?)\)\s*\]",
    flags=re.DOTALL,
)

# Round 210: JSON-shape tool call leak. Live T7 (multi-agent
# orchestration) capture surfaced the model emitting four
# concatenated `{"name": "task", "arguments": {...}}` JSON blocks
# as plain text, instead of using the structured tool_use channel.
# Restrictive on purpose: only matches a JSON object that has
# BOTH a string `"name"` and an object `"arguments"` at the top
# level, with the name beginning with a letter (so we don't
# false-positive on `{"name": 42, ...}` or arbitrary JSON in
# documentation).
#
# The body uses a balanced-brace approximation: `\{[^{}]*\}` for
# the inner `arguments` object, then a final `\}`. This handles
# the wild-emission shape without trying to parse arbitrary
# nested JSON via regex.
_RE_JSON_TOOL_CALL = re.compile(
    r"\{\s*"
    r'"name"\s*:\s*"([A-Za-z_][A-Za-z0-9_]*)"\s*,\s*'
    r'"arguments"\s*:\s*'
    r"(\{(?:[^{}]|\{[^{}]*\})*\})"
    r"\s*\}",
    flags=re.DOTALL,
)
# Known tool names — used to gate the JSON detector so that an
# unrelated `{"name": "user", "arguments": {...}}` JSON object in
# user data isn't mistaken for a leaked tool call. This list
# mirrors what `build_default_registry` ships; new tools should
# be added here when they're added there.
_KNOWN_TOOL_NAMES_FOR_LEAK = frozenset({
    "read_file", "write_file", "edit_file", "multi_edit", "apply_patch",
    "glob_files", "list_files", "search_code", "run_bash", "bash_output",
    "kill_shell", "web_fetch", "web_search", "todo_write", "calculator",
    "discover_test_command", "task", "task_create", "task_update",
    "task_get", "task_list", "team_create", "team_delete", "send_message",
    "team_broadcast", "monitor", "skill", "remote_trigger",
    "enter_worktree", "exit_worktree", "task_stop", "task_output",
    "notebook_edit", "powershell", "enter_plan_mode", "exit_plan_mode",
    "list_mcp_resources", "read_mcp_resource",
})


# Quick top-level check used by the UI before doing the more
# expensive extract pass.
def _has_json_tool_call_leak(text: str) -> bool:
    """Round 210: JSON-shape leak detector. Gated on a known tool
    name so we don't false-positive on user data."""
    if not text or '"arguments"' not in text:
        return False
    for m in _RE_JSON_TOOL_CALL.finditer(text):
        if m.group(1) in _KNOWN_TOOL_NAMES_FOR_LEAK:
            return True
    return False


def detect_tool_call_leak(text: str) -> bool:
    """Cheap regex scan — returns True if the text appears to
    contain any of the supported leak patterns."""
    if not text:
        return False
    return bool(
        _RE_FUNCTION_SLASH.search(text)
        or _RE_FUNCTION_SPACE.search(text)
        or _RE_TOOL_USE.search(text)
        or _RE_FUNCTION_CALLS.search(text)
        or _RE_BRACKET_TOOL_CALL.search(text)
        or _has_json_tool_call_leak(text)
    )


def extract_leaks(text: str) -> list[ParsedLeak]:
    """Find every leak pattern in `text` and return parsed records.

    JSON args are parsed when possible; on failure the raw string
    is preserved in `raw_args` and `args` is None. Order of
    returned leaks matches their position in the input text."""
    if not text:
        return []
    leaks: list[ParsedLeak] = []

    def _try_json(raw: str) -> Optional[dict[str, Any]]:
        try:
            obj = json.loads(raw)
            if isinstance(obj, dict):
                return obj
        except (ValueError, TypeError):
            pass
        return None

    for m in _RE_FUNCTION_SLASH.finditer(text):
        name, raw_args = m.group(1), m.group(2)
        leaks.append(ParsedLeak(
            tool_name=name,
            args=_try_json(raw_args),
            raw_args=raw_args,
            raw=m.group(0),
        ))
    for m in _RE_FUNCTION_SPACE.finditer(text):
        name, raw_args = m.group(1), m.group(2)
        leaks.append(ParsedLeak(
            tool_name=name,
            args=_try_json(raw_args),
            raw_args=raw_args,
            raw=m.group(0),
        ))
    for m in _RE_BRACKET_TOOL_CALL.finditer(text):
        name, raw_args = m.group(1), m.group(2)
        # Bracket form's args are usually keyword=value, not JSON.
        # Don't try to parse — just keep raw.
        leaks.append(ParsedLeak(
            tool_name=name,
            args=None,
            raw_args=raw_args.strip(),
            raw=m.group(0),
        ))
    # tool_use / function_calls envelopes don't carry a parseable
    # tool name at this depth — record them as opaque so the UI
    # surfaces "leaked tool-use envelope" without claiming to know
    # which tool.
    for m in _RE_TOOL_USE.finditer(text):
        leaks.append(ParsedLeak(
            tool_name="<tool_use>",
            args=None,
            raw_args="",
            raw=m.group(0),
        ))
    for m in _RE_FUNCTION_CALLS.finditer(text):
        leaks.append(ParsedLeak(
            tool_name="<function_calls>",
            args=None,
            raw_args="",
            raw=m.group(0),
        ))
    # Round 210: JSON-shape `{"name": "task", "arguments": {...}}` leaks.
    # Only treated as a leak when the name matches a known tool, so
    # documentation/JSON examples don't get stripped.
    for m in _RE_JSON_TOOL_CALL.finditer(text):
        name = m.group(1)
        if name not in _KNOWN_TOOL_NAMES_FOR_LEAK:
            continue
        raw_args = m.group(2)
        leaks.append(ParsedLeak(
            tool_name=name,
            args=_try_json(raw_args),
            raw_args=raw_args,
            raw=m.group(0),
        ))
    return leaks


def sanitize(text: str) -> tuple[str, list[ParsedLeak]]:
    """Return (cleaned_text, leaks). The cleaned text has every
    leak block stripped; the returned `leaks` list lets the
    caller surface a system-warning line per leak."""
    if not text or not detect_tool_call_leak(text):
        return text, []
    leaks = extract_leaks(text)
    cleaned = text
    for pattern in (
        _RE_FUNCTION_SLASH,
        _RE_FUNCTION_SPACE,
        _RE_TOOL_USE,
        _RE_FUNCTION_CALLS,
        _RE_BRACKET_TOOL_CALL,
    ):
        cleaned = pattern.sub("", cleaned)
    # Round 210: JSON-shape leaks. Only strip when the name matches
    # a known tool — protects user JSON data / examples in prose.
    def _strip_known_json(match: re.Match) -> str:
        return "" if match.group(1) in _KNOWN_TOOL_NAMES_FOR_LEAK else match.group(0)
    cleaned = _RE_JSON_TOOL_CALL.sub(_strip_known_json, cleaned)
    # Collapse runs of blank lines that the strip may have created.
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    # Trim trailing whitespace per line so we don't leave dangling
    # spaces where a leak was inline with prose.
    cleaned = "\n".join(ln.rstrip() for ln in cleaned.splitlines())
    return cleaned, leaks


def warning_line(leak: ParsedLeak) -> str:
    """One-line user-facing recovery message. Quoted in the
    public scrollback as a `system_dim(...)` so the user knows
    something was stripped — better than silent suppression."""
    desc = leak.description
    if leak.tool_name in ("<tool_use>", "<function_calls>"):
        return (
            "⚠ model emitted tool-call envelope as text "
            "(suppressed; please retry via the tool_calls channel)"
        )
    return (
        f"⚠ model emitted `{leak.tool_name}` as text "
        f"(suppressed; would have called: {desc})"
    )


# ---------- round 97.2: auto-recovery into real tool calls ----------


# Cap on how many leaks we'll recover per turn. The model is the
# attacker here — if it loops emitting markup we don't want to
# fire 50 tool calls. Round-39's repetition guard catches the
# stuck-loop case but the cap is a defense-in-depth measure.
MAX_RECOVERIES_PER_TURN = 8

# Allowlist of tool names we'll recover. Built from the default
# registry's safe tools — anything outside this set is suppressed
# but not executed. Lives in this module rather than dynamically
# pulled from the registry so the audit surface is explicit.
RECOVERABLE_TOOL_NAMES = frozenset({
    # Read-side
    "read_file", "list_files", "glob_files", "search_code",
    "discover_test_command", "bash_output", "web_fetch",
    "web_search", "calculator",
    # Write-side (already gated by permission_mode at execute time)
    "write_file", "edit_file", "multi_edit", "apply_patch",
    "todo_write",
    # Exec
    "run_bash",
    # Subagent dispatch
    "task",
})


@dataclass
class RecoveryRecord:
    """One result of the recovery process. Mirrors ParsedLeak but
    with extra fields about what happened: was it executed (`accepted`),
    was it rewritten (`canonicalized_from`), was it refused (`refused_reason`)?"""
    leak: ParsedLeak
    accepted: bool
    tool_name: str                       # final tool name (post-canonicalization)
    arguments_json: str                  # final JSON-string args
    canonicalized_from: Optional[str] = None  # original name if rewritten
    refused_reason: Optional[str] = None


def _canonicalize(
    tool_name: str, args: dict[str, Any],
) -> tuple[str, dict[str, Any], Optional[str]]:
    """Apply known model-confusion canonicalizations.

    The big one (round 97.2): if the model called `run_bash` with
    `run_in_background: true`, it really meant the `task` tool's
    background dispatch. Translate it. Returns
    `(new_name, new_args, original_name_if_rewritten)`."""
    if (
        tool_name == "run_bash"
        and args.get("run_in_background") is True
    ):
        cmd = str(args.get("command", "") or "").strip()
        desc = str(args.get("description", "") or "").strip()
        if not cmd:
            # No command — refuse to canonicalize, let the
            # validator reject downstream.
            return tool_name, args, None
        new_args: dict[str, Any] = {
            "description": desc or cmd[:60],
            # The subagent runs an isolated agent that will do the
            # work; phrase the command as a focused subtask prompt.
            "prompt": (
                f"Run the following shell command and report its "
                f"results concisely:\n\n```\n{cmd}\n```"
            ),
            "subagent_type": "general-purpose",
            "run_in_background": True,
        }
        return "task", new_args, "run_bash"
    return tool_name, args, None


def recover_tool_calls(
    text: str,
    *,
    allowlist: Optional[frozenset[str]] = None,
    max_recoveries: int = MAX_RECOVERIES_PER_TURN,
) -> tuple[str, list[RecoveryRecord]]:
    """Round 97.2: parse leaked tool-call markup out of `text`,
    validate against the allowlist, apply canonicalization, and
    return synthetic tool-call records the agent loop can dispatch.

    Returns `(cleaned_text, records)`:
      * `cleaned_text` — `text` with all leak markup stripped.
      * `records` — one RecoveryRecord per leak. `accepted=True`
        means the loop should execute the call; `accepted=False`
        means the leak was suppressed (the warning_line is built
        from `leak.description` regardless).

    Safety rules:
      * Only allowlisted tool names are accepted.
      * Args MUST be valid JSON (envelope-only leaks like
        `<tool_use>...</tool_use>` are auto-rejected).
      * Canonicalization is applied AFTER allowlist check so a
        translated `task` call is still allowlist-checked.
      * Cap at `max_recoveries`. Excess leaks are suppressed with
        `refused_reason="cap exceeded"`.
    """
    cleaned, leaks = sanitize(text)
    if not leaks:
        return cleaned, []
    allow = allowlist if allowlist is not None else RECOVERABLE_TOOL_NAMES
    records: list[RecoveryRecord] = []
    accepted_count = 0
    for leak in leaks:
        # Cap enforcement.
        if accepted_count >= max_recoveries:
            records.append(RecoveryRecord(
                leak=leak,
                accepted=False,
                tool_name=leak.tool_name,
                arguments_json="",
                refused_reason="cap exceeded",
            ))
            continue
        # Reject envelope-only leaks immediately — we don't have
        # a structured tool name to dispatch against.
        if leak.tool_name in ("<tool_use>", "<function_calls>"):
            records.append(RecoveryRecord(
                leak=leak,
                accepted=False,
                tool_name=leak.tool_name,
                arguments_json="",
                refused_reason="opaque envelope",
            ))
            continue
        # Args must have parsed cleanly.
        if leak.args is None:
            records.append(RecoveryRecord(
                leak=leak,
                accepted=False,
                tool_name=leak.tool_name,
                arguments_json=leak.raw_args,
                refused_reason="malformed args",
            ))
            continue
        # Canonicalize before allowlist check so a rewritten name
        # is what gets validated.
        new_name, new_args, original = _canonicalize(
            leak.tool_name, leak.args,
        )
        if new_name not in allow:
            records.append(RecoveryRecord(
                leak=leak,
                accepted=False,
                tool_name=new_name,
                arguments_json=json.dumps(new_args),
                canonicalized_from=original,
                refused_reason=f"tool {new_name!r} not in allowlist",
            ))
            continue
        # Accepted.
        records.append(RecoveryRecord(
            leak=leak,
            accepted=True,
            tool_name=new_name,
            arguments_json=json.dumps(new_args),
            canonicalized_from=original,
        ))
        accepted_count += 1
    return cleaned, records


def recovery_warning_line(record: RecoveryRecord) -> str:
    """User-facing one-liner about what happened to a leak.
    Used by the UI/loop to surface recovery actions in dim system
    style. Three shapes:
      * accepted          — `↻ recovered text-emitted tool call: <desc>`
      * accepted (canon.) — `↻ recovered & canonicalized run_bash → task: <desc>`
      * refused           — `⚠ suppressed text-emitted call: <reason>`
    """
    if record.accepted:
        if record.canonicalized_from:
            return (
                f"↻ recovered & canonicalized "
                f"{record.canonicalized_from} → {record.tool_name}: "
                f"{record.leak.description}"
            )
        return (
            f"↻ recovered text-emitted tool call: "
            f"{record.tool_name} · {record.leak.description}"
        )
    return (
        f"⚠ suppressed text-emitted call to "
        f"{record.tool_name!r}: {record.refused_reason}"
    )
