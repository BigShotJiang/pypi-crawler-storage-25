"""Round 120: Outcomes — success-criteria-driven auto-retry.

`/outcomes <markdown-file>` loads a rubric. After each turn the
agent self-evaluates against the rubric. If criteria are not met
and we're under the retry cap, the loop re-runs with the rubric
as additional context.

Round-120 ships:
  * `Rubric` parser — reads bulleted/checkboxed markdown into a
    list of criteria.
  * `Outcomes` engine — tracks criteria, retry count, completion.
  * Self-eval helper that produces a synthesized "did you hit
    each criterion?" report from assistant text.
  * `/outcomes <file>` and `/outcomes stop` slash commands.

Self-evaluation uses heuristic substring + fuzzy matching by
default. An optional evaluator-cohort path can be wired by a
caller to produce richer scoring.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


def max_retries() -> int:
    try:
        return max(0, int(
            os.environ.get("PROMETHEUS_OUTCOMES_MAX_RETRIES", "5")
        ))
    except (TypeError, ValueError):
        return 5


@dataclass
class Criterion:
    text: str               # original line, with leading bullet stripped
    keywords: tuple[str, ...] = ()   # extracted lowercase tokens

    @property
    def short(self) -> str:
        first = self.text.strip().splitlines()[0] if self.text else ""
        return first[:80] + ("…" if len(first) > 80 else "")


@dataclass
class Rubric:
    """A parsed success-criteria rubric.

    File format: any markdown with bullet (`-`, `*`, or `+`) or
    checkbox (`- [ ]`) lines. Each line becomes a criterion.
    Lines outside bullets are treated as preamble context."""
    criteria: list[Criterion] = field(default_factory=list)
    preamble: str = ""
    source_path: Optional[Path] = None


# Bullet / checkbox markers we recognize.
_BULLET_RX = re.compile(
    r"^\s*(?:[-*+]|\d+\.)\s+(?:\[[ x]\]\s+)?(.+?)\s*$",
    re.MULTILINE,
)


def parse_rubric(text: str, *, source_path: Optional[Path] = None) -> Rubric:
    """Round 120: turn a markdown rubric into criteria + preamble."""
    criteria: list[Criterion] = []
    for m in _BULLET_RX.finditer(text):
        line = m.group(1).strip()
        if not line:
            continue
        # Skip empty checkboxes that are just "- [ ]" with no body.
        if line in ("[ ]", "[x]", "[X]"):
            continue
        keywords = tuple(
            w.strip(",.;:!?\"()[]'`").lower()
            for w in line.split()
            if len(w) > 3
        )[:8]
        criteria.append(Criterion(text=line, keywords=keywords))
    # Preamble = text before the first bullet, capped.
    preamble = ""
    first_match = _BULLET_RX.search(text)
    if first_match:
        preamble = text[: first_match.start()].strip()
    return Rubric(
        criteria=criteria, preamble=preamble[:1_000],
        source_path=source_path,
    )


def load_rubric_file(path: Path) -> Optional[Rubric]:
    if not path.exists() or not path.is_file():
        return None
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    return parse_rubric(text, source_path=path)


# ---------- evaluator ----------


@dataclass
class CriterionScore:
    criterion: Criterion
    met: bool
    confidence: float       # 0.0 - 1.0
    evidence: str = ""


def evaluate_assistant_reply(
    rubric: Rubric, assistant_text: str,
) -> list[CriterionScore]:
    """Heuristic self-eval: a criterion is "met" when the
    assistant's reply mentions enough of the criterion's
    keywords. Confidence is the fraction of keywords matched.

    This is a simple baseline — real users with a paid model
    can swap in an evaluator cohort for richer scoring."""
    out: list[CriterionScore] = []
    text_low = assistant_text.lower()
    for c in rubric.criteria:
        if not c.keywords:
            out.append(CriterionScore(
                criterion=c, met=False, confidence=0.0,
                evidence="(no keywords extracted)",
            ))
            continue
        hits = sum(1 for k in c.keywords if k in text_low)
        confidence = hits / len(c.keywords)
        # Threshold: ≥ 60% of keywords present.
        met = confidence >= 0.6
        evidence = f"{hits}/{len(c.keywords)} keywords matched"
        out.append(CriterionScore(
            criterion=c, met=met,
            confidence=round(confidence, 2),
            evidence=evidence,
        ))
    return out


def all_met(scores: list[CriterionScore]) -> bool:
    return bool(scores) and all(s.met for s in scores)


def render_score_summary(scores: list[CriterionScore]) -> str:
    if not scores:
        return "(no criteria)"
    lines = []
    n_met = sum(1 for s in scores if s.met)
    lines.append(f"{n_met}/{len(scores)} criteria met")
    for s in scores:
        mark = "✓" if s.met else "·"
        lines.append(
            f"  {mark} {s.criterion.short} "
            f"(confidence {s.confidence:.2f})"
        )
    return "\n".join(lines)


# ---------- engine ----------


@dataclass
class Outcomes:
    """Round 120: per-session outcomes engine. Lives on the app
    at `app._outcomes`. Loaded by `/outcomes <file>`,
    cleared by `/outcomes stop`."""
    rubric: Optional[Rubric] = None
    retries_used: int = 0
    completed: bool = False
    last_scores: list[CriterionScore] = field(default_factory=list)

    @property
    def active(self) -> bool:
        return self.rubric is not None and not self.completed

    def reset(self) -> None:
        self.rubric = None
        self.retries_used = 0
        self.completed = False
        self.last_scores = []

    def record_attempt(
        self, assistant_text: str,
    ) -> tuple[bool, list[CriterionScore]]:
        """Score `assistant_text` against the active rubric and
        update internal state. Returns `(should_retry, scores)`."""
        if not self.active:
            return False, []
        scores = evaluate_assistant_reply(self.rubric, assistant_text)
        self.last_scores = scores
        if all_met(scores):
            self.completed = True
            return False, scores
        if self.retries_used >= max_retries():
            return False, scores
        self.retries_used += 1
        return True, scores

    def render_retry_prompt(self) -> str:
        """When we want to retry, build a prompt that includes
        the rubric + which criteria failed so the agent can
        narrow its next attempt."""
        if self.rubric is None:
            return ""
        lines = [
            "Your previous reply did not satisfy the success "
            "criteria. Re-attempt the task. Each criterion "
            "MUST be addressed:",
            "",
        ]
        for s in self.last_scores:
            mark = "✓" if s.met else "✗"
            lines.append(f"  {mark} {s.criterion.text}")
        if self.rubric.preamble:
            lines.append("")
            lines.append("Context:")
            lines.append(self.rubric.preamble)
        return "\n".join(lines)
