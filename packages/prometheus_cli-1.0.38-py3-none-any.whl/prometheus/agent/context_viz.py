"""Round 127: /context — visualize context-window usage.

Walks the agent's `messages` list and bucket-counts by role and
type so the UI can render a colored grid showing how much of the
window each component owns. Helps users decide when to /compact.

Buckets:
  * system            — system prompt + Charter + Aptitudes
  * user              — user messages
  * assistant         — assistant turns (text)
  * tool_calls        — assistant tool_call records (JSON)
  * tool_outputs      — tool result messages
  * other             — anything that doesn't fit
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any


# Approximate token-per-byte ratio. The 4-bytes-per-token rule
# the rest of PrometheUS uses for live context estimates.
APPROX_TOKEN_BYTES = 4


@dataclass
class ContextBuckets:
    system: int = 0
    user: int = 0
    assistant: int = 0
    tool_calls: int = 0
    tool_outputs: int = 0
    other: int = 0

    def total(self) -> int:
        return (
            self.system + self.user + self.assistant
            + self.tool_calls + self.tool_outputs + self.other
        )

    def to_dict(self) -> dict[str, int]:
        return {
            "system": self.system,
            "user": self.user,
            "assistant": self.assistant,
            "tool_calls": self.tool_calls,
            "tool_outputs": self.tool_outputs,
            "other": self.other,
        }


@dataclass
class ContextSnapshot:
    """One full context-window snapshot: byte buckets + window
    size + percentage breakdown."""
    buckets: ContextBuckets
    window_bytes: int            # context-window size in bytes
    used_bytes: int

    @property
    def used_pct(self) -> float:
        if self.window_bytes <= 0:
            return 0.0
        return min(100.0, (self.used_bytes / self.window_bytes) * 100)

    @property
    def remaining_bytes(self) -> int:
        return max(0, self.window_bytes - self.used_bytes)

    def color_for(self, pct: float) -> str:
        """Round 127: traffic-light coloring per the spec."""
        if pct >= 80:
            return "red"
        if pct >= 50:
            return "yellow"
        return "green"

    def overall_color(self) -> str:
        return self.color_for(self.used_pct)

    def bucket_pcts(self) -> dict[str, float]:
        if self.window_bytes <= 0:
            return {k: 0.0 for k in self.buckets.to_dict()}
        return {
            k: round(v / self.window_bytes * 100, 1)
            for k, v in self.buckets.to_dict().items()
        }


def _byte_size(value: Any) -> int:
    """Best-effort byte-count of a message field. Strings count
    their length; other types JSON-encode and count that."""
    if isinstance(value, str):
        return len(value)
    try:
        return len(json.dumps(value, default=str))
    except Exception:
        return len(str(value))


def bucket_messages(messages: list[dict[str, Any]]) -> ContextBuckets:
    """Round 127: walk the message list and bucket-count by role
    and content type."""
    b = ContextBuckets()
    for m in messages or []:
        role = (m.get("role") or "").lower()
        content_size = _byte_size(m.get("content"))
        if role == "system":
            b.system += content_size
        elif role == "user":
            b.user += content_size
        elif role == "assistant":
            b.assistant += content_size
            tcs = m.get("tool_calls") or []
            for tc in tcs:
                b.tool_calls += _byte_size(tc)
        elif role == "tool":
            b.tool_outputs += content_size
        else:
            b.other += content_size
    return b


def snapshot_context(
    messages: list[dict[str, Any]], *,
    window_bytes: int = 1_000_000,
) -> ContextSnapshot:
    """Build a ContextSnapshot from `messages`. `window_bytes`
    defaults to a 1 MB approximation (~250k tokens) but the
    caller can pass the actual model-context limit."""
    b = bucket_messages(messages)
    return ContextSnapshot(
        buckets=b,
        window_bytes=window_bytes,
        used_bytes=b.total(),
    )


def render_context_grid(snap: ContextSnapshot) -> str:
    """Round 127: ASCII-art context grid, 40 cells wide. Each
    cell represents 2.5% of the window. Cells are filled
    according to the bucket order; the rest are empty."""
    width = 40
    cells = [" "] * width
    bucket_chars = {
        "system": "▌",
        "user": "▐",
        "assistant": "█",
        "tool_calls": "▓",
        "tool_outputs": "░",
        "other": "·",
    }
    pct = snap.bucket_pcts()
    cursor = 0
    lines: list[str] = []
    for label, char in bucket_chars.items():
        n = max(0, round(pct[label] / 100 * width))
        for _ in range(n):
            if cursor >= width:
                break
            cells[cursor] = char
            cursor += 1
    grid = "[" + "".join(cells) + "]"
    color = snap.overall_color()
    lines.append(f"context · {snap.used_pct:.1f}% used · {color}")
    lines.append(grid)
    lines.append("")
    lines.append("legend:")
    for label, char in bucket_chars.items():
        b_pct = pct[label]
        b_bytes = snap.buckets.to_dict()[label]
        b_tokens = b_bytes // APPROX_TOKEN_BYTES
        lines.append(
            f"  {char}  {label:<14} "
            f"{b_pct:>5.1f}% · ~{b_tokens:,} tokens"
        )
    lines.append("")
    rem_tokens = snap.remaining_bytes // APPROX_TOKEN_BYTES
    lines.append(
        f"remaining: ~{rem_tokens:,} tokens "
        f"(~{snap.remaining_bytes:,} bytes)"
    )
    if snap.used_pct >= 80:
        lines.append("⚠ over 80% — /compact recommended")
    return "\n".join(lines)
