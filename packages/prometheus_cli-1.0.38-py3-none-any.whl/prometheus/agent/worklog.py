"""Round 101 (Phase 4): Work Log — structured task coordination.

The Work Log is a richer task system on top of PrometheUS's
existing TodoWrite. Each WorkItem has:

  * `id`         — short hex
  * `subject`    — imperative title
  * `description`— longer body, optional
  * `status`     — pending / in_progress / completed / failed / cancelled
  * `dependencies` — list of WorkItem ids
  * `owner`      — `main` | `cohort:<id>` | `team:<lead-id>`
  * `notes`      — list of timestamped strings
  * `created_at` / `updated_at` — ISO timestamps

Persisted to `.prometheus/worklog.json` so subagents and resumed
sessions see the same task list. The Phase-4 spec calls for four
explicit task tools; this module is the storage layer; the tools
that wrap it are added below.
"""
from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional


VALID_STATUSES = ("pending", "in_progress", "completed", "failed", "cancelled")


@dataclass
class WorkItem:
    id: str
    subject: str
    description: str = ""
    status: str = "pending"
    dependencies: list[str] = field(default_factory=list)
    owner: str = "main"
    notes: list[str] = field(default_factory=list)
    created_at: str = ""
    updated_at: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, raw: dict) -> "WorkItem":
        return cls(
            id=str(raw.get("id", "")),
            subject=str(raw.get("subject", "")),
            description=str(raw.get("description", "")),
            status=str(raw.get("status", "pending")),
            dependencies=[str(x) for x in (raw.get("dependencies") or [])],
            owner=str(raw.get("owner", "main")),
            notes=[str(x) for x in (raw.get("notes") or [])],
            created_at=str(raw.get("created_at", "")),
            updated_at=str(raw.get("updated_at", "")),
        )


def _now_iso() -> str:
    import datetime as _dt
    return _dt.datetime.now(_dt.timezone.utc).isoformat()


def _short_id() -> str:
    return uuid.uuid4().hex[:8]


@dataclass
class WorkLog:
    """In-memory + on-disk task list. Persists to
    `.prometheus/worklog.json`."""
    workdir: Path
    items: list[WorkItem] = field(default_factory=list)

    @property
    def path(self) -> Path:
        return self.workdir / ".prometheus" / "worklog.json"

    @classmethod
    def load(cls, workdir: Path) -> "WorkLog":
        log = cls(workdir=workdir)
        p = log.path
        if not p.exists() or not p.is_file():
            return log
        try:
            data = json.loads(p.read_text(encoding="utf-8", errors="replace"))
        except (OSError, ValueError):
            return log
        for raw in (data.get("items") or []):
            if isinstance(raw, dict):
                log.items.append(WorkItem.from_dict(raw))
        return log

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            self.path.write_text(
                json.dumps(
                    {"items": [it.to_dict() for it in self.items]},
                    indent=2, default=str,
                ),
                encoding="utf-8",
            )
        except OSError:
            pass

    def create(
        self, *,
        subject: str,
        description: str = "",
        dependencies: Optional[list[str]] = None,
        owner: str = "main",
    ) -> WorkItem:
        now = _now_iso()
        item = WorkItem(
            id=_short_id(),
            subject=subject.strip(),
            description=description.strip(),
            dependencies=list(dependencies or []),
            owner=owner,
            created_at=now,
            updated_at=now,
        )
        self.items.append(item)
        self.save()
        return item

    def update(
        self, item_id: str,
        *,
        status: Optional[str] = None,
        subject: Optional[str] = None,
        description: Optional[str] = None,
        owner: Optional[str] = None,
        add_dependency: Optional[str] = None,
        add_note: Optional[str] = None,
    ) -> Optional[WorkItem]:
        item = self.get(item_id)
        if item is None:
            return None
        changed = False
        if status is not None and status in VALID_STATUSES:
            item.status = status
            changed = True
        if subject is not None:
            item.subject = subject.strip()
            changed = True
        if description is not None:
            item.description = description.strip()
            changed = True
        if owner is not None:
            item.owner = owner
            changed = True
        if add_dependency:
            if add_dependency not in item.dependencies:
                item.dependencies.append(add_dependency)
                changed = True
        if add_note:
            item.notes.append(f"{_now_iso()} · {add_note.strip()}")
            changed = True
        if changed:
            item.updated_at = _now_iso()
            self.save()
        return item

    def get(self, item_id: str) -> Optional[WorkItem]:
        for it in self.items:
            if it.id == item_id:
                return it
        return None

    def list(self, *, status: Optional[str] = None) -> list[WorkItem]:
        if status is None:
            return list(self.items)
        return [it for it in self.items if it.status == status]

    def remove(self, item_id: str) -> bool:
        before = len(self.items)
        self.items = [it for it in self.items if it.id != item_id]
        if len(self.items) != before:
            self.save()
            return True
        return False

    def summary(self) -> dict[str, int]:
        out: dict[str, int] = {s: 0 for s in VALID_STATUSES}
        for it in self.items:
            out[it.status] = out.get(it.status, 0) + 1
        return out
