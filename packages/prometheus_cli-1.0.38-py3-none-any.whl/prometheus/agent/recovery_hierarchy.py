"""Round 161 — Hardening 3: dual-state recovery hierarchy.

Research (Dual-State Architecture): retry explosion is what kills
multi-step agent runs. The fix is three explicit recovery levels:

  L1 — Context Refinement: inject the error + a hint into the next
       turn's context. Retry the *same* step with enriched context.
       Caps at 2 retries.

  L2 — Informed Backtracking: if L1 exhausts, walk back to the last
       successful checkpoint and invalidate every downstream output
       that depended on the failed step. Re-execute from there with
       the lessons learned baked into context.

  L3 — Human Escalation: if L2 also fails, pause the run and surface
       a clear, actionable message naming the last successful step,
       the failed step, and one suggested action.

The hierarchy is a state machine. Each step the agent executes is a
`Step(name, depends_on)` and produces a `StepResult(ok, output)`. The
hierarchy's job is to orchestrate retries / backtracks / escalation
without the LLM having to reason about it.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Awaitable, Callable, Optional


class Level(str, Enum):
    L1_REFINE = "L1_context_refinement"
    L2_BACKTRACK = "L2_informed_backtracking"
    L3_ESCALATE = "L3_human_escalation"


@dataclass
class Step:
    """One unit of work in a multi-step plan."""
    name: str
    depends_on: tuple[str, ...] = ()
    """Names of steps this one depends on. Used by L2 to invalidate
    downstream outputs when an upstream step is re-executed."""


@dataclass
class StepResult:
    ok: bool
    output: str = ""
    error: str = ""
    hint: str = ""


@dataclass
class RecoveryRecord:
    step: str
    level: Level
    attempt: int
    note: str


@dataclass
class HierarchyState:
    """Mutable orchestration state. The agent loop creates one of
    these per multi-step task and feeds Step results into it."""
    plan: list[Step] = field(default_factory=list)
    completed: dict[str, StepResult] = field(default_factory=dict)
    """name → last successful result"""
    invalidated: set[str] = field(default_factory=set)
    """names of completed steps invalidated by an L2 backtrack"""
    retry_counts: dict[str, int] = field(default_factory=dict)
    history: list[RecoveryRecord] = field(default_factory=list)
    max_l1_retries: int = 2
    max_l2_backtracks: int = 1


@dataclass
class EscalationNotice:
    last_successful: Optional[str]
    failed: str
    suggestion: str
    error: str

    def render(self) -> str:
        last = self.last_successful or "(none — failed on first step)"
        return (
            "⚠️ Task stalled after 2 recovery attempts.\n"
            f"  Last successful step: {last}\n"
            f"  Failed step:          {self.failed}\n"
            f"  Last error:           {self.error or '(empty)'}\n"
            f"  Suggested action:     {self.suggestion}"
        )


class RecoveryHierarchy:
    """The orchestrator. Drive it with `step()` and it decides which
    of L1 / L2 / L3 fires next."""

    def __init__(self, plan: list[Step]) -> None:
        self.state = HierarchyState(plan=list(plan))

    # ---- public API --------------------------------------------

    async def execute(
        self,
        runner: Callable[[Step, str], Awaitable[StepResult]],
        *,
        on_recover: Callable[[RecoveryRecord], None] | None = None,
    ) -> tuple[bool, Optional[EscalationNotice]]:
        """Drive the plan to completion. `runner(step, refined_hint)`
        executes one step and returns its result. Returns
        `(success, escalation_notice_if_any)`."""
        s = self.state
        last_successful: Optional[str] = None
        for step in s.plan:
            ok = await self._run_with_recovery(
                step, runner, last_successful=last_successful,
                on_recover=on_recover,
            )
            if not ok:
                # Build a clear escalation notice and bail.
                notice = EscalationNotice(
                    last_successful=last_successful,
                    failed=step.name,
                    suggestion=self._suggestion_for(step),
                    error=s.completed.get(step.name, StepResult(False)).error,
                )
                return False, notice
            last_successful = step.name
        return True, None

    # ---- internal --------------------------------------------------

    async def _run_with_recovery(
        self, step: Step,
        runner: Callable[[Step, str], Awaitable[StepResult]],
        *, last_successful: Optional[str],
        on_recover: Callable[[RecoveryRecord], None] | None,
    ) -> bool:
        s = self.state
        # L1 — try with enriched context up to max_l1_retries times.
        hint = ""
        for attempt in range(s.max_l1_retries + 1):
            res = await runner(step, hint)
            if res.ok:
                s.completed[step.name] = res
                s.retry_counts[step.name] = attempt
                return True
            # Failed — record and prepare L1 hint for next attempt.
            s.completed[step.name] = res
            rec = RecoveryRecord(
                step=step.name, level=Level.L1_REFINE,
                attempt=attempt + 1,
                note=f"L1 refine #{attempt + 1}: {res.error[:120]}",
            )
            s.history.append(rec)
            if on_recover: on_recover(rec)
            # Build the L1 hint from the failure.
            hint = (
                f"<system-reminder>\n"
                f"⚠️ Step `{step.name}` failed on attempt "
                f"{attempt + 1}: {res.error[:200]}.\n"
                f"Hint: {res.hint or 'inspect the error and adjust before retrying.'}\n"
                f"</system-reminder>"
            )
        # L1 exhausted — try L2 backtrack.
        for bt in range(s.max_l2_backtracks):
            target = self._pick_backtrack_target(step)
            if target is None:
                break
            # Invalidate downstream outputs.
            invalidated = self._invalidate_downstream(target.name)
            s.invalidated.update(invalidated)
            rec = RecoveryRecord(
                step=step.name, level=Level.L2_BACKTRACK,
                attempt=bt + 1,
                note=f"L2 backtrack to `{target.name}`; invalidated {sorted(invalidated)}",
            )
            s.history.append(rec)
            if on_recover: on_recover(rec)
            # Re-run target with a backtrack hint, then retry the
            # original failing step.
            bt_hint = (
                f"<system-reminder>\n"
                f"⚠️ Backtracking — earlier output of `{target.name}` "
                f"may be the root cause of `{step.name}` failures. "
                f"Re-execute it cleanly, then retry the failing step.\n"
                f"</system-reminder>"
            )
            target_res = await runner(target, bt_hint)
            if not target_res.ok:
                continue  # L2 itself failed — try escalation.
            s.completed[target.name] = target_res
            # Retry the failing step once.
            res = await runner(step, "<system-reminder>retry after L2 backtrack</system-reminder>")
            if res.ok:
                s.completed[step.name] = res
                return True
            s.completed[step.name] = res
        # L3 — surface escalation.
        rec = RecoveryRecord(
            step=step.name, level=Level.L3_ESCALATE, attempt=1,
            note="L3 human escalation — both L1 and L2 exhausted",
        )
        s.history.append(rec)
        if on_recover: on_recover(rec)
        return False

    def _pick_backtrack_target(self, failing: Step) -> Optional[Step]:
        """The most recent dependency of the failing step. We back to
        the immediate parent because that's where corrupted output
        most often originates — going further is more disruption than
        useful."""
        if not failing.depends_on:
            return None
        s = self.state
        # Walk depends_on in plan order; pick the last one that's
        # already completed.
        plan_index = {st.name: i for i, st in enumerate(s.plan)}
        candidates = sorted(
            [n for n in failing.depends_on if n in s.completed],
            key=lambda n: plan_index.get(n, 0),
            reverse=True,
        )
        for name in candidates:
            for st in s.plan:
                if st.name == name: return st
        return None

    def _invalidate_downstream(self, root: str) -> set[str]:
        """Remove `root` and every step that transitively depended on
        it from `completed`. Returns the set of names invalidated."""
        s = self.state
        inv: set[str] = set()
        # Build a quick reverse-deps map.
        children: dict[str, list[str]] = {}
        for st in s.plan:
            for d in st.depends_on:
                children.setdefault(d, []).append(st.name)
        # BFS from root.
        frontier = [root]
        while frontier:
            n = frontier.pop()
            if n in inv: continue
            inv.add(n)
            s.completed.pop(n, None)
            frontier.extend(children.get(n, []))
        # We don't drop `root` from `completed` until just before the
        # caller re-runs it; that ordering is handled above.
        return inv

    def _suggestion_for(self, step: Step) -> str:
        if not step.depends_on:
            return (
                f"the failure is on the first step — re-read the user's "
                f"request, sanity-check `{step.name}`'s preconditions, and "
                f"start over."
            )
        return (
            f"`{step.name}` depends on {list(step.depends_on)}. "
            f"Run those steps manually, observe their output, and re-run "
            f"the task with that context surfaced explicitly."
        )
