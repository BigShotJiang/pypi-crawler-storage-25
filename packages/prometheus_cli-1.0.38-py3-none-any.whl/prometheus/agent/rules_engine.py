"""Round 109: Path-scoped rules engine.

A Rule is a markdown file under `.prometheus/rules/` (project,
Trust-gated) or `~/.prometheus/rules/` (user). Each rule
declares one or more glob patterns in its `paths:` frontmatter
and a markdown body that gets injected into the agent's context
ONLY when the agent is currently working with files matching
those globs.

Rules are the answer to "I want X behavior in /api/auth, but not
elsewhere" without bloating the always-on Charter or the trigger-
keyword Aptitude pool.

Example rule file (`.prometheus/rules/api-auth.md`):

    ---
    name: api-auth-conventions
    description: Auth-route conventions for /api/auth/*
    paths:
      - "app/api/auth/**/*.py"
      - "app/api/auth/**/*.ts"
    ---
    All auth routes return:
      {"success": bool, "data": Any, "error": str | None}
    Use `await session.execute(stmt)` not `session.query(...)`.
    The legacy `auth_*_v1` decorators are deprecated — replace
    with `require_auth` from `app/api/auth/deps.py`.

Loading model:

  * The rule's frontmatter loads at startup so the catalogue is
    cheap (~30 tokens per rule).
  * The body loads only when the agent's currently-touched-files
    set has at least one match against the rule's glob list.
  * Each load fires the `InstructionsLoaded` sentinel event so
    project hooks can react.

Discovery paths:

  1. `<workdir>/.prometheus/rules/<name>.md` (Trust-gated)
  2. `~/.prometheus/rules/<name>.md`
"""
from __future__ import annotations

import fnmatch
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


MAX_BODY_BYTES = 6_000


def _glob_to_regex(pattern: str) -> str:
    """Translate a glob with `**` recursive segments + `*` /
    `?` / `[abc]` character classes into a regex that matches
    forward-slash paths.

    `**`     → `.*`
    `*`      → `[^/]*`
    `?`      → `[^/]`
    `[abc]`  → preserved as-is
    """
    out: list[str] = []
    i = 0
    n = len(pattern)
    while i < n:
        c = pattern[i]
        if c == "*":
            if i + 1 < n and pattern[i + 1] == "*":
                # `**` — match anything including separators.
                out.append(".*")
                i += 2
                # Skip an optional trailing `/`.
                if i < n and pattern[i] == "/":
                    i += 1
            else:
                out.append("[^/]*")
                i += 1
        elif c == "?":
            out.append("[^/]")
            i += 1
        elif c == "[":
            j = pattern.find("]", i + 1)
            if j == -1:
                out.append(re.escape(c))
                i += 1
            else:
                out.append(pattern[i:j + 1])
                i = j + 1
        else:
            out.append(re.escape(c))
            i += 1
    return "^" + "".join(out) + "$"


def _glob_match(pattern: str, path: str) -> bool:
    """Return True iff `path` matches `pattern` (with `**`
    support). Cached compile per-call is fine — globs are
    short enough that re-compile cost is negligible against
    the agent loop."""
    rx = _glob_to_regex(pattern)
    try:
        return re.match(rx, path) is not None
    except re.error:
        return fnmatch.fnmatch(path, pattern)


@dataclass
class Rule:
    """One discovered Rule. The `paths` field carries the glob
    patterns; `matches_any` checks a path against them."""
    name: str
    description: str
    paths: tuple[str, ...]
    body: str
    path: Path
    source: str = "user"     # `project` | `user`

    def matches_any(self, file_path: str) -> bool:
        """Return True if `file_path` (relative or absolute) hits
        ANY of this rule's glob patterns. Normalizes Windows
        backslashes to forward slashes so cross-platform globs
        work consistently. Supports `**` recursive segments."""
        if not self.paths:
            return False
        target = file_path.replace("\\", "/")
        for glob in self.paths:
            g = glob.replace("\\", "/")
            if _glob_match(g, target):
                return True
            # Also try matching the basename if the glob is a
            # simple filename pattern.
            base = target.rsplit("/", 1)[-1]
            if _glob_match(g, base):
                return True
        return False

    def matches_set(self, paths: set[str]) -> bool:
        return any(self.matches_any(p) for p in paths)

    def short_description(self, n: int = 80) -> str:
        first = self.description.strip().splitlines()[0] if self.description else ""
        return first[:n] + ("…" if len(first) > n else "")


def _split_strings(raw: str) -> tuple[str, ...]:
    s = raw.strip()
    if s.startswith("[") and s.endswith("]"):
        s = s[1:-1]
    return tuple(
        part.strip().strip('"').strip("'")
        for part in s.split(",") if part.strip()
    )


def _load_rule_file(path: Path, *, source: str) -> Optional[Rule]:
    try:
        raw = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    from prometheus.agent.aptitudes import _parse_frontmatter
    fm, body = _parse_frontmatter(raw)
    name = fm.get("name") or path.stem
    description = (fm.get("description") or "").strip()[:200]
    paths_raw = fm.get("paths") or fm.get("path") or ""
    paths = _split_strings(paths_raw)
    return Rule(
        name=name[:64],
        description=description,
        paths=paths,
        body=body.strip()[:MAX_BODY_BYTES],
        path=path,
        source=source,
    )


def discover_rules(workdir: Path) -> list[Rule]:
    """Walk project + user scopes for `*.md` rule files."""
    try:
        from prometheus.safety.trust import is_trusted
    except Exception:
        is_trusted = lambda _: False  # type: ignore
    out: list[Rule] = []
    seen: set[str] = set()
    paths: list[tuple[Path, str]] = []
    if is_trusted(workdir):
        proj = workdir / ".prometheus" / "rules"
        if proj.exists() and proj.is_dir():
            for p in sorted(proj.glob("*.md")):
                paths.append((p, "project"))
    user = Path.home() / ".prometheus" / "rules"
    if user.exists() and user.is_dir():
        for p in sorted(user.glob("*.md")):
            paths.append((p, "user"))
    for p, source in paths:
        r = _load_rule_file(p, source=source)
        if r is None or r.name in seen:
            continue
        seen.add(r.name)
        out.append(r)
    return out


def select_matching(
    rules: list[Rule], touched_files: set[str],
) -> list[Rule]:
    """Return the subset of rules whose globs match at least one
    file in `touched_files`. Matches are by-glob, not by
    filesystem state — the file doesn't need to exist."""
    return [r for r in rules if r.matches_set(touched_files)]


def render_active_rules_block(rules: list[Rule]) -> str:
    """Format active rules for system-prompt injection."""
    if not rules:
        return ""
    parts: list[str] = ["", "ACTIVE RULES (path-scoped):"]
    for r in rules:
        parts.append(f"\n## {r.name}")
        if r.description:
            parts.append(r.description)
        parts.append("")
        parts.append(r.body)
    return "\n".join(parts)


def get_rule(workdir: Path, name: str) -> Optional[Rule]:
    for r in discover_rules(workdir):
        if r.name == name:
            return r
    return None


def validate(rule: Rule) -> list[str]:
    """Return a list of validation problems; empty list = OK."""
    issues: list[str] = []
    if not rule.name:
        issues.append("missing name")
    if not rule.paths:
        issues.append("no `paths:` glob declared (rule will never load)")
    for g in rule.paths:
        # Empty glob would fnmatch.fnmatch every path with "" — flag it.
        if not g.strip():
            issues.append("empty glob in `paths:` list")
    if not rule.body.strip():
        issues.append("empty body — rule loads but tells the agent nothing")
    if len(rule.body) >= MAX_BODY_BYTES:
        issues.append(f"body capped at {MAX_BODY_BYTES} bytes")
    return issues
