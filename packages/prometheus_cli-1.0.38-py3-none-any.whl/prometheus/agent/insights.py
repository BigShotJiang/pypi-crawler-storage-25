"""Round 127: /insights — session analysis report.

Aggregates a session (or many sessions) into an actionable
markdown report:

  * Project areas touched (file paths grouped by directory)
  * Tool usage frequency
  * Friction points (errors, retries, denials)
  * Interaction patterns (avg messages-per-turn, time-on-task)

The report is written to disk under
`~/.prometheus/insights/<session-id>.md` so users can review
later or commit per-project highlights.
"""
from __future__ import annotations

import json
import time
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Optional


@dataclass
class SessionInsights:
    session_id: str
    n_messages: int
    n_user_turns: int
    n_assistant_turns: int
    tool_usage: Counter = field(default_factory=Counter)
    files_touched: set[str] = field(default_factory=set)
    error_count: int = 0
    denial_count: int = 0
    duration_s: float = 0.0
    summary_line: str = ""


def analyze_messages(
    messages: list[dict[str, Any]], *,
    session_id: str = "session",
    started_at: float = 0.0,
) -> SessionInsights:
    """Round 127: walk the message list and produce insights."""
    insights = SessionInsights(
        session_id=session_id, n_messages=len(messages or []),
        n_user_turns=0, n_assistant_turns=0,
    )
    last_assistant_text = ""
    for m in messages or []:
        role = (m.get("role") or "").lower()
        if role == "user":
            insights.n_user_turns += 1
        elif role == "assistant":
            insights.n_assistant_turns += 1
            content = m.get("content", "")
            if isinstance(content, str) and content.strip():
                last_assistant_text = content.strip()
            for tc in (m.get("tool_calls") or []):
                fn = tc.get("function") or {}
                name = fn.get("name", "")
                if name:
                    insights.tool_usage[name] += 1
                # Pull file paths from arg blobs.
                try:
                    args = json.loads(fn.get("arguments", "") or "{}")
                except (ValueError, TypeError):
                    args = {}
                for key in ("path", "file"):
                    v = args.get(key)
                    if isinstance(v, str):
                        insights.files_touched.add(v)
        elif role == "tool":
            content = str(m.get("content", "") or "")
            low = content.lower()
            if "error" in low and "no error" not in low:
                insights.error_count += 1
            if "denied" in low or "blocked" in low:
                insights.denial_count += 1
    if started_at:
        insights.duration_s = max(0.0, time.time() - started_at)
    insights.summary_line = last_assistant_text.splitlines()[0][:100] if last_assistant_text else ""
    return insights


def render_insights_report(insights: SessionInsights) -> str:
    """Round 127: markdown report for /insights."""
    lines: list[str] = []
    iso = datetime.utcnow().isoformat() + "Z"
    lines.append(f"# Session insights — {insights.session_id}")
    lines.append(f"_generated {iso}_")
    lines.append("")
    lines.append("## Overview")
    lines.append(f"- Messages: {insights.n_messages}")
    lines.append(f"- User turns: {insights.n_user_turns}")
    lines.append(f"- Assistant turns: {insights.n_assistant_turns}")
    if insights.duration_s > 0:
        m = int(insights.duration_s // 60)
        s = int(insights.duration_s % 60)
        lines.append(f"- Duration: {m}m {s}s")
    if insights.summary_line:
        lines.append(f"- Last assistant outcome: _{insights.summary_line}_")
    lines.append("")
    if insights.tool_usage:
        lines.append("## Tool usage")
        for name, n in insights.tool_usage.most_common():
            lines.append(f"- {name}: {n}")
        lines.append("")
    if insights.files_touched:
        lines.append("## Files touched")
        # Group by parent dir for readability.
        by_dir: dict[str, list[str]] = {}
        for path in sorted(insights.files_touched):
            parent = "/".join(path.split("/")[:-1]) or "."
            by_dir.setdefault(parent, []).append(path)
        for parent, files in sorted(by_dir.items()):
            lines.append(f"- `{parent}/` ({len(files)} file(s))")
            for f in files[:6]:
                lines.append(f"  - `{f}`")
            if len(files) > 6:
                lines.append(f"  - …{len(files) - 6} more")
        lines.append("")
    if insights.error_count or insights.denial_count:
        lines.append("## Friction points")
        if insights.error_count:
            lines.append(f"- {insights.error_count} tool error(s)")
        if insights.denial_count:
            lines.append(f"- {insights.denial_count} permission denial(s)")
        lines.append("")
    if not (insights.tool_usage or insights.files_touched
            or insights.error_count or insights.denial_count):
        lines.append("_(empty session — nothing to analyze yet.)_")
    return "\n".join(lines).rstrip() + "\n"


def write_insights_report(
    insights: SessionInsights,
) -> Path:
    """Write the report under `~/.prometheus/insights/`."""
    d = Path.home() / ".prometheus" / "insights"
    d.mkdir(parents=True, exist_ok=True)
    p = d / f"{insights.session_id}.md"
    p.write_text(render_insights_report(insights), encoding="utf-8")
    return p
