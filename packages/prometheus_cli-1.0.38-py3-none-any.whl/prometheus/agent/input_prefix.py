"""Round 124: Input prefix engine — bash mode (`!`) + file
mention (`@`).

These two prefixes turn the input box into a swiss-army UX:

  * `! <command>` — execute the command directly in the shell
                    without an LLM round-trip. Output flows into
                    the conversation as a dim system block. The
                    next agent turn sees the output as context.
  * `@<path>`     — glob-expand the path and inject the file(s)
                    contents into the next prompt. Supports
                    `@*.py`, `@src/**/*.ts`, etc.

Both prefixes are detected here (pure data layer) so the input
handler can route raw text without recompiling regex on every
keystroke. The slash command `/bash-mode` lets users disable the
prefix detection if it gets in the way.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


# ---------- detection ----------


def is_bash_prefix(text: str) -> bool:
    """True iff `text` (after lstrip) starts with `!` followed by
    a non-equals char (so `!=` in the middle of a sentence
    doesn't trip)."""
    s = (text or "").lstrip()
    if not s.startswith("!"):
        return False
    if len(s) < 2:
        return False
    # Bash prefix is `!<space-or-letter>...`. `!!` and `!=` are
    # not bash mode.
    next_ch = s[1]
    if next_ch in ("!", "="):
        return False
    return True


def strip_bash_prefix(text: str) -> str:
    """Return everything after the leading `!`."""
    s = (text or "").lstrip()
    if not s.startswith("!"):
        return s
    return s[1:].lstrip()


def has_file_mention(text: str) -> bool:
    """True iff `text` contains a `@<path>` token. The text-prefix
    matcher runs before submit; UI autocomplete uses a stricter
    cursor-position-aware probe."""
    if not text:
        return False
    # Word boundary or start of line, then `@`, then path-friendly
    # characters.
    import re
    return bool(re.search(r"(^|\s)@[A-Za-z0-9_./*?\[\]\-]+", text))


# ---------- file mention expansion ----------


@dataclass
class FileMention:
    """One discovered `@<token>` mention."""
    token: str          # raw token after @, e.g. `src/auth.py` or `*.py`
    matches: list[Path]


def extract_file_mentions(
    text: str, *, workdir: Path,
) -> list[FileMention]:
    """Round 124: pull every `@<path>` token and resolve via glob."""
    if not text:
        return []
    import re
    out: list[FileMention] = []
    for m in re.finditer(
        r"(?:^|\s)@([A-Za-z0-9_./*?\[\]\-]+)",
        text,
    ):
        token = m.group(1)
        matches = expand_glob(token, workdir=workdir)
        out.append(FileMention(token=token, matches=matches))
    return out


def expand_glob(token: str, *, workdir: Path) -> list[Path]:
    """Round 124: expand a glob token relative to `workdir`.

    Supports `*`, `?`, `**` recursion. Path-traversal (`..`) is
    refused — callers must stay inside the workdir."""
    if not token:
        return []
    # Reject path traversal so an attacker-authored token can't
    # @-include `/etc/passwd`.
    parts = token.replace("\\", "/").split("/")
    if any(p == ".." for p in parts):
        return []
    target = workdir.resolve()
    candidates: list[Path] = []
    # If the token has a glob char, walk the workdir.
    if any(c in token for c in ("*", "?", "[")):
        try:
            for p in target.glob(token):
                if p.is_file():
                    candidates.append(p)
        except (OSError, ValueError):
            pass
    else:
        # Plain path — resolve and accept if it's a file inside
        # the workdir.
        candidate = (target / token).resolve()
        try:
            candidate.relative_to(target)
        except ValueError:
            return []
        if candidate.exists() and candidate.is_file():
            candidates.append(candidate)
    # Cap at 20 files so a `@**/*` doesn't melt the prompt.
    return candidates[:20]


def render_file_mention_block(
    mentions: list[FileMention], *, workdir: Path,
    max_bytes_per_file: int = 8_000,
    max_total_bytes: int = 32_000,
) -> str:
    """Format expanded mentions for prompt injection. Each file
    appears as a fenced code block with its relative path as the
    label."""
    if not mentions:
        return ""
    parts: list[str] = ["", "FILE MENTIONS:"]
    used = 0
    for mention in mentions:
        if not mention.matches:
            parts.append(
                f"\n_(no match for `@{mention.token}`)_"
            )
            continue
        for p in mention.matches:
            try:
                rel = p.relative_to(workdir).as_posix()
            except ValueError:
                rel = str(p)
            try:
                body = p.read_text(
                    encoding="utf-8", errors="replace"
                )[:max_bytes_per_file]
            except OSError:
                continue
            chunk = f"\n### {rel}\n```\n{body}\n```\n"
            if used + len(chunk) > max_total_bytes:
                parts.append("\n_(file mention limit reached)_")
                return "\n".join(parts)
            parts.append(chunk)
            used += len(chunk)
    return "\n".join(parts)


# ---------- mode toggle ----------


def bash_mode_enabled() -> bool:
    """Round 124: bash mode is on by default. `/bash-mode off`
    flips PROMETHEUS_BASH_MODE=0; `/bash-mode on` flips it back.
    The env var is the persistent surface so a fresh launch
    inherits the user's preference."""
    return os.environ.get(
        "PROMETHEUS_BASH_MODE", "1",
    ).strip().lower() in ("1", "true", "yes", "on")


def set_bash_mode(enabled: bool) -> None:
    os.environ["PROMETHEUS_BASH_MODE"] = "1" if enabled else "0"
