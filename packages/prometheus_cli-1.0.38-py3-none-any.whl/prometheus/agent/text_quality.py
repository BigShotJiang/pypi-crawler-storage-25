"""Round 215: shared text-quality helpers for assistant output.

Used by:
  * `prometheus/ui/app.py` to suppress degenerate text from the
    activity-summary title (R214 fix).
  * `prometheus/agent/loop.py` to detect degenerate streams and
    auto-retry on a different free model (R215 fix).

The detector is intentionally conservative: only fires when one
noun-candidate token (>2 chars) makes up >=35% of all tokens AND
appears 3+ times. Real outputs ("Tests passed: 139 in 2.68s",
URLs, timestamps, normal English prose) stay clean.

Surfaced by live capture: minimax-m2.5:free emitted
"San Diego time is San Diego: San Diego:" as final answer text
when asked "what time is it in San Diego CA now?" — classic
free-tier degenerate generation loop.
"""
from __future__ import annotations

import re


_TOKEN_RX = re.compile(r"[A-Za-z][A-Za-z0-9_]*")


def is_degenerate_repetition(text: str) -> bool:
    """Return True iff `text` looks like a degenerate model loop.

    Heuristic:
      1. Tokenize on word boundaries.
      2. Lowercase, drop tokens of length <= 2 (articles, pronouns).
      3. Count remaining tokens. If the most-common one appears
         >= 3 times AND is >= 35% of all original tokens → degenerate.

    Skip lines under 4 tokens (not enough signal).

    Examples that trigger:
      "San Diego time is San Diego: San Diego:"  (san=3, diego=3
        of 8 tokens = 75%)
      "docker docker docker docker"
      "foo foo foo bar baz"

    Examples that do NOT trigger:
      "Tests passed: 139 in 2.68s"
      "Visit https://www.google.com/chrome/ to download..."
      "Saturday, May 9, 2026 11:06:26 AM"
      Normal English prose.
    """
    if not text:
        return False
    tokens = [t.lower() for t in _TOKEN_RX.findall(text)]
    if len(tokens) < 4:
        return False
    counts: dict[str, int] = {}
    for t in tokens:
        if len(t) <= 2:  # skip a / an / is / of / to / etc.
            continue
        counts[t] = counts.get(t, 0) + 1
    if not counts:
        return False
    top_count = max(counts.values())
    if top_count < 3:  # need at least 3 repeats to call it a loop
        return False
    return top_count / len(tokens) >= 0.35
