"""Round 145-final-v3: prompt-cache break detection.

Tracks `cache_read_input_tokens` across responses. When it
falls to zero after a sequence of cached turns, we log a
`cache_break` event to the audit trail and signal the agent
loop to retry with adjusted parameters.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class CacheBreakEvent:
    timestamp: int
    turn_index: int
    prior_cached_tokens: int
    current_cached_tokens: int
    reason: str = ""


@dataclass
class CacheTracker:
    """Round 145-final-v3: tracks cache hits across turns and
    surfaces break events."""
    cached_tokens_history: list[int] = field(default_factory=list)
    breaks: list[CacheBreakEvent] = field(default_factory=list)
    consecutive_misses: int = 0

    def record(
        self,
        *,
        cached_tokens: int,
        turn_index: int = 0,
    ) -> Optional[CacheBreakEvent]:
        """Round 145-final-v3: record a turn's cached-token
        count. Returns a `CacheBreakEvent` when a break is
        detected, or None when not."""
        cached_tokens = max(0, int(cached_tokens))
        prior = (
            self.cached_tokens_history[-1]
            if self.cached_tokens_history else 0
        )
        self.cached_tokens_history.append(cached_tokens)
        # Break: prior was non-zero AND current is zero.
        if prior > 0 and cached_tokens == 0:
            ev = CacheBreakEvent(
                timestamp=int(time.time()),
                turn_index=turn_index or len(self.cached_tokens_history),
                prior_cached_tokens=prior,
                current_cached_tokens=0,
                reason="cache_read_input_tokens dropped to 0",
            )
            self.breaks.append(ev)
            self.consecutive_misses = 1
            return ev
        if cached_tokens == 0:
            self.consecutive_misses += 1
        else:
            self.consecutive_misses = 0
        return None

    def reset(self) -> None:
        self.cached_tokens_history.clear()
        self.breaks.clear()
        self.consecutive_misses = 0


def render_break_event(ev: CacheBreakEvent) -> str:
    return (
        f"cache break at turn #{ev.turn_index}: "
        f"prior={ev.prior_cached_tokens:,} → current=0 "
        f"({ev.reason})"
    )


def should_retry(tracker: CacheTracker) -> bool:
    """Round 145-final-v3: a single cache break warrants one
    retry with adjusted parameters. After two consecutive
    breaks we stop retrying — there's a deeper issue."""
    return len(tracker.breaks) == 1 and tracker.consecutive_misses == 1
