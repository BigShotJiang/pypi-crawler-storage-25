"""Round 117: cohort isolation via git worktree.

When a Cohort declares `isolation: worktree`, the manager
creates a git worktree for that cohort's run. All file
operations happen inside the worktree's path. On completion,
the worktree is removed (or kept if the cohort wrote useful
results — the host decides).

Lifecycle events fired:

  * `WorktreeCreate` — before the worktree is created. Can block.
  * `WorktreeRemove` — after the worktree is removed. Non-blocking.

Both events are already in the `SentinelEvent` enum (round 99).

This module is a thin subprocess wrapper around `git worktree`.
On systems without git, `is_git_repo` returns False and the
caller should fall back to running the cohort in the parent's
workdir (with a clear log message — never silently downgrade).
"""
from __future__ import annotations

import asyncio
import os
import shutil
import subprocess
import sys
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


# ---------- repo detection ----------


def is_git_repo(workdir: Path) -> bool:
    """True iff `workdir` (or an ancestor) is a git working
    tree."""
    try:
        proc = subprocess.run(
            ["git", "-C", str(workdir), "rev-parse", "--is-inside-work-tree"],
            capture_output=True, text=True, timeout=5,
            **_spawn_kwargs(),
        )
        return proc.returncode == 0 and proc.stdout.strip() == "true"
    except (OSError, subprocess.TimeoutExpired):
        return False


def _spawn_kwargs() -> dict:
    """OS-aware subprocess kwargs."""
    kw: dict = {}
    if sys.platform == "win32":
        try:
            import subprocess as _sp
            kw["creationflags"] = getattr(_sp, "CREATE_NO_WINDOW", 0)
        except Exception:
            pass
    return kw


# ---------- worktree lifecycle ----------


@dataclass
class Worktree:
    path: Path
    branch: str
    parent_workdir: Path

    @property
    def safe_name(self) -> str:
        return self.path.name


def _worktrees_root(parent: Path) -> Path:
    """Round 117: keep cohort worktrees under
    `<workdir>/.prometheus/worktrees/` so they're trivially
    findable + cleanable."""
    return parent / ".prometheus" / "worktrees"


def create_worktree(
    parent_workdir: Path,
    *,
    name_hint: str = "cohort",
    base_ref: str = "HEAD",
) -> tuple[Optional[Worktree], str]:
    """Create a git worktree off `base_ref` for a cohort.

    Returns `(worktree, message)`. On failure, worktree is None
    and message describes the problem."""
    if not is_git_repo(parent_workdir):
        return None, "not a git repository — worktree isolation unavailable"
    safe = "".join(
        c if c.isalnum() or c in "-_" else "-" for c in name_hint.strip()
    )[:32] or "cohort"
    short_id = uuid.uuid4().hex[:6]
    target_root = _worktrees_root(parent_workdir)
    target_root.mkdir(parents=True, exist_ok=True)
    target = target_root / f"{safe}-{short_id}"
    branch = f"prometheus/cohort/{safe}-{short_id}"
    # `git worktree add -b <branch> <path> <ref>` creates a new
    # branch off `ref` and checks it out at `path`.
    try:
        proc = subprocess.run(
            [
                "git", "-C", str(parent_workdir),
                "worktree", "add",
                "-b", branch,
                str(target),
                base_ref,
            ],
            capture_output=True, text=True, timeout=30,
            **_spawn_kwargs(),
        )
    except (OSError, subprocess.TimeoutExpired) as e:
        return None, f"git worktree add failed: {e}"
    if proc.returncode != 0:
        return None, (
            f"git worktree add failed (rc={proc.returncode}): "
            f"{proc.stderr.strip()[:120]}"
        )
    return Worktree(
        path=target, branch=branch, parent_workdir=parent_workdir,
    ), f"created worktree {target}"


def remove_worktree(
    worktree: Worktree,
    *,
    force: bool = False,
) -> tuple[bool, str]:
    """Remove the worktree directory + branch."""
    if not worktree.path.exists():
        return False, "worktree path does not exist"
    args = [
        "git", "-C", str(worktree.parent_workdir),
        "worktree", "remove",
    ]
    if force:
        args.append("--force")
    args.append(str(worktree.path))
    try:
        proc = subprocess.run(
            args, capture_output=True, text=True, timeout=20,
            **_spawn_kwargs(),
        )
    except (OSError, subprocess.TimeoutExpired) as e:
        return False, f"git worktree remove failed: {e}"
    if proc.returncode != 0 and not force:
        # Retry with force.
        return remove_worktree(worktree, force=True)
    if proc.returncode != 0:
        # Fall back to filesystem-level removal.
        try:
            shutil.rmtree(worktree.path, ignore_errors=True)
        except Exception:
            pass
    # Best-effort branch cleanup. Non-fatal if it fails.
    try:
        subprocess.run(
            [
                "git", "-C", str(worktree.parent_workdir),
                "branch", "-D", worktree.branch,
            ],
            capture_output=True, timeout=10, **_spawn_kwargs(),
        )
    except Exception:
        pass
    return True, f"removed worktree {worktree.path}"


# ---------- async helpers (fire sentinels around create/remove) ----------


async def create_worktree_with_sentinels(
    parent_workdir: Path,
    *,
    name_hint: str,
    sentinel_registry,
    session_id: str = "",
    permission_mode: str = "",
) -> tuple[Optional[Worktree], str]:
    """Round 117: create worktree, fire WorktreeCreate sentinels.

    A blocking deny aborts the create."""
    from prometheus.safety.sentinels import (
        SentinelDecision, SentinelEvent, fire_event,
    )
    final, _results = await fire_event(
        sentinel_registry,
        SentinelEvent.WORKTREE_CREATE,
        match_value=name_hint,
        session_id=session_id,
        cwd=str(parent_workdir),
        permission_mode=permission_mode,
        payload_extra={"name_hint": name_hint},
    )
    if final == SentinelDecision.DENY:
        return None, "worktree creation denied by sentinel"
    return create_worktree(parent_workdir, name_hint=name_hint)


async def remove_worktree_with_sentinels(
    worktree: Worktree,
    *,
    sentinel_registry,
    session_id: str = "",
    permission_mode: str = "",
) -> tuple[bool, str]:
    """Round 117: remove worktree, fire WorktreeRemove sentinel.
    The remove event is non-blocking by design — we always reap
    the worktree, the sentinel just gets to log/audit."""
    ok, msg = remove_worktree(worktree)
    try:
        from prometheus.safety.sentinels import (
            SentinelEvent, fire_event,
        )
        await fire_event(
            sentinel_registry,
            SentinelEvent.WORKTREE_REMOVE,
            match_value=worktree.safe_name,
            session_id=session_id,
            cwd=str(worktree.parent_workdir),
            permission_mode=permission_mode,
            payload_extra={
                "worktree_path": str(worktree.path),
                "branch": worktree.branch,
                "removed_ok": ok,
            },
        )
    except Exception:
        pass
    return ok, msg
