"""Round 107: typo suggestions for slash commands and CLI flags.

When the user types something close to a known command, surface
a "Did you mean ...?" hint. Uses Python's stdlib `difflib` so we
don't pull a heavy fuzzy-matching dep.
"""
from __future__ import annotations

import difflib
from typing import Iterable, Optional


def suggest_one(
    typed: str,
    candidates: Iterable[str],
    *,
    cutoff: float = 0.6,
) -> Optional[str]:
    """Return the closest match if confidence ≥ cutoff. None
    when no candidate is close enough."""
    if not typed:
        return None
    cands = list(candidates)
    if not cands:
        return None
    matches = difflib.get_close_matches(
        typed, cands, n=1, cutoff=cutoff,
    )
    return matches[0] if matches else None


def suggest_many(
    typed: str,
    candidates: Iterable[str],
    *,
    n: int = 3,
    cutoff: float = 0.5,
) -> list[str]:
    """Up to `n` close matches, ordered by similarity."""
    if not typed:
        return []
    return difflib.get_close_matches(
        typed, list(candidates), n=n, cutoff=cutoff,
    )


def format_did_you_mean(
    typed: str,
    candidates: Iterable[str],
    *,
    prefix: str = "",
) -> str:
    """Build the user-facing `Did you mean 'X'?` string. Empty
    when no match meets the threshold."""
    pick = suggest_one(typed, candidates)
    if pick is None:
        return ""
    if prefix:
        return f"Did you mean '{prefix}{pick}'?"
    return f"Did you mean '{pick}'?"
