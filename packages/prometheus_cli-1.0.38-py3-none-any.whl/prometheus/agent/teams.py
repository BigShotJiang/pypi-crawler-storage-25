"""Round 107: Agent Teams — multi-instance coordination.

The Phase-4 spec called for Agent Teams; round 101 shipped the
shared Work Log surface they coordinate over. This round adds
the explicit Teammate registry + tools.

Activation: `prometheus --agent-teams` or
`PROMETHEUS_AGENT_TEAMS=1`. Without activation, the team tools
register but refuse to spawn (the model still sees them in the
catalogue but each call returns a clear "team mode disabled"
error).

Teammate model:

    name              str   — short id (e.g. `frontend-spec`)
    role              str   — human-readable role description
    process_id        int|None — pid when spawned (round-107
                       scope: bookkeeping only; subprocess spawn
                       is round-108 polish)
    color             str   — visual identifier in dashboards
    status            str   — idle | working | done | failed
    inbox             list  — unread messages, structured records
    last_active       float — epoch seconds

Persisted to `<workdir>/.prometheus/team.json` so teammates can
reload after restarts. Communication via the shared Work Log
(round 101) plus a dedicated mailbox per teammate.
"""
from __future__ import annotations

import json
import os
import time
import uuid
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional


def is_team_mode_enabled() -> bool:
    """Round 107: env-flag activation. The CLI flag
    `--agent-teams` should set the env var early in startup."""
    return os.environ.get("PROMETHEUS_AGENT_TEAMS", "").strip() in (
        "1", "true", "yes", "on",
    )


VALID_STATUSES = ("idle", "working", "done", "failed")


@dataclass
class TeamMessage:
    sender: str
    recipient: str        # teammate name OR "*" for broadcast
    body: str
    ts: float
    seen: bool = False
    # Round 112: threaded messages. `id` uniquely identifies this
    # message; `reply_to` points at the message it replies to (or
    # empty for top-level). Threads form via `reply_to` chains.
    id: str = ""
    reply_to: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Teammate:
    name: str
    role: str
    color: str = "default"
    process_id: Optional[int] = None
    status: str = "idle"
    inbox: list[TeamMessage] = field(default_factory=list)
    created_at: float = 0.0
    last_active: float = 0.0
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["inbox"] = [m.to_dict() for m in self.inbox]
        return d

    @classmethod
    def from_dict(cls, raw: dict) -> "Teammate":
        return cls(
            name=str(raw.get("name", "")),
            role=str(raw.get("role", "")),
            color=str(raw.get("color", "default")),
            process_id=raw.get("process_id"),
            status=str(raw.get("status", "idle")),
            inbox=[
                TeamMessage(**m) if isinstance(m, dict) else m
                for m in (raw.get("inbox") or [])
            ],
            created_at=float(raw.get("created_at", 0.0)),
            last_active=float(raw.get("last_active", 0.0)),
            metadata=dict(raw.get("metadata") or {}),
        )


@dataclass
class TeamRegistry:
    """Round 107: persistent team state for the workdir."""
    workdir: Path
    teammates: dict[str, Teammate] = field(default_factory=dict)

    @property
    def path(self) -> Path:
        return self.workdir / ".prometheus" / "team.json"

    @classmethod
    def load(cls, workdir: Path) -> "TeamRegistry":
        reg = cls(workdir=workdir)
        if not reg.path.exists() or not reg.path.is_file():
            return reg
        try:
            data = json.loads(
                reg.path.read_text(encoding="utf-8", errors="replace")
            )
        except (OSError, ValueError):
            return reg
        for raw in (data.get("teammates") or []):
            if isinstance(raw, dict):
                t = Teammate.from_dict(raw)
                if t.name:
                    reg.teammates[t.name] = t
        return reg

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            self.path.write_text(
                json.dumps(
                    {
                        "teammates": [
                            t.to_dict() for t in self.teammates.values()
                        ],
                    },
                    indent=2, default=str,
                ),
                encoding="utf-8",
            )
        except OSError:
            pass

    # ---------- public API ----------

    def create(
        self, *,
        name: str,
        role: str,
        color: str = "default",
        metadata: Optional[dict] = None,
    ) -> tuple[Optional[Teammate], str]:
        if not name.strip():
            return None, "teammate name required"
        if name in self.teammates:
            return None, f"teammate {name!r} already exists"
        t = Teammate(
            name=name.strip(),
            role=role.strip(),
            color=color,
            created_at=time.time(),
            last_active=time.time(),
            metadata=dict(metadata or {}),
        )
        self.teammates[t.name] = t
        self.save()
        return t, f"teammate {name!r} created"

    def delete(self, name: str) -> tuple[bool, str]:
        if name not in self.teammates:
            return False, f"no teammate named {name!r}"
        self.teammates.pop(name, None)
        self.save()
        return True, f"teammate {name!r} removed"

    def get(self, name: str) -> Optional[Teammate]:
        return self.teammates.get(name)

    def list(self) -> list[Teammate]:
        return list(self.teammates.values())

    def send(
        self, *,
        sender: str,
        recipient: str,
        body: str,
        reply_to: str = "",
    ) -> tuple[bool, str]:
        if not body.strip():
            return False, "message body required"
        msg = TeamMessage(
            sender=sender, recipient=recipient,
            body=body.strip(), ts=time.time(), seen=False,
            id=uuid.uuid4().hex[:10],
            reply_to=reply_to,
        )
        if recipient == "*":
            for t in self.teammates.values():
                if t.name != sender:
                    t.inbox.append(msg)
            self.save()
            return True, (
                f"broadcast → {len(self.teammates) - (1 if sender in self.teammates else 0)} teammate(s)"
            )
        target = self.teammates.get(recipient)
        if target is None:
            return False, f"no teammate named {recipient!r}"
        target.inbox.append(msg)
        self.save()
        return True, f"message → {recipient}"

    def set_status(self, name: str, status: str) -> bool:
        if status not in VALID_STATUSES:
            return False
        t = self.teammates.get(name)
        if t is None:
            return False
        t.status = status
        t.last_active = time.time()
        self.save()
        return True
