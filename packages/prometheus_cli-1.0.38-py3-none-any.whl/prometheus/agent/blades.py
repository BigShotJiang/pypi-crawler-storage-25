"""Round 103 (Phase 6): Command Blades — custom slash commands.

A Blade is a reusable prompt template stored as a Markdown file.
It becomes invocable as `/blade-name` once loaded.

Three blade types per the Phase-6 spec:

  * `prompt`  — sends the body to the model with optional tool
                allowlist. The most common type (~90%).
  * `local`   — runs in-process, returns plain text. For commands
                that don't need the model (e.g., `/cost`, `/version`).
  * `jsx`     — runs in-process, returns rendered terminal UI
                components. For commands that build their own
                output (e.g., `/doctor`, `/dashboard`).

For round 103, this module loads `prompt`-type blades. `local`
and `jsx` blades have a stable definition surface; their
in-process execution adapter lands in a future polish round.

Discovery paths:

  * `<workdir>/.prometheus/blades/<name>.md`  (project, Trust-gated)
  * `~/.prometheus/blades/<name>.md`          (user)
  * `<aptitude>/blades/<name>.md`             (component-scoped)
  * Forge kit's `blades` field                 (round 100)

Frontmatter:

    ---
    name: review
    description: Perform a thorough code review of changes.
    type: prompt
    allowed-tools: [Read, Grep, Glob, Bash]
    ---
    Review the current changes:
    1. Check for bugs and edge cases
    2. Verify test coverage
    3. Review error handling
    4. Suggest improvements
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


VALID_TYPES = ("prompt", "local", "jsx")


@dataclass
class Blade:
    name: str
    description: str
    body: str                       # the prompt template
    path: Path
    type: str = "prompt"
    allowed_tools: tuple[str, ...] = ()
    source: str = "user"            # `project` | `user` | `aptitude:<name>` | `forge:<kit>`

    def short_description(self, n: int = 80) -> str:
        first = self.description.strip().splitlines()[0] if self.description else ""
        return first[:n] + ("…" if len(first) > n else "")


def _split_strings(raw: str) -> tuple[str, ...]:
    s = raw.strip()
    if s.startswith("[") and s.endswith("]"):
        s = s[1:-1]
    return tuple(
        part.strip().strip('"').strip("'")
        for part in s.split(",") if part.strip()
    )


def _load_blade_file(path: Path, *, source: str) -> Optional[Blade]:
    try:
        raw = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    from prometheus.agent.aptitudes import _parse_frontmatter
    fm, body = _parse_frontmatter(raw)
    name = fm.get("name") or path.stem
    type_ = fm.get("type", "prompt").lower()
    if type_ not in VALID_TYPES:
        type_ = "prompt"
    return Blade(
        name=name[:64],
        description=(fm.get("description") or "").strip()[:200],
        body=body.strip()[:8000],
        path=path,
        type=type_,
        allowed_tools=_split_strings(
            fm.get("allowed-tools") or fm.get("allowed_tools") or ""
        ),
        source=source,
    )


def discover_blades(workdir: Path) -> list[Blade]:
    """Walk project, user, and aptitude scopes for blade files."""
    try:
        from prometheus.safety.trust import is_trusted
    except Exception:
        is_trusted = lambda _: False  # type: ignore
    out: list[Blade] = []
    seen: set[str] = set()
    paths: list[tuple[Path, str]] = []
    if is_trusted(workdir):
        proj = workdir / ".prometheus" / "blades"
        if proj.exists() and proj.is_dir():
            for p in sorted(proj.rglob("*.md")):
                paths.append((p, "project"))
    user = Path.home() / ".prometheus" / "blades"
    if user.exists() and user.is_dir():
        for p in sorted(user.rglob("*.md")):
            paths.append((p, "user"))
    # Aptitude-scoped blades (component-level).
    try:
        from prometheus.agent.aptitudes import discover_aptitudes
        for apt in discover_aptitudes(workdir):
            blades_dir = apt.root_dir / "blades"
            if blades_dir.exists() and blades_dir.is_dir():
                for p in sorted(blades_dir.rglob("*.md")):
                    paths.append((p, f"aptitude:{apt.name}"))
    except Exception:
        pass
    for p, source in paths:
        b = _load_blade_file(p, source=source)
        if b is None or b.name in seen:
            continue
        seen.add(b.name)
        out.append(b)
    return out


def get_blade(workdir: Path, name: str) -> Optional[Blade]:
    for b in discover_blades(workdir):
        if b.name == name:
            return b
    return None
