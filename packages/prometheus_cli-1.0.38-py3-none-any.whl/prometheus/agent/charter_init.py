"""Round 98: `/init` Charter scanner + draft generator.

The `/init` command should produce a CHARTER (PROMETHEUS.md) that
reads like what a senior engineer would tell a new hire on day one:
critical context, commands that work, important patterns, gotchas.

This module is the deterministic part — it walks the workdir and
emits a draft charter based on what it finds. The slash command
shows the draft as a preview; on confirmation it writes the file.

Detected stacks (one or more may apply to a single repo):

  * Python      — pyproject.toml, setup.py, requirements.txt, tox.ini
  * Node/TS     — package.json, tsconfig.json, yarn.lock, pnpm-lock.yaml
  * Rust        — Cargo.toml
  * Go          — go.mod
  * Ruby        — Gemfile, Gemfile.lock
  * Java/Kotlin — pom.xml, build.gradle, build.gradle.kts
  * Elixir      — mix.exs
  * .NET        — *.csproj, *.fsproj, *.sln
  * PHP         — composer.json
  * Make/CMake  — Makefile, CMakeLists.txt
  * Docker      — Dockerfile, docker-compose.yml
  * CI          — .github/workflows/, .gitlab-ci.yml, circle.yml

Detected test runners:

  * Python pytest, unittest, tox
  * Node jest, vitest, mocha
  * Rust cargo test
  * Go go test
  * Ruby rspec, minitest
  * .NET dotnet test

The output is deterministic — the same workdir always yields the
same draft. No LLM calls; no network. The draft is a starting
point, not a finished product; the user is expected to refine it.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class CharterScan:
    """Aggregated detection results from the workdir scan.

    `languages` and `frameworks` are lists rather than sets so the
    output ordering is stable for tests."""

    workdir: Path
    languages: list[str] = field(default_factory=list)
    frameworks: list[str] = field(default_factory=list)
    test_commands: list[str] = field(default_factory=list)
    build_commands: list[str] = field(default_factory=list)
    package_files: list[str] = field(default_factory=list)
    has_dockerfile: bool = False
    has_compose: bool = False
    has_ci: bool = False
    has_readme: bool = False
    has_license: bool = False
    has_gitignore: bool = False
    repo_name: str = ""

    def is_empty(self) -> bool:
        return not (
            self.languages or self.frameworks or self.test_commands
            or self.package_files
        )


def _exists(workdir: Path, *names: str) -> Path | None:
    for n in names:
        p = workdir / n
        if p.exists() and p.is_file():
            return p
    return None


def _read_safe(p: Path, max_bytes: int = 32_000) -> str:
    try:
        return p.read_text(encoding="utf-8", errors="replace")[:max_bytes]
    except OSError:
        return ""


def _parse_pyproject(p: Path) -> tuple[list[str], list[str]]:
    """Return (frameworks, test_commands) from a pyproject.toml. We
    avoid pulling in tomllib's overhead for round-98 acceptance —
    string-scan for a few signals is enough for a draft."""
    txt = _read_safe(p)
    fw: list[str] = []
    tests: list[str] = []
    low = txt.lower()
    if "[tool.poetry]" in low:
        fw.append("Poetry")
    if "[tool.hatch" in low or "[tool.hatchling]" in low:
        fw.append("Hatch")
    if "[tool.uv]" in low or "uv.lock" in low:
        fw.append("uv")
    if "[tool.pytest" in low or "pytest" in low:
        tests.append("python -m pytest")
    if "[tool.ruff]" in low:
        fw.append("Ruff")
    if "[tool.mypy]" in low:
        fw.append("mypy")
    return fw, tests


def _parse_package_json(p: Path) -> tuple[list[str], list[str], list[str]]:
    """Return (frameworks, scripts, test_commands) from package.json."""
    txt = _read_safe(p)
    try:
        data = json.loads(txt)
    except (ValueError, TypeError):
        return [], [], []
    fw: list[str] = []
    scripts: list[str] = []
    tests: list[str] = []
    deps_pool: dict[str, str] = {}
    deps_pool.update(data.get("dependencies", {}) or {})
    deps_pool.update(data.get("devDependencies", {}) or {})
    deps_pool.update(data.get("peerDependencies", {}) or {})
    for marker, label in (
        ("react", "React"),
        ("next", "Next.js"),
        ("vue", "Vue"),
        ("svelte", "Svelte"),
        ("angular", "Angular"),
        ("typescript", "TypeScript"),
        ("vite", "Vite"),
        ("webpack", "webpack"),
        ("eslint", "ESLint"),
        ("prettier", "Prettier"),
    ):
        if any(marker in k.lower() for k in deps_pool):
            fw.append(label)
    pkg_scripts = data.get("scripts", {}) or {}
    for k in ("dev", "start", "build", "test", "lint", "typecheck"):
        if k in pkg_scripts:
            scripts.append(f"npm run {k}" if k != "test" else "npm test")
    if "test" in pkg_scripts:
        cmd = pkg_scripts["test"]
        if isinstance(cmd, str):
            low = cmd.lower()
            if "jest" in low:
                tests.append("npx jest")
            elif "vitest" in low:
                tests.append("npx vitest")
            elif "mocha" in low:
                tests.append("npx mocha")
            else:
                tests.append("npm test")
    return fw, scripts, tests


def scan_workdir(workdir: Path) -> CharterScan:
    """Walk the workdir surface (top-level only) and return a
    CharterScan describing what was found."""
    s = CharterScan(workdir=workdir, repo_name=workdir.name)
    # Python
    py_proj = _exists(workdir, "pyproject.toml")
    py_setup = _exists(workdir, "setup.py")
    py_req = _exists(workdir, "requirements.txt")
    py_tox = _exists(workdir, "tox.ini")
    if py_proj or py_setup or py_req or py_tox:
        s.languages.append("Python")
        if py_proj:
            s.package_files.append("pyproject.toml")
            fw, tests = _parse_pyproject(py_proj)
            s.frameworks.extend(fw)
            s.test_commands.extend(tests)
        if py_setup:
            s.package_files.append("setup.py")
        if py_req:
            s.package_files.append("requirements.txt")
        if py_tox:
            s.test_commands.append("tox")
        # Default pytest fallback if test/ or tests/ exists.
        if not s.test_commands:
            for tdir in ("tests", "test"):
                if (workdir / tdir).exists() and (workdir / tdir).is_dir():
                    s.test_commands.append("python -m pytest")
                    break
    # Node / TypeScript
    pkg_json = _exists(workdir, "package.json")
    if pkg_json:
        s.languages.append("JavaScript/TypeScript")
        s.package_files.append("package.json")
        fw, scripts, tests = _parse_package_json(pkg_json)
        s.frameworks.extend(fw)
        s.build_commands.extend(scripts)
        s.test_commands.extend(tests)
    # Rust
    if _exists(workdir, "Cargo.toml"):
        s.languages.append("Rust")
        s.package_files.append("Cargo.toml")
        s.test_commands.append("cargo test")
        s.build_commands.extend(["cargo build", "cargo run"])
    # Go
    if _exists(workdir, "go.mod"):
        s.languages.append("Go")
        s.package_files.append("go.mod")
        s.test_commands.append("go test ./...")
        s.build_commands.append("go build ./...")
    # Ruby
    if _exists(workdir, "Gemfile"):
        s.languages.append("Ruby")
        s.package_files.append("Gemfile")
        if (workdir / "spec").exists():
            s.test_commands.append("bundle exec rspec")
        else:
            s.test_commands.append("bundle exec rake test")
    # Java/Kotlin
    if _exists(workdir, "pom.xml"):
        s.languages.append("Java")
        s.package_files.append("pom.xml")
        s.test_commands.append("mvn test")
        s.build_commands.append("mvn package")
    if _exists(workdir, "build.gradle", "build.gradle.kts"):
        s.languages.append("Java/Kotlin")
        if "build.gradle" not in s.package_files:
            s.package_files.append("build.gradle")
        s.test_commands.append("./gradlew test")
        s.build_commands.append("./gradlew build")
    # Elixir
    if _exists(workdir, "mix.exs"):
        s.languages.append("Elixir")
        s.package_files.append("mix.exs")
        s.test_commands.append("mix test")
    # PHP
    if _exists(workdir, "composer.json"):
        s.languages.append("PHP")
        s.package_files.append("composer.json")
    # .NET
    try:
        for entry in workdir.iterdir():
            if (
                entry.is_file()
                and entry.suffix.lower() in (".csproj", ".fsproj", ".sln")
            ):
                if ".NET" not in s.languages:
                    s.languages.append(".NET")
                s.package_files.append(entry.name)
                if "dotnet test" not in s.test_commands:
                    s.test_commands.append("dotnet test")
                if "dotnet build" not in s.build_commands:
                    s.build_commands.append("dotnet build")
                break
    except OSError:
        pass
    # Make / CMake
    if _exists(workdir, "Makefile"):
        s.frameworks.append("Make")
        s.build_commands.append("make")
        if "make test" not in s.test_commands:
            mk = _read_safe(workdir / "Makefile", max_bytes=8000)
            if "test:" in mk or "\ntest:" in mk:
                s.test_commands.append("make test")
    if _exists(workdir, "CMakeLists.txt"):
        s.frameworks.append("CMake")
    # Docker
    s.has_dockerfile = _exists(workdir, "Dockerfile") is not None
    s.has_compose = _exists(
        workdir, "docker-compose.yml", "docker-compose.yaml",
        "compose.yml", "compose.yaml",
    ) is not None
    # CI
    s.has_ci = (
        (workdir / ".github" / "workflows").exists()
        or _exists(workdir, ".gitlab-ci.yml") is not None
        or _exists(workdir, "circle.yml", ".circleci/config.yml") is not None
        or _exists(workdir, ".travis.yml") is not None
    )
    s.has_readme = _exists(
        workdir, "README.md", "README.rst", "README.txt", "README",
    ) is not None
    s.has_license = _exists(
        workdir, "LICENSE", "LICENSE.md", "LICENSE.txt", "COPYING",
    ) is not None
    s.has_gitignore = _exists(workdir, ".gitignore") is not None
    # De-duplicate while preserving order.
    s.languages = list(dict.fromkeys(s.languages))
    s.frameworks = list(dict.fromkeys(s.frameworks))
    s.package_files = list(dict.fromkeys(s.package_files))
    s.test_commands = list(dict.fromkeys(s.test_commands))
    s.build_commands = list(dict.fromkeys(s.build_commands))
    return s


# ---------- charter draft generator ----------


def render_draft(scan: CharterScan) -> str:
    """Turn a CharterScan into a Markdown draft that mirrors the
    Phase-1 spec layout: Project header → Critical Context →
    Commands That Work → Important Patterns → Gotchas."""
    lines: list[str] = []
    name = scan.repo_name or "this project"
    lines.append(f"# Project: {name}")
    lines.append("")
    lines.append(
        "This Charter loads at the start of every PrometheUS "
        "session. Edit it like you'd onboard a new engineer — "
        "what would you tell them on day one?"
    )
    lines.append("")
    lines.append("## Critical Context (Read First)")
    if scan.languages:
        lines.append(f"- Languages: {', '.join(scan.languages)}")
    if scan.frameworks:
        lines.append(f"- Frameworks/tools: {', '.join(scan.frameworks)}")
    if scan.package_files:
        lines.append(
            f"- Manifests detected: {', '.join(scan.package_files)}"
        )
    if scan.has_dockerfile:
        lines.append("- Containerized: Dockerfile present")
    if scan.has_compose:
        lines.append("- Multi-service: docker-compose detected")
    if scan.has_ci:
        lines.append("- CI: continuous-integration config present")
    lines.append("")
    lines.append("## Commands That Work")
    lines.append("```bash")
    if scan.test_commands:
        lines.append("# Tests")
        for cmd in scan.test_commands:
            lines.append(cmd)
    if scan.build_commands:
        lines.append("# Build / dev")
        for cmd in scan.build_commands:
            lines.append(cmd)
    if not scan.test_commands and not scan.build_commands:
        lines.append("# (Add the commands you actually use here.)")
        lines.append("# Example: make dev, make test, npm run lint")
    lines.append("```")
    lines.append("")
    lines.append("## Important Patterns")
    if scan.has_readme:
        lines.append(
            "- Read the README before assuming defaults — "
            "it captured what the auto-scan can't see."
        )
    lines.append(
        "- (Replace these stubs with the patterns your team "
        "actually relies on — directory layout, public API "
        "shape, naming conventions, etc.)"
    )
    lines.append("")
    lines.append("## Gotchas & What NOT to Do")
    lines.append(
        "- (List the traps that have bitten the team. Keep them "
        "specific — \"Don't run X\", not \"Be careful with X\".)"
    )
    if not scan.has_gitignore:
        lines.append("- No `.gitignore` was detected — add one before committing.")
    if not scan.has_license:
        lines.append(
            "- No LICENSE file was detected — confirm the project's "
            "licensing intent before publishing."
        )
    lines.append("")
    lines.append("## Style & Conventions")
    lines.append(
        "- (Coding style notes go here — line width, import "
        "ordering, error-handling philosophy, comment policy.)"
    )
    lines.append("")
    lines.append("---")
    lines.append(
        f"<!-- Charter generated by `/init`. "
        f"Repo: {scan.repo_name}. "
        f"Replace the stubs above with project-specific content. -->"
    )
    return "\n".join(lines).rstrip() + "\n"


def empty_draft(workdir: Path) -> str:
    """Fallback when the scan finds nothing worth templating —
    plain skeleton the user can fill in."""
    name = workdir.name or "this project"
    return (
        f"# Project: {name}\n\n"
        "## Critical Context (Read First)\n\n"
        "- (Languages, frameworks, key dependencies)\n\n"
        "## Commands That Work\n\n"
        "```bash\n# Add the commands you actually use\n```\n\n"
        "## Important Patterns\n\n"
        "- (Architecture, conventions, naming)\n\n"
        "## Gotchas & What NOT to Do\n\n"
        "- (Traps and rules of the road)\n"
    )


def generate_charter(workdir: Path) -> tuple[str, CharterScan]:
    """Single entry point: scan the workdir and return
    `(draft_markdown, scan)`. The caller (slash command) is
    responsible for prompting the user to confirm before writing
    the file."""
    scan = scan_workdir(workdir)
    if scan.is_empty():
        return empty_draft(workdir), scan
    return render_draft(scan), scan
