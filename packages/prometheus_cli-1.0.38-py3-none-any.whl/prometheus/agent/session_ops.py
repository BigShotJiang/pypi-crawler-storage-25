"""Round 125: /fork, /export, /recap helpers.

  * `fork_session(...)` — copy the live agent state to a new
    session id; the new session inherits all messages, todos,
    permission_mode, and read_history.
  * `export_transcript(...)` — turn a session's messages into a
    plain-text export.
  * `recap(...)` — synthesize a one-line `✦ Xm session · N tool
    calls · M files edited · summary` line from session state.

These helpers are pure-data so the slash commands wire to them
without needing the live Textual app.
"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional


# ---------- fork ----------


@dataclass
class ForkResult:
    parent_session_id: str
    new_session_id: str
    messages_copied: int
    todos_copied: int


def fork_session(
    *,
    parent_session_id: str,
    messages: list,
    todos: list,
    permission_mode: str,
    read_history: set,
) -> ForkResult:
    """Round 125: build a new session payload identical to the
    parent at this moment. The caller persists the payload via
    SessionStore (the same path that handles /resume)."""
    new_id = uuid.uuid4().hex[:8]
    return ForkResult(
        parent_session_id=parent_session_id,
        new_session_id=new_id,
        messages_copied=len(messages or []),
        todos_copied=len(todos or []),
    )


def fork_payload(
    *,
    messages: list,
    todos: list,
    permission_mode: str,
    read_history: set,
    label: str = "",
) -> dict[str, Any]:
    """Return a payload dict the SessionStore can persist as a
    new session record. The shape mirrors round-102 anchors
    (which already supports messages + todos + permission_mode +
    read_history) so /resume reads back without changes."""
    return {
        "messages": list(messages or []),
        "todos": list(todos or []),
        "permission_mode": permission_mode,
        "read_history": list(read_history or []),
        "label": label,
        "forked_at": time.time(),
    }


# ---------- export ----------


def export_transcript(
    messages: list[dict[str, Any]], *,
    label: str = "",
) -> str:
    """Round 125: produce a plain-text export of the conversation.

    Layout:
        # PrometheUS transcript — <label>
        # <ISO timestamp>
        # <N> messages

        ## user
        ...

        ## assistant
        ...

        ## tool: run_bash
        ...
    """
    import datetime as _dt
    lines: list[str] = []
    lines.append(
        f"# PrometheUS transcript"
        + (f" — {label}" if label else "")
    )
    lines.append(
        f"# {_dt.datetime.utcnow().isoformat() + 'Z'}"
    )
    lines.append(f"# {len(messages)} messages")
    lines.append("")
    for msg in messages:
        role = str(msg.get("role", "")).strip() or "unknown"
        content = msg.get("content", "")
        if isinstance(content, list):
            # OpenAI-style content blocks — flatten.
            content = "\n".join(
                str(c.get("text", c)) if isinstance(c, dict) else str(c)
                for c in content
            )
        name = msg.get("name", "")
        head = f"## {role}"
        if name:
            head += f": {name}"
        lines.append(head)
        lines.append("")
        lines.append(str(content).rstrip())
        lines.append("")
        # Surface tool_calls in the export too.
        for tc in (msg.get("tool_calls") or []):
            fn = tc.get("function") or {}
            tc_name = fn.get("name", "")
            tc_args = fn.get("arguments", "")
            lines.append(f"  ↳ tool_call: {tc_name}({tc_args})")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def write_transcript_file(
    messages: list, *, target: Path, label: str = "",
) -> tuple[bool, str]:
    """Write transcript to `target`. Returns `(ok, message)`."""
    body = export_transcript(messages, label=label)
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(body, encoding="utf-8")
    except OSError as e:
        return False, f"could not write {target}: {e}"
    return True, f"wrote {target} ({len(body)} chars)"


# ---------- recap ----------


@dataclass
class RecapStats:
    duration_s: float
    n_messages: int
    n_tool_calls: int
    files_changed: int
    summary: str       # one-line outcome


def _format_short_duration(seconds: float) -> str:
    s = int(max(0, seconds))
    if s < 60:
        return f"{s}s"
    if s < 3600:
        return f"{s // 60}m"
    return f"{s // 3600}h{(s % 3600) // 60}m"


def compute_recap(
    *,
    started_at: float,
    messages: list,
    files_changed: Optional[set] = None,
) -> RecapStats:
    """Round 125: synthesize recap metrics from a session's
    state. The caller renders `✦ Xm session · N tool calls · M
    files edited · summary`."""
    duration = max(0.0, time.time() - started_at) if started_at else 0.0
    n_msgs = len(messages or [])
    n_tool_calls = 0
    summary = ""
    for m in (messages or []):
        if (m.get("role") or "").lower() == "tool":
            n_tool_calls += 1
        elif (m.get("role") or "").lower() == "assistant":
            content = m.get("content", "")
            if isinstance(content, str) and content.strip():
                # Last assistant text wins as the "outcome".
                summary = content.strip().splitlines()[0][:80]
    return RecapStats(
        duration_s=duration,
        n_messages=n_msgs,
        n_tool_calls=n_tool_calls,
        files_changed=len(files_changed or set()),
        summary=summary or "(no outcome)",
    )


def render_recap(stats: RecapStats) -> str:
    """Round 125: one-line recap formatted like Claude's session
    summary banner."""
    return (
        f"✦ {_format_short_duration(stats.duration_s)} session "
        f"· {stats.n_tool_calls} tool calls "
        f"· {stats.files_changed} files edited "
        f"· {stats.summary}"
    )
