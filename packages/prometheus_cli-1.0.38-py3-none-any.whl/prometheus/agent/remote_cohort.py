"""Round 117: RemoteCohort — agent execution over MCP transport.

A RemoteCohort runs in an external environment (cloud worker,
container, separate VM) and PrometheUS talks to it via MCP. The
parent dispatches the cohort, the remote endpoint runs it, the
result rolls back over the same MCP channel.

Round 117 ships:

  * the data model (`RemoteCohortConfig`, `RemoteCohortHandle`)
  * configuration discovery (from `forge.json`'s `mcpServers` +
    a new `remoteCohorts` section)
  * dispatch + result-collection shape

The actual `tools/call` round-trip over an MCP transport
arrives when the MCP transport layer goes live (the round-100
MCPServerRegistry has the bookkeeping; round-117 adds the
dispatch contract on top).
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


@dataclass
class RemoteCohortConfig:
    """One configured remote-cohort endpoint.

    Loaded from `forge.json` or `~/.prometheus/settings.json`:

        {
          "remoteCohorts": {
            "secops-deep": {
              "server": "secops-mcp-server",
              "tool": "deep_audit",
              "model": "default",
              "timeout_s": 600
            }
          }
        }

    `server` references an MCPServer in the same registry
    (round 100); `tool` is the MCP tool name on that server
    that triggers a remote-agent run.
    """
    name: str
    server: str
    tool: str
    model: str = "default"
    timeout_s: int = 600
    description: str = ""
    source: str = "user"


@dataclass
class RemoteCohortHandle:
    """Live handle to a dispatched RemoteCohort. The parent uses
    `await handle.wait()` to collect the result."""
    config: RemoteCohortConfig
    invocation_id: str
    status: str = "queued"        # queued | running | completed | failed
    result: Optional[str] = None
    error: Optional[str] = None
    started_at: float = 0.0
    finished_at: float = 0.0


def parse_remote_cohort_entry(
    name: str, raw: dict, *, source: str = "user",
) -> Optional[RemoteCohortConfig]:
    if not isinstance(raw, dict):
        return None
    server = str(raw.get("server", "") or "").strip()
    tool = str(raw.get("tool", "") or "").strip()
    if not (server and tool):
        return None
    return RemoteCohortConfig(
        name=name.strip(),
        server=server,
        tool=tool,
        model=str(raw.get("model", "default") or "default"),
        timeout_s=int(raw.get("timeout_s", 600) or 600),
        description=str(raw.get("description", "")),
        source=source,
    )


def load_remote_cohorts_from_settings(
    path: Path, *, source: str = "settings",
) -> list[RemoteCohortConfig]:
    if not path.exists() or not path.is_file():
        return []
    try:
        data = json.loads(
            path.read_text(encoding="utf-8", errors="replace")
        )
    except (OSError, ValueError):
        return []
    block = data.get("remoteCohorts") or data.get("remote_cohorts") or {}
    out: list[RemoteCohortConfig] = []
    for name, raw in (block.items() if isinstance(block, dict) else []):
        cfg = parse_remote_cohort_entry(name, raw, source=source)
        if cfg:
            out.append(cfg)
    return out


def discover_remote_cohorts(workdir: Path) -> list[RemoteCohortConfig]:
    out: list[RemoteCohortConfig] = []
    seen: set[str] = set()
    for path, source in (
        (workdir / ".prometheus" / "settings.json", "project"),
        (Path.home() / ".prometheus" / "settings.json", "user"),
    ):
        for cfg in load_remote_cohorts_from_settings(path, source=source):
            if cfg.name in seen:
                continue
            seen.add(cfg.name)
            out.append(cfg)
    # Forge-kit-shipped remote cohorts.
    try:
        from prometheus.forge.registry import ForgeRegistry
        for kit in ForgeRegistry(workdir).active_kits():
            block = kit.manifest.raw.get("remoteCohorts") or {}
            if not isinstance(block, dict):
                continue
            for name, raw in block.items():
                cfg = parse_remote_cohort_entry(
                    name, raw, source=f"forge:{kit.name}",
                )
                if cfg and cfg.name not in seen:
                    seen.add(cfg.name)
                    out.append(cfg)
    except Exception:
        pass
    return out


# ---------- dispatch shape ----------


async def dispatch_remote_cohort(
    config: RemoteCohortConfig,
    *,
    prompt: str,
    mcp_registry,
) -> RemoteCohortHandle:
    """Round 117: dispatch contract for RemoteCohort.

    Looks up the configured MCP server in the registry and
    returns a handle. Actual transport (`tools/call` round-trip)
    plugs in when the MCP transport goes live — round 117 ships
    the handle shape so callers can wire against it now.
    """
    import time
    import uuid
    handle = RemoteCohortHandle(
        config=config,
        invocation_id=uuid.uuid4().hex[:10],
        status="queued",
        started_at=time.time(),
    )
    server = mcp_registry.find(config.server) if mcp_registry else None
    if server is None:
        handle.status = "failed"
        handle.error = (
            f"MCP server {config.server!r} not configured. "
            f"Add it to `mcpServers` in settings.json."
        )
        handle.finished_at = time.time()
        return handle
    # When the transport layer goes live, this is where we'd
    # await `server.call_tool(config.tool, {"prompt": prompt})`
    # and capture the result. Round 117 stub: mark queued so the
    # caller's UI can show the state correctly.
    handle.status = "queued"
    return handle
