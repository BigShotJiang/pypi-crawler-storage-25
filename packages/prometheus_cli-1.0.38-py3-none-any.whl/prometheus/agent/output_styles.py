"""Round 106: Output Styles.

A setting that switches the agent between three reply styles:

  * `default`     — Standard concise output. The pre-106 behavior.
  * `explanatory` — Includes "Insight" annotations explaining why
                    the agent made specific decisions.
  * `learning`    — Includes interactive "TODO(human)" markers
                    inviting the user to practice or verify.

The style is applied as a system-prompt overlay so it shapes
every reply without requiring per-tool changes. AgentLoop.output_style
is the canonical setting (existing field; round 106 just wires it
to a richer overlay).
"""
from __future__ import annotations


VALID_STYLES = ("default", "explanatory", "learning")


_OVERLAYS: dict[str, str] = {
    "default": "",
    "explanatory": (
        "\n\n=== OUTPUT STYLE: explanatory ===\n"
        "After significant decisions or non-obvious choices, surface a "
        "compact `Insight:` annotation explaining your reasoning. Keep "
        "each insight to one or two sentences — not a lecture. Examples:\n"
        "  Insight: chose `aiohttp` over `httpx` because the existing\n"
        "  client in `app/clients/` already uses aiohttp's retry\n"
        "  middleware.\n"
        "  Insight: skipped the obvious `re.match` because the string\n"
        "  can contain newlines, which `re.match` doesn't span.\n"
        "Do NOT prepend an `Insight:` line to every reply — only when\n"
        "the choice is non-obvious or the user might wonder why.\n"
        "================================="
    ),
    "learning": (
        "\n\n=== OUTPUT STYLE: learning ===\n"
        "When you write code, include `TODO(human)` markers at points\n"
        "where the user should practice or verify. Each marker is a\n"
        "one-line invitation, e.g.:\n"
        "  # TODO(human): write the test for this branch.\n"
        "  // TODO(human): run `npm test` and confirm green.\n"
        "Place markers at decision points, not every line. Match the\n"
        "comment syntax of the surrounding language. After the code,\n"
        "summarize what you did and what's left for the human to do.\n"
        "============================="
    ),
}


def overlay_for(style: str) -> str:
    """Return the system-prompt overlay for an output style.
    Unknown style → empty string (acts as `default`)."""
    return _OVERLAYS.get(style, "")


def is_valid(style: str) -> bool:
    return style in VALID_STYLES
