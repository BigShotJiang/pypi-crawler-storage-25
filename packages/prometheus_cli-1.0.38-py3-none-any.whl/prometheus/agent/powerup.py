"""Round 122: /powerup — interactive tutorials.

Tutorials are markdown files in `.prometheus/tutorials/<name>.md`
or under `~/.prometheus/tutorials/`. Five built-in tutorials ship
with PrometheUS. Each tutorial is parsed into alternating `lesson`
and `try` blocks that the user advances through with Enter.

File format:

    ---
    name: getting-started
    description: Tour of the most-used commands.
    ---
    # Getting started with PrometheUS

    ## Lesson
    Welcome to PrometheUS. Slash commands start with `/`.

    ## Try
    Type `/help` to see every command.

    ## Lesson
    Aptitudes are auto-loaded knowledge packages.

    ## Try
    Run `/aptitude` to list the ones available.

`## Lesson` / `## Try` headings split the file into steps. Each
step has a kind (`lesson` or `try`) and a body. The runtime
walks them sequentially.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


_STEP_RX = re.compile(
    r"^##\s+(lesson|try|note)\b",
    re.IGNORECASE | re.MULTILINE,
)


@dataclass
class TutorialStep:
    kind: str          # `lesson` / `try` / `note`
    body: str

    @property
    def short(self) -> str:
        first = self.body.strip().splitlines()[0] if self.body else ""
        return first[:80] + ("…" if len(first) > 80 else "")


@dataclass
class Tutorial:
    name: str
    description: str
    steps: list[TutorialStep] = field(default_factory=list)
    path: Optional[Path] = None
    source: str = "builtin"


def parse_tutorial(text: str, *, path: Optional[Path] = None) -> Optional[Tutorial]:
    """Round 122: parse a tutorial markdown file."""
    from prometheus.agent.aptitudes import _parse_frontmatter
    fm, body = _parse_frontmatter(text)
    name = fm.get("name") or (path.stem if path else "tutorial")
    description = (fm.get("description") or "").strip()[:200]
    steps: list[TutorialStep] = []
    matches = list(_STEP_RX.finditer(body))
    if not matches:
        # No `## Lesson` / `## Try` markers — treat the whole
        # body as a single lesson step.
        if body.strip():
            steps.append(TutorialStep(kind="lesson", body=body.strip()))
    else:
        for i, m in enumerate(matches):
            kind = m.group(1).lower()
            start = m.end()
            stop = matches[i + 1].start() if i + 1 < len(matches) else len(body)
            chunk = body[start:stop].strip()
            if chunk:
                steps.append(TutorialStep(kind=kind, body=chunk))
    return Tutorial(
        name=name[:64], description=description,
        steps=steps, path=path,
        source="user" if path else "builtin",
    )


# ---------- built-in tutorials ----------


_BUILTIN_DEFS: list[tuple[str, str, str]] = [
    (
        "getting-started",
        "Tour of PrometheUS's most-used commands.",
        """
## Lesson
Welcome. PrometheUS is a terminal AI coding agent. Slash
commands start with `/`. Type `/help` to see them all.

## Try
Type `/help` and press Enter.

## Lesson
Tools — Read, Edit, Bash — appear as compact receipts in your
chat-log when the agent runs them.

## Try
Ask: `What files are in this directory?` and watch the receipts.

## Lesson
The Charter (`PROMETHEUS.md`) is loaded into every session as
project context.

## Try
Run `/init --print` to preview a generated Charter for this repo.
""",
    ),
    (
        "using-aptitudes",
        "How to author and use Aptitudes.",
        """
## Lesson
An Aptitude is a markdown file under `.prometheus/aptitudes/`
that loads when its trigger keywords appear in your prompt.

## Try
Run `/aptitude` to list discovered aptitudes.

## Lesson
Each aptitude has a `purpose:` line (Tier 1 catalogue) and a
body (Tier 2 — loads only when triggered).

## Try
Run `/aptitude show <name>` to inspect an aptitude's contents.

## Lesson
Force-load an aptitude even without trigger words via
`/aptitude run <name>`. The boost is one-shot.
""",
    ),
    (
        "background-cohorts",
        "Dispatch and manage background Cohort agents.",
        """
## Lesson
Cohorts are specialized agents that run alongside the main
session — useful for parallel research or independent
verification.

## Try
Type `/cohorts` to see defined cohort templates.

## Lesson
Dispatch a background cohort by asking the agent to use the
`task` tool with `run_in_background: true`.

## Try
Ask: `In the background, list the files in this directory.`

## Lesson
Cards stack in the panel. Press `Ctrl+O` to expand the
most-recent one. Esc cancels every running cohort.
""",
    ),
    (
        "permission-modes",
        "Permission modes and the Overseer.",
        """
## Lesson
Permission mode controls when PrometheUS asks before acting.
Modes: default, acceptEdits, plan, skipAll, auto. Cycle with
Shift+Tab.

## Try
Press Shift+Tab a few times and watch the bottom bar pill
change.

## Lesson
The Overseer auto-blocks irreversible operations (rm -rf,
DROP DATABASE, force push). Tier rules apply: HARD_DENY can't
be overridden; SOFT_DENY can be retried with intent.

## Try
Run `/overseer test run_bash "rm -rf /home"` — see the deny.

## Lesson
View the recently-denied ledger with `/permissions denied`.
""",
    ),
    (
        "the-charter",
        "Author a Charter for your project.",
        """
## Lesson
The Charter (`PROMETHEUS.md`) loads at every session. Treat it
like onboarding for a new dev: critical context, commands,
patterns, gotchas.

## Try
Run `/init --print` to preview a generated Charter scan.

## Lesson
The Charter supports `@references` — a line like
`@docs/auth-conventions.md` inlines the referenced file.

## Try
Add a section "## See also" with `@README.md` and re-load.

## Lesson
Path-scoped rules under `.prometheus/rules/` complement the
Charter for context that only applies under certain paths.
""",
    ),
]


def get_builtins() -> list[Tutorial]:
    """Round 122: parse + return the five built-in tutorials."""
    out: list[Tutorial] = []
    for name, description, body in _BUILTIN_DEFS:
        text = (
            "---\n"
            f"name: {name}\n"
            f"description: {description}\n"
            "---\n"
            + body
        )
        t = parse_tutorial(text)
        if t is not None:
            t.source = "builtin"
            out.append(t)
    return out


def discover_tutorials(workdir: Path) -> list[Tutorial]:
    """Walk built-ins + project + user tutorial dirs."""
    try:
        from prometheus.safety.trust import is_trusted
    except Exception:
        is_trusted = lambda _: False  # type: ignore
    out: list[Tutorial] = list(get_builtins())
    seen: set[str] = {t.name for t in out}
    if is_trusted(workdir):
        proj = workdir / ".prometheus" / "tutorials"
        if proj.exists() and proj.is_dir():
            for p in sorted(proj.glob("*.md")):
                try:
                    text = p.read_text(encoding="utf-8", errors="replace")
                except OSError:
                    continue
                t = parse_tutorial(text, path=p)
                if t is not None and t.name not in seen:
                    t.source = "project"
                    seen.add(t.name)
                    out.append(t)
    user = Path.home() / ".prometheus" / "tutorials"
    if user.exists() and user.is_dir():
        for p in sorted(user.glob("*.md")):
            try:
                text = p.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            t = parse_tutorial(text, path=p)
            if t is not None and t.name not in seen:
                t.source = "user"
                seen.add(t.name)
                out.append(t)
    return out


def get_tutorial(workdir: Path, name: str) -> Optional[Tutorial]:
    for t in discover_tutorials(workdir):
        if t.name == name:
            return t
    return None


# ---------- step renderer ----------


def render_step(step: TutorialStep, *, idx: int, total: int) -> str:
    """Round 122: turn a step into a chat-log-friendly string."""
    glyph = "📖" if step.kind == "lesson" else "▸"
    head = f"{glyph} step {idx + 1}/{total} · {step.kind}"
    return f"{head}\n\n{step.body}"
