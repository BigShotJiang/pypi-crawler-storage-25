"""Round-95 turn-4: hard post-tool short-circuit.

When a tool result clearly indicates a complete success (e.g., pytest
"N passed in Ys"), don't burn another LLM turn deliberating. Compose a
one-line summary directly and end the turn.

Without this, the model sometimes spends 60-120s "thinking" after a
clean exit-0 with the result already in front of it. Prompt-only
guidance helps but isn't enough — the model is already deep in
reasoning by the time it sees the directive. This module gives the
agent loop a deterministic shortcut.

Conservative trigger contract:
  • Fires ONLY when the iteration had exactly ONE tool call. Multi-
    tool turns (chains of 2-4) are left alone — those need the model
    to compose a real summary.
  • Fires ONLY for run_bash with metadata.exit == 0.
  • Output must match a clear-success regex from a known runner.
  • Never fires for tools that mutate source (write_file, edit_file,
    etc.) — verification of an edit's correctness is the model's job.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

# Patterns ordered most-specific first. Each maps captured groups to
# a one-line summary template. The first match wins — return its reply.
_SUCCESS_PATTERNS: list[tuple[re.Pattern, str]] = [
    # pytest: "97 passed in 2.92s" / "5 passed, 1 skipped in 0.41s"
    (
        re.compile(
            r"(?P<n>\d+)\s+passed"
            r"(?:,\s*\d+\s+(?:skipped|deselected|warnings?|xfailed))*"
            r"\s+in\s+(?P<t>[\d.]+)s",
            re.IGNORECASE,
        ),
        "Tests passed: {n} in {t}s.",
    ),
    # node test runner / mocha / jest: "Tests:       42 passed, 42 total"
    (
        re.compile(
            r"Tests:\s+(?P<n>\d+)\s+passed",
            re.IGNORECASE,
        ),
        "Tests passed: {n}.",
    ),
    # cargo test: "test result: ok. 23 passed; 0 failed"
    (
        re.compile(
            r"test\s+result:\s+ok\.\s+(?P<n>\d+)\s+passed",
            re.IGNORECASE,
        ),
        "Tests passed: {n}.",
    ),
    # go test (-v): "PASS\nok      package    0.42s"
    (
        re.compile(
            r"^PASS\s*$.*?^ok\s+\S+\s+(?P<t>[\d.]+)s",
            re.MULTILINE | re.DOTALL,
        ),
        "Go tests passed in {t}s.",
    ),
    # generic OK / passing
    (
        re.compile(r"\ball\s+tests\s+passed\b", re.IGNORECASE),
        "All tests passed.",
    ),
    (
        re.compile(r"^\s*OK\s*$", re.MULTILINE),
        "OK.",
    ),
]


@dataclass
class FinalizeDecision:
    fire: bool
    reply: str = ""
    reason: str = ""


def should_fast_finalize(
    tool_calls: list[Any], results: list[Any],
) -> FinalizeDecision:
    """Decide whether the current iteration should short-circuit.

    Returns FinalizeDecision(fire=True, reply="...") when:
      - exactly one tool call this iteration
      - that call was run_bash
      - the result has metadata.exit == 0
      - either:
          * the output matches a clear-success pattern (test runners), OR
          * R223: the command is an obviously-safe diagnostic read
            (Get-Date, ls, pwd, git status, [System.TimeZoneInfo]::, …)
            and the output is a single short non-empty line. The
            screenshot bug — `what is the time in Hartford CT?`
            spent 50s "thinking" after the bash receipt already
            showed `Saturday, May 9, 2026 3:51:23 PM`. For these
            queries the answer is already in the tool result; the
            model just has to relay it.

    Otherwise returns FinalizeDecision(fire=False) — the loop
    continues normally and the model gets to think.
    """
    if len(tool_calls) != 1 or len(results) != 1:
        return FinalizeDecision(fire=False, reason="non-singleton")
    tc = tool_calls[0]
    rr = results[0]
    if getattr(tc, "name", "") != "run_bash":
        return FinalizeDecision(fire=False, reason="not run_bash")
    meta = getattr(rr, "metadata", None) or {}
    if meta.get("exit") != 0:
        return FinalizeDecision(fire=False, reason=f"exit={meta.get('exit')!r}")
    output = getattr(rr, "output", "") or ""
    for pat, template in _SUCCESS_PATTERNS:
        m = pat.search(output)
        if m:
            try:
                reply = template.format(**m.groupdict())
            except (KeyError, IndexError):
                reply = template
            return FinalizeDecision(
                fire=True, reply=reply,
                reason=f"matched {pat.pattern[:40]!r}",
            )
    # R223: safe-readonly diagnostic short-circuit. When the user
    # asked a one-shot factual question (`what time is it in NYC?`,
    # `where am I?`, `git status`) and the safe-readonly classifier
    # accepted the command, the bash result already contains the
    # answer — burning 50s of free-tier "thinking" to rephrase a
    # date-string is wasted UX. Fire only when:
    #   * the command is in the same allow-set the R221 auto-approve
    #     gate uses (so we don't blanket-finalize arbitrary bash),
    #   * the filtered output has 1-3 non-empty lines (consistent
    #     with the R222 oneliner-receipt threshold; multi-line
    #     output likely benefits from a real LLM summary),
    #   * none of those lines exceeds 200 chars (avoid finalizing
    #     on a stray verbose dump).
    cmd = str(meta.get("command", ""))
    try:
        from prometheus.safety.trust_gradient import is_obviously_safe_command
    except Exception:
        return FinalizeDecision(fire=False, reason="trust_gradient import failed")
    if not cmd or not is_obviously_safe_command(cmd):
        return FinalizeDecision(fire=False, reason="not safe-readonly")
    # Apply the same runner blocklist as the R222 oneliner — pytest
    # / cargo / npm / etc. produce structured output that benefits
    # from the model's summary, even when the command is "safe".
    first_token = cmd.lstrip().split(maxsplit=1)[0].lower() if cmd else ""
    if first_token.endswith(".exe") or first_token.endswith(".cmd"):
        first_token = first_token.rsplit(".", 1)[0]
    if first_token in {"pytest", "cargo", "go", "npm", "yarn", "docker",
                       "python", "python3", "node"}:
        return FinalizeDecision(fire=False, reason=f"runner: {first_token}")
    # Use `metadata.last_lines` (raw stdout) NOT `output` — the
    # latter is the bash tool's formatted blob with `exit: 0\n
    # --- output ---\n` framing that would leak into the reply.
    last_lines = meta.get("last_lines") or []
    nonempty = [ln.strip() for ln in last_lines if (ln or "").strip()]
    if not nonempty:
        return FinalizeDecision(fire=False, reason="empty output")
    if len(nonempty) > 3:
        return FinalizeDecision(fire=False, reason="multi-line output")
    if any(len(ln) > 200 for ln in nonempty):
        return FinalizeDecision(fire=False, reason="line too long")
    # Reply: the output verbatim (joined by space if multi-line),
    # capped at 200 chars. The model would rephrase it to be more
    # conversational, but on free-tier the 50s wait isn't worth the
    # polish. The answer's already on screen via the receipt — this
    # just lets the turn end so the user can move on.
    reply = " ".join(nonempty)[:200]
    return FinalizeDecision(
        fire=True, reply=reply,
        reason=f"safe-readonly diagnostic ({len(nonempty)} lines)",
    )
