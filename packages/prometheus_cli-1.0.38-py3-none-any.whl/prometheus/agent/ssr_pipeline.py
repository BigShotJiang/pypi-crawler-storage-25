"""Round 161 — Hardening 7: SSR-style self-improvement pipeline.

Research (Self-Play SWE-RL): a single LLM trained to BOTH inject
realistic bugs AND repair them learns continuously without
human-labeled data. Bug-injection produces training data; bug-repair
distills it. Performance improves throughout training.

Production reality on free-tier OpenRouter: training a model is out
of scope. What we DO ship is the inference-time analogue:

  • Bug-Injection Phase: pick a random module, mutate it deterministically
    (one of N safe mutation operators), verify the bug is reproducible
    by running the module's tests and seeing them fail.

  • Bug-Repair Phase: a separate caller (the repair driver) attempts a
    fix. The pipeline reports success/failure.

  • Pattern Distillation: when a repair lands, the diff + the fix
    operator are written to the Memory Vault as a reusable
    "fix-pattern" memory.

The pipeline is intentionally idempotent — running it on a clean
codebase against a known module produces the same mutation each time
given the same seed. This lets the round-161 runner exercise the
full lifecycle reproducibly.

The four mutation operators are:
  • drop_import   — remove the first `from x import y` line
  • flip_compare  — swap `==` ↔ `!=` once
  • off_by_one    — flip `range(n)` → `range(n - 1)`
  • return_zero   — make the first def's return value 0

Each operator records what it changed so the repair phase can
double-check the fix actually inverted the bug rather than masking it.
"""
from __future__ import annotations

import hashlib
import random
import re
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class InjectionResult:
    """Output of the bug-injection phase."""
    operator: str
    """Which operator ran. One of `drop_import / flip_compare /
    off_by_one / return_zero`."""
    module_path: str
    original: str
    mutated: str
    summary: str
    """Short human-readable description of the change."""
    reproducible: bool
    """True when the test suite ran and now fails on the mutation."""
    test_output_tail: str = ""


@dataclass
class RepairResult:
    """Output of the repair phase."""
    success: bool
    diff: str
    """Unified-style diff of the repair (original vs. patched)."""
    test_output_tail: str = ""


@dataclass
class FixPattern:
    """The distilled lesson — written to the Memory Vault on success."""
    operator: str
    bug_signature: str
    """Short shape of what changed (e.g. 'missing-import:json' or
    'inverted-compare')."""
    fix_signature: str
    confidence: float


# ---- mutation operators ---------------------------------------------


def _drop_import(src: str) -> tuple[str, str] | None:
    """Drop the first import line. Returns (new_src, summary) or None
    if the source has no imports we can safely remove."""
    lines = src.splitlines(keepends=True)
    for i, ln in enumerate(lines):
        s = ln.strip()
        if s.startswith(("import ", "from ")) and "__future__" not in s:
            removed = ln.rstrip("\n")
            new_lines = lines[:i] + lines[i + 1:]
            return "".join(new_lines), f"dropped import: {removed!r}"
    return None


def _flip_compare(src: str) -> tuple[str, str] | None:
    """Swap the first `==` to `!=` (or vice versa). Returns
    (new_src, summary) or None if no compare is present."""
    if "==" in src:
        new = src.replace("==", "!=", 1)
        return new, "flipped first `==` → `!=`"
    if "!=" in src:
        new = src.replace("!=", "==", 1)
        return new, "flipped first `!=` → `==`"
    return None


def _off_by_one(src: str) -> tuple[str, str] | None:
    """Replace the first `range(N)` with `range(N - 1)` where N is a
    literal int. Returns (new_src, summary) or None."""
    m = re.search(r"\brange\(\s*(\d+)\s*\)", src)
    if not m:
        return None
    n = int(m.group(1))
    new_n = max(0, n - 1)
    new_src = src[:m.start()] + f"range({new_n})" + src[m.end():]
    return new_src, f"off-by-one in range({n}) → range({new_n})"


def _return_zero(src: str) -> tuple[str, str] | None:
    """Replace the first `return <expr>` with `return 0`."""
    m = re.search(r"^(\s*)return\s+([^\n]+)$", src, re.MULTILINE)
    if not m:
        return None
    indent, expr = m.group(1), m.group(2).rstrip()
    new = src[:m.start()] + f"{indent}return 0" + src[m.end():]
    return new, f"made first return constant: {expr!r} → 0"


_OPERATORS = (
    ("drop_import",  _drop_import),
    ("flip_compare", _flip_compare),
    ("off_by_one",   _off_by_one),
    ("return_zero",  _return_zero),
)


# ---- pipeline phases ------------------------------------------------


def _module_signature(path: Path) -> str:
    """Stable seed for `random.choice` so the same file always picks
    the same operator (until we explicitly randomize)."""
    return hashlib.sha1(str(path).encode("utf-8")).hexdigest()[:12]


def inject_bug(
    module_path: Path,
    *,
    test_path: Optional[Path] = None,
    seed: Optional[int] = None,
) -> Optional[InjectionResult]:
    """Pick an operator and apply it. Returns None if no operator
    applies cleanly (e.g. an empty file)."""
    src = module_path.read_text(encoding="utf-8")
    rnd = random.Random(seed if seed is not None else _module_signature(module_path))
    operators = list(_OPERATORS)
    rnd.shuffle(operators)
    for name, fn in operators:
        try:
            res = fn(src)
        except Exception:
            continue
        if res is None:
            continue
        new_src, summary = res
        # Apply the mutation, then check whether the test suite (if
        # any) now fails. If no test_path is supplied the pipeline
        # still records the mutation but `reproducible=False`.
        module_path.write_text(new_src, encoding="utf-8")
        reproducible = False
        tail = ""
        if test_path is not None and test_path.exists():
            ok, tail = _run_pytest(test_path)
            reproducible = not ok
        return InjectionResult(
            operator=name,
            module_path=str(module_path),
            original=src,
            mutated=new_src,
            summary=summary,
            reproducible=reproducible,
            test_output_tail=tail,
        )
    return None


def repair_via_revert(
    module_path: Path, *, original: str, test_path: Optional[Path] = None,
) -> RepairResult:
    """Trivial repair driver: write the original back. Used by the
    round-161 runner to demonstrate the full lifecycle without
    requiring an LLM call. A real-world repair driver would generate
    a candidate fix from the model and run the same verification
    pipeline."""
    pre = module_path.read_text(encoding="utf-8")
    module_path.write_text(original, encoding="utf-8")
    tail = ""
    success = True
    if test_path is not None and test_path.exists():
        ok, tail = _run_pytest(test_path)
        success = ok
    diff = _unified_diff(pre, original, str(module_path))
    return RepairResult(success=success, diff=diff, test_output_tail=tail)


def distill_pattern(
    injection: InjectionResult, repair: RepairResult,
) -> FixPattern | None:
    """Once a repair succeeds, build a FixPattern from it."""
    if not (injection and repair and repair.success):
        return None
    return FixPattern(
        operator=injection.operator,
        bug_signature=injection.summary,
        fix_signature=("revert" if "@@" in (repair.diff or "") else "patch"),
        confidence=1.0 if repair.success else 0.0,
    )


def write_pattern_to_vault(
    pattern: FixPattern, *, workdir: Path,
) -> Optional[Path]:
    """Persist a FixPattern as a Memory Vault entry. Returns the
    written file path (or None if the vault is unavailable)."""
    try:
        from prometheus.agent.memory_vault import save_memory
    except Exception:
        return None
    name = f"ssr-fix-{pattern.operator}"
    desc = (
        f"SSR-distilled fix pattern: when {pattern.bug_signature}, "
        f"apply {pattern.fix_signature} (confidence {pattern.confidence:.0%})"
    )
    body = (
        f"# SSR Fix Pattern — {pattern.operator}\n\n"
        f"**Bug signature.** {pattern.bug_signature}\n\n"
        f"**Fix signature.** {pattern.fix_signature}\n\n"
        f"**Confidence.** {pattern.confidence:.0%}\n\n"
        f"_Distilled by the round-161 SSR pipeline. "
        f"This pattern was learned from a self-play injection + repair "
        f"cycle on `{pattern.operator}` and is reusable on the same "
        f"bug shape._\n"
    )
    try:
        mem = save_memory(
            workdir, name=name, description=desc,
            type_="project", body=body, scope="project",
        )
        return Path(workdir) / ".prometheus" / "memory" / f"{name}.md"
    except Exception:
        return None


# ---- helpers -------------------------------------------------------


def _run_pytest(test_path: Path, timeout_s: float = 30.0) -> tuple[bool, str]:
    try:
        proc = subprocess.run(
            [sys.executable, "-m", "pytest", "-q", "--no-header", str(test_path)],
            capture_output=True, text=True, timeout=timeout_s,
            cwd=str(test_path.parent),
        )
        ok = proc.returncode == 0
        tail = (proc.stdout or proc.stderr or "")[-400:].strip()
        return ok, tail
    except subprocess.TimeoutExpired:
        return False, f"timed out after {timeout_s}s"


def _unified_diff(a: str, b: str, path: str) -> str:
    import difflib
    return "".join(difflib.unified_diff(
        a.splitlines(keepends=True), b.splitlines(keepends=True),
        fromfile=f"a/{path}", tofile=f"b/{path}", n=2,
    ))
