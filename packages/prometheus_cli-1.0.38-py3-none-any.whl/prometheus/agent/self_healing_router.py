"""Round 161 — Hardening 2: self-healing tool router.

Research (Self-Healing Router): tool failures are routing problems,
not reasoning problems. When a tool fails, mark its node unavailable
and route via the cheapest remaining alternative — without a fresh
LLM call. Production data: 93% reduction in control-plane LLM calls.

This module models the tool catalogue as a DAG of *capabilities* (the
high-level intents the agent expresses, like "fetch a remote URL" or
"read a file") with edges to the concrete tools that satisfy them.
When a tool fails, the router walks the alternatives in cost order
and returns the first one whose node is still healthy. The agent
loop calls `route(intent, exclude_tools)` to get the next-best tool
to try; the LLM is only re-invoked when no alternative remains.

The router itself does not execute tools — it only rewires the
dispatch decision. That keeps it deterministic, side-effect-free,
and unit-testable in isolation.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum


class Capability(str, Enum):
    """Coarse-grained intents. Each maps to one or more concrete tools."""
    READ_FILE = "read_file"
    LIST_FILES = "list_files"
    SEARCH_TEXT = "search_text"
    WRITE_FILE = "write_file"
    EDIT_FILE = "edit_file"
    RUN_CMD = "run_cmd"
    FETCH_URL = "fetch_url"
    SEARCH_WEB = "search_web"


# Default capability → ordered alternatives. Order is preference;
# earlier = lower cost / higher fidelity. Each entry is
# (tool_name, cost) where cost is a small integer (0 = preferred).
_DEFAULT_CAPABILITIES: dict[Capability, tuple[tuple[str, int], ...]] = {
    Capability.READ_FILE: (("read_file", 0),),
    Capability.LIST_FILES: (("list_files", 0), ("glob_files", 1)),
    Capability.SEARCH_TEXT: (("search_code", 0), ("grep", 1)),
    Capability.WRITE_FILE: (("write_file", 0),),
    Capability.EDIT_FILE: (("edit_file", 0), ("multi_edit", 1), ("apply_patch", 2)),
    Capability.RUN_CMD: (("run_bash", 0),),
    Capability.FETCH_URL: (
        ("web_fetch", 0),
        # Fallback: ask Bash to curl/urllib the URL when web_fetch fails.
        ("run_bash", 5),
    ),
    Capability.SEARCH_WEB: (("web_search", 0),),
}


@dataclass
class _NodeHealth:
    """Per-tool health record. `unavailable_until` is a monotonic
    timestamp — the router treats the node as healthy again past it."""
    failures: int = 0
    last_error: str = ""
    unavailable_until: float = 0.0


@dataclass
class RouteDecision:
    """The router's verdict for one routing call."""
    capability: Capability
    chosen_tool: str | None
    """`None` means no alternative is available — the agent loop must
    escalate to a fresh LLM call."""
    fallback_args: dict | None = None
    """When `chosen_tool` is a generic alternative (e.g. `run_bash`
    standing in for `web_fetch`), the router supplies the canonical
    args mapping. Otherwise None."""
    rerouted: bool = False
    reroute_log: list[str] = field(default_factory=list)
    """Human-readable trail of which tools were skipped + why."""
    escalate: bool = False


@dataclass
class SelfHealingRouter:
    """Stateful router. Holds per-tool health + capability map; emits
    `RouteDecision`s deterministically."""
    capabilities: dict[Capability, tuple[tuple[str, int], ...]] = field(
        default_factory=lambda: dict(_DEFAULT_CAPABILITIES)
    )
    health: dict[str, _NodeHealth] = field(default_factory=dict)
    cooldown_seconds: float = 30.0
    """How long a tool stays marked unavailable after a failure."""
    total_reroutes: int = 0
    total_escalations: int = 0

    # ---- public API ----

    def record_failure(self, tool: str, error: str) -> None:
        """Mark `tool` unavailable for `cooldown_seconds`."""
        h = self.health.setdefault(tool, _NodeHealth())
        h.failures += 1
        h.last_error = error[:200] if error else ""
        h.unavailable_until = time.monotonic() + self.cooldown_seconds

    def record_success(self, tool: str) -> None:
        """Reset a tool's health on success."""
        h = self.health.setdefault(tool, _NodeHealth())
        h.failures = 0
        h.last_error = ""
        h.unavailable_until = 0.0

    def is_available(self, tool: str) -> bool:
        h = self.health.get(tool)
        if h is None:
            return True
        return time.monotonic() >= h.unavailable_until

    def route(
        self,
        capability: Capability | str,
        *,
        original_args: dict | None = None,
        exclude_tools: tuple[str, ...] = (),
    ) -> RouteDecision:
        """Pick the lowest-cost still-healthy tool for `capability`.

        `exclude_tools` lets the caller reject candidates the model has
        already tried this turn (so a single failure can't oscillate).
        """
        cap = Capability(capability) if isinstance(capability, str) else capability
        choices = self.capabilities.get(cap, ())
        decision = RouteDecision(capability=cap, chosen_tool=None)
        for tool, _cost in sorted(choices, key=lambda kv: kv[1]):
            if tool in exclude_tools:
                decision.reroute_log.append(f"skip {tool}: already tried")
                continue
            if not self.is_available(tool):
                h = self.health.get(tool)
                err = h.last_error if h else "unhealthy"
                decision.reroute_log.append(f"skip {tool}: {err}")
                continue
            decision.chosen_tool = tool
            # If we picked a fallback (cost > 0 → not the primary),
            # it's a reroute and may need synthetic args.
            primary = choices[0][0] if choices else None
            if tool != primary:
                decision.rerouted = True
                self.total_reroutes += 1
                decision.fallback_args = self._synthesize_fallback_args(
                    cap, tool, original_args or {},
                )
            return decision
        # No healthy alternative.
        decision.escalate = True
        self.total_escalations += 1
        decision.reroute_log.append("no healthy alternative — escalating to LLM")
        return decision

    # ---- fallback args synthesis ----

    def _synthesize_fallback_args(
        self, capability: Capability, fallback_tool: str, original_args: dict,
    ) -> dict:
        """When the fallback tool has a different schema than the
        primary (e.g. run_bash standing in for web_fetch), translate
        the args. Caller doesn't have to know how — they just dispatch.

        We support the ones that actually matter; unknown combinations
        return the original args unchanged so the caller can decide."""
        if capability == Capability.FETCH_URL and fallback_tool == "run_bash":
            url = str(original_args.get("url", "")).strip()
            if not url:
                return {"command": "echo 'fallback: missing url'"}
            # urllib via the host python — works on Win/macOS/Linux.
            cmd = (
                "python -c \""
                "import urllib.request, sys; "
                f"r=urllib.request.urlopen({url!r}, timeout=20); "
                "sys.stdout.write(r.read(100000).decode('utf-8','replace'))"
                "\""
            )
            return {"command": cmd, "timeout_ms": 30000}
        if capability == Capability.SEARCH_TEXT and fallback_tool == "grep":
            return {
                "pattern": str(original_args.get("pattern", "")),
                "path": str(original_args.get("path", ".")),
            }
        if capability == Capability.LIST_FILES and fallback_tool == "glob_files":
            return {
                "pattern": original_args.get("pattern") or "*",
                "limit": original_args.get("limit", 200),
            }
        return dict(original_args)


# ---- intent inference helpers (used by the agent loop) ----------------


def infer_capability(tool_name: str) -> Capability | None:
    """Best-guess capability from a tool name. Used by the agent loop
    to feed the router when the model emits a tool call directly."""
    name = (tool_name or "").lower()
    table = {
        "read_file": Capability.READ_FILE,
        "list_files": Capability.LIST_FILES,
        "glob_files": Capability.LIST_FILES,
        "search_code": Capability.SEARCH_TEXT,
        "grep": Capability.SEARCH_TEXT,
        "write_file": Capability.WRITE_FILE,
        "edit_file": Capability.EDIT_FILE,
        "multi_edit": Capability.EDIT_FILE,
        "apply_patch": Capability.EDIT_FILE,
        "run_bash": Capability.RUN_CMD,
        "web_fetch": Capability.FETCH_URL,
        "web_search": Capability.SEARCH_WEB,
    }
    return table.get(name)
