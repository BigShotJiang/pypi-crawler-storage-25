"""Round 102 (Phase 5): Anchor Points — named conversation checkpoints.

The Phase-5 spec calls for `/anchor save "<name>"` and
`/anchor restore <name>`. This module provides the data layer.
The slash command is wired in `prometheus/slash/commands.py`.

Storage: `<workdir>/.prometheus/anchors/<safe-name>.json`. Each
file contains a snapshot of:

  * messages       — `agent.messages` at save time
  * todos          — `agent.todos`
  * permission_mode
  * read_history   — `agent.read_history` set
  * created_at
  * label          — original user-supplied name
  * description    — optional notes

Round-103 polish will add auto-anchors before risky tool calls.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Optional


def _safe_name(label: str) -> str:
    """Slugify a user label for filesystem safety."""
    return "".join(
        c if c.isalnum() or c in "-_" else "-" for c in label.strip()
    )[:64] or "anchor"


def _now_iso() -> str:
    import datetime as _dt
    return _dt.datetime.now(_dt.timezone.utc).isoformat()


@dataclass
class Anchor:
    label: str
    safe_name: str
    path: Path
    created_at: str
    description: str = ""
    auto: bool = False             # True for auto-anchors before risky calls

    def load_payload(self) -> Optional[dict[str, Any]]:
        try:
            return json.loads(
                self.path.read_text(encoding="utf-8", errors="replace")
            )
        except (OSError, ValueError):
            return None


@dataclass
class AnchorRegistry:
    """All anchors saved under `<workdir>/.prometheus/anchors/`."""
    workdir: Path

    @property
    def root(self) -> Path:
        return self.workdir / ".prometheus" / "anchors"

    def list(self) -> list[Anchor]:
        if not self.root.exists() or not self.root.is_dir():
            return []
        out: list[Anchor] = []
        try:
            for p in sorted(self.root.glob("*.json")):
                try:
                    raw = json.loads(p.read_text(
                        encoding="utf-8", errors="replace",
                    ))
                except (OSError, ValueError):
                    continue
                out.append(Anchor(
                    label=str(raw.get("label", p.stem)),
                    safe_name=p.stem,
                    path=p,
                    created_at=str(raw.get("created_at", "")),
                    description=str(raw.get("description", "")),
                    auto=bool(raw.get("auto", False)),
                ))
        except OSError:
            pass
        return out

    def save(
        self,
        *,
        label: str,
        messages: list,
        todos: Optional[list] = None,
        permission_mode: str = "default",
        read_history: Optional[set] = None,
        description: str = "",
        auto: bool = False,
    ) -> Anchor:
        name = _safe_name(label)
        self.root.mkdir(parents=True, exist_ok=True)
        path = self.root / f"{name}.json"
        # If a same-name anchor already exists, append `_2`/`_3`/etc.
        idx = 2
        while path.exists():
            path = self.root / f"{name}_{idx}.json"
            idx += 1
        payload = {
            "label": label,
            "safe_name": path.stem,
            "created_at": _now_iso(),
            "description": description,
            "auto": auto,
            "messages": messages,
            "todos": todos or [],
            "permission_mode": permission_mode,
            "read_history": list(read_history or []),
        }
        path.write_text(
            json.dumps(payload, indent=2, default=str),
            encoding="utf-8",
        )
        return Anchor(
            label=label, safe_name=path.stem, path=path,
            created_at=payload["created_at"],
            description=description, auto=auto,
        )

    def find(self, name_or_label: str) -> Optional[Anchor]:
        target = name_or_label.strip()
        for a in self.list():
            if a.label == target or a.safe_name == target:
                return a
            if _safe_name(target) == a.safe_name:
                return a
        return None

    def remove(self, name_or_label: str) -> bool:
        a = self.find(name_or_label)
        if a is None:
            return False
        try:
            a.path.unlink()
        except OSError:
            return False
        return True

    def restore(self, name_or_label: str) -> Optional[dict]:
        """Return the payload dict for the named anchor — caller
        applies the restore to the live agent."""
        a = self.find(name_or_label)
        if a is None:
            return None
        return a.load_payload()
