"""Round 97: BackgroundAgentManager — owns the lifecycle of
PrometheUS subagents launched with `run_in_background=true`.

This is the data-model + dispatcher half of the Background Subagent
Infrastructure. The UI half lives in `prometheus/ui/subagent_widgets.py`.
The architecture and the gap matrix that drove these design choices
live in `docs/SUBAGENT_ARCHITECTURE.md` and
`docs/SUBAGENT_GAP_MATRIX.md`.

Behavior summary:
  * `submit(...)` creates a `SubAgentTask`, queues it (status=queued)
    or spawns it immediately (status=running) depending on the
    concurrency cap.
  * Each running task has its own `asyncio.Task` wrapping a
    coroutine that runs an isolated AgentLoop. The coroutine
    funnels events into `task.events` as compact SubAgentEvent
    records — they are NOT routed to the parent's chat-log.
  * Tasks reach a terminal state (`completed`/`failed`/`cancelled`/
    `timeout`) and stay there. The UI reads `tasks()` periodically
    via the existing rail tick.
  * Defaults: max parallel = 4, timeout = 600s (10 min, matching
    Claude Code v2.1.113), max depth = 1.
  * Cap at depth 1: a subagent cannot spawn another subagent.
"""
from __future__ import annotations

import asyncio
import os
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Awaitable, Callable, Optional


class SubAgentStatus(str, Enum):
    """Lifecycle states for a SubAgentTask. Subclass of str so the
    UI can `f"{status}"` without unwrapping the enum."""
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"


# Terminal states — once reached, the task does not transition again.
_TERMINAL_STATES = frozenset({
    SubAgentStatus.COMPLETED,
    SubAgentStatus.FAILED,
    SubAgentStatus.CANCELLED,
    SubAgentStatus.TIMEOUT,
})


@dataclass
class SubAgentEvent:
    """A compact one-line record of something the subagent did.
    Stored in the SubAgentTask for the expanded-view body. NEVER
    routed to the parent's chat-log."""
    ts: float
    kind: str            # "text" | "tool_call" | "tool_result" | "status"
    text: str            # short summary; never raw tool output


@dataclass
class SubAgentTask:
    """Authoritative record of a single dispatched subagent. The UI
    reads from these; widgets never own state directly."""
    id: str
    name: str                                  # `description` arg → card title
    subagent_type: str
    prompt: str
    parent_session_id: str
    depth: int = 1                             # parent depth + 1; rejected if > MAX_DEPTH
    status: SubAgentStatus = SubAgentStatus.QUEUED
    started_at: Optional[float] = None
    finished_at: Optional[float] = None
    result: Optional[str] = None
    error: Optional[str] = None
    expanded: bool = False
    events: list[SubAgentEvent] = field(default_factory=list)
    task_handle: Optional[asyncio.Task] = None
    # Round 164 / #2: live progress for the currently-running tool
    # inside this cohort. `current_tool` is None when the cohort is
    # between tool calls; when set, the card surfaces a
    # `✦ Running: <verb> <detail>` line under the status pill.
    # `last_completed_tool` + `last_completed_summary` carry the
    # most-recent finished tool's `⏺ Completed: <past-verb> <detail>`
    # line so the card has something useful to show after the tool
    # exits but before the cohort itself terminates.
    current_tool: Optional[str] = None
    current_tool_args: dict = field(default_factory=dict)
    last_completed_tool: Optional[str] = None
    last_completed_summary: Optional[str] = None

    # ---------- derived helpers ----------

    def elapsed_s(self, now: Optional[float] = None) -> float:
        """Live elapsed wall-clock; returns 0 if not started yet."""
        if self.started_at is None:
            return 0.0
        end = self.finished_at if self.finished_at is not None else (
            now if now is not None else time.monotonic()
        )
        return max(0.0, end - self.started_at)

    def is_terminal(self) -> bool:
        return self.status in _TERMINAL_STATES

    def preview(self, n: int = 80) -> str:
        """One-line preview for the collapsed card body. Pulls the
        first non-empty line of result; returns short text. Never
        leaks raw tool output (only the final assistant text)."""
        if not self.result:
            return ""
        for ln in self.result.splitlines():
            ln = ln.strip()
            if ln:
                return ln[:n] + ("…" if len(ln) > n else "")
        return ""


# ---------- env-tunable knobs ----------


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


def _max_parallel() -> int:
    """Round 97: default 4 to avoid the 24-spawn resource exhaustion
    surfaced in Claude Code issue #25714. Configurable via
    `PROMETHEUS_SUBAGENT_MAX_PARALLEL`."""
    return max(1, _env_int("PROMETHEUS_SUBAGENT_MAX_PARALLEL", 4))


def _timeout_s() -> float:
    """Round 97: default 600s (10 min), matching Claude Code's
    v2.1.113 stalled-subagent ceiling. Configurable via
    `PROMETHEUS_SUBAGENT_TIMEOUT_S`."""
    return max(10.0, _env_float("PROMETHEUS_SUBAGENT_TIMEOUT_S", 600.0))


# Hard recursion cap. Constant rather than env-tunable: nested
# subagents trivially deadlock and there's no plausible reason
# the user wants depth > 1.
MAX_DEPTH = 1


# ---------- the manager ----------


# Type alias for the per-subagent runner — async callable that takes
# (task, parent_ctx) and returns the final assistant text. The actual
# implementation lives in app.py (`_run_one_subagent_for_manager`)
# because it needs access to the parent app's client / settings.
RunnerFn = Callable[
    ["SubAgentTask", Any],
    Awaitable[str],
]


class BackgroundAgentManager:
    """Singleton-per-app dispatcher that owns SubAgentTask records.

    Lifecycle:
      1. `submit(...)` creates a task. If active count < MAX_PARALLEL,
         the task is spawned immediately (status=running). Otherwise
         it sits in queued status until a running task finishes.
      2. Each running task has an `asyncio.Task` wrapping a runner
         coroutine. The coroutine sets status to running, calls the
         runner_fn, then sets the terminal status.
      3. `cancel(agent_id)` cancels the asyncio.Task.
      4. `tasks()` returns a snapshot for the UI to render.

    The manager is event-emitting (via `task.events`) but not
    event-consuming — the UI polls on its existing tick, not via a
    subscribe.
    """

    def __init__(self, runner_fn: RunnerFn) -> None:
        # `runner_fn(task, parent_ctx)` is the per-subagent worker.
        # It runs the isolated AgentLoop and feeds events into the
        # task. Implementation supplied by the host app.
        self._runner = runner_fn
        self._tasks: dict[str, SubAgentTask] = {}
        # Order of submission so `tasks()` is stable.
        self._order: list[str] = []
        # Lock around state transitions so concurrent submit/cancel
        # don't race when promoting queued → running.
        self._lock = asyncio.Lock()

    # ---------- public API ----------

    def tasks(self) -> list[SubAgentTask]:
        """Snapshot of all known tasks in submission order."""
        return [self._tasks[i] for i in self._order if i in self._tasks]

    def get(self, agent_id: str) -> Optional[SubAgentTask]:
        return self._tasks.get(agent_id)

    def active_count(self) -> int:
        """How many tasks are currently running (excludes queued and
        terminal)."""
        return sum(
            1 for t in self._tasks.values()
            if t.status == SubAgentStatus.RUNNING
        )

    def queued_count(self) -> int:
        return sum(
            1 for t in self._tasks.values()
            if t.status == SubAgentStatus.QUEUED
        )

    def visible_tasks(self) -> list[SubAgentTask]:
        """Tasks the UI should render — everything that hasn't been
        explicitly dismissed. Currently same as `tasks()` but split
        out so a future `dismiss(agent_id)` can hide terminal cards."""
        return self.tasks()

    async def submit(
        self,
        *,
        name: str,
        prompt: str,
        subagent_type: str,
        parent_session_id: str,
        parent_depth: int,
        parent_ctx: Any,
    ) -> SubAgentTask:
        """Register a new subagent. Returns the SubAgentTask
        immediately. If under the concurrency cap, the task starts
        running in the background; otherwise it sits in queued.

        Depth check: if `parent_depth >= MAX_DEPTH`, the task is
        born in failed status — a subagent cannot spawn another.
        """
        agent_id = uuid.uuid4().hex[:8]
        task = SubAgentTask(
            id=agent_id,
            name=name,
            subagent_type=subagent_type,
            prompt=prompt,
            parent_session_id=parent_session_id,
            depth=parent_depth + 1,
        )
        async with self._lock:
            self._tasks[agent_id] = task
            self._order.append(agent_id)
            # Reject nested-spawn attempts immediately. The model
            # cannot recurse into more subagents from inside one.
            if task.depth > MAX_DEPTH:
                task.status = SubAgentStatus.FAILED
                task.error = (
                    f"subagent nesting depth exceeded "
                    f"(depth={task.depth}, max={MAX_DEPTH})"
                )
                task.started_at = time.monotonic()
                task.finished_at = task.started_at
                return task
            # Promote to running if there's headroom; otherwise
            # leave queued. `_drain_queue` runs after each finish.
            if self.active_count() < _max_parallel():
                self._spawn(task, parent_ctx)
        return task

    async def cancel(self, agent_id: str) -> bool:
        """Cancel a running or queued task. Returns True if a
        transition happened, False otherwise."""
        task = self._tasks.get(agent_id)
        if task is None or task.is_terminal():
            return False
        if task.status == SubAgentStatus.QUEUED:
            # Wasn't running yet — flip to cancelled directly.
            task.status = SubAgentStatus.CANCELLED
            task.error = "cancelled before start"
            task.started_at = task.started_at or time.monotonic()
            task.finished_at = time.monotonic()
            return True
        # Running — cancel the asyncio.Task. The runner's
        # `except CancelledError` branch finalizes status.
        if task.task_handle is not None and not task.task_handle.done():
            task.task_handle.cancel()
            return True
        return False

    async def cancel_all(self) -> int:
        """Cancel every non-terminal task. Returns the count
        cancelled. Intended for parent-Esc and app-shutdown paths."""
        n = 0
        for tid in list(self._tasks.keys()):
            if await self.cancel(tid):
                n += 1
        return n

    def emit_event(
        self,
        agent_id: str,
        kind: str,
        text: str,
    ) -> None:
        """Append a one-line event record to the subagent's
        in-memory transcript. Used by the runner to populate the
        expanded-view body. NEVER routes to parent's chat-log."""
        task = self._tasks.get(agent_id)
        if task is None:
            return
        # Cap the events list so a runaway subagent doesn't blow
        # memory. 400 events × ~200 chars ≈ 80KB ceiling.
        if len(task.events) >= 400:
            return
        task.events.append(SubAgentEvent(
            ts=time.monotonic(), kind=kind, text=text[:200],
        ))

    # ---------- internals ----------

    def _spawn(self, task: SubAgentTask, parent_ctx: Any) -> None:
        """Promote a task to running and create its asyncio.Task.
        Caller must hold `self._lock`."""
        task.status = SubAgentStatus.RUNNING
        task.started_at = time.monotonic()
        # Wrap in wait_for to enforce the timeout. The runner
        # handles its own cleanup on CancelledError, so wait_for's
        # cancel-on-timeout reaches the runner cleanly.
        task.task_handle = asyncio.create_task(
            self._run_with_finalization(task, parent_ctx),
            name=f"prometheus-subagent-{task.id}",
        )

    async def _run_with_finalization(
        self, task: SubAgentTask, parent_ctx: Any,
    ) -> None:
        """Wraps the runner with timeout, finalization, and
        queue-draining. Always lands the task in a terminal state."""
        try:
            try:
                result = await asyncio.wait_for(
                    self._runner(task, parent_ctx),
                    timeout=_timeout_s(),
                )
            except asyncio.TimeoutError:
                task.status = SubAgentStatus.TIMEOUT
                task.error = f"timed out after {_timeout_s():.0f}s"
                return
            except asyncio.CancelledError:
                # Honor cooperative cancel — runner's own
                # CancelledError handler may have already set
                # status; otherwise mark cancelled here.
                if not task.is_terminal():
                    task.status = SubAgentStatus.CANCELLED
                    task.error = "cancelled"
                raise
            except Exception as e:
                task.status = SubAgentStatus.FAILED
                task.error = f"{type(e).__name__}: {e}"
                return
            # Runner returned cleanly — completed.
            task.status = SubAgentStatus.COMPLETED
            task.result = result
        finally:
            task.finished_at = time.monotonic()
            # Round 176: fire SubagentStop hook on every termination
            # path (success / failure / cancel). Non-blocking — exit
            # code is ignored. Best-effort: hook system failure must
            # never deadlock the queue drain.
            try:
                from prometheus.safety.hooks import load_hooks, run_event
                workdir = (
                    getattr(parent_ctx, "workdir", None)
                    if parent_ctx is not None else None
                )
                if workdir is not None:
                    hooks = load_hooks(workdir)
                    run_event(
                        hooks, "SubagentStop",
                        matcher_value=getattr(task, "subagent_type", "") or "",
                        payload={
                            "subagent_id": task.id,
                            "subagent_type": getattr(task, "subagent_type", ""),
                            "name": getattr(task, "name", ""),
                            "status": str(task.status),
                            "error": task.error or "",
                            "duration_s": (
                                task.finished_at - task.started_at
                                if task.started_at and task.finished_at
                                else 0.0
                            ),
                        },
                    )
            except Exception:
                pass
            # Drain the queue: try to promote one queued task per
            # finish. Done outside the lock-held submit path so we
            # don't reenter; reacquire here.
            await self._drain_queue(parent_ctx)

    async def _drain_queue(self, parent_ctx: Any) -> None:
        """Promote queued tasks while there's headroom. Called
        after every running task finishes."""
        async with self._lock:
            while self.active_count() < _max_parallel():
                next_queued = next(
                    (t for t in self.tasks()
                     if t.status == SubAgentStatus.QUEUED),
                    None,
                )
                if next_queued is None:
                    break
                self._spawn(next_queued, parent_ctx)
