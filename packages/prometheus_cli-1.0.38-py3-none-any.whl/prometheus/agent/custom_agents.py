"""Round-49: custom subagent loader.

Discovers `*.md` files under `.prometheus/agents/` (project) and
`~/.prometheus/agents/` (user-global), parses YAML-like frontmatter,
and exposes them as named subagent types the model can invoke via the
`task` tool.

File format (matches Claude Code's `.claude/agents/<name>.md`):

    ---
    name: code-reviewer
    description: Reviews code for quality and best practices
    tools: read_file, grep, search_code
    disallowed_tools: write_file, edit_file, run_bash
    model: planner
    permission_mode: plan
    ---
    You are a thorough code reviewer. Look for:
    - Obvious bugs and edge cases
    - Style/consistency issues
    - Missing error handling
    Report findings as a markdown checklist.

The body is the system-prompt overlay applied on top of the standard
PrometheUS system prompt. Frontmatter fields are all optional.

Project agents shadow user agents with the same name (so a repo can
override a user's default `code-reviewer` for its specific style).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable


_FRONTMATTER_RE = re.compile(
    r"\A---\s*\n(?P<front>.*?)\n---\s*\n(?P<body>.*)\Z",
    re.DOTALL,
)


@dataclass
class CustomAgent:
    """One agent loaded from a `.md` file."""
    name: str
    description: str = ""
    body: str = ""                 # system-prompt overlay
    tools: list[str] | None = None  # None = inherit all; [] = empty
    disallowed_tools: list[str] = field(default_factory=list)
    model: str = ""                # "" = inherit; else "coder"|"planner"|"fast"
    permission_mode: str = ""      # "" = inherit; else default|acceptEdits|plan|skipAll
    source: str = ""               # absolute path the file was loaded from
    scope: str = "user"            # "project" or "user" — for /agents listing


def _parse_csv(value: str) -> list[str]:
    return [t.strip() for t in value.split(",") if t.strip()]


def _parse_frontmatter(text: str) -> tuple[dict[str, str], str]:
    """Return (frontmatter_dict, body). Empty front when no `---` fence."""
    m = _FRONTMATTER_RE.match(text)
    if not m:
        return {}, text
    front_raw = m.group("front")
    body = m.group("body").strip()
    fm: dict[str, str] = {}
    for line in front_raw.splitlines():
        line = line.rstrip()
        if not line or line.lstrip().startswith("#"):
            continue
        if ":" not in line:
            continue
        key, _, val = line.partition(":")
        key = key.strip().lower().replace("-", "_")
        val = val.strip().strip("'").strip('"')
        if key:
            fm[key] = val
    return fm, body


def _load_one(path: Path, scope: str) -> CustomAgent | None:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return None
    fm, body = _parse_frontmatter(text)
    name = (fm.get("name") or path.stem).strip()
    if not name:
        return None
    # Validate name shape — only alphanumeric / dash / underscore so the
    # model can't pass through whitespace or path traversal in
    # subagent_type.
    if not re.match(r"^[A-Za-z0-9_\-]{1,64}$", name):
        return None
    tools_raw = fm.get("tools")
    tools = _parse_csv(tools_raw) if tools_raw else None
    pm = (fm.get("permission_mode") or "").strip()
    if pm and pm not in ("default", "acceptEdits", "plan", "skipAll"):
        pm = ""  # silently drop bad values
    return CustomAgent(
        name=name,
        description=fm.get("description", "").strip(),
        body=body,
        tools=tools,
        disallowed_tools=_parse_csv(fm.get("disallowed_tools", "")),
        model=fm.get("model", "").strip(),
        permission_mode=pm,
        source=str(path),
        scope=scope,
    )


def discover(workdir: Path) -> dict[str, CustomAgent]:
    """Load every `.md` agent definition. Project shadows user.

    Round 178: also walks `.claude/agents/` (Claude Code's
    documented path) so a user migrating from CC keeps every
    custom subagent definition without renaming directories.
    `.prometheus/agents/` takes precedence at the same scope when
    both define the same agent name.

    Returns a name → CustomAgent mapping. Bad files are silently
    skipped (logged) — never crashes the agent loop.
    """
    found: dict[str, CustomAgent] = {}
    locations: list[tuple[str, Path]] = []
    try:
        # CC convention first, native second — second overwrites
        # on name collision, so Prometheus dirs win at same scope.
        locations.append(("user", Path.home() / ".claude" / "agents"))
        locations.append(("user", Path.home() / ".prometheus" / "agents"))
    except (OSError, RuntimeError):
        pass
    locations.append(("project", workdir / ".claude" / "agents"))
    locations.append(("project", workdir / ".prometheus" / "agents"))
    for scope, base in locations:
        if not base.exists() or not base.is_dir():
            continue
        for f in sorted(base.glob("*.md")):
            agent = _load_one(f, scope)
            if agent is None:
                continue
            # Project scope overrides user scope on name collision.
            existing = found.get(agent.name)
            if existing and existing.scope == "project" and scope == "user":
                continue
            found[agent.name] = agent
    return found


def filter_tool_set(
    available_tools: Iterable[str],
    agent: CustomAgent,
) -> list[str]:
    """Apply tools allowlist + disallowed_tools denylist to tool names."""
    avail = list(available_tools)
    if agent.tools is not None:
        allow = {t.strip().lower() for t in agent.tools}
        avail = [t for t in avail if t.lower() in allow]
    if agent.disallowed_tools:
        deny = {t.strip().lower() for t in agent.disallowed_tools}
        avail = [t for t in avail if t.lower() not in deny]
    return avail
