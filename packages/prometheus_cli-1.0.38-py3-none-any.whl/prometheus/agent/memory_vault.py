"""Round 102 (Phase 5): Memory Vault — persistent knowledge store.

PrometheUS uses a pure-filesystem memory system (Markdown + YAML
frontmatter) so memories work with Git workflows and stay
human-readable.

Four memory types:

  * `user`      — personal preferences, coding style
  * `feedback`  — what worked, what didn't
  * `project`   — project-specific patterns, architecture notes
  * `reference` — external API specs, design docs

Two scopes:

  * `private` — `~/.prometheus/memory/` (per-user)
  * `project` — `.prometheus/memory/` (committed with the repo)

Each memory file:

    ---
    name: prefer-async-postgres
    description: One-line summary used at lookup time.
    type: project       # user | feedback | project | reference
    source: project     # private | project
    ---
    Body: full memory text. Markdown.

Staleness: each file's mtimeMs is exposed; reads older than
`STALE_AFTER_DAYS` (default 90) carry a `stale=True` flag so the
caller can render a `<system-reminder>` warning.
"""
from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


VALID_TYPES = ("user", "feedback", "project", "reference")
STALE_AFTER_DAYS = int(os.environ.get(
    "PROMETHEUS_MEMORY_STALE_DAYS", "90",
))


@dataclass
class Memory:
    """One discovered memory file."""
    name: str
    description: str
    type: str
    body: str
    path: Path
    scope: str = "private"      # `private` | `project`
    mtime_s: float = 0.0

    @property
    def is_stale(self) -> bool:
        if self.mtime_s == 0:
            return False
        age_days = (time.time() - self.mtime_s) / 86400.0
        return age_days > STALE_AFTER_DAYS

    def stale_warning(self) -> str:
        if not self.is_stale:
            return ""
        age_days = int((time.time() - self.mtime_s) / 86400.0)
        return (
            f"<system-reminder>Memory '{self.name}' is {age_days} days "
            "old. Verify the facts inside against the current code "
            "before relying on them.</system-reminder>"
        )


def _parse_memory_file(path: Path, *, scope: str) -> Optional[Memory]:
    try:
        raw = path.read_text(encoding="utf-8", errors="replace")
        st = path.stat()
    except OSError:
        return None
    from prometheus.agent.aptitudes import _parse_frontmatter
    fm, body = _parse_frontmatter(raw)
    name = fm.get("name") or path.stem
    type_ = fm.get("type", "project")
    if type_ not in VALID_TYPES:
        type_ = "project"
    return Memory(
        name=name[:64],
        description=(fm.get("description") or "").strip()[:200],
        type=type_,
        body=body.strip()[:8000],
        path=path,
        scope=scope,
        mtime_s=st.st_mtime,
    )


def _scope_paths(workdir: Path) -> list[tuple[Path, str]]:
    """Return (memory_dir, scope) tuples in priority order."""
    out: list[tuple[Path, str]] = []
    proj = workdir / ".prometheus" / "memory"
    if proj.exists() and proj.is_dir():
        out.append((proj, "project"))
    user = Path.home() / ".prometheus" / "memory"
    if user.exists() and user.is_dir():
        out.append((user, "private"))
    return out


def discover_memories(workdir: Path) -> list[Memory]:
    """Walk all scopes for `.md` files. Project entries take
    precedence in deduplication."""
    out: list[Memory] = []
    seen: set[str] = set()
    for root, scope in _scope_paths(workdir):
        try:
            for p in sorted(root.glob("*.md")):
                m = _parse_memory_file(p, scope=scope)
                if m is None or m.name in seen:
                    continue
                seen.add(m.name)
                out.append(m)
        except OSError:
            continue
    return out


def get_memory(workdir: Path, name: str) -> Optional[Memory]:
    for m in discover_memories(workdir):
        if m.name == name:
            return m
    return None


# ---------- write API ----------


def save_memory(
    workdir: Path,
    *,
    name: str,
    description: str,
    type_: str = "project",
    body: str = "",
    scope: str = "private",
) -> Memory:
    """Write a memory file. Returns the freshly-loaded Memory."""
    if type_ not in VALID_TYPES:
        raise ValueError(f"invalid memory type: {type_}")
    if scope not in ("private", "project"):
        raise ValueError(f"invalid scope: {scope}")
    if scope == "project":
        target_dir = workdir / ".prometheus" / "memory"
    else:
        target_dir = Path.home() / ".prometheus" / "memory"
    target_dir.mkdir(parents=True, exist_ok=True)
    safe_name = "".join(c if c.isalnum() or c in "-_" else "-" for c in name)
    path = target_dir / f"{safe_name}.md"
    fm_lines = [
        "---",
        f"name: {name}",
        f"description: {description}",
        f"type: {type_}",
        f"source: {scope}",
        "---",
        "",
        body.strip(),
        "",
    ]
    path.write_text("\n".join(fm_lines), encoding="utf-8")
    return _parse_memory_file(path, scope=scope) or Memory(
        name=name, description=description, type=type_,
        body=body, path=path, scope=scope, mtime_s=time.time(),
    )


def remove_memory(workdir: Path, name: str) -> bool:
    m = get_memory(workdir, name)
    if m is None:
        return False
    try:
        m.path.unlink()
    except OSError:
        return False
    return True


# ---------- prompt block ----------


def render_memory_block(
    memories: list[Memory], *, max_total_bytes: int = 8_000,
) -> str:
    """Format memories for system-prompt injection. Stale ones
    carry a leading warning."""
    if not memories:
        return ""
    parts: list[str] = ["", "RELEVANT MEMORIES:"]
    used = 0
    for m in memories:
        warning = m.stale_warning()
        chunk = ""
        if warning:
            chunk += warning + "\n"
        chunk += f"\n## {m.name} [{m.type}/{m.scope}]\n"
        if m.description:
            chunk += f"{m.description}\n\n"
        chunk += m.body + "\n"
        if used + len(chunk) > max_total_bytes:
            parts.append(
                f"[…{len(memories) - len(parts) + 2} more memories truncated]"
            )
            break
        parts.append(chunk)
        used += len(chunk)
    return "\n".join(parts)
