"""Round 144-final: regex-based frustration detector.

Scans user messages for frustration signals and returns a
score with a list of matched signals. The agent loop reads
`should_de_escalate()` before composing its next reply.

Default: enabled. Disable via
`PROMETHEUS_FRUSTRATION_DETECTION=0`.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import Optional


_TRUTHY = ("1", "true", "yes", "on")
_FALSY = ("0", "false", "no", "off")


def frustration_detection_enabled() -> bool:
    """Round 144-final: default ON; disable with =0."""
    raw = os.environ.get(
        "PROMETHEUS_FRUSTRATION_DETECTION", "",
    ).strip().lower()
    if raw in _FALSY:
        return False
    return True


# ---------- signal patterns ----------


_PATTERNS: list[tuple[str, re.Pattern[str], int]] = [
    # (label, regex, weight)
    ("explicit_failure",
     re.compile(r"\b(?:doesn'?t\s+work|isn'?t\s+working|broken|busted|borked)\b", re.I),
     3),
    ("wtf",
     re.compile(r"\b(?:wtf|wth|tf)\b", re.I),
     3),
    ("curse_strong",
     re.compile(r"\b(?:fuck|fucking|fucked|shit|shitty|bullshit|damn|dammit|hell)\b", re.I),
     3),
    ("complaint",
     re.compile(r"\b(?:stupid|idiotic|useless|garbage|terrible|awful)\b", re.I),
     2),
    ("repeated_no",
     re.compile(r"\b(?:no\s+){2,}|\bnope+\b", re.I),
     2),
    ("escalating_punct",
     re.compile(r"[!?]{3,}|[?!][?!]+"),
     1),
    ("yelling",
     re.compile(r"\b[A-Z]{4,}\b"),
     1),
    ("again",
     re.compile(r"\b(?:again|still|once\s+more)\b.*\b(?:fail|broken|wrong|error)\b", re.I),
     2),
    ("ugh",
     re.compile(r"\b(?:ugh+|sigh|argh+|gah)\b", re.I),
     1),
    ("repeated_same_question",
     re.compile(r"\bI(?:'ve|\s+have)\s+(?:already|told\s+you)\b", re.I),
     2),
    ("overreach_complaint",
     re.compile(r"\bnot\s+what\s+I\s+(?:asked|wanted|said)\b", re.I),
     3),
]


# Threshold scores.
DE_ESCALATE_SCORE = 2       # acknowledge frustration
SLOW_DOWN_SCORE = 5         # offer to slow down + alternatives


# ---------- detection ----------


@dataclass
class FrustrationSignal:
    label: str
    matched_text: str
    weight: int


@dataclass
class FrustrationReading:
    score: int = 0
    signals: list[FrustrationSignal] = field(default_factory=list)
    text_length: int = 0

    @property
    def detected(self) -> bool:
        return self.score >= DE_ESCALATE_SCORE

    @property
    def severe(self) -> bool:
        return self.score >= SLOW_DOWN_SCORE


def detect(text: str) -> FrustrationReading:
    """Round 144-final: scan a user message. Empty / whitespace
    inputs return zero-score readings."""
    reading = FrustrationReading(text_length=len(text or ""))
    if not text or not text.strip():
        return reading
    for label, rx, weight in _PATTERNS:
        for m in rx.finditer(text):
            reading.signals.append(FrustrationSignal(
                label=label,
                matched_text=m.group(0)[:40],
                weight=weight,
            ))
            reading.score += weight
    return reading


def should_de_escalate(text: str) -> bool:
    """Round 144-final: convenience predicate for the agent
    loop. Honors the env gate."""
    if not frustration_detection_enabled():
        return False
    return detect(text).detected


def acknowledgement_for(reading: FrustrationReading) -> str:
    """Round 144-final: build a short acknowledgement the
    agent prepends to its next reply when frustration is
    detected. Returns empty when not detected.

    The agent loop's system-prompt builder takes the value
    and treats it as a *behaviour hint* rather than a literal
    string to copy — so tone stays consistent with the
    current output style."""
    if not reading.detected:
        return ""
    if reading.severe:
        return (
            "User is visibly frustrated. Acknowledge this "
            "explicitly in one sentence. Offer to back up and "
            "try a different angle. Don't restate the previous "
            "approach."
        )
    return (
        "User is showing frustration signals. Lead with a brief "
        "acknowledgement, then propose a concrete next step."
    )


def render_reading(reading: FrustrationReading) -> str:
    if not reading.signals:
        return "frustration: none detected"
    out: list[str] = [f"frustration score: {reading.score}"]
    for s in reading.signals:
        out.append(
            f"  • {s.label:24s}  +{s.weight}  {s.matched_text!r}"
        )
    return "\n".join(out)
