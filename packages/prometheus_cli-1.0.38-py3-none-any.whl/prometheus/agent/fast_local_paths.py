"""R236: deterministic local fast paths — answer simple factual
prompts without any LLM round-trip.

Why this exists:
  Live screenshot timing on `openrouter/free`:
    "what is the time in NYC?"
    → 175 seconds wall-clock (R235 acceptance smoke).
    → ~95% of that is upstream model first-token latency on a free-tier
      slug; Prometheus's PowerShell tool itself runs in 0.3s.
  For simple factual prompts where Prometheus already knows the
  exact tool to call, waiting on the model to "decide" to call it is
  pure waste. R236 routes these directly to the deterministic
  resolver — model is never invoked. Result: ~1-2s end-to-end.

Scope is intentionally narrow:
  * Only prompts that match a strict pattern (must mention time +
    location-token; "what time is it in NYC?" matches; "any thoughts
    on time management?" does NOT).
  * Only known cities mapped to Windows TZ identifiers (matches the
    same map used by the receipt humanizer).
  * Only Windows for now — uses PowerShell `[System.TimeZoneInfo]::
    ConvertTimeFromUtc(...)`. Other platforms fall through to the
    model.
  * Anything we don't fast-path returns None — the agent loop
    proceeds normally.

The fast path emits the same shape of events the agent loop would
emit (tool_use + tool_result + final) so receipt rendering, audit
logs, and stream-json consumers see no surprises. The receipt label
goes through the same `_humanize_command_intent` humanizer we
already trust.

R236 is the right architectural answer to:
  * "Simple time question takes 1-2 minutes" (user feedback)
  * "Public CLI feels random" (model latency made every turn feel
    flaky)
  * "Should not wait on slow model if it can answer locally" (user
    direction R236)
"""
from __future__ import annotations

import asyncio
import platform
import re
from dataclasses import dataclass
from typing import Any, Optional


# City token → IANA Windows TZ name. Order matters — multi-word
# tokens first so "new york city" wins over "new york" wins over
# "york". Keys are lowercase for case-insensitive matching.
_CITY_TO_WIN_TZ: tuple[tuple[str, str, str], ...] = (
    # (token, display name, Windows TZ id)
    ("new york city",   "New York",      "Eastern Standard Time"),
    ("new york",        "New York",      "Eastern Standard Time"),
    ("nyc",             "NYC",           "Eastern Standard Time"),
    ("miami fl",        "Miami",         "Eastern Standard Time"),
    ("miami",           "Miami",         "Eastern Standard Time"),
    ("boston",          "Boston",        "Eastern Standard Time"),
    ("atlanta",         "Atlanta",       "Eastern Standard Time"),
    ("philadelphia",    "Philadelphia",  "Eastern Standard Time"),
    ("washington dc",   "Washington DC", "Eastern Standard Time"),
    ("toronto",         "Toronto",       "Eastern Standard Time"),
    ("orlando",         "Orlando",       "Eastern Standard Time"),
    ("chicago",         "Chicago",       "Central Standard Time"),
    ("houston",         "Houston",       "Central Standard Time"),
    ("dallas",          "Dallas",        "Central Standard Time"),
    ("austin",          "Austin",        "Central Standard Time"),
    ("minneapolis",     "Minneapolis",   "Central Standard Time"),
    ("nashville",       "Nashville",     "Central Standard Time"),
    ("new orleans",     "New Orleans",   "Central Standard Time"),
    ("kansas city",     "Kansas City",   "Central Standard Time"),
    ("denver",          "Denver",        "Mountain Standard Time"),
    ("phoenix",         "Phoenix",       "Mountain Standard Time"),
    ("salt lake city",  "Salt Lake City","Mountain Standard Time"),
    ("albuquerque",     "Albuquerque",   "Mountain Standard Time"),
    ("los angeles",     "Los Angeles",   "Pacific Standard Time"),
    ("san francisco",   "San Francisco", "Pacific Standard Time"),
    ("seattle",         "Seattle",       "Pacific Standard Time"),
    ("san diego",       "San Diego",     "Pacific Standard Time"),
    ("portland or",     "Portland",      "Pacific Standard Time"),
    ("portland",        "Portland",      "Pacific Standard Time"),
    ("las vegas",       "Las Vegas",     "Pacific Standard Time"),
    ("vegas",           "Las Vegas",     "Pacific Standard Time"),
    ("vancouver",       "Vancouver",     "Pacific Standard Time"),
    ("london",          "London",        "GMT Standard Time"),
    ("dublin",          "Dublin",        "GMT Standard Time"),
    ("edinburgh",       "Edinburgh",     "GMT Standard Time"),
    ("paris",           "Paris",         "W. Europe Standard Time"),
    ("berlin",          "Berlin",        "W. Europe Standard Time"),
    ("amsterdam",       "Amsterdam",     "W. Europe Standard Time"),
    ("madrid",          "Madrid",        "W. Europe Standard Time"),
    ("rome",            "Rome",          "W. Europe Standard Time"),
    ("zurich",          "Zurich",        "W. Europe Standard Time"),
    ("vienna",          "Vienna",        "W. Europe Standard Time"),
    ("tokyo",           "Tokyo",         "Tokyo Standard Time"),
    ("osaka",           "Osaka",         "Tokyo Standard Time"),
    ("kyoto",           "Kyoto",         "Tokyo Standard Time"),
    ("beijing",         "Beijing",       "China Standard Time"),
    ("shanghai",        "Shanghai",      "China Standard Time"),
    ("hong kong",       "Hong Kong",     "China Standard Time"),
    ("singapore",       "Singapore",     "China Standard Time"),
    ("mumbai",          "Mumbai",        "India Standard Time"),
    ("delhi",           "Delhi",         "India Standard Time"),
    ("bangalore",       "Bangalore",     "India Standard Time"),
    ("sydney",          "Sydney",        "AUS Eastern Standard Time"),
    ("melbourne",       "Melbourne",     "AUS Eastern Standard Time"),
)

# Windows TZ → short label (matches time_label.py).
_TZ_SHORT: dict[str, str] = {
    "Eastern Standard Time":   "Eastern",
    "Central Standard Time":   "Central",
    "Mountain Standard Time":  "Mountain",
    "Pacific Standard Time":   "Pacific",
    "GMT Standard Time":       "UK",
    "W. Europe Standard Time": "CET",
    "Tokyo Standard Time":     "JST",
    "China Standard Time":     "CST",
    "India Standard Time":     "IST",
    "AUS Eastern Standard Time": "AEST",
}

# Prompt must look like a time/date question. We require both:
#   * an interrogative tail (what / when / tell me)
#   * a time/date noun (time, clock, hour, date)
# This rejects "I had a great time in NYC" while accepting
# "what's the time in NYC?", "tell me the time in Tokyo".
_TIME_QUERY_RX = re.compile(
    r"\b(time|clock|hour|date|day|datetime)\b",
    re.IGNORECASE,
)
_INTERROGATIVE_RX = re.compile(
    r"\b(what|whats|what's|when|tell|give|show|right now|currently|now)\b",
    re.IGNORECASE,
)


@dataclass
class FastAnswer:
    """A deterministic local answer + the synthetic tool call that
    would produce it. Lets the agent loop emit the same event shapes
    a real LLM-driven turn would, so receipt rendering and audit
    logs see no surprises."""
    bash_command: str       # what we ran (powershell command body)
    tool_output: str        # the raw bash result
    final_text: str         # the labeled assistant reply
    receipt_label: str      # the human-readable receipt label
    duration_s: float       # wall-clock time for the local call


def _find_city(prompt_lower: str) -> Optional[tuple[str, str]]:
    """Return (display_name, win_tz) for the first matching city,
    or None if no city is in the prompt. Uses word-boundary check
    so "vegas" doesn't match "veggas" / "lasvegas" malformed text."""
    haystack = " " + prompt_lower + " "
    for token, display, tz in _CITY_TO_WIN_TZ:
        needle = " " + token + " "
        # Loose match — also accept terminal punctuation like '?' or '.'.
        for terminator in (" ", "?", ".", ",", "!", ";", ":"):
            if (token + terminator) in haystack[1:] or haystack.endswith(" " + token):
                return display, tz
        if needle in haystack:
            return display, tz
    return None


def looks_like_time_query(prompt: str) -> bool:
    """Pure-function classifier: does the prompt look like a
    time/date factual question we can answer locally?

    Conservative — we'd rather miss a fast-pathable prompt than
    fast-path something that needed the model. False positives
    would short-circuit a legitimate model turn."""
    if not prompt:
        return False
    p = prompt.strip()
    if len(p) > 200:
        return False  # not a simple factual question
    p_low = p.lower()
    if not _TIME_QUERY_RX.search(p_low):
        return False
    if not _INTERROGATIVE_RX.search(p_low):
        return False
    return True


def _build_powershell_command(win_tz: str) -> str:
    """The exact PowerShell expression the system prompt teaches the
    model to emit — kept identical so the receipt humanizer
    recognizes it and renders 'Checked time in <city>'."""
    return (
        "[System.TimeZoneInfo]::ConvertTimeFromUtc("
        "(Get-Date).ToUniversalTime(), "
        f"[System.TimeZoneInfo]::FindSystemTimeZoneById('{win_tz}'))"
    )


def _format_final_text(timestamp: str, display_city: str, win_tz: str) -> str:
    """Match the same shape `prometheus.agent.time_label.relabel_time_reply`
    produces — `<City>: <ts> (<TZ short>)`. Keeps the user's experience
    consistent whether we fast-path or the model produces the answer."""
    short = _TZ_SHORT.get(win_tz, win_tz.replace(" Standard Time", ""))
    return f"{display_city}: {timestamp.strip()} ({short})"


async def try_local_time_answer(prompt: str) -> Optional[FastAnswer]:
    """Attempt the local fast path. Returns a FastAnswer if all of:
      * platform is Windows (PowerShell available)
      * prompt matches the time-query classifier
      * a known city is named in the prompt
      * the PowerShell call succeeds in <5s
    Otherwise None — the agent loop should proceed normally.
    """
    if platform.system() != "Windows":
        return None
    if not looks_like_time_query(prompt):
        return None
    found = _find_city(prompt.lower())
    if not found:
        return None
    display_city, win_tz = found
    ps_cmd = _build_powershell_command(win_tz)
    # Run via shell auto-wrap so the receipt label generator sees
    # the same shape it would for a model-emitted call. We want the
    # raw PowerShell expression (not the wrap) in the bash_command
    # field so downstream receipt humanization fires.
    import time as _time
    t0 = _time.monotonic()
    try:
        wrapped = f'powershell.exe -NoProfile -Command "& {{ {ps_cmd} }}"'
        proc = await asyncio.create_subprocess_shell(
            wrapped,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        try:
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=5.0)
        except asyncio.TimeoutError:
            try:
                proc.kill()
            except Exception:
                pass
            return None
    except Exception:
        return None
    duration = _time.monotonic() - t0
    if proc.returncode != 0:
        return None
    output = stdout.decode("utf-8", "replace").strip()
    if not output:
        return None
    # Sanity-check shape — should be a single timestamp line like
    # "Saturday, May 9, 2026 8:30:00 PM". Anything else: bail.
    first_line = output.split("\n", 1)[0].strip()
    if len(first_line) < 10 or len(first_line) > 80:
        return None
    final_text = _format_final_text(first_line, display_city, win_tz)
    receipt_label = f"PowerShell · Checked time in {display_city}"
    return FastAnswer(
        bash_command=ps_cmd,
        tool_output=output,
        final_text=final_text,
        receipt_label=receipt_label,
        duration_s=duration,
    )


def looks_like_simple_local_factual(prompt: str) -> bool:
    """Public classifier — exposes whether a prompt is a candidate
    for ANY local fast path (currently just time queries; future
    rounds may add date / weather / version checks). Used by tests
    to assert the classifier keeps a stable contract."""
    return looks_like_time_query(prompt)
