"""Round 129: /btw — side question that doesn't pollute history.

A `/btw` reply is a one-shot, read-only sub-query against the
current conversation context. It:

  * Has no tool access.
  * Does NOT add to `agent.messages` (so future turns don't see
    the question or the answer).
  * Renders in a dim overlay block; dismisses on Esc/Space/Enter.
  * Works even while the main agent is mid-response.

Round 129 ships:
  * `BTWQuery` data model
  * `synthesize_answer(...)` — heuristic context lookup that
    works offline (no LLM needed for simple questions like
    "what's the last command I ran?")
  * `/btw` slash command that queues the synthesis + renders
    the answer
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class BTWQuery:
    question: str
    answer: str
    confidence: str = "heuristic"   # `heuristic` / `model`


# ---------- pattern-based heuristic answers ----------


_LAST_COMMAND_RX = re.compile(
    r"\b(last|previous|recent)\b.*\b(command|bash|shell)\b"
    r"|\b(command|bash|shell)\b.*\b(last|previous|recent)\b",
    re.IGNORECASE,
)
_LAST_FILE_RX = re.compile(
    r"\b(last|recent)\b.*\b(file|read|edit)\b"
    r"|\b(file|read|edit)\b.*\b(last|recent)\b",
    re.IGNORECASE,
)
_TOOL_COUNT_RX = re.compile(
    r"\b(how many|count)\b.*\b(tool|tools|tool calls)\b",
    re.IGNORECASE,
)
_DURATION_RX = re.compile(
    r"\b(how long|duration|time)\b",
    re.IGNORECASE,
)


def synthesize_answer(
    question: str,
    *,
    messages: list[dict[str, Any]],
    started_at: Optional[float] = None,
    last_assistant_text: str = "",
) -> str:
    """Round 129: pattern-based answers for the most common
    `/btw` queries — last command, last file, tool call count,
    session duration. Falls back to a generic note when the
    question doesn't match any known pattern."""
    q = question.strip()
    if not q:
        return "(empty question)"
    if _LAST_COMMAND_RX.search(q):
        return _last_command(messages) or (
            "no shell command found in this session yet."
        )
    if _LAST_FILE_RX.search(q):
        return _last_file(messages) or (
            "no file read or edit found in this session yet."
        )
    if _TOOL_COUNT_RX.search(q):
        n = sum(
            1 for m in messages
            if (m.get("role") or "").lower() == "tool"
        )
        return f"{n} tool call{'s' if n != 1 else ''} so far."
    if _DURATION_RX.search(q):
        if started_at is None:
            return "session start time isn't tracked."
        import time
        sec = int(max(0, time.time() - started_at))
        m = sec // 60
        s = sec % 60
        return (
            f"{m}m {s}s into this session."
            if m else f"{s}s into this session."
        )
    # Fallback — try to give the user something actionable.
    if last_assistant_text:
        head = last_assistant_text.splitlines()[0][:80]
        return (
            "I can answer simple session-context questions "
            "without a model call (last command, last file, "
            "tool count, session duration). For richer queries, "
            f"send the question to the main agent. Last reply was: "
            f"{head!r}"
        )
    return (
        "I can answer simple session-context questions without "
        "a model call (last command, last file, tool count, "
        "session duration). For richer queries, ask the main "
        "agent."
    )


def _last_command(messages: list[dict[str, Any]]) -> Optional[str]:
    """Walk back through assistant tool_calls to find the most
    recent run_bash invocation."""
    import json as _json
    for m in reversed(messages or []):
        if (m.get("role") or "").lower() != "assistant":
            continue
        for tc in (m.get("tool_calls") or []):
            fn = tc.get("function") or {}
            if fn.get("name") == "run_bash":
                try:
                    args = _json.loads(fn.get("arguments", "") or "{}")
                except (ValueError, TypeError):
                    args = {}
                cmd = str(args.get("command", "")).strip()
                if cmd:
                    return f"last shell command: `{cmd}`"
    return None


def _last_file(messages: list[dict[str, Any]]) -> Optional[str]:
    """Most-recent path arg in a Read/Edit/Write tool call."""
    import json as _json
    for m in reversed(messages or []):
        if (m.get("role") or "").lower() != "assistant":
            continue
        for tc in (m.get("tool_calls") or []):
            fn = tc.get("function") or {}
            name = fn.get("name", "")
            if name not in (
                "read_file", "edit_file", "write_file", "multi_edit",
            ):
                continue
            try:
                args = _json.loads(fn.get("arguments", "") or "{}")
            except (ValueError, TypeError):
                args = {}
            path = str(args.get("path", "")).strip()
            if path:
                return f"last file ({name}): `{path}`"
    return None
