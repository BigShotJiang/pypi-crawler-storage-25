"""Round 98: Promethean Aptitudes — extensible expertise packages.

An Aptitude is a self-contained markdown package that teaches PrometheUS
specialized knowledge. Aptitudes follow the Agent Skills open standard
(SKILL.md / APTITUDE.md), so existing Anthropic-format skill packages
work unchanged.

The full Aptitude frontmatter spec (per the Phase-1 brief):

    ---
    name: python-testing
    purpose: >-
      Run pytest suites, analyze test coverage,
      and fix failing tests in Python codebases.
    disable-model-invocation: false
    user-invocable: true
    context: default          # or "fork" for isolated subagent
    allowed-tools: ["Bash", "Read"]
    model: default
    effort: medium            # low | medium | high
    dependencies:
      - python>=3.8
      - pytest>=7
    triggers: [pytest, coverage, "test failures"]
    ---
    Markdown body — instructions, examples, patterns.
    Maximum recommended size: 5000 tokens / ~500 lines.

Three-tier progressive revelation:

    Tier 1 — Purpose statement only (~30-50 tokens per aptitude).
             Loaded at session startup as a lightweight catalogue
             the model consults to decide when to activate.

    Tier 2 — Full APTITUDE.md body. Loaded only when the current
             task matches the purpose / triggers, or the user
             explicitly invokes via `/aptitude <name>`.

    Tier 3 — Linked `scripts/`, `references/`, `assets/`.
             Discovered at parse time but NOT loaded into context
             until the model explicitly reads them via Read tool.

Discovery paths (highest precedence first):

  1. Project: <workdir>/.prometheus/aptitudes/<name>/APTITUDE.md
             or <workdir>/.prometheus/aptitudes/<name>.md (flat)
  2. Project: <workdir>/.prometheus/skills/*.md  (legacy Skills)
  3. User:    ~/.prometheus/aptitudes/<name>/APTITUDE.md
             or ~/.prometheus/aptitudes/<name>.md (flat)
  4. User:    ~/.prometheus/skills/*.md  (legacy Skills)
  5. Forge kit aptitudes (round-100; placeholder paths exposed).

Project-scoped paths are gated by Workspace Trust — same defense
as `.prometheus/hooks.json` and custom slash commands. The legacy
Skills loader (`prometheus/agent/skills.py`) remains unchanged so
existing skills continue to load.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


# ---------- caps ----------


MAX_BODY_BYTES = 6_000          # per-aptitude body cap when loaded into prompt
MAX_PER_TURN = 6                # cap so 50 matched aptitudes don't blow context
MAX_TOTAL_BYTES = 24_000        # total cap across all loaded aptitudes
PURPOSE_LINE_CAP = 200          # truncate long purpose strings


# ---------- dataclass ----------


@dataclass
class Aptitude:
    """One discovered Aptitude. Mirrors the APTITUDE.md frontmatter
    spec; falls back to legacy Skill fields when reading a SKILL.md
    or a `.prometheus/skills/*.md` file."""

    name: str
    purpose: str                                # Tier 1 catalogue copy
    body: str                                   # Tier 2 full instructions
    path: Path                                  # absolute path to source file
    triggers: tuple[str, ...] = ()              # case-insensitive substrings
    user_invocable: bool = True                 # `/aptitude <name>` allowed?
    disable_model_invocation: bool = False      # explicit-only activation?
    context: str = "default"                    # `default` | `fork`
    allowed_tools: tuple[str, ...] = ()         # tools auto-permitted while active
    model: str = "default"                      # `default` | model id override
    effort: str = "medium"                      # `low` | `medium` | `high`
    dependencies: tuple[str, ...] = ()          # external deps (pytest>=7 etc.)
    scripts_dir: Optional[Path] = None          # Tier 3 — exists?
    references_dir: Optional[Path] = None       # Tier 3 — exists?
    assets_dir: Optional[Path] = None           # Tier 3 — exists?
    source: str = "user"                        # `project` | `user` | `forge`

    # ---- helpers ----

    def matches(self, haystack: str) -> bool:
        """Tier 1 match — true when ANY trigger appears in `haystack`,
        case-insensitive substring. Aptitudes with no triggers are
        always-on (the author opted to keep it loaded every turn)."""
        if not self.triggers:
            return False
        low = haystack.lower()
        return any(t.lower() in low for t in self.triggers)

    @property
    def root_dir(self) -> Path:
        """Directory holding APTITUDE.md (for foldered packages) or
        the file's parent directory (for flat single-file form)."""
        return self.path.parent

    def short_purpose(self, n: int = 80) -> str:
        """One-line preview for `/aptitude` list output."""
        first = self.purpose.strip().splitlines()[0] if self.purpose else ""
        return first[:n] + ("…" if len(first) > n else "")

    def list_resources(self) -> dict[str, list[str]]:
        """Return a tier-3 resource manifest the model can read on
        demand. Empty dict when no resources were declared. Files
        listed are relative to `root_dir` so paths stay tidy."""
        out: dict[str, list[str]] = {}
        for label, dirp in (
            ("scripts", self.scripts_dir),
            ("references", self.references_dir),
            ("assets", self.assets_dir),
        ):
            if dirp is None or not dirp.exists() or not dirp.is_dir():
                continue
            try:
                files = sorted(
                    str(p.relative_to(self.root_dir).as_posix())
                    for p in dirp.rglob("*")
                    if p.is_file()
                )
            except (OSError, ValueError):
                files = []
            if files:
                out[label] = files[:50]
        return out


# ---------- frontmatter parser ----------


def _parse_frontmatter(text: str) -> tuple[dict[str, str], str]:
    """Cheap YAML-subset parser sufficient for SKILL.md / APTITUDE.md
    headers. Supports scalar `key: value` and list-shape
    `key: [a, b, c]` plus block-list:

        dependencies:
          - python>=3.8
          - pytest>=7

    Returns ({}, original_text) when no frontmatter delimiter is
    found — never raises. We avoid PyYAML to keep PrometheUS slim;
    aptitude headers are user-authored and small enough for a
    line-by-line walker."""
    if not text.startswith("---"):
        return {}, text
    rest = text[3:]
    end = rest.find("\n---")
    if end == -1:
        return {}, text
    fm_block = rest[:end].strip()
    body = rest[end + 4:].lstrip("\n")
    out: dict[str, str] = {}
    pending_list_key: Optional[str] = None
    pending_list: list[str] = []
    for raw in fm_block.splitlines():
        line = raw.rstrip()
        if not line or line.lstrip().startswith("#"):
            continue
        if pending_list_key is not None and line.lstrip().startswith("-"):
            item = line.lstrip()[1:].strip().strip('"').strip("'")
            if item:
                pending_list.append(item)
            continue
        if pending_list_key is not None:
            # End of block-list — flush it and process this line normally.
            out[pending_list_key] = ", ".join(pending_list)
            pending_list_key = None
            pending_list = []
        if ":" not in line:
            continue
        k, v = line.split(":", 1)
        key = k.strip().lower()
        val = v.strip()
        # Folded-scalar `>-` and similar — collapse to next-line's
        # value. Cheap form: just record the empty string and let the
        # next non-empty line populate it.
        if val in (">-", "|-", "|", ">"):
            out[key] = ""
            pending_list_key = None
            continue
        # Block-list start: `key:` with empty value.
        if not val:
            pending_list_key = key
            pending_list = []
            continue
        out[key] = val.strip('"').strip("'")
    if pending_list_key is not None:
        out[pending_list_key] = ", ".join(pending_list)
    return out, body


def _split_strings(raw: str) -> tuple[str, ...]:
    """Accept `[a, b, c]` (YAML list) or `a, b, c` (comma-sep)."""
    s = raw.strip()
    if s.startswith("[") and s.endswith("]"):
        s = s[1:-1]
    return tuple(
        part.strip().strip('"').strip("'")
        for part in s.split(",") if part.strip()
    )


def _truthy(s: str) -> bool:
    return str(s).strip().lower() in ("1", "true", "yes", "on")


# ---------- file loaders ----------


def _load_aptitude_file(
    path: Path, *, source: str,
) -> Aptitude | None:
    """Parse a single APTITUDE.md / SKILL.md / `.prometheus/skills/*.md`
    file into an Aptitude. Detects sibling `scripts/`, `references/`,
    `assets/` directories when the file lives inside a foldered
    package."""
    try:
        raw = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    fm, body = _parse_frontmatter(raw)
    # `purpose` is the canonical field; `description` is the Skills
    # legacy synonym. Read both so existing skills work unchanged.
    purpose = (
        fm.get("purpose")
        or fm.get("description")
        or ""
    )
    purpose = purpose[:PURPOSE_LINE_CAP * 4]  # generous headroom for body folds
    name = fm.get("name") or path.stem
    if path.name.upper() in ("APTITUDE.MD", "SKILL.MD"):
        # Foldered form — name defaults to the package directory name.
        name = fm.get("name") or path.parent.name
    triggers_raw = (
        fm.get("triggers") or fm.get("trigger") or ""
    )
    triggers = _split_strings(triggers_raw) if triggers_raw else ()
    body = body.strip()[:MAX_BODY_BYTES]
    # Subdirectory awareness — only meaningful when the file is a
    # foldered package. For flat .md files there's no scripts/
    # sibling, so root_dir.scripts() simply doesn't exist.
    root = path.parent
    scripts = root / "scripts"
    refs = root / "references"
    assets = root / "assets"
    return Aptitude(
        name=name[:64],
        purpose=purpose.strip(),
        body=body,
        path=path,
        triggers=triggers,
        user_invocable=_truthy(fm.get("user-invocable", "true"))
            or _truthy(fm.get("user_invocable", "true")),
        disable_model_invocation=_truthy(
            fm.get("disable-model-invocation", "false")
        ) or _truthy(fm.get("disable_model_invocation", "false")),
        context=fm.get("context", "default") or "default",
        allowed_tools=_split_strings(fm.get("allowed-tools") or fm.get("allowed_tools") or ""),
        model=fm.get("model", "default") or "default",
        effort=fm.get("effort", "medium") or "medium",
        dependencies=_split_strings(fm.get("dependencies", "")),
        scripts_dir=scripts if scripts.exists() and scripts.is_dir() else None,
        references_dir=refs if refs.exists() and refs.is_dir() else None,
        assets_dir=assets if assets.exists() and assets.is_dir() else None,
        source=source,
    )


# ---------- discovery ----------


def _iter_aptitude_paths(root: Path) -> list[Path]:
    """Walk `root` for aptitude files. Two shapes are supported:

      foldered:  root/<name>/APTITUDE.md  (or SKILL.md)
      flat:      root/<name>.md

    `root` itself does not need to exist; missing returns []."""
    out: list[Path] = []
    if not root.exists() or not root.is_dir():
        return out
    # Foldered packages first (canonical form).
    try:
        for entry in sorted(root.iterdir()):
            if not entry.is_dir():
                continue
            for fname in ("APTITUDE.md", "SKILL.md"):
                p = entry / fname
                if p.exists() and p.is_file():
                    out.append(p)
                    break
    except OSError:
        pass
    # Flat single-file packages.
    try:
        for entry in sorted(root.glob("*.md")):
            if entry.is_file():
                out.append(entry)
    except OSError:
        pass
    return out


def discover_aptitudes(workdir: Path) -> list[Aptitude]:
    """Find every loadable Aptitude across project + user scopes.

    Project-scoped paths require Workspace Trust. User-scoped paths
    always load — they're the user's own config, not influenced by
    a hostile repo. Same defense as the Skills discovery path
    (CVE-2025-59536 attack class).

    Round 128: bundled aptitudes (security-review / simplify /
    batch / debug) appear in the catalogue alongside on-disk
    aptitudes. Bundled entries have lowest precedence — a user-
    or project-authored aptitude with the same name overrides."""
    try:
        from prometheus.safety.trust import is_trusted
    except Exception:
        is_trusted = lambda _: False  # type: ignore
    out: list[Aptitude] = []
    seen: set[str] = set()
    # Build the path/source list in PRECEDENCE order. First-seen wins
    # in dedupe so project Aptitudes shadow user-global ones with the
    # same name.
    paths: list[tuple[Path, str]] = []
    if is_trusted(workdir):
        proj_aptitudes = workdir / ".prometheus" / "aptitudes"
        proj_skills = workdir / ".prometheus" / "skills"
        for p in _iter_aptitude_paths(proj_aptitudes):
            paths.append((p, "project"))
        for p in _iter_aptitude_paths(proj_skills):
            paths.append((p, "project"))
    user_aptitudes = Path.home() / ".prometheus" / "aptitudes"
    user_skills = Path.home() / ".prometheus" / "skills"
    for p in _iter_aptitude_paths(user_aptitudes):
        paths.append((p, "user"))
    for p in _iter_aptitude_paths(user_skills):
        paths.append((p, "user"))
    for path, source in paths:
        apt = _load_aptitude_file(path, source=source)
        if apt is None or apt.name in seen:
            continue
        seen.add(apt.name)
        out.append(apt)
    # Round 128: bundled aptitudes — lowest precedence.
    try:
        from prometheus.agent.bundled_skills import bundled_aptitudes
        for apt in bundled_aptitudes():
            if apt.name in seen:
                continue
            seen.add(apt.name)
            out.append(apt)
    except Exception:
        pass
    return out


def get_aptitude(workdir: Path, name: str) -> Aptitude | None:
    """Look up a single Aptitude by name. Convenience helper for
    `/aptitude <name>` and other explicit-invocation paths."""
    for a in discover_aptitudes(workdir):
        if a.name == name:
            return a
    return None


# ---------- catalogue + body rendering ----------


def render_catalogue(aptitudes: list[Aptitude]) -> str:
    """Tier-1 rendering: per-aptitude purpose-only line.

    The catalogue lands in the system prompt at session start so the
    model knows what's available without paying for full bodies. One
    line per aptitude keeps the budget tight (~50 tokens each).
    """
    if not aptitudes:
        return ""
    parts: list[str] = ["", "AVAILABLE APTITUDES (purpose-only catalogue):"]
    for a in aptitudes:
        if a.disable_model_invocation:
            # The model can't auto-trigger this one, so don't waste
            # context advertising it. The user can still call
            # `/aptitude <name>` to load it explicitly.
            continue
        parts.append(f"- {a.name}: {a.short_purpose(140)}")
    return "\n".join(parts) + "\n"


def select_relevant(
    aptitudes: list[Aptitude], prompt: str,
) -> list[Aptitude]:
    """Tier-2 selection: pick aptitudes whose triggers fire on this
    prompt (or always-on aptitudes with no triggers). Capped at
    `MAX_PER_TURN`."""
    matched: list[Aptitude] = []
    for a in aptitudes:
        if a.disable_model_invocation:
            continue
        if not a.triggers:
            # No triggers → always-on. Author opted in.
            matched.append(a)
        elif a.matches(prompt):
            matched.append(a)
    return matched[:MAX_PER_TURN]


def render_active_block(aptitudes: list[Aptitude]) -> str:
    """Tier-2 rendering: full body for activated aptitudes. Mirrors
    Skills's `render_skills_block` so callers can swap in safely."""
    if not aptitudes:
        return ""
    parts: list[str] = ["", "ACTIVE APTITUDES (loaded for this turn):"]
    used = 0
    for a in aptitudes:
        chunk = f"\n## {a.name}\n{a.purpose}\n\n{a.body}"
        # Tier 3: surface the resource manifest so the model knows
        # what's available to read on demand. We do NOT inline the
        # contents — the model fetches via Read tool when needed.
        resources = a.list_resources()
        if resources:
            chunk += "\n\nResources (read on demand):\n"
            for label, files in resources.items():
                chunk += f"- {label}/: {', '.join(files[:8])}"
                if len(files) > 8:
                    chunk += f" (+{len(files) - 8} more)"
                chunk += "\n"
        if used + len(chunk) > MAX_TOTAL_BYTES:
            parts.append(
                f"\n[…{len(aptitudes) - len(parts) + 2} more aptitudes truncated]"
            )
            break
        parts.append(chunk)
        used += len(chunk)
    return "\n".join(parts)
