"""Round 112: team-onboarding analyzer.

`/team-onboarding` walks the local PrometheUS configuration plus
the workdir and generates a markdown ramp-up guide for new team
members. The guide explains:

  * What languages / frameworks the project uses (from the
    Charter scanner).
  * Which Aptitudes and Cohorts the team has authored.
  * What slash commands have been used recently (from session
    history when available).
  * Project conventions surfaced by Charter sections + Rules.
  * Common gotchas.

The output is a markdown file the user can commit alongside the
Charter so future hires can read it on day one without consulting
their teammate.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional


def generate_onboarding_guide(workdir: Path) -> str:
    """Round 112: produce a markdown ramp-up guide.

    Aggregates:
      * Charter scan (round 98)
      * Aptitudes (round 98)
      * Cohorts (round 101)
      * Rules (round 109)
      * Sentinel hooks (round 99)
      * Forge kits (round 100)
    """
    sections: list[str] = []
    sections.append(f"# Onboarding guide — {workdir.name}\n")
    sections.append(
        "This guide is auto-generated from the project's PrometheUS "
        "configuration. It captures the conventions, tools, and "
        "workflows the team has codified so a new contributor can "
        "ramp up without a 1:1.\n"
    )

    # Charter scan.
    try:
        from prometheus.agent.charter_init import scan_workdir
        scan = scan_workdir(workdir)
        sections.append("## Stack\n")
        if scan.languages:
            sections.append(f"- Languages: {', '.join(scan.languages)}")
        if scan.frameworks:
            sections.append(
                f"- Frameworks/tools: {', '.join(scan.frameworks)}"
            )
        if scan.test_commands:
            sections.append(
                f"- Test commands: `{', '.join(scan.test_commands[:3])}`"
            )
        if scan.has_dockerfile:
            sections.append("- Containerized: yes (`Dockerfile`)")
        if scan.has_ci:
            sections.append("- CI configured")
        sections.append("")
    except Exception:
        pass

    # Aptitudes.
    try:
        from prometheus.agent.aptitudes import discover_aptitudes
        apts = discover_aptitudes(workdir)
        if apts:
            sections.append("## Aptitudes\n")
            sections.append(
                "These knowledge packages auto-load when their "
                "trigger keywords appear in your prompt. Read them "
                "to learn the team's coding patterns.\n"
            )
            for a in apts:
                sections.append(
                    f"- **{a.name}** — {a.short_purpose(80)}"
                )
                if a.triggers:
                    sections.append(
                        f"  - triggers: `{', '.join(a.triggers[:5])}`"
                    )
            sections.append("")
    except Exception:
        pass

    # Cohorts.
    try:
        from prometheus.agent.cohorts import discover_cohorts
        cohorts = discover_cohorts(workdir)
        if cohorts:
            sections.append("## Cohorts (specialist agents)\n")
            for c in cohorts:
                sections.append(
                    f"- **{c.name}** — {c.short_description(80)}"
                )
                if c.disallowed_tools:
                    sections.append(
                        f"  - disallowed tools: "
                        f"`{', '.join(c.disallowed_tools)}`"
                    )
            sections.append("")
    except Exception:
        pass

    # Rules.
    try:
        from prometheus.agent.rules_engine import discover_rules
        rules = discover_rules(workdir)
        if rules:
            sections.append("## Path-scoped rules\n")
            sections.append(
                "These rules auto-inject when you touch matching "
                "paths. Worth knowing about so you don't fight the "
                "patterns the team has set.\n"
            )
            for r in rules:
                sections.append(
                    f"- **{r.name}** — applies to "
                    f"`{', '.join(r.paths[:2])}`"
                )
                if r.description:
                    sections.append(f"  - {r.description[:80]}")
            sections.append("")
    except Exception:
        pass

    # Sentinel hooks.
    try:
        from prometheus.safety.sentinels import load_sentinels
        reg = load_sentinels(workdir)
        if reg.sentinels:
            sections.append("## Sentinel hooks\n")
            sections.append(
                "Automation that fires at lifecycle events. If a "
                "tool call gets blocked unexpectedly, one of these "
                "is probably why.\n"
            )
            for s in reg.sentinels:
                sections.append(
                    f"- {s.event.value} · {s.type.value} · "
                    f"matcher=`{s.matcher.pattern}`"
                )
            sections.append("")
    except Exception:
        pass

    # Forge kits.
    try:
        from prometheus.forge.registry import ForgeRegistry
        reg = ForgeRegistry(workdir)
        kits = reg.installed()
        if kits:
            sections.append("## Forge kits\n")
            for k in kits:
                state = "active" if k.active else "inactive"
                sections.append(
                    f"- **{k.name}** v{k.manifest.version} ({state})"
                )
                if k.manifest.description:
                    sections.append(f"  - {k.manifest.description[:80]}")
            sections.append("")
    except Exception:
        pass

    # Common workflows section.
    sections.append("## Common workflows\n")
    sections.append(
        "- `/help` — list every slash command\n"
        "- `/aptitude` — list aptitudes\n"
        "- `/cohorts` — list cohort agents\n"
        "- `/tasks` — see the shared work log\n"
        "- `/rewind` — checkpoint-restore (full / code / conversation)\n"
        "- `/permissions` — inspect permission mode + recently denied\n"
    )

    sections.append("---")
    sections.append(
        "_Generated by `/team-onboarding`. Re-run periodically to "
        "keep the guide in sync with project state._"
    )
    return "\n".join(sections) + "\n"
