"""Skills — markdown files the agent loads automatically when relevant.

A "skill" is a markdown file under `~/.prometheus/skills/` (user-global)
or `<workdir>/.prometheus/skills/` (project-local) with optional YAML
frontmatter:

    ---
    name: deploy-cf
    description: Deploy a Cloudflare Worker. Loaded when the user mentions
                 "cloudflare", "wrangler", or "cf worker".
    triggers: [cloudflare, wrangler, cf worker]
    user_invocable: false
    ---
    To deploy:
    1. wrangler deploy
    2. wait for the upload to complete
    3. visit the dashboard ...

The matcher walks the user prompt + recent history; a skill loads when
ANY of its triggers (case-insensitive substring match) appear. Loaded
skill bodies are injected into the system prompt under a SKILLS section
so the model has them at hand without burning context every turn.

Project-local skills are gated behind Workspace Trust — same defense as
.prometheus/hooks.json and custom slash commands. CVE-2025-59536 class.

Format inspired by the Anthropic Agent Skills open standard (SKILL.md
in claude.com/skills) so users can drop existing skills in unchanged.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


MAX_SKILL_BODY_BYTES = 6_000   # per-skill cap in the system prompt
MAX_SKILLS_PER_TURN = 6        # cap so 50 matched skills don't blow context
MAX_TOTAL_BYTES = 24_000       # total cap across all loaded skills


@dataclass
class Skill:
    name: str
    description: str
    triggers: tuple[str, ...]
    body: str
    path: Path
    user_invocable: bool = True

    def matches(self, haystack: str) -> bool:
        if not self.triggers:
            return False
        low = haystack.lower()
        return any(t.lower() in low for t in self.triggers)


def _parse_frontmatter(text: str) -> tuple[dict[str, str], str]:
    """Cheap YAML-subset parser. Supports: scalar key: value, and
    list-shape `key: [a, b, c]`. Returns ({}, original_text) when no
    frontmatter delimiter is found — never raises. We don't pull in
    PyYAML because it's a hard dep we don't otherwise need; skill files
    are user-authored and small."""
    if not text.startswith("---"):
        return {}, text
    rest = text[3:]
    end = rest.find("\n---")
    if end == -1:
        return {}, text
    fm_block = rest[:end].strip()
    body = rest[end + 4:].lstrip("\n")
    out: dict[str, str] = {}
    for raw in fm_block.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            continue
        k, v = line.split(":", 1)
        out[k.strip().lower()] = v.strip().strip('"').strip("'")
    return out, body


def _split_triggers(raw: str) -> tuple[str, ...]:
    """Accept either `[a, b, c]` (YAML list) or `a, b, c` (comma-sep)."""
    s = raw.strip()
    if s.startswith("[") and s.endswith("]"):
        s = s[1:-1]
    return tuple(part.strip().strip('"').strip("'") for part in s.split(",") if part.strip())


def _load_skill_file(path: Path) -> Skill | None:
    try:
        raw = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    fm, body = _parse_frontmatter(raw)
    name = fm.get("name") or path.stem
    desc = fm.get("description") or ""
    triggers_raw = fm.get("triggers") or fm.get("trigger") or ""
    triggers = _split_triggers(triggers_raw) if triggers_raw else ()
    user_invocable = fm.get("user_invocable", "true").lower() != "false"
    body = body.strip()[:MAX_SKILL_BODY_BYTES]
    return Skill(
        name=name,
        description=desc[:200],
        triggers=triggers,
        body=body,
        path=path,
        user_invocable=user_invocable,
    )


def discover_skills(workdir: Path) -> list[Skill]:
    """Find every loadable skill from user + project directories.

    Project-local skills are only loaded when the workdir is trusted
    (Workspace Trust gate). User-level skills always load.

    Round 178: walks BOTH `.prometheus/skills/` and `.claude/skills/`
    so a user with existing Claude Code skills keeps them working.
    Per the Anthropic Agent Skills standard, the canonical filename
    inside a skill directory is `SKILL.md` — both the bare `*.md`
    file form (Prometheus native) and the directory-with-`SKILL.md`
    form (Anthropic standard) are accepted at every layer.
    """
    from prometheus.safety.trust import is_trusted
    out: list[Skill] = []
    seen: set[str] = set()  # dedupe by name; project wins over user

    def _gather(base: Path) -> list[Path]:
        """Round 178: a skills root contains either bare `*.md`
        files (one per skill) OR sub-directories each holding a
        `SKILL.md`. Yield both forms in deterministic order so
        load-order is reproducible."""
        if not base.exists() or not base.is_dir():
            return []
        results: list[Path] = []
        # Sub-directory form (Anthropic Agent Skills standard).
        for sub in sorted(base.iterdir()):
            if sub.is_dir():
                skill_md = sub / "SKILL.md"
                if skill_md.exists() and skill_md.is_file():
                    results.append(skill_md)
        # Bare-file form (Prometheus native + back-compat).
        results.extend(sorted(base.glob("*.md")))
        return results

    user_paths: list[Path] = []
    user_paths.extend(_gather(Path.home() / ".claude" / "skills"))
    user_paths.extend(_gather(Path.home() / ".prometheus" / "skills"))
    project_paths: list[Path] = []
    if is_trusted(workdir):
        project_paths.extend(_gather(workdir / ".claude" / "skills"))
        project_paths.extend(_gather(workdir / ".prometheus" / "skills"))
    # Project entries first so they take precedence in the dedupe step.
    paths = project_paths + user_paths
    for p in paths:
        skill = _load_skill_file(p)
        if skill is None or skill.name in seen:
            continue
        seen.add(skill.name)
        out.append(skill)
    return out


def select_relevant(skills: list[Skill], prompt: str) -> list[Skill]:
    """Pick the (up to MAX_SKILLS_PER_TURN) skills that match this prompt.

    A skill with NO triggers is treated as always-on (the user opted to
    keep it loaded). A skill with triggers is included only when the
    prompt mentions one of them (case-insensitive).
    """
    matched: list[Skill] = []
    for s in skills:
        if not s.triggers or s.matches(prompt):
            matched.append(s)
    return matched[:MAX_SKILLS_PER_TURN]


def render_skills_block(skills: list[Skill]) -> str:
    """Format the matched skills for injection into the system prompt."""
    if not skills:
        return ""
    parts: list[str] = ["", "RELEVANT SKILLS (loaded for this turn):"]
    used = 0
    for s in skills:
        chunk = f"\n## {s.name}\n{s.description}\n\n{s.body}"
        if used + len(chunk) > MAX_TOTAL_BYTES:
            parts.append(f"\n[…{len(skills) - len(parts) + 2} more skills truncated]")
            break
        parts.append(chunk)
        used += len(chunk)
    return "\n".join(parts)
