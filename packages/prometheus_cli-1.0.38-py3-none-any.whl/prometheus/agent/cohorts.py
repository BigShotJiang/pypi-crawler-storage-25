"""Round 101 (Phase 4): Cohort system.

A Cohort is a specialized autonomous sub-assistant with its own
system prompt, curated tool set, and isolated context window. The
existing SubAgent infrastructure (round 97) provides the runtime;
this module adds the Cohort definition layer and surfaces the
Phase-4 spec's terminology + features.

Two execution modes (per Phase-4 spec):

  * `LocalCohort`  — isolated subprocess spawned from the main
                     agent. Inherits parent permission_mode, has
                     its own context window, supports
                     `disallowed_tools`, `isolation: worktree`,
                     hierarchical cancellation.
  * `RemoteCohort` — agent executing in a remote environment via
                     MCP or HTTP. Round-101 supports the
                     definition; transport lands in round 102.

Cohort definition (`.prometheus/cohorts/<name>.md`):

    ---
    name: code-reviewer
    description: >-
      Specialized agent for thorough code review.
      Invoke when code changes need review.
    model: sonnet
    effort: high
    max_turns: 30
    disallowed_tools: [Write, Edit, Bash]
    skills: [security-auditor]
    memory: true
    background: true
    isolation: worktree
    ---
    Body — the cohort's system-prompt overlay.

This module is the definition + parsing layer. The dispatch layer
(turning a Cohort into a running SubAgentTask) is the existing
`prometheus/agent/subagent_manager.py`. Cohort cards in the UI
reuse `SubAgentCard` with the cohort name as the card title.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


MAX_BODY_BYTES = 6_000


@dataclass
class Cohort:
    """One discovered Cohort definition. Mirrors SubAgentTask
    but at the DEFINITION level — Cohorts are templates that get
    instantiated into SubAgentTasks at dispatch time."""
    name: str
    description: str
    body: str
    path: Path
    model: str = "default"
    effort: str = "medium"
    max_turns: int = 6
    disallowed_tools: tuple[str, ...] = ()
    allowed_tools: tuple[str, ...] = ()
    skills: tuple[str, ...] = ()
    memory: bool = False
    background: bool = False
    isolation: str = "default"     # `default` | `worktree`
    source: str = "user"           # `project` | `user` | `forge`

    @property
    def is_local(self) -> bool:
        """Round-101 scope: every Cohort is local. RemoteCohort
        (over MCP/HTTP) lands in round 102."""
        return True

    def short_description(self, n: int = 80) -> str:
        first = self.description.strip().splitlines()[0] if self.description else ""
        return first[:n] + ("…" if len(first) > n else "")


# ---------- frontmatter parser (reuses Aptitude's parser) ----------


def _parse_int(v: str, default: int) -> int:
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return default


def _parse_bool(v: str) -> bool:
    return str(v).strip().lower() in ("1", "true", "yes", "on")


def _split_strings(raw: str) -> tuple[str, ...]:
    s = raw.strip()
    if s.startswith("[") and s.endswith("]"):
        s = s[1:-1]
    return tuple(
        part.strip().strip('"').strip("'")
        for part in s.split(",") if part.strip()
    )


def _load_cohort_file(path: Path, *, source: str) -> Optional[Cohort]:
    try:
        raw = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    # Reuse Aptitude's frontmatter parser — same shape.
    from prometheus.agent.aptitudes import _parse_frontmatter
    fm, body = _parse_frontmatter(raw)
    name = fm.get("name") or path.stem
    return Cohort(
        name=name[:64],
        description=(fm.get("description") or fm.get("purpose") or "").strip(),
        body=body.strip()[:MAX_BODY_BYTES],
        path=path,
        model=fm.get("model", "default") or "default",
        effort=fm.get("effort", "medium") or "medium",
        max_turns=_parse_int(fm.get("max_turns", "6"), 6),
        disallowed_tools=_split_strings(
            fm.get("disallowed-tools") or fm.get("disallowed_tools") or ""
        ),
        allowed_tools=_split_strings(
            fm.get("allowed-tools") or fm.get("allowed_tools") or ""
        ),
        skills=_split_strings(fm.get("skills") or ""),
        memory=_parse_bool(fm.get("memory", "false")),
        background=_parse_bool(fm.get("background", "false")),
        isolation=fm.get("isolation", "default") or "default",
        source=source,
    )


def discover_cohorts(workdir: Path) -> list[Cohort]:
    """Walk project + user scopes for `.prometheus/cohorts/*.md`."""
    try:
        from prometheus.safety.trust import is_trusted
    except Exception:
        is_trusted = lambda _: False  # type: ignore
    out: list[Cohort] = []
    seen: set[str] = set()
    paths: list[tuple[Path, str]] = []
    if is_trusted(workdir):
        proj = workdir / ".prometheus" / "cohorts"
        if proj.exists() and proj.is_dir():
            for p in sorted(proj.glob("*.md")):
                paths.append((p, "project"))
    user = Path.home() / ".prometheus" / "cohorts"
    if user.exists() and user.is_dir():
        for p in sorted(user.glob("*.md")):
            paths.append((p, "user"))
    # Round-49 custom-agents path also discovers .prometheus/agents/*.md
    # files. Phase-4 brings them into the unified Cohort namespace.
    if is_trusted(workdir):
        proj_agents = workdir / ".prometheus" / "agents"
        if proj_agents.exists() and proj_agents.is_dir():
            for p in sorted(proj_agents.glob("*.md")):
                paths.append((p, "project"))
    user_agents = Path.home() / ".prometheus" / "agents"
    if user_agents.exists() and user_agents.is_dir():
        for p in sorted(user_agents.glob("*.md")):
            paths.append((p, "user"))
    for p, source in paths:
        c = _load_cohort_file(p, source=source)
        if c is None or c.name in seen:
            continue
        seen.add(c.name)
        out.append(c)
    return out


def get_cohort(workdir: Path, name: str) -> Optional[Cohort]:
    for c in discover_cohorts(workdir):
        if c.name == name:
            return c
    return None
