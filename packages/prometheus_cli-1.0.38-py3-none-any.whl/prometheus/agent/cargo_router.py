"""Round 161 — Hardening 6: CARGO-style confidence-aware model router.

Research (CARGO): predict the best model per prompt with an
embedding-based regressor, fall back to a binary classifier when
the regressor's confidence is low. ~76% top-1 accuracy on the
benchmark suite, 72-89% win rate against any single expert.

Production reality on free-tier OpenRouter: the embedding model
itself is the bottleneck. CARGO's full pipeline needs an embedding
endpoint plus a regressor model — we don't have either as a free,
quota-friendly resource. So this module ships the *deterministic
keyword-based* version of CARGO that the original paper compared
against in Table 4 — same shape (category classifier → per-category
expert), simpler classifier. Production deployments can swap the
classifier for an embedding model by implementing the same
`classify(prompt)` signature.

Categories + best free model per category come from the benchmark
data the user cited:

  code_generation → kimi-k2.5
  debugging       → deepseek-v3.2
  code_review     → glm-4.7
  long_context    → qwen-3.6-plus
  quick_task      → elephant-alpha
  explanation     → glm-4.7
  data_processing → deepseek-v3.2
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum


class TaskCategory(str, Enum):
    CODE_GENERATION = "code_generation"
    DEBUGGING = "debugging"
    CODE_REVIEW = "code_review"
    LONG_CONTEXT = "long_context"
    QUICK_TASK = "quick_task"
    EXPLANATION = "explanation"
    DATA_PROCESSING = "data_processing"
    GENERAL = "general"  # default when classifier is uncertain


# Best free model per category. These slugs are the OpenRouter
# free-tier identifiers Prometheus already recognises in
# prometheus/model_tiers.py — no new alias plumbing needed.
BEST_PER_CATEGORY: dict[TaskCategory, str] = {
    TaskCategory.CODE_GENERATION: "moonshotai/kimi-k2",
    TaskCategory.DEBUGGING: "deepseek/deepseek-chat-v3.1:free",
    TaskCategory.CODE_REVIEW: "z-ai/glm-4.6:free",
    TaskCategory.LONG_CONTEXT: "qwen/qwen3-235b-a22b:free",
    TaskCategory.QUICK_TASK: "google/gemini-flash-1.5:free",
    TaskCategory.EXPLANATION: "z-ai/glm-4.6:free",
    TaskCategory.DATA_PROCESSING: "deepseek/deepseek-chat-v3.1:free",
    TaskCategory.GENERAL: "deepseek/deepseek-chat-v3.1:free",
}


# Friendlier display names used in the activity rail.
DISPLAY_NAME: dict[str, str] = {
    "moonshotai/kimi-k2": "Kimi K2",
    "deepseek/deepseek-chat-v3.1:free": "DeepSeek V3.1",
    "z-ai/glm-4.6:free": "GLM-4.6",
    "qwen/qwen3-235b-a22b:free": "Qwen3 235B",
    "google/gemini-flash-1.5:free": "Gemini Flash 1.5",
}


# Keyword classifier. Each rule contributes votes for one category.
# Strong-intent verbs (`implement`, `write a function`, `from scratch`,
# `walk me through`, `bug`, `traceback`) are tagged with a 2x weight
# so they out-rank incidental data-shape keywords like `csv` / `json`.
# The category with the most votes wins; confidence = winning / total.
_RULES: tuple[tuple[TaskCategory, tuple[str, ...]], ...] = (
    (TaskCategory.CODE_GENERATION, (
        "implement::2", "build", "write a function::2", "create a class::2",
        "scaffold", "generate code::2", "boilerplate", "from scratch::2",
        "new module", "add a feature",
    )),
    (TaskCategory.DEBUGGING, (
        "bug", "broken", "crashes", "crash", "error", "exception",
        "traceback", "stack trace", "fix", "debug",
        "keyerror", "valueerror", "typeerror", "attributeerror",
    )),
    (TaskCategory.CODE_REVIEW, (
        "review", "pull request", "pr ", "code review", "audit",
        "look over", "check for issues", "lint", "best practice",
    )),
    (TaskCategory.LONG_CONTEXT, (
        "entire codebase", "across the project", "every file",
        "all files", "whole repo", "across modules", "summarize the architecture",
    )),
    (TaskCategory.QUICK_TASK, (
        "rename", "list ", "show me", "what is", "one-liner",
        "quick", "short", "simple",
    )),
    (TaskCategory.EXPLANATION, (
        "explain", "walk me through", "how does", "what does",
        "describe", "document", "summarize", "tell me about",
    )),
    (TaskCategory.DATA_PROCESSING, (
        "csv", "json", "parquet", "dataframe", "pandas", "pivot",
        "groupby", "aggregate", "etl", "transform",
    )),
)


@dataclass
class Routing:
    """The router's verdict for one prompt."""
    category: TaskCategory
    confidence: float           # 0..1
    chosen_model: str
    reason: str
    rail_label: str             # human-readable for the activity line
    used_default_fallback: bool = False
    candidates: dict[TaskCategory, int] = field(default_factory=dict)


def _parse_keyword(raw: str) -> tuple[str, int]:
    """Split `keyword::weight` into (keyword, weight). Default weight is 1."""
    if "::" in raw:
        kw, w = raw.split("::", 1)
        try:
            return kw.strip(), max(1, int(w))
        except ValueError:
            return kw.strip(), 1
    return raw, 1


def classify(prompt: str) -> tuple[TaskCategory, float, dict[TaskCategory, int]]:
    """Run the keyword classifier. Returns (category, confidence, votes).

    Each rule entry may carry a `keyword::N` weight; matching that
    keyword contributes N votes for the category. Strong intent verbs
    use this to out-rank incidental data-shape matches."""
    p = (prompt or "").lower()
    votes: dict[TaskCategory, int] = {}
    for cat, kws in _RULES:
        score = 0
        for raw in kws:
            kw, w = _parse_keyword(raw)
            if kw in p:
                score += w
        if score:
            votes[cat] = score
    if not votes:
        return TaskCategory.GENERAL, 0.0, {}
    total = sum(votes.values())
    cat, top = max(votes.items(), key=lambda kv: kv[1])
    confidence = top / total if total else 0.0
    return cat, confidence, votes


def route(
    prompt: str,
    *,
    default_model: str = "deepseek/deepseek-chat-v3.1:free",
    confidence_floor: float = 0.40,
) -> Routing:
    """Classify the prompt and pick the best model. When the
    classifier is uncertain (confidence < `confidence_floor`), fall
    back to `default_model`."""
    cat, conf, votes = classify(prompt)
    if cat is TaskCategory.GENERAL or conf < confidence_floor:
        chosen = default_model
        used_fallback = True
        reason = (
            f"classifier uncertain (confidence {conf:.0%}) — using "
            f"default model"
            if cat is not TaskCategory.GENERAL
            else "no category keywords matched — using default model"
        )
        rail_cat = TaskCategory.GENERAL
    else:
        chosen = BEST_PER_CATEGORY[cat]
        used_fallback = False
        reason = f"classified as {cat.value} ({conf:.0%} confidence)"
        rail_cat = cat
    rail_label = (
        f"✦ Routed to {DISPLAY_NAME.get(chosen, chosen)} "
        f"({rail_cat.value}, confidence {conf:.0%})"
    )
    return Routing(
        category=cat, confidence=conf, chosen_model=chosen,
        reason=reason, rail_label=rail_label,
        used_default_fallback=used_fallback, candidates=votes,
    )
