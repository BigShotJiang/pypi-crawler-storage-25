"""Round 111: Routines — scheduled autonomous agents.

A Routine is a markdown file under `.prometheus/routines/<name>.md`
that describes an agent run scheduled to fire on:

  * a cron expression  (`schedule:`),
  * a GitHub event     (`trigger: github_event`),
  * an HTTP webhook    (`trigger: api_call`),
  * a file change      (`trigger: file_changed`),
  * a manual run       (`/routine run <name>`).

When the routine fires, it spawns a fresh PrometheUS session,
runs the prompt, captures the transcript to `~/.prometheus/
routines/<name>/<run-id>.jsonl`, and exits.

Round 111 ships:

  * the data model (`Routine`, `RoutineRegistry`)
  * file-format parser
  * cron-expression parser (5-field standard cron)
  * `/routine create / list / run / delete` slash commands
  * a `prometheus-routined` daemon stub callable via
    `python -m prometheus.agent.routines`

The actual scheduling daemon spawns subprocesses; round 111
exposes the spawn API. A future polish round (post-117) wires
in OS-level service registration (systemd / Windows Task
Scheduler / launchd).

Frontmatter contract:

    ---
    name: nightly-deps-audit
    description: Run security audit + flag CVEs.
    schedule: "0 3 * * *"             # every night at 03:00
    trigger: schedule                 # schedule | github_event | api_call | manual
    prompt: |
      Run `pip-audit --strict` and email me the report.
    model: default
    permission_mode: plan
    ---
    Optional notes / context.

`schedule` is a 5-field standard cron expression. `trigger:
manual` makes the routine run-only via `/routine run`.
"""
from __future__ import annotations

import json
import re
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Optional


VALID_TRIGGERS = ("schedule", "github_event", "api_call", "manual", "file_changed")
VALID_PERMISSION_MODES = (
    "default", "acceptEdits", "plan", "skipAll", "auto",
)


# ---------- Routine dataclass ----------


@dataclass
class Routine:
    name: str
    description: str
    prompt: str
    schedule: str = ""        # 5-field cron; empty for non-schedule triggers
    trigger: str = "schedule"
    model: str = "default"
    permission_mode: str = "default"
    body: str = ""            # markdown notes after frontmatter
    path: Optional[Path] = None
    source: str = "user"

    def is_valid(self) -> tuple[bool, list[str]]:
        issues: list[str] = []
        if not self.name:
            issues.append("missing name")
        if not self.prompt.strip():
            issues.append("empty prompt")
        if self.trigger not in VALID_TRIGGERS:
            issues.append(f"invalid trigger {self.trigger!r}")
        if self.permission_mode not in VALID_PERMISSION_MODES:
            issues.append(f"invalid permission_mode {self.permission_mode!r}")
        if self.trigger == "schedule" and not self.schedule:
            issues.append("trigger=schedule but no `schedule:` cron expression")
        if self.schedule:
            try:
                parse_cron(self.schedule)
            except ValueError as e:
                issues.append(f"bad cron: {e}")
        return (len(issues) == 0, issues)


# ---------- 5-field cron parser ----------


@dataclass
class CronExpression:
    """Parsed 5-field cron: minute, hour, day-of-month, month,
    day-of-week. Each field is either a list of ints or `None`
    for `*` (any)."""
    minute: Optional[list[int]]
    hour: Optional[list[int]]
    day: Optional[list[int]]
    month: Optional[list[int]]
    weekday: Optional[list[int]]


def _parse_field(
    raw: str, *, lo: int, hi: int,
) -> Optional[list[int]]:
    """Parse one cron field. `*` → None. Otherwise comma-list of
    `n`, `lo-hi`, `n-m/k`, `*/k`."""
    raw = raw.strip()
    if raw == "*":
        return None
    out: set[int] = set()
    for piece in raw.split(","):
        piece = piece.strip()
        if not piece:
            continue
        # Step value: `*/k` or `lo-hi/k`.
        step = 1
        if "/" in piece:
            piece, sraw = piece.split("/", 1)
            try:
                step = int(sraw)
            except ValueError:
                raise ValueError(f"bad step in {piece!r}")
            if step < 1:
                raise ValueError(f"step must be ≥ 1: {piece!r}")
        if piece == "*" or piece == "":
            start, stop = lo, hi
        elif "-" in piece:
            a, b = piece.split("-", 1)
            try:
                start, stop = int(a), int(b)
            except ValueError:
                raise ValueError(f"bad range in {piece!r}")
        else:
            try:
                start = stop = int(piece)
            except ValueError:
                raise ValueError(f"bad value in {piece!r}")
        if start < lo or stop > hi or start > stop:
            raise ValueError(
                f"value out of range [{lo}-{hi}]: {piece!r}"
            )
        for v in range(start, stop + 1, step):
            out.add(v)
    return sorted(out)


def parse_cron(expr: str) -> CronExpression:
    """Round 111: parse a 5-field standard cron expression.
    Raises ValueError on malformed input."""
    fields = expr.split()
    if len(fields) != 5:
        raise ValueError(
            f"expected 5 fields (minute hour day month weekday), got {len(fields)}"
        )
    minute = _parse_field(fields[0], lo=0, hi=59)
    hour = _parse_field(fields[1], lo=0, hi=23)
    day = _parse_field(fields[2], lo=1, hi=31)
    month = _parse_field(fields[3], lo=1, hi=12)
    weekday = _parse_field(fields[4], lo=0, hi=6)
    return CronExpression(
        minute=minute, hour=hour, day=day,
        month=month, weekday=weekday,
    )


def cron_disabled() -> bool:
    """1.0.3 (CC v2.1.105 parity): kill-switch for scheduled cron
    jobs. When set truthy, `cron_matches` always returns False so
    no routine ever fires this session — useful to halt mid-session
    runaway routines without unloading them.

    Honours both Claude Code's name and the native prefix:
      - `CLAUDE_CODE_DISABLE_CRON`
      - `PROMETHEUS_DISABLE_CRON`
    """
    import os
    truthy = ("1", "true", "yes", "on")
    return (
        os.environ.get("PROMETHEUS_DISABLE_CRON", "").strip().lower() in truthy
        or os.environ.get(
            "CLAUDE_CODE_DISABLE_CRON", "",
        ).strip().lower() in truthy
    )


def cron_matches(expr: CronExpression, when: datetime) -> bool:
    """Return True iff `when` is a moment when `expr` would fire.

    1.0.3: short-circuits to False when `cron_disabled()` is set,
    so a routine config of fire-every-minute genuinely halts when
    the user sets `PROMETHEUS_DISABLE_CRON=1` mid-session.
    """
    if cron_disabled():
        return False
    if expr.minute is not None and when.minute not in expr.minute:
        return False
    if expr.hour is not None and when.hour not in expr.hour:
        return False
    if expr.day is not None and when.day not in expr.day:
        return False
    if expr.month is not None and when.month not in expr.month:
        return False
    # Python: Mon=0 .. Sun=6. Cron: Sun=0 .. Sat=6.
    cron_weekday = (when.weekday() + 1) % 7
    if expr.weekday is not None and cron_weekday not in expr.weekday:
        return False
    return True


# ---------- file format ----------


def _load_routine_file(path: Path, *, source: str) -> Optional[Routine]:
    try:
        raw = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    from prometheus.agent.aptitudes import _parse_frontmatter
    fm, body = _parse_frontmatter(raw)
    name = fm.get("name") or path.stem
    return Routine(
        name=name[:64],
        description=(fm.get("description") or "").strip()[:200],
        prompt=fm.get("prompt", "").strip(),
        schedule=fm.get("schedule", "").strip(),
        trigger=fm.get("trigger", "schedule").strip().lower() or "schedule",
        model=fm.get("model", "default") or "default",
        permission_mode=fm.get("permission_mode", "default") or "default",
        body=body.strip(),
        path=path,
        source=source,
    )


# ---------- registry ----------


@dataclass
class RoutineRegistry:
    workdir: Path

    @property
    def proj_dir(self) -> Path:
        return self.workdir / ".prometheus" / "routines"

    @property
    def user_dir(self) -> Path:
        return Path.home() / ".prometheus" / "routines"

    def list(self) -> list[Routine]:
        try:
            from prometheus.safety.trust import is_trusted
        except Exception:
            is_trusted = lambda _: False  # type: ignore
        out: list[Routine] = []
        seen: set[str] = set()
        if is_trusted(self.workdir) and self.proj_dir.exists():
            for p in sorted(self.proj_dir.glob("*.md")):
                r = _load_routine_file(p, source="project")
                if r and r.name not in seen:
                    seen.add(r.name)
                    out.append(r)
        if self.user_dir.exists():
            for p in sorted(self.user_dir.glob("*.md")):
                r = _load_routine_file(p, source="user")
                if r and r.name not in seen:
                    seen.add(r.name)
                    out.append(r)
        return out

    def get(self, name: str) -> Optional[Routine]:
        for r in self.list():
            if r.name == name:
                return r
        return None

    def create(
        self,
        *,
        name: str,
        description: str,
        prompt: str,
        schedule: str = "",
        trigger: str = "manual",
        model: str = "default",
        permission_mode: str = "default",
        scope: str = "user",
    ) -> tuple[Optional[Routine], str]:
        if not name.strip():
            return None, "name required"
        target_dir = self.user_dir if scope == "user" else self.proj_dir
        target_dir.mkdir(parents=True, exist_ok=True)
        safe_name = re.sub(r"[^a-zA-Z0-9_-]+", "-", name).strip("-") or "routine"
        target = target_dir / f"{safe_name}.md"
        if target.exists():
            return None, f"routine {safe_name!r} already exists at {target}"
        body_lines = [
            "---",
            f"name: {name}",
            f"description: {description}",
            f"trigger: {trigger}",
        ]
        if schedule:
            body_lines.append(f"schedule: \"{schedule}\"")
        body_lines.append(f"model: {model}")
        body_lines.append(f"permission_mode: {permission_mode}")
        body_lines.append("prompt: |")
        for line in prompt.splitlines():
            body_lines.append(f"  {line}")
        body_lines.append("---")
        body_lines.append("")
        body_lines.append(f"# Routine: {name}")
        body_lines.append("")
        target.write_text("\n".join(body_lines) + "\n", encoding="utf-8")
        r = _load_routine_file(target, source=scope)
        return r, f"created {target}"

    def delete(self, name: str) -> tuple[bool, str]:
        r = self.get(name)
        if r is None or r.path is None:
            return False, f"no routine named {name!r}"
        try:
            r.path.unlink()
        except OSError as e:
            return False, f"could not remove {r.path}: {e}"
        return True, f"removed {name!r}"

    def transcript_dir(self, name: str) -> Path:
        d = Path.home() / ".prometheus" / "routines" / name / "runs"
        d.mkdir(parents=True, exist_ok=True)
        return d


# ---------- run helper ----------


def make_run_id() -> str:
    return f"run-{int(time.time())}-{uuid.uuid4().hex[:6]}"


def write_transcript(
    transcript_dir: Path, *,
    run_id: str, routine: Routine, lines: list[str],
) -> Path:
    """Append a JSONL transcript for one routine run."""
    p = transcript_dir / f"{run_id}.jsonl"
    with p.open("w", encoding="utf-8") as f:
        f.write(json.dumps({
            "kind": "routine_start",
            "name": routine.name,
            "trigger": routine.trigger,
            "ts": time.time(),
            "iso": datetime.utcnow().isoformat() + "Z",
        }) + "\n")
        for line in lines:
            f.write(json.dumps({
                "kind": "line",
                "text": line,
                "ts": time.time(),
            }) + "\n")
        f.write(json.dumps({
            "kind": "routine_end",
            "ts": time.time(),
        }) + "\n")
    return p
