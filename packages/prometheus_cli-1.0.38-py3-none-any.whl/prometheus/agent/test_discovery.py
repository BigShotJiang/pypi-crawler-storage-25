"""Round-95 turn-6: deterministic test-command discovery.

Pure helper that decides which shell command to run for a "run the
test suite" request, based on what config files exist in the workdir.
No LLM involvement — runs in <100ms and returns a single command +
explanation.

Without this, free-tier models burn 4-6 LLM iterations reading
pyproject.toml / globbing tests/ / Makefile / scripts/ before they
agree on `python -m pytest -q`. Each iteration is a network round-trip
+ tokens. On the live smoke test, that pre-bash phase took ~50 seconds
of wall-clock and ~10K tokens for a project where the answer was
trivially derivable from one toml file.

Resolution order (most-specific first):
  1.  pytest config in `pyproject.toml [tool.pytest.ini_options]`
  2.  `pytest.ini`, `setup.cfg [tool:pytest]`, or `tox.ini`
  3.  npm `package.json` with a `test` script
  4.  `Cargo.toml` for cargo
  5.  `go.mod` for `go test ./...`
  6.  `Makefile` with a `test:` target
  7.  Last-resort: probe for `tests/` or `test/` and fall back to
      `python -m pytest -q` if Python is the dominant language.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class DiscoveryResult:
    """Result of a discover_test_command() call.

    Round-95 turn-6: previously named `DiscoveryResult`. Renamed to
    avoid pytest's `Test*` class-collection heuristic, which flagged
    the dataclass as a test class and emitted a warning every test
    run.
    """
    command: str
    why: str
    evidence: list[str] = field(default_factory=list)
    risk: str = "low"
    confidence: str = "high"   # "high" | "medium" | "low"

    def to_dict(self) -> dict[str, object]:
        return {
            "command":    self.command,
            "why":        self.why,
            "evidence":   list(self.evidence),
            "risk":       self.risk,
            "confidence": self.confidence,
        }


def _safe_read(path: Path, max_bytes: int = 65_536) -> str:
    """Read a config file with bounded size and explicit encoding."""
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read(max_bytes)
    except OSError:
        return ""


def _has_marker(text: str, marker: str) -> bool:
    """Cheap substring check used for probing config sections."""
    return marker in (text or "")


def discover_test_command(workdir: Path | str) -> DiscoveryResult:
    """Walk the workdir's well-known config files and return the single
    best test command, or a sensible fallback. Pure function — no LLM
    calls, no subprocess spawn, no network.

    Always returns a DiscoveryResult — never raises. Confidence is
    "high" when an explicit pytest/cargo/go/npm config drives the
    pick, "medium" when we infer from directory layout, "low" for
    pure fallback.
    """
    p = Path(workdir).resolve() if not isinstance(workdir, Path) else workdir.resolve()
    evidence: list[str] = []

    # 1. pyproject.toml — prefer pytest if a [tool.pytest.ini_options]
    #    section exists, OR if pytest is in dependencies.
    pp = p / "pyproject.toml"
    if pp.exists():
        body = _safe_read(pp)
        if "[tool.pytest.ini_options]" in body or "[tool.pytest]" in body:
            evidence.append("pyproject.toml has [tool.pytest.ini_options]")
            return DiscoveryResult(
                command="python -m pytest -q",
                why="pytest config in pyproject.toml",
                evidence=evidence,
                risk="low",
                confidence="high",
            )
        # pytest listed as a dependency but no config section — still high-confidence.
        if re.search(r"\bpytest\b", body, re.IGNORECASE):
            evidence.append("pyproject.toml mentions pytest (no explicit config section)")
            return DiscoveryResult(
                command="python -m pytest -q",
                why="pytest in pyproject.toml dependencies",
                evidence=evidence,
                risk="low",
                confidence="high",
            )
        evidence.append("pyproject.toml present (no pytest hint)")

    # 2. pytest.ini / setup.cfg / tox.ini
    pi = p / "pytest.ini"
    if pi.exists():
        evidence.append("pytest.ini present")
        return DiscoveryResult(
            command="python -m pytest -q",
            why="pytest.ini drives test discovery",
            evidence=evidence,
            risk="low",
            confidence="high",
        )
    sc = p / "setup.cfg"
    if sc.exists():
        body = _safe_read(sc)
        if "[tool:pytest]" in body or "[pytest]" in body:
            evidence.append("setup.cfg has [tool:pytest]")
            return DiscoveryResult(
                command="python -m pytest -q",
                why="pytest config in setup.cfg",
                evidence=evidence,
                risk="low",
                confidence="high",
            )
    ti = p / "tox.ini"
    if ti.exists():
        body = _safe_read(ti)
        if "[testenv]" in body:
            evidence.append("tox.ini has [testenv] (use tox)")
            return DiscoveryResult(
                command="tox",
                why="tox.ini drives test execution",
                evidence=evidence,
                risk="low",
                confidence="high",
            )

    # 3. package.json with `test` script — npm/yarn/pnpm preference.
    pj = p / "package.json"
    if pj.exists():
        body = _safe_read(pj)
        # Match a "test": "..." entry inside scripts.
        m = re.search(r'"scripts"\s*:\s*\{[^}]*"test"\s*:\s*"([^"]*)"', body, re.DOTALL)
        if m:
            cmd_in_pkg = m.group(1).strip()
            evidence.append(f"package.json scripts.test = {cmd_in_pkg!r}")
            # Prefer the package manager that matches the lockfile.
            if (p / "yarn.lock").exists():
                runner = "yarn test"
            elif (p / "pnpm-lock.yaml").exists():
                runner = "pnpm test"
            else:
                runner = "npm test"
            return DiscoveryResult(
                command=runner,
                why="test script defined in package.json",
                evidence=evidence,
                risk="low",
                confidence="high",
            )
        evidence.append("package.json present (no test script)")

    # 4. Cargo.toml — Rust.
    ct = p / "Cargo.toml"
    if ct.exists():
        evidence.append("Cargo.toml present")
        return DiscoveryResult(
            command="cargo test",
            why="Cargo workspace — `cargo test` runs the unit + doc test suite",
            evidence=evidence,
            risk="low",
            confidence="high",
        )

    # 5. go.mod — Go.
    gm = p / "go.mod"
    if gm.exists():
        evidence.append("go.mod present")
        return DiscoveryResult(
            command="go test ./...",
            why="Go module — `go test ./...` runs all package tests",
            evidence=evidence,
            risk="low",
            confidence="high",
        )

    # 6. Makefile with a `test:` target.
    mk = p / "Makefile"
    if mk.exists():
        body = _safe_read(mk)
        # Test target detection — `^test:` at start of line, preceded only by whitespace.
        if re.search(r"^test\s*:", body, re.MULTILINE):
            evidence.append("Makefile has `test:` target")
            return DiscoveryResult(
                command="make test",
                why="Makefile defines a `test` target",
                evidence=evidence,
                risk="low",
                confidence="high",
            )
        evidence.append("Makefile present (no `test:` target)")

    # 7. Probe for tests/ or test/ directories — medium confidence.
    if (p / "tests").is_dir():
        evidence.append("tests/ directory exists")
        # Check whether it's a Python project (.py files dominant) — fall back to pytest.
        return DiscoveryResult(
            command="python -m pytest -q tests",
            why="tests/ directory exists; defaulting to pytest",
            evidence=evidence,
            risk="low",
            confidence="medium",
        )
    if (p / "test").is_dir():
        evidence.append("test/ directory exists")
        return DiscoveryResult(
            command="python -m pytest -q test",
            why="test/ directory exists; defaulting to pytest",
            evidence=evidence,
            risk="low",
            confidence="medium",
        )

    # 8. Last-resort fallback — bare pytest.
    evidence.append("no config / tests dir found — fallback to pytest")
    return DiscoveryResult(
        command="python -m pytest -q",
        why="no test config detected; falling back to pytest",
        evidence=evidence,
        risk="low",
        confidence="low",
    )


def render_for_model(d: DiscoveryResult) -> str:
    """Convert a DiscoveryResult into the string the tool returns to the
    LLM. Compact, easy to parse, no markdown noise."""
    lines = [
        f"command: {d.command}",
        f"why:     {d.why}",
        f"risk:    {d.risk}",
        f"confidence: {d.confidence}",
    ]
    if d.evidence:
        lines.append("evidence:")
        for e in d.evidence:
            lines.append(f"  - {e}")
    return "\n".join(lines)
