"""R233: deterministic post-processor that adds city/TZ labels to
time-zone-conversion replies.

Free-tier models on `openrouter/free` reliably echo the bare PowerShell
timestamp from `[System.TimeZoneInfo]::ConvertTimeFromUtc(...)` without
the city/TZ label, even when the system prompt explicitly demands the
label (R231 evidence). This is a known limit of weak free models.

R233's fix: pattern-match (a) the tool-call shape, (b) the reply
shape, and (c) the user-prompt city tokens, then rewrite a
bare-timestamp reply to '<City>: <timestamp> (<TZ short>)'.

Surgical: zero LLM synthesis, zero behavior change unless ALL three
pattern checks match. Functions are pure — no I/O, no side effects,
trivially unit-testable in isolation.
"""
from __future__ import annotations

import re

# IANA Windows TZ name → short label shown to user.
# Only entries the system prompt teaches the model to use are listed
# here; unknown TZs fall through to a no-op (safer than guessing the
# wrong short name).
_TZ_SHORT: dict[str, str] = {
    "Eastern Standard Time": "Eastern",
    "Central Standard Time": "Central",
    "Mountain Standard Time": "Mountain",
    "Pacific Standard Time": "Pacific",
    "Alaskan Standard Time": "Alaska",
    "Hawaiian Standard Time": "Hawaii",
    "Atlantic Standard Time": "Atlantic",
    "GMT Standard Time": "UK",
    "W. Europe Standard Time": "CET",
    "Central European Standard Time": "CET",
    "Romance Standard Time": "CET",
    "Tokyo Standard Time": "JST",
    "China Standard Time": "CST",
    "India Standard Time": "IST",
    "Korea Standard Time": "KST",
    "AUS Eastern Standard Time": "AEST",
    "UTC": "UTC",
}

# IANA Windows TZ → tuple of city tokens (case-insensitive substring
# match against the user's prompt). Order matters: more specific
# tokens first so "new york" wins over "york" when both could fire.
_TZ_TO_CITIES: dict[str, tuple[tuple[str, str], ...]] = {
    # (token, display_name)
    "Eastern Standard Time": (
        ("new york city", "NYC"),
        ("nyc", "NYC"),
        ("new york", "NYC"),
        ("miami", "Miami"),
        ("boston", "Boston"),
        ("atlanta", "Atlanta"),
        ("philadelphia", "Philadelphia"),
        ("washington dc", "Washington DC"),
        ("washington", "Washington DC"),
        ("toronto", "Toronto"),
        ("orlando", "Orlando"),
    ),
    "Central Standard Time": (
        ("chicago", "Chicago"),
        ("houston", "Houston"),
        ("dallas", "Dallas"),
        ("austin", "Austin"),
        ("minneapolis", "Minneapolis"),
        ("milwaukee", "Milwaukee"),
        ("st. louis", "St. Louis"),
        ("st louis", "St. Louis"),
        ("nashville", "Nashville"),
        ("kansas city", "Kansas City"),
        ("new orleans", "New Orleans"),
    ),
    "Mountain Standard Time": (
        ("denver", "Denver"),
        ("phoenix", "Phoenix"),
        ("salt lake city", "Salt Lake City"),
        ("salt lake", "Salt Lake City"),
        ("albuquerque", "Albuquerque"),
        ("colorado springs", "Colorado Springs"),
    ),
    "Pacific Standard Time": (
        ("los angeles", "Los Angeles"),
        ("san francisco", "San Francisco"),
        ("seattle", "Seattle"),
        ("san diego", "San Diego"),
        ("portland or", "Portland"),
        ("portland", "Portland"),
        ("las vegas", "Las Vegas"),
        ("vegas", "Las Vegas"),
        ("vancouver", "Vancouver"),
        ("la", "LA"),
    ),
    "GMT Standard Time": (
        ("london", "London"),
        ("dublin", "Dublin"),
        ("edinburgh", "Edinburgh"),
        ("manchester", "Manchester"),
    ),
    "W. Europe Standard Time": (
        ("paris", "Paris"),
        ("berlin", "Berlin"),
        ("amsterdam", "Amsterdam"),
        ("madrid", "Madrid"),
        ("rome", "Rome"),
        ("zurich", "Zurich"),
        ("vienna", "Vienna"),
    ),
    "Tokyo Standard Time": (
        ("tokyo", "Tokyo"),
        ("osaka", "Osaka"),
        ("kyoto", "Kyoto"),
    ),
    "China Standard Time": (
        ("beijing", "Beijing"),
        ("shanghai", "Shanghai"),
        ("hong kong", "Hong Kong"),
        ("singapore", "Singapore"),
    ),
    "India Standard Time": (
        ("mumbai", "Mumbai"),
        ("delhi", "Delhi"),
        ("bangalore", "Bangalore"),
        ("bengaluru", "Bengaluru"),
    ),
    "AUS Eastern Standard Time": (
        ("sydney", "Sydney"),
        ("melbourne", "Melbourne"),
        ("brisbane", "Brisbane"),
    ),
}

# Bare PowerShell timestamp shape — the canonical
# `[System.TimeZoneInfo]::ConvertTimeFromUtc(...)` output:
#   "Saturday, May 9, 2026 6:34:26 PM"
#   "Saturday, May 9, 2026 6:34 PM"
_BARE_TIMESTAMP_RX = re.compile(
    r"^\s*"
    r"(Sunday|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday),?\s+"
    r"(January|February|March|April|May|June|July|August|September|October|November|December)\s+"
    r"\d{1,2},?\s+\d{4}\s+"
    r"\d{1,2}:\d{2}(?::\d{2})?\s+(AM|PM)"
    r"\s*$",
    re.IGNORECASE,
)

# Extracts the IANA Windows TZ name from a FindSystemTimeZoneById call.
# Quotes can be ' or "; trailing spaces tolerated.
_FINDTZ_RX = re.compile(
    r"FindSystemTimeZoneById\s*\(\s*['\"]([^'\"]+)['\"]\s*\)",
    re.IGNORECASE,
)


def _find_city(user_prompt: str, tz_long: str) -> str:
    """Best-match city token from `user_prompt` for the given TZ.

    Returns the display-name string ("NYC", "Miami", "Tokyo") or empty
    when no token matches. The TZ→cities mapping is the authority —
    we never guess a city that isn't on the list for that TZ, so we
    can't put "Tokyo" next to an Eastern Standard Time conversion.
    """
    if not user_prompt:
        return ""
    haystack = " " + user_prompt.lower() + " "
    for token, display in _TZ_TO_CITIES.get(tz_long, ()):
        # Word-boundary-ish match: surround token with spaces or
        # common punctuation so "la" doesn't match "place" / "blah".
        needle = " " + token.lower()
        if needle in haystack and (
            haystack.find(needle) + len(needle) >= len(haystack)
            or not haystack[haystack.find(needle) + len(needle)].isalpha()
        ):
            return display
    return ""


def is_timestamp_only(text: str) -> bool:
    """True iff `text` is exactly a bare PowerShell timestamp.

    Used by the live hook AND by tests to verify the regex matches
    the live tool-output shapes we've seen."""
    return bool(_BARE_TIMESTAMP_RX.match(text or ""))


def extract_tz_from_command(bash_command: str) -> str:
    """Extract the IANA Windows TZ name from a run_bash command, if
    the command is a `FindSystemTimeZoneById('<X>')` call. Empty when
    not a TZ-conversion call."""
    if not bash_command:
        return ""
    m = _FINDTZ_RX.search(bash_command)
    return m.group(1) if m else ""


def relabel_time_reply(
    reply: str,
    last_bash_command: str,
    user_prompt: str,
) -> str:
    """Surgical post-processor for time-zone-conversion replies.

    Returns `reply` unchanged unless ALL of these match:
      1. `last_bash_command` contains FindSystemTimeZoneById('<TZ>').
      2. `<TZ>` is a known IANA Windows name (in `_TZ_SHORT`).
      3. `reply` is exactly a bare PowerShell timestamp (no label
         already present).
    When matched, returns `<City>: <timestamp> (<TZ short>)` if the
    user prompt names a known city for that TZ, otherwise just
    `<timestamp> (<TZ short>)` (TZ-only, still better than nothing).

    Pure function — no side effects, no I/O. Safe to call on every
    reply; cheap when the patterns don't match.
    """
    if not reply:
        return reply
    tz_long = extract_tz_from_command(last_bash_command)
    if not tz_long:
        return reply
    tz_short = _TZ_SHORT.get(tz_long)
    if not tz_short:
        return reply  # unknown TZ — don't guess a label
    text = reply.strip()
    if not _BARE_TIMESTAMP_RX.match(text):
        return reply  # already labeled, or not a bare timestamp
    city = _find_city(user_prompt, tz_long)
    if city:
        return f"{city}: {text} ({tz_short})"
    return f"{text} ({tz_short})"
