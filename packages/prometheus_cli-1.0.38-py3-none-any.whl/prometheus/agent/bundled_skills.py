"""Round 128: Bundled skills.

Four built-in aptitudes shipped with PrometheUS that give the
agent first-class playbooks for common workflows:

  * security-review — categorized vulnerability findings
  * simplify        — quality-and-readability suggestions
  * batch           — parallel changes across worktrees
  * debug           — log capture + analysis

Each is a synthesized `Aptitude` record (no on-disk file ships
in the wheel — keeps install-size tiny). They're auto-discovered
alongside user-authored aptitudes by the existing
`prometheus.agent.aptitudes` machinery via the
`bundled_aptitudes()` accessor.

Bundled skills also expose slash-command wrappers
(`/security-review`, `/simplify`, `/batch`, `/debug`) that submit
the bundled prompt as a regular agent turn — the model gets the
playbook content automatically.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from prometheus.agent.aptitudes import Aptitude


# ---------- bundled aptitude definitions ----------


_BUNDLED_DEFS: list[dict[str, Any]] = [
    {
        "name": "security-review",
        "purpose": (
            "Analyze pending changes for security vulnerabilities — "
            "injection, auth flaws, data exposure, insecure deps."
        ),
        "triggers": (
            "security-review", "security audit", "vulnerability check",
        ),
        "body": (
            "You are running a security review on the project's "
            "pending changes. Walk through the diff (or the most "
            "recently edited files) and flag findings under these "
            "categories:\n\n"
            "1. **Injection** — SQL, command, template, header.\n"
            "2. **Authentication & authorization** — missing checks, "
            "broken session handling, IDOR, privilege escalation.\n"
            "3. **Data exposure** — secrets in logs/responses, "
            "verbose error pages, PII leaks.\n"
            "4. **Insecure dependencies** — outdated libs with known "
            "CVEs, unmaintained packages.\n"
            "5. **Cryptography** — weak hashes, hard-coded keys, "
            "missing TLS, predictable randomness.\n\n"
            "For each finding, output:\n"
            "  - **Severity** (critical / high / medium / low / info)\n"
            "  - **Location** (file:line)\n"
            "  - **Why it's a problem** (1-2 sentences)\n"
            "  - **Suggested fix** (concrete, file:line if possible)\n\n"
            "End with a one-line summary of the highest-severity "
            "category. Use `git diff` to scope the review when "
            "available."
        ),
    },
    {
        "name": "simplify",
        "purpose": (
            "Review changed code for quality issues and propose "
            "concrete simplifications."
        ),
        "triggers": ("simplify", "code review", "refactor review"),
        "body": (
            "You are reviewing recent code changes for "
            "simplification opportunities. Walk through the diff "
            "(or recently edited files) and surface findings under:\n\n"
            "1. **Readability** — long functions, deeply nested "
            "control flow, unclear names.\n"
            "2. **Complexity** — code paths that branch more than "
            "necessary, overengineered abstractions.\n"
            "3. **Duplication** — copy-paste patterns or near-"
            "duplicate helpers that could merge.\n"
            "4. **Naming** — vague identifiers, inconsistent "
            "casing, misleading words.\n"
            "5. **Error handling** — silently swallowed errors, "
            "broad except clauses, missing fallbacks.\n\n"
            "For each finding, output:\n"
            "  - **Type** (one of the five above)\n"
            "  - **Location** (file:line)\n"
            "  - **Issue** (what's currently there)\n"
            "  - **Suggestion** (concrete simpler form)\n\n"
            "Skip stylistic-only nits — focus on changes that "
            "make the code easier to maintain."
        ),
    },
    {
        "name": "batch",
        "purpose": (
            "Spawn 5-30 isolated worktree cohorts to make parallel "
            "changes across the codebase."
        ),
        "triggers": ("batch", "parallel changes", "multi-worktree"),
        "body": (
            "You have a large refactor or batch operation to apply "
            "across many independent units (files, modules, services).\n\n"
            "Workflow:\n"
            "1. Analyze the codebase and split the task into 5-30 "
            "independent units.\n"
            "2. For each unit, dispatch a background cohort with "
            "`task` + `run_in_background: true` + "
            "`subagent_type: general-purpose`. Pass the unit's "
            "scope as the prompt.\n"
            "3. Set `isolation: worktree` in the cohort definition "
            "so each agent runs in its own git worktree (round 117).\n"
            "4. After all cohorts complete, aggregate the results "
            "into a unified summary table:\n"
            "    | unit | status | files changed | summary |\n\n"
            "Cap parallelism at the env-tunable "
            "`PROMETHEUS_SUBAGENT_MAX_PARALLEL` (default 4) — the "
            "manager queues the rest. Watch for unit-level "
            "failures and retry once before reporting."
        ),
    },
    {
        "name": "debug",
        "purpose": (
            "Capture and analyze logs to identify issues. Optional "
            "problem description focuses the analysis."
        ),
        "triggers": ("debug", "analyze logs", "diagnose"),
        "body": (
            "You are debugging an issue. Workflow:\n\n"
            "1. If the user supplied a problem description, anchor "
            "the analysis on it. If not, scan logs for anomalies.\n"
            "2. Identify recent log files. Common locations:\n"
            "    - `logs/`, `tmp/logs/`, `var/log/`\n"
            "    - the current working directory's `.log` files\n"
            "    - the most-recently-modified file matching "
            "`*.log`\n"
            "3. Read the last ~500 lines and surface:\n"
            "    - **Errors** — stack traces, ERROR-level lines\n"
            "    - **Warnings** — WARN/WARNING-level lines\n"
            "    - **Anomalies** — unusual repetition, sudden "
            "silence, unexpected patterns\n"
            "4. For each finding, propose:\n"
            "    - **Likely root cause** (1-2 sentences)\n"
            "    - **Next step to verify** (specific tool call)\n\n"
            "End with the single most likely cause + the single "
            "most-leveraged next step."
        ),
    },
]


def bundled_aptitudes() -> list[Aptitude]:
    """Round 128: realize the bundled aptitudes as `Aptitude`
    records. Each is virtual — there's no on-disk file. The
    catalogue surfaces them alongside user-authored aptitudes;
    their `path` is a sentinel pseudo-path. Round 134 adds two
    more (fewer-permission-prompts, claude-api). Round 138
    adds three more (ghost, ultraplan, ultrareview)."""
    defs = list(_BUNDLED_DEFS)
    try:
        from prometheus.terminal_ux import bundled_round134
        defs.extend(bundled_round134())
    except Exception:
        pass
    try:
        from prometheus.bundled_skills_v138 import bundled_round138
        defs.extend(bundled_round138())
    except Exception:
        pass
    out: list[Aptitude] = []
    for d in defs:
        triggers = d["triggers"]
        if isinstance(triggers, str):
            triggers = (triggers,)
        else:
            triggers = tuple(triggers)
        out.append(Aptitude(
            name=str(d["name"]),
            purpose=str(d["purpose"]),
            body=str(d["body"]),
            path=Path(f"<bundled:{d['name']}>"),
            triggers=triggers,
            user_invocable=True,
            disable_model_invocation=False,
            source="bundled",
        ))
    return out


def bundled_names() -> list[str]:
    names = [str(d["name"]) for d in _BUNDLED_DEFS]
    try:
        from prometheus.terminal_ux import bundled_round134
        names.extend(str(d["name"]) for d in bundled_round134())
    except Exception:
        pass
    try:
        from prometheus.bundled_skills_v138 import bundled_round138
        names.extend(str(d["name"]) for d in bundled_round138())
    except Exception:
        pass
    return names


def get_bundled(name: str):
    """Look up a bundled aptitude by name. Returns None if the
    name isn't one of the built-ins."""
    for a in bundled_aptitudes():
        if a.name == name:
            return a
    return None
