"""Round 121: Dreaming — async self-improvement.

`/dream` triggers an asynchronous reflection cycle. The engine
walks the Memory Vault + recent session transcripts and produces
a Dream Report — curated memories + suggested Charter updates +
identified patterns.

Round-121 ships:
  * Transcript scanner (reads `~/.prometheus/sessions/*.jsonl`)
  * Pattern detectors (frequent corrections, repeated mistakes,
    successful strategies, project gotchas)
  * Dream report writer (`~/.prometheus/memory/dreams/<ts>.md`)
  * Approval flow data model
  * `/dream`, `/dream status`, `/dream schedule` slash commands

Round 1.0.3 adds autonomous consolidation (default on):
  * Lock file at `~/.prometheus/dream.lock` so concurrent cycles
    don't collide; stale locks (dead PID) are reclaimed.
  * Deduplication of near-identical memory bodies.
  * Stale-entry pruning (mtime older than the configured floor).
  * Relative-date rewriting in memory bodies (yesterday/tomorrow/
    weekday/N days ago → ISO dates).
  * Size cap: keep the user-private memory directory below a
    configured entry count (default 200, mirroring CC's index cap).
  * Source code is *never* modified — consolidation only touches
    `~/.prometheus/memory/*.md`.

The engine is heuristic — no LLM calls so dreams work offline.
A future polish round can layer LLM-driven synthesis on top.
"""
from __future__ import annotations

import json
import os
import re
import time
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Optional


def max_transcripts() -> int:
    try:
        return max(1, int(os.environ.get(
            "PROMETHEUS_DREAM_MAX_TRANSCRIPTS", "50",
        )))
    except (TypeError, ValueError):
        return 50


# ---------- detected patterns ----------


@dataclass
class Pattern:
    """One detected pattern in recent sessions."""
    kind: str          # `frequent_correction` / `repeated_mistake` / etc.
    title: str
    evidence: str      # 1-2 line summary
    confidence: float  # 0.0 - 1.0


@dataclass
class SuggestedMemory:
    """A memory the user might want to commit to the vault."""
    name: str
    type: str          # `user` / `feedback` / `project` / `reference`
    description: str
    body: str
    approved: Optional[bool] = None  # None = pending, True/False = decision


@dataclass
class DreamReport:
    """Full output of one dream cycle."""
    generated_at: str
    transcripts_scanned: int
    patterns: list[Pattern] = field(default_factory=list)
    suggested_memories: list[SuggestedMemory] = field(default_factory=list)
    suggested_charter_additions: list[str] = field(default_factory=list)
    # 1.0.3: only populated when autonomous mode actually ran.
    consolidation: Optional["ConsolidationResult"] = None


# ---------- transcript scanning ----------


def _sessions_dir() -> Path:
    return Path.home() / ".prometheus" / "sessions"


def find_recent_transcripts(limit: Optional[int] = None) -> list[Path]:
    """Return up to `limit` most-recent session transcripts."""
    cap = limit or max_transcripts()
    d = _sessions_dir()
    if not d.exists() or not d.is_dir():
        return []
    try:
        files = sorted(
            d.glob("*.jsonl"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
    except OSError:
        return []
    return files[:cap]


def read_transcript_lines(path: Path) -> list[dict[str, Any]]:
    """Yield each JSONL row as a dict. Errors return []."""
    out: list[dict[str, Any]] = []
    try:
        with path.open("r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                    if isinstance(obj, dict):
                        out.append(obj)
                except (ValueError, TypeError):
                    continue
    except OSError:
        pass
    return out


# ---------- pattern detectors ----------


_CORRECTION_RX = re.compile(
    r"\b(no|wait|actually|don.?t|please don.?t|stop)\b",
    re.IGNORECASE,
)


def detect_frequent_corrections(
    transcripts: list[list[dict]],
) -> list[Pattern]:
    """Round 121: find recurring user corrections."""
    triggers: Counter[str] = Counter()
    for rows in transcripts:
        for row in rows:
            role = (row.get("role") or "").lower()
            content = str(row.get("content", "") or "")
            if role != "user":
                continue
            if _CORRECTION_RX.search(content):
                # Capture the first 60 chars as the trigger key
                # (rough — good enough for clustering across runs).
                key = content.strip().splitlines()[0][:60].lower()
                triggers[key] += 1
    out: list[Pattern] = []
    for key, n in triggers.most_common(5):
        if n < 2:
            continue
        out.append(Pattern(
            kind="frequent_correction",
            title=f"User has corrected '{key[:50]}…' {n} times",
            evidence=f"appeared in {n} sessions",
            confidence=min(1.0, n / 5.0),
        ))
    return out


def detect_repeated_mistakes(
    transcripts: list[list[dict]],
) -> list[Pattern]:
    """Round 121: tool calls that errored repeatedly with the
    same shape."""
    errors: Counter[str] = Counter()
    for rows in transcripts:
        for row in rows:
            if (row.get("role") or "").lower() != "tool":
                continue
            content = str(row.get("content", "") or "")
            if "error" not in content.lower():
                continue
            head = content.strip().splitlines()[0][:80].lower()
            errors[head] += 1
    out: list[Pattern] = []
    for head, n in errors.most_common(5):
        if n < 2:
            continue
        out.append(Pattern(
            kind="repeated_mistake",
            title=f"Tool error repeated {n} times: {head[:60]}",
            evidence=f"observed in {n} runs",
            confidence=min(1.0, n / 5.0),
        ))
    return out


def detect_successful_strategies(
    transcripts: list[list[dict]],
) -> list[Pattern]:
    """Round 121: tool sequences that ended in clean reply +
    no error tail."""
    seen_strategies: Counter[str] = Counter()
    for rows in transcripts:
        # Walk the row list collecting tool-name sequences.
        seq: list[str] = []
        for row in rows:
            role = (row.get("role") or "").lower()
            if role == "tool":
                seq.append(str(row.get("name", "tool")))
            elif role == "assistant" and seq:
                key = " → ".join(seq[-4:])
                if key:
                    seen_strategies[key] += 1
                seq = []
    out: list[Pattern] = []
    for key, n in seen_strategies.most_common(5):
        if n < 3 or "→" not in key:
            continue
        out.append(Pattern(
            kind="successful_strategy",
            title=f"Reusable tool sequence ({n}×): {key[:80]}",
            evidence=f"used cleanly in {n} sessions",
            confidence=min(1.0, n / 10.0),
        ))
    return out


# ---------- autonomous consolidation (1.0.3) ----------


class LockBusyError(RuntimeError):
    """Another dream cycle holds the lock."""


def _lock_path() -> Path:
    return Path.home() / ".prometheus" / "dream.lock"


def _lock_stale_seconds() -> int:
    try:
        return max(60, int(os.environ.get(
            "PROMETHEUS_DREAM_LOCK_STALE_SECONDS", "1800",
        )))
    except (TypeError, ValueError):
        return 1800


def _pid_alive(pid: int) -> bool:
    """Best-effort liveness check; conservative — returns True
    when uncertain so we never reclaim a live process's lock."""
    if pid <= 0:
        return False
    try:
        if os.name == "nt":
            # Windows: opening the process handle proves liveness.
            import ctypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            h = ctypes.windll.kernel32.OpenProcess(
                PROCESS_QUERY_LIMITED_INFORMATION, False, pid,
            )
            if h:
                ctypes.windll.kernel32.CloseHandle(h)
                return True
            return False
        os.kill(pid, 0)
        return True
    except (OSError, PermissionError, ValueError):
        # PermissionError on POSIX means the PID exists but
        # belongs to another user — still alive.
        return True
    except Exception:
        return True


def acquire_dream_lock() -> Path:
    """Atomically claim the dream lock. Reclaims a stale lock if
    its recorded PID is dead or the file is older than the stale
    floor. Raises LockBusyError when a live cycle holds it."""
    path = _lock_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        # Decide whether to reclaim.
        try:
            raw = path.read_text(encoding="utf-8", errors="replace").strip()
            recorded_pid = int(raw.split()[0]) if raw else 0
        except (OSError, ValueError):
            recorded_pid = 0
        try:
            age = time.time() - path.stat().st_mtime
        except OSError:
            age = 0.0
        if (recorded_pid and _pid_alive(recorded_pid)
                and age < _lock_stale_seconds()):
            raise LockBusyError(
                f"dream cycle already running (pid {recorded_pid})"
            )
        # Stale — reclaim by removing then recreating.
        try:
            path.unlink()
        except OSError:
            pass
        fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    try:
        os.write(fd, f"{os.getpid()} {datetime.utcnow().isoformat()}Z\n".encode())
    finally:
        os.close(fd)
    return path


def release_dream_lock() -> None:
    p = _lock_path()
    try:
        if p.exists():
            p.unlink()
    except OSError:
        pass


# ---- relative-date rewriting ----

_WEEKDAYS = (
    "monday", "tuesday", "wednesday", "thursday",
    "friday", "saturday", "sunday",
)


def _absolute_date_for(today: datetime, phrase: str) -> Optional[str]:
    p = phrase.strip().lower()
    if p == "today":
        return today.strftime("%Y-%m-%d")
    if p == "yesterday":
        return (today - timedelta(days=1)).strftime("%Y-%m-%d")
    if p == "tomorrow":
        return (today + timedelta(days=1)).strftime("%Y-%m-%d")
    m = re.match(r"^(\d+)\s+days?\s+ago$", p)
    if m:
        return (today - timedelta(days=int(m.group(1)))).strftime("%Y-%m-%d")
    m = re.match(r"^in\s+(\d+)\s+days?$", p)
    if m:
        return (today + timedelta(days=int(m.group(1)))).strftime("%Y-%m-%d")
    if p in _WEEKDAYS:
        target = _WEEKDAYS.index(p)
        # Most-recent past occurrence (including today if matches).
        diff = (today.weekday() - target) % 7
        if diff == 0:
            diff = 7
        return (today - timedelta(days=diff)).strftime("%Y-%m-%d")
    return None


_RELATIVE_PATTERN = re.compile(
    r"\b(today|yesterday|tomorrow|"
    r"\d+\s+days?\s+ago|in\s+\d+\s+days?|"
    r"monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b",
    re.IGNORECASE,
)


def rewrite_relative_dates(text: str, *, today: Optional[datetime] = None) -> str:
    """Replace relative date phrases with ISO dates.

    Conservative: skips any phrase already followed by a parenthesised
    or em-dash absolute date, and skips Markdown links / code blocks.
    """
    if not text:
        return text
    today = today or datetime.utcnow()

    def _sub(m: "re.Match[str]") -> str:
        phrase = m.group(0)
        absolute = _absolute_date_for(today, phrase)
        if not absolute:
            return phrase
        # Don't double-rewrite if already annotated.
        end = m.end()
        tail = text[end:end + 16].lstrip()
        if tail.startswith(f"({absolute}") or tail.startswith(f"— {absolute}"):
            return phrase
        return f"{phrase} ({absolute})"

    # Skip fenced code blocks for safety.
    parts = re.split(r"(```.*?```)", text, flags=re.DOTALL)
    for i, chunk in enumerate(parts):
        if chunk.startswith("```"):
            continue
        parts[i] = _RELATIVE_PATTERN.sub(_sub, chunk)
    return "".join(parts)


# ---- consolidation ----


def _user_memory_dir() -> Path:
    return Path.home() / ".prometheus" / "memory"


def _max_memory_entries() -> int:
    try:
        return max(10, int(os.environ.get(
            "PROMETHEUS_MEMORY_MAX_ENTRIES", "200",
        )))
    except (TypeError, ValueError):
        return 200


def _stale_floor_days() -> int:
    try:
        return max(7, int(os.environ.get(
            "PROMETHEUS_MEMORY_STALE_DAYS", "90",
        )))
    except (TypeError, ValueError):
        return 90


_FRONTMATTER_RX = re.compile(r"^---\n.*?\n---\n", re.DOTALL)


def _body_signature(raw: str) -> str:
    """Whitespace-insensitive fingerprint of a memory's body
    (frontmatter stripped). Used to dedup near-identical entries
    even when their `name:` frontmatter differs."""
    body = _FRONTMATTER_RX.sub("", raw or "", count=1)
    norm = re.sub(r"\s+", " ", body.strip().lower())
    return norm[:600]


@dataclass
class ConsolidationResult:
    """What autonomous consolidation actually changed on disk."""
    deduplicated: list[str] = field(default_factory=list)
    pruned_stale: list[str] = field(default_factory=list)
    pruned_for_size: list[str] = field(default_factory=list)
    dates_rewritten: list[str] = field(default_factory=list)
    skipped_protected: list[str] = field(default_factory=list)
    error: Optional[str] = None


def consolidate_memories(
    memory_dir: Optional[Path] = None,
    *,
    today: Optional[datetime] = None,
    max_entries: Optional[int] = None,
    stale_days: Optional[int] = None,
    dry_run: bool = False,
) -> ConsolidationResult:
    """Round 1.0.3: autonomous Memory Vault pruning.

    Operates exclusively on `*.md` files inside the user-private
    memory directory (default `~/.prometheus/memory/`). Source code,
    project files, transcripts, and dream reports are *never* touched.

    Steps (in order):
      1. Rewrite relative dates inside each memory body.
      2. Drop near-duplicate memories (keep newest by mtime).
      3. Drop memories older than `stale_days` (default env-driven).
      4. If still over `max_entries`, drop the oldest until under.
    """
    result = ConsolidationResult()
    root = memory_dir or _user_memory_dir()
    if not root.exists() or not root.is_dir():
        return result
    today = today or datetime.utcnow()
    cap = max_entries or _max_memory_entries()
    floor_days = stale_days if stale_days is not None else _stale_floor_days()

    try:
        files = sorted(root.glob("*.md"))
    except OSError as exc:
        result.error = f"scan failed: {exc}"
        return result

    # Resolve protected dirs we must never recurse into.
    dreams_dir = (root / "dreams").resolve()

    entries: list[tuple[Path, float, str, str]] = []  # path, mtime, body_sig, raw
    for p in files:
        try:
            real = p.resolve()
        except OSError:
            result.skipped_protected.append(p.name)
            continue
        if dreams_dir in real.parents or real == dreams_dir:
            result.skipped_protected.append(p.name)
            continue
        try:
            raw = p.read_text(encoding="utf-8", errors="replace")
            mtime = p.stat().st_mtime
        except OSError:
            continue
        entries.append((p, mtime, _body_signature(raw), raw))

    # 1. Rewrite relative dates.
    for p, _mtime, _sig, raw in entries:
        rewritten = rewrite_relative_dates(raw, today=today)
        if rewritten != raw:
            result.dates_rewritten.append(p.name)
            if not dry_run:
                try:
                    p.write_text(rewritten, encoding="utf-8")
                except OSError:
                    pass

    # 2. Deduplicate by signature — keep newest mtime.
    by_sig: dict[str, tuple[Path, float]] = {}
    duplicates: list[Path] = []
    for p, mtime, sig, _raw in entries:
        if not sig:
            continue
        prev = by_sig.get(sig)
        if prev is None or mtime > prev[1]:
            if prev is not None:
                duplicates.append(prev[0])
            by_sig[sig] = (p, mtime)
        else:
            duplicates.append(p)
    for dup in duplicates:
        result.deduplicated.append(dup.name)
        if not dry_run:
            try:
                dup.unlink()
            except OSError:
                pass

    # Re-scan for the size+staleness pass (post-dedup).
    survivors: list[tuple[Path, float]] = [
        (p, mt) for (p, mt, _, _) in entries if p not in duplicates
    ]

    # 3. Prune stale entries.
    cutoff = time.time() - floor_days * 86400.0
    still_living: list[tuple[Path, float]] = []
    for p, mtime in survivors:
        if mtime < cutoff:
            result.pruned_stale.append(p.name)
            if not dry_run:
                try:
                    p.unlink()
                except OSError:
                    pass
            continue
        still_living.append((p, mtime))

    # 4. Size cap — drop oldest until under.
    if len(still_living) > cap:
        still_living.sort(key=lambda t: t[1])  # oldest first
        excess = len(still_living) - cap
        for p, _mtime in still_living[:excess]:
            result.pruned_for_size.append(p.name)
            if not dry_run:
                try:
                    p.unlink()
                except OSError:
                    pass

    return result


# ---------- dream cycle ----------


def run_dream_cycle(
    *,
    limit: Optional[int] = None,
    autonomous: bool = True,
    today: Optional[datetime] = None,
) -> DreamReport:
    """Produce a DreamReport. Pure-Python heuristics — no LLM
    calls. Safe to run offline / on a cron.

    When `autonomous=True` (the default since 1.0.3) the cycle
    holds a lock file and applies Memory Vault consolidation
    (dedup + stale prune + relative-date rewrite + size cap).
    Pass `autonomous=False` for the original approval-only flow,
    which writes a report but never modifies memories.
    """
    consolidation: Optional[ConsolidationResult] = None
    if autonomous:
        try:
            acquire_dream_lock()
        except LockBusyError:
            # Another cycle is running — return an empty report
            # rather than fight it.
            return DreamReport(
                generated_at=datetime.utcnow().isoformat() + "Z",
                transcripts_scanned=0,
            )
        try:
            consolidation = consolidate_memories(today=today)
        finally:
            release_dream_lock()

    files = find_recent_transcripts(limit=limit)
    transcripts = [read_transcript_lines(p) for p in files]
    patterns: list[Pattern] = []
    patterns += detect_frequent_corrections(transcripts)
    patterns += detect_repeated_mistakes(transcripts)
    patterns += detect_successful_strategies(transcripts)
    suggested_memories: list[SuggestedMemory] = []
    for p in patterns:
        if p.kind == "frequent_correction":
            suggested_memories.append(SuggestedMemory(
                name=f"correction-{int(time.time())}",
                type="feedback",
                description=p.title[:120],
                body=(
                    f"Recurring correction observed in recent "
                    f"sessions. Treat the underlying behavior as a "
                    f"settled preference unless the user explicitly "
                    f"reverses it.\n\nEvidence: {p.evidence}"
                ),
            ))
        elif p.kind == "repeated_mistake":
            suggested_memories.append(SuggestedMemory(
                name=f"avoid-{int(time.time())}",
                type="feedback",
                description=p.title[:120],
                body=(
                    f"This tool error keeps surfacing — investigate "
                    f"the root cause once, not per-session.\n\n"
                    f"Evidence: {p.evidence}"
                ),
            ))
        elif p.kind == "successful_strategy":
            suggested_memories.append(SuggestedMemory(
                name=f"strategy-{int(time.time())}",
                type="project",
                description=p.title[:120],
                body=(
                    f"This tool sequence has produced clean results "
                    f"repeatedly. Preserve as a known-good "
                    f"workflow.\n\nEvidence: {p.evidence}"
                ),
            ))
    charter_suggestions: list[str] = []
    if any(p.kind == "frequent_correction" for p in patterns):
        charter_suggestions.append(
            "Add a 'Recurring corrections' subsection to the "
            "Charter under 'Important Patterns'."
        )
    if any(p.kind == "successful_strategy" for p in patterns):
        charter_suggestions.append(
            "Document the recurring tool-sequence strategies in "
            "the Charter's 'Commands That Work' section."
        )
    return DreamReport(
        generated_at=datetime.utcnow().isoformat() + "Z",
        transcripts_scanned=len(files),
        patterns=patterns,
        suggested_memories=suggested_memories,
        suggested_charter_additions=charter_suggestions,
        consolidation=consolidation,
    )


# ---------- report writer + approval flow ----------


def _dreams_dir() -> Path:
    return Path.home() / ".prometheus" / "memory" / "dreams"


def render_dream_report(report: DreamReport) -> str:
    """Round 121: format a DreamReport as markdown."""
    lines = [
        f"# Dream report — {report.generated_at}",
        "",
        f"Transcripts scanned: {report.transcripts_scanned}",
        "",
    ]
    if report.patterns:
        lines.append("## Patterns detected")
        for p in report.patterns:
            lines.append(
                f"- **{p.kind}** — {p.title} "
                f"_(confidence {p.confidence:.2f})_"
            )
            lines.append(f"  - {p.evidence}")
        lines.append("")
    if report.suggested_memories:
        lines.append("## Suggested memories (pending approval)")
        for m in report.suggested_memories:
            lines.append(f"### {m.name}")
            lines.append(f"_type: {m.type}_")
            lines.append("")
            lines.append(f"> {m.description}")
            lines.append("")
            lines.append(m.body)
            lines.append("")
    if report.suggested_charter_additions:
        lines.append("## Suggested Charter additions")
        for s in report.suggested_charter_additions:
            lines.append(f"- {s}")
        lines.append("")
    c = report.consolidation
    if c is not None and (
        c.deduplicated or c.pruned_stale
        or c.pruned_for_size or c.dates_rewritten
    ):
        lines.append("## Autonomous consolidation")
        if c.deduplicated:
            lines.append(f"- Deduplicated: {len(c.deduplicated)}")
            for n in c.deduplicated[:10]:
                lines.append(f"  - {n}")
        if c.pruned_stale:
            lines.append(f"- Pruned (stale): {len(c.pruned_stale)}")
            for n in c.pruned_stale[:10]:
                lines.append(f"  - {n}")
        if c.pruned_for_size:
            lines.append(f"- Pruned (size cap): {len(c.pruned_for_size)}")
            for n in c.pruned_for_size[:10]:
                lines.append(f"  - {n}")
        if c.dates_rewritten:
            lines.append(f"- Relative dates rewritten: {len(c.dates_rewritten)}")
        lines.append("")
    if not (
        report.patterns or report.suggested_memories
        or report.suggested_charter_additions
        or (c and (c.deduplicated or c.pruned_stale
                   or c.pruned_for_size or c.dates_rewritten))
    ):
        lines.append(
            "_No patterns detected. PrometheUS is sleeping "
            "peacefully — nothing to learn from recent sessions._"
        )
    return "\n".join(lines).rstrip() + "\n"


def write_dream_report(report: DreamReport) -> Path:
    """Round 121: write report to disk under
    `~/.prometheus/memory/dreams/<ts>.md`."""
    d = _dreams_dir()
    d.mkdir(parents=True, exist_ok=True)
    ts = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    p = d / f"dream-{ts}.md"
    p.write_text(render_dream_report(report), encoding="utf-8")
    return p


def list_dream_reports() -> list[Path]:
    d = _dreams_dir()
    if not d.exists() or not d.is_dir():
        return []
    try:
        return sorted(
            d.glob("dream-*.md"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
    except OSError:
        return []


@dataclass
class DreamSchedule:
    """Round 121: simple cron-like schedule for periodic
    dreams. Persisted at `~/.prometheus/dream-schedule.json`."""
    cron: str = ""              # 5-field cron, empty = disabled
    last_run_iso: str = ""

    @classmethod
    def load(cls) -> "DreamSchedule":
        p = Path.home() / ".prometheus" / "dream-schedule.json"
        if not p.exists() or not p.is_file():
            return cls()
        try:
            data = json.loads(p.read_text(encoding="utf-8", errors="replace"))
            return cls(
                cron=str(data.get("cron", "")),
                last_run_iso=str(data.get("last_run_iso", "")),
            )
        except (OSError, ValueError):
            return cls()

    def save(self) -> None:
        p = Path.home() / ".prometheus" / "dream-schedule.json"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps({
            "cron": self.cron,
            "last_run_iso": self.last_run_iso,
        }, indent=2), encoding="utf-8")
