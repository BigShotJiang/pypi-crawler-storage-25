"""Round-87: heuristic task decomposer for chain-heavy free-model
reliability.

Empirical findings (rounds 71/74/75/77/78): free models reliably
handle 1-2 tool calls per turn but stall on 3+ tool chains. This
module breaks a multi-step request into single-step subtasks, each
of which can run cleanly in its own turn — trading 4× more requests
for staying inside the proven 1-2-tool comfort zone.

Round 87 ships the heuristic-only decomposer for known patterns:
  • clone + read README          (Task 6 pattern)
  • find + fix syntax error      (Task 7 pattern)
  • init + write + add + commit  (Task 8 pattern)

Patterns not matched return None — the caller falls back to the
existing single-loop path (no regression for SIMPLE/CHAT/CODE-INFO).

This module is pure Python — no LLM calls — so it ships in the wheel
and can be unit-tested without provider credentials.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass
class Subtask:
    """One single-step unit of a decomposed chain.

    The `prompt` is what the harness sends to the agent loop. The
    `predicate_name` + `predicate_args` identify a hardcoded check
    the test harness runs against workdir state after the subtask
    completes — the harness's predicate registry knows how to evaluate
    each name. Round 88 may upgrade these to LLM-judged predicates.
    """
    index: int                                # 1-based step number
    total: int                                # total subtasks in this plan
    goal_text: str                            # human-readable summary
    prompt: str                               # what to send to the agent
    predicate_name: str                       # registry lookup
    predicate_args: dict = field(default_factory=dict)


# === Pattern matchers ====================================================
# Each matcher returns list[Subtask] if it recognizes the prompt shape,
# else None. Matchers run in order; first match wins. Order is by
# specificity — most-distinctive patterns first.

_CLONE_PAT = re.compile(
    r"git\s+clone\s+(?P<url>https?://\S+)\s+(?P<target>\S+?)(?:\s|\.|$)",
    re.I,
)
_FIND_FIX_PAT = re.compile(
    r"(?:find\s+and\s+fix|fix\s+the\s+(?:syntax\s+)?error)\s+(?:in\s+)?(?P<path>\S+\.(?:py|js|ts|go|rs|java|rb|c|cpp|h))",
    re.I,
)
_GIT_SETUP_PAT = re.compile(
    r"(?:set\s+up|create)\s+(?:a\s+)?(?:new\s+)?(?:directory\s+)?(?P<target>\S+).*?git\s+init",
    re.I | re.DOTALL,
)


def _match_clone_and_read(prompt: str) -> list[Subtask] | None:
    """Pattern: 'git clone <url> <target> ... then read [the] README ...'"""
    m = _CLONE_PAT.search(prompt)
    if not m:
        return None
    p_low = prompt.lower()
    if "readme" not in p_low:
        return None
    url = m.group("url")
    target = m.group("target").rstrip(".")
    return [
        Subtask(
            index=1, total=2,
            goal_text=f"clone {url} into {target}",
            prompt=(
                f"Run exactly this command and nothing else: "
                f"git clone {url} {target} . Then reply 'done'."
            ),
            predicate_name="dir_has_git",
            predicate_args={"target": target},
        ),
        Subtask(
            index=2, total=2,
            goal_text=f"read README in {target}",
            prompt=(
                f"The repository is already cloned at {target}. "
                f"Read the README file inside that directory and tell "
                f"me what it contains in one sentence. Reply 'done' after."
            ),
            predicate_name="readme_surfaced_in_tail",
            predicate_args={"target": target},
        ),
    ]


def _match_find_and_fix(prompt: str) -> list[Subtask] | None:
    """Pattern: 'Find and fix the syntax error in <file>'"""
    m = _FIND_FIX_PAT.search(prompt)
    if not m:
        return None
    path = m.group("path")
    return [
        Subtask(
            index=1, total=3,
            goal_text=f"read {path}",
            prompt=(
                f"Read the file {path} using read_file and quote back "
                f"the exact line number that has a syntax error. Reply "
                f"'done' once you've identified it. Do NOT edit yet."
            ),
            predicate_name="file_was_read",
            predicate_args={"path": path},
        ),
        Subtask(
            index=2, total=3,
            goal_text=f"edit {path} to fix",
            prompt=(
                f"Now use edit_file on {path} to fix the syntax error "
                f"you identified. Make the smallest possible change. "
                f"Reply 'done' once edited."
            ),
            predicate_name="file_was_modified",
            predicate_args={"path": path},
        ),
        Subtask(
            index=3, total=3,
            goal_text=f"verify {path} compiles",
            prompt=(
                f"Run: python -c \"import py_compile; "
                f"py_compile.compile(r'{path}', doraise=True); print('OK')\" "
                f"and reply 'done' if it printed OK, otherwise reply with "
                f"the error and stop."
            ),
            predicate_name="file_compiles_clean",
            predicate_args={"path": path},
        ),
    ]


def _match_git_init_commit(prompt: str) -> list[Subtask] | None:
    """Pattern: 'Set up <dir>: git init, write README, git add, git commit'"""
    m = _GIT_SETUP_PAT.search(prompt)
    if not m:
        return None
    p_low = prompt.lower()
    if "git init" not in p_low or "commit" not in p_low:
        return None
    target = m.group("target").rstrip(":").rstrip(".")
    return [
        Subtask(
            index=1, total=4,
            goal_text=f"git init at {target}",
            prompt=(
                # Round-93: `git init <path>` does mkdir+init in one
                # call. Previous chained `mkdir -p && cd && git init`
                # caused free models to hang at subtask 1 (r93 final
                # SKIP at 205s). Single-purpose command is reliable.
                f"Run exactly this single bash command and nothing else: "
                f"git init {target} . Reply 'done' after."
            ),
            predicate_name="dir_has_git",
            predicate_args={"target": target},
        ),
        Subtask(
            index=2, total=4,
            goal_text=f"write README at {target}/README.md",
            prompt=(
                f"Use write_file to create {target}/README.md with the "
                f"content '# demo-project'. Reply 'done' after."
            ),
            predicate_name="readme_file_exists",
            predicate_args={"target": target},
        ),
        Subtask(
            index=3, total=4,
            goal_text=f"git add README.md in {target}",
            prompt=(
                # Round-93: cwd MUST be explicit. r93 dump showed
                # the model ran `git add README.md .` in the agent's
                # cwd (PrometheUS repo root) and timed out staging
                # 1000s of files. `cd` makes it unambiguous.
                f"Run exactly this single bash command and nothing else: "
                f"cd {target} && git add README.md . Reply 'done' after."
            ),
            predicate_name="readme_staged",
            predicate_args={"target": target},
        ),
        Subtask(
            index=4, total=4,
            goal_text=f"git commit in {target}",
            prompt=(
                f"Run exactly this single bash command and nothing else: "
                f"cd {target} && "
                f"git commit --no-gpg-sign -m \"initial commit\" . "
                f"Reply 'done' after."
            ),
            predicate_name="git_log_has_initial_commit",
            predicate_args={"target": target},
        ),
    ]


_PATTERNS = (
    _match_clone_and_read,     # Task 6
    _match_find_and_fix,       # Task 7
    _match_git_init_commit,    # Task 8
)


def decompose(prompt: str) -> list[Subtask] | None:
    """Decompose a multi-step prompt into single-step subtasks.

    Returns None if no pattern matches — caller should fall back to
    the existing single-loop path. Returns list[Subtask] (always
    length >= 2) when a known pattern fires.

    Round 87: heuristic-only. Round 88+ may add an LLM-decomposer
    fallback for novel patterns.
    """
    if not prompt or len(prompt.strip()) < 10:
        return None
    for matcher in _PATTERNS:
        result = matcher(prompt)
        if result and len(result) >= 2:
            return result
    return None


def is_enabled() -> bool:
    """Round-87 ships opt-in. Caller checks this before invoking
    decompose() so the existing single-loop path remains the default."""
    import os
    return os.getenv("PROMETHEUS_DECOMPOSE") == "1"
