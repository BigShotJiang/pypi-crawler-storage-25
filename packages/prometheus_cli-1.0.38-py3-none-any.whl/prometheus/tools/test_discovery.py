"""Round-95 turn-6: discover_test_command tool.

Wraps the deterministic helper in `prometheus.agent.test_discovery` as
a registered tool the model can invoke. Replaces the LLM-driven loop
of read_file/glob_files that used to take ~50s and 5 iterations to
arrive at `python -m pytest -q`.
"""
from __future__ import annotations

from typing import Any

from prometheus.agent.test_discovery import (
    discover_test_command,
    render_for_model,
)
from prometheus.tools.base import (
    SideEffect,
    Tool,
    ToolContext,
    ToolResult,
)


class DiscoverTestCommand(Tool):
    name = "discover_test_command"
    description = (
        "Deterministically pick the right test command for the current "
        "project by reading well-known config files (pyproject.toml, "
        "pytest.ini, tox.ini, setup.cfg, Makefile, package.json, Cargo.toml, "
        "go.mod). Returns ONE command with a short reason and the evidence "
        "used. Use this BEFORE running tests instead of inspecting config "
        "files manually with read_file/glob_files."
    )
    side_effect = SideEffect.READ
    schema = {
        "type": "object",
        "properties": {},
        "additionalProperties": False,
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        # Round-95 turn-7: public-facing label. The previous render
        # showed the raw tool name ("discover_test_command") which read
        # as debug output. Use commercial language instead — the user
        # sees what the tool DID, not what it was named in code.
        return "Selected test command"

    async def execute(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult:
        # Round-95 turn-8: bullet-proof against ANY exception. Smoke 4
        # turn-7 retest showed `parallel crash` summaries leaking into
        # the chat — a sign that something inside execute() (or the
        # agent-loop's pre-call prologue) raised before the standard
        # `tool crashed: {e}` handler could fire. We catch absolutely
        # everything here so the worst-case failure mode is a clean
        # tool-error message ("Could not auto-detect test command")
        # instead of internal-debug language in the timeline.
        try:
            d = discover_test_command(ctx.workdir)
        except Exception as e:
            try:
                ctx.audit("discover_test_command", {"error": repr(e)})
            except Exception:
                pass
            return ToolResult(
                output=(
                    f"Could not auto-detect the test command: {e!s}\n"
                    f"Fallback: try `python -m pytest -q` if pytest is "
                    f"installed and you're in a Python project."
                ),
                summary="Could not auto-detect test command",
                error=True,
                metadata={
                    "kind":  "discovery",
                    "error": str(e),
                    # Suggest a safe fallback the agent loop can rerun.
                    "fallback_command": "python -m pytest -q",
                },
            )
        try:
            ctx.audit("discover_test_command", {
                "command":    d.command,
                "confidence": d.confidence,
                "evidence":   d.evidence,
            })
        except Exception:
            # Audit hiccups must never crash the tool — round-22 had
            # the same fix for run_bash. Best-effort, never propagate.
            pass
        # Round-95 turn-7: clean public summary. The previous form
        # `{cmd} · {confidence} confidence` leaked internal scoring into
        # the chat timeline. Confidence stays in metadata for audit /
        # debug consumers but never reaches the default chat renderer.
        return ToolResult(
            output=render_for_model(d),
            summary=d.command,
            metadata={
                # Round-95 turn-7: use a discovery-specific key
                # (`chosen_command`) so the bash-style execution
                # receipt renderer never matches on this result. The
                # bash receipt expects a full execution shape (exit /
                # duration / cwd) which a discovery-only call doesn't
                # have — feeding it a partial dict produced the broken
                # `? · cwd=` row the user reported.
                "kind":           "discovery",
                "chosen_command": d.command,
                "why":            d.why,
                "source":         d.why,
                "risk":           d.risk,
                "confidence":     d.confidence,
                "evidence":       d.evidence,
            },
        )
