"""ComputerUse — model-facing Tool wrapper for the macOS-only
Computer-Use MCP server.

Conditional registration: the `tools/registry.py` builder checks
`computer_use_mcp.is_supported()` (True only on darwin) before
registering this Tool. On Linux / Windows / WSL the tool is
never advertised, so the agent never sees it.

The Tool dispatches to `prometheus.tools.computer_use_mcp` and
maps each operation onto a single MCP-shaped call. Permission
gating: every operation is treated as `EXEC` so the
PermissionMode workflow asks before it fires.
"""
from __future__ import annotations

from typing import Any

from prometheus.tools.base import (
    SideEffect,
    Tool,
    ToolContext,
    ToolResult,
)


VALID_OPERATIONS = (
    "screenshot", "find_by_label", "click", "type_text", "scroll",
)


class ComputerUse(Tool):
    name = "computer_use"
    description = (
        "macOS computer-use control. Take a screenshot, locate UI "
        "elements by label, click, type, scroll. Requires "
        "Accessibility + Screen Recording permissions in macOS "
        "System Settings."
    )
    side_effect = SideEffect.EXEC
    is_destructive = False
    schema = {
        "type": "object",
        "properties": {
            "operation": {
                "type": "string",
                "enum": list(VALID_OPERATIONS),
                "description": (
                    "screenshot — capture full desktop. "
                    "find_by_label — locate UI element by AX "
                    "title / value / description. "
                    "click — synthesize a click at (x, y). "
                    "type_text — synthesize keystrokes. "
                    "scroll — vertical scroll at (x, y)."
                ),
            },
            "label": {"type": "string"},        # find_by_label
            "x": {"type": "number"},            # click / scroll
            "y": {"type": "number"},            # click / scroll
            "button": {                         # click
                "type": "string",
                "enum": ["left", "right"],
                "default": "left",
            },
            "text": {"type": "string"},         # type_text
            "amount": {"type": "integer"},      # scroll
        },
        "required": ["operation"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        op = args.get("operation", "?")
        return f"ComputerUse({op})"

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        op = str(args.get("operation", "")).strip().lower()
        if op not in VALID_OPERATIONS:
            return ToolResult(
                output=(
                    f"unknown operation {op!r}. Valid: "
                    f"{', '.join(VALID_OPERATIONS)}"
                ),
                error=True,
                summary="bad operation",
            )
        # Approval gate. Even in acceptEdits mode, screen-capture
        # and synthesized clicks are out-of-band side effects —
        # the user should confirm before each.
        try:
            ok = await ctx.request_approval(
                "computer_use",
                f"computer_use {op}\n{_summarize(args)}",
            )
        except Exception:
            ok = False
        if not ok:
            return ToolResult(
                output="user denied computer_use call",
                error=True,
                summary="denied",
            )
        from prometheus.tools import computer_use_mcp as _mcp
        # Dispatch.
        if op == "screenshot":
            r = _mcp.screenshot()
        elif op == "find_by_label":
            r = _mcp.find_by_label(str(args.get("label", "")))
        elif op == "click":
            r = _mcp.click(
                float(args.get("x", 0)),
                float(args.get("y", 0)),
                button=str(args.get("button", "left")),
            )
        elif op == "type_text":
            r = _mcp.type_text(str(args.get("text", "")))
        elif op == "scroll":
            r = _mcp.scroll(
                float(args.get("x", 0)),
                float(args.get("y", 0)),
                int(args.get("amount", 0)),
            )
        else:
            # Belt-and-suspenders — already validated above.
            return ToolResult(
                output=f"unhandled operation {op!r}",
                error=True, summary="unhandled",
            )
        if not r.ok:
            return ToolResult(
                output=r.message or "computer_use failed",
                error=True,
                summary=f"{op} failed",
                metadata={"operation": op, "payload": r.payload or {}},
            )
        return ToolResult(
            output=r.message or f"{op} OK",
            error=False,
            summary=f"{op} ok",
            metadata={"operation": op, "payload": r.payload or {}},
        )


def _summarize(args: dict[str, Any]) -> str:
    op = args.get("operation", "")
    if op == "find_by_label":
        return f"label: {args.get('label', '')[:60]}"
    if op == "click":
        return (
            f"button: {args.get('button', 'left')} at "
            f"({args.get('x', 0)},{args.get('y', 0)})"
        )
    if op == "type_text":
        snippet = str(args.get("text", ""))[:40]
        return f"text: {snippet!r}"
    if op == "scroll":
        return (
            f"amount: {args.get('amount', 0)} at "
            f"({args.get('x', 0)},{args.get('y', 0)})"
        )
    return ""
