"""apply_patch: apply a unified diff to one or more files in one shot.

Closes the workflow gap with Cursor / Aider / Claude Code where the
model proposes a diff and the agent applies it directly — instead of
forcing the model to re-emit `edit_file` calls per hunk. Critically:
each hunk is validated against the current file content BEFORE we
commit any change, so a stale diff fails atomically rather than
half-applying.

Diff format: standard unified diff. Multiple files are supported in one
call as long as each file block is properly delimited with `--- a/path`
and `+++ b/path`. New-file hunks (`--- /dev/null`) and deletes
(`+++ /dev/null`) work too.

The model gets one approval prompt per call (with the full diff
preview) — not one per file — so /apply_patch feels like a single
checkpoint operation. /rewind restores all files touched by the patch.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from prometheus.tools.base import (
    PermissionDenied,
    SideEffect,
    Tool,
    ToolContext,
    ToolResult,
)
from prometheus.tools.files import _atomic_write_text, _resolve


def _split_per_file(diff: str) -> list[tuple[str, str, str]]:
    """Split a multi-file unified diff into [(path, kind, body), ...].

    `kind` is "modify" / "create" / "delete" depending on the --- / +++
    lines. We split on `--- ` boundaries — anything before the first
    such line is dropped (some tools print a `diff --git` header).
    """
    lines = diff.splitlines(keepends=True)
    out: list[tuple[str, str, str]] = []
    i = 0
    while i < len(lines):
        if not lines[i].startswith("--- "):
            i += 1
            continue
        # Find the matching +++ line.
        if i + 1 >= len(lines) or not lines[i + 1].startswith("+++ "):
            i += 1
            continue
        a = lines[i][4:].strip()
        b = lines[i + 1][4:].strip()
        # Determine kind + canonical path.
        if a == "/dev/null":
            kind = "create"
            path = b[2:] if b.startswith("b/") else b
        elif b == "/dev/null":
            kind = "delete"
            path = a[2:] if a.startswith("a/") else a
        else:
            kind = "modify"
            path = b[2:] if b.startswith("b/") else b
        # Body runs until the next `--- ` line.
        j = i + 2
        while j < len(lines) and not lines[j].startswith("--- "):
            j += 1
        body = "".join(lines[i:j])
        out.append((path, kind, body))
        i = j
    return out


def _detect_eol(text: str) -> str:
    """Heuristic line-ending detection on the first ~64 KB.

    Returns "\\r\\n" if CRLF dominates, "\\n" otherwise. Used so an
    apply_patch operation preserves the file's existing line endings
    even if the diff itself was generated on a different platform —
    audit P0: a Windows-generated CRLF diff applied to an LF file
    silently rewrote every line and showed up as a noisy git diff.
    """
    sample = text[:65536]
    crlf = sample.count("\r\n")
    lf = sample.count("\n") - crlf  # bare LFs that aren't part of CRLF
    return "\r\n" if crlf > lf else "\n"


def _lines_match(actual: str, expected: str) -> bool:
    """Progressive whitespace tolerance — Cursor/V4A behavior.

    Try exact match first, then trim trailing newlines, then trim all
    whitespace. The model's view of a file routinely drifts from disk
    by a single trailing space or CRLF/LF mismatch; without progressive
    matching these "off by whitespace" patches fail at the strictness
    layer when they should apply cleanly.
    """
    if actual == expected:
        return True
    # Trim line endings only.
    if actual.rstrip("\r\n") == expected.rstrip("\r\n"):
        return True
    # Last-resort: collapse all internal whitespace runs and compare.
    # This is the V4A "trim all whitespace" tier.
    a = " ".join(actual.split())
    e = " ".join(expected.split())
    return a == e


def _apply_hunks(original: str, patch_body: str) -> tuple[str | None, str]:
    """Apply unified-diff hunks (`@@ ... @@`) to `original`. Returns
    (new_text, error). new_text is None on failure."""
    original_lines = original.splitlines(keepends=True)
    out_lines: list[str] = []
    src_idx = 0  # cursor into original_lines

    body_lines = patch_body.splitlines(keepends=True)
    i = 0
    # Skip --- and +++ headers (already parsed by caller).
    while i < len(body_lines) and not body_lines[i].startswith("@@"):
        i += 1

    while i < len(body_lines):
        line = body_lines[i]
        if not line.startswith("@@"):
            i += 1
            continue
        # Parse header: @@ -<oldstart>[,<oldlen>] +<newstart>[,<newlen>] @@
        header = line.rstrip("\n")
        try:
            spec = header.split("@@")[1].strip()
            old_part, _, _ = spec.partition(" +")
            old_start_s = old_part.lstrip("-").split(",")[0]
            old_start = int(old_start_s)
        except (IndexError, ValueError):
            return None, f"malformed hunk header: {header!r}"
        # Copy unchanged lines up to old_start (1-based).
        target = max(0, old_start - 1)
        while src_idx < target:
            if src_idx >= len(original_lines):
                return None, f"hunk targets line {old_start} but file has only {len(original_lines)}"
            out_lines.append(original_lines[src_idx])
            src_idx += 1
        # Walk the hunk body.
        i += 1
        while i < len(body_lines) and not body_lines[i].startswith("@@"):
            row = body_lines[i]
            if row.startswith(" "):
                # context — must match the file (progressive whitespace ladder)
                expected = row[1:]
                if src_idx >= len(original_lines):
                    return None, f"context line past EOF: {expected!r}"
                if not _lines_match(original_lines[src_idx], expected):
                    return None, (
                        f"context mismatch at line {src_idx+1}:\n"
                        f"  expected: {expected.rstrip()!r}\n"
                        f"  actual:   {original_lines[src_idx].rstrip()!r}"
                    )
                out_lines.append(original_lines[src_idx])
                src_idx += 1
            elif row.startswith("-"):
                expected = row[1:]
                if src_idx >= len(original_lines):
                    return None, f"deletion past EOF: {expected!r}"
                if not _lines_match(original_lines[src_idx], expected):
                    return None, (
                        f"deletion mismatch at line {src_idx+1}:\n"
                        f"  expected: {expected.rstrip()!r}\n"
                        f"  actual:   {original_lines[src_idx].rstrip()!r}"
                    )
                src_idx += 1
            elif row.startswith("+"):
                # New line — synthesize \n if not already present.
                added = row[1:]
                if not added.endswith("\n"):
                    added = added + "\n"
                out_lines.append(added)
            elif row.startswith("\\"):
                # "\ No newline at end of file" — drop trailing \n on the
                # last out_line / honor the original.
                if out_lines and out_lines[-1].endswith("\n"):
                    out_lines[-1] = out_lines[-1].rstrip("\n")
            else:
                # blank line (some tools emit naked blanks for context)
                if src_idx < len(original_lines):
                    out_lines.append(original_lines[src_idx])
                    src_idx += 1
            i += 1
    # Copy any trailing unchanged lines.
    while src_idx < len(original_lines):
        out_lines.append(original_lines[src_idx])
        src_idx += 1
    return "".join(out_lines), ""


class ApplyPatch(Tool):
    name = "apply_patch"
    description = (
        "Apply a unified diff to one or more files atomically. The diff "
        "must use standard `--- a/file` / `+++ b/file` headers and `@@` "
        "hunk markers. Use /dev/null on either side for create/delete. "
        "Validates context lines against current file content; aborts "
        "without touching disk if any hunk fails. Multiple files in one "
        "call get a single approval prompt."
    )
    side_effect = SideEffect.WRITE
    schema = {
        "type": "object",
        "properties": {
            "patch": {
                "type": "string",
                "description": "unified diff text",
            },
        },
        "required": ["patch"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        # Show first file path so the receipt isn't generic "Patch".
        text = str(args.get("patch", ""))
        for line in text.splitlines():
            if line.startswith("+++ "):
                tail = line[4:].strip()
                tail = tail[2:] if tail.startswith("b/") else tail
                tail = Path(tail).name or tail
                return f"ApplyPatch({tail})"
        return "ApplyPatch"

    async def execute(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult:
        if (r := ctx.plan_mode_refusal("apply_patch")):
            return r
        patch = str(args.get("patch", ""))
        if not patch.strip():
            return ToolResult(output="empty patch", error=True, summary="empty")
        files = _split_per_file(patch)
        if not files:
            return ToolResult(
                output="no `--- a/...` / `+++ b/...` headers found — is this a unified diff?",
                error=True,
                summary="no headers",
            )
        # Phase 1: dry-run all hunks to verify the diff applies cleanly.
        plans: list[tuple[Path, str, str | None, str | None]] = []
        # tuple: (resolved_path, kind, before_text, after_text)
        for rel, kind, body in files:
            path = _resolve(ctx.workdir, rel)
            if kind == "create":
                if path.exists():
                    return ToolResult(
                        output=f"create-file hunk targets existing path: {path}",
                        error=True,
                        summary="create over existing",
                    )
                # The hunk should have a single +++ block of additions.
                added: list[str] = []
                for ln in body.splitlines():
                    if ln.startswith("+") and not ln.startswith("+++"):
                        added.append(ln[1:])
                plans.append((path, "create", None, "\n".join(added) + ("\n" if added else "")))
                continue
            if kind == "delete":
                if not path.exists():
                    return ToolResult(
                        output=f"delete-file hunk targets missing path: {path}",
                        error=True,
                        summary="delete missing",
                    )
                before = path.read_text(encoding="utf-8", errors="replace")
                plans.append((path, "delete", before, None))
                continue
            # modify
            if not path.exists():
                return ToolResult(
                    output=f"modify-file hunk targets missing path: {path}",
                    error=True,
                    summary="modify missing",
                )
            before = path.read_text(encoding="utf-8", errors="replace")
            after, err = _apply_hunks(before, body)
            if after is None:
                return ToolResult(
                    output=f"patch failed for {path}:\n{err}",
                    error=True,
                    summary="hunk mismatch",
                )
            # Preserve the file's existing line endings. _apply_hunks
            # works on splitlines(keepends=True) which keeps whatever
            # line ending each line had, but added lines are normalized
            # to '\n'. Re-normalize the final text to match the
            # dominant EOL of the original file (audit P0: cross-platform
            # diffs were silently rewriting every line ending).
            target_eol = _detect_eol(before)
            if target_eol == "\r\n":
                # Convert any bare LFs (newly-added lines) to CRLF
                # without touching existing CRLFs.
                normalized = after.replace("\r\n", "\n").replace("\n", "\r\n")
                after = normalized
            else:
                # Convert any CRLFs introduced by a Windows-generated
                # diff back to LF so the file stays clean.
                after = after.replace("\r\n", "\n")
            plans.append((path, "modify", before, after))

        # Phase 2: ask for approval (single prompt for the whole diff).
        if ctx.permission_mode not in ("acceptEdits", "skipAll"):
            preview = patch if len(patch) <= 4000 else patch[:4000] + "\n…(truncated)"
            summary_lines = [
                f"{kind} {p.relative_to(ctx.workdir) if p.is_relative_to(ctx.workdir) else p}"
                for p, kind, _, _ in plans
            ]
            detail = (
                f"apply patch to {len(plans)} file(s):\n  "
                + "\n  ".join(summary_lines)
                + "\n---\n"
                + preview
            )
            ok = await ctx.request_approval("apply_patch", detail)
            if not ok:
                raise PermissionDenied(f"user denied apply_patch ({len(plans)} files)")

        # Phase 3: write. Snapshot per file for /rewind.
        applied = 0
        for path, kind, before, after in plans:
            ctx.snapshots.append({
                "kind": "apply_patch",
                "path": str(path),
                "before": before,
                "after": after,
            })
            if kind == "delete":
                try:
                    path.unlink()
                except OSError as e:
                    return ToolResult(
                        output=f"unlink failed for {path}: {e}",
                        error=True,
                        summary="unlink failed",
                    )
            else:
                path.parent.mkdir(parents=True, exist_ok=True)
                _atomic_write_text(path, after or "")
            applied += 1

        ctx.audit("apply_patch", {"files": [str(p) for p, *_ in plans]})
        return ToolResult(
            output=f"applied patch to {applied} file(s):\n  "
                   + "\n  ".join(str(p) for p, *_ in plans),
            summary=f"{applied} file{'s' if applied != 1 else ''}",
        )
