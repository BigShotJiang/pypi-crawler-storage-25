"""Round 101 (Phase 4): TaskCreate / TaskUpdate / TaskGet / TaskList
tools — the four explicit task tools per the Phase-4 spec.

These wrap `prometheus.agent.worklog.WorkLog`. The persistent
storage lives at `<workdir>/.prometheus/worklog.json` so resumed
sessions and dispatched cohorts share the same task list.
"""
from __future__ import annotations

from typing import Any

from prometheus.tools.base import (
    SideEffect,
    Tool,
    ToolContext,
    ToolResult,
)


# ---------- TaskCreate ----------


class TaskCreate(Tool):
    name = "task_create"
    description = (
        "Create a new task in the project Work Log. Returns the "
        "task id. Tasks coordinate work across the main agent, "
        "background cohorts, and team teammates."
    )
    side_effect = SideEffect.WRITE
    schema = {
        "type": "object",
        "properties": {
            "subject": {
                "type": "string",
                "description": "Short imperative title.",
            },
            "description": {
                "type": "string",
                "description": "Optional longer description.",
            },
            "dependencies": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Task ids that must finish first.",
            },
            "owner": {
                "type": "string",
                "description": (
                    "main / cohort:<id> / team:<lead-id>. "
                    "Defaults to 'main'."
                ),
            },
        },
        "required": ["subject"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        subject = str(args.get("subject", "")).strip()
        return f"TaskCreate({subject[:60]})"

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        subject = str(args.get("subject", "")).strip()
        if not subject:
            return ToolResult(
                output="subject required", error=True,
                summary="empty subject",
            )
        from prometheus.agent.worklog import WorkLog
        log = WorkLog.load(ctx.workdir)
        item = log.create(
            subject=subject,
            description=str(args.get("description", "")).strip(),
            dependencies=list(args.get("dependencies") or []),
            owner=str(args.get("owner") or "main"),
        )
        return ToolResult(
            output=f"created task {item.id}: {subject}",
            summary=f"created · {item.id}",
            metadata={"task_id": item.id},
        )


# ---------- TaskUpdate ----------


class TaskUpdate(Tool):
    name = "task_update"
    description = (
        "Update a task: change status (pending/in_progress/"
        "completed/failed/cancelled), edit subject/description, "
        "add a dependency or note."
    )
    side_effect = SideEffect.WRITE
    schema = {
        "type": "object",
        "properties": {
            "id": {"type": "string"},
            "status": {
                "type": "string",
                "enum": [
                    "pending", "in_progress", "completed",
                    "failed", "cancelled",
                ],
            },
            "subject": {"type": "string"},
            "description": {"type": "string"},
            "owner": {"type": "string"},
            "add_dependency": {"type": "string"},
            "add_note": {"type": "string"},
        },
        "required": ["id"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        return f"TaskUpdate({args.get('id', '?')})"

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        item_id = str(args.get("id", "")).strip()
        if not item_id:
            return ToolResult(
                output="id required", error=True, summary="empty id",
            )
        from prometheus.agent.worklog import WorkLog
        log = WorkLog.load(ctx.workdir)
        item = log.update(
            item_id,
            status=args.get("status"),
            subject=args.get("subject"),
            description=args.get("description"),
            owner=args.get("owner"),
            add_dependency=args.get("add_dependency"),
            add_note=args.get("add_note"),
        )
        if item is None:
            return ToolResult(
                output=f"no task with id {item_id!r}",
                error=True, summary="not found",
            )
        return ToolResult(
            output=(
                f"updated {item_id} → status={item.status} "
                f"subject={item.subject!r}"
            ),
            summary=f"{item.status} · {item_id}",
            metadata={"task_id": item_id, "status": item.status},
        )


# ---------- TaskGet ----------


class TaskGet(Tool):
    name = "task_get"
    description = "Retrieve full details of a task by id."
    side_effect = SideEffect.READ
    schema = {
        "type": "object",
        "properties": {"id": {"type": "string"}},
        "required": ["id"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        return f"TaskGet({args.get('id', '?')})"

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        item_id = str(args.get("id", "")).strip()
        from prometheus.agent.worklog import WorkLog
        log = WorkLog.load(ctx.workdir)
        item = log.get(item_id)
        if item is None:
            return ToolResult(
                output=f"no task with id {item_id!r}",
                error=True, summary="not found",
            )
        lines = [
            f"id: {item.id}",
            f"subject: {item.subject}",
            f"status: {item.status}",
            f"owner: {item.owner}",
            f"created_at: {item.created_at}",
            f"updated_at: {item.updated_at}",
        ]
        if item.description:
            lines.append(f"description: {item.description}")
        if item.dependencies:
            lines.append(f"dependencies: {', '.join(item.dependencies)}")
        if item.notes:
            lines.append("notes:")
            for n in item.notes:
                lines.append(f"  · {n}")
        return ToolResult(
            output="\n".join(lines),
            summary=f"{item.status} · {item.id}",
            metadata={"task_id": item.id, "status": item.status},
        )


# ---------- TaskList ----------


class TaskList(Tool):
    name = "task_list"
    description = (
        "List all tasks in the Work Log. Optional `status` filter."
    )
    side_effect = SideEffect.READ
    schema = {
        "type": "object",
        "properties": {
            "status": {
                "type": "string",
                "enum": [
                    "pending", "in_progress", "completed",
                    "failed", "cancelled",
                ],
            },
        },
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        status = args.get("status", "")
        suffix = f" status={status}" if status else ""
        return f"TaskList({suffix})"

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        status = args.get("status")
        from prometheus.agent.worklog import WorkLog
        log = WorkLog.load(ctx.workdir)
        items = log.list(status=status)
        if not items:
            return ToolResult(
                output="(no tasks)", summary="0 tasks",
            )
        lines = [
            f"{it.status:<12} {it.id}  {it.owner:<14} {it.subject}"
            for it in items
        ]
        summary = log.summary()
        head = (
            f"{len(items)} task(s) · "
            f"{summary.get('pending', 0)} pending, "
            f"{summary.get('in_progress', 0)} in progress, "
            f"{summary.get('completed', 0)} completed"
        )
        return ToolResult(
            output=head + "\n" + "\n".join(lines),
            summary=head,
        )
