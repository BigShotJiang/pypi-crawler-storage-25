"""bash_output + kill_shell — model-callable counterparts to /bashes.

These are what unlock real dev workflows for the agent: start
`npm run dev` in the background, run tests, poll the dev-server log,
fix the failure, kill the server.

Without them, run_bash is foreground-only and the model has to wait up
to 900s for any single command. With them, the model can keep watchers
alive and check on them when needed.
"""
from __future__ import annotations

from typing import Any

from prometheus.tools.base import (
    SideEffect,
    Tool,
    ToolContext,
    ToolResult,
)


class BashOutput(Tool):
    name = "bash_output"
    description = (
        "Read new stdout/stderr from a backgrounded shell (one started via "
        "run_bash with run_in_background=true). Returns ONLY output that "
        "appeared since the last bash_output call for this shell_id, plus "
        "a status line. Use to poll dev servers, watchers, or anything "
        "running in the background."
    )
    side_effect = SideEffect.READ
    # Round 174: schema accepts Claude Code's `bash_id` (preferred)
    # and `filter` (regex applied to new output), in addition to the
    # native `shell_id` / `max_chars` names. CC-trained models that
    # passed `bash_id` were getting "shell_id required" errors.
    schema = {
        "type": "object",
        "properties": {
            "bash_id": {
                "type": "string",
                "description": "shell id returned by a previous run_bash (preferred)",
            },
            "shell_id": {
                "type": "string",
                "description": "alias for bash_id",
            },
            "filter": {
                "type": "string",
                "description": (
                    "Optional regex; only lines matching are returned. "
                    "Empty / omitted means no filter."
                ),
            },
            "max_chars": {
                "type": "integer",
                "default": 16_000,
                "description": "cap on returned output size",
            },
        },
        "required": ["bash_id"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        sid = args.get("bash_id") or args.get("shell_id", "?")
        return f"BashOutput({sid})"

    async def execute(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult:
        # Round 174: prefer bash_id, fall back to shell_id.
        sid = str(args.get("bash_id") or args.get("shell_id") or "").strip()
        if not sid:
            return ToolResult(
                output="bash_id required (alias: shell_id)",
                error=True, summary="empty",
            )
        app = getattr(ctx.runtime, "app", None) if ctx.runtime else None
        if app is None or not hasattr(app, "bg_jobs"):
            return ToolResult(
                output="bg job registry unavailable",
                error=True,
                summary="no registry",
            )
        job = app.bg_jobs.get(sid)
        if job is None:
            return ToolResult(
                output=f"no shell with id {sid!r} (use /bashes to list)",
                error=True,
                summary="not found",
            )
        max_chars = max(512, min(64_000, int(args.get("max_chars", 16_000))))
        new = job.read_new(max_chars=max_chars)
        # Round 174: optional regex filter — Claude Code semantics.
        # Lines matching the supplied regex are kept; non-matching
        # are dropped. Invalid regex is reported as a tool error so
        # the model can self-correct.
        filt = str(args.get("filter") or "").strip()
        if filt and new:
            import re as _re
            try:
                rx = _re.compile(filt)
            except _re.error as e:
                return ToolResult(
                    output=f"invalid regex in filter: {e}",
                    error=True, summary="bad regex",
                )
            new = "\n".join(line for line in new.splitlines() if rx.search(line))
        status = "running"
        if job.finished:
            status = f"exited {job.exit_code}"
        out = (
            f"shell_id: {sid} · status: {status} · {job.elapsed}s elapsed\n"
            f"--- new output ---\n{new or '(no new output)'}"
        )
        return ToolResult(
            output=out,
            summary=f"{status} · {len(new)} new chars",
            error=job.finished and (job.exit_code or 0) != 0,
        )


class KillShell(Tool):
    name = "kill_shell"
    description = (
        "Terminate a backgrounded shell by shell_id. Use after a dev "
        "server / watcher is no longer needed, or when a command is "
        "wedged. Idempotent — already-finished shells return ok."
    )
    side_effect = SideEffect.EXEC
    schema = {
        "type": "object",
        "properties": {
            "shell_id": {
                "type": "string",
                "description": "shell_id returned by a previous run_bash call",
            },
        },
        "required": ["shell_id"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        return f"KillShell({args.get('shell_id', '?')})"

    async def execute(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult:
        sid = str(args.get("shell_id", "")).strip()
        if not sid:
            return ToolResult(output="shell_id required", error=True, summary="empty")
        app = getattr(ctx.runtime, "app", None) if ctx.runtime else None
        if app is None or not hasattr(app, "bg_jobs"):
            return ToolResult(
                output="bg job registry unavailable",
                error=True,
                summary="no registry",
            )
        ok = await app.bg_jobs.kill(sid)
        if not ok:
            return ToolResult(
                output=f"no shell with id {sid!r}",
                error=True,
                summary="not found",
            )
        ctx.audit("kill_shell", {"shell_id": sid})
        return ToolResult(output=f"killed {sid}", summary="killed")
