"""Round 123: Monitor tool — stream a background process's
stdout/stderr as system messages.

Useful for build watchers, deployment logs, test watchers, CI
streams. The agent dispatches `monitor` with a shell command;
the tool spawns the process, returns immediately, and streams
output lines into the conversation as dim system text.

Limits:
  * Max 1 active Monitor per session (configurable via
    PROMETHEUS_MAX_MONITORS).
  * Auto-stops when the session exits.
  * `monitor.stop` kills the process explicitly.
"""
from __future__ import annotations

import asyncio
import os
import sys
from dataclasses import dataclass, field
from typing import Any, Optional

from prometheus.tools.base import (
    SideEffect,
    Tool,
    ToolContext,
    ToolResult,
)


def max_monitors() -> int:
    try:
        return max(1, int(os.environ.get("PROMETHEUS_MAX_MONITORS", "1")))
    except (TypeError, ValueError):
        return 1


@dataclass
class MonitorJob:
    """Round 123: live monitor process."""
    monitor_id: str
    command: str
    proc: Any
    notify: Any              # `notify(msg)` callable for streaming output
    started_at: float
    lines_emitted: int = 0
    stopped: bool = False


class MonitorRegistry:
    """In-memory pool of live Monitor jobs. One instance per
    PrometheusApp."""

    def __init__(self) -> None:
        self.jobs: dict[str, MonitorJob] = {}

    def list(self) -> list[MonitorJob]:
        return list(self.jobs.values())

    def get(self, monitor_id: str) -> Optional[MonitorJob]:
        return self.jobs.get(monitor_id)

    def active_count(self) -> int:
        return sum(1 for j in self.jobs.values() if not j.stopped)

    async def stop(self, monitor_id: str) -> tuple[bool, str]:
        job = self.jobs.get(monitor_id)
        if job is None:
            return False, f"no monitor with id {monitor_id!r}"
        if job.stopped:
            return False, "monitor already stopped"
        try:
            if job.proc.returncode is None:
                job.proc.kill()
                try:
                    await asyncio.wait_for(job.proc.wait(), timeout=3)
                except asyncio.TimeoutError:
                    pass
        except Exception:
            pass
        job.stopped = True
        return True, f"monitor {monitor_id} stopped"

    async def stop_all(self) -> int:
        n = 0
        for mid in list(self.jobs.keys()):
            ok, _ = await self.stop(mid)
            if ok:
                n += 1
        return n


# ---------- the Tool ----------


class Monitor(Tool):
    name = "monitor"
    description = (
        "Run a shell command in the background and stream its "
        "stdout/stderr lines as dim system messages. Useful for "
        "build watchers, deploy logs, test runners. "
        "`monitor.stop <id>` kills the process. "
        "Max one active monitor per session."
    )
    side_effect = SideEffect.EXEC
    is_destructive = False
    schema = {
        "type": "object",
        "properties": {
            "command": {
                "type": "string",
                "description": "Shell command to run.",
            },
            "stop": {
                "type": "string",
                "description": (
                    "Monitor id to stop. When set, the tool stops "
                    "the named monitor instead of starting a new one."
                ),
            },
        },
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        if args.get("stop"):
            return f"Monitor.stop({args.get('stop')})"
        cmd = str(args.get("command", "")).strip().split("\n", 1)[0]
        return f"Monitor({cmd[:60]}{'…' if len(cmd) > 60 else ''})"

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        runtime = getattr(ctx, "runtime", None)
        app = getattr(runtime, "app", None) if runtime else None
        registry: Optional[MonitorRegistry] = (
            getattr(app, "monitors", None) if app else None
        )
        # Some test contexts run without a full app — make a
        # standalone registry so the tool stays exercisable.
        if registry is None:
            registry = MonitorRegistry()
            if app is not None:
                app.monitors = registry  # type: ignore[attr-defined]
        # Stop sub-command.
        stop_id = str(args.get("stop", "")).strip()
        if stop_id:
            ok, msg = await registry.stop(stop_id)
            return ToolResult(
                output=msg,
                error=not ok,
                summary="stopped" if ok else "stop failed",
            )
        command = str(args.get("command", "")).strip()
        if not command:
            return ToolResult(
                output="command required", error=True,
                summary="empty command",
            )
        # Cap at max_monitors active.
        if registry.active_count() >= max_monitors():
            return ToolResult(
                output=(
                    f"already at max monitors "
                    f"({max_monitors()}). Stop one first."
                ),
                error=True,
                summary="max monitors",
            )
        # Spawn.
        notify = getattr(ctx, "notify", lambda _: None)
        try:
            spawn_kw: dict[str, Any] = dict(
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                cwd=str(ctx.workdir),
                env=os.environ.copy(),
            )
            if sys.platform == "win32":
                try:
                    import subprocess as _sp
                    spawn_kw["creationflags"] = (
                        getattr(_sp, "CREATE_NEW_PROCESS_GROUP", 0)
                        | getattr(_sp, "CREATE_NO_WINDOW", 0)
                    )
                except Exception:
                    pass
            else:
                spawn_kw["start_new_session"] = True
            proc = await asyncio.create_subprocess_shell(
                command, **spawn_kw,
            )
        except Exception as e:
            return ToolResult(
                output=f"spawn failed: {e}", error=True,
                summary="spawn failed",
            )
        import time
        import uuid
        monitor_id = uuid.uuid4().hex[:8]
        job = MonitorJob(
            monitor_id=monitor_id,
            command=command,
            proc=proc,
            notify=notify,
            started_at=time.monotonic(),
        )
        registry.jobs[monitor_id] = job

        async def _pump():
            try:
                while True:
                    line = await proc.stdout.readline()
                    if not line:
                        break
                    job.lines_emitted += 1
                    text = line.decode("utf-8", errors="replace").rstrip()
                    if text:
                        try:
                            notify(f"[monitor:{monitor_id}] {text}")
                        except Exception:
                            pass
            except asyncio.CancelledError:
                pass
            except Exception:
                pass
            finally:
                job.stopped = True

        asyncio.create_task(
            _pump(), name=f"prometheus-monitor-{monitor_id}",
        )
        return ToolResult(
            output=(
                f"monitor started · id={monitor_id} · "
                f"command={command[:60]}"
            ),
            summary=f"monitor · {monitor_id}",
            metadata={"monitor_id": monitor_id, "command": command},
        )
