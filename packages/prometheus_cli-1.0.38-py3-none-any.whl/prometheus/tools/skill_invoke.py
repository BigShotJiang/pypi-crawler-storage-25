"""invoke_skill — agent-invokable Skill tool.

Round-206: Claude Code's `Skill` tool lets the agent programmatically
trigger a registered skill mid-conversation. Prior to this, Prometheus
had a `/skill` slash command and a skills subsystem
(`prometheus.agent.skills`), but no way for the agent itself to call
a skill — the user had to type the slash command.

This tool closes that gap. The agent receives the skill's body as the
tool result and can act on it in its next turn.
"""
from __future__ import annotations

from typing import Any

from prometheus.agent.skills import discover_skills
from prometheus.tools.base import SideEffect, Tool, ToolContext, ToolResult


class InvokeSkill(Tool):
    """Look up a registered skill by name and return its content
    so the agent can apply it to the current task."""

    name = "skill"
    description = (
        "Invoke a registered skill by name. Returns the skill's "
        "body so the agent can apply its instructions to the "
        "current task. Use `args` to pass an optional argument "
        "string the skill body can reference."
    )
    side_effect = SideEffect.READ
    schema = {
        "type": "object",
        "properties": {
            "skill": {
                "type": "string",
                "description": (
                    "Exact name of the skill to invoke. Must match "
                    "the `name:` field in the skill's frontmatter."
                ),
            },
            "args": {
                "type": "string",
                "description": (
                    "Optional arguments to pass to the skill. The "
                    "skill body decides how to interpret them."
                ),
                "default": "",
            },
        },
        "required": ["skill"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        s = str(args.get("skill", "?"))[:40]
        return f"Skill({s})"

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        requested = str(args.get("skill", "")).strip()
        if not requested:
            return ToolResult(
                output="skill name is required",
                error=True,
                summary="missing skill name",
            )
        try:
            skills = discover_skills(ctx.workdir)
        except Exception as e:
            return ToolResult(
                output=f"failed to enumerate skills: {e}",
                error=True,
                summary="skill discovery failed",
            )
        match = next(
            (s for s in skills if s.name == requested),
            None,
        )
        if match is None:
            available = ", ".join(s.name for s in skills) or "(none discovered)"
            return ToolResult(
                output=(
                    f"skill {requested!r} not found. Available: "
                    f"{available}"
                ),
                error=True,
                summary=f"unknown skill: {requested}",
            )
        passed_args = str(args.get("args", "") or "")
        body = match.body or "(skill body is empty)"
        # Return the skill body verbatim — the agent reads this and
        # applies the instructions in its next turn. Mimics how CC's
        # Skill tool surfaces skill content as the tool_result text.
        out_parts = [
            f"--- skill: {match.name} ---",
            f"description: {match.description}",
        ]
        if passed_args:
            out_parts.append(f"args: {passed_args}")
        out_parts.append("")
        out_parts.append(body.strip())
        return ToolResult(
            output="\n".join(out_parts),
            summary=f"invoked skill: {match.name}",
        )
