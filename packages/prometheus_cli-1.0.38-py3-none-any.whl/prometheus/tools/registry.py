"""Default tool registry — one place to wire all built-in tools."""
from __future__ import annotations

from typing import Any, Awaitable, Callable

from prometheus.tools.ask import AskUserQuestion
from prometheus.tools.base import ToolRegistry
from prometheus.tools.calculator import Calculate
from prometheus.tools.files import (
    EditFile,
    GlobFiles,
    ListFiles,
    MultiEdit,
    ReadFile,
    WriteFile,
)
from prometheus.tools.bg_shells import BashOutput, KillShell
from prometheus.tools.patch import ApplyPatch
from prometheus.tools.search import SearchCode
from prometheus.tools.shell import RunBash
from prometheus.tools.subagent import TaskTool
from prometheus.tools.test_discovery import DiscoverTestCommand
from prometheus.tools.todo import TodoWrite
from prometheus.tools.web import WebFetch, WebSearch
from prometheus.tools.worklog import (
    TaskCreate, TaskGet, TaskList, TaskUpdate,
)
from prometheus.tools.teams import (
    SendMessage, TeamBroadcast, TeamCreate, TeamDelete,
)
from prometheus.tools.monitor import Monitor


def _build_invoke_skill_tool():
    """Round 206: agent-invokable Skill tool. Lazy import so the
    skills subsystem isn't loaded until the registry is actually
    built (matches the ComputerUse/round-143 lazy pattern)."""
    from prometheus.tools.skill_invoke import InvokeSkill
    return InvokeSkill()


def _build_remote_trigger_tool():
    """Round 207: agent-invokable RemoteTrigger tool. Webhook
    fire-and-report with SSRF defenses (deny-first on
    loopback/private/link-local/cloud-metadata)."""
    from prometheus.tools.remote_trigger import RemoteTrigger
    return RemoteTrigger()
# Round-final: ComputerUse is registered conditionally on macOS
# only — see the `is_supported()` check in `build_default_registry`.
from prometheus.tools.computer_use import ComputerUse
from prometheus.tools.computer_use_mcp import is_supported as _computer_use_supported
# Round 173: round-143 defined 10 Claude-Code-style tools
# (NotebookEdit, ExitPlanMode, EnterPlanMode, EnterWorktree,
# ExitWorktree, TaskOutput, TaskStop, ListMcpResources,
# ReadMcpResource, PowerShell) and an `all_round143_tools()`
# accessor — but the function was never called. The tools were
# orphan code from the registry's perspective. Wire them now so
# Jupyter users, plan-mode users, and worktree users actually
# get the documented tool surface.
#
# Import is deferred to inside `build_default_registry()` because
# `prometheus.tools_v143` imports `prometheus.tools.base`, which
# pulls in this very module via `prometheus.tools.__init__` —
# top-level import would form a cycle.


def build_default_registry(
    spawn_subagent: Callable[[str, Any], Awaitable[str]] | None = None,
    ask_user: Callable[[str, list[str]], Awaitable[str]] | None = None,
) -> ToolRegistry:
    reg = ToolRegistry()
    for t in [
        ReadFile(),
        WriteFile(),
        EditFile(),
        MultiEdit(),
        ApplyPatch(),
        GlobFiles(),
        ListFiles(),
        SearchCode(),
        RunBash(),
        BashOutput(),
        KillShell(),
        WebFetch(),
        WebSearch(),
        TodoWrite(),
        Calculate(),  # round-72: deterministic arithmetic
        DiscoverTestCommand(),  # round-95 turn-6: kill the LLM-driven test-config loop
        # Round 101: Work Log task tools — finer-grained than the
        # one-shot TodoWrite, and persisted across cohort dispatch.
        TaskCreate(),
        TaskUpdate(),
        TaskGet(),
        TaskList(),
        # Round 107: Agent Team tools. They self-gate on
        # PROMETHEUS_AGENT_TEAMS=1 so the default install behaves
        # as before — when team mode is off, calling these
        # returns a clean "team mode disabled" error.
        TeamCreate(),
        TeamDelete(),
        SendMessage(),
        TeamBroadcast(),
        # Round 123: streaming background-process monitor.
        Monitor(),
        # Round 206: agent-invokable Skill tool. Claude Code parity —
        # lets the model trigger a registered skill mid-task without
        # the user typing a slash command.
        _build_invoke_skill_tool(),
        # Round 207: agent-invokable RemoteTrigger tool. Lets the
        # model fire a webhook (Slack/Discord/CI hook) with deny-
        # first SSRF protection.
        _build_remote_trigger_tool(),
    ]:
        reg.register(t)
    # Round 173: wire the round-143 tool surface that was
    # defined-but-never-registered. Each tool guards its own
    # platform/availability constraints internally (PowerShell
    # no-ops off Windows; Notebook tools require nbformat;
    # Worktree tools require git). Deferred import breaks the
    # `tools_v143 → tools.base → tools.__init__ → tools.registry`
    # cycle that a top-level import would create.
    try:
        from prometheus.tools_v143 import all_round143_tools
        for t in all_round143_tools():
            try:
                reg.register(t)
            except Exception:
                # Defensive — a missing optional dep shouldn't kill
                # registry construction. The tool stays unregistered
                # and the agent simply won't see it.
                pass
    except ImportError:
        pass
    if spawn_subagent is not None:
        reg.register(TaskTool(spawn_subagent))
    if ask_user is not None:
        reg.register(AskUserQuestion(ask_user))
    # Round-final: macOS-only ComputerUse registration. On every
    # other platform the tool stays out of the registry — the
    # agent never sees it advertised, so it can't accidentally
    # invoke it. The `is_supported()` check is evaluated at
    # build time so a session moved between platforms picks up
    # the correct surface.
    if _computer_use_supported():
        reg.register(ComputerUse())
    # Round 108: PROMETHEUS_SIMPLE filters the registry down to
    # Bash / Read / Edit only. Applied last so the filter sees
    # every tool we'd otherwise ship.
    try:
        from prometheus.config_env import filter_simple_registry
        filter_simple_registry(reg)
    except Exception:
        pass
    return reg
