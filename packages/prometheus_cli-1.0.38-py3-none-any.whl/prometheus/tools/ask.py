"""ask_user_question — let the model ask the user a multi-choice question.

The model invokes this when it needs a clarifying decision before
proceeding (Claude Code's `AskUserQuestion` pattern). The UI renders an
arrow-key picker and the chosen option becomes the tool result, which
the model receives as the next message in the loop.
"""
from __future__ import annotations

from typing import Any, Awaitable, Callable

from prometheus.tools.base import SideEffect, Tool, ToolContext, ToolResult


class AskUserQuestion(Tool):
    name = "ask_user_question"
    description = (
        "Ask the user a clarifying multi-choice question and wait for the "
        "answer. Use this when you need a decision before proceeding "
        "(e.g. 'Do you want to proceed?', 'Which installer?', 'Confirm "
        "delete?'). Provide 2-5 short, concrete options. Don't use this "
        "for things you can decide on your own."
    )
    side_effect = SideEffect.READ
    # Round 176: Claude Code's AskUserQuestion also takes `header`
    # (a short title above the question) and `multiSelect` (boolean
    # for multi-choice answers). Earlier rounds dropped both
    # silently — calls passing them errored or had the values
    # ignored.
    schema = {
        "type": "object",
        "properties": {
            "question": {"type": "string", "description": "the question to display"},
            "header": {
                "type": "string",
                "description": (
                    "Optional short header / title shown above the "
                    "question (e.g. 'Confirm deletion')."
                ),
            },
            "options": {
                "type": "array",
                "items": {"type": "string"},
                "minItems": 2,
                "maxItems": 5,
                "description": "2-5 short option labels",
            },
            "multiSelect": {
                "type": "boolean",
                "default": False,
                "description": (
                    "When true, the user can pick multiple options. "
                    "The result is comma-separated."
                ),
            },
        },
        "required": ["question", "options"],
    }

    def __init__(self, ask_fn: Callable[[str, list[str]], Awaitable[str]]) -> None:
        self._ask = ask_fn

    def receipt_label(self, args: dict[str, Any]) -> str:
        q = str(args.get("question", "?"))
        return f"AskUser({q[:60]})"

    async def execute(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult:
        # R229.1: free-tier models emit `question` and `options` under
        # several names. Accept the same aliases the dispatcher
        # validator does so a `AskUser(prompt=..., choices=...)` call
        # works the same as `AskUser(question=..., options=...)`.
        question = str(
            args.get("question")
            or args.get("prompt")
            or args.get("query")
            or args.get("ask")
            or args.get("message")
            or ""
        ).strip()
        options = (
            args.get("options")
            or args.get("choices")
            or args.get("answers")
            or args.get("items")
            or args.get("values")
            or []
        )
        if not question:
            return ToolResult(output="question required", error=True, summary="empty question")
        if not isinstance(options, list) or len(options) < 2:
            return ToolResult(output="options must be a list of >= 2 items", error=True, summary="bad options")
        options = [str(o)[:120] for o in options[:5]]
        try:
            choice = await self._ask(question, options)
        except Exception as e:
            return ToolResult(output=f"ask failed: {e}", error=True, summary="ask error")
        if choice == "cancel":
            return ToolResult(
                output="user cancelled the question — abort and ask differently or stop.",
                summary="cancelled",
            )
        if choice == "__amend__":
            return ToolResult(
                output="user wants to amend / type a custom answer; do not assume any of the proposed options.",
                summary="amend",
            )
        return ToolResult(
            output=f"user chose: {choice}",
            summary=f"chose: {choice[:40]}",
        )
