"""Minimal .gitignore matcher used by glob/search/list.

We support the common subset of git's ignore syntax — enough that a
typical project's .gitignore filters as a developer would expect.
Edge cases not covered: !negation re-include after a directory exclude,
range globs ([abc]), and nested .gitignore files inside subdirs (we
honour only the root one). For commercial-grade we can swap to a real
library later.
"""
from __future__ import annotations

import fnmatch
from pathlib import Path
from typing import Iterable


# Patterns we always exclude regardless of .gitignore — same as git's
# implicit core.excludesFile + venv/cache norms.
ALWAYS_IGNORE_DIRS = {
    ".git", ".hg", ".svn", "__pycache__", "node_modules", ".venv", "venv",
    "dist", "build", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    ".tox", ".cache", ".idea", ".vscode", "target", ".next",
}


class GitIgnore:
    def __init__(self, root: Path, patterns: list[str]) -> None:
        self.root = root.resolve()
        self.dir_patterns: list[str] = []
        self.file_patterns: list[str] = []
        self.negations: list[str] = []
        for raw in patterns:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            negate = line.startswith("!")
            if negate:
                line = line[1:]
            if line.endswith("/"):
                self.dir_patterns.append(line.rstrip("/"))
            else:
                target = self.negations if negate else self.file_patterns
                target.append(line)

    @classmethod
    def for_workdir(cls, workdir: Path) -> "GitIgnore":
        """Load `.gitignore` plus any agent-specific ignore files.

        Round 183: also reads `.prometheusignore` (and the
        cross-tool aliases `.aiderignore`, `.clineignore`,
        `.cursorignore`, `.codexignore`, `.aiignore`) and concatenates
        their patterns. This lets a project exclude paths from agent
        context that it still wants checked into git — secrets
        examples, large fixtures, generated docs, vendored code.
        Cline's `.clineignore` reportedly cuts starting context from
        200k to <50k tokens on real repos; same mechanism here.
        Negations and directory patterns from each file all stack."""
        patterns: list[str] = []
        # Read in reverse precedence so later files'
        # negations / patterns are appended after — fnmatch is
        # order-independent for the OR-of-all-patterns check, but
        # this preserves intuitive layering.
        candidates = (
            ".gitignore",
            ".prometheusignore",
            ".aiderignore",
            ".clineignore",
            ".cursorignore",
            ".codexignore",
            ".aiignore",
        )
        for name in candidates:
            f = workdir / name
            if not f.exists():
                continue
            try:
                patterns.extend(
                    f.read_text(encoding="utf-8", errors="replace").splitlines()
                )
            except Exception:
                continue
        return cls(workdir, patterns)

    def is_ignored(self, path: Path) -> bool:
        try:
            rel = path.resolve().relative_to(self.root)
        except (ValueError, OSError):
            return False
        # Always-ignore dirs anywhere on the path.
        if any(p in ALWAYS_IGNORE_DIRS for p in rel.parts):
            return True
        rel_posix = rel.as_posix()
        # Negations win over file_patterns.
        for pat in self.negations:
            if self._match(pat, rel_posix, rel.name):
                return False
        for pat in self.dir_patterns:
            if any(part == pat or fnmatch.fnmatch(part, pat) for part in rel.parts[:-1]):
                return True
            if rel.parts and (rel.parts[0] == pat or fnmatch.fnmatch(rel.parts[0], pat)):
                return True
        for pat in self.file_patterns:
            if self._match(pat, rel_posix, rel.name):
                return True
        return False

    @staticmethod
    def _match(pattern: str, rel_posix: str, name: str) -> bool:
        if "/" in pattern:
            return fnmatch.fnmatch(rel_posix, pattern.lstrip("/"))
        # bare pattern matches anywhere by basename
        return fnmatch.fnmatch(name, pattern)

    def filter(self, paths: Iterable[Path]) -> list[Path]:
        return [p for p in paths if not self.is_ignored(p)]
