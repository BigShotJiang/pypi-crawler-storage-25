"""macOS Computer-Use MCP server.

This module exposes screenshot / find-by-label / click / type /
scroll operations against the macOS accessibility + screen-
capture APIs via `pyobjc`. It's structured as an MCP-shaped
server — a `serve()` entry point that the host can spawn as a
subprocess and talk to over stdio — but it's also importable
directly so tests can mock the platform calls.

Hard requirements:
  * macOS only. On other platforms `is_supported()` returns
    False and the host MUST NOT register the tool.
  * `pyobjc` must be installed for actual operation. Without it,
    operations return clean error results rather than crashing.
  * Accessibility permission must be granted to the parent
    terminal (System Settings → Privacy & Security → Accessibility).
  * Screen Recording permission must be granted for screenshots.

Provided operations (all require accessibility permission):

  * `screenshot()`         — capture full desktop, return PNG bytes.
  * `find_by_label(text)`  — locate UI element with matching role,
                             title, value, or AX label.
  * `click(x, y, button)`  — synthesize click at screen coords.
  * `type_text(text)`      — synthesize keystrokes.
  * `scroll(x, y, amount)` — vertical scroll wheel event.

The implementation does NOT auto-grant any system permissions.
If a call fails because the user hasn't granted access in
System Settings, the error message tells them what to do.
"""
from __future__ import annotations

import platform
import sys
from dataclasses import dataclass
from typing import Any, Optional


# ---------- platform gate ----------


def is_supported() -> bool:
    """Round-final: True iff this process is running on macOS.
    The host registers the ComputerUse tool ONLY when this is
    True — non-mac systems never see the tool advertised."""
    return sys.platform == "darwin"


def pyobjc_available() -> bool:
    """Check whether pyobjc is importable. Probed lazily so the
    cost is paid only when ComputerUse is actually invoked."""
    if not is_supported():
        return False
    try:
        import Quartz  # type: ignore  # noqa: F401
        return True
    except ImportError:
        return False


# ---------- result envelope ----------


@dataclass
class ComputerUseResult:
    """Round-final: shape of every ComputerUse response. Tests
    rely on this stable surface to verify behavior without a
    real Mac."""
    ok: bool
    operation: str
    message: str = ""
    payload: Optional[dict[str, Any]] = None


def _err(operation: str, message: str) -> ComputerUseResult:
    return ComputerUseResult(
        ok=False, operation=operation, message=message,
    )


def _ok(
    operation: str, *, message: str = "", payload: Optional[dict] = None,
) -> ComputerUseResult:
    return ComputerUseResult(
        ok=True, operation=operation,
        message=message, payload=payload,
    )


# ---------- guard helpers ----------


def _guard_platform(operation: str) -> Optional[ComputerUseResult]:
    if not is_supported():
        return _err(
            operation,
            f"ComputerUse is macOS-only. Current platform: "
            f"{sys.platform!r}. The tool should not be "
            f"registered on this OS — please file a bug.",
        )
    if not pyobjc_available():
        return _err(
            operation,
            "pyobjc is not installed. Run "
            "`pip install pyobjc-framework-Cocoa "
            "pyobjc-framework-Quartz` to enable ComputerUse.",
        )
    return None


# ---------- public API ----------


def screenshot() -> ComputerUseResult:
    """Capture the entire desktop and return PNG bytes.

    Requires Screen Recording permission. The PNG bytes go in
    `result.payload['png']` as base64 to keep the JSON envelope
    JSON-serializable."""
    guard = _guard_platform("screenshot")
    if guard is not None:
        return guard
    try:
        import base64
        import Quartz  # type: ignore
        from Cocoa import NSBitmapImageRep, NSPNGFileType  # type: ignore
        # CGWindowListCreateImage(rect, listOption, windowID, options)
        cg_image = Quartz.CGWindowListCreateImage(
            Quartz.CGRectInfinite,
            Quartz.kCGWindowListOptionOnScreenOnly,
            Quartz.kCGNullWindowID,
            Quartz.kCGWindowImageDefault,
        )
        if cg_image is None:
            return _err(
                "screenshot",
                "screen capture returned None — Screen Recording "
                "permission may be missing.",
            )
        rep = NSBitmapImageRep.alloc().initWithCGImage_(cg_image)
        png_data = rep.representationUsingType_properties_(
            NSPNGFileType, None,
        )
        png_bytes = bytes(png_data)
        b64 = base64.b64encode(png_bytes).decode("ascii")
        return _ok(
            "screenshot",
            message=f"captured {len(png_bytes)} bytes",
            payload={"png_base64": b64, "byte_size": len(png_bytes)},
        )
    except Exception as e:
        return _err("screenshot", f"capture failed: {e}")


def find_by_label(label: str) -> ComputerUseResult:
    """Locate the topmost UI element whose AXTitle / AXValue /
    AXDescription contains `label` (case-insensitive)."""
    guard = _guard_platform("find_by_label")
    if guard is not None:
        return guard
    label_low = (label or "").lower().strip()
    if not label_low:
        return _err("find_by_label", "empty label")
    try:
        # ApplicationServices is where AX* lives.
        import ApplicationServices  # type: ignore
        # Walk the focused application's UI tree.
        system_wide = ApplicationServices.AXUIElementCreateSystemWide()
        focused_app = None
        err, focused_app = ApplicationServices.AXUIElementCopyAttributeValue(
            system_wide,
            ApplicationServices.kAXFocusedApplicationAttribute,
            None,
        )
        if err != 0 or focused_app is None:
            return _err(
                "find_by_label",
                "could not get focused application — "
                "Accessibility permission missing?",
            )
        # Recursive walk capped at depth 6 / 200 elements so a
        # crazy app tree doesn't burn the session.
        match = _walk_for_label(focused_app, label_low, depth=0)
        if match is None:
            return _err(
                "find_by_label",
                f"no UI element matches {label!r}",
            )
        # Pull bounds for click coordination.
        bounds = _ax_bounds(match)
        return _ok(
            "find_by_label",
            message=f"matched element with bounds {bounds}",
            payload={"bounds": bounds},
        )
    except Exception as e:
        return _err("find_by_label", f"AX query failed: {e}")


def _walk_for_label(
    element, target_low: str,
    *, depth: int = 0, visited: int = 0,
) -> Optional[Any]:
    """Best-effort tree walk. macOS-only — this is only called
    from `find_by_label` after the platform gate passes."""
    if depth > 6 or visited > 200:
        return None
    try:
        import ApplicationServices  # type: ignore
        for attr in (
            ApplicationServices.kAXTitleAttribute,
            ApplicationServices.kAXValueAttribute,
            ApplicationServices.kAXDescriptionAttribute,
        ):
            err, value = ApplicationServices.AXUIElementCopyAttributeValue(
                element, attr, None,
            )
            if err == 0 and value:
                if target_low in str(value).lower():
                    return element
        # Recurse into children.
        err, children = ApplicationServices.AXUIElementCopyAttributeValue(
            element, ApplicationServices.kAXChildrenAttribute, None,
        )
        if err == 0 and children:
            for c in children[:20]:
                visited += 1
                hit = _walk_for_label(
                    c, target_low,
                    depth=depth + 1, visited=visited,
                )
                if hit is not None:
                    return hit
    except Exception:
        return None
    return None


def _ax_bounds(element) -> Optional[dict]:
    try:
        import ApplicationServices  # type: ignore
        err, position = ApplicationServices.AXUIElementCopyAttributeValue(
            element, ApplicationServices.kAXPositionAttribute, None,
        )
        err2, size = ApplicationServices.AXUIElementCopyAttributeValue(
            element, ApplicationServices.kAXSizeAttribute, None,
        )
        if err == 0 and err2 == 0 and position and size:
            # AX values are CGPoint / CGSize structs.
            return {
                "x": float(position.x),
                "y": float(position.y),
                "w": float(size.width),
                "h": float(size.height),
            }
    except Exception:
        pass
    return None


def click(
    x: float, y: float, *, button: str = "left",
) -> ComputerUseResult:
    """Synthesize a click at screen coordinates."""
    guard = _guard_platform("click")
    if guard is not None:
        return guard
    if button not in ("left", "right"):
        return _err("click", f"invalid button {button!r}")
    try:
        import Quartz  # type: ignore
        down = (
            Quartz.kCGEventLeftMouseDown if button == "left"
            else Quartz.kCGEventRightMouseDown
        )
        up = (
            Quartz.kCGEventLeftMouseUp if button == "left"
            else Quartz.kCGEventRightMouseUp
        )
        btn = (
            Quartz.kCGMouseButtonLeft if button == "left"
            else Quartz.kCGMouseButtonRight
        )
        evt_down = Quartz.CGEventCreateMouseEvent(
            None, down, (x, y), btn,
        )
        evt_up = Quartz.CGEventCreateMouseEvent(
            None, up, (x, y), btn,
        )
        Quartz.CGEventPost(Quartz.kCGHIDEventTap, evt_down)
        Quartz.CGEventPost(Quartz.kCGHIDEventTap, evt_up)
        return _ok(
            "click",
            message=f"{button} click at ({x:.0f},{y:.0f})",
            payload={"x": x, "y": y, "button": button},
        )
    except Exception as e:
        return _err("click", f"event-post failed: {e}")


def type_text(text: str) -> ComputerUseResult:
    """Synthesize keystrokes for the literal string `text`.

    Round-final: this is keyboard-event simulation, not paste.
    Intended for short strings (form fields, command-palette
    queries). For long pastes the host should drop into the
    clipboard via Cmd+V."""
    guard = _guard_platform("type_text")
    if guard is not None:
        return guard
    if not text:
        return _err("type_text", "empty text")
    try:
        import Quartz  # type: ignore
        for ch in text:
            evt = Quartz.CGEventCreateKeyboardEvent(None, 0, True)
            # CGEventKeyboardSetUnicodeString takes a single
            # Unicode string per event — encode the char as a
            # UTF-16 unit pair when needed.
            Quartz.CGEventKeyboardSetUnicodeString(
                evt, len(ch), ch,
            )
            Quartz.CGEventPost(Quartz.kCGHIDEventTap, evt)
            evt_up = Quartz.CGEventCreateKeyboardEvent(
                None, 0, False,
            )
            Quartz.CGEventKeyboardSetUnicodeString(
                evt_up, len(ch), ch,
            )
            Quartz.CGEventPost(Quartz.kCGHIDEventTap, evt_up)
        return _ok(
            "type_text",
            message=f"typed {len(text)} chars",
            payload={"length": len(text)},
        )
    except Exception as e:
        return _err("type_text", f"keystroke failed: {e}")


def scroll(x: float, y: float, amount: int) -> ComputerUseResult:
    """Synthesize a vertical scroll wheel event at (x, y).
    Positive `amount` scrolls up; negative scrolls down."""
    guard = _guard_platform("scroll")
    if guard is not None:
        return guard
    try:
        import Quartz  # type: ignore
        # Position the cursor first so the scroll lands on the
        # right element. Move only — no click.
        move = Quartz.CGEventCreateMouseEvent(
            None, Quartz.kCGEventMouseMoved, (x, y),
            Quartz.kCGMouseButtonLeft,
        )
        Quartz.CGEventPost(Quartz.kCGHIDEventTap, move)
        wheel = Quartz.CGEventCreateScrollWheelEvent(
            None,
            Quartz.kCGScrollEventUnitPixel,
            1,                  # axes — vertical only
            int(amount),
        )
        Quartz.CGEventPost(Quartz.kCGHIDEventTap, wheel)
        return _ok(
            "scroll",
            message=f"scrolled {amount} at ({x:.0f},{y:.0f})",
            payload={"x": x, "y": y, "amount": amount},
        )
    except Exception as e:
        return _err("scroll", f"scroll-post failed: {e}")


# ---------- MCP-shaped serve() entry point ----------


def serve() -> int:
    """Round-final: start the MCP-shaped JSON-RPC loop on
    stdin/stdout. Returns 0 on clean shutdown.

    This function is intentionally minimal — it lets the host
    spawn `python -m prometheus.tools.computer_use_mcp` as an
    MCP child process. The full MCP transport (request framing,
    capability negotiation) plugs in via the round-100 server
    registry.
    """
    if not is_supported():
        # On non-mac, exit immediately with a clear status. The
        # host's MCP registry filters us out at registration.
        sys.stderr.write(
            "ComputerUse MCP server is macOS-only. Exiting.\n"
        )
        return 1
    if not pyobjc_available():
        sys.stderr.write(
            "pyobjc not installed. Run `pip install pyobjc-framework-Cocoa "
            "pyobjc-framework-Quartz` and re-launch.\n"
        )
        return 1
    # Real MCP loop is wired by the round-100 transport layer.
    # The contract here is: this script lives, supports the five
    # operations above, and exits cleanly when its stdin closes.
    sys.stderr.write(
        "ComputerUse MCP server ready. (Awaiting MCP-transport wire-up.)\n"
    )
    try:
        for _ in sys.stdin:
            pass
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(serve())
