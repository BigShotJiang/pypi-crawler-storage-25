"""search_code: ripgrep-style content search using stdlib.

We don't ship ripgrep — instead we walk the workdir, respect a small
default ignore list, and search by regex. Fast enough for typical project
sizes (10k files), and zero external deps.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from prometheus.tools.base import SideEffect, Tool, ToolContext, ToolResult
from prometheus.tools.ignore import GitIgnore
TEXT_EXTS = {
    ".py", ".js", ".jsx", ".ts", ".tsx", ".go", ".rs", ".java", ".kt", ".swift",
    ".rb", ".php", ".c", ".h", ".cpp", ".hpp", ".cs", ".scala", ".clj",
    ".html", ".css", ".scss", ".sass", ".less", ".md", ".rst", ".txt",
    ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".sh", ".bash", ".zsh",
    ".sql", ".vue", ".svelte", ".lua", ".r", ".jl", ".dart", ".ex", ".exs",
    ".elm", ".pl", ".pm", ".tf", ".dockerfile", ".env",
}
MAX_FILES = 10_000
MAX_HITS = 200


_TYPE_TO_GLOB: dict[str, list[str]] = {
    # Round 174: Claude Code's Grep `type` parameter accepts ripgrep's
    # type names. Map the most common ones to extension globs so the
    # filter actually narrows the scan.
    "py": ["*.py"],
    "python": ["*.py"],
    "js": ["*.js", "*.jsx", "*.mjs"],
    "ts": ["*.ts", "*.tsx"],
    "go": ["*.go"],
    "rust": ["*.rs"],
    "java": ["*.java"],
    "cpp": ["*.cpp", "*.cc", "*.cxx", "*.hpp", "*.h"],
    "c": ["*.c", "*.h"],
    "ruby": ["*.rb"],
    "php": ["*.php"],
    "swift": ["*.swift"],
    "kotlin": ["*.kt", "*.kts"],
    "scala": ["*.scala"],
    "html": ["*.html", "*.htm"],
    "css": ["*.css", "*.scss", "*.sass", "*.less"],
    "md": ["*.md"],
    "markdown": ["*.md"],
    "json": ["*.json"],
    "yaml": ["*.yaml", "*.yml"],
    "toml": ["*.toml"],
    "sh": ["*.sh", "*.bash", "*.zsh"],
    "shell": ["*.sh", "*.bash", "*.zsh"],
}


class SearchCode(Tool):
    name = "search_code"
    description = (
        "Search file contents by regex across the working directory. "
        "Filter results by file glob (`glob`), file type (`type`), or "
        "search root (`path`). Output mode controls shape: "
        "`content` (default — path:line: match), `files_with_matches` "
        "(unique paths), or `count` (per-file hit counts)."
    )
    side_effect = SideEffect.READ
    # Round 174: schema expanded to match Claude Code's Grep tool —
    # `path` (search root), `type` (ripgrep type filter),
    # `output_mode` (content / files_with_matches / count),
    # `head_limit`, `-i`/`-n`/`-A`/`-B`/`-C` shortcuts, `multiline`.
    # Native names `case_insensitive` and `max_results` retained as
    # aliases.
    schema = {
        "type": "object",
        "properties": {
            "pattern": {"type": "string", "description": "Python regex"},
            "path": {
                "type": "string",
                "description": (
                    "Optional search root (workdir-relative). "
                    "Defaults to the workdir."
                ),
            },
            "glob": {"type": "string", "description": "optional file glob filter, e.g. '*.py'"},
            "type": {
                "type": "string",
                "description": (
                    "ripgrep-style file-type filter: "
                    "py / js / ts / go / rust / java / cpp / md / "
                    "json / yaml / toml / sh / etc."
                ),
            },
            "output_mode": {
                "type": "string",
                "enum": ["content", "files_with_matches", "count"],
                "default": "content",
                "description": (
                    "content: path:line: match. files_with_matches: "
                    "unique paths. count: per-file match counts."
                ),
            },
            "-i": {"type": "boolean", "description": "case insensitive"},
            "case_insensitive": {"type": "boolean", "description": "alias for -i"},
            "-n": {"type": "boolean", "description": "include line numbers (always on for content mode)"},
            "-A": {"type": "integer", "description": "lines AFTER each match (content mode only)"},
            "-B": {"type": "integer", "description": "lines BEFORE each match (content mode only)"},
            "-C": {"type": "integer", "description": "context lines before AND after (content mode only)"},
            "multiline": {
                "type": "boolean",
                "default": False,
                "description": "DOTALL+MULTILINE; allow patterns to span lines",
            },
            "head_limit": {"type": "integer", "description": "cap output rows (Claude Code name)"},
            "max_results": {"type": "integer", "default": 100, "description": "alias for head_limit"},
            "offset": {
                "type": "integer",
                "default": 0,
                "description": (
                    "Skip first N output rows before applying head_limit "
                    "(Claude Code parity — equivalent to `| tail -n +N+1 "
                    "| head -head_limit`)."
                ),
            },
        },
        "required": ["pattern"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        pat = str(args.get('pattern','?'))[:60]
        return f'Grep("{pat}")'

    async def execute(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult:
        pattern = str(args.get("pattern", ""))
        if not pattern:
            return ToolResult(output="pattern required", error=True, summary="empty pattern")
        if len(pattern) > 500:
            return ToolResult(output="pattern too long (max 500 chars)", error=True, summary="bad regex")
        if re.search(r"\([^)]*[*+?][^)]*\)[*+?]", pattern):
            return ToolResult(
                output="pattern has a quantifier inside AND outside the same group "
                       "(catastrophic-backtracking shape). Rewrite using non-capturing "
                       "groups or atomic groups, e.g. `(?>...)+` or just simpler chars.",
                error=True,
                summary="redos blocked",
            )
        # Round 174: resolve the optional `path` (search root) first
        # — refuses traversal outside the workdir.
        search_root = ctx.workdir
        sub = str(args.get("path") or "").strip()
        if sub:
            from prometheus.tools.files import _resolve as _resolve_path
            candidate = _resolve_path(ctx.workdir, sub)
            try:
                wd_canon = ctx.workdir.resolve()
                cand_canon = candidate.resolve()
                if not str(cand_canon).startswith(str(wd_canon)):
                    return ToolResult(
                        output=f"path is outside workdir: {sub}",
                        error=True, summary="path escape",
                    )
            except (OSError, RuntimeError):
                pass
            if candidate.is_dir():
                search_root = candidate
            else:
                return ToolResult(
                    output=f"path is not a directory: {sub}",
                    error=True, summary="not a dir",
                )
        glob_ = str(args.get("glob", "") or "")
        # Round 174: `type` filter — convert to a list of globs that
        # the file-iterator will treat as "match any".
        type_filter = str(args.get("type", "") or "").lower().strip()
        type_globs: list[str] = []
        if type_filter and type_filter in _TYPE_TO_GLOB:
            type_globs = list(_TYPE_TO_GLOB[type_filter])
        # Round 174: -i alias.
        case_insensitive = bool(args.get("-i") or args.get("case_insensitive"))
        flags = re.IGNORECASE if case_insensitive else 0
        if bool(args.get("multiline")):
            flags |= re.DOTALL | re.MULTILINE
        # Round 174: head_limit (CC) preferred, max_results (native) alias.
        if "head_limit" in args:
            cap = int(args["head_limit"])
        else:
            cap = int(args.get("max_results", 100))
        max_results = max(1, min(MAX_HITS, cap))
        # 1.0.3: Claude Code Grep `offset` — skip first N rows
        # before applying head_limit. Internally we collect
        # `offset + max_results` rows so the post-collection
        # slice gives a stable window.
        try:
            skip_offset = max(0, int(args.get("offset", 0) or 0))
        except (TypeError, ValueError):
            skip_offset = 0
        collect_cap = max_results + skip_offset
        # Round 174: context lines for content mode.
        try:
            ctx_C = int(args.get("-C", 0) or 0)
            ctx_A = int(args.get("-A", ctx_C) or ctx_C)
            ctx_B = int(args.get("-B", ctx_C) or ctx_C)
            ctx_A = max(0, min(ctx_A, 50))
            ctx_B = max(0, min(ctx_B, 50))
        except (TypeError, ValueError):
            ctx_A = ctx_B = 0
        try:
            rx = re.compile(pattern, flags)
        except re.error as e:
            return ToolResult(output=f"invalid regex: {e}", error=True, summary="bad regex")

        # Round 174: output_mode dispatch.
        output_mode = str(args.get("output_mode") or "content").lower()
        if output_mode not in ("content", "files_with_matches", "count"):
            output_mode = "content"

        gi = GitIgnore.for_workdir(ctx.workdir)
        hits_content: list[str] = []
        files_matched: list[Path] = []
        per_file_counts: dict[str, int] = {}
        scanned = 0
        multiline = bool(args.get("multiline"))
        for p in _iter_files(search_root, glob_, gi, type_globs=type_globs):
            scanned += 1
            if scanned > MAX_FILES:
                break
            file_had_match = False
            file_count = 0
            try:
                full_text = p.read_text(encoding="utf-8", errors="replace")
                lines = full_text.splitlines()
            except Exception:
                continue
            # Round 174: in multiline mode, run the regex over the
            # WHOLE file body so patterns can span line breaks. Then
            # convert each match's character offset back to a line
            # number for content-mode output. Per-line iteration
            # only happens for single-line patterns.
            if multiline:
                for m in rx.finditer(full_text):
                    file_had_match = True
                    file_count += 1
                    if output_mode == "content":
                        # Map character offset → line number.
                        ln_idx = full_text.count("\n", 0, m.start()) + 1
                        try:
                            rel = p.relative_to(ctx.workdir).as_posix()
                        except ValueError:
                            try:
                                rel = p.resolve().relative_to(
                                    ctx.workdir.resolve()
                                ).as_posix()
                            except (ValueError, OSError):
                                rel = str(p)
                        snippet = m.group(0).replace("\n", " ").strip()[:300]
                        hits_content.append(f"{rel}:{ln_idx}: {snippet}")
                        if len(hits_content) >= collect_cap:
                            break
                if file_had_match:
                    files_matched.append(p)
                    try:
                        rel = p.relative_to(ctx.workdir).as_posix()
                    except ValueError:
                        rel = str(p)
                    per_file_counts[rel] = file_count
                if output_mode == "content" and len(hits_content) >= collect_cap:
                    break
                if output_mode == "files_with_matches" and len(files_matched) >= collect_cap:
                    break
                continue
            for ln, line in enumerate(lines, 1):
                if rx.search(line):
                    file_had_match = True
                    file_count += 1
                    if output_mode == "content":
                        try:
                            rel = p.relative_to(ctx.workdir).as_posix()
                        except ValueError:
                            try:
                                rel = p.resolve().relative_to(
                                    ctx.workdir.resolve()
                                ).as_posix()
                            except (ValueError, OSError):
                                rel = str(p)
                        # Build context window if -A / -B / -C asked.
                        if ctx_A == 0 and ctx_B == 0:
                            hits_content.append(f"{rel}:{ln}: {line.rstrip()[:300]}")
                        else:
                            start = max(0, ln - 1 - ctx_B)
                            end = min(len(lines), ln + ctx_A)
                            block = []
                            for j in range(start, end):
                                marker = ":" if (j + 1) == ln else "-"
                                block.append(f"{rel}:{j + 1}{marker} {lines[j].rstrip()[:300]}")
                            hits_content.append("\n".join(block))
                        if len(hits_content) >= collect_cap:
                            break
            if file_had_match:
                files_matched.append(p)
                try:
                    rel = p.relative_to(ctx.workdir).as_posix()
                except ValueError:
                    rel = str(p)
                per_file_counts[rel] = file_count
            if output_mode == "content" and len(hits_content) >= collect_cap:
                break
            if output_mode == "files_with_matches" and len(files_matched) >= collect_cap:
                break

        if output_mode == "files_with_matches":
            rels: list[str] = []
            for p in files_matched[skip_offset:skip_offset + max_results]:
                try:
                    rels.append(p.relative_to(ctx.workdir).as_posix())
                except ValueError:
                    rels.append(str(p))
            out = "\n".join(rels) if rels else "(no matches)"
            return ToolResult(
                output=out,
                summary=f"{len(rels)} file{'s' if len(rels) != 1 else ''}",
            )
        if output_mode == "count":
            sorted_counts = sorted(
                per_file_counts.items(), key=lambda kv: -kv[1],
            )
            lines_out = [
                f"{rel}: {n}"
                for rel, n in sorted_counts[skip_offset:skip_offset + max_results]
            ]
            out = "\n".join(lines_out) if lines_out else "(no matches)"
            return ToolResult(
                output=out,
                summary=f"{sum(per_file_counts.values())} hit"
                        f"{'s' if sum(per_file_counts.values()) != 1 else ''} "
                        f"across {len(per_file_counts)} file"
                        f"{'s' if len(per_file_counts) != 1 else ''}",
            )

        # default: content mode
        windowed = hits_content[skip_offset:skip_offset + max_results]
        out = "\n".join(windowed) if windowed else "(no matches)"
        capped = len(hits_content) >= collect_cap
        return ToolResult(
            output=out + (f"\n…[capped at {max_results}]" if capped else ""),
            summary=f"{len(windowed)} hit{'s' if len(windowed) != 1 else ''}",
        )


def _iter_files(root: Path, glob_: str, gi: GitIgnore, *, type_globs: list[str] | None = None):
    """Round 174: extended to accept `type_globs` from Grep's
    `type` parameter. When `type_globs` is non-empty, only files
    matching any of those globs are yielded — even if `glob_`
    is also provided, both filters must match."""
    glob_pat = glob_ or None
    type_globs = type_globs or []
    from fnmatch import fnmatch
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        if gi.is_ignored(p):
            continue
        # Glob filter (single user-supplied pattern).
        if glob_pat and not fnmatch(p.name, glob_pat):
            continue
        # Type filter (ripgrep-style).
        if type_globs and not any(fnmatch(p.name, g) for g in type_globs):
            continue
        # If neither filter is set, fall back to text-extension allowlist.
        if not glob_pat and not type_globs:
            if p.suffix.lower() not in TEXT_EXTS:
                continue
        try:
            if p.stat().st_size > 2 * 1024 * 1024:
                continue
        except OSError:
            continue
        yield p
