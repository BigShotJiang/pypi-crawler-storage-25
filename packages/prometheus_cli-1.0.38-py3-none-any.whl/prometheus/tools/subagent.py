"""task: launch a fresh sub-agent on a focused subtask.

Sub-agents have their own message history and a small toolset — useful
for big searches or independent investigations that would pollute the
parent's context. Returns the sub-agent's final text reply.
"""
from __future__ import annotations

from typing import Any, TYPE_CHECKING

from prometheus.tools.base import SideEffect, Tool, ToolContext, ToolResult

if TYPE_CHECKING:
    from prometheus.agent.loop import AgentLoop


class TaskTool(Tool):
    name = "task"
    description = (
        "Launch a fresh sub-agent on a focused subtask. Sub-agents have their "
        "own message history and a small toolset; runs to completion and "
        "returns a final text reply. Use for parallel searches, independent "
        "investigations, or anything that would clutter the parent thread."
    )
    side_effect = SideEffect.READ
    # Round-48: subagent types match Claude Code's pattern. Each type
    # primes the sub-agent with a different system-prompt overlay so
    # the model knows what kind of work to focus on.
    SUBAGENT_TYPES = (
        "general-purpose",   # default — read/write/exec, full toolset
        "explore",           # read-only, parallel search across the repo
        "plan",              # read-only + write a plan, no edits
        "code-reviewer",     # read-only, structured review output
    )
    schema = {
        "type": "object",
        "properties": {
            "description": {
                "type": "string",
                "description": "Short imperative subject — appears in the receipt",
            },
            "prompt": {
                "type": "string",
                "description": "Self-contained instructions for the sub-agent",
            },
            "subagent_type": {
                "type": "string",
                "enum": list(SUBAGENT_TYPES),
                "default": "general-purpose",
                "description": (
                    "Specialized agent type. 'explore' = read-only repo "
                    "search; 'plan' = produce a plan with no edits; "
                    "'code-reviewer' = structured review; 'general-purpose' "
                    "= full toolset (default)."
                ),
            },
            # Round 97: background dispatch. When true, the tool
            # returns immediately with an agent ID; the subagent
            # runs in the BackgroundAgentManager and surfaces in
            # the parent UI as an `Agent(...)` card. The parent's
            # main rail / scrollback stay clean — subagent activity
            # appears only inside the card's expanded view.
            "run_in_background": {
                "type": "boolean",
                "default": False,
                "description": (
                    "When true, returns immediately with an agent ID "
                    "and runs the subagent in the background. The "
                    "parent agent can keep working; the result "
                    "surfaces via an Agent(...) card in the UI. "
                    "Default false (synchronous, blocks until done)."
                ),
            },
            # Round 176: Claude Code's Task tool also takes `model`
            # and `isolation`. Without these, parent-agent calls
            # using `{"model": "haiku-4-5"}` to delegate to a fast
            # tier got the parent's model regardless, and
            # `{"isolation": "worktree"}` for git-worktree-based
            # isolation was silently ignored.
            "model": {
                "type": "string",
                "description": (
                    "Optional model override for the subagent. Uses "
                    "the parent's model when omitted."
                ),
            },
            "isolation": {
                "type": "string",
                "enum": ["", "worktree"],
                "default": "",
                "description": (
                    "When 'worktree', spawns the subagent in a "
                    "fresh git worktree so its writes don't affect "
                    "the parent's working tree until merged."
                ),
            },
        },
        "required": ["description", "prompt"],
    }

    def __init__(self, spawn_subagent: Any) -> None:
        # spawn_subagent is an async callable: (prompt, ctx, subagent_type) -> str
        self._spawn = spawn_subagent

    def receipt_label(self, args: dict[str, Any]) -> str:
        st = args.get("subagent_type") or "general-purpose"
        return f"Task[{st}]({str(args.get('description','?'))[:60]})"

    async def execute(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult:
        prompt = str(args.get("prompt", "")).strip()
        desc = str(args.get("description", "subtask"))
        subagent_type = str(args.get("subagent_type") or "general-purpose")
        run_in_background = bool(args.get("run_in_background", False))
        # Round 97.3: free-tier models often emit `task` calls
        # with `description` set but `prompt` missing. Pre-97.3
        # this surfaced as a public RED `Task[...] └ empty prompt`
        # receipt, looking like a real failure. Fall back to using
        # the description as the prompt body — the description IS
        # the work order, just shorter than a full prompt.
        if not prompt and desc and desc != "subtask":
            prompt = desc
            try:
                ctx.audit("task_prompt_fallback", {
                    "description": desc, "subagent_type": subagent_type,
                })
            except Exception:
                pass
        # Round-49: accept either a built-in type OR a custom agent
        # discovered from .prometheus/agents/<name>.md.
        if subagent_type not in self.SUBAGENT_TYPES:
            try:
                from prometheus.agent.custom_agents import discover as _disc
                workdir = getattr(ctx, "workdir", None)
                if workdir is not None:
                    custom = _disc(workdir)
                    if subagent_type in custom:
                        # Valid custom agent — fall through to spawn.
                        pass
                    else:
                        return ToolResult(
                            output=(
                                f"unknown subagent_type {subagent_type!r}. "
                                f"Valid built-ins: {', '.join(self.SUBAGENT_TYPES)}. "
                                f"Custom agents loaded: {sorted(custom.keys()) or '(none)'}. "
                                f"Drop a .md file in .prometheus/agents/ to define one."
                            ),
                            error=True,
                            summary="bad type",
                        )
                else:
                    return ToolResult(
                        output=f"unknown subagent_type {subagent_type!r}",
                        error=True,
                        summary="bad type",
                    )
            except Exception:
                return ToolResult(
                    output=f"unknown subagent_type {subagent_type!r}",
                    error=True,
                    summary="bad type",
                )
        if not prompt:
            return ToolResult(output="prompt required", error=True, summary="empty prompt")

        # Round 97: background dispatch path. When run_in_background
        # is true, hand off to the BackgroundAgentManager so the
        # parent agent can keep working. The manager surfaces a
        # SubAgentCard in the UI; this tool returns immediately
        # with an agent ID + name so the model knows the dispatch
        # succeeded. The actual reply will land in the card.
        if run_in_background:
            mgr = None
            parent_session_id = getattr(ctx, "session_id", "") or ""
            parent_depth = 0
            try:
                runtime = getattr(ctx, "runtime", None)
                app = getattr(runtime, "app", None) if runtime else None
                mgr = getattr(app, "subagent_manager", None)
                # Read parent depth from the runtime if available.
                # Fresh foreground invocation → 0; subagent of
                # subagent → 1 (and the manager will refuse).
                parent_depth = getattr(
                    runtime, "subagent_depth", 0,
                ) if runtime else 0
            except Exception:
                mgr = None
            if mgr is None:
                # No manager wired (running outside the app, e.g. tests
                # that exercise TaskTool directly). Fall back to
                # synchronous spawn so behavior is at least defined.
                run_in_background = False
            else:
                try:
                    task = await mgr.submit(
                        name=desc,
                        prompt=prompt,
                        subagent_type=subagent_type,
                        parent_session_id=parent_session_id,
                        parent_depth=parent_depth,
                        parent_ctx=ctx,
                    )
                except Exception as e:
                    return ToolResult(
                        output=f"sub-agent dispatch error: {e}",
                        error=True,
                        summary="dispatch failed",
                    )
                # Status reflects the manager's decision (running /
                # queued / failed depth-exceeded). The model sees a
                # short tool result; the user sees the live card.
                return ToolResult(
                    output=(
                        f"Agent dispatched: id={task.id} "
                        f"name={desc!r} type={subagent_type} "
                        f"status={task.status.value}"
                    ),
                    summary=f"backgrounded · {desc[:40]}",
                    metadata={
                        "subagent_id": task.id,
                        "subagent_status": task.status.value,
                        "background": True,
                    },
                )

        try:
            # Try the subagent_type-aware path first; fall back for older
            # spawn signatures that only take (prompt, ctx).
            try:
                reply = await self._spawn(prompt, ctx, subagent_type)
            except TypeError:
                reply = await self._spawn(prompt, ctx)
        except Exception as e:
            return ToolResult(output=f"sub-agent error: {e}", error=True, summary="sub-agent error")
        return ToolResult(
            output=reply,
            summary=f"{subagent_type} · {len(reply):,} chars",
            metadata={"collapse": True, "lines": reply.count('\n') + 1},
        )
