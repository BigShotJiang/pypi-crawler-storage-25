"""Round-72 calculator tool — deterministic arithmetic for the agent.

Free models hallucinate arithmetic ("15% of $87.32 = $7.50" — round-71
captured this verbatim). The fix is to give the agent a tool that does
the math precisely, the same way Anthropic's official cookbook
recommends [^1] and the ALU project [^2] demonstrates.

Security: this does NOT use raw `eval()`. Even with input sanitization,
Python's eval can be smuggled into ("__import__('os').system('rm -rf /')",
exponent-bomb DoS via "9**9**9", etc.). Instead we parse the expression
into an AST and walk it, allowing only:

  • Constants (int, float, complex)
  • UnaryOp with USub, UAdd
  • BinOp with Add, Sub, Mult, Div, FloorDiv, Mod, Pow
  • Parens (handled by the parser)

Anything else — function calls, attribute access, names, subscripts,
imports, string ops — raises a clean error.

[^1]: https://docs.claude.com/en/docs/agents-and-tools/tool-use/tools-overview
[^2]: https://github.com/joonspk-research/alu — "LLMs are unreliable at
      precise arithmetic. Built so AI agents can offload arithmetic to
      a reliable evaluator instead of hallucinating results."
"""
from __future__ import annotations

import ast
import math
from typing import Any

from prometheus.tools.base import (
    SideEffect,
    Tool,
    ToolContext,
    ToolResult,
)


# Allow-listed binary ops. Pow is included but with a guard against
# exponent-bombs (round-72 P0).
_BIN_OPS = {
    ast.Add: lambda a, b: a + b,
    ast.Sub: lambda a, b: a - b,
    ast.Mult: lambda a, b: a * b,
    ast.Div: lambda a, b: a / b,
    ast.FloorDiv: lambda a, b: a // b,
    ast.Mod: lambda a, b: a % b,
    ast.Pow: lambda a, b: a ** b,
}
_UNARY_OPS = {
    ast.USub: lambda x: -x,
    ast.UAdd: lambda x: +x,
}


# Expression length cap — guards against "1+1+1+...+1" megabyte payloads
# the model could accidentally emit on a hallucinated tool-call.
_MAX_EXPR_LEN = 1024
# Pow exponent cap — prevents `9**9**9` style exponent-bombs that would
# allocate a number with billions of digits.
_MAX_POW_BASE = 1_000_000_000   # 1e9
_MAX_POW_EXP = 1_000


def _walk(node: ast.AST) -> Any:
    """Evaluate one AST node using only the whitelisted ops."""
    # Python 3.8+ uses ast.Constant for numeric literals.
    # ast.Num was deprecated in 3.8, removed in 3.14; pyproject.toml
    # requires-python >= 3.11 so we only need the Constant branch.
    if isinstance(node, ast.Constant):
        if isinstance(node.value, (int, float, complex)):
            return node.value
        raise ValueError(f"non-numeric constant {node.value!r} not allowed")
    if isinstance(node, ast.UnaryOp):
        op = _UNARY_OPS.get(type(node.op))
        if op is None:
            raise ValueError(f"unary op {type(node.op).__name__} not allowed")
        return op(_walk(node.operand))
    if isinstance(node, ast.BinOp):
        op = _BIN_OPS.get(type(node.op))
        if op is None:
            raise ValueError(f"binary op {type(node.op).__name__} not allowed")
        left = _walk(node.left)
        right = _walk(node.right)
        # Pow exponent-bomb guard
        if isinstance(node.op, ast.Pow):
            try:
                if abs(right) > _MAX_POW_EXP or abs(left) > _MAX_POW_BASE:
                    raise ValueError(
                        f"exponent {right!r} or base {left!r} exceeds safety "
                        f"cap (max base {_MAX_POW_BASE}, max exponent "
                        f"{_MAX_POW_EXP})"
                    )
            except TypeError:
                pass  # complex numbers — pow() handles them
        return op(left, right)
    if isinstance(node, ast.Expression):
        return _walk(node.body)
    raise ValueError(f"node type {type(node).__name__} not allowed")


def safe_eval(expression: str) -> float | int | complex:
    """Evaluate a numeric expression. Raises ValueError on anything
    outside the whitelist (function calls, names, attributes, etc.).
    Raises ZeroDivisionError, OverflowError on overflow.
    """
    if not isinstance(expression, str):
        raise ValueError("expression must be a string")
    expression = expression.strip()
    if not expression:
        raise ValueError("empty expression")
    if len(expression) > _MAX_EXPR_LEN:
        raise ValueError(f"expression exceeds {_MAX_EXPR_LEN} chars")
    # Reject obvious smuggling attempts cheaply before parsing
    if any(bad in expression for bad in ("__", "import", "lambda", "exec",
                                          "eval", "open", "globals",
                                          "locals", "compile", "getattr")):
        raise ValueError("expression contains disallowed identifier")
    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError as e:
        raise ValueError(f"syntax error: {e.msg} at char {e.offset}")
    return _walk(tree)


def _format_result(value: float | int | complex) -> str:
    """Format the result for display. Floats with ≥6 decimal places
    truncate to 6 to keep output readable but informative."""
    if isinstance(value, complex):
        return str(value)
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        if math.isnan(value):
            return "NaN"
        if math.isinf(value):
            return "Infinity" if value > 0 else "-Infinity"
        if value == int(value) and abs(value) < 1e15:
            return str(int(value))
        # Trim trailing zeros for clean display
        return f"{value:.10g}"
    return str(value)


class Calculate(Tool):
    name = "calculator"
    description = (
        "Perform arithmetic. Use this for ANY math calculation — "
        "percentages, multiplication, division, powers, parentheses. "
        "Free models hallucinate math; this tool is deterministic. "
        "Pass the full expression as a single Python-syntax string "
        "(e.g. '87.32 * 0.15', '(100 + 25) / 5', '2 ** 10')."
    )
    side_effect = SideEffect.READ
    schema = {
        "type": "object",
        "properties": {
            "expression": {
                "type": "string",
                "description": (
                    "Python-syntax math expression. Allowed: numbers, "
                    "+ - * / // % **, parentheses, unary +/-. NOT "
                    "allowed: function calls, names, imports."
                ),
            },
        },
        "required": ["expression"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        expr = str(args.get("expression", "?"))[:48]
        return f"Calculate({expr})"

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        expr = str(args.get("expression", ""))
        try:
            result = safe_eval(expr)
        except ZeroDivisionError:
            return ToolResult(
                output="error: division by zero",
                error=True, summary="div by zero",
            )
        except OverflowError:
            return ValueError("error: result overflows numeric range")
        except ValueError as e:
            return ToolResult(
                output=f"error: {e}", error=True, summary="bad expression",
            )
        except Exception as e:
            return ToolResult(
                output=f"error: {type(e).__name__}: {e}",
                error=True, summary="eval failed",
            )
        formatted = _format_result(result)
        return ToolResult(
            output=formatted, summary=f"= {formatted[:40]}",
        )
