"""remote_trigger — agent-invokable webhook tool.

Round-207: Claude Code's `RemoteTrigger` lets the agent fire an HTTP
webhook (Slack/Discord notification, CI hook, custom internal service)
mid-task. Prometheus had `web_fetch` for GET requests but no clean way
to POST a payload to a URL the user has authorized.

Security posture
----------------
The agent decides what URL to call based on its understanding of the
user's intent. That makes this a high-blast-radius tool by default —
an agent that gets prompt-injected into firing
``http://169.254.169.254/`` (AWS metadata) or ``http://localhost:6379``
(local Redis) is a textbook SSRF.

Defenses (deny-first):

  * The URL is parsed and the host resolved. ALL of:
    - loopback (`127.0.0.0/8`, `::1`)
    - link-local (`169.254.0.0/16`, `fe80::/10`)
    - private RFC1918 (`10/8`, `172.16/12`, `192.168/16`)
    - unspecified (`0.0.0.0/8`, `::`)
    - cloud metadata (`169.254.169.254` exact, `100.100.100.200` exact)
    - file:// / data:// / javascript:// schemes
  * are rejected.
  * Only `http`/`https` schemes are allowed.
  * Hostnames that resolve to multiple addresses must have ALL
    addresses pass the check (DNS rebinding defense).
  * Method is one of GET/POST/PUT/PATCH/DELETE — no TRACE/CONNECT.
  * Body is capped at 64 KB. Response body returned to the agent is
    capped at 4 KB.
  * Timeout is bounded to [1s, 30s].

The user can opt-in to private-network access via
`PROMETHEUS_REMOTE_TRIGGER_ALLOW_PRIVATE=1` (off by default) — useful
for self-hosted internal CI hooks but should never be on in the
default install.
"""
from __future__ import annotations

import ipaddress
import json
import os
import socket
from typing import Any
from urllib.parse import urlparse

from prometheus.tools.base import SideEffect, Tool, ToolContext, ToolResult


_ALLOWED_METHODS = ("GET", "POST", "PUT", "PATCH", "DELETE")
_MAX_BODY_BYTES = 64 * 1024
_MAX_RESPONSE_BYTES = 4 * 1024
_DEFAULT_TIMEOUT_MS = 10_000
_MIN_TIMEOUT_MS = 1_000
_MAX_TIMEOUT_MS = 30_000

# Cloud-metadata exact-match denylist. RFC1918 already covers most
# ranges; these are the well-known IMDS endpoints that need explicit
# pinning because their addresses (especially 169.254.169.254) are
# inside link-local but worth naming.
_CLOUD_METADATA_HOSTS = frozenset({
    "169.254.169.254",   # AWS / Azure / DigitalOcean / OpenStack IMDS
    "100.100.100.200",   # Alibaba Cloud
    "metadata.google.internal",
})


def _allow_private() -> bool:
    return os.environ.get(
        "PROMETHEUS_REMOTE_TRIGGER_ALLOW_PRIVATE", "",
    ).strip().lower() in ("1", "true", "yes", "on")


def _classify_address(addr: str) -> tuple[bool, str]:
    """Return ``(is_blocked, reason)`` for an IP literal.

    A True first element means the address must be rejected.
    """
    try:
        ip = ipaddress.ip_address(addr)
    except ValueError:
        return True, f"unparseable address: {addr!r}"
    if ip.is_loopback:
        return True, f"loopback address: {addr}"
    if ip.is_link_local:
        return True, f"link-local address: {addr}"
    if ip.is_unspecified:
        return True, f"unspecified address: {addr}"
    if ip.is_multicast:
        return True, f"multicast address: {addr}"
    if ip.is_reserved:
        return True, f"reserved address: {addr}"
    # Private: only blocked when the user hasn't opted in.
    if ip.is_private:
        if _allow_private():
            return False, ""
        return True, (
            f"private address: {addr} "
            f"(set PROMETHEUS_REMOTE_TRIGGER_ALLOW_PRIVATE=1 to allow)"
        )
    return False, ""


def _validate_url(url: str) -> tuple[bool, str]:
    """Return ``(ok, reason_if_blocked)`` for a target URL.

    Performs DNS resolution and rejects if ANY resolved address is
    private/loopback/etc. (DNS-rebinding defense).
    """
    if not isinstance(url, str) or not url.strip():
        return False, "url is required"
    try:
        parsed = urlparse(url.strip())
    except Exception:
        return False, "could not parse url"
    if parsed.scheme.lower() not in ("http", "https"):
        return False, (
            f"scheme {parsed.scheme!r} not allowed "
            f"(only http/https)"
        )
    host = (parsed.hostname or "").lower()
    if not host:
        return False, "url has no host"
    # Cloud-metadata exact-name block (covers
    # `metadata.google.internal` which would otherwise resolve to a
    # private IP and be blocked anyway, but pin by name for clarity).
    if host in _CLOUD_METADATA_HOSTS:
        return False, f"cloud-metadata host blocked: {host}"
    # If the host is already an IP literal, classify directly.
    try:
        ipaddress.ip_address(host)
        ok = not _classify_address(host)[0]
        if not ok:
            return False, _classify_address(host)[1]
        return True, ""
    except ValueError:
        pass
    # Hostname → resolve all A/AAAA records, classify each.
    try:
        results = socket.getaddrinfo(host, None)
    except socket.gaierror as e:
        return False, f"dns resolution failed: {e}"
    addrs = {r[4][0] for r in results}
    if not addrs:
        return False, "no addresses resolved"
    for addr in addrs:
        blocked, reason = _classify_address(addr)
        if blocked:
            return False, (
                f"resolves to blocked address: {reason}"
            )
    return True, ""


class RemoteTrigger(Tool):
    """Fire an HTTP webhook to a user-authorized URL."""

    name = "remote_trigger"
    description = (
        "Send an HTTP request to a webhook URL (Slack/Discord/CI/"
        "custom). Use this for one-shot notifications and triggers, "
        "NOT for fetching content (use web_fetch for that). Refuses "
        "URLs that resolve to loopback, private, link-local, or "
        "cloud-metadata addresses."
    )
    side_effect = SideEffect.WRITE
    schema = {
        "type": "object",
        "properties": {
            "url": {
                "type": "string",
                "description": "Full http:// or https:// webhook URL.",
            },
            "method": {
                "type": "string",
                "enum": list(_ALLOWED_METHODS),
                "default": "POST",
                "description": "HTTP method.",
            },
            "headers": {
                "type": "object",
                "description": (
                    "Optional request headers as a flat string→string map."
                ),
                "default": {},
            },
            "body": {
                "type": "string",
                "description": (
                    "Optional request body. JSON should be pre-encoded "
                    "as a string. Capped at 64 KB."
                ),
                "default": "",
            },
            "timeout_ms": {
                "type": "integer",
                "minimum": _MIN_TIMEOUT_MS,
                "maximum": _MAX_TIMEOUT_MS,
                "default": _DEFAULT_TIMEOUT_MS,
                "description": (
                    "Per-request timeout in milliseconds (1000-30000)."
                ),
            },
        },
        "required": ["url"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        method = str(args.get("method", "POST")).upper()
        url = str(args.get("url", "?"))
        # Display host-only to keep the receipt compact.
        try:
            host = urlparse(url).hostname or url
        except Exception:
            host = url
        return f"RemoteTrigger({method} {host[:60]})"

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        url = str(args.get("url", "")).strip()
        ok, reason = _validate_url(url)
        if not ok:
            return ToolResult(
                output=f"refused: {reason}",
                error=True,
                summary="remote_trigger blocked",
            )
        method = str(args.get("method", "POST")).upper()
        if method not in _ALLOWED_METHODS:
            return ToolResult(
                output=(
                    f"method {method!r} not allowed; use one of: "
                    f"{', '.join(_ALLOWED_METHODS)}"
                ),
                error=True,
                summary="bad method",
            )
        raw_headers = args.get("headers") or {}
        if not isinstance(raw_headers, dict):
            return ToolResult(
                output="headers must be an object (string -> string)",
                error=True,
                summary="bad headers",
            )
        headers: dict[str, str] = {}
        for k, v in raw_headers.items():
            if not isinstance(k, str) or not isinstance(v, str):
                return ToolResult(
                    output="header keys/values must be strings",
                    error=True,
                    summary="bad headers",
                )
            headers[k] = v
        body = str(args.get("body", "") or "")
        if len(body.encode("utf-8", "replace")) > _MAX_BODY_BYTES:
            return ToolResult(
                output=(
                    f"body exceeds {_MAX_BODY_BYTES} bytes "
                    f"(use external storage + reference URL instead)"
                ),
                error=True,
                summary="body too large",
            )
        try:
            timeout_ms = int(args.get("timeout_ms", _DEFAULT_TIMEOUT_MS))
        except (TypeError, ValueError):
            timeout_ms = _DEFAULT_TIMEOUT_MS
        timeout_ms = max(_MIN_TIMEOUT_MS, min(_MAX_TIMEOUT_MS, timeout_ms))

        # Defer the httpx import so unit tests can patch the layer
        # without paying for a real network request.
        try:
            import httpx
        except ImportError:
            return ToolResult(
                output="httpx is not installed",
                error=True,
                summary="httpx missing",
            )
        try:
            from prometheus.net import net_kwargs
        except ImportError:
            net_kwargs = lambda **kw: kw  # type: ignore[assignment]

        timeout_s = timeout_ms / 1000.0
        try:
            async with httpx.AsyncClient(**net_kwargs(timeout=timeout_s)) as client:
                response = await client.request(
                    method, url, headers=headers,
                    content=body.encode("utf-8") if body else None,
                )
        except httpx.TimeoutException:
            return ToolResult(
                output=f"timeout after {timeout_ms}ms",
                error=True,
                summary="remote_trigger timeout",
            )
        except httpx.RequestError as e:
            return ToolResult(
                output=f"network error: {type(e).__name__}: {e}",
                error=True,
                summary="remote_trigger network error",
            )
        except Exception as e:
            return ToolResult(
                output=f"unexpected error: {type(e).__name__}: {e}",
                error=True,
                summary="remote_trigger crash",
            )

        # Truncate the response body for the model — it's a notification
        # tool, not a content-fetch tool. Anything bigger than 4 KB
        # likely means the agent should use web_fetch instead.
        text = response.text or ""
        if len(text) > _MAX_RESPONSE_BYTES:
            text = text[:_MAX_RESPONSE_BYTES] + (
                f"\n…[truncated, full length {len(response.text)} bytes]"
            )
        is_error = response.status_code >= 400
        out_lines = [
            f"status: {response.status_code} {response.reason_phrase or ''}",
            f"method: {method}  url: {url}",
            "",
        ]
        if text:
            out_lines.append("--- response body ---")
            out_lines.append(text)
        return ToolResult(
            output="\n".join(out_lines).rstrip() + "\n",
            error=is_error,
            summary=(
                f"{method} {response.status_code}"
                if not is_error
                else f"{method} {response.status_code} (error)"
            ),
        )
