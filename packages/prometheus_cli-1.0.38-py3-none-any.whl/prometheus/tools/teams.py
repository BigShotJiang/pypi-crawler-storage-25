"""Round 107: TeamCreate / TeamDelete / SendMessage / TeamBroadcast tools.

The model-facing surface for Agent Teams. Tools refuse to operate
when team mode is disabled (PROMETHEUS_AGENT_TEAMS != 1) so the
default install behaves as before.
"""
from __future__ import annotations

from typing import Any

from prometheus.tools.base import (
    SideEffect,
    Tool,
    ToolContext,
    ToolResult,
)


def _team_mode_check() -> tuple[bool, str]:
    from prometheus.agent.teams import is_team_mode_enabled
    if not is_team_mode_enabled():
        return False, (
            "team mode disabled. Launch with `--agent-teams` "
            "or set `PROMETHEUS_AGENT_TEAMS=1`."
        )
    return True, ""


class TeamCreate(Tool):
    name = "team_create"
    description = (
        "Spawn a new teammate process under the Team Lead. "
        "Returns the teammate name. Requires team mode."
    )
    side_effect = SideEffect.WRITE
    schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "role": {"type": "string"},
            "color": {"type": "string", "default": "default"},
        },
        "required": ["name", "role"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        return f"TeamCreate({args.get('name', '?')})"

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        ok, msg = _team_mode_check()
        if not ok:
            return ToolResult(
                output=msg, error=True, summary="team mode off",
            )
        from prometheus.agent.teams import TeamRegistry
        reg = TeamRegistry.load(ctx.workdir)
        teammate, message = reg.create(
            name=str(args.get("name", "")).strip(),
            role=str(args.get("role", "")).strip(),
            color=str(args.get("color", "default")),
        )
        if teammate is None:
            return ToolResult(
                output=message, error=True, summary="create failed",
            )
        return ToolResult(
            output=message, summary=f"created · {teammate.name}",
            metadata={"teammate": teammate.name},
        )


class TeamDelete(Tool):
    name = "team_delete"
    description = "Remove a teammate. Requires team mode."
    side_effect = SideEffect.WRITE
    schema = {
        "type": "object",
        "properties": {"name": {"type": "string"}},
        "required": ["name"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        return f"TeamDelete({args.get('name', '?')})"

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        ok, msg = _team_mode_check()
        if not ok:
            return ToolResult(
                output=msg, error=True, summary="team mode off",
            )
        from prometheus.agent.teams import TeamRegistry
        reg = TeamRegistry.load(ctx.workdir)
        success, message = reg.delete(str(args.get("name", "")))
        return ToolResult(
            output=message,
            error=not success,
            summary="deleted" if success else "delete failed",
        )


class SendMessage(Tool):
    name = "send_message"
    description = (
        "Send a message to a specific teammate, visible in their "
        "conversation. Requires team mode. Round 112: pass "
        "`reply_to` to thread a reply onto a prior message."
    )
    side_effect = SideEffect.WRITE
    schema = {
        "type": "object",
        "properties": {
            "recipient": {"type": "string"},
            "body": {"type": "string"},
            "reply_to": {
                "type": "string",
                "description": (
                    "Optional id of the message this is a reply "
                    "to. Threads form via reply_to chains."
                ),
            },
        },
        "required": ["recipient", "body"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        return f"SendMessage({args.get('recipient', '?')})"

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        ok, msg = _team_mode_check()
        if not ok:
            return ToolResult(
                output=msg, error=True, summary="team mode off",
            )
        from prometheus.agent.teams import TeamRegistry
        reg = TeamRegistry.load(ctx.workdir)
        success, message = reg.send(
            sender="lead",
            recipient=str(args.get("recipient", "")),
            body=str(args.get("body", "")),
            reply_to=str(args.get("reply_to", "") or ""),
        )
        return ToolResult(
            output=message,
            error=not success,
            summary="sent" if success else "send failed",
        )


class TeamBroadcast(Tool):
    name = "team_broadcast"
    description = (
        "Send a message to ALL teammates. Requires team mode."
    )
    side_effect = SideEffect.WRITE
    schema = {
        "type": "object",
        "properties": {"body": {"type": "string"}},
        "required": ["body"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        return "TeamBroadcast()"

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        ok, msg = _team_mode_check()
        if not ok:
            return ToolResult(
                output=msg, error=True, summary="team mode off",
            )
        from prometheus.agent.teams import TeamRegistry
        reg = TeamRegistry.load(ctx.workdir)
        success, message = reg.send(
            sender="lead", recipient="*",
            body=str(args.get("body", "")),
        )
        return ToolResult(
            output=message,
            error=not success,
            summary="broadcast" if success else "broadcast failed",
        )
