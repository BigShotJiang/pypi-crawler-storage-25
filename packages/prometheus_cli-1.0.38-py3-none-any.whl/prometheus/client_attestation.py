"""Round 145-final-v3: client-attestation header.

Proves an API request originated from the genuine Prometheus
CLI executable. Header format:

    prometheus-cli/v{version} ({os}/{arch})

Behind `PROMETHEUS_CLIENT_ATTESTATION=1` — opt-in. The
provider can use the value for telemetry / abuse detection.
"""
from __future__ import annotations

import os
import platform
from typing import Optional


_TRUTHY = ("1", "true", "yes", "on")


def attestation_enabled() -> bool:
    return os.environ.get(
        "PROMETHEUS_CLIENT_ATTESTATION", "",
    ).strip().lower() in _TRUTHY


def _arch_token() -> str:
    """Round 145-final-v3: compact arch identifier."""
    m = platform.machine().lower()
    if m in ("amd64", "x86_64"):
        return "x86_64"
    if m in ("arm64", "aarch64"):
        return "arm64"
    if m.startswith("arm"):
        return "arm"
    if m.startswith("x86") or m.startswith("i"):
        return "i386"
    return m or "unknown"


def _os_token() -> str:
    s = platform.system().lower()
    if s.startswith("win"):
        return "windows"
    if s == "darwin":
        return "macos"
    return s or "unknown"


def _version() -> str:
    try:
        from prometheus import __version__ as v
        return v
    except ImportError:
        return "0.0.0"


def header_value() -> Optional[str]:
    """Round 145-final-v3: return the attestation header
    value when enabled, else None so the caller can skip
    setting the header at all."""
    if not attestation_enabled():
        return None
    return (
        f"prometheus-cli/v{_version()} "
        f"({_os_token()}/{_arch_token()})"
    )


def attach_header(headers: dict) -> dict:
    val = header_value()
    if val is None:
        return headers
    headers["x-prometheus-client"] = val
    return headers
