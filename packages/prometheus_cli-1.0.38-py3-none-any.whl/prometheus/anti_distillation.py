"""Round 143-final-v3: anti-distillation header injection.

Server-side feature — Prometheus only adds the header so the
provider can decide whether to inject decoy tool definitions
into the system prompt. The server uses the decoys to
distinguish genuine queries from training-data scraping.

Behind `PROMETHEUS_ANTI_DISTILLATION=1`. Default off — when
enabled, every API request includes:

    anti-distillation: fake_tools

The provider may inject decoys; the agent loop ignores any
tool whose name appears in the decoy list (server returns
that list in the response metadata).
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional


_TRUTHY = ("1", "true", "yes", "on")


def anti_distillation_enabled() -> bool:
    return os.environ.get(
        "PROMETHEUS_ANTI_DISTILLATION", "",
    ).strip().lower() in _TRUTHY


def header_value() -> Optional[str]:
    """Round 143-final-v3: return the header value to attach
    to API requests. None when disabled."""
    if not anti_distillation_enabled():
        return None
    return "fake_tools"


def attach_header(headers: dict) -> dict:
    """Round 143-final-v3: merge into a headers dict. Returns
    the mutated dict."""
    val = header_value()
    if val is None:
        return headers
    headers["anti-distillation"] = val
    return headers


def filter_decoy_tools(
    tools: list[dict], *, decoy_names: list[str],
) -> list[dict]:
    """Round 143-final-v3: drop any tool whose name appears
    in `decoy_names`. The server-returned list is the source
    of truth for which names to filter."""
    if not decoy_names:
        return tools
    blocked = {n.lower() for n in decoy_names if n}
    return [
        t for t in tools
        if str(t.get("name", "")).lower() not in blocked
    ]
