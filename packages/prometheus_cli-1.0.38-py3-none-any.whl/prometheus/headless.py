"""Round 126: Headless mode — `prometheus -p "<prompt>"`.

Non-interactive CLI for scripts, CI/CD, and automation. The
entry point parses CLI flags, builds a minimal AgentLoop, runs
the prompt to completion, prints the final reply, exits with
status reflecting success/failure.

Flags:
  -p, --print              non-interactive mode
  --output-format text|json|stream-json
  --bare                   skip hooks/plugins/skills/MCP/auto-memory
  --max-turns N            cap iterations (exit with error on hit)
  --max-budget-usd FLOAT   stop when API cost crosses cap
  --prompt TEXT            (alternative to positional)

The headless runner is process-isolated from the Textual app —
it imports AgentLoop directly and skips the Textual mount path
entirely. Output formats:

  text         — final assistant reply, plain.
  json         — JSON object: {"reply", "tool_calls", "cost", ...}
  stream-json  — one JSON object per AgentEvent, line-delimited.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import tempfile
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional


def _resolve_plugin_dir_arg(raw: str) -> str:
    """1.0.3 (CC v2.1.128 parity): turn `--plugin-dir` arg into a
    real directory.

    Accepts:
      - an existing directory path (returned as-is)
      - a `.zip` plugin archive (extracted to a temp dir, that path
        returned). Refuses entries with absolute paths or `..`
        components (Zip Slip defence). Refuses archives larger than
        20 MB after extraction (resource-exhaustion defence).
    """
    p = Path(raw).expanduser()
    if p.is_dir():
        return str(p)
    if p.is_file() and p.suffix.lower() == ".zip":
        max_total_bytes = 20 * 1024 * 1024
        out_dir = Path(tempfile.mkdtemp(prefix="prom-plugin-"))
        total = 0
        with zipfile.ZipFile(p) as zf:
            for member in zf.infolist():
                name = member.filename
                if not name or name.endswith("/"):
                    # Directory entry; create lazily via extract.
                    pass
                # Zip Slip: reject absolute paths and `..` components.
                clean = name.replace("\\", "/")
                if clean.startswith("/") or ".." in clean.split("/"):
                    raise ValueError(
                        f"refusing unsafe zip entry: {name!r}"
                    )
                total += member.file_size
                if total > max_total_bytes:
                    raise ValueError(
                        f"plugin zip exceeds {max_total_bytes} bytes "
                        f"after extraction"
                    )
            zf.extractall(out_dir)
        # If the zip wrapped a single top-level directory, return that
        # directory directly (matches how users typically zip plugins).
        children = [c for c in out_dir.iterdir() if not c.name.startswith(".")]
        if len(children) == 1 and children[0].is_dir():
            return str(children[0])
        return str(out_dir)
    raise ValueError(
        f"--plugin-dir expects an existing directory or a .zip "
        f"archive; got: {raw!r}"
    )


VALID_OUTPUT_FORMATS = ("text", "json", "stream-json")


# ---------- argparse builder ----------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="prometheus",
        description="PrometheUS — autonomous terminal coding assistant.",
        add_help=True,
    )
    parser.add_argument(
        "prompt", nargs="*",
        help="Prompt to run in non-interactive mode (with -p).",
    )
    parser.add_argument(
        "-p", "--print",
        dest="print_mode", action="store_true",
        help="Process the prompt and exit (non-interactive).",
    )
    parser.add_argument(
        "--prompt",
        dest="prompt_flag", default="",
        help="Alternative way to pass the prompt.",
    )
    parser.add_argument(
        "--output-format",
        choices=VALID_OUTPUT_FORMATS, default="text",
        help="Output format for --print mode.",
    )
    parser.add_argument(
        "--bare", action="store_true",
        help=(
            "Skip hooks, plugins, skills, MCP, auto-memory. "
            "Fast startup for quick queries."
        ),
    )
    parser.add_argument(
        "--max-turns", type=int, default=0,
        help="Cap agentic iterations in --print mode (0 = no cap).",
    )
    parser.add_argument(
        "--max-budget-usd", type=float, default=0.0,
        help="Stop when API cost exceeds this dollar amount.",
    )
    parser.add_argument(
        "-c", "--continue", dest="continue_session", action="store_true",
        help="Continue the most recent session.",
    )
    parser.add_argument(
        "-r", "--resume", dest="resume_id", default="",
        help="Resume a specific session by id.",
    )
    # Round 173: Claude Code's `--add-dir <path>` lets the user
    # attach extra working directories the agent can read/edit
    # without leaving the launch root. Repeatable. Tools that
    # take a path argument resolve against any of the registered
    # roots; outside-tree access still requires permission.
    parser.add_argument(
        "--add-dir", dest="add_dirs", action="append", default=[],
        metavar="PATH",
        help=(
            "Extra working directory (repeatable). The agent can "
            "read/edit files under any --add-dir as if they were "
            "inside the launch root."
        ),
    )
    parser.add_argument(
        "--strict-mcp-config", action="store_true",
        help=(
            "Fail loud if any --mcp-config file is missing or "
            "invalid (instead of silently degrading)."
        ),
    )
    # Round 175: Claude Code's `--permission-mode` selects the
    # initial permission posture. The four modes mirror what
    # Shift+Tab cycles through inside the TUI: `default` asks for
    # every non-read tool, `acceptEdits` auto-accepts file edits,
    # `plan` is read-only / planning-only, `bypassPermissions`
    # auto-approves every tool. Without this flag a user who only
    # ever runs `prometheus -p` (CI / pipelines / IDE bridges)
    # has no way to opt out of approval prompts at launch — they'd
    # have to use the harder-to-discover
    # `--dangerously-skip-permissions`.
    parser.add_argument(
        "--permission-mode",
        dest="permission_mode_initial",
        default="",
        choices=("", "default", "acceptEdits", "plan", "bypassPermissions"),
        help=(
            "Initial permission posture: default (ask) | "
            "acceptEdits (auto-accept edits) | plan (read-only) | "
            "bypassPermissions (auto-approve all). Empty leaves "
            "the user/project setting in place."
        ),
    )
    parser.add_argument(
        "--settings", dest="settings_path", default="",
        metavar="PATH",
        help=(
            "Path to an explicit settings.json. Overrides the "
            "default user/project/local settings hierarchy."
        ),
    )
    parser.add_argument(
        "--ide", action="store_true",
        help=(
            "Mark this session as IDE-attached. Reduces visual "
            "chrome and emits IDE-friendly status events."
        ),
    )
    parser.add_argument(
        "--agent-teams", action="store_true",
        help="Enable Agent Teams (round 107 feature).",
    )
    # ----- Round 130: model + permission control -----
    parser.add_argument(
        "--model", default="",
        help=(
            "Model id or tier alias (haiku/sonnet/opus/opusplan/best/auto). "
            "Round 130/135."
        ),
    )
    parser.add_argument(
        "--effort", default="",
        help="Reasoning effort: auto|low|medium|high|xhigh|max.",
    )
    parser.add_argument(
        "--fallback-model", default="",
        help=(
            "Model used when the primary is rate-limited or "
            "errors out. Round 130."
        ),
    )
    parser.add_argument(
        "--dangerously-skip-permissions", action="store_true",
        help=(
            "Auto-approve every tool call. Use only with code you "
            "trust completely. Round 130."
        ),
    )
    parser.add_argument(
        "--allow-dangerously-skip-permissions", action="store_true",
        help=(
            "Allow `bypassPermissions` to appear in the Shift+Tab "
            "permission cycle. Round 130."
        ),
    )
    # ----- Round 133: advanced CLI flags -----
    parser.add_argument(
        "--session-id", default="",
        help="Reuse the supplied UUID as the session id (Round 133).",
    )
    parser.add_argument(
        "--no-session-persistence", action="store_true",
        help=(
            "Skip writing this session to the SQLite store "
            "(Round 133)."
        ),
    )
    parser.add_argument(
        "--system-prompt", default="",
        help=(
            "Override the built-in system prompt with the supplied "
            "string (Round 133)."
        ),
    )
    parser.add_argument(
        "--system-prompt-file", default="",
        help=(
            "Path to a file whose contents replace the system "
            "prompt (Round 133)."
        ),
    )
    parser.add_argument(
        "--tools", default="",
        help=(
            "Comma-separated allowlist of tool names. All others "
            "are filtered out (Round 133)."
        ),
    )
    parser.add_argument(
        "--json-schema", default="",
        help=(
            "Path to a JSON-schema file. The final reply is "
            "validated against it (Round 133)."
        ),
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="Verbose log output (Round 133).",
    )
    parser.add_argument(
        "--debug", default="",
        help=(
            "Comma-separated debug categories: api,tools,subagents,"
            "all (Round 133)."
        ),
    )
    parser.add_argument(
        "--debug-file", default="",
        help="Write debug output to file (Round 133).",
    )
    parser.add_argument(
        "--mcp-config", default="",
        help=(
            "Path to an MCP server config JSON (Round 133)."
        ),
    )
    # ----- Round 136: ultimate cleanup flags -----
    parser.add_argument(
        "--name", "-n", default="",
        help="Name the session at launch (Round 136).",
    )
    parser.add_argument(
        "--worktree", "-w", action="store_true",
        help=(
            "Launch in an isolated git worktree of the current "
            "repo (Round 136)."
        ),
    )
    parser.add_argument(
        "--keep-worktree", action="store_true",
        help="Don't auto-clean the worktree on exit (Round 136).",
    )
    parser.add_argument(
        "--tmux", action="store_true",
        help=(
            "Wrap the session in a tmux session (POSIX only; "
            "no-op on Windows). Round 136."
        ),
    )
    parser.add_argument(
        "--append-system-prompt", default="",
        help="Text appended to the default system prompt (Round 136).",
    )
    parser.add_argument(
        "--append-system-prompt-file", default="",
        help="File whose content is appended to the system prompt.",
    )
    parser.add_argument(
        "--disable-slash-commands", action="store_true",
        help=(
            "Disable all skills, aptitudes, and slash commands "
            "(Round 136). Only `/help`, `/quit`, `/exit` remain."
        ),
    )
    # Round 183: --offline / --no-offline — Aider-style flag for
    # running on air-gapped networks. Sets PROMETHEUS_OFFLINE=1 in
    # the process env so every network-using tool refuses cleanly.
    parser.add_argument(
        "--offline", action="store_true",
        help=(
            "Refuse network tools (web_fetch, web_search, MCP-over-"
            "HTTP) with a clean message instead of timing out. The "
            "LLM provider connection is NOT gated by this flag — "
            "set --base-url to point at a local LLM if the upstream "
            "is also unreachable. Equivalent to PROMETHEUS_OFFLINE=1."
        ),
    )
    # Round 183: --reasoning-effort dial (Aider parity).
    parser.add_argument(
        "--reasoning-effort", default="",
        choices=("", "minimal", "low", "medium", "high", "xhigh", "max", "0"),
        help=(
            "Set the LLM reasoning-effort dial. low/medium/high are "
            "the Aider names; xhigh/max map to Claude Opus 4.7's "
            "highest tier; 0 disables thinking entirely. Empty = "
            "model default. Equivalent to PROMETHEUS_REASONING_EFFORT."
        ),
    )
    parser.add_argument(
        "--add-gitignore-files", action="store_true",
        help=(
            "Allow editing files matched by .gitignore. Default off "
            "(generated artifacts, lock files, .env are usually "
            "skipped). Aider parity. Equivalent to "
            "PROMETHEUS_ADD_GITIGNORE_FILES=1."
        ),
    )
    parser.add_argument(
        "--setting-sources", default="",
        help=(
            "Comma-separated list of config sources to load "
            "(user,project,local,managed). Round 136."
        ),
    )
    parser.add_argument(
        "--betas", default="",
        help=(
            "Comma-separated API beta headers to include in "
            "requests (Round 136)."
        ),
    )
    parser.add_argument(
        "--include-partial-messages", action="store_true",
        help=(
            "Stream partial message events for streaming-compatible "
            "output formats (Round 136)."
        ),
    )
    parser.add_argument(
        "--input-format", default="text",
        choices=("text", "stream-json"),
        help="Input format for headless mode (Round 136).",
    )
    parser.add_argument(
        "--replay-user-messages", action="store_true",
        help=(
            "Re-emit stdin user messages in the output (Round 136)."
        ),
    )
    parser.add_argument(
        "--teammate-mode", default="in-process",
        choices=("in-process", "tmux", "auto"),
        help="Round 136: how Agent Teams spawn teammates.",
    )
    parser.add_argument(
        "--thinking", default="",
        choices=("", "on", "off"),
        help="Round 136: extended-thinking toggle at launch.",
    )
    # ----- Round 137: TRUE-final flags -----
    parser.add_argument(
        "--dump-system-prompt", action="store_true",
        help=(
            "Round 137: print the assembled system prompt to "
            "stdout and exit."
        ),
    )
    parser.add_argument(
        "--from-pr", type=int, default=0,
        help=(
            "Round 137: resume a session linked to a specific "
            "GitHub PR number."
        ),
    )
    parser.add_argument(
        "--fork-session", default="",
        help=(
            "Round 137: fork an existing session at its current "
            "state and start fresh."
        ),
    )
    # ----- Round 138: final polish flags -----
    parser.add_argument(
        "--fast", action="store_true",
        help="Round 138: launch in Fast Mode (low-latency).",
    )
    parser.add_argument(
        "--tui", default="",
        help=(
            "Round 138: TUI rendering mode. `fullscreen` enters "
            "alternate-screen + diff renderer."
        ),
    )
    # ----- Round 139: TRUE-final flags -----
    parser.add_argument(
        "--allowedTools", default="",
        help=(
            "Round 139: comma-separated tool allowlist for this "
            "session. Overrides all other tool config."
        ),
    )
    parser.add_argument(
        "--disallowedTools", default="",
        help=(
            "Round 139: comma-separated tool blocklist for this "
            "session."
        ),
    )
    parser.add_argument(
        "--agent", "--agents", dest="agent_name", default="",
        help=(
            "Round 139: use a named Cohort agent definition as "
            "the main conversation agent at launch."
        ),
    )
    parser.add_argument(
        "--init", action="store_true",
        help=(
            "Round 139: run setup hooks + Charter generation, "
            "then start interactive session."
        ),
    )
    parser.add_argument(
        "--init-only", action="store_true",
        help=(
            "Round 139: run initialization only and exit."
        ),
    )
    parser.add_argument(
        "--plugin-dir", default="",
        help=(
            "Round 139: load a single Forge Kit from a local "
            "directory for this session only. 1.0.3 (CC v2.1.128 "
            "parity): also accepts a `.zip` plugin archive — it is "
            "extracted to a temp directory and that directory is "
            "used for the session."
        ),
    )
    parser.add_argument(
        "--plugin-url", default="",
        help=(
            "Round 139: load a single Forge Kit from a URL "
            "for this session only."
        ),
    )
    parser.add_argument(
        "--include-hook-events", action="store_true",
        help=(
            "Round 139: include Sentinel hook event output in "
            "stream-json output."
        ),
    )
    parser.add_argument(
        "--no-chrome", action="store_true",
        help=(
            "Round 139: explicitly disable Chrome/Playwright "
            "integration at launch."
        ),
    )
    return parser


# ---------- result envelope ----------


@dataclass
class HeadlessResult:
    ok: bool
    reply: str = ""
    tool_calls: int = 0
    iterations: int = 0
    cost_usd: float = 0.0
    error: str = ""
    truncated_by: str = ""    # `max-turns` / `max-budget-usd` / ""

    def exit_code(self) -> int:
        if not self.ok or self.error:
            return 1
        if self.truncated_by:
            return 2
        return 0

    def to_json(self) -> str:
        return json.dumps({
            "ok": self.ok,
            "reply": self.reply,
            "tool_calls": self.tool_calls,
            "iterations": self.iterations,
            "cost_usd": self.cost_usd,
            "error": self.error,
            "truncated_by": self.truncated_by,
        }, indent=None)


# ---------- bare-mode env application ----------


_BARE_ENV_FLAGS = (
    ("PROMETHEUS_DISABLE_AUTO_MEMORY", "1"),
    ("PROMETHEUS_DISABLE_HOOKS", "1"),
    ("PROMETHEUS_DISABLE_MCP", "1"),
    ("PROMETHEUS_DISABLE_SKILLS", "1"),
    ("PROMETHEUS_DISABLE_PLUGINS", "1"),
)


def apply_bare_mode(env: Optional[dict] = None) -> dict:
    """Round 126: when `--bare` is set, populate the env vars
    that other subsystems honor as opt-out flags. Returns the
    mutated env so callers can inspect what changed."""
    target = env if env is not None else os.environ
    for k, v in _BARE_ENV_FLAGS:
        target[k] = v
    return target


# ---------- run loop helpers ----------


def is_print_mode(args: argparse.Namespace) -> bool:
    return bool(args.print_mode)


def collect_prompt(args: argparse.Namespace) -> str:
    """Combine positional prompt + --prompt flag."""
    parts: list[str] = []
    if args.prompt:
        parts.append(" ".join(args.prompt))
    if args.prompt_flag:
        parts.append(args.prompt_flag)
    return " ".join(p for p in parts if p).strip()


# ---------- the run path ----------


async def run_headless(args: argparse.Namespace) -> HeadlessResult:
    """Round 126: drive an AgentLoop to completion in print mode.

    Round-126 scope: the runner interface + flag handling +
    output-format dispatch. The actual model call uses the same
    `AgentLoop.run()` the interactive app uses; we just consume
    events differently here (print to stdout instead of mounting
    UI widgets).
    """
    prompt = collect_prompt(args)
    if not prompt:
        return HeadlessResult(
            ok=False,
            error="no prompt given. Use `-p \"<prompt>\"`.",
        )
    if args.bare:
        apply_bare_mode()
    if args.agent_teams:
        os.environ["PROMETHEUS_AGENT_TEAMS"] = "1"
    if args.max_turns > 0:
        os.environ["PROMETHEUS_MAX_ITERATIONS"] = str(args.max_turns)
    # Round 130/133: env-flip for bypass + advanced flags so the
    # rest of the runtime picks them up via existing accessors.
    if getattr(args, "dangerously_skip_permissions", False):
        from prometheus.bypass_mode import set_bypass_active
        set_bypass_active(True)
        sys.stderr.write(
            "⚠ BYPASS PERMISSIONS — every tool auto-approved.\n"
        )
    if getattr(args, "allow_dangerously_skip_permissions", False):
        from prometheus.bypass_mode import set_bypass_in_cycle
        set_bypass_in_cycle(True)
    # Round 175: --permission-mode wires the initial posture via
    # the same env-var handoff the other launch flags use, so the
    # interactive PermissionBar / agent loop pick it up without a
    # separate code path. `bypassPermissions` here is exactly the
    # in-cycle mode (Shift+Tab visible). For the dangerous one-shot
    # auto-approve, --dangerously-skip-permissions stays the only
    # entry — that flag has its own scary-warning print path.
    if getattr(args, "permission_mode_initial", ""):
        mode = args.permission_mode_initial
        os.environ["PROMETHEUS_PERMISSION_MODE"] = mode
        if mode == "bypassPermissions":
            from prometheus.bypass_mode import set_bypass_active, set_bypass_in_cycle
            set_bypass_active(True)
            set_bypass_in_cycle(True)
    # Round 176: --add-dir plumbing. Until R176 the flag was
    # accepted by argparse but never propagated — `--add-dir /tmp`
    # was a silent no-op. Now: collect every supplied path, push
    # to PROMETHEUS_ADD_DIRS as a colon-separated list, and merge
    # into the live Settings instance so file-resolving tools can
    # consult them.
    extra_dirs = list(getattr(args, "add_dirs", []) or [])
    if extra_dirs:
        from pathlib import Path as _Path
        canonical: list[str] = []
        for d in extra_dirs:
            try:
                p = _Path(d).expanduser().resolve()
                if p.exists() and p.is_dir():
                    canonical.append(str(p))
                else:
                    sys.stderr.write(
                        f"⚠ --add-dir skipped (not a directory): {d}\n"
                    )
            except Exception as e:
                sys.stderr.write(f"⚠ --add-dir skipped ({e}): {d}\n")
        if canonical:
            os.environ["PROMETHEUS_ADD_DIRS"] = os.pathsep.join(canonical)
    if getattr(args, "fallback_model", ""):
        os.environ["PROMETHEUS_FALLBACK_MODEL"] = args.fallback_model
    if getattr(args, "model", ""):
        os.environ["PROMETHEUS_MODEL"] = args.model
    if getattr(args, "no_session_persistence", False):
        os.environ["PROMETHEUS_NO_SESSION_PERSISTENCE"] = "1"
    if getattr(args, "verbose", False):
        os.environ["PROMETHEUS_VERBOSE"] = "1"
    if getattr(args, "debug", ""):
        os.environ["PROMETHEUS_DEBUG"] = args.debug
    # Round 136: env handoff for the absolute-final flags.
    if getattr(args, "disable_slash_commands", False):
        os.environ["PROMETHEUS_DISABLE_SLASH_COMMANDS"] = "1"
    if getattr(args, "setting_sources", ""):
        os.environ["PROMETHEUS_SETTING_SOURCES"] = args.setting_sources
    if getattr(args, "betas", ""):
        os.environ["PROMETHEUS_API_BETAS"] = args.betas
    if getattr(args, "include_partial_messages", False):
        os.environ["PROMETHEUS_INCLUDE_PARTIAL"] = "1"
    if getattr(args, "replay_user_messages", False):
        os.environ["PROMETHEUS_REPLAY_USER_MESSAGES"] = "1"
    if getattr(args, "teammate_mode", ""):
        os.environ["PROMETHEUS_TEAMMATE_MODE"] = args.teammate_mode
    if getattr(args, "thinking", ""):
        os.environ["PROMETHEUS_THINKING"] = args.thinking
    if getattr(args, "name", ""):
        os.environ["PROMETHEUS_SESSION_NAME"] = args.name
    # Round 139: env handoff for TRUE-final flags.
    if getattr(args, "allowedTools", ""):
        os.environ["PROMETHEUS_ALLOWED_TOOLS"] = args.allowedTools
    if getattr(args, "disallowedTools", ""):
        os.environ["PROMETHEUS_DISALLOWED_TOOLS"] = args.disallowedTools
    if getattr(args, "agent_name", ""):
        os.environ["PROMETHEUS_AGENT_NAME"] = args.agent_name
    if getattr(args, "plugin_dir", ""):
        # 1.0.3 (CC v2.1.128 parity): --plugin-dir also accepts a
        # `.zip` plugin archive. Extract it to a temp directory and
        # point PROMETHEUS_PLUGIN_DIR at the extracted root. Refuses
        # absolute / parent-traversing entries (Zip Slip defence).
        _resolved_plugin_dir = _resolve_plugin_dir_arg(args.plugin_dir)
        os.environ["PROMETHEUS_PLUGIN_DIR"] = _resolved_plugin_dir
    if getattr(args, "plugin_url", ""):
        os.environ["PROMETHEUS_PLUGIN_URL"] = args.plugin_url
    if getattr(args, "include_hook_events", False):
        os.environ["PROMETHEUS_INCLUDE_HOOK_EVENTS"] = "1"
    if getattr(args, "no_chrome", False):
        os.environ["PROMETHEUS_DISABLE_CHROME"] = "1"
    if getattr(args, "init", False) or getattr(args, "init_only", False):
        os.environ["PROMETHEUS_INIT_FLOW"] = (
            "init-only" if getattr(args, "init_only", False) else "init"
        )
    # Build minimal AgentLoop. Importing here keeps the
    # textual-free import path clean for tests that don't need
    # the model.
    try:
        from prometheus.agent.loop import AgentLoop
        from prometheus.config import load_settings
        from prometheus.provider.openrouter import OpenRouterClient
        from prometheus.tools.registry import build_default_registry
    except Exception as e:
        return HeadlessResult(
            ok=False, error=f"runtime import failed: {e}",
        )
    # 1.0.3 first-day bug fix: bare `Settings()` returned an empty
    # config — the api_key, model, and the rest of the user's
    # settings.json were silently ignored. `load_settings()` is the
    # canonical loader used everywhere else (TUI, /doctor, slash
    # commands) and produces a populated `Settings` object.
    try:
        settings = load_settings()
    except Exception as e:
        return HeadlessResult(
            ok=False, error=f"settings init failed: {e}",
        )
    if args.max_turns > 0:
        try:
            settings.max_iterations = args.max_turns
        except Exception:
            pass
    registry = build_default_registry()
    client: Any = None
    # 1.0.3 first-day bug fix: pass the configured api_key (and
    # related fields) into the client. The bare `OpenRouterClient()`
    # call would crash on the required `api_key` positional, which
    # in `--output-format text` mode emerged as a silent exit-1
    # with no stdout at all on a brand-new user's first run.
    api_key = (getattr(settings, "api_key", "") or "").strip()
    if not api_key:
        return HeadlessResult(
            ok=False,
            error=(
                "no API key configured. Set PROMETHEUS_API_KEY or "
                "OPENROUTER_API_KEY, or place your key in "
                "~/.prometheus/settings.json under `api_key`."
            ),
        )
    try:
        client_kwargs: dict[str, Any] = {"api_key": api_key}
        # `model` and `base_url` are optional positionals on the
        # client; pass through whatever the settings provided so
        # `--model …` / custom base URLs propagate to headless too.
        base_url = (getattr(settings, "base_url", "") or "").strip()
        if base_url:
            client_kwargs["base_url"] = base_url
        client = OpenRouterClient(**client_kwargs)
    except Exception as e:
        return HeadlessResult(
            ok=False,
            error=(
                f"could not initialize the model client: {e}. "
                f"Check your provider config."
            ),
        )

    async def _noop_approval(*a, **kw): return True

    def _noop_notify(_): pass
    def _noop_audit(*a, **kw): pass
    loop = AgentLoop(
        client=client, registry=registry, settings=settings,
        request_approval=_noop_approval,
        notify=_noop_notify,
        audit=_noop_audit,
        session_id=f"headless-{int(time.time())}",
    )
    # Round 176: fire SessionStart so workflows can checkpoint /
    # log / pre-warm caches at the start of every headless run.
    # Non-blocking; failure is silent.
    try:
        from prometheus.safety.hooks import fire_session_start
        fire_session_start(
            settings.workdir,
            session_id=loop.session_id,
            source="headless",
        )
    except Exception:
        pass
    reply_chunks: list[str] = []
    n_tool_calls = 0
    n_iterations = 0
    cost = 0.0
    truncated_by = ""
    error = ""
    fmt = args.output_format
    # Round 176: Claude-Code-compatible stream-json envelope.
    # Earlier the format was `{"kind": ...}` — neither the field
    # name nor the event taxonomy matched CC's documented format.
    # CI scripts, IDE bridges, and CC-style consumers parsing
    # `{"type": "system"|"user"|"assistant"|"result"|"tool_use"|
    # "tool_result"}` would have seen unknown events and either
    # broken or silently ignored everything.
    _stream_started_at = time.time()
    if fmt == "stream-json":
        init_msg = {
            "type": "system",
            "subtype": "init",
            "session_id": loop.session_id,
            "cwd": str(settings.workdir),
            "model": getattr(settings, "model", ""),
            "tools": list(registry.names()),
            "permission_mode": getattr(settings, "default_mode", "")
                or os.environ.get("PROMETHEUS_PERMISSION_MODE", "default"),
        }
        sys.stdout.write(json.dumps(init_msg) + "\n")
        sys.stdout.flush()
        # Echo the user prompt as Claude Code does.
        user_msg = {
            "type": "user",
            "session_id": loop.session_id,
            "message": {
                "role": "user",
                "content": [{"type": "text", "text": prompt}],
            },
        }
        sys.stdout.write(json.dumps(user_msg) + "\n")
        sys.stdout.flush()
    # 1.0.3 first-day bug fix: `OpenRouterClient` lazily creates
    # its httpx.AsyncClient inside `__aenter__`; calling `.stream()`
    # outside `async with` asserts with `"use async with"`. The TUI
    # path enters the client when the App starts; headless never
    # did, so every -p invocation crashed at the first model call.
    # Use explicit __aenter__/__aexit__ rather than `async with`
    # to avoid re-indenting the existing 70-line event loop.
    try:
        await client.__aenter__()
    except Exception as e:
        return HeadlessResult(
            ok=False, error=f"client enter failed: {e}",
        )
    # 1.0.3 stream-json hardening — round 200 live audit caught
    # four divergences from CC's documented stream-json contract:
    #
    #   1. `iteration`/`final` events were leaking through as CC-
    #      foreign types (CC's vocabulary is system|user|assistant|
    #      tool_use|tool_result|result).
    #   2. `usage` events were emitted twice per LLM call (raw
    #      duplicate). CI consumers parsing total_tokens would
    #      double-count.
    #   3. `tool_result` events had no payload — no `tool_use_id`
    #      to correlate against the prior `tool_use`, no `content`
    #      with the actual result.
    #   4. `tool_use.id` was an empty string when the upstream
    #      provider didn't supply one. CC always populates it; CI
    #      consumers use it to match tool_use → tool_result.
    _last_usage_sig: str = ""
    # Round 210: track the last-emitted prompt_tokens so we can
    # suppress streaming-delta usage events (each completion-token
    # chunk emits a usage update with the SAME prompt_tokens but
    # bumped total_tokens; relaying every chunk floods stream-json
    # with O(N) usage events per turn). Claude Code emits one
    # usage event per turn — match that.
    _last_usage_prompt_tokens: int = -1
    _synth_id_counter: int = 0
    _last_tool_use_id: str = ""

    def _ensure_id(call_id: str) -> str:
        nonlocal _synth_id_counter
        if call_id:
            return call_id
        _synth_id_counter += 1
        return f"toolu_synth_{loop.session_id}_{_synth_id_counter}"

    try:
        async for ev in loop.run(prompt):
            if fmt == "stream-json":
                # CC's documented event taxonomy. Anything not in
                # this map is a Prometheus-internal event (iteration,
                # final, etc.) and must NOT be emitted in the
                # CC-shaped stream — it would confuse parsers.
                cc_type_map = {
                    "text": "assistant",
                    "tool_call": "tool_use",
                    "tool_result": "tool_result",
                    "usage": "usage",
                    # Round 210: `error` and `halt` are NOT mapped here.
                    # They used to map to "result" which emitted an
                    # inline result event ALONGSIDE the final-envelope
                    # result emitted at end-of-run, producing TWO
                    # `{"type":"result"}` events per failing run. CC
                    # emits exactly one. The error/halt branches below
                    # set the `error` and `truncated_by` flags and let
                    # the final envelope at end-of-run carry the
                    # subtype/is_error/result text.
                }
                cc_type = cc_type_map.get(ev.kind)
                if cc_type is None:
                    # R223: special-case `final` events that carry text.
                    # The fast-finalize path (loop.py:1809) emits the
                    # synthesized reply only as `final` — never as a
                    # `text` event, because the TUI renders it via
                    # `last_assistant_text` and a duplicate `text`
                    # event would triple-render in the chat log
                    # (R96.5 comment). But headless mode never sees
                    # the TUI rendering; without this branch the
                    # fast-finalize reply was silently dropped and
                    # the result envelope's `result` field came out
                    # empty. Surface it as assistant here so
                    # `prometheus -p ... --output-format stream-json`
                    # carries the answer.
                    if ev.kind == "final" and getattr(ev, "text", ""):
                        obj = {
                            "type": "assistant",
                            "session_id": loop.session_id,
                            "message": {
                                "role": "assistant",
                                "content": [{"type": "text", "text": ev.text}],
                            },
                        }
                        sys.stdout.write(json.dumps(obj) + "\n")
                        sys.stdout.flush()
                    # Drop iteration/final/other internal events.
                    pass
                else:
                    obj: dict[str, Any] = {
                        "type": cc_type,
                        "session_id": loop.session_id,
                    }
                    emit = True
                    if ev.kind == "text" and ev.text:
                        obj["message"] = {
                            "role": "assistant",
                            "content": [{"type": "text", "text": ev.text}],
                        }
                    elif ev.kind == "text":
                        # Empty text events are noise.
                        emit = False
                    if ev.kind == "tool_call" and ev.tool_call:
                        tool_name = getattr(ev.tool_call, "name", "")
                        # 1.0.4 final-QA fix: ToolCall stores the
                        # arguments as a JSON STRING in `.arguments`
                        # and exposes a parsed dict via the
                        # `.parsed_arguments()` method. The previous
                        # `.args` getattr always returned {} (the
                        # default) because no such attribute exists,
                        # so every stream-json `input` field was
                        # empty in production — CI consumers parsing
                        # tool_use to determine "what command did
                        # the agent run?" got nothing.
                        parser = getattr(ev.tool_call, "parsed_arguments", None)
                        if callable(parser):
                            try:
                                tool_input = parser() or {}
                            except Exception:
                                tool_input = {}
                        else:
                            tool_input = (
                                getattr(ev.tool_call, "args", None)
                                or getattr(ev.tool_call, "arguments", None)
                                or {}
                            )
                            if isinstance(tool_input, str):
                                # Last-ditch — raw json string.
                                try:
                                    tool_input = json.loads(tool_input)
                                except (ValueError, TypeError):
                                    tool_input = {}
                        # ToolCall's id field is `id`, not `call_id`.
                        # Try both for forward-compat with any future
                        # rename, but the canonical one is `id`.
                        upstream_id = (
                            getattr(ev.tool_call, "id", "")
                            or getattr(ev.tool_call, "call_id", "")
                            or ""
                        )
                        tool_id = _ensure_id(upstream_id)
                        _last_tool_use_id = tool_id
                        obj["name"] = tool_name
                        obj["input"] = tool_input
                        obj["id"] = tool_id
                    if ev.kind == "tool_result":
                        # Correlate with the immediately-prior
                        # tool_use via id, and surface the actual
                        # result content so CC-shaped consumers
                        # can read tool output without inferring.
                        tc = getattr(ev, "tool_call", None)
                        result = getattr(ev, "tool_result", None)
                        tu_id = ""
                        if tc is not None:
                            # 1.0.4 final-QA fix: ToolCall.id, not
                            # .call_id (see above).
                            tu_id = (
                                getattr(tc, "id", "")
                                or getattr(tc, "call_id", "")
                                or ""
                            )
                        obj["tool_use_id"] = tu_id or _last_tool_use_id
                        result_text = ""
                        is_err = False
                        if result is not None:
                            result_text = getattr(result, "output", "") or ""
                            is_err = bool(getattr(result, "error", False))
                        obj["content"] = [
                            {"type": "text", "text": result_text[:4000]},
                        ]
                        obj["is_error"] = is_err
                    if ev.kind == "usage" and ev.usage:
                        # Round 210: emit usage only when the prompt-
                        # token count changes — that's the signal of
                        # a new TURN. Streaming token deltas keep
                        # prompt_tokens fixed and only bump
                        # completion_tokens; flooding stream-json
                        # with one usage event per token chunk is the
                        # exact divergence from CC the round-210
                        # sweep surfaced. Final per-turn cost still
                        # reaches the result envelope through `cost`
                        # accumulation below.
                        try:
                            pt = int(ev.usage.get("prompt_tokens", 0) or 0)
                        except (TypeError, ValueError):
                            pt = -1
                        sig = json.dumps(ev.usage, sort_keys=True, default=str)
                        if (
                            pt == _last_usage_prompt_tokens
                            or sig == _last_usage_sig
                        ):
                            emit = False
                        else:
                            _last_usage_sig = sig
                            _last_usage_prompt_tokens = pt
                            obj["usage"] = ev.usage
                    if ev.kind in ("error", "halt"):
                        obj["subtype"] = "error_during_execution"
                        obj["is_error"] = True
                        obj["result"] = str(getattr(ev, "error", "")) or ev.kind
                    if emit:
                        sys.stdout.write(json.dumps(obj) + "\n")
                        sys.stdout.flush()
            if ev.kind == "text" and ev.text:
                reply_chunks.append(ev.text)
            if ev.kind == "tool_call":
                n_tool_calls += 1
            # Round 212: emit Claude Code's `compact_boundary` event
            # whenever auto-compaction fires. CC stream-json consumers
            # parse this to know that older turns were summarized so
            # message-history reconstruction stays accurate. The
            # `_maybe_compact()` method in agent/loop.py emits a
            # `kind="compact"` AgentEvent on success or graceful
            # degradation; we relay the success cases as
            # `compact_boundary` and skip the failure-text variant.
            if (
                ev.kind == "compact"
                and fmt == "stream-json"
                and ev.text
                and ev.text.startswith("compacted ")
            ):
                # Round 212: emit Claude Code's `compact_boundary`
                # event. The agent loop's `_maybe_compact()` populates
                # ev.metadata with preTokens and trigger; fall back
                # to parsing ev.text if metadata isn't present (older
                # call sites, future custom emitters).
                meta = ev.metadata or {}
                pre_tokens = int(meta.get("preTokens", 0) or 0)
                trigger = meta.get("trigger") or "auto"
                if not pre_tokens:
                    # Fallback: extract message count from "compacted N..."
                    try:
                        head_tok = ev.text.split(" ", 2)
                        if len(head_tok) >= 2 and head_tok[0] == "compacted":
                            pre_tokens = int(head_tok[1])
                    except (ValueError, IndexError):
                        pre_tokens = 0
                cb = {
                    "type": "compact_boundary",
                    "session_id": loop.session_id,
                    "compactMetadata": {
                        "trigger": "auto" if trigger == "tokens" else trigger,
                        "preTokens": pre_tokens,
                    },
                }
                sys.stdout.write(json.dumps(cb) + "\n")
                sys.stdout.flush()
            if ev.kind == "iteration":
                n_iterations += 1
                if args.max_turns and n_iterations > args.max_turns:
                    truncated_by = "max-turns"
                    break
            if ev.kind == "usage" and ev.usage:
                try:
                    cost += float(ev.usage.get("cost", 0) or 0)
                except (TypeError, ValueError):
                    pass
                if (
                    args.max_budget_usd > 0
                    and cost >= args.max_budget_usd
                ):
                    truncated_by = "max-budget-usd"
                    sys.stderr.write(
                        f"⚠ budget cap ${args.max_budget_usd:.2f} "
                        f"crossed at ${cost:.4f} — stopping.\n"
                    )
                    break
            if ev.kind == "error":
                error = str(getattr(ev, "error", "") or "stream error")
                break
            if ev.kind == "halt":
                error = str(getattr(ev, "error", "") or "halted")
                break
    except Exception as e:
        try:
            await client.__aexit__(None, None, None)
        except Exception:
            pass
        return HeadlessResult(
            ok=False, error=f"agent run failed: {e}",
        )
    # 1.0.3: client must be released — held httpx.AsyncClient leaks
    # otherwise.
    try:
        await client.__aexit__(None, None, None)
    except Exception:
        pass
    reply = "".join(reply_chunks).strip()
    # Round 211: sanitize the final reply before it lands in the
    # result envelope. R210 added JSON-shape tool-call leak
    # detection (`{"name": "task", "arguments": {...}}`) but only
    # wired it into TUI rendering and stored-message history. The
    # stream-json `result` envelope was emitting the raw leak
    # because the sanitizer wasn't called here. T7 (R210 + R211)
    # captured this — the result.result string contained four
    # concatenated JSON tool-call blocks instead of the model's
    # actual prose answer. Fix: run `sanitize()` on the reply
    # right before the envelope is built.
    try:
        from prometheus.agent.leak_sanitizer import sanitize as _sanitize_leak
        cleaned_reply, _leaks = _sanitize_leak(reply)
        reply = cleaned_reply.strip()
    except Exception:
        pass
    # Round 176: emit Claude-Code-style `result` envelope as the
    # closing event of stream-json output. CI consumers parse this
    # to determine success / failure and to extract the final reply.
    if fmt == "stream-json":
        duration_ms = int((time.time() - _stream_started_at) * 1000)
        result_msg = {
            "type": "result",
            "subtype": "error_during_execution" if error else (
                "max_turns_exceeded" if truncated_by == "max-turns"
                else ("max_budget_exceeded" if truncated_by == "max-budget-usd"
                      else "success")
            ),
            "is_error": bool(error),
            "duration_ms": duration_ms,
            "num_turns": n_iterations,
            "result": reply,
            "session_id": loop.session_id,
            "total_cost_usd": round(cost, 4),
            "tool_calls": n_tool_calls,
        }
        sys.stdout.write(json.dumps(result_msg) + "\n")
        sys.stdout.flush()
    # Round 176: fire SessionEnd at the end of every headless run.
    try:
        from prometheus.safety.hooks import fire_session_end
        fire_session_end(
            settings.workdir,
            session_id=loop.session_id,
            reason=truncated_by or ("error" if error else "complete"),
        )
    except Exception:
        pass
    return HeadlessResult(
        ok=not error and not truncated_by,
        reply=reply,
        tool_calls=n_tool_calls,
        iterations=n_iterations,
        cost_usd=round(cost, 4),
        error=error,
        truncated_by=truncated_by,
    )


def render_result(
    result: HeadlessResult, fmt: str,
) -> str:
    """Return what should land on stdout for `text` / `json`
    formats. `stream-json` was already streamed during run —
    including its closing `result` envelope (round 176), so we
    return empty here to avoid emitting the legacy summary blob
    on top of the proper CC-shaped final event."""
    if fmt == "stream-json":
        return ""
    if fmt == "json":
        return result.to_json()
    return result.reply
