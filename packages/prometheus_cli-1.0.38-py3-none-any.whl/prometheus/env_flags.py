"""Round 137: environment-variable flags.

Twelve env-driven toggles that the host consults at runtime.
Each accessor returns a bool/str so callers can short-circuit
features quickly without touching settings.json.

Defaults are conservative: every new flag is off by default,
preserving the round-136 behavior unless the user opts in.
"""
from __future__ import annotations

import os


_TRUTHY = ("1", "true", "yes", "on")


def _flag(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in _TRUTHY


# ---------- PROMETHEUS_SIMPLE ----------


def simple_mode_active() -> bool:
    """Round 137: minimal-tools mode (Bash, Read, Edit only).
    Existed before round 137 — the accessor is the canonical
    public API."""
    return _flag("PROMETHEUS_SIMPLE")


# ---------- PROMETHEUS_HIDE_CWD ----------


def hide_cwd() -> bool:
    """Round 137: hide working directory in startup banner."""
    return _flag("PROMETHEUS_HIDE_CWD")


# ---------- PROMETHEUS_DISABLE_1M_CONTEXT ----------


def disable_1m_context() -> bool:
    """Round 137: skip the 1M-context model variants in
    routing decisions."""
    return _flag("PROMETHEUS_DISABLE_1M_CONTEXT")


# ---------- PROMETHEUS_DISABLE_NONESSENTIAL_TRAFFIC ----------


def nonessential_traffic_disabled() -> bool:
    """Round 137: disable telemetry, feedback, error reporting.
    Returns True for any of the three disablers being set
    (PrometheUS doesn't ship telemetry, but third-party plugins
    may; this is the canonical signal).

    Round 185: also honour the cross-tool env-var aliases
    (`DISABLE_TELEMETRY`, `CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC`,
    `DISABLE_ERROR_REPORTING`, `DISABLE_AUTOUPDATER`) so a user
    migrating from Claude Code / Codex / Aider doesn't have to
    flip a Prometheus-specific flag to opt out. Any of these
    being truthy disables non-essential traffic.
    """
    return (
        _flag("PROMETHEUS_DISABLE_NONESSENTIAL_TRAFFIC")
        or _flag("DISABLE_TELEMETRY")
        or _flag("CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC")
        or _flag("DISABLE_ERROR_REPORTING")
        or _flag("DISABLE_AUTOUPDATER")
        or os.environ.get("PROMETHEUS_TELEMETRY", "off").strip().lower()
        not in ("on", "1", "true", "yes")
    )


# ---------- PROMETHEUS_FORK_SUBAGENT ----------


def fork_subagent_enabled() -> bool:
    """Round 137: when set, dispatched cohorts inherit the
    parent's full conversation context instead of starting
    fresh."""
    return _flag("PROMETHEUS_FORK_SUBAGENT")


# ---------- PROMETHEUS_NEW_INIT ----------


def new_init_flow() -> bool:
    """Round 137: switch /init to interactive setup instead of
    auto-generated."""
    return _flag("PROMETHEUS_NEW_INIT")


# ---------- PROMETHEUS_SUBPROCESS_ENV_SCRUB ----------


_SUBPROCESS_SCRUB_KEYS = (
    "OPENROUTER_API_KEY",
    "ANTHROPIC_API_KEY",
    "OPENAI_API_KEY",
    "GOOGLE_API_KEY",
    "GEMINI_API_KEY",
    "AWS_ACCESS_KEY_ID",
    "AWS_SECRET_ACCESS_KEY",
    "AWS_SESSION_TOKEN",
    "GITHUB_TOKEN",
    "GH_TOKEN",
    "PROMETHEUS_API_KEY",
)


def subprocess_env_scrub_enabled() -> bool:
    """Round 137: when set, subprocess launches strip
    credentials from the inherited env."""
    return _flag("PROMETHEUS_SUBPROCESS_ENV_SCRUB")


def scrub_subprocess_env(env: dict) -> dict:
    """Round 137: return a copy of `env` with credential keys
    removed when scrubbing is active. No-op otherwise."""
    if not subprocess_env_scrub_enabled():
        return env
    return {
        k: v for k, v in env.items()
        if k not in _SUBPROCESS_SCRUB_KEYS
    }


# ---------- PROMETHEUS_SKIP_PROMPT_HISTORY ----------


def skip_prompt_history() -> bool:
    """Round 137: don't persist transcripts/prompt history."""
    return _flag("PROMETHEUS_SKIP_PROMPT_HISTORY")


# ---------- PROMETHEUS_ENABLE_AWAY_SUMMARY ----------


def away_summary_enabled() -> bool:
    """Round 137: override session-recap availability. The
    runtime treats `True` as forcing the recap on; the
    setting otherwise honors the host's policy."""
    return _flag("PROMETHEUS_ENABLE_AWAY_SUMMARY")


# ---------- PROMETHEUS_DISABLE_GIT_INSTRUCTIONS ----------


def git_instructions_disabled() -> bool:
    """Round 137: drop the bundled git-workflow lines from the
    system prompt. Mirrors the `includeGitInstructions=false`
    setting."""
    return _flag("PROMETHEUS_DISABLE_GIT_INSTRUCTIONS")


# ---------- PROMETHEUS_DISABLE_BACKGROUND_TASKS ----------


def background_tasks_disabled() -> bool:
    """Round 137: disable all background-task functionality
    (cohorts, async jobs, monitor, routines)."""
    return _flag("PROMETHEUS_DISABLE_BACKGROUND_TASKS")


# ---------- PROMETHEUS_MCP_ALLOWLIST_ENV ----------


_MCP_ALLOWLISTED_ENV_KEYS = (
    "PATH",
    "HOME",
    "USERPROFILE",
    "TEMP",
    "TMP",
    "LANG",
    "LC_ALL",
    "TZ",
)


def mcp_allowlist_env_enabled() -> bool:
    """Round 137: when set, MCP server subprocess launches
    receive only a safe baseline env."""
    return _flag("PROMETHEUS_MCP_ALLOWLIST_ENV")


def mcp_baseline_env(env: dict) -> dict:
    """Round 137: project the user env down to a safe
    baseline. No-op when the flag is off."""
    if not mcp_allowlist_env_enabled():
        return env
    return {
        k: v for k, v in env.items()
        if k in _MCP_ALLOWLISTED_ENV_KEYS
    }


# ---------- summary helper ----------


def env_flag_summary() -> dict[str, bool]:
    """Round 137: snapshot the round-137 env-flag state. Used
    by `/doctor` and `/config` to surface what's currently
    active."""
    return {
        "PROMETHEUS_SIMPLE": simple_mode_active(),
        "PROMETHEUS_HIDE_CWD": hide_cwd(),
        "PROMETHEUS_DISABLE_1M_CONTEXT": disable_1m_context(),
        "PROMETHEUS_DISABLE_NONESSENTIAL_TRAFFIC":
            nonessential_traffic_disabled(),
        "PROMETHEUS_FORK_SUBAGENT": fork_subagent_enabled(),
        "PROMETHEUS_NEW_INIT": new_init_flow(),
        "PROMETHEUS_SUBPROCESS_ENV_SCRUB":
            subprocess_env_scrub_enabled(),
        "PROMETHEUS_SKIP_PROMPT_HISTORY": skip_prompt_history(),
        "PROMETHEUS_ENABLE_AWAY_SUMMARY": away_summary_enabled(),
        "PROMETHEUS_DISABLE_GIT_INSTRUCTIONS":
            git_instructions_disabled(),
        "PROMETHEUS_DISABLE_BACKGROUND_TASKS":
            background_tasks_disabled(),
        "PROMETHEUS_MCP_ALLOWLIST_ENV":
            mcp_allowlist_env_enabled(),
    }
