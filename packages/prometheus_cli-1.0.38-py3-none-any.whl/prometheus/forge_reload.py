"""Round 136: hot-reload Forge Kits without restarting.

`/reload-forge`:

  1. Re-discover kits in `~/.prometheus/forge` + `<workdir>/.prometheus/forge`.
  2. Re-parse manifests + bodies.
  3. Re-register each kit's components: aptitudes, sentinels,
     cohorts, blades.
  4. Restart any MCP servers the kits register.
  5. Return a `ReloadReport` summarizing additions, updates,
     removals, and any errors.

The reload is best-effort: each step is wrapped so a single
broken manifest doesn't block the rest. Trust gating is
inherited from the round-100 `forge` machinery — project-scoped
kits only load when the workdir is on the trusted list.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


@dataclass
class ReloadReport:
    """Round 136: per-component reload accounting."""
    added: list[str] = field(default_factory=list)
    updated: list[str] = field(default_factory=list)
    removed: list[str] = field(default_factory=list)
    errors: list[tuple[str, str]] = field(default_factory=list)
    duration_ms: int = 0
    components_reloaded: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors

    def summary(self) -> str:
        parts: list[str] = []
        if self.added:
            parts.append(f"+{len(self.added)} added")
        if self.updated:
            parts.append(f"~{len(self.updated)} updated")
        if self.removed:
            parts.append(f"-{len(self.removed)} removed")
        if self.errors:
            parts.append(f"⚠ {len(self.errors)} error(s)")
        if not parts:
            return "no changes"
        return ", ".join(parts) + f"  ({self.duration_ms}ms)"


def reload_kits(
    *,
    workdir: Optional[Path] = None,
    app: Optional[Any] = None,
) -> ReloadReport:
    """Round 136: orchestrate the hot-reload. The host passes
    `app` so we can mutate its kit registry in place. Pure
    when `app=None` (returns a report describing what would
    happen)."""
    started = time.monotonic()
    report = ReloadReport()

    # ---- 1. discover ----
    new_kits: dict[str, Any] = {}
    try:
        from prometheus.cli_subcommands import _import_first
        discover = _import_first(
            "prometheus.forge.registry:discover_kits",
            "prometheus.forge.discovery:discover_kits",
            "prometheus.forge.registry:installed_kits",
        )
        registry_cls = _import_first(
            "prometheus.forge.registry:ForgeRegistry",
        )
        if discover is not None:
            try:
                kits = discover(workdir=workdir)
            except TypeError:
                kits = discover(workdir) if workdir else []
            new_kits = {k.name: k for k in (kits or [])}
        elif registry_cls is not None and workdir is not None:
            reg = registry_cls(workdir)
            kits = (
                reg.installed()
                if hasattr(reg, "installed")
                else getattr(reg, "kits", None) or []
            )
            new_kits = {k.name: k for k in (kits or [])}
    except Exception as e:
        report.errors.append(("discovery", str(e)))

    # ---- 2. diff against current ----
    old_kits: dict[str, Any] = {}
    if app is not None:
        old_kits = {
            k.name: k
            for k in (getattr(app, "forge_kits", []) or [])
        }
    for name in new_kits:
        if name in old_kits:
            report.updated.append(name)
        else:
            report.added.append(name)
    for name in old_kits:
        if name not in new_kits:
            report.removed.append(name)

    # ---- 3. reload components ----
    component_reloaders: list[tuple[str, str]] = [
        ("aptitudes", "prometheus.agent.aptitudes"),
        ("sentinels", "prometheus.safety.sentinels"),
        ("cohorts",   "prometheus.agent.cohorts"),
        ("blades",    "prometheus.agent.blades"),
        ("rules",     "prometheus.rules"),
    ]
    for label, module in component_reloaders:
        try:
            __import__(module)
            report.components_reloaded.append(label)
        except ImportError:
            # Not every install ships every component; quiet skip.
            continue
        except Exception as e:
            report.errors.append((label, str(e)))

    # ---- 4. restart MCP servers ----
    try:
        from prometheus.cli_subcommands import _import_first
        restart_fn = _import_first(
            "prometheus.forge.mcp:restart_mcp_servers",
            "prometheus.mcp.registry:restart_mcp_servers",
        )
        if restart_fn is not None and app is not None:
            try:
                restart_fn(app)
            except Exception as e:
                report.errors.append(("mcp", str(e)))
    except Exception as e:
        report.errors.append(("mcp", str(e)))

    # ---- 5. swap kit registry on the app ----
    if app is not None:
        try:
            app.forge_kits = list(new_kits.values())
        except Exception as e:
            report.errors.append(("apply", str(e)))

    elapsed = (time.monotonic() - started) * 1000.0
    report.duration_ms = int(elapsed)
    return report


def render_report(report: ReloadReport) -> str:
    """Round 136: human summary for the slash command."""
    lines: list[str] = [f"forge reload: {report.summary()}"]
    if report.added:
        lines.append("  added:")
        for name in report.added:
            lines.append(f"    + {name}")
    if report.updated:
        lines.append("  updated:")
        for name in report.updated:
            lines.append(f"    ~ {name}")
    if report.removed:
        lines.append("  removed:")
        for name in report.removed:
            lines.append(f"    - {name}")
    if report.components_reloaded:
        lines.append(
            "  components: " + ", ".join(report.components_reloaded)
        )
    if report.errors:
        lines.append("  errors:")
        for label, msg in report.errors:
            lines.append(f"    ⚠ {label}: {msg}")
    return "\n".join(lines)
