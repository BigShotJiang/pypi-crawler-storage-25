"""Round 150: pipeline health checks for /doctor.

Verifies every load-bearing component the runtime depends on
imports + behaves at its documented contract:

  * 9 pipeline stages — each module imports
  * 5 tool-pool steps — registry + filter accessors present
  * 7 recovery paths — each module + entry point loads
  * 28 sentinel events — full event catalogue is enumerable
  * 5 sentinel types — full type catalogue
  * 3 injection-point separation — system / pre-model / post-tool
  * 6 compaction strategies — modules import
"""
from __future__ import annotations

import importlib
from dataclasses import dataclass


@dataclass
class HealthCheck:
    name: str
    ok: bool
    detail: str = ""


def _import(module: str) -> bool:
    try:
        importlib.import_module(module)
        return True
    except ImportError:
        return False


def check_pipeline_stages() -> list[HealthCheck]:
    from prometheus.pipeline_viz import PIPELINE_STAGES
    rows: list[HealthCheck] = []
    for stage in PIPELINE_STAGES:
        all_ok = all(_import(m) for m in stage.typical_modules)
        rows.append(HealthCheck(
            name=f"pipeline.{stage.name}",
            ok=all_ok,
            detail=(
                "ok" if all_ok else "one or more modules failed to import"
            ),
        ))
    return rows


def check_tool_pool() -> list[HealthCheck]:
    rows: list[HealthCheck] = []
    try:
        from prometheus.tools.registry import build_default_registry
        reg = build_default_registry()
        n = len(list(reg.all()))
        rows.append(HealthCheck(
            name="tool-pool.base",
            ok=n > 0,
            detail=f"{n} tool(s) registered",
        ))
    except Exception as e:
        rows.append(HealthCheck(
            name="tool-pool.base", ok=False, detail=str(e),
        ))
    try:
        from prometheus.cli_flags import filter_registry_to_allowlist
        rows.append(HealthCheck(
            name="tool-pool.allowlist",
            ok=callable(filter_registry_to_allowlist),
            detail="round-133 --tools allowlist filter",
        ))
    except ImportError:
        rows.append(HealthCheck(
            name="tool-pool.allowlist", ok=False,
            detail="missing",
        ))
    try:
        from prometheus.launch_flags import filter_router_to_core
        rows.append(HealthCheck(
            name="tool-pool.disable-slash",
            ok=callable(filter_router_to_core),
            detail="round-136 --disable-slash-commands filter",
        ))
    except ImportError:
        rows.append(HealthCheck(
            name="tool-pool.disable-slash", ok=False,
            detail="missing",
        ))
    return rows


def check_recovery_paths() -> list[HealthCheck]:
    from prometheus.recovery_paths import (
        RECOVERY_PATHS, health_summary,
    )
    summary = health_summary()
    return [
        HealthCheck(
            name=f"recovery.{p.name}",
            ok=summary.get(p.name, False),
            detail=p.module,
        )
        for p in RECOVERY_PATHS
    ]


def check_sentinel_coverage() -> list[HealthCheck]:
    rows: list[HealthCheck] = []
    try:
        from prometheus.safety.sentinels import (
            SentinelEvent, SentinelType, BLOCKING_EVENTS,
        )
        events = list(SentinelEvent)
        types_ = list(SentinelType)
        rows.append(HealthCheck(
            name="sentinels.events",
            ok=len(events) >= 28,
            detail=f"{len(events)} events (need ≥ 28)",
        ))
        rows.append(HealthCheck(
            name="sentinels.types",
            ok=len(types_) >= 5,
            detail=f"{len(types_)} types (need ≥ 5)",
        ))
        rows.append(HealthCheck(
            name="sentinels.blocking",
            ok=len(BLOCKING_EVENTS) > 0,
            detail=f"{len(BLOCKING_EVENTS)} blocking event(s)",
        ))
    except ImportError as e:
        rows.append(HealthCheck(
            name="sentinels", ok=False, detail=str(e),
        ))
    return rows


def check_compaction_strategies() -> list[HealthCheck]:
    from prometheus.compaction_catalogue import COMPACTION_STRATEGIES
    rows: list[HealthCheck] = []
    rows.append(HealthCheck(
        name="compaction.strategies",
        ok=len(COMPACTION_STRATEGIES) >= 6,
        detail=f"{len(COMPACTION_STRATEGIES)} active stage(s)",
    ))
    return rows


def check_injection_points() -> list[HealthCheck]:
    """Round 150: 3 distinct injection points must remain
    isolated — system prompt, pre-model shapers, and
    post-tool result hooks. Each lives in its own module so
    a leak between them is visible at import time."""
    rows: list[HealthCheck] = []
    rows.append(HealthCheck(
        name="injection.system-prompt",
        ok=_import("prometheus.agent.system"),
        detail="prometheus.agent.system",
    ))
    rows.append(HealthCheck(
        name="injection.pre-model-shapers",
        ok=_import("prometheus.prompt_interceptor"),
        detail="prometheus.prompt_interceptor",
    ))
    rows.append(HealthCheck(
        name="injection.post-tool",
        ok=_import("prometheus.agent.leak_sanitizer"),
        detail="prometheus.agent.leak_sanitizer",
    ))
    return rows


# ---------- aggregate ----------


def all_checks() -> list[HealthCheck]:
    return (
        check_pipeline_stages()
        + check_tool_pool()
        + check_recovery_paths()
        + check_sentinel_coverage()
        + check_compaction_strategies()
        + check_injection_points()
    )


def render_health(checks: list[HealthCheck]) -> str:
    by_group: dict[str, list[HealthCheck]] = {}
    for c in checks:
        group = c.name.split(".", 1)[0]
        by_group.setdefault(group, []).append(c)
    total = len(checks)
    passed = sum(1 for c in checks if c.ok)
    lines = [f"pipeline health: {passed}/{total} checks pass"]
    for group, rows in by_group.items():
        lines.append("")
        lines.append(f"  [{group}]")
        for c in rows:
            glyph = "✓" if c.ok else "✗"
            lines.append(
                f"    {glyph} {c.name:36s}  {c.detail}"
            )
    return "\n".join(lines)
