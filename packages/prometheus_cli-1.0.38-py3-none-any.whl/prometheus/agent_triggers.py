"""Round 145-final-v3: agent-trigger gates + remote webhook
support.

  PROMETHEUS_AGENT_TRIGGERS=1 — enable cron-driven triggers
  PROMETHEUS_AGENT_TRIGGERS_REMOTE=1 — accept webhook triggers

Extends the round-111 Routines engine. Pure data-layer.
"""
from __future__ import annotations

import hashlib
import hmac
import os
import time
from dataclasses import dataclass
from typing import Optional


_TRUTHY = ("1", "true", "yes", "on")


def triggers_enabled() -> bool:
    return os.environ.get(
        "PROMETHEUS_AGENT_TRIGGERS", "",
    ).strip().lower() in _TRUTHY


def remote_triggers_enabled() -> bool:
    return os.environ.get(
        "PROMETHEUS_AGENT_TRIGGERS_REMOTE", "",
    ).strip().lower() in _TRUTHY


@dataclass
class WebhookVerification:
    accepted: bool
    reason: str = ""


def verify_webhook(
    *,
    payload: bytes,
    signature: str,
    secret: str,
    max_age_s: int = 300,
    timestamp: Optional[int] = None,
) -> WebhookVerification:
    """Round 145-final-v3: HMAC-SHA256 webhook verification
    matching the GitHub format. The secret comes from
    `~/.prometheus/webhook-secret`. Replay window: 5 minutes
    (configurable)."""
    if not remote_triggers_enabled():
        return WebhookVerification(
            accepted=False,
            reason="remote triggers disabled (set PROMETHEUS_AGENT_TRIGGERS_REMOTE=1)",
        )
    if not signature or not secret:
        return WebhookVerification(
            accepted=False, reason="missing signature or secret",
        )
    expected = "sha256=" + hmac.new(
        secret.encode("utf-8"), payload, hashlib.sha256,
    ).hexdigest()
    if not hmac.compare_digest(expected, signature):
        return WebhookVerification(
            accepted=False, reason="signature mismatch",
        )
    # Optional age check via the request's `t=` parameter.
    if timestamp is not None:
        now = int(time.time())
        if abs(now - int(timestamp)) > max_age_s:
            return WebhookVerification(
                accepted=False, reason="webhook too old",
            )
    return WebhookVerification(accepted=True, reason="ok")
