"""Round 144-final: auto-detect terminal background.

Best-effort detection of light vs dark terminal so the
default theme matches. Three signals, in priority order:

  1. `COLORFGBG` env var (the most portable signal)
  2. `OSC 11` query response (when the terminal supports it
     and a TTY is attached)
  3. fallback: dark (modern terminals default to dark)

A manual `/theme <name>` override always wins.
"""
from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from typing import Optional


@dataclass
class TerminalBackground:
    flavor: str        # `light` / `dark`
    source: str        # how we decided
    rgb: Optional[tuple[int, int, int]] = None


# ---------- COLORFGBG parser ----------


def _from_colorfgbg() -> Optional[TerminalBackground]:
    raw = os.environ.get("COLORFGBG", "").strip()
    if not raw or ";" not in raw:
        return None
    parts = raw.split(";")
    try:
        bg = int(parts[-1])
    except ValueError:
        return None
    # Convention: bg < 8 → dark; bg >= 8 → light. Some
    # terminals emit `15` for white — treat as light.
    flavor = "light" if bg >= 8 else "dark"
    return TerminalBackground(
        flavor=flavor, source="COLORFGBG",
    )


# ---------- OSC 11 query ----------


_OSC_11_QUERY = "\x1b]11;?\x07"


def _parse_osc_11_response(resp: str) -> Optional[tuple[int, int, int]]:
    """Round 144-final: parse `\\e]11;rgb:RRRR/GGGG/BBBB\\a`."""
    if "rgb:" not in resp:
        return None
    body = resp.split("rgb:", 1)[1]
    body = body.split("\x07", 1)[0].split("\x1b\\", 1)[0]
    parts = body.split("/")
    if len(parts) != 3:
        return None
    try:
        # Each component may be 1-4 hex chars; scale to 0..255.
        r, g, b = (int(p[:4] or "0", 16) for p in parts)
        # Normalize to 0..255 from whatever bit-depth.
        max_per = 0xFFFF if max(len(p) for p in parts) >= 4 else 0xFF
        r = int(255 * r / max_per)
        g = int(255 * g / max_per)
        b = int(255 * b / max_per)
        return (r, g, b)
    except ValueError:
        return None


def _luminance(rgb: tuple[int, int, int]) -> float:
    """Round 144-final: rec-601 brightness, 0..1."""
    r, g, b = rgb
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255.0


def _from_osc_11(*, query_fn=None) -> Optional[TerminalBackground]:
    """Round 144-final: query the terminal. The host injects
    `query_fn` so tests can mock the round-trip without a TTY."""
    if query_fn is None:
        # Default: attempt only when stdin is a TTY.
        if not sys.stdin.isatty():
            return None
        # We don't actually do the round-trip in module-import
        # time — that requires raw-mode terminal control. Real
        # query happens inside the host's startup probe.
        return None
    try:
        resp = query_fn(_OSC_11_QUERY)
    except Exception:
        return None
    rgb = _parse_osc_11_response(resp or "")
    if rgb is None:
        return None
    flavor = "light" if _luminance(rgb) >= 0.5 else "dark"
    return TerminalBackground(
        flavor=flavor, source="OSC11", rgb=rgb,
    )


# ---------- public API ----------


def detect_background(
    *, query_fn=None,
) -> TerminalBackground:
    """Round 144-final: best-effort detection. Always returns
    a TerminalBackground; falls back to `dark/fallback`
    when no signal succeeds."""
    osc = _from_osc_11(query_fn=query_fn)
    if osc:
        return osc
    cfg = _from_colorfgbg()
    if cfg:
        return cfg
    return TerminalBackground(flavor="dark", source="fallback")


def recommended_theme(bg: TerminalBackground) -> str:
    """Round 144-final: theme recommendation by flavor."""
    return "paper" if bg.flavor == "light" else "dark"


def auto_theme_setting(setting_value: Optional[str] = None) -> str:
    """Round 144-final: combine settings + detection. A user-
    set `/theme <name>` always wins; otherwise we use the
    auto-detected recommendation."""
    if setting_value and setting_value.strip().lower() != "auto":
        return setting_value.strip()
    return recommended_theme(detect_background())
