"""Round 150: tool concurrency classification.

Used by `/concurrency-model`. Each registered tool falls
into one of three classes:

  * `parallel-safe` — read-only, side-effect-free; many can
    run in the same turn
  * `exclusive`     — mutates state; only one runs at a time
                      with a serialized lock
  * `network`       — outbound HTTP / SSE / API call; may
                      run concurrent but rate-limit-aware

The classifier reads `Tool.side_effect` (round-93 contract)
and groups accordingly.
"""
from __future__ import annotations

from dataclasses import dataclass


# `parallel-safe` matches SideEffect.READ
# `exclusive` matches SideEffect.WRITE / SideEffect.EXEC
# `network` matches SideEffect.NETWORK


@dataclass
class ConcurrencyEntry:
    tool_name: str
    side_effect: str
    klass: str


def classify_registry() -> list[ConcurrencyEntry]:
    """Round 150: walk the default registry, classify each
    tool, return the list."""
    try:
        from prometheus.tools.registry import build_default_registry
        from prometheus.tools.base import SideEffect
    except ImportError:
        return []
    reg = build_default_registry()
    out: list[ConcurrencyEntry] = []
    for t in reg.all():
        side = getattr(t, "side_effect", SideEffect.READ)
        if side == SideEffect.READ:
            klass = "parallel-safe"
        elif side == SideEffect.NETWORK:
            klass = "network"
        else:  # WRITE or EXEC
            klass = "exclusive"
        out.append(ConcurrencyEntry(
            tool_name=t.name,
            side_effect=side.value,
            klass=klass,
        ))
    return out


def render_concurrency() -> str:
    rows = classify_registry()
    if not rows:
        return "concurrency model: registry unavailable"
    by_class: dict[str, list[ConcurrencyEntry]] = {}
    for r in rows:
        by_class.setdefault(r.klass, []).append(r)
    lines = ["tool concurrency classification:"]
    for klass in ("parallel-safe", "exclusive", "network"):
        entries = sorted(
            by_class.get(klass, []), key=lambda e: e.tool_name,
        )
        if not entries:
            continue
        lines.append("")
        lines.append(
            f"  [{klass}] — {len(entries)} tool(s)"
        )
        for e in entries:
            lines.append(
                f"    {e.tool_name:24s}  side_effect={e.side_effect}"
            )
    lines.append("")
    lines.append(
        "  scheduler: parallel-safe runs concurrent inside one "
        "turn; exclusive serializes; network is concurrent "
        "with rate-limit awareness."
    )
    return "\n".join(lines)
