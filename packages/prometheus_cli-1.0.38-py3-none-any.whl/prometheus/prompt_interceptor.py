"""Round 143-v2: prompt-framework keyword interceptor.

Detects uppercase keyword prefixes at the start of user
prompts and injects corresponding system instructions before
the agent loop sees the turn. The keyword is stripped from
the visible prompt before display.

Keywords (case-insensitive, must be the first token):

  L99           — kill hedging, pick a side
  OODA          — observe-orient-decide-act
  ULTRATHINK    — extra reasoning cycles
  SCAFFOLD      — full project structure first
  PERSONA: <r>  — adopt the named persona
  BEASTMODE     — maximum effort, production-quality

Pure data layer. The host's input pipeline calls
`intercept(text)` before dispatching the prompt; the
returned `Interception` carries the cleaned prompt + the
system-instruction fragment to inject.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional


# ---------- framework definitions ----------


_FRAMEWORKS: dict[str, str] = {
    "L99": (
        "You are in L99 mode. Kill the hedging. Pick a side and "
        "defend it. No 'it depends' answers — commit to one path "
        "and explain why. If the user wants tradeoffs they will "
        "ask explicitly."
    ),
    "OODA": (
        "Use the Observe–Orient–Decide–Act loop:\n"
        "  1. Observe — list every constraint the user named.\n"
        "  2. Orient — frame around team, speed, and risk.\n"
        "  3. Decide — pick one approach.\n"
        "  4. Act — give a concrete implementation plan.\n"
        "Show your work in those four labelled sections."
    ),
    "ULTRATHINK": (
        "Spend extra reasoning cycles before answering. Think "
        "deeper. Walk through edge cases exhaustively. State the "
        "assumptions you're making and challenge each one. The "
        "user expects depth, not speed."
    ),
    "SCAFFOLD": (
        "Generate the complete project structure first: every "
        "file path, the directory tree, all config files (package "
        "manifest, lockfile, CI, formatter, linter, README), and "
        "boilerplate. Only after the scaffold is complete should "
        "you touch business logic."
    ),
    "BEASTMODE": (
        "Maximum effort. No shortcuts. No 'this is a stub'. No "
        "'in production you would'. Production-quality output "
        "only — handle errors, write tests, document edge cases, "
        "include the rollback plan."
    ),
}


# ---------- detection ----------


_KEYWORD_RX = re.compile(
    r"^(?P<kw>[A-Za-z][A-Za-z0-9_-]{2,16})(?:\b|:)\s*",
)
_PERSONA_RX = re.compile(
    r"^PERSONA\s*:\s*(?P<role>[^\n]{1,200})",
    re.IGNORECASE,
)


@dataclass
class Interception:
    matched: bool
    keyword: str = ""
    cleaned_prompt: str = ""
    system_fragment: str = ""
    persona: str = ""


def intercept(text: str) -> Interception:
    """Round 143-v2: detect a framework keyword at the start
    of the prompt. Case-insensitive; the keyword and any
    trailing whitespace get stripped from the cleaned prompt.
    """
    raw = (text or "").lstrip()
    if not raw:
        return Interception(matched=False, cleaned_prompt=text or "")
    # PERSONA gets its own pattern because it has an argument.
    persona_m = _PERSONA_RX.match(raw)
    if persona_m:
        role = persona_m.group("role").strip()
        # Strip the matched prefix.
        rest = raw[persona_m.end():].lstrip()
        fragment = (
            f"Adopt this persona: {role}. "
            "Frame all responses through this expertise lens. "
            "Use the vocabulary and priorities a "
            f"{role} would actually use."
        )
        return Interception(
            matched=True,
            keyword="PERSONA",
            cleaned_prompt=rest,
            system_fragment=fragment,
            persona=role,
        )
    # Single-word frameworks. Match the leading keyword token.
    m = _KEYWORD_RX.match(raw)
    if not m:
        return Interception(matched=False, cleaned_prompt=text or "")
    kw = m.group("kw").upper()
    if kw not in _FRAMEWORKS:
        return Interception(matched=False, cleaned_prompt=text or "")
    rest = raw[m.end():].lstrip()
    return Interception(
        matched=True,
        keyword=kw,
        cleaned_prompt=rest,
        system_fragment=_FRAMEWORKS[kw],
    )


def list_frameworks() -> list[tuple[str, str]]:
    """Round 143-v2: catalogue used by `/help frameworks`."""
    rows: list[tuple[str, str]] = []
    for kw, body in _FRAMEWORKS.items():
        # First sentence — short summary.
        first = body.split(".")[0].strip()
        rows.append((kw, first))
    rows.append(("PERSONA: <role>", "Adopt the named persona"))
    return rows


def render_catalogue() -> str:
    lines = ["prompt frameworks:"]
    for kw, summary in list_frameworks():
        lines.append(f"  {kw:18s}  {summary}")
    lines.append("")
    lines.append("Type the keyword as the first token of any prompt.")
    return "\n".join(lines)
