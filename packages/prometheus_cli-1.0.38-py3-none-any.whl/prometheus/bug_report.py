"""Round 136: `/bug` — submit a bug report.

Collects:

  * the current session transcript (last 60 messages, redacted)
  * recent error logs from `~/.prometheus/logs/`
  * system info (OS, Python version, PrometheUS version)

Two output forms:

  1. local file: `~/.prometheus/bug-reports/bug-<unix>.md`
     plus a zip bundle alongside it.
  2. GitHub Issues text: a markdown body the user can paste
     into a new issue on the project repo.

Nothing is uploaded. The user controls the output.
"""
from __future__ import annotations

import os
import platform
import re
import time
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


# ---------- redaction ----------


_SECRET_RXES = (
    re.compile(r"sk-[A-Za-z0-9]{20,}"),
    re.compile(r"sk-ant-[A-Za-z0-9_-]{20,}"),
    re.compile(r"OPENROUTER_API_KEY=\S+"),
    re.compile(r"ANTHROPIC_API_KEY=\S+"),
    re.compile(r"Bearer\s+[A-Za-z0-9_\-\.]+"),
)


def redact(text: str) -> str:
    """Round 136: scrub anything that looks like an API key."""
    out = text
    for rx in _SECRET_RXES:
        out = rx.sub("[REDACTED]", out)
    return out


# ---------- collection ----------


@dataclass
class BugReport:
    timestamp: int
    version: str
    os_name: str
    python_version: str
    note: str
    messages: list[dict[str, Any]] = field(default_factory=list)
    log_excerpts: list[tuple[str, str]] = field(default_factory=list)

    def to_markdown(self) -> str:
        """Round 136: render the bug report as markdown the
        user can paste into GitHub Issues."""
        lines: list[str] = []
        lines.append("# PrometheUS bug report")
        lines.append("")
        lines.append(
            f"- timestamp: {time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime(self.timestamp))}"
        )
        lines.append(f"- version: {self.version}")
        lines.append(f"- os: {self.os_name}")
        lines.append(f"- python: {self.python_version}")
        lines.append("")
        if self.note:
            lines.append("## What happened")
            lines.append("")
            lines.append(redact(self.note))
            lines.append("")
        lines.append("## Recent messages")
        lines.append("")
        for m in self.messages[-30:]:
            role = m.get("role", "?")
            content = m.get("content", "")
            if isinstance(content, list):
                content = " ".join(
                    c.get("text", "") for c in content
                    if isinstance(c, dict)
                )
            text = redact(str(content))
            lines.append(f"### {role}")
            lines.append("")
            lines.append("```")
            lines.append(text[:800])
            lines.append("```")
            lines.append("")
        if self.log_excerpts:
            lines.append("## Log excerpts")
            lines.append("")
            for fname, excerpt in self.log_excerpts:
                lines.append(f"### {fname}")
                lines.append("")
                lines.append("```")
                lines.append(redact(excerpt[:2000]))
                lines.append("```")
                lines.append("")
        return "\n".join(lines)


def collect_log_excerpts(
    logs_dir: Optional[Path] = None,
) -> list[tuple[str, str]]:
    """Round 136: pick up to 3 recent .log files; tail each at
    ~120 lines. Returns [(filename, excerpt)]."""
    if logs_dir is None:
        logs_dir = Path.home() / ".prometheus" / "logs"
    out: list[tuple[str, str]] = []
    if not logs_dir.exists():
        return out
    try:
        files = sorted(
            (p for p in logs_dir.glob("*.log") if p.is_file()),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )[:3]
    except OSError:
        return out
    for p in files:
        try:
            content = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        # Tail ~120 lines.
        lines = content.splitlines()[-120:]
        out.append((p.name, "\n".join(lines)))
    return out


def collect_bug_report(
    *,
    messages: list[dict[str, Any]],
    note: str = "",
    version: str = "",
    logs_dir: Optional[Path] = None,
) -> BugReport:
    """Round 136: gather everything into a BugReport."""
    if not version:
        try:
            from prometheus import __version__ as _v
            version = _v
        except ImportError:
            version = "unknown"
    return BugReport(
        timestamp=int(time.time()),
        version=version,
        os_name=f"{platform.system()} {platform.release()}",
        python_version=platform.python_version(),
        note=note,
        messages=list(messages[-60:]),
        log_excerpts=collect_log_excerpts(logs_dir),
    )


# ---------- write to disk ----------


def write_bug_report(
    report: BugReport, *, target_dir: Optional[Path] = None,
) -> tuple[Path, Path]:
    """Round 136: write the markdown + zip bundle. Returns
    (markdown_path, zip_path)."""
    if target_dir is None:
        target_dir = (
            Path.home() / ".prometheus" / "bug-reports"
        )
    target_dir.mkdir(parents=True, exist_ok=True)
    md_name = f"bug-{report.timestamp}.md"
    zip_name = f"bug-{report.timestamp}.zip"
    md_path = target_dir / md_name
    zip_path = target_dir / zip_name
    body = report.to_markdown()
    md_path.write_text(body, encoding="utf-8")
    with zipfile.ZipFile(
        zip_path, "w", compression=zipfile.ZIP_DEFLATED,
    ) as zf:
        zf.writestr(md_name, body)
        for fname, excerpt in report.log_excerpts:
            zf.writestr(f"logs/{fname}", redact(excerpt))
    return (md_path, zip_path)


def github_issues_url(repo: str = "anthropics/prometheus") -> str:
    """Round 136: link the user can open to file the report."""
    return f"https://github.com/{repo}/issues/new"
