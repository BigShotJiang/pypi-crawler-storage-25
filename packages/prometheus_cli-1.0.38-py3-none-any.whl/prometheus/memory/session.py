"""SQLite-backed session store + JSONL audit trail.

Tables:
  sessions(id, started_at, model, workdir, label)
  messages(session_id, ts, role, content)
  snippets(id, content, tag)  — saved code snippets
  cache(key, value, ts)        — small KV
  audit(session_id, ts, action, data)

Per-session JSONL audit trail also written to USER_DATA_DIR/logs/<sid>.jsonl
"""
from __future__ import annotations

import json
import sqlite3
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

from prometheus.config import LOG_DIR, SESSION_DB

_SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    started_at REAL NOT NULL,
    model TEXT,
    workdir TEXT,
    label TEXT
);
CREATE TABLE IF NOT EXISTS messages (
    session_id TEXT NOT NULL,
    ts REAL NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    FOREIGN KEY(session_id) REFERENCES sessions(id)
);
CREATE INDEX IF NOT EXISTS messages_sid ON messages(session_id, ts);
CREATE TABLE IF NOT EXISTS snippets (
    id TEXT PRIMARY KEY,
    content TEXT NOT NULL,
    tag TEXT,
    ts REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS cache (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    ts REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS audit (
    session_id TEXT NOT NULL,
    ts REAL NOT NULL,
    action TEXT NOT NULL,
    data TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS audit_sid ON audit(session_id, ts);
"""


class SessionStore:
    def __init__(self, db_path: Path | None = None) -> None:
        self.db_path = db_path or SESSION_DB
        # Per-instance hash chain — class-level shared state would
        # corrupt the audit chain if two SessionStore objects audited
        # the same session id (e.g., main app + a /sessions inspector).
        self._last_audit_hash: dict[str, str] = {}
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as c:
            c.executescript(_SCHEMA)
            try:
                # WAL handles two concurrent readers + one writer
                # without "database is locked" errors. Critical for
                # multi-instance use (two PrometheUS terminals open).
                c.execute("PRAGMA journal_mode=WAL")
                c.execute("PRAGMA synchronous=NORMAL")
            except sqlite3.OperationalError:
                pass

    @contextmanager
    def _conn(self) -> Iterator[sqlite3.Connection]:
        # 15s busy timeout — the previous default of 5s would surface
        # `database is locked` errors during concurrent writes from
        # parallel agent turns.
        conn = sqlite3.connect(self.db_path, timeout=15.0)
        try:
            yield conn
            try:
                conn.commit()
            except sqlite3.OperationalError as e:
                # Disk full / DB locked / read-only mount. Best-effort:
                # log and roll back so we leave a coherent in-memory
                # state; never propagate so the agent run isn't killed
                # by a session-store hiccup. Reliability audit P0:
                # the old commit() would propagate ENOSPC and crash
                # the loop on a session message append.
                import logging
                logging.getLogger("memory.session").warning(
                    "session DB commit failed (disk full / locked?): %s", e,
                )
                try:
                    conn.rollback()
                except Exception:
                    pass
        finally:
            conn.close()

    # --- sessions / messages ---

    def start(self, session_id: str, model: str, workdir: str, label: str | None = None) -> None:
        with self._conn() as c:
            c.execute(
                "INSERT OR REPLACE INTO sessions(id, started_at, model, workdir, label) VALUES (?,?,?,?,?)",
                (session_id, time.time(), model, workdir, label),
            )

    def add_message(self, session_id: str, role: str, content: str) -> None:
        with self._conn() as c:
            c.execute(
                "INSERT INTO messages(session_id, ts, role, content) VALUES (?,?,?,?)",
                (session_id, time.time(), role, content),
            )

    def list_sessions(self, limit: int = 50) -> list[dict[str, Any]]:
        with self._conn() as c:
            rows = c.execute(
                "SELECT id, started_at, model, workdir, label FROM sessions ORDER BY started_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [
            {"id": r[0], "started_at": r[1], "model": r[2], "workdir": r[3], "label": r[4]}
            for r in rows
        ]

    def get_messages(self, session_id: str) -> list[dict[str, Any]]:
        with self._conn() as c:
            rows = c.execute(
                "SELECT ts, role, content FROM messages WHERE session_id=? ORDER BY ts ASC",
                (session_id,),
            ).fetchall()
        return [{"ts": r[0], "role": r[1], "content": r[2]} for r in rows]

    def find_session_id(self, prefix: str) -> str | None:
        """Round-95 turn-6: resolve an 8-char (or longer) prefix to a
        full session id.

        The /sessions picker and welcome card both display 8-char
        prefixes, but `get_messages` and `load_state` insist on the
        full UUID. Without this lookup, a user typing /resume with the
        prefix shown on screen got "no session with id starting with
        X" — confusing UX. Returns None if the prefix is empty,
        ambiguous, or unmatched.
        """
        if not prefix:
            return None
        with self._conn() as c:
            rows = c.execute(
                "SELECT id FROM sessions WHERE id LIKE ? "
                "ORDER BY started_at DESC LIMIT 5",
                (prefix + "%",),
            ).fetchall()
        if not rows:
            return None
        if len(rows) == 1:
            return rows[0][0]
        # Ambiguous prefix — caller decides whether to error or pick
        # the most recent. We default to the most-recent (the same
        # ordering /sessions shows) since users almost always mean
        # "the one I just left."
        return rows[0][0]

    def count_messages(self, session_id: str) -> int:
        """Round-43: cheap message count for /sessions picker."""
        with self._conn() as c:
            row = c.execute(
                "SELECT COUNT(*) FROM messages WHERE session_id=?",
                (session_id,),
            ).fetchone()
        return int(row[0] or 0) if row else 0

    def last_user_message(self, session_id: str) -> str:
        """Round-43: most recent user prompt for /sessions preview."""
        with self._conn() as c:
            row = c.execute(
                "SELECT content FROM messages "
                "WHERE session_id=? AND role='user' "
                "ORDER BY ts DESC LIMIT 1",
                (session_id,),
            ).fetchone()
        return (row[0] if row else "") or ""

    def rename(self, session_id: str, label: str) -> None:
        with self._conn() as c:
            c.execute("UPDATE sessions SET label=? WHERE id=?", (label, session_id))

    # --- crash-recovery state snapshot (round-17) ---

    def _state_path(self, session_id: str) -> "Path":
        from pathlib import Path
        from prometheus.config import USER_DATA_DIR
        return Path(USER_DATA_DIR) / "sessions" / session_id / "state.json"

    def save_state(self, session_id: str, state: dict[str, Any]) -> None:
        """Persist the agent's in-memory message buffer + todos + snapshots.

        Round-17 P0: --resume previously rebuilt the chat log from the
        DB but not the in-flight agent message buffer (architectural
        review #49). A crash mid-edit therefore lost the working state
        entirely. Now we snapshot after every turn so re-launch with
        --resume <sid> can rebuild `agent.messages` exactly as it was.
        """
        try:
            from prometheus.tools.files import _atomic_write_text
            import json
            p = self._state_path(session_id)
            p.parent.mkdir(parents=True, exist_ok=True)
            _atomic_write_text(p, json.dumps(state, default=str))
        except Exception:
            pass  # snapshot is best-effort; never fail a turn over it

    def load_state(self, session_id: str) -> dict[str, Any] | None:
        try:
            import json
            p = self._state_path(session_id)
            if not p.exists():
                return None
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return None

    # --- snippets ---

    def save_snippet(self, content: str, tag: str | None = None) -> str:
        sid = str(uuid.uuid4())
        with self._conn() as c:
            c.execute(
                "INSERT INTO snippets(id, content, tag, ts) VALUES (?,?,?,?)",
                (sid, content, tag, time.time()),
            )
        return sid

    def list_snippets(self, limit: int = 50) -> list[dict[str, Any]]:
        with self._conn() as c:
            rows = c.execute(
                "SELECT id, tag, ts, substr(content, 1, 80) FROM snippets ORDER BY ts DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [{"id": r[0], "tag": r[1], "ts": r[2], "preview": r[3]} for r in rows]

    # --- audit (DB + JSONL with hash-chain) ---

    def audit(self, session_id: str, action: str, data: dict[str, Any]) -> None:
        """Append a tamper-evident audit record.

        Each line is a single JSON object containing the event AND a SHA-256
        hash of (previous_hash + canonical_json_of_event). An auditor can
        re-hash the chain to confirm no entry has been silently altered or
        removed. This closes Claude Code's documented SOC2 audit-log gap.
        """
        import hashlib
        ts = time.time()
        prev_hash = self._last_audit_hash.get(session_id, "0" * 64)
        record = {"ts": ts, "action": action, "data": data, "prev": prev_hash}
        canonical = json.dumps(record, default=str, sort_keys=True)
        cur_hash = hashlib.sha256(canonical.encode()).hexdigest()
        record["hash"] = cur_hash
        # Advance the in-memory chain ONLY after at least one persistent
        # write succeeds (audit P1: previously the hash advanced before
        # writes, so a JSONL-append failure left the next record's
        # `prev` pointing at a hash whose row never existed).
        payload = json.dumps(data, default=str)
        line = json.dumps(record, default=str) + "\n"
        path = LOG_DIR / f"{session_id}.jsonl"
        wrote_anywhere = False
        # DB row.
        try:
            with self._conn() as c:
                c.execute(
                    "INSERT INTO audit(session_id, ts, action, data) VALUES (?,?,?,?)",
                    (session_id, ts, action, payload),
                )
            wrote_anywhere = True
        except Exception:
            pass
        # JSONL append (with rotation at 10 MB).
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            if path.exists() and path.stat().st_size > 10 * 1024 * 1024:
                idx = 1
                while (LOG_DIR / f"{session_id}.jsonl.{idx}").exists():
                    idx += 1
                path.rename(LOG_DIR / f"{session_id}.jsonl.{idx}")
            with path.open("a", encoding="utf-8") as f:
                f.write(line)
                f.flush()
                try:
                    import os as _os
                    _os.fsync(f.fileno())
                except (OSError, AttributeError):
                    pass
            wrote_anywhere = True
        except OSError:
            pass
        if wrote_anywhere:
            self._last_audit_hash[session_id] = cur_hash

    # --- cache ---

    def cache_get(self, key: str) -> Any:
        with self._conn() as c:
            r = c.execute("SELECT value FROM cache WHERE key=?", (key,)).fetchone()
        return json.loads(r[0]) if r else None

    def cache_set(self, key: str, value: Any) -> None:
        with self._conn() as c:
            c.execute(
                "INSERT OR REPLACE INTO cache(key, value, ts) VALUES (?,?,?)",
                (key, json.dumps(value, default=str), time.time()),
            )


# Round-95 turn-6 (corrected): module-level convenience wrapper around
# SessionStore.find_session_id. The /resume slash command and the
# verification harness both want to import this as a top-level symbol
# without having to instantiate a SessionStore first. Defaults to the
# standard SessionStore (the one the live app uses).
def find_session_id(
    prefix: str, store: "SessionStore | None" = None,
) -> str | None:
    """Resolve a session-id prefix (e.g. the 8-char form shown by
    /sessions and the welcome card) to the full UUID.

    Returns None for empty/unmatched prefixes. On an ambiguous prefix,
    returns the most-recently-started match — the same ordering that
    /sessions displays, which matches what users almost always mean
    by `/resume <prefix>`.

    Importable as `from prometheus.memory.session import find_session_id`
    so the verification harness and external scripts don't need to
    construct a SessionStore manually.
    """
    s = store if store is not None else SessionStore()
    return s.find_session_id(prefix)
