"""Round 134: Terminal UX polish helpers.

Six surfaces:

  * `/terminal-setup` — emit the right tput/escape sequences to
    arm the user's terminal for our reporting + status bar
  * `/color`          — apply one of several built-in palettes
  * Vim visual modes  — `v` / `V` / `Ctrl+V` selection state +
    `d`/`y`/`>`/`<` operators
  * `/heapdump`       — write a one-shot heap snapshot to disk
  * `/fewer-permission-prompts` — bundled skill body
  * `/claude-api`     — bundled API reference body

Pure data layer. Slash commands consume these helpers.
"""
from __future__ import annotations

import gc
import os
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


# ---------- /terminal-setup ----------


@dataclass
class TerminalProfile:
    name: str
    enable_truecolor: bool
    enable_mouse: bool
    enable_alt_screen: bool
    notes: str = ""


_TERMINAL_PROFILES: dict[str, TerminalProfile] = {
    "wezterm": TerminalProfile(
        "wezterm", True, True, True,
        "tested + recommended; full truecolor + Kitty graphics",
    ),
    "iterm2": TerminalProfile(
        "iterm2", True, True, True,
        "macOS only; ⌥+arrow word jump works; ITM mode supported",
    ),
    "windows-terminal": TerminalProfile(
        "windows-terminal", True, True, True,
        "Windows 11 default; arm with profile JSON",
    ),
    "alacritty": TerminalProfile(
        "alacritty", True, True, True,
        "GPU rendered; uses live-config so changes pick up fast",
    ),
    "kitty": TerminalProfile(
        "kitty", True, True, True,
        "kitty graphics protocol available",
    ),
    "vscode": TerminalProfile(
        "vscode", True, True, True,
        "set 'terminal.integrated.shellIntegration.enabled' = true",
    ),
    "tmux": TerminalProfile(
        "tmux", True, True, False,
        "alt-screen disabled because tmux owns it",
    ),
    "screen": TerminalProfile(
        "screen", False, False, False,
        "minimal mode; many features unavailable",
    ),
}


def detect_terminal() -> str:
    """Round 134: best-effort terminal detection. Reads the
    standard env hints. Fallback `unknown` keeps the rest of
    the system safe."""
    if os.environ.get("TMUX"):
        return "tmux"
    if os.environ.get("WT_SESSION"):
        return "windows-terminal"
    term_program = os.environ.get("TERM_PROGRAM", "").lower()
    if "wezterm" in term_program:
        return "wezterm"
    if "iterm" in term_program:
        return "iterm2"
    if "vscode" in term_program:
        return "vscode"
    if os.environ.get("ALACRITTY_LOG"):
        return "alacritty"
    if os.environ.get("KITTY_PID"):
        return "kitty"
    if os.environ.get("STY"):
        return "screen"
    return "unknown"


def setup_recommendations() -> tuple[str, list[str]]:
    """Round 134: detect-then-advise. Returns (profile_name,
    recommendation_lines)."""
    name = detect_terminal()
    prof = _TERMINAL_PROFILES.get(name)
    if prof is None:
        return (name, [
            "unknown terminal — try one of the supported ones:",
            "  wezterm, iTerm2, Windows Terminal, Alacritty, Kitty",
            "PrometheUS will work but some features may be reduced.",
        ])
    out: list[str] = []
    out.append(f"detected terminal: {prof.name}")
    if prof.enable_truecolor:
        out.append("  ✓ truecolor available")
    else:
        out.append("  ⚠ truecolor unavailable; colors may be coarse")
    if prof.enable_mouse:
        out.append("  ✓ mouse capture supported")
    else:
        out.append("  ⚠ mouse capture limited")
    if prof.enable_alt_screen:
        out.append("  ✓ alternate screen supported")
    else:
        out.append("  ⚠ alternate screen owned by host")
    if prof.notes:
        out.append(f"  note: {prof.notes}")
    out.append("")
    out.append("To enable shift-enter for newlines:")
    out.append(
        "  • iTerm2: Preferences → Keys → Key Bindings: bind "
        "Shift-Enter → 'Send Escape Sequence' → '[27;2;13~'"
    )
    out.append(
        "  • Windows Terminal: profile.json → keybindings → bind "
        "shift+enter → sendInput \"\\u001b[27;2;13~\""
    )
    out.append(
        "  • VS Code: settings.json → "
        "'terminal.integrated.sendKeybindingsToShell': true"
    )
    return (name, out)


# ---------- /color (palettes) ----------


@dataclass
class Palette:
    name: str
    primary: str
    accent: str
    success: str
    warning: str
    danger: str
    dim: str


_PALETTES: dict[str, Palette] = {
    "default": Palette(
        "default",
        primary="#cba6f7",
        accent="#f9e2af",
        success="#a6e3a1",
        warning="#f9e2af",
        danger="#f38ba8",
        dim="#7f849c",
    ),
    "monochrome": Palette(
        "monochrome",
        primary="#e0e0e0",
        accent="#c8c8c8",
        success="#b0b0b0",
        warning="#a0a0a0",
        danger="#909090",
        dim="#606060",
    ),
    "ocean": Palette(
        "ocean",
        primary="#89b4fa",
        accent="#74c7ec",
        success="#94e2d5",
        warning="#f9e2af",
        danger="#f38ba8",
        dim="#6c7086",
    ),
    "amber": Palette(
        "amber",
        primary="#fab387",
        accent="#f9e2af",
        success="#a6e3a1",
        warning="#fab387",
        danger="#f38ba8",
        dim="#7f849c",
    ),
    "matrix": Palette(
        "matrix",
        primary="#00ff5f",
        accent="#00d75f",
        success="#5fff5f",
        warning="#ffaf00",
        danger="#ff5f5f",
        dim="#005f5f",
    ),
    "dracula": Palette(
        "dracula",
        primary="#bd93f9",
        accent="#ff79c6",
        success="#50fa7b",
        warning="#f1fa8c",
        danger="#ff5555",
        dim="#6272a4",
    ),
    "solarized-light": Palette(
        "solarized-light",
        primary="#268bd2",
        accent="#b58900",
        success="#859900",
        warning="#cb4b16",
        danger="#dc322f",
        dim="#93a1a1",
    ),
    "solarized-dark": Palette(
        "solarized-dark",
        primary="#268bd2",
        accent="#b58900",
        success="#859900",
        warning="#cb4b16",
        danger="#dc322f",
        dim="#586e75",
    ),
    "high-contrast": Palette(
        "high-contrast",
        primary="#ffffff",
        accent="#ffff00",
        success="#00ff00",
        warning="#ffaa00",
        danger="#ff0000",
        dim="#888888",
    ),
}


def list_palettes() -> list[str]:
    return list(_PALETTES.keys())


def get_palette(name: str) -> Optional[Palette]:
    return _PALETTES.get(name.strip().lower())


def render_palette_swatch(p: Palette) -> str:
    """Round 134: short swatch line — palette name + each role."""
    return (
        f"{p.name:18s}  "
        f"primary={p.primary}  accent={p.accent}  "
        f"success={p.success}  danger={p.danger}"
    )


# ---------- Vim visual modes ----------


VISUAL_CHAR = "v"
VISUAL_LINE = "V"
VISUAL_BLOCK = "ctrl+v"


@dataclass
class VisualSelection:
    """Round 134: selection state used by the round-106 vim
    state machine. The Input widget consults this when
    rendering the cursor and applying operators."""
    mode: str = ""      # "" (no selection) / "char" / "line" / "block"
    anchor: int = 0     # selection origin column
    head: int = 0       # current cursor column
    line_anchor: int = 0
    line_head: int = 0

    @property
    def active(self) -> bool:
        return self.mode != ""

    def normalized(self) -> tuple[int, int]:
        a, h = self.anchor, self.head
        return (a, h) if a <= h else (h, a)


def begin_visual(
    sel: VisualSelection, mode: str, *, col: int, line: int = 0,
) -> None:
    """Start a visual selection at the cursor position."""
    sel.mode = mode
    sel.anchor = col
    sel.head = col
    sel.line_anchor = line
    sel.line_head = line


def update_visual_head(
    sel: VisualSelection, *, col: int, line: int = 0,
) -> None:
    if not sel.active:
        return
    sel.head = col
    sel.line_head = line


def end_visual(sel: VisualSelection) -> None:
    sel.mode = ""
    sel.anchor = 0
    sel.head = 0
    sel.line_anchor = 0
    sel.line_head = 0


def apply_visual_operator(
    text: str, sel: VisualSelection, op: str,
) -> str:
    """Round 134: apply `d` (delete), `y` (yank — no-op return),
    `>` (indent), `<` (unindent) to the current selection.
    Returns the new buffer."""
    if not sel.active:
        return text
    a, b = sel.normalized()
    if a < 0:
        a = 0
    if b > len(text):
        b = len(text)
    if op == "d":
        return text[:a] + text[b:]
    if op == "y":
        # Yank doesn't mutate the buffer; the caller stores the
        # selection elsewhere if it wants a clipboard analogue.
        return text
    if op == ">":
        # Indent every line in selection by 2 spaces.
        chunk = text[a:b]
        indented = "\n".join("  " + l for l in chunk.split("\n"))
        return text[:a] + indented + text[b:]
    if op == "<":
        chunk = text[a:b]
        out_lines = []
        for line in chunk.split("\n"):
            if line.startswith("  "):
                out_lines.append(line[2:])
            elif line.startswith(" "):
                out_lines.append(line[1:])
            elif line.startswith("\t"):
                out_lines.append(line[1:])
            else:
                out_lines.append(line)
        return text[:a] + "\n".join(out_lines) + text[b:]
    return text


# ---------- /heapdump ----------


@dataclass
class HeapdumpResult:
    path: Path
    object_count: int
    timestamp: int


def write_heapdump(out_dir: Optional[Path] = None) -> HeapdumpResult:
    """Round 134: write a one-shot heap snapshot.

    What we capture (cheap, doesn't pull in optional deps):

      * Total live-object count from gc.get_objects()
      * Top-20 types by instance count
      * Top-10 largest individual objects via sys.getsizeof
      * Reference counts for the top-10 types

    The output is a markdown file under `~/.prometheus/heapdumps/`
    or the supplied directory. Use this when triaging a memory
    leak — diff two snapshots to see what grew."""
    base = out_dir or (
        Path.home() / ".prometheus" / "heapdumps"
    )
    base.mkdir(parents=True, exist_ok=True)
    ts = int(time.time())
    target = base / f"heap-{ts}.md"
    objs = gc.get_objects()
    type_counts: dict[str, int] = {}
    for o in objs:
        try:
            n = type(o).__name__
        except Exception:
            n = "?"
        type_counts[n] = type_counts.get(n, 0) + 1
    top_types = sorted(
        type_counts.items(), key=lambda kv: kv[1], reverse=True,
    )[:20]
    sized: list[tuple[str, int]] = []
    for o in objs:
        try:
            sz = sys.getsizeof(o)
            sized.append((type(o).__name__, sz))
        except Exception:
            continue
    top_sized = sorted(sized, key=lambda kv: kv[1], reverse=True)[:10]
    lines: list[str] = []
    lines.append(f"# PrometheUS heap snapshot {ts}")
    lines.append("")
    lines.append(f"- live objects: {len(objs)}")
    lines.append("")
    lines.append("## top types by count")
    lines.append("")
    for name, count in top_types:
        lines.append(f"- {name:40s}  {count}")
    lines.append("")
    lines.append("## top objects by size")
    lines.append("")
    for name, sz in top_sized:
        lines.append(f"- {name:40s}  {sz} bytes")
    target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return HeapdumpResult(
        path=target, object_count=len(objs), timestamp=ts,
    )


# ---------- bundled body: /fewer-permission-prompts ----------


FEWER_PERMISSION_PROMPTS_BODY = (
    "You're configuring PrometheUS to ask for fewer approvals "
    "without sacrificing safety.\n\n"
    "## Recommended setup\n\n"
    "1. Switch the default permission mode to `acceptEdits` for "
    "this session: `/permissions acceptEdits`. File edits no "
    "longer prompt; tool calls that escape the workdir still do.\n"
    "2. Add a project-scoped allowlist in `.prometheus/settings."
    "local.json`:\n\n"
    "    {\n"
    "      \"allow\": [\n"
    "        \"run_bash:pytest *\",\n"
    "        \"run_bash:python -m pytest *\",\n"
    "        \"run_bash:git status\",\n"
    "        \"run_bash:git diff *\",\n"
    "        \"web_fetch:https://docs.python.org/*\"\n"
    "      ]\n"
    "    }\n\n"
    "3. For high-trust day-to-day work, switch the toggle cycle "
    "to include `auto`: pressing Shift+Tab cycles default → "
    "acceptEdits → auto. The `auto` mode auto-approves repeated "
    "patterns from the same session.\n"
    "4. **Don't enable `--dangerously-skip-permissions` unless "
    "you've reviewed the workspace** — it disables every prompt "
    "including writes to system paths.\n\n"
    "## Rules of thumb\n\n"
    "* Allow patterns are anchored to the tool name + first "
    "argument shape. Globs (`*`) are supported in the pattern.\n"
    "* Project allow-lists are trust-gated: PrometheUS only "
    "loads them after the workdir is on the trusted list.\n"
    "* Sentinels still fire even when an action is auto-approved "
    "— so dangerous patterns are still blocked.\n\n"
    "Done. Your prompts should drop noticeably while keeping "
    "the safety nets in place."
)


# ---------- bundled body: /claude-api ----------


CLAUDE_API_BODY = (
    "Quick reference for the Anthropic Messages API + the "
    "OpenRouter compatible surface PrometheUS uses.\n\n"
    "## Endpoint\n\n"
    "```\n"
    "POST https://api.anthropic.com/v1/messages\n"
    "POST https://openrouter.ai/api/v1/chat/completions\n"
    "```\n\n"
    "## Auth headers\n\n"
    "* `x-api-key: <key>` — Anthropic\n"
    "* `Authorization: Bearer <key>` — OpenRouter\n"
    "* `anthropic-version: 2023-06-01` — Anthropic only\n\n"
    "## Request shape (Anthropic)\n\n"
    "```json\n"
    "{\n"
    "  \"model\": \"claude-opus-4-7\",\n"
    "  \"max_tokens\": 4096,\n"
    "  \"system\": \"You are an autonomous coding assistant.\",\n"
    "  \"messages\": [\n"
    "    {\"role\": \"user\", \"content\": \"...\"}\n"
    "  ],\n"
    "  \"tools\": [...],\n"
    "  \"stream\": true\n"
    "}\n"
    "```\n\n"
    "## Tool use\n\n"
    "Tools are declared on the request and invoked via "
    "`tool_use` content blocks in assistant messages. Reply "
    "with `tool_result` blocks referencing the same `tool_use_id`.\n\n"
    "## Streaming events\n\n"
    "* `message_start` — opening envelope\n"
    "* `content_block_start` — new content block (text or tool_use)\n"
    "* `content_block_delta` — partial content\n"
    "* `content_block_stop` — block terminated\n"
    "* `message_delta` — final usage + stop_reason\n"
    "* `message_stop` — message complete\n\n"
    "## Latest model ids (claude 4.x)\n\n"
    "* `claude-opus-4-7`     — most capable\n"
    "* `claude-sonnet-4-6`   — strong default\n"
    "* `claude-haiku-4-5`    — fast/cheap\n\n"
    "## Errors to handle\n\n"
    "* 429 rate-limited — back off + retry with jitter\n"
    "* 529 overloaded   — fall back to `--fallback-model`\n"
    "* 400 invalid_request — surface raw error to caller\n"
    "* 401 unauthorized  — re-prompt for API key\n\n"
    "PrometheUS uses round-130 fallback resolution to swap to "
    "the configured fallback model on 429/529."
)


# ---------- bundled aptitude additions ----------


def bundled_round134() -> list[dict[str, Any]]:
    """Round 134: two new bundled aptitudes."""
    return [
        {
            "name": "fewer-permission-prompts",
            "purpose": (
                "Configure PrometheUS to ask for fewer approval "
                "prompts while keeping safety nets in place."
            ),
            "triggers": (
                "fewer-permission-prompts", "fewer prompts",
                "less approval", "auto-approve",
            ),
            "body": FEWER_PERMISSION_PROMPTS_BODY,
        },
        {
            "name": "claude-api",
            "purpose": (
                "Quick reference for the Anthropic Messages API "
                "+ OpenRouter compatible surface."
            ),
            "triggers": (
                "claude-api", "anthropic api", "messages api",
                "tool-use api",
            ),
            "body": CLAUDE_API_BODY,
        },
    ]
