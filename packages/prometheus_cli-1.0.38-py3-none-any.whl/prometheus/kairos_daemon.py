"""Round 144-final-v3: KAIROS persistent background daemon.

Daemon survives terminal closure. PID file at
`~/.prometheus/daemon.pid`. Daily append-only logs at
`~/.prometheus/logs/YYYY/MM/YYYY-MM-DD.md`.

Sub-flags:
  PROMETHEUS_KAIROS=1                 — enable
  PROMETHEUS_KAIROS_DREAM=1           — nightly distillation
  PROMETHEUS_KAIROS_BRIEF=1           — on-demand brief
  PROMETHEUS_KAIROS_CHANNELS=1        — MCP channel ingest
  PROMETHEUS_KAIROS_PUSH_NOTIFICATION=1
  PROMETHEUS_KAIROS_GITHUB_WEBHOOKS=1

CLI subcommands (wired into `cli_subcommands.py`):
  prometheus daemon start
  prometheus daemon status
  prometheus daemon stop
"""
from __future__ import annotations

import json
import os
import signal
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Optional


_TRUTHY = ("1", "true", "yes", "on")


def _flag(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in _TRUTHY


# ---------- env gates ----------


def kairos_enabled() -> bool:
    return _flag("PROMETHEUS_KAIROS")


def kairos_dream_enabled() -> bool:
    return _flag("PROMETHEUS_KAIROS_DREAM")


def kairos_brief_enabled() -> bool:
    return _flag("PROMETHEUS_KAIROS_BRIEF")


def kairos_channels_enabled() -> bool:
    return _flag("PROMETHEUS_KAIROS_CHANNELS")


def kairos_push_enabled() -> bool:
    return _flag("PROMETHEUS_KAIROS_PUSH_NOTIFICATION")


def kairos_github_webhooks_enabled() -> bool:
    return _flag("PROMETHEUS_KAIROS_GITHUB_WEBHOOKS")


# ---------- paths ----------


def daemon_dir() -> Path:
    return Path.home() / ".prometheus"


def pid_file() -> Path:
    return daemon_dir() / "daemon.pid"


def log_path_for(date: Optional[datetime] = None) -> Path:
    """Round 144-final-v3: daily append-only log path.

    `~/.prometheus/logs/YYYY/MM/YYYY-MM-DD.md`."""
    d = date or datetime.utcnow()
    return (
        daemon_dir() / "logs"
        / f"{d.year:04d}" / f"{d.month:02d}"
        / f"{d.year:04d}-{d.month:02d}-{d.day:02d}.md"
    )


# ---------- daemon record ----------


@dataclass
class DaemonRecord:
    pid: int
    started_at: int
    log_path: str
    sub_flags: dict[str, bool] = field(default_factory=dict)


def write_pid(record: DaemonRecord) -> Path:
    """Round 144-final-v3: persist the PID + metadata."""
    p = pid_file()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({
        "pid": record.pid,
        "started_at": record.started_at,
        "log_path": record.log_path,
        "sub_flags": record.sub_flags,
    }, indent=2), encoding="utf-8")
    return p


def read_pid() -> Optional[DaemonRecord]:
    p = pid_file()
    if not p.exists():
        return None
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        return DaemonRecord(
            pid=int(d.get("pid", 0)),
            started_at=int(d.get("started_at", 0)),
            log_path=str(d.get("log_path", "")),
            sub_flags={
                str(k): bool(v)
                for k, v in (d.get("sub_flags") or {}).items()
            },
        )
    except (OSError, json.JSONDecodeError, TypeError, ValueError):
        return None


def remove_pid() -> bool:
    p = pid_file()
    if not p.exists():
        return False
    try:
        p.unlink()
        return True
    except OSError:
        return False


# ---------- liveness ----------


def is_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        if os.name == "nt":
            import ctypes
            kernel32 = ctypes.windll.kernel32
            SYNCHRONIZE = 0x00100000
            handle = kernel32.OpenProcess(SYNCHRONIZE, False, int(pid))
            if not handle:
                return False
            kernel32.CloseHandle(handle)
            return True
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError, PermissionError):
        return False


# ---------- log append ----------


def append_log(line: str, *, date: Optional[datetime] = None) -> Path:
    """Round 144-final-v3: append a markdown line to today's
    log. The file is opened append-only so multiple processes
    can write without losing entries."""
    target = log_path_for(date)
    target.parent.mkdir(parents=True, exist_ok=True)
    timestamp = (date or datetime.utcnow()).strftime("%H:%M:%S")
    with target.open("a", encoding="utf-8") as f:
        f.write(f"- [{timestamp}] {line}\n")
    return target


def read_log(*, date: Optional[datetime] = None) -> str:
    target = log_path_for(date)
    if not target.exists():
        return ""
    try:
        return target.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


# ---------- start / status / stop ----------


@dataclass
class StartResult:
    ok: bool
    record: Optional[DaemonRecord] = None
    output: str = ""


def start(*, force: bool = False) -> StartResult:
    """Round 144-final-v3: register the calling process as
    the active daemon. The host calls this *after* it has
    forked / detached its main process — this module owns the
    PID file, not the daemonization itself.

    `force=True` overwrites a stale PID file."""
    if not kairos_enabled():
        return StartResult(
            ok=False,
            output="kairos daemon disabled (set PROMETHEUS_KAIROS=1)",
        )
    existing = read_pid()
    if existing is not None and is_alive(existing.pid):
        if not force:
            return StartResult(
                ok=False, record=existing,
                output=(
                    f"daemon already running with pid "
                    f"{existing.pid}; pass --force to replace."
                ),
            )
    record = DaemonRecord(
        pid=os.getpid(),
        started_at=int(time.time()),
        log_path=str(log_path_for()),
        sub_flags={
            "dream": kairos_dream_enabled(),
            "brief": kairos_brief_enabled(),
            "channels": kairos_channels_enabled(),
            "push_notification": kairos_push_enabled(),
            "github_webhooks": kairos_github_webhooks_enabled(),
        },
    )
    write_pid(record)
    return StartResult(
        ok=True, record=record,
        output=(
            f"daemon started (pid {record.pid})\n"
            f"  log:  {record.log_path}\n"
            f"  flags: {', '.join(k for k, v in record.sub_flags.items() if v) or '(none)'}"
        ),
    )


@dataclass
class StatusResult:
    running: bool
    record: Optional[DaemonRecord]
    output: str


def status() -> StatusResult:
    rec = read_pid()
    if rec is None:
        return StatusResult(
            running=False, record=None,
            output="daemon: not running (no PID file)",
        )
    if not is_alive(rec.pid):
        return StatusResult(
            running=False, record=rec,
            output=f"daemon: stale PID {rec.pid} (process gone)",
        )
    elapsed = int(time.time()) - rec.started_at
    flags_on = ", ".join(k for k, v in rec.sub_flags.items() if v) or "(none)"
    return StatusResult(
        running=True, record=rec,
        output=(
            f"daemon: running\n"
            f"  pid:       {rec.pid}\n"
            f"  uptime:    {_format_duration(elapsed)}\n"
            f"  log:       {rec.log_path}\n"
            f"  sub-flags: {flags_on}"
        ),
    )


def stop() -> StatusResult:
    rec = read_pid()
    if rec is None:
        return StatusResult(
            running=False, record=None,
            output="daemon: nothing to stop (no PID file)",
        )
    if is_alive(rec.pid):
        try:
            if os.name == "nt":
                import ctypes
                kernel32 = ctypes.windll.kernel32
                handle = kernel32.OpenProcess(0x0001, False, rec.pid)
                if handle:
                    kernel32.TerminateProcess(handle, 0)
                    kernel32.CloseHandle(handle)
            else:
                os.kill(rec.pid, signal.SIGTERM)
                # Give it a moment.
                for _ in range(20):
                    if not is_alive(rec.pid):
                        break
                    time.sleep(0.05)
        except OSError:
            pass
    remove_pid()
    return StatusResult(
        running=False, record=rec,
        output=f"daemon: stopped (pid {rec.pid})",
    )


def _format_duration(seconds: int) -> str:
    if seconds < 60:
        return f"{seconds}s"
    m, s = divmod(seconds, 60)
    if m < 60:
        return f"{m}m {s}s"
    h, m = divmod(m, 60)
    if h < 24:
        return f"{h}h {m}m"
    d, h = divmod(h, 24)
    return f"{d}d {h}h"


# ---------- subcommand dispatcher ----------


@dataclass
class DaemonCmdResult:
    exit_code: int
    output: str = ""


def dispatch_daemon_subcommand(argv: list[str]) -> DaemonCmdResult:
    """Round 144-final-v3: route `prometheus daemon <action>`."""
    sub = ""
    for tok in argv:
        if tok.startswith("-"):
            continue
        if tok == "daemon":
            continue
        sub = tok
        break
    if sub == "" or sub == "status":
        s = status()
        return DaemonCmdResult(
            exit_code=0 if s.running else 1, output=s.output,
        )
    if sub == "start":
        force = "--force" in argv
        r = start(force=force)
        return DaemonCmdResult(
            exit_code=0 if r.ok else 1, output=r.output,
        )
    if sub == "stop":
        s = stop()
        return DaemonCmdResult(exit_code=0, output=s.output)
    return DaemonCmdResult(
        exit_code=2,
        output=(
            "usage: prometheus daemon "
            "[start [--force] | status | stop]"
        ),
    )
