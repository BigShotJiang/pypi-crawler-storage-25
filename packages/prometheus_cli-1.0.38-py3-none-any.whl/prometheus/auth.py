"""Round 138: `prometheus auth` — credential management.

Stores per-provider API keys in `~/.prometheus/auth.json` with
file-mode 0600. Two surfaces:

  * `prometheus auth login [provider]`   — prompt + store
  * `prometheus auth status`              — show what's set
  * `prometheus auth logout [provider]`  — clear

Plus a `/login` and `/logout` slash command equivalent for
mid-session use.

We do not call provider validation endpoints — `--doctor`
already does that. `auth login` is purely a credential
capture surface.
"""
from __future__ import annotations

import json
import os
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


VALID_PROVIDERS = (
    "openrouter", "anthropic", "openai", "groq",
    "google", "fireworks", "together", "deepinfra",
)


_PROVIDER_ENV = {
    "openrouter": "OPENROUTER_API_KEY",
    "anthropic":  "ANTHROPIC_API_KEY",
    "openai":     "OPENAI_API_KEY",
    "groq":       "GROQ_API_KEY",
    "google":     "GOOGLE_API_KEY",
    "fireworks":  "FIREWORKS_API_KEY",
    "together":   "TOGETHER_API_KEY",
    "deepinfra":  "DEEPINFRA_API_KEY",
}


def _store_path() -> Path:
    return Path.home() / ".prometheus" / "auth.json"


def _ensure_secure_perms(p: Path) -> None:
    """Round 138: best-effort 0600 on POSIX. Windows users
    rely on their user profile's NTFS ACL."""
    try:
        os.chmod(p, stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass


def _load_store() -> dict:
    path = _store_path()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _save_store(store: dict) -> None:
    path = _store_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(store, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    _ensure_secure_perms(path)


# ---------- public API ----------


@dataclass
class AuthResult:
    ok: bool
    output: str = ""


def normalize_provider(name: str) -> Optional[str]:
    n = (name or "").strip().lower()
    if n in VALID_PROVIDERS:
        return n
    return None


def store_credential(
    provider: str, api_key: str,
) -> AuthResult:
    """Round 138: persist a credential."""
    p = normalize_provider(provider)
    if p is None:
        return AuthResult(
            ok=False,
            output=(
                f"unknown provider: {provider!r}. "
                f"choices: {', '.join(VALID_PROVIDERS)}"
            ),
        )
    if not api_key.strip():
        return AuthResult(
            ok=False, output="empty key — aborted.",
        )
    store = _load_store()
    store[p] = {
        "api_key": api_key.strip(),
        "stored_via": "prometheus auth login",
    }
    _save_store(store)
    return AuthResult(
        ok=True,
        output=f"stored credentials for {p}.",
    )


def clear_credential(
    provider: Optional[str] = None,
) -> AuthResult:
    """Round 138: drop one or all stored credentials."""
    store = _load_store()
    if provider is None:
        if not store:
            return AuthResult(ok=True, output="no credentials stored.")
        n = len(store)
        _save_store({})
        return AuthResult(
            ok=True, output=f"cleared {n} credential(s).",
        )
    p = normalize_provider(provider)
    if p is None:
        return AuthResult(
            ok=False,
            output=f"unknown provider: {provider!r}.",
        )
    if p not in store:
        return AuthResult(
            ok=True, output=f"no credentials stored for {p}.",
        )
    del store[p]
    _save_store(store)
    return AuthResult(
        ok=True, output=f"cleared credentials for {p}.",
    )


def auth_status() -> AuthResult:
    """Round 138: show which providers have credentials, both
    from the file store and from env vars."""
    store = _load_store()
    lines: list[str] = ["auth status:"]
    for p in VALID_PROVIDERS:
        env_var = _PROVIDER_ENV.get(p, "")
        env_set = bool(os.environ.get(env_var, ""))
        file_set = p in store
        if not env_set and not file_set:
            continue
        sources: list[str] = []
        if file_set:
            sources.append("file")
        if env_set:
            sources.append(f"env({env_var})")
        lines.append(f"  ✓ {p:14s}  [{', '.join(sources)}]")
    if len(lines) == 1:
        lines.append("  (no credentials configured)")
    lines.append("")
    lines.append(
        "use `prometheus auth login <provider>` to store more"
    )
    return AuthResult(ok=True, output="\n".join(lines))


def get_credential(provider: str) -> Optional[str]:
    """Round 138: read a credential. Env wins over file so
    short-lived overrides work without rewriting the store."""
    p = normalize_provider(provider)
    if p is None:
        return None
    env_var = _PROVIDER_ENV.get(p, "")
    if env_var and os.environ.get(env_var):
        return os.environ[env_var]
    store = _load_store()
    entry = store.get(p)
    if isinstance(entry, dict):
        return entry.get("api_key")
    return None


# ---------- CLI subcommand entry ----------


def parse_auth_argv(argv: list[str]) -> tuple[str, str]:
    """Round 138: parse `auth <action> [provider]`. Returns
    (action, provider) where action defaults to `status` when
    nothing else is supplied."""
    raw = [a for a in argv or [] if not a.startswith("-")]
    action = (raw[1] if len(raw) > 1 else "status").lower()
    provider = raw[2] if len(raw) > 2 else ""
    return (action, provider)
