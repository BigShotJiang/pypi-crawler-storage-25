"""Round 143: `/share` blade — sanitized session export.

Exports the current session as a Markdown file under
`~/.prometheus/shared/`, with API keys, tokens, passwords,
and other secrets scrubbed. Optionally copies to clipboard
via pyperclip.

Pure data layer. The slash command consumes the helpers.
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional


# ---------- redaction ----------


_SECRET_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"sk-[A-Za-z0-9_-]{20,}"),
    re.compile(r"sk-ant-[A-Za-z0-9_-]{20,}"),
    re.compile(r"sk-or-v\d-[A-Za-z0-9_-]{20,}"),
    re.compile(r"gsk_[A-Za-z0-9]{20,}"),
    re.compile(r"AIza[A-Za-z0-9_-]{30,}"),         # Google
    re.compile(r"ghp_[A-Za-z0-9]{20,}"),           # GitHub PAT
    re.compile(r"github_pat_[A-Za-z0-9_]{20,}"),
    re.compile(r"ya29\.[A-Za-z0-9._-]{20,}"),      # Google OAuth
    re.compile(r"xox[bpoasr]-[A-Za-z0-9-]{10,}"),  # Slack
    re.compile(r"ntn_[A-Za-z0-9]{20,}"),           # Notion
    re.compile(r"Bearer\s+[A-Za-z0-9._-]{20,}"),
    re.compile(
        r"(?i)(?:api[_-]?key|secret|password|passwd|token)\s*[:=]\s*['\"]?[A-Za-z0-9._\-+/]{16,}",
    ),
    re.compile(
        r"-----BEGIN\s+(?:RSA\s+|EC\s+|DSA\s+|OPENSSH\s+)?PRIVATE\s+KEY-----[\s\S]+?-----END\s+(?:RSA\s+|EC\s+|DSA\s+|OPENSSH\s+)?PRIVATE\s+KEY-----",
    ),
)

_ENV_LINE_RX = re.compile(
    r"(?im)^([A-Z][A-Z0-9_]*(?:KEY|TOKEN|SECRET|PASS|PASSWORD)[A-Z0-9_]*)\s*=\s*\S+",
)


def redact(text: str) -> str:
    """Round 143: scrub secrets from a string. Pattern matches
    are replaced with `[REDACTED]`; ENV-style lines have their
    values masked entirely."""
    if not text:
        return text
    out = text
    out = _ENV_LINE_RX.sub(r"\1=[REDACTED]", out)
    for rx in _SECRET_PATTERNS:
        out = rx.sub("[REDACTED]", out)
    return out


# ---------- export ----------


@dataclass
class ShareExport:
    path: Path
    char_count: int
    message_count: int
    redacted_count: int


def _flatten_content(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for blk in content:
            if isinstance(blk, dict):
                parts.append(str(blk.get("text", "")))
            else:
                parts.append(str(blk))
        return "\n".join(p for p in parts if p)
    return str(content) if content is not None else ""


def assemble_markdown(
    *,
    messages: list[dict[str, Any]],
    label: str = "",
    timestamp: Optional[int] = None,
) -> tuple[str, int]:
    """Round 143: produce the markdown body + a count of
    redactions applied."""
    ts = timestamp if timestamp is not None else int(time.time())
    when = time.strftime(
        "%Y-%m-%d %H:%M:%S UTC", time.gmtime(ts),
    )
    out: list[str] = []
    title = label or "PrometheUS shared session"
    out.append(f"# {title}")
    out.append("")
    out.append(f"_Exported {when} · sanitized for sharing._")
    out.append("")
    redacted_total = 0
    for m in messages:
        if not isinstance(m, dict):
            continue
        role = str(m.get("role") or "")
        if role not in ("user", "assistant"):
            # Skip system + tool results — share is meant
            # for human-readable conversation only.
            continue
        body = _flatten_content(m.get("content"))
        if not body:
            continue
        scrubbed = redact(body)
        if scrubbed != body:
            redacted_total += 1
        out.append(f"## {role}")
        out.append("")
        out.append(scrubbed)
        out.append("")
    return ("\n".join(out), redacted_total)


def shared_dir() -> Path:
    return Path.home() / ".prometheus" / "shared"


def write_share(
    *,
    messages: list[dict[str, Any]],
    label: str = "",
    target_dir: Optional[Path] = None,
    timestamp: Optional[int] = None,
) -> ShareExport:
    """Round 143: write the sanitized markdown."""
    base = target_dir or shared_dir()
    base.mkdir(parents=True, exist_ok=True)
    ts = timestamp if timestamp is not None else int(time.time())
    body, redacted_n = assemble_markdown(
        messages=messages, label=label, timestamp=ts,
    )
    path = base / f"shared-{ts}.md"
    path.write_text(body, encoding="utf-8")
    return ShareExport(
        path=path,
        char_count=len(body),
        message_count=sum(
            1 for m in messages
            if isinstance(m, dict)
            and m.get("role") in ("user", "assistant")
        ),
        redacted_count=redacted_n,
    )


def copy_to_clipboard(body: str) -> bool:
    """Round 143: best-effort clipboard copy via pyperclip.
    Returns True on success, False when the dep isn't
    installed or the copy fails."""
    try:
        import pyperclip  # type: ignore[import-not-found]
    except ImportError:
        return False
    try:
        pyperclip.copy(body)
        return True
    except Exception:
        return False


def render_summary(export: ShareExport) -> str:
    return (
        f"shared session\n"
        f"  path:      {export.path}\n"
        f"  size:      {export.char_count:,} chars\n"
        f"  messages:  {export.message_count}\n"
        f"  redacted:  {export.redacted_count} block(s)"
    )
