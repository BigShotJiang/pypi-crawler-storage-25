"""Round 142: background-session management.

Sessions survive terminal closure. Each background session
writes a PID file to `~/.prometheus/sessions/<session-id>.json`
with metadata + a tail-able log file.

Subcommands:

  * `prometheus ps`              — list all background sessions
  * `prometheus logs <id>`       — tail a session's log file
  * `prometheus attach <id>`     — reattach to the session
  * `prometheus kill <id>`       — terminate the session

Pure data layer — actual process spawning is the host's job;
this module gives the registry, PID-file I/O, and the
subcommand bodies.
"""
from __future__ import annotations

import json
import os
import signal
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


_TRUTHY = ("1", "true", "yes", "on")


def bg_sessions_enabled() -> bool:
    """Round 142: env gate. Default OFF — opt-in only because
    the feature requires the user to be aware that sessions
    don't auto-clean."""
    return os.environ.get(
        "PROMETHEUS_BG_SESSIONS", "",
    ).strip().lower() in _TRUTHY


def bg_sessions_setting_enabled(setting: Optional[bool]) -> bool:
    """Round 142: env wins, then setting, default off."""
    if bg_sessions_enabled():
        return True
    if setting is None:
        return False
    return bool(setting)


# ---------- registry ----------


@dataclass
class BgSession:
    session_id: str
    pid: int
    started_at: int
    status: str          # `running` / `stopped` / `unknown`
    log_path: str
    workdir: str = ""
    label: str = ""


def sessions_dir() -> Path:
    return Path.home() / ".prometheus" / "sessions"


def _session_file(session_id: str) -> Path:
    return sessions_dir() / f"{session_id}.json"


def write_pid_file(s: BgSession) -> Path:
    """Round 142: register a session. The runtime calls this
    once when a background session starts."""
    base = sessions_dir()
    base.mkdir(parents=True, exist_ok=True)
    target = _session_file(s.session_id)
    payload = {
        "session_id": s.session_id,
        "pid": int(s.pid),
        "started_at": int(s.started_at),
        "status": s.status,
        "log_path": s.log_path,
        "workdir": s.workdir,
        "label": s.label,
    }
    target.write_text(
        json.dumps(payload, indent=2), encoding="utf-8",
    )
    return target


def remove_pid_file(session_id: str) -> bool:
    p = _session_file(session_id)
    if not p.exists():
        return False
    try:
        p.unlink()
        return True
    except OSError:
        return False


def _read_pid_file(p: Path) -> Optional[BgSession]:
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    try:
        return BgSession(
            session_id=str(d.get("session_id") or p.stem),
            pid=int(d.get("pid", 0)),
            started_at=int(d.get("started_at", 0)),
            status=str(d.get("status", "unknown")),
            log_path=str(d.get("log_path", "")),
            workdir=str(d.get("workdir", "")),
            label=str(d.get("label", "")),
        )
    except (TypeError, ValueError):
        return None


def list_sessions() -> list[BgSession]:
    """Round 142: enumerate registered sessions. Stale PIDs
    (process no longer alive) get marked `stopped` but are
    still returned so the user can clean them up."""
    base = sessions_dir()
    if not base.exists():
        return []
    out: list[BgSession] = []
    for p in sorted(base.glob("*.json")):
        s = _read_pid_file(p)
        if s is None:
            continue
        if s.status == "running" and not pid_is_alive(s.pid):
            s.status = "stopped"
        out.append(s)
    out.sort(key=lambda s: s.started_at, reverse=True)
    return out


def find_session(prefix: str) -> Optional[BgSession]:
    """Round 142: pick a session by id-prefix match."""
    if not prefix:
        return None
    rows = list_sessions()
    matches = [
        s for s in rows
        if s.session_id == prefix or s.session_id.startswith(prefix)
    ]
    if not matches:
        # Try label fallback.
        matches = [
            s for s in rows
            if s.label and prefix.lower() in s.label.lower()
        ]
    return matches[0] if matches else None


# ---------- pid liveness + signaling ----------


def pid_is_alive(pid: int) -> bool:
    """Round 142: cross-platform liveness check."""
    if pid <= 0:
        return False
    try:
        if os.name == "nt":
            # On Windows, sending signal 0 raises if dead.
            import ctypes
            kernel32 = ctypes.windll.kernel32
            SYNCHRONIZE = 0x00100000
            handle = kernel32.OpenProcess(SYNCHRONIZE, False, int(pid))
            if not handle:
                return False
            kernel32.CloseHandle(handle)
            return True
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError, PermissionError):
        return False


def kill_session(s: BgSession) -> tuple[bool, str]:
    """Round 142: graceful then force terminate."""
    if not pid_is_alive(s.pid):
        return (True, "already stopped")
    try:
        if os.name == "nt":
            import ctypes
            kernel32 = ctypes.windll.kernel32
            PROCESS_TERMINATE = 0x0001
            handle = kernel32.OpenProcess(PROCESS_TERMINATE, False, int(s.pid))
            if not handle:
                return (False, "OpenProcess failed")
            ok = bool(kernel32.TerminateProcess(handle, 1))
            kernel32.CloseHandle(handle)
            return (ok, "terminated" if ok else "TerminateProcess failed")
        os.kill(s.pid, signal.SIGTERM)
        # Give the process a moment to clean up.
        for _ in range(20):
            if not pid_is_alive(s.pid):
                return (True, "terminated (SIGTERM)")
            time.sleep(0.05)
        os.kill(s.pid, signal.SIGKILL)
        return (True, "killed (SIGKILL)")
    except (OSError, ProcessLookupError) as e:
        return (False, str(e))


# ---------- log tailing ----------


def tail_log(
    log_path: str, *, lines: int = 200,
) -> list[str]:
    """Round 142: cheap last-N-lines reader."""
    p = Path(log_path)
    if not p.exists():
        return []
    try:
        content = p.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    return content.splitlines()[-max(1, lines):]


# ---------- subcommand bodies ----------


@dataclass
class BgResult:
    exit_code: int
    output: str = ""


def _format_duration(seconds: int) -> str:
    if seconds < 60:
        return f"{seconds}s"
    m, s = divmod(seconds, 60)
    if m < 60:
        return f"{m}m {s}s"
    h, m = divmod(m, 60)
    if h < 24:
        return f"{h}h {m}m"
    d, h = divmod(h, 24)
    return f"{d}d {h}h"


def render_ps(rows: list[BgSession]) -> str:
    if not rows:
        return (
            "no background sessions.\n"
            "  enable with PROMETHEUS_BG_SESSIONS=1, "
            "then launch with `prometheus --bg`."
        )
    out: list[str] = ["background sessions:"]
    out.append(
        f"  {'session-id':16s}  {'pid':>7s}  "
        f"{'status':9s}  {'age':>10s}  label"
    )
    now = int(time.time())
    for s in rows:
        age = _format_duration(max(0, now - s.started_at))
        out.append(
            f"  {s.session_id[:16]:16s}  "
            f"{s.pid:>7d}  {s.status:9s}  "
            f"{age:>10s}  {s.label or '(unlabeled)'}"
        )
    return "\n".join(out)


def run_ps_subcommand() -> BgResult:
    return BgResult(
        exit_code=0,
        output=render_ps(list_sessions()),
    )


def run_logs_subcommand(
    target: str, *, lines: int = 200,
) -> BgResult:
    if not target:
        return BgResult(
            exit_code=2,
            output="usage: prometheus logs <session-id>",
        )
    s = find_session(target)
    if s is None:
        return BgResult(
            exit_code=1, output=f"no session matching {target!r}",
        )
    if not s.log_path:
        return BgResult(
            exit_code=1,
            output=f"session {s.session_id[:8]} has no log path",
        )
    body = tail_log(s.log_path, lines=lines)
    if not body:
        return BgResult(
            exit_code=0,
            output=(
                f"(log empty or unreadable: {s.log_path})"
            ),
        )
    return BgResult(exit_code=0, output="\n".join(body))


def run_attach_subcommand(target: str) -> BgResult:
    if not target:
        return BgResult(
            exit_code=2,
            output="usage: prometheus attach <session-id>",
        )
    s = find_session(target)
    if s is None:
        return BgResult(
            exit_code=1, output=f"no session matching {target!r}",
        )
    if not pid_is_alive(s.pid):
        return BgResult(
            exit_code=1,
            output=(
                f"session {s.session_id[:8]} not running "
                f"(status={s.status}); use `prometheus logs` instead."
            ),
        )
    return BgResult(
        exit_code=0,
        output=(
            f"attaching to session {s.session_id[:8]} "
            f"(pid {s.pid})…\n"
            f"  log: {s.log_path}"
        ),
    )


def run_kill_subcommand(target: str) -> BgResult:
    if not target:
        return BgResult(
            exit_code=2, output="usage: prometheus kill <session-id>",
        )
    s = find_session(target)
    if s is None:
        return BgResult(
            exit_code=1, output=f"no session matching {target!r}",
        )
    ok, msg = kill_session(s)
    if ok:
        s.status = "stopped"
        try:
            write_pid_file(s)
        except Exception:
            pass
        return BgResult(
            exit_code=0,
            output=f"session {s.session_id[:8]}: {msg}",
        )
    return BgResult(
        exit_code=1,
        output=f"session {s.session_id[:8]}: failed — {msg}",
    )
