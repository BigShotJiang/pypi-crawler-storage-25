"""Round 141: streaming text incremental append + flush rate.

Two surfaces:

  * `IncrementalBuffer` — a single message's growing text. Each
    streamed chunk appends; the host emits the *delta* only,
    never re-renders the full message.
  * `FlushClock` — gates renders to a configurable cadence so
    we don't redraw 60×/sec for small chunks.

Plus the static/dynamic split tracker (Task 10): finalized
messages are marked `static` and never re-rendered; only the
currently-streaming message + active UI elements are dynamic.
"""
from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from typing import Any, Optional


_TRUTHY = ("1", "true", "yes", "on")


# ---------- flush rate ----------


def streaming_flush_ms(setting: Any = None) -> int:
    """Round 141: how often the host flushes streaming text to
    the screen. Default 16ms (~60fps). 0 means flush every chunk
    (highest CPU)."""
    raw = os.environ.get("PROMETHEUS_STREAMING_FLUSH_MS", "").strip()
    if raw:
        try:
            n = int(raw)
            return max(0, n)
        except ValueError:
            pass
    if isinstance(setting, (int, float)):
        try:
            n = int(setting)
            if n >= 0:
                return n
        except (TypeError, ValueError):
            pass
    return 16


@dataclass
class FlushClock:
    """Round 141: rate-limit the renderer. `should_flush()`
    returns True every `interval_ms` plus on-demand at message
    end."""
    interval_ms: int = 16
    last_flush_at: float = 0.0   # monotonic seconds

    def should_flush(self, *, now: Optional[float] = None) -> bool:
        t = now if now is not None else time.monotonic()
        if self.interval_ms <= 0:
            self.last_flush_at = t
            return True
        elapsed_ms = (t - self.last_flush_at) * 1000.0
        if elapsed_ms >= self.interval_ms:
            self.last_flush_at = t
            return True
        return False

    def force_flush(self, *, now: Optional[float] = None) -> None:
        """Mark a flush as having happened (e.g., end-of-message)."""
        self.last_flush_at = now if now is not None else time.monotonic()

    def reset(self) -> None:
        self.last_flush_at = 0.0


# ---------- incremental buffer ----------


@dataclass
class IncrementalBuffer:
    """Round 141: one streaming message. `append()` returns
    the *delta* the host should write to screen, not the full
    text. Once `finalize()` is called, the buffer is sealed."""
    text: str = ""
    finalized: bool = False
    char_count: int = 0
    chunk_count: int = 0

    def append(self, chunk: str) -> str:
        if self.finalized or not chunk:
            return ""
        self.text += chunk
        self.char_count += len(chunk)
        self.chunk_count += 1
        return chunk

    def finalize(self) -> str:
        """Round 141: seal the buffer. No further appends; the
        message moves from `dynamic` to `static`."""
        self.finalized = True
        return self.text

    def reset(self) -> None:
        self.text = ""
        self.finalized = False
        self.char_count = 0
        self.chunk_count = 0


# ---------- static / dynamic split (Task 10) ----------


@dataclass
class RenderEntry:
    """Round 141: one entry in the render log. `kind=static`
    is never re-rendered; `kind=dynamic` is allowed to update."""
    kind: str        # "static" / "dynamic"
    role: str        # "user" / "assistant" / "tool" / "system" / "ui"
    content: str
    id: str = ""     # optional handle for in-place updates


@dataclass
class RenderTimeline:
    """Round 141: ordered list of render entries. Static
    entries are write-once. The host can mutate dynamic ones
    by id."""
    entries: list[RenderEntry] = field(default_factory=list)

    def append_static(
        self, *, role: str, content: str, id: str = "",
    ) -> RenderEntry:
        e = RenderEntry(
            kind="static", role=role, content=content, id=id,
        )
        self.entries.append(e)
        return e

    def append_dynamic(
        self, *, role: str, content: str, id: str,
    ) -> RenderEntry:
        e = RenderEntry(
            kind="dynamic", role=role, content=content, id=id,
        )
        self.entries.append(e)
        return e

    def update_dynamic(self, *, id: str, content: str) -> bool:
        """Round 141: in-place update. Refuses to mutate static
        entries — that's the contract."""
        for e in self.entries:
            if e.id == id and e.kind == "dynamic":
                e.content = content
                return True
        return False

    def freeze_dynamic(self, *, id: str) -> bool:
        """Round 141: promote a dynamic entry to static — once
        the streaming message is done, it's done."""
        for e in self.entries:
            if e.id == id and e.kind == "dynamic":
                e.kind = "static"
                return True
        return False

    def static_count(self) -> int:
        return sum(1 for e in self.entries if e.kind == "static")

    def dynamic_count(self) -> int:
        return sum(1 for e in self.entries if e.kind == "dynamic")

    # ---- round 166 / B4: contract surfaces -----------------

    def streaming_entry(self) -> Optional[RenderEntry]:
        """Round 166: the single in-flight dynamic entry, if any.
        Returns None when nothing is streaming. Used by the host
        to identify which message should land in the
        STREAMING_MESSAGE region."""
        for e in self.entries:
            if e.kind == "dynamic":
                return e
        return None

    def freeze_all_dynamic_except(
        self, *, active_id: str = "",
    ) -> int:
        """Round 166: freeze every dynamic entry except the one
        with `active_id`. Returns the number of entries promoted
        to static. Defensive cleanup the host calls when the
        model emits `stop` but a previous in-flight entry was
        never explicitly frozen."""
        n = 0
        for e in self.entries:
            if e.kind == "dynamic" and e.id != active_id:
                e.kind = "static"
                n += 1
        return n

    def static_content_hash(self) -> int:
        """Round 166 / B4: a stable hash of every static entry's
        content. Used by the contract test to assert that the
        static transcript is byte-identical after 100 streaming
        ticks. If this hash changes between ticks while only the
        streaming entry was updated, the static-no-repaint
        contract is broken."""
        h = 0
        for e in self.entries:
            if e.kind == "static":
                # Combine in a stable, order-sensitive way.
                h = (h * 1_000_003) ^ hash((e.role, e.id, e.content))
        return h


# ---------- layout-shift tracking (Task 3 helper) ----------


@dataclass
class LayoutShift:
    """Round 141: tracks whether the next frame will require a
    layout-shifted full-repaint vs a content-only patch.

    Set `mark_layout_change()` whenever the host adds/removes
    widgets, resizes, or scrolls. Otherwise `text_only_change()`
    keeps the diff path active."""
    layout_shifted: bool = False

    def mark_layout_change(self) -> None:
        self.layout_shifted = True

    def text_only_change(self) -> None:
        # Caller hint: this frame is content-only.
        pass

    def consume(self) -> bool:
        """Returns True when the next render must do a full
        repaint; resets the flag."""
        was = self.layout_shifted
        self.layout_shifted = False
        return was


def render_streaming_status(
    flush: FlushClock, buf: IncrementalBuffer,
) -> str:
    """Round 141: status surfaced by `/tui status`."""
    return (
        f"streaming: flush={flush.interval_ms}ms · "
        f"buf_chars={buf.char_count} · "
        f"chunks={buf.chunk_count} · "
        f"finalized={buf.finalized}"
    )
