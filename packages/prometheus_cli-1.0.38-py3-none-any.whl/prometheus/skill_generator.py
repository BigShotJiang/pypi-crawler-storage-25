"""Round 147-final-v3: /skill-generator wizard.

Generates a new aptitude markdown file from a structured
prompt set. The wizard's state machine walks the user
through:

  1. name (snake-kebab)
  2. purpose (one sentence)
  3. triggers (comma-separated)
  4. body (the playbook itself)

When complete, writes
`<workdir>/.prometheus/aptitudes/<name>/APTITUDE.md` with
the YAML frontmatter the round-98 loader expects.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


_NAME_RX = re.compile(r"^[a-z][a-z0-9_-]{1,40}$")


# ---------- wizard state ----------


_STAGES = ("name", "purpose", "triggers", "body", "review", "done")


@dataclass
class GeneratorState:
    stage: str = "name"
    name: str = ""
    purpose: str = ""
    triggers: tuple[str, ...] = ()
    body: str = ""

    def step(self, value: str) -> tuple[str, str]:
        """Round 147-final-v3: feed the user's answer for the
        current stage. Returns (next_stage, prompt). Raises
        ValueError on invalid input."""
        v = (value or "").strip()
        if self.stage == "name":
            cleaned = re.sub(r"\s+", "-", v.lower())
            if not _NAME_RX.match(cleaned):
                raise ValueError(
                    "name must be lowercase letters, digits, "
                    "`_`, or `-` (2–40 chars)"
                )
            self.name = cleaned
            self.stage = "purpose"
            return (self.stage, "Describe the purpose in one sentence.")
        if self.stage == "purpose":
            if len(v) < 10:
                raise ValueError(
                    "purpose must be at least 10 characters"
                )
            self.purpose = v
            self.stage = "triggers"
            return (self.stage, (
                "Enter trigger phrases, comma-separated "
                "(blank for always-on)."
            ))
        if self.stage == "triggers":
            if not v:
                self.triggers = ()
            else:
                parts = [p.strip() for p in v.split(",")]
                self.triggers = tuple(p for p in parts if p)
            self.stage = "body"
            return (self.stage, (
                "Paste the aptitude body (playbook text)."
            ))
        if self.stage == "body":
            if len(v) < 30:
                raise ValueError(
                    "body must be at least 30 characters"
                )
            self.body = v
            self.stage = "review"
            return (self.stage, (
                "Review the aptitude. Type `save` to write, "
                "or `cancel` to discard."
            ))
        if self.stage == "review":
            cmd = v.lower()
            if cmd == "save":
                self.stage = "done"
                return (self.stage, "saving…")
            if cmd == "cancel":
                self.stage = "done"
                return (self.stage, "cancelled.")
            raise ValueError("type `save` or `cancel`")
        return (self.stage, "")


def assemble_markdown(state: GeneratorState) -> str:
    """Round 147-final-v3: produce the full APTITUDE.md
    contents."""
    lines: list[str] = []
    lines.append("---")
    lines.append(f"name: {state.name}")
    lines.append(f"purpose: {state.purpose}")
    if state.triggers:
        lines.append(
            "triggers: ["
            + ", ".join(state.triggers) + "]"
        )
    lines.append("---")
    lines.append("")
    lines.append(state.body.strip())
    lines.append("")
    return "\n".join(lines)


def write_aptitude(
    state: GeneratorState, *, workdir: Path,
) -> Path:
    """Round 147-final-v3: persist the aptitude. Returns the
    written path."""
    target_dir = workdir / ".prometheus" / "aptitudes" / state.name
    target_dir.mkdir(parents=True, exist_ok=True)
    target = target_dir / "APTITUDE.md"
    target.write_text(
        assemble_markdown(state), encoding="utf-8",
    )
    return target


def render_review(state: GeneratorState) -> str:
    triggers = ", ".join(state.triggers) if state.triggers else "(always-on)"
    return (
        f"new aptitude — review\n"
        f"  name:     {state.name}\n"
        f"  purpose:  {state.purpose}\n"
        f"  triggers: {triggers}\n"
        f"  body:     {len(state.body):,} chars\n\n"
        f"  type `save` to write, `cancel` to discard."
    )
