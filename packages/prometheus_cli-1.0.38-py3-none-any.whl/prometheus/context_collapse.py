"""Round 143-final: 6th compaction stage — Context Collapse.

When standard compaction can't free enough room (~90% window
still full after pass 5), Context Collapse archives entire
conversation chunks into metadata placeholders. The
placeholder retains:

  * the role boundary (so model still sees the turn happened)
  * a one-line summary the host's compactor produced
  * an opaque archive id pointing to the full transcript

Triggered by the agent loop when `should_collapse()` returns
True. Pure data layer.

Behind `PROMETHEUS_CONTEXT_COLLAPSE=1` — opt-in.
"""
from __future__ import annotations

import json
import os
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


_TRUTHY = ("1", "true", "yes", "on")


def context_collapse_enabled() -> bool:
    return os.environ.get(
        "PROMETHEUS_CONTEXT_COLLAPSE", "",
    ).strip().lower() in _TRUTHY


def should_collapse(
    *,
    used_tokens: int,
    context_window: int,
    threshold_pct: int = 90,
) -> bool:
    """Round 143-final: trigger when used / window crosses the
    threshold percentage."""
    if not context_collapse_enabled():
        return False
    if context_window <= 0:
        return False
    return (used_tokens / context_window) * 100 >= threshold_pct


# ---------- archive store ----------


@dataclass
class CollapsedChunk:
    """Round 143-final: one collapsed chunk of conversation."""
    archive_id: str
    role_summary: dict[str, int]   # role → message count
    summary: str
    archived_at: int
    original_message_count: int


def archive_dir() -> Path:
    return Path.home() / ".prometheus" / "collapsed"


def write_archive(
    *,
    archive_id: str,
    messages: list[dict[str, Any]],
    target_dir: Optional[Path] = None,
) -> Path:
    """Round 143-final: write the full chunk to the archive
    directory so it can be re-hydrated later."""
    base = target_dir or archive_dir()
    base.mkdir(parents=True, exist_ok=True)
    p = base / f"{archive_id}.json"
    p.write_text(
        json.dumps(messages, indent=2, default=str),
        encoding="utf-8",
    )
    return p


def read_archive(
    archive_id: str, *, target_dir: Optional[Path] = None,
) -> list[dict[str, Any]]:
    base = target_dir or archive_dir()
    p = base / f"{archive_id}.json"
    if not p.exists():
        return []
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except (OSError, json.JSONDecodeError):
        return []


# ---------- collapse pipeline ----------


def collapse_messages(
    messages: list[dict[str, Any]],
    *,
    keep_last: int = 10,
    summary: str = "",
    target_dir: Optional[Path] = None,
) -> tuple[list[dict[str, Any]], CollapsedChunk]:
    """Round 143-final: archive everything except the system
    prompt + last N messages. Inject a single placeholder
    message in their place.

    Returns (new_message_list, chunk_record)."""
    if not messages:
        return ([], CollapsedChunk(
            archive_id="", role_summary={},
            summary="", archived_at=int(time.time()),
            original_message_count=0,
        ))
    head: list[dict[str, Any]] = []
    body = list(messages)
    # Preserve system prompt at the front.
    if body and isinstance(body[0], dict) and body[0].get("role") == "system":
        head.append(body[0])
        body = body[1:]
    keep_last = max(1, int(keep_last))
    if len(body) <= keep_last:
        # Nothing to collapse.
        return (head + body, CollapsedChunk(
            archive_id="", role_summary={},
            summary=summary, archived_at=int(time.time()),
            original_message_count=0,
        ))
    archived = body[:-keep_last]
    keep = body[-keep_last:]
    archive_id = str(uuid.uuid4())[:12]
    # Role count for the placeholder.
    role_summary: dict[str, int] = {}
    for m in archived:
        if isinstance(m, dict):
            r = str(m.get("role") or "")
            if r:
                role_summary[r] = role_summary.get(r, 0) + 1
    # Persist.
    write_archive(
        archive_id=archive_id,
        messages=archived,
        target_dir=target_dir,
    )
    chunk = CollapsedChunk(
        archive_id=archive_id,
        role_summary=role_summary,
        summary=summary or _auto_summary(archived),
        archived_at=int(time.time()),
        original_message_count=len(archived),
    )
    placeholder = {
        "role": "system",
        "content": (
            f"[context collapsed: {chunk.original_message_count} "
            f"message(s) archived. summary: {chunk.summary}. "
            f"archive_id: {chunk.archive_id}]"
        ),
        "_collapsed_archive_id": chunk.archive_id,
    }
    return (head + [placeholder] + keep, chunk)


def _auto_summary(archived: list[dict[str, Any]]) -> str:
    """Round 143-final: cheap auto-summary — last user
    message's first 80 chars, since user turns usually frame
    intent."""
    for m in reversed(archived):
        if isinstance(m, dict) and m.get("role") == "user":
            body = m.get("content") or ""
            if isinstance(body, list):
                # Multi-part — flatten.
                body = " ".join(
                    str(b.get("text", "")) if isinstance(b, dict)
                    else str(b)
                    for b in body
                )
            text = str(body).strip().replace("\n", " ")
            if text:
                return text[:80] + ("…" if len(text) > 80 else "")
    return f"{len(archived)} message(s) archived"


def render_chunk(chunk: CollapsedChunk) -> str:
    """Round 143-final: human render for the host log."""
    if not chunk.archive_id:
        return "context collapse: nothing to archive"
    parts: list[str] = []
    parts.append(
        f"context collapsed → {chunk.original_message_count} "
        f"message(s) archived as {chunk.archive_id}"
    )
    if chunk.role_summary:
        roles = ", ".join(
            f"{r}={n}" for r, n in sorted(
                chunk.role_summary.items(),
            )
        )
        parts.append(f"  by role: {roles}")
    if chunk.summary:
        parts.append(f"  summary: {chunk.summary}")
    return "\n".join(parts)
