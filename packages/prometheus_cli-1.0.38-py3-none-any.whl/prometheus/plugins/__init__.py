"""Plugin marketplace + loader.

A plugin is a directory under `~/.prometheus/plugins/<name>/` containing
a `plugin.json` manifest and any combination of:
  - commands/*.md       — slash commands (loaded the same way as
                          .prometheus/commands but tagged with origin)
  - skills/*.md         — agent-skills (same merge into the system prompt)
  - hooks.json          — PreToolUse / PostToolUse hooks
  - mcp.json            — MCP servers to register

The marketplace is just an index file at `~/.prometheus/marketplace.json`
listing where to FETCH plugins from (filesystem path, git URL, http URL).
We don't auto-fetch — installation is explicit via /plugins install.

v1 keeps the surface small: filesystem sources only; git/http resolvers
are stubbed with a clear "not yet" error so users hit a good message
instead of a NotImplementedError. Trust is gated through the existing
Workspace Trust file — installing a plugin marks it trusted; uninstall
removes the grant.
"""
from .loader import (
    Plugin,
    PluginManifest,
    discover_installed,
    install_filesystem_plugin,
    uninstall_plugin,
    load_plugin_skills,
    load_plugin_commands,
)
from .marketplace import (
    MarketplaceEntry,
    list_marketplace,
    load_marketplace,
)

__all__ = [
    "Plugin", "PluginManifest", "MarketplaceEntry",
    "discover_installed", "install_filesystem_plugin",
    "uninstall_plugin", "load_plugin_skills", "load_plugin_commands",
    "list_marketplace", "load_marketplace",
]
