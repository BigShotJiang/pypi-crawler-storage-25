"""Marketplace index — pointers to where plugins can be FETCHED from.

`~/.prometheus/marketplace.json` (community list, user-editable):

    {
      "plugins": [
        {"name": "deploy-cf", "source": "filesystem", "path": "~/code/cf-plugin"},
        {"name": "lint-pack", "source": "git", "url": "https://github.com/.../...", "rev": "v1.0.0"}
      ]
    }

The marketplace is informational in v1: listing it tells the user what
they CAN install. /plugins install <name> resolves the entry's `source`
and copies into the plugin dir. Only filesystem source resolves today;
git/http throw a clear "not yet" error.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from prometheus.config import USER_CONFIG_DIR


MARKETPLACE_FILE = USER_CONFIG_DIR / "marketplace.json"


@dataclass(frozen=True, slots=True)
class MarketplaceEntry:
    name: str
    source: str          # "filesystem" | "git" | "http"
    path: str = ""       # filesystem path (when source=filesystem)
    url: str = ""        # git/http URL
    rev: str = ""        # optional git revision
    description: str = ""


def load_marketplace(path: Path | None = None) -> list[MarketplaceEntry]:
    target = path or MARKETPLACE_FILE
    if not target.exists():
        return []
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
    except Exception:
        return []
    plugins = data.get("plugins") or [] if isinstance(data, dict) else []
    out: list[MarketplaceEntry] = []
    for entry in plugins:
        if not isinstance(entry, dict):
            continue
        name = str(entry.get("name", "")).strip()
        source = str(entry.get("source", "")).strip().lower()
        if not name or source not in ("filesystem", "git", "http"):
            continue
        out.append(MarketplaceEntry(
            name=name,
            source=source,
            path=str(entry.get("path", "")),
            url=str(entry.get("url", "")),
            rev=str(entry.get("rev", "")),
            description=str(entry.get("description", ""))[:200],
        ))
    return out


def list_marketplace() -> list[MarketplaceEntry]:
    return load_marketplace()


def resolve_to_filesystem(entry: MarketplaceEntry) -> Path:
    """Convert a marketplace entry to a local source dir we can install
    from. v1 = filesystem only; git/http raise a friendly error."""
    if entry.source == "filesystem":
        from os.path import expanduser
        p = Path(expanduser(entry.path))
        if not p.exists() or not p.is_dir():
            raise ValueError(f"filesystem source missing: {p}")
        return p
    raise NotImplementedError(
        f"plugin source {entry.source!r} not supported in v1 — "
        f"clone manually and use 'filesystem' source for now"
    )
