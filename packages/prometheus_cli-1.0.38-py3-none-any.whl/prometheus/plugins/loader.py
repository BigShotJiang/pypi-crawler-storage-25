"""Plugin discovery + install/uninstall.

Plugins live under `~/.prometheus/plugins/<name>/`. Installing a plugin
copies (or links) its files into that location and creates an entry in
`~/.prometheus/installed.json`. Discovery walks the directory and
returns one Plugin per valid manifest.

`plugin.json` schema:

    {
      "name": "deploy-cf",
      "version": "1.0.0",
      "description": "Cloudflare Worker deployment",
      "author": "PrometheUS Community",
      "enabled": true,
      "components": {
        "commands": true,
        "skills": true,
        "hooks": false,
        "mcp": false
      }
    }

Unknown keys are rejected (closed-schema, same posture as MCP config).
Component flags let users disable parts of a plugin without uninstalling.
"""
from __future__ import annotations

import json
import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from prometheus.config import USER_CONFIG_DIR


PLUGINS_DIR = USER_CONFIG_DIR / "plugins"
INSTALLED_INDEX = USER_CONFIG_DIR / "installed.json"

_NAME_RX = re.compile(r"^[a-z0-9][a-z0-9_-]{0,40}$")


@dataclass(frozen=True, slots=True)
class PluginManifest:
    name: str
    version: str
    description: str
    author: str
    enabled: bool
    components: dict[str, bool]
    # 1.0.3 (CC v2.1.105 parity): top-level `monitors` key — list of
    # background monitor specs that auto-arm at session start (or on
    # skill invoke if `trigger=="skill"`). A monitor spec is a dict
    # with keys: `name` (str), `command` (str shell), `cadence_seconds`
    # (int, default 60), `trigger` (str, "session_start"|"skill",
    # default "session_start"). Empty tuple means no monitors.
    monitors: tuple[dict, ...] = ()


@dataclass(frozen=True, slots=True)
class Plugin:
    manifest: PluginManifest
    path: Path  # filesystem location of the plugin directory


def _parse_manifest(raw: dict[str, Any]) -> PluginManifest:
    allowed = {
        "name", "version", "description",
        "author", "enabled", "components",
        # 1.0.3: CC v2.1.105 parity — top-level monitors key.
        "monitors",
    }
    extras = set(raw.keys()) - allowed
    if extras:
        raise ValueError(f"unknown plugin manifest keys: {sorted(extras)}")
    name = str(raw.get("name", "")).strip()
    if not _NAME_RX.match(name):
        raise ValueError(f"invalid plugin name: {name!r}")
    components = raw.get("components") or {}
    if not isinstance(components, dict):
        raise ValueError("components must be object")
    safe_components = {
        k: bool(components.get(k, False))
        for k in ("commands", "skills", "hooks", "mcp")
    }
    # 1.0.3: parse monitors. Each entry must be a dict with at least
    # `name` (str) and `command` (str). Bad entries are dropped (not
    # raised) so a typo in one monitor doesn't take down the plugin.
    raw_monitors = raw.get("monitors") or []
    monitors_out: list[dict] = []
    if isinstance(raw_monitors, list):
        for m in raw_monitors:
            if not isinstance(m, dict):
                continue
            mname = str(m.get("name") or "").strip()
            mcmd = str(m.get("command") or "").strip()
            if not mname or not mcmd:
                continue
            try:
                cadence = max(1, int(m.get("cadence_seconds", 60)))
            except (TypeError, ValueError):
                cadence = 60
            trigger = str(m.get("trigger") or "session_start").strip()
            if trigger not in ("session_start", "skill"):
                trigger = "session_start"
            monitors_out.append({
                "name": mname[:60],
                "command": mcmd,
                "cadence_seconds": cadence,
                "trigger": trigger,
            })
    return PluginManifest(
        name=name,
        version=str(raw.get("version", "0.0.0")),
        description=str(raw.get("description", ""))[:200],
        author=str(raw.get("author", ""))[:120],
        enabled=bool(raw.get("enabled", True)),
        components=safe_components,
        monitors=tuple(monitors_out),
    )


def discover_installed() -> list[Plugin]:
    """Walk PLUGINS_DIR. Returns one Plugin per valid manifest. Plugins
    with malformed manifests are skipped (not raised) so one bad entry
    doesn't take down /plugins."""
    if not PLUGINS_DIR.exists() or not PLUGINS_DIR.is_dir():
        return []
    out: list[Plugin] = []
    for child in sorted(PLUGINS_DIR.iterdir()):
        if not child.is_dir():
            continue
        manifest_path = child / "plugin.json"
        if not manifest_path.exists():
            continue
        try:
            data = json.loads(manifest_path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                continue
            manifest = _parse_manifest(data)
        except Exception:
            continue
        if manifest.name != child.name:
            # Defensive: directory must match manifest name so /plugins
            # uninstall <name> can't delete the wrong directory.
            continue
        out.append(Plugin(manifest=manifest, path=child))
    return out


def install_filesystem_plugin(source: Path, *, force: bool = False) -> Plugin:
    """Copy a plugin directory into PLUGINS_DIR. Source must be a
    directory containing a valid plugin.json. Returns the installed Plugin.

    No git/http resolver in v1 — those routes are open supply-chain holes
    we're not ready to defend; user installs from filesystem only.
    Symlinks within the source are REJECTED (audit P2: a symlink-bombed
    or self-referential source would hang/fill disk during copytree).
    """
    if not source.exists() or not source.is_dir():
        raise ValueError(f"source must be an existing directory: {source}")
    if source.is_symlink():
        raise ValueError("plugin source must not be a symlink")
    # Walk the source and bail if anything is a symlink. iterdir is
    # cheap; we only walk top + 1 level deep where plugin files live.
    for child in source.rglob("*"):
        if child.is_symlink():
            raise ValueError(
                f"plugin source contains symlink: {child.relative_to(source)} "
                f"(symlinks not allowed for supply-chain hardening)"
            )
    manifest_path = source / "plugin.json"
    if not manifest_path.exists():
        raise ValueError(f"missing plugin.json in {source}")
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest = _parse_manifest(data)
    target = PLUGINS_DIR / manifest.name
    if target.exists() and not force:
        raise ValueError(f"already installed: {manifest.name}")
    PLUGINS_DIR.mkdir(parents=True, exist_ok=True)
    if target.exists():
        shutil.rmtree(target)
    # symlinks=False ensures any symlink we missed in the pre-walk
    # would be copied as a regular file (not followed); but the
    # pre-walk above is the load-bearing defense.
    shutil.copytree(source, target, symlinks=False)
    _record_install(manifest)
    return Plugin(manifest=manifest, path=target)


def uninstall_plugin(name: str) -> None:
    target = PLUGINS_DIR / name
    if target.exists() and target.is_dir():
        shutil.rmtree(target)
    _record_uninstall(name)


def _load_index() -> dict:
    if not INSTALLED_INDEX.exists():
        return {}
    try:
        data = json.loads(INSTALLED_INDEX.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_index(data: dict) -> None:
    INSTALLED_INDEX.parent.mkdir(parents=True, exist_ok=True)
    tmp = INSTALLED_INDEX.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    tmp.replace(INSTALLED_INDEX)


def _record_install(m: PluginManifest) -> None:
    data = _load_index()
    plugins = data.setdefault("plugins", {})
    from datetime import datetime, timezone
    plugins[m.name] = {
        "version": m.version,
        "installed_at": datetime.now(timezone.utc).isoformat(),
        "enabled": m.enabled,
    }
    _save_index(data)


def _record_uninstall(name: str) -> None:
    data = _load_index()
    plugins = data.setdefault("plugins", {})
    plugins.pop(name, None)
    _save_index(data)


# ---- Component loaders (called by the system prompt + slash router) ----

def load_plugin_skills(workdir: Path) -> list:
    """Yield Skill objects from every enabled plugin that ships skills.

    Returns the same Skill dataclass as agent/skills.py so we can merge
    plugin skills into the auto-invoke pool.
    """
    from prometheus.agent.skills import _load_skill_file
    out: list = []
    for plugin in discover_installed():
        if not plugin.manifest.enabled:
            continue
        if not plugin.manifest.components.get("skills"):
            continue
        skills_dir = plugin.path / "skills"
        if not skills_dir.exists():
            continue
        for md in sorted(skills_dir.glob("*.md")):
            skill = _load_skill_file(md)
            if skill is not None:
                out.append(skill)
    return out


def load_plugin_commands(app: "Any", router: "Any") -> int:
    """Register slash commands from every enabled plugin. Returns count."""
    from pathlib import Path as _P
    n = 0
    for plugin in discover_installed():
        if not plugin.manifest.enabled:
            continue
        if not plugin.manifest.components.get("commands"):
            continue
        cmd_dir = plugin.path / "commands"
        if not cmd_dir.exists() or not cmd_dir.is_dir():
            continue
        for path in sorted(cmd_dir.glob("*.md")):
            try:
                body = path.read_text(encoding="utf-8")
            except Exception:
                continue
            name = path.stem.lower().replace(" ", "-")
            if not name or name.startswith("_"):
                continue
            summary = "custom"
            for line in body.splitlines():
                line = line.strip()
                if not line:
                    continue
                if line.startswith("#"):
                    summary = line.lstrip("# ").strip()[:60]
                else:
                    summary = line[:60]
                break
            # Closure capturing the prompt template.
            def make_fn(template: str, _name: str):
                async def _custom(_app, arg: str) -> None:
                    prompt = (
                        template.replace("{{args}}", arg)
                                .replace("{{ARGS}}", arg)
                    )
                    if "{{args}}" not in template and "{{ARGS}}" not in template and arg:
                        prompt = prompt.rstrip() + "\n\n" + arg
                    await _app._run_agent(prompt)
                _custom.__name__ = f"cmd_plugin_{plugin.manifest.name}_{_name}"
                return _custom
            try:
                router.add(name, summary, make_fn(body, name), "plugin")
                n += 1
            except Exception:
                continue
    return n
