"""Round 150: pipeline + tool-pool visualization.

Two surfaces:

  * 9-step turn-execution pipeline (`/pipeline`):
    Settings → State → Context → Pre-Model Shapers → Model →
    Dispatch → Permission → Execution → Stop

  * 5-step tool-pool assembly (`/tool-pool`):
    Base → Mode → Deny → MCP → Dedup

Both expose the catalogue + a renderer plus a tracker the
host can populate during a real turn so timing data shows
up alongside the catalogue.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional


# ---------- pipeline catalogue ----------


@dataclass
class PipelineStage:
    name: str
    description: str
    typical_modules: tuple[str, ...]


PIPELINE_STAGES: tuple[PipelineStage, ...] = (
    PipelineStage(
        name="Settings",
        description="Resolve env + settings.json + project overlay",
        typical_modules=(
            "prometheus.config", "prometheus.settings_v139",
            "prometheus.env_flags",
        ),
    ),
    PipelineStage(
        name="State",
        description="Load session messages, todos, snapshots",
        typical_modules=(
            "prometheus.memory.session", "prometheus.agent.loop",
        ),
    ),
    PipelineStage(
        name="Context",
        description="Build active context: charter, aptitudes, rules",
        typical_modules=(
            "prometheus.agent.system",
            "prometheus.agent.aptitudes",
            "prometheus.agent.rules_engine",
        ),
    ),
    PipelineStage(
        name="Pre-Model Shapers",
        description="Apply prompt-framework keywords + ghost mode",
        typical_modules=(
            "prometheus.prompt_interceptor",
            "prometheus.ghost_mode",
            "prometheus.fast_mode",
        ),
    ),
    PipelineStage(
        name="Model",
        description="Send to provider, stream response",
        typical_modules=(
            "prometheus.provider.openrouter",
            "prometheus.model_tiers",
        ),
    ),
    PipelineStage(
        name="Dispatch",
        description="Parse tool calls, build tool pool",
        typical_modules=(
            "prometheus.tools.registry",
            "prometheus.agent.leak_sanitizer",
        ),
    ),
    PipelineStage(
        name="Permission",
        description="Sentinels → Overseer → user approval",
        typical_modules=(
            "prometheus.safety.sentinels",
            "prometheus.safety.overseer",
            "prometheus.tui_inline_approval",
        ),
    ),
    PipelineStage(
        name="Execution",
        description="Run tools, capture output, render receipt",
        typical_modules=(
            "prometheus.tools.shell",
            "prometheus.tools.files",
            "prometheus.tui_progress",
        ),
    ),
    PipelineStage(
        name="Stop",
        description="Compact, persist, emit final-message event",
        typical_modules=(
            "prometheus.context_collapse",
            "prometheus.cached_microcompact",
        ),
    ),
)


# ---------- tool-pool assembly ----------


@dataclass
class ToolPoolStep:
    name: str
    description: str


TOOL_POOL_STEPS: tuple[ToolPoolStep, ...] = (
    ToolPoolStep(
        name="Base",
        description="Tools from prometheus.tools.registry.build_default_registry",
    ),
    ToolPoolStep(
        name="Mode",
        description="Filter by permission mode + plan-mode read-only gate",
    ),
    ToolPoolStep(
        name="Deny",
        description="Apply --disallowedTools + sentinel deny rules",
    ),
    ToolPoolStep(
        name="MCP",
        description="Merge MCP-server-registered tools",
    ),
    ToolPoolStep(
        name="Dedup",
        description="Deduplicate name collisions; later sources win",
    ),
)


# ---------- per-stage timing ----------


@dataclass
class StageTrace:
    stage: str
    status: str = "idle"        # idle / processing / done / failed
    started_at: Optional[float] = None
    ended_at: Optional[float] = None
    detail: str = ""

    @property
    def duration_ms(self) -> float:
        if self.started_at is None:
            return 0.0
        end = self.ended_at if self.ended_at is not None else time.monotonic()
        return (end - self.started_at) * 1000.0

    @property
    def color(self) -> str:
        return {
            "idle":       "grey",
            "processing": "amber",
            "done":       "green",
            "failed":     "red",
        }.get(self.status, "grey")


@dataclass
class PipelineTracker:
    """Round 150: optional tracker the agent loop populates as
    it walks the 9 stages. Renderer reads it for timing."""
    stages: dict[str, StageTrace] = field(default_factory=dict)

    def begin(self, stage: str, *, detail: str = "") -> None:
        t = self.stages.setdefault(stage, StageTrace(stage=stage))
        t.status = "processing"
        t.started_at = time.monotonic()
        if detail:
            t.detail = detail

    def end(self, stage: str, *, ok: bool = True, detail: str = "") -> None:
        t = self.stages.get(stage)
        if t is None:
            return
        t.ended_at = time.monotonic()
        t.status = "done" if ok else "failed"
        if detail:
            t.detail = detail


# ---------- tool-pool tracker ----------


@dataclass
class ToolPoolFilterTrace:
    step: str
    tools_in: int
    tools_out: int
    dropped: list[str] = field(default_factory=list)

    @property
    def dropped_count(self) -> int:
        return self.tools_in - self.tools_out


@dataclass
class ToolPoolTracker:
    traces: list[ToolPoolFilterTrace] = field(default_factory=list)

    def record(
        self,
        *,
        step: str,
        tools_in: list[str],
        tools_out: list[str],
    ) -> ToolPoolFilterTrace:
        dropped = [t for t in tools_in if t not in tools_out]
        trace = ToolPoolFilterTrace(
            step=step,
            tools_in=len(tools_in),
            tools_out=len(tools_out),
            dropped=dropped,
        )
        self.traces.append(trace)
        return trace


# ---------- renderers ----------


_GLYPH_BY_COLOR = {
    "green": "✓",
    "amber": "◐",
    "grey":  "·",
    "red":   "✗",
}


def render_pipeline(
    *, tracker: Optional[PipelineTracker] = None,
) -> str:
    lines = ["9-step turn pipeline:"]
    for stage in PIPELINE_STAGES:
        trace = (
            tracker.stages.get(stage.name)
            if tracker else None
        )
        glyph = _GLYPH_BY_COLOR[
            trace.color if trace else "grey"
        ]
        timing = (
            f"  {trace.duration_ms:6.1f}ms" if trace
            and trace.started_at is not None else "         "
        )
        line = f"  {glyph} {stage.name:18s}{timing}  {stage.description}"
        if trace and trace.detail:
            line += f"  · {trace.detail[:50]}"
        lines.append(line)
        if trace and trace.color == "amber":
            lines.append("    └ in progress")
    return "\n".join(lines)


def render_tool_pool(
    *, tracker: Optional[ToolPoolTracker] = None,
) -> str:
    lines = ["5-step tool-pool assembly:"]
    for step in TOOL_POOL_STEPS:
        trace = None
        if tracker is not None:
            for t in tracker.traces:
                if t.step == step.name:
                    trace = t
                    break
        if trace is None:
            lines.append(
                f"  · {step.name:8s}                 {step.description}"
            )
            continue
        glyph = "✓" if trace.dropped_count == 0 else "✂"
        lines.append(
            f"  {glyph} {step.name:8s}  "
            f"{trace.tools_in:>3} → {trace.tools_out:>3}"
            f"  ({trace.dropped_count} dropped)"
            f"  {step.description}"
        )
        if trace.dropped:
            sample = ", ".join(trace.dropped[:5])
            more = (
                f" +{len(trace.dropped) - 5} more"
                if len(trace.dropped) > 5 else ""
            )
            lines.append(f"      dropped: {sample}{more}")
    return "\n".join(lines)
