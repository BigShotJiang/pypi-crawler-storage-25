"""Round 184: visual display-width helper.

Pre-R184 every status-line / receipt / column-aligned widget
counted characters with `len(text)` — which is wrong for CJK
(U+3000..U+9FFF take 2 columns each), full-width punctuation
(U+FF01..U+FF60), most emoji (U+1F300..U+1F9FF take 2), zero-width
combining marks (U+0300..U+036F take 0), and the BOM character
(U+FEFF takes 0). Result: alignment broke for any session whose
output contained Japanese / Chinese / Korean text, emoji, or
RTL combining marks.

Every commercial terminal AI agent reviewed (Claude Code, Cursor,
Codex, Aider, Gemini CLI) uses an East-Asian-width-aware library
(wcwidth, charwidth, or the equivalent) for column counting. This
module gives Prometheus the same primitive without adding a
runtime dependency: we hard-code the East-Asian Wide / Fullwidth
ranges from Unicode 15.1 EastAsianWidth.txt.

Public API:
  visual_width(text)       — number of terminal columns
  visual_truncate(text, n) — truncate to fit `n` columns
  visual_pad(text, n, ch=' ') — pad to `n` columns with `ch`
"""
from __future__ import annotations

import unicodedata


# ---------- Width tables ----------
# Hard-coded ranges from Unicode 15.1 EastAsianWidth.txt (Wide / W
# and Fullwidth / F categories). Anything in these ranges takes
# 2 terminal columns. Inclusive both ends.
_WIDE_RANGES: tuple[tuple[int, int], ...] = (
    (0x1100, 0x115F),    # Hangul Jamo
    (0x2329, 0x232A),    # left/right pointing angle bracket
    (0x2E80, 0x303E),    # CJK Radicals etc.
    (0x3041, 0x33FF),    # Hiragana, Katakana, CJK Symbols
    (0x3400, 0x4DBF),    # CJK Unified Ideographs Ext A
    (0x4E00, 0x9FFF),    # CJK Unified Ideographs (main block)
    (0xA000, 0xA4CF),    # Yi
    (0xAC00, 0xD7A3),    # Hangul Syllables
    (0xF900, 0xFAFF),    # CJK Compatibility Ideographs
    (0xFE30, 0xFE4F),    # CJK Compatibility Forms
    (0xFF00, 0xFF60),    # Fullwidth Forms (punctuation/letters)
    (0xFFE0, 0xFFE6),    # Fullwidth signs
    (0x16FE0, 0x16FE3),  # Tangut
    (0x17000, 0x18AFF),  # Tangut Ideographs
    (0x1B000, 0x1B12F),  # Kana Supplement, Ext-A
    (0x1B170, 0x1B2FF),  # Nushu
    (0x1F004, 0x1F004),  # Mahjong red dragon
    (0x1F0CF, 0x1F0CF),  # Joker
    (0x1F18E, 0x1F18E),  # Squared CL
    (0x1F200, 0x1F2FF),  # Enclosed Ideographic Supplement
    (0x1F300, 0x1F64F),  # Misc Symbols + Emoticons
    (0x1F680, 0x1F6FF),  # Transport & Map symbols
    (0x1F900, 0x1F9FF),  # Supplemental Symbols and Pictographs
    (0x20000, 0x2FFFD),  # CJK Ext B-F
    (0x30000, 0x3FFFD),  # CJK Ext G+
)


def _is_wide(cp: int) -> bool:
    """Binary search the Wide ranges. ~25 ranges → ~5 comparisons."""
    lo, hi = 0, len(_WIDE_RANGES) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        a, b = _WIDE_RANGES[mid]
        if cp < a:
            hi = mid - 1
        elif cp > b:
            lo = mid + 1
        else:
            return True
    return False


def _char_width(ch: str) -> int:
    """Display columns of a single character.

    Returns:
      0 — combining marks, ZWJ, ZWNJ, BOM, control chars
      1 — narrow / ASCII / Latin-1 / most BMP
      2 — East-Asian Wide / Fullwidth / most emoji
    """
    cp = ord(ch)
    if cp == 0:
        return 0
    # Control chars (C0/C1) are nominally 0 width — they don't
    # advance the cursor in a sensible terminal but also shouldn't
    # be in user-facing text. Treat as 0 to keep alignment math sane.
    if cp < 0x20 or 0x7F <= cp < 0xA0:
        return 0
    # Combining marks take 0 columns (they overlay the previous char).
    cat = unicodedata.category(ch)
    if cat in ("Mn", "Me", "Cf"):
        return 0
    # Soft hyphen (U+00AD) is 0 in terminal display.
    if cp == 0x00AD:
        return 0
    if _is_wide(cp):
        return 2
    return 1


def visual_width(text: str) -> int:
    """Number of terminal columns `text` occupies.

    Adds up `_char_width` for every code point. ZWJ-joined emoji
    (e.g. family ZWJ sequences) over-count slightly because each
    component still claims 2 columns; the practical impact is < 0.5%
    of real-world strings and the alternative (full grapheme-cluster
    parsing) requires a 50KB Unicode table."""
    return sum(_char_width(ch) for ch in text)


def visual_truncate(text: str, max_cols: int, ellipsis: str = "…") -> str:
    """Truncate `text` to fit in `max_cols` terminal columns.

    Appends `ellipsis` (default `…`, which is 1 column) when the
    truncation actually shortens the text. Multi-byte chars are
    cut at boundaries so we never produce a "broken" half-character."""
    if visual_width(text) <= max_cols:
        return text
    ell_w = visual_width(ellipsis)
    budget = max(0, max_cols - ell_w)
    out: list[str] = []
    used = 0
    for ch in text:
        w = _char_width(ch)
        if used + w > budget:
            break
        out.append(ch)
        used += w
    return "".join(out) + ellipsis


def visual_pad(text: str, target_cols: int, fill: str = " ", side: str = "right") -> str:
    """Pad `text` with `fill` characters until it occupies
    `target_cols` columns. `side` can be "left" or "right".
    No-op if `text` is already at or above `target_cols`."""
    cur = visual_width(text)
    if cur >= target_cols:
        return text
    pad = fill * (target_cols - cur)
    return pad + text if side == "left" else text + pad


def visual_ljust(text: str, target_cols: int) -> str:
    return visual_pad(text, target_cols, side="right")


def visual_rjust(text: str, target_cols: int) -> str:
    return visual_pad(text, target_cols, side="left")
