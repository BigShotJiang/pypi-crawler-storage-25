"""Round 144-final: connector text — bridging summaries.

After compaction or a mode switch, the chat log inserts a
one-line bridge that names what was happening before, so the
user (and the model) keep continuity.

  ⟐ continuing from auth module refactor — branch fix-auth-race-condition

Pure data-layer. The host calls `build_connector(...)` after
each compaction event.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Optional


# ---------- glyph + helpers ----------


CONNECTOR_GLYPH = "⟐"


def _last_user_subject(messages: list[dict[str, Any]]) -> str:
    """Round 144-final: pull the most recent user message and
    truncate it for the bridge. Empty when no user message."""
    for m in reversed(messages or []):
        if not isinstance(m, dict):
            continue
        if m.get("role") != "user":
            continue
        body = m.get("content")
        if isinstance(body, list):
            body = " ".join(
                str(b.get("text", "")) if isinstance(b, dict)
                else str(b) for b in body
            )
        text = str(body or "").strip().replace("\n", " ")
        if text:
            return text[:60] + ("…" if len(text) > 60 else "")
    return ""


_BRANCH_RX = re.compile(r"^[A-Za-z0-9._/\-]{1,80}$")


def _branch_clause(branch: str) -> str:
    branch = (branch or "").strip()
    if not branch:
        return ""
    if not _BRANCH_RX.match(branch):
        return ""
    return f" — branch {branch}"


# ---------- builders ----------


@dataclass
class ConnectorContext:
    """Round 144-final: optional metadata the host can supply
    so the bridge text reads more concretely."""
    branch: str = ""
    files_modified_recent: int = 0


def build_connector(
    *,
    reason: str,
    messages: Optional[list[dict[str, Any]]] = None,
    context: Optional[ConnectorContext] = None,
) -> str:
    """Round 144-final: build the bridge string.

    `reason` is one of:
      `compaction` / `mode-switch` / `resume` / `wake`
    """
    subject = _last_user_subject(messages or [])
    branch = _branch_clause(context.branch if context else "")
    if reason == "compaction":
        head = "continuing from"
    elif reason == "mode-switch":
        head = "mode switched, picking up"
    elif reason == "resume":
        head = "resumed:"
    elif reason == "wake":
        head = "back from sleep, on"
    else:
        head = reason.replace("-", " ") + ":"
    if subject:
        body = f"{head} {subject}"
    elif context and context.files_modified_recent:
        body = (
            f"{head} {context.files_modified_recent} "
            "recent file edit(s)"
        )
    else:
        body = head
    return f"{CONNECTOR_GLYPH} {body.strip()}{branch}"
