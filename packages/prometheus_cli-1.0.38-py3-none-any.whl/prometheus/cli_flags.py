"""Round 133: Advanced CLI flag handling.

Centralizes the application logic for the new flags wired into
`headless.build_parser()`:

  * `--session-id <uuid>`        — reuse a specific session id
  * `--no-session-persistence`   — skip writing this run to SQLite
  * `--system-prompt <text>`     — replace the built-in system prompt
  * `--system-prompt-file <p>`   — read prompt from a file
  * `--tools <list>`             — allowlist of tool names
  * `--json-schema <path>`       — validate the final reply against schema
  * `--verbose` / `--debug`      — log verbosity controls
  * `--debug-file <path>`        — write debug logs to file
  * `--mcp-config <path>`        — supply an MCP server config

Each function is small, pure, and individually testable. The
host wires them up in headless.run_headless and the Textual
launch path.
"""
from __future__ import annotations

import json
import os
import re
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


# ---------- --session-id ----------


_UUID_RX = re.compile(
    r"^[0-9a-fA-F]{8}-?[0-9a-fA-F]{4}-?"
    r"[0-9a-fA-F]{4}-?[0-9a-fA-F]{4}-?"
    r"[0-9a-fA-F]{12}$"
)


def validate_session_id(raw: str) -> Optional[str]:
    """Round 133: accept any of the standard UUID forms; reject
    anything that doesn't look like a UUID. Returns the
    canonical hyphenated string, or None on rejection."""
    s = (raw or "").strip()
    if not s:
        return None
    if not _UUID_RX.match(s):
        return None
    try:
        return str(uuid.UUID(s))
    except ValueError:
        return None


# ---------- --no-session-persistence ----------


def session_persistence_enabled(*, flag: bool = False) -> bool:
    """Round 133: returns False when persistence is disabled by
    either the CLI flag or the env override."""
    if flag:
        return False
    return os.environ.get(
        "PROMETHEUS_NO_SESSION_PERSISTENCE", "",
    ).strip().lower() not in ("1", "true", "yes")


# ---------- --system-prompt(-file) ----------


@dataclass
class SystemPromptOverride:
    """Round 133: the chosen replacement system prompt + where
    it came from."""
    text: str
    source: str        # `inline` / `file` / `none`


def resolve_system_prompt(
    *,
    inline: Optional[str] = None,
    file_path: Optional[str] = None,
) -> SystemPromptOverride:
    """Inline wins over file. When both are empty, returns the
    `none` placeholder."""
    if inline and inline.strip():
        return SystemPromptOverride(text=inline, source="inline")
    if file_path and file_path.strip():
        try:
            txt = Path(file_path).expanduser().read_text(
                encoding="utf-8",
            )
            return SystemPromptOverride(text=txt, source="file")
        except OSError:
            return SystemPromptOverride(text="", source="none")
    return SystemPromptOverride(text="", source="none")


# ---------- --tools <list> ----------


def parse_tool_allowlist(raw: str) -> list[str]:
    """Round 133: split on commas, strip, drop empties. Order
    is preserved so deterministic dispatch order matches the
    user's input."""
    if not raw:
        return []
    parts = [p.strip() for p in raw.split(",")]
    return [p for p in parts if p]


def filter_registry_to_allowlist(
    registry: Any, allow: list[str],
) -> int:
    """Round 133: drop every tool not in the allowlist. Returns
    the count removed. Mutates `registry` in place — works on
    the round-existing ToolRegistry shape."""
    if not allow:
        return 0
    keep = set(allow)
    removed = 0
    # Two common shapes: `tools` dict, or `_tools` dict.
    bag = getattr(registry, "tools", None)
    if bag is None:
        bag = getattr(registry, "_tools", None)
    if not isinstance(bag, dict):
        return 0
    for name in list(bag.keys()):
        if name not in keep:
            try:
                del bag[name]
                removed += 1
            except KeyError:
                pass
    return removed


# ---------- --json-schema ----------


@dataclass
class JsonSchemaSpec:
    schema: dict[str, Any]
    path: Path


def load_json_schema(path: str) -> Optional[JsonSchemaSpec]:
    """Round 133: load + validate the schema is JSON. We don't
    fully validate the schema's correctness against the JSON
    Schema spec — that would pull in jsonschema as a hard dep.
    The runner uses the schema for shape checking only."""
    if not path:
        return None
    p = Path(path).expanduser()
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return None
        return JsonSchemaSpec(schema=data, path=p)
    except (OSError, json.JSONDecodeError):
        return None


def validate_against_schema(
    payload: dict[str, Any] | str,
    spec: JsonSchemaSpec,
) -> tuple[bool, str]:
    """Round 133: ultra-lite schema validator covering `type`,
    `required`, `properties`. Designed for the common case
    where headless callers want JSON-mode confirmation, not
    full Draft 7 semantics."""
    if isinstance(payload, str):
        try:
            payload = json.loads(payload)
        except json.JSONDecodeError as e:
            return (False, f"reply is not valid JSON: {e}")
    if not isinstance(payload, dict):
        return (False, "reply is not a JSON object")
    schema = spec.schema
    typ = schema.get("type")
    if typ and typ != "object":
        return (False, f"unsupported schema type {typ!r}")
    required = schema.get("required", []) or []
    for key in required:
        if key not in payload:
            return (False, f"missing required key {key!r}")
    props = schema.get("properties", {}) or {}
    for key, sub in props.items():
        if key not in payload:
            continue
        wanted = sub.get("type")
        if wanted is None:
            continue
        val = payload[key]
        ok = (
            (wanted == "string" and isinstance(val, str))
            or (wanted == "integer" and isinstance(val, int)
                and not isinstance(val, bool))
            or (wanted == "number"
                and isinstance(val, (int, float))
                and not isinstance(val, bool))
            or (wanted == "boolean" and isinstance(val, bool))
            or (wanted == "array" and isinstance(val, list))
            or (wanted == "object" and isinstance(val, dict))
            or (wanted == "null" and val is None)
        )
        if not ok:
            return (False, f"key {key!r} expected {wanted}")
    return (True, "")


# ---------- --verbose / --debug ----------


VALID_DEBUG_CATS = ("api", "tools", "subagents", "router", "all")


@dataclass
class DebugConfig:
    verbose: bool = False
    categories: list[str] = field(default_factory=list)
    file_path: Optional[Path] = None

    def enabled(self, cat: str) -> bool:
        return (
            "all" in self.categories
            or cat in self.categories
            or self.verbose
        )


def build_debug_config(
    *,
    verbose: bool = False,
    debug: str = "",
    debug_file: str = "",
) -> DebugConfig:
    cats: list[str] = []
    if debug:
        cats = [
            c.strip().lower() for c in debug.split(",") if c.strip()
        ]
        cats = [c for c in cats if c in VALID_DEBUG_CATS]
    file_path: Optional[Path] = None
    if debug_file:
        file_path = Path(debug_file).expanduser()
    return DebugConfig(
        verbose=verbose, categories=cats, file_path=file_path,
    )


# ---------- --mcp-config ----------


@dataclass
class McpConfig:
    """Parsed MCP server config — list of {name, command, args}
    entries. The host wires each entry into the existing
    round-100 MCP launcher."""
    servers: list[dict[str, Any]] = field(default_factory=list)
    path: Optional[Path] = None


def load_mcp_config(path: str) -> Optional[McpConfig]:
    """Round 133: read the MCP config JSON. Accepts the
    Claude-Code-compatible shape `{"mcpServers": {name: {...}}}`."""
    if not path:
        return None
    p = Path(path).expanduser()
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    servers_in = data.get("mcpServers") or data.get("servers") or {}
    if not isinstance(servers_in, dict):
        return None
    out: list[dict[str, Any]] = []
    for name, entry in servers_in.items():
        if not isinstance(entry, dict):
            continue
        cmd = entry.get("command", "")
        args = entry.get("args", []) or []
        env = entry.get("env", {}) or {}
        if not cmd:
            continue
        out.append({
            "name": str(name),
            "command": str(cmd),
            "args": [str(a) for a in args] if isinstance(args, list)
                    else [],
            "env": {str(k): str(v) for k, v in env.items()}
                   if isinstance(env, dict) else {},
        })
    return McpConfig(servers=out, path=p)
