"""Round 143: 9 additional settings keys.

  * thinkingEnabled               bool, default True
  * fastMode                      bool, default False
  * prStatusFooterEnabled         bool, default True
  * copyFullResponse              bool, default False
  * teammateMode                  str:  in-process|tmux|auto, default auto
  * teammateDefaultModel          str:  alias or full id
  * enableTokenUsageAttachment    bool, default False
  * skipFastModeOrgCheck          bool, default False
  * enhancedTelemetry             bool, default False
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional


_TRUTHY = ("1", "true", "yes", "on")


def _b(value: Any, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in _TRUTHY
    return default


def _s(value: Any, default: str) -> str:
    return (
        str(value).strip()
        if isinstance(value, str) and value.strip()
        else default
    )


VALID_TEAMMATE_MODES = ("in-process", "tmux", "auto")


def thinking_enabled(setting: Any = None) -> bool:
    return _b(setting, True)


def fast_mode_setting(setting: Any = None) -> bool:
    return _b(setting, False)


def pr_status_footer_enabled(setting: Any = None) -> bool:
    return _b(setting, True)


def copy_full_response(setting: Any = None) -> bool:
    """Round 143: when True, /copy-last copies the entire
    assistant response instead of the last code block."""
    return _b(setting, False)


def teammate_mode(setting: Any = None) -> str:
    v = _s(setting, "auto").lower()
    return v if v in VALID_TEAMMATE_MODES else "auto"


def teammate_default_model(setting: Any = None) -> str:
    """Round 143: defaults to empty so cohorts use the
    parent's model (round-135 fallback). Caller resolves
    aliases via `model_tiers.resolve_alias`."""
    if not isinstance(setting, str):
        return ""
    return setting.strip()


def enable_token_usage_attachment(setting: Any = None) -> bool:
    """Round 143: when on, every assistant turn appends a
    token-usage one-liner to the visible reply."""
    return _b(setting, False)


def skip_fast_mode_org_check(setting: Any = None) -> bool:
    """Round 143: bypass the org-policy check that gates fast
    mode in regulated environments. Default off."""
    return _b(setting, False)


def enhanced_telemetry(setting: Any = None) -> bool:
    """Round 143: opt-in extra telemetry. Default off — this
    is the *only* setting that ever flips telemetry on, and it
    is overridden by `PROMETHEUS_DISABLE_TELEMETRY=1`."""
    import os
    if os.environ.get(
        "PROMETHEUS_DISABLE_TELEMETRY", "",
    ).strip().lower() in _TRUTHY:
        return False
    if os.environ.get(
        "PROMETHEUS_DISABLE_NONESSENTIAL_TRAFFIC", "",
    ).strip().lower() in _TRUTHY:
        return False
    return _b(setting, False)


@dataclass
class V143Resolved:
    thinkingEnabled: bool
    fastMode: bool
    prStatusFooterEnabled: bool
    copyFullResponse: bool
    teammateMode: str
    teammateDefaultModel: str
    enableTokenUsageAttachment: bool
    skipFastModeOrgCheck: bool
    enhancedTelemetry: bool


def settings_v143_summary(settings: Any = None) -> V143Resolved:
    s = settings if isinstance(settings, dict) else {}
    return V143Resolved(
        thinkingEnabled=
            thinking_enabled(s.get("thinkingEnabled")),
        fastMode=fast_mode_setting(s.get("fastMode")),
        prStatusFooterEnabled=
            pr_status_footer_enabled(s.get("prStatusFooterEnabled")),
        copyFullResponse=
            copy_full_response(s.get("copyFullResponse")),
        teammateMode=teammate_mode(s.get("teammateMode")),
        teammateDefaultModel=
            teammate_default_model(s.get("teammateDefaultModel")),
        enableTokenUsageAttachment=
            enable_token_usage_attachment(
                s.get("enableTokenUsageAttachment"),
            ),
        skipFastModeOrgCheck=
            skip_fast_mode_org_check(
                s.get("skipFastModeOrgCheck"),
            ),
        enhancedTelemetry=
            enhanced_telemetry(s.get("enhancedTelemetry")),
    )
