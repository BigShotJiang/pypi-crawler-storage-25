"""Round 141: live tool-progress activity line.

During tool execution the activity rail shows:

    ✦ Running test suite · 12s · ↓1.5k tokens

  * the verb derives from the tool name (Bash → Running, Read
    → Reading, Glob → Searching, etc.)
  * the duration ticks every second
  * the token delta updates as streaming continues
  * for Bash, the command snippet replaces the verb tail

Pure data layer. The host's render loop ticks `update()` and
re-emits `render()` at the streaming flush cadence.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional


# ---------- per-tool labels ----------


_VERB_BY_TOOL: dict[str, str] = {
    "run_bash":          "Running",
    "read_file":         "Reading",
    "write_file":        "Writing",
    "edit_file":         "Updating",
    "multi_edit":        "Updating",
    "apply_patch":       "Patching",
    "glob_files":        "Searching",
    "search_code":       "Searching",
    "list_files":        "Listing",
    "web_fetch":         "Fetching",
    "web_search":        "Searching",
    "task":              "Dispatching",
    "todo_write":        "Tracking",
    "task_create":       "Tracking",
    "task_update":       "Tracking",
    "monitor":           "Monitoring",
    "computer_use":      "Acting",
    "discover_test_command": "Discovering",
}


# Round 164 / #4: past-tense pair for every present-tense verb above.
# When the activity rail flips from active to completed, the host
# uses past_verb_for(tool) instead of verb_for(tool) — so the line
# reads `⏺ Ran test suite · 45s` rather than the present-progressive
# `Running…`. Generic fallback is "Completed".
_PAST_VERB_BY_TOOL: dict[str, str] = {
    "run_bash":          "Ran",
    "read_file":         "Read",
    "write_file":        "Wrote",
    "edit_file":         "Updated",
    "multi_edit":        "Updated",
    "apply_patch":       "Patched",
    "glob_files":        "Searched",
    "search_code":       "Searched",
    "list_files":        "Listed",
    "web_fetch":         "Fetched",
    "web_search":        "Searched",
    "task":              "Dispatched",
    "todo_write":        "Tracked",
    "task_create":       "Tracked",
    "task_update":       "Tracked",
    "monitor":           "Monitored",
    "computer_use":      "Acted on",
    "discover_test_command": "Discovered",
}


def verb_for(tool: str) -> str:
    return _VERB_BY_TOOL.get(tool, "Working")


def past_verb_for(tool: str) -> str:
    """Round 164: past-tense verb for completed activity rail.

    Falls back to "Completed" when the tool isn't in the catalogue,
    matching Claude Code's spinner-completion behaviour."""
    return _PAST_VERB_BY_TOOL.get(tool, "Completed")


def past_verb_from_present(present: str) -> str:
    """Round 164: when a host uses a custom spinnerVerb (a string,
    not a tool name), fall back to a regex-based past-tense
    transform: `Running…` → `Ran…`, `Optimising` → `Optimised`,
    `Building` → `Built`. Pure suffix heuristics — won't get every
    verb right, but produces a plausible past tense for the common
    `-ing` shapes that DEFAULT_SPINNER_VERBS contains."""
    if not present:
        return "Completed"
    s = present.rstrip(" .…")
    # Hand-rolled irregular pairs first (these are common enough
    # in the catalogue that the suffix heuristic would mis-conjugate
    # them).
    irregular = {
        "Running": "Ran", "Building": "Built", "Writing": "Wrote",
        "Reading": "Read", "Finding": "Found", "Making": "Made",
        "Thinking": "Thought", "Choosing": "Chose", "Driving": "Drove",
        "Drawing": "Drew", "Diving": "Dove", "Flying": "Flew",
        "Hunting": "Hunted", "Spreading": "Spread", "Setting": "Set",
        "Splitting": "Split", "Cutting": "Cut", "Hitting": "Hit",
        "Putting": "Put", "Doing": "Did", "Going": "Went",
        "Seeing": "Saw", "Sending": "Sent", "Spending": "Spent",
        "Bringing": "Brought", "Buying": "Bought", "Catching": "Caught",
        "Coming": "Came", "Knowing": "Knew", "Leaving": "Left",
        "Meaning": "Meant", "Meeting": "Met", "Paying": "Paid",
        "Saying": "Said", "Selling": "Sold", "Sitting": "Sat",
        "Sleeping": "Slept", "Standing": "Stood", "Swimming": "Swam",
        "Taking": "Took", "Teaching": "Taught", "Telling": "Told",
        "Thinking": "Thought", "Understanding": "Understood",
        "Winning": "Won",
    }
    if s in irregular:
        return irregular[s]
    if not s.endswith("ing"):
        return "Completed"
    stem = s[:-3]
    # Doubled-consonant case: "Running" → stem "Runn" → "Ran"
    # is irregular (handled above). For regular verbs like
    # "Optimising" → stem "Optimis" → past "Optimised", "Calibrating"
    # → "Calibrated", we add `ed`. If stem ends in `e` (pronounced
    # silent: "Coding" → stem "Cod" but actual verb is "Code"), we
    # restore the `e`. The catalogue has both shapes — `Coding` and
    # `Calibrating` — so we sniff the consonant pattern.
    if stem.endswith("at") or stem.endswith("ot") or stem.endswith("ut"):
        # "Calibrat" → "Calibrated"
        return stem + "ed"
    if len(stem) >= 2 and stem[-1] not in "aeiouy" and stem[-2] not in "aeiou":
        # Probably needs an `e` restored: "Cod" → "Coded"
        return stem + "ed"
    return stem + "ed"


# Round 149: interpreter binaries whose full paths swamp the
# activity rail. When a bash command starts with one of these,
# the path prefix is stripped down to the basename — so
# `/opt/conda/bin/python -m pip install x` becomes
# `python -m pip install x`. The user already knows which
# python they're running.
_INTERPRETER_BINS = (
    "python", "python3", "python.exe",
    "node", "node.exe",
    "ruby", "ruby.exe",
    "perl", "perl.exe",
    "pwsh", "pwsh.exe", "powershell.exe",
    "bash", "sh", "zsh",
)


def _strip_interpreter_prefix(cmd: str) -> str:
    """Round 149: when the command begins with a quoted-or-
    unquoted absolute path to a known interpreter binary,
    rewrite to the basename. Preserves the rest of the
    command verbatim."""
    if not cmd:
        return cmd
    # Handle quoted absolute paths first.
    import re as _re
    quoted = _re.match(r'^"([^"]+)"\s+(.*)$', cmd)
    if quoted:
        head_path, rest = quoted.group(1), quoted.group(2)
    else:
        # Unquoted leading token — split on the first space.
        space = cmd.find(" ")
        if space < 0:
            head_path, rest = cmd, ""
        else:
            head_path, rest = cmd[:space], cmd[space + 1:]
    # Only strip when the head looks like an absolute path
    # AND its basename is in our interpreter list.
    is_abs = (
        head_path.startswith("/")
        or (len(head_path) > 2 and head_path[1] == ":")
    )
    if not is_abs:
        return cmd
    base = head_path.replace("\\", "/").rsplit("/", 1)[-1]
    if base.lower() not in _INTERPRETER_BINS:
        return cmd
    return f"{base} {rest}".strip() if rest else base


def detail_for(tool: str, args: Optional[dict]) -> str:
    """Round 141 + 149: short description appended after the
    verb. Bash → command snippet; file ops → path; otherwise
    the most-distinguishing argument.

    Round 149 fix: when bash invokes a Python interpreter via
    its full path (`/usr/bin/python3`, `C:\\…\\python.exe`),
    strip the leading path so the activity rail shows the
    *meaningful* part (`-m pip install requests`) instead of
    burning real-estate on `/usr/bin/python3 -m pip ...`."""
    args = args or {}
    if tool == "run_bash":
        cmd = str(args.get("command") or "").strip()
        if cmd:
            head = cmd.splitlines()[0]
            head = _strip_interpreter_prefix(head)
            return head[:60] + ("…" if len(head) > 60 else "")
        return "shell"
    if tool in (
        "read_file", "write_file", "edit_file",
        "multi_edit", "apply_patch",
    ):
        path = (
            args.get("path")
            or args.get("file")
            or args.get("file_path")
            or ""
        )
        if path:
            return str(path)
    if tool in ("glob_files", "search_code"):
        pat = args.get("pattern") or args.get("query") or ""
        if pat:
            return str(pat)[:60]
    if tool == "web_fetch":
        url = args.get("url") or ""
        if url:
            return str(url)
    if tool == "web_search":
        q = args.get("query") or ""
        if q:
            return str(q)[:60]
    if tool == "task":
        st = args.get("subagent_type") or "agent"
        prompt = (args.get("prompt") or "")[:40]
        return f"{st} · {prompt}…" if prompt else str(st)
    return ""


# ---------- progress state ----------


# ---------- Round 167: tool-call state enum ----------


from enum import Enum


class ToolCallState(str, Enum):
    """Round 167: explicit lifecycle states for a chat-log tool
    call. The Round-141 activity rail tracks this implicitly
    (tool field empty → no call; tool set + finished=False →
    in_progress; finished=True → done). This enum makes the
    contract explicit so renderers / tests can switch on it
    without inspecting raw fields.

    Mirrors Claude Code's documented per-call states. The cohort
    cards already use SubAgentStatus for the same purpose at the
    cohort level — this is the chat-log analogue.
    """
    QUEUED = "queued"
    """The model emitted the tool call; permission gate hasn't
    cleared yet (or the tool is waiting for an earlier tool to
    finish in the round-141 serial-write queue)."""
    IN_PROGRESS = "in_progress"
    """Tool body is executing; activity rail shows
    `verb_for(tool)`."""
    COMPLETED = "completed"
    """Tool returned without error. Activity rail shows the
    round-164 past-tense verb on the receipt."""
    ERROR = "error"
    """Tool returned `error=True`. Receipt is rendered with the
    round-39 error styling."""


def state_for_progress(p: "ToolProgress") -> ToolCallState:
    """Map a `ToolProgress` instance to its `ToolCallState`. Used
    by hosts that want to switch on the explicit state without
    duplicating the field-inspection logic."""
    if not p.tool:
        return ToolCallState.QUEUED
    if p.finished:
        return ToolCallState.COMPLETED
    return ToolCallState.IN_PROGRESS


@dataclass
class ToolProgress:
    """Round 141 / 165: live state for the activity rail.

    Round 165 / B1 adds an explicit `finishing` phase. Claude Code's
    active_label state machine has three discrete phases:

      1. planning        — model is choosing a tool (no tool active)
      2. tool execution  — a tool is running; verb is tool-specific
      3. finishing       — tool returned, model is generating its
                           final reply ("Finalizing…")

    The host transitions through them via `start()` / `finish()` /
    `transition_to_finishing()`. Phase is exposed as a property so
    the renderer can pick the right verb without inspecting the
    other fields.
    """
    tool: str = ""
    args: dict = field(default_factory=dict)
    started_at: Optional[float] = None
    tokens_delta: int = 0
    last_render_at: float = 0.0
    finished: bool = False
    # Round 165 / B1: finishing-phase state. When True, the renderer
    # emits `✦ Finalizing…` (or `✦ <past-verb> · finalizing…` if a
    # tool just finished) instead of either the live or the finished
    # form. `last_tool` carries the past-verb context so the line
    # reads `Wrote utils.py · finalizing…`. Set by
    # `transition_to_finishing()`; cleared by `start()`.
    finalizing: bool = False
    last_tool: str = ""

    def start(
        self,
        *, tool: str, args: Optional[dict] = None,
        now: Optional[float] = None,
    ) -> None:
        self.tool = tool
        self.args = dict(args) if args else {}
        self.started_at = now if now is not None else time.monotonic()
        self.tokens_delta = 0
        self.finished = False
        # Round 165: a new tool starting clears finalizing.
        self.finalizing = False

    def update_tokens(self, delta: int) -> None:
        if delta > 0:
            self.tokens_delta += delta

    def elapsed_seconds(
        self, *, now: Optional[float] = None,
    ) -> int:
        if self.started_at is None:
            return 0
        t = now if now is not None else time.monotonic()
        return max(0, int(t - self.started_at))

    def finish(self) -> None:
        self.finished = True

    def transition_to_finishing(
        self, *, last_tool: str = "", now: Optional[float] = None,
    ) -> None:
        """Round 165 / B1: flip the activity rail into the
        finishing phase. Called by the agent loop when a tool
        returns and the model resumes text generation. `last_tool`
        is the tool that just exited; the renderer uses its
        past-tense verb as the prefix (`Wrote utils.py ·
        finalizing…`)."""
        self.tool = ""           # no live tool
        self.args = {}
        self.finished = False
        self.finalizing = True
        self.last_tool = last_tool or self.last_tool
        # Reset the timer so finalizing has its own elapsed clock.
        self.started_at = now if now is not None else time.monotonic()

    @property
    def phase(self) -> str:
        """Round 165 / B1: 'planning' | 'tool' | 'finishing'."""
        if self.finalizing:
            return "finishing"
        if self.tool:
            return "tool"
        return "planning"


def _format_duration(seconds: int) -> str:
    if seconds < 60:
        return f"{seconds}s"
    m, s = divmod(seconds, 60)
    if m < 60:
        return f"{m}m {s}s"
    h, m = divmod(m, 60)
    return f"{h}h {m}m"


def _format_tokens(n: int) -> str:
    if n < 1000:
        return f"{n}"
    if n < 1_000_000:
        return f"{n / 1000:.1f}k".replace(".0k", "k")
    return f"{n / 1_000_000:.1f}M".replace(".0M", "M")


# Round 172: how many seconds a tool must be running before the
# `esc to interrupt` affordance is appended to the activity rail.
# Below this floor the tool is too short-lived for the hint to be
# useful — instant tools never show it. Above this floor the user
# is reading the rail and wants to know they can stop a runaway
# command. Matches Claude Code's observed behavior.
ESC_INTERRUPT_HINT_THRESHOLD_S: float = 3.0


def render_progress(
    p: ToolProgress, *, now: Optional[float] = None,
    show_interrupt_hint: bool = True,
) -> str:
    """Round 141 / 165 / 172: build the activity-rail line.

    Three render shapes by phase:
      - tool active:   `✦ Running pytest -q · 4s · esc to interrupt`
      - finishing:     `✦ Finalizing… · 1s`
        OR (if a tool just exited):
                      `✦ Wrote utils.py · finalizing… · 1s`
      - idle / done:   `` (empty)

    Round 172: the `esc to interrupt` affordance is appended to
    active-tool renders once `elapsed >= ESC_INTERRUPT_HINT_THRESHOLD_S`
    so users know the running step can be cancelled. Pass
    `show_interrupt_hint=False` to suppress.
    """
    # Round 165 / B1: finishing phase has its own render.
    if p.finalizing and not p.finished:
        elapsed = p.elapsed_seconds(now=now)
        if p.last_tool:
            past = past_verb_for(p.last_tool)
            # Pull a brief detail from the last tool's args if the
            # caller stuffed them on `last_args` — but our state
            # machine clears `args` in transition_to_finishing(), so
            # we'll just surface the past verb + finalizing… cue.
            body = f"{past} · finalizing…"
        else:
            body = "Finalizing…"
        parts: list[str] = [f"✦ {body}", _format_duration(elapsed)]
        if p.tokens_delta > 0:
            parts.append(f"↓{_format_tokens(p.tokens_delta)} tokens")
        return " · ".join(parts)
    if not p.tool or p.finished:
        return ""
    verb = verb_for(p.tool)
    detail = detail_for(p.tool, p.args)
    body = f"{verb} {detail}".strip()
    elapsed = p.elapsed_seconds(now=now)
    parts = [f"✦ {body}"]
    parts.append(_format_duration(elapsed))
    if p.tokens_delta > 0:
        parts.append(f"↓{_format_tokens(p.tokens_delta)} tokens")
    if show_interrupt_hint and elapsed >= ESC_INTERRUPT_HINT_THRESHOLD_S:
        parts.append("esc to interrupt")
    return " · ".join(parts)


# ---------- Round 168 / A4: windowed message rendering ----------


@dataclass
class WindowedView:
    """Round 168 / A4: only-paint-the-visible-slice contract.

    For long sessions (10K+ messages) we should never iterate the
    full transcript on a render tick. The host queries
    `visible_indices(scroll_top, viewport_height)` and paints
    only those indices. The static-transcript region (round 166)
    is still cached — `WindowedView` is the layer above that
    decides which cached lines actually go to the screen this
    frame.

    Pure data: no Textual import. The host wires this against
    its own scroll-region bookkeeping.
    """
    total_messages: int = 0
    """The full transcript size."""
    average_line_height: int = 1
    """Approximate rows per message — used for hint math; the
    host is welcome to pass exact heights via `heights`."""

    def visible_indices(
        self, *, scroll_top: int, viewport_height: int,
        heights: Optional[list[int]] = None,
    ) -> tuple[int, int]:
        """Return the (start, end_exclusive) range of message
        indices the host should paint this frame.

        When `heights` is supplied (per-message exact line count),
        we walk it precisely. Otherwise we approximate using
        `average_line_height`. The viewport above + below the
        visible slice is guaranteed to be cached static (see
        round 166 RenderLayout).
        """
        if self.total_messages <= 0 or viewport_height <= 0:
            return (0, 0)
        if heights is None:
            avg = max(1, self.average_line_height)
            start = max(0, scroll_top // avg)
            end = min(self.total_messages, start + (viewport_height // avg) + 1)
            return (start, end)
        # Precise walk through actual heights.
        cursor = 0
        start = 0
        while start < len(heights) and cursor + heights[start] <= scroll_top:
            cursor += heights[start]
            start += 1
        end = start
        rows = 0
        while end < len(heights) and rows < viewport_height:
            rows += heights[end]
            end += 1
        return (start, min(self.total_messages, end))

    def is_visible(
        self, idx: int, *,
        scroll_top: int, viewport_height: int,
        heights: Optional[list[int]] = None,
    ) -> bool:
        s, e = self.visible_indices(
            scroll_top=scroll_top, viewport_height=viewport_height,
            heights=heights,
        )
        return s <= idx < e


# ---------- Round 168 / A10: risk-based receipt styling ----------


# Risk tier maps tool name → visual class. The actual ANSI styling
# (color, bold, underline) is the renderer's job; this layer just
# names the tier so callers can pick a style consistently.
_RISK_BY_TOOL: dict[str, str] = {
    # Read-only / safe (cyan / dim by convention).
    "read_file":         "read_only",
    "list_files":        "read_only",
    "glob_files":        "read_only",
    "search_code":       "read_only",
    "web_fetch":         "read_only",
    "web_search":        "read_only",
    "todo_read":         "read_only",
    "test_discovery":    "read_only",
    # Write — modifies the workspace (amber / ink by convention).
    "write_file":        "write",
    "edit_file":         "write",
    "multi_edit":        "write",
    "apply_patch":       "write",
    "todo_write":        "write",
    # Exec — runs commands, may be destructive (orange / underline).
    "run_bash":          "exec",
    "computer_use":      "exec",
    # Subagent dispatch — parallel scope (purple / italic).
    "task":              "dispatch",
}


def risk_class_for_tool(tool_name: str) -> str:
    """Round 168 / A10: classify a tool by its visual-risk tier.

    Returns one of `'read_only' | 'write' | 'exec' | 'dispatch' |
    'unknown'`. Renderers map each tier to a style; tests assert
    the partition is correct."""
    return _RISK_BY_TOOL.get((tool_name or "").lower(), "unknown")


def is_destructive_command(command: str) -> bool:
    """Round 168 / A10: heuristic for whether a Bash command is
    in the destructive tier (rm -rf, drop database, force push).
    Used by the receipt renderer to bump from `exec` styling to
    a more prominent `destructive` treatment."""
    if not command: return False
    cmd = command.lower().strip()
    destructive_starts = (
        "rm -rf", "rm -fr", "rmdir /s",
        "git filter-repo", "git filter-branch", "git push --force",
        "git reset --hard", "drop database", "drop table",
        "mkfs", "dd if=", "shred",
        ":(){:", ":(){ :|", "yes |",
    )
    return any(cmd.startswith(p) or f" {p}" in cmd for p in destructive_starts)


# ---------- Round 168 / A22: OSC-8 hyperlink helper ----------


def osc8_link(target: str, display: Optional[str] = None) -> str:
    """Round 168: render an OSC-8 hyperlink. Modern terminals
    (iTerm2, Windows Terminal, Kitty, WezTerm, gnome-terminal)
    will surface this as a clickable link to `target`. Older
    terminals show the plain `display` text — the escape
    sequences are silently ignored.

    Used to make file paths in tool receipts clickable
    (open in the user's $EDITOR) without any other UI change.
    """
    if not target:
        return display or ""
    label = display or target
    # \x1b]8;;<target>\x1b\\<label>\x1b]8;;\x1b\\
    return f"\x1b]8;;{target}\x1b\\{label}\x1b]8;;\x1b\\"


# ---------- Round 169 / A7: thinking-spinner state labels ----------
#
# Claude Code's activity rail surfaces three escalating
# "thinking" labels as the model takes longer to produce its
# next token:
#
#   t < 5s          → "thinking"
#   5s ≤ t < 15s    → "still thinking"
#   15s ≤ t < 45s   → "thinking more"
#   45s ≤ t          → "almost done thinking"
#
# These are explicit user-visible cues that the model hasn't
# stalled — long-context turns can take a while, and silence
# would otherwise look like a hang. The thresholds are the
# observed Claude Code defaults; the function accepts overrides
# for tests.


# Thresholds in seconds: (lower-bound, label).
THINKING_LABEL_LADDER: tuple[tuple[float, str], ...] = (
    (0.0, "thinking"),
    (5.0, "still thinking"),
    (15.0, "thinking more"),
    (45.0, "almost done thinking"),
)


def thinking_label_for(elapsed_seconds: float) -> str:
    """Round 169 / A7: pick the right thinking-spinner label
    for `elapsed_seconds` since the model started generating.

    Returns one of the four labels in `THINKING_LABEL_LADDER`.
    Hosts use this when no tool is active and the model is
    streaming — the activity rail reads
    `✦ <thinking_label>… · <Xs>`.
    """
    s = max(0.0, float(elapsed_seconds or 0))
    label = "thinking"
    for threshold, lbl in THINKING_LABEL_LADDER:
        if s >= threshold:
            label = lbl
        else:
            break
    return label


# ---------- Round 169 / A8: spinner verb categories ----------
#
# Claude Code's 200+ spinner verbs fall into six rough
# categories: cooking / intellectual / movement / scientific /
# playful / musical. This taxonomy lets the host bias verb
# selection by context (e.g., the planner picks "intellectual"
# verbs while the file-edit pass picks "movement" verbs). The
# round-137 `DEFAULT_SPINNER_VERBS` list is shared; here we
# tag a representative subset of each category so callers can
# pick from the relevant pool without a separate list.


SPINNER_VERB_CATEGORIES: dict[str, tuple[str, ...]] = {
    "cooking": (
        "Baking", "Brewing", "Cooking", "Heating", "Stirring",
        "Whisking", "Simmering", "Braising", "Glazing",
    ),
    "intellectual": (
        "Analyzing", "Pondering", "Considering", "Examining",
        "Inferring", "Deliberating", "Reasoning", "Synthesizing",
        "Distilling", "Investigating", "Thinking",
    ),
    "movement": (
        "Climbing", "Diving", "Driving", "Flying", "Hunting",
        "Journeying", "Navigating", "Running", "Walking",
        "Marching", "Charging", "Soaring",
    ),
    "scientific": (
        "Calibrating", "Computing", "Measuring", "Observing",
        "Optimizing", "Probing", "Quantifying", "Sampling",
        "Testing", "Validating",
    ),
    "playful": (
        "Bouncing", "Dancing", "Doodling", "Frolicking",
        "Giggling", "Juggling", "Skipping", "Swooping",
    ),
    "musical": (
        "Composing", "Conducting", "Harmonizing", "Humming",
        "Improvising", "Orchestrating", "Tuning", "Riffing",
    ),
}


def categorize_spinner_verb(verb: str) -> str:
    """Round 169 / A8: classify a spinner verb into one of the
    six categories. Returns 'general' for unclassified verbs."""
    if not verb:
        return "general"
    for category, members in SPINNER_VERB_CATEGORIES.items():
        if verb in members:
            return category
    return "general"


def verbs_for_category(category: str) -> tuple[str, ...]:
    """Round 169 / A8: return the verbs in `category` (or empty
    tuple for unknown categories). Useful for hosts that want to
    bias verb selection by the current activity phase."""
    return SPINNER_VERB_CATEGORIES.get(category, ())


# ---------- Round 169 / A15: subagent tool-call attribution ----------


def render_subagent_tool_call(
    receipt_label: str,
    *,
    agent_type: str = "",
    indent: int = 4,
) -> str:
    """Round 169 / A15: format a tool-call line that ran *inside*
    a subagent.

    The chat-log shows these lines indented and tagged with the
    subagent type so it's visually distinct from the parent
    agent's own tool calls:

        ⏺ Read(loop.py)               ← parent's own tool call
            ⏺ Read(helper.py) [explore]   ← subagent's, indented + tagged

    `receipt_label` is whatever `Tool.receipt_label(args)`
    returned; we only add the indent and the trailing
    `[<agent_type>]` tag.
    """
    if not receipt_label:
        return ""
    pad = " " * max(0, indent)
    if agent_type:
        return f"{pad}{receipt_label} [{agent_type}]"
    return f"{pad}{receipt_label}"


# ---------- Round 168 / A22: spinner suppression for instant locals ----------


# Slash commands that resolve synchronously and never call the
# model. The host suppresses the spinner + token counter for
# these because they'd flash on-then-off and create flicker.
INSTANT_LOCAL_COMMANDS: frozenset[str] = frozenset({
    "/model", "/theme", "/help", "/quit", "/exit", "/clear",
    "/sessions", "/stats", "/details", "/verbose", "/compact",
    "/keymap", "/version", "/doctor", "/audit", "/checkpoint",
    "/snapshots", "/permissions", "/budget", "/credits",
})


def is_instant_local_command(prompt: str) -> bool:
    """Round 168 / A22: True when `prompt` is a slash command
    that resolves locally without a model call. The host hides
    the spinner + suppresses the token counter for these."""
    if not prompt: return False
    head = prompt.strip().split(maxsplit=1)
    if not head: return False
    return head[0].lower() in INSTANT_LOCAL_COMMANDS


def should_suppress_token_counter(*, tokens_received: int) -> bool:
    """Round 168 / A22: True until the first token arrives.

    Showing `↓0 tokens` or `↓0/0` flashes a meaningless 0 in the
    activity rail before the model has produced anything; the
    counter renders cleanly only after the first token, matching
    Claude Code's pre-first-token suppression."""
    return tokens_received <= 0


# ---------- Round 165 / B5: reduced-motion accessibility ----------


def reduced_motion_active(setting: Optional[bool] = None) -> bool:
    """Round 165 / B5: read the `prefersReducedMotion` setting.

    Pass an explicit value to override (test paths use this); otherwise
    we walk the round-139 settings loader, which itself walks the
    settings.json file. Defaults to False (animations on).
    """
    if setting is not None:
        return bool(setting)
    try:
        from prometheus.settings_v139 import prefers_reduced_motion
        return bool(prefers_reduced_motion(None))
    except Exception:
        return False


# Static spinner glyph used when reduced motion is active. A dim
# bullet — visually present but with no animation cycle.
STATIC_SPINNER_GLYPH = "·"


def spinner_frame(
    tick: int, *,
    frames: tuple[str, ...] = ("⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"),
    reduced_motion: Optional[bool] = None,
) -> str:
    """Round 165 / B5: return the spinner glyph for `tick`.

    When `prefersReducedMotion` is True the function returns
    `STATIC_SPINNER_GLYPH` for every tick — no animation cycle —
    so screen-readers and motion-sensitive users see a stable
    cursor instead of a flicker.
    """
    if reduced_motion_active(reduced_motion):
        return STATIC_SPINNER_GLYPH
    if not frames:
        return STATIC_SPINNER_GLYPH
    return frames[tick % len(frames)]


def shimmer_active(setting: Optional[bool] = None) -> bool:
    """Round 165 / B5: True when shimmer / fade-in / animated
    transitions should run. Inverse of reduced-motion."""
    return not reduced_motion_active(setting)


# ---------- Round 165 / B3: status-bar background-task count ----------


def format_background_task_indicator(
    count: int, *, queued: int = 0,
) -> str:
    """Round 165 / B3: status-bar indicator for background subagents.

    Empty string when nothing is running (so the bar collapses
    cleanly). For one or more active tasks:

      ⚡ 1 agent
      ⚡ 3 agents
      ⚡ 3 agents (+2 queued)

    The compact `⚡` glyph is the same one Claude Code uses in its
    bottom HUD; falls back to ASCII `[*]` when the host indicates
    a non-Unicode terminal (caller can pass the rendered string
    through any existing glyph-degrade pass).
    """
    if count <= 0:
        return ""
    label = "agent" if count == 1 else "agents"
    base = f"⚡ {count} {label}"
    if queued > 0:
        base += f" (+{queued} queued)"
    return base


def format_background_task_indicator_ascii(
    count: int, *, queued: int = 0,
) -> str:
    """ASCII-safe variant of `format_background_task_indicator` for
    terminals that can't render `⚡`. Same shape, `[*]` glyph."""
    if count <= 0:
        return ""
    label = "agent" if count == 1 else "agents"
    base = f"[*] {count} {label}"
    if queued > 0:
        base += f" (+{queued} queued)"
    return base


# ---------- Round 165 / B2: tool receipt collapse ----------


# Default threshold — outputs with more lines than this collapse
# to a single summary row + the `+N lines (ctrl+o to expand)` cue.
DEFAULT_COLLAPSE_THRESHOLD = 5


@dataclass(frozen=True)
class CollapsedReceipt:
    """Round 165 / B2: outcome of `collapse_output(...)`.

    `summary` is the first non-empty line (or an exit-code hint
    when the output is empty); `cue` is the
    `+N lines (ctrl+o to expand)` affordance. `expanded_full` is the
    untouched original — kept on the receipt object so the
    Ctrl+O transcript viewer can expand to it.
    """
    collapsed: bool
    line_count: int
    summary: str
    cue: str
    expanded_full: str

    def render(self) -> str:
        """Single-line collapsed receipt for the chat-log:
            ⎿ <summary> · +N lines (ctrl+o to expand)
        Or, when the output didn't need collapsing:
            (the original text, indented)
        """
        if not self.collapsed:
            return self.expanded_full
        bits = []
        if self.summary:
            bits.append(self.summary)
        if self.cue:
            bits.append(self.cue)
        return "⎿ " + " · ".join(bits) if bits else "⎿ (no output)"


def _first_nonempty_line(text: str) -> str:
    for ln in (text or "").splitlines():
        s = ln.strip()
        if s:
            return s
    return ""


def collapse_output(
    output: str,
    *,
    threshold: int = DEFAULT_COLLAPSE_THRESHOLD,
    summary_max_chars: int = 80,
    exit_code: Optional[int] = None,
) -> CollapsedReceipt:
    """Round 165 / B2: collapse verbose tool output into a single
    summary row when it exceeds `threshold` lines.

    Returns a `CollapsedReceipt`. When the output is short enough,
    `collapsed=False` and the host renders the full text. When it
    isn't, `collapsed=True` and the host renders only `summary` +
    `cue` — the full output is preserved on the receipt object so
    Ctrl+O can expand it later.

    The summary picks (in order):
      1. The first non-empty line (capped at `summary_max_chars`).
      2. `(exited 0)` / `(exited N)` when the output is empty AND
         `exit_code` is known.
      3. Empty when there's nothing useful to surface.
    """
    text = output or ""
    lines = text.splitlines()
    n = len(lines)
    if n <= threshold:
        return CollapsedReceipt(
            collapsed=False, line_count=n,
            summary="", cue="", expanded_full=text,
        )
    # Build the summary.
    first = _first_nonempty_line(text)
    if first:
        summary = first[:summary_max_chars]
        if len(first) > summary_max_chars:
            summary += "…"
    elif exit_code is not None:
        summary = f"(exited {exit_code})"
    else:
        summary = ""
    # Reuse the round-39 cue formatter for consistency.
    hidden = max(0, n - 1)  # everything but the summary line
    cue = (
        f"+{hidden} line{'s' if hidden != 1 else ''} (ctrl+o to expand)"
        if hidden > 0 else ""
    )
    return CollapsedReceipt(
        collapsed=True, line_count=n,
        summary=summary, cue=cue, expanded_full=text,
    )


def render_finished(
    p: ToolProgress, *, now: Optional[float] = None,
) -> str:
    """Round 141 / 164: post-completion summary line.

    Round 164: uses the past-tense verb (`Ran`, `Wrote`, `Searched`)
    instead of the present-progressive form, matching Claude Code's
    spinner-completion behaviour.
    """
    if not p.tool:
        return ""
    elapsed = p.elapsed_seconds(now=now)
    body = f"{past_verb_for(p.tool)} {detail_for(p.tool, p.args)}".strip()
    parts: list[str] = [f"⏺ {body}", _format_duration(elapsed)]
    if p.tokens_delta > 0:
        parts.append(f"↓{_format_tokens(p.tokens_delta)} tokens")
    return " · ".join(parts)
