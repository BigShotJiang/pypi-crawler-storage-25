"""Round 138: additional env-var flags.

Layered on top of round-137's `env_flags.py`. New flags:

  * PROMETHEUS_DISABLE_MOUSE
  * PROMETHEUS_DISABLE_TERMINAL_TITLE
  * PROMETHEUS_DISABLE_VIRTUAL_SCROLL
  * PROMETHEUS_DISABLE_PROMPT_SUGGESTION
  * PROMETHEUS_NO_FLICKER
  * PROMETHEUS_DISABLE_FAST_MODE
  * PROMETHEUS_DISABLE_FILE_CHECKPOINTING
  * PROMETHEUS_SCRIPT_CAPS=<N>          per-session script cap
  * PROMETHEUS_CUSTOM_MODEL_OPTION
  * PROMETHEUS_CUSTOM_MODEL_OPTION_DESCRIPTION
  * PROMETHEUS_PROXY_RESOLVES_HOSTS
  * PROMETHEUS_TASK_LIST_ID

Plus accessors for new settings keys.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional


_TRUTHY = ("1", "true", "yes", "on")


def _flag(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in _TRUTHY


# ---------- TUI flags ----------


def disable_mouse() -> bool:
    return _flag("PROMETHEUS_DISABLE_MOUSE")


def disable_terminal_title() -> bool:
    return _flag("PROMETHEUS_DISABLE_TERMINAL_TITLE")


def disable_virtual_scroll() -> bool:
    return _flag("PROMETHEUS_DISABLE_VIRTUAL_SCROLL")


def disable_prompt_suggestion() -> bool:
    return _flag("PROMETHEUS_DISABLE_PROMPT_SUGGESTION")


def no_flicker_on() -> bool:
    return _flag("PROMETHEUS_NO_FLICKER")


# ---------- mode-disabling ----------


def fast_mode_disabled() -> bool:
    return _flag("PROMETHEUS_DISABLE_FAST_MODE")


def file_checkpointing_disabled_env() -> bool:
    return _flag("PROMETHEUS_DISABLE_FILE_CHECKPOINTING")


# ---------- script caps ----------


def script_cap() -> Optional[int]:
    """Round 138: PROMETHEUS_SCRIPT_CAPS=<N>. None when unset
    or invalid. 0 means "deny all script execution"."""
    val = os.environ.get("PROMETHEUS_SCRIPT_CAPS", "").strip()
    if not val:
        return None
    try:
        n = int(val)
    except ValueError:
        return None
    return max(0, n)


@dataclass
class ScriptCapState:
    """Round 138: per-session script-invocation counter."""
    count: int = 0
    cap: Optional[int] = None

    def allowed(self) -> bool:
        if self.cap is None:
            return True
        return self.count < self.cap

    def consume(self) -> bool:
        if not self.allowed():
            return False
        self.count += 1
        return True


# ---------- custom model option ----------


def custom_model_option() -> Optional[tuple[str, str]]:
    """Round 138: a user-supplied entry to surface in `/model`.
    Returns (model_id, description) or None when unset."""
    val = os.environ.get("PROMETHEUS_CUSTOM_MODEL_OPTION", "").strip()
    if not val:
        return None
    desc = os.environ.get(
        "PROMETHEUS_CUSTOM_MODEL_OPTION_DESCRIPTION", "",
    ).strip() or "(custom model)"
    return (val, desc)


# ---------- proxy / task list id ----------


def proxy_resolves_hosts() -> bool:
    return _flag("PROMETHEUS_PROXY_RESOLVES_HOSTS")


def shared_task_list_id() -> Optional[str]:
    """Round 138: when set, every session reads/writes from the
    same task-list id so multi-session work shares state."""
    val = os.environ.get("PROMETHEUS_TASK_LIST_ID", "").strip()
    return val or None


# ---------- summary helper ----------


def env_flag_summary_v138() -> dict[str, bool | int | str | None]:
    """Round 138: consolidated snapshot of round-138 flags."""
    return {
        "PROMETHEUS_DISABLE_MOUSE": disable_mouse(),
        "PROMETHEUS_DISABLE_TERMINAL_TITLE":
            disable_terminal_title(),
        "PROMETHEUS_DISABLE_VIRTUAL_SCROLL":
            disable_virtual_scroll(),
        "PROMETHEUS_DISABLE_PROMPT_SUGGESTION":
            disable_prompt_suggestion(),
        "PROMETHEUS_NO_FLICKER": no_flicker_on(),
        "PROMETHEUS_DISABLE_FAST_MODE": fast_mode_disabled(),
        "PROMETHEUS_DISABLE_FILE_CHECKPOINTING":
            file_checkpointing_disabled_env(),
        "PROMETHEUS_SCRIPT_CAPS": script_cap(),
        "PROMETHEUS_CUSTOM_MODEL_OPTION":
            os.environ.get("PROMETHEUS_CUSTOM_MODEL_OPTION", "")
            or None,
        "PROMETHEUS_PROXY_RESOLVES_HOSTS": proxy_resolves_hosts(),
        "PROMETHEUS_TASK_LIST_ID": shared_task_list_id(),
    }


# ---------- new settings keys ----------


def auto_memory_enabled(setting: Optional[bool] = None) -> bool:
    """Round 138: defaults to True unless settings or env says
    otherwise."""
    # Env override (round-126 bare-mode flag) wins.
    if os.environ.get(
        "PROMETHEUS_DISABLE_AUTO_MEMORY", "",
    ).strip().lower() in _TRUTHY:
        return False
    if setting is None:
        return True
    return bool(setting)


def auto_compact_threshold(setting: Optional[float] = None) -> float:
    """Round 138: ratio of context-window-used at which auto
    compaction kicks in. Default 0.8."""
    if setting is None:
        return 0.8
    try:
        v = float(setting)
    except (TypeError, ValueError):
        return 0.8
    if v <= 0 or v > 1:
        return 0.8
    return v


def enable_prompt_suggestion(
    setting: Optional[bool] = None,
) -> bool:
    """Round 138: env wins, then settings, default True."""
    if disable_prompt_suggestion():
        return False
    if setting is None:
        return True
    return bool(setting)


def show_startup_tips(setting: Optional[bool] = None) -> bool:
    """Round 138: defaults True for first-run; the host can
    track 'has-seen' state in a marker file. We return the
    setting value when supplied."""
    if setting is None:
        return True
    return bool(setting)
