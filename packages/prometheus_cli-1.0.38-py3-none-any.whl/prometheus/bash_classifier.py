"""Round 144-final: bash command safety classifier.

Second layer beyond the round-94 static blocklist. Walks
the parsed command, examines argument shapes, pipes, and
redirects, and assigns a class:

  * `safe`      — read-only or low-risk (ls, cat, grep, …)
  * `caution`   — has side-effects but recoverable (npm
                  install, git commit, mkdir, mv, cp)
  * `dangerous` — irreversible or privileged (rm -rf, dd,
                  mkfs, curl|sh, sudo, fork bombs)

Integrates with the round-104 Overseer tier system: the
caller passes `dangerous` results straight to HARD_DENY /
SOFT_DENY review instead of allowing in `auto` mode.
"""
from __future__ import annotations

import re
import shlex
from dataclasses import dataclass, field
from typing import Optional


# ---------- patterns ----------


_DANGEROUS_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"\brm\s+(?:-[a-zA-Z]*r[a-zA-Z]*\s+|--recursive\s+).*?(?:/|\$HOME|\~)"),
    re.compile(r"\brm\s+-rf?\s+/\s*$"),
    re.compile(r"\bdd\s+.*\bof\s*=\s*/dev/(?!null|zero|random|urandom)"),
    re.compile(r"\bmkfs\.[a-z0-9]+\b"),
    re.compile(r"\b:\(\)\s*\{[^}]*:\s*\|\s*:[^}]*\}\s*;\s*:\b"),  # fork bomb
    re.compile(r"\bchmod\s+-?R?\s*7?77\s+/"),
    re.compile(r"\b(?:wget|curl)\b[^|]*\|\s*(?:bash|sh|zsh|fish)\b"),
    re.compile(r"\bsudo\s+rm\s+-r"),
    re.compile(r"\beval\s+\$\("),
    re.compile(r"\bgit\s+filter-repo\b"),
    re.compile(r"\bgit\s+reset\s+--hard\b"),
    re.compile(r"\bgit\s+push\s+(?:--force|-f)\b"),
)


_CAUTION_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"\b(?:rm|rmdir)\s+(?!-rf?\s+/)"),
    re.compile(r"\bmv\s+"),
    re.compile(r"\bcp\s+-rf?\s+"),
    re.compile(r"\bnpm\s+(?:install|i)\b"),
    re.compile(r"\bpip\s+install\b"),
    re.compile(r"\bcargo\s+install\b"),
    re.compile(r"\bgo\s+get\b"),
    re.compile(r"\bgit\s+(?:commit|checkout|merge|rebase|cherry-pick)\b"),
    re.compile(r"\bdocker\s+(?:run|exec|build)\b"),
    re.compile(r"\bmake\s+install\b"),
    re.compile(r"\bsudo\s+"),
    re.compile(r"\bsystemctl\s+(?:start|stop|restart|enable|disable)\b"),
    re.compile(r"\bchmod\b"),
    re.compile(r"\bchown\b"),
)


_SAFE_COMMANDS: frozenset[str] = frozenset({
    "ls", "ll", "la", "dir",
    "cat", "head", "tail", "less", "more",
    "grep", "rg", "ag", "ack",
    "find", "fd", "locate", "which", "whereis",
    "echo", "printf", "true", "false",
    "pwd", "whoami", "id", "uname",
    "date", "time",
    "git",                    # status/log/diff are safe; mutating
                              # forms are caught by patterns above
    "wc", "sort", "uniq", "cut", "awk", "sed",
    "diff", "cmp",
    "file", "stat",
    "env", "printenv",
    "history", "alias",
    "ps", "top", "htop",
    "df", "du",
})


# ---------- classification ----------


@dataclass
class BashClassification:
    classification: str           # `safe` / `caution` / `dangerous`
    reasons: list[str] = field(default_factory=list)
    primary_command: str = ""
    has_pipe: bool = False
    has_redirect: bool = False

    @property
    def safe(self) -> bool:
        return self.classification == "safe"

    @property
    def dangerous(self) -> bool:
        return self.classification == "dangerous"


def _first_command_token(command: str) -> str:
    try:
        tokens = shlex.split(command, posix=True)
        return tokens[0] if tokens else ""
    except ValueError:
        # shlex chokes on unbalanced quotes — fall back.
        return command.strip().split()[0] if command.strip() else ""


def classify(command: str) -> BashClassification:
    """Round 144-final: classify a bash command string.
    Empty input → safe. Pattern matches escalate; safe-list
    keeps low-risk commands fast."""
    cmd = (command or "").strip()
    result = BashClassification(
        classification="safe",
        primary_command=_first_command_token(cmd),
        has_pipe="|" in cmd,
        has_redirect=any(c in cmd for c in (">", "<")),
    )
    if not cmd:
        return result
    # Dangerous wins.
    for rx in _DANGEROUS_PATTERNS:
        if rx.search(cmd):
            result.classification = "dangerous"
            result.reasons.append(f"matches dangerous pattern: {rx.pattern[:40]}")
            return result
    # Caution next.
    for rx in _CAUTION_PATTERNS:
        if rx.search(cmd):
            result.classification = "caution"
            result.reasons.append(f"matches caution pattern: {rx.pattern[:40]}")
            return result
    # Heuristic: pipe into a shell stays caution.
    if result.has_pipe and re.search(
        r"\|\s*(?:bash|sh|zsh|fish|python|node|ruby)\b", cmd,
    ):
        result.classification = "caution"
        result.reasons.append("pipe into interpreter")
        return result
    # Safe-list lookup.
    if result.primary_command in _SAFE_COMMANDS:
        return result
    # Unknown command → caution by default. The agent sees
    # the reason and can present the command verbatim for
    # approval.
    if result.primary_command:
        result.classification = "caution"
        result.reasons.append(
            f"unknown primary command: {result.primary_command}"
        )
    return result


def render(c: BashClassification) -> str:
    """Round 144-final: human render for /classify-bash."""
    parts: list[str] = [
        f"classification: {c.classification}",
        f"  primary_command: {c.primary_command or '(empty)'}",
    ]
    if c.has_pipe:
        parts.append("  has_pipe: yes")
    if c.has_redirect:
        parts.append("  has_redirect: yes")
    if c.reasons:
        parts.append("  reasons:")
        for r in c.reasons:
            parts.append(f"    - {r}")
    return "\n".join(parts)
