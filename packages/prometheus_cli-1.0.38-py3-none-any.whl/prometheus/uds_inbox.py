"""Round 143-v2: cross-session IPC via Unix domain sockets
or Windows named pipes.

Sessions on the same machine can exchange messages so a
multi-pane workflow ("team mode") can wire up without the
network. Storage backend:

  POSIX:   `~/.prometheus/inbox/<session-name>.sock`
  Windows: file under `~/.prometheus/inbox/` — name resolves
           to a server-side queue read via the same backing
           file (named-pipe surface is the round-119 polish
           patch; the durable contract here is the message
           store + queue API).

Pure data layer + a file-based message store. The slash
command consumes the queue.
"""
from __future__ import annotations

import json
import os
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


_TRUTHY = ("1", "true", "yes", "on")


def uds_inbox_enabled() -> bool:
    """Round 143-v2: opt-in. Default off — the queue store
    consumes disk space and isn't needed unless multi-session
    teams are wired up."""
    return os.environ.get(
        "PROMETHEUS_UDS_INBOX", "",
    ).strip().lower() in _TRUTHY


def inbox_dir() -> Path:
    return Path.home() / ".prometheus" / "inbox"


def _session_file(session_name: str) -> Path:
    safe = "".join(
        c if c.isalnum() or c in "-_." else "-"
        for c in (session_name or "default")
    )
    return inbox_dir() / f"{safe}.jsonl"


# ---------- message record ----------


@dataclass
class InboxMessage:
    id: str
    sent_at: int
    from_session: str
    to_session: str
    body: str
    read: bool = False


def _serialize(m: InboxMessage) -> str:
    return json.dumps({
        "id": m.id,
        "sent_at": m.sent_at,
        "from": m.from_session,
        "to": m.to_session,
        "body": m.body,
        "read": m.read,
    })


def _parse(line: str) -> Optional[InboxMessage]:
    try:
        d = json.loads(line)
    except json.JSONDecodeError:
        return None
    try:
        return InboxMessage(
            id=str(d.get("id") or ""),
            sent_at=int(d.get("sent_at", 0)),
            from_session=str(d.get("from") or ""),
            to_session=str(d.get("to") or ""),
            body=str(d.get("body") or ""),
            read=bool(d.get("read", False)),
        )
    except (TypeError, ValueError):
        return None


# ---------- send / receive ----------


def send_message(
    *,
    to: str,
    from_session: str,
    body: str,
) -> Optional[InboxMessage]:
    """Round 143-v2: append a message to the recipient's queue.
    Returns the persisted record, or None when the inbox is
    disabled."""
    if not uds_inbox_enabled():
        return None
    if not to.strip() or not body.strip():
        return None
    base = inbox_dir()
    base.mkdir(parents=True, exist_ok=True)
    msg = InboxMessage(
        id=str(uuid.uuid4())[:8],
        sent_at=int(time.time()),
        from_session=from_session.strip() or "anon",
        to_session=to.strip(),
        body=body,
    )
    target = _session_file(to)
    with target.open("a", encoding="utf-8") as f:
        f.write(_serialize(msg) + "\n")
    return msg


def list_messages(
    *,
    session_name: str,
    include_read: bool = False,
) -> list[InboxMessage]:
    """Round 143-v2: list messages addressed to `session_name`."""
    target = _session_file(session_name)
    if not target.exists():
        return []
    out: list[InboxMessage] = []
    try:
        for line in target.read_text(
            encoding="utf-8", errors="replace",
        ).splitlines():
            m = _parse(line)
            if m is None:
                continue
            if not include_read and m.read:
                continue
            out.append(m)
    except OSError:
        return []
    return out


def mark_all_read(*, session_name: str) -> int:
    """Round 143-v2: walk the queue file and flip every entry
    to `read=True`. Returns the count flipped."""
    target = _session_file(session_name)
    if not target.exists():
        return 0
    flipped = 0
    rows: list[InboxMessage] = []
    try:
        for line in target.read_text(
            encoding="utf-8", errors="replace",
        ).splitlines():
            m = _parse(line)
            if m is None:
                continue
            if not m.read:
                m.read = True
                flipped += 1
            rows.append(m)
    except OSError:
        return 0
    target.write_text(
        "\n".join(_serialize(m) for m in rows) + ("\n" if rows else ""),
        encoding="utf-8",
    )
    return flipped


def clear_inbox(*, session_name: str) -> bool:
    target = _session_file(session_name)
    if not target.exists():
        return False
    try:
        target.unlink()
        return True
    except OSError:
        return False


# ---------- discovery + render ----------


def list_known_sessions() -> list[str]:
    """Round 143-v2: every session name that has an inbox
    file. Used by `/inbox who` to discover live recipients."""
    base = inbox_dir()
    if not base.exists():
        return []
    return sorted(
        p.stem for p in base.glob("*.jsonl") if p.is_file()
    )


def render_inbox(
    *,
    session_name: str,
    include_read: bool = False,
) -> str:
    rows = list_messages(
        session_name=session_name, include_read=include_read,
    )
    if not rows:
        return f"inbox for {session_name}: empty"
    lines = [f"inbox for {session_name}:"]
    for m in rows:
        ts = time.strftime(
            "%H:%M:%S", time.localtime(m.sent_at),
        )
        glyph = "•" if not m.read else "·"
        head = m.body.splitlines()[0] if m.body else ""
        lines.append(
            f"  {glyph} [{ts}]  from {m.from_session:14s}  "
            f"#{m.id}  {head[:60]}"
        )
    lines.append("")
    lines.append(
        f"({len(rows)} message(s); /inbox read to mark all)"
    )
    return "\n".join(lines)
