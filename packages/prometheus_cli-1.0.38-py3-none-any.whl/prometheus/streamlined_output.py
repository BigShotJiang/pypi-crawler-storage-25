"""Round 144-final: streamlined output for stream-json
consumers.

When `PROMETHEUS_STREAMLINED_OUTPUT=1` is set, the headless
stream-json writer:

  * collapses verbose tool output (truncates at 1k chars per
    tool call result)
  * strips `metadata` fields that aren't read by typical
    consumers
  * uses compact JSON formatting (no indentation, no spaces
    after separators)
  * folds repeated `text` events of the same content into a
    single `text` event with a multi-chunk count

Pure data layer. The headless `stream_json` event writer
calls `streamline_event()` per emitted line.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any, Optional


_TRUTHY = ("1", "true", "yes", "on")
_PER_TOOL_OUTPUT_CAP = 1000


def streamlined_output_enabled() -> bool:
    return os.environ.get(
        "PROMETHEUS_STREAMLINED_OUTPUT", "",
    ).strip().lower() in _TRUTHY


_STRIP_FIELDS = ("metadata", "_internal", "raw_response")


def streamline_event(event: dict[str, Any]) -> dict[str, Any]:
    """Round 144-final: project a stream-json event down to
    the fields a typical consumer needs. No-op when the
    streamlined env var isn't set."""
    if not streamlined_output_enabled():
        return event
    if not isinstance(event, dict):
        return event
    out = dict(event)
    for f in _STRIP_FIELDS:
        out.pop(f, None)
    # Truncate tool output.
    if out.get("kind") == "tool_result":
        text = out.get("output", "")
        if isinstance(text, str) and len(text) > _PER_TOOL_OUTPUT_CAP:
            out["output"] = (
                text[:_PER_TOOL_OUTPUT_CAP]
                + f"…[truncated: {len(text) - _PER_TOOL_OUTPUT_CAP} more chars]"
            )
    return out


def streamline_serialize(event: dict[str, Any]) -> str:
    """Round 144-final: JSON-serialize with no whitespace."""
    return json.dumps(
        streamline_event(event),
        separators=(",", ":"),
        default=str,
    )


# ---------- text-event coalescing ----------


@dataclass
class TextCoalescer:
    """Round 144-final: collapse repeated `text` events of
    the same content into one `text` event with a chunk
    counter. The host calls `feed()` per event and emits the
    return — None means "nothing to emit yet, still
    coalescing"; a dict means "emit this now"."""
    pending_text: str = ""
    pending_chunks: int = 0

    def feed(
        self, event: dict[str, Any],
    ) -> Optional[dict[str, Any]]:
        if not streamlined_output_enabled():
            return event
        if event.get("kind") != "text":
            # Flush any pending text first.
            if self.pending_text:
                flushed = {
                    "kind": "text",
                    "text": self.pending_text,
                    "chunks": self.pending_chunks,
                }
                self.pending_text = ""
                self.pending_chunks = 0
                return flushed
            return event
        # text event — append.
        self.pending_text += str(event.get("text") or "")
        self.pending_chunks += 1
        return None

    def flush(self) -> Optional[dict[str, Any]]:
        if not self.pending_text:
            return None
        out = {
            "kind": "text",
            "text": self.pending_text,
            "chunks": self.pending_chunks,
        }
        self.pending_text = ""
        self.pending_chunks = 0
        return out
