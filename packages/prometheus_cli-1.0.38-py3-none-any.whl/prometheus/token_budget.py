"""Round 143-final: token-budget tracking with diminishing-
returns detection.

After 3 consecutive turns each adding fewer than 500 tokens,
the agent loop stops appending the "you have more work to do"
nudge — the agent has clearly converged and pushing harder
just burns context.

Pure data-layer. The agent loop calls `record_turn()` after
each turn and `should_nudge()` before composing the next
system reminder.

Behind `PROMETHEUS_TOKEN_BUDGET=1` — opt-in.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Optional


_TRUTHY = ("1", "true", "yes", "on")


def token_budget_enabled() -> bool:
    return os.environ.get(
        "PROMETHEUS_TOKEN_BUDGET", "",
    ).strip().lower() in _TRUTHY


@dataclass
class TurnDelta:
    turn_index: int
    delta_tokens: int


# Hysteresis threshold: a turn that adds less than this is
# "small" and counts toward the diminishing-returns streak.
SMALL_TURN_THRESHOLD = 500
# Streak length that trips the suppress signal.
STREAK_LENGTH = 3


@dataclass
class TokenBudgetTracker:
    """Round 143-final: per-session tracker."""
    deltas: list[TurnDelta] = field(default_factory=list)
    suppress_nudge: bool = False

    def record_turn(self, *, delta_tokens: int) -> None:
        """Round 143-final: append a turn's delta. Updates
        the suppress flag."""
        self.deltas.append(TurnDelta(
            turn_index=len(self.deltas) + 1,
            delta_tokens=max(0, int(delta_tokens)),
        ))
        # Detect streak.
        if len(self.deltas) < STREAK_LENGTH:
            self.suppress_nudge = False
            return
        last_n = self.deltas[-STREAK_LENGTH:]
        small = sum(
            1 for t in last_n
            if t.delta_tokens < SMALL_TURN_THRESHOLD
        )
        self.suppress_nudge = (small == STREAK_LENGTH)

    def should_nudge(self) -> bool:
        """Round 143-final: returns False once diminishing
        returns are detected."""
        if not token_budget_enabled():
            return True
        return not self.suppress_nudge

    def reset(self) -> None:
        self.deltas.clear()
        self.suppress_nudge = False

    def report(self) -> str:
        if not self.deltas:
            return "token-budget: no turns recorded"
        last_n = self.deltas[-STREAK_LENGTH:]
        last_summary = ", ".join(
            f"#{t.turn_index}={t.delta_tokens}"
            for t in last_n
        )
        return (
            f"token-budget: {len(self.deltas)} turn(s); "
            f"recent ({last_summary}); "
            f"suppress_nudge={self.suppress_nudge}"
        )
