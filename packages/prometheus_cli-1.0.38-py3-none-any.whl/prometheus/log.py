"""Internal logger. Routes everything to a file under USER_DATA_DIR/logs.

CRITICAL: nothing logged here ever appears in the chat pane. Internal
warm-up, init, debug, errors all go through here — not the UI.
"""
from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path

from prometheus.config import LOG_DIR

_FORMATTER = logging.Formatter("%(asctime)s %(levelname)s %(name)s — %(message)s")
_initialized = False


def setup(level: str = "INFO") -> Path:
    global _initialized
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logfile = LOG_DIR / f"{datetime.now().strftime('%Y%m%d')}.log"
    if _initialized:
        return logfile
    handler = logging.FileHandler(logfile, encoding="utf-8")
    handler.setFormatter(_FORMATTER)
    root = logging.getLogger("prometheus")
    root.addHandler(handler)
    root.setLevel(getattr(logging, level.upper(), logging.INFO))
    root.propagate = False
    _initialized = True
    return logfile


def get(name: str) -> logging.Logger:
    if not _initialized:
        setup()
    return logging.getLogger(f"prometheus.{name}")
