"""Round 145-final + 146: enterprise + teammate + hidden env vars.

Task 4 (enterprise DISABLE):
  PROMETHEUS_DISABLE_BUG_COMMAND
  PROMETHEUS_DISABLE_EXTRA_USAGE_COMMAND
  PROMETHEUS_DISABLE_ALL_EXTERNAL_COMMANDS  (composite)

Task 5 (teammate config):
  PROMETHEUS_TEAMMATE_COMMAND
  PROMETHEUS_PLAN_MODE_REQUIRED
  PROMETHEUS_BASH_MAINTAIN_PROJECT_WORKING_DIR

Task 6 (hidden):
  PROMETHEUS_EAGER_FLUSH
  PROMETHEUS_MAX_STRUCTURED_OUTPUT_RETRIES (int, default 3)
  PROMETHEUS_ENABLE_PROMPT_SUGGESTION
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional


_TRUTHY = ("1", "true", "yes", "on")


def _flag(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name, "").strip().lower()
    if not raw:
        return default
    return raw in _TRUTHY


# ---------- Task 4: enterprise DISABLE ----------


def bug_command_disabled() -> bool:
    return _flag("PROMETHEUS_DISABLE_BUG_COMMAND")


def extra_usage_command_disabled() -> bool:
    return _flag("PROMETHEUS_DISABLE_EXTRA_USAGE_COMMAND")


def all_external_commands_disabled() -> bool:
    """Round 145-final: composite. When set, every individual
    external-comms disabler returns True."""
    return _flag("PROMETHEUS_DISABLE_ALL_EXTERNAL_COMMANDS")


def effective_bug_command_disabled() -> bool:
    return bug_command_disabled() or all_external_commands_disabled()


def effective_extra_usage_command_disabled() -> bool:
    return (
        extra_usage_command_disabled()
        or all_external_commands_disabled()
    )


# ---------- Task 5: teammate config ----------


def teammate_command() -> Optional[str]:
    """Round 145-final: override the executable path used to
    spawn teammate sessions."""
    val = os.environ.get(
        "PROMETHEUS_TEAMMATE_COMMAND", "",
    ).strip()
    return val or None


def plan_mode_required() -> bool:
    """Round 145-final: force teammates to enter plan mode
    before any implementation."""
    return _flag("PROMETHEUS_PLAN_MODE_REQUIRED")


def bash_maintain_project_cwd() -> bool:
    """Round 145-final: when set, every Bash invocation runs
    from the project root regardless of `cd` commands within
    a single tool call."""
    return _flag("PROMETHEUS_BASH_MAINTAIN_PROJECT_WORKING_DIR")


# ---------- Task 6: hidden flags ----------


def eager_flush_enabled() -> bool:
    """Round 145-final: force eager flushes on transcript +
    storage writes — safer in CI, slower in interactive."""
    return _flag("PROMETHEUS_EAGER_FLUSH")


def max_structured_output_retries() -> int:
    """Round 145-final: retry budget for structured-output
    recovery when the model emits malformed JSON."""
    raw = os.environ.get(
        "PROMETHEUS_MAX_STRUCTURED_OUTPUT_RETRIES", "",
    ).strip()
    if not raw:
        return 3
    try:
        n = int(raw)
        return max(0, n)
    except ValueError:
        return 3


def prompt_suggestion_explicitly_enabled() -> bool:
    """Round 145-final: explicit opt-in for the round-138
    prompt-suggestions feature (overrides the
    `PROMETHEUS_DISABLE_PROMPT_SUGGESTION` disabler)."""
    return _flag("PROMETHEUS_ENABLE_PROMPT_SUGGESTION")


# ---------- summary ----------


@dataclass
class V146Summary:
    bug_command_disabled: bool
    extra_usage_command_disabled: bool
    all_external_commands_disabled: bool
    teammate_command: Optional[str]
    plan_mode_required: bool
    bash_maintain_project_cwd: bool
    eager_flush_enabled: bool
    max_structured_output_retries: int
    prompt_suggestion_explicitly_enabled: bool


def env_flag_summary_v146() -> V146Summary:
    return V146Summary(
        bug_command_disabled=effective_bug_command_disabled(),
        extra_usage_command_disabled=
            effective_extra_usage_command_disabled(),
        all_external_commands_disabled=
            all_external_commands_disabled(),
        teammate_command=teammate_command(),
        plan_mode_required=plan_mode_required(),
        bash_maintain_project_cwd=bash_maintain_project_cwd(),
        eager_flush_enabled=eager_flush_enabled(),
        max_structured_output_retries=
            max_structured_output_retries(),
        prompt_suggestion_explicitly_enabled=
            prompt_suggestion_explicitly_enabled(),
    )
