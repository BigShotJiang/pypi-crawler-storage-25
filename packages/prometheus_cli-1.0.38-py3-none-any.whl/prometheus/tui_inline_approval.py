"""Round 141: inline permission approval UX.

When a tool needs approval, the prompt area transforms inline
instead of spawning a popup:

    ● Bash(pwd) — Allow? (y)es / (n)o / (a)lways

Color: amber/yellow background. Three keystroke responses.
`y` approves once, `n` denies once, `a` adds the (tool, arg)
shape to the session allowlist so future calls don't prompt.

Pure data layer + state machine. The Textual host's prompt
widget consults this state to decide what to render and how
to handle keypresses.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


# ---------- approval state ----------


@dataclass
class InlineApproval:
    """Round 141: one pending approval in the input area."""
    active: bool = False
    tool_name: str = ""
    detail: str = ""           # rendered (path / command / arg summary)
    arg_signature: str = ""    # used for the always-allow allowlist
    why: str = ""              # short reason / safety note
    decision: str = ""         # filled by handle_keypress


def begin(
    state: InlineApproval, *,
    tool_name: str, detail: str = "",
    arg_signature: str = "", why: str = "",
) -> None:
    """Round 141: arm the inline approval. The host blocks the
    Input from accepting normal keystrokes until `decision` is
    populated."""
    state.active = True
    state.tool_name = tool_name
    state.detail = detail
    state.arg_signature = arg_signature or detail
    state.why = why
    state.decision = ""


def handle_keypress(
    state: InlineApproval, key: str,
) -> Optional[str]:
    """Round 141: feed a single keypress into the approval
    state machine. Returns one of `yes`/`no`/`always`/None
    (None when the key isn't a decision)."""
    if not state.active:
        return None
    k = (key or "").strip().lower()
    decision: Optional[str] = None
    if k in ("y", "yes", "enter", "return"):
        decision = "yes"
    elif k in ("n", "no", "esc", "escape"):
        decision = "no"
    elif k in ("a", "always"):
        decision = "always"
    if decision:
        state.decision = decision
        state.active = False
    return decision


def end(state: InlineApproval) -> None:
    """Round 141: clear the approval. Caller invokes after
    consuming `decision`."""
    state.active = False
    state.tool_name = ""
    state.detail = ""
    state.arg_signature = ""
    state.why = ""
    state.decision = ""


# ---------- session allowlist ----------


@dataclass
class SessionAllowlist:
    """Round 141: per-session "always allow" cache. Survives
    until quit. Keyed by `(tool_name, arg_signature)` so a
    `Bash(pwd)` allow doesn't allow `Bash(rm -rf)`."""
    entries: set[tuple[str, str]] = field(default_factory=set)

    def allow(self, tool_name: str, arg_signature: str) -> None:
        if tool_name:
            self.entries.add((tool_name, arg_signature or ""))

    def is_allowed(
        self, tool_name: str, arg_signature: str,
    ) -> bool:
        if not tool_name:
            return False
        if (tool_name, arg_signature or "") in self.entries:
            return True
        # Tool-level wildcard ("always allow Bash regardless of
        # args") if the user added an empty signature entry.
        if (tool_name, "") in self.entries:
            return True
        return False

    def clear(self) -> None:
        self.entries.clear()


# ---------- render contract ----------


_STYLE_CLASS = "inline-approval-amber"


def render_prompt_line(state: InlineApproval) -> str:
    """Round 141: the text that should appear in the input
    area while approval is pending."""
    if not state.active:
        return ""
    inner = (
        f"{state.tool_name}({state.detail})"
        if state.detail else state.tool_name
    )
    body = f"● {inner} — Allow? (y)es / (n)o / (a)lways"
    if state.why:
        body += f"\n  why: {state.why}"
    return body


def render_style_class() -> str:
    """Round 141: CSS class the host applies to the input area
    while approval is pending. The Textual stylesheet styles
    `.inline-approval-amber` with amber background + black
    foreground."""
    return _STYLE_CLASS


def is_pending(state: InlineApproval) -> bool:
    return state.active


# ---------- Round 168 / A19: tabbed modal for compound Bash ----------
#
# When the user (or model) issues a compound Bash command such as
# `git status && rm -rf build && pytest -q`, the tabbed modal
# lets them approve / deny each subcommand individually. Left /
# Right keys navigate; Enter approves; Esc denies; A approves
# the whole batch.


@dataclass
class TabbedSubcommandApproval:
    """Round 168: per-subcommand approval state for compound
    Bash invocations.

    The host populates `subcommands` from the parsed Bash AST
    (or a simple `&& / ; / |` split for the fast path), arms the
    modal, then drives `select_left()` / `select_right()` /
    `approve_current()` / `deny_current()` from key events. When
    every subcommand has a verdict, `is_complete()` returns True
    and the host consumes the per-subcommand verdicts."""
    active: bool = False
    subcommands: list[str] = field(default_factory=list)
    verdicts: list[str] = field(default_factory=list)
    """Parallel to `subcommands`: 'pending' / 'approve' / 'deny' /
    'always'. Initialised to all 'pending' on `begin_tabbed`."""
    cursor: int = 0
    """Currently-selected tab index."""

    # ---- public API ------------------------------------------

    def select_left(self) -> int:
        if self.subcommands:
            self.cursor = (self.cursor - 1) % len(self.subcommands)
        return self.cursor

    def select_right(self) -> int:
        if self.subcommands:
            self.cursor = (self.cursor + 1) % len(self.subcommands)
        return self.cursor

    def approve_current(self) -> str:
        if self.subcommands:
            self.verdicts[self.cursor] = "approve"
        return self.verdicts[self.cursor] if self.subcommands else ""

    def deny_current(self) -> str:
        if self.subcommands:
            self.verdicts[self.cursor] = "deny"
        return self.verdicts[self.cursor] if self.subcommands else ""

    def approve_all(self) -> None:
        for i in range(len(self.verdicts)):
            self.verdicts[i] = "approve"

    def deny_all(self) -> None:
        for i in range(len(self.verdicts)):
            self.verdicts[i] = "deny"

    def is_complete(self) -> bool:
        return bool(self.subcommands) and all(
            v != "pending" for v in self.verdicts
        )


def begin_tabbed(
    state: TabbedSubcommandApproval, *,
    subcommands: list[str],
) -> None:
    """Round 168: arm the tabbed modal with `subcommands`. Resets
    the cursor to 0 and marks every verdict pending."""
    state.active = True
    state.subcommands = list(subcommands)
    state.verdicts = ["pending"] * len(subcommands)
    state.cursor = 0


def end_tabbed(state: TabbedSubcommandApproval) -> None:
    state.active = False
    state.subcommands = []
    state.verdicts = []
    state.cursor = 0


def render_tabbed_modal(state: TabbedSubcommandApproval) -> str:
    """Round 168: human-readable modal render. The Textual host
    displays this as styled text (selected tab in amber, denied
    in red, approved in green); this returns the plain shape
    that tests assert on.

    Format:
        Approve compound command (← → to navigate)
        ▸ [1/3] git status                 (selected)
          [2/3] rm -rf build
          [3/3] pytest -q
        Enter approves · Esc denies · A approves all · D denies all
    """
    if not state.active or not state.subcommands:
        return ""
    n = len(state.subcommands)
    lines = [f"Approve compound command (← → to navigate)"]
    for i, (cmd, v) in enumerate(zip(state.subcommands, state.verdicts)):
        marker = "▸" if i == state.cursor else " "
        verdict_glyph = {
            "pending": "·", "approve": "✓",
            "deny": "✗", "always": "◇",
        }.get(v, "·")
        lines.append(f"{marker} [{i + 1}/{n}] {verdict_glyph} {cmd}")
    lines.append(
        "Enter approves · Esc denies · A approves all · D denies all"
    )
    return "\n".join(lines)


def split_compound_bash(command: str) -> list[str]:
    """Round 168: best-effort split of a compound Bash command
    into subcommands.

    Conservative: splits on top-level `&&`, `||`, `;`, and `|`,
    while respecting single + double-quoted strings. Doesn't
    parse subshells (`$(...)` / `\\`(...)\\``) — those count as
    one subcommand. Good enough for the tabbed-modal use case;
    the round-104 Overseer still re-evaluates the whole string."""
    if not command:
        return []
    parts: list[str] = []
    buf: list[str] = []
    i = 0
    in_single = in_double = False
    paren_depth = 0
    while i < len(command):
        ch = command[i]
        nxt = command[i + 1] if i + 1 < len(command) else ""
        if not in_single and not in_double:
            if ch == "(" or (ch == "$" and nxt == "(" ):
                paren_depth += 1
                buf.append(ch); i += 1; continue
            if ch == ")" and paren_depth > 0:
                paren_depth -= 1
                buf.append(ch); i += 1; continue
            if paren_depth == 0:
                # Check for two-char delimiters first.
                if ch == "&" and nxt == "&":
                    parts.append("".join(buf).strip())
                    buf = []; i += 2; continue
                if ch == "|" and nxt == "|":
                    parts.append("".join(buf).strip())
                    buf = []; i += 2; continue
                if ch == ";":
                    parts.append("".join(buf).strip())
                    buf = []; i += 1; continue
                if ch == "|":
                    parts.append("".join(buf).strip())
                    buf = []; i += 1; continue
        # Quote tracking.
        if ch == "'" and not in_double:
            in_single = not in_single
        elif ch == '"' and not in_single:
            in_double = not in_double
        buf.append(ch); i += 1
    tail = "".join(buf).strip()
    if tail:
        parts.append(tail)
    return [p for p in parts if p]
