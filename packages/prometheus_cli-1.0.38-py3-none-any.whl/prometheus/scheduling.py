"""Round 139: `/schedule` — interactive cron-based agent registration.

Wraps the existing Round-111 Routines registry in a friendly
prompt-driven workflow. The user supplies:

  1. cron schedule (5-field)
  2. task description
  3. model (alias or full id)

We validate the cron, normalize the model alias via round-135
`resolve_alias`, and emit a Routine record the host writes to
`~/.prometheus/routines/`.
"""
from __future__ import annotations

import re
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


# ---------- cron validation ----------


_CRON_FIELD_RX = re.compile(r"^(\*|\d+|\d+-\d+|\*/\d+|\d+(?:,\d+)+)$")


def validate_cron(expr: str) -> tuple[bool, str]:
    """Round 139: validate a 5-field cron expression. Returns
    (ok, message). Accepts `*`, `N`, `N-M`, `*/N`, `N,M,O`."""
    if not expr or not isinstance(expr, str):
        return (False, "empty cron expression")
    parts = expr.strip().split()
    if len(parts) != 5:
        return (
            False,
            "cron must have 5 fields (minute hour dom month dow); "
            f"got {len(parts)}",
        )
    labels = ("minute", "hour", "dom", "month", "dow")
    for label, field in zip(labels, parts):
        if not _CRON_FIELD_RX.match(field):
            return (
                False,
                f"invalid {label} field: {field!r}",
            )
    return (True, "")


# ---------- model normalization ----------


def normalize_model(raw: str) -> str:
    """Round 139: resolve an alias to a concrete model id via
    round-135 `resolve_alias`. Empty input becomes the
    auto/free router."""
    raw = (raw or "").strip()
    if not raw:
        return "openrouter/auto"
    try:
        from prometheus.model_tiers import resolve_alias
        return resolve_alias(raw)
    except Exception:
        return raw


# ---------- routine record ----------


@dataclass
class ScheduledRoutine:
    """Round 139: the record written to disk + handed to the
    Routines engine."""
    id: str
    cron: str
    task: str
    model: str
    created_at: int
    enabled: bool = True


def make_routine(
    *,
    cron: str,
    task: str,
    model: str = "",
) -> Optional[ScheduledRoutine]:
    """Round 139: validate inputs and assemble the record.
    Returns None when validation fails."""
    ok, _ = validate_cron(cron)
    if not ok:
        return None
    if not task.strip():
        return None
    return ScheduledRoutine(
        id=str(uuid.uuid4())[:8],
        cron=cron.strip(),
        task=task.strip(),
        model=normalize_model(model),
        created_at=int(time.time()),
    )


def routines_dir() -> Path:
    return Path.home() / ".prometheus" / "routines"


def write_routine(
    routine: ScheduledRoutine,
    *, target_dir: Optional[Path] = None,
) -> Path:
    """Round 139: persist as YAML-frontmatter markdown so the
    round-111 routines loader can pick it up."""
    base = target_dir or routines_dir()
    base.mkdir(parents=True, exist_ok=True)
    p = base / f"{routine.id}.md"
    body = (
        f"---\n"
        f"id: {routine.id}\n"
        f"cron: \"{routine.cron}\"\n"
        f"model: {routine.model}\n"
        f"enabled: {'true' if routine.enabled else 'false'}\n"
        f"created_at: {routine.created_at}\n"
        f"---\n\n"
        f"{routine.task}\n"
    )
    p.write_text(body, encoding="utf-8")
    return p


def render_routine(r: ScheduledRoutine) -> str:
    """Round 139: human-friendly summary printed after register."""
    return (
        f"scheduled routine\n"
        f"  id:    {r.id}\n"
        f"  cron:  {r.cron}\n"
        f"  model: {r.model}\n"
        f"  task:  {r.task[:80]}{'…' if len(r.task) > 80 else ''}"
    )


# ---------- interactive prompts ----------


SCHEDULE_PROMPT_QUESTIONS = (
    {
        "key": "cron",
        "label": "cron schedule",
        "hint": "5-field cron, e.g. `0 9 * * 1-5` for weekdays at 9am",
    },
    {
        "key": "task",
        "label": "task description",
        "hint": "what the agent should do on each tick",
    },
    {
        "key": "model",
        "label": "model (optional)",
        "hint": "alias or full id; blank = auto/free router",
    },
)


def parse_inline_args(arg: str) -> dict:
    """Round 139: support a non-interactive form,
    `/schedule --cron "0 9 * * 1-5" --task "review PRs" --model sonnet`,
    so power users don't have to walk the prompts."""
    raw = arg or ""
    out: dict = {}
    # Match --key="value" or --key value forms.
    rx = re.compile(
        r'--(cron|task|model)(?:=|\s+)("([^"]*)"|\'([^\']*)\'|(\S+))'
    )
    for m in rx.finditer(raw):
        key = m.group(1)
        val = m.group(3) or m.group(4) or m.group(5) or ""
        out[key] = val
    return out
