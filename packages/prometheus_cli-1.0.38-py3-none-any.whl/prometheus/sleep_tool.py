"""Round 143-final: SleepTool — voluntary agent sleep + auto-wake.

The agent can call `sleep_tool` to pause its work loop for a
duration. The terminal session stays connected; any keypress
wakes early. Combined with auto-mode this gives a fully
autonomous work cycle with rest periods.

Pure data layer + an async helper. The Tool subclass runs the
sleep via `asyncio.sleep` so the event loop stays responsive
to user keystrokes.
"""
from __future__ import annotations

import asyncio
import os
import re
import time
from dataclasses import dataclass
from typing import Any, Optional

from prometheus.tools.base import Tool, SideEffect, ToolContext, ToolResult


_TRUTHY = ("1", "true", "yes", "on")


def proactive_enabled() -> bool:
    """Round 143-final: env gate. Default off — opt-in only."""
    return os.environ.get(
        "PROMETHEUS_PROACTIVE", "",
    ).strip().lower() in _TRUTHY


# ---------- duration parser ----------


_DURATION_RX = re.compile(
    r"^\s*(\d+(?:\.\d+)?)\s*(ms|s|m|h)?\s*$",
    re.IGNORECASE,
)
_MAX_SLEEP_S = 60 * 60 * 4  # 4 hour cap


def parse_duration(spec: str) -> Optional[float]:
    """Round 143-final: parse `'5m'`, `'90s'`, `'500ms'`. Returns
    seconds, or None on parse failure."""
    if not spec:
        return None
    m = _DURATION_RX.match(str(spec))
    if not m:
        return None
    try:
        n = float(m.group(1))
    except ValueError:
        return None
    unit = (m.group(2) or "s").lower()
    factor = {"ms": 0.001, "s": 1.0, "m": 60.0, "h": 3600.0}[unit]
    seconds = n * factor
    if seconds < 0:
        return None
    return min(seconds, _MAX_SLEEP_S)


# ---------- sleep state ----------


@dataclass
class SleepState:
    """Round 143-final: tracks an active sleep so the host's
    keystroke handler can wake it early."""
    sleeping: bool = False
    wake_at: float = 0.0
    requested_seconds: float = 0.0
    woken_early: bool = False
    started_at: float = 0.0


_STATE = SleepState()


def state() -> SleepState:
    """Round 143-final: shared singleton. The Textual host
    wakes the active sleep by setting `state().woken_early =
    True` from its keystroke handler."""
    return _STATE


def wake_early() -> bool:
    """Round 143-final: signal the active sleep to terminate
    on the next tick. Returns True when a sleep was active."""
    if not _STATE.sleeping:
        return False
    _STATE.woken_early = True
    return True


async def sleep_for(
    seconds: float, *, tick_ms: int = 100,
) -> SleepState:
    """Round 143-final: cooperative sleep that polls the wake
    flag at `tick_ms`. Returns the final state — `woken_early`
    flag indicates whether the user interrupted."""
    if seconds <= 0:
        return _STATE
    _STATE.sleeping = True
    _STATE.requested_seconds = seconds
    _STATE.started_at = time.monotonic()
    _STATE.wake_at = _STATE.started_at + seconds
    _STATE.woken_early = False
    tick = max(0.01, tick_ms / 1000.0)
    try:
        while True:
            now = time.monotonic()
            if now >= _STATE.wake_at:
                break
            if _STATE.woken_early:
                break
            await asyncio.sleep(min(tick, _STATE.wake_at - now))
    finally:
        _STATE.sleeping = False
    return _STATE


# ---------- the Tool ----------


class SleepTool(Tool):
    """Round 143-final: voluntary agent sleep. Only available
    when `PROMETHEUS_PROACTIVE=1` is set."""
    name = "sleep_tool"
    description = (
        "Pause the agent for a duration. Format: '5m', '30s', "
        "'500ms'. The user can press any key to wake early. "
        "Use only when waiting for an external event or when "
        "explicitly told to sleep."
    )
    schema = {
        "type": "object",
        "properties": {
            "duration": {
                "type": "string",
                "description": "Duration like '5m' or '30s'.",
            },
            "reason": {
                "type": "string",
                "description": "Why you're pausing.",
            },
        },
        "required": ["duration"],
    }
    side_effect = SideEffect.READ

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        if not proactive_enabled():
            return ToolResult(
                error=True,
                output=(
                    "sleep_tool needs PROMETHEUS_PROACTIVE=1 "
                    "(opt-in)."
                ),
            )
        secs = parse_duration(str(args.get("duration", "")))
        if secs is None:
            return ToolResult(
                error=True,
                output="bad duration — use '5m', '30s', '500ms'.",
            )
        reason = str(args.get("reason", "")).strip()
        await sleep_for(secs)
        elapsed = time.monotonic() - _STATE.started_at
        woke = "woken early" if _STATE.woken_early else "elapsed"
        return ToolResult(
            error=False,
            output=(
                f"slept {elapsed:.1f}s ({woke})"
                + (f"  reason: {reason}" if reason else "")
            ),
        )
