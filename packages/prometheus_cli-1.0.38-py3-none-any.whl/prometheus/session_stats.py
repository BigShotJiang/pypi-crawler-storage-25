"""Round 137: detailed session statistics for `/stats` + `/cost`.

The existing /stats was a thin shim. Round 137 adds:

  * duration since session start
  * message count + breakdown by role
  * tool calls grouped by tool name
  * files created/modified (parsed from tool calls)
  * errors encountered (counted from tool results)

Plus per-tool cost rollup for `/cost`. Pure data layer; the
slash command consumes the dataclass.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class SessionStats:
    """Round 137: snapshot of session state for `/stats`."""
    started_at: float
    now: float
    message_count: int = 0
    role_counts: dict[str, int] = field(default_factory=dict)
    tool_call_counts: dict[str, int] = field(default_factory=dict)
    files_created: list[str] = field(default_factory=list)
    files_modified: list[str] = field(default_factory=list)
    errors_encountered: int = 0

    @property
    def duration_seconds(self) -> int:
        return max(0, int(self.now - self.started_at))


def _format_duration(seconds: int) -> str:
    if seconds < 60:
        return f"{seconds}s"
    m, s = divmod(seconds, 60)
    if m < 60:
        return f"{m}m {s}s"
    h, m = divmod(m, 60)
    return f"{h}h {m}m"


_FILE_TOOL_CREATE = ("write_file", "Write")
_FILE_TOOL_MODIFY = (
    "edit_file", "multi_edit", "apply_patch",
    "Edit", "Update", "MultiEdit", "ApplyPatch",
)


def _extract_file_path(args: Any) -> Optional[str]:
    """Round 137: pull a path-like field out of tool arguments."""
    if not isinstance(args, dict):
        return None
    for key in ("path", "file", "file_path", "target", "filename"):
        v = args.get(key)
        if isinstance(v, str) and v.strip():
            return v.strip()
    return None


def _parse_tool_args(call: Any) -> Any:
    """Round 137: extract the dict args from a tool_call shape.
    Tolerates both the round-95 dict shape and the round-83
    structured object shape."""
    if isinstance(call, dict):
        args = call.get("arguments") or call.get("args") or {}
    else:
        args = getattr(call, "arguments", None)
        if args is None:
            args = getattr(call, "args", None)
    if isinstance(args, str):
        try:
            args = json.loads(args)
        except (ValueError, TypeError):
            args = {}
    return args if isinstance(args, dict) else {}


def _tool_name(call: Any) -> str:
    if isinstance(call, dict):
        return str(call.get("name") or call.get("function") or "")
    return str(getattr(call, "name", "") or "")


def compute_session_stats(
    *,
    messages: list[dict[str, Any]],
    started_at: Optional[float] = None,
    now: Optional[float] = None,
) -> SessionStats:
    """Round 137: walk messages + tool_calls to build the
    SessionStats snapshot."""
    if started_at is None:
        started_at = time.time()
    if now is None:
        now = time.time()
    stats = SessionStats(started_at=started_at, now=now)
    seen_created: set[str] = set()
    seen_modified: set[str] = set()
    for m in messages:
        if not isinstance(m, dict):
            continue
        stats.message_count += 1
        role = str(m.get("role") or "")
        if role:
            stats.role_counts[role] = stats.role_counts.get(role, 0) + 1
        # tool calls
        for call in m.get("tool_calls") or []:
            name = _tool_name(call)
            if not name:
                continue
            stats.tool_call_counts[name] = stats.tool_call_counts.get(
                name, 0,
            ) + 1
            args = _parse_tool_args(call)
            path = _extract_file_path(args)
            if path:
                if name in _FILE_TOOL_CREATE:
                    if path not in seen_created:
                        seen_created.add(path)
                        stats.files_created.append(path)
                elif name in _FILE_TOOL_MODIFY:
                    if path not in seen_modified:
                        seen_modified.add(path)
                        stats.files_modified.append(path)
        # tool results — count errors
        if role == "tool":
            content = m.get("content") or ""
            if isinstance(content, str):
                low = content.lower()
                if (
                    "error" in low
                    or "failed" in low
                    or "traceback" in low
                ):
                    stats.errors_encountered += 1
        if m.get("is_error"):
            stats.errors_encountered += 1
    return stats


def render_stats(stats: SessionStats) -> str:
    """Round 137: human render of the SessionStats snapshot."""
    lines: list[str] = []
    lines.append("session stats:")
    lines.append(
        f"  duration: {_format_duration(stats.duration_seconds)}"
    )
    lines.append(f"  messages: {stats.message_count}")
    if stats.role_counts:
        roles = "  ".join(
            f"{role}={n}"
            for role, n in sorted(stats.role_counts.items())
        )
        lines.append(f"    by role: {roles}")
    if stats.tool_call_counts:
        lines.append("  tool calls:")
        for name, n in sorted(
            stats.tool_call_counts.items(),
            key=lambda kv: kv[1],
            reverse=True,
        ):
            lines.append(f"    {name:24s}  {n}")
    if stats.files_created:
        lines.append(
            f"  files created ({len(stats.files_created)}):"
        )
        for p in stats.files_created[:10]:
            lines.append(f"    + {p}")
    if stats.files_modified:
        lines.append(
            f"  files modified ({len(stats.files_modified)}):"
        )
        for p in stats.files_modified[:10]:
            lines.append(f"    ~ {p}")
    if stats.errors_encountered:
        lines.append(
            f"  errors: {stats.errors_encountered}"
        )
    return "\n".join(lines)


# ---------- /cost ----------


@dataclass
class CostBreakdown:
    """Round 137: token + cost rollup for `/cost`."""
    tokens_in: int = 0
    tokens_out: int = 0
    cost_usd: float = 0.0
    per_tool_calls: dict[str, int] = field(default_factory=dict)


def compute_cost_breakdown(
    *,
    tokens_in: int,
    tokens_out: int,
    cost_usd: float,
    messages: list[dict[str, Any]],
) -> CostBreakdown:
    """Round 137: assemble the rollup. Per-tool cost can't be
    derived from a single conversation without per-call usage
    metering — we surface call counts so users can see *where*
    spend is going even when we can't attribute exact dollars."""
    cb = CostBreakdown(
        tokens_in=tokens_in,
        tokens_out=tokens_out,
        cost_usd=cost_usd,
    )
    for m in messages:
        if not isinstance(m, dict):
            continue
        for call in m.get("tool_calls") or []:
            name = _tool_name(call)
            if name:
                cb.per_tool_calls[name] = cb.per_tool_calls.get(
                    name, 0,
                ) + 1
    return cb


def render_cost(cb: CostBreakdown) -> str:
    """Round 137: human render of the cost rollup."""
    lines: list[str] = []
    lines.append("session cost:")
    lines.append(f"  ↑ input  tokens: {cb.tokens_in:,}")
    lines.append(f"  ↓ output tokens: {cb.tokens_out:,}")
    lines.append(f"  ≈ total cost:    ${cb.cost_usd:.4f}")
    if cb.per_tool_calls:
        lines.append("  tool call counts:")
        for name, n in sorted(
            cb.per_tool_calls.items(),
            key=lambda kv: kv[1],
            reverse=True,
        ):
            lines.append(f"    {name:24s}  {n}")
    lines.append("  (local — no API call to compute)")
    return "\n".join(lines)
