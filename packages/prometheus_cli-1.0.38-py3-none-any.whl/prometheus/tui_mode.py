"""Round 138: `/tui fullscreen` — fullscreen rendering mode.

When active:

  * The terminal switches to the alternate screen buffer.
  * Mouse tracking is enabled (unless PROMETHEUS_DISABLE_MOUSE=1).
  * The terminal title is updated (unless
    PROMETHEUS_DISABLE_TERMINAL_TITLE=1).
  * The NO_FLICKER renderer takes over (when
    PROMETHEUS_NO_FLICKER=1).

Toggle via `/tui fullscreen` mid-session, or launch with
`--tui fullscreen`.
"""
from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass
class TuiMode:
    fullscreen: bool = False


def fullscreen_active() -> bool:
    return os.environ.get(
        "PROMETHEUS_TUI_FULLSCREEN", "",
    ).strip().lower() in ("1", "true", "yes")


def enable_fullscreen(state: TuiMode) -> TuiMode:
    state.fullscreen = True
    os.environ["PROMETHEUS_TUI_FULLSCREEN"] = "1"
    return state


def disable_fullscreen(state: TuiMode) -> TuiMode:
    state.fullscreen = False
    os.environ["PROMETHEUS_TUI_FULLSCREEN"] = "0"
    return state


# ---------- escape-sequence helpers ----------


def enter_alt_screen_seq() -> str:
    """Round 138: ANSI to enter alternate-screen buffer."""
    return "\x1b[?1049h"


def leave_alt_screen_seq() -> str:
    """Round 138: ANSI to leave alternate-screen buffer."""
    return "\x1b[?1049l"


def enable_mouse_seq() -> str:
    return "\x1b[?1003h\x1b[?1006h"


def disable_mouse_seq() -> str:
    return "\x1b[?1006l\x1b[?1003l"


def set_title_seq(title: str) -> str:
    """Round 138: OSC 0 — set terminal title."""
    return f"\x1b]0;{title}\x07"


# ---------- env gates ----------


def mouse_disabled() -> bool:
    return os.environ.get(
        "PROMETHEUS_DISABLE_MOUSE", "",
    ).strip().lower() in ("1", "true", "yes")


def title_disabled() -> bool:
    return os.environ.get(
        "PROMETHEUS_DISABLE_TERMINAL_TITLE", "",
    ).strip().lower() in ("1", "true", "yes")


def parse_tui_arg(arg: str) -> str:
    """Round 138: parse `/tui` arg. Returns one of:
      ""             — toggle (default)
      "fullscreen"   — enter fullscreen
      "off"          — leave fullscreen
      "status"       — show current
    """
    v = (arg or "").strip().lower()
    if not v:
        return ""
    if v in ("fullscreen", "on", "enter"):
        return "fullscreen"
    if v in ("off", "exit", "leave", "windowed"):
        return "off"
    if v in ("status", "info"):
        return "status"
    return v
