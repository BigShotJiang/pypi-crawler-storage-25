"""Round 136: `--worktree` and `--tmux` launch helpers.

`--worktree` creates an isolated git worktree of the current
repo in a temp directory and launches Prometheus there. The
worktree is cleaned up on exit unless `--keep-worktree` is set.

`--tmux` (POSIX only — graceful no-op on Windows) wraps the
worktree session in a detached tmux session named after the
worktree path.

Pure data layer + small subprocess wrappers. The host wires
the actual launch in `prometheus/__main__.py`.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


# ---------- worktree ----------


@dataclass
class WorktreeHandle:
    path: Path
    branch: str
    base_repo: Path
    keep: bool = False


def create_worktree(
    *,
    base: Optional[Path] = None,
    branch_prefix: str = "prometheus",
    keep: bool = False,
) -> Optional[WorktreeHandle]:
    """Round 136: create a fresh git worktree. Returns None if
    `git` isn't on PATH or the base path isn't a git repo."""
    if shutil.which("git") is None:
        return None
    base = base or Path.cwd()
    # Verify base is in a git repo.
    cp = subprocess.run(
        ["git", "-C", str(base), "rev-parse", "--git-dir"],
        capture_output=True, text=True, check=False,
    )
    if cp.returncode != 0:
        return None
    target = Path(tempfile.mkdtemp(prefix=f"{branch_prefix}-wt-"))
    branch = f"{branch_prefix}/{int(time.time())}"
    cp2 = subprocess.run(
        [
            "git", "-C", str(base), "worktree", "add",
            "-b", branch, str(target),
        ],
        capture_output=True, text=True, check=False,
    )
    if cp2.returncode != 0:
        # Clean up if the create failed.
        try:
            shutil.rmtree(target, ignore_errors=True)
        except OSError:
            pass
        return None
    return WorktreeHandle(
        path=target, branch=branch, base_repo=base, keep=keep,
    )


def cleanup_worktree(h: WorktreeHandle) -> bool:
    """Round 136: tear down a worktree. Skips when `keep=True`."""
    if h.keep:
        return False
    if shutil.which("git") is None:
        try:
            shutil.rmtree(h.path, ignore_errors=True)
            return True
        except OSError:
            return False
    cp = subprocess.run(
        [
            "git", "-C", str(h.base_repo), "worktree", "remove",
            "--force", str(h.path),
        ],
        capture_output=True, text=True, check=False,
    )
    if cp.returncode != 0:
        # Fallback to a hard remove.
        try:
            shutil.rmtree(h.path, ignore_errors=True)
        except OSError:
            return False
    return True


def list_worktrees(repo_dir: Path) -> list[Path]:
    """1.0.3: enumerate the worktrees of `repo_dir`'s repository.

    Returns each worktree path (including the main checkout) as
    a list of `Path` objects. Empty list when `git` is missing,
    `repo_dir` is not inside a repo, or parsing fails — callers
    should treat empty as "unknown" and fall back to a softer
    check rather than refusing.
    """
    if shutil.which("git") is None:
        return []
    try:
        cp = subprocess.run(
            ["git", "-C", str(repo_dir), "worktree", "list", "--porcelain"],
            capture_output=True, text=True, check=False, timeout=10,
        )
    except (OSError, subprocess.SubprocessError):
        return []
    if cp.returncode != 0:
        return []
    out: list[Path] = []
    for line in (cp.stdout or "").splitlines():
        if line.startswith("worktree "):
            out.append(Path(line[len("worktree "):].strip()))
    return out


# ---------- tmux ----------


@dataclass
class TmuxResult:
    ok: bool
    session_name: str = ""
    error: str = ""


def tmux_supported() -> bool:
    """Round 136: True only on POSIX with `tmux` on PATH."""
    if sys.platform.startswith("win"):
        return False
    return shutil.which("tmux") is not None


def launch_tmux_session(
    *, cwd: Path, session_name: str, command: list[str],
) -> TmuxResult:
    """Round 136: detach a new tmux session running `command`
    inside `cwd`. No-op + clear error message when tmux isn't
    available."""
    if not tmux_supported():
        return TmuxResult(
            ok=False,
            error="tmux not available on this system",
        )
    cmd = [
        "tmux", "new-session", "-d",
        "-s", session_name,
        "-c", str(cwd),
        *command,
    ]
    cp = subprocess.run(
        cmd, capture_output=True, text=True, check=False,
    )
    if cp.returncode != 0:
        return TmuxResult(
            ok=False,
            error=f"tmux failed: {cp.stderr.strip()}",
        )
    return TmuxResult(ok=True, session_name=session_name)


# ---------- summary banners ----------


def worktree_banner(h: WorktreeHandle) -> str:
    return (
        f"worktree session\n"
        f"  branch: {h.branch}\n"
        f"  path:   {h.path}\n"
        f"  base:   {h.base_repo}\n"
        + ("  (kept on exit)" if h.keep else "  (cleaned up on exit)")
    )


def tmux_banner(r: TmuxResult) -> str:
    if r.ok:
        return (
            f"tmux session ready: {r.session_name}\n"
            f"  attach with: tmux attach -t {r.session_name}"
        )
    return f"tmux unavailable: {r.error}"
