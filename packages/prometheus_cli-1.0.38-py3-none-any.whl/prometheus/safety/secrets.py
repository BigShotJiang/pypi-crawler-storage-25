"""Read-side defense against accidental secret leakage to the LLM.

Two layers:

1. **Path denylist** — blocks reads from a curated list of common
   secret paths (~/.ssh/, ~/.aws/, ~/.gnupg/, /proc/<pid>/environ,
   .env*, *.pem, *.key) before the file is ever opened. Users can
   override per-call with an explicit /allow list, but the default
   denies them silently with a clear message back to the model.

2. **Regex scrubber** — for files / bash output that ARE legitimately
   read but happen to contain tokens, replace them with `<redacted:KIND>`
   markers before sending to the LLM. Catches the common patterns:
   AWS access keys, GitHub tokens, OpenAI keys, JWTs, private-key blocks.

This addresses Claude Code's own documented gap (Issues #44868, #25053,
#14300) where .env contents got echoed into the conversation.
"""
from __future__ import annotations

import os
import re
from pathlib import Path


# Path-prefix denylist. Match by absolute resolved path.
_HOME = Path.home()
_DEFAULT_DENY_PREFIXES: list[Path] = [
    _HOME / ".ssh",
    _HOME / ".aws",
    _HOME / ".gnupg",
    _HOME / ".config" / "gh" / "hosts.yml",
    _HOME / ".netrc",
    _HOME / ".pypirc",
    _HOME / ".docker" / "config.json",
    _HOME / ".kube" / "config",
    _HOME / ".prometheus" / "credentials",
    Path("/proc"),  # /proc/<pid>/environ etc. (Linux)
    Path("/etc/shadow"),
]
# Filename-suffix denylist (anywhere in the tree).
_DEFAULT_DENY_SUFFIXES = (
    ".pem", ".key", ".keystore", ".p12", ".pfx", ".jks",
)
# Filename-glob denylist.
_DEFAULT_DENY_NAMES = (".env", ".env.local", ".env.production",
                      ".env.development", ".env.test", "credentials",
                      "credentials.json", ".credentials.json",
                      "id_rsa", "id_ed25519", "id_ecdsa", "id_dsa",
                      ".npmrc")


def is_secret_path(path: Path) -> tuple[bool, str]:
    """Returns (is_secret, reason). Reason is empty when not a secret."""
    try:
        rp = path.resolve()
    except Exception:
        rp = path
    # /proc, /etc/shadow, etc.
    for deny in _DEFAULT_DENY_PREFIXES:
        try:
            if rp == deny or rp.is_relative_to(deny):
                return True, f"path under {deny}"
        except (ValueError, OSError):
            pass
    name = rp.name.lower()
    for deny in _DEFAULT_DENY_NAMES:
        if name == deny.lower() or name.startswith(deny.lower() + "."):
            return True, f"filename {deny!r}"
    for suf in _DEFAULT_DENY_SUFFIXES:
        if name.endswith(suf):
            return True, f"suffix {suf!r}"
    return False, ""


# Regex patterns that indicate a token. Every match is replaced with
# <redacted:KIND> in any text the model would see.
# Bounded {min,max} on every token-shape pattern so a 10MB string of
# `sk-` + alphanumerics can't ReDoS the redactor (audit P1). 200 chars
# is a comfortable upper bound — every real-world API token fits in
# ~100 chars, so capping at 200 catches all of them with no false
# negatives.
_MAX_TOKEN_LEN = 200

_REDACT_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("aws-key",   re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("aws-key",   re.compile(r"\bASIA[0-9A-Z]{16}\b")),
    ("aws-secret", re.compile(r"(?<![A-Za-z0-9/+=])[A-Za-z0-9/+=]{40}(?![A-Za-z0-9/+=])(?=.*aws|secret|access)", re.I)),
    ("github",    re.compile(rf"\bgh[pousr]_[A-Za-z0-9]{{36,{_MAX_TOKEN_LEN}}}\b")),
    # ORDER MATTERS: anthropic/openrouter must match BEFORE openai or
    # the broad "sk-..." pattern eats the more-specific prefix.
    ("anthropic", re.compile(rf"\bsk-ant-[A-Za-z0-9_-]{{20,{_MAX_TOKEN_LEN}}}\b")),
    ("openrouter",re.compile(rf"\bsk-or-[A-Za-z0-9_-]{{20,{_MAX_TOKEN_LEN}}}\b")),
    ("openai",    re.compile(rf"\bsk-(?!ant-|or-)[A-Za-z0-9_-]{{20,{_MAX_TOKEN_LEN}}}\b")),
    ("slack",     re.compile(rf"\bxox[baprs]-[A-Za-z0-9-]{{20,{_MAX_TOKEN_LEN}}}\b")),
    ("stripe",    re.compile(rf"\b(?:sk|pk|rk)_(?:test|live)_[A-Za-z0-9]{{20,{_MAX_TOKEN_LEN}}}\b")),
    ("jwt",       re.compile(rf"\beyJ[A-Za-z0-9_-]{{4,{_MAX_TOKEN_LEN}}}\.[A-Za-z0-9_-]{{4,{_MAX_TOKEN_LEN}}}\.[A-Za-z0-9_-]{{4,{_MAX_TOKEN_LEN}}}\b")),
    ("private-key", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----")),
    ("rsa-pub",   re.compile(r"-----BEGIN OPENSSH PRIVATE KEY-----[\s\S]*?-----END OPENSSH PRIVATE KEY-----")),
]


def redact_secrets(text: str) -> tuple[str, int]:
    """Scrub known secret patterns out of `text`. Returns (cleaned, n_redactions)."""
    n = 0
    for kind, rx in _REDACT_PATTERNS:
        def _sub(_m, _kind=kind):
            nonlocal n
            n += 1
            return f"<redacted:{_kind}>"
        text = rx.sub(_sub, text)
    return text, n
