"""Round 161 — Hardening 5: Spotify-style verification loop.

Research: Spotify ships every agent-proposed change through
deterministic verifiers (formatters, build, tests) plus an LLM
judge that vetoes ~25% of changes. The agent course-corrects ~50%
of the time on judge feedback. Result: functionally-incorrect code
doesn't reach production.

This module ships two layers:

  • DeterministicVerifier: syntax check (py_compile), import check
    (python -c "import x"), and a relevant-test runner. All real
    subprocess calls — no mocks.

  • ScopeJudge: a *deterministic* judge (no LLM call) that compares
    the changed-file set against the user's stated scope. Flags
    edits to files the user did not name. Production deployments
    can swap this for an LLM judge by implementing the same
    `judge(...)` signature.

The two layers compose into `verify_change(...)` which returns a
single `VerificationResult` carrying the verdict, the reason, and
optional revision feedback the agent loop can inject as a system
reminder.
"""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class VerificationResult:
    ok: bool
    syntax_ok: bool = True
    import_ok: bool = True
    tests_ok: bool = True
    scope_ok: bool = True
    reason: str = ""
    feedback: str = ""
    """The system-reminder text the agent loop should inject when the
    judge / verifiers veto. Empty when ok=True."""
    test_summary: str = ""

    def render(self) -> str:
        if self.ok:
            return "✓ Verification passed."
        return f"⚠️ Verification failed: {self.reason}\n{self.feedback}"


@dataclass
class ChangeRequest:
    """One change proposal the agent wants to commit."""
    path: str
    new_contents: str
    user_intent: str
    """The user's original request — what scope they asked for."""
    declared_files: tuple[str, ...] = ()
    """Files the user named or the agent's plan listed. The judge
    flags edits outside this set."""


# ---- Layer 1: deterministic verifiers ---------------------------------


def syntax_check(path: str, contents: str) -> tuple[bool, str]:
    """Run python -m py_compile on a temp copy. Returns (ok, error)."""
    if not path.endswith(".py"):
        return True, ""  # only Python is gated by syntax check today
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", delete=False, encoding="utf-8",
    ) as f:
        f.write(contents)
        tmp = f.name
    try:
        proc = subprocess.run(
            [sys.executable, "-m", "py_compile", tmp],
            capture_output=True, text=True, timeout=15,
        )
        if proc.returncode == 0:
            return True, ""
        return False, (proc.stderr or proc.stdout or "py_compile failed").strip()[:600]
    finally:
        try: os.unlink(tmp)
        except OSError: pass


def import_check(module_path: str, contents: str) -> tuple[bool, str]:
    """Try to import the module. Writes the proposed contents to a
    temp dir, runs `python -c "import <basename>"` with that dir on
    sys.path. Catches missing-imports / NameError / IndentationError
    / etc. that py_compile lets through."""
    if not module_path.endswith(".py"):
        return True, ""
    base = Path(module_path).stem
    if not base or base.startswith(("_", ".")):
        return True, ""  # private modules / __init__.py — skip
    with tempfile.TemporaryDirectory() as td:
        target = Path(td) / f"{base}.py"
        target.write_text(contents, encoding="utf-8")
        proc = subprocess.run(
            [sys.executable, "-c", f"import {base}"],
            capture_output=True, text=True, timeout=15,
            cwd=td, env={**os.environ, "PYTHONPATH": td},
        )
        if proc.returncode == 0:
            return True, ""
        return False, (proc.stderr or proc.stdout or "import failed").strip()[:600]


def relevant_tests(workdir: Path, module_path: str) -> Path | None:
    """Find a test file that almost certainly covers `module_path`."""
    base = Path(module_path).stem
    if not base:
        return None
    candidates = [
        workdir / f"test_{base}.py",
        workdir / "tests" / f"test_{base}.py",
        workdir / "tests" / f"test_{base}_basic.py",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


def run_tests(test_path: Path, timeout_s: float = 60.0) -> tuple[bool, str]:
    if not test_path.exists():
        return True, "(no relevant tests)"
    try:
        proc = subprocess.run(
            [sys.executable, "-m", "pytest", "-q", str(test_path)],
            capture_output=True, text=True, timeout=timeout_s,
            cwd=str(test_path.parent),
        )
        ok = proc.returncode == 0
        tail = (proc.stdout or proc.stderr or "")[-600:].strip()
        return ok, tail or ("ok" if ok else "tests failed")
    except subprocess.TimeoutExpired:
        return False, f"tests timed out after {timeout_s}s"


# ---- Layer 2: scope judge (deterministic by default) ------------------


def scope_judge(req: ChangeRequest) -> tuple[bool, str]:
    """Returns (ok, reason). The deterministic judge compares the
    target path against the declared scope; if the path isn't in the
    declared list AND the user's intent doesn't name it, veto.

    To swap in a real LLM judge, replace this function with one that
    issues a single LLM call asking the same questions:
      - does the change match the user's request?
      - does it modify files outside the stated scope?
      - does it introduce obvious bugs or security issues?
    """
    target = req.path.replace("\\", "/")
    declared = {d.replace("\\", "/") for d in req.declared_files}
    intent = (req.user_intent or "").lower()
    # If the user never declared a scope explicitly, allow all.
    if not declared and not intent:
        return True, ""
    # Direct match against the declared list.
    if any(target == d or target.endswith("/" + d) for d in declared):
        return True, ""
    # Mention in the user prompt.
    if Path(target).name.lower() in intent:
        return True, ""
    if Path(target).stem.lower() in intent:
        return True, ""
    # Out of scope.
    return False, (
        f"target `{target}` is outside the declared scope. The user "
        f"asked about {sorted(declared) or '[no explicit scope]'} and "
        f"did not name `{target}`. Confirm before editing."
    )


# ---- composed verification --------------------------------------------


def verify_change(
    req: ChangeRequest,
    *,
    workdir: Path | None = None,
    skip_tests: bool = False,
) -> VerificationResult:
    """Run all four checks. Short-circuits on first hard failure
    (syntax) but reports every layer's verdict on the result."""
    syn_ok, syn_err = syntax_check(req.path, req.new_contents)
    if not syn_ok:
        return VerificationResult(
            ok=False, syntax_ok=False, reason=f"syntax: {syn_err}",
            feedback=(
                "The proposed change has a Python syntax error. Fix the "
                "syntax and re-emit. Do not commit code that won't parse."
            ),
        )
    imp_ok, imp_err = import_check(req.path, req.new_contents)
    if not imp_ok:
        return VerificationResult(
            ok=False, syntax_ok=True, import_ok=False,
            reason=f"import: {imp_err}",
            feedback=(
                "The proposed change parses but doesn't import cleanly "
                "(missing import, undefined name, indentation drift). "
                "Fix and re-emit."
            ),
        )
    sj_ok, sj_reason = scope_judge(req)
    if not sj_ok:
        return VerificationResult(
            ok=False, syntax_ok=True, import_ok=True, scope_ok=False,
            reason=sj_reason,
            feedback=(
                "The judge vetoed this change because it edits a file "
                "outside the declared scope. Either restrict the change "
                "to the declared files OR ask the user to expand scope."
            ),
        )
    test_summary = "(skipped)"
    if not skip_tests and workdir is not None:
        tp = relevant_tests(workdir, req.path)
        if tp is not None:
            t_ok, t_tail = run_tests(tp)
            test_summary = t_tail
            if not t_ok:
                return VerificationResult(
                    ok=False, syntax_ok=True, import_ok=True, scope_ok=True,
                    tests_ok=False, reason=f"tests: {t_tail[:200]}",
                    feedback=(
                        "Relevant tests failed after this change. The "
                        "agent should diagnose the failure and revise — "
                        "do not commit a regression."
                    ),
                    test_summary=test_summary,
                )
    return VerificationResult(
        ok=True, test_summary=test_summary,
        reason="all checks passed",
    )
