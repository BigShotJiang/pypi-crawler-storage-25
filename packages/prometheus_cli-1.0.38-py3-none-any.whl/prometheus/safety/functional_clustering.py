"""Round 161 — Hardening 4: functional clustering for hallucination
elimination.

Research: sample N candidate solutions, execute each with the same
inputs, cluster by I/O behavior. The largest cluster's mass is a
confidence estimate; small confidence ⇒ flag for human review. Drops
hallucination error rate from ~65% to 0% at conservative thresholds.

This module owns the *clustering + confidence* primitives. It does
NOT generate candidates itself — generation is the agent loop's job
(it would call N free models with varied temperatures). What this
module guarantees is:

  • Each candidate is executed in an isolated subprocess (so an
    infinite-loop candidate or `os.system("rm -rf")` candidate can't
    take down the parent).
  • Outputs are clustered by exact equality of stdout/exit/exception.
  • The largest cluster's mass is reported as a confidence score.
  • A `Verdict` carries the chosen winning code OR a "low confidence
    — flag for review" message.

The subprocess sandbox is intentionally small: a fresh `python -c`
with the candidate written to a temp file, run with a 5-second timeout
and no stdin. Good enough for catching most "candidate runs differently
than the cluster" bugs; for stronger isolation use a container.
"""
from __future__ import annotations

import hashlib
import os
import subprocess
import sys
import tempfile
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path


@dataclass(frozen=True)
class CandidateRun:
    """One execution of one candidate against one test input."""
    candidate_id: str       # short hash
    test_label: str         # human-readable
    stdout: str
    stderr_tail: str        # last 200 chars only
    exit_code: int
    timed_out: bool


@dataclass
class ClusterReport:
    """Result of clustering N candidates against M test inputs."""
    candidate_count: int
    test_count: int
    clusters: list[list[str]]
    """Lists of candidate_ids; first list is the largest cluster."""
    largest_size: int
    confidence: float       # largest_size / candidate_count
    winning_candidate_id: str | None
    """The candidate_id from the largest cluster — pick any from the
    cluster, since they're behaviorally identical."""
    flagged: bool           # True if confidence < threshold
    threshold: float
    notes: list[str] = field(default_factory=list)

    def render(self) -> str:
        if self.flagged:
            return (
                f"⚠️ Low confidence ({self.confidence:.0%} of "
                f"{self.candidate_count} candidates clustered the same way). "
                f"Multiple candidate solutions produced different results. "
                f"Flag for human review."
            )
        return (
            f"✓ Confidence {self.confidence:.0%} "
            f"({self.largest_size}/{self.candidate_count} candidates "
            f"clustered). Winner: {self.winning_candidate_id}"
        )


def _candidate_id(code: str) -> str:
    return hashlib.sha1(code.encode("utf-8")).hexdigest()[:8]


def execute_candidate(
    code: str, *, test_label: str, test_input: str, timeout_s: float = 5.0,
) -> CandidateRun:
    """Run `code` in a subprocess. `test_input` is the script we
    append to `code` to drive a deterministic check (e.g. a function
    call followed by `print(result)`)."""
    cid = _candidate_id(code + "::" + test_label)
    full = code + "\n\n# --- test harness ---\n" + test_input + "\n"
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", delete=False, encoding="utf-8",
    ) as f:
        f.write(full)
        path = f.name
    try:
        try:
            proc = subprocess.run(
                [sys.executable, path],
                capture_output=True, text=True, timeout=timeout_s,
                cwd=tempfile.gettempdir(),
            )
            stdout = (proc.stdout or "").rstrip()
            stderr_tail = (proc.stderr or "")[-200:].rstrip()
            return CandidateRun(
                candidate_id=cid, test_label=test_label,
                stdout=stdout, stderr_tail=stderr_tail,
                exit_code=proc.returncode, timed_out=False,
            )
        except subprocess.TimeoutExpired:
            return CandidateRun(
                candidate_id=cid, test_label=test_label,
                stdout="", stderr_tail="(timed out)",
                exit_code=-1, timed_out=True,
            )
    finally:
        try: os.unlink(path)
        except OSError: pass


def _signature(runs: list[CandidateRun]) -> str:
    """Behavioral fingerprint of a candidate across all tests. Two
    candidates with identical signatures have identical I/O."""
    parts = []
    for r in sorted(runs, key=lambda x: x.test_label):
        parts.append(f"{r.test_label}|{r.exit_code}|{int(r.timed_out)}|{r.stdout}")
    blob = "\n".join(parts)
    return hashlib.sha1(blob.encode("utf-8")).hexdigest()[:12]


def cluster(
    candidates: dict[str, str],
    tests: list[tuple[str, str]],
    *,
    threshold: float = 0.80,
    timeout_s: float = 5.0,
) -> ClusterReport:
    """Run every candidate against every test and cluster by signature.

    `candidates` is `{candidate_id: source_code}`.
    `tests` is a list of `(label, harness_code)`.
    """
    if not candidates:
        return ClusterReport(
            candidate_count=0, test_count=len(tests),
            clusters=[], largest_size=0, confidence=0.0,
            winning_candidate_id=None, flagged=True, threshold=threshold,
            notes=["no candidates supplied"],
        )
    # signature → list of candidate_ids
    by_sig: dict[str, list[str]] = {}
    notes: list[str] = []
    for cid, code in candidates.items():
        runs = [
            execute_candidate(code, test_label=t[0], test_input=t[1],
                              timeout_s=timeout_s)
            for t in tests
        ]
        sig = _signature(runs)
        by_sig.setdefault(sig, []).append(cid)
        # Surface infrastructural notes.
        if any(r.timed_out for r in runs):
            notes.append(f"{cid}: timed out on at least one test")
    clusters = sorted(by_sig.values(), key=lambda lst: -len(lst))
    largest = clusters[0] if clusters else []
    largest_size = len(largest)
    n = len(candidates)
    confidence = largest_size / n if n else 0.0
    winner = largest[0] if largest else None
    return ClusterReport(
        candidate_count=n, test_count=len(tests),
        clusters=clusters, largest_size=largest_size,
        confidence=confidence, winning_candidate_id=winner,
        flagged=(confidence < threshold), threshold=threshold,
        notes=notes,
    )


# ---- helpers for the agent loop ---------------------------------------


def make_candidate_id(code: str) -> str:
    """Public alias of _candidate_id so callers don't reach into the
    private name."""
    return _candidate_id(code)
