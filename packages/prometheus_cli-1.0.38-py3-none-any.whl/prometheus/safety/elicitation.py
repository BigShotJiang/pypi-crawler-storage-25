"""Round 110: Elicitation sentinel events.

When an MCP server requests user input mid-tool-call, two events
fire:

  * `Elicitation`        — fires WITH the request, before the
                           user is prompted. Sees the request
                           schema. Can block.
  * `ElicitationResult`  — fires AFTER the user responds, before
                           the response goes back to the MCP
                           server. Sees the user's reply. Can
                           block.

Both events are already in the `SentinelEvent` enum (round 99)
and `BLOCKING_EVENTS` set. This module wraps the firing in a
single helper that the MCP host can call as one line.

Real MCP transport that triggers these events lands later; this
module's contract is stable so callers can wire it now.
"""
from __future__ import annotations

from typing import Any, Optional

from prometheus.safety.sentinels import (
    SentinelDecision,
    SentinelEvent,
    SentinelRegistry,
    fire_event,
)


async def fire_elicitation(
    registry: SentinelRegistry,
    *,
    server_name: str,
    tool_name: str,
    elicitation_schema: dict[str, Any],
    session_id: str = "",
    cwd: str = "",
    permission_mode: str = "",
) -> tuple[SentinelDecision, list]:
    """Fire `Elicitation` event before the user is prompted.

    Returns `(final_decision, results)`. When `final_decision`
    is `deny`, the MCP host should refuse the elicitation
    instead of prompting the user — useful for projects that
    want to block sensitive input requests."""
    return await fire_event(
        registry,
        SentinelEvent.ELICITATION,
        match_value=tool_name or server_name,
        session_id=session_id,
        cwd=cwd,
        permission_mode=permission_mode,
        tool_name=tool_name,
        payload_extra={
            "server_name": server_name,
            "elicitation_schema": elicitation_schema,
        },
    )


async def fire_elicitation_result(
    registry: SentinelRegistry,
    *,
    server_name: str,
    tool_name: str,
    user_response: Any,
    session_id: str = "",
    cwd: str = "",
    permission_mode: str = "",
) -> tuple[SentinelDecision, list]:
    """Fire `ElicitationResult` after the user responds, before
    the response is sent back to the MCP server.

    On deny: the host MUST NOT forward the response. Useful for
    redacting secrets the user accidentally typed, or for
    rejecting responses that violate project policy.
    """
    # The schema lets the recipient inspect what the user actually
    # typed. We intentionally do NOT capture sensitive values into
    # the audit log — the sentinel's command output is what
    # decides whether to deny.
    return await fire_event(
        registry,
        SentinelEvent.ELICITATION_RESULT,
        match_value=tool_name or server_name,
        session_id=session_id,
        cwd=cwd,
        permission_mode=permission_mode,
        tool_name=tool_name,
        payload_extra={
            "server_name": server_name,
            "user_response": user_response,
        },
    )
