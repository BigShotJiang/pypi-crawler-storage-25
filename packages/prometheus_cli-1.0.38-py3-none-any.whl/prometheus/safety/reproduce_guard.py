"""Round 160 — Failure-Mode 1: Reproduce-Before-Patching guard.

Research (ETH Zurich "Fixing Correct Code"): coding agents modify
already-correct code over 50% of the time because they skip the
reproduction step. Sonnet 4.6 abstains correctly only ~65% of the
time. The fix is requiring the agent to reproduce the issue first.

This module:
  • Classifies whether the user prompt looks like a bug-fix request.
  • Builds an addendum to the system prompt mandating the
    reproduce-first protocol when classification is True.
  • Provides `should_abstain()` that callers can use to render
    "this appears to already be resolved" when reproduction fails.

The classifier is keyword-based and intentionally conservative —
false positives just produce a harmless reminder; false negatives
fall back to the agent's normal behavior.
"""
from __future__ import annotations

import re
from dataclasses import dataclass


# Phrases / patterns that strongly imply "fix this bug for me."
_BUG_REPORT_RX = re.compile(
    r"\b("
    r"i'?m\s+getting|i\s+see|getting|hit|hitting|crashed|crashes|"
    r"throws?|throwing|raises?|raising|fails?|failing|broken|broke|"
    r"bug|error|exception|stack\s*trace|traceback|"
    r"keyerror|valueerror|typeerror|attributeerror|importerror|"
    r"modulenotfounderror|filenotfounderror|permissionerror|"
    r"500\b|502\b|503\b|504\b"
    r")\b",
    re.IGNORECASE,
)

# Imperative "fix it" directives. Inner alternatives use `(?:...)` so
# `re.findall` returns plain strings, not tuples.
_FIX_DIRECTIVE_RX = re.compile(
    r"\b("
    r"fix|repair|resolve|patch|debug|"
    r"track\s+down|figure\s+out\s+why|find\s+(?:the|this)\s+bug"
    r")\b",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class ReproduceVerdict:
    is_bug_fix: bool
    """True if the prompt reads like a bug report or fix-this-please."""
    has_repro_steps: bool
    """True if the user supplied something we can use to trigger it."""
    matched_phrases: tuple[str, ...]


def classify(prompt: str) -> ReproduceVerdict:
    """Classify a user prompt for the reproduce-before-patch protocol.

    `is_bug_fix` is True if BOTH a bug-symptom phrase AND a fix-it
    directive appear, OR if the prompt explicitly cites an error type
    (e.g. `KeyError`). Either signal alone is too noisy on its own.
    """
    if not prompt:
        return ReproduceVerdict(False, False, ())
    bug_hits = _BUG_REPORT_RX.findall(prompt) or []
    fix_hits = _FIX_DIRECTIVE_RX.findall(prompt) or []
    matched = tuple({*(s.lower() for s in bug_hits), *(s.lower() for s in fix_hits)})
    # Strong signal: error-type token present (KeyError, ValueError, ...).
    has_error_type = bool(re.search(
        r"\b\w*(?:Error|Exception)\b",
        prompt,
    ))
    is_bug_fix = bool(
        (bug_hits and fix_hits)
        or has_error_type
        or "stack trace" in prompt.lower()
        or "traceback" in prompt.lower()
    )
    # Repro steps: user gave us something concrete (file:line, command,
    # or "to reproduce" / "steps:" header).
    has_repro = any(s in prompt.lower() for s in (
        "to reproduce", "steps:", "repro:", "reproduce:", "i ran ",
    )) or bool(re.search(r"\.py:\d+", prompt) or re.search(r"\.ts:\d+", prompt))
    return ReproduceVerdict(
        is_bug_fix=is_bug_fix,
        has_repro_steps=has_repro,
        matched_phrases=matched,
    )


# Plain-language addendum the agent loop appends to the system prompt
# whenever `classify(...).is_bug_fix` is True. Wording mirrors the
# round-95 read-before-edit note so the model recognises the shape.
SYSTEM_PROMPT_ADDENDUM = (
    "REPRODUCE BEFORE PATCHING (round 160 / FM1).\n"
    "Research (ETH Zurich) shows agents modify already-correct code over\n"
    "50% of the time when they skip reproduction. When the user reports a\n"
    "bug or asks for a fix, you MUST do this — in this order — before\n"
    "writing or editing any code:\n"
    "  1. Search for reproduction steps in the user's message and any\n"
    "     attached logs / file:line references.\n"
    "  2. Attempt to trigger the reported bug yourself — read the cited\n"
    "     file, run the cited command, exercise the cited path. If the\n"
    "     user did not supply steps, propose the cheapest possible repro\n"
    "     (a one-line script, a unit test, a grep) and run it.\n"
    "  3. Only propose a fix once you have observed the bug. If the\n"
    "     symptom does not reproduce on HEAD, REPORT 'this appears to\n"
    "     already be resolved' and stop. Do not invent fixes for code\n"
    "     that already works — that is the failure mode this protocol\n"
    "     is here to prevent.\n"
    "If reproduction is impossible (e.g. the user is on a remote host),\n"
    "say so explicitly and ask the user for a minimal repro before\n"
    "writing any fix."
)


def render_addendum(verdict: ReproduceVerdict) -> str:
    """Return the addendum text iff the verdict says it's a bug-fix prompt."""
    if not verdict.is_bug_fix:
        return ""
    return SYSTEM_PROMPT_ADDENDUM


def should_abstain(*, repro_attempted: bool, repro_succeeded: bool) -> bool:
    """The "abstain" signal callers can use to render the
    "appears to already be resolved" message."""
    return bool(repro_attempted and not repro_succeeded)


ABSTAIN_NOTICE = (
    "The reported symptom does not reproduce on the current code. "
    "This appears to already be resolved. No fix proposed. "
    "Confirm you're running the current version (`pip show prometheus-cli`) "
    "and re-run with `PROMETHEUS_LOG_LEVEL=DEBUG` if the symptom returns."
)
