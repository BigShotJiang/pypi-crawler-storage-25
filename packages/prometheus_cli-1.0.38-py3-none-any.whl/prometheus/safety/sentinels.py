"""Round 99 (Phase 2): Sentinel Hooks engine.

A Sentinel is a deterministic automation script that fires at a
specific moment in PrometheUS's execution lifecycle. They are
GUARANTEES, not suggestions — if a `PreToolUse` Sentinel returns
"deny", the tool call is blocked.

Five Sentinel types:

  * `command`   — runs a shell command. Receives JSON via stdin.
                  Exit 0 = allow, exit 2 = block. Workhorse.
  * `http`      — POSTs the event JSON to a webhook URL.
  * `prompt`    — single-turn LLM evaluation for judgment calls
                  that don't need tool access.
  * `mcp_tool`  — invokes an MCP server tool directly.
  * `agent`     — spawns a Cohort agent (round 101) with read +
                  search + bash for verification work.

Twenty-eight lifecycle events (see `SentinelEvent`). The engine
fires every applicable Sentinel for an event, ordered by
configuration order, and applies the strictest decision (deny
overrides allow).

Sentinel sources (precedence order):
  1. Component-scoped: aptitude/cohort/blade frontmatter
     `hooks:` blocks (round 100/101 wires this).
  2. Project: `<workdir>/.prometheus/sentinels.json` (Trust-gated).
  3. Project legacy: `<workdir>/.prometheus/hooks.json` (the old
     pre-99 format; auto-upgraded into Sentinel records).
  4. User: `~/.prometheus/sentinels.json`.
  5. User legacy: `~/.prometheus/hooks.json`.
  6. Forge kits: `${FORGE_ROOT}/sentinels.json` (round 100).
  7. Enterprise: `/etc/prometheus/sentinels.json` (managed policy).

Exit-code semantics (Command sentinel):
  * exit 0 → success; parse stdout for optional JSON decision.
  * exit 2 → block. stderr surfaces to the model as the reason.
  * any other non-zero → fail-open; logged but doesn't block.

Backwards compatibility: the legacy `prometheus/safety/hooks.py`
module remains importable. Existing `.prometheus/hooks.json`
files load as Sentinels automatically — no user migration needed.
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import subprocess
import sys
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Optional


# ---------- 28 lifecycle events ----------


class SentinelEvent(str, Enum):
    """The 28 events PrometheUS Sentinels can hook. Subclass of str
    so config files can reference events by their string form."""
    SESSION_START = "SessionStart"
    SESSION_END = "SessionEnd"
    USER_PROMPT_SUBMIT = "UserPromptSubmit"
    USER_PROMPT_EXPANSION = "UserPromptExpansion"
    PRE_TOOL_USE = "PreToolUse"
    POST_TOOL_USE = "PostToolUse"
    POST_TOOL_USE_FAILURE = "PostToolUseFailure"
    POST_TOOL_BATCH = "PostToolBatch"
    PERMISSION_REQUEST = "PermissionRequest"
    PERMISSION_DENIED = "PermissionDenied"
    NOTIFICATION = "Notification"
    SUBAGENT_START = "SubagentStart"
    SUBAGENT_STOP = "SubagentStop"
    STOP = "Stop"
    STOP_FAILURE = "StopFailure"
    PRE_COMPACT = "PreCompact"
    POST_COMPACT = "PostCompact"
    WORKTREE_CREATE = "WorktreeCreate"
    WORKTREE_REMOVE = "WorktreeRemove"
    FILE_CHANGED = "FileChanged"
    CWD_CHANGED = "CwdChanged"
    CONFIG_CHANGE = "ConfigChange"
    INSTRUCTIONS_LOADED = "InstructionsLoaded"
    TASK_CREATED = "TaskCreated"
    TASK_COMPLETED = "TaskCompleted"
    ELICITATION = "Elicitation"
    ELICITATION_RESULT = "ElicitationResult"
    TEAMMATE_IDLE = "TeammateIdle"


# Events that CAN BLOCK the underlying action when a Sentinel
# returns deny. The runtime checks this set before honoring any
# block decision — non-blocking events get logged but never
# prevent the action from happening.
BLOCKING_EVENTS = frozenset({
    SentinelEvent.USER_PROMPT_SUBMIT,
    SentinelEvent.PRE_TOOL_USE,
    SentinelEvent.PERMISSION_REQUEST,
    SentinelEvent.SUBAGENT_STOP,
    SentinelEvent.STOP,
    SentinelEvent.WORKTREE_CREATE,
    SentinelEvent.CONFIG_CHANGE,
    SentinelEvent.TASK_COMPLETED,
    SentinelEvent.ELICITATION,
    SentinelEvent.ELICITATION_RESULT,
    SentinelEvent.TEAMMATE_IDLE,
    SentinelEvent.USER_PROMPT_EXPANSION,
})


# ---------- 5 sentinel types ----------


class SentinelType(str, Enum):
    COMMAND = "command"
    HTTP = "http"
    PROMPT = "prompt"
    MCP_TOOL = "mcp_tool"
    AGENT = "agent"


# ---------- decision record ----------


class SentinelDecision(str, Enum):
    """Outcome of a single Sentinel run. The engine collapses the
    list-of-decisions into one final answer using the rule:
    `deny` always wins; otherwise the last non-noop decision wins."""
    ALLOW = "allow"
    DENY = "deny"
    NOOP = "noop"
    ERROR = "error"   # Sentinel itself failed; treated as fail-open.


@dataclass
class SentinelResult:
    decision: SentinelDecision
    reason: str = ""             # surfaced to the model on deny
    stdout: str = ""             # captured for audit
    stderr: str = ""
    exit_code: int = 0
    duration_s: float = 0.0
    sentinel_id: str = ""        # for audit / debug
    fail_open: bool = False      # True when error → allow


# ---------- sentinel record ----------


@dataclass
class Sentinel:
    """One configured Sentinel — type + event + matcher + payload.
    Loaded from JSON, lives in the registry, runs on demand."""
    type: SentinelType
    event: SentinelEvent
    matcher: re.Pattern                    # `tool_name` / `event_kind` regex
    timeout_s: int = 30
    once_per_session: bool = False         # `once: true` in config

    # Type-specific fields. Only the field for this Sentinel's type
    # is meaningful; the rest are ignored.
    command: str = ""                      # type=command
    url: str = ""                          # type=http
    prompt: str = ""                       # type=prompt
    mcp_server: str = ""                   # type=mcp_tool
    mcp_tool: str = ""                     # type=mcp_tool
    agent_prompt: str = ""                 # type=agent

    # Provenance — surfaces in audit log, helps users find the source.
    source: str = "user"                   # `project` | `user` | `forge` | `enterprise` | `component`
    source_path: str = ""                  # absolute path to sentinels.json or component file
    raw_id: str = ""                       # auto-generated short id

    # Runtime state.
    has_fired_this_session: bool = False


# ---------- input envelope ----------


def _build_event_payload(
    event: SentinelEvent,
    *,
    session_id: str = "",
    cwd: str = "",
    permission_mode: str = "",
    tool_name: str = "",
    tool_input: Optional[dict[str, Any]] = None,
    tool_result: Any = None,
    tool_use_id: str = "",
    agent_id: str = "",
    agent_type: str = "main",
    worktree: str = "",
    last_assistant_message: str = "",
    user_prompt: str = "",
    extra: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    """Build the event JSON envelope every Sentinel receives.
    Schema mirrors Claude Code's hook input so existing hook
    scripts work unchanged."""
    payload: dict[str, Any] = {
        "session_id": session_id,
        "cwd": cwd,
        "permission_mode": permission_mode,
        "hook_event_name": str(event.value),
        "agent_type": agent_type,
    }
    if tool_name:
        payload["tool_name"] = tool_name
    if tool_input is not None:
        payload["tool_input"] = tool_input
    if tool_result is not None:
        # Stringify tool result to keep the JSON envelope small.
        try:
            payload["tool_result"] = (
                tool_result if isinstance(tool_result, (str, int, float, bool, list, dict))
                else str(tool_result)
            )
        except Exception:
            payload["tool_result"] = "<unserializable>"
    if tool_use_id:
        payload["tool_use_id"] = tool_use_id
    if agent_id:
        payload["agent_id"] = agent_id
    if worktree:
        payload["worktree"] = worktree
    if last_assistant_message:
        payload["last_assistant_message"] = last_assistant_message[:4000]
    if user_prompt:
        payload["user_prompt"] = user_prompt[:4000]
    if extra:
        for k, v in extra.items():
            if k not in payload:
                payload[k] = v
    return payload


# ---------- spawn helpers ----------


def _spawn_kwargs() -> dict:
    """OS-aware subprocess kwargs that ensure children die with the parent."""
    kw: dict = {}
    if sys.platform == "win32":
        try:
            import subprocess as _sp
            kw["creationflags"] = (
                getattr(_sp, "CREATE_NEW_PROCESS_GROUP", 0)
                | getattr(_sp, "CREATE_NO_WINDOW", 0)
            )
        except Exception:
            pass
    else:
        kw["start_new_session"] = True
    return kw


# ---------- sentinel runners ----------


async def _run_command_sentinel(
    s: Sentinel, payload: dict[str, Any],
) -> SentinelResult:
    """Spawn the configured shell command, pipe payload as stdin
    JSON, collect exit code + stdout + stderr."""
    import time
    started = time.monotonic()
    try:
        proc = await asyncio.create_subprocess_shell(
            s.command,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            **_spawn_kwargs(),
        )
    except Exception as e:
        return SentinelResult(
            decision=SentinelDecision.ERROR,
            reason=f"sentinel spawn failed: {e}",
            sentinel_id=s.raw_id,
            fail_open=True,
            duration_s=time.monotonic() - started,
        )
    try:
        stdin_blob = json.dumps(payload, default=str).encode("utf-8", "replace")
    except Exception:
        stdin_blob = b"{}"
    try:
        out_b, err_b = await asyncio.wait_for(
            proc.communicate(input=stdin_blob),
            timeout=max(1, s.timeout_s),
        )
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except Exception:
            pass
        return SentinelResult(
            decision=SentinelDecision.ERROR,
            reason=f"sentinel timed out after {s.timeout_s}s",
            sentinel_id=s.raw_id,
            fail_open=True,
            duration_s=time.monotonic() - started,
        )
    rc = proc.returncode or 0
    stdout = out_b.decode("utf-8", "replace") if out_b else ""
    stderr = err_b.decode("utf-8", "replace") if err_b else ""
    duration = time.monotonic() - started
    if rc == 0:
        # Optional structured stdout — first line of `{"decision":...}`
        # JSON overrides allow with a richer reason.
        decision = SentinelDecision.ALLOW
        reason = stdout[:200] if stdout else ""
        first = stdout.strip().splitlines()[0] if stdout.strip() else ""
        if first.startswith("{"):
            try:
                obj = json.loads(first)
                d = str(obj.get("decision", "")).lower()
                if d == "deny":
                    decision = SentinelDecision.DENY
                    reason = str(obj.get("reason", "")) or "denied by sentinel"
            except Exception:
                pass
        return SentinelResult(
            decision=decision, reason=reason, stdout=stdout,
            stderr=stderr, exit_code=rc,
            sentinel_id=s.raw_id, duration_s=duration,
        )
    if rc == 2:
        return SentinelResult(
            decision=SentinelDecision.DENY,
            reason=stderr.strip()[:200] or "denied by sentinel (exit 2)",
            stdout=stdout, stderr=stderr, exit_code=rc,
            sentinel_id=s.raw_id, duration_s=duration,
        )
    # Non-zero, non-2 → fail-open per spec.
    return SentinelResult(
        decision=SentinelDecision.ERROR,
        reason=stderr.strip()[:200] or f"sentinel exited rc={rc}",
        stdout=stdout, stderr=stderr, exit_code=rc,
        sentinel_id=s.raw_id, fail_open=True, duration_s=duration,
    )


async def _run_http_sentinel(
    s: Sentinel, payload: dict[str, Any],
) -> SentinelResult:
    """POST event JSON to webhook. Returns ALLOW unless the response
    body has `{"decision": "deny", "reason": "..."}`. Optional —
    soft-fails if httpx is missing."""
    import time
    started = time.monotonic()
    try:
        import httpx
    except ImportError:
        return SentinelResult(
            decision=SentinelDecision.ERROR,
            reason="httpx not installed; HTTP sentinel skipped",
            sentinel_id=s.raw_id, fail_open=True,
            duration_s=time.monotonic() - started,
        )
    try:
        # Round 179: HTTP sentinels respect corporate proxy + custom CA.
        from prometheus.net import net_kwargs
        async with httpx.AsyncClient(
            **net_kwargs(timeout=max(1, s.timeout_s)),
        ) as c:
            r = await c.post(s.url, json=payload)
            r.raise_for_status()
            try:
                obj = r.json() if r.content else {}
            except Exception:
                obj = {}
    except Exception as e:
        return SentinelResult(
            decision=SentinelDecision.ERROR,
            reason=f"HTTP sentinel failed: {e}",
            sentinel_id=s.raw_id, fail_open=True,
            duration_s=time.monotonic() - started,
        )
    duration = time.monotonic() - started
    d = str(obj.get("decision", "")).lower() if isinstance(obj, dict) else ""
    if d == "deny":
        return SentinelResult(
            decision=SentinelDecision.DENY,
            reason=str(obj.get("reason", "")) or "denied by HTTP sentinel",
            stdout=json.dumps(obj)[:400],
            sentinel_id=s.raw_id, duration_s=duration,
        )
    return SentinelResult(
        decision=SentinelDecision.ALLOW,
        stdout=json.dumps(obj)[:400] if isinstance(obj, dict) else "",
        sentinel_id=s.raw_id, duration_s=duration,
    )


async def _run_stub_sentinel(
    s: Sentinel, payload: dict[str, Any],
    kind: str,
) -> SentinelResult:
    """Round 99 stub for `prompt`, `mcp_tool`, and `agent` types.
    Logs the invocation, returns ALLOW. Real implementation lands
    in round 100 (MCP tool sentinel) and round 101 (agent sentinel)."""
    return SentinelResult(
        decision=SentinelDecision.ALLOW,
        reason=f"{kind}-type sentinel ({s.raw_id}) is a stub in round 99 — "
               f"will fully execute in round {{100,101}}",
        sentinel_id=s.raw_id,
    )


# ---------- registry + loader ----------


@dataclass
class SentinelRegistry:
    """In-memory store of all loaded Sentinels. Iterating yields
    them in priority order — component → project → user → forge →
    enterprise."""
    sentinels: list[Sentinel] = field(default_factory=list)

    def add(self, s: Sentinel) -> None:
        self.sentinels.append(s)

    def for_event(
        self,
        event: SentinelEvent,
        *,
        match_value: str = "",
    ) -> list[Sentinel]:
        out: list[Sentinel] = []
        for s in self.sentinels:
            if s.event != event:
                continue
            if match_value and not s.matcher.search(match_value):
                continue
            if s.once_per_session and s.has_fired_this_session:
                continue
            out.append(s)
        return out

    def reset_once_flags(self) -> None:
        """Called on session start so `once: true` Sentinels can
        fire again in a fresh session."""
        for s in self.sentinels:
            s.has_fired_this_session = False


def _compile_matcher(raw: Any) -> re.Pattern:
    """Accept exact string, regex, wildcard `*`, MCP pattern, etc."""
    s = str(raw or "").strip()
    if not s or s == "*":
        return re.compile(".*")
    # Treat as regex; if compile fails, escape and try as literal.
    try:
        return re.compile(s)
    except re.error:
        return re.compile(re.escape(s))


def _parse_event(raw: Any) -> Optional[SentinelEvent]:
    s = str(raw or "").strip()
    for ev in SentinelEvent:
        if ev.value == s:
            return ev
    return None


def _parse_type(raw: Any, *, default: SentinelType = SentinelType.COMMAND) -> SentinelType:
    s = str(raw or "").strip().lower()
    for t in SentinelType:
        if t.value == s:
            return t
    return default


def _make_id(*parts: str) -> str:
    """Stable short id for a Sentinel — used in audit + once tracking."""
    import hashlib
    src = "|".join(p or "" for p in parts).encode("utf-8", "replace")
    return hashlib.sha1(src).hexdigest()[:10]


def _entries_from_legacy_hooks(
    data: dict, *, source: str, source_path: str,
) -> list[Sentinel]:
    """Load the pre-99 `hooks.json` shape (PreToolUse/PostToolUse only,
    Command type only) into Sentinel records."""
    out: list[Sentinel] = []
    hooks = data.get("hooks") or {}
    for kind in ("PreToolUse", "PostToolUse"):
        ev = _parse_event(kind)
        if ev is None:
            continue
        for entry in hooks.get(kind, []):
            try:
                cmd = str(entry.get("command", "")).strip()
                if not cmd:
                    continue
                matcher = _compile_matcher(entry.get("matcher", "*"))
                t = int(entry.get("timeout_seconds", 30))
                rid = _make_id(source_path, kind, cmd)
                out.append(Sentinel(
                    type=SentinelType.COMMAND,
                    event=ev,
                    matcher=matcher,
                    timeout_s=t,
                    command=cmd,
                    source=source,
                    source_path=source_path,
                    raw_id=rid,
                ))
            except Exception:
                continue
    return out


def _entries_from_sentinels_json(
    data: dict, *, source: str, source_path: str,
) -> list[Sentinel]:
    """Load the round-99 sentinels.json shape:

      {
        "hooks": {
          "PreToolUse": [
            {
              "matcher": "Bash",
              "hooks": [
                {"type": "command", "command": "...", "timeout": 30, "once": false}
              ]
            }
          ],
          "Stop": [...]
        }
      }

    Each `hooks` block is a list of records grouped by matcher.
    Each record has a `hooks` array of Sentinel definitions."""
    out: list[Sentinel] = []
    blocks = data.get("hooks") or {}
    for ev_name, ev_blocks in blocks.items():
        ev = _parse_event(ev_name)
        if ev is None:
            continue
        if not isinstance(ev_blocks, list):
            continue
        for block in ev_blocks:
            if not isinstance(block, dict):
                continue
            matcher = _compile_matcher(block.get("matcher", "*"))
            sub_hooks = block.get("hooks") or []
            if not isinstance(sub_hooks, list):
                continue
            for entry in sub_hooks:
                try:
                    sentinel_type = _parse_type(entry.get("type"))
                    timeout = int(entry.get("timeout", entry.get("timeout_seconds", 30)))
                    once = bool(entry.get("once", False))
                    s = Sentinel(
                        type=sentinel_type,
                        event=ev,
                        matcher=matcher,
                        timeout_s=timeout,
                        once_per_session=once,
                        source=source,
                        source_path=source_path,
                    )
                    if sentinel_type == SentinelType.COMMAND:
                        s.command = str(entry.get("command", "")).strip()
                        if not s.command:
                            continue
                    elif sentinel_type == SentinelType.HTTP:
                        s.url = str(entry.get("url", "")).strip()
                        if not s.url:
                            continue
                    elif sentinel_type == SentinelType.PROMPT:
                        s.prompt = str(entry.get("prompt", "")).strip()
                        if not s.prompt:
                            continue
                    elif sentinel_type == SentinelType.MCP_TOOL:
                        s.mcp_server = str(entry.get("server", "")).strip()
                        s.mcp_tool = str(entry.get("tool", "")).strip()
                        if not (s.mcp_server and s.mcp_tool):
                            continue
                    elif sentinel_type == SentinelType.AGENT:
                        s.agent_prompt = str(entry.get("prompt", "")).strip()
                        if not s.agent_prompt:
                            continue
                    s.raw_id = _make_id(
                        source_path, ev.value, sentinel_type.value,
                        s.command or s.url or s.prompt or s.agent_prompt,
                    )
                    out.append(s)
                except Exception:
                    continue
    return out


def _load_json_safe(path: Path) -> Optional[dict]:
    if not path.exists() or not path.is_file():
        return None
    try:
        raw = path.read_text(encoding="utf-8", errors="replace").strip()
        if not raw:
            return None
        return json.loads(raw)
    except (OSError, ValueError):
        return None


def load_sentinels(workdir: Path) -> SentinelRegistry:
    """Discover Sentinels across all sources in priority order.

    Project-scope is gated by Workspace Trust — same defense as
    `.prometheus/aptitudes/` and the legacy hooks loader. Hostile
    repos can't ship a `sentinels.json` that runs arbitrary code on
    first session-start without trust elevation.
    """
    try:
        from prometheus.safety.trust import is_trusted
    except Exception:
        is_trusted = lambda _: False  # type: ignore
    reg = SentinelRegistry()

    def _ingest(path: Path, source: str) -> None:
        data = _load_json_safe(path)
        if not data:
            return
        # Round-99 shape uses nested `hooks: {Event: [{matcher,
        # hooks: [...]}]}`. Pre-99 shape used the same Event keys
        # but the entries had `{matcher, command}` directly. Detect
        # by sniffing the first sub-entry shape.
        is_modern = False
        for ev_blocks in (data.get("hooks") or {}).values():
            if isinstance(ev_blocks, list) and ev_blocks:
                first = ev_blocks[0]
                if isinstance(first, dict) and "hooks" in first:
                    is_modern = True
                    break
        if is_modern:
            for s in _entries_from_sentinels_json(
                data, source=source, source_path=str(path),
            ):
                reg.add(s)
        else:
            for s in _entries_from_legacy_hooks(
                data, source=source, source_path=str(path),
            ):
                reg.add(s)

    # 1. Project sentinels.json + legacy hooks.json (Trust-gated).
    if is_trusted(workdir):
        _ingest(workdir / ".prometheus" / "sentinels.json", "project")
        _ingest(workdir / ".prometheus" / "hooks.json", "project")
    # 2. User-scope.
    home = Path.home()
    _ingest(home / ".prometheus" / "sentinels.json", "user")
    _ingest(home / ".prometheus" / "hooks.json", "user")
    # 3. Enterprise / managed (round-103 will wire managed config
    # discovery; for now we read a fixed path on POSIX).
    if sys.platform != "win32":
        _ingest(Path("/etc/prometheus/sentinels.json"), "enterprise")
    return reg


# ---------- public dispatch API ----------


async def fire_event(
    registry: SentinelRegistry,
    event: SentinelEvent,
    *,
    match_value: str = "",
    payload_extra: Optional[dict[str, Any]] = None,
    session_id: str = "",
    cwd: str = "",
    permission_mode: str = "",
    tool_name: str = "",
    tool_input: Optional[dict[str, Any]] = None,
    tool_result: Any = None,
    tool_use_id: str = "",
    agent_id: str = "",
    agent_type: str = "main",
    worktree: str = "",
    last_assistant_message: str = "",
    user_prompt: str = "",
) -> tuple[SentinelDecision, list[SentinelResult]]:
    """Fire every applicable Sentinel for `event`. Returns
    `(final_decision, all_results)`.

    The final decision is:
      * `deny` if ANY Sentinel returned deny AND `event` is in
        `BLOCKING_EVENTS` (non-blocking events ignore deny).
      * `allow` if ANY Sentinel returned allow.
      * `noop` otherwise.

    `match_value` is what the matcher regex tests against. For
    PreToolUse/PostToolUse, pass the tool name. For UserPromptSubmit,
    pass the user prompt. For others, pass an empty string and every
    matcher will fire.
    """
    payload = _build_event_payload(
        event,
        session_id=session_id, cwd=cwd, permission_mode=permission_mode,
        tool_name=tool_name, tool_input=tool_input,
        tool_result=tool_result, tool_use_id=tool_use_id,
        agent_id=agent_id, agent_type=agent_type,
        worktree=worktree,
        last_assistant_message=last_assistant_message,
        user_prompt=user_prompt, extra=payload_extra,
    )
    sentinels = registry.for_event(event, match_value=match_value)
    if not sentinels:
        return SentinelDecision.NOOP, []
    results: list[SentinelResult] = []
    final = SentinelDecision.NOOP
    for s in sentinels:
        if s.type == SentinelType.COMMAND:
            r = await _run_command_sentinel(s, payload)
        elif s.type == SentinelType.HTTP:
            r = await _run_http_sentinel(s, payload)
        elif s.type == SentinelType.PROMPT:
            r = await _run_stub_sentinel(s, payload, "prompt")
        elif s.type == SentinelType.MCP_TOOL:
            r = await _run_stub_sentinel(s, payload, "mcp_tool")
        elif s.type == SentinelType.AGENT:
            r = await _run_stub_sentinel(s, payload, "agent")
        else:
            r = SentinelResult(
                decision=SentinelDecision.ERROR,
                reason=f"unknown sentinel type {s.type!r}",
                sentinel_id=s.raw_id, fail_open=True,
            )
        s.has_fired_this_session = True
        results.append(r)
        # `deny` only counts if the event is in BLOCKING_EVENTS.
        if r.decision == SentinelDecision.DENY:
            if event in BLOCKING_EVENTS:
                final = SentinelDecision.DENY
                # Don't short-circuit — keep firing the rest so audit
                # records all decisions, but the final answer is
                # locked to deny.
            else:
                # Logged but not enforceable. Treat as ALLOW for the
                # final-decision aggregator.
                if final == SentinelDecision.NOOP:
                    final = SentinelDecision.ALLOW
        elif r.decision == SentinelDecision.ALLOW:
            if final != SentinelDecision.DENY:
                final = SentinelDecision.ALLOW
    return final, results


# ---------- audit helper ----------


def render_decision_summary(
    final: SentinelDecision,
    results: list[SentinelResult],
) -> str:
    """One-line human summary suitable for the audit log."""
    if not results:
        return f"{final.value} (no sentinels fired)"
    n_deny = sum(1 for r in results if r.decision == SentinelDecision.DENY)
    n_allow = sum(1 for r in results if r.decision == SentinelDecision.ALLOW)
    n_err = sum(1 for r in results if r.decision == SentinelDecision.ERROR)
    return (
        f"{final.value} ({len(results)} sentinels: "
        f"{n_allow} allow, {n_deny} deny, {n_err} error)"
    )
