"""Persistent permission rules from settings.json (Claude Code parity).

Format (.prometheus/settings.json or ~/.prometheus/settings.json):

    {
      "permissions": {
        "deny":  ["Bash(rm -rf:*)", "Bash(curl * | sh)", "WriteFile(.env)"],
        "allow": ["Bash(npm run test:*)", "Bash(git status)"],
        "ask":   ["Bash(git push:*)", "Edit(.env)"]
      }
    }

Evaluation order: deny → allow → ask. First match wins. Patterns map to
(tool_class, glob) — `*` matches anything. Tool class is the camelcase
group name; we normalize to our snake_case tool ids.
"""
from __future__ import annotations

import fnmatch
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# Map Claude Code-style tool group names to our actual tool names.
TOOL_ALIASES = {
    "bash": "run_bash",
    "shell": "run_bash",
    "read": "read_file",
    "write": "write_file",
    "edit": "edit_file",
    "multiedit": "multi_edit",
    "writefile": "write_file",
    "readfile": "read_file",
    "editfile": "edit_file",
    "glob": "glob_files",
    "list": "list_files",
    "grep": "search_code",
    "search": "search_code",
    "websearch": "web_search",
    "webfetch": "web_fetch",
}

PATTERN_RX = re.compile(r"^([A-Za-z][A-Za-z0-9_]*)\s*\(([^)]*)\)\s*$")


@dataclass
class Rule:
    tool: str       # canonical tool name
    arg_glob: str   # fnmatch pattern, "*" = any
    raw: str        # original string for debugging


@dataclass
class RuleSet:
    deny: list[Rule] = field(default_factory=list)
    allow: list[Rule] = field(default_factory=list)
    ask: list[Rule] = field(default_factory=list)


def _parse(pattern: str) -> Rule | None:
    m = PATTERN_RX.match(pattern.strip())
    if not m:
        return None
    raw_tool, arg = m.group(1), m.group(2)
    tool = TOOL_ALIASES.get(raw_tool.lower(), raw_tool.lower())
    arg = arg.strip() or "*"
    # Claude Code's pattern dialect uses `:*` as the "prefix then any
    # args" marker (e.g. `Bash(npm test:*)` matches `npm test --watch`).
    # Translate it to a plain wildcard for fnmatch.
    if arg.endswith(":*"):
        arg = arg[:-2] + "*"
    elif arg.endswith(":"):
        arg = arg[:-1] + "*"
    return Rule(tool=tool, arg_glob=arg, raw=pattern.strip())


PARSE_ERRORS: list[str] = []


def _load_settings(path: Path) -> dict[str, Any]:
    """Lenient: any error returns {} instead of raising.

    On parse failure we now ALSO append a one-line message to the
    module-level PARSE_ERRORS list so /doctor and the welcome-time
    rule load can surface it. Silent swallowing meant users with a
    typo in settings.json had no idea their permission rules were
    being ignored — they just observed prompts they thought they'd
    pre-approved (a P1 audit finding).
    """
    try:
        if not path.exists() or not path.is_file():
            return {}
        raw = path.read_text(encoding="utf-8", errors="replace").strip()
        if not raw:
            return {}
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as e:
            # Permissive recovery: strip trailing commas (commonest hand-edit error).
            cleaned = re.sub(r",\s*([}\]])", r"\1", raw)
            try:
                data = json.loads(cleaned)
            except Exception:
                PARSE_ERRORS.append(f"{path}: {e}")
                return {}
        return data if isinstance(data, dict) else {}
    except (OSError, UnicodeError, RecursionError) as e:
        PARSE_ERRORS.append(f"{path}: {e}")
        return {}


def load_rules(workdir: Path) -> RuleSet:
    """Merge project + user permission rules. Project takes precedence
    in evaluation order (project.deny is checked before user.deny etc.).

    Project-local settings.json is ONLY honored when the workdir is
    trusted (Workspace Trust gate). User-level settings always load —
    they're the user's own config, not influenced by a hostile repo.
    Beats the CVE-2025-59536 / CVE-2026-21852 attack class where a
    cloned repo's settings.json silently elevates permissions or
    redirects API calls before the user can react.
    """
    from prometheus.safety.trust import is_trusted
    user = _load_settings(Path.home() / ".prometheus" / "settings.json")
    if is_trusted(workdir):
        project = _load_settings(workdir / ".prometheus" / "settings.json")
    else:
        project = {}
    rs = RuleSet()
    for src in (project, user):
        perms = (src.get("permissions") or {}) if isinstance(src, dict) else {}
        for kind, target in (("deny", rs.deny), ("allow", rs.allow), ("ask", rs.ask)):
            for raw in perms.get(kind, []) or []:
                rule = _parse(str(raw))
                if rule:
                    target.append(rule)
    return rs


def _normalize_ws(s: str) -> str:
    """Collapse runs of whitespace to single spaces — fix for the
    `Bash(rm -rf:*)` rule failing on `rm  -rf` (multi-space). Claude
    Code shipped this same fix in v2.1.84."""
    return " ".join(s.split())


def _match(rule: Rule, tool_name: str, args_text: str) -> bool:
    if rule.tool != tool_name and rule.tool != "*":
        return False
    if rule.arg_glob == "*":
        return True
    canon_arg = _normalize_ws(args_text)
    canon_glob = _normalize_ws(rule.arg_glob)
    return (
        fnmatch.fnmatch(canon_arg, canon_glob)
        or fnmatch.fnmatch(canon_arg, canon_glob + "*")
    )


def evaluate(rules: RuleSet, tool_name: str, args: dict[str, Any]) -> str:
    """Return one of: 'deny' | 'allow' | 'ask' | 'default'.

    `default` means no rule matched; the caller falls through to the
    permission_mode (default mode = ask, acceptEdits = allow for write
    tools, etc.).

    Round 182: file-tool deny rules are now matched against BOTH the
    literal path and the resolved symlink target. Pre-R182 a deny
    rule like `WriteFile(/etc/passwd)` could be bypassed by
    `write_file(file_path="/tmp/link-to-passwd")` when that path was
    a symlink — the same class of bypass tracked as
    CVE-2025-59829 in Claude Code. We now check the resolved target
    as a candidate so the deny still fires.
    """
    # Round 173/182: include file_path (CC dual-schema) in the
    # arg-extraction order. Bash uses `command`, file tools use
    # `file_path` or `path`, web uses `url`.
    candidates: list[str] = []
    primary = ""
    for key in ("command", "file_path", "path", "url", "pattern", "query"):
        v = args.get(key)
        if isinstance(v, str) and v:
            primary = v
            candidates.append(v)
            break
    # Round 182: for file tools, also try the resolved symlink target.
    # This is the CVE-2025-59829 mitigation — a deny rule on the real
    # path must still fire when reached through a symlink alias.
    if primary and tool_name in {
        "read_file", "write_file", "edit_file", "multi_edit",
        "list_files", "glob_files",
    }:
        try:
            from pathlib import Path
            p = Path(primary)
            # resolve(strict=False) follows symlinks but tolerates
            # non-existent components (write_file creates new files).
            resolved = str(p.resolve(strict=False))
            if resolved and resolved != primary:
                candidates.append(resolved)
        except (OSError, RuntimeError, ValueError):
            # Cyclic symlink, permission error, or path too long —
            # fall through with just the literal path. Better to
            # let the tool layer surface the OS error than to
            # silently skip the deny check.
            pass
    if not candidates:
        try:
            candidates = [json.dumps(args, default=str)[:200]]
        except Exception:
            candidates = [""]
    for rule in rules.deny:
        for args_text in candidates:
            if _match(rule, tool_name, args_text):
                return "deny"
    for rule in rules.allow:
        for args_text in candidates:
            if _match(rule, tool_name, args_text):
                return "allow"
    for rule in rules.ask:
        for args_text in candidates:
            if _match(rule, tool_name, args_text):
                return "ask"
    return "default"
