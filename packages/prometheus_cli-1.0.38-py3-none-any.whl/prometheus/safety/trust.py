"""Workspace Trust — gate untrusted code paths from project-local config.

Mitigates the CVE-2025-59536 / CVE-2026-21852 class of attacks where a
hostile repository ships `.prometheus/hooks.json`, `.prometheus/settings.json`,
or custom `.prometheus/commands/*.md` files that get executed simply by
opening the directory.

Model: VS Code Workspace Trust. The first time a user starts PrometheUS
in a directory, that directory is "untrusted" — we refuse to load hook
scripts, MCP servers, custom permission rules, or custom slash commands
until the user explicitly trusts it via `/trust` (or sets the env var
PROMETHEUS_TRUST_ALL=1, opt-in only). Plain chat / built-in tools are
unaffected — only the project-config code paths are gated.

Trust is persisted per-directory in ~/.prometheus/trust.json:
    {
      "trusted": [
        "/home/user/projects/myrepo",
        "C:\\Users\\me\\code\\app"
      ]
    }
"""
from __future__ import annotations

import json
import os
from pathlib import Path

from prometheus.config import USER_CONFIG_DIR


_TRUST_FILE = USER_CONFIG_DIR / "trust.json"


def _load() -> set[str]:
    try:
        if not _TRUST_FILE.exists():
            return set()
        data = json.loads(_TRUST_FILE.read_text(encoding="utf-8"))
        return {str(p) for p in data.get("trusted", []) if isinstance(p, str)}
    except Exception:
        return set()


def _save(trusted: set[str]) -> None:
    _TRUST_FILE.parent.mkdir(parents=True, exist_ok=True)
    payload = {"trusted": sorted(trusted)}
    # Atomic-ish: write to .tmp then rename. On Windows, replace() will
    # overwrite. If the write fails partway, the original is preserved.
    # Round-13 P0: OneDrive (and other syncing file managers) briefly
    # locks files during sync, making `replace()` raise PermissionError.
    # Retry up to 3× with short backoff before propagating the error.
    import time as _t
    tmp = _TRUST_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    for attempt in range(3):
        try:
            tmp.replace(_TRUST_FILE)
            break
        except PermissionError:
            if attempt == 2:
                # Final attempt failed — log and bail; the .tmp leftover
                # gives the user something to debug with rather than a
                # silently-lost trust grant.
                import logging
                logging.getLogger("safety.trust").warning(
                    "trust.json replace blocked (OneDrive/sync lock?); "
                    ".tmp left at %s for manual recovery", tmp,
                )
                raise
            _t.sleep(0.2 * (attempt + 1))
    # Lock down to user-only on POSIX (audit P2: shared-host users
    # could read trusted directory paths). chmod is a no-op on Windows
    # which uses ACLs, but the call doesn't error there.
    try:
        os.chmod(_TRUST_FILE, 0o600)
    except OSError:
        pass


def _norm(p: Path | str) -> str:
    try:
        return str(Path(p).resolve())
    except Exception:
        return str(p)


def is_trusted(workdir: Path | str) -> bool:
    """Return True if the directory has been explicitly trusted, OR if
    the user has set PROMETHEUS_TRUST_ALL=1 (opt-in escape hatch — must
    be set in the user's environment, never project-local).
    """
    if os.getenv("PROMETHEUS_TRUST_ALL") == "1":
        return True
    target = _norm(workdir)
    for t in _load():
        # Allow nested directories under a trusted root.
        if target == t or target.startswith(t + os.sep):
            return True
    return False


def trust(workdir: Path | str) -> None:
    """Mark `workdir` (and everything under it) as trusted, persistently."""
    trusted = _load()
    trusted.add(_norm(workdir))
    _save(trusted)


def untrust(workdir: Path | str) -> None:
    """Remove a previously granted trust grant."""
    trusted = _load()
    trusted.discard(_norm(workdir))
    _save(trusted)


def list_trusted() -> list[str]:
    return sorted(_load())
