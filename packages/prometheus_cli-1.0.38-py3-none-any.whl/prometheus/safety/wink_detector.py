"""Round 161 — Hardening 1: Wink-style asynchronous misbehavior detector.

Research (Wink: Active Trajectory Course-Correction): observing agent
trajectories and providing targeted nudges resolves ~90% of
misbehaviors with a single intervention. The three categories Wink
addresses are:

  - Specification Drift   — output contradicts the user's intent
  - Reasoning Problems    — repetitive loops, self-contradiction
  - Tool Call Failures    — error / empty result before blind retry

This module is a passive observer: it sees each tool call + the
original user prompt, classifies misbehavior, and emits a structured
intervention the agent loop can inject as a system reminder. It owns
no LLM calls, no retries — those are the agent loop's job. The
detector's only contract is "given history, return interventions."

A 3-strikes counter escalates to the round-104 Overseer circuit
breaker so a runaway turn can't burn the whole session.
"""
from __future__ import annotations

import hashlib
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Iterable, Optional


class MisbehaviorKind(str, Enum):
    SPEC_DRIFT = "spec_drift"
    REASONING_LOOP = "reasoning_loop"
    SELF_CONTRADICTION = "self_contradiction"
    TOOL_FAILURE = "tool_failure"
    REPEAT_TOOL_FAILURE = "repeat_tool_failure"


@dataclass(frozen=True)
class Intervention:
    """Structured course-correction the agent loop injects as a
    system reminder on the next turn."""
    kind: MisbehaviorKind
    message: str
    """Human-readable text for the system reminder."""
    severity: str = "warn"  # 'info' | 'warn' | 'escalate'
    detail: dict = field(default_factory=dict)


@dataclass
class _ToolCallRecord:
    name: str
    fingerprint: str       # sha1 of (name, args)
    error: bool
    summary: str
    ts: float


@dataclass
class WinkDetector:
    """Passive observer with a small ring-buffer of recent tool calls
    and a record of the original user intent."""
    user_prompt: str = ""
    forbidden_paths: tuple[str, ...] = ()
    """User-asserted "do not modify" paths (or repo-root globs) the
    Charter has flagged. Edits to these trigger spec_drift."""
    history: list[_ToolCallRecord] = field(default_factory=list)
    interventions_this_turn: int = 0
    total_interventions: int = 0
    escalation_threshold: int = 3
    """How many interventions in one turn before we ask the Overseer
    circuit breaker to trip."""

    def reset_turn(self) -> None:
        """Call at the start of each model turn to reset the per-turn
        intervention counter (the cumulative `total_interventions`
        keeps growing for /stats)."""
        self.interventions_this_turn = 0

    # ---- main API --------------------------------------------------

    def observe(
        self,
        *,
        tool_name: str,
        args: dict,
        result_summary: str,
        result_error: bool,
        agent_text: str = "",
    ) -> list[Intervention]:
        """Record one tool call + return any interventions that fire.

        `agent_text` is the assistant text emitted alongside the tool
        call (used for self-contradiction detection)."""
        rec = _ToolCallRecord(
            name=tool_name,
            fingerprint=_fingerprint(tool_name, args),
            error=bool(result_error),
            summary=result_summary or "",
            ts=time.monotonic(),
        )
        self.history.append(rec)
        # Keep a rolling 32-call ring so very long sessions don't grow
        # unbounded.
        if len(self.history) > 32:
            self.history = self.history[-32:]
        out: list[Intervention] = []
        out.extend(self._check_spec_drift(tool_name, args))
        out.extend(self._check_reasoning_loop(rec))
        out.extend(self._check_tool_failure(rec))
        out.extend(self._check_self_contradiction(agent_text))
        # Update counters.
        for _ in out:
            self.interventions_this_turn += 1
            self.total_interventions += 1
        return out

    def should_trip_circuit_breaker(self) -> bool:
        """Returns True once enough interventions have fired this turn
        that a runaway is the more likely explanation than transient
        confusion."""
        return self.interventions_this_turn >= self.escalation_threshold

    # ---- detectors -------------------------------------------------

    def _check_spec_drift(
        self, tool_name: str, args: dict
    ) -> list[Intervention]:
        """Edit/Write to a path the user explicitly told us not to touch."""
        out: list[Intervention] = []
        if tool_name not in {"write_file", "edit_file", "multi_edit", "apply_patch"}:
            return out
        path = str(args.get("path", "") or "")
        if not path:
            return out
        # Direct forbidden-path check.
        for bad in self.forbidden_paths:
            if bad and (bad in path or path.endswith(bad) or _path_match(bad, path)):
                out.append(Intervention(
                    kind=MisbehaviorKind.SPEC_DRIFT,
                    message=(
                        f"⚠️ Course correction: the user said do not modify "
                        f"`{bad}`. The current edit targets `{path}`, which "
                        f"matches that constraint. Stop, ask for confirmation, "
                        f"or pick a different file."
                    ),
                    severity="escalate",
                    detail={"forbidden": bad, "attempted": path},
                ))
                return out
        # Heuristic: user prompt contains "do not modify <X>" or "don't
        # touch <X>" — extract <X> and compare.
        for m in re.finditer(
            r"(?:do\s*not|don'?t)\s+(?:modify|change|edit|touch)\s+([A-Za-z0-9_./\\-]+)",
            self.user_prompt or "",
            re.IGNORECASE,
        ):
            asked = m.group(1).lower()
            if asked and asked in path.lower():
                out.append(Intervention(
                    kind=MisbehaviorKind.SPEC_DRIFT,
                    message=(
                        f"⚠️ Course correction: your earlier message said "
                        f"do not modify `{asked}`. The current edit targets "
                        f"`{path}`. Re-read the user's instruction before "
                        f"proceeding."
                    ),
                    severity="escalate",
                    detail={"asked": asked, "attempted": path},
                ))
                return out
        return out

    def _check_reasoning_loop(
        self, rec: _ToolCallRecord
    ) -> list[Intervention]:
        """Same fingerprint repeated > N times in the recent window."""
        same = [r for r in self.history[-8:] if r.fingerprint == rec.fingerprint]
        if len(same) < 4:
            return []
        return [Intervention(
            kind=MisbehaviorKind.REASONING_LOOP,
            message=(
                f"⚠️ Course correction: you've called `{rec.name}` with the "
                f"same arguments {len(same)} times in the last 8 calls. "
                f"That's a loop. Either change the arguments, switch tools, "
                f"or report what you've found and stop."
            ),
            severity="warn",
            detail={"tool": rec.name, "count": len(same)},
        )]

    def _check_tool_failure(
        self, rec: _ToolCallRecord
    ) -> list[Intervention]:
        """Last call errored OR the same tool errored twice in a row."""
        if not rec.error:
            return []
        # Walk back through history for prior failures of the same tool.
        prior = [r for r in self.history[:-1] if r.name == rec.name and r.error]
        if not prior:
            # First failure — nudge the agent to inspect, not retry blindly.
            return [Intervention(
                kind=MisbehaviorKind.TOOL_FAILURE,
                message=(
                    f"⚠️ Course correction: `{rec.name}` returned an error "
                    f"({rec.summary or 'no summary'}). Read the error before "
                    f"retrying — a blind retry rarely succeeds. Consider an "
                    f"alternative tool if the failure looks structural."
                ),
                severity="warn",
                detail={"tool": rec.name, "summary": rec.summary},
            )]
        # Repeat failure — escalate.
        return [Intervention(
            kind=MisbehaviorKind.REPEAT_TOOL_FAILURE,
            message=(
                f"⚠️ Course correction: `{rec.name}` has failed "
                f"{len(prior) + 1} times. Stop retrying it and either pick "
                f"another tool or report the failure clearly to the user. "
                f"Last summary: {rec.summary or '(empty)'}"
            ),
            severity="escalate",
            detail={"tool": rec.name, "failures": len(prior) + 1},
        )]

    def _check_self_contradiction(self, text: str) -> list[Intervention]:
        """Detect 'I will do X.' followed in the next turn by 'I will not
        do X' or 'instead I will do not-X.' Conservative: only flags
        direct affirm/negate pairs of the same verb-object."""
        if not text:
            return []
        # Compare against the last assistant text we observed (stored
        # on history[-1].summary if our caller stuffs it there). The
        # caller can also pass `agent_text` directly.
        # Pattern: assistant said "I will <verb> <obj>" then "I will not <verb> <obj>"
        affirms = re.findall(r"I (?:will|am going to) (\w+ \w+)", text, re.IGNORECASE)
        negates = re.findall(r"I (?:will not|won't|am not going to) (\w+ \w+)", text, re.IGNORECASE)
        common = set(a.lower() for a in affirms) & set(n.lower() for n in negates)
        if not common:
            return []
        return [Intervention(
            kind=MisbehaviorKind.SELF_CONTRADICTION,
            message=(
                f"⚠️ Course correction: in the same response you both "
                f"affirmed and negated {sorted(common)}. Pick one, then "
                f"act."
            ),
            severity="warn",
            detail={"common": sorted(common)},
        )]


# ---- helpers ----------------------------------------------------------


def _fingerprint(tool_name: str, args: dict) -> str:
    import json as _json
    try:
        s = _json.dumps(args or {}, default=str, sort_keys=True)[:400]
    except Exception:
        s = repr(args)[:400]
    return hashlib.sha1(f"{tool_name}|{s}".encode("utf-8")).hexdigest()[:16]


def _path_match(pattern: str, path: str) -> bool:
    """Forgiving path-glob match. Allows `*` in pattern."""
    if "*" not in pattern:
        return False
    from fnmatch import fnmatch
    return fnmatch(path, pattern) or fnmatch(path, "*/" + pattern)


def render_intervention_banner(interventions: Iterable[Intervention]) -> str:
    """Render a list of interventions as a single system-reminder block
    suitable for injection into the next turn's context."""
    parts = []
    for iv in interventions:
        sev = {"info": "ℹ", "warn": "⚠", "escalate": "‼"}.get(iv.severity, "·")
        parts.append(f"{sev} [{iv.kind.value}] {iv.message}")
    if not parts:
        return ""
    return "<system-reminder>\n" + "\n".join(parts) + "\n</system-reminder>"
