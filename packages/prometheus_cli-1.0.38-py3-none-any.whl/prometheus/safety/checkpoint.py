"""Rewind/restore disk state from snapshots produced by file tools.

Every file write/edit/multi_edit pushes a {kind, path, before, after}
record onto ToolContext.snapshots. To undo, we walk the list in reverse
and write `before` back to disk (or delete the file if before is None
and after exists).
"""
from __future__ import annotations

from pathlib import Path
from typing import Any


def rewind_snapshots(snapshots: list[dict[str, Any]], count: int) -> tuple[int, list[str]]:
    """Roll back the last `count` snapshots. Returns (n_restored, errors).

    Pops the snapshots off the list as it goes — caller's list is mutated.
    Restores route through `_atomic_write_text` so a crash mid-rewind
    can't leave a half-written file on disk (round-16 P0).
    """
    from prometheus.tools.files import _atomic_write_text
    restored = 0
    errors: list[str] = []
    for _ in range(min(count, len(snapshots))):
        snap = snapshots.pop()
        path = Path(snap["path"])
        before = snap.get("before")
        try:
            if before is None:
                if path.exists():
                    path.unlink()
            else:
                _atomic_write_text(path, before)
            restored += 1
        except Exception as e:
            errors.append(f"{path}: {e}")
    return restored, errors
