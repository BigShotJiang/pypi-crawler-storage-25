"""Round 182: encoding-safe file I/O.

Pre-R182 every Read / Edit / MultiEdit / search call decoded files
with `errors="replace"`, which silently mojibakes any non-UTF-8
source (legacy ISO-8859-1 .py, Windows-1252 .csv, Shift-JIS .java
in older Tokyo repos, etc.) and silently drops UTF-8 BOMs on
writeback. Both are real correctness bugs for commercial users.

This module owns the read-bytes-to-text round-trip so callers don't
have to think about encodings:

  info, text = decode_smart(path.read_bytes())
  ...edit text...
  out_bytes = encode_smart(text, info)
  path.write_bytes(out_bytes)

`info` carries the encoding name and BOM presence so the writeback
preserves them byte-for-byte. The legacy decode_replace() path is
still exposed for callers that genuinely don't care about fidelity
(activity log scraping, error-message previews).
"""
from __future__ import annotations

import codecs
from dataclasses import dataclass


# Byte-order-mark patterns. Order matters: UTF-8 BOM is 3 bytes,
# UTF-16 BOMs are 2 bytes, so we check UTF-8 first to avoid a false
# UTF-16 hit on a UTF-8 file that happens to start with the right
# byte. UTF-32 BOMs are also 4 bytes but their first 2 bytes look
# like UTF-16 BOMs, so UTF-32 must be checked before UTF-16.
_BOM_TABLE: tuple[tuple[bytes, str], ...] = (
    (codecs.BOM_UTF8, "utf-8-sig"),
    (codecs.BOM_UTF32_LE, "utf-32-le"),
    (codecs.BOM_UTF32_BE, "utf-32-be"),
    (codecs.BOM_UTF16_LE, "utf-16-le"),
    (codecs.BOM_UTF16_BE, "utf-16-be"),
)


@dataclass(frozen=True)
class TextInfo:
    """What we learned about a file when decoding it.

    `encoding` — codec name ("utf-8", "utf-8-sig", "cp1252", ...)
    `had_bom`  — True if the original bytes began with a recognised BOM
    `lossy`    — True if decode used errors="replace" because no codec
                 worked cleanly. Callers that care about correctness
                 should refuse to write back when this is True.
    """
    encoding: str
    had_bom: bool
    lossy: bool


def detect_bom(data: bytes) -> tuple[str, bool]:
    """Sniff the first ~4 bytes for a known BOM.

    Returns (encoding, had_bom). When no BOM is detected, returns
    ("utf-8", False) — caller should attempt utf-8 decode and only
    fall back to other codecs on UnicodeDecodeError."""
    for bom, enc in _BOM_TABLE:
        if data.startswith(bom):
            return enc, True
    return "utf-8", False


# Codecs we'll try in order when there's no BOM and utf-8 fails.
# cp1252 is the most-common Windows legacy codec; latin-1 is the
# universal fallback because every byte decodes to a single
# code point (so it never raises). We list it last on purpose:
# the others get a chance to recognise their structure first.
_FALLBACK_CODECS: tuple[str, ...] = (
    "cp1252",
    "iso-8859-1",
    "latin-1",
)


def decode_smart(data: bytes) -> tuple[str, TextInfo]:
    """Decode bytes to text, preserving BOM/encoding info for writeback.

    Strategy:
      1. If a BOM is present, decode with the BOM's codec.
         - utf-8-sig automatically eats the UTF-8 BOM during decode.
         - utf-16-le/be and utf-32-le/be do NOT strip the BOM
           character — they leave a leading `\\ufeff`. We strip it
           explicitly so the returned text matches what a user
           would see in their editor.
      2. Otherwise try utf-8 strict.
      3. Otherwise fall through cp1252 → iso-8859-1 → latin-1.
      4. Last resort: utf-8 with errors="replace" and lossy=True
         so the caller can refuse to write back.

    The returned TextInfo carries the codec + BOM presence so an
    eventual writeback round-trips byte-for-byte."""
    encoding, had_bom = detect_bom(data)
    if had_bom:
        text = data.decode(encoding)
        # utf-8-sig strips the BOM; utf-16/utf-32 do not. Normalize
        # by removing a leading BOM character (﻿) if present.
        if text.startswith("﻿"):
            text = text[1:]
        return text, TextInfo(encoding=encoding, had_bom=True, lossy=False)
    # No BOM: try strict utf-8 first.
    try:
        return data.decode("utf-8"), TextInfo(encoding="utf-8", had_bom=False, lossy=False)
    except UnicodeDecodeError:
        pass
    for enc in _FALLBACK_CODECS:
        try:
            return data.decode(enc), TextInfo(encoding=enc, had_bom=False, lossy=False)
        except (UnicodeDecodeError, LookupError):
            continue
    # All codecs failed — surface lossy=True so callers refuse writeback.
    return data.decode("utf-8", errors="replace"), TextInfo(
        encoding="utf-8", had_bom=False, lossy=True,
    )


def encode_smart(text: str, info: TextInfo) -> bytes:
    """Re-encode text using the codec we originally decoded with.

    BOM-prefixed sources round-trip via utf-8-sig / utf-16 / utf-32
    which prepend the BOM automatically. Non-BOM sources use the
    matched codec without any prefix.

    Encoding errors fall back to utf-8 (with errors="replace" only
    if the original was already lossy) so we never lose data when
    the model has added characters the original codec can't
    represent."""
    if info.lossy:
        # We never had a clean decode — don't pretend a writeback is
        # safe. utf-8 strict is the cleanest commitment.
        return text.encode("utf-8", errors="replace")
    enc = info.encoding
    try:
        if info.had_bom and enc == "utf-8-sig":
            return text.encode("utf-8-sig")
        if info.had_bom and enc in ("utf-16-le", "utf-16-be", "utf-32-le", "utf-32-be"):
            # We stripped the leading BOM char on decode, so re-add
            # the BOM bytes manually before the encoded payload.
            bom = {
                "utf-16-le": codecs.BOM_UTF16_LE,
                "utf-16-be": codecs.BOM_UTF16_BE,
                "utf-32-le": codecs.BOM_UTF32_LE,
                "utf-32-be": codecs.BOM_UTF32_BE,
            }[enc]
            return bom + text.encode(enc)
        return text.encode(enc)
    except (UnicodeEncodeError, LookupError):
        # The model added characters the original codec can't
        # represent. Promote to utf-8 + BOM if the original had one,
        # else plain utf-8.
        return text.encode("utf-8-sig" if info.had_bom else "utf-8")


def decode_replace(data: bytes) -> str:
    """Legacy lossy decode for callers that genuinely don't care
    about fidelity (preview blocks, error messages, scraping output
    for the receipt timeline). Equivalent to the pre-R182 default."""
    return data.decode("utf-8", errors="replace")
