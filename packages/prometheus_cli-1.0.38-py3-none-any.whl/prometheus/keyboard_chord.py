"""Round 142: chord keyboard shortcuts.

Two-step chords (Emacs-style) and additional single-press
bindings:

  * Ctrl+X Ctrl+K  — kill all background agents (chord)
  * Ctrl+X Ctrl+E  — open input buffer in $EDITOR
  * Ctrl+G         — same as Ctrl+X Ctrl+E (single-press alias)
  * Ctrl+_         — undo input
  * Ctrl+Shift+B   — toggle Brief mode
  * Ctrl+Shift+O   — toggle teammate preview
  * Meta+J         — toggle terminal panel

Pure data layer + state machines.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from typing import Optional


# ---------- Ctrl+X chord state ----------


@dataclass
class ChordState:
    """Round 142: tracks the leading Ctrl+X. After that key is
    pressed, the next keystroke within `window_s` is treated
    as the chord completion."""
    armed_at: Optional[float] = None
    window_s: float = 1.5

    def begin(self, *, now: Optional[float] = None) -> None:
        """Round 142: Ctrl+X pressed — arm the chord."""
        self.armed_at = now if now is not None else time.monotonic()

    def is_armed(self, *, now: Optional[float] = None) -> bool:
        if self.armed_at is None:
            return False
        t = now if now is not None else time.monotonic()
        return (t - self.armed_at) <= self.window_s

    def consume(
        self, key: str, *, now: Optional[float] = None,
    ) -> Optional[str]:
        """Round 142: feed the second key. Returns the chord
        name (`kill_all` / `edit_buffer`) or None when not a
        chord follow-up."""
        if not self.is_armed(now=now):
            return None
        k = (key or "").lower().strip()
        action: Optional[str] = None
        if k in ("ctrl+k", "k"):
            action = "kill_all"
        elif k in ("ctrl+e", "e"):
            action = "edit_buffer"
        # Always release the chord, even on miss — Emacs UX:
        # an unrecognized follow-up cancels the prefix.
        self.armed_at = None
        return action

    def cancel(self) -> None:
        self.armed_at = None


# ---------- input undo ----------


@dataclass
class UndoStack:
    """Round 142: bounded undo stack for the input buffer.
    Keeps the last `capacity` snapshots; Ctrl+_ pops one."""
    capacity: int = 32
    history: list[str] = field(default_factory=list)

    def push(self, snapshot: str) -> None:
        if not isinstance(snapshot, str):
            return
        # Skip dupes.
        if self.history and self.history[-1] == snapshot:
            return
        self.history.append(snapshot)
        if len(self.history) > self.capacity:
            self.history.pop(0)

    def undo(self, current: str) -> Optional[str]:
        """Round 142: return the prior snapshot, popping the
        stack. Returns None when nothing to undo."""
        # If the user typed but never pushed, treat current as
        # the most-recent state — pop the previous one.
        if not self.history:
            return None
        # If top-of-stack equals current, pop it before
        # returning the next one.
        if self.history[-1] == current:
            self.history.pop()
        if not self.history:
            return ""
        return self.history[-1]

    def clear(self) -> None:
        self.history.clear()


# ---------- $EDITOR launch ----------


def resolve_editor() -> str:
    """Round 142: pick an editor for Ctrl+X Ctrl+E / Ctrl+G."""
    for var in ("VISUAL", "EDITOR"):
        val = os.environ.get(var, "").strip()
        if val:
            return val
    if sys.platform.startswith("win"):
        return "notepad.exe"
    for cand in ("nano", "vi", "vim", "emacs"):
        if shutil.which(cand):
            return cand
    return "vi"


def edit_buffer_in_editor(
    initial: str, *,
    editor: Optional[str] = None,
    suffix: str = ".txt",
    timeout_s: int = 600,
) -> Optional[str]:
    """Round 142: drop `initial` into a temp file, launch the
    editor synchronously, return the file's contents (or None
    on failure)."""
    chosen = editor or resolve_editor()
    if not chosen:
        return None
    fd, path = tempfile.mkstemp(prefix="prometheus-buf-", suffix=suffix)
    try:
        os.close(fd)
        with open(path, "w", encoding="utf-8") as f:
            f.write(initial or "")
        cmd = chosen.split() + [path]
        try:
            subprocess.run(cmd, timeout=timeout_s, check=False)
        except (OSError, subprocess.TimeoutExpired):
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        except OSError:
            return None
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


# ---------- Brief mode toggle (Ctrl+Shift+B) ----------


@dataclass
class BriefModeState:
    """Round 142: toggle for KAIROS Brief mode — quick session-
    state summary mode. Mirrors round 113's brief output style
    so toggling here flips the same flag."""
    enabled: bool = False


def toggle_brief(state: BriefModeState) -> bool:
    state.enabled = not state.enabled
    if state.enabled:
        os.environ["PROMETHEUS_BRIEF_MODE"] = "1"
    else:
        os.environ["PROMETHEUS_BRIEF_MODE"] = "0"
    return state.enabled


def brief_mode_active() -> bool:
    return os.environ.get(
        "PROMETHEUS_BRIEF_MODE", "",
    ).strip().lower() in ("1", "true", "yes")


# ---------- teammate preview (Ctrl+Shift+O) ----------


@dataclass
class TeammatePreviewState:
    visible: bool = False


def toggle_teammate_preview(state: TeammatePreviewState) -> bool:
    state.visible = not state.visible
    return state.visible


# ---------- terminal panel (Meta+J) ----------


@dataclass
class TerminalPanelState:
    """Round 142: compact system-info bar that shows kernel,
    shell, current-dir, and elapsed-since-launch."""
    visible: bool = False


def toggle_terminal_panel(state: TerminalPanelState) -> bool:
    state.visible = not state.visible
    return state.visible


def render_terminal_panel(state: TerminalPanelState) -> str:
    """Round 142: produces the one-line panel content. Empty
    when hidden."""
    if not state.visible:
        return ""
    import platform as _plat
    parts: list[str] = []
    parts.append(f"os={_plat.system()} {_plat.release()}")
    parts.append(f"py={_plat.python_version()}")
    parts.append(
        f"shell={os.environ.get('SHELL') or os.environ.get('COMSPEC') or '?'}"
    )
    parts.append(f"cwd={os.getcwd()}")
    return "  ·  ".join(parts)


# ---------- key dispatcher helpers ----------


_CHORD_LEADER = "ctrl+x"
_DIRECT_BINDINGS = {
    "ctrl+g":         "edit_buffer",
    "ctrl+_":         "undo_input",
    "ctrl+shift+b":   "toggle_brief",
    "ctrl+shift+o":   "toggle_teammate_preview",
    "meta+j":         "toggle_terminal_panel",
    "alt+j":          "toggle_terminal_panel",  # cross-terminal alias
}


def dispatch(
    key: str, *, chord: ChordState,
    now: Optional[float] = None,
) -> Optional[str]:
    """Round 142: map a key (already in the host's `ctrl+x`
    style) to one of the round-142 actions, plus chord state
    machine. Returns one of:

      `kill_all`, `edit_buffer`, `undo_input`,
      `toggle_brief`, `toggle_teammate_preview`,
      `toggle_terminal_panel`, `chord_armed`, or None.
    """
    k = (key or "").lower().strip()
    if not k:
        return None
    # Chord follow-ups when armed.
    if chord.is_armed(now=now):
        action = chord.consume(k, now=now)
        return action  # may be None (cancels chord)
    # Chord leader.
    if k == _CHORD_LEADER:
        chord.begin(now=now)
        return "chord_armed"
    # Direct bindings.
    return _DIRECT_BINDINGS.get(k)
