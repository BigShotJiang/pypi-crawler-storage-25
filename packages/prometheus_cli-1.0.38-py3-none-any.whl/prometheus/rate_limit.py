"""Round 137: `/rate-limit-options` — show available strategies.

When the primary model is overloaded or rate-limited, the
runtime can take one of three actions:

  * `auto-retry` — exponential backoff + retry the same model
  * `fallback`   — switch to `--fallback-model` (round 130)
  * `notify`     — surface the error to the user and pause

The selection persists for the session and is consulted by
the provider's retry loop.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional


VALID_STRATEGIES = ("auto-retry", "fallback", "notify")


@dataclass
class RateLimitStrategy:
    """Round 137: one strategy option."""
    name: str
    description: str
    when_to_use: str


def strategies() -> list[RateLimitStrategy]:
    return [
        RateLimitStrategy(
            name="auto-retry",
            description=(
                "Retry the same model with exponential backoff "
                "(2s → 4s → 8s, capped at 60s)."
            ),
            when_to_use=(
                "Best for transient overload. The runtime keeps "
                "trying until the model accepts."
            ),
        ),
        RateLimitStrategy(
            name="fallback",
            description=(
                "Switch to `--fallback-model` (round 130) on the "
                "next iteration."
            ),
            when_to_use=(
                "Best when you've configured a cheaper/faster "
                "fallback that can finish the work."
            ),
        ),
        RateLimitStrategy(
            name="notify",
            description=(
                "Surface the rate-limit error and pause until "
                "you acknowledge."
            ),
            when_to_use=(
                "Best for interactive sessions where you want "
                "to handle each rate-limit yourself."
            ),
        ),
    ]


def current_strategy() -> str:
    """Round 137: env-driven current selection. Defaults to
    `auto-retry`."""
    val = os.environ.get(
        "PROMETHEUS_RATE_LIMIT_STRATEGY", "",
    ).strip().lower()
    return val if val in VALID_STRATEGIES else "auto-retry"


def set_strategy(name: str) -> Optional[str]:
    """Round 137: persist a new selection via env. Returns the
    set value, or None when the input is invalid."""
    n = (name or "").strip().lower()
    if n not in VALID_STRATEGIES:
        return None
    os.environ["PROMETHEUS_RATE_LIMIT_STRATEGY"] = n
    return n


def render_options() -> str:
    """Round 137: `/rate-limit-options` body."""
    cur = current_strategy()
    lines: list[str] = []
    lines.append(f"current: {cur}")
    lines.append("")
    lines.append("strategies:")
    for s in strategies():
        mark = "›" if s.name == cur else " "
        lines.append(f"  {mark} {s.name:11s}  {s.description}")
        lines.append(f"      when: {s.when_to_use}")
    lines.append("")
    lines.append("(use `/rate-limit-options <name>` to switch)")
    return "\n".join(lines)
