"""Round 118: Remote Session Bridge.

`/bridge` starts a lightweight HTTP server on localhost. Any
device on the same network can browse to the URL, enter the
one-time pairing code printed in the terminal, and view the
live PrometheUS transcript. They can also send prompts back to
the local session.

Security model:
  * Server binds to `0.0.0.0` so it's reachable from
    other devices on the LAN. (Browser users still need to
    know the host IP.)
  * Each session generates a 6-digit pairing code. Without it,
    the page shows a login form, never the transcript.
  * Pairing code is shown ONCE in the local terminal. Lost code
    means the user must `/bridge stop` and start a new bridge.
  * Read+prompt only — the bridge never executes file I/O on
    behalf of the remote user. The remote can ONLY see the
    transcript and submit prompts.
  * Auto-stops on local session exit.

Round-118 scope: the data/lifecycle layer, with a stdlib
`http.server` HTTP fallback (no external dep) and a
`websockets` upgrade path when the package is installed. Both
paths share the BridgeServer interface so the slash command
talks to one object.
"""
from __future__ import annotations

import asyncio
import json
import secrets
import socket
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Optional


# ---------- pairing code ----------


def generate_pairing_code() -> str:
    """Round 118: 6-digit pairing code printed in the terminal.
    Cryptographically random — `secrets.randbelow` is the right
    PRNG for auth tokens."""
    return f"{secrets.randbelow(1_000_000):06d}"


# ---------- transcript ring ----------


@dataclass
class TranscriptEvent:
    """One event the bridge can broadcast to remote clients."""
    ts: float
    kind: str              # `text` / `tool_receipt` / `system` / `prompt`
    body: str

    def to_dict(self) -> dict[str, Any]:
        return {"ts": self.ts, "kind": self.kind, "body": self.body}


@dataclass
class TranscriptRing:
    """Bounded ring buffer of broadcast events. Round-118
    cap is 500 events (≈the last few turns of a session)."""
    capacity: int = 500
    events: deque = field(default_factory=lambda: deque(maxlen=500))

    def append(self, ev: TranscriptEvent) -> None:
        self.events.append(ev)

    def snapshot(self) -> list[dict[str, Any]]:
        return [e.to_dict() for e in self.events]


# ---------- bridge server ----------


@dataclass
class BridgeConfig:
    host: str = "127.0.0.1"      # localhost by default; overrideable for LAN
    port: int = 0                # 0 → OS picks a free one
    pairing_code: str = ""
    started_at: float = 0.0


@dataclass
class BridgeServer:
    """Round 118: read-only + prompt-send transport for remote
    viewers.

    The server uses Python's stdlib `http.server` so PrometheUS
    doesn't grow a hard websockets dependency. A future polish
    round can swap in a websockets-backed server for live push
    when the optional dep is installed.

    Public API:
      * `start(prompt_callback)` — bind socket + spawn thread
      * `stop()` — close socket, join thread
      * `append_event(kind, body)` — broadcast to subscribers
      * `submit_prompt(code, body)` — accept a remote prompt
    """
    config: BridgeConfig = field(default_factory=BridgeConfig)
    transcript: TranscriptRing = field(default_factory=TranscriptRing)
    running: bool = False
    pending_prompts: deque = field(default_factory=deque)
    on_prompt: Optional[Callable[[str], None]] = None
    _server_thread: Optional[threading.Thread] = None
    _http_server: Any = None
    _bind_address: tuple[str, int] = ("", 0)

    # ---- pairing-code auth ----

    def verify_code(self, code: str) -> bool:
        if not self.config.pairing_code:
            return False
        # Constant-time compare so timing attacks can't probe
        # the code one digit at a time.
        return secrets.compare_digest(
            (code or "").strip(),
            self.config.pairing_code,
        )

    # ---- lifecycle ----

    def start(
        self,
        *,
        on_prompt: Optional[Callable[[str], None]] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
    ) -> tuple[bool, str]:
        if self.running:
            return False, "bridge already running"
        if host is not None:
            self.config.host = host
        if port is not None:
            self.config.port = port
        self.config.pairing_code = generate_pairing_code()
        self.config.started_at = time.time()
        self.on_prompt = on_prompt
        try:
            from http.server import HTTPServer
            handler = _make_handler(self)
            self._http_server = HTTPServer(
                (self.config.host, self.config.port), handler,
            )
            self._bind_address = self._http_server.server_address[:2]
            self._server_thread = threading.Thread(
                target=self._http_server.serve_forever,
                daemon=True,
                name="prometheus-bridge",
            )
            self._server_thread.start()
            self.running = True
            return True, (
                f"bridge running at http://{self._bind_address[0]}:"
                f"{self._bind_address[1]} · code "
                f"{self.config.pairing_code}"
            )
        except Exception as e:
            return False, f"could not start bridge: {e}"

    def stop(self) -> tuple[bool, str]:
        if not self.running:
            return False, "bridge not running"
        try:
            if self._http_server is not None:
                self._http_server.shutdown()
                self._http_server.server_close()
        except Exception:
            pass
        self._http_server = None
        if self._server_thread is not None:
            try:
                self._server_thread.join(timeout=2.0)
            except Exception:
                pass
        self._server_thread = None
        self.running = False
        self.config.pairing_code = ""
        return True, "bridge stopped"

    @property
    def url(self) -> str:
        if not self.running:
            return ""
        return f"http://{self._bind_address[0]}:{self._bind_address[1]}"

    # ---- broadcast ----

    def append_event(self, kind: str, body: str) -> None:
        """Public API the local PrometheUS app calls when a new
        event lands in the chat-log."""
        if not self.running:
            return
        self.transcript.append(TranscriptEvent(
            ts=time.time(), kind=kind, body=body,
        ))

    def submit_prompt(self, code: str, body: str) -> tuple[bool, str]:
        """Accept a remote prompt. Verifies pairing code, then
        invokes `on_prompt(body)` callback. Returns `(ok, msg)`."""
        if not self.verify_code(code):
            return False, "invalid pairing code"
        if not body.strip():
            return False, "empty prompt"
        self.pending_prompts.append(body)
        cb = self.on_prompt
        if cb is not None:
            try:
                cb(body)
            except Exception:
                pass
        return True, "prompt accepted"

    def drain_prompts(self) -> list[str]:
        """The local app reads pending prompts off this queue
        on every tick if it didn't wire a callback."""
        out: list[str] = []
        while self.pending_prompts:
            out.append(self.pending_prompts.popleft())
        return out


# ---------- HTTP handler ----------


def _make_handler(bridge: "BridgeServer"):
    """Round 118: build the request handler class with a closure
    over the bridge instance."""
    from http.server import BaseHTTPRequestHandler

    class _Handler(BaseHTTPRequestHandler):
        # Silence the default stdout request log — too noisy for
        # an interactive CLI session. The local terminal
        # surfaces bridge events through the transcript instead.
        def log_message(self, *_a, **_kw) -> None:
            return

        def _send_json(self, status: int, payload: dict) -> None:
            blob = json.dumps(payload).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(blob)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            try:
                self.wfile.write(blob)
            except Exception:
                pass

        def _send_html(self, status: int, body: str) -> None:
            blob = body.encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(blob)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            try:
                self.wfile.write(blob)
            except Exception:
                pass

        def do_GET(self) -> None:
            if self.path in ("/", "/index", "/index.html"):
                self._send_html(200, _LANDING_HTML)
                return
            if self.path == "/healthz":
                self._send_json(200, {"running": bridge.running})
                return
            if self.path.startswith("/transcript"):
                # `/transcript?code=NNNNNN`.
                code = ""
                if "?" in self.path:
                    qs = self.path.split("?", 1)[1]
                    for piece in qs.split("&"):
                        if piece.startswith("code="):
                            code = piece.split("=", 1)[1]
                            break
                if not bridge.verify_code(code):
                    self._send_json(401, {"error": "invalid pairing code"})
                    return
                self._send_json(200, {
                    "events": bridge.transcript.snapshot(),
                    "session_started_at": bridge.config.started_at,
                })
                return
            self._send_json(404, {"error": "not found"})

        def do_POST(self) -> None:
            if self.path != "/prompt":
                self._send_json(404, {"error": "not found"})
                return
            length = int(self.headers.get("Content-Length", "0") or 0)
            if length <= 0 or length > 65_536:
                self._send_json(
                    400, {"error": "missing or oversized body"},
                )
                return
            try:
                raw = self.rfile.read(length)
                payload = json.loads(raw.decode("utf-8", errors="replace"))
            except Exception as e:
                self._send_json(400, {"error": f"bad json: {e}"})
                return
            code = str(payload.get("code", ""))
            body = str(payload.get("body", ""))
            ok, msg = bridge.submit_prompt(code, body)
            self._send_json(200 if ok else 401, {"ok": ok, "message": msg})

    return _Handler


# ---------- LAN-friendly host detection ----------


def detect_lan_host() -> str:
    """Best-effort: get a reachable IP address other machines on
    the LAN can hit."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        # Doesn't actually connect; routes the hop kernel lookup.
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


# ---------- minimal landing page ----------


_LANDING_HTML = """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>PrometheUS Bridge</title>
  <style>
    body { font-family: ui-monospace, Menlo, Consolas, monospace;
           background: #111; color: #eee; margin: 0; padding: 24px; }
    h1 { font-size: 18px; color: #f8b500; margin: 0 0 16px 0; }
    input, button, textarea {
        background: #222; color: #eee; border: 1px solid #333;
        padding: 8px; font-family: inherit; font-size: 14px; }
    button { cursor: pointer; }
    #login, #app { max-width: 800px; margin: 0 auto; }
    #app { display: none; }
    #log { background: #0c0c0c; border: 1px solid #222;
           padding: 12px; height: 60vh; overflow-y: auto;
           white-space: pre-wrap; line-height: 1.4; font-size: 13px; }
    .ev-text       { color: #eee; }
    .ev-tool_receipt { color: #aaa; }
    .ev-system     { color: #888; }
    .ev-prompt     { color: #f8b500; }
    #composer { display: flex; gap: 8px; margin-top: 12px; }
    #composer textarea { flex: 1; }
  </style>
</head>
<body>
  <div id="login">
    <h1>PrometheUS Bridge</h1>
    <p>Enter the 6-digit pairing code from the terminal.</p>
    <input id="code" inputmode="numeric" pattern="[0-9]*" maxlength="6" autofocus>
    <button id="go">Connect</button>
    <p id="err" style="color: #ff6b6b;"></p>
  </div>
  <div id="app">
    <h1>PrometheUS · live transcript</h1>
    <div id="log"></div>
    <div id="composer">
      <textarea id="prompt" rows="3" placeholder="Send a prompt…"></textarea>
      <button id="send">Send</button>
    </div>
  </div>
<script>
let pairingCode = "";
const log = document.getElementById("log");
const errEl = document.getElementById("err");

function escapeHtml(s) {
  return s.replace(/[&<>"]/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;",
  }[c]));
}
function render(events) {
  log.innerHTML = "";
  for (const ev of events) {
    const div = document.createElement("div");
    div.className = "ev-" + (ev.kind || "text");
    div.textContent = ev.body;
    log.appendChild(div);
  }
  log.scrollTop = log.scrollHeight;
}
async function poll() {
  if (!pairingCode) return;
  try {
    const r = await fetch("/transcript?code=" + encodeURIComponent(pairingCode));
    if (!r.ok) {
      pairingCode = "";
      document.getElementById("login").style.display = "block";
      document.getElementById("app").style.display = "none";
      errEl.textContent = "session ended.";
      return;
    }
    const data = await r.json();
    render(data.events || []);
  } catch (e) {
    /* ignore transient errors */
  }
}
document.getElementById("go").onclick = async () => {
  const code = document.getElementById("code").value.trim();
  errEl.textContent = "";
  // Probe via transcript fetch — if 401, code is wrong.
  const r = await fetch("/transcript?code=" + encodeURIComponent(code));
  if (!r.ok) {
    errEl.textContent = "Invalid pairing code.";
    return;
  }
  pairingCode = code;
  document.getElementById("login").style.display = "none";
  document.getElementById("app").style.display = "block";
  await poll();
  setInterval(poll, 1500);
};
document.getElementById("send").onclick = async () => {
  const body = document.getElementById("prompt").value.trim();
  if (!body) return;
  const r = await fetch("/prompt", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ code: pairingCode, body }),
  });
  if (r.ok) {
    document.getElementById("prompt").value = "";
  }
};
</script>
</body>
</html>
"""
