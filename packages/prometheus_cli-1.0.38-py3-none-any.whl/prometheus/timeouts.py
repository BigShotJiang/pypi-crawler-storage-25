"""Round 139: tool & MCP timeout / output-size env vars + a
handful of `disable command` flags.

All accessors return integers (or bools) so callers can use
them inline without parsing each invocation.

Defaults are conservative — chosen so `prometheus` works the
same as before round 139 unless the user opts in.
"""
from __future__ import annotations

import os
from typing import Optional


_TRUTHY = ("1", "true", "yes", "on")


def _flag(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in _TRUTHY


def _int_env(name: str, default: int) -> int:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        n = int(raw)
    except ValueError:
        return default
    return max(0, n)


# ---------- bash / shell tool ----------


def _int_env_aliased(*names: str, default: int) -> int:
    """1.0.3: read the first env var in `names` that is non-empty.
    Lets users migrating from Claude Code keep their existing env
    setup (`BASH_DEFAULT_TIMEOUT_MS`, etc.) without renaming."""
    for n in names:
        raw = os.environ.get(n, "").strip()
        if raw:
            try:
                return max(0, int(raw))
            except ValueError:
                continue
    return default


def bash_default_timeout_ms() -> int:
    # Claude Code parity: honour the bare CC name in addition to
    # the namespaced one. Native takes precedence when both are set.
    return _int_env_aliased(
        "PROMETHEUS_BASH_DEFAULT_TIMEOUT_MS",
        "BASH_DEFAULT_TIMEOUT_MS",
        default=120_000,
    )


def bash_max_timeout_ms() -> int:
    return _int_env_aliased(
        "PROMETHEUS_BASH_MAX_TIMEOUT_MS",
        "BASH_MAX_TIMEOUT_MS",
        default=600_000,
    )


def bash_max_output_length() -> int:
    return _int_env_aliased(
        "PROMETHEUS_BASH_MAX_OUTPUT_LENGTH",
        "BASH_MAX_OUTPUT_LENGTH",
        default=50_000,
    )


def clamp_bash_timeout_ms(requested_ms: Optional[int]) -> int:
    """Round 139: clamp a tool-supplied timeout to the configured
    floor + ceiling. Returns the effective value in ms."""
    floor = 1_000
    default = bash_default_timeout_ms()
    ceiling = bash_max_timeout_ms()
    if requested_ms is None or requested_ms <= 0:
        chosen = default
    else:
        chosen = int(requested_ms)
    if chosen < floor:
        chosen = floor
    if chosen > ceiling:
        chosen = ceiling
    return chosen


def truncate_bash_output(text: str) -> tuple[str, bool]:
    """Round 139: clip stdout/stderr at the configured limit.
    Returns (text, was_truncated)."""
    cap = bash_max_output_length()
    if cap <= 0 or not text:
        return (text or "", False)
    if len(text) <= cap:
        return (text, False)
    cut = text[: cap]
    return (
        cut + f"\n…(truncated; {len(text) - cap} more chars)",
        True,
    )


# ---------- MCP ----------


def mcp_max_output_tokens() -> int:
    return _int_env("PROMETHEUS_MAX_MCP_OUTPUT_TOKENS", 25_000)


def mcp_timeout_ms() -> int:
    return _int_env("PROMETHEUS_MCP_TIMEOUT", 30_000)


def mcp_tool_timeout_ms() -> int:
    return _int_env("PROMETHEUS_MCP_TOOL_TIMEOUT", 60_000)


def truncate_mcp_output(text: str) -> tuple[str, bool]:
    """Round 139: rough char-budget cap for MCP tool output.
    Uses ~4 chars/token heuristic to convert the token cap."""
    cap_tokens = mcp_max_output_tokens()
    if cap_tokens <= 0 or not text:
        return (text or "", False)
    cap_chars = cap_tokens * 4
    if len(text) <= cap_chars:
        return (text, False)
    return (
        text[: cap_chars]
        + f"\n…(truncated; {len(text) - cap_chars} more chars)",
        True,
    )


# ---------- thinking ----------


def max_thinking_tokens() -> int:
    return _int_env("PROMETHEUS_MAX_THINKING_TOKENS", 16_000)


# ---------- disable-command toggles ----------


def compact_disabled() -> bool:
    return _flag("PROMETHEUS_DISABLE_COMPACT")


def doctor_disabled() -> bool:
    return _flag("PROMETHEUS_DISABLE_DOCTOR_COMMAND")


def feedback_disabled() -> bool:
    """Round 139: disable feedback / bug reporting commands
    (/feedback, /bug)."""
    return _flag("PROMETHEUS_DISABLE_FEEDBACK_COMMAND")


# ---------- summary ----------


def timeout_summary() -> dict[str, int | bool]:
    """Round 139: snapshot used by `/doctor` + `/config` to
    surface effective timeouts."""
    return {
        "PROMETHEUS_BASH_DEFAULT_TIMEOUT_MS":
            bash_default_timeout_ms(),
        "PROMETHEUS_BASH_MAX_TIMEOUT_MS": bash_max_timeout_ms(),
        "PROMETHEUS_BASH_MAX_OUTPUT_LENGTH":
            bash_max_output_length(),
        "PROMETHEUS_MAX_MCP_OUTPUT_TOKENS":
            mcp_max_output_tokens(),
        "PROMETHEUS_MCP_TIMEOUT": mcp_timeout_ms(),
        "PROMETHEUS_MCP_TOOL_TIMEOUT": mcp_tool_timeout_ms(),
        "PROMETHEUS_MAX_THINKING_TOKENS": max_thinking_tokens(),
        "PROMETHEUS_DISABLE_COMPACT": compact_disabled(),
        "PROMETHEUS_DISABLE_DOCTOR_COMMAND": doctor_disabled(),
        "PROMETHEUS_DISABLE_FEEDBACK_COMMAND": feedback_disabled(),
    }
