"""Round 138: greyed-out prompt suggestions in the input bar.

When the user opens a new session, an example prompt appears
in the input box as ghost text. Tab or Right-arrow accepts;
typing dismisses; Enter accepts and submits.

Sources (in priority order):
  1. Most-recent commit subject — "Continue work on <subject>"
  2. Open TODOs in the workdir — "Finish <todo>"
  3. Active branch name — "Pick up <branch> work"
  4. Static fallbacks — "Add tests for…", "Refactor…"

Disabled by `PROMETHEUS_DISABLE_PROMPT_SUGGESTION=1` or
`enablePromptSuggestion: false` in settings.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


_FALLBACKS: tuple[str, ...] = (
    "Add tests for the most recently changed file",
    "Refactor the largest file in this project",
    "Run the test suite and fix any failures",
    "Show me the project structure",
    "Find TODOs and propose fixes",
    "Explain how the main module works",
    "Update CHANGELOG.md from recent commits",
)


@dataclass
class Suggestion:
    text: str
    source: str       # `commit` / `todo` / `branch` / `fallback`


def suggestions_disabled() -> bool:
    """Round 138: env override."""
    return os.environ.get(
        "PROMETHEUS_DISABLE_PROMPT_SUGGESTION", "",
    ).strip().lower() in ("1", "true", "yes")


def _git_subject(workdir: Path) -> Optional[str]:
    if shutil.which("git") is None:
        return None
    try:
        cp = subprocess.run(
            ["git", "-C", str(workdir), "log", "-1", "--format=%s"],
            capture_output=True, text=True, timeout=5, check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if cp.returncode != 0:
        return None
    s = (cp.stdout or "").strip().splitlines()
    return s[0] if s else None


def _git_branch(workdir: Path) -> Optional[str]:
    if shutil.which("git") is None:
        return None
    try:
        cp = subprocess.run(
            ["git", "-C", str(workdir), "branch", "--show-current"],
            capture_output=True, text=True, timeout=5, check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if cp.returncode != 0:
        return None
    branch = (cp.stdout or "").strip()
    if not branch or branch in ("main", "master"):
        return None
    return branch


_TODO_RX = re.compile(
    r"#\s*TODO[:\s]+([^\n#]{5,80})", re.I,
)


def _scan_todos(
    workdir: Path, *, max_files: int = 30,
) -> Optional[str]:
    """Round 138: scan top-level files for `TODO:` markers. Cheap
    — we cap the search to the first 30 source-shaped files in
    the workdir's top + immediate subdirs."""
    candidates: list[Path] = []
    for ext in ("py", "ts", "tsx", "js", "go", "rs", "rb", "java"):
        for p in workdir.glob(f"*.{ext}"):
            candidates.append(p)
        for p in workdir.glob(f"*/*.{ext}"):
            candidates.append(p)
        if len(candidates) > max_files:
            break
    candidates = candidates[:max_files]
    for p in candidates:
        try:
            txt = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        m = _TODO_RX.search(txt)
        if m:
            return m.group(1).strip()
    return None


def build_suggestion(
    *, workdir: Optional[Path] = None,
) -> Suggestion:
    """Round 138: assemble one suggestion per the priority
    order. Tries the cheap stuff first (git), falls back to
    static text when offline."""
    workdir = workdir or Path.cwd()
    subject = _git_subject(workdir)
    if subject and len(subject) < 100:
        return Suggestion(
            text=f"Continue work on: {subject}",
            source="commit",
        )
    todo = _scan_todos(workdir)
    if todo:
        return Suggestion(
            text=f"Finish: {todo}",
            source="todo",
        )
    branch = _git_branch(workdir)
    if branch:
        return Suggestion(
            text=f"Pick up '{branch}' branch work",
            source="branch",
        )
    # Deterministic-but-rotating fallback: use the workdir
    # path hash so different projects see different defaults.
    idx = hash(str(workdir)) % len(_FALLBACKS)
    return Suggestion(
        text=_FALLBACKS[idx],
        source="fallback",
    )


def render_ghost_text(s: Suggestion) -> str:
    """Round 138: how the suggestion appears in the input bar.
    The host applies a dim color to make it look greyed-out."""
    return s.text


def consume_typing(suggestion_text: str, typed: str) -> Optional[str]:
    """Round 138: decide whether to keep showing the suggestion
    given what the user has typed. Returns None when typing
    has dismissed the suggestion, otherwise returns the
    remaining greyed-out tail."""
    if not typed:
        return suggestion_text
    if suggestion_text.startswith(typed):
        return suggestion_text[len(typed):]
    return None
