"""Round 138: `prometheus rc` — remote-control session.

Generates a pairing URL + 6-digit code (and an ASCII QR-like
glyph for terminal display). Mobile/browser at the URL can
read the live transcript and send prompts; the local machine
retains full file-system access.

Pure data layer. The HTTP server uses round-118 bridge
infrastructure when actually serving requests; this module
covers the handshake state.
"""
from __future__ import annotations

import secrets
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class RemoteControlSession:
    code: str
    pair_token: str
    bridge_port: int
    public_url: str
    paired: bool = False
    read_only: bool = True
    allowed_actions: list[str] = field(default_factory=list)

    @property
    def display_url(self) -> str:
        return f"{self.public_url.rstrip('/')}/?code={self.code}"


def new_pair_code() -> str:
    """Round 138: 6-digit numeric pairing code."""
    return f"{secrets.randbelow(1_000_000):06d}"


def new_pair_token() -> str:
    return secrets.token_urlsafe(24)


def new_session(
    *, public_url: str, bridge_port: int,
) -> RemoteControlSession:
    return RemoteControlSession(
        code=new_pair_code(),
        pair_token=new_pair_token(),
        bridge_port=bridge_port,
        public_url=public_url,
        allowed_actions=["read_transcript", "send_prompt"],
    )


def pair(
    session: RemoteControlSession, *, code: str,
) -> bool:
    """Round 138: constant-time compare to avoid timing leaks
    on the 6-digit code."""
    import secrets as _sec
    if session.paired:
        return False
    if not _sec.compare_digest(
        session.code.encode("utf-8"),
        (code or "").encode("utf-8"),
    ):
        return False
    session.paired = True
    return True


# ---------- ASCII QR placeholder ----------


def render_ascii_qr(data: str, *, size: int = 21) -> str:
    """Round 138: deterministic ASCII glyph that visually
    encodes the URL hash. Not a real QR — but unambiguous
    for the user to verify what the mobile client should
    point at. Mobile QR scanners do not consume this; they
    consume the printed URL (which is what the user types
    into the browser anyway)."""
    import hashlib
    h = hashlib.sha256(data.encode("utf-8")).digest()
    # Expand into `size*size` bits.
    bits: list[int] = []
    while len(bits) < size * size:
        for byte in h:
            for i in range(8):
                bits.append((byte >> i) & 1)
                if len(bits) >= size * size:
                    break
        if len(bits) < size * size:
            h = hashlib.sha256(h).digest()
    out_lines: list[str] = []
    out_lines.append("+" + "-" * size + "+")
    for r in range(size):
        row_chars: list[str] = ["|"]
        for c in range(size):
            row_chars.append(
                "█" if bits[r * size + c] else " "
            )
        row_chars.append("|")
        out_lines.append("".join(row_chars))
    out_lines.append("+" + "-" * size + "+")
    return "\n".join(out_lines)


def render_pair_banner(session: RemoteControlSession) -> str:
    return (
        f"remote-control session ready\n"
        f"  url:   {session.display_url}\n"
        f"  code:  {session.code}\n"
        f"  port:  {session.bridge_port}\n"
        f"  mode:  {'read-only' if session.read_only else 'full'}\n"
        f"  /rc stop on local to end the session.\n\n"
        f"{render_ascii_qr(session.display_url)}"
    )


def stop_session(session: RemoteControlSession) -> None:
    """Round 138: mark the session as ended. The HTTP server
    shutdown is the host's responsibility (round-118)."""
    session.paired = False


# ---------- subcommand parser ----------


def parse_rc_argv(argv: list[str]) -> tuple[str, dict]:
    """Round 138: parse `prometheus rc [args]`. Returns the
    sub-action and any extras."""
    raw = list(argv or [])
    # Strip leading flags before action token.
    action = ""
    extras: dict = {}
    for tok in raw:
        if tok.startswith("--"):
            if "=" in tok:
                k, _, v = tok[2:].partition("=")
                extras[k] = v
            else:
                extras[tok[2:]] = True
        elif not action:
            action = tok
    return (action or "start", extras)
