"""Round 138: NO_FLICKER fullscreen renderer.

A virtual viewport that diffs against the previous frame and
only emits ANSI for changed cells. When PROMETHEUS_NO_FLICKER=1
is set, the host's render loop uses this instead of clearing
and repainting on every frame.

Two pieces:

  * `VirtualScreen` — fixed-size grid of cells; supports
    `set_cell` / `set_line` / `clear`.
  * `diff_render` — compute the minimal ANSI to transform an
    old frame into a new one.

Plus virtual-scroll: `Scrollback` keeps every message and
returns only the slice that fits the current viewport. The
renderer never has to clear-and-repaint on scroll.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Iterable, Optional


# ---------- env gates ----------


def no_flicker_enabled() -> bool:
    return os.environ.get(
        "PROMETHEUS_NO_FLICKER", "",
    ).strip().lower() in ("1", "true", "yes")


def virtual_scroll_disabled() -> bool:
    return os.environ.get(
        "PROMETHEUS_DISABLE_VIRTUAL_SCROLL", "",
    ).strip().lower() in ("1", "true", "yes")


# ---------- virtual screen ----------


@dataclass
class VirtualScreen:
    """Round 138: a fixed-size grid of cells. Each cell holds
    a single rune. The renderer compares two of these and emits
    only the diff."""
    rows: int
    cols: int
    grid: list[list[str]] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.grid:
            self.grid = [
                [" "] * self.cols for _ in range(self.rows)
            ]

    def clear(self) -> None:
        for row in self.grid:
            for c in range(self.cols):
                row[c] = " "

    def set_cell(self, row: int, col: int, ch: str) -> None:
        if 0 <= row < self.rows and 0 <= col < self.cols:
            self.grid[row][col] = ch[0] if ch else " "

    def set_line(self, row: int, text: str) -> None:
        if not (0 <= row < self.rows):
            return
        clipped = text[: self.cols]
        for c in range(self.cols):
            self.grid[row][c] = clipped[c] if c < len(clipped) else " "

    def line(self, row: int) -> str:
        if 0 <= row < self.rows:
            return "".join(self.grid[row])
        return ""

    def snapshot(self) -> list[str]:
        return ["".join(row) for row in self.grid]

    def resize(self, rows: int, cols: int) -> None:
        new_grid: list[list[str]] = []
        for r in range(rows):
            row_chars: list[str] = []
            for c in range(cols):
                if r < self.rows and c < self.cols:
                    row_chars.append(self.grid[r][c])
                else:
                    row_chars.append(" ")
            new_grid.append(row_chars)
        self.rows = rows
        self.cols = cols
        self.grid = new_grid


# ---------- diff render ----------


def _move_cursor(row: int, col: int) -> str:
    # ANSI cursor positions are 1-indexed.
    return f"\x1b[{row + 1};{col + 1}H"


@dataclass
class DiffStats:
    """Round 138: telemetry from a single render pass."""
    cells_changed: int = 0
    rows_touched: int = 0
    bytes_emitted: int = 0


def diff_render(
    old: VirtualScreen, new: VirtualScreen,
) -> tuple[str, DiffStats]:
    """Round 138: produce the minimal ANSI sequence that
    transforms `old` into `new`. Returns (sequence, stats)."""
    stats = DiffStats()
    if old.rows != new.rows or old.cols != new.cols:
        # Size change — full repaint.
        out: list[str] = ["\x1b[H"]
        for r in range(new.rows):
            out.append(_move_cursor(r, 0))
            line = new.line(r)
            out.append(line)
            stats.cells_changed += new.cols
            stats.rows_touched += 1
        body = "".join(out)
        stats.bytes_emitted = len(body)
        return (body, stats)
    pieces: list[str] = []
    for r in range(new.rows):
        old_line = old.line(r)
        new_line = new.line(r)
        if old_line == new_line:
            continue
        stats.rows_touched += 1
        # Find the leftmost + rightmost differing column to
        # avoid repainting unchanged prefixes.
        left = 0
        while (
            left < new.cols
            and left < len(old_line)
            and old_line[left] == new_line[left]
        ):
            left += 1
        right = new.cols - 1
        while (
            right > left
            and right < len(old_line)
            and old_line[right] == new_line[right]
        ):
            right -= 1
        slice_text = new_line[left:right + 1]
        pieces.append(_move_cursor(r, left))
        pieces.append(slice_text)
        stats.cells_changed += len(slice_text)
    body = "".join(pieces)
    stats.bytes_emitted = len(body)
    return (body, stats)


# ---------- scrollback ----------


@dataclass
class Scrollback:
    """Round 138: virtual scrollback. Holds every message ever
    rendered; the viewport asks for the slice that fits."""
    messages: list[str] = field(default_factory=list)
    offset: int = 0          # how many lines from bottom we've scrolled up

    def append(self, line: str) -> None:
        if not isinstance(line, str):
            line = str(line)
        for sub in line.split("\n"):
            self.messages.append(sub)

    def visible(self, *, rows: int) -> list[str]:
        """Return the slice the viewport should render. When
        offset=0, this is the latest `rows` messages. Higher
        offset scrolls back in time."""
        if not self.messages:
            return []
        end = max(0, len(self.messages) - self.offset)
        start = max(0, end - rows)
        return list(self.messages[start:end])

    def scroll_up(self, n: int = 1) -> int:
        max_offset = max(0, len(self.messages) - 1)
        self.offset = min(max_offset, self.offset + n)
        return self.offset

    def scroll_down(self, n: int = 1) -> int:
        self.offset = max(0, self.offset - n)
        return self.offset

    def reset(self) -> None:
        self.offset = 0


# ---------- viewport orchestration ----------


def render_messages_to_screen(
    screen: VirtualScreen,
    messages: Iterable[str],
) -> None:
    """Round 138: paint a sequence of message lines onto the
    virtual screen, starting at row 0. Lines longer than the
    viewport are clipped."""
    screen.clear()
    for r, line in enumerate(list(messages)[: screen.rows]):
        screen.set_line(r, line)
