"""Round 147-final-v3: BrowserAutomation tool via Playwright.

The tool dispatches one of five actions: navigate, click,
type, screenshot, extract. Sandboxed to session scope —
each call spawns/reuses a single Playwright browser instance
held on the runtime.

When `playwright` isn't installed or
`PROMETHEUS_WEB_BROWSER=0`, the tool returns a clean
unsupported error.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from prometheus.tools.base import (
    Tool, SideEffect, ToolContext, ToolResult,
)


_TRUTHY = ("1", "true", "yes", "on")


def web_browser_enabled() -> bool:
    return os.environ.get(
        "PROMETHEUS_WEB_BROWSER", "",
    ).strip().lower() in _TRUTHY


def playwright_available() -> bool:
    """Round 147-final-v3: cheap import check."""
    try:
        import playwright  # noqa: F401
        return True
    except ImportError:
        return False


VALID_ACTIONS = (
    "navigate", "click", "type", "screenshot", "extract",
)


# ---------- the tool ----------


class BrowserAutomation(Tool):
    """Round 147-final-v3: Playwright-backed browser tool."""
    name = "browser_automation"
    description = (
        "Browser automation: navigate, click, type, "
        "screenshot, extract. Requires "
        "PROMETHEUS_WEB_BROWSER=1 + playwright installed."
    )
    schema = {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": list(VALID_ACTIONS),
            },
            "url": {"type": "string"},
            "selector": {"type": "string"},
            "text": {"type": "string"},
            "screenshot_path": {"type": "string"},
        },
        "required": ["action"],
    }
    side_effect = SideEffect.NETWORK

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        if not web_browser_enabled():
            return ToolResult(
                error=True,
                output=(
                    "browser_automation needs "
                    "PROMETHEUS_WEB_BROWSER=1 (opt-in)."
                ),
            )
        if not playwright_available():
            return ToolResult(
                error=True,
                output=(
                    "browser_automation needs the playwright "
                    "package: `pip install playwright "
                    "&& playwright install chromium`."
                ),
            )
        action = str(args.get("action", "")).lower()
        if action not in VALID_ACTIONS:
            return ToolResult(
                error=True,
                output=f"unknown action: {action}",
            )
        # The actual driver routine lives in `_drive` so we
        # can mock it in tests without instantiating
        # playwright.
        try:
            return await _drive(action, args, ctx)
        except Exception as e:
            return ToolResult(
                error=True,
                output=f"browser_automation failed: {e}",
            )


async def _drive(
    action: str, args: dict[str, Any], ctx: ToolContext,
) -> ToolResult:
    """Round 147-final-v3: thin Playwright dispatcher.

    Production builds re-use a single browser instance held
    on `ctx.runtime` — first call creates it, subsequent
    calls re-use. Tests can monkeypatch this function."""
    from playwright.async_api import async_playwright
    runtime = getattr(ctx, "runtime", None)
    browser = getattr(runtime, "_browser", None) if runtime else None
    page = getattr(runtime, "_page", None) if runtime else None
    if browser is None or page is None:
        pw = await async_playwright().start()
        browser = await pw.chromium.launch(headless=True)
        page = await browser.new_page()
        if runtime is not None:
            try:
                runtime._browser = browser
                runtime._page = page
            except Exception:
                pass
    if action == "navigate":
        url = str(args.get("url", "")).strip()
        if not url:
            return ToolResult(error=True, output="url required")
        await page.goto(url)
        return ToolResult(
            error=False,
            output=f"navigated → {url}",
        )
    if action == "click":
        sel = str(args.get("selector", "")).strip()
        if not sel:
            return ToolResult(error=True, output="selector required")
        await page.click(sel)
        return ToolResult(error=False, output=f"clicked {sel}")
    if action == "type":
        sel = str(args.get("selector", "")).strip()
        text = str(args.get("text", ""))
        if not sel:
            return ToolResult(error=True, output="selector required")
        await page.type(sel, text)
        return ToolResult(
            error=False,
            output=f"typed {len(text)} chars into {sel}",
        )
    if action == "screenshot":
        target = args.get("screenshot_path") or "screenshot.png"
        path = Path(target)
        if not path.is_absolute():
            path = ctx.workdir / path
        await page.screenshot(path=str(path))
        return ToolResult(
            error=False,
            output=f"screenshot → {path}",
        )
    if action == "extract":
        body = await page.content()
        return ToolResult(
            error=False,
            output=body[:30_000],
            summary=f"extracted {len(body)} chars",
        )
    return ToolResult(error=True, output=f"unknown action {action}")
