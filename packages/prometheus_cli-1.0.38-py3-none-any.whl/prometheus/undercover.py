"""Round 143-final-v3: undercover mode.

Auto-activates in non-internal repos (detected via the git
remote URL). When active, scrubs Prometheus brand markers
and "Co-Authored-By: Prometheus" trailers from commit
messages, PR descriptions, and any string the host runs
through `scrub()`.

Env override:
  PROMETHEUS_UNDERCOVER=1 — force on
  PROMETHEUS_UNDERCOVER=0 — force off
  unset → auto-detect
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


_TRUTHY = ("1", "true", "yes", "on")
_FALSY = ("0", "false", "no", "off")


# Substrings considered "internal" — when the git remote URL
# contains any of these, Prometheus treats the repo as
# internal and stays out of undercover mode.
_INTERNAL_HOSTS: tuple[str, ...] = (
    "anthropic", "prometheus-cli",
)


def _git_remote_url(workdir: Path) -> Optional[str]:
    if shutil.which("git") is None:
        return None
    try:
        cp = subprocess.run(
            ["git", "-C", str(workdir), "remote", "get-url", "origin"],
            capture_output=True, text=True, timeout=5, check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if cp.returncode != 0:
        return None
    return (cp.stdout or "").strip() or None


def auto_undercover_for(workdir: Path) -> bool:
    """Round 143-final-v3: should we go undercover here? True
    when the git remote points to a non-internal host."""
    url = _git_remote_url(workdir)
    if url is None:
        # No git remote → safest default is undercover
        # (we don't know if we're being recorded).
        return True
    low = url.lower()
    for host in _INTERNAL_HOSTS:
        if host in low:
            return False
    return True


def undercover_active(*, workdir: Optional[Path] = None) -> bool:
    """Round 143-final-v3: env override > auto-detect."""
    raw = os.environ.get("PROMETHEUS_UNDERCOVER", "").strip().lower()
    if raw in _TRUTHY:
        return True
    if raw in _FALSY:
        return False
    return auto_undercover_for(workdir or Path.cwd())


# ---------- scrubbing ----------


_BRAND_RXES: tuple[re.Pattern[str], ...] = (
    re.compile(
        r"^\s*Co-Authored-By:\s*Prometheus.*$",
        re.IGNORECASE | re.MULTILINE,
    ),
    re.compile(
        r"\b(?:PrometheUS|Prometheus\s+CLI|prometheus-cli)\b",
        re.IGNORECASE,
    ),
    re.compile(
        r"🤖\s*Generated\s+with.*Prometheus.*",
        re.IGNORECASE,
    ),
    re.compile(
        r"\bvia\s+Prometheus\b", re.IGNORECASE,
    ),
)


# Project codename allowlist — the host can append more.
_PROJECT_CODENAMES: list[str] = [
    "kairos", "lodestone", "moonshot",
]


def add_codename(name: str) -> None:
    """Round 143-final-v3: register a project codename so
    `scrub()` strips it from outgoing text."""
    n = (name or "").strip()
    if n and n not in _PROJECT_CODENAMES:
        _PROJECT_CODENAMES.append(n)


def scrub(
    text: str, *, workdir: Optional[Path] = None,
) -> str:
    """Round 143-final-v3: scrub brand mentions + project
    codenames from a string when undercover is active.
    No-op when not active."""
    if not text:
        return text
    if not undercover_active(workdir=workdir):
        return text
    out = text
    for rx in _BRAND_RXES:
        out = rx.sub("", out)
    for name in _PROJECT_CODENAMES:
        if not name:
            continue
        out = re.sub(
            r"\b" + re.escape(name) + r"\b",
            "[redacted]",
            out, flags=re.IGNORECASE,
        )
    # Tidy double-blank-lines that the trailer removal can
    # leave behind.
    out = re.sub(r"\n{3,}", "\n\n", out).strip("\n")
    return out + ("\n" if text.endswith("\n") else "")


def scrub_commit_message(message: str, *, workdir: Path) -> str:
    """Round 143-final-v3: targeted commit-message scrub —
    keeps the subject + body but strips trailers."""
    return scrub(message, workdir=workdir)


def scrub_pr_description(body: str, *, workdir: Path) -> str:
    """Round 143-final-v3: PR description scrub."""
    return scrub(body, workdir=workdir)


# ---------- status renderer ----------


@dataclass
class UndercoverStatus:
    active: bool
    source: str       # `env-on` / `env-off` / `auto-internal` /
                      # `auto-external` / `auto-no-remote`
    remote_url: Optional[str]


def status(workdir: Path) -> UndercoverStatus:
    raw = os.environ.get("PROMETHEUS_UNDERCOVER", "").strip().lower()
    if raw in _TRUTHY:
        return UndercoverStatus(
            active=True, source="env-on",
            remote_url=_git_remote_url(workdir),
        )
    if raw in _FALSY:
        return UndercoverStatus(
            active=False, source="env-off",
            remote_url=_git_remote_url(workdir),
        )
    url = _git_remote_url(workdir)
    if url is None:
        return UndercoverStatus(
            active=True, source="auto-no-remote", remote_url=None,
        )
    low = url.lower()
    for host in _INTERNAL_HOSTS:
        if host in low:
            return UndercoverStatus(
                active=False, source="auto-internal", remote_url=url,
            )
    return UndercoverStatus(
        active=True, source="auto-external", remote_url=url,
    )


def render_status(s: UndercoverStatus) -> str:
    parts = [
        f"undercover: {'on' if s.active else 'off'}",
        f"  source:  {s.source}",
    ]
    if s.remote_url:
        parts.append(f"  remote:  {s.remote_url}")
    return "\n".join(parts)
