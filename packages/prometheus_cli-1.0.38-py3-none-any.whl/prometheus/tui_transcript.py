"""Round 141: transcript viewer (Ctrl+O).

A modal scrollable view of the full conversation: user
messages, assistant text, tool calls and results. Search-as-
you-type with `/`, `n`/`N` navigate matches, `Esc` or `Ctrl+O`
again closes.

Pure data layer. The Textual host's transcript modal binds
its keystrokes through `handle_key`.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


# ---------- per-line item ----------


@dataclass
class TranscriptLine:
    role: str        # user / assistant / tool / system
    text: str
    index: int       # ordinal in the source message list


def build_lines(
    messages: list[dict[str, Any]],
) -> list[TranscriptLine]:
    """Round 141: flatten messages into searchable lines. Each
    role gets a one-line header followed by indented body
    lines so the search hits map cleanly back to the source."""
    out: list[TranscriptLine] = []
    for i, m in enumerate(messages):
        if not isinstance(m, dict):
            continue
        role = str(m.get("role") or "")
        if not role:
            continue
        out.append(TranscriptLine(
            role=role,
            text=f"── {role} ──",
            index=i,
        ))
        content = m.get("content")
        body = ""
        if isinstance(content, str):
            body = content
        elif isinstance(content, list):
            parts: list[str] = []
            for blk in content:
                if isinstance(blk, dict):
                    parts.append(str(blk.get("text", "")))
                else:
                    parts.append(str(blk))
            body = "\n".join(p for p in parts if p)
        for line in body.splitlines():
            out.append(TranscriptLine(
                role=role,
                text="  " + line,
                index=i,
            ))
        for call in m.get("tool_calls") or []:
            name = (
                call.get("name") if isinstance(call, dict)
                else getattr(call, "name", "")
            )
            out.append(TranscriptLine(
                role="tool_call",
                text=f"  ● {name}",
                index=i,
            ))
    return out


# ---------- viewer state ----------


@dataclass
class TranscriptViewer:
    """Round 141: state machine for the modal viewer."""
    open: bool = False
    lines: list[TranscriptLine] = field(default_factory=list)
    cursor: int = 0          # currently highlighted line
    page_size: int = 20
    search_active: bool = False
    search_buffer: str = ""
    matches: list[int] = field(default_factory=list)
    match_idx: int = 0


def open_viewer(
    state: TranscriptViewer,
    *, messages: list[dict[str, Any]],
) -> None:
    state.lines = build_lines(messages)
    state.cursor = max(0, len(state.lines) - 1)
    state.search_active = False
    state.search_buffer = ""
    state.matches = []
    state.match_idx = 0
    state.open = True


def close_viewer(state: TranscriptViewer) -> None:
    state.open = False
    state.search_active = False
    state.search_buffer = ""
    state.matches = []
    state.match_idx = 0


def move_cursor(
    state: TranscriptViewer, delta: int,
) -> int:
    if not state.lines:
        return 0
    new = state.cursor + delta
    new = max(0, min(len(state.lines) - 1, new))
    state.cursor = new
    return new


def page(
    state: TranscriptViewer, direction: int,
) -> int:
    delta = state.page_size * (1 if direction > 0 else -1)
    return move_cursor(state, delta)


# ---------- search ----------


def begin_search(state: TranscriptViewer) -> None:
    state.search_active = True
    state.search_buffer = ""
    state.matches = []
    state.match_idx = 0


def commit_search(state: TranscriptViewer) -> int:
    """Round 141: finalize the current search query. Computes
    the match list + jumps to the first match. Returns the
    number of matches found."""
    state.search_active = False
    q = state.search_buffer.lower()
    if not q:
        state.matches = []
        return 0
    state.matches = [
        i for i, line in enumerate(state.lines)
        if q in line.text.lower()
    ]
    state.match_idx = 0
    if state.matches:
        state.cursor = state.matches[0]
    return len(state.matches)


def append_search_char(state: TranscriptViewer, ch: str) -> None:
    if not state.search_active:
        return
    if ch == "\b" or ch == "backspace":
        state.search_buffer = state.search_buffer[:-1]
        return
    if len(ch) == 1 and ch.isprintable():
        state.search_buffer += ch


def cancel_search(state: TranscriptViewer) -> None:
    state.search_active = False
    state.search_buffer = ""


def next_match(state: TranscriptViewer) -> Optional[int]:
    if not state.matches:
        return None
    state.match_idx = (state.match_idx + 1) % len(state.matches)
    state.cursor = state.matches[state.match_idx]
    return state.cursor


def prev_match(state: TranscriptViewer) -> Optional[int]:
    if not state.matches:
        return None
    state.match_idx = (
        state.match_idx - 1
    ) % len(state.matches)
    state.cursor = state.matches[state.match_idx]
    return state.cursor


# ---------- key dispatcher ----------


def handle_key(
    state: TranscriptViewer, key: str,
) -> str:
    """Round 141: feed a key into the viewer. Returns one of:
      `closed` — viewer was closed
      `searched` — search committed
      `moved` — cursor moved
      `noop` — key consumed but no state change relevant to host
    """
    if not state.open:
        return "noop"
    k = key
    if state.search_active:
        if k in ("escape", "esc"):
            cancel_search(state)
            return "noop"
        if k in ("enter", "return"):
            commit_search(state)
            return "searched"
        append_search_char(state, k)
        return "noop"
    if k in ("escape", "esc", "ctrl+o"):
        close_viewer(state)
        return "closed"
    if k in ("up", "k"):
        move_cursor(state, -1)
        return "moved"
    if k in ("down", "j"):
        move_cursor(state, 1)
        return "moved"
    if k in ("pageup",):
        page(state, -1)
        return "moved"
    if k in ("pagedown",):
        page(state, 1)
        return "moved"
    if k == "/":
        begin_search(state)
        return "noop"
    if k == "n":
        next_match(state)
        return "moved"
    if k == "N":
        prev_match(state)
        return "moved"
    return "noop"


# ---------- render helpers ----------


def visible_window(
    state: TranscriptViewer, *, rows: int,
) -> list[TranscriptLine]:
    if not state.lines:
        return []
    half = rows // 2
    start = max(0, state.cursor - half)
    end = min(len(state.lines), start + rows)
    if end - start < rows:
        start = max(0, end - rows)
    return state.lines[start:end]


def render_status(state: TranscriptViewer) -> str:
    if not state.open:
        return ""
    parts: list[str] = [f"line {state.cursor + 1}/{len(state.lines)}"]
    if state.search_active:
        parts.append(f"search: /{state.search_buffer}")
    elif state.matches:
        parts.append(
            f"match {state.match_idx + 1}/{len(state.matches)}"
        )
    parts.append("Esc to close · / to search · n/N next/prev")
    return "  ·  ".join(parts)
