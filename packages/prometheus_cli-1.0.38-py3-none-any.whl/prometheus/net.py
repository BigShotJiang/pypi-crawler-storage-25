"""Round 179 / Dimension 1 — centralized network kwargs.

Every httpx client in Prometheus calls one of two helpers in this
module instead of constructing its own kwargs. The result is uniform
behaviour across the codebase for:

  * Corporate HTTP/HTTPS proxies (`HTTP_PROXY`, `HTTPS_PROXY`,
    `NO_PROXY` / `no_proxy`).
  * Custom CA bundles for SSL-inspection environments
    (`REQUESTS_CA_BUNDLE`, `SSL_CERT_FILE`).
  * Insecure-mode opt-in (`PROMETHEUS_INSECURE=1`) for internal
    self-signed-cert deployments. Off by default.

Pre-R179 every client constructed its own `httpx.AsyncClient(...)`
without forwarding any of these env vars — so a user running
behind a corporate proxy or behind an SSL-inspecting firewall
saw every web tool, every MCP HTTP transport, and the LLM
provider itself silently fail. Commercial-grade gap.

The helpers return a kwargs dict so call sites can splat them
into `httpx.AsyncClient(**net_kwargs(), timeout=...)`. This keeps
the original timeout/headers/etc. arguments local to the call
site while picking up proxy + verify uniformly.
"""
from __future__ import annotations

import os
from typing import Any


def _proxy_settings() -> dict[str, str] | None:
    """Build the `proxy` mapping httpx expects.

    Honours the standard env-var contract used by curl, wget,
    requests, and pip:

      * `HTTPS_PROXY` (and lowercase `https_proxy`) — proxy for
        HTTPS targets.
      * `HTTP_PROXY`  (and lowercase `http_proxy`)  — proxy for
        HTTP targets.
      * `ALL_PROXY`   (lowercase `all_proxy`)        — fallback
        for both schemes.

    Returns None when nothing is configured, in which case the
    client makes direct connections.
    """
    https_proxy = (
        os.environ.get("HTTPS_PROXY")
        or os.environ.get("https_proxy")
        or os.environ.get("ALL_PROXY")
        or os.environ.get("all_proxy")
        or ""
    ).strip()
    http_proxy = (
        os.environ.get("HTTP_PROXY")
        or os.environ.get("http_proxy")
        or os.environ.get("ALL_PROXY")
        or os.environ.get("all_proxy")
        or ""
    ).strip()
    out: dict[str, str] = {}
    if https_proxy:
        out["https://"] = https_proxy
    if http_proxy:
        out["http://"] = http_proxy
    return out or None


def _verify_setting() -> bool | str:
    """Resolve the SSL `verify` kwarg.

    Order of precedence:
      1. `PROMETHEUS_INSECURE=1` → `verify=False` (self-signed,
         testing only — explicit opt-in by the operator).
      2. `REQUESTS_CA_BUNDLE` (path) → `verify=<that path>`.
         Used by corporate SSL-inspection middleboxes.
      3. `SSL_CERT_FILE` (path) → `verify=<that path>`. Same
         purpose, alternative env-var name from OpenSSL.
      4. Otherwise → `verify=True`. System trust store.
    """
    if os.environ.get("PROMETHEUS_INSECURE", "").strip() in ("1", "true", "yes"):
        return False
    # Round 182: also honour CURL_CA_BUNDLE (curl convention) as a
    # third source. Some corporate environments only set this one
    # because their MITM-CA install script targets curl. The order
    # `REQUESTS_CA_BUNDLE` → `SSL_CERT_FILE` → `CURL_CA_BUNDLE`
    # follows what `requests` itself does internally.
    bundle = (
        os.environ.get("REQUESTS_CA_BUNDLE")
        or os.environ.get("SSL_CERT_FILE")
        or os.environ.get("CURL_CA_BUNDLE")
        # 1.0.3: Claude Code parity — Node CLIs (claude-code, codex,
        # gemini-cli) all read this. Honour it so a corporate CA
        # install that already works for those tools works for
        # Prometheus without renaming.
        or os.environ.get("NODE_EXTRA_CA_CERTS")
        or ""
    ).strip()
    if bundle and os.path.exists(bundle):
        return bundle
    return True


def net_kwargs(**overrides: Any) -> dict[str, Any]:
    """Return the kwargs every httpx client should pass.

    Usage:
        async with httpx.AsyncClient(**net_kwargs(timeout=20.0)) as cli:
            r = await cli.get(url)

    Caller-supplied `overrides` win — passing `verify=False` here
    disables verification regardless of env. The order is:
    base → env-derived → call-site overrides.
    """
    out: dict[str, Any] = {}
    proxy = _proxy_settings()
    if proxy is not None:
        # Modern httpx accepts a single `proxy` URL or a `mounts`
        # dict for per-scheme routing. The `mounts` style is the
        # documented multi-scheme path. We construct an
        # `httpx.HTTPTransport` proxy mount per scheme — but to
        # stay backward-compatible with older httpx versions that
        # only support a single `proxy` URL, we fall back when
        # only one scheme is set.
        if len(proxy) == 1:
            out["proxy"] = next(iter(proxy.values()))
        else:
            try:
                import httpx
                out["mounts"] = {
                    scheme: httpx.AsyncHTTPTransport(proxy=url)
                    for scheme, url in proxy.items()
                }
            except Exception:
                # Defensive — don't crash on any httpx-version
                # incompatibility; just skip the proxy.
                pass
    out["verify"] = _verify_setting()
    out.update(overrides)
    return out


def sync_net_kwargs(**overrides: Any) -> dict[str, Any]:
    """Same as net_kwargs() but produces sync `httpx.Client`-shaped
    transport mounts (uses `httpx.HTTPTransport` instead of the
    async one). Used by the sync foundry path.
    """
    out: dict[str, Any] = {}
    proxy = _proxy_settings()
    if proxy is not None:
        if len(proxy) == 1:
            out["proxy"] = next(iter(proxy.values()))
        else:
            try:
                import httpx
                out["mounts"] = {
                    scheme: httpx.HTTPTransport(proxy=url)
                    for scheme, url in proxy.items()
                }
            except Exception:
                pass
    out["verify"] = _verify_setting()
    out.update(overrides)
    return out


def is_no_proxy_host(host: str) -> bool:
    """Honour `NO_PROXY` (and lowercase `no_proxy`) for any caller
    that wants to short-circuit the proxy decision themselves —
    most callers don't need this because httpx applies NO_PROXY
    when proxies are env-driven, but our `mounts` construction
    overrides that. Returns True when the host should bypass.

    Format follows the curl/requests convention: comma-separated
    list of hostname suffixes; `*` means everything.
    """
    raw = (
        os.environ.get("NO_PROXY")
        or os.environ.get("no_proxy")
        or ""
    ).strip()
    if not raw:
        return False
    if raw.strip() == "*":
        return True
    host_l = host.lower().strip(".")
    for entry in raw.split(","):
        suffix = entry.strip().lower().strip(".")
        if not suffix:
            continue
        # Round 179: accept `*.example.com` form (dotted-wildcard
        # syntax used by curl, requests, and Claude Code's docs).
        # Strip the leading `*.` so the suffix matches both the
        # bare domain and any subdomain.
        if suffix.startswith("*."):
            suffix = suffix[2:]
        if host_l == suffix or host_l.endswith("." + suffix):
            return True
    return False
