"""Round 142: context-management commands — /break-cache and
/force-snip.

`/break-cache` invalidates the prompt cache so the next turn
re-evaluates from scratch. Useful when the user changes
external context (file edits) the agent is supposed to pick
up but the cached prefix is masking.

`/force-snip` immediately runs history snip — drop old
messages, preserve the last N — without waiting for the
auto-compact threshold.

Pure data layer. The host's session loop calls these.
"""
from __future__ import annotations

import os
import time
import uuid
from dataclasses import dataclass
from typing import Any, Optional


# ---------- /break-cache ----------


def break_cache_enabled() -> bool:
    """Round 142: env gate for `/break-cache` — opt-in."""
    return os.environ.get(
        "PROMETHEUS_BREAK_CACHE", "",
    ).strip().lower() in ("1", "true", "yes", "on")


@dataclass
class CacheBreakResult:
    new_marker: str
    invalidated_at: int


def break_cache(*, current_marker: str = "") -> CacheBreakResult:
    """Round 142: produce a fresh cache marker. The agent loop
    threads this into the next request so the provider sees
    a different prefix and skips its cache."""
    return CacheBreakResult(
        new_marker=str(uuid.uuid4()),
        invalidated_at=int(time.time()),
    )


def render_break_cache_banner(res: CacheBreakResult) -> str:
    return (
        f"prompt cache invalidated\n"
        f"  marker: {res.new_marker[:16]}…\n"
        f"  next turn re-evaluates the full context."
    )


# ---------- /force-snip ----------


@dataclass
class SnipResult:
    kept: int
    dropped: int


def _is_system(m: Any) -> bool:
    return isinstance(m, dict) and m.get("role") == "system"


def force_snip(
    messages: list[Any], *, keep_last: int = 20,
) -> tuple[list[Any], SnipResult]:
    """Round 142: drop messages from the front, preserving:
      * the system prompt (always)
      * the last `keep_last` non-system messages

    Returns the new list + accounting."""
    if not messages:
        return ([], SnipResult(kept=0, dropped=0))
    keep_last = max(1, int(keep_last))
    head: list[Any] = []
    if _is_system(messages[0]):
        head.append(messages[0])
        body = messages[1:]
    else:
        body = list(messages)
    if len(body) <= keep_last:
        return (head + body, SnipResult(kept=len(body), dropped=0))
    dropped_n = len(body) - keep_last
    keep = body[-keep_last:]
    return (
        head + keep,
        SnipResult(kept=len(keep), dropped=dropped_n),
    )


def render_snip_banner(res: SnipResult) -> str:
    return (
        f"history snipped — kept {res.kept} message(s), "
        f"dropped {res.dropped}"
    )


def force_snip_keep_last_default() -> int:
    """Round 142: env-overridable default for /force-snip."""
    raw = os.environ.get(
        "PROMETHEUS_FORCE_SNIP_KEEP", "",
    ).strip()
    if not raw:
        return 20
    try:
        n = int(raw)
        return max(1, n)
    except ValueError:
        return 20
