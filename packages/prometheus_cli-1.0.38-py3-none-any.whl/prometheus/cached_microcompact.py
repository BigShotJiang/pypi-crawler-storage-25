"""Round 144-final: cache-aware micro-compaction.

When the provider's prompt cache is active (Anthropic /
OpenRouter), a compaction pass that touches the cached
prefix invalidates the whole cache hit. This module trims
*only* the messages beyond the cache boundary, preserving
every byte of the cached prefix.

The boundary is the index of the last cached message. The
host tracks it via response headers (Anthropic emits
`prompt_token_count` / `cache_read_input_tokens`); when those
aren't available, callers can pass `cache_boundary=None` to
fall back to the standard compaction pipeline.

Pure data layer.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class MicrocompactResult:
    new_messages: list[dict[str, Any]]
    dropped: int
    preserved_prefix: int
    bytes_saved: int


def _bytes_of(messages: list[dict[str, Any]]) -> int:
    return sum(len(json.dumps(m, default=str)) for m in messages)


def microcompact(
    messages: list[dict[str, Any]],
    *,
    cache_boundary: Optional[int] = None,
    target_tail_messages: int = 20,
) -> MicrocompactResult:
    """Round 144-final: trim messages beyond the cache
    boundary down to `target_tail_messages`.

    `cache_boundary` is the count of leading messages we
    must preserve byte-for-byte. When None, we fall back to
    a no-op (caller should use the standard pipeline)."""
    if cache_boundary is None or cache_boundary <= 0:
        return MicrocompactResult(
            new_messages=list(messages),
            dropped=0,
            preserved_prefix=0,
            bytes_saved=0,
        )
    if not messages:
        return MicrocompactResult(
            new_messages=[],
            dropped=0,
            preserved_prefix=0,
            bytes_saved=0,
        )
    boundary = min(cache_boundary, len(messages))
    prefix = messages[:boundary]
    tail = messages[boundary:]
    if len(tail) <= target_tail_messages:
        return MicrocompactResult(
            new_messages=list(messages),
            dropped=0,
            preserved_prefix=boundary,
            bytes_saved=0,
        )
    keep = tail[-target_tail_messages:]
    dropped = tail[:-target_tail_messages]
    bytes_before = _bytes_of(messages)
    new_messages = list(prefix) + list(keep)
    bytes_after = _bytes_of(new_messages)
    return MicrocompactResult(
        new_messages=new_messages,
        dropped=len(dropped),
        preserved_prefix=boundary,
        bytes_saved=bytes_before - bytes_after,
    )


def render_result(r: MicrocompactResult) -> str:
    return (
        f"microcompact: preserved {r.preserved_prefix} "
        f"cached message(s); dropped {r.dropped}; "
        f"saved {r.bytes_saved:,} bytes"
    )
