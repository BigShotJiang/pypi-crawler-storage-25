"""Round 170 / B3 — iTerm2 native progress bar (OSC 9;4).

iTerm2 (and a handful of other modern terminals) supports a
proprietary OSC 9;4 escape sequence that drives a native
progress indicator on the macOS Dock + the tab title.

Public API:
  • `is_iterm2()` — environment-based detection.
  • `progress_indeterminate()` — start an indeterminate spinner.
  • `progress_set(percent)` — show a determinate bar at 0..100.
  • `progress_clear()` — clear the indicator.
  • `with_progress(stream, percent=None)` — context manager that
    sets a progress on enter, clears on exit (including on
    exception). Drops to a no-op silently on non-iTerm2 terminals,
    so the host can wrap any long-running operation without
    branching on terminal type.

The OSC 9;4 protocol (iTerm2 docs):
    \x1b]9;4;<state>;<percent>\x1b\\
  state: 0 = remove   1 = set    2 = error    3 = indeterminate    4 = pause

On non-iTerm2 terminals the sequence is silently ignored
because the OSC handler doesn't recognise the 9;4 prefix; we
also gate emission on `ITERM_SESSION_ID` so we don't spam the
output anywhere it could matter.
"""
from __future__ import annotations

import contextlib
import os
from typing import Optional


# ---- detection -------------------------------------------------


def is_iterm2() -> bool:
    """Round 170 / B3: True when running inside iTerm2.

    iTerm2 sets `ITERM_SESSION_ID` for every shell session
    and (more recently) `LC_TERMINAL=iTerm2`. We accept either.
    """
    if os.environ.get("ITERM_SESSION_ID"):
        return True
    if os.environ.get("LC_TERMINAL", "").lower() == "iterm2":
        return True
    if os.environ.get("TERM_PROGRAM", "").lower() == "iterm.app":
        return True
    return False


# ---- escape sequences -----------------------------------------


# State codes per iTerm2's OSC 9;4 protocol.
_STATE_REMOVE = 0
_STATE_SET = 1
_STATE_ERROR = 2
_STATE_INDETERMINATE = 3
_STATE_PAUSE = 4


def _osc94(state: int, percent: int = 0) -> str:
    """Build the raw OSC 9;4 sequence. Terminator `\\x1b\\\\` (ESC
    backslash) is the standard ST."""
    return f"\x1b]9;4;{state};{int(percent)}\x1b\\"


def progress_indeterminate() -> str:
    """Indeterminate-spinner variant. Use when the work has no
    knowable percentage (`Bash(pytest -q)` for example)."""
    return _osc94(_STATE_INDETERMINATE, 0)


def progress_set(percent: int) -> str:
    """Determinate progress at `percent` (0..100). Values are
    clamped to the valid range."""
    p = max(0, min(100, int(percent)))
    return _osc94(_STATE_SET, p)


def progress_error(percent: int = 0) -> str:
    """Mark the progress indicator as errored — the iTerm2 dock
    icon turns red. Useful when a tool returns non-zero."""
    p = max(0, min(100, int(percent)))
    return _osc94(_STATE_ERROR, p)


def progress_pause(percent: int = 0) -> str:
    """Paused state — used during inline approvals so the dock
    icon shows the work isn't actively running."""
    p = max(0, min(100, int(percent)))
    return _osc94(_STATE_PAUSE, p)


def progress_clear() -> str:
    """Clear the progress indicator. Always safe to emit."""
    return _osc94(_STATE_REMOVE, 0)


# ---- writer helpers --------------------------------------------


def _write(stream, sequence: str) -> None:
    """Write `sequence` to `stream` and flush. Best-effort:
    swallows OSError so a closed stream during shutdown doesn't
    crash the host."""
    try:
        stream.write(sequence)
        if hasattr(stream, "flush"):
            stream.flush()
    except (OSError, ValueError):
        pass


def emit_indeterminate(stream) -> None:
    """Emit an indeterminate progress, but only if we detect
    iTerm2. Silent no-op otherwise."""
    if is_iterm2():
        _write(stream, progress_indeterminate())


def emit_set(stream, percent: int) -> None:
    if is_iterm2():
        _write(stream, progress_set(percent))


def emit_error(stream, percent: int = 0) -> None:
    if is_iterm2():
        _write(stream, progress_error(percent))


def emit_clear(stream) -> None:
    if is_iterm2():
        _write(stream, progress_clear())


@contextlib.contextmanager
def with_progress(stream, *, percent: Optional[int] = None):
    """Round 170 / B3: context manager for a long-running
    operation.

      • On enter:
          - If iTerm2: emit indeterminate (or determinate when
            `percent` is provided).
          - Else: no-op.
      • On exit (normal):
          - If iTerm2: emit clear.
      • On exit (exception):
          - If iTerm2: emit error.

    Usage:
        with with_progress(sys.stdout):
            run_long_bash_command()

    The host can wrap any tool body with this without branching
    on terminal type. Non-iTerm2 terminals see nothing.
    """
    if not is_iterm2():
        yield
        return
    if percent is None:
        _write(stream, progress_indeterminate())
    else:
        _write(stream, progress_set(percent))
    try:
        yield
    except Exception:
        _write(stream, progress_error(0))
        raise
    else:
        _write(stream, progress_clear())
