"""Round 139: Focus View — hide all but the most recent turn.

Different from the round-24 `/focus` (which collapses tool
receipts). Focus View hides every prior message in the chat
log; only the most recent user prompt and assistant response
remain visible. Earlier messages are *hidden*, not deleted —
toggle off restores them.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any


@dataclass
class FocusViewState:
    enabled: bool = False


def focus_view_active() -> bool:
    return os.environ.get(
        "PROMETHEUS_FOCUS_VIEW", "",
    ).strip().lower() in ("1", "true", "yes")


def enable_focus_view(state: FocusViewState) -> FocusViewState:
    state.enabled = True
    os.environ["PROMETHEUS_FOCUS_VIEW"] = "1"
    return state


def disable_focus_view(state: FocusViewState) -> FocusViewState:
    state.enabled = False
    os.environ["PROMETHEUS_FOCUS_VIEW"] = "0"
    return state


def status_chip(state: FocusViewState) -> str:
    return "FOCUS" if state.enabled else ""


def visible_messages(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Round 139: when Focus View is on, return only the most
    recent user prompt + the assistant response that followed
    it. Tool messages and earlier turns are hidden.

    The system prompt (role=system) is always preserved so the
    model still sees it on the next turn. The hidden state is
    purely a *display* filter — the underlying message list is
    untouched."""
    if not messages:
        return list(messages)
    last_user_idx = -1
    for i in range(len(messages) - 1, -1, -1):
        if isinstance(messages[i], dict) and messages[i].get(
            "role"
        ) == "user":
            last_user_idx = i
            break
    if last_user_idx < 0:
        return list(messages)
    out: list[dict[str, Any]] = []
    if messages and messages[0].get("role") == "system":
        out.append(messages[0])
    out.extend(messages[last_user_idx:])
    return out


def hidden_count(messages: list[dict[str, Any]]) -> int:
    """Round 139: how many messages are being hidden right now."""
    if not messages:
        return 0
    visible = visible_messages(messages)
    return max(0, len(messages) - len(visible))
