"""Round 146-final-v3: enterprise lockdown settings.

8 settings keys + a `lockdown_summary()` accessor used by
the host's hook-loader, MCP loader, marketplace registry,
and permission-rule resolver to enforce admin policy.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


def _b(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes", "on")
    return default


def _list_field(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(s).strip() for s in value if str(s).strip()]


# ---------- accessors ----------


def disable_all_hooks(setting: Any = None) -> bool:
    """Round 146-final-v3: emergency kill-switch for every
    Sentinel hook."""
    return _b(setting)


def strict_plugin_only_customization(setting: Any = None) -> bool:
    """Round 146-final-v3: when on, skills + agents are loaded
    only from approved Forge Kits — user/project files are
    ignored."""
    return _b(setting)


def allow_managed_hooks_only(setting: Any = None) -> bool:
    return _b(setting)


def allow_managed_mcp_servers_only(setting: Any = None) -> bool:
    return _b(setting)


def allow_managed_permission_rules_only(setting: Any = None) -> bool:
    return _b(setting)


def blocked_marketplaces(setting: Any = None) -> list[str]:
    return _list_field(setting)


def strict_known_marketplaces(setting: Any = None) -> bool:
    return _b(setting)


def company_announcements(setting: Any = None) -> list[str]:
    """Round 146-final-v3: admin-supplied announcements
    surfaced in the welcome banner."""
    return _list_field(setting)


# ---------- summary ----------


@dataclass
class LockdownSummary:
    disable_all_hooks: bool
    strict_plugin_only_customization: bool
    allow_managed_hooks_only: bool
    allow_managed_mcp_servers_only: bool
    allow_managed_permission_rules_only: bool
    blocked_marketplaces: list[str]
    strict_known_marketplaces: bool
    company_announcements: list[str]


def lockdown_summary(settings: Any = None) -> LockdownSummary:
    s = settings if isinstance(settings, dict) else {}
    return LockdownSummary(
        disable_all_hooks=disable_all_hooks(s.get("disableAllHooks")),
        strict_plugin_only_customization=
            strict_plugin_only_customization(
                s.get("strictPluginOnlyCustomization"),
            ),
        allow_managed_hooks_only=allow_managed_hooks_only(
            s.get("allowManagedHooksOnly"),
        ),
        allow_managed_mcp_servers_only=allow_managed_mcp_servers_only(
            s.get("allowManagedMcpServersOnly"),
        ),
        allow_managed_permission_rules_only=
            allow_managed_permission_rules_only(
                s.get("allowManagedPermissionRulesOnly"),
            ),
        blocked_marketplaces=blocked_marketplaces(
            s.get("blockedMarketplaces"),
        ),
        strict_known_marketplaces=strict_known_marketplaces(
            s.get("strictKnownMarketplaces"),
        ),
        company_announcements=company_announcements(
            s.get("companyAnnouncements"),
        ),
    )


def render_lockdown(s: LockdownSummary) -> str:
    """Round 146-final-v3: surface the lockdown state to
    operators — used by `/doctor --enterprise` and `/audit`."""
    lines = ["enterprise lockdown:"]
    flags = (
        ("disableAllHooks", s.disable_all_hooks),
        ("strictPluginOnlyCustomization", s.strict_plugin_only_customization),
        ("allowManagedHooksOnly", s.allow_managed_hooks_only),
        ("allowManagedMcpServersOnly", s.allow_managed_mcp_servers_only),
        ("allowManagedPermissionRulesOnly", s.allow_managed_permission_rules_only),
        ("strictKnownMarketplaces", s.strict_known_marketplaces),
    )
    for name, on in flags:
        lines.append(f"  {'✓' if on else ' '} {name}")
    if s.blocked_marketplaces:
        lines.append(
            "  blockedMarketplaces: "
            + ", ".join(s.blocked_marketplaces)
        )
    if s.company_announcements:
        lines.append(
            f"  companyAnnouncements: "
            f"{len(s.company_announcements)} active"
        )
    return "\n".join(lines)
