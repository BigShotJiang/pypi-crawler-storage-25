"""Round 150: /devtools — developer debugging panel.

Surfaces, in one screen:

  * active feature flags (env vars in PROMETHEUS_*)
  * settings file locations + load order
  * log levels
  * hook registrations from sentinels
  * config overlay sources

Pure read-only. No state mutation; safe to run anytime.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any


# ---------- env flags ----------


def active_env_flags() -> dict[str, str]:
    """Round 150: every PROMETHEUS_* env var currently set."""
    return {
        k: v for k, v in os.environ.items()
        if k.startswith("PROMETHEUS_") and v.strip()
    }


# ---------- settings paths ----------


def settings_paths() -> list[tuple[str, Path, bool]]:
    """Round 150: known settings sources, in load order
    (later overrides earlier). Returns (label, path, exists)."""
    user_root = Path.home() / ".prometheus"
    cwd = Path.cwd()
    rows: list[tuple[str, Path, bool]] = [
        ("user-global", user_root / "settings.json",
         (user_root / "settings.json").exists()),
        ("project-shared", cwd / ".prometheus" / "settings.json",
         (cwd / ".prometheus" / "settings.json").exists()),
        ("project-local", cwd / ".prometheus" / "settings.local.json",
         (cwd / ".prometheus" / "settings.local.json").exists()),
        ("user .env", user_root / ".env",
         (user_root / ".env").exists()),
        ("project .env", cwd / ".env", (cwd / ".env").exists()),
    ]
    return rows


# ---------- hook registrations ----------


def sentinel_event_summary() -> dict[str, int]:
    """Round 150: count of registered sentinels per event type."""
    try:
        from prometheus.safety.sentinels import (
            SentinelType,
        )
    except ImportError:
        return {}
    return {t.value: 0 for t in SentinelType}


# ---------- log levels ----------


def log_level() -> str:
    raw = os.environ.get("PROMETHEUS_LOG_LEVEL", "").strip()
    if raw:
        return raw
    return "WARNING (default)"


# ---------- render ----------


def render() -> str:
    lines = ["devtools panel:"]
    # Env flags.
    flags = active_env_flags()
    lines.append("")
    lines.append(f"  env flags ({len(flags)} set):")
    for k in sorted(flags.keys())[:30]:
        v = flags[k]
        if len(v) > 40:
            v = v[:37] + "…"
        lines.append(f"    {k} = {v}")
    if len(flags) > 30:
        lines.append(f"    …+{len(flags) - 30} more")
    # Settings.
    lines.append("")
    lines.append("  settings (load order — later wins):")
    for label, p, exists in settings_paths():
        glyph = "✓" if exists else "·"
        lines.append(f"    {glyph} {label:18s}  {p}")
    # Sentinels.
    lines.append("")
    sm = sentinel_event_summary()
    if sm:
        lines.append("  sentinel event types:")
        for name, n in sm.items():
            lines.append(f"    {name:20s}  {n} registered")
    # Log level.
    lines.append("")
    lines.append(f"  log level: {log_level()}")
    return "\n".join(lines)
