"""Round 164 / #1 — Custom statusLine script hook.

Claude Code's `statusLine` setting points to a user-supplied shell
script (or executable). On every UI render, the script is invoked
with the current session state piped to stdin as JSON; its stdout
becomes the footer line. Script failures (non-zero exit, timeout,
missing executable, malformed JSON output) silently fall back to
the default status bar — the goal is to enrich the UI, not to
turn every script bug into a visible error.

Public API:
  • `build_payload(...)` — assembles the JSON payload (model name,
    context-window percentage, cwd, transcript path, rate-limit
    windows, session id).
  • `run_status_line(script_path, payload, *, timeout_ms=300)` —
    invokes the script. Returns `(stdout_str | None, error | None)`.
    `None` means "fall back to the default status bar."

The script is invoked once per UI refresh tick — at our 16 ms /
~62 fps default that's a lot of subprocess spawns, so the host's
caller is expected to debounce to a sensible cadence (the live
TUI uses 1 s).
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger("prometheus.tui_status_line")


# Hard cap so a slow status-line script can't freeze the UI.
DEFAULT_TIMEOUT_MS = 300

# Output cap. The status bar is a single terminal line; if a
# script tries to dump 100KB of output we truncate to keep the
# render contract.
MAX_OUTPUT_CHARS = 400


# ---- payload ----------------------------------------------------


@dataclass
class StatusLinePayload:
    """Round 164 / 170: structured per-render state passed to the
    script.

    Round 170 extends the schema to match Claude Code's documented
    full payload — `git_branch`, `context_window` (used / total /
    percentage), `background_task_count`, `cost`, and
    `thinking_duration_ms`.
    """
    # ---- core identity (round 164) ----
    model: str = ""
    context_pct: int = 0
    cwd: str = ""
    transcript_path: str = ""
    session_id: str = ""
    permission_mode: str = ""
    rate_limit_window: dict[str, Any] = field(default_factory=dict)
    """Per-provider remaining quota: {'groq': {'remaining': 14000,
    'reset_in_s': 3600, 'used_percentage': 35, 'resets_at': '...'},
    ...}"""
    elapsed_seconds: int = 0
    """Wall-clock since session started."""
    # ---- round 170 additions ----
    git_branch: str = ""
    """Current git branch (empty when cwd isn't in a repo)."""
    context_window: dict[str, Any] = field(default_factory=dict)
    """`{'used': N, 'total': N, 'percentage': pct}` — used by
    Claude HUD and other status-bar plugins."""
    background_task_count: int = 0
    """Active background subagent count — same number that drives
    the round-165 ⚡ N agents indicator."""
    cost: dict[str, Any] = field(default_factory=dict)
    """`{'cumulative_usd': float, 'last_request_usd': float}` —
    surfaced when the user has opted into cost telemetry."""
    thinking_duration_ms: int = 0
    """Round 170 / B2: how long the model has been generating its
    current response in ms; used by status-bar scripts to surface
    long-running thinks. 0 when no model call is in flight."""

    def to_json(self) -> str:
        return json.dumps({
            "model": self.model,
            "context_pct": int(self.context_pct),
            "cwd": self.cwd,
            "transcript_path": self.transcript_path,
            "session_id": self.session_id,
            "permission_mode": self.permission_mode,
            "rate_limit_window": dict(self.rate_limit_window),
            "elapsed_seconds": int(self.elapsed_seconds),
            # Round 170 additions:
            "git_branch": self.git_branch,
            "context_window": dict(self.context_window),
            "background_task_count": int(self.background_task_count),
            "cost": dict(self.cost),
            "thinking_duration_ms": int(self.thinking_duration_ms),
        })


def build_payload(
    *,
    model: str,
    context_pct: float | int = 0,
    cwd: str | Path = "",
    transcript_path: str | Path = "",
    session_id: str = "",
    permission_mode: str = "",
    rate_limit_window: Optional[dict[str, Any]] = None,
    elapsed_seconds: float | int = 0,
    # ---- round 170 additions (all keyword-only, all default
    # to neutral values so existing callers don't break) ----
    git_branch: str = "",
    context_window: Optional[dict[str, Any]] = None,
    background_task_count: int = 0,
    cost: Optional[dict[str, Any]] = None,
    thinking_duration_ms: float | int = 0,
) -> StatusLinePayload:
    return StatusLinePayload(
        model=str(model or ""),
        context_pct=int(round(float(context_pct or 0))),
        cwd=str(cwd or ""),
        transcript_path=str(transcript_path or ""),
        session_id=str(session_id or ""),
        permission_mode=str(permission_mode or ""),
        rate_limit_window=dict(rate_limit_window or {}),
        elapsed_seconds=int(round(float(elapsed_seconds or 0))),
        # round 170:
        git_branch=str(git_branch or ""),
        context_window=dict(context_window or {}),
        background_task_count=int(background_task_count or 0),
        cost=dict(cost or {}),
        thinking_duration_ms=int(round(float(thinking_duration_ms or 0))),
    )


def detect_git_branch(workdir: Path | str) -> str:
    """Round 170 / B1: current git branch for `workdir` (empty
    when the dir isn't in a repo or git isn't on PATH).

    Tries `rev-parse --abbrev-ref HEAD` first (the canonical
    answer), then falls back to `symbolic-ref --short HEAD`
    which works on a fresh repo with no commits yet (where
    rev-parse exits 128 with "ambiguous argument 'HEAD'").

    The host calls this once per debounced status-line tick. We
    avoid spawning `git` on every render — the bottom HUD's
    300ms debounce already throttles the call site.
    """
    import subprocess
    for argv in (
        ["git", "rev-parse", "--abbrev-ref", "HEAD"],
        ["git", "symbolic-ref", "--short", "HEAD"],
    ):
        try:
            proc = subprocess.run(
                argv, capture_output=True, text=True, timeout=2,
                cwd=str(workdir),
            )
            if proc.returncode == 0:
                branch = (proc.stdout or "").strip()
                if branch:
                    return branch
        except (OSError, subprocess.TimeoutExpired):
            continue
    return ""


def context_window_dict(
    *, used: int, total: int,
) -> dict[str, Any]:
    """Round 170 / B1: helper to produce the
    `{'used': ..., 'total': ..., 'percentage': ...}` shape every
    Claude Code status-bar plugin expects."""
    used = max(0, int(used or 0))
    total = max(1, int(total or 1))
    pct = int(round(100.0 * used / total))
    return {"used": used, "total": total, "percentage": pct}


def rate_limit_entry(
    *, used: int, limit: int,
    resets_at: Optional[str] = None,
) -> dict[str, Any]:
    """Round 170 / B1: per-provider rate-limit shape with the
    `used_percentage` + `resets_at` Claude Code documents.

    `resets_at` is an ISO-8601 string ("2026-05-08T17:30:00Z"),
    or None when the provider doesn't expose a reset time."""
    used = max(0, int(used or 0))
    limit = max(1, int(limit or 1))
    pct = min(100, int(round(100.0 * used / limit)))
    out: dict[str, Any] = {
        "used": used, "limit": limit, "used_percentage": pct,
        "remaining": max(0, limit - used),
    }
    if resets_at:
        out["resets_at"] = resets_at
    return out


# ---- runner ---------------------------------------------------


def _expand_script(script_path: str | Path) -> Optional[list[str]]:
    """Resolve `script_path` against $PATH + ~ expansion. Returns
    a subprocess argv list or None if the script can't be located.

    Supports either a single executable path OR a shell-style
    command line (split on whitespace via shlex)."""
    if not script_path:
        return None
    raw = str(script_path).strip()
    if not raw:
        return None
    raw = os.path.expanduser(raw)
    # If the path exists as-is, use it directly.
    p = Path(raw)
    if p.exists() and p.is_file():
        return [str(p)]
    # Otherwise try shlex-splitting the command line — this lets
    # users write `statusLine: ./bin/status.sh --compact`. We use
    # posix=True on every platform so quote chars are stripped from
    # tokens (Windows users still routinely quote paths-with-spaces;
    # the alternative would leave the literal `"..."` in the argv
    # and subprocess would fail with WinError 2).
    try:
        import shlex
        parts = shlex.split(raw, posix=True)
    except ValueError:
        return None
    if not parts:
        return None
    head = Path(parts[0])
    if head.is_absolute() and not head.exists():
        return None
    return parts


@dataclass
class StatusLineResult:
    """Outcome of one `run_status_line` call."""
    text: Optional[str]
    """The script's captured stdout, or None on any failure."""
    error: Optional[str]
    """Short error description when text is None; suitable for
    debug logging (never shown to the user)."""
    duration_ms: int


def run_status_line(
    script_path: str | Path,
    payload: StatusLinePayload,
    *,
    timeout_ms: int = DEFAULT_TIMEOUT_MS,
) -> StatusLineResult:
    """Invoke `script_path` with `payload` JSON on stdin.

    Returns a `StatusLineResult`. On any failure the `text` field
    is `None` and the host MUST silently fall back to the default
    status bar — never surface this error in the UI.
    """
    started = time.monotonic()
    argv = _expand_script(script_path)
    if argv is None:
        return StatusLineResult(
            text=None, error="script not found", duration_ms=0,
        )
    # Round 170 / B1: inject PYTHONIOENCODING=utf-8 on Windows so
    # user statusline scripts can emit Unicode (emoji, branch
    # glyphs, box-drawing chars) without the cp1252 stdout
    # encoder crashing them. Same fix as the round-160 Bash tool.
    _env = os.environ.copy()
    if sys.platform == "win32" and "PYTHONIOENCODING" not in _env:
        _env["PYTHONIOENCODING"] = "utf-8"
    try:
        proc = subprocess.run(
            argv,
            input=payload.to_json(),
            capture_output=True, text=True,
            encoding="utf-8", errors="replace",
            timeout=max(0.05, timeout_ms / 1000.0),
            cwd=os.getcwd(),
            env=_env,
        )
    except subprocess.TimeoutExpired:
        d = int((time.monotonic() - started) * 1000)
        return StatusLineResult(
            text=None, error=f"timeout after {timeout_ms}ms",
            duration_ms=d,
        )
    except FileNotFoundError as e:
        d = int((time.monotonic() - started) * 1000)
        return StatusLineResult(
            text=None, error=f"FileNotFoundError: {e}",
            duration_ms=d,
        )
    except OSError as e:
        d = int((time.monotonic() - started) * 1000)
        return StatusLineResult(
            text=None, error=f"OSError: {e}",
            duration_ms=d,
        )
    d = int((time.monotonic() - started) * 1000)
    if proc.returncode != 0:
        return StatusLineResult(
            text=None, error=f"exit {proc.returncode}",
            duration_ms=d,
        )
    out = (proc.stdout or "").rstrip("\r\n")
    # Cap to a single line — multi-line stdout would break the
    # bottom-bar render contract.
    if "\n" in out:
        out = out.split("\n", 1)[0]
    if len(out) > MAX_OUTPUT_CHARS:
        out = out[:MAX_OUTPUT_CHARS - 1] + "…"
    if not out:
        return StatusLineResult(
            text=None, error="empty stdout", duration_ms=d,
        )
    return StatusLineResult(text=out, error=None, duration_ms=d)


# ---- settings integration -------------------------------------


def resolve_status_line_script(setting: Any) -> Optional[str]:
    """Round 164: parse the `statusLine` settings.json key.

    Accepts:
      "statusLine": "/path/to/script.sh"
      "statusLine": "./bin/status.sh --compact"
      "statusLine": {"command": "/path/to/script", "timeout_ms": 200}
      (anything else)         → None (disabled)
    """
    if not setting:
        return None
    if isinstance(setting, str):
        return setting.strip() or None
    if isinstance(setting, dict):
        cmd = setting.get("command", "")
        return str(cmd).strip() or None
    return None


def resolve_status_line_timeout_ms(setting: Any) -> int:
    """Pull `timeout_ms` from the dict form, else default."""
    if isinstance(setting, dict):
        try:
            v = int(setting.get("timeout_ms", DEFAULT_TIMEOUT_MS))
            return max(50, min(2000, v))  # clamp 50-2000 ms
        except (TypeError, ValueError):
            pass
    return DEFAULT_TIMEOUT_MS
