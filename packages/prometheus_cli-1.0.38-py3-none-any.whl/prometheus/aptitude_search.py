"""Round 145-final: fuzzy search across installed aptitudes.

`/aptitude search <query>` ranks every installed aptitude by
relevance to the query. Search corpus per aptitude:

  * name (highest weight)
  * triggers (high weight)
  * purpose (medium)
  * body (low)

Pure data layer. The slash command consumes the ranked rows.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional


# ---------- ranking ----------


@dataclass
class SearchHit:
    name: str
    score: float
    purpose: str
    source: str
    matched_fields: list[str]


_TOKEN_RX = re.compile(r"[A-Za-z][A-Za-z0-9_-]+")


def _tokens(text: str) -> set[str]:
    return {
        m.group(0).lower() for m in _TOKEN_RX.finditer(text or "")
    }


def _score_field(
    needle: set[str], haystack: str, weight: float,
) -> tuple[float, bool]:
    if not haystack:
        return (0.0, False)
    hay = _tokens(haystack)
    if not hay:
        return (0.0, False)
    hits = needle & hay
    if not hits:
        # substring fallback for the full query.
        joined = " ".join(needle)
        if joined and joined in haystack.lower():
            return (weight * 0.4, True)
        return (0.0, False)
    coverage = len(hits) / len(needle)
    return (weight * coverage, True)


def search(
    query: str, *, aptitudes: list[Any],
    top_k: int = 10,
) -> list[SearchHit]:
    """Round 145-final: rank aptitudes by `query` relevance.
    `aptitudes` items must expose `.name`, `.purpose`,
    `.triggers`, `.body`, and `.source`."""
    q_tokens = _tokens(query)
    if not q_tokens:
        return []
    rows: list[SearchHit] = []
    for a in aptitudes:
        name = str(getattr(a, "name", "") or "")
        purpose = str(getattr(a, "purpose", "") or "")
        triggers = list(getattr(a, "triggers", []) or [])
        body = str(getattr(a, "body", "") or "")
        source = str(getattr(a, "source", "?") or "?")
        score = 0.0
        matched: list[str] = []
        # Name: weight 5.
        s, ok = _score_field(q_tokens, name, 5.0)
        score += s
        if ok:
            matched.append("name")
        # Triggers: weight 3, joined.
        s, ok = _score_field(
            q_tokens, " ".join(triggers), 3.0,
        )
        score += s
        if ok:
            matched.append("triggers")
        # Purpose: weight 2.
        s, ok = _score_field(q_tokens, purpose, 2.0)
        score += s
        if ok:
            matched.append("purpose")
        # Body: weight 1, capped to first 1k chars to keep
        # ranking deterministic.
        s, ok = _score_field(q_tokens, body[:1000], 1.0)
        score += s
        if ok:
            matched.append("body")
        # Exact-name boost.
        if name.lower() == " ".join(q_tokens):
            score *= 2.0
        if score > 0:
            rows.append(SearchHit(
                name=name,
                score=round(score, 3),
                purpose=purpose[:120],
                source=source,
                matched_fields=matched,
            ))
    rows.sort(key=lambda r: r.score, reverse=True)
    return rows[:top_k]


def render_search(query: str, hits: list[SearchHit]) -> str:
    if not hits:
        return f"no aptitudes match {query!r}"
    lines = [f"aptitudes matching {query!r}:"]
    for h in hits:
        fields = ",".join(h.matched_fields) or "—"
        lines.append(
            f"  {h.score:5.2f}  {h.name:24s}  [{h.source}]  "
            f"{fields:24s}  {h.purpose[:50]}"
        )
    return "\n".join(lines)


def parse_search_arg(arg: str) -> str:
    """Round 145-final: strip the `search` keyword if the
    user wrote `/aptitude search <query>`."""
    raw = (arg or "").strip()
    if raw.lower().startswith("search "):
        return raw[7:].strip()
    if raw.lower() == "search":
        return ""
    return raw
