"""Round 184: ASCII banner shown on first interactive launch.

Every commercial terminal AI agent reviewed shows brand identity
on first run. Claude Code's `*` constellation, Aider's `aider`
wordmark, Gemini CLI's gradient logo, Codex's banner — each
establishes "you are using X" in the first frame the user sees.

Pre-R184 Prometheus showed plain "PrometheUS" text; this module
adds a properly-rendered ASCII banner that is degraded gracefully
on terminals without color, on Windows legacy console, and when
NO_COLOR is set.

Public API:
  render_banner(width=None, color=None) — returns the banner as
    a single string ready to print. `width` clips to that column
    count; `color` overrides the auto-detection from
    prometheus.color.should_use_color().
"""
from __future__ import annotations

import sys

# Wide form (≥80 columns). Built from the unicode block characters
# █ ▀ ▄ — single-byte width per cell. Each line is exactly 60 cols
# wide so the right-edge alignment never breaks under reflow.
_BANNER_WIDE = r"""
 ██████╗ ██████╗  ██████╗ ███╗   ███╗███████╗████████╗██╗  ██╗
 ██╔══██╗██╔══██╗██╔═══██╗████╗ ████║██╔════╝╚══██╔══╝██║  ██║
 ██████╔╝██████╔╝██║   ██║██╔████╔██║█████╗     ██║   ███████║
 ██╔═══╝ ██╔══██╗██║   ██║██║╚██╔╝██║██╔══╝     ██║   ██╔══██║
 ██║     ██║  ██║╚██████╔╝██║ ╚═╝ ██║███████╗   ██║   ██║  ██║
 ╚═╝     ╚═╝  ╚═╝ ╚═════╝ ╚═╝     ╚═╝╚══════╝   ╚═╝   ╚═╝  ╚═╝
""".lstrip("\n").rstrip()


# Narrow form (<80 columns) — single-line wordmark with a flame
# emoji that gracefully falls through to ASCII when the terminal
# can't render it.
_BANNER_NARROW = "  PrometheUS"
_BANNER_NARROW_TAGLINE = "  free terminal AI coding agent"


# Colors — the file uses raw escape codes so we don't pull in a
# heavy dependency. Amber / orange = the brand accent.
_AMBER = "\x1b[38;5;208m"
_DIM = "\x1b[2m"
_RESET = "\x1b[0m"


def render_banner(width: int | None = None, color: bool | None = None) -> str:
    """Return the welcome banner ready to print.

    `width`  — terminal width in columns. If None, auto-detect via
               shutil.get_terminal_size().
    `color`  — force color on/off. If None, ask
               prometheus.color.should_use_color().

    Output never ends with a newline so callers control vertical
    spacing."""
    if width is None:
        try:
            import shutil
            width = shutil.get_terminal_size((80, 24)).columns
        except Exception:
            width = 80
    if color is None:
        try:
            from prometheus.color import should_use_color
            color = should_use_color()
        except Exception:
            color = False

    # Pick wide vs narrow based on the longest banner line plus
    # a comfortable margin.
    longest = max(len(line) for line in _BANNER_WIDE.splitlines())
    use_wide = width >= longest + 2

    if use_wide:
        body = _BANNER_WIDE
        tagline = "  free terminal AI coding agent · github.com/PrometheUS"
    else:
        body = _BANNER_NARROW
        tagline = _BANNER_NARROW_TAGLINE

    if color:
        body = f"{_AMBER}{body}{_RESET}"
        tagline = f"{_DIM}{tagline}{_RESET}"

    return f"{body}\n{tagline}"


def render_compact_marker() -> str:
    """One-line marker shown at session restart — for `/resume` and
    crash-recovery banners. Far shorter than the welcome banner so
    it doesn't bloat the scrollback on every restart."""
    try:
        from prometheus.color import should_use_color
        on = should_use_color()
    except Exception:
        on = False
    if on:
        return f"{_AMBER}●{_RESET} PrometheUS"
    return "● PrometheUS"
