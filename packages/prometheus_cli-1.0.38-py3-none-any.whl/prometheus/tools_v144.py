"""Round 144-v2: torch mode, templates, session backfill,
perf snapshot, commit attribution, away summary, file
persistence.

Pure data layers + state machines. The slash commands and
agent loop consume them.
"""
from __future__ import annotations

import json
import os
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


_TRUTHY = ("1", "true", "yes", "on")


def _flag(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in _TRUTHY


# ---------- /torch ----------


@dataclass
class TorchMode:
    """Round 144-v2: aggressive context burn for speed."""
    enabled: bool = False


def torch_mode_active() -> bool:
    return os.environ.get(
        "PROMETHEUS_TORCH_MODE", "",
    ).strip().lower() in _TRUTHY


def enable_torch(state: TorchMode) -> TorchMode:
    state.enabled = True
    os.environ["PROMETHEUS_TORCH_MODE"] = "1"
    # Round 144-v2: torch overrides — drop autocompact threshold
    # to ~50% so context gets snipped sooner.
    os.environ["PROMETHEUS_AUTOCOMPACT_PCT"] = "50"
    return state


def disable_torch(state: TorchMode) -> TorchMode:
    state.enabled = False
    os.environ["PROMETHEUS_TORCH_MODE"] = "0"
    os.environ.pop("PROMETHEUS_AUTOCOMPACT_PCT", None)
    return state


def torch_status_chip(state: TorchMode) -> str:
    return "TORCH" if state.enabled else ""


# ---------- /templates ----------


@dataclass
class Template:
    name: str
    description: str
    body: str
    path: Path


def templates_dir(workdir: Path) -> Path:
    return workdir / ".prometheus" / "templates"


def discover_templates(workdir: Path) -> list[Template]:
    """Round 144-v2: load every .md file in
    `<workdir>/.prometheus/templates/` plus
    `~/.prometheus/templates/`."""
    rows: list[Template] = []
    for base in (
        templates_dir(workdir),
        Path.home() / ".prometheus" / "templates",
    ):
        if not base.exists():
            continue
        for p in sorted(base.glob("*.md")):
            try:
                body = p.read_text(encoding="utf-8")
            except OSError:
                continue
            # First non-blank line = description.
            lines = [
                line for line in body.splitlines()
                if line.strip()
            ]
            desc = lines[0].lstrip("# ").strip() if lines else ""
            rows.append(Template(
                name=p.stem,
                description=desc[:200],
                body=body,
                path=p,
            ))
    # Dedupe: workdir wins over user.
    seen: dict[str, Template] = {}
    for t in rows:
        if t.name not in seen:
            seen[t.name] = t
    return list(seen.values())


def find_template(workdir: Path, name: str) -> Optional[Template]:
    for t in discover_templates(workdir):
        if t.name == name:
            return t
    return None


def render_template_list(rows: list[Template]) -> str:
    if not rows:
        return (
            "no templates found.\n"
            "  drop .md files in .prometheus/templates/ or "
            "~/.prometheus/templates/."
        )
    lines = ["templates:"]
    for t in rows:
        lines.append(
            f"  {t.name:24s}  {t.description[:60]}"
        )
    lines.append("")
    lines.append("(use `/templates <name>` to load)")
    return "\n".join(lines)


# ---------- /backfill-sessions ----------


@dataclass
class BackfillStats:
    scanned: int = 0
    indexed: int = 0
    errors: int = 0


def backfill_session_index(
    *,
    transcripts_dir: Optional[Path] = None,
    index_path: Optional[Path] = None,
) -> BackfillStats:
    """Round 144-v2: rebuild the session index from raw
    transcript files. The index is a JSON map keyed by
    session id, with started_at + label + path."""
    stats = BackfillStats()
    base = transcripts_dir or (
        Path.home() / ".prometheus" / "transcripts"
    )
    target = index_path or (
        Path.home() / ".prometheus" / "session-index.json"
    )
    if not base.exists():
        return stats
    new_index: dict[str, dict[str, Any]] = {}
    for p in base.glob("*.jsonl"):
        stats.scanned += 1
        try:
            first_line = ""
            with p.open("r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    if line.strip():
                        first_line = line
                        break
            if not first_line:
                continue
            try:
                d = json.loads(first_line)
            except json.JSONDecodeError:
                stats.errors += 1
                continue
            sid = str(d.get("session_id") or p.stem)
            new_index[sid] = {
                "session_id": sid,
                "path": str(p),
                "label": str(d.get("label", "")),
                "started_at": int(d.get("started_at", 0) or 0),
                "indexed_at": int(time.time()),
            }
            stats.indexed += 1
        except OSError:
            stats.errors += 1
            continue
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(new_index, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return stats


def render_backfill(stats: BackfillStats) -> str:
    return (
        f"backfill complete\n"
        f"  scanned: {stats.scanned} transcript file(s)\n"
        f"  indexed: {stats.indexed} session(s)\n"
        f"  errors:  {stats.errors}"
    )


# ---------- /perf-issue ----------


@dataclass
class PerfSnapshot:
    timestamp: int
    frame_count: int
    avg_frame_ms: float
    p95_frame_ms: float
    rss_mb: float
    slow_tools: list[tuple[str, float]] = field(default_factory=list)


def collect_perf_snapshot(
    *,
    frame_log_path: Optional[Path] = None,
    tool_durations: Optional[dict[str, list[float]]] = None,
) -> PerfSnapshot:
    """Round 144-v2: read the frame-timing log (if set), pull
    process RSS, and surface the slowest tools."""
    timestamps: list[float] = []
    if frame_log_path is None:
        from prometheus.env_flags_v142 import frame_timing_log_path
        frame_log_path = frame_timing_log_path()
    if frame_log_path and frame_log_path.exists():
        try:
            for line in frame_log_path.read_text(
                encoding="utf-8", errors="replace",
            ).splitlines():
                parts = line.split("\t")
                if len(parts) >= 2:
                    try:
                        timestamps.append(float(parts[1]))
                    except ValueError:
                        continue
        except OSError:
            pass
    timestamps.sort()
    n = len(timestamps)
    avg = sum(timestamps) / n if n else 0.0
    p95 = (
        timestamps[int(0.95 * (n - 1))] if n
        else 0.0
    )
    # RSS via psutil if available; otherwise resource on
    # POSIX; otherwise 0 with a clear flag.
    rss_mb = 0.0
    try:
        import psutil  # type: ignore[import-not-found]
        rss_mb = psutil.Process().memory_info().rss / (1024 * 1024)
    except ImportError:
        try:
            import resource  # POSIX
            rss_kb = resource.getrusage(
                resource.RUSAGE_SELF,
            ).ru_maxrss
            # macOS reports bytes, Linux reports KB. Detect by
            # magnitude — if it's > 1e9 it's bytes.
            if rss_kb > 1_000_000_000:
                rss_mb = rss_kb / (1024 * 1024)
            else:
                rss_mb = rss_kb / 1024
        except (ImportError, AttributeError):
            rss_mb = 0.0
    slow: list[tuple[str, float]] = []
    if tool_durations:
        for name, vals in tool_durations.items():
            if not vals:
                continue
            slow.append((name, sum(vals) / len(vals)))
        slow.sort(key=lambda kv: kv[1], reverse=True)
    return PerfSnapshot(
        timestamp=int(time.time()),
        frame_count=n,
        avg_frame_ms=round(avg, 3),
        p95_frame_ms=round(p95, 3),
        rss_mb=round(rss_mb, 1),
        slow_tools=slow[:10],
    )


def render_perf_snapshot(snap: PerfSnapshot) -> str:
    lines = [
        "perf snapshot:",
        f"  frames:    {snap.frame_count}",
        f"  avg ms:    {snap.avg_frame_ms}",
        f"  p95 ms:    {snap.p95_frame_ms}",
        f"  RSS MB:    {snap.rss_mb}",
    ]
    if snap.slow_tools:
        lines.append("  slow tools (avg ms):")
        for name, avg in snap.slow_tools:
            lines.append(f"    {name:24s}  {avg:.1f}")
    return "\n".join(lines)


# ---------- attribution ----------


def commit_attribution_enabled() -> bool:
    return _flag("PROMETHEUS_COMMIT_ATTRIBUTION")


COMMIT_TRAILER = "Co-Authored-By: Prometheus <prometheus@ai>"


def append_commit_trailer(message: str) -> str:
    """Round 144-v2: append the attribution trailer to a
    commit message when the env flag is set. Idempotent — if
    the trailer is already present, returns unchanged."""
    if not commit_attribution_enabled():
        return message
    if COMMIT_TRAILER in (message or ""):
        return message
    if not message:
        return COMMIT_TRAILER
    sep = "\n\n" if not message.endswith("\n\n") else ""
    return message.rstrip() + sep + "\n" + COMMIT_TRAILER + "\n"


# ---------- away summary ----------


def away_summary_enabled() -> bool:
    return _flag("PROMETHEUS_AWAY_SUMMARY")


@dataclass
class IdleTracker:
    """Round 144-v2: tracks user idle time. Crosses 30s →
    triggers an away-summary recap."""
    last_input_at: float = 0.0
    threshold_s: float = 30.0
    summary_emitted: bool = False

    def mark_input(self, *, now: Optional[float] = None) -> None:
        self.last_input_at = (
            now if now is not None else time.monotonic()
        )
        self.summary_emitted = False

    def should_emit_summary(
        self, *, now: Optional[float] = None,
    ) -> bool:
        if not away_summary_enabled():
            return False
        if self.summary_emitted:
            return False
        t = now if now is not None else time.monotonic()
        if self.last_input_at <= 0:
            return False
        return (t - self.last_input_at) >= self.threshold_s

    def mark_emitted(self) -> None:
        self.summary_emitted = True


# ---------- file persistence ----------


def file_persistence_enabled() -> bool:
    return _flag("PROMETHEUS_FILE_PERSISTENCE")


@dataclass
class TouchedFiles:
    """Round 144-v2: tracks every file the agent has touched
    across the session so the system prompt can re-include
    them on each turn for continuity."""
    files: list[str] = field(default_factory=list)
    seen: set[str] = field(default_factory=set)

    def record(self, path: str) -> None:
        if not file_persistence_enabled() or not path:
            return
        if path not in self.seen:
            self.seen.add(path)
            self.files.append(path)

    def recent(self, n: int = 10) -> list[str]:
        return self.files[-n:]
