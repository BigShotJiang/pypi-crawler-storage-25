"""Round 146-final-v3 + 147 + 148: consolidated env vars.

Round 146 — Remote / Bridge:
  PROMETHEUS_CCR_REMOTE_SETUP
  PROMETHEUS_SSH_REMOTE
  PROMETHEUS_DIRECT_CONNECT
  PROMETHEUS_LODESTONE
  PROMETHEUS_BYOC_ENVIRONMENT_RUNNER
  PROMETHEUS_SELF_HOSTED_RUNNER

Round 146 — Debug + testing:
  PROMETHEUS_HARD_FAIL
  PROMETHEUS_DUMP_SYSTEM_PROMPT
  PROMETHEUS_OVERFLOW_TEST_TOOL
  PROMETHEUS_ABLATION_BASELINE

Round 146 — Settings sync:
  PROMETHEUS_DOWNLOAD_USER_SETTINGS
  PROMETHEUS_UPLOAD_USER_SETTINGS
  PROMETHEUS_MEMORY_SHAPE_TELEMETRY
  PROMETHEUS_COWORKER_TYPE_TELEMETRY

Round 147 — feature gates:
  PROMETHEUS_WEB_BROWSER
  PROMETHEUS_MCP_SKILLS

Round 148 — sandbox + OTEL:
  PROMETHEUS_SANDBOX
  PROMETHEUS_OTEL_EXPORTER_OTLP_HEADERS
  PROMETHEUS_OTEL_HEADERS_HELPER_DEBOUNCE_MS
  PROMETHEUS_OTEL_SHUTDOWN_TIMEOUT_MS
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional


_TRUTHY = ("1", "true", "yes", "on")


def _flag(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name, "").strip().lower()
    if not raw:
        return default
    return raw in _TRUTHY


def _int_env(name: str, default: int) -> int:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        return max(0, int(raw))
    except ValueError:
        return default


# ---------- Round 146: remote / bridge ----------


def ccr_remote_setup() -> bool:
    return _flag("PROMETHEUS_CCR_REMOTE_SETUP")


def ssh_remote() -> bool:
    return _flag("PROMETHEUS_SSH_REMOTE")


def direct_connect() -> bool:
    return _flag("PROMETHEUS_DIRECT_CONNECT")


def lodestone() -> bool:
    """Round 146-final-v3: prometheus:// protocol handler
    registration."""
    return _flag("PROMETHEUS_LODESTONE")


def byoc_environment_runner() -> bool:
    return _flag("PROMETHEUS_BYOC_ENVIRONMENT_RUNNER")


def self_hosted_runner() -> bool:
    return _flag("PROMETHEUS_SELF_HOSTED_RUNNER")


# ---------- Round 146: debug / testing ----------


def hard_fail() -> bool:
    """Round 146-final-v3: crash on any error — debugging
    only."""
    return _flag("PROMETHEUS_HARD_FAIL")


def dump_system_prompt_only() -> bool:
    """Round 146-final-v3: print system prompt and exit. The
    cli reads this on launch."""
    return _flag("PROMETHEUS_DUMP_SYSTEM_PROMPT")


def overflow_test_tool_enabled() -> bool:
    return _flag("PROMETHEUS_OVERFLOW_TEST_TOOL")


def ablation_baseline() -> bool:
    return _flag("PROMETHEUS_ABLATION_BASELINE")


# ---------- Round 146: settings sync ----------


def download_user_settings() -> bool:
    return _flag("PROMETHEUS_DOWNLOAD_USER_SETTINGS")


def upload_user_settings() -> bool:
    return _flag("PROMETHEUS_UPLOAD_USER_SETTINGS")


def memory_shape_telemetry() -> bool:
    return _flag("PROMETHEUS_MEMORY_SHAPE_TELEMETRY")


def coworker_type_telemetry() -> bool:
    return _flag("PROMETHEUS_COWORKER_TYPE_TELEMETRY")


# ---------- Round 147 ----------


def web_browser_enabled() -> bool:
    return _flag("PROMETHEUS_WEB_BROWSER")


def mcp_skills_enabled() -> bool:
    return _flag("PROMETHEUS_MCP_SKILLS")


# ---------- Round 148: sandbox + OTEL ----------


def sandbox_enabled() -> bool:
    return _flag("PROMETHEUS_SANDBOX")


def otel_exporter_headers() -> Optional[str]:
    """Round 148-final-v3: raw header string passed to the
    OTLP exporter. None when unset."""
    val = os.environ.get(
        "PROMETHEUS_OTEL_EXPORTER_OTLP_HEADERS", "",
    ).strip()
    return val or None


def otel_headers_helper_debounce_ms() -> int:
    return _int_env(
        "PROMETHEUS_OTEL_HEADERS_HELPER_DEBOUNCE_MS", 1000,
    )


def otel_shutdown_timeout_ms() -> int:
    return _int_env(
        "PROMETHEUS_OTEL_SHUTDOWN_TIMEOUT_MS", 5000,
    )


# ---------- summary ----------


@dataclass
class V148Summary:
    ccr_remote_setup: bool
    ssh_remote: bool
    direct_connect: bool
    lodestone: bool
    byoc_environment_runner: bool
    self_hosted_runner: bool
    hard_fail: bool
    dump_system_prompt_only: bool
    overflow_test_tool_enabled: bool
    ablation_baseline: bool
    download_user_settings: bool
    upload_user_settings: bool
    memory_shape_telemetry: bool
    coworker_type_telemetry: bool
    web_browser_enabled: bool
    mcp_skills_enabled: bool
    sandbox_enabled: bool
    otel_exporter_headers: Optional[str]
    otel_headers_helper_debounce_ms: int
    otel_shutdown_timeout_ms: int


def env_flag_summary_v148() -> V148Summary:
    return V148Summary(
        ccr_remote_setup=ccr_remote_setup(),
        ssh_remote=ssh_remote(),
        direct_connect=direct_connect(),
        lodestone=lodestone(),
        byoc_environment_runner=byoc_environment_runner(),
        self_hosted_runner=self_hosted_runner(),
        hard_fail=hard_fail(),
        dump_system_prompt_only=dump_system_prompt_only(),
        overflow_test_tool_enabled=overflow_test_tool_enabled(),
        ablation_baseline=ablation_baseline(),
        download_user_settings=download_user_settings(),
        upload_user_settings=upload_user_settings(),
        memory_shape_telemetry=memory_shape_telemetry(),
        coworker_type_telemetry=coworker_type_telemetry(),
        web_browser_enabled=web_browser_enabled(),
        mcp_skills_enabled=mcp_skills_enabled(),
        sandbox_enabled=sandbox_enabled(),
        otel_exporter_headers=otel_exporter_headers(),
        otel_headers_helper_debounce_ms=
            otel_headers_helper_debounce_ms(),
        otel_shutdown_timeout_ms=otel_shutdown_timeout_ms(),
    )
