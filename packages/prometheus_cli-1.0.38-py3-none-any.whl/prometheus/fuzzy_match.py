"""Round 164 / #3 — Fuzzy file-name matching for Ctrl+Shift+F.

Claude Code's `QUICK_SEARCH` flag enables global file search with
fuzzy matching — typing "loop" surfaces `loop.py`, `loop_test.py`,
and `event_loop.py` ranked by match quality, not alphabetical.

Public API:
  • `score(query, candidate)` → 0..1 float (1.0 = perfect match)
  • `rank(query, candidates, limit=N)` → list of (path, score)
    sorted by score desc, then by length asc (stable tie-break).

Implementation: stdlib `difflib.SequenceMatcher` + a few heuristic
boosts for the file-search use case:
  • case-insensitive match
  • exact-substring bonus
  • basename-of-path bonus (so `loop` ranks `agent/loop.py` higher
    than `loop_helper.py` IF the substring lands in the basename)
  • shorter-candidate bonus (tie-breaker; matches the intuition
    that `loop.py` should out-rank `loop_some_huge_thing.py`)

No third-party dependency. The optional `rapidfuzz` library would
be 5-10× faster on big project trees, but the stdlib version is
fast enough for ~10K files (a typical Python repo) on the
keystroke-by-keystroke cadence the live TUI uses.
"""
from __future__ import annotations

import difflib
import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class FuzzyMatch:
    path: str
    score: float
    """0.0 .. 1.0; 1.0 is a perfect substring of the basename."""


def _basename(path: str) -> str:
    return os.path.basename(path) or path


def score(query: str, candidate: str) -> float:
    """Return a fuzzy-match score in 0..1 for `candidate` against
    `query`. Symmetrical case (case-insensitive) and biased toward
    matches that land in the file's basename rather than its
    directory prefix."""
    if not query: return 0.0
    if not candidate: return 0.0
    q = query.lower()
    full = candidate.replace("\\", "/").lower()
    base = _basename(full)

    # 1. Exact basename — top score.
    if base == q:
        return 1.0

    # 2. Substring of basename — strong bonus.
    if q in base:
        # Closer to a substring-of-the-stem (e.g. "loop" in "loop.py")
        # ranks higher than a substring buried in a longer name
        # ("loop" in "tools_loop_helper.py").
        # Use difflib for the granular score, then boost.
        ratio = difflib.SequenceMatcher(None, q, base).ratio()
        return min(1.0, 0.75 + 0.25 * ratio)

    # 3. Substring of full path (matches in the directory part).
    if q in full:
        ratio = difflib.SequenceMatcher(None, q, full).ratio()
        return min(0.85, 0.55 + 0.30 * ratio)

    # 4. Subsequence match in basename — `lop` matches `loop.py`.
    # Use SequenceMatcher's quick_ratio + ratio combo. Lower
    # ceiling since this is a softer match.
    ratio = difflib.SequenceMatcher(None, q, base).ratio()
    if ratio >= 0.5:
        return min(0.70, ratio)

    # 5. Subsequence in full path. Even weaker.
    ratio = difflib.SequenceMatcher(None, q, full).ratio()
    if ratio >= 0.4:
        return min(0.50, ratio)

    return 0.0


def rank(
    query: str,
    candidates: list[str],
    *,
    limit: int = 50,
    min_score: float = 0.30,
) -> list[FuzzyMatch]:
    """Score every candidate and return the top `limit`. Filters
    out anything below `min_score` so the popup doesn't drown in
    near-zero-relevance matches.

    Stable tie-break: shorter candidates first (intuition: when
    two paths score equally, the user almost always wants the
    one with the shorter basename).
    """
    if not query: return []
    matches: list[FuzzyMatch] = []
    for c in candidates:
        if not c: continue
        s = score(query, c)
        if s >= min_score:
            matches.append(FuzzyMatch(path=c, score=s))
    # Sort by score desc, then by basename length asc, then by
    # full-path length asc.
    matches.sort(
        key=lambda m: (-m.score, len(_basename(m.path)), len(m.path))
    )
    return matches[:limit]


# ---- file-tree convenience -----------------------------------


def gather_candidates(
    workdir: Path | str, *,
    extensions: tuple[str, ...] = (
        ".py", ".ts", ".tsx", ".js", ".jsx", ".md", ".rs",
        ".go", ".rb", ".java", ".cs", ".sql", ".yaml", ".yml",
        ".json", ".toml", ".cfg", ".ini",
    ),
    skip_dirs: tuple[str, ...] = (
        "__pycache__", "node_modules", ".git", ".pytest_cache",
        ".mypy_cache", ".ruff_cache", "dist", "build", ".venv",
        "venv", ".tox",
    ),
    limit: int = 20_000,
) -> list[str]:
    """Walk `workdir` and collect candidate file paths. Filtered
    by `extensions` and skips `skip_dirs`. Capped at `limit` so
    a misconfigured search root doesn't OOM the process."""
    root = Path(workdir)
    out: list[str] = []
    skip = set(skip_dirs)
    for dirpath, dirnames, filenames in os.walk(root):
        # In-place filter so os.walk doesn't descend into skipped dirs.
        dirnames[:] = [d for d in dirnames if d not in skip and not d.startswith(".")]
        for fn in filenames:
            if extensions and not fn.lower().endswith(extensions):
                continue
            try:
                rel = str(Path(dirpath, fn).relative_to(root))
            except ValueError:
                rel = os.path.join(dirpath, fn)
            out.append(rel.replace("\\", "/"))
            if len(out) >= limit:
                return out
    return out
