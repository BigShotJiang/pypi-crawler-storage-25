"""Round 144: `/selftest` — programmatic verification harness.

25 steps that exercise every major subsystem PrometheUS ships.
Each step is **pure** (no network, no spawned processes,
deterministic) so the harness runs the same way every time.

Honest scope:
  This is not a UI driver. It cannot type into the Textual
  Input box or watch the screen render. It exercises the
  *contracts* every UI surface depends on: state machines,
  data layers, env-flag accessors, registry lookups. If a UI
  surface fails despite a green selftest, the bug is in the
  Textual binding, not in the underlying contract — fix the
  binding, not the contract.

The slash command renders the report inline. The pytest test
file runs the same harness in CI so regressions can't slip in.
"""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Optional


# ---------- step record ----------


@dataclass
class StepResult:
    name: str
    ok: bool
    detail: str = ""
    duration_ms: float = 0.0


@dataclass
class SelftestReport:
    results: list[StepResult]

    @property
    def passed(self) -> int:
        return sum(1 for r in self.results if r.ok)

    @property
    def failed(self) -> int:
        return sum(1 for r in self.results if not r.ok)

    @property
    def total(self) -> int:
        return len(self.results)

    @property
    def ok(self) -> bool:
        return self.failed == 0

    def failed_rows(self) -> list[StepResult]:
        return [r for r in self.results if not r.ok]


# ---------- step helper ----------


def _step(name: str, body: Callable[[], None]) -> StepResult:
    start = time.monotonic()
    try:
        body()
        ok, detail = (True, "ok")
    except AssertionError as e:
        ok, detail = (False, str(e) or "assertion failed")
    except Exception as e:
        ok, detail = (False, f"{type(e).__name__}: {e}")
    elapsed_ms = (time.monotonic() - start) * 1000.0
    return StepResult(
        name=name, ok=ok, detail=detail, duration_ms=elapsed_ms,
    )


# ---------- the 25 steps ----------


def run_selftest(
    *, workdir: Optional[Path] = None,
) -> SelftestReport:
    """Round 144: execute the harness. Caller passes a workdir
    so the steps that depend on a project root (charter,
    aptitudes, forge kits, rules) can read from a real
    location."""
    workdir = workdir or Path.cwd()
    results: list[StepResult] = []

    # --- 1. Charter loading ----
    def step_01() -> None:
        from prometheus.agent.system import build_system_prompt
        from prometheus.tools.registry import build_default_registry
        tools = build_default_registry()
        prompt = build_system_prompt(
            workdir, tools,
            permission_mode="default",
            output_style="default",
            user_prompt="",
        )
        assert isinstance(prompt, str) and len(prompt) > 100
    results.append(_step("01 charter load + system prompt", step_01))

    # --- 2. Aptitude discovery + bundled skills ----
    def step_02() -> None:
        from prometheus.agent.aptitudes import discover_aptitudes
        rows = discover_aptitudes(workdir) or []
        names = {a.name for a in rows}
        for required in (
            "security-review", "simplify", "batch", "debug",
            "ghost", "ultraplan", "ultrareview",
        ):
            assert required in names, f"missing aptitude: {required}"
    results.append(_step("02 aptitude discovery", step_02))

    # --- 3. Sentinel engine ----
    def step_03() -> None:
        from prometheus.safety.sentinels import (
            BLOCKING_EVENTS, SentinelEvent, SentinelType,
        )
        # The 28-event catalogue is enumerated as `SentinelEvent`
        # values; round-99 BLOCKING_EVENTS is the immutable
        # subset the runtime treats as halting.
        assert len(list(SentinelEvent)) >= 28
        assert len(list(SentinelType)) >= 5
        assert isinstance(BLOCKING_EVENTS, frozenset)
    results.append(_step("03 sentinel engine event catalogue", step_03))

    # --- 4. Forge kit manifest module present ----
    def step_04() -> None:
        from prometheus.forge.registry import ForgeRegistry  # noqa: F401
    results.append(_step("04 forge registry import", step_04))

    # --- 5. Cohort definition module ----
    def step_05() -> None:
        from prometheus.agent.cohorts import (
            Cohort, discover_cohorts,
        )
        # Discover with a real workdir; an empty one returns [].
        rows = discover_cohorts(workdir)
        assert isinstance(rows, list)
    results.append(_step("05 cohort discovery", step_05))

    # --- 6. Overseer 3-tier ledger ----
    def step_06() -> None:
        from prometheus.safety.overseer import Overseer
        ov = Overseer()
        # Smoke that the deny ledger surfaces denied actions.
        assert hasattr(ov, "recently_denied")
        assert hasattr(ov, "breaker")
    results.append(_step("06 overseer 3-tier + circuit breaker", step_06))

    # --- 7. Memory vault ----
    def step_07() -> None:
        from prometheus.agent.memory_vault import (
            Memory, save_memory, discover_memories,
            VALID_TYPES,
        )
        # The vault's surface is functional rather than
        # class-based — round 102 ships free functions.
        assert "user" in VALID_TYPES
        assert "feedback" in VALID_TYPES
        assert callable(save_memory)
        assert callable(discover_memories)
    results.append(_step("07 memory vault load", step_07))

    # --- 8. Anchor save + restore module ----
    def step_08() -> None:
        from prometheus.agent.anchors import (
            Anchor, AnchorRegistry,
        )
        # AnchorRegistry takes a workdir at construction.
        reg = AnchorRegistry(workdir=workdir)
        assert reg is not None
        assert Anchor is not None
    results.append(_step("08 anchor save / restore", step_08))

    # --- 9. Vim mode state machine ----
    def step_09() -> None:
        from prometheus.ui.vim_mode import VimState, make_vim_input_class
        s = VimState()
        # State machine has the round-106 verbs.
        assert hasattr(s, "mode")
        # `make_vim_input_class()` is a zero-arg factory in
        # the current build; in older builds it took a base
        # class. Both shapes are valid contracts here.
        cls = make_vim_input_class()
        assert cls is not None
    results.append(_step("09 vim mode state machine", step_09))

    # --- 10. Output styles ----
    def step_10() -> None:
        from prometheus.agent.system import OUTPUT_STYLES
        for name in ("default", "explanatory", "learning",
                     "focus", "brief"):
            assert name in OUTPUT_STYLES, f"missing style: {name}"
    results.append(_step("10 output styles inventory", step_10))

    # --- 11. Bypass mode ----
    def step_11() -> None:
        from prometheus.bypass_mode import (
            bypass_active, set_bypass_active,
        )
        prior = bypass_active()
        try:
            set_bypass_active(True)
            assert bypass_active() is True
            set_bypass_active(False)
            assert bypass_active() is False
        finally:
            set_bypass_active(prior)
    results.append(_step("11 bypass mode toggle", step_11))

    # --- 12. Model tier switching ----
    def step_12() -> None:
        from prometheus.model_tiers import (
            resolve_alias, list_aliases, AUTO_FREE_ROUTE,
        )
        assert resolve_alias("auto") == AUTO_FREE_ROUTE
        assert "/" in resolve_alias("haiku")
        rows = list_aliases()
        names = [n for n, _ in rows]
        for tier in ("haiku", "sonnet", "opus", "best", "auto/free"):
            assert tier in names
    results.append(_step("12 model tier switching", step_12))

    # --- 13. Bash mode (!) prefix ----
    def step_13() -> None:
        from prometheus.agent.input_prefix import (
            is_bash_prefix, strip_bash_prefix,
        )
        assert is_bash_prefix("! git status") is True
        assert is_bash_prefix("hello") is False
        assert strip_bash_prefix("! git status") == "git status"
    results.append(_step("13 bash mode (!) prefix", step_13))

    # --- 14. File mention (@) ----
    def step_14() -> None:
        from prometheus.agent.input_prefix import (
            has_file_mention, extract_file_mentions,
        )
        assert has_file_mention("@README.md summarize") is True
        mentions = extract_file_mentions(
            "@README.md please", workdir=workdir,
        )
        assert isinstance(mentions, list)
    results.append(_step("14 file mention (@) extraction", step_14))

    # --- 15. Background session management ----
    def step_15() -> None:
        from prometheus.bg_sessions import (
            BgSession, list_sessions, find_session, pid_is_alive,
        )
        # Pure registry surface — no actual sessions needed.
        rows = list_sessions()
        assert isinstance(rows, list)
        assert pid_is_alive(0) is False
    results.append(_step("15 background session registry", step_15))

    # --- 16. Keyboard chord state machine ----
    def step_16() -> None:
        from prometheus.keyboard_chord import (
            ChordState, dispatch,
        )
        c = ChordState()
        assert dispatch("ctrl+x", chord=c, now=0.0) == "chord_armed"
        assert dispatch("ctrl+k", chord=c, now=0.1) == "kill_all"
    results.append(_step("16 keyboard chord (Ctrl+X Ctrl+K)", step_16))

    # --- 17. Task dependency chain ----
    def step_17() -> None:
        from prometheus.task_deps import (
            apply_dependencies, is_blocked, can_complete,
        )
        t0 = {"id": "T0", "status": "open"}
        t1 = {"id": "T1", "status": "open"}
        apply_dependencies(t1, blocked_by=["T0"])
        assert is_blocked(t1, [t0, t1]) is True
        ok, _ = can_complete(t1, [t0, t1])
        assert ok is False
        t0["status"] = "completed"
        ok, _ = can_complete(t1, [t0, t1])
        assert ok is True
    results.append(_step("17 task dependency chain", step_17))

    # --- 18. Context visualization ----
    def step_18() -> None:
        from prometheus.agent.context_viz import (
            bucket_messages, ContextBuckets,
        )
        snap = bucket_messages([
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "hello"},
        ])
        # ContextBuckets exposes role-keyed counts + a `total()`
        # method + `to_dict`; that's the renderer's contract.
        assert isinstance(snap, ContextBuckets)
        d = snap.to_dict()
        assert isinstance(d, dict)
        assert snap.total() >= 0
    results.append(_step("18 context visualization grid", step_18))

    # --- 19. Inline approval state machine ----
    def step_19() -> None:
        from prometheus.tui_inline_approval import (
            InlineApproval, begin, handle_keypress,
            render_prompt_line,
        )
        s = InlineApproval()
        begin(s, tool_name="Bash", detail="pwd")
        line = render_prompt_line(s)
        assert "● Bash(pwd)" in line
        assert "(y)es" in line
        assert handle_keypress(s, "a") == "always"
    results.append(_step("19 inline approval state machine", step_19))

    # --- 20. Sentinel HARD_DENY pattern ----
    def step_20() -> None:
        from prometheus.safety.overseer import Overseer
        ov = Overseer()
        # Round-104 contract: `evaluate(tool_name, args)`
        # returns an `OverseerVerdict`. Pass a destructive
        # bash command and verify the hard-deny rule fires.
        verdict = ov.evaluate(
            tool_name="run_bash",
            args={"command": "rm -rf /"},
        )
        assert verdict is not None
        tier = (
            getattr(verdict, "tier", None)
            or getattr(verdict, "decision", None)
        )
        if tier is not None:
            assert str(tier).lower() != "allow"
    results.append(_step("20 overseer rm -rf / hard deny", step_20))

    # --- 21. Round-141 streaming buffer ----
    def step_21() -> None:
        from prometheus.tui_streaming import (
            IncrementalBuffer, FlushClock,
        )
        b = IncrementalBuffer()
        assert b.append("hello") == "hello"
        assert b.append(", world") == ", world"
        b.finalize()
        assert b.text == "hello, world"
        c = FlushClock(interval_ms=100)
        # First call always passes.
        assert c.should_flush(now=10.0) is True
    results.append(_step("21 streaming incremental buffer", step_21))

    # --- 22. Round-141 transcript viewer ----
    def step_22() -> None:
        from prometheus.tui_transcript import (
            TranscriptViewer, open_viewer, handle_key,
        )
        v = TranscriptViewer()
        open_viewer(v, messages=[
            {"role": "user", "content": "alpha"},
            {"role": "assistant", "content": "beta"},
        ])
        assert v.open is True
        handle_key(v, "esc")
        assert v.open is False
    results.append(_step("22 transcript viewer key dispatch", step_22))

    # --- 23. Round-138 ghost mode + bundled skill ----
    def step_23() -> None:
        from prometheus.ghost_mode import (
            GhostMode, enable_ghost, ghost_mode_active,
            disable_ghost,
        )
        g = GhostMode()
        enable_ghost(g)
        assert ghost_mode_active() is True
        disable_ghost(g)
        assert ghost_mode_active() is False
    results.append(_step("23 ghost mode toggle", step_23))

    # --- 24. Round-143 share blade redaction ----
    def step_24() -> None:
        from prometheus.share_blade import redact, assemble_markdown
        body = "OPENROUTER_API_KEY=sk-or-v1-abcdef0123456789abcdef"
        out = redact(body)
        assert "[REDACTED]" in out
        assert "sk-or" not in out
        md, _ = assemble_markdown(messages=[
            {"role": "user", "content": "key: sk-ant-abcdef0123456789abcdef"},
        ])
        assert "[REDACTED]" in md
    results.append(_step("24 share blade redaction", step_24))

    # --- 25. Round-140 feature matrix audit ----
    def step_25() -> None:
        from prometheus.feature_matrix import run_audit
        report = run_audit()
        # The matrix has been growing across rounds; require
        # at least 50 surfaces verified (way under the actual
        # count, but this guards against the matrix being
        # accidentally emptied).
        assert report.passed >= 50, (
            f"only {report.passed} surfaces verified"
        )
    results.append(_step("25 feature matrix audit", step_25))

    return SelftestReport(results=results)


# ---------- async wrapper ----------


async def run_selftest_async(
    *, workdir: Optional[Path] = None,
) -> SelftestReport:
    """Round 144: thin async wrapper so the slash command can
    `await` it. The body is sync — we just yield to the loop."""
    return run_selftest(workdir=workdir)


# ---------- rendering ----------


def render_report(report: SelftestReport) -> str:
    """Round 144: aligned report. Failed rows surface at the
    bottom with their detail."""
    lines: list[str] = []
    lines.append(
        f"selftest: {report.passed}/{report.total} steps passed"
    )
    lines.append("")
    for r in report.results:
        glyph = "✓" if r.ok else "✗"
        ms = f"{r.duration_ms:6.1f}ms"
        line = f"  {glyph} {r.name:50s}  {ms}"
        if not r.ok:
            line += f"  — {r.detail[:80]}"
        lines.append(line)
    if report.failed:
        lines.append("")
        lines.append(f"⚠ {report.failed} step(s) failed:")
        for r in report.failed_rows():
            lines.append(f"  ✗ {r.name}")
            lines.append(f"      {r.detail}")
    else:
        lines.append("")
        lines.append("✓ every step passed — public-quality build")
    return "\n".join(lines)
