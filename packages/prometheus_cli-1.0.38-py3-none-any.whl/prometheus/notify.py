"""Round 184: terminal desktop notifications (OSC 9 / OSC 777 / BEL).

When a long-running bash command finishes, when a background agent
completes, or when an approval prompt is awaiting user input and
the terminal is not focused, every commercial terminal AI agent
fires a desktop notification. Codex CLI uses OSC 9 (iTerm2 / Warp
convention). xterm / rxvt-unicode / Konsole / VTE-based terminals
honour OSC 777. As a last-resort fallback, plain BEL (\\x07)
flashes the terminal title bar in most apps.

Pre-R184 Prometheus had no completion notification path beyond the
in-TUI banner. This module adds the standard escape-sequence layer
behind a `PROMETHEUS_NOTIFY=1` opt-in (per Codex's
`notification_condition = "always"` config).

Public API:
  notify(title, body)           — emit a desktop notification
  bell()                        — emit BEL (terminal bell / flash)
  notify_on_complete_enabled()  — has the user opted in?

The opt-in defaults to OFF because aggressive notifications are
the #1 cited annoyance with terminal AI tools (Codex #3962); users
turn it on only when running long tasks unattended.
"""
from __future__ import annotations

import os
import sys


def _emit(seq: str) -> None:
    """Write a control sequence to stderr without disturbing stdout
    (which may be piped to a file). Best-effort — swallow IOError."""
    try:
        sys.stderr.write(seq)
        sys.stderr.flush()
    except (OSError, ValueError):
        pass


def notify_on_complete_enabled() -> bool:
    """Whether the user opted into desktop notifications. Re-read
    on every call so a runtime `/notify on` slash command can flip
    the flag."""
    return os.environ.get("PROMETHEUS_NOTIFY", "").strip().lower() in (
        "1", "true", "yes", "on",
    )


def bell() -> None:
    """Emit BEL (\\x07). Most terminal emulators flash the tab/title
    bar or play a system bell. Universal fallback when richer
    notifications aren't supported."""
    _emit("\x07")


def _osc9(message: str) -> str:
    """iTerm2 / Warp / urxvt notification format:
        ESC ] 9 ; <message> ST
    where ST is BEL (\\x07) or ESC \\\\.
    """
    safe = message.replace("\x07", " ").replace("\x1b", " ")
    return f"\x1b]9;{safe}\x07"


def _osc777(title: str, body: str) -> str:
    """rxvt-unicode / Konsole / VTE notification format:
        ESC ] 777 ; notify ; <title> ; <body> ST
    """
    safe_t = title.replace(";", ",").replace("\x07", " ").replace("\x1b", " ")
    safe_b = body.replace(";", ",").replace("\x07", " ").replace("\x1b", " ")
    return f"\x1b]777;notify;{safe_t};{safe_b}\x07"


def notify(title: str, body: str = "") -> None:
    """Emit a desktop notification.

    No-op when `PROMETHEUS_NOTIFY` is not set. When enabled, fires
    BOTH OSC 9 and OSC 777 — terminals that recognise neither just
    silently ignore the unknown sequence. The dual emit costs
    nothing and reaches every major emulator (iTerm2, Warp, Ghostty,
    Konsole, GNOME Terminal, rxvt-unicode, urxvt).

    A trailing BEL is also emitted so terminals without OSC support
    still flash their tab. Users who find this annoying can suppress
    by leaving PROMETHEUS_NOTIFY unset (the default)."""
    if not notify_on_complete_enabled():
        return
    label = title if not body else f"{title}: {body}"
    _emit(_osc9(label))
    _emit(_osc777(title, body))
    bell()


def notify_task_done(task_summary: str, duration_s: float) -> None:
    """Convenience wrapper for the most common firing point —
    a long-running bash / background agent finishes. Includes an
    elapsed-time figure so the user knows how long they were AFK."""
    if duration_s < 1:
        body = f"({duration_s:.0f}s)"
    elif duration_s < 60:
        body = f"({duration_s:.1f}s)"
    else:
        m = int(duration_s // 60)
        s = int(duration_s % 60)
        body = f"({m}m {s}s)"
    notify(f"PrometheUS · {task_summary}", body)
