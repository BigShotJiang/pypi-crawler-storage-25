"""Round 131: PR integration suite.

Three slash commands wrap the GitHub `gh` CLI to surface PRs
inside the chat:

  * `/review`        — review the PR for current branch (or
                       supplied PR number) and produce inline
                       comments locally
  * `/pr-comments`   — post inline comments to a GitHub PR
  * `/autofix-pr`    — watch CI on the open PR and propose +
                       push fixes when a check fails

Architecture: every shell-out goes through `_run_gh()` which
returns a structured `GhResult`. Callers decide how to render.
We never trust untrusted CLI output for code execution; we only
parse for our own message formatting.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


# ---------- gh CLI invocation ----------


@dataclass
class GhResult:
    ok: bool
    stdout: str = ""
    stderr: str = ""
    exit_code: int = 0


def gh_available() -> bool:
    """Round 131: detect whether the `gh` CLI is installed and
    reachable on PATH. The whole suite depends on it."""
    return bool(shutil.which("gh"))


def _run_gh(args: list[str], *, cwd: Optional[Path] = None) -> GhResult:
    """Invoke `gh` with the supplied arguments. Captures stdout
    + stderr. Never shells out (uses `subprocess.run` with the
    list form). 30-second timeout."""
    if not gh_available():
        return GhResult(
            ok=False, stderr="gh CLI not installed", exit_code=127,
        )
    try:
        cp = subprocess.run(
            ["gh", *args],
            cwd=str(cwd) if cwd else None,
            capture_output=True, text=True, timeout=30,
            check=False,
        )
        return GhResult(
            ok=(cp.returncode == 0),
            stdout=cp.stdout or "",
            stderr=cp.stderr or "",
            exit_code=cp.returncode,
        )
    except subprocess.TimeoutExpired:
        return GhResult(
            ok=False, stderr="gh call timed out", exit_code=124,
        )
    except OSError as e:
        return GhResult(
            ok=False, stderr=f"gh launch failed: {e}", exit_code=1,
        )


# ---------- PR resolution ----------


def current_pr_number(cwd: Optional[Path] = None) -> Optional[int]:
    """Round 131: ask `gh pr view` for the current branch's PR
    number. Returns None when no PR is open."""
    res = _run_gh(["pr", "view", "--json", "number"], cwd=cwd)
    if not res.ok:
        return None
    try:
        data = json.loads(res.stdout)
        n = int(data.get("number", 0))
        return n or None
    except (ValueError, json.JSONDecodeError):
        return None


@dataclass
class PullRequest:
    number: int
    title: str
    head_ref: str
    base_ref: str
    state: str
    files: list[str] = field(default_factory=list)


def fetch_pr(
    pr_number: Optional[int] = None,
    *, cwd: Optional[Path] = None,
) -> Optional[PullRequest]:
    """Fetch core PR fields. Returns None on failure."""
    args = [
        "pr", "view",
        "--json", "number,title,headRefName,baseRefName,state,files",
    ]
    if pr_number:
        args.insert(2, str(pr_number))
    res = _run_gh(args, cwd=cwd)
    if not res.ok:
        return None
    try:
        d = json.loads(res.stdout)
        files = [f.get("path", "") for f in d.get("files", []) or []]
        return PullRequest(
            number=int(d.get("number", 0)),
            title=str(d.get("title", "")),
            head_ref=str(d.get("headRefName", "")),
            base_ref=str(d.get("baseRefName", "")),
            state=str(d.get("state", "")),
            files=[f for f in files if f],
        )
    except (ValueError, json.JSONDecodeError):
        return None


# ---------- inline comment shape ----------


@dataclass
class InlineComment:
    """One review comment targeting a specific file:line range."""
    file: str
    line: int
    body: str
    severity: str = "info"        # critical/high/medium/low/info
    side: str = "RIGHT"           # RIGHT (head) or LEFT (base)

    def to_payload(self) -> dict[str, Any]:
        return {
            "path": self.file,
            "line": int(self.line),
            "body": self.body,
            "side": self.side,
        }


def render_review_summary(
    pr: PullRequest, comments: list[InlineComment],
) -> str:
    """Round 131: human summary for `/review`. Groups by
    severity and lists each comment with file:line."""
    lines: list[str] = []
    lines.append(
        f"Review for #{pr.number} · {pr.title}  ({pr.state})"
    )
    lines.append(f"  base: {pr.base_ref}  head: {pr.head_ref}")
    if not comments:
        lines.append("  ✓ No findings.")
        return "\n".join(lines)
    by_sev: dict[str, list[InlineComment]] = {}
    for c in comments:
        by_sev.setdefault(c.severity, []).append(c)
    order = ("critical", "high", "medium", "low", "info")
    for sev in order:
        if sev not in by_sev:
            continue
        lines.append(f"  {sev.upper()} ({len(by_sev[sev])}):")
        for c in by_sev[sev]:
            head = c.body.splitlines()[0] if c.body else ""
            lines.append(f"    {c.file}:{c.line}  {head}")
    return "\n".join(lines)


# ---------- post comments ----------


def post_inline_comments(
    pr_number: int, comments: list[InlineComment],
    *, cwd: Optional[Path] = None,
) -> GhResult:
    """Round 131: post inline review comments to a GitHub PR.

    Uses `gh api` to call the GitHub reviews endpoint. Returns
    a single GhResult — the API call either succeeds (the
    review is posted in `COMMENT` state) or fails with the
    error from gh."""
    if not comments:
        return GhResult(ok=False, stderr="no comments to post")
    payload = {
        "event": "COMMENT",
        "body": "PrometheUS inline review",
        "comments": [c.to_payload() for c in comments],
    }
    body = json.dumps(payload)
    args = [
        "api", "--method", "POST",
        f"repos/{{owner}}/{{repo}}/pulls/{pr_number}/reviews",
        "--input", "-",
    ]
    if not gh_available():
        return GhResult(
            ok=False, stderr="gh CLI not installed", exit_code=127,
        )
    try:
        cp = subprocess.run(
            ["gh", *args],
            input=body, capture_output=True, text=True,
            cwd=str(cwd) if cwd else None,
            timeout=30, check=False,
        )
        return GhResult(
            ok=(cp.returncode == 0),
            stdout=cp.stdout or "",
            stderr=cp.stderr or "",
            exit_code=cp.returncode,
        )
    except subprocess.TimeoutExpired:
        return GhResult(
            ok=False, stderr="gh post timed out", exit_code=124,
        )
    except OSError as e:
        return GhResult(
            ok=False, stderr=f"gh post failed: {e}", exit_code=1,
        )


# ---------- CI check status ----------


@dataclass
class CheckRun:
    name: str
    status: str       # `completed` / `in_progress` / `queued`
    conclusion: str   # `success` / `failure` / `cancelled` / ...
    workflow: str = ""
    job_url: str = ""


def fetch_pr_checks(
    pr_number: Optional[int] = None,
    *, cwd: Optional[Path] = None,
) -> list[CheckRun]:
    """Round 131: list CI checks for the PR. Empty list when
    gh fails or no checks are configured."""
    args = ["pr", "checks"]
    if pr_number:
        args.append(str(pr_number))
    args.extend(["--json", "name,status,conclusion,workflow,link"])
    res = _run_gh(args, cwd=cwd)
    if not res.ok:
        return []
    try:
        rows = json.loads(res.stdout)
        if not isinstance(rows, list):
            return []
        return [
            CheckRun(
                name=str(r.get("name", "")),
                status=str(r.get("status", "")),
                conclusion=str(r.get("conclusion", "")),
                workflow=str(r.get("workflow", "")),
                job_url=str(r.get("link", "")),
            )
            for r in rows
        ]
    except (ValueError, json.JSONDecodeError):
        return []


def failed_checks(checks: list[CheckRun]) -> list[CheckRun]:
    """Round 131: helper for `/autofix-pr` — only the failures."""
    return [
        c for c in checks
        if c.status == "completed"
        and c.conclusion in ("failure", "cancelled", "timed_out")
    ]


def render_check_summary(checks: list[CheckRun]) -> str:
    """Round 131: human summary of CI state."""
    if not checks:
        return "  no CI checks configured."
    out: list[str] = []
    for c in checks:
        if c.status != "completed":
            out.append(f"  ⏵ {c.name}  ({c.status})")
        elif c.conclusion == "success":
            out.append(f"  ✓ {c.name}")
        else:
            out.append(f"  ✗ {c.name}  ({c.conclusion})")
    return "\n".join(out)


# ---------- diff parser ----------


_HUNK_RX = re.compile(r"^@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@")


def fetch_pr_diff(
    pr_number: Optional[int] = None,
    *, cwd: Optional[Path] = None,
) -> str:
    """Round 131: raw diff for the PR. Used by `/review`."""
    args = ["pr", "diff"]
    if pr_number:
        args.append(str(pr_number))
    res = _run_gh(args, cwd=cwd)
    return res.stdout if res.ok else ""


def parse_diff_files(diff: str) -> list[tuple[str, list[int]]]:
    """Walk a unified diff, return [(file, [head-line-numbers])].

    The line numbers are the +start of each hunk — enough to
    place inline comments on changed regions."""
    out: list[tuple[str, list[int]]] = []
    cur_file = ""
    cur_lines: list[int] = []
    for raw in diff.splitlines():
        if raw.startswith("+++ b/"):
            if cur_file:
                out.append((cur_file, cur_lines))
            cur_file = raw[6:].strip()
            cur_lines = []
            continue
        m = _HUNK_RX.match(raw)
        if m and cur_file:
            try:
                cur_lines.append(int(m.group(1)))
            except ValueError:
                pass
    if cur_file:
        out.append((cur_file, cur_lines))
    return out
