"""Round 142: fork-cache optimization.

When `/fork` spawns N child subagents, every child shares the
parent's full conversation up to the fork point. The naive
implementation re-tokenizes the same prefix N times. By
constructing **byte-identical** message prefixes for every
child, the provider's prompt cache hits, and we save one
prefix worth of tokens per fork.

The trick: tool calls in the parent often have *open*
`tool_call` entries that need a `tool_result` to follow them.
For child forks, we synthesize a placeholder
`tool_result` so the prefix terminates cleanly without
diverging between children. Only the per-child *suffix* (the
fork directive) differs.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Optional


# ---------- prefix construction ----------


def _last_open_tool_call_id(messages: list[dict[str, Any]]) -> Optional[str]:
    """Round 142: a tool_call is `open` if no matching
    tool_result follows it. Returns the id of the last open
    call, or None when the conversation ends cleanly."""
    open_ids: list[str] = []
    seen_results: set[str] = set()
    for m in messages:
        if not isinstance(m, dict):
            continue
        for call in m.get("tool_calls") or []:
            if isinstance(call, dict):
                cid = str(call.get("id") or call.get("tool_use_id") or "")
                if cid:
                    open_ids.append(cid)
        if m.get("role") == "tool":
            tid = str(
                m.get("tool_call_id")
                or m.get("tool_use_id")
                or ""
            )
            if tid:
                seen_results.add(tid)
    for cid in reversed(open_ids):
        if cid not in seen_results:
            return cid
    return None


def synthesize_placeholder_result(tool_call_id: str) -> dict[str, Any]:
    """Round 142: a deterministic, byte-identical placeholder
    that terminates an open tool call so the cached prefix is
    well-formed."""
    return {
        "role": "tool",
        "tool_call_id": tool_call_id,
        "content": "[fork-placeholder]",
        "_fork_placeholder": True,
    }


def build_forked_messages(
    parent_messages: list[dict[str, Any]],
    *,
    directives: list[str],
) -> list[list[dict[str, Any]]]:
    """Round 142: for each per-child directive, return a full
    message list that shares a byte-identical prefix with all
    other children. Only the trailing user message differs.

    Returns a list of per-child message lists, one per
    directive."""
    if not directives:
        return []
    base = list(parent_messages)
    open_id = _last_open_tool_call_id(base)
    if open_id is not None:
        base = base + [synthesize_placeholder_result(open_id)]
    out: list[list[dict[str, Any]]] = []
    for directive in directives:
        directive = (directive or "").strip()
        if not directive:
            continue
        suffix = {"role": "user", "content": directive}
        out.append(base + [suffix])
    return out


# ---------- prefix verification ----------


def shared_prefix_length(
    forks: list[list[dict[str, Any]]],
) -> int:
    """Round 142: how many leading messages are byte-identical
    across every fork. Used by tests + telemetry."""
    if not forks or any(not f for f in forks):
        return 0
    encoded = [
        [json.dumps(m, sort_keys=True, default=str) for m in f]
        for f in forks
    ]
    n = min(len(e) for e in encoded)
    for i in range(n):
        sample = encoded[0][i]
        if any(e[i] != sample for e in encoded):
            return i
    return n


@dataclass
class ForkCacheReport:
    fork_count: int
    shared_prefix_messages: int
    suffix_per_fork_messages: int
    cache_hit_ratio: float


def report(
    parent_messages: list[dict[str, Any]],
    forks: list[list[dict[str, Any]]],
) -> ForkCacheReport:
    """Round 142: telemetry helper. `cache_hit_ratio` is the
    fraction of messages that are part of the shared prefix —
    a rough proxy for how much the provider cache will save
    you."""
    if not forks:
        return ForkCacheReport(
            fork_count=0,
            shared_prefix_messages=0,
            suffix_per_fork_messages=0,
            cache_hit_ratio=0.0,
        )
    shared = shared_prefix_length(forks)
    avg_len = sum(len(f) for f in forks) / len(forks)
    if avg_len == 0:
        ratio = 0.0
    else:
        ratio = shared / avg_len
    return ForkCacheReport(
        fork_count=len(forks),
        shared_prefix_messages=shared,
        suffix_per_fork_messages=int(avg_len - shared),
        cache_hit_ratio=round(ratio, 4),
    )


def render_report(r: ForkCacheReport) -> str:
    return (
        f"fork-cache report:\n"
        f"  forks:            {r.fork_count}\n"
        f"  shared prefix:    {r.shared_prefix_messages} message(s)\n"
        f"  per-fork suffix:  {r.suffix_per_fork_messages} message(s)\n"
        f"  cache hit ratio:  {r.cache_hit_ratio:.1%}"
    )
