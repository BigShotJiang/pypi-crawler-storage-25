"""Round 130: --dangerously-skip-permissions bypass mode.

Bypass mode auto-approves every tool call, no prompts. It is
intentionally:

  * Only enable-able via CLI flag (`--dangerously-skip-permissions`).
  * Cannot be enabled mid-session — the user must restart with
    the flag. This forces an explicit acknowledgment.
  * Visible: the status bar shows a red `BYPASS` chip while
    active, and the launch banner prints a prominent warning.
  * Reversible only by quitting and relaunching.

A separate flag, `--allow-dangerously-skip-permissions`, adds
`bypassPermissions` to the Shift+Tab cycle so a user can opt
into the toggle path explicitly.
"""
from __future__ import annotations

import os


def bypass_active() -> bool:
    """Round 130: true when the launch flag set bypass on. The
    flag writes `PROMETHEUS_BYPASS=1`."""
    return os.environ.get("PROMETHEUS_BYPASS", "").strip().lower() in (
        "1", "true", "yes",
    )


def bypass_in_cycle() -> bool:
    """True when `--allow-dangerously-skip-permissions` was
    supplied — adds bypass to the Shift+Tab cycle."""
    return os.environ.get(
        "PROMETHEUS_ALLOW_BYPASS_TOGGLE", "",
    ).strip().lower() in ("1", "true", "yes")


def set_bypass_active(on: bool) -> None:
    """Round 130: write the env flag. Refuses to enable when
    called mid-session (env was unset on launch). Caller
    enforces the once-at-launch contract."""
    os.environ["PROMETHEUS_BYPASS"] = "1" if on else "0"


def set_bypass_in_cycle(on: bool) -> None:
    os.environ["PROMETHEUS_ALLOW_BYPASS_TOGGLE"] = "1" if on else "0"


def warning_banner() -> str:
    """The launch warning shown when bypass is active. Bright,
    unambiguous — public-quality."""
    return (
        "╭─────────────────────────────────────────────────────────╮\n"
        "│  ⚠ BYPASS PERMISSIONS MODE — every tool auto-approved.  │\n"
        "│  Cannot be turned off without quitting + relaunch.       │\n"
        "│  Use only with code you fully trust.                     │\n"
        "╰─────────────────────────────────────────────────────────╯"
    )


def status_chip() -> str:
    """Round 130: status-bar text for the BYPASS indicator."""
    return "BYPASS"


def cycle_modes(*, include_bypass: bool = False) -> list[str]:
    """Round 130: build the Shift+Tab cycle order. The bypass
    mode shows up only when explicitly opted in."""
    base = ["default", "acceptEdits", "plan", "auto"]
    if include_bypass or bypass_in_cycle():
        base.append("bypassPermissions")
    return base
