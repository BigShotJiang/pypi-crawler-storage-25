"""Local Whisper transcription via faster-whisper (CTranslate2).

Lazy module-level cache so the first call pays the model load tax
(~1-3s for distil-small.en) and subsequent calls reuse the loaded
model.
"""
from __future__ import annotations

import asyncio
from typing import Any

_model: Any = None
_loaded_name: str = ""


def _load(name: str) -> Any:
    global _model, _loaded_name
    if _model is None or _loaded_name != name:
        from faster_whisper import WhisperModel
        _model = WhisperModel(
            name,
            device="cpu",
            compute_type="int8",
            cpu_threads=4,
        )
        _loaded_name = name
    return _model


async def transcribe(audio_f32, sr: int, prompt: str, model_name: str) -> str:
    def _run() -> str:
        m = _load(model_name)
        segments, _info = m.transcribe(
            audio_f32,
            language="en",
            initial_prompt=prompt,
            vad_filter=True,
            vad_parameters=dict(min_silence_duration_ms=400),
            beam_size=1,
            condition_on_previous_text=False,
            no_speech_threshold=0.6,
        )
        return " ".join(s.text.strip() for s in segments).strip()
    return await asyncio.to_thread(_run)
