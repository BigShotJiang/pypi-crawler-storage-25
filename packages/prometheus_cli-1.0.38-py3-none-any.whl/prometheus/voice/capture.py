"""Microphone capture wrapper. sounddevice → ring of numpy float32 frames.

Lazy: `import sounddevice` only happens when this module is loaded,
which is gated by VoiceSession.start(). The base install can survive
without it.
"""
from __future__ import annotations

import collections
import math
from typing import Callable


class _Capture:
    """Owns one InputStream. RMS callback fires ~20× per second so a
    VU meter widget can animate smoothly."""

    def __init__(self, sample_rate: int, on_level: Callable[[float], None] | None) -> None:
        self.sr = sample_rate
        self.on_level = on_level
        self.buf: list = []
        self._stream = None
        self._rms_window = collections.deque(maxlen=30)

    def _cb(self, indata, frames, time_info, status):
        import numpy as np
        mono = indata[:, 0] if indata.ndim == 2 else indata
        self.buf.append(mono.copy())
        rms = float(math.sqrt(float(np.mean(mono * mono)) + 1e-12))
        self._rms_window.append(rms)
        if self.on_level:
            try:
                # 6× gain so the meter has visible swing even on quiet mics.
                self.on_level(min(1.0, rms * 6.0))
            except Exception:
                pass

    def start(self) -> None:
        import sounddevice as sd
        self._stream = sd.InputStream(
            samplerate=self.sr,
            channels=1,
            dtype="float32",
            blocksize=int(self.sr * 0.05),
            callback=self._cb,
        )
        self._stream.start()

    def stop(self):
        import numpy as np
        s = self._stream
        self._stream = None
        if s is not None:
            try:
                s.stop()
                s.close()
            except Exception:
                pass
        if not self.buf:
            return np.zeros(0, dtype="float32")
        return np.concatenate(self.buf, axis=0)
