"""Push-to-talk voice mode for PrometheUS.

Hold-spacebar isn't reliably detectable in terminals (no key-release
events on stdin), so we use a TOGGLE: Ctrl+Space (or `/voice`) starts
recording, the same gesture stops + transcribes. Esc cancels.

Backend selection (lazy):
    PROMETHEUS_VOICE_BACKEND=local|groq|auto  (default auto)
      auto → local if faster-whisper installed
            else groq if GROQ_API_KEY set
            else "none" → friendly error.

The base install stays slim. faster-whisper, sounddevice, numpy are
ALL optional — `is_available()` reports the missing one cleanly, and
`pip install prometheus[voice]` (or piecemeal) wires everything up.

Privacy: local backend never leaves the machine. Groq's published
policy is zero-retention by default for /audio/transcriptions.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Callable, Optional


_CODER_PROMPT = (
    "Coding session. Common terms: ripgrep, regex, stdio, stdin, "
    "stderr, async, await, npm, pip, git, ssh, kubectl, sed, awk, "
    "grep, jq, tmux, vim, neovim, postgres, sqlite, json, yaml, "
    "kubernetes, docker, react, fastapi, uvicorn."
)


@dataclass
class VoiceConfig:
    backend: str = "auto"               # "auto" | "local" | "groq"
    model: str = "distil-small.en"      # local model name; ignored for groq
    sample_rate: int = 16000
    channels: int = 1
    initial_prompt: str = _CODER_PROMPT
    max_seconds: float = 60.0
    min_seconds: float = 0.4
    silence_rms: float = 0.005
    silence_seconds: float = 1.5


def _pick_backend(cfg: VoiceConfig) -> str:
    if cfg.backend != "auto":
        return cfg.backend
    try:
        import faster_whisper  # noqa: F401
        return "local"
    except ImportError:
        if os.getenv("GROQ_API_KEY"):
            return "groq"
        return "none"


def is_available(cfg: VoiceConfig | None = None) -> tuple[bool, str]:
    """Returns (ok, reason). reason is the exact next step the user
    needs to take if voice can't run yet."""
    cfg = cfg or VoiceConfig()
    try:
        import sounddevice  # noqa: F401
        import numpy        # noqa: F401
    except ImportError:
        return False, "audio capture libs missing — pip install sounddevice numpy"
    backend = _pick_backend(cfg)
    if backend == "none":
        return False, (
            "no STT backend — pip install faster-whisper, "
            "or set GROQ_API_KEY to use Groq's free Whisper API"
        )
    if backend == "groq" and not os.getenv("GROQ_API_KEY"):
        return False, "GROQ_API_KEY not set"
    return True, ""


class VoiceSession:
    """Owns one recording. Use:

        s = VoiceSession(cfg, on_level=meter_callback)
        s.start()
        # ... user speaks; on_level(rms_float) fires every ~50ms ...
        text = await s.stop_and_transcribe()
    """

    def __init__(
        self,
        cfg: VoiceConfig,
        on_level: Callable[[float], None] | None = None,
    ) -> None:
        self.cfg = cfg
        self.on_level = on_level
        self._cap: "Any" = None
        self._started_at: float = 0.0

    @property
    def is_recording(self) -> bool:
        return self._cap is not None

    @property
    def elapsed_s(self) -> float:
        if not self._started_at:
            return 0.0
        import time
        return time.monotonic() - self._started_at

    def start(self) -> None:
        # Lazy import — we only require sounddevice when voice actually fires.
        from prometheus.voice.capture import _Capture
        import time
        cap = _Capture(self.cfg.sample_rate, self.on_level)
        cap.start()
        self._cap = cap
        self._started_at = time.monotonic()

    def cancel(self) -> None:
        if self._cap is not None:
            try:
                self._cap.stop()
            except Exception:
                pass
            self._cap = None

    async def stop_and_transcribe(self) -> str:
        if self._cap is None:
            return ""
        cap = self._cap
        self._cap = None
        audio = cap.stop()
        # Reject too-short recordings (accidental keypress).
        if len(audio) < int(self.cfg.sample_rate * self.cfg.min_seconds):
            return ""
        backend = _pick_backend(self.cfg)
        if backend == "local":
            from prometheus.voice.stt_local import transcribe as _local
            return await _local(audio, self.cfg.sample_rate, self.cfg.initial_prompt, self.cfg.model)
        if backend == "groq":
            from prometheus.voice.stt_groq import transcribe as _groq
            return await _groq(audio, self.cfg.sample_rate, self.cfg.initial_prompt)
        raise RuntimeError("no voice backend available")
