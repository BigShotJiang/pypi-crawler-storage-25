"""Groq Whisper transcription — free-tier OpenAI-compatible endpoint.

Pure httpx; we don't pull the openai SDK as a dep just for one POST.
Groq's published policy is zero-retention by default for
/audio/transcriptions, which is why we recommend it as the cloud
fallback.
"""
from __future__ import annotations

import io
import os
import wave

import httpx


GROQ_URL = "https://api.groq.com/openai/v1/audio/transcriptions"


async def transcribe(audio_f32, sr: int, prompt: str) -> str:
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        raise RuntimeError("GROQ_API_KEY not set")
    # Encode float32 [-1.0, 1.0] → 16-bit PCM WAV in memory.
    pcm16 = (audio_f32 * 32767.0).clip(-32768, 32767).astype("int16").tobytes()
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm16)
    buf.seek(0)
    # Round-20 P1: one transparent retry on transient transport errors
    # (architectural review #12). A single Groq blip would otherwise
    # eat the user's full transcription with no recovery path.
    import asyncio as _aio
    last: Exception | None = None
    for attempt in range(2):
        buf.seek(0)
        try:
            # Round 179: STT (voice) respects corporate proxy + CA.
            from prometheus.net import net_kwargs
            async with httpx.AsyncClient(**net_kwargs(timeout=30.0)) as c:
                r = await c.post(
                    GROQ_URL,
                    headers={"Authorization": f"Bearer {api_key}"},
                    data={
                        "model": "whisper-large-v3-turbo",
                        "language": "en",
                        "prompt": prompt,
                        "response_format": "json",
                        "temperature": "0",
                    },
                    files={"file": ("audio.wav", buf, "audio/wav")},
                )
                if 500 <= r.status_code < 600 and attempt == 0:
                    await _aio.sleep(0.6)
                    continue
                r.raise_for_status()
                return (r.json().get("text") or "").strip()
        except (httpx.TimeoutException, httpx.ConnectError, httpx.RemoteProtocolError) as e:
            last = e
            if attempt == 0:
                await _aio.sleep(0.6)
                continue
            break
    if last:
        raise last
    return ""
