"""Round 140: feature-matrix verification layer.

Every item from the round 140 spec was already shipped in
rounds 137–139. Round 140's genuine contribution is the
**audit module** that catalogues each shipped surface and the
integration tests that prove the wiring still works.

The matrix is consumed by:

  * `tests/test_round140_audit.py` — asserts every entry is
    importable + behaves at its documented contract.
  * `/audit` slash command — prints a human matrix at runtime
    so users can inspect the surface coverage of their build.

Add a new surface? Append a row here with a one-line `check`
callable that returns (ok, detail). Failing rows surface in
both the test suite and the slash command.
"""
from __future__ import annotations

import importlib
from dataclasses import dataclass
from typing import Any, Callable, Optional


@dataclass
class Surface:
    """Round 140: one entry in the matrix."""
    name: str
    category: str
    shipped_in: str
    check: Callable[[], tuple[bool, str]]


# ---------- check helpers ----------


def _has_attr(module: str, attr: str) -> tuple[bool, str]:
    try:
        m = importlib.import_module(module)
    except ImportError as e:
        return (False, f"import failed: {e}")
    if not hasattr(m, attr):
        return (False, f"{module}.{attr} missing")
    return (True, "ok")


def _has_attrs(module: str, attrs: tuple[str, ...]) -> tuple[bool, str]:
    try:
        m = importlib.import_module(module)
    except ImportError as e:
        return (False, f"import failed: {e}")
    missing = [a for a in attrs if not hasattr(m, a)]
    if missing:
        return (False, f"missing: {', '.join(missing)}")
    return (True, f"ok ({len(attrs)} symbols)")


def _has_cli_flag(flag: str) -> tuple[bool, str]:
    try:
        from prometheus.headless import build_parser
        p = build_parser()
    except Exception as e:
        return (False, f"build_parser failed: {e}")
    # argparse stores flags by their name; walk the actions.
    for action in p._actions:
        if flag in (action.option_strings or []):
            return (True, "ok")
    return (False, f"flag {flag!r} not in parser")


def _has_subcommand(name: str) -> tuple[bool, str]:
    try:
        from prometheus.cli_subcommands import SUBCOMMANDS
    except ImportError as e:
        return (False, f"import failed: {e}")
    if name not in SUBCOMMANDS:
        return (False, f"subcommand {name!r} not registered")
    return (True, "ok")


def _has_bundled_aptitude(name: str) -> tuple[bool, str]:
    try:
        from prometheus.agent.bundled_skills import bundled_names
    except ImportError as e:
        return (False, f"import failed: {e}")
    names = bundled_names()
    if name not in names:
        return (False, f"{name!r} not in bundled aptitudes")
    return (True, "ok")


# ---------- the matrix ----------


def matrix() -> list[Surface]:
    return [
        # ---- Task 1: timeouts ----
        Surface(
            "PROMETHEUS_BASH_DEFAULT_TIMEOUT_MS",
            "timeouts", "139",
            lambda: _has_attr(
                "prometheus.timeouts", "bash_default_timeout_ms",
            ),
        ),
        Surface(
            "PROMETHEUS_BASH_MAX_TIMEOUT_MS",
            "timeouts", "139",
            lambda: _has_attr(
                "prometheus.timeouts", "bash_max_timeout_ms",
            ),
        ),
        Surface(
            "PROMETHEUS_BASH_MAX_OUTPUT_LENGTH",
            "timeouts", "139",
            lambda: _has_attr(
                "prometheus.timeouts", "bash_max_output_length",
            ),
        ),
        Surface(
            "PROMETHEUS_MAX_MCP_OUTPUT_TOKENS",
            "timeouts", "139",
            lambda: _has_attr(
                "prometheus.timeouts", "mcp_max_output_tokens",
            ),
        ),
        Surface(
            "PROMETHEUS_MCP_TIMEOUT",
            "timeouts", "139",
            lambda: _has_attr(
                "prometheus.timeouts", "mcp_timeout_ms",
            ),
        ),
        Surface(
            "PROMETHEUS_MCP_TOOL_TIMEOUT",
            "timeouts", "139",
            lambda: _has_attr(
                "prometheus.timeouts", "mcp_tool_timeout_ms",
            ),
        ),
        Surface(
            "PROMETHEUS_MAX_THINKING_TOKENS",
            "timeouts", "139",
            lambda: _has_attr(
                "prometheus.timeouts", "max_thinking_tokens",
            ),
        ),
        # ---- Task 1: disable env vars ----
        Surface(
            "PROMETHEUS_DISABLE_BACKGROUND_TASKS",
            "env-flags", "137",
            lambda: _has_attr(
                "prometheus.env_flags", "background_tasks_disabled",
            ),
        ),
        Surface(
            "PROMETHEUS_DISABLE_FAST_MODE",
            "env-flags", "138",
            lambda: _has_attr(
                "prometheus.env_flags_v138", "fast_mode_disabled",
            ),
        ),
        Surface(
            "PROMETHEUS_DISABLE_MOUSE",
            "env-flags", "138",
            lambda: _has_attr(
                "prometheus.env_flags_v138", "disable_mouse",
            ),
        ),
        Surface(
            "PROMETHEUS_DISABLE_TERMINAL_TITLE",
            "env-flags", "138",
            lambda: _has_attr(
                "prometheus.env_flags_v138", "disable_terminal_title",
            ),
        ),
        Surface(
            "PROMETHEUS_DISABLE_VIRTUAL_SCROLL",
            "env-flags", "138",
            lambda: _has_attr(
                "prometheus.env_flags_v138", "disable_virtual_scroll",
            ),
        ),
        Surface(
            "PROMETHEUS_DISABLE_PROMPT_SUGGESTION",
            "env-flags", "138",
            lambda: _has_attr(
                "prometheus.env_flags_v138",
                "disable_prompt_suggestion",
            ),
        ),
        Surface(
            "PROMETHEUS_CUSTOM_MODEL_OPTION",
            "env-flags", "138",
            lambda: _has_attr(
                "prometheus.env_flags_v138", "custom_model_option",
            ),
        ),
        Surface(
            "PROMETHEUS_PROXY_RESOLVES_HOSTS",
            "env-flags", "138",
            lambda: _has_attr(
                "prometheus.env_flags_v138", "proxy_resolves_hosts",
            ),
        ),
        Surface(
            "PROMETHEUS_TASK_LIST_ID",
            "env-flags", "138",
            lambda: _has_attr(
                "prometheus.env_flags_v138", "shared_task_list_id",
            ),
        ),
        Surface(
            "PROMETHEUS_DISABLE_COMPACT",
            "env-flags", "139",
            lambda: _has_attr(
                "prometheus.timeouts", "compact_disabled",
            ),
        ),
        Surface(
            "PROMETHEUS_DISABLE_DOCTOR_COMMAND",
            "env-flags", "139",
            lambda: _has_attr(
                "prometheus.timeouts", "doctor_disabled",
            ),
        ),
        Surface(
            "PROMETHEUS_DISABLE_FEEDBACK_COMMAND",
            "env-flags", "139",
            lambda: _has_attr(
                "prometheus.timeouts", "feedback_disabled",
            ),
        ),
        Surface(
            "PROMETHEUS_SUBPROCESS_ENV_SCRUB",
            "env-flags", "137",
            lambda: _has_attr(
                "prometheus.env_flags",
                "subprocess_env_scrub_enabled",
            ),
        ),
        Surface(
            "PROMETHEUS_SCRIPT_CAPS",
            "env-flags", "138",
            lambda: _has_attr(
                "prometheus.env_flags_v138", "script_cap",
            ),
        ),
        # ---- Task 2: settings ----
        Surface(
            "settings.autoDreamEnabled",
            "settings", "139",
            lambda: _has_attr(
                "prometheus.settings_v139", "auto_dream_enabled",
            ),
        ),
        Surface(
            "settings.availableModels",
            "settings", "139",
            lambda: _has_attr(
                "prometheus.settings_v139", "available_models",
            ),
        ),
        Surface(
            "settings.alwaysThinkingEnabled",
            "settings", "139",
            lambda: _has_attr(
                "prometheus.settings_v139",
                "always_thinking_enabled",
            ),
        ),
        Surface(
            "settings.showTurnDuration",
            "settings", "139",
            lambda: _has_attr(
                "prometheus.settings_v139", "show_turn_duration",
            ),
        ),
        Surface(
            "settings.terminalProgressBarEnabled",
            "settings", "139",
            lambda: _has_attr(
                "prometheus.settings_v139",
                "terminal_progress_bar_enabled",
            ),
        ),
        Surface(
            "settings.spinnerTipsEnabled",
            "settings", "139",
            lambda: _has_attrs(
                "prometheus.settings_v139",
                ("spinner_tips_enabled", "spinner_tips_override"),
            ),
        ),
        Surface(
            "settings.prefersReducedMotion",
            "settings", "139",
            lambda: _has_attr(
                "prometheus.settings_v139", "prefers_reduced_motion",
            ),
        ),
        Surface(
            "settings.feedbackSurveyRate",
            "settings", "139",
            lambda: _has_attr(
                "prometheus.settings_v139", "feedback_survey_rate",
            ),
        ),
        Surface(
            "settings.disableDeepLinkRegistration",
            "settings", "139",
            lambda: _has_attr(
                "prometheus.settings_v139", "deep_link_disabled",
            ),
        ),
        Surface(
            "settings.showThinkingSummaries",
            "settings", "139",
            lambda: _has_attr(
                "prometheus.settings_v139", "show_thinking_summaries",
            ),
        ),
        Surface(
            "settings.viewMode",
            "settings", "139",
            lambda: _has_attr(
                "prometheus.settings_v139", "view_mode",
            ),
        ),
        Surface(
            "settings.prUrlTemplate",
            "settings", "139",
            lambda: _has_attrs(
                "prometheus.settings_v139",
                ("pr_url_template", "render_pr_url"),
            ),
        ),
        Surface(
            "settings.skipWebFetchPreflight",
            "settings", "139",
            lambda: _has_attr(
                "prometheus.settings_v139",
                "skip_web_fetch_preflight",
            ),
        ),
        Surface(
            "settings.voice",
            "settings", "139",
            lambda: _has_attr(
                "prometheus.settings_v139", "voice_config",
            ),
        ),
        Surface(
            "settings.editorMode",
            "settings", "139",
            lambda: _has_attr(
                "prometheus.settings_v139", "editor_mode",
            ),
        ),
        Surface(
            "settings.autoConnectIde",
            "settings", "139",
            lambda: _has_attrs(
                "prometheus.settings_v139",
                ("auto_connect_ide", "auto_install_ide_extension"),
            ),
        ),
        Surface(
            "settings.defaultShell",
            "settings", "139",
            lambda: _has_attr(
                "prometheus.settings_v139", "default_shell",
            ),
        ),
        Surface(
            "settings.respectGitignore",
            "settings", "137",
            lambda: _has_attr(
                "prometheus.settings_schema", "respect_gitignore",
            ),
        ),
        Surface(
            "settings.includeGitInstructions",
            "settings", "137",
            lambda: _has_attr(
                "prometheus.settings_schema",
                "include_git_instructions",
            ),
        ),
        Surface(
            "settings.network.*",
            "settings", "137",
            lambda: _has_attrs(
                "prometheus.settings_schema",
                ("resolve_network_policy", "network_decision"),
            ),
        ),
        Surface(
            "settings.filesystem.*",
            "settings", "137",
            lambda: _has_attrs(
                "prometheus.settings_schema",
                (
                    "resolve_filesystem_policy",
                    "filesystem_decision",
                ),
            ),
        ),
        # ---- Task 3: slash commands ----
        Surface(
            "/schedule",
            "slash", "139",
            lambda: _has_attrs(
                "prometheus.scheduling",
                ("validate_cron", "make_routine", "write_routine"),
            ),
        ),
        Surface(
            "/fast",
            "slash", "136",
            lambda: _has_attrs(
                "prometheus.fast_mode",
                ("FastMode", "enable_fast_mode", "fast_mode_active"),
            ),
        ),
        # ---- Task 3: CLI flags ----
        Surface(
            "--agent",
            "cli", "139",
            lambda: _has_cli_flag("--agent"),
        ),
        Surface(
            "--init",
            "cli", "139",
            lambda: _has_cli_flag("--init"),
        ),
        Surface(
            "--init-only",
            "cli", "139",
            lambda: _has_cli_flag("--init-only"),
        ),
        Surface(
            "--plugin-dir",
            "cli", "139",
            lambda: _has_cli_flag("--plugin-dir"),
        ),
        Surface(
            "--plugin-url",
            "cli", "139",
            lambda: _has_cli_flag("--plugin-url"),
        ),
        Surface(
            "--include-hook-events",
            "cli", "139",
            lambda: _has_cli_flag("--include-hook-events"),
        ),
        Surface(
            "--no-chrome",
            "cli", "139",
            lambda: _has_cli_flag("--no-chrome"),
        ),
        Surface(
            "--allowedTools",
            "cli", "139",
            lambda: _has_cli_flag("--allowedTools"),
        ),
        Surface(
            "--disallowedTools",
            "cli", "139",
            lambda: _has_cli_flag("--disallowedTools"),
        ),
        Surface(
            "--fast",
            "cli", "138",
            lambda: _has_cli_flag("--fast"),
        ),
        # ---- Task 3: subcommands ----
        Surface(
            "prometheus agents",
            "subcommand", "136",
            lambda: _has_subcommand("agents"),
        ),
        Surface(
            "prometheus mcp",
            "subcommand", "136",
            lambda: _has_subcommand("mcp"),
        ),
        Surface(
            "prometheus forge",
            "subcommand", "136",
            lambda: _has_subcommand("forge"),
        ),
        Surface(
            "prometheus project",
            "subcommand", "136",
            lambda: _has_subcommand("project"),
        ),
        # ---- Task 4: bundled skills ----
        Surface(
            "/ghost (bundled)",
            "skill", "138",
            lambda: _has_bundled_aptitude("ghost"),
        ),
        Surface(
            "/ultraplan (bundled)",
            "skill", "138",
            lambda: _has_bundled_aptitude("ultraplan"),
        ),
        Surface(
            "/ultrareview (bundled)",
            "skill", "138",
            lambda: _has_bundled_aptitude("ultrareview"),
        ),
    ]


# ---------- audit ----------


@dataclass
class AuditReport:
    surfaces: list[Surface]
    results: list[tuple[Surface, bool, str]]

    @property
    def ok(self) -> bool:
        return all(ok for _s, ok, _d in self.results)

    @property
    def passed(self) -> int:
        return sum(1 for _s, ok, _d in self.results if ok)

    @property
    def failed(self) -> int:
        return sum(1 for _s, ok, _d in self.results if not ok)

    def failed_rows(self) -> list[tuple[Surface, str]]:
        return [
            (s, d) for s, ok, d in self.results if not ok
        ]


def run_audit(
    surfaces: Optional[list[Surface]] = None,
) -> AuditReport:
    """Round 140: execute every check. Returns a structured
    report; caller decides how to present."""
    rows = surfaces if surfaces is not None else matrix()
    results: list[tuple[Surface, bool, str]] = []
    for s in rows:
        try:
            ok, detail = s.check()
        except Exception as e:
            ok, detail = (False, f"check raised: {e}")
        results.append((s, ok, detail))
    return AuditReport(surfaces=rows, results=results)


def render_audit(report: AuditReport) -> str:
    """Round 140: aligned text rendering used by `/audit` and
    by the test failure messages."""
    by_cat: dict[str, list[tuple[Surface, bool, str]]] = {}
    for s, ok, detail in report.results:
        by_cat.setdefault(s.category, []).append((s, ok, detail))
    out: list[str] = []
    out.append(
        f"feature matrix: {report.passed}/{len(report.results)} surfaces verified"
    )
    out.append("")
    order = (
        "timeouts", "env-flags", "settings",
        "slash", "cli", "subcommand", "skill",
    )
    for cat in order:
        if cat not in by_cat:
            continue
        out.append(f"  [{cat}]")
        for s, ok, detail in by_cat[cat]:
            mark = "✓" if ok else "✗"
            shipped = f"r{s.shipped_in}"
            line = f"    {mark} {s.name:42s} {shipped:>5s}"
            if not ok:
                line += f"  — {detail}"
            out.append(line)
        out.append("")
    if report.failed:
        out.append(f"⚠ {report.failed} surface(s) failed verification")
    else:
        out.append("✓ every surface verified")
    return "\n".join(out)
