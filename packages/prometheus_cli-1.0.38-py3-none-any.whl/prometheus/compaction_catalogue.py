"""Round 150: compaction strategies catalogue.

Six active strategies that compact context across the 6
stages of the round-143-final pipeline. /compaction-strategies
shows them with triggers + thresholds.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class CompactionStrategy:
    name: str
    stage: int
    trigger: str
    threshold: str
    behaviour: str


COMPACTION_STRATEGIES: tuple[CompactionStrategy, ...] = (
    CompactionStrategy(
        name="tool-output truncation",
        stage=1,
        trigger="every tool result over the per-call cap",
        threshold="PROMETHEUS_BASH_MAX_OUTPUT_LENGTH (default 50 000)",
        behaviour=(
            "Drop chars beyond the cap; append "
            "`(truncated; N more chars)` marker."
        ),
    ),
    CompactionStrategy(
        name="bash output filter",
        stage=2,
        trigger="every bash result in compact mode",
        threshold="round-96 smart filter (regex over warn-noise)",
        behaviour=(
            "Strip pytest_asyncio warnings, progress dots, "
            "and other noise before persistence."
        ),
    ),
    CompactionStrategy(
        name="recent-bash trim",
        stage=3,
        trigger="active context > active threshold",
        threshold="round-96.1 fresh-bash window",
        behaviour=(
            "Replace older verbatim bash payloads with one-line "
            "summaries (keep last 1)."
        ),
    ),
    CompactionStrategy(
        name="cached microcompact",
        stage=4,
        trigger="provider cache active + tail beyond N messages",
        threshold="cache_boundary + target_tail_messages (20)",
        behaviour=(
            "Trim only the tail beyond the cache boundary, "
            "preserve the cached prefix byte-for-byte (round 144)."
        ),
    ),
    CompactionStrategy(
        name="auto-compact",
        stage=5,
        trigger="active tokens > autocompact threshold",
        threshold=(
            "PROMETHEUS_AUTOCOMPACT_PCT (default 80) of "
            "PROMETHEUS_AUTO_COMPACT_WINDOW or model context"
        ),
        behaviour=(
            "Summarize early turns into a single system "
            "message; keep last 20."
        ),
    ),
    CompactionStrategy(
        name="context collapse",
        stage=6,
        trigger=(
            "auto-compact insufficient (~90% window still full)"
        ),
        threshold="PROMETHEUS_CONTEXT_COLLAPSE=1 (opt-in)",
        behaviour=(
            "Archive entire conversation chunks to disk; "
            "inject placeholder with archive id (round 143)."
        ),
    ),
)


def render_compaction_strategies() -> str:
    lines = ["compaction strategies (6 stages):"]
    for s in COMPACTION_STRATEGIES:
        lines.append("")
        lines.append(f"  {s.stage}. {s.name}")
        lines.append(f"      trigger:    {s.trigger}")
        lines.append(f"      threshold:  {s.threshold}")
        lines.append(f"      behaviour:  {s.behaviour}")
    return "\n".join(lines)


# Round 181: framework-name aliases. The arXiv "Dive into Claude Code"
# paper names a 5-layer pipeline using different labels than ours.
# Both naming conventions describe the same observed behaviour, so we
# expose a translation table for users coming from CC docs.
ARXIV_NAME_ALIASES: dict[str, str] = {
    # arXiv name (left)         -> Prometheus stage name (right)
    "Microcompact":              "cached microcompact",
    "History Snip":              "recent-bash trim",
    "Session Memory":            "auto-compact",  # rolling summary on fire
    "AutoCompact":               "auto-compact",
    "Context Collapse":          "context collapse",
}


def resolve_arxiv_stage(name: str) -> CompactionStrategy | None:
    """Resolve an arXiv-paper stage label to the local CompactionStrategy.

    Useful when a user reading CC's docs asks `/compaction-strategies
    Microcompact`. Returns None if the name is unknown."""
    target = ARXIV_NAME_ALIASES.get(name)
    if target is None:
        return None
    for s in COMPACTION_STRATEGIES:
        if s.name == target:
            return s
    return None
