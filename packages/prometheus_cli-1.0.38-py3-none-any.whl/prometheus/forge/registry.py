"""Round 100: installed-Forge-Kit registry.

Forge Kits live under one of two roots:

  * project: `<workdir>/.prometheus/forges/<name>/`
  * user:    `~/.prometheus/forges/<name>/`

Each kit is a directory with at minimum a `forge.json` at the
root. Other contents (aptitudes/, blades/, cohorts/, scripts/) are
referenced by the manifest.

The registry tracks ACTIVATION state in a sidecar file:

    <root>/.activation.json
    {
      "active": ["python-dev-kit", "security-kit"],
      "installed_at": {"python-dev-kit": "2026-05-07T..."}
    }

Activation mounts the kit's components into PrometheUS for the
duration of the session. Deactivation removes them — but does
NOT delete the on-disk kit directory.
"""
from __future__ import annotations

import json
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from prometheus.forge.manifest import (
    ForgeManifest,
    load_forge_manifest_file,
)


@dataclass
class InstalledKit:
    """One installed Forge Kit on disk + its activation state."""
    name: str
    root: Path                                # forge install dir
    data_dir: Path                            # writable data dir
    manifest: ForgeManifest
    active: bool = False
    installed_at: str = ""                    # ISO 8601 timestamp
    source: str = "user"                      # `project` | `user`

    @property
    def display_name(self) -> str:
        return self.manifest.display_name


def _now_iso() -> str:
    import datetime as _dt
    return _dt.datetime.now(_dt.timezone.utc).isoformat()


def _read_activation_state(root: Path) -> dict:
    p = root / ".activation.json"
    if not p.exists() or not p.is_file():
        return {"active": [], "installed_at": {}}
    try:
        data = json.loads(p.read_text(encoding="utf-8", errors="replace"))
        if not isinstance(data, dict):
            return {"active": [], "installed_at": {}}
        data.setdefault("active", [])
        data.setdefault("installed_at", {})
        return data
    except (OSError, ValueError):
        return {"active": [], "installed_at": {}}


def _write_activation_state(root: Path, data: dict) -> None:
    root.mkdir(parents=True, exist_ok=True)
    p = root / ".activation.json"
    try:
        p.write_text(
            json.dumps(data, indent=2, default=str),
            encoding="utf-8",
        )
    except OSError:
        pass


@dataclass
class ForgeRegistry:
    """Tracks installed Forge Kits across project + user scopes."""
    workdir: Path
    project_root: Path = field(init=False)
    user_root: Path = field(init=False)

    def __post_init__(self) -> None:
        self.project_root = self.workdir / ".prometheus" / "forges"
        self.user_root = Path.home() / ".prometheus" / "forges"

    # ---- discovery ----

    def installed(self) -> list[InstalledKit]:
        """Walk both roots and return every kit with a valid
        forge.json. Kits in the project scope take precedence
        over user scope when names collide."""
        out: list[InstalledKit] = []
        seen: set[str] = set()
        for root, source in (
            (self.project_root, "project"),
            (self.user_root, "user"),
        ):
            if not root.exists() or not root.is_dir():
                continue
            state = _read_activation_state(root)
            try:
                for kit_dir in sorted(root.iterdir()):
                    if not kit_dir.is_dir() or kit_dir.name.startswith("."):
                        continue
                    manifest = load_forge_manifest_file(
                        kit_dir / "forge.json"
                    )
                    if manifest is None:
                        continue
                    if manifest.name in seen:
                        continue
                    seen.add(manifest.name)
                    data_dir = kit_dir / "_data"
                    out.append(InstalledKit(
                        name=manifest.name,
                        root=kit_dir,
                        data_dir=data_dir,
                        manifest=manifest,
                        active=manifest.name in (state.get("active") or []),
                        installed_at=str(
                            (state.get("installed_at") or {}).get(
                                manifest.name, ""
                            )
                        ),
                        source=source,
                    ))
            except OSError:
                continue
        return out

    def find(self, name: str) -> Optional[InstalledKit]:
        for k in self.installed():
            if k.name == name:
                return k
        return None

    # ---- install / uninstall ----

    def install_from_path(
        self,
        source_path: Path,
        *,
        scope: str = "user",
    ) -> tuple[Optional[InstalledKit], str]:
        """Copy a Forge Kit from a local directory into the
        configured scope. Returns `(kit_or_none, message)`."""
        if not source_path.exists() or not source_path.is_dir():
            return None, f"source not a directory: {source_path}"
        manifest = load_forge_manifest_file(source_path / "forge.json")
        if manifest is None:
            return None, f"no valid forge.json in {source_path}"
        target_root = (
            self.project_root if scope == "project" else self.user_root
        )
        target_dir = target_root / manifest.name
        if target_dir.exists():
            return None, (
                f"kit {manifest.name!r} already installed at {target_dir}; "
                f"use /forge update or remove it first"
            )
        target_root.mkdir(parents=True, exist_ok=True)
        try:
            shutil.copytree(source_path, target_dir)
        except OSError as e:
            return None, f"copy failed: {e}"
        # Stamp installed_at.
        state = _read_activation_state(target_root)
        state.setdefault("installed_at", {})[manifest.name] = _now_iso()
        _write_activation_state(target_root, state)
        return self.find(manifest.name), (
            f"installed {manifest.display_name} → {target_dir}"
        )

    def uninstall(self, name: str) -> tuple[bool, str]:
        kit = self.find(name)
        if kit is None:
            return False, f"no installed kit named {name!r}"
        try:
            shutil.rmtree(kit.root)
        except OSError as e:
            return False, f"remove failed: {e}"
        # Drop activation entry.
        for root in (self.project_root, self.user_root):
            state = _read_activation_state(root)
            active = state.get("active") or []
            if name in active:
                active = [a for a in active if a != name]
                state["active"] = active
            installed_at = state.get("installed_at") or {}
            if name in installed_at:
                installed_at.pop(name, None)
                state["installed_at"] = installed_at
            _write_activation_state(root, state)
        return True, f"uninstalled {name!r}"

    # ---- activation ----

    def activate(self, name: str) -> tuple[bool, str]:
        kit = self.find(name)
        if kit is None:
            return False, f"no installed kit named {name!r}"
        root = (
            self.project_root if kit.source == "project"
            else self.user_root
        )
        state = _read_activation_state(root)
        active = state.get("active") or []
        if name not in active:
            active.append(name)
            state["active"] = active
            _write_activation_state(root, state)
        return True, f"activated {kit.display_name}"

    def deactivate(self, name: str) -> tuple[bool, str]:
        kit = self.find(name)
        if kit is None:
            return False, f"no installed kit named {name!r}"
        root = (
            self.project_root if kit.source == "project"
            else self.user_root
        )
        state = _read_activation_state(root)
        active = state.get("active") or []
        if name in active:
            active = [a for a in active if a != name]
            state["active"] = active
            _write_activation_state(root, state)
        return True, f"deactivated {name}"

    def active_kits(self) -> list[InstalledKit]:
        return [k for k in self.installed() if k.active]
