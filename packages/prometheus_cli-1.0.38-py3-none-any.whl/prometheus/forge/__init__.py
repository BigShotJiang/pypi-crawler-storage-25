"""Round 100 (Phase 3): Forge Kits and the Foundry marketplace.

A Forge Kit is a single installable bundle that combines any of:
  * Aptitudes
  * Blades (custom slash commands)
  * Cohorts (subagent definitions)
  * Sentinel Hooks
  * MCP server connections
  * LSP server configs
  * Settings overrides

A Foundry is a marketplace catalog (foundry.json) listing many
Forge Kits. Anyone can publish one — the system is decentralized.

This package contains:
  * `manifest`      — forge.json + foundry.json parsers
  * `registry`      — installed-kit registry (read/write)
  * `install`       — install / activate / deactivate
  * `mcp`           — MCP server registry and lifecycle stubs
  * `foundry`       — marketplace catalog + search
"""
from prometheus.forge.manifest import (
    ForgeManifest,
    FoundryManifest,
    FoundryKitEntry,
    parse_forge_manifest,
    parse_foundry_manifest,
)
from prometheus.forge.registry import (
    ForgeRegistry,
    InstalledKit,
)
from prometheus.forge.mcp import (
    MCPServer,
    MCPServerRegistry,
    discover_mcp_from_forge_kits,
)

__all__ = [
    "ForgeManifest",
    "FoundryManifest",
    "FoundryKitEntry",
    "parse_forge_manifest",
    "parse_foundry_manifest",
    "ForgeRegistry",
    "InstalledKit",
    "MCPServer",
    "MCPServerRegistry",
    "discover_mcp_from_forge_kits",
]
