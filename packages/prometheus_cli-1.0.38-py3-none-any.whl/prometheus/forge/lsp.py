"""Round 102 (Phase 5): LSP integration — Language Server Protocol.

PrometheUS integrates with LSP servers for real-time code
intelligence: instant diagnostics after each edit, go-to-
definition, find references, hover info. Round 102 establishes
the REGISTRY surface — discovery, parsing, lifecycle accounting.
The actual LSP transport (JSON-RPC framing, server lifecycle,
diagnostic streaming) is round-103 polish.

Server config shape (in `forge.json` or `settings.json`):

    {
      "lspServers": {
        "python": {
          "command": "pyright-langserver",
          "args": ["--stdio"],
          "extensionToLanguage": {
            ".py": "python", ".pyi": "python"
          }
        },
        "typescript": {
          "command": "typescript-language-server",
          "args": ["--stdio"]
        }
      }
    }
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


@dataclass
class LSPServer:
    name: str
    command: str = ""
    args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)
    extension_to_language: dict[str, str] = field(default_factory=dict)
    source: str = "user"
    source_path: str = ""

    running: bool = False
    pid: Optional[int] = None
    diagnostics: list[dict[str, Any]] = field(default_factory=list)


def parse_lsp_entry(
    name: str, raw: dict, *, source: str, source_path: str,
) -> Optional[LSPServer]:
    if not isinstance(raw, dict):
        return None
    cmd = str(raw.get("command", "") or "")
    if not cmd:
        return None
    args = [str(x) for x in (raw.get("args") or []) if x is not None]
    env = {
        str(k): str(v) for k, v in (raw.get("env") or {}).items()
    }
    ext_map = {
        str(k): str(v)
        for k, v in (
            raw.get("extensionToLanguage")
            or raw.get("extension_to_language")
            or {}
        ).items()
    }
    return LSPServer(
        name=str(name).strip(),
        command=cmd,
        args=args,
        env=env,
        extension_to_language=ext_map,
        source=source,
        source_path=source_path,
    )


@dataclass
class LSPServerRegistry:
    servers: list[LSPServer] = field(default_factory=list)

    def add(self, s: LSPServer) -> None:
        # First-registration-wins — same precedence as MCPRegistry.
        if any(existing.name == s.name for existing in self.servers):
            return
        self.servers.append(s)

    def find(self, name: str) -> Optional[LSPServer]:
        for s in self.servers:
            if s.name == name:
                return s
        return None

    def names(self) -> list[str]:
        return [s.name for s in self.servers]

    def language_for_path(self, path: Path) -> Optional[str]:
        """Return the LSP language id for a file path, if any
        configured server claims its extension."""
        ext = path.suffix.lower()
        for s in self.servers:
            lang = s.extension_to_language.get(ext)
            if lang:
                return lang
        return None

    def from_settings_json(
        self, path: Path, *, source: str = "settings",
    ) -> int:
        if not path.exists() or not path.is_file():
            return 0
        try:
            data = json.loads(
                path.read_text(encoding="utf-8", errors="replace")
            )
        except (OSError, ValueError):
            return 0
        servers = (
            data.get("lspServers") or data.get("lsp_servers") or {}
        )
        n = 0
        for name, raw in servers.items():
            entry = parse_lsp_entry(
                name, raw, source=source, source_path=str(path),
            )
            if entry:
                self.add(entry)
                n += 1
        return n


def discover_lsp_from_forge_kits(workdir: Path) -> LSPServerRegistry:
    """Walk active Forge Kits + project/user settings for
    LSP servers. Project precedence over user, settings precedence
    over forge."""
    from prometheus.forge.registry import ForgeRegistry
    reg = LSPServerRegistry()
    reg.from_settings_json(
        workdir / ".prometheus" / "settings.json", source="project",
    )
    reg.from_settings_json(
        Path.home() / ".prometheus" / "settings.json", source="user",
    )
    forge = ForgeRegistry(workdir)
    for kit in forge.active_kits():
        for name, raw in kit.manifest.lsp_servers.items():
            entry = parse_lsp_entry(
                name, raw,
                source=f"forge:{kit.name}",
                source_path=str(kit.root / "forge.json"),
            )
            if entry:
                reg.add(entry)
    return reg
