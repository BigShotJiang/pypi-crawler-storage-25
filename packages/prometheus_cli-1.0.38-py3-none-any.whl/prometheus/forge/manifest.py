"""Round 100: Forge Kit and Foundry manifest parsers.

forge.json schema (per Phase-3 spec):

    {
      "name": "python-dev-kit",
      "version": "1.0.0",
      "description": "Complete Python development toolkit",
      "author": "Acme Corp",
      "license": "MIT",
      "aptitudes": ["python-testing", "type-checking"],
      "blades": ["review", "deploy"],
      "cohorts": ["code-reviewer", "security-auditor"],
      "hooks": {
        "PostToolUse": [
          {
            "matcher": "Write|Edit",
            "hooks": [{"type": "command", "command": "${FORGE_ROOT}/scripts/format-code.sh"}]
          }
        ]
      },
      "mcpServers": {
        "postgres": {
          "command": "npx",
          "args": ["-y", "@anthropic/mcp-server-postgres"]
        }
      },
      "lspServers": {
        "python": {"command": "pyright-langserver", "args": ["--stdio"]}
      },
      "settings": {"permission_mode": "acceptEdits"}
    }

foundry.json schema:

    {
      "name": "Acme Corp Foundry",
      "description": "Internal tools for Acme engineering",
      "maintainer": "acme-eng@example.com",
      "kits": [
        {
          "name": "python-dev-kit",
          "description": "...",
          "version": "1.0.0",
          "source": "./kits/python-dev-kit",
          "author": "Acme Corp",
          "tags": ["python", "testing"]
        }
      ]
    }

`${FORGE_ROOT}` and `${FORGE_DATA}` are expanded at activation time
to the kit's install dir and writable data dir respectively.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


# ---------- forge.json ----------


@dataclass
class ForgeManifest:
    """Parsed forge.json. Every list defaults to empty so callers
    can iterate without None-checks. Path values are stored as
    strings — they get resolved to absolute paths at activation
    time when ${FORGE_ROOT} is known."""
    name: str
    version: str = "0.0.0"
    description: str = ""
    author: str = ""
    license: str = ""
    aptitudes: list[str] = field(default_factory=list)
    blades: list[str] = field(default_factory=list)
    cohorts: list[str] = field(default_factory=list)
    hooks: dict[str, Any] = field(default_factory=dict)
    mcp_servers: dict[str, dict[str, Any]] = field(default_factory=dict)
    lsp_servers: dict[str, dict[str, Any]] = field(default_factory=dict)
    settings: dict[str, Any] = field(default_factory=dict)
    raw: dict[str, Any] = field(default_factory=dict)

    @property
    def display_name(self) -> str:
        return f"{self.name}@{self.version}" if self.version else self.name


def parse_forge_manifest(raw: dict[str, Any]) -> Optional[ForgeManifest]:
    """Validate + parse a forge.json dict. Returns None when the
    manifest is missing the required `name` field."""
    if not isinstance(raw, dict):
        return None
    name = raw.get("name")
    if not isinstance(name, str) or not name.strip():
        return None
    return ForgeManifest(
        name=str(name).strip(),
        version=str(raw.get("version", "0.0.0")),
        description=str(raw.get("description", "")),
        author=str(raw.get("author", "")),
        license=str(raw.get("license", "")),
        aptitudes=[str(x) for x in (raw.get("aptitudes") or []) if x],
        blades=[str(x) for x in (raw.get("blades") or []) if x],
        cohorts=[str(x) for x in (raw.get("cohorts") or []) if x],
        hooks=dict(raw.get("hooks") or {}),
        mcp_servers={
            str(k): dict(v) for k, v in
            (raw.get("mcpServers") or raw.get("mcp_servers") or {}).items()
            if isinstance(v, dict)
        },
        lsp_servers={
            str(k): dict(v) for k, v in
            (raw.get("lspServers") or raw.get("lsp_servers") or {}).items()
            if isinstance(v, dict)
        },
        settings=dict(raw.get("settings") or {}),
        raw=raw,
    )


def load_forge_manifest_file(path: Path) -> Optional[ForgeManifest]:
    """Read forge.json from disk and parse it. Returns None on
    missing file, malformed JSON, or invalid manifest."""
    if not path.exists() or not path.is_file():
        return None
    try:
        raw = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except (OSError, ValueError):
        return None
    return parse_forge_manifest(raw)


# ---------- ${FORGE_ROOT} / ${FORGE_DATA} expansion ----------


def expand_forge_vars(
    text: str,
    *,
    forge_root: Path,
    forge_data: Path,
) -> str:
    """Round 100: replace ${FORGE_ROOT} and ${FORGE_DATA} with the
    actual paths. Both keep POSIX-style separators in the output
    so commands work cross-platform on POSIX shells. On Windows,
    the resulting path is still valid for native exec via the
    same string substitution."""
    out = text
    out = out.replace("${FORGE_ROOT}", str(forge_root))
    out = out.replace("${FORGE_DATA}", str(forge_data))
    # Also accept ${forge_root} (lowercase) for tolerance.
    out = out.replace("${forge_root}", str(forge_root))
    out = out.replace("${forge_data}", str(forge_data))
    return out


# ---------- foundry.json ----------


@dataclass
class FoundryKitEntry:
    """One kit entry inside a foundry.json catalog."""
    name: str
    description: str = ""
    version: str = "0.0.0"
    source: str = ""           # local path, git url, or http url
    author: str = ""
    tags: list[str] = field(default_factory=list)


@dataclass
class FoundryManifest:
    """Parsed foundry.json — a marketplace catalog."""
    name: str
    description: str = ""
    maintainer: str = ""
    kits: list[FoundryKitEntry] = field(default_factory=list)
    source_url: str = ""        # where the foundry was registered from
    raw: dict[str, Any] = field(default_factory=dict)

    def search(self, query: str) -> list[FoundryKitEntry]:
        """Case-insensitive substring match across name +
        description + tags."""
        if not query:
            return list(self.kits)
        q = query.lower()
        out: list[FoundryKitEntry] = []
        for k in self.kits:
            if (
                q in k.name.lower()
                or q in k.description.lower()
                or any(q in t.lower() for t in k.tags)
            ):
                out.append(k)
        return out


def parse_foundry_manifest(
    raw: dict[str, Any], *, source_url: str = "",
) -> Optional[FoundryManifest]:
    if not isinstance(raw, dict):
        return None
    name = raw.get("name")
    if not isinstance(name, str) or not name.strip():
        return None
    kits: list[FoundryKitEntry] = []
    for k in (raw.get("kits") or []):
        if not isinstance(k, dict):
            continue
        kn = k.get("name")
        if not isinstance(kn, str) or not kn.strip():
            continue
        kits.append(FoundryKitEntry(
            name=kn.strip(),
            description=str(k.get("description", "")),
            version=str(k.get("version", "0.0.0")),
            source=str(k.get("source", "")),
            author=str(k.get("author", "")),
            tags=[str(t) for t in (k.get("tags") or []) if t],
        ))
    return FoundryManifest(
        name=str(name).strip(),
        description=str(raw.get("description", "")),
        maintainer=str(raw.get("maintainer", "")),
        kits=kits,
        source_url=source_url,
        raw=raw,
    )


def load_foundry_manifest_file(
    path: Path, *, source_url: str = "",
) -> Optional[FoundryManifest]:
    if not path.exists() or not path.is_file():
        return None
    try:
        raw = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except (OSError, ValueError):
        return None
    return parse_foundry_manifest(raw, source_url=source_url)
