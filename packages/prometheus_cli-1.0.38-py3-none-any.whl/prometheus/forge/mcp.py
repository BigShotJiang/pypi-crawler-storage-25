"""Round 100: MCP server registry (Forge Connections).

PrometheUS connects to external tools via the Model Context
Protocol — an open standard where each tool server is a separate
process that PrometheUS talks to over stdio (or HTTP/SSE for
remote servers).

This round establishes the REGISTRY surface — discovery, parsing,
lifecycle accounting. The actual MCP transport (spawning servers,
JSON-RPC framing, tool-list calls) lands in round 102 to keep
round-100 scope tight. The registry interface is stable so the
round-102 implementation slots in without breaking anything that
reads it now.

Server config shape (in `forge.json` or `settings.json`):

    {
      "mcpServers": {
        "postgres": {
          "command": "npx",
          "args": ["-y", "@anthropic/mcp-server-postgres"],
          "env": {"DATABASE_URL": "${env:POSTGRES_URL}"}
        },
        "browser": {
          "command": "npx",
          "args": ["@anthropic/mcp-server-puppeteer"]
        }
      }
    }
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


# ---------- env-var expansion ----------


_ENV_VAR_RE = re.compile(r"\$\{env:([A-Za-z_][A-Za-z0-9_]*)\}")


def _expand_env(value: Any) -> Any:
    """Round 100: expand `${env:VAR_NAME}` references in strings.
    Matches Claude Code's settings.json convention. Only env-var
    references — does NOT expand `${FORGE_ROOT}` (that happens at
    activation time, see manifest.expand_forge_vars)."""
    if isinstance(value, str):
        def _sub(m):
            return os.environ.get(m.group(1), "")
        return _ENV_VAR_RE.sub(_sub, value)
    if isinstance(value, dict):
        return {k: _expand_env(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_expand_env(v) for v in value]
    return value


# ---------- MCPServer record ----------


@dataclass
class MCPServer:
    """One configured MCP server.

    `transport` is `stdio` (default) or `http`. `running` flips
    when the round-102 lifecycle code spawns the server. `tools`
    populates after the server's tool-list response."""
    name: str
    command: str = ""
    args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)
    transport: str = "stdio"             # `stdio` | `http` | `sse`
    url: str = ""                        # for http/sse transports
    source: str = "user"                 # `forge:<kit>` / `project` / `user`
    source_path: str = ""

    running: bool = False
    pid: Optional[int] = None
    tools: list[str] = field(default_factory=list)
    last_error: str = ""

    @property
    def display_name(self) -> str:
        return f"{self.source}/{self.name}" if self.source else self.name


def parse_mcp_entry(name: str, raw: dict, *, source: str, source_path: str) -> Optional[MCPServer]:
    """Parse one entry from `mcpServers: {name: {...}}`. Returns
    None on malformed config."""
    if not isinstance(raw, dict):
        return None
    transport = str(raw.get("transport", "stdio") or "stdio").lower()
    cmd = str(raw.get("command", "") or "")
    url = str(raw.get("url", "") or "")
    if transport == "stdio" and not cmd:
        return None
    if transport in ("http", "sse") and not url:
        return None
    args = [str(x) for x in (raw.get("args") or []) if x is not None]
    env_raw = raw.get("env") or {}
    env = {
        str(k): str(v) for k, v in env_raw.items()
        if isinstance(env_raw, dict)
    }
    # Expand ${env:VAR} now so the registry stores resolved values.
    env = {k: _expand_env(v) for k, v in env.items()}
    return MCPServer(
        name=str(name).strip(),
        command=_expand_env(cmd),
        args=[_expand_env(a) for a in args],
        env=env,
        transport=transport,
        url=_expand_env(url),
        source=source,
        source_path=source_path,
    )


# ---------- registry ----------


@dataclass
class MCPServerRegistry:
    """In-memory pool of MCP servers known to this session.

    Round-100 scope: discovery + accounting. Round-102 will add
    `start()`, `stop()`, `list_tools()`, and tool-call dispatch."""
    servers: list[MCPServer] = field(default_factory=list)

    def add(self, s: MCPServer) -> None:
        # Dedupe by name — first registration wins (matches the
        # Forge Kit precedence: project > user > forge).
        if any(existing.name == s.name for existing in self.servers):
            return
        self.servers.append(s)

    def find(self, name: str) -> Optional[MCPServer]:
        for s in self.servers:
            if s.name == name:
                return s
        return None

    def names(self) -> list[str]:
        return [s.name for s in self.servers]

    def from_settings_json(
        self, path: Path, *, source: str = "settings",
    ) -> int:
        """Load mcpServers from a settings.json. Returns count added."""
        if not path.exists() or not path.is_file():
            return 0
        try:
            data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
        except (OSError, ValueError):
            return 0
        servers = (
            data.get("mcpServers") or data.get("mcp_servers") or {}
        )
        n = 0
        for name, raw in servers.items():
            entry = parse_mcp_entry(
                name, raw, source=source, source_path=str(path),
            )
            if entry:
                self.add(entry)
                n += 1
        return n


# ---------- Forge Kit MCP discovery ----------


# Round 116: opt-in MCP tool search via proxy/gateway. When
# `ENABLE_TOOL_SEARCH` is set, the registry will report
# tool_reference blocks that the host can resolve to remote
# MCP tools alongside local ones. This is an env-flag opt-in
# because tool search adds latency on every tool-list request.
def tool_search_enabled() -> bool:
    import os as _os
    return _os.environ.get(
        "PROMETHEUS_ENABLE_MCP_TOOL_SEARCH",
        _os.environ.get("ENABLE_TOOL_SEARCH", ""),
    ).strip().lower() in ("1", "true", "yes", "on")


@dataclass
class MCPToolReference:
    """A discovered remote tool surfaced via MCP tool search.
    Tools surfaced this way appear in the registry alongside
    local servers but are dispatched via the gateway."""
    server_name: str        # gateway / proxy name
    tool_name: str          # remote tool's canonical name
    description: str = ""
    schema: Optional[dict] = None
    source: str = "mcp-search"


def discover_tool_references(
    registry: MCPServerRegistry,
) -> list[MCPToolReference]:
    """Round 116: ask configured gateway/proxy servers for their
    tool catalogue. Round-116 scope is the discovery API; the
    actual `tools/list` MCP request lands when the transport
    layer goes live in a follow-up patch.

    Returns an empty list when tool search is disabled or no
    gateway servers are configured."""
    if not tool_search_enabled():
        return []
    out: list[MCPToolReference] = []
    for s in registry.servers:
        # Heuristic: a server is treated as a gateway when its
        # `args` mention `gateway` or `proxy`. The host can
        # extend this with an explicit field in a polish round.
        is_gateway = (
            "gateway" in (s.command + " " + " ".join(s.args)).lower()
            or "proxy" in (s.command + " " + " ".join(s.args)).lower()
        )
        if not is_gateway:
            continue
        # Stub: in round-116 we surface that the gateway is known
        # but don't yet round-trip its tool list. The reference
        # carries enough context for the agent to decide whether
        # to route through it.
        out.append(MCPToolReference(
            server_name=s.name,
            tool_name=f"{s.name}.*",
            description=f"remote MCP tools via {s.name} gateway",
            schema=None,
        ))
    return out


def discover_mcp_from_forge_kits(
    workdir: Path,
) -> MCPServerRegistry:
    """Walk the active Forge Kits + project/user settings.json
    and build an MCPServerRegistry. Active kit precedence:
    project-scope kits > user-scope kits > settings.json (project >
    user)."""
    from prometheus.forge.registry import ForgeRegistry
    reg = MCPServerRegistry()
    # Project + user settings.json (highest priority).
    reg.from_settings_json(
        workdir / ".prometheus" / "settings.json", source="project",
    )
    reg.from_settings_json(
        Path.home() / ".prometheus" / "settings.json", source="user",
    )
    # Active forge kits (lowest priority — settings overrides kits).
    forge = ForgeRegistry(workdir)
    for kit in forge.active_kits():
        for name, raw in kit.manifest.mcp_servers.items():
            entry = parse_mcp_entry(
                name, raw,
                source=f"forge:{kit.name}",
                source_path=str(kit.root / "forge.json"),
            )
            if entry:
                reg.add(entry)
    return reg
