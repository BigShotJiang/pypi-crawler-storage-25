"""Round 100: Foundry marketplace catalog.

A Foundry is a JSON catalog (foundry.json) listing many Forge
Kits. PrometheUS users register Foundries by URL or local path,
search across them, and install kits by name.

Registered Foundries live in `~/.prometheus/foundries.json`:

    {
      "foundries": [
        {"name": "Acme Internal", "url": "https://acme.example.com/foundry.json"},
        {"name": "Personal", "url": "/home/me/foundry.json"}
      ]
    }

The Foundry JSON itself is fetched on demand (network for HTTP,
filesystem for local paths). Round 100 supports local paths
fully and HTTP/git fetching as a stub — http fetch lands in
round 102 alongside the MCP transport work.
"""
from __future__ import annotations

import json
import shutil
import urllib.parse
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from prometheus.forge.manifest import (
    FoundryManifest,
    parse_foundry_manifest,
    load_foundry_manifest_file,
)


def _foundries_index_path() -> Path:
    return Path.home() / ".prometheus" / "foundries.json"


@dataclass
class RegisteredFoundry:
    name: str
    url: str
    enabled: bool = True


@dataclass
class FoundryIndex:
    """The user's `~/.prometheus/foundries.json` — a list of
    registered Foundry sources."""
    foundries: list[RegisteredFoundry] = field(default_factory=list)

    @classmethod
    def load(cls) -> "FoundryIndex":
        p = _foundries_index_path()
        if not p.exists() or not p.is_file():
            return cls()
        try:
            raw = json.loads(p.read_text(encoding="utf-8", errors="replace"))
        except (OSError, ValueError):
            return cls()
        out = cls()
        for entry in (raw.get("foundries") or []):
            if not isinstance(entry, dict):
                continue
            name = str(entry.get("name", "")).strip()
            url = str(entry.get("url", "")).strip()
            if not (name and url):
                continue
            out.foundries.append(RegisteredFoundry(
                name=name, url=url,
                enabled=bool(entry.get("enabled", True)),
            ))
        return out

    def save(self) -> None:
        p = _foundries_index_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        body = {
            "foundries": [
                {
                    "name": f.name, "url": f.url, "enabled": f.enabled,
                }
                for f in self.foundries
            ]
        }
        try:
            p.write_text(
                json.dumps(body, indent=2),
                encoding="utf-8",
            )
        except OSError:
            pass

    def add(self, name: str, url: str) -> tuple[bool, str]:
        # Dedupe by url — re-add same url is a no-op.
        for f in self.foundries:
            if f.url == url:
                return False, f"foundry already registered: {url}"
        self.foundries.append(RegisteredFoundry(name=name, url=url))
        self.save()
        return True, f"registered {name} ({url})"

    def remove(self, name_or_url: str) -> tuple[bool, str]:
        before = len(self.foundries)
        self.foundries = [
            f for f in self.foundries
            if f.name != name_or_url and f.url != name_or_url
        ]
        if len(self.foundries) == before:
            return False, f"no foundry named {name_or_url!r}"
        self.save()
        return True, f"removed {name_or_url}"


# ---------- fetching foundry manifests ----------


def fetch_foundry(url: str) -> Optional[FoundryManifest]:
    """Resolve a Foundry source. Local paths read directly; URLs
    fetch via httpx (if installed). Returns None on failure —
    callers report the user-facing error themselves so this
    function stays side-effect-free."""
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme in ("http", "https"):
        return _fetch_http(url)
    # Treat as local path. Strip `file://` prefix if present.
    if parsed.scheme == "file":
        url = parsed.path
    p = Path(url)
    if p.is_dir():
        # Convention: foundry.json lives at the directory root.
        p = p / "foundry.json"
    if not p.exists() or not p.is_file():
        return None
    return load_foundry_manifest_file(p, source_url=str(p))


def _fetch_http(url: str) -> Optional[FoundryManifest]:
    """Best-effort HTTP fetch. Soft-fails when httpx isn't installed
    so a user without optional deps still sees `/foundry list` etc."""
    try:
        import httpx  # type: ignore
    except ImportError:
        return None
    try:
        # Round 179: foundry index fetches respect corporate proxy +
        # custom CA via sync_net_kwargs.
        from prometheus.net import sync_net_kwargs
        with httpx.Client(**sync_net_kwargs(timeout=15.0)) as c:
            r = c.get(url)
            r.raise_for_status()
            data = r.json()
    except Exception:
        return None
    return parse_foundry_manifest(data, source_url=url)


# ---------- search across all foundries ----------


def search_all(query: str) -> list[tuple[FoundryManifest, list]]:
    """Search every registered, enabled Foundry. Returns a list of
    `(foundry, matching_kit_entries)` tuples — empty matches are
    omitted. Round-100 scope: read foundries the user has already
    registered. Discovery + auto-add is round-103 polish."""
    out: list[tuple[FoundryManifest, list]] = []
    index = FoundryIndex.load()
    for f in index.foundries:
        if not f.enabled:
            continue
        manifest = fetch_foundry(f.url)
        if manifest is None:
            continue
        matches = manifest.search(query)
        if matches:
            out.append((manifest, matches))
    return out
