"""Round 147-final-v3: MCP-provided aptitudes.

When `PROMETHEUS_MCP_SKILLS=1`, every connected MCP server
is queried for `skills/list`; each returned skill is
converted to a synthesized `Aptitude` record and merged into
the round-128 bundled-aptitudes catalogue.

Pure data-layer. The host's aptitude resolver pulls from
`mcp_provided_skills(servers)` after starting MCP servers.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any


_TRUTHY = ("1", "true", "yes", "on")


def mcp_skills_enabled() -> bool:
    return os.environ.get(
        "PROMETHEUS_MCP_SKILLS", "",
    ).strip().lower() in _TRUTHY


@dataclass
class McpSkill:
    name: str
    purpose: str
    triggers: tuple[str, ...]
    body: str
    server: str


async def fetch_skills_from(
    server_name: str, server: Any,
) -> list[McpSkill]:
    """Round 147-final-v3: ask one MCP server for its skills.
    Servers that don't expose the endpoint return [] — not
    every MCP implementation has it."""
    if not mcp_skills_enabled() or server is None:
        return []
    try:
        resp = await server.call("skills/list", {})
    except Exception:
        return []
    if not isinstance(resp, dict):
        return []
    rows = resp.get("skills", []) or []
    out: list[McpSkill] = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        name = str(r.get("name") or "").strip()
        if not name:
            continue
        triggers = r.get("triggers", []) or []
        if isinstance(triggers, str):
            triggers = (triggers,)
        else:
            triggers = tuple(str(t) for t in triggers if t)
        out.append(McpSkill(
            name=name,
            purpose=str(r.get("purpose") or ""),
            triggers=triggers,
            body=str(r.get("body") or r.get("description") or ""),
            server=server_name,
        ))
    return out


def to_aptitude_record(skill: McpSkill) -> dict[str, Any]:
    """Round 147-final-v3: convert to the dict shape
    `prometheus.agent.bundled_skills` consumes when merging
    new aptitudes into the catalogue."""
    return {
        "name": skill.name,
        "purpose": skill.purpose,
        "triggers": skill.triggers,
        "body": skill.body,
        "source": f"mcp:{skill.server}",
    }
