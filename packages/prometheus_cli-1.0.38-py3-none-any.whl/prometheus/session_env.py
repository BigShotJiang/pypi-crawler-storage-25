"""Round 132: Session & environment tools.

Three quality-of-life surfaces:

  * `/diff`       — interactive viewer for git changes; navigates
                    by hunk and supports `--stat` and `--cached`
  * `/add-dir`    — expand the agent's `workdir` set with
                    additional directories so file mentions, glob
                    expansion and reads can reach outside the
                    initial root
  * `--remote`    — turn this session into a remote-accessible
                    web bridge with a 6-digit pairing code +
                    QR-friendly URL
  * `/teleport`   — pull a remote web session back into the
                    local terminal (alias `/tp`)

Architecture: pure data layer — no Textual imports. Slash command
wrappers in `prometheus/slash/commands.py` consume these helpers.
"""
from __future__ import annotations

import os
import re
import secrets
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Optional


# ---------- /diff ----------


@dataclass
class DiffHunk:
    file: str
    head_line: int        # the +start line in the new file
    body: list[str] = field(default_factory=list)


@dataclass
class DiffView:
    """Parsed diff used by the interactive viewer."""
    raw: str
    hunks: list[DiffHunk] = field(default_factory=list)
    files: list[str] = field(default_factory=list)


_HUNK_HDR_RX = re.compile(
    r"^@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@"
)


def _run_git(
    args: list[str], *, cwd: Optional[Path] = None,
) -> tuple[bool, str]:
    """Run `git <args>`; return (ok, stdout). Quiet on failure."""
    try:
        cp = subprocess.run(
            ["git", *args],
            cwd=str(cwd) if cwd else None,
            capture_output=True, text=True, timeout=30,
            check=False,
        )
        if cp.returncode != 0:
            return (False, cp.stderr or "")
        return (True, cp.stdout or "")
    except (OSError, subprocess.TimeoutExpired) as e:
        return (False, str(e))


def fetch_diff(
    *,
    cached: bool = False,
    stat: bool = False,
    cwd: Optional[Path] = None,
) -> str:
    """Round 132: shell out to git for the diff. Returns "" on
    error so the caller can surface a friendly empty state."""
    args = ["diff"]
    if cached:
        args.append("--cached")
    if stat:
        args.append("--stat")
    ok, out = _run_git(args, cwd=cwd)
    return out if ok else ""


def parse_diff(raw: str) -> DiffView:
    """Round 132: turn a raw `git diff` into a DiffView with
    file boundaries + hunk metadata for the interactive nav."""
    files: list[str] = []
    hunks: list[DiffHunk] = []
    cur_file = ""
    cur_hunk: Optional[DiffHunk] = None
    for line in raw.splitlines():
        if line.startswith("+++ b/"):
            cur_file = line[6:].strip()
            if cur_file and cur_file not in files:
                files.append(cur_file)
            continue
        m = _HUNK_HDR_RX.match(line)
        if m and cur_file:
            try:
                head_line = int(m.group(1))
            except ValueError:
                head_line = 1
            if cur_hunk is not None:
                hunks.append(cur_hunk)
            cur_hunk = DiffHunk(
                file=cur_file, head_line=head_line, body=[line],
            )
            continue
        if cur_hunk is not None:
            cur_hunk.body.append(line)
    if cur_hunk is not None:
        hunks.append(cur_hunk)
    return DiffView(raw=raw, hunks=hunks, files=files)


def render_diff_overview(view: DiffView) -> str:
    """Round 132: short summary used as the viewer's footer."""
    if not view.files:
        return "no changes."
    return (
        f"{len(view.files)} file(s), "
        f"{len(view.hunks)} hunk(s) — j/k to nav, q to quit"
    )


# ---------- /add-dir ----------


@dataclass
class AddDirResult:
    added: list[Path] = field(default_factory=list)
    skipped: list[tuple[Path, str]] = field(default_factory=list)


def _safe_path(s: str) -> Optional[Path]:
    """Round 132: harden against path traversal and obvious
    bad inputs. Returns None when the path is unsafe."""
    if not s.strip():
        return None
    try:
        p = Path(s).expanduser()
        return p.resolve()
    except (OSError, ValueError):
        return None


def add_directories(
    inputs: Iterable[str],
    *,
    current: list[Path],
) -> AddDirResult:
    """Round 132: extend the workdir set. Reject paths that
    don't exist, aren't directories, or duplicate an existing
    entry."""
    res = AddDirResult()
    seen = {p.resolve() for p in current}
    for raw in inputs:
        p = _safe_path(raw)
        if p is None:
            res.skipped.append((Path(raw), "invalid path"))
            continue
        if not p.exists():
            res.skipped.append((p, "does not exist"))
            continue
        if not p.is_dir():
            res.skipped.append((p, "not a directory"))
            continue
        if p in seen:
            res.skipped.append((p, "already added"))
            continue
        res.added.append(p)
        seen.add(p)
    return res


def remove_directory(
    path_str: str,
    *,
    current: list[Path],
) -> Optional[Path]:
    """Round 132: pop a path from the working set."""
    p = _safe_path(path_str)
    if p is None:
        return None
    for entry in list(current):
        if entry.resolve() == p:
            return entry
    return None


def render_dir_list(workdirs: list[Path]) -> str:
    """Round 132: human-friendly listing for `/add-dir --list`."""
    if not workdirs:
        return "no extra directories registered."
    lines = ["working directories:"]
    for d in workdirs:
        lines.append(f"  {d}")
    return "\n".join(lines)


# ---------- --remote / /teleport ----------


@dataclass
class RemoteSession:
    """Round 132: handle for a `--remote`-launched session.

    Mirrors the round-118 Bridge design but slightly different —
    `--remote` advertises the session for *creation* on the web
    (instead of mirroring an existing local one), and `/teleport`
    pulls a web-created session back into a local terminal."""
    code: str
    url: str
    bridge_port: int
    pair_token: str = ""

    @property
    def display_url(self) -> str:
        return self.url.rstrip("/") + "/?code=" + self.code


def new_pair_code() -> str:
    """Round 132: 6-digit numeric pairing code. The user pairs
    by typing this into the web client. Constant-time compare
    is enforced when the bridge validates."""
    return f"{secrets.randbelow(1_000_000):06d}"


def new_pair_token() -> str:
    """Round 132: random URL-safe token issued after pairing
    succeeds. Used for subsequent web requests in lieu of the
    one-shot code."""
    return secrets.token_urlsafe(24)


def render_remote_banner(rs: RemoteSession) -> str:
    """Round 132: the banner printed at session launch."""
    return (
        f"remote session ready\n"
        f"  url:  {rs.display_url}\n"
        f"  code: {rs.code}\n"
        f"  port: {rs.bridge_port}\n"
        f"  share the URL + code with the web client; the code "
        f"expires after first use."
    )


def teleport_target_from_url(url: str) -> Optional[tuple[str, str]]:
    """Round 132: parse a teleport URL into (base, code).

    Accepts forms:
      http://host:port/?code=NNNNNN
      http://host:port/code/NNNNNN
    Returns None when neither matches."""
    if not url.strip():
        return None
    m = re.search(r"\?code=(\d{6})\b", url)
    if m:
        base = url.split("?", 1)[0]
        return (base.rstrip("/"), m.group(1))
    m = re.search(r"/code/(\d{6})\b", url)
    if m:
        base = url.split("/code/", 1)[0]
        return (base.rstrip("/"), m.group(1))
    return None


def remote_enabled() -> bool:
    """Round 132: did the user pass `--remote`? Set by the
    launch path."""
    return os.environ.get("PROMETHEUS_REMOTE", "").strip().lower() in (
        "1", "true", "yes",
    )


def set_remote_enabled(on: bool) -> None:
    os.environ["PROMETHEUS_REMOTE"] = "1" if on else "0"
