"""Round 137: additional keyboard helpers.

Eight new bindings extend the round-136 keyboard module:

  * Ctrl+Shift+F  — global file search across project
  * Ctrl+Shift+P  — quick-open file by fuzzy name match
  * Shift+Up      — message-actions mode (j/k/c/p)
  * Shift+Down    — next teammate in multi-agent sessions
  * Ctrl+U        — clear entire input line
  * Ctrl+W        — delete word backward
  * Ctrl+A        — jump to start of line
  * Ctrl+E        — jump to end of line
  * PgUp / PgDn   — scroll transcript

All are pure data-layer helpers. The Textual `on_key` handler
in the TUI calls these.
"""
from __future__ import annotations

import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


# ---------- Ctrl+U: clear input ----------


def clear_line(_text: str) -> tuple[str, int]:
    """Round 137: Ctrl+U wipes the entire input. Returns
    (new_text, new_cursor)."""
    return ("", 0)


# ---------- Ctrl+W: delete word backward ----------


def delete_word_backward(text: str, cursor: int) -> tuple[str, str, int]:
    """Round 137: Ctrl+W. Returns (new_text, killed, new_cursor).
    Mirrors `word_backward` from round 136."""
    if cursor <= 0:
        return (text, "", 0)
    i = cursor
    while i > 0 and text[i - 1].isspace():
        i -= 1
    while i > 0 and not text[i - 1].isspace():
        i -= 1
    killed = text[i:cursor]
    new_text = text[:i] + text[cursor:]
    return (new_text, killed, i)


# ---------- Ctrl+A / Ctrl+E ----------


def jump_to_start(_text: str, _cursor: int) -> int:
    return 0


def jump_to_end(text: str, _cursor: int) -> int:
    return len(text)


# ---------- PgUp / PgDn ----------


@dataclass
class ScrollState:
    """Round 137: tracks transcript scroll offset for PgUp/PgDn.
    The host's transcript widget consumes the offset value."""
    offset: int = 0
    page_size: int = 20

    def page_up(self) -> int:
        self.offset += self.page_size
        return self.offset

    def page_down(self) -> int:
        self.offset = max(0, self.offset - self.page_size)
        return self.offset

    def reset(self) -> None:
        self.offset = 0


# ---------- Ctrl+Shift+F: global search ----------


@dataclass
class FileSearchHit:
    file: str
    line: int
    text: str


def search_dispatch(
    query: str, *, workdir: Path,
) -> list[FileSearchHit]:
    """Round 137: Ctrl+Shift+F dispatcher. Prefers `rg`, falls
    back to `grep`. Returns up to 50 hits."""
    if not query.strip():
        return []
    out: list[FileSearchHit] = []
    use_rg = bool(shutil.which("rg"))
    cmd: list[str]
    if use_rg:
        cmd = [
            "rg", "--no-heading", "-n", "--max-count", "5",
            "--max-columns", "200", query, str(workdir),
        ]
    elif shutil.which("grep"):
        cmd = [
            "grep", "-rn", "-m", "5", query, str(workdir),
        ]
    else:
        return []
    try:
        cp = subprocess.run(
            cmd, capture_output=True, text=True,
            timeout=10, check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return []
    if cp.returncode not in (0, 1):  # 1 = no matches
        return []
    for raw in (cp.stdout or "").splitlines()[:50]:
        # Format: file:line:text
        parts = raw.split(":", 2)
        if len(parts) < 3:
            continue
        try:
            ln = int(parts[1])
        except ValueError:
            continue
        out.append(FileSearchHit(
            file=parts[0],
            line=ln,
            text=parts[2],
        ))
    return out


# ---------- Ctrl+Shift+P: quick-open ----------


def quick_open_candidates(
    query: str, *, workdir: Path, max_results: int = 30,
) -> list[Path]:
    """Round 137: fuzzy-match files in workdir by name. Pure
    Python — no extra deps."""
    q = (query or "").strip().lower()
    if not q:
        return []
    skip_dirs = {
        ".git", "node_modules", "__pycache__", ".venv", "venv",
        "dist", "build", ".tox", ".mypy_cache", ".pytest_cache",
    }
    scored: list[tuple[int, Path]] = []
    try:
        for root, dirs, files in _walk(workdir, skip_dirs):
            for fname in files:
                low = fname.lower()
                score = _fuzzy_score(low, q)
                if score > 0:
                    scored.append((score, Path(root) / fname))
                    if len(scored) > 5000:
                        break
            if len(scored) > 5000:
                break
    except OSError:
        return []
    scored.sort(key=lambda kv: kv[0], reverse=True)
    return [p for _s, p in scored[:max_results]]


def _walk(workdir: Path, skip_dirs: set[str]):
    """Round 137: tiny os.walk wrapper that skips noise dirs."""
    import os as _os
    for root, dirs, files in _os.walk(workdir):
        dirs[:] = [d for d in dirs if d not in skip_dirs]
        yield root, dirs, files


def _fuzzy_score(name: str, query: str) -> int:
    """Round 137: small subsequence-match scorer. Higher is
    better. Returns 0 when query isn't a subsequence of name."""
    i = 0
    score = 0
    last_match_idx = -1
    for idx, ch in enumerate(name):
        if i < len(query) and ch == query[i]:
            score += 1
            if last_match_idx >= 0 and idx == last_match_idx + 1:
                score += 1   # bonus for consecutive matches
            last_match_idx = idx
            i += 1
    if i < len(query):
        return 0
    if name.startswith(query):
        score += 5
    return score


# ---------- Shift+Up: message-actions mode ----------


@dataclass
class MessageActionsState:
    """Round 137: state machine for the Shift+Up overlay."""
    active: bool = False
    cursor: int = 0
    pinned: list[int] = field(default_factory=list)
    last_copied: str = ""

    def enter(self, total_messages: int) -> None:
        self.active = True
        self.cursor = max(0, total_messages - 1)

    def exit(self) -> None:
        self.active = False
        self.cursor = 0

    def move(self, delta: int, *, total_messages: int) -> int:
        if not self.active:
            return self.cursor
        new = self.cursor + delta
        new = max(0, min(total_messages - 1, new))
        self.cursor = new
        return new

    def copy(self, content: str) -> str:
        self.last_copied = content
        return content

    def pin(self) -> int:
        if self.cursor in self.pinned:
            self.pinned.remove(self.cursor)
        else:
            self.pinned.append(self.cursor)
        return self.cursor


# ---------- Shift+Down: next teammate ----------


def next_teammate(
    teammates: list[str], current: Optional[str],
) -> Optional[str]:
    """Round 137: ring-cycle through teammates."""
    if not teammates:
        return None
    if current is None or current not in teammates:
        return teammates[0]
    idx = teammates.index(current)
    return teammates[(idx + 1) % len(teammates)]
