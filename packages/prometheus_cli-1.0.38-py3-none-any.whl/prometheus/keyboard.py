"""Round 136: Additional keyboard shortcuts.

Eight new bindings:

  * Ctrl+F (×2 within 2s)  — kill all background agents/cohorts
  * Ctrl+S                 — stash input (clear); press again to restore
  * ?                      — show shortcuts overlay (Esc dismisses)
  * Alt+P                  — cycle model tier haiku→sonnet→opus→…
  * Alt+T                  — toggle extended thinking (when available)
  * Alt+B / Alt+F          — backward/forward one word in input
  * Ctrl+K                 — delete from cursor to end of line
  * Ctrl+Y                 — paste last deleted text (yank)

Pure data layer. The Textual app's `on_key` dispatcher consumes
these helpers — no Textual imports here keeps the unit tests
fast and free of UI dependencies.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional


# ---------- Ctrl+F double-press to kill cohorts ----------


@dataclass
class DoublePressGate:
    """Round 136 / 167: arms once, fires on second press within window.

    Round 167: window_s default raised from 2.0 to 3.0 to match
    Claude Code's documented 3-second double-tap window for
    chord-style shortcuts (Esc Esc rewind, Ctrl+F × 2 kill
    agents, etc.).

    Round 167: changed the sentinel from `0.0` to `-1.0` so a
    legitimate first-press at `now=0.0` is correctly recognised
    as armed. Pre-fix, calling `press(now=0.0)` set armed_at to
    0.0 — which collided with the initial-value sentinel — so
    a second press was treated as a new arming, not a fire.
    """
    armed_at: float = -1.0
    window_s: float = 3.0

    def press(self, *, now: Optional[float] = None) -> bool:
        """Returns True iff this is the *second* press within
        the window. Otherwise arms and returns False."""
        t = now if now is not None else time.monotonic()
        if (
            self.armed_at >= 0.0
            and (t - self.armed_at) <= self.window_s
        ):
            self.armed_at = -1.0
            return True
        self.armed_at = t
        return False

    def disarm(self) -> None:
        self.armed_at = -1.0


# ---------- Ctrl+S stash buffer ----------


@dataclass
class StashBuffer:
    """Round 136: one-slot stash. press to capture; press again
    to restore. Empty stash + non-empty input → capture.
    Non-empty stash + empty input → restore. Both empty → no-op.
    Both non-empty → capture (overwrite — most-recent wins)."""
    stashed: str = ""

    def toggle(self, current: str) -> tuple[str, str]:
        """Returns (new_input_value, action) where action is one
        of `stash`/`restore`/`noop`."""
        if current and not self.stashed:
            self.stashed = current
            return ("", "stash")
        if not current and self.stashed:
            out = self.stashed
            self.stashed = ""
            return (out, "restore")
        if current and self.stashed:
            self.stashed = current
            return ("", "stash")
        return ("", "noop")


# ---------- Alt+P model tier cycle ----------


_TIER_CYCLE = ("haiku", "sonnet", "opus")


def next_tier(current: str) -> str:
    """Round 136: walk the haiku→sonnet→opus→haiku ring. If the
    current selection isn't one of the three tiers, snap to
    haiku."""
    cur = (current or "").strip().lower()
    if cur not in _TIER_CYCLE:
        return _TIER_CYCLE[0]
    idx = _TIER_CYCLE.index(cur)
    return _TIER_CYCLE[(idx + 1) % len(_TIER_CYCLE)]


# ---------- Alt+B / Alt+F word movement ----------


def word_backward(text: str, cursor: int) -> int:
    """Round 136: standard word-back rule. Skip whitespace
    immediately before cursor, then skip word chars to the
    left. Returns the new cursor index."""
    if cursor <= 0:
        return 0
    i = cursor
    # Skip trailing whitespace.
    while i > 0 and text[i - 1].isspace():
        i -= 1
    # Skip word characters.
    while i > 0 and not text[i - 1].isspace():
        i -= 1
    return i


def word_forward(text: str, cursor: int) -> int:
    """Round 136: skip word chars at cursor, then trailing
    whitespace. Returns the new cursor index."""
    if cursor >= len(text):
        return len(text)
    i = cursor
    # Skip word characters.
    while i < len(text) and not text[i].isspace():
        i += 1
    # Skip whitespace.
    while i < len(text) and text[i].isspace():
        i += 1
    return i


# ---------- Ctrl+K delete-to-end-of-line ----------


def kill_to_end(text: str, cursor: int) -> tuple[str, str]:
    """Round 136: returns (new_text, killed_text). Standard
    bash/readline kill. Cursor stays at its position."""
    if cursor >= len(text):
        return (text, "")
    return (text[:cursor], text[cursor:])


# ---------- Ctrl+Y yank ----------


@dataclass
class KillRing:
    """Round 136 / 167: kill ring backing Ctrl+K / Ctrl+U / Ctrl+Y / Alt+Y.

    Originally single-slot (round 136 stored only the most-recent
    kill). Round 167 extends to a true multi-slot ring with a
    rotation cursor so Alt+Y cycles through prior kills — the
    documented Emacs / readline behaviour.

    Backwards compat: the original `kill(text)` and
    `yank(text, cursor)` methods retain the single-slot
    semantics they had in round 136. New methods `push(text)` /
    `cycle_yank(text, cursor)` drive the multi-slot path.
    """
    last_killed: str = ""
    """Round 136 single-slot field. Mirrors entries[-1] when
    `push` is the only mutation path; kept distinct so callers
    that only used the single-slot API still work."""
    entries: list = field(default_factory=list)
    """Round 167: ring of kills, oldest first. Bounded at
    `max_entries` so a long session doesn't grow unbounded."""
    cursor: int = -1
    """Round 167: index into `entries` for Alt+Y cycling.
    -1 = no cycle in progress. After a yank() places
    entries[-1], pressing Alt+Y rotates to entries[-2], etc."""
    max_entries: int = 32

    def kill(self, killed: str) -> None:
        """Round 136 API: record `killed` in the most-recent
        slot AND push to the ring."""
        if killed:
            self.last_killed = killed
            self.push(killed)

    def push(self, killed: str) -> None:
        """Round 167: append to the multi-slot ring. Empty
        strings are ignored; duplicates of the most-recent
        entry are coalesced (matches Emacs behaviour)."""
        if not killed:
            return
        if self.entries and self.entries[-1] == killed:
            return
        self.entries.append(killed)
        if len(self.entries) > self.max_entries:
            self.entries = self.entries[-self.max_entries:]
        self.cursor = -1  # any new push resets the cycle

    def yank(self, text: str, cursor: int) -> tuple[str, int]:
        """Round 136 API: insert `last_killed` at `cursor`.
        Returns (new_text, new_cursor)."""
        if not self.last_killed:
            return (text, cursor)
        out = text[:cursor] + self.last_killed + text[cursor:]
        return (out, cursor + len(self.last_killed))

    def cycle_yank(
        self, text: str, cursor: int, *, last_yanked_len: int = 0,
    ) -> tuple[str, int, str]:
        """Round 167: Alt+Y. If a previous yank just placed
        `last_yanked_len` chars at `cursor`, replace those chars
        with the next-older entry. Returns (new_text, new_cursor,
        yanked).

        First call (cursor=-1 internal): rotates to second-most-
        recent. Subsequent calls walk further back, wrapping at
        the start of the ring.
        """
        if not self.entries:
            return (text, cursor, "")
        if self.cursor == -1:
            self.cursor = len(self.entries) - 1
        # Step backward in the ring (wrapping).
        self.cursor = (self.cursor - 1) % len(self.entries)
        replacement = self.entries[self.cursor]
        # Strip the most-recent yank from `text` if the caller
        # passed its length.
        if last_yanked_len > 0 and cursor >= last_yanked_len:
            text = text[:cursor - last_yanked_len] + text[cursor:]
            cursor -= last_yanked_len
        out = text[:cursor] + replacement + text[cursor:]
        return (out, cursor + len(replacement), replacement)


# ---------- ? overlay shortcut catalogue ----------


@dataclass
class Shortcut:
    keys: str
    action: str
    category: str = "general"


def shortcut_catalogue() -> list[Shortcut]:
    """Round 136 / 172: full list shown in the `?` overlay."""
    return [
        # input
        Shortcut("Enter",     "submit prompt / complete slash command",  "input"),
        Shortcut("Shift+Enter", "newline in prompt",                      "input"),
        Shortcut("Tab",       "complete slash command / file mention",   "input"),
        Shortcut("Esc",       "cancel running tool / dismiss overlay",   "input"),
        Shortcut("Esc Esc",   "rewind one turn · restore last prompt for editing", "input"),
        Shortcut("Up / Down", "recall previous / next prompt",           "input"),
        Shortcut("Ctrl+S",    "stash current input · press again to restore", "input"),
        Shortcut("Ctrl+K",    "delete from cursor to end of line",       "input"),
        Shortcut("Ctrl+U",    "delete from cursor to start of line",     "input"),
        Shortcut("Ctrl+Y",    "yank (paste) last deleted text",          "input"),
        Shortcut("Alt+Y",     "cycle through previously yanked entries", "input"),
        Shortcut("Alt+B",     "move cursor back one word",               "input"),
        Shortcut("Alt+F",     "move cursor forward one word",            "input"),
        # prompt prefixes
        Shortcut("!",         "prefix to run a shell command directly",  "input"),
        Shortcut("#",         "prefix to append the rest to project memory", "input"),
        Shortcut("@",         "prefix to mention a file (Tab to complete)", "input"),
        Shortcut("/",         "prefix to invoke a slash command (Tab to complete)", "input"),
        # session
        Shortcut("Ctrl+C",    "interrupt current step",                  "session"),
        Shortcut("Ctrl+D",    "quit session",                            "session"),
        Shortcut("Ctrl+L",    "clear screen",                            "session"),
        Shortcut("Ctrl+F ×2", "kill all background agents (within 2s)",  "session"),
        Shortcut("Ctrl+R",    "search history",                          "session"),
        Shortcut("Shift+Tab", "cycle permission mode",                   "session"),
        # model
        Shortcut("Alt+P",     "cycle model tier  haiku → sonnet → opus", "model"),
        Shortcut("Alt+T",     "toggle extended thinking (when available)", "model"),
        # navigation
        Shortcut("Ctrl+End",  "jump to bottom & re-arm auto-scroll",     "navigation"),
        Shortcut("Ctrl+O",    "expand most-recent agent card · transcript viewer", "navigation"),
        Shortcut("?",         "show this shortcuts overlay",             "navigation"),
    ]


def render_shortcut_overlay(rows: list[Shortcut]) -> str:
    """Round 136: format the `?` overlay as a grouped, aligned
    text block."""
    by_cat: dict[str, list[Shortcut]] = {}
    for s in rows:
        by_cat.setdefault(s.category, []).append(s)
    order = ("input", "session", "model", "navigation")
    out: list[str] = ["Keyboard shortcuts:", ""]
    for cat in order:
        if cat not in by_cat:
            continue
        out.append(f"  {cat}:")
        for s in by_cat[cat]:
            out.append(f"    {s.keys:14s}  {s.action}")
        out.append("")
    out.append("Press Esc to dismiss.")
    return "\n".join(out)
