"""Round 144-final: declarative multi-step workflows.

Workflows live as YAML/JSON files under
`<workdir>/.prometheus/workflows/`. Each defines a sequence
of steps the agent runs in order. Branching is supported via
a per-step `if` condition that reads from an accumulated
`vars` dict.

Schema:

    name: bug-triage
    description: Open issue triage workflow
    steps:
      - name: gather
        prompt: "Read the failing test and summarize."
        save_to: summary
      - name: branch
        if: "summary contains 'flaky'"
        prompt: "Mark the test flaky."
      - name: fix
        if: "summary not contains 'flaky'"
        prompt: "Propose a fix."

Pure data layer. The host's `/workflow <name>` slash command
loads the file and dispatches each step's prompt.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


# ---------- schema ----------


@dataclass
class WorkflowStep:
    name: str
    prompt: str
    if_condition: str = ""
    save_to: str = ""
    permission_mode: str = ""
    model: str = ""


@dataclass
class Workflow:
    name: str
    description: str
    steps: list[WorkflowStep] = field(default_factory=list)
    path: Optional[Path] = None


# ---------- discovery + parsing ----------


def workflows_dir(workdir: Path) -> Path:
    return workdir / ".prometheus" / "workflows"


def _parse_yaml_lite(body: str) -> dict[str, Any]:
    """Round 144-final: minimal YAML reader — supports the
    small subset workflow files use (top-level scalars + a
    `steps:` list of maps). PyYAML gets used when installed.
    """
    try:
        import yaml  # type: ignore[import-not-found]
        data = yaml.safe_load(body)
        return data if isinstance(data, dict) else {}
    except ImportError:
        pass
    # Hand-rolled minimal parser. Handles:
    #   key: value
    #   key:
    #   - key: value
    #     ...
    out: dict[str, Any] = {}
    lines = body.splitlines()
    i = 0
    while i < len(lines):
        raw = lines[i].rstrip()
        if not raw or raw.lstrip().startswith("#"):
            i += 1
            continue
        if not raw.startswith(" "):
            if ":" not in raw:
                i += 1
                continue
            k, _, v = raw.partition(":")
            v = v.strip()
            if not v:
                # block follows
                if k.strip() == "steps":
                    steps, i = _parse_steps(lines, i + 1)
                    out["steps"] = steps
                    continue
                else:
                    out[k.strip()] = ""
            else:
                out[k.strip()] = _strip_quotes(v)
        i += 1
    return out


def _strip_quotes(v: str) -> str:
    v = v.strip()
    if (v.startswith('"') and v.endswith('"')) or (
        v.startswith("'") and v.endswith("'")
    ):
        return v[1:-1]
    return v


def _parse_steps(
    lines: list[str], start: int,
) -> tuple[list[dict[str, Any]], int]:
    steps: list[dict[str, Any]] = []
    i = start
    cur: Optional[dict[str, Any]] = None
    while i < len(lines):
        raw = lines[i]
        if not raw.strip():
            i += 1
            continue
        if not raw.startswith(" "):
            break
        # New step: `  - key: value`
        m = re.match(r"^\s*-\s*(\w+)\s*:\s*(.*)$", raw)
        if m:
            cur = {m.group(1): _strip_quotes(m.group(2))}
            steps.append(cur)
            i += 1
            continue
        # Continuation field of current step.
        m2 = re.match(r"^\s+(\w+)\s*:\s*(.*)$", raw)
        if m2 and cur is not None:
            cur[m2.group(1)] = _strip_quotes(m2.group(2))
            i += 1
            continue
        i += 1
    return steps, i


def load_workflow(path: Path) -> Optional[Workflow]:
    """Round 144-final: load a single workflow file."""
    if not path.exists():
        return None
    suffix = path.suffix.lower()
    try:
        body = path.read_text(encoding="utf-8")
    except OSError:
        return None
    try:
        if suffix in (".json",):
            data = json.loads(body)
        else:
            data = _parse_yaml_lite(body)
    except (ValueError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    steps_raw = data.get("steps") or []
    steps: list[WorkflowStep] = []
    for s in steps_raw:
        if not isinstance(s, dict):
            continue
        prompt = str(s.get("prompt") or "").strip()
        if not prompt:
            continue
        steps.append(WorkflowStep(
            name=str(s.get("name") or f"step-{len(steps) + 1}"),
            prompt=prompt,
            if_condition=str(s.get("if") or ""),
            save_to=str(s.get("save_to") or ""),
            permission_mode=str(s.get("permission_mode") or ""),
            model=str(s.get("model") or ""),
        ))
    return Workflow(
        name=str(data.get("name") or path.stem),
        description=str(data.get("description") or ""),
        steps=steps,
        path=path,
    )


def discover_workflows(workdir: Path) -> list[Workflow]:
    base = workflows_dir(workdir)
    if not base.exists():
        return []
    out: list[Workflow] = []
    for p in sorted(base.iterdir()):
        if p.suffix.lower() not in (".yaml", ".yml", ".json"):
            continue
        wf = load_workflow(p)
        if wf is not None:
            out.append(wf)
    return out


def find_workflow(workdir: Path, name: str) -> Optional[Workflow]:
    name = (name or "").strip().lower()
    for w in discover_workflows(workdir):
        if w.name.lower() == name or w.path.stem.lower() == name:
            return w
    return None


# ---------- conditional evaluation ----------


_CONTAINS_RX = re.compile(
    r"^\s*(\w+)\s+(contains|not\s+contains|equals|not\s+equals)"
    r"\s+['\"](.+?)['\"]\s*$",
)


def evaluate_condition(
    cond: str, *, vars: dict[str, Any],
) -> bool:
    """Round 144-final: tiny condition language. Supports
    `<var> contains '<text>'` / `not contains` / `equals` /
    `not equals`. Empty condition → always True."""
    cond = (cond or "").strip()
    if not cond:
        return True
    m = _CONTAINS_RX.match(cond)
    if not m:
        # Unparseable — fail closed (skip the step) so the
        # user notices.
        return False
    var, op, val = m.group(1), m.group(2).strip(), m.group(3)
    raw = str(vars.get(var, "")).lower()
    needle = val.lower()
    if op == "contains":
        return needle in raw
    if op == "not contains":
        return needle not in raw
    if op == "equals":
        return raw == needle
    if op == "not equals":
        return raw != needle
    return False


# ---------- rendering ----------


def render_workflow_list(rows: list[Workflow]) -> str:
    if not rows:
        return (
            "no workflows found. Drop YAML files in "
            ".prometheus/workflows/."
        )
    lines = ["workflows:"]
    for w in rows:
        lines.append(
            f"  {w.name:24s}  ({len(w.steps)} step(s))  "
            f"{w.description[:60]}"
        )
    return "\n".join(lines)


def render_workflow(w: Workflow) -> str:
    lines = [f"workflow: {w.name}"]
    if w.description:
        lines.append(f"  {w.description}")
    lines.append("")
    for i, step in enumerate(w.steps, 1):
        head = f"  {i}. {step.name}"
        if step.if_condition:
            head += f"  (if: {step.if_condition})"
        if step.save_to:
            head += f"  → {step.save_to}"
        lines.append(head)
        for line in step.prompt.splitlines()[:3]:
            lines.append(f"      {line}")
    return "\n".join(lines)
