"""Round 137: `/debug` — diagnostics mode.

A small per-session state object that tracks which debug
categories are active. The host's API client, hook runner,
MCP launcher, tool dispatcher, and permission gate consult
this state before emitting verbose log output.

Categories: `api` / `hooks` / `mcp` / `tools` / `permissions`
/ `all`.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Iterable


VALID_CATEGORIES = (
    "api", "hooks", "mcp", "tools", "permissions",
)


@dataclass
class DebugState:
    """Round 137: per-session debug toggles. Empty `categories`
    means debug is off."""
    categories: set[str] = field(default_factory=set)

    @property
    def active(self) -> bool:
        return bool(self.categories)

    def enabled(self, cat: str) -> bool:
        return "all" in self.categories or cat in self.categories

    def enable(self, names: Iterable[str]) -> list[str]:
        added: list[str] = []
        for raw in names:
            n = (raw or "").strip().lower()
            if not n:
                continue
            if n == "all":
                self.categories = {"all"}
                added.append(n)
                continue
            if n in VALID_CATEGORIES and n not in self.categories:
                self.categories.add(n)
                added.append(n)
        return added

    def disable(self, names: Iterable[str]) -> list[str]:
        removed: list[str] = []
        for raw in names:
            n = (raw or "").strip().lower()
            if n in self.categories:
                self.categories.discard(n)
                removed.append(n)
        return removed

    def clear(self) -> None:
        self.categories.clear()


def parse_debug_arg(arg: str) -> tuple[str, list[str]]:
    """Round 137: parse `/debug` argument forms.

    Returns (action, categories) where action is `on` (default,
    enables), `off` (disable), or `status` (show current).

    Examples:
      ""               → ("status", [])
      "off"            → ("off", [])
      "all"            → ("on", ["all"])
      "api,tools"      → ("on", ["api", "tools"])
      "off api"        → ("off", ["api"])
    """
    raw = (arg or "").strip()
    if not raw:
        return ("status", [])
    parts = raw.split()
    head = parts[0].lower()
    if head == "off":
        rest = parts[1].split(",") if len(parts) > 1 else []
        return ("off", [p.strip().lower() for p in rest if p.strip()])
    if head == "on":
        rest = parts[1] if len(parts) > 1 else ""
        return ("on", [p.strip().lower() for p in rest.split(",") if p.strip()])
    if head == "status":
        return ("status", [])
    # Treat the bare arg as a CSV of categories to enable.
    cats = [p.strip().lower() for p in raw.split(",") if p.strip()]
    return ("on", cats)


def render_status(state: DebugState) -> str:
    """Round 137: human-friendly render of `/debug` state."""
    if not state.active:
        return "debug: off"
    cats = sorted(state.categories)
    return "debug: on  (" + ", ".join(cats) + ")"


def render_categories() -> str:
    """Round 137: list available categories for `/debug`."""
    return (
        "categories: api, hooks, mcp, tools, permissions, all\n"
        "  /debug                    show current state\n"
        "  /debug all                enable everything\n"
        "  /debug api,tools          enable specific categories\n"
        "  /debug off                disable\n"
        "  /debug off api            disable just `api`"
    )
