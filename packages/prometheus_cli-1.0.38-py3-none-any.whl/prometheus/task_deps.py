"""Round 142: task dependency tracking.

Extends the round-101 Work Log task system with `blocks` and
`blockedBy` fields. Pure data layer — exposes:

  * `apply_dependencies(task, *, blocks, blocked_by)` — set
    fields on a task dict.
  * `update_blocked_by(task, *, add, remove)` — mutate.
  * `compute_blocked_set(tasks)` — given a list of tasks,
    returns the set of task ids that have unmet blockers.
  * `can_complete(task, tasks)` — refuse to mark complete
    while any blocker is still open.
  * `render_task_list(tasks)` — chained rendering with
    indentation and `▲ blocked by #N` markers.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable, Optional


# Internal helpers — task dicts share the round-101 shape.


def _id(task: Any) -> str:
    if isinstance(task, dict):
        return str(task.get("id") or task.get("task_id") or "")
    return str(getattr(task, "id", "") or getattr(task, "task_id", ""))


def _status(task: Any) -> str:
    if isinstance(task, dict):
        return str(task.get("status") or "")
    return str(getattr(task, "status", "") or "")


def _subject(task: Any) -> str:
    if isinstance(task, dict):
        return str(task.get("subject") or task.get("title") or "")
    return str(getattr(task, "subject", "") or getattr(task, "title", ""))


def _blocks(task: Any) -> list[str]:
    if isinstance(task, dict):
        v = task.get("blocks") or []
    else:
        v = getattr(task, "blocks", None) or []
    return [str(x) for x in v if x]


def _blocked_by(task: Any) -> list[str]:
    if isinstance(task, dict):
        v = task.get("blocked_by") or task.get("blockedBy") or []
    else:
        v = (
            getattr(task, "blocked_by", None)
            or getattr(task, "blockedBy", None)
            or []
        )
    return [str(x) for x in v if x]


def _set(task: Any, key: str, value: Any) -> None:
    if isinstance(task, dict):
        task[key] = value
    else:
        try:
            setattr(task, key, value)
        except Exception:
            pass


# ---------- mutation helpers ----------


def apply_dependencies(
    task: Any,
    *,
    blocks: Optional[Iterable[str]] = None,
    blocked_by: Optional[Iterable[str]] = None,
) -> Any:
    """Round 142: set `blocks` / `blocked_by` on a task,
    deduping + skipping self-references."""
    self_id = _id(task)
    if blocks is not None:
        cleaned = []
        seen: set[str] = set()
        for b in blocks:
            s = str(b).strip()
            if s and s != self_id and s not in seen:
                seen.add(s)
                cleaned.append(s)
        _set(task, "blocks", cleaned)
    if blocked_by is not None:
        cleaned = []
        seen = set()
        for b in blocked_by:
            s = str(b).strip()
            if s and s != self_id and s not in seen:
                seen.add(s)
                cleaned.append(s)
        _set(task, "blocked_by", cleaned)
    return task


def update_blocked_by(
    task: Any,
    *,
    add: Optional[Iterable[str]] = None,
    remove: Optional[Iterable[str]] = None,
) -> list[str]:
    """Round 142: incrementally mutate `blocked_by`. Returns
    the resulting list."""
    cur = list(_blocked_by(task))
    self_id = _id(task)
    if add:
        for a in add:
            s = str(a).strip()
            if s and s != self_id and s not in cur:
                cur.append(s)
    if remove:
        rm = {str(r).strip() for r in remove}
        cur = [c for c in cur if c not in rm]
    _set(task, "blocked_by", cur)
    return cur


# ---------- queries ----------


def is_blocked(task: Any, tasks: list[Any]) -> bool:
    """Round 142: a task is blocked when at least one of its
    `blocked_by` entries exists in the task list and is not
    yet completed."""
    deps = _blocked_by(task)
    if not deps:
        return False
    by_id = {_id(t): t for t in tasks}
    for dep in deps:
        blocker = by_id.get(dep)
        if blocker is None:
            # Unknown blocker — treat as still open so the
            # user resolves the inconsistency before
            # completing.
            return True
        if _status(blocker) != "completed":
            return True
    return False


def compute_blocked_set(tasks: list[Any]) -> set[str]:
    """Round 142: ids of every task currently blocked."""
    return {
        _id(t) for t in tasks
        if _id(t) and is_blocked(t, tasks)
    }


def can_complete(task: Any, tasks: list[Any]) -> tuple[bool, str]:
    """Round 142: `(ok, reason)`. Refuses completion when any
    blocker is still open."""
    if _status(task) == "completed":
        return (True, "already complete")
    if not is_blocked(task, tasks):
        return (True, "no blockers")
    by_id = {_id(t): t for t in tasks}
    open_blockers: list[str] = []
    for dep in _blocked_by(task):
        b = by_id.get(dep)
        if b is None:
            open_blockers.append(f"#{dep}(missing)")
        elif _status(b) != "completed":
            open_blockers.append(
                f"#{dep}({_status(b) or 'open'})"
            )
    if not open_blockers:
        return (True, "no blockers")
    return (
        False,
        "blocked by: " + ", ".join(open_blockers),
    )


# ---------- rendering ----------


def _topological_chain(tasks: list[Any]) -> list[Any]:
    """Round 142: order tasks so blockers come before their
    dependents. Cycles + tasks not part of any chain fall to
    the end in their original order."""
    by_id = {_id(t): t for t in tasks if _id(t)}
    indegree: dict[str, int] = {tid: 0 for tid in by_id}
    for t in tasks:
        for dep in _blocked_by(t):
            tid = _id(t)
            if dep in by_id and tid in indegree:
                indegree[tid] += 1
    queue = [tid for tid, n in indegree.items() if n == 0]
    out: list[Any] = []
    seen: set[str] = set()
    while queue:
        tid = queue.pop(0)
        if tid in seen:
            continue
        seen.add(tid)
        out.append(by_id[tid])
        # Find tasks blocked-by this id; decrement their count.
        for cand in tasks:
            if _id(cand) in seen:
                continue
            if tid in _blocked_by(cand):
                cid = _id(cand)
                indegree[cid] = max(0, indegree.get(cid, 0) - 1)
                if indegree[cid] == 0:
                    queue.append(cid)
    # Add any leftovers (cycles / orphans).
    for t in tasks:
        if _id(t) and _id(t) not in seen:
            out.append(t)
    return out


def render_task_list(tasks: list[Any]) -> str:
    """Round 142: chain-aware render. Tasks blocked by another
    are indented under their blocker. Blocked-but-unresolved
    rows show `▲ blocked by #N`."""
    if not tasks:
        return "(no tasks)"
    by_id = {_id(t): t for t in tasks if _id(t)}
    blocked_set = compute_blocked_set(tasks)
    ordered = _topological_chain(tasks)
    # Compute depth from the dependency graph.
    depth: dict[str, int] = {}
    for t in ordered:
        deps = _blocked_by(t)
        if not deps:
            depth[_id(t)] = 0
            continue
        best = 0
        for dep in deps:
            if dep in depth:
                best = max(best, depth[dep] + 1)
            else:
                best = max(best, 1)
        depth[_id(t)] = best
    out: list[str] = ["tasks:"]
    for t in ordered:
        tid = _id(t)
        d = depth.get(tid, 0)
        indent = "  " * (1 + d)
        status = _status(t) or "open"
        glyph = {
            "completed":  "✓",
            "in_progress": "◐",
            "blocked":    "▲",
        }.get(status, "·")
        if tid in blocked_set:
            glyph = "▲"
        line = f"{indent}{glyph} #{tid:<8} [{status:11s}] {_subject(t)}"
        if tid in blocked_set:
            deps = ", ".join(f"#{d}" for d in _blocked_by(t))
            line += f"  ▲ blocked by {deps}"
        out.append(line)
    return "\n".join(out)
