"""PrometheUS — free terminal AI coding agent."""

# Round 187: version SoT is pyproject.toml at the repo root —
# read it directly when reachable so dev / editable installs always
# show the version the source declares. Pre-R187 we read from
# installed-package metadata, which went stale whenever someone
# bumped pyproject.toml without re-running `pip install -e .`
# (so `prometheus --version` printed an old number while the
# release-channel intent was something newer).
def _read_version() -> str:
    try:
        from pathlib import Path as _P
        # __file__ -> prometheus/__init__.py; parent.parent -> repo root
        pyproject = _P(__file__).resolve().parent.parent / "pyproject.toml"
        if pyproject.exists():
            for line in pyproject.read_text(encoding="utf-8").splitlines():
                s = line.strip()
                if s.startswith("version"):
                    # `version = "1.0.0"` — split off the quoted value.
                    parts = s.split("=", 1)
                    if len(parts) == 2:
                        v = parts[1].strip().strip('"').strip("'")
                        if v:
                            return v
    except Exception:
        pass
    try:
        from importlib.metadata import version as _pkg_version
        return _pkg_version("prometheus-cli")
    except Exception:
        return "1.0.0"


__version__ = _read_version()
__all__ = ["__version__"]
