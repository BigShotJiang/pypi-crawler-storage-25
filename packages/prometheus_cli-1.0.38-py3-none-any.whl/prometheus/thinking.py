"""Round 136: Extended-thinking toggle + per-model availability.

Two surfaces:

  * `--thinking on|off`           CLI flag, applied at launch
  * Alt+T                         mid-session toggle (round 136)

A small whitelist tracks which model families support the
extended-thinking call. The heuristic uses substring matches
(`opus`/`sonnet` are known to support it; small models like
`haiku` are gated off by default but allowed via env override).

When a user switches models (`/model haiku`) we surface a note
if the new model doesn't support thinking, and the toggle is
disabled until they swap to a supporting model.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional


# Known to support extended thinking. Substring match.
_THINKING_PATTERNS = (
    "opus", "sonnet",
    "claude-opus", "claude-sonnet",
    "deepseek", "minimax", "kimi",
)

# Known NOT to support extended thinking (strong signal — wins
# over the patterns above when a model id matches both).
_NON_THINKING_PATTERNS = (
    "haiku", "claude-haiku",
)


def model_supports_thinking(model: str) -> bool:
    """Round 136: best-effort detection. Env override
    `PROMETHEUS_FORCE_THINKING=1` returns True for any model
    (caller responsibility if the model rejects the call)."""
    if os.environ.get("PROMETHEUS_FORCE_THINKING", "").strip() in (
        "1", "true", "yes",
    ):
        return True
    low = (model or "").lower()
    if not low:
        return False
    for p in _NON_THINKING_PATTERNS:
        if p in low:
            return False
    for p in _THINKING_PATTERNS:
        if p in low:
            return True
    return False


# ---------- thinking state ----------


@dataclass
class ThinkingState:
    """Round 136: tracks the user's intent (on/off) and the
    effective state given the current model. The effective
    state is what the provider call uses; intent is preserved
    so when the user re-enables a thinking-capable model the
    flag flips back automatically."""
    enabled: bool = False
    available: bool = False

    @property
    def effective(self) -> bool:
        return self.enabled and self.available


def parse_thinking_flag(value: str) -> Optional[bool]:
    """Round 136: parse the `--thinking` CLI flag. Accepts
    `on`/`true`/`1` (True), `off`/`false`/`0` (False),
    empty/unknown (None — leave default in place)."""
    v = (value or "").strip().lower()
    if not v:
        return None
    if v in ("on", "true", "1", "yes", "enable", "enabled"):
        return True
    if v in ("off", "false", "0", "no", "disable", "disabled"):
        return False
    return None


def apply_model_change(
    state: ThinkingState, *, new_model: str,
) -> ThinkingState:
    """Round 136: when the model changes, recompute availability.
    The user's intent (`enabled`) is preserved — if the new
    model doesn't support thinking, the toggle is "disabled"
    (effective=False) without losing the intent."""
    return ThinkingState(
        enabled=state.enabled,
        available=model_supports_thinking(new_model),
    )


def status_chip(state: ThinkingState) -> str:
    """Round 136: status-bar chip describing thinking state.
    Returns `""` when nothing should be shown."""
    if state.effective:
        return "THINK"
    if state.enabled and not state.available:
        return "think (n/a)"
    return ""


def model_change_note(
    state_before: ThinkingState, state_after: ThinkingState,
    *, new_model: str,
) -> str:
    """Round 136: short message printed after `/model` switch
    when thinking availability changed."""
    if state_before.available == state_after.available:
        return ""
    if state_after.available and state_after.enabled:
        return (
            f"  ✓ extended thinking re-enabled "
            f"({new_model} supports it)"
        )
    if state_after.available:
        return (
            f"  ℹ {new_model} supports extended thinking "
            f"(currently off — Alt+T to enable)"
        )
    if state_before.enabled:
        return (
            f"  ℹ {new_model} does not support extended thinking "
            f"— toggle disabled until you switch back"
        )
    return ""
