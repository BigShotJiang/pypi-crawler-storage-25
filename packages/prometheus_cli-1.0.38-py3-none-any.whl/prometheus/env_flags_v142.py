"""Round 142: 12 additional environment-variable flags.

  * PROMETHEUS_MAX_TOOL_USE_CONCURRENCY    int, default 10
  * PROMETHEUS_AUTO_COMPACT_WINDOW         int, override window
  * PROMETHEUS_MAX_OUTPUT_TOKENS           int, override
  * PROMETHEUS_MAX_RETRIES                 int, default 3
  * PROMETHEUS_BLOCKING_LIMIT_OVERRIDE     int, override
  * PROMETHEUS_AUTOCOMPACT_PCT             int 0..100, default 80
  * PROMETHEUS_DISABLE_CHARTER             bool
  * PROMETHEUS_DISABLE_COMMAND_INJECTION_CHECK  bool
  * PROMETHEUS_UNATTENDED_RETRY            bool
  * PROMETHEUS_FRAME_TIMING_LOG=/path      str (path)
  * PROMETHEUS_BASH_SANDBOX_INDICATOR      bool
  * PROMETHEUS_SYNTAX_HIGHLIGHT            bool
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


_TRUTHY = ("1", "true", "yes", "on")


def _flag(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name, "").strip().lower()
    if not raw:
        return default
    return raw in _TRUTHY


def _int_env(name: str, default: int, *, lo: int = 0, hi: int = 1_000_000_000) -> int:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        n = int(raw)
    except ValueError:
        return default
    return max(lo, min(hi, n))


# ---------- concurrency / retries ----------


def _int_env_aliased(*names: str, default: int, lo: int, hi: int) -> int:
    """1.0.3: read first non-empty env in `names`. Lets CC migrants
    keep their existing env knobs (`CLAUDE_CODE_MAX_RETRIES`,
    `CLAUDE_CODE_MAX_TOOL_USE_CONCURRENCY`) without renaming."""
    for n in names:
        raw = os.environ.get(n, "").strip()
        if raw:
            try:
                return max(lo, min(hi, int(raw)))
            except ValueError:
                continue
    return default


def max_tool_use_concurrency() -> int:
    return _int_env_aliased(
        "PROMETHEUS_MAX_TOOL_USE_CONCURRENCY",
        "CLAUDE_CODE_MAX_TOOL_USE_CONCURRENCY",
        default=10, lo=1, hi=64,
    )


def max_retries() -> int:
    return _int_env_aliased(
        "PROMETHEUS_MAX_RETRIES",
        "CLAUDE_CODE_MAX_RETRIES",
        default=3, lo=0, hi=20,
    )


def unattended_retry_enabled() -> bool:
    """Round 142: when set, the provider retry loop runs without
    the usual cap (CI mode)."""
    return _flag("PROMETHEUS_UNATTENDED_RETRY")


def effective_max_retries() -> int:
    """Round 142: combine `--unattended-retry` with the cap.
    Unattended → very large; otherwise honor the env."""
    if unattended_retry_enabled():
        return 1_000_000
    return max_retries()


# ---------- compact + window overrides ----------


def auto_compact_window() -> Optional[int]:
    """Round 142: hard override for the compact target. None
    when unset → use the model's reported context window."""
    raw = os.environ.get(
        "PROMETHEUS_AUTO_COMPACT_WINDOW", "",
    ).strip()
    if not raw:
        return None
    try:
        n = int(raw)
        return max(1024, n)
    except ValueError:
        return None


def autocompact_pct() -> int:
    return _int_env("PROMETHEUS_AUTOCOMPACT_PCT", 80, lo=1, hi=100)


def autocompact_threshold_tokens(
    *, context_window: int,
) -> int:
    """Round 142: how many tokens before auto-compact triggers.
    Honors the override window first, then the percentage."""
    target = auto_compact_window() or context_window
    pct = autocompact_pct()
    return max(1024, int(target * pct / 100))


# ---------- output / blocking ----------


def max_output_tokens() -> Optional[int]:
    raw = os.environ.get(
        "PROMETHEUS_MAX_OUTPUT_TOKENS", "",
    ).strip()
    if not raw:
        return None
    try:
        n = int(raw)
        return max(1, n)
    except ValueError:
        return None


def blocking_limit_override() -> Optional[int]:
    """Round 142: override the rate-limit-blocking threshold
    that triggers the configured fallback strategy."""
    raw = os.environ.get(
        "PROMETHEUS_BLOCKING_LIMIT_OVERRIDE", "",
    ).strip()
    if not raw:
        return None
    try:
        n = int(raw)
        return max(0, n)
    except ValueError:
        return None


# ---------- security toggles ----------


def charter_disabled() -> bool:
    """Round 142: skip Charter (PROMETHEUS.md) loading."""
    return _flag("PROMETHEUS_DISABLE_CHARTER")


def command_injection_check_disabled() -> bool:
    """Round 142: opt-out of the prose-as-bash-command guard
    from round-94. **Use with extreme caution** — this guard
    blocks a real attack class (an LLM emitting a model-
    smuggled prose payload that the shell tool then executes)."""
    return _flag("PROMETHEUS_DISABLE_COMMAND_INJECTION_CHECK")


# ---------- diagnostics ----------


def frame_timing_log_path() -> Optional[Path]:
    """Round 142: when set, the renderer logs every frame's
    timing to this file. Useful for chasing dropped frames."""
    raw = os.environ.get(
        "PROMETHEUS_FRAME_TIMING_LOG", "",
    ).strip()
    if not raw:
        return None
    return Path(raw).expanduser()


def append_frame_timing(
    *, kind: str, ms: float, detail: str = "",
) -> bool:
    """Round 142: append one row to the frame-timing log.
    Returns True on success."""
    path = frame_timing_log_path()
    if path is None:
        return False
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"{kind}\t{ms:.3f}\t{detail}\n")
        return True
    except OSError:
        return False


# ---------- UI toggles ----------


def bash_sandbox_indicator_enabled() -> bool:
    return _flag("PROMETHEUS_BASH_SANDBOX_INDICATOR")


def syntax_highlight_enabled() -> bool:
    return _flag("PROMETHEUS_SYNTAX_HIGHLIGHT")


# ---------- summary ----------


@dataclass
class V142Summary:
    max_tool_use_concurrency: int
    max_retries: int
    effective_max_retries: int
    auto_compact_window: Optional[int]
    autocompact_pct: int
    max_output_tokens: Optional[int]
    blocking_limit_override: Optional[int]
    charter_disabled: bool
    command_injection_check_disabled: bool
    unattended_retry_enabled: bool
    frame_timing_log_path: Optional[str]
    bash_sandbox_indicator_enabled: bool
    syntax_highlight_enabled: bool


def env_flag_summary_v142() -> V142Summary:
    fp = frame_timing_log_path()
    return V142Summary(
        max_tool_use_concurrency=max_tool_use_concurrency(),
        max_retries=max_retries(),
        effective_max_retries=effective_max_retries(),
        auto_compact_window=auto_compact_window(),
        autocompact_pct=autocompact_pct(),
        max_output_tokens=max_output_tokens(),
        blocking_limit_override=blocking_limit_override(),
        charter_disabled=charter_disabled(),
        command_injection_check_disabled=
            command_injection_check_disabled(),
        unattended_retry_enabled=unattended_retry_enabled(),
        frame_timing_log_path=str(fp) if fp else None,
        bash_sandbox_indicator_enabled=
            bash_sandbox_indicator_enabled(),
        syntax_highlight_enabled=syntax_highlight_enabled(),
    )
