"""Round 169 / A2 — Diff-based screen rendering (`VirtualScreen`).

Claude Code's custom Ink-based renderer keeps two grids: the
*current* grid (what's on screen) and the *next* grid (what we
want to show). On a frame tick it compares them cell-by-cell
and emits ANSI moves + writes only for the differences. With
a 120×40 terminal that's 4,800 cells; a typical streaming tick
changes 5-50 of them, so the bandwidth saving is two orders of
magnitude over a full repaint.

Public API:

  - `VirtualScreen(rows, cols)` — pair of grids initialised to
    blank.
  - `set_cell(row, col, ch)` — stage a change on the *next* grid.
  - `set_row(row, text)` — convenience that stages a whole row.
  - `diff_render() → list[Patch]` — compute the changes vs. the
    current grid, advance the current grid to match next, and
    return the patches the host should write.
  - `Patch.to_ansi()` — emit the ANSI sequence for one patch.
  - `clear()` — blank both grids (used after a layout shift).

This module owns no Textual import; it's the pure-data layer
the host's render loop calls. Tests assert the patch shape
without any terminal IO.
"""
from __future__ import annotations

from dataclasses import dataclass, field


# ---- patch ---------------------------------------------------


@dataclass(frozen=True)
class Patch:
    """A run of changed characters on one row, starting at
    `col`. The host writes:
        \x1b[<row+1>;<col+1>H<text>
    to apply it."""
    row: int
    col: int
    text: str

    def to_ansi(self) -> str:
        # Cursor positioning is 1-indexed in ANSI.
        return f"\x1b[{self.row + 1};{self.col + 1}H{self.text}"


# ---- the virtual screen --------------------------------------


@dataclass
class VirtualScreen:
    """Round 169 / A2: pair of grids backing the diff-based
    renderer."""
    rows: int
    cols: int
    current: list[list[str]] = field(default_factory=list)
    """What's on screen *right now*. After each `diff_render()`
    call this is brought into sync with `next`."""
    next: list[list[str]] = field(default_factory=list)
    """The frame we want to show. Populated via `set_cell` /
    `set_row` between `diff_render()` calls."""

    def __post_init__(self) -> None:
        if not self.current:
            self.current = [[" "] * self.cols for _ in range(self.rows)]
        if not self.next:
            self.next = [[" "] * self.cols for _ in range(self.rows)]

    # ---- staging API ----

    def set_cell(self, row: int, col: int, ch: str) -> None:
        """Stage a single-character change on the *next* grid.
        Out-of-bounds writes are silently dropped — the host
        layer is responsible for clipping."""
        if 0 <= row < self.rows and 0 <= col < self.cols:
            # Normalise to a single character (or space). Multi-
            # char strings would corrupt the grid; the caller
            # should use `set_row` for those.
            self.next[row][col] = ch[:1] if ch else " "

    def set_row(self, row: int, text: str) -> None:
        """Stage a whole row. `text` is left-padded with spaces
        and right-truncated to fit `cols`."""
        if not (0 <= row < self.rows):
            return
        # Pad / truncate to the row width.
        padded = (text or "")[: self.cols].ljust(self.cols, " ")
        self.next[row] = list(padded)

    def clear(self) -> None:
        """Blank both grids — used after a layout shift so the
        next render rewrites the entire screen."""
        for r in range(self.rows):
            for c in range(self.cols):
                self.current[r][c] = " "
                self.next[r][c] = " "

    # ---- diff renderer ----

    def diff_render(self) -> list[Patch]:
        """Round 169 / A2: compute the change set, advance
        `current` to match `next`, return the patches.

        The implementation walks each row coalescing runs of
        consecutive changed cells into a single Patch — that's
        the best single-row optimisation: one cursor move +
        one write per run instead of per cell.
        """
        patches: list[Patch] = []
        for r in range(self.rows):
            cur_row = self.current[r]
            nxt_row = self.next[r]
            c = 0
            while c < self.cols:
                if cur_row[c] != nxt_row[c]:
                    # Start of a run. Walk until the cells match again.
                    start = c
                    chars: list[str] = []
                    while c < self.cols and cur_row[c] != nxt_row[c]:
                        chars.append(nxt_row[c])
                        cur_row[c] = nxt_row[c]
                        c += 1
                    patches.append(
                        Patch(row=r, col=start, text="".join(chars))
                    )
                else:
                    c += 1
        return patches

    # ---- diagnostics ----

    def changed_cell_count(self) -> int:
        """How many cells differ between `current` and `next`.
        The host can use this for telemetry / `/stats`."""
        n = 0
        for r in range(self.rows):
            for c in range(self.cols):
                if self.current[r][c] != self.next[r][c]:
                    n += 1
        return n

    def total_cells(self) -> int:
        return self.rows * self.cols


def render_patches_to_ansi(patches: list[Patch]) -> str:
    """Round 169: concatenate `Patch.to_ansi()` for each patch.
    The host writes this single string to stdout."""
    return "".join(p.to_ansi() for p in patches)
