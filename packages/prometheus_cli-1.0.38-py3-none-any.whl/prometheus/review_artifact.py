"""Round 145-final: ReviewArtifact tool.

The agent reviews its own generated code artifact and returns
a structured quality assessment:

  * Style compliance (line length, trailing whitespace,
    consistent indentation)
  * Test coverage hint (has matching test file?)
  * Potential issues (TODOs, FIXMEs, debug prints, hard-coded
    secrets, broad except clauses)

Pure heuristic — no model call. The agent calls the tool;
when something looks worth re-reading, the agent reads the
file and investigates.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from prometheus.tools.base import (
    Tool, SideEffect, ToolContext, ToolResult,
)


# ---------- heuristic checks ----------


_STYLE_LIMIT = 120     # max line length (warn-level)
_CHECKS: tuple[tuple[str, str, re.Pattern[str], int], ...] = (
    # (name, description, regex, severity 1..3)
    ("todo", "TODO marker",
     re.compile(r"\b(?:TODO|FIXME|XXX|HACK)\b"), 1),
    ("debug_print", "debug print statement",
     re.compile(r"\b(?:print\(|console\.log\(|fmt\.Println\()"), 1),
    ("broad_except", "bare except clause",
     re.compile(r"^\s*except\s*:\s*$", re.MULTILINE), 2),
    ("hardcoded_secret", "possible hard-coded secret",
     re.compile(
        r"(?i)(?:api[_-]?key|secret|password|token)\s*[:=]\s*"
        r"['\"][^'\"\s]{8,}['\"]"
     ), 3),
    ("eval", "eval / exec usage",
     re.compile(r"\b(?:eval|exec)\s*\("), 3),
    ("subprocess_shell_true", "subprocess shell=True",
     re.compile(r"shell\s*=\s*True"), 2),
)


_PATH_TO_TEST_FILE: tuple[tuple[str, str], ...] = (
    # (source-glob, test-glob)
    (".py",  "test_*.py"),
    (".ts",  "*.test.ts"),
    (".tsx", "*.test.tsx"),
    (".js",  "*.test.js"),
    (".rs",  "*_test.rs"),
    (".go",  "*_test.go"),
)


# ---------- assessment ----------


@dataclass
class Issue:
    name: str
    description: str
    severity: int
    line: int
    snippet: str


@dataclass
class ArtifactAssessment:
    path: str
    line_count: int
    long_lines: list[int] = field(default_factory=list)
    trailing_whitespace_lines: list[int] = field(default_factory=list)
    has_test_file: bool = False
    issues: list[Issue] = field(default_factory=list)

    @property
    def issue_count(self) -> int:
        return len(self.issues)

    @property
    def severity_score(self) -> int:
        return sum(i.severity for i in self.issues)

    def summary_line(self) -> str:
        return (
            f"{self.path}: {self.line_count} lines, "
            f"{self.issue_count} issue(s), "
            f"severity {self.severity_score}"
        )


def assess_text(text: str, *, path: str = "") -> ArtifactAssessment:
    """Round 145-final: pure-python heuristic pass over the
    file body."""
    a = ArtifactAssessment(path=path, line_count=0)
    if not text:
        return a
    lines = text.splitlines()
    a.line_count = len(lines)
    for i, line in enumerate(lines, 1):
        if len(line) > _STYLE_LIMIT:
            a.long_lines.append(i)
        if line != line.rstrip():
            a.trailing_whitespace_lines.append(i)
        for name, desc, rx, sev in _CHECKS:
            for m in rx.finditer(line):
                a.issues.append(Issue(
                    name=name,
                    description=desc,
                    severity=sev,
                    line=i,
                    snippet=line.strip()[:120],
                ))
    return a


def has_matching_test_file(
    *, path: Path, workdir: Path,
) -> bool:
    """Round 145-final: cheap matching-test-file probe."""
    if not path.exists():
        return False
    for source_ext, test_glob in _PATH_TO_TEST_FILE:
        if path.suffix == source_ext:
            stem = path.stem
            test_glob_re = test_glob.replace(
                "*", stem,
            )
            for cand in workdir.rglob(test_glob_re):
                if cand.is_file():
                    return True
            return False
    return False


def assess_file(
    path: Path, *, workdir: Path,
) -> ArtifactAssessment:
    """Round 145-final: read + assess. Returns an empty
    assessment when the file doesn't exist."""
    if not path.exists() or not path.is_file():
        return ArtifactAssessment(path=str(path), line_count=0)
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ArtifactAssessment(path=str(path), line_count=0)
    a = assess_text(text, path=str(path))
    a.has_test_file = has_matching_test_file(
        path=path, workdir=workdir,
    )
    return a


def render_assessment(a: ArtifactAssessment) -> str:
    lines = [f"review: {a.summary_line()}"]
    if a.long_lines:
        lines.append(
            f"  long lines (> {_STYLE_LIMIT} chars): "
            f"{len(a.long_lines)} (e.g. line {a.long_lines[0]})"
        )
    if a.trailing_whitespace_lines:
        lines.append(
            f"  trailing whitespace on {len(a.trailing_whitespace_lines)} line(s)"
        )
    if a.path and a.line_count:
        lines.append(
            f"  test file: {'present' if a.has_test_file else 'missing'}"
        )
    if a.issues:
        lines.append("  issues:")
        for i in sorted(a.issues, key=lambda x: -x.severity)[:10]:
            sev = "•" * i.severity
            lines.append(
                f"    {sev:3s} line {i.line:>4}  {i.name:24s}  "
                f"{i.snippet[:60]}"
            )
    return "\n".join(lines)


# ---------- the Tool ----------


class ReviewArtifact(Tool):
    """Round 145-final: review a code artifact for style +
    quality issues."""
    name = "review_artifact"
    description = (
        "Review a code file for style compliance, test "
        "coverage, and potential issues. Pure heuristic — "
        "no network, no model call."
    )
    schema = {
        "type": "object",
        "properties": {"path": {"type": "string"}},
        "required": ["path"],
    }
    side_effect = SideEffect.READ

    async def execute(
        self, args: dict[str, Any], ctx: ToolContext,
    ) -> ToolResult:
        path_str = str(args.get("path", "")).strip()
        if not path_str:
            return ToolResult(
                error=True, output="path is required",
            )
        path = Path(path_str)
        if not path.is_absolute():
            path = ctx.workdir / path
        if not path.exists():
            return ToolResult(
                error=True, output=f"not found: {path}",
            )
        a = assess_file(path, workdir=ctx.workdir)
        return ToolResult(
            error=False,
            output=render_assessment(a),
            summary=a.summary_line(),
        )
