"""Round 144-final: independent verification agent.

After the main agent completes a task, an independent verifier
checks the output against success criteria. The verifier
returns a structured `VerificationVerdict` with pass/fail +
reasons + suggested retries.

Pure data layer + a deterministic checklist. The host's
`/verify` command consumes the verdict; when it fails, the
agent loop receives the feedback as a system message.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Optional


# ---------- success-criteria checks ----------


@dataclass
class CriterionResult:
    name: str
    ok: bool
    detail: str = ""


@dataclass
class VerificationVerdict:
    passed: bool
    score: int               # 0..100
    criteria: list[CriterionResult] = field(default_factory=list)
    suggested_retry: str = ""


def verify(
    *,
    user_prompt: str,
    agent_output: str,
    files_modified: Optional[list[str]] = None,
    test_run_passed: Optional[bool] = None,
    success_criteria: Optional[list[str]] = None,
) -> VerificationVerdict:
    """Round 144-final: deterministic verification. Each check
    is independent; the verdict is the AND of every check
    plus a 0..100 score.

    Default checks:
      1. The agent produced *some* output.
      2. The output addresses the user's prompt (token overlap).
      3. If files were modified, the user's prompt mentioned
         change vocabulary.
      4. If `test_run_passed` is supplied, it's True.
      5. Each `success_criteria` string appears in the output.
    """
    rows: list[CriterionResult] = []

    # 1. non-empty
    has_output = bool((agent_output or "").strip())
    rows.append(CriterionResult(
        name="non_empty_output",
        ok=has_output,
        detail=("ok" if has_output else "agent emitted no text"),
    ))

    # 2. token overlap with prompt
    prompt_tokens = _tokenize(user_prompt)
    output_tokens = _tokenize(agent_output)
    overlap = (
        len(prompt_tokens & output_tokens)
        if prompt_tokens else 0
    )
    addresses = overlap >= max(1, len(prompt_tokens) // 4)
    rows.append(CriterionResult(
        name="addresses_prompt",
        ok=addresses or len(prompt_tokens) <= 2,
        detail=f"{overlap} shared token(s) with prompt",
    ))

    # 3. file-change vocabulary alignment
    if files_modified:
        change_words = (
            "edit", "modify", "fix", "add", "remove",
            "delete", "create", "write", "update", "rename",
            "refactor", "implement", "build", "scaffold",
        )
        body = (user_prompt or "").lower()
        mentions_change = any(w in body for w in change_words)
        rows.append(CriterionResult(
            name="file_change_aligned_with_intent",
            ok=mentions_change,
            detail=(
                "ok" if mentions_change
                else f"modified {len(files_modified)} file(s) but prompt has no change vocabulary"
            ),
        ))

    # 4. tests
    if test_run_passed is not None:
        rows.append(CriterionResult(
            name="tests_passed",
            ok=bool(test_run_passed),
            detail=("ok" if test_run_passed else "test run failed"),
        ))

    # 5. user-supplied criteria
    if success_criteria:
        body_low = (agent_output or "").lower()
        for crit in success_criteria:
            c = (crit or "").strip()
            if not c:
                continue
            present = c.lower() in body_low
            rows.append(CriterionResult(
                name=f"criterion: {c[:40]}",
                ok=present,
                detail=("present" if present else "absent in output"),
            ))

    passed = all(r.ok for r in rows) if rows else False
    score = (
        100 * sum(1 for r in rows if r.ok) // len(rows)
        if rows else 0
    )
    suggested = ""
    if not passed:
        failed = [r.name for r in rows if not r.ok]
        suggested = (
            "retry with attention to: "
            + ", ".join(failed[:3])
        )
    return VerificationVerdict(
        passed=passed,
        score=score,
        criteria=rows,
        suggested_retry=suggested,
    )


_TOKEN_RX = re.compile(r"[A-Za-z][A-Za-z0-9_]{2,}")
_STOPWORDS = frozenset({
    "the", "and", "for", "with", "that", "this", "into",
    "from", "have", "will", "your", "you", "are", "but",
    "not", "all", "any", "can", "use", "make", "let", "get",
    "should", "would", "could", "what", "when", "where", "how",
})


def _tokenize(text: str) -> set[str]:
    return {
        m.group(0).lower() for m in _TOKEN_RX.finditer(text or "")
        if m.group(0).lower() not in _STOPWORDS
    }


# ---------- rendering ----------


def render_verdict(v: VerificationVerdict) -> str:
    head = (
        f"verification: {'PASS' if v.passed else 'FAIL'}  "
        f"({v.score}/100)"
    )
    lines = [head]
    for r in v.criteria:
        glyph = "✓" if r.ok else "✗"
        lines.append(f"  {glyph} {r.name:36s}  {r.detail}")
    if not v.passed and v.suggested_retry:
        lines.append("")
        lines.append(f"  → {v.suggested_retry}")
    return "\n".join(lines)


# ---------- /verify slash arg parser ----------


def parse_verify_arg(arg: str) -> dict[str, Any]:
    """Round 144-final: support free-text criteria via
    `/verify must contain X | should mention Y`."""
    raw = (arg or "").strip()
    if not raw:
        return {"success_criteria": []}
    parts = [p.strip() for p in raw.split("|") if p.strip()]
    return {"success_criteria": parts}
