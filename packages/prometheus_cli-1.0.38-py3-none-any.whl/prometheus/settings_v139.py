"""Round 139: 18 new settings keys.

  * autoDreamEnabled (bool)
  * availableModels (list[str])
  * alwaysThinkingEnabled (bool)
  * showTurnDuration (bool)
  * terminalProgressBarEnabled (bool)
  * spinnerTipsEnabled (bool)
  * spinnerTipsOverride (str)
  * prefersReducedMotion (bool)
  * feedbackSurveyRate (float in [0,1])
  * disableDeepLinkRegistration (str — `disable` only meaningful)
  * showThinkingSummaries (bool)
  * viewMode (`default`/`verbose`/`focus`)
  * prUrlTemplate (str — supports {owner}/{repo}/{number})
  * skipWebFetchPreflight (bool)
  * voice (object: enabled/mode/autoSubmit)
  * editorMode (str — `default`/`vim`/`emacs`)
  * autoConnectIde (bool)
  * autoInstallIdeExtension (bool)
  * defaultShell (`bash`/`powershell`/auto-detected)
"""
from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field
from typing import Any, Optional


_TRUTHY = ("1", "true", "yes", "on")


def _b(value: Any, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in _TRUTHY
    return default


def _f(value: Any, default: float, *, lo: float = 0.0, hi: float = 1.0) -> float:
    try:
        v = float(value)
    except (TypeError, ValueError):
        return default
    if v < lo or v > hi:
        return default
    return v


def _s(value: Any, default: str) -> str:
    return str(value).strip() if isinstance(value, str) and value.strip() else default


# ---------- bool settings ----------


def auto_dream_enabled(setting: Any = None) -> bool:
    """Round 139: background dream consolidation. Default True."""
    return _b(setting, True)


def always_thinking_enabled(setting: Any = None) -> bool:
    """Round 139: extended thinking on by default."""
    return _b(setting, False)


def show_turn_duration(setting: Any = None) -> bool:
    return _b(setting, True)


def terminal_progress_bar_enabled(setting: Any = None) -> bool:
    return _b(setting, True)


def spinner_tips_enabled(setting: Any = None) -> bool:
    return _b(setting, True)


def prefers_reduced_motion(setting: Any = None) -> bool:
    """Round 139: accessibility — disable spinners + animations."""
    return _b(setting, False)


def show_thinking_summaries(setting: Any = None) -> bool:
    return _b(setting, False)


def skip_web_fetch_preflight(setting: Any = None) -> bool:
    return _b(setting, False)


def auto_connect_ide(setting: Any = None) -> bool:
    return _b(setting, False)


def auto_install_ide_extension(setting: Any = None) -> bool:
    return _b(setting, False)


# ---------- list / str settings ----------


def available_models(setting: Any = None) -> list[str]:
    """Round 139: when set, restrict /model to these ids/aliases.
    Empty list = no restriction."""
    if not isinstance(setting, list):
        return []
    return [str(s).strip() for s in setting if str(s).strip()]


def spinner_tips_override(setting: Any = None) -> Optional[str]:
    """Round 139: forces a single tip string when set."""
    if not isinstance(setting, str):
        return None
    s = setting.strip()
    return s or None


_VALID_VIEW_MODES = ("default", "verbose", "focus")


def view_mode(setting: Any = None) -> str:
    v = _s(setting, "default").lower()
    return v if v in _VALID_VIEW_MODES else "default"


_VALID_EDITOR_MODES = ("default", "vim", "emacs")


def editor_mode(setting: Any = None) -> str:
    v = _s(setting, "default").lower()
    return v if v in _VALID_EDITOR_MODES else "default"


def deep_link_disabled(setting: Any = None) -> bool:
    """Round 139: any setting value of `disable` (case-insensitive)
    counts as disabled."""
    if not isinstance(setting, str):
        return False
    return setting.strip().lower() == "disable"


def feedback_survey_rate(setting: Any = None) -> float:
    """Round 139: post-session survey probability in [0, 1].
    Default 0 (off)."""
    return _f(setting, 0.0, lo=0.0, hi=1.0)


def pr_url_template(setting: Any = None) -> str:
    """Round 139: custom URL template. Default = GitHub PR URL.
    Supports {owner}/{repo}/{number} placeholders."""
    return _s(
        setting,
        "https://github.com/{owner}/{repo}/pull/{number}",
    )


def render_pr_url(
    template: str, *, owner: str, repo: str, number: int,
) -> str:
    """Round 139: substitute placeholders in the PR URL template."""
    return (
        template
        .replace("{owner}", owner)
        .replace("{repo}", repo)
        .replace("{number}", str(number))
    )


# ---------- shell ----------


def default_shell(setting: Any = None) -> str:
    """Round 139: bash on POSIX, powershell on Windows by default;
    user can override with `bash`/`powershell`."""
    raw = _s(setting, "").lower()
    if raw in ("bash", "powershell", "pwsh", "sh", "zsh"):
        return "powershell" if raw in ("powershell", "pwsh") else "bash"
    return "powershell" if sys.platform.startswith("win") else "bash"


# ---------- voice ----------


@dataclass
class VoiceConfig:
    enabled: bool = False
    mode: str = "push-to-talk"
    auto_submit: bool = False


_VALID_VOICE_MODES = ("push-to-talk", "vad", "always-on")


def voice_config(setting: Any = None) -> VoiceConfig:
    """Round 139: voice dictation configuration."""
    if not isinstance(setting, dict):
        return VoiceConfig()
    mode = _s(setting.get("mode"), "push-to-talk").lower()
    if mode not in _VALID_VOICE_MODES:
        mode = "push-to-talk"
    return VoiceConfig(
        enabled=_b(setting.get("enabled"), False),
        mode=mode,
        auto_submit=_b(setting.get("autoSubmit"), False),
    )


# ---------- summary ----------


def settings_v139_summary(settings: dict) -> dict[str, Any]:
    """Round 139: resolve every round-139 key from a settings
    dict, applying defaults. The host calls this once at launch
    and threads the resolved values through the runtime."""
    s = settings if isinstance(settings, dict) else {}
    return {
        "autoDreamEnabled":
            auto_dream_enabled(s.get("autoDreamEnabled")),
        "availableModels":
            available_models(s.get("availableModels")),
        "alwaysThinkingEnabled":
            always_thinking_enabled(s.get("alwaysThinkingEnabled")),
        "showTurnDuration":
            show_turn_duration(s.get("showTurnDuration")),
        "terminalProgressBarEnabled":
            terminal_progress_bar_enabled(
                s.get("terminalProgressBarEnabled"),
            ),
        "spinnerTipsEnabled":
            spinner_tips_enabled(s.get("spinnerTipsEnabled")),
        "spinnerTipsOverride":
            spinner_tips_override(s.get("spinnerTipsOverride")),
        "prefersReducedMotion":
            prefers_reduced_motion(s.get("prefersReducedMotion")),
        "feedbackSurveyRate":
            feedback_survey_rate(s.get("feedbackSurveyRate")),
        "disableDeepLinkRegistration":
            deep_link_disabled(s.get("disableDeepLinkRegistration")),
        "showThinkingSummaries":
            show_thinking_summaries(s.get("showThinkingSummaries")),
        "viewMode": view_mode(s.get("viewMode")),
        "prUrlTemplate": pr_url_template(s.get("prUrlTemplate")),
        "skipWebFetchPreflight":
            skip_web_fetch_preflight(s.get("skipWebFetchPreflight")),
        "voice": voice_config(s.get("voice")),
        "editorMode": editor_mode(s.get("editorMode")),
        "autoConnectIde":
            auto_connect_ide(s.get("autoConnectIde")),
        "autoInstallIdeExtension":
            auto_install_ide_extension(
                s.get("autoInstallIdeExtension"),
            ),
        "defaultShell": default_shell(s.get("defaultShell")),
        # 1.0.3: Claude Code v2.1.105+ parity — UI language,
        # plans/auto-memory directory paths, and the file-suggestion
        # `@`-mention configuration object.
        "language": ui_language(s.get("language")),
        "plansDirectory": plans_directory(s.get("plansDirectory")),
        "autoMemoryDirectory":
            auto_memory_directory(s.get("autoMemoryDirectory")),
        "fileSuggestion":
            file_suggestion_config(s.get("fileSuggestion")),
        # 1.0.3 (CC v2.1.105–v2.1.132 reference parity):
        "showClearContextOnPlanAccept":
            show_clear_context_on_plan_accept(
                s.get("showClearContextOnPlanAccept"),
            ),
        "includeCoAuthoredBy":
            include_co_authored_by(s.get("includeCoAuthoredBy")),
        "apiKeyHelper": api_key_helper(s.get("apiKeyHelper")),
        "otelHeadersHelper":
            otel_headers_helper(s.get("otelHeadersHelper")),
    }


# ---------- 1.0.3 final reference-parity additions ----------


def show_clear_context_on_plan_accept(setting: Any = None) -> bool:
    """1.0.3: when True, accepting a plan via /plan-accept clears
    the conversation context (the plan becomes the new starting
    point). Default False — preserves backwards-compatible
    behaviour where context is preserved across plan acceptance."""
    return _b(setting, False)


def include_co_authored_by(setting: Any = None) -> bool:
    """1.0.3: when True, Prometheus appends a `Co-Authored-By:`
    trailer to commits it generates. Default True — matches the
    historical `attribution.commit` behaviour. The CC reference
    documents this key as deprecated; honour it for migrating
    users while a future round can fold it into `attribution.commit`."""
    return _b(setting, True)


def api_key_helper(setting: Any = None) -> str:
    """1.0.3: path to a script that prints the API key on stdout.
    Empty string (default) means "use the env-var route" —
    Prometheus's 13-provider key pool reads from
    `PROMETHEUS_API_KEY` / `OPENROUTER_API_KEY` / etc. directly,
    so this is advisory and primarily for CC-migrant settings
    files; the actual helper-script-execution path is currently
    a no-op (security: arbitrary-script execution from a settings
    file is a classic supply-chain hole and requires a Forge Kit
    consent gate before we wire it through)."""
    return _s(setting, "")


def otel_headers_helper(setting: Any = None) -> str:
    """1.0.3: path to a script that prints OTLP headers on stdout
    (e.g. `Authorization: Bearer ...`). Empty string (default)
    means "no helper" — Prometheus reads OTLP headers directly
    from the standard `OTEL_EXPORTER_OTLP_HEADERS` env var. Like
    `apiKeyHelper`, this key is honoured at the schema level so
    settings files copied from Claude Code parse cleanly; helper-
    script execution is gated behind the same consent flow."""
    return _s(setting, "")


# ---------- 1.0.3: CC v2.1.105+ parity additions ----------


_VALID_LANGUAGES = (
    "en", "en-US", "en-GB",
    "fr", "fr-FR", "de", "de-DE", "es", "es-ES",
    "it", "it-IT", "pt", "pt-BR", "pt-PT",
    "ja", "ja-JP", "ko", "ko-KR",
    "zh", "zh-CN", "zh-TW", "zh-Hans", "zh-Hant",
    "ru", "ru-RU", "ar", "ar-SA",
    "nl", "nl-NL", "pl", "pl-PL", "sv", "sv-SE",
    "tr", "tr-TR",
)


def ui_language(setting: Any = None) -> str:
    """1.0.3 (CC v2.1.105 parity): UI language code. Defaults to
    `en`. Unrecognised tags fall back to the default rather than
    raising — Prometheus's UI is English-only today, so this is
    advisory configuration that downstream renderers can honour
    as i18n is added."""
    val = _s(setting, "en")
    return val if val in _VALID_LANGUAGES else "en"


def plans_directory(setting: Any = None) -> str:
    """1.0.3: filesystem path for `/plan` artefacts. Empty string
    means "use the default" (`~/.prometheus/plans/`)."""
    return _s(setting, "")


def auto_memory_directory(setting: Any = None) -> str:
    """1.0.3: filesystem path for the autonomous Dreams memory
    directory. Empty string means "use the default"
    (`~/.prometheus/memory/`). When set, `consolidate_memories`
    operates on this path instead of the default."""
    return _s(setting, "")


_VALID_FILE_SUGGESTION_TYPES = ("default", "custom", "off")


@dataclass
class FileSuggestionConfig:
    """1.0.3 (CC v2.1.105 parity): @-mention autocomplete.

    `type=default` uses the built-in glob-based suggester.
    `type=custom` shells out to `command` whose stdout (one path
      per line) provides candidates.
    `type=off` disables suggestions.
    """
    type: str = "default"
    command: str = ""


def file_suggestion_config(setting: Any = None) -> FileSuggestionConfig:
    if not isinstance(setting, dict):
        return FileSuggestionConfig()
    type_ = _s(setting.get("type"), "default").lower()
    if type_ not in _VALID_FILE_SUGGESTION_TYPES:
        type_ = "default"
    command = _s(setting.get("command"), "")
    if type_ == "custom" and not command:
        # `custom` without a command falls back to default rather
        # than silently doing nothing.
        type_ = "default"
        command = ""
    return FileSuggestionConfig(type=type_, command=command)
