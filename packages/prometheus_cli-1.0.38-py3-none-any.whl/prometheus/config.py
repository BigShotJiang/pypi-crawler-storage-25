"""Configuration: env loading, paths, defaults.

Single place to read environment variables. Never reads them elsewhere.
"""
from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv
from platformdirs import user_data_dir, user_config_dir

# Round-27 P0: bounded .env discovery. Previously walked all the way
# to filesystem root, which is a config-injection vector — a hostile
# parent dir could plant a `.env` with overriding API keys / spending
# caps. Now we only consider workdir + HOME (and strict descendants
# of HOME). Anything above HOME requires explicit /trust to opt in.
def _load_env() -> None:
    """Round-60: search order for .env files.

    1. Workdir + parents up to HOME (existing behaviour — round 27)
    2. Package install directory's parent (the project repo when
       running `pip install -e .`, or the user-level config when
       running from a wheel install). This lets `prometheus` work
       from ANY directory once the user has put their keys in the
       repo's .env file.
    3. ~/.prometheus/.env — user-level fallback for wheel installs.

    Round-27 P0 still holds: never walk above HOME from cwd. The
    install-dir / user-config lookups are explicit allowlist paths,
    not a parent-walk.
    """
    cur = Path.cwd().resolve()
    try:
        home = Path.home().resolve()
    except (OSError, RuntimeError):
        home = None
    seen: set[Path] = set()
    # 1. cwd → HOME walk
    for d in [cur, *cur.parents]:
        if d in seen:
            break
        seen.add(d)
        if home is not None and not str(d).startswith(str(home)) and d != cur:
            break
        env = d / ".env"
        if env.exists():
            load_dotenv(env, override=False)
            return
    # 2. Package-install dir — `prometheus.__file__`'s parent is the
    # `prometheus/` package; its parent is the repo root (or the
    # site-packages dir for wheel installs).
    try:
        import prometheus as _pkg
        pkg_dir = Path(_pkg.__file__).resolve().parent.parent
        env = pkg_dir / ".env"
        if env.exists():
            load_dotenv(env, override=False)
            return
    except Exception:
        pass
    # 3. ~/.prometheus/.env — wheel-install user-config fallback
    if home is not None:
        env = home / ".prometheus" / ".env"
        if env.exists():
            load_dotenv(env, override=False)
            return

_load_env()

APP_NAME = "prometheus"
USER_DATA_DIR = Path(user_data_dir(APP_NAME, appauthor=False))
USER_CONFIG_DIR = Path(user_config_dir(APP_NAME, appauthor=False))
SESSION_DB = USER_DATA_DIR / "sessions.db"
USER_MEMORY = USER_CONFIG_DIR / "PROMETHEUS.md"
LOG_DIR = USER_DATA_DIR / "logs"


# Free-tier OpenRouter models, organized by role. The router picks based
# on the task at hand and walks the chain on 429/5xx. All listed IDs
# were live on OpenRouter as of 2026-05; the audit's "model availability
# probe" (collect()'s sanitize-then-fall-back) skips dead routes.
#
# Role chains (best-first; each falls back to the next):
#   coder    — default for code edits / search / multi-file work
#   planner  — plan mode, architecture, hard debugging (reasoning models)
#   fast     — compaction, summarization, commit messages, micro tasks
#   vision   — image-paste / screenshot-attach flows
#
# The flat FREE_MODELS_PREFERRED list is what OpenRouter's `models` body
# field accepts; it's the union of all chains, primary roles first. The
# OpenRouter gateway caps `models` at 3, so the agent loop slices to the
# top of whatever is most relevant for the call (see openrouter.py).

CODER_CHAIN = [
    # Round-51 P0 fix: probed OpenRouter's live catalog (372 models)
    # 2026-05-05 and found 11/30 of our chain entries were actually
    # live. The chain HEAD was dead and every first request silently
    # rotated to entry #3. Reordered so live IDs lead; dead/lapsed
    # IDs moved to a backup tail and may return later (OpenRouter
    # occasionally reissues :free tiers).
    #
    # === LIVE on OpenRouter as of 2026-05-05 (verified) ===
    # Round-66: minimax/minimax-m2.5:free promoted to #1 — only entry
    # in the user-added top-4 that lived through the round-65 probe
    # alongside poolside/laguna-m.1. owl-alpha and qwen-3.6-plus-preview
    # were 404 at probe time and removed from chain head per user
    # instruction to recover the 1-2s per-request latency they cost.
    "minimax/minimax-m2.5:free",                          # 80.2% SWE-Bench Verified — verified live #1
    "poolside/laguna-m.1:free",                           # round-65 user-added — verified live
    "arcee-ai/trinity-large-thinking:free",               # round-65 user-added (kept; probe said dead but user asserted live)
    "inclusionai/ling-2.6-1t:free",                       # 1T-param flagship — verified live
    "qwen/qwen3-coder:free",                              # 480B MoE, 262K ctx — verified live
    "nvidia/nemotron-3-super-120b-a12b:free",             # 1M ctx Mamba-Transformer — verified live
    "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free", # round-58: Claude-class reasoner — also in VISION_CHAIN
    "nvidia/nemotron-3-nano-30b-a3b:free",                # round-59: 30B mid-size reasoner — live-verified
    "tencent/hy3-preview:free",                           # round-60: Hunyuan Hy3 (correct ID) — live-verified
    # round-65 dedup: poolside/laguna-m.1:free moved to top of chain (line ~108)
    "meta-llama/llama-3.3-70b-instruct:free",             # round-60: now live again (was 404 in round 51)
    "openai/gpt-oss-120b:free",                           # 117B MoE, native tool use — verified live
    "poolside/laguna-xs.2:free",                          # 33B MoE — verified live
    "qwen/qwen3-next-80b-a3b-instruct:free",              # 80B/3B-active — verified live
    "openrouter/owl-alpha",                               # round-94: 1M ctx, $0, tools — verified live (no `:free` suffix on this model)
    # === DEAD on OpenRouter (2026-05-06) but may reappear ===
    # Keeping in chain so the request `models` array transparently
    # picks them up if/when OpenRouter republishes.
    "moonshotai/kimi-k2.6:free",                          # research-asserted #1 (currently 404)
    "z-ai/glm-5.1:free",                                  # research-asserted #2 (currently 404)
    "deepseek/deepseek-v4-pro:free",                      # research-asserted (currently 404)
    "openrouter/elephant-alpha:free",                     # round-36 stealth — PrometheUS Titan (currently 404)
    "xiaomi/mimo-v2.5-pro:free",                          # round-36 MIT 1T — PrometheUS MiMo (currently 404)
    "qwen/qwen3.6-plus-preview:free",                     # 27B dense (currently 404; distinct from `qwen-3.6-plus-preview` at top)
    # Round-67: 3 user-asserted frontier IDs added to dead-tail per
    # round-66 discipline (probe 2026-05-05 returned 404 for all
    # three; they'll auto-activate when OpenRouter republishes).
    "minimax/minimax-m2.7:free",                          # PrometheUS Force (currently 404)
    "openrouter/owl-alpha:free",                          # PrometheUS Owl (currently 404)
    "arcee-ai/trinity-large-preview:free",                # PrometheUS Trinity (currently 404)
    "tencent/hunyuan-hy3-preview:free",                   # 295B/21B (currently 404)
    "deepseek/deepseek-chat-v3-0324:free",                # 685B MoE (currently 404)
    "stepfun/step-3.5-flash:free",                        # 11B-active (currently 404)
    "tencent/hunyuan-a13b-instruct:free",                 # 13B-active (currently 404)
    "meta-llama/llama-4-maverick:free",                   # 1M ctx (currently 404)
    "meta-llama/llama-4-scout:free",                      # 10M ctx (currently 404)
]

PLANNER_CHAIN = [
    # Round-51 P0: same live-vs-dead reordering as CODER_CHAIN.
    # === LIVE on OpenRouter (2026-05-05) ===
    "inclusionai/ling-2.6-1t:free",                       # 1T agent-tuned — verified live
    "nvidia/nemotron-3-super-120b-a12b:free",             # 1M ctx — verified live
    "openai/gpt-oss-120b:free",                           # configurable reasoning — verified live
    "minimax/minimax-m2.5:free",                          # agentic planning — verified live
    "qwen/qwen3-next-80b-a3b-instruct:free",              # 80B/3B-active — verified live
    "nousresearch/hermes-3-llama-3.1-405b:free",          # round-60: 405B Hermes reasoner — live-verified
    # === DEAD currently but may reappear ===
    "deepseek/deepseek-v4-pro:free",                      # research-asserted (currently 404)
    "moonshotai/kimi-k2.6:free",                          # research-asserted (currently 404)
    "z-ai/glm-5.1:free",                                  # MIT flagship (currently 404)
    "openrouter/owl-alpha:free",                          # 1M-ctx stealth (currently 404)
    "openrouter/elephant-alpha:free",                     # 1T stealth (currently 404)
    "qwen/qwen3-235b-a22b-thinking-2507:free",            # 262K ctx (currently 404)
    "deepseek/deepseek-r1:free",                          # reasoner (currently 404)
    "qwen/qwen3.6-plus-preview:free",                     # 1M ctx CoT (currently 404)
    "deepseek/deepseek-chat-v3-0324:free",                # 685B MoE (currently 404)
]

FAST_CHAIN = [
    # Round-51 P0: live entries first.
    "google/gemma-4-26b-a4b-it:free",                     # multimodal — verified live
    "nvidia/nemotron-nano-9b-v2:free",                    # smallest — verified live
    "nvidia/nemotron-nano-12b-v2-vl:free",                # round-59: 12B vision-capable — live-verified
    "openai/gpt-oss-20b:free",                            # 21B MoE — verified live
    # === DEAD currently ===
    "stepfun/step-3.5-flash:free",                        # 11B active (currently 404)
    "tencent/hunyuan-a13b-instruct:free",                 # 13B active (currently 404)
    "mistralai/mistral-small-3.1-24b-instruct:free",      # 24B (currently 404)
]

VISION_CHAIN = [
    # Round-51 P0: live entries first.
    "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free", # text+image+audio+video — verified live
    "nvidia/nemotron-nano-12b-v2-vl:free",                # round-59: 12B vision-language — live-verified
    "google/gemma-4-26b-a4b-it:free",                     # 26B multimodal — verified live
    # === DEAD currently ===
    "qwen/qwen3-vl-235b-a22b-thinking:free",              # 131K ctx vision (currently 404)
    "qwen/qwen3-vl-235b-a22b-instruct:free",              # 262K ctx vision (currently 404)
    "meta-llama/llama-4-scout:free",                      # multimodal (currently 404)
    "meta-llama/llama-4-maverick:free",                   # multimodal (currently 404)
    "qwen/qwen3.6-plus:free",                             # multimodal + tools (currently 404)
]

# Flat union for OpenRouter's models[] fallback list. Order matters:
# coder roles first (most invocations), then planner, then fast.
FREE_MODELS_PREFERRED = list(dict.fromkeys(  # de-dupe preserving order
    CODER_CHAIN + PLANNER_CHAIN + FAST_CHAIN + VISION_CHAIN
))

# R230: default route is `openrouter/free` — OpenRouter's auto-router
# constrained to free models. R234 correction: per OpenRouter's own
# docs (https://openrouter.ai/openrouter/free), the router selects free
# models AT RANDOM with intelligent feature-filtering for capabilities
# the request needs (tools, vision, structured output) — NOT
# "best per request." We use it because (a) it auto-rotates around
# dead `:free` slugs without us touching the chain heads, (b) the
# pool is large enough that random + feature-filtered is in practice
# better than pinning a single slug, and (c) free-tier rate limits
# (50/day default) are per-router so spreading across the pool is
# friendlier. CODER_CHAIN[] is still consulted as the OpenRouter
# `models[]` fallback array if the router itself errors.
# `PROMETHEUS_MODEL` env wins — power users pin a specific slug.
DEFAULT_MODEL = os.getenv("PROMETHEUS_MODEL", "openrouter/free")
DEFAULT_FAST_MODEL = os.getenv("PROMETHEUS_FAST_MODEL", FAST_CHAIN[0])
DEFAULT_PLANNER_MODEL = os.getenv("PROMETHEUS_PLANNER_MODEL", PLANNER_CHAIN[0])
DEFAULT_VISION_MODEL = os.getenv("PROMETHEUS_VISION_MODEL", VISION_CHAIN[0])


# ============================================================
# Public-name registry — round-14 total identity rebrand.
# ============================================================
# Every user-visible reference to a model uses the PUBLIC name,
# never the upstream ID. The mapping below is the single source
# of truth: `public_name(upstream_id)` returns the brand-neutral
# label, falling back to a generic "PrometheUS Engine" so a model
# the registry doesn't know about can never expose its real id.
#
# Power users who genuinely need the upstream id (debugging, custom
# /model invocation) can opt in via PROMETHEUS_VERBOSE_MODELS=1.

_PUBLIC_NAMES: dict[str, str] = {
    # ---- Round-76: Kimi K2.6 brand label "PrometheUS Falcon" ----
    # NVIDIA-hosted slug (free): used when PROMETHEUS_NVIDIA_DEFAULT_MODEL
    # is set to enable long-horizon autonomous chains. OpenRouter-paid
    # slug isn't in our chains. The :free OpenRouter dead-tail entry
    # below also gets the Falcon label so any future republish surfaces
    # consistently.
    "moonshotai/kimi-k2.6":                               "PrometheUS Falcon",
    # ---- Round-78: MiniMax M2.7 NVIDIA slug = "PrometheUS Force" ----
    # NVIDIA hosts minimaxai/minimax-m2.7 (and m2.5) free. OpenRouter
    # has no :free variant for M2.7 (the dead-tail :free entry below
    # auto-activates if republished). Same Force label across both
    # surfaces so brand display stays consistent.
    "minimaxai/minimax-m2.7":                             "PrometheUS Force",
    "minimaxai/minimax-m2.5":                             "PrometheUS Builder",
    # ---- Round-79: GLM-4.7 NVIDIA slug = "PrometheUS Vision" ----
    # NVIDIA hosts z-ai/glm4.7 (and glm-5.1, glm5) free. The OpenRouter
    # `z-ai/glm-5.1:free` mapping above keeps its existing Thinker label;
    # GLM-4.7 on NVIDIA is a separate slug with its own brand label per
    # user spec.
    "z-ai/glm4.7":                                        "PrometheUS Vision",
    # ---- Round-80: GPT4Free (PrometheUS Nexus) frontier aliases ----
    # GPT4Free scrapes public free providers; these slugs reach the
    # respective frontier models when the user's gpt4free .env is
    # configured. Brand label "PrometheUS Nexus" matches the GPT4Free
    # provider tier label in pool.py (_PROVIDER_TIERS).
    "gpt-5.2":                                            "PrometheUS Nexus",
    "gemini-3-pro":                                       "PrometheUS Nexus",
    "deepseek-v3.2":                                      "PrometheUS Nexus",
    # ---- Round-56 PrometheUS Undercover Mode brand-name mapping ----
    # Specific upstream IDs the user named in their brand sheet:
    "moonshotai/kimi-k2.6:free":                          "PrometheUS Falcon",
    "z-ai/glm-5.1:free":                                  "PrometheUS Thinker",
    "minimax/minimax-m2.5:free":                          "PrometheUS Builder",
    "inclusionai/ling-2.6-1t:free":                       "PrometheUS Architect",
    "meta-llama/llama-3.3-70b-instruct:free":             "PrometheUS Plus",
    "codestral-latest":                                   "PrometheUS Coder",
    "mistralai/codestral-latest":                         "PrometheUS Coder",
    "claude-opus-4-6":                                    "PrometheUS Genius",
    "claude-opus-4-7":                                    "PrometheUS Genius",
    "gemini-2.5-flash":                                   "PrometheUS Swift",
    "gemini-2.5-pro":                                     "PrometheUS Swift",
    # ---- R230: openrouter/free auto-router brand label ----
    # R237: simplified to plain "PrometheUS" for public users — the
    # "Auto-Free" qualifier leaked an implementation detail
    # (random-with-feature-filter routing) that didn't help end users
    # and felt uncommercial in live screenshots. Power users who want
    # to see the actual router slug can run `/model` or set
    # `PROMETHEUS_VERBOSE_MODELS=1`.
    "openrouter/free":                                    "PrometheUS",
    "auto/free":                                          "PrometheUS",
    # ---- Round-65: 4 newly live :free models at CODER head ----
    "openrouter/owl-alpha:free":                          "PrometheUS Owl",
    "openrouter/owl-alpha":                               "PrometheUS Owl",  # round-94: live without :free suffix
    "qwen/qwen-3.6-plus-preview:free":                    "PrometheUS Swift",
    "poolside/laguna-m.1:free":                           "PrometheUS Laguna",
    "arcee-ai/trinity-large-thinking:free":               "PrometheUS Thinker",
    # ---- Round-67: 4 more brand mappings for user-asserted IDs ----
    "minimax/minimax-m2.7:free":                          "PrometheUS Force",
    "xiaomi/mimo-v2.5-pro:free":                          "PrometheUS MiMo",
    "openrouter/elephant-alpha:free":                     "PrometheUS Titan",
    "arcee-ai/trinity-large-preview:free":                "PrometheUS Trinity",
    # ---- Free tier coder fallbacks ----
    "qwen/qwen3-coder:free":                              "PrometheUS Core",
    "nvidia/nemotron-3-super-120b-a12b:free":             "PrometheUS Core",
    "deepseek/deepseek-chat-v3-0324:free":                "PrometheUS Core",
    "qwen/qwen3.6-plus-preview:free":                     "PrometheUS Core",
    "openai/gpt-oss-120b:free":                           "PrometheUS Core",
    "stepfun/step-3.5-flash:free":                        "PrometheUS Core",
    "tencent/hunyuan-a13b-instruct:free":                 "PrometheUS Core",
    "meta-llama/llama-4-maverick:free":                   "PrometheUS Core",
    "mistralai/devstral-small:free":                      "PrometheUS Core",
    "moonshotai/kimi-k2:free":                            "PrometheUS Core",
    "z-ai/glm-4.5-air:free":                              "PrometheUS Core",
    # ---- Free tier: Planner role -> "PrometheUS Reasoner" ----
    "deepseek/deepseek-r1:free":                          "PrometheUS Reasoner",
    "qwen/qwen3-235b-a22b-thinking-2507:free":            "PrometheUS Reasoner",
    "qwen/qwen3-next-80b-a3b-instruct:free":              "PrometheUS Reasoner",
    # ---- Free tier: Fast role -> "PrometheUS Swift" ----
    "google/gemma-4-26b-a4b-it:free":                     "PrometheUS Swift",
    "nvidia/nemotron-nano-9b-v2:free":                    "PrometheUS Swift",
    "nvidia/nemotron-3-nano-30b-a3b:free":                "PrometheUS Core",
    "nvidia/nemotron-nano-12b-v2-vl:free":                "PrometheUS Vision",
    "openai/gpt-oss-20b:free":                            "PrometheUS Swift",
    "mistralai/mistral-small-3.1-24b-instruct:free":      "PrometheUS Swift",
    "google/gemma-3-27b-it:free":                         "PrometheUS Swift",
    # ---- Free tier: Vision role -> "PrometheUS Vision" ----
    "qwen/qwen3-vl-235b-a22b-thinking:free":              "PrometheUS Vision",
    "qwen/qwen3-vl-235b-a22b-instruct:free":              "PrometheUS Vision",
    "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free": "PrometheUS Vision",
    "meta-llama/llama-4-scout:free":                      "PrometheUS Vision",
    "qwen/qwen3.6-plus:free":                             "PrometheUS Vision",
    "google/gemini-2.0-flash-exp:free":                   "PrometheUS Vision",
    # ---- Paid escalation tier (round-56: aliased to user's brand sheet) ----
    "claude-haiku-4-5":                                   "PrometheUS Premium",
    "claude-sonnet-4-5":                                  "PrometheUS Premium+",
    "claude-sonnet-4-6":                                  "PrometheUS Premium+",
    # Note: claude-opus-4-6 / 4-7 are explicitly mapped to "PrometheUS
    # Genius" at the top of this dict per the user's brand sheet.
}


def public_name(upstream_id: str | None) -> str:
    """Resolve an upstream model id to its public PrometheUS-branded name.

    Falls back through three tiers:
      1. exact match in `_PUBLIC_NAMES`
      2. Anthropic family heuristic (haiku/sonnet/opus → Premium/+/Max)
         so a future model id we haven't enumerated still resolves cleanly
      3. role-based lookup against the configured chains
      4. generic "PrometheUS Engine"

    Power-user opt-out: setting PROMETHEUS_VERBOSE_MODELS=1 returns the
    upstream id unchanged so developers can see which model handled a
    turn. Default behavior NEVER reveals upstream ids.
    """
    if not upstream_id:
        return "PrometheUS Engine"
    if os.getenv("PROMETHEUS_VERBOSE_MODELS") == "1":
        return upstream_id
    name = _PUBLIC_NAMES.get(str(upstream_id))
    if name:
        return name
    # Anthropic family heuristic — future haiku-X-Y / sonnet-X-Y / opus-X-Y
    # variants resolve to the right Premium tier without manual updates.
    low = str(upstream_id).lower()
    if "opus" in low:
        return "PrometheUS Premium Max"
    if "sonnet" in low:
        return "PrometheUS Premium+"
    if "haiku" in low or "claude" in low:
        return "PrometheUS Premium"
    # Role-based fallback against configured chains.
    if upstream_id in CODER_CHAIN:
        return "PrometheUS Core"
    if upstream_id in PLANNER_CHAIN:
        return "PrometheUS Reasoner"
    if upstream_id in FAST_CHAIN:
        return "PrometheUS Swift"
    if upstream_id in VISION_CHAIN:
        return "PrometheUS Vision"
    return "PrometheUS Engine"


def all_public_names() -> set[str]:
    """The set of brand-neutral labels we display anywhere user-visible.
    Used by the audit suite to verify NO upstream ID leaks into output."""
    return set(_PUBLIC_NAMES.values())


@dataclass
class Settings:
    api_key: str = field(
        default_factory=lambda: os.getenv("PROMETHEUS_API_KEY")
        or os.getenv("OPENROUTER_API_KEY", "")
    )
    base_url: str = field(default_factory=lambda: os.getenv("PROMETHEUS_BASE_URL")
        or os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1"))
    model: str = DEFAULT_MODEL
    fast_model: str = DEFAULT_FAST_MODEL
    planner_model: str = DEFAULT_PLANNER_MODEL
    log_level: str = field(default_factory=lambda: os.getenv("PROMETHEUS_LOG_LEVEL", "INFO"))
    workdir: Path = field(default_factory=lambda: Path.cwd())
    max_iterations: int = 15
    consecutive_failure_limit: int = 3
    context_compact_threshold: float = 0.85
    request_timeout: float = 120.0
    # Round 175: Claude-Code-style settings.json fields. These get
    # populated from `~/.prometheus/settings.json` and the project
    # `.prometheus/settings.json` (and `.local.json` on top) by
    # `load_settings()`. Earlier rounds didn't merge these at all
    # — every CC user copying their `~/.claude/settings.json`
    # equivalent would have had `defaultMode`, `additionalDirectories`,
    # `outputStyle`, `includeCoAuthoredBy`, `autoUpdates`,
    # `ideAutoConnect`, `hasTrustDialogAccepted` silently dropped.
    default_mode: str = ""
    additional_directories: list[Path] = field(default_factory=list)
    output_style: str = ""
    include_co_authored_by: bool = True
    auto_updates: bool = True
    ide_auto_connect: bool = False
    has_trust_dialog_accepted: bool = False
    extra_env: dict[str, str] = field(default_factory=dict)
    # Round 183: offline-mode flag. Honors `PROMETHEUS_OFFLINE=1` /
    # `--offline` CLI flag. When True, network-requiring tools
    # (web_fetch, web_search, MCP-over-HTTP, the foundry marketplace,
    # plugin --plugin-url archive fetch) refuse with a clean message
    # so the user gets fast feedback instead of a 30s socket timeout.
    # The LLM provider connection is NOT gated by this — running
    # offline against a network-required upstream is the user's
    # responsibility (set --base-url to a local LLM if needed).
    # Aider and OpenDevin both expose equivalent flags; this is
    # required for air-gapped enterprise deployments.
    offline: bool = field(
        default_factory=lambda: os.getenv("PROMETHEUS_OFFLINE", "").strip().lower() in ("1", "true", "yes")
    )
    # Round 183: reasoning-effort dial. Aider exposes it as
    # `--reasoning-effort low/medium/high/0=disable` and the in-chat
    # `/reasoning-effort` slash; Codex has Alt+,/Alt+. live shortcuts;
    # Claude Code has `/effort` with a `xhigh` tier. Prometheus
    # follows the Aider naming for the env var / CLI flag and maps
    # the level to the OpenRouter `reasoning_effort` parameter.
    # Empty string = use the model's default (don't send the field).
    reasoning_effort: str = field(
        default_factory=lambda: os.getenv("PROMETHEUS_REASONING_EFFORT", "").strip().lower()
    )
    # Round 183: opt-in to edit files matched by .gitignore.
    # Default off — gitignored paths are usually generated artifacts
    # the user doesn't want changed (build outputs, env files, lock
    # files). Set via `--add-gitignore-files` or
    # `PROMETHEUS_ADD_GITIGNORE_FILES=1`. Aider parity.
    add_gitignore_files: bool = field(
        default_factory=lambda: os.getenv("PROMETHEUS_ADD_GITIGNORE_FILES", "").strip().lower() in ("1", "true", "yes")
    )

    def ensure_dirs(self) -> None:
        # Round-14 P1: corp-policy / read-only home shouldn't crash
        # the launch path. mkdir is best-effort; persistence layers
        # (session DB, audit log, trust file) all already wrap their
        # writes in try/except, so an unwritable user-data dir
        # degrades the app to in-memory state without a stack trace.
        for d in (USER_DATA_DIR, USER_CONFIG_DIR, LOG_DIR):
            try:
                d.mkdir(parents=True, exist_ok=True)
            except OSError:
                pass


def _load_settings_json(path: Path) -> dict:
    """Round 175: load one settings.json layer; tolerate missing /
    malformed files. Returns an empty dict on any failure so the
    caller can simply chain `merged = {**user, **project, **local}`."""
    if not path.exists() or not path.is_file():
        return {}
    try:
        import json as _json
        return _json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _settings_search_paths(workdir: Path) -> list[tuple[str, Path]]:
    """Round 175: settings.json hierarchy.

    Order (lowest precedence → highest):
      1. enterprise managed: /etc/prometheus/managed-settings.json
                            (or %ProgramData%\\PrometheUS on Windows)
      2. user: ~/.prometheus/settings.json
               (or $CLAUDE_CONFIG_DIR / $PROMETHEUS_CONFIG_DIR)
      3. project shared: <workdir>/.prometheus/settings.json
      4. project local: <workdir>/.prometheus/settings.local.json

    Mirrors Claude Code's documented enterprise / user / project /
    local cascade.
    """
    layers: list[tuple[str, Path]] = []
    if sys.platform == "win32":
        program_data = os.environ.get("ProgramData", r"C:\ProgramData")
        layers.append(("managed", Path(program_data) / "PrometheUS" / "managed-settings.json"))
    else:
        layers.append(("managed", Path("/etc/prometheus/managed-settings.json")))
    config_root = (
        os.environ.get("PROMETHEUS_CONFIG_DIR")
        or os.environ.get("CLAUDE_CONFIG_DIR")
        or str(Path.home() / ".prometheus")
    )
    layers.append(("user", Path(config_root) / "settings.json"))
    layers.append(("project", workdir / ".prometheus" / "settings.json"))
    layers.append(("local", workdir / ".prometheus" / "settings.local.json"))
    return layers


def _apply_cc_settings_keys(s: Settings, merged: dict) -> None:
    """Round 175: apply the Claude-Code-style keys from a merged
    settings.json blob to the live Settings instance.

    Recognized keys:
      - `model`                       → Settings.model
      - `defaultMode`                 → Settings.default_mode
      - `additionalDirectories`       → Settings.additional_directories
      - `outputStyle`                 → Settings.output_style
      - `includeCoAuthoredBy`         → Settings.include_co_authored_by
      - `autoUpdates`                 → Settings.auto_updates
      - `ideAutoConnect`              → Settings.ide_auto_connect
      - `hasTrustDialogAccepted`      → Settings.has_trust_dialog_accepted
      - `env`                         → Settings.extra_env (and pushed to os.environ)

    Unknown keys are ignored — the loader is forward-compatible
    with future Claude Code additions and downstream Prometheus-
    specific extensions.
    """
    import sys as _sys
    from pathlib import Path as _Path
    if not isinstance(merged, dict):
        return
    if "model" in merged and isinstance(merged["model"], str) and merged["model"].strip():
        s.model = merged["model"].strip()
    # Round 212: support BOTH the nested `permissions.defaultMode`
    # (Claude Code's canonical form per CC settings.json docs) AND
    # the flat top-level `defaultMode` (legacy Prometheus form).
    # Nested wins when both are present, so a user porting their
    # CC settings.json gets the expected behavior. Otherwise we
    # fall back to the flat form to keep older configs working.
    perms_block = merged.get("permissions")
    nested_dm = (
        perms_block.get("defaultMode")
        if isinstance(perms_block, dict) else None
    )
    flat_dm = merged.get("defaultMode")
    dm = nested_dm if isinstance(nested_dm, str) else flat_dm
    if isinstance(dm, str) and dm in ("default", "acceptEdits", "plan", "bypassPermissions"):
        s.default_mode = dm
        os.environ.setdefault("PROMETHEUS_PERMISSION_MODE", dm)
    extra_dirs = merged.get("additionalDirectories")
    if isinstance(extra_dirs, list):
        s.additional_directories = [
            _Path(d).expanduser().resolve()
            for d in extra_dirs
            if isinstance(d, str) and d.strip()
        ]
    if "outputStyle" in merged and isinstance(merged["outputStyle"], str):
        s.output_style = merged["outputStyle"]
    if "includeCoAuthoredBy" in merged and isinstance(merged["includeCoAuthoredBy"], bool):
        s.include_co_authored_by = merged["includeCoAuthoredBy"]
    if "autoUpdates" in merged and isinstance(merged["autoUpdates"], bool):
        s.auto_updates = merged["autoUpdates"]
    if "ideAutoConnect" in merged and isinstance(merged["ideAutoConnect"], bool):
        s.ide_auto_connect = merged["ideAutoConnect"]
    if "hasTrustDialogAccepted" in merged and isinstance(merged["hasTrustDialogAccepted"], bool):
        s.has_trust_dialog_accepted = merged["hasTrustDialogAccepted"]
    extra_env = merged.get("env")
    if isinstance(extra_env, dict):
        for k, v in extra_env.items():
            if isinstance(k, str) and isinstance(v, str):
                s.extra_env[k] = v
                os.environ.setdefault(k, v)


def load_settings() -> Settings:
    """Round 175 / 176: walk the settings.json hierarchy and apply
    Claude-Code-style keys to the live Settings instance, then layer
    in the `PROMETHEUS_ADD_DIRS` env var (set by --add-dir).

    Hierarchy precedence (highest wins): local → project → user →
    managed. Any layer that fails to parse is silently skipped so a
    malformed user file doesn't crash the launch path. Round 176:
    additional directories from --add-dir are appended to whatever
    the settings.json `additionalDirectories` key supplied so the
    flag and the persistent setting compose.
    """
    s = Settings()
    s.ensure_dirs()
    merged: dict = {}
    for _layer_name, p in _settings_search_paths(s.workdir):
        layer = _load_settings_json(p)
        if layer:
            merged = {**merged, **layer}
    if merged:
        _apply_cc_settings_keys(s, merged)
    # Round 176: PROMETHEUS_ADD_DIRS handoff from --add-dir.
    add_dirs_env = os.environ.get("PROMETHEUS_ADD_DIRS", "")
    if add_dirs_env:
        for raw in add_dirs_env.split(os.pathsep):
            raw = raw.strip()
            if not raw:
                continue
            try:
                p = Path(raw).expanduser().resolve()
                if p.exists() and p.is_dir() and p not in s.additional_directories:
                    s.additional_directories.append(p)
            except (OSError, RuntimeError):
                pass
    return s
