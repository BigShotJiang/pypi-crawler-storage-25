"""OpenRouter OpenAI-compatible streaming client.

One file, one job: take a list of OpenAI-format messages + tools, return
an async stream of events: text deltas, tool calls (assembled from
incremental SSE deltas), and final usage/finish.

Ref: https://openrouter.ai/docs/api-reference/chat-completion
The OpenAI tool-call streaming protocol delivers tool_calls as deltas
indexed by `index`, with id/name on the first chunk and arguments
streamed as a string. We accumulate.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, AsyncIterator

import os
import re

import httpx

from prometheus import log

logger = log.get("provider.openrouter")


# Words/phrases from the upstream API that must NEVER reach the user.
# We log the original to file but show a branded message in the UI.
_LEAK_PATTERNS = [
    re.compile(r"\bopenrouter[^\s]*", re.I),
    re.compile(r"\bprovider[^\s]*", re.I),  # "Provider returned error", "provider_name"
    re.compile(r"\bvenice\b", re.I),
    re.compile(r"\b(deepseek|qwen|gemini|gemma|llama|mistral|nvidia|nemotron|gpt-oss|glm|claude|anthropic|gpt-4|gpt-3|hermes|nous|liquid|inclusion|baidu|tencent|poolside|minimax|cognitive|stepfun|step-3|moonshotai|kimi|hunyuan|devstral|haiku|sonnet|opus|maverick|scout|nemotron-nano)[^\s]*", re.I),
    re.compile(r"\:free\b", re.I),
    re.compile(r"\bbyok\b", re.I),
    re.compile(r"\brate[- ]?limit", re.I),
]


def sanitize_error(msg: str) -> str:
    """Map upstream-branded error text to a generic PrometheUS message.

    Goals:
      - Hide vendor/model identifiers from end users.
      - Keep the user-actionable signal (timeout vs auth vs rate-limit).
    Rule of thumb: if it sounds like a brand or a model name, drop it.
    """
    if not msg:
        return "engine error"
    raw = msg
    low = raw.lower()
    if "timed out" in low or "timeout" in low:
        out = "engine busy — retrying"
    elif "rate" in low and "limit" in low:
        out = "engine busy — retrying"
    elif "no endpoints" in low or "404" in low:
        out = "engine unavailable — retrying"
    elif "auth" in low or "401" in low or "403" in low or "api key" in low:
        out = "credentials rejected — check PROMETHEUS_API_KEY in .env"
    elif "context" in low and ("length" in low or "window" in low):
        out = "context too large — try /compact"
    elif "5" in low and ("0" in low or "2" in low or "3" in low) and "internal" in low:
        out = "engine error — retrying"
    else:
        # Strip leakage tokens and pass through.
        cleaned = raw
        for rx in _LEAK_PATTERNS:
            cleaned = rx.sub("engine", cleaned)
        # Trim trailing JSON / IDs / urls
        cleaned = re.sub(r"https?://\S+", "", cleaned)
        cleaned = re.sub(r"\{.*\}", "", cleaned, flags=re.S)
        cleaned = re.sub(r"\s+", " ", cleaned).strip(" :,.")
        out = cleaned[:200] if cleaned else "engine error"
    logger.warning("upstream error sanitized: %r → %r", raw[:300], out)
    return out


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: str = ""

    def parsed_arguments(self) -> dict[str, Any]:
        if not self.arguments:
            return {}
        try:
            return json.loads(self.arguments)
        except json.JSONDecodeError:
            return _repair_json(self.arguments) or {"_raw": self.arguments, "_parse_error": True}


def _repair_json(s: str) -> dict[str, Any] | None:
    """Best-effort repair pass for free-tier model JSON quirks.

    Handles, in order:
      - leading/trailing prose ("Here are the args: { ... }")
      - markdown code fences (```json ... ```)
      - smart quotes / single quotes
      - trailing commas
      - unterminated tail (model cut off mid-stream)
    Returns the parsed dict, or None if every attempt fails.
    """
    import re as _re
    candidates: list[str] = []
    raw = s.strip()

    # 1. Strip code fences.
    m = _re.search(r"```(?:json)?\s*(\{.*\})\s*```", raw, _re.S)
    if m:
        candidates.append(m.group(1))
    # 2. First {...} block in the text.
    m = _re.search(r"\{.*\}", raw, _re.S)
    if m:
        candidates.append(m.group(0))
    candidates.append(raw)

    for cand in candidates:
        # Smart-quote → ASCII
        c = cand.replace("‘", "'").replace("’", "'")
        c = c.replace("“", '"').replace("”", '"')
        # Trailing commas before } or ]
        c = _re.sub(r",\s*([}\]])", r"\1", c)
        # Single quotes around keys/strings → double (very heuristic; only do
        # when we don't see double quotes at all, to avoid breaking JSON
        # that contains apostrophes inside strings)
        if '"' not in c and "'" in c:
            c = c.replace("'", '"')
        try:
            return json.loads(c)
        except json.JSONDecodeError:
            pass
    return None


@dataclass
class StreamEvent:
    """One streaming event from the model."""
    kind: str  # "text" | "tool_call_delta" | "tool_call_complete" | "done" | "error" | "usage"
    text: str | None = None
    tool_call: ToolCall | None = None
    finish_reason: str | None = None
    usage: dict[str, Any] | None = None
    error: str | None = None


@dataclass
class StreamResult:
    text: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    finish_reason: str | None = None
    usage: dict[str, Any] = field(default_factory=dict)


class OpenRouterClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://openrouter.ai/api/v1",
        timeout: float = 120.0,
        app_url: str = "https://prometheus.dev",
        app_name: str = "PrometheUS",
    ) -> None:
        # Round-30 P0: multi-key rotation pool. PROMETHEUS_API_KEYS
        # (comma-separated) lets the host stack 5-10 free keys; each
        # has its own daily limit (50/day free, 1000/day with $10
        # paid credit on OpenRouter). On 429, we rotate to the next
        # key transparently — 10 keys × 1000 = 10K turns/day at $0.
        # If only `api_key` is set, the pool degrades to a single
        # entry (backwards compatible).
        import os as _os
        # 1.0.7: `PROMETHEUS_OPENROUTER_KEYS` is the preferred name for
        # users who only use OpenRouter and find `PROMETHEUS_API_KEYS`
        # ambiguous. The original name stays as the canonical fallback
        # for backwards compatibility — both are read, the OpenRouter-
        # specific one wins when both are set.
        pool_env = (
            _os.getenv("PROMETHEUS_OPENROUTER_KEYS", "")
            or _os.getenv("PROMETHEUS_API_KEYS", "")
        )
        if pool_env.strip():
            keys = [k.strip() for k in pool_env.split(",") if k.strip()]
            if api_key and api_key not in keys:
                keys.insert(0, api_key)
            self._key_pool = keys
        elif api_key:
            self._key_pool = [api_key]
        else:
            raise RuntimeError("OPENROUTER_API_KEY is not set. Add it to .env.")
        self._key_pool_idx = 0
        self.api_key = self._key_pool[0]
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.app_url = app_url
        self.app_name = app_name
        self._client: httpx.AsyncClient | None = None
        self._models_cache: list[dict[str, Any]] | None = None

    def _rotate_key(self) -> bool:
        """Round-30 P0: advance to the next key in the pool.

        Returns True if rotation produced a NEW key, False if we've
        exhausted the pool. Caller updates the httpx client headers.
        """
        if len(self._key_pool) <= 1:
            return False
        self._key_pool_idx = (self._key_pool_idx + 1) % len(self._key_pool)
        if self._key_pool_idx == 0:
            return False  # full lap; pool exhausted
        self.api_key = self._key_pool[self._key_pool_idx]
        if self._client is not None:
            try:
                self._client.headers["Authorization"] = f"Bearer {self.api_key}"
            except Exception:
                pass
        return True

    async def __aenter__(self) -> "OpenRouterClient":
        # Round-34: opt-in to OpenRouter Response Caching. When the
        # exact same prompt is sent twice within the cache TTL, the
        # second response is served at zero token cost. Harmless when
        # the upstream ignores the header. Opt-out via env for users
        # who want every request to be a fresh inference.
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "HTTP-Referer": self.app_url,
            "X-Title": self.app_name,
            "Content-Type": "application/json",
        }
        if os.getenv("PROMETHEUS_DISABLE_RESPONSE_CACHE") != "1":
            headers["X-OpenRouter-Cache"] = "true"
        # Round 179 / Dim 1: honour HTTP(S)_PROXY and REQUESTS_CA_BUNDLE
        # / SSL_CERT_FILE so corporate users behind proxies or SSL-
        # inspecting middleboxes can reach the LLM provider. Without
        # this, every LLM request silently failed with a connection
        # error inside corp networks — the most common single launch
        # blocker for commercial deployments.
        from prometheus.net import net_kwargs
        self._client = httpx.AsyncClient(
            **net_kwargs(
                timeout=httpx.Timeout(self.timeout, connect=10.0),
                headers=headers,
            ),
        )
        return self

    async def __aexit__(self, *exc: Any) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    async def list_models(self) -> list[dict[str, Any]]:
        # Round-20 P1: 30-minute TTL on the model-list cache. The
        # previous infinite cache held a stale `:free` set across an
        # entire process lifetime, so a model deprecation or upstream
        # rebalance could leave the agent routing to dead engines for
        # hours. 30 min is short enough to recover from a deprecation,
        # long enough that --doctor / first-prompt overhead is once.
        import time as _time
        now = _time.monotonic()
        cache_at = getattr(self, "_models_cache_at", 0.0)
        if self._models_cache is not None and (now - cache_at) < 1800:
            return self._models_cache
        assert self._client
        try:
            r = await self._client.get(f"{self.base_url}/models")
            r.raise_for_status()
            self._models_cache = r.json().get("data", [])
        except Exception as e:
            logger.warning("Failed to list models: %s", e)
            self._models_cache = []
        self._models_cache_at = now
        return self._models_cache

    async def free_models(self) -> list[str]:
        models = await self.list_models()
        return [m["id"] for m in models if m.get("id", "").endswith(":free")]

    async def is_vision_capable(self, model_id: str) -> bool:
        """Returns True if the model accepts image inputs.

        Checked against the cached /models response — every OpenRouter
        model entry has architecture.input_modalities. Permissive
        default (True) when the model isn't in the cache so we don't
        block users with a private/custom endpoint we couldn't probe.
        """
        try:
            models = await self.list_models()
        except Exception:
            return True
        for m in models:
            if m.get("id") == model_id:
                arch = m.get("architecture") or {}
                mods = arch.get("input_modalities") or []
                return "image" in mods
        return True

    async def stream(
        self,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.2,
        max_tokens: int | None = None,
        fallback_models: list[str] | None = None,
        reasoning_effort: str | None = None,
    ) -> AsyncIterator[StreamEvent]:
        """Stream a chat completion. Yields StreamEvent.

        Free OpenRouter models are aggressively rate-limited upstream. We
        pass `models` (OpenRouter's native fallback list) so the gateway
        will try each in order on 429/5xx.

        `reasoning_effort` is one of "low" | "medium" | "high" — forwarded
        to OpenRouter's `reasoning` param for models that support it
        (e.g. extended-thinking variants). Ignored when None.
        """
        assert self._client, "use async with"
        # Round-63: task-aware provider preference. Classify the most
        # recent user message; if a non-OR provider is preferred for
        # this task kind AND configured, route through failover with
        # that provider FIRST. The rest of the cascade still catches
        # any error — preference never costs availability.
        if os.getenv("PROMETHEUS_DISABLE_TASK_ROUTING") != "1":
            try:
                from prometheus.provider.router import (
                    classify_query, preferred_provider_for,
                )
                from prometheus.provider.pool import ProviderPool
                # Pull the latest user-role message text for classification.
                user_text = ""
                has_image = False
                for m in reversed(messages):
                    if m.get("role") == "user":
                        c = m.get("content")
                        if isinstance(c, str):
                            user_text = c
                        elif isinstance(c, list):
                            for part in c:
                                if isinstance(part, dict):
                                    if part.get("type") == "text":
                                        user_text = part.get("text", "") or user_text
                                    if part.get("type") == "image_url":
                                        has_image = True
                        break
                kind = classify_query(user_text, has_image=has_image)
                pref = preferred_provider_for(kind)
                if pref:
                    pool = ProviderPool.from_env()
                    pref_entry = next(
                        (p for p in pool.configured_providers()
                         if p.name == pref),
                        None,
                    )
                    if pref_entry is not None:
                        # Round-64: log the routing decision so users can
                        # `tail -f ~/.prometheus/logs/prometheus-*.log`
                        # to verify the right provider handled the turn.
                        logger.info(
                            "task-aware routing: kind=%s prefer=%s (configured)",
                            kind.value, pref,
                        )
                        # Build the request body the way the OpenRouter
                        # path would, then hand it to the failover layer
                        # with the preferred provider pinned first.
                        from prometheus.provider.failover import stream_with_failover
                        body: dict[str, Any] = {
                            "model": model,
                            "messages": messages,
                            "stream": True,
                            "temperature": temperature,
                        }
                        if tools:
                            body["tools"] = tools
                            body["tool_choice"] = "auto"
                        if max_tokens is not None:
                            body["max_tokens"] = max_tokens
                        # `skip_providers=()` so OpenRouter is still in
                        # the cascade as a fallback; just not first.
                        async for ev in stream_with_failover(
                            body,
                            skip_providers=(),
                            prefer_provider=pref,
                        ):
                            yield ev
                        return
            except Exception:
                # Routing should never break the request — fall through
                # to the canonical OpenRouter-primary path.
                logger.exception("task-aware routing failed; falling through")
        # Empirically OpenRouter accepts more than 3 entries in `models`
        # but free-tier rate-limit + provider routing get more reliable
        # when we keep the chain tight. Stay at 3 (round-11: tested
        # 6-entry expansion, free providers behave better with 3).
        models_chain = [model] + [m for m in (fallback_models or []) if m != model]
        models_chain = models_chain[:3]
        body: dict[str, Any] = {
            "model": model,
            "models": models_chain,
            "messages": messages,
            "stream": True,
            "temperature": temperature,
            # Always ask for usage stats in the final SSE chunk.
            "usage": {"include": True},
        }
        # Optional provider-routing flags (round-11). All opt-in via
        # env so the default is the previous behavior — anything set
        # here filters the free provider pool, sometimes drastically.
        provider_overrides: dict[str, Any] = {}
        if os.getenv("PROMETHEUS_REQUIRE_TOOL_PARAMS") == "1":
            provider_overrides["require_parameters"] = True
        if os.getenv("PROMETHEUS_REQUIRE_PRIVATE") == "1":
            provider_overrides["data_collection"] = "deny"
        if provider_overrides:
            provider_overrides.setdefault("allow_fallbacks", True)
            body["provider"] = provider_overrides
        if tools:
            body["tools"] = tools
            body["tool_choice"] = "auto"
        if max_tokens is not None:
            body["max_tokens"] = max_tokens
        if reasoning_effort in ("low", "medium", "high"):
            # Some free-tier engines on OpenRouter reject the `reasoning`
            # body field with 400. We attach it and let the fallback
            # chain rotate to a different model on rejection — but we
            # don't want a *single* slow model to block the entire
            # query, so the field is also opt-out via env var if a user
            # has a model that hard-fails on it.
            if not os.getenv("PROMETHEUS_DISABLE_REASONING_PARAM"):
                body["reasoning"] = {"effort": reasoning_effort}

        # Per-index assembly state for tool calls.
        partial: dict[int, ToolCall] = {}
        completed_indices: set[int] = set()
        finish_reason: str | None = None
        usage: dict[str, Any] = {}
        # Round-40: track yielded content so we can detect "empty 200
        # OK" from a free model that just stalled mid-tool-chain.
        # When a model returns success but no text and no tool calls,
        # we cascade to the next provider in the pool — the same
        # failover that fires on 429/5xx, but for "soft" failures.
        yielded_content = False

        # Retry strategy split by error class:
        #
        #   • Transport errors (ConnectError / TimeoutException — i.e.
        #     OpenRouter never responded at all): exponential backoff,
        #     because the gateway might be momentarily unreachable.
        #   • 429 / 5xx HTTP responses: bail IMMEDIATELY and surface the
        #     error to the caller. The agent loop has its own model-
        #     fallback chain (see loop.py:_run); retrying inside stream()
        #     stacks two retry layers and a quota-exhausted free model
        #     would eat ~40s of sleeps before letting the loop rotate.
        #   • SSE body errors (mid-stream): never retried — partial
        #     tokens have already been yielded and we'd duplicate.
        #
        # This was the audit P0 — old code retried 0.6s once on any
        # error. New behavior: retry only when the *transport* failed,
        # let HTTP failures cascade to the model-fallback layer.
        import asyncio as _asyncio
        # Round-29 Track F: exponential backoff with jitter. Each
        # delay is base * 2^attempt + random jitter ±20%. Prevents
        # thundering-herd retries when the gateway is briefly down.
        # Per Anthropic's own April-23 postmortem (#22-23): "exponential
        # backoff applies as a minimum even when Retry-After is small."
        import random as _random
        def _delay(attempt: int) -> float:
            base = 0.5 * (2 ** attempt)  # 0.5, 1.0, 2.0, 4.0
            jitter = _random.uniform(-0.2, 0.2) * base
            return max(0.1, base + jitter)
        retry_delays = [_delay(i) for i in range(3)]
        succeeded = False

        for retry_attempt in range(len(retry_delays) + 1):
            try:
                async with self._client.stream(
                    "POST", f"{self.base_url}/chat/completions", json=body
                ) as r:
                    if r.status_code >= 400:
                        # Round-30 P0: on 429 (rate limit) try rotating
                        # to the next key in the pool BEFORE giving up.
                        # 10 stacked free keys × 1000 turns/day each =
                        # 10k turns/day on $0 budget.
                        if r.status_code == 429 and self._rotate_key():
                            logger.info(
                                "rotated to next API key in pool (idx=%d)",
                                self._key_pool_idx,
                            )
                            await r.aclose()
                            continue  # outer retry loop re-issues with new key
                        # Round-33: OpenRouter pool is fully exhausted
                        # (429 with no more keys, or 5xx). Cascade
                        # through every other configured provider —
                        # Groq, Gemini, Cerebras, NVIDIA, Mistral,
                        # Together, Cloudflare, Pollinations. The user
                        # never sees a rate-limit error.
                        if r.status_code in (429, 500, 502, 503, 504) and \
                                os.getenv("PROMETHEUS_DISABLE_FAILOVER") != "1":
                            await r.aclose()
                            from prometheus.provider.failover import stream_with_failover
                            logger.info(
                                "OpenRouter %d — cascading to free pool",
                                r.status_code,
                            )
                            cascaded_any = False
                            async for ev in stream_with_failover(body):
                                cascaded_any = True
                                if ev.kind == "done":
                                    yield ev
                                    return
                                yield ev
                            if cascaded_any:
                                return
                            # Failover yielded nothing — fall through
                            # to surface the original 429 to the caller.
                        detail = (await r.aread()).decode("utf-8", "replace")
                        yield StreamEvent(kind="error", error=sanitize_error(detail))
                        return

                    # SSE body streaming — once we yield a single token,
                    # there is no going back.
                    async for line in r.aiter_lines():
                        if not line:
                            continue
                        if line.startswith(":"):
                            continue  # keep-alive comment
                        if not line.startswith("data:"):
                            continue
                        data = line[5:].strip()
                        if data == "[DONE]":
                            break
                        try:
                            chunk = json.loads(data)
                        except json.JSONDecodeError:
                            continue
                        if "error" in chunk:
                            err = chunk["error"]
                            msg = err.get("message", str(err)) if isinstance(err, dict) else str(err)
                            yield StreamEvent(kind="error", error=sanitize_error(msg))
                            return
                        choices = chunk.get("choices") or []
                        if choices:
                            c0 = choices[0]
                            delta = c0.get("delta") or {}
                            # Round-64: defensive content-shape handling.
                            # OpenAI string by default, but some
                            # OpenRouter-mirrored providers return list
                            # of parts. Match failover.py's logic.
                            _raw = delta.get("content")
                            _text: str | None = None
                            if isinstance(_raw, str):
                                _text = _raw
                            elif isinstance(_raw, list):
                                _parts = []
                                for _p in _raw:
                                    if not isinstance(_p, dict):
                                        continue
                                    if _p.get("type") in ("text", "output_text"):
                                        if _p.get("text"):
                                            _parts.append(_p["text"])
                                if _parts:
                                    _text = "".join(_parts)
                            if _text:
                                yielded_content = True
                                yield StreamEvent(kind="text", text=_text)
                            for tc in delta.get("tool_calls") or []:
                                idx = tc.get("index", 0)
                                cur = partial.get(idx)
                                if cur is None:
                                    cur = ToolCall(
                                        id=tc.get("id", "") or "",
                                        name=(tc.get("function") or {}).get("name", "") or "",
                                        arguments="",
                                    )
                                    partial[idx] = cur
                                else:
                                    if tc.get("id"):
                                        cur.id = tc["id"]
                                    fn = tc.get("function") or {}
                                    if fn.get("name"):
                                        cur.name = fn["name"]
                                fn = tc.get("function") or {}
                                if "arguments" in fn and fn["arguments"]:
                                    cur.arguments += fn["arguments"]
                                yielded_content = True
                                yield StreamEvent(kind="tool_call_delta", tool_call=cur)
                            if c0.get("finish_reason"):
                                finish_reason = c0["finish_reason"]
                                for idx, tc in partial.items():
                                    if idx not in completed_indices:
                                        completed_indices.add(idx)
                                        yield StreamEvent(kind="tool_call_complete", tool_call=tc)
                        if chunk.get("usage"):
                            usage = chunk["usage"]
                            yield StreamEvent(kind="usage", usage=usage)
                    succeeded = True
                    break
            except (httpx.ConnectError, httpx.TimeoutException) as e:
                # Transport-layer error before/during stream open — safe
                # to retry because no tokens have been yielded.
                if retry_attempt < len(retry_delays):
                    delay = retry_delays[retry_attempt]
                    logger.warning(
                        "transport error (attempt %d), retrying in %.1fs: %s",
                        retry_attempt + 1, delay, e,
                    )
                    await _asyncio.sleep(delay)
                    continue
                # Round-33: OpenRouter unreachable (DNS / connection
                # refused / connect timeout) after every retry → cascade
                # to the rest of the free pool. User never sees the
                # "network: ..." error if any other provider is alive.
                if os.getenv("PROMETHEUS_DISABLE_FAILOVER") != "1":
                    from prometheus.provider.failover import stream_with_failover
                    logger.info("OpenRouter unreachable — cascading to free pool")
                    cascaded_any = False
                    async for ev in stream_with_failover(body):
                        cascaded_any = True
                        if ev.kind == "done":
                            yield ev
                            return
                        yield ev
                    if cascaded_any:
                        return
                logger.exception("stream transport error (final)")
                yield StreamEvent(kind="error", error=sanitize_error(f"network: {e}"))
                return
            except httpx.HTTPError as e:
                logger.exception("stream HTTP error")
                yield StreamEvent(kind="error", error=sanitize_error(f"network: {e}"))
                return
            except Exception as e:
                logger.exception("stream error")
                yield StreamEvent(kind="error", error=sanitize_error(str(e)))
                return

        if not succeeded:
            yield StreamEvent(kind="error", error=sanitize_error("engine unavailable"))
            return

        # Round-40: empty-200 failover. Free models occasionally return
        # a clean 200 OK with NO content (no text, no tool_calls) — the
        # model effectively stalls mid-tool-chain. The agent loop sees
        # `done` with empty `turn`, classifies it as a finished turn,
        # and the user gets a SKIP. We catch this here and cascade to
        # the next provider in the pool just like a 429 cascade.
        # Opt-out via PROMETHEUS_DISABLE_FAILOVER=1.
        if (not yielded_content
                and os.getenv("PROMETHEUS_DISABLE_FAILOVER") != "1"):
            try:
                from prometheus.provider.failover import stream_with_failover
                from prometheus.provider.pool import ProviderPool
                # Only cascade if there's actually another provider
                # configured beyond OpenRouter — otherwise we'd loop
                # back through Pollinations on every empty turn.
                pool = ProviderPool.from_env()
                fallbacks = [
                    p for p in pool.configured_providers()
                    if p.name != "OpenRouter"
                ]
                if fallbacks:
                    logger.info(
                        "OpenRouter returned empty 200 — cascading to free pool",
                    )
                    cascaded_any_content = False
                    async for ev in stream_with_failover(body):
                        if ev.kind in ("text", "tool_call_delta"):
                            cascaded_any_content = True
                        if ev.kind == "done":
                            yield ev
                            return
                        yield ev
                    if cascaded_any_content:
                        return
                # Fall through to the normal done path if the cascade
                # also produced nothing — the agent loop will rotate
                # to the next model in its own chain.
            except Exception:
                logger.exception("empty-200 failover failed; passing through")

        # Fallback completion of any tool calls that didn't get a finish_reason event.
        for idx, tc in partial.items():
            if idx not in completed_indices:
                completed_indices.add(idx)
                yield StreamEvent(kind="tool_call_complete", tool_call=tc)
        yield StreamEvent(kind="done", finish_reason=finish_reason, usage=usage)

    async def collect(
        self,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.2,
        max_tokens: int | None = None,
        fallback_models: list[str] | None = None,
    ) -> StreamResult:
        """Collect the full result without exposing the live stream — used for
        non-interactive paths (subagents, /selftest, planner)."""
        out = StreamResult()
        async for ev in self.stream(
            model, messages, tools, temperature, max_tokens, fallback_models
        ):
            if ev.kind == "text" and ev.text:
                out.text += ev.text
            elif ev.kind == "tool_call_complete" and ev.tool_call:
                out.tool_calls.append(ev.tool_call)
            elif ev.kind == "usage" and ev.usage:
                out.usage = ev.usage
            elif ev.kind == "done":
                out.finish_reason = ev.finish_reason
            elif ev.kind == "error":
                raise RuntimeError(f"OpenRouter error: {ev.error}")
        return out
