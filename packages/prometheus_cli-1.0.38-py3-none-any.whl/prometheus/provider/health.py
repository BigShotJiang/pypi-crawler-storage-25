"""Round-88: per-provider health tracking with cooldowns.

Existing failover logic in failover.py rotates on errors but doesn't
remember which provider just failed. The result is that a 429-rate-
limited provider gets retried again immediately on the next request,
costing latency on every turn. This module tracks recent error
history per provider and exposes a `is_healthy()` predicate the
router can consult to skip providers in cooldown.

Design choices:
  • In-memory only (per-process). No persistence across restarts —
    cooldowns are short (minutes), so disk persistence isn't worth
    the complexity.
  • Categorized errors: AUTH (401/403, no retry), RATE (429, short
    cooldown), TIMEOUT (network/timeout, medium cooldown), SERVER
    (5xx, short cooldown), EMPTY (200 with no content, short cooldown).
  • Cooldown durations chosen for free-tier reality: 429 typically
    resolves in 60-120s; AUTH errors don't self-resolve and stay in
    cooldown until the user fixes the key (PROCESS lifetime).
  • Thread-safe via a single module-level lock.

Round-88 ships the data structure + record/skip API only — wiring
into failover.py's `stream_with_failover` is round 89 to keep this
PR small and reviewable.
"""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from enum import Enum


class ErrorKind(str, Enum):
    """Categorized error kinds the router cares about for cooldown
    decisions. Mapped from HTTP status / exception type by the caller."""
    AUTH = "auth"            # 401/403 — won't self-resolve
    RATE = "rate"            # 429 — short cooldown
    TIMEOUT = "timeout"      # network/socket/transport timeout
    SERVER = "server"        # 5xx
    EMPTY = "empty"          # 200 OK with no content
    OTHER = "other"          # anything else (parse error, etc.)


# Cooldown seconds per error kind. Conservative — we'd rather rotate
# back too soon than hold a working provider out for too long.
_COOLDOWN: dict[ErrorKind, float] = {
    ErrorKind.AUTH:    24 * 3600.0,   # effectively process lifetime; user must fix key
    ErrorKind.RATE:    90.0,          # 429 typically clears in 60-120s
    ErrorKind.TIMEOUT: 60.0,
    ErrorKind.SERVER:  30.0,
    ErrorKind.EMPTY:   30.0,
    ErrorKind.OTHER:   15.0,
}


@dataclass
class ProviderHealth:
    """Per-provider rolling health state. One instance per provider name."""
    name: str
    consecutive_failures: int = 0
    last_error_kind: ErrorKind | None = None
    cooldown_until: float = 0.0   # monotonic clock; 0 = no cooldown
    total_calls: int = 0
    total_failures: int = 0
    last_success_at: float = 0.0  # monotonic clock; 0 = never

    @property
    def in_cooldown(self) -> bool:
        return time.monotonic() < self.cooldown_until

    @property
    def cooldown_remaining_s(self) -> float:
        return max(0.0, self.cooldown_until - time.monotonic())


class HealthRegistry:
    """Module-level state container. Single instance via `default()`."""
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._h: dict[str, ProviderHealth] = {}

    def get(self, provider_name: str) -> ProviderHealth:
        with self._lock:
            h = self._h.get(provider_name)
            if h is None:
                h = ProviderHealth(name=provider_name)
                self._h[provider_name] = h
            return h

    def record_success(self, provider_name: str) -> None:
        with self._lock:
            h = self._h.get(provider_name) or ProviderHealth(name=provider_name)
            h.total_calls += 1
            h.consecutive_failures = 0
            h.last_error_kind = None
            h.cooldown_until = 0.0
            h.last_success_at = time.monotonic()
            self._h[provider_name] = h

    def record_error(self, provider_name: str, kind: ErrorKind) -> None:
        with self._lock:
            h = self._h.get(provider_name) or ProviderHealth(name=provider_name)
            h.total_calls += 1
            h.total_failures += 1
            h.consecutive_failures += 1
            h.last_error_kind = kind
            base = _COOLDOWN.get(kind, _COOLDOWN[ErrorKind.OTHER])
            # Mild exponential bump on consecutive failures, capped at 10×.
            multiplier = min(10, 2 ** max(0, h.consecutive_failures - 1))
            h.cooldown_until = time.monotonic() + base * multiplier
            self._h[provider_name] = h

    def is_healthy(self, provider_name: str) -> bool:
        return not self.get(provider_name).in_cooldown

    def snapshot(self) -> list[ProviderHealth]:
        """Read-only view for /provider --health diagnostic output."""
        with self._lock:
            return list(self._h.values())

    def reset(self, provider_name: str | None = None) -> None:
        """Manually clear cooldowns. Useful in tests + /provider --reset."""
        with self._lock:
            if provider_name is None:
                self._h.clear()
            else:
                self._h.pop(provider_name, None)


_DEFAULT: HealthRegistry | None = None


def default() -> HealthRegistry:
    """Process-singleton accessor."""
    global _DEFAULT
    if _DEFAULT is None:
        _DEFAULT = HealthRegistry()
    return _DEFAULT


# === Convenience: classify common errors into ErrorKind ==================

def classify_http_status(status: int) -> ErrorKind:
    if status in (401, 403):
        return ErrorKind.AUTH
    if status == 429:
        return ErrorKind.RATE
    if 500 <= status < 600:
        return ErrorKind.SERVER
    return ErrorKind.OTHER


def classify_exception(exc: BaseException) -> ErrorKind:
    name = type(exc).__name__.lower()
    msg = str(exc).lower()
    if "timeout" in name or "timeout" in msg:
        return ErrorKind.TIMEOUT
    if "connect" in name or "connection" in msg:
        return ErrorKind.TIMEOUT
    return ErrorKind.OTHER
