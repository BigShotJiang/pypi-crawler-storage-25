"""Task → model routing + Claude-fallback escalation logic.

Free OpenRouter models handle every turn by default. The escalation
gatekeeper (`should_escalate`) is the ONLY reason an Anthropic API
call ever fires — it's deliberately conservative because each Claude
call costs real money.

Escalation triggers:
  1. **Explicit user opt-in**: /escalate slash command sets
     `escalate_next_turn=True`, OR the user prefixed their prompt with
     a `!claude` token.
  2. **Repeated free-model failure**: same prompt has failed N=2 times
     consecutively against the free chain (e.g. parse errors, halt,
     stuck-loop). Tracked per-prompt via SHA-256 fingerprint.
  3. **Context overflow**: prompt + history exceeds the smallest
     free-model context window (128k) AND user has set
     PROMETHEUS_AUTO_ESCALATE=1.
  4. **Effort=max + ultrathink**: high-effort + ultrathink keyword AND
     opt-in flag set. Free reasoners (DeepSeek R1) handle most of these
     for free; this is for the cases where R1 has already failed.

The trigger evaluation is in `should_escalate()` — single function so
all routing decisions are auditable.
"""
from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass, field
from enum import Enum

from prometheus.config import Settings


class TaskKind(str, Enum):
    SIMPLE = "simple"        # one-line lookup, no tools needed
    CHAT = "chat"            # default coding chat
    PLANNING = "planning"    # /plan, architect, deep single-file analysis
    EXECUTION = "execution"  # multi-step bash/git chains (round-75)
    SUBAGENT = "subagent"    # task() spawned worker


@dataclass
class EscalationDecision:
    """Why a turn was (or wasn't) escalated to Claude. Exposed so /cost,
    audit logs, and tests can inspect the routing decision."""
    escalate: bool
    model: str | None = None        # claude model id when escalating
    reason: str = ""                # human-readable explanation


@dataclass
class ModelRouter:
    settings: Settings

    def pick(self, kind: TaskKind) -> str:
        if kind == TaskKind.SIMPLE:
            return self.settings.fast_model
        if kind == TaskKind.PLANNING:
            return self.settings.planner_model
        if kind == TaskKind.SUBAGENT:
            return self.settings.fast_model
        # EXECUTION (multi-step bash/git) uses the default chat model —
        # round-74 showed NVIDIA's reasoner stalls on these chains.
        return self.settings.model


# Round-63: task-aware provider preference. Round-75: split refined.
#
# Each TaskKind maps to the provider that best fits its workload:
#   • SIMPLE / SUBAGENT → Groq (700+ tok/s, fastest cascade reach)
#   • PLANNING          → NVIDIA NIM (Claude-class reasoners — strong on
#                         single-file analysis "find/fix/refactor", as
#                         round-74 confirmed: 311s → 69s on Task 7)
#   • EXECUTION         → None (default cascade) — multi-step bash/git
#                         chains. Round-74 showed NVIDIA's reasoner is
#                         WORSE here (Tasks 6/8 went 255s/440s → 614s/620s
#                         when forced through NVIDIA). The OpenRouter
#                         primary handles tool sequencing better for
#                         clone/init/install/commit chains.
#   • CHAT              → no preference; OpenRouter chain runs as primary
#
# When a preferred provider is configured, the agent loop routes to it
# FIRST instead of OpenRouter. If it errors / rate-limits / returns
# empty, the existing failover cascade catches the request and
# transparently rotates through the rest of the pool. So preference
# never costs availability — at worst, one extra hop.
#
# Opt-out via PROMETHEUS_DISABLE_TASK_ROUTING=1 (forces OpenRouter
# primary for every turn).
_TASK_PROVIDER_PREFERENCE: dict[TaskKind, str | None] = {
    TaskKind.SIMPLE:    "Groq",
    TaskKind.SUBAGENT:  "Groq",
    TaskKind.PLANNING:  "NVIDIA",
    TaskKind.EXECUTION: None,  # default cascade (round-75)
    TaskKind.CHAT:      None,  # default: OpenRouter primary
}


def lean_tool_names(kind: TaskKind) -> list[str]:
    """Round-92: per-TaskKind tool subset. Free models attention-degrade
    past ~6-8 tool definitions; sending all 15 tools every request
    burns ~2K input tokens for irrelevant choices.

    Empirical mapping based on the chain-heavy task suite:
      EXECUTION (clone, init, install, scaffold) needs bash + file IO
      PLANNING  (find+fix, refactor) needs read + edit + run_bash to verify
      SIMPLE    (math, time, weather) needs calculator + web_search
      CHAT      (everything else) gets a balanced minimum

    The agent loop applies this only when PROMETHEUS_LEAN_TOOLS=1 is set
    (opt-in until empirically validated). When unset, all 15 tools ship
    every request — the existing behavior.
    """
    if kind == TaskKind.EXECUTION:
        return ["run_bash", "read_file", "write_file", "edit_file",
                "list_files", "bash_output", "discover_test_command"]
    if kind == TaskKind.PLANNING:
        return ["read_file", "edit_file", "multi_edit", "run_bash",
                "search_code", "glob_files", "discover_test_command"]
    if kind == TaskKind.SIMPLE:
        return ["calculator", "web_search", "read_file"]
    if kind == TaskKind.SUBAGENT:
        return ["read_file", "edit_file", "run_bash", "search_code",
                "discover_test_command"]
    # CHAT — balanced default
    return ["read_file", "edit_file", "run_bash", "search_code",
            "glob_files", "web_search", "calculator", "todo_write",
            "discover_test_command"]


def task_tier_label(kind: TaskKind, *, escalating: bool = False) -> str:
    """Round-91: Claude-Code-style 3-tier role label for chat display.

    Maps the classified TaskKind (and escalation state) to one of three
    role-based brand names that the user sees on the assistant turn
    header. This is INDEPENDENT of the per-provider _PROVIDER_TIERS
    mapping (which labels which UPSTREAM is configured, for /provider
    admin display). Role tiers describe the COMPUTE tier serving this
    request:

      • PrometheUS Swift — fast tier (Haiku-equivalent). SIMPLE lookups,
        greetings, math. Served by Groq / Cerebras / Gemini Flash.
      • PrometheUS Pro   — daily-coding tier (Sonnet-equivalent).
        CHAT, PLANNING, EXECUTION, SUBAGENT. Served by the OpenRouter
        free chain + NVIDIA NIM.
      • PrometheUS Max   — premium tier (Opus-equivalent). Fires only
        when /escalate is invoked or auto-escalate threshold hits.

    Parallel to Claude Code's 3-tier model (Haiku/Sonnet/Opus) — same
    pattern, different brand vocabulary, all behind opt-in /escalate
    so paid Anthropic credit is never spent silently.

    This is a NEW user-facing label system. Existing public_name()
    per-model entries (round-14 audits) remain unchanged for /provider,
    /sessions, audit logs, and developer telemetry.
    """
    if escalating:
        return "PrometheUS Max"
    if kind == TaskKind.SIMPLE:
        return "PrometheUS Swift"
    # CHAT, PLANNING, EXECUTION, SUBAGENT all serve from the free chain
    # at the daily-coding tier. They differ only in which provider
    # gets preferred (already handled by preferred_provider_for).
    return "PrometheUS Pro"


def pick_provider_by_tag(
    tag: str, *, exclude: tuple[str, ...] = (),
) -> str | None:
    """Round-89: capability-tag selector. Return the name of the
    first configured + healthy provider whose tags contain `tag`.
    None if no match.

    Order matters: providers are scanned in `ProviderPool.from_env()`
    cascade order (OpenRouter first), so the head of the cascade
    wins ties. The `exclude` arg lets callers skip providers they've
    already tried this turn. Cooled-down providers (per the round-88
    health registry) are NOT returned, so a tag-based selection
    automatically respects backoff state.

    Used by routing policies that prefer capability over default
    cascade — e.g. "code edit task → first 'coder' provider that's
    not in cooldown, fall through to default cascade if none."
    """
    from prometheus.provider.pool import ProviderPool
    from prometheus.provider.health import default as _hd
    pool = ProviderPool.from_env()
    health = _hd()
    for p in pool.configured_providers():
        if p.name in exclude:
            continue
        if tag not in (p.tags or set()):
            continue
        if not health.is_healthy(p.name):
            continue
        return p.name
    return None


def preferred_provider_for(kind: TaskKind) -> str | None:
    """Return the provider NAME that should handle this TaskKind first,
    or None if there's no preference (default OpenRouter primary).

    Honest framing: this is a HINT, not a guarantee. If the named
    provider isn't configured (no key set), or fails, the cascade
    rotates to the next provider as usual. Never breaks an existing
    deployment.

    Env overrides:
      • PROMETHEUS_DISABLE_TASK_ROUTING=1 — turn off all task-aware
        routing (forces OpenRouter primary for every turn).
      • PROMETHEUS_EXECUTION_VIA_NVIDIA=1 — round-77 opt-in: route
        EXECUTION (multi-step bash/git chains) through NVIDIA NIM
        instead of the default OpenRouter cascade. Pair with
        PROMETHEUS_NVIDIA_DEFAULT_MODEL=moonshotai/kimi-k2.6 (or any
        other agentic-first NVIDIA-hosted slug) to test that model.

    EMPIRICAL STATE on the 4-task chain-heavy suite (Tasks 6/7/8/D),
    same Pilot harness, 600s watchdog per task, across five routes:

      Round 71 — OpenRouter default cascade alone        : 0/4 PASS
      Round 74 — NVIDIA Nemotron forced for everything   : 0/4 PASS
      Round 75 — split EXECUTION→default, PLANNING→NVIDIA: 0/3 PASS
      Round 77 — NVIDIA + Kimi K2.6 forced (all 4)       : 0/4 PASS
      Round 78 — NVIDIA + MiniMax M2.7 forced (all 4)    : 0/4 PASS

    Failure modes vary (watchdog timeout, didn't-call-tool, wrong-edit)
    but converge to one root cause: free-tier model output quality on
    multi-step tool sequences is the ceiling, not routing. The flag
    and `model_chain` infrastructure stay available for future model
    swaps; the default remains OFF. For chain-heavy work today,
    /escalate to a paid Claude key is the documented path. When user
    activates their OpenClaw Bridge tier (real Opus 4.6), that path
    becomes free-from-the-user's-perspective.
    """
    if os.getenv("PROMETHEUS_DISABLE_TASK_ROUTING") == "1":
        return None
    # Round-82: when the user is running Kiro Gateway (real Claude
    # via Kiro IDE free tier), PROMETHEUS_USE_KIRO=1 pins ALL task
    # kinds to Kiro so chain-heavy work uses real Claude rather than
    # the free-tier OpenRouter cascade. Wins over EXECUTION_VIA_NVIDIA
    # because real Claude is strictly better than free agentic models
    # for multi-step tool sequences.
    if os.getenv("PROMETHEUS_USE_KIRO") == "1":
        return "Kiro"
    if (
        kind == TaskKind.EXECUTION
        and os.getenv("PROMETHEUS_EXECUTION_VIA_NVIDIA") == "1"
    ):
        return "NVIDIA"
    return _TASK_PROVIDER_PREFERENCE.get(kind)


def classify_query(prompt: str, *, has_image: bool = False) -> TaskKind:
    """Round-29 Track 7: lightweight heuristic classifier that picks
    the right TaskKind for the upstream model selection.

    Stays pure-Python so it ships in the wheel without ONNX/torch
    deps. The contract for a future LoRA-distilled adapter is:
    receive `(prompt, has_image, ctx_token_estimate)`, return
    TaskKind. The current heuristic is a strong baseline (matches
    Aider's mode-pick logic + Continue.dev's autocomplete-detect)
    and is the floor any future ML router has to beat.

    Heuristics in priority order:
      1. has_image  → SIMPLE (vision tier handles it)
      2. EXECUTION signal (clone/init/install/scaffold/...) → EXECUTION
      3. PLANNING signal (find+fix/refactor/architect/...) → PLANNING
      4. subagent dispatch keyword → SUBAGENT
      5. tiny one-liner (≤8 words, no code) → SIMPLE
      6. default → CHAT
    """
    if has_image:
        return TaskKind.SIMPLE  # vision tier
    p = (prompt or "").strip().lower()
    if not p:
        return TaskKind.CHAT
    # EXECUTION signals — multi-step bash/git chains where the work is
    # mostly *running things in sequence* (clone → read; init → write →
    # commit; install → verify). Round-74 found NVIDIA's reasoner stalls
    # on these and the default OpenRouter cascade handles them better,
    # so EXECUTION → None (no preferred provider). Checked FIRST so that
    # "set up a new project" (bash chain) doesn't fall into PLANNING.
    execution_signals = (
        "clone ", "git clone", "git init",
        "set up ", "set-up ", "set up a new",
        "install ", "scaffold ", "bootstrap ", "initialize ",
        "build me a", "create a project",
    )
    if any(s in p for s in execution_signals):
        return TaskKind.EXECUTION
    # PLANNING signals — deep single-file analysis or architect-level
    # work where Claude-class reasoning helps. Routes to NVIDIA NIM via
    # preferred provider (round-74: Task 7 was 4× faster here).
    plan_signals = (
        "plan ", "design ", "architect", "refactor ", "rewrite ",
        "migrate ", "redesign", "restructure",
        "step by step", "step-by-step", "let's think",
        "think hard", "think through", "ultrathink",
        # Single-file find-and-fix — NVIDIA's strength.
        "find and fix", "find bugs", "fix bugs", "fix all",
        "read and analyze", "analyze and fix", "review and fix",
    )
    if any(s in p for s in plan_signals):
        return TaskKind.PLANNING
    # Subagent dispatch hints (when the user explicitly delegates).
    if p.startswith("/task ") or p.startswith("dispatch ") or "in parallel" in p:
        return TaskKind.SUBAGENT
    # Trivial one-liners → fast tier (sub-second latency).
    word_count = len(p.split())
    has_code_token = any(t in p for t in ("```", "def ", "class ", "function ", "import ", "from "))
    if word_count <= 8 and not has_code_token and "?" in p:
        return TaskKind.SIMPLE
    return TaskKind.CHAT


# How many consecutive failures on the SAME prompt before we auto-
# escalate to the paid key. 1.0.5 raised this from 2 → 8 because the
# free-tier fallback pool now has 5 verified-or-catalog-confirmed
# alternatives — the failover layer should rotate through every one
# of them before any paid call is even considered. The user's stated
# goal: "the API key must take a very very very damn longer time to
# exhaust." Honouring that means burning every free option first.
AUTO_ESCALATE_FAILURE_THRESHOLD = 8

# Token-load ceiling above which the opt-in auto-escalator switches
# to the paid Claude tier. 1.0.5 raised this from 100K → 500K because
# the new free defaults all have 131K–262K context windows, and the
# failover pool extends to 256K-context Nemotron variants. For the
# vast majority of sessions, free coverage is now sufficient.
AUTO_ESCALATE_TOKEN_THRESHOLD = 500_000

# Tier-aware escalation ladder (round-13 credit-conservation):
# Default Claude tier is Haiku — at $0.80/$4 per Mt it's ~4× cheaper
# than Sonnet ($3/$15) and ~20× cheaper than Opus ($15/$75). For most
# escalations (free chain failed once or twice on a prompt), Haiku is
# perfectly adequate. We only step UP to Sonnet when the user
# explicitly says /escalate (one-shot opt-in) — and only to Opus when
# they say /escalate --hard. This is the single biggest action a $10
# budget can take.
DEFAULT_CLAUDE_MODEL = "claude-haiku-4-5"      # auto-escalation target
SONNET_CLAUDE_MODEL = "claude-sonnet-4-6"      # /escalate
HARD_CLAUDE_MODEL = "claude-opus-4-7"          # /escalate --hard


@dataclass
class EscalationState:
    """Per-app state the escalation decision depends on. Lives on the
    AgentLoop instance so it survives across turns within one session
    but is cleared on /clear or /resume."""
    # SHA-256(prompt) → consecutive-failure count.
    failure_counts: dict[str, int] = field(default_factory=dict)
    # User-driven one-shot flag. Set by /escalate; consumed and cleared
    # on the next agent turn.
    escalate_next_turn: bool = False
    # /escalate --hard: use Opus instead of Sonnet for the next turn.
    next_turn_hard: bool = False
    # /escalate (no flag) bumps to Sonnet instead of the default Haiku.
    # This keeps "/escalate" a meaningful upgrade from auto-escalation.
    next_turn_sonnet: bool = False
    # Round-16 (deferred from round-15): when an AUTO-escalated Haiku
    # call burns its retry budget without yielding text or tool calls,
    # the loop bumps to Sonnet ONCE for the same prompt. We track per
    # prompt fingerprint so a fresh prompt doesn't inherit the bump.
    auto_bumped: set = field(default_factory=set)


def _fingerprint(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", "replace")).hexdigest()[:16]


def mark_auto_bumped(state: EscalationState, prompt: str) -> None:
    """Mark this prompt as already having auto-bumped Haiku→Sonnet."""
    state.auto_bumped.add(_fingerprint(prompt))


def already_auto_bumped(state: EscalationState, prompt: str) -> bool:
    return _fingerprint(prompt) in state.auto_bumped


def record_free_failure(state: EscalationState, prompt: str) -> int:
    """Increment the failure counter for `prompt`. Returns the new count."""
    fp = _fingerprint(prompt)
    state.failure_counts[fp] = state.failure_counts.get(fp, 0) + 1
    return state.failure_counts[fp]


def record_free_success(state: EscalationState, prompt: str) -> None:
    """Free chain succeeded — reset the per-prompt counter so a future
    failure on a DIFFERENT prompt doesn't trigger escalation."""
    fp = _fingerprint(prompt)
    state.failure_counts.pop(fp, None)


def should_escalate(
    state: EscalationState,
    prompt: str,
    *,
    approx_token_load: int = 0,
    has_anthropic_key: bool = False,
) -> EscalationDecision:
    """Decide whether THIS turn should run on Claude instead of the free chain.

    The check order is the priority order — `escalate_next_turn` always
    wins, regardless of the other flags, because it's a direct user
    instruction.
    """
    # Baseline: no key, no escalation. We never silently fail-over to
    # a paid path the user didn't authorize.
    if not has_anthropic_key:
        return EscalationDecision(escalate=False, reason="ANTHROPIC_API_KEY not set")

    # 1. Explicit opt-in. Tier-aware:
    #    /escalate --hard → Opus (most capable, most expensive)
    #    /escalate (no flag) → Sonnet (mid-tier, ~4× cheaper than Opus)
    #    auto-escalation (free chain failed) → Haiku (cheapest tier)
    if state.escalate_next_turn:
        if state.next_turn_hard:
            model = HARD_CLAUDE_MODEL
            reason = "user invoked /escalate --hard"
        elif state.next_turn_sonnet:
            model = SONNET_CLAUDE_MODEL
            reason = "user invoked /escalate"
        else:
            # Bare opt-in defaults to Haiku for credit conservation.
            model = DEFAULT_CLAUDE_MODEL
            reason = "user invoked /escalate"
        return EscalationDecision(escalate=True, model=model, reason=reason)

    # 2. Repeated free-model failure on the same prompt → Haiku.
    # Round-30 P0: auto-escalation now ALWAYS requires the explicit
    # `PROMETHEUS_AUTO_ESCALATE=1` env opt-in, EVEN for failure-based
    # paths. This protects a public deploy's paid credit ($10 budget
    # serving millions of users) — without the opt-in, even a
    # repeatedly-failing prompt can never burn paid credit.
    fp = _fingerprint(prompt)
    n_fails = state.failure_counts.get(fp, 0)
    if (
        os.getenv("PROMETHEUS_AUTO_ESCALATE") == "1"
        and n_fails >= AUTO_ESCALATE_FAILURE_THRESHOLD
    ):
        return EscalationDecision(
            escalate=True,
            model=DEFAULT_CLAUDE_MODEL,  # Haiku — cheapest tier for auto path
            reason=f"free chain failed {n_fails}× on this prompt",
        )

    # 3. Context overflow — opt-in only.
    if (
        os.getenv("PROMETHEUS_AUTO_ESCALATE") == "1"
        and approx_token_load >= AUTO_ESCALATE_TOKEN_THRESHOLD
    ):
        return EscalationDecision(
            escalate=True,
            model=DEFAULT_CLAUDE_MODEL,
            reason=f"context size {approx_token_load} ≥ {AUTO_ESCALATE_TOKEN_THRESHOLD}",
        )

    return EscalationDecision(escalate=False, reason="free chain OK")


def consume_escalate_flag(state: EscalationState) -> None:
    """Called by the agent loop after a turn starts so the next turn
    isn't also escalated unless the user re-issues /escalate."""
    state.escalate_next_turn = False
    state.next_turn_hard = False
    state.next_turn_sonnet = False
