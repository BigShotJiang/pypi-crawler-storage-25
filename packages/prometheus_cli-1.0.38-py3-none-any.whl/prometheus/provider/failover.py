"""Round-33: cross-provider failover for the agent stream layer.

When the primary provider (OpenRouter) returns 429 / 5xx and its own
multi-key rotation pool is exhausted, we cascade through every other
configured provider in `ProviderPool.from_env()` order:

    OpenRouter → Groq → Gemini → Cerebras → NVIDIA → Mistral
                → Together → Cloudflare → Pollinations

Every provider beyond OpenRouter speaks an OpenAI-compatible
`/chat/completions` SSE protocol, which is identical at the wire
level: same body shape (minus OpenRouter-specific fields like
`models` / `provider`), same delta format, same `[DONE]` sentinel.
So the failover layer is a single generic OAI-compat streamer that
parameterises on `(base_url, auth, default_model)`.

Two integration rules the agent stream layer relies on:

  • Failover only fires *before* the first token is yielded. Once we
    surface text to the user, mid-stream provider switching would
    duplicate output. Errors after first-token cascade to the agent
    loop's existing model-fallback layer (see loop.py:_run).
  • Errors are sanitised the same way `openrouter.sanitize_error`
    sanitises them — the user never sees a vendor name or rate-limit
    string. Brand-neutral surface.
"""
from __future__ import annotations

import asyncio
import json
import os
import random
from typing import Any, AsyncIterator

import httpx

from prometheus import log
from prometheus.provider.openrouter import (
    StreamEvent,
    ToolCall,
    sanitize_error,
)
from prometheus.provider.pool import ProviderEntry, ProviderPool
from prometheus.provider.health import (
    default as _health,
    ErrorKind,
    classify_http_status,
    classify_exception,
)

logger = log.get("provider.failover")


def _build_headers(provider: ProviderEntry, key: str) -> dict[str, str]:
    """Provider-specific auth header construction."""
    base = {"Content-Type": "application/json"}
    if provider.auth_style == "none":
        return base
    if provider.name == "Cloudflare":
        # Composite key: "<account_id>:<token>"
        if ":" not in key:
            return base  # malformed — caller will catch the 401
        _, token = key.split(":", 1)
        base["Authorization"] = f"Bearer {token}"
        return base
    if provider.auth_style == "basic":
        # Round-65: HTTP Basic auth — `Authorization: Basic <b64(id:secret)>`.
        # Modal uses this with PROMETHEUS_MODAL_TOKEN_ID:_SECRET.
        # The composite key arrives as "<id>:<secret>" already.
        import base64
        if ":" not in key:
            return base  # malformed — caller will catch the 401
        token = base64.b64encode(key.encode("utf-8")).decode("ascii")
        base["Authorization"] = f"Basic {token}"
        return base
    base["Authorization"] = f"Bearer {key}"
    return base


def _build_url(provider: ProviderEntry, key: str) -> str:
    """Resolve `{account_id}` substitution for Cloudflare; otherwise pass-through."""
    base = provider.base_url
    if provider.name == "Cloudflare" and ":" in key:
        account_id, _ = key.split(":", 1)
        base = base.replace("{account_id}", account_id)
    return f"{base.rstrip('/')}{provider.oai_compat_path}"


def _strip_openrouter_fields(body: dict[str, Any]) -> dict[str, Any]:
    """Remove OpenRouter-only keys before posting to a non-OR provider."""
    cleaned = dict(body)
    for k in ("models", "provider", "reasoning"):
        cleaned.pop(k, None)
    # `usage.include` is an OpenRouter extension; standard OAI returns
    # usage in the final chunk by default with stream_options.
    cleaned.pop("usage", None)
    cleaned["stream_options"] = {"include_usage": True}
    return cleaned


async def stream_via_provider(
    provider: ProviderEntry,
    body: dict[str, Any],
    timeout: float = 120.0,
) -> AsyncIterator[StreamEvent]:
    """Stream against one specific provider in OpenAI-compat SSE format.

    Yields the same StreamEvent vocabulary as OpenRouterClient.stream
    so callers can splice it into their existing event handling. On
    any pre-first-token error, yields a single `error` event and
    returns; the failover orchestrator decides whether to advance to
    the next provider.
    """
    if not provider.configured:
        yield StreamEvent(kind="error", error="provider not configured")
        return
    key = provider.keys[0]  # round-33: per-provider rotation is round-34
    url = _build_url(provider, key)
    headers = _build_headers(provider, key)

    # Substitute model id with the provider's native default when the
    # incoming model id looks OpenRouter-shaped (`vendor/name:tag`).
    req_body = _strip_openrouter_fields(body)
    incoming_model = req_body.get("model", "")
    if "/" in incoming_model or incoming_model.endswith(":free"):
        if provider.default_model:
            req_body["model"] = provider.default_model

    partial: dict[int, ToolCall] = {}
    completed_indices: set[int] = set()
    finish_reason: str | None = None
    usage: dict[str, Any] = {}
    yielded_any = False

    # Round-92 debug: dump request body + response chunks when
    # PROMETHEUS_DEBUG_DUMP=<path> is set. Lets us diagnose what the
    # model actually sees + returns without instrumenting the model's
    # side. Disabled by default (no perf hit). Path is appended to.
    _debug_dump = os.getenv("PROMETHEUS_DEBUG_DUMP")
    if _debug_dump:
        try:
            with open(_debug_dump, "a", encoding="utf-8") as f:
                import datetime as _dt
                f.write(f"\n=== {_dt.datetime.now().isoformat()} REQUEST → {provider.name} {url} ===\n")
                f.write(f"model: {req_body.get('model')!r}\n")
                f.write(f"tool count: {len(req_body.get('tools') or [])}\n")
                msgs = req_body.get('messages') or []
                f.write(f"message count: {len(msgs)}\n")
                for i, m in enumerate(msgs):
                    role = m.get('role','?')
                    content = m.get('content', '')
                    if isinstance(content, list):
                        content = ' / '.join(
                            str(p.get('text', p))[:100] if isinstance(p, dict) else str(p)[:100]
                            for p in content
                        )
                    content_str = str(content) if content else ''
                    tcs = m.get('tool_calls') or []
                    f.write(f"  [{i}] role={role} chars={len(content_str)} tool_calls={len(tcs)}\n")
                    if i == len(msgs) - 1:  # last message: dump full content
                        f.write(f"      content: {content_str[:500]!r}\n")
        except Exception:
            pass

    try:
        # Round 179: HTTP(S)_PROXY + REQUESTS_CA_BUNDLE / SSL_CERT_FILE
        # — corporate networks need this on the failover path too,
        # otherwise the primary provider works behind the proxy and
        # every fallback errors out.
        from prometheus.net import net_kwargs
        async with httpx.AsyncClient(
            **net_kwargs(
                timeout=httpx.Timeout(timeout, connect=10.0),
                headers=headers,
            ),
        ) as client:
            async with client.stream("POST", url, json=req_body) as r:
                if r.status_code >= 400:
                    detail = (await r.aread()).decode("utf-8", "replace")
                    logger.warning(
                        "%s upstream %d: %s",
                        provider.name, r.status_code, detail[:200],
                    )
                    # Round-89: record the error in the health registry
                    # so the next request skips this provider until its
                    # cooldown expires (auth=24h, rate=90s, server=30s).
                    _health().record_error(
                        provider.name,
                        classify_http_status(r.status_code),
                    )
                    yield StreamEvent(
                        kind="error",
                        error=sanitize_error(detail) or "engine busy — retrying",
                    )
                    return
                async for line in r.aiter_lines():
                    if not line or line.startswith(":"):
                        continue
                    if not line.startswith("data:"):
                        continue
                    data = line[5:].strip()
                    if data == "[DONE]":
                        break
                    try:
                        chunk = json.loads(data)
                    except json.JSONDecodeError:
                        continue
                    if "error" in chunk:
                        err = chunk["error"]
                        msg = (
                            err.get("message", str(err))
                            if isinstance(err, dict) else str(err)
                        )
                        yield StreamEvent(kind="error", error=sanitize_error(msg))
                        return
                    choices = chunk.get("choices") or []
                    if choices:
                        c0 = choices[0]
                        delta = c0.get("delta") or {}
                        # Round-64: content shape varies across upstream
                        # providers. OpenAI/OpenRouter return a string;
                        # NVIDIA NIM, Anthropic-compat, and some others
                        # return a list of parts: [{"type":"text",
                        # "text":"..."}, ...]. Pre-64 the parser would
                        # JSON-stringify the whole list and emit it as
                        # text — surfacing raw `{"type":"text","text":"4"}`
                        # in the chat (user-reported live bug).
                        raw = delta.get("content")
                        text_chunk: str | None = None
                        if isinstance(raw, str):
                            text_chunk = raw
                        elif isinstance(raw, list):
                            parts = []
                            for part in raw:
                                if not isinstance(part, dict):
                                    continue
                                ptype = part.get("type", "")
                                if ptype == "text" and part.get("text"):
                                    parts.append(part["text"])
                                elif ptype == "output_text" and part.get("text"):
                                    parts.append(part["text"])
                                # Other part types (image_url, refusal,
                                # tool_use) are silently ignored — they
                                # don't belong in the assistant text
                                # stream.
                            if parts:
                                text_chunk = "".join(parts)
                        if text_chunk:
                            yielded_any = True
                            yield StreamEvent(kind="text", text=text_chunk)
                        for tc in delta.get("tool_calls") or []:
                            idx = tc.get("index", 0)
                            cur = partial.get(idx)
                            if cur is None:
                                cur = ToolCall(
                                    id=tc.get("id", "") or "",
                                    name=(tc.get("function") or {}).get("name", "") or "",
                                    arguments="",
                                )
                                partial[idx] = cur
                            else:
                                if tc.get("id"):
                                    cur.id = tc["id"]
                                fn = tc.get("function") or {}
                                if fn.get("name"):
                                    cur.name = fn["name"]
                            fn = tc.get("function") or {}
                            if "arguments" in fn and fn["arguments"]:
                                cur.arguments += fn["arguments"]
                            yielded_any = True
                            yield StreamEvent(kind="tool_call_delta", tool_call=cur)
                        if c0.get("finish_reason"):
                            finish_reason = c0["finish_reason"]
                            for idx, tc in partial.items():
                                if idx not in completed_indices:
                                    completed_indices.add(idx)
                                    yield StreamEvent(
                                        kind="tool_call_complete", tool_call=tc,
                                    )
                    if chunk.get("usage"):
                        usage = chunk["usage"]
                        yield StreamEvent(kind="usage", usage=usage)
    except (httpx.ConnectError, httpx.TimeoutException) as e:
        logger.warning("%s transport error: %s", provider.name, e)
        # Round-89: classify and record so the next call rotates past
        # this provider until cooldown clears.
        _health().record_error(provider.name, classify_exception(e))
        yield StreamEvent(
            kind="error",
            error=sanitize_error(f"network: {e}"),
        )
        return
    except Exception as e:
        logger.exception("%s unexpected error", provider.name)
        _health().record_error(provider.name, ErrorKind.OTHER)
        yield StreamEvent(kind="error", error=sanitize_error(str(e)))
        return

    for idx, tc in partial.items():
        if idx not in completed_indices:
            completed_indices.add(idx)
            yield StreamEvent(kind="tool_call_complete", tool_call=tc)
    if not yielded_any:
        # An "empty success" — provider returned 200 but no content.
        # Treat as a soft failure so the orchestrator advances.
        _health().record_error(provider.name, ErrorKind.EMPTY)
        yield StreamEvent(kind="error", error="empty response")
        return
    # Round-89: real success — clear any prior cooldown for this
    # provider so it's preferred again on the next request.
    _health().record_success(provider.name)
    # Round-92 debug: log what came back when PROMETHEUS_DEBUG_DUMP is set.
    if _debug_dump:
        try:
            with open(_debug_dump, "a", encoding="utf-8") as f:
                f.write(f"=== RESPONSE ← {provider.name} (finish={finish_reason!r}) ===\n")
                tc_summary = [(tc.name, (tc.arguments or '')[:80]) for tc in partial.values()]
                f.write(f"tool_calls observed: {tc_summary}\n")
        except Exception:
            pass
    yield StreamEvent(kind="done", finish_reason=finish_reason, usage=usage)


async def stream_with_failover(
    body: dict[str, Any],
    skip_providers: tuple[str, ...] = ("OpenRouter",),
    timeout: float = 120.0,
    prefer_provider: str | None = None,
) -> AsyncIterator[StreamEvent]:
    """Cascade through every configured non-skipped provider in order.

    Buffers events from each provider until we either get a `text` /
    `tool_call_delta` (commit — pass through to caller and stop), or
    hit an `error` before any token (move on to next provider).

    Round-63: optional `prefer_provider` puts that provider FIRST in
    the cascade order. Used by task-aware routing — PLANNING goes to
    NVIDIA first, SIMPLE/SUBAGENT goes to Groq first. If the preferred
    provider isn't configured or fails, the rest of the cascade runs
    as usual.

    If every provider fails, yields a single sanitised error event.
    """
    pool = ProviderPool.from_env()
    # Order is the canonical Round-33 cascade defined by from_env()
    # ordering (OpenRouter first, Pollinations last). We skip the
    # provider(s) the caller already exhausted.
    all_candidates = [
        p for p in pool.configured_providers()
        if p.name not in skip_providers
    ]
    # Round-89: split into healthy + cooled-down. Healthy providers
    # try first; cooled-down providers are kept as last-resort
    # fallback (so the request still has a chance if every healthy
    # provider also fails — better than refusing service entirely).
    health = _health()
    healthy = [p for p in all_candidates if health.is_healthy(p.name)]
    cooling = [p for p in all_candidates if not health.is_healthy(p.name)]
    if cooling:
        for p in cooling:
            h = health.get(p.name)
            logger.info(
                "failover: skipping %s (cooldown %ds, last_error=%s)",
                p.name, int(h.cooldown_remaining_s),
                h.last_error_kind.value if h.last_error_kind else "?",
            )
    candidates = healthy + cooling
    # Round-63: pull the preferred provider to the front if configured
    # AND it's healthy. Don't promote a cooled-down provider — that
    # would defeat the purpose of the cooldown.
    if prefer_provider:
        for i, p in enumerate(candidates):
            if p.name == prefer_provider and i > 0 and health.is_healthy(p.name):
                candidates.insert(0, candidates.pop(i))
                break
    if not candidates:
        yield StreamEvent(
            kind="error",
            error="all engines exhausted — try again in a minute",
        )
        return

    last_error = "engine unavailable"
    for provider in candidates:
        logger.info(
            "failover: trying %s (%d keys, %d/day)",
            provider.name, len(provider.keys), provider.free_per_day,
        )
        # Buffer head events until either a token commits or an error
        # surfaces. Streaming events are async, so we have to peek by
        # collecting until the first non-error/non-usage event.
        buffer: list[StreamEvent] = []
        committed = False
        async for ev in stream_via_provider(provider, body, timeout=timeout):
            if not committed:
                if ev.kind == "error":
                    last_error = ev.error or last_error
                    logger.info(
                        "failover: %s failed pre-token: %s",
                        provider.name, last_error,
                    )
                    break  # try next provider
                if ev.kind in ("text", "tool_call_delta"):
                    committed = True
                    # Replay buffered usage events, then yield this one
                    for buf in buffer:
                        yield buf
                    buffer.clear()
                    yield ev
                else:
                    buffer.append(ev)
            else:
                yield ev
        if committed:
            return
    yield StreamEvent(
        kind="error",
        error=sanitize_error(last_error) or "engines busy — try again",
    )


def _backoff_jitter(attempt: int) -> float:
    base = 0.5 * (2 ** attempt)
    return max(0.1, base + random.uniform(-0.2, 0.2) * base)
