"""Round-31/32/35 multi-provider key pool.

Beyond OpenRouter's free tier, eight key-only providers offer generous
free quotas with no credit card and no gateway deployment burden.
Stacking them gives PrometheUS a much higher effective ceiling at $0
cost. The pool is read at process start from environment variables.

Free-tier capacity (May 2026, research-confirmed):

  OpenRouter      → 50/day per key uncredited; 1000/day with $10 paid.
                    PROMETHEUS_API_KEYS — handled in openrouter.py.
  Groq            → 14,400 req/day, 700+ tok/s. Llama 3.3 70B + Llama 4.
                    PROMETHEUS_GROQ_KEYS.
  Google AI       → ~500 req/day Gemini 2.5 Flash, no card.
                    PROMETHEUS_GEMINI_KEYS.
  Cerebras        → ~2,000 req/day Llama 3.3 70B, 2000 tok/s free.
                    PROMETHEUS_CEREBRAS_KEYS.
  NVIDIA          → Frontier free models incl. MiniMax M2.7 (top
                    multi-turn tool-calling scores) + GLM-5.1.
                    PROMETHEUS_NVIDIA_KEYS.
  Mistral La Plat → 1B tokens/month free w/ phone verify. Codestral-
                    latest (123B coder, frontier SWE-Bench scores).
                    PROMETHEUS_MISTRAL_KEYS.
  Together AI     → $25 free credits, 200+ models incl. DeepSeek-V3 +
                    Qwen3-Coder. PROMETHEUS_TOGETHER_KEYS.
  Cloudflare      → 10K neurons/day, no card.
                    PROMETHEUS_CLOUDFLARE_ACCOUNT_ID +
                    PROMETHEUS_CLOUDFLARE_API_TOKEN.
  Pollinations    → Zero-config: no key, no signup. Rate-limited free
                    text endpoint. Auto-included.
  FreeClaude      → Local proxy routing to NVIDIA NIM + OpenRouter.
                    PROMETHEUS_FREECLAUDE_URL.

This module exposes:
  • `ProviderPool` — read-only snapshot of available providers + counts
  • `pool_status()` — formatted multi-line status string for /provider
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass
class ProviderEntry:
    """One configured provider in the multi-pool."""
    name: str            # human-readable: "OpenRouter", "Groq", ...
    keys: list[str]      # list of API keys configured (count = capacity)
    env_var: str         # env var the keys come from
    base_url: str        # API base URL
    free_per_day: int    # rough per-key daily ceiling (for status display)
    notes: str = ""      # extra info: "frontier coding", "fastest", etc.
    # Round-33: cross-provider failover wiring. Every non-OpenRouter
    # provider in the pool is OpenAI-compatible. We just need the
    # default model id and the OAI-compat path suffix (Gemini for
    # example serves OAI-compat at /openai/ under /v1beta).
    default_model: str = ""           # provider-native model id
    # Round-79: optional ordered list of model IDs the provider knows
    # about. Used by /provider status display and audit checks; doesn't
    # by itself implement intra-provider failover (cross-provider
    # failover is the existing mechanism). For NVIDIA the chain
    # documents the agentic-first models the user opt-in into via
    # PROMETHEUS_NVIDIA_DEFAULT_MODEL: Kimi K2.6 / MiniMax M2.7 /
    # GLM-4.7. Future work could rotate within model_chain on hard
    # provider error, but rounds 77/78 showed the failure mode is
    # watchdog timeout (model loops without converging), which model
    # rotation doesn't address — the failure is at the provider's
    # response level, not the HTTP level.
    model_chain: list[str] = field(default_factory=list)
    oai_compat_path: str = "/chat/completions"  # appended to base_url
    auth_style: str = "bearer"        # "bearer" | "none" | "x-api-key"
    # Round-88: capability tags for intelligent task routing.
    # Recognized tags:
    #   fast          — sub-second time-to-first-token
    #   coder         — strong on code edits / SWE-Bench
    #   planner       — strong reasoning / multi-step planning
    #   long_context  — handles >100k token inputs cleanly
    #   free          — sustained zero-cost free tier (no trial credits)
    #   fallback      — appropriate as a backup when primary chain stalls
    #   vision        — multimodal (image input)
    # Tags are advisory; real routing also consults health + preference.
    tags: set[str] = field(default_factory=set)

    @property
    def configured(self) -> bool:
        return len(self.keys) > 0

    @property
    def total_daily_capacity(self) -> int:
        return self.free_per_day * len(self.keys) if self.configured else 0


def _load_keys(var: str) -> list[str]:
    raw = os.getenv(var, "") or ""
    return [k.strip() for k in raw.split(",") if k.strip()]


@dataclass
class ProviderPool:
    """Read-only snapshot of every configured upstream provider.

    The actual routing logic lives in openrouter.py / escalate.py;
    this module only enumerates capacity. Future round 32 work will
    add per-provider HTTP clients + automatic failover at the
    AgentLoop layer (`OpenRouter → Groq → Gemini → Cerebras`).
    """
    providers: list[ProviderEntry] = field(default_factory=list)

    @classmethod
    def from_env(cls) -> "ProviderPool":
        # OpenRouter pool — multi-key from PROMETHEUS_API_KEYS, falls
        # back to single PROMETHEUS_API_KEY / OPENROUTER_API_KEY.
        or_keys = _load_keys("PROMETHEUS_API_KEYS")
        if not or_keys:
            single = (
                os.getenv("PROMETHEUS_API_KEY")
                or os.getenv("OPENROUTER_API_KEY")
                or ""
            ).strip()
            if single:
                or_keys = [single]
        # Cloudflare is split across two env vars; we treat the
        # `<account_id>:<token>` pair as a single composite "key" so
        # the rest of the pool plumbing is uniform.
        cf_account = (os.getenv("PROMETHEUS_CLOUDFLARE_ACCOUNT_ID") or "").strip()
        cf_token = (os.getenv("PROMETHEUS_CLOUDFLARE_API_TOKEN") or "").strip()
        cf_keys = [f"{cf_account}:{cf_token}"] if (cf_account and cf_token) else []
        # Pollinations is the special always-available zero-config
        # provider. We synthesize a placeholder "key" so it shows up
        # in /provider as configured even when the user hasn't done
        # anything, and treat the empty string downstream as "no auth
        # header needed."
        pollinations_keys = ["zero-config"]
        # Round-55: OpenClaw self-hosted gateway. Activates when the
        # operator sets PROMETHEUS_OPENCLAW_URL=<url> (canonical local
        # default: http://localhost:18789/v1). No API key — gateway
        # uses an internal auth token tied to the user's browser
        # session. Inert for users who don't run OpenClaw.
        openclaw_url = (os.getenv("PROMETHEUS_OPENCLAW_URL") or "").strip()
        if not openclaw_url and os.getenv("PROMETHEUS_OPENCLAW") == "1":
            # Convenience: PROMETHEUS_OPENCLAW=1 picks the canonical
            # localhost default, so users running it on the standard
            # port don't have to type the URL.
            openclaw_url = "http://localhost:18789/v1"
        openclaw_keys = ["zero-config"] if openclaw_url else []
        # Round-64: FreeClaude Bridge — local proxy routing to
        # NVIDIA NIM + OpenRouter. Activates when the operator sets
        # PROMETHEUS_FREECLAUDE_URL=<url>. No API key — the proxy
        # uses keys embedded in its own .env. Inert when not running.
        freeclaude_url = (os.getenv("PROMETHEUS_FREECLAUDE_URL") or "").strip()
        freeclaude_keys = ["zero-config"] if freeclaude_url else []
        # Round-68: GPT4Free (gpt4free, github.com/xtekky/gpt4free) self-
        # hosted OpenAI-compat gateway. Default localhost:1337 if user
        # sets PROMETHEUS_GPT4FREE=1, or specify PROMETHEUS_GPT4FREE_URL
        # for a custom location. The gateway has its OWN .env for
        # upstream API keys (OpenRouter, Anthropic, OpenAI keys live
        # there, not here) — PrometheUS just speaks OAI-compat to it.
        gpt4free_url = (os.getenv("PROMETHEUS_GPT4FREE_URL") or "").strip()
        if not gpt4free_url and os.getenv("PROMETHEUS_GPT4FREE") == "1":
            gpt4free_url = "http://localhost:1337/v1"
        gpt4free_keys = ["zero-config"] if gpt4free_url else []
        # Round-65: Modal GLM-5.1 endpoint. Two-var auth like Cloudflare:
        # PROMETHEUS_MODAL_TOKEN_ID + PROMETHEUS_MODAL_TOKEN_SECRET form
        # an HTTP Basic credential. Composite key `<id>:<secret>` is
        # base64-encoded by failover._build_headers when auth_style="basic".
        modal_id = (os.getenv("PROMETHEUS_MODAL_TOKEN_ID") or "").strip()
        modal_secret = (os.getenv("PROMETHEUS_MODAL_TOKEN_SECRET") or "").strip()
        modal_keys = (
            [f"{modal_id}:{modal_secret}"]
            if (modal_id and modal_secret) else []
        )
        # Round-86: simplified back to the 13 proven providers. The
        # Kiro / Antigravity / NadirClaw / ClaudeCodeRouter /
        # HuggingFace / SambaNova / Ollama / LMStudio slots added in
        # rounds 81-84 were never fully activated/tested in this
        # environment and added complexity without empirical wins.
        providers = [
            ProviderEntry(
                name="OpenRouter",
                keys=or_keys,
                env_var="PROMETHEUS_API_KEYS",
                base_url="https://openrouter.ai/api/v1",
                free_per_day=1000,
                notes="frontier free chain (MiniMax M2.5, Ling-2.6, Qwen3-Coder, Nemotron-3)",
                # Round-76: align with CODER_CHAIN[0]. The previous default
                # `moonshotai/kimi-k2.6:free` was a 404 against OpenRouter's
                # live catalog (probed 2026-05-05); every primary call wasted
                # one round-trip on a 404 before the `models[]` body field
                # rotated. CODER_CHAIN's dead-tail still keeps that slug for
                # transparent re-activation if OpenRouter republishes Kimi free.
                default_model="minimax/minimax-m2.5:free",
                tags={"coder", "long_context", "free", "fallback"},
            ),
            ProviderEntry(
                name="Groq",
                keys=_load_keys("PROMETHEUS_GROQ_KEYS"),
                env_var="PROMETHEUS_GROQ_KEYS",
                base_url="https://api.groq.com/openai/v1",
                free_per_day=14400,
                notes="700+ tok/s, Llama 3.3 70B + Llama 4 Scout/Maverick",
                default_model="llama-3.3-70b-versatile",
                tags={"fast", "free"},
            ),
            ProviderEntry(
                name="Gemini",
                keys=_load_keys("PROMETHEUS_GEMINI_KEYS"),
                env_var="PROMETHEUS_GEMINI_KEYS",
                base_url="https://generativelanguage.googleapis.com/v1beta/openai",
                # Round-85: Google reduced the Gemini free tier on
                # 2026-12-07 (research-confirmed): 2.5 Pro = 100 RPD /
                # 5 RPM; 2.5 Flash dropped from 250 RPD to ~50. We
                # use 100/day as a conservative honest cap (was 500).
                # Per-project, not per-key — multi-key sharding has
                # no effect. Note: free-tier inputs are used for
                # training per Google's published policy.
                free_per_day=100,
                notes="Gemini 2.5 Flash — 100 RPD / 5 RPM (training-eligible)",
                default_model="gemini-2.5-flash",
                tags={"fast", "vision", "free", "long_context"},
            ),
            ProviderEntry(
                name="Cerebras",
                keys=_load_keys("PROMETHEUS_CEREBRAS_KEYS"),
                env_var="PROMETHEUS_CEREBRAS_KEYS",
                base_url="https://api.cerebras.ai/v1",
                free_per_day=2000,
                notes="2,000 tok/s Llama 3.3 70B",
                default_model="llama-3.3-70b",
                tags={"fast", "free"},
            ),
            ProviderEntry(
                name="NVIDIA",
                keys=_load_keys("PROMETHEUS_NVIDIA_KEYS"),
                env_var="PROMETHEUS_NVIDIA_KEYS",
                base_url="https://integrate.api.nvidia.com/v1",
                free_per_day=1000,
                notes=(
                    "Frontier reasoner + agentic-first free chain "
                    "(40 req/min, no credit card). Hosts Kimi K2.6 / "
                    "MiniMax M2.7 / GLM-4.7 free."
                ),
                # Round-63: nvidia/nemotron-3-nano-omni-30b-a3b-reasoning
                # is the verified-working default — Claude-class reasoning,
                # high speed. Round-76 added PROMETHEUS_NVIDIA_DEFAULT_MODEL
                # override. Round-79: documented an agentic-first
                # model_chain (Kimi K2.6 → MiniMax M2.7 → GLM-4.7), all
                # probe-verified live on NVIDIA NIM.
                #
                # Empirical record on the 4-task chain-heavy suite:
                #   r77 Kimi K2.6 alone   : 0/4 PASS (4 SKIP, watchdog)
                #   r78 MiniMax M2.7 alone: 0/4 PASS (2 SKIP, 2 FAIL)
                # M2.7 was 5× faster on Task 7 (100s vs 547s) but the
                # edit was equally wrong; on Task 6 it didn't call
                # git_clone at all. Speed isn't the ceiling — output
                # correctness on multi-step sequences is.
                #
                # Default stays on Nemotron because no single model
                # has cleared the suite. Flipping requires empirical
                # 4/4 evidence, not marketing claims. See
                # router.py preferred_provider_for() for the cross-
                # round empirical record.
                default_model=(
                    os.getenv("PROMETHEUS_NVIDIA_DEFAULT_MODEL")
                    or "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning"
                ),
                model_chain=[
                    "moonshotai/kimi-k2.6",     # PrometheUS Falcon
                    "minimaxai/minimax-m2.7",   # PrometheUS Force
                    "z-ai/glm4.7",              # PrometheUS Vision (NVIDIA slug)
                    "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning",
                ],
                tags={"planner", "long_context", "free"},
            ),
            ProviderEntry(
                name="Mistral",
                keys=_load_keys("PROMETHEUS_MISTRAL_KEYS"),
                env_var="PROMETHEUS_MISTRAL_KEYS",
                base_url="https://api.mistral.ai/v1",
                free_per_day=33000,
                notes="Codestral-latest (123B coder, frontier SWE-Bench scores)",
                default_model="codestral-latest",
                tags={"coder", "free"},
            ),
            ProviderEntry(
                name="Together",
                keys=_load_keys("PROMETHEUS_TOGETHER_KEYS"),
                env_var="PROMETHEUS_TOGETHER_KEYS",
                base_url="https://api.together.xyz/v1",
                free_per_day=10000,
                notes="DeepSeek-V3 + Qwen3-Coder, $25 free credits",
                default_model="deepseek-ai/DeepSeek-V3",
                tags={"coder", "long_context"},
            ),
            ProviderEntry(
                name="Cloudflare",
                keys=cf_keys,
                env_var="PROMETHEUS_CLOUDFLARE_ACCOUNT_ID + _API_TOKEN",
                base_url=(
                    "https://api.cloudflare.com/client/v4/accounts/"
                    "{account_id}/ai/v1"
                ),
                free_per_day=3000,
                notes="Workers AI, 10K neurons/day",
                default_model="@cf/meta/llama-3.3-70b-instruct-fp8-fast",
                tags={"fast", "free"},
            ),
            ProviderEntry(
                name="Pollinations",
                keys=pollinations_keys,
                env_var="(zero-config)",
                base_url="https://text.pollinations.ai/openai",
                free_per_day=5000,
                notes="zero-config OpenAI-compat fallback",
                default_model="openai-large",
                auth_style="none",
                tags={"free", "fallback"},
            ),
            # Round-55: OpenClaw — self-hosted browser-bridge gateway.
            ProviderEntry(
                name="OpenClaw",
                keys=openclaw_keys,
                env_var="PROMETHEUS_OPENCLAW_URL",
                base_url=openclaw_url or "(set PROMETHEUS_OPENCLAW_URL)",
                free_per_day=5000,
                notes="self-hosted browser-bridge to frontier closed-source",
                default_model="claude-opus-4-6",
                auth_style="none",
                tags={"planner", "coder", "long_context"},
            ),
            # Round-64: FreeClaude Bridge — local proxy that routes
            # Anthropic-format API calls to NVIDIA NIM + OpenRouter.
            ProviderEntry(
                name="FreeClaude",
                keys=freeclaude_keys,
                env_var="PROMETHEUS_FREECLAUDE_URL",
                base_url=freeclaude_url or "(set PROMETHEUS_FREECLAUDE_URL)",
                free_per_day=5000,
                notes="local free-tier proxy (frontier-class via NVIDIA & OpenRouter)",
                default_model="claude-sonnet-4-6",
                auth_style="none",
                tags={"coder", "free", "fallback"},
            ),
            # Round-68: GPT4Free local OAI-compat gateway. Auth lives
            # inside the gateway's own .env — PrometheUS just speaks
            # OpenAI-compat to it (no API key on our side).
            #
            # Round-76 user-verified: GPT4Free responds on
            # http://127.0.0.1:1337 once it's running. To activate the
            # provider chains it speaks to (OpenRouter, etc.), the user
            # must populate the gpt4free repo's OWN `.env` with their
            # provider keys (e.g. OPENROUTER_API_KEY, GEMINI_API_KEY).
            # PrometheUS does NOT pass keys through — gpt4free reads
            # them itself. This is third-party config, outside the
            # PrometheUS process; we just speak OpenAI-compat to its
            # /v1/chat/completions.
            ProviderEntry(
                name="GPT4Free",
                keys=gpt4free_keys,
                env_var="PROMETHEUS_GPT4FREE_URL",
                base_url=gpt4free_url or "(set PROMETHEUS_GPT4FREE_URL)",
                free_per_day=5000,
                notes=(
                    "local gpt4free gateway (third-party, 500+ models "
                    "incl. gpt-5.2, gemini-3-pro, deepseek-v3.2). "
                    "Activation: populate gpt4free's own .env with "
                    "OPENROUTER_API_KEY etc., then restart its server."
                ),
                default_model="gpt-3.5-turbo",
                # Round-80: documented aliases the user can pass via
                # /model — gpt4free maps these to its internal scrapers.
                # Listed for /provider display + audit; not failover
                # (gpt4free decides which scraper to use per call).
                model_chain=[
                    "gpt-5.2",            # OpenAI flagship via gpt4free scrape
                    "gemini-3-pro",       # Google flagship via gpt4free scrape
                    "deepseek-v3.2",      # DeepSeek flagship via gpt4free scrape
                    "gpt-3.5-turbo",      # safe fallback
                ],
                auth_style="none",
                tags={"free", "fallback"},
            ),
            # Round-65: Modal GLM-5.1 endpoint. HTTP Basic auth via
            # token_id:token_secret composite. GLM-5.1 was the #1
            # SWE-Bench Pro model at launch; Modal hosts it with no
            # token cap (QPS-limited only).
            ProviderEntry(
                name="Modal",
                keys=modal_keys,
                env_var="PROMETHEUS_MODAL_TOKEN_ID + _SECRET",
                base_url="https://api.us-west-2.modal.direct/v1",
                free_per_day=10000,  # QPS-limited; ~10k/day is conservative
                notes="GLM-5.1 — #1 SWE-Bench Pro, unlimited tokens, QPS-limited",
                default_model="glm-5-endpoint",
                auth_style="basic",
                tags={"coder", "planner", "long_context"},
            ),
        ]
        return cls(providers=providers)

    def configured_providers(self) -> list[ProviderEntry]:
        return [p for p in self.providers if p.configured]

    def total_capacity(self) -> int:
        return sum(p.total_daily_capacity for p in self.providers)


# Round-56: PrometheUS Undercover Mode — every upstream provider name
# the operator configures via env vars maps to a brand-neutral
# PrometheUS tier label. End users see only these labels; the upstream
# vendor is never surfaced in non-admin chat output.
_PROVIDER_TIERS: dict[str, str] = {
    "OpenRouter":   "PrometheUS Core",
    "Groq":         "PrometheUS Plus",
    "Gemini":       "PrometheUS Lightning",
    "Cerebras":     "PrometheUS Ultra",
    "Mistral":      "PrometheUS Pro",
    "Pollinations": "PrometheUS Auxiliary",
    "OpenClaw":     "PrometheUS Gateway",
    "NVIDIA":       "PrometheUS Accelerator",
    "Cloudflare":   "PrometheUS Edge",
    "Together":     "PrometheUS Collaborate",
    "FreeClaude":   "PrometheUS Bridge",
    "Modal":        "PrometheUS Logic",
    "GPT4Free":     "PrometheUS Nexus",
}


def provider_tier(name: str) -> str:
    """Map an upstream provider name to its PrometheUS tier label.

    Falls back to a generic 'PrometheUS Tier' for any unknown
    provider so a future addition can't accidentally leak the raw
    name before the mapping is updated.
    """
    return _PROVIDER_TIERS.get(name, "PrometheUS Tier")


def pool_status(admin: bool | None = None) -> str:
    """Render a /provider status block.

    Round-56: two views.
      • non-admin (default): clean tier labels, no upstream names,
        no daily counts, no $0/free language. Just confirms the
        pool is active and lists tiers in cascade order.
      • admin (PROMETHEUS_ADMIN=1): tier→upstream mapping with
        capacity numbers so the operator can debug.

    Pass admin=True/False to override the env-var sniff (used by
    audit scenarios that don't want to mutate global env state).
    """
    if admin is None:
        admin = os.getenv("PROMETHEUS_ADMIN") == "1"
    pool = ProviderPool.from_env()
    configured = pool.configured_providers()
    if not configured:
        return (
            "Provider pool not configured."
            if not admin
            else (
                "no providers configured · set PROMETHEUS_API_KEYS for OpenRouter, "
                "PROMETHEUS_GROQ_KEYS for Groq, PROMETHEUS_GEMINI_KEYS for Gemini, "
                "PROMETHEUS_CEREBRAS_KEYS for Cerebras"
            )
        )

    failover_disabled = os.getenv("PROMETHEUS_DISABLE_FAILOVER") == "1"
    failover_note = (
        "failover off"
        if failover_disabled
        else "failover on"
    )

    if not admin:
        # Public / end-user view — tier labels only, no vendor names,
        # no capacity numbers, no $0/free language.
        lines = ["Provider pool active. All tiers operational."]
        tier_w = max(
            (len(provider_tier(p.name)) for p in configured), default=20,
        )
        for idx, p in enumerate(configured, 1):
            cascade_tag = "primary" if idx == 1 else "fallback"
            lines.append(
                f"  {provider_tier(p.name):<{tier_w}}  #{idx} {cascade_tag}"
            )
        lines.append(f"  {failover_note}")
        return "\n".join(lines)

    # Admin view — full debug table with tier → upstream → capacity.
    lines = ["multi-provider free pool (admin view):"]
    tier_w = max(
        (len(provider_tier(p.name)) for p in pool.providers), default=20,
    )
    # Round-59: drop the column padding on (provider) — it produced
    # ugly trailing spaces like "(Gemini      )" that the user flagged.
    cascade_idx = 0
    for p in pool.providers:
        tier = provider_tier(p.name)
        if not p.configured:
            lines.append(
                f"  {tier:<{tier_w}}  ({p.name})  "
                f"not configured  ·  set {p.env_var}"
            )
        else:
            cascade_idx += 1
            kc = len(p.keys)
            cascade_tag = (
                f"#{cascade_idx} primary" if cascade_idx == 1
                else f"#{cascade_idx} fallback"
            )
            lines.append(
                f"  {tier:<{tier_w}}  ({p.name})  "
                f"{kc} key{'s' if kc != 1 else ''} × {p.free_per_day:,} "
                f"= {p.total_daily_capacity:,}/day  ·  {cascade_tag}  ·  "
                f"{p.notes}"
            )
    detailed_failover = (
        "failover off (PROMETHEUS_DISABLE_FAILOVER=1)"
        if failover_disabled
        else "failover on (429/5xx/empty-200 → next fallback)"
    )
    lines.append(
        f"  total  ~ {pool.total_capacity():,} req/day at $0  ·  "
        f"{detailed_failover}"
    )
    return "\n".join(lines)