"""Anthropic Claude streaming client.

Used as a *credit-conscious fallback* — free OpenRouter models handle
every turn by default; Claude only fires when (a) the user explicitly
asks for it via /escalate or `ultrathink` + a long prompt, (b) the free
chain has failed N times consecutively on the SAME prompt, or (c) the
prompt itself is too large for free-tier context windows.

Mirrors the OpenRouter client's StreamEvent surface so loop.py can
consume either provider with the same async iterator. Hides every
Anthropic-specific identifier from end users (sanitize_error reused).

Auth:
    ANTHROPIC_API_KEY  — required when this provider is used.
    PROMETHEUS_CLAUDE_MODEL — defaults to claude-sonnet-4-6 (cheap, fast).
                              Power users can override to claude-opus-4-7.

Cost tracking:
    Anthropic returns input/output token counts in the message_delta
    event; we map those to the same usage shape the OpenRouter client
    yields (prompt_tokens / completion_tokens / cost). Cost in USD is
    estimated from PRICING below; users see live spend in /cost.

CRITICAL — credit conservation:
    Each call here costs real money. The agent loop must never reach
    Claude on a turn that the free chain can answer. router.py's
    `should_escalate()` is the gatekeeper.
"""
from __future__ import annotations

import json
import os
from typing import Any, AsyncIterator

from prometheus import log
from prometheus.provider.openrouter import (
    StreamEvent,
    ToolCall,
    sanitize_error,
)

logger = log.get("provider.escalate")


def _load_pricing_from_disk() -> tuple[dict[str, tuple[float, float]], str, float, float, str]:
    """Round-18: pricing now lives in `pricing.json` next to this
    module so a vendor price change is a one-file refresh, not an
    edit to PRICING constants. Returns (table, fallback_model,
    cache_create_mult, cache_read_mult, last_updated).

    Falls back to the previous hard-coded constants if the JSON file
    is unreadable so an OS-level filesystem hiccup doesn't break
    /cost telemetry.
    """
    import json as _json
    import os as _os
    here = _os.path.dirname(_os.path.abspath(__file__))
    path = _os.path.join(here, "pricing.json")
    try:
        with open(path, encoding="utf-8") as f:
            doc = _json.load(f)
        models = {k: tuple(v) for k, v in (doc.get("models") or {}).items()}
        fallback = str(doc.get("fallback_model") or "claude-sonnet-4-6")
        cc = float(doc.get("cache_create_multiplier") or 1.25)
        cr = float(doc.get("cache_read_multiplier") or 0.10)
        last = str(doc.get("last_updated") or "")
        if not models:
            raise ValueError("empty pricing models")
        return models, fallback, cc, cr, last
    except Exception:
        return (
            {
                "claude-opus-4-7":   (15.00, 75.00),
                "claude-sonnet-4-6": (3.00,  15.00),
                "claude-haiku-4-5":  (1.00,  5.00),
            },
            "claude-sonnet-4-6",
            1.25, 0.10, "",
        )


PRICING, _PRICING_FALLBACK, _CACHE_CREATE_MULT, _CACHE_READ_MULT, PRICING_LAST_UPDATED = _load_pricing_from_disk()


def pricing_is_stale(max_age_days: int = 90) -> bool:
    """Return True if the pricing.json `last_updated` stamp is older
    than `max_age_days`. Surfaced via `--doctor` so users notice when
    their /cost numbers may have drifted from public rates.
    """
    try:
        from datetime import datetime, timezone
        if not PRICING_LAST_UPDATED:
            return True
        stamp = datetime.fromisoformat(PRICING_LAST_UPDATED).replace(tzinfo=timezone.utc)
        age = (datetime.now(timezone.utc) - stamp).days
        return age > max_age_days
    except Exception:
        return False


def estimate_cost(
    model: str,
    prompt_tokens: int,
    completion_tokens: int,
    cache_creation_tokens: int = 0,
    cache_read_tokens: int = 0,
) -> float:
    """USD estimate from PRICING. Falls back to the configured fallback
    model's pricing for unknown model ids so cost is never wildly
    under-reported.

    Cache pricing: cache_creation tokens cost _CACHE_CREATE_MULT × the
    base input rate (5-min ephemeral TTL); cache_read tokens cost
    _CACHE_READ_MULT × the base input rate. With 70-85% cache hits
    typical on agentic loops, this is a 3-4× input-cost multiplier on
    the budget.
    """
    p_in, p_out = PRICING.get(model, PRICING[_PRICING_FALLBACK])
    return (
        prompt_tokens * p_in
        + cache_creation_tokens * p_in * _CACHE_CREATE_MULT
        + cache_read_tokens * p_in * _CACHE_READ_MULT
        + completion_tokens * p_out
    ) / 1_000_000


class AnthropicClient:
    """Streaming Claude client.

    Lazy import: the `anthropic` package is only required when this
    class is constructed. Users who never escalate never need it
    installed.
    """

    def __init__(
        self,
        api_key: str | None = None,
        timeout: float = 120.0,
    ) -> None:
        key = api_key or os.getenv("ANTHROPIC_API_KEY", "")
        if not key:
            # Round 96.21: keep the env-var name (it's literal config
            # for the upstream provider) but reframe the prose so the
            # public error doesn't lead with a competitor brand.
            raise RuntimeError(
                "premium escalation requires ANTHROPIC_API_KEY in "
                "your environment."
            )
        try:
            import anthropic  # noqa: F401
        except ImportError as e:
            raise RuntimeError(
                "premium escalation SDK not installed. Run: "
                "pip install anthropic"
            ) from e
        from anthropic import AsyncAnthropic
        self._client = AsyncAnthropic(api_key=key, timeout=timeout)
        self.timeout = timeout

    async def __aenter__(self) -> "AnthropicClient":
        return self

    async def __aexit__(self, *exc: Any) -> None:
        # AsyncAnthropic owns its httpx client; close it via context exit.
        try:
            await self._client.close()
        except Exception:
            pass

    @staticmethod
    def _to_anthropic_messages(
        messages: list[dict[str, Any]],
    ) -> tuple[str, list[dict[str, Any]]]:
        """Split the OpenAI-style message list into (system, messages).

        Claude wants `system` as a top-level string and `messages` as
        the user/assistant transcript. Tool messages get rewritten as
        Claude's `tool_result` content blocks.
        """
        system_chunks: list[str] = []
        out: list[dict[str, Any]] = []
        for m in messages:
            role = m.get("role")
            content = m.get("content")
            if role == "system":
                if isinstance(content, str) and content.strip():
                    system_chunks.append(content)
                continue
            if role == "tool":
                # OpenAI tool message: {role, tool_call_id, name, content}
                # Claude equivalent: a `user` message with one tool_result block.
                out.append({
                    "role": "user",
                    "content": [{
                        "type": "tool_result",
                        "tool_use_id": m.get("tool_call_id", ""),
                        "content": str(content or ""),
                    }],
                })
                continue
            if role == "assistant":
                # OpenAI assistant: {role, content?, tool_calls?}
                blocks: list[dict[str, Any]] = []
                if isinstance(content, str) and content:
                    blocks.append({"type": "text", "text": content})
                for tc in m.get("tool_calls") or []:
                    fn = tc.get("function") or {}
                    try:
                        args = json.loads(fn.get("arguments") or "{}")
                    except json.JSONDecodeError:
                        args = {}
                    blocks.append({
                        "type": "tool_use",
                        "id": tc.get("id", ""),
                        "name": fn.get("name", ""),
                        "input": args,
                    })
                if not blocks:
                    blocks = [{"type": "text", "text": ""}]
                out.append({"role": "assistant", "content": blocks})
                continue
            # default user
            if isinstance(content, list):
                # OpenAI-multipart → Anthropic block list. Audit P0:
                # passing image_url shape directly to Claude either
                # silently drops the image or 400s.
                converted: list[dict[str, Any]] = []
                for part in content:
                    ptype = part.get("type")
                    if ptype == "text":
                        converted.append({
                            "type": "text",
                            "text": part.get("text", ""),
                        })
                    elif ptype == "image_url":
                        url_obj = part.get("image_url") or {}
                        # Accept either {"url": ...} or a plain string —
                        # some upstream callers emit the unwrapped form.
                        if isinstance(url_obj, dict):
                            url = url_obj.get("url", "")
                        else:
                            url = str(url_obj)
                        if not url:
                            logger.warning(
                                "dropping malformed image_url part (no url): %r",
                                part,
                            )
                            continue
                        if url.startswith("data:"):
                            # data:image/png;base64,iVBOR... → split into media_type + b64.
                            try:
                                header, b64 = url.split(",", 1)
                                media_type = header.split(";")[0].split(":", 1)[1]
                                if not media_type or not b64:
                                    raise ValueError("empty media_type or data")
                            except Exception:
                                logger.warning(
                                    "dropping malformed data: URL: %r",
                                    url[:80],
                                )
                                continue
                            converted.append({
                                "type": "image",
                                "source": {
                                    "type": "base64",
                                    "media_type": media_type,
                                    "data": b64,
                                },
                            })
                        else:
                            converted.append({
                                "type": "image",
                                "source": {"type": "url", "url": url},
                            })
                    # Unknown part types are dropped — Claude rejects
                    # unknown content shapes with 400.
                if not converted:
                    converted = [{"type": "text", "text": ""}]
                out.append({"role": "user", "content": converted})
            else:
                out.append({"role": "user", "content": str(content or "")})
        return "\n\n".join(system_chunks), out

    @staticmethod
    def _to_anthropic_tools(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """OpenAI {type:function, function:{name, description, parameters}}
        → Anthropic {name, description, input_schema}."""
        out: list[dict[str, Any]] = []
        for t in tools or []:
            fn = t.get("function") or t
            out.append({
                "name": fn.get("name", ""),
                "description": fn.get("description", ""),
                "input_schema": fn.get("parameters", {"type": "object"}),
            })
        return out

    async def stream(
        self,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.2,
        max_tokens: int | None = None,
        fallback_models: list[str] | None = None,  # ignored — Claude doesn't fallback-chain
        reasoning_effort: str | None = None,
    ) -> AsyncIterator[StreamEvent]:
        """Stream a chat completion. Yields StreamEvent in the same
        shape as OpenRouterClient.stream so loop.py is provider-agnostic.
        """
        system_str, msgs = self._to_anthropic_messages(messages)
        kwargs: dict[str, Any] = {
            "model": model,
            "messages": msgs,
            "max_tokens": max_tokens or 8192,
            "temperature": temperature,
        }
        # Prompt caching (round-13 credit conservation): tools array
        # and system prompt are stable across most of a session, so
        # we mark them as cacheable. Cache reads are 0.10× the base
        # input rate — turning a $10 budget into the equivalent of
        # roughly $25-35 of un-cached spend on hot agentic loops.
        # Off-by-default opt-out via PROMETHEUS_PROMPT_CACHE=0 so
        # users with non-cache-enabled providers (or behavioral debug
        # work) can disable.
        cache_enabled = os.getenv("PROMETHEUS_PROMPT_CACHE", "1") != "0"
        # Round-30 P0: 1-hour TTL default-on for the paid path.
        # Round 28 made it opt-in; the cost-stretching research shows
        # 1h TTL is unambiguously the right default for any developer
        # session > 5 min — the 2.0x write multiplier amortizes after
        # ~3 hits whereas 5m TTL re-writes every time the user pauses
        # to think. To opt OUT, set PROMETHEUS_PROMPT_CACHE_LONG=0.
        cache_ttl_long = os.getenv("PROMETHEUS_PROMPT_CACHE_LONG", "1") != "0"
        cache_block = (
            {"type": "ephemeral", "ttl": "1h"} if cache_ttl_long
            else {"type": "ephemeral"}
        )
        if cache_ttl_long:
            extra_headers = kwargs.get("extra_headers") or {}
            extra_headers["anthropic-beta"] = "extended-cache-ttl-2025-04-11"
            kwargs["extra_headers"] = extra_headers
        if system_str:
            if cache_enabled:
                # Structured-block form is required to attach cache_control.
                kwargs["system"] = [{
                    "type": "text",
                    "text": system_str,
                    "cache_control": cache_block,
                }]
            else:
                kwargs["system"] = system_str
        if tools:
            anth_tools = self._to_anthropic_tools(tools)
            if cache_enabled and anth_tools:
                # Mark the LAST tool entry — Anthropic caches everything
                # up to and including that breakpoint.
                anth_tools[-1] = {**anth_tools[-1], "cache_control": cache_block}
            kwargs["tools"] = anth_tools
        if reasoning_effort in ("low", "medium", "high"):
            # Map to Anthropic extended-thinking budgets. Numbers chosen
            # to roughly match OpenRouter's effort tiers.
            budget = {"low": 1024, "medium": 4096, "high": 16384}[reasoning_effort]
            kwargs["thinking"] = {"type": "enabled", "budget_tokens": budget}

        # State for assembling tool-use deltas.
        partial_tool_calls: dict[int, ToolCall] = {}
        partial_args: dict[int, str] = {}

        try:
            async with self._client.messages.stream(**kwargs) as stream:
                async for event in stream:
                    et = getattr(event, "type", "")
                    if et == "content_block_start":
                        block = getattr(event, "content_block", None)
                        if block is None:
                            continue
                        if getattr(block, "type", "") == "tool_use":
                            idx = getattr(event, "index", 0)
                            tc = ToolCall(
                                id=getattr(block, "id", ""),
                                name=getattr(block, "name", ""),
                                arguments="",
                            )
                            partial_tool_calls[idx] = tc
                            partial_args[idx] = ""
                    elif et == "content_block_delta":
                        delta = getattr(event, "delta", None)
                        if delta is None:
                            continue
                        dt = getattr(delta, "type", "")
                        if dt == "text_delta":
                            text = getattr(delta, "text", "")
                            if text:
                                yield StreamEvent(kind="text", text=text)
                        elif dt == "input_json_delta":
                            idx = getattr(event, "index", 0)
                            chunk = getattr(delta, "partial_json", "")
                            partial_args[idx] = partial_args.get(idx, "") + chunk
                            tc = partial_tool_calls.get(idx)
                            if tc is not None:
                                tc.arguments = partial_args[idx]
                                yield StreamEvent(kind="tool_call_delta", tool_call=tc)
                    elif et == "content_block_stop":
                        idx = getattr(event, "index", 0)
                        tc = partial_tool_calls.get(idx)
                        if tc is not None:
                            tc.arguments = partial_args.get(idx, "") or "{}"
                            yield StreamEvent(kind="tool_call_complete", tool_call=tc)
                    elif et == "message_delta":
                        usage = getattr(event, "usage", None)
                        if usage is not None:
                            in_t = getattr(usage, "input_tokens", 0) or 0
                            out_t = getattr(usage, "output_tokens", 0) or 0
                            cache_create = getattr(
                                usage, "cache_creation_input_tokens", 0,
                            ) or 0
                            cache_read = getattr(
                                usage, "cache_read_input_tokens", 0,
                            ) or 0
                            cost = estimate_cost(
                                model, in_t, out_t,
                                cache_creation_tokens=cache_create,
                                cache_read_tokens=cache_read,
                            )
                            yield StreamEvent(kind="usage", usage={
                                "prompt_tokens": in_t,
                                "completion_tokens": out_t,
                                "cache_creation_tokens": cache_create,
                                "cache_read_tokens": cache_read,
                                "cost": cost,
                            })
                    elif et == "message_stop":
                        # Anthropic doesn't send an explicit finish_reason
                        # the same way; we mark done here.
                        pass
                # Final usage once stream is fully consumed.
                final = await stream.get_final_message()
                fr = getattr(final, "stop_reason", None)
                yield StreamEvent(kind="done", finish_reason=fr)
        except Exception as e:
            logger.exception("Claude stream error")
            # Round-25 Track 2: parse Retry-After / rate-limit context
            # from the exception so the upstream loop can back off
            # intelligently. Anthropic ships RateLimitError with the
            # response object attached. We surface the suggested wait
            # so the user sees "rate-limited; retry in 30s" instead of
            # an opaque 429.
            err_str = str(e)
            try:
                resp = getattr(e, "response", None)
                if resp is not None:
                    headers = getattr(resp, "headers", {}) or {}
                    ra = headers.get("retry-after") or headers.get("Retry-After")
                    if ra:
                        # Per Anthropic's own postmortem (April 23):
                        # exponential backoff applies as a minimum even
                        # when Retry-After is small. We surface BOTH so
                        # the loop can pick the larger.
                        err_str = f"{err_str} (retry_after={ra}s)"
            except Exception:
                pass
            yield StreamEvent(kind="error", error=sanitize_error(err_str))
            return

    async def collect(
        self,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.2,
        max_tokens: int | None = None,
        fallback_models: list[str] | None = None,
    ):
        """Non-streaming convenience — used by /compact, planners, etc."""
        from prometheus.provider.openrouter import StreamResult
        out = StreamResult()
        async for ev in self.stream(
            model, messages, tools, temperature, max_tokens, fallback_models
        ):
            if ev.kind == "text" and ev.text:
                out.text += ev.text
            elif ev.kind == "tool_call_complete" and ev.tool_call:
                out.tool_calls.append(ev.tool_call)
            elif ev.kind == "usage" and ev.usage:
                out.usage = ev.usage
            elif ev.kind == "done":
                out.finish_reason = ev.finish_reason
            elif ev.kind == "error":
                raise RuntimeError(f"escalation error: {ev.error}")
        return out
