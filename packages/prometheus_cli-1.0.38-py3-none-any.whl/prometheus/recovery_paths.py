"""Round 150: catalogue of the 7 recovery paths Prometheus
ships. Used by `/recovery-paths` and `/doctor`.

Each path describes a category of failure the runtime
recovers from, the trigger condition, and where the recovery
logic lives.
"""
from __future__ import annotations

import importlib
from dataclasses import dataclass


@dataclass
class RecoveryPath:
    name: str
    trigger: str
    description: str
    module: str
    public_symbol: str = ""

    def importable(self) -> bool:
        try:
            mod = importlib.import_module(self.module)
            if self.public_symbol:
                return hasattr(mod, self.public_symbol)
            return True
        except ImportError:
            return False


RECOVERY_PATHS: tuple[RecoveryPath, ...] = (
    RecoveryPath(
        name="tool-call markup leak",
        trigger="model emits <function calls=...> as text",
        description=(
            "Detects markup in streamed text and re-parses it as "
            "real tool calls (round 97.1/97.2)."
        ),
        module="prometheus.agent.leak_sanitizer",
        public_symbol="recover_tool_calls",
    ),
    RecoveryPath(
        name="rate-limit retry",
        trigger="provider returns 429 / 529 overloaded",
        description=(
            "Auto-retries with backoff or falls back to "
            "PROMETHEUS_FALLBACK_MODEL (round 130 / 137)."
        ),
        module="prometheus.rate_limit",
        public_symbol="strategies",
    ),
    RecoveryPath(
        name="cache-break recovery",
        trigger="cache_read_input_tokens drops to 0",
        description=(
            "Logs the break event and signals the agent loop to "
            "retry with adjusted parameters (round 145)."
        ),
        module="prometheus.agent.cache_detection",
        public_symbol="should_retry",
    ),
    RecoveryPath(
        name="circuit breaker reset",
        trigger=(
            "3 consecutive denies / 20 cumulative denies in a "
            "session"
        ),
        description=(
            "Trips the round-104 circuit breaker; user resets "
            "with /permissions reset-breaker."
        ),
        module="prometheus.safety.overseer",
        public_symbol="Overseer",
    ),
    RecoveryPath(
        name="discovery-failure fallback",
        trigger="discover_test_command parallel crash",
        description=(
            "Round-95.8 fallback: synthesize a sensible default "
            "test command instead of bubbling the crash."
        ),
        module="prometheus.tools.test_discovery",
    ),
    RecoveryPath(
        name="structured-output retry",
        trigger="model emits malformed JSON for /json-schema",
        description=(
            "Retries up to PROMETHEUS_MAX_STRUCTURED_OUTPUT_RETRIES "
            "times before failing (round 145)."
        ),
        module="prometheus.env_flags_v146",
        public_symbol="max_structured_output_retries",
    ),
    RecoveryPath(
        name="provider-pool failover",
        trigger="provider returns 5xx / 401 / empty 200",
        description=(
            "Health-aware cooldown rotation across the 13-provider "
            "pool (rounds 18-20)."
        ),
        module="prometheus.provider.pool",
        public_symbol="ProviderPool",
    ),
)


def render_recovery_paths(
    *, include_health: bool = True,
) -> str:
    lines = ["recovery paths (7):"]
    for p in RECOVERY_PATHS:
        glyph = "·"
        if include_health:
            glyph = "✓" if p.importable() else "✗"
        lines.append(f"  {glyph} {p.name}")
        lines.append(f"      trigger:     {p.trigger}")
        lines.append(f"      description: {p.description}")
        lines.append(f"      module:      {p.module}")
    return "\n".join(lines)


def health_summary() -> dict[str, bool]:
    """Round 150: used by /doctor to verify every recovery
    path's module loads."""
    return {p.name: p.importable() for p in RECOVERY_PATHS}
