"""Round 116: image-paste support.

Ctrl+V from clipboard pastes an image into the conversation. The
image is saved to `<workdir>/.prometheus/media/<safe-name>.<ext>`
and a Markdown reference is inserted into the input buffer.

Images get content-hash filenames so duplicates dedupe naturally.
This module is the data layer; the Textual binding lives in app.py
(if/when we wire Ctrl+V).
"""
from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


# Recognized image signatures → file extension.
_IMAGE_MAGIC = (
    (b"\x89PNG\r\n\x1a\n", "png"),
    (b"\xff\xd8\xff", "jpg"),
    (b"GIF87a", "gif"),
    (b"GIF89a", "gif"),
    (b"BM", "bmp"),
    (b"RIFF", "webp"),  # WebP starts with RIFF; ext probe is loose.
)


def detect_image_extension(data: bytes) -> Optional[str]:
    """Return one of {png, jpg, gif, bmp, webp} when the byte
    string starts with a recognized image magic. None otherwise."""
    if not data or len(data) < 4:
        return None
    for magic, ext in _IMAGE_MAGIC:
        if data.startswith(magic):
            # WebP needs an extra check: bytes 8-12 should be `WEBP`.
            if ext == "webp" and len(data) >= 12 and data[8:12] != b"WEBP":
                continue
            return ext
    return None


@dataclass
class SavedImage:
    path: Path
    ext: str
    sha1: str
    size: int


def save_image(
    data: bytes, *, workdir: Path,
) -> tuple[Optional[SavedImage], str]:
    """Round 116: persist a clipboard image into
    `<workdir>/.prometheus/media/<sha1>.<ext>`. Returns the
    SavedImage record and a status message."""
    if not data:
        return None, "empty image data"
    ext = detect_image_extension(data)
    if ext is None:
        return None, "clipboard contents don't look like a known image format"
    sha1 = hashlib.sha1(data).hexdigest()[:12]
    media_dir = workdir / ".prometheus" / "media"
    media_dir.mkdir(parents=True, exist_ok=True)
    target = media_dir / f"{sha1}.{ext}"
    if not target.exists():
        try:
            target.write_bytes(data)
        except OSError as e:
            return None, f"could not write {target}: {e}"
    return SavedImage(
        path=target, ext=ext, sha1=sha1, size=len(data),
    ), f"saved → {target}"


def markdown_reference(image: SavedImage, *, workdir: Path) -> str:
    """Build a Markdown reference suitable for insertion into
    the input buffer. Uses a relative path so the conversation
    transcript is portable."""
    try:
        rel = image.path.relative_to(workdir)
    except ValueError:
        rel = image.path
    return f"![pasted image]({rel.as_posix()})"
