"""Round 144-v2: TUI Pilot test harness.

A minimal Textual `App` that mounts the widgets the round-141
TUI alignment work depends on, wired to the real state
machines (vim mode, ghost mode, inline approval, transcript
viewer). Headless `app.run_test()` drives `Pilot.press()`
through real keystrokes and lets tests assert on widget
state — the same pattern Claude Code uses internally.

This is intentionally separate from `prometheus/ui/app.py`
(the production app) — that one needs a real Settings,
SessionStore, AgentLoop, and provider connections, which
we don't want to spin up in CI. The harness gives us a
deterministic, dep-free surface that exercises the same
state-machine contracts.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

try:
    from textual.app import App, ComposeResult
    from textual.containers import Vertical
    from textual.widgets import Input, Static
    from textual.binding import Binding
    _TEXTUAL_AVAILABLE = True
except ImportError:                          # pragma: no cover
    _TEXTUAL_AVAILABLE = False
    App = object                             # type: ignore[assignment]
    ComposeResult = None                     # type: ignore[assignment]


def textual_available() -> bool:
    return _TEXTUAL_AVAILABLE


# ---------- harness app ----------


if _TEXTUAL_AVAILABLE:
    class HarnessApp(App):
        """Round 144-v2: minimal harness for TUI pilot tests.

        Mounts:
          * `#prompt` Input — the input bar
          * `#status` Static — status-bar chip readout
          * `#transcript` Static — transcript-viewer modal body

        Bindings:
          * `ctrl+o` — toggle the transcript viewer modal
          * `escape` — cancel / close modal / clear approval

        State the test pokes:
          * `app.model_alias` — set via `/model <alias>`
          * `app.ghost_on` — set via `/ghost`
          * `app.vim_on` — set via `/vim`
          * `app.bash_output` — populated from `! cmd` input
          * `app.file_mention_body` — populated from `@path`
          * `app.approval` — InlineApproval state
          * `app.transcript_open` — transcript viewer flag
        """

        BINDINGS = [
            Binding("ctrl+o", "toggle_transcript", "transcript"),
            Binding("escape", "cancel", "cancel"),
        ]

        def __init__(self) -> None:
            super().__init__()
            from prometheus.ghost_mode import GhostMode
            from prometheus.tui_inline_approval import (
                InlineApproval, SessionAllowlist,
            )
            from prometheus.tui_transcript import TranscriptViewer
            from prometheus.ui.vim_mode import VimState
            self.model_alias: str = ""
            self.ghost_state: GhostMode = GhostMode()
            self.vim_state: VimState = VimState()
            self.vim_on: bool = False
            self.ghost_on: bool = False
            self.bash_output: str = ""
            self.file_mention_body: str = ""
            self.approval: InlineApproval = InlineApproval()
            self.allowlist: SessionAllowlist = SessionAllowlist()
            self.transcript_viewer: TranscriptViewer = TranscriptViewer()
            self.transcript_open: bool = False
            self.last_status: str = ""

        def compose(self) -> "ComposeResult":
            yield Static("", id="status")
            yield Input(placeholder="type / for commands", id="prompt")
            yield Static("", id="transcript")

        def update_status(self) -> None:
            chips: list[str] = []
            if self.model_alias:
                chips.append(self.model_alias)
            if self.ghost_on:
                chips.append("GHOST")
            if self.vim_on:
                chips.append("VIM")
            if self.approval.active:
                chips.append("APPROVE")
            self.last_status = " ".join(chips)
            try:
                self.query_one("#status", Static).update(
                    self.last_status,
                )
            except Exception:
                pass

        def on_input_submitted(
            self, event: "Input.Submitted",
        ) -> None:
            text = event.value
            self._dispatch(text)
            event.input.value = ""

        def _dispatch(self, text: str) -> None:
            from prometheus.agent.input_prefix import (
                is_bash_prefix, strip_bash_prefix,
                has_file_mention, extract_file_mentions,
            )
            from prometheus.tui_inline_approval import (
                handle_keypress as approval_keypress,
            )
            t = (text or "").strip()
            if not t:
                return
            # Approval keystrokes win when armed.
            if self.approval.active:
                decision = approval_keypress(self.approval, t.lower())
                if decision in ("yes", "no", "always"):
                    if decision == "always":
                        self.allowlist.allow(
                            self.approval.tool_name,
                            self.approval.arg_signature,
                        )
                    self.approval.decision = decision
                    self.approval.active = False
                    self.update_status()
                return
            # Slash dispatch.
            if t.startswith("/"):
                self._dispatch_slash(t[1:])
                return
            if is_bash_prefix(t):
                self.bash_output = strip_bash_prefix(t)
                return
            if has_file_mention(t):
                from pathlib import Path as _P
                mentions = extract_file_mentions(
                    t, workdir=_P("."),
                )
                if mentions:
                    m = mentions[0]
                    if m.matches:
                        self.file_mention_body = str(m.matches[0])
                    else:
                        self.file_mention_body = m.token

        def _dispatch_slash(self, body: str) -> None:
            parts = body.strip().split(maxsplit=1)
            cmd = parts[0].lower() if parts else ""
            arg = parts[1] if len(parts) > 1 else ""
            if cmd == "model":
                from prometheus.model_tiers import resolve_alias
                self.model_alias = (arg or "").strip().lower() or "auto"
                _ = resolve_alias(self.model_alias)
                self.update_status()
            elif cmd == "ghost":
                from prometheus.ghost_mode import (
                    enable_ghost, disable_ghost,
                )
                if self.ghost_on:
                    disable_ghost(self.ghost_state)
                    self.ghost_on = False
                else:
                    enable_ghost(self.ghost_state)
                    self.ghost_on = True
                self.update_status()
            elif cmd == "vim":
                self.vim_on = not self.vim_on
                if self.vim_on:
                    self.vim_state.mode = "normal"
                else:
                    self.vim_state.mode = "insert"
                self.update_status()
            elif cmd == "approve":
                from prometheus.tui_inline_approval import begin
                begin(
                    self.approval,
                    tool_name="Bash",
                    detail=arg or "pwd",
                    arg_signature=f"Bash:{arg or 'pwd'}",
                )
                self.update_status()

        def action_toggle_transcript(self) -> None:
            from prometheus.tui_transcript import (
                open_viewer, close_viewer,
            )
            if self.transcript_open:
                close_viewer(self.transcript_viewer)
                self.transcript_open = False
                try:
                    self.query_one("#transcript", Static).update("")
                except Exception:
                    pass
            else:
                # Synthetic transcript so the viewer has lines.
                msgs = [
                    {"role": "user", "content": "alpha"},
                    {"role": "assistant", "content": "beta"},
                ]
                open_viewer(self.transcript_viewer, messages=msgs)
                self.transcript_open = True
                try:
                    body = "\n".join(
                        line.text for line in
                        self.transcript_viewer.lines
                    )
                    self.query_one("#transcript", Static).update(body)
                except Exception:
                    pass

        def action_cancel(self) -> None:
            if self.transcript_open:
                self.action_toggle_transcript()
                return
            if self.approval.active:
                self.approval.active = False
                self.approval.decision = "cancelled"
                self.update_status()
                return


# ---------- pilot helpers ----------


async def type_text(pilot, text: str) -> None:
    """Round 144-v2: feed a string keystroke-by-keystroke
    through the pilot, then press Enter."""
    if not text:
        return
    keys: list[str] = []
    for ch in text:
        if ch == " ":
            keys.append("space")
        elif ch == "/":
            keys.append("slash")
        elif ch == "!":
            keys.append("exclamation_mark")
        elif ch == "@":
            keys.append("at")
        elif ch == ".":
            keys.append("full_stop")
        else:
            keys.append(ch)
    keys.append("enter")
    await pilot.press(*keys)
