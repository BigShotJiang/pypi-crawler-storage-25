"""Round 106: Vim mode for the input buffer.

A minimal modal editor state machine on top of Textual's Input.
Real vim has hundreds of motions; this implementation covers the
ones a CLI agent's input box actually benefits from:

  * Normal / Insert mode toggle (Esc → Normal, i → Insert)
  * h/j/k/l navigation (j/k act as no-op on a single line)
  * w / b / e word movement
  * 0 / $ line boundaries
  * x delete char under cursor
  * d / c / y operators with text objects (dw, cw, yw, dd, etc.)
  * . repeat last edit
  * / search forward, n / N navigate matches

The state lives in `VimState`; key dispatch lives in
`apply_keystroke`. The Textual app wires `apply_keystroke` from a
key handler when `vim_enabled` is true. This module is also
self-contained enough for unit tests to drive it without a TTY.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


# ---------- mode enum ----------


NORMAL = "normal"
INSERT = "insert"
VISUAL = "visual"


# ---------- state ----------


@dataclass
class VimState:
    """The editor state for one input buffer.

    `text` is the buffer; `cursor` is the column position
    (0-indexed). `mode` is one of NORMAL/INSERT/VISUAL.
    `last_edit` records the last destructive keystroke sequence
    so `.` can repeat it. `search_pat` and `search_dir` track the
    most recent `/` query for n/N."""
    text: str = ""
    cursor: int = 0
    mode: str = INSERT             # input boxes start in INSERT
    last_edit: list[str] = field(default_factory=list)
    search_pat: str = ""
    search_dir: int = 1            # +1 forward, -1 backward
    pending_op: str = ""           # for d/c/y operators waiting on text-object
    # Round 169 / A22: visual-mode selection anchor + kind.
    # `visual_anchor` is the cursor position where v / V was pressed;
    # the active selection is min(anchor, cursor) .. max(anchor, cursor).
    # `visual_kind` is "v" (character) or "V" (line). Both are -1 / "".
    # when not in VISUAL mode.
    visual_anchor: int = -1
    visual_kind: str = ""


# ---------- helpers ----------


def _word_boundary_after(text: str, idx: int) -> int:
    """w motion — start of next word."""
    n = len(text)
    if idx >= n:
        return n
    # Skip current word.
    while idx < n and not text[idx].isspace():
        idx += 1
    # Skip whitespace.
    while idx < n and text[idx].isspace():
        idx += 1
    return idx


def _word_boundary_before(text: str, idx: int) -> int:
    """b motion — start of previous word."""
    if idx <= 0:
        return 0
    idx -= 1
    # Skip whitespace going back.
    while idx > 0 and text[idx].isspace():
        idx -= 1
    # Find start of word.
    while idx > 0 and not text[idx - 1].isspace():
        idx -= 1
    return idx


def _word_end(text: str, idx: int) -> int:
    """e motion — end of current/next word."""
    n = len(text)
    if idx >= n:
        return n
    if not text[idx].isspace():
        idx += 1
    while idx < n and text[idx].isspace():
        idx += 1
    while idx < n and not text[idx].isspace():
        idx += 1
    return max(0, idx - 1)


# ---------- the dispatcher ----------


def apply_keystroke(state: VimState, key: str) -> VimState:
    """Round 106: apply a single key to a VimState. Returns the
    new state. Mutates in place AND returns for convenience.

    Keys are passed as user-friendly strings: `i`, `Esc`, `j`,
    `dw`, etc. Multi-char operators arrive as single characters
    in sequence — the state's `pending_op` field tracks the
    operator wait."""
    if key == "":
        return state
    if state.mode == INSERT:
        if key == "Esc":
            state.mode = NORMAL
            # Vim moves cursor back one when leaving insert if
            # not at line start.
            if state.cursor > 0:
                state.cursor -= 1
            state.pending_op = ""
            return state
        # All other keys in INSERT are letters typed at the cursor.
        # The Textual Input handles this natively; we let the key
        # pass through. State updates only happen on mode flip.
        return state

    # Normal mode dispatch.
    if state.pending_op:
        # We're waiting for a text-object after d/c/y.
        op = state.pending_op
        state.pending_op = ""
        if key == "w":
            end = _word_boundary_after(state.text, state.cursor)
            chunk = state.text[state.cursor:end]
            state.last_edit = [op, "w"]
            if op == "d":
                state.text = (
                    state.text[:state.cursor] + state.text[end:]
                )
            elif op == "c":
                state.text = (
                    state.text[:state.cursor] + state.text[end:]
                )
                state.mode = INSERT
            elif op == "y":
                # yank — we don't track the register here; ack only.
                _ = chunk
            return state
        if key == op:
            # `dd`, `cc`, `yy` — operate on the whole line.
            line_start = state.text.rfind("\n", 0, state.cursor) + 1
            line_end = state.text.find("\n", state.cursor)
            if line_end == -1:
                line_end = len(state.text)
            state.last_edit = [op, op]
            if op == "d":
                state.text = (
                    state.text[:line_start]
                    + state.text[line_end + 1:]
                )
                state.cursor = min(line_start, len(state.text))
            elif op == "c":
                state.text = (
                    state.text[:line_start] + state.text[line_end:]
                )
                state.cursor = line_start
                state.mode = INSERT
            elif op == "y":
                pass
            return state
        # Unknown text-object — drop the operator.
        return state

    # Round 169 / A22: visual-mode entry from NORMAL.
    if state.mode == NORMAL and key in ("v", "V"):
        state.mode = VISUAL
        state.visual_kind = key
        if key == "V":
            # Line-visual anchors at the start of the current line.
            state.visual_anchor = state.text.rfind("\n", 0, state.cursor) + 1
        else:
            state.visual_anchor = state.cursor
        return state

    # Round 169 / A22: visual-mode key handling. We use dedicated
    # `visual_anchor` / `visual_kind` fields so the d/c/y operator
    # state (which lives on `pending_op`) doesn't collide.
    if state.mode == VISUAL:
        if key == "Esc":
            state.mode = NORMAL
            state.visual_anchor = -1
            state.visual_kind = ""
            return state
        if key in ("h", "l", "w", "b", "0", "$", "j", "k", "e"):
            # Movement extends the selection — flip to NORMAL just
            # for the motion, then back. Since the motion handlers
            # below don't touch visual_anchor / visual_kind, the
            # selection survives the recursion.
            state.mode = NORMAL
            try:
                apply_keystroke(state, key)
            finally:
                state.mode = VISUAL
            return state
        if key in ("d", "y", "c"):
            anchor = state.visual_anchor if state.visual_anchor >= 0 else state.cursor
            kind = state.visual_kind or "v"
            lo, hi = sorted((anchor, state.cursor))
            if kind == "V":
                # Line-visual: extend hi to end-of-line.
                line_end = state.text.find("\n", hi)
                if line_end == -1:
                    line_end = len(state.text)
                hi = line_end
            chunk = state.text[lo:hi]
            state.last_edit = ["visual", key, chunk]
            if key == "d":
                state.text = state.text[:lo] + state.text[hi:]
                state.cursor = lo
                state.mode = NORMAL
            elif key == "y":
                state.cursor = lo
                state.mode = NORMAL
            elif key == "c":
                state.text = state.text[:lo] + state.text[hi:]
                state.cursor = lo
                state.mode = INSERT
            state.visual_anchor = -1
            state.visual_kind = ""
            return state
        # Unknown key in VISUAL — stay in mode, do nothing.
        return state

    # Plain Normal-mode key.
    if key == "i":
        state.mode = INSERT
        return state
    if key == "a":
        # Append after cursor.
        state.cursor = min(state.cursor + 1, len(state.text))
        state.mode = INSERT
        return state
    if key == "I":
        # Insert at line start.
        line_start = state.text.rfind("\n", 0, state.cursor) + 1
        state.cursor = line_start
        state.mode = INSERT
        return state
    if key == "A":
        # Append at line end.
        line_end = state.text.find("\n", state.cursor)
        state.cursor = len(state.text) if line_end == -1 else line_end
        state.mode = INSERT
        return state
    if key == "h":
        if state.cursor > 0:
            state.cursor -= 1
        return state
    if key == "l":
        if state.cursor < len(state.text):
            state.cursor += 1
        return state
    if key == "0":
        state.cursor = state.text.rfind("\n", 0, state.cursor) + 1
        return state
    if key == "$":
        end = state.text.find("\n", state.cursor)
        state.cursor = len(state.text) if end == -1 else end
        return state
    if key == "w":
        state.cursor = _word_boundary_after(state.text, state.cursor)
        return state
    if key == "b":
        state.cursor = _word_boundary_before(state.text, state.cursor)
        return state
    if key == "e":
        state.cursor = _word_end(state.text, state.cursor)
        return state
    if key == "x":
        if state.cursor < len(state.text):
            state.text = (
                state.text[:state.cursor]
                + state.text[state.cursor + 1:]
            )
            state.last_edit = ["x"]
        return state
    if key in ("d", "c", "y"):
        state.pending_op = key
        return state
    if key == ".":
        # Replay last_edit.
        for k in list(state.last_edit):
            apply_keystroke(state, k)
        return state
    # Unknown key in normal mode → no-op.
    return state


def search(state: VimState, pattern: str, *, forward: bool = True) -> bool:
    """Run / or ? search. Returns True if a match was found and
    `cursor` was moved; False otherwise."""
    state.search_pat = pattern
    state.search_dir = 1 if forward else -1
    if not pattern:
        return False
    if forward:
        idx = state.text.find(pattern, state.cursor + 1)
    else:
        idx = state.text.rfind(pattern, 0, state.cursor)
    if idx == -1:
        return False
    state.cursor = idx
    return True


def search_next(state: VimState) -> bool:
    return search(
        state, state.search_pat,
        forward=state.search_dir == 1,
    )


def search_prev(state: VimState) -> bool:
    return search(
        state, state.search_pat,
        forward=state.search_dir != 1,
    )


# ---------- Textual Input subclass ----------


# These imports go at function call time so the test suite can
# import this module without Textual mounted.
def _get_input_class():
    from textual.widgets import Input
    return Input


class _VimInputMixin:
    """Mixin that adds vim-mode keystroke interception to a
    Textual Input. We mix into Input lazily because Textual is a
    runtime dep and we want this module unit-testable without it."""

    # Reactive flag the host app flips via /vim toggle.
    vim_enabled: bool = False

    def _vim_state_get(self) -> VimState:
        if not hasattr(self, "_vim_state"):
            self._vim_state = VimState(
                text=getattr(self, "value", "") or "",
                cursor=getattr(self, "cursor_position", 0) or 0,
                mode=INSERT,
            )
        return self._vim_state

    def _vim_sync_to_widget(self) -> None:
        """Push state.text + state.cursor back into the Textual
        Input. Done after every accepted Normal-mode keystroke."""
        s = self._vim_state_get()
        try:
            self.value = s.text
            self.cursor_position = max(
                0, min(s.cursor, len(s.text))
            )
        except Exception:
            pass

    def _vim_sync_from_widget(self) -> None:
        """Pull current Input value/cursor INTO the state — done
        before each keystroke so the user's typed-since-last-key
        text is captured."""
        s = self._vim_state_get()
        s.text = getattr(self, "value", "") or ""
        s.cursor = getattr(self, "cursor_position", 0) or 0

    def vim_handle_key(self, key: str) -> bool:
        """Round 106-final: intercept a single Textual key event.
        Returns True iff the key was consumed by the vim
        handler. Returning False lets Textual handle it normally
        (the INSERT-mode path)."""
        if not self.vim_enabled:
            return False
        s = self._vim_state_get()
        # Always pull current widget state in so external typing
        # is visible to the vim engine.
        self._vim_sync_from_widget()
        # In INSERT, only `Esc` is consumed — everything else
        # passes through to Textual's default editing.
        if s.mode == INSERT:
            if key == "escape":
                apply_keystroke(s, "Esc")
                self._vim_sync_to_widget()
                return True
            return False
        # Normal / Visual modes: intercept printable letters +
        # `escape`. Map Textual key names to the single-char form
        # that `apply_keystroke` expects.
        mapped = _normalize_textual_key(key)
        if mapped is None:
            return False
        apply_keystroke(s, mapped)
        self._vim_sync_to_widget()
        return True


def _normalize_textual_key(key: str) -> Optional[str]:
    """Round 106-final: translate a Textual key string into the
    single-character vim key the engine consumes.

    Textual surfaces alphanumerics as `'a'`, `'b'`, etc., but
    arrow keys / control chars come as `'left'`, `'ctrl+r'`. We
    only intercept the printable letters relevant to Normal-mode
    motions / operators."""
    if not key:
        return None
    # Direct single-char letter / digit / punctuation.
    if len(key) == 1:
        return key
    # Word-key aliases.
    if key == "escape":
        return "Esc"
    if key == "dollar_sign":
        return "$"
    return None


def make_vim_input_class():
    """Round 106-final: build `VimInput` as a subclass of
    Textual's `Input` that consumes Normal-mode keystrokes via
    `VimState`. Built lazily so tests don't import Textual when
    they only exercise the engine."""
    Input = _get_input_class()

    class VimInput(_VimInputMixin, Input):
        """Round 106-final: Textual Input subclass with vim-mode
        keystroke interception.

        When `self.vim_enabled` is True and the user is in
        Normal mode, motions (h/j/k/l, w/b/e, 0/$, x, dw/cw/yw,
        .) edit the buffer. When `vim_enabled` is False or the
        user is in Insert mode, the widget behaves exactly like
        a stock `Input`."""

        async def _on_key(self, event):
            # Textual fires `_on_key` for every key. We try the
            # vim handler first; if it returns False, the parent
            # Input handles the key normally.
            try:
                consumed = self.vim_handle_key(event.key)
            except Exception:
                consumed = False
            if consumed:
                event.stop()
                event.prevent_default()
                # Manually refresh so the cursor visibly jumps.
                self.refresh()
                return
            # Fall through to default Input behavior.
            return await super()._on_key(event)

    return VimInput
