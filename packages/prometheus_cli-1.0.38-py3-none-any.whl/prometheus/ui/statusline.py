r"""Shell-driven custom statusline.

If the user has `~/.prometheus/statusline.sh` (Linux/macOS) or
`~/.prometheus/statusline.ps1` (Windows), we run it every
STATUSLINE_INTERVAL_S seconds and surface the first line of stdout
in the StatusBar. The script gets PROMETHEUS_* env vars filled in
with current state (model, tokens, cost, mode, branch, workdir).

Example user `statusline.sh`:

    #!/usr/bin/env bash
    branch=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo -)
    echo "$PROMETHEUS_FOLDER · $branch · ⤢$PROMETHEUS_TOKENS_OUT · \$$PROMETHEUS_COST"

Hard caps:
- 1 second timeout per invocation (kill if it hangs)
- 200-char output cap (longer = truncated)
- Disabled if any 2 consecutive invocations error → user has to delete
  + re-add the script to reactivate
"""
from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path
from typing import Any


STATUSLINE_INTERVAL_S = 5.0
STATUSLINE_TIMEOUT_S = 1.0
MAX_OUTPUT_CHARS = 200
MAX_CONSECUTIVE_FAILURES = 2


def _resolve_public_name(app: "Any") -> str:
    """Resolve the active engine's PUBLIC brand name for the statusline
    env. Never leaks the upstream id (audit pass-2 finding #3)."""
    try:
        from prometheus.config import public_name
        return public_name(getattr(app.settings, "model", ""))
    except Exception:
        return "PrometheUS Engine"


def _script_path() -> Path | None:
    """Locate the user's statusline script, if any."""
    home = Path.home() / ".prometheus"
    if sys.platform == "win32":
        ps = home / "statusline.ps1"
        if ps.exists():
            return ps
        bat = home / "statusline.bat"
        if bat.exists():
            return bat
    sh = home / "statusline.sh"
    if sh.exists():
        return sh
    return None


async def _run_once(script: Path, env: dict[str, str]) -> str:
    """Invoke the script once with timeout. Returns the trimmed first
    line of stdout, or '' on any failure (timeout, non-zero exit, etc.).
    """
    cmd: list[str]
    if script.suffix == ".ps1":
        cmd = ["powershell", "-NoProfile", "-NonInteractive",
               "-ExecutionPolicy", "Bypass", "-File", str(script)]
    elif script.suffix == ".bat":
        cmd = [str(script)]
    else:
        # POSIX sh
        cmd = ["/bin/sh", str(script)]
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
            env={**os.environ, **env},
        )
        try:
            out_b, _ = await asyncio.wait_for(
                proc.communicate(), timeout=STATUSLINE_TIMEOUT_S,
            )
        except asyncio.TimeoutError:
            try:
                proc.kill()
            except ProcessLookupError:
                pass
            return ""
        if proc.returncode != 0:
            return ""
        out = (out_b or b"").decode("utf-8", "replace").splitlines()
        first = out[0].strip() if out else ""
        return first[:MAX_OUTPUT_CHARS]
    except Exception:
        return ""


class StatuslineRunner:
    """Background task that polls the user's statusline script.

    Mount in PrometheusApp.on_mount() with `start(app)`. Stops itself
    after MAX_CONSECUTIVE_FAILURES bad runs so a broken script doesn't
    burn cycles forever — user fixes it then runs `/statusline reload`.
    """

    def __init__(self) -> None:
        self.task: asyncio.Task | None = None
        self.failures = 0
        self.disabled = False
        self.last_output: str = ""

    async def _loop(self, app: "Any") -> None:
        script = _script_path()
        if script is None:
            return  # No script — nothing to do.
        from prometheus.safety.trust import is_trusted
        if not is_trusted(Path.cwd()):
            # User-level only when the workdir isn't trusted. The
            # script lives in ~/.prometheus/, which the user owns,
            # but a hostile cwd could ship env that affects its
            # output. We still run it; just don't expose project-
            # local env hints.
            pass
        while not self.disabled:
            env = {
                "PROMETHEUS_FOLDER": str(getattr(app.settings, "workdir", "")),
                # Pass the public brand name to user statusline scripts so
                # an accidental `echo $PROMETHEUS_MODEL` from a snippet
                # pasted into a public terminal can't leak the upstream id.
                "PROMETHEUS_MODEL": _resolve_public_name(app),
                "PROMETHEUS_MODE": str(
                    app.agent.permission_mode if app.agent else "default"
                ),
                "PROMETHEUS_TOKENS_IN": str(getattr(app, "_tokens_total_in", 0)),
                "PROMETHEUS_TOKENS_OUT": str(getattr(app, "_tokens_total_out", 0)),
                "PROMETHEUS_COST": f"{float(getattr(app, '_cost_total_usd', 0.0)):.4f}",
                "PROMETHEUS_SESSION_ID": str(getattr(app, "session_id", "")),
            }
            line = await _run_once(script, env)
            if not line:
                self.failures += 1
                if self.failures >= MAX_CONSECUTIVE_FAILURES:
                    self.disabled = True
                    return
            else:
                self.failures = 0
                self.last_output = line
                # Hand off to the StatusBar via a custom attribute.
                try:
                    sb = app.query_one("#status-bar")
                    sb.custom_line = line
                    sb.refresh()
                except Exception:
                    pass
            await asyncio.sleep(STATUSLINE_INTERVAL_S)

    def start(self, app: "Any") -> None:
        if self.task is None or self.task.done():
            self.task = asyncio.create_task(self._loop(app))

    def stop(self) -> None:
        if self.task and not self.task.done():
            self.task.cancel()
        self.task = None

    def reload(self, app: "Any") -> None:
        self.stop()
        self.failures = 0
        self.disabled = False
        self.last_output = ""
        self.start(app)
