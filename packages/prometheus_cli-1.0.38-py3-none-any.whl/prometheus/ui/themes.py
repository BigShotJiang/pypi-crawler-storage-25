"""Round 114: built-in color themes + persistence.

Themes are name → color-mapping dicts. The active theme name is
persisted to `~/.prometheus/theme.json` so it survives restarts.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional


# ---------- built-in palettes ----------


THEMES: dict[str, dict[str, str]] = {
    "dark": {
        "ink": "white",
        "dim": "grey50",
        "muted": "grey70",
        "amber": "yellow",
        "success": "green",
        "error": "red",
        "cyan": "cyan",
    },
    "light": {
        "ink": "black",
        "dim": "grey40",
        "muted": "grey30",
        "amber": "dark_orange",
        "success": "green",
        "error": "red",
        "cyan": "blue",
    },
    "monokai": {
        "ink": "#f8f8f2",
        "dim": "#75715e",
        "muted": "#a6a39c",
        "amber": "#fd971f",
        "success": "#a6e22e",
        "error": "#f92672",
        "cyan": "#66d9ef",
    },
    "solarized": {
        "ink": "#839496",
        "dim": "#586e75",
        "muted": "#93a1a1",
        "amber": "#b58900",
        "success": "#859900",
        "error": "#dc322f",
        "cyan": "#2aa198",
    },
    "nord": {
        "ink": "#d8dee9",
        "dim": "#4c566a",
        "muted": "#81a1c1",
        "amber": "#ebcb8b",
        "success": "#a3be8c",
        "error": "#bf616a",
        "cyan": "#88c0d0",
    },
}


VALID_THEMES = tuple(THEMES.keys()) + ("custom",)


# ---------- persistence ----------


def _theme_settings_path() -> Path:
    return Path.home() / ".prometheus" / "theme.json"


def load_active_theme() -> str:
    p = _theme_settings_path()
    if not p.exists() or not p.is_file():
        return "dark"
    try:
        data = json.loads(p.read_text(encoding="utf-8", errors="replace"))
        name = str(data.get("active", "dark"))
        if name in VALID_THEMES:
            return name
    except (OSError, ValueError):
        pass
    return "dark"


def save_active_theme(name: str) -> tuple[bool, str]:
    if name not in VALID_THEMES:
        return False, f"unknown theme {name!r}. Available: {', '.join(VALID_THEMES)}"
    p = _theme_settings_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    try:
        p.write_text(
            json.dumps({"active": name}, indent=2),
            encoding="utf-8",
        )
    except OSError as e:
        return False, f"could not save theme: {e}"
    return True, f"theme set to {name!r}"


def get_theme_palette(name: str) -> Optional[dict[str, str]]:
    """Return the color palette dict for a theme name, or None
    if the name isn't recognized."""
    return THEMES.get(name)


def load_custom_palette() -> Optional[dict[str, str]]:
    """Round 114: `custom` theme reads palette from
    `~/.prometheus/theme-custom.json`. Returns None when not
    configured."""
    p = Path.home() / ".prometheus" / "theme-custom.json"
    if not p.exists() or not p.is_file():
        return None
    try:
        data = json.loads(p.read_text(encoding="utf-8", errors="replace"))
        if isinstance(data, dict):
            return {str(k): str(v) for k, v in data.items()}
    except (OSError, ValueError):
        pass
    return None
