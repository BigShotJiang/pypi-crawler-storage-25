"""R226: PrometheUS-themed playful activity verbs.

User feedback after seeing CC's "Channeling…", "Crunched for 8s",
"Spelunking…", "Topsy-turvying…", "Brewed for 37s" verbs: those make
the rail feel alive instead of clinical. PrometheUS gets its own
themed pool that fits the forge / fire / fuel branding instead of
copying CC's word list verbatim.

Wiring is gated behind `PROMETHEUS_PLAYFUL_VERBS=1` so this round
ships the pool without disturbing the 9 tests that assert exact
phase-label strings (`Reviewing result…`, `Planning…`, etc.). R227
flips the default and updates those tests in one coherent change.

Public API:
    PLAYFUL_PRESENT   — gerund verbs for active phases ("Forging…")
    PLAYFUL_PAST      — past-tense verbs for completion ("Forged for Ns")
    enabled()         — True iff the env-flag is set
    pick(seed)        — deterministic-per-seed verb selection so the
                        same turn keeps the same verb across re-renders
"""
from __future__ import annotations

import os


# 10 verbs across forge / fire / craft / earth tropes — present-tense
# gerunds, used during active phases.
PLAYFUL_PRESENT: tuple[str, ...] = (
    "Forging",
    "Smelting",
    "Igniting",
    "Crafting",
    "Tempering",
    "Hammering",
    "Stoking",
    "Kindling",
    "Refining",
    "Channeling",
)


# Past-tense versions for the post-turn timing line ("Forged for 12s").
# Order matches PLAYFUL_PRESENT 1:1 so pick() can return a coherent pair.
PLAYFUL_PAST: tuple[str, ...] = (
    "Forged",
    "Smelted",
    "Ignited",
    "Crafted",
    "Tempered",
    "Hammered",
    "Stoked",
    "Kindled",
    "Refined",
    "Channeled",
)


_TRUTHY = ("1", "true", "yes", "on")


def enabled() -> bool:
    """R235: default flipped back to False (commercial CLI polish).
    Live screenshots showed branded labels like "Tempering…",
    "Smelting…", "Forging…", "Channeling…" surfacing for ordinary
    "what time is it" / "install opera" prompts and feeling
    unprofessional / random for public users. Themed verbs were
    default-on under R227 for charm; the trade-off doesn't favor a
    public-facing CLI assistant. Now opt-in only.

    Set `PROMETHEUS_PLAYFUL_VERBS=1` (or `true` / `yes` / `on`) to
    re-enable the themed pool. The legacy lifecycle labels
    ("Thinking…", "Working…", "Reviewing result…", "Finalizing…")
    are now the default for everyone."""
    raw = os.environ.get("PROMETHEUS_PLAYFUL_VERBS", "").strip().lower()
    if not raw:
        return False
    return raw in _TRUTHY


# R227: thinking-class phases that adopt playful verbs. Tool-specific
# phases ("approval", "running_tests", "searching", "editing", etc.)
# keep their concrete labels because they convey real lifecycle info
# the user would otherwise lose.
PLAYFUL_PHASES: frozenset[str] = frozenset({
    "planning",
    "thinking",
    "processing",
    "finalizing",
})


def label_for_phase(phase: str, elapsed_s: int) -> str | None:
    """R227: return the playful verb to display for a thinking-class
    phase, or None if the phase doesn't take a playful verb. Stable
    per ~minute so a single turn keeps a single verb; longer runs
    may transition once a minute, which reads as natural variety
    rather than flicker."""
    if not enabled() or phase not in PLAYFUL_PHASES:
        return None
    bucket = int(max(0, elapsed_s)) // 60
    seed = f"{phase}-{bucket}"
    present, _past = pick(seed)
    return present + "…"


def pick(seed: int | str) -> tuple[str, str]:
    """Return (present, past) verb pair for a given seed.

    Stable per seed: the same turn-id (or hash thereof) always
    yields the same pair, so a re-render mid-turn doesn't flip
    the verb on the user. Caller passes whatever stable token it
    has — turn index, session id slice, monotonic-tick bucket.
    """
    if isinstance(seed, str):
        # Cheap, deterministic, no crypto dependency.
        seed = sum(ord(c) for c in seed)
    idx = int(seed) % len(PLAYFUL_PRESENT)
    return PLAYFUL_PRESENT[idx], PLAYFUL_PAST[idx]
