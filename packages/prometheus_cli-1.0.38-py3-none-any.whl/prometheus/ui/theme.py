"""Visual theme — colors and glyphs.

The brand glyph (●) and brand accent (amber) are constant. Other tones
swap with the active theme so light-terminal users get readable text.

Switch with `/theme dark|light|night|paper`.
"""
from __future__ import annotations

import os

# Brand-fixed (never change with theme)
AMBER = "#d77757"
SUCCESS = "#7eb95e"
WARN = "#e6b86a"
ERROR = "#e06464"
CYAN = "#67c1e4"

# Theme palettes for ink/dim/muted (the text-vs-background tones).
# All four "name-brand" community palettes are mapped to our role
# slots — every modern TUI ships these and users expect them. Hex
# values match the official palettes (Tokyo Night Storm, Catppuccin
# Mocha, Gruvbox Dark Medium, Nord Polar/Snow). Brand AMBER stays
# constant across themes — these only swap the surrounding tones.
_THEMES: dict[str, dict[str, str]] = {
    "dark":  {"INK": "grey85", "DIM": "grey50", "MUTED": "grey39",
              "USER_INK": "grey62", "ASSISTANT_INK": "#e6a85c",
              "ASSISTANT_CODE": "#f0c98a"},
    "night": {"INK": "white",  "DIM": "grey58", "MUTED": "grey42",
              "USER_INK": "grey70", "ASSISTANT_INK": "#f0bd75",
              "ASSISTANT_CODE": "#fcd38e"},
    "light": {"INK": "grey15", "DIM": "grey42", "MUTED": "grey50",
              "USER_INK": "grey30", "ASSISTANT_INK": "#a05a30",
              "ASSISTANT_CODE": "#7d4520"},
    "paper": {"INK": "grey20", "DIM": "grey48", "MUTED": "grey55",
              "USER_INK": "grey35", "ASSISTANT_INK": "#8a4a25",
              "ASSISTANT_CODE": "#5d3015"},
    # Tokyo Night Storm — popular dark theme, high signal/noise.
    "tokyonight": {
        "INK": "#c0caf5", "DIM": "#7aa2f7", "MUTED": "#565f89",
        "USER_INK": "#9ece6a", "ASSISTANT_INK": "#ff9e64",
        "ASSISTANT_CODE": "#e0af68",
    },
    # Catppuccin Mocha — pastel dark; second-most-requested theme.
    "catppuccin": {
        "INK": "#cdd6f4", "DIM": "#a6adc8", "MUTED": "#6c7086",
        "USER_INK": "#a6e3a1", "ASSISTANT_INK": "#fab387",
        "ASSISTANT_CODE": "#f9e2af",
    },
    # Gruvbox Dark Medium — retro warm palette, big retro-dev fanbase.
    "gruvbox": {
        "INK": "#ebdbb2", "DIM": "#bdae93", "MUTED": "#7c6f64",
        "USER_INK": "#b8bb26", "ASSISTANT_INK": "#fe8019",
        "ASSISTANT_CODE": "#fabd2f",
    },
    # Nord — frosty cool palette.
    "nord": {
        "INK": "#eceff4", "DIM": "#d8dee9", "MUTED": "#4c566a",
        "USER_INK": "#a3be8c", "ASSISTANT_INK": "#d08770",
        "ASSISTANT_CODE": "#ebcb8b",
    },
}

THEME_NAMES = list(_THEMES.keys())
_DEFAULT = os.getenv("PROMETHEUS_THEME", "dark")
if _DEFAULT not in _THEMES:
    _DEFAULT = "dark"

_active = _DEFAULT


def set_theme(name: str) -> bool:
    global _active, INK, DIM, MUTED, USER_INK, ASSISTANT_INK, ASSISTANT_CODE
    if name not in _THEMES:
        return False
    _active = name
    pal = _THEMES[name]
    INK = pal["INK"]
    DIM = pal["DIM"]
    MUTED = pal["MUTED"]
    USER_INK = pal["USER_INK"]
    ASSISTANT_INK = pal["ASSISTANT_INK"]
    ASSISTANT_CODE = pal["ASSISTANT_CODE"]
    return True


def active_theme() -> str:
    return _active


# Initialize at import time so module-level constants are always defined.
INK = _THEMES[_DEFAULT]["INK"]
DIM = _THEMES[_DEFAULT]["DIM"]
MUTED = _THEMES[_DEFAULT]["MUTED"]
USER_INK = _THEMES[_DEFAULT]["USER_INK"]
ASSISTANT_INK = _THEMES[_DEFAULT]["ASSISTANT_INK"]
ASSISTANT_CODE = _THEMES[_DEFAULT]["ASSISTANT_CODE"]

# Glyphs.
# We deliberately AVOID U+23FA "BLACK CIRCLE FOR RECORD" because
# Windows Terminal substitutes it with the blue Apple-style emoji
# regardless of the U+FE0E text-presentation selector
# (microsoft/terminal#8970, ongoing). U+25CF "BLACK CIRCLE" has been
# a pure text codepoint since Unicode 1.1 and is never emoji-promoted —
# so the receipt always renders as a solid amber dot, matching Claude
# Code's tone.
# Round-50: U+FE0E variation selector turned out NOT to suppress emoji
# presentation in Windows Terminal + Cascadia Code (verified live by
# user-supplied screenshots 2026-05-05 — every emoji-class glyph still
# rendered as a teal box). Falling back to BMP glyphs that have ONLY
# text presentation: ● (BLACK CIRCLE U+25CF), * (ASTERISK), and a
# few unicode arrows / triangles that don't have emoji variants.
GLYPH_RECEIPT = "●"   # BLACK CIRCLE — guaranteed monochrome
GLYPH_EXPAND = "▸"    # BLACK RIGHT-POINTING SMALL TRIANGLE
GLYPH_COLLAPSE = "▾"  # BLACK DOWN-POINTING SMALL TRIANGLE
GLYPH_THOUGHT = "*"   # ASCII ASTERISK — rendered amber, never an emoji
GLYPH_RESUME = "«"    # LEFT-POINTING DOUBLE ANGLE QUOTATION MARK
GLYPH_PAUSE = "‖"     # DOUBLE VERTICAL LINE — pause indicator
GLYPH_QUEUED = "·"    # MIDDLE DOT — minimalist queued indicator
GLYPH_WARN = "!"      # ASCII EXCLAMATION — most reliable warning glyph
GLYPH_DONE = "✓"     # round-41: matches Claude Code (was ● — research-corrected)
GLYPH_ACTIVE = "●"   # round-41: in_progress (CC mapping; was ◼)
GLYPH_PENDING = "○"  # unchanged
# Spinner uses Braille frames (U+2800–U+28FF). Pure text codepoints —
# Windows Terminal cannot emoji-promote them, so they always render in
# whatever foreground color we set (amber). The asterisk-style frames
# (✢ ✳ ✻) caused green/colored emoji glyphs on Windows.
GLYPH_SPINNER = "⠿"
GLYPH_PERM = "⏵⏵"

# Note: USER_INK / ASSISTANT_INK / ASSISTANT_CODE are theme-driven and
# initialized above. Re-importing this module after `set_theme()` updates
# them in-place — but most callers reference them at usage-time, so the
# active theme value is always picked up.

# Round-94: switched from Braille (10 frames) to Claude Code's asterisk
# cycle (5 frames) for visual parity. The asterisks read as more
# substantive than dots — fits a coding-agent's tone better than the
# dotted Braille spinner ever did.
SPINNER_FRAMES = ["✻", "✽", "✶", "✳", "✢"]
