"""Round 97: Textual widgets for the Background Subagent
infrastructure.

  * `SubAgentCard` — one card per dispatched subagent. Two visual
    states: collapsed (just the header + status pill subline) and
    expanded (header + indented body of recent events + result
    preview).
  * `SubAgentPanel` — vertical stack of cards. The app calls
    `.sync(tasks)` on each rail tick to add/remove/refresh cards
    based on the manager's snapshot.

Design choices and the verbatim card-string shape are documented
in `docs/SUBAGENT_ARCHITECTURE.md`. The header reads:
    `⏺ Agent(<name>)`
and the subline reads:
    `└ <pill> · ↓ to manage · ctrl+o to expand`

PrometheUS keeps its own brand strings — the *shape* mirrors
Claude Code's rhythm but the verbatim render is ours. We don't
claim verbatim parity with Claude (per the round-96 brand-leak
invariant).

These widgets are independent of the manager — they read state
from a SubAgentTask reference and never write back. State
transitions happen inside `BackgroundAgentManager`; widgets just
render.
"""
from __future__ import annotations

from typing import Any, Optional

from rich.console import Group
from rich.text import Text
from textual.containers import Vertical
from textual.widgets import Static

from prometheus.agent.subagent_manager import (
    SubAgentStatus,
    SubAgentTask,
)
from prometheus.ui.theme import (
    AMBER,
    DIM,
    ERROR,
    INK,
    MUTED,
    SUCCESS,
)


# ---------- formatting helpers ----------


def _format_elapsed(seconds: float) -> str:
    """Compact elapsed for the status pill: `0:42`, `1:12`,
    `10:00`. Mirrors Claude's M:SS surface."""
    s = max(0, int(seconds))
    m = s // 60
    sec = s % 60
    return f"{m}:{sec:02d}"


def _status_pill_for(task: SubAgentTask) -> tuple[str, str]:
    """Return `(text, style)` for the status pill on the card
    subline. Pill text matches the architecture doc; style maps
    each lifecycle state to a sensible color from the theme."""
    elapsed = _format_elapsed(task.elapsed_s())
    if task.status == SubAgentStatus.QUEUED:
        return "queued", DIM
    if task.status == SubAgentStatus.RUNNING:
        return f"running {elapsed}", AMBER
    if task.status == SubAgentStatus.COMPLETED:
        preview = task.preview(n=60)
        if preview:
            return f"✓ completed {elapsed} · {preview}", SUCCESS
        return f"✓ completed {elapsed}", SUCCESS
    if task.status == SubAgentStatus.FAILED:
        reason = (task.error or "unknown error")[:60]
        return f"× failed: {reason}", ERROR
    if task.status == SubAgentStatus.CANCELLED:
        return "· cancelled", MUTED
    if task.status == SubAgentStatus.TIMEOUT:
        return f"⏱ timed out after {elapsed}", ERROR
    # Defensive default.
    return str(task.status.value), MUTED


# Glyphs for the card surface. Unicode middle-dot bullet for the
# header so cards visually punch out from chat-log receipts.
_GLYPH_HEAD = "⏺"   # U+23FA  black circle for record (Claude-style)
_GLYPH_TAIL = "└"   # U+2514  box drawings light up and right


def progress_line_for(task: SubAgentTask) -> Optional[tuple[str, str]]:
    """Round 164 / #2: the inline progress line shown on a cohort
    card under the status pill.

    Returns `(text, style)` or `None` when there's nothing useful
    to show (cohort hasn't called any tools yet, or it's terminal
    and we've already surfaced the result via `task.preview()`).

    Two states:
      - `task.current_tool` is set:  "✦ Running: <verb> <detail>"
        (e.g. `Running: pytest -q`)
      - cohort has finished a tool but not the cohort itself:
        "⏺ Completed: <past-verb> <detail>"

    The verb tables are the same `tui_progress.verb_for` /
    `past_verb_for` the activity rail uses, so the cohort surface
    stays consistent with the parent's surface.
    """
    from prometheus.tui_progress import (
        verb_for, past_verb_for, detail_for,
    )
    # Currently-running tool wins.
    if task.current_tool:
        verb = verb_for(task.current_tool)
        detail = detail_for(task.current_tool, task.current_tool_args)
        body = f"{verb} {detail}".strip() if detail else verb
        return f"✦ {body}", AMBER
    # Most-recent completed tool, only shown while the cohort is
    # still running (terminal cohorts use the status pill's preview).
    if task.last_completed_tool and not task.is_terminal():
        if task.last_completed_summary:
            return f"⏺ {task.last_completed_summary}", MUTED
        verb = past_verb_for(task.last_completed_tool)
        return f"⏺ {verb}", MUTED
    return None


# ---------- SubAgentCard ----------


class SubAgentCard(Static):
    """One card in the SubAgentPanel.

    Holds a reference to a SubAgentTask and renders from it. The
    card never mutates the task — callers (the manager + the
    expand/collapse action) own all state changes.
    """

    DEFAULT_CSS = """
    SubAgentCard { padding: 0 2; height: auto; }
    """

    def __init__(self, task: SubAgentTask) -> None:
        super().__init__()
        # Textual's Static reserves the `task` attribute internally
        # (the widget has its own asyncio.Task mechanic). Hold the
        # subagent under a non-conflicting name.
        self.subagent: SubAgentTask = task

    # Backward-compat alias for callers that prefer the
    # architecture-doc name. Read-only.
    @property
    def task_record(self) -> SubAgentTask:
        return self.subagent

    # The panel calls `.refresh()` directly when state changes;
    # we don't need a reactive on the task reference itself.

    def render(self) -> Any:
        task = self.subagent

        # Header: `⏺ Agent(<name>)`
        head = Text()
        head.append(_GLYPH_HEAD + " ", style=INK)
        head.append("Agent(", style=DIM)
        # Truncate the name so a runaway description doesn't wrap
        # the panel — 64 chars covers most real cases.
        name_disp = task.name[:64] + ("…" if len(task.name) > 64 else "")
        head.append(name_disp, style=INK)
        head.append(")", style=DIM)

        # Subline: `└ <pill> · ↓ to manage · ctrl+o to expand`.
        # `↓ to manage` is a forward-looking affordance (the
        # round-97 manage picker is deferred); we keep the string
        # because it's part of the contract surface a user sees
        # in screenshots. `ctrl+o to expand` hints the binding.
        # Once expanded, `ctrl+o` collapses again — same key.
        sub = Text()
        sub.append(_GLYPH_TAIL + " ", style=DIM)
        pill_text, pill_style = _status_pill_for(task)
        sub.append(pill_text, style=pill_style)
        # Affordance hints, dim so they don't fight the pill.
        if not task.is_terminal():
            sub.append("  ·  ", style=DIM)
            sub.append("↓ to manage", style=MUTED)
        sub.append("  ·  ", style=DIM)
        if task.expanded:
            sub.append("ctrl+o to collapse", style=MUTED)
        else:
            sub.append("ctrl+o to expand", style=MUTED)

        # Round 164 / #2: live progress line for the currently-
        # running tool inside this cohort. Sits between the status
        # subline and the (collapsed-or-expanded) body.
        progress = progress_line_for(task)
        progress_widget: Optional[Text] = None
        if progress is not None:
            ptext, pstyle = progress
            progress_widget = Text("    " + ptext, style=pstyle)

        if not task.expanded:
            if progress_widget is not None:
                return Group(head, sub, progress_widget)
            return Group(head, sub)

        # Expanded body: indented event lines + (if available) the
        # result, capped to keep the UI manageable.
        body_lines: list[Text] = []
        # Limit the events shown so a 400-event task doesn't blow
        # the panel. Most-recent 12.
        recent = task.events[-12:]
        for ev in recent:
            line = Text("    ", style=DIM)
            # Kind glyph for visual scan; `·` is the neutral default.
            kind_glyph = {
                "text":        "·",
                "tool_call":   "▸",
                "tool_result": "✓",
                "status":      "*",
            }.get(ev.kind, "·")
            line.append(f"{kind_glyph} ", style=DIM)
            line.append(ev.text[:120], style=MUTED)
            body_lines.append(line)
        # Result preview block (final assistant text).
        if task.result:
            sep = Text("    ----", style=DIM)
            body_lines.append(sep)
            for ln in task.result.splitlines()[:8]:
                body_lines.append(Text("    " + ln[:160], style=INK))
            if task.result.count("\n") > 8:
                body_lines.append(Text(
                    "    … (truncated; full text returned to parent)",
                    style=DIM,
                ))
        elif task.error:
            sep = Text("    ----", style=DIM)
            body_lines.append(sep)
            body_lines.append(Text(
                f"    error: {task.error}", style=ERROR,
            ))
        if not body_lines:
            body_lines.append(Text("    (no activity yet)", style=DIM))

        # Round 164 / #2: progress line sits between subline and the
        # event body so it stays visible in expanded mode too.
        if progress_widget is not None:
            return Group(head, sub, progress_widget, *body_lines)
        return Group(head, sub, *body_lines)


# ---------- SubAgentPanel ----------


class SubAgentPanel(Vertical):
    """Vertical stack of SubAgentCards. The app calls `.sync(tasks)`
    each rail tick; we add cards for new tasks, refresh existing
    cards, and remove cards for tasks that no longer appear.

    The panel is invisible (height=0) when there are zero cards so
    it doesn't displace the rail or chat-log when no subagents are
    in flight.
    """

    DEFAULT_CSS = """
    SubAgentPanel { height: auto; }
    SubAgentPanel.-empty { display: none; }
    """

    def __init__(self) -> None:
        super().__init__()
        # Map agent_id → SubAgentCard for O(1) sync.
        self._cards: dict[str, SubAgentCard] = {}

    def sync(self, tasks: list[SubAgentTask]) -> None:
        """Reconcile mounted cards against the manager's snapshot.

        Adds new tasks as cards, refreshes existing cards in
        submission order (so the panel reads top-to-bottom oldest-
        to-newest), removes cards whose tasks are no longer in the
        snapshot.
        """
        snapshot_ids = {t.id for t in tasks}
        # Remove vanished cards.
        for tid in list(self._cards.keys()):
            if tid not in snapshot_ids:
                card = self._cards.pop(tid)
                try:
                    card.remove()
                except Exception:
                    # Card may have already been removed mid-tick.
                    pass
        # Add and refresh.
        for task in tasks:
            card = self._cards.get(task.id)
            if card is None:
                card = SubAgentCard(task)
                self._cards[task.id] = card
                try:
                    self.mount(card)
                except Exception:
                    # Mount race; the next tick will retry.
                    pass
            else:
                # Update the task reference in case the manager
                # replaced it (rare; defensive).
                card.subagent = task
                card.refresh()
        # Empty-state class.
        self.set_class(not self._cards, "-empty")

    def cards(self) -> list[SubAgentCard]:
        """Return the cards in mount order. Test-only convenience —
        production code reads from the manager."""
        return list(self._cards.values())

    def most_recent_card(self) -> Optional[SubAgentCard]:
        """The card mounted most recently — the implicit target
        for `ctrl+o` when there's no other selection signal."""
        if not self._cards:
            return None
        # Submission order is preserved by dict insertion order.
        last_id = next(reversed(self._cards))
        return self._cards[last_id]


# ---------- toggle action helper ----------


def toggle_most_recent_card(panel: SubAgentPanel) -> bool:
    """Flip the `expanded` flag on the most-recent card. Returns
    True if a toggle happened, False if there was nothing to
    toggle. Pulled out as a standalone helper so the App can wire
    `ctrl+o` without depending on the panel's internals.

    The actual key binding lives on the App; this is the
    behavioral kernel that the binding's action calls.
    """
    card = panel.most_recent_card()
    if card is None:
        return False
    card.subagent.expanded = not card.subagent.expanded
    card.refresh()
    return True
