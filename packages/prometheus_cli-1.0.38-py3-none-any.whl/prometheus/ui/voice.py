"""Round 119: Voice input mode.

Push-to-talk at the input cursor. The hard parts (microphone
capture, Whisper transcription) live behind clean fallback paths
so PrometheUS works fine without them — the user gets a clear
message instead of a crash.

State machine:

  off              — no recording, /voice toggles to `armed`
  armed            — voice mode active, status bar shows indicator
  recording        — spacebar held, capturing audio
  transcribing     — releasing spacebar, awaiting transcription
  off (after)      — text inserted at cursor, return to typing

Round-119 ships:
  * `VoiceState` data model + transitions
  * `Backend` protocol so multiple transcribers can plug in
    (Whisper local, OpenAI API, Anthropic transcription, etc.)
  * `NullBackend` — clean fallback when no microphone is
    available; emits a friendly "voice mode unavailable" message
  * `/voice` slash command toggle
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional, Protocol


VOICE_OFF = "off"
VOICE_ARMED = "armed"
VOICE_RECORDING = "recording"
VOICE_TRANSCRIBING = "transcribing"


VOICE_STATES = (
    VOICE_OFF, VOICE_ARMED, VOICE_RECORDING, VOICE_TRANSCRIBING,
)


# ---------- backend protocol ----------


class TranscriberBackend(Protocol):
    """Round 119: pluggable transcription backend."""

    available: bool
    name: str

    async def start_recording(self) -> None: ...
    async def stop_and_transcribe(self) -> str: ...


@dataclass
class NullBackend:
    """Fallback backend used when no microphone or transcriber
    library is available. Returns a friendly message instead of
    raising."""
    available: bool = False
    name: str = "null"

    async def start_recording(self) -> None:
        return None

    async def stop_and_transcribe(self) -> str:
        return ""


def detect_backend() -> TranscriberBackend:
    """Probe the environment for usable backends. Order:
      1. Whisper (whisper.cpp / openai-whisper) — local
      2. SoundDevice + Whisper API — local mic + remote transcribe
      3. NullBackend (always available)

    Round-119 scope: just NullBackend until the user opts into a
    specific backend. Real backends go into a separate module so
    PrometheUS stays slim by default."""
    return NullBackend()


# ---------- state model ----------


@dataclass
class VoiceState:
    """Round 119: voice-mode state. Lives on the app at
    `app._voice_state`. Transitions are explicit so tests can
    drive them without a mic."""
    mode: str = VOICE_OFF
    backend: TranscriberBackend = None  # type: ignore[assignment]
    last_transcription: str = ""

    def __post_init__(self) -> None:
        if self.backend is None:
            self.backend = detect_backend()

    @property
    def is_active(self) -> bool:
        return self.mode != VOICE_OFF

    @property
    def status_label(self) -> str:
        return {
            VOICE_OFF: "",
            VOICE_ARMED: "voice",
            VOICE_RECORDING: "🎙 recording",
            VOICE_TRANSCRIBING: "voice (transcribing…)",
        }.get(self.mode, "")

    def toggle(self) -> tuple[str, str]:
        """Toggle voice mode on/off. Returns (new_mode, message)."""
        if self.mode == VOICE_OFF:
            if not self.backend.available:
                return VOICE_OFF, (
                    "voice mode unavailable: no transcriber backend. "
                    "Install whisper or set PROMETHEUS_VOICE_BACKEND."
                )
            self.mode = VOICE_ARMED
            return VOICE_ARMED, "voice mode armed (hold space to record)"
        # Anything else → off.
        self.mode = VOICE_OFF
        return VOICE_OFF, "voice mode off"

    async def begin_recording(self) -> tuple[bool, str]:
        if self.mode != VOICE_ARMED:
            return False, "not armed"
        try:
            await self.backend.start_recording()
        except Exception as e:
            return False, f"recording failed: {e}"
        self.mode = VOICE_RECORDING
        return True, "recording"

    async def end_and_transcribe(self) -> tuple[bool, str]:
        if self.mode != VOICE_RECORDING:
            return False, "not recording"
        self.mode = VOICE_TRANSCRIBING
        try:
            text = await self.backend.stop_and_transcribe()
        except Exception as e:
            self.mode = VOICE_ARMED
            return False, f"transcription failed: {e}"
        self.mode = VOICE_ARMED
        self.last_transcription = text
        return True, text
