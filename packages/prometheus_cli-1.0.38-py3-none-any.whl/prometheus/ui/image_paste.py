"""Per-app image-paste manager.

Owns the placeholder ↔ bytes map for one App. Mirrors the existing
text-paste collapse: Ctrl+V inserts `[Image #N: WxH PNG, K KB]` into
the Input; on submit we substitute the placeholder back with an OpenAI
multipart `image_url` content part.
"""
from __future__ import annotations

import base64
import re
from dataclasses import dataclass


@dataclass
class PastedImage:
    seq: int
    bytes_data: bytes
    mime: str
    width: int
    height: int
    placeholder: str


class ImagePasteManager:
    def __init__(self) -> None:
        self._items: dict[str, PastedImage] = {}
        self._seq: int = 0

    def add(self, image_bytes: bytes, mime: str = "image/png") -> PastedImage:
        from prometheus.ui.clipboard import measure_png
        self._seq += 1
        if mime == "image/png":
            w, h = measure_png(image_bytes)
        else:
            w, h = (0, 0)
        size_kb = max(1, len(image_bytes) // 1024)
        size_label = "PNG" if mime == "image/png" else mime.split("/")[-1].upper()
        ph = (
            f"[Image #{self._seq}: {w}x{h} {size_label}, {size_kb:,} KB]"
            if w and h else
            f"[Image #{self._seq}: {size_label}, {size_kb:,} KB]"
        )
        item = PastedImage(self._seq, image_bytes, mime, w, h, ph)
        self._items[ph] = item
        return item

    def get(self, placeholder: str) -> PastedImage | None:
        return self._items.get(placeholder)

    def all(self) -> list[PastedImage]:
        return list(self._items.values())

    def clear(self) -> None:
        self._items.clear()
        self._seq = 0


_PLACEHOLDER_RX = re.compile(r"\[Image #\d+:[^\]]*\]")


def build_user_message_parts(
    text_with_placeholders: str,
    items: dict[str, PastedImage],
) -> list[dict]:
    """Convert a text+placeholder string into OpenAI multipart content.

    Returns a list of {type: text|image_url, ...}. Order is preserved:
    text-before, image, text-between, image, text-after.
    """
    if not items:
        cleaned = text_with_placeholders.strip()
        return [{"type": "text", "text": cleaned}] if cleaned else []
    parts: list[dict] = []
    cursor = 0
    for m in _PLACEHOLDER_RX.finditer(text_with_placeholders):
        before = text_with_placeholders[cursor:m.start()]
        if before.strip():
            parts.append({"type": "text", "text": before})
        token = m.group(0)
        img = items.get(token)
        if img is not None:
            b64 = base64.b64encode(img.bytes_data).decode("ascii")
            parts.append({
                "type": "image_url",
                "image_url": {
                    "url": f"data:{img.mime};base64,{b64}",
                    "detail": "high",
                },
            })
        cursor = m.end()
    tail = text_with_placeholders[cursor:]
    if tail.strip():
        parts.append({"type": "text", "text": tail})
    if not parts:
        # All placeholders, no text — keep at least one text part for engines
        # that reject empty content arrays.
        parts.insert(0, {"type": "text", "text": "(image attached)"})
    return parts
