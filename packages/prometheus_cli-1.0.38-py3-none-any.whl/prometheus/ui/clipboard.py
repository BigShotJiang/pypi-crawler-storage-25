"""Cross-platform clipboard image reader.

Returns (png_bytes, "image/png") or None. Always normalizes to PNG so
callers (image_paste.py, openrouter multipart message builder) don't
care about source format.

Windows priority order (most reliable → least):
    1. Registered "PNG" / "image/png" formats — modern Snipping Tool
       and `Win+Shift+S` write PNG directly. No conversion. This is
       the fix Claude Code keeps missing (issues #26679, #32005).
    2. CF_DIBV5 / CF_DIB → reconstruct BMP file → encode to PNG via
       pure-stdlib BMP→PNG (no Pillow dependency).
    3. CF_HDROP → user copied an image FILE in Explorer; read bytes.

macOS:
    osascript fallback (always present) → temp PNG file → bytes.
    pngpaste used if installed (faster).

Linux:
    wl-paste on Wayland, xclip on X11. Walks MIME types in priority
    order: image/png → image/jpeg → image/webp → image/bmp →
    text/uri-list (file:// scheme).

Never raises — every error path returns None and a debug log entry.
"""
from __future__ import annotations

import sys
from pathlib import Path

from prometheus import log

logger = log.get("ui.clipboard")


# Public entry point — dispatched at module load.
def read_clipboard_image() -> tuple[bytes, str] | None:
    """Returns (png_bytes, "image/png") or None."""
    try:
        if sys.platform == "win32":
            return _read_windows()
        if sys.platform == "darwin":
            return _read_macos()
        return _read_linux()
    except Exception:
        logger.exception("clipboard read failed")
        return None


# ---------------------------------------------------------------- Windows

def _read_windows() -> tuple[bytes, str] | None:
    import ctypes
    from ctypes import wintypes as w

    u32 = ctypes.WinDLL("user32", use_last_error=True)
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)

    u32.OpenClipboard.argtypes = (w.HWND,)
    u32.OpenClipboard.restype = w.BOOL
    u32.CloseClipboard.argtypes = ()
    u32.CloseClipboard.restype = w.BOOL
    u32.EnumClipboardFormats.argtypes = (w.UINT,)
    u32.EnumClipboardFormats.restype = w.UINT
    u32.GetClipboardData.argtypes = (w.UINT,)
    u32.GetClipboardData.restype = w.HANDLE
    u32.RegisterClipboardFormatW.argtypes = (w.LPCWSTR,)
    u32.RegisterClipboardFormatW.restype = w.UINT
    k32.GlobalLock.argtypes = (w.HGLOBAL,)
    k32.GlobalLock.restype = w.LPVOID
    k32.GlobalUnlock.argtypes = (w.HGLOBAL,)
    k32.GlobalUnlock.restype = w.BOOL
    k32.GlobalSize.argtypes = (w.HGLOBAL,)
    k32.GlobalSize.restype = ctypes.c_size_t

    CF_DIB = 8
    CF_DIBV5 = 17
    CF_HDROP = 15

    def _read_format_bytes(fmt: int) -> bytes | None:
        h = u32.GetClipboardData(fmt)
        if not h:
            return None
        n = k32.GlobalSize(h)
        p = k32.GlobalLock(h)
        if not p:
            return None
        try:
            return ctypes.string_at(p, n)
        finally:
            k32.GlobalUnlock(h)

    if not u32.OpenClipboard(None):
        return None
    try:
        png_fmt = u32.RegisterClipboardFormatW("PNG")
        png_mime_fmt = u32.RegisterClipboardFormatW("image/png")
        available: set[int] = set()
        f = 0
        while True:
            f = u32.EnumClipboardFormats(f)
            if not f:
                break
            available.add(f)
        # Priority 1: PNG already in the clipboard — no conversion.
        for fmt in (png_fmt, png_mime_fmt):
            if fmt and fmt in available:
                data = _read_format_bytes(fmt)
                if data and data[:8] == b"\x89PNG\r\n\x1a\n":
                    return data, "image/png"
        # Priority 2: DIB → BMP → PNG.
        for fmt in (CF_DIBV5, CF_DIB):
            if fmt in available:
                dib = _read_format_bytes(fmt)
                if dib:
                    bmp = _dib_to_bmp(dib)
                    if bmp:
                        png = _bmp_to_png(bmp)
                        if png:
                            return png, "image/png"
        # Priority 3: file path list.
        if CF_HDROP in available:
            paths = _read_hdrop(u32, ctypes)
            for p in paths:
                low = p.lower()
                if low.endswith(".png"):
                    return Path(p).read_bytes(), "image/png"
                if low.endswith((".jpg", ".jpeg")):
                    return Path(p).read_bytes(), "image/jpeg"
                if low.endswith(".webp"):
                    return Path(p).read_bytes(), "image/webp"
                if low.endswith(".bmp"):
                    bmp = Path(p).read_bytes()
                    png = _bmp_to_png(bmp)
                    return (png or bmp), "image/png"
        return None
    finally:
        u32.CloseClipboard()


def _read_hdrop(u32, ctypes) -> list[str]:
    from ctypes import wintypes as w
    shell32 = ctypes.WinDLL("shell32")
    shell32.DragQueryFileW.argtypes = (w.HANDLE, w.UINT, w.LPWSTR, w.UINT)
    shell32.DragQueryFileW.restype = w.UINT
    CF_HDROP = 15
    h = u32.GetClipboardData(CF_HDROP)
    if not h:
        return []
    count = shell32.DragQueryFileW(h, 0xFFFFFFFF, None, 0)
    out: list[str] = []
    for i in range(count):
        n = shell32.DragQueryFileW(h, i, None, 0)
        buf = ctypes.create_unicode_buffer(n + 1)
        shell32.DragQueryFileW(h, i, buf, n + 1)
        out.append(buf.value)
    return out


def _dib_to_bmp(dib: bytes) -> bytes:
    """Prepend a BITMAPFILEHEADER so DIB bytes become a valid .bmp."""
    import struct
    if len(dib) < 16:
        return b""
    bi_size = struct.unpack_from("<I", dib, 0)[0]
    bit_count = struct.unpack_from("<H", dib, 14)[0]
    bi_clr_used = struct.unpack_from("<I", dib, 32)[0] if bi_size >= 36 else 0
    if bit_count <= 8:
        n_colors = bi_clr_used or (1 << bit_count)
        palette_size = n_colors * 4
    else:
        compression = struct.unpack_from("<I", dib, 16)[0] if bi_size >= 20 else 0
        palette_size = 12 if (compression == 3 and bi_size == 40) else 0
    pixel_offset = 14 + bi_size + palette_size
    file_size = 14 + len(dib)
    bfh = struct.pack("<2sIHHI", b"BM", file_size, 0, 0, pixel_offset)
    return bfh + dib


def _bmp_to_png(bmp: bytes) -> bytes:
    """Pure-stdlib BMP → PNG. Handles 24/32 bpp uncompressed BMPs.
    Returns b"" on unsupported formats (caller falls back / errors)."""
    import binascii
    import struct
    import zlib
    if bmp[:2] != b"BM":
        return b""
    pix_off = struct.unpack_from("<I", bmp, 10)[0]
    bi_size = struct.unpack_from("<I", bmp, 14)[0]
    if bi_size < 12:
        return b""
    width, height_signed = struct.unpack_from("<ii", bmp, 18)
    bit_count = struct.unpack_from("<H", bmp, 28)[0]
    height = abs(height_signed)
    top_down = height_signed < 0
    stride = ((bit_count * width + 31) // 32) * 4
    pixels = bmp[pix_off:]
    rows: list[bytes] = []
    if bit_count == 32:
        for r in range(height):
            src_row = r if top_down else (height - 1 - r)
            row = pixels[src_row * stride: src_row * stride + width * 4]
            out = bytearray(len(row))
            for i in range(0, len(row), 4):
                out[i] = row[i + 2]
                out[i + 1] = row[i + 1]
                out[i + 2] = row[i]
                out[i + 3] = row[i + 3]
            rows.append(bytes(out))
    elif bit_count == 24:
        for r in range(height):
            src_row = r if top_down else (height - 1 - r)
            row = pixels[src_row * stride: src_row * stride + width * 3]
            out = bytearray(width * 4)
            for i in range(width):
                out[4 * i] = row[3 * i + 2]
                out[4 * i + 1] = row[3 * i + 1]
                out[4 * i + 2] = row[3 * i]
                out[4 * i + 3] = 0xFF
            rows.append(bytes(out))
    else:
        return b""

    def chunk(tag: bytes, data: bytes) -> bytes:
        return (
            struct.pack(">I", len(data)) + tag + data
            + struct.pack(">I", binascii.crc32(tag + data) & 0xFFFFFFFF)
        )
    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)
    raw = b"".join(b"\x00" + row for row in rows)
    idat = zlib.compress(raw, 6)
    return sig + chunk(b"IHDR", ihdr) + chunk(b"IDAT", idat) + chunk(b"IEND", b"")


# ---------------------------------------------------------------- macOS

def _read_macos() -> tuple[bytes, str] | None:
    import os
    import shutil
    import subprocess
    import tempfile
    if shutil.which("pngpaste"):
        try:
            r = subprocess.run(["pngpaste", "-"], capture_output=True, timeout=2)
            if r.returncode == 0 and r.stdout[:8] == b"\x89PNG\r\n\x1a\n":
                return r.stdout, "image/png"
        except Exception:
            pass
    # osascript fallback: write PNG class to a temp file, then read.
    fd, path = tempfile.mkstemp(suffix=".png")
    os.close(fd)
    try:
        script = (
            'set png_data to the clipboard as «class PNGf»\n'
            f'set f to open for access POSIX file "{path}" with write permission\n'
            'set eof of f to 0\n'
            'write png_data to f\n'
            'close access f'
        )
        r = subprocess.run(["osascript", "-e", script], capture_output=True, timeout=3)
        if r.returncode == 0 and os.path.getsize(path) > 0:
            with open(path, "rb") as fh:
                data = fh.read()
            if data[:8] == b"\x89PNG\r\n\x1a\n":
                return data, "image/png"
        return None
    except Exception:
        return None
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


# ---------------------------------------------------------------- Linux

def _read_linux() -> tuple[bytes, str] | None:
    import os
    import shutil
    import subprocess

    is_wayland = bool(os.environ.get("WAYLAND_DISPLAY"))
    if is_wayland and shutil.which("wl-paste"):
        try:
            r = subprocess.run(["wl-paste", "--list-types"], capture_output=True, timeout=2, text=True)
            if r.returncode != 0:
                return None
            types = [t.strip() for t in r.stdout.splitlines() if t.strip()]
            for t in ("image/png", "image/jpeg", "image/webp", "image/bmp"):
                if t in types:
                    r = subprocess.run(["wl-paste", "--type", t], capture_output=True, timeout=3)
                    if r.returncode == 0 and r.stdout:
                        if t == "image/bmp":
                            png = _bmp_to_png(r.stdout)
                            return (png or r.stdout), ("image/png" if png else "image/bmp")
                        return r.stdout, t
            return None
        except Exception:
            return None
    if shutil.which("xclip"):
        try:
            r = subprocess.run(
                ["xclip", "-selection", "clipboard", "-t", "TARGETS", "-o"],
                capture_output=True, timeout=2, text=True,
            )
            if r.returncode != 0:
                return None
            targets = set(r.stdout.split())
            for t in ("image/png", "image/jpeg", "image/webp", "image/bmp"):
                if t in targets:
                    r = subprocess.run(
                        ["xclip", "-selection", "clipboard", "-t", t, "-o"],
                        capture_output=True, timeout=3,
                    )
                    if r.returncode == 0 and r.stdout:
                        if t == "image/bmp":
                            png = _bmp_to_png(r.stdout)
                            return (png or r.stdout), ("image/png" if png else "image/bmp")
                        return r.stdout, t
            if "text/uri-list" in targets:
                r = subprocess.run(
                    ["xclip", "-selection", "clipboard", "-t", "text/uri-list", "-o"],
                    capture_output=True, timeout=2, text=True,
                )
                for line in r.stdout.splitlines():
                    if line.startswith("file://"):
                        path = line[7:]
                        low = path.lower()
                        if low.endswith(".png"):
                            return Path(path).read_bytes(), "image/png"
                        if low.endswith((".jpg", ".jpeg")):
                            return Path(path).read_bytes(), "image/jpeg"
                        if low.endswith(".webp"):
                            return Path(path).read_bytes(), "image/webp"
                        if low.endswith(".bmp"):
                            png = _bmp_to_png(Path(path).read_bytes())
                            return (png or Path(path).read_bytes()), "image/png"
            return None
        except Exception:
            return None
    return None


def measure_png(data: bytes) -> tuple[int, int]:
    """Width, height from PNG IHDR. Returns (0, 0) for invalid input."""
    import struct
    if data[:8] != b"\x89PNG\r\n\x1a\n" or len(data) < 24:
        return (0, 0)
    return struct.unpack(">II", data[16:24])
