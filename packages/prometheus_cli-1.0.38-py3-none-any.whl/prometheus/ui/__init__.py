"""Round-162 fix: lazy-load `PrometheusApp` so importing any
sibling under `prometheus.ui` (e.g. `prometheus.ui.render`) does
not cascade through `app.py`'s heavy imports — which include
`prometheus.slash.commands` and trigger a circular import when
the slash package's own `__init__` is what triggered the import
in the first place.

Importers who actually need `PrometheusApp` can still do
`from prometheus.ui import PrometheusApp` — it's resolved via
__getattr__ on first access.
"""
from __future__ import annotations

__all__ = ["PrometheusApp"]


def __getattr__(name):
    if name == "PrometheusApp":
        from prometheus.ui.app import PrometheusApp as _Cls
        return _Cls
    raise AttributeError(f"module 'prometheus.ui' has no attribute {name!r}")
