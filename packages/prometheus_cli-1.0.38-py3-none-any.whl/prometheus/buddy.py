"""Round 145: Buddy Pet system — cosmetic finale.

A deterministic virtual companion seeded from the user id.
18 species, 5 rarity tiers, 5 stats, 3-frame ASCII animation.

Stored at `~/.prometheus/buddy.json`. The slash command
`/buddy` toggles the panel; `/buddy pet` triggers the
heart-particle effect.
"""
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


_SEED_SUFFIX = "friend-2026-401"


# ---------- catalogue ----------


SPECIES: tuple[str, ...] = (
    "duck", "goose", "blob", "cat", "dragon", "octopus",
    "owl", "penguin", "turtle", "snail", "ghost",
    "axolotl", "capybara", "cactus", "robot", "rabbit",
    "mushroom", "chonk",
)


RARITY_TIERS: tuple[tuple[str, int], ...] = (
    ("common",     50),
    ("uncommon",   25),
    ("rare",       15),
    ("epic",        7),
    ("legendary",   3),
)


STAT_NAMES: tuple[str, ...] = (
    "DEBUGGING", "PATIENCE", "CHAOS", "WISDOM", "SNARK",
)


# ---------- ASCII frames ----------


_FRAMES: dict[str, tuple[str, str, str]] = {
    "duck":      ("(o< ", "(O< ", "(o>~"),
    "goose":     (" 7_<", " 7_o", " 7_-"),
    "blob":      ("(o ω o)", "(O ω o)", "(o ω O)"),
    "cat":       ("=^.^=", "=^_^=", "=^o^="),
    "dragon":    ("<})))><", "<})))>~", "<}))>><"),
    "octopus":   ("(o)8888", "(O)8888", "(o)8~8~"),
    "owl":       ("{O,O}", "{-,-}", "{O,O}"),
    "penguin":   ("<(o.o)>", "<(-.-)>", "<(o.o)>"),
    "turtle":    ("(__o__)", "(__O__)", "(__o__)~"),
    "snail":     ("@_v_v_", "@_v_v_~", "@_v_v_-"),
    "ghost":     ("~Boo~", "~boO~", "~bOO~"),
    "axolotl":   ("(°ヮ°)", "(°O°)", "(°ヮ°)~"),
    "capybara":  ("(=^o^=)", "(=^_^=)", "(=^O^=)"),
    "cactus":    ("|_||_|", "|_||_|*", "*|_||_|"),
    "robot":     ("[o_o]", "[O_O]", "[-_-]"),
    "rabbit":    ("(\\_/)", "(\\.\\)", "(/_/)"),
    "mushroom":  ("⌒(o.o)", "⌒(O.o)", "⌒(o.O)"),
    "chonk":     ("(='-'=)", "(=^_^=)", "(=O_O=)"),
}


# ---------- seed → traits ----------


def _seed_bytes(user_id: str) -> bytes:
    raw = f"{user_id or 'anon'}:{_SEED_SUFFIX}"
    return hashlib.sha256(raw.encode("utf-8")).digest()


def _pick_index(seed: bytes, modulo: int, offset: int) -> int:
    chunk = seed[offset:offset + 4]
    return int.from_bytes(chunk, "big") % max(1, modulo)


def derive_species(user_id: str) -> str:
    seed = _seed_bytes(user_id)
    idx = _pick_index(seed, len(SPECIES), 0)
    return SPECIES[idx]


def derive_rarity(user_id: str) -> str:
    """Round 145: weighted rarity pick. Stable across calls."""
    seed = _seed_bytes(user_id)
    n = _pick_index(seed, 100, 4)
    cum = 0
    for name, weight in RARITY_TIERS:
        cum += weight
        if n < cum:
            return name
    return RARITY_TIERS[0][0]


def derive_stats(user_id: str) -> dict[str, int]:
    """Round 145: deterministic 1–10 per-stat from the seed."""
    seed = _seed_bytes(user_id)
    out: dict[str, int] = {}
    for i, name in enumerate(STAT_NAMES):
        chunk = seed[8 + i * 2:8 + i * 2 + 2]
        n = int.from_bytes(chunk, "big") % 10 + 1
        out[name] = n
    # Rarity boost — legendary +2, epic +1.
    rarity = derive_rarity(user_id)
    boost = {"legendary": 2, "epic": 1}.get(rarity, 0)
    for k in out:
        out[k] = min(10, out[k] + boost)
    return out


def derive_name(user_id: str) -> str:
    """Round 145: friendly two-syllable name."""
    seed = _seed_bytes(user_id)
    syl_a = (
        "Bo", "Lu", "Ka", "Mi", "Pi", "Ro", "Su", "Ta",
        "Vi", "Wu", "Yo", "Zi", "Cha", "Fe", "Gri", "Ha",
    )
    syl_b = (
        "lo", "tu", "na", "ki", "pa", "ru", "se", "ta",
        "vi", "ko", "le", "fi", "mo", "by", "do", "ze",
    )
    a = syl_a[_pick_index(seed, len(syl_a), 16)]
    b = syl_b[_pick_index(seed, len(syl_b), 20)]
    return a + b


# ---------- buddy record ----------


@dataclass
class Buddy:
    user_id: str
    name: str
    species: str
    rarity: str
    stats: dict[str, int]
    born_at: int = 0
    times_petted: int = 0


def make_buddy(user_id: str) -> Buddy:
    return Buddy(
        user_id=user_id,
        name=derive_name(user_id),
        species=derive_species(user_id),
        rarity=derive_rarity(user_id),
        stats=derive_stats(user_id),
        born_at=int(time.time()),
        times_petted=0,
    )


# ---------- persistence ----------


def buddy_path() -> Path:
    return Path.home() / ".prometheus" / "buddy.json"


def load_buddy() -> Optional[Buddy]:
    p = buddy_path()
    if not p.exists():
        return None
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    try:
        return Buddy(
            user_id=str(d.get("user_id", "")),
            name=str(d.get("name", "")),
            species=str(d.get("species", "")),
            rarity=str(d.get("rarity", "")),
            stats={
                str(k): int(v)
                for k, v in (d.get("stats") or {}).items()
            },
            born_at=int(d.get("born_at", 0)),
            times_petted=int(d.get("times_petted", 0)),
        )
    except (TypeError, ValueError):
        return None


def save_buddy(b: Buddy) -> Path:
    p = buddy_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(
        json.dumps({
            "user_id": b.user_id,
            "name": b.name,
            "species": b.species,
            "rarity": b.rarity,
            "stats": b.stats,
            "born_at": b.born_at,
            "times_petted": b.times_petted,
        }, indent=2),
        encoding="utf-8",
    )
    return p


def get_or_create(user_id: str) -> Buddy:
    """Round 145: load or create. Returning the same Buddy
    for the same user_id is the determinism contract."""
    existing = load_buddy()
    if existing is not None and existing.user_id == user_id:
        return existing
    b = make_buddy(user_id)
    save_buddy(b)
    return b


# ---------- animation ----------


def frame_at(species: str, tick: int) -> str:
    frames = _FRAMES.get(species, ("(o.o)", "(O.O)", "(-.-)"))
    return frames[tick % 3]


# ---------- pet action ----------


def pet(b: Buddy) -> Buddy:
    b.times_petted += 1
    save_buddy(b)
    return b


HEART_PARTICLES = [
    "  ♥",
    " ♥ ♥",
    "♥ ♥ ♥",
    " ♥ ♥",
    "  ♥",
]


def render_pet_burst() -> str:
    """Round 145: heart-particle effect rendered as a stack of
    ASCII frames."""
    return "\n".join(HEART_PARTICLES)


# ---------- panel render ----------


def render_panel(b: Buddy, *, tick: int = 0) -> str:
    """Round 145: full companion panel. Includes name,
    species, rarity, stats, animation frame."""
    lines = []
    lines.append(f"  {frame_at(b.species, tick)}")
    lines.append("")
    lines.append(f"  {b.name}  the  {b.species}")
    lines.append(f"  rarity: {b.rarity}")
    lines.append("")
    for stat in STAT_NAMES:
        v = b.stats.get(stat, 0)
        bar = "█" * v + "·" * (10 - v)
        lines.append(f"  {stat:<10s} {bar} {v}/10")
    lines.append("")
    lines.append(f"  petted {b.times_petted} time(s)")
    return "\n".join(lines)
