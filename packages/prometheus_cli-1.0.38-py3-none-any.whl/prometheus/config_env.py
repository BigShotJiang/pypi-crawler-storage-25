"""Round 108: environment-variable knobs.

Centralizes the feature-toggle env vars introduced across the
Command Center build so callers can ask one function and get a
typed answer. Tested in `tests/test_round108_env_polish.py`.

Recognized variables:

  * PROMETHEUS_SIMPLE              — bare mode: only Bash / Read /
                                     Edit registered. Useful for
                                     fast minimal sessions.
  * PROMETHEUS_DISABLE_AUTO_MEMORY — disables automatic memory
                                     writes. The /memory command
                                     still works for explicit
                                     saves.
  * PROMETHEUS_DISABLE_THINKING    — turns off the model's hidden
                                     reasoning budget request.
  * PROMETHEUS_AGENT_COLOR         — short color label used in
                                     Team Mode dashboards.
  * PROMETHEUS_AGENT_TEAMS         — already wired in round 107.
  * PROMETHEUS_LEAN_PROMPT         — already wired in round 92.
  * PROMETHEUS_SUBAGENT_*          — already wired in round 97.
  * PROMETHEUS_CHECKPOINT_RETENTION_DAYS — round 105 checkpoint
                                          retention floor.
"""
from __future__ import annotations

import os


def _truthy(name: str, default: str = "0") -> bool:
    return os.environ.get(name, default).strip().lower() in (
        "1", "true", "yes", "on",
    )


def simple_mode_enabled() -> bool:
    """`PROMETHEUS_SIMPLE=1` → only Bash / Read / Edit register."""
    return _truthy("PROMETHEUS_SIMPLE")


def auto_memory_disabled() -> bool:
    """`PROMETHEUS_DISABLE_AUTO_MEMORY=1` → no automatic
    memory-extraction. Explicit /memory save still works."""
    return _truthy("PROMETHEUS_DISABLE_AUTO_MEMORY")


def thinking_disabled() -> bool:
    """`PROMETHEUS_DISABLE_THINKING=1` → don't request reasoning
    tokens from the provider."""
    return _truthy("PROMETHEUS_DISABLE_THINKING")


def agent_color() -> str:
    """`PROMETHEUS_AGENT_COLOR=<name>` → visual identifier for
    Team Mode. Default `default` (no color)."""
    return os.environ.get("PROMETHEUS_AGENT_COLOR", "default").strip() or "default"


def checkpoint_retention_days() -> int:
    """`PROMETHEUS_CHECKPOINT_RETENTION_DAYS=N` → days before an
    auto-checkpoint is eligible for cleanup. Default 30."""
    try:
        return int(
            os.environ.get(
                "PROMETHEUS_CHECKPOINT_RETENTION_DAYS", "30",
            )
        )
    except (TypeError, ValueError):
        return 30


SIMPLE_TOOLS = ("run_bash", "read_file", "edit_file")
"""Tool names retained when PROMETHEUS_SIMPLE=1. Everything else
is dropped from the registry on init."""


def filter_simple_registry(registry) -> None:
    """Mutate `registry` in place: keep only the SIMPLE_TOOLS
    when simple mode is active. No-op otherwise. The caller
    invokes this AFTER `build_default_registry` so all tools
    get the chance to be filtered together."""
    if not simple_mode_enabled():
        return
    keep = set(SIMPLE_TOOLS)
    for name in list(registry._tools.keys()):
        if name not in keep:
            registry._tools.pop(name, None)


def env_summary() -> dict[str, str]:
    """Return a dict of recognized env-var states for /doctor."""
    return {
        "PROMETHEUS_SIMPLE": "1" if simple_mode_enabled() else "0",
        "PROMETHEUS_DISABLE_AUTO_MEMORY":
            "1" if auto_memory_disabled() else "0",
        "PROMETHEUS_DISABLE_THINKING":
            "1" if thinking_disabled() else "0",
        "PROMETHEUS_AGENT_COLOR": agent_color(),
        "PROMETHEUS_AGENT_TEAMS":
            os.environ.get("PROMETHEUS_AGENT_TEAMS", "0"),
        "PROMETHEUS_LEAN_PROMPT":
            os.environ.get("PROMETHEUS_LEAN_PROMPT", "1"),
        "PROMETHEUS_CHECKPOINT_RETENTION_DAYS":
            str(checkpoint_retention_days()),
    }
