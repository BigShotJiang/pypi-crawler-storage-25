"""Round 136: top-level CLI subcommands.

Invoked as `prometheus <subcommand>` from the shell — i.e.
*outside* a Prometheus session. Mirrors the in-session slash
commands so users can scope work without launching the TUI.

Subcommands:

  * `prometheus agents`         — list/manage cohort agent definitions
  * `prometheus mcp`            — list/manage MCP server connections
  * `prometheus forge`          — list/manage Forge Kits
  * `prometheus project purge`  — delete project-scoped state

Each subcommand is dispatchable: returns an exit code (0 on
success, non-zero on failure). The argv parser detects whether
the first positional is a known subcommand and routes here
before falling through to the headless prompt path.
"""
from __future__ import annotations

import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional


SUBCOMMANDS = (
    "agents", "mcp", "forge", "project",
    # Round 138: auth + rc (+ remote-control alias)
    "auth", "rc", "remote-control",
    # Round 142: background-session management
    "ps", "logs", "attach", "kill",
    # Round 143: install + update
    "install", "update",
    # Round 144-final-v3: KAIROS daemon
    "daemon",
    # Round 151: config CLI
    "config",
)


@dataclass
class SubcommandResult:
    exit_code: int
    output: str = ""


def is_subcommand(argv: list[str]) -> bool:
    """Round 136: detect a top-level subcommand from raw argv.
    Skips leading flags so `--verbose agents` still routes."""
    for tok in argv:
        if tok.startswith("-"):
            continue
        return tok in SUBCOMMANDS
    return False


def first_nonflag(argv: list[str]) -> Optional[str]:
    for tok in argv:
        if not tok.startswith("-"):
            return tok
    return None


# ---------- agents ----------


def _import_first(*candidates: str):
    """Round 136: try a list of `module:attr` candidates and
    return the first successful import. Returns None when none
    resolve so callers can fall back to a friendly empty
    response instead of crashing."""
    for cand in candidates:
        try:
            mod_name, _, attr = cand.partition(":")
            mod = __import__(mod_name, fromlist=[attr] if attr else [])
            if attr:
                return getattr(mod, attr, None)
            return mod
        except (ImportError, AttributeError):
            continue
    return None


def run_agents_subcommand(
    argv: list[str], *, workdir: Optional[Path] = None,
) -> SubcommandResult:
    """Round 136: `prometheus agents` — list cohort agent
    definitions. Subcommand mirrors `/cohorts` slash."""
    workdir = workdir or Path.cwd()
    discover = _import_first(
        "prometheus.agent.cohorts:discover_cohorts",
        "prometheus.cohorts:discover_cohorts",
    )
    if discover is None:
        return SubcommandResult(
            exit_code=0, output="no cohort agents discovered.",
        )
    try:
        cohorts = discover(workdir=workdir)
    except TypeError:
        try:
            cohorts = discover(workdir)
        except Exception as e:
            return SubcommandResult(
                exit_code=1,
                output=f"failed to discover cohorts: {e}",
            )
    except Exception as e:
        return SubcommandResult(
            exit_code=1, output=f"failed to discover cohorts: {e}",
        )
    if not cohorts:
        return SubcommandResult(
            exit_code=0, output="no cohort agents discovered.",
        )
    lines: list[str] = ["cohort agents:"]
    for c in cohorts:
        triggers = ", ".join(getattr(c, "triggers", []) or [])
        scope = getattr(c, "source", "?")
        lines.append(
            f"  {c.name:24s}  [{scope}]  {triggers or '—'}"
        )
    return SubcommandResult(exit_code=0, output="\n".join(lines))


# ---------- mcp ----------


def run_mcp_subcommand(
    argv: list[str], *, workdir: Optional[Path] = None,
) -> SubcommandResult:
    """Round 136: `prometheus mcp` — list MCP server
    connections."""
    workdir = workdir or Path.cwd()
    list_fn = _import_first(
        "prometheus.forge.mcp:list_mcp_servers",
        "prometheus.forge.mcp:discover_mcp_servers",
        "prometheus.mcp.registry:list_mcp_servers",
    )
    if list_fn is None:
        return SubcommandResult(
            exit_code=0, output="no MCP servers configured.",
        )
    try:
        servers = list_fn(workdir=workdir)
    except TypeError:
        try:
            servers = list_fn(workdir)
        except Exception as e:
            return SubcommandResult(
                exit_code=1,
                output=f"failed to list mcp servers: {e}",
            )
    except Exception as e:
        return SubcommandResult(
            exit_code=1, output=f"failed to list mcp servers: {e}",
        )
    if not servers:
        return SubcommandResult(
            exit_code=0, output="no MCP servers configured.",
        )
    lines: list[str] = ["mcp servers:"]
    for s in servers:
        cmd = getattr(s, "command", "?")
        scope = getattr(s, "source", "?")
        lines.append(f"  {s.name:24s}  [{scope}]  {cmd}")
    return SubcommandResult(exit_code=0, output="\n".join(lines))


# ---------- forge ----------


def run_forge_subcommand(
    argv: list[str], *, workdir: Optional[Path] = None,
) -> SubcommandResult:
    """Round 136: `prometheus forge` — list installed Forge Kits."""
    workdir = workdir or Path.cwd()
    discover = _import_first(
        "prometheus.forge.registry:discover_kits",
        "prometheus.forge.discovery:discover_kits",
        "prometheus.forge.registry:installed_kits",
    )
    if discover is None:
        # Try the round-100 ForgeRegistry shape directly.
        registry_cls = _import_first(
            "prometheus.forge.registry:ForgeRegistry",
        )
        if registry_cls is not None:
            try:
                reg = registry_cls(workdir)
                kits = (
                    reg.installed()
                    if hasattr(reg, "installed")
                    else getattr(reg, "kits", None) or []
                )
            except Exception as e:
                return SubcommandResult(
                    exit_code=1,
                    output=f"failed to discover kits: {e}",
                )
        else:
            return SubcommandResult(
                exit_code=0, output="no Forge Kits installed.",
            )
    else:
        try:
            kits = discover(workdir=workdir)
        except TypeError:
            try:
                kits = discover(workdir)
            except Exception as e:
                return SubcommandResult(
                    exit_code=1,
                    output=f"failed to discover kits: {e}",
                )
        except Exception as e:
            return SubcommandResult(
                exit_code=1, output=f"failed to discover kits: {e}",
            )
    if not kits:
        return SubcommandResult(
            exit_code=0, output="no Forge Kits installed.",
        )
    lines: list[str] = ["forge kits:"]
    for k in kits:
        components: list[str] = []
        for attr in ("aptitudes", "sentinels", "cohorts", "blades"):
            n = len(getattr(k, attr, []) or [])
            if n:
                components.append(f"{attr}={n}")
        ver = getattr(k, "version", "")
        cs = ", ".join(components) if components else "—"
        lines.append(f"  {k.name:24s}  v{ver or '0'}  {cs}")
    return SubcommandResult(exit_code=0, output="\n".join(lines))


# ---------- project purge ----------


def project_state_paths(workdir: Path) -> list[Path]:
    """Round 136: every project-scoped state path that
    `prometheus project purge` should remove."""
    return [
        workdir / ".prometheus",
        workdir / "PROMETHEUS.md",
        workdir / "CHARTER.md",
    ]


def run_project_subcommand(
    argv: list[str], *, workdir: Optional[Path] = None,
    confirm: bool = False,
) -> SubcommandResult:
    """Round 136: `prometheus project purge` — delete all
    project-scoped Prometheus state (charter, aptitudes, rules,
    memory, settings).

    Without `--yes`, prints what would be deleted and exits 0.
    With `--yes`, actually deletes."""
    sub = None
    for tok in argv[1:]:
        if not tok.startswith("-"):
            sub = tok
            break
    if sub != "purge":
        return SubcommandResult(
            exit_code=2,
            output="usage: prometheus project purge [--yes]",
        )
    yes = "--yes" in argv or confirm
    workdir = workdir or Path.cwd()
    targets = [p for p in project_state_paths(workdir) if p.exists()]
    if not targets:
        return SubcommandResult(
            exit_code=0,
            output=f"no project state in {workdir}.",
        )
    lines: list[str] = []
    if not yes:
        lines.append(
            f"would remove the following from {workdir}:"
        )
        for p in targets:
            lines.append(f"  {p}")
        lines.append("")
        lines.append("re-run with `--yes` to actually delete.")
        return SubcommandResult(exit_code=0, output="\n".join(lines))
    removed: list[str] = []
    errors: list[str] = []
    for p in targets:
        try:
            if p.is_dir():
                shutil.rmtree(p)
            else:
                p.unlink()
            removed.append(str(p))
        except OSError as e:
            errors.append(f"{p}: {e}")
    if errors:
        return SubcommandResult(
            exit_code=1,
            output=(
                "errors during purge:\n"
                + "\n".join(f"  {e}" for e in errors)
            ),
        )
    return SubcommandResult(
        exit_code=0,
        output=(
            f"purged {len(removed)} item(s) from {workdir}:\n"
            + "\n".join(f"  - {r}" for r in removed)
        ),
    )


# ---------- dispatch ----------


def run_auth_subcommand(argv: list[str]) -> SubcommandResult:
    """Round 138: `prometheus auth login|logout|status`."""
    from prometheus.auth import (
        parse_auth_argv, store_credential, clear_credential,
        auth_status,
    )
    action, provider = parse_auth_argv(argv)
    if action == "status":
        res = auth_status()
        return SubcommandResult(
            exit_code=0 if res.ok else 1, output=res.output,
        )
    if action == "logout":
        res = clear_credential(provider or None)
        return SubcommandResult(
            exit_code=0 if res.ok else 1, output=res.output,
        )
    if action == "login":
        if not provider:
            return SubcommandResult(
                exit_code=2,
                output="usage: prometheus auth login <provider>",
            )
        # Pull the key from PROMETHEUS_AUTH_KEY (CI/scripted)
        # so we don't block on an interactive prompt.
        import os
        key = os.environ.get("PROMETHEUS_AUTH_KEY", "").strip()
        if not key:
            return SubcommandResult(
                exit_code=1,
                output=(
                    "set PROMETHEUS_AUTH_KEY in your shell, then "
                    "re-run `prometheus auth login <provider>`. "
                    "Interactive prompt isn't supported in this "
                    "non-TTY mode."
                ),
            )
        res = store_credential(provider, key)
        return SubcommandResult(
            exit_code=0 if res.ok else 1, output=res.output,
        )
    return SubcommandResult(
        exit_code=2,
        output=(
            "usage: prometheus auth login <provider> | "
            "prometheus auth status | prometheus auth logout"
        ),
    )


def run_rc_subcommand(argv: list[str]) -> SubcommandResult:
    """Round 138: `prometheus rc` — remote-control launcher."""
    import os
    from prometheus.remote_control import (
        parse_rc_argv, new_session, render_pair_banner,
    )
    action, extras = parse_rc_argv(argv[1:] if argv else [])
    if action == "stop":
        return SubcommandResult(
            exit_code=0,
            output="rc: no active session in this process.",
        )
    port = int(extras.get("port", 0)) or 8765
    public_url = (
        str(extras.get("url", ""))
        or f"http://127.0.0.1:{port}"
    )
    sess = new_session(public_url=public_url, bridge_port=port)
    return SubcommandResult(
        exit_code=0, output=render_pair_banner(sess),
    )


def dispatch_subcommand(
    argv: list[str], *, workdir: Optional[Path] = None,
) -> SubcommandResult:
    """Round 136 + 138: route argv to the right subcommand."""
    head = first_nonflag(argv)
    if head == "agents":
        return run_agents_subcommand(argv, workdir=workdir)
    if head == "mcp":
        return run_mcp_subcommand(argv, workdir=workdir)
    if head == "forge":
        return run_forge_subcommand(argv, workdir=workdir)
    if head == "project":
        return run_project_subcommand(argv, workdir=workdir)
    if head == "auth":
        return run_auth_subcommand(argv)
    if head in ("rc", "remote-control"):
        return run_rc_subcommand(argv)
    # Round 142: bg-session subcommands.
    if head in ("ps", "logs", "attach", "kill"):
        return run_bg_subcommand(head, argv)
    # Round 143: install / update.
    if head in ("install", "update"):
        return run_pkg_subcommand(head, argv)
    # Round 144-final-v3: KAIROS daemon.
    if head == "daemon":
        from prometheus.kairos_daemon import dispatch_daemon_subcommand
        res = dispatch_daemon_subcommand(argv)
        return SubcommandResult(
            exit_code=res.exit_code, output=res.output,
        )
    # Round 151: prometheus config show
    if head == "config":
        return run_config_subcommand(argv)
    return SubcommandResult(
        exit_code=2,
        output=f"unknown subcommand: {head}",
    )


def run_config_subcommand(argv: list[str]) -> SubcommandResult:
    """Round 151: `prometheus config [show|edit|path]`.

    show — print effective settings (env-flag summary +
           settings.json keys).
    path — print the canonical settings.json path.
    edit — open settings.json in $EDITOR / notepad.
    """
    import os as _os
    import shutil as _sh
    import subprocess as _sp
    from pathlib import Path as _P
    sub = ""
    for tok in argv[1:]:
        if not tok.startswith("-") and tok != "config":
            sub = tok
            break
    sub = sub or "show"
    user_path = _P.home() / ".prometheus" / "settings.json"
    project_path = _P.cwd() / ".prometheus" / "settings.json"
    if sub == "path":
        return SubcommandResult(
            exit_code=0,
            output=(
                f"user-global:    {user_path}\n"
                f"project-shared: {project_path}"
            ),
        )
    if sub == "edit":
        editor = (
            _os.environ.get("VISUAL")
            or _os.environ.get("EDITOR")
            or ("notepad.exe" if _os.name == "nt" else "vi")
        )
        target = (
            project_path if project_path.exists()
            else user_path
        )
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            target.write_text("{}\n", encoding="utf-8")
        try:
            _sp.run(
                editor.split() + [str(target)],
                check=False, timeout=600,
            )
        except (OSError, _sp.TimeoutExpired) as e:
            return SubcommandResult(
                exit_code=1, output=f"editor failed: {e}",
            )
        return SubcommandResult(
            exit_code=0, output=f"edited {target}",
        )
    # show.
    lines: list[str] = []
    lines.append("config sources:")
    for label, p in (
        ("user-global", user_path),
        ("project-shared", project_path),
    ):
        glyph = "✓" if p.exists() else "·"
        lines.append(f"  {glyph} {label:14s}  {p}")
    # Env summary.
    flags = {
        k: v for k, v in _os.environ.items()
        if k.startswith("PROMETHEUS_") and v.strip()
    }
    lines.append("")
    lines.append(f"env flags ({len(flags)} set):")
    for k in sorted(flags.keys()):
        v = flags[k]
        if len(v) > 50:
            v = v[:47] + "…"
        lines.append(f"  {k}={v}")
    return SubcommandResult(
        exit_code=0, output="\n".join(lines),
    )


def run_pkg_subcommand(
    head: str, argv: list[str],
) -> SubcommandResult:
    """Round 143: pip-compatible install + update.

      `prometheus install <version>` → pip install
        prometheus-cli==<version>
      `prometheus install`           → pip install -U prometheus-cli
      `prometheus update`            → same as install with -U
    """
    import shutil as _sh
    import subprocess as _sp
    import sys as _sys
    target_version = ""
    for tok in argv[1:]:
        if not tok.startswith("-"):
            target_version = tok
            break
    pip_exe = _sh.which("pip") or _sh.which("pip3")
    if pip_exe is None:
        # Fall back to running pip as a module.
        pip_cmd = [_sys.executable, "-m", "pip"]
    else:
        pip_cmd = [pip_exe]
    install_args = list(pip_cmd) + ["install", "--upgrade"]
    if head == "install" and target_version:
        install_args = (
            list(pip_cmd) + ["install", f"prometheus-cli=={target_version}"]
        )
    else:
        install_args.append("prometheus-cli")
    # Surface the resolved command so users can copy-paste it.
    plan = " ".join(install_args)
    # Honor `--dry-run` so tests don't hit the network.
    if "--dry-run" in argv or "--plan" in argv:
        return SubcommandResult(
            exit_code=0,
            output=f"would run:  {plan}",
        )
    try:
        cp = _sp.run(
            install_args,
            capture_output=True, text=True,
            timeout=600, check=False,
        )
    except (OSError, _sp.TimeoutExpired) as e:
        return SubcommandResult(
            exit_code=1,
            output=f"install failed: {e}\n  command: {plan}",
        )
    out = (cp.stdout or "") + (cp.stderr or "")
    if cp.returncode != 0:
        return SubcommandResult(
            exit_code=cp.returncode,
            output=(
                f"install failed (exit {cp.returncode}):\n"
                f"  command: {plan}\n"
                f"  output:  {out.strip()[:600]}"
            ),
        )
    return SubcommandResult(
        exit_code=0,
        output=(
            f"{head} ok\n"
            f"  command: {plan}\n"
            + (
                f"  hint:    relaunch `prometheus` to pick up the new build."
            )
        ),
    )


def run_bg_subcommand(
    head: str, argv: list[str],
) -> SubcommandResult:
    """Round 142: dispatch to the bg_sessions module."""
    from prometheus.bg_sessions import (
        run_ps_subcommand, run_logs_subcommand,
        run_attach_subcommand, run_kill_subcommand,
    )
    target = ""
    for tok in argv:
        if tok.startswith("-") or tok == head:
            continue
        target = tok
        break
    if head == "ps":
        res = run_ps_subcommand()
    elif head == "logs":
        res = run_logs_subcommand(target)
    elif head == "attach":
        res = run_attach_subcommand(target)
    elif head == "kill":
        res = run_kill_subcommand(target)
    else:
        return SubcommandResult(
            exit_code=2,
            output=f"unknown bg subcommand: {head}",
        )
    return SubcommandResult(
        exit_code=res.exit_code, output=res.output,
    )
