"""Round 139: `/projects` — list and switch between Prometheus
projects.

A project is any directory with a `.prometheus/` subdir. We
maintain a registry at `~/.prometheus/projects.json` listing
known projects + last-accessed timestamps. The current workdir
is upserted on every launch.

Selection prints the resume hint; the host's slash command
opens a new session in that workdir.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass
class Project:
    name: str
    path: Path
    last_accessed: int          # unix seconds
    session_count: int = 0


def _store_path() -> Path:
    return Path.home() / ".prometheus" / "projects.json"


def _load() -> dict:
    p = _store_path()
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _save(data: dict) -> None:
    p = _store_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(
        json.dumps(data, indent=2, sort_keys=True),
        encoding="utf-8",
    )


def derive_project_name(path: Path) -> str:
    """Round 139: project name = workdir folder name."""
    try:
        return path.resolve().name or str(path)
    except OSError:
        return str(path)


def upsert_project(workdir: Path) -> Project:
    """Round 139: register or update the project for `workdir`."""
    data = _load()
    key = str(workdir.resolve())
    now = int(time.time())
    entry = data.get(key) or {}
    entry["name"] = entry.get("name") or derive_project_name(workdir)
    entry["path"] = key
    entry["last_accessed"] = now
    entry["session_count"] = int(entry.get("session_count", 0)) + 1
    data[key] = entry
    _save(data)
    return Project(
        name=str(entry["name"]),
        path=Path(entry["path"]),
        last_accessed=int(entry["last_accessed"]),
        session_count=int(entry["session_count"]),
    )


def list_projects() -> list[Project]:
    """Round 139: return registered projects, most-recently-used
    first."""
    data = _load()
    out: list[Project] = []
    for key, entry in data.items():
        if not isinstance(entry, dict):
            continue
        try:
            out.append(Project(
                name=str(entry.get("name") or key),
                path=Path(entry.get("path") or key),
                last_accessed=int(entry.get("last_accessed", 0)),
                session_count=int(entry.get("session_count", 0)),
            ))
        except (TypeError, ValueError):
            continue
    out.sort(key=lambda p: p.last_accessed, reverse=True)
    return out


def find_project(query: str) -> Optional[Project]:
    """Round 139: pick a project by name prefix, exact name, or
    path substring. Returns the most-recently-accessed match."""
    q = (query or "").strip().lower()
    if not q:
        return None
    matches: list[Project] = []
    for p in list_projects():
        if (
            p.name.lower() == q
            or p.name.lower().startswith(q)
            or q in str(p.path).lower()
        ):
            matches.append(p)
    return matches[0] if matches else None


def remove_project(query: str) -> Optional[Project]:
    """Round 139: drop a project from the registry."""
    target = find_project(query)
    if target is None:
        return None
    data = _load()
    key = str(target.path.resolve())
    if key in data:
        del data[key]
        _save(data)
    return target


def render_projects(rows: list[Project]) -> str:
    """Round 139: aligned table for the slash command."""
    if not rows:
        return (
            "no projects registered yet.\n"
            "  open a session in a project to register it."
        )
    out: list[str] = ["projects:"]
    for p in rows:
        ts = (
            time.strftime(
                "%Y-%m-%d %H:%M",
                time.localtime(p.last_accessed),
            )
            if p.last_accessed else "—"
        )
        out.append(
            f"  {p.name:24s}  {ts:16s}  "
            f"sessions={p.session_count:>3}  {p.path}"
        )
    out.append("")
    out.append("(use `/projects <name>` to switch)")
    return "\n".join(out)


def parse_projects_arg(arg: str) -> tuple[str, str]:
    """Round 139: parse `/projects [<sub>] [<target>]`.

    Returns (action, target). Actions:
      ""        — list
      "remove"  — drop a project
      "<name>"  — switch
    """
    raw = (arg or "").strip()
    if not raw:
        return ("list", "")
    parts = raw.split(maxsplit=1)
    head = parts[0].lower()
    if head == "remove":
        return ("remove", parts[1] if len(parts) > 1 else "")
    if head == "list":
        return ("list", "")
    return ("switch", raw)
