"""Round 137: settings schema for the new round-137 keys.

Nine new settings:

  * `spinnerVerbs`            customizable loading verbs
  * `attribution`             commit/PR attribution control
  * `fileCheckpointingEnabled` toggle pre-edit snapshots
  * `cleanupPeriodDays`       transcript retention
  * `modelOverrides`          per-skill / per-tool model swap
  * `respectGitignore`        @-mention completions filter
  * `includeGitInstructions`  built-in git workflow text
  * `network.allowedDomains` / `network.deniedDomains`
  * `filesystem.allowRead/allowWrite/denyRead/denyWrite`

All optional. Each loader returns a sensible default when the
key is absent, so users can add the keys piecemeal.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


# ---------- spinnerVerbs ----------


DEFAULT_SPINNER_VERBS: tuple[str, ...] = (
    "Aligning", "Analyzing", "Annotating", "Architecting",
    "Arranging", "Assembling", "Auditing", "Authoring",
    "Balancing", "Baking", "Binding", "Brainstorming",
    "Browsing", "Building", "Calibrating", "Capturing",
    "Cataloging", "Charting", "Checking", "Choosing",
    "Cleaning", "Climbing", "Coaching", "Coalescing",
    "Coding", "Collating", "Combing", "Comparing",
    "Compiling", "Composing", "Computing", "Conferring",
    "Configuring", "Connecting", "Consulting", "Cooking",
    "Coordinating", "Copying", "Crafting", "Cranking",
    "Crawling", "Creating", "Cross-referencing", "Cultivating",
    "Curating", "Cogitating", "Considering", "Contemplating",
    "Debating", "Deciding", "Decoding",
    "Defining", "Deliberating", "Delving", "Demystifying",
    "Designing", "Detecting", "Determining", "Developing",
    "Diagramming", "Digging", "Dispatching", "Distilling",
    "Diving", "Documenting", "Drafting", "Drawing",
    "Dreaming", "Driving", "Editing", "Elaborating",
    "Emerging", "Encoding", "Engineering", "Enhancing",
    "Enumerating", "Erecting", "Establishing", "Evaluating",
    "Examining", "Excavating", "Exploring", "Extracting",
    "Fabricating", "Fashioning", "Fathoming", "Filtering",
    "Finalizing", "Finding", "Fine-tuning", "Finishing",
    "Fixing", "Flexing", "Flying", "Focusing",
    "Forging", "Formulating", "Foraging", "Framing",
    "Gathering", "Generating", "Glancing", "Grinding",
    "Grokking", "Growing", "Guiding", "Hammering",
    "Hand-crafting", "Hardening", "Harmonizing", "Harvesting",
    "Hatching", "Heating", "Honing", "Humming",
    "Hunting", "Hustling", "Identifying", "Imagining",
    "Implementing", "Improvising", "Improving", "Inferring",
    "Initializing", "Inspecting", "Installing", "Integrating",
    "Interpreting", "Inventing", "Investigating", "Iterating",
    "Joining", "Joneing", "Journeying", "Juggling",
    "Kindling", "Knitting", "Laboring", "Labeling",
    "Laying", "Layering", "Lighting", "Linking",
    "Listing", "Locating", "Logging", "Mapping",
    "Marshalling", "Materializing", "Measuring", "Meditating",
    "Merging", "Mining", "Mobilizing", "Modeling",
    "Modulating", "Mulling", "Munching", "Musing", "Mustering",
    "Navigating", "Negotiating", "Networking", "Noodling",
    "Noting", "Observing", "Ordering", "Organizing",
    "Orienting", "Outlining", "Pacing", "Packing",
    "Painting", "Parsing", "Patrolling", "Pattern-matching",
    "Perceiving", "Performing", "Persisting", "Picking",
    "Piecing", "Pitching", "Plotting", "Plowing",
    "Pondering", "Polishing", "Polishing", "Powering",
    "Practicing", "Preparing", "Prioritizing", "Probing",
    "Processing", "Producing", "Profiling", "Programming",
    "Prospecting", "Pulling", "Pursuing", "Querying",
    "Questioning", "Quilting", "Reaching", "Reading",
    "Reasoning", "Reaping", "Reckoning", "Reconciling",
    "Recovering", "Reflecting", "Refining", "Refining",
    "Reformulating", "Rendering", "Repairing", "Researching",
    "Reshaping", "Resolving", "Restructuring", "Retrieving",
    "Reviewing", "Revising", "Routing", "Ruminating", "Sampling",
    "Sanding", "Scaling", "Scanning", "Scavenging",
    "Scheming", "Scoping", "Sculpting", "Searching",
    "Seeking", "Selecting", "Sequencing", "Setting",
    "Shaping", "Sharpening", "Shipping", "Showing",
    "Sifting", "Simulating", "Sketching", "Skipping",
    "Smelting", "Smithing", "Smoothing", "Sorting",
    "Sourcing", "Spinning", "Splitting", "Stacking",
    "Stitching", "Storing", "Strategizing", "Streamlining",
    "Stretching", "Striving", "Structuring", "Studying",
    "Stumbling", "Subdividing", "Summarizing", "Surveying",
    "Synthesizing", "Tackling", "Tapping", "Taking",
    "Tasting", "Templating", "Tempering", "Testing",
    "Thinking", "Threading", "Tinkering", "Toggling",
    "Tossing", "Tracing", "Tracking", "Translating",
    "Transmuting", "Trekking", "Trying", "Tuning",
    "Tweaking", "Unboxing", "Uncovering", "Understanding",
    "Unraveling", "Unwinding", "Updating", "Validating",
    "Varifying", "Verifying", "Visualizing", "Walking",
    "Wandering", "Watching", "Weaving", "Weighing",
    "Welding", "Whittling", "Winnowing", "Wiring",
    "Wondering", "Woodworking", "Working", "Wrangling",
    "Writing", "Yielding", "Zapping",
)


def resolve_spinner_verbs(
    setting: Optional[Any] = None,
) -> list[str]:
    """Round 137: resolve `spinnerVerbs`.

    Schema:
      "spinnerVerbs": "x" | ["a","b"]
        legacy form — replaces the default list
      "spinnerVerbs": {"mode": "replace"|"append", "verbs": [...]}
        replace: use only the supplied verbs
        append:  default + the supplied verbs
    """
    base = list(DEFAULT_SPINNER_VERBS)
    if setting is None:
        return base
    if isinstance(setting, list):
        verbs = [str(v).strip() for v in setting if str(v).strip()]
        return verbs or base
    if isinstance(setting, str):
        v = setting.strip()
        return [v] if v else base
    if isinstance(setting, dict):
        mode = str(setting.get("mode", "append")).lower()
        verbs = setting.get("verbs", []) or []
        if isinstance(verbs, list):
            verbs = [str(v).strip() for v in verbs if str(v).strip()]
        else:
            verbs = []
        if mode == "replace":
            return verbs or base
        if mode == "append":
            return base + verbs
    return base


# ---------- attribution ----------


@dataclass
class AttributionConfig:
    commit: bool = True
    pr: bool = True


def resolve_attribution(setting: Optional[Any]) -> AttributionConfig:
    """Round 137: defaults to all-on. Both fields can be
    independently disabled."""
    if not isinstance(setting, dict):
        return AttributionConfig()
    return AttributionConfig(
        commit=bool(setting.get("commit", True)),
        pr=bool(setting.get("pr", True)),
    )


# ---------- fileCheckpointingEnabled ----------


def file_checkpointing_enabled(
    setting: Optional[Any], *, default: bool = True,
) -> bool:
    """Round 137: defaults to True."""
    if setting is None:
        return default
    if isinstance(setting, bool):
        return setting
    if isinstance(setting, str):
        return setting.strip().lower() in ("1", "true", "yes", "on")
    return default


# ---------- cleanupPeriodDays ----------


def resolve_cleanup_period_days(
    setting: Optional[Any], *, default: int = 90,
) -> int:
    """Round 137: 0 = never auto-delete. Negative is treated
    as default."""
    if setting is None:
        return default
    try:
        n = int(setting)
    except (TypeError, ValueError):
        return default
    if n < 0:
        return default
    return n


# ---------- modelOverrides ----------


def resolve_model_overrides(
    setting: Optional[Any],
) -> dict[str, str]:
    """Round 137: maps skill/tool name → model id (or alias).
    Returns {} when missing or malformed."""
    if not isinstance(setting, dict):
        return {}
    out: dict[str, str] = {}
    for k, v in setting.items():
        if not isinstance(k, str) or not isinstance(v, str):
            continue
        if k.strip() and v.strip():
            out[k.strip()] = v.strip()
    return out


# ---------- respectGitignore ----------


def respect_gitignore(
    setting: Optional[Any], *, default: bool = True,
) -> bool:
    if setting is None:
        return default
    if isinstance(setting, bool):
        return setting
    if isinstance(setting, str):
        return setting.strip().lower() in ("1", "true", "yes", "on")
    return default


# ---------- includeGitInstructions ----------


def include_git_instructions(
    setting: Optional[Any], *, default: bool = True,
) -> bool:
    """Round 137: env override `PROMETHEUS_DISABLE_GIT_INSTRUCTIONS=1`
    forces False regardless of the setting value."""
    import os
    if os.environ.get(
        "PROMETHEUS_DISABLE_GIT_INSTRUCTIONS", "",
    ).strip().lower() in ("1", "true", "yes"):
        return False
    if setting is None:
        return default
    if isinstance(setting, bool):
        return setting
    if isinstance(setting, str):
        return setting.strip().lower() in ("1", "true", "yes", "on")
    return default


# ---------- network.* ----------


@dataclass
class NetworkPolicy:
    allowed: list[str] = field(default_factory=list)
    denied: list[str] = field(default_factory=list)


def resolve_network_policy(setting: Optional[Any]) -> NetworkPolicy:
    """Round 137: read `network` settings sub-tree."""
    if not isinstance(setting, dict):
        return NetworkPolicy()
    allow = setting.get("allowedDomains", [])
    deny = setting.get("deniedDomains", [])
    if not isinstance(allow, list):
        allow = []
    if not isinstance(deny, list):
        deny = []
    return NetworkPolicy(
        allowed=[str(d).strip().lower() for d in allow if str(d).strip()],
        denied=[str(d).strip().lower() for d in deny if str(d).strip()],
    )


def network_decision(
    domain: str, policy: NetworkPolicy,
) -> tuple[bool, str]:
    """Round 137: domain-based gate. Deny wins ties.

    Empty allowlist + empty denylist → allow everything.
    Non-empty allowlist → only those (subdomain match).
    Non-empty denylist  → block those.
    Both → deny wins, then allowlist applies.
    """
    d = (domain or "").strip().lower()
    if not d:
        return (False, "empty domain")
    for blocked in policy.denied:
        if d == blocked or d.endswith("." + blocked):
            return (False, f"matches deniedDomains: {blocked}")
    if not policy.allowed:
        return (True, "no allowlist; permitted by default")
    for allowed in policy.allowed:
        if d == allowed or d.endswith("." + allowed):
            return (True, f"matches allowedDomains: {allowed}")
    return (False, "not in allowedDomains")


# ---------- filesystem.* ----------


@dataclass
class FilesystemPolicy:
    allow_read: list[str] = field(default_factory=list)
    allow_write: list[str] = field(default_factory=list)
    deny_read: list[str] = field(default_factory=list)
    deny_write: list[str] = field(default_factory=list)


def resolve_filesystem_policy(
    setting: Optional[Any],
) -> FilesystemPolicy:
    if not isinstance(setting, dict):
        return FilesystemPolicy()

    def _list_field(key: str) -> list[str]:
        v = setting.get(key, [])
        if not isinstance(v, list):
            return []
        return [str(p).strip() for p in v if str(p).strip()]

    return FilesystemPolicy(
        allow_read=_list_field("allowRead"),
        allow_write=_list_field("allowWrite"),
        deny_read=_list_field("denyRead"),
        deny_write=_list_field("denyWrite"),
    )


def filesystem_decision(
    path: str, policy: FilesystemPolicy, *, op: str = "read",
) -> tuple[bool, str]:
    """Round 137: path-based gate. `op` is `read` or `write`."""
    if not path:
        return (False, "empty path")
    norm = path.replace("\\", "/").lower()
    if op == "write":
        deny_list = policy.deny_write
        allow_list = policy.allow_write
    else:
        deny_list = policy.deny_read
        allow_list = policy.allow_read
    for pat in deny_list:
        if _path_match(norm, pat.lower()):
            return (False, f"matches deny{op.capitalize()}: {pat}")
    if not allow_list:
        return (True, f"no allow{op.capitalize()} list; permitted")
    for pat in allow_list:
        if _path_match(norm, pat.lower()):
            return (True, f"matches allow{op.capitalize()}: {pat}")
    return (False, f"not in allow{op.capitalize()}")


def _path_match(path: str, pat: str) -> bool:
    """Round 137: lightweight path match. Treats `**` as
    multi-segment wildcard, `*` as single-segment, exact prefix
    otherwise."""
    if not pat:
        return False
    if pat.endswith("/**"):
        prefix = pat[:-3]
        return path.startswith(prefix)
    if "**" in pat:
        head, _, tail = pat.partition("**")
        return path.startswith(head) and path.endswith(tail)
    if "*" in pat:
        import fnmatch
        return fnmatch.fnmatch(path, pat)
    return path.startswith(pat)
