"""Round 183: offline-mode helper.

When `PROMETHEUS_OFFLINE=1` is set (or the user passed `--offline`
to `prometheus`), every network-requiring tool refuses early with a
clean message rather than letting the user wait for a 30-second
socket timeout. The LLM provider is NOT gated by this flag — running
offline against a network-required upstream is the operator's
responsibility (set `--base-url` to a local LLM if needed).

This is the equivalent of:
  - Aider's `--offline` flag (https://aider.chat/docs/llms.html)
  - Codex CLI sandbox `disable-network` policy
  - OpenDevin's `disable-network` runtime config

Required for air-gapped enterprise environments and CI sandboxes
where outbound HTTPS to public registries / search engines is
explicitly blocked.
"""
from __future__ import annotations

import os


def is_offline() -> bool:
    """Return True if offline mode is active.

    Honours `PROMETHEUS_OFFLINE` (any truthy value) — the canonical
    env var. Re-read on every call so a runtime `/offline on` slash
    command can flip the flag without restarting."""
    val = os.environ.get("PROMETHEUS_OFFLINE", "").strip().lower()
    return val in ("1", "true", "yes", "on")


def offline_refusal_text(tool_name: str) -> str:
    """Standard refusal message used by every network-requiring tool
    when offline mode is active. Tool name is included so the user
    can quickly grep their session log to see what hit the wall."""
    return (
        f"refused: {tool_name} requires network access, but "
        f"PROMETHEUS_OFFLINE=1 is set. "
        f"Run with --offline=false or unset the env var to enable "
        f"network tools, or answer from local repo content."
    )
