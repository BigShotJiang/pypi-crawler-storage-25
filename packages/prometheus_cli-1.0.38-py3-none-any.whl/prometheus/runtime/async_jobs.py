"""Background agent jobs — long-horizon turns the user kicks off and walks away from.

Each `AsyncJob` owns a fresh isolated `AgentLoop` instance running a
single user message to completion. Output accumulates in a ring buffer
identical to BgJob (bash). When the job finishes, a notification is
posted to the user's chat the next time they interact OR a one-shot
desktop bell rings (the existing _arm_idle_bell path).

Surface in the UI:
    /async <prompt>       — start a job; user gets back the job id
    /jobs                 — list active + recent jobs
    /jobs <id>            — show full transcript of a finished job
    /jobs kill <id>       — cancel a running job
    /jobs results <id>    — append the job's final reply to the chat

Cost is tracked per-job (via the same usage events the foreground loop
sees); the daily-spend cap applies. A user can have at most
MAX_CONCURRENT async jobs; further /async submissions error politely.

NOT a cloud feature — it runs locally. Cursor's hosted long-running
agents need a paid backend we don't have. This gives users the same
"detach this and walk away" workflow on their own machine.
"""
from __future__ import annotations

import asyncio
import time
import uuid
from dataclasses import dataclass, field
from typing import Any


MAX_CONCURRENT = 4
MAX_OUTPUT_CHARS = 80_000


@dataclass
class AsyncJob:
    job_id: str
    prompt: str
    started_at: float
    text_buf: list[str] = field(default_factory=list)
    finished: bool = False
    error: str | None = None
    final_text: str = ""
    cost_usd: float = 0.0
    tokens_in: int = 0
    tokens_out: int = 0
    task: asyncio.Task | None = None

    @property
    def elapsed_s(self) -> int:
        return int(time.monotonic() - self.started_at)

    @property
    def status(self) -> str:
        if self.finished and self.error:
            return "failed"
        if self.finished:
            return "done"
        return "running"

    def tail(self, n_chars: int = MAX_OUTPUT_CHARS) -> str:
        joined = "".join(self.text_buf)
        return joined[-n_chars:]


class AsyncJobs:
    """Process-wide registry — owned by the App. Singleton-ish."""

    def __init__(self) -> None:
        self.jobs: dict[str, AsyncJob] = {}
        self._counter = 0

    def _new_id(self) -> str:
        self._counter += 1
        return f"a{self._counter}"

    def active_count(self) -> int:
        return sum(1 for j in self.jobs.values() if not j.finished)

    def list(self) -> list[AsyncJob]:
        return list(self.jobs.values())

    def get(self, job_id: str) -> AsyncJob | None:
        return self.jobs.get(job_id)

    async def submit(
        self,
        prompt: str,
        agent_factory: Any,
        on_done: Any = None,
    ) -> AsyncJob | None:
        """agent_factory is a callable returning a fresh AgentLoop. We
        run agent_factory().run(prompt) in the background, accumulate
        text+usage, and notify on_done when the iterator drains.
        Returns the new job, or None if the concurrency cap is hit."""
        if self.active_count() >= MAX_CONCURRENT:
            return None
        job = AsyncJob(
            job_id=self._new_id(),
            prompt=prompt,
            started_at=time.monotonic(),
        )
        self.jobs[job.job_id] = job

        async def _run() -> None:
            try:
                agent = agent_factory()
                async for ev in agent.run(prompt):
                    if ev.kind == "text" and ev.text:
                        job.text_buf.append(ev.text)
                        # Cap accumulated text.
                        if sum(len(s) for s in job.text_buf) > MAX_OUTPUT_CHARS:
                            joined = "".join(job.text_buf)
                            job.text_buf = [joined[-MAX_OUTPUT_CHARS:]]
                    elif ev.kind == "final" and ev.text:
                        job.final_text = ev.text
                    elif ev.kind == "usage" and ev.usage:
                        job.tokens_in += int(ev.usage.get("prompt_tokens", 0) or 0)
                        job.tokens_out += int(ev.usage.get("completion_tokens", 0) or 0)
                        try:
                            job.cost_usd += float(ev.usage.get("cost", 0) or 0)
                        except (TypeError, ValueError):
                            pass
                    elif ev.kind == "error":
                        job.error = ev.error
                    elif ev.kind == "halt":
                        job.error = ev.error
                if not job.final_text:
                    job.final_text = "".join(job.text_buf).strip()
            except asyncio.CancelledError:
                job.error = "cancelled"
                raise
            except Exception as e:
                job.error = f"{type(e).__name__}: {e}"
            finally:
                job.finished = True
                if on_done is not None:
                    try:
                        on_done(job)
                    except Exception:
                        pass

        job.task = asyncio.create_task(_run())
        return job

    async def kill(self, job_id: str) -> bool:
        job = self.jobs.get(job_id)
        if job is None:
            return False
        if job.task and not job.task.done():
            job.task.cancel()
            try:
                await asyncio.wait_for(job.task, timeout=3)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                pass
        return True

    async def shutdown_all(self) -> None:
        """App is exiting — cancel everything."""
        for job in list(self.jobs.values()):
            if job.task and not job.task.done():
                job.task.cancel()
        await asyncio.gather(
            *(j.task for j in self.jobs.values() if j.task is not None),
            return_exceptions=True,
        )

    def reap(self, ttl_s: int = 600) -> int:
        """Drop finished jobs older than ttl_s."""
        now = time.monotonic()
        keep = {
            jid: j for jid, j in self.jobs.items()
            if not j.finished or (now - j.started_at) < ttl_s
        }
        n = len(self.jobs) - len(keep)
        self.jobs = keep
        return n
