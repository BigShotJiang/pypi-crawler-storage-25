"""Background bash registry — supports Ctrl+B handoff and /bashes listing.

Process model:
- A foreground bash via run_bash returns its asyncio.subprocess handle to
  this registry on demand (when the user hits Ctrl+B mid-run).
- The registry assigns a short id (b1, b2, …), keeps reading stdout into
  a ring buffer, and lets `/bashes` list them, `/bashes <id>` show output,
  `/kill-bash <id>` terminate.

The registry is a process-wide singleton owned by the App; it's safe
because a Textual app is single-process.
"""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class BgJob:
    job_id: str
    cmd: str
    proc: asyncio.subprocess.Process
    started_at: float
    output: list[str] = field(default_factory=list)
    finished: bool = False
    exit_code: Optional[int] = None
    reader_task: Optional[asyncio.Task] = None
    # Byte offset into the joined output that was already shown to
    # the model. bash_output reads from this and updates it so each
    # poll returns ONLY new output, not the entire history.
    read_cursor: int = 0

    @property
    def elapsed(self) -> int:
        return int(time.monotonic() - self.started_at)

    def tail(self, n_chars: int = 4000) -> str:
        joined = "".join(self.output)
        return joined[-n_chars:]

    def read_new(self, max_chars: int = 16_000) -> str:
        """Return output appended since the last call. Updates the cursor.

        Snapshot the chunks list ATOMICALLY before joining so the
        reader_task's appends can't race the cursor update (round-11
        audit P0: previously len(joined) referred to a different list
        state than the slice that produced `new`, leading to skipped or
        duplicated bytes).
        """
        snapshot = tuple(self.output)
        joined = "".join(snapshot)
        new = joined[self.read_cursor:]
        self.read_cursor = len(joined)
        if len(new) > max_chars:
            # Reserve room for the elision banner so the final string
            # never exceeds max_chars (audit P1: previously the banner
            # was added AFTER the head/tail split and could push total
            # length over the cap).
            banner_template = "\n…[%d chars elided]\n"
            banner = banner_template % len(new)  # placeholder length
            available = max(64, max_chars - len(banner))
            head_n = available // 4
            tail_n = available - head_n
            return new[:head_n] + banner + new[-tail_n:]
        return new


class BackgroundJobs:
    def __init__(self) -> None:
        self.jobs: dict[str, BgJob] = {}
        self._counter = 0

    def next_id(self) -> str:
        self._counter += 1
        return f"b{self._counter}"

    def adopt(self, cmd: str, proc: asyncio.subprocess.Process) -> BgJob:
        """Take ownership of an in-flight subprocess and start a reader."""
        job_id = self.next_id()
        job = BgJob(job_id=job_id, cmd=cmd, proc=proc, started_at=time.monotonic())
        self.jobs[job_id] = job

        async def _reader() -> None:
            assert proc.stdout
            try:
                while True:
                    chunk = await proc.stdout.read(4096)
                    if not chunk:
                        break
                    job.output.append(chunk.decode("utf-8", "replace"))
                    # Cap memory: keep last 200 chunks.
                    if len(job.output) > 200:
                        job.output = job.output[-200:]
            except Exception:
                pass
            finally:
                job.exit_code = await proc.wait()
                job.finished = True

        job.reader_task = asyncio.create_task(_reader())
        return job

    def list(self) -> list[BgJob]:
        return list(self.jobs.values())

    def get(self, job_id: str) -> BgJob | None:
        return self.jobs.get(job_id)

    async def kill(self, job_id: str) -> bool:
        job = self.jobs.get(job_id)
        if not job:
            return False
        if not job.finished:
            try:
                job.proc.kill()
                await asyncio.wait_for(job.proc.wait(), timeout=3)
            except Exception:
                pass
        return True

    def reap(self) -> int:
        """Drop entries that finished more than 60s ago."""
        now = time.monotonic()
        keep = {
            jid: job for jid, job in self.jobs.items()
            if not job.finished or (now - (job.started_at + job.elapsed)) < 60
        }
        n_dropped = len(self.jobs) - len(keep)
        self.jobs = keep
        return n_dropped
