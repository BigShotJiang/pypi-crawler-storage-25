"""Runtime singletons used across tools and UI: background-bash registry, etc."""
from prometheus.runtime.bashes import BackgroundJobs

__all__ = ["BackgroundJobs"]
