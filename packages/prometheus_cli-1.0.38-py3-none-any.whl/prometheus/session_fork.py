"""Round 137: `--fork-session` and `--from-pr` helpers.

`--fork-session <id>` clones an existing session at its current
state and starts a fresh one. The new session inherits
messages + state but writes under a new id so the original
isn't mutated.

`--from-pr <number>` searches the session store for a session
linked to that PR — either via the round-131 review machinery
that stamps `pr` into session metadata, or by scanning recent
sessions whose label/branch references the number.

Pure data layer. The runtime calls these from the launch path.
"""
from __future__ import annotations

import re
import time
import uuid
from dataclasses import dataclass
from typing import Any, Optional


_PR_SESSION_LABEL_RX = re.compile(r"\bpr[-/_# ]*(\d+)\b", re.I)


@dataclass
class ForkResult:
    """Round 137: outcome of `--fork-session`."""
    new_session_id: str
    source_session_id: str
    message_count: int


def _gen_session_id() -> str:
    return str(uuid.uuid4())


def fork_session(
    *,
    source_id: str,
    store: Any,
) -> Optional[ForkResult]:
    """Round 137: clone source_id → new_session_id in the
    SQLite session store. Returns None when the source
    doesn't resolve.

    The store is duck-typed (matches round-95 SessionStore)
    — works against any object with `get_messages`, `start`,
    `add_message`, `load_state`, `save_state`."""
    if not source_id:
        return None
    try:
        msgs = store.get_messages(source_id)
    except Exception:
        return None
    if not msgs:
        return None
    new_id = _gen_session_id()
    label = f"forked from {source_id[:8]}"
    try:
        store.start(
            new_id,
            getattr(store, "default_model", "auto/free"),
            getattr(store, "default_workdir", ""),
            label=label,
        )
    except TypeError:
        # Older store signatures; try positional only.
        try:
            store.start(new_id)
        except Exception:
            return None
    except Exception:
        return None
    for m in msgs:
        try:
            store.add_message(
                new_id,
                m.get("role", "user"),
                str(m.get("content", "")),
            )
        except Exception:
            continue
    state: dict = {}
    try:
        loaded = store.load_state(source_id)
        if isinstance(loaded, dict):
            state = loaded
    except Exception:
        pass
    if state:
        try:
            store.save_state(new_id, state)
        except Exception:
            pass
    return ForkResult(
        new_session_id=new_id,
        source_session_id=source_id,
        message_count=len(msgs),
    )


# ---------- --from-pr ----------


def _label_for_pr(pr_number: int, label: str) -> bool:
    if not label:
        return False
    m = _PR_SESSION_LABEL_RX.search(label)
    if not m:
        return False
    try:
        return int(m.group(1)) == pr_number
    except ValueError:
        return False


def find_session_for_pr(
    *,
    pr_number: int,
    sessions: list[dict[str, Any]],
) -> Optional[dict[str, Any]]:
    """Round 137: walk a list of session metadata rows looking
    for one tagged with `pr_number`. The list is duck-typed
    against the round-95 session store's `list_sessions()`
    output: each row has `session_id`, `label`, `started_at`,
    optionally `pr` and `branch`."""
    if pr_number <= 0:
        return None
    matches: list[dict[str, Any]] = []
    for row in sessions:
        if not isinstance(row, dict):
            continue
        try:
            row_pr = int(row.get("pr") or 0)
        except (TypeError, ValueError):
            row_pr = 0
        if row_pr == pr_number:
            matches.append(row)
            continue
        if _label_for_pr(pr_number, str(row.get("label") or "")):
            matches.append(row)
            continue
        if _label_for_pr(pr_number, str(row.get("branch") or "")):
            matches.append(row)
            continue
    if not matches:
        return None
    matches.sort(
        key=lambda r: r.get("started_at", 0) or 0,
        reverse=True,
    )
    return matches[0]


def render_fork_banner(res: ForkResult) -> str:
    return (
        f"forked session\n"
        f"  source: {res.source_session_id}\n"
        f"  new:    {res.new_session_id}\n"
        f"  copied: {res.message_count} messages"
    )


def render_from_pr_banner(
    pr_number: int, session: Optional[dict[str, Any]],
) -> str:
    if session is None:
        return f"no session linked to PR #{pr_number}"
    sid = str(session.get("session_id", "?"))
    label = str(session.get("label", "")) or "(no label)"
    return (
        f"resuming PR-#{pr_number} session\n"
        f"  session: {sid[:16]}\n"
        f"  label:   {label}"
    )
