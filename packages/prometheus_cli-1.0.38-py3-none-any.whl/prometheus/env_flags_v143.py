"""Round 143: env-var gap closure (16 new flags).

  Task 1 — DISABLE flags:
    PROMETHEUS_DISABLE_AUTOUPDATER
    PROMETHEUS_DISABLE_ERROR_REPORTING
    PROMETHEUS_DISABLE_TELEMETRY
    PROMETHEUS_DISABLE_FEEDBACK_COMMAND   (round 139 — re-export)
    PROMETHEUS_DISABLE_NONESSENTIAL_TRAFFIC (composite — sets all four)
    PROMETHEUS_DISABLE_AUTO_COMPACT
    PROMETHEUS_DISABLE_ALL_HOOKS

  Task 2 — Compaction & thinking:
    PROMETHEUS_AUTOCOMPACT_PCT (round 142 — accessor here for parity)
    PROMETHEUS_DISABLE_ADAPTIVE_THINKING
    PROMETHEUS_DISABLE_INTERLEAVED_THINKING

  Task 3 — Runtime overrides:
    PROMETHEUS_OVERRIDE_DATE
    PROMETHEUS_MAX_CONTEXT_TOKENS
    PROMETHEUS_EXTRA_BODY
    PROMETHEUS_DONT_INHERIT_ENV

  Task 4 — Performance / debug:
    PROMETHEUS_PERFETTO_TRACE
    PROMETHEUS_PROFILE_STARTUP
    PROMETHEUS_DEBUG_REPAINTS
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Optional


_TRUTHY = ("1", "true", "yes", "on")


def _flag(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in _TRUTHY


# ---------- Task 1: DISABLE flags ----------


def autoupdater_disabled() -> bool:
    return _flag("PROMETHEUS_DISABLE_AUTOUPDATER")


def error_reporting_disabled() -> bool:
    return _flag("PROMETHEUS_DISABLE_ERROR_REPORTING")


def telemetry_disabled() -> bool:
    return _flag("PROMETHEUS_DISABLE_TELEMETRY")


def feedback_command_disabled() -> bool:
    """Round 139 already shipped this; re-export keeps the
    surface coherent."""
    from prometheus.timeouts import feedback_disabled
    return feedback_disabled()


def nonessential_traffic_disabled() -> bool:
    """Round 143: composite flag — when set, every individual
    nonessential traffic disabler returns True.

    Per-flag explicit disables still win when set explicitly,
    so users can opt out of the composite at the per-flag
    level."""
    return _flag("PROMETHEUS_DISABLE_NONESSENTIAL_TRAFFIC")


def effective_autoupdater_disabled() -> bool:
    return autoupdater_disabled() or nonessential_traffic_disabled()


def effective_error_reporting_disabled() -> bool:
    return (
        error_reporting_disabled()
        or nonessential_traffic_disabled()
    )


def effective_telemetry_disabled() -> bool:
    return telemetry_disabled() or nonessential_traffic_disabled()


def effective_feedback_disabled() -> bool:
    return (
        feedback_command_disabled()
        or nonessential_traffic_disabled()
    )


def auto_compact_disabled() -> bool:
    return _flag("PROMETHEUS_DISABLE_AUTO_COMPACT")


def all_hooks_disabled() -> bool:
    """Round 143: emergency kill-switch for every Sentinel."""
    return _flag("PROMETHEUS_DISABLE_ALL_HOOKS")


# ---------- Task 2: compaction & thinking ----------


def autocompact_pct() -> int:
    """Round 143: re-export of the round-142 accessor for
    a single import surface."""
    from prometheus.env_flags_v142 import autocompact_pct as _pct
    return _pct()


def adaptive_thinking_disabled() -> bool:
    return _flag("PROMETHEUS_DISABLE_ADAPTIVE_THINKING")


def interleaved_thinking_disabled() -> bool:
    return _flag("PROMETHEUS_DISABLE_INTERLEAVED_THINKING")


# ---------- Task 3: runtime overrides ----------


_DATE_RX = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def override_date() -> Optional[str]:
    """Round 143: deterministic-test date injection. Returns
    None when unset or malformed; YYYY-MM-DD string otherwise."""
    raw = os.environ.get("PROMETHEUS_OVERRIDE_DATE", "").strip()
    if not raw:
        return None
    if not _DATE_RX.match(raw):
        return None
    try:
        # Validate roundtrip.
        datetime.strptime(raw, "%Y-%m-%d")
        return raw
    except ValueError:
        return None


def effective_today() -> str:
    """Round 143: today's date with override honored."""
    od = override_date()
    if od:
        return od
    return datetime.utcnow().strftime("%Y-%m-%d")


def max_context_tokens() -> Optional[int]:
    """Round 143: hard override for the context window. None
    when unset (use the model's reported window)."""
    raw = os.environ.get(
        "PROMETHEUS_MAX_CONTEXT_TOKENS", "",
    ).strip()
    if not raw:
        return None
    try:
        n = int(raw)
        return max(1024, n)
    except ValueError:
        return None


def extra_body() -> dict[str, Any]:
    """Round 143: parsed JSON dict to merge into provider
    requests. Returns {} on parse failure or when unset."""
    raw = os.environ.get("PROMETHEUS_EXTRA_BODY", "").strip()
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    if not isinstance(data, dict):
        return {}
    return data


def dont_inherit_env() -> bool:
    """Round 143: subprocess launches start from a clean env."""
    return _flag("PROMETHEUS_DONT_INHERIT_ENV")


def filter_subprocess_env(env: dict) -> dict:
    """Round 143: when `dont_inherit_env()` is True, project
    the env down to a minimal baseline so the child doesn't
    receive unrelated parent vars."""
    if not dont_inherit_env():
        return env
    keep = {
        "PATH", "HOME", "USERPROFILE", "TEMP", "TMP",
        "LANG", "LC_ALL", "TZ", "SHELL", "COMSPEC",
        # Pass through PrometheUS-internal flags so child
        # cohorts see the same configuration.
    }
    out: dict = {}
    for k, v in env.items():
        if k in keep or k.startswith("PROMETHEUS_"):
            out[k] = v
    return out


# ---------- Task 4: performance / debug ----------


def perfetto_trace_path() -> Optional[Path]:
    raw = os.environ.get("PROMETHEUS_PERFETTO_TRACE", "").strip()
    if not raw:
        return None
    return Path(raw).expanduser()


def append_perfetto_event(
    *, kind: str, ts_us: float, detail: str = "",
) -> bool:
    """Round 143: append one trace event in a minimal Chrome-
    trace-compatible JSON-line format. Returns True on success.
    """
    p = perfetto_trace_path()
    if p is None:
        return False
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps({
            "name": kind,
            "ph": "i",
            "ts": ts_us,
            "pid": os.getpid(),
            "args": {"detail": detail} if detail else {},
        })
        with p.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
        return True
    except OSError:
        return False


def profile_startup_enabled() -> bool:
    return _flag("PROMETHEUS_PROFILE_STARTUP")


def debug_repaints_enabled() -> bool:
    return _flag("PROMETHEUS_DEBUG_REPAINTS")


# ---------- consolidated summary ----------


@dataclass
class V143Summary:
    autoupdater_disabled: bool
    error_reporting_disabled: bool
    telemetry_disabled: bool
    feedback_disabled: bool
    nonessential_traffic_disabled: bool
    auto_compact_disabled: bool
    all_hooks_disabled: bool
    autocompact_pct: int
    adaptive_thinking_disabled: bool
    interleaved_thinking_disabled: bool
    override_date: Optional[str]
    max_context_tokens: Optional[int]
    extra_body_keys: list[str]
    dont_inherit_env: bool
    perfetto_trace_path: Optional[str]
    profile_startup_enabled: bool
    debug_repaints_enabled: bool


def env_flag_summary_v143() -> V143Summary:
    pp = perfetto_trace_path()
    return V143Summary(
        autoupdater_disabled=effective_autoupdater_disabled(),
        error_reporting_disabled=effective_error_reporting_disabled(),
        telemetry_disabled=effective_telemetry_disabled(),
        feedback_disabled=effective_feedback_disabled(),
        nonessential_traffic_disabled=
            nonessential_traffic_disabled(),
        auto_compact_disabled=auto_compact_disabled(),
        all_hooks_disabled=all_hooks_disabled(),
        autocompact_pct=autocompact_pct(),
        adaptive_thinking_disabled=adaptive_thinking_disabled(),
        interleaved_thinking_disabled=
            interleaved_thinking_disabled(),
        override_date=override_date(),
        max_context_tokens=max_context_tokens(),
        extra_body_keys=list(extra_body().keys()),
        dont_inherit_env=dont_inherit_env(),
        perfetto_trace_path=str(pp) if pp else None,
        profile_startup_enabled=profile_startup_enabled(),
        debug_repaints_enabled=debug_repaints_enabled(),
    )
