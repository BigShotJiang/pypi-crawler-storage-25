"""Round 143-final-v3: speculation system.

After each agent response, generate a "next suggested
action" prompt and start a forked Cohort agent in background
that begins executing the suggestion against a copy-on-write
file overlay. If the user accepts, the overlay is committed
to the real filesystem; if rejected, the overlay is
discarded.

Pure data layer:
  * `Suggestion` — what the model proposed
  * `Speculation` — running speculation state
  * `OverlayStore` — COW file staging area at
    `~/.prometheus/tmp/speculation/<pid>/<id>/`

Constraints:
  * Read tools always allowed
  * Write tools only when permission_mode allows
  * Bash must pass read-only verification
  * Max 20 turns, 100 messages per speculation
  * Status bar shows `✦ speculating` while active

Gated by `PROMETHEUS_SPECULATION=1`.
"""
from __future__ import annotations

import os
import shutil
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


_TRUTHY = ("1", "true", "yes", "on")


def speculation_enabled() -> bool:
    return os.environ.get(
        "PROMETHEUS_SPECULATION", "",
    ).strip().lower() in _TRUTHY


# ---------- caps ----------


MAX_TURNS = 20
MAX_MESSAGES = 100


# ---------- COW overlay store ----------


def overlay_root() -> Path:
    return (
        Path.home() / ".prometheus" / "tmp" / "speculation"
        / str(os.getpid())
    )


@dataclass
class OverlayStore:
    """Round 143-final-v3: per-speculation file staging."""
    speculation_id: str
    root: Path

    @classmethod
    def create(cls, speculation_id: str) -> "OverlayStore":
        base = overlay_root() / speculation_id
        base.mkdir(parents=True, exist_ok=True)
        return cls(speculation_id=speculation_id, root=base)

    def stage_path(self, real_path: Path) -> Path:
        """Round 143-final-v3: where the COW copy lives."""
        # Use a flattened name so absolute paths fit.
        rel = str(real_path).replace("\\", "/").lstrip("/")
        rel = rel.replace(":", "_")
        return self.root / rel

    def stage(self, real_path: Path, content: str) -> Path:
        """Round 143-final-v3: write `content` into the
        overlay for `real_path`."""
        target = self.stage_path(real_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return target

    def staged_files(self) -> list[Path]:
        if not self.root.exists():
            return []
        out: list[Path] = []
        for p in self.root.rglob("*"):
            if p.is_file():
                out.append(p)
        return out

    def commit(self, real_to_stage: dict[Path, Path]) -> int:
        """Round 143-final-v3: copy each stage file back to
        its real path. Returns the count copied."""
        n = 0
        for real, stage in real_to_stage.items():
            if not stage.exists():
                continue
            real.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(stage, real)
            n += 1
        return n

    def discard(self) -> None:
        if self.root.exists():
            shutil.rmtree(self.root, ignore_errors=True)


# ---------- speculation state ----------


@dataclass
class Suggestion:
    text: str
    confidence: float = 0.5


@dataclass
class Speculation:
    id: str
    suggestion: Suggestion
    started_at: float
    overlay: OverlayStore
    turns: int = 0
    messages: int = 0
    status: str = "running"           # running / accepted / rejected /
                                      # exhausted / cancelled
    accepted_paths: dict[Path, Path] = field(default_factory=dict)

    def record_turn(self) -> bool:
        """Round 143-final-v3: returns False when the cap is
        reached (caller should stop speculating)."""
        self.turns += 1
        if self.turns >= MAX_TURNS:
            self.status = "exhausted"
            return False
        return True

    def record_message(self) -> bool:
        self.messages += 1
        if self.messages >= MAX_MESSAGES:
            self.status = "exhausted"
            return False
        return True


def make_speculation(suggestion: Suggestion) -> Speculation:
    sid = str(uuid.uuid4())[:8]
    return Speculation(
        id=sid,
        suggestion=suggestion,
        started_at=time.monotonic(),
        overlay=OverlayStore.create(sid),
    )


# ---------- accept / reject ----------


def accept(
    spec: Speculation,
    *,
    real_to_stage: dict[Path, Path],
) -> int:
    """Round 143-final-v3: copy overlay files to the real
    filesystem. Returns count copied. Marks speculation
    accepted."""
    n = spec.overlay.commit(real_to_stage)
    spec.accepted_paths = dict(real_to_stage)
    spec.status = "accepted"
    return n


def reject(spec: Speculation) -> None:
    spec.overlay.discard()
    spec.status = "rejected"


def cancel(spec: Speculation) -> None:
    spec.overlay.discard()
    spec.status = "cancelled"


# ---------- status chip ----------


def status_chip(spec: Optional[Speculation]) -> str:
    if spec is None or spec.status != "running":
        return ""
    return "✦ speculating"


def render_status(spec: Speculation) -> str:
    elapsed = time.monotonic() - spec.started_at
    return (
        f"speculation #{spec.id}\n"
        f"  status:    {spec.status}\n"
        f"  turns:     {spec.turns}/{MAX_TURNS}\n"
        f"  messages:  {spec.messages}/{MAX_MESSAGES}\n"
        f"  elapsed:   {elapsed:.1f}s\n"
        f"  suggestion: {spec.suggestion.text[:80]}"
    )


# ---------- read-only verification for Bash ----------


_WRITE_LIKE = (
    "rm ", "rmdir", "mv ", "cp ", " > ", " >> ",
    "git commit", "git push", "git reset",
    "git checkout", "git rebase", "git merge",
    "npm install", "pip install", "cargo install",
    "make install", "sudo ", "kill ", "pkill",
    "chmod ", "chown ", "ln ", "touch ",
    "mkfs", "dd if",
)


def is_read_only(command: str) -> bool:
    """Round 143-final-v3: deterministic check before letting
    Bash run inside speculation. Conservative — anything
    matching a write-like substring is rejected."""
    if not command:
        return True
    low = command.lower()
    for needle in _WRITE_LIKE:
        if needle in low:
            return False
    return True
