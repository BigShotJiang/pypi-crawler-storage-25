"""Round 160 — Failure-Mode 3: headless checkpoint + structured failure.

Research (SitePoint production analysis): when agents run in -p mode,
failures can go undetected for days because no one is watching. The
fix is mandatory checkpoints + non-zero exit on failure + a known
location to find the structured error.

This module owns:
  • `headless_checkpoint_path()` — deterministic location keyed by
    session_id (or PID fallback).
  • `write_checkpoint()` — called BEFORE every tool execution in
    headless mode. Records {session, tool, args fingerprint, ts}.
  • `write_error_state()` — called on any failure. Writes a structured
    JSON file with the same path stem + `.error.json`.
  • `format_error_for_stderr()` — renders the user-visible message,
    including the checkpoint path so the user can resume.

Files land under USER_DATA_DIR/headless/ — same convention as the
session DB. We never block the loop on a checkpoint write; on disk
errors we degrade silently rather than crash the user's CLI.
"""
from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger("prometheus.headless_checkpoint")


def _data_dir() -> Path:
    """Resolve the headless checkpoint directory — same root the
    session DB / audit log use, with a `headless/` leaf."""
    try:
        from prometheus.config import USER_DATA_DIR
        d = Path(USER_DATA_DIR) / "headless"
    except Exception:
        d = Path.home() / ".prometheus" / "headless"
    try:
        d.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    return d


def headless_checkpoint_path(session_id: Optional[str] = None) -> Path:
    """Return the JSON checkpoint path for this headless run.

    Keyed by session_id when provided (so `--session=foo` runs all share
    one file), else by PID (so concurrent headless runs don't stomp).
    """
    sid = (session_id or f"pid-{os.getpid()}").replace("/", "_").replace(os.sep, "_")
    return _data_dir() / f"{sid}.checkpoint.json"


def headless_error_path(session_id: Optional[str] = None) -> Path:
    """Sibling file for the structured failure record. Lives next to
    the checkpoint with a `.error.json` suffix instead of
    `.checkpoint.json` — keeps both files easy to discover with
    `glob '<sid>.*.json'`."""
    sid = (session_id or f"pid-{os.getpid()}").replace("/", "_").replace(os.sep, "_")
    return _data_dir() / f"{sid}.error.json"


def _atomic_write_json(path: Path, payload: dict[str, Any]) -> bool:
    """Round 179: write JSON atomically (temp + fsync + replace).

    Pre-R179 the checkpoint and error files were written via
    `path.write_text(...)` — a single open-truncate-write call.
    If the process was killed mid-write (SIGKILL, terminal close,
    container OOM), the resume path saw a half-written file and
    `json.loads()` raised, defeating the whole point of the
    checkpoint. Atomic write + fsync + os.replace is the standard
    crash-safe pattern: either the old contents stay (last good
    checkpoint) or the new contents land complete.

    Returns True on success, False on any disk error (caller must
    not block on this — the checkpoint is best-effort).
    """
    import tempfile as _tempfile
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp_str = _tempfile.mkstemp(
            prefix=f".{path.name}.", suffix=".tmp",
            dir=str(path.parent),
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2, default=str)
                f.flush()
                try:
                    os.fsync(f.fileno())
                except OSError:
                    # Some filesystems / mocks don't support fsync.
                    # The os.replace below is still atomic on POSIX
                    # and Windows, so a missing fsync only relaxes
                    # the durability guarantee, not the atomicity.
                    pass
            os.replace(tmp_str, path)
            return True
        except Exception:
            try:
                os.unlink(tmp_str)
            except OSError:
                pass
            raise
    except OSError as e:
        logger.warning("could not atomic-write %s: %s", path, e)
        return False


def write_checkpoint(
    *,
    session_id: Optional[str],
    tool: str,
    args: dict[str, Any] | None = None,
    iteration: int = 0,
    extra: dict[str, Any] | None = None,
) -> Path | None:
    """Write a tool-pre-execution checkpoint. Returns the path written
    (or None if the write failed — caller must not block on this).

    Round 179: write is atomic (tmp + fsync + replace). A SIGKILL
    mid-write no longer leaves a corrupt file that breaks resume.
    """
    p = headless_checkpoint_path(session_id)
    payload = {
        "session_id": session_id or "",
        "tool": tool,
        "args_fingerprint": _fingerprint(args or {}),
        "iteration": iteration,
        "ts": time.time(),
        "pid": os.getpid(),
    }
    if extra:
        payload["extra"] = extra
    if _atomic_write_json(p, payload):
        return p
    return None


def write_error_state(
    *,
    session_id: Optional[str],
    error: str,
    last_tool: Optional[str] = None,
    iteration: int = 0,
    traceback_text: Optional[str] = None,
    extra: dict[str, Any] | None = None,
) -> Path | None:
    """Write a structured error record on any failure. Returns the path
    written (or None on disk-write failure).

    Round 179: atomic write — same crash-safe contract as
    write_checkpoint. The error file is what tells the user
    'something broke', so corrupting it on a crash mid-write
    would be the worst possible outcome.
    """
    p = headless_error_path(session_id)
    payload = {
        "session_id": session_id or "",
        "error": error or "",
        "last_tool": last_tool or "",
        "iteration": iteration,
        "ts": time.time(),
        "pid": os.getpid(),
    }
    # Keep traceback short — surfacing it to stderr is what the
    # checkpoint URL is for; stuffing 100KB into the JSON is wasteful.
    if traceback_text:
        payload["traceback_tail"] = traceback_text[-4000:]
    if extra:
        payload["extra"] = extra
    if _atomic_write_json(p, payload):
        return p
    return None


def format_error_for_stderr(
    *, error: str, session_id: Optional[str], last_tool: Optional[str] = None,
) -> str:
    """Build the user-facing error message that goes to stderr. Always
    includes the checkpoint + error file paths so the user can resume."""
    cp = headless_checkpoint_path(session_id)
    er = headless_error_path(session_id)
    lines = ["", f"error: {error}"]
    if last_tool:
        lines.append(f"last tool: {last_tool}")
    lines.append(f"checkpoint: {cp}")
    lines.append(f"error state: {er}")
    lines.append("resume: re-run the same prompt; the checkpoint records "
                 "the last tool that ran so you can replay or skip.")
    return "\n".join(lines)


def _fingerprint(args: dict[str, Any]) -> str:
    """Short, log-safe fingerprint of tool args. Not for security —
    just disambiguates two checkpoints from the same tool."""
    try:
        s = json.dumps(args, default=str, sort_keys=True)[:200]
    except Exception:
        s = repr(args)[:200]
    return s
