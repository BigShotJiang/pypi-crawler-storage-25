"""Round 167 — Prompt input ghost-text suggestion.

Claude Code shows a single dimmed "ghost text" suggestion in the
input area as the user types. The contract:
  • Tab    → accept the suggestion (replace input with full text)
  • Enter  → accept + submit
  • Typing → dismiss (the user moved past it)

This module owns the data layer. The host's Input widget plugs
in `accept`/`dismiss`/`render_ghost` calls; the actual ANSI dim
styling is the caller's responsibility (Textual's Input widget
already supports overlay text).

Pure data, no Textual import — tests run fast.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class Suggestion:
    """One pending ghost-text suggestion."""
    text: str = ""
    """The full text the user would see if they accept (Tab) or
    accept+submit (Enter). Empty string means no suggestion."""
    source: str = ""
    """Where the suggestion came from — 'history', 'aptitude',
    'plugin', etc. Used for /stats; not user-visible."""


@dataclass
class SuggestionState:
    """Per-Input-widget state machine. Lives on the host's Input
    widget; mutated by `propose`/`accept`/`dismiss`/`feed_typed_char`.
    """
    current: Optional[Suggestion] = None
    last_typed_prefix: str = ""

    # ---- public API --------------------------------------------

    def propose(self, *, text: str, source: str = "") -> bool:
        """Round 167: arm a ghost-text suggestion. Returns True
        if the suggestion was accepted (non-empty text)."""
        if not text:
            self.current = None
            return False
        self.current = Suggestion(text=text, source=source)
        return True

    def is_pending(self) -> bool:
        return bool(self.current and self.current.text)

    def accept(self) -> Optional[str]:
        """Round 167: Tab pressed. Returns the suggestion's full
        text and clears the suggestion. None if nothing was
        pending."""
        if not self.is_pending():
            return None
        text = self.current.text
        self.current = None
        return text

    def dismiss(self) -> None:
        """Round 167: typing/Esc pressed. Clear the suggestion."""
        self.current = None

    def feed_typed_char(self, ch: str, *, current_input: str) -> None:
        """Round 167: the user typed a character. If `current_input`
        is now NOT a prefix of the suggestion, dismiss."""
        if not self.is_pending():
            return
        if not self.current.text.startswith(current_input):
            self.dismiss()

    def render_ghost(self, current_input: str) -> str:
        """Round 167: the *trailing* portion of the suggestion
        the host should overlay in dimmed style. Empty string
        when there's nothing to show.

        Example:
          current_input  = 'gi'
          suggestion     = 'git status'
          render_ghost() = 't status'

        The caller renders this immediately after `current_input`
        in the input box, in the host's `DIM` style.
        """
        if not self.is_pending():
            return ""
        full = self.current.text
        if not full.startswith(current_input):
            return ""
        return full[len(current_input):]
