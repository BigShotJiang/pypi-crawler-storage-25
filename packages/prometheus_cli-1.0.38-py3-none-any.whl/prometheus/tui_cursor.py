"""Round 167 — Terminal cursor style management.

Claude Code uses a solid (non-blinking) block cursor while the
input area has focus, and restores the terminal's default
cursor on exit so the user's shell looks the way they left it.

This module owns:
  * `CURSOR_BLOCK_STEADY` — the ANSI sequence for "solid block"
  * `CURSOR_DEFAULT`      — restore the terminal's user default
  * `CURSOR_BAR_STEADY`   — solid bar (used during specific
                            edit modes if the host wants)
  * `set_cursor(stream, kind)` — write the right sequence
  * `with_cursor(...)`    — context manager that sets a cursor
                            and restores on exit (covers the
                            crash path)

The sequences are the standard DECSCUSR variants (CSI Ps SP q):
  Ps=0  blinking block (terminal default)
  Ps=1  blinking block
  Ps=2  steady block       ← this is what we use
  Ps=3  blinking underline
  Ps=4  steady underline
  Ps=5  blinking bar
  Ps=6  steady bar
"""
from __future__ import annotations

import contextlib
from enum import Enum


# DECSCUSR sequences. The leading `\x1b[` is the CSI prefix; the
# trailing `q` is the operation code. The number selects the
# cursor shape.
CURSOR_DEFAULT = "\x1b[0 q"
"""Restore the terminal's user-configured default. Use this on
exit so the user's shell behaves the way they left it."""

CURSOR_BLOCK_BLINKING = "\x1b[1 q"
CURSOR_BLOCK_STEADY = "\x1b[2 q"
"""Solid block, no blink — Claude Code's default while the
input box has focus."""

CURSOR_UNDERLINE_BLINKING = "\x1b[3 q"
CURSOR_UNDERLINE_STEADY = "\x1b[4 q"

CURSOR_BAR_BLINKING = "\x1b[5 q"
CURSOR_BAR_STEADY = "\x1b[6 q"


class CursorStyle(str, Enum):
    DEFAULT = "default"
    BLOCK_STEADY = "block_steady"
    BLOCK_BLINKING = "block_blinking"
    UNDERLINE_STEADY = "underline_steady"
    UNDERLINE_BLINKING = "underline_blinking"
    BAR_STEADY = "bar_steady"
    BAR_BLINKING = "bar_blinking"


_SEQ_BY_STYLE: dict[CursorStyle, str] = {
    CursorStyle.DEFAULT:             CURSOR_DEFAULT,
    CursorStyle.BLOCK_STEADY:        CURSOR_BLOCK_STEADY,
    CursorStyle.BLOCK_BLINKING:      CURSOR_BLOCK_BLINKING,
    CursorStyle.UNDERLINE_STEADY:    CURSOR_UNDERLINE_STEADY,
    CursorStyle.UNDERLINE_BLINKING:  CURSOR_UNDERLINE_BLINKING,
    CursorStyle.BAR_STEADY:          CURSOR_BAR_STEADY,
    CursorStyle.BAR_BLINKING:        CURSOR_BAR_BLINKING,
}


def sequence_for(style: CursorStyle) -> str:
    """Return the DECSCUSR ANSI sequence for `style`."""
    return _SEQ_BY_STYLE.get(style, CURSOR_DEFAULT)


def set_cursor(stream, style: CursorStyle) -> None:
    """Write the ANSI sequence for `style` to `stream` and flush.

    `stream` is anything with `.write()` + `.flush()` — typically
    `sys.stdout`. Falls back silently if the stream raises.
    """
    seq = sequence_for(style)
    try:
        stream.write(seq)
        if hasattr(stream, "flush"):
            stream.flush()
    except (OSError, ValueError):
        # Best-effort. A closed stream during shutdown is fine.
        pass


@contextlib.contextmanager
def with_cursor(stream, style: CursorStyle):
    """Round 167: context manager — set the cursor on enter,
    restore the terminal default on exit (including on exception).

    Usage:
        with with_cursor(sys.stdout, CursorStyle.BLOCK_STEADY):
            run_input_loop()
        # cursor restored to user default here, even on Ctrl+C
    """
    set_cursor(stream, style)
    try:
        yield
    finally:
        set_cursor(stream, CursorStyle.DEFAULT)
