"""Round 136: `/fast` toggle.

Fast Mode optimizes for low latency over thoroughness. When
enabled:

  * thinking effort drops to `low`
  * tool-use streaming defaults to compact receipts
  * the model's `max_tokens` budget is reduced
  * the planner pre-pass is skipped

The flag is a per-session env override
(`PROMETHEUS_FAST_MODE=1`) so subprocess subagents inherit it
naturally. Disable returns each setting to its prior value.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class FastModeSnapshot:
    """Round 136: prior values for the settings we override.
    Toggling fast off restores them."""
    thinking_effort: Optional[str] = None
    max_tokens: Optional[int] = None
    compact: Optional[bool] = None
    skip_planner: Optional[bool] = None


@dataclass
class FastMode:
    """Round 136: the toggle's runtime state."""
    enabled: bool = False
    saved: FastModeSnapshot = field(default_factory=FastModeSnapshot)


def fast_mode_active() -> bool:
    """Round 136: env-flag check; subprocess agents pick it up
    too."""
    return os.environ.get("PROMETHEUS_FAST_MODE", "").strip().lower() in (
        "1", "true", "yes",
    )


def enable_fast_mode(
    fm: FastMode,
    *,
    current_effort: str = "medium",
    current_max_tokens: int = 4096,
    current_compact: bool = False,
    current_skip_planner: bool = False,
) -> FastMode:
    """Round 136: snapshot prior settings + flip env flag. Pure
    — caller mutates the actual config from the return value."""
    if fm.enabled:
        return fm
    fm.saved = FastModeSnapshot(
        thinking_effort=current_effort,
        max_tokens=current_max_tokens,
        compact=current_compact,
        skip_planner=current_skip_planner,
    )
    fm.enabled = True
    os.environ["PROMETHEUS_FAST_MODE"] = "1"
    return fm


def disable_fast_mode(fm: FastMode) -> FastMode:
    """Round 136: undo. Returns the saved snapshot so the
    caller can restore those fields."""
    if not fm.enabled:
        return fm
    fm.enabled = False
    os.environ["PROMETHEUS_FAST_MODE"] = "0"
    return fm


def fast_mode_settings() -> dict[str, object]:
    """Round 136: the canonical override values for fast mode."""
    return {
        "thinking_effort": "low",
        "max_tokens": 1024,
        "compact": True,
        "skip_planner": True,
    }


def status_chip(fm: FastMode) -> str:
    """Round 136: status-bar chip when fast mode is active."""
    return "FAST" if fm.enabled else ""
