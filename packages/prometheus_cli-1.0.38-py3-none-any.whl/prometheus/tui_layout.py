"""Round 141: TUI layout primitives — sticky prompt, diff
render, hardware-scroll, alternate-screen.

Pure data-layer + env-flag accessors. The Textual host reads
these to decide layout constraints; we don't import textual
here so the unit tests stay fast.

Env flags (all default conservative):

  * PROMETHEUS_STICKY_PROMPT          (default: ON)
  * PROMETHEUS_DIFF_RENDER            (default: OFF; opt-in)
  * PROMETHEUS_HARDWARE_SCROLL        (default: ON)
  * PROMETHEUS_DISABLE_ALTERNATE_SCREEN (default: OFF)

Settings keys (read by `resolve_layout`):

  * stickyPrompt        bool — force-disable sticky prompt
  * diffRenderEnabled   bool — force-enable diff render
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Optional


_TRUTHY = ("1", "true", "yes", "on")


def _flag(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name, "").strip().lower()
    if not raw:
        return default
    return raw in _TRUTHY


# ---------- sticky prompt ----------


def sticky_prompt_enabled(setting: Optional[bool] = None) -> bool:
    """Round 141: pinned-input-at-bottom. Default ON. Env wins
    when set; else setting; else default."""
    raw = os.environ.get("PROMETHEUS_STICKY_PROMPT", "").strip().lower()
    if raw:
        return raw in _TRUTHY
    if setting is None:
        return True
    return bool(setting)


# ---------- diff render ----------


def diff_render_enabled(setting: Optional[bool] = None) -> bool:
    """Round 141: only-changed-lines patcher. Default OFF
    (opt-in) so the existing render path stays the default."""
    raw = os.environ.get("PROMETHEUS_DIFF_RENDER", "").strip().lower()
    if raw:
        return raw in _TRUTHY
    if setting is None:
        return False
    return bool(setting)


# ---------- hardware scroll ----------


def hardware_scroll_enabled() -> bool:
    """Round 141: emit ANSI scroll-region sequences when content
    shifts without layout changes. Default ON.

    1.0.3 (CC v2.1.131 parity): `CLAUDE_CODE_FORCE_SYNC_OUTPUT=1`
    or `PROMETHEUS_FORCE_SYNC_OUTPUT=1` forces synchronous, line-
    based rendering — needed by Emacs `eat` and other terminals
    that don't tolerate the async hardware-scroll path. Setting
    either disables hardware scroll regardless of the user's
    `PROMETHEUS_HARDWARE_SCROLL` value."""
    if force_sync_output():
        return False
    return _flag("PROMETHEUS_HARDWARE_SCROLL", default=True)


def force_sync_output() -> bool:
    """1.0.3 (CC v2.1.131 parity): honour both names so a user
    migrating from CC keeps their existing env."""
    truthy = ("1", "true", "yes", "on")
    return (
        os.environ.get(
            "PROMETHEUS_FORCE_SYNC_OUTPUT", "",
        ).strip().lower() in truthy
        or os.environ.get(
            "CLAUDE_CODE_FORCE_SYNC_OUTPUT", "",
        ).strip().lower() in truthy
    )


def alternate_screen_disabled() -> bool:
    """Round 141: opt-out of alt-screen. When True, /tui
    fullscreen still toggles, but doesn't actually enter the
    alternate buffer (useful for screen-recording + tmux pane
    splits where alt-screen confuses the viewer)."""
    return _flag(
        "PROMETHEUS_DISABLE_ALTERNATE_SCREEN", default=False,
    )


# ---------- ANSI scroll-region helpers ----------


def scroll_region_seq(top: int, bottom: int) -> str:
    """Round 141: DECSTBM — set scrolling region rows [top, bottom]
    (1-indexed)."""
    return f"\x1b[{int(top)};{int(bottom)}r"


def scroll_up_seq(n: int = 1) -> str:
    """Round 141: SU — scroll up N lines."""
    return f"\x1b[{int(max(1, n))}S"


def scroll_down_seq(n: int = 1) -> str:
    """Round 141: SD — scroll down N lines."""
    return f"\x1b[{int(max(1, n))}T"


def reset_scroll_region_seq() -> str:
    """Round 141: clear scroll region (back to full screen)."""
    return "\x1b[r"


def hardware_scroll_payload(
    *,
    top: int, bottom: int, direction: str, lines: int,
) -> str:
    """Round 141: build the full hardware-scroll sequence —
    set region, emit scroll, reset region. Caller pipes the
    payload to the terminal."""
    if direction not in ("up", "down"):
        return ""
    if lines <= 0:
        return ""
    if not hardware_scroll_enabled():
        return ""
    move = scroll_up_seq(lines) if direction == "up" else scroll_down_seq(lines)
    return scroll_region_seq(top, bottom) + move + reset_scroll_region_seq()


# ---------- consolidated layout snapshot ----------


@dataclass
class LayoutMode:
    sticky_prompt: bool
    diff_render: bool
    hardware_scroll: bool
    fullscreen: bool
    alternate_screen_active: bool
    no_flicker: bool


def resolve_layout(settings: Optional[dict] = None) -> LayoutMode:
    """Round 141: assemble the effective layout state from env
    + settings + round-138 fullscreen toggle. Used by the
    host's render loop."""
    s = settings or {}
    fullscreen = False
    no_flicker = False
    try:
        from prometheus.tui_mode import fullscreen_active
        fullscreen = fullscreen_active()
    except ImportError:
        pass
    try:
        from prometheus.no_flicker import no_flicker_enabled
        no_flicker = no_flicker_enabled()
    except ImportError:
        pass
    alternate_screen_active = (
        fullscreen and not alternate_screen_disabled()
    )
    return LayoutMode(
        sticky_prompt=sticky_prompt_enabled(s.get("stickyPrompt")),
        diff_render=diff_render_enabled(s.get("diffRenderEnabled")),
        hardware_scroll=hardware_scroll_enabled(),
        fullscreen=fullscreen,
        alternate_screen_active=alternate_screen_active,
        no_flicker=no_flicker,
    )


def render_layout_status(mode: LayoutMode) -> str:
    """Round 141: status text used by `/tui status` and `/audit`."""
    def _on(v: bool) -> str:
        return "ON " if v else "off"
    lines = ["TUI layout:"]
    lines.append(f"  sticky prompt:    {_on(mode.sticky_prompt)}")
    lines.append(f"  diff render:      {_on(mode.diff_render)}")
    lines.append(f"  hardware scroll:  {_on(mode.hardware_scroll)}")
    lines.append(f"  no-flicker:       {_on(mode.no_flicker)}")
    lines.append(f"  fullscreen:       {_on(mode.fullscreen)}")
    if mode.fullscreen:
        lines.append(
            f"  alt-screen:       {_on(mode.alternate_screen_active)}"
        )
    return "\n".join(lines)


# ---------------------------------------------------------------
# Round 166 / B4 — region-level static/dynamic render split
# ---------------------------------------------------------------
#
# Round 141 already implements the *message-level* split via
# `RenderTimeline` in `tui_streaming.py` (static entries are
# write-once, dynamic entries can update). What was missing
# until now is the *region-level* split: which areas of the
# screen repaint vs. stay frozen on a frame tick.
#
# Claude Code's TUI architecture analysis identifies this as
# the single biggest performance lever for large transcripts:
# only the streaming response, the spinner, the input area, and
# the status bar ever need to repaint per tick. Everything else
# is static and must never be re-rendered, even when the user
# generates 50+ messages and starts a new prompt.

from collections import Counter
from enum import Enum


class Region(str, Enum):
    """Round 166: every region of the TUI that the renderer can
    paint independently. The split between static and dynamic
    is the contract — `STATIC_TRANSCRIPT` repaints exactly once
    per session at initial layout; everything else repaints
    freely on frame ticks."""
    STATIC_TRANSCRIPT = "static_transcript"
    """Finalized user + assistant messages above the current
    streaming line. Once content lands here it is frozen — the
    renderer must never re-emit the bytes for those rows."""
    STREAMING_MESSAGE = "streaming_message"
    """The single in-flight assistant message. Repaints on
    every flush tick (~16 ms / 60fps) until the model emits
    `tool_call_complete` or `stop`, at which point the host
    moves it to the static transcript."""
    SPINNER = "spinner"
    """Spinner glyph + activity-rail label. Independent from
    the streaming message because the rail can update during
    the round-165 `finishing` phase when no streaming text is
    arriving."""
    INPUT = "input"
    """Bottom input box including any inline approval overlay
    (round 141)."""
    STATUS_BAR = "status_bar"
    """Top or bottom HUD: model name, permission mode, token
    counters, USD ticker, round-165 background-task
    indicator."""
    STATUS_LINE_FOOTER = "status_line_footer"
    """Round-164 user `statusLine` script output. Repaints once
    per debounced tick."""
    SUBAGENT_PANEL = "subagent_panel"
    """Vertical stack of round-97 cohort cards. Each card paints
    independently."""


STATIC_REGIONS: frozenset[Region] = frozenset({Region.STATIC_TRANSCRIPT})
"""Regions that must NEVER repaint after first layout. Any
attempt to mark these dirty during steady-state operation is a
contract violation. The Layout class catches this at the API
boundary."""

DYNAMIC_REGIONS: frozenset[Region] = frozenset({
    Region.STREAMING_MESSAGE,
    Region.SPINNER,
    Region.INPUT,
    Region.STATUS_BAR,
    Region.STATUS_LINE_FOOTER,
    Region.SUBAGENT_PANEL,
})
"""Regions that may repaint freely on any frame tick."""


def is_static_region(region: Region) -> bool:
    return region in STATIC_REGIONS


def is_dynamic_region(region: Region) -> bool:
    return region in DYNAMIC_REGIONS


@dataclass
class RenderLayout:
    """Round 166 / B4: the host's dirty-region ledger.

    Per frame tick:
      1. Whatever happened (input keystroke, model token, spinner
         tick, cohort status change) is marked via
         `mark_dirty(region)`.
      2. The renderer iterates `dirty_regions()` and repaints
         only those regions.
      3. After the frame is painted the host calls `clear()`.
      4. Static regions can be marked dirty exactly once (the
         initial layout). Later attempts are dropped AND
         logged in `contract_violations`, which tests assert on.

    Naming: this dataclass is `RenderLayout` (not `Layout`) to
    avoid colliding with `LayoutMode` above.
    """
    _dirty: set = None
    _initial_paint_done: dict = None
    contract_violations: list = None

    def __post_init__(self) -> None:
        if self._dirty is None:
            self._dirty = set()
        if self._initial_paint_done is None:
            self._initial_paint_done = {}
        if self.contract_violations is None:
            self.contract_violations = []

    def mark_dirty(self, region: "Region") -> bool:
        """Round 166: flag `region` for repaint on the next
        frame. Returns True when the mark was accepted, False
        when suppressed (static region after its initial paint)."""
        if region in STATIC_REGIONS and self._initial_paint_done.get(region):
            self.contract_violations.append(
                f"refused to mark static region {region.value!r} "
                f"dirty after initial paint"
            )
            return False
        self._dirty.add(region)
        return True

    def mark_initial_paint_done(self, region: "Region") -> None:
        self._initial_paint_done[region] = True

    def is_dirty(self, region: "Region") -> bool:
        return region in self._dirty

    def dirty_regions(self) -> set:
        return set(self._dirty)

    def clear(self) -> None:
        """Round 166: call after a frame is painted. Marks every
        currently-dirty region as having had its initial paint."""
        for r in self._dirty:
            self._initial_paint_done.setdefault(r, True)
        self._dirty.clear()

    def force_repaint_static(self, region: "Region") -> None:
        """Round 166: explicit override — used when the user
        resized and the static transcript needs to re-flow.
        Resets the initial-paint flag so the next `mark_dirty`
        will accept it."""
        if region not in STATIC_REGIONS:
            return
        self._initial_paint_done.pop(region, None)


@dataclass
class RenderCounter:
    """Round 166 / B4: paint-count ledger across a session.

    The contract regression test uses this directly: after 50
    finalised messages + 100 streaming ticks, the static-
    transcript count must be 1, and the streaming-message
    count must be 100.
    """
    paints: Optional[Any] = None  # Counter[Region]

    def __post_init__(self) -> None:
        if self.paints is None:
            self.paints = Counter()

    def record_paint(self, region: "Region") -> None:
        self.paints[region] += 1

    def count(self, region: "Region") -> int:
        return int(self.paints[region])

    def reset(self) -> None:
        self.paints.clear()

    def render_summary(self) -> str:
        """Compact one-line summary: e.g.
        `static:1 streaming:100 spinner:100 input:3 status_bar:100`."""
        order = (
            Region.STATIC_TRANSCRIPT, Region.STREAMING_MESSAGE,
            Region.SPINNER, Region.INPUT, Region.STATUS_BAR,
            Region.STATUS_LINE_FOOTER, Region.SUBAGENT_PANEL,
        )
        short = {
            Region.STATIC_TRANSCRIPT: "static",
            Region.STREAMING_MESSAGE: "streaming",
            Region.SPINNER: "spinner",
            Region.INPUT: "input",
            Region.STATUS_BAR: "status_bar",
            Region.STATUS_LINE_FOOTER: "footer",
            Region.SUBAGENT_PANEL: "panel",
        }
        bits = [
            f"{short[r]}:{self.paints[r]}"
            for r in order if r in self.paints
        ]
        return " ".join(bits)


def paint_dirty(
    layout: RenderLayout, counter: RenderCounter,
    *, painter=None,
) -> set:
    """Round 166 / B4: one tick of the frame loop. Repaints
    every region currently flagged dirty, records each paint in
    `counter`, and clears the layout. Returns the set of
    regions that were actually painted.

    `painter` is an optional `painter(region)` callable the host
    plugs in to do the actual rendering. The default no-op is
    used by tests — they only care about which regions *would*
    have been painted, not the bytes.
    """
    dirty = layout.dirty_regions()
    for region in dirty:
        if painter is not None:
            try:
                painter(region)
            except Exception:
                # Frame loop swallows per-region render
                # exceptions; surfacing one would break the
                # rest of the frame.
                pass
        counter.record_paint(region)
    layout.clear()
    return dirty
