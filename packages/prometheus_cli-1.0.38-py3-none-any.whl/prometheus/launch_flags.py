"""Round 136: launch-time flag handling for the absolute final
sprint.

  * --name / -n                   session label
  * --disable-slash-commands      hide every slash + skill + aptitude
  * --setting-sources             whitelist of config sources
  * --betas                       comma-separated API beta headers
  * --include-partial-messages    streaming partial events
  * --input-format text|stream-json
  * --replay-user-messages        echo stdin to stdout
  * --append-system-prompt(-file) append (not replace) the prompt
  * --teammate-mode               in-process / tmux / auto
  * --thinking on|off             extended thinking toggle
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


VALID_SETTING_SOURCES = ("user", "project", "local", "managed")
VALID_INPUT_FORMATS = ("text", "stream-json")
VALID_TEAMMATE_MODES = ("in-process", "tmux", "auto")


# ---------- --name ----------


def normalize_session_name(raw: str) -> str:
    """Round 136: trim + lower-snake. Reject things that would
    confuse path lookups. Returns "" when the input is empty."""
    s = (raw or "").strip()
    if not s:
        return ""
    out: list[str] = []
    for ch in s:
        if ch.isalnum() or ch in "-_":
            out.append(ch)
        elif ch.isspace() or ch in "/\\":
            out.append("-")
    cleaned = "".join(out).strip("-_")
    return cleaned[:64]  # keep filenames sane


# ---------- --disable-slash-commands ----------


def slash_commands_enabled() -> bool:
    """Round 136: env-flag check. True by default."""
    return os.environ.get(
        "PROMETHEUS_DISABLE_SLASH_COMMANDS", "",
    ).strip().lower() not in ("1", "true", "yes")


def core_slash_commands() -> set[str]:
    """Round 136: when slash commands are disabled, only this
    minimal set survives."""
    return {"help", "quit", "exit"}


def filter_router_to_core(router) -> int:
    """Round 136: drop every command not in the core set.
    Returns the count of removed commands. Mutates the router
    in place."""
    keep = core_slash_commands()
    bag = getattr(router, "cmds", None)
    if not isinstance(bag, dict):
        return 0
    removed = 0
    for name in list(bag.keys()):
        if name not in keep:
            try:
                del bag[name]
                removed += 1
            except KeyError:
                pass
    return removed


# ---------- --setting-sources ----------


def parse_setting_sources(raw: str) -> list[str]:
    """Round 136: split CSV, filter to known names, preserve
    order. Empty input → load defaults (all four sources)."""
    if not raw or not raw.strip():
        return list(VALID_SETTING_SOURCES)
    parts = [p.strip().lower() for p in raw.split(",")]
    out: list[str] = []
    for p in parts:
        if p in VALID_SETTING_SOURCES and p not in out:
            out.append(p)
    return out or list(VALID_SETTING_SOURCES)


def setting_source_enabled(name: str) -> bool:
    """Round 136: env-driven runtime check used by config
    loaders."""
    raw = os.environ.get("PROMETHEUS_SETTING_SOURCES", "")
    if not raw:
        return True  # default-on for all
    return name.lower() in [
        p.strip().lower() for p in raw.split(",")
    ]


# ---------- --betas ----------


def parse_betas(raw: str) -> list[str]:
    """Round 136: split CSV, dedupe, preserve order. Each entry
    is a beta header value the API will receive."""
    if not raw:
        return []
    seen: set[str] = set()
    out: list[str] = []
    for p in raw.split(","):
        p = p.strip()
        if p and p not in seen:
            seen.add(p)
            out.append(p)
    return out


def betas_header(values: list[str]) -> Optional[str]:
    """Round 136: build the comma-joined header value. Returns
    None when the list is empty so the caller can omit the
    header entirely."""
    if not values:
        return None
    return ",".join(values)


# ---------- --include-partial-messages ----------


def include_partial_messages() -> bool:
    return os.environ.get(
        "PROMETHEUS_INCLUDE_PARTIAL", "",
    ).strip().lower() in ("1", "true", "yes")


# ---------- --input-format ----------


def normalize_input_format(raw: str) -> str:
    v = (raw or "").strip().lower()
    if v in VALID_INPUT_FORMATS:
        return v
    return "text"


# ---------- --replay-user-messages ----------


def replay_user_messages() -> bool:
    return os.environ.get(
        "PROMETHEUS_REPLAY_USER_MESSAGES", "",
    ).strip().lower() in ("1", "true", "yes")


# ---------- --append-system-prompt(-file) ----------


@dataclass
class AppendedSystemPrompt:
    text: str
    source: str        # `inline` / `file` / `none`


def resolve_appended_system_prompt(
    *,
    inline: Optional[str] = None,
    file_path: Optional[str] = None,
) -> AppendedSystemPrompt:
    """Round 136: inline + file are concatenated (inline first)
    so the user can supply both."""
    parts: list[str] = []
    sources: list[str] = []
    if inline and inline.strip():
        parts.append(inline.strip())
        sources.append("inline")
    if file_path and file_path.strip():
        try:
            txt = Path(file_path).expanduser().read_text(
                encoding="utf-8",
            )
            parts.append(txt.strip())
            sources.append("file")
        except OSError:
            pass
    if not parts:
        return AppendedSystemPrompt(text="", source="none")
    return AppendedSystemPrompt(
        text="\n\n".join(parts),
        source="+".join(sources),
    )


def apply_append_to_system_prompt(
    base: str, appended: AppendedSystemPrompt,
) -> str:
    """Round 136: ensure separation between base + appended,
    even when base ends without trailing newline."""
    if not appended.text:
        return base
    if not base:
        return appended.text
    sep = "\n\n" if not base.endswith("\n") else "\n"
    return base + sep + appended.text


# ---------- --teammate-mode ----------


def normalize_teammate_mode(raw: str) -> str:
    """Round 136: pick a teammate spawn mode. `auto` means we
    detect at runtime — tmux when available + POSIX; in-process
    otherwise."""
    v = (raw or "").strip().lower()
    if v in VALID_TEAMMATE_MODES:
        return v
    return "in-process"


def resolve_effective_teammate_mode(requested: str) -> str:
    """Round 136: resolve `auto` → concrete value. Caller calls
    this when actually spawning a teammate."""
    val = normalize_teammate_mode(requested)
    if val != "auto":
        return val
    try:
        from prometheus.worktree_launch import tmux_supported
        return "tmux" if tmux_supported() else "in-process"
    except ImportError:
        return "in-process"
