"""Strict JSON-RPC 2.0 codec for MCP stdio.

Closed-schema validation is the single chokepoint that defangs the
CVE-2025-6514 attack class for our parser: any field beyond the
documented closed set (e.g. an unsolicited `authorization_endpoint`)
is rejected at the framing layer before any business logic sees it.

References:
- https://modelcontextprotocol.io/specification/2025-06-18/basic/transports
- https://modelcontextprotocol.io/specification/2025-06-18/basic/lifecycle
- https://nvd.nist.gov/vuln/detail/CVE-2025-6514
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Iterator, Literal

from prometheus.mcp.errors import McpProtocolError


MAX_MESSAGE_BYTES = 1 * 1024 * 1024
MAX_METHOD_LEN = 64
MAX_DEPTH = 8


CLIENT_TO_SERVER_METHODS = frozenset({
    "initialize",
    "ping",
    "tools/list", "tools/call",
    "resources/list", "resources/read",
    "resources/subscribe", "resources/unsubscribe",
    "prompts/list", "prompts/get",
    "logging/setLevel",
    "completion/complete",
})
CLIENT_TO_SERVER_NOTIFICATIONS = frozenset({
    "notifications/initialized",
    "notifications/cancelled",
    "notifications/progress",
    "notifications/roots/list_changed",
})
SERVER_TO_CLIENT_METHODS = frozenset({
    "ping",
    "sampling/createMessage",
    "roots/list",
    "elicitation/create",
})
SERVER_TO_CLIENT_NOTIFICATIONS = frozenset({
    "notifications/cancelled",
    "notifications/progress",
    "notifications/message",
    "notifications/resources/list_changed",
    "notifications/resources/updated",
    "notifications/tools/list_changed",
    "notifications/prompts/list_changed",
})


@dataclass(frozen=True, slots=True)
class JsonRpcErrorObj:
    code: int
    message: str
    data: object | None = None


@dataclass(frozen=True, slots=True)
class JsonRpcRequest:
    id: int | str
    method: str
    params: dict | None = None


@dataclass(frozen=True, slots=True)
class JsonRpcNotification:
    method: str
    params: dict | None = None


@dataclass(frozen=True, slots=True)
class JsonRpcResponse:
    id: int | str
    result: dict | None = None
    error: JsonRpcErrorObj | None = None


Message = JsonRpcRequest | JsonRpcNotification | JsonRpcResponse


def _measure_depth(obj: Any, depth: int = 0) -> int:
    if depth > MAX_DEPTH:
        return depth
    if isinstance(obj, dict):
        return max((_measure_depth(v, depth + 1) for v in obj.values()), default=depth)
    if isinstance(obj, list):
        return max((_measure_depth(v, depth + 1) for v in obj), default=depth)
    return depth


def _no_dup_keys(pairs: list[tuple[str, Any]]) -> dict:
    seen: set[str] = set()
    for k, _ in pairs:
        if k in seen:
            raise McpProtocolError(f"duplicate JSON key: {k}")
        seen.add(k)
    return dict(pairs)


class JsonRpcCodec:
    """Newline-delimited JSON-RPC 2.0 codec for MCP stdio.

    Two instances expected per server: one for client→server (validates
    OUTGOING method names against CLIENT_TO_SERVER_*), one for server→
    client (validates INCOMING method names against SERVER_TO_CLIENT_*).
    """

    def __init__(
        self,
        *,
        peer: Literal["server", "client"] = "server",
        max_bytes: int = MAX_MESSAGE_BYTES,
        max_depth: int = MAX_DEPTH,
        max_method_len: int = MAX_METHOD_LEN,
    ) -> None:
        self.peer = peer
        self.max_bytes = max_bytes
        self.max_depth = max_depth
        self.max_method_len = max_method_len
        self._buf = bytearray()
        if peer == "server":
            # Inbound side: messages COMING FROM the server.
            self._allowed_methods = SERVER_TO_CLIENT_METHODS
            self._allowed_notifications = SERVER_TO_CLIENT_NOTIFICATIONS
        else:
            # Inbound side: messages COMING FROM the client (test/echo flows).
            self._allowed_methods = CLIENT_TO_SERVER_METHODS
            self._allowed_notifications = CLIENT_TO_SERVER_NOTIFICATIONS

    # ---- Encoding ----

    def encode(self, msg: Message) -> bytes:
        if isinstance(msg, JsonRpcRequest):
            obj: dict[str, Any] = {
                "jsonrpc": "2.0", "id": msg.id, "method": msg.method,
            }
            if msg.params is not None:
                obj["params"] = msg.params
        elif isinstance(msg, JsonRpcNotification):
            obj = {"jsonrpc": "2.0", "method": msg.method}
            if msg.params is not None:
                obj["params"] = msg.params
        elif isinstance(msg, JsonRpcResponse):
            obj = {"jsonrpc": "2.0", "id": msg.id}
            if msg.error is not None:
                err: dict[str, Any] = {
                    "code": msg.error.code, "message": msg.error.message,
                }
                if msg.error.data is not None:
                    err["data"] = msg.error.data
                obj["error"] = err
            else:
                obj["result"] = msg.result or {}
        else:
            raise McpProtocolError(f"cannot encode {type(msg).__name__}")
        line = json.dumps(obj, ensure_ascii=True, separators=(",", ":"))
        if "\n" in line:
            raise McpProtocolError("encoded JSON contains embedded newline")
        return (line + "\n").encode("utf-8")

    # ---- Decoding ----

    def feed(self, chunk: bytes) -> Iterator[Message]:
        self._buf.extend(chunk)
        while True:
            nl = self._buf.find(b"\n")
            if nl == -1:
                if len(self._buf) > self.max_bytes:
                    raise McpProtocolError(
                        f"oversized line ({len(self._buf)} > {self.max_bytes})"
                    )
                return
            line = bytes(self._buf[:nl]).rstrip(b"\r")
            del self._buf[: nl + 1]
            if not line:
                continue
            if len(line) > self.max_bytes:
                raise McpProtocolError(
                    f"oversized line ({len(line)} > {self.max_bytes})"
                )
            try:
                text = line.decode("utf-8", "strict")
            except UnicodeDecodeError as e:
                raise McpProtocolError(f"non-utf8 input: {e}") from e
            try:
                obj = json.loads(text, object_pairs_hook=_no_dup_keys)
            except json.JSONDecodeError as e:
                raise McpProtocolError(f"bad JSON: {e}") from e
            if _measure_depth(obj) > self.max_depth:
                raise McpProtocolError("params too deep")
            yield self._classify(obj)

    def _classify(self, obj: Any) -> Message:
        if not isinstance(obj, dict):
            raise McpProtocolError("top-level must be object")
        if obj.get("jsonrpc") != "2.0":
            raise McpProtocolError("missing or wrong jsonrpc version")
        # Allowlist of permitted top-level keys. Anything else (e.g.
        # an `authorization_endpoint` field smuggled in by a malicious
        # server) raises here. This is the CVE-2025-6514 regression
        # gate.
        ALLOWED = {"jsonrpc", "id", "method", "params", "result", "error"}
        extras = set(obj.keys()) - ALLOWED
        if extras:
            raise McpProtocolError(f"unknown top-level fields: {sorted(extras)}")

        has_id = "id" in obj
        has_method = "method" in obj
        has_result = "result" in obj
        has_error = "error" in obj

        if has_method and has_id and not (has_result or has_error):
            method = obj["method"]
            self._validate_method(method)
            params = obj.get("params")
            if params is not None and not isinstance(params, (dict, list)):
                raise McpProtocolError("params must be object/array/null")
            return JsonRpcRequest(
                id=self._validate_id(obj["id"]),
                method=method,
                params=params if isinstance(params, dict) else (
                    {"_array": params} if isinstance(params, list) else None
                ),
            )
        if has_method and not has_id and not (has_result or has_error):
            method = obj["method"]
            # Notifications use a separate allowlist.
            if (method not in self._allowed_notifications
                    and method not in self._allowed_methods):
                raise McpProtocolError(f"disallowed notification: {method}")
            if len(method) > self.max_method_len:
                raise McpProtocolError("method name too long")
            params = obj.get("params")
            if params is not None and not isinstance(params, (dict, list)):
                raise McpProtocolError("params must be object/array/null")
            return JsonRpcNotification(
                method=method,
                params=params if isinstance(params, dict) else (
                    {"_array": params} if isinstance(params, list) else None
                ),
            )
        if has_id and (has_result ^ has_error) and not has_method:
            err: JsonRpcErrorObj | None = None
            if has_error:
                e = obj["error"]
                if not isinstance(e, dict):
                    raise McpProtocolError("error must be object")
                code = e.get("code")
                msg = e.get("message")
                if not isinstance(code, int) or not isinstance(msg, str):
                    raise McpProtocolError("error.code/message malformed")
                err = JsonRpcErrorObj(code=code, message=msg, data=e.get("data"))
                result = None
            else:
                result = obj["result"]
                if result is not None and not isinstance(result, dict):
                    # Some servers return JSON arrays/scalars as result.
                    # Wrap so downstream always gets a dict shape.
                    result = {"_value": result}
            return JsonRpcResponse(
                id=self._validate_id(obj["id"]),
                result=result,
                error=err,
            )
        raise McpProtocolError("ambiguous message shape")

    def _validate_method(self, method: Any) -> None:
        if not isinstance(method, str) or not method:
            raise McpProtocolError("method must be a non-empty string")
        if len(method) > self.max_method_len:
            raise McpProtocolError("method name too long")
        if method not in self._allowed_methods:
            raise McpProtocolError(f"disallowed method: {method}")

    @staticmethod
    def _validate_id(value: Any) -> int | str:
        if isinstance(value, bool) or value is None:
            raise McpProtocolError("id must be int or string")
        if isinstance(value, (int, str)):
            return value
        raise McpProtocolError("id must be int or string")
