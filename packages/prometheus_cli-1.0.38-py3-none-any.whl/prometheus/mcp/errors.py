"""Typed exceptions for the MCP integration."""
from __future__ import annotations


class McpError(Exception):
    """Base class. Catch this to handle any MCP error."""


class McpProtocolError(McpError):
    """Wire violation: bad framing, oversize, schema reject, embedded newline."""


class McpSandboxError(McpError):
    """preexec_fn / Job Object / sandbox-exec failed to apply."""


class McpConsentDenied(McpError):
    """User denied first-call approval or trust.json says deny."""


class McpServerCrashed(McpError):
    """Subprocess exited non-zero or exceeded restart budget."""


class McpTimeout(McpError):
    """RPC timed out before the server responded."""
