"""Stdio MCP server lifecycle — subprocess + JSON-RPC client wrapper.

This is the v1 stdio-only implementation. Per-OS hardening (Linux
preexec_fn RLIMITs, macOS sandbox-exec profile, Windows Job Object) is
applied opportunistically: we attempt the harden but never refuse to
spawn if the syscall isn't available — the codec-layer schema guard +
workspace-trust + binary-hash gate are the load-bearing defenses against
CVE-2025-6514. Subprocess limits are defense-in-depth.
"""
from __future__ import annotations

import asyncio
import enum
import os
import sys
from pathlib import Path
from typing import Any

from prometheus import log
from prometheus.mcp.config import McpServerConfig
from prometheus.mcp.errors import (
    McpProtocolError,
    McpServerCrashed,
    McpTimeout,
)
from prometheus.mcp.protocol import (
    JsonRpcCodec,
    JsonRpcRequest,
    JsonRpcNotification,
    JsonRpcResponse,
)


logger = log.get("mcp.server")


class ServerState(str, enum.Enum):
    IDLE = "idle"
    STARTING = "starting"
    READY = "ready"
    CRASHED = "crashed"
    DISABLED = "disabled"
    SHUTDOWN = "shutdown"


def _minimal_env(extra: dict[str, str]) -> dict[str, str]:
    """Whitelist a tiny set of inherited env vars + add caller-supplied
    ones. Hostile env in the parent shouldn't leak into the MCP server,
    BUT users genuinely need to forward their PrometheUS preferences
    (theme, voice backend, trust override) into hooks that some MCP
    servers respect — so PROMETHEUS_* and OPENROUTER_* (which the
    user explicitly set) pass through. API keys are still gated:
    *_API_KEY values never leak (the MCP server has no business
    seeing them)."""
    base = {
        k: os.environ[k]
        for k in ("PATH", "HOME", "LANG", "LC_ALL", "USER", "USERNAME",
                  "SYSTEMROOT", "TEMP", "TMP")
        if k in os.environ
    }
    for key, value in os.environ.items():
        if key.startswith(("PROMETHEUS_", "OPENROUTER_")):
            # Drop credential-bearing vars even within the trusted prefixes.
            if "API_KEY" in key or "TOKEN" in key or "SECRET" in key:
                continue
            base[key] = value
    base.update(extra)
    return base


def _macos_sandbox_wrapper(cfg: McpServerConfig) -> tuple[str, ...] | None:
    """Build a `sandbox-exec` argv prefix for the spawn.

    Returns None if sandbox-exec isn't available (the caller falls back
    to an unwrapped spawn). The profile denies network entirely, allows
    read-everywhere, and confines writes to the per-server cache dir
    plus /private/tmp.
    """
    import shutil
    import tempfile
    if not shutil.which("/usr/bin/sandbox-exec"):
        return None
    cache_dir = Path.home() / ".prometheus" / "mcp-cache" / cfg.name
    try:
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_dir.chmod(0o700)
    except OSError:
        return None
    profile = (
        "(version 1)\n"
        "(deny default)\n"
        "(allow process-fork)\n"
        "(allow process-exec*)\n"
        "(allow signal (target self))\n"
        "(allow file-read*)\n"
        f'(allow file-write* (subpath "{cache_dir}") '
        '(subpath "/private/tmp") (literal "/dev/null"))\n'
        "(deny network*)\n"
        "(allow mach-lookup (global-name \"com.apple.system.notification_center\"))\n"
    )
    fd, prof_path = tempfile.mkstemp(suffix=".sb", prefix="prometheus-mcp-")
    try:
        os.write(fd, profile.encode())
    finally:
        os.close(fd)
    return ("/usr/bin/sandbox-exec", "-f", prof_path)


def _attach_windows_job_object(pid: int, cfg: McpServerConfig) -> None:
    """Best-effort Job Object attach on Windows.

    Limits: KILL_ON_JOB_CLOSE so the child dies when we die; PROCESS_MEMORY
    bound to rlimit_as_mb. Requires kernel32 + ctypes; if any call fails
    we silently degrade — the codec + consent gates remain.
    """
    if sys.platform != "win32":
        return
    import ctypes
    from ctypes import wintypes as w
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    PROCESS_TERMINATE = 0x0001
    PROCESS_SET_QUOTA = 0x0100
    rights = PROCESS_TERMINATE | PROCESS_SET_QUOTA | 0x00100000  # SYNCHRONIZE
    h_proc = k32.OpenProcess(rights, False, pid)
    if not h_proc:
        return
    try:
        h_job = k32.CreateJobObjectW(None, None)
        if not h_job:
            return
        # JOBOBJECT_EXTENDED_LIMIT_INFORMATION — just enough fields
        # to set kill-on-close + memory cap.
        class IO_COUNTERS(ctypes.Structure):
            _fields_ = [(n, ctypes.c_uint64) for n in (
                "ReadOperationCount", "WriteOperationCount",
                "OtherOperationCount", "ReadTransferCount",
                "WriteTransferCount", "OtherTransferCount",
            )]
        class BASIC_LIMITS(ctypes.Structure):
            _fields_ = [
                ("PerProcessUserTimeLimit", ctypes.c_int64),
                ("PerJobUserTimeLimit", ctypes.c_int64),
                ("LimitFlags", ctypes.c_uint32),
                ("MinimumWorkingSetSize", ctypes.c_size_t),
                ("MaximumWorkingSetSize", ctypes.c_size_t),
                ("ActiveProcessLimit", ctypes.c_uint32),
                ("Affinity", ctypes.c_void_p),
                ("PriorityClass", ctypes.c_uint32),
                ("SchedulingClass", ctypes.c_uint32),
            ]
        class EXT_LIMITS(ctypes.Structure):
            _fields_ = [
                ("BasicLimitInformation", BASIC_LIMITS),
                ("IoInfo", IO_COUNTERS),
                ("ProcessMemoryLimit", ctypes.c_size_t),
                ("JobMemoryLimit", ctypes.c_size_t),
                ("PeakProcessMemoryUsed", ctypes.c_size_t),
                ("PeakJobMemoryUsed", ctypes.c_size_t),
            ]
        info = EXT_LIMITS()
        # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE | JOB_OBJECT_LIMIT_PROCESS_MEMORY
        info.BasicLimitInformation.LimitFlags = 0x2000 | 0x100
        info.ProcessMemoryLimit = cfg.sandbox.rlimit_as_mb * 1024 * 1024
        # ExtendedLimitInformation = 9
        k32.SetInformationJobObject(h_job, 9, ctypes.byref(info), ctypes.sizeof(info))
        k32.AssignProcessToJobObject(h_job, h_proc)
        # We deliberately DON'T close h_job — closing it kills the
        # process. The Job is owned by our parent process; when we
        # exit, KILL_ON_JOB_CLOSE reaps the child.
    finally:
        k32.CloseHandle(h_proc)


def _linux_preexec(cfg: McpServerConfig):
    """Returns a callable for preexec_fn that drops the child's caps.
    Wrapped in try/except so a missing libc symbol can't kill spawn."""
    def _apply():
        try:
            import resource
            import signal
            os.setsid()
            mb = cfg.sandbox.rlimit_as_mb * 1024 * 1024
            for rlim, val in (
                (resource.RLIMIT_AS, (mb, mb)),
                (resource.RLIMIT_NOFILE, (cfg.sandbox.rlimit_nofile,) * 2),
                (resource.RLIMIT_CPU, (cfg.sandbox.rlimit_cpu_sec,) * 2),
                (resource.RLIMIT_CORE, (0, 0)),
            ):
                try:
                    resource.setrlimit(rlim, val)
                except (ValueError, OSError):
                    pass
            try:
                signal.pthread_sigmask(signal.SIG_SETMASK, [])
            except Exception:
                pass
            try:
                import ctypes
                libc = ctypes.CDLL("libc.so.6", use_errno=True)
                # PR_SET_NO_NEW_PRIVS = 38
                libc.prctl(38, 1, 0, 0, 0)
                # PR_SET_PDEATHSIG = 1, SIGKILL = 9
                libc.prctl(1, 9, 0, 0, 0)
            except Exception:
                pass
        except Exception:
            pass
    return _apply


class McpServer:
    """One stdio MCP server. Lazy-started on first use."""

    def __init__(
        self,
        cfg: McpServerConfig,
        audit: Any = None,
    ) -> None:
        self.cfg = cfg
        self.audit = audit or (lambda *_a, **_k: None)
        self.state = ServerState.IDLE
        self._proc: asyncio.subprocess.Process | None = None
        self._inbound = JsonRpcCodec(peer="server")
        self._outbound = JsonRpcCodec(peer="client")
        self._next_id = 1
        self._pending: dict[int | str, asyncio.Future] = {}
        self._reader_task: asyncio.Task | None = None
        self._stderr_task: asyncio.Task | None = None
        self._restart_count = 0

    async def start(self) -> dict:
        if self.state in (ServerState.READY, ServerState.STARTING):
            return {}
        self.state = ServerState.STARTING
        env = _minimal_env(dict(self.cfg.env))
        kwargs: dict[str, Any] = {
            "stdin": asyncio.subprocess.PIPE,
            "stdout": asyncio.subprocess.PIPE,
            "stderr": asyncio.subprocess.PIPE,
            "cwd": self.cfg.cwd,
            "env": env,
            "limit": 4 * 1024 * 1024,
        }
        spawn_cmd = self.cfg.command
        spawn_args: list[str] = list(self.cfg.args)

        if sys.platform == "linux":
            kwargs["preexec_fn"] = _linux_preexec(self.cfg)
        elif sys.platform == "darwin":
            # macOS sandbox-exec wrapper: read-everywhere is OK (read_file
            # tools also work this way), writes confined to the cache
            # dir + /tmp, network denied. Best-effort — sandbox-exec is
            # technically deprecated but still works; if it's missing we
            # fall through to an unwrapped spawn.
            wrapper = _macos_sandbox_wrapper(self.cfg)
            if wrapper:
                spawn_cmd, spawn_args = wrapper[0], list(wrapper[1:]) + [self.cfg.command] + list(self.cfg.args)
        elif sys.platform == "win32":
            # CREATE_NEW_PROCESS_GROUP | CREATE_NO_WINDOW
            kwargs["creationflags"] = 0x00000200 | 0x08000000
        try:
            self._proc = await asyncio.create_subprocess_exec(
                spawn_cmd, *spawn_args, **kwargs,
            )
        except Exception as e:
            self.state = ServerState.CRASHED
            raise McpServerCrashed(f"spawn failed: {e}") from e
        if sys.platform == "win32":
            # Windows Job Object best-effort: assign the spawned process
            # so it dies when our parent process dies. Failure is not
            # fatal — the codec-layer guard is the load-bearing defense.
            try:
                _attach_windows_job_object(self._proc.pid, self.cfg)
            except Exception:
                logger.debug("windows job object attach skipped", exc_info=True)
        self._reader_task = asyncio.create_task(self._read_loop())
        self._stderr_task = asyncio.create_task(self._drain_stderr())
        # Initialize handshake.
        try:
            init_result = await self.call(
                "initialize",
                {
                    "protocolVersion": "2025-06-18",
                    "capabilities": {},
                    "clientInfo": {"name": "PrometheUS", "version": "1.0"},
                },
                timeout_ms=self.cfg.timeout_ms,
            )
            await self.notify("notifications/initialized", {})
        except Exception:
            # Kill the spawned process FIRST — shutdown's grace-period
            # handshake won't terminate a server that ignored
            # initialize and is hanging on stdin.read. Audit P0:
            # without this we leak the process (Job Object only reaps
            # on parent exit, not on a per-server timeout).
            try:
                if self._proc is not None and self._proc.returncode is None:
                    self._proc.kill()
            except (ProcessLookupError, AttributeError):
                pass
            await self.shutdown(grace_ms=100)
            raise
        self.state = ServerState.READY
        self.audit("mcp.server.started", {"server": self.cfg.name})
        return init_result

    async def call(self, method: str, params: dict | None = None,
                   *, timeout_ms: int | None = None) -> dict:
        if self._proc is None or self._proc.stdin is None:
            raise McpServerCrashed("not started")
        rid = self._next_id
        self._next_id += 1
        # Round 191: was `asyncio.get_event_loop().create_future()` —
        # `get_event_loop()` is deprecated in 3.12 and raises
        # RuntimeError in 3.14 when no loop is set. We're inside an
        # async method, so the running loop is always available.
        fut: asyncio.Future = asyncio.get_running_loop().create_future()
        self._pending[rid] = fut
        # Validate-and-encode using the OUTBOUND codec.
        msg = JsonRpcRequest(id=rid, method=method, params=params)
        # Outbound side has the client→server allowlist.
        line = self._outbound.encode(msg)
        self._proc.stdin.write(line)
        try:
            await self._proc.stdin.drain()
        except (BrokenPipeError, ConnectionResetError) as e:
            raise McpServerCrashed(f"stdin closed: {e}") from e
        timeout_s = (timeout_ms or self.cfg.timeout_ms) / 1000.0
        try:
            return await asyncio.wait_for(fut, timeout=timeout_s)
        except asyncio.TimeoutError:
            self._pending.pop(rid, None)
            await self.notify("notifications/cancelled", {"requestId": rid})
            raise McpTimeout(f"{method} timed out after {timeout_s:.1f}s")

    async def notify(self, method: str, params: dict | None = None) -> None:
        if self._proc is None or self._proc.stdin is None:
            return
        msg = JsonRpcNotification(method=method, params=params)
        line = self._outbound.encode(msg)
        try:
            self._proc.stdin.write(line)
            await self._proc.stdin.drain()
        except (BrokenPipeError, ConnectionResetError):
            pass

    async def shutdown(self, *, grace_ms: int = 2000) -> None:
        if self.state == ServerState.SHUTDOWN:
            return
        self.state = ServerState.SHUTDOWN
        proc = self._proc
        self._proc = None
        if proc is None:
            return
        try:
            if proc.stdin and not proc.stdin.is_closing():
                proc.stdin.close()
        except Exception:
            pass
        try:
            await asyncio.wait_for(proc.wait(), timeout=grace_ms / 1000.0)
        except asyncio.TimeoutError:
            try:
                proc.terminate()
            except ProcessLookupError:
                pass
            try:
                await asyncio.wait_for(proc.wait(), timeout=2.0)
            except asyncio.TimeoutError:
                try:
                    proc.kill()
                except ProcessLookupError:
                    pass
        # Cancel pending RPCs.
        for fut in self._pending.values():
            if not fut.done():
                fut.set_exception(McpServerCrashed("server shut down"))
        self._pending.clear()
        for t in (self._reader_task, self._stderr_task):
            if t and not t.done():
                t.cancel()

    async def _read_loop(self) -> None:
        proc = self._proc
        if proc is None or proc.stdout is None:
            return
        try:
            while True:
                chunk = await proc.stdout.read(64 * 1024)
                if not chunk:
                    break
                try:
                    for msg in self._inbound.feed(chunk):
                        self._dispatch(msg)
                except McpProtocolError as e:
                    self.audit("mcp.protocol.violation", {
                        "server": self.cfg.name, "error": str(e)[:200],
                    })
                    logger.warning("mcp protocol violation: %s", e)
                    # Hard fail — protocol corruption usually means
                    # malicious or broken server. Tear it down.
                    asyncio.create_task(self.shutdown())
                    return
        except asyncio.CancelledError:
            return
        except Exception:
            logger.exception("mcp read loop crashed")

    async def _drain_stderr(self) -> None:
        proc = self._proc
        if proc is None or proc.stderr is None:
            return
        try:
            while True:
                line = await proc.stderr.readline()
                if not line:
                    break
                self.audit("mcp.stderr", {
                    "server": self.cfg.name,
                    "line": line.decode("utf-8", "replace").rstrip()[:4000],
                })
        except asyncio.CancelledError:
            return
        except Exception:
            pass

    def _dispatch(self, msg: Any) -> None:
        if isinstance(msg, JsonRpcResponse):
            fut = self._pending.pop(msg.id, None)
            if fut is None or fut.done():
                return
            if msg.error is not None:
                fut.set_exception(
                    McpServerCrashed(f"rpc error: {msg.error.code} {msg.error.message}")
                )
            else:
                fut.set_result(msg.result or {})
            return
        # Notifications / server-initiated requests are ignored in v1.
        # We don't expose sampling/createMessage or roots/list yet —
        # those let the server steer our LLM and need their own approval
        # gates before we wire them up.
