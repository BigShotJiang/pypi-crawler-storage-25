"""MCP → ToolRegistry bridge (round-18).

Wraps a connected `McpServer`'s tool list as `Tool` objects the agent
loop can call. Two-level laziness:

  • Registration phase (eager-cheap): `tools/list` returns name +
    description + input_schema for every tool the server exposes.
    We register one `McpProxyTool` per entry whose `description` is a
    1-line summary and whose `schema` is `{}` (empty parameters).
    The model sees only the names.

  • First-call phase (lazy-expensive): when the model calls a tool,
    we fetch the FULL `input_schema` from the server response we
    already cached, and pass the args verbatim to `tools/call`.

The token-bloat fix from competitive research (Claude Code's loudest
criticism) is that tool definitions don't ride every prompt — only
the active server's tool *names* do. Schemas are kept locally and
re-attached to the OpenAI-shape dict only when the model actually
invokes the tool's name.
"""
from __future__ import annotations

from typing import Any

from prometheus.mcp.server import McpServer
from prometheus.tools.base import (
    SideEffect, Tool, ToolContext, ToolResult,
)


class McpProxyTool(Tool):
    """A `Tool` that forwards every call to an MCP server's `tools/call`.

    Defaults to the lazy-loaded shape: `description` is a short summary,
    `schema` is the empty `{}` so the model can't produce structured
    args until it sees the full schema. To upgrade to fully-loaded
    (so the model can produce args), call `expand_schema()` once.
    """

    side_effect = SideEffect.WRITE  # MCP tools may have side effects;
    #                                 conservative default. Per-server
    #                                 trust + consent gate the call,
    #                                 so this just fences off
    #                                 acceptEdits skipping for them.

    def __init__(
        self, *, server_name: str, tool_name: str, summary: str,
        full_schema: dict, server: McpServer,
    ) -> None:
        # Public name uses `mcp__<server>__<tool>` — matches Claude
        # Code's permission-rule convention so existing rules-engine
        # paths apply unmodified.
        self.name = f"mcp__{server_name}__{tool_name}"
        self.description = summary or f"MCP tool {tool_name} on server {server_name}"
        self.schema: dict[str, Any] = {}  # empty by default — lazy
        self._server_name = server_name
        self._tool_name = tool_name
        self._full_schema = full_schema or {"type": "object", "properties": {}}
        self._server = server
        self._expanded = False

    def expand_schema(self) -> None:
        """Promote the lazy 1-line description to the full input_schema.

        Called by the agent on first invocation. Subsequent calls
        no-op. Once expanded, the model can also produce structured
        args for this tool — but only if the server is still alive.
        """
        if self._expanded:
            return
        self.schema = self._full_schema
        self._expanded = True

    def receipt_label(self, args: dict[str, Any]) -> str:
        return f"MCP {self._server_name}/{self._tool_name}"

    async def execute(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult:
        # Always expand on first call so subsequent prompts see the
        # full schema and can produce well-typed args.
        if not self._expanded:
            self.expand_schema()
        try:
            resp = await self._server.call(
                "tools/call",
                {"name": self._tool_name, "arguments": args or {}},
            )
        except Exception as e:
            return ToolResult(
                output=f"MCP call failed: {e}",
                error=True,
                summary=f"{self.name} error",
            )
        # Per spec, content is a list of {type, text, ...} blocks.
        content = (resp or {}).get("content") or []
        if isinstance(content, list):
            parts: list[str] = []
            for block in content:
                if isinstance(block, dict) and block.get("type") == "text":
                    parts.append(str(block.get("text", "")))
                elif isinstance(block, dict):
                    parts.append(f"[{block.get('type','?')} block]")
            text = "\n".join(parts) if parts else "(no content)"
        else:
            text = str(content)
        is_error = bool((resp or {}).get("isError"))
        return ToolResult(
            output=text,
            error=is_error,
            summary=f"{self._tool_name}{' (err)' if is_error else ''}",
        )


async def register_mcp_server(
    registry: Any, server_name: str, server: McpServer, *, lazy: bool = True,
) -> list[str]:
    """List tools on `server` and register an `McpProxyTool` for each.

    Returns the registered tool names. With `lazy=True` (default), the
    proxy tools start with empty `schema` — the agent only sees their
    names. With `lazy=False`, schemas are eager-loaded so the model
    can produce args immediately at the cost of prompt-token volume.
    """
    try:
        listing = await server.call("tools/list")
    except Exception:
        return []
    tools = (listing or {}).get("tools") or []
    names: list[str] = []
    for entry in tools:
        if not isinstance(entry, dict):
            continue
        tname = str(entry.get("name") or "")
        if not tname:
            continue
        summary = str(entry.get("description") or "").splitlines()
        summary_line = summary[0] if summary else ""
        proxy = McpProxyTool(
            server_name=server_name, tool_name=tname,
            summary=summary_line[:200],
            full_schema=entry.get("inputSchema") or {},
            server=server,
        )
        if not lazy:
            proxy.expand_schema()
        registry.register(proxy)
        names.append(proxy.name)
    return names
