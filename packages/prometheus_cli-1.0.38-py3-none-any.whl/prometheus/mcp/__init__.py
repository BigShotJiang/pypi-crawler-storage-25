"""PrometheUS MCP integration — stdio servers, v1.

Defends against the CVE-2025-6514 attack class by:
  • forbidding remote transports entirely in v1
  • validating every server response against a closed-schema codec
    (any unknown top-level field, including the `authorization_endpoint`
    used in the original exploit, is rejected at framing layer)
  • requiring per-server-per-project consent + binary-hash pinning
  • opt-in only via /mcp slash commands; no implicit autoload
"""
from .config import McpServerConfig, SandboxLimits, hash_binary, load_config
from .consent import McpConsent, get_consent, grant_consent, revoke_consent
from .errors import (
    McpConsentDenied, McpError, McpProtocolError,
    McpSandboxError, McpServerCrashed, McpTimeout,
)
from .protocol import (
    JsonRpcCodec, JsonRpcNotification, JsonRpcRequest, JsonRpcResponse,
    MAX_MESSAGE_BYTES, MAX_DEPTH, MAX_METHOD_LEN,
)
from .server import McpServer, ServerState
from .bridge import McpProxyTool, register_mcp_server

PROTOCOL_VERSION = "2025-06-18"

__all__ = [
    "McpServerConfig", "SandboxLimits", "hash_binary", "load_config",
    "McpConsent", "get_consent", "grant_consent", "revoke_consent",
    "McpConsentDenied", "McpError", "McpProtocolError",
    "McpSandboxError", "McpServerCrashed", "McpTimeout",
    "JsonRpcCodec", "JsonRpcNotification", "JsonRpcRequest", "JsonRpcResponse",
    "MAX_MESSAGE_BYTES", "MAX_DEPTH", "MAX_METHOD_LEN",
    "McpServer", "ServerState",
    "McpProxyTool", "register_mcp_server",
    "PROTOCOL_VERSION",
]
