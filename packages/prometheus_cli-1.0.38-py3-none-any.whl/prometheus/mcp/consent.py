"""Per-server-per-project MCP consent, persisted in ~/.prometheus/trust.json
under an `mcp_servers` block. Independent of workspace trust — even a
trusted workspace requires explicit consent for each MCP server because
the server is an opaque external binary.

A consent record is keyed on (workspace_abs_path, server_name, binary_sha256).
If the binary's hash changes (new install, file-replace attack), consent
is invalidated and the user is re-prompted.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path

from prometheus.config import USER_CONFIG_DIR


_TRUST_FILE = USER_CONFIG_DIR / "trust.json"


@dataclass
class McpConsent:
    workspace: str
    server_name: str
    binary_sha256: str
    approved_tools: set[str] = field(default_factory=set)
    denied_tools: set[str] = field(default_factory=set)
    session_only: bool = False


def _load_blob() -> dict:
    if not _TRUST_FILE.exists():
        return {}
    try:
        return json.loads(_TRUST_FILE.read_text(encoding="utf-8")) or {}
    except Exception:
        return {}


def _save_blob(data: dict) -> None:
    _TRUST_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = _TRUST_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    tmp.replace(_TRUST_FILE)


def _ws_key(workspace: Path | str) -> str:
    return str(Path(workspace).resolve())


def get_consent(workspace: Path | str, server_name: str, binary_sha256: str) -> McpConsent | None:
    blob = _load_blob()
    mcp = (blob.get("mcp_servers") or {}).get(_ws_key(workspace)) or {}
    rec = mcp.get(server_name)
    if not isinstance(rec, dict):
        return None
    if rec.get("binary_sha256") != binary_sha256:
        # Hash drift → consent invalidated. User must re-approve.
        return None
    return McpConsent(
        workspace=_ws_key(workspace),
        server_name=server_name,
        binary_sha256=binary_sha256,
        approved_tools=set(rec.get("approved_tools") or []),
        denied_tools=set(rec.get("denied_tools") or []),
        session_only=bool(rec.get("session_only", False)),
    )


def grant_consent(consent: McpConsent) -> None:
    blob = _load_blob()
    mcp = blob.setdefault("mcp_servers", {})
    ws = mcp.setdefault(consent.workspace, {})
    ws[consent.server_name] = {
        "binary_sha256": consent.binary_sha256,
        "approved_tools": sorted(consent.approved_tools),
        "denied_tools": sorted(consent.denied_tools),
        "session_only": consent.session_only,
        "approved_at": _utc_now(),
    }
    _save_blob(blob)


def revoke_consent(workspace: Path | str, server_name: str) -> None:
    blob = _load_blob()
    mcp = blob.get("mcp_servers") or {}
    ws = mcp.get(_ws_key(workspace)) or {}
    if server_name in ws:
        del ws[server_name]
        _save_blob(blob)


def _utc_now() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()
