"""Declarative MCP server config (~/.prometheus/mcp.json).

Schema (single source of truth — anything else is rejected):

    {
      "version": 1,
      "servers": {
        "ripgrep": {
          "command": "/usr/local/bin/rg-mcp",  # ABSOLUTE path required
          "args": ["--root", "${WORKSPACE}"],
          "env": {"RUST_LOG": "warn"},
          "cwd": "${WORKSPACE}",
          "timeout_ms": 30000,
          "max_restarts": 3,
          "sandbox": {
            "rlimit_as_mb": 512,
            "rlimit_nofile": 256,
            "rlimit_cpu_sec": 60
          }
        }
      }
    }

Supply-chain hardening:
- `command` MUST be an absolute filesystem path. We never invoke npx,
  uvx, or any package resolver.
- Server name must match ^[a-z0-9_-]{1,32}$.
- Unknown keys are rejected with a clear error.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

from prometheus.mcp.errors import McpError


_NAME_RX = re.compile(r"^[a-z0-9_-]{1,32}$")


@dataclass(frozen=True, slots=True)
class SandboxLimits:
    rlimit_as_mb: int = 512
    rlimit_nofile: int = 256
    rlimit_cpu_sec: int = 60
    allow_network: bool = False
    extra_read_paths: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class McpServerConfig:
    name: str
    command: str
    args: tuple[str, ...] = ()
    env: Mapping[str, str] = field(default_factory=dict)
    cwd: str | None = None
    timeout_ms: int = 30_000
    max_restarts: int = 3
    sandbox: SandboxLimits = field(default_factory=SandboxLimits)


def _expand(value: str, *, workspace: Path) -> str:
    """Expand ${WORKSPACE} and ${HOME} only — no general env expansion
    (would let a hostile env var smuggle data into the server's argv)."""
    home = str(Path.home())
    return (
        value
        .replace("${WORKSPACE}", str(workspace))
        .replace("${HOME}", home)
    )


def _parse_sandbox(raw: dict[str, Any]) -> SandboxLimits:
    allowed = {
        "rlimit_as_mb", "rlimit_nofile", "rlimit_cpu_sec",
        "allow_network", "extra_read_paths",
    }
    extras = set(raw.keys()) - allowed
    if extras:
        raise McpError(f"unknown sandbox keys: {sorted(extras)}")
    return SandboxLimits(
        rlimit_as_mb=int(raw.get("rlimit_as_mb", 512)),
        rlimit_nofile=int(raw.get("rlimit_nofile", 256)),
        rlimit_cpu_sec=int(raw.get("rlimit_cpu_sec", 60)),
        allow_network=bool(raw.get("allow_network", False)),
        extra_read_paths=tuple(raw.get("extra_read_paths", []) or ()),
    )


def _parse_server(name: str, raw: dict[str, Any], workspace: Path) -> McpServerConfig:
    if not _NAME_RX.match(name):
        raise McpError(f"invalid server name: {name!r}")
    allowed = {
        "command", "args", "env", "cwd", "timeout_ms",
        "max_restarts", "sandbox",
    }
    extras = set(raw.keys()) - allowed
    if extras:
        raise McpError(f"unknown server keys for {name}: {sorted(extras)}")
    cmd = str(raw.get("command", ""))
    if not cmd:
        raise McpError(f"server {name}: missing 'command'")
    cmd = _expand(cmd, workspace=workspace)
    if not Path(cmd).is_absolute():
        raise McpError(
            f"server {name}: 'command' must be an absolute path "
            f"(got {cmd!r}). PrometheUS never resolves package managers."
        )
    args = tuple(_expand(str(a), workspace=workspace) for a in raw.get("args", []) or ())
    env = {str(k): _expand(str(v), workspace=workspace)
           for k, v in (raw.get("env") or {}).items()}
    cwd = raw.get("cwd")
    cwd = _expand(str(cwd), workspace=workspace) if cwd else None
    sandbox = _parse_sandbox(raw.get("sandbox") or {})
    return McpServerConfig(
        name=name, command=cmd, args=args, env=env, cwd=cwd,
        timeout_ms=int(raw.get("timeout_ms", 30_000)),
        max_restarts=int(raw.get("max_restarts", 3)),
        sandbox=sandbox,
    )


def load_config(
    path: Path | None = None,
    workspace: Path | None = None,
) -> dict[str, McpServerConfig]:
    """Load + validate the user's MCP config. Returns empty dict if no
    file is present (running without MCP is the default).

    Round 178: when no explicit `path` is given, walks the full
    Claude-Code-compatible hierarchy. Highest-precedence layer wins
    on name collision.

      1. <workspace>/.mcp.json             (project root, CC convention,
                                             shared across collaborators)
      2. <workspace>/.claude/mcp.json      (project, CC)
      3. <workspace>/.prometheus/mcp.json  (project, native)
      4. ~/.claude/mcp.json                (user, CC)
      5. ~/.prometheus/mcp.json            (user, native)

    Top-level key is either `servers` (native) or `mcpServers`
    (Claude Code convention). A user copying their CC config keeps
    every server registered without renaming the field.
    """
    workspace = workspace or Path.cwd()
    candidates: list[Path]
    if path is not None:
        candidates = [path]
    else:
        candidates = [
            workspace / ".mcp.json",
            workspace / ".claude" / "mcp.json",
            workspace / ".prometheus" / "mcp.json",
            Path.home() / ".claude" / "mcp.json",
            Path.home() / ".prometheus" / "mcp.json",
        ]
    out: dict[str, McpServerConfig] = {}
    for candidate in candidates:
        if not candidate.exists() or not candidate.is_file():
            continue
        try:
            raw = candidate.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if not raw.strip():
            continue
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as e:
            # Explicit path: surface the parse error.
            # Implicit hierarchy: skip silently so a single bad file
            # doesn't break every other config layer.
            if path is not None:
                raise McpError(f"{candidate}: {e}") from e
            continue
        if not isinstance(data, dict):
            if path is not None:
                raise McpError(f"{candidate}: top-level must be object")
            continue
        servers_raw = data.get("mcpServers") or data.get("servers") or {}
        if not isinstance(servers_raw, dict):
            if path is not None:
                raise McpError(f"{candidate}: 'mcpServers' must be object")
            continue
        for name, server_raw in servers_raw.items():
            if name in out:
                # Higher-precedence layer already supplied this name.
                continue
            if not isinstance(server_raw, dict):
                raise McpError(f"{candidate}: server {name!r} must be object")
            out[name] = _parse_server(name, server_raw, workspace)
    return out


def hash_binary(path: str) -> str:
    """SHA-256 of the binary at `path`. Used to pin consent — when the
    binary's hash changes, consent is invalidated and the user is
    re-prompted (file-replace attack defense)."""
    import hashlib
    h = hashlib.sha256()
    p = Path(path)
    if not p.exists() or not p.is_file():
        return ""
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(64 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()
