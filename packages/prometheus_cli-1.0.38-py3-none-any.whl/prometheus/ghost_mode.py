"""Round 138: `/ghost` — Ghost Writer mode.

Strips AI hedging, filler, and corporate tone from output.
When active, Claude writes like a senior engineer:

  * No "Certainly!" / "I'd be happy to" / "Let me…" preambles
  * No "I hope this helps!" / "Feel free to ask" suffixes
  * No "Great question!" / "That's a fascinating point"
  * No softening hedges ("perhaps", "might be", "could potentially")
  * Direct declarative sentences. Code first, prose minimal.

Mid-session toggle. Status bar shows `GHOST` chip while active.
The system prompt builder reads `ghost_mode_active()` and
prepends the ghost block when on.
"""
from __future__ import annotations

import os
from dataclasses import dataclass


GHOST_PROMPT_BLOCK = (
    "GHOST WRITER MODE — write like a senior engineer:\n"
    "• No 'Certainly!', 'I'd be happy to', 'Let me…' preambles.\n"
    "• No 'I hope this helps!', 'Feel free to ask' suffixes.\n"
    "• No 'Great question!', flattery, or AI-hedging phrases.\n"
    "• No softeners ('perhaps', 'might be', 'could potentially')\n"
    "  unless genuine uncertainty.\n"
    "• Lead with the answer. Code blocks first; prose minimal.\n"
    "• Direct declarative sentences. Skip the conclusion paragraph.\n"
)


@dataclass
class GhostMode:
    enabled: bool = False


def ghost_mode_active() -> bool:
    """Round 138: env-flag check; subprocess agents inherit it."""
    return os.environ.get(
        "PROMETHEUS_GHOST_MODE", "",
    ).strip().lower() in ("1", "true", "yes")


def enable_ghost(state: GhostMode) -> GhostMode:
    state.enabled = True
    os.environ["PROMETHEUS_GHOST_MODE"] = "1"
    return state


def disable_ghost(state: GhostMode) -> GhostMode:
    state.enabled = False
    os.environ["PROMETHEUS_GHOST_MODE"] = "0"
    return state


def status_chip(state: GhostMode) -> str:
    return "GHOST" if state.enabled else ""


# ---------- post-hoc text scrubber ----------


_FILLER_PHRASES = (
    "Certainly!",
    "Certainly,",
    "Of course!",
    "Of course,",
    "Sure!",
    "Sure thing!",
    "Absolutely!",
    "I'd be happy to",
    "I'd be glad to",
    "Happy to help",
    "Let me help you",
    "Let me explain",
    "I hope this helps!",
    "I hope this helps",      # round 156: matches "I hope this helps you get started!"
    "Hope that helps",
    "Feel free to ask",
    "Don't hesitate to ask",
    "Let me know if",
    "Great question!",
    "That's a fascinating",
    "That's a great",
    "Excellent question",
    "What a great",
)


def scrub_text(text: str) -> str:
    """Round 138 + 153 + 156: post-stream scrubber.

    Two passes, evaluated against the *original* line:
      1. **Drop**: if the line starts with a filler phrase AND the
         whole line is short (under `len(phrase) + 30`), the line
         is filler-only — drop it. Catches `"Certainly!"`,
         `"I hope this helps you get started!"`, etc.
      2. **Strip**: otherwise, if the line starts with a filler
         phrase but is too long to be filler-only (filler prefix
         on real content), strip just the leading phrase + its
         trailing punctuation. Keep the rest of the line so we
         don't lose actual answer text.

    The system prompt is the primary mechanism — this is a
    belt-and-braces fallback when the model still leaks filler."""
    if not text:
        return text
    out_lines: list[str] = []
    for line in text.split("\n"):
        stripped = line.strip()
        if not stripped:
            out_lines.append(line)
            continue
        # Pass 1 (evaluated first): drop short filler-only lines.
        # Round 156: this must run BEFORE the prefix-strip pass so
        # the threshold check sees the original line length.
        skip = False
        for phrase in _FILLER_PHRASES:
            if stripped.startswith(phrase) and len(stripped) < (
                len(phrase) + 30
            ):
                skip = True
                break
        if skip:
            continue
        # Pass 2: long lines that start with filler — strip the
        # leading phrase + its punctuation, keep the rest.
        for phrase in _FILLER_PHRASES:
            if stripped.startswith(phrase):
                rest = stripped[len(phrase):].lstrip(" ,.;:!?-—–")
                if rest:
                    indent = line[:len(line) - len(line.lstrip())]
                    line = indent + rest
                break
        out_lines.append(line)
    return "\n".join(out_lines)
