# csrd-models

Shared Pydantic models, settings, and parsing utilities for FastAPI microservices.

**Package**: `csrd.models` · **Import**: `from csrd.models import BaseModel, BaseSettings`

## What's included

- `BaseModel` / `BaseSettings` with camelCase alias config and `populate_by_name=True`
- `ModelParserMixin` — response parsing mixin for delegates and repositories
- `PayloadExtractor` / `DefaultExtractor` — pluggable payload extraction
- `UserClaims` — JWT user claims dataclass
- `APIErrorResponse`, `ErrorMeta`, `Error`, `APIVersion` — structured error response models

## Installation

```bash
uv pip install "csrd-models @ git+ssh://git@github.com/csrd-api/fastapi-common.git#subdirectory=packages/models"
```

## Dependencies

None (Tier 1 — standalone)
