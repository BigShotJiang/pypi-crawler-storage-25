# manywe-crypto

Official ManyWe placeholder package for future crypto-related integration work.

Current utilities:
- normalize hexadecimal key material
- validate fixed-size hex strings
- format byte lengths for integration checks

This package is intentionally small and is not a production cryptography implementation.
