PACKAGE_NAME = "manywe-crypto"
__version__ = "0.0.1"


def normalize_hex(value: str) -> str:
    if not isinstance(value, str):
        raise TypeError("expected a string")
    value = value.strip().lower()
    return value[2:] if value.startswith("0x") else value


def is_fixed_hex(value: str, byte_length: int) -> bool:
    value = normalize_hex(value)
    return byte_length > 0 and len(value) == byte_length * 2 and all(c in "0123456789abcdef" for c in value)


def require_fixed_hex(value: str, byte_length: int) -> str:
    normalized = normalize_hex(value)
    if not is_fixed_hex(normalized, byte_length):
        raise ValueError(f"expected {byte_length}-byte hex string")
    return normalized


def format_byte_length(byte_length: int) -> str:
    if byte_length < 0:
        raise ValueError("byte_length must be non-negative")
    suffix = "" if byte_length == 1 else "s"
    return f"{byte_length} byte{suffix}"
