"""Application configuration loaded from a .env file."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Runtime configuration read from environment variables / .env file.

    Minimal required fields:
        MICROSOFT_CLIENT_ID  – Azure app registration client ID
        MICROSOFT_TENANT_ID  – tenant ID or "common" for multi-tenant
        MICROSOFT_CLIENT_SECRET – required for client_credentials mode;
                                   optional for device_code mode

    Optional fields control token storage, timezone, and defaults.
    """

    # ── Azure App Registration ──────────────────────────────────────────────
    microsoft_client_id: str = Field(..., alias="MICROSOFT_CLIENT_ID")
    microsoft_client_secret: str | None = Field(
        default=None, alias="MICROSOFT_CLIENT_SECRET"
    )
    microsoft_tenant_id: str = Field("common", alias="MICROSOFT_TENANT_ID")

    # ── Authentication mode ─────────────────────────────────────────────────
    # "device_code"        – interactive browser login; refresh token cached locally
    # "client_credentials" – headless service-account; requires client_secret +
    #                         admin-consented application permissions
    microsoft_auth_mode: Literal["device_code", "client_credentials"] = Field(
        "device_code", alias="MICROSOFT_AUTH_MODE"
    )

    # ── Token storage ───────────────────────────────────────────────────────
    # Default: ~/.m365/tokens.json  (created automatically)
    token_path: Path = Field(
        default_factory=lambda: Path.home() / ".m365" / "tokens.json",
        alias="TOKEN_PATH",
    )
    # Fernet key (base64, 32-byte).  Auto-generated + saved to ~/.m365/.key
    # if not supplied.  Set this in .env for reproducible encryption.
    token_encryption_key: str | None = Field(
        default=None, alias="TOKEN_ENCRYPTION_KEY"
    )

    # ── User preferences ────────────────────────────────────────────────────
    # IANA timezone string, e.g. "America/Chicago"
    my_timezone: str = Field("UTC", alias="MY_TIMEZONE")
    # How many emails to return when --limit is not specified
    default_email_limit: int = Field(20, alias="DEFAULT_EMAIL_LIMIT")

    model_config = {
        # Search order (later files override earlier ones):
        #   1. ~/.m365/.env  — global config written by `m365 setup`
        #   2. .env          — per-project override in the current working directory
        # This lets the CLI work from any directory after a one-time `m365 setup`.
        "env_file": [str(Path.home() / ".m365" / ".env"), ".env"],
        "env_file_encoding": "utf-8",
        "populate_by_name": True,
        # Ignore unknown env-vars so stray shell variables don't fail validation
        "extra": "ignore",
    }

    @field_validator("microsoft_auth_mode")
    @classmethod
    def _validate_auth_mode(cls, v: str, info: object) -> str:
        return v


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return cached settings instance (reads .env once)."""
    return Settings()
