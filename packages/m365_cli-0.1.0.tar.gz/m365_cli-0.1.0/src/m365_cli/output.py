"""Agent-friendly output helpers.

All successful output is JSON to stdout.
All errors are JSON to stderr + sys.exit with a meaningful code.

Exit codes:
    0  – success
    1  – general error
    2  – authentication required  (agent: re-run `m365 auth login`)
    3  – resource not found
"""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from typing import Any, NoReturn

import click
from rich.console import Console

_err = Console(stderr=True, highlight=False)


# ── Serialization ────────────────────────────────────────────────────────────


def _default(obj: Any) -> Any:
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON-serializable")


def _dump(payload: dict) -> str:
    return json.dumps(payload, indent=2, default=_default)


# ── Success ──────────────────────────────────────────────────────────────────


def emit(data: Any, *, count: int | None = None) -> None:
    """Write a successful result to stdout as JSON and exit 0."""
    payload: dict[str, Any] = {
        "success": True,
        "data": data,
        "fetched_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    }
    if count is not None:
        payload["count"] = count
    click.echo(_dump(payload))


# ── Errors ───────────────────────────────────────────────────────────────────


def emit_error(
    message: str,
    *,
    code: str = "ERROR",
    hint: str | None = None,
    exit_code: int = 1,
) -> NoReturn:
    """Write an error to stderr as JSON and exit with *exit_code*."""
    err: dict[str, Any] = {"code": code, "message": message}
    if hint:
        err["hint"] = hint
    payload = {"success": False, "error": err}
    _err.print_json(_dump(payload))
    sys.exit(exit_code)


def auth_required(hint: str | None = None) -> NoReturn:
    """Shortcut for the 'not authenticated' error (exit code 2)."""
    emit_error(
        "Not authenticated. Run: m365 auth login",
        code="AUTH_REQUIRED",
        hint=hint,
        exit_code=2,
    )


def not_found(resource: str) -> NoReturn:
    """Shortcut for 404-style errors (exit code 3)."""
    emit_error(f"{resource} not found.", code="NOT_FOUND", exit_code=3)


# ── Exception handling helpers ───────────────────────────────────────────────


def handle_graph_error(exc: Exception) -> None:
    """Inspect a Graph / auth exception and emit the right error."""
    msg = str(exc)
    lower = msg.lower()

    if "auth_required" in lower or "refresh" in lower or "token" in lower:
        auth_required(hint=msg)
    if "not found" in lower or "itemnotfound" in lower or "erroritemnotfound" in lower:
        emit_error(msg, code="NOT_FOUND", exit_code=3)

    emit_error(msg, code="GRAPH_ERROR")
