"""Allow running the CLI with ``python -m m365_cli``."""

import sys

from m365_cli.cli import main

sys.exit(main())
