"""Logging configuration for m365-cli.

Writes structured log lines to ~/.m365/m365.log with rotation (5 MB × 3 files).
Console output is intentionally suppressed — all user-facing output is JSON via
the output module.  Agent operators can tail the log file for diagnostics.

Call setup_logging() once from the main CLI group before any command runs.
"""

from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path


_LOG_DIR = Path.home() / ".m365"
_LOG_FILE = _LOG_DIR / "m365.log"
_MAX_BYTES = 5 * 1024 * 1024   # 5 MB per file
_BACKUP_COUNT = 3               # keep 3 rotated files (~15 MB total)
_FMT = "%(asctime)s %(levelname)-8s %(name)s  %(message)s"
_DATE_FMT = "%Y-%m-%dT%H:%M:%S"

_configured = False


def setup_logging(debug: bool = False) -> None:
    """Configure root logger to write to ~/.m365/m365.log.

    Safe to call multiple times — subsequent calls are no-ops.

    Args:
        debug: If True, set level to DEBUG; otherwise INFO.
    """
    global _configured
    if _configured:
        return

    _LOG_DIR.mkdir(parents=True, exist_ok=True)

    handler = logging.handlers.RotatingFileHandler(
        _LOG_FILE,
        maxBytes=_MAX_BYTES,
        backupCount=_BACKUP_COUNT,
        encoding="utf-8",
    )
    handler.setFormatter(logging.Formatter(fmt=_FMT, datefmt=_DATE_FMT))

    root = logging.getLogger()
    root.setLevel(logging.DEBUG if debug else logging.INFO)
    root.addHandler(handler)

    # Quiet noisy SDK loggers unless debug mode is on
    if not debug:
        for noisy in ("httpx", "httpcore", "msal", "azure", "kiota"):
            logging.getLogger(noisy).setLevel(logging.WARNING)

    _configured = True
    logging.getLogger(__name__).debug("Logging initialised → %s", _LOG_FILE)


def log_path() -> Path:
    """Return the path to the active log file."""
    return _LOG_FILE
