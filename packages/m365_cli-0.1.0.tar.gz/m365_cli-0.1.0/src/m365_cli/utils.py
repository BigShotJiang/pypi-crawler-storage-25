"""Shared utilities for m365-cli commands."""

from __future__ import annotations

from datetime import date, datetime, timezone
from zoneinfo import ZoneInfo


def parse_dt(value: str, tz: ZoneInfo) -> datetime:
    """Parse a flexible datetime string into a UTC-aware datetime.

    Accepted formats (all interpreted in *tz*):
      HH:MM                → today at that local time
      HH:MM:SS             → today at that local time (with seconds)
      YYYY-MM-DD           → that date at 00:00:00 local (midnight)
      YYYY-MM-DDTHH:MM     → exact local datetime (T separator)
      YYYY-MM-DD HH:MM     → exact local datetime (space separator)
      YYYY-MM-DDTHH:MM:SS  → exact local datetime with seconds
      YYYY-MM-DD HH:MM:SS  → exact local datetime with seconds

    Args:
        value: The string to parse.
        tz:    The ZoneInfo timezone to interpret naive values in.

    Returns:
        A UTC-aware datetime.

    Raises:
        ValueError: If the string doesn't match any accepted format.
    """
    utc = timezone.utc
    today = date.today()

    # Time-only: HH:MM or HH:MM:SS → today at that time in the user's timezone
    for fmt in ("%H:%M", "%H:%M:%S"):
        try:
            t = datetime.strptime(value, fmt).time()
            return datetime.combine(today, t, tzinfo=tz).astimezone(utc)
        except ValueError:
            pass

    # Date + time (T or space separator, with or without seconds)
    for fmt in (
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
    ):
        try:
            return datetime.strptime(value, fmt).replace(tzinfo=tz).astimezone(utc)
        except ValueError:
            pass

    # Date only → midnight in user's timezone
    try:
        return (
            datetime.strptime(value, "%Y-%m-%d")
            .replace(hour=0, minute=0, second=0, tzinfo=tz)
            .astimezone(utc)
        )
    except ValueError:
        pass

    raise ValueError(
        f"Cannot parse '{value}'. "
        "Use HH:MM, YYYY-MM-DD, YYYY-MM-DDTHH:MM, or YYYY-MM-DD HH:MM."
    )
