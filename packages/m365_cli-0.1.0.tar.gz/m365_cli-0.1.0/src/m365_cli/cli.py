"""m365 — Agent-friendly Microsoft 365 CLI.

All commands output structured JSON to stdout.
Errors are JSON to stderr with a non-zero exit code.

Exit codes:
  0  success
  1  error
  2  authentication required  →  run: m365 auth login
  3  resource not found

Configuration:
  Drop a .env file in the working directory (or set environment variables):

    MICROSOFT_CLIENT_ID=...
    MICROSOFT_TENANT_ID=...          # or "common"
    MICROSOFT_CLIENT_SECRET=...      # optional for device_code; required for
                                     # client_credentials
    MICROSOFT_AUTH_MODE=device_code  # or client_credentials
    MY_TIMEZONE=America/Chicago      # for display; all API times are UTC
    DEFAULT_EMAIL_LIMIT=20
"""

import sys

import click

from m365_cli import __version__
from m365_cli.commands.auth import auth_group
from m365_cli.commands.calendar import calendar_group
from m365_cli.commands.email import email_group
from m365_cli.commands.people import people_group
from m365_cli.commands.setup import setup_cmd
from m365_cli.logging_config import setup_logging


@click.group()
@click.version_option(version=__version__)
@click.option("--debug", is_flag=True, default=False, hidden=True,
              help="Enable DEBUG-level logging to ~/.m365/m365.log.")
@click.pass_context
def main(ctx: click.Context, debug: bool) -> None:
    """Microsoft 365 CLI — agent-friendly access to email and calendar."""
    ctx.ensure_object(dict)
    setup_logging(debug=debug)


main.add_command(auth_group)
main.add_command(email_group)
main.add_command(calendar_group)
main.add_command(people_group)
main.add_command(setup_cmd)


if __name__ == "__main__":
    sys.exit(main())
