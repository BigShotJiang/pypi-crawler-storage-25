"""Async retry utility for transient Microsoft Graph API errors.

Retries on:
  - HTTP 429 (rate-limited) — respects Retry-After header
  - HTTP 500 / 503 / 504 (transient server errors)
  - Network-level failures (timeout, connection reset)

Usage:
    from m365_cli.retry import with_retry
    result = await with_retry(lambda: client.me.messages.get(...))
"""

from __future__ import annotations

import asyncio
import logging
from typing import Awaitable, Callable, TypeVar

logger = logging.getLogger(__name__)

T = TypeVar("T")

_RETRYABLE_STATUS_CODES = {429, 500, 503, 504}


# ── Exception introspection ───────────────────────────────────────────────────


def _status_code(exc: Exception) -> int | None:
    """Extract HTTP status code from a kiota / Graph SDK exception."""
    code = getattr(exc, "response_status_code", None)
    if code is not None:
        try:
            return int(code)
        except (TypeError, ValueError):
            pass
    return None


def _retry_after_seconds(exc: Exception) -> float | None:
    """Return Retry-After value in seconds from exception headers, if present."""
    headers: dict = getattr(exc, "response_headers", None) or {}
    val = headers.get("Retry-After") or headers.get("retry-after")
    try:
        return float(val) if val is not None else None
    except (TypeError, ValueError):
        return None


def _is_retryable(exc: Exception) -> bool:
    code = _status_code(exc)
    if code is not None:
        return code in _RETRYABLE_STATUS_CODES
    # Network-level errors from httpx / kiota transport
    name = type(exc).__name__
    return any(k in name for k in ("Timeout", "Connect", "Network", "Transport"))


# ── Public API ────────────────────────────────────────────────────────────────


async def with_retry(
    fn: Callable[[], Awaitable[T]],
    *,
    max_attempts: int = 4,
    base_delay: float = 1.0,
) -> T:
    """Invoke async *fn*, retrying on transient errors with exponential backoff.

    Args:
        fn:           Zero-argument async callable (use a lambda or functools.partial).
        max_attempts: Maximum number of total attempts (default 4 → up to 3 retries).
        base_delay:   Base wait in seconds; doubled each attempt (1 → 2 → 4 …).

    Raises:
        The last exception if all attempts are exhausted, or immediately if the
        error is not considered transient.
    """
    last_exc: Exception = RuntimeError("with_retry: no attempts made")

    for attempt in range(max_attempts):
        try:
            return await fn()
        except Exception as exc:
            if not _is_retryable(exc):
                raise

            last_exc = exc
            remaining = max_attempts - attempt - 1

            if remaining == 0:
                break

            wait = _retry_after_seconds(exc) or base_delay * (2**attempt)
            logger.warning(
                "Transient Graph error on attempt %d/%d — retrying in %.1fs: %s",
                attempt + 1,
                max_attempts,
                wait,
                exc,
            )
            await asyncio.sleep(wait)

    raise last_exc
