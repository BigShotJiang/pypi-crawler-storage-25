"""m365 email — email commands."""

from __future__ import annotations

import asyncio
from datetime import datetime
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import click

from m365_cli import output
from m365_cli.auth.manager import AuthManager
from m365_cli.auth.token_store import TokenStore
from m365_cli.config import get_settings
from m365_cli.graph import email as graph_email
from m365_cli.graph.client import get_graph_client
from m365_cli.utils import parse_dt


def _get_settings_or_exit():
    try:
        return get_settings()
    except Exception as exc:
        output.emit_error(
            f"Configuration error: {exc}",
            code="CONFIG_ERROR",
            hint="Ensure MICROSOFT_CLIENT_ID is set in your .env file.",
        )


def _graph_client():
    settings = _get_settings_or_exit()
    store = TokenStore(settings.token_path, settings.token_encryption_key)
    manager = AuthManager(settings, store)
    if not manager.is_authenticated():
        output.auth_required()
    return get_graph_client(settings, manager)


def _resolve_window(
    *,
    since_str: str | None,
    until_str: str | None,
) -> tuple[datetime | None, datetime | None]:
    settings = _get_settings_or_exit()
    try:
        tz = ZoneInfo(settings.my_timezone)
    except (ZoneInfoNotFoundError, KeyError):
        output.emit_error(
            f"Unknown timezone '{settings.my_timezone}'. "
            "Set MY_TIMEZONE to a valid IANA name (e.g. America/Chicago).",
            code="CONFIG_ERROR",
        )

    since: datetime | None = None
    until: datetime | None = None
    if since_str:
        try:
            since = parse_dt(since_str, tz)
        except ValueError as exc:
            output.emit_error(str(exc), code="INVALID_INPUT")
    if until_str:
        try:
            until = parse_dt(until_str, tz)
        except ValueError as exc:
            output.emit_error(str(exc), code="INVALID_INPUT")
    if since and until and since >= until:
        output.emit_error(
            f"--since ({since_str}) must be before --until ({until_str}).",
            code="INVALID_INPUT",
        )
    return since, until


def _normalize_limit(limit: int | None, since: datetime | None, until: datetime | None) -> int | None:
    settings = _get_settings_or_exit()
    if (since or until) and limit is None:
        return None
    return limit or settings.default_email_limit


@click.group("email")
def email_group() -> None:
    """Read and manage Microsoft 365 email."""


@email_group.command("list")
@click.option("--limit", "-n", default=None, type=int,
              help="Max emails to return. Omit with a time filter to fetch all matches.")
@click.option("--unread-only", is_flag=True, default=False, help="Only unread messages.")
@click.option("--since", "since_str", default=None, metavar="TIME",
              help="Start of time window. Accepts HH:MM, YYYY-MM-DD, or YYYY-MM-DDTHH:MM.")
@click.option("--until", "until_str", default=None, metavar="TIME",
              help="End of time window. Same formats as --since.")
@click.option("--include-body", is_flag=True, default=False,
              help="Include full message body in each result instead of preview-only scan output.")
def email_list(
    limit: int | None,
    unread_only: bool,
    since_str: str | None,
    until_str: str | None,
    include_body: bool,
) -> None:
    """List emails from the inbox.

    Default output is a quick scan: message metadata plus `preview`.
    Use `--include-body` for full bodies inline, or `email read <message-id>`
    to fetch one message in detail.
    """
    since, until = _resolve_window(since_str=since_str, until_str=until_str)
    resolved_limit = _normalize_limit(limit, since, until)

    async def _run():
        return await graph_email.fetch_emails(
            _graph_client(),
            limit=resolved_limit,
            unread_only=unread_only,
            since=since,
            until=until,
            include_body=include_body,
        )

    try:
        emails = asyncio.run(_run())
        output.emit(emails, count=len(emails))
    except Exception as exc:
        output.handle_graph_error(exc)


@email_group.command("search")
@click.option("--query", required=True, help="Case-insensitive mailbox query.")
@click.option("--folder", default=None, help="Folder name or ID to scope the search.")
@click.option("--limit", "-n", default=20, type=int, help="Max results to return.")
@click.option("--unread-only", is_flag=True, default=False, help="Only unread messages.")
@click.option("--since", "since_str", default=None, metavar="TIME")
@click.option("--until", "until_str", default=None, metavar="TIME")
def email_search(
    query: str,
    folder: str | None,
    limit: int,
    unread_only: bool,
    since_str: str | None,
    until_str: str | None,
) -> None:
    """Search messages with practical mailbox filters.

    Returns summary results for quick scanning. Use `email read <message-id>`
    on a returned ID to fetch the full body.
    """
    since, until = _resolve_window(since_str=since_str, until_str=until_str)

    async def _run():
        return await graph_email.fetch_emails(
            _graph_client(),
            limit=limit,
            unread_only=unread_only,
            since=since,
            until=until,
            include_body=False,
            folder=folder,
            query=query,
        )

    try:
        emails = asyncio.run(_run())
        output.emit(emails, count=len(emails))
    except Exception as exc:
        output.handle_graph_error(exc)


@email_group.command("folders")
def email_folders() -> None:
    """List mail folders."""

    async def _run():
        return await graph_email.list_mail_folders(_graph_client())

    try:
        folders = asyncio.run(_run())
        output.emit(folders, count=len(folders))
    except Exception as exc:
        output.handle_graph_error(exc)


@email_group.command("read")
@click.argument("message_id")
def email_read(message_id: str) -> None:
    """Fetch a single email by Graph message ID, including the full body."""

    async def _run():
        return await graph_email.fetch_email_by_id(_graph_client(), message_id)

    try:
        msg = asyncio.run(_run())
        output.emit(msg)
    except Exception as exc:
        output.handle_graph_error(exc)


@email_group.command("thread")
@click.argument("message_id")
def email_thread(message_id: str) -> None:
    """Fetch all messages in the same conversation."""

    async def _run():
        return await graph_email.fetch_thread(_graph_client(), message_id)

    try:
        thread = asyncio.run(_run())
        output.emit(thread, count=len(thread["messages"]))
    except Exception as exc:
        output.handle_graph_error(exc)


@email_group.command("send")
@click.option("--to", "recipients", multiple=True, required=True, help="Recipient address.")
@click.option("--subject", required=True, help="Email subject.")
@click.option("--body", required=True, help="Email body text.")
@click.option("--html", "use_html", is_flag=True, default=False, help="Treat body as HTML.")
@click.option("--file", "file_paths", multiple=True, help="Attach a local file.")
def email_send(
    recipients: tuple[str, ...],
    subject: str,
    body: str,
    use_html: bool,
    file_paths: tuple[str, ...],
) -> None:
    """Send an email."""

    async def _run():
        await graph_email.send_email(
            _graph_client(),
            to=list(recipients),
            subject=subject,
            body=body,
            body_type="html" if use_html else "text",
            file_paths=list(file_paths),
        )

    try:
        asyncio.run(_run())
        output.emit(
            {
                "status": "sent",
                "to": list(recipients),
                "subject": subject,
                "attachments_added": len(file_paths),
            }
        )
    except Exception as exc:
        output.handle_graph_error(exc)


@email_group.command("mark-read")
@click.argument("message_id")
def email_mark_read(message_id: str) -> None:
    """Mark an email as read."""

    async def _run():
        await graph_email.mark_as_read(_graph_client(), message_id)

    try:
        asyncio.run(_run())
        output.emit({"status": "marked_read", "message_id": message_id})
    except Exception as exc:
        output.handle_graph_error(exc)


@email_group.command("move")
@click.argument("message_id")
@click.option("--folder", "folder_ref", required=True, help="Destination folder name or ID.")
def email_move(message_id: str, folder_ref: str) -> None:
    """Move a message to another folder."""

    async def _run():
        return await graph_email.move_message(_graph_client(), message_id, folder_ref)

    try:
        moved = asyncio.run(_run())
        output.emit({"status": "moved", "message": moved})
    except Exception as exc:
        output.handle_graph_error(exc)


@email_group.command("archive")
@click.argument("message_id")
def email_archive(message_id: str) -> None:
    """Move a message to Archive."""

    async def _run():
        return await graph_email.archive_message(_graph_client(), message_id)

    try:
        moved = asyncio.run(_run())
        output.emit({"status": "archived", "message": moved})
    except Exception as exc:
        output.handle_graph_error(exc)


@email_group.command("delete")
@click.argument("message_id")
def email_delete(message_id: str) -> None:
    """Move a message to Deleted Items."""

    async def _run():
        return await graph_email.delete_message(_graph_client(), message_id)

    try:
        moved = asyncio.run(_run())
        output.emit({"status": "deleted", "message": moved})
    except Exception as exc:
        output.handle_graph_error(exc)


@email_group.command("restore")
@click.argument("message_id")
def email_restore(message_id: str) -> None:
    """Restore a message to Inbox."""

    async def _run():
        return await graph_email.restore_message(_graph_client(), message_id)

    try:
        moved = asyncio.run(_run())
        output.emit({"status": "restored", "message": moved})
    except Exception as exc:
        output.handle_graph_error(exc)


@email_group.command("categorize")
@click.argument("message_id")
@click.option("--category", "categories", multiple=True, required=True, help="Category name.")
def email_categorize(message_id: str, categories: tuple[str, ...]) -> None:
    """Set message categories."""

    async def _run():
        return await graph_email.categorize_message(
            _graph_client(), message_id, list(categories)
        )

    try:
        message = asyncio.run(_run())
        output.emit({"status": "categorized", "message": message})
    except Exception as exc:
        output.handle_graph_error(exc)


@email_group.command("flag")
@click.argument("message_id")
@click.option(
    "--status",
    required=True,
    type=click.Choice(["flagged", "complete", "not-flagged"], case_sensitive=False),
)
def email_flag(message_id: str, status: str) -> None:
    """Set follow-up flag status."""

    async def _run():
        return await graph_email.set_message_flag(_graph_client(), message_id, status.lower())

    try:
        message = asyncio.run(_run())
        output.emit({"status": "flag_updated", "message": message})
    except Exception as exc:
        output.handle_graph_error(exc)


@email_group.command("reply")
@click.argument("message_id")
@click.option("--reply-all", is_flag=True, default=False, help="Reply to all recipients.")
@click.option("--body", required=True, help="Reply body.")
@click.option("--html", "use_html", is_flag=True, default=False, help="Treat body as HTML.")
@click.option("--file", "file_paths", multiple=True, help="Attach a local file.")
def email_reply(
    message_id: str,
    reply_all: bool,
    body: str,
    use_html: bool,
    file_paths: tuple[str, ...],
) -> None:
    """Reply to a message and send immediately."""

    async def _run():
        await graph_email.reply_to_message(
            _graph_client(),
            message_id=message_id,
            body=body,
            body_type="html" if use_html else "text",
            reply_all=reply_all,
            file_paths=list(file_paths),
        )

    try:
        asyncio.run(_run())
        output.emit(
            {
                "status": "sent",
                "message_id": message_id,
                "reply_all": reply_all,
                "attachments_added": len(file_paths),
            }
        )
    except Exception as exc:
        output.handle_graph_error(exc)


@email_group.command("forward")
@click.argument("message_id")
@click.option("--to", "recipients", multiple=True, required=True, help="Recipient address.")
@click.option("--body", default=None, help="Optional forward body.")
@click.option("--html", "use_html", is_flag=True, default=False, help="Treat body as HTML.")
@click.option("--file", "file_paths", multiple=True, help="Attach a local file.")
def email_forward(
    message_id: str,
    recipients: tuple[str, ...],
    body: str | None,
    use_html: bool,
    file_paths: tuple[str, ...],
) -> None:
    """Forward a message and send immediately."""

    async def _run():
        await graph_email.forward_message(
            _graph_client(),
            message_id=message_id,
            to=list(recipients),
            body=body,
            body_type="html" if use_html else "text",
            file_paths=list(file_paths),
        )

    try:
        asyncio.run(_run())
        output.emit(
            {
                "status": "sent",
                "message_id": message_id,
                "to": list(recipients),
                "attachments_added": len(file_paths),
            }
        )
    except Exception as exc:
        output.handle_graph_error(exc)


@email_group.group("attachments")
def attachments_group() -> None:
    """Manage message attachments."""


@attachments_group.command("list")
@click.argument("message_id")
def attachment_list(message_id: str) -> None:
    """List message attachments."""

    async def _run():
        return await graph_email.list_attachments(_graph_client(), message_id)

    try:
        attachments = asyncio.run(_run())
        output.emit(attachments, count=len(attachments))
    except Exception as exc:
        output.handle_graph_error(exc)


@attachments_group.command("download")
@click.argument("message_id")
@click.option("--attachment", "attachment_id", required=True, help="Attachment ID.")
@click.option("--output", "output_path", default=None, help="Optional output path.")
def attachment_download(message_id: str, attachment_id: str, output_path: str | None) -> None:
    """Download a file attachment."""

    async def _run():
        return await graph_email.download_attachment(
            _graph_client(),
            message_id,
            attachment_id,
            output_path,
        )

    try:
        result = asyncio.run(_run())
        output.emit(result)
    except Exception as exc:
        output.handle_graph_error(exc)


@email_group.group("draft")
def draft_group() -> None:
    """Manage Outlook draft emails."""


@draft_group.command("create")
@click.option("--to", "recipients", multiple=True, required=True)
@click.option("--subject", required=True)
@click.option("--body", required=True)
@click.option("--html", "use_html", is_flag=True, default=False)
@click.option("--file", "file_paths", multiple=True, help="Attach a local file.")
def draft_create(
    recipients: tuple[str, ...],
    subject: str,
    body: str,
    use_html: bool,
    file_paths: tuple[str, ...],
) -> None:
    """Create a draft email and return its ID."""

    async def _run():
        return await graph_email.create_draft(
            _graph_client(),
            to=list(recipients),
            subject=subject,
            body=body,
            body_type="html" if use_html else "text",
            file_paths=list(file_paths),
        )

    try:
        draft_id = asyncio.run(_run())
        output.emit(
            {
                "draft_id": draft_id,
                "status": "created",
                "attachments_added": len(file_paths),
            }
        )
    except Exception as exc:
        output.handle_graph_error(exc)


@draft_group.command("get")
@click.argument("draft_id")
def draft_get(draft_id: str) -> None:
    """Fetch a draft email by ID."""

    async def _run():
        return await graph_email.get_draft(_graph_client(), draft_id)

    try:
        draft = asyncio.run(_run())
        output.emit(draft)
    except Exception as exc:
        output.handle_graph_error(exc)


@draft_group.command("update")
@click.argument("draft_id")
@click.option("--to", "recipients", multiple=True, help="Replace all recipients.")
@click.option("--subject", default=None, help="Replace the subject.")
@click.option("--body", default=None, help="Replace the body.")
@click.option("--html", "use_html", is_flag=True, default=False, help="Treat body as HTML.")
def draft_update(
    draft_id: str,
    recipients: tuple[str, ...],
    subject: str | None,
    body: str | None,
    use_html: bool,
) -> None:
    """Patch a draft message."""

    async def _run():
        return await graph_email.update_draft(
            _graph_client(),
            draft_id,
            to=list(recipients) if recipients else None,
            subject=subject,
            body=body,
            body_type="html" if use_html else "text",
        )

    try:
        draft = asyncio.run(_run())
        output.emit({"status": "updated", "draft": draft})
    except Exception as exc:
        output.handle_graph_error(exc)


@draft_group.command("reply")
@click.argument("message_id")
@click.option("--reply-all", is_flag=True, default=False, help="Draft a reply-all instead of reply.")
@click.option("--body", default=None, help="Optional initial reply body.")
@click.option("--html", "use_html", is_flag=True, default=False, help="Treat body as HTML.")
@click.option("--file", "file_paths", multiple=True, help="Attach a local file.")
def draft_reply(
    message_id: str,
    reply_all: bool,
    body: str | None,
    use_html: bool,
    file_paths: tuple[str, ...],
) -> None:
    """Create a draft reply without sending it."""

    async def _run():
        draft = await graph_email.create_reply_draft(
            _graph_client(),
            message_id=message_id,
            body=body,
            body_type="html" if use_html else "text",
            reply_all=reply_all,
        )
        if file_paths:
            attachments = await graph_email.add_files_to_draft(
                _graph_client(), draft["draft_id"], list(file_paths)
            )
            draft["attachments_added"] = len(attachments)
        return draft

    try:
        draft = asyncio.run(_run())
        output.emit(draft)
    except Exception as exc:
        output.handle_graph_error(exc)


@draft_group.command("forward")
@click.argument("message_id")
@click.option("--to", "recipients", multiple=True, help="Recipient address.")
@click.option("--body", default=None, help="Optional initial forward body.")
@click.option("--html", "use_html", is_flag=True, default=False, help="Treat body as HTML.")
@click.option("--file", "file_paths", multiple=True, help="Attach a local file.")
def draft_forward(
    message_id: str,
    recipients: tuple[str, ...],
    body: str | None,
    use_html: bool,
    file_paths: tuple[str, ...],
) -> None:
    """Create a forward draft without sending it."""

    async def _run():
        draft = await graph_email.create_forward_draft(
            _graph_client(),
            message_id=message_id,
            to=list(recipients),
            body=body,
            body_type="html" if use_html else "text",
        )
        if file_paths:
            attachments = await graph_email.add_files_to_draft(
                _graph_client(), draft["draft_id"], list(file_paths)
            )
            draft["attachments_added"] = len(attachments)
        return draft

    try:
        draft = asyncio.run(_run())
        output.emit(draft)
    except Exception as exc:
        output.handle_graph_error(exc)


@draft_group.command("send")
@click.argument("draft_id")
def draft_send(draft_id: str) -> None:
    """Send a draft email."""

    async def _run():
        await graph_email.send_draft(_graph_client(), draft_id)

    try:
        asyncio.run(_run())
        output.emit({"status": "sent", "draft_id": draft_id})
    except Exception as exc:
        output.handle_graph_error(exc)


@draft_group.command("delete")
@click.argument("draft_id")
def draft_delete(draft_id: str) -> None:
    """Delete a draft email."""

    async def _run():
        await graph_email.delete_draft(_graph_client(), draft_id)

    try:
        asyncio.run(_run())
        output.emit({"status": "deleted", "draft_id": draft_id})
    except Exception as exc:
        output.handle_graph_error(exc)


@draft_group.group("attachments")
def draft_attachments_group() -> None:
    """Manage draft attachments."""


@draft_attachments_group.command("add")
@click.argument("draft_id")
@click.option("--file", "file_paths", multiple=True, required=True, help="Attach a local file.")
def draft_attachments_add(draft_id: str, file_paths: tuple[str, ...]) -> None:
    """Add local file attachments to a draft."""

    async def _run():
        return await graph_email.add_files_to_draft(
            _graph_client(), draft_id, list(file_paths)
        )

    try:
        attachments = asyncio.run(_run())
        output.emit(attachments, count=len(attachments))
    except Exception as exc:
        output.handle_graph_error(exc)
