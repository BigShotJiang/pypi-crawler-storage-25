"""m365 auth — authentication commands.

  m365 auth login                  # device code (interactive browser)
  m365 auth login --service-account # client credentials (headless)
  m365 auth logout                 # clear stored tokens
  m365 auth status                 # JSON: who is logged in + token validity
  m365 auth token                  # print raw access token (useful for piping)
"""

from __future__ import annotations

import asyncio

import click

from m365_cli import output
from m365_cli.auth.manager import AuthManager
from m365_cli.auth.token_store import TokenStore
from m365_cli.config import get_settings


def _get_auth_manager() -> AuthManager:
    try:
        settings = get_settings()
    except Exception as exc:
        output.emit_error(
            f"Configuration error: {exc}",
            code="CONFIG_ERROR",
            hint="Ensure MICROSOFT_CLIENT_ID is set in your .env file.",
        )
    store = TokenStore(
        token_path=settings.token_path,
        encryption_key=settings.token_encryption_key,
    )
    return AuthManager(settings=settings, token_store=store)


@click.group("auth")
def auth_group() -> None:
    """Authenticate with Microsoft 365."""


@auth_group.command("login")
@click.option(
    "--service-account",
    is_flag=True,
    default=False,
    help="Use client credentials (headless). Requires MICROSOFT_CLIENT_SECRET.",
)
def auth_login(service_account: bool) -> None:
    """Authenticate with Microsoft 365.

    Default: opens a browser device-code flow and caches a refresh token.
    --service-account: uses client credentials (no browser, no cached token).
    """
    manager = _get_auth_manager()
    settings = get_settings()

    try:
        if service_account or settings.microsoft_auth_mode == "client_credentials":
            token = manager.authenticate_service_account()
            output.emit({"mode": "client_credentials", "token_preview": token[:20] + "…"})
        else:
            click.echo("Starting device code authentication…")
            manager.authenticate_device_code()
            output.emit({"mode": "device_code", "status": "authenticated"})
    except Exception as exc:
        output.emit_error(str(exc), code="AUTH_FAILED")


@auth_group.command("logout")
def auth_logout() -> None:
    """Clear stored tokens and log out."""
    manager = _get_auth_manager()
    manager.logout()
    output.emit({"status": "logged_out"})


@auth_group.command("status")
def auth_status() -> None:
    """Show authentication status and the logged-in user profile."""
    manager = _get_auth_manager()

    if not manager.is_authenticated():
        output.emit({"authenticated": False, "hint": "Run: m365 auth login"})
        return

    async def _get_profile() -> dict:
        from m365_cli.graph.client import get_graph_client

        settings = get_settings()
        graph = get_graph_client(settings, manager)
        user = await graph.me.get()
        return {
            "authenticated": True,
            "auth_mode": settings.microsoft_auth_mode,
            "display_name": user.display_name,
            "email": user.mail or user.user_principal_name,
            "user_id": user.id,
            "token_valid": manager.token_store.has_valid_tokens(),
        }

    try:
        profile = asyncio.run(_get_profile())
        output.emit(profile)
    except Exception as exc:
        output.handle_graph_error(exc)


@auth_group.command("token")
def auth_token() -> None:
    """Print the raw access token to stdout (useful for piping into other tools)."""
    manager = _get_auth_manager()
    if not manager.is_authenticated():
        output.auth_required()
    try:
        token = manager.get_access_token()
        # Raw token — no JSON wrapper so it can be used in shell pipelines
        click.echo(token)
    except Exception as exc:
        output.handle_graph_error(exc)
