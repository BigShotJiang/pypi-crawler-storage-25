"""m365 calendar — calendar commands."""

from __future__ import annotations

import asyncio
from datetime import date, datetime, timedelta, timezone

import click

from m365_cli import output
from m365_cli.auth.manager import AuthManager
from m365_cli.auth.token_store import TokenStore
from m365_cli.config import get_settings
from m365_cli.graph import calendar as graph_cal
from m365_cli.graph.client import get_graph_client
from m365_cli.utils import parse_dt


def _get_settings_or_exit():
    try:
        return get_settings()
    except Exception as exc:
        output.emit_error(
            f"Configuration error: {exc}",
            code="CONFIG_ERROR",
            hint="Ensure MICROSOFT_CLIENT_ID is set in your .env file.",
        )


def _graph_client():
    settings = _get_settings_or_exit()
    store = TokenStore(settings.token_path, settings.token_encryption_key)
    manager = AuthManager(settings, store)
    if not manager.is_authenticated():
        output.auth_required()
    return get_graph_client(settings, manager)


def _parse_event_datetime(value: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError as exc:
        output.emit_error(f"Invalid datetime format: {exc}", code="INVALID_INPUT")
    if parsed.tzinfo is None:
        output.emit_error(
            "Datetime must include a timezone offset, e.g. 2026-04-17T14:00:00-05:00.",
            code="INVALID_INPUT",
        )
    return parsed


def _parse_optional_date(value: str | None) -> date | None:
    if value is None:
        return None
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        output.emit_error(f"Invalid date format: {exc}", code="INVALID_INPUT")


def _validate_recurrence(
    recurrence: str | None,
    recurrence_interval: int,
    recurrence_until: date | None,
    recurrence_count: int | None,
) -> None:
    if not recurrence:
        if recurrence_until or recurrence_count:
            output.emit_error(
                "Recurrence end options require --recurrence.",
                code="INVALID_INPUT",
            )
        return
    if recurrence_interval < 1:
        output.emit_error("--recurrence-interval must be >= 1.", code="INVALID_INPUT")
    if recurrence_until and recurrence_count:
        output.emit_error(
            "Use only one of --recurrence-until or --recurrence-count.",
            code="INVALID_INPUT",
        )
    if recurrence_count is not None and recurrence_count < 1:
        output.emit_error("--recurrence-count must be >= 1.", code="INVALID_INPUT")


@click.group("calendar")
def calendar_group() -> None:
    """Read and manage your Microsoft 365 calendar."""


@calendar_group.command("events")
@click.option("--start", "start_str", default=None, metavar="TIME",
              help="Window start. Accepts HH:MM, YYYY-MM-DD, or YYYY-MM-DDTHH:MM.")
@click.option("--end", "end_str", default=None, metavar="TIME",
              help="Window end. Same formats as --start.")
@click.option("--today", "today_only", is_flag=True, default=False,
              help="Shortcut: show all of today's events.")
def calendar_events(start_str: str | None, end_str: str | None, today_only: bool) -> None:
    """List calendar events in a time window."""
    from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

    settings = _get_settings_or_exit()
    try:
        tz = ZoneInfo(settings.my_timezone)
    except (ZoneInfoNotFoundError, KeyError):
        output.emit_error(
            f"Unknown timezone '{settings.my_timezone}'. "
            "Set MY_TIMEZONE to a valid IANA name (e.g. America/Chicago).",
            code="CONFIG_ERROR",
        )

    now_local = datetime.now(tz)
    if today_only or (start_str is None and end_str is None):
        start = now_local.replace(hour=0, minute=0, second=0, microsecond=0)
        end = (start + timedelta(days=1)).replace(microsecond=0)
    else:
        start = parse_dt(start_str, tz) if start_str else now_local.replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        if end_str:
            end = parse_dt(end_str, tz)
        else:
            local_start = start.astimezone(tz)
            end = (
                local_start + timedelta(days=1)
            ).replace(hour=0, minute=0, second=0, microsecond=0).astimezone(timezone.utc)

    if start >= end:
        output.emit_error("--start must be before --end.", code="INVALID_INPUT")

    async def _run():
        return await graph_cal.fetch_calendar_events(
            _graph_client(), start_date=start, end_date=end
        )

    try:
        events = asyncio.run(_run())
        output.emit(events, count=len(events))
    except Exception as exc:
        output.handle_graph_error(exc)


@calendar_group.command("create")
@click.option("--subject", required=True, help="Meeting subject/title.")
@click.option("--start", "start_str", required=True, help="Start datetime ISO 8601.")
@click.option("--end", "end_str", required=True, help="End datetime ISO 8601.")
@click.option("--attendee", "attendees", multiple=True, help="Attendee email.")
@click.option("--body", default=None, help="Optional meeting description.")
@click.option("--location", default=None, help="Optional meeting location.")
@click.option("--online", "is_online", is_flag=True, default=False, help="Create as Teams online meeting.")
@click.option(
    "--recurrence",
    type=click.Choice(["daily", "weekly", "monthly"], case_sensitive=False),
    default=None,
    help="Recurring event pattern.",
)
@click.option("--recurrence-interval", default=1, type=int, show_default=True)
@click.option("--recurrence-until", default=None, help="Recurrence end date (YYYY-MM-DD).")
@click.option("--recurrence-count", default=None, type=int, help="Fixed occurrence count.")
def calendar_create(
    subject: str,
    start_str: str,
    end_str: str,
    attendees: tuple[str, ...],
    body: str | None,
    location: str | None,
    is_online: bool,
    recurrence: str | None,
    recurrence_interval: int,
    recurrence_until: str | None,
    recurrence_count: int | None,
) -> None:
    """Create a new calendar event."""
    start_dt = _parse_event_datetime(start_str)
    end_dt = _parse_event_datetime(end_str)
    if start_dt >= end_dt:
        output.emit_error("--start must be before --end.", code="INVALID_INPUT")
    recurrence_until_date = _parse_optional_date(recurrence_until)
    _validate_recurrence(
        recurrence,
        recurrence_interval,
        recurrence_until_date,
        recurrence_count,
    )

    async def _run():
        return await graph_cal.create_calendar_event(
            _graph_client(),
            subject=subject,
            start_time=start_dt,
            end_time=end_dt,
            attendee_emails=list(attendees),
            body=body,
            location=location,
            is_online_meeting=is_online,
            recurrence_pattern=recurrence.lower() if recurrence else None,
            recurrence_interval=recurrence_interval,
            recurrence_end_date=recurrence_until_date,
            recurrence_count=recurrence_count,
        )

    try:
        result = asyncio.run(_run())
        output.emit(result)
    except Exception as exc:
        output.handle_graph_error(exc)


@calendar_group.command("update")
@click.argument("event_id")
@click.option("--subject", default=None, help="New meeting subject/title.")
@click.option("--start", "start_str", default=None, help="New start datetime ISO 8601.")
@click.option("--end", "end_str", default=None, help="New end datetime ISO 8601.")
@click.option("--attendee", "attendees", multiple=True, help="Replace attendee list.")
@click.option("--body", default=None, help="Replace meeting description.")
@click.option("--location", default=None, help="Replace meeting location.")
@click.option("--online", "is_online", flag_value=True, default=None, help="Set as Teams online meeting.")
@click.option("--no-online", "is_online", flag_value=False, help="Set as non-online meeting.")
def calendar_update(
    event_id: str,
    subject: str | None,
    start_str: str | None,
    end_str: str | None,
    attendees: tuple[str, ...],
    body: str | None,
    location: str | None,
    is_online: bool | None,
) -> None:
    """Patch an existing calendar event."""
    start_dt = _parse_event_datetime(start_str) if start_str else None
    end_dt = _parse_event_datetime(end_str) if end_str else None
    if start_dt and end_dt and start_dt >= end_dt:
        output.emit_error("--start must be before --end.", code="INVALID_INPUT")

    async def _run():
        return await graph_cal.update_calendar_event(
            _graph_client(),
            event_id=event_id,
            subject=subject,
            start_time=start_dt,
            end_time=end_dt,
            attendee_emails=list(attendees) if attendees else None,
            body=body,
            location=location,
            is_online_meeting=is_online,
        )

    try:
        result = asyncio.run(_run())
        output.emit(result)
    except Exception as exc:
        output.handle_graph_error(exc)


@calendar_group.command("delete")
@click.argument("event_id")
def calendar_delete(event_id: str) -> None:
    """Delete an event."""

    async def _run():
        await graph_cal.delete_calendar_event(_graph_client(), event_id)

    try:
        asyncio.run(_run())
        output.emit({"status": "deleted", "event_id": event_id})
    except Exception as exc:
        output.handle_graph_error(exc)


@calendar_group.command("availability")
@click.option("--user", "users", multiple=True, required=True, help="Attendee email to check.")
@click.option("--start", "start_str", required=True, help="Start datetime ISO 8601.")
@click.option("--end", "end_str", required=True, help="End datetime ISO 8601.")
@click.option("--duration-minutes", default=30, type=int, show_default=True)
def calendar_availability(
    users: tuple[str, ...],
    start_str: str,
    end_str: str,
    duration_minutes: int,
) -> None:
    """Return free/busy data and suggested meeting slots."""
    start_dt = _parse_event_datetime(start_str)
    end_dt = _parse_event_datetime(end_str)
    if start_dt >= end_dt:
        output.emit_error("--start must be before --end.", code="INVALID_INPUT")
    if duration_minutes < 5:
        output.emit_error("--duration-minutes must be >= 5.", code="INVALID_INPUT")

    async def _run():
        return await graph_cal.get_availability(
            _graph_client(),
            users=list(users),
            start_time=start_dt,
            end_time=end_dt,
            duration_minutes=duration_minutes,
        )

    try:
        availability = asyncio.run(_run())
        output.emit(availability, count=len(availability["users"]))
    except Exception as exc:
        output.handle_graph_error(exc)


@calendar_group.command("rsvp")
@click.argument("event_id")
@click.option(
    "--response", "-r",
    required=True,
    type=click.Choice(["accept", "decline", "tentative"], case_sensitive=False),
    help="Your RSVP response.",
)
@click.option("--comment", default=None, help="Optional comment to include with your response.")
def calendar_rsvp(event_id: str, response: str, comment: str | None) -> None:
    """RSVP to a meeting invitation."""

    async def _run():
        await graph_cal.respond_to_meeting(
            _graph_client(), event_id=event_id, response=response, comment=comment
        )

    try:
        asyncio.run(_run())
        output.emit(
            {
                "status": response,
                "event_id": event_id,
                **({"comment": comment} if comment else {}),
            }
        )
    except Exception as exc:
        output.handle_graph_error(exc)
