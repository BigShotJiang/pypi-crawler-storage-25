"""m365 people — people lookup commands."""

from __future__ import annotations

import asyncio

import click

from m365_cli import output
from m365_cli.auth.manager import AuthManager
from m365_cli.auth.token_store import TokenStore
from m365_cli.config import get_settings
from m365_cli.graph import people as graph_people
from m365_cli.graph.client import get_graph_client


def _get_settings_or_exit():
    try:
        return get_settings()
    except Exception as exc:
        output.emit_error(
            f"Configuration error: {exc}",
            code="CONFIG_ERROR",
            hint="Ensure MICROSOFT_CLIENT_ID is set in your .env file.",
        )


def _graph_client():
    settings = _get_settings_or_exit()
    store = TokenStore(settings.token_path, settings.token_encryption_key)
    manager = AuthManager(settings, store)
    if not manager.is_authenticated():
        output.auth_required()
    return get_graph_client(settings, manager)


@click.group("people")
def people_group() -> None:
    """Search for people and recipient candidates."""


@people_group.command("search")
@click.option("--query", required=True, help="Search query.")
@click.option("--limit", default=10, type=int, show_default=True, help="Max results to return.")
def people_search(query: str, limit: int) -> None:
    """Search Graph people for recipients and attendees."""

    async def _run():
        return await graph_people.search_people(
            _graph_client(),
            query=query,
            limit=limit,
        )

    try:
        people = asyncio.run(_run())
        output.emit(people, count=len(people))
    except Exception as exc:
        output.handle_graph_error(exc)
