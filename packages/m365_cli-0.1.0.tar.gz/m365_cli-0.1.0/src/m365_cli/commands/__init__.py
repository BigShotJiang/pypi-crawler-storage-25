"""CLI command groups for m365-cli."""
