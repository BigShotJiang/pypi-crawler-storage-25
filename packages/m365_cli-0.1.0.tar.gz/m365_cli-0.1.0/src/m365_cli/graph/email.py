"""Microsoft Graph email operations.

All functions accept a GraphServiceClient and return plain Python dicts/lists
so the command layer can JSON-serialize them directly.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from msgraph import GraphServiceClient
from msgraph.generated.models.attachment import Attachment
from msgraph.generated.models.body_type import BodyType
from msgraph.generated.models.email_address import EmailAddress
from msgraph.generated.models.file_attachment import FileAttachment
from msgraph.generated.models.followup_flag import FollowupFlag
from msgraph.generated.models.followup_flag_status import FollowupFlagStatus
from msgraph.generated.models.item_body import ItemBody
from msgraph.generated.models.mail_folder import MailFolder
from msgraph.generated.models.message import Message
from msgraph.generated.models.recipient import Recipient

from m365_cli.retry import with_retry

logger = logging.getLogger(__name__)

_PAGE_SIZE = 50
_SMALL_ATTACHMENT_MAX_BYTES = 3 * 1024 * 1024
_SELECT_FIELDS = [
    "id",
    "subject",
    "from",
    "toRecipients",
    "ccRecipients",
    "receivedDateTime",
    "sentDateTime",
    "bodyPreview",
    "conversationId",
    "isRead",
    "parentFolderId",
    "categories",
    "flag",
    "hasAttachments",
    "internetMessageId",
    "webLink",
]
_SELECT_FIELDS_WITH_BODY = _SELECT_FIELDS + ["body"]
_KNOWN_FOLDER_IDS = {
    "archive": "archive",
    "deleted": "deleteditems",
    "deleteditems": "deleteditems",
    "drafts": "drafts",
    "inbox": "inbox",
    "junk": "junkemail",
    "junkemail": "junkemail",
    "sent": "sentitems",
    "sentitems": "sentitems",
}


def _recipients(addresses: list[str]) -> list[Recipient]:
    return [Recipient(email_address=EmailAddress(address=addr)) for addr in addresses]


def _body(content: str, body_type: str) -> ItemBody:
    return ItemBody(
        content_type=BodyType.Html if body_type == "html" else BodyType.Text,
        content=content,
    )


def _normalize_body_type(body_type: str | None) -> str:
    return "html" if body_type == "html" else "text"


def _flag_to_dict(flag: FollowupFlag | None) -> dict[str, Any] | None:
    if not flag:
        return None
    status = flag.flag_status.value if flag.flag_status else None
    return {
        "status": status,
        "start": flag.start_date_time.date_time if flag.start_date_time else None,
        "due": flag.due_date_time.date_time if flag.due_date_time else None,
        "completed": (
            flag.completed_date_time.date_time if flag.completed_date_time else None
        ),
    }


def _attachment_to_dict(attachment: Attachment) -> dict[str, Any]:
    return {
        "id": attachment.id,
        "name": attachment.name,
        "content_type": attachment.content_type,
        "size": attachment.size,
        "is_inline": attachment.is_inline or False,
        "odata_type": attachment.odata_type,
    }


def _msg_to_dict(msg: Message, *, include_body: bool = False) -> dict[str, Any]:
    body_type = (
        "html"
        if msg.body and msg.body.content_type == BodyType.Html
        else "text"
    )
    return {
        "id": msg.id,
        "conversation_id": msg.conversation_id,
        "subject": msg.subject or "",
        "from": (
            msg.from_.email_address.address
            if msg.from_ and msg.from_.email_address
            else None
        ),
        "from_name": (
            msg.from_.email_address.name
            if msg.from_ and msg.from_.email_address
            else None
        ),
        "to": [
            r.email_address.address
            for r in (msg.to_recipients or [])
            if r.email_address and r.email_address.address
        ],
        "cc": [
            r.email_address.address
            for r in (msg.cc_recipients or [])
            if r.email_address and r.email_address.address
        ],
        "received_at": msg.received_date_time,
        "sent_at": msg.sent_date_time,
        "is_read": msg.is_read,
        "is_draft": msg.is_draft or False,
        "preview": msg.body_preview or "",
        "folder_id": msg.parent_folder_id,
        "categories": list(msg.categories or []),
        "flag": _flag_to_dict(msg.flag),
        "has_attachments": msg.has_attachments or False,
        "internet_message_id": msg.internet_message_id,
        "web_link": msg.web_link,
        **(
            {
                "body_text": msg.body.content if msg.body else "",
                "body_type": body_type,
            }
            if include_body
            else {}
        ),
    }


def _folder_to_dict(folder: MailFolder) -> dict[str, Any]:
    return {
        "id": folder.id,
        "display_name": folder.display_name,
        "parent_id": folder.parent_folder_id,
        "child_count": folder.child_folder_count,
        "unread_count": folder.unread_item_count,
        "total_count": folder.total_item_count,
        "is_hidden": folder.is_hidden or False,
    }


def _serialize_draft(
    draft: Message,
    *,
    source_message_id: str | None = None,
    reply_all: bool | None = None,
) -> dict[str, Any]:
    data = _msg_to_dict(draft, include_body=True)
    if source_message_id is not None:
        data["source_message_id"] = source_message_id
    if reply_all is not None:
        data["reply_all"] = reply_all
    return data


def _to_utc(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _build_filter(
    *,
    unread_only: bool,
    since: datetime | None,
    until: datetime | None,
    conversation_id: str | None = None,
) -> str | None:
    parts = []
    if unread_only:
        parts.append("isRead eq false")
    if since:
        parts.append(
            f"receivedDateTime ge {_to_utc(since).strftime('%Y-%m-%dT%H:%M:%SZ')}"
        )
    if until:
        parts.append(
            f"receivedDateTime le {_to_utc(until).strftime('%Y-%m-%dT%H:%M:%SZ')}"
        )
    if conversation_id:
        parts.append(f"conversationId eq '{conversation_id}'")
    return " and ".join(parts) if parts else None


def _query_matches(msg: Message, query: str | None) -> bool:
    if not query:
        return True
    haystacks = [
        msg.subject or "",
        msg.body_preview or "",
        msg.internet_message_id or "",
        msg.body.content if msg.body and msg.body.content else "",
        msg.from_.email_address.address
        if msg.from_ and msg.from_.email_address and msg.from_.email_address.address
        else "",
        msg.from_.email_address.name
        if msg.from_ and msg.from_.email_address and msg.from_.email_address.name
        else "",
    ]
    for recipient in (msg.to_recipients or []) + (msg.cc_recipients or []):
        if recipient.email_address:
            haystacks.append(recipient.email_address.address or "")
            haystacks.append(recipient.email_address.name or "")
    needle = query.lower()
    return any(needle in value.lower() for value in haystacks if value)


async def _iter_collection(first_page: Any, fetch_next: Any) -> list[Any]:
    items: list[Any] = []
    page = first_page
    while page and page.value:
        items.extend(page.value)
        next_link = page.odata_next_link
        if not next_link:
            break
        page = await with_retry(lambda: fetch_next(next_link))
    return items


async def _list_child_folders(
    client: GraphServiceClient,
    folder_id: str,
) -> list[MailFolder]:
    from msgraph.generated.users.item.mail_folders.item.child_folders.child_folders_request_builder import (
        ChildFoldersRequestBuilder,
    )

    params = ChildFoldersRequestBuilder.ChildFoldersRequestBuilderGetQueryParameters(
        top=100,
        select=[
            "id",
            "displayName",
            "parentFolderId",
            "childFolderCount",
            "unreadItemCount",
            "totalItemCount",
            "isHidden",
        ],
    )
    cfg = ChildFoldersRequestBuilder.ChildFoldersRequestBuilderGetRequestConfiguration(
        query_parameters=params
    )
    result = await with_retry(
        lambda: client.me.mail_folders.by_mail_folder_id(folder_id).child_folders.get(
            request_configuration=cfg
        )
    )
    items = await _iter_collection(
        result,
        lambda url: client.me.mail_folders.by_mail_folder_id(folder_id)
        .child_folders.with_url(url)
        .get(),
    )
    return items


async def list_mail_folders(client: GraphServiceClient) -> list[dict[str, Any]]:
    from msgraph.generated.users.item.mail_folders.mail_folders_request_builder import (
        MailFoldersRequestBuilder,
    )

    params = MailFoldersRequestBuilder.MailFoldersRequestBuilderGetQueryParameters(
        top=100,
        include_hidden_folders="true",
        select=[
            "id",
            "displayName",
            "parentFolderId",
            "childFolderCount",
            "unreadItemCount",
            "totalItemCount",
            "isHidden",
        ],
    )
    cfg = MailFoldersRequestBuilder.MailFoldersRequestBuilderGetRequestConfiguration(
        query_parameters=params
    )
    root_page = await with_retry(
        lambda: client.me.mail_folders.get(request_configuration=cfg)
    )
    folders = await _iter_collection(
        root_page,
        lambda url: client.me.mail_folders.with_url(url).get(),
    )

    all_folders: list[MailFolder] = []
    queue = list(folders)
    while queue:
        folder = queue.pop(0)
        all_folders.append(folder)
        if folder.child_folder_count:
            queue.extend(await _list_child_folders(client, folder.id))
    return [_folder_to_dict(folder) for folder in all_folders]


async def resolve_mail_folder(client: GraphServiceClient, folder_ref: str) -> str:
    lowered = folder_ref.strip().lower()
    if lowered in _KNOWN_FOLDER_IDS:
        return _KNOWN_FOLDER_IDS[lowered]

    folders = await list_mail_folders(client)
    exact_id = next((folder for folder in folders if folder["id"] == folder_ref), None)
    if exact_id:
        return exact_id["id"]

    matches = [
        folder for folder in folders if (folder["display_name"] or "").lower() == lowered
    ]
    if not matches:
        raise ValueError(f"Unknown folder '{folder_ref}'.")
    if len(matches) > 1:
        ids = ", ".join(folder["id"] for folder in matches)
        raise ValueError(
            f"Folder '{folder_ref}' is ambiguous. Use one of these IDs: {ids}"
        )
    return matches[0]["id"]


def _message_collection(
    client: GraphServiceClient, folder_id: str | None = None
) -> Any:
    if folder_id:
        return client.me.mail_folders.by_mail_folder_id(folder_id).messages
    return client.me.messages


async def fetch_emails(
    client: GraphServiceClient,
    *,
    limit: int | None = 20,
    unread_only: bool = False,
    since: datetime | None = None,
    until: datetime | None = None,
    include_body: bool = False,
    folder: str | None = None,
    query: str | None = None,
) -> list[dict[str, Any]]:
    from msgraph.generated.users.item.messages.messages_request_builder import (
        MessagesRequestBuilder,
    )

    folder_id = await resolve_mail_folder(client, folder) if folder else None
    collection = _message_collection(client, folder_id)
    has_time_filter = since is not None or until is not None
    page_size = _PAGE_SIZE if limit is None else min(limit, _PAGE_SIZE)
    params = MessagesRequestBuilder.MessagesRequestBuilderGetQueryParameters(
        top=page_size,
        orderby=["receivedDateTime DESC"],
        select=_SELECT_FIELDS_WITH_BODY if include_body else _SELECT_FIELDS,
        filter=_build_filter(unread_only=unread_only, since=since, until=until),
    )
    cfg = MessagesRequestBuilder.MessagesRequestBuilderGetRequestConfiguration(
        query_parameters=params
    )
    result = await with_retry(lambda: collection.get(request_configuration=cfg))

    collected: list[Message] = []
    page = result
    while page and page.value:
        for message in page.value:
            if _query_matches(message, query):
                collected.append(message)
                if limit is not None and len(collected) >= limit:
                    break
        if limit is not None and len(collected) >= limit:
            break
        next_link = page.odata_next_link
        if not next_link:
            break
        should_paginate = has_time_filter or query is not None or limit is None
        if not should_paginate:
            break
        page = await with_retry(lambda: collection.with_url(next_link).get())

    return [_msg_to_dict(message, include_body=include_body) for message in collected]


async def fetch_email_by_id(
    client: GraphServiceClient, message_id: str
) -> dict[str, Any]:
    msg = await with_retry(
        lambda: client.me.messages.by_message_id(message_id).get()
    )
    return _msg_to_dict(msg, include_body=True)


async def fetch_thread(
    client: GraphServiceClient, message_id: str
) -> dict[str, Any]:
    from msgraph.generated.users.item.messages.messages_request_builder import (
        MessagesRequestBuilder,
    )

    source = await with_retry(lambda: client.me.messages.by_message_id(message_id).get())
    params = MessagesRequestBuilder.MessagesRequestBuilderGetQueryParameters(
        top=100,
        orderby=["receivedDateTime DESC"],
        select=_SELECT_FIELDS,
        filter=_build_filter(
            unread_only=False,
            since=None,
            until=None,
            conversation_id=source.conversation_id,
        ),
    )
    cfg = MessagesRequestBuilder.MessagesRequestBuilderGetRequestConfiguration(
        query_parameters=params
    )
    result = await with_retry(lambda: client.me.messages.get(request_configuration=cfg))
    messages = await _iter_collection(
        result,
        lambda url: client.me.messages.with_url(url).get(),
    )
    return {
        "conversation_id": source.conversation_id,
        "messages": [_msg_to_dict(message, include_body=False) for message in messages],
    }


async def send_email(
    client: GraphServiceClient,
    *,
    to: list[str],
    subject: str,
    body: str,
    body_type: str = "text",
    file_paths: list[str] | None = None,
) -> None:
    from msgraph.generated.users.item.send_mail.send_mail_post_request_body import (
        SendMailPostRequestBody,
    )

    msg = Message(
        subject=subject,
        body=_body(body, body_type),
        to_recipients=_recipients(to),
        attachments=_file_attachments(file_paths or []),
    )
    request_body = SendMailPostRequestBody(message=msg, save_to_sent_items=True)
    await with_retry(lambda: client.me.send_mail.post(body=request_body))
    logger.info("Email sent to %s", to)


async def mark_as_read(client: GraphServiceClient, message_id: str) -> None:
    patch = Message(is_read=True)
    await with_retry(
        lambda: client.me.messages.by_message_id(message_id).patch(body=patch)
    )


async def move_message(
    client: GraphServiceClient,
    message_id: str,
    destination_folder: str,
) -> dict[str, Any]:
    from msgraph.generated.users.item.messages.item.move.move_post_request_body import (
        MovePostRequestBody,
    )

    destination_id = await resolve_mail_folder(client, destination_folder)
    moved = await with_retry(
        lambda: client.me.messages.by_message_id(message_id).move.post(
            body=MovePostRequestBody(destination_id=destination_id)
        )
    )
    return _msg_to_dict(moved, include_body=False)


async def archive_message(client: GraphServiceClient, message_id: str) -> dict[str, Any]:
    return await move_message(client, message_id, "archive")


async def delete_message(client: GraphServiceClient, message_id: str) -> dict[str, Any]:
    return await move_message(client, message_id, "deleteditems")


async def restore_message(client: GraphServiceClient, message_id: str) -> dict[str, Any]:
    return await move_message(client, message_id, "inbox")


async def categorize_message(
    client: GraphServiceClient,
    message_id: str,
    categories: list[str],
) -> dict[str, Any]:
    patch = Message(categories=categories)
    updated = await with_retry(
        lambda: client.me.messages.by_message_id(message_id).patch(body=patch)
    )
    return _msg_to_dict(updated, include_body=False)


async def set_message_flag(
    client: GraphServiceClient,
    message_id: str,
    status: str,
) -> dict[str, Any]:
    mapping = {
        "not-flagged": FollowupFlagStatus.NotFlagged,
        "complete": FollowupFlagStatus.Complete,
        "flagged": FollowupFlagStatus.Flagged,
    }
    patch = Message(flag=FollowupFlag(flag_status=mapping[status]))
    updated = await with_retry(
        lambda: client.me.messages.by_message_id(message_id).patch(body=patch)
    )
    return _msg_to_dict(updated, include_body=False)


def _reply_payload(body: str | None, body_type: str) -> Message | None:
    if body is None:
        return None
    return Message(body=_body(body, body_type))


async def reply_to_message(
    client: GraphServiceClient,
    *,
    message_id: str,
    body: str,
    body_type: str = "text",
    reply_all: bool = False,
    file_paths: list[str] | None = None,
) -> None:
    draft = await create_reply_draft(
        client,
        message_id=message_id,
        body=body,
        body_type=body_type,
        reply_all=reply_all,
    )
    if file_paths:
        await add_files_to_draft(client, draft["draft_id"], file_paths)
    await send_draft(client, draft["draft_id"])


async def forward_message(
    client: GraphServiceClient,
    *,
    message_id: str,
    to: list[str],
    body: str | None = None,
    body_type: str = "text",
    file_paths: list[str] | None = None,
) -> None:
    draft = await create_forward_draft(
        client,
        message_id=message_id,
        to=to,
        body=body,
        body_type=body_type,
    )
    if file_paths:
        await add_files_to_draft(client, draft["draft_id"], file_paths)
    await send_draft(client, draft["draft_id"])


def _create_reply_request(body: str | None, body_type: str, reply_all: bool) -> Any:
    if reply_all:
        from msgraph.generated.users.item.messages.item.create_reply_all.create_reply_all_post_request_body import (
            CreateReplyAllPostRequestBody,
        )

        return CreateReplyAllPostRequestBody(message=_reply_payload(body, body_type))
    from msgraph.generated.users.item.messages.item.create_reply.create_reply_post_request_body import (
        CreateReplyPostRequestBody,
    )

    return CreateReplyPostRequestBody(message=_reply_payload(body, body_type))


async def create_reply_draft(
    client: GraphServiceClient,
    *,
    message_id: str,
    body: str | None = None,
    body_type: str = "text",
    reply_all: bool = False,
) -> dict[str, Any]:
    builder = client.me.messages.by_message_id(message_id)
    request_body = _create_reply_request(body, body_type, reply_all)
    if reply_all:
        draft = await with_retry(lambda: builder.create_reply_all.post(body=request_body))
    else:
        draft = await with_retry(lambda: builder.create_reply.post(body=request_body))
    return {
        "draft_id": draft.id,
        **_serialize_draft(draft, source_message_id=message_id, reply_all=reply_all),
    }


async def create_forward_draft(
    client: GraphServiceClient,
    *,
    message_id: str,
    to: list[str] | None = None,
    body: str | None = None,
    body_type: str = "text",
) -> dict[str, Any]:
    from msgraph.generated.users.item.messages.item.create_forward.create_forward_post_request_body import (
        CreateForwardPostRequestBody,
    )

    request_body = CreateForwardPostRequestBody(
        message=_reply_payload(body, body_type),
        to_recipients=_recipients(to or []),
    )
    draft = await with_retry(
        lambda: client.me.messages.by_message_id(message_id).create_forward.post(
            body=request_body
        )
    )
    return {
        "draft_id": draft.id,
        **_serialize_draft(draft, source_message_id=message_id),
    }


async def create_draft(
    client: GraphServiceClient,
    *,
    to: list[str],
    subject: str,
    body: str,
    body_type: str = "html",
    file_paths: list[str] | None = None,
) -> str:
    msg = Message(
        subject=subject,
        body=_body(body, body_type),
        to_recipients=_recipients(to),
        attachments=_file_attachments(file_paths or []),
    )
    result = await with_retry(lambda: client.me.messages.post(msg))
    return result.id


async def get_draft(client: GraphServiceClient, draft_id: str) -> dict[str, Any]:
    msg = await with_retry(lambda: client.me.messages.by_message_id(draft_id).get())
    return _serialize_draft(msg)


async def update_draft(
    client: GraphServiceClient,
    draft_id: str,
    *,
    to: list[str] | None = None,
    subject: str | None = None,
    body: str | None = None,
    body_type: str = "text",
) -> dict[str, Any]:
    patch = Message()
    if to is not None:
        patch.to_recipients = _recipients(to)
    if subject is not None:
        patch.subject = subject
    if body is not None:
        patch.body = _body(body, body_type)
    updated = await with_retry(
        lambda: client.me.messages.by_message_id(draft_id).patch(body=patch)
    )
    return _serialize_draft(updated)


async def send_draft(client: GraphServiceClient, draft_id: str) -> None:
    await with_retry(lambda: client.me.messages.by_message_id(draft_id).send.post())


async def delete_draft(client: GraphServiceClient, draft_id: str) -> None:
    await with_retry(lambda: client.me.messages.by_message_id(draft_id).delete())


async def list_attachments(
    client: GraphServiceClient, message_id: str
) -> list[dict[str, Any]]:
    result = await with_retry(
        lambda: client.me.messages.by_message_id(message_id).attachments.get()
    )
    attachments = await _iter_collection(
        result,
        lambda url: client.me.messages.by_message_id(message_id)
        .attachments.with_url(url)
        .get(),
    )
    return [_attachment_to_dict(attachment) for attachment in attachments]


async def download_attachment(
    client: GraphServiceClient,
    message_id: str,
    attachment_id: str,
    output_path: str | None = None,
) -> dict[str, Any]:
    attachment = await with_retry(
        lambda: client.me.messages.by_message_id(message_id)
        .attachments.by_attachment_id(attachment_id)
        .get()
    )
    if not isinstance(attachment, FileAttachment):
        raise ValueError("Only file attachments can be downloaded.")
    target = Path(output_path) if output_path else Path(attachment.name or attachment_id)
    target.write_bytes(attachment.content_bytes or b"")
    return {
        "attachment_id": attachment_id,
        "name": attachment.name,
        "content_type": attachment.content_type,
        "size": attachment.size,
        "output_path": str(target.resolve()),
    }


def _file_attachments(file_paths: list[str]) -> list[FileAttachment]:
    attachments: list[FileAttachment] = []
    for raw_path in file_paths:
        path = Path(raw_path).expanduser()
        if not path.exists():
            raise ValueError(f"Attachment file not found: {raw_path}")
        if not path.is_file():
            raise ValueError(f"Attachment path is not a file: {raw_path}")
        data = path.read_bytes()
        if len(data) > _SMALL_ATTACHMENT_MAX_BYTES:
            raise ValueError(
                f"Attachment '{path.name}' exceeds the { _SMALL_ATTACHMENT_MAX_BYTES } byte"
                " small-file limit for this CLI."
            )
        attachments.append(
            FileAttachment(
                name=path.name,
                content_type="application/octet-stream",
                content_bytes=data,
                size=len(data),
            )
        )
    return attachments


async def add_files_to_draft(
    client: GraphServiceClient,
    draft_id: str,
    file_paths: list[str],
) -> list[dict[str, Any]]:
    created: list[dict[str, Any]] = []
    for attachment in _file_attachments(file_paths):
        result = await with_retry(
            lambda attachment=attachment: client.me.messages.by_message_id(draft_id)
            .attachments.post(attachment)
        )
        created.append(_attachment_to_dict(result))
    return created
