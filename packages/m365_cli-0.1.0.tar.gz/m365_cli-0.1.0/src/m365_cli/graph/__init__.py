"""Microsoft Graph API package for m365-cli."""
