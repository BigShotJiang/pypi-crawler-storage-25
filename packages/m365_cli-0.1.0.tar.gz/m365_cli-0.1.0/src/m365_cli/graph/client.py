"""GraphServiceClient factory.

Two modes:
  • device_code / refresh-token → OAuthCredential wraps the AuthManager
  • client_credentials           → azure-identity ClientSecretCredential
"""

from __future__ import annotations

import logging
import time
from typing import Any

from azure.core.credentials import AccessToken
from azure.identity import ClientSecretCredential
from msgraph import GraphServiceClient

from m365_cli.auth.manager import AuthManager
from m365_cli.config import Settings

logger = logging.getLogger(__name__)


class OAuthCredential:
    """Thin Azure credential shim that delegates to our AuthManager."""

    def __init__(self, auth_manager: AuthManager) -> None:
        self._auth = auth_manager

    def get_token(self, *_scopes: str, **_kwargs: Any) -> AccessToken:
        token = self._auth.get_access_token()
        logger.debug("OAuthCredential.get_token → %s…", token[:20])

        tokens = self._auth.token_store.load_tokens()
        if tokens and tokens.get("expires_at"):
            from datetime import timezone
            ea = tokens["expires_at"]
            if ea.tzinfo is None:
                from datetime import timezone
                ea = ea.replace(tzinfo=timezone.utc)
            expires_on = int(ea.timestamp())
        else:
            expires_on = int(time.time()) + 3600

        return AccessToken(token, expires_on)


def get_graph_client(settings: Settings, auth_manager: AuthManager) -> GraphServiceClient:
    """Build and return a configured GraphServiceClient.

    For client_credentials mode the standard azure-identity credential is used
    so that application-level (non-delegated) Graph calls work correctly.
    For device_code mode our OAuthCredential shim handles refresh transparently.
    """
    if settings.microsoft_auth_mode == "client_credentials":
        if not settings.microsoft_client_secret:
            raise ValueError(
                "MICROSOFT_CLIENT_SECRET is required for client_credentials mode."
            )
        credential = ClientSecretCredential(
            tenant_id=settings.microsoft_tenant_id,
            client_id=settings.microsoft_client_id,
            client_secret=settings.microsoft_client_secret,
        )
    else:
        credential = OAuthCredential(auth_manager)

    return GraphServiceClient(credentials=credential)
