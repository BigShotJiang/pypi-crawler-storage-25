"""Microsoft Graph calendar operations."""

from __future__ import annotations

import logging
from datetime import date, datetime, timedelta
from typing import Any

from msgraph import GraphServiceClient

from m365_cli.retry import with_retry

logger = logging.getLogger(__name__)


def _attendees(attendee_emails: list[str]) -> list[Any]:
    from msgraph.generated.models.attendee import Attendee
    from msgraph.generated.models.attendee_type import AttendeeType
    from msgraph.generated.models.email_address import EmailAddress

    return [
        Attendee(
            email_address=EmailAddress(address=email),
            type=AttendeeType.Required,
        )
        for email in attendee_emails
    ]


def _dt_tz(value: datetime) -> Any:
    from msgraph.generated.models.date_time_time_zone import DateTimeTimeZone

    return DateTimeTimeZone(
        date_time=value.strftime("%Y-%m-%dT%H:%M:%S"),
        time_zone=str(value.tzinfo) if value.tzinfo else "UTC",
    )


def _event_to_dict(event: Any) -> dict[str, Any]:
    attendees = []
    for attendee in event.attendees or []:
        if attendee.email_address:
            attendees.append(
                {
                    "name": attendee.email_address.name,
                    "email": attendee.email_address.address,
                }
            )

    recurrence = None
    if event.recurrence and event.recurrence.pattern and event.recurrence.range:
        recurrence = {
            "pattern_type": (
                event.recurrence.pattern.type.value
                if event.recurrence.pattern.type
                else None
            ),
            "interval": event.recurrence.pattern.interval,
            "days_of_week": [
                day.value for day in (event.recurrence.pattern.days_of_week or [])
            ],
            "day_of_month": event.recurrence.pattern.day_of_month,
            "range_type": (
                event.recurrence.range.type.value
                if event.recurrence.range.type
                else None
            ),
            "start_date": event.recurrence.range.start_date,
            "end_date": event.recurrence.range.end_date,
            "occurrence_count": event.recurrence.range.number_of_occurrences,
            "timezone": event.recurrence.range.recurrence_time_zone,
        }

    return {
        "id": event.id,
        "subject": event.subject or "",
        "start": event.start.date_time if event.start else None,
        "start_timezone": event.start.time_zone if event.start else None,
        "end": event.end.date_time if event.end else None,
        "end_timezone": event.end.time_zone if event.end else None,
        "location": event.location.display_name if event.location else None,
        "organizer_name": (
            event.organizer.email_address.name
            if event.organizer and event.organizer.email_address
            else None
        ),
        "organizer_email": (
            event.organizer.email_address.address
            if event.organizer and event.organizer.email_address
            else None
        ),
        "attendees": attendees,
        "body_preview": event.body_preview or "",
        "is_online_meeting": event.is_online_meeting or False,
        "online_meeting_url": event.online_meeting_url,
        "recurrence": recurrence,
        "web_link": event.web_link,
    }


def _schedule_item_to_dict(item: Any) -> dict[str, Any]:
    status = item.status.value if item.status else None
    return {
        "status": status,
        "start": item.start.date_time if item.start else None,
        "end": item.end.date_time if item.end else None,
        "subject": item.subject,
        "location": item.location,
        "is_private": item.is_private or False,
    }


def _working_hours_to_dict(working_hours: Any) -> dict[str, Any] | None:
    if not working_hours:
        return None
    return {
        "days_of_week": [day.value for day in (working_hours.days_of_week or [])],
        "start_time": working_hours.start_time,
        "end_time": working_hours.end_time,
        "timezone": (
            working_hours.time_zone.name if working_hours.time_zone else None
        ),
    }


def _suggestion_to_dict(suggestion: Any) -> dict[str, Any]:
    slot = suggestion.meeting_time_slot
    return {
        "confidence": suggestion.confidence,
        "order": suggestion.order,
        "organizer_availability": (
            suggestion.organizer_availability.value
            if suggestion.organizer_availability
            else None
        ),
        "reason": suggestion.suggestion_reason,
        "start": slot.start.date_time if slot and slot.start else None,
        "end": slot.end.date_time if slot and slot.end else None,
        "timezone": slot.start.time_zone if slot and slot.start else None,
        "attendee_availability": [
            {
                "attendee": (
                    availability.attendee.email_address.address
                    if availability.attendee and availability.attendee.email_address
                    else None
                ),
                "availability": (
                    availability.availability.value
                    if availability.availability
                    else None
                ),
            }
            for availability in (suggestion.attendee_availability or [])
        ],
    }


def _build_recurrence(
    *,
    pattern_type: str | None,
    interval: int,
    end_date: date | None,
    occurrence_count: int | None,
    start_time: datetime,
) -> Any | None:
    if not pattern_type:
        return None

    from msgraph.generated.models.day_of_week import DayOfWeek
    from msgraph.generated.models.patterned_recurrence import PatternedRecurrence
    from msgraph.generated.models.recurrence_pattern import RecurrencePattern
    from msgraph.generated.models.recurrence_pattern_type import RecurrencePatternType
    from msgraph.generated.models.recurrence_range import RecurrenceRange
    from msgraph.generated.models.recurrence_range_type import RecurrenceRangeType

    pattern_map = {
        "daily": RecurrencePatternType.Daily,
        "weekly": RecurrencePatternType.Weekly,
        "monthly": RecurrencePatternType.AbsoluteMonthly,
    }
    recurrence_pattern = RecurrencePattern(
        type=pattern_map[pattern_type],
        interval=interval,
    )
    if pattern_type == "weekly":
        weekday = [
            DayOfWeek(start_time.strftime("%A").lower())
        ]
        recurrence_pattern.days_of_week = weekday
        recurrence_pattern.first_day_of_week = DayOfWeek.Monday
    if pattern_type == "monthly":
        recurrence_pattern.day_of_month = start_time.day

    range_type = (
        RecurrenceRangeType.EndDate
        if end_date
        else RecurrenceRangeType.Numbered
        if occurrence_count
        else RecurrenceRangeType.NoEnd
    )
    recurrence_range = RecurrenceRange(
        type=range_type,
        start_date=start_time.date(),
        end_date=end_date,
        number_of_occurrences=occurrence_count,
        recurrence_time_zone=str(start_time.tzinfo) if start_time.tzinfo else "UTC",
    )
    return PatternedRecurrence(pattern=recurrence_pattern, range=recurrence_range)


async def fetch_calendar_events(
    client: GraphServiceClient,
    *,
    start_date: datetime,
    end_date: datetime,
) -> list[dict[str, Any]]:
    from msgraph.generated.users.item.calendar_view.calendar_view_request_builder import (
        CalendarViewRequestBuilder,
    )

    params = CalendarViewRequestBuilder.CalendarViewRequestBuilderGetQueryParameters(
        start_date_time=start_date.isoformat(),
        end_date_time=end_date.isoformat(),
        select=[
            "id",
            "subject",
            "start",
            "end",
            "location",
            "attendees",
            "organizer",
            "bodyPreview",
            "isOnlineMeeting",
            "onlineMeetingUrl",
            "recurrence",
            "webLink",
        ],
    )
    cfg = CalendarViewRequestBuilder.CalendarViewRequestBuilderGetRequestConfiguration(
        query_parameters=params
    )
    result = await with_retry(
        lambda: client.me.calendar_view.get(request_configuration=cfg)
    )
    events = result.value if result and result.value else []
    return [_event_to_dict(event) for event in events]


async def create_calendar_event(
    client: GraphServiceClient,
    *,
    subject: str,
    start_time: datetime,
    end_time: datetime,
    attendee_emails: list[str],
    body: str | None = None,
    location: str | None = None,
    is_online_meeting: bool = False,
    recurrence_pattern: str | None = None,
    recurrence_interval: int = 1,
    recurrence_end_date: date | None = None,
    recurrence_count: int | None = None,
) -> dict[str, Any]:
    from msgraph.generated.models.body_type import BodyType
    from msgraph.generated.models.event import Event
    from msgraph.generated.models.item_body import ItemBody
    from msgraph.generated.models.location import Location

    event = Event(
        subject=subject,
        start=_dt_tz(start_time),
        end=_dt_tz(end_time),
        attendees=_attendees(attendee_emails),
        is_online_meeting=is_online_meeting,
        recurrence=_build_recurrence(
            pattern_type=recurrence_pattern,
            interval=recurrence_interval,
            end_date=recurrence_end_date,
            occurrence_count=recurrence_count,
            start_time=start_time,
        ),
    )
    if body:
        event.body = ItemBody(content_type=BodyType.Text, content=body)
    if location:
        event.location = Location(display_name=location)

    created = await with_retry(lambda: client.me.events.post(event))
    return _event_to_dict(created)


async def update_calendar_event(
    client: GraphServiceClient,
    *,
    event_id: str,
    subject: str | None = None,
    start_time: datetime | None = None,
    end_time: datetime | None = None,
    attendee_emails: list[str] | None = None,
    body: str | None = None,
    location: str | None = None,
    is_online_meeting: bool | None = None,
) -> dict[str, Any]:
    from msgraph.generated.models.body_type import BodyType
    from msgraph.generated.models.event import Event
    from msgraph.generated.models.item_body import ItemBody
    from msgraph.generated.models.location import Location

    patch = Event()
    if subject is not None:
        patch.subject = subject
    if start_time is not None:
        patch.start = _dt_tz(start_time)
    if end_time is not None:
        patch.end = _dt_tz(end_time)
    if attendee_emails is not None:
        patch.attendees = _attendees(attendee_emails)
    if body is not None:
        patch.body = ItemBody(content_type=BodyType.Text, content=body)
    if location is not None:
        patch.location = Location(display_name=location)
    if is_online_meeting is not None:
        patch.is_online_meeting = is_online_meeting

    updated = await with_retry(
        lambda: client.me.events.by_event_id(event_id).patch(body=patch)
    )
    return _event_to_dict(updated)


async def delete_calendar_event(client: GraphServiceClient, event_id: str) -> None:
    await with_retry(lambda: client.me.events.by_event_id(event_id).delete())


async def get_availability(
    client: GraphServiceClient,
    *,
    users: list[str],
    start_time: datetime,
    end_time: datetime,
    duration_minutes: int,
) -> dict[str, Any]:
    from msgraph.generated.models.activity_domain import ActivityDomain
    from msgraph.generated.models.attendee_base import AttendeeBase
    from msgraph.generated.models.date_time_time_zone import DateTimeTimeZone
    from msgraph.generated.models.email_address import EmailAddress
    from msgraph.generated.models.location_constraint import LocationConstraint
    from msgraph.generated.models.time_constraint import TimeConstraint
    from msgraph.generated.models.time_slot import TimeSlot
    from msgraph.generated.users.item.calendars.item.get_schedule.get_schedule_post_request_body import (
        GetSchedulePostRequestBody,
    )
    from msgraph.generated.users.item.find_meeting_times.find_meeting_times_post_request_body import (
        FindMeetingTimesPostRequestBody,
    )

    start = DateTimeTimeZone(
        date_time=start_time.strftime("%Y-%m-%dT%H:%M:%S"),
        time_zone=str(start_time.tzinfo) if start_time.tzinfo else "UTC",
    )
    end = DateTimeTimeZone(
        date_time=end_time.strftime("%Y-%m-%dT%H:%M:%S"),
        time_zone=str(end_time.tzinfo) if end_time.tzinfo else "UTC",
    )

    schedule_response = await with_retry(
        lambda: client.me.calendar.get_schedule.post(
            body=GetSchedulePostRequestBody(
                schedules=users,
                start_time=start,
                end_time=end,
                availability_view_interval=duration_minutes,
            )
        )
    )

    suggestions_response = await with_retry(
        lambda: client.me.find_meeting_times.post(
            body=FindMeetingTimesPostRequestBody(
                attendees=[
                    AttendeeBase(email_address=EmailAddress(address=user))
                    for user in users
                ],
                location_constraint=LocationConstraint(is_required=False),
                max_candidates=10,
                meeting_duration=timedelta(minutes=duration_minutes),
                return_suggestion_reasons=True,
                time_constraint=TimeConstraint(
                    activity_domain=ActivityDomain.Work,
                    time_slots=[TimeSlot(start=start, end=end)],
                ),
            )
        )
    )

    schedule_data = []
    for info in (schedule_response.value or []):
        schedule_data.append(
            {
                "user": info.schedule_id,
                "availability_view": info.availability_view,
                "working_hours": _working_hours_to_dict(info.working_hours),
                "busy": [
                    _schedule_item_to_dict(item)
                    for item in (info.schedule_items or [])
                ],
                "error": (
                    {
                        "message": info.error.message,
                        "response_code": info.error.response_code,
                    }
                    if info.error
                    else None
                ),
            }
        )

    return {
        "start": start_time.isoformat(),
        "end": end_time.isoformat(),
        "duration_minutes": duration_minutes,
        "users": users,
        "schedules": schedule_data,
        "suggestions": [
            _suggestion_to_dict(suggestion)
            for suggestion in (
                suggestions_response.meeting_time_suggestions or []
            )
        ],
        "empty_suggestions_reason": suggestions_response.empty_suggestions_reason,
    }


async def respond_to_meeting(
    client: GraphServiceClient,
    *,
    event_id: str,
    response: str,
    comment: str | None = None,
) -> None:
    response = response.lower()
    if response == "accept":
        from msgraph.generated.users.item.events.item.accept.accept_post_request_body import (
            AcceptPostRequestBody,
        )

        await client.me.events.by_event_id(event_id).accept.post(
            body=AcceptPostRequestBody(comment=comment, send_response=True)
        )
    elif response == "decline":
        from msgraph.generated.users.item.events.item.decline.decline_post_request_body import (
            DeclinePostRequestBody,
        )

        await client.me.events.by_event_id(event_id).decline.post(
            body=DeclinePostRequestBody(comment=comment, send_response=True)
        )
    elif response == "tentative":
        from msgraph.generated.users.item.events.item.tentatively_accept.tentatively_accept_post_request_body import (
            TentativelyAcceptPostRequestBody,
        )

        await client.me.events.by_event_id(event_id).tentatively_accept.post(
            body=TentativelyAcceptPostRequestBody(comment=comment, send_response=True)
        )
    else:
        raise ValueError(f"Invalid response '{response}'. Use: accept, decline, tentative")
