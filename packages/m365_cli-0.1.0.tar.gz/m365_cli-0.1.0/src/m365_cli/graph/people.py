"""Microsoft Graph people operations."""

from __future__ import annotations

from typing import Any

from msgraph import GraphServiceClient

from m365_cli.retry import with_retry


def _person_to_dict(person: Any) -> dict[str, Any]:
    scored_emails = []
    for scored in person.scored_email_addresses or []:
        if scored.address:
            scored_emails.append(
                {
                    "address": scored.address,
                    "score": scored.relevance_score,
                }
            )
    primary_email = (
        scored_emails[0]["address"] if scored_emails else person.user_principal_name
    )
    return {
        "id": person.id,
        "display_name": person.display_name,
        "email": primary_email,
        "emails": [entry["address"] for entry in scored_emails],
        "job_title": person.job_title,
        "department": person.department,
        "company_name": person.company_name,
        "office_location": person.office_location,
        "person_type": (
            person.person_type.class_ if person.person_type else None
        ),
        "score": scored_emails[0]["score"] if scored_emails else None,
        "user_principal_name": person.user_principal_name,
    }


async def search_people(
    client: GraphServiceClient,
    *,
    query: str,
    limit: int = 10,
) -> list[dict[str, Any]]:
    from msgraph.generated.users.item.people.people_request_builder import (
        PeopleRequestBuilder,
    )

    params = PeopleRequestBuilder.PeopleRequestBuilderGetQueryParameters(
        search=f'"{query}"',
        top=limit,
        select=[
            "id",
            "displayName",
            "scoredEmailAddresses",
            "jobTitle",
            "department",
            "companyName",
            "officeLocation",
            "personType",
            "userPrincipalName",
        ],
    )
    cfg = PeopleRequestBuilder.PeopleRequestBuilderGetRequestConfiguration(
        query_parameters=params
    )
    result = await with_retry(lambda: client.me.people.get(request_configuration=cfg))
    people = result.value if result and result.value else []
    return [_person_to_dict(person) for person in people]
