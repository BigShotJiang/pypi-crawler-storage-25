"""Local, Fernet-encrypted token storage for Microsoft 365 OAuth credentials.

Tokens are stored in a single JSON file (default: ~/.m365/tokens.json).
The refresh token is encrypted at rest using a Fernet symmetric key.
The key is loaded from TOKEN_ENCRYPTION_KEY env-var or auto-generated
and saved alongside the token file as ~/.m365/.key (chmod 600).
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from cryptography.fernet import Fernet

logger = logging.getLogger(__name__)


class TokenStore:
    """Manages encrypted, file-based storage of Microsoft 365 OAuth tokens."""

    def __init__(self, token_path: Path, encryption_key: str | None = None) -> None:
        self.token_path = token_path.expanduser()
        self._key = self._resolve_key(encryption_key)
        self._cipher = Fernet(self._key)

    # ── Key management ───────────────────────────────────────────────────────

    def _resolve_key(self, env_key: str | None) -> bytes:
        if env_key:
            return env_key.encode()

        key_path = self.token_path.parent / ".key"
        if key_path.exists():
            return key_path.read_bytes().strip()

        key = Fernet.generate_key()
        key_path.parent.mkdir(parents=True, exist_ok=True)
        key_path.write_bytes(key)
        key_path.chmod(0o600)
        import click
        click.echo(
            f"\n⚠  New encryption key generated and saved to {key_path}\n"
            f"   Add this to your .env to keep tokens portable:\n\n"
            f"   TOKEN_ENCRYPTION_KEY={key.decode()}\n",
            err=True,
        )
        return key

    # ── Persistence ──────────────────────────────────────────────────────────

    def save_tokens(
        self,
        *,
        access_token: str,
        refresh_token: str,
        expires_in: int,
        token_type: str = "Bearer",
        scope: str | None = None,
    ) -> None:
        expires_at = datetime.now(timezone.utc) + timedelta(seconds=expires_in)
        encrypted_rt = self._cipher.encrypt(refresh_token.encode()).decode()

        data = {
            "access_token": access_token,
            "refresh_token": encrypted_rt,
            "token_type": token_type,
            "expires_at": expires_at.isoformat(),
            "scope": scope,
            "saved_at": datetime.now(timezone.utc).isoformat(),
        }

        self.token_path.parent.mkdir(parents=True, exist_ok=True)
        self.token_path.write_text(json.dumps(data, indent=2))
        self.token_path.chmod(0o600)
        logger.debug("Tokens saved → %s (expires %s)", self.token_path, expires_at)

    def load_tokens(self) -> dict[str, Any] | None:
        if not self.token_path.exists():
            return None
        try:
            data = json.loads(self.token_path.read_text())
            decrypted_rt = self._cipher.decrypt(data["refresh_token"].encode()).decode()
            expires_at_str = data["expires_at"].replace("Z", "+00:00")
            expires_at = datetime.fromisoformat(expires_at_str)
            if expires_at.tzinfo is None:
                expires_at = expires_at.replace(tzinfo=timezone.utc)
            return {
                "access_token": data["access_token"],
                "refresh_token": decrypted_rt,
                "token_type": data.get("token_type", "Bearer"),
                "expires_at": expires_at,
                "scope": data.get("scope"),
            }
        except Exception as exc:
            logger.warning("Could not load/decrypt tokens (%s); treating as missing.", exc)
            return None

    def clear_tokens(self) -> None:
        if self.token_path.exists():
            self.token_path.unlink()
            logger.info("Tokens cleared from %s", self.token_path)

    # ── Status helpers ───────────────────────────────────────────────────────

    def is_expired(self, buffer_seconds: int = 300) -> bool:
        tokens = self.load_tokens()
        if not tokens:
            return True
        expires_at: datetime = tokens["expires_at"]
        if expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=timezone.utc)
        return expires_at <= datetime.now(timezone.utc) + timedelta(seconds=buffer_seconds)

    def has_valid_tokens(self) -> bool:
        return not self.is_expired()

    def get_access_token(self) -> str | None:
        if self.is_expired():
            return None
        tokens = self.load_tokens()
        return tokens["access_token"] if tokens else None

    def get_refresh_token(self) -> str | None:
        tokens = self.load_tokens()
        return tokens["refresh_token"] if tokens else None
