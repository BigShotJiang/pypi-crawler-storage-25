"""MSAL-based authentication manager.

Supports two flows:
  • device_code        – interactive; user visits a URL and enters a code.
                         Best for first-time setup and human use.
  • client_credentials – headless service account; requires a client secret
                         and admin-consented application permissions in Azure.
"""

from __future__ import annotations

import logging
from typing import Any

import msal

from m365_cli.auth.token_store import TokenStore
from m365_cli.config import Settings

logger = logging.getLogger(__name__)

# Delegated (user-level) scopes — used for device_code flow
DELEGATED_SCOPES = [
    "https://graph.microsoft.com/User.Read",
    "https://graph.microsoft.com/Mail.Read",
    "https://graph.microsoft.com/Mail.ReadWrite",
    "https://graph.microsoft.com/Mail.Send",
    "https://graph.microsoft.com/Calendars.Read",
    "https://graph.microsoft.com/Calendars.ReadWrite",
    "https://graph.microsoft.com/People.Read",
]

# Application scope — used for client_credentials flow
APP_SCOPE = ["https://graph.microsoft.com/.default"]


class AuthManager:
    """Unified authentication manager supporting device-code and service-account flows."""

    def __init__(self, settings: Settings, token_store: TokenStore) -> None:
        self.settings = settings
        self.token_store = token_store
        self._authority = (
            f"https://login.microsoftonline.com/{settings.microsoft_tenant_id}"
        )
        self._msal_app = self._build_msal_app()

    # ── MSAL app factory ─────────────────────────────────────────────────────

    def _build_msal_app(self) -> msal.ClientApplication:
        # device_code flow requires PublicClientApplication — ConfidentialClientApplication
        # does NOT expose initiate_device_flow(), regardless of whether a secret is present.
        # client_credentials flow requires ConfidentialClientApplication.
        if self.settings.microsoft_auth_mode == "client_credentials":
            if not self.settings.microsoft_client_secret:
                raise ValueError(
                    "MICROSOFT_CLIENT_SECRET is required for client_credentials mode."
                )
            return msal.ConfidentialClientApplication(
                client_id=self.settings.microsoft_client_id,
                client_credential=self.settings.microsoft_client_secret,
                authority=self._authority,
            )
        # device_code (default) — always a public client
        return msal.PublicClientApplication(
            client_id=self.settings.microsoft_client_id,
            authority=self._authority,
        )

    # ── Device code flow ─────────────────────────────────────────────────────

    def initiate_device_flow(self) -> dict[str, Any]:
        """Start device code flow; returns the flow dict (contains message for user)."""
        flow = self._msal_app.initiate_device_flow(scopes=DELEGATED_SCOPES)
        if "error" in flow:
            desc = flow.get("error_description", flow.get("error", "unknown"))
            hint = ""
            if "marked as 'mobile'" in desc or "AADSTS70002" in desc:
                hint = (
                    " FIX: In Azure Portal → App registrations → your app → "
                    "Authentication → Advanced settings → "
                    "set 'Allow public client flows' to Yes → Save."
                )
            raise RuntimeError(f"Failed to initiate device flow: {desc}{hint}")
        return flow

    def complete_device_flow(self, flow: dict[str, Any]) -> None:
        """Block until the user completes the browser step, then save tokens."""
        result = self._msal_app.acquire_token_by_device_flow(flow)
        self._save_result(result, flow="device_code")

    def authenticate_device_code(self) -> None:
        """Full device code authentication (initiate + complete).
        Prints the user-facing message and blocks until done.
        """
        flow = self.initiate_device_flow()
        print(flow["message"])  # e.g. "To sign in, use a web browser…"
        self.complete_device_flow(flow)

    # ── Client credentials flow ──────────────────────────────────────────────

    def authenticate_service_account(self) -> str:
        """Acquire a token using client credentials (application permissions).
        Returns the access token string (not cached to disk — short-lived).
        """
        if not self.settings.microsoft_client_secret:
            raise ValueError("MICROSOFT_CLIENT_SECRET is required for client_credentials mode.")
        result = self._msal_app.acquire_token_for_client(scopes=APP_SCOPE)
        if "access_token" not in result:
            raise RuntimeError(result.get("error_description", result.get("error")))
        return result["access_token"]

    # ── Token refresh ────────────────────────────────────────────────────────

    def refresh_access_token(self) -> str:
        """Refresh the stored access token using the saved refresh token."""
        rt = self.token_store.get_refresh_token()
        if not rt:
            raise ValueError("No refresh token available. Re-run: m365 auth login")
        result = self._msal_app.acquire_token_by_refresh_token(
            refresh_token=rt,
            scopes=DELEGATED_SCOPES,
        )
        self._save_result(result, flow="refresh")
        return result["access_token"]

    def get_access_token(self) -> str:
        """Return a valid access token, refreshing automatically if needed."""
        if self.settings.microsoft_auth_mode == "client_credentials":
            return self.authenticate_service_account()

        cached = self.token_store.get_access_token()
        if cached:
            return cached
        logger.info("Access token expired; refreshing…")
        return self.refresh_access_token()

    # ── Status ───────────────────────────────────────────────────────────────

    def is_authenticated(self) -> bool:
        """True if usable tokens are on disk (device_code) or creds are set (cc)."""
        if self.settings.microsoft_auth_mode == "client_credentials":
            return bool(self.settings.microsoft_client_secret)
        tokens = self.token_store.load_tokens()
        return tokens is not None and tokens.get("refresh_token") is not None

    def logout(self) -> None:
        self.token_store.clear_tokens()

    # ── Internal helpers ─────────────────────────────────────────────────────

    def _save_result(self, result: dict[str, Any], *, flow: str) -> None:
        if "access_token" not in result:
            raise RuntimeError(
                f"{flow} failed: {result.get('error_description', result.get('error'))}"
            )
        self.token_store.save_tokens(
            access_token=result["access_token"],
            refresh_token=result.get("refresh_token", ""),
            expires_in=result.get("expires_in", 3600),
            token_type=result.get("token_type", "Bearer"),
            scope=" ".join(result.get("scope", [])) if isinstance(result.get("scope"), list) else result.get("scope"),
        )
        logger.info("Tokens saved (flow=%s)", flow)
