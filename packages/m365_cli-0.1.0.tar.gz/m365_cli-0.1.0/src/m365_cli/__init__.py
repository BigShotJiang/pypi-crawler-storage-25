"""Top-level package for m365-cli."""

__author__ = """Chris Goetz"""
__email__ = "goetzcj@gmail.com"
__version__ = "0.1.0"