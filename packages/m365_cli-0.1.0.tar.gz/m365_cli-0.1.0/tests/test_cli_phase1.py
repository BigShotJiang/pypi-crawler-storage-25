from __future__ import annotations

from click.testing import CliRunner

from m365_cli.cli import main


def test_cli_includes_people_group() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["--help"])

    assert result.exit_code == 0
    assert "people" in result.output


def test_email_draft_reply_adds_files(monkeypatch) -> None:
    from m365_cli.commands import email as email_cmd

    calls: dict[str, object] = {}

    monkeypatch.setattr(email_cmd, "_graph_client", lambda: object())

    async def fake_create_reply_draft(client, **kwargs):
        calls["create"] = kwargs
        return {"draft_id": "draft-123", "subject": "Re: Test"}

    async def fake_add_files_to_draft(client, draft_id, file_paths):
        calls["attachments"] = {"draft_id": draft_id, "file_paths": file_paths}
        return [{"id": "att-1"}]

    monkeypatch.setattr(email_cmd.graph_email, "create_reply_draft", fake_create_reply_draft)
    monkeypatch.setattr(email_cmd.graph_email, "add_files_to_draft", fake_add_files_to_draft)

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "email",
            "draft",
            "reply",
            "msg-1",
            "--reply-all",
            "--body",
            "hello",
            "--file",
            "note.txt",
        ],
    )

    assert result.exit_code == 0
    assert '"draft_id": "draft-123"' in result.output
    assert calls["create"] == {
        "message_id": "msg-1",
        "body": "hello",
        "body_type": "text",
        "reply_all": True,
    }
    assert calls["attachments"] == {
        "draft_id": "draft-123",
        "file_paths": ["note.txt"],
    }


def test_email_search_passes_filters(monkeypatch) -> None:
    import types
    from m365_cli.commands import email as email_cmd

    calls: dict[str, object] = {}

    # _resolve_window calls _get_settings_or_exit() for the timezone; stub it out
    # so the test doesn't require a real .env file.
    mock_settings = types.SimpleNamespace(my_timezone="UTC", default_email_limit=20)
    monkeypatch.setattr(email_cmd, "_get_settings_or_exit", lambda: mock_settings)
    monkeypatch.setattr(email_cmd, "_graph_client", lambda: object())

    async def fake_fetch_emails(client, **kwargs):
        calls["kwargs"] = kwargs
        return [{"id": "msg-1", "subject": "Search hit"}]

    monkeypatch.setattr(email_cmd.graph_email, "fetch_emails", fake_fetch_emails)

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "email",
            "search",
            "--query",
            "invoice",
            "--folder",
            "Inbox",
            "--limit",
            "15",
            "--unread-only",
            "--since",
            "2026-04-20",
            "--until",
            "2026-04-21",
        ],
    )

    assert result.exit_code == 0
    kwargs = calls["kwargs"]
    assert kwargs["query"] == "invoice"
    assert kwargs["folder"] == "Inbox"
    assert kwargs["limit"] == 15
    assert kwargs["unread_only"] is True
    assert kwargs["include_body"] is False
    assert kwargs["since"] is not None
    assert kwargs["until"] is not None


def test_calendar_create_rejects_conflicting_recurrence_options() -> None:
    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "calendar",
            "create",
            "--subject",
            "Weekly sync",
            "--start",
            "2026-04-20T09:00:00-05:00",
            "--end",
            "2026-04-20T09:30:00-05:00",
            "--recurrence",
            "weekly",
            "--recurrence-until",
            "2026-05-31",
            "--recurrence-count",
            "5",
        ],
    )

    assert result.exit_code == 1
    assert "Use only one of --recurrence-until or --recurrence-count." in result.output


def test_calendar_availability_emits_graph_result(monkeypatch) -> None:
    from m365_cli.commands import calendar as calendar_cmd

    monkeypatch.setattr(calendar_cmd, "_graph_client", lambda: object())

    async def fake_get_availability(client, **kwargs):
        assert kwargs["users"] == ["a@example.com", "b@example.com"]
        return {
            "start": kwargs["start_time"].isoformat(),
            "end": kwargs["end_time"].isoformat(),
            "duration_minutes": kwargs["duration_minutes"],
            "users": kwargs["users"],
            "schedules": [],
            "suggestions": [],
            "empty_suggestions_reason": "",
        }

    monkeypatch.setattr(calendar_cmd.graph_cal, "get_availability", fake_get_availability)

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "calendar",
            "availability",
            "--user",
            "a@example.com",
            "--user",
            "b@example.com",
            "--start",
            "2026-04-20T09:00:00-05:00",
            "--end",
            "2026-04-20T11:00:00-05:00",
        ],
    )

    assert result.exit_code == 0
    assert '"duration_minutes": 30' in result.output
    assert '"count": 2' in result.output


def test_people_search_emits_results(monkeypatch) -> None:
    from m365_cli.commands import people as people_cmd

    monkeypatch.setattr(people_cmd, "_graph_client", lambda: object())

    async def fake_search_people(client, *, query, limit):
        assert query == "chris"
        assert limit == 5
        return [
            {
                "display_name": "Chris Goetz",
                "email": "chris@example.com",
                "emails": ["chris@example.com"],
                "job_title": "Engineer",
                "department": "Product",
                "person_type": "Person",
                "score": 0.98,
            }
        ]

    monkeypatch.setattr(people_cmd.graph_people, "search_people", fake_search_people)

    runner = CliRunner()
    result = runner.invoke(main, ["people", "search", "--query", "chris", "--limit", "5"])

    assert result.exit_code == 0
    assert '"display_name": "Chris Goetz"' in result.output
    assert '"count": 1' in result.output


def test_handle_graph_error_maps_not_found() -> None:
    from m365_cli import output

    try:
        output.handle_graph_error(RuntimeError("ErrorItemNotFound: missing message"))
    except SystemExit as exc:
        assert exc.code == 3
    else:
        raise AssertionError("Expected SystemExit")


def test_emit_uses_utc_z_suffix(capsys) -> None:
    from m365_cli import output

    output.emit({"ok": True})
    captured = capsys.readouterr()

    assert '"success": true' in captured.out
    assert '"fetched_at": "' in captured.out
    assert "Z" in captured.out
