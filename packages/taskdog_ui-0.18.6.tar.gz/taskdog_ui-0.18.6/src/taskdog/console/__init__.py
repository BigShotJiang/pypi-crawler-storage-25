"""Console output abstractions."""
