"""TUI constants package."""
