# Bland-Altman Plot
A lightweight Python library for generating **Bland-Altman Plots** to evaluate agreement between two measurements methods.
This implementation provides a simple interface for quickly visualizing bias and limits of agreements.

## Installation
Install from PyPI

```
pip install bland-altman
```
## Usage

```python
import numpy as np
from bland_altman import bland_altman_plot

# Generate example data
np.random.seed(42) 
x = np.random.normal(100,10,500)
y = x + np.random.normal(0,5,500)

# Generate Bland-Altman plot
bland_altman_plot(x, y, ylim=(-20, 20), figsize=(10,6), label_offset=0.025, color='blue', alpha=0.5, display_grid=True, display_legend=True)
```

## Example Plot
Below is an example Bland-Altman plot generated using this library.

<p align="center">
    <img src="https://github.com/amulshinde/bland-altman/blob/main/docs/bland_altman_example.png", width="600">
</p>

---

## Features
- Simple and easy-to-use API
- Automate calculation of mean difference and limits of agreement
- Customizable plot appearance
- Buit using Numpy and Matplotlib

---
## Requirements
- Python 3.8+
- NumPy
- Matplotlib

These dependencies will be installed automatically with the package.

---
## License
This project is licensed under MIT License.