from ._validation import validate_inputs
import numpy as np
import matplotlib.pyplot as plt


def bland_altman_plot(data1, data2, figsize=(8, 5), ylim=None, label_offset=0.02, color='blue', alpha=0.5, 
                      display_grid=True, display_legend=True, save_path=None, dpi=300, 
                      title="Bland–Altman Plot", xlabel="Mean", ylabel="Difference", 
                      data_label="Data Points"):
    """
    Generate a Bland–Altman plot to assess agreement between two measurement methods.

    Parameters
    ----------
    data1 : array-like
    First set of measurements.

    data2 : array-like
    Second set of measurements (must have the same length as data1).

    figsize : tuple of float, optional, default=(8, 5)
    Size of the figure as (width, height) in inches.

    ylim : tuple of float, optional
    Limits for the y-axis as (min, max). If not provided, limits are determined automatically.

    label_offset : float, optional, default=0.02
    Fraction of the y-axis range used to vertically offset annotation labels from the lines.

    color : str, optional, default=‘blue’
    Color of the scatter points.

    alpha : float, optional, default=0.5
    Transparency level of the scatter points (0 = fully transparent, 1 = opaque).

    display_grid : bool, optional, default=True
    Whether to display grid lines on the plot.

    display_legend : bool, optional, default=True
    Whether to display the legend.

    save_path : str or None, optional
    File path to save the figure. If None, the figure is not saved.

    dpi : int, optional, default=300
    Resolution of the saved figure in dots per inch.

    title : str, optional, default=“Bland–Altman Plot”
    Title of the plot.

    xlabel : str, optional, default=“Mean”
    Label for the x-axis.

    ylabel : str, optional, default=“Difference”
    Label for the y-axis.

    data_label : str, optional, default=“Data Points”
    Label used for the scatter plot in the legend.

    Returns
    -------
    None
    Displays the Bland–Altman plot and optionally saves it to disk.
    """

    # # Remove ylim from kwargs if user mistakenly passed it there
    # ylim = kwargs.pop("ylim", ylim)

    data1, data2 = validate_inputs(data1, data2)

    mean = np.mean([data1, data2], axis=0)
    diff = data1 - data2

    md = np.mean(diff)
    sd = np.std(diff)

    upper = md + 1.96 * sd
    lower = md - 1.96 * sd

    plt.figure(figsize=figsize)

    plt.scatter(mean, diff, label=data_label, color=color, alpha=alpha)

    plt.axhline(md, color='gray', linestyle='-.', label="Mean Difference")
    plt.axhline(upper, color='gray', linestyle='--', label="± 1.96 SD")
    plt.axhline(lower, color='gray', linestyle='--')

    # ---- Y-axis limits ----
    if ylim is not None:

        if not isinstance(ylim, (tuple, list)) or len(ylim) != 2:
            raise ValueError("ylim must be a tuple or list with two values (min, max).")

        ymin, ymax = ylim

        if ymin >= ymax:
            raise ValueError("ylim minimum must be smaller than maximum.")

        plt.ylim(ymin, ymax)

    else:
        padding = 0.1 * (diff.max() - diff.min())
        ymin = min(diff.min(), lower) - padding
        ymax = max(diff.max(), upper) + padding
        plt.ylim(ymin, ymax)

    # ---- Text positioning ----
    y_range = plt.ylim()[1] - plt.ylim()[0]
    offset = label_offset * y_range
    x_pos = np.max(mean) * 0.98

    plt.text(
        x_pos,
        upper + offset,
        f'+1.96 SD = {upper:.2f}',
        ha='right',
        bbox=dict(facecolor='white', edgecolor='none', alpha=0.7)
    )

    plt.text(
        x_pos,
        md + offset,
        f'Mean = {md:.2f}',
        ha='right',
        bbox=dict(facecolor='white', edgecolor='none', alpha=0.7)
    )

    plt.text(
        x_pos,
        lower - offset,
        f'-1.96 SD = {lower:.2f}',
        ha='right',
        bbox=dict(facecolor='white', edgecolor='none', alpha=0.7),
        verticalalignment='top'
    )

    plt.xlabel(xlabel, fontsize=14)
    plt.ylabel(ylabel, fontsize=14)
    plt.title(title)

    if display_grid:
        plt.grid(True, linestyle='--', alpha=0.5)

    if display_legend:
        plt.legend(loc="best")
    
    plt.tight_layout()
    
    if save_path is not None:
        plt.savefig(save_path, dpi=dpi, bbox_inches='tight')

    plt.show()
    