import numpy as np

def validate_inputs(data1, data2):
    """Validate input arrays."""

    data1 = np.asarray(data1)
    data2 = np.asarray(data2)

    if data1.shape != data2.shape:
        raise ValueError(
            f"Input data must have the same length. "
            f"Got len(data1)={len(data1)} and len(data2)={len(data2)}."
        )

    return data1, data2