# from .plot import bland_altman_plot

"""
Bland–Altman
---------

Simple and lightweight Bland–Altman plotting utility.
"""

from .plot import bland_altman_plot

__all__ = ["bland_altman_plot"]

__version__ = "0.1.4"