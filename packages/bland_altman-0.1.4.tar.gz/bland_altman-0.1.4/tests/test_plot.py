import os
import sys

import numpy as np
import pytest
import matplotlib
import matplotlib.pyplot as plt


# Ensure src package root is on sys.path when tests are run
CURRENT_DIR = os.path.dirname(__file__)
PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, os.pardir))
SRC_ROOT = os.path.join(PROJECT_ROOT, "src")
if SRC_ROOT not in sys.path:
    sys.path.insert(0, SRC_ROOT)

from bland_altman import bland_altman_plot


# Use a non-interactive backend for tests so plotting
# does not block or require a display.
matplotlib.use("Agg")


def test_bland_altman_runs():
    """Test that the function runs without errors."""
    
    x = np.array([1,2,3,4,5])
    y = np.array([1.1,2.1,2.9,4.2,5.1])

    # Should run without raising exception
    bland_altman_plot(x, y)
    plt.close("all")


def test_length_mismatch():
    """Test that unequal length arrays raise ValueError."""
    
    x = np.array([1,2,3])
    y = np.array([1,2])

    with pytest.raises(ValueError):
        bland_altman_plot(x, y)
    plt.close("all")


def test_numpy_input_conversion():
    """Test that list inputs are converted correctly."""
    
    x = [1,2,3,4]
    y = [1.1,1.9,3.2,3.8]

    bland_altman_plot(x, y)
    plt.close("all")


def test_ylim_argument():
    """Test manual ylim input."""
    
    x = np.random.normal(100,10,20)
    y = x + np.random.normal(0,5,20)

    bland_altman_plot(x, y, ylim=(-20,20))
    plt.close("all")
