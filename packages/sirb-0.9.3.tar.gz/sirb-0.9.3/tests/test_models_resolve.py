"""Regression tests for `sirb models add/remove` node disambiguation.

The 0.5.0 ship had a real bug: `--node` accepted a 0x-wallet, but
every node an operator owns shares the same wallet (1:1 API-key ↔
wallet binding). The flag could not disambiguate two nodes the
operator owned, defeating its entire purpose. Fixed in 0.5.1+ by
switching the disambiguator to `node_id` (gateway-assigned) — the
wallet stays the owner check only.

These tests pin the new behavior so the regression can't reappear.
"""

from __future__ import annotations

from unittest.mock import patch

import httpx
import pytest

from sirb_cli.commands.models import _mutate_models, _resolve_target_node
from sirb_cli.config import CliConfig

OWNER = "0xowner0000000000000000000000000000000001"
OTHER = "0xstranger00000000000000000000000000000099"


def _mock_nodes_response(nodes: list[dict]):
    """Build an httpx response stub the way the live code consumes it."""

    class _R:
        status_code = 200

        def raise_for_status(self) -> None:
            return None

        def json(self) -> list[dict]:
            return nodes

    return _R()


@pytest.fixture
def two_owned_nodes() -> list[dict]:
    """Two nodes owned by the same operator — same wallet, distinct
    node_ids. This is the case the broken `--node <wallet>` flag
    couldn't disambiguate."""
    return [
        {
            "node_id": "node_workstation_aaa",
            "wallet_address": OWNER,
            "endpoint": "https://ws.example.com",
            "supported_models": ["gemma2:2b"],
        },
        {
            "node_id": "node_homelab_bbb",
            "wallet_address": OWNER,
            "endpoint": "https://lab.example.com",
            "supported_models": ["gemma2:2b", "qwen2.5:0.5b"],
        },
        {
            "node_id": "node_someone_else_zzz",
            "wallet_address": OTHER,
            "endpoint": "https://stranger.example.com",
            "supported_models": ["mock-7b"],
        },
    ]


def test_resolve_owner_with_single_node_auto_targets(two_owned_nodes):
    """When the operator owns exactly one node, return it without
    requiring --node-id."""
    just_one = [n for n in two_owned_nodes if n["node_id"] == "node_workstation_aaa"]
    with patch("sirb_cli.commands.models.httpx.get", return_value=_mock_nodes_response(just_one)):
        node, owned = _resolve_target_node(
            "https://api.sirb.run",
            owner_wallet=OWNER,
            target_node_id=None,
        )
    assert node is not None
    assert node["node_id"] == "node_workstation_aaa"
    assert len(owned) == 1


def test_resolve_owner_with_multiple_nodes_demands_disambiguator(two_owned_nodes):
    """The regression case: two owned nodes, no --node-id given →
    return (None, owned) so the caller can show candidates."""
    with patch(
        "sirb_cli.commands.models.httpx.get", return_value=_mock_nodes_response(two_owned_nodes)
    ):
        node, owned = _resolve_target_node(
            "https://api.sirb.run",
            owner_wallet=OWNER,
            target_node_id=None,
        )
    assert node is None  # caller must demand a node_id
    assert len(owned) == 2
    assert {n["node_id"] for n in owned} == {"node_workstation_aaa", "node_homelab_bbb"}


def test_resolve_owner_with_node_id_targets_correctly(two_owned_nodes):
    """--node-id picks exactly one of the operator's nodes."""
    with patch(
        "sirb_cli.commands.models.httpx.get", return_value=_mock_nodes_response(two_owned_nodes)
    ):
        node, owned = _resolve_target_node(
            "https://api.sirb.run",
            owner_wallet=OWNER,
            target_node_id="node_homelab_bbb",
        )
    assert node is not None
    assert node["node_id"] == "node_homelab_bbb"


def test_resolve_node_id_not_owned_returns_none(two_owned_nodes):
    """Owner check must beat the node_id filter — even a valid node_id
    that belongs to someone else returns None, never leaks to a
    stranger's node."""
    with patch(
        "sirb_cli.commands.models.httpx.get", return_value=_mock_nodes_response(two_owned_nodes)
    ):
        node, owned = _resolve_target_node(
            "https://api.sirb.run",
            owner_wallet=OWNER,
            target_node_id="node_someone_else_zzz",
        )
    assert node is None
    # `owned` still contains the operator's own nodes (for the error
    # display), not the stranger's.
    assert all(n["wallet_address"] == OWNER for n in owned)


def test_resolve_no_owned_nodes_returns_empty():
    """Operator owns zero nodes → (None, [])."""
    with patch("sirb_cli.commands.models.httpx.get", return_value=_mock_nodes_response([])):
        node, owned = _resolve_target_node(
            "https://api.sirb.run",
            owner_wallet=OWNER,
            target_node_id=None,
        )
    assert node is None
    assert owned == []


def test_resolve_network_failure_returns_empty():
    """Gateway unreachable → (None, []) so the caller can surface a
    real error rather than crash."""
    with patch("sirb_cli.commands.models.httpx.get", side_effect=httpx.ConnectError("boom")):
        node, owned = _resolve_target_node(
            "https://api.sirb.run",
            owner_wallet=OWNER,
            target_node_id=None,
        )
    assert node is None
    assert owned == []


def test_mutate_models_hot_update_signs_as_target_node_wallet(tmp_path, monkeypatch):
    """The hot-update path must use a real signer from the resolved node.

    A previous regression referenced an undefined ``target_wallet`` after
    resolving the node, so `sirb models add/remove` persisted the disk
    override and then crashed before the live node-agent update.
    """
    sirb_home = tmp_path / ".sirb"
    sirb_home.mkdir()
    (sirb_home / "callback_secret").write_text("test-secret", encoding="utf-8")
    (sirb_home / "local_url").write_text("http://127.0.0.1:9100", encoding="utf-8")
    monkeypatch.setenv("SIRB_HOME", str(sirb_home))

    node_wallet = "0xnodewallet0000000000000000000000000001"
    node = {
        "node_id": "node_workstation_aaa",
        "wallet_address": node_wallet,
        "endpoint": "https://ws.example.com",
        "supported_models": ["gemma2:2b"],
    }
    seen: dict[str, object] = {}

    def fake_hmac_post(url: str, **kwargs) -> dict:
        seen["url"] = url
        seen.update(kwargs)
        return {"loaded_models": kwargs["payload"]["supported_models"]}

    monkeypatch.setattr(
        "sirb_cli.commands.models.env_override_or_config",
        lambda: CliConfig(base_url="https://api.sirb.run", api_key="sirb_test"),
    )
    monkeypatch.setattr("sirb_cli.commands.models._get_bound_wallet", lambda *_a: OWNER)
    monkeypatch.setattr(
        "sirb_cli.commands.models._resolve_target_node", lambda *_a, **_k: (node, [node])
    )
    monkeypatch.setattr("sirb_cli.commands.models._hmac_post", fake_hmac_post)

    _mutate_models(add_id="qwen2.5:0.5b", remove_id=None, node_id=None, no_pull=True)

    assert seen["url"] == "http://127.0.0.1:9100/admin/models"
    assert seen["signer"] == node_wallet
    assert seen["payload"] == {"supported_models": ["gemma2:2b", "qwen2.5:0.5b"]}
    assert (sirb_home / "data" / "supported_models.json").read_text(encoding="utf-8") == (
        '[\n  "gemma2:2b",\n  "qwen2.5:0.5b"\n]\n'
    )
