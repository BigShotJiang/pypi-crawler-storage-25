from __future__ import annotations

import typer
from rich import print as rprint

from sirb_cli.config import CliConfig, ProfileStore


def run(
    api_key: str = typer.Option(..., "--api-key", "-k", prompt=True, hide_input=True,
                                help="Your Sirb API key (input is hidden)."),
    base_url: str = typer.Option("https://api.sirb.run", "--base-url", "-u",
                                 help="Backend base URL. Defaults to the public Sirb gateway; override for local dev."),
    default_model: str = typer.Option("gemma4:e4b", "--model", "-m",
                                       help="Default model id for `sirb chat`."),
    edge_url: str | None = typer.Option(
        None, "--edge", "-e",
        help="Edge cache node URL. When set, `sirb chat` etc. hit this node first "
             "for models it hosts, falling back to base_url when needed.",
    ),
    profile: str | None = typer.Option(
        None, "--profile", "-p",
        help="Name of the profile to save into. Defaults to the active profile, "
             "or 'default' if no profiles exist yet. See `sirb profiles --help`.",
    ),
) -> None:
    """Save credentials into a profile.

    Without --profile this updates the currently-active profile (or
    creates 'default' if the config file is empty). With --profile it
    writes to a named profile, leaving the active selection alone unless
    nothing was active before.
    """
    store = ProfileStore.load()
    target = profile or store.active

    cfg = CliConfig(
        base_url=base_url.rstrip("/"),
        api_key=api_key,
        default_model=default_model,
        edge_url=edge_url.rstrip("/") if edge_url else None,
    )
    is_new = target not in store.profiles
    store.profiles[target] = cfg
    # When the store was empty, the new profile becomes active automatically.
    if not store.profiles or store.active not in store.profiles:
        store.active = target
    p = store.save()

    label = f"profile [cyan]{target}[/cyan]"
    if target == store.active:
        label += " [bold green](active)[/bold green]"
    verb = "Saved" if is_new else "Updated"
    rprint(f"[green]{verb}[/green] {label} → [bold]{p}[/bold]")
    rprint(f"  base_url:      {cfg.base_url}")
    if cfg.edge_url:
        rprint(f"  edge_url:      {cfg.edge_url}")
    rprint(f"  default_model: {cfg.default_model}")
    rprint(f"  api_key:       [dim]sirb_***{api_key[-6:] if len(api_key) > 6 else '***'}[/dim]")
    if len(store.profiles) > 1:
        rprint(f"\n[dim]You have {len(store.profiles)} profiles. "
               f"Manage with [cyan]sirb profiles[/cyan].[/dim]")
