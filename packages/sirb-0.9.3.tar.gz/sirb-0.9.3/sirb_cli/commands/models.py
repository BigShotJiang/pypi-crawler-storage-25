"""``sirb models`` — list catalog + manage a node's served list.

Three subcommands:

  sirb models                — list models routable in the network
  sirb models list           — same (explicit form)
  sirb models add <id>       — add a model to YOUR node
  sirb models remove <id>    — remove one

`add` / `remove` mutate the running node-agent's runner registry
AND persist the new list to ``~/.sirb/data/supported_models.json``,
which the node-agent reads on every boot — so changes survive
``docker restart sirb-node``.

The CLI:

  1. Confirms your API key is bound to a wallet via ``GET /v1/me``.
  2. Lists your owned nodes (via the public ``GET /nodes`` filter).
     Errors if you own 0 or >1 (pass ``--node <wallet>`` for the
     multi-node case).
  3. For the Ollama backend, runs ``ollama pull <id>`` on the host
     so the model is actually available before we advertise it.
  4. Atomically writes ``~/.sirb/data/supported_models.json``.
  5. HMAC-signs and POSTs to the local node-agent's
     ``POST /admin/models`` so the runner registry updates without
     a container restart. The next heartbeat (forced immediately by
     the agent) carries the new list to the gateway.

Auth model: same HMAC envelope the gateway uses for ``/infer``
callbacks. The secret lives at ``~/.sirb/callback_secret`` on the
operator's host and is shared with the running node-agent
(``SIRB_NODE_SIGNING_SECRET``). No new credentials.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import shutil
import subprocess
import time
from pathlib import Path

import httpx
import typer
from rich import print as rprint
from rich.console import Console
from rich.table import Table

from sirb_cli.client import SirbClient
from sirb_cli.config import env_override_or_config

app = typer.Typer(
    invoke_without_command=True,
    no_args_is_help=False,
    help="List network catalog, or add/remove models on your running node.",
)


# ───────────────────────── network catalog (list) ──────────────────────────


@app.callback()
def default(ctx: typer.Context) -> None:
    """Default action (no subcommand) = list the network catalog,
    matching the pre-0.4 behavior of `sirb models`."""
    if ctx.invoked_subcommand is None:
        _list_catalog()


@app.command("list", help="List models routable in the Sirb network.")
def list_cmd() -> None:
    _list_catalog()


def _list_catalog() -> None:
    body = SirbClient(env_override_or_config()).get("/v1/models")
    table = Table(title="Available models", show_lines=False)
    table.add_column("id", style="bold")
    table.add_column("owned_by", style="dim")
    for m in body.get("data", []):
        table.add_row(m.get("id", ""), m.get("owned_by", ""))
    Console().print(table)


# Back-compat: `sirb_cli.main` calls `models.run` directly because the
# old module exported only that function. Keep the symbol so the entry
# point keeps working when invoked the old way.
def run() -> None:
    _list_catalog()


# ─────────────────────────── add / remove ──────────────────────────────────


@app.command("add")
def add(
    model_id: str = typer.Argument(..., help="Model id to add (e.g. gemma2:2b or hf.co/...)."),
    node_id: str | None = typer.Option(
        None,
        "--node-id",
        "--node",
        help=(
            "Node id of the node to target (NOT the wallet — every node your "
            "API key owns shares the same wallet, so wallet can't "
            "disambiguate). Required when your API key owns >1 nodes; "
            "otherwise auto-detected. `--node` is kept as an alias for "
            "back-compat."
        ),
    ),
    no_pull: bool = typer.Option(
        False,
        "--no-pull",
        help=(
            "Skip the `ollama pull` step. Use when the model isn't on Ollama "
            "or you've already pulled it."
        ),
    ),
) -> None:
    """Add a model to YOUR running node.

    Default flow:
      1. Resolve your wallet via GET /v1/me.
      2. Find your owned nodes via GET /nodes (filter by wallet).
      3. Pick the single owned node, or use --node-id to disambiguate
         when you own multiple.
      4. `ollama pull <model_id>` on the host (skip with --no-pull).
      5. Write ~/.sirb/data/supported_models.json (so the change
         survives container restart).
      6. HMAC-POST to the local node-agent's /admin/models so the
         runner registry updates without a restart.
    """
    _mutate_models(add_id=model_id, remove_id=None, node_id=node_id, no_pull=no_pull)


@app.command("remove")
def remove(
    model_id: str = typer.Argument(..., help="Model id to remove."),
    node_id: str | None = typer.Option(
        None,
        "--node-id",
        "--node",
        help="Node id of the node to target. Required when your API key owns >1 nodes.",
    ),
) -> None:
    """Remove a model from YOUR running node."""
    _mutate_models(add_id=None, remove_id=model_id, node_id=node_id, no_pull=True)


# ─────────────────────────── implementation ────────────────────────────────


def _sirb_home() -> Path:
    import os

    p = Path(os.environ.get("SIRB_HOME") or (Path.home() / ".sirb"))
    p.mkdir(parents=True, exist_ok=True)
    return p


def _mutate_models(
    *,
    add_id: str | None,
    remove_id: str | None,
    node_id: str | None,
    no_pull: bool,
) -> None:
    cfg = env_override_or_config()
    if not cfg.api_key:
        rprint("[red]No API key configured.[/red] Run `sirb login` first.")
        raise typer.Exit(code=1)
    backend_url = cfg.base_url.rstrip("/")

    # 1. Wallet binding — the owner check.
    me_wallet = _get_bound_wallet(backend_url, cfg.api_key)
    if not me_wallet:
        rprint(
            "[red]Your API key has no bound wallet.[/red] "
            "Mint a new key with --wallet or contact your gateway admin."
        )
        raise typer.Exit(code=1)

    # 2. Find target node. Wallet identifies the OWNER (one per API key).
    # node_id identifies WHICH of the owner's nodes — they all share a
    # wallet so wallet alone can't disambiguate, which was the entire
    # point of this fix.
    node, owned_nodes = _resolve_target_node(
        backend_url,
        owner_wallet=me_wallet,
        target_node_id=node_id,
    )
    if node is None:
        if node_id:
            rprint(f"[red]No node with id [bold]{node_id}[/bold] is owned by your API key.[/red]")
            if owned_nodes:
                rprint("Nodes you own:")
                for n in owned_nodes:
                    _print_owned_node_row(n)
        elif not owned_nodes:
            rprint(
                "[red]Your API key owns no registered nodes.[/red] "
                "Run `sirb deploy node ...` first."
            )
        else:
            rprint(
                f"[red]Your API key owns {len(owned_nodes)} nodes — pass "
                f"[cyan]--node-id <id>[/cyan] to pick one:[/red]"
            )
            for n in owned_nodes:
                _print_owned_node_row(n)
        raise typer.Exit(code=1)

    # 3. Compute the new list.
    current = list(node.get("supported_models") or [])
    if add_id:
        if add_id in current:
            rprint(f"[yellow]Model [bold]{add_id}[/bold] is already advertised.[/yellow]")
            raise typer.Exit(code=0)
        new_list = current + [add_id]
    else:
        if remove_id not in current:
            rprint(f"[yellow]Model [bold]{remove_id}[/bold] is not currently advertised.[/yellow]")
            raise typer.Exit(code=0)
        new_list = [m for m in current if m != remove_id]
        if not new_list:
            rprint(
                "[red]Refusing to remove the last model.[/red] "
                "Add another first, or tear the node down with "
                "`docker rm -f sirb-node`."
            )
            raise typer.Exit(code=1)

    rprint(f"[bold]Target node:[/bold] {node.get('wallet_address')}")
    rprint(f"  current models: {current}")
    rprint(f"  new models:     {new_list}")

    # 4. Ollama pull (best-effort).
    if add_id and not no_pull:
        _maybe_ollama_pull(add_id)

    # 5. Persist the new list to ~/.sirb/data/supported_models.json
    #    BEFORE hitting the node — that way if the network step fails,
    #    the change still applies on next container restart.
    home = _sirb_home()
    data_dir = home / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    seed = data_dir / "supported_models.json"
    tmp = seed.with_suffix(".tmp")
    tmp.write_text(json.dumps(new_list, indent=2) + "\n", encoding="utf-8")
    tmp.replace(seed)
    rprint(f"[green]✓[/green] persisted to {seed}")

    # 6. Hot-update via HMAC envelope.
    secret_path = home / "callback_secret"
    if not secret_path.is_file():
        rprint(
            "[red]Missing ~/.sirb/callback_secret.[/red] "
            "Was this node deployed by an older sirb? Re-run `sirb deploy node` to mint one."
        )
        raise typer.Exit(code=1)
    signing_secret = secret_path.read_text(encoding="utf-8").strip()
    local_url = _read_local_url(home)
    target_wallet = node.get("wallet_address") or me_wallet
    try:
        result = _hmac_post(
            f"{local_url}/admin/models",
            payload={"supported_models": new_list},
            signer=target_wallet,
            secret=signing_secret,
            timeout=15.0,
        )
    except httpx.HTTPError as e:
        rprint(
            f"[yellow]Network update failed: {type(e).__name__}: {e}[/yellow]\n"
            f"[dim]The change is already persisted on disk; it will apply on next "
            f"`docker restart {home.name}` or container restart.[/dim]"
        )
        raise typer.Exit(code=2) from e
    loaded = result.get("loaded_models") or []
    rprint(f"[green]✓[/green] node now serving: {loaded}")


def _get_bound_wallet(backend_url: str, api_key: str) -> str | None:
    try:
        r = httpx.get(
            f"{backend_url}/v1/me",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=10.0,
        )
        if r.status_code != 200:
            return None
        return r.json().get("wallet_address")
    except (httpx.HTTPError, ValueError):
        return None


def _resolve_target_node(
    backend_url: str,
    *,
    owner_wallet: str,
    target_node_id: str | None,
) -> tuple[dict | None, list[dict]]:
    """Return (target_node, all_owned_nodes).

    ``owner_wallet`` is the API key's bound wallet — the OWNER check.
    Every node returned in ``all_owned_nodes`` has this wallet.

    ``target_node_id`` is which of the owner's nodes to target. When
    omitted: if the operator owns exactly one node, that's the target.
    Otherwise the caller must surface the candidates so the user can
    pass ``--node-id``.

    The pre-0.5.1 version of this function tried to disambiguate by
    wallet, which always failed because all the operator's nodes share
    a wallet (1:1 API-key↔wallet binding). The fix is to require a
    distinct identifier per node — ``node_id`` is what the gateway
    assigns at registration, so it's the natural choice.

    ``node`` is None when the caller needs more info (no nodes,
    multiple without a chosen ``--node-id``, or the named id doesn't
    match anything the operator owns).
    """
    try:
        r = httpx.get(f"{backend_url}/nodes", timeout=10.0)
        r.raise_for_status()
        body = r.json()
        all_nodes = body if isinstance(body, list) else []
    except (httpx.HTTPError, ValueError):
        return None, []
    owned = [
        n
        for n in all_nodes
        if isinstance(n, dict) and (n.get("wallet_address") or "").lower() == owner_wallet.lower()
    ]
    if target_node_id:
        matched = [n for n in owned if n.get("node_id") == target_node_id]
        return (matched[0] if matched else None), owned
    if len(owned) == 1:
        return owned[0], owned
    return None, owned


def _print_owned_node_row(node: dict) -> None:
    """Single-line summary of one owned node, used in the "you own
    multiple" error message and the wrong-node-id error. Kept in one
    place so the format stays consistent."""
    node_id = node.get("node_id", "?")
    models = node.get("supported_models") or []
    endpoint = node.get("endpoint", "?")
    rprint(f"  • [bold]{node_id}[/bold]  at {endpoint}  → {models}")


def _maybe_ollama_pull(model_id: str) -> None:
    if not shutil.which("ollama"):
        rprint(
            "[yellow][warn][/yellow] `ollama` not on PATH; skipping pull. "
            "If your node uses --backend=ollama, pull the model on whatever host runs Ollama."
        )
        return
    rprint(f"[blue]ollama pull[/blue] {model_id}")
    # Stream the pull output so the operator sees progress.
    proc = subprocess.run(["ollama", "pull", model_id])
    if proc.returncode != 0:
        rprint(
            f"[red]ollama pull failed (exit {proc.returncode}).[/red] "
            "The node-agent will return 500 for this model until it's pulled. "
            "Re-run with [cyan]--no-pull[/cyan] to skip this step."
        )
        raise typer.Exit(code=proc.returncode)


def _read_local_url(home: Path) -> str:
    """Get the local node-agent URL from ~/.sirb/local_url (written by
    deploy_node.py). Falls back to http://127.0.0.1:9000."""
    p = home / "local_url"
    if p.is_file():
        url = p.read_text(encoding="utf-8").strip()
        if url:
            return url.rstrip("/")
    return "http://127.0.0.1:9000"


def _hmac_post(
    url: str,
    *,
    payload: dict,
    signer: str,
    secret: str,
    timeout: float = 15.0,
) -> dict:
    """Build, sign, and POST a SignedEnvelope to a node-agent admin
    endpoint. Returns the JSON response body, or raises httpx.HTTPError
    on transport failure / non-2xx."""
    now = int(time.time())
    envelope: dict = {
        "payload": payload,
        "nonce": secrets.token_hex(16),
        "issued_at": now,
        "expires_at": now + 30,
        "signer": signer,
    }
    # Match the node-agent's _canonical(): sort keys, no spaces.
    canonical = json.dumps(
        {
            "payload": envelope["payload"],
            "nonce": envelope["nonce"],
            "issued_at": envelope["issued_at"],
            "expires_at": envelope["expires_at"],
            "signer": envelope["signer"],
        },
        sort_keys=True,
        separators=(",", ":"),
    ).encode()
    envelope["signature"] = hmac.new(
        secret.encode(),
        canonical,
        hashlib.sha256,
    ).hexdigest()
    r = httpx.post(url, json=envelope, timeout=timeout)
    if r.status_code >= 400:
        # Surface the gateway's error body so the operator sees WHY
        # it was rejected (signature mismatch, model_load_failed, etc).
        try:
            body = r.json()
        except ValueError:
            body = r.text
        raise httpx.HTTPStatusError(
            f"{url} returned {r.status_code}: {body}",
            request=r.request,
            response=r,
        )
    return r.json()
