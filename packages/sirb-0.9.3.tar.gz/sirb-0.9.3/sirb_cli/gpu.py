"""GPU vendor detection + container image variant selection.

The Sirb node-agent ships four GPU-specialized container variants:

  cpu   — non-GPU hosts + Ollama/vLLM-proxy nodes
  cuda  — NVIDIA hosts (RTX 30/40/50, Blackwell, Hopper, Ada)
  rocm  — AMD hosts (RDNA2+, MI200, MI300)
  sycl  — Intel hosts (Arc Alchemist/Battlemage, Iris Xe, Data Center Max/Flex)

This module probes the host once and picks the right variant for
`sirb deploy node --image <auto>`. Operators can override with
`--gpu-vendor nvidia|amd|intel|cpu` if the auto-detect picks wrong
(e.g. hybrid Intel iGPU + NVIDIA dGPU laptops, dual-GPU rigs).

Detection priority order — first match wins:
  1. NVIDIA  via `nvidia-smi -L`
  2. AMD     via /dev/kfd + AMD PCI vendor (0x1002) on /sys/class/drm
  3. Intel   via Intel PCI vendor (0x8086) on /sys/class/drm
  4. Falls through to "cpu"

The ordering reflects which vendor's GPU is most likely to be the
*compute* target on a multi-GPU host: in a laptop with Intel iGPU +
NVIDIA dGPU, the operator nearly always wants CUDA; in a server with
an AMD MI300 + a tiny integrated AST2600 BMC display chip, they
nearly always want ROCm. Intel-only is the fall-through.

No external dependencies. Reads /sys and /dev, shells out to
nvidia-smi only when that binary is on $PATH.
"""

from __future__ import annotations

import platform
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

GpuVendor = Literal["nvidia", "amd", "intel", "cpu", "proxy"]


# Stable PCI vendor IDs — these don't change.
PCI_VENDOR_NVIDIA = "0x10de"
PCI_VENDOR_AMD = "0x1002"
PCI_VENDOR_INTEL = "0x8086"

# Shape of an `nvidia-smi -L` line. Anchored regex so a random binary
# named `nvidia-smi` on PATH that prints "hello world\n" can't trick
# us into pulling the 5GB :cuda image. Authentic output is exactly:
#   "GPU 0: NVIDIA GeForce RTX 4090 (UUID: GPU-abc123)"
_NVIDIA_SMI_L_RE = re.compile(r"^GPU \d+:")


@dataclass(frozen=True)
class GpuDetection:
    """What the probe found on this host.

    `vendor` drives the image variant; `docker_args` lists the
    extra `docker run` flags the operator needs to actually expose
    the GPU to the container (vendor-specific). `notes` is free-text
    for the deploy preflight to print.
    """
    vendor: GpuVendor
    device_name: str | None       # e.g. "RTX 4090", "Radeon RX 7900 XTX"
    docker_args: list[str]        # additional `docker run` args
    notes: list[str]              # operator-facing context lines


# ─────────────────── per-vendor probes ─────────────────────────────


def _probe_nvidia() -> GpuDetection | None:
    """Run `nvidia-smi -L` if available.

    The -L flag lists GPUs and exits fast (no live telemetry query).
    A 0 exit with non-empty output means there's at least one NVIDIA
    GPU AND the userspace driver is loaded. We don't accept "binary
    exists but exits non-zero" because that indicates a driver
    mismatch (common with kernel upgrades) and forcing a CUDA image
    in that state just relocates the failure.
    """
    smi = shutil.which("nvidia-smi")
    if not smi:
        return None
    try:
        result = subprocess.run(
            [smi, "-L"], capture_output=True, text=True, timeout=5, check=False,
        )
    except (subprocess.TimeoutExpired, OSError):
        return None
    if result.returncode != 0:
        return None
    first_line = result.stdout.strip().splitlines()
    if not first_line:
        return None
    # Validate the output shape — must match nvidia-smi -L's canonical
    # format. Reject anything else (PATH shadowing by an unrelated
    # binary, broken driver emitting weird output, etc.) instead of
    # silently picking the 5GB :cuda image on a non-NVIDIA host.
    if not _NVIDIA_SMI_L_RE.match(first_line[0]):
        return None
    name: str | None = first_line[0].split(":", 1)[1].strip()
    if name and "(UUID" in name:
        name = name.split("(UUID", 1)[0].strip()
    return GpuDetection(
        vendor="nvidia",
        device_name=name,
        # `--gpus all` is the simplest invocation; the user can still
        # cap with --gpu-count to translate this to `--gpus count=N`.
        docker_args=["--gpus", "all"],
        notes=[
            f"detected NVIDIA GPU: {name or 'unknown'}",
            "image variant: cuda  (requires nvidia-container-toolkit on host)",
        ],
    )


def _read_pci_vendors() -> list[tuple[str, str]]:
    """Read PCI vendor IDs for every DRM card on the host.

    Returns a list of (card_name, vendor_id) for each /sys/class/drm/cardN.
    Empty list on non-Linux or when sysfs isn't readable (containers
    without /sys mounted, exotic kernels). Safe to call anywhere.
    """
    drm = Path("/sys/class/drm")
    if not drm.is_dir():
        return []
    out: list[tuple[str, str]] = []
    try:
        cards = sorted(drm.glob("card[0-9]*"))
    except OSError:
        return []
    for card in cards:
        # cardN/device/vendor is the canonical reader.
        v_file = card / "device" / "vendor"
        try:
            vendor = v_file.read_text().strip().lower()
        except OSError:
            continue
        out.append((card.name, vendor))
    return out


def _probe_amd() -> GpuDetection | None:
    """ROCm capability requires /dev/kfd AND an AMD-vendor DRM card.

    /dev/kfd alone isn't sufficient — some hosts have the amdkfd
    kernel module loaded for a non-supported chip. The combination
    (kfd device node + an actual AMD GPU at PCI 0x1002) is the
    authoritative signal.
    """
    if not Path("/dev/kfd").exists():
        return None
    cards = _read_pci_vendors()
    amd_cards = [c for c, v in cards if v == PCI_VENDOR_AMD]
    if not amd_cards:
        return None

    # Look up the per-card name if rocminfo is available — purely
    # cosmetic for the preflight print.
    name = None
    rocminfo = shutil.which("rocminfo")
    if rocminfo:
        try:
            r = subprocess.run(
                [rocminfo], capture_output=True, text=True, timeout=5, check=False,
            )
            for line in r.stdout.splitlines():
                line = line.strip()
                if line.startswith("Marketing Name:"):
                    name = line.split(":", 1)[1].strip()
                    break
        except (subprocess.TimeoutExpired, OSError):
            pass

    # ROCm needs /dev/kfd AND /dev/dri exposed, plus the in-container
    # user added to render+video groups (gid varies per host distro,
    # so we read from /etc/group when we can).
    docker_args: list[str] = [
        "--device", "/dev/kfd",
        "--device", "/dev/dri",
        "--security-opt", "seccomp=unconfined",
    ]
    for gname in ("render", "video"):
        gid = _gid_of(gname)
        if gid is not None:
            docker_args.extend(["--group-add", str(gid)])

    return GpuDetection(
        vendor="amd",
        device_name=name,
        docker_args=docker_args,
        notes=[
            f"detected AMD GPU: {name or 'unknown'}",
            "image variant: rocm  (requires ROCm driver + /dev/kfd on host)",
        ],
    )


def _probe_intel() -> GpuDetection | None:
    """Intel iGPU or dGPU on /sys/class/drm with vendor 0x8086.

    NOTE: we run this AFTER nvidia + amd because hybrid laptops
    (Intel iGPU + NVIDIA dGPU) should pick CUDA, not Intel iGPU.
    A pure-Intel host (Arc dGPU, Iris Xe iGPU, Data Center GPU
    Max/Flex on a server) lands here.
    """
    cards = _read_pci_vendors()
    intel_cards = [c for c, v in cards if v == PCI_VENDOR_INTEL]
    if not intel_cards:
        return None

    name = _intel_device_name(intel_cards[0])

    docker_args: list[str] = [
        "--device", "/dev/dri",
    ]
    # Intel /dev/dri requires render+video gids like ROCm.
    for gname in ("render", "video"):
        gid = _gid_of(gname)
        if gid is not None:
            docker_args.extend(["--group-add", str(gid)])

    return GpuDetection(
        vendor="intel",
        device_name=name,
        docker_args=docker_args,
        notes=[
            f"detected Intel GPU: {name or 'unknown'}",
            "image variant: cpu  (sycl variant temporarily disabled "
            "— see sirb.run/docs/news; the cpu image still runs but "
            "won't use Intel GPU acceleration)",
        ],
    )


# ─────────────────── helpers ─────────────────────────────


def _gid_of(group_name: str) -> int | None:
    """Look up a unix group's numeric gid via /etc/group.

    Returns None if the group doesn't exist on this host (which is
    fine for `docker run --group-add` — we just skip adding it).
    Avoids the `grp` module so this works inside minimal Python envs
    that ship without the C extensions.
    """
    try:
        with open("/etc/group", encoding="utf-8") as fh:
            for line in fh:
                parts = line.split(":")
                if len(parts) >= 3 and parts[0] == group_name:
                    return int(parts[2])
    except (OSError, ValueError):
        pass
    return None


def _intel_device_name(card: str) -> str | None:
    """Best-effort Intel GPU name via the DRM device-id → marketing
    name lookup that ships in lspci's pci.ids database, if available.

    Falls back to "Intel GPU (device 0xXXXX)" so the preflight at
    least shows the operator something they can search for.
    """
    dev_file = Path(f"/sys/class/drm/{card}/device/device")
    try:
        device_id = dev_file.read_text().strip().lower()
    except OSError:
        return None

    lspci = shutil.which("lspci")
    if lspci:
        try:
            r = subprocess.run(
                [lspci, "-d", f"8086:{device_id[2:]}", "-mm", "-nn"],
                capture_output=True, text=True, timeout=3, check=False,
            )
            for line in r.stdout.splitlines():
                # Format: "00:02.0 "VGA compatible controller [0300]" "Intel Corporation [8086]" "Arc A750 Graphics [56a1]" ..."
                if '"' in line:
                    parts = line.split('"')
                    # parts[5] is the device name field.
                    if len(parts) >= 6 and parts[5].strip():
                        return parts[5].strip()
        except (subprocess.TimeoutExpired, OSError):
            pass

    return f"Intel GPU (device {device_id})"


# ─────────────────── public API ─────────────────────────────


def detect_gpu() -> GpuDetection:
    """Run all probes in priority order; return the first match or "cpu"."""
    # macOS Apple Silicon: ship the cpu (arm64) image. Metal-accelerated
    # inference on macOS happens via host Ollama or external llama-server,
    # not the bundled llama-cpp-python. (We don't currently publish a
    # metal-tagged variant — abetlen's /whl/metal wheels are macOS-only
    # and would only ever run on a mac host, not in a Linux container.)
    if platform.system() == "Darwin":
        return GpuDetection(
            vendor="cpu",
            device_name=None,
            docker_args=[],
            notes=[
                "macOS detected — image variant: cpu (arm64)",
                "for GPU acceleration use --backend ollama against a host Ollama with Metal",
            ],
        )

    for probe in (_probe_nvidia, _probe_amd, _probe_intel):
        result = probe()
        if result is not None:
            return result

    return GpuDetection(
        vendor="cpu",
        device_name=None,
        docker_args=[],
        notes=["no GPU detected — image variant: cpu"],
    )


class GpuVendorMismatch(RuntimeError):
    """Operator forced `--gpu-vendor=<X>` but no matching GPU is on
    the host. Raised loudly so the deploy preflight surfaces an
    actionable RED error rather than a dim note an operator scrolls
    past. The previous "silent fallback" behavior pulled a multi-GB
    image and started a container with the wrong GPU passthrough,
    leaving the operator to puzzle out at runtime why inference was
    at 2 tok/s on what they thought was an MI300.
    """


def detect_for_vendor(vendor: GpuVendor) -> GpuDetection:
    """Force-pick a specific vendor (operator override path).

    Re-runs the per-vendor probe so we still get the docker_args and
    name fields populated. Raises ``GpuVendorMismatch`` if the probe
    can't confirm a matching GPU on the host — pulling the rocm/sycl/
    cuda image without the matching passthrough flags is strictly
    worse than failing fast (it burns 3-5 GB of disk + 5+ minutes
    before the operator realizes nothing's offloading to GPU).

    The CPU vendor always succeeds — `--gpu-vendor=cpu` is "I know
    this host has a GPU but I want to force CPU anyway", an explicit
    choice that doesn't need a probe.
    """
    if vendor == "cpu":
        return GpuDetection(
            vendor="cpu", device_name=None, docker_args=[],
            notes=["forced cpu variant"],
        )
    probe_map = {
        "nvidia": _probe_nvidia,
        "amd": _probe_amd,
        "intel": _probe_intel,
    }
    probe = probe_map[vendor]
    found = probe()
    if found is not None:
        return found
    # Operator forced a GPU vendor that isn't actually here. Fail fast
    # with a message that names the missing signal so they can fix the
    # host (or drop the override).
    missing_signal = {
        "nvidia": "nvidia-smi -L found no GPUs",
        "amd": "/dev/kfd missing or no AMD PCI vendor (0x1002) on /sys/class/drm",
        "intel": "no Intel PCI vendor (0x8086) on /sys/class/drm",
    }[vendor]
    raise GpuVendorMismatch(
        f"--gpu-vendor={vendor} was requested but the matching GPU "
        f"isn't detectable on this host ({missing_signal}). "
        f"Fix the host driver, remove --gpu-vendor to fall through to "
        f"CPU, or pass --gpu-vendor=cpu to explicitly run CPU-only."
    )


def image_tag_for(vendor: GpuVendor, version: str = "latest") -> str:
    """Compose the GHCR tag for a given vendor + version.

    Args:
      vendor:  one of cpu/cuda/rocm/sycl variants. Note that the
               GpuVendor type uses NVIDIA/amd/intel as the *detection*
               labels; we translate to image-variant names here.
      version: the version string to pin (e.g. "v0.20.0") or "latest"
               for the always-current build.

    Example: image_tag_for("nvidia", "v0.20.0")
             → "ghcr.io/ammarwa/sirb-node:cuda-v0.20.0"
    """
    vendor_to_variant: dict[GpuVendor, str] = {
        "nvidia": "cuda",
        "amd":    "rocm",
        # Intel GPU operators are routed to the cpu image while the
        # sycl variant is disabled in CI (Dockerfile.sycl currently
        # fails on `source setvars.sh` — see docs/news.md "SYCL image
        # variant temporarily disabled in CI" for the full story).
        # Without this remap, deploy_node would docker-pull
        # `:sycl-vX.Y.Z` and 404. When Dockerfile.sycl is fixed and
        # the workflow's default variant list re-includes sycl,
        # flip this back to "sycl".
        "intel":  "cpu",
        "cpu":    "cpu",
        # "proxy" is not a GPU vendor — it's a deployment shape (host
        # has its own model server, we just relay). The slim proxy image
        # has no llama-cpp-python bundled. See node-agent/Dockerfile.proxy.
        "proxy":  "proxy",
    }
    variant = vendor_to_variant[vendor]
    # The cpu variant keeps the historical short-tag form (no
    # variant prefix) so an operator pinning :v0.20.0 keeps working;
    # but for clarity in the deploy preflight we always emit the
    # explicit variant-prefixed tag.
    return f"ghcr.io/ammarwa/sirb-node:{variant}-{version}"
