from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable

from .errors import CycleDetected, Diagnostic, DuplicateName, ValidationFailed
from .models import Capability, CapabilityCreate, CapabilityPatch, CapabilityTreeNode, now_iso


def normalize_name(name: str) -> str:
    return " ".join(name.strip().lower().split())


def assert_unique_name(
    capabilities: Iterable[Capability], name: str, exclude_id: str | None = None
) -> None:
    wanted = normalize_name(name)
    for capability in capabilities:
        if capability.id != exclude_id and normalize_name(capability.name) == wanted:
            raise DuplicateName(name)


def get_capability(capabilities: Iterable[Capability], capability_id: str) -> Capability:
    for capability in capabilities:
        if capability.id == capability_id:
            return capability
    raise ValidationFailed(f'Capability "{capability_id}" does not exist.')


def assert_parent_exists(capabilities: Iterable[Capability], parent_id: str | None) -> None:
    if parent_id is None:
        return
    get_capability(capabilities, parent_id)


def is_descendant(
    capabilities: Iterable[Capability], maybe_descendant_id: str, ancestor_id: str
) -> bool:
    by_id = {capability.id: capability for capability in capabilities}
    current = by_id.get(maybe_descendant_id)
    seen: set[str] = set()
    while current is not None and current.parent_id is not None:
        if current.parent_id == ancestor_id:
            return True
        if current.parent_id in seen:
            raise CycleDetected()
        seen.add(current.parent_id)
        current = by_id.get(current.parent_id)
    return False


def next_order(capabilities: Iterable[Capability], parent_id: str | None) -> int:
    sibling_orders = [
        capability.order for capability in capabilities if capability.parent_id == parent_id
    ]
    return max(sibling_orders, default=-1) + 1


def with_computed_types(capabilities: Iterable[Capability]) -> list[Capability]:
    capability_list = list(capabilities)
    parent_ids = {
        capability.parent_id for capability in capability_list if capability.parent_id is not None
    }
    return [
        capability.model_copy(
            update={"type": "abstract" if capability.id in parent_ids else "leaf"}
        )
        for capability in capability_list
    ]


def validate_capability_set(
    capabilities: list[Capability],
    path: str | None = None,
    require_parents: bool = True,
    line_numbers: list[int] | None = None,
) -> list[Diagnostic]:
    diagnostics: list[Diagnostic] = []
    ids: dict[str, int] = {}
    names: dict[str, int] = {}
    by_id = {capability.id: capability for capability in capabilities}

    def line(index: int) -> int | None:
        if line_numbers is None or index >= len(line_numbers):
            return None
        return line_numbers[index]

    for index, capability in enumerate(capabilities):
        if capability.id in ids:
            diagnostics.append(
                Diagnostic(
                    code="DUPLICATE_ID",
                    message=f'Duplicate capability id "{capability.id}".',
                    path=path,
                    line=line(index),
                )
            )
        ids[capability.id] = index

        name = normalize_name(capability.name)
        if name in names:
            diagnostics.append(
                Diagnostic(
                    code="DUPLICATE_NAME",
                    message=f'Duplicate capability name "{capability.name}".',
                    path=path,
                    line=line(index),
                )
            )
        names[name] = index

        if require_parents and capability.parent_id and capability.parent_id not in by_id:
            diagnostics.append(
                Diagnostic(
                    code="VALIDATION_FAILED",
                    message=(
                        f'Parent "{capability.parent_id}" for "{capability.name}" '
                        "does not exist."
                    ),
                    path=path,
                    line=line(index),
                )
            )

    for index, capability in enumerate(capabilities):
        seen: set[str] = set()
        current: Capability | None = capability
        while current is not None:
            if current.id in seen:
                diagnostics.append(
                    Diagnostic(
                        code="CYCLE_DETECTED",
                        message=(
                            f'Capability "{capability.name}" participates in a '
                            "hierarchy cycle."
                        ),
                        path=path,
                        line=line(index),
                    )
                )
                break
            seen.add(current.id)
            current = by_id.get(current.parent_id) if current.parent_id else None

    return diagnostics


def create_capability(capabilities: list[Capability], input_data: CapabilityCreate) -> Capability:
    name = input_data.name.strip()
    if not name:
        raise ValidationFailed("Capability name is required.")
    assert_unique_name(capabilities, name)
    assert_parent_exists(capabilities, input_data.parent_id)
    data = input_data.model_dump(mode="json", exclude={"type"})
    data["name"] = name
    data["order"] = next_order(capabilities, input_data.parent_id)
    data["type"] = "leaf"
    return Capability(**data)


def update_capability(
    capabilities: list[Capability], capability_id: str, patch: CapabilityPatch
) -> Capability:
    capability = get_capability(capabilities, capability_id)
    data = patch.model_dump(exclude_unset=True, mode="json")
    if "name" in data and data["name"] is not None:
        data["name"] = data["name"].strip()
        if not data["name"]:
            raise ValidationFailed("Capability name is required.")
        assert_unique_name(capabilities, data["name"], exclude_id=capability_id)
    data["updated_at"] = now_iso()
    return capability.model_copy(update=data)


def move_capability(
    capabilities: list[Capability],
    capability_id: str,
    new_parent_id: str | None,
    order: int | None = None,
) -> tuple[list[Capability], Capability]:
    capability = get_capability(capabilities, capability_id)
    assert_parent_exists(capabilities, new_parent_id)
    if new_parent_id == capability_id:
        raise CycleDetected()
    if new_parent_id is not None and is_descendant(capabilities, new_parent_id, capability_id):
        raise CycleDetected()
    current_parent_id = capability.parent_id
    destination_siblings = _ordered_siblings(
        capabilities, new_parent_id, exclude_id=capability_id
    )
    destination_index = (
        len(destination_siblings)
        if order is None
        else min(max(0, order), len(destination_siblings))
    )
    moved = capability.model_copy(
        update={
            "parent_id": new_parent_id,
            "order": destination_index,
            "updated_at": now_iso(),
        }
    )

    replacements: dict[str, Capability] = {}
    if current_parent_id != new_parent_id:
        for sibling in _normalize_sibling_order(
            _ordered_siblings(capabilities, current_parent_id, exclude_id=capability_id)
        ):
            replacements[sibling.id] = sibling

    destination_with_moved = destination_siblings.copy()
    destination_with_moved.insert(destination_index, moved)
    for sibling in _normalize_sibling_order(destination_with_moved):
        replacements[sibling.id] = sibling

    moved = replacements[capability_id]
    return [replacements.get(item.id, item) for item in capabilities], moved


def retire_capability(
    capabilities: list[Capability],
    capability_id: str,
    rationale: str,
    replacement_capability_id: str | None = None,
    effective_to: str | None = None,
) -> Capability:
    rationale = rationale.strip()
    if not rationale:
        raise ValidationFailed("Structural operation rationale is required.")
    capability = get_capability(capabilities, capability_id)
    if replacement_capability_id is not None:
        if replacement_capability_id == capability_id:
            raise ValidationFailed(
                "Replacement capability must be different from the retired capability."
            )
        get_capability(capabilities, replacement_capability_id)
    return capability.model_copy(
        update={
            "lifecycle_status": "Retired",
            "effective_to": effective_to or now_iso(),
            "rationale": rationale,
            "replacement_capability_id": replacement_capability_id,
            "updated_at": now_iso(),
        }
    )


def delete_capability(
    capabilities: list[Capability], capability_id: str
) -> tuple[list[Capability], Capability]:
    capability = get_capability(capabilities, capability_id)
    if capability.lifecycle_status != "Draft":
        raise ValidationFailed("Only Draft leaf capabilities can be deleted.")
    if any(item.parent_id == capability_id for item in capabilities):
        raise ValidationFailed("Only Draft leaf capabilities can be deleted.")
    return _remove_capability_and_normalize(capabilities, capability), capability


def merge_capabilities(
    capabilities: list[Capability],
    source_id: str,
    survivor_id: str,
    rationale: str,
    effective_to: str | None = None,
) -> tuple[list[Capability], Capability, Capability | None, Capability, bool]:
    rationale = rationale.strip()
    if not rationale:
        raise ValidationFailed("Structural operation rationale is required.")
    if source_id == survivor_id:
        raise ValidationFailed("Source and survivor capabilities must be different.")
    source = get_capability(capabilities, source_id)
    survivor = get_capability(capabilities, survivor_id)
    if is_descendant(capabilities, survivor_id, source_id):
        raise ValidationFailed(
            "Survivor capability cannot be a descendant of the source capability."
        )

    survivor_aliases = _merged_aliases(survivor, source)
    working = replace_capability(
        capabilities,
        survivor.model_copy(
            update={
                "aliases": survivor_aliases,
                "updated_at": now_iso(),
            }
        ),
    )

    for child in _ordered_siblings(working, source_id):
        working, _ = move_capability(working, child.id, survivor_id)

    working = with_computed_types(working)
    source_removed = source.lifecycle_status == "Draft"
    source_after: Capability | None = None
    if source_removed:
        working = _remove_capability_and_normalize(working, source)
    else:
        source_after = retire_capability(
            working,
            source_id,
            rationale,
            replacement_capability_id=survivor_id,
            effective_to=effective_to,
        )
        working = replace_capability(working, source_after)

    working = with_computed_types(working)
    survivor_after = get_capability(working, survivor_id)
    if source_after is not None:
        source_after = get_capability(working, source_id)
    return working, source, source_after, survivor_after, source_removed


def replace_capability(capabilities: list[Capability], updated: Capability) -> list[Capability]:
    return [updated if capability.id == updated.id else capability for capability in capabilities]


def _ordered_siblings(
    capabilities: Iterable[Capability],
    parent_id: str | None,
    exclude_id: str | None = None,
) -> list[Capability]:
    return sorted(
        [
            capability
            for capability in capabilities
            if capability.parent_id == parent_id and capability.id != exclude_id
        ],
        key=lambda c: (c.order, normalize_name(c.name), c.id),
    )


def _normalize_sibling_order(siblings: Iterable[Capability]) -> list[Capability]:
    result: list[Capability] = []
    for index, capability in enumerate(siblings):
        if capability.order == index:
            result.append(capability)
        else:
            result.append(capability.model_copy(update={"order": index}))
    return result


def _merged_aliases(survivor: Capability, source: Capability) -> list[str]:
    aliases: list[str] = []
    seen = {normalize_name(survivor.name)}
    for alias in [*survivor.aliases, source.name, *source.aliases]:
        alias = alias.strip()
        if not alias:
            continue
        normalized = normalize_name(alias)
        if normalized in seen:
            continue
        seen.add(normalized)
        aliases.append(alias)
    return aliases


def _remove_capability_and_normalize(
    capabilities: list[Capability], removed: Capability
) -> list[Capability]:
    remaining = [item for item in capabilities if item.id != removed.id]
    replacements = {
        sibling.id: sibling
        for sibling in _normalize_sibling_order(_ordered_siblings(remaining, removed.parent_id))
    }
    return [replacements.get(item.id, item) for item in remaining]


def sort_capabilities_depth_first(capabilities: Iterable[Capability]) -> list[Capability]:
    by_parent: dict[str | None, list[Capability]] = defaultdict(list)
    all_ids = {capability.id for capability in capabilities}
    for capability in capabilities:
        parent_id = capability.parent_id if capability.parent_id in all_ids else None
        by_parent[parent_id].append(capability)
    for siblings in by_parent.values():
        siblings.sort(key=lambda c: (c.order, normalize_name(c.name), c.id))

    result: list[Capability] = []
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(parent_id: str | None) -> None:
        for capability in by_parent.get(parent_id, []):
            if capability.id in visiting:
                raise CycleDetected()
            if capability.id in visited:
                continue
            visiting.add(capability.id)
            result.append(capability)
            visit(capability.id)
            visiting.remove(capability.id)
            visited.add(capability.id)

    visit(None)
    for capability in sorted(capabilities, key=lambda c: c.id):
        if capability.id not in visited:
            parent_id = capability.parent_id if capability.parent_id in all_ids else None
            visit(parent_id)
    return result


def build_tree(capabilities: Iterable[Capability]) -> list[CapabilityTreeNode]:
    sorted_capabilities = sort_capabilities_depth_first(capabilities)
    nodes = {
        capability.id: CapabilityTreeNode(capability=capability)
        for capability in sorted_capabilities
    }
    roots: list[CapabilityTreeNode] = []
    for capability in sorted_capabilities:
        node = nodes[capability.id]
        if capability.parent_id is None or capability.parent_id not in nodes:
            roots.append(node)
        else:
            nodes[capability.parent_id].children.append(node)
    return roots


def capability_path(capabilities: Iterable[Capability], capability_id: str) -> list[Capability]:
    by_id = {capability.id: capability for capability in capabilities}
    current = by_id.get(capability_id)
    if current is None:
        raise ValidationFailed(f'Capability "{capability_id}" does not exist.')
    path: list[Capability] = []
    seen: set[str] = set()
    while current is not None:
        if current.id in seen:
            raise CycleDetected()
        path.append(current)
        seen.add(current.id)
        current = by_id.get(current.parent_id) if current.parent_id else None
    path.reverse()
    return path
