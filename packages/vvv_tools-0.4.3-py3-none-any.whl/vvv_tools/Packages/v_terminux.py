# [
#     { "keys": ["ctrl+enter"], "command": "v_universal_chat" },
#     { "keys": ["ctrl+alt+`"], "command": "v_terminux" },
#     { "keys": ["ctrl+w"], "command": "v_close" }
# ]

import os
import re
import sys
import time
import base64
import sublime
import sublime_plugin
import subprocess
import threading
import http.client
import urllib.request
import json
import socket
class MCPClient:
    def __init__(self, host="127.0.0.1:18988", timeout=20):
        self.host = host
        self.id = 0
        self._addr = self._parse_host()
        self.timeout = timeout
    def call(self, method, params=None):
        self.id += 1
        self.conn = http.client.HTTPConnection(self.host, timeout=self.timeout)
        payload = json.dumps({
            "jsonrpc": "2.0",
            "method": method,
            "params": params or {},
            "id": self.id
        })
        self.conn.request("POST", "/", payload)
        res = self.conn.getresponse()
        _data = res.read()
        _data = _data.decode() if type(_data) == bytes else _data
        data = json.loads(_data)
        if "error" in data:
            raise Exception(data["error"])
        return data["result"]
    def _parse_host(self):
        if ":" in self.host:
            h, p = self.host.split(":")
            return h, int(p)
        return self.host, 80
    def _is_port_open(self):
        try:
            with socket.create_connection(self._addr, timeout=0.3):
                return True
        except Exception as e:
            return False
    def list_tools(self):
        if not self._is_port_open():
            return []
        return self.call("tools/list")
    def call_tool(self, name, arguments):
        return self.call("tools/call", {
            "name": name,
            "arguments": arguments,
            "file_env": read_file_env(),
        })

mcp = MCPClient("127.0.0.1:19989")

def kill_old_mcp():
    try:
        resp = urllib.request.urlopen("http://127.0.0.1:19989/shutdown", timeout=1)
    except Exception as e:
        print(e)

def init_mcp():
    kill_old_mcp()
    script_name = "v_terminux_mcp_server.vpy"
    script_path = os.path.join(os.path.dirname(__file__), script_name)
    proc = subprocess.Popen( ["python", "-u", script_path],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        shell=True )
    def reader():
        while True:
            line = proc.stdout.readline()
            time.sleep(0.01)
            if not line:
                break
            try:
                line = line.decode("utf-8", "ignore").strip()
            except:
                line = str(line)
            print("[MCP]", line)
    t = threading.Thread(target=reader)
    t.daemon = True
    t.start()
    return 'ok'

def read_file_env():
    windows = sublime.windows()
    if not windows:
        return
    win = windows[0]
    view = win.active_view_in_group(0)
    if not view:
        return
    file_path = view.file_name()
    def get_best_folder(file_path, folders):
        def is_subpath(file_path, folder):
            file_path = os.path.abspath(file_path)
            folder = os.path.abspath(folder)
            folder = folder.rstrip(os.sep) + os.sep
            file_path = file_path.rstrip(os.sep) + os.sep
            return file_path.startswith(folder)
        best = None
        for folder in folders:
            if is_subpath(file_path, folder):
                if not best or len(folder) > len(best):
                    best = folder
        return best
    visible_region = view.visible_region()
    start_row, _ = view.rowcol(visible_region.begin())
    end_row, _ = view.rowcol(visible_region.end())
    return {
        'file_path': file_path,
        'best_folder': get_best_folder(file_path, win.folders()),
        'view_start_end_row': [start_row, end_row],
    }


import re
from ast import literal_eval
def strip_inline_comment(line: str):
    in_str = False
    quote_char = None
    for i, ch in enumerate(line):
        if ch in ('"', "'"):
            if not in_str:
                in_str = True
                quote_char = ch
            elif quote_char == ch:
                in_str = False
        elif ch == '#' and not in_str:
            return line[:i].rstrip()
    return line
def parse_dsl(text: str, strict=True):
    section_re = re.compile(r'\[([^\]:]+)(?::([^\]]+))?\]')
    kv_re = re.compile(r'(\w+)\s*=\s*(.+)')
    result = {}
    current_section = None
    section_type = "kv"
    lines = text.splitlines()
    i = 0
    buffer_lines = []
    def flush_lines():
        if current_section and section_type == "lines":
            result[current_section] = buffer_lines.copy()
    while i < len(lines):
        raw_line = lines[i]
        stripped = raw_line.strip()
        if not stripped or stripped.startswith("#"):
            i += 1
            continue
        sec_match = section_re.match(stripped)
        if sec_match:
            flush_lines()
            buffer_lines.clear()
            name, typ = sec_match.groups()
            current_section = name
            section_type = typ or "kv"
            if section_type == "kv":
                result.setdefault(current_section, {})
            i += 1
            continue
        if section_type == "lines":
            if not stripped.startswith("#"):
                buffer_lines.append(raw_line.rstrip())
            i += 1
            continue
        line = strip_inline_comment(raw_line).strip()
        if not line:
            i += 1
            continue
        kv_match = kv_re.match(line)
        if kv_match:
            key, value = kv_match.groups()
            if value.startswith('"""'):
                value_lines = []
                value = value[3:]
                while True:
                    if value.endswith('"""'):
                        value_lines.append(value[:-3])
                        break
                    else:
                        value_lines.append(value)
                        i += 1
                        if i >= len(lines):
                            raise ValueError("Unclosed triple quote")
                        value = lines[i]
                final_value = "\n".join(value_lines)
            else:
                try:
                    final_value = literal_eval(value)
                except:
                    final_value = value.strip()
            result[current_section][key] = final_value
        else:
            if strict:
                raise ValueError(
                    "Invalid line in [{}]: {}".format(current_section, line)
                )
        i += 1
    flush_lines()
    return result

def load_config():
    c = {}
    cfg_path = os.path.join(os.path.expanduser("~"), '.vsublime.cfg.py')
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, 'r', encoding='utf8') as f:
                s = f.read()
                dsl = parse_dsl(s)
                c = dsl.get('config', {})
                c['extra'] = dsl.get('extra', [])
        except Exception as e: 
            print(e)
            pass
    else:
        with open(cfg_path, 'w', encoding='utf8') as f:
            demo = [
                # ai code相关
                "[config] ai_code_api_key: none",
                "[config] ai_code_base_url: api.deepseek.com",
                "[config] ai_code_path: /chat/completions",
                "[config] ai_code_model: deepseek-chat",
                "[config] ai_code_max_search: 1000",
                # ai chat相关
                "[config] ai_chat_api_key: none",
                "[config] ai_chat_base_url: api.deepseek.com",
                "[config] ai_chat_path: /chat/completions",
                "[config] ai_chat_model: deepseek-chat",
                "[config] ai_chat_system: 你是一个知识渊博的人，你会回答我所有的问题。",
                "[config] ai_chat_max_search: 1000",
                # 其他功能
                "[config] max_line_length: 500",
                "[right] python ${file}",
            ]
            f.write('\n')
    try:
        c["ai_tools"] = mcp.list_tools()
    except Exception as e:
        # import traceback
        # print(traceback.format_exc())
        print('[*] load mcp fail.', e)
    return c

def get_chunk(json_data):
    choice = json_data["choices"][0]
    if "text" in choice:
        chunk = choice["text"]
    elif "delta" in choice:
        delta = choice.get("delta", {})
        chunk = delta.get("content", "") or ""
    else:
        chunk = ""
    return chunk










class AiCurrWindowCompletionCommand(sublime_plugin.TextCommand):
    def run(self, edit, type):
        cfg = load_config()
        ai_code_api_key = cfg.get('ai_code_api_key', '')
        ai_max_search = int(cfg.get('ai_max_search', 5000))
        selections = self.view.sel()
        if not selections:
            sublime.status_message("No text selected")
            return
        self.view.erase(edit, selections[0])
        selections = self.view.sel()
        prompt = self.view.substr(selections[0])
        cursor_start_pos = selections[0].begin()
        cursor_end_pos = selections[0].end()
        start_pos = max(0, cursor_start_pos - ai_max_search)
        before_text = self.view.substr(sublime.Region(start_pos, cursor_start_pos))
        prompt = before_text
        if type == 'add':
            suffix = None
        if type == 'insert':
            end_pos = min(self.view.size(), cursor_end_pos + ai_max_search)
            after_text = self.view.substr(sublime.Region(cursor_end_pos, end_pos))
            suffix = after_text
        cfg['prompt'] = prompt
        cfg['suffix'] = suffix
        sublime.status_message("Requesting code completion...")
        self.output_view = self.view
        thread = AiStreamingFixCodeApiThread(
            cfg,
            self.handle_stream_response,
            self.handle_completion,
            self.handle_error
        )
        thread.start()
    def handle_stream_response(self, text_chunk): sublime.set_timeout(lambda: self.append_to_output(text_chunk), 0)
    def append_to_output(self, text):
        if hasattr(self, 'output_view') and self.output_view: self.view.run_command("simple_stream_insert", {"text": text})
    def handle_completion(self): sublime.status_message("Completion finished in output window")
    def handle_error(self, error):
        sublime.status_message("Error: " + str(error))
        if hasattr(self, 'output_view') and self.output_view:
            self.view.run_command("simple_stream_insert", {"text": "\n\nError: " + str(error)})
class AppendTextCommand(sublime_plugin.TextCommand):
    def run(self, edit, text):
        self.view.insert(edit, self.view.size(), text)
        self.view.show(self.view.size())
class SimpleStreamInsertCommand(sublime_plugin.TextCommand):
    def run(self, edit, text):
        if not self.view.sel(): return
        start_pos = self.view.sel()[0].begin()
        end_pos = self.view.sel()[0].end()
        self.view.insert(edit, end_pos, text)
        new_pos = end_pos + len(text)
        self.view.sel().clear()
        self.view.sel().add(sublime.Region(start_pos, new_pos))
        self.view.show(new_pos)
class AiStreamingFixCodeApiThread(threading.Thread):
    def __init__(self, cfg, chunk_callback, completion_callback, error_callback):
        threading.Thread.__init__(self)
        self.base_url = cfg['ai_code_base_url']
        self.model = cfg['ai_code_model']
        self.path = cfg['ai_code_path']
        self.api_key = cfg['ai_code_api_key']
        self.prompt = cfg['prompt']
        self.suffix = cfg['suffix'] or ""
        self.max_tokens = int(cfg.get('max_tokens', 2048))
        self.chunk_callback = chunk_callback
        self.completion_callback = completion_callback
        self.error_callback = error_callback
        self.stop_event = threading.Event()
    def run(self):
        try:
            conn = http.client.HTTPSConnection(self.base_url.replace("https://", "").replace("http://", ""))
            tk = '''
你是一个代码补全助手。

下面提供插入点附近的上下文。
请生成应该插入到该位置的新代码。

⚠ 必须遵守：
1. 只输出新增代码。
2. 不要重复上下文。
3. 不要输出任何解释或 Markdown。
4. 不能修改 before/after 内容。
5. 你需要考虑缩进的内容，一定不能输出多余的空格！

================ 上下文 ================
{}
================ 插入点前 ================
{}
================ 插入点后 ================
{}
================ 结束 ================
                '''.format(self.prompt+self.suffix, self.prompt, self.suffix)
            messages =  [{"role": "system", "content": '你是一个代码补全助手。'}]
            messages.append({"role": "user", "content": tk})
            payload = json.dumps({
                "model": self.model,
                "messages": messages,
                "max_tokens": int(self.max_tokens),
                "stream": True
            })
            headers = {
                'Content-Type': 'application/json',
                'Accept': 'text/event-stream',
                'Authorization': 'Bearer ' + self.api_key
            }
            conn.request("POST", self.path, payload, headers)
            response = conn.getresponse()
            if response.status != 200:
                self.error_callback("API error: " + str(response.status) + " " + response.reason)
                return
            buffer = b""
            while not self.stop_event.is_set():
                chunk = response.read(16)
                if not chunk:
                    break
                buffer += chunk
                lines = buffer.split(b'\n')
                for line in lines[:-1]:
                    line = line.strip()
                    if not line:
                        continue
                    if line.startswith(b'data: '):
                        data = line[6:]
                        if data == b'[DONE]':
                            self.completion_callback()
                            return
                        try:
                            json_data = json.loads(data.decode('utf-8'))
                            if 'choices' in json_data and json_data['choices']:
                                self.chunk_callback(get_chunk(json_data))
                        except ValueError:
                            continue
                buffer = lines[-1]
            self.completion_callback()
        except Exception as e:
            self.error_callback(str(e))
        finally:
            try:
                conn.close()
            except:
                pass
    def stop(self):
        self.stop_event.set()

class CancelAiCompletionCommand(sublime_plugin.ApplicationCommand):
    def run(self):
        for thread in threading.enumerate():
            if isinstance(thread, (AiStreamingFixCodeApiThread, ApiStreamThread)):
                thread.stop()




























import copy
import os, re, json, threading, http.client
import sublime, sublime_plugin
CHAT_MEMORY = {}
class VUniversalChatCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        cfg = load_config()
        if not cfg.get('ai_chat_api_key') or cfg.get('ai_chat_api_key') == 'none':
            sublime.status_message("Error: ai_chat_api_key missing in .vsublime.cfg.py")
            return
        if self.view.name() != "AI Chat":
            chat_view = self.get_or_create_chat_view()
            if chat_view.id() not in CHAT_MEMORY:
                CHAT_MEMORY[chat_view.id()] = [{"role": "system", "content": cfg['ai_chat_system']}]
            win = self.view.window()
            if win:
                win.focus_view(chat_view)
            chat_view.run_command("append_text", {"text": '[init_AI]\n'})
            init_mcp()
            chat_view.run_command("append_text", {"text": 'create mcp.\n'})
            chat_view.run_command("append_text", {"text": '[End]\n\n'})
        else:
            if self.view.sel()[0].begin() != self.view.size():
                self.view.sel().clear()
                self.view.sel().add(sublime.Region(self.view.size()))
            sel = self.view.sel()[0]
            is_mutli = False
            if sel.empty():
                ai_max_search = int(cfg.get('ai_max_search', 5000))
                cursor_start_pos = sel.begin()
                start_pos = max(0, cursor_start_pos - ai_max_search)
                before_text = self.view.substr(sublime.Region(start_pos, cursor_start_pos)).rsplit('\n[End]', 1)[-1]
                sel_text = before_text.strip()
                is_mutli = True
            else:
                sel_text = self.view.substr(sel).strip()
            if not sel_text: return sublime.status_message("Type something to send")
            if is_mutli:
                start_pos = cursor_start_pos - len(before_text)
                if len(before_text) >= 1 and before_text[0] == '\n': start_pos += 1
                if len(before_text) >= 2 and before_text[1] == '\n': start_pos += 1
                cursor_start_pos = sel.begin()
                self.view.erase(edit, sublime.Region(start_pos, cursor_start_pos))
            else:
                if sel.end() >= self.view.size() - 5: 
                    self.view.erase(edit, sel)
            if not sel_text.strip():
                sublime.status_message("Select text to send")
                return
            self.view.run_command("universal_chat_send", {"user_input": sel_text, "cfg": cfg})
    def get_or_create_chat_view(self):
        win = self.view.window()
        for v in win.views():
            if v.name() == "AI Chat":
                win.focus_view(v)
                return v
        win.set_layout({
            "cols": [0.0, 0.65, 1.0],
            "rows": [0.0, 1.0],
            "cells": [[0, 0, 1, 1], [1, 0, 2, 1]]
        })
        win.focus_group(1)
        cv = win.new_file()
        cv.set_name("AI Chat")
        cv.set_scratch(True)
        cv.settings().set("word_wrap", True)
        cv.settings().set("wrap_width", 0)
        cv.set_syntax_file("Packages/Markdown/Markdown.sublime-syntax")
        return cv
class UniversalChatSendCommand(sublime_plugin.TextCommand):
    def run(self, edit, user_input, cfg):
        vid = self.view.id()
        if vid not in CHAT_MEMORY: 
            CHAT_MEMORY[vid] = [{"role": "system", "content": cfg['ai_chat_system']}]
        display_text = "[User]:\n" + user_input + "\n[AI]:\n"
        self.view.run_command("append_text", {"text": display_text})
        CHAT_MEMORY[vid].append({"role": "user", "content": user_input})
        self.__th = ApiStreamThread(cfg, CHAT_MEMORY[vid], self.on_chunk, self.on_done, self.on_err)
        self.__th.start()
    def on_chunk(self, text):
        print(text)
        def group_consecutive_chars(text):
            if not text:
                return []
            consecutive_groups = []
            if text:
                current_char = text[0]
                current_group = current_char
                for char in text[1:]:
                    if char == current_char:
                        current_group += char
                    else:
                        consecutive_groups.append(current_group)
                        current_char = char
                        current_group = char
                consecutive_groups.append(current_group)
            result = []
            i = 0
            while i < len(consecutive_groups):
                current_group = consecutive_groups[i]
                if len(current_group) >= 3:
                    result.append(current_group)
                    i += 1
                else:
                    combined = current_group
                    i += 1
                    while i < len(consecutive_groups) and len(combined) < 3:
                        next_group = consecutive_groups[i]
                        if len(combined) + len(next_group) <= 3:
                            combined += next_group
                            i += 1
                        else:
                            break
                    result.append(combined)
            return result
        def send(t):
            sublime.set_timeout(lambda: self.view.run_command("append_text", {"text": t}), 0)
            time.sleep(0.01)
        for i in group_consecutive_chars(text):
            send(i)
        # sublime.set_timeout(lambda: self.view.run_command("append_text", {"text": text}), 0)
    def on_done(self, full_text, role_type=None):
        print('role_type:', role_type)
        if role_type == 'ai':
            CHAT_MEMORY[self.view.id()].append({"role": "assistant", "content": full_text})
            sublime.set_timeout(lambda: self.view.run_command("append_text", {"text": '\n[End]\n\n'}), 0)
        if role_type == 'tools':
            sublime.set_timeout(lambda: self.view.run_command("append_text", {"text": '<use tools>'}), 0)
        sublime.set_timeout(lambda: self.view.set_status("ai_status", "AI Ready"), 0)
        print(json.dumps(CHAT_MEMORY[self.view.id()], indent=4, ensure_ascii=False))
    def on_err(self, err):
        msg = "\n[Error: " + str(err) + "]\n"
        sublime.set_timeout(lambda: self.view.run_command("append_text", {"text": msg}), 0)
class AppendTextCommand(sublime_plugin.TextCommand):
    def run(self, edit, text):
        self.view.insert(edit, self.view.size(), text)
        self.view.show(self.view.size())
class ApiStreamThread(threading.Thread):
    def __init__(self, cfg, msgs, block_cb=None, done_cb=None, err_cb=None):
        threading.Thread.__init__(self)
        self.c = cfg
        self.m = msgs
        self.h = copy.deepcopy(msgs)
        self.b_cb = block_cb or (lambda a:print(a, end=''))
        self.d_cb = done_cb or (lambda a,b=None:None)
        def dferr_cb(e):
            raise e
        self.e_cb = err_cb or dferr_cb
        self.stop_event = threading.Event()
    def get_chunk(self, json_data):
        choice = json_data["choices"][0]
        if "text" in choice:
            chunk = choice["text"]
        elif "delta" in choice:
            delta = choice.get("delta", {})
            chunk = delta.get("content", "") or ""
        else:
            chunk = ""
        return chunk
    def run(self):
        try:
            host = self.c['ai_chat_base_url'].replace("https://", "").replace("http://", "")
            conn = http.client.HTTPSConnection(host, timeout=30)
            payload = {
                "model": self.c['ai_chat_model'], 
                "messages": self.m, 
                "max_tokens": int(self.c.get('max_tokens', 2048)), 
                "stream": True,
            }
            if self.c.get('ai_tools'):
                payload["tool_choice"] = "auto"
                payload["tools"] = self.c.get('ai_tools')
            payload = json.dumps(payload)
            headers = {
                'Content-Type': 'application/json', 
                'Accept': 'text/event-stream',
                'Authorization': 'Bearer ' + self.c['ai_chat_api_key']
            }
            conn.request("POST", self.c['ai_chat_path'], payload, headers)
            response = conn.getresponse()
            if response.status != 200:
                self.e_cb(Exception("API error: " + str(response.status) + " " + response.reason))
                return
            buffer = b""
            full_text = []
            end = False
            role_type = ''
            tool_call_ids = []
            tool_call_names = []
            tool_call_kv_args = {}
            while not end:
                chunk = response.read(16)
                if not chunk:
                    break
                buffer += chunk
                lines = buffer.split(b'\n')
                for line in lines[:-1]:
                    line = line.strip()
                    if not line:
                        continue
                    if line.startswith(b'data: '):
                        data = line[6:]
                        if data == b'[DONE]':
                            break
                        try:
                            json_data = json.loads(data.decode('utf-8'))
                            # print(json_data)
                            if 'choices' in json_data and json_data['choices']:
                                choice0 = json_data['choices'][0]
                                finish_reason = choice0.get("finish_reason")
                                tcalls = (choice0.get("delta") or {}).get("tool_calls")
                                if finish_reason == "tool_calls":
                                    end = True
                                    break
                                if tcalls:
                                    role_type = 'tools'
                                    t0 = tcalls[0]
                                    func = t0.get("function") or {}
                                    if func.get('name'):
                                        tool_call_ids.append(t0.get('id'))
                                        tool_call_names.append(func.get('name'))
                                    if func.get('arguments'):
                                        tool_call_kv_args[tool_call_ids[-1]] = tool_call_kv_args.get(tool_call_ids[-1], '')
                                        tool_call_kv_args[tool_call_ids[-1]] += func.get('arguments')
                                else:
                                    role_type = 'ai'
                                    text_chunk = self.get_chunk(json_data)
                                    full_text.append(text_chunk)
                                    self.b_cb(text_chunk)
                        except ValueError:
                            continue
                buffer = lines[-1]
            self.d_cb("".join(full_text), role_type)
            if role_type == 'ai':
                self.h.append({"role": "assistant", "content": "".join(full_text)})
                # print(json.dumps(self.h, indent=4, ensure_ascii=False))
            elif role_type == 'tools':
                self.h = copy.deepcopy(self.m)
                tcalls = []
                for tid, name in zip(tool_call_ids,tool_call_names):
                    tcalls.append({
                        'id': tid,
                        'type': 'function',
                        'function': {
                            'name': name,
                            'arguments': tool_call_kv_args[tid],
                        }
                    })
                self.h.append({
                    "role": "assistant", 
                    "tool_calls": tcalls
                })
                def callbcak(reslist):
                    # 处理调用函数返回的结果，用回调是用于兼容异步处理
                    for tid, res in reslist:
                        self.h.append({
                            "role": "tool",
                            "tool_call_id": tid,
                            "content": json.dumps(res),
                        })
                    ApiStreamThread(self.c,self.h,self.b_cb,self.d_cb,self.e_cb).start()
                self.call_tools(tool_call_ids, tool_call_names, tool_call_kv_args, callbcak)
        except Exception as e:
            self.e_cb(e)
        finally:
            try:
                conn.close()
            except:
                pass
    def call_tools(self, ids, names, kvargs, callbcak):
        retlist = []
        for id, name in zip(ids, names):
            args = json.loads(kvargs[id])
            retlist.append([id, mcp.call_tool(name, args)])
        callbcak(retlist)

class ClearChatMemoryCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        if self.view.id() in CHAT_MEMORY: del CHAT_MEMORY[self.view.id()]
        self.view.run_command("append_text", {"text": "\n[Memory Cleared]\n"})



















class JsonDumpsCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        region = sublime.Region(0, self.view.size())
        content = self.view.substr(region)
        try:
            data = json.loads(content)
            pretty = json.dumps(data, indent=4, ensure_ascii=False)
            self.view.replace(edit, region, pretty)
            sublime.status_message("JSON 格式化成功")
        except json.JSONDecodeError as e:
            sublime.status_message("JSON 解析错误: "+str(e))











class FoldExcessLengthOnLoad(sublime_plugin.EventListener):
    def __init__(self):
        self.max_line_length = 500
    def on_load(self, view):
        self.fold_excess_length(view)
    def fold_excess_length(self, view):
        cfg = load_config()
        max_line_length = int(cfg.get('max_line_length', self.max_line_length))
        for region in view.lines(sublime.Region(0, view.size())):
            line_text = view.substr(region)
            if len(line_text) > max_line_length:
                excess_region = sublime.Region(region.begin() + max_line_length, region.end())
                view.fold(excess_region)
    def on_activated(self, view):
        self.fold_excess_length(view)









def parse_cmd(self, command):
    cmd = []
    _cmds = command.split(' ')
    is_right = False
    is_bottom = False
    is_goback = False
    is_bat = True
    is_auto_close = False
    for i in range(10):
        if _cmds[0] == '{close}':
            _cmds = _cmds[1:]
            is_auto_close = True
        if _cmds[0] == '{right}':
            is_right = True
            _cmds = _cmds[1:]
        if _cmds[0] == '{bottom}':
            is_bottom = True
            _cmds = _cmds[1:]
        if _cmds[0] == '{back}':
            is_goback = True
            _cmds = _cmds[1:]
    cmd.extend(_cmds)
    file_path = self.view.file_name()
    if not file_path:
        print('no curr file')
        return
    cwd = os.path.dirname(file_path)
    for idx, i in enumerate(cmd):
        if "${file}" in i:
            file_name = os.path.split(file_path)[-1]
            cmd[idx] = file_name.join(i.split("${file}"))
    if is_bat:
        with open(self.batfile, 'w', encoding='utf8') as f:
            f.write("chcp 65001\n")
            for i in " ".join(cmd).split('&&'):
                f.write(i + '\n')
        cmd = [self.batfile]
    print(cmd)
    print(cwd)
    window = sublime.active_window()
    if is_right:
        window.set_layout({
            "cols": [0.0, 0.65, 1.0],
            "rows": [0.0, 1.0],
            "cells": [[0, 0, 1, 1], [1, 0, 2, 1]]
        })
        window.focus_group(1)
    if is_bottom:
        window.set_layout({
            "cols": [0.0, 1.0],
            "rows": [0.0, 0.65, 1.0],
            "cells": [[0, 0, 1, 1], [0, 1, 1, 2]]
        })
        window.focus_group(1)
    self.view.window().run_command("terminus_open", {
        "cmd": cmd,
        "cwd": cwd,
        "auto_close": is_auto_close,
    })
    if (is_right or is_bottom) and is_goback:
        sublime.set_timeout(lambda:window.focus_group(0), 300)

class VTerminuxCommand(sublime_plugin.TextCommand):
    cfgfile = os.path.join(os.path.expanduser("~"),'.vsublime.cfg.py')
    batfile = os.path.join(os.path.expanduser("~"),'.temp.bat')
    def run(self, edit):
        cfg = load_config()
        tabs = []
        if cfg.get('ai_chat_api_key') and cfg.get('ai_chat_api_key') != 'none':
            tabs.append(['[ai chat] (Ctrl+Enter)', 'ai_chat'])
        if cfg.get('ai_code_api_key') and cfg.get('ai_code_api_key') != 'none':
            tabs.append(['[ai code insert]', 'ai_insert'])
            tabs.append(['[ai code add]', 'ai_add'])
            tabs.append(['[ai code cancel]', 'ai_cancel'])
        tabs.append(['[json.dumps 4]', 'json_dumps'])
        for i in cfg['extra']: tabs.append([i, i])
        tabs.append(('[*] open_config', 'open_config'))
        tabs.append(('[*] terminus_open', 'terminus_open'))
        options = [name for name, _ in tabs]
        self.view.window().show_quick_panel(options, lambda index: self.on_done(index, tabs))
    def on_done(self, index, tabs):
        if index == -1: return
        command = tabs[index][1]
        if command == 'ai_chat':         self.view.window().run_command("v_universal_chat"); return
        if command == 'ai_add':          self.view.window().run_command("ai_curr_window_completion", { "type": "add" }); return
        if command == 'ai_insert':       self.view.window().run_command("ai_curr_window_completion", { "type": "insert" }); return
        if command == 'ai_cancel':       self.view.window().run_command("cancel_ai_completion"); return
        if command == 'json_dumps':      self.view.window().run_command("json_dumps"); return
        if command == 'open_config':     sublime.active_window().open_file(self.cfgfile); return
        if command == 'terminus_open':   self.view.window().run_command("terminus_open", { "cwd": "${file_path}" }); return
        parse_cmd(self, command)

class VCloseCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        layout_one = {"cols": [0.0, 1.0], "rows": [0.0, 1.0], "cells": [[0, 0, 1, 1]]}
        if self.view.window().num_groups() == 2 and len(self.view.window().views_in_group(1)) == 0:
            self.view.window().set_layout(layout_one)
        else:
            self.view.window().run_command("close")