<p align="center">
  <img src="https://raw.githubusercontent.com/kirineko/deepy/main/asset/deepy-logo.png" alt="Deepy logo" width="160">
</p>

<h1 align="center">Deepy</h1>

<p align="center">
  A cute terminal coding agent for DeepSeek models.
  <br>
  Read, edit, run tools, search the web, and keep project context in one terminal session.
</p>

<p align="center">
  <a href="https://kirineko.github.io/deepy/">Website</a>
  ·
  <a href="README.zh-CN.md">中文文档</a>
  ·
  <a href="#quick-start">Quick Start</a>
</p>

![Deepy welcome screen](https://raw.githubusercontent.com/kirineko/deepy/main/asset/welcome.jpg)

## What Is Deepy?

Deepy is a Python terminal coding agent built for DeepSeek's OpenAI-compatible
models. It keeps the workflow inside your terminal: ask questions, inspect a
project, edit files, run commands, search or fetch web content, and resume the
same project session later.

Deepy is designed around DeepSeek V4 thinking mode, long context, cache-friendly
prompting, and a Rich terminal interface that makes tool calls, diffs, usage, and
context state visible while the agent works.

## Highlights

- DeepSeek-first model setup with `deepseek-v4-pro`, thinking enabled, and
  `reasoning_effort=max` by default.
- OpenAI Agents SDK integration through `OpenAIChatCompletionsModel`.
- Project-aware coding tools for reading files, modifying files, running shell
  commands, and showing readable diffs.
- Web research tools for search and direct URL fetching when a task needs fresh
  information.
- Session history, `/resume`, `/new`, automatic context tracking, and compacting
  for long project work.
- TOML-only private configuration at `~/.deepy/config.toml`.
- Theme-aware terminal UI with Markdown rendering, DeepSeek thinking display,
  per-turn usage, context window status, and version update checks.

## See It Work

### Start In A Project

Deepy shows the current model, thinking settings, working directory, and the core
commands directly on startup.

![Deepy startup screen](https://raw.githubusercontent.com/kirineko/deepy/main/asset/welcome.jpg)

### Build And Verify Code

Ask Deepy to implement a change, write tests, run the project test command, and
summarize the result.

![Deepy coding workflow with diff](https://raw.githubusercontent.com/kirineko/deepy/main/asset/coding-1.jpg)

Deepy can also turn command output into a readable project summary, including
files created, code snippets, and test coverage.

![Deepy project summary](https://raw.githubusercontent.com/kirineko/deepy/main/asset/coding-2.jpg)

### Research With Sources

Deepy includes WebSearch and WebFetch tools, so a terminal session can gather
current information and fetch exact pages when a URL is provided.

![Deepy web research workflow](https://raw.githubusercontent.com/kirineko/deepy/main/asset/websearch.jpg)

## Quick Start

Install from PyPI after the first release:

```bash
uv tool install deepy-cli
```

The installed command is still `deepy`.

Install the latest code from GitHub:

```bash
uv tool install git+https://github.com/kirineko/deepy.git
```

Configure your DeepSeek API key:

```bash
deepy config setup
```

Start Deepy in a project:

```bash
cd your-project
deepy
```

## Configuration

Deepy only uses TOML configuration. JSON config files are intentionally rejected.

```toml
# ~/.deepy/config.toml
[model]
api_key = "sk-..."
name = "deepseek-v4-pro"
base_url = "https://api.deepseek.com"

[context]
window_tokens = 1048576
compact_trigger_ratio = 0.8

[ui]
theme = "auto" # auto, dark, or light
```

WebSearch uses Deepy's hosted SearXNG endpoint by default. You can override it
with your own SearXNG instance:

```toml
[tools.web_search]
searxng_url = "https://your-searxng.example/"
```

You can also initialize config non-interactively:

```bash
deepy config init --api-key sk-... --model deepseek-v4-pro
```

If your terminal uses a light background and parts of the UI look low contrast,
set the UI theme explicitly:

```bash
deepy config theme light
```

## Common Commands

```bash
deepy --version
deepy config setup
deepy config reset
deepy config theme
deepy config theme light
deepy doctor
deepy doctor --live --json
deepy status
deepy skills list
deepy sessions list
deepy sessions show <session-id>
deepy run "summarize this project"
```

Inside the interactive terminal:

```text
/skills   List available skills
/new      Start a fresh conversation
/resume   Pick a previous session
/theme    Show or change UI theme
/reset    Delete config and run setup again
/         Open the command menu
Esc       Interrupt the current model turn
Ctrl+D    Press twice to quit
```

## Project Rules And Skills

Deepy automatically loads project instructions from:

- `AGENTS.md`
- `.deepy/skills/*/SKILL.md`

This lets each repository define local conventions, commands, review rules, and
domain-specific skills without changing global config.

## Development

```bash
uv sync --group dev
uv run pytest
uv run ruff check
uv run pyright
uv build
```

The Python package is built from `src/deepy`. GitHub Pages files and screenshot
assets live outside the package directory and are not included in the wheel.

## Release Status

Deepy is preparing its first public `0.1.5` release. The current release path is
GitHub + PyPI. Standalone binaries and npm wrappers can be added later, but the
primary distribution is the Python CLI.
