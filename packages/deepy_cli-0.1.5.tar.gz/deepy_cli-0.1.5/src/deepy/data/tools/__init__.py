"""Built-in tool documentation."""
