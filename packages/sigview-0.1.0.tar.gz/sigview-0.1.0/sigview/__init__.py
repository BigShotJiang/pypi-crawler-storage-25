from __future__ import annotations

import html
import json
from importlib import resources
from pathlib import Path


class RunViewer:
    """Jupyter rich display wrapper for Sigview."""

    def __init__(
        self,
        path: str | Path | None = None,
        *,
        text: str | None = None,
        name: str | None = None,
        format: str | None = None,
        height: int = 720,
        template: str | Path | None = None,
    ) -> None:
        if path is None and text is None:
            raise ValueError("RunViewer needs either path or text")
        self.path = Path(path) if path is not None else None
        self.text = text
        self.name = name
        self.format = format
        self.height = int(height)
        self.template = Path(template) if template is not None else None

    @classmethod
    def from_text(
        cls,
        text: str,
        *,
        name: str = "waveform.csv",
        format: str | None = None,
        height: int = 720,
    ) -> "RunViewer":
        return cls(text=text, name=name, format=format, height=height)

    def _payload(self) -> dict[str, str]:
        if self.path is not None:
            text = self.path.read_text(encoding="utf-8")
            name = self.name or self.path.name
            fmt = self.format or self.path.suffix.lstrip(".")
        else:
            text = self.text or ""
            name = self.name or f"waveform.{self.format or 'csv'}"
            fmt = self.format or Path(name).suffix.lstrip(".")
        return {"text": text, "name": name, "format": fmt.lower()}

    def _template_html(self) -> str:
        if self.template is not None:
            if not self.template.exists():
                raise FileNotFoundError(f"{self.template} does not exist")
            return self.template.read_text(encoding="utf-8")

        try:
            return resources.files("sigview").joinpath("sigview.html").read_text(encoding="utf-8")
        except FileNotFoundError as exc:
            raise FileNotFoundError(
                "sigview/sigview.html does not exist; run `node sigview/build.js` "
                "before using RunViewer from a source checkout"
            ) from exc

    def _repr_html_(self) -> str:
        template = self._template_html()
        payload = json.dumps(self._payload(), ensure_ascii=False).replace("</", "<\\/")
        init_script = f"<script>globalThis.RUNVIEWER_INITIAL = {payload};</script>"
        srcdoc = template.replace("</body>", f"{init_script}\n</body>")
        return (
            '<iframe '
            'sandbox="allow-scripts allow-downloads" '
            f'style="width:100%;height:{self.height}px;border:1px solid #d0d7de;border-radius:6px;" '
            f'srcdoc="{html.escape(srcdoc, quote=True)}">'
            "</iframe>"
        )

