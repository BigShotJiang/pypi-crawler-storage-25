# SPDX-FileCopyrightText: 2026 Jiri Vyskocil
# SPDX-License-Identifier: 0BSD

"""Generate a Markdown map of GitHub workflows and jobs.

Parses ``.github/workflows/*.yml`` and ``.yaml`` files and produces a
Markdown document with workflow summary and per-job detail tables.
"""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

import yaml

# ── Entry point ─────────────────────────────────────────


def generate_ci_map(
    workflows: list[dict[str, object]] | None = None,
    *,
    workflows_dir: Path | None = None,
) -> str:
    """Generate the Markdown CI map.

    Args:
        workflows: Pre-loaded workflow data. If ``None``, loads from disk.
        workflows_dir: Override for the workflows directory.
    """
    if workflows is None:
        workflows = load_workflows(workflows_dir)
    job_count = sum(len(workflow["jobs"]) for workflow in workflows)
    now = datetime.now(UTC).strftime("%Y-%m-%d %H:%M UTC")

    lines = [
        "# CI Workflow Map\n\n",
        f"*Generated: {now}*\n\n",
        f"**{len(workflows)} workflows** with **{job_count} jobs**\n\n",
        "## Workflows\n\n",
        "| Workflow | File | Triggers | Jobs |\n",
        "|---|---|---|---|\n",
    ]
    for workflow in workflows:
        lines.append(
            f"| `{workflow['name']}` | `{workflow['file_name']}` | "
            f"{workflow['triggers']} | {len(workflow['jobs'])} |\n"
        )

    lines.extend(
        [
            "\n## Jobs\n\n",
            "| Workflow | Job | Needs | Uploads | Downloads |\n",
            "|---|---|---|---|---|\n",
        ]
    )
    for workflow in workflows:
        for job in workflow["jobs"]:
            lines.append(
                f"| `{workflow['name']}` | `{job['name']}` | {_render(job['needs'])} | "
                f"{_render(job['uploads'])} | {_render(job['downloads'])} |\n"
            )

    lines.append("\n")
    return "".join(lines)


# ── Workflow loading ────────────────────────────────────


def load_workflows(workflows_dir: Path | None = None) -> list[dict[str, object]]:
    """Load workflow and job facts from ``.github/workflows/*.yml``.

    Args:
        workflows_dir: Directory containing workflow YAML files.
            Defaults to ``.github/workflows/`` relative to cwd.
    """
    if workflows_dir is None:
        workflows_dir = Path.cwd() / ".github" / "workflows"
    workflows: list[dict[str, object]] = []
    yml_files = list(workflows_dir.glob("*.yml")) + list(workflows_dir.glob("*.yaml"))
    for path in sorted(yml_files):
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        if not isinstance(data, dict):
            continue

        jobs: list[dict[str, object]] = []
        jobs_section = data.get("jobs", {})
        if isinstance(jobs_section, dict):
            for job_id, job_data in jobs_section.items():
                if not isinstance(job_data, dict):
                    continue
                needs = job_data.get("needs", ())
                needs_tuple = (
                    (needs,)
                    if isinstance(needs, str)
                    else tuple(str(item) for item in needs)
                    if isinstance(needs, list)
                    else ()
                )
                jobs.append(
                    {
                        "name": str(job_data.get("name", job_id)),
                        "needs": needs_tuple,
                        "uploads": _artifact_names(
                            job_data.get("steps"), "actions/upload-artifact"
                        ),
                        "downloads": _artifact_names(
                            job_data.get("steps"), "actions/download-artifact"
                        ),
                    }
                )

        workflows.append(
            {
                "file_name": path.name,
                "name": str(data.get("name", path.stem)),
                "triggers": _trigger_summary(data),
                "jobs": jobs,
            }
        )
    return workflows


# ── Formatting helpers ──────────────────────────────────


def _artifact_names(steps: object, prefix: str) -> tuple[str, ...]:
    """Collect upload/download artifact names from a list of steps."""
    if not isinstance(steps, list):
        return ()
    names: list[str] = []
    for step in steps:
        if not isinstance(step, dict):
            continue
        uses = step.get("uses")
        if not isinstance(uses, str) or not uses.startswith(prefix):
            continue
        with_section = step.get("with", {})
        if isinstance(with_section, dict):
            name = with_section.get("name")
            names.append(str(name) if name else "(all artifacts)")
    return tuple(names)


def _trigger_summary(data: dict[object, object]) -> str:
    """Render the top-level ``on`` section as a compact string."""
    on_section = data.get("on", data.get(True, {}))
    if isinstance(on_section, str):
        return f"`{on_section}`"
    if isinstance(on_section, list):
        return ", ".join(f"`{item}`" for item in on_section)
    if not isinstance(on_section, dict):
        return "—"

    parts: list[str] = []
    for name, value in on_section.items():
        suffix = ""
        if isinstance(value, dict):
            if name in {"push", "pull_request", "pull_request_target"}:
                branches = value.get("branches")
                if isinstance(branches, list) and branches:
                    suffix = f"({', '.join(str(branch) for branch in branches)})"
            elif name == "workflow_run":
                workflows = value.get("workflows")
                if isinstance(workflows, list) and workflows:
                    suffix = f"({', '.join(str(workflow) for workflow in workflows)})"
        parts.append(f"`{name}{suffix}`")
    return ", ".join(parts) if parts else "—"


def _render(values: tuple[str, ...]) -> str:
    """Render a tuple of values into one Markdown table cell."""
    return "<br>".join(f"`{value}`" for value in values) if values else "—"
