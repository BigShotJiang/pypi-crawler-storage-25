# Copyright (C) 2021 Nimarosa (Nicolas Rodriguez) (<nicolasrsande@gmail.com>).
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

{
    "name": "Payroll Public Holidays",
    "version": "18.0.1.0.1",
    "category": "Payroll",
    "website": "https://github.com/OCA/payroll",
    "summary": "Integration between payroll and hr_public_holidays",
    "license": "AGPL-3",
    "author": "Nimarosa, Odoo Community Association (OCA)",
    "depends": ["payroll", "hr_holidays", "calendar_public_holiday"],
    "data": [],
    "installable": True,
    "maintainers": ["nimarosa"],
}
