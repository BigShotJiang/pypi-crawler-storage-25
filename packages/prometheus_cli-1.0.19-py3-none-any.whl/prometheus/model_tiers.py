"""Round 135: Strategic model-routing tiers.

Three named aliases — `haiku`, `sonnet`, `opus` — plus two
context-aware aliases (`opusplan`, `best`) and the OpenRouter
free-router shortcut (`auto/free` / `openrouter/free`).

Resolution priority (highest to lowest):

  1. /model command mid-session
  2. --model CLI flag at launch
  3. PROMETHEUS_MODEL environment variable
  4. settings file (`model` field)
  5. default: `auto/free` (OpenRouter free router)

Per-tier env overrides:

  * PROMETHEUS_DEFAULT_HAIKU_MODEL
  * PROMETHEUS_DEFAULT_SONNET_MODEL
  * PROMETHEUS_DEFAULT_OPUS_MODEL

Premium fallback: when `PROMETHEUS_PREMIUM=1` is set the alias
defaults flip to the Anthropic Claude line. Otherwise we
default to the best free OpenRouter slugs that PrometheUS has
proven work for tool-calling agents.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional


# ---------- defaults ----------


# Free-tier defaults — what `haiku` / `sonnet` / `opus` resolve
# to when no env override + no premium opt-in.
#
# 1.0.5 verification status (2026-05-09, round-205 model audit):
# Each slug below was directly verified live with a real `prometheus
# -p` call, NOT just by catalog presence. Frontier free models
# preferred — order matches the user's stated goal of "free models do
# the heavy lifting, paid key for explicit tasks only."
#
#   • haiku  →  google/gemma-4-31b-it:free      (frontier OS, native
#               function calling, 262k context, "gemma-test-passed")
#   • sonnet →  poolside/laguna-m.1:free         (flagship coding agent,
#               131k context, "laguna-m1-test-passed")
#   • opus   →  inclusionai/ring-2.6-1t:free     (1T-parameter coding
#               agent, 262k context, "ring-test-passed")
#
# Failover ladder: if any primary slug returns 404 / 429 / parse-loop,
# `provider/failover.py` rotates through `FREE_FALLBACK_POOL` below
# before any escalation to the paid key fires.
FREE_DEFAULTS: dict[str, str] = {
    # Verified live 2026-05-09: native function calling + 262k context.
    "haiku":  "google/gemma-4-31b-it:free",
    # Verified live 2026-05-09: flagship coding agent.
    "sonnet": "poolside/laguna-m.1:free",
    # Verified live 2026-05-09: 1T-param coding agent.
    "opus":   "inclusionai/ring-2.6-1t:free",
}

# 1.0.5: free-tier fallback pool. When a FREE_DEFAULTS slug returns
# 404 / 429 / parse-loop, the failover layer rotates through this
# list IN ORDER before any escalation to the paid key happens. Order
# is best-quality-first.
#
#   ✓ = live-verified  ·  ◯ = catalog-confirmed, not yet probed
FREE_FALLBACK_POOL: tuple[str, ...] = (
    # ✓ Already-known-good fallback (verified live in round-200).
    "minimax/minimax-m2.5:free",
    # ◯ Frontier MoE coding model, 262k context.
    "google/gemma-4-26b-a4b-it:free",
    # ◯ NVIDIA Nemotron 120B, 262k context, multi-agent oriented.
    "nvidia/nemotron-3-super-120b-a12b:free",
    # ◯ Smaller poolside coding model, 131k context.
    "poolside/laguna-xs.2:free",
    # ◯ NVIDIA reasoning sub-agent, 256k context.
    "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free",
)

# Premium defaults — what the same aliases resolve to when
# `PROMETHEUS_PREMIUM=1` is set and the user has paid creds.
PREMIUM_DEFAULTS: dict[str, str] = {
    "haiku":  "anthropic/claude-haiku-4-5",
    "sonnet": "anthropic/claude-sonnet-4-6",
    "opus":   "anthropic/claude-opus-4-7",
}


# Special routes:
#   * `auto/free` and `openrouter/free` → OpenRouter free router
#     (auto-selects best free model per request).
AUTO_FREE_ROUTE = "openrouter/auto"


VALID_TIERS = ("haiku", "sonnet", "opus")
VALID_ALIASES = VALID_TIERS + ("opusplan", "best", "auto/free", "openrouter/free")


# ---------- helpers ----------


def _premium_enabled() -> bool:
    return os.environ.get("PROMETHEUS_PREMIUM", "").strip().lower() in (
        "1", "true", "yes", "on",
    )


def _env_override(tier: str) -> Optional[str]:
    if tier == "haiku":
        return os.environ.get("PROMETHEUS_DEFAULT_HAIKU_MODEL")
    if tier == "sonnet":
        return os.environ.get("PROMETHEUS_DEFAULT_SONNET_MODEL")
    if tier == "opus":
        return os.environ.get("PROMETHEUS_DEFAULT_OPUS_MODEL")
    return None


def tier_default(tier: str) -> str:
    """Resolve a tier alias (`haiku`/`sonnet`/`opus`) to a model
    id. Env override > premium-vs-free table."""
    override = _env_override(tier)
    if override:
        return override.strip()
    table = PREMIUM_DEFAULTS if _premium_enabled() else FREE_DEFAULTS
    return table.get(tier, FREE_DEFAULTS["sonnet"])


# ---------- alias resolution ----------


def resolve_alias(
    requested: str,
    *,
    permission_mode: str = "default",
) -> str:
    """Round 135: turn an alias into a concrete model id.

    Pure resolution — no I/O, no provider calls. The host
    threads `permission_mode` so `opusplan` knows when to flip.

    Pass-through for unknown / explicit ids: when `requested`
    contains a `/`, treat it as a fully-qualified model id and
    return it unchanged."""
    val = (requested or "").strip()
    if not val:
        return tier_default("sonnet")
    low = val.lower()
    # Auto/free routes.
    if low in ("auto", "auto/free", "openrouter/free"):
        return AUTO_FREE_ROUTE
    # Best — most capable available.
    if low == "best":
        return tier_default("opus")
    # opusplan — opus during plan mode, sonnet otherwise.
    if low == "opusplan":
        return tier_default(
            "opus" if permission_mode == "plan" else "sonnet"
        )
    # Bare tier names.
    if low in VALID_TIERS:
        return tier_default(low)
    # Already a fully-qualified model id (`vendor/model`).
    if "/" in val:
        return val
    # Unknown short name — return as-is so the provider error
    # surface is the caller's, not ours.
    return val


# ---------- session-level resolver ----------


@dataclass
class ModelResolution:
    """The resolved model + the source that picked it. The UI
    surfaces both so users see why a particular model is active."""
    model: str
    source: str       # `cli` / `env` / `slash` / `settings` / `default`


def resolve_session_model(
    *,
    cli_flag: Optional[str] = None,
    slash_override: Optional[str] = None,
    settings_value: Optional[str] = None,
    permission_mode: str = "default",
) -> ModelResolution:
    """Round 135: priority resolver.

    Order:
      1. /model command mid-session   (slash_override)
      2. --model CLI flag             (cli_flag)
      3. PROMETHEUS_MODEL env         (env)
      4. settings.json `model`        (settings_value)
      5. default `auto/free`          (default)
    """
    if slash_override and slash_override.strip():
        return ModelResolution(
            model=resolve_alias(
                slash_override, permission_mode=permission_mode,
            ),
            source="slash",
        )
    if cli_flag and cli_flag.strip():
        return ModelResolution(
            model=resolve_alias(
                cli_flag, permission_mode=permission_mode,
            ),
            source="cli",
        )
    env_val = os.environ.get("PROMETHEUS_MODEL", "").strip()
    if env_val:
        return ModelResolution(
            model=resolve_alias(
                env_val, permission_mode=permission_mode,
            ),
            source="env",
        )
    if settings_value and settings_value.strip():
        return ModelResolution(
            model=resolve_alias(
                settings_value, permission_mode=permission_mode,
            ),
            source="settings",
        )
    return ModelResolution(
        model=resolve_alias("auto/free"),
        source="default",
    )


# ---------- subagent override ----------


def resolve_subagent_model(
    *,
    spawn_explicit: Optional[str] = None,
    parent_model: Optional[str] = None,
    permission_mode: str = "default",
) -> str:
    """Round 135: subagent model resolution.

    Order: explicit-on-spawn > PROMETHEUS_COHORT_MODEL env >
    parent-session model. Aliases are resolved through
    `resolve_alias` so the same `opus` shorthand works."""
    if spawn_explicit and spawn_explicit.strip():
        return resolve_alias(
            spawn_explicit, permission_mode=permission_mode,
        )
    env_val = os.environ.get("PROMETHEUS_COHORT_MODEL", "").strip()
    if env_val:
        return resolve_alias(env_val, permission_mode=permission_mode)
    if parent_model and parent_model.strip():
        return resolve_alias(
            parent_model, permission_mode=permission_mode,
        )
    return tier_default("sonnet")


# ---------- public catalogue ----------


def list_aliases() -> list[tuple[str, str]]:
    """Round 135: return alias → resolved model id pairs for
    `/model` to display."""
    out: list[tuple[str, str]] = []
    for tier in VALID_TIERS:
        out.append((tier, tier_default(tier)))
    out.append(("opusplan", f"{tier_default('opus')} → {tier_default('sonnet')}"))
    out.append(("best", tier_default("opus")))
    out.append(("auto/free", AUTO_FREE_ROUTE))
    return out


# ---------- fallback model ----------


def fallback_model() -> Optional[str]:
    """Round 130: PROMETHEUS_FALLBACK_MODEL or `--fallback-model`
    (set into the env at launch). When the primary model errors
    out (rate-limit / overload), the host should retry on this."""
    val = os.environ.get("PROMETHEUS_FALLBACK_MODEL", "").strip()
    if not val:
        return None
    return resolve_alias(val)
